package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.uedasRest.UedasRestClient;
import tr.com.aktifbank.integration.uedasV2.ServiceMessage;
import tr.com.aktifbank.integration.uedasV2.UedasV2Client;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.clkenerji.service.ebs_payment_operat�ons.FaultMessage;
import tr.com.uedas.BorcluSahisTahakkuklariniGetirBilgiler;
import tr.com.uedas.MutabakatOzetiGetirResponse;
import tr.com.uedas.MutabakatYapResponse;
import tr.com.uedas.OdemeIptalEtResponse;
import tr.com.uedas.OdemeYapResponse;
import tr.com.uedas.TalimatIptalEtResponse;
import tr.com.uedas.TalimatlandirTekilKodResponse;
import tr.com.uedas.TalimatlandirmaDetayiGetirBilgiler;
import tr.com.uedas.TalimatlandirmaMutabakatDetayiGetirResponse;
import tr.com.uedas.TalimatlandirmaMutabakatOzetiGetirResponse;
import tr.com.uedas.TalimatliSahisBorclariniGetirResponse;
import uedasV2.entity.AboneBorcluTahakkuklarDetayliSahisliResult;
import uedasV2.entity.AboneGetirBorcluSahislarTekilKodResult;
import uedasV2.entity.TahsilatIptalEtYeniResult;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class UEDASServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(BedasCampaignServices.class);

	private static String p_BNKKD = "143";
	private static String p_TIP = "1";
	private static String p_BUKRS = "610"; // Kayseri Gaz
	private static String p_NEDEN = "01"; // �01� �m�nferit iptal
	private static String IV_ISLEM_INSERT = "I"; // I(�nsert): Otomatik �deme talimat� verme
	private static String IV_ISLEM_DELETE = "D"; // D(Delete): Otomatik �deme talimat� iptal etme

	private static final String ERROR_STATUS = "Error";
	private static final String BRANCH_CODE = "555";
	private static final String DEFAULT_USER_CODE = "U0000";
	private static final String DEFAULT_AGENT_CODE = "A0000";
	private static final String DEFAULT_CHANNEL_CODE = "C0000";

	@GraymoundService("ICS_UEDAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UEDAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String errorCode = "";
		String errorMessage = "";
		int counter = 0;
		String p_sDonem = "";
		String offerText = "";
		// boolean isEligibleConsumer = false;
		String customerPersonalNumber = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int p_nTekilKod = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
		int p_nAboneSahis = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
		String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
		String tedarikciID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
		int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String channelCode = CommonHelper.getChannelId();
		String p_sKanalKodu = channelCode;
		String userCode = DEFAULT_USER_CODE;
		String agentCode = DEFAULT_AGENT_CODE;
		// StringBuilder sb=new StringBuilder();
		if (!StringUtil.isEmpty(iMap.getString(MapKeys.AGENT_CODE))) {
			agentCode = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);
		}
		if (!StringUtil.isEmpty(iMap.getString(MapKeys.USER_CODE))) {
			userCode = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
		}

		String p_sBankaKullaniciKodu = userCode;
		String p_sBayiKodu = agentCode;
		ServiceMessage serviceMessage = new ServiceMessage();
		String aboneKodu = "ABONE_KODU=";
		ArrayList<uedasV2.entity.AboneBorcluTahakkuklarDetayliSahisliResult> debtList = null;
		ArrayList<AboneGetirBorcluSahislarTekilKodResult> customerList = null;
		boolean customerNotFound = false;
		boolean hasActiveCustomer = false;
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String isCampaignChannel = CommonHelper.getValueOfParameter("BEDAS_CAMPAIGN_CHANNEL_MAPPING", channelCode);
			outMap.put(MapKeys.IS_CAMPAIGN_CHANNEL, isCampaignChannel);
			logger.info("ICS_UEDAS_INVOICE_DEBT_INQUIRY is called and isCampaignChannel true with channel value of ".concat(channelCode));
			customerList = UedasV2Client.aboneGetirBorcluSahislarTekilKod(p_nTekilKod, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage, timeOut);
			insertWsCallLog(iMap, serviceMessage);
			try {
				if (null == customerList.get(0).getSatisDurumu()) {
					hasActiveCustomer = false;
				}
				else {
					hasActiveCustomer = true;
				}

				if (null == customerList.get(0).getEksikBilgiVarMi()) {
					hasActiveCustomer = false;
				}
				else {
					hasActiveCustomer = true;
					outMap.put(MapKeys.MISSING_INFORMATION, customerList.get(0).getEksikBilgiVarMi());
				}
			}
			catch (Exception e) {
				logger.info("ICS_UEDAS_INVOICE_DEBT_INQUIRY -> aktif musteri kontrolunde hata aldi -> ".concat(e.toString()));
				customerNotFound = true;
			}
			iMap.put("REQUEST_XML_ABONE_GETIR_BORCLU_SAHISLAR", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML_ABONE_GETIR_BORCLU_SAHISLAR", serviceMessage.getResponse());
			// responseCode = GeneralConstants.ERROR_CODE_APPROVE;

			// if (customerList.size() > 0) {
			// if (customerList == null) {
			//
			// }
			//
			// }

			if (!customerNotFound) {
				if (customerList != null) {
					// if (customerControlNumber > 1) {
					// for (int z = customerStartNumber; z < customerList.size(); z++) {
					for (int z = 0; z < customerList.size(); z++) {
						p_nAboneSahis = Integer.parseInt(customerList.get(z).getAboneSahisKodu());

						debtList = UedasV2Client.aboneBorcluTahakkuklarDetayliSahisli(p_nAboneSahis, p_sDonem, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, p_sKanalKodu, p_sBankaKullaniciKodu, p_sBayiKodu, serviceMessage, timeOut);
						insertWsCallLog(iMap, serviceMessage);
						iMap.put("REQUEST_XML_FOR_DEBT_INQ_NKOLAY_".concat(Integer.toString(z)), serviceMessage.getRequest());
						outMap.put("RESPONSE_XML_FOR_DEBT_INQ_NKOLAY_".concat(Integer.toString(z)), serviceMessage.getResponse());
						for (AboneBorcluTahakkuklarDetayliSahisliResult borc : debtList) {
							if (tedarikciID.equals(borc.getTedarikciID())) {
								String termYear = borc.getDnm().split("/")[0];
								String termMonth = borc.getDnm().split("/")[1];
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_nTekilKod);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_nAboneSahis);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getThkNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getBorc());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSyd());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonTrh(), "dd.MM.yyyy"));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getBorc());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "0");
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getIslKod());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, "#PasifAbone=EVET#Taksit No:0".concat(borc.getDetay()).concat("TEDARIKCIID=".concat(borc.getTedarikciID()).concat("#")));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, aboneKodu);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER16, borc.getTedarikciID());
								outMap.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", z + 1 + ". Abone Borcu");
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
							}
						}
					}
				}
			}
			else {
				debtList = UedasV2Client.aboneBorcluTahakkuklarDetayliSahisli(p_nAboneSahis, p_sDonem, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, p_sKanalKodu, p_sBankaKullaniciKodu, p_sBayiKodu, serviceMessage, timeOut);
				insertWsCallLog(iMap, serviceMessage);
				iMap.put("REQUEST_XML_FOR_DEBT_INQ_NKOLAY_".concat(Integer.toString(0)), serviceMessage.getRequest());
				outMap.put("RESPONSE_XML_FOR_DEBT_INQ_NKOLAY_".concat(Integer.toString(0)), serviceMessage.getResponse());
				for (AboneBorcluTahakkuklarDetayliSahisliResult borc : debtList) {
					if (tedarikciID.equals(borc.getTedarikciID())) {
						String termYear = borc.getDnm().split("/")[0];
						String termMonth = borc.getDnm().split("/")[1];
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_nTekilKod);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_nAboneSahis);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getThkNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSyd());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonTrh(), "dd.MM.yyyy"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "0");
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getIslKod());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, "#PasifAbone=EVET#Taksit No:0".concat(borc.getDetay()).concat("TEDARIKCIID=".concat(borc.getTedarikciID()).concat("#")));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, aboneKodu);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER16, borc.getTedarikciID());
						outMap.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", 0 + 1 + ". Abone Borcu");
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
				if (debtList == null) {
					responseCode = "660";
					errorMessage = "Beda� bor� sorgulamada kurum servis cagriminda hata meydana geldi.";
				}
				else if (debtList.size() == 1 && ERROR_STATUS.equalsIgnoreCase(debtList.get(0).getT())) {
					responseCode = "660";
					errorMessage = debtList.get(0).getMsg();
				}

			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			// else {
			// logger.error("ICS_UEDAS_INVOICE_DEBT_INQUIRY -> an error occured - customer not found exception");
			// outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			// outMap.put(MapKeys.ERROR_CODE, responseCode);
			// outMap.put(MapKeys.ERROR_DESC, errorMessage.concat(" (Beda� ile irtibat kurun!)"));
			// outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage.concat(" (Beda� ile irtibat kurun!)"));
			// }
		}
		catch (Exception e) {
			logger.error("ICS_UEDAS_INVOICE_DEBT_INQUIRY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_UEDAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UEDAS_DO_INVOICE_COLLECTION");
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		String errorMessage = "";
		try {
			boolean installmentPayment = false;
			boolean collected = false;
			String updatedThsNo = "";
			String errorCode = "";
			String hataKodu = "";
			String hataMesaji = "";
			String channelCode = CommonHelper.getChannelId();
			String userCode = DEFAULT_USER_CODE;
			String agentCode = DEFAULT_AGENT_CODE;
			String installmentNo = iMap.getString(MapKeys.INSTALLMENT_NO);
			BigDecimal p_sTutar = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String amount = iMap.getString(MapKeys.PAYMENT_AMOUNT);

			// StringBuilder sb=new StringBuilder();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.AGENT_CODE))) {
				agentCode = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);
			}
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.USER_CODE))) {
				userCode = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
			}
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			int p_nIsletmeKodu = iMap.getInt(MapKeys.PARAMETER1);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			String endPoint = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			}
			else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			ServiceMessage serviceMessage = new ServiceMessage();
			uedasV2.entity.OnlineTahsilEtV2YeniResult response = null;

			if (StringUtil.isEmpty(channelCode)) {
				responseCode = "660";
				errorMessage = "Kanal bilgisi bo� geldi�i i�in �deme yap�lamaz!";
			}
			else {

				String isCampaignChannel = CommonHelper.getValueOfParameter("BEDAS_CAMPAIGN_CHANNEL_MAPPING", channelCode);
				if ("EVET".equals(isCampaignChannel)) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					boolean taksitliOdemeMi = false;
					if (iMap.getString(MapKeys.INSTALLMENT_NO) != null) {
						if (!iMap.getString(MapKeys.INSTALLMENT_NO).isEmpty()) {
							if (!"0".equals(iMap.getString(MapKeys.INSTALLMENT_NO)) && !"9999".equals(iMap.getString(MapKeys.INSTALLMENT_NO))) {
								taksitliOdemeMi = true;
							}
						}
					}

					response = UedasV2Client.onlineTahsilEtV2Yeni(p_nIsletmeKodu, tahakkukNo, tahsilatTarihi, BRANCH_CODE, p_sBankaKodu, p_sIslemReferansNo, channelCode, userCode, agentCode, sLoginName, sPassword, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), endPoint, serviceMessage, timeOut);
					if (response == null) {
						responseCode = "660";
						errorMessage = "Fatura �deme sirasinda hata meydana geldi.";
					}
					else if (ERROR_STATUS.equalsIgnoreCase(response.getT())) {
						if (serviceMessage.getResponse().contains("Tahsil Eden: AKTIF YATIRIM BANKASI")) {
							collected = true;
						}
						else {
							responseCode = "660";
							errorMessage = response.getMsg();
						}
					}

					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						Session session = DAOSession.getSession("BNSPRDal");
						invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
						if (collected) {
							try {
								String str = response.getMsg();
								int baslangic = str.indexOf("ThsNo:") + 7;
								int bitis = baslangic + 17;
								str = str.substring(baslangic, bitis);
								invoicePayment.setParameter2(str);
								invoicePayment.setParameter20("UEDAS_HATA_YAKALAMA_ILE_ODENDI");
							}
							catch (Exception e) {
								invoicePayment.setParameter2("");
							}
						}
						else {
							invoicePayment.setParameter2(response.getThsNo());
							invoicePayment.setParameter3(response.getAdr());
							invoicePayment.setParameter4(response.getAdSyd());
							invoicePayment.setParameter5(response.getAIslKod());
							invoicePayment.setParameter6(response.getANo());
							invoicePayment.setParameter7(response.getMsg());
							invoicePayment.setParameter8(response.getOTrh());
							invoicePayment.setParameter9(response.getT());
							invoicePayment.setParameter10(response.getThkNo());
							invoicePayment.setParameter11(response.getThsIslKod());
							invoicePayment.setParameter12(response.getThsNo());
							invoicePayment.setParameter13(channelCode);
							invoicePayment.setParameter14(agentCode);
							invoicePayment.setParameter15(userCode);
							// invoicePayment.setParameter20(sb.toString());

						}
						session.saveOrUpdate(invoicePayment);
					}

					iMap.put("REQUEST_XML_FOR_PAYMENT", serviceMessage.getRequest());
					outMap.put("RESPONSE_XML_FOR_PAYMENT", serviceMessage.getResponse());

				}
				else {

					String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
					String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
					String bankUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
					int p_nTedarikciID = iMap.getInt(MapKeys.PARAMETER16);
					String header = "";
					tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
					tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(bankUrl, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
					if (loginResponse.getSonucMesaj() == null) {
						header = loginResponse.getSonucIcerik().get(0).getToken();
					}
					else {
						responseCode = loginResponse.getSonucMesaj();
					}
					iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
					outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
					OdemeYapResponse odemeYapResponse = null;
					String responseMessage = "";
					boolean p_bKismiTahsilatMi = false;
					Date p_dtOdemeTarihi = new Date();
					String p_sSubeKodu = BRANCH_CODE;
					tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageOdemeYap = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
					odemeYapResponse = UedasRestClient.odemeYap(bankUrl, header, serviceMessageOdemeYap, p_bKismiTahsilatMi, isStandingOrderCollection, p_dtOdemeTarihi, p_nTedarikciID, p_nIsletmeKodu, p_sIslemReferansNo, p_sSubeKodu, tahakkukNo, p_sTutar);
					if (odemeYapResponse.getSonucMesaj() == null) {
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					}
					else {
						responseCode = "660";
						errorMessage = odemeYapResponse.getSonucMesaj();
					}
					iMap.put("REQUEST_XML", serviceMessageOdemeYap.getRequest());
					outMap.put("RESPONSE_XML", serviceMessageOdemeYap.getResponse());
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCodeBranch = responceCodeMap.getString(MapKeys.ERROR_CODE);
					if (errorCodeBranch.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						updatedThsNo = odemeYapResponse.getSonucIcerik().get(0).getThsFisNo();

						Session session = DAOSession.getSession("BNSPRDal");
						invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
						invoicePayment.setParameter2(updatedThsNo);
						session.saveOrUpdate(invoicePayment);
					}

				}

			}

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("ICS_UEDAS_DO_INVOICE_COLLECTION is called an error occured with explanation : ".concat(CommonHelper.getStringifiedException(e2)));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE.concat(errorMessage));
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_UEDAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UEDAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String errorMessage = "";
		try {
			String channel = CommonHelper.getChannelId();

			String channelCode = iMap.getString(MapKeys.CHANNEL_CODE, DEFAULT_CHANNEL_CODE);
			String userCode = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
			String agentCode = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int p_nIsletmeKodu = iMap.getInt(MapKeys.PARAMETER_1);
			String p_sThsFisNo = iMap.getString(MapKeys.PARAMETER_2);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String wsUrlBanka = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String endPoint = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String isCampaignChannel = CommonHelper.getValueOfParameter("BEDAS_CAMPAIGN_CHANNEL_MAPPING", channel);
			if ("EVET".equals(isCampaignChannel)) {
				ServiceMessage serviceMessage = new ServiceMessage();
				TahsilatIptalEtYeniResult response = UedasV2Client.tahsilatIptalEtYeni(p_nIsletmeKodu, p_sThsFisNo, channelCode, agentCode, userCode, p_sLoginName, p_sPassword, p_sBankaKodu, userName, password, endPoint, serviceMessage, timeOut);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				if (response == null) {
					responseCode = "660";
					errorMessage = "Tahsilat iptali sirasinda beklenmeyen bir hata meydana geldi.";
				}
				else if (ERROR_STATUS.equalsIgnoreCase(response.getT())) {
					responseCode = "660";
					errorMessage = response.getMsg();
				}
				else {
					if (response.getT().equals("Success")) {
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					}
				}
			}
			else {

				int p_nTedarikciID = iMap.getInt(MapKeys.PARAMETER_16);
				String header = "";
				tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
				tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(wsUrlBanka, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
				if (loginResponse.getSonucMesaj() == null) {
					header = loginResponse.getSonucIcerik().get(0).getToken();
				}
				else {
					responseCode = loginResponse.getSonucMesaj();
				}
				iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
				outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
				OdemeIptalEtResponse odemeIptalEtResponse = null;
				String responseMessage = "";
				tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageOdemeIptalEt = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
				odemeIptalEtResponse = UedasRestClient.odemeIptalEt(wsUrlBanka, header, serviceMessageOdemeIptalEt, p_nTedarikciID, p_nIsletmeKodu, p_sThsFisNo);
				if (odemeIptalEtResponse.getSonucMesaj() == null) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				else {
					responseCode = "660";
					errorMessage = odemeIptalEtResponse.getSonucMesaj();
				}
				iMap.put("REQUEST_XML", serviceMessageOdemeIptalEt.getRequest());
				outMap.put("RESPONSE_XML", serviceMessageOdemeIptalEt.getResponse());
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("ICS_UEDAS_SEND_COLLECTION_CANCEL_MESSAGE is called an error occured with explanation : ".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_UEDAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_UEDAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int p_nTekilKod = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String bankUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int tedarikciID = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String errorMessage = "";
			String header = "";
			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
			tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(url, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
			if (loginResponse.getSonucMesaj() == null) {
				header = loginResponse.getSonucIcerik().get(0).getToken();
			}
			else {
				responseCode = loginResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			TalimatlandirTekilKodResponse talimatlandirTekilKodResponse = null;
			String responseMessage = "";
			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessage = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
			talimatlandirTekilKodResponse = UedasRestClient.talimatlandirTekilKod(url, header, serviceMessage, tedarikciID, p_nTekilKod);
			if (talimatlandirTekilKodResponse.getSonucMesaj() == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			else {
				responseCode = "660";
				errorMessage = talimatlandirTekilKodResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				String sahisTekilKod = talimatlandirTekilKodResponse.getSonucIcerik().get(0).getSahisTekilKod();

				Session session = DAOSession.getSession("BNSPRDal");
				icsStandingOrders icsStandingOrder = (icsStandingOrders) session.createCriteria(icsStandingOrders.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("subscriberNo1", iMap.getString(MapKeys.SUBSCRIBER_NO1))).uniqueResult();
				icsStandingOrder.setSubscriberNo2(sahisTekilKod);
				;
				session.saveOrUpdate(icsStandingOrder);
				session.flush();
			}

			insertOnlineServiceLog(iMap, outMap);

		}
		catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_UEDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_UEDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int p_nSahisTekilKod = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String bankUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int tedarikciID = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String errorMessage = "";
			String header = "";
			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
			tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(url, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
			if (loginResponse.getSonucMesaj() == null) {
				header = loginResponse.getSonucIcerik().get(0).getToken();
			}
			else {
				responseCode = loginResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			TalimatIptalEtResponse talimatIptalEtResponse = null;
			String responseMessage = "";
			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessage = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
			talimatIptalEtResponse = UedasRestClient.talimatIptalEt(url, header, serviceMessage, p_nSahisTekilKod, tedarikciID);
			if (talimatIptalEtResponse.getSonucMesaj() == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			else {
				responseCode = "660";
				errorMessage = talimatIptalEtResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			insertOnlineServiceLog(iMap, outMap);

		}
		catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_UEDAS_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_UEDAS_STANDING_ORDER_RECONCILIATION");
		GMMap output = new GMMap();

		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String responseMessage = "";
		int corpCancelCount = 0;
		int corpOrderCount = 0;
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		TalimatlandirmaMutabakatOzetiGetirResponse response = null;

		try {

			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int p_nTedarikciID = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String p_dtTalimatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");

			String header = "";
			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
			tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(url, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
			if (loginResponse.getSonucMesaj() == null) {
				header = loginResponse.getSonucIcerik().get(0).getToken();
			}
			else {
				responseCode = loginResponse.getSonucMesaj();
			}

			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageTMutabakatOzeti = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();

			try {
				response = UedasRestClient.talimatMutabakatOzetGetir(url, header, serviceMessageTMutabakatOzeti, p_nTedarikciID, p_dtTalimatTarihi);
				responseCode = String.valueOf(response.getSonucDurum());
				responseMessage = response.getSonucMesaj();
				if (response.getSonucMesaj() == null) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				else {
					responseCode = "660";
				}
			}
			catch (FaultMessage f) {
				logger.error("UEDAS HATA:", f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("STO_UEDAS_STANDING_ORDER_RECONCILIATION ".concat(" - an error is occured (FaultMessage)"));
				// responseCode = serviceMessageTMutabakatOzeti.getResponse()()..getResponseCode();
				// responseMessage = serviceMessageTMutabakatOzeti.getResponseMessage();
				logger.info("STO_UEDAS_STANDING_ORDER_RECONCILIATION error code = ".concat(responseCode));
				logger.info("STO_UEDAS_STANDING_ORDER_RECONCILIATION error message = ".concat(responseMessage));
			}

			iMap.put("REQUEST_XML", serviceMessageTMutabakatOzeti.getRequest());
			output.put("RESPONSE_XML", serviceMessageTMutabakatOzeti.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				try {
					corpCancelCount = response.getSonucIcerik().get(0).getIptal();
				}
				catch (Exception e) {
					corpCancelCount = 0;
					logger.error("STO_UEDAS_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi alinirken hata meydana geldi");
				}
				try {
					corpOrderCount = response.getSonucIcerik().get(0).getYeni();
				}
				catch (Exception e) {
					corpOrderCount = 0;
					logger.error("STO_UEDAS_STANDING_ORDER_RECONCILIATION -> talimat sayisi alinirken hata meydana geldi");
				}
			}

			if (!responceCodeMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// // hata meydana geldi
				logger.error("STO_UEDAS_STANDING_ORDER_RECONCILIATION -> kurum web servisinde hata meydana geldi...");
				output.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				output.put(MapKeys.RECON_BANK_COUNT, 0);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
				responseCode = "3342";
			}
			else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
			GMMap sorMap = BedasCampaignServices.getBankStandingOrdersForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			GMMap sorcMap = BedasCampaignServices.getBankStandingOrderCancelsForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			int bankOrderCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			int bankCancelCount = sorcMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);

			// GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			// List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");
			// List<icsStandingOrders> bankCancelledStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");

			output.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
			output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);

			output.put(MapKeys.RECON_CORPORATE_COUNT, corpOrderCount);
			output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancelCount);

			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Throwable e) {
			responseCode = "3342";
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap standingOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		String collectionTypeId = "0";
		String responseCode = "";
		String responseMessage = "";
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");

		String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
		int p_nTedarikciID = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

		TalimatlandirmaMutabakatDetayiGetirResponse response = null;
		String p_dtTalimatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");

		String header = "";
		tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
		tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(url, serviceMessageLogin, bankCode, p_sLoginName, p_sPassword);
		if (loginResponse.getSonucMesaj() == null) {
			header = loginResponse.getSonucIcerik().get(0).getToken();
		}
		else {
			responseCode = loginResponse.getSonucMesaj();
		}

		tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageTMutabakatDetay = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();

		try {
			try {
				response = UedasRestClient.talimatlandirmaMutabakatDetayiGetir(url, header, serviceMessageTMutabakatDetay, p_nTedarikciID, p_dtTalimatTarihi);
				responseCode = String.valueOf(response.getSonucDurum());
				responseMessage = response.getSonucMesaj();
				if (response.getSonucMesaj() == null) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				else {
					responseCode = "660";
				}
			}
			catch (Exception f) {
				logger.error("UEDAS HATA:", f);
				// FaultMessage kurum tarafindan gelen mant�ksal bir
				// hata oldugu icin logluyoruz
				logger.error("STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL ".concat(" - an error is occured (FaultMessage)"));
				// responseCode = serviceMessage.getResponseCode();
				// responseMessage = serviceMessage.getResponseMessage();
				logger.info("STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL error code = ".concat(responseCode));
				logger.info("STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL error message = ".concat(responseMessage));
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			iMap.put("REQUEST_XML", serviceMessageTMutabakatDetay.getRequest());
			outMap.put("RESPONSE_XML", serviceMessageTMutabakatDetay.getResponse());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				logger.info("...STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL detaya girdi...");
				boolean found = true;

				GMMap bsorMap = BedasCampaignServices.getBankStandingOrdersDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
				GMMap bsorcMap = BedasCampaignServices.getBankStandingOrderCancelsDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);

				List<TalimatlandirmaDetayiGetirBilgiler> corporateList = response.getSonucIcerik();

				ArrayList corporateStandingOrderList = new ArrayList();
				ArrayList corporateStandingOrderCancelList = new ArrayList();

				for (int i = 0; i < corporateList.size(); i++) {
					if (corporateList.get(i).getIslem().equals("YENI")) {
						corporateStandingOrderList.add((TalimatlandirmaDetayiGetirBilgiler) corporateList.get(i));
					}
					if (corporateList.get(i).getIslem().equals("IPTAL")) {
						corporateStandingOrderCancelList.add((TalimatlandirmaDetayiGetirBilgiler) corporateList.get(i));
					}
				}

				int bankOrderCount = bsorMap.getInt("DETAIL_COUNT");
				int bankOrderCancelCount = bsorcMap.getInt("DETAIL_COUNT");

				int corporateOrderCount = corporateStandingOrderList.size();
				int corporateOrderCancelCount = corporateStandingOrderCancelList.size();

				for (int i = 0; i < bankOrderCount; i++) {
					for (int j = 0; j < corporateOrderCount; j++) {
						if (bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1).equals(((TalimatlandirmaDetayiGetirBilgiler) corporateStandingOrderList.get(j)).getTekilKod()) && bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2).equals(((TalimatlandirmaDetayiGetirBilgiler) corporateStandingOrderList.get(j)).getSahisTekilKod())) {

							found = true;// bizdeki talimat kaydi kurumda
							break; // bulundu//
						}
						else {
							found = false;// bizdeki talimat kaydi kurumda
											// bulunamadi
						}
					}
					//
					if (!found) {
						// bulunamayan numara icin talimat istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						}
						catch (GMRuntimeException e) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
					}
				}

				found = false;
				if (bankOrderCancelCount > corporateOrderCancelCount)
					for (int i = 0; i < bankOrderCancelCount; i++) {
						for (int j = 0; j < corporateOrderCancelCount; j++) {

							if (bsorMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1).equals(((TalimatlandirmaDetayiGetirBilgiler) corporateStandingOrderList.get(j)).getTekilKod()) && bsorMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2).equals(((TalimatlandirmaDetayiGetirBilgiler) corporateStandingOrderList.get(j)).getSahisTekilKod())) {
								found = true;
								break;
							}
							else {
								found = false;
							}
						}
						if (!found) {

							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							}
							catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent); //
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}

				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				insertOnlineServiceLog(iMap, outMap);

			}
			else {
				// detay mutabakat sirasinda hata olustu
				responseCode = "3422";
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				insertOnlineServiceLog(iMap, outMap);
			}

		}

		catch (Throwable e2) {
			logger.error("An exception occured while executing STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	// @GraymoundService("STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	// public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
	// iMap.put(MapKeys.WS_SERVICE_NAME,"STO_UEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
	// String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
	// String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
	// GMMap outMap = new GMMap();
	// String responseCode = "";
	// try {
	// String reconDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
	// IntHolder talimatSayisi = new IntHolder();
	// IntHolder talimatIptalSayisi = new IntHolder();
	//
	// TABLE_OF_ZISU_WS_OOT_CHECK_SHolder t_OUT = new TABLE_OF_ZISU_WS_OOT_CHECK_SHolder();
	// TABLE_OF_ZISU_WS_OOT_CHECK_SHolder t_OUT2 = new TABLE_OF_ZISU_WS_OOT_CHECK_SHolder();
	//
	// responseCode = KayseriGazClient.talimatMutabakat(p_BUKRS, p_BNKKD, reconDate, talimatSayisi, talimatIptalSayisi, t_OUT, t_OUT2, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
	//
	// GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
	// String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
	//
	// outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
	// outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	// outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
	//
	// if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
	// for(ZISU_WS_OOT_CHECK_S talimat : t_OUT.value){
	// outMap.put(MapKeys.SUBSCRIBER_NO1, talimat.getVKONT());
	// }
	// }
	//
	// GMMap rcInput = new GMMap();
	// rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
	// iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
	// rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));
	// GMMap listMap = new GMMap();
	// listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
	//
	// @SuppressWarnings("unchecked")
	// List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST");
	// List<ZISU_WS_OOT_CHECK_S> corpStandingOrderList = Arrays.asList(t_OUT.value);
	//
	// boolean found = false;
	// if (bankStandingOrderList.size() > corpStandingOrderList.size()) {
	// short collectionType = 0;
	// for (int j=0; j < bankStandingOrderList.size(); j++) {
	// for (int i = 0; i < corpStandingOrderList.size(); i++) {
	// if (bankStandingOrderList.get(j).getSubscriberNo1().equals(corpStandingOrderList.get(i).getVKONT())) {
	// collectionType = bankStandingOrderList.get(j).getCollectionType();
	// found = true;
	// corpStandingOrderList.remove(i);
	// break;
	// } else {
	// found = false;
	// }
	// }
	// if (!found) {
	// // bulunamayan numara icin talimat istegi gonder
	// GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
	// String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
	// String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
	// GMMap onlineCorporateServiceCallInputMap = new GMMap();
	// GMMap onlineCorporateServiceCallOutputMap = new GMMap();
	// onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderList.get(j).getSubscriberNo1());
	// onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
	// onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
	// onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
	// onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
	// onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
	// onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
	// GMMap reconProcessDataLogInsertInputMap = new GMMap();
	// try {
	// onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
	// } catch (GMRuntimeException e) {
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
	// }
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);// Talimat Mesaji Gonderildi
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderList.get(j).getSubscriberNo1());
	// CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
	// }
	// }
	// } else if(bankStandingOrderList.size() == corpStandingOrderList.size()){
	// /* DB deki kayitlar hicbir zaman az olamaz, hepsini cekiyoruz.
	// * Toplam olusturulan sayilar esit olur ancak iptal statusunde olanlarda farkliliklar olabilir.
	// * DB tarafinda iptal statusu fazla olan olabilir, eksik olamaz.
	// * Karsiya iptal gitmedi isi bizde iptal fazla olur. iptal edilen abone tekrar talimat
	// * verdiyse zaten yeni kayit ekliyoruz. Bu yeni verilen talimat ulasmadi ise de yukaridaki
	// * dongude kontrol ediliyor.
	// */
	// short collectionType = 0;
	//
	// @SuppressWarnings("unchecked")
	// List<icsStandingOrders> bankStandingOrderCancelList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");
	// List<ZISU_WS_OOT_CHECK_S> corpStandingOrderCancelList = Arrays.asList(t_OUT2.value);
	//
	// for (int j=0; j < bankStandingOrderCancelList.size(); j++) {
	// for (int i = 0; i < corpStandingOrderCancelList.size(); i++) {
	// if (bankStandingOrderCancelList.get(j).getSubscriberNo1().equals(corpStandingOrderCancelList.get(i).getVKONT())) {
	// collectionType = bankStandingOrderCancelList.get(j).getCollectionType();
	// found = true;
	// corpStandingOrderCancelList.remove(i);
	// break;
	// } else {
	// found = false;
	// }
	// }
	// if (!found) {
	// // bulunamayan numara icin talimat iptal istegi gonder
	// String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
	// GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
	// String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
	// GMMap onlineCorporateServiceCallInputMap = new GMMap();
	// GMMap onlineCorporateServiceCallOutputMap = new GMMap();
	// onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderCancelList.get(j).getSubscriberNo1());
	// onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
	// onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
	// onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
	// onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
	// onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
	// onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
	// GMMap reconProcessDataLogInsertInputMap = new GMMap();
	// try {
	// onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
	// } catch (GMRuntimeException e) {
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
	// }
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);// Talimat Iptal Mesaji Gonderildi
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderCancelList.get(j).getSubscriberNo1());
	// CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
	// }
	// }
	// }
	//
	// insertOnlineServiceLog(iMap, outMap);
	//
	// } catch (Exception e2) {
	// outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
	// outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
	// outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
	// insertOnlineServiceLog(iMap, outMap);
	// e2.printStackTrace();
	// throw e2;
	// }
	//
	// return outMap;
	// }

	// @GraymoundService("STO_UEDAS_STANDING_ORDER_RECONCILIATION")
	// public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
	// iMap.put(MapKeys.WS_SERVICE_NAME,"STO_UEDAS_STANDING_ORDER_RECONCILIATION");
	// GMMap outMap = new GMMap();
	// try {
	// String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
	// String responseCode = "";
	// String reconDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
	// IntHolder talimatSayisi = new IntHolder();
	// IntHolder talimatIptalSayisi = new IntHolder();
	//
	// TABLE_OF_ZISU_WS_OOT_CHECK_SHolder t_OUT = new TABLE_OF_ZISU_WS_OOT_CHECK_SHolder();
	// TABLE_OF_ZISU_WS_OOT_CHECK_SHolder t_OUT2 = new TABLE_OF_ZISU_WS_OOT_CHECK_SHolder();
	//
	// responseCode = KayseriGazClient.talimatMutabakat(p_BUKRS, p_BNKKD, reconDate, talimatSayisi, talimatIptalSayisi, t_OUT, t_OUT2, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
	//
	// GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
	// String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
	//
	// outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
	// outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	// outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
	//
	// if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
	// outMap.put(MapKeys.RECON_CORPORATE_COUNT, talimatSayisi.value);
	// outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, talimatIptalSayisi.value);
	// GMMap rcInput = new GMMap();
	// rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
	// iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
	// rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));
	//
	// GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);
	//
	// int bankReconCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT) +
	// rcOutput.getInt("CANCEL_COUNT");
	//
	// outMap.put(MapKeys.RECON_BANK_COUNT, bankReconCount);
	// outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.CANCEL_COUNT));
	// } else {
	// outMap.put(MapKeys.RECON_CORPORATE_COUNT, -1);
	// outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
	// outMap.put(MapKeys.RECON_BANK_COUNT, 0);
	// outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
	// }
	//
	// insertOnlineServiceLog(iMap, outMap);
	//
	// } catch (Exception e2) {
	// outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
	// outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
	// outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
	// insertOnlineServiceLog(iMap, outMap);
	// e2.printStackTrace();
	// throw e2;
	// }
	//
	// return outMap;
	// }

	// @GraymoundService("ICS_UEDAS_GET_COLLECTION_RECONCILIATION_DETAIL")
	// public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
	// iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_UEDAS_GET_COLLECTION_RECONCILIATION_DETAIL");
	// GMMap outMap = new GMMap();
	// GMMap reconCorpAmountMap = new GMMap();
	// try {
	// String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
	// String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
	//
	// String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
	// String responseCode="";
	//
	// TABLE_OF_ZISU_WS_BA_CHECK2_SHolder tahsilatList = new TABLE_OF_ZISU_WS_BA_CHECK2_SHolder();
	// TABLE_OF_ZISU_WS_BA_CHECK2_SHolder tahsilatIptalList = new TABLE_OF_ZISU_WS_BA_CHECK2_SHolder();
	//
	// responseCode = KayseriGazClient.mutabakatSorgulamaToplu(p_BUKRS, p_BNKKD, tarih, tahsilatList, tahsilatIptalList, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
	//
	// GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
	// outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
	// outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	// outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
	//
	// int tahsilatListLength = 0;
	// if (tahsilatList.value != null) {
	// tahsilatListLength = tahsilatList.value.length;
	//
	//
	// for (int i = 0; i < tahsilatListLength; i++) {
	// ZISU_WS_BA_CHECK2_S tahsilat = tahsilatList.value[i];
	// reconCorpAmountMap.put("CORPORATE", i, MapKeys.SUBSCRIBER_NO1, tahsilat.getVKONT());
	// reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_AMOUNT, tahsilat.getTOTAL_AMNT());
	// reconCorpAmountMap.put("CORPORATE", i, MapKeys.INVOICE_NO, tahsilat.getMATBU());
	// reconCorpAmountMap.put("CORPORATE", i, MapKeys.TRX_NO, tahsilat.getTEXT1());
	// // hibenate ile kay�t etmece
	// }
	// }
	// GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
	// outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
	// outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
	// outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
	// outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
	// int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
	// int corporateCollectionCount = tahsilatListLength;
	// GMMap rcInput = new GMMap();
	// rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
	//
	// boolean found = false;
	// if (bankCollectionCount > corporateCollectionCount) {
	// short collectionType = 0;
	// for (int j = 0; j < bankCollectionCount; j++) {
	// for (int i = 0; i < corporateCollectionCount; i++) {
	// if (reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(
	// reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1))
	// && reconBankMap.getString("BANK", j, MapKeys.INVOICE_NO).equals(
	// reconCorpAmountMap.getString("CORPORATE", i, MapKeys.INVOICE_NO))
	// && reconBankMap.getString("BANK", j, MapKeys.TRX_NO).equals(
	// reconCorpAmountMap.getString("CORPORATE", i, MapKeys.TRX_NO))
	// && reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(
	// reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
	// found = true;
	// break;
	// } else {
	// found = false;
	// }
	// }
	// if (!found) {
	// // bulunamayan numara icin talimat istegi gonder
	// GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
	// String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
	// String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
	// GMMap onlineCorporateServiceCallInputMap = new GMMap();
	// GMMap request = new GMMap();
	// request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
	// request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
	// request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
	// request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
	// request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
	// request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
	// request.put(MapKeys.CORPORATE_CODE, corporateCode);
	// request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
	// GMMap onlineCorporateServiceCallOutputMap = new GMMap();
	// onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
	// onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
	// onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
	// onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
	// onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
	// onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
	// onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
	// onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
	//
	// onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
	// onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
	// onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
	// onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
	// onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
	// onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
	//
	// try {
	// onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
	// } catch (Exception e) {
	// // TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
	// e.printStackTrace();
	// onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
	// onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
	// }
	//
	// GMMap reconProcessDataLogInsertInputMap = new GMMap();
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
	// if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
	// }
	// if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
	// }
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat Mesaji Gonderildi
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
	//
	// CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
	// }
	// }
	// } else {
	// short collectionType = 0;
	// for (int j = 0; j < corporateCollectionCount; j++) {
	// for (int k = 0; k < bankCollectionCount; k++) {
	// if (reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(
	// reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1))
	// && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO).equals(
	// reconBankMap.getString("BANK", k, MapKeys.INVOICE_NO))
	// && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO).equals(
	// reconBankMap.getString("BANK", k, MapKeys.TRX_NO))
	// && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(
	// reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
	// found = true;
	// break;
	// } else {
	// found = false;
	// }
	// }
	// if (!found) {
	// // bulunamayan numara icin talimat iptal istegi gonder
	// String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
	// GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
	// String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
	// GMMap onlineCorporateServiceCallInputMap = new GMMap();
	// GMMap request = new GMMap();
	// request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
	// request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
	// request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
	// request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
	// request.put(MapKeys.INVOICE_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO));
	// request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
	// request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
	// GMMap onlineCorporateServiceCallOutputMap = new GMMap();
	// onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
	// onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
	// onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
	// onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
	// onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
	// onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("BANK", j, MapKeys.INSTALLMENT_NO));
	// onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
	// onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_DATE, request.getString(MapKeys.CANCEL_DATE));
	//
	// onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
	// onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
	// onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
	// onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
	// onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
	// onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
	// try {
	// onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
	// } catch (Exception e) {
	// // TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
	// e.printStackTrace();
	// onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
	// onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
	// }
	//
	// GMMap reconProcessDataLogInsertInputMap = new GMMap();
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
	// if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
	// onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
	// }
	// if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
	// onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
	// }
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
	//
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
	// reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
	// CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
	//
	// }
	// }
	// }
	//
	// insertOnlineServiceLog(iMap, outMap);
	//
	// } catch (Exception e2) {
	// outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
	// outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
	// outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
	// insertOnlineServiceLog(iMap, outMap);
	// e2.printStackTrace();
	// throw e2;
	// }
	//
	// return outMap;
	// }

	@GraymoundService("ICS_UEDAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UEDAS_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String errorMessage = "";

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Session session = CommonHelper.getHibernateSession();
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String bankUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String tedarikciID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			Date p_dtOdemeTarihi = CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd");

			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");

			Number reconCountPerakendeNumber = ((Number) session.createCriteria(invoicePayment.class).add(Restrictions.eq("status", true)).add(Restrictions.like("paymentDate", iMap.getString(MapKeys.RECON_DATE), MatchMode.START)).add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("parameter16", tedarikciID)).setProjection(Projections.rowCount()).uniqueResult());

			int reconCountPerakende = reconCountPerakendeNumber.intValue();

			Number reconTotalPerakende = (Number) session.createCriteria(invoicePayment.class).add(Restrictions.eq("status", true)).add(Restrictions.like("paymentDate", iMap.getString(MapKeys.RECON_DATE), MatchMode.START)).add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("parameter16", tedarikciID)).setProjection(Projections.sum("paymentAmount")).uniqueResult();

			BigDecimal reconTotalAmountPerakende = BigDecimal.ZERO;
			if (reconTotalPerakende != null) {
				reconTotalAmountPerakende = new BigDecimal(reconTotalPerakende.doubleValue()).setScale(2, RoundingMode.HALF_UP);
			}

			String header = "";
			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
			tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(url, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
			if (loginResponse.getSonucMesaj() == null) {
				header = loginResponse.getSonucIcerik().get(0).getToken();
			}
			else {
				responseCode = loginResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			MutabakatYapResponse mutabakatYapResponse = null;

			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageMutabakatYap = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();

			mutabakatYapResponse = UedasRestClient.mutabakatYap(url, header, serviceMessageMutabakatYap, Integer.parseInt(tedarikciID), p_dtOdemeTarihi, reconTotalAmountPerakende, reconCountPerakende);
			if (mutabakatYapResponse.getSonucMesaj() == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			else {
				responseCode = "660";
				errorMessage = mutabakatYapResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML", serviceMessageMutabakatYap.getRequest());
			outMap.put("RESPONSE_XML", serviceMessageMutabakatYap.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			// Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

				outMap.putAll(onlineCorporateServiceCallOutputMap);
			}

			insertOnlineServiceLog(iMap, outMap);

		}
		catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;

	}

	@GraymoundService("ICS_UEDAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UEDAS_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String errorMessage = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Date p_dtOdemeTarihi = CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal corpReconTotal = new BigDecimal(0);
			int corpReconCount = 0;
			BigDecimal corpReconCancelTotal = new BigDecimal(0);
			int corpReconCancelCount = 0;

			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String bankUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int tedarikciID = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			String header = "";
			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
			tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(url, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
			if (loginResponse.getSonucMesaj() == null) {
				header = loginResponse.getSonucIcerik().get(0).getToken();
			}
			else {
				responseCode = loginResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			MutabakatOzetiGetirResponse mutabakatOzetiGetirResponse = null;

			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageMutabakatOzeti = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();

			mutabakatOzetiGetirResponse = UedasRestClient.mutabakatOzetiGetir(url, header, serviceMessageMutabakatOzeti, tedarikciID, p_dtOdemeTarihi);
			if (mutabakatOzetiGetirResponse.getSonucMesaj() == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			else {
				responseCode = "660";
				errorMessage = mutabakatOzetiGetirResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML_PERAKENDE", serviceMessageMutabakatOzeti.getRequest());
			outMap.put("RESPONSE_XML_PERAKENDE", serviceMessageMutabakatOzeti.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				corpReconTotal = mutabakatOzetiGetirResponse.getSonucIcerik().get(0).getGecerliTutar();
				corpReconCount = mutabakatOzetiGetirResponse.getSonucIcerik().get(0).getGecerliSayi();
				corpReconCancelTotal = mutabakatOzetiGetirResponse.getSonucIcerik().get(0).getIptalTutar();
				corpReconCancelCount = mutabakatOzetiGetirResponse.getSonucIcerik().get(0).getIptalSayi();
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpReconTotal);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpReconCount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpReconCancelTotal);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corpReconCancelCount);
			}

			// /invoice payment dan corporate payment_amount count payment
			// status t I ayr�m� yap
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}
			else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			insertOnlineServiceLog(iMap, outMap);

		}
		catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_UEDAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_UEDAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String bankUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int tedarikciID = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			String header = "";
			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
			tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(url, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
			if (loginResponse.getSonucMesaj() == null) {
				header = loginResponse.getSonucIcerik().get(0).getToken();
			}
			else {
				responseCode = loginResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			TalimatliSahisBorclariniGetirResponse talimatliSahisBorclariniGetirResponse = null;

			tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessage = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();

			talimatliSahisBorclariniGetirResponse = UedasRestClient.talimatliSahisBorclariniGetir(url, header, serviceMessage, tedarikciID);
			String errorMessage = "";
			if (talimatliSahisBorclariniGetirResponse.getSonucMesaj() == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			else {
				responseCode = "660";
				errorMessage = talimatliSahisBorclariniGetirResponse.getSonucMesaj();
			}
			iMap.put("REQUEST_XML_PERAKENDE", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML_PERAKENDE", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			int i = 0;
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (BorcluSahisTahakkuklariniGetirBilgiler borc : talimatliSahisBorclariniGetirResponse.getSonucIcerik()) {
					String termYear = borc.getDonem().split("/")[0];
					String termMonth = borc.getDonem().split("/")[1];
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, borc.getTekilKod());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, borc.getSahisTekilKod());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, borc.getThkFisNo());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, borc.getBorcToplami());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, "0");// collection
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);

					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, borc.getMusteriAdi());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonOdemeTarihi().substring(0, 10), "yyyy-MM-dd"));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_YEAR, termYear);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_MONTH, termMonth);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE, 0);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_AMOUNT, borc.getBorcToplami());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, "0");
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER1, borc.getThkIsletmeKodu());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER11, borc.getAboneNo());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER16, borc.getThkTedarikciID());
					outMap.put(MapKeys.INVOICE_LIST, i, "DESCRIPTION", 0 + 1 + ". Abone Borcu");
					i++;
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, i);

			insertOnlineServiceLog(iMap, outMap);

		}
		catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	private static void insertWsCallLog(GMMap iMap, tr.com.aktifbank.integration.uedasV2.ServiceMessage serviceMessage) {
		try {
			iMap.put(MapKeys.DURATION, serviceMessage.getParameter1());
			iMap.put(MapKeys.START_TIME, serviceMessage.getParameter2());
			iMap.put(MapKeys.END_TIME, serviceMessage.getParameter3());
			GMServiceExecuter.executeAsync("ICS_INSERT_ONLINE_WS_CALL_LOG", iMap);
		}
		catch (Exception e) {
			logger.error("ICS_INSERT_ONLINE_WS_CALL_LOG hata ald�.".concat(iMap.toString()));
		}
	}
}
