package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.ErzurumWaterNewReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.erzurumWaterNew.ErzurumWaterNewClient;
import tr.com.aktifbank.integration.erzurumWaterNew.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.gov.eski.webservis.BankaTalimatlari;
import tr.gov.eski.webservis.BorcBilgileri;
import tr.gov.eski.webservis.BorcBilgisi;
import tr.gov.eski.webservis.POut;
import tr.gov.eski.webservis.TahsilatMutabakat;
import tr.gov.eski.webservis.TalimatMutabakat;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ErzurumWaterNewServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(ErzurumWaterNewServices.class);
	private static String SERVICE_SUCCESS_CODE = "100";
	private static String SERVICE_DATE_FORMAT = "dd/MM/yyyy";

	@GraymoundService("ICS_ERZURUM_WATER_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquiry(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
		String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

		try {
			int username = 0;
			if (CommonHelper.getChannelId().equals("32"))
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);   
			else
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			int installationNumber = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			int customerNumber = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
			int rowCount = 0;
		
			BorcBilgileri result = ErzurumWaterNewClient.borcSor(reqTimeout, connTimeout, serviceUrl, username, password, sm, installationNumber, customerNumber);

			if (result != null) {
				if (!result.getPOut().getKod().equals(SERVICE_SUCCESS_CODE)) {
					responseCode = result.getPOut().getKod();
				}
				else {
					for (BorcBilgisi invoice : result.getBorcBilgileri().getBorcBilgisi()) {
						String termYear = invoice.getDonem().substring(0, 4);
						String termMonth = invoice.getDonem().substring(4, 6);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.AMOUNT, new BigDecimal(invoice.getGecikmeliToplam().replace(",", ".")));
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.CORPORATE_CODE, corporateCode);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DATE, CommonHelper.getDateTime(invoice.getTahakkukTarihi(), "dd.MM.yyyy"));
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoice.getVade(), "dd.MM.yyyy"));
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_NO, invoice.getTahakkukNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_TERM_YEAR, termYear);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_TERM_MONTH, termMonth);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER1, invoice.getTesisatNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER2, invoice.getMusteriNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER3, invoice.getTahakkukNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER4, new BigDecimal(invoice.getGecikme().replace(",", ".")));
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER5, new BigDecimal(invoice.getTutar().replace(",", ".")));
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER6, invoice.getTaksitGrupId());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER7, invoice.getTaksitSiraNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER8, invoice.getYasalTakipGrupId());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE, collectionType);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NAME, invoice.getMusteriAdi());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO1, invoice.getTesisatNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO2, invoice.getMusteriNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SURNAME, invoice.getMusteriAdi());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.EXPLANATION, invoice.getTahakkukTuru());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.DESCRIPTION, invoice.getTahakkukTuru());
						rowCount++;
					}
				}
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_ERZURUM_WATER_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}

	@GraymoundService("ICS_ERZURUM_WATER_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			int username = 0;
			if (CommonHelper.getChannelId().equals("32"))
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			else
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			int installationNumber = iMap.getInt(MapKeys.PARAMETER1);
			int customerNumber = iMap.getInt(MapKeys.PARAMETER2);
			long accrueNumber = iMap.getLong(MapKeys.PARAMETER3);
			double lateFee = iMap.getBigDecimal(MapKeys.PARAMETER4).doubleValue();
			double lateFeeTotal = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT).doubleValue();
			int taksitGrupId = iMap.getInt(MapKeys.PARAMETER6);
			int taksitSiraNo = iMap.getInt(MapKeys.PARAMETER7);
			int yasalTakipGrupId = iMap.getInt(MapKeys.PARAMETER8);
			String receiptNumber = iMap.getString(MapKeys.TRX_NO);
			String explanation = iMap.getString(MapKeys.EXPLANATION);
			String processDate = CommonHelper.getDateString(new Date(), "dd/MM/yyyy HH:mm:ss");

			POut result = ErzurumWaterNewClient.bankaTahsilatYap(reqTimeout, connTimeout, serviceUrl, username, password, sm, installationNumber, customerNumber, accrueNumber, lateFee, lateFeeTotal, taksitGrupId, taksitSiraNo, yasalTakipGrupId, receiptNumber, explanation, processDate);

			if (result != null) {
				if (!result.getKod().equals(SERVICE_SUCCESS_CODE)) {
					responseCode = result.getKod();
				}
				else {
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
					invoicePayment.setParameter9(result.getMakbuzSeri());
					invoicePayment.setParameter10(result.getMakbuzNo());
					session.saveOrUpdate(invoicePayment);
				}
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_ERZURUM_WATER_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_ERZURUM_WATER_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			int username = 0;
			if (CommonHelper.getChannelId().equals("32"))
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			else
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String paymentDate = CommonHelper.formatDateString(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddHHmmss", SERVICE_DATE_FORMAT);
			String receiptSerial = iMap.getString(MapKeys.PARAMETER_9);
			int installationNumber = iMap.getInt(MapKeys.PARAMETER_1);
			int receiptNumber = iMap.getInt(MapKeys.PARAMETER_10);
			

			String dekontno = iMap.getString(MapKeys.TRX_NO);
			POut result = ErzurumWaterNewClient.bankaTahsilatIptalDekontNo(reqTimeout, connTimeout, serviceUrl, username, password, sm, installationNumber, dekontno, paymentDate);

			if (result != null && !result.getKod().equals(SERVICE_SUCCESS_CODE)) {
				responseCode = result.getKod();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_ERZURUM_WATER_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_ERZURUM_WATER_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		ServiceMessage smYIM = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			int username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			int usernameYIM = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String date = CommonHelper.formatDateString(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd", SERVICE_DATE_FORMAT);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL));
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT));
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			
			TahsilatMutabakat result = ErzurumWaterNewClient.bankaTahsilatMutabakat(reqTimeout, connTimeout, serviceUrl, username, password, sm, date);
			TahsilatMutabakat resultYIM = ErzurumWaterNewClient.bankaTahsilatMutabakat(reqTimeout, connTimeout, serviceUrl, usernameYIM, password, smYIM, date);

			if (result != null) {
				if (!result.getPOut().getKod().equals(SERVICE_SUCCESS_CODE)) {
					responseCode = result.getPOut().getKod();
				}
				else {
					logger.info("ICS_ERZURUM_WATER_COLLECTION_RECONCILIATION - result() null degil");
					oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(result.getYekunTahsilatTutar().replace(",", ".")).add(new BigDecimal(resultYIM.getYekunTahsilatTutar().replace(",", "."))));
					oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, new Integer(result.getYekunTahsilatAdet()).intValue() + new Integer(resultYIM.getYekunTahsilatAdet()).intValue());
					oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(result.getIptalTutar().replace(",", ".")).add(new BigDecimal(resultYIM.getIptalTutar().replace(",", "."))));
					oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, new Integer(result.getIptalAdet()).intValue() + new Integer(resultYIM.getIptalAdet()).intValue());
				}
			}

			if (oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0 && oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {
				oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}
			else {
				oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			iMap.put("REQUEST_XML_YIM", smYIM.getRequest());
			oMap.put("RESPONSE_XML_YIM", smYIM.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_ERZURUM_WATER_COLLECTION_RECONCILIATION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_ERZURUM_WATER_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();

		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			ErzurumWaterNewReconciliationDetailBatch batch = new ErzurumWaterNewReconciliationDetailBatch(iMap, sm);
			oMap = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_ERZURUM_WATER_GET_COLLECTION_RECONCILIATION_DETAIL for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_ERZURUM_WATER_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		ServiceMessage smYIM = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			int username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String date = CommonHelper.formatDateString(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd", SERVICE_DATE_FORMAT);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			double collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL).doubleValue();
			double cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL).doubleValue();
			double totalPaymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL).add(reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL)).doubleValue();
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			int totalPaymentCount = collectionCount + cancelCount;

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			POut result = ErzurumWaterNewClient.bankaMutabakatIstek(reqTimeout, connTimeout, serviceUrl, username, password, sm, date, collectionCount, collectionTotal, cancelCount, cancelTotal, totalPaymentAmount, totalPaymentCount);

			if (result != null && !result.getKod().equals(SERVICE_SUCCESS_CODE)) {
				responseCode = result.getKod();
			}

			iMap.put("REQUEST_XML_YIM", smYIM.getRequest());
			oMap.put("RESPONSE_XML_YIM", smYIM.getResponse());
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());
			CommonHelper.insertWsCallLog(iMap, smYIM.getDuration(), smYIM.getStartTime(), smYIM.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_ERZURUM_WATER_COLLECTION_RECONCILIATION_CLOSED for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_ERZURUM_WATER_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
		String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

		try {
			int username = 0;
			if (CommonHelper.getChannelId().equals("32"))
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			else
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String term = CommonHelper.getDateString(new Date(), SERVICE_DATE_FORMAT);
			int rowCount = 0;

			BorcBilgileri result = ErzurumWaterNewClient.borcSorgulaTalimat(reqTimeout, connTimeout, serviceUrl, username, password, sm, term);

			if (result != null) {
				if (!result.getPOut().getKod().equals(SERVICE_SUCCESS_CODE)) {
					responseCode = result.getPOut().getKod();
				}
				else {
					for (BorcBilgisi invoice : result.getBorcBilgileri().getBorcBilgisi()) {
						String termYear = invoice.getDonem().substring(0, 4);
						String termMonth = invoice.getDonem().substring(4, 6);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.AMOUNT, invoice.getGecikmeliToplam());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.CORPORATE_CODE, corporateCode);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DATE, invoice.getTahakkukTarihi());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DUE_DATE, invoice.getServisIslemTarihi());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_NO, invoice.getTahakkukNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_TERM_YEAR, termYear);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_TERM_MONTH, termMonth);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER1, invoice.getTesisatNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER2, invoice.getMusteriNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER3, invoice.getTahakkukNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER4, invoice.getGecikme());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER5, invoice.getTutar());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER6, invoice.getTaksitGrupId());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER7, invoice.getTaksitSiraNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER8, invoice.getYasalTakipGrupId());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE, collectionType);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NAME, invoice.getMusteriAdi());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO1, invoice.getTesisatNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO2, invoice.getMusteriNo());
						oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SURNAME, invoice.getMusteriAdi());
						rowCount++;
					}
					oMap.put(MapKeys.TABLE_SIZE, rowCount);
				}
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_ERZURUM_WATER_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("STO_ERZURUM_WATER_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			int username = 0;
			if (CommonHelper.getChannelId().equals("32"))
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			else
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			int installationNumber = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			int customerNumber = iMap.getInt(MapKeys.SUBSCRIBER_NO2);

			POut result = ErzurumWaterNewClient.bankaTalimatIstek(reqTimeout, connTimeout, serviceUrl, username, password, sm, installationNumber, customerNumber);

			if (result != null && !result.getKod().equals(SERVICE_SUCCESS_CODE)) {
				responseCode = result.getKod();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Exception e) {
			logger.error("STO_ERZURUM_WATER_SEND_STANDING_ORDER_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("STO_ERZURUM_WATER_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			int username = 0;
			if (CommonHelper.getChannelId().equals("32"))
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			else
				username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			int installationNumber = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			int customerNumber = iMap.getInt(MapKeys.SUBSCRIBER_NO2);

			POut result = ErzurumWaterNewClient.bankaTalimatIptal(reqTimeout, connTimeout, serviceUrl, username, password, sm, installationNumber, customerNumber);

			if (result != null && !result.getKod().equals(SERVICE_SUCCESS_CODE)) {
				responseCode = result.getKod();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("STO_ERZURUM_WATER_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("STO_ERZURUM_WATER_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ERZURUM_WATER_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage message = new ServiceMessage();
		GMMap oMap = new GMMap();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			int username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			int usernameYIM = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			BankaTalimatlari result = ErzurumWaterNewClient.bankaTalimatListesi(reqTimeout, connTimeout, serviceUrl, username, password, message);
			BankaTalimatlari resultYIM = ErzurumWaterNewClient.bankaTalimatListesi(reqTimeout, connTimeout, serviceUrl, usernameYIM, password, message);
			
			
			
		}
		catch (Exception e) {
			logger.error("STO_ERZURUM_WATER_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("STO_ERZURUM_WATER_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ERZURUM_WATER_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		ServiceMessage smYIM = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		try {
			int username = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			int usernameYIM = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			GMMap rciMap = new GMMap();
			rciMap.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rciMap.put("RECON_DATE", iMap.getString(MapKeys.RECON_DATE));

			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rciMap);
			outMap.put(MapKeys.RECON_BANK_COUNT, rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT));
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);

			TalimatMutabakat result = ErzurumWaterNewClient.bankaTalimatMutabakat(reqTimeout, connTimeout, serviceUrl, username, password, sm);
			TalimatMutabakat resultYIM = ErzurumWaterNewClient.bankaTalimatMutabakat(reqTimeout, connTimeout, serviceUrl, usernameYIM, password, sm);

			if (result != null) {
				if (!result.getPOut().getKod().equals(SERVICE_SUCCESS_CODE)) {
					responseCode = result.getPOut().getKod();
				}
				else {
					outMap.put(MapKeys.RECON_CORPORATE_COUNT, Integer.parseInt(result.getAdet()) + Integer.parseInt(resultYIM.getAdet()));
					outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				}
			}
			else {
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
			}

			iMap.put("REQUEST_XML_YIM", smYIM.getRequest());
			outMap.put("RESPONSE_XML_YIM", smYIM.getResponse());	
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());
			CommonHelper.insertWsCallLog(iMap, smYIM.getDuration(), smYIM.getStartTime(), smYIM.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("STO_ERZURUM_WATER_STANDING_ORDER_RECONCILIATION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e));
			insertOnlineServiceLog(iMap, outMap);
			e.printStackTrace();
			throw e;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_ERZURUM_WATER_STANDING_ORDER_RECONCILIATION_CLOSED")
	public static GMMap closeRecon(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ERZURUM_WATER_STANDING_ORDER_RECONCILIATION_CLOSED");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		try {
			output = CommonHelper.callGraymoundServiceInHibernateSession("STO_ERZURUM_WATER_STANDING_ORDER_RECONCILIATION", iMap);

			output.put("BANK", 0, MapKeys.RECON_CORPORATE_COUNT, output.getString(MapKeys.RECON_CORPORATE_COUNT));
			output.put("BANK", 0, MapKeys.RECON_CORPORATE_CANCEL_COUNT, output.getString(MapKeys.RECON_CORPORATE_CANCEL_COUNT));
			output.put("CORPORATE", 0, MapKeys.RECON_BANK_COUNT, output.getString(MapKeys.RECON_BANK_COUNT));
			output.put("CORPORATE", 0, MapKeys.RECON_BANK_CANCEL_COUNT, output.getString(MapKeys.RECON_BANK_CANCEL_COUNT));

			output.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("STO_ERZURUM_WATER_STANDING_ORDER_RECONCILIATION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			insertOnlineServiceLog(iMap, output);
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}
}