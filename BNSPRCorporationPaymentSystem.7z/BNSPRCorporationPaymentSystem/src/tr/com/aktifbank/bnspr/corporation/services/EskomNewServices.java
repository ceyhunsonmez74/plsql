package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.EskomNewReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.eskomNew.EskomNewClient;
import tr.com.aktifbank.integration.eskomNew.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.eskom.ws.tahsilatservice.AboneBilgiResponseType;
import tr.com.eskom.ws.tahsilatservice.AboneNoType;
import tr.com.eskom.ws.tahsilatservice.BeyanTurType;
import tr.com.eskom.ws.tahsilatservice.BorcDetayType;
import tr.com.eskom.ws.tahsilatservice.BorcResponseType;
import tr.com.eskom.ws.tahsilatservice.BorclarType;
import tr.com.eskom.ws.tahsilatservice.MutabakatResponseType;
import tr.com.eskom.ws.tahsilatservice.TahsilatIptalResponseType;
import tr.com.eskom.ws.tahsilatservice.TahsilatResponseType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EskomNewServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(EskomNewServices.class);
	public static final int CASH_PAYMENT_TYPE=4201;
	public static final String RESPONSE_CODE_APPROVE ="0000";

	@GraymoundService("ICS_ESKOM_INVOICE_DEBT_INQUIRY_NEW")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_INVOICE_DEBT_INQUIRY_NEW");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String errorCode = "";
			String errorDesc = "";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String glrmdIdList = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String kurumKod = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			
			ServiceMessage serviceMessage = new ServiceMessage();
			String sorgulamaTipi = "";
			AboneNoType aboneNoType = AboneNoType.SICILNO;
			BeyanTurType beyanTurType = BeyanTurType.HEPSI;
			
			String subscriberNumber = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String tcNumber = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String subscriberWaterNumber = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			String subscriberId = iMap.getString(MapKeys.SUBSCRIBER_NO4);
			String aboneNumarasi = "";
			String sicilNo = "";
			String suAboneNo= "";
			AboneBilgiResponseType aboneBilgiResponse = null;
			if (StringUtils.isNotBlank(subscriberNumber) && StringUtils.isNotBlank(CommonHelper.trimStart(subscriberNumber, '0'))) {
				aboneBilgiResponse = EskomNewClient.aboneBilgi(reqTimeout, connTimeout, url, username, password, serviceMessage, CommonHelper.trimStart(subscriberNumber, '0'), kurumKod, AboneNoType.SICILNO);
				sorgulamaTipi = AboneNoType.SICILNO.toString();
				aboneNoType = AboneNoType.SICILNO;
				sicilNo = aboneBilgiResponse.getSicilNo();
				beyanTurType = BeyanTurType.HEPSI;
				aboneNumarasi = subscriberNumber;
			}else if (StringUtils.isNotBlank(tcNumber) && StringUtils.isNotBlank(CommonHelper.trimStart(tcNumber, '0'))) {
				aboneBilgiResponse = EskomNewClient.aboneBilgi(reqTimeout, connTimeout, url, username, password, serviceMessage, CommonHelper.trimStart(tcNumber, '0'), kurumKod, AboneNoType.TCKIMLIKNO);
				sorgulamaTipi = AboneNoType.TCKIMLIKNO.toString();
				aboneNoType = AboneNoType.TCKIMLIKNO;
				beyanTurType = BeyanTurType.HEPSI;
				sicilNo = aboneBilgiResponse.getSicilNo();
				aboneNumarasi = tcNumber;
			} else if (StringUtils.isNotBlank(subscriberWaterNumber) && StringUtils.isNotBlank(CommonHelper.trimStart(subscriberWaterNumber, '0'))) {
				aboneBilgiResponse= EskomNewClient.aboneBilgi(reqTimeout, connTimeout, url, username, password, serviceMessage, CommonHelper.trimStart(subscriberWaterNumber, '0'), kurumKod, AboneNoType.SUABONENO);
				sorgulamaTipi = AboneNoType.SUABONENO.toString();
				aboneNoType = AboneNoType.SUABONENO;
				beyanTurType = BeyanTurType.SU;
				suAboneNo= aboneBilgiResponse.getSicilNo(); 
				aboneNumarasi = subscriberWaterNumber;
			}
			try {
				iMap.put("ABONE_BILGI_REQUEST_XML", serviceMessage.getRequest());
				outMap.put("ABONE_BILGI_RESPONSE_XML", serviceMessage.getResponse());
			} catch (Exception e) {
				logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> aboneSorgu service message xml al�rken hata meydana geldi.");
			}
			if (aboneBilgiResponse == null) {
				errorCode = "660";
				errorDesc = "Kurum web servis �a�r�s�nda hata meydana geldi.";
				logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> abone sorgu web servis cagrisi sonucu null dondu.");
			} else {
				errorCode = aboneBilgiResponse.getKod();
				if (RESPONSE_CODE_APPROVE.equals(aboneBilgiResponse.getKod())) {
					// sorgulama basarili oldu
//					int sicilId = aboneBilgiResponse.getSicilNo();
//					BeyanType beyanId = aboneBilgiResponse.getBeyanlar().getBeyan().get(0);
					
//					BorcResponse borcSorguResult = EskomJaxWSClient.borc(reqTimeout, connTimeout, url, username, password, beyanId, guser, sicilId, sicilNo,suAboneNo, serviceMessage);
					
					BorcResponseType borcSorguResult = EskomNewClient.borc(reqTimeout, connTimeout, url, username, password, serviceMessage, aboneNumarasi, kurumKod, aboneNoType, beyanTurType);

					try {
						iMap.put("BORC_SORGU_REQUEST_XML", serviceMessage.getRequest());
						outMap.put("BORC_SORGU_RESPONSE_XML", serviceMessage.getResponse());
					} catch (Exception e) {
						logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> borcSorgu service message xml al�rken hata meydana geldi.");
					}
					if (borcSorguResult == null) {
						errorCode = "660";
						errorDesc = "Kurum web servis �a�r�s�nda hata meydana geldi.";
						logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY -> borc sorgu web servis cagrisi sonucu null dondu.");
					} else {
						errorCode = borcSorguResult.getKod();
						if (RESPONSE_CODE_APPROVE.equals(borcSorguResult.getKod())) {
							
							HashMap<Long, String> borcTurleri = null;
							if(glrmdIdList != null){
								borcTurleri = new HashMap<Long, String>();
								for(String s : glrmdIdList.split(",")){
									borcTurleri.put(Long.valueOf(s), "1");
								}
							}
							
							int counter = 0;
							BorclarType borcArray = borcSorguResult.getBorc().getBorclar();
							for (BorcDetayType borc : borcArray.getBorcDetay()) {
								if(borcTurleri == null || borcTurleri.containsKey(borc.getGlrmdId())){
									if (!isCollectedInvoice(borc.getTahakkukNo(),subscriberNumber, tcNumber,subscriberWaterNumber , subscriberId, corporateCode)) {
										String termYear = borc.getYil();
										String termMonth = borc.getDonem();
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, aboneNumarasi);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getTahakkukNo());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplamTutar());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, aboneBilgiResponse.getAd().concat(" ").concat(aboneBilgiResponse.getSoyad()));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.convertGregorianCalendar2Date(borc.getSonOdemeTarihi()));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplamTutar());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
//										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borcSorguResult.getBorc().getSicilNo());
//										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borcSorguResult.getBorc().get);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, borcSorguResult.getBorc().getSicilNo());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, sorgulamaTipi);

										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, borc.getVergiAd());
										outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
										outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
										counter++;
									}
								}
							}
						}
					}
				} else {
					// sorgulama basarisiz oldu hata kodunu al ve dondur
					errorCode = "660";
					errorDesc = aboneBilgiResponse.getMesaj().concat("(Sorgu Tipi : ".concat(sorgulamaTipi).concat(" )"));
					logger.error("ICS_ESKOM_INVOICE_DEBT_INQUIRY_NEW -> hata meydana geldi, kurumdan donen cevap : ".concat(errorDesc).concat(" Sorgu Tipi : ").concat(sorgulamaTipi).concat(" Abone Numarasi : ").concat(aboneNumarasi));
				}
			}
			GMMap responceCodeMap = getResponseCodeMapping(errorCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ESKOM_INVOICE_DEBT_INQUIRY_NEW.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ESKOM_DO_INVOICE_COLLECTION_NEW")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_DO_INVOICE_COLLECTION_NEW");
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			String kurumKod = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String bankaReferansNo = iMap.getString(MapKeys.TRX_NO);
			BigDecimal tahsilatTutar = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			tahsilatTutar.setScale(2);
			tahsilatTutar = tahsilatTutar.add(new BigDecimal("0.00"));
			// tahsilatTutar=tahsilatTutar.subtract(new BigDecimal("0.01"));
			XMLGregorianCalendar tahsilatTarihi ;
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.convertDate2GregorianCalendar(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss");       
			} else {
				tahsilatTarihi = CommonHelper.convertDate2GregorianCalendar(new Date());
			}
				
			
//			TahsilatResponse eskomTahsilat = EskomJaxWSClient.tahsilat(reqTimeout, connTimeout, url, username, password, guser, sicilId, null, tahakkukNo, bankaReferansNo, netId, tahsilatTutar, tahsilatTarihi, serviceMessage);
			
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			
			AboneNoType aboneNoType;
			String aboneType = iMap.getString(MapKeys.PARAMETER10);
			if (aboneType.equals(AboneNoType.SICILNO.toString())) {
				aboneNoType = AboneNoType.SICILNO;
			} else if (aboneType.equals(AboneNoType.SUABONENO.toString())) {
				aboneNoType = AboneNoType.SUABONENO; 
			} else {
				aboneNoType = AboneNoType.TCKIMLIKNO;
			}
			
			TahsilatResponseType eskomTahsilat = EskomNewClient.tahsilat(reqTimeout, connTimeout, url, username, password, serviceMessage, kurumKod, bankaReferansNo, tahsilatTarihi, aboneNo, aboneNoType, CASH_PAYMENT_TYPE, tahsilatTutar, tahakkukNo);
			
			responseCode = eskomTahsilat.getKod();
			iMap.put("REQUEST_XML_TAHSILAT", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT", serviceMessage.getResponse());
			if (RESPONSE_CODE_APPROVE.equals(responseCode)) {
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
					invoicePayment.setParameter1(iMap.getString(MapKeys.PARAMETER1));
					invoicePayment.setParameter2(iMap.getString(MapKeys.PARAMETER2));
					invoicePayment.setParameter3(iMap.getString(MapKeys.PARAMETER3));
					invoicePayment.setParameter4(iMap.getString(MapKeys.PARAMETER4));
					invoicePayment.setParameter5(eskomTahsilat.getTahsilat().getReferansNo());
					invoicePayment.setParameter6(eskomTahsilat.getKod());
					invoicePayment.setParameter7(eskomTahsilat.getMesaj());
					invoicePayment.setParameter8(eskomTahsilat.getTahsilat().getSeriNo());
					invoicePayment.setParameter9(eskomTahsilat.getTahsilat().getSiraNo());
					// parameter11 iptalde kullanilacaktir
					invoicePayment.setParameter11(Long.toString(eskomTahsilat.getTahsilat().getTahsilatId()));
					session.saveOrUpdate(invoicePayment);
				}
			} else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, eskomTahsilat.getMesaj());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, eskomTahsilat.getMesaj());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ESKOM_DO_INVOICE_COLLECTION_NEW");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ESKOM_SEND_COLLECTION_CANCEL_MESSAGE_NEW")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_SEND_COLLECTION_CANCEL_MESSAGE_NEW");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String kurumKod = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);


			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			ServiceMessage serviceMessage = new ServiceMessage();
			long tahsilatId = 0;
			if (iMap.getLong(MapKeys.PARAMETER_11) > 0) {
				tahsilatId = iMap.getLong(MapKeys.PARAMETER_11);
			} else {
				tahsilatId = iMap.getLong(MapKeys.PARAMETER11);
			}
			String bankaReferansNo = "0";
			if (iMap.getString(MapKeys.PARAMETER5) == null) {
				bankaReferansNo = iMap.getString(MapKeys.PARAMETER_5);
			} else {
				bankaReferansNo = iMap.getString(MapKeys.PARAMETER5);
			}
			String iptalneden = "MUSTERI_ISTEGI";
//			IptalResponse tahsilatIptal = EskomJaxWSClient.iptal(reqTimeout, connTimeout, url, username, password, tahsilatId, bankaReferansNo, iptalneden, guser, serviceMessage);
			
			TahsilatIptalResponseType tahsilatIptal = EskomNewClient.tahsilatIptal(reqTimeout, connTimeout, url, username, password, serviceMessage, iptalneden, kurumKod, bankaReferansNo, tahsilatId);

			iMap.put("REQUEST_XML_IPTAL", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_IPTAL", serviceMessage.getResponse());
			String responseCode = tahsilatIptal.getKod();
			if (RESPONSE_CODE_APPROVE.equals(responseCode)) {
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, tahsilatIptal.getMesaj());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, tahsilatIptal.getMesaj());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ESKOM_SEND_COLLECTION_CANCEL_MESSAGE_NEW");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ESKOM_COLLECTION_RECONCILIATION_NEW")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_COLLECTION_RECONCILIATION_NEW");
		GMMap outMap = new GMMap();
		String responseCode = "";

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String kurumKod = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			ServiceMessage serviceMessage = new ServiceMessage();
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar tarih = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");
			
			String bankaReferansNo = iMap.getString(MapKeys.TRX_NO);
//			MutabakatResponse mutabakat = EskomJaxWSClient.mutabakat(reqTimeout, connTimeout, url, username, password, bankaReferansNo, tarih, guser, serviceMessage);
			
			MutabakatResponseType mutabakat = EskomNewClient.mutabakat(reqTimeout, connTimeout, url, username, password, serviceMessage, kurumKod, BeyanTurType.HEPSI, bankaReferansNo, tarih);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			
			responseCode = mutabakat.getKod();
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		

			if (GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {

				// banka kayitlarini hesapla
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
				BigDecimal reconCollectionTotalBank = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
				BigDecimal reconCancelTotalBank = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
				int reconCollectionCountBank = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
				int reconCancelCountBank = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
				reconCollectionCountBank = reconCancelCountBank + reconCollectionCountBank;
				reconCollectionTotalBank = reconCollectionTotalBank.add(reconCancelTotalBank);

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconCollectionTotalBank);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconCancelTotalBank);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconCollectionCountBank);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconCancelCountBank);
				BigDecimal corpTahsilatTutar = new BigDecimal("0");
				if (mutabakat.getTahsilatTutar() != null) {
					corpTahsilatTutar = mutabakat.getTahsilatTutar();
				}

				BigDecimal corpIptalTutar = new BigDecimal("0");
				if (mutabakat.getIptalTutar() != null) {
					corpIptalTutar = mutabakat.getIptalTutar();
				}

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpTahsilatTutar);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpIptalTutar);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, mutabakat.getTahsilatSayi());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, mutabakat.getIptalSayi());

				if (reconCollectionTotalBank.compareTo(corpTahsilatTutar) == 0 && reconCancelTotalBank.compareTo(corpIptalTutar) == 0 && reconCollectionCountBank == mutabakat.getTahsilatSayi() && reconCancelCountBank == mutabakat.getIptalSayi()) {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					responseCode = RESPONSE_CODE_APPROVE;
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				} else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "");
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "Say� ve tutarlar farkl� oldu�u i�in mutabakat ba�ar�s�z!");
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}
			} else {
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, mutabakat.getMesaj());
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, mutabakat.getMesaj());
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e) {
			outMap.put(MapKeys.ERROR_CODE, "660");
			outMap.put(MapKeys.ERROR_DESC, "Mutabakat yap�l�rken hata meydana geldi!");
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "Mutabakat yap�l�rken hata meydana geldi!".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ESKOM_GET_COLLECTION_RECONCILIATION_DETAIL_NEW")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_GET_COLLECTION_RECONCILIATION_DETAIL_NEW");
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal reconCollectionTotalBank = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int reconCollectionCountBank = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			iMap.put(MapKeys.RECON_BANK_COUNT, reconCollectionCountBank);
			iMap.put(MapKeys.RECON_COLLECTION_TOTAL, reconCollectionTotalBank);
			CollectionReconciliationDetailBatch batch = new EskomNewReconciliationDetailBatch(iMap, serviceMessage);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
		} catch (Throwable e) {
			logger.info("ICS_ESKOM_GET_COLLECTION_RECONCILIATION_DETAIL_NEW - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;

	}

	@GraymoundService("ICS_ESKOM_COLLECTION_RECONCILIATION_CLOSED_NEW")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ESKOM_COLLECTION_RECONCILIATION_CLOSED_NEW");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;

	}
	
	public static XMLGregorianCalendar stringToXMLGregorianCalendar(String datetime, String dateFormat) {

	    try {

	    	Date date = CommonHelper.getDateTime(datetime, dateFormat);	        
	        GregorianCalendar cal = (GregorianCalendar) GregorianCalendar
	                .getInstance();

	        cal.setTime(date);

	        return  DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);


	    } catch (Exception e) {

	        System.out.print(e.getMessage());

	        return null;

	    }
	}


}
