package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.LuleburgazReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.luleburgaz.LuleburgazClient;
import tr.com.aktifbank.integration.luleburgaz.ServiceMessage;
import tr.com.aktifbank.luleburgaz.ArrayOfSetBorcBakiyeTopluParametre;
import tr.com.aktifbank.luleburgaz.ArrayOfTahakkukBorclariToplu;
import tr.com.aktifbank.luleburgaz.ArrayOfint;
import tr.com.aktifbank.luleburgaz.MutabakatRapor;
import tr.com.aktifbank.luleburgaz.ObjectFactory;
import tr.com.aktifbank.luleburgaz.OdemeIptalSonucu;
import tr.com.aktifbank.luleburgaz.OdemeSonucu;
import tr.com.aktifbank.luleburgaz.SetBorcBakiyeTopluParametre;
import tr.com.aktifbank.luleburgaz.TahakkukBorclariToplu;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class LuleburgazServices extends OnlineCorporationInterface implements OnlineInstitutionConstants{
	
	private static final Log logger = LogFactory.getLog(LuleburgazServices.class);
	private static final String errorCode = "660";
	
	@GraymoundService("ICS_LULEBURGAZ_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquiry(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String errorDesc = "";
		ArrayOfTahakkukBorclariToplu response = new ArrayOfTahakkukBorclariToplu();
		int rowCount = 0;
		
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 				
			Integer subscriberNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			Integer subscriberNo2 = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
			
			if(StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				response = LuleburgazClient.getBorcBakiyeAboneNoToplu(reqTimeout, connTimeout, url, username, password, sm, subscriberNo);
			} else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				response = LuleburgazClient.getBorcBakiyeToplu(reqTimeout, connTimeout, url, username, password, sm, subscriberNo2);
			}
			
			logger.info("ICS_LULEBURGAZ_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - LuleburgazClient.getBorcBakiyeAboneNoToplu(...) will be called..."));
			
			List<TahakkukBorclariToplu> invoiceList = response.getTahakkukBorclariToplu();
			
			if(response.getTahakkukBorclariToplu().get(0).getSonucKodu().equals(response.getTahakkukBorclariToplu().get(0).getSonucKodu().SUCCESS)){
				for(TahakkukBorclariToplu invoice: invoiceList){
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO2, iMap.getString(MapKeys.SUBSCRIBER_NO2));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateString(invoice.getSonOdemeTarihi().getValue().toGregorianCalendar().getTime(), "yyyyMMdd"));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NAME, invoice.getAdSoyadUnvan().getValue());					
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.AMOUNT, invoice.getToplamBorc().getValue().setScale(2, RoundingMode.HALF_UP));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER1, invoice.getBakiye().getValue().setScale(2, RoundingMode.HALF_UP));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER2, invoice.getGecikmeTutar().setScale(2, RoundingMode.HALF_UP));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER3, invoice.getIslemKayitID().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER4, invoice.getModelAdi().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER5, invoice.getGenelProgramID());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER7, invoice.getBorcYili());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER8, invoice.getTaksitDonem().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.DESCRIPTION, invoice.getTurAdi().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.EXPLANATION, invoice.getTurAdi().getValue());	
					rowCount++;
				}
			} else{
				responseCode = errorCode;
				errorDesc = response.getTahakkukBorclariToplu().get(0).getSonucMesaji().getValue();
			}
			
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);			
		}
		catch (Exception e) {
			logger.error("ICS_LULEBURGAZ_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}

	@SuppressWarnings("static-access")
	@GraymoundService("ICS_LULEBURGAZ_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String errorDesc = "";
		OdemeSonucu response = new OdemeSonucu();
		ServiceMessage sm = new ServiceMessage();

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 	
			
			logger.info("ICS_LULEBURGAZ_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - LuleburgazClient.setBorcBakiyeToplu(...) will be called..."));			
			
			String referansKodu = iMap.getString(MapKeys.TRX_NO);
			BigDecimal anaPara = iMap.getBigDecimal(MapKeys.PARAMETER1);
			BigDecimal gecikme = iMap.getBigDecimal(MapKeys.PARAMETER2);
			Integer islemKayitID = iMap.getInt(MapKeys.PARAMETER3);
			String modelAdi = iMap.getString(MapKeys.PARAMETER4);
			Integer genelProgramID = iMap.getInt(MapKeys.PARAMETER5);		
			Integer borcYili = iMap.getInt(MapKeys.PARAMETER7);
			Integer taksitDonem = iMap.getInt(MapKeys.PARAMETER8);
			
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(new Date());
			XMLGregorianCalendar islemTarih = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
			
			if(StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				response = LuleburgazClient.setBorcBakiyeToplu(reqTimeout, connTimeout, url, username, password, sm, islemTarih, genelProgramID, modelAdi, islemKayitID, anaPara, gecikme, referansKodu);
			} else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				ObjectFactory objectFactory = new ObjectFactory();
				ArrayOfSetBorcBakiyeTopluParametre odenecekListe = new ArrayOfSetBorcBakiyeTopluParametre();
				SetBorcBakiyeTopluParametre paymentParameter = new SetBorcBakiyeTopluParametre();
				paymentParameter.setAnaPara(anaPara);
				paymentParameter.setBorcYili(objectFactory.createSetBorcBakiyeTopluParametreBorcYili(borcYili));
				paymentParameter.setEklenenGecikme(BigDecimal.ZERO);
				paymentParameter.setGecikme(gecikme);
				paymentParameter.setGenelProgramID(genelProgramID);
				paymentParameter.setIslemKayitID(islemKayitID);
				paymentParameter.setIslemTarihParam(islemTarih);
				paymentParameter.setModelAdi(objectFactory.createSetBorcBakiyeTopluParametreModelAdi(modelAdi));
				paymentParameter.setReferansKodu(objectFactory.createSetBorcBakiyeTopluParametreReferansKodu(referansKodu));
				paymentParameter.setTaksitDonem(objectFactory.createSetBorcBakiyeTopluParametreTaksitDonem(taksitDonem));
				odenecekListe.getSetBorcBakiyeTopluParametre().add(paymentParameter );
				response = LuleburgazClient.setBorcBakiyeTopluList(reqTimeout, connTimeout, url, username, password, sm, odenecekListe);
			} 
		
			if(response.getSonucKodu().equals(response.getSonucKodu().SUCCESS)){
				JAXBElement<ArrayOfint> tahakkukOdemeIdList = response.getTahakkukOdemeIDList();			
				Integer tahakkukOdemeId = tahakkukOdemeIdList.getValue().getInt().get(0);
				
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class)
																		.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter6(tahakkukOdemeId.toString());

				session.saveOrUpdate(invoicePayment);
			} else{
				responseCode = errorCode;
				errorDesc = response.getResultMessage().getValue();
			}
			
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);			
		}
		catch (Exception e) {
			logger.error("ICS_LULEBURGAZ_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@SuppressWarnings("static-access")
	@GraymoundService("ICS_LULEBURGAZ_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String errorDesc = "";
		ServiceMessage sm = new ServiceMessage();

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 	
			
			logger.info("ICS_LULEBURGAZ_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - LuleburgazClient.odemeIptal(...) will be called..."));
			
			Integer tahakkukOdemeId = iMap.getInt(MapKeys.PARAMETER_6);
			String tahsilatIptalAciklama = "-";
			
			OdemeIptalSonucu response = LuleburgazClient.odemeIptal(reqTimeout, connTimeout, url, username, password, sm, tahakkukOdemeId, tahsilatIptalAciklama);

			if(!response.getSonucKodu().equals(response.getSonucKodu().SUCCESS)){
				responseCode = errorCode;
				errorDesc = response.getResultMessage().getValue();
			}
			
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);			
		}
		catch (Exception e) {
			logger.error("ICS_LULEBURGAZ_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@SuppressWarnings("static-access")
	@GraymoundService("ICS_LULEBURGAZ_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String errorDesc = "";
		ServiceMessage sm = new ServiceMessage();

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			BigDecimal corpCollectionTotal= new BigDecimal(0);
			int corpCollectionCount = 0;
			
			Date reconDate = CommonHelper.getDateTime(CommonHelper.formatDateString(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd", "yyyy-MM-dd"), "yyyy-MM-dd");
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));			
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(reconDate);
			XMLGregorianCalendar islemTarih = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
			
			MutabakatRapor response = LuleburgazClient.getGunlukIslemRaporToplu(reqTimeout, connTimeout, url, username, password, sm, islemTarih);
			
			if(response.getResultCode().equals(response.getResultCode().SUCCESS)){
				corpCollectionCount = response.getTahsilatNumber();
				corpCollectionTotal = response.getTotalTahsilatPrice().setScale(2, RoundingMode.HALF_UP);
			} else{
				responseCode = errorCode;
				errorDesc = response.getMutabakatMessage().getValue();
			}
			
			oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpCollectionTotal);
			oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpCollectionCount);
			oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
			oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			
			 if (oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && 
					 oMap.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == oMap.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) {
				 logger.info("ICS_LULEBURGAZ_COLLECTION_RECONCILIATION - mutabakat basarili  ");
				 oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);	
			} else {
				 oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}			
			
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorDesc);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);			
		}
		catch (Exception e) {
			logger.error("ICS_LULEBURGAZ_COLLECTION_RECONCILIATION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_LULEBURGAZ_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();

		try {
			CollectionReconciliationDetailBatch batch = new LuleburgazReconciliationDetailBatch(iMap, sm);
			oMap = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			oMap.put(MapKeys.ERROR_DESC, "Onay");
		}
		catch (Exception e) {
			logger.error("ICS_LULEBURGAZ_GET_COLLECTION_RECONCILIATION_DETAIL for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

}
