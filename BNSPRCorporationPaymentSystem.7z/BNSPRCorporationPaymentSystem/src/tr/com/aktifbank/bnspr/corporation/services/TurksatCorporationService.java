package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.turksat.ServiceMessage;
import tr.com.aktifbank.integration.turksat.TurksatClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.turksat.ktv.Invoice;
import tr.com.turksat.ktv.Payment;
import tr.com.turksat.ktv.Verification;
import tr.com.turksat.ktv.VerificationDetail;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TurksatCorporationService extends OnlineCorporationInterface
		implements OnlineInstitutionConstants {
	
	public static final String ERROR_SUCCESS ="0";
	public static final String NOT_FOUND ="99";
	private static final Log logger = LogFactory.getLog(TurkcellServices.class);
	private static final int SUCCESS_OPID = 91;
	public static final String BRANCH_CODE ="555";
	public static final String TELLER ="TELLER";
	public static final String ACCOUNT_NO ="ACCOUNT_NO";
	public static final int PAYMENT_STATUS =1;
	public static final int PAYMENT_CANCEL_STATUS =2;

	
	@GraymoundService("ICS_TURKSAT_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKSAT_INVOICE_DEBT_INQUIRY");
		try {
//			TurksatClient debtInquiryClient = getSoapClient(iMap);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String responseCode ="";
			String errorCode="";
			String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			ServiceMessage serviceMessage= new ServiceMessage();
			Invoice[] invoiceList = TurksatClient.getInvoiceList(wsUrl, wsUserName, wsPassword, subscriberNo1, serviceMessage);
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getParameter1(), serviceMessage.getParameter2(), serviceMessage.getParameter3());
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			int counter = 0;
			if( null != invoiceList ){
				responseCode = ERROR_SUCCESS;
				for (int i = 0; i < invoiceList.length; i++) {
					Invoice invoice = invoiceList[i];
					String invoiceDueDate = getStringDate(invoice.getDueDate());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, iMap.getString(MapKeys.SUBSCRIBER_NO2));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, iMap.getString(MapKeys.SUBSCRIBER_NO3));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, "");
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, invoice.getTitle());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getInvoiceNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getTotalAmount());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, invoice.getQueryID());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, invoice.getReferenceNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, invoiceDueDate.substring(0, 4));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH,invoiceDueDate.substring(4, 6));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, invoice.getTotalAmount());
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
				
			}else{
				responseCode=NOT_FOUND;
			}
			
			
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_TURKSAT_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		String responseCode="";
		String errorCode="";
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKSAT_DO_INVOICE_COLLECTION");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int paymentChannel=0;
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			Invoice invoice = new Invoice();
			invoice.setDueDate(getCalendarDate(iMap.getString(MapKeys.INVOICE_DUE_DATE)));
			invoice.setInvoiceNo(iMap.getString(MapKeys.INVOICE_NO));
			invoice.setTitle(iMap.getString(MapKeys.SUBSCRIBER_NAME));
			invoice.setQueryID(iMap.getInt(MapKeys.PARAMETER1));
			invoice.setReferenceNo(iMap.getInt(MapKeys.PARAMETER2));
			invoice.setServiceNo(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			invoice.setAmount(new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
			invoice.setDelayFine(new BigDecimal(0));
			invoice.setTotalAmount(new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT)));
//			Calendar payDate = Calendar.getInstance();
//			payDate.setTime(new Date());
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.SOURCE))){
				String sourceCode = iMap.getString(MapKeys.SOURCE);
				String channelCode = CommonHelper.getChannelId();
				Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
				paymentChannel = Integer.parseInt(getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType));
			}else{
				paymentChannel = iMap.getInt(MapKeys.PARAMETER4);
			}
			
			String receiptNo = iMap.getString(MapKeys.TRX_NO);
			
			ServiceMessage serviceMessage = new ServiceMessage();
			
			Payment payment=TurksatClient.payInvoice(wsUrl, wsUserName, wsPassword, invoice, getPayDate(), paymentChannel, receiptNo, SUCCESS_OPID, BRANCH_CODE, TELLER, ACCOUNT_NO, serviceMessage);
			responseCode= payment.getStatus().toString();
			boolean isPaid=false;
			if(ERROR_SUCCESS.equals(responseCode)){
				isPaid=true;
			}else{
				//kurumdan donen deger 8 ise odeme basarili demektir.
				if("8".equals(responseCode)){
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("invoiceNo", iMap.getString(MapKeys.INVOICE_NO)))
							.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected)).uniqueResult();
					if (invoicePayment==null) {
						logger.info("ICS_TURKSAT_DO_INVOICE_COLLECTION -> kay�t veritbaninda yok, odeme basarili kabul edilecek");
						isPaid=true;
						responseCode=GeneralConstants.ERROR_CODE_APPROVE;
					}else{
						logger.info("ICS_TURKSAT_DO_INVOICE_COLLECTION -> kay�t veritbaninda yok, odeme basarisiz kabul edilecek");
					}
				}
			}
			if (isPaid) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("invoiceNo", iMap.getString(MapKeys.INVOICE_NO))).add(Restrictions.eq("status", true))
						.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("parameter1", iMap.getString(MapKeys.PARAMETER1))).add(Restrictions.eq("parameter2", iMap.getString(MapKeys.PARAMETER2))).uniqueResult();
				invoicePayment.setParameter3(String.valueOf(payment.getRefNo()));
				invoicePayment.setParameter4(String.valueOf(paymentChannel));
				session.saveOrUpdate(invoicePayment); 
			}
			System.out.println(payment);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_TURKSAT_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKCELL_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String subscriberNo1 = iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO1);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			BigDecimal amount = new BigDecimal(iMap.getString(MapKeys.PAYMENT_AMOUNT));
			int refNo = iMap.getInt(MapKeys.CANCEL_PARAMETER3);
			Calendar cancelDate = getPayDate();
			ServiceMessage serviceMessage = new ServiceMessage();
			int result = TurksatClient.cancelPayment(wsUrl, wsUserName, wsPassword, subscriberNo1, invoiceNo, amount, refNo, cancelDate, serviceMessage);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String responseCode = String.valueOf(result);
			
			logger.error(responseCode + " returned by Corporate for ICS_TURKSAT_SEND_COLLECTION_CANCEL_MESSAGE.");	
	
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_TURKSAT_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKSAT_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Calendar startDateTime = new GregorianCalendar();
			Calendar endDateTime = new GregorianCalendar();
			if(!"".equals(iMap.getString(MapKeys.RECON_DATE))){
				String reconDate = iMap.getString(MapKeys.RECON_DATE);
				startDateTime = getReconStartDateTime(reconDate);
				endDateTime = getReconEndDateTime(reconDate);
			}else{
				startDateTime = getReconStartDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
				endDateTime = getReconEndDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
			}
			ServiceMessage serviceMessage = new ServiceMessage();
			Verification verification = TurksatClient.verify(wsUrl, wsUserName, wsPassword, startDateTime, endDateTime, serviceMessage);
			
			String responseCode = ERROR_SUCCESS;
			logger.error(responseCode + " returned by Corporate for ICS_TURKSAT_COLLECTION_RECONCILIATION.");	
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			
			if(responseCode.equals(ERROR_SUCCESS) ){
				
				outMap.put(MapKeys.RECON_BANK_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT,reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_CORPORATE_COUNT,verification.getSuccessfulPaymentCount());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, verification.getCanceledPaymentCount());
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, verification.getSuccessfulPaymentAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, verification.getSuccessfulPaymentCount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, verification.getCanceledPaymentAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT,verification.getCanceledPaymentCount());

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL,  reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				
				if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(
						outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(
								outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(
								outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
						&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(
								outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}
			
			
			responseCode = ERROR_SUCCESS;
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Throwable e) {
			logger.info("ICS_TURKCELL_COLLECTION_RECONCILIATION - mutabakat hatali ");
			outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_TURKSAT_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKSAT_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			String responseCode="";
			Calendar startDateTime = new GregorianCalendar();
			Calendar endDateTime = new GregorianCalendar();
			if(!"".equals(iMap.getString(MapKeys.RECON_DATE))){
				String reconDate = iMap.getString(MapKeys.RECON_DATE);
				startDateTime = getReconStartDateTime(reconDate);
				endDateTime = getReconEndDateTime(reconDate);
			}else{
				startDateTime = getReconStartDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
				endDateTime = getReconEndDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
			}
			ServiceMessage serviceMessage=new ServiceMessage();
			VerificationDetail[] paymentDetail = TurksatClient.getDetailedTransactions(wsUrl, wsUserName, wsPassword, startDateTime, endDateTime, BRANCH_CODE, PAYMENT_STATUS, serviceMessage);
			VerificationDetail[] paymentCancelDetail = TurksatClient.getDetailedTransactions(wsUrl, wsUserName, wsPassword, startDateTime, endDateTime, BRANCH_CODE, PAYMENT_CANCEL_STATUS, serviceMessage);

			
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
	
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int corporateCollectionCount = paymentDetail.length;
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			boolean found = false;
			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < bankCollectionCount; j++) {
					for (int i = 0; i < corporateCollectionCount; i++) {
						if (reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(paymentDetail[i].getServiceNo())
								&& reconBankMap.getString("BANK", j, MapKeys.INVOICE_NO).equals(paymentDetail[i].getInvoiceNo())) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
						request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, request.getString(MapKeys.PAYMENT_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat Mesaji Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
					
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						if (paymentDetail[j].getServiceNo().equals(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1))
								&& paymentDetail[j].getInvoiceNo().equals(reconBankMap.getString("BANK", k, MapKeys.INVOICE_NO))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, paymentDetail[j].getServiceNo());
						request.put(MapKeys.PARAMETER2, paymentDetail[j].getRefNo() );
						request.put(MapKeys.PAYMENT_AMOUNT, paymentDetail[j].getAmount());
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString("BANK", j, MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, request.getString(MapKeys.PAYMENT_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("BANK", j, MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);																										
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);

					}
				}
			}
		
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_GET_COLLECTION_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}
	
	@GraymoundService("ICS_TURKSAT_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKSAT_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		try {
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		
			Calendar startDateTime = new GregorianCalendar();
			Calendar endDateTime = new GregorianCalendar();
			if(!"".equals(iMap.getString(MapKeys.RECON_DATE))){
				String reconDate = iMap.getString(MapKeys.RECON_DATE);
				startDateTime = getReconStartDateTime(reconDate);
				endDateTime = getReconEndDateTime(reconDate);
			}else{
				startDateTime = getReconStartDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
				endDateTime = getReconEndDateTime(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
			}
			ServiceMessage serviceMessage = new ServiceMessage();
			Verification verification = TurksatClient.verify(wsUrl, wsUserName, wsPassword, startDateTime, endDateTime, serviceMessage);
			
			String responseCode = ERROR_SUCCESS;
			logger.error(responseCode + " returned by Corporate for ICS_TURKSAT_COLLECTION_RECONCILIATION.");	
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			
			if(responseCode.equals(ERROR_SUCCESS) ){
				
				outMap.put(MapKeys.RECON_BANK_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT,reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_CORPORATE_COUNT,verification.getSuccessfulPaymentCount());
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, verification.getCanceledPaymentCount());
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, verification.getSuccessfulPaymentAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, verification.getSuccessfulPaymentCount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, verification.getCanceledPaymentAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT,verification.getCanceledPaymentCount());

				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL,  reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TURKSAT_COLLECTION_RECONCILIATION_CLOSED");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}
	
	public static String getStringDate(Calendar date){
		SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
		String formatted = format1.format(date.getTime());
		return formatted;
	}
	
	public static Calendar getCalendarDate(String dateString ) throws Exception{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date date = sdf.parse(dateString);
		SimpleDateFormat gregorianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
		String gregorianDateString = gregorianFormat.format(date);
		Date gregorianDate = gregorianFormat.parse(gregorianDateString);
		Calendar calendarDate  = new GregorianCalendar();
		calendarDate.setTime(gregorianDate);
		return calendarDate;
	}
	

	
	public static Calendar getPayDate() throws Exception{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
		String dateString = sdf.format(new Date());
		Date date = sdf.parse(dateString);
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		System.out.println(calendar);
//		 Calendar payDate = Calendar.getInstance();
//	     payDate.setTime(new SimpleDateFormat("YYYY-MM-DDThh:mm:SS.mss+hh:mm").parse(new Date().toString()));
	     return calendar;
		
	}
	 

		public static Calendar getReconStartDateTime(String dateString) throws ParseException{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			dateString = dateString + "000000";
			Date date = sdf.parse(dateString);
			SimpleDateFormat gregorianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
			String gregorianDateString = gregorianFormat.format(date);
			Date gregorianDate = gregorianFormat.parse(gregorianDateString);
			Calendar calendarDate  = new GregorianCalendar();
			calendarDate.setTime(gregorianDate);
			return calendarDate;
			
		}
		
		public static Calendar getReconEndDateTime(String dateString) throws ParseException{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			dateString = dateString + "235959";
			Date date = sdf.parse(dateString);
			SimpleDateFormat gregorianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
			String gregorianDateString = gregorianFormat.format(date);
			Date gregorianDate = gregorianFormat.parse(gregorianDateString);
			Calendar calendarDate  = new GregorianCalendar();
			calendarDate.setTime(gregorianDate);
			return calendarDate;
			
		}
		
		
		@GraymoundService("ICS_TURKSAT_DEBT_INQUERY_FOR_STANDING_ORDER")
		public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
			iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_TURKSAT_DEBT_INQUERY_FOR_STANDING_ORDER");
			GMMap outMap = new GMMap();
			String responseCode=ERROR_SUCCESS;;
			try {
				String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
						iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

				GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
				int counter=0;
				@SuppressWarnings("unchecked")
				List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

				GMMap debtLoadingMap = new GMMap();
					int bankStandingOrderListLenght = bankStandingOrderList.size();
					
					for (int i = 0; i < bankStandingOrderListLenght; i++) {
						icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
						
						iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
						debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_TURKSAT_INVOICE_DEBT_INQUIRY", iMap);
						String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);
						
						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							int invoiceListeLenght =  debtLoadingMap.getSize("INVOICES");
							for (int j = 0; j < invoiceListeLenght; j++) {
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO1));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2,debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER2));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_NO));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER1));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INSTALLMENT_NO));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DUE_DATE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DATE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER3));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER4));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER5));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER6));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER7));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER8));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER9));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER10));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO2));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO3));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO4));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, debtLoadingMap.getString("INVOICES",j,MapKeys.TERM_MONTH));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, debtLoadingMap.getString("INVOICES",j,MapKeys.TERM_YEAR));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, debtLoadingMap.getString("INVOICES",j,MapKeys.ZONE_CODE));
								counter++;
							}
							
						}
					}
					outMap.put(MapKeys.TABLE_SIZE, bankStandingOrderListLenght);
					outMap.put(MapKeys.RESPONSE_CODE, responseCode);
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "Onay");
					
				insertOnlineServiceLog(iMap, outMap);

			} catch (Exception e2) {
				logger.error("An exception occured while executing ICS_TURKSAT_DEBT_INQUERY_FOR_STANDING_ORDER.");
				logger.error(System.currentTimeMillis(), e2);
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				insertOnlineServiceLog(iMap, outMap);
				e2.printStackTrace();
				throw e2;
			}

			return outMap;
		}
		
		
		
		@GraymoundService("STO_TURKSAT_SEND_STANDING_ORDER_MESSAGE")
		public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
			iMap.put(MapKeys.WS_SERVICE_NAME, "STO_AVEA_SEND_STANDING_ORDER_MESSAGE");
			GMMap outMap = new GMMap();
			try {
				String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
				String gsmNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
				logger.info("STO_AVEA_SEND_STANDING_ORDER_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" abone no -> ").concat(gsmNo));
				// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
				// yapmadan basarili olarak geri don
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} catch (Throwable e2) {
				logger.info("STO_AVEA_SEND_STANDING_ORDER_MESSAGE -> error occured...");
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
				insertOnlineServiceLog(iMap, outMap);
				throw ExceptionHandler.convertException(e2);
			} finally {
				insertOnlineServiceLog(iMap, outMap);
			}
			return outMap;
		}
		
		@GraymoundService("STO_TURKSAT_SEND_STANDING_ORDER_CANCEL_MESSAGE")
		public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
			iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TURKSAT_SEND_STANDING_ORDER_CANCEL_MESSAGE");
			GMMap outMap = new GMMap();
			try {
				String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
				String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
				logger.info("STO_TURKSAT_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" abone no -> ").concat(aboneNo));
				// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
				// yapmadan basarili olarak geri don
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
				
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} catch (Throwable e2) {
				logger.info("STO_TURKSAT_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
				insertOnlineServiceLog(iMap, outMap);
				throw ExceptionHandler.convertException(e2);
			} finally {
				insertOnlineServiceLog(iMap, outMap);
			}
			return outMap;
		}
		
	}
