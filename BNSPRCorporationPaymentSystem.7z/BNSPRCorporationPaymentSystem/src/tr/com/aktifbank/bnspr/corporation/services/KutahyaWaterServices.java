package tr.com.aktifbank.bnspr.corporation.services;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.kutahyaSu.KutahyaSuClient;
import tr.com.calikbank.bnspr.util.StringUtil;
import webservis.ITahsilatWS_xsd.Webservis_MutabakatBean;
import webservis.ITahsilatWS_xsd.Webservis_MutabakatBeanA;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class KutahyaWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants { 
	private static final Log logger = LogFactory.getLog(KutahyaWaterServices.class);
	public static String DELIMITER = "-";
	public static String COLLECTION_INFO_DELIMITER = ",";
	public static String RECON_DELIMITER = " ";
	public static String RECEIPT_DELIMITER1 = "-";
	public static String RECEIPT_DELIMITER2 = "/";
	public static String RECEIPT_DELIMITER3 = " ";
	public static String BRANCH_CODE = "555";
	public static String PAY_DESK = "1";
	public static String ERROR_PREFIX = "Kod:";
	public static String RECONCILIATION_DETAY = "D";
	public static String RECONCILIATION = "I";
	public static int DAY_IN_MILLIS = 1000 * 60 * 60 * 24;
	
	@GraymoundService("ICS_KUTAHYA_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KUTAHYA_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();		
		String responseCode = "";
		String description ="";
		int counter = 0;
		int aboneNo = 0;	
		int sicilNo = 0;
		String mernisNo ="0";
		webservis.ITahsilatWS_xsd.Webservis_BorcBean[] aboneBorcList = null;
		webservis.ITahsilatWS_xsd.Webservis_BorcBean[] mernisBorcList = null;
		try {

			short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
//			String corporateCollectionType =getCorporateCollectionType(corporateCode, collectionType);
//			int modulNo = Integer.parseInt(corporateCollectionType);
			
		
			if(iMap.containsKey(MapKeys.COLLECTION_TYPE) &&  "0".equals(iMap.getString(MapKeys.COLLECTION_TYPE))){
				aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
				aboneBorcList = KutahyaSuClient.aboneBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), aboneNo);
			}else{
				mernisNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
				mernisBorcList = KutahyaSuClient.mernisBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo);
			}
		
			
			if(aboneBorcList!=null){
				int aboneLength = aboneBorcList.length;
				for (int i = 0; i < aboneLength; i++) {
					webservis.ITahsilatWS_xsd.Webservis_BorcBean borc = aboneBorcList[i];
					description = borc.getAciklama();
					if(!description.contains(ERROR_PREFIX)){
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					}else{
						responseCode = description.substring(0,7);
					}
					logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_INVOICE_DEBT_INQUIRY.");	
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						if(!isCollectedInvoice( Double.toString(borc.getToplam()), Integer.toString(aboneNo), Integer.toString(sicilNo), mernisNo, "", corporateCode)){
							String invoiceNo = borc.getBorcId();
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, "");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, "");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, "");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoiceNo);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getGenelToplam());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getTurKod());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, borc.getTakNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdi());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getVade(), "dd/MM/yyyy"));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borc.getThkYil());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, borc.getTakNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getGenelToplam());
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
						}	
					}
				}
			}
			
			if(mernisBorcList!=null){
				int mernisLength = mernisBorcList.length;
				for (int i = 0; i < mernisLength; i++) {
					webservis.ITahsilatWS_xsd.Webservis_BorcBean borc = mernisBorcList[i];
					description = borc.getAciklama();
					if(!description.contains(ERROR_PREFIX)){
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					}else{
						responseCode = description.substring(0,7);
					}
					logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_INVOICE_DEBT_INQUIRY.");	
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						if(!isCollectedInvoice( Double.toString(borc.getToplam()), "", mernisNo, "", "", corporateCode)){
							String invoiceNo = borc.getBorcId();
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, iMap.getString(MapKeys.SUBSCRIBER_NO2));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, "");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, "");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoiceNo);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getGenelToplam());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getTurKod());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, borc.getTakNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdi()+" "+borc.getSoyadi());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getVade(), "dd/MM/yyyy"));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, borc.getThkYil());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, borc.getTakNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getGenelToplam());
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
						}	
					}
				}
			}
			
			insertOnlineServiceLog(iMap, outMap);
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KUTAHYA_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}
	
	@GraymoundService("ICS_KUTAHYA_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KUTAHYA_DO_INVOICE_COLLECTION");
		String responseCode = "";
		String thsTarih = "";
		if(iMap.containsKey(MapKeys.PAYMENT_DATE) &&  !StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))){
			thsTarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddHHmmss"),"dd/MM/yyyy");
		}else{
			thsTarih = CommonHelper.getDateString(new Date(),"dd/MM/yyyy");	
		}
		
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int aboneNo = 0;	
			int sicilNo = 0;
			String mernisNo ="0";
//			short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
//			String corporateCollectionType =getCorporateCollectionType(corporateCode, collectionType);
//			int modulNo = Integer.parseInt(corporateCollectionType);
			
			
			if(iMap.containsKey(MapKeys.COLLECTION_TYPE) &&  "0".equals(iMap.getString(MapKeys.COLLECTION_TYPE))){
				aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			}else{
				if(iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !"00000000000".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1))){
					mernisNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
				}
			}
			
			String tahsilBilgi = iMap.getString(MapKeys.INVOICE_NO);
			String dekontNo = iMap.getString(MapKeys.TRX_NO);
//			String dekontNo = getKutahyaSuDekont(iMap.getString(MapKeys.TRX_NO));
			if(!iMap.containsKey("cf615b28a8044f06928ca81f3bab8eb9")){
				String[] tahsilatList = KutahyaSuClient.tahsilatYap(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), sicilNo, aboneNo , mernisNo, tahsilBilgi, dekontNo, thsTarih);

				int tahsilatListLength = tahsilatList.length;
					String response = tahsilatList[0] ;
					responseCode = response.substring(0, 7);
					logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_DO_INVOICE_COLLECTION.");
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
//						String makbuzNo = getMakbuzNo(tahsilatList[1]);
						String makbuzNo = tahsilatList[1].substring(14);
				        String iptalRefId = tahsilatList[2];
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						outMap.put(MapKeys.CORPORATE_PAYMENT_ID, makbuzNo);
						Session session = DAOSession.getSession("BNSPRDal");
						invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
						invoicePayment.setCorporatePaymentId(makbuzNo);		
						session.saveOrUpdate(invoicePayment); 
					}
				
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			insertOnlineServiceLog(iMap, outMap);
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KUTAHYA_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_KUTAHYA_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KUTAHYA_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
//			short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
//			String corporateCollectionType =getCorporateCollectionType(corporateCode, collectionType);
//			int modulNo = Integer.parseInt(corporateCollectionType);
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddHHmmss"),"dd/MM/yyyy");
			String makbuzNo = iMap.getString(MapKeys.CORPORATE_PAYMENT_ID);
			String[] cancelResults = KutahyaSuClient.tahsilatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, makbuzNo);
			String responseCode =cancelResults[0].substring(0,7);
			logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_SEND_COLLECTION_CANCEL_MESSAGE.");
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KUTAHYA_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}
	
	@GraymoundService("STO_KUTAHYA_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_KUTAHYA_SEND_STANDING_ORDER_MESSAGE");		
		GMMap outMap = new GMMap();
		String result="";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
//			String corporateCollectionType =getCorporateCollectionType(corporateCode, collectionType);
//			int modulNo = Integer.parseInt(corporateCollectionType);
			String responseCode = "";
			int aboneNo = 0;	
			int sicilNo = 0;
			String mernisNo ="0";
			if (collectionType==0) {
				if(iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1))){
					aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
					result = KutahyaSuClient.suTalimatVer(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), aboneNo);
					responseCode = result.substring(0, 7);
				}	
				
				if(iMap.containsKey(MapKeys.SUBSCRIBER_NO2) && !StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2)) && !"00000000000".equals(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
					mernisNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 2);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 3);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 4);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 5);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 6);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 12);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 13);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 14);
					result = KutahyaSuClient.modulTalimatEkle(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 15);

					if(result.equals("Bu mod�l i�in daha �nce talimat kayd� verilmi�")){
						responseCode = "Kod:940";
					}else{
						responseCode = result.substring(0, 7);	
					}
				}
			}else{
				responseCode = GeneralConstants.NOT_SUPPORTED_COLLECTION_TYPE_ERROR;
			}
			
			
//			if(iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1))){
//				aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
//			}
//			
//			if(iMap.containsKey(MapKeys.SUBSCRIBER_NO2) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
//				sicilNo = iMap.getInt(MapKeys.SUBSCRIBER_NO2);
//				
//			}
//			
//			if(iMap.containsKey(MapKeys.SUBSCRIBER_NO3) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO3))){
//				mernisNo = iMap.getString(MapKeys.SUBSCRIBER_NO3);
//			}
			
//			if(corporateCollectionType.equals("1")){
//				
//			}else{
//				
//			}
			
			logger.error(responseCode + " returned by Corporate for STO_KUTAHYA_SEND_STANDING_ORDER_MESSAGE.");
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_KUTAHYA_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}
	
	@GraymoundService("STO_KUTAHYA_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
 		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_KUTAHYA_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String responseCode = "";
			String result = "";
			short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
//			String corporateCollectionType =getCorporateCollectionType(corporateCode, collectionType);
			int aboneNo = 0;	
			int sicilNo = 0;
			String mernisNo ="0";
//			int modulNo = Integer.parseInt(corporateCollectionType);
			
			if (collectionType==0) {
				if(iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1))){
					aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
					result = KutahyaSuClient.suTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), aboneNo);
					responseCode = result.substring(0, 7);
				}
			
			
//				if(iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1))){
//					mernisNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 2);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 3);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 4);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 5);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 6);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 12);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 13);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 14);
//					result = KutahyaSuClient.modulTalimatIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), mernisNo, 15);
//					
//
//					responseCode = result.substring(0, 7);
//				}
			}else{
				responseCode = GeneralConstants.NOT_SUPPORTED_COLLECTION_TYPE_ERROR;	
			}
			logger.error(responseCode + " returned by Corporate for STO_KUTAHYA_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_KUTAHYA_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}
	
	@GraymoundService("ICS_KUTAHYA_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KUTAHYA_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int tableSize = 0;
		String tarih = CommonHelper.shortTimeStringToViewDateString(CommonHelper.getShortDateTimeString(new Date()));
	
		try {
			String[] talimatliBorclist = KutahyaSuClient.suTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih);
//			String[] talimatl�BorclistModul2 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 2);//2-	Emlak Vergisi
//			String[] talimatl�BorclistModul3 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 3);//3-	�evre Temizlik Vergisi
//			String[] talimatl�BorclistModul4 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 4);//4-	�lan Reklam, Tabela Vergisi
//			String[] talimatl�BorclistModul5 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 5);//5-	Gayrimenkul Kira
//			String[] talimatl�BorclistModul6 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 6);//6-	E�lence Vergisi
//			String[] talimatl�BorclistModul12 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 12);//12- Genel Tahakkuk
//			String[] talimatl�BorclistModul13 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 13);//13- Yat�r�m ��tirak
//			String[] talimatl�BorclistModul14 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 14);//14- Taksitli Sat��lar
//			String[] talimatl�BorclistModul15 = KutahyaSuClient.modulTalimatliBorc(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, 15);//15- ��galiye (Zab�ta)
//		
			
			
			if (talimatliBorclist != null) {
				int talimatliBorclistLenght = talimatliBorclist.length;
				if(talimatliBorclistLenght>0){
					for (int i = tableSize; i < tableSize + talimatliBorclistLenght; i++) {
						String  talimatliBorc = talimatliBorclist[i];
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
						logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_DEBT_INQUERY_FOR_STANDING_ORDER.");
						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
							
						String[] splitedTalimatliBorc= talimatliBorc.split(COLLECTION_INFO_DELIMITER);
						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatliBorc[0]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatliBorc[1]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatliBorc[2]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatliBorc[3]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatliBorc[4]);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
						}
					}
				 tableSize = tableSize + talimatliBorclistLenght;
				}
			
//			if (talimatl�BorclistModul2!= null) {
//				int talimatl�BorclistModul2lenght = talimatl�BorclistModul2.length;
//				if(talimatl�BorclistModul2lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize + talimatl�BorclistModul2lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul2[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize = tableSize + talimatl�BorclistModul2lenght;
//				}
//			
//			if (talimatl�BorclistModul3!= null) {
//				int talimatl�BorclistModul3Lenght = talimatl�BorclistModul3.length;
//				if(talimatl�BorclistModul3Lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize + talimatl�BorclistModul3Lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul3[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize = tableSize + talimatl�BorclistModul3Lenght;
//				}
//
//			if (talimatl�BorclistModul4!= null) {
//				int talimatl�BorclistModul4Lenght = talimatl�BorclistModul4.length;
//				if(talimatl�BorclistModul4Lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize + talimatl�BorclistModul4Lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul4[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize = tableSize + talimatl�BorclistModul4Lenght;
//				}
//
//			if (talimatl�BorclistModul5!= null) {
//				int talimatl�BorclistModul5Lenght = talimatl�BorclistModul5.length;
//				if(talimatl�BorclistModul5Lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize + talimatl�BorclistModul5Lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul5[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize = tableSize + talimatl�BorclistModul5Lenght;
//				}
//
//			if (talimatl�BorclistModul6!= null) {
//				int talimatl�BorclistModul6Lenght = talimatl�BorclistModul6.length;
//				if(talimatl�BorclistModul6Lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize + talimatl�BorclistModul6Lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul6[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize = tableSize + talimatl�BorclistModul6Lenght;
//				}
//
//			if (talimatl�BorclistModul12!= null) {
//				int talimatl�BorclistModul12Lenght = talimatl�BorclistModul12.length;
//				if(talimatl�BorclistModul12Lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize +talimatl�BorclistModul12Lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul12[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize = tableSize + talimatl�BorclistModul12Lenght;
//				}
//
//			if (talimatl�BorclistModul13!= null) {
//				int talimatl�BorclistModul13Lenght = talimatl�BorclistModul13.length;
//				if(talimatl�BorclistModul13Lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize + talimatl�BorclistModul13Lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul13[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize = tableSize + talimatl�BorclistModul13Lenght;
//				}
//
//			if (talimatl�BorclistModul14!= null) {
//				int talimatl�BorclistModul14Lenght = talimatl�BorclistModul14.length;
//				if(talimatl�BorclistModul14Lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize + talimatl�BorclistModul14Lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul14[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize =tableSize + talimatl�BorclistModul14Lenght;
//				}
//
//			if (talimatl�BorclistModul15!= null) {
//				int talimatl�BorclistModul15Lenght = talimatl�BorclistModul15.length;
//				if(talimatl�BorclistModul15Lenght>0){
//					int counter = 0;
//					for (int i = tableSize; i < tableSize + talimatl�BorclistModul15Lenght; i++) {
//						String  talimatl�Borc = talimatl�BorclistModul15[counter];
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						
//						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//
//						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							
//						String[] splitedTalimatl�Borc= talimatl�Borc.split(COLLECTION_INFO_DELIMITER);
//						String bankCollectionType = getBankCollectionType(corporateCode, splitedTalimatl�Borc[0]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, splitedTalimatl�Borc[1]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, splitedTalimatl�Borc[2]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, splitedTalimatl�Borc[3]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, splitedTalimatl�Borc[4]);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, bankCollectionType);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE,new Date());
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
//						outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
//						counter++;
//						}
//					}
//					tableSize = tableSize + talimatl�BorclistModul15Lenght;
//				}
			outMap.put(MapKeys.TABLE_SIZE, tableSize);
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KUTAHYA_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}
	
	@GraymoundService("ICS_KUTAHYA_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
	iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KUTAHYA_GET_COLLECTION_RECONCILIATION_DETAIL");
	GMMap outMap = new GMMap();
	GMMap reconCorpAmountMap = new GMMap();
	try {
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
		String responseCode="";
		Webservis_MutabakatBean[] makbuzList = KutahyaSuClient.mutabakatListe(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, RECONCILIATION_DETAY);
		if(makbuzList == null){
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		}
		logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_GET_COLLECTION_RECONCILIATION_DETAIL.");
		GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
		outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
		outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
		outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
		int makbuzlistLenght = 0;
		if (makbuzList != null) {
			makbuzlistLenght = makbuzList.length;
			Webservis_MutabakatBean makbuz = new Webservis_MutabakatBean();
			for (int i = 0; i < makbuzlistLenght; i++) {
				makbuz = makbuzList[i];
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.SUBSCRIBER_NO1, makbuz.getAboneNo());
//				reconCorpAmountMap.put("CORPORATE", i, MapKeys.TRX_NO, getMakbuzNo(makbuz.getDekontNo()));
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.TRX_NO, makbuz.getDekontNo());
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_AMOUNT, makbuz.getToplam());
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.INVOICE_NO, makbuz.getBorcId());
			}
		}
		
		GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
		outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
		int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
		int corporateCollectionCount = makbuzlistLenght;
		GMMap rcInput = new GMMap();
		rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

		boolean found = false;
		if (bankCollectionCount > corporateCollectionCount) {
			short collectionType = 0;
			for (int j = 0; j < bankCollectionCount; j++) {
				for (int i = 0; i < corporateCollectionCount; i++) {
					if (reconBankMap.getString("BANK", j, MapKeys.TRX_NO).equals(
									reconCorpAmountMap.getString("CORPORATE", i, MapKeys.TRX_NO))
//							&& reconBankMap.getString("BANK", j, MapKeys.PARAMETER2).equals(
//									reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PARAMETER2))
							&& reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(
									reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
						found = true;
						break;
					} else {
						found = false;
					}
				}
				if (!found) {
					// bulunamayan numara icin talimat istegi gonder
					GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
					request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
					request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
					request.put(MapKeys.CORPORATE_CODE, corporateCode);
					request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, request.getString(MapKeys.SUBSCRIBER_NO2));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO3, request.getString(MapKeys.SUBSCRIBER_NO3));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO4, request.getString(MapKeys.SUBSCRIBER_NO4));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString(MapKeys.INSTALLMENT_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_PAYMENT_ID, request.getString(MapKeys.CORPORATE_PAYMENT_ID));
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					
					try {
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
					} catch (Exception e) {
						// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
						e.printStackTrace();
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
					}

					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat Mesaji Gonderildi
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
				
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
				}
			}
		} else {
			short collectionType = 0;
			for (int j = 0; j < corporateCollectionCount; j++) {
				for (int k = 0; k < bankCollectionCount; k++) {
					if (//reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1))&&
							reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO).equals(
									reconBankMap.getString("BANK", k, MapKeys.TRX_NO))
//							&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2).equals(
//									reconBankMap.getString("BANK", k, MapKeys.PARAMETER2))
							&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(
									reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
						found = true;
						break;
					} else {
						found = false;
						break;
					}
				}
				if (!found) {
					// bulunamayan numara icin talimat iptal istegi gonder
					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
					String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					GMMap request = new GMMap();
					request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
					request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
					request.put(MapKeys.PARAMETER2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2));
					request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
					request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
					request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, request.getString(MapKeys.SUBSCRIBER_NO2));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO3, request.getString(MapKeys.SUBSCRIBER_NO3));
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO4, request.getString(MapKeys.SUBSCRIBER_NO4));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
					onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
					onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString(MapKeys.INSTALLMENT_NO));
					onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_PAYMENT_ID, request.getString(MapKeys.CORPORATE_PAYMENT_ID));
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					try {
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
					} catch (Exception e) {
						// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
						e.printStackTrace();
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
						onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
					}

					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
								onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
					}
					if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
								onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);																										
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);

				}
			}
		}
	
		insertOnlineServiceLog(iMap, outMap);

	} catch (Exception e2) {
		logger.error("An exception occured while executing ICS_KUTAHYA_GET_COLLECTION_RECONCILIATION_DETAIL.");
		logger.error(System.currentTimeMillis(), e2);
		outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
		outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
		outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
		insertOnlineServiceLog(iMap, outMap);
		e2.printStackTrace();
		throw e2;
	}

	return outMap;
	}
	
	@GraymoundService("ICS_KUTAHYA_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KUTAHYA_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
//			String tarih = "11/10/2013";
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");

			Webservis_MutabakatBean[] reconciliationResult = KutahyaSuClient.mutabakatListe(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih,RECONCILIATION_DETAY);

			if (reconciliationResult != null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_COLLECTION_RECONCILIATION.");
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && reconciliationResult.length>0) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconciliationResult[0].getTahsilatToplam());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconciliationResult[0].getTahsilatSayisi());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconciliationResult[0].getIptalToplam());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconciliationResult[0].getIptalSayisi());
			}else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);

			}

			// /invoice payment dan corporate payment_amount count payment
			// status t I ayr�m� yap
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(
					outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) 
			{
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KUTAHYA_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}
	
	@GraymoundService("ICS_KUTAHYA_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KUTAHYA_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		GMMap responceCodeMap;
		
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			
			double tutar = 0;
			int makbuzAdet = 0;
			
				Webservis_MutabakatBean[] reconciliationResult = KutahyaSuClient.mutabakatListe(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih,RECONCILIATION_DETAY);
	
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				
				if (reconciliationResult != null) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				logger.error(responseCode + " returned by Corporate for Kutahya Reconciliation Detail.");
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && reconciliationResult.length>0) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconciliationResult[0].getTahsilatToplam());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconciliationResult[0].getTahsilatSayisi());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconciliationResult[0].getIptalToplam());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconciliationResult[0].getIptalSayisi());
				}else {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);

				}

				tutar = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL).doubleValue();
				makbuzAdet = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);

			
			
			Webservis_MutabakatBeanA[] result = KutahyaSuClient.mutabakatIstek(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, tutar, makbuzAdet);
			
			if (result != null) {
				responseCode = result[0].getMesaj().substring(0,7);
			}
			logger.error(responseCode + " returned by Corporate for ICS_KUTAHYA_COLLECTION_RECONCILIATION_CLOSED.");
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID),corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KUTAHYA_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;

	}

	
//	private static String getKutahyaSuDekont(String dekont) {
//		String kutahyaSuDekont = BRANCH_CODE + RECEIPT_DELIMITER1 +  PAY_DESK + RECEIPT_DELIMITER2 + dekont;
//		return kutahyaSuDekont;
//	}
//	
//	private static String getMakbuzNo(String dekontNo){
//		String makbuzNo="";
//		String[] splitedTahsilat = dekontNo.split(RECEIPT_DELIMITER2);
//		makbuzNo = splitedTahsilat[1]; 
//		return makbuzNo;	
//	}
//	
	
}

	
