package tr.com.aktifbank.bnspr.corporation.management;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateServices;
import tr.com.aktifbank.bnspr.dao.CorporateWsAccountMatching;
import tr.com.aktifbank.bnspr.dao.CorporateWsUsers;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.aktifbank.bnspr.dao.EccpsCreditLoad;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.aktifbank.bnspr.dao.ServiceResponseCodeMapping;
import tr.com.aktifbank.bnspr.dao.StandingOrderMain;
import tr.com.aktifbank.bnspr.dao.WebServices;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class CorporationManagementServices {
	private static final Log logger = LogFactory.getLog(CorporationManagementServices.class);
	private final static String SAME_SUBSCRIBER_GSM_MONEY_LOAD = "SAME_SUBSCRIBER_GSM_MONEY_LOAD";
	private final static String SAME_INVOICE_NO = "SAME_INVOICE_NO";
	private final static String START_WITH = "START_WITH";
	private final static String END_WITH = "END_WITH";
	private final static String EQUALS = "EQUALS";
	private final static String IN = "IN";
	private final static String NOT_LIKE = "NOT_LIKE";
	private final static String NOT_EQUAL = "NOT_EQUAL";
	private final static String AND = "AND";
	private final static String OR = "OR";

	@GraymoundService("CDM_GET_CORPORATION_MANAGEMENT_SERVICES")
	public static GMMap getCorporationManagementServices(GMMap inputMap) {
		GMMap returnMap = new GMMap();

		String corporateCode = inputMap.getString(MapKeys.CORPORATE_CODE);
		Session session = DAOSession.getSession("BNSPRDal");

		Criteria cr;

		cr = session.createCriteria(WebServices.class).add(Restrictions.eq("corporateCode", corporateCode));

		@SuppressWarnings("unchecked")
		List<WebServices> webServiceList = (List<WebServices>) cr.list();
		int row = 0;
		for (WebServices webServices : webServiceList) {
			returnMap.put("WEB_SERVICES", row, "OID", webServices.getOid());
			returnMap.put("WEB_SERVICES", row, "CORPORATE_CODE", webServices.getCorporateCode());
			returnMap.put("WEB_SERVICES", row, "SERVICE_NAME", webServices.getServiceName());
			returnMap.put("WEB_SERVICES", row, "WS_USER", webServices.getWsUser());
			returnMap.put("WEB_SERVICES", row, "WS_PASSWORD", webServices.getWsPassword());
			returnMap.put("WEB_SERVICES", row, "WS_ENDPOINT", webServices.getWsEndPoint());
			returnMap.put("WEB_SERVICES", row, "WS_TIMEOUT_DURATION", webServices.getWsTimeOutDuration());
			returnMap.put("WEB_SERVICES", row, "CREATE_DATE", webServices.getCreateDate());
			returnMap.put("WEB_SERVICES", row, "CREATE_USER", webServices.getCreateUser());
			returnMap.put("WEB_SERVICES", row, "UPDATE_DATE", webServices.getUpdateDate());
			returnMap.put("WEB_SERVICES", row, "UPDATE_USER", webServices.getUpdateUser());
			returnMap.put("WEB_SERVICES", row, "PARAMETER_1", webServices.getParameter1());
			returnMap.put("WEB_SERVICES", row, "PARAMETER_2", webServices.getParameter2());
			returnMap.put("WEB_SERVICES", row, "PARAMETER_3", webServices.getParameter3());
			returnMap.put("WEB_SERVICES", row, "PARAMETER_4", webServices.getParameter4());
			returnMap.put("WEB_SERVICES", row, "PARAMETER_5", webServices.getParameter5());
			returnMap.put("WEB_SERVICES", row, "PARAMETER_6", webServices.getParameter6());
			if (webServices.isStatus()) {
				returnMap.put("WEB_SERVICES", row, "STATUS", "1");
			}
			else {
				returnMap.put("WEB_SERVICES", row, "STATUS", "0");
			}
			row++;
		}

		cr = session.createCriteria(CorporateServices.class).add(Restrictions.eq("corporateCode", corporateCode));

		@SuppressWarnings("unchecked")
		List<CorporateServices> corporateServiceList = (List<CorporateServices>) cr.list();
		row = 0;
		for (CorporateServices corporateServices : corporateServiceList) {
			returnMap.put("CORPORATE_SERVICES", row, "OID", corporateServices.getOid());
			returnMap.put("CORPORATE_SERVICES", row, "CORPORATE_CODE", corporateServices.getCorporateCode());
			returnMap.put("CORPORATE_SERVICES", row, "GM_SERVICE_NAME", corporateServices.getGmServiceName());
			returnMap.put("CORPORATE_SERVICES", row, "WEB_SERVICE_NAME", corporateServices.getWebServiceName());
			returnMap.put("CORPORATE_SERVICES", row, "IS_SAF_SERVICE", corporateServices.getIsSafService());
			returnMap.put("CORPORATE_SERVICES", row, "CREATE_DATE", corporateServices.getCreateDate());
			returnMap.put("CORPORATE_SERVICES", row, "CREATE_USER", corporateServices.getCreateUser());
			returnMap.put("CORPORATE_SERVICES", row, "UPDATE_DATE", corporateServices.getUpdateDate());
			returnMap.put("CORPORATE_SERVICES", row, "UPDATE_USER", corporateServices.getUpdateUser());
			if (corporateServices.isStatus()) {
				returnMap.put("CORPORATE_SERVICES", row, "STATUS", "1");
			}
			else {
				returnMap.put("CORPORATE_SERVICES", row, "STATUS", "0");
			}
			row++;
		}
		return returnMap;
	}

	@GraymoundService("CDM_CHANGE_SAF_STATUS")
	public static GMMap changeSafStatus(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		String isSafService = inputMap.getString("IS_SAF_SERVICE");
		if (isSafService.equals("EVET")) {
			isSafService = "0";
		}
		else {
			isSafService = "1";
		}
		String oid = inputMap.getString("OID");
		String query = String.format(QueryRepository.CorporationManagementServicesRepository.CHANGE_SAF_STATUS, isSafService, oid);
		// String query =
		// "update cdm.corporate_services set is_saf_service=".concat(isSafService).concat(" where oid='").concat(oid).concat("'");
		String result = "FALSE";
		try {
			CommonHelper.executeQuery(query);
			result = "TRUE";
		}
		catch (Exception e) {
			logger.info("CDM_CHANGE_SAF_STATUS -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_CHANGE_SAF_STATUS -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		returnMap.put("RESULT", result);
		return returnMap;

	}

	@GraymoundService("CDM_CM_FILL_COMBO_VALUES")
	public static GMMap cdmFillComboValues(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		GMMap returnMapForTableName = new GMMap();
		GMMap inputForGetComboValues = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		Criteria cr;
		String corporateCode = inputMap.getString("CORPORATE_CODE");

		try {
			// for tab duplicate check
			returnMap.put("COMBO_VALUES", 0, "NAME", "Ayn� fatura numaras� ile fatura �deme (T�m Kurumlar)");
			returnMap.put("COMBO_VALUES", 0, "VALUE", SAME_INVOICE_NO);
			returnMap.put("COMBO_VALUES", 1, "NAME", "Ayn� GSM numaras� ile TL y�kleme (T�m Kurumlar)");
			returnMap.put("COMBO_VALUES", 1, "VALUE", SAME_SUBSCRIBER_GSM_MONEY_LOAD);
			// for tab payment check start
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 0, "NAME", "e�it");
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 0, "VALUE", EQUALS);
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 1, "NAME", "ile ba�layan");
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 1, "VALUE", START_WITH);
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 2, "NAME", "ile biten");
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 2, "VALUE", END_WITH);
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 3, "NAME", "i�eren");
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 3, "VALUE", IN);
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 4, "NAME", "e�it de�il");
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 4, "VALUE", NOT_EQUAL);
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 5, "NAME", "i�ermeyen");
			returnMap.put("COMBO_VALUES_PAYMENT_CHECK", 5, "VALUE", NOT_LIKE);
			inputForGetComboValues.put("KOD", "CDM_PAYMENT_CHECK_TABLE_NAMES");
			returnMapForTableName = CorporationServiceUtil.getComboValues(inputForGetComboValues);
			returnMap.put("COMBO_VALUES_TABLE_NAME", 0, "NAME", "Tablo Se�iniz...");
			returnMap.put("COMBO_VALUES_TABLE_NAME", 0, "VALUE", "SELECT_TABLE");
			for (int i = 1; i < returnMapForTableName.getSize("RESULTS") + 1; i++) {
				returnMap.put("COMBO_VALUES_TABLE_NAME", i, "NAME", returnMapForTableName.getString("RESULTS", i - 1, "NAME"));
				returnMap.put("COMBO_VALUES_TABLE_NAME", i, "VALUE", returnMapForTableName.getString("RESULTS", i - 1, "VALUE"));
			}
			// for tab payment check
			returnMap.put("COMBO_VALUES_AND_OR", 0, "NAME", "VE");
			returnMap.put("COMBO_VALUES_AND_OR", 0, "VALUE", AND);
			returnMap.put("COMBO_VALUES_AND_OR", 1, "NAME", "VEYA");
			returnMap.put("COMBO_VALUES_AND_OR", 1, "VALUE", OR);

			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 0, "NAME", "5");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 0, "VALUE", "5");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 1, "NAME", "15");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 1, "VALUE", "15");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 2, "NAME", "30");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 2, "VALUE", "30");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 3, "NAME", "45");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 3, "VALUE", "45");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 4, "NAME", "60");
			returnMap.put("COMBO_VALUES_TIME_INTERVAL", 4, "VALUE", "60");

			returnMap.put("COMBO_VALUES_LOG_MONITORING", 0, "NAME", "i�eren");
			returnMap.put("COMBO_VALUES_LOG_MONITORING", 0, "VALUE", IN);

			cr = session.createCriteria(CorporateServices.class).add(Restrictions.eq("status", true));
			cr.add(Restrictions.eq("corporateCode", corporateCode));

			@SuppressWarnings("unchecked")
			List<CorporateServices> corporateServiceList = (List<CorporateServices>) cr.list();
			returnMap.put("COMBO_VALUES_SERVICE_NAMES", 0, "NAME", "T�m Servisler...");
			returnMap.put("COMBO_VALUES_SERVICE_NAMES", 0, "VALUE", "ALL");
			int row = 1;
			for (CorporateServices corporateServices : corporateServiceList) {
				returnMap.put("COMBO_VALUES_SERVICE_NAMES", row, "NAME", corporateServices.getGmServiceName());
				returnMap.put("COMBO_VALUES_SERVICE_NAMES", row, "VALUE", corporateServices.getGmServiceName());
				row++;
			}
		}
		catch (Exception e) {
			logger.info("CDM_CM_FILL_COMBO_VALUES -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_CM_FILL_COMBO_VALUES -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		return returnMap;
	}

	@GraymoundService("CDM_CM_RUN_DUPLICATE_CHECK")
	public static GMMap cdmRunDuplicateCheck(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		
		Date date = new Date();
		String dateString = CommonHelper.getDateString(date, "yyyyMMdd");
		
		StringBuilder sb = new StringBuilder();
		if (inputMap.getString("CONTROL_TYPE").equals(SAME_INVOICE_NO)) {
			sb.append(String.format(QueryRepository.CorporationManagementServicesRepository.DUPLICATE_INVOICE_CHECK_QUERY, dateString));
		}
		else if (inputMap.getString("CONTROL_TYPE").equals(SAME_SUBSCRIBER_GSM_MONEY_LOAD)) {
			sb.append(String.format(QueryRepository.CorporationManagementServicesRepository.DUPLICATE_MONEY_LOAD_QUERY, dateString));
		}

		String query = sb.toString();

		String result = "FALSE";
		try {
			GMMap returnMap2 = CommonHelper.queryData(query, "DUPLICATE_SUMMARY");
			for (int i = 0; i < returnMap2.getSize("DUPLICATE_SUMMARY"); i++) {
				returnMap.put("RESULT_SET", i, "INVOICE_NO", returnMap2.get("DUPLICATE_SUMMARY", i, "INVOICE_NO"));
				returnMap.put("RESULT_SET", i, "PAYMENT_AMOUNT", returnMap2.get("DUPLICATE_SUMMARY", i, "PAYMENT_AMOUNT"));
				returnMap.put("RESULT_SET", i, "RECORD_NUMBER", returnMap2.get("DUPLICATE_SUMMARY", i, "RECORD_NUMBER"));
			}
			returnMap.putAll(returnMap2);
			result = "TRUE";
		}
		catch (Exception e) {
			logger.info("CDM_CM_RUN_DUPLICATE_CHECK -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_CM_RUN_DUPLICATE_CHECK -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		returnMap.put("RESULT", result);
		return returnMap;

	}

	@GraymoundService("CDM_CM_GET_INVOICE_DETAIL")
	public static GMMap cdmGetInvoiceDetails(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		StringBuilder sb = new StringBuilder();
		if (inputMap.getString("CONTROL_TYPE").equals(SAME_INVOICE_NO)) {
			Date date = new Date();
			String dateString = CommonHelper.getDateString(date, "yyyyMMdd");
			sb.append(String.format(QueryRepository.CorporationManagementServicesRepository.GET_INVOICE_DETAIL, inputMap.getString("INVOICE_NO"), dateString));
		}
		else if (inputMap.getString("CONTROL_TYPE").equals(SAME_SUBSCRIBER_GSM_MONEY_LOAD)) {
			Date date = new Date();
			String dateString = CommonHelper.getDateString(date, "yyyyMMdd");
			sb.append(String.format(QueryRepository.CorporationManagementServicesRepository.GET_MONEY_LOAD_DETAIL, inputMap.getString("INVOICE_NO"), dateString));
		}

		String query = sb.toString();
		String result = "FALSE";
		try {
			GMMap returnMap2 = CommonHelper.queryData(query, "DUPLICATE_SUMMARY");
			for (int i = 0; i < returnMap2.getSize("DUPLICATE_SUMMARY"); i++) {
				returnMap.put("RESULT_SET", i, "OID", returnMap2.get("DUPLICATE_SUMMARY", i, "OID"));
				returnMap.put("RESULT_SET", i, "CORPORATE_CODE", returnMap2.get("DUPLICATE_SUMMARY", i, "CORPORATE_CODE"));
				returnMap.put("RESULT_SET", i, "SUBSCRIBER_NO", returnMap2.get("DUPLICATE_SUMMARY", i, "SUBSCRIBER_NO1"));
				returnMap.put("RESULT_SET", i, "TX_NO", returnMap2.get("DUPLICATE_SUMMARY", i, "TX_NO"));
				returnMap.put("RESULT_SET", i, "INVOICE_NO", returnMap2.get("DUPLICATE_SUMMARY", i, "INVOICE_NO"));
				returnMap.put("RESULT_SET", i, "PAYMENT_AMOUNT", returnMap2.get("DUPLICATE_SUMMARY", i, "PAYMENT_AMOUNT"));
				returnMap.put("RESULT_SET", i, "SHORT_CODE", returnMap2.get("DUPLICATE_SUMMARY", i, "SHORT_CODE"));
				returnMap.put("RESULT_SET", i, "INSTALLMENT_NO", returnMap2.get("DUPLICATE_SUMMARY", i, "INSTALLMENT_NO"));
				returnMap.put("RESULT_SET", i, "REC_OWNER", returnMap2.get("DUPLICATE_SUMMARY", i, "REC_OWNER"));
				returnMap.put("RESULT_SET", i, "STATUS", returnMap2.get("DUPLICATE_SUMMARY", i, "STATUS"));
			}
			returnMap.putAll(returnMap2);
			result = "TRUE";
		}
		catch (Exception e) {
			logger.info("CDM_CM_GET_INVOICE_DETAIL -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_CM_GET_INVOICE_DETAIL -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		returnMap.put("RESULT", result);
		return returnMap;

	}

	@GraymoundService("CDM_RUN_QUERY_FOR_PAYMENT_CHECK")
	public static GMMap cdmRunQueryForPaymentCheck(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		new GMMap();
		StringBuilder sbForCriterias = new StringBuilder();
		StringBuilder criterias = new StringBuilder();
		int listSize = 0;
		String errorMessage = "";
		String woCorporte = inputMap.getString("WO_CORPORATE");
		String dateStartStr = inputMap.getString("START_DATE");
		String dateEndStr = inputMap.getString("END_DATE");
		String startTime = inputMap.getString("START_TIME");
		String endTime = inputMap.getString("END_TIME");
		String corporateCode = inputMap.getString("CORPORATE_CODE");
		int listSizeForResultFields = inputMap.getSize("RESULT_FIELDS");
		for (int i = 0; i < 10; i++) {
			returnMap.put("COL".concat(Integer.toString(i + 1)).concat("_VISIBLE"), "FALSE");
		}
		for (int i = 0; i < listSizeForResultFields; i++) {
			sbForCriterias.append(inputMap.getString("RESULT_FIELDS", i, "RESULT"));
			sbForCriterias.append(",");
			returnMap.put("COL".concat(Integer.toString(i + 1)).concat("_TITLE"), inputMap.getString("RESULT_FIELDS", i, "RESULT"));
			returnMap.put("COL".concat(Integer.toString(i + 1)).concat("_VISIBLE"), "TRUE");
		}

		listSize = inputMap.getSize("CRITERIA_LIST");
		for (int i = 0; i < listSize; i++) {
			if (inputMap.getString("CRITERIA_LIST", i, "USE_FOR_QUERY").equals("1")) {
				criterias.append(inputMap.getString("CRITERIA_LIST", i, "CRITERIA"));
				if ("NULL".equals(inputMap.getString("CRITERIA_LIST", i, "VALUE"))) {
					criterias.append(" is null ");
				}
				else if (EQUALS.equals(inputMap.getString("CRITERIA_LIST", i, "EQUALITY_STATUS"))) {
					criterias.append("='");
					criterias.append(inputMap.getString("CRITERIA_LIST", i, "VALUE"));
					criterias.append("'");
				}
				else if (START_WITH.equals(inputMap.getString("CRITERIA_LIST", i, "EQUALITY_STATUS"))) {
					criterias.append(" like '");
					criterias.append(inputMap.getString("CRITERIA_LIST", i, "VALUE"));
					criterias.append("%'");
				}
				else if (END_WITH.equals(inputMap.getString("CRITERIA_LIST", i, "EQUALITY_STATUS"))) {
					criterias.append(" like '%");
					criterias.append(inputMap.getString("CRITERIA_LIST", i, "VALUE"));
					criterias.append("'");
				}
				else if (IN.equals(inputMap.getString("CRITERIA_LIST", i, "EQUALITY_STATUS"))) {
					criterias.append(" like '%");
					criterias.append(inputMap.getString("CRITERIA_LIST", i, "VALUE"));
					criterias.append("%'");
				}
				else if (NOT_LIKE.equals(inputMap.getString("CRITERIA_LIST", i, "EQUALITY_STATUS"))) {
					criterias.append(" not like '%");
					criterias.append(inputMap.getString("CRITERIA_LIST", i, "VALUE"));
					criterias.append("%'");
				}
				else if (NOT_EQUAL.equals(inputMap.getString("CRITERIA_LIST", i, "EQUALITY_STATUS"))) {
					criterias.append(" <> '");
					criterias.append(inputMap.getString("CRITERIA_LIST", i, "VALUE"));
					criterias.append("'");
				}
				if (listSize > i + 1) {
					criterias.append(" AND ");
				}
			}
		}

		StringBuilder sb = new StringBuilder();
		sb.append("select ");
		sb.append(sbForCriterias.toString().substring(0, sbForCriterias.toString().length() - 1));
		sb.append(" from ");
		sb.append(inputMap.getString("SCHEMA"));
		sb.append(".");
		sb.append(inputMap.getString("TABLE_NAME"));
		sb.append(" where ");
		sb.append(criterias.toString());
		if (!woCorporte.equals("true")) {
			sb.append(" and corporate_code='".concat(corporateCode).concat("'"));
		}
		if (inputMap.getString("TABLE_NAME").equals("ICS_STANDING_ORDERS")) {
			// sb.append("'");
		}
		else {
			sb.append((" and payment_date > '"));
			sb.append(dateStartStr.concat(startTime));
			sb.append(("' and payment_date < '"));
			sb.append(dateEndStr.concat(endTime));
			sb.append("'");
		}
		String query = sb.toString();
		String result = "FALSE";
		try {
			// returnMap.put("RESULT_SET", 0, "COL1", "BA�LIK 1");
			GMMap returnMap2 = CommonHelper.queryData(query, "RUN_QUERY_RESULT");
			for (int i = 0; i < returnMap2.getSize("RUN_QUERY_RESULT"); i++) {
				for (int J = 0; J < listSize; J++) {
					for (int j2 = 1; j2 < listSizeForResultFields + 1; j2++) {
						returnMap.put("RESULT_SET", i, "COL".concat(Integer.toString(j2)), returnMap2.get("RUN_QUERY_RESULT", i, inputMap.getString("RESULT_FIELDS", j2 - 1, "RESULT")));
					}
				}
			}
			returnMap.putAll(returnMap2);
			result = "TRUE";
		}
		catch (Exception e) {
			logger.info("CDM_RUN_QUERY_FOR_PAYMENT_CHECK -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_RUN_QUERY_FOR_PAYMENT_CHECK -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
			errorMessage = e.getMessage();
		}
		returnMap.put("RESULT", result);
		returnMap.put("ERROR_MESSAGE", errorMessage);
		returnMap.put("RUNNED_QUERY", sb.toString());
		return returnMap;

	}

	@GraymoundService("CDM_PAYMENT_CHECK_GET_TABLE_FIELDS")
	public static GMMap cdmGetTableFields(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		GMMap returnMapForTableName = new GMMap();
		GMMap inputForGetComboValues = new GMMap();
		try {
			inputForGetComboValues.put("KOD", "CDM_PAYMENT_CHECK_".concat(inputMap.getString("TABLE_NAME")).concat("_FIELDS"));
			returnMapForTableName = CorporationServiceUtil.getComboValues(inputForGetComboValues);
			returnMap.put("TABLE_FIELDS", 0, "NAME", "Alan Se�iniz...");
			returnMap.put("TABLE_FIELDS", 0, "VALUE", "SELECT_FIELD");
			for (int i = 0; i < returnMapForTableName.getSize("RESULTS"); i++) {
				returnMap.put("TABLE_FIELDS", i + 1, "NAME", returnMapForTableName.getString("RESULTS", i, "NAME"));
				returnMap.put("TABLE_FIELDS", i + 1, "VALUE", returnMapForTableName.getString("RESULTS", i, "VALUE"));
			}
		}
		catch (Exception e) {
			logger.info("CDM_PAYMENT_CHECK_GET_TABLE_FIELDS -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_PAYMENT_CHECK_GET_TABLE_FIELDS -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		return returnMap;
	}

	@GraymoundService("CDM_RUN_QUERY_FOR_LOG_MONITORING")
	public static GMMap cdmRunQueryForLogMonitoring(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		boolean rdbDatetimeInterval = inputMap.getBoolean("RDB_DATE_TIME_INTERVAL", false);
		boolean rdbtimeInterval = inputMap.getBoolean("RDB_TIME_INTERVAL", false);
		String dateTime = inputMap.getString("DATE_TIME");
		String startTime = inputMap.getString("START_TIME");
		String EndTime = inputMap.getString("END_TIME");
		String timeInterval = inputMap.getString("TIME_INTERVAL");
		String inputText = inputMap.getString("INPUT_TEXT");
		String returnText = inputMap.getString("RETURN_TEXT");
		String inputMapCriteria = inputMap.getString("INPUT_MAP_CRITERIA");
		String returnMapCriteria = inputMap.getString("RETURN_MAP_CRITERIA");
		String andOr = inputMap.getString("AND_OR");
		String corporateCode = inputMap.getString("CORPORATE_CODE");
		String serviceName = inputMap.getString("SERVICE_NAME");
		String errorCheck = inputMap.getString("ERROR_CHECK");
		String subscriberNo1 = inputMap.getString("SUBSCRIBER_NO1");
		String subscriberNo2 = inputMap.getString("SUBSCRIBER_NO2");
		String subscriberNo3 = inputMap.getString("SUBSCRIBER_NO3");
		String subscriberNo4 = inputMap.getString("SUBSCRIBER_NO4");
		String invoiceNo = inputMap.getString("INVOICE_NO");
		
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("Select * from ics.online_service_log where corporate_code='");
			sb.append(corporateCode);
			sb.append("' ");
			if ("true".equals(errorCheck)) {
				sb.append(" and error_code !='0' ");
			}
			if (!inputText.isEmpty()) {
				if (IN.equals(inputMapCriteria)) {
					sb.append(" and (input_map like '%");
					sb.append(inputText);
					sb.append("%'");
				}
			}
			if (!returnText.isEmpty()) {
				if (!inputText.isEmpty()) {
					if ("OR".equals(andOr)) {
						sb.append(" or ");
					}
					else {
						sb.append(" and ");
					}

				}
				else {
					sb.append(" and ");
				}
				if (IN.equals(returnMapCriteria)) {
					sb.append(" response like '%");
					sb.append(returnText);
					sb.append("%'");
				}
			}
			if (!inputText.isEmpty()) {
				sb.append(")");
			}
			if (rdbtimeInterval) {
				sb.append(" and ");
				sb.append(" process_date>sysdate-1/");
				if ("5".equals(timeInterval)) {
					sb.append("288");
				}
				else if ("15".equals(timeInterval)) {
					sb.append("96");
				}
				else if ("30".equals(timeInterval)) {
					sb.append("48");
				}
				else if ("45".equals(timeInterval)) {
					sb.append("32");
				}
				else if ("60".equals(timeInterval)) {
					sb.append("24");
				}
			}
			else if (rdbDatetimeInterval) {
				sb.append(" and ");
				String dateStr = CommonHelper.convertToDate(dateTime, "yyyyMMdd", "yyyy-MM-dd", null);
				sb.append(" process_date>to_date('".concat(dateStr).concat(" ".concat(startTime).concat("', 'yyyy-mm-dd hh24miss')")));
				sb.append(" and process_date<to_date('".concat(dateStr).concat(" ".concat(EndTime).concat("', 'yyyy-mm-dd hh24miss')")));
			}
			if (!serviceName.equals("ALL")) {
				sb.append(" and gm_service_name='");
				sb.append(serviceName);
				sb.append("'");
			}
			
			if(!subscriberNo1.equals("")){
				sb.append(" and subscriber_no1='");
				sb.append(subscriberNo1);
				sb.append("'");
			}
			if(!subscriberNo2.equals("")){
				sb.append(" and subscriber_no2='");
				sb.append(subscriberNo2);
				sb.append("'");		
						}
			if(!subscriberNo3.equals("")){
				sb.append(" and subscriber_no3='");
				sb.append(subscriberNo3);
				sb.append("'");
			}
			if(!subscriberNo4.equals("")){
				sb.append(" and subscriber_no4='");
				sb.append(subscriberNo4);
				sb.append("'");
			}
			if(!invoiceNo.equals("")){
				sb.append(" and invoice_no='");
				sb.append(invoiceNo);
				sb.append("'");
			}
			sb.append(" order by process_date desc");
			returnMap.put("RUNNED_SQL", sb.toString());
			String query = sb.toString();
			String result = "FALSE";
			try {
				// returnMap.put("RESULT_SET", 0, "COL1", "BA�LIK 1");
				GMMap returnMap2 = CommonHelper.queryData(query, "LOG_LIST");
				returnMap.putAll(returnMap2);
				result = "TRUE";
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		catch (Exception e) {
			logger.info("CDM_RUN_QUERY_FOR_LOG_MONITORING -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_RUN_QUERY_FOR_LOG_MONITORING -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		return returnMap;
	}

	@GraymoundService("CDM_CORPORATE_MANAGEMENT_GET_ERROR_LIST")
	public static GMMap getErrorList(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			Criteria cr = session.createCriteria(ServiceResponseCodeMapping.class).add(Restrictions.eq("status", true));
			cr.add(Restrictions.eq("corporateCode", inputMap.getString("CORPORATE_CODE")));
			List<ServiceResponseCodeMapping> srcmList = (List<ServiceResponseCodeMapping>) cr.list();
			int row = 0;
			for (ServiceResponseCodeMapping srcm : srcmList) {
				returnMap.put("ERROR_LIST", row, "CORPORATE_CODE", srcm.getCorporateCode());
				returnMap.put("ERROR_LIST", row, "ERROR_CODE", srcm.getErrorCode());
				returnMap.put("ERROR_LIST", row, "EXPLANATION", srcm.getExplanation());
				returnMap.put("ERROR_LIST", row, "FOR_ALL_SERVICES", srcm.getForAllServices());
				returnMap.put("ERROR_LIST", row, "OID", srcm.getOid());
				returnMap.put("ERROR_LIST", row, "RETURN_CODE", srcm.getReturnCode());
				returnMap.put("ERROR_LIST", row, "RETURN_CODE_DESC", srcm.getReturnCodeDesc());
				returnMap.put("ERROR_LIST", row, "SERVICE_OID", srcm.getServiceOid());
				row++;
			}
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_GET_ERROR_LIST -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_CORPORATE_MANAGEMENT_GET_ERROR_LIST -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		return returnMap;

	}

	@GraymoundService("CDM_CORPORATE_MANAGEMENT_UPDATE_ERROR_CODE")
	public static GMMap updateErrorCode(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String strOid = inputMap.getString("OID");
		String returnCode = inputMap.getString("RETURN_CODE");
		String returnCodeDesc = inputMap.getString("RETURN_CODE_DESC");
		String errorCode = inputMap.getString("ERROR_CODE");
		String explanation = inputMap.getString("EXPLANATION");
		String forAllServices = inputMap.getString("FOR_ALL_SERVICES");
		try {
			Criteria cr = session.createCriteria(ServiceResponseCodeMapping.class).add(Restrictions.eq("oid", strOid));
			ServiceResponseCodeMapping srcm = (ServiceResponseCodeMapping) cr.uniqueResult();
			srcm.setReturnCode(returnCode);
			srcm.setReturnCodeDesc(returnCodeDesc);
			srcm.setErrorCode(errorCode);
			srcm.setExplanation(explanation);
			srcm.setForAllServices(forAllServices);
			session.saveOrUpdate(srcm);
			session.flush();
			returnMap.put("ERROR", "FALSE");
		}
		catch (Exception e) {
			returnMap.put("ERROR", "TRUE");
			logger.info("CDM_CORPORATE_MANAGEMENT_UPDATE_ERROR_CODE -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_CORPORATE_MANAGEMENT_UPDATE_ERROR_CODE -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		return returnMap;
	}

	@GraymoundService("CDM_CORPORATE_MANAGEMENT_GET_RECON_LIST")
	public static GMMap getReconList(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			Criteria cr = session.createCriteria(ReconLog.class).add(Restrictions.eq("status", true));
			cr.add(Restrictions.eq("corporateCode", inputMap.getString("CORPORATE_CODE")));
			cr.add(Restrictions.eq("reconDate", inputMap.getString("RECON_DATE")));
			List<ReconLog> reconList = (List<ReconLog>) cr.list();
			int row = 0;
			for (ReconLog srcm : reconList) {
				returnMap.put("RECON_LIST", row, "CORPORATE_CODE", srcm.getCorporateCode());
				returnMap.put("RECON_LIST", row, "RECON_STATUS", srcm.getReconStatus());
				returnMap.put("RECON_LIST", row, "RECON_TYPE", srcm.getReconType());
				returnMap.put("RECON_LIST", row, "PROCESS_DATE", srcm.getProcessDate());
				returnMap.put("RECON_LIST", row, "PROCESS_TIME", srcm.getProcessTime());
				returnMap.put("RECON_LIST", row, "PROCESS_USER", srcm.getProcessUser());
				returnMap.put("RECON_LIST", row, "BANK_COUNT", srcm.getBankCount());
				returnMap.put("RECON_LIST", row, "BANK_AMOUNT", srcm.getBankAmount());
				returnMap.put("RECON_LIST", row, "CORPORATE_COUNT", srcm.getCorporateCount());
				returnMap.put("RECON_LIST", row, "CORPORATE_AMOUNT", srcm.getCorporateAmount());
				returnMap.put("RECON_LIST", row, "BANK_CANCEL_COUNT", srcm.getBankCancelCount());
				returnMap.put("RECON_LIST", row, "BANK_CANCEL_AMOUNT", srcm.getBankCancelAmount());
				returnMap.put("RECON_LIST", row, "CORPORATE_CANCEL_COUNT", srcm.getCorporateCancelCount());
				returnMap.put("RECON_LIST", row, "CORPORATE_CANCEL_AMOUNT", srcm.getCorporateCancelAmount());
				returnMap.put("RECON_LIST", row, "ERROR_DESC", srcm.getErrorDesc());
				returnMap.put("RECON_LIST", row, "ERROR_CODE", srcm.getErrorCode());
				returnMap.put("RECON_LIST", row, "SUB_TYPE", srcm.getSubType());
				returnMap.put("RECON_LIST", row, "RECON_DATE", srcm.getReconDate());
				returnMap.put("RECON_LIST", row, "RECON_TIME", srcm.getReconTime());
				row++;
			}
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_GET_RECON_LIST -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_CORPORATE_MANAGEMENT_GET_RECON_LIST -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		return returnMap;

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_INSERT_CANCEL_RECORD")
	public static GMMap cdmInsertCancelRecord(GMMap inputMap) {
		GMMap outMap = new GMMap();
		try {
			String corporateCode = inputMap.getString(MapKeys.CORPORATE_CODE);
			String corporateOid = CommonBusinessOperations.getCorporateOidFromCorporateCode(corporateCode);
			Session session = CommonHelper.getHibernateSession();
			List<CorporationAccountMaster> list = session.createCriteria(CorporationAccountMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("accountDefinitionType", "TH")).list();
			
			String sectorCode = CommonBusinessOperations.getSectorCodeFromCorporateCode(corporateCode);
			
			String eccpsSectorCode = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "ECCPS_SECTOR_CODE");
			
			BigDecimal accountNo = list.get(0).getAccountNumber();

			if (eccpsSectorCode.equals(sectorCode)) {
				EccpsCreditLoad eccpsCreditLoad = new EccpsCreditLoad();
				eccpsCreditLoad.setStatus(true);
				eccpsCreditLoad.setSubscriberCardInfo(inputMap.getString(MapKeys.SUBSCRIBER_NO1));
				eccpsCreditLoad.setCorporateCode(corporateCode);
				eccpsCreditLoad.setLoadedAmount(new BigDecimal(inputMap.getString(MapKeys.PAYMENT_AMOUNT)));
				eccpsCreditLoad.setTxNo(new BigDecimal("-1"));
				eccpsCreditLoad.setPaymentDate(inputMap.getString(MapKeys.PAYMENT_DATE).concat("110000"));
				eccpsCreditLoad.setCancelDate(inputMap.getString(MapKeys.PAYMENT_DATE).concat("110000"));
				eccpsCreditLoad.setCorporateAccountNo(accountNo);
				eccpsCreditLoad.setPaymentStatus(PaymentStatuses.Cancelled);
				session.saveOrUpdate(eccpsCreditLoad);
			} else {
				invoicePayment payment = new invoicePayment();
				payment.setStatus(true);
				payment.setCorporateCode(corporateCode);
				payment.setCollectionType(Short.valueOf("0"));
				payment.setInvoiceMainOid("0");
				payment.setSubscriberNo1(inputMap.getString(MapKeys.SUBSCRIBER_NO1));
				payment.setSubscriberNo2(inputMap.getString(MapKeys.SUBSCRIBER_NO2));
				payment.setInvoiceNo(inputMap.getString(MapKeys.INVOICE_NO));
				payment.setPaymentStatus(PaymentStatuses.Cancelled);
				payment.setTxNo(new BigDecimal("-1"));
				payment.setInvoiceAmount(new BigDecimal(inputMap.getString(MapKeys.PAYMENT_AMOUNT)));
				payment.setPaymentAmount(new BigDecimal(inputMap.getString(MapKeys.PAYMENT_AMOUNT)));
				payment.setPaymentDate(inputMap.getString(MapKeys.PAYMENT_DATE).concat("110000"));
				payment.setCancelDate(inputMap.getString(MapKeys.PAYMENT_DATE).concat("110000"));
				payment.setCorporateAccountNo(accountNo);
				session.saveOrUpdate(payment);
			}
			
			session.flush();
			outMap.put("RESULT", "OK");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_INSERT_CANCEL_RECORD -> iptal kaydi olusurken hata meydana geldi..");
			outMap.put("RESULT", "ERROR");
		}
		return outMap;

	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_INSERT_BULK_CANCEL_RECORD")
	public static GMMap cdmInsertBulkCancelRecord(GMMap inputMap) {
		GMMap outMap = new GMMap();
		try {
			String corporateCode = inputMap.getString(MapKeys.CORPORATE_CODE);
			String corporateOid = CommonBusinessOperations.getCorporateOidFromCorporateCode(corporateCode);
			Session session = CommonHelper.getHibernateSession();
			List<CorporationAccountMaster> list = session.createCriteria(CorporationAccountMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("accountDefinitionType", "TH")).list();
			
			BigDecimal accountNo = list.get(0).getAccountNumber();
			String tableName = "CANCEL_RECORD_LIST"; 
			
			for (int i = 0; i < inputMap.getSize(tableName); i++) {
				String paymentDate = inputMap.getString(tableName, i, MapKeys.PAYMENT_DATE);

				invoicePayment payment = new invoicePayment();
				payment.setStatus(true);
				payment.setCorporateCode(corporateCode);
				payment.setCollectionType(Short.valueOf("0"));
				payment.setInvoiceMainOid("0");
				payment.setSubscriberNo1(inputMap.getString(tableName, i, MapKeys.SUBSCRIBER_NO1));
				payment.setSubscriberNo2(inputMap.getString(tableName, i, MapKeys.SUBSCRIBER_NO2));
				payment.setInvoiceNo(inputMap.getString(tableName, i, MapKeys.INVOICE_NO));
				payment.setPaymentStatus(PaymentStatuses.Cancelled);
				payment.setTxNo(new BigDecimal("-1"));
				payment.setInvoiceAmount(new BigDecimal(inputMap.getString(tableName, i, MapKeys.PAYMENT_AMOUNT)));
				payment.setPaymentAmount(new BigDecimal(inputMap.getString(tableName, i, MapKeys.PAYMENT_AMOUNT)));
				payment.setPaymentDate(CommonHelper.formatDateString(paymentDate, "dd.MM.yyyy", "yyyyMMdd").concat("110000"));
				payment.setCancelDate(CommonHelper.formatDateString(paymentDate, "dd.MM.yyyy", "yyyyMMdd").concat("110000"));
				payment.setCorporateAccountNo(accountNo);
				session.save(payment);
			}
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_INSERT_CANCEL_RECORD -> iptal kaydi olusurken hata meydana geldi..");
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
		
	}
	
	@GraymoundService("CDM_LOAD_CANCEL_RECORD_FILE")
	public static GMMap cdmLoadCancelRecordFile(GMMap inputMap) {
		GMMap outMap = new GMMap();
		try {
			String tableName = "CANCEL_RECORD_LIST"; 
			String filePath = inputMap.getString("FILE_PATH");
			String subscriberNo1 = null, subscriberNo2 = null, invoiceNo = null, paymentDate = null;
			BigDecimal paymentAmount = null;
			
			if (StringUtils.isEmpty(filePath))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Dosya Ad�"));	

			List<String> pathSplitForName = Arrays.asList(StringUtils.split(filePath, "\\"));			
			String fileName = pathSplitForName.get(pathSplitForName.size()-1);
			
			List<String> pathSplitForExtension = Arrays.asList(filePath.split("[.]"));			
			String fileExt = pathSplitForExtension.get(pathSplitForExtension.size()-1);
			if (!( StringUtils.equalsIgnoreCase("XLSX", fileExt) ) )
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.EMPTYMESSAGE, "Dosya XLSX format�nda olmal�"));

            File file = FileUtil.createTempDirFile("EpledgeFile");
            OutputStream writer = new FileOutputStream(file);
            byte[] fileBytes = (byte[]) inputMap.get("FILE_PATH_CONTENT");	
			writer.write(fileBytes);
            writer.flush();
            
            int currentRow = 1, LAST_ROW_NUM = 0;
            
			FileInputStream fis = new FileInputStream(file); 				
			XSSFWorkbook workBook = new XSSFWorkbook (fis);
			XSSFSheet sheet = workBook.getSheetAt(0);
			LAST_ROW_NUM = sheet.getLastRowNum();				
			
			int COLUMN_COUNT = 5;
			while (currentRow <= LAST_ROW_NUM) {
				Row row = sheet.getRow(currentRow);
				subscriberNo1 = null; subscriberNo2 = null; invoiceNo = null; paymentDate = null;
				paymentAmount = null;
				
				if (row != null) {
					for (int columnIndex = 0; columnIndex < COLUMN_COUNT; columnIndex++) {
						Cell cell = row.getCell(columnIndex, Row.RETURN_BLANK_AS_NULL);
						if (cell == null) {
							// empty cell
						} else {
							//System.out.println(String.valueOf(cell.getColumnIndex()).concat(" ").concat(cell.toString()));
							
							if (columnIndex == 0) {
								if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) { 
									paymentDate = CommonHelper.getDateString(cell.getDateCellValue(), "dd.MM.yyyy");
								} else if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
									paymentDate = cell.getStringCellValue();
								}	
							} else if (columnIndex == 1) {
								if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
									subscriberNo1 = cell.getStringCellValue();
								} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
									subscriberNo1 = String.valueOf(new BigDecimal(cell.getNumericCellValue()).setScale(0));
								}
							} else if (columnIndex == 2) {
								if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
									subscriberNo2 = cell.getStringCellValue();
								} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
									subscriberNo2 = String.valueOf(new BigDecimal(cell.getNumericCellValue()).setScale(0));
								}		                		
							} else if (columnIndex == 3) {
								if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
									invoiceNo = cell.getStringCellValue();
								} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
									invoiceNo = String.valueOf(new BigDecimal(cell.getNumericCellValue()).setScale(0));
								}
							} else if (columnIndex == 4) {
								if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
									paymentAmount = new BigDecimal(cell.getNumericCellValue()).setScale(2, RoundingMode.HALF_UP);
								}	                		
							}
						}
					}
					
					outMap.put(tableName, currentRow-1, "LINE_NUMBER", currentRow);
					outMap.put(tableName, currentRow-1, MapKeys.SUBSCRIBER_NO1, subscriberNo1);
					outMap.put(tableName, currentRow-1, MapKeys.SUBSCRIBER_NO2, subscriberNo2);
					outMap.put(tableName, currentRow-1, MapKeys.INVOICE_NO, invoiceNo);
					outMap.put(tableName, currentRow-1, MapKeys.PAYMENT_AMOUNT, paymentAmount);
					outMap.put(tableName, currentRow-1, MapKeys.PAYMENT_DATE, paymentDate);
				}
				
				currentRow++;
			}
			
		} catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_INSERT_CANCEL_RECORD -> iptal kaydi olusurken hata meydana geldi..");
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
		
	}

	@GraymoundService("CDM_CORPORATE_MANAGEMENT_UPDATE_PAYMENT_RECORD")
	public static GMMap cdmUpdatePaymentRecord(GMMap inputMap) {
		GMMap outMap = new GMMap();
		try {

			String strOid = inputMap.getString("OID");
			String status = inputMap.getString("STATUS", "");
			String paymentStatus = inputMap.getString("PAYMENT_STATUS", "");
			String invoiceAmount = inputMap.getString("INVOICE_AMOUNT", "");
			String corporateCode = inputMap.getString("CORPORATE_CODE", "");
			String invoiceNo = inputMap.getString("INVOICE_NO", "");

			Session session = CommonHelper.getHibernateSession();

			Criteria cr = session.createCriteria(invoicePayment.class).add(Restrictions.eq("oid", strOid));
			invoicePayment invPay = (invoicePayment) cr.uniqueResult();
			if (status != null) {
				if (status.equals("1")) {
					invPay.setStatus(true);
				}
				else if (status.equals("0")) {
					invPay.setStatus(false);
				}
			}
			if (paymentStatus != null) {
				if (paymentStatus.equals("T") || paymentStatus.equals("C") || paymentStatus.equals("I")) {
					invPay.setPaymentStatus(paymentStatus);
				}
			}
			if (invoiceAmount != null) {
				if (!invoiceAmount.isEmpty()) {
					invPay.setInvoiceAmount(new BigDecimal(invoiceAmount.replace(",", ".")));
					invPay.setPaymentAmount(new BigDecimal(invoiceAmount.replace(",", ".")));
				}
			}
			if (corporateCode != null) {
				if (corporateCode.contains("C") || corporateCode.contains("-")) {
					invPay.setCorporateCode(corporateCode);
				}
			}
			if (invoiceNo != null) {
				invPay.setInvoiceNo(invoiceNo);
			}
			session.saveOrUpdate(invPay);
			session.flush();
			outMap.put("RESULT", "OK");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_UPDATE_PAYMENT_RECORD -> �deme kaydi g�ncellenirken hata meydana geldi..");
			outMap.put("RESULT", "ERROR");
		}
		return outMap;

	}

	@GraymoundService("CDM_ACCOUNT_MATCHING_GET_CUSTOMER_ACCOUNT_LIST")
	public static GMMap getCustomerAccountList(GMMap inputMap) {
		GMMap outMap = new GMMap();
		try {
			BigDecimal customerNo = inputMap.getBigDecimal("CUSTOMER_NUMBER");
			StringBuilder sb = new StringBuilder();
			// sb.append("select mh.hesap_no,mh.iban,mh.musteri_no, mh.sube_kodu,mh.modul_tur_kod,mh.urun_tur_kod, ");
			// sb.append(" case when ws.sorguya_acik is null then '0' ");
			// sb.append(" else ws.sorguya_acik end AS sorguya_acik,");
			// sb.append(" ws.kullanici_kodu,ws.sifre from bnspr.muh_hesap mh ");
			// sb.append(" left join CDM.CORPORATE_WS_ACCOUNT_MATCHING ws on mh.iban = ws.iban ");
			// sb.append(" and mh.musteri_no =ws.musteri_no where mh.musteri_no = '");
			// sb.append(customerNo.toString());
			// sb.append("'");
			sb.append(String.format(QueryRepository.CorporationManagementServicesRepository.GET_ACCOUNT_MATCHING_GET_ACCOUNT_LIST, customerNo.toString()));
			String query = sb.toString();
			GMMap returnMap2 = CommonHelper.queryData(query, "RUN_QUERY_RESULT");
			for (int i = 0; i < returnMap2.getSize("RUN_QUERY_RESULT"); i++) {
				outMap.put("ACCOUNT_LIST", i, "HESAP_NO", returnMap2.getString("RUN_QUERY_RESULT", i, "HESAP_NO"));
				outMap.put("ACCOUNT_LIST", i, "IBAN", returnMap2.getString("RUN_QUERY_RESULT", i, "IBAN"));
				outMap.put("ACCOUNT_LIST", i, "MUSTERI_NO", returnMap2.getString("RUN_QUERY_RESULT", i, "MUSTERI_NO"));
				outMap.put("ACCOUNT_LIST", i, "ACIKLAMA", returnMap2.getString("RUN_QUERY_RESULT", i, "ACIKLAMA"));
				outMap.put("ACCOUNT_LIST", i, "SORGUYA_ACIK", returnMap2.getString("RUN_QUERY_RESULT", i, "SORGUYA_ACIK"));
				outMap.put("ACCOUNT_LIST", i, "KULLANICI_KODU", returnMap2.getString("RUN_QUERY_RESULT", i, "KULLANICI_KODU"));
				outMap.put("ACCOUNT_LIST", i, "SUBE_KODU", returnMap2.getString("RUN_QUERY_RESULT", i, "SUBE_KODU"));
				outMap.put("ACCOUNT_LIST", i, "MODUL_TUR_KOD", returnMap2.getString("RUN_QUERY_RESULT", i, "MODUL_TUR_KOD"));
				if (!StringUtil.isEmpty(returnMap2.getString("RUN_QUERY_RESULT", i, "KULLANICI_KODU"))) {
					outMap.put("USER_CODE", returnMap2.getString("RUN_QUERY_RESULT", i, "KULLANICI_KODU"));
					outMap.put("PASSWORD", returnMap2.getString("RUN_QUERY_RESULT", i, "SIFRE"));
				}
			}

			String sqlForWsUser = "select kullanici_kodu from cdm.corporate_ws_users where musteri_No=".concat(customerNo.toString());
			GMMap returnForUser = CommonHelper.queryData(sqlForWsUser, "RETURN_MAP");
			if (returnForUser.getSize("RETURN_MAP") > 0) {
				outMap.put("USER_CODE", returnForUser.getString("RETURN_MAP", 0, "KULLANICI_KODU"));
			}

		}
		catch (Exception e) {
			logger.info("CDM_ACCOUNT_MATCHING_GET_CUSTOMER_ACCOUNT_LIST -> hesap listesi alinirken hata meydana geldi.");
			outMap.put("RESULT", "ERROR");
		}
		return outMap;
	}

	@GraymoundService("CDM_ACCOUNT_MATC_SAVE_ACCOUNT_SETTINGS")
	public static GMMap saveAccountSettings(GMMap inputMap) {
		GMMap outMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			String userCode = inputMap.getString("USER_CODE");
			BigDecimal customerNo = inputMap.getBigDecimal("CUSTOMER_NO");
			StringBuilder sb = new StringBuilder();
			// sb.append("DELETE FROM CDM.corporate_ws_account_matching WHERE MUSTERI_NO='");
			// sb.append(customerNo);
			// sb.append("'");
			sb.append(String.format(QueryRepository.CorporationManagementServicesRepository.DELETE_ACCOUNT_MATCHING, customerNo));
			String query = sb.toString();
			CommonHelper.executeQuery(query);
			int size = inputMap.getSize("ACCOUNT_LIST");
			for (int i = 0; i < size; i++) {
				CorporateWsAccountMatching ws = new CorporateWsAccountMatching();
				ws.setIban(inputMap.getString("ACCOUNT_LIST", i, "IBAN"));
				ws.setKullaniciKodu("");
				ws.setMusteriNo(inputMap.getBigDecimal("ACCOUNT_LIST", i, "MUSTERI_NO"));
				ws.setSifre("");
				ws.setSorguyaAcik(inputMap.getString("ACCOUNT_LIST", i, "SORGUYA_ACIK"));
				session.saveOrUpdate(ws);
				// session.flush();
			}

			// String sqlForWsUser =
			// "select * from cdm.corporate_ws_users where musteri_No=".concat(customerNo.toString());
			String sqlForWsUser = String.format(QueryRepository.CorporationManagementServicesRepository.GET_WS_USER, customerNo.toString());
			GMMap returnForUser = CommonHelper.queryData(sqlForWsUser, "RETURN_MAP");

			if (returnForUser.getSize("RETURN_MAP") == 0) {
				CorporateWsUsers nwsu = new CorporateWsUsers();
				nwsu.setKullaniciKodu(userCode);
				nwsu.setMusteriNo(customerNo);
				session.saveOrUpdate(nwsu);
			}
			else {
				CorporateWsUsers user = null;
				user = (CorporateWsUsers) session.createCriteria(CorporateWsUsers.class).add(Restrictions.eq("musteriNo", customerNo)).uniqueResult();
				user.setKullaniciKodu(userCode);
				user.setMusteriNo(customerNo);
				session.saveOrUpdate(user);
			}

			session.flush();
			outMap.put("RESULT", "S");
			outMap.put("MESSAGE", "G�ncelleme i�lemi ba�ar�l� olarak tamamland�.");
		}
		catch (Exception e) {
			logger.info("CDM_ACCOUNT_MATCHING_GET_CUSTOMER_ACCOUNT_LIST -> hesap listesi alinirken hata meydana geldi.");
			outMap.put("RESULT", "F");
			outMap.put("MESSAGE", "Hata meydana geldi.".concat(CommonHelper.getStringifiedException(e)));
		}
		return outMap;
	}

	@GraymoundService("CDM_CORPORATE_MANAGEMENT_UPDATE_STO_RECORD")
	public static GMMap cdmUpdateStoRecord(GMMap inputMap) {
		GMMap outMap = new GMMap();
		try {

			String strOid = inputMap.getString("OID");
			String status = inputMap.getString("STATUS", "");
			String standingOrderStatus = inputMap.getString("STO_STATUS", "");
			String subscriberNo1 = inputMap.getString("SUBSCRIBER_NO1", "");
			String subscriberNo2 = inputMap.getString("SUBSCRIBER_NO2", "");

			Session session = CommonHelper.getHibernateSession();

			Criteria cr = session.createCriteria(icsStandingOrders.class).add(Restrictions.eq("oid", strOid));
			icsStandingOrders stoRec = (icsStandingOrders) cr.uniqueResult();
			String stoId = stoRec.getStandingOrderOid();
			if (status != null) {
				if (status.equals("1")) {
					stoRec.setStatus(true);
				}
				else if (status.equals("0")) {
					stoRec.setStatus(false);
				}
			}
			if (standingOrderStatus != null) {
				if (standingOrderStatus.equals("1") || standingOrderStatus.equals("3")) {
					stoRec.setStandingOrderStatus(standingOrderStatus);
				}
			}
			if (subscriberNo1 != null) {
				if (!subscriberNo1.isEmpty()) {
					stoRec.setSubscriberNo1(subscriberNo1);
				}
			}
			if (subscriberNo2 != null) {
				if (!subscriberNo2.isEmpty()) {
					stoRec.setSubscriberNo2(subscriberNo2);
				}
			}
			session.saveOrUpdate(stoRec);
			session.flush();
			Criteria crSto = session.createCriteria(StandingOrderMain.class).add(Restrictions.eq("oid", stoId));
			StandingOrderMain stoMain = (StandingOrderMain) crSto.uniqueResult();
			if (status != null) {
				if (status.equals("1")) {
					stoMain.setStatus(true);
				}
				else if (status.equals("0")) {
					stoMain.setStatus(false);
				}
			}
			if (standingOrderStatus != null) {
				if (standingOrderStatus.equals("1") || standingOrderStatus.equals("3")) {
					stoMain.setStandingOrderStatus(standingOrderStatus);
				}
			}
			session.saveOrUpdate(stoMain);
			session.flush();
			outMap.put("RESULT", "OK");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_UPDATE_STO_RECORD -> otomatik �deme talimat kaydi g�ncellenirken hata meydana geldi..");
			outMap.put("RESULT", "ERROR");
		}
		return outMap;

	}

	@GraymoundService("CDM_CORPORATE_MANAGEMENT_CALCULATE_REC_DIFF")
	public static GMMap cdmCalculateReconDiff(GMMap inputMap) {
		GMMap outMap = new GMMap();
		try {
			int diffCount = 0;
			BigDecimal diffTotal = new BigDecimal("0");
			int diffCountCancel = 0;
			BigDecimal diffTotalCancel = new BigDecimal("0");
			int bankCount = inputMap.getInt("RECON_BANK_COUNT");
			int corpCount = inputMap.getInt("RECON_CORP_COUNT");
			BigDecimal bankTotal = new BigDecimal(inputMap.getString("RECON_BANK_TOTAL"));
			BigDecimal corpTotal = new BigDecimal(inputMap.getString("RECON_CORP_TOTAL"));
			if (bankCount > corpCount) {
				diffCount = bankCount - corpCount;
			}
			else {
				diffCount = corpCount - bankCount;
			}
			if (bankTotal.compareTo(corpTotal) == 1) {
				diffTotal = bankTotal.subtract(corpTotal);
			}
			else {
				diffTotal = corpTotal.subtract(bankTotal);
			}
			outMap.put("PAYMENT_COUNT_DIFF", Integer.toString(diffCount));
			outMap.put("PAYMENT_TOTAL_DIFF", diffTotal.toString());

			int bankCountCancel = inputMap.getInt("RECON_BANK_COUNT_CANCEL");
			int corpCountCancel = inputMap.getInt("RECON_CORP_COUNT_CANCEL");
			BigDecimal bankTotalCancel = new BigDecimal(inputMap.getString("RECON_BANK_TOTAL_CANCEL"));
			BigDecimal corpTotalCancel = new BigDecimal(inputMap.getString("RECON_CORP_TOTAL_CANCEL"));

			if (bankCountCancel > corpCountCancel) {
				diffCountCancel = bankCountCancel - corpCountCancel;
			}
			else {
				diffCountCancel = corpCountCancel - bankCountCancel;
			}
			if (bankTotalCancel.compareTo(corpTotalCancel) == 1) {
				diffTotalCancel = bankTotalCancel.subtract(corpTotalCancel);
			}
			else {
				diffTotalCancel = corpTotalCancel.subtract(bankTotalCancel);
			}
			outMap.put("CANCEL_COUNT_DIFF", Integer.toString(diffCountCancel));
			outMap.put("CANCEL_TOTAL_DIFF", diffTotalCancel.toString());

			outMap.put("RESULT", "OK");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_UPDATE_STO_RECORD -> otomatik �deme talimat kaydi g�ncellenirken hata meydana geldi..");
			outMap.put("RESULT", "ERROR");
		}
		return outMap;
	}

	@GraymoundService("CALL_BATCH_SERVICES_FOR_CORPORATE")
	public static GMMap callBatchServicesForCorporate(GMMap inputMap) {
		GMMap output = new GMMap();
		try {
			String serviceName = inputMap.getString("SERVICE_NAME");
			String parameters = inputMap.getString("PARAMETERS");
			boolean runOnBnk = inputMap.getBoolean("RUN_ON_BNK");
			GMMap request = getRequest(parameters);
			GMMap batchRemoteSubmitRequest = new GMMap();
			batchRemoteSubmitRequest.put("INPUT_MAP", request);
			batchRemoteSubmitRequest.put("BATCH_SERVICE_NAME", serviceName);
			if (runOnBnk) {
				CommonHelper.callGraymoundServiceOutsideSession(serviceName, request);
			}
			else {
				CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CDM_EXECUTE_ASYNC_BATCH_SUBMIT", batchRemoteSubmitRequest);
			}
			output.put("MESSAGE", "Servis ba�ar�l� bir �ekilde �al��t�r�lm��t�r.");
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
			output.put("MESSAGE", e.toString());
		}
		return output;
	}

	@GraymoundService("CDM_SEND_ISKI_ONLINE_EKSTRE_DETAIL")
	public static GMMap cdmSendIskiOnlineEkstreDetail(GMMap inputMap) {
		GMMap output = new GMMap();
		try {
			List<String> recipientList = Arrays.asList("nakityonetimioperasyonlariservisi@aktifbank.com.tr");
			List<String> ccList = Arrays.asList("nakityonetimioperasyonlariservisi@aktifbank.com.tr");
			String from = "nakityonetimioperasyonlariservisi@aktifbank.com.tr";
			boolean isHtmlBody = true;
			String subject = "ISKI Online Ekstre Bilgileri";
			String body = "";
			String date = inputMap.getString("DATE");
			String sql = "select SUM(dv_tutar) ALACAK from bnspr.muh_fis_satir where hesap_numara = '616432' and yaratildigi_tarih >= to_date('".concat(date).concat(" 000000', 'yyyyMMdd hh24miss') and yaratildigi_tarih <= to_date('".concat(date).concat(" 235959', 'yyyyMMdd hh24miss') and b_a='A'"));
			GMMap returnSql = CommonHelper.queryData(sql, "RETURN_MAP");
			String alacak = "0";
			if (returnSql.getString("RETURN_MAP", 0, "ALACAK") != null) {
				alacak = returnSql.getString("RETURN_MAP", 0, "ALACAK");
			}

			sql = "select sum(dv_tutar) BORC from bnspr.muh_fis_satir where hesap_numara = '616432' and yaratildigi_tarih >= to_date('".concat(date).concat(" 000000', 'yyyyMMdd hh24miss') and yaratildigi_tarih <= to_date('".concat(date).concat(" 235959', 'yyyyMMdd hh24miss') and b_a='B'"));
			returnSql = CommonHelper.queryData(sql, "RETURN_MAP");
			String borc = "0";
			if (returnSql.getString("RETURN_MAP", 0, "BORC") != null) {
				borc = returnSql.getString("RETURN_MAP", 0, "BORC");
			}

			sql = "SELECT a.kalanbakiye  bakiye,rownum FROM (SELECT balance_after kalanbakiye FROM BNSPR.Muh_Fis_Satir where  hesap_numara = '616432' and yaratildigi_tarih >= to_date('".concat(date).concat(" 000000', 'yyyyMMdd hh24miss') and yaratildigi_tarih <= to_date('".concat(date).concat(" 235959', 'yyyyMMdd hh24miss')) a WHERE rownum = 1"));
			returnSql = CommonHelper.queryData(sql, "RETURN_MAP");

			String bakiye = "0";
			if (returnSql.getString("RETURN_MAP", 0, "BAKIYE") != null) {
				bakiye = returnSql.getString("RETURN_MAP", 0, "BAKIYE");
			}

			body = body.concat("Hesap : ").concat("616432").concat("<br>");
			body = body.concat("Bakiye : ").concat(bakiye).concat("<br>");
			body = body.concat("Borc : ").concat(borc).concat("<br>");
			body = body.concat("Alacak : ").concat(alacak).concat("<br>");
			body = body.concat("-----------------").concat("<br>");

			sql = "SELECT a.kalanbakiye  bakiye,rownum FROM (SELECT fis.muh_tarih islemTarihi,replace(to_char(satir.sonraki_bakiye, 'fm99999990.00999'),'.',',') kalanBakiye FROM bnspr.muh_fis fis, bnspr.muh_fis_satir satir WHERE fis.numara = satir.fis_numara AND satir.hesap_numara = to_char(16742) AND satir.hesap_tur_kodu != 'DK' AND satir.valor_tarihi >= to_date('".concat(date).concat("', 'yyyyMMdd') AND satir.valor_tarihi <= to_date('".concat(date).concat("', 'yyyyMMdd') and fis.tur = 'G' ORDER BY fis.muh_tarih desc, fis.yarat_tar desc, fis.numara desc) a WHERE rownum = 1"));
			returnSql = CommonHelper.queryData(sql, "RETURN_MAP");
			if (returnSql.getString("RETURN_MAP", 0, "BAKIYE") != null) {
				bakiye = returnSql.getString("RETURN_MAP", 0, "BAKIYE");
			}
			else {
				bakiye = "0";
			}

			sql = "select sum(alacakTutar) alacak,sum(borcTutar) borc from (select to_char(fis.muh_tarih) " + "islemTarihi,replace(to_char(sum(decode(satir.b_a, 'A', satir.dv_tutar)) + (select case when sum(amount)" + " is null then 0 else sum(amount) end from bnspr.cs_accounting_tx where target_acc_code = to_char(16742) " + "and status = 'TAMAM' and valor_date >=to_date('".concat(date).concat("' || ' 000000','yyyyMMdd hh24miss') ") + "and valor_date <=to_date('".concat(date).concat("' || ' 235959','yyyyMMdd hh24miss')),'fm99999990.00999'),'.',',') ") + "alacakTutar,replace(to_char(nvl(sum(decode(satir.b_a, 'B', satir.dv_tutar)),0),'fm99999990.00999'),'.',',') " + "borcTutar from bnspr.muh_fis fis, bnspr.muh_fis_satir satir where fis.numara = satir.fis_numara and satir.hesap_numara = to_char(16742) " + "and satir.hesap_tur_kodu != 'DK' and satir.valor_tarihi >= to_date('".concat(date).concat("', 'yyyyMMdd') and satir.valor_tarihi ") + "<= to_date('".concat(date).concat("', 'yyyyMMdd') and fis.tur = 'G' group by fis.muh_tarih, satir.hesap_numara)");
			returnSql = CommonHelper.queryData(sql, "RETURN_MAP");
			if (returnSql.getString("RETURN_MAP", 0, "BORC") != null) {
				borc = returnSql.getString("RETURN_MAP", 0, "BORC");
			}
			else {
				borc = "0";
			}
			if (returnSql.getString("RETURN_MAP", 0, "ALACAK") != null) {
				alacak = returnSql.getString("RETURN_MAP", 0, "ALACAK");
			}
			else {
				alacak = "0";
			}

			body = body.concat("Hesap : ").concat("16742").concat("<br>");
			body = body.concat("Bakiye : ").concat(bakiye).concat("<br>");
			body = body.concat("Borc : ").concat(borc).concat("<br>");
			body = body.concat("Alacak : ").concat(alacak).concat("<br>");
			body = body.concat("-----------------").concat("<br>");

			sql = "SELECT a.kalanbakiye  bakiye,rownum FROM (SELECT fis.muh_tarih islemTarihi,replace(to_char(satir.sonraki_bakiye, 'fm99999990.00999'),'.',',') kalanBakiye FROM bnspr.muh_fis fis, bnspr.muh_fis_satir satir WHERE fis.numara = satir.fis_numara AND satir.hesap_numara = to_char(649652) AND satir.hesap_tur_kodu != 'DK' AND satir.valor_tarihi >= to_date('".concat(date).concat("', 'yyyyMMdd') AND satir.valor_tarihi <= to_date('".concat(date).concat("', 'yyyyMMdd') and fis.tur = 'G' ORDER BY fis.muh_tarih desc, fis.yarat_tar desc, fis.numara desc) a WHERE rownum = 1"));
			returnSql = CommonHelper.queryData(sql, "RETURN_MAP");
			if (returnSql.getString("RETURN_MAP", 0, "BAKIYE") != null)
				bakiye = returnSql.getString("RETURN_MAP", 0, "BAKIYE");

			sql = "select sum(alacakTutar) alacak,sum(borcTutar) borc from (select to_char(fis.muh_tarih) islemTarihi," + "replace(to_char(sum(decode(satir.b_a, 'A', satir.dv_tutar)) + (select case when sum(amount) is null then" + " 0 else sum(amount) end from bnspr.cs_accounting_tx where target_acc_code = to_char(649652)" + " and status = 'TAMAM' and valor_date >= to_date('".concat(date).concat("' || ' 000000','yyyyMMdd hh24miss')") + " and valor_date <= to_date('".concat(date).concat("' || ' 235959', 'yyyyMMdd hh24miss')),'fm99999990.00999'),") + "'.',',') alacakTutar,replace(to_char(nvl(sum(decode(satir.b_a, 'B', satir.dv_tutar)),0)," + " 'fm99999990.00999'), '.',',') borcTutar from bnspr.muh_fis fis, bnspr.muh_fis_satir satir" + " where fis.numara = satir.fis_numara and satir.hesap_numara = to_char(649652) and satir.hesap_tur_kodu" + " != 'DK' and satir.valor_tarihi >= to_date('".concat(date).concat("', 'yyyyMMdd') and satir.valor_tarihi ") + " <= to_date('".concat(date).concat("', 'yyyyMMdd') and fis.tur = 'G' group by fis.muh_tarih, satir.hesap_numara)");
			returnSql = CommonHelper.queryData(sql, "RETURN_MAP");
			if (returnSql.getString("RETURN_MAP", 0, "BORC") != null) {
				borc = returnSql.getString("RETURN_MAP", 0, "BORC");
			}
			else {
				borc = "0";
			}
			if (returnSql.getString("RETURN_MAP", 0, "ALACAK") != null) {
				alacak = returnSql.getString("RETURN_MAP", 0, "ALACAK");
			}
			else {
				alacak = "0";
			}

			body = body.concat("Hesap : ").concat("649652").concat("<br>");
			body = body.concat("Bakiye : ").concat(bakiye).concat("<br>");
			body = body.concat("Borc : ").concat(borc).concat("<br>");
			body = body.concat("Alacak : ").concat(alacak).concat("<br>");
			body = body.concat("-----------------").concat("<br>");

			CommonHelper.sendMail(recipientList, ccList, from, isHtmlBody, subject, body);

		}
		catch (Exception e) {
			logger.error(e.getMessage());
		}
		return output;
	}

	private static GMMap getRequest(String parameters) {
		GMMap request = new GMMap();
		if (!StringUtil.isEmpty(parameters)) {
			List<String> keyValuePairs = Arrays.asList(parameters.split("#"));
			for (String pair : keyValuePairs) {
				String[] keyValue = pair.split("=");
				request.put(keyValue[0], keyValue[1]);
			}
		}
		return request;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_INSERT_NEW_CORP_SERVICE")
	public static GMMap insertCorporateService(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			boolean status = true;
			String oid = iMap.getString("OID");
			String corporateCode = iMap.getString("CORPORATE_CODE");

			String gmServiceName = iMap.getString("GM_SERVICE_NAME");
			String isSafService = iMap.getString("IS_SAF_SERVICE");
			if (iMap.getString("STATUS").equals("1")) {
				status = true;
			}
			else {
				status = false;
			}
			String webServiceName = iMap.getString("WEB_SERVICE_NAME");

			Session session = CommonHelper.getHibernateSession();
			CorporateServices corporateService;
			if ("".equals(oid)) {
				corporateService = new CorporateServices();
				corporateService.setCreateDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
				corporateService.setCreateUser(CommonHelper.getCurrentUser());
			}
			else {
				Criteria cr = session.createCriteria(CorporateServices.class).add(Restrictions.eq("oid", oid));
				corporateService = (CorporateServices) cr.uniqueResult();
				corporateService.setUpdateDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
				corporateService.setUpdateUser(CommonHelper.getCurrentUser());
			}
			corporateService.setCorporateCode(corporateCode);
			corporateService.setGmServiceName(gmServiceName);
			corporateService.setIsSafService(isSafService);
			corporateService.setStatus(status);
			corporateService.setWebServiceName(webServiceName);

			session.saveOrUpdate(corporateService);
			session.flush();
			outMap.put("RESULT_MESSAGE", "��lem Ba�ar�l� Olarak Tamamland�.");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_INSERT_NEW_CORP_SERVICE -> servis kaydi olusurken hata meydana geldi..");
			outMap.put("RESULT_MESSAGE", "Hata Meydana Geldi! (".concat(e.getMessage()).concat(")"));
		}
		return outMap;

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_DELETE_CORP_SERVICE")
	public static GMMap deleteCorporateService(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			String oid = iMap.getString("OID");
			Session session = CommonHelper.getHibernateSession();
			Criteria cr = session.createCriteria(CorporateServices.class).add(Restrictions.eq("oid", oid));
			CorporateServices corporateService = (CorporateServices) cr.uniqueResult();
			session.delete(corporateService);
			session.flush();
			outMap.put("RESULT_MESSAGE", "Servis kayd� silindi.");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_DELETE_CORP_SERVICE -> servis kaydi silinirken hata meydana geldi..");
			outMap.put("RESULT_MESSAGE", "Hata Meydana Geldi! (".concat(e.getMessage()).concat(")"));
		}
		return outMap;

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_DELETE_WEB_SERVICE")
	public static GMMap deleteWebService(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			String oid = iMap.getString("OID");
			Session session = CommonHelper.getHibernateSession();
			Criteria cr = session.createCriteria(WebServices.class).add(Restrictions.eq("oid", oid));
			WebServices webService = (WebServices) cr.uniqueResult();
			session.delete(webService);
			session.flush();
			outMap.put("RESULT_MESSAGE", "Servis kayd� silindi.");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_DELETE_WEB_SERVICE -> servis kaydi silinirken hata meydana geldi..");
			outMap.put("RESULT_MESSAGE", "Hata Meydana Geldi! (".concat(e.getMessage()).concat(")"));
		}
		return outMap;

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_INSERT_NEW_WEB_SERVICE")
	public static GMMap insertWebService(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {

			String oid = iMap.getString("OID");
			String corporateCode = iMap.getString("CORPORATE_CODE");
			String parameter1 = iMap.getString("PARAMETER1");
			String parameter2 = iMap.getString("PARAMETER2");
			String parameter3 = iMap.getString("PARAMETER3");
			String parameter4 = iMap.getString("PARAMETER4");
			String parameter5 = iMap.getString("PARAMETER5");
			String parameter6 = iMap.getString("PARAMETER6");
			String serviceName = iMap.getString("SERVICE_NAME");
			boolean status = true;
			if (iMap.getString("STATUS").equals("1")) {
				status = true;
			}
			else {
				status = false;
			}
			String wsEndPoint = iMap.getString("WS_END_POINT");
			String wsPassword = iMap.getString("WS_PASSWORD");
			BigDecimal wsTimeOutDuration = new BigDecimal("30");
			String wsUser = iMap.getString("WS_USER");
			Session session = CommonHelper.getHibernateSession();
			WebServices webService;
			if ("".equals(oid)) {
				webService = new WebServices();
				webService.setCreateDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
				webService.setCreateUser(CommonHelper.getCurrentUser());
			}
			else {
				Criteria cr = session.createCriteria(WebServices.class).add(Restrictions.eq("oid", oid));
				webService = (WebServices) cr.uniqueResult();
				webService.setUpdateDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
				webService.setUpdateUser(CommonHelper.getCurrentUser());
			}
			webService.setCorporateCode(corporateCode);
			webService.setParameter1(parameter1);
			webService.setParameter2(parameter2);
			webService.setParameter3(parameter3);
			webService.setParameter4(parameter4);
			webService.setParameter5(parameter5);
			webService.setParameter6(parameter6);
			webService.setServiceName(serviceName);
			webService.setStatus(status);
			webService.setWsEndPoint(wsEndPoint);
			webService.setWsPassword(wsPassword);
			webService.setWsTimeOutDuration(wsTimeOutDuration);
			webService.setWsUser(wsUser);
			session.saveOrUpdate(webService);
			session.flush();
			outMap.put("RESULT_MESSAGE", "��lem Ba�ar�l� Olarak Tamamland�.");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_INSERT_NEW_WEB_SERVICE -> servis kaydi olusurken hata meydana geldi..");
			outMap.put("RESULT_MESSAGE", "Hata Meydana Geldi! (".concat(e.getMessage()).concat(")"));
		}
		return outMap;

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_ADD_SERVICE_MESSAGE")
	public static GMMap insertNewServiceMessage(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String errorCode = iMap.getString(MapKeys.ERROR_CODE);
			String explanation = iMap.getString(MapKeys.ERROR_DESC);
			String forAllServices = "1";
			String returnCode = iMap.getString("RETURN_CODE");
			String returnCodeDesc = iMap.getString("RETURN_DESC");

			Session session = CommonHelper.getHibernateSession();
			ServiceResponseCodeMapping mapping = new ServiceResponseCodeMapping();
			mapping.setCorporateCode(corporateCode);
			mapping.setCreateDate(CommonHelper.getDateString(new Date(), "yyyyMMddHHmmss"));
			mapping.setCreateUser(CommonHelper.getCurrentUser());
			mapping.setErrorCode(errorCode);
			mapping.setExplanation(explanation);
			mapping.setForAllServices(forAllServices);
			mapping.setReturnCode(returnCode);
			mapping.setReturnCodeDesc(returnCodeDesc);
			mapping.setStatus(true);
			session.saveOrUpdate(mapping);
			outMap.put("RESULT_MESSAGE", "��lem Ba�ar�l� Olarak Tamamland�.");
		}
		catch (Exception e) {
			logger.info("CDM_CORPORATE_MANAGEMENT_ADD_SERVICE_MESSAGE -> servis kaydi olusurken hata meydana geldi..");
			outMap.put("RESULT_MESSAGE", "Hata Meydana Geldi! (".concat(e.getMessage()).concat(")"));
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_DELETE_SERVICE_MESSAGE")
	public static GMMap deleteServiceMessage(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String strOid = inputMap.getString("OID");
		try {
			Criteria cr = session.createCriteria(ServiceResponseCodeMapping.class).add(Restrictions.eq("oid", strOid));
			ServiceResponseCodeMapping srcm = (ServiceResponseCodeMapping) cr.uniqueResult();
			srcm.setStatus(false);
			session.saveOrUpdate(srcm);
			session.flush();
			returnMap.put("ERROR", "FALSE");
		}
		catch (Exception e) {
			returnMap.put("ERROR", "TRUE");
			logger.info("CDM_CORPORATE_MANAGEMENT_DELETE_SERVICE_MESSAGE -> an error occured with for input -> ".concat(inputMap.toString()));
			logger.info("CDM_CORPORATE_MANAGEMENT_DELETE_SERVICE_MESSAGE -> an error occured with explamnation -> ".concat(CommonHelper.getStringifiedException(e)));
		}
		return returnMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CORPORATE_MANAGEMENT_SAVE_WITH_SAME_CORPORATE_INFOS")
	public static GMMap saveWithSameCorporateInfos(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		String corporateCode = inputMap.getString(MapKeys.CORPORATE_CODE);
		String corporateCodeDesired = inputMap.getString(MapKeys.DESIRED_CORPORATE_CODE);

		Criteria criteriaWS = session.createCriteria(WebServices.class).add(Restrictions.eq("corporateCode", corporateCodeDesired));

		@SuppressWarnings("unchecked")
		List<WebServices> webServiceList = (List<WebServices>) criteriaWS.list();
		int row = 0;
		for (WebServices webServices : webServiceList) {
			WebServices newWebService= new WebServices();
		
			newWebService.setCreateDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
			newWebService.setCreateUser(CommonHelper.getCurrentUser());
	
			newWebService.setCorporateCode(corporateCode);
			newWebService.setParameter1(webServices.getParameter1());
			newWebService.setParameter2(webServices.getParameter2());
			newWebService.setParameter3(webServices.getParameter3());
			newWebService.setParameter4(webServices.getParameter4());
			newWebService.setParameter5(webServices.getParameter5());
			newWebService.setParameter6(webServices.getParameter6());
			newWebService.setServiceName(webServices.getServiceName());
			newWebService.setStatus(webServices.isStatus());
			newWebService.setWsEndPoint(webServices.getWsEndPoint());
			newWebService.setWsPassword(webServices.getWsPassword());
			newWebService.setWsTimeOutDuration(webServices.getWsTimeOutDuration());
			newWebService.setWsUser(webServices.getWsUser());
			session.saveOrUpdate(newWebService);
			session.flush();

		}

		Criteria criteriaCs = session.createCriteria(CorporateServices.class).add(Restrictions.eq("corporateCode", corporateCodeDesired));

		@SuppressWarnings("unchecked")
		List<CorporateServices> corporateServiceList = (List<CorporateServices>) criteriaCs.list();
		row = 0;
		for (CorporateServices corporateServices : corporateServiceList) {
			CorporateServices newCorporateServices = new CorporateServices();
			newCorporateServices.setCreateDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
			newCorporateServices.setCreateUser(CommonHelper.getCurrentUser());
			newCorporateServices.setCorporateCode(corporateCode);
			newCorporateServices.setGmServiceName(corporateServices.getGmServiceName());
			newCorporateServices.setIsSafService(corporateServices.getIsSafService());
			newCorporateServices.setStatus(corporateServices.isStatus());
			newCorporateServices.setWebServiceName(corporateServices.getWebServiceName());

			session.saveOrUpdate(newCorporateServices);
			session.flush();
		}

	
		Criteria criteriaResponseMap = session.createCriteria(ServiceResponseCodeMapping.class).add(Restrictions.eq("status", true));
		criteriaResponseMap.add(Restrictions.eq("corporateCode", corporateCodeDesired));
		List<ServiceResponseCodeMapping> srcmList = (List<ServiceResponseCodeMapping>) criteriaResponseMap.list();
		for (ServiceResponseCodeMapping srcm : srcmList) {
			ServiceResponseCodeMapping responseCodeMappingNew = new ServiceResponseCodeMapping();
			responseCodeMappingNew.setCorporateCode(corporateCode);
			responseCodeMappingNew.setCreateDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
			responseCodeMappingNew.setCreateUser(CommonHelper.getCurrentUser());
			responseCodeMappingNew.setErrorCode(srcm.getErrorCode());
			responseCodeMappingNew.setExplanation(srcm.getExplanation());
			responseCodeMappingNew.setForAllServices(srcm.getForAllServices());
			responseCodeMappingNew.setReturnCode(srcm.getReturnCode());
			responseCodeMappingNew.setReturnCodeDesc(srcm.getReturnCodeDesc());
			responseCodeMappingNew.setStatus(srcm.isStatus());
			session.saveOrUpdate(responseCodeMappingNew);
			session.flush();
		}
		return returnMap;
	}

}
