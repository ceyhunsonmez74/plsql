package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.BedasCampaignReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationResubmitType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.bedas.campaign.BedasCampaignClient;
import tr.com.aktifbank.integration.bedas.campaign.ServiceMessage;
import tr.com.aktifbank.integration.uedasRest.UedasRestClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.uedas.OdemeIptalEtResponse;
import tr.com.uedas.OdemeYapResponse;
import campaign.entity.AboneBilgiGetirResult;
import campaign.entity.AboneBorcluTahakkuklarDetayliResult;
import campaign.entity.AboneBorcluTahakkuklarDetayliSahisliResult;
import campaign.entity.AboneBorcluTahakkuklarResult;
import campaign.entity.AboneEksikBilgiKaydetResult;
import campaign.entity.AboneGetirBorcluSahislarResult;
import campaign.entity.AboneTaksitBorclariResult;
import campaign.entity.AboneTaksitBorclariSahisliResult;
import campaign.entity.AboneTalimatIptalResultBoth;
import campaign.entity.AboneTalimatlandirResultBoth;
import campaign.entity.GetTalimatliAboneBorclarBySonOdemeTarihiResult;
import campaign.entity.KampanyaAboneSatisOnayDurumGetirResult;
import campaign.entity.KampanyaAboneSatisUygunlukGetirResult;
import campaign.entity.KampanyaBilgisiniKaydetResult;
import campaign.entity.KampanyaDurumDetayGetirResult;
import campaign.entity.KampanyaDurumGetirResult;
import campaign.entity.KampanyaLogBilgisiniKaydetResult;
import campaign.entity.MutabakatYapResult;
import campaign.entity.OnlineTahsilEtV2YeniResult;
import campaign.entity.TahsilatIptalEtYeniResult;
import campaign.entity.TahsilatMutabakatDetayVersion2Result;
import campaign.entity.TahsilatMutabakatProtokoluBankaToplamiResult;
import campaign.entity.TaksitBorcuTahsilEtYeniResult;
import campaign.entity.TaksitDetay;
import campaign.entity.TalimatMutabakatDetayResult;
import campaign.entity.TalimatMutabakatProtokoluBankaToplamiResult;
import campaign.entity.TalimatliAboneOnlineTahsilEtYeniResult;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class BedasCampaignServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(BedasCampaignServices.class);
	private static final String ERROR_STATUS = "Error";
	private static final String BRANCH_CODE = "555";
	private static final String DEFAULT_USER_CODE = "U0000";
	private static final String DEFAULT_AGENT_CODE = "A0000";
	private static final String DEFAULT_CHANNEL_CODE = "C0000";
	private static final String OFFER = "OFFER";
	private static final String PERCENTAGE_DISCOUNT = "PERCENTAGE_DISCOUNT";
	private static final String CONSUMER_NAME = "CONSUMER_NAME";
	private static final String AVARAGE_CONSUMPTION = "AVARAGE_CONSUMPTION";
	private static final String AVARAGE_CONSUMPTION_OFFER = "AVARAGE_CONSUMPTION_OFFER";
	private static final String OFFERED_BENEFIT = "OFFE	RED_BENEFIT";
	private static final String ELIGIBLE_CONSUMER_CODE = "1";

	@SuppressWarnings("unused")
	@GraymoundService("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String errorCode = "";
		String errorMessage = "";
		int counter = 0;
		String p_sDonem = "";
		String offerText = "";
//		boolean isEligibleConsumer = false;
		String customerPersonalNumber = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String p_sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
		String p_sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
		String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
		int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String channelCode = CommonHelper.getChannelId();
		String p_sKanalKodu =channelCode;
		String userCode = DEFAULT_USER_CODE;
		String agentCode = DEFAULT_AGENT_CODE;
		// StringBuilder sb=new StringBuilder();
		if (!StringUtil.isEmpty(iMap.getString(MapKeys.AGENT_CODE))) {
			agentCode = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);
		}
		if (!StringUtil.isEmpty(iMap.getString(MapKeys.USER_CODE))) {
			userCode = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
		}
		
		String p_sBankaKullaniciKodu=userCode;
		String p_sBayiKodu = agentCode;
		ServiceMessage serviceMessage = new ServiceMessage();
		String aboneKodu = "ABONE_KODU=";
		ArrayList<AboneBorcluTahakkuklarDetayliResult> debtList = null;
		ArrayList<AboneBorcluTahakkuklarDetayliSahisliResult> debtListPasif = null;
		ArrayList<AboneGetirBorcluSahislarResult> customerList = null;
		boolean customerNotFound = false;
		boolean hasActiveCustomer = false;

		try {
			String isCampaignChannel = CommonHelper.getValueOfParameter("BEDAS_CAMPAIGN_CHANNEL_MAPPING", channelCode);
			outMap.put(MapKeys.IS_CAMPAIGN_CHANNEL, isCampaignChannel);
			logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY is called and isCampaignChannel true with channel value of ".concat(channelCode));
			customerList = BedasCampaignClient.aboneGetirBorcluSahislar(p_sIsletmeKodu, p_sAboneNo, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage,timeOut);
			insertWsCallLog(iMap, serviceMessage);
			try {
				if (null == customerList.get(0).getSatisDurumu()) {
					hasActiveCustomer = false;
				}
				else {
					hasActiveCustomer = true;
				}
				
				if (null == customerList.get(0).getEksikBilgiVarMi()) {
					hasActiveCustomer = false;
				}
				else {
					hasActiveCustomer = true;
					outMap.put(MapKeys.MISSING_INFORMATION, customerList.get(0).getEksikBilgiVarMi());
				}
			}
			catch (Exception e) {
				logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY -> aktif musteri kontrolunde hata aldi -> ".concat(e.toString()));
			}
			if ("EVET".equals(isCampaignChannel)) {
				iMap.put("REQUEST_XML_ABONE_GETIR_BORCLU_SAHISLAR", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML_ABONE_GETIR_BORCLU_SAHISLAR", serviceMessage.getResponse());
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				if (customerList.size() > 0) {
					if (customerList == null) {
						responseCode = "660";
						errorMessage = "Bedas abone sorgulamada hata meydana geldi.";
						logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY abonegetirborclusahislar method is returned null response...");
					}
					else if (ERROR_STATUS.equalsIgnoreCase(customerList.get(0).getT())) {
						responseCode = "660";
						errorMessage = customerList.get(0).getMsg();
						logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY abonegetirborclusahislar returned error with explanation = ".concat(errorMessage));
					}
//					else {
//						try {
//							aboneKodu = aboneKodu.concat(customerList.get(0).getAboneKodu());
//						}
//						catch (Exception e) {
//							logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY -> abone kodu alinirken hata meydana geldi...".concat(e.toString()));
//						}
//						if (ELIGIBLE_CONSUMER_CODE.equals(customerList.get(0).getSatisDurumu())) {
//							logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY find an eligible consumer...");
//							outMap.put(MapKeys.ELIGIBLE_CONSUMER, "EVET");
//							customerPersonalNumber = customerList.get(0).getAboneSahisKodu();
//							if ("EVET".equals(customerList.get(0).getEksikBilgiVarMi())) {
//								outMap.put(MapKeys.MISSING_INFORMATION, "EVET");
//								logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY returned a consumer with missing information");
//							}
//							else {
//								outMap.put(MapKeys.MISSING_INFORMATION, "HAYIR");
//								logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY returned a consumer with complete information");
//							}
//							isEligibleConsumer = true;
//						}
//						else {
//							outMap.put(MapKeys.ELIGIBLE_CONSUMER, "HAYIR");
//						}
//					}
				}
				else {
					responseCode = "660";
					errorMessage = "Bedas abone kayd� bulunamad�.";
					logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY Bedas abone kayd� bulunamad�.");
//					isEligibleConsumer = false;
					customerNotFound = true;
				}
			}
//			if (isEligibleConsumer) {
//				logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY isEligibleConsumer = true ");
//				offerText = CommonHelper.getValueOfParameter("BEDAS_CAMPAIGN_OFFER_TEXT", OFFER);
//				if ("".equals(customerList.get(0).getAdSoyad())) {
//					offerText = offerText.replace(CONSUMER_NAME, customerList.get(0).getSirketAdi());
//				}
//				else {
//					offerText = offerText.replace(CONSUMER_NAME, customerList.get(0).getAdSoyad());
//				}
//				offerText = offerText.replace(AVARAGE_CONSUMPTION_OFFER, CommonHelper.trimEnd(customerList.get(0).getIndirimliFaturaTutari(), '0'));
//				offerText = offerText.replace(AVARAGE_CONSUMPTION, CommonHelper.trimEnd(customerList.get(0).getOrtalamaFaturaTutari(), '0'));
//				offerText = offerText.replace(OFFERED_BENEFIT, CommonHelper.trimEnd(customerList.get(0).getYillikKazanc(), '0'));
//				BigDecimal oran = new BigDecimal(CommonHelper.trimEnd(customerList.get(0).getSatisOrani().toString().replace(",", "."), '0'));
//				oran = oran.multiply(new BigDecimal(100));
//				String oranStr = CommonHelper.trimEnd(oran.toString(), '0');
//				if (oranStr.endsWith(".")) {
//					oranStr = oranStr.replace(".", "");
//				}
//				offerText = offerText.replace(PERCENTAGE_DISCOUNT, oranStr);
//				logger.info("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY returned offer text : ".concat(offerText));
//			}
			if (!customerNotFound) {
				if (!"EVET".equals(isCampaignChannel)) {
					outMap.put(MapKeys.OFFER, offerText);
					outMap.put(MapKeys.CUSTOMER_PERSONAL_NUMBER, customerPersonalNumber);
					debtList = BedasCampaignClient.borcSorgulaDetayli(p_sIsletmeKodu, p_sAboneNo, p_sDonem, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage,timeOut);
					insertWsCallLog(iMap, serviceMessage);
					iMap.put("REQUEST_XML_FOR_DEBT_INQ", serviceMessage.getRequest());
					outMap.put("RESPONSE_XML_FOR_DEBT_INQ", serviceMessage.getResponse());
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					if (debtList == null) {
						responseCode = "660";
						errorMessage = "Beda� bor� sorgulamada kurum servis cagriminda hata meydana geldi.";
					}
					else if (debtList.size() == 1 && ERROR_STATUS.equalsIgnoreCase(debtList.get(0).getT())) {
						responseCode = "660";
						errorMessage = debtList.get(0).getMsg();
					}
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					int installmentArrayNumber = 0;
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						for (AboneBorcluTahakkuklarDetayliResult borc : debtList) {
							if (!"TaksitBorcu".equals(borc.getDetay())) {
//								if (!isCollectedInvoiceNoCheck(borc.getThkNo(), borc.getIslKod(), corporateCode)) {
									String termYear = borc.getDnm().split("/")[0];
									String termMonth = borc.getDnm().split("/")[1];
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_sIsletmeKodu);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_sAboneNo);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getThkNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getBorc());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSyd());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonTrh(), "dd.MM.yyyy"));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getBorc());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getIslKod());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER16, borc.getTedarikciID());

									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, "#".concat(borc.getDetay()).concat("TEDARIKCIID=".concat(borc.getTedarikciID()).concat("#")).concat("ANAPARA=").concat(borc.getAnaPara()).concat("#").concat("GZ=").concat(borc.getGZ()).concat("#").concat("GZKDV=").concat(borc.getGZKDV()).concat("#"));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, aboneKodu);
									outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
//								}
							}
							else {
								ArrayList<AboneTaksitBorclariResult> taksitBorclari = BedasCampaignClient.aboneTaksitBorcSorgula(p_sIsletmeKodu, p_sAboneNo, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage,timeOut);
								insertWsCallLog(iMap, serviceMessage);
								ArrayList<TaksitDetay> detay = taksitBorclari.get(installmentArrayNumber).getTaksitDetaylari();
								installmentArrayNumber++;
								iMap.put("REQUEST_XML_FOR_INSTALLMENT_PAYMENT_REQ_".concat(Integer.toBinaryString(installmentArrayNumber)), serviceMessage.getRequest());
								iMap.put("REQUEST_XML_FOR_INSTALLMENT_PAYMENT_RES_".concat(Integer.toBinaryString(installmentArrayNumber)), serviceMessage.getResponse());
								for (int i = 0; i < detay.size(); i++) {
//									if (!isCollectedInvoiceNoCheckForInstallment(borc.getThkNo(), Integer.parseInt(detay.get(i).getNo()), corporateCode)) {
										String termYear = borc.getDnm().split("/")[0];
										String termMonth = borc.getDnm().split("/")[1];
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_sIsletmeKodu);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_sAboneNo);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getThkNo());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, detay.get(i).getBorc());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSyd());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonTrh(), "dd.MM.yyyy"));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, detay.get(i).getBorc());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, detay.get(i).getNo());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getIslKod());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, "Taksit No:".concat(detay.get(i).getNo()));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, aboneKodu);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER16, borc.getTedarikciID());
										outMap.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", "Taksit No:".concat(detay.get(i).getNo()));
										outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
										outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
										counter++;
//									}
								}
							}
						}
					}

//					if ("EVET".equals(isCampaignChannel) && counter == 0 && isEligibleConsumer) {
//						Calendar now = GregorianCalendar.getInstance();
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_sIsletmeKodu);
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_sAboneNo);
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, "");
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, "0");
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, "");
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(Integer.toString(now.get(Calendar.DATE)).concat(".").concat(Integer.toString(now.get(Calendar.MONTH) + 1).concat(".").concat(Integer.toString(now.get(Calendar.YEAR)))), "dd.MM.yyyy"));
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, "");
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, "");
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, "0");
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
//						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, "");
//						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
//						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
//						counter++;
//					}
				}
//				int customerStartNumber = 1;
//				int customerControlNumber = customerList.size();
//				if (!hasActiveCustomer) {
//					customerStartNumber = 0;
//					customerControlNumber = 2;
//				}
				if ("EVET".equals(isCampaignChannel)) {
					if (customerList != null) {
//						if (customerControlNumber > 1) {
//							for (int z = customerStartNumber; z < customerList.size(); z++) {
								for (int z = 0; z < customerList.size(); z++) {

								debtListPasif = BedasCampaignClient.aboneSahisliBorcSorgulaDetayli(Integer.parseInt(customerList.get(z).getAboneSahisKodu()), p_sDonem, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url,p_sKanalKodu, p_sBankaKullaniciKodu, p_sBayiKodu, serviceMessage,timeOut);
								insertWsCallLog(iMap, serviceMessage);
								iMap.put("REQUEST_XML_FOR_DEBT_INQ_NKOLAY_".concat(Integer.toString(z)), serviceMessage.getRequest());
								outMap.put("RESPONSE_XML_FOR_DEBT_INQ_NKOLAY_".concat(Integer.toString(z)), serviceMessage.getResponse());
								for (AboneBorcluTahakkuklarDetayliSahisliResult borc : debtListPasif) {
//									if (!isCollectedInvoiceNoCheck(borc.getThkNo(), borc.getIslKod(), corporateCode)) {
										String termYear = borc.getDnm().split("/")[0];
										String termMonth = borc.getDnm().split("/")[1];
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_sIsletmeKodu);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_sAboneNo);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getThkNo());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getBorc());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSyd());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonTrh(), "dd.MM.yyyy"));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getBorc());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "0");
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getIslKod());
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, "#PasifAbone=EVET#Taksit No:0".concat(borc.getDetay()).concat("TEDARIKCIID=".concat(borc.getTedarikciID()).concat("#")));
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, aboneKodu);
										outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER16, borc.getTedarikciID());
										outMap.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", z+1+ ". Abone Borcu");
										outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
										outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
										counter++;
//									}
								}
								int installmentArrayNumberPasif = 0;
								ArrayList<AboneTaksitBorclariSahisliResult> debtListPasifTaksitli = BedasCampaignClient.aboneTaksitBorcSorgulaSahisli(Integer.parseInt(customerList.get(z).getAboneSahisKodu()), p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage,timeOut);
								insertWsCallLog(iMap, serviceMessage);
								iMap.put("REQUEST_XML_FOR_DEBT_INQ_TAKSIT_NKOLAY_".concat(Integer.toString(z)), serviceMessage.getRequest());
								outMap.put("RESPONSE_XML_FOR_DEBT_INQ_TAKSIT_NKOLAY_".concat(Integer.toString(z)), serviceMessage.getResponse());
								for (AboneTaksitBorclariSahisliResult borc : debtListPasifTaksitli) {
									ArrayList<TaksitDetay> detay = debtListPasifTaksitli.get(installmentArrayNumberPasif).getTaksitDetaylari();
									installmentArrayNumberPasif++;
									for (int i = 0; i < detay.size(); i++) {
//										if (!isCollectedInvoiceNoCheckForInstallment(borc.getThkNo(), Integer.parseInt(detay.get(i).getNo()), corporateCode)) {
											String termYear = borc.getDnm().split("/")[0];
											String termMonth = borc.getDnm().split("/")[1];
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_sIsletmeKodu);
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_sAboneNo);
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getThkNo());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, detay.get(i).getBorc());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSyd());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(detay.get(i).getSonTrh(), "dd.MM.yyyy"));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, detay.get(i).getBorc());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, detay.get(i).getNo());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getIslKod());
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, "#PasifAbone=EVET#Taksit No:".concat(detay.get(i).getNo()));
											outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, aboneKodu);
											outMap.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", z+1+ ". Abone Taksit Borcu");
											outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
											outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
											counter++;
//										}
									}
								}
							}
//						}
					}
				}
			}
			else {
				logger.error("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY -> an error occured - customer not found exception");
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				outMap.put(MapKeys.ERROR_CODE, responseCode);
				outMap.put(MapKeys.ERROR_DESC, errorMessage.concat(" (Beda� ile irtibat kurun!)"));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage.concat(" (Beda� ile irtibat kurun!)"));
			}
		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_INVOICE_DEBT_INQUIRY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		finally {
 			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	private static void insertWsCallLog(GMMap iMap, ServiceMessage serviceMessage) {
		try {
			iMap.put(MapKeys.DURATION, serviceMessage.getParameter1());
			iMap.put(MapKeys.START_TIME, serviceMessage.getParameter2());
			iMap.put(MapKeys.END_TIME, serviceMessage.getParameter3());
			GMServiceExecuter.executeAsync("ICS_INSERT_ONLINE_WS_CALL_LOG", iMap);
		}
		catch (Exception e) {
			logger.error("ICS_INSERT_ONLINE_WS_CALL_LOG hata ald�.".concat(iMap.toString()));
		}

	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_DO_INVOICE_COLLECTION");
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		String errorMessage = "";
		try {
			boolean installmentPayment = false;
			boolean collected = false;
			String updatedThsNo = "";
			String errorCode = "";
			String hataKodu = "";
			String hataMesaji = "";
			String channelCode = CommonHelper.getChannelId();
			String userCode = DEFAULT_USER_CODE;
			String agentCode = DEFAULT_AGENT_CODE;
			String installmentNo = iMap.getString(MapKeys.INSTALLMENT_NO);
			BigDecimal p_sTutar = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String amount = iMap.getString(MapKeys.PAYMENT_AMOUNT);


			// StringBuilder sb=new StringBuilder();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.AGENT_CODE))) {
				agentCode = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);
			}
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.USER_CODE))) {
				userCode = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
			}
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			

			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			int p_nIsletmeKodu = iMap.getInt(MapKeys.PARAMETER1);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			String endPoint = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			}
			else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			ServiceMessage serviceMessage = new ServiceMessage();
			OnlineTahsilEtV2YeniResult response = null;
			TaksitBorcuTahsilEtYeniResult responseTaksitliOdeme = null;
			TalimatliAboneOnlineTahsilEtYeniResult responseTalimatliOdeme = null;
			if (isStandingOrderCollection) {
				String p_sSonOdemeTarihiForCompare = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
				logger.info("ICS_BEDAS_CAMPAIGN_DO_INVOICE_COLLECTION is called for standing order collection..");
				String p_sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
				String p_sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
				String p_sDonem = "";
//				ArrayList<AboneBorcluTahakkuklarResult> responseStandingOrder = BedasCampaignClient.borcSorgula(p_sIsletmeKodu, p_sAboneNo, p_sDonem, p_sBankaKodu, sLoginName, sPassword, sLoginName, sPassword, endPoint, serviceMessage,timeOut);
//				iMap.put("REQUEST_XML_FOR_DEBT_INQUERY", serviceMessage.getRequest());
//				outMap.put("RESPONSE_XML_FOR_DEBT_INQUERY", serviceMessage.getResponse());
//				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//				if (responseStandingOrder == null) {
//					responseCode = "660";
//					errorMessage = "Otomatik �deme �ncesi bor� sorgulamada kurum web servisinde hata meydana geldi.";
//				}
//				else if (responseStandingOrder.size() == 1 && ERROR_STATUS.equalsIgnoreCase(responseStandingOrder.get(0).getT())) {
//					responseCode = "660";
//					errorMessage = responseStandingOrder.get(0).getMsg();
//				}
				if (StringUtil.isEmpty(channelCode)) {
					responseCode = "660";
					errorMessage = "Kanal bilgisi bo� geldi�i i�in �deme yap�lamaz!";
				}
//				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
//				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
//				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
//				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
//					for (AboneBorcluTahakkuklarResult borc : responseStandingOrder) {
//						if (borc.getSonTrh().equals(p_sSonOdemeTarihiForCompare)) {

						logger.info("ICS_BEDAS_CAMPAIGN_DO_INVOICE_COLLECTION is called and find invoice to pay...");
						responseTalimatliOdeme = BedasCampaignClient.talimatliAboneOnlineTahsilEt(p_sBankaKodu, sLoginName, sPassword, p_nIsletmeKodu, tahakkukNo, p_sIsletmeKodu, p_sAboneNo, tahsilatTarihi, BRANCH_CODE, p_sIslemReferansNo, amount, channelCode, userCode, agentCode, sLoginName, sPassword, endPoint, serviceMessage, timeOut);
						iMap.put("REQUEST_XML_FOR_STO_PAYMENT", serviceMessage.getRequest());
						outMap.put("RESPONSE_XML_FOR_STO_PAYMENT", serviceMessage.getResponse());
						// if (responseTalimatliOdeme.getMsg() != null) {
						// errorMessage = responseTalimatliOdeme.getMsg();
						// }
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
						if (responseTalimatliOdeme == null) {
							responseCode = "660";
							errorMessage = "Talimatli odemede hata meydana geldi.";
						}
						else if (ERROR_STATUS.equalsIgnoreCase(responseTalimatliOdeme.getT())) {
							responseCode = "660";
							errorMessage = responseTalimatliOdeme.getMsg();
						}
						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
							if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
								outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
								Session session = DAOSession.getSession("BNSPRDal");
								invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
								invoicePayment.setParameter2(responseTalimatliOdeme.getThsNo());
								// invoicePayment.setParameter3(responseTalimatliOdeme.getAdr());
								// invoicePayment.setParameter4(responseTalimatliOdeme.getAdSyd());
								// invoicePayment.setParameter5(responseTalimatliOdeme.getAIslKod());
								// invoicePayment.setParameter6(responseTalimatliOdeme.getANo());
								// invoicePayment.setParameter7(responseTalimatliOdeme.getMsg());
								// invoicePayment.setParameter8(responseTalimatliOdeme.getOTrh());
								// invoicePayment.setParameter9(responseTalimatliOdeme.getT());
								// invoicePayment.setParameter10(responseTalimatliOdeme.getThkNo());
								// invoicePayment.setParameter11(responseTalimatliOdeme.getThsIslKod());
								// invoicePayment.setParameter12(responseTalimatliOdeme.getThsNo());
								invoicePayment.setParameter13(channelCode);
								invoicePayment.setParameter14(agentCode);
								invoicePayment.setParameter15(userCode);
								session.saveOrUpdate(invoicePayment);
								session.flush();
							}
//						}
//					}
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//				}
			}
			else {
				
				if (StringUtil.isEmpty(channelCode)) {
					responseCode = "660";
					errorMessage = "Kanal bilgisi bo� geldi�i i�in �deme yap�lamaz!";
				}
				else {
					
					String isCampaignChannel = CommonHelper.getValueOfParameter("BEDAS_CAMPAIGN_CHANNEL_MAPPING", channelCode);
					if ("EVET".equals(isCampaignChannel)) {	
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					boolean taksitliOdemeMi = false;
					if (iMap.getString(MapKeys.INSTALLMENT_NO) != null) {
						if (!iMap.getString(MapKeys.INSTALLMENT_NO).isEmpty()) {
							if (!"0".equals(iMap.getString(MapKeys.INSTALLMENT_NO)) && !"9999".equals(iMap.getString(MapKeys.INSTALLMENT_NO))) {
								taksitliOdemeMi = true;
							}
						}
					}
					
					if (taksitliOdemeMi) {
						responseTaksitliOdeme = BedasCampaignClient.taksitBorcuTahsilEt(p_nIsletmeKodu, tahakkukNo, Calendar.getInstance(), iMap.getInt(MapKeys.INSTALLMENT_NO), BRANCH_CODE, p_sBankaKodu, p_sIslemReferansNo, sLoginName, sPassword, channelCode, userCode, agentCode, sLoginName, sPassword, endPoint, serviceMessage,timeOut);
						if (responseTaksitliOdeme == null) {
							responseCode = "660";
							errorMessage = "Fatura �deme sirasinda hata meydana geldi.";
						}
						else if (ERROR_STATUS.equalsIgnoreCase(responseTaksitliOdeme.getT())) {
							if (serviceMessage.getResponse().contains("Tahsil Eden: AKTIF YATIRIM BANKASI")) {
								collected = true;
							}
							else {
								responseCode = "660";
								errorMessage = responseTaksitliOdeme.getMsg();
							}
						}
						else if ("Tahsilat".equals(responseTaksitliOdeme.getT())) {
							installmentPayment = true;
							responseCode = GeneralConstants.ERROR_CODE_APPROVE;
						}
						
					}
					else {
						response = BedasCampaignClient.tahsilat(p_nIsletmeKodu, tahakkukNo, tahsilatTarihi, BRANCH_CODE, p_sBankaKodu, p_sIslemReferansNo, channelCode, userCode, agentCode, sLoginName, sPassword, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), endPoint, serviceMessage,timeOut);
						if (response == null) {
							responseCode = "660";
							errorMessage = "Fatura �deme sirasinda hata meydana geldi.";
						}
						else if (ERROR_STATUS.equalsIgnoreCase(response.getT())) {
							if (serviceMessage.getResponse().contains("Tahsil Eden: AKTIF YATIRIM BANKASI")) {
								collected = true;
							}
							else {
								responseCode = "660";
								errorMessage = response.getMsg();
							}
						}
					}
						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
							Session session = DAOSession.getSession("BNSPRDal");
							invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
							if (collected) {
								try {
									String str = response.getMsg();
									int baslangic = str.indexOf("ThsNo:") + 7;
									int bitis = baslangic + 17;
									str = str.substring(baslangic, bitis);
									invoicePayment.setParameter2(str);
									invoicePayment.setParameter20("BEDAS_HATA_YAKALAMA_ILE_ODENDI");
								}
								catch (Exception e) {
									invoicePayment.setParameter2("");
								}
							}
							else {
								if (installmentPayment) {
									invoicePayment.setParameter2(responseTaksitliOdeme.getThsNo());
									invoicePayment.setParameter3(responseTaksitliOdeme.getAdr());
									invoicePayment.setParameter4(responseTaksitliOdeme.getAdSyd());
									invoicePayment.setParameter5(responseTaksitliOdeme.getAIslKod());
									invoicePayment.setParameter6(responseTaksitliOdeme.getANo());
									invoicePayment.setParameter7(responseTaksitliOdeme.getMsg());
									invoicePayment.setParameter8(responseTaksitliOdeme.getOTrh());
									invoicePayment.setParameter9(responseTaksitliOdeme.getT());
									invoicePayment.setParameter10(responseTaksitliOdeme.getThkNo());
									invoicePayment.setParameter11(responseTaksitliOdeme.getThsIslKod());
									invoicePayment.setParameter12(responseTaksitliOdeme.getThsNo());
									invoicePayment.setParameter13(channelCode);
									invoicePayment.setParameter14(agentCode);
									invoicePayment.setParameter15(userCode);
								}
								else {
									invoicePayment.setParameter2(response.getThsNo());
									invoicePayment.setParameter3(response.getAdr());
									invoicePayment.setParameter4(response.getAdSyd());
									invoicePayment.setParameter5(response.getAIslKod());
									invoicePayment.setParameter6(response.getANo());
									invoicePayment.setParameter7(response.getMsg());
									invoicePayment.setParameter8(response.getOTrh());
									invoicePayment.setParameter9(response.getT());
									invoicePayment.setParameter10(response.getThkNo());
									invoicePayment.setParameter11(response.getThsIslKod());
									invoicePayment.setParameter12(response.getThsNo());
									invoicePayment.setParameter13(channelCode);
									invoicePayment.setParameter14(agentCode);
									invoicePayment.setParameter15(userCode);
									// invoicePayment.setParameter20(sb.toString());
								}
							}
							session.saveOrUpdate(invoicePayment);
						}
						
					
					iMap.put("REQUEST_XML_FOR_PAYMENT", serviceMessage.getRequest());
					outMap.put("RESPONSE_XML_FOR_PAYMENT", serviceMessage.getResponse());

				}else{
					
					String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
					String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
					String bankUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
					int p_nTedarikciID = iMap.getInt(MapKeys.PARAMETER16);
					String header = "";
					tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
					tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(bankUrl, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
					if (loginResponse.getSonucMesaj() == null) {
						header = loginResponse.getSonucIcerik().get(0).getToken();
					} else {
						responseCode = loginResponse.getSonucMesaj();
					}
					iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
					outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
					OdemeYapResponse odemeYapResponse = null;
					String responseMessage = "";
					boolean p_bKismiTahsilatMi = false;
					Date p_dtOdemeTarihi = new Date();
					String p_sSubeKodu = BRANCH_CODE;
					tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageOdemeYap = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
					odemeYapResponse = UedasRestClient.odemeYap(bankUrl, header, serviceMessageOdemeYap, p_bKismiTahsilatMi, isStandingOrderCollection, p_dtOdemeTarihi, p_nTedarikciID, p_nIsletmeKodu, p_sIslemReferansNo,
							p_sSubeKodu, tahakkukNo, p_sTutar);
					if (odemeYapResponse.getSonucMesaj() == null) {
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					}else{
							responseCode = "660";
							errorMessage = odemeYapResponse.getSonucMesaj();
					}
					iMap.put("REQUEST_XML", serviceMessageOdemeYap.getRequest());
					outMap.put("RESPONSE_XML", serviceMessageOdemeYap.getResponse());
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCodeBranch = responceCodeMap.getString(MapKeys.ERROR_CODE);
					if (errorCodeBranch.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						updatedThsNo = odemeYapResponse.getSonucIcerik().get(0).getThsFisNo();

						Session session = DAOSession.getSession("BNSPRDal");
						invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
						invoicePayment.setParameter2(updatedThsNo);
						session.saveOrUpdate(invoicePayment);
					}
				
//					if ("0".equals(installmentNo)) {
//
//						OnlineTahsilEtV2Result responseBranch = EdasClient.tahsilat(p_nIsletmeKodu, tahakkukNo, tahsilatTarihi, BRANCH_CODE, p_sBankaKodu, p_sIslemReferansNo, sLoginName, sPassword, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6), serviceMessageBranch);
//
//						iMap.put("REQUEST_XML", serviceMessageBranch.getRequest());
//						outMap.put("RESPONSE_XML", serviceMessageBranch.getResponse());
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						if (responseBranch == null) {
//							responseCode = "3318";
//						} else if (ERROR_STATUS.equalsIgnoreCase(responseBranch.getT())) {
//							if (serviceMessageBranch.getResponse().contains("Tahsil Eden: AKTIF YATIRIM BANKASI")) {
//								try {
//									// operasyonel bedas hatasi yakala
//									Session session = DAOSession.getSession("BNSPRDal");
//									invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.ne("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).add(Restrictions.eq("invoiceNo", tahakkukNo)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).uniqueResult();
//									if (invoicePayment == null) {
//										int baslangic = serviceMessageBranch.getResponse().indexOf("ThsNo:");
//										updatedThsNo = serviceMessageBranch.getResponse().substring(baslangic + 7, baslangic + 24);
//										collected = true;
//									}
//								} catch (Exception e) {
//									responseCode = "3318";
//									logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - BEDAS hatasi yakalanirken hata meydana geldi"));
//									logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(CommonHelper.getStringifiedException(e)));
//								}
//							} else {
//								responseCode = "3318";
//							}
//						}
//						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						String errorCodeBranch = responceCodeMap.getString(MapKeys.ERROR_CODE);
//						if (errorCodeBranch.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
//							outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							Session session = DAOSession.getSession("BNSPRDal");
//							invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
//							if (collected) {
//								invoicePayment.setParameter2(updatedThsNo);
//							} else {
//								invoicePayment.setParameter2(responseBranch.getThsNo());
//							}
//							session.saveOrUpdate(invoicePayment);
//						}
//						try {
//							if (responseBranch.getT() != null) {
//								hataKodu = responseBranch.getT();
//							}
//
//							if (responseBranch.getMsg() != null) {
//								hataMesaji = responseBranch.getMsg();
//							}
//						} catch (Exception e) {
//							logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
//						}
//					} else {
//						Calendar cDate = GregorianCalendar.getInstance();
//						if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
//							cDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"));
//						}
//						TaksitBorcuTahsilEtResult responseTaksit = EdasClient.taksitBorcuTahsilEt(p_nIsletmeKodu, tahakkukNo, cDate, Integer.parseInt(installmentNo), BRANCH_CODE, p_sBankaKodu, p_sIslemReferansNo, sLoginName, sPassword, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6),
//								serviceMessageBranch);
//
//						iMap.put("REQUEST_XML", serviceMessageBranch.getRequest());
//						outMap.put("RESPONSE_XML", serviceMessageBranch.getResponse());
//						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
//						if (responseTaksit == null) {
//							responseCode = "3318";
//						} else if (ERROR_STATUS.equalsIgnoreCase(responseTaksit.getT())) {
//							responseCode = "3318";
//						}
//
//						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
//						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
//						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
//							outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
//							Session session = DAOSession.getSession("BNSPRDal");
//							invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
//							invoicePayment.setParameter2(responseTaksit.getThsNo());
//							session.saveOrUpdate(invoicePayment);
//						}
//						try {
//							if (responseTaksit.getT() != null) {
//								hataKodu = responseTaksit.getT();
//							}
//
//							if (responseTaksit.getMsg() != null) {
//								hataMesaji = responseTaksit.getMsg();
//							}
//						} catch (Exception e) {
//							logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
//						}
//					}
				}
				
			}


			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("ICS_BEDAS_CAMPAIGN_DO_INVOICE_COLLECTION is called an error occured with explanation : ".concat(CommonHelper.getStringifiedException(e2)));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE.concat(errorMessage));
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String errorMessage = "";
		try {
			String channel = CommonHelper.getChannelId();

			String channelCode = iMap.getString(MapKeys.CHANNEL_CODE, DEFAULT_CHANNEL_CODE);
			String userCode = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
			String agentCode = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int p_nIsletmeKodu = iMap.getInt(MapKeys.PARAMETER_1);
			String p_sThsFisNo = iMap.getString(MapKeys.PARAMETER_2);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String wsUrlBanka = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String endPoint = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String isCampaignChannel = CommonHelper.getValueOfParameter("BEDAS_CAMPAIGN_CHANNEL_MAPPING", channel);
			if ("EVET".equals(isCampaignChannel)) {	
				ServiceMessage serviceMessage = new ServiceMessage();
				TahsilatIptalEtYeniResult response = BedasCampaignClient.tahsilatIptal(p_nIsletmeKodu, p_sThsFisNo, channelCode, agentCode, userCode, p_sLoginName, p_sPassword, p_sBankaKodu, userName, password, endPoint, serviceMessage,timeOut);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				if (response == null) {
					responseCode = "660";
					errorMessage = "Tahsilat iptali sirasinda beklenmeyen bir hata meydana geldi.";
				}
				else if (ERROR_STATUS.equalsIgnoreCase(response.getT())) {
					responseCode = "660";
					errorMessage = response.getMsg();
				}
				else {
					if (response.getT().equals("Success")) {
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					}
				}
			}else{
				
				int p_nTedarikciID = iMap.getInt(MapKeys.PARAMETER_16);
				String header = "";
				tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
				tr.com.uedas.LoginResponse loginResponse = UedasRestClient.login(wsUrlBanka, serviceMessageLogin, p_sBankaKodu, p_sLoginName, p_sPassword);
				if (loginResponse.getSonucMesaj() == null) {
					header = loginResponse.getSonucIcerik().get(0).getToken();
				} else {
					responseCode = loginResponse.getSonucMesaj();
				}
				iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
				outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
				OdemeIptalEtResponse odemeIptalEtResponse = null;
				String responseMessage = "";
				tr.com.aktifbank.integration.uedasRest.ServiceMessage serviceMessageOdemeIptalEt = new tr.com.aktifbank.integration.uedasRest.ServiceMessage();
				odemeIptalEtResponse =	UedasRestClient.odemeIptalEt(wsUrlBanka, header, serviceMessageOdemeIptalEt, p_nTedarikciID, p_nIsletmeKodu, p_sThsFisNo);
				if (odemeIptalEtResponse.getSonucMesaj() == null) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}else{
						responseCode = "660";
						errorMessage = odemeIptalEtResponse.getSonucMesaj();
				}
				iMap.put("REQUEST_XML", serviceMessageOdemeIptalEt.getRequest());
				outMap.put("RESPONSE_XML", serviceMessageOdemeIptalEt.getResponse());
			}
			

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("ICS_BEDAS_CAMPAIGN_SEND_COLLECTION_CANCEL_MESSAGE is called an error occured with explanation : ".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_BEDAS_CAMPAIGN_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_BEDAS_CAMPAIGN_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		AboneTalimatlandirResultBoth response = null;
		String responseCode = "";
		String errorMessage = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String sSubeKodu = BRANCH_CODE;
			String sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			response = BedasCampaignClient.talimat(sSubeKodu, sIsletmeKodu, sAboneNo, sBankaKodu, sLoginName, sPassword, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			if (ERROR_STATUS.equalsIgnoreCase(response.getAboneTalimatlandirResult().getT())) {
				responseCode = "660";
				errorMessage = response.getAboneTalimatlandirResult().getMsg();
			}
			else {
				if (response.getAboneTalimatlandirResultSucces().getSonuc().equals("OK")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("STO_BEDAS_CAMPAIGN_SEND_STANDING_ORDER_MESSAGE is called an error occured with explanation : ".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_BEDAS_CAMPAIGN_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_BEDAS_CAMPAIGN_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		AboneTalimatIptalResultBoth response = null;
		String responseCode = "";
		String errorMessage = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String sSubeKodu = BRANCH_CODE;
			String sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			response = BedasCampaignClient.talimatIptal(sIsletmeKodu, sAboneNo, sBankaKodu, sLoginName, sPassword, sSubeKodu, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			if (ERROR_STATUS.equalsIgnoreCase(response.getAboneTalimatIptalResult().getT())) {
				responseCode = "660";
				errorMessage = response.getAboneTalimatIptalResult().getMsg();
			}
			else {
				if (response.getAboneTalimatIptalResultSucces().getSonuc().equals("OK")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e2) {
			logger.info("STO_BEDAS_CAMPAIGN_SEND_STANDING_ORDER_CANCEL_MESSAGE is called an error occured with explanation : ".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap debtInqueryForStandingOrders(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		ArrayList<GetTalimatliAboneBorclarBySonOdemeTarihiResult> response = null;
		Date date = new Date();
		String responseCode = "";
		int counter = 0;
		StringBuilder builder = new StringBuilder();
		String errorMessage = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String serviceOID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

			String p_sDonem = "";
			ServiceMessage serviceMessage = new ServiceMessage();

			String p_sSonOdemeTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			String p_sSonOdemeTarihiForCompare = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			response = BedasCampaignClient.talimatliBorcSorgulama(p_sSonOdemeTarihi, p_sLoginName, p_sPassword, "34", username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			if (response.size() == 0) {
				responseCode = "660";
				errorMessage = "Talimatli borcu olan abone bulunamadi.";
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, serviceOID, corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			int indexForXmlLog = 0;
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (GetTalimatliAboneBorclarBySonOdemeTarihiResult borc : response) {
					ServiceMessage serviceMessageForDebtInquery = new ServiceMessage();
					ArrayList<AboneBorcluTahakkuklarResult> responseDebtInuery = BedasCampaignClient.borcSorgula(borc.getAIs(), borc.getANo(), p_sDonem, "34", p_sLoginName, p_sPassword, username, password, url, serviceMessageForDebtInquery,timeOut);
					iMap.put("REQUEST_XML_BORC_SORGULAMA".concat(Integer.toString(indexForXmlLog++)), serviceMessageForDebtInquery.getRequest());
					outMap.put("RESPONSE_XML_BORC_SORGULAMA".concat(Integer.toString(indexForXmlLog++)), serviceMessageForDebtInquery.getResponse());
					for (AboneBorcluTahakkuklarResult responseQuery : responseDebtInuery) {
						if (responseQuery.getSonTrh().equals(p_sSonOdemeTarihiForCompare)) {
//							if (!isCollectedInvoiceNoCheck(responseQuery.getThkNo(), responseQuery.getIslKod(), corporateCode)) {
								String termYear = borc.getOTrh().substring(0, 4);
								String termMonth = borc.getOTrh().substring(5, 7);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getAIs());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borc.getANo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, responseQuery.getThkNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, responseQuery.getBorc());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getOTrh().toString().replace(".", ""));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, responseQuery.getIslKod());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, "");
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, responseQuery.getAdSyd());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
								counter++;
//							}
						}

					}
				}
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put(MapKeys.TABLE_SIZE, counter);
		}
		catch (Throwable e2) {
			logger.info("ICS_BEDAS_CAMPAIGN_DEBT_INQUERY_FOR_STANDING_ORDER -> hata meydana geldi.".concat(CommonHelper.getStringifiedException(e2)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION_CLOSED");

		try {
			String p_sTahsilatFisTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = "34";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			ServiceMessage serviceMessage = new ServiceMessage();

			ArrayList<TahsilatMutabakatProtokoluBankaToplamiResult> result = BedasCampaignClient.tahsilatMutabakatProtokoluBankaToplami(p_sTahsilatFisTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage,timeOut);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (result.size() == 0) {
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}
			else {
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
				for (int i = 0; i < result.size(); i++) {
					if (result.get(i).getTip().equals("GE�ERLI")) {
						logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION_CLOSED - kurumdan gelen gecerli tahsilat tutari = ".concat(result.get(i).getTutar().toString()));
						logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION_CLOSED - kurumdan gelen gecerli tahsilat sayisi = ".concat(result.get(i).getSayi()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(result.get(i).getTutar()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.get(i).getSayi());
					}
					if (result.get(i).getTip().equals("IPTAL")) {
						logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION_CLOSED - kurumdan gelen iptal tahsilat tutar� = ".concat(result.get(i).getTutar().toString()));
						logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION_CLOSED - kurumdan gelen iptal tahsilat sayisi = ".concat(result.get(i).getSayi()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(result.get(i).getTutar()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.get(i).getSayi());
					}
				}
			}
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}

		return output;
	}

	@GraymoundService("ICS_BEDAS_CLOSE_COLLECTION_RECONCILIATION_MANUALLY")
	public static GMMap closeCollectionReconManually(GMMap iMap) {
		GMMap output = new GMMap();

		ServiceMessage serviceMessage = new ServiceMessage();
		String oid = null;
		String reconDate = iMap.getString(MapKeys.RECON_DATE);
		String corporateCode = iMap.getString("CORPORATE_CODE");

		try {

			String p_sTahsilatFisTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(reconDate, "yyyyMMdd"), "yyyy-MM-dd");
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String p_sBankaKodu = "34";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			oid = CommonBusinessOperations.insertReconLog(corporateCode, reconDate, CommonHelper.getStringTimeNow(), ReconciliationResubmitType.ReconciliationClose);

			ArrayList<TahsilatMutabakatProtokoluBankaToplamiResult> result = BedasCampaignClient.tahsilatMutabakatProtokoluBankaToplami(p_sTahsilatFisTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage,timeOut);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			if (result.size() == 0) {
				MutabakatYapResult resultClose = BedasCampaignClient.mutabakatYap(p_sTahsilatFisTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage,timeOut);
				iMap.put("REQUEST_XML_FOR_CLOSE", serviceMessage.getRequest());
				output.put("RESPONSE_XML_FOR_CLOSE", serviceMessage.getResponse());
				String errorCode = null;
				String errorDesc = null;
				String reconStatus = null;
				if (resultClose.getT() != null) {
					if (resultClose.getT().equals("Error")) {
						reconStatus = ReconciliationStatus.ReconciliationFailed;
						errorDesc = resultClose.getMsg();
					}
					else {
						reconStatus = ReconciliationStatus.ReconciliationSucceeded;
					}
				}
				else {
					reconStatus = ReconciliationStatus.ReconciliationSucceeded;
					errorDesc = "Mutabakat say�lar�n� alan servis cevab� anla��lamad�. Ancak mutabakat kapat�ld�.";
				}
				CommonBusinessOperations.updateReconLog(oid, reconStatus, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, errorCode, errorDesc);
			}
			else {
				int collectionCount = 0;
				int cancelCount = 0;
				BigDecimal collectionAmount = new BigDecimal(0);
				BigDecimal cancelAmount = BigDecimal.ZERO;
				for (int i = 0; i < result.size(); i++) {
					if (result.get(i).getTip().equals("GE�ERLI")) {
						collectionAmount = new BigDecimal(result.get(i).getTutar());
						collectionCount = new Integer(result.get(i).getSayi());
					}
					if (result.get(i).getTip().equals("IPTAL")) {
						cancelAmount = new BigDecimal(result.get(i).getTutar());
						cancelCount = Integer.valueOf(result.get(i).getSayi());
					}
				}

				MutabakatYapResult resultClose = BedasCampaignClient.mutabakatYap(p_sTahsilatFisTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage,timeOut);
				iMap.put("REQUEST_XML_FOR_CLOSE", serviceMessage.getRequest());
				output.put("RESPONSE_XML_FOR_CLOSE", serviceMessage.getResponse());
				String errorCode = null;
				String errorDesc = null;
				String reconStatus = null;
				if (resultClose.getT() != null) {
					if (resultClose.getT().equals("Error")) {
						reconStatus = ReconciliationStatus.ReconciliationFailed;
						errorDesc = resultClose.getMsg();
					}
					else {
						reconStatus = ReconciliationStatus.ReconciliationSucceeded;
					}
				}
				else {
					reconStatus = ReconciliationStatus.ReconciliationSucceeded;
				}
				CommonBusinessOperations.updateReconLog(oid, reconStatus, collectionAmount, cancelAmount, collectionAmount, cancelAmount, new Date(), reconDate, corporateCode, collectionCount, cancelCount, collectionCount, cancelCount, ReconciliationResubmitType.ReconciliationClose, errorCode, errorDesc);
			}

		}
		catch (Exception e) {
			try {
				CommonBusinessOperations.updateReconLog(oid, ReconciliationStatus.ReconciliationFailed, new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new BigDecimal(-1), new Date(), reconDate, corporateCode, -1, -1, -1, -1, ReconciliationResubmitType.ReconciliationClose, "-1", "Sistem hatas� : ".concat(e.getMessage()));
			}
			catch (Exception e1) {
				logger.error("An exception occured while updating recon log");
				logger.error(System.currentTimeMillis(), e);
			}
			throw ExceptionHandler.convertException(e);
		}

		return output;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		try {
			MutabakatYapResult resultClose = null;
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION");
			String p_sTahsilatFisTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = "34";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);


			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();

			ArrayList<TahsilatMutabakatProtokoluBankaToplamiResult> result = BedasCampaignClient.tahsilatMutabakatProtokoluBankaToplami(p_sTahsilatFisTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage,timeOut);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			if (result.size() == 0) {
				// tahsilat yok ya da hata var
				// sayilari 0 a esitle
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}
			else {
				// aldigin sayilari koy
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
				for (int i = 0; i < result.size(); i++) {
					if (result.get(i).getTip().equals("GE�ERLI")) {
						logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION - kurumdan gelen gecerli tahsilat tutari = ".concat(result.get(i).getTutar().toString()));
						logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION - kurumdan gelen gecerli tahsilat sayisi = ".concat(result.get(i).getSayi()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(result.get(i).getTutar()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.get(i).getSayi());
					}
					if (result.get(i).getTip().equals("IPTAL")) {
						logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION - kurumdan gelen iptal tahsilat tutar� = ".concat(result.get(i).getTutar().toString()));
						logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION - kurumdan gelen iptal tahsilat sayisi = ".concat(result.get(i).getSayi()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(result.get(i).getTutar()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.get(i).getSayi());
					}
				}
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT) && output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				ServiceMessage serviceMessageForClose = new ServiceMessage();
				resultClose = BedasCampaignClient.mutabakatYap(p_sTahsilatFisTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessageForClose,timeOut);

				iMap.put("REQUEST_XML_FOR_CLOSE", serviceMessageForClose.getRequest());
				output.put("RESPONSE_XML_FOR_CLOSE", serviceMessageForClose.getResponse());
				if (resultClose.getT() != null) {
					if (resultClose.getT().equals("Error")) {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						errorMessage = resultClose.getMsg();
						output.put(MapKeys.ERROR_CODE, "660");
						output.put(MapKeys.ERROR_DESC, errorMessage);
					}
					else {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
				}
				else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
			}
			else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = "Mutabakat basarisiz oldu!Adet ve tutarlar farkli!";
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_BEDAS_CAMPAIGN_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_GET_COLLECTION_RECONCILIATION_DETAIL");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

		try {
			CollectionReconciliationDetailBatch batch = new BedasCampaignReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			ServiceMessage sm = new ServiceMessage();
			ArrayList<TahsilatMutabakatDetayVersion2Result> s = BedasCampaignClient.tahsilatMutabakatDetayVersion2(formatDate(iMap.getString(MapKeys.RECON_DATE)), "555", true, false, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2), "34", iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), sm,timeOut);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			int bankCancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			boolean found = false;
			if (s.size() > bankCancelCount) {
				for (int i = 0; i < s.size(); i++) {
					found = false;
					for (int j = 0; j < bankCancelCount; j++) {
						if (reconBankMap.getString("BANK_CANCEL", j, MapKeys.PARAMETER2).equals(s.get(i).getThsNo())) {
							found = true;
							break;
						}
					}
					if (!found) {
						try {
							insertCancelRecord(corporateCode, s.get(i).getAIs(), s.get(i).getANo(), s.get(i).getThsIs(), s.get(i).getThsNo(), s.get(i).getTutar(), iMap.getString(MapKeys.RECON_DATE));
						}
						catch (Exception e) {
							logger.info("ICS_BEDAS_CAMPAIGN_GET_COLLECTION_RECONCILIATION_DETAIL -> iptal kaydi insert edilirken hata meydana geldi..");
						}
					}
				}
			}

		}
		catch (Throwable e) {
			logger.info("ICS_BEDAS_CAMPAIGN_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;

	}

	private static void insertCancelRecord(String corporateCode, String subscriberNo1, String subscriberNo2, String thsIs, String thsNo, String tutar, String reconDate) {
		Session session = CommonHelper.getHibernateSession();
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(corporateCode);
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(subscriberNo1);
		payment.setSubscriberNo2(subscriberNo2);
		payment.setParameter1(thsIs);
		payment.setParameter2(thsNo);
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(new BigDecimal(tutar));
		payment.setPaymentAmount(new BigDecimal(tutar));
		payment.setPaymentDate(reconDate + "120000");
		payment.setCancelDate(reconDate + "120000");
		session.saveOrUpdate(payment);
		session.flush();
	}

	private static String formatDate(String str) {
		String returnDate = "";
		try {
			returnDate = CommonHelper.getDateString(CommonHelper.getDateTime(str, "yyyyMMdd"), "yyyy-MM-dd");
		}
		catch (ParseException e) {
			e.printStackTrace();
		}
		return returnDate;
	}

	@GraymoundService("STO_BEDAS_CAMPAIGN_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_BEDAS_CAMPAIGN_STANDING_ORDER_RECONCILIATION");
		ServiceMessage message = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		int corpCancelCount = 0;
		int corpOrderCount = 0;
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		try {
			String p_dTalimatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = "34";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			TalimatMutabakatProtokoluBankaToplamiResult reconResult = BedasCampaignClient.talimatMutabakatProtokoluBankaToplami(p_dTalimatTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage,timeOut);

			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			if (reconResult.getIptal() != null) {
				try {
					corpCancelCount = Integer.parseInt(reconResult.getIptal());
				}
				catch (Exception e) {
					corpCancelCount = 0;
					logger.error("STO_BEDAS_CAMPAIGN_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi alinirken hata meydana geldi");
				}
			}
			else {
				corpCancelCount = 0;
				logger.error("STO_BEDAS_CAMPAIGN_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi null geldi");
			}
			if (reconResult.getIptal() != null) {
				try {
					corpOrderCount = Integer.parseInt(reconResult.getYeni());
				}
				catch (Exception e) {
					corpOrderCount = 0;
					logger.error("STO_BEDAS_CAMPAIGN_STANDING_ORDER_RECONCILIATION -> talimat sayisi alinirken hata meydana geldi");
				}
			}
			else {
				corpOrderCount = 0;
				logger.error("STO_BEDAS_CAMPAIGN_STANDING_ORDER_RECONCILIATION ->  talimat sayisi null geldi");
			}

			if ("Error".equals(reconResult.getT())) {
				// hata meydana geldi
				logger.error("STO_BEDAS_CAMPAIGN_STANDING_ORDER_RECONCILIATION -> kurum web servisinde hata meydana geldi...");
				output.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				output.put(MapKeys.RECON_BANK_COUNT, 0);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
				responseCode = "3342";
			}
			else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap sorMap = getBankStandingOrdersForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			GMMap sorcMap = getBankStandingOrderCancelsForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			int bankOrderCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			int bankCancelCount = sorcMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
			output.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
			output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);
			output.put(MapKeys.RECON_CORPORATE_COUNT, corpOrderCount);
			output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancelCount);

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (bankCancelCount == corpCancelCount && bankOrderCount == corpOrderCount) {
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			else {
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch (Throwable e) {
			responseCode = "3342";
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("STO_BEDAS_CAMPAIGN_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_BEDAS_CAMPAIGN_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		String collectionTypeId = "0";
		String TABLE_NAME = "RECON_DETAIL_DATA";
		String responseCode = "";

		String p_sTalimatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
		String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String p_sBankaKodu = "34";
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

		ServiceMessage serviceMessage = new ServiceMessage();

		try {
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));

			ArrayList<TalimatMutabakatDetayResult> aboneTalimatMutabakatDetayCevap = BedasCampaignClient.talimatMutabakatDetay(p_sTalimatTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			if (!"Error".equals(aboneTalimatMutabakatDetayCevap.get(0).getT())) {
				logger.info("...STO_BEDAS_CAMPAIGN_GET_STANDING_ORDER_RECONCILIATION_DETAIL detaya girdi...");

				if (loadReconDetailDataTableForStandingOrder(aboneTalimatMutabakatDetayCevap, corporateCode, collectionTypeId, reconLogOid, iMap.getString(MapKeys.RECON_DATE), Integer.toString(reconDate.get(Calendar.HOUR)).concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(Integer.toString(reconDate.get(Calendar.SECOND))))) {
					//
					// // mutabakatlar tabloya yuklendi
					// // simdi bizdeki kayitlar alinarak kurumdan gelen
					// // recordset icerisinde aranacak
					// // once kurum verilerini
					// // recon_detail_data dan al
					logger.info("...STO_IGDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL detail logs are inserted temp table successfully...");

					boolean found = true;

					GMMap bsorMap = getBankStandingOrdersDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
					GMMap bsorcMap = getBankStandingOrderCancelsDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode);
					GMMap csorMap = getCorporateStandingOrdersDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode, reconLogOid);
					GMMap csorcMap = getCorporateStandingOrderCancelsDetailForBedasCampaign(iMap.getString(MapKeys.RECON_DATE), corporateCode, reconLogOid);
					int bankOrderCount = bsorMap.getInt("DETAIL_COUNT");
					int bankOrderCancelCount = bsorcMap.getInt("DETAIL_COUNT");
					int corporateOrderCount = csorMap.getInt("DETAIL_COUNT");
					int corporateOrderCancelCount = csorcMap.getInt("DETAIL_COUNT");

					String subscriberNo2 = "";

					int subscriber2length = 0;
					for (int i = 0; i < bankOrderCount; i++) {
						for (int j = 0; j < corporateOrderCount; j++) {
							subscriberNo2 = bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2);
							subscriber2length = subscriberNo2.length();
							if (subscriber2length < 4) {
								for (int j2 = 0; j2 < 4 - subscriber2length; j2++) {
									subscriberNo2 = "0".concat(subscriberNo2);
								}
							}
							if (bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1).equals(csorMap.getString("CORPORATE_ORDERS", j, MapKeys.SUBSCRIBER_NO1)) && subscriberNo2.equals(csorMap.getString("CORPORATE_ORDERS", j, MapKeys.SUBSCRIBER_NO2)) && bsorMap.getInt("BANK_ORDERS", i, "COUNT") <= csorMap.getInt("CORPORATE_ORDERS", j, "COUNT")) {
								found = true;// bizdeki talimat kaydi kurumda
								break; // bulundu

							}
							else {
								found = false;// bizdeki talimat kaydi kurumda
												// bulunamadi
							}
						}

						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2));
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							}
							catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2));
						}
					}

					found = false;
					if (bankOrderCancelCount > corporateOrderCancelCount)
						for (int i = 0; i < bankOrderCancelCount; i++) {
							for (int j = 0; j < corporateOrderCancelCount; j++) {
								subscriberNo2 = bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2);
								subscriber2length = subscriberNo2.length();
								if (subscriber2length < 4) {
									for (int j2 = 0; j2 < 4 - subscriber2length; j2++) {
										subscriberNo2 = "0".concat(subscriberNo2);
									}
								}

								if (bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1).equals(csorcMap.getString("CORPORATE_CANCELS", j, MapKeys.SUBSCRIBER_NO1)) && subscriberNo2.equals(csorcMap.getString("CORPORATE_CANCELS", i, MapKeys.SUBSCRIBER_NO2)) && bsorcMap.getInt("BANK_CANCELS", i, "COUNT") <= csorcMap.getInt("CORPORATE_CANCELS", j, "COUNT")) {
									found = true;
									break;
								}
								else {
									found = false;
								}
							}
							if (!found) {

								String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
								GMMap onlineCorporateServiceCallInputMap = new GMMap();
								GMMap onlineCorporateServiceCallOutputMap = new GMMap();
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2));
								onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
								onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
								onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
								onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
								GMMap reconProcessDataLogInsertInputMap = new GMMap();
								try {
									onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
								}
								catch (GMRuntimeException e) {
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
								}
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent); //
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2));
								CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
							}
						}

					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					insertOnlineServiceLog(iMap, outMap);

				}
				else {
					// detay mutabakat sirasinda hata olustu
					responseCode = "3422";
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
					insertOnlineServiceLog(iMap, outMap);
				}

			}
		}
		catch (Throwable e2) {
			logger.error("An exception occured while executing STO_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	public static GMMap getBankStandingOrdersForBedasCampaign(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		String strSQLTalimat = "";
		// strSQLTalimat = "SELECT subscriber_no1,subscriber_no2 " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + "AND m.create_date LIKE '" +
		// reconcilitionDate + "%'";
		strSQLTalimat = String.format(QueryRepository.BedasCampaignServicesRepository.GET_BANK_STANDING_ORDERS, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLTalimat, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
		}
		else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
		}

		return returnMap;
	}

	public static GMMap getBankStandingOrderCancelsForBedasCampaign(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_CANCELS";
		String strSQLIptal = "";

		// strSQLIptal = "SELECT subscriber_no1,subscriber_no2 " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + "AND m.cancel_date LIKE '" +
		// reconcilitionDate + "%'";
		strSQLIptal = String.format(QueryRepository.BedasCampaignServicesRepository.GET_BANK_STANDING_ORDERS_CANCEL, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLIptal, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, al.size());
		}
		else {
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
		}
		return returnMap;

	}

	public static boolean loadReconDetailDataTableForStandingOrder(ArrayList<TalimatMutabakatDetayResult> corpList, String corporateCode, String collectionTypeId, String reconLogOid, String reconDate, String reconTime) {
		boolean result = false;
		try {
			logger.info("...loadReconDeatilDataTable has just started...");
			int yeniAdedi = 0;
			int iptalAdedi = 0;
			int bankaKodu = Integer.parseInt("34");
			addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", "", Integer.toString(bankaKodu), "", "Talimat Mutabakat detay data yuklemesi basliyor", "", "", "", "", "", "Talimat", new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);
			for (int i = 0; i < corpList.size(); i++) {
				String tesisatNumarasi = corpList.get(i).getAIs();
				String daireNumarasi = corpList.get(i).getANo();
				String islemTipi = corpList.get(i).getIslem();
				addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", "", "", "", tesisatNumarasi, daireNumarasi, "", "", "", "", "Talimat", new BigDecimal(0), tesisatNumarasi, daireNumarasi, "", "", islemTipi, reconLogOid, reconDate, reconTime);
				if (islemTipi.equals("YENI")) {
					yeniAdedi++;
				}
				if (islemTipi.equals("IPTAL")) {
					iptalAdedi++;
				}
			}
			logger.info("...loadReconDeatilDataTable has just parsed first part...");
			BigDecimal talimatAdedi = new BigDecimal(Integer.toString(yeniAdedi));
			BigDecimal talimatIptalAdedi = new BigDecimal(Integer.toString(iptalAdedi));
			BigDecimal toplam = talimatAdedi.add(talimatIptalAdedi);
			addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", "", Integer.toString(bankaKodu), "", "Talimat Mutabakat detay data yuklemesi bitti. toplam y�klenen kayit sayisi : ".concat(toplam.toString()), "Toplam Talimat Adedi : ", talimatAdedi.toString(), "Toplam Talimat Iptal Adedi : ", talimatIptalAdedi.toString(), "", "Talimat", new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);
			result = true;
		}
		catch (Exception e) {
			logger.info("...loadReconDetailDataTableForStandingOrder �al���rken hata meydana geldi...".concat(e.getMessage()));
			return result;
		}
		return result;
	}

	public static boolean addNewReconDetailData(Short collectionType, String corporateCode, String invoiceNo, String parameter1, String parameter2, String parameter3, String parameter4, String parameter5, String parameter6, String parameter7, String parameter8, String parameter9, String parameter10, BigDecimal paymentAmount, String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4, String transactionType, String reconLogOid, String reconDate, String reconTime) {
		try {
			// logger.info("...addNewReconDetailData...");
			Session session = DAOSession.getSession("BNSPRDal");
			ReconDetailData rdd = new ReconDetailData();
			rdd.setCollectionType(collectionType);
			rdd.setCorporateCode(corporateCode);
			rdd.setInvoiceNo(invoiceNo);
			rdd.setParameter1(parameter1);
			rdd.setParameter2(parameter2);
			rdd.setParameter3(parameter3);
			rdd.setParameter4(parameter4);
			rdd.setParameter5(parameter5);
			rdd.setParameter6(parameter6);
			rdd.setParameter7(parameter7);
			rdd.setParameter8(parameter8);
			rdd.setParameter9(parameter9);
			rdd.setParameter10(parameter10);
			rdd.setPaymentAmount(paymentAmount);
			rdd.setStatus(true);
			rdd.setSubscriberNo1(subscriberNo1);
			rdd.setSubscriberNo2(subscriberNo2);
			rdd.setSubscriberNo3(subscriberNo3);
			rdd.setSubscriberNo4(subscriberNo4);
			rdd.setTransactionType(transactionType);
			rdd.setReconLogOid(reconLogOid);
			rdd.setReconDate(reconDate);
			rdd.setReconTime(reconTime);
			session.saveOrUpdate(rdd);
			session.flush();
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}

	public static GMMap getBankStandingOrdersDetailForBedasCampaign(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		String strSQLTalimat = "";
		strSQLTalimat = "SELECT subscriber_no1,subscriber_no2, count(*) as count " + "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " + "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='" + corporateCode + "'" + "AND m.create_date LIKE '" + reconcilitionDate + "%' " + "group by subscriber_no1,subscriber_no2 ";

		GMMap returnMap = DALUtil.getResults(strSQLTalimat, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		}
		else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;
	}

	public static GMMap getBankStandingOrderCancelsDetailForBedasCampaign(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_CANCELS";
		String strSQLIptal = "";

		strSQLIptal = "SELECT subscriber_no1,subscriber_no2 " + "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " + "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='" + corporateCode + "'" + "AND m.cancel_date LIKE '" + reconcilitionDate + "%'";

		GMMap returnMap = DALUtil.getResults(strSQLIptal, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		}
		else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;

	}

	public static GMMap getCorporateStandingOrdersDetailForBedasCampaign(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_ORDERS";
		String strSQL = "";
		strSQL = "SELECT subscriber_no1,subscriber_no2, count(*) as count " + "FROM ics.recon_detail_data " + "WHERE collection_type ='0'" + "AND status = 1 AND corporate_code = '" + corporateCode + "' " + "AND recon_log_oid = '" + reconLogOid + "' AND transaction_type='K' " + "group by subscriber_no1,subscriber_no2 ";
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		}
		else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;

	}

	public static GMMap getCorporateStandingOrderCancelsDetailForBedasCampaign(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_CANCELS";
		String strSQL = "";
		strSQL = "SELECT subscriber_no1,subscriber_no2, count(*) as count " + "FROM ics.recon_detail_data " + "WHERE collection_type ='0'" + "AND status = 1 AND corporate_code = '" + corporateCode + "' " + "AND recon_log_oid = '" + reconLogOid + "' AND transaction_type='I' " + "group by subscriber_no1,subscriber_no2 ";
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		}
		else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;

	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS")
	public static GMMap getCampaignStatus(GMMap iMap) {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS");
		logger.info("ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS is called...");
		try {
			int counter = 0;
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			ArrayList<KampanyaDurumGetirResult> campaignStatus = BedasCampaignClient.kampanyaDurumGetir(p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			logger.info("ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS called kampanyadurumgetir and service returned ".concat(Integer.toString(campaignStatus.size())));
			for (KampanyaDurumGetirResult kampanyaDurumGetirResult : campaignStatus) {
				outMap.put(MapKeys.CAMPAIGN_LIST, counter, MapKeys.CAMPAIGN_STATUS_CODE, kampanyaDurumGetirResult.getKampanyaDurumKodu());
				outMap.put(MapKeys.CAMPAIGN_LIST, counter, MapKeys.CAMPAIGN_STATUS_NAME, kampanyaDurumGetirResult.getKampanyaDurumAdi());
				counter++;
			}

		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS -> an error occured ");
			logger.error("ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS ->".concat(Long.toString(System.currentTimeMillis())), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "");
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS_DETAIL")
	public static GMMap getCampaignStatusDetail(GMMap iMap) {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS_DETAIL");
		try {
			int counter = 0;
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			String p_sKampanyaDurumKodu = iMap.getString(MapKeys.CAMPAIGN_STATUS_CODE, "");
			ArrayList<KampanyaDurumDetayGetirResult> campaignStatus = BedasCampaignClient.kampanyaDurumDetayGetir(p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, p_sKampanyaDurumKodu, serviceMessage,timeOut);

			for (KampanyaDurumDetayGetirResult kampanyaDurumGetirResult : campaignStatus) {
				outMap.put(MapKeys.CAMPAIGN_LIST_DETAIL, counter, MapKeys.CAMPAIGN_STATUS_DETAIL_CODE, kampanyaDurumGetirResult.getKampanyaDurumDetayKodu());
				outMap.put(MapKeys.CAMPAIGN_LIST_DETAIL, counter, MapKeys.CAMPAIGN_STATUS_DETAIL_NAME, kampanyaDurumGetirResult.getKampanyaDurumDetayAdi());
				outMap.put(MapKeys.CAMPAIGN_LIST_DETAIL, counter, MapKeys.CAMPAIGN_STATUS_CODE, kampanyaDurumGetirResult.getKampanyaDurumKodu());
				counter++;
			}

		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS_DETAIL -> an error occured ");
			logger.error("ICS_BEDAS_CAMPAIGN_GET_CAMPAIGN_STATUS_DETAIL ->".concat(Long.toString(System.currentTimeMillis())), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "");
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_INFO")
	public static GMMap saveCampaignInfo(GMMap iMap) {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_INFO");
		String errorMessage = "";

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			String p_sKampanyaDurumKodu = iMap.getString(MapKeys.CAMPAIGN_STATUS_CODE, "");

			int p_nAboneSahisKodu = iMap.getInt(MapKeys.CUSTOMER_PERSONAL_NUMBER, 0);
			String p_sKampanyaDurumDetayKodu = iMap.getString(MapKeys.CAMPAIGN_STATUS_DETAIL_CODE, "");
			String p_sAciklama = iMap.getString(MapKeys.EXPLANATION, "");
			String p_sKanalKodu = CommonHelper.getChannelId();
			String p_sBankaKullaniciKodu = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
			String p_sBayiKodu = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);

			KampanyaBilgisiniKaydetResult saveCampaign = BedasCampaignClient.kampanyaBilgisiniKaydet(p_sBankaKodu, p_sLoginName, p_sPassword, username, p_sPassword, url, serviceMessage, p_nAboneSahisKodu, p_sKampanyaDurumKodu, p_sKampanyaDurumDetayKodu, p_sAciklama, p_sKanalKodu, p_sBankaKullaniciKodu, p_sBayiKodu,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			GMMap responceCodeMap = new GMMap();
			if (saveCampaign != null) {
				if ("Basarili".equals(saveCampaign.getT())) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				else {
					responseCode = "660";
				}
				errorMessage = saveCampaign.getDurum();
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			}
			else {
				responseCode = "660";
				errorMessage = "CLK Kampanya bilgisini kaydet servis cagirimi basarisiz oldu!";
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				logger.info("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_INFO -> CLK Kampanya bilgisini kaydet servis cagirimi basarisiz oldu! -> iMap = ".concat(iMap.toString()));
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put("RESULT", "SUCCESSFUL");
		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_INFO -> an error occured ");
			logger.error("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_INFO -> ".concat(CommonHelper.getStringifiedException(e)));
			logger.error("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_INFO ->".concat(Long.toString(System.currentTimeMillis())), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_GET_CUSTOMER_INFO")
	public static GMMap getCustomerInfo(GMMap iMap) {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_GET_CUSTOMER_INFO");
		try {
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();

			String p_sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String p_sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			// abone numaras�n� 11 karaktere tamamla
			p_sAboneNo = CommonHelper.fillCharacters(p_sAboneNo, "0", 11, true);
			p_sIsletmeKodu = CommonHelper.fillCharacters(p_sIsletmeKodu, "0", 11, true);
			AboneBilgiGetirResult customerInfo = BedasCampaignClient.aboneBilgiGetir(p_sIsletmeKodu, p_sAboneNo, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.ID_NUMBER, customerInfo.getTCKimlikNo());
			outMap.put(MapKeys.TAX_NUMBER, customerInfo.getVergiKimlikNo());
			outMap.put(MapKeys.TAX_OFFICE, customerInfo.getVergiDairesi());
			outMap.put(MapKeys.PHONE, customerInfo.getTelefon());
			outMap.put(MapKeys.EMAIL, customerInfo.getEMail());
			outMap.put(MapKeys.CUSTOMER_ADDRESS, customerInfo.getKayitliAdres());
			outMap.put(MapKeys.DECLARED_ADDRESS, customerInfo.getBeyanEdilenAdres());
			outMap.put(MapKeys.CUSTOMER_TYPE, customerInfo.getGercekTuzel());

			outMap.put(MapKeys.NAME, customerInfo.getAd());
			outMap.put(MapKeys.SURNAME, customerInfo.getSoyad());
			outMap.put(MapKeys.COMPANY_NAME, customerInfo.getSirketAdi());
			outMap.put(MapKeys.TERM, customerInfo.getTerim());
			outMap.put(MapKeys.SUBSCRIBER_GROUP, customerInfo.getAboneGrubu());
			outMap.put(MapKeys.PRICE_LIST_GROUP, customerInfo.getTarifeGrubu());
			outMap.put(MapKeys.ELECTRIC_METER_SERIAL_NUMBER, customerInfo.getSayacSeriNo());
			outMap.put(MapKeys.ELECTRIC_METER_BRAND, customerInfo.getSayacMarka());

			if ("".equals(customerInfo.getT())) {
				// customer gelmedi ise hata f�rlat
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, "M��teri bilgisi bulunamad�!");
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "M��teri bilgisi bulunamad�!");
				logger.error("ICS_BEDAS_CAMPAIGN_GET_CUSTOMER_INFO -> M��teri bilgisi bulunamad�! ");
				CommonHelper.throwBusinessException(660, "M��teri bilgisi bulunamad�!");
			}

		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_GET_CUSTOMER_INFO -> an error occured ");
			logger.error("ICS_BEDAS_CAMPAIGN_GET_CUSTOMER_INFO ->".concat(Long.toString(System.currentTimeMillis())), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "ICS_BEDAS_CAMPAIGN_GET_CUSTOMER_INFO hata meydana geldi");
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_SAVE_CUSTOMER_INFO")
	public static GMMap saveCustomerInfo(GMMap iMap) {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_SAVE_CUSTOMER_INFO");
		String responseCode = "";
		String errorMessage = "";
		try {

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();

			String p_sKanalKodu = CommonHelper.getChannelId();
			String p_sBankaKullaniciKodu = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
			String p_sBayiKodu = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);

			String p_sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String p_sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String p_sTelefon = iMap.getString(MapKeys.PHONE);
			String p_sTcKimlikNo = iMap.getString(MapKeys.ID_NUMBER);
			String p_sVergiNo = iMap.getString(MapKeys.TAX_NUMBER);
			String p_sVergiDairesi = iMap.getString(MapKeys.TAX_OFFICE);
			String p_sEPosta = iMap.getString(MapKeys.EMAIL);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String p_sBeyanEdilenAdres = iMap.getString(MapKeys.DECLARED_ADDRESS);
			AboneEksikBilgiKaydetResult savedCustomerInfo = BedasCampaignClient.aboneEksikBilgiKaydet(p_sIsletmeKodu, p_sAboneNo, p_sTcKimlikNo, p_sVergiNo, p_sVergiDairesi, p_sTelefon, p_sEPosta, p_sBeyanEdilenAdres, p_sBankaKodu, p_sLoginName, p_sPassword, p_sKanalKodu, p_sBankaKullaniciKodu, p_sBayiKodu, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			if (ERROR_STATUS.equals(savedCustomerInfo.getT())) {
				responseCode = "660";
			}
			else if ("Basarili".equals(savedCustomerInfo.getT())) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			errorMessage = savedCustomerInfo.getIslemDurum();
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put("RESULT", "SUCCESSFUL");
		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_SAVE_CUSTOMER_INFO -> an error occured ");
			logger.error("ICS_BEDAS_CAMPAIGN_SAVE_CUSTOMER_INFO ->".concat(Long.toString(System.currentTimeMillis())), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_LOG")
	public static GMMap saveCampaignLog(GMMap iMap) {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_LOG");
		String errorMessage = "";
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		try {
			int p_nAboneUN = iMap.getInt("ABONE_KODU", 0);
			int p_nAboneSahisKodu = iMap.getInt(MapKeys.CUSTOMER_PERSONAL_NUMBER, 0);
			String p_sKampanyaDurumKodu = iMap.getString(MapKeys.CAMPAIGN_STATUS_CODE, "");
			String p_sTarih = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String p_sKanalKodu = CommonHelper.getChannelId();
			String p_sBankaKullaniciKodu = iMap.getString(MapKeys.USER_CODE, DEFAULT_USER_CODE);
			String p_sBayiKodu = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);

			KampanyaLogBilgisiniKaydetResult campaignSaveLog = BedasCampaignClient.kampanyaLogBilgisinikaydet(p_nAboneUN, p_nAboneSahisKodu, p_sKampanyaDurumKodu, p_sTarih, p_sBankaKodu, p_sLoginName, p_sPassword, p_sKanalKodu, p_sBankaKullaniciKodu, p_sBayiKodu, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responseCode = "660";
			if (campaignSaveLog == null) {
				errorMessage = "CLK Kampanya log bilgisini kaydet servis cagirimi basarisiz oldu!Hata";
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				logger.info("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_LOG -> CLK Kampanya log bilgisini kaydet servis cagirimi basarisiz oldu! -> iMap = ".concat(iMap.toString()));
			}
			else {
				if ("Basarili".equals(campaignSaveLog.getT())) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					errorMessage = campaignSaveLog.getDurum();
				}
				else {
					responseCode = "660";
					errorMessage = campaignSaveLog.getMsg();
				}
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put("RESULT", "SUCCESSFUL");
		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_LOG -> an error occured ");
			logger.error("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_LOG -> ".concat(CommonHelper.getStringifiedException(e)));
			logger.error("ICS_BEDAS_CAMPAIGN_SAVE_CAMPAIGN_LOG ->".concat(Long.toString(System.currentTimeMillis())), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_CHECK_CUSTOMER_ELIGIBILITY")
	public static GMMap checkCustomerEligibility(GMMap iMap) {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_CHECK_CUSTOMER_ELIGIBILITY");
		try {
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();

			String p_sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			p_sAboneNo = CommonHelper.fillCharacters(p_sAboneNo, "0", 11, true);
			KampanyaAboneSatisUygunlukGetirResult customerInfo = BedasCampaignClient.KampanyaAboneSatisUygunlukGetir(p_sAboneNo, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.SUBSCRIBER_NO1, customerInfo.getAboneNo());
			outMap.put(MapKeys.CUSTOMER_ADDRESS, customerInfo.getAdres());
			outMap.put(MapKeys.NAME, customerInfo.getAdSoyad());
			outMap.put("AVERAGE_CONSUMPTION", customerInfo.getOrtalamaYillikTuketim());
			outMap.put("SALE_STATUS", customerInfo.getSatisDurum());
			outMap.put("TARIFF_GROUP_NO", customerInfo.getTarifeGrupNo());
			outMap.put("TERM", customerInfo.getTerim());

			if ("ERROR".equals(customerInfo.getT())) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				outMap.put(MapKeys.ERROR_CODE, "660");
				outMap.put(MapKeys.ERROR_DESC, "Abone uygunluk kontrol servisinde hata meydana geldi!");
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "Abone uygunluk kontrol servisinde hata meydana geldi!");
				logger.error("ICS_BEDAS_CAMPAIGN_CHECK_CUSTOMER_ELIGIBILITY -> Abone uygunluk kontrol servisinde hata meydana geldi!");
				CommonHelper.throwBusinessException(660, "Abone uygunluk kontrol servisinde hata meydana geldi!");
			}

		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_CHECK_CUSTOMER_ELIGIBILITY -> an error occured ");
			logger.error("ICS_BEDAS_CAMPAIGN_CHECK_CUSTOMER_ELIGIBILITY ->".concat(Long.toString(System.currentTimeMillis())), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "ICS_BEDAS_CAMPAIGN_CHECK_CUSTOMER_ELIGIBILITY hata meydana geldi");
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_BEDAS_CAMPAIGN_GET_APPROVAL_STATUS")
	public static GMMap getApprovalStatus(GMMap iMap) {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_BEDAS_CAMPAIGN_GET_APPROVAL_STATUS");
		try {
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int timeOut = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();

			String p_sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			p_sAboneNo = CommonHelper.fillCharacters(p_sAboneNo, "0", 11, true);
			ArrayList<KampanyaAboneSatisOnayDurumGetirResult> customerInfo = BedasCampaignClient.kampanyaAboneSatisOnayDurumGetir(p_sAboneNo, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage,timeOut);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			int counter = 0;

			for (KampanyaAboneSatisOnayDurumGetirResult satisKontrol : customerInfo) {
				outMap.put("APPROVAL_STATUS_LIST", counter, "SUBSCRIBER_NO1", satisKontrol.getAboneNo());
				outMap.put("APPROVAL_STATUS_LIST", counter, "NAME", satisKontrol.getAdSoyad());
				outMap.put("APPROVAL_STATUS_LIST", counter, "BRANCH_NAME", satisKontrol.getBayiAd());
				outMap.put("APPROVAL_STATUS_LIST", counter, "BRANCH_CODE", satisKontrol.getBayiKod());
				outMap.put("APPROVAL_STATUS_LIST", counter, "AGENT_NAME", satisKontrol.getGorevliAdiSoyadi());
				outMap.put("APPROVAL_STATUS_LIST", counter, "AGENT_CODE", satisKontrol.getGorevliKod());
				outMap.put("APPROVAL_STATUS_LIST", counter, "APPROVAL_STATUS", satisKontrol.getOnayDrm());
				outMap.put("APPROVAL_STATUS_LIST", counter, "DATE", satisKontrol.getTarih());
				counter++;
			}
		}
		catch (Exception e) {
			logger.error("ICS_BEDAS_CAMPAIGN_GET_APPROVAL_STATUS -> an error occured ");
			logger.error("ICS_BEDAS_CAMPAIGN_GET_APPROVAL_STATUS ->".concat(Long.toString(System.currentTimeMillis())), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, "ICS_BEDAS_CAMPAIGN_GET_APPROVAL_STATUS hata meydana geldi");
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static boolean isCollectedInvoiceNoCheck(String invoiceNo, String parameter1, String corporateCode) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			@SuppressWarnings("unchecked")
			List<invoicePayment> collectedInvoice = criteria.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("invoiceNo", invoiceNo)).add(Restrictions.eq("parameter1", parameter1)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).add(Restrictions.eq("status", true)).list();
			if (collectedInvoice.size() > 0) {
				result = true;
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public static boolean isCollectedInvoiceNoCheckForInstallment(String invoiceNo, int installmentNo, String corporateCode) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			@SuppressWarnings("unchecked")
			List<invoicePayment> collectedInvoice = criteria.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("invoiceNo", invoiceNo)).add(Restrictions.eq("installmentNo", installmentNo)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).add(Restrictions.eq("status", true)).list();
			if (collectedInvoice.size() > 0) {
				result = true;
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}