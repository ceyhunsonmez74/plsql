package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.IzmirWaterCollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CollectionReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.FtmProcess;
import tr.com.aktifbank.integration.izmirwater.client.IzmirWaterClient;
import tr.com.aktifbank.integration.izmirwater.client.IzmirWaterServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvBorclarDetailUser;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvBorclarTypeUser;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvDetmutabakatRUser;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvIptalRecUser;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvMutabakatRecUser;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvTahsilRecUser;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvTalimatDetmutUser;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvTalimatKaydetUser;
import abys.Onltahbankasrv_wsdl.types.OnltahbankasrvTalimatMutabaUser;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class IzmirWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	
	private static final Log logger = LogFactory.getLog(BaskentGasServices.class);
	private static final int BRANCH_CODE = 1; 
	private static final String INQUIRY_REQUIRED = "10037";
	private static final String FAILED_RECON = "10055";
	private static final String FAILED_STD_ORDER_RECON = "10065";
	
	@GraymoundService("ICS_IZMIRWATER_DEBT_INQUIRY")
	public static GMMap debtInquiry(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_DEBT_INQUIRY");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			BigDecimal subscriberNo = input.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			String collectionType = input.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = input.getString(MapKeys.COLLECTION_TYPE_NAME);
			
			OnltahbankasrvBorclarTypeUser result = client.debtInquiry(subscriberNo);
			
			if(StringUtil.isEmpty(result.getMaster().getErrorMsg())){
				int counter = 0;
				for (OnltahbankasrvBorclarDetailUser element : result.getDetail()) {
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, element.getBorc());
					Date termDate = element.getDonem().getTime();
					int year = CommonHelper.getYear(termDate);
					int month = CommonHelper.getMonth(termDate);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, year);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, month);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, element.getThkfisno());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, element.getSot().getTime());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, result.getMaster().getAdsoyad());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, termDate);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, result.getMaster().getAdres());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, result.getMaster().getBolgeAdi());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, result.getMaster().getBolgeKodu());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, result.getMaster().getIlAdi());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, result.getMaster().getIlceAdi());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, result.getMaster().getIlceKodu());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, result.getMaster().getIlKodu());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, result.getMaster().getKasabaAdi());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, result.getMaster().getKasabaKodu());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, result.getMaster().getKoyAdi());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER12, result.getMaster().getKoyKodu());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER13, result.getMaster().getParolaYenilemeGunu());
					output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}
			else{
				setErrorCodeToOutput(result.getMaster().getErrorType(), result.getMaster().getErrorMsg(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while debt inquiry of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_DO_INVOICE_COLLECTION");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			boolean isStandingOrderCollection = input.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			
			OnltahbankasrvTahsilRecUser result = null;
			Date collectionDate = new Date();
			BigDecimal subscriberNo = input.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			
			Date term = input.getDate(MapKeys.PARAMETER1);
			Date dueDate = input.getDate(MapKeys.INVOICE_DUE_DATE);
			BigDecimal amount = input.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			BigDecimal txNo = input.getBigDecimal(MapKeys.TRX_NO);
			BigDecimal invoiceNo = input.getBigDecimal(MapKeys.INVOICE_NO);
			
			if(input.getBoolean(MapKeys.RECON_CALL, false)){
				collectionDate = input.getDate(MapKeys.PAYMENT_DATE);
			}
			
			if(isStandingOrderCollection){
				result = client.stdOrderInvoiceCollection(new BigDecimal(BRANCH_CODE), subscriberNo, term, dueDate, amount, collectionDate, txNo);
			}
			else{
				result = client.doInvoiceCollection(new BigDecimal(BRANCH_CODE), invoiceNo, collectionDate, txNo);
			}
			
			if(StringUtil.isEmpty(result.getErrorMsg())){
				// Confirmed payment
			}
			else{
				if(result.getErrorMsg().equals(INQUIRY_REQUIRED)){
					input.put("REQUEST_XML1", message.getRequest());
					output.put("RESPONSE_XML1", message.getResponse());
					
					OnltahbankasrvBorclarTypeUser inquiryResult = client.debtInquiry(subscriberNo);
					if(StringUtil.isEmpty(inquiryResult.getMaster().getErrorMsg())){
						input.put("REQUEST_XML2", message.getRequest());
						output.put("RESPONSE_XML2", message.getResponse());
						result = client.doInvoiceCollection(new BigDecimal(BRANCH_CODE), invoiceNo, collectionDate, txNo);
						if(StringUtil.isEmpty(result.getErrorMsg())){
							// Confirmed payment
						}
						else{
							setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
						}
					}
					else{
						setErrorCodeToOutput(inquiryResult.getMaster().getErrorType(), 
								"Zaman a��m�na u�rayan �deme sorgusu tekrar yap�ld���nda hata al�nm��t�r : ".concat(inquiryResult.getMaster().getErrorMsg()), 
								output);
					}
				}
				else{
					setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while invoice collection of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_CANCEL_INVOICE_COLLECTION")
	public static GMMap cancelInvoiceCollection(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_CANCEL_INVOICE_COLLECTION");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			
			OnltahbankasrvIptalRecUser result = client.cancelCollection(input.getBigDecimal(MapKeys.TRX_NO));
			
			if(StringUtil.isEmpty(result.getErrorMsg())){
				// Confirmed cancel
			}
			else{
				setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while cancel collection of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_SAVE_STANDING_ORDER")
	public static GMMap saveStandingOrder(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_SAVE_STANDING_ORDER");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			BigDecimal subscriberNo = input.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			Date stdOrderDate = new Date();
			
			OnltahbankasrvTalimatKaydetUser result = client.saveStandingOrder(subscriberNo, stdOrderDate);
			
			if(StringUtil.isEmpty(result.getErrorMsg())){
				if(result.getSonuc()){
					// Confirmed standing order
				}
				else{
					setErrorCodeToOutput("1", String.format("Abonenin %s bankas�ndan talimat� bulunmaktad�r.", result.getBankaAdi()), output);
				}
			}
			else{
				setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while save std order of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_CANCEL_STANDING_ORDER")
	public static GMMap cancelStandingOrder(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_CANCEL_STANDING_ORDER");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			BigDecimal subscriberNo = input.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			Date cancelDate = new Date();
			
			OnltahbankasrvTalimatKaydetUser result = client.cancelStandingOrder(subscriberNo, cancelDate);
			
			if(StringUtil.isEmpty(result.getErrorMsg())){
				if(result.getSonuc()){
					// Confirmed cancel
				}
				else{
					setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
				}
			}
			else{
				setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while cancel std order of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_COLLECTION_RECONCILIATION")
	public static GMMap collectionRecon(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_COLLECTION_RECONCILIATION");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			
			Date reconDate = input.getDate(MapKeys.RECON_DATE);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", input);
			
			BigDecimal collectionAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			OnltahbankasrvMutabakatRecUser result = client.collectionRecon(reconDate, collectionCount, collectionAmount, cancelCount, cancelAmount);
			
			if(StringUtil.isEmpty(result.getErrorMsg())){
				int corpCollectionCount = result.getTahsilsayi().intValue();
				BigDecimal corpCollectionAmount = result.getTahsiltutar();
				int corpCancelCount = result.getIptalsayi().intValue();
				BigDecimal corpCancelAmount = result.getIptaltutar();
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpCollectionAmount);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, corpCancelAmount);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corpCollectionCount);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, corpCancelCount);
				
				if(corpCollectionCount == collectionCount && corpCancelCount == cancelCount && 
						corpCollectionAmount.compareTo(collectionAmount) == 0 && corpCancelAmount.compareTo(cancelAmount) == 0){
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
				else{
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}
			else{
				if(result.getErrorType().equals(FAILED_RECON)){
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getTahsiltutar());
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getIptaltutar());
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getTahsilsayi());
					output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.getIptalsayi());
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
				else{
					setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while reconciliation process of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconDetail(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_COLLECTION_RECONCILIATION_DETAIL");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			
			Date reconDate = input.getDate(MapKeys.RECON_DATE);
			
			OnltahbankasrvDetmutabakatRUser result = client.collectionReconDetail(reconDate);
			
			if(!StringUtil.isEmpty(result.getErrorMsg())){
				setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while reconciliation detail process of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_COLLECTION_RECON_DETAIL_FILE")
	public static GMMap collectionReconDetailFile(GMMap input){
		GMMap output = new GMMap();
		
		IzmirWaterCollectionReconciliationDetailBatch batch = new IzmirWaterCollectionReconciliationDetailBatch(input);
		output = batch.runBatch();
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			FtmProcess process = (FtmProcess) session.createCriteria(FtmProcess.class)
					.add(Restrictions.eq("oid", input.getBigDecimal("PROCESS_ID")))
					.uniqueResult();
			
			String fileName = process.getFileName();
			
			String reconDate = fileName.substring(3, 11);
			
			String corporateCode = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "IZMIRWATER_CORP_CODE");
			
			GMMap reconCallInputMap = new GMMap();
			reconCallInputMap.put(CollectionReconciliationBatch.Input.SCREEN_RECONCILIATION, "1");
			reconCallInputMap.put(CollectionReconciliationBatch.Input.CORPORATE_CODE, corporateCode);
			reconCallInputMap.put(CollectionReconciliationBatch.Input.RECON_DATE, reconDate);
			reconCallInputMap.put(CollectionReconciliationBatch.Input.RESUBMIT_TYPE, DatabaseConstants.ReconciliationResubmitType.FindDifferences);
			reconCallInputMap.put("BATCH_NAME", "Tahsilat Mutabakat");
			reconCallInputMap.put("ONLY_RECON", true);
			
			GMServiceExecuter.executeAsync("ICS_COLLECTION_RECONCILIATION", reconCallInputMap);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_STD_ORDER_RECONCILIATION")
	public static GMMap standingOrderRecon(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_STD_ORDER_RECONCILIATION");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			
			Date reconDate = input.getDate(MapKeys.RECON_DATE);
			if(input.getString("SCREEN_RECONCILIATION", "0").equals("0")){
				reconDate = CommonHelper.addDay(reconDate, -1);
			}
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, input.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", reconDate);

			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);
			
			int bankStandingOrderCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
			int bankStandingOrderCancelCount = rcOutput.getInt("CANCEL_COUNT");
			
			OnltahbankasrvTalimatMutabaUser result = client.stdOrderRecon(reconDate, bankStandingOrderCount, bankStandingOrderCancelCount);
			
			if(StringUtil.isEmpty(result.getErrorMsg())){
				output.put(MapKeys.RECON_CORPORATE_COUNT, result.getTalimatsayi());
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, result.getIptalsayi());
				output.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
			}
			else{
				if(result.getErrorType().equals(FAILED_STD_ORDER_RECON)){
					output.put(MapKeys.RECON_CORPORATE_COUNT, result.getTalimatsayi());
					output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, result.getIptalsayi());
					output.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
					output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
				}
				else{
					setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while std order reconciliation process of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_STD_ORDER_RECONCILIATION_DETAIL")
	public static GMMap standingOrderReconDetail(GMMap input){
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_STD_ORDER_RECONCILIATION_DETAIL");
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		
		try{
			IzmirWaterClient client = getClient(input, message);
			
			Date reconDate = input.getDate(MapKeys.RECON_DATE);
			
			OnltahbankasrvTalimatDetmutUser result = client.stdOrderReconDetail(reconDate);
			
			if(!StringUtil.isEmpty(result.getErrorMsg())){
				setErrorCodeToOutput(result.getErrorType(), result.getErrorMsg(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while std order reconciliation detail process of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_STD_ORDER_RECON_DETAIL_FILE")
	public static GMMap stdOrderReconDetailFile(GMMap input){
		GMMap output = new GMMap();
		
		return output;
	}
	
	@GraymoundService("ICS_IZMIRWATER_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap closeRecon(GMMap input){
		GMMap output = new GMMap();
		IzmirWaterServiceMessage message = new IzmirWaterServiceMessage();
		input.put(MapKeys.WS_SERVICE_NAME,"ICS_IZMIRWATER_COLLECTION_RECONCILIATION_CLOSED");
		
		try{
			
			String screenRecon = input.getString("SCREEN_RECONCILIATION", "");
			String reconDate = input.getString(MapKeys.RECON_DATE);
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			Session session = CommonHelper.getHibernateSession();
			if(screenRecon.equals("1")){
				setCollectionInfoToOutput(output, reconDate, corporateCode,
						session);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			logger.error("An exception occured while reconciliation close process of IZMIRWATER");
			logger.error(System.currentTimeMillis(), e);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			input.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(input, output);
		}
		
		return output;
	}
	
	private static IzmirWaterClient getClient(GMMap input, IzmirWaterServiceMessage message) throws Exception {
		return new IzmirWaterClient(input.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), 
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), 
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), 
				message);
	}
	
	private static void setErrorCodeToOutput(String errorType, String errorMessage, GMMap output){
		String message = "";
		int firstIndex = errorMessage.indexOf("[");
		int lastIndex = errorMessage.indexOf("]");
		int length = lastIndex - firstIndex;
		if(length > 0){
			message = errorMessage.substring(firstIndex + 1, lastIndex);
		}
		else{
			message = errorMessage;
		}
		output.put(MapKeys.ERROR_CODE, GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE);
		output.put(MapKeys.ERROR_DESC, errorMessage);
		output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, message);
	}
}
