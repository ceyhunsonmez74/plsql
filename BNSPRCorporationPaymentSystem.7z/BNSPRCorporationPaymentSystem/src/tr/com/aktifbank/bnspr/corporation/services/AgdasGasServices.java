package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.agdas.AgDasGazOnlineClient;
import tr.com.aktifbank.integration.agdas.Assesment;
import tr.com.aktifbank.integration.agdas.Result;
import tr.com.aktifbank.integration.agdas.Revenue;
import tr.com.aktifbank.integration.agdas.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * 
 * @author selman.lafci
 * 
 */
public class AgdasGasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(AgdasGasServices.class);
	private static final String WS_RESPONSE_CODE = "WS_RESPONSE_CODE";
	private static final String reconcile_close_after_ok = "1319";

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_AGDAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AGDAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage s = new ServiceMessage();
		int counter = 0;

		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);
			String aboneNo = "";
			String processType = "";
			String subscriberNo1 = "";
			String subscriberNo2 = "";
			
			if(StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){				
				aboneNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
				subscriberNo1 = aboneNo;
				processType = "S";
			} else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				aboneNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO2), '0');
				subscriberNo2 = aboneNo;
				processType = "A";
			}	
			
			Result result = client.borcSorgu(processType, aboneNo, s);
			outMap.put(WS_RESPONSE_CODE, result.getErrorCode() + " " + result.getErrorDescription());
			GMMap responceCodeMap = getResponseCodeMapping(result.getErrorCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && result != null && result.getList().size() > 0) {
				for (Assesment assesment : (List<Assesment>) result.getList()) {
					if (!isCollectedInvoice(assesment.getAssesmentID(), aboneNo, "", "", "", corporateCode)) {
						String termYear = assesment.getLastPaymentDate().substring(6);
						String termMonth = assesment.getLastPaymentDate().substring(3, 5);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo1);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, subscriberNo2);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, assesment.getAssesmentID());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, new BigDecimal(StringUtils.isBlank(assesment.getPaymentValue()) ? "0" : assesment.getPaymentValue().replace(",", ".")));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, result.getObjectName());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(assesment.getLastPaymentDate(), "dd.MM.yyyy"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, assesment.getAssesmentType());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, assesment.getOrderNumber());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, processType);
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_AGDAS_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_AGDAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AGDAS_DO_INVOICE_COLLECTION");
		ServiceMessage s = new ServiceMessage();
		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String subscriberNumber = "";
			String invoiceNumber = iMap.getString(MapKeys.INVOICE_NO);
			String invoiceType = iMap.getString(MapKeys.PARAMETER1);
			String paymentValue = StringUtils.isEmpty(iMap.getString(MapKeys.PAYMENT_AMOUNT)) ? "0" : iMap.getString(MapKeys.PAYMENT_AMOUNT).replace('.', ',');
			String processType = "";
			
			if(StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				subscriberNumber = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
				processType = "S";
			} else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				subscriberNumber = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO2), '0');
				processType = "A";
			}	
			
			String processDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) ? iMap.getString(MapKeys.PAYMENT_DATE).substring(6, 8) + "." + iMap.getString(MapKeys.PAYMENT_DATE).substring(4, 6) + "." + iMap.getString(MapKeys.PAYMENT_DATE).substring(0, 4) : CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			if (!iMap.containsKey("cf615b28a8044f06928ca81f3bab8eb9")) {
				Result result = client.tahsilat(processType, subscriberNumber, processDate, invoiceNumber, invoiceType, paymentValue, s);
				outMap.put(WS_RESPONSE_CODE, result.getErrorCode() + " " + result.getErrorDescription());
				GMMap responceCodeMap = getResponseCodeMapping(result.getErrorCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && result != null && result.getList().size() > 0) {
					outMap.put("TAHSILAT", 0, "MAKBUZ_NO", ((List<Revenue>) result.getList()).get(0).getRevenueID());
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
					invoicePayment.setParameter3(((List<Revenue>) result.getList()).get(0).getRevenueID());
					invoicePayment.setParameter4(processType);
					session.saveOrUpdate(invoicePayment);
				}
			}
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_AGDAS_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AGDAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AGDAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String processType = iMap.getString(MapKeys.PARAMETER_4);
			String subscriberNumber = "";
			
			
			if(processType.equals("A")){
				subscriberNumber = CommonHelper.trimStart(StringUtils.isBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2)) ? iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO2) : iMap.getString(MapKeys.SUBSCRIBER_NO2), '0');
			} else{
				subscriberNumber = CommonHelper.trimStart(StringUtils.isBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) ? iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO1) : iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			}			
			
			String revenueId = iMap.getString(MapKeys.PARAMETER_3);
			String paymentValue = iMap.getString(MapKeys.PAYMENT_AMOUNT).replace(".", ",");
			Result result = client.tahsilatIptal(processType, subscriberNumber, revenueId, paymentValue, s);
			outMap.put(WS_RESPONSE_CODE, result.getErrorCode() + " " + result.getErrorDescription());
			GMMap responceCodeMap = getResponseCodeMapping(result.getErrorCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_AGDAS_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_AGDAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_AGDAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			Result result = client.talimatGirisi(aboneNo, s);
			outMap.put(WS_RESPONSE_CODE, result.getErrorCode() + " " + result.getErrorDescription());

			GMMap responceCodeMap = getResponseCodeMapping(result.getErrorCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_AGDAS_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_AGDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_AGDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');

			Result result = client.talimatIptal(aboneNo, s);
			outMap.put(WS_RESPONSE_CODE, result.getErrorCode() + " " + result.getErrorDescription());

			GMMap responceCodeMap = getResponseCodeMapping(result.getErrorCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_AGDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_AGDAS_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AGDAS_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);

			String processDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? iMap.getString(MapKeys.RECON_DATE).substring(6, 8) + "." + iMap.getString(MapKeys.RECON_DATE).substring(4, 6) + "." + iMap.getString(MapKeys.RECON_DATE).substring(0, 4) : CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);

			Result result = client.mutabakatDetay(processDate, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT).toString(), reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL).toString(), reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT).toString(), reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL).toString(), "d-selmanl@aktifbank.com.tr", s);
			outMap.put(WS_RESPONSE_CODE, result.getErrorCode() + " " + result.getErrorDescription());
			GMMap responceCodeMap = getResponseCodeMapping(result.getErrorCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			int tahsilatListLength = 0;

			for (Revenue revenue : (List<Revenue>) result.getList()) {
				boolean cancelCheck = true;
				for (Revenue giveBack : (List<Revenue>) result.getList()) {
					if (revenue.getRevenueID().equals(giveBack.getRevenueID()) && StringUtils.isNotBlank(giveBack.getGiveBackPaymentID())) {
						cancelCheck = false;
						break;
					}
				}
				if (StringUtils.isNotBlank(revenue.getAssesmentType()) && cancelCheck) {
					reconCorpAmountMap.put("CORPORATE", tahsilatListLength, MapKeys.SUBSCRIBER_NO1, revenue.getProcessID());
					reconCorpAmountMap.put("CORPORATE", tahsilatListLength, MapKeys.PAYMENT_AMOUNT, revenue.getRevenueTotal());
					reconCorpAmountMap.put("CORPORATE", tahsilatListLength, MapKeys.INVOICE_NO, revenue.getAssesmentID());
					reconCorpAmountMap.put("CORPORATE", tahsilatListLength, MapKeys.PARAMETER1, revenue.getAssesmentType());
					reconCorpAmountMap.put("CORPORATE", tahsilatListLength, MapKeys.PARAMETER3, revenue.getRevenueID());
					tahsilatListLength++;
				}
			}

			int corporateCollectionCount = tahsilatListLength;
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			boolean found = false;
			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < bankCollectionCount; j++) {
					for (int i = 0; i < corporateCollectionCount; i++) {
						if (reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1)) && reconBankMap.getString("BANK", j, MapKeys.INVOICE_NO).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.INVOICE_NO))
								&& reconBankMap.getString("BANK", j, MapKeys.TRX_NO).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.TRX_NO))
						// && reconBankMap.getString("BANK", j,
						// MapKeys.PAYMENT_AMOUNT).equals(
						// reconCorpAmountMap.getString("CORPORATE", i,
						// MapKeys.PAYMENT_AMOUNT))
						) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat istegi gonder
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.INVOICE_NO, reconBankMap.getString("BANK", j, MapKeys.INVOICE_NO));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, request.getString(MapKeys.PAYMENT_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));

						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);

						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola
							// devam ediyoruz
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat
																																											// Mesaji
																																											// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, request.getString(MapKeys.SUBSCRIBER_NO2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));

						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						if (reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1)) && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO).equals(reconBankMap.getString("BANK", k, MapKeys.INVOICE_NO))
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO).equals(reconBankMap.getString("BANK", k, MapKeys.TRX_NO)) && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();

						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER_3, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER3));

						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola
							// devam ediyoruz
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER3));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);

					}
				}
			}
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_AGDAS_GET_COLLECTION_RECONCILIATION_DETAIL.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AGDAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AGDAS_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String processDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? iMap.getString(MapKeys.RECON_DATE).substring(6, 8) + "." + iMap.getString(MapKeys.RECON_DATE).substring(4, 6) + "." + iMap.getString(MapKeys.RECON_DATE).substring(0, 4) : CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			BigDecimal revenueCount = new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT).toString()).add(new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT).toString()));
			BigDecimal revenueTotal = new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL).toString()).add(new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL).toString()));
			String emailAdress = StringUtils.isNotBlank(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2)) ? iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2) : "kurumoperasyonlariservisi@aktifbank.com.tr";

			Result result = client.mutabakatKapat(processDate, revenueCount.toString().replace(".", ","), revenueTotal.toString().replace(".", ","), outMap.getString("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).replace(".", ","), outMap.getString("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).replace(".", ","), emailAdress, s);
			String errorCodeResult = result.getErrorCode();
			outMap.put(WS_RESPONSE_CODE, errorCodeResult + " " + result.getErrorDescription());
			// 1319 Bu Tarihe Ait Cevaplanmam�� Mutabakat Talebi Bulunmaktad�r.
			// mutabakat kapama daha �nce �al��t�r�lm��.
			if (reconcile_close_after_ok.equals(errorCodeResult)) {
				errorCodeResult = "0";
			}
			GMMap responceCodeMap = getResponseCodeMapping(errorCodeResult, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			// Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

				outMap.putAll(onlineCorporateServiceCallOutputMap);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_AGDAS_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AGDAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AGDAS_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String processDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? iMap.getString(MapKeys.RECON_DATE).substring(6, 8) + "." + iMap.getString(MapKeys.RECON_DATE).substring(4, 6) + "." + iMap.getString(MapKeys.RECON_DATE).substring(0, 4) : CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			Result result = client.mutabakat(processDate, s);
			outMap.put(WS_RESPONSE_CODE, result.getErrorCode() + " " + result.getErrorDescription());
			GMMap responceCodeMap = getResponseCodeMapping(result.getErrorCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(StringUtils.isBlank(result.getRevenueTotal()) ? "0" : result.getRevenueTotal().replace(",", ".")).subtract(new BigDecimal(StringUtils.isBlank(result.getRevenueTotal()) ? "0" : result.getGiveBackTotal().replace(",", "."))));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, new BigDecimal(StringUtils.isBlank(result.getRevenueCount()) ? "0" : result.getRevenueCount().replace(",", ".")).subtract(new BigDecimal(StringUtils.isBlank(result.getGiveBackCount()) ? "0" : result.getGiveBackCount().replace(",", "."))));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, new BigDecimal(StringUtils.isBlank(result.getGiveBackCount()) ? "0" : result.getGiveBackCount().replace(",", ".")));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(StringUtils.isBlank(result.getGiveBackTotal()) ? "0" : result.getGiveBackTotal().replace(",", ".")));
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			}

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_AGDAS_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_AGDAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AGDAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		ServiceMessage s = new ServiceMessage();
		try {
			AgDasGazOnlineClient client = getSoapClient(iMap);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toDay = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			GMMap sorMap = getBankStandingOrdersForAgdas(toDay, corporateCode);
			int reconCollectionCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			Result results = client.talimatliBorcSorgulama(s);
			outMap.put(WS_RESPONSE_CODE, results.getErrorCode() + " " + results.getErrorDescription());
			String responseCode = results.getErrorCode();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			int count = 0;
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (int j = 0; j < reconCollectionCount; j++) {
					String subscriberNumber1 = sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1);
					String subscriberNumber2 = sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO2);
					for (Assesment debt : (List<Assesment>) results.getList()) {
						if (CommonHelper.trimStart(sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1), '0').equals(debt.getObjectID()) && debt.getLastPaymentDate().equals(CommonHelper.getDateString(new Date(), "dd.MM.yyyy"))) {
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, subscriberNumber1);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, subscriberNumber2);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, debt.getAssesmentID());
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, new BigDecimal(StringUtils.isBlank(debt.getPaymentValue()) ? "0" : debt.getPaymentValue().replace(",", ".")));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_TYPE, "0");// collection
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(debt.getLastPaymentDate(), "dd.MM.yyyy"));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER1, debt.getAssesmentType());
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER2, debt.getOrderNumber());
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);							
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							count++;
						}
					}
				}
			}
			iMap.put("REQUEST_XML", s.getRequest());
			outMap.put("RESPONSE_XML", s.getResponse());
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_AGDAS_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static GMMap getBankStandingOrdersForAgdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		StringBuilder sb = new StringBuilder();
		// sb.append("select * from sto.standing_order_main sm,ics.ics_standing_orders so");
		// sb.append(" where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='").append(corporateCode).append("'");
		// sb.append(" and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' ");
		// sb.append(" and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'");
		sb.append(String.format(QueryRepository.AgdasGasServicesRepository.GET_BANK_STANDING_ORDER, reconcilitionDate, reconcilitionDate, corporateCode));
		GMMap returnMap = DALUtil.getResults(sb.toString(), TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
		}

		return returnMap;
	}

	private static AgDasGazOnlineClient getSoapClient(GMMap iMap) {
		AgDasGazOnlineClient client = new AgDasGazOnlineClient(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
		return client;
	}
}
