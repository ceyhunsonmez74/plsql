package tr.com.aktifbank.bnspr.corporation.services;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.sampas.SampasClient;
import tr.com.aktifbank.integration.sampas.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.sampas.akos.service.AkosException;
import com.sampas.akos.service.AkosResponce;
import com.sampas.akos.service.BakiyeV2;
import com.sampas.akos.service.Mutabakat;
import com.sampas.akos.service.MutabakatDetayOut;
import com.sampas.akos.service.MutabakatOut;
import com.sampas.akos.service.OnlineTalimat;
import com.sampas.akos.service.Tahsilat;
import com.sampas.akos.service.TahsilatIptalTur;
import com.sampas.akos.service.TalimatIn;
import com.sampas.akos.service.TalimatOut;

/**
 * 
 * Bu Servis icin WEB_SERVICE tablosundaki Parametreler
 * 
 * Belediye Kodu: PARAMETER1
 * Kurum Kodu : PARAMETER2
 * Banka Kodu : PARAMETER3
 * 
 * 
 * 
 * @author murat.bayram
 *
 */
public class SampasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(SampasServices.class);

	private static final Long BRANCH_CODE = new Long(555);
	private static final String WS_RESPONSE_CODE="WS_RESPONSE_CODE";
	private static final String WS_RESPONSE_MESSAGE="WS_RESPONSE_MESSAGE";
	
	@GraymoundService("ICS_SAMPAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			//coklu kayit gelenlerde PARAMETER6'dan kontrol etsin tekrardan.
			for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
				if (iMap.getString(MapKeys.COLLECTION_TYPE)!=null && iMap.getString(MapKeys.COLLECTION_TYPE).equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER6))) {
					wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
					wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
					wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				}
			}
			//End of note
			
			Long aboneNo = null;
			Long sicilNo = null;
			
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !isZero(iMap.getString(MapKeys.SUBSCRIBER_NO1))){
				aboneNo = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			}
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2)) && !isZero(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				sicilNo = iMap.getLong(MapKeys.SUBSCRIBER_NO2);
			}
			
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			Long sistemKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			ServiceMessage sm = new ServiceMessage();
			BakiyeV2[] borcList = SampasClient.borcSorgulamaTum(p_belediyeKodu, p_kurumKodu, sicilNo, aboneNo, sistemKodu, wsUserName, wsPassword, wsUrl, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			
			
			//Basarili sonuc disindaki tum hatalarda exception atiyor zaten.
			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			for(BakiyeV2 borc : borcList){
				Map<String, String> maps=new HashMap<String, String>();
				maps.put("corporateCode", corporateCode);
				maps.put("subscriberNo1", Long.toString(borc.getIsYadaAboneNo()));
				maps.put("invoiceNo", Long.toString(borc.getId()));
				maps.put("parameter1", borc.getUnId());
				maps.put("paymentStatus", DatabaseConstants.PaymentStatuses.Collected);
				if(!isCollectedInvoiceMaps(maps)){
					Double amount = BigDecimal.valueOf(borc.getBorcVergi()).add(BigDecimal.valueOf(borc.getBorcGecikmeZammi())).add(BigDecimal.valueOf(borc.getBorcGecikmeFaizi())).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
					String termYear = Integer.toString(borc.getSonOdemeTar().get(Calendar.YEAR));
					String termMonth = Integer.toString(borc.getSonOdemeTar().get(Calendar.MONTH));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getIsYadaAboneNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borc.getSicilNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getId());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, amount);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSoyad());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getSonOdemeTar().getTime());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, borc.getAciklama());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, amount);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getUnId());
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}	
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);			
		}
		return outMap;
	}

	@GraymoundService("ICS_SAMPAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_DO_INVOICE_COLLECTION");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			
			String p_ref = iMap.getString(MapKeys.PARAMETER1);
			Double p_odenecekTutar = Double.valueOf(iMap.getString(MapKeys.INVOICE_AMOUNT));
			String tahsilatTarihi;
			
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))){
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd/MM/yyyy");
			}else{
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			}
			
			if(!iMap.containsKey("cf615b28a8044f06928ca81f3bab8eb9")){
				Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
				String p_tahsilatTur = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
				/*
				 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
				 * Musait bir zamanda ayri bir metoda alinmali.
				 */
				// Yine de tek olanlar icin defaultu cekelim.
				String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
				String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				
				//coklu kayit gelenlerde PARAMETER6'dan kontrol etsin tekrardan.
				for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
					if (iMap.getString(MapKeys.COLLECTION_TYPE)!=null && iMap.getString(MapKeys.COLLECTION_TYPE).equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER6))) {
						wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
						wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
						wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
					}
				}
				//End of note
				
				ServiceMessage sm = new ServiceMessage();
				AkosResponce response = SampasClient.tahsilat(p_belediyeKodu, p_kurumKodu, tahsilatTarihi, p_tahsilatTur , p_ref, p_odenecekTutar, wsUserName, wsPassword, wsUrl, sm);
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());			
				
				outMap.put(WS_RESPONSE_CODE, response.getResponceCode());
				
				GMMap responceCodeMap = getResponseCodeMapping(response.getResponceCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
					invoicePayment.setParameter2(response.getResponceExplanation());		
					session.saveOrUpdate(invoicePayment); 
				}
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_SAMPAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			//coklu kayit gelenlerde PARAMETER6'dan kontrol etsin tekrardan.
			for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
				if (iMap.getString(MapKeys.COLLECTION_TYPE)!=null && iMap.getString(MapKeys.COLLECTION_TYPE).equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER6))) {
					wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
					wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
					wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				}
			}
			//End of note
			
			String unId = iMap.getString("PARAMETER_1", null); if(StringUtil.isEmpty(unId)){unId = iMap.getString(MapKeys.PARAMETER1);}
			
			String paymentDate = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				 paymentDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd/MM/yyyy");
			} else {
				 paymentDate = CommonHelper.getDateString(new Date() , "dd/MM/yyyy");
			}
			
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			TahsilatIptalTur p_tahsilatIptalTur = new TahsilatIptalTur(new Long("999"), "M��teri �ste�i");
			ServiceMessage sm = new ServiceMessage();
			boolean returnCode = SampasClient.tahsilatIptal(p_belediyeKodu, p_kurumKodu, unId, p_tahsilatIptalTur , paymentDate, wsUserName, wsPassword, wsUrl, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			
			
			if(returnCode){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_SAMPAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_SAMPAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode="";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			//coklu kayit gelenlerde PARAMETER6'dan kontrol etsin tekrardan.
			for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
				if (iMap.getString(MapKeys.COLLECTION_TYPE)!=null && iMap.getString(MapKeys.COLLECTION_TYPE).equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER6))) {
					wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
					wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
					wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				}
			}
			//End of note
			
			Long aboneNo = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			Long tesisatNo = iMap.getLong(MapKeys.SUBSCRIBER_NO3, new Long(0));
			if(tesisatNo == null){tesisatNo = new Long(0);}
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			Long bankCode = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			String hesapNo = iMap.getString(MapKeys.TRX_NO); // gunsonu kontrolu icin gonderiyoruz
			TalimatIn p_talimatIn = new TalimatIn(aboneNo, bankCode, hesapNo, BRANCH_CODE, tesisatNo, "", "");
			ServiceMessage sm = new ServiceMessage();
			TalimatOut response = SampasClient.talimat(p_belediyeKodu, p_kurumKodu, p_talimatIn , wsUserName, wsPassword, wsUrl, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			

			outMap.put(WS_RESPONSE_CODE, response.getMesajKodu());
			
			responseCode = response.getMesajKodu();
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_SAMPAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_SAMPAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode="";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			//coklu kayit gelenlerde PARAMETER6'dan kontrol etsin tekrardan.
			for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
				if (iMap.getString(MapKeys.COLLECTION_TYPE)!=null && iMap.getString(MapKeys.COLLECTION_TYPE).equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER6))) {
					wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
					wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
					wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				}
			}
			//End of note
			
			Long aboneNo = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			Long bankCode = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

			ServiceMessage sm = new ServiceMessage();
			TalimatOut response = SampasClient.talimatIptal(p_belediyeKodu, p_kurumKodu, bankCode, aboneNo, wsUserName, wsPassword, wsUrl, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			
			
			outMap.put(WS_RESPONSE_CODE, response.getMesajKodu());
			
			responseCode = response.getMesajKodu();
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_SAMPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_SAMPAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		String errorCode = "";
		try {
			List<OnlineTalimat> totalList = new ArrayList<OnlineTalimat>();
			Calendar reconDate = new GregorianCalendar();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			Long p_bankCode = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			
			//coklu kayit gelenlerde PARAMETER6'dan kontrol etsin tekrardan.
			for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
				String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
				String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);

				ServiceMessage sm = new ServiceMessage();
				MutabakatDetayOut response = SampasClient.talimatMutabakatDetay(p_belediyeKodu, p_kurumKodu, p_bankCode, BRANCH_CODE, reconDate, reconDate, wsUserName, wsPassword, wsUrl, sm);
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());			
				responseCode = response.getMesajKodu();
				
				outMap.put(WS_RESPONSE_CODE, response.getMesajKodu());

				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					for(OnlineTalimat value : response.getOlumluTalimats()){
						outMap.put(MapKeys.SUBSCRIBER_NO1, value.getAboneNo());
					}
					
					totalList.addAll(Arrays.asList(response.getOlumluTalimats()));
				}else{
					break;
				}
			}
			//End of note
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
						iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
				rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));
				GMMap listMap = new GMMap();
				listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
	
				@SuppressWarnings("unchecked")
				List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

				OnlineTalimat[] t = new OnlineTalimat[0];
				OnlineTalimat[] corpStandingOrderList = totalList.toArray(t);
				
				boolean found = false;
				if (bankStandingOrderList.size() > corpStandingOrderList.length) {
					short collectionType = 0;
					for (int j=0; j < bankStandingOrderList.size(); j++) {
						for (int i = 0; i < corpStandingOrderList.length ; i++) {
							if (bankStandingOrderList.get(j).getSubscriberNo1().equals(corpStandingOrderList[i].getAboneNo())) {
								collectionType = bankStandingOrderList.get(j).getCollectionType();
								found = true;
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderList.get(j).getSubscriberNo1());
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
							} catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);// Talimat Mesaji Gonderildi
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderList.get(j).getSubscriberNo1());
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				} else { 
					
					short collectionType = 0;
					
					for (int j=0; j < corpStandingOrderList.length; j++) {
						for (int i = 0; i < bankStandingOrderList.size(); i++) {
							if (corpStandingOrderList[j].getAboneNo().equals(bankStandingOrderList.get(i).getSubscriberNo1())) {
								found = true;
								bankStandingOrderList.remove(i);
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat iptal istegi gonder
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, corpStandingOrderList[j].getAboneNo());
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
							} catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);// Talimat Iptal Mesaji Gonderildi
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, corpStandingOrderList[j].getAboneNo());
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				}
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("STO_SAMPAS_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_SAMPAS_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			String responseCode = "";
			Calendar reconDate = new GregorianCalendar();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			Long bankCode = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

			Long talimatSayisi = new Long(0);
			Long talimatIptalSayisi = new Long(0);
			
			GMMap responceCodeMap = new GMMap();
			String errorCode = "";
			
			for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
					String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
					String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
					String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);

					ServiceMessage sm = new ServiceMessage();
					MutabakatOut response = SampasClient.talimatMutabakatSayi(p_belediyeKodu, p_kurumKodu, bankCode, BRANCH_CODE, reconDate, reconDate, wsUserName, wsPassword, wsUrl, sm);
					iMap.put("REQUEST_XML", sm.getRequest());
					outMap.put("RESPONSE_XML", sm.getResponse());			
					outMap.put(WS_RESPONSE_CODE, response.getMesajKodu());
					responseCode = response.getMesajKodu();

					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						if(response.getOlumluMutabakatSayisi() != null){
							talimatSayisi += response.getOlumluMutabakatSayisi();
						}
						if(response.getIptalMutabakatSayisi() != null){
							talimatIptalSayisi += response.getIptalMutabakatSayisi();
						}
					}else {
						break;
					}
			}
				

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, talimatSayisi);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, talimatIptalSayisi);
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
						iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
				rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));

				GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);
	
				int bankReconCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
				
				outMap.put(MapKeys.RECON_BANK_COUNT, bankReconCount);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.CANCEL_COUNT));
			} else {
				outMap.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_COUNT, 0);
				outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_SAMPAS_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		String responseCode="";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			String corporateCodeIn = getCompanyCode4Reconciliation(corporateCode);
			iMap.put(MapKeys.CORPORATE_CODE, corporateCodeIn);
			
			String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			Calendar reconDate = new GregorianCalendar();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
				
			ServiceMessage sm = new ServiceMessage();
			Tahsilat[] response = SampasClient.tahsilatMutabakatDetay(p_belediyeKodu, p_kurumKodu, reconDate, reconDate, wsUserName, wsPassword, wsUrl, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			
			int tahsilatListLength = response.length;
			
			for (int i = 0; i < tahsilatListLength; i++) {
				Tahsilat tahsilat = response[i];
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.INVOICE_NO, tahsilat.getMakbuzNo());
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.SUBSCRIBER_NO1, tahsilat.getId());
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.SUBSCRIBER_NO2, tahsilat.getSicilNo());
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_AMOUNT, tahsilat.getTahsilatToplam());
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_DATE, tahsilat.getTahsilatTarih());
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.PARAMETER1, tahsilat.getTahsilatReferans());
				reconCorpAmountMap.put("CORPORATE", i, MapKeys.PARAMETER2, tahsilat.getSeriNo() + tahsilat.getMakbuzNo());
				// hibenate ile kay�t etmece
			}
				
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			GMMap responseCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responseCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
	
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
				int corporateCollectionCount = tahsilatListLength;
				GMMap rcInput = new GMMap();
				rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, corporateCode);
	
				boolean found = false;
				if (bankCollectionCount > corporateCollectionCount) {
					short collectionType = 0;
					for (int j = 0; j < bankCollectionCount; j++) {
						for (int i = 0; i < corporateCollectionCount; i++) {
							BigDecimal bankAmount = new BigDecimal(reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).replace(",", ".")).setScale(2, BigDecimal.ROUND_UP);
							BigDecimal corpAmount = new BigDecimal(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT).replace(",", ".")).setScale(2, BigDecimal.ROUND_UP);
							String bankSubscriber = CommonHelper.trimStart(reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO2), '0');
							String corpSubscriber = CommonHelper.trimStart(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO2), '0');
							
							if (bankSubscriber.equals(corpSubscriber)
									&& reconBankMap.getString("BANK", j, MapKeys.PARAMETER2).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PARAMETER2))
									&& corpAmount.equals(bankAmount)) {
								found = true;
								break;
							} else {
								found = false;
							}
						}
						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap request = new GMMap();
							request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
							request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
							request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
							request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
							request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
							request.put(MapKeys.CORPORATE_CODE, corporateCode);
							request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getString(MapKeys.PARAMETER3));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getString(MapKeys.PARAMETER4));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER5, request.getString(MapKeys.PARAMETER5));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER6, request.getString(MapKeys.PARAMETER6));
							onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER7, request.getString(MapKeys.PARAMETER7));
							onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
							onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
	
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));

							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							} catch (Exception e) {
								// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
								e.printStackTrace();
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
								onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
							}
	
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
							}
							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat Mesaji Gonderildi
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3,request.getString(MapKeys.PARAMETER3));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4,request.getString(MapKeys.PARAMETER4));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5,request.getString(MapKeys.PARAMETER5));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6,request.getString(MapKeys.PARAMETER6));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7,request.getString(MapKeys.PARAMETER7));
						
							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				} else {
					// bulunamayan numara icin talimat iptal istegi gonder
					//Bu case manuel cozulecektir
				}
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_SAMPAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {

			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			//Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
//			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
			
				outMap.putAll(onlineCorporateServiceCallOutputMap);
//			}

		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;

	}

	@GraymoundService("ICS_SAMPAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			String corporateCodeIn = getCompanyCode4Reconciliation(corporateCode);
			iMap.put(MapKeys.CORPORATE_CODE, corporateCodeIn);
			
			Calendar reconDate = new GregorianCalendar();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);			
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			Double toplamTahsilatTutari = (double) 0;
			Long toplamTahsilatSayisi = (long) 0;
			Double toplamIptalTutari = (double) 0;
			Long toplamIptalSayisi = (long) 0;
			
			ServiceMessage sm = new ServiceMessage();
			Mutabakat response = SampasClient.tahsilatMutabakatSayi(p_belediyeKodu, p_kurumKodu, reconDate, reconDate, wsUserName, wsPassword, wsUrl, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			
			
			if(response.getToplamTahsilatTutari() != null){
				toplamTahsilatTutari = BigDecimal.valueOf(response.getToplamTahsilatTutari()).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
			}
			if(response.getToplamTahsilatSayisi() != null){
				toplamTahsilatSayisi = response.getToplamTahsilatSayisi(); 
			}
			if(response.getToplamIptalTutari() != null){
				toplamIptalTutari = BigDecimal.valueOf(response.getToplamIptalTutari()).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
			}
			if(response.getToplamIptalSayisi() != null){
				toplamIptalSayisi = response.getToplamIptalSayisi();
			}			
			
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, toplamTahsilatTutari);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, toplamTahsilatSayisi);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, toplamIptalTutari);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, toplamIptalSayisi);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal total = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL).add(reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			int count = Integer.parseInt(reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT)) + Integer.parseInt(reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, String.valueOf(total));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, String.valueOf(count));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) 
			{
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_SAMPAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			/*
			 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
			 * Musait bir zamanda ayri bir metoda alinmali.
			 */
			// Yine de tek olanlar icin defaultu cekelim.
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			//coklu kayit gelenlerde PARAMETER6'dan kontrol etsin tekrardan.
			for (int k = 0; k < iMap.getSize(MapKeys.WS_PARAMETERS); k++) {
				if (iMap.getString(MapKeys.COLLECTION_TYPE)!=null && iMap.getString(MapKeys.COLLECTION_TYPE).equals(iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.PARAMETER6))) {
					wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_USER);
					wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_PASSWORD);
					wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, k, MapKeys.WS_ENDPOINT);
				}
			}
			//End of note
			
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			Long bankCode = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);


			String dueDate = CommonHelper.getDateString(new Date(), "dd/MM/yyyy"); 
			
			
			
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.PROCESS_DATE))){
				dueDate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PROCESS_DATE), "yyyyMMdd"),"dd/MM/yyyy");
			}
			ServiceMessage sm = new ServiceMessage();
			BakiyeV2[] borcList = SampasClient.talimatliBorcSorgulama(p_belediyeKodu, p_kurumKodu, bankCode, dueDate, dueDate, wsUserName, wsPassword, wsUrl, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			
			
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			int i = 0;
			outMap.put(MapKeys.TABLE_SIZE, borcList.length);
			for(BakiyeV2 borc : borcList){
				Double amount = BigDecimal.valueOf(borc.getBorcVergi()).add(BigDecimal.valueOf(borc.getBorcGecikmeZammi())).add(BigDecimal.valueOf(borc.getBorcGecikmeFaizi())).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, borc.getIsYadaAboneNo());
				//outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, borc.getSicilNo());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, borc.getId());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, amount);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, "0");// collection
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, borc.getSonOdemeTar().getTime());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER1, borc.getUnId());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, borc.getAdSoyad());
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
				outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE_NAME, borc.getAciklama());
				i++;
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	private static boolean isZero(String input){
		for(char c : input.toCharArray()){
			if (!"0".equals(Character.toString(c))){
				return false;
			}
		}
		return true;
	}
	
	private static String getCompanyCode4Reconciliation(String corporateCode) {
		String tmpCompanyCode = CommonHelper.getValueOfParameter("CDM_CORPORATE_COMPANY_CODE_RECON", corporateCode);
		
		if(tmpCompanyCode != null)
			corporateCode = corporateCode.concat(",").concat(tmpCompanyCode);
		
		return corporateCode;
	}
}
