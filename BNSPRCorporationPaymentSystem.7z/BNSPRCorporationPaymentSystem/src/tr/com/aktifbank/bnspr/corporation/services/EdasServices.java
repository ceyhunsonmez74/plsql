package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.EdasReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.uedas.EdasClient;
import tr.com.aktifbank.integration.uedas.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

import entity.AboneBorcluTahakkuklarResult;
import entity.AboneTaksitBorclariResult;
import entity.AboneTalimatIptalResult;
import entity.AboneTalimatlandirResult;
import entity.GetTalimatliAboneBorclarBySonOdemeTarihiResult;
import entity.OnlineTahsilEtV2Result;
import entity.TahsilatIptalEtResult;
import entity.TahsilatMutabakatKapamaResult;
import entity.TahsilatMutabakatSayiResult;
import entity.TaksitBorcuTahsilEtResult;
import entity.TaksitDetay;
import entity.TalimatMutabakatDetayResult;
import entity.TalimatMutabakatSayiResult;

public class EdasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(EdasServices.class);

	private static final String ERROR_STATUS = "Error";
	private static final String BRANCH_CODE = "555";
	private static final String BANK_CODE = "34";
	private static final String DEFAULT_AGENT_CODE = "A0000";
	private static final String YIM_CHANNEL_CODE = "32";



	@GraymoundService("ICS_EDAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_EDAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		String hataKodu = "";
		String hataMesaji = "";
		try {
			// parameters are taken
			String p_sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String p_sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String p_sDonem = "";
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			// logger info will be logged
			builder.append(" ICS_EDAS_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Isletme Kodu -> ");
			builder.append(p_sIsletmeKodu);
			builder.append(" | Abone No -> ");
			builder.append(p_sAboneNo);
			builder.append(" | Donem -> ");
			builder.append(p_sDonem);
			builder.append(" | Login Name -> ");
			builder.append(p_sLoginName);
			builder.append(" | Password -> ");
			builder.append(p_sPassword);
			builder.append(" | Banka Kodu -> ");
			builder.append(p_sBankaKodu);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(url);
			builder.append(" | namespaceURI -> ");
			builder.append(namespaceUri);
			logger.info(builder.toString());

			// set namespaceuri to use in stub
			// namespace is taken from parameters
			ServiceMessage serviceMessage = new ServiceMessage();
			serviceMessage.setParameter1(namespaceUri);

			logger.info("ICS_EDAS_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EdasClient.borcSorgulamaTum(...) will be called..."));
			ArrayList<AboneBorcluTahakkuklarResult> response = EdasClient.borcSorgulamaTum(p_sIsletmeKodu, p_sAboneNo, p_sDonem, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage);
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getParameter1(), serviceMessage.getParameter2(), serviceMessage.getParameter3());
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			logger.info("ICS_EDAS_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EdasClient.borcSorgulamaTum(...) is called..."));
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			if (response == null) {
				// if response is null that means an error occurred on service
				responseCode = "3317";
			} else if (response.size() == 1 && ERROR_STATUS.equalsIgnoreCase(response.get(0).getT())) {
				// if getT equals Error, an error occured
				responseCode = "3317";
			}
			try {
				if (response.get(0).getT() != null) {
					hataKodu = response.get(0).getT();
				}

				if (response.get(0).getT() != null) {
					hataMesaji = response.get(0).getT();
				}
			} catch (Exception e) {
				logger.info("ICS_EDAS_INVOICE_DEBT_INQUIRY FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
			}
			logger.info("ICS_EDAS_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EdasClient.borcSorgulamaTum(...) returned response code ".concat(responseCode)));
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_EDAS_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EdasClient.borcSorgulamaTum(...) returned errorCode ".concat(errorCode)));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (AboneBorcluTahakkuklarResult borc : response) {
					if (!isCollectedInvoiceNoCheck(borc.getThkNo(), borc.getIslKod(), corporateCode)) {
						String termYear = borc.getDnm().split("/")[0];
						String termMonth = borc.getDnm().split("/")[1];
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_sIsletmeKodu);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_sAboneNo);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getThkNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSyd());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(borc.getSonTrh(), "dd.MM.yyyy"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getBorc());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getIslKod());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			String installmentCollectionFlag = CommonHelper.getValueOfParameter("EDAS_INSTALLMENT_PAYMENT_MAPPING", corporateCode);
			boolean isAcceptable = false;
			if (installmentCollectionFlag != null) {
				if ("HAYIR".equals(installmentCollectionFlag)) {
					isAcceptable = false;
				} else {
					isAcceptable = true;
				}
			} else {
				isAcceptable = true;
			}
			if (isAcceptable) {
				// taksit borcu sorgula
				int installmentArrayNumber = 0;
				ArrayList<AboneTaksitBorclariResult> taksitBorclari = EdasClient.aboneTaksitBorcSorgula(p_sIsletmeKodu, p_sAboneNo, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage);
				CommonHelper.insertWsCallLog(iMap, serviceMessage.getParameter1(), serviceMessage.getParameter2(), serviceMessage.getParameter3());
				iMap.put("REQUEST_XML_FOR_INSTALLMENT", serviceMessage.getRequest());
				iMap.put("RESPONSE_XML_FOR_INSTALLMENT", serviceMessage.getResponse());
				for (int i = 0; i < taksitBorclari.size(); i++) {
					ArrayList<TaksitDetay> detay = taksitBorclari.get(installmentArrayNumber).getTaksitDetaylari();
					installmentArrayNumber++;
					for (int j = 0; j < detay.size(); j++) {
						if (!isCollectedInvoiceNoCheckForInstallment(taksitBorclari.get(i).getThkNo(), Integer.parseInt(detay.get(j).getNo()), corporateCode)) {
							String termYear = taksitBorclari.get(i).getDnm().split("/")[0];
							String termMonth = taksitBorclari.get(i).getDnm().split("/")[1];
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, p_sIsletmeKodu);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, p_sAboneNo);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, taksitBorclari.get(i).getThkNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, detay.get(j).getBorc());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, taksitBorclari.get(i).getAdSyd());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							// outMap.put(MapKeys.INVOICE_LIST, counter,
							// MapKeys.INVOICE_DUE_DATE,
							// CommonHelper.getDateTime(borc.getSonTrh(),
							// "dd.MM.yyyy"));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, detay.get(j).getBorc());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, detay.get(j).getNo());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, taksitBorclari.get(i).getIslKod());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, "Taksit No:".concat(detay.get(j).getNo()));
							// outMap.put(MapKeys.INVOICE_LIST, counter,
							// MapKeys.PARAMETER11, aboneKodu);
							outMap.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", "Taksit No:".concat(detay.get(j).getNo()));
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
						}
					}
				}
			}
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			logger.info("ICS_EDAS_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EdasClient.borcSorgulamaTum(...) finished succesfully"));
			//insertOnlineServiceLog(iMap, outMap);
		} catch (Throwable e2) {
			logger.error("ICS_EDAS_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@SuppressWarnings("unused")
	@GraymoundService("ICS_EDAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_EDAS_DO_INVOICE_COLLECTION");
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		try {
			boolean collected = false;
			String updatedThsNo = "";
			String hataKodu = "";
			String hataMesaji = "";
			String branchCode = "";
			
			StringBuilder builder = new StringBuilder();
			String agentCode = DEFAULT_AGENT_CODE;
			String channelCode = iMap.getString("CHANNEL_CODE", null);

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.AGENT_CODE))) {
				agentCode = iMap.getString(MapKeys.AGENT_CODE, DEFAULT_AGENT_CODE);
			}
			if(!StringUtil.isEmpty(channelCode)){
				if(YIM_CHANNEL_CODE.equals(channelCode)){
					branchCode = agentCode;
				}
				else{
					branchCode = BRANCH_CODE;
				}
			}

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String installmentNo = iMap.getString(MapKeys.INSTALLMENT_NO);
			String sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			int p_nIsletmeKodu = iMap.getInt(MapKeys.PARAMETER1);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String tahsilatTarihi = "";

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			ServiceMessage serviceMessage = new ServiceMessage();
			serviceMessage.setParameter1(namespaceUri);

			builder.append(" ICS_EDAS_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Isletme Kodu -> ");
			builder.append(Integer.toString(p_nIsletmeKodu));
			builder.append(" | ��lem Referans No -> ");
			builder.append(p_sIslemReferansNo);
			builder.append(" | Tahakkuk No -> ");
			builder.append(tahakkukNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			builder.append(" | Branch Code -> ");
			builder.append(branchCode);
			builder.append(" | Banka Kodu -> ");
			builder.append(p_sBankaKodu);
			builder.append(" | UserName -> ");
			builder.append(sLoginName);
			builder.append(" | Password -> ");
			builder.append(sPassword);
			builder.append(" | namespaceURI -> ");
			builder.append(namespaceUri);
			logger.info(builder.toString());

			logger.info("ICS_EDAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - EdasClient.tahsilat(...) before call.."));

			OnlineTahsilEtV2Result response = null;
			TaksitBorcuTahsilEtResult responseTaksit = null;
			OnlineTahsilEtV2Result responseTalimatliOdeme;
			if (isStandingOrderCollection) {
				logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - otomatik odeme talimatli abone icin borc sorgulanacak->".concat(tahakkukNo).concat("-").concat(p_sIslemReferansNo)));
				ArrayList<AboneBorcluTahakkuklarResult> responseStandingOrder = EdasClient.borcSorgulamaTum(iMap.getString(MapKeys.SUBSCRIBER_NO1), iMap.getString(MapKeys.SUBSCRIBER_NO2), "", p_sBankaKodu, sLoginName, sPassword, sLoginName, sPassword, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), serviceMessage);
				logger.info("ICS_EDAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(responseStandingOrder.toString()));
				iMap.put("REQUEST_XML_FOR_DEBT_INQUERY", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML_FOR_DEBT_INQUERY", serviceMessage.getResponse());
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				if (responseStandingOrder == null) {
					responseCode = "3317";
				} else if (responseStandingOrder.size() == 1 && ERROR_STATUS.equalsIgnoreCase(responseStandingOrder.get(0).getT())) {
					responseCode = "3317";
				}
				logger.info("ICS_EDAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - EdasClient.borcSorgulamaTum(...) returned response code ".concat(responseCode)));
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				logger.info("ICS_EDAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - EdasClient.borcSorgulamaTum(...) returned errorCode ".concat(errorCode)));
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					for (AboneBorcluTahakkuklarResult borc : responseStandingOrder) {
						logger.info("ICS_EDAS_DO_INVOICE_COLLECTION will be called ".concat(corporateCode).concat(" p_nIsletmeKodu->".concat(Integer.toString(p_nIsletmeKodu).concat(" - borc.getThkNo() -> ").concat(borc.getThkNo()).concat(" - tahsilatTarihi->").concat(tahsilatTarihi).concat(" - p_sIslemReferansNo->").concat(p_sIslemReferansNo))));
						responseTalimatliOdeme = EdasClient.tahsilat(p_nIsletmeKodu, borc.getThkNo(), tahsilatTarihi, branchCode, p_sBankaKodu, p_sIslemReferansNo, sLoginName, sPassword, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), serviceMessage);
						try {
							if (responseTalimatliOdeme.getT() != null) {
								hataKodu = responseTalimatliOdeme.getT();
							}

							if (responseTalimatliOdeme.getMsg() != null) {
								hataMesaji = responseTalimatliOdeme.getMsg();
							}
						} catch (Exception e) {
							logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
						}
						logger.info("ICS_EDAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - EdasClient.tahsilat is called ".concat(serviceMessage.getRequest())));
						logger.info("ICS_EDAS_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - EdasClient.tahsilat is called ".concat(serviceMessage.getResponse())));
						iMap.put("REQUEST_XML_FOR_INVOICE_PAYMENT", serviceMessage.getRequest());
						outMap.put("RESPONSE_XML_FOR_INVOICE_PAYMENT", serviceMessage.getResponse());
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
						if (responseTalimatliOdeme == null) {
							responseCode = "3318";
						} else if (ERROR_STATUS.equalsIgnoreCase(responseTalimatliOdeme.getT())) {
							responseCode = "3318";
						}
						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
							Session session = DAOSession.getSession("BNSPRDal");
							invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
							invoicePayment.setParameter2(responseTalimatliOdeme.getThsNo());
							session.saveOrUpdate(invoicePayment);
						}
					}
				}
			} else {
				if ("0".equals(installmentNo)) {
					response = EdasClient.tahsilat(p_nIsletmeKodu, tahakkukNo, tahsilatTarihi, branchCode, p_sBankaKodu, p_sIslemReferansNo, sLoginName, sPassword, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), serviceMessage);

					iMap.put("REQUEST_XML", serviceMessage.getRequest());
					outMap.put("RESPONSE_XML", serviceMessage.getResponse());
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					if (response == null) {
						responseCode = "3318";
					} else if (ERROR_STATUS.equalsIgnoreCase(response.getT())) {
						if (serviceMessage.getResponse().contains("Tahsil Eden: AKTIF YATIRIM BANKASI")) {
							try {
								// operasyonel bedas hatasi yakala
								Session session = DAOSession.getSession("BNSPRDal");
								invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.ne("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).add(Restrictions.eq("invoiceNo", tahakkukNo)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).uniqueResult();
								if (invoicePayment == null) {
									int baslangic = serviceMessage.getResponse().indexOf("ThsNo:");
									updatedThsNo = serviceMessage.getResponse().substring(baslangic + 7, baslangic + 24);
									collected = true;
								}
							} catch (Exception e) {
								responseCode = "3318";
								logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - BEDAS hatasi yakalanirken hata meydana geldi"));
								logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(CommonHelper.getStringifiedException(e)));
							}
						} else {
							responseCode = "3318";
						}
					}
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						Session session = DAOSession.getSession("BNSPRDal");
						invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
						if (collected) {
							invoicePayment.setParameter2(updatedThsNo);
						} else {
							invoicePayment.setParameter2(response.getThsNo());
						}
						session.saveOrUpdate(invoicePayment);
					}
					try {
						if (response.getT() != null) {
							hataKodu = response.getT();
						}

						if (response.getMsg() != null) {
							hataMesaji = response.getMsg();
						}
					} catch (Exception e) {
						logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
					}
				} else {
					Calendar cDate = GregorianCalendar.getInstance();
					if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
						cDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"));
					}
					responseTaksit = EdasClient.taksitBorcuTahsilEt(p_nIsletmeKodu, tahakkukNo, cDate, Integer.parseInt(installmentNo), branchCode, p_sBankaKodu, p_sIslemReferansNo, sLoginName, sPassword, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),
							serviceMessage);

					iMap.put("REQUEST_XML", serviceMessage.getRequest());
					outMap.put("RESPONSE_XML", serviceMessage.getResponse());
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					if (responseTaksit == null) {
						responseCode = "3318";
					} else if (ERROR_STATUS.equalsIgnoreCase(responseTaksit.getT())) {
						responseCode = "3318";
					}

					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						Session session = DAOSession.getSession("BNSPRDal");
						invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
						invoicePayment.setParameter2(responseTaksit.getThsNo());
						session.saveOrUpdate(invoicePayment);
					}
					try {
						if (responseTaksit.getT() != null) {
							hataKodu = responseTaksit.getT();
						}

						if (responseTaksit.getMsg() != null) {
							hataMesaji = responseTaksit.getMsg();
						}
					} catch (Exception e) {
						logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
					}
				}
			}
			logger.info("ICS_EDAS_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EdasClient.tahsilat(...) after call.."));
			logger.info("ICS_EDAS_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - EdasClient.tahsilat(...) returned errorCode ".concat(responseCode).concat(" --- ").concat(hataKodu).concat(hataMesaji)));
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_EDAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_EDAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String hataKodu = "";
		String hataMesaji = "";
		StringBuilder builder = new StringBuilder();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			String tahsilatIptalTarihi = "";

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.CANCEL_DATE))) {
				tahsilatIptalTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.CANCEL_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatIptalTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}

			String aboneNo = iMap.getString("SUBSCRIBER_NO_1", null);
			if (aboneNo == null) {
				aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}
			int p_nIsletmeKodu = iMap.getInt(MapKeys.PARAMETER_1);
			String p_sThsFisNo = iMap.getString(MapKeys.PARAMETER_2);
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String endPoint = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			serviceMessage.setParameter1(namespaceUri);

			builder.append(" ICS_EDAS_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Isletme Kodu -> ");
			builder.append(Integer.toString(p_nIsletmeKodu));
			builder.append(" | Tahsilat Fis No -> ");
			builder.append(p_sThsFisNo);
			builder.append(" | Login Name -> ");
			builder.append(p_sLoginName);
			builder.append(" | PassWord -> ");
			builder.append(p_sPassword);
			builder.append(" | Branch Code -> ");
			builder.append(BRANCH_CODE);
			builder.append(" | Banka Kodu -> ");
			builder.append(p_sBankaKodu);
			builder.append(" | UserName -> ");
			builder.append(userName);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(endPoint);
			builder.append(" | namespaceURI -> ");
			builder.append(namespaceUri);
			logger.info(builder.toString());

			TahsilatIptalEtResult response = EdasClient.tahsilatIptal(p_nIsletmeKodu, p_sThsFisNo, p_sLoginName, p_sPassword, p_sBankaKodu, userName, password, endPoint, serviceMessage);
			try {
				if (response.getT() != null) {
					hataKodu = response.getT();
				}

				if (response.getT() != null) {
					hataMesaji = response.getT();
				}
			} catch (Exception e) {
				logger.info("ICS_EDAS_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			logger.info("ICS_EDAS_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			if (response == null) {
				responseCode = "3319";
			} else if (ERROR_STATUS.equalsIgnoreCase(response.getT())) {
				responseCode = "3319";
			} else {
				if (response.getT().equals("Success")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
			}
			logger.info("ICS_EDAS_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(responseCode));
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_EDAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_EDAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		AboneTalimatlandirResult response = null;
		String responseCode = "";
		StringBuilder builder = new StringBuilder();
		String hataKodu = "";
		String hataMesaji = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String sSubeKodu = BRANCH_CODE;
			String sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String sBankaKodu = BANK_CODE;
			String sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			ServiceMessage serviceMessage = new ServiceMessage();
			serviceMessage.setParameter1(namespaceUri);

			builder.append(" STO_EDAS_SEND_STANDING_ORDER_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | �ube Kodu -> ");
			builder.append(sSubeKodu);
			builder.append(" | �sletme Kodu -> ");
			builder.append(sIsletmeKodu);
			builder.append(" | Abone No -> ");
			builder.append(sAboneNo);
			builder.append(" | Banka Kodu -> ");
			builder.append(sBankaKodu);
			builder.append(" | Login name -> ");
			builder.append(sLoginName);
			builder.append(" | Password -> ");
			builder.append(sPassword);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			builder.append(" namespaceURI -> ");
			builder.append(namespaceUri);
			logger.info(builder.toString());

			response = EdasClient.talimat(sSubeKodu, sIsletmeKodu, sAboneNo, sBankaKodu, sLoginName, sPassword, username, password, url, serviceMessage);
			try {
				if (response.getT() != null) {
					hataKodu = response.getT();
				}

				if (response.getT() != null) {
					hataMesaji = response.getT();
				}
			} catch (Exception e) {
				logger.info("ICS_EDAS_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			if (response.getT() == null) {
				responseCode = String.valueOf(GeneralConstants.ERROR_CODE_APPROVE);
			} else if (ERROR_STATUS.equalsIgnoreCase(response.getT())) {
				responseCode = "3320";
			} else {
				if (response.getT().equals("Success")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
			}

			logger.info("STO_EDAS_SEND_STANDING_ORDER_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(responseCode));

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Throwable e2) {
			logger.info("STO_EDAS_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		AboneTalimatIptalResult response = null;
		String responseCode = "";
		StringBuilder builder = new StringBuilder();
		String hataKodu = "";
		String hataMesaji = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sSubeKodu = BRANCH_CODE;
			String sIsletmeKodu = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String sAboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String sBankaKodu = BANK_CODE;
			String sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			ServiceMessage serviceMessage = new ServiceMessage();
			serviceMessage.setParameter1(namespaceUri);

			builder.append(" STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | �sletme Kodu -> ");
			builder.append(sIsletmeKodu);
			builder.append(" | Abone No -> ");
			builder.append(sAboneNo);
			builder.append(" | Banka Kodu -> ");
			builder.append(sBankaKodu);
			builder.append(" | Login name -> ");
			builder.append(sLoginName);
			builder.append(" | Password -> ");
			builder.append(sPassword);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			builder.append(" | namespaceURI -> ");
			builder.append(namespaceUri);
			logger.info(builder.toString());

			response = EdasClient.talimatIptal(sIsletmeKodu, sAboneNo, sBankaKodu, sLoginName, sPassword, sSubeKodu, username, password, url, serviceMessage);
			try {
				if (response.getT() != null) {
					hataKodu = response.getT();
				}

				if (response.getT() != null) {
					hataMesaji = response.getT();
				}
			} catch (Exception e) {
				logger.info("ICS_EDAS_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			if (response.getT() == null) {
				responseCode = String.valueOf(GeneralConstants.ERROR_CODE_APPROVE);
			} else if (ERROR_STATUS.equalsIgnoreCase(response.getT())) {
				if (response.getMsg().contains("Abonenin Talimat� Yok")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				responseCode = "3321";
			} else {
				if (response.getT().equals("Success")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
			}

			logger.info("STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(responseCode));
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Throwable e2) {
			logger.info("STO_EDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap debtInqueryForStandingOrders(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		ArrayList<GetTalimatliAboneBorclarBySonOdemeTarihiResult> response = null;
		Date date = new Date();
		String responseCode = "";
		int counter = 0;
		StringBuilder builder = new StringBuilder();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String p_sBankaKodu = BANK_CODE;
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String serviceOID = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

			String p_sDonem = "";
			ServiceMessage serviceMessage = new ServiceMessage();
			serviceMessage.setParameter1(namespaceUri);

			String p_sSonOdemeTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			String p_sSonOdemeTarihiForCompare = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			builder.append(" ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Son �deme tarihi -> ");
			builder.append(p_sSonOdemeTarihi);
			builder.append(" | Login name -> ");
			builder.append(p_sLoginName);
			builder.append(" | Password -> ");
			builder.append(p_sPassword);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			builder.append(" | namespaceURI -> ");
			builder.append(namespaceUri);
			logger.info(builder.toString());
			response = EdasClient.talimatliBorcSorgulama(p_sSonOdemeTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			if (response.size() == 0) {
				responseCode = "3322";
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, serviceOID, corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(responseCode));

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" odeme listesi alindi"));
				for (GetTalimatliAboneBorclarBySonOdemeTarihiResult borc : response) {
					ServiceMessage serviceMessageForDebtInquery = new ServiceMessage();
					serviceMessageForDebtInquery.setParameter1(namespaceUri);
					logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" will call debt inquery qith parameters - ".concat(borc.getaIs()).concat("-").concat(borc.getaNo())));
					ArrayList<AboneBorcluTahakkuklarResult> responseDebtInuery = EdasClient.borcSorgulamaTum(borc.getaIs(), borc.getaNo(), p_sDonem, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessageForDebtInquery);
					iMap.put("REQUEST_XML_BORC_SORGULAMA", serviceMessageForDebtInquery.getRequest());
					outMap.put("RESPONSE_XML_BORC_SORGULAMA", serviceMessageForDebtInquery.getResponse());
					logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" fatura sorgulama cagirildi"));
					if (responseDebtInuery.size() == 1) {
						// tek fatura geldi, son �deme tarihi bug�n olan bir
						// fatura var demektir
						logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" son odeme tarihi bugun olan bir fatura var"));
						if (responseDebtInuery.get(0).getSonTrh().equals(p_sSonOdemeTarihiForCompare)) {
							logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" fatura eslesti"));
							if (!isCollectedInvoice("0", borc.getaIs(), borc.getaNo(), "", "", corporateCode)) {
								logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" kayitlara eklenmek icin map e atildi"));
								String termYear = borc.getoTrh().substring(0, 4);
								String termMonth = borc.getoTrh().substring(5, 7);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getaIs());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borc.getaNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, responseDebtInuery.get(0).getThkNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, responseDebtInuery.get(0).getBorc());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getoTrh().toString().replace(".", ""));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getThkIs());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSoyad());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
								counter++;
							}
						}

					} else {
						// birden fazla fatura geldi ise
						// son �deme tarihi olan faturay� bul
						logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" birden fazla borc geldi"));
						for (AboneBorcluTahakkuklarResult responseQuery : responseDebtInuery) {
							if (responseQuery.getSonTrh().equals(p_sSonOdemeTarihi)) {
								logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" eslesen kayit bulundu"));
								if (!isCollectedInvoice(responseQuery.getThkNo(), borc.getaIs(), borc.getaNo(), "", "", corporateCode)) {
									logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - ").concat(" kayitlara eklenmek icin map e atildi"));
									String termYear = borc.getoTrh().substring(0, 4);
									String termMonth = borc.getoTrh().substring(5, 7);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getaIs());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borc.getaNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, responseDebtInuery.get(0).getThkNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, responseDebtInuery.get(0).getBorc());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getoTrh().toString().replace(".", ""));
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, responseQuery.getThkNo());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, responseQuery.getAdSyd());
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
									outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
									counter++;
								}
							}
						}
					}
				}
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put(MapKeys.TABLE_SIZE, counter);
		} catch (Throwable e2) {
			logger.info("ICS_EDAS_DEBT_INQUERY_FOR_STANDING_ORDER hata meydana geldi");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_EDAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		String hataKodu = "";
		String hataMesaji = "";
		try {

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_EDAS_COLLECTION_RECONCILIATION");
			Date date = iMap.getDate(MapKeys.RECON_DATE);
			String p_sTahsilatFisTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = BANK_CODE;
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();
			serviceMessage.setParameter1(namespaceUri);

			builder.append(" ICS_EDAS_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Tahsilat Fis e tarihi -> ");
			builder.append(p_sTahsilatFisTarihi);
			builder.append(" | Login name -> ");
			builder.append(p_sLoginName);
			builder.append(" | Password -> ");
			builder.append(p_sPassword);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			builder.append(" | namespaceURI -> ");
			builder.append(namespaceUri);
			logger.info(builder.toString());

			ArrayList<TahsilatMutabakatSayiResult> result = EdasClient.tahsilatMutabakatSayi(p_sTahsilatFisTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			if (result.size() == 0) {
				// tahsilat yok ya da hata var
				// sayilari 0 a esitle
				logger.info("ICS_EDAS_COLLECTION_RECONCILIATION - result size 0 geldi");

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_EDAS_COLLECTION_RECONCILIATION - result size 0 dan buyuk geldi , size =".concat(Integer.toString(result.size())));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
				for (int i = 0; i < result.size(); i++) {
					if (result.get(i).getTip().equals("GE�ERLI")) {
						logger.info("ICS_EDAS_COLLECTION_RECONCILIATION - kurumdan gelen gecerli tahsilat tutari = ".concat(result.get(i).getTutar().toString()));
						logger.info("ICS_EDAS_COLLECTION_RECONCILIATION - kurumdan gelen gecerli tahsilat sayisi = ".concat(result.get(i).getSayi()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(result.get(i).getTutar()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.get(i).getSayi());
					}
					if (result.get(i).getTip().equals("IPTAL")) {
						logger.info("ICS_EDAS_COLLECTION_RECONCILIATION - kurumdan gelen iptal tahsilat tutar� = ".concat(result.get(i).getTutar().toString()));
						logger.info("ICS_EDAS_COLLECTION_RECONCILIATION - kurumdan gelen iptal tahsilat sayisi = ".concat(result.get(i).getSayi()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(result.get(i).getTutar()));
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.get(i).getSayi());
					}
				}
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_EDAS_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");
				ServiceMessage serviceMessageForClose = new ServiceMessage();
				serviceMessageForClose.setParameter1(namespaceUri);
				TahsilatMutabakatKapamaResult resultClose = EdasClient.tahsilatMutabakatKapama(p_sTahsilatFisTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessageForClose);
				try {
					if (resultClose.getT() != null) {
						hataKodu = resultClose.getT();
					}

					if (resultClose.getT() != null) {
						hataMesaji = resultClose.getT();
					}
				} catch (Exception e) {
					logger.info("ICS_EDAS_COLLECTION_RECONCILIATION FOR ".concat(corporateCode).concat(" - hata mesaji okunurken hata meydana geldi"));
				}
				iMap.put("REQUEST_XML_FOR_CLOSE", serviceMessageForClose.getRequest());
				output.put("RESPONSE_XML_FOR_CLOSE", serviceMessageForClose.getResponse());
				if (resultClose.getT() != null) {
					if (resultClose.getT().equals("Error")) {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						logger.error("ICS_EDAS_COLLECTION_RECONCILIATION -> EdasClient.tahsilatMutabakatKapama() hata meydana geldi...".concat(resultClose.getType().concat(" - ").concat(resultClose.getMsg())));
					} else {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
				} else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
		} catch (Throwable e) {
			logger.info("ICS_EDAS_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_EDAS_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		message.setParameter1(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4));
		logger.info("ICS_EDAS_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_EDAS_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			CollectionReconciliationDetailBatch batch = new EdasReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
		} catch (Throwable e) {
			logger.info("ICS_EDAS_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("STO_EDAS_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_EDAS_STANDING_ORDER_RECONCILIATION");
		ServiceMessage message = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		int corpCancelCount = 0;
		int corpOrderCount = 0;
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		try {
			String p_dTalimatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String p_sBankaKodu = BANK_CODE;
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			ServiceMessage serviceMessage = new ServiceMessage();
			serviceMessage.setParameter1(namespaceUri);
			TalimatMutabakatSayiResult reconResult = EdasClient.talimatMutabakatSayi(p_dTalimatTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			if (reconResult.getIptal() != null) {
				try {
					corpCancelCount = Integer.parseInt(reconResult.getIptal());
				} catch (Exception e) {
					corpCancelCount = 0;
					logger.error("STO_EDAS_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi alinirken hata meydana geldi");
				}
			} else {
				corpCancelCount = 0;
				logger.error("STO_EDAS_STANDING_ORDER_RECONCILIATION -> iptal talimat sayisi null geldi");
			}
			if (reconResult.getIptal() != null) {
				try {
					corpOrderCount = Integer.parseInt(reconResult.getYeni());
				} catch (Exception e) {
					corpOrderCount = 0;
					logger.error("STO_EDAS_STANDING_ORDER_RECONCILIATION -> talimat sayisi alinirken hata meydana geldi");
				}
			} else {
				corpOrderCount = 0;
				logger.error("STO_EDAS_STANDING_ORDER_RECONCILIATION ->  talimat sayisi null geldi");
			}

			if ("Error".equals(reconResult.getT())) {
				// hata meydana geldi
				logger.error("STO_EDAS_STANDING_ORDER_RECONCILIATION -> kurum web servisinde hata meydana geldi...");
				output.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
				output.put(MapKeys.RECON_BANK_COUNT, 0);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
				responseCode = "3342";
			} else {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap sorMap = getBankStandingOrdersForEdas(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			GMMap sorcMap = getBankStandingOrderCancelsForEdas(iMap.getString(MapKeys.RECON_DATE), corporateCode);
			int bankOrderCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			int bankCancelCount = sorcMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
			output.put(MapKeys.RECON_BANK_COUNT, bankOrderCount);
			output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankCancelCount);
			output.put(MapKeys.RECON_CORPORATE_COUNT, corpOrderCount);
			output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancelCount);

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (bankCancelCount == corpCancelCount && bankOrderCount == corpOrderCount) {
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Throwable e) {
			responseCode = "3342";
			logger.error("An exception occured while executing STO_EDAS_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("STO_EDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_EDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		String collectionTypeId = "0";
		String TABLE_NAME = "RECON_DETAIL_DATA";
		String responseCode = "";

		String p_sTalimatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
		String p_sLoginName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		String p_sPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String p_sBankaKodu = BANK_CODE;
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String namespaceUri = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
		ServiceMessage serviceMessage = new ServiceMessage();
		serviceMessage.setParameter1(namespaceUri);

		try {
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			logger.info("...STO_EDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL called EdasClient.talimatMutabakatDetay (before)...");

			ArrayList<TalimatMutabakatDetayResult> aboneTalimatMutabakatDetayCevap = EdasClient.talimatMutabakatDetay(p_sTalimatTarihi, p_sLoginName, p_sPassword, p_sBankaKodu, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			if (!"Error".equals(aboneTalimatMutabakatDetayCevap.get(0).getT())) {
				logger.info("...STO_EDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL detaya girdi...");

				if (loadReconDetailDataTableForStandingOrder(aboneTalimatMutabakatDetayCevap, corporateCode, collectionTypeId, reconLogOid, iMap.getString(MapKeys.RECON_DATE), Integer.toString(reconDate.get(Calendar.HOUR)).concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(Integer.toString(reconDate.get(Calendar.SECOND))))) {
					//
					// // mutabakatlar tabloya yuklendi
					// // simdi bizdeki kayitlar alinarak kurumdan gelen
					// // recordset icerisinde aranacak
					// // once kurum verilerini
					// // recon_detail_data dan al
					logger.info("...STO_IGDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL detail logs are inserted temp table successfully...");

					boolean found = true;

					GMMap bsorMap = getBankStandingOrdersDetailForEdas(iMap.getString(MapKeys.RECON_DATE), corporateCode);
					GMMap bsorcMap = getBankStandingOrderCancelsDetailForEdas(iMap.getString(MapKeys.RECON_DATE), corporateCode);
					GMMap csorMap = getCorporateStandingOrdersDetailForEdas(iMap.getString(MapKeys.RECON_DATE), corporateCode, reconLogOid);
					GMMap csorcMap = getCorporateStandingOrderCancelsDetailForEdas(iMap.getString(MapKeys.RECON_DATE), corporateCode, reconLogOid);
					int bankOrderCount = bsorMap.getInt("DETAIL_COUNT");
					int bankOrderCancelCount = bsorcMap.getInt("DETAIL_COUNT");
					int corporateOrderCount = csorMap.getInt("DETAIL_COUNT");
					int corporateOrderCancelCount = csorcMap.getInt("DETAIL_COUNT");

					String subscriberNo2 = "";

					int subscriber2length = 0;
					for (int i = 0; i < bankOrderCount; i++) {
						for (int j = 0; j < corporateOrderCount; j++) {
							subscriberNo2 = bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2);
							subscriber2length = subscriberNo2.length();
							if (subscriber2length < 4) {
								for (int j2 = 0; j2 < 4 - subscriber2length; j2++) {
									subscriberNo2 = "0".concat(subscriberNo2);
								}
							}
							if (bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1).equals(csorMap.getString("CORPORATE_ORDERS", j, MapKeys.SUBSCRIBER_NO1)) && subscriberNo2.equals(csorMap.getString("CORPORATE_ORDERS", j, MapKeys.SUBSCRIBER_NO2)) && bsorMap.getInt("BANK_ORDERS", i, "COUNT") <= csorMap.getInt("CORPORATE_ORDERS", j, "COUNT")) {
								found = true;// bizdeki talimat kaydi kurumda
								break; // bulundu

							} else {
								found = false;// bizdeki talimat kaydi kurumda
												// bulunamadi
							}
						}

						if (!found) {
							// bulunamayan numara icin talimat istegi gonder
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2));
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
							GMMap reconProcessDataLogInsertInputMap = new GMMap();
							try {
								onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							} catch (GMRuntimeException e) {
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
							}
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO1));
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, bsorMap.getString("BANK_ORDERS", i, MapKeys.SUBSCRIBER_NO2));
						}
					}

					found = false;
					if (bankOrderCancelCount > corporateOrderCancelCount)
						for (int i = 0; i < bankOrderCancelCount; i++) {
							for (int j = 0; j < corporateOrderCancelCount; j++) {
								subscriberNo2 = bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2);
								subscriber2length = subscriberNo2.length();
								if (subscriber2length < 4) {
									for (int j2 = 0; j2 < 4 - subscriber2length; j2++) {
										subscriberNo2 = "0".concat(subscriberNo2);
									}
								}

								if (bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1).equals(csorcMap.getString("CORPORATE_CANCELS", j, MapKeys.SUBSCRIBER_NO1)) && subscriberNo2.equals(csorcMap.getString("CORPORATE_CANCELS", i, MapKeys.SUBSCRIBER_NO2)) && bsorcMap.getInt("BANK_CANCELS", i, "COUNT") <= csorcMap.getInt("CORPORATE_CANCELS", j, "COUNT")) {
									found = true;
									break;
								} else {
									found = false;
								}
							}
							if (!found) {

								String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
								GMMap onlineCorporateServiceCallInputMap = new GMMap();
								GMMap onlineCorporateServiceCallOutputMap = new GMMap();
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
								onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2));
								onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
								onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
								onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
								onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
								onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
								GMMap reconProcessDataLogInsertInputMap = new GMMap();
								try {
									onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
								} catch (GMRuntimeException e) {
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
									reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
								}
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionTypeId);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent); //
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO1));
								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, bsorcMap.getString("BANK_CANCELS", i, MapKeys.SUBSCRIBER_NO2));
								CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
							}
						}

					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					insertOnlineServiceLog(iMap, outMap);

				} else {
					// detay mutabakat sirasinda hata olustu
					responseCode = "3422";
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
					insertOnlineServiceLog(iMap, outMap);
				}

			}
		} catch (Throwable e2) {
			logger.error("An exception occured while executing STO_BUSKI_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_EDAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_EDAS_COLLECTION_RECONCILIATION_CLOSED");

		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	public static GMMap getBankStandingOrdersForEdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		String strSQLTalimat = "";
		// strSQLTalimat = "SELECT subscriber_no1,subscriber_no2 " +
		// "FROM ics.ics_standing_orders i, " + "sto.STANDING_ORDER_MAIN m " +
		// "WHERE i.standing_order_oid=m.oid " + "AND i.corporate_code      ='"
		// + corporateCode + "'" + "AND m.create_date LIKE '" +
		// reconcilitionDate + "%'";
		strSQLTalimat = String.format(QueryRepository.EdasServicesRepository.GET_BANK_STANDING_ORDERS, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLTalimat, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
		}
		return returnMap;
	}

	public static GMMap getBankStandingOrdersDetailForEdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		String strSQLTalimat = "";
		strSQLTalimat = String.format(QueryRepository.EdasServicesRepository.GET_STANDING_ORDER_DETAIL, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLTalimat, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		} else {
			returnMap.put("DETAIL_COUNT", 0);
		}

		return returnMap;
	}

	public static GMMap getBankStandingOrderCancelsForEdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_CANCELS";
		String strSQLIptal = "";
		strSQLIptal = String.format(QueryRepository.EdasServicesRepository.GET_BANK_CANCELLED_STANDING_ORDERS, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLIptal, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
		}
		return returnMap;

	}

	public static GMMap getBankStandingOrderCancelsDetailForEdas(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_CANCELS";
		String strSQLIptal = "";
		strSQLIptal = String.format(QueryRepository.EdasServicesRepository.GET_BANK_CANCELLED_STANDING_ORDERS_DETAIL, corporateCode, reconcilitionDate);
		GMMap returnMap = DALUtil.getResults(strSQLIptal, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		} else {
			returnMap.put("DETAIL_COUNT", 0);
		}
		return returnMap;
	}

	public static GMMap getCorporateStandingOrderCancelsForEdas(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_CANCELS";
		String strSQL = "";
		strSQL = String.format(QueryRepository.EdasServicesRepository.GET_BANK_CORPORATE_STANDING_ORDERS_CANCEL, corporateCode, reconLogOid);
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
		}
		return returnMap;
	}

	public static GMMap getCorporateStandingOrdersForEdas(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_ORDERS";
		String strSQL = "";
		strSQL = String.format(QueryRepository.EdasServicesRepository.GET_CORPORATE_STANDING_ORDERS, corporateCode, reconLogOid);
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_CORPORATE_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_CORPORATE_COUNT, 0);
		}
		return returnMap;
	}

	public static GMMap getCorporateStandingOrdersDetailForEdas(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_ORDERS";
		String strSQL = "";
		strSQL = String.format(QueryRepository.EdasServicesRepository.GET_CORPORATE_STANDING_ORDERS_DETAIL, corporateCode, reconLogOid);
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		} else {
			returnMap.put("DETAIL_COUNT", 0);
		}
		return returnMap;
	}

	public static GMMap getCorporateStandingOrderCancelsDetailForEdas(String reconcilitionDate, String corporateCode, String reconLogOid) {
		String TABLE_NAME = "CORPORATE_CANCELS";
		String strSQL = "";
		strSQL = String.format(QueryRepository.EdasServicesRepository.GET_CORPORATE_STANDING_ORDERS_CANCEL_DETAIL, corporateCode, reconLogOid);
		logger.info(strSQL);
		GMMap returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put("DETAIL_COUNT", al.size());
		} else {
			returnMap.put("DETAIL_COUNT", 0);
		}
		return returnMap;
	}

	public static boolean loadReconDetailDataTableForStandingOrder(ArrayList<TalimatMutabakatDetayResult> corpList, String corporateCode, String collectionTypeId, String reconLogOid, String reconDate, String reconTime) {
		boolean result = false;
		try {
			logger.info("...loadReconDeatilDataTable has just started...");
			int yeniAdedi = 0;
			int iptalAdedi = 0;
			int bankaKodu = Integer.parseInt(BANK_CODE);
			addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", "", Integer.toString(bankaKodu), "", "Talimat Mutabakat detay data yuklemesi basliyor", "", "", "", "", "", "Talimat", new BigDecimal(0), "", "", "", "", "", reconLogOid, reconDate, reconTime);
			for (int i = 0; i < corpList.size(); i++) {
				String tesisatNumarasi = corpList.get(i).getAIs();
				String daireNumarasi = corpList.get(i).getANo();
				String islemTipi = corpList.get(i).getIslem();
				addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", "", "", "", tesisatNumarasi, daireNumarasi, "", "", "", "", "Talimat", new BigDecimal(0), tesisatNumarasi, daireNumarasi, "", "", islemTipi, reconLogOid, reconDate, reconTime);
				if (islemTipi.equals("YENI")) {
					yeniAdedi++;
				}
				if (islemTipi.equals("IPTAL")) {
					iptalAdedi++;
				}
			}
			logger.info("...loadReconDeatilDataTable has just parsed first part...");
			BigDecimal talimatAdedi = new BigDecimal(Integer.toString(yeniAdedi));
			BigDecimal talimatIptalAdedi = new BigDecimal(Integer.toString(iptalAdedi));
			BigDecimal toplam = talimatAdedi.add(talimatIptalAdedi);
			addNewReconDetailData(Short.parseShort(collectionTypeId), corporateCode, "", "", Integer.toString(bankaKodu), "", "Talimat Mutabakat detay data yuklemesi bitti. toplam y�klenen kayit sayisi : ".concat(toplam.toString()), "Toplam Talimat Adedi : ", talimatAdedi.toString(), "Toplam Talimat Iptal Adedi : ", talimatIptalAdedi.toString(), "", "Talimat", new BigDecimal(0), "", "", "", "",
					"", reconLogOid, reconDate, reconTime);
			result = true;
		} catch (Exception e) {
			logger.info("...loadReconDetailDataTableForStandingOrder �al���rken hata meydana geldi...".concat(e.getMessage()));
			return result;
		}
		return result;
	}

	public static boolean addNewReconDetailData(Short collectionType, String corporateCode, String invoiceNo, String parameter1, String parameter2, String parameter3, String parameter4, String parameter5, String parameter6, String parameter7, String parameter8, String parameter9, String parameter10, BigDecimal paymentAmount, String subscriberNo1, String subscriberNo2, String subscriberNo3,
			String subscriberNo4, String transactionType, String reconLogOid, String reconDate, String reconTime) {
		try {
			// logger.info("...addNewReconDetailData...");
			Session session = DAOSession.getSession("BNSPRDal");
			ReconDetailData rdd = new ReconDetailData();
			rdd.setCollectionType(collectionType);
			rdd.setCorporateCode(corporateCode);
			rdd.setInvoiceNo(invoiceNo);
			rdd.setParameter1(parameter1);
			rdd.setParameter2(parameter2);
			rdd.setParameter3(parameter3);
			rdd.setParameter4(parameter4);
			rdd.setParameter5(parameter5);
			rdd.setParameter6(parameter6);
			rdd.setParameter7(parameter7);
			rdd.setParameter8(parameter8);
			rdd.setParameter9(parameter9);
			rdd.setParameter10(parameter10);
			rdd.setPaymentAmount(paymentAmount);
			rdd.setStatus(true);
			rdd.setSubscriberNo1(subscriberNo1);
			rdd.setSubscriberNo2(subscriberNo2);
			rdd.setSubscriberNo3(subscriberNo3);
			rdd.setSubscriberNo4(subscriberNo4);
			rdd.setTransactionType(transactionType);
			rdd.setReconLogOid(reconLogOid);
			rdd.setReconDate(reconDate);
			rdd.setReconTime(reconTime);
			session.saveOrUpdate(rdd);
			session.flush();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean isCollectedInvoiceNoCheck(String invoiceNo, String parameter1, String corporateCode) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			@SuppressWarnings("unchecked")
			List<invoicePayment> collectedInvoice = criteria.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("invoiceNo", invoiceNo)).add(Restrictions.eq("parameter1", parameter1)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).add(Restrictions.eq("status", true)).list();
			if (collectedInvoice.size() > 0) {
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public static boolean isCollectedInvoiceNoCheckForInstallment(String invoiceNo, int installmentNo, String corporateCode) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			@SuppressWarnings("unchecked")
			List<invoicePayment> collectedInvoice = criteria.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("invoiceNo", invoiceNo)).add(Restrictions.eq("installmentNo", installmentNo)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).add(Restrictions.eq("status", true)).list();
			if (collectedInvoice.size() > 0) {
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

}
