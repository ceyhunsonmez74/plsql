package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.adana.dto.BorcSorgulaResult;
import tr.com.adana.dto.Mesaj;
import tr.com.adana.dto.Mutabakat;
import tr.com.adana.dto.Sonuc;
import tr.com.adana.dto.Tahakkuk;
import tr.com.aktifbank.bnspr.cps.batch.implementations.AskiReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.integration.adana.AdanaWaterClient;
import tr.com.aktifbank.integration.adana.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class AskiServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(AskiServices.class);

	@GraymoundService("ICS_ASKI_INVOICE_DEBT_INQUIRY_NEW")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_INVOICE_DEBT_INQUIRY_NEW");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;

		try {
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);

			ServiceMessage serviceMessage = new ServiceMessage();
			BorcSorgulaResult borcSorgulaResult = AdanaWaterClient.borcSorgula(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessage, aboneNo);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());

			responseCode = borcSorgulaResult.getMesaj().getMESAJ_KODU();
			if (responseCode == null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				int length = borcSorgulaResult.getTahakkukList().size();
				for (int i = 0; i < length; i++) {
					Tahakkuk tahakkuk = borcSorgulaResult.getTahakkukList().get(i);
					if (!isCollectedInvoice(tahakkuk.getID_TAHAKKUK(), aboneNo.toString(), "", "", "", corporateCode, tahakkuk.getSON_ODEME_TARIHI())) {
						String termYear = tahakkuk.getYIL();
						String termMonth = tahakkuk.getAY();
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, aboneNo);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, tahakkuk.getID_TAHAKKUK_DETAY_TIPI());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, tahakkuk.getID_TAHAKKUK());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, tahakkuk.getTOPLAM_BORC());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, tahakkuk.getID_TAHAKKUK_TIPI());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borcSorgulaResult.getSicil().getADI() + " " + borcSorgulaResult.getSicil().getSOYADI());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.formatDateString(tahakkuk.getSON_ODEME_TARIHI(), "yyyy-MM-dd", "yyyyMMdd"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, tahakkuk.getTOPLAM_BORC());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, tahakkuk.getTAHAKKUK_DETAY_ADI());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_INVOICE_DEBT_INQUIRY_NEW.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));

			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_ASKI_DO_INVOICE_COLLECTION_NEW")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_DO_INVOICE_COLLECTION_NEW");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			BigDecimal idTahakkuk = iMap.getBigDecimal(MapKeys.INVOICE_NO);
			String tarih = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyyMMdd");
			} else {
				tarih = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			}
			
			Calendar tahsilatTarihi = CommonHelper.getCalendarWithYYYYMMDD(tarih);

			ServiceMessage serviceMessage = new ServiceMessage();
			BigDecimal tahsilatTutar = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT);
			String bankaReferansID = iMap.getString(MapKeys.TRX_NO);
			Sonuc sonuc = AdanaWaterClient.tahsilEt(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessage, aboneNo, tahsilatTarihi, tahsilatTutar, idTahakkuk, bankaReferansID);

			iMap.put("REQUEST_XML_TAHSILAT_YAP", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT_YAP", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(sonuc.getHATAKOD(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_DO_INVOICE_COLLECTION_NEW");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE_NEW")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE_NEW");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String bankaReferansID = iMap.getString(MapKeys.TRX_NO);
			ServiceMessage serviceMessage = new ServiceMessage();
			BigDecimal aboneNO = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1, null);
			if (aboneNO == null) {
				aboneNO = iMap.getBigDecimal("SUBSCRIBER_NO_1");
			}

			Mesaj mesaj = AdanaWaterClient.tahsilatReferansIptal(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),
					iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), serviceMessage, aboneNO, bankaReferansID);

			iMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessage.getResponse());

			GMMap responceCodeMap = getResponseCodeMapping(mesaj.getMESAJ_KODU(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ASKI_SEND_COLLECTION_CANCEL_MESSAGE");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL_NEW")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL_NEW - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL_NEW");
		try {
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new AskiReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_ASKI_GET_COLLECTION_RECONCILIATION_DETAIL_NEW - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_ASKI_COLLECTION_RECONCILIATION_NEW")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		Mutabakat mutabakat = null;

		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_COLLECTION_RECONCILIATION_NEW");
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String reconDateString = iMap.getString(MapKeys.RECON_DATE);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();

			BigDecimal idKurum = iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			Calendar tahsilatTarihi = CommonHelper.getCalendarWithYYYYMMDD(reconDateString);
			mutabakat = AdanaWaterClient.tahsilatGunlukToplam(serviceUrl, userName, password, serviceMessage, tahsilatTarihi, idKurum);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			if ("0".equals(mutabakat.getADET())) {
				// tahsilat yok ya da hata var
				// sayilari 0 a esitle
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			} else {
				// aldigin sayilari koy
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(mutabakat.getTOPLAM_TAHSILAT()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, Integer.parseInt(mutabakat.getADET()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {

				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);

			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				errorMessage = "Mutabakat basarisiz oldu!Adet ve tutarlar farkli!";
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_BASKENTGAS_SAP_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_ASKI_COLLECTION_RECONCILIATION_CLOSED_NEW")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ASKI_COLLECTION_RECONCILIATION_CLOSED");

		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

}