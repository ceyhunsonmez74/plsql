package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import oski.org.alfabim.abone.tahsilat.model.BakiyeVw;
import oski.org.alfabim.abone.tahsilat.model.WSTahsilat;
import oski.org.alfabim.abone.webService.bean.WSAboneSicil;
import oski.org.alfabim.abone.webService.bean.WsMakbuz;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.oski.OskiClient;
import tr.com.aktifbank.integration.oski.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class OrduWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(OrduWaterServices.class);
	public static String DELIMITER = "-";
	public static String COLLECTION_INFO_DELIMITER = "~";
	public static String MAKBUZ_DELIMITER = ";";
	public static String RECON_DELIMITER = " ";
	public static String RECEIPT_DELIMITER1 = "-";
	public static String RECEIPT_DELIMITER2 = "/";
	public static String BRANCH_CODE = "555";
	public static String PAY_DESK = "1";
	public static BigDecimal SICIL_NO_CANCELLED_VALUE = new BigDecimal(0);
	public static BigDecimal SICIL_NO_SYSTEM_ERROR_VALUE= new BigDecimal(-1);
	public static String SICIL_NO_CANCELLED_ERROR_CODE = "899";
	public static String SICIL_NO_SYSTEM_ERROR_CODE="9999";
	public static String APPROVE_KEY="a�ar�";
	public static String APPROVE_KEY_RECONCILIATION="Tamamland�";

	@GraymoundService("ICS_OSKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_OSKI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		BigDecimal sicilNo = BigDecimal.ZERO;
		String borcAlacak = "";
		String responseCode = "0";
		String invoiceDueDate="";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		GMMap responceCodeMap = new GMMap();
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		BigDecimal bankID = iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
		try {
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			sicilNo = getSicilno(aboneNo,wsUrl, wsUserName, wsPassword);
			if (SICIL_NO_CANCELLED_VALUE.compareTo(sicilNo)==0) {
				responseCode = SICIL_NO_CANCELLED_ERROR_CODE;
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			}else if (SICIL_NO_SYSTEM_ERROR_VALUE.compareTo(sicilNo)==0){		
				responseCode = SICIL_NO_CANCELLED_ERROR_CODE;
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			}
			if(responseCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				ServiceMessage serviceMessage=new ServiceMessage();
				BakiyeVw[] bakiyeVwList = OskiClient.getAboneOrSicilBorc(aboneNo, sicilNo, borcAlacak, wsUrl, wsUserName , wsPassword,serviceMessage);
				iMap.put("REQUEST_TXT", serviceMessage.getRequest());
				outMap.put("RESPONSE_TXT", serviceMessage.getResponse());
				if(bakiyeVwList!=null){
					int length = bakiyeVwList.length;
					if(length==1){
						if (bakiyeVwList[0].getThsAciklama() == null) {
							responseCode = GeneralConstants.ERROR_CODE_APPROVE;
						}else{
							responseCode = bakiyeVwList[0].getThsAciklama();
							responseCode=responseCode.substring(5,8);
						}
				
					}
					for (int i = 0; i < length; i++) {
						BakiyeVw bakiyeVw = bakiyeVwList[i];
						
						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						
						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							if(!isCollectedInvoice( bakiyeVw.getTahakkukNo(), bakiyeVw.getAboneNo().toString(),"","","", corporateCode)){
								String termYear = bakiyeVw.getDonem().toString().substring(0,4);
								String termMonth = bakiyeVw.getDonem().toString().substring(4);
								invoiceDueDate = getStringDate(bakiyeVw.getVade());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, bakiyeVw.getAboneNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, bakiyeVw.getSicilNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, bakiyeVw.getTahakkukNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bakiyeVw.getGecikmeliToplam());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, bakiyeVw.getTur());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, bakiyeVw.getSiraNo());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, bakiyeVw.getAdiSoyadi());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bakiyeVw.getGecikmeliToplam());
								outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, bakiyeVw.getAciklama());
								outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
								outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
								counter++;
							}	
						}
					}
				}
			}
			
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			insertOnlineServiceLog(iMap, outMap);
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_OSKI_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_OSKI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_OSKI_DO_INVOICE_COLLECTION");
		String responseCode = "";
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
	
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal aboneNo = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1);
			String aboneNoString = iMap.getBigDecimal(MapKeys.SUBSCRIBER_NO1).toString();
			BigDecimal sicilNo = getSicilno(aboneNo, wsUrl, wsUserName, wsPassword);
			String sicilNoString = sicilNo.toString();
			String tahsilatTarihi;
			
			if (SICIL_NO_CANCELLED_VALUE.compareTo(sicilNo)==0) {
				responseCode = SICIL_NO_CANCELLED_ERROR_CODE;
			}else if (SICIL_NO_SYSTEM_ERROR_VALUE.compareTo(sicilNo)==0){		
				responseCode = SICIL_NO_SYSTEM_ERROR_CODE;
			}
			
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))){
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"),"dd/MM/yyyy HH:mm:ss");
			}else{
				tahsilatTarihi = CommonHelper.getDateString(new Date(),"dd/MM/yyyy HH:mm:ss");
			}
				
			
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String gecikmeliToplam = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT).toString();
			String tur = iMap.getString(MapKeys.PARAMETER1);
			String siraNo = iMap.getString(MapKeys.INSTALLMENT_NO) != null ? iMap.getBigDecimal(MapKeys.INSTALLMENT_NO).toString() : "";
			String tahsilatInfo = String.format("%s~%s~%s~%s~%s~%s", aboneNoString, sicilNoString, tahakkukNo, gecikmeliToplam, tur, siraNo);
			String aciklama = "";
			String krediKartNo = "";// Varsa, kredi kart�n�n numaras�. Zorunlu
									// de�ildir. Bu alan numeric aland�r bo�
									// de�er g�nderilemez, null veya bir rakam
									// dizisi g�nderilmesi gerekiyor. yani
									// bo�luk karakteri g�nderilemez.
			BigDecimal user = new BigDecimal(wsUserName);
			String sifre = wsPassword;
			BigDecimal txNo = new BigDecimal(iMap.getString(MapKeys.TRX_NO));
			String dekontNo = getOSKIDekont(iMap.getString(MapKeys.TRX_NO));
			BigDecimal bankId = new BigDecimal(0);
			if(!iMap.containsKey("cf615b28a8044f06928ca81f3bab8eb9")){
				ServiceMessage serviceMessage=new ServiceMessage();
				WSTahsilat[] tahsilatList = OskiClient.tahsilatYap(tahsilatInfo, user, sifre, dekontNo, krediKartNo, aciklama,tahsilatTarihi, wsUrl,wsUserName, wsPassword,serviceMessage);
				iMap.put("REQUEST_TXT", serviceMessage.getRequest());
				outMap.put("RESPONSE_TXT", serviceMessage.getResponse());
				int tahsilatListLength = tahsilatList.length;
					responseCode = tahsilatList[0].getAciklama();
					if (responseCode.contains(APPROVE_KEY)) {
						responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					}else{
						responseCode=responseCode.substring(5,8);
					}
					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						saveReceipts(tahsilatList,corporateCode,tahakkukNo,txNo);
					}
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			insertOnlineServiceLog(iMap, outMap);
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_OSKI_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}

	@GraymoundService("ICS_OSKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_OSKI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String aciklama = "";
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
	
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tahsilatIslemTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"),"dd/MM/yyyy");
			String dekontNo = getOSKIDekont(iMap.getString(MapKeys.TRX_NO));
			BigDecimal user = new BigDecimal(wsUserName);
			String makbuzSeri = iMap.getString(MapKeys.CANCEL_PARAMETER3);
			BigDecimal makbuzNo = iMap.getBigDecimal(MapKeys.CANCEL_PARAMETER4);
			String sifre = wsPassword;
			ServiceMessage serviceMessage=new ServiceMessage();
			
			String result = OskiClient.tahsilatIptal(makbuzSeri, makbuzNo, aciklama, user, sifre, tahsilatIslemTarihi ,wsUrl,	wsUserName, wsPassword,serviceMessage);
			iMap.put("REQUEST_TXT", serviceMessage.getRequest());
			outMap.put("RESPONSE_TXT", serviceMessage.getResponse());
			String responseCode = result.substring(5, 8);
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_OSKI_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("STO_OSKI_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_OSKI_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String gsmNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_AVEA_SEND_STANDING_ORDER_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" abone no -> ").concat(gsmNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_AVEA_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_OSKI_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_OSKI_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_OSKI_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" abone no -> ").concat(aboneNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");
			
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_OSKI_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	


	@GraymoundService("ICS_OSKI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_OSKI_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		BigDecimal bankID = iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

	
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(wsUserName);
			String reconLogOid=iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String sifre = wsPassword;
			String giseNo = "";// �ube Kodu-Gi�e No/ �eklinde olacak, e�er gi�e
								// no kullanm�yorsan�z �ube kodu-/ olarak
								// g�ndereceksiniz. veya hi�bir de�er olmayacak
								// bo�luk dahi olmayacak.
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			String responseCode="";
			ServiceMessage serviceMessage=new ServiceMessage();
			WsMakbuz[] makbuzList = OskiClient.gunSonuDetay(giseNo, tarih, user, sifre, bankID, wsUrl, wsUserName, wsPassword,serviceMessage);
			iMap.put("REQUEST_TXT", serviceMessage.getRequest());
			outMap.put("RESPONSE_TXT", serviceMessage.getResponse());
			if(makbuzList == null){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}else{
				responseCode = makbuzList[0].getDekont();
				if (responseCode.contains(RECEIPT_DELIMITER2)) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				} 
			}
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			int makbuzlistLenght = 0;
			if (makbuzList != null) {
				makbuzlistLenght = makbuzList.length;
			

				WsMakbuz makbuz = new WsMakbuz();
				for (int i = 0; i < makbuzlistLenght; i++) {
					makbuz = makbuzList[i];
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.SUBSCRIBER_NO1, makbuz.getKulNo());
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.TRX_NO, getAktifDekont(makbuz.getDekont()));
					reconCorpAmountMap.put("CORPORATE", i, MapKeys.PAYMENT_AMOUNT, makbuz.getToplam());
						// hibenate ile kay�t etmece
				}
			}
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int corporateCollectionCount = makbuzlistLenght;
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			boolean found = false;
			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < bankCollectionCount; j++) {
					for (int i = 0; i < corporateCollectionCount; i++) {
						if (reconBankMap.getString("BANK", j, MapKeys.TRX_NO).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.TRX_NO))&& 
							reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(
										reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat istegi gonder
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.PARAMETER2, reconBankMap.getString("BANK", j, MapKeys.PARAMETER2));
						request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Talimat Mesaji Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
					
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						if ( reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO).equals(
										reconBankMap.getString("BANK", k, MapKeys.TRX_NO))
							 && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(
										reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
						request.put(MapKeys.PARAMETER2, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PARAMETER2));
						request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, request.getString(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString("BANK", j, MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, request.getString(MapKeys.PARAMETER1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getString("BANK", j, MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// TODO Tahsilatta hata al�nca yakal�yoruz yola devam ediyoruz
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
									onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);																										
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,request.getString(MapKeys.PARAMETER2));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);

					}
				}
			}
		
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_OSKI_GET_COLLECTION_RECONCILIATION_DETAIL");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_OSKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_OSKI_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		BigDecimal bankID = iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

		ServiceMessage serviceMessage=new ServiceMessage();

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(wsUserName);
			String sifre = wsPassword;
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			GMMap responceCodeMap = new GMMap();
			String reconciliationResult = OskiClient.getMutabakatToplamAdetTutar("", tarih, user, sifre,bankID, wsUrl, wsUserName,	wsPassword,serviceMessage);
			
			iMap.put("REQUEST_TXT", serviceMessage.getRequest());
			outMap.put("RESPONSE_TXT", serviceMessage.getResponse());
			
			if (reconciliationResult != null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// tahsilat toplam�-tahsilat adeti- iptal toplam�- iptal adeti
				// tahsilat toplam� ve tahsilat adeti de�erlerinde iptal toplam
				// ve adetleri ��kart�lm�� halidir.yani kalan (yek�n)
				String[] splitedReconciliationResult = reconciliationResult.split(COLLECTION_INFO_DELIMITER);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, splitedReconciliationResult[0]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, splitedReconciliationResult[1]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, splitedReconciliationResult[2]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, splitedReconciliationResult[3]);

			}
			
			String toplam = "0";
			String makbuzAdet = "0";
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			toplam = reconBankMap.getString(MapKeys.RECON_COLLECTION_TOTAL);
			makbuzAdet = reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT);
			responseCode = OskiClient.mutbakatIstek(tarih, makbuzAdet, toplam, bankID, wsUrl, wsUserName, wsPassword, serviceMessage);
			if(responseCode.contains(APPROVE_KEY_RECONCILIATION)){
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}else{
				responseCode=responseCode.substring(5,8);
			}
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_OSKI_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;

	}

	@GraymoundService("ICS_OSKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_OSKI_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		BigDecimal bankID = iMap.getBigDecimal(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal user = new BigDecimal(wsUserName);
			String sifre = wsPassword;
			// String tarih = iMap.getString(MapKeys.RECON_DATE_BEGIN);
			ServiceMessage serviceMessage=new ServiceMessage();
			String tarih = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");

			String reconciliationResult = OskiClient.getMutabakatToplamAdetTutar("", tarih, user, sifre,bankID, wsUrl, wsUserName,	wsPassword,serviceMessage);
			
			iMap.put("REQUEST_TXT", serviceMessage.getRequest());
			outMap.put("RESPONSE_TXT", serviceMessage.getResponse());

			if (reconciliationResult != null) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				// tahsilat toplam�-tahsilat adeti- iptal toplam�- iptal adeti
				// tahsilat toplam� ve tahsilat adeti de�erlerinde iptal toplam
				// ve adetleri ��kart�lm�� halidir.yani kalan (yek�n)
				String[] splitedReconciliationResult = reconciliationResult.split(COLLECTION_INFO_DELIMITER);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, splitedReconciliationResult[0]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, splitedReconciliationResult[1]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, splitedReconciliationResult[2]);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, splitedReconciliationResult[3]);

			}

			// /invoice payment dan corporate payment_amount count payment
			// status t I ayr�m� yap
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(
					outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(
							outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_OSKI_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	@GraymoundService("ICS_OSKI_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_OSKI_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode=GeneralConstants.ERROR_CODE_APPROVE;;
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
					iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter=0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
				int bankStandingOrderListLenght = bankStandingOrderList.size();
				
				for (int i = 0; i < bankStandingOrderListLenght; i++) {
					icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
					
					iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
					debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_OSKI_INVOICE_DEBT_INQUIRY", iMap);
					String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);
					
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						int invoiceListeLenght =  debtLoadingMap.getSize("INVOICES");
						for (int j = 0; j < invoiceListeLenght; j++) {
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO1));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2,debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER2));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_NO));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES",j,MapKeys.AMOUNT));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER1));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, debtLoadingMap.getString("INVOICES",j,MapKeys.INSTALLMENT_NO));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, "0");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DUE_DATE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, debtLoadingMap.getString("INVOICES",j,MapKeys.INVOICE_DATE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER3));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER4));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER5));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER6));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER7));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER8));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER9));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, debtLoadingMap.getString("INVOICES",j,MapKeys.PARAMETER10));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO2));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO3));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, debtLoadingMap.getString("INVOICES",j,MapKeys.SUBSCRIBER_NO4));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, debtLoadingMap.getString("INVOICES",j,MapKeys.TERM_MONTH));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, debtLoadingMap.getString("INVOICES",j,MapKeys.TERM_YEAR));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, debtLoadingMap.getString("INVOICES",j,MapKeys.ZONE_CODE));
							counter++;
						}
						
					}
				}
				outMap.put(MapKeys.TABLE_SIZE, counter);
				outMap.put(MapKeys.RESPONSE_CODE, responseCode);
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
				
			insertOnlineServiceLog(iMap, outMap);

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_OSKI_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}

		return outMap;
	}

	public static BigDecimal getSicilno(BigDecimal subscribeNo, String wsUrl, String wsUserName, String wsPassword) {
		BigDecimal sicilNo = new BigDecimal(0);
		try {
		
			WSAboneSicil[] wsAboneSicils = OskiClient.aboneSicilleri(subscribeNo, wsUrl, wsUserName, wsPassword);
			if(wsAboneSicils!=null){
				int s = wsAboneSicils.length;

				for (int i = 0; i < s; i++) {

					if (wsAboneSicils[i].getFesihTarihi() == null || wsAboneSicils[i].getFesihTarihi().toString().isEmpty()) {
						sicilNo = wsAboneSicils[i].getSicilNo();
						break;
					}else{
						sicilNo= new BigDecimal(-1);
					}
				}
			}else{
				sicilNo= new BigDecimal(-1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sicilNo;
	}

	public static boolean isResponseCodeApprove(GMMap inMap) {
		if (!(inMap.getString("RETURN_CODE").equals("0"))) {
			return false;
		} else {
			return true;
		}

	}

	public static String getOSKIDekont(String dekont) {
		String OSKIDekont = BRANCH_CODE + RECEIPT_DELIMITER1 +  PAY_DESK + RECEIPT_DELIMITER2 + dekont;
		return OSKIDekont;
	}

	public static String getAktifDekont(String dekont) {
		String[] splitedDekont = dekont.split(RECEIPT_DELIMITER2);
		String aktifDekont = splitedDekont[1];
		return aktifDekont;
	}
	
	
	public static String getStringDate(Calendar date){
		SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
		String formatted = format1.format(date.getTime());
		return formatted;
	}
	
	public static void saveReceipts(WSTahsilat[] tahsilatList,String corporateCode,String invoiceNo,BigDecimal txNo){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("invoiceNo", invoiceNo))
					.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("txNo", txNo)).uniqueResult();
			invoicePayment.setParameter3(tahsilatList[0].getMakbuzSeri());
			invoicePayment.setParameter4(tahsilatList[0].getMakbuzNo().toString());
			session.saveOrUpdate(invoicePayment);
		} catch (HibernateException e) {
			e.printStackTrace();
			throw e;
		} 
	}
	
	
	


}
