package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.akmercan.AboneBorc;
import tr.com.akmercan.AboneTahsilatToplam;
import tr.com.akmercan.AboneTalimat;
import tr.com.akmercan.ResultOfBool;
import tr.com.akmercan.ResultOfListOfAboneBorc;
import tr.com.akmercan.ResultOfListOfAboneTahsilatToplam;
import tr.com.akmercan.ResultOfListOfAboneTalimat;
import tr.com.akmercan.ResultOfListOfAboneTalimatToplam;
import tr.com.aktifbank.bnspr.cps.batch.implementations.AkmercanNewReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.akmercanNew.AkmercanNewClient;
import tr.com.aktifbank.integration.akmercanNew.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AkmercanNewServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {

	private static final Log logger = LogFactory.getLog(AkmercanNewServices.class);
	private static String PB_CODE = "TL";

	@GraymoundService("ICS_AKMERCAN_MUGLA_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquiry(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			int rowCount = 0;
			String type = "Hepsi";

			ResultOfListOfAboneBorc result = AkmercanNewClient.borcSor(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, subscriberNo, type);

			if (result.getKod().getValue().equals("B3")) {
				for (AboneBorc borc : result.getKayit().getValue().getAboneBorc()) {
					XMLGregorianCalendar dueDateGregorian = borc.getSonOdemeTarih();
					Date dueDate = dueDateGregorian.toGregorianCalendar().getTime();
					String dueDateStr = CommonHelper.getDateString(dueDate, "yyyyMMdd");

					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO1, borc.getAboneNo());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_NO, borc.getBelgeNo().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER4, borc.getTuketiciNo());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.EXPLANATION, borc.getAciklama().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DUE_DATE, dueDateStr);
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SURNAME, borc.getSoyad().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DATE, CommonHelper.getDateString(borc.getTarih().toGregorianCalendar().getTime(), "yyyyMMdd"));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NAME, borc.getAd().getValue()+" "+ borc.getSoyad().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER3, borc.getAnahtar().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.AMOUNT, borc.getTutar());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					rowCount++;
				}
			}
			else {
				responseCode = result.getKod().getValue();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_AKMERCAN_MUGLA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}
		return oMap;
	}

	@GraymoundService("ICS_AKMERCAN_MUGLA_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String amount = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			String key = iMap.getString(MapKeys.PARAMETER3);
			String date = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			ResultOfBool result = AkmercanNewClient.borcOde(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, subscriberNo, key, amount, date, PB_CODE);

			if (result != null && !result.getKod().getValue().equals("B3")) {
				responseCode = result.getKod().getValue();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_AKMERCAN_MUGLA_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_AKMERCAN_MUGLA_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String subscriberNo = iMap.getString(MapKeys.CANCEL_SUBSCRIBER_NO1);
			String amount = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			String key = iMap.getString(MapKeys.PARAMETER_3);
			String date = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			ResultOfBool result = AkmercanNewClient.borcIptal(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, subscriberNo, key, amount, date, PB_CODE);

			if (result != null && !result.getKod().getValue().equals("B3")) {
				responseCode = result.getKod().getValue();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_AKMERCAN_MUGLA_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("STO_AKMERCAN_MUGLA_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String date = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			ResultOfBool result = AkmercanNewClient.talimatVer(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, subscriberNo, date);

			if (result != null && !result.getKod().getValue().equals("B2")) {
				responseCode = result.getKod().getValue();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("STO_AKMERCAN_MUGLA_SEND_STANDING_ORDER_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("STO_AKMERCAN_MUGLA_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String date = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");

			ResultOfBool result = AkmercanNewClient.talimatIptal(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, subscriberNo, date);

			if (result != null && !result.getKod().getValue().equals("B4")) {
				responseCode = result.getKod().getValue();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("STO_AKMERCAN_MUGLA_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_AKMERCAN_MUGLA_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String type = "Hepsi";
			String date = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			int rowCount = 0;

			ResultOfListOfAboneBorc result = AkmercanNewClient.sonOdemeTarihiGelmisBorclar(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, date, type);

			if (result.getKod().getValue().equals("B3")) {
				for (AboneBorc borc : result.getKayit().getValue().getAboneBorc()) {
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO1, borc.getAboneNo());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_NO, borc.getBelgeNo().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER4, borc.getTuketiciNo());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.EXPLANATION, borc.getAciklama().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateString(borc.getSonOdemeTarih().toGregorianCalendar().getTime(), "yyyyMMdd"));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SURNAME, borc.getSoyad().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DATE, CommonHelper.getDateString(borc.getTarih().toGregorianCalendar().getTime(), "yyyyMMdd"));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NAME, borc.getAd().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER3, borc.getAnahtar().getValue());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.AMOUNT, borc.getTutar());
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					oMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
					rowCount++;
				}
				oMap.put(MapKeys.TABLE_SIZE, rowCount);
			}
			else {
				responseCode = result.getKod().getValue();
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		}
		catch (Exception e) {
			logger.error("ICS_AKMERCAN_MUGLA_DEBT_INQUERY_FOR_STANDING_ORDER for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("STO_AKMERCAN_MUGLA_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String date = CommonHelper.formatDateString(reconDate, "yyyyMMdd", "dd.MM.yyyy");
			String type = "Hepsi";

			ResultOfListOfAboneTalimat result = AkmercanNewClient.talimatliAboneler(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, date, type);

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			String iptalList = "";
			String talimatList = "";

			if (result == null) {
				oMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderList.size());
				oMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
				oMap.put(MapKeys.RECON_CORPORATE_COUNT, 0);
				oMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
			}
			else {
				for (AboneTalimat talimat : result.getKayit().getValue().getAboneTalimat()) {
					String subscriberNo = talimat.getAboneNo().toString();
					boolean found = false;
					for (int i = 0; i < bankStandingOrderList.size(); i++) {
						if (bankStandingOrderList.get(i).getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
							String bankSubscriberNo = CommonHelper.trimStart(bankStandingOrderList.get(i).getSubscriberNo1(), '0');
							if (bankSubscriberNo.equals(subscriberNo)) {
								found = true;
							}
						}
					}

					if (!found) {
						iptalList = iptalList.concat(subscriberNo).concat(";");
						try {
							iMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNo);
							GMServiceExecuter.call("STO_AKMERCAN_MUGLA_SEND_STANDING_ORDER_CANCEL_MESSAGE", iMap);
						}
						catch (GMRuntimeException e) {
							logger.info("STO_AKMERCAN_MUGLA_STANDING_ORDER_RECONCILIATION ".concat(subscriberNo).concat(" iptalinde hata : ").concat(e.getMessage()));
						}
					}
				}

				int bankStandingOrderCounter = 0;
				for (int i = 0; i < bankStandingOrderList.size(); i++) {
					if (bankStandingOrderList.get(i).getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Active)) {
						String bankSubscriberNo = bankStandingOrderList.get(i).getSubscriberNo1();
						boolean found = false;
						for (AboneTalimat talimat : result.getKayit().getValue().getAboneTalimat()) {
							String subscriberNo = talimat.getAboneNo().toString();
							if (bankSubscriberNo.equals(subscriberNo)) {
								found = true;
							}
						}

						if (!found) {
							talimatList = talimatList.concat(bankSubscriberNo).concat(";");
							try {
								iMap.put(MapKeys.SUBSCRIBER_NO1, bankSubscriberNo);
								GMServiceExecuter.call("STO_AKMERCAN_MUGLA_SEND_STANDING_ORDER_MESSAGE", iMap);
							}
							catch (GMRuntimeException e) {
								logger.info("STO_AKMERCAN_MUGLA_STANDING_ORDER_RECONCILIATION ".concat(bankSubscriberNo).concat(" talimat hata : ").concat(e.getMessage()));
							}
						}
						bankStandingOrderCounter++;
					}
				}

				oMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCounter);
				oMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
				oMap.put(MapKeys.RECON_CORPORATE_COUNT, result.getKayit().getValue().getAboneTalimat().size());
				oMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);

				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}

			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());
		}
		catch (Exception e) {
			logger.error("STO_AKMERCAN_MUGLA_STANDING_ORDER_RECONCILIATION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("STO_AKMERCAN_MUGLA_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String date = CommonHelper.formatDateString(reconDate, "yyyyMMdd", "dd.MM.yyyy");
			String type = "Hepsi";

			ResultOfListOfAboneTalimatToplam result = AkmercanNewClient.talimatliAbonelerToplam(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, date, type);

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			String iptalList = "";
			String talimatList = "";

		}
		catch (Exception e) {
			logger.error("STO_AKMERCAN_MUGLA_GET_STANDING_ORDER_RECONCILIATION_DETAIL for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_AKMERCAN_MUGLA_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String clientId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String date = CommonHelper.formatDateString(reconDate, "yyyyMMdd", "dd.MM.yyyy");
			String type = "Hepsi";

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);

			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			oMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);

			ResultOfListOfAboneTahsilatToplam result = AkmercanNewClient.yapilanTahsilatlarToplam(reqTimeout, connTimeout, serviceUrl, username, password, sm, clientId, date, type);
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());

			logger.info("ICS_AKMERCAN_MUGLA_COLLECTION_RECONCILIATION - result() null degil");
			if (result != null && result.getKayit().getValue().getAboneTahsilatToplam().size() > 0) {
				BigDecimal corporateTotal = BigDecimal.ZERO;
				int corporateCount = 0;
				for (AboneTahsilatToplam tahsilatToplam : result.getKayit().getValue().getAboneTahsilatToplam()) {
					corporateTotal = corporateTotal.add(tahsilatToplam.getTutar());
					corporateCount = corporateCount + tahsilatToplam.getSayi();
				}

				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, !corporateTotal.equals(BigDecimal.ZERO) ? corporateTotal : BigDecimal.ZERO);
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, corporateCount != 0 ? corporateCount : 0);
			}
			else {
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, BigDecimal.ZERO);
				oMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
			}

			if (oMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(oMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && oMap.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == oMap.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) {
				oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			}
			else {
				oMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			oMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			oMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			oMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_AKMERCAN_MUGLA_COLLECTION_RECONCILIATION for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_AKMERCAN_MUGLA_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();

		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			AkmercanNewReconciliationDetailBatch batch = new AkmercanNewReconciliationDetailBatch(iMap, sm);
			oMap = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			oMap.put("RESPONSE_XML", sm.getResponse());
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			logger.error("ICS_AKMERCAN_MUGLA_GET_COLLECTION_RECONCILIATION_DETAIL for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e);
			oMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			oMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			oMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, oMap);
		}

		return oMap;
	}

	@GraymoundService("ICS_AKMERCAN_MUGLA_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AKMERCAN_MUGLA_COLLECTION_RECONCILIATION_CLOSED");
		try {
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal paymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int paymentCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("BANK", 0, MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
			output.put("BANK", 0, MapKeys.RECON_CORPORATE_CANCEL_TOTAL, BigDecimal.ZERO);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("CORPORATE", 0, MapKeys.RECON_BANK_CANCEL_COUNT, 0);
			output.put("CORPORATE", 0, MapKeys.RECON_CORPORATE_CANCEL_TOTAL, BigDecimal.ZERO);

			output.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

}
