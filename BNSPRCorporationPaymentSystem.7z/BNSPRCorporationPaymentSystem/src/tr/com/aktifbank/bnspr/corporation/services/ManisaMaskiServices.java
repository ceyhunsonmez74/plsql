package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.ManisaMaskiReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.manisa.maski.services.ManisaMaskiClient;
import tr.com.aktifbank.integration.manisa.maski.services.ServiceMessage;
import tr.com.aktifbank.integration.manisa.maski.ws.BorcSorgulaResultModel;
import tr.com.aktifbank.integration.manisa.maski.ws.GenelMutabakatResultModel;
import tr.com.aktifbank.integration.manisa.maski.ws.TahsilatIptalResultModel;
import tr.com.aktifbank.integration.manisa.maski.ws.TahsilatResultModel;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ManisaMaskiServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(ManisaMaskiServices.class);
	public static String DELIMITER = "-";
	public static String COLLECTION_INFO_DELIMITER = "~";
	public static String RECON_DELIMITER = " ";
	public static String RECEIPT_DELIMITER1 = "-";
	public static String RECEIPT_DELIMITER2 = "/";
	public static String BRANCH_CODE = "555";
	public static String PAY_DESK = "1";
	public static BigDecimal SICIL_NO_CANCELLED_VALUE = new BigDecimal(0);
	public static BigDecimal SICIL_NO_SYSTEM_ERROR_VALUE = new BigDecimal(-1);
	public static String SICIL_NO_CANCELLED_ERROR_CODE = "899";
	public static String SICIL_NO_SYSTEM_ERROR_CODE = "999";
	public static int WATER_DEBT_SERVICE_NO = 2342;

	@GraymoundService("ICS_MANISAMASKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInqueryMaski(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MANISAMASKI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;

		try {
			String vezneNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String aboneNoStr = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			int aboneNo = 0;
			if (StringUtils.isNotEmpty(aboneNoStr)) {
				String aboneNoTrmStr = CommonHelper.trimStart(aboneNoStr, '0');
				aboneNo = Integer.parseInt(aboneNoTrmStr);
			}

			ServiceMessage serviceMessageGetAboneBorc = new ServiceMessage();
			BorcSorgulaResultModel[] borcList = ManisaMaskiClient.getAboneBorc(aboneNo, vezneNo, sifre, url, serviceMessageGetAboneBorc);
			iMap.put("REQUEST_XML_GET_ABONE_BORC", serviceMessageGetAboneBorc.getRequest());
			outMap.put("RESPONSE_XML_GET_ABONE_BORC", serviceMessageGetAboneBorc.getResponse());
			int length = borcList.length;
			Map<String, Integer> termGroupList = new HashMap<String, Integer>();
			int groupCounter = 1;
			for (int i = 0; i < length; i++) {
				BorcSorgulaResultModel borc = borcList[i];
				if (borc.getBorcServisNo() != WATER_DEBT_SERVICE_NO) {
					continue;
				}
				responseCode = String.valueOf(borc.getHataKodu());
				if (responseCode == null) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					if (!isCollectedInvoice(String.valueOf(borc.getBorcTekilNumara()), String.valueOf(borc.getAboneNo()), "", "", "", corporateCode)) {
						String termYear = String.valueOf(borc.getYil());
						String termMonth = Integer.toString(borc.getDonem());
						String groupId = "";
						String term = termYear.concat(termMonth).concat(String.valueOf(borc.getBeyanBeyanNo()));
						if (termGroupList.containsKey(term)) {
							groupId = String.valueOf(termGroupList.get(term));
						}
						else {
							groupId = String.valueOf(groupCounter++);
							termGroupList.put(term, Integer.valueOf(groupId));
						}
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getAboneNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getFaturaNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, new BigDecimal(borc.getTutar() + borc.getGecikmeZammi()).setScale(2, RoundingMode.HALF_UP));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getDonem());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAboneAdSoyadUnvan());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getSonOdemeTarihi().getTime());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getTutar());
						outMap.put(MapKeys.INVOICE_LIST, counter, "DESCRIPTION", borc.getAciklama().toString());
						outMap.put(MapKeys.INVOICE_LIST, counter, "GROUP_ID", groupId);
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_MASKI_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw e2;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_MANISAMASKI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MANISAMASKI_DO_INVOICE_COLLECTION");
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int aboneNo = iMap.getInt(MapKeys.SUBSCRIBER_NO1);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);

			String vezneNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			TahsilatResultModel[] tahsilatList = null;
			ServiceMessage serviceMessageGetAboneBorc = new ServiceMessage();
			BorcSorgulaResultModel[] borcList = ManisaMaskiClient.getAboneBorc(aboneNo, vezneNo, sifre, url, serviceMessageGetAboneBorc);
			iMap.put("REQUEST_XML_GET_ABONE_BORC", serviceMessageGetAboneBorc.getRequest());
			outMap.put("REQUEST_XML_GET_ABONE_BORC", serviceMessageGetAboneBorc.getResponse());
			int length = borcList.length;
			for (int i = 0; i < length; i++) {
				BorcSorgulaResultModel[] borc = new BorcSorgulaResultModel[] { borcList[i] };
				if (borc[0].getFaturaNo().equals(tahakkukNo)) {
					try {
						ServiceMessage serviceMessageTahsilat = new ServiceMessage();
						tahsilatList = ManisaMaskiClient.tahsilat(borc, Calendar.getInstance(), iMap.getString("STAN"), vezneNo, sifre, url, serviceMessageTahsilat);
						iMap.put("REQUEST_XML_TAHSILAT", serviceMessageTahsilat.getRequest());
						outMap.put("REQUEST_XML_TAHSILAT", serviceMessageTahsilat.getResponse());
						responseCode = Integer.toString(tahsilatList[0].getHataKodu());
						break;
					}
					catch (Exception e) {
						responseCode = "2801";
						break;
					}
				}
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				outMap.put("TAHSILAT", 0, "MAKBUZ_NO", tahsilatList[0].getMakbuzNumarasi());
				outMap.put("TAHSILAT", 0, "MAKBUZ_SERI", tahsilatList[0].getMakbuzSeri());

				outMap.put(MapKeys.CORPORATE_PAYMENT_ID, tahsilatList[0].getMakbuzNumarasi());
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter3(Integer.toString(tahsilatList[0].getMakbuzNumarasi()));
				invoicePayment.setParameter4(tahsilatList[0].getMakbuzSeri());
				session.saveOrUpdate(invoicePayment);

			}
			else {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_MANISAMASKI_DO_INVOICE_COLLECTION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_MANISAMASKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MANISAMASKI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String vezneNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			int makbuzNo = iMap.getInt("PARAMETER_3");
			if (makbuzNo == 0) {
				makbuzNo = iMap.getInt(MapKeys.PARAMETER3);
			}

			String makbuzSeri = iMap.getString("PARAMETER_4");
			if (makbuzSeri == null) {
				makbuzSeri = iMap.getString(MapKeys.PARAMETER4);
			}

			ServiceMessage serviceMessageTahsilatIptal = new ServiceMessage();
			TahsilatIptalResultModel response = ManisaMaskiClient.tahsilatIptal(makbuzSeri, makbuzNo, vezneNo, sifre, url, serviceMessageTahsilatIptal);
			iMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessageTahsilatIptal.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessageTahsilatIptal.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(Integer.toString(response.getHataKodu()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_MANISAMASKI_SEND_COLLECTION_CANCEL_MESSAGE");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_MANISAMASKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MANISAMASKI_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));

			String vezneNo = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sifre = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessageGenelMutabakat = new ServiceMessage();
			GenelMutabakatResultModel reconciliationResult = ManisaMaskiClient.genelMutabakat(reconDate, vezneNo, sifre, url, serviceMessageGenelMutabakat);
			iMap.put("REQUEST_XML_GENEL_MUTABAKAT", serviceMessageGenelMutabakat.getRequest());
			outMap.put("REQUEST_XML_GENEL_MUTABAKAT", serviceMessageGenelMutabakat.getResponse());
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				logger.info("error Code equals ERROR CODE APPROVE");
				if (reconciliationResult == null) {
					logger.info("reconciliationResult is null");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				}
				else {
					logger.info("reconciliationResult is not null");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconciliationResult.getToplamTahsilatTutari());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconciliationResult.getToplamTahsilatAdedi());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconciliationResult.getToplamIptalTutari());
					logger.info("corporate iptal tutari " + reconciliationResult.getToplamIptalTutari());
					logger.info("corporate iptal adedi " + reconciliationResult.getToplamIptalAdedi());
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconciliationResult.getToplamIptalAdedi());
				}
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				logger.info("reconciliation succeeded");
			}
			else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				logger.info("reconciliation failed");
			}
		}
		catch (Exception e2) {
			logger.error("An exception occured while executing ICS_MANISAMASKI_COLLECTION_RECONCILIATION");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_MANISAMASKI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {

		GMMap output = new GMMap();
		logger.info("ICS_MANISAMASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MANISAMASKI_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage sm = new ServiceMessage();
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			CollectionReconciliationDetailBatch batch = new ManisaMaskiReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Throwable e) {
			logger.info("ICS_MANISAMASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_MANISAMASKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MANISAMASKI_COLLECTION_RECONCILIATION_CLOSED");
		try {
			String screenRecon = iMap.getString("SCREEN_RECONCILIATION", "");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Session session = CommonHelper.getHibernateSession();
			if (screenRecon.equals("1")) {
				setCollectionInfoToOutput(output, reconDate, corporateCode, session);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	public static boolean isResponseCodeApprove(GMMap inMap) {
		if (!(inMap.getString("RETURN_CODE").equals("0"))) {
			return false;
		}
		else {
			return true;
		}

	}

	public static String getSibeskiDekont(String dekont) {
		String SibeskiDekont = BRANCH_CODE + RECEIPT_DELIMITER1 + PAY_DESK + RECEIPT_DELIMITER2 + dekont;
		return SibeskiDekont;
	}

	public static String getAktifDekont(String dekont) {
		String[] splitedDekont = dekont.split(RECEIPT_DELIMITER2);
		String aktifDekont = splitedDekont[1];
		return aktifDekont;
	}

}
