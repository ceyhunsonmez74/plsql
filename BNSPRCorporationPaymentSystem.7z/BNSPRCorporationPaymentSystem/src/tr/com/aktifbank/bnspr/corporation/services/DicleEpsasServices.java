package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.DicleReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.aydem.dicle.bankalar.DicleClient;
import com.aydem.dicle.bankalar.ServiceMessage;
import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

import dicleborc.Fatura;
import dicleborc.holders.ArrayOfFaturaHolder;
import dicleborc.holders.TahsilatOzetHolder;
import diclemark.MarkFatura;
import diclemark.UnMarkFatura;

public class DicleEpsasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(DicleEpsasServices.class);

	@GraymoundService("ICS_DICLE_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DICLE_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		String hataMesaji = "";
		boolean errorOccured = false;
		int sorguTipi = 1;

		try {
			int tesisatNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			logger.info("ICS_DICLE_INVOICE_DEBT_INQUIRY is called for subscriber no : ".concat(Integer.toString(tesisatNo)));
			ServiceMessage serviceMessage = new ServiceMessage();
			ArrayOfFaturaHolder borcList = null;
			try {
				borcList = DicleClient.getBorc(tesisatNo, sorguTipi, username, password, url, serviceMessage);
				if (!serviceMessage.getParameter1().equals(responseCode)) {
					responseCode = "4263";
					hataMesaji = "Fatura sorgulama s�ras�nda hata meydana geldi.��lem ba�ar�s�z.";
					logger.info("ICS_DICLE_INVOICE_DEBT_INQUIRY -> fatura sorgulama s�ras�nda hata meydana geldi.");
				}
				logger.info("ICS_DICLE_INVOICE_DEBT_INQUIRY returned ".concat(Integer.toString(borcList.value.length).concat(" number of invoice.")));
			} catch (Exception e) {
				responseCode = "4263";
				hataMesaji = "Tesisat numaras� bulunamad� ya da hata meydana geldi.";
				errorOccured = true;
				logger.info("ICS_DICLE_INVOICE_DEBT_INQUIRY is called getBorc and an error occured while calling remote service ".concat(responseCode).concat(" and error message is : ").concat(hataMesaji));
				logger.info("ICS_DICLE_INVOICE_DEBT_INQUIRY is called an error occured : ".concat(CommonHelper.getStringifiedException(e)));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			if (!errorOccured) {
				if (borcList == null) {
					responseCode = "2733";
					logger.info("ICS_DICLE_INVOICE_DEBT_INQUIRY -> kurum borc sorgulamas� null deger donuyor...");
				} else if (borcList.value.length == 0) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					logger.info("ICS_DICLE_INVOICE_DEBT_INQUIRY -> fatura sorgulamas�ndan hi� fatura d�nmedi...");
				}
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (Fatura borc : borcList.value) {
					if (!isCollectedInvoiceNo(borc.getFaturaNo(), corporateCode)) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, Integer.toString(tesisatNo));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getFaturaNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplamTutar());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getUnvan());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getSonOdemeTarihi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplamTutar());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			} else {
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			}
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			logger.info("ICS_DICLE_INVOICE_DEBT_INQUIRY -> borc sorgulamada hata meydana geldi...".concat(hataMesaji).concat(CommonHelper.getStringifiedException(e2)));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_DICLE_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DICLE_DO_INVOICE_COLLECTION");
		String responseCode = "";
		GMMap responceCodeMap = new GMMap();
		try {
			String hataMesaji = "";
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String faturaNo = iMap.getString(MapKeys.INVOICE_NO);
			int tesisatNo = Integer.parseInt(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			logger.info("ICS_DICLE_DO_INVOICE_COLLECTION is called for subscriber no ".concat(Integer.toString(tesisatNo).concat(" and invoice no ").concat(faturaNo)));
			ServiceMessage serviceMessage = new ServiceMessage();
			MarkFatura response = null;
			try {
				response = DicleClient.markFatura(tesisatNo, faturaNo, username, password, url, serviceMessage);
				responseCode = Integer.toString(response.getResultCode());
				if (responseCode.equals("0")) {
					responseCode = "4263";
					hataMesaji = "Fatura �deme s�ras�nda hata meydana geldi.��lem ba�ar�s�z.";
					logger.info("ICS_DICLE_DO_INVOICE_COLLECTION -> fatura �deme s�ras�nda hata meydana geldi.");
				} else if (responseCode.equals("-1")) {
					responseCode = "4263";
					hataMesaji = "Fatura zaten daha �nce �denmi�tir.M�kerrer �deme meydana geldi.";
					logger.info("ICS_DICLE_DO_INVOICE_COLLECTION -> M�kerrer �deme meydana geldi.");
				} else if (responseCode.equals("1")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					logger.info("ICS_DICLE_DO_INVOICE_COLLECTION -> fatura basarili olarak odendi");
				}
			} catch (Exception e) {
				responseCode = "4263";
				hataMesaji = "Fatura No bulunamadi ya da tesisat no ile e�le�miyor";
				logger.info("ICS_DICLE_DO_INVOICE_COLLECTION is called markFatura and an error occured while calling remote service ".concat(responseCode).concat(" and error message is : ").concat(hataMesaji));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			logger.info("ICS_DICLE_DO_INVOICE_COLLECTION is called markFatura and an error occured while calling remote service ".concat(responseCode).concat(" and error message is : ").concat(CommonHelper.getStringifiedException(e2)));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String hataMesaji = "";
			String faturaNo = iMap.getString(MapKeys.INVOICE_NO);
			int tesisatNo = Integer.parseInt(iMap.getString("SUBSCRIBER_NO_1"));
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			ServiceMessage serviceMessage = new ServiceMessage();
			logger.info("ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE is called for subscriber no ".concat(Integer.toString(tesisatNo).concat(" and invoice no ").concat(faturaNo)));
			try {
				UnMarkFatura response = DicleClient.unMarkFatura(tesisatNo, faturaNo, username, password, url, serviceMessage);
				responseCode = Integer.toString(response.getResultCode());
				if (responseCode.equals("0")) {
					responseCode = "4263";
					hataMesaji = "Fatura iptal s�ras�nda hata meydana geldi.��lem ba�ar�s�z.";
					logger.info("ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE -> fatura iptali sirasinda hata meydana geldi");
				} else if (responseCode.equals("-1")) {
					responseCode = "4263";
					hataMesaji = "�ptal edilecek fatura tahsilati bulunamad�";
					logger.info("ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE -> iptal edilecek fatura bulunamadi");
				} else if (responseCode.equals("1")) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
					logger.info("ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE -> fatura basarili olarak iptal edildi.");
				}
			} catch (Exception e) {
				responseCode = "4263";
				hataMesaji = "Fatura No bulunamadi ya da tesisat no ile e�le�miyor";
				logger.info("ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE is called markFatura and replied with response code ".concat(responseCode).concat(" and error message is : ").concat(hataMesaji));
			}
			iMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessage.getRequest());
			outMap.put("REQUEST_XML_TAHSILAT_IPTAL", serviceMessage.getResponse());
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

		} catch (Exception e2) {
			logger.info("ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE is called markFatura and replied with response code ".concat(responseCode).concat(" and error message is : ").concat(CommonHelper.getStringifiedException(e2)));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			logger.info("ICS_DICLE_SEND_COLLECTION_CANCEL_MESSAGE -> fatura iptalinde hata meydana geldi".concat(CommonHelper.getStringifiedException(e2)));
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_DICLE_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_DICLE_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tesisatNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_DICLE_SEND_STANDING_ORDER_MESSAGE called for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(tesisatNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_DICLE_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_DICLE_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_DICLE_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String tesisatNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			logger.info("STO_DICLE_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" subscriber no 1 -> ").concat(tesisatNo));
			// kurumun otomatik odeme online servisi olmadigi icin hic bir islem
			// yapmadan basarili olarak geri don
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_DICLE_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_DICLE_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_DICLE_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		GMMap stoMap = new GMMap();

		try {
			logger.info("STO_DICLE_STANDING_ORDER_RECONCILIATION is called");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			stoMap = getBankStandingOrdersForDicle(reconDate, corporateCode);
			int reconCollectionCount = stoMap.getInt(MapKeys.RECON_BANK_COUNT);
			outMap.put(MapKeys.RECON_CORPORATE_COUNT, reconCollectionCount);
			outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, "0");
			outMap.put(MapKeys.RECON_BANK_COUNT, reconCollectionCount);
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, "0");

			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("STO_DICLE_STANDING_ORDER_RECONCILIATION finished succesfully");
		return outMap;
	}

	@GraymoundService("ICS_DICLE_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DICLE_COLLECTION_RECONCILIATION_CLOSED");
		try {
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			String fileTransferOid = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "DICLE_EPSAS_FT_OID");

			CommonHelper.callGraymoundServiceOutsideSession("CDM_DICLE_UPDATE_FTL_STATUS", new GMMap().put("FTL_OID", fileTransferOid).put("NEW_STATUS", true));

			GMMap fileInput = new GMMap();
			fileInput.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
			fileInput.put(TransactionConstants.INFORM_BATCH_DATE_GENERAL_KEY, iMap.getString(MapKeys.RECON_DATE));

			CommonHelper.callGraymoundServiceOutsideSession("ICS_INFORM_INVOICE_COLLECTION_STARTER", fileInput);

			CommonHelper.callGraymoundServiceOutsideSession("CDM_DICLE_UPDATE_FTL_STATUS", new GMMap().put("FTL_OID", fileTransferOid).put("NEW_STATUS", false));

		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("CDM_DICLE_UPDATE_FTL_STATUS")
	public static GMMap updateFtlStatus(GMMap input) {
		GMMap output = new GMMap();

		try {
			String oid = input.getString("FTL_OID");
			boolean status = input.getBoolean("NEW_STATUS");
			Session session = CommonHelper.getHibernateSession();

			CorporateFileTransfer transfer = (CorporateFileTransfer) session.createCriteria(CorporateFileTransfer.class).add(Restrictions.eq("oid", oid)).uniqueResult();

			if (transfer != null) {
				transfer.setStatus(status);
				session.saveOrUpdate(transfer);
				session.flush();
			} else {
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, String.format("%s oid ile bir kurum dosya tan�m� bulunamam��t�r.", oid));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return output;
	}

	@GraymoundService("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER is started...");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toDay = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			String toDayToCompare = CommonHelper.getDateString(new Date(), "yyyyMMdd");
			GMMap sorMap = getBankStandingOrdersForDicle(toDay, corporateCode);
			int reconCollectionCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER recon count to check is ".concat(Integer.toString(reconCollectionCount)));
			int count = 0;
			for (int j = 0; j < reconCollectionCount; j++) {
				String subscriberNumber = CommonHelper.trimStart(sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1), '0');
				logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" will be called.."));
				iMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNumber);
				iMap.put(MapKeys.COLLECTION_TYPE, "0");
				iMap.put(MapKeys.COLLECTION_TYPE_NAME, "Fatura Odeme");
				GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_DICLE_INVOICE_DEBT_INQUIRY", iMap);
				int billNumber = reconBankMap.getSize(MapKeys.INVOICE_LIST);
				logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" is called and return map").concat(reconBankMap.toString()).concat(" and bill number is").concat(Integer.toString(billNumber)));
				if (billNumber > 0) {
					for (int z = 0; z < billNumber; z++) {
						logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" compares date invoice date -> ").concat(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE).toString()).concat(" with todays date -> ").concat(toDayToCompare));
						if (toDayToCompare.equals(reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE))) {
							logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER debt inquery for ".concat(subscriberNumber).concat(" returned result which matches due date with today..."));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, subscriberNumber);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_NO));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.AMOUNT));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_TYPE, "0");// collection
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DUE_DATE, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.INVOICE_DUE_DATE));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, corporateCode);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER3, reconBankMap.get(MapKeys.INVOICE_LIST, z, MapKeys.PARAMETER3));
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
							outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							count++;
						}
					}
				}
			}
			logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER returned table size -> ".concat(Integer.toString(count)));
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.info("An exception occured on service ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_DICLE_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DICLE_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String gatewayErrorDesc = "";
		String responseCode = "";
		String errorCode = "";
		try {
			logger.info("ICS_DICLE_COLLECTION_RECONCILIATION is called...");
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			ServiceMessage serviceMessage = new ServiceMessage();
			Date tarih = CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd");
			TahsilatOzetHolder tahsilatOzet = DicleClient.getTahsilatOzet(tarih, username, password, url, serviceMessage);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, tahsilatOzet.value.getToplamTutar());
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, tahsilatOzet.value.getAdet());
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			BigDecimal toplamTutarKurum = new BigDecimal(Double.toString(tahsilatOzet.value.getToplamTutar()));
			if (toplamTutarKurum.scale() == 1) {
				toplamTutarKurum = toplamTutarKurum.add(new BigDecimal("0.00"));
			}
			logger.info("ICS_DICLE_COLLECTION_RECONCILIATION bank count -> ".concat(Integer.toString(collectionCount)));
			logger.info("ICS_DICLE_COLLECTION_RECONCILIATION bank total -> ".concat(collectionTotal.toString()));
			logger.info("ICS_DICLE_COLLECTION_RECONCILIATION corporate count -> ".concat(Integer.toString(tahsilatOzet.value.getAdet())));
			logger.info("ICS_DICLE_COLLECTION_RECONCILIATION corproate total -> ".concat(Double.toString(tahsilatOzet.value.getToplamTutar())));

			if ((toplamTutarKurum.equals(new BigDecimal("0.00")) && collectionTotal.equals(new BigDecimal("0"))) || (tahsilatOzet.value.getAdet() == collectionCount && toplamTutarKurum.equals(collectionTotal))) {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				outMap.put(MapKeys.ERROR_DESC, "Mutabakat basarili olarak saglandi.");
				logger.info("ICS_DICLE_COLLECTION_RECONCILIATION mutabakati basarili olarak saglandi....");
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				outMap.put(MapKeys.ERROR_DESC, "Mutabakat basarisiz.Sayi ve tutarlar farkli.");
				logger.info("ICS_DICLE_COLLECTION_RECONCILIATION mutabakat adet tutar farki var....");
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
		} catch (Exception e) {
			logger.info("ICS_DICLE_COLLECTION_RECONCILIATION an error accoured with error code : ".concat(errorCode));
			logger.info("ICS_DICLE_COLLECTION_RECONCILIATION an error accoured with response code : ".concat(responseCode));
			logger.error("ICS_DICLE_COLLECTION_RECONCILIATION -> an error is occured...".concat(CommonHelper.getStringifiedException(e)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e).concat(gatewayErrorDesc));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_DICLE_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		ServiceMessage message = new ServiceMessage();
		message.setParameter1(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4));
		logger.info("ICS_DICLE_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DICLE_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			CollectionReconciliationDetailBatch batch = new DicleReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
		} catch (Throwable e) {
			logger.info("ICS_EDAS_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	public static GMMap getBankStandingOrdersForDicle(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER is called getBankStandingOrdersForGaski...");
		StringBuilder sb = new StringBuilder();
		// sb.append("select * from sto.standing_order_main sm,ics.ics_standing_orders so");
		// sb.append(" where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='").append(corporateCode).append("'");
		// sb.append(" and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' ");
		// sb.append(" and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'");
		sb.append(String.format(QueryRepository.DicleServicesRepository.GET_BANK_STANDING_ORDER, reconcilitionDate, reconcilitionDate, corporateCode));
		GMMap returnMap = DALUtil.getResults(sb.toString(), TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
			logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER found ".concat(Integer.toString(al.size())).concat(" standing order for DICLE"));
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
			logger.info("ICS_DICLE_DEBT_INQUERY_FOR_STANDING_ORDER found 0 standing order");
		}
		return returnMap;
	}
}
