package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import service.BankLogin;
import service.Invoice;
import service.Result;
import service.UserInvoice;
import service.UserSyncPaymentsSummary;
import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.GoknetReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.integration.goknet.GoknetClient;
import tr.com.aktifbank.integration.goknet.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class GoknetServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(GoknetServices.class);

	private static final String LOGIN_SUCCESS_CODE="1";
	private static final String BANK_PAYMENT_TYPE="3";
	@GraymoundService("ICS_GOKNET_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessageInvoice = new ServiceMessage();

		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_GOKNET_INVOICE_DEBT_INQUIRY");

		try{
			
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			String collectionTypeId = "0";
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			ServiceMessage serviceMessageLogin = new ServiceMessage();
			BankLogin  login = GoknetClient.checkBankLogin(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageLogin, firmCode);
			
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			output.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  login.getPResult();
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){

			String pTokenid = login.getPTokenid();
			
			UserInvoice userInvoice = GoknetClient.getUserInvoices(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageInvoice, pTokenid, subscriberNo);
			
			iMap.put("REQUEST_XML", serviceMessageInvoice.getRequest());
			output.put("RESPONSE_XML", serviceMessageInvoice.getResponse());
			
			CommonHelper.insertWsCallLog(iMap, serviceMessageInvoice.getDuration(), serviceMessageInvoice.getStartTime(), serviceMessageInvoice.getEndTime());
			responseCode =  userInvoice.getPResult();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				int counter = 0;
				for (Invoice invoice : userInvoice.getInvoice()) {

					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, invoice.getTutar());
					String[] period = invoice.getDonem().split("-");
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, period[0]);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, period[1]);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, invoice.getFaturaID());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(invoice.getSonOdemeTarihi(), "yyyy-MM-dd"));
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, invoice.getTamIsim());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, invoice.getTutar());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));

					output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}
			
			
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", serviceMessageInvoice.getRequest());
			output.put("RESPONSE_XML", serviceMessageInvoice.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_GOKNET_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GOKNET_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String pInvoiceid = iMap.getString(MapKeys.INVOICE_NO);
			String pReferenceuniqueid = iMap.getString(MapKeys.TRX_NO);

			
			String pPaymentdate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd HH:mm:ss");
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				pPaymentdate = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd HH:mm:ss");
			}
			ServiceMessage serviceMessageLogin = new ServiceMessage();
			BankLogin  login = GoknetClient.checkBankLogin(reqTimeout, connTimeout, url, userName, passWord, serviceMessageLogin, firmCode);
			
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  login.getPResult();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){

			String pTokenid = login.getPTokenid();
			responseCode = "0";
			String responseMessage = "";
			String pAmount = iMap.getString(MapKeys.INVOICE_AMOUNT);
			Result response = GoknetClient.addPayment(reqTimeout, connTimeout, url, userName, passWord, serviceMessage, pAmount, pPaymentdate, pReferenceuniqueid, pTokenid, pInvoiceid, BANK_PAYMENT_TYPE);
				responseCode = response.getPResult();
				responseMessage = response.getMessage();
			
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_GOKNET_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GOKNET_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int faturaId = iMap.getInt(MapKeys.INVOICE_NO);
			String pReferenceuniqueid = iMap.getString(MapKeys.TRX_NO,"0");
			String pInvoiceid = iMap.getString(MapKeys.INVOICE_NO);

			ServiceMessage serviceMessageLogin = new ServiceMessage();
			BankLogin  login = GoknetClient.checkBankLogin(reqTimeout, connTimeout, url, username, password, serviceMessageLogin, firmCode);
			
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  login.getPResult();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				String pTokenid = login.getPTokenid();
	
				Result response = GoknetClient.cancelPayment(reqTimeout, connTimeout, url, username, password, serviceMessage, pReferenceuniqueid, pTokenid, pInvoiceid);
				responseCode = response.getPResult();
				String 	responseMessage = response.getMessage();
				
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", serviceMessage.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_GOKNET_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GOKNET_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		GMMap responceCodeMap = new GMMap();

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String pSyncdate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) {
				pSyncdate= CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			} else {
				pSyncdate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
				String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
				String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
				int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
				String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			ServiceMessage serviceMessageLogin = new ServiceMessage();
			BankLogin  login = GoknetClient.checkBankLogin(reqTimeout, connTimeout, url, username, password, serviceMessageLogin, firmCode);
			
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  login.getPResult();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
			
			String pTokenid = login.getPTokenid();
			UserSyncPaymentsSummary result = GoknetClient.getSyncPaymentsSummary(reqTimeout, connTimeout, url, username, password, serviceMessage, pTokenid, pSyncdate);
			responceCodeMap = getResponseCodeMapping(String.valueOf(result.getPResult()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			 errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getSyncPaymentsSummary().get(0).getOdemeTutari()==null ? BigDecimal.ZERO : result.getSyncPaymentsSummary().get(0).getOdemeTutari());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, new BigDecimal(StringUtils.isBlank(result.getSyncPaymentsSummary().get(0).getOdemeAdeti()) ? "0" : result.getSyncPaymentsSummary().get(0).getOdemeAdeti()));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, new BigDecimal(StringUtils.isBlank(result.getSyncPaymentsSummary().get(0).getIptalOdemeAdeti()) ? "0" : result.getSyncPaymentsSummary().get(0).getIptalOdemeAdeti()));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getSyncPaymentsSummary().get(0).getIptalOdemeTutari()==null ? BigDecimal.ZERO : result.getSyncPaymentsSummary().get(0).getIptalOdemeTutari());
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			}

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_GOKNET_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_GOKNET_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GOKNET_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		GMMap responceCodeMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			String firmCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String pSyncdate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) {
				pSyncdate= CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			} else {
				pSyncdate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			ServiceMessage serviceMessageLogin = new ServiceMessage();
			BankLogin  login = GoknetClient.checkBankLogin(reqTimeout, connTimeout, url, username, password, serviceMessageLogin, firmCode);
			
			iMap.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			outMap.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
			
			String responseCode =  login.getPResult();
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				
			String pTokenid = login.getPTokenid(); 
			Result result = GoknetClient.confirmSyncPayments(reqTimeout, connTimeout, url, username, password, serviceMessage, pSyncdate, pTokenid);
			responseCode = result.getPResult();
	
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			// Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

				outMap.putAll(onlineCorporateServiceCallOutputMap);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_GOKNET_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_GOKNET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		GMMap output = new GMMap();
		logger.info("ICS_GOKNET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GOKNET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
//			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
//			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			ServiceMessage message = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new GoknetReconciliationDetailBatch(iMap, message);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_GOKNET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
}
