package tr.com.aktifbank.bnspr.corporation.services;

import java.sql.Clob;
import java.util.List;
import java.util.Map;

import org.apache.axis.utils.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.CorporateChannelPrm;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.OnlineServiceLog;
import tr.com.aktifbank.bnspr.dao.OnlineWsCallLog;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.aktifbank.bnspr.dao.ServiceResponseCodeMapping;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public  class OnlineCorporationInterface {
	
	public OnlineCorporationInterface() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	/**
	 * @description set initial variables
	 * @param 
	 * @return 
	 * @history 
	 * 	@author erdogan.demir		
	 *  @date 10.06.2013
	 *  @specification
	 *  	call service CDM_GET_CORPORATE_WEB_SERVICES_INFO 
	 *  		set CORPORATE_CODE = getCorporateCode() into input map
	 *  		set WS_SERVICE_NAME = getWsServiceName() into input map
	 *  		get service return into output GMMap
	 *  	set variables from output GMMap
	 */
	public static void init() {
		
	}
	
	
	/**
	 * @description set initial variables
	 * @param 
	 * @return 
	 * @history 
	 * 	@author erdogan.demir		
	 * @throws Exception 
	 *  @date 10.06.2013
	 *  @specification
	 *  	prepare parameter string by using method BatchUtilities.decomposeBatchParameters()
	 *      set hibernate object of ONLINE_SERVICE_LOG
	 *      	date and time should be current values
	 *      save and flush 
	 *  
	 */
	
	public static void insertOnlineServiceLog(GMMap insertParameters, GMMap responseMap)  {
		try {
			GMMap iMap = new GMMap();
			iMap.put(MapKeys.INPUT_MAP_STRING, insertParameters.toString());
			if(responseMap.containsKey(MapKeys.ERROR_CODE)){
				 iMap.put(MapKeys.ERROR_CODE, responseMap.getString(MapKeys.ERROR_CODE));
				 String errorDesc = responseMap.getString(MapKeys.ERROR_DESC);
				 if(!StringUtil.isEmpty(errorDesc) && errorDesc.length() > 950){
					 errorDesc = errorDesc.substring(0, 950);
				 }
				 iMap.put(MapKeys.ERROR_DESC, errorDesc);
			}
			iMap.put(MapKeys.RESPONSE_MAP_STRING,responseMap.toString());
			iMap.put(MapKeys.CORPORATE_CODE, insertParameters.getString(MapKeys.CORPORATE_CODE));
			iMap.put(MapKeys.SERVICE_STATUS, insertParameters.getInt(MapKeys.SERVICE_STATUS));
			iMap.put(MapKeys.STAN_NO, insertParameters.getInt(MapKeys.STAN_NO));
			iMap.put(MapKeys.GM_SERVICE_NAME, insertParameters.getString(MapKeys.GM_SERVICE_NAME));
			iMap.put(MapKeys.WS_ENDPOINT, insertParameters.getString(MapKeys.WS_ENDPOINT));
			iMap.put(MapKeys.WS_SERVICE_NAME, insertParameters.getString(MapKeys.WS_SERVICE_NAME));
			
			iMap.put(MapKeys.SUBSCRIBER_NO1, insertParameters.getString(MapKeys.SUBSCRIBER_NO1));
			iMap.put(MapKeys.SUBSCRIBER_NO2, insertParameters.getString(MapKeys.SUBSCRIBER_NO2));
			iMap.put(MapKeys.SUBSCRIBER_NO3, insertParameters.getString(MapKeys.SUBSCRIBER_NO3));
			iMap.put(MapKeys.SUBSCRIBER_NO4, insertParameters.getString(MapKeys.SUBSCRIBER_NO4));
			
			iMap.put(MapKeys.INVOICE_NO, insertParameters.getString(MapKeys.INVOICE_NO));
			
			GMServiceExecuter.executeAsync("ICS_INSERT_ONLINE_LOG", iMap);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@GraymoundService("ICS_INSERT_ONLINE_LOG")
	public static GMMap insertOnlineServiceLogNewTrx(GMMap iMap)  {
		try {
			String inputMapString = iMap.getString(MapKeys.INPUT_MAP_STRING);
			Clob inputMapClob = new ClobImpl(inputMapString);
			String errorCode ="";
			String errorDesc = "";
			
			if(iMap.containsKey(MapKeys.ERROR_CODE)){
				 errorCode = iMap.getString(MapKeys.ERROR_CODE);
				 errorDesc = iMap.getString(MapKeys.ERROR_DESC);
			}

			short serviceStatus = (short)iMap.getInt(MapKeys.SERVICE_STATUS);
			String stanNo = iMap.getString(MapKeys.STAN_NO);
			String responseMapString = iMap.getString(MapKeys.RESPONSE_MAP_STRING);
			
			String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String subscriberNo2 = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String subscriberNo3 = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			String subscriberNo4 = iMap.getString(MapKeys.SUBSCRIBER_NO4);
			
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			
			Clob response =new ClobImpl(responseMapString);
			Session session = DAOSession.getSession("BNSPRDal");
			OnlineServiceLog onlineServiceLog= new OnlineServiceLog();
			onlineServiceLog.setInputMap(inputMapClob);
			onlineServiceLog.setCorporateCode(iMap.getString(MapKeys.CORPORATE_CODE));
			onlineServiceLog.setErrorCode(errorCode);
			onlineServiceLog.setErrorDesc(errorDesc);
			onlineServiceLog.setGmServiceName(iMap.getString(MapKeys.GM_SERVICE_NAME));
			onlineServiceLog.setServiceStatus(serviceStatus);
			onlineServiceLog.setStanNo(stanNo);
			onlineServiceLog.setStatus(true);
			onlineServiceLog.setWsEndPoint(iMap.getString(MapKeys.WS_ENDPOINT));
			onlineServiceLog.setWsServiceName(iMap.getString(MapKeys.WS_SERVICE_NAME));
			onlineServiceLog.setResponse(response);
			
			onlineServiceLog.setSubscriberNo1(subscriberNo1);
			onlineServiceLog.setSubscriberNo2(subscriberNo2);
			onlineServiceLog.setSubscriberNo3(subscriberNo3);
			onlineServiceLog.setSubscriberNo4(subscriberNo4);
			
			onlineServiceLog.setInvoiceNo(invoiceNo);
			
			session.save(onlineServiceLog);
			session.flush();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return iMap;
	}
	
	@GraymoundService("ICS_INSERT_ONLINE_WS_CALL_LOG")
	public static GMMap insertOnlineWsCallLog(GMMap iMap)  {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			OnlineWsCallLog onlineWsCallLog=new OnlineWsCallLog();
			onlineWsCallLog.setCorporateCode(iMap.getString(MapKeys.CORPORATE_CODE));
			onlineWsCallLog.setDuration(iMap.getBigDecimal(MapKeys.DURATION));
			onlineWsCallLog.setEndTime(CommonHelper.getDateTime(iMap.getString(MapKeys.END_TIME), "dd/MM/yyyy hh:mm:ss"));
			onlineWsCallLog.setGmServiceName(iMap.getString(MapKeys.GM_SERVICE_NAME));
			onlineWsCallLog.setStartTime(CommonHelper.getDateTime(iMap.getString(MapKeys.START_TIME), "dd/MM/yyyy hh:mm:ss"));
			onlineWsCallLog.setStatus(true);
			onlineWsCallLog.setWsEndPoint(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			onlineWsCallLog.setWsServiceName(iMap.getString(MapKeys.WS_SERVICE_NAME));
			session.save(onlineWsCallLog);
			session.flush();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return iMap;
	}
		
	public static String getCorporateChannel(String corporateCode, String sourceCode, String channelCode, short collectionType){
		Session hibernateSession = DAOSession.getSession("BNSPRDal");
		CorporateChannelPrm channelParameter = (CorporateChannelPrm)hibernateSession.createCriteria(CorporateChannelPrm.class)
	            .add(Restrictions.eq("status", true))
	            .add(Restrictions.eq("corporateCode", corporateCode))
	            .add(Restrictions.eq("sourceCode", sourceCode))
	            .add(Restrictions.eq("channelCode", channelCode))
	            .add(Restrictions.eq("collectionType", collectionType))
	            .uniqueResult();
		String corporateChannel = channelParameter.getCorporateConstant();
		return corporateChannel;
	}
	
	public static GMMap debtInquiry() {
		return null;
		// TODO Auto-generated method stub
		
	}

	public static GMMap sendCollectionMessage() {
		return null;
		// TODO Auto-generated method stub
		
	}
	
	public static GMMap sendCollectionCancelMessage() {
		return null;
		// TODO Auto-generated method stub
		
	}	

	public static GMMap sendStandingOrderMessage() {
		return null;
		// TODO Auto-generated method stub
		
	}
	
	public static GMMap sendStandingOrderCancelMessage() {
		return null;
		// TODO Auto-generated method stub
		
	}

	public static GMMap getStandinOrderReconciliationDetail() {
		return null;
		// TODO Auto-generated method stub
		
	}
	
	public static GMMap collectionReconciliation() {
		return null;
		// TODO Auto-generated method stub
		
	}
	
	
	




	
	
	
	public static  GMMap getResponseCodeMapping(String responseCode,String serviceOid, String corporateCode) {
		GMMap output = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(ServiceResponseCodeMapping.class);
			Criterion status = Restrictions.eq("status", true);
			Criterion returnCode = Restrictions.eq("returnCode", responseCode);
			Criterion serviceOID = Restrictions.eq("serviceOid", serviceOid);// wrapper dan gelecek 
			Criterion forAllServices = Restrictions.eq("forAllServices", "1");
			Criterion corporateCODE = Restrictions.eq("corporateCode", corporateCode);
			LogicalExpression expression = Restrictions.or(serviceOID, forAllServices);
			criteria.add(expression).add(status).add(returnCode).add(corporateCODE);
			List<ServiceResponseCodeMapping> responseCodeMappingList = criteria.list();
			
			if(responseCodeMappingList.size() > 0){
				for(ServiceResponseCodeMapping responseCodeMapping: responseCodeMappingList){
					output.put("RETURN_CODE",responseCodeMapping.getReturnCode());
					output.put("RETURN_CODE_DESC",responseCodeMapping.getReturnCodeDesc());
					output.put(MapKeys.ERROR_CODE, responseCodeMapping.getErrorCode());
					output.put(MapKeys.ERROR_DESC,responseCodeMapping.getExplanation());
					
				}	
			}else{
				output.put("RETURN_CODE",responseCode);
				output.put("RETURN_CODE_DESC",GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
				output.put(MapKeys.ERROR_CODE,GeneralConstants.ERROR_CODE_NOT_FOUND);
				output.put(MapKeys.ERROR_DESC,GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			}
		} catch (Exception e) {
			output.put("RETURN_CODE",responseCode);
			output.put("RETURN_CODE_DESC",GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			output.put("ERROR_CODE", GeneralConstants.ERROR_CODE_NOT_FOUND);
			output.put("EXPLANATION",GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			e.printStackTrace();
		}
		return output;
	}
	
	public static  GMMap getResponseDescMapping(String responseDesc,String serviceOid, String corporateCode) {
		GMMap output = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(ServiceResponseCodeMapping.class);
			Criterion status = Restrictions.eq("status", true);
			Criterion returnCode = Restrictions.like("returnCodeDesc", responseDesc);
			Criterion serviceOID = Restrictions.eq("serviceOid", serviceOid);// wrapper dan gelecek 
			Criterion forAllServices = Restrictions.eq("forAllServices", "1");
			Criterion corporateCODE = Restrictions.eq("corporateCode", corporateCode);
			LogicalExpression expression = Restrictions.or(serviceOID, forAllServices);
			criteria.add(expression).add(status).add(returnCode).add(corporateCODE);
			List<ServiceResponseCodeMapping> responseCodeMappingList = criteria.list();
			
			if(responseCodeMappingList.size() > 0){
				for(ServiceResponseCodeMapping responseCodeMapping: responseCodeMappingList){
					output.put("RETURN_CODE",responseCodeMapping.getReturnCode());
					output.put("RETURN_CODE_DESC",responseCodeMapping.getReturnCodeDesc());
					output.put(MapKeys.ERROR_CODE, responseCodeMapping.getErrorCode());
					output.put(MapKeys.ERROR_DESC,responseCodeMapping.getExplanation());
					
				}	
			}else{
				output.put("RETURN_CODE",GeneralConstants.ERROR_CODE_NOT_FOUND);
				output.put("RETURN_CODE_DESC",responseDesc);
				output.put(MapKeys.ERROR_CODE,GeneralConstants.ERROR_CODE_NOT_FOUND);
				output.put(MapKeys.ERROR_DESC,GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			}
		} catch (Exception e) {
			output.put("RETURN_CODE",GeneralConstants.ERROR_CODE_NOT_FOUND);
			output.put("RETURN_CODE_DESC",responseDesc);
			output.put("ERROR_CODE", GeneralConstants.ERROR_CODE_NOT_FOUND);
			output.put("EXPLANATION",GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			e.printStackTrace();
		}
		return output;
	}
	public static String getBankCode(String corporateCode){
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<CorporateMaster> corporateMasterList = session
			.createCriteria(CorporateMaster.class)
			.add(Restrictions.eq("status", true))
			.add(Restrictions.eq("corporateCode",corporateCode)).list();
		return corporateMasterList.get(0).getCorporateBankCode();	
	}
	
	public static String getCorporateCollectionType(String corporateCode, Short collectionType){
		Session session = DAOSession.getSession("BNSPRDal");
		String corporateCollectionType = "";
		List<CorporateChannelPrm> corporateCollectionTypeList;
		try {
			corporateCollectionTypeList = session.createCriteria(CorporateChannelPrm.class)
			 .add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("collectionType", collectionType))
			 .add(Restrictions.eq("status", true)).list();
			corporateCollectionType = corporateCollectionTypeList.get(0).getCorporateConstant();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return corporateCollectionType;	
	}
	
	public static String getBankCollectionType(String corporateCode, String corporateConstant){
		Session session = DAOSession.getSession("BNSPRDal");
		String bankteCollectionType = "";
		List<CorporateChannelPrm> corporateCollectionTypeList;
		try {
			corporateCollectionTypeList = session.createCriteria(CorporateChannelPrm.class)
			 .add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("corporateConstant", corporateConstant))
			 .add(Restrictions.eq("status", true)).list();
			bankteCollectionType = corporateCollectionTypeList.get(0).getCollectionType().toString();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bankteCollectionType;	
	}
	
	public static boolean isCollectedInvoiceNo(String invoiceNo, String corporateCode) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			@SuppressWarnings("unchecked")
			List<invoicePayment> collectedInvoice = criteria.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("invoiceNo", invoiceNo)).add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected)).add(Restrictions.eq("status", true)).list();
			if (collectedInvoice.size() > 0) {
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static boolean isCollectedInvoice(String invoiceNo, String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4, String corporateCode ) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			Criterion criterionCorporateCode = Restrictions.eq("corporateCode", corporateCode);
			Criterion criterionPaymentStatus = Restrictions.eq("paymentStatus", PaymentStatuses.Collected);
			Criterion criterionInvoiceNo = Restrictions.eq("invoiceNo", invoiceNo);
			Criterion criterionStatus = Restrictions.eq("status", true);
			Criterion criterionSubscriberNo1 = Restrictions.eq("subscriberNo1", subscriberNo1);
			Criterion criterionSubscriberNo2 = Restrictions.eq("subscriberNo2", subscriberNo2); 
			Criterion criterionSubscriberNo3 = Restrictions.eq("subscriberNo3", subscriberNo3);
			Criterion criterionSubscriberNo4 = Restrictions.eq("subscriberNo4", subscriberNo4); 

			LogicalExpression expression = Restrictions.or(criterionSubscriberNo1, criterionSubscriberNo2);
			LogicalExpression expression2 = Restrictions.or(criterionSubscriberNo3,criterionSubscriberNo4);
			LogicalExpression expression3 = Restrictions.or(expression, expression2);
			criteria.add(expression3).add(criterionStatus).add(criterionInvoiceNo).add(criterionPaymentStatus).add(criterionCorporateCode);
			List<invoicePayment> collectedInvoice = criteria.list();					
			if(collectedInvoice.size()>0){
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static boolean isCollectedInvoice(String invoiceNo, String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4, String corporateCode,String invoiceDueDate ) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			Criterion criterionCorporateCode = Restrictions.eq("corporateCode", corporateCode);
			Criterion criterionPaymentStatus = Restrictions.eq("paymentStatus", PaymentStatuses.Collected);
			Criterion criterionInvoiceNo = Restrictions.eq("invoiceNo", invoiceNo);
			Criterion criterionStatus = Restrictions.eq("status", true);
			Criterion criterionSubscriberNo1 = Restrictions.eq("subscriberNo1", subscriberNo1);
			Criterion criterionSubscriberNo2 = Restrictions.eq("subscriberNo2", subscriberNo2); 
			Criterion criterionSubscriberNo3 = Restrictions.eq("subscriberNo3", subscriberNo3);
			Criterion criterionSubscriberNo4 = Restrictions.eq("subscriberNo4", subscriberNo4); 
			Criterion criterionDueDate = Restrictions.eq("invoiceDueDate", invoiceDueDate); 
			
			LogicalExpression expression = Restrictions.or(criterionSubscriberNo1, criterionSubscriberNo2);
			LogicalExpression expression2 = Restrictions.or(criterionSubscriberNo3,criterionSubscriberNo4);
			LogicalExpression expression3 = Restrictions.or(expression, expression2);
			criteria.add(expression3).add(criterionStatus).add(criterionInvoiceNo).add(criterionPaymentStatus).add(criterionCorporateCode).add(criterionDueDate);
			List<invoicePayment> collectedInvoice = criteria.list();					
			if(collectedInvoice.size()>0){
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static boolean isCollectedInvoice(String invoiceNo, String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4, String corporateCode,int installmentNo) {
		boolean result = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(invoicePayment.class);
			Criterion criterionCorporateCode = Restrictions.eq("corporateCode", corporateCode);
			Criterion criterionPaymentStatus = Restrictions.eq("paymentStatus", PaymentStatuses.Collected);
			Criterion criterionInvoiceNo = Restrictions.eq("invoiceNo", invoiceNo);
			Criterion criterionStatus = Restrictions.eq("status", true);
			Criterion criterionSubscriberNo1 = Restrictions.eq("subscriberNo1", subscriberNo1);
			Criterion criterionSubscriberNo2 = Restrictions.eq("subscriberNo2", subscriberNo2); 
			Criterion criterionSubscriberNo3 = Restrictions.eq("subscriberNo3", subscriberNo3);
			Criterion criterionSubscriberNo4 = Restrictions.eq("subscriberNo4", subscriberNo4);
			Criterion criterionInstallmentNo = Restrictions.eq("installmentNo", installmentNo);

			LogicalExpression expression = Restrictions.or(criterionSubscriberNo1, criterionSubscriberNo2);
			LogicalExpression expression2 = Restrictions.or(criterionSubscriberNo3,criterionSubscriberNo4);
			LogicalExpression expression3 = Restrictions.or(expression, expression2);
			criteria.add(expression3).add(criterionStatus).add(criterionInvoiceNo).add(criterionPaymentStatus).add(criterionCorporateCode).add(criterionInstallmentNo);
			List<invoicePayment> collectedInvoice = criteria.list();					
			if(collectedInvoice.size()>0){
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static boolean isCollectedInvoiceNew(String corporateCode, String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4, String invoiceNo, Object... params){ // installmentNo
		try{
			
			Session hibSession = CommonHelper.getHibernateSession();
			Criteria criteria = hibSession.createCriteria(invoicePayment.class).add(Restrictions.eq("status", true));
			criteria = criteria.add(Restrictions.eq("corporateCode", corporateCode));
			if(!StringUtils.isEmpty(subscriberNo1)){
				criteria = criteria.add(Restrictions.eq("subscriberNo1", subscriberNo1));
			}
			if(!StringUtils.isEmpty(subscriberNo2)){
				criteria = criteria.add(Restrictions.eq("subscriberNo2", subscriberNo2));
			}
			if(!StringUtils.isEmpty(subscriberNo3)){
				criteria = criteria.add(Restrictions.eq("subscriberNo3", subscriberNo3));
			}
			if(!StringUtils.isEmpty(subscriberNo4)){
				criteria = criteria.add(Restrictions.eq("subscriberNo4", subscriberNo4));
			}
			if(!StringUtils.isEmpty(invoiceNo)){
				criteria = criteria.add(Restrictions.eq("invoiceNo", invoiceNo));
			}
			if(params != null && params.length != 0){
				Integer installmentNo = (Integer)params[0];
				if(installmentNo != null){
					criteria = criteria.add(Restrictions.eq("installmentNo", installmentNo));
				}
			}
			
			criteria = criteria.setProjection(Projections.rowCount());
			
			int count = ((Number)criteria.uniqueResult()).intValue();
			
			return count > 0;
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	public static boolean isCollectedInvoiceMaps( Map<String, String> maps){ // installmentNo
		try{
			Session hibSession = CommonHelper.getHibernateSession();
			Criteria criteria = hibSession.createCriteria(invoicePayment.class).add(Restrictions.eq("status", true));
			for (Map.Entry<String, String> entry : maps.entrySet()) {
				criteria = criteria.add(Restrictions.eq(entry.getKey(), entry.getValue()));
			}
			criteria = criteria.setProjection(Projections.rowCount());
			
			int count = ((Number)criteria.uniqueResult()).intValue();
			
			return count > 0;
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	protected static void setCollectionInfoToOutput(GMMap output,
			String reconDate, String corporateCode, Session session) {
		List<ReconLog> list = session.createCriteria(ReconLog.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.add(Restrictions.eq("reconDate", reconDate))
				.add(Restrictions.eq("reconStatus", DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded))
				.add(Restrictions.eq("reconType", DatabaseConstants.ReconciliationTypes.Collection))
				.addOrder(Order.desc("processDate"))
				.addOrder(Order.desc("processTime"))
				.list();
		
		ReconLog log = list.get(0);
		
		output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, log.getBankAmount());
		output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, log.getBankCancelAmount());
		output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, log.getBankCount());
		output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, log.getBankCancelCount());
		
		output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, log.getCorporateAmount());
		output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, log.getCorporateCancelAmount());
		output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, log.getCorporateCount());
		output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, log.getCorporateCancelCount());
		
		output.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);
	}
}
