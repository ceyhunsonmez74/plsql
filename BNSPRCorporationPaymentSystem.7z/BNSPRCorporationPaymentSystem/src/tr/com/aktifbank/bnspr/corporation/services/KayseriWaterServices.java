package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.StandingOrderStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.IcsUpdateStandingOrder;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.kayserisu.BorcSorgulaResult;
import tr.com.aktifbank.integration.kayserisu.KayseriSuOnlineClient;
import tr.com.aktifbank.integration.kayserisu.ReconciliationDetailResult;
import tr.com.aktifbank.integration.kayserisu.ReconciliationResult;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class KayseriWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(KayseriWaterServices.class);
	private static final String OTHER_BANK_TALIMAT = "3306";
	private static final String NOT_FOUND_TALIMAT = "2721";
	private static final String BRANCH_CODE = "555";

	public KayseriWaterServices() {
	}

	@GraymoundService("ICS_KAYSU_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KAYSU_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		try {
			KayseriSuOnlineClient client = getSoapClient(iMap);
			int subscriberNumber = Integer.valueOf(CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0')).intValue();
			String pBankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			ArrayList<BorcSorgulaResult> sorgulaResults = client.borcSorgula(pBankCode, subscriberNumber);

			String responseCode = sorgulaResults.size() == 0 ? null : sorgulaResults.get(0).getERRCODE();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				int counter = 0;
				for (BorcSorgulaResult debt : sorgulaResults) {
					if (!isCollectedInvoice(debt.getIHBARNAME_MAKBUZ_NO(), String.valueOf(subscriberNumber), "", "", "", corporateCode)) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNumber);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debt.getIHBARNAME_MAKBUZ_NO());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, new BigDecimal(StringUtils.isBlank(debt.getODENECEK_MIKTAR()) ? "0" : debt.getODENECEK_MIKTAR().replace(",", ".")));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debt.getABONE_AD_SOYAD());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(debt.getSON_ODEME_TARIHI(), "dd.MM.yyyy"));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, debt.getDONEM_YILI());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, String.format("%02d", Integer.valueOf(debt.getDONEM_SAYISI()).intValue()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, debt.getTAKSIT_SIRASI());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, new BigDecimal(StringUtils.isBlank(debt.getHESAPLANAN_GECIKME_ZAMMI()) ? "0" : debt.getHESAPLANAN_GECIKME_ZAMMI().replace(",", ".")));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, new BigDecimal(StringUtils.isBlank(debt.getTAHSILAT_KALAN_BAKIYE()) ? "0" : debt.getTAHSILAT_KALAN_BAKIYE().replace(",", ".")));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KAYSU_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_KAYSU_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KAYSU_DO_INVOICE_COLLECTION");
		GMMap outMap = new GMMap();
		try {
			KayseriSuOnlineClient client = getSoapClient(iMap);
			int subscriberNumber = Integer.valueOf(CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0')).intValue();
			String pBankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String pBranchCode = StringUtils.isNotBlank(iMap.getString(MapKeys.BRANCH_CODE)) ? iMap.getString(MapKeys.BRANCH_CODE) : BRANCH_CODE;
			String islemreferansno = iMap.getString(MapKeys.TRX_NO);
			int ihbarnameMakbuzNo = iMap.getInt(MapKeys.INVOICE_NO);
			String donemYili = iMap.getString(MapKeys.TERM_YEAR);
			String odemeSekli = "N";
			String tahsilatTarihi = stringLongToStringDate("todaytime");
			String kartNo = String.valueOf(BigDecimal.ZERO);
			String taksitSira = StringUtils.isBlank(iMap.getString(MapKeys.INSTALLMENT_NO)) ? "0" : iMap.getString(MapKeys.INSTALLMENT_NO);
			String hesaplananGecikmeZammi = StringUtils.isEmpty(iMap.getString(MapKeys.PARAMETER3)) ? "0" : iMap.getString(MapKeys.PARAMETER3).replace('.', ',');
			String tahsilatKalanBakiye = StringUtils.isEmpty(iMap.getString(MapKeys.PARAMETER4)) ? "0" : iMap.getString(MapKeys.PARAMETER4).replace('.', ',');
			String odemeMiktari = StringUtils.isEmpty(iMap.getString(MapKeys.PAYMENT_AMOUNT)) ? "0" : iMap.getString(MapKeys.PAYMENT_AMOUNT).replace('.', ',');
			String donemSayisi = iMap.getString(MapKeys.TERM_MONTH);
			BorcSorgulaResult result = client.tahsilatOlustur(pBankCode, subscriberNumber, Short.valueOf(donemYili), Short.valueOf(donemSayisi), ihbarnameMakbuzNo, Short.valueOf(taksitSira), tahsilatKalanBakiye, hesaplananGecikmeZammi, odemeMiktari, odemeSekli, kartNo, tahsilatTarihi, islemreferansno, pBranchCode);

			String responseCode = result.getERRCODE();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), iMap.getString(MapKeys.CORPORATE_CODE));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("TAHSILAT", 0, "MAKBUZ_NO", result.getIHBARNAME_MAKBUZ_NO());
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter2(pBranchCode);
				invoicePayment.setParameter5(donemSayisi);
				invoicePayment.setParameter6(donemYili);
				session.saveOrUpdate(invoicePayment);
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KAYSU_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_KAYSU_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KAYSU_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			KayseriSuOnlineClient client = getSoapClient(iMap);
			int subscriberNumber = Integer.valueOf(CommonHelper.trimStart(iMap.getString(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1), '0')).intValue();
			String pBankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int ihbarnameMakbuzNo = iMap.getInt(MapKeys.INVOICE_NO);
			String tahsilatTarihi = stringLongToStringDate(iMap.getString(MapKeys.PAYMENT_DATE));
			String iptalAciklama = iMap.getString(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON);
			ReconciliationResult result = client.tahsilatIptali(pBankCode, subscriberNumber, ihbarnameMakbuzNo, tahsilatTarihi, iptalAciklama);

			String responseCode = result.getERRCODE();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), iMap.getString(MapKeys.CORPORATE_CODE));
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KAYSU_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_KAYSU_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KAYSU_SEND_STANDING_ORDER_MESSAGE");
		try {
			KayseriSuOnlineClient client = getSoapClient(iMap);
			int subscriberNumber = Integer.valueOf(CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0')).intValue();
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			ReconciliationResult result = client.talimatGirisi(bankCode, subscriberNumber);

			String responseCode = result.getERRCODE();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responseCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), iMap.getString(MapKeys.CORPORATE_CODE));
			outMap.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_KAYSU_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_KAYSU_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KAYSU_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		try {
			KayseriSuOnlineClient client = getSoapClient(iMap);
			int subscriberNumber = Integer.valueOf(CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0')).intValue();
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			ReconciliationResult result = client.talimatIptali(bankCode, subscriberNumber);

			String responseCode = result.getERRCODE();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responseCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), iMap.getString(MapKeys.CORPORATE_CODE));
			outMap.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_KAYSU_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_KAYSU_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KAYSU_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		try {
			KayseriSuOnlineClient client = getSoapClient(iMap);
			String pBankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String tahsilatTarihi = stringLongToStringDate(iMap.getString(MapKeys.RECON_DATE));
			ReconciliationResult result = client.mutabakat(pBankCode, tahsilatTarihi);
			String responseCode = result.getERRCODE();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), iMap.getString(MapKeys.CORPORATE_CODE));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(StringUtils.isBlank(result.getTAHSILAT_NAKIT_TOPLAM()) ? "0" : result.getTAHSILAT_NAKIT_TOPLAM().replace(",", ".")));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, StringUtils.isBlank(result.getTAHSILAT_SAYISI()) ? "0" : result.getTAHSILAT_SAYISI());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(StringUtils.isBlank(result.getIPTAL_NAKIT_TOPLAM()) ? "0" : result.getIPTAL_NAKIT_TOPLAM().replace(",", ".")));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, StringUtils.isBlank(result.getIPTAL_SAYISI()) ? "0" : result.getIPTAL_SAYISI());
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KAYSU_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_KAYSU_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KAYSU_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			KayseriSuOnlineClient client = getSoapClient(iMap);
			String pBankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String tahsilatTarihi = stringLongToStringDate(iMap.getString(MapKeys.RECON_DATE));
			ReconciliationResult result = client.mutabakat(pBankCode, tahsilatTarihi);
			String responseCode = result.getERRCODE();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), iMap.getString(MapKeys.CORPORATE_CODE));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(StringUtils.isBlank(result.getTAHSILAT_NAKIT_TOPLAM()) ? "0" : result.getTAHSILAT_NAKIT_TOPLAM().replace(",", ".")));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, StringUtils.isBlank(result.getTAHSILAT_SAYISI()) ? "0" : result.getTAHSILAT_SAYISI());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(StringUtils.isBlank(result.getIPTAL_NAKIT_TOPLAM()) ? "0" : result.getIPTAL_NAKIT_TOPLAM().replace(",", ".")));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, StringUtils.isBlank(result.getIPTAL_SAYISI()) ? "0" : result.getIPTAL_SAYISI());
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KAYSU_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_KAYSU_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KAYSU_GET_COLLECTION_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			KayseriSuOnlineClient client = getSoapClient(iMap);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String tahsilatTarihi = stringLongToStringDate(iMap.getString(MapKeys.RECON_DATE));
			ArrayList<ReconciliationDetailResult> resultList = client.mutabakatDetay(bankCode, tahsilatTarihi);

			String responseCode = resultList.size() == 0 ? null : resultList.get(0).getERRCODE();
			if (StringUtils.isBlank(responseCode)) {
				responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			}

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			int reconDetResCount = 0;
			for (ReconciliationDetailResult reconDetailResult : resultList) {
				if (StringUtils.isBlank(reconDetailResult.getIPTAL_TARIHI()) && StringUtils.isBlank(reconDetailResult.getIPTAL_EDILEN_MIKTAR())) {
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.SUBSCRIBER_NO1, Integer.valueOf(reconDetailResult.getABONE_NO()).intValue());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.PAYMENT_AMOUNT, new BigDecimal(StringUtils.isBlank(reconDetailResult.getTAHSILAT_MIKTARI()) ? "0" : reconDetailResult.getTAHSILAT_MIKTARI().replace(",", ".")));
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.CANCEL_AMOUNT, new BigDecimal(StringUtils.isBlank(reconDetailResult.getIPTAL_EDILEN_MIKTAR()) ? "0" : reconDetailResult.getIPTAL_EDILEN_MIKTAR().replace(",", ".")));
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.INVOICE_NO, reconDetailResult.getIHBARNAME_MAKBUZ_NO());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.SUBSCRIBER_NAME, reconDetailResult.getABONE_ADI_SOYADI());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.PAYMENT_DATE, reconDetailResult.getTAHSILAT_TARIHI());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.CANCEL_DATE, reconDetailResult.getIPTAL_TARIHI());
					reconCorpAmountMap.put("CORPORATE", reconDetResCount, MapKeys.PARAMETER6, reconDetailResult.getYIL_DONEM());
					reconDetResCount++;
				}
			}
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			outMap.put("BANK", 0, MapKeys.TRX_NO, reconBankMap.get(MapKeys.TRX_NO));
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int corporateCollectionCount = reconDetResCount;
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			boolean found = false;

			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < bankCollectionCount; j++) {
					for (int i = 0; i < corporateCollectionCount; i++) {
						if (Integer.valueOf(CommonHelper.trimStart(reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1), '0')).intValue() == Integer.valueOf(CommonHelper.trimStart(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1), '0')).intValue()
								&& reconBankMap.getString("BANK", j, MapKeys.INVOICE_NO).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.INVOICE_NO)) && reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat istegi gonder
						@SuppressWarnings("unused")
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.SUBSCRIBER_NO1, Integer.valueOf(CommonHelper.trimStart(reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1), '0')).intValue());
						request.put(MapKeys.PARAMETER3, reconBankMap.getString("BANK", j, MapKeys.PARAMETER3));
						request.put(MapKeys.PARAMETER4, reconBankMap.getString("BANK", j, MapKeys.PARAMETER4));
						request.put(MapKeys.PAYMENT_AMOUNT, reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, Integer.valueOf(CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO1), '0')).intValue());
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.BRANCH_CODE, request.getBigDecimal(MapKeys.PARAMETER2));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, request.getBigDecimal(MapKeys.PARAMETER3));
						onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, request.getBigDecimal(MapKeys.PARAMETER4));
						onlineCorporateServiceCallInputMap.put(MapKeys.TERM_MONTH, request.getBigDecimal(MapKeys.PARAMETER5));
						onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, request.getBigDecimal(MapKeys.PARAMETER6));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, request.getBigDecimal(MapKeys.PAYMENT_AMOUNT));

						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);

						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi"));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Tahsilat
																																											// Mesaji
																																											// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, Integer.valueOf(CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO1), '0')).intValue());
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER4));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5, request.getString(MapKeys.PARAMETER5));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6, request.getString(MapKeys.PARAMETER6));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					for (int k = 0; k < bankCollectionCount; k++) {
						if (Integer.valueOf(CommonHelper.trimStart(reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1), '0')).intValue() == Integer.valueOf(CommonHelper.trimStart(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1), '0')).intValue()
								&& reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO).equals(reconBankMap.getString("BANK", k, MapKeys.INVOICE_NO)) && reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						@SuppressWarnings("unused")
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						request.put(MapKeys.SUBSCRIBER_NO1, Integer.valueOf(CommonHelper.trimStart(reconCorpAmountMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1), '0')).intValue());
						request.put(MapKeys.TRX_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.TRX_NO));
						request.put(MapKeys.PAYMENT_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.INVOICE_NO, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.INVOICE_NO));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, Integer.valueOf(CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO1), '0')).intValue());
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON, "Mutabakat");

						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// Tahsilatta hata al�nca yakal�yoruz yola devam
							// ediyoruz
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi"));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, Integer.valueOf(CommonHelper.trimStart(request.getString(MapKeys.SUBSCRIBER_NO1), '0')).intValue());
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconCorpAmountMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER4));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5, request.getString(MapKeys.PARAMETER5));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6, request.getString(MapKeys.PARAMETER6));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KAYSU_GET_COLLECTION_RECONCILIATION_DETAIL.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_KAYSU_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KAYSU_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		logger.info("ICS_KAYSU_DEBT_INQUERY_FOR_STANDING_ORDER start");
		try {
			KayseriSuOnlineClient client = getSoapClient(iMap);
			String pBankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toDay = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			String sonOdemeTarihi = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			GMMap sorMap = getBankStandingOrdersForKaysu(toDay, corporateCode);
			int reconCollectionCount = sorMap.getInt(MapKeys.RECON_BANK_COUNT);
			int count = 0;
			for (int j = 0; j < reconCollectionCount; j++) {
				int subscriberNumber = Integer.valueOf(CommonHelper.trimStart(sorMap.getString("BANK_ORDERS", j, MapKeys.SUBSCRIBER_NO1), '0')).intValue();
				ArrayList<BorcSorgulaResult> results = client.talimatliAboneBorcSorgulama(pBankCode, subscriberNumber, sonOdemeTarihi);
				String responseCode = results.get(0).getERRCODE();
				if (StringUtils.isBlank(responseCode)) {
					responseCode = GeneralConstants.ERROR_CODE_APPROVE;
				}
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					for (BorcSorgulaResult debt : results) {
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO1, Integer.valueOf(debt.getABONE_NO()).intValue());
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_NO, debt.getIHBARNAME_MAKBUZ_NO());
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.AMOUNT, new BigDecimal(StringUtils.isBlank(debt.getODENECEK_MIKTAR()) ? "0" : debt.getODENECEK_MIKTAR().replace(",", ".")));
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.COLLECTION_TYPE, "0");// collection
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(debt.getSON_ODEME_TARIHI(), "dd.MM.yyyy"));
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_TERM_YEAR, debt.getDONEM_YILI());
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_TERM_MONTH, String.format("%02d", Integer.valueOf(debt.getDONEM_SAYISI()).intValue()));
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_YEAR, debt.getDONEM_YILI());
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.TERM_MONTH, String.format("%02d", Integer.valueOf(debt.getDONEM_SAYISI()).intValue()));
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INSTALLMENT_NO, debt.getTAKSIT_SIRASI());
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_TERM_MONTH, String.format("%02d", Integer.valueOf(debt.getDONEM_SAYISI()).intValue()));
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER3, new BigDecimal(StringUtils.isBlank(debt.getHESAPLANAN_GECIKME_ZAMMI()) ? "0" : debt.getHESAPLANAN_GECIKME_ZAMMI().replace(",", ".")));
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER4, new BigDecimal(StringUtils.isBlank(debt.getTAHSILAT_KALAN_BAKIYE()) ? "0" : debt.getTAHSILAT_KALAN_BAKIYE().replace(",", ".")));
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NAME, debt.getABONE_AD_SOYAD());
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);

						outMap.put(MapKeys.INVOICE_LIST, count, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
						count++;
					}
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, count);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KAYSU_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_KAYSU_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_KAYSU_STANDING_ORDER_RECONCILIATION");

		GMMap outMap = new GMMap();
		String responseCode = "";
		try {
			int instructionCount = 0;
			int otherBankInstructionCount = 0;
			int instructionCancelCount = 0;
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String pBankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			KayseriSuOnlineClient client = getSoapClient(iMap);

			GMMap rcInput = new GMMap();
			rcInput.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
			rcInput.put(MapKeys.CORPORATE_CODE, corporateCode);
			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GET_BANK_STANDING_ORDERS_COLLECTION_RECONCILIATION", rcInput);
			int reconCollectionCount = rcOutput.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int reconCollectionCancelCount = rcOutput.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String succesCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			for (int i = 0; i < reconCollectionCount; i++) {
				ReconciliationResult result = client.talimatSorgulama(pBankCode, Integer.valueOf(CommonHelper.trimStart(rcOutput.getString("BANK", i, MapKeys.SUBSCRIBER_NO1), '0')).intValue());
				responseCode = result.getERRCODE();
				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				if (errorCode.equals(NOT_FOUND_TALIMAT)) {
					// talimat yap�lacak
					GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
					String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
					String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
					GMMap onlineCorporateServiceCallInputMap = new GMMap();
					@SuppressWarnings("unused")
					GMMap onlineCorporateServiceCallOutputMap = new GMMap();
					onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, Integer.valueOf(CommonHelper.trimStart(rcOutput.getString("BANK", i, MapKeys.SUBSCRIBER_NO1), '0')).intValue());
					onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
					onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
					onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
					onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
					GMMap reconProcessDataLogInsertInputMap = new GMMap();
					try {
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
					} catch (GMRuntimeException e) {
						instructionCount--;
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
					}
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, rcOutput.getInt("BANK", i, MapKeys.COLLECTION_TYPE));
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);// Talimat
																																											// Mesaji
																																											// Gonderildi
					reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, Integer.valueOf(CommonHelper.trimStart(rcOutput.getString("BANK", i, MapKeys.SUBSCRIBER_NO1), '0')).intValue());
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
				} else if (errorCode.equals(OTHER_BANK_TALIMAT)) {
					GMMap icsInputMap = new GMMap();
					@SuppressWarnings("unused")
					GMMap icsOutputMap = null;
					icsInputMap.put(IcsUpdateStandingOrder.Input.STANDING_ORDER_OID, rcOutput.getInt("BANK", i, MapKeys.STANDING_ORDER_OID));
					icsInputMap.put(IcsUpdateStandingOrder.Input.TRX_NO, rcOutput.getInt("BANK", i, MapKeys.TRX_NO));
					icsInputMap.put(IcsUpdateStandingOrder.Input.UPDATE_DATE, stringLongToStringDate("today"));
					icsInputMap.put(IcsUpdateStandingOrder.Input.UPDATE_USER, GMContext.getCurrentContext().getSession().get("USER_NAME").toString());
					icsInputMap.put(IcsUpdateStandingOrder.Input.STANDING_ORDER_STATUS, StandingOrderStatus.Canelled);
					icsOutputMap = CommonBusinessOperations.callGraymoundService(icsInputMap, "ICS_UPDATE_STANDING_ORDER", true);
					otherBankInstructionCount++;
				}
			}
			for (int i = 0; i < reconCollectionCancelCount; i++) {
				boolean found = false;
				for (int j = 0; j < reconCollectionCount; j++) {
					if (Integer.valueOf(CommonHelper.trimStart(rcOutput.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1), '0')).intValue() == Integer.valueOf(CommonHelper.trimStart(rcOutput.getString("BANK_CANCEL", j, MapKeys.SUBSCRIBER_NO1), '0')).intValue()) {
						found = true;
						break;
					} else {
						found = false;
					}
				}
				if (!found) {
					ReconciliationResult result = client.talimatSorgulama(pBankCode, Integer.valueOf(CommonHelper.trimStart(rcOutput.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1), '0')).intValue());
					responseCode = result.getERRCODE();
					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					if (errorCode.equals(succesCode)) {
						// iptal edilecek
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						@SuppressWarnings("unused")
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, Integer.valueOf(CommonHelper.trimStart(rcOutput.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1), '0')).intValue());
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (GMRuntimeException e) {
							instructionCancelCount--;
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, rcOutput.getInt("BANK_CANCEL", i, MapKeys.COLLECTION_TYPE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);// Talimat
																																														// Iptal
																																														// Mesaji
																																														// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, Integer.valueOf(CommonHelper.trimStart(rcOutput.getString("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1), '0')).intValue());
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}
			outMap.put(MapKeys.RECON_BANK_COUNT, reconCollectionCount - otherBankInstructionCount);
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, reconCollectionCount + instructionCancelCount);
			outMap.put(MapKeys.RECON_CORPORATE_COUNT, reconCollectionCancelCount + instructionCount - otherBankInstructionCount);
			outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, reconCollectionCancelCount + instructionCancelCount + instructionCancelCount);

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_KAYSU_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	public static GMMap getBankStandingOrdersForKaysu(String reconcilitionDate, String corporateCode) {
		String TABLE_NAME = "BANK_ORDERS";
		StringBuilder sb = new StringBuilder();
		// sb.append("select * from sto.standing_order_main sm,ics.ics_standing_orders so");
		// sb.append(" where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('").append(reconcilitionDate).append("', 'dd/MM/yyyy')");
		// sb.append(" and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='").append(corporateCode).append("'");
		// sb.append(" and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' ");
		// sb.append(" and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'");
		sb.append(String.format(QueryRepository.KayseriWaterServicesRepository.GET_BANK_STANDING_ORDERS, reconcilitionDate, reconcilitionDate, corporateCode));

		GMMap returnMap = DALUtil.getResults(sb.toString(), TABLE_NAME);
		if (returnMap.size() > 0) {
			ArrayList<?> al = (ArrayList<?>) returnMap.get(TABLE_NAME);
			returnMap.put(MapKeys.RECON_BANK_COUNT, al.size());
		} else {
			returnMap.put(MapKeys.RECON_BANK_COUNT, 0);
		}

		return returnMap;
	}

	private static KayseriSuOnlineClient getSoapClient(GMMap iMap) {
		KayseriSuOnlineClient client = new KayseriSuOnlineClient(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
		return client;
	}

	private static String stringLongToStringDate(String longDate) {
		if (StringUtils.isBlank(longDate) || longDate.equalsIgnoreCase("today") || (StringUtils.isNotBlank(longDate) && longDate.length() < 8)) {
			return CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
		} else if (longDate.equalsIgnoreCase("todaytime") || StringUtils.isBlank(longDate) || (StringUtils.isNotBlank(longDate) && longDate.length() < 8)) {
			return CommonHelper.getDateString(new Date(), "dd.MM.yyyy HH:mm:ss");
		} else {
			return longDate.substring(6, 8) + "." + longDate.substring(4, 6) + "." + longDate.substring(0, 4);
		}
	}
}
