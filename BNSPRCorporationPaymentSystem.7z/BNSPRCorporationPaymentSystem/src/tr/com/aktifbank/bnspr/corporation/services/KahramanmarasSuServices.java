package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.KaskiReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.kahramanmaras.su.KahramanmarasSuClient;
import tr.com.aktifbank.integration.kahramanmaras.su.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import webservices.BorcKalemi;
import webservices.MutabakatBilgi;
import webservices.SonOdemeBilgi;
import webservices.TahsilatBilgi;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class KahramanmarasSuServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(KahramanmarasSuServices.class);

	@GraymoundService("ICS_KASKI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			// logger info will be logged
			builder.append(" ICS_KASKI_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Abone No -> ");
			builder.append(aboneNo);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(url);
			logger.info(builder.toString());

			logger.info("ICS_KASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - KahramanmarasSuClient.borcListesiniGetir(...) will be called..."));
			BorcKalemi[] response = KahramanmarasSuClient.borcListesiniGetir(url, Integer.valueOf(username), password, aboneNo, sm);
			Integer invoiceCount = 0;
			logger.info("ICS_KASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - KahramanmarasSuClient.borcListesiniGetir(...) returned with count ".concat(invoiceCount.toString())));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());//response exception alinca null geliyor
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_KASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - KahramanmarasSuClient.borcListesiniGetir(...) returned errorCode ".concat(errorCode)));
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (BorcKalemi borc : response) {
					if (borc.getAboneNo() != 0 && !isCollectedInvoice(String.valueOf(borc.getAboneNo()), borc.getSeq(), "", "", "", corporateCode)) {
						int year = borc.getThkTar().get(Calendar.YEAR);
						int month = borc.getThkTar().get(Calendar.MONTH);						
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getAboneNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borc.getSicil());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getSira());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getToplam());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getSicilBilgisi().getAd() + " " + borc.getSicilBilgisi().getSoyad());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(borc.getVade().getTime()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, year);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, month);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getToplam());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, String.valueOf(borc.getTutar()).replace(".", ","));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, borc.getTurKod());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, borc.getSeq());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, borc.getTakNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			logger.info("ICS_KASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - KahramanmarasSuClient.borcListesiniGetir(...) finished succesfully"));
		} catch (Throwable e2) {
			logger.error("ICS_KASKI_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_KASKI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String trasnactionId = iMap.getString(MapKeys.TRX_NO);
			Long aboneNo = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			String tahsilTuru = iMap.getString(MapKeys.PARAMETER2);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String toplam = iMap.getString(MapKeys.PAYMENT_AMOUNT);
			
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			Calendar tahsilatTarihi = Calendar.getInstance();
			String date = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				date = CommonHelper.getShortDateTimeString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"));
				
			} else {
				date = CommonHelper.getShortDateTimeString(new Date());
			}
			tahsilatTarihi.setTime(CommonHelper.getDateTime(date, "yyyyMMdd"));
			
			String seq = iMap.getString(MapKeys.PARAMETER3);
			if(seq == null)
				seq = iMap.getString(MapKeys.PARAMETER_3);
			
			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_KASKI_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | trasnactionId -> ");
			builder.append(trasnactionId);
			builder.append(" | tahakkukNo -> ");
			builder.append(seq);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			logger.info(builder.toString());
			
			if (isStandingOrderCollection) {
				logger.info("ICS_KASKI_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - KahramanmarasSuClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			}else{
				logger.info("ICS_KASKI_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - KahramanmarasSuClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			
			TahsilatBilgi response = KahramanmarasSuClient.borclariTahsilEt(url, Integer.valueOf(username), password, trasnactionId, seq, aboneNo, tahsilTuru, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			responceCodeMap = getResponseCodeMapping(String.valueOf(response.getDurumkodu()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter5(String.valueOf(tahsilTuru));
				invoicePayment.setParameter6(CommonHelper.getLongDateTimeString(tahsilatTarihi.getTime()));
				invoicePayment.setParameter7(toplam);
				invoicePayment.setParameter8(iMap.getBigDecimal(MapKeys.TRX_NO).toString()); 
				invoicePayment.setParameter9(String.valueOf(response.getMakbuzNo()));
				invoicePayment.setParameter10(String.valueOf(response.getSicilNo()));
				session.saveOrUpdate(invoicePayment);
			}
			
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_KASKI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			int makbuzNo = 0;
			makbuzNo=Integer.valueOf(iMap.getString(MapKeys.PARAMETER_9));
			if (makbuzNo == 0) {
				makbuzNo = Integer.valueOf(iMap.getString(MapKeys.PARAMETER9));
			}
			
			String sub = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			if(sub == null){
				sub = iMap.getString("SUBSCRIBER_NO_1");
			}
			long aboneNo = Long.valueOf(sub);			
			
			Calendar tahsilatTarihi = Calendar.getInstance();
			String btt = iMap.getString(MapKeys.PARAMETER_6, null);
			if (btt == null) {
				btt = iMap.getString(MapKeys.PARAMETER6);
			}
			tahsilatTarihi.setTime(CommonHelper.getDateTime(btt, "yyyyMMddhhmmss"));
			
			String toplam = iMap.getString(MapKeys.PARAMETER_7, null);
			if (toplam == null) {
				toplam = iMap.getString(MapKeys.PARAMETER7);
			}
			
			String karsireferansNo = iMap.getString(MapKeys.PARAMETER_8, null);
			if (karsireferansNo == null) {
				karsireferansNo = iMap.getString(MapKeys.PARAMETER8);
			}
			String sicilNoString= iMap.getString(MapKeys.PARAMETER_10, null);
			if (sicilNoString == null) {
				sicilNoString = iMap.getString(MapKeys.PARAMETER10);
			}
			long sicilNo = 0;
			if (sicilNoString == null) {
				sicilNo = Long.getLong(sicilNoString);
			}
			
			builder.append(" ICS_KASKI_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | serviceUrl -> ");
			builder.append(url);
			logger.info(builder.toString());

			int durumkodu = 1;
		
			
			int response = KahramanmarasSuClient.tahsilatIptalIstegi(url, Integer.valueOf(username), password, aboneNo, durumkodu, karsireferansNo, makbuzNo,sicilNo, tahsilatTarihi, Double.valueOf(toplam), sm);
			
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			responceCodeMap = getResponseCodeMapping(String.valueOf(response), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_KASKI_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_KASKI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		ServiceMessage sm = new ServiceMessage();
		Session session = CommonHelper.getHibernateSession();
		try {

			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_COLLECTION_RECONCILIATION");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			builder.append(" ICS_KASKI_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | reconDate -> ");
			builder.append(reconDate);
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | serviceUrl -> ");
			builder.append(url);
			logger.info(builder.toString());
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			String paymentDateStart = reconDate + "000000";
			String paymentDateFinish = reconDate + "235959";
			String ct = (String) session.createCriteria(invoicePayment.class).add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Cancelled))
					.add(Restrictions.between("paymentDate", paymentDateStart, paymentDateFinish))
					.setProjection(Projections.sum("parameter7")).uniqueResult();
			BigDecimal cancelTotal = new BigDecimal(ct == null ? "0" : ct);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			Calendar tarih = Calendar.getInstance();
			tarih.setTime(CommonHelper.getDateTime(reconDate, "yyyyMMdd"));
			
			MutabakatBilgi response = KahramanmarasSuClient.mutabakatBilgisiVer(url, Integer.valueOf(username), password, tarih, sm);
			
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			
			// aldigin sayilari koy
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getToplam());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getAdet());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getIptalToplam());
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getIptalAdet());
			
			//tahsilat tutarlari
			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 
				&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
				&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
				&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				logger.info("ICS_KASKI_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_KASKI_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_KASKI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_KASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_GET_COLLECTION_RECONCILIATION_DETAIL");
		tr.com.aktifbank.integration.kahramanmaras.su.ServiceMessage sm = new ServiceMessage();
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			CollectionReconciliationDetailBatch batch = new KaskiReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_KASKI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_KASKI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_KASKI_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("STO_KASKI_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_KASKI_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();		
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			
			int response = KahramanmarasSuClient.otomatikOdemeKayit(url, Integer.valueOf(username), password, aboneNo, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());	
			
			GMMap responceCodeMap = getResponseCodeMapping(String.valueOf(response), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			}
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_KASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_KASKI_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			
			int response = KahramanmarasSuClient.otomatikOdemeIptal(url, Integer.valueOf(username), password, aboneNo, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			
			
			GMMap responceCodeMap = getResponseCodeMapping(String.valueOf(response), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			}
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_KASKI_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KASKI_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			// banka talimatli aboneleri getirir
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
					iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter=0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			int bankStandingOrderListLenght = bankStandingOrderList.size();
			
			String processDate = iMap.getString(MapKeys.PROCESS_DATE);
			Calendar vade = Calendar.getInstance();
			vade.setTime(CommonHelper.getDateTime(processDate, "yyyyMMdd"));
			SonOdemeBilgi[] response = KahramanmarasSuClient.sonOdemesiGelenBorcluAboneler(url, Integer.valueOf(username), password, vade, sm);
			
			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);
				Long subscriberNo1 = Long.valueOf(icsStandingOrder.getSubscriberNo1()); 
				for(SonOdemeBilgi borc : response){
					if(subscriberNo1.equals(borc.getAboneNo())){
						int year = borc.getThkTar().get(Calendar.YEAR);
						int month = borc.getThkTar().get(Calendar.MONTH);	
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getAboneNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getSeq());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getTutar());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdi() + " " + borc.getSoyadi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(borc.getVade().getTime()));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, year);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, month);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getTutar());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getDurumkodu());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}					
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");				
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_KASKI_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
}
