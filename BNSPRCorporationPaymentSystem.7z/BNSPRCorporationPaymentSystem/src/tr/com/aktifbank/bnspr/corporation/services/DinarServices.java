package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.integration.dinar.DinarClient;
import tr.com.aktifbank.integration.dinar.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.beyazweb.service.client.cobot.CoBotOtomatikOdeme;
import com.beyazweb.service.client.cobot.CoBotResult;
import com.beyazweb.service.client.cobot.DebtRow;
import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class DinarServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(DinarServices.class);
	private static final String WS_RESPONSE_CODE = "WS_RESPONSE_CODE";
	private static final String WATER_PREFIX = "SU";
	
	@GraymoundService("ICS_DINAR_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DINAR_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage serviceMessage = new ServiceMessage();
		int counter = 0;

		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String remoteIP = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String identityNumber = "";
			String processType = "";
			String subscriberNo1 = "";
			String subscriberNo2 = "";
			
			if(StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){				
				subscriberNo1 = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
				identityNumber = WATER_PREFIX + subscriberNo1 ;
			} else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				subscriberNo2 = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO2), '0');
				identityNumber = subscriberNo2; 
			}	
			
			CoBotResult result = DinarClient.queryDebits(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, identityNumber, remoteIP);
			outMap.put(WS_RESPONSE_CODE, result.getCoBotError());
			GMMap responceCodeMap = getResponseCodeMapping(result.getCoBotError().value(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && result != null && result.getCoBotDebt().getDebtRows().size() > 0) {
				for (DebtRow debt : result.getCoBotDebt().getDebtRows()) {
					String dueDate = CommonHelper.getShortDateTimeString(debt.getExpiryDate().toGregorianCalendar().getTime());
					if (!isCollectedInvoice(debt.getRecordid().toString(), subscriberNo1, subscriberNo2, "", "", corporateCode, dueDate)) {
						if (("EVET".equals(CommonHelper.getValueOfParameter("DINAR_ODENEBILEN_BORC_TIPI", debt.getIncomeModule().value())))) {

						String termYear = dueDate.substring(0,4);
						String termMonth = dueDate.substring(4, 6);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo1);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, subscriberNo2);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debt.getRecordid());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debt.getTotalAmount());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, result.getCoBotDebt().getNameSurname());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debt.getExpiryDate().toGregorianCalendar().getTime());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, debt.getInstallment());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debt.getIncomeModule().value());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2,identityNumber);
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					
						}
					}
					
				}
			}

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_DINAR_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_DINAR_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DINAR_DO_INVOICE_COLLECTION");
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String remoteIP = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String identityNumber = iMap.getString(MapKeys.PARAMETER2);
			String invoiceNumber = iMap.getString(MapKeys.INVOICE_NO);
			String invoiceType = iMap.getString(MapKeys.PARAMETER1);
			String paymentValue = StringUtils.isEmpty(iMap.getString(MapKeys.PAYMENT_AMOUNT)) ? "0" : iMap.getString(MapKeys.PAYMENT_AMOUNT).replace('.', ',');
			
			String bankID = iMap.getString(MapKeys.TRX_NO);

				BigDecimal amount =iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
				Long detailID = new Long(invoiceNumber);
				XMLGregorianCalendar collectionDate = CommonHelper.convertDate2GregorianCalendar(new Date());
				if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
					 collectionDate = CommonHelper.convertDate2GregorianCalendar(iMap.getDate(MapKeys.PAYMENT_DATE));
				}
				
				CoBotResult result = DinarClient.collect(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, identityNumber, remoteIP, bankID, collectionDate, detailID, amount);
				
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RESPONSE_XML", serviceMessage.getResponse());
				
				outMap.put(WS_RESPONSE_CODE, result.getCoBotError().value());
				GMMap responceCodeMap = getResponseCodeMapping(result.getCoBotError().value(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));


			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_DINAR_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_DINAR_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DINAR_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String remoteIP = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			Long tahakkukId = iMap.getLong(MapKeys.INVOICE_NO);
			String bankID = iMap.getString(MapKeys.TRX_NO);


			CoBotResult result =  DinarClient.cancel(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, remoteIP, bankID);
			
			iMap.put("REQUEST_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getResponse());
	
				
			GMMap responceCodeMap = getResponseCodeMapping(result.getCoBotError().value(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			insertOnlineServiceLog(iMap, outMap);
		} catch (Exception e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, e2.getMessage().length()<950? e2.getMessage() : e2.getMessage().substring(0, 949));
			iMap.put("REQUEST_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML_SEND_COLLECTION_CANCEL_MESSAGE", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, outMap);
			e2.printStackTrace();
			throw e2;
		}
		return outMap;
	}
	
	@GraymoundService("STO_DINAR_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_DINAR_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		String responseCode="";
		ServiceMessage serviceMessage = new ServiceMessage();

		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String identityNumber = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String remoteIP = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			

			CoBotResult   result = DinarClient.sendStandingOrder(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, remoteIP, identityNumber);
			outMap.put(WS_RESPONSE_CODE, result.getCoBotError().value());
			
			GMMap responceCodeMap = getResponseCodeMapping(result.getCoBotError().value(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_DINAR_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("STO_DINAR_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_DINAR_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();

		String responseCode="";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String identityNumber = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String remoteIP = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			

			CoBotResult   result = DinarClient.cancelStandingOrder(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, remoteIP, identityNumber);
			outMap.put(WS_RESPONSE_CODE, result.getCoBotError().value());
			
			GMMap responceCodeMap = getResponseCodeMapping(result.getCoBotError().value(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_DINAR_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_DINAR_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DINAR_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String remoteIP = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			Date dueDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMddhhmmss") : new Date();

			ServiceMessage serviceMessage=new ServiceMessage();
			XMLGregorianCalendar date = CommonHelper.convertDate2GregorianCalendar(dueDate);
			CoBotResult response = DinarClient.debtQueryforStandingOrder(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, remoteIP, date);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(WS_RESPONSE_CODE, response.getCoBotError().value());
			GMMap responceCodeMap = getResponseCodeMapping(response.getCoBotError().value(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			int i = 0;
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.TABLE_SIZE, response != null && response.getOtomatikOdemeler() != null ? response.getOtomatikOdemeler().size() : 0);
				for (CoBotOtomatikOdeme borc : response.getOtomatikOdemeler()) {
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, borc.getAboneNo());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, borc.getBorcId());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, borc.getBorc());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, "0");// collection
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, dueDate);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER2, WATER_PREFIX + borc.getAboneNo());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
					i++;
				}
			} else {
				outMap.put(MapKeys.TABLE_SIZE, 0);
			}

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_DINAR_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_DINAR_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DINAR_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Date mutabakatTarihi = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) {
				mutabakatTarihi= CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd");
			} 
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String remoteIP = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			XMLGregorianCalendar agreementDate = CommonHelper.convertDate2GregorianCalendar(mutabakatTarihi);
			BigDecimal cancelAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int cancelCount= reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			BigDecimal collectionAmount= reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int  collectionCount= reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			
			CoBotResult result = DinarClient.agreement(reqTimeout, connTimeout, url, userName, passWord, serviceMessage, remoteIP, agreementDate, collectionAmount, cancelAmount, collectionCount, cancelCount);
			GMMap responceCodeMap = getResponseCodeMapping(result.getCoBotError().value(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getCoBotAggreement().getCollectionAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getCoBotAggreement().getCollectionCount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.getCoBotAggreement().getCancelCount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getCoBotAggreement().getCancelAmount());
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			}

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_DINAR_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_DINAR_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		// kurumun detay servisi yok
		outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		return outMap;
	}

	
	@GraymoundService("ICS_DINAR_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_DINAR_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			Date mutabakatTarihi = new Date();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) {
				mutabakatTarihi= CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd");
			} 
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String passWord = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String remoteIP = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			XMLGregorianCalendar agreementDate = CommonHelper.convertDate2GregorianCalendar(mutabakatTarihi);
			BigDecimal cancelAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int cancelCount= reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			BigDecimal collectionAmount= reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			int  collectionCount= reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			
			CoBotResult result = DinarClient.agreement(reqTimeout, connTimeout, url, userName, passWord, serviceMessage, remoteIP, agreementDate, collectionAmount, cancelAmount, collectionCount, cancelCount);
			GMMap responceCodeMap = getResponseCodeMapping(result.getCoBotError().value(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, result.getCoBotAggreement().getCollectionAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, result.getCoBotAggreement().getCollectionCount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, result.getCoBotAggreement().getCancelCount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, result.getCoBotAggreement().getCancelAmount());
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			}

			if (outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0 && outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0) {

				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_DINAR_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	
	}

}
