package tr.com.aktifbank.bnspr.corporation.services;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.StandingOrderReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.TTSCollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.TTStandingOrderReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.BatchParameterEngine;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.StandingOrderStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant.Email.NewStandingOrderRequestMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.TTSReconciliationLineParserProcess;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.cps.dto.TTSReconciliationDetail;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;
import tr.com.aktifbank.bnspr.dao.CorporateChannelPrm;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.aktifbank.bnspr.dao.FileTransferLog;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.aktifbank.bnspr.dao.ServiceResponseCodeMapping;
import tr.com.aktifbank.bnspr.dao.StandingOrderMain;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.ttadsl.TtAdslClient;
import tr.com.aktifbank.integration.tts.client.ServiceMessage;
import tr.com.aktifbank.integration.tts.client.TTSDebtInquiryClient;
import tr.com.aktifbank.integration.tts.client.TTSReconClient;
import tr.com.aktifbank.integration.tts.client.TTSStandingOrderClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.innova.tts.business.webservice.server.model.banka.FaturaBilgi;
import tr.com.innova.tts.business.webservice.server.model.banka.FaturaOdemeIptaliRequest;
import tr.com.innova.tts.business.webservice.server.model.banka.FaturaOdemeIptaliResponse;
import tr.com.innova.tts.business.webservice.server.model.banka.FaturaOdemeRequest;
import tr.com.innova.tts.business.webservice.server.model.banka.FaturaOdemeResponse;
import tr.com.innova.tts.business.webservice.server.model.banka.OdemeOncesiFaturaBilgi;
import tr.com.innova.tts.business.webservice.server.model.banka.OdemeOncesiFaturaSorgulamaRequest;
import tr.com.innova.tts.business.webservice.server.model.banka.OdemeOncesiFaturaSorgulamaResponse;
import tr.com.innova.tts.business.webservice.server.model.banka.ReferansBilgi;
import tr.com.innova.tts.business.webservice.server.model.mutabakat.MutabakatBilgi;
import tr.com.innova.tts.business.webservice.server.model.mutabakat.MutabakatRequest;
import tr.com.innova.tts.business.webservice.server.model.mutabakat.MutabakatResponse;
import tr.com.innova.tts.business.webservice.server.model.ortak.ErisimBilgi;
import tr.com.innova.tts.business.webservice.server.model.ortak.IslemYapan;
import tr.com.innova.tts.business.webservice.server.talimat.TalimatBilgiSorgulamaRequest;
import tr.com.innova.tts.business.webservice.server.talimat.TalimatBilgiSorgulamaResponse;
import tr.com.innova.tts.business.webservice.server.talimat.TalimatCikarRequest;
import tr.com.innova.tts.business.webservice.server.talimat.TalimatCikarResponse;
import tr.com.innova.tts.business.webservice.server.talimat.TalimatEkleRequest;
import tr.com.innova.tts.business.webservice.server.talimat.TalimatEkleResponse;
import tr.com.innova.tts.business.webservice.server.talimat.TalimatHesap;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TTSystemService extends OnlineCorporationInterface implements OnlineInstitutionConstants {

	private static final Log logger = LogFactory.getLog(TTSystemService.class);

	private static class TTSMessageType {
		private static final int DEBT_INQUERY_REQUEST_CODE = 200;
		private static final int DO_NOTIFICATION_REQUEST_CODE = 220;
		private static final int RECONCILIATION_SUMMARY_REQUEST_CODE = 520;
	}

	private static class TTSProcessCode {
		private static final int DEBT_INQUIRY_CODE = 91;
		private static final int DO_INVIOCE_COLLECTION_CODE = 11;
		private static final int CANCEL_INVOICE_COLLECTION_CODE = 21;
		private static final int POSTPAID_ACCOUNT_4_RECONCILIATION_CODE = 52;
		private static final int STO_ACCOUNT_4_RECONCILIATION_CODE = 54;
		private static final int NEW_STANDING_ORDER_REQUEST_CODE = 66;
		private static final int CANCEL_STANDING_ORDER_REQUEST_CODE = 76;
		private static final int QUERY_STANDING_ORDER_REQUEST_CODE = 97;
	}

	private static class TTSAccesType {
		private static final int SERVICE_NO = 1;
	}

	private static class TTSResponseCode {
		private static final String SUCCES = "00";
		//private static final String PARTIAL_SUCCESS = "86";
		private static final String RECONCILIATION_FAILED = "62";
		private static final String ALREADY_RECONCILIATION_SUCCESS = "72";
	}

	private static class TTSReconcilationType {
		private static final int POSTPAID_ACCOUNTS_RECONCILIATION_TYPE = 2;
		private static final int STO_ACCOUNTS_RECONCILIATION_TYPE = 4;
	}

	private static class TTSOtherCodes {
		private static final int CURRENCY = 949;
		private static final int BANK_CORPORATE_CODE = 2143;
		private static final int RECONLITION_STATUS = 0;
		private static final String OFFICE_CODE = "1";
		private static final String BRANCH_CODE = "555";
		private static final int CITY_CODE = 34;
		private static final String USER_CODE = "101";
		private static final int DEFAULT_CORPORATE_CHANNEL_CODE = 0;
		private static final int DEFAULT_RECORD_COUNT = 5;
		private static final int DECIMAL_FORMAT = 100;
		private static final int SCALE_LENGTH = 2;
		private static final int CORP_SCALE_LENGTH = 0;
		private static final int TOTAL_PROCESS_COUNT = 2;
		private static final int DEFAULT_TT_COMPANY_CODE = 500;
		private static final int STO_TYPE = 2;
		private static final String ACCOUNT_ID_KEY = "ACCOUNT_ID_KEY";
		private static final String DEFAULT_STANDING_ORDER_COUNT = "0";
	}

	private static int getCompanyCode(String corporateCode) {
		String companyCode = CommonHelper.getValueOfParameter("CDM_CORPORATE_COMPANY_CODE", corporateCode);
		if (null == companyCode) {
			return TTSOtherCodes.DEFAULT_TT_COMPANY_CODE;
		}
		return Integer.parseInt(companyCode);
	}

	private static String getCompanyCode4Reconciliation(String corporateCode) {
		String tmpCompanyCode = CommonHelper.getValueOfParameter("CDM_CORPORATE_COMPANY_CODE_RECON", corporateCode);
		return corporateCode.concat(",").concat(tmpCompanyCode);
	}

	@GraymoundService("ICS_TTS_INVOICE_DEBT_INQUIRY")
	public static GMMap invoiceDebtInquiry(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[TTSystemService[invoiceDebtInquiry]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_INVOICE_DEBT_INQUIRY");
		try {
			TTSDebtInquiryClient debtInquiryClient = getSoapClient(iMap);

			String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			StringBuilder serviceNoBuilder = new StringBuilder(subscriberNo1);
			String subscriberNo2 = null;
			if (null != iMap.getString(MapKeys.SUBSCRIBER_NO2) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO2))) {
				subscriberNo2 = iMap.getString(MapKeys.SUBSCRIBER_NO2);
				serviceNoBuilder.append(subscriberNo2);
			}
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);

			logger.info("[TTSystemService[invoiceDebtInquiry]] Values will be used are : Subscriber No :" + subscriberNo1 + "Corporate Code :" + corporateCode + " Collection Type : " + collectionType);
			String billCheck = CommonHelper.getValueOfParameter("TTS_CORPORATE_CODES", "BILL_CHECK");
			int billCycleType = Integer.parseInt(CommonHelper.getDateString(new Date(), "yyyyMM"));
			ServiceMessage serviceMessage = new ServiceMessage();
			OdemeOncesiFaturaSorgulamaResponse debtInquiryResponse = debtInquiryClient.debtInquiry(prepareDebtInquiryRequest(serviceNoBuilder.toString(), billCycleType, getCompanyCode(corporateCode), iMap), serviceMessage);
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getParameter1(), serviceMessage.getParameter2(), serviceMessage.getParameter3());
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			if (null != debtInquiryResponse) {
				if (null != debtInquiryResponse.getOzetCevapMesaj()) {
					if (null != debtInquiryResponse.getOzetCevapMesaj().getIslemSonucKodu() && debtInquiryResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)) {
						int counter = 0;
						if (null != debtInquiryResponse.getFaturaBilgiDizi()) {
							for (OdemeOncesiFaturaBilgi unpaidInvoice : debtInquiryResponse.getFaturaBilgiDizi()) {
								if ((!isCollectedInvoiceNo(Long.toString(unpaidInvoice.getFaturaNo()), corporateCode)) || "EVET".equals(billCheck)) {
									long corporateAmount = unpaidInvoice.getToplamBorcTutari();
									BigDecimal bankAmount = formatCorporateAmount2BankFormat(corporateAmount);
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo1);
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, subscriberNo2);
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, unpaidInvoice.getFaturaNo());
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, bankAmount);
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, unpaidInvoice.getFaturaTaksitNo());
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, unpaidInvoice.getAdsoyadUnvan());
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, String.valueOf(unpaidInvoice.getOdemeDonemi()).substring(0, 4));
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, String.valueOf(unpaidInvoice.getOdemeDonemi()).substring(4));
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, bankAmount);
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, unpaidInvoice.getSonOdemeTarihi());
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, unpaidInvoice.getReferansNo());
									output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, unpaidInvoice.getHesapId());
									output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
									output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
									counter++;
								}
							}
						}
					} else {
						GMMap codeMapping = getResponseCodeMapping(debtInquiryResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						output.put(MapKeys.ERROR_CODE, codeMapping.getString(MapKeys.ERROR_CODE));
						output.put(MapKeys.ERROR_DESC, codeMapping.getString(MapKeys.ERROR_DESC));
					}
				}
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			} else {
				throw new Exception("Servis cevab� anla��lamad�.");
			}
		} catch (Exception ex) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_TTS_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[TTSystemService[doInvoiceCollection]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_DO_INVOICE_COLLECTION");
		try {

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			int paymentDate = convertDate2TTDate(iMap.getString(MapKeys.PAYMENT_DATE));

			String channelCode = iMap.getString("CHANNEL_CODE", null);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE, "0"));
			int channel = getCorporateChannelMapping(corporateCode, sourceCode, channelCode, collectionType);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);

			logger.info("[TTSystemService[doInvoiceCollection]] Values will be used are : Process Date :" + paymentDate + "Corporate Code :" + corporateCode + " Channel Code : " + channelCode + " Standing Order Collection : " + isStandingOrderCollection);

			Session hibernateSession = CommonHelper.getHibernateSession();
			if (isStandingOrderCollection) {
				Criteria paymentUpdateCriteria = hibernateSession.createCriteria(invoicePayment.class);
				invoicePayment queryPaymentResult = (invoicePayment) paymentUpdateCriteria.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).uniqueResult();

				if (null != queryPaymentResult) {
					Criteria paymentControlCriteria = hibernateSession.createCriteria(invoicePayment.class);
					invoicePayment invPayCheck = (invoicePayment) paymentControlCriteria.add(Restrictions.ne("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("paymentStatus", "T")).add(Restrictions.eq("subscriberNo1", queryPaymentResult.getSubscriberNo1()))
							.add(Restrictions.eq("paymentAmount", queryPaymentResult.getPaymentAmount())).add(Restrictions.eq("invoiceNo", queryPaymentResult.getInvoiceNo())).uniqueResult();
					if (invPayCheck != null) {
						logger.info("ICS_TTS_DO_INVOICE_COLLECTION -> fatura odemesi veritabaninda mevcut!Tekrar �deme yap�lamaz! Fatura No: ".concat(queryPaymentResult.getInvoiceNo()));
						Exception e=new Exception("�deme veritaban�nda mevcut! Tekrar �deme yap�lamaz! Fatura Numaras� :".concat(queryPaymentResult.getInvoiceNo()));
						output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
						output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
						output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
						throw ExceptionHandler.convertException(e);
					} else {
						queryPaymentResult.setStanNo(iMap.getString(MapKeys.STAN_NO));
						hibernateSession.saveOrUpdate(queryPaymentResult);
						hibernateSession.flush();
					}
				}
			} else {
				TTSDebtInquiryClient debtPaymentClient = getSoapClient(iMap);
				ServiceMessage serviceMessage = new ServiceMessage();
				FaturaOdemeResponse paymentInvoiceResponse = debtPaymentClient.doInvoiceCollection(prepareInvoicePaymentRequest(getCompanyCode(corporateCode), prepareInvoiceInfo(iMap, null), channel, paymentDate, iMap), serviceMessage);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				output.put("RESPONSE_XML", serviceMessage.getResponse());
				if (null != paymentInvoiceResponse) {
					if (null != paymentInvoiceResponse.getOzetCevapMesaj()) {
						String responseCode = paymentInvoiceResponse.getOzetCevapMesaj().getIslemSonucKodu();
						GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							Criteria paymentUpdateCriteria = hibernateSession.createCriteria(invoicePayment.class);
							invoicePayment queryPaymentResult = (invoicePayment) paymentUpdateCriteria.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).uniqueResult();
							if (null != queryPaymentResult) {
								queryPaymentResult.setStanNo(iMap.getString(MapKeys.STAN_NO));
								try {
									queryPaymentResult.setParameter20(Integer.toString(paymentInvoiceResponse.getIslemKaynagi()));
									queryPaymentResult.setParameter19(Integer.toString(paymentInvoiceResponse.getIslemKodu()));
									queryPaymentResult.setParameter18(Integer.toString(paymentInvoiceResponse.getIslemSaati()));
									queryPaymentResult.setParameter17(Integer.toString(paymentInvoiceResponse.getIslemTarihi()));
									queryPaymentResult.setParameter16(Integer.toString(paymentInvoiceResponse.getKurumKodu()));
									queryPaymentResult.setParameter15(Integer.toString(paymentInvoiceResponse.getMesajTipi()));
									queryPaymentResult.setParameter14(Integer.toString(paymentInvoiceResponse.getParaKodu()));
									queryPaymentResult.setParameter13(Integer.toString(paymentInvoiceResponse.getSirketKodu()));
									queryPaymentResult.setParameter12(Integer.toString(paymentInvoiceResponse.getStan()));
									queryPaymentResult.setParameter11(paymentInvoiceResponse.getOzetCevapMesaj().getHataMesaji());
									queryPaymentResult.setParameter10(paymentInvoiceResponse.getOzetCevapMesaj().getIslemSonucKodu());
								} catch (Exception e) {
									logger.info("ICS_TTS_DO_INVOICE_COLLECTION -> fatura odeme detay update hata aldi");
								}
								hibernateSession.saveOrUpdate(queryPaymentResult);
								hibernateSession.flush();
							}

							output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

						} else {
							setErrorCodeToOutput(paymentInvoiceResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
						}
					}
				}
			}
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_TTS_CANCEL_COLLECTION")
	public static GMMap cancelCollection(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[TTSystemService[cancelCollection]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_SEND_COLLECTION_CANCEL_MESSAGE");

		try {
			int invoicePaymentDate = Integer.parseInt(CommonHelper.getDateString(new Date(), "yyyyMMdd"));

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			String subceriberNo1 = iMap.getString("SUBSCRIBER_NO_1");
			iMap.put(MapKeys.SUBSCRIBER_NO1, subceriberNo1);
			if (iMap.containsKey("SUBSCRIBER_NO_2") && null != iMap.getString("SUBSCRIBER_NO_2")) {
				iMap.put(MapKeys.SUBSCRIBER_NO2, iMap.getString("SUBSCRIBER_NO_2"));
			}
			String channelCode = iMap.getString("CHANNEL_CODE", "0");
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE, "0"));
			int channel = getCorporateChannelMapping(corporateCode, sourceCode, channelCode, collectionType);

			logger.info("[TTSystemService[cancelCollection]] Values will be used are : Invoice Payment Date :" + invoicePaymentDate + "Corporate Code :" + corporateCode + " Channel Code : " + channelCode);

			Session hibernateSession = CommonHelper.getHibernateSession();
			Criteria paymentQueryCriteria = hibernateSession.createCriteria(invoicePayment.class);
			paymentQueryCriteria = paymentQueryCriteria.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("subscriberNo1", subceriberNo1)).add(Restrictions.eq("invoiceNo", iMap.getString(MapKeys.INVOICE_NO))).add(Restrictions.eq("status", true)).addOrder(Order.desc("paymentDate"));

			if (null != iMap.getString(MapKeys.TRX_NO) && !"".equals(iMap.getString(MapKeys.TRX_NO))) {
				paymentQueryCriteria = paymentQueryCriteria.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO)));
			}

			if (null != iMap.getString("SUBSCRIBER_NO_2") && !"".equals(iMap.getString("SUBSCRIBER_NO2"))) {
				paymentQueryCriteria = paymentQueryCriteria.add(Restrictions.eq("subscriberNo2", iMap.getString("SUBSCRIBER_NO_2")));
			}
			if (null != iMap.getString("SUBSCRIBER_NO_3") && !"".equals(iMap.getString("SUBSCRIBER_NO3"))) {
				paymentQueryCriteria = paymentQueryCriteria.add(Restrictions.eq("subscriberNo3", iMap.getString("SUBSCRIBER_NO_3")));
			}
			if (null != iMap.getString("SUBSCRIBER_NO_4") && !"".equals(iMap.getString("SUBSCRIBER_NO4"))) {
				paymentQueryCriteria = paymentQueryCriteria.add(Restrictions.eq("subscriberNo4", iMap.getString("SUBSCRIBER_NO_4")));
			}

			long paymentStanNo = 0;

			if (null != iMap.getString(MapKeys.PARAMETER_3) && !"".equals(iMap.getString(MapKeys.PARAMETER_3))) {
				iMap.put(MapKeys.PARAMETER3, iMap.getString(MapKeys.PARAMETER_3));
				logger.info("[TTSystemService[cancelCollection]] Referens Id has been assigned.");
			}

			if (null != iMap.getString(MapKeys.PARAMETER_7) && !"".equals(iMap.getString(MapKeys.PARAMETER_7))) {
				iMap.put(MapKeys.PARAMETER7, iMap.getString(MapKeys.PARAMETER_7));
				logger.info("[TTSystemService[cancelCollection]] Hesap Id has been assigned.");
			}

			String invoicePaymentDateStr = null;
			if (null == iMap.getString(MapKeys.PARAMETER7) || null == iMap.getString(MapKeys.PARAMETER3)) {
				logger.info("[TTSystemService[cancelCollection]] Hesap Id and Referans Id will be queried.");
				List<invoicePayment> paymentResults = (List<invoicePayment>) paymentQueryCriteria.list();

				if (null != paymentResults) {
					if (null != paymentResults.get(0)) {
						invoicePayment paymentResult = paymentResults.get(0);
						iMap.put(MapKeys.PARAMETER7, paymentResult.getParameter7());
						iMap.put(MapKeys.PARAMETER3, paymentResult.getParameter3());
						paymentStanNo = Long.parseLong(paymentResult.getStanNo());
						invoicePaymentDateStr = CommonHelper.formatDateString(paymentResult.getPaymentDate(), "yyyyMMddhhmmss", "yyyyMMdd");

						logger.info("[TTSystemService[cancelCollection]] Hesap Id and Referans Id has been assigned.");

						if (null == iMap.getString(MapKeys.TERM_YEAR)) {
							iMap.put(MapKeys.TERM_YEAR, paymentResult.getTermYear());
						}
						if (null == iMap.getString(MapKeys.TERM_MONTH)) {
							iMap.put(MapKeys.TERM_MONTH, paymentResult.getTermMonth());
						}
					}
				}
			} else {
				List<invoicePayment> paymentResults = (List<invoicePayment>) paymentQueryCriteria.list();
				if (null != paymentResults) {
					if (null != paymentResults.get(0)) {
						invoicePayment paymentResult = paymentResults.get(0);
						logger.info("[TTSystemService[cancelCollection]] Payment Info can be found.");
						paymentStanNo = Long.parseLong(paymentResult.getStanNo());
						invoicePaymentDateStr = CommonHelper.formatDateString(paymentResult.getPaymentDate(), "yyyyMMddhhmmss", "yyyyMMdd");

						if (null == iMap.getString(MapKeys.TERM_YEAR)) {
							iMap.put(MapKeys.TERM_YEAR, paymentResult.getTermYear());
						}
						if (null == iMap.getString(MapKeys.TERM_MONTH)) {
							iMap.put(MapKeys.TERM_MONTH, paymentResult.getTermMonth());
						}
					}
				}
			}

			TTSDebtInquiryClient cancelInvoicePaymentClient = getSoapClient(iMap);
			ServiceMessage serviceMessage = new ServiceMessage();
			FaturaOdemeIptaliResponse cancelInvoicePaymentResponse = cancelInvoicePaymentClient.cancelInvoiceCollection(prepareCancelInvoicePaymentRequest(invoicePaymentDate, getCompanyCode(corporateCode), prepareInvoiceInfo(iMap, prepareReferenceInfo(invoicePaymentDateStr, paymentStanNo)), channel, iMap), serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			if (null != cancelInvoicePaymentResponse) {
				if (null != cancelInvoicePaymentResponse.getOzetCevapMesaj().getIslemSonucKodu() && cancelInvoicePaymentResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)) {
					output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				} else {
					setErrorCodeToOutput(cancelInvoicePaymentResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
				}
			}
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("ICS_TTS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[TTSystemService[collectionReconciliation]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_COLLECTION_RECONCILIATION");

		try {
			Date reconcilationDate = iMap.getDate(MapKeys.RECON_DATE);
			String tmpCorporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String corporateCode = getCompanyCode4Reconciliation(tmpCorporateCode);
			iMap.put(MapKeys.CORPORATE_CODE, corporateCode);
			iMap.put(MapKeys.TT_RECON_FLAG, true);
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			collectionTotal = collectionTotal.add(cancelTotal);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			collectionCount = collectionCount + cancelCount;

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			logger.info("[TTSystemService[collectionReconciliation]] Values will be used are : Reconciliation Date :" + reconcilationDate + " Corporate Code :" + corporateCode + " Total Collection Count : " + collectionCount + " Total Cancel Count " + cancelCount + " Total Collection Amount " + collectionTotal + " Total Cancel Amount " + cancelTotal);

			TTSReconClient reconClient = getReconSoapClient(iMap);

			MutabakatBilgi[] reconInfos = prepareReconcilationInfo(collectionCount, formatBankAmount2CorporateAmount(collectionTotal), cancelCount, formatBankAmount2CorporateAmount(cancelTotal));
			int totalProcessCount = TTSOtherCodes.TOTAL_PROCESS_COUNT;
			ServiceMessage serviceMessage = new ServiceMessage();
			MutabakatResponse reconciliationSummaryResponse = reconClient.sendReconciliationSummary(prepareReconcilationRequest(getCompanyCode(tmpCorporateCode), reconcilationDate, TTSReconcilationType.POSTPAID_ACCOUNTS_RECONCILIATION_TYPE, TTSProcessCode.POSTPAID_ACCOUNT_4_RECONCILIATION_CODE, reconInfos, totalProcessCount, iMap), serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			if (null != reconciliationSummaryResponse) {

				if (null != reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu() && reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)) {

					MutabakatBilgi[] reconciliationResultInfo = reconciliationSummaryResponse.getMutabakatBilgiDizi();

					if (null != reconciliationResultInfo) {
						if (null != reconciliationResultInfo[0]) {
							output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, formatCorporateAmount2BankFormat(reconciliationResultInfo[0].getToplamIslemTutari()));
							output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconciliationResultInfo[0].getToplamIslemSayisi());
							output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_STATUS, reconciliationResultInfo[0].getMutabakatDurumu());
						}
						if (null != reconciliationResultInfo[1]) {
							output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, formatCorporateAmount2BankFormat((reconciliationResultInfo[1].getToplamIslemTutari())));
							output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconciliationResultInfo[1].getToplamIslemSayisi());
							output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_STATUS, reconciliationResultInfo[1].getMutabakatDurumu());
						}
					}

					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

				} else {
					if (null != reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu() && reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.RECONCILIATION_FAILED)) {

						MutabakatBilgi[] reconciliationResultInfo = reconciliationSummaryResponse.getMutabakatBilgiDizi();

						if (null != reconciliationResultInfo) {
							if (null != reconciliationResultInfo[0]) {
								output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, formatCorporateAmount2BankFormat(reconciliationResultInfo[0].getToplamIslemTutari()));
								output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconciliationResultInfo[0].getToplamIslemSayisi());
								output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_STATUS, reconciliationResultInfo[0].getMutabakatDurumu());
							}
							if (null != reconciliationResultInfo[1]) {
								output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, formatCorporateAmount2BankFormat((reconciliationResultInfo[1].getToplamIslemTutari())));
								output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconciliationResultInfo[1].getToplamIslemSayisi());
								output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_STATUS, reconciliationResultInfo[1].getMutabakatDurumu());
							}
						}

						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						output.put(MapKeys.ERROR_CODE, "0");
					} else if (null != reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu() && reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.ALREADY_RECONCILIATION_SUCCESS)) {
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);

						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
						output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

					} else {
						if (null != reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu())
							logger.info("[TTSystemService[collectionReconciliation]] Corporate Reconciliation Results : " + reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu() + " Description : " + reconciliationSummaryResponse.getOzetCevapMesaj().getHataMesaji());

						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						output.put(MapKeys.ERROR_CODE, "0");
					}
				}

				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("ICS_TTS_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap outMap = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_GET_COLLECTION_RECONCILIATION_DETAIL");

		logger.info("[TTSystemService[getCollectionReconciliationDetail]] is started. Parameters : " + iMap);

		try {

		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);

		}

		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_TTS_FTM_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getFtmCollectionDetail(GMMap iMap) {
		GMMap outMap = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_FTM_COLLECTION_RECONCILIATION_DETAIL");

		List<String> corporateCodes = new ArrayList<String>();

		String corporateCodeList = null;
		String tmpCorporateCode = iMap.getString(TTSReconciliationLineParserProcess.Output.CORPORATE_CODE);
		if (tmpCorporateCode.contains(",")) {
			corporateCodeList = tmpCorporateCode.toString();
		} else {
			corporateCodeList = getCompanyCode4Reconciliation(tmpCorporateCode);
		}
		iMap.put(MapKeys.CORPORATE_CODE, corporateCodeList);
		if (corporateCodeList.contains(",")) {
			for (String corpCode : corporateCodeList.split(",")) {
				corporateCodes.add(corpCode);
			}
		} else {
			corporateCodes.add(corporateCodeList);
		}

		logger.info("[TTSystemService[getFtmCollectionDetail]] is started. Parameters : " + iMap);

		try {

			List<TTSReconciliationDetail> details = null;

			Session hibernateSession = CommonHelper.getHibernateSession();
			Criteria criteria = hibernateSession.createCriteria(ReconLog.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("reconStatus", DatabaseConstants.ReconciliationStatus.ReconciliationFailed)).add(Restrictions.in("corporateCode", corporateCodes)).addOrder(Order.desc("processDate")).addOrder(Order.desc("processTime"));

			List<ReconLog> reconLogs = criteria.setMaxResults(2).list();

			if (null != reconLogs && reconLogs.size() > 0) {
				ReconLog reconLog = reconLogs.get(0);

				if (null != reconLog) {
					String reconDate = reconLog.getReconDate();
					iMap.put(MapKeys.RECON_DATE, reconDate);

					if (DatabaseConstants.ReconciliationTypes.Collection == reconLog.getReconType()) {
						if (iMap.containsKey(TTSReconciliationLineParserProcess.Output.INVOICE_PAYMENT_LIST) && null != iMap.get(TTSReconciliationLineParserProcess.Output.INVOICE_PAYMENT_LIST)) {
							details = (List<TTSReconciliationDetail>) iMap.get(TTSReconciliationLineParserProcess.Output.INVOICE_PAYMENT_LIST);
						}

						BigDecimal collectionTotal = reconLog.getBankAmount();
						BigDecimal cancelTotal = reconLog.getBankCancelAmount();
						collectionTotal = collectionTotal.subtract(cancelTotal);
						int collectionCount = reconLog.getBankCount().intValue();
						int cancelCount = reconLog.getBankCancelCount().intValue();
						collectionCount = collectionCount - cancelCount;

						iMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
						iMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
						iMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
						iMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

						iMap.put(MapKeys.RECON_CORPORATE_COUNT, details.size());
						iMap.put(MapKeys.RECON_BANK_COUNT, collectionCount);

						CollectionReconciliationDetailBatch batch = new TTSCollectionReconciliationDetailBatch(iMap, details);
						outMap = batch.runBatch();
					}

					if (DatabaseConstants.ReconciliationTypes.StandingOrder == reconLog.getReconType()) {
						if (iMap.containsKey(TTSReconciliationLineParserProcess.Output.CANCEL_PAYMENT_LIST) && null != iMap.get(TTSReconciliationLineParserProcess.Output.CANCEL_PAYMENT_LIST)) {
							details = (List<TTSReconciliationDetail>) iMap.get(TTSReconciliationLineParserProcess.Output.CANCEL_PAYMENT_LIST);
						}

						GMMap rcInput = new GMMap();
						rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, corporateCodes);
						rcInput.put("RECON_DATE", reconDate);

						GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);

						int bankStandingOrderCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
						int bankStandingOrderCancelCount = rcOutput.getInt("CANCEL_COUNT");

						iMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
						iMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
						iMap.put(MapKeys.RECON_CORPORATE_COUNT, reconLog.getCorporateCount());
						iMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, reconLog.getCorporateCancelCount());

						StandingOrderReconciliationDetailBatch batch = new TTStandingOrderReconciliationDetailBatch(iMap, details);
						outMap = batch.runBatch();
					}

					logger.info("[TTSystemService[getCollectionReconciliationDetail]] Reconciliation Details Size  " + details.size());
				}
			}
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);

		}

		return outMap;
	}

	@GraymoundService("STO_TTS_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[TTSystemService[standingOrderReconciliation]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TTS_STANDING_ORDER_RECONCILIATION");
		try {
			Date reconDate = iMap.getDate(MapKeys.RECON_DATE);
			String tmpCorporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String corporateCode = getCompanyCode4Reconciliation(tmpCorporateCode);
			iMap.put(MapKeys.CORPORATE_CODE, corporateCode);

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", reconDate);

			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);

			int bankStandingOrderCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
			int bankStandingOrderCancelCount = rcOutput.getInt("CANCEL_COUNT");

			bankStandingOrderCount = bankStandingOrderCount + bankStandingOrderCancelCount;

			logger.info("[TTSystemService[standingOrderReconciliation]] Values will be used are : Reconciliation Date :" + reconDate + " Corporate Code :" + corporateCode + " Total Collection Count : " + bankStandingOrderCount + " Total Cancel Count " + bankStandingOrderCancelCount);

			boolean sendRequest = false;

			if (bankStandingOrderCount > 0 || bankStandingOrderCancelCount > 0) {
				sendRequest = true;
			}

			if (sendRequest) {

				TTSReconClient reconClient = getReconSoapClient(iMap);

				MutabakatBilgi[] reconInfos = prepareReconcilationInfo(bankStandingOrderCount, bankStandingOrderCancelCount);
				int totalProcessCount = TTSOtherCodes.TOTAL_PROCESS_COUNT;

				output.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
				ServiceMessage serviceMessage = new ServiceMessage();
				MutabakatResponse reconciliationSummaryResponse = reconClient.sendReconciliationSummary(prepareReconcilationRequest(getCompanyCode(tmpCorporateCode), reconDate, TTSReconcilationType.STO_ACCOUNTS_RECONCILIATION_TYPE, TTSProcessCode.STO_ACCOUNT_4_RECONCILIATION_CODE, reconInfos, totalProcessCount, iMap), serviceMessage);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				output.put("RESPONSE_XML", serviceMessage.getResponse());
				if (null != reconciliationSummaryResponse) {

					if (null != reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu() && reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)) {
						MutabakatBilgi[] reconciliationResultInfo = reconciliationSummaryResponse.getMutabakatBilgiDizi();
						if (null != reconciliationResultInfo) {
							if (null != reconciliationResultInfo[0]) {
								output.put(MapKeys.RECON_CORPORATE_COUNT, reconciliationResultInfo[0].getToplamIslemSayisi());
							}
							if (null != reconciliationResultInfo[1]) {
								output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, reconciliationResultInfo[1].getToplamIslemSayisi());
							}
						}
						output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						output.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Succeeded);
					} else {
						if (null != reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu() && reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.RECONCILIATION_FAILED)) {
							MutabakatBilgi[] reconciliationResultInfo = reconciliationSummaryResponse.getMutabakatBilgiDizi();
							if (null != reconciliationResultInfo) {
								if (null != reconciliationResultInfo[0]) {
									output.put(MapKeys.RECON_CORPORATE_COUNT, reconciliationResultInfo[0].getToplamIslemSayisi());
								}
								if (null != reconciliationResultInfo[1]) {
									output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, reconciliationResultInfo[1].getToplamIslemSayisi());
								}
							}
							output.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Canelled);
						} else if (null != reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu() && reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.ALREADY_RECONCILIATION_SUCCESS)) {
							MutabakatBilgi[] reconciliationResultInfo = reconciliationSummaryResponse.getMutabakatBilgiDizi();
							output.put(MapKeys.RECON_CORPORATE_COUNT, reconciliationResultInfo[0].getToplamIslemSayisi());
							output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, reconciliationResultInfo[1].getToplamIslemSayisi());

							output.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Succeeded);
						} else {
							if (null != reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu())
								logger.info("[TTSystemService[collectionReconciliation]] Corporate Reconciliation Results : " + reconciliationSummaryResponse.getOzetCevapMesaj().getIslemSonucKodu() + " Description : " + reconciliationSummaryResponse.getOzetCevapMesaj().getHataMesaji());
							output.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Canelled);

						}
					}
				}
			} else {

				output.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);

				output.put(MapKeys.RECON_CORPORATE_COUNT, TTSOtherCodes.DEFAULT_STANDING_ORDER_COUNT);
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, TTSOtherCodes.DEFAULT_STANDING_ORDER_COUNT);

				output.put(MapKeys.STANDING_ORDER_STATUS, StandingOrderStatus.Succeeded);
			}

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("STO_TTS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TTS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");

		try {

		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("STO_TTS_QUERY_STANDING_ORDER")
	public static GMMap queryStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[TTSystemService[queryStandingOrder]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TTS_QUERY_STANDING_ORDER");
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			logger.info("[TTSystemService[queryStandingOrder]] Values will be used are : Subscriber No :" + subscriberNo + "Corporate Code :" + corporateCode);

			TTSStandingOrderClient stoClient = getSTOSoapClient(iMap);
			ServiceMessage serviceMessage = new ServiceMessage();
			TalimatBilgiSorgulamaResponse queryStandingOrderResponse = stoClient.queryStandingOrder(prepareStandingOrderRequest(subscriberNo, getCompanyCode(corporateCode), iMap, 1), serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			if (null != queryStandingOrderResponse) {
				if (null != queryStandingOrderResponse.getOzetCevapMesaj()) {
					if(queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)){
						TalimatHesap[] stoAccountList = queryStandingOrderResponse.getTalimatHesapDizi();
						if (null != stoAccountList && null != stoAccountList[0]) {
							String ttAccountId = String.valueOf(stoAccountList[0].getHesapId());
							output.put(TTSOtherCodes.ACCOUNT_ID_KEY, ttAccountId);
							output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						}
					}
					else if (queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu().equals("58")){
						queryStandingOrderResponse = stoClient.queryStandingOrder(prepareStandingOrderRequest(subscriberNo, getCompanyCode(corporateCode), iMap, 3), serviceMessage);
						iMap.put("REQUEST_XML01", serviceMessage.getRequest());
						output.put("RESPONSE_XML01", serviceMessage.getResponse());
						if(queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)){
							TalimatHesap[] stoAccountList = queryStandingOrderResponse.getTalimatHesapDizi();
							if (null != stoAccountList && null != stoAccountList[0]) {
								String ttAccountId = String.valueOf(stoAccountList[0].getHesapId());
								output.put(TTSOtherCodes.ACCOUNT_ID_KEY, ttAccountId);
								output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
							}
						}else {
							setErrorCodeToOutput(queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
							output.put("RETURN_CODE", queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu());
							//throw new Exception("Hesap id bulunamad�!!!.");
						}
					}
					else{
						setErrorCodeToOutput(queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
						output.put("RETURN_CODE", queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu());
					}
				} else {
					setErrorCodeToOutput(queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
					output.put("RETURN_CODE", queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu());
					//throw new Exception("Hesap id bulunamad�!!!.");
				}
			}
		} catch (Exception ex) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("STO_TTS_SAVE_STANDING_ORDER")
	public static GMMap saveStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[TTSystemService[saveStandingOrder]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TTS_SAVE_STANDING_ORDER");
		try {
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			Date date = getInputDateOrDefault(iMap, MapKeys.RECON_DATE, "yyyyMMdd");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			logger.info("[TTSystemService[saveStandingOrder]] Values will be used are : Subscriber No :" + subscriberNo + "Corporate Code :" + corporateCode);

			GMMap queryTTAccountMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_TTS_QUERY_STANDING_ORDER", iMap);

			if (queryTTAccountMap.containsKey(TTSOtherCodes.ACCOUNT_ID_KEY)) {
				if (null != queryTTAccountMap.getString(TTSOtherCodes.ACCOUNT_ID_KEY)) {
					String ttAccountId = queryTTAccountMap.getString(TTSOtherCodes.ACCOUNT_ID_KEY);
					logger.info("[TTSystemService[saveStandingOrder]] Account ID has obtained. Values will be used are : Subscriber No :" + subscriberNo + "Corporate Code :" + corporateCode + "Process Date : " + date + " Account Id : " + ttAccountId);

					TTSStandingOrderClient stoClient = getSTOSoapClient(iMap);
					ServiceMessage serviceMessage = new ServiceMessage();
					TalimatEkleResponse stoResponse = stoClient.saveStandingOrder(prepareNewStandingOrderRequest(ttAccountId, getCompanyCode(corporateCode), date, iMap), serviceMessage);
					iMap.put("REQUEST_XML", serviceMessage.getRequest());
					output.put("RESPONSE_XML", serviceMessage.getResponse());
					if (null != stoResponse) {
						if (null != stoResponse.getOzetCevapMesaj() && stoResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)) {
							GMMap messageMap = new GMMap();
							messageMap.put("ENVIRONMENT", GMServiceExecuter.call("BNSPR_CORE_GET_SISTEM_ADI", iMap).getString("SISTEM_ADI"));
							String currentDate = CommonHelper.getDateString(new Date(), "yyyyMMdd");
							messageMap.put("CURRENT_DATE", CommonHelper.formatDateString(currentDate, "yyyyMMdd", "dd/MM/yyyy"));
							List<Map<String, String>> mapList = new ArrayList<Map<String, String>>();
							Map<String, String> columnMap = new HashMap<String, String>();
							GMMap corporateDefMap = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, new GMMap().put("CORPORATE_CODE", corporateCode));
							columnMap.put("KURUM_ADI", corporateDefMap.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE));
							columnMap.put("ABONE_NO", subscriberNo);
							columnMap.put("HESAP_ID", ttAccountId);
							mapList.add(columnMap);
							messageMap.put("MAP_TABLE", mapList);

							EmailMessage emailMessage = CommonHelper.prepareEmailBody("", messageMap, NewStandingOrderRequestMessageConstant.MESSAGE_BODY, NewStandingOrderRequestMessageConstant.SUBJECT, NewStandingOrderRequestMessageConstant.RECEIPT_LIST);

							CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(), true);
							output.put(MapKeys.SUBSCRIBER_NO4, ttAccountId);
							output.put("RETURN_INFO_FOR_UPDATE", "YES");
						} else {
							setErrorCodeToOutput(stoResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
						}
					}
					output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				}
			}else {
				setErrorCodeToOutput(queryTTAccountMap.getString("RETURN_CODE"), iMap, output);
			}
		} catch (Exception ex) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("STO_TTS_CANCEL_STANDING_ORDER")
	public static GMMap cancelStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();

		logger.info("[TTSystemService[cancelStandingOrder]] is started. Parameters : " + iMap);
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_TTS_CANCEL_STANDING_ORDER");
		try {
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			Date date = getInputDateOrDefault(iMap, MapKeys.RECON_DATE, "yyyyMMdd");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			logger.info("[TTSystemService[cancelStandingOrder]] Values will be used are : Subscriber No :" + subscriberNo + "Corporate Code :" + corporateCode);

			TTSStandingOrderClient stoClient = getSTOSoapClient(iMap);
			ServiceMessage serviceMessage = new ServiceMessage();
			TalimatBilgiSorgulamaResponse queryStandingOrderResponse = stoClient.queryStandingOrder(prepareStandingOrderRequest(subscriberNo, getCompanyCode(corporateCode), iMap, 1), serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			String ttAccountId = null;

			if (null != queryStandingOrderResponse) {
				boolean successful = true;
				if (null != queryStandingOrderResponse.getOzetCevapMesaj() && !queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)) {
					if(queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu().equals("58")){
						queryStandingOrderResponse = stoClient.queryStandingOrder(prepareStandingOrderRequest(subscriberNo, getCompanyCode(corporateCode), iMap, 3), serviceMessage);
						iMap.put("REQUEST_XML01", serviceMessage.getRequest());
						output.put("RESPONSE_XML01", serviceMessage.getResponse());
						if (null != queryStandingOrderResponse.getOzetCevapMesaj() && !queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)){
							successful = false;
							setErrorCodeToOutput(queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
						}
						else{
							successful = true;
						}
					}
					else{
						successful = false;
						setErrorCodeToOutput(queryStandingOrderResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
					}
				} 
				
				
				if(successful) {
					TalimatHesap[] stoList = queryStandingOrderResponse.getTalimatHesapDizi();
					if (null != stoList && null != stoList[0]) {
						ttAccountId = String.valueOf(stoList[0].getHesapId());
						logger.info("[TTSystemService[saveStandingOrder]] Account ID has obtained. Values will be used are : Subscriber No :" + subscriberNo + "Corporate Code :" + corporateCode + "Process Date : " + date + " Account Id : " + ttAccountId);
					}

					if (null != ttAccountId) {
						logger.info("[TTSystemService[cancelStandingOrder]] Values will be used are : Subscriber No :" + subscriberNo + "Corporate Code :" + corporateCode + "Process Date : " + date);
						ServiceMessage serviceMessageQuery = new ServiceMessage();
						TalimatCikarResponse stoResponse = stoClient.cancelStandingOrder(prepareCancelStandingOrderRequest(ttAccountId, getCompanyCode(corporateCode), date, iMap), serviceMessageQuery);
						iMap.put("REQUEST_XML_QUERY", serviceMessage.getRequest());
						output.put("RESPONSE_XML_QUERY", serviceMessage.getResponse());
						if (null != stoResponse) {
							if (null != stoResponse.getOzetCevapMesaj() && !stoResponse.getOzetCevapMesaj().getIslemSonucKodu().equals(TTSResponseCode.SUCCES)) {
								setErrorCodeToOutput(stoResponse.getOzetCevapMesaj().getIslemSonucKodu(), iMap, output);
							}
						}
					} else {
						logger.info("[TTSystemService[cancelStandingOrder]] Account Id has not been obtained.");
					}
				}
			}

			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(ex));
			throw ExceptionHandler.convertException(ex);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@GraymoundService("ICS_TTS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_COLLECTION_RECONCILIATION_CLOSED");
		GMMap output = new GMMap();
		String responseCode = "";
		try {
			// String tmpCorporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			// iMap.put(MapKeys.CORPORATE_CODE, corporateCode);
			Calendar reconDate = Calendar.getInstance();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE).concat(" ").concat(Integer.toString(reconDate.get(Calendar.HOUR))).concat(":").concat(Integer.toString(reconDate.get(Calendar.MINUTE))).concat(":").concat(Integer.toString(reconDate.get(Calendar.SECOND))), "yyyyMMdd HH:mm:ss"));

			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}

		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_TTS_DETAIL_FTM_FILE_CONTENT")
	public static GMMap detailFTMFileContent(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_DETAIL_FTM_FILE_CONTENT");
		GMMap outMap = new GMMap();

		try {
			BigDecimal ftmProcessOID = iMap.getBigDecimal("PROCESS_ID");
			logger.info("PROCESS_ID is " + ftmProcessOID);
			if (ftmProcessOID == null) {
				logger.error("Error getting FTM Process OID from iMap");
				return outMap;
			}

			Session session = CommonHelper.getHibernateSession();
			Criteria criteriaFtmContentList = session.createCriteria(FtmFileContent.class).add(Restrictions.eq("ftmProcessOid", ftmProcessOID)).addOrder(Order.asc("lineNumber"));
			List<FtmFileContent> ftmFileContentList = criteriaFtmContentList.list();
			logger.info("ftmFileContentList size is " + ftmFileContentList.size());

			List<FtmFileContent> ttSubscribers = new ArrayList<FtmFileContent>();
			BigDecimal ttProcessID = getNextValueOfProcessSequence();
			outMap.put("TURK_TELEKOM_PROCESS_ID", ttProcessID);
			String ttCorporateCode = CommonHelper.getValueOfParameter("TTS_CORPORATE_CODES", "TT");
			outMap.put("TURK_TELEKOM_CORPORATE_CODE", ttCorporateCode);
			int ttLineNumber = 1;
			iMap.put(MapKeys.CORPORATE_CODE, ttCorporateCode);

			List<FtmFileContent> ttnetSubscribers = new ArrayList<FtmFileContent>();
			BigDecimal ttnetProcessID = getNextValueOfProcessSequence();
			outMap.put("TTNET_PROCESS_ID", ttnetProcessID);
			String ttnetCorporateCode = CommonHelper.getValueOfParameter("TTS_CORPORATE_CODES", "TTNET");
			outMap.put("TTNET_CORPORATE_CODE", ttnetCorporateCode);
			int ttnetLineNumber = 1;

			int fileLineCounter = 1;
			String header = "", footer = "";
			for (FtmFileContent ftmFileContent : ftmFileContentList) {
				logger.info("ftmFileContent line is " + ftmFileContent.getLine());
				String subscriberNo = ftmFileContent.getLine().substring(1, 21);
				String ttAccountId = CommonHelper.trimStart(ftmFileContent.getLine().substring(165, 177), '0');
				subscriberNo = CommonHelper.trimEnd(subscriberNo, ' ');
				Criterion criterionSubscriberNo1 = Restrictions.eq("subscriberNo1", subscriberNo);
				Criterion criterionSubscriberNo4 = Restrictions.eq("subscriberNo4", ttAccountId);
				Criteria criteriaSTOSubscriber = session.createCriteria(icsStandingOrders.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("standingOrderStatus", DatabaseConstants.StandingOrderStatus.Active)).add(criterionSubscriberNo1);
				Criteria criteriaSTOAccount = session.createCriteria(icsStandingOrders.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("standingOrderStatus", DatabaseConstants.StandingOrderStatus.Active)).add(criterionSubscriberNo4);
				String corporateCode = null;

				// header ekliyoruz
				if (fileLineCounter == 1) {
					header = ftmFileContent.getLine();

					FtmFileContent h1 = new FtmFileContent();
					h1.setLine(header);
					h1.setFtmProcessOid(ttProcessID);
					h1.setLineNumber(new BigDecimal(ttLineNumber));
					h1.setOid(String.valueOf(fileLineCounter++));
					ttSubscribers.add(h1);
					ttLineNumber++;

					FtmFileContent h2 = new FtmFileContent();
					h2.setLine(header);
					h2.setFtmProcessOid(ttnetProcessID);
					h2.setLineNumber(new BigDecimal(ttnetLineNumber));
					h2.setOid(String.valueOf(fileLineCounter++));
					ttnetSubscribers.add(h2);
					ttnetLineNumber++;
				}
				/*SUBSCRIBER NUMARASINA GORE TALIMAT VAR ISE FTM_FILE_CONTENT UZERINDEN AKIS DEVAM EDER*/
				try {
					icsStandingOrders standingOrder = (icsStandingOrders) criteriaSTOSubscriber.uniqueResult();
					if (standingOrder != null) {
						FtmFileContent fc = new FtmFileContent();
						fc.setLine(ftmFileContent.getLine());

						// ilgili aboneyi ekliyoruz
						if (standingOrder.getCorporateCode().equals(ttCorporateCode)) {
							fc.setFtmProcessOid(ttProcessID);
							fc.setLineNumber(new BigDecimal(ttLineNumber));
							fc.setOid(String.valueOf(fileLineCounter++));
							ttSubscribers.add(fc);
							ttLineNumber++;
						} else if (standingOrder.getCorporateCode().equals(ttnetCorporateCode)) {
							fc.setFtmProcessOid(ttnetProcessID);
							fc.setLineNumber(new BigDecimal(ttnetLineNumber));
							fc.setOid(String.valueOf(fileLineCounter++));
							ttnetSubscribers.add(fc);
							ttnetLineNumber++;
						}
					}
				} catch (Exception e) {
					logger.info("standing order table not return apropriate result. corporateCode : " + corporateCode);
				}
				
				/*ACCOUNTID UZERINDEN TALIMAT VAR ISE MANUEL BORC YUKLEME GERCEKLESTIRILIR*/
				try {
					icsStandingOrders standingOrder = (icsStandingOrders) criteriaSTOAccount.uniqueResult();
					if (standingOrder != null) {
						
						StandingOrderMain stoMain = (StandingOrderMain) session.createCriteria(StandingOrderMain.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("oid", standingOrder.getStandingOrderOid())).uniqueResult();
						if(stoMain != null && stoMain.getEndDate().compareTo(new Date()) > 0){
							BigDecimal ftmSeqNum = standingOrder.getCorporateCode().equals(ttCorporateCode) ? ttProcessID : ttnetProcessID;
							String strAmount = CommonHelper.trimStart(ftmFileContent.getLine().substring(137, 157),'0');
							BigDecimal amount = new BigDecimal(strAmount).divide(new BigDecimal("100"));
							
							String query = String.format("INSERT INTO ICS.INVOICE_MAIN(OID,STATUS,CORPORATE_CODE,COLLECTION_TYPE,INVOICE_NO,AMOUNT,SUBSCRIBER_NO1, SUBSCRIBER_NO4,SUBSCRIBER_NAME," +
									"STANDING_ORDER_OID,INVOICE_DUE_DATE, INVOICE_STATUS,PAYMENT_STATUS,PAYMENT_METHOD,TERM_YEAR,TERM_MONTH,FTM_SEQUENCE_NUMBER,LOADING_DATE,LOADING_USER," +
									"PARAMETER1,PARAMETER3,PARAMETER5,PARAMETER6, PARAMETER7) " +
									"VALUES('%s', '1','%s','0','%s','%s','%s','%s','%s','%s','%s','%s','%s','S','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')", 
									UUID.randomUUID().toString().substring(0, 32),
									standingOrder.getCorporateCode(),
									ftmFileContent.getLine().substring(36, 52),
									amount.toString().replace('.', ','),
									subscriberNo,
									ttAccountId,
									ftmFileContent.getLine().substring(77, 137),
									standingOrder.getStandingOrderOid(),
									ftmFileContent.getLine().substring(69, 77),
									DatabaseConstants.InvoiceStatuses.Active,
									DatabaseConstants.PaymentStatuses.Waiting,
									ftmFileContent.getLine().substring(63, 67),
									ftmFileContent.getLine().substring(67, 69),
									ftmSeqNum,
									CommonHelper.getLongDateTimeString(new Date()),
									CommonHelper.getCurrentUser(),
									ftmFileContent.getLine().substring(21, 25),
									ftmFileContent.getLine().substring(26, 36),
									ftmFileContent.getLine().substring(54, 57),
									ftmFileContent.getLine().substring(57, 63),
									ftmFileContent.getLine().substring(157, 177));
							CommonHelper.executeQuery(query);
						}
					}
				} catch (Exception e) {
					logger.info("standing order table not return apropriate result. corporateCode : " + corporateCode + " exception : " + e.getMessage());
				}

				footer = ftmFileContent.getLine();
			}

			// footer ekliyoruz
			FtmFileContent f1 = new FtmFileContent();
			f1.setLine(footer);
			f1.setFtmProcessOid(ttProcessID);
			f1.setLineNumber(new BigDecimal(ttLineNumber));
			f1.setOid(String.valueOf(fileLineCounter++));
			ttSubscribers.add(f1);

			FtmFileContent f2 = new FtmFileContent();
			f2.setLine(footer);
			f2.setFtmProcessOid(ttnetProcessID);
			f2.setLineNumber(new BigDecimal(ttnetLineNumber));
			f2.setOid(String.valueOf(fileLineCounter++));
			ttnetSubscribers.add(f2);

			for (FtmFileContent s : ttSubscribers)
				session.save(s);
			for (FtmFileContent s : ttnetSubscribers)
				session.save(s);

			session.flush();

			outMap.put("TURK_TELEKOM_LINE_COUNT", ttSubscribers.size());
			outMap.put("TTNET_LINE_COUNT", ttnetSubscribers.size());
			CorporateFileTransfer o = null;
			GMMap ttFTMinput = new GMMap();

			// turktelekom icin servis cagrilir
			o = (CorporateFileTransfer) session.createCriteria(CorporateFileTransfer.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("transferType", DatabaseConstants.TransferTypes.InvoiceLoading)).add(Restrictions.eq("corporateCode", ttCorporateCode)).uniqueResult();
			if (o != null) {
				logger.info("before ICS_FTM_BATCH_STARTER for TURKTELEKOM");
				ttFTMinput.put(TransactionConstants.FtmBatchStarter.Input.FTM_ID, o.getFtmId());
				ttFTMinput.put(TransactionConstants.FtmBatchStarter.Input.FTM_TRANSFER_ID, ttProcessID);
				GMServiceExecuter.call("ICS_FTM_BATCH_STARTER", ttFTMinput);
			}
			// ttnet icin servis cagrilir
			o = (CorporateFileTransfer) session.createCriteria(CorporateFileTransfer.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("transferType", DatabaseConstants.TransferTypes.InvoiceLoading)).add(Restrictions.eq("corporateCode", ttnetCorporateCode)).uniqueResult();
			if (o != null) {
				logger.info("before ICS_FTM_BATCH_STARTER for TTNET");
				ttFTMinput = new GMMap();
				ttFTMinput.put(TransactionConstants.FtmBatchStarter.Input.FTM_ID, o.getFtmId());
				ttFTMinput.put(TransactionConstants.FtmBatchStarter.Input.FTM_TRANSFER_ID, ttnetProcessID);
				GMServiceExecuter.call("ICS_FTM_BATCH_STARTER", ttFTMinput);
			}

		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TTS_DETAIL_FTM_FILE_CONTENT");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_TTS_MERGE_FTM_FILE_CONTENT")
	public static GMMap mergeFTMFileContent(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TTS_MERGE_FTM_FILE_CONTENT");
		GMMap outMap = new GMMap();
		try {
			String ttFileDefinitionOid = CommonHelper.getValueOfParameter("TT_FTM_FILE_DEFINITION_OID", "TT");
			String ttnetFileDefinitionOid = CommonHelper.getValueOfParameter("TT_FTM_FILE_DEFINITION_OID", "TTNET");
			String ttCorporateCode = CommonHelper.getValueOfParameter("TTS_CORPORATE_CODES", "TT");
			String ttnetCorporateCode = CommonHelper.getValueOfParameter("TTS_CORPORATE_CODES", "TTNET");

			outMap.put("TURK_TELEKOM_CORPORATE_CODE", ttCorporateCode);
			outMap.put("TTNET_CORPORATE_CODE", ttnetCorporateCode);
			iMap.put(MapKeys.CORPORATE_CODE, ttCorporateCode);

			logger.info("FileTransferLog tablosundan kayitlari cekiyorum");
			Session session = CommonHelper.getHibernateSession();
			List<FileTransferLog> ttFileLogs = session.createCriteria(FileTransferLog.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", ttCorporateCode)).add(Restrictions.eq("ftmId", ttFileDefinitionOid)).addOrder(Order.desc("logDate")).setMaxResults(1).list();
			List<FileTransferLog> ttnetFileLogs = session.createCriteria(FileTransferLog.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", ttnetCorporateCode)).add(Restrictions.eq("ftmId", ttnetFileDefinitionOid)).addOrder(Order.desc("logDate")).setMaxResults(1).list();
			logger.info("FileTransferLog tablosundan kayitlari cektim");

			List<FtmFileContent> TTFtmFileContentList = null;
			List<FtmFileContent> ttnetFtmFileContentList = null;
			List<FtmFileContent> listForDeletion = new ArrayList<FtmFileContent>();

			if (ttFileLogs != null && ttFileLogs.size() > 0) {
				TTFtmFileContentList = session.createCriteria(FtmFileContent.class).add(Restrictions.eq("ftmProcessOid", ttFileLogs.get(0).getFtmSequenceNumber())).addOrder(Order.asc("lineNumber")).list();
				logger.info("TTFtmFileContentList size is " + TTFtmFileContentList.size());
				outMap.put("TURK_TELEKOM_FILE_CONTENT_SIZE", TTFtmFileContentList.size());
			}

			if (ttnetFileLogs != null && ttnetFileLogs.size() > 0) {
				ttnetFtmFileContentList = session.createCriteria(FtmFileContent.class).add(Restrictions.eq("ftmProcessOid", ttnetFileLogs.get(0).getFtmSequenceNumber())).addOrder(Order.asc("lineNumber")).list();
				logger.info("ttnetFtmFileContentList size is " + ttnetFtmFileContentList.size());
				outMap.put("TTNET_FILE_CONTENT_SIZE", ttnetFtmFileContentList.size());
			}

			int ttHeaderCounter = 0;
			int ttnetHeaderCounter = 0;
			int counter = 1;
			BigDecimal ftmProcessOid = null;
			String header = "";
			for (FtmFileContent ftmFileContent : TTFtmFileContentList) {
				ftmProcessOid = ftmFileContent.getFtmProcessOid();
				counter = ftmFileContent.getLineNumber().intValue();
				if (counter == 1) {
					header = ftmFileContent.getLine();
					ttHeaderCounter = Integer.parseInt(header.substring(33, 41));
					logger.info("header get from file :" + header);
					logger.info("ttHeaderCounter :" + ttHeaderCounter);
				}
			}

			outMap.put("TT_HEADER", header);
			outMap.put("TT_HEADER_COUNT", ttHeaderCounter);

			// son satir footer dir onu alip dosyanin sonuna eklememiz gerekiyor
			FtmFileContent footer = TTFtmFileContentList.get(counter - 1);
			TTFtmFileContentList.remove(counter - 1);
			
			logger.info("TTFtmFileContentList listesinden footer yedeklemek icin cikartildi");

			int sCounter = 0;
			for (FtmFileContent ftmFileContent : ttnetFtmFileContentList) {
				if (sCounter == 0) {
					ttnetHeaderCounter = Integer.parseInt(ftmFileContent.getLine().substring(33, 41));
					listForDeletion.add(ftmFileContent);
					sCounter++;
					outMap.put("TTNET_HEADER_COUNT", ttHeaderCounter);
				} else {
					ftmFileContent.setLineNumber(new BigDecimal(counter));
					ftmFileContent.setFtmProcessOid(ftmProcessOid);
					TTFtmFileContentList.add(ftmFileContent);
					counter++;
				}
			}
			
			header = header.substring(0, 33) + String.format("%08d", ttHeaderCounter + ttnetHeaderCounter) + header.substring(41, header.length());
			outMap.put("OVERALL_HEADER", header);
			TTFtmFileContentList.get(0).setLine(header);// header da rakamlar toplanip set edilir
			
			
			//son satir footer onu kaldirip bironceki dosyanin footer ini eklicez
			listForDeletion.add(TTFtmFileContentList.get(TTFtmFileContentList.size() - 1));
			TTFtmFileContentList.remove(TTFtmFileContentList.size() - 1);
			
			//line numarasi aldigim yerdeki ile ayni kaldi guncelliyorum ve ekliyorum. processOid zaten kullandigimiz deger
			footer.setLineNumber(new BigDecimal(counter - 1));
			TTFtmFileContentList.add(footer);

			Transaction transaction = session.beginTransaction();
			try {

				for (FtmFileContent ftmFileContent : TTFtmFileContentList)
					session.saveOrUpdate(ftmFileContent);
				logger.info("TTFtmFileContentList listesi DB de guncellendi");

				for (FtmFileContent ftmFileContent : listForDeletion)
					session.delete(ftmFileContent);
				logger.info("listForDeletion listesi DB den silindi");

				transaction.commit();
				logger.info("transaction.commit()  calisti");
			} catch (Exception e) {
				transaction.rollback();
				logger.info("transaction.rollback() calisti");
			}
			
			CorporateBatchProcess cbp = (CorporateBatchProcess) session.createCriteria(CorporateBatchProcess.class).add(Restrictions.eq("status", true))
						.add(Restrictions.eq("corporateCode", ttCorporateCode))
						.add(Restrictions.eq("batchName", DatabaseConstants.BatchNames.InformInvoiceCollectionBatch)).uniqueResult();
			
			GMMap prmMap = new GMMap();
			prmMap.put(TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID, cbp.getOid());
			prmMap = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetBatchParameters.SERVICE_NAME, prmMap);
			
			if(prmMap.containsKey(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS)){
				BatchParameterEngine engine = new BatchParameterEngine(prmMap.getString(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS));
				prmMap = CommonHelper.convertMapToGMMap(engine.getDecomposedParameters());
			}
			
			boolean callFtm = true;
			if(prmMap.getString("FTM_BOS_DOSYA_CAGRISI_YAPMA", "2").equals(DatabaseConstants.BatchParameterValues.DoNotCallFtmWithEmtyFileEnabled)){
				if(TTFtmFileContentList.size() < 3){
					callFtm = false;
					outMap.put("DOSYA_SATIR_SAYISI", "3 satirdan kucuk");
				}
			}
			// bir onceki gunun tarihini gondericez
			String processDate = CommonHelper.getShortDateTimeString(new Date(new Date().getTime() - (1000 * 60 * 60 * 24)));
			
			if(callFtm){
				GMMap input = new GMMap();
				input.put("FILE_DEF_ID", Long.valueOf(ttFileDefinitionOid));
				input.put("PROCESS_ID", ftmProcessOid.longValue());
				input.put("PROCESS_DATE", processDate);
				CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.FTM_CONNECTION_NAME, "BNSPR_FTM_CREATE_AND_TRANSFER_FILE", input);
				logger.info("BNSPR_FTM_CREATE_AND_TRANSFER_FILE servisi cagrildi");
	
				String emails = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_INFORM_REPORT");
				CommonHelper.sendMail(Arrays.asList(emails.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "Tahsilat Bildirim batch'i i�in " + processDate + " tarihli �al��ma raporu", "Turk Telekom Ve TTNET Tahsilat Bildirim Ba�ar�l�");
			}else{
				String emails = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_INFORM_REPORT");
				CommonHelper.sendMail(Arrays.asList(emails.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "Tahsilat Bildirim batch'i i�in " + processDate + " tarihli �al��ma raporu", "Turk Telekom Ve TTNET Tahsilat Bildirim : tahsilat olmadigi icin dosya olusturulmadi");
			}
			
			outMap.put("FILE_DEF_ID", Long.valueOf(ttFileDefinitionOid));
			outMap.put("PROCESS_ID", ftmProcessOid.longValue());
			outMap.put("PROCESS_DATE", processDate);
			
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_TTS_MERGE_FTM_FILE_CONTENT");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_TURK_TELEKOM_MANAGE_STAN")
	public static GMMap turkTelekomManageStan(GMMap input){
		GMMap output = new GMMap();
		
		try{
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='ICS_STAN_NO'");	
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

	private static BigDecimal getNextValueOfProcessSequence() {
		return new BigDecimal(((Number) CommonHelper.getHibernateSession().createSQLQuery("SELECT ftm.seq_ftm_process.nextval FROM dual").uniqueResult()).longValue());
	}

	private static TTSDebtInquiryClient getSoapClient(GMMap iMap) {
		Object wsEndpoint = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		Object wsUser = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		Object wsPassword = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);

		TTSDebtInquiryClient debtInquiryClient = new TTSDebtInquiryClient(wsEndpoint.toString(), wsUser.toString(), wsPassword.toString());

		return debtInquiryClient;
	}

	private static TTSReconClient getReconSoapClient(GMMap iMap) {
		Object wsEndpoint = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		Object wsUser = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		Object wsPassword = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);

		TTSReconClient reconClient = new TTSReconClient(wsEndpoint.toString(), wsUser.toString(), wsPassword.toString());

		return reconClient;
	}

	private static TTSStandingOrderClient getSTOSoapClient(GMMap iMap) {
		Object wsEndpoint = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		Object wsUser = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		Object wsPassword = iMap.get(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);

		TTSStandingOrderClient stoClient = new TTSStandingOrderClient(wsEndpoint.toString(), wsUser.toString(), wsPassword.toString());

		return stoClient;
	}

	private static OdemeOncesiFaturaSorgulamaRequest prepareDebtInquiryRequest(String subscriberNo, int billCycleType, int companyCode, GMMap iMap) throws Exception, ParseException {
		OdemeOncesiFaturaSorgulamaRequest request = new OdemeOncesiFaturaSorgulamaRequest();
		request.setMesajTipi(TTSMessageType.DEBT_INQUERY_REQUEST_CODE);
		request.setIslemKodu(TTSProcessCode.DEBT_INQUIRY_CODE);
		request.setErisimBilgi(new ErisimBilgi(TTSAccesType.SERVICE_NO, subscriberNo));
		request.setFaturaDonemi(billCycleType);
		request.setSirketKodu(companyCode);

		prepareCommonData(request, iMap);

		int processDate;
		if (iMap.containsKey(MapKeys.PAYMENT_DATE)) {
			processDate = convertDate2TTDate(iMap.getString(MapKeys.PAYMENT_DATE));
		} else {
			processDate = getTTProcessDate();
		}
		request.setIslemTarihi(processDate);

		logger.info("[TTSystemService [prepareDebtInquiryRequest]] Values are " + makeLogs(request));
		return request;
	}

	private static int convertDate2TTDate(String dateString) throws ParseException {
		int processDate;
		if (null != dateString && !StringUtil.isEmpty(dateString)) {
			processDate = Integer.parseInt(CommonHelper.getDateString(CommonHelper.getDateTime(dateString, "yyyyMMddHHmmss"), "yyyyMMdd"));
		} else {
			processDate = Integer.parseInt(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
		}
		return processDate;
	}

	private static int convertDate2TTDate(Date date) throws ParseException {
		int processDate;
		if (null != date) {
			processDate = Integer.parseInt((CommonHelper.getShortDateTimeString(date)));
		} else {
			processDate = Integer.parseInt(CommonHelper.getDateString(new Date(), "yyyyMMdd"));
		}
		return processDate;
	}

	private static void prepareCommonData(Object requestObj, GMMap iMap) throws NumberFormatException, Exception {

		IslemYapan register = new IslemYapan(TTSOtherCodes.CITY_CODE, TTSOtherCodes.BRANCH_CODE, TTSOtherCodes.OFFICE_CODE, TTSOtherCodes.USER_CODE);
		int stan;
		if (iMap.containsKey(MapKeys.STAN_NO) && null != iMap.getString(MapKeys.STAN_NO)) {
			stan = iMap.getInt(MapKeys.STAN_NO);
		} else {
			stan = generateStan();
		}

		int processTime = 100000;

		if (FaturaOdemeRequest.class.isInstance(requestObj)) {
			((FaturaOdemeRequest) requestObj).setIslemYapan(register);
			((FaturaOdemeRequest) requestObj).setKurumKodu(TTSOtherCodes.BANK_CORPORATE_CODE);
			((FaturaOdemeRequest) requestObj).setStan(stan);
			((FaturaOdemeRequest) requestObj).setIslemSaati(processTime);
			((FaturaOdemeRequest) requestObj).setParaKodu(TTSOtherCodes.CURRENCY);
			((FaturaOdemeRequest) requestObj).setMesajTarihSaat(processTime);
		} else if (OdemeOncesiFaturaSorgulamaRequest.class.isInstance(requestObj)) {
			((OdemeOncesiFaturaSorgulamaRequest) requestObj).setIslemYapan(register);
			((OdemeOncesiFaturaSorgulamaRequest) requestObj).setKurumKodu(TTSOtherCodes.BANK_CORPORATE_CODE);
			((OdemeOncesiFaturaSorgulamaRequest) requestObj).setStan(stan);
			((OdemeOncesiFaturaSorgulamaRequest) requestObj).setIslemSaati(processTime);
			((OdemeOncesiFaturaSorgulamaRequest) requestObj).setParaKodu(TTSOtherCodes.CURRENCY);
			((OdemeOncesiFaturaSorgulamaRequest) requestObj).setMesajTarihSaat(processTime);
			((OdemeOncesiFaturaSorgulamaRequest) requestObj).setKayitSayisi(TTSOtherCodes.DEFAULT_RECORD_COUNT);
		} else if (FaturaOdemeIptaliRequest.class.isInstance(requestObj)) {
			((FaturaOdemeIptaliRequest) requestObj).setIslemYapan(register);
			((FaturaOdemeIptaliRequest) requestObj).setKurumKodu(TTSOtherCodes.BANK_CORPORATE_CODE);
			((FaturaOdemeIptaliRequest) requestObj).setStan(stan);
			((FaturaOdemeIptaliRequest) requestObj).setIslemSaati(processTime);
			((FaturaOdemeIptaliRequest) requestObj).setParaKodu(TTSOtherCodes.CURRENCY);
			((FaturaOdemeIptaliRequest) requestObj).setMesajTarihSaat(processTime);
		}

		else if (MutabakatRequest.class.isInstance(requestObj)) {
			((MutabakatRequest) requestObj).setIslemYapan(register);
			((MutabakatRequest) requestObj).setKurumKodu(TTSOtherCodes.BANK_CORPORATE_CODE);
			((MutabakatRequest) requestObj).setStan(stan);
			((MutabakatRequest) requestObj).setIslemSaati(processTime);
			((MutabakatRequest) requestObj).setParaKodu(TTSOtherCodes.CURRENCY);
		} else if (TalimatEkleRequest.class.isInstance(requestObj)) {
			((TalimatEkleRequest) requestObj).setIslemYapan(register);
			((TalimatEkleRequest) requestObj).setKurumKodu(TTSOtherCodes.BANK_CORPORATE_CODE);
			((TalimatEkleRequest) requestObj).setStan(stan);
			((TalimatEkleRequest) requestObj).setIslemSaati(processTime);
			((TalimatEkleRequest) requestObj).setParaKodu(TTSOtherCodes.CURRENCY);
		} else if (TalimatBilgiSorgulamaRequest.class.isInstance(requestObj)) {
			((TalimatBilgiSorgulamaRequest) requestObj).setIslemYapan(register);
			((TalimatBilgiSorgulamaRequest) requestObj).setKurumKodu(TTSOtherCodes.BANK_CORPORATE_CODE);
			((TalimatBilgiSorgulamaRequest) requestObj).setStan(stan);
			((TalimatBilgiSorgulamaRequest) requestObj).setIslemSaati(processTime);
			((TalimatBilgiSorgulamaRequest) requestObj).setParaKodu(TTSOtherCodes.CURRENCY);
		}

		else if (TalimatCikarRequest.class.isInstance(requestObj)) {
			((TalimatCikarRequest) requestObj).setIslemYapan(register);
			((TalimatCikarRequest) requestObj).setKurumKodu(TTSOtherCodes.BANK_CORPORATE_CODE);
			((TalimatCikarRequest) requestObj).setStan(stan);
			((TalimatCikarRequest) requestObj).setIslemSaati(processTime);
			((TalimatCikarRequest) requestObj).setParaKodu(TTSOtherCodes.CURRENCY);
		}
	}

	private static FaturaOdemeRequest prepareInvoicePaymentRequest(int companyCode, FaturaBilgi invoiceInfo, int channel, int paymentDate, GMMap iMap) throws NumberFormatException, Exception {
		FaturaOdemeRequest invoicePaymentRequest = new FaturaOdemeRequest();

		invoicePaymentRequest.setMesajTipi(TTSMessageType.DO_NOTIFICATION_REQUEST_CODE);
		invoicePaymentRequest.setIslemKodu(TTSProcessCode.DO_INVIOCE_COLLECTION_CODE);
		invoicePaymentRequest.setIslemKabulTarihi(paymentDate);
		invoicePaymentRequest.setSirketKodu(companyCode);
		invoicePaymentRequest.setIslemKaynagi(channel);
		invoicePaymentRequest.setIslemTarihi(paymentDate);

		prepareCommonData(invoicePaymentRequest, iMap);

		invoicePaymentRequest.setFaturaBilgiDizi(new FaturaBilgi[] { invoiceInfo });

		logger.info("[TTSystemService [prepareInvoicePaymentRequest]] Values are " + makeLogs(invoicePaymentRequest));
		return invoicePaymentRequest;
	}

	private static FaturaBilgi prepareInvoiceInfo(GMMap iMap, ReferansBilgi paymentRefInfo) {
		FaturaBilgi invoiceRequestInfo = new FaturaBilgi();

		if (null != iMap.getString(MapKeys.PARAMETER3) && !"".equals(iMap.getString(MapKeys.PARAMETER3))) {
			invoiceRequestInfo.setReferansNo(iMap.getString(MapKeys.PARAMETER3));
		}

		if (null != iMap.getString(MapKeys.PAYMENT_AMOUNT) && !"".equals(iMap.getString(MapKeys.PAYMENT_AMOUNT))) {
			BigDecimal bankAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			invoiceRequestInfo.setToplamBorcTutari(formatBankAmount2CorporateAmount(bankAmount));
		}

		if (null != iMap.getString(MapKeys.PARAMETER7) && !"".equals(iMap.getString(MapKeys.PARAMETER7))) {
			invoiceRequestInfo.setHesapId(iMap.getLong(MapKeys.PARAMETER7));
		}

		if (null != iMap.getString(MapKeys.INVOICE_NO) && !"".equals(iMap.getString(MapKeys.INVOICE_NO))) {
			invoiceRequestInfo.setFaturaNo(Long.parseLong(iMap.getString(MapKeys.INVOICE_NO)));
		}

		if (null != iMap.getString(MapKeys.INSTALLMENT_NO) && !"".equals(iMap.getString(MapKeys.INSTALLMENT_NO))) {
			invoiceRequestInfo.setFaturaTaksitNo(Integer.parseInt(iMap.getString(MapKeys.INSTALLMENT_NO)));
		}

		if (null != iMap.getString(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1))) {
			StringBuilder serviceNoBuilder = new StringBuilder();
			serviceNoBuilder.append(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			if (null != iMap.getString(MapKeys.SUBSCRIBER_NO2) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO2))) {
				serviceNoBuilder.append(iMap.getString(MapKeys.SUBSCRIBER_NO2));
			}

			invoiceRequestInfo.setHesapNo(serviceNoBuilder.toString());
		}

		if (null != iMap.getString(MapKeys.TERM_YEAR) && null != iMap.getString(MapKeys.TERM_MONTH)) {
			StringBuilder billCycleBuilder = new StringBuilder();
			billCycleBuilder.append(iMap.getString(MapKeys.TERM_YEAR));
			billCycleBuilder.append(iMap.getString(MapKeys.TERM_MONTH));
			invoiceRequestInfo.setOdemeDonemi(Integer.parseInt(billCycleBuilder.toString()));
		}

		if (null != paymentRefInfo) {
			invoiceRequestInfo.setReferansBilgi(paymentRefInfo);
		}

		logger.info("[TTSystemService [prepareInvoiceInfo]] Values are " + makeLogs(invoiceRequestInfo));
		return invoiceRequestInfo;
	}

	private static FaturaOdemeIptaliRequest prepareCancelInvoicePaymentRequest(int invoicePaymentDate, int companyCode, FaturaBilgi invoiceInfo, int channel, GMMap iMap) throws NumberFormatException, Exception {
		FaturaOdemeIptaliRequest cancelInvoicePaymentRequest = new FaturaOdemeIptaliRequest();

		cancelInvoicePaymentRequest.setMesajTipi(TTSMessageType.DO_NOTIFICATION_REQUEST_CODE);
		cancelInvoicePaymentRequest.setIslemKabulTarihi(invoicePaymentDate);
		cancelInvoicePaymentRequest.setIslemKodu(TTSProcessCode.CANCEL_INVOICE_COLLECTION_CODE);
		cancelInvoicePaymentRequest.setFaturaBilgiDizi(new FaturaBilgi[] { invoiceInfo });
		cancelInvoicePaymentRequest.setIslemTarihi(invoicePaymentDate);
		cancelInvoicePaymentRequest.setSirketKodu(companyCode);
		cancelInvoicePaymentRequest.setIslemKaynagi(channel);

		prepareCommonData(cancelInvoicePaymentRequest, iMap);

		logger.info("[TTSystemService [prepareCancelInvoicePaymentRequest]] Values are " + makeLogs(cancelInvoicePaymentRequest));
		return cancelInvoicePaymentRequest;
	}

	private static ReferansBilgi prepareReferenceInfo(String invoicePaymentDate, long paymentStanNo) {
		ReferansBilgi refInfo = new ReferansBilgi();

		refInfo.setIslemTarihi(Integer.parseInt(invoicePaymentDate));
		refInfo.setStan(paymentStanNo);

		logger.info("[TTSystemService [prepareReferenceInfo]] Values are " + makeLogs(refInfo));
		return refInfo;
	}

	/**
	 * @param companyCode
	 * @param reconcilationDate
	 * @return
	 * @throws Exception
	 * @throws NumberFormatException
	 */
	private static MutabakatRequest prepareReconcilationRequest(int companyCode, Date reconcilationDate, int reconcilationType, int processCode, MutabakatBilgi[] reconciliationInfos, int totalProcessCount, GMMap iMap) throws NumberFormatException, Exception {

		MutabakatRequest reconcilationRequest = new MutabakatRequest();

		reconcilationRequest.setSirketKodu(companyCode);
		reconcilationRequest.setMesajTipi(TTSMessageType.RECONCILIATION_SUMMARY_REQUEST_CODE);
		reconcilationRequest.setMutabakatTipi(reconcilationType);
		reconcilationRequest.setIslemKodu(processCode);

		reconcilationRequest.setMutabakatBilgiDizi(reconciliationInfos);

		reconcilationRequest.setMutabakatIslemSayisi(totalProcessCount);
		int reconDate = convertDate2TTDate(reconcilationDate);

		reconcilationRequest.setIslemTarihi(getTTProcessDate());
		reconcilationRequest.setMutabakatTarihi(reconDate);

		prepareCommonData(reconcilationRequest, iMap);

		logger.info("[TTSystemService [prepareReconcilationRequest]] Values are " + makeLogs(reconcilationRequest));
		return reconcilationRequest;
	}

	private static MutabakatBilgi[] prepareReconcilationInfo(int collectionCount, Long collectionTotal, int cancelCount, Long cancelTotal) {

		MutabakatBilgi[] reconcilitionInfos = new MutabakatBilgi[] { new MutabakatBilgi(TTSProcessCode.DO_INVIOCE_COLLECTION_CODE, TTSOtherCodes.RECONLITION_STATUS, collectionCount, collectionTotal), new MutabakatBilgi(TTSProcessCode.CANCEL_INVOICE_COLLECTION_CODE, TTSOtherCodes.RECONLITION_STATUS, cancelCount, cancelTotal) };

		return reconcilitionInfos;
	}

	private static MutabakatBilgi[] prepareReconcilationInfo(int collectionCount, int cancelCount) {

		MutabakatBilgi[] reconcilitionInfos = new MutabakatBilgi[] { new MutabakatBilgi(TTSProcessCode.NEW_STANDING_ORDER_REQUEST_CODE, TTSOtherCodes.RECONLITION_STATUS, collectionCount, 0), new MutabakatBilgi(TTSProcessCode.CANCEL_STANDING_ORDER_REQUEST_CODE, TTSOtherCodes.RECONLITION_STATUS, cancelCount, 0) };

		return reconcilitionInfos;
	}

	/**
	 * Subscriber no should be TT Account Id
	 * 
	 * @param subscriberNo
	 * @return
	 * @throws Exception
	 * @throws NumberFormatException
	 */
	private static TalimatEkleRequest prepareNewStandingOrderRequest(String subscriberNo, int companyCode, Date processDate, GMMap iMap) throws NumberFormatException, Exception {
		TalimatEkleRequest newStandingOrderRequest = new TalimatEkleRequest();

		newStandingOrderRequest.setMesajTipi(TTSMessageType.DO_NOTIFICATION_REQUEST_CODE);
		newStandingOrderRequest.setIslemKodu(TTSProcessCode.NEW_STANDING_ORDER_REQUEST_CODE);
		newStandingOrderRequest.setHesapId(Long.parseLong(subscriberNo));
		newStandingOrderRequest.setSirketKodu(companyCode);
		newStandingOrderRequest.setIslemTarihi(getTTProcessDate());
		newStandingOrderRequest.setIslemKabulTarihi(convertDate2TTDate(processDate));

		prepareCommonData(newStandingOrderRequest, iMap);

		logger.info("[TTSystemService [prepareNewStandingOrderRequest]] Values are " + makeLogs(newStandingOrderRequest));
		return newStandingOrderRequest;
	}

	private static TalimatCikarRequest prepareCancelStandingOrderRequest(String subscriberNo, int companyCode, Date processDate, GMMap iMap) throws Exception {
		TalimatCikarRequest cancelStandingOrderRequest = new TalimatCikarRequest();

		cancelStandingOrderRequest.setMesajTipi(TTSMessageType.DO_NOTIFICATION_REQUEST_CODE);
		cancelStandingOrderRequest.setIslemKodu(TTSProcessCode.CANCEL_STANDING_ORDER_REQUEST_CODE);
		cancelStandingOrderRequest.setHesapId(Long.parseLong(subscriberNo));
		cancelStandingOrderRequest.setSirketKodu(companyCode);
		cancelStandingOrderRequest.setIslemTarihi(getTTProcessDate());
		cancelStandingOrderRequest.setIslemKabulTarihi(convertDate2TTDate(processDate));

		prepareCommonData(cancelStandingOrderRequest, iMap);

		logger.info("[TTSystemService [prepareCancelStandingOrderRequest]] Values are " + makeLogs(cancelStandingOrderRequest));
		return cancelStandingOrderRequest;
	}

	private static TalimatBilgiSorgulamaRequest prepareStandingOrderRequest(String subscriberNo, int companyCode, GMMap iMap, int accessType) throws Exception, Exception {
		TalimatBilgiSorgulamaRequest queryStandingOrderRequest = new TalimatBilgiSorgulamaRequest();

		queryStandingOrderRequest.setMesajTipi(TTSMessageType.DEBT_INQUERY_REQUEST_CODE);
		queryStandingOrderRequest.setIslemKodu(TTSProcessCode.QUERY_STANDING_ORDER_REQUEST_CODE);
		queryStandingOrderRequest.setErisimBilgi(new tr.com.innova.tts.business.webservice.server.talimat.ErisimBilgi(accessType, subscriberNo));
		queryStandingOrderRequest.setSirketKodu(companyCode);
		queryStandingOrderRequest.setIslemTarihi(getTTProcessDate());
		queryStandingOrderRequest.setAktivasyonTarihiSorgula(false);
		queryStandingOrderRequest.setTalimatTipi(TTSOtherCodes.STO_TYPE);

		prepareCommonData(queryStandingOrderRequest, iMap);

		logger.info("[TTSystemService [prepareStandingOrderRequest]] Values are " + makeLogs(queryStandingOrderRequest));
		return queryStandingOrderRequest;
	}

	private static int generateStan() throws NumberFormatException, Exception {
		return Integer.parseInt(CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
	}

	public static GMMap getResponseCodeMapping(String responseCode, String serviceOid, String corporateCode) {
		GMMap output = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(ServiceResponseCodeMapping.class);
			Criterion status = Restrictions.eq("status", true);
			Criterion returnCode = Restrictions.eq("returnCode", responseCode);
			Criterion corporateCODE = Restrictions.eq("corporateCode", corporateCode);
			criteria.add(status).add(returnCode).add(corporateCODE);

			@SuppressWarnings("unchecked")
			List<ServiceResponseCodeMapping> responseCodeMappingList = criteria.list();

			if (responseCodeMappingList.size() > 0) {
				for (ServiceResponseCodeMapping responseCodeMapping : responseCodeMappingList) {
					output.put("RETURN_CODE", responseCodeMapping.getReturnCode());
					output.put("RETURN_CODE_DESC", responseCodeMapping.getReturnCodeDesc());
					output.put(MapKeys.ERROR_CODE, responseCodeMapping.getErrorCode());
					output.put(MapKeys.ERROR_DESC, responseCodeMapping.getExplanation());

					logger.info("[TTSystemService[getResponseCodeMapping]] Return Code : " + responseCodeMapping.getReturnCode() + " Return Code Desc : " + responseCodeMapping.getReturnCodeDesc());

				}
			} else {
				output.put("RETURN_CODE", responseCode);
				output.put("RETURN_CODE_DESC", GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
				output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_NOT_FOUND);
				output.put(MapKeys.ERROR_DESC, GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			}
		} catch (Exception e) {
			output.put("RETURN_CODE", responseCode);
			output.put("RETURN_CODE_DESC", GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			output.put("ERROR_CODE", GeneralConstants.ERROR_CODE_NOT_FOUND);
			output.put("EXPLANATION", GeneralConstants.ERROR_CODE_NOT_FOUND_EXPLAIN);
			e.printStackTrace();
		}
		return output;
	}

	private static void setErrorCodeToOutput(String errorCode, GMMap input, GMMap output) {
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);

		GMMap responseCodeMap = getResponseCodeMapping(errorCode, input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

		logger.info("[TTSystemService[setErrorCodeToOutput]] Return Code Map : " + responseCodeMap);

		output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
		output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
	}

	private static int getTTProcessDate() throws ParseException {
		return convertDate2TTDate(new Date());
	}

	private static Date getInputDateOrDefault(GMMap input, String key, String format) throws ParseException {
		Date date = new Date();

		if (!StringUtil.isEmpty(input.getString(key))) {
			date = CommonHelper.getDateTime(input.getString(key), format);
		}

		return date;
	}

	private static int getCorporateChannelMapping(String corporateCode, String sourceCode, String channelCode, short collectionType) {
		Session hibernateSession = DAOSession.getSession("BNSPRDal");
		CorporateChannelPrm channelParameter = (CorporateChannelPrm) hibernateSession.createCriteria(CorporateChannelPrm.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("sourceCode", sourceCode)).add(Restrictions.eq("channelCode", channelCode)).add(Restrictions.eq("collectionType", collectionType)).uniqueResult();
		if (null != channelParameter) {
			return Integer.parseInt(channelParameter.getCorporateConstant());
		} else {
			return TTSOtherCodes.DEFAULT_CORPORATE_CHANNEL_CODE;
		}
	}

	private static String makeLogs(Object requestObj) {

		try {
			StringBuilder logBuffer = new StringBuilder();
			if (null != requestObj) {

				Field[] declaredFields = requestObj.getClass().getDeclaredFields();

				for (Field field : declaredFields) {
					field.setAccessible(true);
					logBuffer.append(" [ ");
					logBuffer.append(field.getName());
					logBuffer.append(" : ");
					Object val = field.get(requestObj);
					if (null != val) {
						logBuffer.append(val.toString());
					}
					logBuffer.append(" ],");
				}

				for (Field parentField : requestObj.getClass().getSuperclass().getDeclaredFields()) {
					parentField.setAccessible(true);
					logBuffer.append(" [ ");
					logBuffer.append(parentField.getName());
					logBuffer.append(" : ");
					Object val = parentField.get(requestObj);
					if (null != val) {
						logBuffer.append(val.toString());
					}
					logBuffer.append(" ],");
				}

				return logBuffer.toString();
			}
		} catch (Exception ex) {
			logger.error("[TTSystemService(makeLogs)] An exception is occurred and logging is interrupted");
		}

		return "An exception is occurred and logging is interrupted";

	}

	private static BigDecimal formatCorporateAmount2BankFormat(long corporateAmount) {
		BigDecimal bankAmount = new BigDecimal(corporateAmount);
		bankAmount = bankAmount.divide(new BigDecimal(TTSOtherCodes.DECIMAL_FORMAT));
		bankAmount = bankAmount.setScale(TTSOtherCodes.SCALE_LENGTH);

		return bankAmount;
	}

	private static long formatBankAmount2CorporateAmount(BigDecimal bankAmount) {
		bankAmount = bankAmount.multiply(new BigDecimal(TTSOtherCodes.DECIMAL_FORMAT));
		bankAmount = bankAmount.setScale(TTSOtherCodes.CORP_SCALE_LENGTH);

		return bankAmount.longValue();
	}
	
	@GraymoundService("CDM_GET_ADSL_NUMBER_TTNET_WRAPPER")
	@SuppressWarnings("unchecked")
	public static GMMap getAdslNumberFromPhoneNumberWrapper(GMMap iMap)
	{
		try {
			GMMap onlineCallRequest = new GMMap();
			onlineCallRequest.put("CORPORATE_CODE", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "TTNET_CORPORATE_CODE"));
			onlineCallRequest.put("GM_SERVICE_NAME", "CDM_GET_ADSL_NUMBER");
			onlineCallRequest.put("IS_MANDATORY_SERVICE", true);
			onlineCallRequest.put("RECON_CALL", false);
			
			onlineCallRequest.putAll(iMap);
			
			return CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", onlineCallRequest);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	

	@GraymoundService("CDM_GET_ADSL_NUMBER_TTNET")
	@SuppressWarnings("unchecked")
	public static GMMap getADSLNumberFromPhoneNumber(GMMap iMap)
	{
		GMMap oMap = new GMMap();
		try {
			String adslNumber = TtAdslClient.getAdslNumberFromPhone(iMap.getString("PSTN_NO"), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER),iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
			oMap.put("ADSL_NUMBER", adslNumber);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}
	
	
}
