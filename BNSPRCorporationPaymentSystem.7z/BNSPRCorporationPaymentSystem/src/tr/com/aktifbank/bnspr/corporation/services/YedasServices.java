package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.yedas.ServiceMessage;
import tr.com.aktifbank.integration.yedas.YedasClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.alfayazilim.xi.BANKINT.AutoPaymentDetailedReconciliationQueryMessage;
import com.alfayazilim.xi.BANKINT.AutoPaymentDetailedReconciliationResponseMessage;
import com.alfayazilim.xi.BANKINT.AutoPaymentDetailedReconciliationResponseMessageItem;
import com.alfayazilim.xi.BANKINT.AutoPaymentGlobalReconciliationQueryMessage;
import com.alfayazilim.xi.BANKINT.AutoPaymentGlobalReconciliationResponseMessage;
import com.alfayazilim.xi.BANKINT.AutoPaymentGlobalReconciliationResponseMessageItem;
import com.alfayazilim.xi.BANKINT.AutoPaymentListQueryMessage;
import com.alfayazilim.xi.BANKINT.AutoPaymentListResponseMessage;
import com.alfayazilim.xi.BANKINT.AutoPaymentListResponseMessageItem;
import com.alfayazilim.xi.BANKINT.CollectionOrderCancellationQueryMessage;
import com.alfayazilim.xi.BANKINT.CollectionOrderCancellationResponseMessage;
import com.alfayazilim.xi.BANKINT.CollectionOrderCreateQueryMessage;
import com.alfayazilim.xi.BANKINT.CollectionOrderCreateResponseMessage;
import com.alfayazilim.xi.BANKINT.GetContractAccountNumberFromLegacyQueryMessage;
import com.alfayazilim.xi.BANKINT.GetContractAccountNumberFromLegacyResponseMessage;
import com.alfayazilim.xi.BANKINT.GlobalReconciliationQueryMessage;
import com.alfayazilim.xi.BANKINT.GlobalReconciliationResponseMessage;
import com.alfayazilim.xi.BANKINT.GlobalReconciliationResponseMessageItem;
import com.alfayazilim.xi.BANKINT.OpenItemListQueryMessage;
import com.alfayazilim.xi.BANKINT.OpenItemListResponseMessage;
import com.alfayazilim.xi.BANKINT.OpenItemListResponseMessageItem;
import com.alfayazilim.xi.BANKINT.PaymentCreateNotificationQueryMessage;
import com.alfayazilim.xi.BANKINT.PaymentCreateNotificationQueryMessagePaymentChannel;
import com.alfayazilim.xi.BANKINT.PaymentCreateNotificationResponseMessage;
import com.alfayazilim.xi.BANKINT.PaymentReverseNotificationQueryMessage;
import com.alfayazilim.xi.BANKINT.PaymentReverseNotificationResponseMessage;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * 
 * @author selman lafci
 * 
 */
public class YedasServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(YedasServices.class);
	private static String paymentStatusCodeCorp = "O";
	private static String paymentStatusCodeCorpStandingOrder = "Y";
	private static final String WS_RESPONSE_CODE = "WS_RESPONSE_CODE";
	private static final String reconcile_close_after_ok = "E-0016";
	private static final String branch_code = "555";
	private static final String YIM_CHANNEL_NKOLAY = "M";
	private static final String YIM_CHANNEL_EPOS = "K";
	private static final String PAYMENT_SOURCE_EPOS = DatabaseConstants.SourceCodes.Cash;
	
	@GraymoundService("ICS_YEDAS_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_YEDAS_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;

		try {
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String[] subscriptionNumberOld = new String[2];
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			GetContractAccountNumberFromLegacyResponseMessage response1 = null;
			GMMap responceCodeMap = null;
			String errorCode = null;
				if (!StringUtils.isBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))) {
					String[] subscriptionNumberOldTrash = iMap.getString(MapKeys.SUBSCRIBER_NO2).split("-");
					subscriptionNumberOld[0] = subscriptionNumberOldTrash.length == 2 ? subscriptionNumberOldTrash[0] : "";
					subscriptionNumberOld[1] = subscriptionNumberOldTrash.length == 2 ? subscriptionNumberOldTrash[1] : "";
					
					GetContractAccountNumberFromLegacyQueryMessage input = new GetContractAccountNumberFromLegacyQueryMessage(bankCode, subscriptionNumberOld[0], subscriptionNumberOld[1]);
					ServiceMessage serviceMessage=new ServiceMessage();
					response1 = YedasClient.borcSorgulamaEskiTum(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3),serviceMessage);
					CommonHelper.insertWsCallLog(iMap, serviceMessage.getParameter1(), serviceMessage.getParameter2(), serviceMessage.getParameter3());
					iMap.put("REQUEST_XML", serviceMessage.getRequest());
					outMap.put("RESPONSE_XML", serviceMessage.getResponse());
					aboneNo = response1.getContractAccountNumber();
					responceCodeMap = getResponseCodeMapping(response1.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				}

			
			
			if (StringUtils.isNotBlank(aboneNo) || errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				OpenItemListQueryMessage input = new OpenItemListQueryMessage(bankCode, aboneNo);
				ServiceMessage serviceMessageAll=new ServiceMessage();
				OpenItemListResponseMessage response = YedasClient.borcSorgulamaTum(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessageAll);
				iMap.put("REQUEST_XML_ALL", serviceMessageAll.getRequest());
				outMap.put("RESPONSE_XML_ALL", serviceMessageAll.getResponse());
				CommonHelper.insertWsCallLog(iMap, serviceMessageAll.getParameter1(), serviceMessageAll.getParameter2(), serviceMessageAll.getParameter3());
				outMap.put(WS_RESPONSE_CODE, response.getMessage());
				responceCodeMap = getResponseCodeMapping(response.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE) && response.getItem() != null) {
					for (OpenItemListResponseMessageItem borc : response.getItem()) {
						if (!isCollectedInvoice(borc.getInvoiceNumber(), borc.getContractAccountNumber(), "", "", "", corporateCode,borc.getOrderOfInstallment())) {
							String termYear = CommonHelper.getDateString(borc.getInvoiceDate(), "yyyy");
							String termMonth = CommonHelper.getDateString(borc.getInvoiceDate(), "MM");
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getContractAccountNumber());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getInvoiceNumber());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, borc.getInvoiceAmount());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getName() + " " + borc.getSurname());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getInvoiceDueDate());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, borc.getInvoiceAmount());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, borc.getOrderOfInstallment());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getCurrency());
							outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.DESCRIPTION, borc.getInvoiceType());
							outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
							outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
							counter++;
						}
					}
				}
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_YEDAS_INVOICE_DEBT_INQUIRY.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_YEDAS_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_YEDAS_DO_INVOICE_COLLECTION");
		ServiceMessage serviceMessage=new ServiceMessage();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String branchCode = StringUtils.isNotBlank(iMap.getString(MapKeys.BRANCH_CODE)) ? iMap.getString(MapKeys.BRANCH_CODE) : branch_code;
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String tahakkukNo = iMap.getString(MapKeys.INVOICE_NO);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			BigDecimal amount = iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT) != null ? iMap.getBigDecimal(MapKeys.INVOICE_AMOUNT) : iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String currency = iMap.getString(MapKeys.PARAMETER1);
			String ref = iMap.getString(MapKeys.TRX_NO);
			Date tahsilatTarihi = (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) ? CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss") : new Date();
			String channelCode = CommonHelper.getChannelId();
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.CHANNEL_CODE))) {
				channelCode = iMap.getString(MapKeys.CHANNEL_CODE);
			}
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			if(channelCode.equals(GeneralConstants.YIM_CHANNEL_CODE) ){
				if (YIM_CHANNEL_EPOS.equals(iMap.getString(MapKeys.YIM_CHANNEL))) {
					channelCode = GeneralConstants.EPOS_CHANNEL_CODE;
					
					Session session = DAOSession.getSession("BNSPRDal");
					invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
					invoicePayment.setPaymentSource(PAYMENT_SOURCE_EPOS);
					session.saveOrUpdate(invoicePayment);
				}
				branchCode=iMap.getString("AGENT_CODE");
				
			}
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			PaymentCreateNotificationQueryMessagePaymentChannel chnl = PaymentCreateNotificationQueryMessagePaymentChannel.V;
			if ("V".equals(paymentChannel)) {
				chnl = PaymentCreateNotificationQueryMessagePaymentChannel.V;
			} else if ("A".equals(paymentChannel)) {
				chnl = PaymentCreateNotificationQueryMessagePaymentChannel.A;
			} else if ("T".equals(paymentChannel)) {
				chnl = PaymentCreateNotificationQueryMessagePaymentChannel.T;
			} else if ("I".equals(paymentChannel)) {
				chnl = PaymentCreateNotificationQueryMessagePaymentChannel.I;
			} else if ("O".equals(paymentChannel)) {
				chnl = PaymentCreateNotificationQueryMessagePaymentChannel.O;
			} else if ("N".equals(paymentChannel)) {
				chnl =PaymentCreateNotificationQueryMessagePaymentChannel.N;
			}else if ("E".equals(paymentChannel)) {
				chnl =PaymentCreateNotificationQueryMessagePaymentChannel.E;
			}
			PaymentCreateNotificationQueryMessage input = new PaymentCreateNotificationQueryMessage(bankCode, branchCode, aboneNo, tahakkukNo, amount, currency, tahsilatTarihi, ref, chnl);
			
			PaymentCreateNotificationResponseMessage response = YedasClient.tahsilat(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(WS_RESPONSE_CODE, response.getMessage());
			GMMap responceCodeMap = getResponseCodeMapping(response.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_YEDAS_DO_INVOICE_COLLECTION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_YEDAS_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_YEDAS_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String ref = iMap.getString(MapKeys.TRX_NO);

			PaymentReverseNotificationQueryMessage input = new PaymentReverseNotificationQueryMessage(bankCode, ref);
			ServiceMessage serviceMessage=new ServiceMessage();
			PaymentReverseNotificationResponseMessage response = YedasClient.tahsilatIptal(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(WS_RESPONSE_CODE, response.getMessage());
			GMMap responceCodeMap = getResponseCodeMapping(response.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_YEDAS_SEND_COLLECTION_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_YEDAS_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_YEDAS_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Date talimatTarihi = (!StringUtil.isEmpty(iMap.getString("START_DATE"))) ? CommonHelper.getDateTime(iMap.getString("START_DATE"), "yyyyMMddhhmmss") : new Date();
			String pBranchCode = "";
			CollectionOrderCreateQueryMessage input = new CollectionOrderCreateQueryMessage(bankCode, pBranchCode, aboneNo, talimatTarihi);
			ServiceMessage serviceMessage=new ServiceMessage();
			CollectionOrderCreateResponseMessage response = YedasClient.talimat(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(WS_RESPONSE_CODE, response.getMessage());
			GMMap responceCodeMap = getResponseCodeMapping(response.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_YEDAS_SEND_STANDING_ORDER_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_YEDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_YEDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String aboneNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			Date iptalTarihi = (!StringUtil.isEmpty(iMap.getString("END_DATE"))) ? CommonHelper.getDateTime(iMap.getString("END_DATE"), "yyyyMMddhhmmss") : new Date();
			CollectionOrderCancellationQueryMessage input = new CollectionOrderCancellationQueryMessage(bankCode, aboneNo, iptalTarihi);
			ServiceMessage serviceMessage=new ServiceMessage();
			CollectionOrderCancellationResponseMessage response = YedasClient.talimatIptal(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(WS_RESPONSE_CODE, response.getMessage());
			GMMap responceCodeMap = getResponseCodeMapping(response.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_YEDAS_SEND_STANDING_ORDER_CANCEL_MESSAGE.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_YEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_YEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
		String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		GMMap outMap = new GMMap();
		GMMap reconCorpAmountMap = new GMMap();
		try {

			Date reconDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd") : new Date();
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			String pBranchCode = "";
			AutoPaymentDetailedReconciliationQueryMessage input = new AutoPaymentDetailedReconciliationQueryMessage(bankCode, pBranchCode, reconDate);
			ServiceMessage serviceMessage=new ServiceMessage();
			AutoPaymentDetailedReconciliationResponseMessage response = YedasClient.talimatMutabakatDetay(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);

			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			
			GMMap responceCodeMap = getResponseCodeMapping(response.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			int corpStandingOrderCount = 0;
			int corpStandingOrderCancelCount = 0;
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (int i = 0; i < response.getItem().length; i++) {
					AutoPaymentDetailedReconciliationResponseMessageItem talimat = response.getItem(i);
					if (talimat.getOrderStatusCode() != null && talimat.getOrderStatusCode().toString().equals(paymentStatusCodeCorpStandingOrder)) {
						outMap.put(MapKeys.SUBSCRIBER_NO1, talimat.getContractAccountNumber());
						reconCorpAmountMap.put("CORPORATE", corpStandingOrderCount, MapKeys.SUBSCRIBER_NO1, talimat.getContractAccountNumber());
						corpStandingOrderCount++;
					}
				}
			}

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));
			GMMap listMap = new GMMap();
			listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);

			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST");

			boolean found = false;
			if (bankStandingOrderList.size() > corpStandingOrderCount) {
				short collectionType = 0;
				for (int j = 0; j < bankStandingOrderList.size(); j++) {
					for (int i = 0; i < corpStandingOrderCount; i++) {
						if (bankStandingOrderList.get(j).getSubscriberNo1().equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1))) {
							collectionType = bankStandingOrderList.get(j).getCollectionType();
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat istegi gonder
						@SuppressWarnings("unused")
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						@SuppressWarnings("unused")
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderList.get(j).getSubscriberNo1());
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (GMRuntimeException e) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);// Talimat
																																												// Mesaji
																																												// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderList.get(j).getSubscriberNo1());
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else if (bankStandingOrderList.size() == corpStandingOrderCount) {
				/*
				 * DB deki kayitlar hicbir zaman az olamaz, hepsini cekiyoruz.
				 * Toplam olusturulan sayilar esit olur ancak iptal statusunde
				 * olanlarda farkliliklar olabilir. DB tarafinda iptal statusu
				 * fazla olan olabilir, eksik olamaz. Karsiya iptal gitmedi isi
				 * bizde iptal fazla olur. iptal edilen abone tekrar talimat
				 * verdiyse zaten yeni kayit ekliyoruz. Bu yeni verilen talimat
				 * ulasmadi ise de yukaridaki dongude kontrol ediliyor.
				 */
				short collectionType = 0;

				@SuppressWarnings("unchecked")
				List<icsStandingOrders> bankStandingOrderCancelList = (List<icsStandingOrders>) listMap.get("LIST_CANCELED");

				for (int j = 0; j < bankStandingOrderCancelList.size(); j++) {
					for (int i = 0; i < corpStandingOrderCancelCount; i++) {
						if (bankStandingOrderCancelList.get(j).getSubscriberNo1().equals(reconCorpAmountMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1))) {
							collectionType = bankStandingOrderCancelList.get(j).getCollectionType();
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin talimat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						@SuppressWarnings("unused")
						GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						@SuppressWarnings("unused")
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderCancelList.get(j).getSubscriberNo1());
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (GMRuntimeException e) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, e.getCode());
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, e.getMessage());
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);// Talimat
																																														// Iptal
																																														// Mesaji
																																														// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, bankStandingOrderCancelList.get(j).getSubscriberNo1());
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_YEDAS_GET_STANDING_ORDER_RECONCILIATION_DETAIL.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_YEDAS_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_YEDAS_STANDING_ORDER_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Date reconDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd") : new Date();

			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", iMap.getString(MapKeys.PROCESS_DATE));
			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);

			int definitionOrderNumber = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT) + rcOutput.getInt("CANCEL_COUNT");
			int cancellationOrderNumber = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.CANCEL_COUNT);
			int corpDefinitionOrderNumber = 0;
			int corpCancellationOrderNumber = 0;

			AutoPaymentGlobalReconciliationQueryMessage input = new AutoPaymentGlobalReconciliationQueryMessage(bankCode, reconDate, String.valueOf(definitionOrderNumber).toString(), String.valueOf(cancellationOrderNumber).toString());
			ServiceMessage serviceMessage=new ServiceMessage();
			AutoPaymentGlobalReconciliationResponseMessage response = YedasClient.talimatMutabakatSayi(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(WS_RESPONSE_CODE, response.getMessage());
			GMMap responceCodeMap = getResponseCodeMapping(response.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			if (response.getItem() != null && response.getItem().length > 0) {
				for (AutoPaymentGlobalReconciliationResponseMessageItem item : response.getItem()) {
					corpDefinitionOrderNumber += (response != null && response.getItem() != null && item != null) ? Integer.valueOf(item.getDefinitionOrderNumber().toString().trim()).intValue() : 0;
					corpCancellationOrderNumber += (response != null && response.getItem() != null && item != null) ? Integer.valueOf(item.getCancellationOrderNumber().toString().trim()).intValue() : 0;
				}
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			}
			outMap.put(MapKeys.RECON_CORPORATE_COUNT, corpDefinitionOrderNumber);
			outMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corpCancellationOrderNumber);
			outMap.put(MapKeys.RECON_BANK_COUNT, definitionOrderNumber);
			outMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, cancellationOrderNumber);

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing STO_YEDAS_STANDING_ORDER_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_YEDAS_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		
		outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		return outMap;
	}

	@GraymoundService("ICS_YEDAS_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_YEDAS_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Date reconDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd") : new Date();

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			GlobalReconciliationQueryMessage input = new GlobalReconciliationQueryMessage(bankCode, reconDate, new BigInteger(reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT).toString()), new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL).toString()), new BigInteger(reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT).toString()));
			ServiceMessage serviceMessage=new ServiceMessage();
			GlobalReconciliationResponseMessage response = YedasClient.tahsilatMutabakatSayi(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(WS_RESPONSE_CODE, response.getMessage());
			String errorCodeResult = response.getMessage().split(":")[0].trim();
			// 1319 Bu Tarihe Ait Cevaplanmam�� Mutabakat Talebi Bulunmaktad�r.
			// mutabakat kapama daha �nce �al��t�r�lm��.
			String errorCode = GeneralConstants.ERROR_CODE_APPROVE;
			if (reconcile_close_after_ok.equals(errorCodeResult)) {
				outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
				outMap.put(MapKeys.ERROR_DESC, "Onay");
			} else {
				GMMap responceCodeMap = getResponseCodeMapping(errorCodeResult, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}
			// Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

				outMap.putAll(onlineCorporateServiceCallOutputMap);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			}

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_YEDAS_COLLECTION_RECONCILIATION_CLOSED.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_YEDAS_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_YEDAS_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Date reconDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd") : new Date();

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			GlobalReconciliationQueryMessage input = new GlobalReconciliationQueryMessage(bankCode, reconDate, new BigInteger(reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT).toString()), new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL).toString()), new BigInteger(reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT).toString()));
			ServiceMessage serviceMessage=new ServiceMessage();
			GlobalReconciliationResponseMessage response = YedasClient.tahsilatMutabakatSayi(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			
			String responceCode = response.getMessage().split(":")[0].trim();
			String responceMsg = response.getMessage().split(":")[1].trim();
			if(responceCode.equals("E-0015") || responceCode.equals("E-0014")){
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, responceMsg);
			}
			else{
				outMap.put(WS_RESPONSE_CODE, responceCode + " " + responceMsg);
				responceCode = "I-0000";
				responceMsg = "Onay";
				GMMap responceCodeMap = getResponseCodeMapping(responceCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				BigDecimal totalCollectionAmount = new BigDecimal("0.0");
				BigDecimal totalCollectionNumber = new BigDecimal("0.0");
				BigDecimal totalCancellationNumber = new BigDecimal("0.0");
				BigDecimal totalCancellationAmount = new BigDecimal("0.0");
				if (response.getItem() != null && response.getItem().length > 0) {
					for (GlobalReconciliationResponseMessageItem item : response.getItem()) {
						totalCollectionAmount = totalCollectionAmount.add(new BigDecimal(StringUtils.isNotBlank(item.getTotalCollectionAmount().toString()) ? item.getTotalCollectionAmount().toString() : "0"));
						totalCollectionNumber = totalCollectionNumber.add(new BigDecimal(StringUtils.isNotBlank(item.getTotalCollectionNumber().toString()) ? item.getTotalCollectionNumber().toString() : "0"));
						totalCancellationNumber = totalCancellationNumber.add(new BigDecimal(StringUtils.isNotBlank(item.getTotalCancellationNumber().toString()) ? item.getTotalCancellationNumber().toString() : "0"));
					}
				} else if (response.getItem() == null || (response.getItem() != null && response.getItem().length == 0)) {
					totalCollectionAmount = totalCollectionAmount.add(new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL).toString()));
					totalCollectionNumber = totalCollectionNumber.add(new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT).toString()));
					totalCancellationNumber = totalCancellationNumber.add(new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT).toString()));
					totalCancellationAmount = totalCancellationAmount.add(new BigDecimal(reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL).toString()));
				}
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, totalCollectionAmount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, totalCollectionNumber);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, totalCancellationAmount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, totalCancellationNumber);

				if (totalCollectionAmount.compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && totalCollectionNumber.compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0 && totalCancellationNumber.compareTo(outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				} else {
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}
			
			
			

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_YEDAS_COLLECTION_RECONCILIATION.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_YEDAS_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_YEDAS_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String pBankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);

			Date dueDate = (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE))) ? CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMddhhmmss") : new Date();

			AutoPaymentListQueryMessage input = new AutoPaymentListQueryMessage(pBankCode, dueDate);
			ServiceMessage serviceMessage=new ServiceMessage();
			AutoPaymentListResponseMessage response = YedasClient.talimatliBorcSorgulama(input, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT),serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RESPONSE_XML", serviceMessage.getResponse());
			outMap.put(WS_RESPONSE_CODE, response.getMessage());
			GMMap responceCodeMap = getResponseCodeMapping(response.getMessage().split(":")[0].trim(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));

			int i = 0;
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put(MapKeys.TABLE_SIZE, response != null && response.getItem() != null ? response.getItem().length : 0);
				for (AutoPaymentListResponseMessageItem borc : response.getItem()) {
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, borc.getContractAccountNumber());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, borc.getInvoiceNumber());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, borc.getInvoiceAmount());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER1, borc.getCurrency());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE, "0");// collection
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, borc.getInvoiceDueDate());
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR, GeneralConstants.DEFAULT_STRING);
					outMap.put(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
					i++;
				}
			} else {
				outMap.put(MapKeys.TABLE_SIZE, 0);
			}

			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_YEDAS_DEBT_INQUERY_FOR_STANDING_ORDER.");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
}
