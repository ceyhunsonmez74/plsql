package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.DigiturkCollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.digiturk.client.ClientInformation;
import tr.com.aktifbank.integration.digiturk.client.DigiturkClient;
import tr.com.aktifbank.integration.digiturk.client.DigiturkServiceMessage;
import tr.com.aktifbank.integration.digiturk.messages.PGWDebtResponse.BillInfo;
import tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderDebtQueryResponse.DeptInfo;
import tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderDebtQueryResponse.PGWResponseMessage.Data.DeptList;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class DigiturkServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
		
	private static final Log logger = LogFactory.getLog(DigiturkServices.class);
	
	private static final class DigiturkConstants {
		public static final int CityCode = 34;
		public static final String BranchCode = "555";
		public static final String CounterCode = "1";
		public static final String UserName = "User1";
		public static final short ProcessSource = 1;
		public static final short FileProcessSource = 3;
		public static final short ExistFileInquiryType = 1;
		public static final short DebtFileType = 1;
	}
	
	private static final class StanNoSequenceKeys {
		public static final String DIGITURK_QUERY_DEBT_STAN = "DIGITURK_QUERY_DEBT_STAN";
		public static final String DIGITURK_PAY_BILL_STAN = "DIGITURK_PAY_BILL_STAN";
		public static final String DIGITURK_CANCEL_PAY_BILL_STAN = "DIGITURK_CANCEL_PAY_BILL_STAN";
		public static final String DIGITURK_QUERY_STD_ORDER_STAN = "DIGITURK_QUERY_STD_ORDER_STAN";
		public static final String DIGITURK_CREATE_STD_ORDER_STAN = "DIGITURK_CREATE_STD_ORDER_STAN";
		public static final String DIGITURK_CANCEL_STD_ORDER_STAN = "DIGITURK_CANCEL_STD_ORDER_STAN";
		public static final String DIGITURK_COLL_RECON_STAN = "DIGITURK_COLL_RECON_STAN";
		public static final String DIGITURK_STD_ORDER_RECON_STAN = "DIGITURK_STD_ORDER_RECON_STAN";
		public static final String DIGITURK_FILE_INQUIRY_STAN = "DIGITURK_FILE_INQUIRY_STAN";
		public static final String DIGITURK_STD_ORDER_DEBT_INQUIRY_STAN = "DIGITURK_STDORD_DEBT_INQ_STAN";
	}
	
	private static final int DIGITURK_SUCCESS_CODE = 0;
	private static final String DIGITURK_DATE_FORMAT = "yyyy-MM-dd";
	private static final short STD_ORD_QUERY_MESSAGE_TYPE = 200;
	private static final short STD_ORD_QUERY_PROCESS_CODE = 97;
	private static final short DEBT_INQUIRY_MESSAGE_TYPE = 200;
	private static final short DEBT_INQUIRY_PROCESS_CODE = 41;
	private static final int DIGITURK_RECON_FAILED_CODE = 6004;
	private static final int DIGITURK_PAYMENT_RECON_PAY_COUNT_CODE = 11;
	private static final int DIGITURK_STD_ORDER_RECON_CREATE_COUNT_CODE = 66;
	private static final int DIGITURK_REPEATED_PAY_CODE = 8014;
	
	@GraymoundService("ICS_DIGITURK_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DIGITURK_INVOICE_DEBT_INQUIRY");
		
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		
		try{
			DigiturkClient client = getSoapClient(iMap, message);
			
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			int stanNo = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_QUERY_DEBT_STAN));
			short processSource = Short.valueOf(getDigiturkChannelCode(corporateCode, iMap.getString(MapKeys.CHANNEL_CODE, null)));
			
			tr.com.aktifbank.integration.digiturk.messages.PGWDebtResponse.PGWResponseMessage response = client.debtInquiry(processSource, subscriberNo , stanNo);
			CommonHelper.insertWsCallLog(iMap, message.getParameter1(), message.getParameter2(), message.getParameter3());
			if(DIGITURK_SUCCESS_CODE == response.getHeader().getResponseCode()){
				int counter = 0;
				for (BillInfo info : response.getData().getBillList().getBillInfo()) {
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, subscriberNo);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, getBankAmount(info.getTotalDebt()));
					String[] period = info.getBillingPeriod().split("-");
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, period[0]);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, period[1]);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, info.getBillNumber());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, info.getBillSequenceNumber());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, info.getBillType());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, info.getCurrencyCode());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(info.getDueDate(), DIGITURK_DATE_FORMAT));
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, info.getNameSurname());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, "");
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, info.getReferenceNumber());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, stanNo);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, response.getHeader().getTransactionDateTime().toGregorianCalendar().getTime());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, response.getHeader().getMessageID());
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, collectionType);
					output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
					output.put(MapKeys.INVOICE_LIST, counter, "CORPORATE_STAN_KEY", StanNoSequenceKeys.DIGITURK_PAY_BILL_STAN);
					output.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					output.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}
			}
			else{
				setErrorCodeToOutput(String.valueOf(response.getHeader().getResponseCode()), response.getHeader().getResponseExplanation(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_DIGITURK_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DIGITURK_DO_INVOICE_COLLECTION");
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		try{
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			if(!isStandingOrderCollection){
				DigiturkClient client = getSoapClient(iMap, message);
				
				String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
				BigDecimal transactionNo = iMap.getBigDecimal(MapKeys.TRX_NO);
				int stanNo = iMap.getInt("CORPORATE_STAN");
				
				int queryStanNo = 0;
				
				if(iMap.getBoolean(MapKeys.RECON_CALL, false)){
					GMMap searchMap = new GMMap();
					searchMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					searchMap.put(MapKeys.GM_SERVICE_NAME, "ICS_SEARCH_INVOICE");
					searchMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					searchMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNo);
					searchMap.put(MapKeys.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
					searchMap.put(MapKeys.COLLECTION_TYPE_NAME, "");
					
					GMMap searchOutput = CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", searchMap);
					
					queryStanNo = searchOutput.getInt(MapKeys.INVOICE_LIST, 0, MapKeys.PARAMETER5);
				}
				else{
					queryStanNo = iMap.getInt(MapKeys.PARAMETER5);
				}
				
				String subscriberName = iMap.getString(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NAME);
				int billType = iMap.getInt(MapKeys.PARAMETER2);
				String billingPeriod = iMap.getString(TransactionConstants.DoInvoiceCollection.Input.TERM_YEAR)
						.concat("-")
						.concat(iMap.getString(TransactionConstants.DoInvoiceCollection.Input.TERM_MONTH));
				Date dueDate = iMap.getDate(TransactionConstants.DoInvoiceCollection.Input.INVOICE_DUE_DATE);
				String referenceNumber = iMap.getString(MapKeys.PARAMETER4);
				String billNumber = iMap.getString(MapKeys.INVOICE_NO);
				int billSequenceNumber = iMap.getInt(MapKeys.PARAMETER1);
				BigDecimal paymentAmount = iMap.getBigDecimal(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_AMOUNT);
				int currencyCode = iMap.getInt(MapKeys.PARAMETER3);
				String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
				String channelCode = iMap.getString(MapKeys.CHANNEL_CODE, null);
				Date queryTransactionDate = new Date();
				
				tr.com.aktifbank.integration.digiturk.messages.PGWPaymentResponse.PGWResponseMessage response = client.doInvoiceCollection(
						Short.valueOf(getDigiturkChannelCode(corporateCode, channelCode)), stanNo, queryStanNo, 
						queryTransactionDate, queryStanNo, subscriberNo, subscriberName, billType, billingPeriod, 
						dueDate, referenceNumber, billNumber, billSequenceNumber, getCorporateAmount(paymentAmount), currencyCode);
				
				if(response.getHeader().getResponseCode() == DIGITURK_SUCCESS_CODE || 
						response.getHeader().getResponseCode() == DIGITURK_REPEATED_PAY_CODE){
					Session hibSession = CommonHelper.getHibernateSession();
					invoicePayment paymentRecord = (invoicePayment) hibSession
							.createCriteria(invoicePayment.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("txNo", transactionNo))
							.uniqueResult();
					paymentRecord.setParameter7(String.valueOf(response
							.getHeader().getMessageID()));
					paymentRecord.setParameter8(String.valueOf(stanNo));
					hibSession.saveOrUpdate(paymentRecord);
					hibSession.flush();
				}
				else{
					setErrorCodeToOutput(String.valueOf(response.getHeader().getResponseCode()), response.getHeader().getResponseExplanation(), output);
				}
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_DIGITURK_SET_STAN_NO")
	public static GMMap setStanNo(GMMap input){
		GMMap output = new GMMap();
		
		try{
			BigDecimal trxNo = input.getBigDecimal(MapKeys.TRX_NO);
			Session hibSession = CommonHelper.getHibernateSession();
			invoicePayment paymentRecord = (invoicePayment)hibSession.createCriteria(invoicePayment.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txNo", trxNo))
					.uniqueResult();
			if(StringUtil.isEmpty(paymentRecord.getParameter8())){
				paymentRecord.setParameter8(input.getString(MapKeys.STAN_NO));
				
				hibSession.saveOrUpdate(paymentRecord);
				hibSession.flush();
			}
		}
		catch(Exception e){
			logger.error(String.format("An exception occured while setting stan no for %s transaction", input.getString(MapKeys.TRX_NO)));
			logger.error(System.currentTimeMillis(), e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_DIGITURK_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap){
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DIGITURK_SEND_COLLECTION_CANCEL_MESSAGE");
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		try{
			DigiturkClient client = getSoapClient(iMap, message);
			
			String subscriberNo = iMap.getString("SUBSCRIBER_NO_1");
			int cancelStanNo = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_CANCEL_PAY_BILL_STAN));
			String billingPeriod = iMap.getString(MapKeys.TERM_YEAR)
					.concat("-")
					.concat(iMap.getString(MapKeys.TERM_MONTH));
			String billNumber = iMap.getString(MapKeys.INVOICE_NO);
			int billSequenceNumber = iMap.getInt("PARAMETER_1");
			int billType = iMap.getInt("PARAMETER_2");
			int currencyCode = iMap.getInt("PARAMETER_3");
			Date dueDate = iMap.getDate("INVOICE_DUE_DATE");
			String subscriberName = iMap.getString("SUBSCRIBER_NAME");
			BigDecimal paymentAmount = iMap.getBigDecimal("PAYMENT_AMOUNT");
			String referenceNumber = iMap.getString("PARAMETER_4");
			int paymentStanNo = iMap.getInt("PARAMETER_8");
			int queryStanNo = iMap.getInt("PARAMETER_5");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String channelCode = iMap.getString("PAYMENT_CHANNEL", null);
			
			tr.com.aktifbank.integration.digiturk.messages.PGWPaymentCancellationResponse.PGWResponseMessage response = client.cancelInvoice(
					Short.valueOf(getDigiturkChannelCode(corporateCode, channelCode)), cancelStanNo, billingPeriod, billNumber, billSequenceNumber, billType, 
					currencyCode, dueDate, subscriberName, getCorporateAmount(paymentAmount), referenceNumber, subscriberNo, queryStanNo, paymentStanNo);
			
			if(response.getHeader().getResponseCode() != DIGITURK_SUCCESS_CODE){
				setErrorCodeToOutput(String.valueOf(response.getHeader().getResponseCode()), response.getHeader().getResponseExplanation(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_DIGITURK_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_DIGITURK_SEND_STANDING_ORDER_MESSAGE");
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		try{
			DigiturkClient client = getSoapClient(iMap, message);
			
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			int queryStanNo = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_QUERY_STD_ORDER_STAN));
			int createStanNo = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_CREATE_STD_ORDER_STAN));
			BigDecimal transactionNo = iMap.getBigDecimal(MapKeys.TRX_NO);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String channelCode = iMap.getString(MapKeys.CHANNEL_CODE, null);
			
			tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderQueryResponse.PGWResponseMessage response = client.queryStandingOrderWithParameters(DigiturkConstants.ProcessSource, 
					queryStanNo, subscriberNo, STD_ORD_QUERY_MESSAGE_TYPE, STD_ORD_QUERY_PROCESS_CODE);
			
			iMap.put("REQUEST_XML_FOR_STD_QUERY", message.getRequest());
			output.put("RESPONSE_XML_FOR_STD_QUERY", message.getResponse());
			
			if(response.getHeader().getResponseCode() == DIGITURK_SUCCESS_CODE){
				tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderResponse.PGWResponseMessage stdOrderResponse = 
						client.createStandingOrder(Short.valueOf(getDigiturkChannelCode(corporateCode, channelCode)), createStanNo, queryStanNo, subscriberNo, queryStanNo);
				
				if(stdOrderResponse.getHeader().getResponseCode() != DIGITURK_SUCCESS_CODE){
					setErrorCodeToOutput(String.valueOf(stdOrderResponse.getHeader().getResponseCode()), stdOrderResponse.getHeader().getResponseExplanation(), output);
				}
				else{
					Session hibSession = CommonHelper.getHibernateSession();
					icsStandingOrders order = (icsStandingOrders) hibSession.createCriteria(icsStandingOrders.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("txNo", transactionNo))
							.uniqueResult();
					
					order.setParameter1(String.valueOf(queryStanNo));
					hibSession.saveOrUpdate(order);
					hibSession.flush();
				}
			}
			else{
				setErrorCodeToOutput(String.valueOf(response.getHeader().getResponseCode()), response.getHeader().getResponseExplanation(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_DIGITURK_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"STO_DIGITURK_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		try{
			DigiturkClient client = getSoapClient(iMap, message);
			
			String subscriberNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			BigDecimal transactionNo = iMap.getBigDecimal(MapKeys.TRX_NO);
			int stanNo = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_CANCEL_STD_ORDER_STAN));
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String channelCode = iMap.getString(MapKeys.CHANNEL_CODE, null);
			
			Session hibSession = CommonHelper.getHibernateSession();
			
			icsStandingOrders order = (icsStandingOrders) hibSession.createCriteria(icsStandingOrders.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txNo", transactionNo))
					.uniqueResult();
			
			tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderCancellationResponse.PGWResponseMessage cancelResponse = 
					client.cancelStandingOrder(Short.valueOf(getDigiturkChannelCode(corporateCode, channelCode)), stanNo, subscriberNo, Integer.valueOf(order.getParameter1()), 
							Integer.valueOf(order.getParameter1()), CommonHelper.getDateTime(order.getCreateDate(),"yyyyMMddhhmmss"));
			
			if(cancelResponse.getHeader().getResponseCode() != DIGITURK_SUCCESS_CODE){
				setErrorCodeToOutput(String.valueOf(cancelResponse.getHeader().getResponseCode()), cancelResponse.getHeader().getResponseExplanation(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_DIGITURK_DEBT_INQUIRY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DIGITURK_DEBT_INQUIRY_FOR_STANDING_ORDER");
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		try{
			DigiturkClient client = getSoapClient(iMap, message);
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			int stan = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_FILE_INQUIRY_STAN));
			
			tr.com.aktifbank.integration.digiturk.messages.PGWFileInquiryResponse.PGWResponseMessage fileInfoResponse = client.fileInfoInquiry(
					DigiturkConstants.FileProcessSource, iMap.getDate(MapKeys.PROCESS_DATE), 
					DigiturkConstants.ExistFileInquiryType, DigiturkConstants.DebtFileType, stan, DEBT_INQUIRY_MESSAGE_TYPE, DEBT_INQUIRY_PROCESS_CODE);
			
			iMap.put("REQUEST_XML_FILE_INFO", message.getRequest());
			output.put("RESPONSE_XML_FILE_INFO", message.getResponse());
			
			if(fileInfoResponse.getHeader().getResponseCode() == DIGITURK_SUCCESS_CODE){
				int counter = 0;
				short pageCount = fileInfoResponse.getData().getPageCount();
				for (short i = 1; i <= pageCount; i++) {
					int queryStan = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_STD_ORDER_DEBT_INQUIRY_STAN));
					tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderDebtQueryResponse.PGWResponseMessage response = 
							client.queryStandingOrderDebts(BigInteger.valueOf(DigiturkConstants.FileProcessSource), BigInteger.valueOf(i), BigInteger.valueOf(queryStan), 
										fileInfoResponse.getData().getFileName(), BigInteger.valueOf(stan));
					iMap.put("REQUEST_XML_DEBT_INQUIRY" + String.valueOf(i), message.getRequest());
					output.put("RESPONSE_XML_DEBT_INQUIRY" + String.valueOf(i), message.getResponse());
					if(response.getHeader().getResponseCode() == DIGITURK_SUCCESS_CODE){
						DeptList debtList = response.getData().getDeptList();
						List<DeptInfo> debtInfoList = debtList.getDeptInfo();
						for (DeptInfo info : debtInfoList) {
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, info.getCustomerNumber());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, info.getBillNumber());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, getBankAmount(info.getTotalDebt()));
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, 0);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(info.getDueDate(), "yyyyMMdd"));
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
							String year = info.getBillingPeriod().substring(0, 4);
							String month = info.getBillingPeriod().substring(4, 6);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, month);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, year);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, info.getNameSurname());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, info.getBillSequenceNumber());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER2, info.getBillType());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER3, info.getCurrencyCode());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER4, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER5, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER6, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER7, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER8, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER9, info.getCustomerAccessType());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER10, info.getSubscriberNumber());
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER11, queryStan);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER12, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER13, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER14, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER15, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER16, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER17, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER18, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER19, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER20, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DATE, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUB_COLLECTION_TYPE, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO3, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO4, GeneralConstants.DEFAULT_STRING);
							output.put(MapKeys.INVOICE_LIST, counter, MapKeys.ZONE_CODE, GeneralConstants.DEFAULT_STRING);
							counter++;
						}
					}
					else{
						setErrorCodeToOutput(String.valueOf(response.getHeader().getResponseCode()), response.getHeader().getResponseExplanation(), output);
						break;
					}
				}
			}
			else{
				setErrorCodeToOutput(String.valueOf(fileInfoResponse.getHeader().getResponseCode()), fileInfoResponse.getHeader().getResponseExplanation(), output);
			}
			
			output.put(MapKeys.TABLE_SIZE, output.getSize(MapKeys.INVOICE_LIST));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_DIGITURK_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DIGITURK_COLLECTION_RECONCILIATION");
		try{
			DigiturkClient client = getSoapClient(iMap, message);
			Date reconDate = iMap.getDate(MapKeys.RECON_DATE);
			
			int stan = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_COLL_RECON_STAN));
			iMap.put(MapKeys.TT_RECON_FLAG, true);/*TALIMATLI TAHSILATLAR MUTABAKAT TOPLAM VE ADEDINDE GELMEYECEK*/
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			BigDecimal collectionAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);
			
			tr.com.aktifbank.integration.digiturk.messages.PGWPaymentReconResponse.PGWResponseMessage response =
					client.collectionReconSummary(DigiturkConstants.ProcessSource, stan, reconDate, getCorporateAmount(collectionAmount), collectionCount, 
							getCorporateAmount(cancelAmount), cancelCount);
			
			int responseCode = response.getHeader().getResponseCode();
			
			if(responseCode == DIGITURK_SUCCESS_CODE || responseCode == DIGITURK_RECON_FAILED_CODE){
				tr.com.aktifbank.integration.digiturk.messages.PGWPaymentReconResponse.PGWResponseMessage.Data.ReconList reconList =
						response.getData().getReconList();
				List<tr.com.aktifbank.integration.digiturk.messages.PGWPaymentReconResponse.ReconInfo> reconInfoList = reconList.getReconInfo();
				
				tr.com.aktifbank.integration.digiturk.messages.PGWPaymentReconResponse.ReconInfo paymentReconInfo = null;
				
				tr.com.aktifbank.integration.digiturk.messages.PGWPaymentReconResponse.ReconInfo cancelReconInfo = null;
				
				for (tr.com.aktifbank.integration.digiturk.messages.PGWPaymentReconResponse.ReconInfo info : reconInfoList) {
					if(info.getProcessCode() == DIGITURK_PAYMENT_RECON_PAY_COUNT_CODE){
						paymentReconInfo = info;
					}
					else{
						cancelReconInfo = info;
					}
				}
				
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, getBankAmount(paymentReconInfo.getTotalProcessAmount() - cancelReconInfo.getTotalProcessAmount()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, paymentReconInfo.getTotalProcessCount() - cancelReconInfo.getTotalProcessCount());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, getBankAmount(cancelReconInfo.getTotalProcessAmount()));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelReconInfo.getTotalProcessCount());
				
				if(responseCode == DIGITURK_SUCCESS_CODE){
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
				else{
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}
			else{
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				
				setErrorCodeToOutput(String.valueOf(response.getHeader().getResponseCode()), response.getHeader().getResponseExplanation(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_DIGITURK_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DIGITURK_GET_COLLECTION_RECONCILIATION_DETAIL");
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		CollectionReconciliationDetailBatch batch = new DigiturkCollectionReconciliationDetailBatch(getSoapClient(iMap, message), iMap);
		output = batch.runBatch();
		return output;
	}
	
	
	@GraymoundService("ICS_DIGITURK_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_DIGITURK_COLLECTION_RECONCILIATION_CLOSED");
		
		try{
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.getString(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.getString(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_DIGITURK_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_DIGITURK_STANDING_ORDER_RECONCILIATION");
		DigiturkServiceMessage message = new DigiturkServiceMessage();
		try{
			DigiturkClient client = getSoapClient(iMap, message);
			Date reconDate = iMap.getDate(MapKeys.RECON_DATE);
			int stan = Integer.valueOf(CorporationServiceUtil.getSequenceCode(StanNoSequenceKeys.DIGITURK_STD_ORDER_RECON_STAN));
			
			if(iMap.getString("SCREEN_RECONCILIATION", "0").equals("0")){
				reconDate = CommonHelper.addDay(reconDate, -1);
			}
			
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
			rcInput.put("RECON_DATE", reconDate);

			GMMap rcOutput = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT", rcInput);
			
			int bankStandingOrderCount = rcOutput.getInt(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT);
			int bankStandingOrderCancelCount = rcOutput.getInt("CANCEL_COUNT");
			
			tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderReconResponse.PGWResponseMessage response = 
					client.stdOrderReconSummary(DigiturkConstants.ProcessSource, reconDate, stan, bankStandingOrderCount, bankStandingOrderCancelCount);
			
			if(response.getHeader().getResponseCode() == DIGITURK_SUCCESS_CODE || response.getHeader().getResponseCode() == DIGITURK_RECON_FAILED_CODE){
				tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderReconResponse.PGWResponseMessage.Data.ReconList reconList =
						response.getData().getReconList();
				List<tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderReconResponse.ReconInfo> reconInfoList = reconList.getReconInfo();
				
				tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderReconResponse.ReconInfo createReconInfo = null;
				
				tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderReconResponse.ReconInfo cancelReconInfo = null;
				
				for (tr.com.aktifbank.integration.digiturk.messages.PGWStandingOrderReconResponse.ReconInfo info : reconInfoList) {
					if(info.getProcessCode() == DIGITURK_STD_ORDER_RECON_CREATE_COUNT_CODE){
						createReconInfo = info;
					}
					else{
						cancelReconInfo = info;
					}
				}
				
				output.put(MapKeys.RECON_CORPORATE_COUNT, createReconInfo.getTotalProcessCount() - cancelReconInfo.getTotalProcessCount());
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, cancelReconInfo.getTotalProcessCount());
				output.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderCount);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
				
			}
			else{
				output.put(MapKeys.RECON_CORPORATE_COUNT, -1);
				output.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, -1);
				output.put(MapKeys.RECON_BANK_COUNT, -1);
				output.put(MapKeys.RECON_BANK_CANCEL_COUNT, -1);
				setErrorCodeToOutput(String.valueOf(response.getHeader().getResponseCode()), response.getHeader().getResponseExplanation(), output);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", message.getRequest());
			output.put("RESPONSE_XML", message.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("STO_DIGITURK_GET_STANDING_ORDER_RECONCILIATION_DETAIL")
	public static GMMap getStandinOrderReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		
		output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
		return output;
	}
	
	@GraymoundService("ICS_DIGITURK_MANAGE_STAN")
	public static GMMap digiturkManageStan(GMMap input){
		GMMap output = new GMMap();
		
		try{
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_QUERY_DEBT_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_PAY_BILL_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_CANCEL_PAY_BILL_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_QUERY_STD_ORDER_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_CREATE_STD_ORDER_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_CANCEL_STD_ORDER_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_COLL_RECON_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_FILE_INQUIRY_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_STDORD_DEBT_INQ_STAN'");
			CommonHelper.executeQuery("UPDATE bnspr.gnl_genel_kod SET kod_deger=0 WHERE kod_adi='DIGITURK_STD_ORDER_RECON_STAN'");		
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	private static void setErrorCodeToOutput(String errorCode, String errorMessage, GMMap output){
		String message = errorCode.concat("-").concat(errorMessage);
		output.put(MapKeys.ERROR_CODE, GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE);
		output.put(MapKeys.ERROR_DESC, message);
		output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, message);
	}

	private static DigiturkClient getSoapClient(GMMap iMap, DigiturkServiceMessage message) {
		ClientInformation information = new ClientInformation();
		information.setBranchCode(DigiturkConstants.BranchCode);
		information.setCityCode(DigiturkConstants.CityCode);
		information.setClientCode(Integer.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER)));
		information.setCounterCode(DigiturkConstants.CounterCode);
		information.setMessageType(Integer.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1)));
		information.setMessageVersion(Integer.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2)));
		information.setPassword(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD));
		information.setProcessCode(Integer.valueOf(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3)));
		information.setUrl(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT));
		information.setUserName(DigiturkConstants.UserName);
		
		return new DigiturkClient(information, message);
	}
	
	private static String getDigiturkChannelCode(String corporateCode, String channelCode){
		String query = "SELECT CORPORATE_CONSTANT FROM CDM.CORPORATE_CHANNEL_PRM WHERE CORPORATE_CODE='%s' AND CHANNEL_CODE='%s' AND SOURCE_CODE='2' AND COLLECTION_TYPE=0";
		if(StringUtil.isEmpty(channelCode)){
			channelCode = CommonHelper.getChannelId();
		}
		return DALUtil.getResult(String.format(query, corporateCode, channelCode));
	}
	
	private static BigDecimal getBankAmount(long corporateAmount){
		return new BigDecimal(corporateAmount).divide(new BigDecimal(100));
	}
	
	private static BigDecimal getCorporateAmount(BigDecimal bankAmount){
		return bankAmount.multiply(new BigDecimal(100));
	}
}
