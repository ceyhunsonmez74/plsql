package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.batch.implementations.TurkeliWaterReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.belsis.BelsisClient;
import tr.com.aktifbank.integration.belsis.ServiceMessage;
import tr.com.belsis.odemeservis.ArrayOfOdenenTahakkuk;
import tr.com.belsis.odemeservis.BorcSorgulaC;
import tr.com.belsis.odemeservis.BorcluTahakkuk;
import tr.com.belsis.odemeservis.KesinMutabakatC;
import tr.com.belsis.odemeservis.MutabakatGenelC;
import tr.com.belsis.odemeservis.OdemeAlC;
import tr.com.belsis.odemeservis.OdemeIptalC;
import tr.com.belsis.odemeservis.OdenenTahakkuk;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class TurkeliWaterServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(TurkeliWaterServices.class);
	private static final String WATER = "S";
	private static final String TAX = "V";

	@GraymoundService("ICS_TURKELI_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKELI_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		int rowCount = 0;
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			int onlyWater = 1;
			if (WATER.equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1))) {
				onlyWater = 1;
			} else if (TAX.equals(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1))){
				onlyWater = 0;
			}
			
			String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String subscriberNo2 = iMap.getString(MapKeys.SUBSCRIBER_NO2);
			String subscriberNo3 = iMap.getString(MapKeys.SUBSCRIBER_NO3);
			String subscriberNo4 = iMap.getString(MapKeys.SUBSCRIBER_NO4);

			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";			
			BorcSorgulaC response = null;
			
			try{				
				if(StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))&& !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO3))&& !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO4))){
					response = BelsisClient.borcSorgula(reqTimeout, connTimeout, serviceUrl, username, password, sm, bankCode, password, 0, subscriberNo1, "SUABN", onlyWater);
					responseCode = Integer.toString(response.getSonucKodu());
					responseMessage = response.getSonucAciklamasi();
				} else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))&& !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO3))&& !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO4))){
					response = BelsisClient.borcSorgula(reqTimeout, connTimeout, serviceUrl, username, password, sm, bankCode, password, 0, subscriberNo2, "SICIL", onlyWater);
					responseCode = Integer.toString(response.getSonucKodu());
					responseMessage = response.getSonucAciklamasi();
				}else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))&& StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO3))&& !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO4))){
					response = BelsisClient.borcSorgula(reqTimeout, connTimeout, serviceUrl, username, password, sm, bankCode, password, 0, subscriberNo3, "TCKN", onlyWater);
					responseCode = Integer.toString(response.getSonucKodu());
					responseMessage = response.getSonucAciklamasi();
				}else if(!StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO2))&& !StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO3))&& StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO4))){
					response = BelsisClient.borcSorgula(reqTimeout, connTimeout, serviceUrl, username, password, sm, bankCode, password, 0, subscriberNo4, "VKN", onlyWater);
					responseCode = Integer.toString(response.getSonucKodu());
					responseMessage = response.getSonucAciklamasi();
				}		
			} catch (Exception ex) {
				logger.error("ICS_TURKELI_INVOICE_DEBT_INQUIRY - an error is occured ()".concat(ex.getMessage()));
				responseCode = Integer.toString(response.getSonucKodu());
				responseMessage = response.getSonucAciklamasi();
				logger.info("ICS_TURKELI_INVOICE_DEBT_INQUIRY error code = ".concat(responseCode));
				logger.info("ICS_TURKELI_INVOICE_DEBT_INQUIRY error message = ".concat(responseMessage));
			}
			
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (BorcluTahakkuk borc : response.getTahakkukListesi().getBorcluTahakkuk()) {
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO1, subscriberNo1);
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO2, subscriberNo2);
					if (StringUtils.isNotBlank(iMap.getString(MapKeys.SUBSCRIBER_NO3))) {
						outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NO1, subscriberNo3);
					}
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PARAMETER2, response.getSicilNo());
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.SUBSCRIBER_NAME, response.getAdiSoyadiUnvani());
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.AMOUNT, borc.getOdenecekTutar());			
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_NO, borc.getTahakkukNo());
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_DUE_DATE, CommonHelper.getShortDateTimeString(borc.getSonOdemeTarihi().toGregorianCalendar().getTime()));
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_TERM_YEAR, borc.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.YEAR));
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.INVOICE_TERM_MONTH, borc.getSonOdemeTarihi().toGregorianCalendar().get(Calendar.MONTH));
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, rowCount, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));	
					rowCount++;
				}
			}
			
		} catch (Throwable e2) {
			logger.error("ICS_TURKELI_INVOICE_DEBT_INQUIRY for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_TURKELI_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKELI_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		ServiceMessage sm = new ServiceMessage();
		try {
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 			
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			BigDecimal paymentAmount = iMap.getBigDecimal(MapKeys.PAYMENT_AMOUNT);
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String billID = iMap.getString(MapKeys.INVOICE_NO);
			long registerId = iMap.getLong(MapKeys.PARAMETER2);
			String referenceNumber = iMap.getString(MapKeys.TRX_NO);
			String paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			String responseMessage = "";			
			OdemeAlC response = null;
			ArrayOfOdenenTahakkuk odemeListesi = new ArrayOfOdenenTahakkuk();
			OdenenTahakkuk odenenTahakkuk = new OdenenTahakkuk();
			odenenTahakkuk.setTahakkukNo(billID);
			odenenTahakkuk.setOdemeTutari(paymentAmount);
			odemeListesi.getOdenenTahakkuk().add(odenenTahakkuk);
			
			String tahsilatTarihi ="";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = iMap.getString(MapKeys.PAYMENT_DATE);
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss");
			}
			
			XMLGregorianCalendar paymentDate= stringToXMLGregorianCalendar(tahsilatTarihi, "yyyyMMddhhmmss");
					
			try {
				response = BelsisClient.odemeAl(reqTimeout, connTimeout, serviceUrl, username, password, sm, bankCode, password, referenceNumber, Integer.parseInt(paymentChannel), registerId, paymentAmount, odemeListesi, paymentDate);
				responseCode = Integer.toString(response.getSonucKodu());
				responseMessage = response.getSonucAciklamasi();
			} catch (Exception ex) {
				logger.error("ICS_TURKELI_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - an error is occured ()"));
				responseCode = Integer.toString(response.getSonucKodu());
				responseMessage = response.getSonucAciklamasi();
				logger.info("ICS_TURKELI_DO_INVOICE_COLLECTION error code = ".concat(responseCode));
				logger.info("ICS_TURKELI_DO_INVOICE_COLLECTION error message = ".concat(responseMessage));
			}			
			
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				Session session = DAOSession.getSession("BNSPRDal");
				invoicePayment invoicePayment = (invoicePayment) session.createCriteria(invoicePayment.class).add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO))).uniqueResult();
				invoicePayment.setParameter3(response.getKurumReferansNo());
				session.saveOrUpdate(invoicePayment);
			}
			
		} catch (Throwable e2) {
			logger.error("ICS_TURKELI_DO_INVOICE_COLLECTION for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_TURKELI_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKELI_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {			
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 			
			long registerId = iMap.getLong(MapKeys.PARAMETER_2);
			String bankaReferansNo = iMap.getString(MapKeys.TRX_NO);
			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			String responseMessage = "";		
			OdemeIptalC response = null;
			
			try {				
				response = BelsisClient.odemeIptal(reqTimeout, connTimeout, serviceUrl, username, password, sm, bankCode, bankaReferansNo, username, registerId);
				responseCode = Integer.toString(response.getSonucKodu());
				responseMessage = response.getSonucAciklamasi();
			} catch (Exception ex) {
				logger.error("ICS_TURKELI_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - an error is occured ()"));
				responseCode = Integer.toString(response.getSonucKodu());
				responseMessage = response.getSonucAciklamasi();
				logger.info("ICS_TURKELI_DO_INVOICE_COLLECTION error code = ".concat(responseCode));
				logger.info("ICS_TURKELI_DO_INVOICE_COLLECTION error message = ".concat(responseMessage));
			}			
			
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			CommonHelper.insertWsCallLog(iMap, sm.getDuration(), sm.getStartTime(), sm.getEndTime());

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				
			}
			
		} catch (Throwable e2) {
			logger.error("ICS_TURKELI_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			outMap.put("ERROR_RESPONSE", sm.getResponse());
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@SuppressWarnings("unused")
	@GraymoundService("ICS_TURKELI_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage sm = new ServiceMessage();
		String errorMessage = "";
		String responseCode = "";
		String responseMessage = "";
		KesinMutabakatC responseClose = new KesinMutabakatC();
		
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKELI_COLLECTION_RECONCILIATION");
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			String firstDateStr = reconDate.concat("000000");
			String lastDateStr = reconDate.concat("235959");
			

			XMLGregorianCalendar firstDate  = stringToXMLGregorianCalendar(firstDateStr, "yyyyMMddHHmmss");
			XMLGregorianCalendar lastDate  = stringToXMLGregorianCalendar(lastDateStr, "yyyyMMddHHmmss");

			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			MutabakatGenelC response = BelsisClient.mutabakatGenel(reqTimeout, connTimeout, serviceUrl, username, password, sm, bankCode, username, firstDate, lastDate);
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());

			// aldigin sayilari koy
			logger.info("ICS_TURKELI_COLLECTION_RECONCILIATION - response() null degil");
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getGecerliDekontSayisi() != 0 ? response.getGecerliDekontTutari() : new BigDecimal(0));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getGecerliDekontSayisi() != 0 ? response.getGecerliDekontSayisi() : 0);
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getIptalDekontSayisi() != 0 ? response.getIptalDekontTutari() : new BigDecimal(0));
			output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getIptalDekontSayisi() != 0 ? response.getIptalDekontSayisi() : 0);

			// tahsilat tutarlari
			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				logger.info("ICS_TURKELI_COLLECTION_RECONCILIATION - mutabakat basarili olarak kapatildi ");
				
				ServiceMessage serviceMessageForClose = new ServiceMessage();
				try {
					responseClose = BelsisClient.kesinMutabakat(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessageForClose, bankCode, username, collectionCount, cancelCount, collectionTotal, cancelTotal, firstDate);
					responseCode = Integer.toString(response.getSonucKodu());
					responseMessage = response.getSonucAciklamasi();
				} catch (Exception ex) {
					logger.error("ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED ".concat(" - an error is occured"));
					responseCode = Integer.toString(response.getSonucKodu());
					responseMessage = response.getSonucAciklamasi();
					logger.info("ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED error code = ".concat(responseCode));
					logger.info("ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED error message = ".concat(responseMessage));
				}

				iMap.put("REQUEST_XML_FOR_CLOSE", serviceMessageForClose.getRequest());
				output.put("RESPONSE_XML_FOR_CLOSE", serviceMessageForClose.getResponse());
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);

				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
					output.put(MapKeys.ERROR_CODE, "660");
					output.put(MapKeys.ERROR_DESC, errorMessage);
				}
				else {
					output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
				
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
				
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_TURKELI_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_TURKELI_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_TURKELI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKELI_GET_COLLECTION_RECONCILIATION_DETAIL");
		ServiceMessage sm = new ServiceMessage();
		try {
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iMap.put(MapKeys.CORPORATE_OID, cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			TurkeliWaterReconciliationDetailBatch batch = new TurkeliWaterReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_TURKELI_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			output.put("ERROR_RESPONSE", sm.getResponse());
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	@GraymoundService("ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		String errorMessage = "";
		ServiceMessage serviceMessage = new ServiceMessage();
		String responseCode="";
		String responseMessage = "";
		KesinMutabakatC response = new KesinMutabakatC();
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED");
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconDate = iMap.getString(MapKeys.RECON_DATE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);			
			int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			
			String firstDateStr = reconDate.concat("000000");
			
			XMLGregorianCalendar firstDate  = stringToXMLGregorianCalendar(firstDateStr, "yyyyMMddHHmmss");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal paymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelPaymentAmount = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int paymentCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelPaymentCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, paymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelPaymentAmount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, paymentCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelPaymentCount);
			try {				
				response = BelsisClient.kesinMutabakat(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, bankCode, username, paymentCount, cancelPaymentCount, paymentAmount, cancelPaymentAmount, firstDate);
				responseCode = Integer.toString(response.getSonucKodu());
				responseMessage = response.getSonucAciklamasi();
			} catch (Exception ex) {
				logger.error("ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED ".concat(" - an error is occured (FaultMessage)"));
				responseCode = Integer.toString(response.getSonucKodu());
				responseMessage = response.getSonucAciklamasi();
				logger.info("ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED error code = ".concat(responseCode));
				logger.info("ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED error message = ".concat(responseMessage));
			}
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());

			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
	
				if (!errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						errorMessage = responceCodeMap.getString(MapKeys.ERROR_DESC);
						output.put(MapKeys.ERROR_CODE, "660");
						output.put(MapKeys.ERROR_DESC, errorMessage);
					}
					else {
						output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
		}
		catch (Throwable e) {
			logger.info("ICS_TURKELI_COLLECTION_RECONCILIATION_CLOSED - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, errorMessage);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}
	
	public static XMLGregorianCalendar stringToXMLGregorianCalendar(String datetime, String dateFormat) {

	    try {

	    	Date date = CommonHelper.getDateTime(datetime, dateFormat);	        
	        GregorianCalendar cal = (GregorianCalendar) GregorianCalendar
	                .getInstance();

	        cal.setTime(date);
	        return	DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);

	    } catch (Exception e) {

	        System.out.print(e.getMessage());

	        return null;

	    }
	}
	

}
