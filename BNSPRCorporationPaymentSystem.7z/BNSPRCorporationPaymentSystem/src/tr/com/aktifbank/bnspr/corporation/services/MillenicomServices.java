package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.MillenicomReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.integration.millenicom.MillenicomClient;
import tr.com.aktifbank.integration.millenicom.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.milleni.online_tahsilat.AcikKalem;
import com.milleni.online_tahsilat.IslemSonucu;
import com.milleni.online_tahsilat.TopluMutabakatRakamlari;

public class MillenicomServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(MillenicomServices.class);

	private static String SUCCESS = "0";
	private static String FAIL = "1";
	
	@GraymoundService("ICS_MILLENICOM_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MILLENICOM_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		try {
			// parameters are taken
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String musteriNo = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1), '0');
			// logger info will be logged
			builder.append(" ICS_MILLENICOM_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Musteri No -> ");
			builder.append(musteriNo);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(url);
			logger.info(builder.toString());

			logger.info("ICS_MILLENICOM_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MillenicomClient.acikKalemler(...) will be called..."));
			ServiceMessage sm = new ServiceMessage();
			AcikKalem[] response = MillenicomClient.acikKalemler(url, username, password, Calendar.getInstance(), musteriNo, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			logger.info("ICS_MILLENICOM_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MillenicomClient.acikKalemler(...) is called..."));
			
			responseCode = response.length > 0 ? SUCCESS : FAIL; 
			logger.info("ICS_MILLENICOM_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MillenicomClient.acikKalemler(...) returned response code ".concat(responseCode)));
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_MILLENICOM_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MillenicomClient.acikKalemler(...) returned errorCode ".concat(errorCode)));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (AcikKalem borc : response) {
					if (!isCollectedInvoice(borc.getReferansNo(), musteriNo, "", "", "", corporateCode)) {

						Date faturaTarihi = CommonHelper.getDateTime(borc.getFaturaTarihi(), "yyyy-MM-dd");
						Calendar cal = Calendar.getInstance();
						cal.setTime(faturaTarihi);
						String invoiceDueDate = CommonHelper.getDateString(CommonHelper.getDateTime(borc.getSonOdemeTarihi(), "yyyy-MM-dd"), "yyyyMMdd");
						
						String billingAmount = borc.getTutar().replace(",", ".");
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getMusteriNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getReferansNo());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, billingAmount);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getMusteriAdi());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, cal.get(Calendar.YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, String.format("%02d", cal.get(Calendar.MONTH)+1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, billingAmount);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getFaturaTarihi());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			logger.info("ICS_MILLENICOM_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - MillenicomClient.acikKalemler(...) finished succesfully"));
			insertOnlineServiceLog(iMap, outMap);
		} catch (Throwable e2) {
			logger.error("ICS_MILLENICOM_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_MILLENICOM_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MILLENICOM_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		try {
			// parameters are taken
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String musteriNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String referansNo = iMap.getString(MapKeys.INVOICE_NO);
			String faturaTarihi = iMap.getString(MapKeys.PARAMETER1);
			
			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";
			
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_MILLENICOM_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | ��lem Referans No -> ");
			builder.append(p_sIslemReferansNo);
			builder.append(" | musteriNo -> ");
			builder.append(musteriNo);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			logger.info(builder.toString());

			if (isStandingOrderCollection) {
				logger.info("ICS_MILLENICOM_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - MillenicomClient.tahsilatYap(...) before call..").concat("isStandingOrderCollection:true"));
			}else{
				logger.info("ICS_MILLENICOM_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - MillenicomClient.tahsilatYap(...) before call..").concat("isStandingOrderCollection:false"));
			}
			
			ServiceMessage sm = new ServiceMessage();
			IslemSonucu[] response = MillenicomClient.tahsilatYap(url, username, password, Calendar.getInstance(), musteriNo, referansNo, faturaTarihi, tahsilatTarihi, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			
			String responseCode = SUCCESS;
			String responseMessage = "";
			if(response.length > 0){
				responseCode = CommonHelper.trimStart(response[0].getMesajKodu(), '0');
				responseMessage = response[0].getDurumAciklamasi();
				outMap.put("DURUM_ACIKLAMASI", responseMessage);
			}else
				responseCode = FAIL;
			
			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
            outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responseMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			logger.info("ICS_MILLENICOM_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - MillenicomClient.tahsilatYap(...) returned errorCode ".concat(responseCode)));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_MILLENICOM_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MILLENICOM_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String referansNo = iMap.getString(MapKeys.INVOICE_NO);
			
			String faturaTarihi = "";
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PARAMETER_1))) {
				faturaTarihi = iMap.getString(MapKeys.PARAMETER_1);
			} else {
				faturaTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}

			String musteriNo = iMap.getString("SUBSCRIBER_NO_1", null);
			if (musteriNo == null) {
				musteriNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}
			
			builder.append(" ICS_MILLENICOM_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | url -> ");
			builder.append(url);
			logger.info(builder.toString());

			musteriNo = CommonHelper.trimStart(musteriNo, '0');
			referansNo = CommonHelper.trimStart(referansNo, '0');
			ServiceMessage sm = new ServiceMessage();
			IslemSonucu[] response = MillenicomClient.tahsilatIptaliYap(url, username, password, Calendar.getInstance(), musteriNo, referansNo, faturaTarihi, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			
			String responseCode = SUCCESS;
			String responseMessage = "";
			if(response.length > 0){
				responseCode = CommonHelper.trimStart(response[0].getMesajKodu(), '0');
				responseMessage = response[0].getDurumAciklamasi();
			}else
				responseCode = FAIL;	
			
			logger.info("ICS_MILLENICOM_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			logger.info("ICS_MILLENICOM_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(responseCode));
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responseMessage);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_MILLENICOM_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MILLENICOM_COLLECTION_RECONCILIATION");
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Date reconDate = CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd");
			String baslangicTarihi = CommonHelper.getDateString(reconDate, "yyyy-MM-dd");
			String bitisTarihi = CommonHelper.getDateString(reconDate, "yyyy-MM-dd");
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal.add(cancelTotal));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount + cancelCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			builder.append(" ICS_MILLENICOM_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());
			
			ServiceMessage sm = new ServiceMessage();
			TopluMutabakatRakamlari response = MillenicomClient.topluMutabakat(url, username, password, Calendar.getInstance(), baslangicTarihi, bitisTarihi, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			
			if (response == null) {
				// tahsilat yok ya da hata var sayilari 0 a esitle
				logger.info("ICS_MILLENICOM_COLLECTION_RECONCILIATION - result size 0 geldi");

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_MILLENICOM_COLLECTION_RECONCILIATION - response.getBgsTahsilIcmalDto() null degil");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getToplamTahsilatTutari());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getToplamTahsilatAdedi());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getToplamIptalTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getToplamIptalAdedi());
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_MILLENICOM_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");
				MillenicomClient.topluMutabakatYap(url, username, password, Calendar.getInstance(), baslangicTarihi, bitisTarihi, sm);
				iMap.put("REQUEST_TMY_XML", sm.getRequest());
				output.put("RESPONSE_TMY_XML", sm.getResponse());				
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_MILLENICOM_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_MILLENICOM_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_MILLENICOM_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MILLENICOM_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {
			
			ServiceMessage sm = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new MillenicomReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());
			
		} catch (Throwable e) {
			logger.info("ICS_MILLENICOM_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_MILLENICOM_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_MILLENICOM_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

}
