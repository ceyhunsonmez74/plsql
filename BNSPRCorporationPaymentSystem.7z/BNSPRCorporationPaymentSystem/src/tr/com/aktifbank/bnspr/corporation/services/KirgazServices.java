package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.integration.kirgaz.KirgazClient;
import tr.com.aktifbank.integration.kirgaz.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.kirgaz.DebtInquiryResponse;
import tr.com.kirgaz.DetailReconResponse;
import tr.com.kirgaz.GeneralReconResponse;
import tr.com.kirgaz.PaymentResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class KirgazServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(KirgazServices.class);

	@GraymoundService("ICS_KIRGAZ_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KIRGAZ_INVOICE_DEBT_INQUIRY");

		try{
			String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String collectionType = iMap.getString(MapKeys.COLLECTION_TYPE);
			String collectionTypeName = iMap.getString(MapKeys.COLLECTION_TYPE_NAME);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			ArrayList<DebtInquiryResponse> debtInquiryResponseList = KirgazClient.invoiceDebtInquiry(subscriberNo1, bankCode, serviceUrl, username, password, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			String responseCode =  debtInquiryResponseList.get(0).getIslemSonucKod();

			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		
			if(errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)){
				int i = 0;
				for (DebtInquiryResponse debtInquiryResponse : debtInquiryResponseList) {	
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1, subscriberNo1);
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT, debtInquiryResponse.getFaturaTutari());
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_YEAR, debtInquiryResponse.getSonOdemeTrYMD().substring(0,4));
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_TERM_MONTH, debtInquiryResponse.getSonOdemeTrYMD().substring(5,7));
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO, debtInquiryResponse.getFaturaNo());
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE, CommonHelper.getDateTime(debtInquiryResponse.getSonOdemeTrYMD(), "yyyyMMdd"));
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME, debtInquiryResponse.getAboneAd().concat(" ").concat(debtInquiryResponse.getAboneSoyad()));
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_AMOUNT, debtInquiryResponse.getFaturaTutari());
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.CORPORATE_CODE, corporateCode);
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE, collectionType);
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE_NAME, collectionTypeName);
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					output.put(MapKeys.INVOICE_LIST, i, MapKeys.DESCRIPTION, debtInquiryResponse.getAciklama());
	
					output.put(MapKeys.INVOICE_LIST, i, "SELECT", false);
					output.put(MapKeys.INVOICE_LIST, i, "OID", "0");
					i++;
				}
			}
		
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}

	@GraymoundService("ICS_KIRGAZ_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollection(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KIRGAZ_DO_INVOICE_COLLECTION");
		
		try{
			String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			String paymentDate = CommonHelper.getShortDateTimeString(new Date());
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			PaymentResponse paymentResponse = KirgazClient.invoiceDebtPayment(subscriberNo1, invoiceNo, paymentDate, bankCode, serviceUrl, username, password, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			String responseCode =  paymentResponse.getIslemSonucKodu();
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_KIRGAZ_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KIRGAZ_SEND_COLLECTION_CANCEL_MESSAGE");
		
		try{
			String invoiceNo = iMap.getString(MapKeys.INVOICE_NO);
			String paymentDate = CommonHelper.getShortDateTimeString(new Date());
			
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			PaymentResponse cancelPaymentResponse = KirgazClient.invoiceDebtPaymentCancel(invoiceNo, paymentDate, bankCode, serviceUrl, username, password, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			String responseCode =  cancelPaymentResponse.getIslemSonucKodu();
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_KIRGAZ_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KIRGAZ_COLLECTION_RECONCILIATION");
		
		try{
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String reconDate = null;
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
				reconDate= CommonHelper.getShortDateTimeString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			else
				reconDate = CommonHelper.getShortDateTimeString(new Date());
			
			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			
			GeneralReconResponse response = KirgazClient.reconciliationGeneral(reconDate, reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL), reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT), reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL), reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT), bankCode, serviceUrl, username, password, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			String responseCode =  response.getIslemSonucKodu();
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getGecerliTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getGecerliAdet());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getIptalTutar());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getIptalAdet());
			} else {
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, 0);
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0 && output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0) {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_KIRGAZ_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		ServiceMessage serviceMessage = new ServiceMessage();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_KIRGAZ_GET_COLLECTION_RECONCILIATION_DETAIL");
		
		try{
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String bankCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String reconLogOid = iMap.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			
			String reconDate = null;
			if (!StringUtil.isEmpty(iMap.getString(MapKeys.RECON_DATE)))
				reconDate= CommonHelper.getShortDateTimeString(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			else
				reconDate = CommonHelper.getShortDateTimeString(new Date());
			
			ArrayList<DetailReconResponse> detailReconResponseList = KirgazClient.reconciliationDetail(reconDate, bankCode, serviceUrl, username, password, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());
			
			int reconDetailCount = 0;
			GMMap reconCorpDetailMap = new GMMap();
			if (detailReconResponseList.size() > 0) {
				String responseCode = detailReconResponseList.get(0).getIslemSonucKodu();
				
				GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				output.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				output.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
				for (DetailReconResponse detailReconResponse : detailReconResponseList) {
					if (detailReconResponse.getDurum().equals("TAH")) {
						reconCorpDetailMap.put("CORPORATE", reconDetailCount, MapKeys.SUBSCRIBER_NO1, detailReconResponse.getAboneNo());
						reconCorpDetailMap.put("CORPORATE", reconDetailCount, MapKeys.PAYMENT_AMOUNT, detailReconResponse.getToplamTutar());
						reconDetailCount++;
					}
				}
			}

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_COUNT));
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			output.put("BANK", 0, MapKeys.TRX_NO, reconBankMap.get(MapKeys.TRX_NO));
			int bankCollectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int corporateCollectionCount = reconDetailCount;

			if (bankCollectionCount > corporateCollectionCount) {
				short collectionType = 0;
				for (int j = 0; j < bankCollectionCount; j++) {
					
					boolean found = false;
					for (int i = 0; i < corporateCollectionCount; i++) {
						if (reconCorpDetailMap.getSize("CORPORATE") > 0 && reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1).equals(reconCorpDetailMap.getString("CORPORATE", i, MapKeys.SUBSCRIBER_NO1))
								&& reconBankMap.getString("BANK", j, MapKeys.PAYMENT_AMOUNT).equals(reconCorpDetailMap.getString("CORPORATE", i, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", j, MapKeys.TRX_NO));
						request.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.INVOICE_NO, reconBankMap.getString("BANK", j, MapKeys.INVOICE_NO));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, request.getString(MapKeys.TRX_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, request.getBigDecimal(MapKeys.PAYMENT_AMOUNT));

						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);

						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							e.printStackTrace();
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ste�i Ba�ar�l� Olarak G�nderildi"));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);// Tahsilat
																																											// Mesaji
																																											// Gonderildi
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER4));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5, request.getString(MapKeys.PARAMETER5));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6, request.getString(MapKeys.PARAMETER6));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			} else {
				short collectionType = 0;
				for (int j = 0; j < corporateCollectionCount; j++) {
					
					boolean found = false;
					for (int k = 0; k < bankCollectionCount; k++) {
						if (reconCorpDetailMap.getSize("CORPORATE") > 0 && reconCorpDetailMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1).equals(reconBankMap.getString("BANK", k, MapKeys.SUBSCRIBER_NO1))
								&& reconCorpDetailMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT).equals(reconBankMap.getString("BANK", k, MapKeys.PAYMENT_AMOUNT))) {
							found = true;
							break;
						} else {
							found = false;
						}
					}
					if (!found) {
						// bulunamayan numara icin tahsilat iptal istegi gonder
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap request = new GMMap();
						request.put(MapKeys.CORPORATE_CODE, corporateCode);
						request.put(MapKeys.SUBSCRIBER_NO1, reconCorpDetailMap.getString("CORPORATE", j, MapKeys.SUBSCRIBER_NO1));
						request.put(MapKeys.PAYMENT_AMOUNT, reconCorpDetailMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						request.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
						request = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", request);
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, request.getString(MapKeys.INVOICE_AMOUNT));
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, request.getString(MapKeys.SUBSCRIBER_NO1));
						onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, request.getString(MapKeys.PAYMENT_DATE));
						onlineCorporateServiceCallInputMap.put(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON, "Mutabakat");

						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
						try {
							onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
						} catch (Exception e) {
							// Tahsilatta hata al�nca yakal�yoruz yola devam
							// ediyoruz
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
							onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
						}

						GMMap reconProcessDataLogInsertInputMap = new GMMap();
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
						}
						if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC).concat(" - ").concat(" Tahsilat �ptal �ste�i Ba�ar�l� Olarak G�nderildi"));
						}
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);

						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelCollectionMessageSent);
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,request.getString(MapKeys.SUBSCRIBER_NO1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, request.getBigDecimal(MapKeys.INSTALLMENT_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT, reconCorpDetailMap.getString("CORPORATE", j, MapKeys.PAYMENT_AMOUNT));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE, request.getString(MapKeys.INVOICE_DUE_DATE));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO, request.getString(MapKeys.INVOICE_NO));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, request.getString(MapKeys.PARAMETER1));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, request.getString(MapKeys.PARAMETER2));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3, request.getString(MapKeys.PARAMETER3));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4, request.getString(MapKeys.PARAMETER4));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5, request.getString(MapKeys.PARAMETER5));
						reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6, request.getString(MapKeys.PARAMETER6));
						CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
					}
				}
			}
		}
		catch(Exception e){
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally{
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			output.put("RESPONSE_XML", serviceMessage.getResponse());
			insertOnlineServiceLog(iMap, output);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_KIRGAZ_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap closeRecon(GMMap input) {
		GMMap output = new GMMap();
		input.put(MapKeys.WS_SERVICE_NAME, "ICS_KIRGAZ_COLLECTION_RECONCILIATION_CLOSED");
		try {
			String screenRecon = input.getString("SCREEN_RECONCILIATION", "");
			String reconDate = input.getString(MapKeys.RECON_DATE);
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			Session session = CommonHelper.getHibernateSession();
			if (screenRecon.equals("1")) {
				setCollectionInfoToOutput(output, reconDate, corporateCode, session);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		}
		catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		finally {
			insertOnlineServiceLog(input, output);
		}
		return output;
	}
}
