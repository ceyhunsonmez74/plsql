package tr.com.aktifbank.bnspr.corporation.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.batch.implementations.CollectionReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.EneryaReconciliationDetailBatch;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.client.EneryaClient;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.energaz.FICA.BorcSorgusu.DT_FICA_WS_KB_Res;
import com.energaz.FICA.BorcSorgusu.DT_FICA_WS_KB_ResOUTKBITEM;
import com.energaz.FICA.MutabakatOzet.DT_FICA_WS_BA_CHECK_Res;
import com.energaz.FICA.OtomatikOdemeTalimati.DT_FICA_WS_OOT_Res;
import com.energaz.FICA.Tahsilat.DT_FICA_WS_BK_Res;
import com.energaz.FICA.TersKayit.DT_FICA_WS_BKT_Res;
import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class EneryaServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(EneryaServices.class);

	public static final String TYPE = "1";
	public static final String BNKKD = "143";
	// public static final String BNODK = "06";
	public static final String TALIMAT_INSERT = "I";
	public static final String TALIMAT_DELETE = "D";

	@GraymoundService("ICS_ENERYA_INVOICE_DEBT_INQUIRY")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ENERYA_INVOICE_DEBT_INQUIRY");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		try {
			// parameters are taken
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String BUKRS = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String VKONT = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			if (VKONT.length() < 12) {
				VKONT = String.format("%012d", Long.valueOf(VKONT));
			}
			// logger info will be logged
			builder.append(" ICS_ENERYA_INVOICE_DEBT_INQUIRY is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Musteri No -> ");
			builder.append(VKONT);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | URL -> ");
			builder.append(url);
			logger.info(builder.toString());

			logger.info("ICS_ENERYA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EneryaClient.borcSorgusu(...) will be called..."));
			ServiceMessage sm = new ServiceMessage();
			DT_FICA_WS_KB_Res response = EneryaClient.borcSorgusu(username, password, url, BUKRS, BNKKD, VKONT, TYPE, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());
			logger.info("ICS_ENERYA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EneryaClient.borcSorgusu(...) is called..."));

			logger.info("ICS_ENERYA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EneryaClient.borcSorgusu(...) returned response code ".concat(response.getRETURN())));
			GMMap responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			logger.info("ICS_ENERYA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EneryaClient.borcSorgusu(...) returned errorCode ".concat(errorCode)));
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				for (DT_FICA_WS_KB_ResOUTKBITEM borc : response.getOUTKB()) {
					if (!isCollectedInvoice(borc.getMATBU(), VKONT, "", "", "", corporateCode)) {

						Date faturaTarihi = CommonHelper.getDateTime(borc.getBUDAT(), "yyyy-MM-dd");
						Calendar cal = Calendar.getInstance();
						cal.setTime(faturaTarihi);
						String invoiceDueDate = CommonHelper.getDateString(CommonHelper.getDateTime(borc.getBUDAT(), "yyyy-MM-dd"), "yyyyMMdd");

						String billingAmount = borc.getTOTAL_AMNT().replace(",", ".");
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, VKONT);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getMATBU());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, billingAmount);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAD());
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, invoiceDueDate);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, cal.get(Calendar.YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, String.format("%02d", cal.get(Calendar.MONTH) + 1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, iMap.getString(MapKeys.COLLECTION_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, billingAmount);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getBUDAT());
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			logger.info("ICS_ENERYA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - EneryaClient.borcSorgusu(...) finished succesfully"));
		} catch (Throwable e2) {
			logger.error("ICS_ENERYA_INVOICE_DEBT_INQUIRY for ".concat(corporateCode).concat(" - an error is occured "));
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ENERYA_DO_INVOICE_COLLECTION")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ENERYA_DO_INVOICE_COLLECTION");
		GMMap responceCodeMap = new GMMap();
		try {
			// parameters are taken
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String BUKRS = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String VKONT = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String MATBU = iMap.getString(MapKeys.INVOICE_NO);
			// String BUDAT = iMap.getString(MapKeys.PARAMETER1);

			String p_sIslemReferansNo = iMap.getString(MapKeys.TRX_NO);
			boolean isStandingOrderCollection = iMap.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION, false);
			String tahsilatTarihi = "";

			if (!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))) {
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "yyyy-MM-dd");
			} else {
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}

			StringBuilder builder = new StringBuilder();
			builder.append(" ICS_ENERYA_DO_INVOICE_COLLECTION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | ��lem Referans No -> ");
			builder.append(p_sIslemReferansNo);
			builder.append(" | VKONT -> ");
			builder.append(VKONT);
			builder.append(" | Tahsilat Tarihi -> ");
			builder.append(tahsilatTarihi);
			logger.info(builder.toString());

			if (isStandingOrderCollection) {
				logger.info("ICS_ENERYA_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - EneryaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:true"));
			} else {
				logger.info("ICS_ENERYA_DO_INVOICE_COLLECTION for ".concat(corporateCode).concat(" - EneryaClient.tahsilat(...) before call..").concat("isStandingOrderCollection:false"));
			}
			String sourceCode = iMap.getString(MapKeys.SOURCE);
			String channelCode = CommonHelper.getChannelId();
			Short collectionType = Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE));
			String paymentChannel = "";
			try {
				paymentChannel = getCorporateChannel(corporateCode, sourceCode, channelCode, collectionType);
			} catch (Exception e) {
				paymentChannel = "06";
			}
			if (paymentChannel == null) {
				paymentChannel = "06";
			}
			ServiceMessage sm = new ServiceMessage();
			DT_FICA_WS_BK_Res response = EneryaClient.tahsilat(username, password, url, tahsilatTarihi, VKONT, MATBU, BUKRS, BNKKD, paymentChannel, "", "", sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());

			responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			logger.info("ICS_ENERYA_DO_INVOICE_COLLECTION FOR ".concat(corporateCode).concat(" - EneryaClient.tahsilat(...) returned errorCode ".concat(response.getRETURN())));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ENERYA_SEND_COLLECTION_CANCEL_MESSAGE")
	public static GMMap sendCollectionCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ENERYA_SEND_COLLECTION_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String BUKRS = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String MATBU = iMap.getString(MapKeys.INVOICE_NO);
			String BUDAT = CommonHelper.getDateString(new Date(), "yyyy-MM-dd"); // tahsilat
																					// yapilan
																					// gunden
																					// 15
																					// gun
																					// sonrasina
																					// kada
																					// iptal
																					// edilebilir

			String VKONT = iMap.getString("SUBSCRIBER_NO_1", null);
			if (VKONT == null) {
				VKONT = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			}

			builder.append(" ICS_ENERYA_SEND_COLLECTION_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | url -> ");
			builder.append(url);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			DT_FICA_WS_BKT_Res response = EneryaClient.tersKayit(username, password, url, BUDAT, VKONT, MATBU, BUKRS, BNKKD, "", "", "01", sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());

			logger.info("ICS_ENERYA_SEND_COLLECTION_CANCEL_MESSAGE FOR ".concat(corporateCode).concat(" - iptal gonderildi"));
			logger.info("ICS_ENERYA_SEND_COLLECTION_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response.get_return()));

			GMMap responceCodeMap = getResponseCodeMapping(response.get_return(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, response.getRETURNTEXT());
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}

	@GraymoundService("ICS_ENERYA_COLLECTION_RECONCILIATION")
	public static GMMap collectionReconciliation(GMMap iMap) {
		GMMap output = new GMMap();
		StringBuilder builder = new StringBuilder();
		try {
			iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ENERYA_COLLECTION_RECONCILIATION");

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String BUKRS = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String mutabakatSonlandirmaURL = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2).concat(iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3));
			Date reconDate = CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd");
			String baslangicTarihi = CommonHelper.getDateString(reconDate, "yyyy-MM-dd");

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);

			BigDecimal collectionTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL);
			BigDecimal cancelTotal = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL);
			int collectionCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_COUNT);
			int cancelCount = reconBankMap.getInt(MapKeys.RECON_COLLECTION_CANCEL_COUNT);

			output.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, collectionTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelTotal);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, collectionCount);
			output.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, cancelCount);

			builder.append(" ICS_ENERYA_COLLECTION_RECONCILIATION is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | username -> ");
			builder.append(username);
			builder.append(" | password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			DT_FICA_WS_BA_CHECK_Res response = EneryaClient.mutabakatOzet(username, password, url, BUKRS, BNKKD, String.valueOf(collectionTotal.add(cancelTotal)), String.valueOf(collectionCount + cancelCount), String.valueOf(cancelTotal), String.valueOf(cancelCount), baslangicTarihi, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());

			if (response == null) {
				// tahsilat yok ya da hata var sayilari 0 a esitle
				logger.info("ICS_ENERYA_COLLECTION_RECONCILIATION - result size 0 geldi");

				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, new BigDecimal(0));
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, 0);
			} else {
				// aldigin sayilari koy
				logger.info("ICS_ENERYA_COLLECTION_RECONCILIATION - response.getBgsTahsilIcmalDto() null degil");
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, response.getSUM());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getCOUNT());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, response.getREV_SUM());
				output.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, response.getREV_COUNT());
			}

			if (output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_COUNT)
					&& output.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(output.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0 && output.getInt("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT) == output.getInt("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) {
				// mutabakat basarili o zaman kapatalim
				logger.info("ICS_ENERYA_COLLECTION_RECONCILIATION - mutabakat basarili o zaman kapatilacak ");
				EneryaClient.mutabakatSonlandirma(username, password, mutabakatSonlandirmaURL, BUKRS, BNKKD, baslangicTarihi, sm);
				iMap.put("REQUEST_TMY_XML", sm.getRequest());
				output.put("RESPONSE_TMY_XML", sm.getResponse());
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);

			} else {
				output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e) {
			logger.info("ICS_ENERYA_COLLECTION_RECONCILIATION - mutabakat hatali ");
			output.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_ENERYA_GET_COLLECTION_RECONCILIATION_DETAIL")
	public static GMMap collectionReconciliationDetail(GMMap iMap) {
		GMMap output = new GMMap();
		logger.info("ICS_ENERYA_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat calisti.. ");
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ENERYA_GET_COLLECTION_RECONCILIATION_DETAIL");
		try {

			ServiceMessage sm = new ServiceMessage();
			CollectionReconciliationDetailBatch batch = new EneryaReconciliationDetailBatch(iMap, sm);
			output = batch.runBatch();
			iMap.put("REQUEST_XML", sm.getRequest());
			output.put("RESPONSE_XML", sm.getResponse());

		} catch (Throwable e) {
			logger.info("ICS_ENERYA_GET_COLLECTION_RECONCILIATION_DETAIL - detay mutabakat hata aldi.. ");
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("ICS_ENERYA_COLLECTION_RECONCILIATION_CLOSED")
	public static GMMap collectionReconciliationClosed(GMMap iMap) {
		GMMap output = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ENERYA_COLLECTION_RECONCILIATION_CLOSED");
		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, output);
		}
		return output;
	}

	@GraymoundService("STO_ENERYA_SEND_STANDING_ORDER_MESSAGE")
	public static GMMap sendStandingOrderMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ENERYA_SEND_STANDING_ORDER_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String hataMesaji = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String BUKRS = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String VKONT = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			builder.append(" STO_ENERYA_SEND_STANDING_ORDER_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | Abone No -> ");
			builder.append(VKONT);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			DT_FICA_WS_OOT_Res response = EneryaClient.otomatikOdemeTalimati(username, password, url, BUKRS, VKONT, BNKKD, TALIMAT_INSERT, "", "", sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());

			logger.info("STO_ENERYA_SEND_STANDING_ORDER_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response.getRETURN()));

			GMMap responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_ENERYA_SEND_STANDING_ORDER_MESSAGE -> error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("STO_ENERYA_SEND_STANDING_ORDER_CANCEL_MESSAGE")
	public static GMMap sendStandingOrderCancelMessage(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "STO_ENERYA_SEND_STANDING_ORDER_CANCEL_MESSAGE");
		GMMap outMap = new GMMap();
		StringBuilder builder = new StringBuilder();
		String hataMesaji = "";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String BUKRS = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String VKONT = iMap.getString(MapKeys.SUBSCRIBER_NO1);

			builder.append(" STO_ENERYA_SEND_STANDING_ORDER_CANCEL_MESSAGE is called for ".concat(corporateCode).concat(" with parameters -> "));
			builder.append(" | �sletme Kodu -> ");
			builder.append(VKONT);
			builder.append(" | UserName -> ");
			builder.append(username);
			builder.append(" | Password -> ");
			builder.append(password);
			builder.append(" | End Point -> ");
			builder.append(url);
			logger.info(builder.toString());

			ServiceMessage sm = new ServiceMessage();
			DT_FICA_WS_OOT_Res response = EneryaClient.otomatikOdemeTalimati(username, password, url, BUKRS, VKONT, BNKKD, TALIMAT_DELETE, "", "", sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());

			logger.info("STO_ENERYA_SEND_STANDING_ORDER_CANCEL_MESSAGE for ".concat(corporateCode).concat(" - ").concat(" and returned response code -> ").concat(response.getRETURN()));
			GMMap responceCodeMap = getResponseCodeMapping(response.getRETURN(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Throwable e2) {
			logger.info("STO_ENERYA_SEND_STANDING_ORDER_CANCEL_MESSAGE an error occured...");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, hataMesaji);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e2));
			throw ExceptionHandler.convertException(e2);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_ENERYA_DEBT_INQUERY_FOR_STANDING_ORDER")
	public static GMMap getdebtQueryForStandingOrder(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_ENERYA_DEBT_INQUERY_FOR_STANDING_ORDER");
		GMMap outMap = new GMMap();
		String responseCode = "1";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			GMMap rcInput = new GMMap();
			rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE, iMap.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));

			GMMap listMap = CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput);
			int counter = 0;
			@SuppressWarnings("unchecked")
			List<icsStandingOrders> bankStandingOrderList = (List<icsStandingOrders>) listMap.get("LIST_ACTIVE");

			GMMap debtLoadingMap = new GMMap();
			int bankStandingOrderListLenght = bankStandingOrderList.size();

			for (int i = 0; i < bankStandingOrderListLenght; i++) {
				icsStandingOrders icsStandingOrder = bankStandingOrderList.get(i);

				iMap.put(MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				debtLoadingMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_ENERYA_INVOICE_DEBT_INQUIRY", iMap);
				String errorCode = debtLoadingMap.getString(MapKeys.ERROR_CODE);

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					int invoiceListeLenght = debtLoadingMap.getSize("INVOICES");
					for (int j = 0; j < invoiceListeLenght; j++) {
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NO1));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_NO));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, debtLoadingMap.getString("INVOICES", j, MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, debtLoadingMap.getString("INVOICES", j, MapKeys.SUBSCRIBER_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, corporateCode);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_DUE_DATE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_YEAR, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_TERM_YEAR));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.TERM_MONTH, debtLoadingMap.getString("INVOICES", j, MapKeys.INVOICE_TERM_MONTH));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_TYPE, debtLoadingMap.getString("INVOICES", j, MapKeys.COLLECTION_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, debtLoadingMap.getString("INVOICES", j, MapKeys.PAYMENT_TYPE));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, debtLoadingMap.getString("INVOICES", j, MapKeys.PAYMENT_TYPE_NAME));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, debtLoadingMap.getString("INVOICES", j, MapKeys.AMOUNT));
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
						outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, debtLoadingMap.getString("INVOICES", j, MapKeys.PARAMETER1));
						outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
						outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
						counter++;
					}
				}
			}
			outMap.put(MapKeys.TABLE_SIZE, counter);
			outMap.put(MapKeys.RESPONSE_CODE, responseCode);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "Onay");
		} catch (Exception e2) {
			logger.error("An exception occured while executing ICS_ENERYA_DEBT_INQUERY_FOR_STANDING_ORDER");
			logger.error(System.currentTimeMillis(), e2);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
}
