package tr.com.aktifbank.bnspr.moneyload;

import i_OTM.EndofDayRequestItem;
import i_OTM.EndofDayResultItem;
import i_OTM.GetProvisionResult;
import i_OTM.PackageInquiryResult;
import i_OTM.TerminalEndOfDayResult;
import i_OTM.TopupResult;
import i_OTM._package;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.TimeZone;
import java.util.TreeMap;

import model.br.turkcell.com.PayConfirmResponse;
import model.br.turkcell.com.PrepQueryResponse;
import model.br.turkcell.com.ReconsQueryResponse;
import model.ppgw.turkcell.com.GetProductsResponse;
import model.ppgw.turkcell.com.Product;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.corporation.services.OnlineCorporationInterface;
import tr.com.aktifbank.bnspr.corporation.services.OnlineInstitutionConstants;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.AveaCommonServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.AveaDebtInqueryServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.AveaDoInvoiceCollectionServices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.AveaReconService;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.VodafoneDebtInqueryServices;
import tr.com.aktifbank.bnspr.cps.transactions.DoGSMMoneyLoad;
import tr.com.aktifbank.bnspr.cps.transactions.InsertMoneyLoadLogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.CorporateTlinstallment;
import tr.com.aktifbank.integration.client.AveaClient;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.aktifbank.integration.client.TurkcellClient;
import tr.com.aktifbank.integration.client.VodafoneClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.OnlineAgreementServiceInput;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.OnlineAgreementServiceRequest;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.OnlineAgreementServiceResponse;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.TopupConfirmationInput;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.TopupConfirmationRequest;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.TopupConfirmationResponse;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.TopupQueryInput;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.TopupQueryRequest;
import tr.com.vodafone.www.etopup.ws.topup.schemas.messages.TopupQueryResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OperatorServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(OperatorServices.class);
	private static final String PAYMENT_SOURCE_KASA = "0";
	private static final String PAYMENT_SOURCE = "K1"; // Gise
	private static short COLLECTION_TYPE = Short.parseShort("1");

	private static final int TURKCELL_APPL_CODE = 1;
	private static final String TURKCELL_APPL_CODE_STRING = "001";
	private static final int TURKCELL_CURRENCY_CODE = 99;
	private static final String TURKCELL_CURRENCY_CODE_STRING = "99";
	private static final int TURKCELL_PRODUCT_TYPE = 1;
	private static final int TURKCELL_PRODUCT_TYPE_NAR = 7;
	// private static final int TURKCELL_ORDER_TYPE = 1; // duzenli TL yukleme
	// Talimati
	private static final String TURKCELL_PACKAGE_TYPE_D = "D"; // Diger banka
																// vadesiz hesap
	private static final String TURKCELL_PACKAGE_TYPE_N = "N"; // Nakit
	private static final String TURKCELL_DIST_CODE = "0"; // POS harici cihazlar
															// icin 0 olacak
	private static final String TURKCELL_TAM_MERCHANT_CODE = "0"; // POS harici
																	// cihazlar
																	// icin 0
																	// olacak
	private static final String TURKCELL_TAN_MERCHANT_CODE = "0"; // POS harici
																	// cihazlar
																	// icin 0
																	// olacak
	private static final String TURKCELL_MSISDN_NOT_FOUND_ERROR = "TL01"; // Turkcell
																			// Abone
																			// bulunamadi
																			// hatasi
																			// mesaj�
	private static final String GATEWAY_ERROR = "GWERR";
	private static final String AVEA_INSTITUTION_ID = "1143";
	private static final int AVEA_CURRENCY_CODE = 949;
	private static final int AVEA_CUSTOMER_ACCESS_TYPE = 1;
	private static final String AVEA_LANGUAGE_CODE = "tr-TR";
	private static final int AVEA_UTILITY_COMPANY_CODE = 555;
	private static final int AVEA_PAYMENT_TYPE = 0; // Gise
	private static final int AVEA_OPERATION_CODE = 730; // TL yukleme

	private static final int VODAFONE_REF_CODE_TYPE = 1; // refCode olarak
															// MSISDN
															// gonderilecegini
															// belirtir
	private static final int VODAFONE_AMOUNT_TYPE = 1; // 1 TL, 2 Kontor u ifade
														// eder
	private static final BigInteger VODAFONE_PAYMENT_CHANNEL = new BigInteger("1"); // Nakit
	private static final BigInteger VODAFONE_REQUEST_CHANNEL = new BigInteger("5"); // Kasa
	private static final String VODAFONE_POINT_OF_SALE = "1"; // satis kanali
																// bazinda
																// kirilim
																// istenmediginden
																// sabit
																// degerler
																// girilecek
	private static final int VODAFONE_POINT_OF_SALE_CITY_PLATE_CODE = 34; // satis
																			// kanali
																			// bazinda
																			// kirilim
																			// istenmediginden
																			// sabit
																			// degerler
																			// girilecek

	// Turkcell Services start
	@GraymoundService("ICS_TURKCELL_MONEY_LOAD_GET_PRODUCTS")
	public static GMMap getTurkcellSubscriberProducts(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_MONEY_LOAD_GET_PRODUCTS");
		GMMap outMap = new GMMap();
		String tableName = BnsprCommonFunctions.getTableName(iMap);
		try {
			String msisdn = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(msisdn) && msisdn.length() == 10) {

				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
				String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String bank = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				long companyId = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
				String stan = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString("TRX_NO");
				stan = stan.substring(stan.length() - 6, stan.length());// turkcell
																		// tarafinda
																		// 6
																		// karakter
																		// sinirindan
																		// dolayi
																		// son 6
																		// basamagini
																		// gonderiyoruz

				ServiceMessage sm = new ServiceMessage();
				List<Product> products = new ArrayList<Product>();

				GetProductsResponse response = TurkcellClient.getProducts(wsUrl, password, Integer.parseInt(stan), userName, TURKCELL_APPL_CODE, bank, companyId, TURKCELL_CURRENCY_CODE, Long.valueOf(msisdn), TURKCELL_PRODUCT_TYPE, sm);
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());

				GetProductsResponse responseNar = TurkcellClient.getProducts(wsUrl, password, Integer.parseInt(stan), userName, TURKCELL_APPL_CODE, bank, companyId, TURKCELL_CURRENCY_CODE, Long.valueOf(msisdn), TURKCELL_PRODUCT_TYPE_NAR, sm);

				String returnCode = "TL" + response.getReturnCode();
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(returnCode, null, corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				iMap.put("REQUEST_XML_NAR", sm.getRequest());
				outMap.put("RESPONSE_XML_NAR", sm.getResponse());

				// paket listesi basarili bir sekilde donerse akisa devam edilir
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

					for (Product p : response.getProducts())
						products.add(p);

					for (Product p : responseNar.getProducts())
						products.add(p);

					// siralama icin treemap de sort ediyoruz
					HashMap<Integer, String> packageList = new HashMap<Integer, String>();
					int counter = 0;
					for (Product p : products) {
						if (p.getPaymentType().equals(TURKCELL_PACKAGE_TYPE_D) || p.getPaymentType().equals(TURKCELL_PACKAGE_TYPE_N)) {
							if (!packageList.containsKey(p.getPackageId())) {
								packageList.put(p.getPackageId(), p.getPackageId() + "|" + p.getPackageName());
								outMap.put(tableName, counter, "AMOUNT", p.getPrice());
								outMap.put(tableName, counter, "DESCRIPTION", p.getPackageName() + " - " + Math.round(p.getPrice()) + " TL");
								outMap.put(tableName, counter, "LOAD_AMOUNT", p.getPrice());
								outMap.put(tableName, counter, "OBJECT", p.getPackageId());
								counter++;

								GuimlUtil.wrapMyCombo(outMap, "PACKAGES", p.getPackageId() + "|" + p.getPrice(), p.getPackageName() + " - " + Math.round(p.getPrice()) + " TL");
							}
						}
					}
				}
			} else {
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(TURKCELL_MSISDN_NOT_FOUND_ERROR, null, corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_PAY_MONEY_LOAD_AMOUNT")
	public static GMMap payTurkcellMoneyLoadAmount(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_PAY_MONEY_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		String msisdn;
		ServiceMessage sm = new ServiceMessage();
		try {
			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && iMap.getString(MapKeys.SUBSCRIBER_NO1).length() == 10) {
				msisdn = iMap.getString(MapKeys.SUBSCRIBER_NO1);

				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
				String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String bank = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				String companyId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
				String stan = "000000";
				String moneyLoadPaymentSource="GI";
				String paymentType = "V";
				if (iMap.containsKey("WITH_OUT_ACCOUNTING_SERVICE")) {
					if (iMap.getBoolean("WITH_OUT_ACCOUNTING_SERVICE")) {
						paymentType = iMap.getString("SOURCE").equals(PAYMENT_SOURCE_KASA) ? TURKCELL_PACKAGE_TYPE_D : TURKCELL_PACKAGE_TYPE_N;
						moneyLoadPaymentSource="NC";
						userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
						password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
						bank = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
						companyId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
						stan = getStanNo();
						if (stan.length() < 6) {
							stan = CommonHelper.fillCharacters(stan, "0", 6, true);
						} else {
							stan = stan.substring(stan.length() - 6, stan.length());
						}
						outMap.put(MapKeys.TRX_NO, stan);
					}
				} else {
					stan = iMap.getString(MapKeys.TRX_NO);
					stan = stan.substring(stan.length() - 6, stan.length());
				}
				Date date = new Date();
				String transDate = CommonHelper.getDateString(date, "yyyyMMdd");
				String transTime = CommonHelper.getDateString(date, "HHmmss");
				String returnCode = "00";
				String transPrice = iMap.getString("PAYMENT_AMOUNT");
				String packageId = iMap.getString("OBJECT");
				transPrice = formatTurkcellPrice(Double.parseDouble(transPrice));
				
				PrepQueryResponse prepQueryResponse = TurkcellClient.preQuery(wsUrl, msisdn, bank, companyId, String.valueOf(TURKCELL_CURRENCY_CODE), TURKCELL_DIST_CODE, password, transDate, returnCode, TURKCELL_TAM_MERCHANT_CODE, TURKCELL_TAN_MERCHANT_CODE, packageId, transDate, paymentType, transPrice, moneyLoadPaymentSource, transTime, stan, userName, sm);
				returnCode = "TL" + prepQueryResponse.getReturnCode();

				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(returnCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());

				// yukleme oncesi onay adimlari basarili olursa TL yuklemeye
				// devam edilir
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					PayConfirmResponse payResponse = TurkcellClient.payConfirm(wsUrl, msisdn, bank, companyId, password, prepQueryResponse.getReturnCode(), transDate, stan, userName, sm);
					returnCode = "TL" + payResponse.getReturnCode();
					responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(returnCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					// yukleme islemi ok olursa ekran da gosterilecek mesajlar
					// bu servisi cagiran yerde set edilir
					outMap.put("STATUS_CODE", responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put("STATUS_DESC", responceCodeMap.getString(MapKeys.ERROR_DESC));
					if (iMap.containsKey("WITH_OUT_ACCOUNTING_SERVICE")) {
						if (iMap.getBoolean("WITH_OUT_ACCOUNTING_SERVICE")) {
						} else {
							outMap.put("TRX_NO", iMap.getString(MapKeys.TRX_NO));
						}
					} else {
						outMap.put("TRX_NO", iMap.getString(MapKeys.TRX_NO));
					}
					iMap.put("REQUEST_XML", sm.getRequest());
					outMap.put("RESPONSE_XML", sm.getResponse());
				}
			} else {
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(TURKCELL_MSISDN_NOT_FOUND_ERROR, null, iMap.getString(MapKeys.CORPORATE_CODE));
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_MONEY_LOAD_RECONCILIATION")
	public static GMMap makeTurkcellMoneyLoadReconciliation(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_MONEY_LOAD_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			// banka tarafindaki toplam degerleri aliriz
			
			// Operator tarafinda sorguyu cagiririz
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String bank = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String companyId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String reconsDate = iMap.getString(MapKeys.RECON_DATE); // format
																	// should be
																	// YYYYMMDD
			String returnCode = "00";
			String totalTransAmt="";
			String transCounter="";
			
			ServiceMessage sm = new ServiceMessage();
			ReconsQueryResponse response = null;

			if (iMap.containsKey("WITH_OUT_ACCOUNTING_SERVICE")) {
				if (iMap.getBoolean("WITH_OUT_ACCOUNTING_SERVICE")) {
					totalTransAmt=formatTurkcellPrice(Double.valueOf(iMap.getString("TOTAL_AMOUNT")));
					transCounter=String.valueOf(Integer.valueOf(iMap.getString("TOTAL_COUNT")));
					userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
					password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
					bank = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
					companyId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
					response = TurkcellClient.reconsQuery(wsUrl, TURKCELL_APPL_CODE_STRING, bank, companyId, TURKCELL_CURRENCY_CODE_STRING, password, reconsDate, returnCode, totalTransAmt, transCounter, userName, sm);
					if(response!=null){
					returnCode = response.getReturnCode();
					}
					GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(returnCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
					iMap.put("REQUEST_XML", sm.getRequest());
					outMap.put("RESPONSE_XML", sm.getResponse());
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					}else{
						outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					}
					outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
					outMap.put(MapKeys.ERROR_DESC, "");
					outMap.put("STATUS_CODE", returnCode);
					outMap.put("STATUS_DESC", responceCodeMap.getString(MapKeys.ERROR_DESC));
				}
			}
			else {
				outMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_CALCULATE_RECONCILIATION_RECORDS", iMap);
				int operationCount = Integer.valueOf(outMap.getString("COUNT"));
				double operationTotalAmount = Double.valueOf(outMap.getString("TOTAL_AMOUNT"));
				iMap.put("COUNT", operationCount);
				iMap.put("TOTAL_AMOUNT", operationTotalAmount);
				totalTransAmt = formatTurkcellPrice(operationTotalAmount);
				transCounter = String.valueOf(operationCount);
				
				response = TurkcellClient.reconsQuery(wsUrl, TURKCELL_APPL_CODE_STRING, bank, companyId, TURKCELL_CURRENCY_CODE_STRING, password, reconsDate, returnCode, totalTransAmt, transCounter, userName, sm);
				returnCode = "TL" + response.getReturnCode();
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(returnCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());

				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
				}
				else {

					Double corpTotal = new Double("0");
					try {
						corpTotal = Double.valueOf(response.getTotalTransectionAmount()) / 100;
					}
					catch (Exception e) {
					}

					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, corpTotal);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, response.getTransactionCounter());
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
					outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
					outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				}
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_MONEY_LOAD_RECONCILIATION_DETAIL")
	public static GMMap makeTurkcellMoneyLoadReconsiliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_MONEY_LOAD_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		try {
			logger.info("ICS_TURKCELL_MONEY_LOAD_RECONCILIATION_DETAIL is called");
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.Continues);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("ICS_TURKCELL_MONEY_LOAD_RECONCILIATION_DETAIL finished succesfully");
		return outMap;
	}

	@GraymoundService("ICS_TURKCELL_MONEY_LOAD_RECONCILIATION_CLOSED")
	public static GMMap makeTurkcellMoneyLoadReconsiliationClose(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_MONEY_LOAD_RECONCILIATION_CLOSED");

		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		logger.info("ICS_TURKCELL_MONEY_LOAD_RECONCILIATION_CLOSED finished succesfully");
		return output;
	}

	// Avea Services start
	@SuppressWarnings("deprecation")
	@GraymoundService("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS")
	public static GMMap getAveaSubscriberProducts(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_MONEY_LOAD_GET_PRODUCTS");
		GMMap outMap = new GMMap();
		String tableName = BnsprCommonFunctions.getTableName(iMap);
		try {
			String msisdn = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(msisdn) && msisdn.length() == 10) {

				String channelCode = CommonHelper.getChannelId();
				String isCampaignChannel = CommonHelper.getValueOfParameter("AVEA_GATEWAY_CHANNEL_MAPPING", channelCode);
				if ("EVET".equals(isCampaignChannel)) {
					String responseCode = "";
					String gatewayErrorDesc = "";

					String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);// 34
					String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);// 104
					String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);// 12
					String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);// CS1002
					int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);// 1
					int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);// 24
					String institutionId = AVEA_INSTITUTION_ID;// 1143
					int currencyCode = AVEA_CURRENCY_CODE;// 949
					int sunCustomerAccessType = AVEA_CUSTOMER_ACCESS_TYPE;// 1
					String sunCustomerAccessNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
					int operationSource = AVEA_PAYMENT_TYPE;

					GMMap inputMap = new GMMap();
					GMMap returnMap = new GMMap();

					inputMap.put(AveaDebtInqueryServices.Input.OPERATION_SOURCE, Integer.toString(operationSource)); // P-25
					inputMap.put(AveaDebtInqueryServices.Input.INSTITUTION_ID, institutionId);
					inputMap.put(AveaDebtInqueryServices.Input.CURRENCY_CODE, currencyCode);// P-49
					inputMap.put(AveaDebtInqueryServices.Input.SUN, 0, AveaDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_TYPE, sunCustomerAccessType);// P-60
					inputMap.put(AveaDebtInqueryServices.Input.SUN, 0, AveaDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_NO, sunCustomerAccessNo);// P-60

					inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
					inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
					inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
					inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44

					inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, Integer.toString(corporationId));
					inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, Integer.toString(operationCodeId));
					// asagidaki 3 satir canliya giderken silinecek
					// logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT will get FTM connection...");
					// GMConnection gmConnection =
					// GMConnection.getConnection("GW_CON");
					// logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT got FTM connection successfully...");
					// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",
					// inputMap));
					// asagidaki satir canliya giderken acilacak
					returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
					logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS is called BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE connection successfully...");
					// check if an error is occured on GW
					if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
						if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
							responseCode = GATEWAY_ERROR;
							logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
							logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
							gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
						} else {
							responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
							logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
						}
					} else {
						responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
						logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
					}

					GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					try {
						if (returnMap.containsKey("SERVER_STAN")) {
							String serverStan = returnMap.getString("SERVER_STAN");
							String stan = returnMap.getString("STAN");
							if (Integer.parseInt(stan) == Integer.parseInt(serverStan)) {
							} else {
								responceCodeMap = getResponseCodeMapping(GATEWAY_ERROR, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
								errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
								outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
								outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
								outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
								logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS -> TIMEOUT -> Gateway timeout problemi meydana geldi... STAN degerleri ayni degil ");
							}
						}
					} catch (Exception e) {
						logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS -> an error occured when comparing STAN values..");
					}
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						int counter = 0;

						for (int i = 0; i < returnMap.getSize("NORMAL_CUT_INFORMATION"); i++) {
							String formattedAmount = CommonHelper.trimStart(returnMap.getString("NORMAL_CUT_INFORMATION", i, "NORMAL_CUT_INFORMATION_UNIT"), '0');
							formattedAmount = formattedAmount.substring(0, formattedAmount.length() - 2).concat(".".concat(formattedAmount.substring(formattedAmount.length() - 2, formattedAmount.length())));
							outMap.put(tableName, counter, "AMOUNT", formattedAmount);
							outMap.put(tableName, counter, "PACKAGE_ID", returnMap.getString("NORMAL_CUT_INFORMATION", i, "NORMAL_CUT_INFORMATION_UNIT"));
							outMap.put(tableName, counter, "DESCRIPTION", formattedAmount.concat(" TL"));
							outMap.put(tableName, counter, "LOAD_AMOUNT", returnMap.getString("NORMAL_CUT_INFORMATION", i, "NORMAL_CUT_INFORMATION_UNIT"));
							GuimlUtil.wrapMyCombo(outMap, "PACKAGES", returnMap.getString("NORMAL_CUT_INFORMATION", i, "NORMAL_CUT_INFORMATION_UNIT").concat("|").concat(formattedAmount.substring(0, formattedAmount.length() - 3)), formattedAmount.concat(" TL"));
							counter++;
						}
					} else {
						// an error occured
						logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS an error accoured with error code : ".concat(errorCode));
						logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS an error accoured with response code : ".concat(responseCode));
						logger.info("ICS_AVEA_MONEY_LOAD_GET_PRODUCTS an error accoured returnMap : ".concat(returnMap.toString()));
						logger.info(responceCodeMap.getString(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM));
					}
				} else {

					String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
					String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
					String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);

					SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					// Convert Local Time to UTC (Works Fine)
					sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
					Calendar c1 = Calendar.getInstance();
					c1.setTime(new Date(sdf.format(new Date())));

					ServiceMessage sm = new ServiceMessage();
					// paket sorgulamak icin provisionId alinir oncesinde
					GetProvisionResult provResult = AveaClient.getProvision(wsUrl, userName, password, c1, AVEA_UTILITY_COMPANY_CODE, sm);
					GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(provResult.getResponseCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					iMap.put("REQUEST_XML", sm.getRequest());
					outMap.put("RESPONSE_XML", sm.getResponse());

					// basarili bir sekilde provisyon ID alinir ise akisa devam
					// eder
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						PackageInquiryResult result = AveaClient.packageInquiry(wsUrl, userName, password, c1, provResult.getProvisionId(), msisdn, AVEA_CUSTOMER_ACCESS_TYPE, AVEA_LANGUAGE_CODE, sm);

						responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(result.getResponseCode(), null, corporateCode);
						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
						iMap.put("REQUEST_XML", sm.getRequest());
						outMap.put("RESPONSE_XML", sm.getResponse());

						// abone ve paket bulunur ise akisa devam eder
						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							// siralama icin treemap de sort ediyoruz
							HashMap<Double, String> packageList = new HashMap<Double, String>();
							int counter = 0;
							for (_package p : result.getPackages()) {
								Double amount = ((double) p.getAmount() / 100);// 1999
																				// olarak
																				// gelen
																				// 20
																				// TL
																				// lik
																				// paketin
																				// tutarini
																				// hesapliyoruz
								if (!packageList.containsKey(amount)) {
									packageList.put(amount, amount + "|" + p.getPackageDescription());
									outMap.put(tableName, counter, "AMOUNT", amount);
									outMap.put(tableName, counter, "DESCRIPTION", p.getPackageDescription());
									outMap.put(tableName, counter, "LOAD_AMOUNT", amount);
									// outMap.put(tableName, counter, "OBJECT",
									// p);
									counter++;
								}
							}
							TreeMap<Double, String> sorted_map = new TreeMap<Double, String>(packageList);
							for (Entry<Double, String> m : sorted_map.entrySet()) {
								String pId = m.getValue().split("[|]")[0];
								String pName = m.getValue().split("[|]")[1];
								GuimlUtil.wrapMyCombo(outMap, "PACKAGES", pId + "|" + m.getKey(), pName + " - " + m.getKey());
							}
						}
					}
				}
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@SuppressWarnings("deprecation")
	@GraymoundService("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT")
	public static GMMap payAveaMoneyLoadAmount(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_PAY_MONEY_LOAD_AMOUNT");
		GMMap inputMap = new GMMap();
		GMMap outMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		try {
			String msisdn = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String referenceInfoStan = "";
			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && iMap.getString(MapKeys.SUBSCRIBER_NO1).length() == 10) {

				String channelCode = CommonHelper.getChannelId();
				String isCampaignChannel = CommonHelper.getValueOfParameter("AVEA_GATEWAY_CHANNEL_MAPPING", channelCode);
				if ("EVET".equals(isCampaignChannel)) {
					String responseCode = "";
					String gatewayErrorDesc = "";
					String amount = "";
					if (!"".equals(iMap.getString("PACKAGE_ID"))) {
						amount = iMap.getString("PACKAGE_ID").replace(".", "").replace(",", "");
					} else {
						amount = iMap.getString("PAYMENT_AMOUNT").replace(".", "").replace(",", "");
					}

					if (amount.length() == 3) {
						amount = amount.concat("0");
					}
					if (amount.length() == 2) {
						amount = amount.concat("00");
					}
					String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);// 34
					String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);// 104
					String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);// 12
					String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);// CS1002
					int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);// 1
					int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);// 24
					String institutionId = AVEA_INSTITUTION_ID;// 1143
					int currencyCode = AVEA_CURRENCY_CODE;// 949
					int sunCustomerAccessType = AVEA_CUSTOMER_ACCESS_TYPE;// 1
					String sunCustomerAccessNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
					int operationSource = AVEA_PAYMENT_TYPE;

					inputMap.put(AveaDebtInqueryServices.Input.OPERATION_SOURCE, Integer.toString(operationSource)); // P-25
					inputMap.put(AveaDebtInqueryServices.Input.INSTITUTION_ID, institutionId);
					inputMap.put(AveaDebtInqueryServices.Input.CURRENCY_CODE, currencyCode);// P-49
					inputMap.put(AveaDebtInqueryServices.Input.SUN, 0, AveaDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_TYPE, sunCustomerAccessType);// P-60
					inputMap.put(AveaDebtInqueryServices.Input.SUN, 0, AveaDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_NO, sunCustomerAccessNo);// P-60

					inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
					inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
					inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
					inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44

					inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, Integer.toString(corporationId));
					inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, Integer.toString(operationCodeId));
					// asagidaki 3 satir canliya giderken silinecek
					// logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT will get FTM connection...");
					// GMConnection gmConnection =
					// GMConnection.getConnection("GW_CON");
					// logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT got FTM connection successfully...");
					// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",
					// inputMap));
					// asagidaki satir canliya giderken acilacak
					returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
					logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT is called BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE connection successfully...");
					// check if an error is occured on GW
					if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
						if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
							responseCode = GATEWAY_ERROR;
							logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
							logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
							gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
						} else {
							responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
							logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
						}
					} else {
						responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
						logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
					}

					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					try {
						if (returnMap.containsKey("SERVER_STAN")) {
							String serverStan = returnMap.getString("SERVER_STAN");
							String stan = returnMap.getString("STAN");
							referenceInfoStan = stan;
							if (Integer.parseInt(stan) == Integer.parseInt(serverStan)) {
							} else {
								responceCodeMap = getResponseCodeMapping(GATEWAY_ERROR, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
								errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
								outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
								outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
								outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
								logger.info("ICS_AVEA_INVOICE_DEBT_INQUIRY -> TIMEOUT -> Gateway timeout problemi meydana geldi... STAN degerleri ayni degil ");
							}
						}
					} catch (Exception e) {
						logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> an error occured when comparing STAN values..");
					}
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

						inputMap = new GMMap();

						operationCodeId = 14;

						inputMap.put(AveaDebtInqueryServices.Input.OPERATION_SOURCE, Integer.toString(operationSource)); // P-25
						inputMap.put(AveaDebtInqueryServices.Input.INSTITUTION_ID, institutionId);
						inputMap.put(AveaDebtInqueryServices.Input.RECORD_NUMBER, "01");
						inputMap.put(AveaDebtInqueryServices.Input.CURRENCY_CODE, currencyCode);// P-49
						inputMap.put(AveaDebtInqueryServices.Input.SUN, 0, AveaDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_TYPE, sunCustomerAccessType);// P-60
						inputMap.put(AveaDebtInqueryServices.Input.SUN, 0, AveaDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_NO, sunCustomerAccessNo);// P-60

						inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
						inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
						inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
						inputMap.put(AveaDebtInqueryServices.Input.ORIGINATOR_ID, 0, AveaDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44

						inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, Integer.toString(corporationId));
						inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, Integer.toString(operationCodeId));

						inputMap.put(AveaDoInvoiceCollectionServices.Input.RELOAD_INFORMATION, 0, AveaDoInvoiceCollectionServices.Input.RELOAD_INFORMATION_COMMISSION, "0000000000000000000");// P-44
						inputMap.put(AveaDoInvoiceCollectionServices.Input.RELOAD_INFORMATION, 0, AveaDoInvoiceCollectionServices.Input.RELOAD_INFORMATION_ORDER_FLAG, "0");// P-44

						inputMap.put(AveaDoInvoiceCollectionServices.Input.NORMAL_CUT_INFORMATION, 0, AveaDoInvoiceCollectionServices.Input.NORMAL_CUT_INFORMATION_UNIT, amount);// P-44
						inputMap.put(AveaDoInvoiceCollectionServices.Input.NORMAL_CUT_INFORMATION, 0, AveaDoInvoiceCollectionServices.Input.NORMAL_CUT_INFORMATION_AMOUNT, amount);// P-44

						inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_STAN, referenceInfoStan);// P-48
						inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_PROCESS_DATE, "20141030");// P-48
						inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_PROCESS_ORDER_NO, "000000");// P-48
						inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_BANK_CODE, "0000");// P-48
						inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_MERCHANT_ID, "00000000000000000000");// P-48
						inputMap.put(AveaDoInvoiceCollectionServices.Input.REFERENCE_INFO, 0, AveaDoInvoiceCollectionServices.Input.ReferenceInfo.REFERENCE_INFO_AUTH_CODE, "0000000000");// P-48

						Calendar cal = Calendar.getInstance();
						int month = cal.get(Calendar.MONTH) + 1;
						String sMonth = String.valueOf(month);
						if (month < 10) {
							sMonth = "0".concat(sMonth);
						}
						int year = cal.get(Calendar.YEAR);
						String sYear = String.valueOf(year);
						String paymentPeriod = sYear.concat(sMonth);
						int day = cal.get(Calendar.DAY_OF_MONTH);
						String sDay = String.valueOf(day);
						if (day < 10) {
							sDay = "0".concat(sDay);
						}
						String acceptanceDate = "";
						String captureDate = "";
						if (iMap.containsKey(MapKeys.PAYMENT_DATE)) {
							acceptanceDate = iMap.getString(MapKeys.PAYMENT_DATE).substring(0, 8);
							captureDate = iMap.getString(MapKeys.PAYMENT_DATE).substring(0, 8);
						} else {
							acceptanceDate = sYear.concat(sMonth).concat(sDay);
							captureDate = sYear.concat(sMonth).concat(sDay);
						}

						inputMap.put(AveaDoInvoiceCollectionServices.Input.ACCEPTENCE_DATE, acceptanceDate);// P-58
						inputMap.put(AveaDoInvoiceCollectionServices.Input.CAPTURE_DATE, captureDate);// P-58
						// asagidaki 3 satir canliya giderken silinecek
						// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",
						// inputMap));
						// asagidaki satir canliya giderken acilacak
						returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
						logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT is called BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE connection successfully...");
						// check if an error is occured on GW
						if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
							if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
								responseCode = GATEWAY_ERROR;
								logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
								logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
								gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
							} else {
								responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
								logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
							}
						} else {
							responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
							logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE)));
						}

						responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
						try {
							if (returnMap.containsKey("SERVER_STAN")) {
								String serverStan = returnMap.getString("SERVER_STAN");
								String stan = returnMap.getString("STAN");
								if (Integer.parseInt(stan) == Integer.parseInt(serverStan)) {
								} else {
									responceCodeMap = getResponseCodeMapping(GATEWAY_ERROR, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
									errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
									outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
									outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
									outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
									logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> TIMEOUT -> Gateway timeout problemi meydana geldi... STAN degerleri ayni degil ");
								}
							}
						} catch (Exception e) {
							logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT -> an error occured when comparing STAN values..");
						}

						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
							outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
							outMap.put("STATUS_CODE", responceCodeMap.getString(MapKeys.ERROR_CODE));
							outMap.put("STATUS_DESC", responceCodeMap.getString(MapKeys.ERROR_DESC));
						} else {
							// an error occured
							logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT an error accoured with error code : ".concat(errorCode));
							logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT an error accoured with response code : ".concat(responseCode));
							logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT an error accoured returnMap : ".concat(returnMap.toString()));
							logger.info(responceCodeMap.getString(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM));
						}

					} else {
						// an error occured
						logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT an error accoured with error code : ".concat(errorCode));
						logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT an error accoured with response code : ".concat(responseCode));
						logger.info("ICS_AVEA_PAY_MONEY_LOAD_AMOUNT an error accoured returnMap : ".concat(returnMap.toString()));
						logger.info(responceCodeMap.getString(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM));
					}
				} else {
					String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
					String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
					String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
					long amount = (long) (Float.valueOf(iMap.getString("PAYMENT_AMOUNT")) * 100);// avea
																									// sayi
																									// formatindan
																									// dolayi

					SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					// Convert Local Time to UTC (Works Fine)
					sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
					Calendar c1 = Calendar.getInstance();
					c1.setTime(new Date(sdf.format(new Date())));

					ServiceMessage sm = new ServiceMessage();
					// paket sorgulamak icin provisionId alinir oncesinde
					GetProvisionResult provResult = AveaClient.getProvision(wsUrl, userName, password, c1, AVEA_UTILITY_COMPANY_CODE, sm);
					responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(provResult.getResponseCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), iMap.getString(MapKeys.CORPORATE_CODE));
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put("STATUS_CODE", responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put("STATUS_DESC", responceCodeMap.getString(MapKeys.ERROR_DESC));
					iMap.put("REQUEST_XML", sm.getRequest());
					outMap.put("RESPONSE_XML", sm.getResponse());

					// basarili bir sekilde provisyon ID alinir ise akisa devam
					// eder
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

						PackageInquiryResult packageInquiryResult = AveaClient.packageInquiry(wsUrl, userName, password, c1, provResult.getProvisionId(), msisdn, AVEA_CUSTOMER_ACCESS_TYPE, AVEA_LANGUAGE_CODE, sm);

						responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(packageInquiryResult.getResponseCode(), null, corporateCode);
						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
						iMap.put("REQUEST_XML", sm.getRequest());
						outMap.put("RESPONSE_XML", sm.getResponse());

						// abone ve paket bulunur ise akisa devam eder
						if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {

							TopupResult result = AveaClient.topup(wsUrl, userName, password, c1, provResult.getProvisionId(), amount, AVEA_CURRENCY_CODE, AVEA_PAYMENT_TYPE, sm);
							responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(result.getResponseCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), iMap.getString(MapKeys.CORPORATE_CODE));
							outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
							outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
							// yukleme islemi ok olursa ekran da gosterilecek
							// mesajlar bu servisi cagiran yerde set edilir
							outMap.put("STATUS_CODE", responceCodeMap.getString(MapKeys.ERROR_CODE));
							outMap.put("STATUS_DESC", responceCodeMap.getString(MapKeys.ERROR_DESC));
							iMap.put("REQUEST_XML", sm.getRequest());
							outMap.put("RESPONSE_XML", sm.getResponse());
						}
					}
				}
				outMap.put("TRX_NO", iMap.getString(MapKeys.TRX_NO));
			} else {
				responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(TURKCELL_MSISDN_NOT_FOUND_ERROR, null, iMap.getString(MapKeys.CORPORATE_CODE));
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AVEA_MONEY_LOAD_RECONCILIATION")
	public static GMMap makeAveaMoneyLoadReconciliation(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_MONEY_LOAD_RECONCILIATION");
		GMMap outMap = new GMMap();
		GMMap inputMap = new GMMap();
		String gatewayErrorDesc = "";
		try {
			// banka tarafindaki toplam degerleri aliriz
			outMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_CALCULATE_RECONCILIATION_RECORDS", iMap);
			int operationCount = Integer.valueOf(outMap.getString("COUNT"));
			double operationTotalAmount = Double.valueOf(outMap.getString("TOTAL_AMOUNT"));
			iMap.put("COUNT", operationCount);
			iMap.put("TOTAL_AMOUNT", operationTotalAmount);
			// Operator tarafinda sorguyu cagiririz
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
			String tahsilatTarihi = iMap.getString(MapKeys.RECON_DATE);
			Calendar reconciliationDate = Calendar.getInstance();
			reconciliationDate.setTime(sdf.parse(tahsilatTarihi));

			long ota = (long) (operationTotalAmount * 1000000); // avea nin
																// rakam
																// formatindan
																// dolayi
			EndofDayRequestItem[] endofDayRequestList = new EndofDayRequestItem[1];
			endofDayRequestList[0] = new EndofDayRequestItem(AVEA_OPERATION_CODE, operationCount, ota, AVEA_CURRENCY_CODE);
			ServiceMessage sm = new ServiceMessage();
			TerminalEndOfDayResult result = AveaClient.terminalEndOfDay(wsUrl, userName, password, Calendar.getInstance(), AVEA_UTILITY_COMPANY_CODE, reconciliationDate, endofDayRequestList, sm);
			String responseCode = "0000";
			for (EndofDayResultItem item : result.getEndofDayResponseList()) {
				if (item.getOperationCode() == AVEA_OPERATION_CODE) {
					responseCode = item.getResponseCode();
				}
			}
			GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(responseCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, 0);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}

			// set parameters
			String operationSource = "0";

			int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);// 11
			inputMap.put(VodafoneDebtInqueryServices.Input.COMPANY_ID, "0555"); // P-26
			inputMap.put(VodafoneDebtInqueryServices.Input.INSTITUTION_ID, "1143"); // P-26
			inputMap.put(AveaCommonServices.Input.RECON_OPERATION_COUNT, "1"); // P-20
			inputMap.put(AveaDoInvoiceCollectionServices.Input.OPERATION_SOURCE, operationSource); // P-25

			String originatorIdCityCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);// 34
			String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);// 104
			String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);// 12
			String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);// CS1002;
			String currencyCode = Integer.toString(AVEA_CURRENCY_CODE);
			inputMap.put(AveaReconService.Input.SETTLEMENT_CURRENCY_CODE, currencyCode);// P-50

			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
			inputMap.put(AveaDoInvoiceCollectionServices.Input.ORIGINATOR_ID, 0, AveaDoInvoiceCollectionServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44

			int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);// 2

			String acceptanceDate = tahsilatTarihi;

			inputMap.put(AveaDoInvoiceCollectionServices.Input.ACCEPTENCE_DATE, acceptanceDate);// P-58
			inputMap.put(AveaDebtInqueryServices.Input.CORPORATION_ID, corporationId);
			// operationCodeId corresponds to OID field on
			// ics.gw_corporation_operation_code table
			inputMap.put(AveaDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);

			String reconInfoTransCode = "61";
			String reconInfoTransState = "0";

			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_CODE, reconInfoTransCode);// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS, operationCount);// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TOTAL_TRANS_AMOUNT, Double.toString(operationTotalAmount).replace(".", "").concat("0"));// P-56
			inputMap.put(AveaReconService.Input.RECON_INFO, 0, AveaReconService.Input.ReconInfo.RECON_INFO_TRANS_STATE, reconInfoTransState);// P-56

			// GMConnection gmConnection = GMConnection.getConnection("GW_CON");
			GMMap returnMap = new GMMap();
			logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> mutabakat bu degerler ile cagirileacktir->".concat(inputMap.toString()));
			// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",inputMap));
			returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
			logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> mutabakat bu degerler ile geri donmustur->".concat(returnMap.toString()));
			if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
				if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
					responseCode = GATEWAY_ERROR;
					logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
					logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
					gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(AveaDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
					logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> mutabakat bu degerler ile cagirileacktir->".concat(gatewayErrorDesc));
				} else {
					responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
					logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> mutabakat bu degerler ile cagirileacktir->".concat(responseCode));
				}
			} else {
				responseCode = returnMap.getString(AveaDebtInqueryServices.Output.RESPONSE_CODE);
				responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(responseCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> mutabakat bu degerler ile cagirileacktir->".concat(responseCode));
				logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> mutabakat bu degerler ile cagirileacktir->".concat(errorCode));
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION -> mutabakat bu degerler ile cagirileacktir->".concat(responceCodeMap.toString()));
				if (GeneralConstants.ERROR_CODE_APPROVE.equals(errorCode)) {
					outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
					outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
				} else {
					outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
				}
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, "0");
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, "0");
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_AVEA_MONEY_LOAD_RECONCILIATION_DETAIL")
	public static GMMap makeAveaMoneyLoadReconsiliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_MONEY_LOAD_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		try {
			logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION_DETAIL is called");
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.Continues);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION_DETAIL finished succesfully");
		return outMap;
	}

	@GraymoundService("ICS_AVEA_MONEY_LOAD_RECONCILIATION_CLOSED")
	public static GMMap makeAveaMoneyLoadReconsiliationClose(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_AVEA_MONEY_LOAD_RECONCILIATION_CLOSED");

		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		logger.info("ICS_AVEA_MONEY_LOAD_RECONCILIATION_CLOSED finished succesfully");
		return output;
	}

	// Vodafone Services Start
	@GraymoundService("ICS_VODAFONE_MONEY_LOAD_GET_PRODUCTS")
	public static GMMap getVodafoneSubscriberProducts(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VODAFONE_MONEY_LOAD_GET_PRODUCTS");
		GMMap outMap = new GMMap();
		String tableName = BnsprCommonFunctions.getTableName(iMap);
		try {
			String msisdn = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(msisdn) && msisdn.length() == 10) {
				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
				String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String refCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				String stan = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString("TRX_NO");

				TopupQueryInput[] topupQueryInput = new TopupQueryInput[1];
				BigDecimal amount = new BigDecimal("20");
				topupQueryInput[0] = new TopupQueryInput(refCode, VODAFONE_REF_CODE_TYPE, stan, VODAFONE_POINT_OF_SALE, VODAFONE_POINT_OF_SALE_CITY_PLATE_CODE, VODAFONE_REQUEST_CHANNEL, VODAFONE_PAYMENT_CHANNEL, msisdn, amount, VODAFONE_AMOUNT_TYPE);
				TopupQueryRequest topupQueryRequest = new TopupQueryRequest(topupQueryInput);
				ServiceMessage sm = new ServiceMessage();
				TopupQueryResponse topupQueryResponse = VodafoneClient.topupQuery(wsUrl, userName, password, topupQueryRequest, sm);
				String resultCode = "TL" + String.format("%02d", topupQueryResponse.getTopupQueryOutput()[0].getResultCode());

				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(resultCode, null, corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());

				// PACKAGES outputunun dolmasi icin
				outMap.put(MapKeys.CORPORATE_CODE, corporateCode);
				outMap.put("TABLE_NAME", tableName);
				outMap = GMServiceExecuter.call("CDM_GET_SELECTED_OPERATOR_PACKAGE_LIST", outMap);
			} else {
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(TURKCELL_MSISDN_NOT_FOUND_ERROR, null, corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_VODAFONE_PAY_MONEY_LOAD_AMOUNT")
	public static GMMap payVodafoneMoneyLoadAmount(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VODAFONE_PAY_MONEY_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		GMMap inputMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		try {
			String msisdn = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			BigDecimal amount = new BigDecimal(iMap.getString("PAYMENT_AMOUNT"));

			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && iMap.getString(MapKeys.SUBSCRIBER_NO1).length() == 10) {
				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
				String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String refCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				String stan = iMap.getString(MapKeys.TRX_NO);

				String channelCode = CommonHelper.getChannelId();
				String isGatewayChannel = CommonHelper.getValueOfParameter("VODAFONE_MONEY_LOAD_CHANNEL_CODE", channelCode);
				if ("EVET".equals(isGatewayChannel)) {
					// on odemeli abone bilgisi sorgula
					Calendar cal = Calendar.getInstance();
					int month = cal.get(Calendar.MONTH) + 1;
					String sMonth = String.valueOf(month);
					if (month < 10) {
						sMonth = "0".concat(sMonth);
					}
					int year = cal.get(Calendar.YEAR);
					String sYear = String.valueOf(year);
					String responseCode = "";
					corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
					String gatewayErrorDesc = "";
					String currencyCode = "949";
					String sunCustomerAccessType = "1";
					String errorCode = "";
					String sunCustomerAccessNo = iMap.getString(MapKeys.SUBSCRIBER_NO1);
					String paymentPeriod = sYear.concat(sMonth);
					int corporationId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
					int operationCodeId = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
					String originatorIdCityCode = "34";
					String originatorIdBranchCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
					String originatorIdOfficeCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
					String originatorIdUserCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

					// set GW call parameters
					inputMap.put(VodafoneDebtInqueryServices.Input.OPERATION_SOURCE, "0"); // P-25
					inputMap.put(VodafoneDebtInqueryServices.Input.COMPANY_ID, "0542"); // P-26
					inputMap.put(VodafoneDebtInqueryServices.Input.INSTITUTION_ID, "1143"); // P-26
					inputMap.put(VodafoneDebtInqueryServices.Input.INSTITUTION_NUMBER, "AKTBANK"); // P-26

					inputMap.put(VodafoneDebtInqueryServices.Input.ORIGINATOR_ID, 0, VodafoneDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_CITY_CODE, originatorIdCityCode);// P-44
					inputMap.put(VodafoneDebtInqueryServices.Input.ORIGINATOR_ID, 0, VodafoneDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_BRANCH_CODE, originatorIdBranchCode);// P-44
					inputMap.put(VodafoneDebtInqueryServices.Input.ORIGINATOR_ID, 0, VodafoneDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_OFFICE_CODE, originatorIdOfficeCode);// P-44
					inputMap.put(VodafoneDebtInqueryServices.Input.ORIGINATOR_ID, 0, VodafoneDebtInqueryServices.Input.OriginatorId.ORIGINATOR_ID_USER_CODE, originatorIdUserCode);// P-44

					inputMap.put(VodafoneDebtInqueryServices.Input.CURRENCY_CODE, currencyCode);// P-49

					inputMap.put(VodafoneDebtInqueryServices.Input.SUN, 0, VodafoneDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_TYPE, sunCustomerAccessType);// P-60
					inputMap.put(VodafoneDebtInqueryServices.Input.SUN, 0, VodafoneDebtInqueryServices.Input.Sun.SUN_CUSTOMER_ACCESS_NO, sunCustomerAccessNo);// P-60

					// corporationId corresponds to OID field on
					// ics.gw_corporation_definition table
					inputMap.put(VodafoneDebtInqueryServices.Input.CORPORATION_ID, corporationId);
					// operationCodeId corresponds to OID field on
					// ics.gw_corporation_operation_code table
					inputMap.put(VodafoneDebtInqueryServices.Input.OPERATION_CODE_ID, operationCodeId);

					inputMap.put(VodafoneDebtInqueryServices.Input.CUT_INFORMATION, 0, VodafoneDebtInqueryServices.Input.TARIFF_UNIT, "00000");// P-44
					inputMap.put(VodafoneDebtInqueryServices.Input.CUT_INFORMATION, 0, VodafoneDebtInqueryServices.Input.TARIFF_AMOUNT, "0000002000");//

					// logger.info("ICS_VF_INVOICE_DEBT_INQUIRY will get GW_CON connection...");
					// logger.info("ICS_VF_INVOICE_DEBT_INQUIRY got GW_CON connection successfully...");
					// GMConnection gmConnection =
					// GMConnection.getConnection("GW_CON");
					// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",inputMap));
					returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
					logger.info("ICS_VF_INVOICE_DEBT_INQUIRY is called BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE connection successfully...");
					// check if an error is occured on GW
					if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
						if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
							responseCode = GATEWAY_ERROR;
							logger.info("ICS_VF_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.GW_INTERNAL_ERROR_CODE)));
							logger.info("ICS_VF_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC)));
							gatewayErrorDesc = " - Gateway Hata Aciklamasi = ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.GW_INTERNAL_ERROR_DESC));
						} else {
							responseCode = returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE);
							logger.info("ICS_VF_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE)));
						}
					} else {
						responseCode = returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE);
						logger.info("ICS_VF_INVOICE_DEBT_INQUIRY -> BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE respond code -> ".concat(returnMap.getString(VodafoneDebtInqueryServices.Output.RESPONSE_CODE)));
					}

					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC).concat(gatewayErrorDesc));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

				} else {
					TopupQueryInput[] topupQueryInput = new TopupQueryInput[1];
					topupQueryInput[0] = new TopupQueryInput(refCode, VODAFONE_REF_CODE_TYPE, stan, VODAFONE_POINT_OF_SALE, VODAFONE_POINT_OF_SALE_CITY_PLATE_CODE, VODAFONE_REQUEST_CHANNEL, VODAFONE_PAYMENT_CHANNEL, msisdn, amount, VODAFONE_AMOUNT_TYPE);
					TopupQueryRequest topupQueryRequest = new TopupQueryRequest(topupQueryInput);
					ServiceMessage sm = new ServiceMessage();
					TopupQueryResponse topupQueryResponse = VodafoneClient.topupQuery(wsUrl, userName, password, topupQueryRequest, sm);
					String resultCode = "TL" + String.format("%02d", topupQueryResponse.getTopupQueryOutput()[0].getResultCode());

					responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(resultCode, null, corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					iMap.put("REQUEST_XML", sm.getRequest());
					outMap.put("RESPONSE_XML", sm.getResponse());

					// abone ve paket bulunur ise akisa devam eder
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
						TopupConfirmationInput[] topupConfirmationInput = new TopupConfirmationInput[1];
						topupConfirmationInput[0] = new TopupConfirmationInput(refCode, VODAFONE_REF_CODE_TYPE, topupQueryResponse.getTopupQueryOutput()[0].getProvisionNo(), VODAFONE_POINT_OF_SALE, VODAFONE_POINT_OF_SALE_CITY_PLATE_CODE, VODAFONE_REQUEST_CHANNEL, VODAFONE_PAYMENT_CHANNEL);
						TopupConfirmationRequest topupConfirmationRequest = new TopupConfirmationRequest(topupConfirmationInput);
						TopupConfirmationResponse topupConfirmationResponse = VodafoneClient.topupConfirmation(wsUrl, userName, password, topupConfirmationRequest, sm);

						resultCode = "TL" + String.format("%02d", topupConfirmationResponse.getTopupConfirmationOutput()[0].getResultCode());
						responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(resultCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
						// yukleme islemi ok olursa ekran da gosterilecek
						// mesajlar
						// bu servisi cagiran yerde set edilir
						outMap.put("STATUS_CODE", responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put("STATUS_DESC", responceCodeMap.getString(MapKeys.ERROR_DESC));
						iMap.put("REQUEST_XML", sm.getRequest());
						outMap.put("RESPONSE_XML", sm.getResponse());
					}
				}
				outMap.put("TRX_NO", iMap.getString(MapKeys.TRX_NO));
			} else {
				responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(TURKCELL_MSISDN_NOT_FOUND_ERROR, null, iMap.getString(MapKeys.CORPORATE_CODE));
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_VODAFONE_MONEY_LOAD_RECONCILIATION")
	public static GMMap makeVodafoneMoneyLoadReconciliation(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VODAFONE_MONEY_LOAD_RECONCILIATION");
		GMMap outMap = new GMMap();
		try {
			// banka tarafindaki toplam degerleri aliriz
			outMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_CALCULATE_RECONCILIATION_RECORDS", iMap);
			int operationCount = Integer.valueOf(outMap.getString("COUNT"));
			double operationTotalAmount = Double.valueOf(outMap.getString("TOTAL_AMOUNT"));
			iMap.put("COUNT", operationCount);
			iMap.put("TOTAL_AMOUNT", operationTotalAmount);
			// Operator tarafinda sorguyu cagiririz
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String refCode = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String reconciliationDate = iMap.getString(MapKeys.RECON_DATE); // format
																			// should
																			// be
																			// YYYYMMDD

			OnlineAgreementServiceRequest onlineAgreementServiceRequest = new OnlineAgreementServiceRequest();
			OnlineAgreementServiceInput[] onlineAgreementServiceInput = new OnlineAgreementServiceInput[1];
			onlineAgreementServiceInput[0] = new OnlineAgreementServiceInput(refCode, VODAFONE_REF_CODE_TYPE, reconciliationDate, BigDecimal.valueOf(operationTotalAmount), BigDecimal.valueOf(operationTotalAmount), VODAFONE_AMOUNT_TYPE, BigDecimal.valueOf(operationTotalAmount), VODAFONE_AMOUNT_TYPE, VODAFONE_POINT_OF_SALE, VODAFONE_REQUEST_CHANNEL, VODAFONE_PAYMENT_CHANNEL);
			onlineAgreementServiceRequest.setOnlineAgreementServiceInput(onlineAgreementServiceInput);
			ServiceMessage sm = new ServiceMessage();
			OnlineAgreementServiceResponse onlineAgreementServiceResponse = VodafoneClient.onlineAgreementService(wsUrl, userName, password, onlineAgreementServiceRequest, sm);
			String responseCode = "TL" + String.format("%02d", onlineAgreementServiceResponse.getOnlineAgreementServiceOutput()[0].getResultCode());
			GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(responseCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());

			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, onlineAgreementServiceResponse.getOnlineAgreementServiceOutput()[0].getAmount());
				outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, 0);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, operationTotalAmount);
				outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, operationCount);
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ICS_VODAFONE_MONEY_LOAD_RECONCILIATION_DETAIL")
	public static GMMap makeVodafoneMoneyLoadReconsiliationDetail(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VODAFONE_MONEY_LOAD_RECONCILIATION_DETAIL");
		GMMap outMap = new GMMap();
		try {
			logger.info("ICS_VODAFONE_MONEY_LOAD_RECONCILIATION_DETAIL is called");
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.Continues);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception ex) {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			outMap.put(MapKeys.ERROR_DESC, "description");
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.RECON_STATUS, DatabaseConstants.ReconciliationStatus.ReconciliationFailed);
			throw ExceptionHandler.convertException(ex);
		}
		logger.info("ICS_VODAFONE_MONEY_LOAD_RECONCILIATION_DETAIL finished succesfully");
		return outMap;
	}

	@GraymoundService("ICS_VODAFONE_MONEY_LOAD_RECONCILIATION_CLOSED")
	public static GMMap makeVodafoneMoneyLoadReconsiliationClose(GMMap iMap) {
		GMMap output = new GMMap();

		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_VODAFONE_MONEY_LOAD_RECONCILIATION_CLOSED");

		try {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} catch (Exception e) {
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
			output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
			throw ExceptionHandler.convertException(e);
		}
		logger.info("ICS_VODAFONE_MONEY_LOAD_RECONCILIATION_CLOSED finished succesfully");
		return output;
	}

	// Frontend Values For Accounting and Money Load
	@GraymoundService("ICS_GSM_MONEY_LOAD_FRONTEND")
	public static GMMap payGsmMoneyLoadAmount(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			String source = iMap.getString("SOURCE_CODE");
			String phoneNumber = iMap.getString("PHONE", null);
			String idNo = iMap.getString("TCKNO", null);
			String taxNo = iMap.getString("TAX_NO", null);
			String balance = iMap.getString("BALANCE");

			if (DatabaseConstants.SourceCodes.Cash.equals(source) && iMap.getBoolean("OVER_LIMIT") && (phoneNumber == null || "".equals(phoneNumber) || idNo == null || "".equals(idNo))) {
				CommonHelper.throwBusinessException(BusinessException.FILLREQUIREDFIELDS.getCode());
			}
			String accountNo = source.equals(DatabaseConstants.SourceCodes.Cash) ? "0" : iMap.getString("ACCOUNT_NO");

			BigDecimal availableBalance = iMap.getBigDecimal("AVAILABLE_BALANCE", null);
			if (!"0".equals(accountNo) && iMap.getString("RECALCULATE_BALANCES", "0").equals("1")) {
				GMMap balanceResponse = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GET_ACCOUNT_INFORMATION_FRONTEND", new GMMap().put("ACCOUNT_NO", accountNo));
				availableBalance = balanceResponse.getBigDecimal("AVAILABLE_BALANCE");
				balance = balanceResponse.getString("BALANCE");
			}

			GMMap gsmMoneyLoadMap = new GMMap();
			// para yukelemek icin ekrandan gelecek parametreler
			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.PACKAGE_ID, iMap.getString("PACKAGE_ID"));
			if (iMap.getString("PACKAGE_ID").contains("|")) {
				gsmMoneyLoadMap.put("OBJECT", iMap.getString("PACKAGE_ID").split("[|]")[0]);
			}

			if (source.equals(DatabaseConstants.SourceCodes.Account)) {
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.ACCOUNT_CURRENCY_CODE, iMap.getString("CURRENCY_CODE"));
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.ACCOUNT_BALANCE, new BigDecimal(balance));
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.IBAN_NO, iMap.getString("IBAN"));
			}

			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));

			if (idNo != null) {
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.CUSTOMER_ID_NO, idNo);
			}

			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.CUSTOMER_NO, iMap.getString("CUSTOMER_NO"));

			if (phoneNumber != null) {
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.CUSTOMER_PHONE, phoneNumber);
			}
			if (taxNo != null) {
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.CUSTOMER_TAX_NO, taxNo);
			}

			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_ACCOUNT_NO, new BigDecimal(accountNo));
			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_AMOUNT, iMap.getBigDecimal(MapKeys.COLLECTION_AMOUNT));
			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.SOURCE, source);
			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_SOURCE, source);
			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.SUBSCRIBER_NAME, iMap.getString("CUSTOMER_NAME", null));
			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.SUBSCRIBER_NO1, iMap.getString(MapKeys.SUBSCRIBER_NO1));

			if (iMap.getString(MapKeys.PARAMETER1) != null) {
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER1, iMap.getString(MapKeys.PARAMETER1));
			}

			if (iMap.getString(MapKeys.PARAMETER2) != null) {
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER2, iMap.getString(MapKeys.PARAMETER2));
			}

			if (iMap.getString(MapKeys.PARAMETER3) != null) {
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER3, iMap.getString(MapKeys.PARAMETER3));
			}

			if (iMap.getString(MapKeys.PARAMETER4) != null) {
				gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER4, iMap.getString(MapKeys.PARAMETER4));
			}

			gsmMoneyLoadMap.put(TransactionConstants.DoGSMMoneyLoad.Input.ACCOUNT_AVAILABLE_BALANCE, availableBalance);
			// ICS_ONLINE_SERVICE call bu servisin icinde yapilacak
			outMap = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.DoGSMMoneyLoad.SERVICE_NAME, gsmMoneyLoadMap);
			// ekranda gorunecek output mesajlari
			StringBuilder messageBuilder = new StringBuilder();
			messageBuilder.append("<html><center>Y�kleme talebi operat�r�n�ze iletilmi�tir. Y�kleme i�lemi tamamland���nda, operat�r�n�z taraf�ndan, y�klemenin yap�ld��� cep telefonuna SMS ile bilgi verilecektir.<br>��lem Numaran�z:<br>");
			messageBuilder.append(outMap.getString(TransactionConstants.DoGSMMoneyLoad.Output.TRX_NO));
			messageBuilder.append("<br></center></html>");
			outMap.put("MESSAGE", "Tahsilat i�lem(ler)iniz ba�ar�yla tamamlanm��t�r.");
			outMap.put("COLLECTION_MESSAGES", messageBuilder.toString());

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}

	@GraymoundService("ICS_DO_GSM_MONEY_LOAD")
	public static GMMap doGsmMoneyLoad(GMMap input) {
		return RequestProcessor.getInstance().process(input, new DoGSMMoneyLoad());
	}

	@GraymoundService("ICS_INSERT_GSM_MONEY_LOAD_LOG")
	public static GMMap insertGsmMoneyLoadLog(GMMap input) {
		return RequestProcessor.getInstance().process(input, new InsertMoneyLoadLogHandler());
	}

	@GraymoundService("ICS_CALCULATE_RECONCILIATION_RECORDS")
	public static GMMap calculateReconciliationRecords(GMMap iMap) {
		GMMap outMap = new GMMap();
		String tableName = "RECON_COUNT";
		try {
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			String reconcilationDate = iMap.getString(MapKeys.RECON_DATE);
			String query = "";
			StringBuilder s = new StringBuilder();
			// s.append("select count(*) as COUNT, nvl(sum(payment_amount),0) as TOTAL_AMOUNT ");
			// s.append(" from ics.gsm_money_load ");
			// s.append("where corporate_code = \'%s\'");
			// s.append("	and status = '1' ");
			// s.append("	and trunc(to_date(payment_date, 'YYYYMMDDHH24MISS')) = to_date(\'%s\', 'YYYYMMDD')");
			s.append(QueryRepository.OperatorServicesRepository.GET_MONEY_LOAD_RECORD);
			query = String.format(s.toString(), corporateCode, reconcilationDate);
			outMap = DALUtil.getResults(query, tableName);

			outMap.put("COUNT", outMap.getString(tableName, 0, "COUNT"));
			outMap.put("TOTAL_AMOUNT", outMap.getString(tableName, 0, "TOTAL_AMOUNT"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}

	@GraymoundService("CDM_GET_MONEY_LOAD_AVAILABLE_CORP_LIST")
	public static GMMap getMoneyLoadAvailableCoprList(GMMap iMap) {
		GMMap outMap = new GMMap();
		String tableName = "OPERATORS";
		String tableName2 = BnsprCommonFunctions.getTableName(iMap);
		try {
			String channelId = iMap.getString(MapKeys.CHANNEL_CODE);
			if (channelId == null || channelId == "") {
				channelId = CommonHelper.getChannelId();
			}

			StringBuilder s = new StringBuilder();
			// s.append("select distinct cm.oid, cm.corporate_code, cm.short_code \n");
			// s.append("from cdm.corporate_master cm, cdm.corporation_account_master cam, cdm.account_collection_type_rel act \n");
			// s.append(" where cm.oid = cam.corporate_oid and cam.oid = act.account_master_oid \n");
			// s.append("	and cm.status = 1 and cam.status = 1 and act.status = 1 \n");
			// s.append("	and act.collection_type = %s and act.channel_code = %s \n");
			s.append(QueryRepository.OperatorServicesRepository.GET_AVAILABLE_CORP_LIST);
			String query = String.format(s.toString(), COLLECTION_TYPE, channelId);

			GMMap results = DALUtil.getResults(query, tableName);
			for (int counter = 0; counter < results.getSize(tableName); counter++) {
				String oid = results.getString(tableName, counter, "OID");
				String corporateCode = results.getString(tableName, counter, "CORPORATE_CODE");
				String shortCode = results.getString(tableName, counter, "SHORT_CODE");

				GuimlUtil.wrapMyCombo(outMap, tableName, corporateCode, shortCode);
				if (counter == 0) {// get initial corporateOid
					outMap.put("CORPORATE_OID", oid);
				}
				outMap.put(tableName2, counter, "CODE", corporateCode);
				outMap.put(tableName2, counter, "NAME", shortCode);
				outMap.put(tableName2, counter, "OID", oid);
			}
			outMap.put("COLLECTION_TYPE", COLLECTION_TYPE);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_SELECTED_OPERATOR_PACKAGE_LIST")
	public static GMMap getSelectedOperatorPackageList(GMMap ioMap) {
		Session session = CommonHelper.getHibernateSession();
		String tableName = "PACKAGES";
		String tableName2 = BnsprCommonFunctions.getTableName(ioMap);
		boolean isPackageExist = false;
		try {

			CorporateMaster cp = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", ioMap.getString("CORPORATE_CODE"))).uniqueResult();
			if (cp != null)
				ioMap.put("CORPORATE_OID", cp.getOid());
			Criteria query = session.createCriteria(CorporateTlinstallment.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", ioMap.getString("CORPORATE_CODE"))).addOrder(Order.asc("installmentAmount"));
			List<CorporateTlinstallment> ctiList = (List<CorporateTlinstallment>) query.list();

			int counter = 0;
			for (CorporateTlinstallment cti : ctiList) {
				GuimlUtil.wrapMyCombo(ioMap, tableName, cti.getInstallmentAmount() + "|" + cti.getInstallmentAmount(), cti.getInstallmentText());
				ioMap.put(tableName2, counter, "AMOUNT", cti.getInstallmentAmount());
				ioMap.put(tableName2, counter, "DESCRIPTION", cti.getInstallmentText());
				ioMap.put(tableName2, counter, "LOAD_AMOUNT", cti.getInstallmentAmount());
				// ioMap.put(tableName2, counter, "OBJECT", cti);
				counter++;
				isPackageExist = true;
			}
			ioMap.put("PACKAGE_ENABLE", isPackageExist ? 1 : 0);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return ioMap;
	}

	@GraymoundService("CDM_GET_SELECTED_OPERATOR_PACKAGE_COMMISSION")
	public static GMMap getSelectedOperatorPackageCommission(GMMap iMap) {
		GMMap outMap = new GMMap();
		Session session = CommonHelper.getHibernateSession();
		try {
			Double commission = (double) 0, amount = (double) 0;
			if (iMap.getString("PACKAGES") != null && iMap.getString("PACKAGES") != "") {
				String pId = iMap.getString("PACKAGES");
				try {
					amount = Double.parseDouble(pId.split("[|]")[1]);
				} catch (Exception e) {
				}
			}

			if (iMap.getString("CORPORATE_CODE") != null && amount != 0) {
				CorporateTlinstallment cti = (CorporateTlinstallment) session.createCriteria(CorporateTlinstallment.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).add(Restrictions.eq("installmentAmount", BigDecimal.valueOf(amount))).uniqueResult();
				commission = (Double) (cti != null ? cti.getCommissionAmount().doubleValue() : Double.valueOf(0));
				outMap.put("COMMISSION", commission);
				outMap.put("TOTAL_AMOUNT", amount + commission);
			} else {
				outMap.put("COMMISSION", "0");
				outMap.put("TOTAL_AMOUNT", amount + commission);
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}

	@GraymoundService("ICS_GET_AVAILABLE_PRODUCTS")
	public static GMMap getAvailableProducts(GMMap iMap) {
		GMMap outMap = new GMMap();
		Session session = CommonHelper.getHibernateSession();
		try {
			String collectionType = iMap.getString(TransactionConstants.DoGSMMoneyLoad.Input.COLLECTION_TYPE);
			if (collectionType == null || collectionType.isEmpty()) {
				collectionType = DatabaseConstants.CollectionTypes.TLLoad;
				iMap.put(TransactionConstants.DoGSMMoneyLoad.Input.COLLECTION_TYPE, collectionType); // COLLECTION_TYPE
																										// =
																										// 1
																										// TL
																										// Yukleme
			}
			if (collectionType.equals(DatabaseConstants.CollectionTypes.TLLoad))
				iMap.put(MapKeys.GM_SERVICE_NAME, "ICS_GET_AVAILABLE_PRODUCTS");
			else if (collectionType.equals(DatabaseConstants.CollectionTypes.InternetPackages))
				iMap.put(MapKeys.GM_SERVICE_NAME, "ICS_GET_AVAILABLE_GPRS_PRODUCTS");
			else if (collectionType.equals(DatabaseConstants.CollectionTypes.VoicePackages))
				iMap.put(MapKeys.GM_SERVICE_NAME, "ICS_GET_AVAILABLE_VOICE_PRODUCTS");

			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			if (corporateCode == null || corporateCode == "") {
				CorporateMaster cm = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("oid", iMap.getString(MapKeys.CORPORATE_OID))).uniqueResult();
				if (cm != null)
					iMap.put(MapKeys.CORPORATE_CODE, cm.getCorporateCode());
			}

			iMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
			outMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}

	// utility function below
	public static String formatTurkcellPrice(Double amount) {
		int n1 = (int) (amount / 1);
		int n2 = (int) ((amount - n1) * 100) / 1;
		return String.format("%08d", n1) + String.format("%02d", n2);
	}

	public static String getStanNo() throws Exception {
		String tableName = "ICS_STAN_FOR_WO_ACCOUNTING";
		return CorporationServiceUtil.getSequenceCode(tableName);

	}
}
