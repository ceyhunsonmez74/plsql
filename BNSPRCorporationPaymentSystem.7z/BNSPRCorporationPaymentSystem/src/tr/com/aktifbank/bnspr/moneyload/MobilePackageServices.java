package tr.com.aktifbank.bnspr.moneyload;

import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeMap;

import model.br.turkcell.com.PayConfirmResponse;
import model.br.turkcell.com.PrepQueryResponse;
import model.ppgw.turkcell.com.GetProductsResponse;
import model.ppgw.turkcell.com.Product;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.corporation.services.OnlineCorporationInterface;
import tr.com.aktifbank.bnspr.corporation.services.OnlineInstitutionConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CollectionTypePrm;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.aktifbank.integration.client.TurkcellClient;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MobilePackageServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {

	private static final Log logger = LogFactory.getLog(MobilePackageServices.class);
	private static final String PAYMENT_SOURCE_KASA = "0";
	private static final String PAYMENT_SOURCE = "GS"; // Gise	

	private static final int TURKCELL_APPL_CODE = 1;
	private static final int TURKCELL_CURRENCY_CODE = 99;
	private static final int TURKCELL_GPRS_RODUCT_TYPE = 4;
	private static final String TURKCELL_PACKAGE_TYPE_D = "D"; // Diger banka vadesiz hesap
	private static final String TURKCELL_PACKAGE_TYPE_N = "N"; // Nakit
	private static final String TURKCELL_DIST_CODE = "0"; // POS harici cihazlar icin 0 olacak
	private static final String TURKCELL_TAM_MERCHANT_CODE = "0"; // POS harici cihazlar icin 0 olacak
	private static final String TURKCELL_TAN_MERCHANT_CODE = "0"; // POS harici cihazlar icin 0 olacak
	private static final String TURKCELL_MSISDN_NOT_FOUND_ERROR = "01"; // Turkcell Abone bulunamadi hatasi mesaj�
	
	//Turkcell Services start	 
	@GraymoundService("ICS_TURKCELL_GPRS_PACKAGE_GET_PRODUCTS")
	public static GMMap getTurkcellSubscriberGPRSProducts(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_GPRS_PACKAGE_GET_PRODUCTS");
		GMMap outMap = new GMMap();
		String tableName = BnsprCommonFunctions.getTableName(iMap);
		try {
			String msisdn = iMap.getString(MapKeys.SUBSCRIBER_NO1);
			String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
			
			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(msisdn) && msisdn.length() == 10) {

				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
				String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String bank = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				long companyId = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
				String stan = iMap.getString(MapKeys.TRX_NO);
				if(stan == null || stan == "") // servis cagrilarinda bos geliyor
					stan = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString("TRX_NO");
				
				stan = stan.substring(stan.length()-6, stan.length());//turkcell tarafinda 6 karakter sinirindan dolayi son 6 basamagini gonderiyoruz
				ServiceMessage sm = new ServiceMessage();
				GetProductsResponse response = TurkcellClient.getProducts(wsUrl, password, Integer.parseInt(stan), userName, TURKCELL_APPL_CODE, bank, companyId, TURKCELL_CURRENCY_CODE, Long.valueOf(msisdn), TURKCELL_GPRS_RODUCT_TYPE, sm );
				String returnCode = "TL" + response.getReturnCode();
				
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(returnCode, null, corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());

				// paket listesi basarili bir sekilde donerse akisa devam edilir
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					// siralama icin treemap de sort ediyoruz
					HashMap<String, String> packageList = new HashMap<String, String>();
					for (Product p : response.getProducts()) {
						if (p.getPaymentType().equals(TURKCELL_PACKAGE_TYPE_D) || p.getPaymentType().equals(TURKCELL_PACKAGE_TYPE_N)) {
							packageList.put(p.getPackageName(), p.getPackageId() + "|" + p.getPrice());									
						}
					}
					TreeMap<String, String> sorted_map = new TreeMap<String, String>(packageList);
					int counter = 0;
					for (Entry<String, String> m : sorted_map.entrySet()) {
						String pName = m.getKey();
						String pId = m.getValue().split("[|]")[0];
						String pPrice = m.getValue().split("[|]")[1];
						
						outMap.put(tableName, counter, "PACKAGE_ID", pId);
						outMap.put(tableName, counter, "DESCRIPTION", pName);
						outMap.put(tableName, counter, "AMOUNT", pPrice);
						outMap.put(tableName, counter, "LOAD_AMOUNT", pPrice);						
						counter++;
					}
				}
				logger.info("ICS_TURKCELL_GPRS_PACKAGE_GET_PRODUCTS called");
				insertOnlineServiceLog(iMap, outMap);
			}else{
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(TURKCELL_MSISDN_NOT_FOUND_ERROR, null, corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_TURKCELL_PAY_GPRS_PACKAGE_AMOUNT")
	public static GMMap payTurkcellGPRSPackageAmount(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_TURKCELL_PAY_GPRS_PACKAGE_AMOUNT");
		GMMap outMap = new GMMap();
		String msisdn;
		try {
			if (iMap.containsKey(MapKeys.SUBSCRIBER_NO1) && !"".equals(iMap.getString(MapKeys.SUBSCRIBER_NO1)) && iMap.getString(MapKeys.SUBSCRIBER_NO1).length() == 10) {
				msisdn = iMap.getString(MapKeys.SUBSCRIBER_NO1);

				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				String userName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
				String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String bank = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				String companyId = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
				String stan = iMap.getString(MapKeys.TRX_NO);
				stan = stan.substring(stan.length()-6, stan.length());
				Date date = new Date();
				String transDate = CommonHelper.getDateString(date, "yyyyMMdd");
				String transTime = CommonHelper.getDateString(date, "HHmmss");
				String returnCode = "00";
				String transPrice = iMap.getString("PAYMENT_AMOUNT");
				String transAmt = iMap.getString("PACKAGE_ID");
				String paymentType = iMap.getString("SOURCE").equals(PAYMENT_SOURCE_KASA) ? TURKCELL_PACKAGE_TYPE_D : TURKCELL_PACKAGE_TYPE_N;
				transPrice = OperatorServices.formatTurkcellPrice(Double.parseDouble(transPrice));
				
				ServiceMessage sm = new ServiceMessage();
				PrepQueryResponse prepQueryResponse = TurkcellClient.preQuery(wsUrl, msisdn, bank, companyId, String.valueOf(TURKCELL_CURRENCY_CODE), TURKCELL_DIST_CODE, password, transDate, returnCode, TURKCELL_TAM_MERCHANT_CODE, TURKCELL_TAN_MERCHANT_CODE, transAmt, transDate, paymentType, transPrice, PAYMENT_SOURCE, transTime, stan, userName, sm );
				returnCode = "TL" + prepQueryResponse.getReturnCode();
				
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(returnCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());

				// yukleme oncesi onay adimlari basarili olursa TL yuklemeye devam edilir
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					PayConfirmResponse payResponse = TurkcellClient.payConfirm(wsUrl, msisdn, bank, companyId, password, prepQueryResponse.getReturnCode(), transDate, stan, userName, sm);
					returnCode = "TL"+ payResponse.getReturnCode();
					responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(returnCode, null, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					// yukleme islemi ok olursa ekran da gosterilecek mesajlar bu servisi cagiran yerde set edilir
					outMap.put("STATUS_CODE", responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put("STATUS_DESC", responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put("TRX_NO", iMap.getString(MapKeys.TRX_NO));
					iMap.put("REQUEST_XML", sm.getRequest());
					outMap.put("RESPONSE_XML", sm.getResponse());
				}
				logger.info("ICS_TURKCELL_PAY_GPRS_PACKAGE_AMOUNT called");
				insertOnlineServiceLog(iMap, outMap);
			}else{
				GMMap responceCodeMap = OnlineCorporationInterface.getResponseCodeMapping(TURKCELL_MSISDN_NOT_FOUND_ERROR, null, iMap.getString(MapKeys.CORPORATE_CODE));
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}
	
	/*
	 * Kurum Bazinda Collection Type listelerini Doneriz, Burda Collection Type Def tablosundan almama nedenimiz fatura tahsilati gibi tiplerin gelmesini istememiz 
	 */
	@GraymoundService("ICS_GET_GSM_PACKAGE_TYPES")
	public static GMMap getGsmPackageTypes(GMMap iMap) {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ICS_GET_GSM_PACKAGE_TYPES");
		GMMap outMap = new GMMap();
		Session session = CommonHelper.getHibernateSession();
		String tableName = BnsprCommonFunctions.getTableName(iMap);
		try {
			CorporateMaster cm = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("status", true)).
					add(Restrictions.eq("oid", iMap.getString(TransactionConstants.DoGSMMoneyLoad.Input.CORPORATE_OID))).uniqueResult();
			CollectionTypePrm tlLoad = (CollectionTypePrm) session.createCriteria(CollectionTypePrm.class).add(Restrictions.eq("collectionType", Short.valueOf(DatabaseConstants.CollectionTypes.TLLoad))).uniqueResult();
			
			outMap.put(tableName, 0, "COLLECTION_TYPE" , tlLoad.getCollectionType());
			outMap.put(tableName, 0, "COLLECTION_NAME" , tlLoad.getCollectionName());

			if(cm.getShortCode().equalsIgnoreCase("TURKCELL")){
				
				//Turkcell de TL yuklemeye ek olarak internet ve voice paketleri olacak
				String internet = CommonHelper.getValueOfParameter("TURKCELL_COLLECTION_TYPES", "INTERNET");
				String konusma = CommonHelper.getValueOfParameter("TURKCELL_COLLECTION_TYPES", "KONUSMA");
				
				if("1".equals(internet)){
					CollectionTypePrm internetPackage = (CollectionTypePrm) session.createCriteria(CollectionTypePrm.class).add(Restrictions.eq("collectionType",  Short.valueOf(DatabaseConstants.CollectionTypes.InternetPackages))).uniqueResult();
					if(internetPackage != null){
						outMap.put(tableName, 1, "COLLECTION_TYPE" , internetPackage.getCollectionType());
						outMap.put(tableName, 1, "COLLECTION_NAME" , internetPackage.getCollectionName());
					}
				}
				
				if("1".equals(konusma)){
					CollectionTypePrm voicePackage = (CollectionTypePrm) session.createCriteria(CollectionTypePrm.class).add(Restrictions.eq("collectionType",  Short.valueOf(DatabaseConstants.CollectionTypes.VoicePackages))).uniqueResult();
					if(voicePackage != null){
						outMap.put(tableName, 2, "COLLECTION_TYPE" , voicePackage.getCollectionType());
						outMap.put(tableName, 2, "COLLECTION_NAME" , voicePackage.getCollectionName());
					}
				}
			}
			
			logger.info("ICS_GET_GSM_PACKAGE_TYPES called");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}
}
