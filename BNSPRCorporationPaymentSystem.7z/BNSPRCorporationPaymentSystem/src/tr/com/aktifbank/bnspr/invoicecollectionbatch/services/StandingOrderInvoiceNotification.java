package tr.com.aktifbank.bnspr.invoicecollectionbatch.services;

public class StandingOrderInvoiceNotification {

}
