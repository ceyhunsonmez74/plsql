package tr.com.aktifbank.bnspr.invoicecollectionbatch.services;

import tr.com.aktifbank.bnspr.cps.transactions.CommitInvoicesHandler;
import tr.com.aktifbank.bnspr.cps.transactions.DebtLineParserHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InvoiceDebtLoadingHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class InvoiceDebtLoading {
	
	/**
	 * @description
	 * @param GMMap logMap
	 * @return GMMap outMap
	 * @history 
	 * 	@author erdogan.demir		
	 *  @date 10.06.2013
	 *  @specification
	 *    try
	 *  	call ICS_INSERT_BATCH_SUBMIT_LOG for submit log with SUBMIT_STATUS 00 (start)
	 *			set START_TIME
	 *      	get SUBMIT_ID from service output
	 *      
	 *      call CDM_GET_CORPORATE_DEFINITION to get corporate main information (values from Corporate_Master)
	 *      	IF check corporate activeness 
	 *      		throw exception
	 *      
	 *      call CDM_GET_CORPORATE_FILE_FORMAT_HEADER to get file format definition
	 *      	get FORMAT_OID from iMap
	 *      	set returns to header_GMMap
	 *      
	 *      call CDM_GET_CORPORATE_FILE_FORMAT_DETAIL to get file format definition
	 *      	get FORMAT_OID from iMap
	 *      	set returns to detail_GMMap
	 *      
	 *      call CDM_GET_CORPORATE_FILE_FORMAT_FOOTER to get file format definition
	 *      	get FORMAT_OID from iMap
	 *      	set returns to footer_GMMap
	 *      
	 *      read FTM.FTM_FILE_CONTENT with FTM_TRANSFER_ID and FTM_ID
	 *      	set values to fileContent object
	 *      
	 *      IF BEKLEYENLERI_SIL is TRUE THEN
	 *      	call ICS_DELETE_WAITED_INVOICE with KURUM_KODU parameter
	 *      		update  all waited invoice () status to ZERO.
	 *      END IF
	 *      
	 *      define a variable name is serviceName
	 *      	serviceName default value is ICS_INSERT_INVOICE
	 *      IF TALIMATLI_YUKLE is TRUE THEN
	 *			serviceName is ICS_INSERT_INVOICE_INVOICE_WITH_STANDING_ORDER
	 *      END IF
	 *      
	 *      create invoice_master instance from InvoiceMaster hibernate object 
	 *      
	 *      FOR each element of fileContent THEN
	 *		    try
	 *				IF INITIAL_CONSTANT (get headerMap) of header parse line for header THEN
	 *					header_line_count + 1
	 *				END IF 
	 *
	 *				IF INITIAL_CONSTANT (get detailMap) of detail parse line for header THEN
	 *					parse detail line
	 *						get parsed values in GMMap
	 *					fill invoice_master object
	 *						put values into invoice_master
	 *							key : get DB_FIELD from detailMap
	 *							value : value from line
	 *						set KURUM_KODU into invoice_master
	 *						set FTM_TRANSFER_ID into invoice_master
	 *						detail_line_count + 1
	 *						totalInvoiceAmount = totalInvoiceAmount + invoiceAmount
	 *					 	set STATUS = ZERO into invoice_master
	 *				   IF size of invoice_master hibenate object > COMMIT_COUNT (exist in iMap) THEN
	 *						push hibernate object
	 *						clear hibernate object
	 *				   END IF
	 *				END IF
	 *
	 *				IF INITIAL_CONSTANT (get footerMap) of footer parse line for header THEN
	 *					footer_line_count + 1
	 *					IF "Toplam Tutar" or "Toplam Adet" find in footerMap THEN
	 *						footerControl is TRUE
	 *						parse "Toplam Adet" and set footerTotalCount
	 *						parse "Toplam Tutar" and set footerTotalAmount
	 *					END
	 *				END IF
	 *			catch
	 *				
	 *      END FOR
	 *      
	 *      IF footerControl is TURE THEN
	 *      	IF footerTotalCount <> detail_line_count THEN
	 *      		throw exception
	 *      	END IF
	 *      	IF footerTotalAmount <> totalInvoiceAmount THEN
	 *      		throw exception
	 *      	END IF
	 *      END IF
	 *  	
	 *  	Update invoice records STATUS = 1
	 *  		Select * from Invoice_master
	 *  			where status =0 and corporate_code = ? and ftm_sequence_number= ?
	 *  
	 *  	call ICS_INSERT_BATCH_SUBMIT_LOG for submit log with SUBMIT_STATUS 99 (successful finish)
	 *			set END_TIME
	 *      
	 *    catch exception 
	 *  	call ICS_INSERT_BATCH_SUBMIT_LOG for update submit log with SUBMIT_STATUS 88 (failure)
	 *  		set SUBMIT_ID
	 *      	set ERROR_CODE and ERROR_DESC
	 *      
	 */
	 @GraymoundService("ICS_BATCH_INVOICE_DEBT_LOADING")
	 public static GMMap invoiceDebtLoading (GMMap iMap) {
		 return RequestProcessor.getInstance().process(iMap, new InvoiceDebtLoadingHandler());
	 }
	 
	 @GraymoundService("ICS_DEBT_LINE_PARSER")
	 public static GMMap parseDebtLines (GMMap iMap) {
		 return RequestProcessor.getInstance().process(iMap, new DebtLineParserHandler());
	 }
	 
	 @GraymoundService("ICS_GET_DEBT_LINES")
	 public static GMMap getDebtLines(GMMap iMap) {
		 GMMap output = new GMMap();
		 try{
			 String fetchQuery = String.format("SELECT line_number, line FROM (SELECT rownum rnum, ffc.* FROM ftm.ftm_file_content ffc WHERE ffc.ftm_process_oid=%s AND rownum < %s) WHERE rnum >= %s",
					iMap.getBigDecimal("FTM_ID"), iMap.getInt("PAGE_END"), iMap.getInt("PAGE_START"));
			final String tableName = "DebtLines";
			output = DALUtil.getResults(fetchQuery, tableName);
		 }
		 catch(Exception e){
			 throw ExceptionHandler.convertException(e);
		 }
		 
		 return output;
	 }
	 
	 @GraymoundService("ICS_COMMIT_INVOICES")
	 public static GMMap commitInvoices(GMMap input){
		 return RequestProcessor.getInstance().process(input, new CommitInvoicesHandler());
	 }

}
