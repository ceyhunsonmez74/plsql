package tr.com.aktifbank.bnspr.eccps;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.corporation.services.OnlineCorporationInterface;
import tr.com.aktifbank.bnspr.corporation.services.OnlineInstitutionConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.EccpsCreditLoadLog;
import tr.com.aktifbank.integration.eskomEccps.EskomEccpsClient;
import tr.com.aktifbank.integration.eskomEccps.ServiceMessage;
import tr.com.eskom.ws.onodemelinakit.KartliAboneBilgisiResponseType;
import tr.com.eskom.ws.onodemelinakit.KartliSayacTahsilatBilgileriResponseType;
import tr.com.eskom.ws.onodemelinakit.SuTonajiHesaplamaResponseType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EskomEccpsServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(EskomEccpsServices.class);
	private static final long BAYLAN_ID=28202;//saya� model bilgisi ile alakal�
	private static final String KIOSK_ID="1";//
	private static final int SALES_NUMBER=1;//
	private static final int CASH_TYPE=4201;//
	private static final String APPROVE="00";//
	private static final String DELIMITER="~";//
	
	


	@GraymoundService("ECCPS_ESKOM_GET_SUBSCRIBER_INFO")
	public static GMMap getSubscriberInfo(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ESKOM_GET_SUBSCRIBER_INFO");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		String suAboneNo = cardInfo.split(DELIMITER)[0] ;
		String suSayacNo = cardInfo.split(DELIMITER)[1] ;
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			KartliAboneBilgisiResponseType returnMessage = EskomEccpsClient.kartliAboneBilgisi(reqTimeout, connTimeout, url, username, password, serviceMessage, KIOSK_ID, SALES_NUMBER, BAYLAN_ID, suAboneNo, suSayacNo);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.Eksws.RETURN_MESSAGE, returnMessage);
			outMap.put("RETURN_CODE", "0");
			outMap.put("RETURN_INFO", returnMessage);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
		}
		catch (Exception e) {
			logger.error("ECCPS_ESKOM_GET_SUBSCRIBER_INFO -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}



	@GraymoundService("ECCPS_ESKOM_CALCULATE_LOAD_AMOUNT")
	public static GMMap eksCalculateLoadAmount(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ESKOM_CALCULATE_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		String ton = iMap.getString(MapKeys.Eksws.TON);
		BigDecimal amount = iMap.getBigDecimal(MapKeys.Eksws.MONEY);
		ServiceMessage serviceMessage = new ServiceMessage();
		boolean callCorporate = true;
		try {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
			if (!ton.equals("")) {
				if (!amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden sadece birinin girilmesi gerekir!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (ton.equals("")) {
				if (amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden birinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (callCorporate) {
				String suAboneNo = cardInfo.split(DELIMITER)[0] ;
				String suSayacNo = cardInfo.split(DELIMITER)[1] ;
				SuTonajiHesaplamaResponseType returnMessage = EskomEccpsClient.suTonajiHesaplama(reqTimeout, connTimeout, url, username, password, serviceMessage, KIOSK_ID, SALES_NUMBER, BAYLAN_ID, suAboneNo, amount, suSayacNo);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RETURN_XML", serviceMessage.getResponse());
				
				if (returnMessage.getGenelSonuc().getKod().equals(APPROVE)) {
					outMap.put("RETURN_CODE", "0");
					outMap.put("RETURN_INFO", returnMessage.getSuTutari()+"~" + returnMessage.getYuklenenSuTonaji());
				}
				else 
				{
					outMap.put("RETURN_CODE", "1");
					outMap.put("RETURN_INFO", returnMessage.getGenelSonuc().getMesaj());
				}
				
			
			}
		}
		catch (Exception e) {
			logger.error("ECCPS_ESKOM_CALCULATE_LOAD_AMOUNT -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ECCPS_ESKOM_LOAD_MONEY")
	public static GMMap eksLoadMoney(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ESKOM_LOAD_MONEY");
		GMMap outMap = new GMMap();
				
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		String ton = iMap.getString(MapKeys.Eksws.TON);
		BigDecimal amount = iMap.getBigDecimal(MapKeys.Eksws.MONEY);
		String paymentType = iMap.getString(MapKeys.PAYMENT_TYPE);
		ServiceMessage serviceMessage = new ServiceMessage();
		boolean callCorporate = true;
		outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
		outMap.put(MapKeys.ERROR_DESC, "");
		try {
			if (!ton.equals("")) {
				if (!amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden sadece birinin girilmesi gerekir!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (ton.equals("")) {
				if (amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden birinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (callCorporate) {
				String suAboneNo = cardInfo.split(DELIMITER)[0] ;
				String suSayacNo = cardInfo.split(DELIMITER)[1] ;
				KartliSayacTahsilatBilgileriResponseType returnMessage = EskomEccpsClient.kartliSayacTahsilatBilgileri(reqTimeout, connTimeout, url, username, password, serviceMessage, KIOSK_ID, SALES_NUMBER, BAYLAN_ID, suAboneNo, amount, suSayacNo, CASH_TYPE);
				iMap.put("REQUEST_XML_LOAD", serviceMessage.getRequest());
				outMap.put("RETURN_XML_LOAD", serviceMessage.getResponse());
				if (returnMessage.getGenelSonuc().getKod().equals(APPROVE)) {
					outMap.put("RETURN_CODE", "0");
					outMap.put("RETURN_INFO", returnMessage.getGenelSonuc().getKod()+ "##"+ returnMessage.getGenelSonuc().getMesaj());
				}
				else 
				{
					outMap.put("RETURN_CODE", "1");
					outMap.put("RETURN_INFO", returnMessage.getGenelSonuc().getMesaj());}
				}
		}
		catch (Exception e) {
			logger.error("ECCPS_ESKOM_LOAD_MONEY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}


}
