package tr.com.aktifbank.bnspr.eccps;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.corporation.services.OnlineCorporationInterface;
import tr.com.aktifbank.bnspr.corporation.services.OnlineInstitutionConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.EccpsCreditLoad;
import tr.com.aktifbank.bnspr.dao.EccpsCreditLoadLog;
import tr.com.aktifbank.integration.eccps.EccpsClient;
import tr.com.aktifbank.integration.eccps.ServiceMessage;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class OrduEccpsServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(OrduEccpsServices.class);
	private static final String CARD_INFO_PREFIX="WSEKS~1~";//saya� model bilgisi ile alakal� kurum eklenmesini istedi

	@GraymoundService("ECCPS_ORDU_GET_SUBSCRIBER_INFO")
	public static GMMap getSubscriberInfo(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ORDU_GET_SUBSCRIBER_INFO");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		cardInfo=CARD_INFO_PREFIX+cardInfo;
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String returnMessage = EccpsClient.eksCardSubscriberInfo(cardInfo, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.Eksws.RETURN_MESSAGE, returnMessage);
			outMap.put("RETURN_CODE", "0");
			outMap.put("RETURN_INFO", returnMessage);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
		}
		catch (Exception e) {
			logger.error("ECCPS_ORDU_GET_SUBSCRIBER_INFO -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ECCPS_ORDU_GET_MINIMUM_LOAD_AMOUNT")
	public static GMMap getMinimumLoadAmount(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ORDU_GET_MINIMUM_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		cardInfo=CARD_INFO_PREFIX+cardInfo;
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String returnMessage = EccpsClient.eksMinimumPaymentAmount(cardInfo, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			outMap.put("RETURN_CODE", "0");
			outMap.put("RETURN_INFO", returnMessage);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
		}
		catch (Exception e) {
			logger.error("ECCPS_ORDU_GET_MINIMUM_LOAD_AMOUNT -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ECCPS_ORDU_CALCULATE_LOAD_AMOUNT")
	public static GMMap eksCalculateLoadAmount(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ORDU_CALCULATE_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		cardInfo=CARD_INFO_PREFIX+cardInfo;

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		String ton = iMap.getString(MapKeys.Eksws.TON);
		String amount = iMap.getString(MapKeys.Eksws.MONEY);
		ServiceMessage serviceMessage = new ServiceMessage();
		boolean callCorporate = true;
		try {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
			if (!ton.equals("")) {
				if (!amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden sadece birinin girilmesi gerekir!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (ton.equals("")) {
				if (amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden birinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (callCorporate) {
				String returnMessage = EccpsClient.eksCalculate(cardInfo, ton, amount, username, password, url, serviceMessage);
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RETURN_XML", serviceMessage.getResponse());
				outMap.put("RETURN_CODE", "0");
				outMap.put("RETURN_INFO", returnMessage);
			}
		}
		catch (Exception e) {
			logger.error("ECCPS_ORDU_CALCULATE_LOAD_AMOUNT -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ECCPS_ORDU_LOAD_MONEY")
	public static GMMap eksLoadMoney(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ORDU_LOAD_MONEY");
		GMMap outMap = new GMMap();
				
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		cardInfo=CARD_INFO_PREFIX+cardInfo;

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		String ton = iMap.getString(MapKeys.Eksws.TON);
		String amount = iMap.getString(MapKeys.Eksws.MONEY);
		String paymentType = iMap.getString(MapKeys.PAYMENT_TYPE);
		ServiceMessage serviceMessage = new ServiceMessage();
		boolean callCorporate = true;
		outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
		outMap.put(MapKeys.ERROR_DESC, "");
		try {
			if (!ton.equals("")) {
				if (!amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden sadece birinin girilmesi gerekir!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (ton.equals("")) {
				if (amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden birinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (callCorporate) {
				String returnMessage = EccpsClient.eksLoad(cardInfo, ton, amount, paymentType, username, password, url, serviceMessage);
				iMap.put("REQUEST_XML_LOAD", serviceMessage.getRequest());
				outMap.put("RETURN_XML_LOAD", serviceMessage.getResponse());
				if (returnMessage.contains("Code")) {
					// hata olustu
					outMap.put("RETURN_CODE", returnMessage.substring(5, 8));
					outMap.put("RETURN_INFO", returnMessage);
				}
				else {
					String returnAslist[] = returnMessage.split("\\#\\#");
					BigDecimal loadedAmount = new  BigDecimal(returnAslist[2]);
					String accuredNumber = returnAslist[7];
					String receiptSerial = returnAslist[8];
					String receiptNumber = returnAslist[9];
					String subscriberNo = returnAslist[10];
					String returnMessageInsert = EccpsClient.insertCardRecord(cardInfo, receiptNumber, receiptSerial, accuredNumber, username, password, url, serviceMessage);
					iMap.put("REQUEST_XML_INSERT_CARD_RECORD", serviceMessage.getRequest());
					outMap.put("RETURN_XML_INSERT_CARD_RECORD", serviceMessage.getResponse());
					if (returnMessageInsert.contains("Code")) {
						// karta yazma s�ras�nda hata meydana geldi
						// iptal yap
						outMap.put(MapKeys.Eksws.ACCURED_NUMBER, accuredNumber);
						outMap.put("RETURN_CODE", returnMessageInsert.substring(5, 8));
						outMap.put("RETURN_INFO", returnMessageInsert);
						String returnMessageCancel = EccpsClient.eksCancelPayment(receiptNumber, receiptSerial, accuredNumber, username, password, url, serviceMessage);
						outMap.put("RETURN_CODE", returnMessageCancel.substring(5, 8));
						outMap.put("RETURN_INFO", returnMessageCancel);
						iMap.put("REQUEST_XML_CANCEL", serviceMessage.getRequest());
						outMap.put("RETURN_XML_CANCEL", serviceMessage.getResponse());
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
						outMap.put(MapKeys.ERROR_CODE, "Karta yazma s�ras�nda hata meydana geldi".concat(returnMessageCancel));
					}
					else {
						// karta basarili olarak yazildi
						// tablolar� update et
						Session session = DAOSession.getSession("BNSPRDal");
						Criteria cr = session.createCriteria(EccpsCreditLoadLog.class);
						cr.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO)));
						EccpsCreditLoadLog creditLoad = (EccpsCreditLoadLog) cr.uniqueResult();
						creditLoad.setAccuredNumber(accuredNumber);
						creditLoad.setReceiptSerial(receiptSerial);
						creditLoad.setReceiptNo(receiptNumber);
						creditLoad.setLoadedAmount(loadedAmount);
						session.saveOrUpdate(creditLoad);
						outMap.put(MapKeys.Eksws.ACCURED_NUMBER, accuredNumber);
						outMap.put(MapKeys.Eksws.RECEIPT_NO, receiptNumber);
						outMap.put(MapKeys.Eksws.RECEIPT_SERIAL, receiptSerial);
						outMap.put("RETURN_CODE", "0");
						outMap.put("RETURN_INFO", returnMessage);
					}
				}
			}
		}
		catch (Exception e) {
			logger.error("ECCPS_ORDU_LOAD_MONEY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ECCPS_ORDU_INSERT_CARD_INFO")
	public static GMMap insertCardInfo(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ORDU_INSERT_CARD_INFO");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		cardInfo=CARD_INFO_PREFIX+cardInfo;

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		String invoiceNo = iMap.getString(MapKeys.Eksws.RECEIPT_NO);
		String invoiceSerial = iMap.getString(MapKeys.Eksws.RECEIPT_SERIAL);
		String debtNo = iMap.getString(MapKeys.Eksws.ACCURED_NUMBER);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String returnMessage = EccpsClient.insertCardRecord(cardInfo, invoiceNo, invoiceSerial, debtNo, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			outMap.put("RETURN_CODE", "0");
			outMap.put("RETURN_INFO", returnMessage);
		}
		catch (Exception e) {
			logger.error("ECCPS_ORDU_INSERT_CARD_INFO -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ECCPS_ORDU_CANCEL_LOAD_MONEY")
	public static GMMap cancelLoadMoney(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_ORDU_CANCEL_LOAD_MONEY");
		GMMap outMap = new GMMap();
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		String invoiceNo = iMap.getString(MapKeys.Eksws.RECEIPT_NO);
		String invoiceSerial = iMap.getString(MapKeys.Eksws.RECEIPT_SERIAL);
		String debtNo = iMap.getString(MapKeys.Eksws.ACCURED_NUMBER);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String returnMessage = EccpsClient.eksCancelPayment(invoiceNo, invoiceSerial, debtNo, username, password, url, serviceMessage);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			if (returnMessage.equals("OK")) {
				outMap.put("RETURN_CODE", "0");
			} else {
				outMap.put("RETURN_CODE", "-1");
			}
			outMap.put("RETURN_INFO", returnMessage);
		}
		catch (Exception e) {
			logger.error("ECCPS_ORDU_CANCEL_LOAD_MONEY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}	

}
