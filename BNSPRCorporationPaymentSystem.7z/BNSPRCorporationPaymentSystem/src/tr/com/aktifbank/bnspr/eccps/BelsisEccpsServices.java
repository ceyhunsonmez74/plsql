package tr.com.aktifbank.bnspr.eccps;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.corporation.services.OnlineCorporationInterface;
import tr.com.aktifbank.bnspr.corporation.services.OnlineInstitutionConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.belsis.BelsisClient;
import tr.com.aktifbank.integration.belsis.ServiceMessage;
import tr.com.belsis.odemeservis.Abone;
import tr.com.belsis.odemeservis.SuHesapSonuc;
import tr.com.belsis.odemeservis.SuTahakkukSonuc;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class BelsisEccpsServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(BelsisEccpsServices.class);
	
	private static final String SOURCE_CODE_DEFAULT = "2";


	@GraymoundService("ECCPS_BELSIS_GET_SUBSCRIBER_INFO")
	public static GMMap getSubscriberInfo(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_BELSIS_GET_SUBSCRIBER_INFO");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String kurumKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

		String kartNo = cardInfo;
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			Abone returnMessage = BelsisClient.suKartNoAboneSorgula(reqTimeout, connTimeout, url, username, password, serviceMessage, bankaKodu, kurumKodu, kartNo);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.Eksws.RETURN_MESSAGE, returnMessage.getSonucKodu1());
			outMap.put("RETURN_CODE", "0");
			outMap.put("RETURN_INFO", returnMessage.getSonucAciklamasi());
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
		}
		catch (Exception e) {
			logger.error("ECCPS_BELSIS_GET_SUBSCRIBER_INFO -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}



	@GraymoundService("ECCPS_BELSIS_CALCULATE_LOAD_AMOUNT")
	public static GMMap eksCalculateLoadAmount(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_BELSIS_CALCULATE_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String responseMessage = "";	
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);


		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String kurumKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
		String ton = iMap.getString(MapKeys.Eksws.TON);
		
		ServiceMessage serviceMessage = new ServiceMessage();
		boolean callCorporate = true;
		try {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
			
			if (StringUtil.isEmpty(ton)) {
					outMap.put("RETURN_INFO", "Ton de�erinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
			}
			
			if (callCorporate) {
			
				ServiceMessage serviceMessageQuery = new ServiceMessage();
				Abone abone = BelsisClient.suKartNoAboneSorgula(reqTimeout, connTimeout, url, username, password, serviceMessageQuery, bankaKodu, kurumKodu, cardInfo);
				
				responceCodeMap = getResponseCodeMapping(Integer.toString(abone.getSonucKodu()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCodeQuery = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

				iMap.put("REQUEST_XML_QUERY_SUBSCRIBER", serviceMessageQuery.getRequest());
				outMap.put("RETURN_XML_QUERY_SUBSCRIBER", serviceMessageQuery.getResponse());
				if (GeneralConstants.ERROR_CODE_APPROVE.equals(errorCodeQuery)) {
					SuHesapSonuc response = null;
					try {
						response = BelsisClient.suTutarHesapla(reqTimeout, connTimeout, url, username, password, serviceMessage, bankaKodu, kurumKodu, abone.getAboneNo(), CommonHelper.getMonth(new Date()), new BigDecimal(ton), CommonHelper.convertDate2GregorianCalendar(new Date()), 1, CommonHelper.getYear(new Date()));
						responseCode = Integer.toString(response.getSonucKodu());
						responseMessage = response.getSonucAciklamasi();
					} catch (Exception ex) {
						logger.error("ECCPS_BELSIS_CALCULATE_LOAD_AMOUNT for ".concat(corporateCode).concat(" - an error is occured ()"));
						responseCode = Integer.toString(response.getSonucKodu());
						responseMessage = response.getSonucAciklamasi();
						logger.info("ECCPS_BELSIS_CALCULATE_LOAD_AMOUNT error code = ".concat(responseCode));
						logger.info("ECCPS_BELSIS_CALCULATE_LOAD_AMOUNT error message = ".concat(responseMessage));
					}			
					
					CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					
					iMap.put("REQUEST_XML", serviceMessage.getRequest());
					outMap.put("RETURN_XML", serviceMessage.getResponse());
					
					if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							outMap.put("RETURN_CODE", "0");
							outMap.put("RETURN_INFO", response.getFaturaTutari()+"~" + ton);
						}
						else 
						{
							outMap.put("RETURN_CODE", "1");
							outMap.put("RETURN_INFO", response.getSonucAciklamasi());
						}
					}
				}

		
		}
		catch (Exception e) {
			logger.error("ECCPS_BELSIS_CALCULATE_LOAD_AMOUNT -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}

	@GraymoundService("ECCPS_BELSIS_LOAD_MONEY")
	public static GMMap eksLoadMoney(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_BELSIS_LOAD_MONEY");
		GMMap outMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		long sicil = 0;
		int aboneNo = 0;

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
		String bankaKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String kurumKodu = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
		String corporateCodeWater = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
		String ton = iMap.getString(MapKeys.Eksws.TON);
		BigDecimal amount = iMap.getBigDecimal(MapKeys.Eksws.MONEY);
		ServiceMessage serviceMessage = new ServiceMessage();
		boolean callCorporate = true;
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String responseMessage = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
		outMap.put(MapKeys.ERROR_DESC, "");
		SuTahakkukSonuc response = null;
		try {

			if (StringUtil.isEmpty(ton)) {
				outMap.put("RETURN_INFO", "Ton de�erinin girilmesi zorunludur!");
				outMap.put("RETURN_CODE", "1");
				callCorporate = false;
			}

			if (callCorporate) {
				
				ServiceMessage serviceMessageQuery = new ServiceMessage();
				Abone abone = BelsisClient.suKartNoAboneSorgula(reqTimeout, connTimeout, url, username, password, serviceMessageQuery, bankaKodu, kurumKodu, cardInfo);
				
				responceCodeMap = getResponseCodeMapping(Integer.toString(abone.getSonucKodu()), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCodeQuery = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

				iMap.put("REQUEST_XML_QUERY_SUBSCRIBER", serviceMessageQuery.getRequest());
				outMap.put("RETURN_XML_QUERY_SUBSCRIBER", serviceMessageQuery.getResponse());
				if (GeneralConstants.ERROR_CODE_APPROVE.equals(errorCodeQuery)) {
					aboneNo = abone.getAboneNo();
					sicil = abone.getSicilNo();
					try {
						response = BelsisClient.suTahakkuk(reqTimeout, connTimeout, url, username, password, serviceMessage, bankaKodu, kurumKodu, aboneNo,
								CommonHelper.getMonth(new Date()), new BigDecimal(ton), CommonHelper.convertDate2GregorianCalendar(new Date()), 1, CommonHelper.getYear(new Date()));
						responseCode = Integer.toString(response.getSonucKodu());
						responseMessage = response.getSonucAciklamasi();
					} catch (Exception ex) {
						logger.error("ECCPS_BELSIS_LOAD_MONEY for ".concat(corporateCode).concat(" - an error is occured ()"));
						responseCode = Integer.toString(response.getSonucKodu());
						responseMessage = response.getSonucAciklamasi();
						logger.info("ECCPS_BELSIS_LOAD_MONEY error code = ".concat(responseCode));
						logger.info("ECCPS_BELSIS_LOAD_MONEY error message = ".concat(responseMessage));
					}

					CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

					responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

					iMap.put("REQUEST_XML_LOAD", serviceMessage.getRequest());
					outMap.put("RETURN_XML_LOAD", serviceMessage.getResponse());

					if (GeneralConstants.ERROR_CODE_APPROVE.equals(responceCodeMap.getString(MapKeys.ERROR_CODE))) {
										
						GMMap onlineCorporateServiceCallInputMap = new GMMap();

						if (GeneralConstants.ERROR_CODE_APPROVE.equals(errorCodeQuery)) {
							GMMap doInvoiceMap = new GMMap();
							String sicilNo = String.valueOf(sicil);
							doInvoiceMap.put(MapKeys.SUBSCRIBER_NO1, cardInfo);
							doInvoiceMap.put(MapKeys.SUBSCRIBER_NO2, aboneNo);
							doInvoiceMap.put(MapKeys.CORPORATE_CODE, corporateCodeWater);
							doInvoiceMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							doInvoiceMap.put(MapKeys.PARAMETER2, sicilNo);
							doInvoiceMap.put(MapKeys.PAYMENT_AMOUNT, response.getTahakkukListesi().getBorcluTahakkuk().get(0).getOdenecekTutar());
							doInvoiceMap.put(MapKeys.SOURCE, SOURCE_CODE_DEFAULT);
							doInvoiceMap.put(MapKeys.COLLECTION_TYPE, 0);
							doInvoiceMap.put(MapKeys.INVOICE_NO, response.getTahakkukListesi().getBorcluTahakkuk().get(0).getTahakkukNo());
							doInvoiceMap.put(MapKeys.TRX_NO, iMap.getString(MapKeys.TRX_NO));
							doInvoiceMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION_FOR_EKS");
							
							String corporateOid = CommonBusinessOperations.getCorporateOidFromCorporateCode(corporateCodeWater);
							Session session = CommonHelper.getHibernateSession();
							List<CorporationAccountMaster> list = session.createCriteria(CorporationAccountMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateOid", corporateOid)).add(Restrictions.eq("accountDefinitionType", DatabaseConstants.AccountDefinitionTypes.CollectionAccount)).list();
							
							BigDecimal accountNo = list.get(0).getAccountNumber();
							
							invoicePayment payment = new invoicePayment();
							payment.setStatus(true);
							payment.setCorporateCode(corporateCodeWater);
							payment.setCollectionType(Short.valueOf("0"));
							payment.setInvoiceMainOid("0");
							payment.setSubscriberNo1(cardInfo);
							payment.setInvoiceNo(response.getTahakkukListesi().getBorcluTahakkuk().get(0).getTahakkukNo());
							payment.setPaymentStatus(PaymentStatuses.Collected);
							payment.setTxNo(iMap.getBigDecimal(MapKeys.TRX_NO));
							payment.setInvoiceAmount(response.getTahakkukListesi().getBorcluTahakkuk().get(0).getOdenecekTutar());
							payment.setPaymentAmount(response.getTahakkukListesi().getBorcluTahakkuk().get(0).getOdenecekTutar());
							payment.setPaymentDate(CommonHelper.getLongDateTimeString(new Date()));
							payment.setCorporateAccountNo(accountNo);
							session.saveOrUpdate(payment);

							doInvoiceMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", doInvoiceMap);

							if (GeneralConstants.ERROR_CODE_APPROVE.equals(doInvoiceMap.getString(MapKeys.ERROR_CODE))) {
								payment.setStatus(true);
								session.saveOrUpdate(payment);

								outMap.put("RETURN_CODE", "0");
								outMap.put("RETURN_INFO", response.getTahakkukListesi().getBorcluTahakkuk().get(0).getTahakkukNo() + "##" + response.getSonucAciklamasi());
							} else {
								payment.setStatus(false);
								session.saveOrUpdate(payment);
								
								outMap.put("RETURN_CODE", "1");
								outMap.put("RETURN_INFO", doInvoiceMap.getString(MapKeys.ERROR_CODE));
							}
						}

					} else {
						outMap.put("RETURN_CODE", "1");
						outMap.put("RETURN_INFO", response.getSonucAciklamasi());
					}
				}

				
				
			}
		} catch (Exception e) {
			logger.error("ECCPS_BELSIS_LOAD_MONEY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}


}
