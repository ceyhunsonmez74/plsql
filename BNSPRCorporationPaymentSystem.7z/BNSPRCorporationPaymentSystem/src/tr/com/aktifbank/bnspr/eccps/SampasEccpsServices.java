package tr.com.aktifbank.bnspr.eccps;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.corporation.services.OnlineCorporationInterface;
import tr.com.aktifbank.bnspr.corporation.services.OnlineInstitutionConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.EccpsCreditLoad;
import tr.com.aktifbank.bnspr.dao.EccpsCreditLoadLog;
import tr.com.aktifbank.integration.sampas.SampasClient;
import tr.com.aktifbank.integration.sampasEks.SampasEksClient;
import tr.com.aktifbank.integration.sampasEks.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.sampas.akos.service.AkosException;
import com.sampas.akos.service.AkosResponce;
import com.sampas.akos.service.BakiyeV2;
import com.sampas.akos.service.CalculateWaterAmountResponseType;
import com.sampas.akos.service.CreateAccuralResponseType;
import com.sampas.akos.service.LimitPriceResponseType;
import com.sampas.akos.service.Mutabakat;
import com.sampas.akos.service.OperateCreditV2ResponseType;
import com.sampas.akos.service.QueryCreditResponseType;
import com.sampas.akos.service.SearchUserResponseType;

public class SampasEccpsServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(SampasEccpsServices.class);
	private static final String STATUS_NEW  = "0";
	private static final String STATUS_UPDATE  = "1";
	private static final String STATUS_DELETE  = "2";
	private static final String SUCCESS  = "1";
	private static final String WS_RESPONSE_CODE="WS_RESPONSE_CODE";
	private static final String WS_RESPONSE_MESSAGE="WS_RESPONSE_MESSAGE";

	@GraymoundService("ECCPS_SAMPAS_GET_SUBSCRIBER_INFO")
	public static GMMap getSubscriberInfo(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_SAMPAS_GET_SUBSCRIBER_INFO");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		int connTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER1);
		int reqTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER2);
		String queryType =iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER3);

		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			SearchUserResponseType returnMessage = SampasEksClient.searchUser(reqTimeout, connTimeout, url, username, password, serviceMessage, cardInfo, queryType);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			outMap.put(MapKeys.Eksws.RETURN_MESSAGE, returnMessage.getResult().get(0).getRegistrationId());
			outMap.put("RETURN_CODE", "0");
			outMap.put("RETURN_INFO", returnMessage);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
		}
		catch (Exception e) {
			logger.error("ECCPS_SAMPAS_GET_SUBSCRIBER_INFO -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ECCPS_SAMPAS_GET_MINIMUM_LOAD_AMOUNT")
	public static GMMap getMinimumLoadAmount(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_SAMPAS_GET_MINIMUM_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		ServiceMessage serviceMessage = new ServiceMessage();
		int connTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER1);
		int reqTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER2);
		String queryType =iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER3);

		try {
			
			SearchUserResponseType returnMessageSearch = SampasEksClient.searchUser(reqTimeout, connTimeout, url, username, password, serviceMessage, cardInfo, queryType);
			
			String region = returnMessageSearch.getResult().get(0).getRegistrationId();
			String waterMeterId= returnMessageSearch.getResult().get(0).getWaterMeter().getWaterMeterId();
			Long regionCode=new Long(region);
			Long subscriberType=new Long(0);
			LimitPriceResponseType returnMessage = SampasEksClient.searchLimitPrice(reqTimeout, connTimeout, url, username, password, serviceMessage, regionCode, subscriberType);
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			outMap.put("RETURN_CODE", "0");
			outMap.put("RETURN_INFO", returnMessage);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
		}
		catch (Exception e) {
			logger.error("ECCPS_SAMPAS_GET_MINIMUM_LOAD_AMOUNT -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ECCPS_SAMPAS_CALCULATE_LOAD_AMOUNT")
	public static GMMap eksCalculateLoadAmount(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_SAMPAS_CALCULATE_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		String amountOfWater = iMap.getString(MapKeys.Eksws.TON);
		String amountOfMoney = iMap.getString(MapKeys.Eksws.MONEY);
		ServiceMessage serviceMessageSearch = new ServiceMessage();
		ServiceMessage serviceMessageCalculate = new ServiceMessage();

		int connTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER1);
		int reqTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER2);
		String queryType =iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER3);

	
		
		boolean callCorporate = true;
		try {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			outMap.put(MapKeys.ERROR_DESC, "");
			if (!"".equals(amountOfWater)) {
				if (!"".equals(amountOfMoney)) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden sadece birinin girilmesi gerekir!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (!"".equals(amountOfWater)) {
				if (!"".equals(amountOfMoney)) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden birinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (callCorporate) {
				if ("".equals(amountOfWater)) {
					amountOfWater="0";
				}
				
				SearchUserResponseType returnMessageSearch = SampasEksClient.searchUser(reqTimeout, connTimeout, url, username, password, serviceMessageSearch, cardInfo, queryType);
				iMap.put("REQUEST_XML_SEARCH", serviceMessageSearch.getRequest());
				outMap.put("RETURN_XML_SEARCH", serviceMessageSearch.getResponse());
//				if (returnMessageSearch.get) {
//					
//				}
				String registrationId = returnMessageSearch.getResult().get(0).getRegistrationId();
//				String waterMeterId= returnMessageSearch.getResult().get(0).getWaterMeter().getWaterMeterId();
				
				CalculateWaterAmountResponseType returnMessage = SampasEksClient.calculateWaterAmount(reqTimeout, connTimeout, url, username, password, serviceMessageCalculate, amountOfMoney, amountOfWater, registrationId, cardInfo);
				iMap.put("REQUEST_XML_CALCULATE", serviceMessageCalculate.getRequest());
				outMap.put("RETURN_XML_CALCULATE", serviceMessageCalculate.getResponse());
				
				outMap.put("RETURN_CODE", "0");
				outMap.put("RETURN_INFO", returnMessage.getResult().getAmountOfMoney()+"~" +returnMessage.getResult().getAmountOfWater().getValue());
			}
		}
		catch (Exception e) {
			logger.error("ECCPS_SAMPAS_CALCULATE_LOAD_AMOUNT -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ECCPS_SAMPAS_LOAD_MONEY")
	public static GMMap eksLoadMoney(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_SAMPAS_LOAD_MONEY");
		GMMap outMap = new GMMap();
		
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		String amountOfWater = iMap.getString(MapKeys.Eksws.TON);
		String amountOfMoney = iMap.getString(MapKeys.Eksws.MONEY);
		
		ServiceMessage serviceMessageSearch = new ServiceMessage();
		ServiceMessage serviceMessageCreate = new ServiceMessage();
		ServiceMessage serviceMessageQuery = new ServiceMessage();
		ServiceMessage serviceMessageOperate = new ServiceMessage();
		ServiceMessage serviceMessage = new ServiceMessage();

		boolean callCorporate = true;
		outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
		outMap.put(MapKeys.ERROR_DESC, "");
		int connTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER1);
		int reqTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER2);
		String queryType =iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER3);
		
		
		try {
		
			if (amountOfWater.equals("")) {
				if (amountOfMoney.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden birinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (callCorporate) {
				
				SearchUserResponseType returnMessageSearch = SampasEksClient.searchUser(reqTimeout, connTimeout, url, username, password, serviceMessageSearch, cardInfo, queryType);
				iMap.put("REQUEST_XML_SEARCH", serviceMessageSearch.getRequest());
				outMap.put("RETURN_XML_SEARCH", serviceMessageSearch.getResponse());
				
				String registrationId = returnMessageSearch.getResult().get(0).getRegistrationId();
				String waterMeterId= returnMessageSearch.getResult().get(0).getWaterMeter().getWaterMeterId();
				String smartCardId = returnMessageSearch.getResult().get(0).getSmartCard().getSmartCardId();
				
				CreateAccuralResponseType returnMessage = SampasEksClient.createAccural(reqTimeout, connTimeout, url, username, password, serviceMessageCreate, amountOfMoney, amountOfWater, registrationId, cardInfo);
				iMap.put("REQUEST_XML_CREATE", serviceMessageCreate.getRequest());
				outMap.put("RETURN_XML_CREATE", serviceMessageCreate.getResponse());
				if (returnMessage.getSuccess().compareTo(new Long(SUCCESS))!=0) {
					// hata olustu
					outMap.put("RETURN_CODE", returnMessage.getResult().getBussinessErrorMessage());
					outMap.put("RETURN_INFO", returnMessage);
				}
				else {
					String accuredNumber="";
					QueryCreditResponseType	returnMessageQuery=SampasEksClient.queryCredit(reqTimeout, connTimeout, url, username, password, serviceMessageQuery, "", "", "", "", "", smartCardId, cardInfo, "", waterMeterId);
					iMap.put("REQUEST_XML_QUERY", serviceMessageQuery.getRequest());
					outMap.put("RETURN_XML_QUERY", serviceMessageQuery.getResponse());
					for (int i = 0; i < returnMessageQuery.getResult().size(); i++) {
						if (returnMessageQuery.getResult().get(i).getOrderResult().getStatus().equals(STATUS_NEW)) {
							accuredNumber=returnMessageQuery.getResult().get(i).getOrderResult().getOrderNumber();
						}
						
					}
					BigDecimal loadedAmount = new  BigDecimal(amountOfMoney);
					
					String operation ="UPDATE"; 

					OperateCreditV2ResponseType returnMessageInsert = SampasEksClient.operateCreditV2(reqTimeout, connTimeout, url, username, password, serviceMessageOperate, operation, smartCardId, cardInfo, waterMeterId, accuredNumber);
					iMap.put("REQUEST_XML_OPERATE", serviceMessageOperate.getRequest());
					outMap.put("RETURN_XML_OPERATE", serviceMessageOperate.getResponse());
					if (returnMessageInsert.getSuccess().compareTo(new Long(SUCCESS))!=0) {
						// karta yazma s�ras�nda hata meydana geldi
						// iptal yap
						operation="DELETE";
						outMap.put("RETURN_CODE", returnMessageInsert);
						outMap.put("RETURN_INFO", returnMessageInsert);
						OperateCreditV2ResponseType returnMessageCancel = SampasEksClient.operateCreditV2(reqTimeout, connTimeout, url, username, password, serviceMessage, operation, smartCardId, cardInfo, waterMeterId, accuredNumber);
						outMap.put("RETURN_CODE", returnMessageCancel);
						outMap.put("RETURN_INFO", returnMessageCancel);
						iMap.put("REQUEST_XML_CANCEL", serviceMessage.getRequest());
						outMap.put("RETURN_XML_CANCEL", serviceMessage.getResponse());
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
						outMap.put(MapKeys.ERROR_CODE, "Karta yazma s�ras�nda hata meydana geldi".equals(returnMessageCancel));
					}
					else {
						try {
							// karta basarili olarak yazildi
							// tablolar� update et
							Session session = DAOSession.getSession("BNSPRDal");
							Criteria cr = session.createCriteria(EccpsCreditLoadLog.class);
							cr.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO)));
							EccpsCreditLoadLog creditLoad = (EccpsCreditLoadLog) cr.uniqueResult();
							creditLoad.setAccuredNumber(accuredNumber);
							creditLoad.setLoadedAmount(loadedAmount);
							session.saveOrUpdate(creditLoad);
							
							
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, cardInfo);
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
							
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_SEARCH_INVOICE_FOR_EKS");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							GMMap debtMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
							
							if (GeneralConstants.ERROR_CODE_APPROVE.equals(debtMap.getString(MapKeys.ERROR_CODE))) {
								GMMap doInvoiceMap = new GMMap();
								String unId = debtMap.getString(MapKeys.INVOICE_LIST, 0, MapKeys.PARAMETER1);
								doInvoiceMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
								doInvoiceMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
								doInvoiceMap.put(MapKeys.PARAMETER1,unId );
								doInvoiceMap.put(MapKeys.INVOICE_AMOUNT, debtMap.getString(MapKeys.INVOICE_LIST, 0, MapKeys.AMOUNT));
								doInvoiceMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION_FOR_EKS");

								doInvoiceMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",doInvoiceMap);
								
								if (GeneralConstants.ERROR_CODE_APPROVE.equals(doInvoiceMap.getString(MapKeys.ERROR_CODE))) {
									creditLoad.setReceiptNo(unId);
									session.saveOrUpdate(creditLoad);
									outMap.put("RETURN_CODE", "0");
									outMap.put("RETURN_INFO", accuredNumber + "##"+ unId);
									
								} else {
									operation="DELETE";
									outMap.put("RETURN_CODE", returnMessageInsert);
									outMap.put("RETURN_INFO", returnMessageInsert);
									OperateCreditV2ResponseType returnMessageCancel = SampasEksClient.operateCreditV2(reqTimeout, connTimeout, url, username, password, serviceMessage, operation, smartCardId, cardInfo, waterMeterId, accuredNumber);
									outMap.put("RETURN_CODE", returnMessageCancel);
									outMap.put("RETURN_INFO", returnMessageCancel);
									iMap.put("REQUEST_XML_CANCEL", serviceMessage.getRequest());
									outMap.put("RETURN_XML_CANCEL", serviceMessage.getResponse());
									outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
									outMap.put(MapKeys.ERROR_CODE, "Karta yazma s�ras�nda hata meydana geldi".equals(returnMessageCancel));

								}
								
							} else {
								operation="DELETE";
								outMap.put("RETURN_CODE", returnMessageInsert);
								outMap.put("RETURN_INFO", returnMessageInsert);
								OperateCreditV2ResponseType returnMessageCancel = SampasEksClient.operateCreditV2(reqTimeout, connTimeout, url, username, password, serviceMessage, operation, smartCardId, cardInfo, waterMeterId, accuredNumber);
								outMap.put("RETURN_CODE", returnMessageCancel);
								outMap.put("RETURN_INFO", returnMessageCancel);
								iMap.put("REQUEST_XML_CANCEL", serviceMessage.getRequest());
								outMap.put("RETURN_XML_CANCEL", serviceMessage.getResponse());
								outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
								outMap.put(MapKeys.ERROR_CODE, "Karta yazma s�ras�nda hata meydana geldi".equals(returnMessageCancel));
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							operation="DELETE";
							outMap.put("RETURN_CODE", returnMessageInsert);
							outMap.put("RETURN_INFO", returnMessageInsert);
							OperateCreditV2ResponseType returnMessageCancel = SampasEksClient.     operateCreditV2(reqTimeout, connTimeout, url, username, password, serviceMessage, operation, smartCardId, cardInfo, waterMeterId, accuredNumber);
							outMap.put("RETURN_CODE", returnMessageCancel);
							outMap.put("RETURN_INFO", returnMessageCancel);
							iMap.put("REQUEST_XML_CANCEL", serviceMessage.getRequest());
							outMap.put("RETURN_XML_CANCEL", serviceMessage.getResponse());
							outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
							outMap.put(MapKeys.ERROR_CODE, "Karta yazma s�ras�nda hata meydana geldi".equals(returnMessageCancel));
						}

					}
				}
			}
		}
		catch (Exception e) {
			logger.error("ECCPS_SAMPAS_LOAD_MONEY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ECCPS_SAMPAS_CANCEL_LOAD_MONEY")
	public static GMMap cancelLoadMoney(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_SAMPAS_CANCEL_LOAD_MONEY");
		GMMap outMap = new GMMap();
		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		String unId = iMap.getString(MapKeys.Eksws.RECEIPT_NO);
		String invoiceSerial = iMap.getString(MapKeys.Eksws.RECEIPT_SERIAL);
		String orderNumber = iMap.getString(MapKeys.Eksws.ACCURED_NUMBER);
		ServiceMessage serviceMessageSearch = new ServiceMessage();
		ServiceMessage serviceMessageOperate = new ServiceMessage();

		int connTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER1);
		int reqTimeout =iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER2);
		String queryType =iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER3);

		String operation ="DELETE";
	

		try {
			GMMap cancelMap = new GMMap();
			cancelMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
			cancelMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
			cancelMap.put(MapKeys.PARAMETER1,unId );
			cancelMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");

			cancelMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",cancelMap);
			
			if (GeneralConstants.ERROR_CODE_APPROVE.equals(cancelMap.getString(MapKeys.ERROR_CODE))) {
			
			SearchUserResponseType returnMessageSearch = SampasEksClient.searchUser(reqTimeout, connTimeout, url, username, password, serviceMessageSearch, cardInfo, queryType);
			
			iMap.put("REQUEST_XML_SEARCH", serviceMessageSearch.getRequest());
			outMap.put("RETURN_XML_SEARCH", serviceMessageSearch.getResponse());
			
			String registrationId = returnMessageSearch.getResult().get(0).getRegistrationId();
			String waterMeterId= returnMessageSearch.getResult().get(0).getWaterMeter().getWaterMeterId();
			String smartCardId = returnMessageSearch.getResult().get(0).getSmartCard().getSmartCardId();

			
			OperateCreditV2ResponseType returnMessage = SampasEksClient.operateCreditV2(reqTimeout, connTimeout, url, username, password, serviceMessageOperate, operation, smartCardId, cardInfo, waterMeterId, orderNumber);
			iMap.put("REQUEST_XML_OPERATE", serviceMessageOperate.getRequest());
			outMap.put("RETURN_XML_OPERATE", serviceMessageOperate.getResponse());
			
			if (returnMessage.getSuccess().compareTo(new Long(SUCCESS))!=0) {
				// hata olustu
				outMap.put("RETURN_CODE", "-1");
				outMap.put("RETURN_INFO", returnMessage.getResult().getBussinessErrorMessage());
			}else{
				outMap.put("RETURN_CODE", "0");
				outMap.put("RETURN_INFO", "Islem Basarili");

			}

			}
		}
		catch (Exception e) {
			logger.error("ECCPS_SAMPAS_CANCEL_LOAD_MONEY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_SAMPAS_INVOICE_DEBT_INQUIRY_FOR_EKS")
	public static GMMap debtInquery(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_INVOICE_DEBT_INQUIRY_FOR_EKS");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		int counter = 0;
		
		try {

			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				
			Long aboneNo = null;
			Long sicilNo = null;
			
			String debtDate = CommonHelper.getDateString(new Date(), "dd/MM/yyyy"); 

			
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1))){
				aboneNo = iMap.getLong(MapKeys.SUBSCRIBER_NO1);
			}
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2))){
				sicilNo = iMap.getLong(MapKeys.SUBSCRIBER_NO2);
			}
			
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			Long sistemKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			tr.com.aktifbank.integration.sampas.ServiceMessage debtServiceMessage = new tr.com.aktifbank.integration.sampas.ServiceMessage();
			BakiyeV2[] borcList = SampasClient.borcSorgulamaGun(p_belediyeKodu, p_kurumKodu, sicilNo, aboneNo, sistemKodu, debtDate, debtDate, wsUserName, wsPassword, wsUrl, debtServiceMessage);
			iMap.put("REQUEST_XML", debtServiceMessage.getRequest());
			outMap.put("RESPONSE_XML", debtServiceMessage.getResponse());			
			
			//Basarili sonuc disindaki tum hatalarda exception atiyor zaten.
			GMMap responceCodeMap = getResponseCodeMapping(GeneralConstants.ERROR_CODE_APPROVE, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			for(BakiyeV2 borc : borcList){
				Map<String, String> maps=new HashMap<String, String>();
				maps.put("corporateCode", corporateCode);
				maps.put("subscriberNo1", Long.toString(borc.getIsYadaAboneNo()));
				maps.put("invoiceNo", Long.toString(borc.getId()));
				maps.put("parameter1", borc.getUnId());
				maps.put("paymentStatus", DatabaseConstants.PaymentStatuses.Collected);
				if(!isCollectedInvoiceMaps(maps)){
					Double amount = BigDecimal.valueOf(borc.getBorcVergi()).add(BigDecimal.valueOf(borc.getBorcGecikmeZammi())).add(BigDecimal.valueOf(borc.getBorcGecikmeFaizi())).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
					String termYear = Integer.toString(borc.getSonOdemeTar().get(Calendar.YEAR));
					String termMonth = Integer.toString(borc.getSonOdemeTar().get(Calendar.MONTH));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO1, borc.getIsYadaAboneNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NO2, borc.getSicilNo());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_NO, borc.getId());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.AMOUNT, amount);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.SUBSCRIBER_NAME, borc.getAdSoyad());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_DUE_DATE, borc.getSonOdemeTar().getTime());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_YEAR, termYear);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INVOICE_TERM_MONTH, termMonth);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE, iMap.get(MapKeys.COLLECTION_TYPE));
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PAYMENT_TYPE_NAME, borc.getAciklama());
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.COLLECTION_AMOUNT, amount);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.INSTALLMENT_NO, BigDecimal.ZERO);
					outMap.put(MapKeys.INVOICE_LIST, counter, MapKeys.PARAMETER1, borc.getUnId());
					outMap.put(MapKeys.INVOICE_LIST, counter, "SELECT", false);
					outMap.put(MapKeys.INVOICE_LIST, counter, "OID", "0");
					counter++;
				}	
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);			
		}
		return outMap;
	}
	
	@GraymoundService("ICS_SAMPAS_DO_INVOICE_COLLECTION_FOR_EKS")
	public static GMMap doINvoiceCollection(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_DO_INVOICE_COLLECTION_FOR_EKS");
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
			
			String p_ref = iMap.getString(MapKeys.PARAMETER1);
			Double p_odenecekTutar = Double.valueOf(iMap.getString(MapKeys.INVOICE_AMOUNT));
			String tahsilatTarihi;
			
			if(!StringUtil.isEmpty(iMap.getString(MapKeys.PAYMENT_DATE))){
				tahsilatTarihi = CommonHelper.getDateString(CommonHelper.getDateTime(iMap.getString(MapKeys.PAYMENT_DATE), "yyyyMMddhhmmss"), "dd/MM/yyyy");
			}else{
				tahsilatTarihi = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			}
			
				Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
				Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
				String p_tahsilatTur = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
				/*
				 * Note: Farkli odeme tiplerine gore farkli ws bilgileri kullanilabilir.
				 * Musait bir zamanda ayri bir metoda alinmali.
				 */
				// Yine de tek olanlar icin defaultu cekelim.
				String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
				String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
				String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
				
						
				tr.com.aktifbank.integration.sampas.ServiceMessage sm = new tr.com.aktifbank.integration.sampas.ServiceMessage();
				AkosResponce response = SampasClient.tahsilat(p_belediyeKodu, p_kurumKodu, tahsilatTarihi, p_tahsilatTur , p_ref, p_odenecekTutar, wsUserName, wsPassword, wsUrl, sm);
				iMap.put("REQUEST_XML", sm.getRequest());
				outMap.put("RESPONSE_XML", sm.getResponse());			
				
				outMap.put(WS_RESPONSE_CODE, response.getResponceCode());
				
				GMMap responceCodeMap = getResponseCodeMapping(response.getResponceCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
				
				if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					
				}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_SAMPAS_COLLECTION_RECONCILIATION_FOR_EKS")
	public static GMMap collectionReconciliation(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_COLLECTION_RECONCILIATION");
		GMMap outMap = new GMMap();
		String responseCode = "";
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {
//			String corporateCodeIn = getCompanyCode4Reconciliation(corporateCode);
//			iMap.put(MapKeys.CORPORATE_CODE, corporateCodeIn);
			
			Calendar reconDate = new GregorianCalendar();
			reconDate.setTime(CommonHelper.getDateTime(iMap.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			
			String wsUserName = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String wsPassword = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);			
			Long p_belediyeKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			Long p_kurumKodu = iMap.getLong(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			Double toplamTahsilatTutari = (double) 0;
			Long toplamTahsilatSayisi = (long) 0;
			Double toplamIptalTutari = (double) 0;
			Long toplamIptalSayisi = (long) 0;
			
			tr.com.aktifbank.integration.sampas.ServiceMessage sm = new tr.com.aktifbank.integration.sampas.ServiceMessage();
			Mutabakat response = SampasClient.tahsilatMutabakatSayi(p_belediyeKodu, p_kurumKodu, reconDate, reconDate, wsUserName, wsPassword, wsUrl, sm);
			iMap.put("REQUEST_XML", sm.getRequest());
			outMap.put("RESPONSE_XML", sm.getResponse());			
			
			if(response.getToplamTahsilatTutari() != null){
				toplamTahsilatTutari = BigDecimal.valueOf(response.getToplamTahsilatTutari()).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
			}
			if(response.getToplamTahsilatSayisi() != null){
				toplamTahsilatSayisi = response.getToplamTahsilatSayisi(); 
			}
			if(response.getToplamIptalTutari() != null){
				toplamIptalTutari = BigDecimal.valueOf(response.getToplamIptalTutari()).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
			}
			if(response.getToplamIptalSayisi() != null){
				toplamIptalSayisi = response.getToplamIptalSayisi();
			}			
			
			responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);

			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL, toplamTahsilatTutari);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT, toplamTahsilatSayisi);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, toplamIptalTutari);
			outMap.put("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, toplamIptalSayisi);

			GMMap reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ECCPS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", iMap);
			BigDecimal total = reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_TOTAL).add(reconBankMap.getBigDecimal(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			int count = Integer.parseInt(reconBankMap.getString(MapKeys.RECON_COLLECTION_COUNT)) + Integer.parseInt(reconBankMap.getString(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL, String.valueOf(total));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_COUNT, String.valueOf(count));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
			outMap.put("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, reconBankMap.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));

			if (outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_TOTAL).compareTo(outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_TOTAL)) == 0
					&& outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_COUNT).compareTo(outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_COUNT)) == 0
					&& outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL).compareTo(outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL)) == 0
					&& outMap.getBigDecimal("BANK", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT).compareTo(outMap.getBigDecimal("CORPORATE", 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT)) == 0) 
			{
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
			} else {
				outMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			}
		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
				e2.printStackTrace();
				throw e2;
			}
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}

		return outMap;
	}
	
	@GraymoundService("ICS_SAMPAS_GET_COLLECTION_RECONCILIATION_DETAIL_FOR_EKS")
	public static GMMap getCollectionReconciliationDetail(GMMap iMap) throws Exception {
		GMMap outMap = new GMMap();
		
		outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		return outMap;
	}
	
	@GraymoundService("ICS_SAMPAS_COLLECTION_RECONCILIATION_CLOSED_FOR_EKS")
	public static GMMap collectionReconciliationClosed(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME,"ICS_SAMPAS_COLLECTION_RECONCILIATION_CLOSED");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		try {

			String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
			
			GMMap responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			//Kapama cagirildinda ekranda sayilari da gormek istiyor is birimi.
//			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
				GMMap onlineCorporateServiceCallOutputMap = new GMMap();
				GMMap onlineCorporateServiceCallInputMap = new GMMap();
				onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
				onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, iMap.getString(MapKeys.RECON_DATE));
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_COLLECTION_RECONCILIATION");
				onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);

				onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
			
				outMap.putAll(onlineCorporateServiceCallOutputMap);
//			}

		} catch (Exception e2) {
			if(e2 instanceof AkosException){
				outMap.put(WS_RESPONSE_CODE, ((AkosException) e2).getErrCode());
				outMap.put(WS_RESPONSE_MESSAGE, ((AkosException) e2).dumpToString());
				
				GMMap responceCodeMap = getResponseCodeMapping(((AkosException) e2).getErrCode(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			}else{
				outMap.put(MapKeys.ERROR_CODE, MapKeys.ERROR_CODE_SYSTEM);
				outMap.put(MapKeys.ERROR_DESC, CommonHelper.getExceptionTrace(e2));
			}
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			e2.printStackTrace();
			throw e2;
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;

	}
	
	@GraymoundService("ECCPS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS")
	public static GMMap getBankCollectionsForReconciliation(GMMap input) {
		GMMap outMap = new GMMap();
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
		
		BigDecimal collectedTotalAmount = new BigDecimal(0);
		BigDecimal cancelledTotalAmount = new BigDecimal(0);
		Session session = DAOSession.getSession("BNSPRDal");
		String paymentDate = input.getString(MapKeys.RECON_DATE);
		String paymentDateStart = paymentDate + "000000";
		String paymentDateFinish = paymentDate + "235959";


			Criteria bankInvoicePaymentCriteria = session.createCriteria(EccpsCreditLoad.class)
					.add(Restrictions.eq("corporateCode",corporateCode))
					.add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected))
					.add(Restrictions.between("paymentDate", paymentDateStart, paymentDateFinish)).add(Restrictions.eq("status", true));
			
			Criteria bankInvoiceCancelPaymentCriteria = session.createCriteria(EccpsCreditLoad.class)
					.add(Restrictions.eq("corporateCode",corporateCode))
					.add(Restrictions.eq("paymentStatus", PaymentStatuses.Cancelled))
					.add(Restrictions.between("paymentDate", paymentDateStart, paymentDateFinish)).add(Restrictions.eq("status", true));

//			if( input.containsKey(MapKeys.CHANNEL_CODE) && !StringUtil.isEmpty(input.getString(MapKeys.CHANNEL_CODE)) ){
//				bankInvoicePaymentCriteria = bankInvoicePaymentCriteria.add(Restrictions.eq("paymentChannel", input.getString(MapKeys.CHANNEL_CODE)));
//				bankInvoiceCancelPaymentCriteria = bankInvoiceCancelPaymentCriteria.add(Restrictions.eq("paymentChannel", input.getString(MapKeys.CHANNEL_CODE)));
//			}
			
			@SuppressWarnings("unchecked")
			List<EccpsCreditLoad> bankInvoicePaymentList = bankInvoicePaymentCriteria.list();
			
			@SuppressWarnings("unchecked")
			List<EccpsCreditLoad> bankInvoicePaymentCancelList = bankInvoiceCancelPaymentCriteria.list();
			
			for (int i = 0; i < bankInvoicePaymentList.size(); i++) {
				EccpsCreditLoad invoice = bankInvoicePaymentList.get(i);
				collectedTotalAmount = collectedTotalAmount.add(invoice.getLoadedAmount());
				outMap.put("BANK", i, MapKeys.TRX_NO, invoice.getTxNo());
			}

			for (int i = 0; i < bankInvoicePaymentCancelList.size(); i++) {
				EccpsCreditLoad invoice = bankInvoicePaymentCancelList.get(i);
				cancelledTotalAmount = cancelledTotalAmount.add(invoice.getLoadedAmount());
				outMap.put("BANK_CANCEL", i, MapKeys.TRX_NO, invoice.getTxNo());
				
			}

			outMap.put(MapKeys.RECON_COLLECTION_TOTAL, collectedTotalAmount);
			outMap.put(MapKeys.RECON_COLLECTION_COUNT, bankInvoicePaymentList.size());
			outMap.put(MapKeys.RECON_COLLECTION_CANCEL_COUNT, bankInvoicePaymentCancelList.size());
			outMap.put(MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelledTotalAmount);
			
		return outMap;
	}
	


}
