package tr.com.aktifbank.bnspr.eccps;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.corporation.services.OnlineCorporationInterface;
import tr.com.aktifbank.bnspr.corporation.services.OnlineInstitutionConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.EccpsCreditLoadLog;
import tr.com.aktifbank.integration.bursaEKS.BursaEKSClient;
import tr.com.aktifbank.integration.bursaEKS.ServiceMessage;
import tr.com.aktifbank.integration.eccps.EccpsClient;
import tr.com.bursaEKS.EKSKartBilgisi;
import tr.com.bursaEKS.WSTahsilat;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class BursaEccpsServices extends OnlineCorporationInterface implements OnlineInstitutionConstants {
	private static final Log logger = LogFactory.getLog(BursaEccpsServices.class);
	private static String DELIMITER = "\\$";
	private static String CARD_INFO_DELIMITER =	"\\|";
	public static String RECEIPT_DELIMITER1 = "-";
	public static String RECEIPT_DELIMITER2 = "/";
	public static String YIM_BRANCH_CODE = "999";
	public static String AGENT_CODE = "999";
	public static String APPROVE = "O";
	public static String CANCEL = "I";
	public static String DESK_CODE = "1";



	@GraymoundService("ECCPS_BURSA_CALCULATE_LOAD_AMOUNT")
	public static GMMap eksCalculateLoadAmount(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_BURSA_CALCULATE_LOAD_AMOUNT");
		GMMap outMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		String responseCode = GeneralConstants.ERROR_CODE_APPROVE;
		String responseMessage = "";	
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);

		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		String amountResult  = "";
		String tonResult = "";

		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);

		String ton = iMap.getString(MapKeys.Eksws.TON);
		BigDecimal amount = iMap.getBigDecimal(MapKeys.Eksws.MONEY);
		
		ServiceMessage serviceMessage = new ServiceMessage();
		ServiceMessage serviceMessageCardInfo = new ServiceMessage();

		boolean callCorporate = true;
		try {

			if (ton.equals("")) {
				if (amount.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden birinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (callCorporate) {
			String response = null;
			try {
				
				String kartBlg = BursaEKSClient.getAboneEKSKartBlg(reqTimeout, connTimeout, url, username, password, serviceMessageCardInfo, cardInfo);
				
				
				iMap.put("REQUEST_XML_SEARCH", serviceMessageCardInfo.getRequest());
				outMap.put("RETURN_XML_SEARCH", serviceMessageCardInfo.getResponse());
				
				String [] cardInfoArray = kartBlg.split(CARD_INFO_DELIMITER);
				
				String aboneNo = cardInfoArray[3];
				
				response = BursaEKSClient.eksHesapYap(reqTimeout, connTimeout, url, username, password, serviceMessage, amount.doubleValue(), Integer.parseInt(ton), new BigDecimal(aboneNo));
				
				iMap.put("REQUEST_XML", serviceMessage.getRequest());
				outMap.put("RETURN_XML", serviceMessage.getResponse());
				
				if (response!=null) {
					String [] responseArray = response.split(DELIMITER);
					amountResult  = responseArray[4];
					tonResult = responseArray[0];
					responseCode = "0";
				}else {
					responseCode = "-1";
				}


			} catch (Exception ex) {
				logger.error("ECCPS_BURSA_CALCULATE_LOAD_AMOUNT for ".concat(corporateCode).concat(" - an error is occured ()"));
				responseCode = "-1";
				logger.info("ECCPS_BURSA_CALCULATE_LOAD_AMOUNT error code = ".concat(responseCode));
				logger.info("ECCPS_BURSA_CALCULATE_LOAD_AMOUNT error message = ".concat(responseMessage));
			}			
			
			CommonHelper.insertWsCallLog(iMap, serviceMessage.getDuration(), serviceMessage.getStartTime(), serviceMessage.getEndTime());

			responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			

			
			if (errorCode.equals(GeneralConstants.ERROR_CODE_APPROVE)) {
					outMap.put("RETURN_CODE", "0");
					outMap.put("RETURN_INFO", amountResult+"~" + tonResult);
				}
				else 
				{
					outMap.put("RETURN_CODE", "1");
					outMap.put("RETURN_INFO", responceCodeMap.getString(MapKeys.ERROR_DESC));
				}
			}
		}
		catch (Exception e) {
			logger.error("ECCPS_BURSA_CALCULATE_LOAD_AMOUNT -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ECCPS_BURSA_LOAD_MONEY")
	public static GMMap eksLoadMoney(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_BURSA_LOAD_MONEY");
		GMMap outMap = new GMMap();
		GMMap responceCodeMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String errorCode = "";
		String responseCode = "0";

		String cardInfo = iMap.getString(MapKeys.Eksws.CARD_INFO);
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		String amountOfWater = iMap.getString(MapKeys.Eksws.TON);
		String amountOfMoney = iMap.getString(MapKeys.Eksws.MONEY);
		String txNo = iMap.getString(MapKeys.TRX_NO);
		
		ServiceMessage serviceMessage = new ServiceMessage();
		ServiceMessage serviceMessageCardInfo = new ServiceMessage();

		ServiceMessage serviceMessageApprove = new ServiceMessage();
		ServiceMessage serviceMessageCancel = new ServiceMessage();
		ServiceMessage serviceMessageOperate = new ServiceMessage();

		boolean callCorporate = true;
		outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
		outMap.put(MapKeys.ERROR_DESC, "");
		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER1);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER2);

		try {

			if (amountOfWater.equals("")) {
				if (amountOfMoney.equals("")) {
					outMap.put("RETURN_INFO", "Ton ya da tutar de�erlerinden birinin girilmesi zorunludur!");
					outMap.put("RETURN_CODE", "1");
					callCorporate = false;
				}
			}
			if (callCorporate) {

				String kartBlg = BursaEKSClient.getAboneEKSKartBlg(reqTimeout, connTimeout, url, username, password, serviceMessage, cardInfo);

				iMap.put("REQUEST_XML_SEARCH", serviceMessage.getRequest());
				outMap.put("RETURN_XML_SEARCH", serviceMessage.getResponse());

				String[] cardInfoArray = kartBlg.split(CARD_INFO_DELIMITER);

				EKSKartBilgisi kartBilgisi = new EKSKartBilgisi();
				kartBilgisi.setKartSeriNo(cardInfo);
				// kartBilgisi.setAboneNo(new BigDecimal(aboneNo));

				kartBilgisi.setSayacModelId(new BigDecimal(cardInfoArray[0]));
				kartBilgisi.setSayacNo(cardInfoArray[1]);
				kartBilgisi.setAdi(cardInfoArray[2]);
				kartBilgisi.setSoyadi(cardInfoArray[2]);
				kartBilgisi.setAboneNo(new BigDecimal(cardInfoArray[3]));
				kartBilgisi.setAvansHakki(new BigDecimal(cardInfoArray[4]));
				kartBilgisi.setFirmaId(new BigDecimal(cardInfoArray[5]));
				kartBilgisi.setEksKademeDurumKodu(new BigDecimal(cardInfoArray[6]));
				kartBilgisi.setFiyat1(new BigDecimal(cardInfoArray[7]));
				kartBilgisi.setFiyat2(new BigDecimal(cardInfoArray[8]));
				kartBilgisi.setFiyat3(new BigDecimal(cardInfoArray[9]));
				kartBilgisi.setFiyat4(new BigDecimal(cardInfoArray[10]));
				kartBilgisi.setFiyat5(new BigDecimal(cardInfoArray[11]));
				kartBilgisi.setKademeUstSinir1(new BigDecimal(cardInfoArray[12]));
				kartBilgisi.setKademeUstSinir2(new BigDecimal(cardInfoArray[13]));
				kartBilgisi.setKademeUstSinir3(new BigDecimal(cardInfoArray[14]));
				kartBilgisi.setKademeUstSinir4(new BigDecimal(cardInfoArray[15]));
				kartBilgisi.setAvansBorcu(new BigDecimal(cardInfoArray[16]));
				kartBilgisi.setMinTutar(new BigDecimal(cardInfoArray[17]));
				kartBilgisi.setSicilNo(new BigDecimal(cardInfoArray[18]));
				kartBilgisi.setAdres(cardInfoArray[19]);
				kartBilgisi.setFirmaAciklama(cardInfoArray[25]);
				kartBilgisi.setSayacModeliAciklama(cardInfoArray[26]);
				kartBilgisi.setAboneTuruAciklama(cardInfoArray[27]);
				kartBilgisi.setTarifeTuruAciklama(cardInfoArray[28]);
				kartBilgisi.setKartTuruV2Id(new BigDecimal(1));

				String gecikmisBorcTutar� = cardInfoArray[30];

				if (!"0".equals(gecikmisBorcTutar�)) {
					responseCode = "109";
				}

				responceCodeMap = getResponseCodeMapping(responseCode, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
				errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
				outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
				outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
				outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
				outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

				if (GeneralConstants.ERROR_CODE_APPROVE.equals(errorCode)) {

					// kartBilgisi =
					// BursaEKSClient.getAboneEKSKartBilgisi(reqTimeout,
					// connTimeout, url, username, password,
					// serviceMessageCardInfo, cardInfo, new
					// BigDecimal(aboneNo));

					// iMap.put("REQUEST_XML_CARD_INFO",
					// serviceMessage.getRequest());
					// outMap.put("RETURN_XML_CARD_INFO",
					// serviceMessage.getResponse());

					List<WSTahsilat> returnMessageTahakkuk = BursaEKSClient.eksTahakkukTahsilat(reqTimeout, connTimeout, url, username, password, serviceMessageOperate, Integer.parseInt(username),
							getBuskiDekont(txNo), kartBilgisi, "", "0", Integer.parseInt(amountOfWater), password);
					iMap.put("REQUEST_XML", serviceMessageOperate.getRequest());
					outMap.put("RETURN_XML", serviceMessageOperate.getResponse());

					BigDecimal tahakkukNo = returnMessageTahakkuk.get(0).getTahakkukNo();

					responceCodeMap = getResponseCodeMapping(returnMessageTahakkuk.get(0).getAciklama(), iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
					errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
					outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
					outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
					outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
					outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);

					if (!GeneralConstants.ERROR_CODE_APPROVE.equals(errorCode)) {
						// hata olustu
						outMap.put("RETURN_CODE", "1");
						outMap.put("RETURN_INFO", responceCodeMap.getString(MapKeys.ERROR_DESC));
						String returnMessage = BursaEKSClient.eksIslemOnayIptal(reqTimeout, connTimeout, url, username, password, serviceMessageCancel, CANCEL, password, tahakkukNo,
								Integer.parseInt(username));
						iMap.put("REQUEST_XML_CANCEL", serviceMessageCancel.getRequest());
						outMap.put("RETURN_XML_CANCEL", serviceMessageCancel.getResponse());

						responceCodeMap = getResponseCodeMapping(returnMessage, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
						errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
						outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
						outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
						outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
						outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
					} else {
							Session session = DAOSession.getSession("BNSPRDal");
							Criteria cr = session.createCriteria(EccpsCreditLoadLog.class);
							cr.add(Restrictions.eq("txNo", iMap.getBigDecimal(MapKeys.TRX_NO)));
							EccpsCreditLoadLog creditLoad = (EccpsCreditLoadLog) cr.uniqueResult();
							creditLoad.setAccuredNumber(tahakkukNo.toString());
							session.saveOrUpdate(creditLoad);
							
							outMap.put("RETURN_CODE", "0");
							outMap.put("RETURN_INFO", tahakkukNo.toString() + "##" + "Islem Basarili");

					}

				}
				if (!GeneralConstants.ERROR_CODE_APPROVE.equals(errorCode)) {
					outMap.put("RETURN_CODE", "1");
					outMap.put("RETURN_INFO", responceCodeMap.getString(MapKeys.ERROR_DESC));
				}

			}

		} catch (Exception e) {
			logger.error("ECCPS_BURSA_LOAD_MONEY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		} finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	@GraymoundService("ECCPS_BURSA_CANCEL_LOAD_MONEY")
	public static GMMap cancelLoadMoney(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_BURSA_CANCEL_LOAD_MONEY");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		BigDecimal tahakkukNo = iMap.getBigDecimal(MapKeys.Eksws.ACCURED_NUMBER);

		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER1);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER2);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String returnMessage = BursaEKSClient.eksIslemOnayIptal(reqTimeout, connTimeout, url, username, password, serviceMessage, CANCEL, password, tahakkukNo,Integer.parseInt(username));
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			
			GMMap responceCodeMap = getResponseCodeMapping(returnMessage, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if (!GeneralConstants.ERROR_CODE_APPROVE.equals(errorCode)) {
				outMap.put("RETURN_CODE", "1");
				outMap.put("RETURN_INFO", responceCodeMap.getString(MapKeys.ERROR_DESC));
			}else{
				outMap.put("RETURN_CODE", "0");
				outMap.put("RETURN_INFO", returnMessage);
			}
			
			
		}
		catch (Exception e) {
			logger.error("ECCPS_BURSA_CANCEL_LOAD_MONEY -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}	
	
	@GraymoundService("ECCPS_BURSA_INSERT_CARD_INFO")
	public static GMMap insertCardInfo(GMMap iMap) throws Exception {
		iMap.put(MapKeys.WS_SERVICE_NAME, "ECCPS_BURSA_INSERT_CARD_INFO");
		GMMap outMap = new GMMap();
		String corporateCode = iMap.getString(MapKeys.CORPORATE_CODE);
		String username = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_USER);
		String password = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_PASSWORD);
		String url = iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.WS_ENDPOINT);
		BigDecimal tahakkukNo = iMap.getBigDecimal(MapKeys.Eksws.ACCURED_NUMBER);

		int connTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER1);
		int reqTimeout = iMap.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.Eksws.PARAMETER2);
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			String returnMessage = BursaEKSClient.eksIslemOnayIptal(reqTimeout, connTimeout, url, username, password, serviceMessage, APPROVE, password, tahakkukNo,Integer.parseInt(username));
			iMap.put("REQUEST_XML", serviceMessage.getRequest());
			outMap.put("RETURN_XML", serviceMessage.getResponse());
			
			GMMap responceCodeMap = getResponseCodeMapping(returnMessage, iMap.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), corporateCode);
			String errorCode = responceCodeMap.getString(MapKeys.ERROR_CODE);
			outMap.put(MapKeys.ERROR_CODE, responceCodeMap.getString(MapKeys.ERROR_CODE));
			outMap.put(MapKeys.ERROR_DESC, responceCodeMap.getString(MapKeys.ERROR_DESC));
			outMap.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, responceCodeMap.getString("RETURN_CODE_DESC"));
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
			
			if (!GeneralConstants.ERROR_CODE_APPROVE.equals(errorCode)) {
				outMap.put("RETURN_CODE", "1");
				outMap.put("RETURN_INFO", responceCodeMap.getString(MapKeys.ERROR_DESC));
			}else{
				outMap.put("RETURN_CODE", "0");
				outMap.put("RETURN_INFO", returnMessage);
			}
			
			
		}
		catch (Exception e) {
			logger.error("ECCPS_BURSA_INSERT_CARD_INFO -> an error occured ");
			logger.error(System.currentTimeMillis(), e);
			outMap.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE);
			outMap.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		}
		finally {
			insertOnlineServiceLog(iMap, outMap);
		}
		return outMap;
	}
	
	public static String getBuskiDekont(String dekont) {
		String buskiDekont =  YIM_BRANCH_CODE + RECEIPT_DELIMITER1 +  DESK_CODE + RECEIPT_DELIMITER2 + dekont;			
		return buskiDekont;
	}
	
}
