package tr.com.aktifbank.bnspr.standingorder.services;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CancelAllWaitingInvoices;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CancelStandingOrderAccount;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CancelStandingOrderMain;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CheckSubscriberPreStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.GetCollectionTypeInfo;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.GetCorporateDefinition;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.GetDefinedStandingOrders;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.GetSectorDefinition;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.GetStandingOrderHistory;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.GetStandingOrderTransactions;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.IcsCancelStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.IcsSaveStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.IcsUpdateStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.SaveStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.SaveStandingOrderComm;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.SaveStandingOrderMain;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.UpdateStandingOrderAccount;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.UpdateStandingOrderComm;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.UpdateStandingOrderMain;
import tr.com.aktifbank.bnspr.cps.transactions.CancelStandingOrderHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.transactions.GetPaidOrdersHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cps.transactions.SaveStandingOrderHandler;
import tr.com.aktifbank.bnspr.cps.transactions.UpdateStandingOrderHandler;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CollectionTypePrm;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.StandingOrderAccount;
import tr.com.aktifbank.bnspr.dao.StandingOrderAccountTx;
import tr.com.aktifbank.bnspr.dao.StandingOrderComm;
import tr.com.aktifbank.bnspr.dao.StandingOrderCommTx;
import tr.com.aktifbank.bnspr.dao.StandingOrderMain;
import tr.com.aktifbank.bnspr.dao.StandingOrderMainTx;
import tr.com.aktifbank.bnspr.dao.StdBulkEmailDef;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.icsStandingOrdersTx;
import tr.com.aktifbank.bnspr.dao.icsStdOrderProcessLog;
import tr.com.aktifbank.bnspr.dao.invoiceMain;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class StandingOrderTransactionServices {
	private static final Log logger = LogFactory.getLog(StandingOrderTransactionServices.class);
	@GraymoundService("STO_STANDING_ORDER_SEND_TRANSACTION")
	public static GMMap sendTransaction(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put(MapKeys.TRX_NAME, "7003");
			iMap.put(MapKeys.TRX_NO, iMap.getString(MapKeys.TRX_NO));
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	@GraymoundService("GET_STANDING_ORDER_STATUS_LIST")
	public static GMMap getStandingOrderStatusList(GMMap iMap) {
		return CorporationServiceUtil.getComboValues(iMap);
	}

	@GraymoundService("ICS_SAVE_STANDING_ORDER")
	public static GMMap icsSaveStandingOrder(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
			String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
			icsStandingOrdersTx iso;
			iso = new icsStandingOrdersTx();
			iso.setCollectionType(Short.parseShort(iMap.getString(IcsSaveStandingOrder.Input.COLLECTION_TYPE)));
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			iso.setCorporateCode(cdMap.getString("CORPORATE_CODE"));
			iso.setCreateDate(sdf.format(new Date()));
			iso.setCreateUser(username);
			iso.setCustomerNo(new BigDecimal(iMap.getString("CUSTOMER_NO")));
			iso.setStandingOrderOid(iMap.getString("STANDING_ORDER_MAIN_OID"));
			iso.setStandingOrderStatus("1");
			iso.setStatus(true);
			iso.setSubscriberNo1(iMap.getString(MapKeys.SUBSCRIBER_NO1));
			iso.setSubscriberNo2(iMap.getString(MapKeys.SUBSCRIBER_NO2));
			iso.setSubscriberNo3(iMap.getString(MapKeys.SUBSCRIBER_NO3));
			iso.setSubscriberNo4(iMap.getString(MapKeys.SUBSCRIBER_NO4));
			iso.setTxNo(iMap.getBigDecimal(MapKeys.TRX_NO));
			iso.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			iso.setRecordOid("-1");
			session.saveOrUpdate(iso);
			oMap.put("ICS_STANDING_ORDER_OID", iso.getOid());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("ICS_UPDATE_STANDING_ORDER")
	public static GMMap icsUpdateStandingOrder(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String standingOrderOid = iMap.getString(IcsUpdateStandingOrder.Input.STANDING_ORDER_OID);
			Session session = CommonHelper.getHibernateSession();
			icsStandingOrders oldRecord = (icsStandingOrders) session.createCriteria(icsStandingOrders.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("standingOrderOid", standingOrderOid))
					.uniqueResult();
//			session.setReadOnly(oldRecord, true);
			icsStandingOrdersTx iso = new icsStandingOrdersTx();
			CommonHelper.mapTxPojoToMainPojo(oldRecord, iso);
			
			iso.setTxNo(iMap.getBigDecimal(IcsUpdateStandingOrder.Input.TRX_NO));
			if (iMap.getString(IcsUpdateStandingOrder.Input.STANDING_ORDER_STATUS) != null) {
				iso.setStandingOrderStatus(iMap.getString(IcsUpdateStandingOrder.Input.STANDING_ORDER_STATUS));
			}
			iso.setUpdateDate(iMap.getString(IcsUpdateStandingOrder.Input.UPDATE_DATE));
			iso.setUpdateUser(iMap.getString(IcsUpdateStandingOrder.Input.UPDATE_USER));
			iso.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			iso.setRecordOid(oldRecord.getOid());
			session.save(iso);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("ICS_CANCEL_STANDING_ORDER")
	public static GMMap icsCancelStandingOrder(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String standingOrderOid = iMap.getString(IcsCancelStandingOrder.Input.STANDING_ORDER_OID);
			Session session = CommonHelper.getHibernateSession();
			icsStandingOrdersTx iso = new icsStandingOrdersTx();
			
			icsStandingOrders oldRecord = (icsStandingOrders) session.createCriteria(icsStandingOrders.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("standingOrderOid", standingOrderOid))
					.uniqueResult();
			
//			session.setReadOnly(oldRecord, true);
			
			CommonHelper.mapTxPojoToMainPojo(oldRecord, iso);
			
			iso.setTxNo(iMap.getBigDecimal(IcsCancelStandingOrder.Input.TRX_NO));
			if (iMap.getString(IcsCancelStandingOrder.Input.STANDING_ORDER_STATUS) != null) {
				iso.setStandingOrderStatus(iMap.getString(IcsCancelStandingOrder.Input.STANDING_ORDER_STATUS));
			}else{
				iso.setStandingOrderStatus(DatabaseConstants.StandingOrderStatus.Canelled);
			}
			iso.setUpdateDate(iMap.getString(IcsCancelStandingOrder.Input.UPDATE_DATE));
			iso.setUpdateUser(iMap.getString(IcsCancelStandingOrder.Input.UPDATE_USER));
			iso.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			iso.setRecordOid(oldRecord.getOid());
			session.save(iso);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static String getCorporateName(String CorporateCode) {
		GMMap iMap = new GMMap();
		iMap.put("CORPORATE_CODE", CorporateCode);
		GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
		return cdMap.getString("CORPORATE_NAME");
	}

	@GraymoundService("STO_GET_DEFINED_STANDING_ORDERS")
	public static GMMap getDefinedStandingOrders(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			boolean getSectors = iMap.getBoolean(GetDefinedStandingOrders.Input.GET_SECTORS, false);
			Session session = DAOSession.getSession("BNSPRDal");

			Criteria cr;
			
			// Filtreleme ile �ekilecekse restrictionlar teker teker ekleniyor.
			// Filtre olmayacaksa(else) normal �ekiyor.
			if (iMap.getBoolean("FILTER", false)) {
				cr = session.createCriteria(StandingOrderMain.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("standingOrderType", "KFT"));
				
				DetachedCriteria subSelect = DetachedCriteria.forClass(icsStandingOrders.class);
				subSelect.setProjection(Property.forName("standingOrderOid"));
				cr.add(Property.forName("oid").in(subSelect));
				
				if (StringUtils.isNotEmpty(iMap.getString(GetDefinedStandingOrders.Input.CUSTOMER_NO)) )
					cr.add(Restrictions.eq("customerNo", iMap.getBigDecimal(GetDefinedStandingOrders.Input.CUSTOMER_NO)));				

				if (StringUtils.isNotEmpty(iMap.getString(GetDefinedStandingOrders.Input.STANDING_ORDER_NUMBER)) )
					cr.add(Restrictions.eq("standingOrderNumber", iMap.getBigDecimal(GetDefinedStandingOrders.Input.STANDING_ORDER_NUMBER)));				

				if (StringUtils.isNotEmpty(iMap.getString(GetDefinedStandingOrders.Input.STANDING_ORDER_STATUS)) ) 
					cr.add(Restrictions.eq("standingOrderStatus", iMap.getString(GetDefinedStandingOrders.Input.STANDING_ORDER_STATUS)));
				
				if (StringUtils.isNotEmpty(iMap.getString(GetDefinedStandingOrders.Input.SUBSCRIBER_NO1)) )
					subSelect.add(Restrictions.eq("subscriberNo1", iMap.getString(GetDefinedStandingOrders.Input.SUBSCRIBER_NO1)));
								
				if (StringUtils.isNotEmpty(iMap.getString(GetDefinedStandingOrders.Input.CORPORATE_CODE)) )
					subSelect.add(Restrictions.eq("corporateCode", iMap.getString(GetDefinedStandingOrders.Input.CORPORATE_CODE)));
				
			} else {
				cr = session.createCriteria(StandingOrderMain.class)
						.add(Restrictions.eq("customerNo", iMap.getBigDecimal(GetDefinedStandingOrders.Input.CUSTOMER_NO)))
						.add(Restrictions.eq("status", true)).add(Restrictions.eq("standingOrderType", "KFT"));
			}

			@SuppressWarnings("unchecked")
			List<StandingOrderMain> somList = (List<StandingOrderMain>) cr.list();
			Map<String, GMMap> detailFetchedCorporates = new HashMap<String, GMMap>();
			Map<String, GMMap> detailFetchedSectors = new HashMap<String, GMMap>();
			// Kayitli talimatlari al
			int row = 0;
			for (StandingOrderMain som : somList) {
				icsStandingOrders ics = (icsStandingOrders) session.createCriteria(icsStandingOrders.class)
						.add(Restrictions.eq("standingOrderOid", som.getOid())).add(Restrictions.eq("status", true)).uniqueResult();
				StandingOrderAccount soa = (StandingOrderAccount) session.createCriteria(StandingOrderAccount.class)
						.add(Restrictions.eq("standingOrderOid", som.getOid())).add(Restrictions.eq("status", true)).uniqueResult();
				short collType = Short.parseShort(ics.getCollectionType().toString());
				CollectionTypePrm ctprm = (CollectionTypePrm) session.createCriteria(CollectionTypePrm.class)
						.add(Restrictions.eq("collectionType", collType)).uniqueResult();
				SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy");
				SimpleDateFormat CREATE_DATE_FORMAT = new SimpleDateFormat("yyyyMMddhhmmss");

				GMMap statusInputMap = new GMMap();
				statusInputMap.put("KOD", "CDM_STANDING_ORDER_STATUS");
				GMMap statusOutMap = (GMMap) GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", statusInputMap);

				for (int i = 0; i < statusOutMap.getSize("RESULTS"); i++) {
					if (som.getStandingOrderStatus().equals(statusOutMap.get("RESULTS", i, "VALUE"))) {
						oMap.put(GetDefinedStandingOrders.Output.RESULT, row, "STATUS", statusOutMap.get("RESULTS", i, "NAME"));
					}
				}

				String corporateName = "";
				String sectorName = "";
				String sectorCode = "";

				if (detailFetchedCorporates.containsKey(ics.getCorporateCode())) {
					corporateName = detailFetchedCorporates.get(ics.getCorporateCode()).getString(GetCorporateDefinition.Output.SHORT_CODE);
					sectorCode = detailFetchedCorporates.get(ics.getCorporateCode()).getString(GetCorporateDefinition.Output.SECTOR_CODE);
				} else {
					GMMap getCorporateDefinitionRequest = new GMMap();
					getCorporateDefinitionRequest.put(GetCorporateDefinition.Inputs.CORPORATE_CODE, ics.getCorporateCode());
					GMMap getCorporateDefinitionResponse = CommonHelper.callGraymoundServiceInHibernateSession(GetCorporateDefinition.SERVICE_NAME,
							getCorporateDefinitionRequest);
					corporateName = getCorporateDefinitionResponse.getString(GetCorporateDefinition.Output.SHORT_CODE);
					sectorCode = getCorporateDefinitionResponse.getString(GetCorporateDefinition.Output.SECTOR_CODE);
					detailFetchedCorporates.put(ics.getCorporateCode(), getCorporateDefinitionResponse);
				}

				if (getSectors) {
					if (detailFetchedSectors.containsKey(sectorCode)) {
						sectorName = detailFetchedSectors.get(sectorCode).getString(GetSectorDefinition.Output.SECTOR_NAME);
					} else {
						GMMap sectorDefinitionRequest = new GMMap();
						sectorDefinitionRequest.put(GetSectorDefinition.Input.SECTOR_CODE, sectorCode);
						GMMap sectorDefinitionResponse = CommonHelper.callGraymoundServiceInHibernateSession(GetSectorDefinition.SERVICE_NAME,
								sectorDefinitionRequest);
						sectorName = sectorDefinitionResponse.getString(GetSectorDefinition.Output.SECTOR_NAME);
						detailFetchedSectors.put(sectorCode, sectorDefinitionResponse);
					}
				}
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.CORPORATE_NAME, corporateName);
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.CORPORATE_CODE, ics.getCorporateCode());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.COLLECTION_TYPE, ctprm.getCollectionName());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.SUBSCRIBER_NO1, ics.getSubscriberNo1());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.SUBSCRIBER_NO2, ics.getSubscriberNo2());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.SUBSCRIBER_NO3, ics.getSubscriberNo3());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.SUBSCRIBER_NO4, ics.getSubscriberNo4());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.START_DATE, DATE_FORMAT.format(som.getStartDate()));
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.END_DATE, DATE_FORMAT.format(som.getEndDate()));
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.CREATE_DATE,
						DATE_FORMAT.format(CREATE_DATE_FORMAT.parse(som.getCreateDate())));
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.CUSTOMER_NO, som.getCustomerNo());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.ACCOUNT_NUMBER, soa.getAccountNumber());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.IBAN, soa.getIban());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.BRANCH_CODE, som.getBranchCode());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.CHANNEL_CODE, som.getCancelChannel());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.STANDING_ORDER_NUMBER, som.getStandingOrderNumber());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.STANDING_ORDER_OID, som.getOid());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.NOTIFY_BY_EMAIL, som.getNotfyByEmail());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.NOTIFY_BY_SMS, som.getNotifyBySms());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.SECTOR_NAME, sectorName);
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.ORDER_STATUS_CODE, som.getStandingOrderStatus());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.CREATE_USER, som.getCreateUser());
				oMap.put("RESULT", row, GetDefinedStandingOrders.Output.USER_LABEL, som.getUserLabel());
				oMap.put("RESULT", row, "CARD_NO", soa.getCardNumber());
				oMap.put("RESULT", row, "PAYMENT_SOURCE", String.valueOf(soa.getPriority()).equals(DatabaseConstants.StandingOrderSourcePriorities.AccountFirst) ? 
						DatabaseConstants.SourceCodes.Account : DatabaseConstants.SourceCodes.CreditCard);
				row++;
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_SAVE_STANDING_ORDER_MAIN")
	public static GMMap saveStandingOrderMain(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		StandingOrderMainTx som;
		GMMap outMap = new GMMap();
		som = new StandingOrderMainTx();
		try {
			som.setBranchCode((String) GMContext.getCurrentContext().getSession().get("BRANCH_ID"));
			String notfyByEmail = "0";
			String notifyAfterPayment = "0";
			String notifyBySms = "0";
			String notifyBeforePayment = "0";
			if (iMap.getBoolean(SaveStandingOrderMain.Input.NOTIFY_BY_EMAIL)) {
				notfyByEmail = "1";
			}
			if (iMap.getBoolean(SaveStandingOrderMain.Input.AFTER_PAYMENT)) {
				notifyAfterPayment = "1";
			}
			if (iMap.getBoolean(SaveStandingOrderMain.Input.BEFORE_PAYMENT)) {
				notifyBeforePayment = "1";
			}
			if (iMap.getBoolean(SaveStandingOrderMain.Input.NOTIFY_BY_SMS)) {
				notifyBySms = "1";
			}
			som.setChannelCode(getChannelId());
			som.setCreateDate(iMap.getString(SaveStandingOrderMain.Input.CR_DATE));
			som.setCreateUser(iMap.getString(SaveStandingOrderMain.Input.USER_NAME));
			som.setCustomerNo(new BigDecimal(iMap.getString(SaveStandingOrderMain.Input.CUSTOMER_NO)));
			som.setEndDate(iMap.getDate(SaveStandingOrderMain.Input.END_DATE));
			som.setStartDate(iMap.getDate(SaveStandingOrderMain.Input.START_DATE));
			som.setNotfyByEmail(notfyByEmail);
			som.setNotifyAfterPayment(notifyAfterPayment);
			som.setNotifyBeforePayment(notifyBeforePayment);
			som.setNotifyBySms(notifyBySms);
			som.setStandingOrderNumber(new BigDecimal(getSequenceCode("STANDING_ORDER_NUMBER")));
			som.setStandingOrderStatus(iMap.getString(SaveStandingOrderMain.Input.ORDER_STATUS));
			som.setStandingOrderType(iMap.getString(SaveStandingOrderMain.Input.TYPE));
			som.setSourceCode(iMap.getString(SaveStandingOrderMain.Input.PAYMENT_CHANNEL));
			som.setTxNo(iMap.getBigDecimal(SaveStandingOrderMain.Input.TRX_NO));
			som.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			som.setRecordOid("-1");
			som.setUserLabel(iMap.getString(SaveStandingOrderMain.Input.STANDING_ORDER_NAME));
			som.setCityCode(iMap.getString(SaveStandingOrderMain.Input.CITY));
			som.setStatus(true);
            som.setPaymentSourceCode(iMap.getString("PAYMENT_SOURCE"));
			session.saveOrUpdate(som);
			session.flush();
			
			outMap.put(SaveStandingOrderMain.Output.STANDING_ORDER_MAIN_OID, som.getOid());
			outMap.put("STANDING_ORDER_NUMBER", som.getStandingOrderNumber());
			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_UPDATE_STANDING_ORDER_MAIN")
	public static GMMap updateStandingOrderMain(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		String standingOrderOid = iMap.getString(UpdateStandingOrderMain.Input.STANDING_ORDER_OID);
		StandingOrderMainTx som;
		GMMap outMap = new GMMap();
		som = new StandingOrderMainTx();
		try {
			StandingOrderMain oldRecord = (StandingOrderMain) session.createCriteria(StandingOrderMain.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("oid", standingOrderOid))
					.uniqueResult();
//			session.setReadOnly(oldRecord, true);
			CommonHelper.mapTxPojoToMainPojo(oldRecord, som);
			som.setBranchCode((String) GMContext.getCurrentContext().getSession().get("BRANCH_ID"));
			som.setStandingOrderNumber(oldRecord.getStandingOrderNumber());
			String notfyByEmail = "0";
			String notifyAfterPayment = "0";
			String notifyBySms = "0";
			String notifyBeforePayment = "0";
			if (iMap.getString(UpdateStandingOrderMain.Input.NOTIFY_BY_EMAIL) != null) {
				if (iMap.getBoolean(UpdateStandingOrderMain.Input.NOTIFY_BY_EMAIL)) {
					notfyByEmail = "1";
				} else {
					notfyByEmail = "0";
				}
				som.setNotfyByEmail(notfyByEmail);
			}
			else{
				som.setNotfyByEmail(oldRecord.getNotfyByEmail());
			}

			if (iMap.getString(UpdateStandingOrderMain.Input.AFTER_PAYMENT) != null) {
				if (iMap.getBoolean(UpdateStandingOrderMain.Input.AFTER_PAYMENT)) {
					notifyAfterPayment = "1";
				} else {
					notifyAfterPayment = "0";
				}
				som.setNotifyAfterPayment(notifyAfterPayment);
			}
			else{
				som.setNotifyAfterPayment(oldRecord.getNotifyAfterPayment());
			}
			if (iMap.getString(UpdateStandingOrderMain.Input.BEFORE_PAYMENT) != null) {
				if (iMap.getBoolean(UpdateStandingOrderMain.Input.BEFORE_PAYMENT)) {
					notifyBeforePayment = "1";
				} else {
					notifyBeforePayment = "0";
				}
				som.setNotifyBeforePayment(notifyBeforePayment);
			}
			else{
				som.setNotifyBeforePayment(oldRecord.getNotifyBeforePayment());
			}
			if (iMap.getString(UpdateStandingOrderMain.Input.NOTIFY_BY_SMS) != null) {
				if (iMap.getBoolean(UpdateStandingOrderMain.Input.NOTIFY_BY_SMS)) {
					notifyBySms = "1";
				} else {
					notifyBySms = "0";
				}
				som.setNotifyBySms(notifyBySms);
			}
			else{
				som.setNotifyBySms(oldRecord.getNotifyBySms());
			}
			som.setChannelCode(getChannelId());
			if (iMap.getString(UpdateStandingOrderMain.Input.CUSTOMER_NO) != null) {
				som.setCustomerNo(new BigDecimal(iMap.getString(UpdateStandingOrderMain.Input.CUSTOMER_NO)));
			}
			else{
				som.setCustomerNo(oldRecord.getCustomerNo());
			}
			if (iMap.getString(UpdateStandingOrderMain.Input.END_DATE) != null) {
				som.setEndDate(iMap.getDate(UpdateStandingOrderMain.Input.END_DATE));
			}
			else{
				som.setEndDate(oldRecord.getEndDate());
			}
			if (iMap.getString(UpdateStandingOrderMain.Input.ORDER_STATUS) != null) {
				som.setStandingOrderStatus(iMap.getString(UpdateStandingOrderMain.Input.ORDER_STATUS));
			}
			else{
				som.setStandingOrderStatus(oldRecord.getStandingOrderStatus());
			}
			if (iMap.getString(UpdateStandingOrderMain.Input.TYPE) != null) {
				som.setStandingOrderType(iMap.getString(UpdateStandingOrderMain.Input.TYPE));
			}
			else{
				som.setStandingOrderType(oldRecord.getStandingOrderType());
			}
			if (iMap.getString(UpdateStandingOrderMain.Input.PAYMENT_CHANNEL) != null) {
				som.setSourceCode(iMap.getString(UpdateStandingOrderMain.Input.PAYMENT_CHANNEL));
			}
			else{
				som.setSourceCode(oldRecord.getSourceCode());
			}
			som.setTxNo(iMap.getBigDecimal(UpdateStandingOrderMain.Input.TRX_NO));
			if (iMap.getString(UpdateStandingOrderMain.Input.STANDING_ORDER_NAME) != null) {
				som.setUserLabel(iMap.getString(UpdateStandingOrderMain.Input.STANDING_ORDER_NAME));
			}
			else{
				som.setUserLabel(oldRecord.getUserLabel());
			}
            if (iMap.getString("PAYMENT_SOURCE") != null) {
                som.setPaymentSourceCode(iMap.getString("PAYMENT_SOURCE"));
            }
            else{
            	som.setPaymentSourceCode(oldRecord.getPaymentSourceCode());
            }
            som.setUpdateDate(iMap.getString(UpdateStandingOrderMain.Input.UPDATE_DATE));
			som.setUpdateUser(iMap.getString(UpdateStandingOrderMain.Input.UPDATE_USER));
			som.setStatus(true);
			som.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			som.setRecordOid(oldRecord.getOid());
			session.save(som);
			session.flush();
			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_CANCEL_STANDING_ORDER_MAIN")
	public static GMMap cancelStandingOrderMain(GMMap iMap) {
		try {
			Session session = CommonHelper.getHibernateSession();
			StandingOrderMainTx som;
			GMMap outMap = new GMMap();
			som = new StandingOrderMainTx();
			String standingOrderOid = iMap.getString(CancelStandingOrderMain.Input.STANDING_ORDER_OID);
			StandingOrderMain oldRecord = (StandingOrderMain) session.createCriteria(StandingOrderMain.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("oid", standingOrderOid))
					.uniqueResult();
//			session.setReadOnly(oldRecord, true);
			
			CommonHelper.mapTxPojoToMainPojo(oldRecord, som);
			
			som.setCancelChannel(CommonHelper.getChannelId());
			som.setCancelDate(iMap.getString(CancelStandingOrderMain.Input.UPDATE_DATE));
			som.setCancelUser(iMap.getString(CancelStandingOrderMain.Input.UPDATE_USER));
			som.setCreateUser(iMap.getString(CancelStandingOrderMain.Input.UPDATE_USER));
			som.setUpdateDate(iMap.getString(CancelStandingOrderMain.Input.UPDATE_DATE));
			som.setUpdateUser(iMap.getString(CancelStandingOrderMain.Input.UPDATE_USER));
			som.setStandingOrderStatus(DatabaseConstants.StandingOrderStatus.Canelled);
			som.setTxNo(new BigDecimal(iMap.getString(CancelStandingOrderMain.Input.TRX_NO)));
			som.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			som.setRecordOid(standingOrderOid);
			session.save(som);
			session.flush();
			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_SAVE_STANDING_ORDER_ACCOUNT")
	public static GMMap saveStandingOrderAccount(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		StandingOrderAccountTx soa;
		try {
			String priority = iMap.getString("PRIORITY", "1");
			soa = new StandingOrderAccountTx();
			soa.setAccountNumber(iMap.getBigDecimal("ACCOUNT_NUMBER"));
			soa.setIban(iMap.getString("IBAN"));
			soa.setCardNumber(iMap.getBigDecimal("COLLECTION_CARD_NO"));
			soa.setIsUsed("1");
			soa.setPriority(Byte.valueOf(priority));
			soa.setStatus(true);
			soa.setStandingOrderOid(iMap.getString("STANDING_ORDER_MAIN_OID"));
			soa.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			soa.setRecordOid("-1");
			soa.setTxNo(iMap.getBigDecimal(MapKeys.TRX_NO));
			session.saveOrUpdate(soa);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_UPDATE_STANDING_ORDER_ACCOUNT")
	public static GMMap updateStandingOrderAccount(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		String standingOrderOid = iMap.getString(UpdateStandingOrderAccount.Input.STANDING_ORDER_OID);
		StandingOrderAccountTx soa;
		try {
			String priority = iMap.getString("PRIORITY", "1");
			StandingOrderAccount oldRecord = (StandingOrderAccount) session.createCriteria(StandingOrderAccount.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("standingOrderOid", standingOrderOid))
					.uniqueResult();
//			session.setReadOnly(oldRecord, true);
			
			soa = new StandingOrderAccountTx();
			
			CommonHelper.mapTxPojoToMainPojo(oldRecord, soa);
			
			if (iMap.getString(UpdateStandingOrderAccount.Input.ACCOUNT_NUMBER) != null) {
				soa.setAccountNumber(iMap.getBigDecimal(UpdateStandingOrderAccount.Input.ACCOUNT_NUMBER));
			}
			else{
				soa.setAccountNumber(oldRecord.getAccountNumber());
			}
			if (iMap.getString(UpdateStandingOrderAccount.Input.IBAN) != null) {
				soa.setIban(iMap.getString(UpdateStandingOrderAccount.Input.IBAN));
			}
			else{
				soa.setIban(oldRecord.getIban());
			}
			soa.setIsUsed("1");
			soa.setPriority(Byte.valueOf(priority));
            soa.setCardNumber(iMap.getBigDecimal("COLLECTION_CARD_NO"));
			soa.setStatus(true);
			soa.setUpdateDate(iMap.getString(UpdateStandingOrderAccount.Input.UPDATE_DATE));
			soa.setUpdateUser(iMap.getString(UpdateStandingOrderAccount.Input.UPDATE_USER));
			soa.setStandingOrderOid(standingOrderOid);
			soa.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			soa.setRecordOid(oldRecord.getOid());
			soa.setTxNo(iMap.getBigDecimal(MapKeys.TRX_NO));
			session.save(soa);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_CANCEL_STANDING_ORDER_ACCOUNT")
	public static GMMap cancelStandingOrderAccount(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			String standingOrderOid = iMap.getString(CancelStandingOrderAccount.Input.STANDING_ORDER_OID);
			Session session = CommonHelper.getHibernateSession();
			StandingOrderAccountTx soa = new StandingOrderAccountTx(); 
			StandingOrderAccount oldRecord = (StandingOrderAccount) session.createCriteria(StandingOrderAccount.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("standingOrderOid", standingOrderOid))
					.uniqueResult();
//			session.setReadOnly(oldRecord, true);
			
			CommonHelper.mapTxPojoToMainPojo(oldRecord, soa);
			
			soa.setUpdateDate(iMap.getString(CancelStandingOrderAccount.Input.UPDATE_DATE));
			soa.setUpdateUser(iMap.getString(CancelStandingOrderAccount.Input.UPDATE_USER));
			soa.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			soa.setRecordOid(oldRecord.getOid());
			soa.setTxNo(iMap.getBigDecimal(MapKeys.TRX_NO));
			session.save(soa);
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("SAVE_STANDING_ORDER_COMM")
	public static GMMap saveStandingOrderComm(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		StandingOrderCommTx soc;
		try {
			soc = new StandingOrderCommTx();
			soc.setEMail(iMap.getString(SaveStandingOrderComm.Input.E_MAIL));
			soc.setMobilePhone(iMap.getString(SaveStandingOrderComm.Input.PHONE_NUMBER));
			soc.setPhoneNumber(iMap.getString(SaveStandingOrderComm.Input.PHONE_NUMBER));
			soc.setStandingOrderOid(iMap.getString(SaveStandingOrderComm.Input.STANDING_ORDER_MAIN_OID));
			soc.setStatus(true);
			soc.setUseForNotification("1");
			soc.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			soc.setRecordOid("-1");
			soc.setTxNo(iMap.getBigDecimal(MapKeys.TRX_NO));
			session.save(soc);
			session.flush();
			oMap.put("RESULT", true);
			return oMap;
		} catch (Exception ex) {
			ex.printStackTrace();
			oMap.put("RESULT", false);
			return oMap;
		}
	}

	@GraymoundService("STO_UPDATE_STANDING_ORDER_COMM")
	public static GMMap updateStandingOrderComm(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		String standingOrderOid = iMap.getString(UpdateStandingOrderComm.Input.STANDING_ORDER_OID);
		StandingOrderCommTx soc;
		try {
			StandingOrderComm oldRecord = (StandingOrderComm) session.createCriteria(StandingOrderComm.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("standingOrderOid", standingOrderOid))
					.uniqueResult();
//			session.setReadOnly(oldRecord, true);
			soc = new StandingOrderCommTx();
			
			CommonHelper.mapTxPojoToMainPojo(oldRecord, soc);
			
			if (iMap.getString(UpdateStandingOrderComm.Input.E_MAIL) != null) {
				soc.setEMail(iMap.getString(UpdateStandingOrderComm.Input.E_MAIL));
			}
			else{
				soc.setEMail(oldRecord.getEMail());
			}
			if (iMap.getString(UpdateStandingOrderComm.Input.PHONE_NUMBER) != null) {
				soc.setMobilePhone(iMap.getString(UpdateStandingOrderComm.Input.PHONE_NUMBER));
			}
			else{
				soc.setMobilePhone(oldRecord.getMobilePhone());
			}
			if (iMap.getString(UpdateStandingOrderComm.Input.PHONE_NUMBER) != null) {
				soc.setPhoneNumber(iMap.getString(UpdateStandingOrderComm.Input.PHONE_NUMBER));
			}
			else{
				soc.setPhoneNumber(oldRecord.getPhoneNumber());
			}
			soc.setStandingOrderOid(standingOrderOid);
			soc.setStatus(true);
			soc.setUseForNotification("1");
			soc.setUpdateDate(iMap.getString(UpdateStandingOrderComm.Input.UPDATE_DATE));
			soc.setUpdateUser(iMap.getString(UpdateStandingOrderComm.Input.UPDATE_USER));
			soc.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			soc.setRecordOid(oldRecord.getOid());
			soc.setTxNo(iMap.getBigDecimal(MapKeys.TRX_NO));
			session.save(soc);
			session.flush();
			oMap.put("RESULT", true);
			return oMap;
		} catch (Exception ex) {
			ex.printStackTrace();
			oMap.put("RESULT", false);
			return oMap;
		}
	}

	@GraymoundService("STO_CANCEL_STANDING_ORDER_COMM")
	public static GMMap cancelStandingOrderComm(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String standingOrderOid = iMap.getString(UpdateStandingOrderComm.Input.STANDING_ORDER_OID);
			Session session = CommonHelper.getHibernateSession();
			StandingOrderCommTx soc = new StandingOrderCommTx();
			
			StandingOrderComm oldRecord = (StandingOrderComm) session.createCriteria(StandingOrderComm.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("standingOrderOid", standingOrderOid))
					.uniqueResult();
			
//			session.setReadOnly(oldRecord, true);
			
			CommonHelper.mapTxPojoToMainPojo(oldRecord, soc);
			
			soc.setUpdateDate(iMap.getString(UpdateStandingOrderComm.Input.UPDATE_DATE));
			soc.setUpdateUser(iMap.getString(UpdateStandingOrderComm.Input.UPDATE_USER));
			soc.setTxStatus(DatabaseConstants.TransactionStatuses.New);
			soc.setRecordOid(oldRecord.getOid());
			soc.setTxNo(iMap.getBigDecimal(MapKeys.TRX_NO));
			session.save(soc);
			session.flush();
			oMap.put("RESULT", true);
			return oMap;
		} catch (Exception ex) {
			ex.printStackTrace();
			oMap.put("RESULT", false);
			return oMap;
		}
	}

	@GraymoundService("CDM_GET_STANDING_ORDER_DETAIL")
	public static GMMap getStandingOrderDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			StandingOrderMain som = (StandingOrderMain) session.createCriteria(StandingOrderMain.class)
					.add(Restrictions.eq("oid", iMap.getString("STANDING_ORDER_OID"))).add(Restrictions.eq("status", true)).uniqueResult();
			icsStandingOrders ics = (icsStandingOrders) session.createCriteria(icsStandingOrders.class)
					.add(Restrictions.eq("standingOrderOid", som.getOid())).add(Restrictions.eq("status", true)).uniqueResult();
			StandingOrderAccount soa = (StandingOrderAccount) session.createCriteria(StandingOrderAccount.class)
					.add(Restrictions.eq("standingOrderOid", som.getOid())).add(Restrictions.eq("status", true)).uniqueResult();
			StandingOrderComm soc = (StandingOrderComm) session.createCriteria(StandingOrderComm.class)
					.add(Restrictions.eq("standingOrderOid", som.getOid())).add(Restrictions.eq("status", true)).uniqueResult();
			logger.info("CDM_GET_STANDING_ORDER_DETAIL CollectionType >>"+ics);
			logger.info("CDM_GET_STANDING_ORDER_DETAIL CollectionType >>"+ics.getCollectionType());	
			short collType = Short.parseShort(ics.getCollectionType().toString());
			oMap.put("STATUS", som.getStandingOrderStatus());
			oMap.put("CORPORATE_CODE", ics.getCorporateCode());
			oMap.put("COLLECTION_TYPE", collType);
			oMap.put("SUBSCRIBER_NO1", ics.getSubscriberNo1());
			oMap.put("SUBSCRIBER_NO2", ics.getSubscriberNo2());
			oMap.put("SUBSCRIBER_NO3", ics.getSubscriberNo3());
			oMap.put("SUBSCRIBER_NO4", ics.getSubscriberNo4());
			oMap.put("START_DATE", som.getStartDate());
			oMap.put("END_DATE", som.getEndDate());
			oMap.put("CUSTOMER_NO", som.getCustomerNo());
			oMap.put("ACCOUNT_NUMBER", soa.getAccountNumber());
			oMap.put("BRANCH_CODE", som.getBranchCode());
			oMap.put("CHANNEL_CODE", som.getCancelChannel());
			oMap.put("STANDING_ORDER_NUMBER", som.getStandingOrderNumber());
			oMap.put("PAYMENT_CHANNEL", som.getSourceCode());
			oMap.put("ACCOUNT_NUMBER", soa.getAccountNumber());
			oMap.put("STANDING_ORDER_NAME", som.getUserLabel());
			oMap.put("STANDING_ORDER_STATUS", som.getStandingOrderStatus());
			oMap.put("IBAN", soa.getIban());
			oMap.put("PHONE_NUMBER", soc.getPhoneNumber());
			oMap.put("EMAIL", soc.getEMail());
			oMap.put("SOURCE", som.getSourceCode());
			oMap.put("CITY", som.getCityCode());
			iMap.put("CORPORATE_CODE", ics.getCorporateCode());
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			oMap.put("CORPORATE_OID", cdMap.getString("CORPORATE_OID"));
			oMap.put("NOTIFY_SMS", ((som.getNotifyBySms().equals("1")) ? true : false));
			oMap.put("NOTIFY_EMAIL", ((som.getNotfyByEmail().equals("1")) ? true : false));
			oMap.put("BEFORE_PAYMENT", ((som.getNotifyBeforePayment().equals("1")) ? true : false));
			oMap.put("AFTER_PAYMENT", ((som.getNotifyAfterPayment().equals("1")) ? true : false));
			oMap.put("BRANCH_NAME", CommonBusinessOperations.getBranchNameFromBranchCode(som.getBranchCode()));
			oMap.put("CARD_NO", soa.getCardNumber());
			oMap.put("PRIORITY", String.valueOf(soa.getPriority()));
			
			if (som.getStandingOrderStatus().equals("3")) {
				oMap.put("IS_EDITABLE_ROW", "FALSE");
			} else {
				oMap.put("IS_EDITABLE_ROW", "TRUE");
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_GET_STANDING_ORDER_TRANSACTIONS")
	public static GMMap getStandingOrderTransactions(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<icsStdOrderProcessLog> stoProcesslist = (List<icsStdOrderProcessLog>) session.createCriteria(icsStdOrderProcessLog.class)
					.add(Restrictions.eq("standingOrderOid", iMap.getString("STANDING_ORDER_OID"))).add(Restrictions.eq("status", true)).list();

			int row = 0;
			for (icsStdOrderProcessLog pl : stoProcesslist) {
				invoiceMain im = (invoiceMain) session.createCriteria(invoiceMain.class).add(Restrictions.eq("oid", pl.getInvoiceMainOid()))
						.add(Restrictions.eq("status", true)).uniqueResult();
				String corporateName = "";
				if(im != null)
				{
					GMMap getCorporateDefinitionRequest = new GMMap();
					getCorporateDefinitionRequest.put(GetCorporateDefinition.Inputs.CORPORATE_CODE, im.getCorporateCode());
					GMMap getCorporateDefinitionResponse = CommonHelper.callGraymoundServiceInHibernateSession(GetCorporateDefinition.SERVICE_NAME,
							getCorporateDefinitionRequest);
					corporateName = getCorporateDefinitionResponse.getString(GetCorporateDefinition.Output.CORPORATE_NAME);
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.CORPORATE_NAME, corporateName);
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.SUBSCRIBER_NO1, im.getSubscriberNo1());
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.INVOICE_NO, im.getInvoiceNo());
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.INVOICE_DUE_DATE,
							CommonHelper.shortTimeStringToViewDateString(im.getInvoiceDueDate()));
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.INVOICE_AMOUNT, im.getAmount());
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.PAYMENT_AMOUNT, im.getPaymentAmount());
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.INVOICE_STATUS,
							CommonHelper.getValueOfParameter("CDM_PAYMENT_STATUS", im.getPaymentStatus()));
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.ERROR_CODE, pl.getErrorCode());
					oMap.put(GetStandingOrderTransactions.Output.RESULT, row, GetStandingOrderTransactions.Output.ERROR_DESC, pl.getErrorDesc());

					row++;
				}
				
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("CDM_GET_STANDING_ORDER_HISTORY")
	public static GMMap getStandingOrderHistory(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			StandingOrderMain som = (StandingOrderMain) session.createCriteria(StandingOrderMain.class)
					.add(Restrictions.eq("oid", iMap.getString("STANDING_ORDER_OID"))).add(Restrictions.eq("status", true)).uniqueResult();

			/*
			 * Bu tablo en fazla 2 satir olabilir. O satirlar da giris ve iptal
			 * islemlerinin tarihini goruntuleyecek. dolayisiyla herhangi bir
			 * dongu yapmaya gerek yoktur. 2 satirin bilgileri ayri ayri
			 * girilebilir.
			 */
			oMap.put(GetStandingOrderHistory.Output.RESULT, 0, GetStandingOrderHistory.Output.DATE,
					CommonHelper.longTimeStringToViewDateString(som.getCreateDate()));
			oMap.put(GetStandingOrderHistory.Output.RESULT, 0, GetStandingOrderHistory.Output.TIME,
					CommonHelper.longTimeStringToViewTimeString(som.getCreateDate()));
			oMap.put(GetStandingOrderHistory.Output.RESULT, 0, GetStandingOrderHistory.Output.OPERATION, "Giri�");

			if (DatabaseConstants.StandingOrderStatus.Canelled.equals(som.getStandingOrderStatus())) {
				oMap.put(GetStandingOrderHistory.Output.RESULT, 1, GetStandingOrderHistory.Output.DATE,
						CommonHelper.longTimeStringToViewDateString(som.getCancelDate()));
				oMap.put(GetStandingOrderHistory.Output.RESULT, 1, GetStandingOrderHistory.Output.TIME,
						CommonHelper.longTimeStringToViewTimeString(som.getCancelDate()));
				oMap.put(GetStandingOrderHistory.Output.RESULT, 1, GetStandingOrderHistory.Output.OPERATION, "�ptal");
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("STO_SAVE_STANDING_ORDER")
	public static GMMap saveStandingOrder(GMMap iMap) {
		return RequestProcessor.getInstance().process(iMap, new SaveStandingOrderHandler());
	}

	@GraymoundService("STO_UPDATE_STANDING_ORDER")
	public static GMMap updateStandingOrder(GMMap iMap) {
		return RequestProcessor.getInstance().process(iMap, new UpdateStandingOrderHandler());
	}

	@GraymoundService("STO_CANCEL_STANDING_ORDER")
	public static GMMap cancelStandingOrder(GMMap iMap) {
		return RequestProcessor.getInstance().process(iMap, new CancelStandingOrderHandler());
	}

	public static void callGraymoundService(GMMap iMap) {
		GMMap servisInputMap = new GMMap();
		servisInputMap.put("CORPORATE_CODE", iMap.getString("CORPORATE_CODE"));
		servisInputMap.put("GM_SERVICE_NAME", iMap.getString("SERVICE_NAME"));
		GMMap servisOutMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_SERVICE_BOUND_GMSERVICE", servisInputMap);
		if (servisOutMap.getString("WEB_SERVICE") != null) {
			CommonHelper.callGraymoundServiceInHibernateSession(servisOutMap.getString("WEB_SERVICE"), iMap);
		}

	}

	@GraymoundService("CDM_STO_CHECK_FIELDS")
	public static GMMap checkFields(GMMap iMap) {
		GMMap oMap = new GMMap();

		String standingOrdername = iMap.getString("STANDING_ORDER_NAME", null);
		if (standingOrdername.length() > 50) {
			oMap.put("ERROR_MESSAGE", "Otomatik �deme Talimat� Ad� 50 karakterden uzun olamaz!");
		}
		
		String customerNo = iMap.getString(SaveStandingOrder.Input.CUSTOMER_NO, null);
		String accountNumber = iMap.getString(SaveStandingOrder.Input.ACCOUNT_NUMBER, null);

		if (customerNo != null && accountNumber != null) {
			oMap = new GMMap();
			try {
				String accNum = DALUtil.getResult(String.format(QueryRepository.StandingOrderTransactionServicesRepository.STO_CHECK_FIELDS, customerNo,accountNumber));
				if (accNum == null) {
					oMap.put("ERROR_MESSAGE", "L�tfen se�ti�iniz m��teriye ait bir hesap numaras� se�iniz!");
					return oMap;
				}
				if (accNum != null) {
					if (accNum.isEmpty()) {
						oMap.put("ERROR_MESSAGE", "L�tfen se�ti�iniz m��teriye ait bir hesap numaras� se�iniz!");
						return oMap;
					}
				}
			} catch (Exception e) {
				oMap.put("ERROR_MESSAGE", "L�tfen se�ti�iniz m��teriye ait bir hesap numaras� se�iniz!");
				return oMap;
			}
		}
		
		oMap.put("ERROR_MESSAGE", "");
		return oMap;
	}

	@GraymoundService("ICS_CHECK_SUBSCRIBER_PRE_STANDING_ORDER")
	public static GMMap checkSubscriberPreStandingOrder(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
		try {
			if (!cdMap.getBoolean(GetCorporateDefinition.Output.CORPORATE_ACTIVENESS)) {
				CommonHelper.throwBusinessException(BusinessException.CORPORATEISNOTACTIVEFORCOLLECTION.getCode());
			}
			iMap.put(GetCollectionTypeInfo.Input.CORPORATE_OID, cdMap.getString(GetCollectionTypeInfo.Input.CORPORATE_OID));
			iMap.put(GetCorporateDefinition.Output.CORPORATE_CODE, cdMap.getString(GetCorporateDefinition.Output.CORPORATE_CODE));
			GMMap ctiMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_COMMON_GET_COLLECTION_TYPE_INFO", iMap);
			if (!ctiMap.getBoolean("ALLOW_AUTO_COLLECTION")) {
				CommonHelper.throwBusinessException(BusinessException.ALLOWAUTOCOLLECTIONNOTACCEPTABLEBYCORPORATE.getCode());
				// Kurum bu �deme tipi i�in talimat kabul etmiyor.
			}
			if (cdMap.getString("IS_ONLINE_CORPORATE").equals("1") && !iMap.getString("OPERATION").equals("UPDATE")) {
				// online calisan kurum entegrasyonu
				try {
					// GMMap input = new GMMap();
					iMap.put("SERVICE_NAME", "ICS_CHECK_SUBSCRIBER_PRE_STANDING_ORDER");
					iMap.put(MapKeys.BANK_CODE, iMap.getString(MapKeys.BANK_CODE));
					iMap.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
					iMap.put(MapKeys.GM_SERVICE_NAME, "ICS_CHECK_SUBSCRIBER_PRE_STANDING_ORDER");
					iMap.put(MapKeys.IS_MANDATORY_SERVICE, false);
					iMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
					GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", iMap);
				} catch (Exception ex) {
					ex.printStackTrace();
					CommonHelper.throwBusinessException(2707);
				}
			}
			if (hasCustomerStandingOrderForCorporate(iMap) && iMap.getString("OPERATION").equals("INSERT")) {
				CommonHelper.throwBusinessException(BusinessException.HASALREADYSTANDINGORDER.getCode());
			}
			oMap.put(CheckSubscriberPreStandingOrder.Output.RESULT, true);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static boolean hasCustomerStandingOrderForCorporate(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		
		Criteria criteria = session.createCriteria(icsStandingOrders.class);
		criteria.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE")));
		criteria.add(Restrictions.eq("collectionType", Short.parseShort(iMap.getString(MapKeys.COLLECTION_TYPE))));
		criteria.add(Restrictions.ne("standingOrderStatus", "3"));
		criteria.add(Restrictions.eq("status", true));
		if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1, null))) {
			criteria.add(Restrictions.eq("subscriberNo1", iMap.getString(MapKeys.SUBSCRIBER_NO1)));
		}
		if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2, null))) {
			criteria.add(Restrictions.eq("subscriberNo2", iMap.getString(MapKeys.SUBSCRIBER_NO2)));
		}
		if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO3, null))) {
			criteria.add(Restrictions.eq("subscriberNo3", iMap.getString(MapKeys.SUBSCRIBER_NO3)));
		}
		if (!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO4, null))) {
			criteria.add(Restrictions.eq("subscriberNo4", iMap.getString(MapKeys.SUBSCRIBER_NO4)));
		}
		@SuppressWarnings("unchecked")
		List<icsStandingOrders> cm = (List<icsStandingOrders>) criteria.list();
	
		if (cm.size() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public static String getChannelId() {
		return (String) GMContext.getCurrentContext().getSession().get("CHANNEL_CODE");
	}

	public static String getSequenceCode(String tableName) throws Exception {
		try {
			GMMap iMap = new GMMap();
			iMap.put("TABLE_NAME", tableName);
			Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap);
			return oMap.get("ID").toString();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
	}

	@GraymoundService("STO_GET_PAID_ORDERS")
	public static GMMap getPaidOrders(GMMap iMap) {
		return RequestProcessor.getInstance().process(iMap, new GetPaidOrdersHandler());
	}

	@GraymoundService("CDM_GET_CITIES_FRONTEND_WITH_SELECTION_OPTION")
	public static GMMap getCities(GMMap iMap) {
		GMMap outMap = new GMMap();
		try {
			String tableName = "CITIES";
			GMMap output = DALUtil.getResults(QueryRepository.StandingOrderTransactionServicesRepository.CITIES_FRONTEND_WITH_SELECTION_OPTION, tableName);
			outMap.put("CITIES", 0, "NAME", "L�tfen �l Se�iniz");
			outMap.put("CITIES", 0, "VALUE", "SECIMYOK");
			for (int i = 0; i < output.getSize(tableName); i++) {
				GuimlUtil.wrapMyCombo(outMap, tableName, output.get(tableName, i, "KOD").toString(), output.get(tableName, i, "IL_ADI").toString());
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return outMap;
	}

	@GraymoundService("CDM_COMMON_GET_CORPORATES_FRONTEND_WITH_SELECTION_OPTION")
	public static GMMap getCorporatesFrontend(GMMap input) {
		GMMap output = new GMMap();
		try {
			output.put("CORPORATES", 0, "NAME", "L�tfen Kurum Se�iniz");
			output.put("CORPORATES", 0, "VALUE", "SECIMYOK");
			GMMap corporateList = DALUtil.getResults(String.format(QueryRepository.StandingOrderTransactionServicesRepository.CORPORATES_FRONTEND_WITH_SELECTION_OPTION, input.getString("IL_KOD")), "CORPORATES");
			for (int i = 0; i < corporateList.getSize("CORPORATES"); i++) {
				GuimlUtil.wrapMyCombo(output, "CORPORATES", (String) corporateList.get("CORPORATES", i, "OID"),
						(String) corporateList.get("CORPORATES", i, "CORPORATE_NAME"));
			}
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}

		return output;
	}

	@GraymoundService("CDM_COMMON_GET_COLLECTION_TYPES_FRONTEND_WTIH_SELECTION_OPTION")
	public static GMMap getCollectionTypes(GMMap input) {
		GMMap output = new GMMap();
		try {
			// output.put("COLLECTION_TYPES",0,
			// "NAME","L�tfen �deme Tipi Se�iniz");
			// output.put("COLLECTION_TYPES",0, "VALUE","SECIMYOK");
			String tableName = "COLLECTION_TYPES";
			String allowAutoCollection = input.getString("ALLOW_AUTO_COLLECTION", null);
			GMMap collectionTypeList = DALUtil.getResults(String.format(QueryRepository.StandingOrderTransactionServicesRepository.COLLECTION_TYPES_FRONTEND_WTIH_SELECTION_OPTION, allowAutoCollection,input.getString("CORPORATE_OID")), tableName);
			logger.info("Sql Query COLLECTION_TYPES_FRONTEND_WTIH_SELECTION_OPTION is >>"+String.format(QueryRepository.StandingOrderTransactionServicesRepository.COLLECTION_TYPES_FRONTEND_WTIH_SELECTION_OPTION, allowAutoCollection,input.getString("CORPORATE_OID")));
			logger.info("collectionTypeList is "+collectionTypeList);
			logger.info("collectionTypeList size is >>"+collectionTypeList.getSize(tableName));	
			// Tek kayit oldugunda Secme olmayacak. PY-3840
			if (collectionTypeList.getSize(tableName) != 1) {
				output.put("COLLECTION_TYPES", 0, "NAME", "L�tfen �deme Tipi Se�iniz");
				output.put("COLLECTION_TYPES", 0, "VALUE", "SECIMYOK");
				output.put("SINGLE_COLLECTION_TYPE", false);
			} else {
				output.put("SINGLE_COLLECTION_TYPE", true);
			}

			for (int i = 0; i < collectionTypeList.getSize(tableName); i++) {
				GuimlUtil.wrapMyCombo(output, tableName, ((BigDecimal) collectionTypeList.get(tableName, i, "COLLECTION_TYPE")).toString(),
						(String) collectionTypeList.get(tableName, i, "COLLECTION_NAME"));
			}

			if (collectionTypeList.getSize(tableName) == 0) {
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOEXISTINGCOLLECTIONTYPE));
			}

		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		output.put("COLLECTION_TYPE_EXISTS", true);
		return output;
	}
	
	@GraymoundService("ICS_GET_CUSTOMER_STANDING_ORDER_INVOICE_LIST")
	public static GMMap getCustomerStandingOrderInvoiceList(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String customerNo = input.getString("CUSTOMER_NO");
			String channelCode = input.getString("CHANNEL_CODE", null);
			
			String invoiceListTableName = "INVOICE_TABLE";
			String query = String.format(QueryRepository.StandingOrderTransactionServicesRepository.CUSTOMER_STANDING_ORDER_INVOICE_LIST,DatabaseConstants.StandingOrderStatus.Active ,DatabaseConstants.PaymentStatuses.Waiting,
					"KFT",customerNo,DatabaseConstants.CorporateActiveness.Active);
			if (!StringUtil.isEmpty(channelCode)) {
				query= query + String.format(" AND som.CHANNEL_CODE='%s'",channelCode); 
			}
			GMMap results = DALUtil.getResults(query, invoiceListTableName);
		
			 
			for (int i = 0; i < results.getSize(invoiceListTableName); i++) {
				output.put(invoiceListTableName, i, "SUBSCRIBER_NO1", results.getString(invoiceListTableName, i, "SUBSCRIBER_NO1"));
				output.put(invoiceListTableName, i, "SUBSCRIBER_NO2", results.getString(invoiceListTableName, i, "SUBSCRIBER_NO2"));
				output.put(invoiceListTableName, i, "SUBSCRIBER_NO3", results.getString(invoiceListTableName, i, "SUBSCRIBER_NO3"));
				output.put(invoiceListTableName, i, "SUBSCRIBER_NO4", results.getString(invoiceListTableName, i, "SUBSCRIBER_NO4"));
				output.put(invoiceListTableName, i, "INVOICE_DUE_DATE", results.getString(invoiceListTableName, i, "INVOICE_DUE_DATE"));
				output.put(invoiceListTableName, i, "INVOICE_AMOUNT", results.getString(invoiceListTableName, i, "AMOUNT"));
				output.put(invoiceListTableName, i, "STD_ORDER_STATUS", results.getString(invoiceListTableName, i, "STANDING_ORDER_STATUS"));
				output.put(invoiceListTableName, i, "CORPORATE_NAME", results.getString(invoiceListTableName, i, "SHORT_CODE"));
			}
			
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	
	@GraymoundService("ICS_GET_CUSTOMER_TOTAL_AMOUNT_STANDING_ORDER_INVOICES")
	public static GMMap getCustomerTotalAmountStandingOrderInvoices(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String customerNo = input.getString("CUSTOMER_NO");
			
			String query = String.format(QueryRepository.StandingOrderTransactionServicesRepository.CUSTOMER_TOTAL_AMOUNT_STANDING_ORDER_INVOICES,customerNo);
	
			String result = DALUtil.getResult(query);
			if(result==null){
				output.put("TOTAL_AMOUNT", new BigDecimal(0));

			}else{
				output.put("TOTAL_AMOUNT", new BigDecimal(result));

			}
			 					
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_GET_CUSTOMER_FAILED_STANDING_ORDER_LIST")
	public static GMMap getCustomerFailedStandingOrderList(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String customerNo = input.getString("CUSTOMER_NO");
			String channelCode = input.getString("CHANNEL_CODE", CommonHelper.getChannelId());
			
			String invoiceListTableName = "FAILED_INVOICE_TABLE";
		
			GMMap results = DALUtil.getResults(String.format(QueryRepository.StandingOrderTransactionServicesRepository.CUSTOMER_FAILED_STANDING_ORDER_LIST,DatabaseConstants.StandingOrderStatus.Active ,DatabaseConstants.PaymentStatuses.Waiting,
					"KFT",customerNo,channelCode,DatabaseConstants.CorporateActiveness.Active), invoiceListTableName);
			for (int i = 0; i < results.getSize(invoiceListTableName); i++) {
				output.put(invoiceListTableName, i, "SUBSCRIBER_NO1", results.getString(invoiceListTableName, i, "SUBSCRIBER_NO1"));
				output.put(invoiceListTableName, i, "SUBSCRIBER_NO2", results.getString(invoiceListTableName, i, "SUBSCRIBER_NO2"));
				output.put(invoiceListTableName, i, "SUBSCRIBER_NO3", results.getString(invoiceListTableName, i, "SUBSCRIBER_NO3"));
				output.put(invoiceListTableName, i, "SUBSCRIBER_NO4", results.getString(invoiceListTableName, i, "SUBSCRIBER_NO4"));
				output.put(invoiceListTableName, i, "INVOICE_DUE_DATE", results.getString(invoiceListTableName, i, "INVOICE_DUE_DATE"));
				output.put(invoiceListTableName, i, "INVOICE_AMOUNT", results.getString(invoiceListTableName, i, "AMOUNT"));
				output.put(invoiceListTableName, i, "STD_ORDER_STATUS", results.getString(invoiceListTableName, i, "STANDING_ORDER_STATUS"));
				output.put(invoiceListTableName, i, "CORPORATE_NAME", results.getString(invoiceListTableName, i, "SHORT_CODE"));
				output.put(invoiceListTableName, i, "FAILED_DATE", results.getString(invoiceListTableName, i, "PROCESS_DATE"));
			}
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("STO_GET_CORPORATE_LIST_FOR_STANDING_ORDER")
	public static GMMap getCorporateListForStandingOrder(GMMap input){
		GMMap output = new GMMap();
		try{
			String sectorCode = input.getString(TransactionConstants.GetCorporates.Inputs.SECTOR_CODE, null);
			String corporateTableName = "CORPORATES";
			
			
			output.put(corporateTableName,0, "NAME","L�tfen Kurum Se�iniz");
			output.put(corporateTableName,0, "VALUE","SECIMYOK");
			
			String tableName = TransactionConstants.GetCorporates.Output.CORPORATE_TABLE;
			GMMap results = DALUtil.getResults(String.format(QueryRepository.StandingOrderTransactionServicesRepository.CORPORATE_LIST_FOR_STANDING_ORDER,
					sectorCode,
					DatabaseConstants.CorporateActiveness.Active,
					GeneralConstants.AUTO_PAY_CHANNEL_CODE), tableName);
			for (int i = 0; i < results.getSize(tableName); i++) {
				output.put(corporateTableName, i+1, "VALUE", results.getString(tableName, i, "OID"));
				output.put(corporateTableName, i+1, "NAME", results.getString(tableName, i, "SHORT_CODE"));
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("STO_STANDING_ORDER_AFTER_APPROVAL")
	public static GMMap standingOrderAfterApproval(GMMap input){
		GMMap output = new GMMap();
		
		try{
			BigDecimal txNo = input.getBigDecimal("ISLEM_NO");
			Session hibSession = CommonHelper.getHibernateSession();
			StandingOrderMainTx newRecord = (StandingOrderMainTx) hibSession.createCriteria(StandingOrderMainTx.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txStatus", DatabaseConstants.TransactionStatuses.New))
					.add(Restrictions.eq("txNo", txNo))
					.uniqueResult();
			
			boolean isNew = newRecord.getRecordOid().trim().equals("-1");
			
			StandingOrderAccountTx newAccountRecord = (StandingOrderAccountTx) hibSession.createCriteria(StandingOrderAccountTx.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txStatus", DatabaseConstants.TransactionStatuses.New))
					.add(Restrictions.eq("txNo", txNo))
					.uniqueResult();
			
			StandingOrderCommTx newCommRecord = null;
			
			icsStandingOrdersTx newIcsRecord = null;
			if (newRecord.getStandingOrderType().equals("KFT")) {
				newCommRecord = (StandingOrderCommTx) hibSession.createCriteria(StandingOrderCommTx.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("txStatus",DatabaseConstants.TransactionStatuses.New))
						.add(Restrictions.eq("txNo",txNo))
						.uniqueResult();
				newIcsRecord = (icsStandingOrdersTx) hibSession.createCriteria(icsStandingOrdersTx.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("txStatus",DatabaseConstants.TransactionStatuses.New))
						.add(Restrictions.eq("txNo",txNo))
						.uniqueResult();
			}
			
			StandingOrderMain mainRecord = null;
			StandingOrderAccount accountRecord = null;
			StandingOrderComm commRecord = null;
			icsStandingOrders icsRecord = null;
			
			if(isNew){
				mainRecord = new StandingOrderMain();
				accountRecord = new StandingOrderAccount();
				commRecord = new StandingOrderComm();
				icsRecord = new icsStandingOrders();
			}
			else{
				mainRecord = (StandingOrderMain) hibSession.createCriteria(StandingOrderMain.class)
						.add(Restrictions.eq("oid", newRecord.getRecordOid()))
						.uniqueResult();
				accountRecord = (StandingOrderAccount) hibSession.createCriteria(StandingOrderAccount.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("standingOrderOid", mainRecord.getOid()))
						.uniqueResult();
				if(mainRecord.getStandingOrderType().equals("KFT")){
					commRecord = (StandingOrderComm) hibSession.createCriteria(StandingOrderComm.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("standingOrderOid", mainRecord.getOid()))
							.uniqueResult();
					icsRecord = (icsStandingOrders) hibSession.createCriteria(icsStandingOrders.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("standingOrderOid", mainRecord.getOid()))
							.uniqueResult();
				}
			}
			
			if(newRecord.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Canelled)){
				mainRecord.setCancelChannel(newRecord.getCancelChannel());
				mainRecord.setCancelUser(newRecord.getCancelUser());
				mainRecord.setCancelDate(newRecord.getCancelDate());
				mainRecord.setUpdateUser(newRecord.getUpdateUser());
				mainRecord.setUpdateDate(newRecord.getUpdateDate());
				mainRecord.setStandingOrderStatus(newRecord.getStandingOrderStatus());
				mainRecord.setTxNo(txNo);
				hibSession.update(mainRecord);
				
				if(mainRecord.getStandingOrderType().equals("KFT")){
					icsRecord.setStandingOrderStatus(newIcsRecord.getStandingOrderStatus());
					icsRecord.setUpdateDate(newIcsRecord.getUpdateDate());
					icsRecord.setUpdateUser(newIcsRecord.getUpdateUser());
					icsRecord.setTxNo(txNo);
					hibSession.update(icsRecord);
				}
			}
			else{
				CommonHelper.mapTxPojoToMainPojo(newRecord, mainRecord);
				hibSession.saveOrUpdate(mainRecord);
				CommonHelper.mapTxPojoToMainPojo(newAccountRecord, accountRecord);
				if (isNew) {
					accountRecord.setStandingOrderOid(mainRecord.getOid());
				}
				hibSession.saveOrUpdate(accountRecord);
				if(mainRecord.getStandingOrderType().equals("KFT")){
					CommonHelper.mapTxPojoToMainPojo(newCommRecord, commRecord);
					if (isNew) {
						commRecord.setStandingOrderOid(mainRecord.getOid());
					}
					hibSession.saveOrUpdate(commRecord);
					CommonHelper.mapTxPojoToMainPojo(newIcsRecord, icsRecord);
					if (isNew) {
						icsRecord.setStandingOrderOid(mainRecord.getOid());
					}
					hibSession.saveOrUpdate(icsRecord);
				}
			}
			
			newRecord.setTxStatus(DatabaseConstants.TransactionStatuses.Finished);
			hibSession.update(newRecord);
			newAccountRecord.setTxStatus(DatabaseConstants.TransactionStatuses.Finished);
			hibSession.update(newAccountRecord);
			
			if(mainRecord.getStandingOrderType().equals("KFT")){
				newCommRecord.setTxStatus(DatabaseConstants.TransactionStatuses.Finished);
				hibSession.update(newCommRecord);
				newIcsRecord.setTxStatus(DatabaseConstants.TransactionStatuses.Finished);
				hibSession.update(newIcsRecord);
				
				CorporateMaster masterRecord = (CorporateMaster)hibSession.createCriteria(CorporateMaster.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("corporateCode", icsRecord.getCorporateCode()))
						.uniqueResult();
				
				hibSession.setReadOnly(masterRecord, true);
				
				if(masterRecord.getIsOnlineCorporate().equals("1")){
					if(isNew){
						String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
						GMMap onlineCorporateServiceCallInputMap = new GMMap();
						GMMap onlineCorporateServiceCallOutputMap = new GMMap();
						onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, masterRecord.getCorporateBankCode());
						onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, masterRecord.getCorporateCode());
						onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
						onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, icsRecord.getSubscriberNo1());
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, icsRecord.getSubscriberNo2());
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO3, icsRecord.getSubscriberNo3());
						onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO4, icsRecord.getSubscriberNo4());
						onlineCorporateServiceCallInputMap.put(MapKeys.CUSTOMER_NO, mainRecord.getCustomerNo());
						onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
						onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, icsRecord.getCollectionType());
						onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE_BEGIN, mainRecord.getStartDate());
						onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, txNo);
						onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);

						if (onlineCorporateServiceCallOutputMap.containsKey("RETURN_INFO_FOR_UPDATE")) {
							if (!onlineCorporateServiceCallOutputMap.getString("RETURN_INFO_FOR_UPDATE").isEmpty()) {
								if ("YES".equals(onlineCorporateServiceCallOutputMap.getString("RETURN_INFO_FOR_UPDATE"))) {
									icsRecord.setSubscriberNo4(onlineCorporateServiceCallOutputMap.getString(MapKeys.SUBSCRIBER_NO4));
									hibSession.update(icsRecord);
								}
							}
						}

//						if (input.containsKey(MapKeys.RECON_CALL) && input.getBoolean(MapKeys.RECON_CALL)) {
//							GMMap reconProcessDataLogInsertInputMap = new GMMap();
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, icsRecord.getCollectionType());
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, icsRecord.getCorporateCode());
//							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
//							}
//							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
//							}
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
//
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, 30);// Talimat
//																																	// Mesaji
//																																	// Gonderildi
//
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO1));
//							if (input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO2) != null) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO2));
//							}
//							if (input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO3) != null) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO3));
//							}
//							if (input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO4) != null) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_4, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO4));
//							}
//
//							CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
//						}
					}
					else{
						if(newRecord.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Canelled)){
							String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
							GMMap onlineCorporateServiceCallInputMap = new GMMap();
							GMMap onlineCorporateServiceCallOutputMap = new GMMap();
							onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, masterRecord.getCorporateBankCode());
							onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, masterRecord.getCorporateCode());
							onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
							onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, icsRecord.getSubscriberNo1());
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, icsRecord.getSubscriberNo2());
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO3, icsRecord.getSubscriberNo3());
							onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO4, icsRecord.getSubscriberNo4());
							onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, icsRecord.getCollectionType());
							onlineCorporateServiceCallInputMap.put(MapKeys.CUSTOMER_NO, mainRecord.getCustomerNo());
							onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
							onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, txNo);
							onlineCorporateServiceCallOutputMap=GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
							
//							GMMap reconProcessDataLogInsertInputMap = new GMMap();
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, collectionType);
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
//							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,
//										onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
//							}
//							if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,
//										onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
//							}
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
//
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE,40);//Talimat Iptal Mesaji Gonderildi
//
//							reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, subscriberNo1);
//							if (subscriberNo2 != null) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2, subscriberNo2);
//							}
//							if (subscriberNo3 != null) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3, subscriberNo3);
//							}
//							if (subscriberNo4 != null) {
//								reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_4, subscriberNo4);
//							}
//							super.callGraymoundServiceAsync("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
						}
					}
				}
				
				if(mainRecord.getStandingOrderStatus().equals(DatabaseConstants.StandingOrderStatus.Canelled)){
					GMMap invoiceCancelInputMap = new GMMap();
					invoiceCancelInputMap.put(CancelAllWaitingInvoices.Input.STANDING_ORDER_MAIN_OID, mainRecord.getOid());
					CommonHelper.callGraymoundServiceInHibernateSession("STO_CANCEL_ALL_WAITING_INVOICES", invoiceCancelInputMap);
				}
			}
			
			hibSession.flush();

		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("STO_STANDING_ORDER_AFTER_REJECTION")
	public static GMMap standingOrderAfterRejection(GMMap input){
		GMMap output = new GMMap();
		
		try{
			BigDecimal txNo = input.getBigDecimal("ISLEM_NO");
			
			Session hibSession = CommonHelper.getHibernateSession();
			StandingOrderMainTx newRecord = (StandingOrderMainTx) hibSession.createCriteria(StandingOrderMainTx.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txStatus", DatabaseConstants.TransactionStatuses.New))
					.add(Restrictions.eq("txNo", txNo))
					.uniqueResult();
			
			newRecord.setStatus(false);
			hibSession.update(newRecord);
			
			StandingOrderAccountTx newAccountRecord = (StandingOrderAccountTx) hibSession.createCriteria(StandingOrderAccountTx.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txStatus", DatabaseConstants.TransactionStatuses.New))
					.add(Restrictions.eq("txNo", txNo))
					.uniqueResult();
			newAccountRecord.setStatus(false);
			hibSession.update(newAccountRecord);
			
			if (newRecord.getStandingOrderType().equals("KFT")) {
				StandingOrderCommTx newCommRecord = (StandingOrderCommTx) hibSession.createCriteria(StandingOrderCommTx.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("txStatus",DatabaseConstants.TransactionStatuses.New))
						.add(Restrictions.eq("txNo",txNo))
						.uniqueResult();
				newCommRecord.setStatus(false);
				hibSession.update(newCommRecord);
				
				icsStandingOrdersTx newIcsRecord = (icsStandingOrdersTx) hibSession.createCriteria(icsStandingOrdersTx.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("txStatus",DatabaseConstants.TransactionStatuses.New))
						.add(Restrictions.eq("txNo",txNo))
						.uniqueResult();
				newIcsRecord.setStatus(false);
				hibSession.update(newIcsRecord);
			}
			
			hibSession.flush();
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("STO_GET_WAITING_ORDER_INFORMATION")
	public static GMMap getWaitingOrderInformation(GMMap input){
		GMMap output = new GMMap();
		
		try{
			BigDecimal trxNo = input.getBigDecimal(MapKeys.TRX_NO);
			Session session = CommonHelper.getHibernateSession();
			
			StandingOrderMainTx mainRecord = (StandingOrderMainTx) session.createCriteria(StandingOrderMainTx.class)
					.add(Restrictions.eq("txNo", trxNo))
					.uniqueResult();
			
			output.put("CUSTOMER_NO", mainRecord.getCustomerNo());
			output.put("CUSTOMER_NAME", DALUtil.getResult("select m.unvan from v_gnl_musteri_kontakt m where m.musteri_no=".concat(mainRecord.getCustomerNo().toString())));
			output.put("STO_STATUS", CommonHelper.getValueOfParameter("CDM_STANDING_ORDER_STATUS", mainRecord.getStandingOrderStatus()));
			output.put("BRANCH_NAME", CommonBusinessOperations.getBranchNameFromBranchCode(mainRecord.getBranchCode()));
			output.put("STO_NO", mainRecord.getStandingOrderNumber());
			output.put("NOTIFY_BEF_PAYMENT", mainRecord.getNotifyBeforePayment().equals("1"));
			output.put("NOTIFY_AF_PAYMENT", mainRecord.getNotifyAfterPayment().equals("1"));
			output.put("USER_LABEL", mainRecord.getUserLabel());
			output.put("NOTIFY_BY_SMS", mainRecord.getNotifyBySms().equals("1"));
			output.put("START_DATE", mainRecord.getStartDate());
			output.put("END_DATE", mainRecord.getEndDate());
			output.put("NOTIFY_BY_EMAIL", mainRecord.getNotfyByEmail().equals("1"));
			
			StandingOrderAccountTx accountRecord = (StandingOrderAccountTx) session.createCriteria(StandingOrderAccountTx.class)
					.add(Restrictions.eq("txNo", trxNo))
					.uniqueResult();
			
			output.put("ACCOUNT_NO", accountRecord.getAccountNumber());
			output.put("IBAN", accountRecord.getIban());
			output.put("PRIORITY", accountRecord.getPriority());
			output.put("CARD_NO", accountRecord.getCardNumber());
			
			if(mainRecord.getStandingOrderType().equals("KFT")){
				StandingOrderCommTx commRecord = (StandingOrderCommTx) session.createCriteria(StandingOrderCommTx.class)
						.add(Restrictions.eq("txNo", trxNo))
						.uniqueResult();
				
				output.put("MOBILE_PHONE", commRecord.getMobilePhone());
				
				icsStandingOrdersTx icsRecord = (icsStandingOrdersTx) session.createCriteria(icsStandingOrdersTx.class)
						.add(Restrictions.eq("txNo", trxNo))
						.uniqueResult();
				
				output.put("CORPORATE_NAME", CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(icsRecord.getCorporateCode()));
				output.put("SECTOR_NAME", CommonBusinessOperations.getSectorNameFromCorporateCode(icsRecord.getCorporateCode()));
				output.put("COLLECTION_TYPE", CommonBusinessOperations.getCollectionTypeName(icsRecord.getCollectionType()));
				output.put("SUBSCRIBER_NO1", icsRecord.getSubscriberNo1());
				output.put("SUBSCRIBER_NO2", icsRecord.getSubscriberNo2());
				output.put("SUBSCRIBER_NO3", icsRecord.getSubscriberNo3());
				output.put("SUBSCRIBER_NO4", icsRecord.getSubscriberNo4());
				
				GMMap metadataRequest = new GMMap();
				metadataRequest.put(MapKeys.CORPORATE_CODE, icsRecord.getCorporateCode());
				metadataRequest.put(MapKeys.COLLECTION_TYPE, icsRecord.getCollectionType());
				
				GMMap metadataResponse = CommonHelper.callGraymoundServiceOutsideSession("CDM_GET_SUBSCRIBER_METADATA", metadataRequest);
				
				int size = metadataResponse.getSize("SUBSCRIBER_METADATA_TABLE");
				output.put("METADATA_SIZE", size);
				for (int i = 1; i <= size; i++) {
					output.put(String.format("SUBSCRIBER_NO%s_LABEL", i), metadataResponse.getString("SUBSCRIBER_METADATA_TABLE", i-1, "LABEL"));
					output.put(String.format("SUBSCRIBER_NO%s_VISIBLE", i), true);
				}
				for (int i = size + 1; i < 5; i++) {
					output.put(String.format("SUBSCRIBER_NO%s_LABEL", i), "");
					output.put(String.format("SUBSCRIBER_NO%s_VISIBLE", i), false);
				}
			}
			else{
				output.put("METADATA_SIZE", 0);
				output.put("SUBSCRIBER_NO1_LABEL", "");
				output.put("SUBSCRIBER_NO1_VISIBLE", false);
				output.put("SUBSCRIBER_NO2_LABEL", "");
				output.put("SUBSCRIBER_NO2_VISIBLE", false);
				output.put("SUBSCRIBER_NO3_LABEL", "");
				output.put("SUBSCRIBER_NO3_VISIBLE", false);
				output.put("SUBSCRIBER_NO4_LABEL", "");
				output.put("SUBSCRIBER_NO4_VISIBLE", false);
			}
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("STO_UPDATE_STANDING_ORDER_CREDIT_CARD_NUMBER")
	public static GMMap updateStandingOrderCreditCardNumber(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session hibSession = CommonHelper.getHibernateSession();
			
			BigDecimal customerNo = input.getBigDecimal("CUSTOMER_NO");
			BigDecimal oldCardNo = input.getBigDecimal("OLD_CARD_NO");
			BigDecimal newCardNo = input.getBigDecimal("NEW_CARD_NO");
			
			List<StandingOrderAccount> soaList = hibSession.createCriteria(StandingOrderAccount.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("cardNumber", oldCardNo))
					.list();
			
			if(soaList.size() == 0){
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, String.format("%s kart numaras�na ait bir kay�t bulunamam��t�r", 
						oldCardNo.toPlainString()));
			}
			
			List<String> standingOrderOidList = new ArrayList<String>();
			
			for (String oid : standingOrderOidList) {
				if(!standingOrderOidList.contains(oid)){
					standingOrderOidList.add(oid);
				}
			}
			
			List<StandingOrderMain> somList = hibSession.createCriteria(StandingOrderMain.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.in("oid", standingOrderOidList))
					.list();
			
			for (StandingOrderMain main : somList) {
				if(!main.getCustomerNo().equals(customerNo)){
					CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, String.format("%s kart numaras�na ait verilen talimatlardan biri i�in %s " +
							"m��teri numaras�ndan farkl� bir m��teri no tan�ml�d�r.", oldCardNo.toPlainString(), customerNo.toPlainString()));
				}
			}
			
			for (StandingOrderAccount acc : soaList) {
				acc.setCardNumber(newCardNo);
				hibSession.update(acc);
			}
			
			hibSession.flush();
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	
	@GraymoundService("STO_CHECK_BULK_EMAIL_DEFINED")
	public static GMMap checkBulkEmailDefined(GMMap input){
		GMMap output = new GMMap();
		
		try{
			BigDecimal accountNo = input.getBigDecimal("ACCOUNT_NO");
			BigDecimal customerNo = input.getBigDecimal("CUSTOMER_NO");
			
			StdBulkEmailDef def = (StdBulkEmailDef) CommonHelper.getHibernateSession().createCriteria(StdBulkEmailDef.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("accountNo", accountNo))
					.add(Restrictions.eq("customerNo", customerNo))
					.uniqueResult();
					
			if(def != null){
				output.put("OUTPUT_TEXT", "Tan�m bulunuyor.");
				output.put("EMAIL", def.getEmail());
			}
			else{
				output.put("OUTPUT_TEXT", "Tan�m bulunmuyor.");
				output.put("EMAIL", "");
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("STO_DEFINE_BULK_EMAIL_FOR_ORDER")
	public static GMMap defineBulkEmailForOrder(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session session = CommonHelper.getHibernateSession();
			BigDecimal accountNo = input.getBigDecimal("ACCOUNT_NO");
			BigDecimal customerNo = input.getBigDecimal("CUSTOMER_NO");
			String email = input.getString("EMAIL");
			
			StdBulkEmailDef def = (StdBulkEmailDef) session.createCriteria(StdBulkEmailDef.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("accountNo", accountNo))
					.add(Restrictions.eq("customerNo", customerNo))
					.uniqueResult();
			
			if(def == null){
				def = new StdBulkEmailDef();
				def.setStatus(true);
				def.setAccountNo(accountNo);
				def.setCustomerNo(customerNo);
				def.setEmail(email);
				session.save(def);
			}
			else{
				if(StringUtil.isEmpty(email)){
					def.setStatus(false);
				}
				else{
					def.setEmail(email);
				}
				def.setUpdateDate(CommonHelper.getLongDateTimeString(new Date()));
				def.setUpdateUser(CommonHelper.getCurrentUser());
				session.update(def);
			}
			session.flush();
			
			output.put("MESSAGE", "Kaydetme i�lemi ba�ar�yla tamamland�.");
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}
