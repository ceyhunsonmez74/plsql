package tr.com.aktifbank.bnspr.cps.session;

import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class SessionManagementServices {
	
	@GraymoundService("CPS_GET_MANAGED_SESSION")
	public static GMMap getManagedSession(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String key = input.getString(MapKeys.SESSION_KEY);
			output.put(MapKeys.SESSION_VALUE, CpsSessionManager.getInstance().getSession(key, input));
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_RENEW_MANAGED_SESSION")
	public static GMMap renewManagedSession(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String key = input.getString(MapKeys.SESSION_KEY);
			CpsSessionManager.getInstance().renewSession(key, input);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}
