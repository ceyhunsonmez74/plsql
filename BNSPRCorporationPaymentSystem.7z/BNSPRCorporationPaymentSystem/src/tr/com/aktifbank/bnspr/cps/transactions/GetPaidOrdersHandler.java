package tr.com.aktifbank.bnspr.cps.transactions;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class GetPaidOrdersHandler extends RequestHandler {

	private static final String RESULT_TABLE_NAME = "PAID_ORDERS";
	
	public GetPaidOrdersHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String customerNo = input.getString(TransactionConstants.GetPaidOrders.Input.CUSTOMER_NO);
		String channelCode = input.getString(TransactionConstants.GetPaidOrders.Input.PAY_CHANNEL_CODE, null);
		
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT cm.CORPORATE_NAME, ip.INVOICE_DUE_DATE, som.STANDING_ORDER_STATUS, ip.PAYMENT_AMOUNT, ");
		queryBuilder.append("ip.SUBSCRIBER_NO1, ip.SUBSCRIBER_NO2, ip.SUBSCRIBER_NO3, ip.SUBSCRIBER_NO4, ip.TX_NO ");
		queryBuilder.append("FROM STO.STANDING_ORDER_MAIN som INNER JOIN ICS.INVOICE_PAYMENT ip ");
		queryBuilder.append("ON som.OID = ip.STANDING_ORDER_OID ");
		queryBuilder.append("INNER JOIN CDM.CORPORATE_MASTER cm ");
		queryBuilder.append("ON ip.CORPORATE_CODE = cm.CORPORATE_CODE ");
		queryBuilder.append("WHERE som.STATUS = 1 AND ip.STATUS = 1 AND cm.STATUS = 1 AND ");
		if(!StringUtil.isEmpty(channelCode)){
			queryBuilder.append(String.format("ip.PAYMENT_CHANNEL = '%s' AND ", channelCode));
		}
		queryBuilder.append(String.format("som.CUSTOMER_NO = '%s' AND ", customerNo));
		queryBuilder.append(String.format("ip.PAYMENT_STATUS = '%s'", DatabaseConstants.PaymentStatuses.Collected));
		
		logger.info(queryBuilder.toString());
		
		GMMap results = DALUtil.getResults(queryBuilder.toString(), RESULT_TABLE_NAME);
		
		for (int i = 0; i < results.getSize(RESULT_TABLE_NAME); i++) {
			output.put(TransactionConstants.GetPaidOrders.Output.PAID_ORDERS_TABLE, i, 
					TransactionConstants.GetPaidOrders.Output.CORPORATE_NAME, 
					results.getString(RESULT_TABLE_NAME, i, "CORPORATE_NAME"));
			output.put(TransactionConstants.GetPaidOrders.Output.PAID_ORDERS_TABLE, i, 
					TransactionConstants.GetPaidOrders.Output.INVOICE_DUE_DATE, 
					results.getString(RESULT_TABLE_NAME, i, "INVOICE_DUE_DATE"));
			output.put(TransactionConstants.GetPaidOrders.Output.PAID_ORDERS_TABLE, i, 
					TransactionConstants.GetPaidOrders.Output.ORDER_STATUS, 
					results.getString(RESULT_TABLE_NAME, i, "STANDING_ORDER_STATUS"));
			output.put(TransactionConstants.GetPaidOrders.Output.PAID_ORDERS_TABLE, i, 
					TransactionConstants.GetPaidOrders.Output.PAID_AMOUNT, 
					results.getString(RESULT_TABLE_NAME, i, "PAYMENT_AMOUNT"));
			output.put(TransactionConstants.GetPaidOrders.Output.PAID_ORDERS_TABLE, i, 
					TransactionConstants.GetPaidOrders.Output.SUBSCRIBER_NO, 
					getSubscriberNoString(results, i));
			output.put(TransactionConstants.GetPaidOrders.Output.PAID_ORDERS_TABLE, i, 
					TransactionConstants.GetPaidOrders.Output.TX_NO, 
					results.getString(RESULT_TABLE_NAME, i, "TX_NO"));
		}
	}

	private String getSubscriberNoString(GMMap results, int index) {
		StringBuilder subscriberNoBuilder = new StringBuilder();
		if(!StringUtil.isEmpty(results.getString(RESULT_TABLE_NAME, index, "SUBSCRIBER_NO1"))){
			subscriberNoBuilder.append(String.format("%s,", results.getString(RESULT_TABLE_NAME, index, "SUBSCRIBER_NO1")));
		}
		
		if(!StringUtil.isEmpty(results.getString(RESULT_TABLE_NAME, index, "SUBSCRIBER_NO2"))){
			subscriberNoBuilder.append(String.format("%s,", results.getString(RESULT_TABLE_NAME, index, "SUBSCRIBER_NO2")));
		}
		
		if(!StringUtil.isEmpty(results.getString(RESULT_TABLE_NAME, index, "SUBSCRIBER_NO3"))){
			subscriberNoBuilder.append(String.format("%s,", results.getString(RESULT_TABLE_NAME, index, "SUBSCRIBER_NO3")));
		}
		
		if(!StringUtil.isEmpty(results.getString(RESULT_TABLE_NAME, index, "SUBSCRIBER_NO4"))){
			subscriberNoBuilder.append(String.format("%s, ", results.getString(RESULT_TABLE_NAME, index, "SUBSCRIBER_NO4")));
		}
		
		String subscriberNo = subscriberNoBuilder.toString();
		
		return StringUtil.isEmpty(subscriberNo) ? "" : subscriberNo.substring(0, subscriberNo.length() - 1);
	}

	private String getOrderStatus(String status) {
		if(status.equals(DatabaseConstants.StandingOrderStatus.Active)){
			return "Aktif";
		}
		else if(status.equals(DatabaseConstants.StandingOrderStatus.Passive)){
			return "Pasif";
		}
		else{
			return "";
		}
	}

}
