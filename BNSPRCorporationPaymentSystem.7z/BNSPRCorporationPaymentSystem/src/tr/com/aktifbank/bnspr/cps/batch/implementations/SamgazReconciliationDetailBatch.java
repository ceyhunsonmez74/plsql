package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.corporation.services.SamgazServices;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.integration.samgaz.SamgazClient;
import tr.com.aktifbank.integration.samgaz.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;
import com.samgaz.entegrasyon.services.BankaIslem;

public final class SamgazReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(SamgazReconciliationDetailBatch.class);
	Session session;
	List<BankaIslem> details = new ArrayList<BankaIslem>();
	ServiceMessage message;
	Map<String, BankaIslem> indexedCorporateRecords;

	public SamgazReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, BankaIslem>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER1, details.get(corporateRecordIndex).getBankaReferansKodu());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String wsUserName = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			Long date= new Long(0);
			if(!StringUtil.isEmpty(input.getString(MapKeys.RECON_DATE))){
				 date = SamgazServices.getTimeStamp(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			}else{
				 date = SamgazServices.getTimeStamp(new Date());
			}
			ServiceMessage serviceMessage= new ServiceMessage();
			List<BankaIslem> detailAll = SamgazClient.getPort(wsUrl, wsUserName, wsPassword, serviceMessage).mutabakatDetayi(date);
			

			for (BankaIslem tahsilat : detailAll) {
				if (!tahsilat.isIptal()) {
					details.add(tahsilat);
				}
			}
			result.setSuccessfulCall(true);
		}
		catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.PARAMETER1, details.get(corporateRecordIndex).getBankaReferansKodu());

	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.PARAMETER1) );
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.PARAMETER1) , super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getBankaReferansKodu() , this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getBankaReferansKodu() );
	}

	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex) throws Exception {

	}

}
