package tr.com.aktifbank.bnspr.cps.acctransfer;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.dto.TransferInformation;

import com.graymound.util.GMMap;

public final class BlockedAccountTransferInformation implements IAccountTransferInformation {
	
	private static final Log logger = LogFactory.getLog(BlockedAccountTransferInformation.class);

	private TransferInformation information;
	Date currentDate;
	
	public BlockedAccountTransferInformation(TransferInformation information) {
		this.information = information;
		this.currentDate = new Date();
	}
	
	@Override
	public int getCount() {
		BigDecimal balance = getBalanceForDay();
		if(balance.compareTo(BigDecimal.ZERO) > 0){
			return 1;
		}
		else{
			return 0;
		}
	}

	@Override
	public BigDecimal getTotalAmount() {
		return getBalanceForDay(); 
	}

	@Override
	public void updateRecords() {
		// No need to update records
	}
	
	private BigDecimal getBalanceForDay() {
		String balanceStartDate = null;
		String balanceEndDate = null;
		
		try {
			String collectionDateString = CommonHelper.getDateString(information.getCollectionDate(), "yyyyMMdd");
			balanceStartDate = collectionDateString.concat("000000");
			balanceEndDate = collectionDateString.concat("235959");
		} catch (Exception e) {
			logger.error("An exception occured while formatting date");
			logger.error(System.currentTimeMillis(), e);
			return BigDecimal.ZERO;
		}
		
		GMMap balanceRequest = new GMMap();
		balanceRequest.put("BAS_TARIH", balanceStartDate);
		balanceRequest.put("SON_TARIH", balanceEndDate);
		balanceRequest.put("MIN_DV_TUTAR", 0);
		balanceRequest.put("MAX_DV_TUTAR", 0);
		balanceRequest.put("HAREKET_TIPI", "G");
		balanceRequest.put("BORC_ALACAK", "A");
		balanceRequest.put("KMH_DAHIL", "H");
		balanceRequest.put("HESAP_NO", this.information.getCorporateAccountNo());
		
		GMMap balanceResponse = CommonHelper.callGraymoundServiceOutsideSession("MT940_QRY2032_GET_CUSTOMER_DETAIL_INFO", balanceRequest);
		
		return balanceResponse.getBigDecimal("TOPLAM");
	}

}
