package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.iski.client.IskiClient;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.gov.iski.ths.bankaonline.webservices.BnkTahsilatMutabakatDetayResponseReturn;


import com.graymound.util.GMMap;

public final class IskiCollectionReconciliationDetailBatch extends
		CollectionReconciliationDetailBatch {
	
	private static final Log logger = LogFactory.getLog(IskiCollectionReconciliationDetailBatch.class);
	
	private static final String COLLECTION_RECON_DETAIL_FAILED = "412";
	private static final String CANCELLED_INVOICE = "403";
	
	IskiClient client;
	BnkTahsilatMutabakatDetayResponseReturn[] details;
	Session session;
	Map<String, BnkTahsilatMutabakatDetayResponseReturn> indexedCorporateRecords;

	public IskiCollectionReconciliationDetailBatch(GMMap input, IskiClient client) {
		super(input);
		this.client = client;
		session = CommonHelper.getHibernateSession();
		indexedCorporateRecords = new HashMap<String, BnkTahsilatMutabakatDetayResponseReturn>();
	}

	@Override
	protected void setCancelCollectionExtraParameters(
			GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put("PARAMETER_1", details[corporateRecordIndex].getMakbuzNo());
		cancelCollectionRequest.put("SUBSCRIBER_NO_1", details[corporateRecordIndex].getSozlesmeNo());
		cancelCollectionRequest.put(MapKeys.TRX_NO, details[corporateRecordIndex].getReferansNo());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()
			throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		
		Date date = input.getDate(MapKeys.RECON_DATE);
		List<String> branchCodes = new ArrayList<String>();
		if(input.containsKey("BRANCHES")){
			GMMap iskiBranches = input.getMap("BRANCHES");
			logger.info("Branches for Iski : " + iskiBranches.toString());
			for (int i = 0; i < iskiBranches.getSize("BRANCH_CODES"); i++) {
				if(!StringUtil.isEmpty(iskiBranches.getString("BRANCH_CODES", i, "BRANCH_CODE"))){
					branchCodes.add(iskiBranches.getString("BRANCH_CODES", i, "BRANCH_CODE"));
				}
			}
		}
		
		if(branchCodes.size() == 0){
			logger.info("No branch returned. Going for default branch recon detail implementation for ISKI.");
			details = client.getReconciliationDetail(date);
			
	
			if(details.length == 1){
				if(details[0].getIslemKodu().equals(COLLECTION_RECON_DETAIL_FAILED)){
					result.setSuccessfulCall(false);
					result.setReturnCode(details[0].getIslemKodu());
				}
				else{
					result.setSuccessfulCall(true);
				}
			}
			else{
				result.setSuccessfulCall(true);
			}
		}
		else{
			List<BnkTahsilatMutabakatDetayResponseReturn> detailList = new ArrayList<BnkTahsilatMutabakatDetayResponseReturn>();
			
			for (String branchCode : branchCodes) {
				BnkTahsilatMutabakatDetayResponseReturn[] detailResult = client.getReconciliationDetail(date, branchCode);
				input.put(String.format("REQUEST_XML%s", branchCodes.indexOf(branchCode)), client.getServiceMessage().getRequest());
				input.put(String.format("RESPONSE_XML%s", branchCodes.indexOf(branchCode)), client.getServiceMessage().getResponse());
				if(detailResult.length == 1){
					if(detailResult[0].getIslemKodu().equals(COLLECTION_RECON_DETAIL_FAILED)){
						// This means no record returned from corporate services for this branch code
					}
					else{
						detailList.add(detailResult[0]);
					}
				}
				else{
					for (int i = 0; i < detailResult.length; i++) {
						detailList.add(detailResult[i]);
					}
				}
			}
			
			this.details = new BnkTahsilatMutabakatDetayResponseReturn[detailList.size()];
			detailList.toArray(this.details);
			result.setSuccessfulCall(true);
		}
		
		return result;
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		BnkTahsilatMutabakatDetayResponseReturn corporateDetail = details[corporateRecordIndex];
		logger.info(String.format("Following corporate record has not been found in database. Voucher No : %s, Reference No : %s, Subscriber No : %s, Amount : %s ", 
				corporateDetail.getMakbuzNo(), 
				corporateDetail.getReferansNo(), 
				corporateDetail.getSozlesmeNo(), 
				corporateDetail.getTutar()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(corporateDetail.getSozlesmeNo());
		payment.setParameter1(corporateDetail.getMakbuzNo());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal(corporateDetail.getReferansNo()));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getSozlesmeNo());
		collectionDetailResponse.put(MapKeys.PARAMETER1, corporateDetail.getMakbuzNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, corporateDetail.getReferansNo());
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getTutar());
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(
			GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, this.details[corporateRecordIndex].getReferansNo());
		
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.length; i++) {
			this.indexedCorporateRecords.put(details[i].getReferansNo(), details[i]);
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		BnkTahsilatMutabakatDetayResponseReturn currentRecord = this.details[corporateRecordIndex];
		if(currentRecord.getIslemKodu().equals(CANCELLED_INVOICE)){
			return true;
		}
		else{
			return super.doesExistWithKey(this.details[corporateRecordIndex].getReferansNo());
		}
	}

}
