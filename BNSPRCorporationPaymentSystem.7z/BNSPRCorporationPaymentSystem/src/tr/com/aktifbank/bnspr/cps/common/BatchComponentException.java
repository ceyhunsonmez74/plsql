package tr.com.aktifbank.bnspr.cps.common;

import java.util.ArrayList;
import java.util.List;

public class BatchComponentException extends Exception {
	/**
	 * Auto generated serial version id
	 */
	private static final long serialVersionUID = 2771420674250009549L;
	long code;
	List<Object> parameters;
	
	public BatchComponentException(long code, Object... params) {
		super();
		this.code = code;
		if(params != null && params.length != 0){
			this.parameters = new ArrayList<Object>();
			for(Object parameter : params){
				this.parameters.add(parameter);
			}
		}
	}
	
	public BatchComponentException(BusinessException exception, Object... params){
		this(exception.getCode(), params);
	}

	public BatchComponentException(String message, long code) {
		super(message);
		this.code = code;
	}
	
	public BatchComponentException(String message, BusinessException exception) {
		this(exception.getCode(), message);
	}

	private static String getMessage(String message, Object... params) {
		return params != null && params.length != 0 ? String.format(message, params) : message;
	}

	public BatchComponentException(Throwable cause, long code) {
		super(cause);
		this.code = code;
	}
	
	public BatchComponentException(Throwable cause, BusinessException exception) {
		this(cause, exception.getCode());
	}

	public BatchComponentException(Throwable cause, String message, long code) {
		super(message, cause);
		this.code = code;
	}
	
	public BatchComponentException(Throwable cause, String message, BusinessException exception) {
		this(cause, message, exception.getCode());
	}
	
	public static BatchComponentException createWithParameteredMessage(long code, String message, Object... params){
		return new BatchComponentException(getMessage(message, params), code);
	}
	
	public static BatchComponentException createWithThrowableAndParameteredMessage(long code, Throwable cause, String message, Object... params){
		return new BatchComponentException(cause, getMessage(message, params), code);
	}
	
	public static BatchComponentException createWithParameteredMessage(BusinessException code, String message, Object... params){
		return new BatchComponentException(getMessage(message, params), code);
	}
	
	public static BatchComponentException createWithThrowableAndParameteredMessage(BusinessException code, Throwable cause, String message, Object... params){
		return new BatchComponentException(cause, getMessage(message, params), code);
	}
	
	public long getCode(){
		return this.code;
	}
	
	public int getIntCode(){
		return (int)this.code;
	}
	
	public short getShortCode(){
		return (short)this.code;
	}
	
	public List<Object> getParameters(){
		return this.parameters;
	}
	
	@Override
	public String toString(){
		return String.format("Batch Component Exception Code is %s, %s", this.code, super.toString());
	}
}
