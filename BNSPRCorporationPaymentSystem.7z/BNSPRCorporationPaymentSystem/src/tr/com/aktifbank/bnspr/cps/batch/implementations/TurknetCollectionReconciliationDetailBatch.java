package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.turknet.client.TurknetClient;
import tr.com.aktifbank.integration.turknet.dto.reconciliation.detail.ReconciliationDetailDto;
import tr.com.aktifbank.integration.turknet.wrapper.ReconciliationDetailResponse;

import com.graymound.util.GMMap;

public class TurknetCollectionReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(TurknetCollectionReconciliationDetailBatch.class);
	
	private static final String ADDED_FILTER = "Iptal";
	
	private TurknetClient client;
	
	private List<ReconciliationDetailDto> details;
	
	private static final String SUCCESS = "0";
	
	private Map<String,ReconciliationDetailDto> indexedCorporateRecords;
	
	
	public TurknetCollectionReconciliationDetailBatch(GMMap input, TurknetClient client) {
		super(input);
		this.client = client;
		indexedCorporateRecords = new HashMap<String, ReconciliationDetailDto>();
	}

	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)throws Exception {
		
		ReconciliationDetailDto invoice = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Subscriber No : %s, Status  : %s, Amount  : %s, Invoice No : %s ", 
				invoice.getSubscriberNo(), 
				invoice.getStatus(), 
				invoice.getPaymentAmount(), 
				invoice.getInvoiceNo()));
		
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(invoice.getSubscriberNo());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal(1));
		payment.setInvoiceNo(invoice.getInvoiceNo());
		payment.setInvoiceAmount(invoice.getPaymentAmount());
		payment.setPaymentAmount(invoice.getPaymentAmount());
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		Session session = CommonHelper.getHibernateSession();
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, invoice.getSubscriberNo());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, invoice.getInvoiceNo());
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, invoice.getPaymentAmount());
	}


	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()throws Exception {
	
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		 
		String reconcilationDate = CommonHelper.getDateString(input.getDate(MapKeys.RECON_DATE),"yyyyMMdd");
		
		ReconciliationDetailResponse reconciliationDetailResponse = client.getReconciliationDetails(reconcilationDate);
		if( null != reconciliationDetailResponse ){
			if( null != reconciliationDetailResponse.getResponse() && reconciliationDetailResponse.getResponse().getReturnCode().equals(SUCCESS) ){
				List<ReconciliationDetailDto> reconciliationDetails = reconciliationDetailResponse.getReconciliationDetails();
				if( null != reconciliationDetails ){
					this.details = reconciliationDetails;
					result.setSuccessfulCall(true);
				}
			}
		}
		
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for( int i = 0; i< size; i++ ){
			GMMap currentRecord = super.getBankRecordAtIndex(i);
			super.setBankRecordIndex(currentRecord.getString(MapKeys.INVOICE_NO), currentRecord);
		}
		
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for( ReconciliationDetailDto detail : details ){
			indexedCorporateRecords.put(detail.getInvoiceNo(), detail);
		}
		
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		if( details.get(corporateRecordIndex).getStatus().equals(ADDED_FILTER) ){
			return true;
		}
		return super.doesExistWithKey(details.get(corporateRecordIndex).getInvoiceNo().toString());
	}
	
	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put("SUBSCRIBER_NO_1", details.get(corporateRecordIndex).getSubscriberNo());
		collectionDetailRequest.put(MapKeys.PAYMENT_DATE, input.getString(MapKeys.RECON_DATE));
		collectionDetailRequest.put(MapKeys.PAYMENT_AMOUNT, details.get(corporateRecordIndex).getPaymentAmount());
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getInvoiceNo());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put("SUBSCRIBER_NO_1", details.get(corporateRecordIndex).getSubscriberNo());
		cancelCollectionRequest.put(MapKeys.PAYMENT_DATE, input.getString(MapKeys.RECON_DATE));
		cancelCollectionRequest.put(MapKeys.PAYMENT_AMOUNT, details.get(corporateRecordIndex).getPaymentAmount());
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getInvoiceNo());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}
}
