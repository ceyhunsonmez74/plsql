package tr.com.aktifbank.bnspr.cps.multithreading.core;

import java.util.List;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cps.dto.ParallelCallResult;

public interface ParallelCallBehaviour {
	void call(List<GMMap> tasks);
	ParallelCallResult getResult();
}
