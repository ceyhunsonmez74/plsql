package tr.com.aktifbank.bnspr.cps.transactions;

import java.sql.Clob;

import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.BatchSubmitLog;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class InsertBatchSubmitLogHandler extends RequestHandler {
	
	public InsertBatchSubmitLogHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String submitId = input.getString(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_ID);
		if(input.containsKey(TransactionConstants.InsertBatchSubmitLog.Input.IS_UPDATE) && input.getBoolean(TransactionConstants.InsertBatchSubmitLog.Input.IS_UPDATE)){
			logger.info("Batch Submit Log Update");
			BatchSubmitLog log = (BatchSubmitLog)super.getHibernateSession().createCriteria(BatchSubmitLog.class).add(Restrictions.eq("batchSubmitId", submitId)).uniqueResult();
			log.setSubmitStatus(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_STATUS));
			if(input.containsKey(TransactionConstants.InsertBatchSubmitLog.Input.ERROR_CODE)){
				logger.info(String.format("Error code : %s", input.getString(TransactionConstants.InsertBatchSubmitLog.Input.ERROR_CODE)));
				log.setErrorCode(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.ERROR_CODE));
			}
			if(input.containsKey(TransactionConstants.InsertBatchSubmitLog.Input.ERROR_DESCRIPTION)){
				String errorDesc = input.getString(TransactionConstants.InsertBatchSubmitLog.Input.ERROR_DESCRIPTION);
				Clob errorDescClob = new ClobImpl(errorDesc);
				log.setErrorDesc(errorDescClob);
			}
			String endDate = input.getString(TransactionConstants.InsertBatchSubmitLog.Input.END_TIME, null);
			if (!StringUtil.isEmpty(endDate)) {
				log.setEndTime(endDate);
			}
			logger.info("Saving log");
			super.getHibernateSession().saveOrUpdate(log);
			logger.info("Flushing session");
			super.getHibernateSession().flush();
		}
		else {
			logger.info("Batch Submit Log Insert");
			BatchSubmitLog log = new BatchSubmitLog();
			log.setBatchName(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.BATCH_NAME));
			log.setStatus(true);
			log.setBatchSubmitId(submitId);
			log.setCorporateCode(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.CORPORATE_CODE));
			log.setSubmitStatus(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_STATUS));
			log.setSubmitUser(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_USER));
			log.setSubmitDate(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_DATE));
			log.setStartTime(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.START_TIME));
			if(input.containsKey(TransactionConstants.InsertBatchSubmitLog.Input.PARAMETERS)){
				log.setParameters(input.getString(TransactionConstants.InsertBatchSubmitLog.Input.PARAMETERS));
			}
			logger.info("Saving log");
			super.getHibernateSession().save(log);
			logger.info("Flushing session");
			super.getHibernateSession().flush();
		}
	}

}
