package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileBatchInformation;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;

import com.graymound.util.GMMap;

public class InformInvoiceCollectionExcelFileBatch extends OutgoingFileBatch {

	protected static final String tableName = "LIST";
	
	public InformInvoiceCollectionExcelFileBatch(
			OutgoingFileBatchInformation information) {
		super(information);
	}

	
	@Override
	public void execute(){
		try{
			Object records = getRecords();
			
			String ftmDelimiter = null;
			
			final String defaultDelimiter = ";";
			String delimiter = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "INVOICE_COLLECTION_WITH_EXCEL_DELIMITER");
			
			if (StringUtils.isNotEmpty(delimiter))
				ftmDelimiter = delimiter;
			else 
				ftmDelimiter = defaultDelimiter;
				
			int lineCounter = 1;
			StringBuilder headerLine = new StringBuilder();
			headerLine.append("�deme Tarihi").append(ftmDelimiter);
			headerLine.append("Kurum Ad�").append(ftmDelimiter);
			headerLine.append("Fatura No").append(ftmDelimiter);
			headerLine.append("Abone No").append(ftmDelimiter);
			headerLine.append("Son �deme Tarihi").append(ftmDelimiter);
			headerLine.append("�deme Tutar�").append(ftmDelimiter);
			headerLine.append("��lem No");
			
			FtmFileContent headerContent = new FtmFileContent();
			headerContent.setOid(String.valueOf(lineCounter));
			headerContent.setFtmProcessOid(this.information.getFtmProcessId());
			headerContent.setLine(headerLine.toString());
			headerContent.setLineNumber(new BigDecimal(lineCounter));
			this.information.getHibernateSession().save(headerContent);
			lineCounter++;
			
			for (int i = 0; i < getRecordsSize(records); i++) {

				GMMap currentRow = getCurrentRow(records, i);
				
				String paymentAmount = currentRow.getString("PAYMENT_AMOUNT");
//				if (StringUtils.isNotEmpty(paymentAmount))
//					paymentAmount = paymentAmount.replace(".", ",");
				
				StringBuilder line = new StringBuilder();
				line.append(currentRow.getString("PAYMENT_DATE")).append(ftmDelimiter);
				line.append(currentRow.getString("SHORT_CODE")).append(ftmDelimiter);
				line.append(currentRow.getString("INVOICE_NO")).append(ftmDelimiter);
				line.append(currentRow.getString("SUBSCRIBER_NO1")).append(ftmDelimiter);
				line.append(currentRow.getString("INVOICE_DUE_DATE")).append(ftmDelimiter);
				line.append(paymentAmount).append(ftmDelimiter);
				line.append(currentRow.getString("TX_NO"));
				
				FtmFileContent content = new FtmFileContent();
				content.setOid(String.valueOf(lineCounter));
				content.setFtmProcessOid(this.information.getFtmProcessId());
				content.setLine(line.toString());
				content.setLineNumber(new BigDecimal(lineCounter));
				this.information.getHibernateSession().save(content);
				lineCounter++;
			}
			
			this.setDetailLineCount(lineCounter-1);
		}
		catch(BatchComponentException ex){
			logger.error(String.format("[OutgoingFileBatch] An exception occured while prepared a batch file. Details %s ", ex.getMessage()));
			logger.error(System.currentTimeMillis(), ex);
			
			this.setErrorExist(true);
			this.setErrorMessage(ex.getMessage());
			this.setErrorCode(String.valueOf(ex.getCode()));
		}
		catch(Exception ex){
			logger.error(String.format("[OutgoingFileBatch] An exception occured while prepared a batch file. Details : %s ", 
					ex.getMessage()));
			logger.error(System.currentTimeMillis(), ex);
			
			this.setErrorExist(true);
			this.setErrorMessage(CommonHelper.getStringifiedException(ex));
			this.setErrorCode("0");

		}
		catch (Throwable ex) {
			logger.error(String.format("[OutgoingFileBatch] An exception occured while prepared a batch file. Details : %s ", 
					ex.getMessage()));
			logger.error(System.currentTimeMillis(), ex);
			
			this.setErrorExist(true);
			this.setErrorMessage(CommonHelper.getStringifiedException(ex));
			this.setErrorCode("0");
		}
	}
	
	@Override
	protected Object getRecords() throws Throwable {
		
		Date processDate = null;
		if (this.information.getProcessDate() != null)
			processDate = this.information.getProcessDate();
		else 
			processDate = CommonHelper.addDay(new Date(), -1);

		GMMap paymentDetailReportRequest = new GMMap();
		paymentDetailReportRequest.put("START_DATE", CommonHelper.getShortDateTimeString(processDate));
		paymentDetailReportRequest.put("END_DATE", CommonHelper.getShortDateTimeString(processDate));
		paymentDetailReportRequest.put("CORPORATE_CODE", this.information.getCorporateCode());
		paymentDetailReportRequest.put("STATUS_ID", DatabaseConstants.PaymentStatuses.Collected);
		paymentDetailReportRequest.put("SECTOR_CODE", "SECIMYOK");
		paymentDetailReportRequest.put("ACTION_TYPE", "LIST");
		return CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_PAYMENTS_DETAIL_REPORT", paymentDetailReportRequest);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Object getDataFromSource(String fieldName, Object records,
			int index) throws Throwable {
		GMMap paymentRecords = (GMMap)records; 
		Object data = null;
		List<HashMap<Object, Object>> mapList = (List<HashMap<Object, Object>>)paymentRecords.get(tableName);
		HashMap<Object, Object> currentIndex = mapList.get(index);
		if(currentIndex.containsKey(fieldName)){
			data = currentIndex.get(fieldName);
		}
		else{
			throw new Exception(String.format("Field %s cannot be found on both invoice payment and invoice main tables", fieldName));
		}
		return data;
	}

	@Override
	protected int getRecordsSize(Object records) throws Throwable {
		GMMap paymentRecords = (GMMap)records;
		return paymentRecords.getSize(tableName);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected GMMap getCurrentRow(Object records, int index) throws Exception {
		GMMap recordSet = (GMMap)records;
		List<HashMap<Object, Object>> recordList = (List<HashMap<Object, Object>>)recordSet.get(tableName);
		HashMap<Object, Object> currentIndex = recordList.get(index);
		return CommonHelper.convertMapToGMMap(currentIndex);
	}

}
