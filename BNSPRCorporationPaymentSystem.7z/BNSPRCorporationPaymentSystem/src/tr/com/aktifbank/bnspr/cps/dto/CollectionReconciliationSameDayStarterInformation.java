package tr.com.aktifbank.bnspr.cps.dto;

import java.util.Date;

import com.graymound.util.GMMap;

public class CollectionReconciliationSameDayStarterInformation extends	BaseTransferObject {


	public CollectionReconciliationSameDayStarterInformation() {
	}

	private GMMap corporateMap = new GMMap();
	private int maxParallelThreadCount;
	private Date processDate;
	private String serviceName;

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Date getProcessDate() {
		return processDate;
	}
	
	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}
	
	public int getMaxParallelThreadCount() {
		return maxParallelThreadCount;
	}
	
	public void setMaxParallelThreadCount(int maxParallelThreadCount) {
		this.maxParallelThreadCount = maxParallelThreadCount;
	}
	
	public GMMap getCorporateMap() {
		return corporateMap;
	}
	
	public void setCorporateMap(GMMap corporateMap) {
		this.corporateMap = corporateMap;
	}



}
