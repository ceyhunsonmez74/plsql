package tr.com.aktifbank.bnspr.cps.transactions;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.GetBalanceTransferLog;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.UpdateBalanceTransferInformation;
import tr.com.aktifbank.bnspr.dao.BalanceTransferProcess;

import com.graymound.util.GMMap;

public class UpdateBalanceTransferInformationHandler extends RequestHandler{

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		String balanceTransferProcessId = input.getString(UpdateBalanceTransferInformation.Input.BALANCE_TRANSFER_PROCESS_ID,null);
		
		if( null == balanceTransferProcessId  ){
			throw new Exception("Balance Transfer Process Value cannot be supplied.");
		}
		
		BalanceTransferProcess balanceTransferProcessResult = (BalanceTransferProcess) super.getHibernateSession().createCriteria(BalanceTransferProcess.class)
			.add(Restrictions.eq("oid", balanceTransferProcessId)).uniqueResult();
		
		if( null != balanceTransferProcessResult ){

			balanceTransferProcessResult.setTransferStatus((byte)0);
			
			this.callServiceWithSessionOption(GetBalanceTransferLog.SERVICE_NAME,true,
					GetBalanceTransferLog.Input.BALANCE_TRANSFER_PROCESS_ID, balanceTransferProcessId );
			
			super.getHibernateSession().saveOrUpdate(balanceTransferProcessResult);
			super.getHibernateSession().flush();
		}
		
	}

}
