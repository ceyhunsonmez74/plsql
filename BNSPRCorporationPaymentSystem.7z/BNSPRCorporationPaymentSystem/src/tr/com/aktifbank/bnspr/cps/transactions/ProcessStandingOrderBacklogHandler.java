package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.List;

import org.apache.axis.utils.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.dao.StandingOrderBacklog;
import tr.com.aktifbank.bnspr.dao.invoiceMain;
import tr.com.aktifbank.bnspr.dao.invoicePayment;

import com.graymound.util.GMMap;

public class ProcessStandingOrderBacklogHandler extends RequestHandler {

	public ProcessStandingOrderBacklogHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		List<StandingOrderBacklog> logList = super.getHibernateSession().createCriteria(StandingOrderBacklog.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.or(Restrictions.eq("isLoaded", false), Restrictions.eq("isPaid", false)))
				.list();
		
		for (StandingOrderBacklog backlog : logList) {
			Criteria criteria = super.getHibernateSession().createCriteria(invoiceMain.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("standingOrderOid", backlog.getStandingOrderOid()))
					.add(Restrictions.eq("amount", backlog.getAmount()));
			
			if(!StringUtils.isEmpty(backlog.getInvoiceNo())){
				criteria = criteria.add(Restrictions.eq("invoiceNo", backlog.getInvoiceNo()));
			}
			
			if(!StringUtils.isEmpty(backlog.getInvoiceDueDate())){
				criteria = criteria.add(Restrictions.eq("invoiceDueDate", backlog.getInvoiceDueDate()));
			}
			
			List<invoiceMain> mainRecordList = criteria.list();
			
			if(mainRecordList.size() > 1){
				continue;
			}
			else{
				if(mainRecordList.size() < 1){
					continue;
				}
				else{
					invoiceMain mainRecord = mainRecordList.get(0);
					backlog.setIsLoaded(true);
					backlog.setLoadDate(mainRecord.getLoadingDate().substring(0, 8));
					if(mainRecord.getPaymentStatus().equals(DatabaseConstants.PaymentStatuses.Collected)){
						invoicePayment paymentRecord = (invoicePayment) super.getHibernateSession().createCriteria(invoicePayment.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
								.add(Restrictions.eq("invoiceMainOid", mainRecord.getOid()))
								.uniqueResult();
						backlog.setIsPaid(true);
						backlog.setPaymentDate(paymentRecord.getPaymentDate().substring(0, 8));
					}
					
					super.getHibernateSession().update(backlog);
				}
			}
		}
	}

}
