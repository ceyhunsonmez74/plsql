package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.FileErrorLog;

import com.graymound.util.GMMap;

public class InsertFileErrorLogHandler extends RequestHandler {

	public InsertFileErrorLogHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String ftmId = input.getString(TransactionConstants.InsertFileErrorLog.Input.FTM_ID);
		BigDecimal ftmTransferId = input.getBigDecimal(TransactionConstants.InsertFileErrorLog.Input.FTM_TRANSFER_ID);
		String batchSubmitId = input.getString(TransactionConstants.InsertFileErrorLog.Input.BATCH_SUBMIT_ID);
		BigDecimal lineNumber = input.getBigDecimal(TransactionConstants.InsertFileErrorLog.Input.LINE_NUMBER);
		String line = input.getString(TransactionConstants.InsertFileErrorLog.Input.LINE);
		String errorCode = input.getString(TransactionConstants.InsertFileErrorLog.Input.ERROR_CODE);
		String errorMessage = input.getString(TransactionConstants.InsertFileErrorLog.Input.ERROR_MESSAGE);
		
		if(errorMessage != null && errorMessage.length() > 1000){
			errorMessage = errorMessage.substring(0 ,950);
		}
		Date processDate = new Date();
		FileErrorLog log = new FileErrorLog();
		log.setBatchSubmitId(batchSubmitId);
		log.setFtmId(ftmId);
		log.setFtmSequenceNumber(ftmTransferId);
		log.setLineNumber(lineNumber);
		log.setErroneousLine(line);
		log.setErrorCode(errorCode);
		log.setErrorDesc(errorMessage);
		log.setStatus(true);
		log.setProcessDate(CommonHelper.getShortDateTimeString(processDate));
		log.setProcessTime(new SimpleDateFormat("hhmmss").format(processDate));
		super.getHibernateSession().save(log);
		super.getHibernateSession().flush();
	}
	
	@Override
	protected void handleError(Throwable e, GMMap output) {
		logger.error("An exception occured while inserting file error log");
		logger.error(System.currentTimeMillis(), e);
	}

}
