package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public abstract class StandingOrderReconciliationDetailBatch extends
		ReconciliationDetailBatch {
	
	private static final Log logger = LogFactory.getLog(StandingOrderReconciliationDetailBatch.class);
	
	List<icsStandingOrders> bankStandingOrderList;
	Map<String, icsStandingOrders> indexedBankRecords;

	public StandingOrderReconciliationDetailBatch(GMMap input) {
		super(input);
		indexedBankRecords = new HashMap<String, icsStandingOrders>();
	}
	
	protected abstract void setCancelStandingOrderExtraParameters(GMMap cancelStandingOrderRequest, int corporateRecordIndex);
	protected abstract void setCorporateParametersToReconProcessLogInput(GMMap reconProcessDataLogInput, int corporateRecordIndex);
	protected abstract boolean doesBankRecordExistInCorporateRecords(icsStandingOrders bankRecord);

	@SuppressWarnings("unchecked")
	@Override
	protected void callBankReconDetail() throws Exception {
		GMMap rcInput = new GMMap();
		rcInput.put(TransactionConstants.GetStandingOrderCount.Input.CORPORATE_CODE,
				input.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
		rcInput.put("RECON_DATE", input.getString(MapKeys.PROCESS_DATE));
		bankStandingOrderList = (List<icsStandingOrders>) CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER", rcInput).get("LIST");;
	}
	
	protected icsStandingOrders getBankRecordAtIndex(int index){
		return this.bankStandingOrderList.get(index);
	}
	
	protected void setBankRecordIndex(String key, icsStandingOrders order){
		this.indexedBankRecords.put(key, order);
	}
	
	protected boolean doesExistWithKey(String key){
		return this.indexedBankRecords.containsKey(key);
	}
	
	protected int getBankRecordsSize(){
		return this.bankStandingOrderList.size();
	}
	
	@Override
	protected boolean doesBankRecordExistInCorporateRecords(int bankRecordIndex) {
		return this.doesBankRecordExistInCorporateRecords(this.bankStandingOrderList.get(bankRecordIndex));
	}

	@Override
	protected void onBankRecordNotFound(int bankRecordIndex) throws Exception {
		String reconLogOid = input.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
		GMMap params = new GMMap();
		if( corporateCode.contains(",") ){	
			Set<Entry<Object, Object>> entrySet = input.entrySet();
			Iterator<Entry<Object, Object>> iterator = entrySet.iterator();
			while( iterator.hasNext() ){
				Entry<Object, Object> nextElement = iterator.next();
				if( input.containsKey(nextElement.getKey()) ){
					params.put(nextElement.getKey().toString(), nextElement.getValue().toString());
				}
			}
		}
		GMMap cdMap =  null;
		if( params.size() > 0 ){
			cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", params);
		}
		else{
		cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", input);
		}
		String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
		String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
		GMMap onlineCorporateServiceCallInputMap = new GMMap();
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, bankStandingOrderList.get(bankRecordIndex).getSubscriberNo1());
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, bankStandingOrderList.get(bankRecordIndex).getSubscriberNo2());
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO3, bankStandingOrderList.get(bankRecordIndex).getSubscriberNo3());
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO4, bankStandingOrderList.get(bankRecordIndex).getSubscriberNo4());
		onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
		onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, input.get(MapKeys.RECON_DATE));
		onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, bankStandingOrderList.get(bankRecordIndex).getTxNo());
		onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, bankStandingOrderList.get(bankRecordIndex).getCorporateCode());
		onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
		onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
		onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
		onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
		GMMap onlineCorporateServiceCallOutput = new GMMap();
		
		try {
			onlineCorporateServiceCallOutput = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL",onlineCorporateServiceCallInputMap);
		} catch (Exception e) {
			logger.error("An exception occured while cancelling invoice for reconciliation");
			logger.error(System.currentTimeMillis(), e);
			onlineCorporateServiceCallOutput.put(MapKeys.ERROR_DESC, e.toString());
			onlineCorporateServiceCallOutput.put(MapKeys.ERROR_CODE, 9999);
		}
		insertReconProcessDataLog(bankRecordIndex, -1, reconLogOid, corporateCode,
				stanNoSequenceKey, onlineCorporateServiceCallOutput);
	}

	private void insertReconProcessDataLog(int bankRecordIndex, int corporateRecordIndex,
			String reconLogOid, String corporateCode, String stanNoSequenceKey,
			GMMap onlineCorporateServiceCallOutput) {
		GMMap reconProcessDataLogInsertInputMap = new GMMap();
		
		if(onlineCorporateServiceCallOutput.containsKey(MapKeys.ERROR_DESC)){
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC, onlineCorporateServiceCallOutput.get(MapKeys.ERROR_DESC));
		}
		
		if(onlineCorporateServiceCallOutput.containsKey(MapKeys.ERROR_CODE)){
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE, onlineCorporateServiceCallOutput.get(MapKeys.ERROR_CODE));
		}
		
		reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
		reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
		reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
		if (bankRecordIndex != -1) {
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.standingOrderMessageSent);
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, bankStandingOrderList.get(bankRecordIndex).getCollectionType());
			reconProcessDataLogInsertInputMap
					.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,
							bankStandingOrderList.get(bankRecordIndex)
									.getSubscriberNo1());
			reconProcessDataLogInsertInputMap
					.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2,
							bankStandingOrderList.get(bankRecordIndex)
									.getSubscriberNo2());
			reconProcessDataLogInsertInputMap
					.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3,
							bankStandingOrderList.get(bankRecordIndex)
									.getSubscriberNo3());
			reconProcessDataLogInsertInputMap
					.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_4,
							bankStandingOrderList.get(bankRecordIndex)
									.getSubscriberNo4());
		}
		else{
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.cancelStandingOrderMessageSent);
			this.setCorporateParametersToReconProcessLogInput(reconProcessDataLogInsertInputMap, corporateRecordIndex);
		}
		CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
	}

	@Override
	protected void onCorporateRecordNotFound(int corporateRecordIndex) throws Exception {
		
		String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
		String reconLogOid = input.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		
		GMMap onlineCorporateServiceCallInputMap = new GMMap();
		onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
		onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
		onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
		onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
		onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
		onlineCorporateServiceCallInputMap.put(MapKeys.RECON_DATE, input.get(MapKeys.RECON_DATE));
		this.setCancelStandingOrderExtraParameters(onlineCorporateServiceCallInputMap, corporateRecordIndex);
		GMMap onlineCorporateServiceCallOutputMap = new GMMap();
		
		try {
			onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
		} catch (Exception e) {
			logger.error("An exception occured while cancelling invoice for reconciliation");
			logger.error(System.currentTimeMillis(), e);
			onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.toString());
			onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
		}
		
		insertReconProcessDataLog(-1, corporateRecordIndex, reconLogOid, corporateCode, stanNoSequenceKey, onlineCorporateServiceCallOutputMap);
	}

}
