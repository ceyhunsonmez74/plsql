package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CollectionTypePrm;
import tr.com.aktifbank.bnspr.dao.invoiceMain;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.bnspr.dao.invoicePaymentLog;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class DoInvoiceCollectionHandler extends RequestHandler {
	
	private static class BagKeys{
		public static final String TRANSACTION_NO = "TRANSACTION_NO"; 
		public static final String COLLECTION_STEP = "COLLECTION_STEP";
		public static final String SOURCE_CODE = "SOURCE_CODE";
		public static final String CARD_NO = "CARD_NO";
		public static final String MERCHANT_CODE = "MERCHANT_CODE";
		public static final String AMOUNT = "AMOUNT";
		public static final String COMM_AMOUNT = "COMM_AMOUNT";
	}
	
	private static class StepNames {
		public static final String START = "START";
		public static final String CARD_COLLECTION = "CARD_COLLECTION";
		public static final String ACCOUNTING = "ACCOUNTING";
		public static final String CORPORATE_CALL = "CORPORATE_CALL";
	}

	private static final String CARD_COLLECTION_SUCCESSFUL = "2";
	private static final String YIM_CHANNEL_NKOLAY = "M";
	private static final String YIM_CHANNEL_EPOS = "K";

	public DoInvoiceCollectionHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		bag.put(BagKeys.COLLECTION_STEP, StepNames.START);
		Session session = CommonHelper.getHibernateSession();
		String corporateCode = input.getString(TransactionConstants.DoInvoiceCollection.Input.CORPORATE_CODE);
		String sourceCode = input.getString(TransactionConstants.DoInvoiceCollection.Input.SOURCE);
		bag.put(BagKeys.SOURCE_CODE, sourceCode);
		String invoiceDueDate = input.getString(TransactionConstants.DoInvoiceCollection.Input.INVOICE_DUE_DATE);
		String channelId = input.getString(TransactionConstants.DoInvoiceCollection.Input.CHANNEL_CODE, null);
		
		int subscriberHash = input.getInt("SUBSCRIBER_HASH");
		
		if (StringUtil.isEmpty(channelId)) {
			channelId = CommonHelper.getChannelId();
		}
		
		input.put(TransactionConstants.DoInvoiceCollection.Input.CHANNEL_CODE, channelId);
		
		if(!StringUtil.isEmpty(input.getString("CORPORATE_STAN_KEY", null))){
			input.put("CORPORATE_STAN", CorporationServiceUtil.getSequenceCode(input.getString("CORPORATE_STAN_KEY")));
		}
		
		if(input.getBoolean("REFERENCE_EXISTS", false)){
			checkIfPaymentExistsWithQueryRefNo(input.getBigDecimal(TransactionConstants.DoInvoiceCollection.Input.QUERY_REF_NO));
		}
		
		GMMap corpMap = new GMMap();
		corpMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corporateDefinitionOutput = super.callGraymoundServiceInSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, corpMap);
		
		short collectionType = Short.parseShort(input.getString(TransactionConstants.DoInvoiceCollection.Input.COLLECTION_TYPE, String.valueOf(GeneralConstants.COLLECTION_TYPE_NOT_MENTIONED)));
		
		collectionType = CommonBusinessOperations.manipulateCollectionTypeForChannels(collectionType, corporateDefinitionOutput.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
		
		input.put(TransactionConstants.DoInvoiceCollection.Input.COLLECTION_TYPE, collectionType);
		
		if(input.getBoolean("CHECK_HASH", true)){
			int currentHash = CommonBusinessOperations.getMetadataHash(corporateCode, collectionType, channelId);
			if(currentHash != subscriberHash){
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, "Referans numaralar�nda bir de�i�iklik yap�lm��t�r, l�tfen borcu tekrar sorgulayarak deneyiniz");
			}
		}
		
		if(input.containsKey(TransactionConstants.DoInvoiceCollection.Input.COLLECTION_TYPE_NAME)){
			CollectionTypePrm collectionTypePrm=(CollectionTypePrm) session.createCriteria(CollectionTypePrm.class)
					.add(Restrictions.eq("collectionType", collectionType)).uniqueResult();
			
			String collectionTypeName = collectionTypePrm.getCollectionName();
			input.put(TransactionConstants.DoInvoiceCollection.Input.COLLECTION_TYPE_NAME, collectionTypeName);
		}
		
		BigDecimal transactionNo = input.getBigDecimal(TransactionConstants.DoInvoiceCollection.Input.TRX_NO);
		bag.put(BagKeys.TRANSACTION_NO, transactionNo);
		BigDecimal paymentAmount = input.getBigDecimal(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_AMOUNT);
		bag.put(BagKeys.AMOUNT, paymentAmount);
		BigDecimal amount = input.getBigDecimal(TransactionConstants.DoInvoiceCollection.Input.INVOICE_AMOUNT);
		BigDecimal commissionAmount = null;
		BigDecimal bsmvAmount = null;
		
		
		if(!corporateDefinitionOutput.getBoolean(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_ACTIVENESS)){
			throw new BatchComponentException(BusinessException.CORPORATEISNOTACTIVE, corporateCode);
		}
		
		String subscriberNo1 = input.getString(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO1,null);
		String subscriberNo2 = input.getString(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO2,null);
		String subscriberNo3 = input.getString(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO3,null);
		String subscriberNo4 = input.getString(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO4,null);
		
		GMMap controlSubscriberMetaDataMap =  super.callServiceWithParams(TransactionConstants.ControlSubscriberMetaData.SERVICE_NAME, 
				TransactionConstants.ControlSubscriberMetaData.Input.CHANNEL_CODE, channelId,
				TransactionConstants.ControlSubscriberMetaData.Input.COLLECTION_TYPE, collectionType,
				TransactionConstants.ControlSubscriberMetaData.Input.CORPORATE_CODE, corporateCode,
				TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO1, subscriberNo1,
				TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO2,subscriberNo2,
				TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO3,subscriberNo3,
				TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO4,subscriberNo4);
		
		CommonHelper.makeSubscriberNoMask(input, controlSubscriberMetaDataMap);
		
		String corporateName = corporateDefinitionOutput.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_NAME);
		input.put(MapKeys.CORPORATE_NAME,corporateName);
		
		if (isEPOSChannelforTransfer(corporateCode, channelId, input.getString(MapKeys.YIM_CHANNEL))) {
			channelId= GeneralConstants.EPOS_CHANNEL_CODE;
		}
		
		GMMap controlOutput = super.callServiceWithParams(TransactionConstants.ControlInvoiceCollection.SERVICE_NAME,
				TransactionConstants.ControlInvoiceCollection.Input.CHANNEL_CODE, channelId,
				TransactionConstants.ControlInvoiceCollection.Input.COLLECTION_TYPE, collectionType,
				TransactionConstants.ControlInvoiceCollection.Input.CORPORATE_CODE, corporateCode,
				TransactionConstants.ControlInvoiceCollection.Input.INVOICE_DUE_DATE, invoiceDueDate,
				TransactionConstants.ControlInvoiceCollection.Input.PAYMENT_AMOUNT, paymentAmount,
				TransactionConstants.ControlInvoiceCollection.Input.AMOUNT, amount,
				TransactionConstants.ControlInvoiceCollection.Input.SOURCE, sourceCode,
				TransactionConstants.ControlInvoiceCollection.Input.SUBSCRIBER_NO1, subscriberNo1,
				TransactionConstants.ControlInvoiceCollection.Input.SUBSCRIBER_NO2, subscriberNo2,
				TransactionConstants.ControlInvoiceCollection.Input.SUBSCRIBER_NO3, subscriberNo3,
				TransactionConstants.ControlInvoiceCollection.Input.SUBSCRIBER_NO4, subscriberNo4);
		
		//talimatl� tahsilatlardan komisyon al�nmayabilir
	    if (input.getString(TransactionConstants.DoInvoiceCollection.Input.CALCULATE_COMMISSION,"1").equals("1")) {
	    	
	    	GMMap commissionOutput = super.callServiceWithParams(TransactionConstants.CalculateCommission.SERVICE_NAME,
					TransactionConstants.CalculateCommission.Input.CORPORATE_CODE, corporateCode,
					TransactionConstants.CalculateCommission.Input.CHANNEL_CODE, channelId,
					TransactionConstants.CalculateCommission.Input.PAYMENT_AMOUNT, paymentAmount,
					TransactionConstants.CalculateCommission.Input.CHECK_EXEMPTION, "1",
					TransactionConstants.CalculateCommission.Input.ACCOUNT_NO, input.getString(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_ACCOUNT_NO),
					TransactionConstants.CalculateCommission.Input.CUSTOMER_NO, input.getString(TransactionConstants.DoInvoiceCollection.Input.CUSTOMER_NO),
					TransactionConstants.CalculateCommission.Input.PROCESS_DEF_ID, "7010");
		
			commissionAmount = commissionOutput.getBigDecimal(TransactionConstants.CalculateCommission.Output.COMMISSION_AMOUNT);
			bsmvAmount = commissionOutput.getBigDecimal(TransactionConstants.CalculateCommission.Output.BSMV_AMOUNT);
			
		}else {
			commissionAmount = BigDecimal.ZERO;
			bsmvAmount = BigDecimal.ZERO;
			
		}
	    
	    bag.put(BagKeys.COMM_AMOUNT, commissionAmount.add(bsmvAmount));

		input.put(MapKeys.COMMISION_AMOUNT, commissionAmount);
		input.put(MapKeys.BSMV_AMOUNT, bsmvAmount);
		input.put(MapKeys.ACCOUNT_NO,controlOutput.getBigDecimal(TransactionConstants.ControlInvoiceCollection.Output.ACCOUNT_NO));
		if(!input.containsKey(TransactionConstants.DoInvoiceCollection.Input.QUERY_REF_NO)){
			input.put(TransactionConstants.DoInvoiceCollection.Input.QUERY_REF_NO, transactionNo);
		}
		
		
		input.put(MapKeys.TRX_NAME, "7010");
		input.put(MapKeys.TRX_NO, transactionNo);
		
		if (corporateDefinitionOutput.getString(MapKeys.IS_ONLINE_CORPORATE).equals("1")) {
			input.put(MapKeys.BANK_CODE, corporateDefinitionOutput.getString(MapKeys.BANK_CODE));
			input.put(MapKeys.CORPORATE_CODE, corporateDefinitionOutput.getString(MapKeys.CORPORATE_CODE));
			input.put(MapKeys.GM_SERVICE_NAME, TransactionConstants.DoInvoiceCollection.SERVICE_NAME);
			input.put(MapKeys.IS_MANDATORY_SERVICE, true);
			input.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
		}
		
		String merchantCode = CommonBusinessOperations.getMerchantCode(corporateCode);
		bag.put(BagKeys.MERCHANT_CODE, merchantCode);
		input.put("CRD_MERCHANT_CODE", merchantCode);
		String creditCardNo = input.getString(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_CARD_NO, null);
		bag.put(BagKeys.CARD_NO, creditCardNo);
		
		if(sourceCode.equals(DatabaseConstants.SourceCodes.CreditCard)){
			String cardType ="";
			BigDecimal accountNo = BigDecimal.ZERO;
			String accountType ="";
			GMMap cardMap = new GMMap();
			cardMap.put("CARD_NO", creditCardNo);
			cardMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARD_DETAILS", cardMap);
			if (!cardMap.getString("RETURN_CODE").equals("2")) {
				String returnCode = cardMap.getString("RETURN_CODE");
				String returnDesc = "Kart Bulunamad�";
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, returnCode.concat("-").concat(returnDesc));
			}
			if (cardMap.getSize("CARD_DETAIL_INFO") > 0) {
				if(isOpenStatusOrRenewalCardWithCourierStatus(cardMap)){
					cardType =  cardMap.getString("CARD_DETAIL_INFO",0,"CARD_DCI");
					accountNo =  cardMap.getBigDecimal("CARD_DETAIL_INFO",0,"DEBIT_ACCOUNT_NO");
					
				}else{
					String returnCode = cardMap.getString("RETURN_CODE");
					String returnDesc = "Kart Bulunamad�";
					CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, returnCode.concat("-").concat(returnDesc));
				}
				
			}else{
				String returnCode = cardMap.getString("RETURN_CODE");
				String returnDesc = "Kart Bulunamad�";
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, returnCode.concat("-").concat(returnDesc));
			}
			
			if("D".equals(cardType)){
				//HEsaptan �deme gibi �al��acak
				sourceCode=DatabaseConstants.SourceCodes.Account;
				input.put(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_ACCOUNT_NO, accountNo);
			}else{
				if("C".equals(cardType)){
					accountType="CREDIT_CARD_DK_NO";
				}else if("P".equals(cardType)){
					accountType="PREPAID_CARD_DK_NO";
				}
				input.put(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_ACCOUNT_NO, CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", accountType));
			}
		}
		
		insertInvoicePaymentLog(input);
		
		if(sourceCode.equals(DatabaseConstants.SourceCodes.CreditCard)){
			bag.put(BagKeys.COLLECTION_STEP, StepNames.CARD_COLLECTION);
			GMMap cardCollectionResponse = CommonBusinessOperations.doCreditCardCollection(creditCardNo, "7010", transactionNo, 
					merchantCode, paymentAmount, "TRY", commissionAmount.add(bsmvAmount));
			if(cardCollectionResponse.getString("RETURN_CODE").equals(CARD_COLLECTION_SUCCESSFUL)){
				// No problem
			}
			else{
				String returnCode = cardCollectionResponse.getString("RETURN_CODE");
				String returnDesc = cardCollectionResponse.getString("RETURN_DESCRIPTION");
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, returnCode.concat("-").concat(returnDesc));
			}
		}
		
		bag.put(BagKeys.COLLECTION_STEP, StepNames.ACCOUNTING);
		
		if(sourceCode.equals(DatabaseConstants.SourceCodes.Account) && 
				CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "DEBIT_EMV_SWITCH").equals("1")){
			super.callServiceWithSessionOption("DEBIT_EMV_TRANSACTION", true, 
					"ACCOUNT_NO", input.getBigDecimal(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_ACCOUNT_NO),
					"AMOUNT", paymentAmount,
					"TRX_NO", transactionNo);
		}
		
		GMMap transactionMap = super.callGraymoundServiceOutsideSession("BNSPR_TRX_SEND_TRANSACTION", input);
		
		output.put("MESSAGE", transactionMap.getString("MESSAGE"));
		
		if(transactionMap.getString("TX_STATUS").equals("0")){
			output.put("WAITING_APPROVAL", false);
			if (corporateDefinitionOutput.getString(MapKeys.IS_ONLINE_CORPORATE).equals("1")) {
				try {
					bag.put(BagKeys.COLLECTION_STEP, StepNames.CORPORATE_CALL);
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", input);
				} catch (Exception e) {
					GMMap cancelPaymentRequest = new GMMap();
					cancelPaymentRequest.put("TRX_NO", transactionNo);
					cancelPaymentRequest.put("CALL_CORPORATE", false);
					cancelPaymentRequest.put("DO_NOT_CHECK_CODE", true);
					cancelPaymentRequest.put("BYPASS_APPROVE", true);
					cancelPaymentRequest.put("IGNORE_PAYMENT", true);
					
					try{
						CommonHelper.callGraymoundServiceOutsideSession("ICS_CANCEL_PAYMENTS_BY_TRX_NO_FRONTEND", cancelPaymentRequest);
					}catch (Exception innerEx) {/*IF ERROR OCCURED WHILE REVERSE ACCOUNTING MAIL NOTIFICATION SHOULD BE SENT*/
						super.callGraymoundServiceAsync("ICS_SEND_REVERSE_ACCOUNTING_FAIL_MAIL", input);
						CommonHelper.callGraymoundServiceOutsideSession("ICS_SAVE_REVERSE_ACCOUNTING_FAIL_ON_SAF", cancelPaymentRequest);
					}
					
					throw e;
				}
				
				invoicePayment paymentRecord = (invoicePayment) session.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("txNo", transactionNo))
						.uniqueResult();
				
				paymentRecord.setPaymentStatus(DatabaseConstants.PaymentStatuses.Collected);
				
				session.saveOrUpdate(paymentRecord);
				
				if(input.getBoolean(MapKeys.IS_STANDING_ORDER_COLLECTION) && 
						input.getBigDecimal(TransactionConstants.DoInvoiceCollection.Input.INVOICE_AMOUNT).compareTo(
						input.getBigDecimal(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_AMOUNT)) != 0){
					String invoiceMainOid = input.getString(TransactionConstants.DoInvoiceCollection.Input.INVOICE_MAIN_OID);
					invoiceMain mainRecord = (invoiceMain)session.createCriteria(invoiceMain.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("oid", invoiceMainOid))
							.uniqueResult();
					
					if(mainRecord != null){
						mainRecord.setPaymentStatus(DatabaseConstants.PaymentStatuses.PartialCollected);
						session.saveOrUpdate(mainRecord);
					}
				}
				session.flush();
			}
			else{
				String invoiceMainOid = input.getString(TransactionConstants.DoInvoiceCollection.Input.INVOICE_MAIN_OID);
				
				invoicePayment paymentRecord = (invoicePayment) session.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("txNo", transactionNo))
						.uniqueResult();
				
				if(paymentRecord.getPaymentAmount().compareTo(paymentRecord.getInvoiceAmount()) != 0){
					invoiceMain mainRecord = (invoiceMain)session.createCriteria(invoiceMain.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("oid", invoiceMainOid))
							.uniqueResult();
					if(mainRecord != null){
						mainRecord.setPaymentStatus(DatabaseConstants.PaymentStatuses.PartialCollected);
						session.saveOrUpdate(mainRecord);
					}
				}
				
				paymentRecord.setPaymentStatus(DatabaseConstants.PaymentStatuses.Collected);
				
				session.saveOrUpdate(paymentRecord);
				session.flush();
			}
		}
		else{
			output.put("WAITING_APPROVAL", true);
			invoicePaymentLog logRecord = (invoicePaymentLog) super.getHibernateSession().createCriteria(invoicePaymentLog.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txNo", transactionNo))
					.uniqueResult();
			
			logRecord.setPaymentInput(new ClobImpl(CommonHelper.serializeRequest(input)));
			logRecord.setCallCorporate(true);
			
			super.getHibernateSession().saveOrUpdate(logRecord);
			super.getHibernateSession().flush();
		}
	}

	private void checkIfPaymentExistsWithQueryRefNo(BigDecimal queryRefNo) throws Exception {
		int count = ((Number)super.getHibernateSession().createCriteria(invoicePayment.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.or(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected), Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.PartialCollected)))
				.add(Restrictions.eq("queryRefNo", queryRefNo))
				.setProjection(Projections.rowCount())
				.uniqueResult()).intValue();
		
		if(count > 0){
			CommonHelper.throwBusinessException(BusinessException.RECORDHASPAIDBEFORE.getCode(), String.valueOf(queryRefNo.longValue()));
		}
	}

	private void insertInvoicePaymentLog(GMMap input) {
		super.callGraymoundServiceOutsideSession("ICS_INSERT_INVOICE_PAYMENT_LOG", input);
	}
	
	@Override
	protected void handleError(Throwable e, GMMap output) {
		String currentStep = (String) bag.get(BagKeys.COLLECTION_STEP);
		if(((String)bag.get(BagKeys.SOURCE_CODE)).equals(DatabaseConstants.SourceCodes.CreditCard) && 
				(currentStep.equals(StepNames.ACCOUNTING) || currentStep.equals(StepNames.CORPORATE_CALL))){
			BigDecimal newTxNo = new BigDecimal(CommonHelper.getNewTransactionNo());
			try {
				CommonBusinessOperations.cancelCreditCardCollection((String) bag.get(BagKeys.CARD_NO), "7010", newTxNo, (String)bag.get(BagKeys.MERCHANT_CODE), 
						(BigDecimal)bag.get(BagKeys.AMOUNT), "TRY", (BigDecimal)bag.get(BagKeys.COMM_AMOUNT), (BigDecimal)bag.get(BagKeys.TRANSACTION_NO));
			} catch (Exception inException) {
				logger.error("An exception occured while reversal credit card transaction");
				logger.error(System.currentTimeMillis(), inException);
				logger.error("Master exception is following :");
				logger.error(System.currentTimeMillis(), e);
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, "�deme i�leminde al�nan hata sonucu kart i�leminin " +
						"reversal'� yap�lamad�. �deme i�lemi hatas� : ".concat(e.getMessage()).concat(". Reversal i�lem hatas� : ").concat(inException.getMessage())
						.concat(". Reversal yap�lmaya �al��an i�lem numaras� : ").concat(((BigDecimal)bag.get(BagKeys.TRANSACTION_NO)).toString()));
			}
		}
		super.handleError(e, output);
	}
	
	private boolean isEPOSChannelforTransfer(String  corporateCode,String channelCode,String yimChannelCode) throws Exception {
		boolean isEposChannelForTransferCorporate=false;
		if(GeneralConstants.YIM_CHANNEL_CODE.equals(channelCode)){
//			String eposChannelAgentCode = CommonBusinessOperations.getCorporateParameterValue(corporateCode, "EPOS_CHANNEL_AGENT_CODE");
			if (!StringUtil.isEmpty(yimChannelCode)&& yimChannelCode.equals(YIM_CHANNEL_EPOS)) {
				String eposChannelForTransferCorporate = CommonBusinessOperations.getCorporateParameterValue(corporateCode, "EPOS_CHANNEL_FOR_TRANSFER_CORPORATE");
				isEposChannelForTransferCorporate = StringUtil.isEmpty(eposChannelForTransferCorporate) ? false : eposChannelForTransferCorporate.equals("1");
			}
		}
		
		return isEposChannelForTransferCorporate;
		
		
	}
	private static boolean isOpenStatusOrRenewalCardWithCourierStatus(GMMap cardList) {
		return cardList.getString("CARD_DETAIL_INFO", 0, "CARD_STAT_CODE").equals(OceanConstants.Card_Bank_Status_Open) || 
				(cardList.getString("CARD_DETAIL_INFO", 0, "CARD_STAT_CODE").equals(OceanConstants.Card_Bank_Status_Followup)
				&& cardList.getString("CARD_DETAIL_INFO", 0, "CARD_SUB_STAT_CODE").equals(OceanConstants.Card_Bank_Status_Followup)) ||
				(cardList.getString("CARD_DETAIL_INFO", 0, "CARD_STAT_CODE").equals(OceanConstants.Card_Bank_Status_Courier) 
				&& (cardList.getString("CARD_DETAIL_INFO", 0, "CARD_SUB_STAT_CODE").equals(OceanConstants.Card_Bank_Status_Courier_Deliver) || 
			   cardList.getString("CARD_DETAIL_INFO", 0, "CARD_SUB_STAT_CODE").equals(OceanConstants.Card_Bank_Status_Courier_Emboss))) 
			   && StringUtils.isNotBlank(cardList.getString("CARD_DETAIL_INFO", 0, "OLD_CARD_NO"));
		// Normal veya (G olan kart�n alt durumu (J ve B olmal�) ve oldCardNo de�eri dolu olmal�)
		// oldCardNo nun dolu olmas� bize kart�n yenilendi�ini g�sterir
	}
	

}
