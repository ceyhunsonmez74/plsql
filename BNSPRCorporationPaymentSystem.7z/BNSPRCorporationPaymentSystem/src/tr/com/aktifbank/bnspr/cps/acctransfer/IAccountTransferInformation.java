package tr.com.aktifbank.bnspr.cps.acctransfer;

import java.math.BigDecimal;

public interface IAccountTransferInformation {
	int getCount();
	BigDecimal getTotalAmount();
	void updateRecords();
}
