package tr.com.aktifbank.bnspr.cps.common;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.axis.utils.StringUtils;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMToolkit;

public class CommonHelper {

	private static final Log logger = LogFactory.getLog(CommonHelper.class);

//	static DateFormat longDateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
//	static DateFormat shortDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
//	static DateFormat hugeDateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmssSSSS");
//	static DateFormat viewtDateFormat = new SimpleDateFormat("dd/MM/yyyy");
//	static DateFormat viewtTimeFormat = new SimpleDateFormat("HH:mm:ss");
	
	static long milisecondCountInADay = 86400000;
	
	static String DECIMAL_FORMAT_PATTERN = "###,###.##";

	public static Enums.ResultSetSpecification getSpecification(ResultSet resultSet) throws SQLException {
		if (resultSet.getType() != ResultSet.TYPE_FORWARD_ONLY) {
			if (resultSet.next()) {
				if (!resultSet.next()) {
					resultSet.previous();
					return Enums.ResultSetSpecification.UniqueRecord;
				} else {
					resultSet.previous();
					resultSet.previous();
					return Enums.ResultSetSpecification.MoreThanOneRecord;
				}
			} else {
				return Enums.ResultSetSpecification.NoRecord;
			}
		} else {
			return Enums.ResultSetSpecification.NotScrollable;
		}
	}

	public static String getLongDateTimeString(Date date) {
		DateFormat longDateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		return longDateTimeFormat.format(date);
	}

	public static String getShortDateTimeString(Date date) {
		DateFormat shortDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
		return shortDateTimeFormat.format(date);
	}
	
	public static String getHugeDateTimeString(Date date) {
		DateFormat hugeDateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmssSSSS");
		return hugeDateTimeFormat.format(date);
	}
	
	/**
	 * Gets the date in the longTimeString
	 * e.g. 20130817033903 -> 17/08/2013
	 * 
	 * @param longTimeString as 20130817033903
	 * @return Date as 17/08/2013
	 * @ParseException returns "" when gets ParseException
	 */
	public static String longTimeStringToViewDateString(String longTimeString){
		Date date;
		try {
			DateFormat longDateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			date = longDateTimeFormat.parse(longTimeString);
			DateFormat viewtDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			return viewtDateFormat.format(date);
		} catch (ParseException e) {
			return "";
		}
	}

	/**
	 * Gets the time in the longTimeString
	 * e.g. 20130817033903 -> 03:39:03
	 * 
	 * @param longTimeString as 20130817033903
	 * @return Time as 03:39:03
	 * @ParseException returns "" when gets ParseException
	 */
	public static String longTimeStringToViewTimeString(String longTimeString){
		Date date;
		try {
			DateFormat longDateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			date = longDateTimeFormat.parse(longTimeString);
			DateFormat viewtTimeFormat = new SimpleDateFormat("HH:mm:ss");
			return viewtTimeFormat.format(date);
		} catch (ParseException e) {
			return "";
		}
	}
	
	/**
	 * Converts to formatted view Date
	 * e.g. 20100415 -> 15/04/2010
	 * @ParseException returns "" when gets ParseException
	 */
	public static String shortTimeStringToViewDateString(String shortTimeString){
		Date date;
		try {
			DateFormat shortDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
			date = shortDateTimeFormat.parse(shortTimeString);
			DateFormat viewtDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			return viewtDateFormat.format(date);
		} catch (ParseException e) {
			return "";
		}
	}

	public static Date getDateTime(String dateTime, String format) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.parse(dateTime);
	}

	public static Date getCurrentDateWithTime(String time, String format) throws ParseException {
		SimpleDateFormat timeFormat = new SimpleDateFormat(format);
		Date timeParsedDate = timeFormat.parse(time);
		Date currentDate = new Date();
		Calendar currentCal = Calendar.getInstance();
		currentCal.setTime(currentDate);
		Calendar timeParsedCal = Calendar.getInstance();
		timeParsedCal.setTime(timeParsedDate);
		currentCal.set(Calendar.HOUR_OF_DAY, timeParsedCal.get(Calendar.HOUR_OF_DAY));
		currentCal.set(Calendar.MINUTE, timeParsedCal.get(Calendar.MINUTE));
		currentCal.set(Calendar.SECOND, timeParsedCal.get(Calendar.SECOND));
		return currentCal.getTime();
	}

	public static String getStringTimeNow() {
		SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
		String strTime = sdf.format(new Date());
		return strTime;
	}

	public static String getValueOrThrow(GMMap input, String key) throws Exception {
		if (input.containsKey(key)) {
			Object value = input.get(key);
			if (value instanceof String) {
				return (String) value;
			} else {
				throw new Exception(String.format(
						"getValueOrThrow method in RequestHandler throws exception for %s key. Type of value is %s instead of String", key, value
								.getClass().getName()));
			}
		} else {
			throw new Exception(String.format("getValueOrThrow method in RequestHandler throws exception for %s key. Key is not found", key));
		}
	}

	public static String getCurrentUser() {
		return (String) GMContext.getCurrentContext().getSession().get("USER_NAME");
	}

	public static String getChannelId() {
		return (String) GMContext.getCurrentContext().getSession().get("CHANNEL_CODE");
	}

	public static Connection getConnection() throws SQLException {
		return DALUtil.getGMConnection();
	}

	public static String trimEnd(String string, char character) {
		String returnString = string;
		while (returnString.endsWith(String.valueOf(character))) {
			returnString = returnString.substring(0, returnString.length() - 1);
		}
		return returnString;
	}

	public static String trimStart(String string, char character) {
		String returnString = string;
		while (returnString.startsWith(String.valueOf(character))) {
			returnString = returnString.substring(1, returnString.length());
		}
		return returnString;
	}

	public static Boolean isTodayWorkingDay() {
		return isWorkingDay(new Date());
	}

	public static Boolean isWorkingDay(Date dateTime) {
		GMMap map = new GMMap();
		map.put("TARIH", dateTime);
		GMMap out = GMServiceExecuter.call("INTERNET_TATIL_MI", map);
		return !out.getBoolean("RESULT");
	}

	public static Date getNextWorkingDay(Date dateTime) {
		GMMap map = new GMMap();
		map.put("TARIH", dateTime);
		Date nextWorkingDay = new Date();
		try {
			nextWorkingDay = GMServiceExecuter.call("INTERNET_ILERI_IS_GUNU", map).getDate("RESULT");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nextWorkingDay;
	}

	public static Date getPreviousWorkingDay(Date dateTime) {
		GMMap map = new GMMap();
		map.put("TARIH", dateTime);
		Date previousWorkingDay = new Date();
		try {
			previousWorkingDay = new java.sql.Date((GMServiceExecuter.call("INTERNET_TATILSE_GERI_IS_GUNU", map).getDate("TARIH")).getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return previousWorkingDay;
	}

	public static Boolean isBetweenDates(Date mainDate, Date startDate, Date endDate) {
		return mainDate.compareTo(startDate) > 0 && mainDate.compareTo(endDate) < 0;
	}

	public static BigDecimal getBsmvAmount(BigDecimal amount) {
		return amount.multiply(new BigDecimal(5).divide(new BigDecimal(100))).setScale(2, RoundingMode.HALF_DOWN);
	}

	public static Date add(Date date, int dayCount, int monthCount, int yearCount) {
		return addDay(addMonth(addYear(date, yearCount), monthCount), dayCount);
	}

	public static int getDay(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.DATE);
	}

	public static int getMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.MONTH) + 1;
	}

	public static int getYear(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.YEAR);
	}

	public static Date addDay(Date date, int dayCount) {
		Calendar defaultCalendar = Calendar.getInstance();
		defaultCalendar.setTime(date);
		defaultCalendar.add(Calendar.DATE, dayCount);
		return defaultCalendar.getTime();
	}

	public static Date addMonth(Date date, int monthCount) {
		Calendar defaultCalendar = Calendar.getInstance();
		defaultCalendar.setTime(date);
		defaultCalendar.add(Calendar.MONTH, monthCount);
		return defaultCalendar.getTime();
	}

	public static Date addYear(Date date, int yearCount) {
		Calendar defaultCalendar = Calendar.getInstance();
		defaultCalendar.setTime(date);
		defaultCalendar.add(Calendar.YEAR, yearCount);
		return defaultCalendar.getTime();
	}

	public static Session getHibernateSession() {
		return DAOSession.getSession(GeneralConstants.DataAccessSessionName);
	}

	public static GMMap callGraymoundServiceInHibernateSession(String serviceName, GMMap input) {
		input.put(TransactionConstants.KeepSession, true);
		return GMServiceExecuter.call(serviceName, input);
	}

	public static void throwBusinessException(long code, Object... params) {
		GMMap errorMap = new GMMap();
		errorMap.put("HATA_NO", code);
		if (params != null && params.length != 0) {
			for (int i = 0; i < params.length; i++) {
				errorMap.put(String.format("P%s", i + 1), params[i]);
			}
		}
		callGraymoundServiceInHibernateSession("BNSPR_COMMON_HATA_YAZ", errorMap);
	}

	public static void throwBusinessException(BatchComponentException ex) {
		if (ex.getParameters() != null) {
			throwBusinessException(ex.getCode(), ex.getParameters().toArray());
		} else {
			throwBusinessException(ex.getCode());
		}
	}

	public static void closeAll(Object... closableObjects) {
		if (closableObjects != null && closableObjects.length != 0) {
			for (Object obj : closableObjects) {
				if (obj != null) {
					try {
						Method closeMethod = obj.getClass().getMethod("close");
						closeMethod.invoke(obj);
					} catch (Exception e) {
						logger.error(e);
					}
				}
			}
		}
	}

	public static String getConfigurationFolderedString(String fileName) {
		String folderedName = String.format("%s%s", System.getProperty("jboss.server.config.url"), fileName);
		if (folderedName.startsWith("file:")) {
			return folderedName.substring(6);
		} else {
			return folderedName;
		}
	}

	public static String composeParameters(Map<String, String> parameters) {
		StringBuilder builder = new StringBuilder();
		for (Map.Entry<String, String> item : parameters.entrySet()) {
			builder.append(String.format("%s~%s|", item.getKey(), item.getValue()));
		}
		return StringUtils.stripEnd(builder.toString(), "|");
	}

	public static Map<String, String> decomposeParameters(String composedString) {
		String[] splittedKeyValuePairs = composedString.split("\\|");
		Map<String, String> pairs = new HashMap<String, String>();
		for (String item : splittedKeyValuePairs) {
			String[] keyAndValue = item.split("~");
			pairs.put(keyAndValue[0], keyAndValue[1]);
		}
		return pairs;
	}

	public static GMMap convertMapToGMMap(Map<?, ?> map) {
		GMMap output = new GMMap();
		for (Object key : map.keySet()) {
			output.put(key, map.get(key));
		}

		return output;
	}

	public static GMMap callGraymoundServiceOutsideSession(String serviceName, GMMap input) {
		Map<?, ?> result = GMServiceExecuter.executeNT(serviceName, input);

		return convertMapToGMMap(result);
	}

	public static GMMap callParallel(List<GMMap> inputMaps) {
		GMMap maps = new GMMap();
		maps.put(TransactionConstants.ParallelCall.Input.T_TASKS, inputMaps);
		return GMServiceExecuter.callParallel(maps);
	}

	public static long subtractDatesToDays(Date first, Date second) {
		GregorianCalendar c1 = new GregorianCalendar();
		GregorianCalendar c2 = new GregorianCalendar();
		c1.setTime(second);
		c2.setTime(first);
		long span = c2.getTimeInMillis() - c1.getTimeInMillis();
		GregorianCalendar c3 = new GregorianCalendar();
		c3.setTimeInMillis(span);
		return c3.getTimeInMillis() / milisecondCountInADay;
	}

	public static String getValueOfParameter(String code, String criteria) {
		GMMap map = new GMMap();
		map.put("CODE", code);
		map.put("KEY1", criteria);
		GMMap output = callGraymoundServiceOutsideSession("CPS_GET_VALUE_OF_GENERAL_PARAMETER", map);

		String result = output.getString("RESULT");

		return result;
	}

	public static String getNameOfParameter(String code, String criteria) {
		GMMap map = new GMMap();
		map.put("KOD", code);
		GMMap output = callGraymoundServiceInHibernateSession("BNSPR_COMMON_GET_COMBO_PARAMETERS", map);

		String result = null;

		for (int i = 0; i < output.getSize("RESULTS"); i++) {
			if (output.getString("RESULTS", i, "NAME").equals(criteria)) {
				result = output.getString("RESULTS", i, "VALUE");
				break;
			}
		}

		return result;
	}
	
	public static GMMap getAllParametersByCode(String code, GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("KOD", code);
        iMap.put("ADD_EMPTY_KEY", "E");
        oMap.put("ERROR_CODE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
        
        return oMap;
	}

	@SuppressWarnings("rawtypes")
	public static int getCountOfRows(Session hibernateSession, Class pojoClass, Object... restrictions) {
		Criteria criteria = hibernateSession.createCriteria(pojoClass);
		if (restrictions != null && restrictions.length != 0) {
			for (int i = 0; i < restrictions.length; i += 2) {
				criteria = criteria.add(Restrictions.eq((String) restrictions[i], restrictions[i + 1]));
			}
		}
		return ((Number) criteria.setProjection(Projections.rowCount()).uniqueResult()).intValue();
	}

	public static String getDateString(Date date, String format) {
		DateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(date);
	}

	public static GMMap callGraymoundServiceWithExternalConnection(String connectionName, String serviceName, GMMap input) throws IOException {
		GMConnection connection = GMConnection.getConnection(connectionName);
		return convertMapToGMMap(connection.serviceCall(serviceName, input));
	}

	public static String getExceptionTrace(Exception exp) {
		StringBuilder error = new StringBuilder();
		error.append(exp.toString());
		if (exp.getStackTrace() != null && exp.getStackTrace().length > 0) {
			StringWriter expDetail = new StringWriter();
			exp.printStackTrace(new PrintWriter(expDetail));
			error.append(expDetail.toString());
		}
		return error.toString();
	}

	public static String serializeRequest(GMMap request) throws IOException {
		return new String(Base64.encodeBase64(GMToolkit.serialize(request)));
	}

	public static GMMap deserializeRequest(String serializedRequest) throws IOException {
		return (GMMap) GMToolkit.deserialize(Base64.decodeBase64(serializedRequest.getBytes()));
	}

	public static int getDayOfWeek(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.DAY_OF_WEEK);
	}

	public static int getDayOfMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.DAY_OF_MONTH);
	}

	public static String getNewTransactionNo() {
		return callGraymoundServiceInHibernateSession("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString(MapKeys.TRX_NO);
	}

	public static String convertToDate(String strDate, String pattern, String newPattern, String splitChar) {
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		SimpleDateFormat sdf = new SimpleDateFormat(newPattern);
		String splitedDate = "";
		String normalDate = "";
		Date date = null;
		try {
			date = format.parse(strDate);
			if (splitChar == null) {
				normalDate = sdf.format(date).toString();
				try {
					splitChar = "/";
					splitedDate = normalDate.substring(9, 11).concat(splitChar).concat(normalDate.substring(11, 13)).concat(splitChar)
							.concat(normalDate.substring(13, 17)).concat(" ").concat(normalDate.substring(0, 8));
				} catch (Exception e) {
					return normalDate;
				}
				return splitedDate;
			} else {
				normalDate = sdf.format(date).toString();
				splitedDate = normalDate.substring(0, 2).concat(splitChar).concat(normalDate.substring(2, 4)).concat(splitChar)
						.concat(normalDate.substring(4, 8));
				return splitedDate;
			}
		} catch (Exception e) {
			return strDate;
		}
	}
	
	public static boolean isValidEmailAddress(String email) {
		Pattern pattern;
		Matcher matcher;
		final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		pattern = Pattern.compile(EMAIL_PATTERN);
		matcher = pattern.matcher(email);
		return matcher.matches();
	}
	
	public static String getStringifiedException(Throwable e){
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}
	
	public static GMMap queryData(String query, String tableName, Object... queryParameters) throws Exception{
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try{
			connection = getConnection();
			statement = connection.prepareStatement(query);
			prepareExecute(statement, queryParameters);
			resultSet = statement.executeQuery();
			return DALUtil.rSetResults(resultSet, tableName);
		}
		finally{
			closeAll(resultSet, statement, connection);
		}
	}
	
	private static void setParameter(int toIndex, BnsprType dataType, Object value, PreparedStatement statement) throws Exception{
		if(dataType == BnsprType.NUMBER){
			statement.setBigDecimal(toIndex, (BigDecimal)value);
		} else if(dataType == BnsprType.STRING){
			statement.setString(toIndex, (String)value);
		} else if(dataType == BnsprType.DATE){
			if(value != null){
				statement.setDate(toIndex, new java.sql.Date(((Date)value).getTime()));
			}else{
				statement.setDate(toIndex, null);
			}
		}
		else{
			throw new Exception(String.format("%s BnsprType is not implemented", dataType.toString()));
		}
	}
	
	public static void executeQuery(String query, Object... queryParameters) throws Exception {
		Connection connection = null;
		PreparedStatement statement = null;
		try{
			connection = getConnection();
			statement = connection.prepareStatement(query);
			prepareExecute(statement, queryParameters);
			statement.execute();
		}
		finally{
			closeAll(statement, connection);
		}
	}
	
	private static void prepareExecute(PreparedStatement statement, Object[] queryParameters) throws Exception{
		if(queryParameters != null && queryParameters.length != 0){
			if(queryParameters.length % 2 != 0){
				throw new Exception("Parameters should be passed in BnsprType, value pairs.");
			}
			int counter = 1;
			for (int i = 0; i < queryParameters.length; i+=2) {
				setParameter(counter++, (BnsprType)queryParameters[i], queryParameters[i + 1], statement);
			}
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static List queryDataWithHibernate(Session session, String query, Object... parameters) throws Exception {
		if(session == null){
			session = getHibernateSession();
		}
		Query hibQuery = session.createSQLQuery(query);
		prepareHibernateExecute(hibQuery, parameters);
		return hibQuery.list();
	}
	
	public static void executeWithHibernate(Session session, String query, Object... parameters) throws Exception {
		if(session == null){
			session = getHibernateSession();
		}
		Query hibQuery = session.createSQLQuery(query);
		prepareHibernateExecute(hibQuery, parameters);
		hibQuery.executeUpdate();
	}
	
	private static void prepareHibernateExecute(Query hibernateQuery, Object... parameters) throws Exception {
		if(parameters != null && parameters.length != 0){
			if(parameters.length % 2 != 0){
				throw new Exception("Parameters should be passed in in query name, value pairs.");
			}
			for (int i = 0; i < parameters.length; i+=2) {
				hibernateQuery.setParameter((String)parameters[i], parameters[i+1]);
			}
		}
	}

	@SuppressWarnings("unchecked")
	public static Object queryUniqueResultWithHibernate(Session session, String query, Object... parameters) throws Exception {
		List<Object> results = queryDataWithHibernate(session, query, parameters);
		if(results.size() > 0){
			return results.get(0);
		}
		else{
			return null;
		}
	}
	
	public static int getDayOfWeekInTurkishLocale(Date date) {
		int rootDayOfWeek = getDayOfWeek(date);
		int turkishDayOfWeek = rootDayOfWeek - 1;
		if(turkishDayOfWeek == 0){
			turkishDayOfWeek = 7;
		}
		return turkishDayOfWeek;
	}
	
	public static void sendMail(List<String> recipientList, List<String> ccList, String from, boolean isHtmlBody, String subject, String body, boolean handleException) 
			throws Exception{
		try{
			sendMail(recipientList, ccList, from, isHtmlBody, subject, body);
		}
		catch(Exception e){
			logger.error("An exception occured while sending email");
			logger.error(System.currentTimeMillis(), e);
			if(!handleException){
				throw e;
			}
		}
	}
	
	public static void sendMail(List<String> recipientList, List<String> ccList, String from, boolean isHtmlBody, String subject, String body){
		GMMap mailRequest = new GMMap();
		List<String> recipients = null;
		if(recipientList != null){
			recipients = recipientList;
		}
		else{
			recipients = new ArrayList<String>();
		}
		
		mailRequest.put("RECIPIENTS_TO", recipients);
		if (ccList != null) {
			mailRequest.put("RECIPIENTS_CC", ccList);
		}
		mailRequest.put("IS_BODY_HTML", isHtmlBody);
		mailRequest.put("RECIPIENTS_TO", recipients);
		mailRequest.put("RECIPIENTS_TO", recipients);
		mailRequest.put("FROM", from);
		mailRequest.put("SUBJECT", subject);
		mailRequest.put("MESSAGE_BODY", body);
		
		callGraymoundServiceInHibernateSession("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailRequest);
		
	}
	
	public static String replaceCharacters(String inputString, String... replaceArray){
		String outString = inputString;
        for (int i = 0; i < replaceArray.length; i+=2) {
               outString = outString.replace(replaceArray[i], replaceArray[i + 1]);
        }
        return outString;
	}
	
	public static String fillCharacters(String input, String fillChar, int wholeSize, boolean fillLeft){
		String output = input;
		
		while(output.length() < wholeSize){
			if(fillLeft){
				output = fillChar.concat(output);
			}
			else{
				output = output.concat(fillChar);
			}
		}
		
		return output;
	}
	
	public static int getUserBranch () throws Exception {
		return GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_SUBE_KOD", new GMMap()).getInt("SUBE_KODU");
	}
	
	public static String formatDateString(String dateString, String oldFormat, String newFormat) throws Exception {
		return getDateString(getDateTime(dateString, oldFormat), newFormat);
	}
	
	public static List<String> fillReceiptList(String notifiers){
		List<String> receiptList = new ArrayList<String>();
		String[] receipts = notifiers.split(",");
		for( String receipt : receipts ){
			receiptList.add(receipt);
		}
		
		return receiptList;
	}
	
	public static String getMessageBody(GMMap input, String messageContent){
		
		String body = messageContent;
		String appendedMessageBody = "";
		int substringLength = getSubstringLength();
		
		boolean isContentHasList = false;
		if( body.contains("<ul>") && body.contains("</ul>") ){
			isContentHasList = true;
			appendedMessageBody = regenerateMessageBody(body, "<ul>", input.get("MAP_LIST"));
		}
		
		boolean isContentHasTable = false;
		if( body.contains("<table border=2>") && body.contains("</table>") ){
			isContentHasTable = true;
			appendedMessageBody = regenerateMessageBody(body, "<table border=2>", input.get("MAP_TABLE"));
		}
		
		Set<Entry<Object, Object>> entrySet = input.entrySet();
		Iterator<Entry<Object, Object>> iterator = entrySet.iterator();
		while( iterator.hasNext() ){
			Entry<Object, Object> nextElement = iterator.next();
			if( input.containsKey(nextElement.getKey()) ){
				if( null != nextElement.getValue() ){
					if(  nextElement.getValue().toString().length() > substringLength ){
						body = body.replaceAll(nextElement.getKey().toString(), Matcher.quoteReplacement(nextElement.getValue().toString().substring(0, substringLength)));
					}
					else{
						body = body.replaceAll(nextElement.getKey().toString(), Matcher.quoteReplacement(nextElement.getValue().toString()));
					}
				}
			}
		}
		
		StringBuilder builder = new StringBuilder(body);
		if( isContentHasList ){
			builder.setLength(0);
			builder.append(body.substring(0,body.indexOf("<ul>")));
			builder.append(appendedMessageBody);
		}
		
		if( isContentHasTable ){
			builder.setLength(0);
			builder.append(body.substring(0,body.indexOf("<table border=2>")));
			builder.append(appendedMessageBody);
			builder.append("</table>");
		}
		
		return builder.toString();
	}

	private static String regenerateMessageBody(String body, String pattern, Object columns){
		int startIndex  = body.indexOf(pattern);
		String restBody = body.substring(startIndex);
		
		return getMessageBody(columns,restBody);
		
	}
	
	private static int getSubstringLength(){
		String lengthValue = CommonHelper.getValueOfParameter("CDM_MESSAGE_PROPERTIES","EMAIL_SUBSTRING_LENGTH");
		int substringLength;
		try{
			substringLength = Integer.parseInt(lengthValue);
		}
		catch(Exception ex){
			substringLength = 400;
		}
		
		return substringLength;
	}
	
	@SuppressWarnings("unchecked")
	private static String getMessageBody(Object columns, String restBody) {
		List<Map<String,String>> columnMap = (List<Map<String, String>>) columns;
		int substringLength = getSubstringLength();
		Iterator<Map<String, String>> columnIterator = columnMap.iterator();
		StringBuilder builder = new StringBuilder();
		if( restBody.contains("<td>") && restBody.contains("</td>") ){
			int startIndex = restBody.lastIndexOf("<tr>");
			int lastIndex = restBody.lastIndexOf("</table>");
			
			builder.append(restBody.substring(0,startIndex));
			restBody = restBody.substring(startIndex, lastIndex);
		}
		while( columnIterator.hasNext() ){
			Set<Entry<String,String>> entrySet = columnIterator.next().entrySet();
			Iterator<Entry<String, String>> iterator = entrySet.iterator();
			String tempBodyMessage = restBody;
			while( iterator.hasNext() ){
				Entry<String, String> nextElement = iterator.next();
				if( !StringUtil.isEmpty(nextElement.getValue()) && nextElement.getValue().toString().length() > substringLength){
					tempBodyMessage = tempBodyMessage.replaceAll(nextElement.getKey().toString(), Matcher.quoteReplacement(nextElement.getValue().toString().substring(0, substringLength)));
				}
				else{
					if(StringUtil.isEmpty(nextElement.getValue())){
						tempBodyMessage = tempBodyMessage.replaceAll(nextElement.getKey().toString(), "");
					}
					else{
						tempBodyMessage = tempBodyMessage.replaceAll(nextElement.getKey().toString(), Matcher.quoteReplacement(nextElement.getValue().toString()));
					}
				}
			}
			builder.append(tempBodyMessage);
		}
		
		return builder.toString();
	}

	public static EmailMessage prepareEmailBody(String corporateName, GMMap messageMap, String messageContent, String subject, String notifiers ){
		return new EmailMessage.MessageBuilder(corporateName + subject).from(NotificationMessageConstant.Email.FROM)
				.receiptList(CommonHelper.fillReceiptList(notifiers))
				.body(getMessageBody(messageMap, messageContent))
				.getEmail();
	}
	
	public static void sendSMS(GMMap smsServisMap){
		 GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsServisMap);
	}
	
	/**
	 * Override all subscriber no's which supplied by the channels.
	 * Such as 2940 - > 00002940 with masking 
	 * @param iMap
	 * @param controlSubscriberMetaDataMap
	 */
	public static void makeSubscriberNoMask(GMMap iMap, GMMap controlSubscriberMetaDataMap){
		
		if( null != controlSubscriberMetaDataMap.get(TransactionConstants.ControlSubscriberMetaData.Output.SUBSCRIBER_NO_LIST) ){
			@SuppressWarnings("unchecked")
			List<String> resultSubscriberNoList = (List<String>) controlSubscriberMetaDataMap.get(TransactionConstants.ControlSubscriberMetaData.Output.SUBSCRIBER_NO_LIST);
			int counter = 1;
			for( String returnSubscriberNo : resultSubscriberNoList ){
				iMap.put("SUBSCRIBER_NO"+counter, returnSubscriberNo);
				counter++;
			}
		}
		
	}
	
	public static String applyDecimalFormat(String amount){
		DecimalFormat format = new DecimalFormat(DECIMAL_FORMAT_PATTERN);
		return format.format(Double.parseDouble(amount));
	}
	
	public static String applyDecimalFormatWithDefaultCurrency(String amount){
		DecimalFormat format = new DecimalFormat(DECIMAL_FORMAT_PATTERN);
		return format.format(Double.parseDouble(amount)).concat(" TL");
	}
	
	public static XMLGregorianCalendar convertDate2GregorianCalendar(Date dateConverted) throws Exception{
		
		if( null == dateConverted ){
			throw new Exception("Date cannot be null for the conversion");
		}
		try{
			DatatypeFactory dataTypeFactory = DatatypeFactory.newInstance();
			GregorianCalendar calendar = new GregorianCalendar();
			calendar.setTimeInMillis(dateConverted.getTime());
			
			return dataTypeFactory.newXMLGregorianCalendar(calendar);
		}
		catch(DatatypeConfigurationException ex){
			CommonHelper.getStringifiedException(ex);
		}
		
		return null;
	}
	
	public static XMLGregorianCalendar convertDate2GregorianCalendar(String dateConvertedString, String format) throws Exception{
		
		if( null == dateConvertedString ){
			throw new Exception("Date cannot be null for the conversion");
		}
	
		Date dateConverted = null;
		try{

			dateConverted = getDateTime(dateConvertedString,format);
		}
		catch(Exception ex){
			CommonHelper.getStringifiedException(ex);
		}
		
		return convertDate2GregorianCalendar(dateConverted);
	}
	
	public static Date convertGregorianCalendar2Date(XMLGregorianCalendar calendar) throws Exception{
		
		if( null == calendar ){
			throw new Exception("Calendar cannot be null for the conversion");
		}
		
		return calendar.toGregorianCalendar().getTime();
	}
	
	public static String generateSubject(String subject, GMMap input){
		
		Set<Entry<Object, Object>> entrySet = input.entrySet();
		Iterator<Entry<Object, Object>> iterator = entrySet.iterator();
		while( iterator.hasNext() ){
			Entry<Object, Object> nextElement = iterator.next();
			if( input.containsKey(nextElement.getKey()) ){
				subject = subject.replaceAll(nextElement.getKey().toString(), nextElement.getValue().toString());
			}
		}
		
		return subject;
	}
	
	@SuppressWarnings("unchecked")
	public static GMMap getSingleDimensionMap(GMMap mainTable, String tableName, int rowIndex){
		List<HashMap<String, Object>> tableRowList = (List<HashMap<String, Object>>)mainTable.get(tableName);
		HashMap<String, Object> table = tableRowList.get(rowIndex);
		return CommonHelper.convertMapToGMMap(table);
	}
	
	public static void mapTxPojoToMainPojo(Object txPojo, Object mainPojo) throws Exception {
		Class<? extends Object> txPojoClass = txPojo.getClass();
		Class<? extends Object> mainPojoClass = mainPojo.getClass();
		
		Field[] txFields = txPojoClass.getDeclaredFields();
		
		for (Field field : txFields) {
			if(field.getName().equals("oid") ||
					field.getName().equals("serialVersionUID")){
				continue;
			}
			Field mainField;
			try {
				mainField = mainPojoClass.getDeclaredField(field.getName());
			} catch (NoSuchFieldException e) {
				continue;
			}
			field.setAccessible(true);
			mainField.setAccessible(true);
			mainField.set(mainPojo, field.get(txPojo));
		}
	}
	
	public static void mapObjects(Object oldObject, Object newObject, String... exceptionalFields) throws Exception {
		Class<? extends Object> oldClass = oldObject.getClass();
		Class<? extends Object> newClass = newObject.getClass();
		
		Field[] oldClassFields = oldClass.getDeclaredFields();
		
		List<String> exceptionalFieldsList = new ArrayList<String>();
		
		if(exceptionalFields != null && exceptionalFields.length != 0){
			exceptionalFieldsList = Arrays.asList(exceptionalFields);
		}
		
		for (Field field : oldClassFields) {
			if(exceptionalFieldsList.contains(field.getName())){
				continue;
			}
			Field mainField;
			try {
				mainField = newClass.getDeclaredField(field.getName());
			} catch (NoSuchFieldException e) {
				continue;
			}
			field.setAccessible(true);
			mainField.setAccessible(true);
			mainField.set(newObject, field.get(oldObject));
		}
	}
	
	public static String[] getPojoExceptionalFields(){
		return new String[] { "oid", "serialVersionUID" };
	}
	
	/**
	 * date format must be yyyyMMdd
	 */
	public static Calendar getCalendarWithYYYYMMDD(String date){
		TimeZone utc = TimeZone.getTimeZone("UTC");
		Calendar cal = Calendar.getInstance(utc);
		cal.clear(Calendar.HOUR_OF_DAY);
		cal.clear(Calendar.HOUR);
		cal.clear(Calendar.MINUTE);
		cal.clear(Calendar.SECOND);
		cal.clear(Calendar.MILLISECOND);
		cal.set(Calendar.YEAR, Integer.valueOf(date.substring(0, 4)));
		cal.set(Calendar.MONTH, Integer.valueOf(date.substring(4, 6)) - 1);
		cal.set(Calendar.DAY_OF_MONTH, Integer.valueOf(date.substring(6, 8)));
		return cal;
	}
	
	public static String convertTurkishCharacter(String value) {
		final char[] turkishChar = { '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', '�' };
		final char[] englishChar = { 'I', 'C', 'G', 'S', 'U', 'O', 'i', 'c', 'g', 's', 'u', 'o' };
		for (int i = 0; i < turkishChar.length; i++) {
			value = value.replace(turkishChar[i], englishChar[i]);
		}
		return value;
	}
	
	public static void sendSMS(String mobilePhone, String content) throws Exception {
		GMMap request = new GMMap();
		request.put("MSISDN", mobilePhone);
		request.put("CONTENT", content);
		callGraymoundServiceOutsideSession("BNSPR_SMS_SEND_SMS", request);
	}
	
	public static void fillBuilderWithTable(StringBuilder builder, boolean boldHeader, String... columnNames) throws Exception {
		builder.append("<table border=1>");
		builder.append("<tr>");
		
		for (String string : columnNames) {
			builder.append(String.format("<td>%s%s%s</td>", boldHeader ? "<b>" : "", string, boldHeader ? "</b>" : ""));
		}
		
		builder.append("</tr>");
	}
	
	public static void closeBuilder(StringBuilder builder) {
		builder.append("</table>");
	}
	
	public static String concatStrings(String delimeter, String... concatenationList) throws Exception {
		StringBuilder builder = new StringBuilder();
		int size = concatenationList.length;
		
		for (int i = 0; i < concatenationList.length; i++) {
			String currentStr = concatenationList[i];
			if(!StringUtil.isEmpty(currentStr)){
				builder.append(currentStr);
				if(i != size - 1){
					if(!StringUtil.isEmpty(concatenationList[i+1])){
						builder.append(delimeter);
					}
				}
			}
		}
		
		return builder.toString();
	}
	
	public static void insertWsCallLog(GMMap iMap, String parameter1,String parameter2,String parameter3) {
		try {
			iMap.put(MapKeys.DURATION, parameter1);
			iMap.put(MapKeys.START_TIME, parameter2);
			iMap.put(MapKeys.END_TIME, parameter3);
			GMServiceExecuter.executeAsync("ICS_INSERT_ONLINE_WS_CALL_LOG", iMap);
		}
		catch (Exception e) {
			logger.error("ICS_INSERT_ONLINE_WS_CALL_LOG hata ald�.".concat(iMap.toString()));
		}

	}
	
	public static String getCurrencyOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.DOVIZ_KODU_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}
	
	public static String getNameOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.ACCOUNT_NAME_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}
	
	public static void callGraymoundServiceAsync(String serviceName, GMMap input){
		GMServiceExecuter.executeAsync(serviceName, input);
	}
}
