package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;

import com.aydem.dicle.bankalar.DicleClient;
import com.aydem.dicle.bankalar.ServiceMessage;
import com.graymound.util.GMMap;

import dicleborc.FaturaThs;
import dicleborc.holders.TahsilatDetayHolder;

public class DicleReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(DicleReconciliationDetailBatch.class);
	Session session;
	TahsilatDetayHolder details;
	ServiceMessage message;
	Map<String, FaturaThs> indexedCorporateRecords;

	public DicleReconciliationDetailBatch(GMMap input, ServiceMessage serviceMessage) {
		super(input);
		this.message = serviceMessage;
		this.indexedCorporateRecords = new HashMap<String, FaturaThs>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.SUBSCRIBER_NO1, details.value.getFaturalar()[corporateRecordIndex].getTesisatNo());
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.value.getFaturalar()[corporateRecordIndex].getFaturaNo());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put("SUBSCRIBER_NO_1", details.value.getFaturalar()[corporateRecordIndex].getTesisatNo());
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.value.getFaturalar()[corporateRecordIndex].getFaturaNo());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			details = DicleClient.getTahsilatDetay(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), this.message);
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling dicle recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.value.getFaturalar().length; i++) {
			this.indexedCorporateRecords.put(this.details.value.getFaturalar()[i].getFaturaNo(), this.details.value.getFaturalar()[i]);
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.value.getFaturalar()[corporateRecordIndex].getFaturaNo());
	}

	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex) throws Exception {
		FaturaThs corporateDetail = details.value.getFaturalar()[corporateRecordIndex];
		logger.info(String.format("Following corporate record has not been found in database. Tesisat No : %s, Fatura No : %s", corporateDetail.getTesisatNo(), corporateDetail.getFaturaNo()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(Integer.toString(corporateDetail.getTesisatNo()));
		payment.setInvoiceNo(corporateDetail.getFaturaNo());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getToplamTutar()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getToplamTutar()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");

		session.saveOrUpdate(payment);
		session.flush();

		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getTesisatNo());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getFaturaNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getToplamTutar());
	}
}
