package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.TTSReconciliationLineParserRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.TTSReconciliationLineParserProcess;
import tr.com.aktifbank.bnspr.cps.dto.TTSReconciliationDetail;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.ReconLog;

import com.graymound.util.GMMap;

public class TTSReconciliationLineParser  extends RequestHandler {

	private static final String DETAIL = "D";
	
	private static final String DO_INVIOCE_COLLECTION_CODE = "11";
	
	private static final String CANCEL_INVIOCE_COLLECTION_CODE = "21";
	
	private static final String STANDING_ORDER_COLLECTION_CODE = "10";
	
	private static final Log logger = LogFactory.getLog(TTSReconciliationLineParser.class);
	
	private static final int []startIndexes = new int[]{1,9,10,12,15,23,31,51,59,75,77};
	
	private static final int []lengthIndexes = new int[]{8,1,2,3,8,8,20,8,16,2,20};
	
	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		String fileDefId = input.getString("FILE_DEF_ID"); 
//		fileDefId = "62";

//		String tableName = "TT_FILE_FORMAT_TABLE";
		
		logger.info("[TTSReconciliationLineParser[handleInternal]] is started. Parameters : " + input);

		String processId = input.getString("PROCESS_ID");
//		processId = "12160";
		
		getCommonInfo(fileDefId,output);
		
//		String fileFormatId = output.getString(TTSReconciliationLineParserProcess.Output.FILE_FORMAT);

//		logger.info("[TTSReconciliationLineParser[handleInternal]] File Format Id : " + fileFormatId);
		
		Session hibernateSession = CommonHelper.getHibernateSession();
		Criteria criteriaFtmContentList = hibernateSession.createCriteria(FtmFileContent.class).add(Restrictions.eq("ftmProcessOid", new BigDecimal(processId)));
		
//		String query = String.format("select oid from cdm.file_format_def where file_format_id='%s'",fileFormatId); 
			
//		GMMap fileDefMap = DALUtil.getResults(query,tableName);
			
//		List<Map<String,String>> fileDefList = (List<Map<String,String>>) fileDefMap.get(tableName);
//		logger.info("[TTSReconciliationLineParser[handleInternal]] File Defition Map : " + fileDefMap);
		
//		Criteria fileDetailCriteria = hibernateSession.createCriteria(FileFormatDetail.class).add(Restrictions.eq("fileFormatOid", fileDefList.get(0).get("OID"))).
//															    add(Restrictions.eq("status", true));
			
//		fileDetailCriteria = fileDetailCriteria.addOrder(Order.asc("lineNumber"));
//		List<FileFormatDetail> resultList = fileDetailCriteria.list();
			
		List<String> parseList = new ArrayList<String>();
		int size = startIndexes.length;
		SortedMap<String,TTSReconciliationDetail> corporateMap = new TreeMap<String, TTSReconciliationDetail>();
		
		Iterator<FtmFileContent> fileContentIterator = criteriaFtmContentList.list().iterator();
		while( fileContentIterator.hasNext() ){
			
			FtmFileContent nextContent = fileContentIterator.next();
			String line = nextContent.getLine();
			
			if( line.startsWith(DETAIL)){
        		logger.info("[TTSReconciliationLineParser[handleInternal]] Parser Processing is started.");
        		StringBuilder buffer = new StringBuilder();
//        		for( FileFormatDetail  nextFileFormatDetailRecord : resultList ){
//					BigDecimal startIndex = nextFileFormatDetailRecord.getStartIndis();
//					BigDecimal length = nextFileFormatDetailRecord.getLength();
//					int lastIndex = startIndex.intValue() + length.intValue();
        		for( int i = 0; i < size; i++ ){
        			int lastIndex = startIndexes[i] + lengthIndexes[i];

					String element = parseElement(line, startIndexes[i], lastIndex);
					buffer.append(element.trim());
					buffer.append(",");
				}
        		logger.info("[TTSReconciliationLineParser[handleInternal]] Next Line : " + buffer.toString());
        		parseList.add(buffer.toString());
        	}
        	
		}
		      
		logger.info("[TTSReconciliationLineParser[handleInternal]] Parser Processing is ended.");
	        
        List<TTSReconciliationDetail> paymentList = new ArrayList<TTSReconciliationDetail>();
        List<TTSReconciliationDetail> standingOrderPaymentList = new ArrayList<TTSReconciliationDetail>();
        List<TTSReconciliationDetail> cancelPaymentList = new ArrayList<TTSReconciliationDetail>();
        
        if( parseList.size() > 0 ){
        	
        	logger.info("[TTSReconciliationLineParser[handleInternal]] Mapping Processing is started.");
        	Iterator<String> parseIterator = parseList.iterator();
        	
        	while( parseIterator.hasNext() ){
        		
        		String nextData = parseIterator.next();
//        		logger.info("[TTSReconciliationLineParser[handleInternal]] Mapping Processing... Next Data : " + nextData);
        		
        		String[] splitList = nextData.split(",");
        		
        		TTSReconciliationDetail detail = new TTSReconciliationDetail();
        		
        		String processCode = splitList[3].substring(1);
        		detail.setProcessCode(processCode);
        		
        		detail.setPaymentDate(splitList[0]);
        		detail.setCollectionAmount(new BigDecimal(splitList[10]).divide(new BigDecimal(100)).setScale(2));
        		detail.setInvoiceNo(new BigDecimal(splitList[8]).toString());
        		detail.setStan(new BigDecimal(splitList[7]).toString());
        		detail.setServiceNo(new BigDecimal(splitList[6]).toString());
        		
        		if( processCode.equals(DO_INVIOCE_COLLECTION_CODE) ){
        			paymentList.add(detail);
        			corporateMap.put(detail.getStan(), detail);
        		}
        		else if( processCode.equals(STANDING_ORDER_COLLECTION_CODE) ){
        			standingOrderPaymentList.add(detail);
        		}
        		else if( processCode.equals(CANCEL_INVIOCE_COLLECTION_CODE) ){
        			cancelPaymentList.add(detail);
        		}
        
        		
//        		logger.info("[TTSReconciliationLineParser[handleInternal]] Mapping Result :  " + detail);
        	}
        	
        	logger.info("[TTSReconciliationLineParser[handleInternal]] Mapping Processing is ended. Reconciliation Detail Size : " + paymentList.size() +" ," + cancelPaymentList.size());
        }
	        
        
           List<TTSReconciliationDetail> paymentDetailList = findDifferPaymentInCancelList(paymentList,cancelPaymentList);
	       output.put(TTSReconciliationLineParserProcess.Output.INVOICE_PAYMENT_LIST, paymentDetailList);
	       output.put(TTSReconciliationLineParserProcess.Output.STANDING_ORDER_PAYMENT_LIST, standingOrderPaymentList);
	       findDifferenceByStanNo(output,corporateMap);
	       this.callGraymoundServiceAsync(TTSReconciliationLineParserProcess.SERVICE_NAME, output);

		
	}
	
	private static String getCompanyCode4Reconciliation(String corporateCode){
		String tmpCompanyCode = CommonHelper.getValueOfParameter("CDM_CORPORATE_COMPANY_CODE_RECON",corporateCode);	
		return corporateCode.concat(",").concat(tmpCompanyCode);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void findDifferenceByStanNo(GMMap iMap, SortedMap<String, TTSReconciliationDetail> corporatDetaileMap){
		 
		List<String> corporateCodes = new ArrayList<String>(); 
		String corporateCodeList = null;
		String tmpCorporateCode = iMap.getString(TTSReconciliationLineParserProcess.Output.CORPORATE_CODE);
//		StringBuilder corporateCodeBuilder = new StringBuilder("(");
		if( tmpCorporateCode.contains(",") ){
			corporateCodeList = tmpCorporateCode.toString();
		}
		else{
			 corporateCodeList = getCompanyCode4Reconciliation(tmpCorporateCode);
		}
		iMap.put(MapKeys.CORPORATE_CODE, corporateCodeList);
		if( corporateCodeList.contains(",") ){
			for( String corpCode : corporateCodeList.split(",") ){
//				corporateCodeBuilder.append("'"+corpCode+"',");
				corporateCodes.add(corpCode);
			}
			
//			corporateCodeBuilder = corporateCodeBuilder.replace(corporateCodeBuilder.length()-1, corporateCodeBuilder.length(), ")");
		}
		else{
//			corporateCodeBuilder.append(corporateCodeList+"')");
			corporateCodes.add(corporateCodeList);
			
		}
		
	    Session hibernateSession = CommonHelper.getHibernateSession();
		 
		Criteria criteria = hibernateSession.createCriteria(ReconLog.class).add(Restrictions.eq("status", true))
				   .add(Restrictions.eq("reconStatus", DatabaseConstants.ReconciliationStatus.ReconciliationFailed))
				   .add(Restrictions.in("corporateCode", corporateCodes))
				   .addOrder(Order.desc("processDate")).addOrder(Order.desc("processTime"));

		List<ReconLog> reconLogs = criteria.setMaxResults(2).list();
		ReconLog reconLog = reconLogs.get(0);
		
		if( null != reconLogs && reconLogs.size() > 0 ){ 
			if( null != reconLog ){
				String reconDate = reconLog.getReconDate();
				logger.info("[TTSReconciliationLineParser[findDifferenceByStanNo]] Finding Recon Date " + reconDate + ", Recon Type : " +  reconLog.getReconType()  );

//				reconLog.setReconType(DatabaseConstants.ReconciliationTypes.Collection);
		
//					iMap.put(MapKeys.RECON_DATE, "20140421");
			
				if( DatabaseConstants.ReconciliationTypes.Collection == reconLog.getReconType() ){
				
				List bankStans = hibernateSession.createSQLQuery(TTSReconciliationLineParserRepository.GET_STAN_NO_QUERY)
	 					.setParameter("corporateCode1", corporateCodes.get(0))
	 					.setParameter("corporateCode2", corporateCodes.get(1))
	 					.setParameter("paymentDate", reconDate + "%")
							.list();

				logger.info("[TTSReconciliationLineParser[getFileFormatId]] Bank Payment Detail Size " +bankStans.size());
				
				
				 Map<String,String> bankStanMap = new HashMap<String, String>();
				 
				 if( null != bankStans ){
					 Iterator iterator = bankStans.iterator();
					 while( iterator.hasNext() ){
						 String bankStanNo =  iterator.next().toString();
//						 if( null != row[0] ){
//							 String bankStanNo = row[0].toString();
							 bankStanMap.put(bankStanNo, bankStanNo);
							
//						 }
					 }
				 }
				 
				 int bankInvoicePaymentCount = bankStans.size();
				 int corporateInvoicePaymentCount = corporatDetaileMap.size();
				 
				 logger.info("[TTSReconciliationLineParser[getFileFormatId]] Bank Payment Detail Size " + bankInvoicePaymentCount + " , Corporate Payment Detail Size : " + corporateInvoicePaymentCount);
				 
				 if( corporateInvoicePaymentCount > bankInvoicePaymentCount ){
				 
					 logger.info("[TTSReconciliationLineParser[getFileFormatId]] Trying to find the records not exist in banks records.");
					 List<TTSReconciliationDetail> resultList = new ArrayList<TTSReconciliationDetail>();
					 Iterator<Entry<String, TTSReconciliationDetail>> corpDetailIterator = corporatDetaileMap.entrySet().iterator();
					 while( corpDetailIterator.hasNext() ){
						 Entry<String, TTSReconciliationDetail> nextCorporateDetail = corpDetailIterator.next();
						 String corporateStanNo = nextCorporateDetail.getKey();
						 
						 if( !bankStanMap.containsKey(corporateStanNo) ){
							 logger.info("[TTSReconciliationLineParser[getFileFormatId]] This detail has not been found : " + nextCorporateDetail.getValue());
							 resultList.add( nextCorporateDetail.getValue());

						 }
					 }
					 
					 
					 logger.info("[TTSReconciliationLineParser[getFileFormatId]] The records are found in banks records : " + resultList.size());
					
					}
				 else{
					 
				 }
				}
		
			}
		
		}

//		 StringBuilder builder = new StringBuilder();
//		 for( TTSReconciliationDetail detail : resultList ){
//			  logger.info(detail);
//			 builder.append("'"+ detail.getStan() +"',");
//		 }
//		
//		 logger.info(builder.toString());
	 }
	
	private boolean compareDetails(List<TTSReconciliationDetail> paymentList, List<TTSReconciliationDetail> cancelPaymentList, String invoiceNo){
		
		int paymentCounter = 0;
		int cancelPaymentCounter = 0;
		
		for( TTSReconciliationDetail paymentDetail : paymentList ){
			if(paymentDetail.getInvoiceNo().equals(invoiceNo) ){
				paymentCounter += 1;
			}
		}
		
		for( TTSReconciliationDetail cancelPaymentDetail : cancelPaymentList ){
			if(cancelPaymentDetail.getInvoiceNo().equals(invoiceNo) ){
				cancelPaymentCounter += 1;
			}
		}
		
		if( paymentCounter == cancelPaymentCounter )
			return true;
		return false;
		
	}
		
	 private List<TTSReconciliationDetail> findDifferPaymentInCancelList(List<TTSReconciliationDetail> paymentList, List<TTSReconciliationDetail> cancelPaymentList) {
		
		List<TTSReconciliationDetail> detailList = new ArrayList<TTSReconciliationDetail>();
		Set<String> cancelList = new HashSet<String>();
		List<TTSReconciliationDetail> sameInvoiceList  = new ArrayList<TTSReconciliationDetail>();
		for( int i = 0; i < paymentList.size(); i++ ){
			boolean flag = false;
			for( int j = 0; j < cancelPaymentList.size(); j++ ){
				if( paymentList.get(i).getInvoiceNo().equals(cancelPaymentList.get(j).getInvoiceNo()) ){
					cancelList.add(paymentList.get(i).getInvoiceNo());
					sameInvoiceList.add(paymentList.get(i));
					flag = true;
					break;
				}
				
			}
			if( !flag ){
				detailList.add(paymentList.get(i));
			}
			
		}
		
		for( String invoiceNo : cancelList ){
			boolean equal = compareDetails(paymentList, cancelPaymentList, invoiceNo);
			
			if( !equal ){
				for( int i = 0; i < sameInvoiceList.size(); i++ ){
					if( sameInvoiceList.get(i).getInvoiceNo().equals(invoiceNo) ){
						detailList.add(sameInvoiceList.get(i));
						break;
					}
				}
			}
		}
		
		return detailList;
		
	 }
		
	private static String parseElement(String line, int startIndex, int lastIndex){
		 return line.substring(startIndex, lastIndex);
	 }
	
	 private static void getCommonInfo(String fileDefId, GMMap output){
			logger.info("[TTSReconciliationLineParser[getFileFormatId]] File Def Id : "+ fileDefId);
			String corporateCode = CommonHelper.getValueOfParameter("CDM_FILE_DEF_CORPORATE_CODE_MAPPING", fileDefId);
//			corporateCode = "C-259,C-260";
			logger.info("[TTSReconciliationLineParser[getFileFormatId]] Corporate Code: "+ corporateCode);
//			String fileFormatId = CommonHelper.getValueOfParameter("CDM_FILE_FORMAT_CORPORATE_CODE_MAPPING", corporateCode);
			
			output.put(TTSReconciliationLineParserProcess.Output.CORPORATE_CODE, corporateCode);
//			output.put(TTSReconciliationLineParserProcess.Output.FILE_FORMAT, fileFormatId);
	 }
}
