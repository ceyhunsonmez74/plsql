package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.EmailConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant.Email.SameDayTransferBalanceMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.SameDayCorporateAccountTransferHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.dao.BalanceTransferDef;
import tr.com.aktifbank.bnspr.dao.BalanceTransferEftEmailDef;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SameDayCorporateAccountTransferHandler extends RequestHandler {
	
	private static final String SUCCESSFUL = "2";

	public SameDayCorporateAccountTransferHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Criteria criteria = super.getHibernateSession().createCriteria(CorporateBatchProcess.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("batchName", DatabaseConstants.BatchNames.SameDayAccountTransferBatch));
		
		if(input.containsKey("CORPORATE_CODE")){
			criteria = criteria.add(Restrictions.eq("corporateCode", input.getString("CORPORATE_CODE")));
		}
		List<CorporateBatchProcess> sameDayBatchList = criteria.list();
		
		String paymentDate = CommonHelper.getShortDateTimeString(new Date());
		String inputDate = input.getString("PROCESS_DATE", null);
		
		if(!StringUtil.isEmpty(inputDate)){
			paymentDate = inputDate;
		}
		
		for (CorporateBatchProcess process : sameDayBatchList) {
			
			String corporateCode = process.getCorporateCode();
			Date currentDate = new Date();
			String corporateOid = null;
			if(!StringUtil.isEmpty(corporateCode)){
				GMMap getCorporateDefResponse = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME,
						TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
				corporateOid = getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID);
			}
			
			Criteria transferDefCriteria = super.getHibernateSession().createCriteria(BalanceTransferDef.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("fromAccountType", DatabaseConstants.AccountDefinitionTypes.CollectionAccount))
					.add(Restrictions.eq("toAccountType", DatabaseConstants.AccountDefinitionTypes.EftAccount));
			
			if(!StringUtil.isEmpty(corporateOid)){
				transferDefCriteria = transferDefCriteria.add(Restrictions.eq("corporateOid", corporateOid));
			}
			
			List<BalanceTransferDef> transferDefList = transferDefCriteria.list();
			
			
			
			for (BalanceTransferDef def : transferDefList) {
				String defCorporateCode = null;
				
				GMMap getCorporateDefResponse = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME,
						TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, def.getCorporateOid());
				
				if(!StringUtil.isEmpty(corporateCode)){
					defCorporateCode = corporateCode;
				}
				else{
					defCorporateCode = getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
				}
				
				String ibanOwner = getIbanOwner(def.getCorporateOid(), def.getToAccountIban());
				
				String balanceTransferProcessId = super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferProcess.Input.COLLECTION_DATE, paymentDate,
						TransactionConstants.InsertBalanceTransferProcess.Input.CORPORATE_CODE, defCorporateCode,
						TransactionConstants.InsertBalanceTransferProcess.Input.CORPORATE_OID, def.getCorporateOid(),
						TransactionConstants.InsertBalanceTransferProcess.Input.FROM_ACCOUNT, def.getFromAccountNo(),
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_EFT_TRANSFER, true,
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, false,
						TransactionConstants.InsertBalanceTransferProcess.Input.PROCESS_DATE, currentDate,
						TransactionConstants.InsertBalanceTransferProcess.Input.TO_ACCOUNT, def.getToAccountNo(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TO_IBAN, def.getToAccountIban(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TO_IBAN_OWNER, ibanOwner,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Executing,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_DEF_OID, def.getOid(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_TYPE, DatabaseConstants.AccountTransferTypes.CorporateTransfer)
						.getString(TransactionConstants.InsertBalanceTransferProcess.Output.RECORD_ID);
				String balanceTransferLogId = super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferLog.Input.CORPORATE_CODE, defCorporateCode,
						TransactionConstants.InsertBalanceTransferLog.Input.CORPORATE_OID, def.getCorporateOid(),
						TransactionConstants.InsertBalanceTransferLog.Input.PROCESS_DATE, currentDate,
						TransactionConstants.InsertBalanceTransferLog.Input.PROCESS_USER, CommonHelper.getCurrentUser(),
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_PROCESS_OID, balanceTransferProcessId,
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferStarted)
						.getString(TransactionConstants.InsertBalanceTransferLog.Output.RECORD_ID);
				
				try {
					
					BigDecimal amount = getAvailableBalance(def.getFromAccountNo());
					
					if(amount == null || amount.equals(BigDecimal.ZERO)) {
						super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
								TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
								TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
								TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.NoPaymentFound);
						super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
								TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
								TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
								TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.NoPaymentFound,
								TransactionConstants.InsertBalanceTransferLog.Input.ERROR_CODE, "1",
								TransactionConstants.InsertBalanceTransferLog.Input.ERROR_MESSAGE, "Herhangi bir tahsilat kayd� bulunamam��t�r.");
						continue;
					}
					
					String transactionNo = CommonHelper.getNewTransactionNo();
					
					String branchCodeQuery = String.format(SameDayCorporateAccountTransferHandlerRepository.GET_BRANCH_CODE_QUERY, def.getFromAccountNo());
					
					String branchCode = DALUtil.getResult(branchCodeQuery);
					
					String branchName = CommonBusinessOperations.getBranchNameFromBranchCode(branchCode);
					
					GMMap eftTransferRequest = new GMMap();
					eftTransferRequest.put("REFERENCE_ID", transactionNo);
					eftTransferRequest.put("AMOUNT", amount);
					eftTransferRequest.put("RCVR_IBAN", def.getToAccountIban());
					eftTransferRequest.put("RCVR_FULL_NAME", getIbanOwner(def.getCorporateOid(), def.getToAccountIban()));
					eftTransferRequest.put("SNDR_ACC_CODE", def.getFromAccountNo());
					eftTransferRequest.put("RCVR_EXPLANATION", getDescription(branchCode, branchName));
					GMMap eftResponse = super.callGraymoundServiceInSession("CS_EFT_DO", eftTransferRequest);
					if(eftResponse.getString("RESULT").equals(SUCCESSFUL)){
						// No problem
						BalanceTransferEftEmailDef emailDef = (BalanceTransferEftEmailDef)super.getHibernateSession().createCriteria(BalanceTransferEftEmailDef.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("corporateCode", defCorporateCode))
															.uniqueResult();
						if(emailDef != null && emailDef.isEmailEftTransfer()) {
							try {
								CommonHelper.sendMail(
										Arrays.asList(emailDef.getEftEmailList().split("[,]")), null, CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "EFT_TRANSFER_EMAIL_FROM"), true, 
										String.format("%s Tarihli %s Nolu hesab�n�zdan yap�lan EFT tutar aktar�m�n� bilgilerinize sunar�z", CommonHelper.shortTimeStringToViewDateString(CommonHelper.getShortDateTimeString(currentDate)), def.getFromAccountNo()), 
										String.format("<html><head></head><body><br/><br/>" + 
										"<b>M��TER� NO :</b> %s<br/>" + 
										"<b>M��TER� �NVANI :</b> %s<br/>" +
										"<b>HESAP NO :</b> %s<br/>" + 
										"<b>HESAP ADI :</b> %s<br/>" + 
										"<b>HESAP D�V�Z KODU :</b> %s<br/>" + 
										"<b>EFT BAK�YES� :</b> %s<br/>" + 
										"</body></html>", getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CUSTOMER_NUMBER), 
														  getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE),
														  def.getFromAccountNo(), CommonHelper.getNameOfAccount(def.getFromAccountNo()), CommonHelper.getCurrencyOfAccount(def.getFromAccountNo()), 
														  amount)
										);
							} catch (Exception e) {
								logger.error("Mail g�nderilirken hata meydana geldi...");
								logger.error(e.toString());
							}
						}
					}
					else{
						throw new Exception(eftResponse.getString("ERROR_DESC"));
					}
					
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Successful,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_AMOUNT, amount);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferExecutedSuccessfully,
							TransactionConstants.InsertBalanceTransferLog.Input.ACTUAL_TRANSFER_AMOUNT, amount,
							TransactionConstants.InsertBalanceTransferLog.Input.CONSTANT_AMOUNT, 0,
							TransactionConstants.InsertBalanceTransferLog.Input.CURRENT_AVAILABLE_BALANCE, 0,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_AMOUNT, amount);
				} catch (Exception e) {
					logger.error(String.format("An exception occured while executing same day transfer for corporate code : %s and payment date : %s", defCorporateCode, paymentDate));
					logger.error(System.currentTimeMillis(), e);
					
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Failed);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferFailed,
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_CODE, "1",
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_MESSAGE, String.format("Transfer yap�l�rken bir hata olu�tu : %s", e));
					
					GMMap messageBodyMap = new GMMap();
					messageBodyMap.put("KURUM_ADI", getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE));
					messageBodyMap.put("KURUM_KODU", corporateCode);
					messageBodyMap.put("KAYNAK_HESAP", def.getFromAccountNo());
					messageBodyMap.put("HEDEF_IBAN", def.getToAccountIban());
					messageBodyMap.put("HATA", e.getMessage());
					
					EmailMessage emailMessage = CommonHelper.prepareEmailBody(getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE), 
							messageBodyMap, 
							SameDayTransferBalanceMessageConstant.Body.MESSAGE_BODY_4_EFT_ACCOUNT ,SameDayTransferBalanceMessageConstant.SUBJECT,
							CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_TRANSFER_ERRORS"));
					
					CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
				}
			}
		}
	}
	
	private BigDecimal getAvailableBalance(BigDecimal fromAccountNo) {
		GMMap getAvailableBalanceRequest = new GMMap();
		getAvailableBalanceRequest.put("HESAP_NO", fromAccountNo);
		
		GMMap getAvailableBalanceResponse = GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", getAvailableBalanceRequest);
		
		return getAvailableBalanceResponse.getBigDecimal("KULLANILABILIR_BAKIYE");
	}

	private String getIbanOwner(String corporateOid, String toAccountIban) {
		if(!StringUtil.isEmpty(toAccountIban)){
			CorporationAccountMaster record = (CorporationAccountMaster)super.getHibernateSession().createCriteria(CorporationAccountMaster.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateOid", corporateOid))
					.add(Restrictions.eq("iban", toAccountIban))
					.uniqueResult();
			if(record != null){
				return record.getAccountOwner();
			}
			else{
				return null;
			}
		}
		else{
			return null;
		}
	}
	
	private String getDescription(String branchCode, String branchName) {
		StringBuilder builder = new StringBuilder();
		
		builder.append(String.format("%s-%s Fatura �demesi Kurum Hesaplar Aras� Aktar�m", branchCode, branchName)); 
		
		return builder.toString();
	}

}
