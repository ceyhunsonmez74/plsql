package tr.com.aktifbank.bnspr.cps.common;

import java.math.BigDecimal;

public final class GeneralConstants {
	public static final String DataAccessSessionName = "BNSPRDal";
	public static final String ConfigurationFileName = "CPSConfiguration.properties";
	public static final String EHCacheConfigurationFilePath = "ehcache.xml";
	public static final String BatchSubmitIdSequenceKey = "BATCH_SUBMIT_ID";
	public static final String FTM_CONNECTION_NAME = "FTM";
	public static final String FTM_EXT_CONNECTION_NAME = "FTM_EXT";
	public static final String FACTORY_INDICATOR = "INDIKATOR";
	public static final String INFORM_STANDING_ORDER_FACTORY_COMMAND = "TALIMAT_BILDIR";
	public static final String StanNoSequenceKey = "ICS_STAN_NO";
	public static final String ERROR_CODE_APPROVE = "0";
	public static final int ERROR_CODE_NOT_FOUND = 2795;
	public static final String ERROR_CODE_NOT_FOUND_EXPLAIN = "Hata kodu bulunamad�";
	public static final int ERROR_CODE_SYSTEM = 2801;
	public static final String ERROR_CODE_SYSTEM_EXPLAIN = "Web Serviste Sistem Hatas�";
	public static final String INVOICE_STATUS_DEFAULT = "A";
	public static final char PAYMENT_METHOD_DEFAULT = '\0';
	public static final String PAYMENT_STATUS_DEFAULT = "B";
	public static final String DEFAULT_STRING = "";
	public static final BigDecimal TRX_NO_DEFAULT = new BigDecimal(0);
	public static final BigDecimal FTM_SEQUENCE_NUMBER_DEFAULT = new BigDecimal(0);
	public static final BigDecimal PAYMENT_AMOUNT_DEFAULT = new BigDecimal(0);
	public static final String SOURCE_DEFAULT = "2";
	public static final String COMMISSION_DEFAULT = "0";
	public static final String GM_BRANCH_CODE = "555";
	public static final String BRANCH_CHANNEL_CODE = "1";
	public static final String JOB_CONNECTION_NAME = "CPS_JOB";
	public static final String NOT_SUPPORTED_COLLECTION_TYPE_ERROR = "2970";
	public static final String CORPORATE_REMOTE_SERVICE_ERROR_CODE = "-10";
	
	public static final short INFORM_COLLECTIONS = 0;
	public static final short INFORM_STANDING_ORDERS = 1;
	public static final short INFORM_STANDING_ORDERS_CANCEL = 2;
	public static final short INFORM_BULK_COLLECTIONS = 3;
	public static final short INFORM_COLLECTIONS_WITH_EXCEL = 4;
	public static final String NOT_PROCESS_WEEKEND_CODE = "4bc30b8354df489aa6342a57c4ae489a";
	public static final String YIM_CHANNEL_CODE = "32";
	public static final long HARDCODED_STRING_ERROR_MESSAGE_CODE = 660;
	public static final String AUTO_PAY_CHANNEL_CONN_NAME = "APAY";
	
	public static final int COLLECTION_TYPE_NOT_MENTIONED = -1;
	public static final String EPOS_CHANNEL_CODE = "21";
	public static final String AUTO_PAY_CHANNEL_CODE = "45";
 
}
