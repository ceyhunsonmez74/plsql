package tr.com.aktifbank.bnspr.cps.multithreading.implementations;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.DebtLoadingProcessInformation;
import tr.com.aktifbank.bnspr.cps.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cps.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.cps.multithreading.core.MultiThreadingUtilities;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ServiceBasedMultiThreading;


public class DebtLineParserImplementation extends ServiceBasedMultiThreading {
	DebtLoadingProcessInformation information;
	private int totalLineCount;
	private BigDecimal totalAmount;
	private int loadedCount;
	private BigDecimal loadedAmount;
	
	public int getTotalLineCount() {
		return totalLineCount;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public int getLoadedCount() {
		return loadedCount;
	}

	public BigDecimal getLoadedAmount() {
		return loadedAmount;
	}

	public DebtLineParserImplementation(DebtLoadingProcessInformation information){
		super();
		this.information = information;
		this.totalLineCount = 0;
		this.totalAmount = new BigDecimal(0);
		this.loadedCount = 0;
		this.loadedAmount = new BigDecimal(0);
	}

	@Override
	protected void prepareCall() throws Throwable {
		int threadCount = information.getThreadCount();
		int rowCount = information.getTotalLineCount();
		GMMap databaseFieldMaps = new GMMap();
		for(ItemDatabaseField field : information.getDatabaseFields()){
			databaseFieldMaps.put(field.getOid(), field);
		}
		GMMap serviceFieldMaps = new GMMap();
		for (ItemServiceField field : information.getServiceFields()) {
			serviceFieldMaps.put(field.getOid(), field);
		}
		Map<Integer, Integer> indexStartMappings = MultiThreadingUtilities.getIndexStartMappings(threadCount, rowCount);
		int counter = 1;
		for(Map.Entry<Integer, Integer> entry : indexStartMappings.entrySet()){
			GMMap inputMap = new GMMap();
			inputMap.put(TransactionConstants.DebtLineParser.Input.BATCH_SUBMIT_ID, information.getBatchSubmitId());
			inputMap.put(TransactionConstants.DebtLineParser.Input.COMMIT_COUNT, information.getCommitCount());
			inputMap.put(TransactionConstants.DebtLineParser.Input.CORPORATE_CODE, information.getCorporateCode());
			inputMap.put(TransactionConstants.DebtLineParser.Input.DATABASE_FIELD_MAPS, databaseFieldMaps);
			inputMap.put(TransactionConstants.DebtLineParser.Input.DETAIL_FORMAT_DETAILS, information.getBodyDetails());
			if (indexStartMappings.containsKey(counter + 1)) {
				inputMap.put(
						TransactionConstants.DebtLineParser.Input.END_LINE_NUMBER,
						indexStartMappings.get(counter + 1) - 1);
			}
			else{
				inputMap.put(
						TransactionConstants.DebtLineParser.Input.END_LINE_NUMBER,
						rowCount);
			}
			inputMap.put(TransactionConstants.DebtLineParser.Input.ERROR_THRESHOLD, information.getErrorThreshold());
			inputMap.put(TransactionConstants.DebtLineParser.Input.CONTROL_LOOP_COUNT, information.getControlLoopCount());
			inputMap.put(TransactionConstants.DebtLineParser.Input.FOOTER_FORMAT_DETAILS, information.getFooterDetails());
			inputMap.put(TransactionConstants.DebtLineParser.Input.FTM_ID, information.getFtmId());
			inputMap.put(TransactionConstants.DebtLineParser.Input.FTM_TRANSFER_ID, information.getFtmTransferId());
			inputMap.put(TransactionConstants.DebtLineParser.Input.HEADER_FORMAT_DETAILS, information.getHeaderDetails());
			inputMap.put(TransactionConstants.DebtLineParser.Input.SERVICE_FIELD_MAPS, serviceFieldMaps);
			inputMap.put(TransactionConstants.DebtLineParser.Input.SERVICE_NAME, information.getServiceName());
			inputMap.put(TransactionConstants.DebtLineParser.Input.START_LINE_NUMBER, entry.getValue());
			inputMap.put(TransactionConstants.DebtLineParser.Input.CONTROL_INVOICE_NO, information.isControlInvoiceNo());
			inputMap.put(TransactionConstants.DebtLineParser.Input.CONTROL_INVOICE_DUE_DATE, information.isControlInvoiceDueDate());
			inputMap.put(TransactionConstants.DebtLineParser.Input.LOAD_ONLY_WITH_STANDING_ORDER, information.isLoadOnlyStandingOrderExists());
			super.registerService(TransactionConstants.DebtLineParser.SERVICE_NAME, inputMap);
			counter++;
		}
	}
	
	@Override
	protected void afterCall() throws Throwable {
		if (!this.isHasError()) {
			List<GMMap> resultList = super.getServiceOutputs();
			boolean footerAmountControl = false;
			boolean footerLineCountControl = false;
			BigDecimal footerAmount = new BigDecimal(0);
			int footerLineCount = 0;
			int totalLineCount = 0;
			int notLoadedLineCount = 0;
			BigDecimal notLoadedAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal totalAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			for(GMMap out : resultList){
				totalAmount = totalAmount.add(out.getBigDecimal(TransactionConstants.DebtLineParser.Output.PROCESSED_AMOUNT)).setScale(2, RoundingMode.HALF_UP);
				totalLineCount += out.getInt(TransactionConstants.DebtLineParser.Output.PROCESSED_LINE_COUNT);
				notLoadedLineCount += out.getInt("NOT_INSERTED_COUNT");
				notLoadedAmount = notLoadedAmount.add(out.getBigDecimal("NOT_INSERTED_AMOUNT"));
				if(out.containsKey(TransactionConstants.DebtLineParser.Output.FOOTER_AMOUNT)){
					footerAmountControl = true;
					footerAmount = out.getBigDecimal(TransactionConstants.DebtLineParser.Output.FOOTER_AMOUNT);
				}
				if(out.containsKey(TransactionConstants.DebtLineParser.Output.FOOTER_LINE_COUNT)){
					footerLineCountControl = true;
					footerLineCount = out.getInt(TransactionConstants.DebtLineParser.Output.FOOTER_LINE_COUNT);
				}
				if(!out.getBoolean(TransactionConstants.DebtLineParser.Output.ISSUCCESSFUL)) {
					super.setHasError(true);
					super.setErrorCode(out.getString(TransactionConstants.DebtLineParser.Output.ERROR_CODE));
					super.setErrorMessage(out.getString(TransactionConstants.DebtLineParser.Output.ERROR_MESSAGE));
					break;
				}
			}
			
			this.totalLineCount = footerLineCountControl ? footerLineCount : totalLineCount;
			this.totalAmount = footerAmountControl ? footerAmount : totalAmount;
			this.loadedAmount = this.totalAmount.subtract(notLoadedAmount);
			this.loadedCount = this.totalLineCount - notLoadedLineCount;
			
			if(!this.isHasError()){
				if(footerAmountControl){
					if(footerAmount.compareTo(totalAmount) == 0){
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.FOOTERAMOUNTCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Footer amount control failed. Processed amount : %s, Footer Amount : %s", totalAmount, footerAmount));
					}
				}
				if(footerLineCountControl){
					if(footerLineCount == totalLineCount){
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.FOOTERLINECOUNTCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Footer line count control failed. Processed line count : %s, Footer Line Count : %s", totalLineCount, footerLineCount));
					}
				}
			}
		}
	}
}
