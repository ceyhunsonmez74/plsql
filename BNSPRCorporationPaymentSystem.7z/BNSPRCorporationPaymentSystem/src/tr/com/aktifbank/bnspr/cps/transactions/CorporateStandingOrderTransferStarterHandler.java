package tr.com.aktifbank.bnspr.cps.transactions;

//import java.util.List;
//
//import org.hibernate.criterion.Restrictions;
//
//import tr.com.aktifbank.bnspr.dao.CsCorporateMapping;

import com.graymound.util.GMMap;

public final class CorporateStandingOrderTransferStarterHandler extends
		RequestHandler {

//	private static final String CS_ACTIVE_ORDER = "1";
//	private static final String CS_PASSIVE_ORDER = "1";
	
	public CorporateStandingOrderTransferStarterHandler() {
		super();
	}

	//@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
//		List<CsCorporateMapping> notTransferredMappings = super.getHibernateSession().createCriteria(CsCorporateMapping.class)
//							.add(Restrictions.eq("status", true))
//							.add(Restrictions.eq("standingOrdersTransferred", false))
//							.list();
//		
//		for (CsCorporateMapping mapping : notTransferredMappings) {
//			StringBuilder builder = new StringBuilder();
//		}
	}

}
