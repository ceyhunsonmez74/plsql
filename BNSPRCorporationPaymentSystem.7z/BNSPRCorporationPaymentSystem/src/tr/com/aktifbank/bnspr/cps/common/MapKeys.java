package tr.com.aktifbank.bnspr.cps.common;

public interface MapKeys {
	public static final String ALLOW_AFTER_DUE_DATE = "ALLOW_AFTER_DUE_DATE";
	public static final String ALLOW_PART_AFTER_DUE = "ALLOW_PART_AFTER_DUE";
	public static final String ALLOW_PART_PAYMENT = "ALLOW_PART_PAYMENT";
	public static final String CORPORATE_ACTIVENESS = "CORPORATE_ACTIVENESS";
	public static final String CORPORATE_BANK_CODE = "CORPORATE_BANK_CODE";
	public static final String CORPORATE_CODE = "CORPORATE_CODE";
	public static final String CORPORATE_NAME = "CORPORATE_NAME";
	public static final String COUNT_AFTER_DUE = "COUNT_AFTER_DUE";
	public static final String COUNT_TYPE_AFTER_DUE = "COUNT_TYPE_AFTER_DUE";
	public static final String CREATE_DATE = "CREATE_DATE";
	public static final String CREATE_USER = "CREATE_USER";
	public static final String CUSTOMER_NUMBER = "CUSTOMER_NUMBER";
	public static final String IF_DUE_DATE_HOLIDAY = "IF_DUE_DATE_HOLIDAY";
	public static final String IS_ONLINE_CORPORATE = "IS_ONLINE_CORPORATE";
	public static final String MARKETING_EXPERT = "MARKETING_EXPERT";
	public static final String PROTOCOL_END_DATE = "PROTOCOL_END_DATE";
	public static final String PROTOCOL_START_DATE = "PROTOCOL_START_DATE";
	public static final String REC_DATE = "REC_DATE";
	public static final String REC_OWNER = "REC_OWNER";
	public static final String SECTOR_CODE = "SECTOR_CODE";
	public static final String SHORT_CODE = "SHORT_CODE";
	public static final String TX_STATUS = "TX_STATUS";
	public static final String BANK_CODE = "BANK_CODE";
	
	public static final String DESIRED_CORPORATE_CODE = "DESIRED_CORPORATE_CODE";

	public static final String INVOICE_TERM_YEAR = "INVOICE_TERM_YEAR";
	public static final String INVOICE_TERM_MONTH = "INVOICE_TERM_MONTH";
	public static final String INVOICE_LIST = "INVOICES";
	public static final String COLLECTION_AMOUNT = "COLLECTION_AMOUNT";
	public static final String ERROR_CODE = "ERROR_CODE";
	public static final String ERROR_DESC = "ERROR_DESC";

	public static final String AMOUNT = "AMOUNT";
	public static final String BRANCH_CODE = "BRANCH_CODE";
	public static final String PAYMENT_BRANCH = "PAYMENT_BRANCH";
	public static final String CANCEL_DATE = "CANCEL_DATE";
	public static final String CANCEL_USER = "CANCEL_USER";
	public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
	public static final String CORPORATE_PAYMENT_ID = "CORPORATE_PAYMENT_ID";
	public static final String CURRENCY_CODE = "CURRENCY_CODE";
	public static final String CUSTOMER_NO = "CUSTOMER_NO";
	public static final String FTM_SEQUENCE_NUMBER = "FTM_SEQUENCE_NUMBER";
	public static final String INSTALLMENT_NO = "INSTALLMENT_NO";
	public static final String INVOICE_DATE = "INVOICE_DATE";
	public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE";
	public static final String INVOICE_NO = "INVOICE_NO";
	public static final String INVOICE_STATUS = "INVOICE_STATUS";
	public static final String LOADING_DATE = "LOADING_DATE";
	public static final String LOADING_USER = "LOADING_USER";
	public static final String DESCRIPTION = "DESCRIPTION";
	public static final String PARAMETER1 = "PARAMETER1";
	public static final String PARAMETER2 = "PARAMETER2";
	public static final String PARAMETER3 = "PARAMETER3";
	public static final String PARAMETER4 = "PARAMETER4";
	public static final String PARAMETER5 = "PARAMETER5";
	public static final String PARAMETER6 = "PARAMETER6";
	public static final String PARAMETER7 = "PARAMETER7";
	public static final String PARAMETER8 = "PARAMETER8";
	public static final String PARAMETER9 = "PARAMETER9";
	public static final String PARAMETER10 = "PARAMETER10";
	public static final String PARAMETER11 = "PARAMETER11";
	public static final String PARAMETER12 = "PARAMETER12";
	public static final String PARAMETER13 = "PARAMETER13";
	public static final String PARAMETER14 = "PARAMETER14";
	public static final String PARAMETER15 = "PARAMETER15";
	public static final String PARAMETER16 = "PARAMETER16";
	public static final String PARAMETER17 = "PARAMETER17";
	public static final String PARAMETER18 = "PARAMETER18";
	public static final String PARAMETER19 = "PARAMETER19";
	public static final String PARAMETER20 = "PARAMETER20";
	public static final String PARAMETER_1 = "PARAMETER_1";
	public static final String PARAMETER_2 = "PARAMETER_2";
	public static final String PARAMETER_3 = "PARAMETER_3";
	public static final String PARAMETER_4 = "PARAMETER_4";
	public static final String PARAMETER_5 = "PARAMETER_5";
	public static final String PARAMETER_6 = "PARAMETER_6";
	public static final String PARAMETER_7 = "PARAMETER_7";
	public static final String PARAMETER_8 = "PARAMETER_8";
	public static final String PARAMETER_9 = "PARAMETER_9";
	public static final String PARAMETER_10 = "PARAMETER_10";
	public static final String PARAMETER_11 = "PARAMETER_11";
	public static final String PARAMETER_12 = "PARAMETER_12";
	public static final String PARAMETER_13 = "PARAMETER_13";
	public static final String PARAMETER_14 = "PARAMETER_14";
	public static final String PARAMETER_15 = "PARAMETER_15";
	public static final String PARAMETER_16 = "PARAMETER_16";
	public static final String PARAMETER_17 = "PARAMETER_17";
	public static final String PARAMETER_18 = "PARAMETER_18";
	public static final String PARAMETER_19 = "PARAMETER_19";
	public static final String PARAMETER_20 = "PARAMETER_20";
	public static final String CANCEL_PARAMETER1 = "PARAMETER_1";
	public static final String CANCEL_PARAMETER2 = "PARAMETER_2";
	public static final String CANCEL_PARAMETER3 = "PARAMETER_3";
	public static final String CANCEL_PARAMETER4 = "PARAMETER_4";
	public static final String CANCEL_PARAMETER5 = "PARAMETER_5";
	public static final String CANCEL_PARAMETER6 = "PARAMETER_6";
	public static final String CANCEL_PARAMETER7 = "PARAMETER_7";
	public static final String PAYMENT_METHOD = "PAYMENT_METHOD";
	public static final String PAYMENT_STATUS = "PAYMENT_STATUS";
	public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
	public static final String SUB_COLLECTION_TYPE = "SUB_COLLECTION_TYPE";
	public static final String SUBSCRIBER_EMAIL = "SUBSCRIBER_EMAIL";
	public static final String SUBSCRIBER_MOBILE = "SUBSCRIBER_MOBILE";
	public static final String SUBSCRIBER_NAME = "SUBSCRIBER_NAME";
	public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
	public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
	public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
	public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
	public static final String CANCEL_SUBSCRIBER_NO1 = "SUBSCRIBER_NO_1";
	public static final String CANCEL_SUBSCRIBER_NO2 = "SUBSCRIBER_NO_2";
	public static final String CANCEL_SUBSCRIBER_NO3 = "SUBSCRIBER_NO_3";
	public static final String CANCEL_SUBSCRIBER_NO4 = "SUBSCRIBER_NO_4";
	public static final String SUBSCRIBER_PHONE = "SUBSCRIBER_PHONE";
	public static final String SUBSCRIBER_PIDNO = "SUBSCRIBER_PIDNO";
	public static final String TERM_MONTH = "TERM_MONTH";
	public static final String TERM_YEAR = "TERM_YEAR";
	public static final String ZONE_CODE = "ZONE_CODE";
	public static final String REFERENCE_NO = "REFERENCE_NO";
	public static final String QUERY_REF_NO = "QUERY_REF_NO";

	
	public static final String RESPONSE_CODE = "RESPONSE_CODE";
	public static final String GM_SERVICE_NAME = "GM_SERVICE_NAME";
	public static final String PAYMENT_TYPE = "PAYMENT_TYPE";
	public static final String PAYMENT_TYPE_NAME = "PAYMENT_TYPE_NAME";
	public static final String COLLECTION_TYPE_NAME = "COLLECTION_TYPE_NAME";
	public static final String COMMISION_AMOUNT = "COMMISSION_AMOUNT";
	public static final String BSMV_AMOUNT = "BSMV_AMOUNT";
	public static final String ACCOUNT_NO = "ACCOUNT_NO";
	public static final String WS_SEND_STATUS = "WS_SEND_STATUS";
	public static final String ACCOUNT_CURRENCY_CODE = "ACCOUNT_CURRENCY_CODE";

	public static final String TRX_NO = "TRX_NO";
	public static final String TRX_NAME = "TRX_NAME";
	public static final String WS_SERVICE_NAME = "WS_SERVICE_NAME";
	public static final String FTS_OUTPUT_DATA = "DATA";
	public static final String RECON_COMPARE_TYPE = "RECON_COMPARE_TYPE";
	public static final String RECON_COMPARE_TYPE_NET = "RECON_COMPARE_TYPE_NET";
	public static final String RECON_COMPARE_TYPE_BRUT = "RECON_COMPARE_TYPE_BRUT";
	public static final String RECON_DATE_BEGIN = "RECON_DATE_BEGIN";
	public static final String RECON_DATE = "RECON_DATE";
	public static final String RECON_DATE_END = "RECON_DATE_END";

	public static final String RECON_COLLECTION_TOTAL = "RECON_COLLECTION_TOTAL";
	public static final String RECON_COLLECTION_COUNT = "RECON_COLLECTION_COUNT";
	public static final String RECON_COLLECTION_CANCEL_TOTAL = "RECON_COLLECTION_CANCEL_TOTAL";
	public static final String RECON_COLLECTION_CANCEL_COUNT = "RECON_COLLECTION_CANCEL_COUNT";

	public static final String RECON_COLLECTION_STATUS = "RECON_COLLECTION_STATUS";
	public static final String RECON_COLLECTION_CANCEL_STATUS = "RECON_COLLECTION_CANCEL_STATUS";

	public static final String RECON_STANDINGORDER_COUNT = "RECON_STANDINGORDER_COUNT";
	public static final String RECON_STANDINGORDER_CANCEL_COUNT = "RECON_STANDINGORDER_CANCEL_COUNT";
	public static final String PAYMENT_DATE = "PAYMENT_DATE";
	public static final String IS_MANDATORY_SERVICE = "IS_MANDATORY_SERVICE";
	public static final String INPUT_MAP_STRING = "INPUT_MAP_STRING";
	public static final String RESPONSE_MAP_STRING = "RESPONSE_MAP_STRING";
	public static final String SERVICE_STATUS = "SERVICE_STATUS";
	public static final String STAN_NO = "STAN_NO";
	public static final String WS_ENDPOINT = "WS_ENDPOINT";
	public static final String WS_PASSWORD = "WS_PASSWORD";
	public static final String WS_USER = "WS_USER";
	public static final String ERROR_CODE_SYSTEM = "ERROR_CODE_SYSTEM";
	public static final String COLLECTION_INFO = "COLLECTION_INFO";
	public static final String SERVICE_OID = "SERVICE_OID";
	public static final String CURRENCY_CODE_DEFAULT = "TRY";
	public static final String STANDING_ORDER_STATUS = "STANDING_ORDER_STATUS";
	public static final String IS_STANDING_ORDER_ACTIVE = "IS_STANDING_ORDER_ACTIVE";
	public static final String PROCESS_DATE = "PROCESS_DATE";
	public static final String CORPORATE_BATCH_PROCESS_OID = "CORPORATE_BATCH_PROCESS_OID";
	public static final String BATCH_PROCESS_OID = "BATCH_PROCESS_OID";
	public static final String CORPORATE_LIST = "CORPORATE_LIST";
	public static final String BATCH_NAME = "BATCH_NAME";
	public static final String CORPORATE_OID = "CORPORATE_OID";

	public static final String INVOICE_MAIN_OID = "INVOICE_MAIN_OID";
	public static final String PROCESS_TIME = "PROCESS_TIME";
	public static final String PROCESS_STATUS = "PROCESS_STATUS";
	public static final String RECON_COUNT = "RECON_COUNT";
	public static final String TABLE_SIZE = "TABLE_SIZE";
	public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
	public static final String CANCEL_AMOUNT = "CANCEL_AMOUNT";
	public static final String RECON_STATUS = "RECON_STATUS";

	public static final String RECON_BANK_COUNT = "RECON_BANK_COUNT";
	public static final String RECON_CORPORATE_COUNT = "RECON_CORPORATE_COUNT";
	public static final String RECON_BANK_CANCEL_COUNT = "RECON_BANK_CANCEL_COUNT";
	public static final String RECON_CORPORATE_CANCEL_COUNT = "RECON_CORPORATE_CANCEL_COUNT";
	public static final String RECON_LOG_OID = "RECON_LOG_OID";
	public static final String PROCESS_DEF_ID = "PROCESS_DEF_ID";
	public static final String CHECK_EXEMPTION = "CHECK_EXEMPTION";
	public static final String INVOICE_AMOUNT = "INVOICE_AMOUNT";
	public static final String SOURCE = "SOURCE";
	public static final String CALCULATE_COMMISSION = "CALCULATE_COMMISSION";
	public static final String RECON_CALL = "RECON_CALL";
	public static final String CHANNEL_CODE = "CHANNEL_CODE";
	public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
	public static final String PAYMENT_ACCOUNT_NO = "PAYMENT_ACCOUNT_NO";
	public static final String RECON_CORPORATE_TOTAL = "RECON_CORPORATE_TOTAL";
	public static final String RECON_CORPORATE_CANCEL_TOTAL = "RECON_CORPORATE_CANCEL_TOTAL";
	public static final String WS_PARAMETERS = "WS_PARAMETERS";

	public static final String BATCH_SERVICE_NAME_FOR_RESUBMIT = "BATCH_SERVICE_NAME_FOR_RESUBMIT ";
	public static final String COLLECTION_TYPE_COUNT = "COLLECTION_TYPE_COUNT";
	public static final String RECON_CONNECTION_FEE_TOTAL = "RECON_CONNECTION_FEE_TOTAL";
	public static final String RECON_CONNECTION_FEE_COUNT = "RECON_CONNECTION_FEE_COUNT";
	public static final String RECON_CONNECTION_FEE_CANCEL_TOTAL = "RECON_CONNECTION_FEE_CANCEL_TOTAL";
	public static final String RECON_CONNECTION_FEE_CANCEL_COUNT = "RECON_CONNECTION_FEE_CANCEL_COUNT";
	public static final String ACCOUNT_BALANCE = "ACCOUNT_BALANCE";
	public static final String PAYMENT_SOURCE = "PAYMENT_SOURCE";

	public static final String IS_STANDING_ORDER_COLLECTION = "IS_STANDING_ORDER_COLLECTION";

	public static final String ERROR_PARAMETERS_TABLE = "ERROR_PARAMETERS_TABLE";
	public static final String ERROR_PARAM = "ERROR_PARAM";
	public static final String SESSION_KEY = "SESSION_KEY";
	public static final String SESSION_VALUE = "SESSION_VALUE";
	public static final String TT_RECON_FLAG = "TT_RECON_FLAG";
	public static final String TT_PAYMENT_ERROR_FLAG = "TT_PAYMENT_ERROR_FLAG";

	public static final String USER_CODE = "USER_CODE";
	public static final String AGENT_CODE = "AGENT_CODE";
	public static final String ELIGIBLE_CONSUMER = "ELIGIBLE_CONSUMER";
	public static final String OFFER = "OFFER";
	public static final String ID_NUMBER = "ID_NUMBER";
	public static final String TAX_NUMBER = "TAX_NUMBER";
	public static final String DECLARED_ADDRESS = "DECLARED_ADDRESS";
	public static final String CUSTOMER_ADDRESS = "CUSTOMER_ADDRESS";
	public static final String TAX_OFFICE = "TAX_OFFICE";
	public static final String PHONE = "PHONE";
	public static final String EMAIL = "EMAIL";
	public static final String CAMPAIGN_LIST = "CAMPAIGN_LIST";
	public static final String CAMPAIGN_LIST_DETAIL = "CAMPAIGN_LIST_DETAIL";
	public static final String CAMPAIGN_STATUS_CODE = "CAMPAIGN_STATUS_CODE";
	public static final String CAMPAIGN_STATUS_NAME = "CAMPAIGN_STATUS_NAME";
	public static final String CAMPAIGN_STATUS_DETAIL_CODE = "CAMPAIGN_STATUS_DETAIL_CODE";
	public static final String CAMPAIGN_STATUS_DETAIL_NAME = "CAMPAIGN_STATUS_DETAIL_NAME";
	public static final String CUSTOMER_PERSONAL_NUMBER = "CUSTOMER_PERSONAL_NUMBER";
	public static final String EXPLANATION = "EXPLANATION";
	public static final String MISSING_INFORMATION = "MISSING_INFORMATION";
	public static final String CUSTOMER_TYPE = "CUSTOMER_TYPE";
	public static final String IS_CAMPAIGN_CHANNEL = "IS_CAMPAIGN_CHANNEL";

	public static final String NAME = "NAME";
	public static final String SURNAME = "SURNAME";
	public static final String COMPANY_NAME = "COMPANY_NAME";
	public static final String TERM = "TERM";
	public static final String SUBSCRIBER_GROUP = "SUBSCRIBER_GROUP";
	public static final String PRICE_LIST_GROUP = "PRICE_LIST_GROUP";
	public static final String ELECTRIC_METER_SERIAL_NUMBER = "ELECTRIC_METER_SERIAL_NUMBER";
	public static final String ELECTRIC_METER_BRAND = "ELECTRIC_METER_BRAND";
	public static final String CREDIT_CARD_NO = "CREDIT_CARD_NO";
	public static final String DURATION = "DURATION";
	public static final String END_TIME = "END_TIME";
	public static final String START_TIME = "START_TIME";
	public static final String YIM_CHANNEL = "YIM_CHANNEL";

	

	public static final class Eksws {
		public static final String WS_USER = "WS_USER";
		public static final String WS_PASSWORD = "WS_PASSWORD";
		public static final String CARD_INFO = "CARD_INFO";
		public static final String URL = "URL";
		public static final String RETURN_MESSAGE = "RETURN_MESSAGE";
		public static final String MONEY = "MONEY";
		public static final String TON = "TON";
		public static final String INVOICE_SERIAL = "INVOICE_SERIAL";
		public static final String DEBT_NO = "DEBT_NO";
		public static final String WS_ENDPOINT = "WS_ENDPOINT";
		public static final String ACCURED_NUMBER = "ACCURED_NUMBER";
		public static final String RECEIPT_SERIAL = "RECEIPT_SERIAL";
		public static final String RECEIPT_NO = "RECEIPT_NO";
		
		public static final String PARAMETER1 = "PARAMETER1";
		public static final String PARAMETER2 = "PARAMETER2";
		public static final String PARAMETER3 = "PARAMETER3";
		public static final String PARAMETER4 = "PARAMETER4";
		public static final String PARAMETER5 = "PARAMETER5";
		public static final String PARAMETER6 = "PARAMETER6";
		

	}

}