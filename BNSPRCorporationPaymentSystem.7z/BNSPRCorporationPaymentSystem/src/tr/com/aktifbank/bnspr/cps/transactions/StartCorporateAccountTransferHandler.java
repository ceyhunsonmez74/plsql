package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CorporateAccountTransferInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.implementations.AccountTransferImplementation;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class StartCorporateAccountTransferHandler extends RequestHandler {

	public StartCorporateAccountTransferHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		CorporateAccountTransferInformation information = new CorporateAccountTransferInformation();
		
		List<CorporateBatchProcess> batchList = super.getHibernateSession().createCriteria(CorporateBatchProcess.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("batchName", input.getString("BATCH_NAME")))
				.addOrder(Order.asc("oid"))
				.list();
		
		Date inputDate = input.getDate("INPUT_DATE", CommonHelper.addDay(new Date(), -1));
		String fromAccountType = input.getString("FROM_ACCOUNT_TYPE", null);
		Date processDate = input.getDate("PROCESS_DATE", CommonHelper.addDay(inputDate, 1));
		
		for (CorporateBatchProcess process : batchList) {
			try {
				GMMap calculateTransferDatesRequest = new GMMap();
				calculateTransferDatesRequest.put(TransactionConstants.CalculateTransferDates.Input.COLLECTION_DATE, inputDate);
				calculateTransferDatesRequest.put(TransactionConstants.CalculateTransferDates.Input.CORPORATE_CODE, process.getCorporateCode());
				calculateTransferDatesRequest.put(TransactionConstants.CalculateTransferDates.Input.TRANSFER_TYPE, input.getString("TRANSFER_TYPE"));
				if(!StringUtil.isEmpty(fromAccountType)){
					calculateTransferDatesRequest.put("FROM_ACCOUNT_TYPE", fromAccountType);
				}
				super.callGraymoundServiceOutsideSession(TransactionConstants.CalculateTransferDates.SERVICE_NAME, calculateTransferDatesRequest);
				information.addToCorporates(process.getCorporateCode());
			} catch (Exception e) {
				logger.error(String.format("An exception occured while calculating dates for corporate with %s code", process.getCorporateCode()));
				logger.error(System.currentTimeMillis(), e);
			}
		}
		
		information.setParallelLoopCount(5);
		information.setProcessDate(processDate);
		information.setServiceName(TransactionConstants.TransferCorporateAccount.SERVICE_NAME);
		information.setTransferType(input.getString("TRANSFER_TYPE"));
		information.setFromAccountType(fromAccountType);
		
		AccountTransferImplementation implementation = new AccountTransferImplementation(information);
		implementation.execute();
	}

}
