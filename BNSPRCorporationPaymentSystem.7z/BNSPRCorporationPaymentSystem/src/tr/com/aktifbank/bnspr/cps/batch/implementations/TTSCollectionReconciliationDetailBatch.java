package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.cps.dto.TTSReconciliationDetail;
import tr.com.aktifbank.bnspr.dao.invoicePayment;

import com.graymound.util.GMMap;

public class TTSCollectionReconciliationDetailBatch extends CollectionReconciliationDetailBatch{

	private static final Log logger = LogFactory.getLog(TTSCollectionReconciliationDetailBatch.class);
	
	
	List<TTSReconciliationDetail> details;
	Map<String, TTSReconciliationDetail> indexedCorporateRecords;
	
	public TTSCollectionReconciliationDetailBatch(GMMap input, List<TTSReconciliationDetail> details) {
		super(input);
		this.details = details;
		indexedCorporateRecords = new HashMap<String, TTSReconciliationDetail>();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put("SUBSCRIBER_NO_1", details.get(corporateRecordIndex).getServiceNo());
		collectionDetailRequest.put(MapKeys.PAYMENT_DATE, details.get(corporateRecordIndex).getPaymentDate());
		collectionDetailRequest.put(MapKeys.PAYMENT_AMOUNT, details.get(corporateRecordIndex).getCollectionAmount());
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getInvoiceNo());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put("SUBSCRIBER_NO_1", details.get(corporateRecordIndex).getServiceNo());
		cancelCollectionRequest.put(MapKeys.PAYMENT_DATE, details.get(corporateRecordIndex).getPaymentDate());
		cancelCollectionRequest.put(MapKeys.PAYMENT_AMOUNT, details.get(corporateRecordIndex).getCollectionAmount());
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getInvoiceNo());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		TTSReconciliationDetail ttsReconciliationDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Voucher No : %s, Reference No : %s, Subscriber No : %s, Amount : %s ", 
				ttsReconciliationDetail.getInvoiceNo(), 
				ttsReconciliationDetail.getPaymentDate(), 
				ttsReconciliationDetail.getServiceNo(), 
				ttsReconciliationDetail.getStan()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		
		List<String> corpCodeList = new ArrayList<String>();
		String corpCode = input.getString(MapKeys.CORPORATE_CODE);
		if( corpCode.contains(",") ){
			
			String []corpCodes = corpCode.split(",");
			corpCode = corpCodes[0].toString();
			corpCodeList.add(corpCodes[0]);
			corpCodeList.add(corpCodes[1]);
			payment.setCorporateCode(corpCode);
		}
		else{
			corpCodeList.add(corpCode);
			payment.setCorporateCode(corpCode);
		}
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(ttsReconciliationDetail.getServiceNo());
		payment.setStanNo(ttsReconciliationDetail.getStan());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal(ttsReconciliationDetail.getStan()));
		payment.setInvoiceAmount(ttsReconciliationDetail.getCollectionAmount());
		payment.setPaymentAmount(ttsReconciliationDetail.getCollectionAmount());
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		Session session = CommonHelper.getHibernateSession();
//		List<OnlineServiceLog> resultLogList = session.createCriteria(OnlineServiceLog.class).add
//								(Restrictions.in("corporateCode", corpCodeList)).add
//								(Restrictions.ilike("inputMap", ttsReconciliationDetail.getStan(),MatchMode.ANYWHERE)).add
//								(Restrictions.eq("wsServiceName", "ICS_TTS_DO_INVOICE_COLLECTION")).setMaxResults
//								(5).list();
		
//		if( null != resultLogList ){
//			for(OnlineServiceLog log : resultLogList ){
//				if( log.getInputMap().)
//			}
//		}
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, ttsReconciliationDetail.getServiceNo());
		collectionDetailResponse.put(MapKeys.STAN_NO, ttsReconciliationDetail.getStan());
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, ttsReconciliationDetail.getCollectionAmount());
		collectionDetailResponse.put(MapKeys.CORPORATE_CODE, corpCode);
	}


	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
//		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.SUBSCRIBER_NO1)) || this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.PARAMETER7)) ;
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.STAN_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		result.setSuccessfulCall(true);
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int bankRecordSize = super.getBankRecordSize();
		for (int i = 0; i < bankRecordSize; i++) {
			GMMap currentRecord = super.getBankRecordAtIndex(i);
			super.setBankRecordIndex(currentRecord.getString(MapKeys.STAN_NO), currentRecord);
//			super.setBankRecordIndex(currentRecord.getString(MapKeys.PARAMETER_7), currentRecord);
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (TTSReconciliationDetail detail : this.details) {
			this.indexedCorporateRecords.put(detail.getStan(), detail);
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getStan());
	}

}
