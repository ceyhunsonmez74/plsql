package tr.com.aktifbank.bnspr.cps.common;

public final class TransactionConstants {
	public static final class FtmBatchStarter {
		public static final class Input {
			public static final String FTM_ID = "FILE_DEF_ID";
			public static final String FTM_TRANSFER_ID = "PROCESS_ID";
		}

		public static final class Output {
			public static final String SUBMIT_ID = "SUBMIT_ID";
		}

		public static final String SERVICE_NAME = "ICS_FTM_BATCH_STARTER";
	}

	public static final class BatchFileReporter {
		public static final String SERVICE_NAME = "CDM_NOTIFY_BATCH_FILE_REPORTER";

		public static final class Input {
			public static final String BATCH_NAME = "BATCH_NAME";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String DURATION = "DURATION";
			public static final String NOTIFICATION_SUBJECT = "SUBJECT";
			public static final String NOTIFICATION_FROM = "FROM";
			public static final String NOTIFICATION_TO = "TO";
			public static final String NOTIFICATION_CC = "CC";
		}

		public static final class Output {

		}
	}

	public static final class InsertBatchSubmitLog {
		public static final String SERVICE_NAME = "ICS_INSERT_BATCH_SUBMIT_LOG";

		public static final class Input {
			public static final String BATCH_NAME = "BATCH_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SUBMIT_STATUS = "SUBMIT_STATUS";
			public static final String SUBMIT_USER = "SUBMIT_USER";
			public static final String SUBMIT_DATE = "SUBMIT_DATE";
			public static final String PARAMETERS = "PARAMETERS";
			public static final String SUBMIT_ID = "SUBMIT_ID";
			public static final String IS_UPDATE = "IS_UPDATE";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_DESCRIPTION = "ERROR_DESCRIPTION";
			public static final String START_TIME = "START_TIME";
			public static final String END_TIME = "END_TIME";
		}

		public static final class Output {

		}
	}

	public static final class GetBatchDetail {
		public static final String SERVICE_NAME = "ICS_GET_CORPORATE_BATCH_DETAIL";

		public static final class Input {
			public static final String BATCH_NAME = "BATCH_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}

		public static final class Output {
			public static final String BATCH_OID = "BATCH_OID";
			public static final String SERVICE_NAME = "SERVICE_NAME";
			public static final String THREAD_COUNT = "THREAD_COUNT";
			public static final String COMMIT_COUNT = "COMMIT_COUNT";
			public static final String THRESHOLD = "THRESHOLD";
			public static final String CORPORATE_BATCH_PROCESS_OID = "CORPORATE_BATCH_PROCESS_OID";
		}
	}

	public static final class GetBatchParameters {
		public static final String SERVICE_NAME = "ICS_GET_CORPORATE_BATCH_PARAMETERS";

		public static final class Input {
			public static final String CORPORATE_BATCH_PROCESS_OID = "CORPORATE_BATCH_PROCESS_OID";
		}

		public static final class Output {
			public static final String COMPOSED_PARAMETERS = "COMPOSED_PARAMETERS";
		}
	}

	public static final class GetCorporateDefinition {
		public static final String SERVICE_NAME = "CDM_GET_CORPORATE_DEFINITION";

		public static final class Inputs {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String THROWS_EXCEPTION = "THROWS_EXCEPTION";
			public static final String GET_CHANNEL_DEFINITIONS = "GET_CHANNEL_DEFINITIONS";
		}

		public static final class Output {
			public static final String CORPORATE_ACTIVENESS = "CORPORATE_ACTIVENESS";
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String IS_ONLINE_CORPORATE = "IS_ONLINE_CORPORATE";
			public static final String BANK_CODE = "BANK_CODE";
			public static final String ALLOW_PART_AFTER_DUE = "ALLOW_PART_AFTER_DUE";
			public static final String RESULT = "RESULT";
			public static final String CHANNELS = "CHANNELS";
			public static final String CHANNEL_ID = "CHANNEL_ID";
			public static final String ALLOW_PART_PAYMENT = "ALLOW_PART_PAYMENT";
			public static final String SECTOR_CODE = "SECTOR_CODE";
			public static final String ALLOW_AFTER_DUE = "ALLOW_AFTER_DUE";
			public static final String SHORT_CODE = "SHORT_CODE";
			public static final String CUSTOMER_NUMBER = "CUSTOMER_NUMBER";
		}
	}

	public static final class GeneralBatchSubmit {
		public static final class Input {
			public static final String BATCH_NAME = "BATCH_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";
			public static final String THREAD_COUNT = "THREAD_COUNT";
			public static final String COMMIT_COUNT = "COMMIT_COUNT";
			public static final String FTM_ID = "FTM_ID";
			public static final String SUBMIT_ID = "SUBMIT_ID";
			public static final String FORMAT_OID = "FORMAT_OID";
			public static final String PARAMETERS = "PARAMETERS";
			public static final String THRESHOLD = "THRESHOLD";
		}
	}

	public static final class InvoiceDebtLoading {
		public static final String SERVICE_NAME = "ICS_BATCH_INVOICE_DEBT_LOADING";
	}

	public static final class GetFileHeaderFormat {
		public static final String SERVICE_NAME = "CDM_GET_CORPORATE_FILE_FORMAT_HEADER";

		public static final class Input {
			public static final String FORMAT_ID = TransactionConstants.FORMAT_ID_GENERAL_KEY;
		}

		public static final class Output {
			public static final String HEADER_FORMATS = "HEADER_FORMATS";

		}
	}

	public static final class GetFileDetailFormat {
		public static final String SERVICE_NAME = "CDM_GET_CORPORATE_FILE_FORMAT_DETAIL";

		public static final class Input {
			public static final String FORMAT_ID = TransactionConstants.FORMAT_ID_GENERAL_KEY;
		}

		public static final class Output {
			public static final String DETAIL_FORMAT = "DETAIL_FORMAT";
		}
	}

	public static final class GetFileFooterFormat {
		public static final String SERVICE_NAME = "CDM_GET_CORPORATE_FILE_FORMAT_FOOTER";

		public static final class Input {
			public static final String FORMAT_ID = TransactionConstants.FORMAT_ID_GENERAL_KEY;
		}

		public static final class Output {
			public static final String FOOTER_FORMATS = "FOOTER_FORMATS";
		}
	}

	public static final class DeleteWaitedInvoice {
		public static final String SERVICE_NAME = "ICS_DELETE_WAITED_INVOICE";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";

		}

		public static final class Output {

		}
	}

	public static final class InsertInvoice {
		public static final String SERVICE_NAME = "ICS_INSERT_INVOICE";

		public static final class Input {
			public static final String DIRECT_INSERT = TransactionConstants.DIRECT_INSERT_GENERAL_KEY;
			public static final String INSERT_KEYVALUE_PAIRS = TransactionConstants.INSERT_KEYVALUE_PAIRS_GENERAL_KEY;
			public static final String INSERT_PAIR_TABLE = TransactionConstants.INSERT_PAIR_TABLE_GENERAL_KEY;
			public static final String CORPORATE_CODE = CORPORATE_CODE_GENERAL_KEY;
			public static final String FTM_TRANSFER_ID = FTM_TRANSFER_ID_GENERAL_KEY;
			public static final String SUBMIT_ID = SUBMIT_ID__GENERAL_KEY;
			public static final String CONTROL_INVOICE_NO = CONTROL_INVOICE_NO_GENERAL_KEY;
			public static final String CONTROL_INVOICE_DUE_DATE = CONTROL_INVOICE_DUE_DATE_GENERAL_KEY;
		}

		public static final class Output {
			public static final String RETURN_CODE = RETURN_CODE_GENERAL_KEY;
			public static final String RETURN_MESSAGE = RETURN_MESSAGE_GENERAL_KEY;
		}
	}

	public static final class ProcessInvoiceWithCommand {
		public static final String SERVICE_NAME = "ICS_PROCESS_INVOICE_WITH_COMMAND";

		public static final class Input {
			public static final String DIRECT_INSERT = TransactionConstants.DIRECT_INSERT_GENERAL_KEY;
			public static final String INSERT_KEYVALUE_PAIRS = TransactionConstants.INSERT_KEYVALUE_PAIRS_GENERAL_KEY;
			public static final String INSERT_PAIR_TABLE = TransactionConstants.INSERT_PAIR_TABLE_GENERAL_KEY;
			public static final String CORPORATE_CODE = CORPORATE_CODE_GENERAL_KEY;
			public static final String FTM_TRANSFER_ID = FTM_TRANSFER_ID_GENERAL_KEY;
			public static final String SUBMIT_ID = SUBMIT_ID__GENERAL_KEY;
			public static final String CONTROL_INVOICE_NO = CONTROL_INVOICE_NO_GENERAL_KEY;
			public static final String CONTROL_INVOICE_DUE_DATE = CONTROL_INVOICE_DUE_DATE_GENERAL_KEY;
			public static final String COMMAND = COMMAND_GENERAL_KEY;
		}

		public static final class Output {
			public static final String RETURN_CODE = RETURN_CODE_GENERAL_KEY;
			public static final String RETURN_MESSAGE = RETURN_MESSAGE_GENERAL_KEY;
		}
	}

	public static final class InsertStandingOrderInvoice {
		public static final String SERVICE_NAME = "ICS_INSERT_INVOICE_WITH_STANDING_ORDER";

		public static final class Input {
			public static final String DIRECT_INSERT = TransactionConstants.DIRECT_INSERT_GENERAL_KEY;
			public static final String INSERT_KEYVALUE_PAIRS = TransactionConstants.INSERT_KEYVALUE_PAIRS_GENERAL_KEY;
			public static final String INSERT_PAIR_TABLE = TransactionConstants.INSERT_PAIR_TABLE_GENERAL_KEY;
			public static final String CORPORATE_CODE = CORPORATE_CODE_GENERAL_KEY;
			public static final String FTM_TRANSFER_ID = FTM_TRANSFER_ID_GENERAL_KEY;
			public static final String SUBMIT_ID = SUBMIT_ID__GENERAL_KEY;
			public static final String CONTROL_INVOICE_NO = CONTROL_INVOICE_NO_GENERAL_KEY;
			public static final String LOAD_ONLY_WITH_STANDING_ORDER = LOAD_ONLY_WITH_STANDING_ORDER_GENERAL_KEY;
			public static final String CONTROL_INVOICE_DUE_DATE = CONTROL_INVOICE_DUE_DATE_GENERAL_KEY;
		}

		public static final class Output {
			public static final String RETURN_CODE = RETURN_CODE_GENERAL_KEY;
			public static final String RETURN_MESSAGE = RETURN_MESSAGE_GENERAL_KEY;
		}
	}

	public static final class DebtInquiry {
		public static final String SERVICE_NAME = "ICS_INVOICE_DEBT_INQUIRY";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
		}

		public static final class Output {
			public static final String OUTPUT_MAP = "OUTPUT_MAP";
		}
	}

	public static final class DoInvoiceCollection {
		public static final String SERVICE_NAME = "ICS_DO_INVOICE_COLLECTION";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SOURCE = "SOURCE";
			public static final String COLLECTION_TYPE_NAME = "COLLECTION_TYPE_NAME";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String TRX_NO = "TRX_NO";
			public static final String INVOICE_MAIN_OID = "INVOICE_MAIN_OID";
			public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
			public static final String PAYMENT_ACCOUNT_NO = "PAYMENT_ACCOUNT_NO";
			public static final String IBAN_NO = "IBAN_NO";
			public static final String ACCOUNT_BALANCE = "ACCOUNT_BALANCE";
			public static final String PAYMENT_CARD_NO = "PAYMENT_CARD_NO";
			public static final String COMMISSION_AMOUNT = "COMMISSION_AMOUNT";
			public static final String BRANCH_CODE = "BRANCH_CODE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String CUSTOMER_PHONE = "CUSTOMER_PHONE";
			public static final String CUSTOMER_ID_NO = "CUSTOMER_ID_NO";
			public static final String CUSTOMER_TAX_NO = "CUSTOMER_TAX_NO";
			public static final String ACCOUNT_CURRENCY_CODE = "ACCOUNT_CURRENCY_CODE";
			public static final String SUBSCRIBER_NAME = "SUBSCRIBER_NAME";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
			public static final String INVOICE_NO = "INVOICE_NO";
			public static final String INVOICE_AMOUNT = "INVOICE_AMOUNT";
			public static final String INSTALLMENT_NO = "INSTALLMENT_NO";
			public static final String TERM_MONTH = "TERM_MONTH";
			public static final String TERM_YEAR = "TERM_YEAR";
			public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE";
			public static final String SUB_COLLECTION_TYPE = "SUB_COLLECTION_TYPE";
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String INVOICE_DATE = "INVOICE_DATE";
			public static final String PARAMETER1 = "PARAMETER1";
			public static final String PARAMETER2 = "PARAMETER2";
			public static final String PARAMETER3 = "PARAMETER3";
			public static final String PARAMETER4 = "PARAMETER4";
			public static final String PARAMETER5 = "PARAMETER5";
			public static final String PARAMETER6 = "PARAMETER6";
			public static final String PARAMETER7 = "PARAMETER7";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String CALCULATE_COMMISSION = "CALCULATE_COMMISSION";
			public static final String ACCOUNT_AVAILABLE_BALANCE = "ACCOUNT_AVAILABLE_BALANCE";
			public static final String PAYER_NAME = "PAYER_NAME";
			public static final String QUERY_REF_NO = "QUERY_REF_NO";
		}

		public static final class Output {
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
		}
	}

	public static final class CancelInvoicePayment {
		public static final String SERVICE_NAME = "ICS_INVOICE_COLLECTION_CANCEL";

		public static final class Input {
			public static final String TRX_NO = MapKeys.TRX_NO;
			public static final String INVOICE_MAIN_OID = "INVOICE_MAIN_OID";
			public static final String INVOICE_PAYMENT_OID = "INVOICE_PAYMENT_OID";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String COLLECTION_TYPE_NAME = "COLLECTION_TYPE_NAME";
			public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
			public static final String AMOUNT = "AMOUNT";
			public static final String PAYMENT_ACCOUNT_NO = "PAYMENT_ACCOUNT_NO";
			public static final String PAYMENT_DATE = "PAYMENT_DATE";
			public static final String IBAN_NO = "IBAN_NO";
			public static final String ACCOUNT_BALANCE = "ACCOUNT_BALANCE";
			public static final String PAYMENT_CARD_NO = "PAYMENT_CARD_NO";
			public static final String CORPORATE_ACCOUNT_NO = "CORPORATE_ACCOUNT_NO";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String BRANCH_CODE = "BRANCH_CODE";
			public static final String PAYMENT_SOURCE = "PAYMENT_SOURCE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String CUSTOMER_PHONE = "CUSTOMER_PHONE";
			public static final String CUSTOMER_ID_NO = "CUSTOMER_ID_NO";
			public static final String CUSTOMER_TAX_NO = "CUSTOMER_TAX_NO";
			public static final String INVOICE_NO = "INVOICE_NO";
			public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE";
			public static final String INVOICE_DATE = "INVOICE_DATE";
			public static final String ACCOUNT_CURRENCY_CODE = "ACCOUNT_CURRENCY_CODE";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
			public static final String PARAMETER1 = "PARAMETER1";
			public static final String PARAMETER2 = "PARAMETER2";
			public static final String PARAMETER3 = "PARAMETER3";
			public static final String PARAMETER4 = "PARAMETER4";
			public static final String PARAMETER5 = "PARAMETER5";
			public static final String PARAMETER6 = "PARAMETER6";
			public static final String PARAMETER7 = "PARAMETER7";
			public static final String REJECTED_REASON_CODE = "REJECTED_REASON_CODE";
			public static final String REJECTED_REASON = "REJECTED_REASON";
		}

		public static final class Output {

		}
	}

	public static final class CorporateChannelWorkingHourControl {
		public static final String SERVICE_NAME = "CDM_CORPORATE_CHANNEL_WORKINGHOUR_CONTROL";

		public static final class Input {
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String SOURCE_CODE = "SOURCE_CODE";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String DATE = "DATE";
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}

		public static final class Output {
			public static final String RESULT = "RESULT";
		}
	}

	public static final class CorporateAccountControl {
		public static final String SERVICE_NAME = "CDM_CORPORATE_ACCOUNT_CONTROL";

		public static final class Input {
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String SOURCE_CODE = "SOURCE_CODE";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
		}

		public static final class Output {
			public static final String RESULT = "RESULT";
			public static final String ACCOUNT_NO = "ACCOUNT_NO";
		}
	}

	public static final class GetCorporateServiceBoundGmService {
		public static final String SERVICE_NAME = "CDM_GET_CORPORATE_SERVICE_BOUND_GMSERVICE";

		public static final class Input {
			public static final String GM_SERVICE_NAME = "GM_SERVICE_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}

		public static final class Output {
			public static final String WEB_SERVICE_NAME = "WEB_SERVICE_NAME";
			public static final String IS_SAF = "IS_SAF";
			public static final String CORPORATE_SERVICE_NAME = "CORPORATE_SERVICE_NAME";
		}
	}

	public static final class CalculateCommission {
		public static final String SERVICE_NAME = "ICS_CALCULATE_COMMISSION";

		public static final class Input {
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
			public static final String CHECK_EXEMPTION = MapKeys.CHECK_EXEMPTION;// 1
																					// or
																					// 0,
																					// if
																					// 1
																					// then
																					// CUSTOMER_NO
																					// or
																					// ACCOUNT_NO
																					// should
																					// be
																					// not
																					// null.
			public static final String CUSTOMER_NO = MapKeys.CUSTOMER_NO; // optional
			public static final String ACCOUNT_NO = MapKeys.ACCOUNT_NO;// optional
			public static final String PROCESS_DEF_ID = MapKeys.PROCESS_DEF_ID;// optional
		}

		public static final class Output {
			public static final String COMMISSION_AMOUNT = "COMMISSION_AMOUNT";
			public static final String BSMV_AMOUNT = "BSMV_AMOUNT";
			public static final String TOTAL_AMOUNT = "TOTAL_AMOUNT";
		}
	}

	public static final class GetCommissionDef {
		public static final String SERVICE_NAME = "CDM_GET_CORPORATE_COMMISSION_DEF";

		public static final class Input {
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}

		public static final class Output {
			public static final String COMMISSION = "COMMISSION";
			public static final String COMMISSION_TYPE = "COMMISSION_TYPE";
			public static final String CUSTOMER_EXEMPTION = "CUSTOMER_EXEMPTION";
			public static final String GROUP_EXEMPTION = "GROUP_EXEMPTION";
			public static final String SEGMENT_EXEMPTION = "SEGMENT_EXEMPTION";
			public static final String ACCOUNT_EXEMPTION = "ACCOUNT_EXEMPTION";
			public static final String BSMV = "BSMV";
		}
	}

	public static final class DebtLineParser {
		public static final String SERVICE_NAME = "ICS_DEBT_LINE_PARSER";

		public static final class SharedAspectKeys {
			public static final String ERROR_COUNTER = "ERROR_COUNTER";
		}

		public static final class Input {
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";
			public static final String START_LINE_NUMBER = "START_LINE_NUMBER";
			public static final String END_LINE_NUMBER = "END_LINE_NUMBER";
			public static final String DATABASE_FIELD_MAPS = "DATABASE_FIELD_MAPS";
			public static final String SERVICE_FIELD_MAPS = "SERVICEC_FIELD_MAPS";
			public static final String HEADER_FORMAT_DETAILS = "HEADER_FORMAT_DETAILS";
			public static final String DETAIL_FORMAT_DETAILS = "DETAIL_FORMAT_DETAILS";
			public static final String FOOTER_FORMAT_DETAILS = "FOOTER_FORMAT_DETAILS";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String COMMIT_COUNT = "COMMIT_COUNT";
			public static final String ERROR_THRESHOLD = "ERROR_THRESHOLD";
			public static final String FTM_ID = "FTM_ID";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String SERVICE_NAME = "SERVICE_NAME";
			public static final String CONTROL_LOOP_COUNT = "CONTROL_LOOP_COUNT";
			public static final String CONTROL_INVOICE_NO = "CONTROL_INVOICE_NO";
			public static final String LOAD_ONLY_WITH_STANDING_ORDER = "LOAD_ONLY_WITH_STANDING_ORDER";
			public static final String CONTROL_INVOICE_DUE_DATE = "CONTROL_INVOICE_DUE_DATE";
		}

		public static final class Output {
			public static final String ISSUCCESSFUL = "ISSUCCESSFUL";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
			public static final String INFORMATION = "INFORMATION";
			public static final String PROCESSED_AMOUNT = "PROCESSED_AMOUNT";
			public static final String PROCESSED_LINE_COUNT = "PROCESSED_LINE_COUNT";
			public static final String FOOTER_AMOUNT = "FOOTER_AMOUNT";
			public static final String FOOTER_LINE_COUNT = "FOOTER_LINE_COUNT";
		}
	}

	public static final class InsertFileErrorLog {
		public static final String SERVICE_NAME = "ICS_INSERT_FILE_ERROR_LOG";

		public static final class Input {
			public static final String FTM_ID = "FTM_ID";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";
			public static final String LINE_NUMBER = "LINE_NUMBER";
			public static final String LINE = "LINE";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
		}

		public static final class Output {

		}
	}

	public static final class GetSectorDefinition {
		public static final String SERVICE_NAME = "CDM_COMMON_GET_SECTOR_DEFINITION";

		public static final class Input {
			public static final String SECTOR_OID = "SECTOR_OID";
			public static final String SECTOR_CODE = "SECTOR_CODE";
		}

		public static final class Output {
			public static final String STATUS = "STATUS";
			public static final String SECTOR_NAME = "SECTOR_NAME";
			public static final String IS_SECTOR_ACTIVE = "IS_SECTOR_ACTIVE";
			public static final String SECTOR_CODE = "SECTOR_CODE";
			public static final String SECTOR_OID = "SECTOR_OID";
		}
	}

	public static final class ControlSectorActiveness {
		public static final String SERVICE_NAME = "CDM_COMMON_CONTROL_SECTOR_ACTIVENESS";

		public static final class Input {
			public static final String SECTOR_OID = "SECTOR_OID";
			public static final String SECTOR_CODE = "SECTOR_CODE";
		}

		public static final class Output {

			public static final String RESULT = "RESULT";
		}
	}

	public static final class ControlCollectionAmount {
		public static final String SERVICE_NAME = "ICS_INVOICE_COLLECTION_AMOUNT_CONTROL";

		public static final class Input {
			public static final String INVOICE_MASTER_OID = "INVOICE_MASTER_OID";
			public static final String COLLECTION_AMOUNT = "COLLECTION_AMOUNT";
			public static final String THROWS_EXCEPTION = "THROWS_EXCEPTION";
			public static final String AMOUNT = "AMOUNT";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}

		public static final class Output {

			public static final String RESULT = "RESULT";
		}
	}

	public static final class ControlDueDate {
		public static final String SERVICE_NAME = "ICS_INVOICE_DUE_DATE_CONTROL";

		public static final class Input {
			public static final String THROWS_EXCEPTION = "THROWS_EXCEPTION";
			public static final String CURRENT_DATE = "CURRENT_DATE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE";
		}

		public static final class Output {

			public static final String RESULT = "RESULT";
		}
	}

	public static final class ControlInvoiceCollection {
		public static final String SERVICE_NAME = "ICS_CONTROL_INVOICE_COLLECTION";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SOURCE = "SOURCE";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE";
			public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String AMOUNT = "AMOUNT";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
		}

		public static final class Output {

			public static final String ACCOUNT_NO = "ACCOUNT_NO";

		}
	}

	public static final class ControlSubscriberMetaData {
		public static final String SERVICE_NAME = "ICS_CONTROL_SUBSCRIBER_META_DATA";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
		}

		public static final class Output {
			public static final String SUBSCRIBER_NO_LIST = "SUBSCRIBER_NO_LIST";
		}
	}

	public static final class ParallelCall {
		public static final class Input {
			public static final String T_SERVICE_NAME = "T_SERVICE_NAME";
			public static final String T_TASKS = "T_TASKS";
			public static final String T_TASK_INDEX = "T_TASK_INDEX";
		}

		public static final class Output {
			public static final String T_SERVICE_NAME = "T_SERVICE_NAME";
			public static final String T_TASK_INDEX = "T_TASK_INDEX";
			public static final String T_SUCCESSFUL = "T_SUCCESSFUL";
			public static final String T_RESULTS = "T_RESULTS";
		}
	}

	public static final class InformInvoiceCollectionStarter {
		public static final String SERVICE_NAME = "ICS_INFORM_INVOICE_COLLECTION_STARTER";

		public static final class Input {
			public static final String DATE = INFORM_BATCH_DATE_GENERAL_KEY;
			public static final String CORPORATE_CODE = INFORM_BATCH_CORPORATE_CODE_GENERAL_KEY;
			public static final String INDICATOR = INFORM_BATCH_INDICATOR_GENERAL_KEY;
		}

		public static final class Output {

			public static final String RESULT = INFORM_BATCH_RESPONSE_RESULT_GENERAL_KEY;
			public static final String ERROR_CODE = INFORM_BATCH_RESPONSE_ERROR_CODE_GENERAL_KEY;
			public static final String ERROR_MESSAGE = INFORM_BATCH_RESPONSE_ERROR_MESSAGE_GENERAL_KEY;

		}
	}

	public static final class InformStandingOrdersStarter {
		public static final String SERVICE_NAME = "ICS_INFORM_STANDING_ORDERS_STARTER";

		public static final class Input {
			public static final String DATE = INFORM_BATCH_DATE_GENERAL_KEY;
			public static final String CORPORATE_CODE = INFORM_BATCH_CORPORATE_CODE_GENERAL_KEY;
			public static final String INDICATOR = INFORM_BATCH_INDICATOR_GENERAL_KEY;
		}

		public static final class Output {

			public static final String RESULT = INFORM_BATCH_RESPONSE_RESULT_GENERAL_KEY;
			public static final String ERROR_CODE = INFORM_BATCH_RESPONSE_ERROR_CODE_GENERAL_KEY;
			public static final String ERROR_MESSAGE = INFORM_BATCH_RESPONSE_ERROR_MESSAGE_GENERAL_KEY;

		}
	}

	public static final class InformStandingOrdersCancelStarter {
		public static final String SERVICE_NAME = "ICS_INFORM_STANDING_ORDERS_CANCEL_STARTER";

		public static final class Input {
			public static final String DATE = INFORM_BATCH_DATE_GENERAL_KEY;
			public static final String CORPORATE_CODE = INFORM_BATCH_CORPORATE_CODE_GENERAL_KEY;
			public static final String INDICATOR = INFORM_BATCH_INDICATOR_GENERAL_KEY;
		}

		public static final class Output {

			public static final String RESULT = INFORM_BATCH_RESPONSE_RESULT_GENERAL_KEY;
			public static final String ERROR_CODE = INFORM_BATCH_RESPONSE_ERROR_CODE_GENERAL_KEY;
			public static final String ERROR_MESSAGE = INFORM_BATCH_RESPONSE_ERROR_MESSAGE_GENERAL_KEY;

		}
	}

	public static final class StartCorporateBatch {
		public static final String SERVICE_NAME = "ICS_CORPORATE_BATCH_STARTER";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String FTM_ID = "FTM_ID";
			public static final String FORMAT_ID = "FORMAT_ID";
			public static final String BATCH_NAME = "BATCH_NAME";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String INFORM_INDICATOR = "INFORM_INDICATOR";
			public static final String FILE_TRANSFER_ID = "FILE_TRANSFER_ID";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
		}

		public static final class Output {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String RESULT = "RESULT";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
		}
	}

	public static final class CorporateGeneralBatchSubmit {
		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String HEADER_DETAILS = "HEADER_DETAILS";
			public static final String BODY_DETAILS = "BODY_DETAILS";
			public static final String FOOTER_DETAILS = "FOOTER_DETAILS";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String FTM_PROCESS_ID = "FTM_PROCESS_ID";
			public static final String DATABASE_FIELDS = "DATABASE_FIELDS";
			public static final String SERVICE_FIELDS = "SERVICE_FIELDS";
			public static final String BATCH_PARAMETERS = "BATCH_PARAMETERS";
			public static final String INFORM_INDICATOR = "INFORM_INDICATOR";
			public static final String LINE_NUMBER = "LINE_NUMBER";
			public static final String BATCH_INPUT = "BATCH_INPUT";
		}

		public static final class Output {
			public static final String RESULT = "RESULT";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
			public static final String AFTER_PROCESS_LINE_NUMBER = "AFTER_PROCESS_LINE_NUMBER";
		}
	}

	public static final class GetDatabaseFields {
		public static final String SERVICE_NAME = "CDM_COMMON_GET_DATABASE_FIELDS";

		public static final class Input {
			public static final String GET_ALL_FIELDS = "GET_ALL_FIELDS";
		}

		public static final class Output {
			public static final String FIELDS = "FIELDS";
		}
	}

	public static final class GetServiceFields {
		public static final String SERVICE_NAME = "CDM_COMMON_GET_SERVICE_FIELDS";

		public static final class Input {
			public static final String GET_ALL_FIELDS = "GET_ALL_FIELDS";
		}

		public static final class Output {
			public static final String FIELDS = "FIELDS";
		}
	}

	public static final class GetCorporateChannelDefinitions {
		public static final String SERVICE_NAME = "CDM_COMMON_GET_CORPORATE_CHANNEL_DEFINITIONS";

		public static final class Input {
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}

		public static final class Output {
			public static final String CHANNEL_TABLE = "CHANNEL_TABLE";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String SOURCE_CODE = "SOURCE_CODE";
			public static final String EXPLANATION = "EXPLANATION";
		}
	}

	public static final class GetCorporates {
		public static final String SERVICE_NAME = "CDM_GET_CORPORATES";

		public static final class Inputs {
			public static final String SECTOR_CODE = "SECTOR_CODE";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String ACTIVENESS = "ACTIVENESS";
		}

		public static final class Output {
			public static final String CORPORATE_TABLE = "CORPORATE_TABLE";
			public static final String CORPORATE_ACTIVENESS = "CORPORATE_ACTIVENESS";
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String SHORT_CODE = "SHORT_CODE";

		}
	}

	public static final class GetSubscriberMetadata {
		public static final String SERVICE_NAME = "CDM_GET_SUBSCRIBER_METADATA";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String LANGUAGE_CODE = "LANGUAGE_CODE";
			public static final String CALLER_SCREEN = "CALLER_SCREEN";
		}

		public static final class Output {
			public static final String SUBSCRIBER_NO_VALIDATION = "SUBSCRIBER_NO_VALIDATION";
			public static final String SUBSCRIBER_METADATA_TABLE = "SUBSCRIBER_METADATA_TABLE";
			public static final String INDEX = "INDEX";
			public static final String LENGTH = "LENGTH";
			public static final String LABEL = "LABEL";
			public static final String MASK = "MASK";
			public static final String PATTERN = "PATTERN";
			public static final String TYPE = "TYPE";
			public static final String SUFFIX = "SUFFIX";
			public static final String PREFIX = "PREFIX";
			public static final String EXAMPLE = "EXAMPLE";
			public static final String IS_ALL_FIELDS_MANDATORY = "IS_ALL_FIELDS_MANDATORY";
		}
	}

	public static final class TaxReconciliationBatch {
		public static final String SERVICE_NAME = "TCS_TAX_RECONCILIATION";

		public static final class Input {
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String SECTOR_NAME = "SECTOR_NAME";
			public static final String TAX_DEFAULT_SECTOR_VALUE = "TAX_DEFAULT_SECTOR_VALUE";
		}

		public static final class Output {
		}
	}
	public static final class StandingOrderReconciliationBatch {
		public static final String SERVICE_NAME = "STO_STANDING_ORDER_RECONCILIATION";

		public static final class Input {
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SCREEN_RECONCILIATION = "SCREEN_RECONCILIATION";
			public static final String RESUBMIT_TYPE = "RESUBMIT_TYPE";
		}

		public static final class Output {
		}
	}

	public static final class CollectionReconciliationBatch {
		public static final String SERVICE_NAME = "ICS_COLLECTION_RECONCILIATION";

		public static final class Input {
			public static final String RECON_DATE = "RECON_DATE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SCREEN_RECONCILIATION = "SCREEN_RECONCILIATION";
			public static final String RESUBMIT_TYPE = "RESUBMIT_TYPE";
		}

		public static final class Output {
		}
	}
	
	public static final class MoneyLoadReconciliationBatch {
		public static final String SERVICE_NAME = "ICS_MONEY_LOAD_RECONCILIATION";

		public static final class Input {
			public static final String RECON_DATE = "RECON_DATE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SCREEN_RECONCILIATION = "SCREEN_RECONCILIATION";
			public static final String RESUBMIT_TYPE = "RESUBMIT_TYPE";
		}

		public static final class Output {
		}
	}

	public static final class SaveStandingOrder {
		public static final String SERVICE_NAME = "STO_SAVE_STANDING_ORDER";

		public static final class Input {
			public static final String TRX_NO = "TRX_NO";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String ORDER_OWNER = "ORDER_OWNER";
			public static final String CITY = "CITY";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
			public static final String PAYMENT_CHANNEL = "PAYMENT_CHANNEL";
			public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
			public static final String STANDING_ORDER_NAME = "STANDING_ORDER_NAME";
			public static final String START_DATE = "START_DATE";
			public static final String END_DATE = "END_DATE";
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String TYPE = "TYPE";
			public static final String IBAN = "IBAN";
			public static final String ORDER_NUMBER = "ORDER_NUMBER";
			public static final String PHONE_NUMBER = "PHONE_NUMBER";
			public static final String EMAIL = "EMAIL";
			public static final String BEFORE_PAYMENT = "BEFORE_PAYMENT";
			public static final String AFTER_PAYMENT = "AFTER_PAYMENT";
			public static final String NOTIFY_BY_SMS = "NOTIFY_BY_SMS";
			public static final String NOTIFY_BY_EMAIL = "NOTIFY_BY_EMAIL";
			public static final String CHECK_RESULT = "CHECK_RESULT";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
		}

		public static final class Output {
			public static final String STANDING_ORDER_MAIN_OID = "STANDING_ORDER_MAIN_OID";
		}
	}

	public static final class ReconLogInsert {
		public static final String SERVICE_NAME = "";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String RECON_STATUS = "RECON_STATUS";
			public static final String RECON_TYPE = "RECON_TYPE";
			public static final String SUB_TYPE = "SUB_TYPE";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String BANK_COUNT = "BANK_COUNT";
			public static final String CORPORATE_COUNT = "CORPORATE_COUNT";
			public static final String BANK_CANCEL_COUNT = "BANK_CANCEL_COUNT";
			public static final String CORPORATE_CANCEL_COUNT = "CORPORATE_CANCEL_COUNT";
			public static final String ERROR_DESC = "ERROR_DESC";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String RECON_DATE = "RECON_DATE";
			public static final String RECON_TIME = "RECON_TIME";
		}

		public static final class Output {
			public static final String RECON_LOG_OID = "RECON_LOG_OID";
		}
	}

	public static final class CheckSubscriberPreStandingOrder {
		public static final String SERVICE_NAME = "ICS_CHECK_SUBSCRIBER_PRE_STANDING_ORDER";

		public static final class Input {
			public static final String BANK_CODE = "BANK_CODE";
			public static final String OPERATION = "OPERATION";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
		}

		public static final class Output {
			public static final String RECON_LOG_OID = "RECON_LOG_OID";
			public static final String RESULT = "RESULT";
		}
	}

	public static final class SaveStandingOrderMain {
		public static final String SERVICE_NAME = "CDM_SAVE_STANDING_ORDER_MAIN";

		public static final class Input {
			public static final String BEFORE_PAYMENT = "BEFORE_PAYMENT";
			public static final String AFTER_PAYMENT = "AFTER_PAYMENT";
			public static final String NOTIFY_BY_SMS = "NOTIFY_BY_SMS";
			public static final String NOTIFY_BY_EMAIL = "NOTIFY_BY_EMAIL";
			public static final String CR_DATE = "CR_DATE";
			public static final String USER_NAME = "USER_NAME";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String START_DATE = "START_DATE";
			public static final String END_DATE = "END_DATE";
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String TYPE = "TYPE";
			public static final String PAYMENT_CHANNEL = "PAYMENT_CHANNEL";
			public static final String TRX_NO = "TRX_NO";
			public static final String STANDING_ORDER_NAME = "STANDING_ORDER_NAME";
			public static final String CITY = "CITY";
		}

		public static final class Output {
			public static final String STANDING_ORDER_MAIN_OID = "STANDING_ORDER_MAIN_OID";
		}
	}

	public static final class SaveStandingOrderAccount {
		public static final String SERVICE_NAME = "CDM_SAVE_STANDING_ORDER_ACCOUNT";

		public static final class Input {
			public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
			public static final String IBAN = "IBAN";
			public static final String STANDING_ORDER_MAIN_OID = "STANDING_ORDER_MAIN_OID";
		}

		public static final class Output {
		}
	}

	public static final class UpdateStandingOrderAccount {
		public static final String SERVICE_NAME = "CDM_UPDATE_STANDING_ORDER_ACCOUNT";

		public static final class Input {
			public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
			public static final String IBAN = "IBAN";
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
		}

		public static final class Output {
		}
	}

	public static final class CancelStandingOrderAccount {
		public static final String SERVICE_NAME = "CDM_CANCEL_STANDING_ORDER_ACCOUNT";

		public static final class Input {
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
		}

		public static final class Output {
		}
	}

	public static final class IcsSaveStandingOrder {
		public static final String SERVICE_NAME = "ICS_SAVE_STANDING_ORDER";

		public static final class Input {
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String STANDING_ORDER_MAIN_OID = "STANDING_ORDER_MAIN_OID";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String TRX_NO = "TRX_NO";
		}

		public static final class Output {
		}
	}

	public static final class IcsUpdateStandingOrder {
		public static final String SERVICE_NAME = "ICS_UPDATE_STANDING_ORDER";

		public static final class Input {
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String STANDING_ORDER_STATUS = "STANDING_ORDER_STATUS";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
			public static final String TRX_NO = "TRX_NO";
		}

		public static final class Output {
		}
	}

	public static final class IcsCancelStandingOrder {
		public static final String SERVICE_NAME = "ICS_CANCEL_STANDING_ORDER";

		public static final class Input {
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String STANDING_ORDER_STATUS = "STANDING_ORDER_STATUS";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
			public static final String TRX_NO = "TRX_NO";
		}

		public static final class Output {
		}
	}

	public static final class SaveStandingOrderComm {
		public static final String SERVICE_NAME = "SAVE_STANDING_ORDER_COMM";

		public static final class Input {
			public static final String E_MAIL = "E_MAIL";
			public static final String PHONE_NUMBER = "PHONE_NUMBER";
			public static final String STANDING_ORDER_MAIN_OID = "STANDING_ORDER_MAIN_OID";
		}

		public static final class Output {
		}
	}

	public static final class UpdateStandingOrderComm {
		public static final String SERVICE_NAME = "STO_UPDATE_STANDING_ORDER_COMM";

		public static final class Input {
			public static final String E_MAIL = "E_MAIL";
			public static final String PHONE_NUMBER = "PHONE_NUMBER";
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
		}

		public static final class Output {
		}
	}

	public static final class CancelStandingOrderComm {
		public static final String SERVICE_NAME = "STO_CANCEL_STANDING_ORDER_COMM";

		public static final class Input {
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
		}

		public static final class Output {
		}
	}

	public static final class ReconLogUpdate {
		public static final String SERVICE_NAME = "";

		public static final class Input {
			public static final String RECON_STATUS = "RECON_STATUS";
			public static final String RECON_TYPE = "RECON_TYPE";
			public static final String RECON_LOG_OID = "RECON_LOG_OID";
			public static final String ERROR_DESC = "ERROR_DESC";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String BANK_AMOUNT = "BANK_AMOUNT";
			public static final String BANK_CANCEL_AMOUNT = "BANK_CANCEL_AMOUNT";
			public static final String BANK_CANCEL_COUNT = "BANK_CANCEL_COUNT";
			public static final String BANK_COUNT = "BANK_COUNT";
			public static final String CORPORATE_AMOUNT = "CORPORATE_AMOUNT";
			public static final String CORPORATE_CANCEL_AMOUNT = "CORPORATE_CANCEL_AMOUNT";
			public static final String CORPORATE_CANCEL_COUNT = "CORPORATE_CANCEL_COUNT";
			public static final String CORPORATE_COUNT = "CORPORATE_COUNT";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String PROCESS_TIME = "PROCESS_TIME";
			public static final String PROCESS_USER = "PROCESS_USER";
			public static final String RECON_DATE = "RECON_DATE";
			public static final String RECON_TIME = "RECON_TIME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SUB_TYPE = "SUB_TYPE";

		}

		public static final class Output {
		}
	}

	public static final class GetStandingOrderCount {
		public static final String SERVICE_NAME = "STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String RECON_DATE = "RECON_DATE";
		}

		public static final class Output {
			public static final String RECORD_COUNT = "RECORD_COUNT";
			public static final String CANCEL_COUNT = "CANCEL_COUNT";
			public static final String RECORD_LIST = "RECORD_LIST";
		}
	}

	public static final class CancelAllWaitingInvoices {
		public static final String SERVICE_NAME = "STO_CANCEL_ALL_WAITING_INVOICES";

		public static final class Input {
			public static final String STANDING_ORDER_MAIN_OID = "STANDING_ORDER_MAIN_OID";
		}

		public static final class Output {
		}
	}

	public static final class GetDefinedStandingOrders {
		public static final String SERVICE_NAME = "STO_GET_DEFINED_STANDING_ORDERS";

		public static final class Input {
			public static final String GET_SECTORS = "GET_SECTORS";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String STANDING_ORDER_STATUS = "STANDING_ORDER_STATUS";
			public static final String STANDING_ORDER_NUMBER = "STANDING_ORDER_NUMBER";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}

		public static final class Output {
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";
			public static final String START_DATE = "START_DATE";
			public static final String END_DATE = "END_DATE";
			public static final String CREATE_DATE = "CREATE_DATE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
			public static final String IBAN = "IBAN";
			public static final String BRANCH_CODE = "BRANCH_CODE";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String STANDING_ORDER_NUMBER = "STANDING_ORDER_NUMBER";
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String NOTIFY_BY_EMAIL = "NOTIFY_BY_EMAIL";
			public static final String NOTIFY_BY_SMS = "NOTIFY_BY_SMS";
			public static final String SECTOR_NAME = "SECTOR_NAME";
			public static final String RESULT = "RESULT";
			public static final String ORDER_STATUS_CODE = "ORDER_STATUS_CODE";
			public static final String CREATE_USER = "CREATE_USER";
			public static final String USER_LABEL = "USER_LABEL";

		}
	}

	public static final class GetStandingOrderTransactions {
		public static final String SERVICE_NAME = "CDM_GET_STANDING_ORDER_TRANSACTIONS";

		public static final class Input {

		}

		public static final class Output {
			public static final String RESULT = "RESULT";
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String INVOICE_NO = "INVOICE_NO";
			public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE";
			public static final String INVOICE_AMOUNT = "INVOICE_AMOUNT";
			public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
			public static final String INVOICE_STATUS = "INVOICE_STATUS";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_DESC = "ERROR_DESC";
		}
	}

	public static final class GetStandingOrderHistory {
		public static final String SERVICE_NAME = "CDM_GET_STANDING_ORDER_HISTORY";

		public static final class Input {

		}

		public static final class Output {
			public static final String RESULT = "RESULT";
			public static final String DATE = "DATE";
			public static final String TIME = "TIME";
			public static final String OPERATION = "OPERATION";
		}
	}

	public static final class GetPaidOrders {
		public static final String SERVICE_NAME = "STO_GET_PAID_ORDERS";

		public static final class Input {
			public static final String PAY_CHANNEL_CODE = "PAY_CHANNEL_CODE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
		}

		public static final class Output {
			public static final String SUBSCRIBER_NO = "SUBSCRIBER_NO";
			public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE";
			public static final String PAID_AMOUNT = "PAID_AMOUNT";
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String PAID_ORDERS_TABLE = "PAID_ORDERS_TABLE";
			public static final String TX_NO = "TX_NO";
		}
	}

	public static final class GetPaymentsByCustomerNumber {
		public static final String SERVICE_NAME = "ICS_GET_PAYMENTS_BY_CUSTOMER_NUMBER";

		public static final class Input {
			public static final String PAY_CHANNEL_CODE = "PAY_CHANNEL_CODE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
		}

		public static final class Output {
			public static final String SUBSCRIBER_NO = "SUBSCRIBER_NO";
			public static final String PAID_AMOUNT = "PAID_AMOUNT";
			public static final String INVOICE_AMOUNT = "INVOICE_AMOUNT";
			public static final String INVOICE_NO = "INVOICE_NO";
			public static final String SUBSCRIBER_NAME = "SUBSCRIBER_NAME";
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String SECTOR_NAME = "SECTOR_NAME";
			public static final String PAYMENT_OID = "PAYMENT_OID";

			public static final String PAYMENTS_TABLE = "PAYMENTS_TABLE";

		}
	}

	public static final class GetCollectionTypeInfo {
		public static final String SERVICE_NAME = "CDM_COMMON_GET_COLLECTION_TYPE_INFO";

		public static final class Input {
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}

		public static final class Output {
			public static final String ALLOW_AUTO_COLLECTION = "ALLOW_AUTO_COLLECTION";

		}
	}

	public static final class UpdateStandingOrder {
		public static final String SERVICE_NAME = "STO_UPDATE_STANDING_ORDER";

		public static final class Input {
			public static final String TRX_NO = "TRX_NO";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String ORDER_OWNER = "ORDER_OWNER";
			public static final String CORPORATE = "CORPORATE";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String PAYMENT_CHANNEL = "PAYMENT_CHANNEL";
			public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
			public static final String STANDING_ORDER_NAME = "STANDING_ORDER_NAME";
			public static final String END_DATE = "END_DATE";
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String TYPE = "TYPE";
			public static final String IBAN = "IBAN";
			public static final String ORDER_NUMBER = "ORDER_NUMBER";
			public static final String PHONE_NUMBER = "PHONE_NUMBER";
			public static final String EMAIL = "EMAIL";
			public static final String BEFORE_PAYMENT = "BEFORE_PAYMENT";
			public static final String AFTER_PAYMENT = "AFTER_PAYMENT";
			public static final String NOTIFY_BY_SMS = "NOTIFY_BY_SMS";
			public static final String NOTIFY_BY_EMAIL = "NOTIFY_BY_EMAIL";
			public static final String CHECK_RESULT = "CHECK_RESULT";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
			public static final String OID = "OID";
		}

		public static final class Output {
		}
	}

	public static final class CancelStandingOrder {
		public static final String SERVICE_NAME = "STO_CANCEL_STANDING_ORDER";

		public static final class Input {

			public static final String OID = "OID";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String TYPE = "TYPE";
			public static final String TRX_NO = "TRX_NO";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String ORDER_NUMBER = "ORDER_NUMBER";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String SUBSCRIBER_NO2 = "SUBSCRIBER_NO2";
			public static final String SUBSCRIBER_NO3 = "SUBSCRIBER_NO3";
			public static final String SUBSCRIBER_NO4 = "SUBSCRIBER_NO4";

		}

		public static final class Output {
		}
	}

	public static final class UpdateStandingOrderMain {
		public static final String SERVICE_NAME = "CDM_UPDATE_STANDING_ORDER_MAIN";

		public static final class Input {
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String BEFORE_PAYMENT = "BEFORE_PAYMENT";
			public static final String AFTER_PAYMENT = "AFTER_PAYMENT";
			public static final String NOTIFY_BY_SMS = "NOTIFY_BY_SMS";
			public static final String NOTIFY_BY_EMAIL = "NOTIFY_BY_EMAIL";
			public static final String USER_NAME = "USER_NAME";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String END_DATE = "END_DATE";
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String TYPE = "TYPE";
			public static final String PAYMENT_CHANNEL = "PAYMENT_CHANNEL";
			public static final String TRX_NO = "TRX_NO";
			public static final String STANDING_ORDER_NAME = "STANDING_ORDER_NAME";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
		}

		public static final class Output {
		}
	}

	public static final class CancelStandingOrderMain {
		public static final String SERVICE_NAME = "CDM_CANCEL_STANDING_ORDER_MAIN";

		public static final class Input {
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String USER_NAME = "USER_NAME";
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String TYPE = "TYPE";
			public static final String TRX_NO = "TRX_NO";
			public static final String UPDATE_DATE = "UPDATE_DATE";
			public static final String UPDATE_USER = "UPDATE_USER";
		}

		public static final class Output {
		}
	}

	public static final class ReconProcessDataLog {
		public static final String SERVICE_NAME = "ICS_RECON_PROCESS_DATA_LOG_INSERT";

		public static final class Input {
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String ERROR_DESC = "ERROR_DESC";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String INSTALLMENT_NO = "INSTALLMENT_NO";
			public static final String INVOICE_AMOUNT = "INVOICE_AMOUNT";
			public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE";
			public static final String INVOICE_NO = "INVOICE_NO";
			public static final String PARAMETER_1 = "PARAMETER_1";
			public static final String PARAMETER_2 = "PARAMETER_2";
			public static final String PARAMETER_3 = "PARAMETER_3";
			public static final String PARAMETER_4 = "PARAMETER_4";
			public static final String PARAMETER_5 = "PARAMETER_5";
			public static final String PARAMETER_6 = "PARAMETER_6";
			public static final String PARAMETER_7 = "PARAMETER_7";
			public static final String PROCESS_STAN_NO = "PROCESS_STAN_NO";
			public static final String PROCESS_TYPE = "PROCESS_TYPE";
			public static final String RECON_LOG_OID = "RECON_LOG_OID";
			public static final String SUBSCRIBER_NO_1 = "SUBSCRIBER_NO_1";
			public static final String SUBSCRIBER_NO_2 = "SUBSCRIBER_NO_2";
			public static final String SUBSCRIBER_NO_3 = "SUBSCRIBER_NO_3";
			public static final String SUBSCRIBER_NO_4 = "SUBSCRIBER_NO_4";
		}

		public static final class Output {
		}
	}

	public static final class StartCorporateAccountTransfer {
		public static final String SERVICE_NAME = "CDM_TRANSFER_CORPORATE_ACCOUNT_BATCH_STARTER";

		public static final class Input {

		}

		public static final class Output {

		}
	}

	public static final class CalculateTransferDates {
		public static final String SERVICE_NAME = "CDM_CALCULATE_TRANSFER_DATES";

		public static final class Input {
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String COLLECTION_DATE = "COLLECTION_DATE";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String IS_GSM_CORPORATE = "IS_GSM_CORPORATE";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
		}

		public static final class Output {

		}
	}

	public static final class TransferCorporateAccount {
		public static final String SERVICE_NAME = "CDM_TRANSFER_CORPORATE_ACCOUNT";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
		}

		public static final class Output {

		}
	}

	public static final class InsertBalanceTransferProcess {
		public static final String SERVICE_NAME = "CDM_INSERT_BALANCE_TRANSFER_PROCESS";

		public static final class Input {
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String COLLECTION_DATE = "COLLECTION_DATE";
			public static final String TRANSFER_STATUS = "TRANSFER_STATUS";
			public static final String TRANSFER_AMOUNT = "TRANSFER_AMOUNT";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String TRANSFER_DATE = "TRANSFER_DATE";
			public static final String FROM_ACCOUNT = "FROM_ACCOUNT";
			public static final String TO_ACCOUNT = "TO_ACCOUNT";
			public static final String TO_IBAN = "TO_IBAN";
			public static final String TO_IBAN_OWNER = "TO_IBAN_OWNER";
			public static final String IS_EFT_TRANSFER = "IS_EFT_TRANSFER";
			public static final String IS_UPDATE = "IS_UPDATE";
			public static final String RECORD_ID = "RECORD_ID";
			public static final String TRANSACTION_NO = "TRANSACTION_NO";
			public static final String TRANSFER_DEF_OID = "TRANSFER_DEF_OID";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
			public static final String FROM_ACCOUNT_TYPE = "FROM_ACCOUNT_TYPE";
		}

		public static final class Output {
			public static final String RECORD_ID = "RECORD_ID";
		}
	}

	public static final class InsertBalanceTransferLog {
		public static final String SERVICE_NAME = "CDM_INSERT_BALANCE_TRANSFER_LOG";

		public static final class Input {
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String TRANSFER_PROCESS_OID = "TRANSFER_PROCESS_OID";
			public static final String TRANSFER_AMOUNT = "TRANSFER_AMOUNT";
			public static final String TRANSFER_STATUS = "TRANSFER_STATUS";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String PROCESS_USER = "PROCESS_USER";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
			public static final String IS_UPDATE = "IS_UPDATE";
			public static final String RECORD_ID = "RECORD_ID";
			public static final String CURRENT_AVAILABLE_BALANCE = "CURRENT_AVAILABLE_BALANCE";
			public static final String ACTUAL_TRANSFER_AMOUNT = "ACTUAL_TRANSFER_AMOUNT";
			public static final String CONSTANT_AMOUNT = "CONSTANT_AMOUNT";
		}

		public static final class Output {
			public static final String RECORD_ID = "RECORD_ID";
		}
	}

	public static final class ReconciliationResubmit {
		public static final String SERVICE_NAME = "ICS_RECON_RESUBMIT";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String DATE = "DATE";
			public static final String RECON_TYPE = "RECON_TYPE";
			public static final String FIND_DIFFERENCES = "FIND_DIFFERENCES";
			public static final String RECON_CLOSE = "RECON_CLOSE";
		}

		public static final class Output {

		}
	}

	public static final class InsertCorporateAccountBlockedLog {
		public static final String SERVICE_NAME = "CDM_INSERT_CORPORATE_ACCOUNT_BLOCKED_LOG";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String BLOCKED_STATUS = "BLOCKED_STATUS";
			public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
			public static final String BLOCK_REFERENCE = "BLOCK_REFERENCE";
			public static final String BLOCKED_USER = "BLOCKED_USER";
			public static final String BLOCKED_DATE = "BLOCKED_DATE";
			public static final String UNBLOCKED_USER = "UNBLOCKED_USER";
			public static final String UNBLOCKED_DATE = "UNBLOCKED_DATE";
			public static final String IS_UPDATE = "IS_UPDATE";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
			public static final String SET_INACTIVE = "SET_INACTIVE";
		}

		public static final class Output {

		}
	}

	public static final class CommitInvoices {
		public static final String SERVICE_NAME = "ICS_COMMIT_INVOICES";

		public static final class Input {
			public static final String INSERT_TABLE = "INSERT_TABLE";
			public static final String SERVICE_NAME = "SERVICE_NAME";
			public static final String INSERT_REQUEST = "INSERT_REQUEST";
		}

		public static final class Output {

		}
	}

	public static final class MultiFileLoading {
		public static final class Input {
			public static final String FTM_ID = "FILE_DEF_ID";
			public static final String FTM_TRANSFER_ID = "PROCESS_ID";
		}

		public static final class Output {
			public static final String SUBMIT_ID = "SUBMIT_ID";
		}

		public static final String SERVICE_NAME = "ICS_FTM_MULTI_FILE_LOADING";
	}

	public static final class ComplexBatchSubmit {
		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String PROCESS_DATE = "PROCESS_DATE";
		}

		public static final class Output {

		}
	}

	public static final class GetBalanceTransferLog {
		public static final String SERVICE_NAME = "CDM_GET_BALANCE_TRANSFER_LOG";

		public static final class Input {
			public static final String BALANCE_TRANSFER_PROCESS_ID = "TRANSFER_PROCESS_OID";
		}

		public static final class Output {

		}
	}

	public static final class UpdateBalanceTransferInformation {
		public static final class Input {
			public static final String BALANCE_TRANSFER_PROCESS_ID = "OID";
		}

		public static final class Output {

		}
	}

	public static final class QueryBalanceTransferInformation {
		public static final class Input {
			public static final String BALANCE_TRANSFER_PROCESS_ID = "OID";
		}

		public static final class Output {
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
			public static final String ACTUAL_TRANSFER_AMOUNT = "ACTUAL_TRANSFER_AMOUNT";
			public static final String CONSTANT_AMOUNT = "CONSTANT_AMOUNT";
			public static final String TRANSFER_STATUS = "TRANSFER_STATUS";
		}
	}

	public static final class StandingOrderNotifyProcesLog {
		public static final String SERVICE_NAME = "";

		public static final class Input {
			public static final String STATUS = "STATUS";
			public static final String INVOICE_MAIN_OID = "INVOICE_MAIN_OID";
			public static final String STANDING_ORDER_COMM_OID = "STANDING_ORDER_COMM_OID";
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String PROCESS_STATUS = "PROCESS_STATUS";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String ERROR_DESC = "ERROR_DESC";
			public static final String IS_UPDATE = "IS_UPDATE";
			public static final String PAYMENT_STATUS = "PAYMENT_STATUS";
		}

		public static final class Output {
			public static final String STANDING_ORDER_NOTIFY_PROCESS_LOG_OID = "STANDING_ORDER_NOTIFY_PROCESS_LOG_OID";
		}
	}

	public static final class UpdateInvoiceDebtProces {
		public static final String SERVICE_NAME = "ICS_UPDATE_INVOICE_DEBT_PROCESS";

		public static final class Input {
			public static final String FTM_SEQUENCE_NUMBER = "FTM_SEQUENCE_NUMBER";
			public static final String PAYMENT_STATUS = "PAYMENT_STATUS";
		}
	}

	public static final class TTSReconciliationLineParserProcess {
		public static final String SERVICE_NAME = "ICS_TTS_FTM_COLLECTION_RECONCILIATION_DETAIL";

		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String FORMAT_ID = "FORMAT_ID";
			public static final String FILE_DIR = "FILE_DIR";
			public static final String PAYMENT_STATUS = "PAYMENT_STATUS";
			public static final String CANCEL_STATUS = "CANCEL_STATUS";
		}

		public static final class Output {
			public static final String INVOICE_PAYMENT_LIST = "INVOICE_PAYMENT_LIST";
			public static final String CANCEL_PAYMENT_LIST = "CANCEL_PAYMENT_LIST";
			public static final String STANDING_ORDER_PAYMENT_LIST = "STANDING_ORDER_PAYMENT_LIST";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String FILE_FORMAT = "FILE_FORMAT";
		}

	}

	public static final class DoGSMMoneyLoad{
		public static final String SERVICE_NAME = "ICS_DO_GSM_MONEY_LOAD";
		public static final String SERVICE_NAME_INTERNET_PACKAGE = "ICS_DO_GSM_GPRS_PACKAGE_SALES";
		public static final String SERVICE_NAME_VOICE_PACKAGE = "ICS_DO_GSM_VOICE_PACKAGE_SALES";
		public static final class Input {
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String TRX_NO = "TRX_NO";
			public static final String INVOICE_MAIN_OID = "INVOICE_MAIN_OID";
			public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
			public static final String PAYMENT_ACCOUNT_NO = "PAYMENT_ACCOUNT_NO";
			public static final String IBAN_NO = "IBAN_NO";
			public static final String QUERY_REF_NO = "QUERY_REF_NO";
			public static final String COLLECTION_TYPE = "COLLECTION_TYPE";
			public static final String SUBSCRIBER_NO1 = "SUBSCRIBER_NO1";
			public static final String STANDING_ORDER_OID = "STANDING_ORDER_OID";
			public static final String SUBSCRIBER_NAME = "SUBSCRIBER_NAME";
			public static final String PACKAGE_ID = "PACKAGE_ID";
			public static final String ACCOUNT_BALANCE = "ACCOUNT_BALANCE";
			public static final String PAYMENT_CARD_NO = "PAYMENT_CARD_NO";
			public static final String SOURCE = "SOURCE";
			public static final String PAYMENT_SOURCE = "PAYMENT_SOURCE";
			public static final String BRANCH_CODE = "BRANCH_CODE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String CUSTOMER_PHONE = "CUSTOMER_PHONE";
			public static final String CUSTOMER_ID_NO = "CUSTOMER_ID_NO";
			public static final String CUSTOMER_TAX_NO = "CUSTOMER_TAX_NO";
			public static final String ACCOUNT_CURRENCY_CODE = "ACCOUNT_CURRENCY_CODE";
			public static final String COLLECTION_TYPE_NAME = "COLLECTION_TYPE_NAME";
			public static final String PARAMETER1 = "PARAMETER1";
			public static final String PARAMETER2 = "PARAMETER2";
			public static final String PARAMETER3 = "PARAMETER3";
			public static final String PARAMETER4 = "PARAMETER4";
			public static final String PARAMETER5 = "PARAMETER5";
			public static final String PARAMETER6 = "PARAMETER6";
			public static final String PARAMETER7 = "PARAMETER7";
			public static final String PARAMETER8 = "PARAMETER8";
			public static final String PARAMETER9 = "PARAMETER9";
			public static final String PARAMETER10 = "PARAMETER10";
			public static final String CHANNEL_CODE = "CHANNEL_CODE";
			public static final String ACCOUNT_AVAILABLE_BALANCE = "ACCOUNT_AVAILABLE_BALANCE";
			public static final String PROVISION_ID = "PROVISION_ID";
			public static final String CORPORATE_ACCOUNT_NO = "CORPORATE_ACCOUNT_NO";
			public static final String CORPORATE_OID = "CORPORATE_OID";
		}
		public static final class Output{
			public static final String ACCOUNT_NO = "ACCOUNT_NO";
			public static final String TRX_NO = "TRX_NO";
		}
	}
	
	public static final String DIRECT_INSERT_GENERAL_KEY = "DIRECT_INSERT";
	public static final String INSERT_KEYVALUE_PAIRS_GENERAL_KEY = "INSERT_KEYVALUE_PAIRS";
	public static final String INSERT_PAIR_TABLE_GENERAL_KEY = "INSERT_PAIR_TABLE";
	public static final String SUBMIT_ID__GENERAL_KEY = "SUBMIT_ID";
	public static final String COMMAND_GENERAL_KEY = "COMMAND";

	public static final String FORMAT_ID_GENERAL_KEY = "FORMAT_ID";

	public static final String INFORM_BATCH_DATE_GENERAL_KEY = "DATE";
	public static final String INFORM_BATCH_CORPORATE_CODE_GENERAL_KEY = "CORPORATE_CODE";
	public static final String INFORM_BATCH_INDICATOR_GENERAL_KEY = "INDICATOR";
	public static final String INFORM_BATCH_RESPONSE_RESULT_GENERAL_KEY = "RESULT";
	public static final String INFORM_BATCH_RESPONSE_ERROR_CODE_GENERAL_KEY = "ERROR_CODE";
	public static final String INFORM_BATCH_RESPONSE_ERROR_MESSAGE_GENERAL_KEY = "ERROR_MESSAGE";

	public static final String CONTROL_INVOICE_NO_GENERAL_KEY = "CONTROL_INVOICE_NO";
	public static final String CONTROL_INVOICE_DUE_DATE_GENERAL_KEY = "CONTROL_INVOICE_DUE_DATE_GENERAL_KEY";
	public static final String LOAD_ONLY_WITH_STANDING_ORDER_GENERAL_KEY = "LOAD_ONLY_WITH_STANDING_ORDER";

	public static final String RETURN_CODE_GENERAL_KEY = "RETURN_CODE";
	public static final String RETURN_MESSAGE_GENERAL_KEY = "RETURN_MESSAGE";

	public static final String KeepSession = "KeepSession";
	public static final String CORPORATE_CODE_GENERAL_KEY = "CORPORATE_CODE";
	public static final String FTM_TRANSFER_ID_GENERAL_KEY = "FTM_TRANSFER_ID";

	public static final class VodafoneDebtInqueryServices {
		public static final String SERVICE_NAME = "ICS_VF_INVOICE_DEBT_INQUIRY";

		public static final class Input {
			public static final String OPERATION_SOURCE = "OPERATION_SOURCE";
			public static final String RECORD_NUMBER = "RECORD_NUMBER";
			public static final String ORIGINATOR_ID = "ORIGINATOR_ID";
			public static final String SUN = "SUN";
			public static final String COMPANY_ID = "COMPANY_ID";
			public static final String INSTITUTION_ID = "INSTITUTION_ID";
			public static final String INSTITUTION_NUMBER = "INSTITUTION_NUMBER";
			public static final String CUT_INFORMATION = "CUT_INFORMATION";
			public static final String TARIFF_UNIT = "TARIFF_UNIT";
			public static final String TARIFF_AMOUNT = "TARIFF_AMOUNT";
			public static final class OriginatorId {
				public static final String ORIGINATOR_ID_CITY_CODE = "ORIGINATOR_ID_CITY_CODE";
				public static final String ORIGINATOR_ID_BRANCH_CODE = "ORIGINATOR_ID_BRANCH_CODE";
				public static final String ORIGINATOR_ID_OFFICE_CODE = "ORIGINATOR_ID_OFFICE_CODE";
				public static final String ORIGINATOR_ID_USER_CODE = "ORIGINATOR_ID_USER_CODE";
			}

			public static final String CURRENCY_CODE = "CURRENCY_CODE";

			public static final class Sun {
				public static final String SUN_CUSTOMER_ACCESS_TYPE = "SUN_CUSTOMER_ACCESS_TYPE";
				public static final String SUN_CUSTOMER_ACCESS_NO = "SUN_CUSTOMER_ACCESS_NO";
			}

			public static final String PEYMENT_PERIOD = "PEYMENT_PERIOD";
			public static final String CORPORATION_ID = "CORPORATION_ID";
			public static final String OPERATION_CODE_ID = "OPERATION_CODE_ID";
			public static final String SUB_COMPANY_ID = "SUB_COMPANY_ID";
		}

		public static final class Output {
			public static final String BILL_INFO = "BILL_INFO";

			public static final class BillInfo {
				public static final String BILL_INFO_NAME_SURNAME = "BILL_INFO_NAME_SURNAME";
				public static final String BILL_INFO_TYPE = "BILL_INFO_TYPE";
				public static final String BILL_INFO_EXPIRY_DATE = "BILL_INFO_EXPIRY_DATE";
				public static final String BILL_INFO_CUSTOMER_NO = "BILL_INFO_CUSTOMER_NO";
				public static final String BILL_INFO_NO = "BILL_INFO_NO";
				public static final String BILL_INFO_CUSTOMER_ACCESS_TYPE = "BILL_INFO_CUSTOMER_ACCESS_TYPE";
				public static final String BILL_INFO_TERM = "BILL_INFO_TERM";
				public static final String BILL_INFO_PHONE_NO = "BILL_INFO_PHONE_NO";
				public static final String BILL_INFO_REF_NO = "BILL_INFO_REF_NO";
				public static final String BILL_INFO_SEQ_NO = "BILL_INFO_SEQ_NO";
				public static final String BILL_INFO_AMOUNT = "BILL_INFO_AMOUNT";
			}

			public static final String STAN = "STAN";
			public static final String ISO_MESSAGE = "ISO_MESSAGE";
			public static final String OPERATION_CODE = "OPERATION_CODE";
			public static final String CURRENCY_CODE = "CURRENCY_CODE";
			public static final String GW_INTERNAL_ERROR_CODE = "GW_INTERNAL_ERROR_CODE";
			public static final String GW_INTERNAL_ERROR_DESC = "GW_INTERNAL_ERROR_DESC";

			public static final class OriginatorId {
				public static final String ORIGINATOR_ID_CITY_CODE = "ORIGINATOR_ID_CITY_CODE";
				public static final String ORIGINATOR_ID_BRANCH_CODE = "ORIGINATOR_ID_BRANCH_CODE";
				public static final String ORIGINATOR_ID_OFFICE_CODE = "ORIGINATOR_ID_OFFICE_CODE";
				public static final String ORIGINATOR_ID_USER_CODE = "ORIGINATOR_ID_USER_CODE";
			}

			public static final String RESPONSE_CODE = "RESPONSE_CODE";
			public static final String MT = "MT";
			public static final String INSTITUTION_ID = "INSTITUTION_ID";
			public static final String PRIMARY_BM = "PRIMARY-BM";
			public static final String TRANS_DATE_TIME = "TRANS_DATE_TIME";
			public static final String COMPANY_ID = "COMPANY_ID";
			public static final String RECORD_NUMBER = "RECORD_NUMBER";

		}
	}

	public static final class VodafoneDoInvoiceCollectionServices {
		public static final String SERVICE_NAME = "ICS_VF_DO_INVOICE_COLLECTION";

		public static final class Input {
			public static final String MT = "MT";
			public static final String PRIMARY_BM = "PRIMARY-BM";
			public static final String OPERATION_CODE = "OPERATION_CODE";
			public static final String TRANS_DATE_TIME = "TRANS_DATE_TIME";
			public static final String STAN = "STAN";
			public static final String TRANS_DATE = "TRANS_DATE";
			public static final String COMPANY_ID = "COMPANY_ID";
			public static final String CAPTURE_DATE = "CAPTURE_DATE";
			public static final String INSTITUTION_ID = "INSTITUTION_ID";
			public static final String OPERATION_SOURCE = "OPERATION_SOURCE";
			public static final String CURRENCY_CODE = "CURRENCY_CODE";
			public static final String ACCEPTENCE_DATE = "ACCEPTENCE_DATE";
			public static final String ORIGINATOR_ID = "ORIGINATOR_ID";
			public static final String SUB_COMPANY_ID = "SUB_COMPANY_ID";


			public static final class OriginatorId {
				public static final String ORIGINATOR_ID_CITY_CODE = "ORIGINATOR_ID_CITY_CODE";
				public static final String ORIGINATOR_ID_BRANCH_CODE = "ORIGINATOR_ID_BRANCH_CODE";
				public static final String ORIGINATOR_ID_OFFICE_CODE = "ORIGINATOR_ID_OFFICE_CODE";
				public static final String ORIGINATOR_ID_USER_CODE = "ORIGINATOR_ID_USER_CODE";
			}

			public static final String BILL_INFO = "BILL_INFO";

			public static final class BillInfo {
				public static final String BILL_INFO_CUSTOMER_ACCESS_TYPE = "BILL_INFO_CUSTOMER_ACCESS_TYPE";
				public static final String BILL_INFO_PHONE_NO = "BILL_INFO_PHONE_NO";
				public static final String BILL_INFO_CUSTOMER_NO = "BILL_INFO_CUSTOMER_NO";
				public static final String BILL_INFO_NAME_SURNAME = "BILL_INFO_NAME_SURNAME";
				public static final String BILL_INFO_TYPE = "BILL_INFO_TYPE";
				public static final String BILL_INFO_TERM = "BILL_INFO_TERM";
				public static final String BILL_INFO_EXPIRY_DATE = "BILL_INFO_EXPIRY_DATE";
				public static final String BILL_INFO_REF_NO = "BILL_INFO_REF_NO";
				public static final String BILL_INFO_NO = "BILL_INFO_NO";
				public static final String BILL_INFO_SEQ_NO = "BILL_INFO_SEQ_NO";
				public static final String BILL_INFO_AMOUNT = "BILL_INFO_AMOUNT";
				public static final String BILL_INFO_STAN = "BILL_INFO_STAN";
				public static final String BILL_INFO_ORDER_NO = "BILL_INFO_ORDER_NO";
			}
		}

		public static final class Output {
			public static final String MT = "MT";
			public static final String PRIMARY_BM = "PRIMARY-BM";

			public static final String OPERATION_CODE = "OPERATION_CODE";
			public static final String TRANS_DATE_TIME = "TRANS_DATE_TIME";
			public static final String STAN = "STAN";
			public static final String TRANS_DATE = "TRANS_DATE";
			public static final String COMPANY_ID = "COMPANY_ID";
			public static final String INSTITUTION_ID = "INSTITUTION_ID";
			public static final String RESPONSE_CODE = "RESPONSE_CODE";

			public static final class OriginatorId {
				public static final String ORIGINATOR_ID_CITY_CODE = "ORIGINATOR_ID_CITY_CODE";
				public static final String ORIGINATOR_ID_BRANCH_CODE = "ORIGINATOR_ID_BRANCH_CODE";
				public static final String ORIGINATOR_ID_OFFICE_CODE = "ORIGINATOR_ID_OFFICE_CODE";
				public static final String ORIGINATOR_ID_USER_CODE = "ORIGINATOR_ID_USER_CODE";
			}

		}
	}

	public static final class AveaDebtInqueryServices {
		public static final String SERVICE_NAME = "ICS_AVEA_INVOICE_DEBT_INQUIRY";

		public static final class Input {
			public static final String OPERATION_SOURCE = "OPERATION_SOURCE";
			public static final String RECORD_NUMBER = "RECORD_NUMBER";
			public static final String ORIGINATOR_ID = "ORIGINATOR_ID";
			public static final String SUN = "SUN";

			public static final class OriginatorId {
				public static final String ORIGINATOR_ID_CITY_CODE = "ORIGINATOR_ID_CITY_CODE";
				public static final String ORIGINATOR_ID_BRANCH_CODE = "ORIGINATOR_ID_BRANCH_CODE";
				public static final String ORIGINATOR_ID_OFFICE_CODE = "ORIGINATOR_ID_OFFICE_CODE";
				public static final String ORIGINATOR_ID_USER_CODE = "ORIGINATOR_ID_USER_CODE";
			}

			public static final String CURRENCY_CODE = "CURRENCY_CODE";

			public static final class Sun {
				public static final String SUN_CUSTOMER_ACCESS_TYPE = "SUN_CUSTOMER_ACCESS_TYPE";
				public static final String SUN_CUSTOMER_ACCESS_NO = "SUN_CUSTOMER_ACCESS_NO";
			}

			public static final String PEYMENT_PERIOD = "PEYMENT_PERIOD";
			public static final String CORPORATION_ID = "CORPORATION_ID";
			public static final String OPERATION_CODE_ID = "OPERATION_CODE_ID";
			public static final String INSTITUTION_ID="INSTITUTION_ID";
		}

		public static final class Output {
			public static final String BILL_INFO = "BILL_INFO";

			public static final class BillInfo {
				public static final String BILL_INFO_NAME_SURNAME = "BILL_INFO_NAME_SURNAME";
				public static final String BILL_INFO_TYPE = "BILL_INFO_TYPE";
				public static final String BILL_INFO_EXPIRY_DATE = "BILL_INFO_EXPIRY_DATE";
				public static final String BILL_INFO_CUSTOMER_NO = "BILL_INFO_CUSTOMER_NO";
				public static final String BILL_INFO_NO = "BILL_INFO_NO";
				public static final String BILL_INFO_CUSTOMER_ACCESS_TYPE = "BILL_INFO_CUSTOMER_ACCESS_TYPE";
				public static final String BILL_INFO_TERM = "BILL_INFO_TERM";
				public static final String BILL_INFO_PHONE_NO = "BILL_INFO_PHONE_NO";
				public static final String BILL_INFO_REF_NO = "BILL_INFO_REF_NO";
				public static final String BILL_INFO_SEQ_NO = "BILL_INFO_SEQ_NO";
				public static final String BILL_INFO_AMOUNT = "BILL_INFO_AMOUNT";				
			}

			public static final String STAN = "STAN";
			public static final String ISO_MESSAGE = "ISO_MESSAGE";
			public static final String OPERATION_CODE = "OPERATION_CODE";
			public static final String CURRENCY_CODE = "CURRENCY_CODE";

			public static final class OriginatorId {
				public static final String ORIGINATOR_ID_CITY_CODE = "ORIGINATOR_ID_CITY_CODE";
				public static final String ORIGINATOR_ID_BRANCH_CODE = "ORIGINATOR_ID_BRANCH_CODE";
				public static final String ORIGINATOR_ID_OFFICE_CODE = "ORIGINATOR_ID_OFFICE_CODE";
				public static final String ORIGINATOR_ID_USER_CODE = "ORIGINATOR_ID_USER_CODE";
			}

			public static final String RESPONSE_CODE = "RESPONSE_CODE";
			public static final String MT = "MT";
			public static final String INSTITUTION_ID = "INSTITUTION_ID";
			public static final String PRIMARY_BM = "PRIMARY-BM";
			public static final String TRANS_DATE_TIME = "TRANS_DATE_TIME";
			public static final String TRANS_DATE = "TRANS_DATE";
			public static final String COMPANY_ID = "COMPANY_ID";
			public static final String RECORD_NUMBER = "RECORD_NUMBER";
			public static final String GW_INTERNAL_ERROR_CODE = "GWERR";
			public static final String GW_INTERNAL_ERROR_DESC = "GWERR";

		}
	}
	public static final class AveaDoInvoiceCollectionServices {
		public static final String SERVICE_NAME = "ICS_AVEA_DO_INVOICE_COLLECTION";

		public static final class Input {
			public static final String MT = "MT";
			public static final String PRIMARY_BM = "PRIMARY-BM";
			public static final String OPERATION_CODE = "OPERATION_CODE";
			public static final String TRANS_DATE_TIME = "TRANS_DATE_TIME";
			public static final String STAN = "STAN";
			public static final String TRANS_DATE = "TRANS_DATE";
			public static final String COMPANY_ID = "COMPANY_ID";
			public static final String CAPTURE_DATE = "CAPTURE_DATE";
			public static final String INSTITUTION_ID = "INSTITUTION_ID";
			public static final String OPERATION_SOURCE = "OPERATION_SOURCE";
			public static final String CURRENCY_CODE = "CURRENCY_CODE";
			public static final String ACCEPTENCE_DATE = "ACCEPTENCE_DATE";
			public static final String ORIGINATOR_ID = "ORIGINATOR_ID";

			public static final class OriginatorId {
				public static final String ORIGINATOR_ID_CITY_CODE = "ORIGINATOR_ID_CITY_CODE";
				public static final String ORIGINATOR_ID_BRANCH_CODE = "ORIGINATOR_ID_BRANCH_CODE";
				public static final String ORIGINATOR_ID_OFFICE_CODE = "ORIGINATOR_ID_OFFICE_CODE";
				public static final String ORIGINATOR_ID_USER_CODE = "ORIGINATOR_ID_USER_CODE";
			}

			public static final String BILL_INFO = "BILL_INFO";
			public static final String RECORD_NUMBER = "RECORD_NUMBER";
			public static final String REFERENCE_INFO = "REFERENCE_INFO";
			public static final String RELOAD_INFORMATION="RELOAD_INFORMATION";
			public static final String RELOAD_INFORMATION_COMMISSION="RELOAD_INFORMATION_COMMISSION";
			public static final String RELOAD_INFORMATION_ORDER_FLAG="RELOAD_INFORMATION_ORDER_FLAG";
			public static final String NORMAL_CUT_INFORMATION="NORMAL_CUT_INFORMATION";
			public static final String NORMAL_CUT_INFORMATION_UNIT="NORMAL_CUT_INFORMATION_UNIT";
			public static final String NORMAL_CUT_INFORMATION_AMOUNT="NORMAL_CUT_INFORMATION_AMOUNT";
			
			public static final class BillInfo {
				public static final String BILL_INFO_CUSTOMER_ACCESS_TYPE = "BILL_INFO_CUSTOMER_ACCESS_TYPE";
				public static final String BILL_INFO_PHONE_NO = "BILL_INFO_PHONE_NO";
				public static final String BILL_INFO_CUSTOMER_NO = "BILL_INFO_CUSTOMER_NO";
				public static final String BILL_INFO_NAME_SURNAME = "BILL_INFO_NAME_SURNAME";
				public static final String BILL_INFO_TYPE = "BILL_INFO_TYPE";
				public static final String BILL_INFO_TERM = "BILL_INFO_TERM";
				public static final String BILL_INFO_EXPIRY_DATE = "BILL_INFO_EXPIRY_DATE";
				public static final String BILL_INFO_REF_NO = "BILL_INFO_REF_NO";
				public static final String BILL_INFO_NO = "BILL_INFO_NO";
				public static final String BILL_INFO_SEQ_NO = "BILL_INFO_SEQ_NO";
				public static final String BILL_INFO_AMOUNT = "BILL_INFO_AMOUNT";
				public static final String BILL_INFO_STAN = "BILL_INFO_STAN";
				public static final String BILL_INFO_ORDER_NO = "BILL_INFO_ORDER_NO";
			}
			
			public static final class ReferenceInfo {
				public static final String REFERENCE_INFO_STAN = "REFERENCE_INFO_STAN";
				public static final String REFERENCE_INFO_PROCESS_DATE = "REFERENCE_INFO_PROCESS_DATE";
				public static final String REFERENCE_INFO_PROCESS_ORDER_NO = "REFERENCE_INFO_PROCESS_ORDER_NO";
				public static final String REFERENCE_INFO_BANK_CODE = "REFERENCE_INFO_BANK_CODE";
				public static final String REFERENCE_INFO_MERCHANT_ID = "REFERENCE_INFO_MERCHANT_ID";
				public static final String REFERENCE_INFO_AUTH_CODE = "REFERENCE_INFO_AUTH_CODE";
			}
		}

		public static final class Output {
			public static final String MT = "MT";
			public static final String PRIMARY_BM = "PRIMARY-BM";

			public static final String OPERATION_CODE = "OPERATION_CODE";
			public static final String TRANS_DATE_TIME = "TRANS_DATE_TIME";
			public static final String STAN = "STAN";
			public static final String TRANS_DATE = "TRANS_DATE";
			public static final String COMPANY_ID = "COMPANY_ID";
			public static final String INSTITUTION_ID = "INSTITUTION_ID";
			public static final String RESPONSE_CODE = "RESPONSE_CODE";

			public static final class OriginatorId {
				public static final String ORIGINATOR_ID_CITY_CODE = "ORIGINATOR_ID_CITY_CODE";
				public static final String ORIGINATOR_ID_BRANCH_CODE = "ORIGINATOR_ID_BRANCH_CODE";
				public static final String ORIGINATOR_ID_OFFICE_CODE = "ORIGINATOR_ID_OFFICE_CODE";
				public static final String ORIGINATOR_ID_USER_CODE = "ORIGINATOR_ID_USER_CODE";
			}

		}
	}
	
	public static final class VodafoneCommonServices {
		public static final class Input {
			public static final String RECON_OPERATION_COUNT = "RECON_OPERATION_COUNT";
			public static final String ACCEPTENCE_DATE = "ACCEPTENCE_DATE";

		}

	}
	
	public static final class AveaCommonServices {
		public static final class Input {
			public static final String RECON_OPERATION_COUNT = "RECON_OPERATION_COUNT";
			public static final String ACCEPTENCE_DATE = "ACCEPTENCE_DATE";

		}

	}

	public static final class VodafoneReconService {
		public static final class Input {
			public static final String SETTLEMENT_CURRENCY_CODE = "SETTLEMENT_CURRENCY_CODE";

			public static final String RECON_INFO = "RECON_INFO";

			public static final class ReconInfo {
				public static final String RECON_INFO_TRANS_CODE = "RECON_INFO_TRANS_CODE";
				public static final String RECON_INFO_TOTAL_TRANS = "RECON_INFO_TOTAL_TRANS";
				public static final String RECON_INFO_TOTAL_TRANS_AMOUNT = "RECON_INFO_TOTAL_TRANS_AMOUNT";
				public static final String RECON_INFO_TRANS_STATE = "RECON_INFO_TRANS_STATE";
			}
		}

	}
	
	public static final class AveaReconService {
		public static final class Input {
			public static final String SETTLEMENT_CURRENCY_CODE = "SETTLEMENT_CURRENCY_CODE";

			public static final String RECON_INFO = "RECON_INFO";

			public static final class ReconInfo {
				public static final String RECON_INFO_TRANS_CODE = "RECON_INFO_TRANS_CODE";
				public static final String RECON_INFO_TOTAL_TRANS = "RECON_INFO_TOTAL_TRANS";
				public static final String RECON_INFO_TOTAL_TRANS_AMOUNT = "RECON_INFO_TOTAL_TRANS_AMOUNT";
				public static final String RECON_INFO_TRANS_STATE = "RECON_INFO_TRANS_STATE";
			}
		}

	}
}
