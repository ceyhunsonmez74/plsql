package tr.com.aktifbank.bnspr.cps.multithreading.implementations;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CorporateAccountTransferInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.PartialParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ServiceBasedMultiThreading;
import tr.com.calikbank.bnspr.util.StringUtil;

public final class AccountTransferImplementation extends
		ServiceBasedMultiThreading {

	public AccountTransferImplementation(CorporateAccountTransferInformation information) {
		super();
		this.information = information;
	}
	
	private CorporateAccountTransferInformation information;

	@Override
	protected void prepareCall() throws Throwable {
		for (String corporateCode : information.getCorporates()) {
			GMMap transferCorporateAccountRequest = new GMMap();
			transferCorporateAccountRequest.put(TransactionConstants.TransferCorporateAccount.Input.CORPORATE_CODE, corporateCode);
			transferCorporateAccountRequest.put(TransactionConstants.TransferCorporateAccount.Input.PROCESS_DATE, information.getProcessDate());
			transferCorporateAccountRequest.put(TransactionConstants.TransferCorporateAccount.Input.TRANSFER_TYPE, information.getTransferType());
			if(!StringUtil.isEmpty(information.getFromAccountType())){
				transferCorporateAccountRequest.put("FROM_ACCOUNT_TYPE", information.getFromAccountType());
			}
			super.registerService(information.getServiceName(), transferCorporateAccountRequest);
		}
	}
	
	@Override
	protected ParallelCallBehaviour getParallelCallBehaviour() {
		return new PartialParallelCallBehaviour(information.getParallelLoopCount(), true);
	}

}
