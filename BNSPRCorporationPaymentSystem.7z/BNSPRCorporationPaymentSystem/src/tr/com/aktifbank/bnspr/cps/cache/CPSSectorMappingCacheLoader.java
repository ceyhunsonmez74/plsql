package tr.com.aktifbank.bnspr.cps.cache;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.dao.CsSectorMapping;

import com.graymound.cache.GMCacheLoader;

public class CPSSectorMappingCacheLoader implements GMCacheLoader {

	private static final Log logger = LogFactory.getLog(CPSSectorMappingCacheLoader.class);
	
	public CPSSectorMappingCacheLoader() {
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> load() {
		Map<String, Object> map = new ConcurrentHashMap<String, Object>();
		
		try {
			List<CsSectorMapping> sectors = CommonHelper.getHibernateSession().createCriteria(CsSectorMapping.class)
					.list();
			
			for (CsSectorMapping csSectorMapping : sectors) {
				if (!map.containsKey(csSectorMapping.getCsSectorCode())) {
					map.put(csSectorMapping.getCsSectorCode(), csSectorMapping);
				}
				if (!map.containsKey(csSectorMapping.getKftSectorCode())) {
					map.put(csSectorMapping.getKftSectorCode(), csSectorMapping);
				}
			}
		} catch (Exception e) {
			logger.error("An exception occured while loading SectorMapping cache");
			logger.error(System.currentTimeMillis(), e);
		}
		
		return map;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object lookup(String arg0) {
		try {
			List<CsSectorMapping> sectorMappings = CommonHelper.getHibernateSession()
					.createCriteria(CsSectorMapping.class)
					.add(Restrictions.disjunction()
							.add(Restrictions.eq("csSectorCode", arg0))
							.add(Restrictions.eq("kftSectorCode", arg0)))
					.list();
			
			if(sectorMappings != null){
				if(sectorMappings.size() == 1){
					return sectorMappings.get(0);
				}
				else{
					if(sectorMappings.size() > 1){
						logger.error(String.format("More than one record returned for %s argument", arg0));
						return null;
					}
					else{
						logger.warn(String.format("No record returned for %s argument", arg0));
						return null;
					}
				}
			}
			else{
				return null;
			}
		} catch (Exception e) {
			logger.error(String.format("An exception occured while looking up for %s argument", arg0));
			logger.error(System.currentTimeMillis(), e);
			return null;
		}
		
	}

}
