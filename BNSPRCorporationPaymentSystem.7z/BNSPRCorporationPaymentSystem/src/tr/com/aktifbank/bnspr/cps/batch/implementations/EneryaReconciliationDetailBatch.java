package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.client.EneryaClient;
import tr.com.aktifbank.integration.client.ServiceMessage;

import com.energaz.FICA.MutabakatDetay.DT_FICA_WS_BA_CHECK2_Res;
import com.energaz.FICA.MutabakatDetay.DT_FICA_WS_BA_CHECK2_ResOUTITEM;
import com.graymound.util.GMMap;

public final class EneryaReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(EneryaReconciliationDetailBatch.class);
	public static final String BNKKD = "143";
	public static final String BNODK = "06";
	Session session;
	List<DT_FICA_WS_BA_CHECK2_ResOUTITEM> details;
	ServiceMessage message;
	Map<String, DT_FICA_WS_BA_CHECK2_ResOUTITEM> indexedCorporateRecords;

	public EneryaReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, DT_FICA_WS_BA_CHECK2_ResOUTITEM>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.SUBSCRIBER_NO1, details.get(corporateRecordIndex).getVKONT());
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getMATBU());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String BUKRS = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String DATE = formatDate(input.getString(MapKeys.RECON_DATE));
					
			DT_FICA_WS_BA_CHECK2_Res allDetails = EneryaClient.mutabakatDetay(username, password, url, BUKRS, BNKKD, DATE, this.message);
			
			details = new ArrayList<DT_FICA_WS_BA_CHECK2_ResOUTITEM>();
			for(DT_FICA_WS_BA_CHECK2_ResOUTITEM md : allDetails.getOUT()){
				details.add(md);
			}			
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	private String formatDate(String str) {
		String returnDate="";
		try {
			returnDate=CommonHelper.getDateString(CommonHelper.getDateTime(str, "yyyyMMdd"), "yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return returnDate;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getMATBU());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getMATBU(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getMATBU());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		DT_FICA_WS_BA_CHECK2_ResOUTITEM corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Abone Numaras� : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getVKONT(), 
				corporateDetail.getMATBU(), 
				corporateDetail.getTOTAL_AMNT()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(CommonHelper.trimStart(corporateDetail.getVKONT(), '0'));
		payment.setInvoiceNo(corporateDetail.getMATBU());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getTOTAL_AMNT()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getTOTAL_AMNT()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getVKONT());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getMATBU());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getTOTAL_AMNT());
	}

}
