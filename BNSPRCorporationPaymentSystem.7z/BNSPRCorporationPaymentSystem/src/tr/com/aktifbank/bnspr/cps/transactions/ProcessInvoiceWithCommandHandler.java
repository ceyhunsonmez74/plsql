package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentSkipListSet;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.SingleInstanceMemory;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class ProcessInvoiceWithCommandHandler extends RequestHandler {

	private static final String COLLECTION_TYPE_COLUMN = "COLLECTION_TYPE";
	private static final String TABLE_NAME="TEMPORARY_TABLE";
	
	private static final class BagKeys{
		public static final Short OPENED_CONNECTION = 1;
		public static final Short OPENED_STATEMENT = 2;
	}
	
	public ProcessInvoiceWithCommandHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String step = ""; 
		String subMessage = "";
		try {
			if(input.containsKey(TransactionConstants.ProcessInvoiceWithCommand.Input.DIRECT_INSERT) && input.getBoolean(TransactionConstants.ProcessInvoiceWithCommand.Input.DIRECT_INSERT)){
				Connection connection = null;
				Statement statement = null;
				
				int notLoadedCount = 0;
				BigDecimal notLoadedAmount = BigDecimal.ZERO;
				
				connection = CommonHelper.getConnection();
				super.bag.put(BagKeys.OPENED_CONNECTION, connection);
				statement = connection.createStatement();
				super.bag.put(BagKeys.OPENED_STATEMENT, statement);
				
				String submitId = input.getString(TransactionConstants.ProcessInvoiceWithCommand.Input.SUBMIT_ID);
				boolean controlInvoiceNo = input.getBoolean(TransactionConstants.ProcessInvoiceWithCommand.Input.CONTROL_INVOICE_NO);
				boolean controlInvoiceDueDate = input.getBoolean(TransactionConstants.ProcessInvoiceWithCommand.Input.CONTROL_INVOICE_DUE_DATE);
				
				ConcurrentSkipListSet<String> indicatorList = (ConcurrentSkipListSet<String>)SingleInstanceMemory.getInstance().getCacheObject(submitId);
				


				step = "Started";
				for (int i = 0; i < input.getSize(TransactionConstants.ProcessInvoiceWithCommand.Input.INSERT_PAIR_TABLE); i++) {
					GMMap directInsertMap = (GMMap)input.get(TransactionConstants.ProcessInvoiceWithCommand.Input.INSERT_PAIR_TABLE, 
							i, 
							TransactionConstants.ProcessInvoiceWithCommand.Input.INSERT_KEYVALUE_PAIRS);
					
					subMessage = directInsertMap.toString();
					
					String command = directInsertMap.getString(TransactionConstants.ProcessInvoiceWithCommand.Input.COMMAND);
					
					directInsertMap.remove(TransactionConstants.ProcessInvoiceWithCommand.Input.COMMAND);
					
					if(controlInvoiceNo && !directInsertMap.containsKey("INVOICE_NO")){
						throw new Exception("Fatura kay�t bilgilerinde fatura numaras� bulunamad�. E�er kurumun dosyas�nda fatura numaras� bilgisi bulunmuyorsa l�tfen " +
								"Batch Y�netim Ekran�nda FATURA_NO_KONTROL_ET parametresini HAYIR olarak ekleyiniz.");
					}
					
					if(controlInvoiceDueDate && !directInsertMap.containsKey("INVOICE_DUE_DATE")){
						throw new Exception("Fatura kay�t bilgilerinde son �deme tarihi bulunamad�. E�er kurumun dosyas�nda son �deme tarihi bilgisi bulunmuyorsa l�tfen " +
								"Batch Y�netim Ekran�nda SON_ODEME_TARIHI_KONTROL_ET parametresini HAYIR olarak ekleyiniz.");
					}
					
					String invoiceNo = controlInvoiceNo ? directInsertMap.getString("INVOICE_NO") : "";
					String dueDate = controlInvoiceDueDate ? directInsertMap.getString("INVOICE_DUE_DATE") : "";
					BigDecimal amount = directInsertMap.getBigDecimal("AMOUNT");
					String subscriberNo1 = directInsertMap.getString("SUBSCRIBER_NO1");
					String subscriberNo2 = directInsertMap.getString("SUBSCRIBER_NO2", null);
					String subscriberNo3 = directInsertMap.getString("SUBSCRIBER_NO3", null);
					String subscriberNo4 = directInsertMap.getString("SUBSCRIBER_NO4", null);
					
					if(command.equals(DatabaseConstants.InvoiceProcessingCommands.Delete)){
						deleteRecord(statement, controlInvoiceNo, directInsertMap,
								invoiceNo, dueDate, amount, subscriberNo1,
								subscriberNo2, subscriberNo3, subscriberNo4);
					}
					else if(command.equals(DatabaseConstants.InvoiceProcessingCommands.Insert)){
						if(!insertRecord(input, controlInvoiceNo, controlInvoiceDueDate, invoiceNo, dueDate, amount, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, 
								indicatorList, directInsertMap, statement, true)){
							notLoadedCount++;
							notLoadedAmount = notLoadedAmount.add(directInsertMap.getBigDecimal("AMOUNT"));
							continue;
						}
					}
					else if(command.equals(DatabaseConstants.InvoiceProcessingCommands.Update)){
						String oid = getInvoiceRecordOid(controlInvoiceNo,
								invoiceNo, subscriberNo1, subscriberNo2,
								subscriberNo3, subscriberNo4);
						if(!StringUtil.isEmpty(oid)){
							String deleteQuery = "UPDATE ICS.INVOICE_MAIN SET STATUS=0 WHERE OID='" + oid + "'";
							statement.addBatch(deleteQuery);
							insertRecord(input, controlInvoiceNo, controlInvoiceDueDate, invoiceNo, dueDate, amount, subscriberNo1, subscriberNo2, 
									subscriberNo3, subscriberNo4, indicatorList, directInsertMap, statement, false);
						}
						else{
							logger.warn("Invoice not found for update process with paramaters : " + directInsertMap.toString());
						}
					}
					else{
						throw new Exception(String.format("%s invoice process command is not recognized as an internal command."));
					}
				}
				
				step = "Executing batch";
				statement.executeBatch();
				
				
				
				output.put(TransactionConstants.ProcessInvoiceWithCommand.Output.RETURN_CODE, 0);
				output.put("NOT_INSERTED_COUNT", notLoadedCount);
				output.put("NOT_INSERTED_AMOUNT", notLoadedAmount);
			}
			else{
				throw new BatchComponentException("No implementation found other than direct insert at inser invoice handler", BusinessException.SYSTEM);
			}
		} catch (Exception e) {
			logger.error(String.format("An exception occured while inserting invoices with subMessage : %s, step : %s .", subMessage, step));
			logger.error(System.currentTimeMillis(), e);
			output.put(TransactionConstants.ProcessInvoiceWithCommand.Output.RETURN_CODE, 1);
			output.put(TransactionConstants.ProcessInvoiceWithCommand.Output.RETURN_MESSAGE, "Fatura kay�tlar�n� eklerken bir hata olu�tu : " + e.toString());
		}
	}

	private String getInvoiceRecordOid(boolean controlInvoiceNo,
			String invoiceNo, String subscriberNo1, String subscriberNo2,
			String subscriberNo3, String subscriberNo4) throws Exception {
		List<Object> parameters = new ArrayList<Object>();
		StringBuilder getInvoiceOidQueryBuilder = new StringBuilder();
		getInvoiceOidQueryBuilder.append("SELECT im.OID FROM ICS.INVOICE_MAIN im WHERE im.STATUS=1 AND im.SUBSCRIBER_NO1=?");
		parameters.add(BnsprType.STRING);
		parameters.add(subscriberNo1);
		if(controlInvoiceNo){
			getInvoiceOidQueryBuilder.append(" AND im.INVOICE_NO=?");
			parameters.add(BnsprType.STRING);
			parameters.add(invoiceNo);
		}
		if(!StringUtil.isEmpty(subscriberNo2)){
			getInvoiceOidQueryBuilder.append(" AND im.SUBSCRIBER_NO2=?");
			parameters.add(BnsprType.STRING);
			parameters.add(subscriberNo2);
		}
		if(!StringUtil.isEmpty(subscriberNo3)){
			getInvoiceOidQueryBuilder.append(" AND im.SUBSCRIBER_NO3=?");
			parameters.add(BnsprType.STRING);
			parameters.add(subscriberNo3);
		}
		if(!StringUtil.isEmpty(subscriberNo4)){
			getInvoiceOidQueryBuilder.append(" AND im.SUBSCRIBER_NO4=?");
			parameters.add(BnsprType.STRING);
			parameters.add(subscriberNo4);
		}
		
		GMMap returnMap = CommonHelper.queryData(getInvoiceOidQueryBuilder.toString(), TABLE_NAME, parameters.toArray());
		if(returnMap.size() > 0){
			return returnMap.getString(TABLE_NAME, 0, "OID");
		}
		else{
			return null;
		}
	}

	private void deleteRecord(Statement statement, boolean controlInvoiceNo,
			GMMap directInsertMap, String invoiceNo, String dueDate,
			BigDecimal amount, String subscriberNo1, String subscriberNo2,
			String subscriberNo3, String subscriberNo4) throws Exception {
		String oid = getInvoiceRecordOid(controlInvoiceNo, invoiceNo, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4);
		
		if(!StringUtil.isEmpty(oid)){
			String updateQuery = "UPDATE ICS.INVOICE_MAIN SET STATUS=0 WHERE OID='" + oid + "'"; 
			//logger.info(updateQuery);
			statement.addBatch(updateQuery);
		}
		else{
			logger.warn("Invoice not found for deletion process with paramaters : " + directInsertMap.toString());
		}
	}
	
	private boolean insertRecord(GMMap input, boolean controlInvoiceNo, boolean controlInvoiceDueDate, String invoiceNo, String dueDate, BigDecimal amount, String subscriberNo1, String subscriberNo2,
			String subscriberNo3, String subscriberNo4, ConcurrentSkipListSet<String> indicatorList, GMMap directInsertMap, Statement statement, boolean controlDuplicate) throws SQLException{
		String corporateCode = input.getString(TransactionConstants.ProcessInvoiceWithCommand.Input.CORPORATE_CODE);
		
		if (controlDuplicate) {
			String indicator = "";
			if (controlInvoiceNo) {
				indicator = indicator.concat(invoiceNo);
			}
			if (controlInvoiceDueDate) {
				indicator = indicator.concat(dueDate);
			}
			indicator = indicator.concat(amount.toPlainString());
			indicator = indicator.concat(subscriberNo1);
			if (!StringUtil.isEmpty(subscriberNo2)) {
				indicator = indicator.concat(subscriberNo2);
			}
			if (!StringUtil.isEmpty(subscriberNo3)) {
				indicator = indicator.concat(subscriberNo3);
			}
			if (!StringUtil.isEmpty(subscriberNo4)) {
				indicator = indicator.concat(subscriberNo4);
			}
			if (indicatorList.contains(indicator)) {
				logger.info(String.format(
						"Invoice with %s map exists on database",
						directInsertMap.toString()));
				return false;
			}
		}
		StringBuilder columnNameBuilder = new StringBuilder();
		StringBuilder valueBuilder = new StringBuilder();
		boolean collectionTypeExists = false;
		for(Object key : directInsertMap.keySet()){
			if(((String)key).equals(COLLECTION_TYPE_COLUMN)){
				collectionTypeExists = true;
			}
			columnNameBuilder.append(String.format("%s,", key));
			Object value = directInsertMap.get(key);
			if(value instanceof String){
				valueBuilder.append(String.format("'%s',", value));
			}
			else if(value instanceof Date){
				valueBuilder.append(String.format("'%s',", CommonHelper.getShortDateTimeString((Date)value)));
			}
			else{
				valueBuilder.append(String.format("%s,", value));
			}
		}
		String query = String.format("INSERT INTO ICS.INVOICE_MAIN(OID,CORPORATE_CODE,%s,STATUS,PAYMENT_METHOD,LOADING_DATE,LOADING_USER,FTM_SEQUENCE_NUMBER,PAYMENT_STATUS,INVOICE_STATUS,PAYMENT_AMOUNT%s) VALUES('%s','%s',%s,0,'S','%s','%s',%s,'%s','%s',0%s)", 
				CommonHelper.trimEnd(columnNameBuilder.toString(), ','), 
				collectionTypeExists ? "" : String.format(",%s", COLLECTION_TYPE_COLUMN),
				UUID.randomUUID().toString().substring(0, 32),
				corporateCode,
				CommonHelper.trimEnd(valueBuilder.toString(), ','),
				CommonHelper.getLongDateTimeString(new Date()),
				CommonHelper.getCurrentUser(),
				input.getBigDecimal(TransactionConstants.ProcessInvoiceWithCommand.Input.FTM_TRANSFER_ID),
				DatabaseConstants.PaymentStatuses.Waiting,
				DatabaseConstants.InvoiceStatuses.Active,
				collectionTypeExists ? "" : String.format(",%s", DatabaseConstants.CollectionTypes.InvoiceLoad));
		//logger.info(query);
		statement.addBatch(query);
		return true;
	}
	
	@Override
	protected void handleFinally(GMMap output) {
		try{
			CommonHelper.closeAll(super.bag.get(BagKeys.OPENED_STATEMENT), super.bag.get(BagKeys.OPENED_CONNECTION));
		}
		catch(Exception e){
			logger.error("An exception occured while closing statement and connection");
			logger.error(System.currentTimeMillis(), e);
		}
	}

}
