package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.cps.common.QueryRepository.DeleteWaitedInvoiceHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;

import com.graymound.util.GMMap;

public final class DeleteWaitedInvoiceHandler extends RequestHandler {

	public DeleteWaitedInvoiceHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.DeleteWaitedInvoice.Input.CORPORATE_CODE);
		BigDecimal ftmTransferId = input.getBigDecimal(TransactionConstants.DeleteWaitedInvoice.Input.FTM_TRANSFER_ID); 
		String query = String.format(DeleteWaitedInvoiceHandlerRepository.UPDATE_INVOICE_STATUS_COMMAND, ftmTransferId, corporateCode, PaymentStatuses.Waiting);
		super.getHibernateSession().createSQLQuery(query).executeUpdate();

	}

}
