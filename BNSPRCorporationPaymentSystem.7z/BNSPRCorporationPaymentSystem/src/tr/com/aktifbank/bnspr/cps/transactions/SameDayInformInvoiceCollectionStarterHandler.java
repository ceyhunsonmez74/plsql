package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.BatchSubmitLog;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class SameDayInformInvoiceCollectionStarterHandler extends
		RequestHandler {

	public SameDayInformInvoiceCollectionStarterHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Date currentDate = new Date();
		
		List<CorporateBatchProcess> processList = super.getHibernateSession().createCriteria(CorporateBatchProcess.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("batchName", DatabaseConstants.BatchNames.SameDayInformInvoiceCollectionBatch))
				.list();
		
		boolean forceStart = input.getBoolean("FORCE_START", false);
		
		for (CorporateBatchProcess process : processList) {
			try {
				boolean shouldStart = false;
				if(forceStart){
					shouldStart = true;
				}
				else{
					String textParameter = process.getTextParameter();
					if(StringUtil.isEmpty(textParameter)){
						throw new Exception("Text parameter is null for same day collection inform corporate with code ".concat(process.getCorporateCode()));
					}
					int hour = Integer.valueOf(textParameter.split("\\:")[0]);
					int minute = Integer.valueOf(textParameter.split("\\:")[1]);
					int currentHour = CommonHelper.getHour(currentDate);
					int currentMinute = CommonHelper.getMinute(currentDate);
					
					if(currentHour > hour){
						shouldStart = true;
					}
					else if(currentHour == hour && currentMinute >= minute) {
						shouldStart = true;
					}
					else {
						shouldStart = false;
					}
					
					if(shouldStart){
						Number countOfLog = ((Number)super.getHibernateSession().createCriteria(BatchSubmitLog.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("corporateCode", process.getCorporateCode()))
								.add(Restrictions.eq("submitDate", CommonHelper.getShortDateTimeString(currentDate)))
								.setProjection(Projections.rowCount())
								.uniqueResult());
						if(countOfLog != null && countOfLog.intValue() > 0){
							shouldStart = false;
						}
					}
				}
				
				if(shouldStart){
					input.put(TransactionConstants.INFORM_BATCH_DATE_GENERAL_KEY, currentDate);
					input.put(TransactionConstants.INFORM_BATCH_CORPORATE_CODE_GENERAL_KEY, process.getCorporateCode());
					input.put(TransactionConstants.INFORM_BATCH_INDICATOR_GENERAL_KEY, GeneralConstants.INFORM_COLLECTIONS);
					CommonBusinessOperations.executeBatchStarterHandler(input, output, DatabaseConstants.TransferTypes.SameDayCollectionInform, super.getHibernateSession());
				}
			} catch (Exception e) {
				logger.error("An exception occured when informing collections for corporate with code ".concat(process.getCorporateCode()));
				logger.error(System.currentTimeMillis(), e);
			}
		}
	}

}
