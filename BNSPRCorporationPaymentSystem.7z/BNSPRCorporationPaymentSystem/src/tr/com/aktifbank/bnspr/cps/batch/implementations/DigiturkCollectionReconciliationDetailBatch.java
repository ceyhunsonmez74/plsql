package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.integration.digiturk.client.DigiturkClient;
import tr.com.aktifbank.integration.digiturk.messages.PGWPaymentReconDetailResponse.PostpaidTranInfo;

import com.graymound.util.GMMap;

public final class DigiturkCollectionReconciliationDetailBatch extends
		CollectionReconciliationDetailBatch {

	DigiturkClient client;
	List<PostpaidTranInfo> transactionInfoList;
	Map<String, PostpaidTranInfo> indexedCorporateRecords;
	
	static final short PROCESS_SOURCE = 3;
	static final short EXIST_FILE_INQUIRY_TYPE = 1;
	static final short COLLECTION_RECON_DETAIL_FILE_TYPE = 3;
	static final short FILE_INQUIRY_MESSAGE_TYPE = 200;
	static final short FILE_INQUIRY_PROCESS_CODE = 41;
	static final short CANCEL_INVOICE_PROCESS_CODE = 21;
	
	static final int DIGITURK_SUCCESS_CODE = 0;
	static final int DIGITURK_FILE_NEED_TO_BE_COMPILED = 6002;
	
	static final String DIGITURK_FILE_INQUIRY_STAN = "DIGITURK_FILE_INQUIRY_STAN";
	static final String DIGITURK_PAYMENT_RECON_DETAIL_STAN = "DIGITURK_PAY_REC_DETAIL_STAN";

	private static final int MAX_WHILE_LOOP_COUNT = 5;
	
	public DigiturkCollectionReconciliationDetailBatch(DigiturkClient client, GMMap input) {
		super(input);
		this.client = client;
		transactionInfoList = new ArrayList<PostpaidTranInfo>();
		indexedCorporateRecords = new HashMap<String, PostpaidTranInfo>();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		PostpaidTranInfo info = this.transactionInfoList.get(corporateRecordIndex);
		collectionDetailRequest.put(MapKeys.PARAMETER8, info.getSTAN());
		collectionDetailRequest.put(MapKeys.INVOICE_NO, info.getBillNumber());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		// No need to be problem.
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO).concat(bankRecord.getString(MapKeys.PARAMETER8)));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()
			throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		
		boolean keepLoop = false;
		boolean interruptLoop = false;
		int loopCounter = 0;
		tr.com.aktifbank.integration.digiturk.messages.PGWFileInquiryResponse.PGWResponseMessage fileInquiryResponse;
		
		do{
			int stanForFileInquiry = Integer.valueOf(CorporationServiceUtil.getSequenceCode(DIGITURK_FILE_INQUIRY_STAN));
			
			fileInquiryResponse = client.fileInfoInquiry(PROCESS_SOURCE, this.input.getDate(MapKeys.RECON_DATE), EXIST_FILE_INQUIRY_TYPE, 
					COLLECTION_RECON_DETAIL_FILE_TYPE, stanForFileInquiry, FILE_INQUIRY_MESSAGE_TYPE, FILE_INQUIRY_PROCESS_CODE);
			
			this.input.put(String.format("REQUEST_XML_FILE_INQUIRY%s", loopCounter), client.getServiceMessage().getRequest());
			this.outputMap.put(String.format("RESPONSE_XML_FILE_INQUIRY%s", loopCounter), client.getServiceMessage().getResponse());
			
			if(fileInquiryResponse.getHeader().getResponseCode() == DIGITURK_SUCCESS_CODE){
				keepLoop = false;
			}
			else if(fileInquiryResponse.getHeader().getResponseCode() == DIGITURK_FILE_NEED_TO_BE_COMPILED){
				keepLoop = true;
				Thread.sleep(120000);
			}
			else{
				interruptLoop = true;
			}
		}while(keepLoop && !interruptLoop && loopCounter++ < MAX_WHILE_LOOP_COUNT);
		
		if(interruptLoop){
			result.setSuccessfulCall(false);
			result.setReturnCode("Dosya bilgileri al�n�rken bir hata olu�tu : " + fileInquiryResponse.getHeader().getResponseCode() + "-" + 
						fileInquiryResponse.getHeader().getResponseExplanation());
		}
		else{
			if(loopCounter >= MAX_WHILE_LOOP_COUNT){
				result.setSuccessfulCall(false);
				result.setReturnCode("Mutabakats�zl�k dosyas� belirlenen bekleme s�resi i�erisinde olu�mad�");
			}
			else{
				short pageCount = fileInquiryResponse.getData().getPageCount();
				String fileName = fileInquiryResponse.getData().getFileName();
				int refStan = fileInquiryResponse.getData().getSTAN();
				
				for (short i = 1; i <= pageCount; i++) {
					int reconStan = Integer.valueOf(CorporationServiceUtil.getSequenceCode(DIGITURK_PAYMENT_RECON_DETAIL_STAN));
					tr.com.aktifbank.integration.digiturk.messages.PGWPaymentReconDetailResponse.PGWResponseMessage response =
							client.getPaymentReconDetail(PROCESS_SOURCE, i, reconStan, refStan, fileName);
					this.input.put(String.format("REQUEST_XML_RECON_DETAIL%s", i), client.getServiceMessage().getRequest());
					this.outputMap.put(String.format("RESPONSE_XML_RECON_DETAIL%s", i), client.getServiceMessage().getResponse());
					
					if(response.getHeader().getResponseCode() == DIGITURK_SUCCESS_CODE){
						List<PostpaidTranInfo> infoList = response.getData().getPostpaidTranList().getPostpaidTranInfo();
						for (PostpaidTranInfo info : infoList) {
							if(info.getProcessCode() != CANCEL_INVOICE_PROCESS_CODE){
								this.transactionInfoList.add(info);
							}
						}
						
						result.setSuccessfulCall(true);
					}
					else{
						result.setSuccessfulCall(false);
						result.setReturnCode(String.valueOf(response.getHeader().getResponseCode()).concat("-").concat(response.getHeader().getResponseExplanation()));
						return result;
					}
				}
			}
		}
		
		
		return result;
	}
	
	@Override
	protected void onFailedCorporateServiceCall(GMMap output,
			CorporateReconciliationDetailCallResult result) {
		output.put(MapKeys.ERROR_CODE, GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE);
		output.put(MapKeys.ERROR_DESC, result.getReturnCode());
		output.put(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM, result.getReturnCode());
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			GMMap bankRecord = super.getBankRecordAtIndex(i);
			super.setBankRecordIndex(bankRecord.getString(MapKeys.INVOICE_NO)
					.concat(bankRecord.getString(MapKeys.PARAMETER8)), bankRecord);
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (PostpaidTranInfo info : this.transactionInfoList) {
			this.indexedCorporateRecords.put(info.getBillNumber()
					.concat(String.valueOf(info.getSTAN())), info);
		}

	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		PostpaidTranInfo tranInfo = this.transactionInfoList.get(corporateRecordIndex);
		return super.doesExistWithKey(tranInfo.getBillNumber().concat(String.valueOf(tranInfo.getSTAN())));
	}

}
