package tr.com.aktifbank.bnspr.cps.acctransfer;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.dto.TransferInformation;
import tr.com.aktifbank.bnspr.dao.invoicePayment;

public class CorporateAccountTransferInformation implements
		IAccountTransferInformation {

	protected TransferInformation information;
	Date currentDate;
	protected boolean processBefore;
	
	public CorporateAccountTransferInformation(TransferInformation information) {
		this.information = information;
		this.currentDate = new Date();
		this.processBefore = false;
	}

	@Override
	public int getCount() {
		Criteria criteria = this.createCriteria() 
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", this.information.getCorporateCode()))
				.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
				.add(Restrictions.eq("corporateAccountNo", this.information.getCorporateAccountNo()))
				.add(Restrictions.isNull("balanceTransferDate"));
		
		if(this.processBefore){
			criteria = criteria.add(Restrictions.or(Restrictions.like("paymentDate", CommonHelper.getShortDateTimeString(this.information.getCollectionDate()), MatchMode.START),
					Restrictions.like("paymentDate", CommonHelper.getShortDateTimeString(CommonHelper.addDay(this.information.getCollectionDate(), -1)), MatchMode.START)));
		}
		else{
			criteria = criteria.add(Restrictions.like("paymentDate", CommonHelper.getShortDateTimeString(this.information.getCollectionDate()), MatchMode.START));
		}
		
		if (this.information.getCollectionTypes().size() > 0) {
			criteria = criteria.add(Restrictions.in("collectionType", this.information.getCollectionTypes()));
		}
		if (this.information.getChannelCodes().size() > 0) {
			criteria = criteria.add(Restrictions.in("paymentChannel", this.information.getChannelCodes()));
		}
		if (this.information.getSourceCodes().size() > 0) {
			criteria = criteria.add(Restrictions.in("paymentSource", this.information.getSourceCodes()));
		}
		criteria = criteria.setProjection(Projections.rowCount());
		return (Integer)criteria.uniqueResult();
	}

	@Override
	public BigDecimal getTotalAmount() {
		Criteria criteria = this.createCriteria()
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", this.information.getCorporateCode()))
				.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
				.add(Restrictions.eq("corporateAccountNo", this.information.getCorporateAccountNo()))
				.add(Restrictions.isNull("balanceTransferDate"));
		
		if(this.processBefore){
			criteria = criteria.add(Restrictions.or(Restrictions.like("paymentDate", CommonHelper.getShortDateTimeString(this.information.getCollectionDate()), MatchMode.START),
					Restrictions.like("paymentDate", CommonHelper.getShortDateTimeString(CommonHelper.addDay(this.information.getCollectionDate(), -1)), MatchMode.START)));
		}
		else{
			criteria = criteria.add(Restrictions.like("paymentDate", CommonHelper.getShortDateTimeString(this.information.getCollectionDate()), MatchMode.START));
		}
		
		if (this.information.getCollectionTypes().size() > 0) {
			criteria = criteria.add(Restrictions.in("collectionType", this.information.getCollectionTypes()));
		}
		if (this.information.getChannelCodes().size() > 0) {
			criteria = criteria.add(Restrictions.in("paymentChannel", this.information.getChannelCodes()));
		}
		if (this.information.getSourceCodes().size() > 0) {
			criteria = criteria.add(Restrictions.in("paymentSource", this.information.getSourceCodes()));
		}
		
		criteria = criteria.setProjection(Projections.sum("paymentAmount"));
		
		BigDecimal amount = (BigDecimal)criteria.uniqueResult();
		
		if(amount == null){
			return new BigDecimal(0);
		}
		else{
			return amount;
		}
	}
	
	protected Criteria createCriteria(){
		return this.information.getHibernateSession().createCriteria(invoicePayment.class);
	}

	@Override
	public void updateRecords() {
		StringBuilder query = new StringBuilder();
		query.append(getUpdatePart());
		query.append(String.format("SET BALANCE_TRANSFER_DATE = '%s' ", CommonHelper.getShortDateTimeString(currentDate)));
		query.append(String.format("WHERE STATUS = 1 AND CORPORATE_CODE = '%s' ", this.information.getCorporateCode()));
		query.append(String.format("AND PAYMENT_STATUS = '%s' ", DatabaseConstants.PaymentStatuses.Collected));
		if(this.processBefore){
			query.append(String.format("AND (PAYMENT_DATE LIKE '%s%%' OR PAYMENT_DATE LIKE '%s%%') ", 
					CommonHelper.getShortDateTimeString(this.information.getCollectionDate()),
					CommonHelper.getShortDateTimeString(CommonHelper.addDay(this.information.getCollectionDate(), -1))));
		}
		else{
			query.append(String.format("AND PAYMENT_DATE LIKE '%s%%' ", CommonHelper.getShortDateTimeString(this.information.getCollectionDate())));
		}
		query.append(String.format("AND CORPORATE_ACCOUNT_NO = %s ", this.information.getCorporateAccountNo().toPlainString()));
		query.append("AND (BALANCE_TRANSFER_DATE is null OR BALANCE_TRANSFER_DATE = '') ");
		int counter = 0;
		if(this.information.getCollectionTypes().size() != 0){
			query.append("AND COLLECTION_TYPE IN (");
			for (Short colType : this.information.getCollectionTypes()) {
				query.append(colType);
				if(counter++ < this.information.getCollectionTypes().size() - 1){
					query.append(",");
				}
			}
			query.append(") ");
		}
		if(this.information.getChannelCodes().size() != 0){
			query.append("AND PAYMENT_CHANNEL IN (");
			counter = 0;
			for (String channel : this.information.getChannelCodes()) {
				query.append(String.format("'%s'", channel));
				if(counter++ < this.information.getChannelCodes().size() - 1){
					query.append(",");
				}
			}
			query.append(") ");
		}
		if(this.information.getSourceCodes().size() != 0){
			query.append("AND PAYMENT_SOURCE IN (");
			counter = 0;
			for (String source : this.information.getSourceCodes()) {
				query.append(String.format("'%s'", source));
				if(counter++ < this.information.getSourceCodes().size() - 1){
					query.append(",");
				}
			}
			query.append(")");
		}
		
		this.information.getHibernateSession().createSQLQuery(query.toString()).executeUpdate();
	}
	
	protected String getUpdatePart(){
		return "UPDATE ics.INVOICE_PAYMENT ";
	}

}
