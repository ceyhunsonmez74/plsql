package tr.com.aktifbank.bnspr.cps.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public final class CorporateAccountTransferInformation extends
		BaseTransferObject {

	public CorporateAccountTransferInformation() {
		super();
		this.corporates = new ArrayList<String>();
	}
	
	List<String> corporates;
	String serviceName;
	int parallelLoopCount;
	Date processDate;
	String transferType;
	String fromAccountType;
	
	
	public String getFromAccountType() {
		return fromAccountType;
	}
	public void setFromAccountType(String fromAccountType) {
		this.fromAccountType = fromAccountType;
	}
	public String getTransferType() {
		return transferType;
	}
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}
	public Date getProcessDate() {
		return processDate;
	}
	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}
	public int getParallelLoopCount() {
		return parallelLoopCount;
	}
	public void setParallelLoopCount(int parallelLoopCount) {
		this.parallelLoopCount = parallelLoopCount;
	}
	public List<String> getCorporates() {
		return corporates;
	}
	public void setCorporates(List<String> corporates) {
		this.corporates = corporates;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	public void addToCorporates(String corporateCode){
		this.corporates.add(corporateCode);
	}
}
