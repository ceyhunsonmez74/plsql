package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import org.apache.commons.lang.NotImplementedException;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class ControlDueDateHandler extends RequestHandler {

	public ControlDueDateHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		boolean throwsExceptions = input.getBoolean(TransactionConstants.ControlDueDate.Input.THROWS_EXCEPTION, true);
		Date currentDate = CommonHelper.getDateTime(CommonHelper.getShortDateTimeString(input.getDate(TransactionConstants.ControlDueDate.Input.CURRENT_DATE)), "yyyyMMdd");
		String corporateCode = input.getString(TransactionConstants.ControlDueDate.Input.CORPORATE_CODE);
		String invoiceDueDate = input.getString(TransactionConstants.ControlDueDate.Input.INVOICE_DUE_DATE);
		if(!StringUtil.isEmpty(invoiceDueDate)){
			Date dueDate = CommonHelper.getDateTime(invoiceDueDate, "yyyyMMdd");
			if(currentDate.compareTo(dueDate) > 0){
				CorporateMaster corporateRecord = (CorporateMaster)super.getHibernateSession().createCriteria(CorporateMaster.class)
						.add(Restrictions.eq("corporateCode", corporateCode))
						.add(Restrictions.eq("status", true))
						.uniqueResult();
				if(corporateRecord != null){
					if(corporateRecord.isAllowAfterDueDate()){
						long daysPassed = CommonHelper.subtractDatesToDays(currentDate, dueDate);
						long timeCount = 0;
						if(corporateRecord.getCountTypeAfterDue().equals(DatabaseConstants.AfterDueCountTypes.Day)){
							timeCount = daysPassed;
						}
						else if(corporateRecord.getCountTypeAfterDue().equals(DatabaseConstants.AfterDueCountTypes.Week)){
							timeCount = daysPassed / 7;
						}
						else if(corporateRecord.getCountTypeAfterDue().equals(DatabaseConstants.AfterDueCountTypes.Month)){
							timeCount = daysPassed / 30;
						}
						else if(corporateRecord.getCountTypeAfterDue().equals(DatabaseConstants.AfterDueCountTypes.Year)){
							timeCount = daysPassed / 365;
						}
						else{
							throw new NotImplementedException(String.format("Calculation of time for %s count type has not been implemented", corporateRecord.getCountTypeAfterDue()));
						}
						if(timeCount <= corporateRecord.getCountAfterDue()){
							output.put(TransactionConstants.ControlDueDate.Output.RESULT, BusinessException.UNDEFINED.getCode());
						}
						else{
							throw new BatchComponentException(BusinessException.COUNTAFTERDUEHASPASSED, 
									corporateRecord.getShortCode(), 
									corporateRecord.getCountAfterDue(), 
									getCountTypeName(corporateRecord.getCountTypeAfterDue()));
						}
					}
					else{
						if(throwsExceptions){
							throw new BatchComponentException(BusinessException.CORPORATENOTALLOWAFTERDUEDATE, corporateRecord.getShortCode());
						}
						else{
							output.put(TransactionConstants.ControlDueDate.Output.RESULT, BusinessException.CORPORATENOTFOUND.getCode());
						}
					}
				}
				else{
					if(throwsExceptions){
						throw new BatchComponentException(BusinessException.CORPORATENOTFOUND, corporateCode);
					}
					else{
						output.put(TransactionConstants.ControlDueDate.Output.RESULT, BusinessException.CORPORATENOTFOUND.getCode());
					}
				}
			}
			else{
				output.put(TransactionConstants.ControlDueDate.Output.RESULT, BusinessException.UNDEFINED.getCode());
			}
		}
	}

	private String getCountTypeName(String countTypeAfterDue) {
		return CommonHelper.getValueOfParameter("CDM_TARIH_TURU", countTypeAfterDue);
	}

}
