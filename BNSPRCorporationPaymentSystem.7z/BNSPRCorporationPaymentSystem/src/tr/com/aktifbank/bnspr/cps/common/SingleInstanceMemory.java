package tr.com.aktifbank.bnspr.cps.common;

import java.util.concurrent.ConcurrentHashMap;

public class SingleInstanceMemory {

	private static final SingleInstanceMemory instance;
	
	static{
		instance = new SingleInstanceMemory();
	}
	
	private SingleInstanceMemory() {
		cachePairs = new ConcurrentHashMap<String, Object>();
	}

	public static final SingleInstanceMemory getInstance(){
		return instance;
	}

	private final ConcurrentHashMap<String, Object> cachePairs;

	public void createNewCache(String key, Object cacheObj) throws Exception {
		if (!this.cachePairs.containsKey(key)) {
			this.cachePairs.put(key, cacheObj);
		}
		else{
			throw new Exception(String.format("%s key present in SingleInstanceMemory pairs", key));
		}
	}
	
	public Object getCacheObject(String key){
		return this.cachePairs.get(key);
	}
	
	public void removeCache(String key){
		if(this.cachePairs.containsKey(key)){
			this.cachePairs.remove(key);
		}
	}
}
