package tr.com.aktifbank.bnspr.cps.multithreading.core;

import java.util.ArrayList;
import java.util.List;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.ParallelCallResult;

public final class PartialParallelCallBehaviour implements
		ParallelCallBehaviour {
	
	ParallelCallResult result;
	int parallelLoopCount;
	boolean keepCallAfterFail;
	
	public PartialParallelCallBehaviour(int parallelLoopCount, boolean keepCallAfterFail) {
		this.parallelLoopCount = parallelLoopCount;
		this.result = new ParallelCallResult();
		this.keepCallAfterFail = keepCallAfterFail;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void call(List<GMMap> tasks) {
		int taskCount = tasks.size();
		if(taskCount > parallelLoopCount){
			int counter = 0;
			List<GMMap> resultList = new ArrayList<GMMap>();
			boolean isAllSuccessful = true;
			while(taskCount >= parallelLoopCount){
				GMMap result = CommonHelper.callParallel(tasks.subList(counter * parallelLoopCount, (counter + 1) * parallelLoopCount));
				taskCount -= parallelLoopCount;
				counter++;
				resultList.addAll((List<GMMap>)result.get(TransactionConstants.ParallelCall.Output.T_RESULTS));
				isAllSuccessful = isAllSuccessful & result.getBoolean(TransactionConstants.ParallelCall.Output.T_SUCCESSFUL);
				if(!isAllSuccessful && !keepCallAfterFail){
					break;
				}
			}
			if(isAllSuccessful){
				if(taskCount != 0){
					GMMap result = CommonHelper.callParallel(tasks.subList(counter * parallelLoopCount, tasks.size()));
					resultList.addAll((List<GMMap>)result.get(TransactionConstants.ParallelCall.Output.T_RESULTS));
					isAllSuccessful = isAllSuccessful & result.getBoolean(TransactionConstants.ParallelCall.Output.T_SUCCESSFUL);
				}
			}
			else{
				if(keepCallAfterFail){
					GMMap result = CommonHelper.callParallel(tasks.subList(counter * parallelLoopCount, tasks.size()));
					resultList.addAll((List<GMMap>)result.get(TransactionConstants.ParallelCall.Output.T_RESULTS));
				}
			}
			
			this.result.setAllSuccessful(isAllSuccessful);
			this.result.setResults(resultList);
		}
		else{
			GMMap result = CommonHelper.callParallel(tasks);
			this.result.setAllSuccessful(result.getBoolean(TransactionConstants.ParallelCall.Output.T_SUCCESSFUL));
			this.result.setResults((List<GMMap>)result.get(TransactionConstants.ParallelCall.Output.T_RESULTS));
		}
	}

	@Override
	public ParallelCallResult getResult() {
		return this.result;
	}

}
