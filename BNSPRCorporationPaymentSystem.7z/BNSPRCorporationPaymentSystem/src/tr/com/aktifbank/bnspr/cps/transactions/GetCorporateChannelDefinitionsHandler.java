package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.ChannelSourceDef;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class GetCorporateChannelDefinitionsHandler extends RequestHandler {

	public GetCorporateChannelDefinitionsHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateOid = input.getString(TransactionConstants.GetCorporateChannelDefinitions.Input.CORPORATE_OID, null);
		String channelCode = input.getString(TransactionConstants.GetCorporateChannelDefinitions.Input.CHANNEL_CODE, null);
		String corporateCode = input.getString(TransactionConstants.GetCorporateChannelDefinitions.Input.CORPORATE_CODE, null);
		
		Criteria criteria = super.getHibernateSession().createCriteria(ChannelSourceDef.class)
				.add(Restrictions.eq("status", true));
		
		if(StringUtil.isEmpty(corporateOid)){
			corporateOid = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
					TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode)
					.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID);
		}
		
		criteria = criteria.add(Restrictions.eq("corporateOid", corporateOid));
		
		if(!StringUtil.isEmpty(channelCode)){
			criteria = criteria.add(Restrictions.eq("channelCode", channelCode));
		}
		
		List<ChannelSourceDef> definitions = criteria
				.list();
		
		int counter = 0;
		
		for (ChannelSourceDef channelSourceDef : definitions) {
			output.put(TransactionConstants.GetCorporateChannelDefinitions.Output.CHANNEL_TABLE, 
					counter, 
					TransactionConstants.GetCorporateChannelDefinitions.Output.CHANNEL_CODE, 
					channelSourceDef.getChannelCode());
			output.put(TransactionConstants.GetCorporateChannelDefinitions.Output.CHANNEL_TABLE, 
					counter, 
					TransactionConstants.GetCorporateChannelDefinitions.Output.SOURCE_CODE, 
					channelSourceDef.getSourceCode());
			output.put(TransactionConstants.GetCorporateChannelDefinitions.Output.CHANNEL_TABLE, 
					counter, 
					TransactionConstants.GetCorporateChannelDefinitions.Output.EXPLANATION, 
					channelSourceDef.getExplanation());
			counter++;
		}
	}

}
