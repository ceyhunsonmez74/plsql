package tr.com.aktifbank.bnspr.cps.acctransfer;

import java.util.Date;

public interface IDateCalcManipulationInformation extends
		IAccountTransferInformation {
	Date calculateDate();
}
