package tr.com.aktifbank.bnspr.cps.batch.implementations;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.corporation.services.OnlineCorporationInterface;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.util.GMMap;

public abstract class ReconciliationDetailBatch {
	
	private static final String WS_SEND_FAIL="0";
	public static final String WS_SEND_SUCCESSFUL="1";
	
	private static final Log logger = LogFactory.getLog(ReconciliationDetailBatch.class);

	protected GMMap input;
	protected GMMap outputMap;
	
	public ReconciliationDetailBatch(GMMap input) {
		this.input = input;
	}
	
	protected abstract CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception;
	protected abstract void callBankReconDetail() throws Exception;
	protected abstract void onBankRecordNotFound(int bankRecordIndex) throws Exception;
	protected abstract void onCorporateRecordNotFound(int corporateRecordIndex) throws Exception;
	protected abstract void indexBankRecords() throws Exception;
	protected abstract void indexCorporateRecords() throws Exception;
	protected abstract boolean doesBankRecordExistInCorporateRecords(int bankRecordIndex);
	protected abstract boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex);
	
	public GMMap runBatch(){
		GMMap output = new GMMap();
		outputMap = output;
		logger.info("Started to run reconciliation detail batch");
		try {
			CorporateReconciliationDetailCallResult result = this.callCorporateReconDetail();
			logger.info("Corporate Recon Detail Service Result : Is Successfull : " + String.valueOf(result.isSuccessfulCall()) + " Return Code : " + result.getReturnCode());
			if(result.isSuccessfulCall()){
				logger.info("Indexing corporate records");
				this.indexCorporateRecords();
				logger.info("Calling Bank Recon Detail");
				this.callBankReconDetail();
				logger.info("Indexing bank records");
				this.indexBankRecords();
				
				int corporateRecordCount = this.input.getInt(MapKeys.RECON_CORPORATE_COUNT);
				int bankRecordCount = this.input.getInt(MapKeys.RECON_BANK_COUNT);
				
				logger.info("Bank Record Count : " + String.valueOf(bankRecordCount) + " Corporate Record Count : " + String.valueOf(corporateRecordCount));
				
				if(bankRecordCount > corporateRecordCount){
					for(int i = 0; i < bankRecordCount; i++){
						boolean found = this.doesBankRecordExistInCorporateRecords(i);
						if(!found){
							logger.info(String.format("Bank Record Not Found In Corporate Records For Bank Record Index : %s", i));
							this.onBankRecordNotFound(i);
						}
					}
				}
				else if(corporateRecordCount > bankRecordCount) {
					for(int i = 0; i < corporateRecordCount; i++){
						boolean found = this.doesCorporateRecordExistInBankRecords(i);
						if(!found){
							logger.info(String.format("Corporate Record Not Found In Bank Records For Corporate Record Index : %s", i));
							this.onCorporateRecordNotFound(i);
						}
					}
				}
				else{
					// Do nothing for equal record counts
				}
			}
			else{
				onFailedCorporateServiceCall(output, result);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} 
		catch (Exception e) {
			onError(output, e);
		}
		finally{
			onFinally(output);
		}
		
		return output;
	}

	protected void onFailedCorporateServiceCall(GMMap output,
			CorporateReconciliationDetailCallResult result) {
		GMMap responseCodeMap = OnlineCorporationInterface.getResponseCodeMapping(result.getReturnCode(),
				input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.SERVICE_OID), this.input.getString(MapKeys.CORPORATE_CODE));
		
		output.put(MapKeys.ERROR_CODE, responseCodeMap.getString(MapKeys.ERROR_CODE));
		output.put(MapKeys.ERROR_DESC, responseCodeMap.getString(MapKeys.ERROR_DESC));
	}
	
	protected void onError(GMMap output, Exception e) {
		output.put(MapKeys.WS_SEND_STATUS, WS_SEND_FAIL);
		output.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_SYSTEM);
		output.put(MapKeys.ERROR_DESC, CommonHelper.getStringifiedException(e));
		throw ExceptionHandler.convertException(e);
	}
	
	protected void onFinally(GMMap output){
		OnlineCorporationInterface.insertOnlineServiceLog(this.input, output);
	}

	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex, GMMap collectionDetailResponse) {
	}

}
