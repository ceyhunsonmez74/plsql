package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.bedas.campaign.BedasCampaignClient;
import tr.com.aktifbank.integration.bedas.campaign.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;

import campaign.entity.TahsilatMutabakatDetayVersion2Result;

import com.graymound.util.GMMap;

public final class BedasCampaignReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(BedasCampaignReconciliationDetailBatch.class);
	Session session;
	ArrayList<TahsilatMutabakatDetayVersion2Result> details;
	ServiceMessage message;
	Map<String, TahsilatMutabakatDetayVersion2Result> indexedCorporateRecords;

	public BedasCampaignReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, TahsilatMutabakatDetayVersion2Result>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER_1, details.get(corporateRecordIndex).getThsIs());
		cancelCollectionRequest.put(MapKeys.PARAMETER_2, details.get(corporateRecordIndex).getThsNo());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			details = BedasCampaignClient.tahsilatMutabakatDetayVersion2(formatDate(input.getString(MapKeys.RECON_DATE)), "555", false, true, input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2), "34", input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD),
					input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), this.message,input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5));
			if (details.size() == 1) {
				if (!StringUtil.isEmpty(details.get(0).getT()) && "Error".equals(details.get(0).getT())) {
					result.setSuccessfulCall(false);
					result.setReturnCode("0");
					return result;
				}
			}
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	private String formatDate(String str) {
		String returnDate = "";
		try {
			returnDate = CommonHelper.getDateString(CommonHelper.getDateTime(str, "yyyyMMdd"), "yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return returnDate;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getThsNo());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.PARAMETER2));
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.PARAMETER2), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getThsNo(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getThsNo());
	}

	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex) throws Exception {
		TahsilatMutabakatDetayVersion2Result corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. ��letme Kodu : %s, Abone Numaras� : %s, ThsIs : %s, ThsNo : %s, Miktar : %s ", corporateDetail.getAIs(), corporateDetail.getANo(), corporateDetail.getThsIs(), corporateDetail.getThsNo(), corporateDetail.getTutar()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(corporateDetail.getAIs());
		payment.setSubscriberNo2(corporateDetail.getANo());
		payment.setParameter1(corporateDetail.getThsIs());
		payment.setParameter2(corporateDetail.getThsNo());
		payment.setParameter20("MANUEL_IPTAL_MUTABAKAT");
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");

		session.saveOrUpdate(payment);
		session.flush();

		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getAIs());
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO2, corporateDetail.getANo());
		collectionDetailResponse.put(MapKeys.PARAMETER1, corporateDetail.getThsIs());
		collectionDetailResponse.put(MapKeys.PARAMETER2, corporateDetail.getThsNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getTutar());
	}

}
