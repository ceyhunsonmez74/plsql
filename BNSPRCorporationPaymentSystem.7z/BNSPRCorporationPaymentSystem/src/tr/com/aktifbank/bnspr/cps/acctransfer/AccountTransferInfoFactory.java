package tr.com.aktifbank.bnspr.cps.acctransfer;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.dto.TransferInformation;

public final class AccountTransferInfoFactory {

	private static final AccountTransferInfoFactory instance;
	
	static {
		instance = new AccountTransferInfoFactory();
	}
	
	public static AccountTransferInfoFactory getInstance(){
		return instance;
	}
	
	private AccountTransferInfoFactory() {
		
	}
	
	public IAccountTransferInformation createInformation(String transferType, TransferInformation information) throws Exception {
		if(transferType.equals(DatabaseConstants.AccountTransferTypes.CorporateTransfer)){
			return new CorporateAccountTransferInformation(information);
		}
		else if(transferType.equals(DatabaseConstants.AccountTransferTypes.GSMCorporateTransfer)){
			return new GSMCorporateAccountTransferInformation(information);
		}
		else if(transferType.equals(DatabaseConstants.AccountTransferTypes.EKSCorporateTransfer)){
			return new EKSCorporateAccountTransferInformation(information);
		}
		else if(transferType.equals(DatabaseConstants.AccountTransferTypes.IskiCreditTransfer)){
			return new IskiCreditAccountTransferInformation(information);
		}
		else if(transferType.equals(DatabaseConstants.AccountTransferTypes.BlockedAccountTransfer)){
			return new BlockedAccountTransferInformation(information);
		}
		else if(transferType.equals(DatabaseConstants.AccountTransferTypes.TaxTransfer)){
			return new TaxAccountTransferInformation(information) ;
		}
		else if(transferType.equals(DatabaseConstants.AccountTransferTypes.SameDayTransfer)){
			return new SameDayAccountTransferInformation(information);
		}
		else if(transferType.equals(DatabaseConstants.AccountTransferTypes.GameOfChanceTransfer)){
			return new GameOfChanceAccountTransferInformation(information);
		}
		else{
			throw new Exception("Transfer type with ".concat(transferType).concat(" has not been implemented"));
		}
	}

}
