package tr.com.aktifbank.bnspr.cps.dto;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import tr.com.aktifbank.bnspr.cps.acctransfer.IAccountTransferInformation;
import tr.com.aktifbank.bnspr.dao.BalanceTransferProcess;

public class EftAtOnceInformation {
	public EftAtOnceInformation(){
		this.processList = new HashMap<String, BalanceTransferProcess>();
	}
	
	private Map<String, BalanceTransferProcess> processList;
	private BigDecimal amount;
	private TransferLogInformation information;
	private IAccountTransferInformation transferInformation;
	private String logRecordOid;
	
	public IAccountTransferInformation getTransferInformation() {
		return transferInformation;
	}
	public void setTransferInformation(
			IAccountTransferInformation transferInformation) {
		this.transferInformation = transferInformation;
	}
	public String getLogRecordOid() {
		return logRecordOid;
	}
	public void setLogRecordOid(String logRecordOid) {
		this.logRecordOid = logRecordOid;
	}
	public void addToProcessList(String logRecordOid, BalanceTransferProcess process){
		this.processList.put(logRecordOid, process);
	}
	public Map<String, BalanceTransferProcess> getProcessList(){
		return this.processList;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public TransferLogInformation getInformation() {
		return information;
	}
	public void setInformation(TransferLogInformation information) {
		this.information = information;
	}
	
	
}
