package tr.com.aktifbank.bnspr.cps.transactions;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.TransferTypes;

import com.graymound.util.GMMap;

public class InformInvoiceCollectionStarterHandler extends RequestHandler {

	public InformInvoiceCollectionStarterHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		CommonBusinessOperations.executeBatchStarterHandler(input, output, TransferTypes.CollectionInform, super.getHibernateSession());
	}

}
