package tr.com.aktifbank.bnspr.cps.util;

import tr.com.aktifbank.bnspr.cps.transactions.FtmBatchStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.MultiFileLoadingHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class FTMUtilities {

	@GraymoundService("ICS_FTM_BATCH_STARTER")
	public static GMMap ftmBatchStarter(GMMap FTMMap) {
		return RequestProcessor.getInstance().process(FTMMap,
				new FtmBatchStarterHandler());
	}
	
	@GraymoundService("ICS_FTM_MULTI_FILE_LOADING")
	public static GMMap ftmMultiFileLoading(GMMap input){
		return RequestProcessor.getInstance().process(input, new MultiFileLoadingHandler());
	}
}
