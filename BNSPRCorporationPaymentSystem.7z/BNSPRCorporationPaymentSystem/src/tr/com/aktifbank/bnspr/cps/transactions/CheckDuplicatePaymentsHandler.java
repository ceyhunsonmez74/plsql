package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Arrays;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;

import com.graymound.util.GMMap;

public class CheckDuplicatePaymentsHandler extends RequestHandler {
	private static final Log logger = LogFactory.getLog(CheckDuplicatePaymentsHandler.class);

	final String INVOICES = "RESULT_SET";
	final String OID_LIST = "OID_LIST";
	
	public CheckDuplicatePaymentsHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		input.put("CONTROL_TYPE", "SAME_INVOICE_NO");
		output = CommonHelper.callGraymoundServiceInHibernateSession("CDM_CM_RUN_DUPLICATE_CHECK", input);
		String mailBody = "FATURALAR<br />" +
						  "<table  border='1'>" +
						  "<tr>" +
						  	"<td>KURUM ADI</td>" +
						  	"<td>KURUM KODU</td>" +
						  	"<td>ABONE NO</td>" +
						  	"<td>FATURA NO</td>" +
						  	"<td>FATURA TUTARI</td>" +
						  	"<td>OID</td>" +
						  	"<td>TX_NO</td>" +
						  	"<td>TAKSIT NO</td>" +
						  "</tr>";
		boolean invoiceDuplicateFlag = false;
		for (int i = 0; i < output.getSize(INVOICES); i++) {
			GMMap output2 = new GMMap(), input2 = new GMMap();
			input2.put("CONTROL_TYPE", "SAME_INVOICE_NO");
			input2.put("INVOICE_NO", output.get(INVOICES, i, "INVOICE_NO"));
			output2 = CommonHelper.callGraymoundServiceInHibernateSession("CDM_CM_GET_INVOICE_DETAIL", input2);
			for (int j = 0; j < output2.getSize(INVOICES); j++) {
				mailBody +="<tr>" +
							"<td>"+output2.get(INVOICES, j, "SHORT_CODE")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "CORPORATE_CODE")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "SUBSCRIBER_NO")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "INVOICE_NO")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "PAYMENT_AMOUNT")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "OID")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "TX_NO")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "INSTALLMENT_NO")+"</td>" +
						   "</tr>";
				invoiceDuplicateFlag = true;
				logger.info("Duplicate Faturalar bulundu");
			}
		}
		mailBody+="</table><br /><br /><br />";
		
		input.put("CONTROL_TYPE", "SAME_SUBSCRIBER_GSM_MONEY_LOAD");
		output = CommonHelper.callGraymoundServiceInHibernateSession("CDM_CM_RUN_DUPLICATE_CHECK", input);
		mailBody += "TL YUKLEMELER<br />" +
				"<table  border='1'>" +
				  "<tr>" +
				  	"<td>KURUM ADI</td>" +
				  	"<td>KURUM KODU</td>" +
				  	"<td>ABONE NO</td>" +
				  	"<td>FATURA NO</td>" +
				  	"<td>FATURA TUTARI</td>" +
				  	"<td>OID</td>" +
				  	"<td>TX_NO</td>" +
				  	"<td>TAKSIT NO</td>" +
				  "</tr>";
		boolean moneyLoadDuplicateFlag = false;

		for (int i = 0; i < output.getSize(INVOICES); i++) {
			GMMap output2 = new GMMap(), input2 = new GMMap();
			input2.put("CONTROL_TYPE", "SAME_SUBSCRIBER_GSM_MONEY_LOAD");
			input2.put("INVOICE_NO", output.get(INVOICES, i, "INVOICE_NO"));
			output2 = CommonHelper.callGraymoundServiceInHibernateSession("CDM_CM_GET_INVOICE_DETAIL", input2);
			for (int j = 0; j < output2.getSize(INVOICES); j++) {
				mailBody +="<tr>" +
						 	"<td>"+output2.get(INVOICES, j, "SHORT_CODE")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "CORPORATE_CODE")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "SUBSCRIBER_NO")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "INVOICE_NO")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "PAYMENT_AMOUNT")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "OID")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "TX_NO")+"</td>" +
							"<td>"+output2.get(INVOICES, j, "INSTALLMENT_NO")+"</td>" +
						   "</tr>";
				moneyLoadDuplicateFlag = true;
				logger.info("Duplicate TL Yuklemeler bulundu");
			}
		}
		mailBody+="</table><br /><br /><br />";
		
		if(invoiceDuplicateFlag || moneyLoadDuplicateFlag){
			String emails = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_DAILY_DUPLICATE_CONTROL");
			CommonHelper.sendMail(Arrays.asList(emails.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "M�kerrer ��lem Kontrol batch'i i�in " + CommonHelper.getShortDateTimeString(new Date()) + " tarihli �al��ma raporu", mailBody);
			logger.info("Mail gonderimi " + emails + " adreslerine gerceklestirildi");
		}
	}
}
