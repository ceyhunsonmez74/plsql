package tr.com.aktifbank.bnspr.cps.common;

public final class QueryRepository {
	public static final class IskiServicesRepository {
		public static final String BRANCH_CODE_QUERY = "SELECT DISTINCT(PARAMETER2) AS BRANCH_CODE FROM ICS.INVOICE_PAYMENT WHERE STATUS=1 AND CORPORATE_CODE='%s' AND PAYMENT_STATUS='T' AND PAYMENT_DATE LIKE '%s%%' AND PARAMETER2 is not null";
	}

	public static final class CorporationManagementServicesRepository {
		public static final String CHANGE_SAF_STATUS = "update cdm.corporate_services set is_saf_service=%s where oid='%s'";
		public static final String DUPLICATE_INVOICE_CHECK_QUERY = "select invoice_no, payment_amount, count(invoice_no) RECORD_NUMBER from ics.invoice_payment where status=1 and payment_date like '%s%%' and payment_status = 'T' group by invoice_no,payment_amount having count(invoice_no) > 1 ";
		public static final String DUPLICATE_MONEY_LOAD_QUERY = "select subscriber_no invoice_no, payment_amount, count(subscriber_no) RECORD_NUMBER from ics.gsm_money_load where status=1 and payment_date like '%s%%' and payment_status = 'T' group by subscriber_no,payment_amount having count(subscriber_no) > 1 ";
		public static final String GET_INVOICE_DETAIL = "select ip.oid,ip.corporate_code,ip.subscriber_no1,ip.invoice_no,ip.payment_amount,ip.tx_no,cm.short_code,ip.installment_no,ip.rec_owner,ip.status from ics.invoice_payment ip,cdm.corporate_master cm where ip.status=1 and ip.payment_status='T' and ip.corporate_code=cm.corporate_code and ip.invoice_no='%s' and payment_date like '%s%%'";
		public static final String GET_MONEY_LOAD_DETAIL = "select gml.oid,gml.corporate_code,gml.subscriber_no subscriber_no1, '',gml.payment_amount,gml.tx_no,cm.short_code,gml.rec_owner from ics.gsm_money_load gml,cdm.corporate_master cm where gml.corporate_code=cm.corporate_code and gml.subscriber_no='%s' and gml.payment_date like '%s%%'";
		public static final String GET_ACCOUNT_MATCHING_GET_ACCOUNT_LIST = "select mh.hesap_no,mh.iban,mh.musteri_no, mh.sube_kodu,mh.modul_tur_kod,mh.urun_tur_kod, case when ws.sorguya_acik is null then '0' else ws.sorguya_acik end AS sorguya_acik,ws.kullanici_kodu,ws.sifre from bnspr.muh_hesap mh left join "
				+ " CDM.CORPORATE_WS_ACCOUNT_MATCHING ws on mh.iban = ws.iban and mh.musteri_no =ws.musteri_no where mh.musteri_no = '%s'";
		public static final String DELETE_ACCOUNT_MATCHING = "DELETE FROM CDM.corporate_ws_account_matching WHERE MUSTERI_NO='%s'";
		public static final String GET_WS_USER = "select * from cdm.corporate_ws_users where musteri_No=%s";
	}

	public static final class IskiCreditAccountTransferInformationRepository {
		public static final String BALANCE_TRANSFER_UPDATE_QUERY = "UPDATE ICRS.CREDIT_LOAD SET BALANCE_TRANSFER_DATE='%s' WHERE STATUS=1 AND PAYMENT_STATUS='T' AND CUSTOMER_TYPE='1' AND PAYMENT_DATE='%s' AND BALANCE_TRANSFER_DATE is null";
	}

	public static final class InformStandingOrdersFileBatchRepository {
		public static final String RECORD_FETCH_QUERY = "SELECT * FROM sto.STANDING_ORDER_MAIN som INNER JOIN ics.ICS_STANDING_ORDERS iso ON som.OID = iso.STANDING_ORDER_OID INNER JOIN sto.STANDING_ORDER_ACCOUNT soa ON som.OID = soa.STANDING_ORDER_OID WHERE som.STATUS=1 AND iso.STATUS=1 AND som.%s LIKE '%s%%' AND iso.CORPORATE_CODE = '%s' AND som.STANDING_ORDER_STATUS = '%s'";
	}

	public static final class CPSBatchUtilitiesRepository {
		public static final String NOTIFY_BEF_PAYMENT_SELECT_QUERY = "SELECT cast(im.OID as VARCHAR2(32)),cast(im.STANDING_ORDER_OID as VARCHAR2(32)),som.NOTFY_BY_EMAIL,som.NOTIFY_BY_SMS,im.corporate_code,TO_DATE(im.INVOICE_DUE_DATE, 'yyyy/mm/dd'),im.subscriber_no1,im.subscriber_no2,im.amount,cast(iso.OID as VARCHAR2(32)),cast(som.OID as VARCHAR2(32)),cast(soa.OID as VARCHAR2(32))"
				+ " FROM ICS.INVOICE_MAIN im,ICS.ICS_STANDING_ORDERS iso,sto.standing_order_main som,sto.standing_order_account soa WHERE im.customer_no is not null and im.payment_status='B' AND im.STANDING_ORDER_OID=iso.STANDING_ORDER_OID and iso.STANDING_ORDER_OID is not null and im.status=1 and iso.status=1 and iso.standing_order_status=1"
				+ " AND som.oid=im.STANDING_ORDER_OID and som.oid=iso.STANDING_ORDER_OID and som.status=1 and som.standing_order_status=1 AND soa.STANDING_ORDER_OID=som.oid and soa.status=1 and soa.is_used=1 and soa.STANDING_ORDER_OID=im.STANDING_ORDER_OID and soa.STANDING_ORDER_OID=iso.STANDING_ORDER_OID AND som.NOTIFY_BEFORE_PAYMENT=1 and (som.NOTIFY_BY_SMS=1 or som.NOTFY_BY_EMAIL=1)"
				+ " AND (substr(im.loading_date,0,8)=im.INVOICE_DUE_DATE and to_char(sysdate,'yyyymmdd')=im.INVOICE_DUE_DATE ) or(im.INVOICE_DUE_DATE-substr(im.loading_date,0,8)=1 and im.INVOICE_DUE_DATE-to_char(sysdate,'yyyymmdd')=1)";

		public static final String NOTIFY_AFTER_PAYMENT_SELECT_QUERY = "SELECT cast(im.OID as VARCHAR2(32)),cast(im.STANDING_ORDER_OID as VARCHAR2(32)),som.NOTFY_BY_EMAIL,som.NOTIFY_BY_SMS,im.corporate_code,TO_DATE(im.INVOICE_DUE_DATE, 'yyyy/mm/dd'),im.subscriber_no1,im.subscriber_no2,im.payment_amount"
				+ ",cast(iso.OID as VARCHAR2(32)),cast(som.OID as VARCHAR2(32)),cast(soa.OID as VARCHAR2(32)) FROM ICS.INVOICE_PAYMENT im,ICS.ICS_STANDING_ORDERS iso,sto.standing_order_main som,sto.standing_order_account soa WHERE im.payment_status='T'"
				+ " and im.STANDING_ORDER_OID=iso.STANDING_ORDER_OID and iso.STANDING_ORDER_OID is not null and im.status=1 and iso.status=1 and iso.standing_order_status=1  and som.oid=im.STANDING_ORDER_OID and som.oid=iso.STANDING_ORDER_OID and som.status=1 and som.standing_order_status=1"
				+ " and soa.STANDING_ORDER_OID=som.oid and soa.status=1 and soa.is_used=1 and soa.STANDING_ORDER_OID=im.STANDING_ORDER_OID and soa.STANDING_ORDER_OID=iso.STANDING_ORDER_OID and som.NOTIFY_AFTER_PAYMENT=1 and (som.NOTIFY_BY_SMS=1 or som.NOTFY_BY_EMAIL=1) and im.INVOICE_DUE_DATE=to_char(sysdate,'yyyymmdd')";
		public static final String BULK_EMAIL_BEFORE_QUERY = "SELECT cm.short_code, soa.account_number, som.customer_no, im.subscriber_no1, im.subscriber_no2, im.subscriber_no3, " +
				"im.subscriber_name, im.invoice_due_date, im.amount " +
				"FROM sto.standing_order_main som LEFT JOIN sto.standing_order_account soa " +
				"ON som.OID = soa.STANDING_ORDER_OID " +
				"LEFT JOIN ics.invoice_main im " +
				"ON som.OID = im.STANDING_ORDER_OID " +
				"LEFT JOIN cdm.corporate_master cm " +
				"ON im.CORPORATE_CODE = cm.CORPORATE_CODE " +
				"WHERE som.status=1 AND som.standing_order_status='1' AND soa.status=1 AND som.customer_no = %s AND soa.account_number = %s " +
				"AND im.status=1 AND im.payment_status='B' AND im.invoice_due_date = '%s' AND cm.status=1 AND cm.corporate_activeness='A'";
		public static final String BULK_EMAIL_AFTER_QUERY = "SELECT cm.short_code, soa.account_number, som.customer_no, im.subscriber_no1, im.subscriber_no2, im.subscriber_no3, " +
				"im.subscriber_name, im.invoice_due_date, im.amount, im.payment_status, im.oid " +
				"FROM sto.standing_order_main som LEFT JOIN sto.standing_order_account soa " +
				"ON som.OID = soa.STANDING_ORDER_OID " +
				"LEFT JOIN ics.invoice_main im " +
				"ON som.OID = im.STANDING_ORDER_OID " +
				"LEFT JOIN cdm.corporate_master cm " +
				"ON im.CORPORATE_CODE = cm.CORPORATE_CODE " +
				"WHERE som.status=1 AND som.standing_order_status='1' AND soa.status=1 AND som.customer_no = %s AND soa.account_number = %s " +
				"AND im.status=1 AND cm.status=1 AND cm.corporate_activeness='A' AND im.invoice_due_date='%s'";
		public static final String DISTINCT_YIM_CORPORATES_QUERY = "SELECT DISTINCT cm.oid, cm.short_code, cm.sector_code " +
				"FROM cdm.channel_source_def csd INNER JOIN cdm.corporate_master cm ON csd.corporate_oid = cm.oid " +
				"WHERE csd.status=1 AND cm.status=1 AND cm.corporate_activeness='A' AND csd.channel_code='32'";
		public static final String INSERT_YIM_CORPORATE_FOR_RECEIPT_QUERY = "insert into BNSPR.v_ml_gnl_param_text(ID,KOD,KEY1,KEY2,KEY3,TEXT,SAYI,TARIH,SIRA_NO) " +
				"values (BNSPR.pkg_genel_pr.genel_kod_al('GNL_PARAM_TEXT'),'CS_KURUM_OID',?,?,'',?,null,null,5)";
	}

	public static final class ServiceWrapperRepository {
		public static final String FETCH_REC_OWNER_QUERY = "select p.rec_owner from ics.invoice_payment p where p.status = 1 and p.oid = \'%s\'";
		public static final String FETCH_BRANCH_CODE_QUERY = "select b.sube_adi from bnspr.gnl_sube_kod_pr b where b.kod = \'%s\'";
		public static final String FETCH_ACCOUNT_INFO_QUERY = "select h.hesap_no, h.kisa_isim, h.sube_kodu, h.doviz_kodu, h.musteri_no, h.iban from muh_hesap h where h.hesap_no = %s";
		public static final String GET_STANDING_ORDER_COUNT_QUERY = "select count(*) from ics.ics_standing_orders where standing_order_oid = \'%s\' and status = 1 and standing_order_status = 1 and collection_type = \'%s\'";
		public static final String UPDATE_INV_MAIN_QUERY = "UPDATE invoiceMain set ftmSequenceNumber = :newFtmSeqeunceNumber WHERE ftmSequenceNumber = :oldFtmSequenceNumber";
		public static final String FETCH_RECEIPT_NO_QUERY = "select fis_no from bnspr.cs_accounting_tx where  reference_id= \'%s\'";
		public static final String FETCH_CHANNEL_NAME_QUERY = "SELECT g.aciklama FROM bnspr.gnl_kanal_grup_kod_pr g WHERE g.kod IN ( select channel_code from ics.invoice_payment_log where  invoice_payment_oid= \'%s\')";
		public static final String FETCH_USER_NAME_QUERY = "Select user_code From ics.invoice_payment_log where invoice_payment_oid = \'%s\'";
		public static final String CALCULATE_TOTAL_COMM_AMOUNT = "SELECT SUM(ic.commission_amount) + SUM(ic.bsmv_amount) FROM ics.invoice_commission ic INNER JOIN " +
				"ics.invoice_payment ip ON ic.invoice_payment_oid=ip.oid INNER JOIN ics.invoice_payment_log ipl ON ip.oid=ipl.invoice_payment_oid " +
				"WHERE ipl.payment_status='I' AND ipl.cashback_trx_no=%s AND ipl.cancel_status='%s'";
	}

	public static final class AveaServicesRepository {
		public static final String GET_DETAIL_FTM_FILE_CONTENT = "select * from (select tahsilat.invoice_no,tahsilat.payment_amount,case when tahsilat.sayacTahsilat > iptal.sayacIptal then 'T' else 'I' end as payment_status,tahsilat.subscriber_no1,tahsilat.subscriber_no2,tahsilat.parameter9 from (select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
				+ "sayacTahsilat,subscriber_no1,subscriber_no2,parameter9 from ics.recon_detail_data where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '%s' and recon_log_oid = '%s' and transaction_type = 'T' group by invoice_no,transaction_type,payment_amount,"
				+ "subscriber_no1,subscriber_no2,parameter9 order by invoice_no, transaction_type desc) tahsilat,(select invoice_no,transaction_type,payment_amount,Count(transaction_type) sayacIptal,subscriber_no1,subscriber_no2,parameter9 from ics.recon_detail_data where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '%s' "
				+ "and recon_log_oid = '%s' and transaction_type = 'I' group by invoice_no,transaction_type,payment_amount,subscriber_no1,subscriber_no2,parameter9 order by invoice_no, transaction_type desc) iptal where tahsilat.invoice_no = iptal.invoice_no union select invoice_no,payment_amount,transaction_type as "
				+ "payment_status,subscriber_no1, subscriber_no2,parameter9 from ics.recon_detail_data where collection_type='0' and transaction_type = 'T' and status = 1 and corporate_code = '%s' and "
				+ "recon_log_oid = '%s' and invoice_no not in (select invoice_no from ics.recon_detail_data where collection_type='0' and transaction_type = 'I' and status = 1 and corporate_code = '%s' and recon_log_oid = '%s')) where payment_status='T'";

		public static final String GET_BANK_STANDING_ORDERS = "select * from sto.standing_order_main sm,ics.ics_standing_orders so where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('%s', 'dd/MM/yyyy')"
				+ " and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('%s', 'dd/MM/yyyy') and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='%s' and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'";
	}

	public static final class EdasServicesRepository {
		public static final String GET_BANK_STANDING_ORDERS = "SELECT subscriber_no1,subscriber_no2 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code ='%s' AND m.create_date LIKE '%s%%'";
		public static final String GET_STANDING_ORDER_DETAIL = "SELECT subscriber_no1,subscriber_no2, count(*) as count FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code='%s' AND m.create_date LIKE '%s%%' group by subscriber_no1,subscriber_no2 ";
		public static final String GET_BANK_CANCELLED_STANDING_ORDERS = "SELECT subscriber_no1,subscriber_no2 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code='%s' AND m.cancel_date LIKE '%s%%'";
		public static final String GET_BANK_CANCELLED_STANDING_ORDERS_DETAIL = "SELECT subscriber_no1,subscriber_no2 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code='%s' AND m.cancel_date LIKE '%s%%'";
		public static final String GET_BANK_CORPORATE_STANDING_ORDERS_CANCEL = "SELECT subscriber_no1,subscriber_no2, transaction_type as PAYMENT_STATUS FROM ics.recon_detail_data WHERE collection_type ='0' AND status = 1 AND corporate_code = '%s' AND recon_log_oid = '%s' AND transaction_type='I' ";
		public static final String GET_CORPORATE_STANDING_ORDERS = "SELECT subscriber_no1,subscriber_no2, transaction_type as PAYMENT_STATUS FROM ics.recon_detail_data WHERE collection_type ='0' AND status = 1 AND corporate_code = '%s' AND recon_log_oid = '%s' AND transaction_type='K' ";
		public static final String GET_CORPORATE_STANDING_ORDERS_DETAIL = "SELECT subscriber_no1,subscriber_no2, count(*) as count FROM ics.recon_detail_data WHERE collection_type ='0' AND status = 1 AND corporate_code = '%s' AND recon_log_oid = '%s' AND transaction_type='K' group by subscriber_no1,subscriber_no2 ";
		public static final String GET_CORPORATE_STANDING_ORDERS_CANCEL_DETAIL = "SELECT subscriber_no1,subscriber_no2, count(*) as count FROM ics.recon_detail_data WHERE collection_type ='0' AND status = 1 AND corporate_code = '%s' AND recon_log_oid = '%s' AND transaction_type='I' group by subscriber_no1,subscriber_no2 ";
	}

	public static final class BedasCampaignServicesRepository {
		public static final String GET_BANK_STANDING_ORDERS = "SELECT subscriber_no1,subscriber_no2 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code='%s' AND m.create_date LIKE '%s%%'";
		public static final String GET_BANK_STANDING_ORDERS_CANCEL = "SELECT subscriber_no1,subscriber_no2 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code='%s' AND m.cancel_date LIKE '%s%%'";

	}

	public static final class GaskiServicesRepository {
		public static final String GET_BANK_STANDING_ORDERS = "select * from sto.standing_order_main sm,ics.ics_standing_orders so where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('%s', 'dd/MM/yyyy') and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('%s', 'dd/MM/yyyy') and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='%s' and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'";
	}

	public static final class IskiBankAccountObservationServicesRepository {
		public static final String GET_ACCOUNT_LIST = "select IBAN from bnspr.muh_hesap where hesap_no in(select account_number from cdm.corporation_account_master where corporate_oid='%s' and status=1)";
		public static final String GET_ACCOUNT_LIST_FROM_DEFINITION = "SELECT * FROM cdm.corporate_ws_account_matching where musteri_no='%s' and sorguya_acik=1";
		public static final String GET_BRANCH_CODE = "select sube_kodu from bnspr.muh_hesap where iban='%s'";
	}

	public static final class KayseriWaterServicesRepository {
		public static final String GET_BANK_STANDING_ORDERS = "select * from sto.standing_order_main sm,ics.ics_standing_orders so where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('%s', 'dd/MM/yyyy') and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('%s', 'dd/MM/yyyy') and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='%s' and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'";
	}

	public static final class VodafoneServicesRepository {
		public static final String GET_FTM_FILE_CONTENT = "select * from (select tahsilat.invoice_no,tahsilat.payment_amount,case when tahsilat.sayacTahsilat > iptal.sayacIptal then 'T' else 'I' end as payment_status,tahsilat.subscriber_no1,tahsilat.subscriber_no2,tahsilat.parameter9 from (select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
				+ "sayacTahsilat,subscriber_no1,subscriber_no2,parameter9 from ics.recon_detail_data where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '%s' and recon_log_oid = '%s' and transaction_type = 'T' group by invoice_no,transaction_type,payment_amount,"
				+ "subscriber_no1,subscriber_no2,parameter9 order by invoice_no, transaction_type desc) tahsilat,(select invoice_no,transaction_type,payment_amount,Count(transaction_type) sayacIptal,subscriber_no1,subscriber_no2,parameter9 from ics.recon_detail_data where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '%s' "
				+ "and recon_log_oid = '%s' and transaction_type = 'I' group by invoice_no,transaction_type,payment_amount,subscriber_no1,subscriber_no2,parameter9 order by invoice_no, transaction_type desc) iptal where tahsilat.invoice_no = iptal.invoice_no union select invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1, "
				+ "subscriber_no2,parameter9 from ics.recon_detail_data where collection_type='0' and transaction_type = 'T' and status = 1 and corporate_code = '%s' and "
				+ "recon_log_oid = '%s' and invoice_no not in (select invoice_no from ics.recon_detail_data where collection_type='0' and transaction_type = 'I' and status = 1 and corporate_code = '%s' and recon_log_oid = '%s')) where payment_status='T'";
		public static final String GET_BANK_STANDING_ORDERS = "select * from sto.standing_order_main sm,ics.ics_standing_orders so where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('%s', 'dd/MM/yyyy') and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('%s', 'dd/MM/yyyy') and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='%s' and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'";

	}

	public static final class GatewayManagementServicesRepository {
		public static final String GET_CORPORATE_DEFINITION = "SELECT OID,corporation_name FROM ICS.GW_CORPORATION_DEFINITION";
		public static final String GET_GW_OPERATION_CODE = "SELECT OID,operation_name FROM ICS.GW_OPERATION_CODE";
		public static final String GW_TEMPLATE_MESSAGE = "select mf.map_name from ics.gw_message_structure ms,ics.gw_message_field mf where ms.operation_code_oid='%s' and ms.message_field_oid=mf.oid and message_type_oid=1 and mf.oid not in(select root from ics.gw_message_field)";
		public static final String GW_ADD_TEMPLATE_MESSAGE = "select mf2.map_name parent_name,mf.map_name from ics.gw_message_field mf,ics.gw_message_field mf2 where mf.root in(select mf.oid from ics.gw_message_structure ms,ics.gw_message_field mf where ms.operation_code_oid='%s' and ms.message_field_oid=mf.oid and message_type_oid=1 and mf.oid in(select root from ics.gw_message_field)) and mf.root=mf2.oid";
		public static final String LOAD_CORPORATE_OPERATIONS = "select coc.oid,oc.operation_name,oc.oid OCS_OID from ics.gw_corporation_operation_code coc,ics.gw_corporation_definition cd,ics.gw_operation_code oc where coc.corporation_definition_oid=cd.oid and oc.oid=coc.operation_code_oid and coc.corporation_definition_oid=%s";
	}

	public static final class ADAWaterServicesRepository {
		public static final String GET_COLLECTION_RECON_SQL = "select subscriber_no1,invoice_no, count(*), sum(payment_amount/2) from ICS.INVOICE_PAYMENT where corporate_code = :corporateCode and payment_date like :paymentDate group by subscriber_no1,invoice_no having count(*) > 1";
	}

	public static final class AgdasGasServicesRepository {
		public static final String GET_BANK_STANDING_ORDER = "select * from sto.standing_order_main sm,ics.ics_standing_orders so where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('%s', 'dd/MM/yyyy') and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('%s', 'dd/MM/yyyy') and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='%s' and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1'  and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'";
	}

	public static final class DicleServicesRepository {
		public static final String GET_BANK_STANDING_ORDER = "select * from sto.standing_order_main sm,ics.ics_standing_orders so where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('%s', 'dd/MM/yyyy') and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('%s', 'dd/MM/yyyy') and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='%s'"
				+ " and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1'  and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'";
	}

	public static final class KcetasOnlineServicesRepository {
		public static final String GET_FTM_DETAIL = "select distinct invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1 from ics.recon_detail_data where status = 1 and corporate_code = '%s' and recon_log_oid = '%s' and transaction_type = 'G' and transaction_type is not null";
		public static final String GET_BANK_STANDING_ORDER = "select * from sto.standing_order_main sm,ics.ics_standing_orders so where TO_DATE(to_char(sm.START_DATE ,'dd/MM/yyyy'))<=TO_DATE('%s', 'dd/MM/yyyy') and TO_DATE(to_char(sm.end_DATE  ,'dd/MM/yyyy'))>=TO_DATE('%s', 'dd/MM/yyyy') and so.standing_order_oid=sm.oid and so.CORPORATE_CODE='%s'"
				+ " and sm.STATUS=1 and sm.STANDING_ORDER_STATUS='1' and so.STATUS=1 and so.STANDING_ORDER_STATUS='1'";
	}

	public static final class OperatorServicesRepository {
		public static final String GET_MONEY_LOAD_RECORD = "select count(*) as COUNT, nvl(sum(payment_amount),0) as TOTAL_AMOUNT from ics.gsm_money_load where corporate_code = \'%s\' and status = '1' and trunc(to_date(payment_date, 'YYYYMMDDHH24MISS')) = to_date(\'%s\', 'YYYYMMDD')";
		public static final String GET_AVAILABLE_CORP_LIST = "select distinct cm.oid, cm.corporate_code, cm.short_code \n from cdm.corporate_master cm, cdm.corporation_account_master cam, cdm.account_collection_type_rel act \n where cm.oid = cam.corporate_oid and cam.oid = act.account_master_oid \n	and cm.status = 1 and cam.status = 1 and act.status = 1 \n"
				+ "	and act.collection_type = %s and act.channel_code = %s \n";
	}

	public static final class IgdasServicesRepository {
		public static final String RECON_DETAIL_STRING = "select tahsilat.invoice_no,tahsilat.payment_amount,case when tahsilat.sayacTahsilat > iptal.sayacIptal then 'T' else 'I' end as payment_status,tahsilat.subscriber_no1,tahsilat.subscriber_no2 from (select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
				+ "sayacTahsilat,subscriber_no1,subscriber_no2 from ics.recon_detail_data where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '%s' and recon_log_oid = '%s' and transaction_type = 'T' group by invoice_no,transaction_type,payment_amount,"
				+ "subscriber_no1,subscriber_no2 order by invoice_no, transaction_type desc) tahsilat,(select invoice_no,transaction_type,payment_amount,Count(transaction_type) sayacIptal,subscriber_no1,subscriber_no2 from ics.recon_detail_data where collection_type='0' and transaction_type is not null and status = 1 and corporate_code = '%s' "
				+ "and recon_log_oid = '%s' and transaction_type = 'I' group by invoice_no,transaction_type,payment_amount,subscriber_no1,subscriber_no2 order by invoice_no, transaction_type desc) iptal where tahsilat.invoice_no = iptal.invoice_no union select invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1, "
				+ "subscriber_no2 from ics.recon_detail_data where collection_type='0' and transaction_type = 'T' and status = 1 and corporate_code = '%s' and recon_log_oid = '%s' and invoice_no not in (select invoice_no from ics.recon_detail_data where collection_type='0' and transaction_type = 'I' and status = 1 and corporate_code = '%s' and recon_log_oid = '%s') ";
		public static final String RECON_CONN_FEE_SQL = "select tahsilat.invoice_no,tahsilat.payment_amount,case when tahsilat.sayacTahsilat > iptal.sayacIptal then 'T' else 'I' end as payment_status,tahsilat.subscriber_no1,tahsilat.subscriber_no2,tahsilat.parameter1,tahsilat.parameter4 from (select invoice_no,transaction_type,payment_amount,Count(transaction_type) "
				+ "sayacTahsilat,subscriber_no1,subscriber_no2,parameter1,parameter4 from ics.recon_detail_data where collection_type='%s' and transaction_type is not null and status = 1 and corporate_code = '%s' and recon_log_oid = '%s' and transaction_type = 'T' group by invoice_no,transaction_type,payment_amount,"
				+ "subscriber_no1,subscriber_no2,parameter1,parameter4 order by invoice_no, transaction_type desc) tahsilat,(select invoice_no,transaction_type,payment_amount,Count(transaction_type) sayacIptal,subscriber_no1,subscriber_no2,parameter1,parameter4 from ics.recon_detail_data where collection_type='%s' and transaction_type is not null and status = 1 and corporate_code = '%s' "
				+ "and recon_log_oid = '%s' and transaction_type = 'I' group by invoice_no,transaction_type,payment_amount,subscriber_no1,subscriber_no2,parameter1,parameter4 order by invoice_no, transaction_type desc) iptal where tahsilat.invoice_no = iptal.invoice_no union select invoice_no,payment_amount,transaction_type as payment_status,subscriber_no1, "
				+ "subscriber_no2,parameter1,parameter4 from ics.recon_detail_data where collection_type='%s' and transaction_type = 'T' and status = 1 and corporate_code = '%s' and recon_log_oid = '%s' and invoice_no not in (select invoice_no from ics.recon_detail_data where collection_type='%s' and transaction_type = 'I' and status = 1 and corporate_code = '%s' and recon_log_oid = '%s') ";

		public static final String GET_BANK_STANDING_ORDERS = "SELECT subscriber_no1,subscriber_no2 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code='%s' AND m.create_date LIKE '%s%%'";
		public static final String GET_BANK_STANDING_ORDER_DETAIL = "SELECT subscriber_no1,subscriber_no2, count(*) as count FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code='%s' AND m.create_date LIKE '%s%%' group by subscriber_no1,subscriber_no2 ";
		public static final String GET_BANK_STANDING_ORDER_CANCEL = "SELECT subscriber_no1,subscriber_no2 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code='%s'AND m.cancel_date LIKE '%s%%'";
		public static final String GET_BANK_STANDING_ORDER_CANCEL_DETAIL = "SELECT subscriber_no1,subscriber_no2 FROM ics.ics_standing_orders i,sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code ='%s' AND m.cancel_date LIKE '%s%%'";
		public static final String GET_CORPORATE_CANCEL_STANDING_ORDERS = "SELECT subscriber_no1,subscriber_no2, transaction_type as PAYMENT_STATUS FROM ics.recon_detail_data WHERE collection_type ='0' AND status = 1 AND corporate_code = '%s' AND recon_log_oid = '%s' AND transaction_type='I' ";
		public static final String GET_CORPORATE_STANDING_ORDERS = "SELECT subscriber_no1,subscriber_no2, transaction_type as PAYMENT_STATUS FROM ics.recon_detail_data WHERE collection_type ='0' AND status = 1 AND corporate_code = '%s' AND recon_log_oid = '%s' AND transaction_type='K' ";
		public static final String GET_CORPORATE_STANDING_ORDER_DETAIL = "SELECT subscriber_no1,subscriber_no2, count(*) as count FROM ics.recon_detail_data WHERE collection_type ='0' AND status = 1 AND corporate_code = '%s' AND recon_log_oid = '%s' AND transaction_type='K' group by subscriber_no1,subscriber_no2 ";
		public static final String GET_CORPORATE_STANDING_ORDER_CANCEL_DETAIL = "SELECT subscriber_no1,subscriber_no2, count(*) as count FROM ics.recon_detail_data WHERE collection_type ='0' AND status = 1 AND corporate_code = '%s' AND recon_log_oid = '%s' AND transaction_type='I' group by subscriber_no1,subscriber_no2 ";
	}

	public static final class TurkcellServicesRepository {
		public static final String GET_BANK_PAYMENT = "SELECT subscriber_no1,payment_amount, total_amount FROM ics.invoice_payment,  (SELECT SUM(payment_amount) AS TOTAL_AMOUNT  FROM ics.invoice_payment  WHERE corporate_code ='%s' AND payment_date LIKE '%s%%' AND status=1) t  WHERE corporate_code ='%s' AND payment_date LIKE '%s%%' AND status=1";
		public static final String GET_BANK_PAYMENT_CANCEL = "SELECT subscriber_no1, payment_amount, total_amount FROM ics.invoice_payment , (SELECT SUM(payment_amount) AS TOTAL_AMOUNT  FROM ics.invoice_payment  WHERE corporate_code ='%s' AND cancel_date LIKE '%s%%' AND status=1 ) t WHERE corporate_code ='%s' AND cancel_date LIKE '%s%%' AND payment_status='I' AND status=1";
		public static final String GET_BANK_STANDING_ORDER = "SELECT subscriber_no1 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code ='%s' AND m.create_date LIKE '%s%%' AND i.status=1 and m.status=1";
		public static final String GET_BANK_STANDING_ORDER_CANCEL = "SELECT subscriber_no1 FROM ics.ics_standing_orders i, sto.STANDING_ORDER_MAIN m WHERE i.standing_order_oid=m.oid AND i.corporate_code ='%s' AND m.cancel_date LIKE '%s%%' AND i.status=1 and m.status=1";
	}

	public static final class CommonCorporationServicesRepository {
		public static final String GET_CORPORATES_FRONTED = "SELECT m.oid, m.corporate_name\n FROM cdm.corporate_master m INNER JOIN cdm.corporate_city_rel c ON m.oid = c.corporate_oid\n WHERE  m.status=1 AND c.status = 1 AND (c.is_public_corporate = 1 OR c.kod = %s)\n ORDER BY m.corporate_name";
		public static final String GET_COLLECTION_TYPES_FRONTED = "SELECT ctp.collection_type, ctp.collection_name FROM cdm.collection_type_def ctd INNER JOIN cdm.collection_type_prm ctp ON ctd.collection_type = ctp.collection_type WHERE ctd.status=1 AND ctd.corporate_oid='%s'"
				+"AND ctd.ALLOW_AUTO_COLLECTION=nvl(%s,ctd.ALLOW_AUTO_COLLECTION) AND ctd.is_appearance_payment_screen=nvl(%s,ctd.is_appearance_payment_screen)";
		public static final String GET_CMN_CITIES_FRONTED = "SELECT DISTINCT c.kod, c.il_adi FROM bnspr.gnl_il_kod_pr c ORDER BY c.int_sira, c.kod";
		public static final String COMMON_GET_SOURCES_FRONTED = "SELECT source_code, source_name FROM cdm.source_param WHERE source_code = :sourceCode ";
		public static final String COMMON_GET_SOURCE_ACCOUNT_FRONTED = "SELECT source_code, source_name FROM cdm.source_param WHERE source_code=";
		public static final String COMMON_GET_CORPORATE_SOURCE_FRONTED = "SELECT source_code, source_name FROM cdm.source_param WHERE ";
		public static final String GET_SOURCE_PARAM = "SELECT source_name FROM cdm.source_param WHERE source_code = '%s'";
		public static final String BLOCK_QUERY = "SELECT BLOKE_NEDEN_KODU, REF_TX_NO FROM BNSPR.MUH_BLOKE WHERE HESAP_NO=%s AND DURUM_KODU='A'";
		public static final String BLOCK_QUERY_WITH_REASON = "SELECT BLOKE_NEDEN_KODU, REF_TX_NO FROM BNSPR.MUH_BLOKE WHERE HESAP_NO=%s AND DURUM_KODU='A' AND BLOKE_NEDEN_KODU='16'";
	}

	public static final class CorporationBatchDefinitionServicesRepository {
		public static final String GET_BATCH_SUBMIT_LOG_QUERY = "SELECT bsl.oid, bsl.batch_name, bsl.batch_submit_id, bsl.corporate_code,cm.short_code, p.text submit_status, trunc(to_date(bsl.start_time, 'YYYYMMDDHH24MISS')) start_date, substr(bsl.start_time,9,6) start_time, trunc(to_date(bsl.end_time, 'YYYYMMDDHH24MISS')) end_date, substr(bsl.end_time,9,6) end_time, "
				+ "bsl.submit_user, trunc(to_date(bsl.submit_date, 'YYYYMMDDHH24MISS')) submit_date, bsl.error_code, bsl.error_desc, ftl.total_line_count, ftl.total_amount,ftl.total_load_count, ftl.total_load_amount FROM cdm.batch_submit_log bsl LEFT JOIN cdm.file_transfer_log ftl ON bsl.batch_submit_id=ftl.batch_submit_id "
				+ "INNER JOIN bnspr.v_ml_gnl_param_text p ON p.kod='CDM_BATCH_SUBMIT_STATUS' AND p.key1=bsl.submit_status INNER JOIN cdm.corporate_master cm ON cm.corporate_code=bsl.corporate_code WHERE bsl.status=1 AND bsl.batch_name = '%s' AND bsl.submit_date BETWEEN '%s' AND '%s'";
	}

	public static final class CorporationColoringRepository {
		public static final String GET_PREVIOUS_TX_NO = "select max(cm.tx_no) from %s cm join bnspr.muh_islem mi on cm.tx_no=mi.numara where cm.tx_no < %s and mi.durum in ('P','3')and cm.corporate_code='%s'";
		public static final String GET_CORPORATE_INFO_COLORING = "SELECT CORPORATE_NAME CORPORATE_NAME_COLOR,CORPORATE_ACTIVENESS CORPORATE_ACTIVENESS_COLOR,CORPORATE_BANK_CODE CORPORATE_BANK_CODE_COLOR,COUNT_TYPE_AFTER_DUE COUNT_TYPE_AFTER_DUE_COLOR,CUSTOMER_NUMBER CUSTOMER_NUMBER_COLOR,IF_DUE_DATE_HOLIDAY IF_DUE_DATE_HOLIDAY_COLOR,PROTOCOL_START_DATE PROTOCOL_START_DATE_COLOR,"
				+ "(SELECT SECTOR_NAME FROM CDM.SECTOR_DEF SD WHERE SD.SECTOR_CODE=CM.SECTOR_CODE AND SD.STATUS=1) SECTOR_NAME_COLOR,SHORT_CODE SHORT_CODE_COLOR,CM.ALLOW_PART_AFTER_DUE ALLOW_END_PAYMEND_COLOR,CM.COUNT_AFTER_DUE COUNT_AFTER_DUE_COLOR,CM.ALLOW_AFTER_DUE_DATE ALLOW_AFTER_PAYMEND_COLOR,"
				+ "CM.ALLOW_PART_PAYMENT ALLOW_BEFORE_PAYMEND_COLOR,CM.IS_ONLINE_CORPORATE IS_ONLINE_CORPORATE_COLOR,CM.CORPORATE_BUSINESS_CODE CORPORATE_BUSINESS_CODE_COLOR FROM CDM.CORPORATE_MASTER CM WHERE oid='%s' and cm.status=1";
		public static final String GET_CORPORATE_INFO_COLORING_NEW = "	SELECT CORPORATE_NAME CORPORATE_NAME_COLOR,CORPORATE_ACTIVENESS CORPORATE_ACTIVENESS_COLOR,CORPORATE_BANK_CODE CORPORATE_BANK_CODE_COLOR,COUNT_TYPE_AFTER_DUE COUNT_TYPE_AFTER_DUE_COLOR,CUSTOMER_NUMBER CUSTOMER_NUMBER_COLOR,IF_DUE_DATE_HOLIDAY IF_DUE_DATE_HOLIDAY_COLOR,PROTOCOL_START_DATE PROTOCOL_START_DATE_COLOR,"
				+ "(SELECT SECTOR_NAME FROM CDM.SECTOR_DEF SD WHERE SD.SECTOR_CODE=CM.SECTOR_CODE AND SD.STATUS=1) SECTOR_NAME_COLOR,SHORT_CODE SHORT_CODE_COLOR,CM.ALLOW_PART_AFTER_DUE ALLOW_END_PAYMEND_COLOR,CM.COUNT_AFTER_DUE COUNT_AFTER_DUE_COLOR,CM.ALLOW_AFTER_DUE_DATE ALLOW_AFTER_PAYMEND_COLOR,"
				+ "CM.ALLOW_PART_PAYMENT ALLOW_BEFORE_PAYMEND_COLOR,CM.IS_ONLINE_CORPORATE IS_ONLINE_CORPORATE_COLOR,CM.CORPORATE_BUSINESS_CODE CORPORATE_BUSINESS_CODE_COLOR FROM CDM.CORPORATE_MASTER_TX CM WHERE tx_no=%s";
		public static final String GET_CORPORATE_SELECTED_CITY = "SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel c WHERE c.status= 1 AND c.corporate_oid ='%s' AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI";
		public static final String GET_CORPORATE_SELECTED_CITY_NEW = "SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel_tx c WHERE c.tx_no =%s AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI";
		public static final String GET_CITY_OLD = "SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel c WHERE c.status= 1 AND c.corporate_oid ='%s'";
		public static final String GET_CITY_NEW = "SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel_tx c WHERE c.tx_no =%s";
		public static final String SUBSCRIBER_LIST = " SELECT subscriber.*,ii.oid IMAGE_OID from( SELECT d.oid maskDetailOid,f.corporate_oid,d.use_for_inquiry,p.collection_name,p.collection_type,d.label,d.mask,d.example,d.prefix,d.suffix,d.use_for_collection,d.use_for_standing_order,"
				+ " d.view_order,td.is_appearance_payment_screen as USE_PAYMENT_INVOICE_SCREEN, td.allow_auto_collection as USE_AUTOMATIC_PAYMENT FROM cdm.subscriber_mask_def f,cdm.collection_type_def td,cdm.subscriber_mask_detail d,cdm.collection_type_prm p WHERE f.corporate_oid = '%s' AND f.oid = d.mask_oid AND f.collection_type = p.collection_type "
				+ " AND f.status = 1 AND d.status = 1  AND p.collection_type = td.collection_type AND td.status= 1 AND f.corporate_oid=td.corporate_oid ORDER BY 3   ) subscriber  LEFT OUTER JOIN cdm.invoice_image ii ON subscriber.corporate_oid =ii.corporate_oid and ii.status= 1 AND ii.MASK_OID=subscriber.maskDetailOid  order by collection_name,view_order";

		public static final String SUBSCRIBER_LIST_NEW = " SELECT subscriber.*,ii.oid IMAGE_OID from( SELECT d.oid maskDetailOid,f.corporate_oid,d.use_for_inquiry,p.collection_name,p.collection_type,d.label,d.mask,d.example,d.prefix,d.suffix,d.use_for_collection,d.use_for_standing_order,"
				+ " d.view_order,td.is_appearance_payment_screen as USE_PAYMENT_INVOICE_SCREEN, td.allow_auto_collection as USE_AUTOMATIC_PAYMENT FROM cdm.subscriber_mask_def_tx f,cdm.collection_type_def_tx td,cdm.subscriber_mask_detail_tx d,cdm.collection_type_prm p WHERE f.tx_no = %s AND f.oid = d.mask_oid AND f.collection_type = p.collection_type "
				+ " AND d.status = 1  AND p.collection_type = td.collection_type AND td.status= 1 AND f.corporate_oid=td.corporate_oid ORDER BY 3   ) subscriber  LEFT OUTER JOIN cdm.invoice_image_tx ii ON subscriber.corporate_oid =ii.corporate_oid and ii.status= 1 AND ii.MASK_OID=subscriber.maskDetailOid order by collection_name,view_order";
		public static final String CONTACT_LIST = " SELECT cc.name_surname,cc.department department_id, (SELECT TEXT FROM BNSPR.V_ML_GNL_PARAM_TEXT WHERE KOD = 'CDM_DEPARTMAN' and KEY1 = cc.department )as department, cc.phone_number, cc.mobile, cc.email, cc.fax,cc.note  FROM cdm.corporate_contact_info cc WHERE cc.corporate_oid ='%s' AND cc.status = 1 ORDER BY 1";
		public static final String CONTACT_LIST_NEW = " SELECT cc.name_surname,cc.department department_id, (SELECT TEXT FROM BNSPR.V_ML_GNL_PARAM_TEXT WHERE KOD = 'CDM_DEPARTMAN' and KEY1 = cc.department )as department, cc.phone_number, cc.mobile, cc.email, cc.fax,cc.note   FROM cdm.corporate_contact_info_tx cc WHERE cc.tx_no =%s ORDER BY 1";
		public static final String CHANNEL_SOURCE_LIST = "select distinct  (SELECT LISTAGG(channel_code, ',') WITHIN GROUP (ORDER BY channel_code) FROM cdm.channel_source_def agg where csd.corporate_oid=agg.corporate_oid and agg.status=1 and agg.screen_line = csd.screen_line) as CHANNEL_NAME,"
				+ " (SELECT LISTAGG(source_code, ',') WITHIN GROUP (ORDER BY source_code) FROM cdm.channel_source_def agg where csd.corporate_oid=agg.corporate_oid and agg.status=1  and agg.screen_line = csd.screen_line ) as SOURCE_NAME,"
				+ " (SELECT LISTAGG(channel_code, ',') WITHIN GROUP (ORDER BY channel_code) FROM cdm.channel_source_def agg where csd.corporate_oid=agg.corporate_oid and agg.status=1  and agg.screen_line = csd.screen_line ) as CHANNEL_CODE,"
				+ " (SELECT LISTAGG(source_code, ',') WITHIN GROUP (ORDER BY source_code) FROM cdm.channel_source_def agg where csd.corporate_oid=agg.corporate_oid and agg.status=1  and agg.screen_line = csd.screen_line ) as SOURCE_CODE,"
				+ " csd.WORKINGDAY_START_TIME,csd.WORKINGDAY_END_TIME,csd.HOLIDAY_START_TIME,csd.HOLIDAY_END_TIME,csd.CLOSED_DATE_START,csd.CLOSED_DATE_END,csd.EXPLANATION,csd.SCREEN_LINE from cdm.channel_source_def csd where csd.corporate_oid='%s' and csd.status=1 ORDER BY csd.screen_line";
		public static final String CHANNEL_SOURCE_LIST_NEW = "select distinct  (SELECT LISTAGG(channel_code, ',') WITHIN GROUP (ORDER BY channel_code) FROM cdm.channel_source_def_tx agg where csd.corporate_oid=agg.corporate_oid and agg.screen_line = csd.screen_line) as CHANNEL_NAME,"
				+ " (SELECT LISTAGG(source_code, ',') WITHIN GROUP (ORDER BY source_code) FROM cdm.channel_source_def_tx agg where csd.corporate_oid=agg.corporate_oid and agg.screen_line = csd.screen_line) as SOURCE_NAME,"
				+ " (SELECT LISTAGG(channel_code, ',') WITHIN GROUP (ORDER BY channel_code) FROM cdm.channel_source_def_tx agg where csd.corporate_oid=agg.corporate_oid and agg.screen_line = csd.screen_line) as CHANNEL_CODE,"
				+ " (SELECT LISTAGG(source_code, ',') WITHIN GROUP (ORDER BY source_code) FROM cdm.channel_source_def_tx agg where csd.corporate_oid=agg.corporate_oid and agg.screen_line = csd.screen_line ) as SOURCE_CODE,"
				+ " csd.WORKINGDAY_START_TIME,csd.WORKINGDAY_END_TIME,csd.HOLIDAY_START_TIME,csd.HOLIDAY_END_TIME,csd.CLOSED_DATE_START,csd.CLOSED_DATE_END,csd.EXPLANATION,csd.SCREEN_LINE from cdm.channel_source_def_tx csd where csd.tx_no=%s ORDER BY csd.screen_line";		
		public static final String ACCOUNT_LIST = "select * from( select distinct decode(m.account_definition_type,'TH','Tahsilat Hesab�' ,'KH','Kullan�m Hesab�','EH','EFT Hesab�',null) as account_definition_name, m.account_definition_type , decode(m.account_type,'VL','Vadeli','VS','Vadesiz',null) as account_name, m.account_type,"
				+ " m.account_number, m.account_owner, m.concentration_type, m.default_amount, m.iban, (select listagg(z.account_match_def_id, ',') within group (order by account_match_def_id) from (select distinct r.account_match_def_id,r.account_master_oid from cdm.account_collection_type_rel r where r.status = 1) z where z.account_master_oid = m.oid )as tree_list,"
				+ " (select listagg(z.collection_name, ',') within group (order by z.collection_type) from  (select distinct p.collection_name, p.collection_type, r.account_master_oid from cdm.account_collection_type_rel r, cdm.collection_type_prm p where r.collection_type  = p.collection_type and r.status = 1) z where z.account_master_oid = m.oid ) as collection_name,"
				+ " (select listagg(z.collection_type, ',')  within group (order by z.collection_type) from (select distinct r.collection_type, r.account_master_oid from cdm.account_collection_type_rel r where r.status= 1) z where z.account_master_oid = m.oid )as collection_type,"
				+ " (select listagg(z.source_name||'<->'||z.aciklama, ',') within group (order by z.source_code, to_number(z.channel_code)) from  (select distinct k.aciklama, s.source_name, r.account_master_oid, r.source_code, r.channel_code from cdm.account_collection_type_rel"
				+ " r,cdm.source_param s, bnspr.gnl_kanal_grup_kod_pr k where s.source_code = r.source_code and k.kod = r.channel_code and r.status = 1 ) z where z.account_master_oid = m.oid )  as channel_source_name,"
				+ " (select listagg(z.source_code||'<->'||z.channel_code, ',') within group (order by z.source_code, to_number(z.channel_code)) from  (select distinct r.channel_code, r.source_code ,r.account_master_oid from cdm.account_collection_type_rel r where r.status = 1) z where z.account_master_oid = m.oid )  as channel_source_code from cdm.corporation_account_master m"
				+ " where m.corporate_oid = '%s' and m.status = 1  order by account_definition_type,account_number)";   		
		public static final String ACCOUNT_LIST_NEW = "select * from( select distinct decode(m.account_definition_type,'TH','Tahsilat Hesab�' ,'KH','Kullan�m Hesab�','EH','EFT Hesab�',null) as account_definition_name, m.account_definition_type , decode(m.account_type,'VL','Vadeli','VS','Vadesiz',null) as account_name, m.account_type,"
				+ " m.account_number, m.account_owner, m.concentration_type, m.default_amount, m.�ban, (select listagg(z.account_match_def_id, ',') within group (order by account_match_def_id) from (select distinct r.account_match_def_�d,r.account_master_oid from cdm.account_collection_type_rel_tx r where r.status = 1) z where z.account_master_oid = m.oid )as tree_list,"
				+ " (select listagg(z.collection_name, ',') within group (order by z.collection_type) from  (select distinct p.collection_name, p.collection_type, r.account_master_oid from cdm.account_collection_type_rel_tx r, cdm.collection_type_prm p where r.collection_type  = p.collection_type and r.status = 1) z where z.account_master_oid = m.oid ) as collection_name,"
				+ " (select listagg(z.collection_type, ',')  within group (order by z.collection_type) from ( select distinct r.collection_type, r.account_master_oid from cdm.account_collection_type_rel_tx r where r.status= 1) z where z.account_master_oid = m.oid )as collection_type,"
				+ " (select listagg(z.source_name||'<->'||z.aciklama, ',') within group (order by z.source_code, to_number(z.channel_code)) from  (select distinct k.aciklama, s.source_name, r.account_master_oid, r.source_code, r.channel_code from cdm.account_collection_type_rel_tx"
				+ " r,cdm.source_param s, bnspr.gnl_kanal_grup_kod_pr k where s.source_code = r.source_code and k.kod = r.channel_code and r.status = 1 ) z where z.account_master_oid = m.oid )  as channel_source_name,"
				+ " (select listagg(z.source_code||'<->'||z.channel_code, ',') within group (order by z.source_code, to_number(z.channel_code)) from  ( select distinct r.channel_code, r.source_code ,r.account_master_oid from cdm.account_collection_type_rel_tx r where r.status = 1 ) z where z.account_master_oid = m.oid )  as channel_source_code from cdm.corporation_account_master_tx m"
				+ " where m.tx_no = '%s' order by account_definition_type,account_number)";

		public static final String TRANSFER_LIST = "SELECT DISTINCT f.transfer_day_type DAY_TYPE_ID, DECODE(f.from_account_type,'TH','Tahsilat Hesab�-'||f.from_account_no,'KH','Kullan�m Hesab�-'||f.from_account_no,NULL) AS SOURCE_ACCOUNT_NO, DECODE(f.to_account_type,'EH','EFT Hesab�-'||f.to_account_iban,'KH','Kullan�m Hesab�-'||f.to_account_no,NULL) AS TRANSFUSION_ACCOUNT_NO,"
				+ " f.from_account_type||'-'||f.from_account_no AS SOURCE_ACCOUNT_NO_ID, f.to_account_type||'-'||DECODE(f.to_account_type,'EH',f.to_account_iban,f.to_account_no) AS TRANSFUSION_ACCOUNT_NO_ID, case when f.to_account_type = 'KH' then (select m.oid to_account_no_id FROM cdm.corporation_account_master m"
				+ " where m.status = 1 and m.corporate_oid = '%s' and m.account_number is not null and m.account_number = f.to_account_no and m.account_definition_type = f.to_account_type) when f.to_account_type = 'EH' then (select m.oid TRANSFUSION_ACCOUNT_NO_ID FROM cdm.corporation_account_master m where m.status = 1 and m.corporate_oid = '%s' and"
				+ " m.iban is not null and m.iban = f.to_account_iban and m.account_definition_type = f.to_account_type) end, f.transfer_collections_inholiday VACATION_TYPE_ID,f.transfer_day_option,f.transfer_month_option, (SELECT ListAgg('('||p.collection_name||'<->'||k.aciklama||'<->'||s.source_name||')',',') within GROUP(ORDER BY p.collection_name DESC)"
				+ " FROM cdm.account_collection_type_rel a,cdm.collection_transfer_rel r,cdm.source_param s, BNSPR.gnl_kanal_grup_kod_pr k,cdm.collection_type_prm p WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code"
				+ " AND p.collection_type= a.collection_type AND r.transfer_param_oid= f.oid AND r.status= 1 ) AS COLLECTION_CHANNEL_SOURCE, (SELECT ListAgg(p.collection_type||'<->'||k.kod||'<->'||s.source_code,',') within GROUP(ORDER BY p.collection_type DESC) FROM cdm.account_collection_type_rel a,cdm.collection_transfer_rel r,cdm.source_param s,"
				+ " BNSPR.gnl_kanal_grup_kod_pr k,cdm.collection_type_prm p WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code AND p.collection_type= a.collection_type AND r.transfer_param_oid= f.oid AND r.status= 1 ) AS COLLECTION_CHANNEL_SOURCE_ID, CASE WHEN f.transfer_day_option = 2 THEN "
				+ " (SELECT ListAgg('('|| d.in_day_of_each_week||'->'||d.out_day_of_each_week||')',',') within GROUP(ORDER BY d.in_day_of_each_week ASC) FROM cdm.balance_transfer_days d WHERE d.balance_transfer_oid = f.oid ) WHEN f.transfer_day_option = 1 THEN  ('('||f.transfer_day_count||' '||(SELECT g.text FROM BNSPR.v_ml_gnl_param_text g"
				+ " WHERE kod = 'CDM_AKTARIM_GUN_TIPI' AND key1  = f.transfer_day_type) ||' sonra aktar�ls�n)') END AS transfer_day_rule, CASE WHEN f.transfer_month_option = 1 THEN f.day_of_each_month||'. g�n� yap�ls�n' WHEN f.transfer_month_option = 2 THEN f.in_day_of_each_month||'. g�n� gelen ay�n '||f.out_day_of_each_month||'. g�n� yap�ls�n'END AS TRANSFER_MONTH_RULE,"
				+ " (SELECT g.text FROM BNSPR.v_ml_gnl_param_text g WHERE kod = 'CDM_AKTARIM_TATIL_GUNU' AND key1 = f.transfer_collections_inholiday ) VACATION_TYPE FROM cdm.balance_transfer_def f where F.CORPORATE_OID = '%s' and F.STATUS = 1 and (f.from_account_no||'' in  (select m.account_number from cdm.corporation_account_master m"
				+ " where m.corporate_oid = '%s' and m.status = 1) and f.to_account_no||'' in (select m.account_number from cdm.corporation_account_master m where m.corporate_oid = '%s' and m.status = 1) or f.to_account_iban||'' in (select m.iban" + " from cdm.CORPORATION_ACCOUNT_MASTER M where m.corporate_oid = '%s' and m.status = 1)) order by source_account_no_id,transfusion_account_no_id";

		public static final String TRANSFER_LIST_NEW = "SELECT DISTINCT f.transfer_day_type DAY_TYPE_ID, DECODE(f.from_account_type,'TH','Tahsilat Hesab�-'||f.from_account_no,'KH','Kullan�m Hesab�-'||f.from_account_no,NULL) AS SOURCE_ACCOUNT_NO, DECODE(f.to_account_type,'EH','EFT Hesab�-'||f.to_account_iban,'KH','Kullan�m Hesab�-'||f.to_account_no,NULL) AS TRANSFUSION_ACCOUNT_NO,"
				+ " f.from_account_type||'-'||f.from_account_no AS SOURCE_ACCOUNT_NO_ID, f.to_account_type||'-'||DECODE(f.to_account_type,'EH',f.to_account_iban,f.to_account_no) AS TRANSFUSION_ACCOUNT_NO_ID, case when f.to_account_type = 'KH' then (select m.oid to_account_no_id FROM cdm.corporation_account_master_tx m"
				+ " where m.tx_no = %s and m.account_number is not null and m.account_number = f.to_account_no and m.account_definition_type = f.to_account_type) when f.to_account_type = 'EH' then (select m.oid TRANSFUSION_ACCOUNT_NO_ID FROM cdm.corporation_account_master_tx m where m.tx_no = %s and"
				+ " m.iban is not null and m.iban = f.to_account_iban and m.account_definition_type = f.to_account_type) end, f.transfer_collections_inholiday VACATION_TYPE_ID,f.transfer_day_option,f.transfer_month_option, (SELECT ListAgg('('||p.collection_name||'<->'||k.aciklama||'<->'||s.source_name||')',',') within GROUP(ORDER BY p.collection_name DESC)"
				+ " FROM cdm.account_collection_type_rel_tx a,cdm.collection_transfer_rel_tx r,cdm.source_param s, BNSPR.gnl_kanal_grup_kod_pr k,cdm.collection_type_prm p WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code"
				+ " AND p.collection_type= a.collection_type AND r.transfer_param_oid= f.oid AND r.status= 1 ) AS COLLECTION_CHANNEL_SOURCE, (SELECT ListAgg(p.collection_type||'<->'||k.kod||'<->'||s.source_code,',') within GROUP(ORDER BY p.collection_type DESC) FROM cdm.account_collection_type_rel_tx a,cdm.collection_transfer_rel_tx r,cdm.source_param s,"
				+ " BNSPR.gnl_kanal_grup_kod_pr k,cdm.collection_type_prm p WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code AND p.collection_type= a.collection_type AND r.transfer_param_oid= f.oid AND r.status= 1 ) AS COLLECTION_CHANNEL_SOURCE_ID, CASE WHEN f.transfer_day_option = 2 THEN "
				+ " (SELECT ListAgg('('|| d.in_day_of_each_week||'->'||d.out_day_of_each_week||')',',') within GROUP(ORDER BY d.in_day_of_each_week ASC) FROM cdm.balance_transfer_days_tx d WHERE d.balance_transfer_oid = f.oid ) WHEN f.transfer_day_option = 1 THEN  ('('||f.transfer_day_count||' '||(SELECT g.text FROM BNSPR.v_ml_gnl_param_text g"
				+ " WHERE kod = 'CDM_AKTARIM_GUN_TIPI' AND key1  = f.transfer_day_type) ||' sonra aktar�ls�n)') END AS transfer_day_rule, CASE WHEN f.transfer_month_option = 1 THEN f.day_of_each_month||'. g�n� yap�ls�n' WHEN f.transfer_month_option = 2 THEN f.in_day_of_each_month||'. g�n� gelen ay�n '||f.out_day_of_each_month||'. g�n� yap�ls�n'END AS TRANSFER_MONTH_RULE,"
				+ " (SELECT g.text FROM BNSPR.v_ml_gnl_param_text g WHERE kod = 'CDM_AKTARIM_TATIL_GUNU' AND key1 = f.transfer_collections_inholiday ) VACATION_TYPE FROM cdm.balance_transfer_def_tx f where F.TX_NO = %s and (f.from_account_no||'' in  (select m.account_number from cdm.corporation_account_master_tx m"
				+ " where m.tx_no = %s) and f.to_account_no||'' in (select m.account_number from cdm.corporation_account_master_tx m where m.tx_no = %s) or f.to_account_iban||'' in (select m.iban"
				+ " from cdm.CORPORATION_ACCOUNT_MASTER_tx M where m.tx_no = %s)) order by source_account_no_id,transfusion_account_no_id";
	}

	public static final class CorporationDefinitionServicesRepository {
		public static final String GET_CITIES = "select S.KOD, S.IL_ADI From BNSPR.Gnl_Il_Kod_Pr S Order By S.IL_ADI";
		public static final String CORPORATE_CITIES = "SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel c WHERE c.status= 1 AND c.corporate_oid ='%s' AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI";
		public static final String CORPORATE_CITIES_DIST = "SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel c WHERE c.status= 1 AND c.corporate_oid ='%s'";
		public static final String CORPORATE_CITIES_ELSE = "SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel_tx c WHERE c.status= 1 AND c.corporate_oid ='%s' AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI";
		public static final String CORPORATE_CITIES_ELSE_TX = "SELECT (SELECT COUNT(1) FROM cdm.corporate_city_rel_tx c WHERE c.tx_no=%s AND c.kod= p.kod) IL_SEC, p.KOD, p.IL_ADI FROM BNSPR.Gnl_Il_Kod_Pr p ORDER BY p.IL_ADI";
		public static final String CORPORATE_CITIES_DIST_ELSE = "SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel_tx c WHERE c.status= 1 AND c.corporate_oid ='%s'";
		public static final String CORPORATE_CITIES_DIST_ELSE_TX = "SELECT DISTINCT c.is_public_corporate from cdm.corporate_city_rel_tx c WHERE c.tx_no=%s";
		public static final String CHANNEL_SOURCE_LIST="SELECT cs.workingday_start_time, cs.workingday_end_time, cs.holiday_start_time, cs.holiday_end_time,cs.closed_date_start, cs.closed_date_end, cs.explanation,"
			+" (SELECT listagg(z.aciklama, ',')  within group (order by z.channel_code) FROM  "
			+" (select distinct k.aciklama, c.screen_line,c.channel_code from cdm.channel_source_def%s c, BNSPR.gnl_kanal_grup_kod_pr k"
			+" WHERE c.status = 1 and c.channel_code = k.kod and c.corporate_oid = '%s'  order by channel_code) z"
			+" WHERE z.screen_line = cs.screen_line)  AS channel_name,"
			+" (SELECT listagg(z.source_name, ',')  within group (order by z.source_code) FROM  (select distinct s.source_name, c.source_code, c.screen_line"
			+" from cdm.channel_source_def%s c, cdm.source_param s WHERE c.status = 1 and c.source_code = s.source_code"
			+" and c.corporate_oid = '%s') z WHERE z.screen_line = cs.screen_line )  AS source_name,"
			+" (SELECT listagg(z.channel_code, ',')  within group (order by z.channel_code) FROM  (select distinct c.channel_code, c.screen_line"
			+" from cdm.channel_source_def%s c WHERE c.status = 1 and c.corporate_oid = '%s' order by channel_code) z"
			+" WHERE z.screen_line = cs.screen_line)  AS channel_code,"
			+" (SELECT listagg(z.source_code, ',')  within group (order by z.source_code) FROM  (select distinct c.source_code, c.screen_line"
			+" from cdm.channel_source_def%s c WHERE c.status = 1 and c.corporate_oid = '%s') z"
			+" WHERE z.screen_line = cs.screen_line)  AS source_code"
			+" FROM  cdm.channel_source_def%s cs"
			+" WHERE cs.status = 1 and  cs.corporate_oid = '%s'"
			+" group by cs.screen_line,cs.workingday_start_time, cs.workingday_end_time, cs.holiday_start_time, cs.holiday_end_time,"
			+" cs.closed_date_start, cs.closed_date_end, cs.explanation";
		public static final String CHANNEL_SOURCE_LIST_TX="SELECT cs.workingday_start_time, cs.workingday_end_time, cs.holiday_start_time, cs.holiday_end_time,cs.closed_date_start, cs.closed_date_end, cs.explanation,"
				+" (SELECT listagg(z.aciklama, ',')  within group (order by z.channel_code) FROM  "
				+" (select distinct k.aciklama, c.screen_line,c.channel_code from cdm.channel_source_def_tx c, BNSPR.gnl_kanal_grup_kod_pr k"
				+" WHERE c.channel_code = k.kod and c.tx_no = '%s'  order by channel_code) z"
				+" WHERE z.screen_line = cs.screen_line)  AS channel_name,"
				+" (SELECT listagg(z.source_name, ',')  within group (order by z.source_code) FROM  (select distinct s.source_name, c.source_code, c.screen_line"
				+" from cdm.channel_source_def_tx c, cdm.source_param s WHERE c.source_code = s.source_code"
				+" and c.tx_no = '%s') z WHERE z.screen_line = cs.screen_line )  AS source_name,"
				+" (SELECT listagg(z.channel_code, ',')  within group (order by z.channel_code) FROM  (select distinct c.channel_code, c.screen_line"
				+" from cdm.channel_source_def_tx c WHERE c.tx_no = '%s' order by channel_code) z"
				+" WHERE z.screen_line = cs.screen_line)  AS channel_code,"
				+" (SELECT listagg(z.source_code, ',')  within group (order by z.source_code) FROM  (select distinct c.source_code, c.screen_line"
				+" from cdm.channel_source_def_tx c WHERE c.tx_no = '%s') z"
				+" WHERE z.screen_line = cs.screen_line)  AS source_code"
				+" FROM  cdm.channel_source_def_tx cs"
				+" WHERE cs.tx_no = '%s'"
				+" group by cs.screen_line,cs.workingday_start_time, cs.workingday_end_time, cs.holiday_start_time, cs.holiday_end_time,"
				+" cs.closed_date_start, cs.closed_date_end, cs.explanation";
		public static final String SUBSCRIBER_LIST_FIRST="select distinct ";
		public static final String SUBSCRIBER_LIST_TAX_TYPE_IF=" (select listagg(%s,',') within group(order by %s desc) "
			+" FROM %s p,cdm.collection_type_def%s td where  td.collection_type=p.collection_type and td.corporate_oid ='%s' and td.status=1 ) as collection_name,"
			+" (select listagg(p.collection_type,',') within group(order by p.collection_type desc) "
			+" FROM %s p,cdm.collection_type_def%s td where  td.collection_type=p.collection_type and td.corporate_oid ='%s' and td.status=1 ) as collection_type,";
		public static final String SUBSCRIBER_LIST_TAX_TYPE_ELSE=" (select p.collection_name FROM cdm.collection_type_prm p where td.collection_type=p.collection_type) as collection_name,"
				+" (select p.collection_type FROM cdm.collection_type_prm p where td.collection_type=p.collection_type) as collection_type,(select ii.oid from cdm.invoice_image ii where f.corporate_oid =ii.corporate_oid And ii.Status= 1 AND ii.MASK_OiD= d.oid) iMAGE_OiD,";
		public static final String SUBSCRIBER_LIST_LAST="f.corporate_oid,d.use_for_inquiry,d.label,d.mask,d.example,d.prefix,d.suffix,d.use_for_collection,d.use_for_standing_order,d.PREFIX_USE_FOR_COLLECTION,"
			+" d.PREFIX_USE_FOR_STANDING_ORDER,d.SUFFIX_USE_FOR_COLLECTION,d.SUFFIX_USE_FOR_STANDING_ORDER,d.view_order,"
			+" td.is_appearance_payment_screen AS USE_PAYMENT_INVOICE_SCREEN,td.allow_auto_collection AS USE_AUTOMATIC_PAYMENT"
			+" FROM cdm.subscriber_mask_def%s f,cdm.collection_type_def%s td,cdm.subscriber_mask_detail%s d"
			+" WHERE f.corporate_oid = '%s'"
			+" AND f.oid = d.mask_oid AND f.status= 1  AND d.status= 1  AND td.status= 1  and f.corporate_oid=td.corporate_oid  and td.COLLECTION_TYPE=f.COLLECTION_TYPE order by collection_type,view_order";
		public static final String SUBSCRIBER_LIST_LAST_TX="f.corporate_oid,d.use_for_inquiry,d.label,d.mask,d.example,d.prefix,d.suffix,d.use_for_collection,d.use_for_standing_order,d.PREFIX_USE_FOR_COLLECTION,"
				+" d.PREFIX_USE_FOR_STANDING_ORDER,d.SUFFIX_USE_FOR_COLLECTION,d.SUFFIX_USE_FOR_STANDING_ORDER,d.view_order,"
				+" td.is_appearance_payment_screen AS USE_PAYMENT_INVOICE_SCREEN,td.allow_auto_collection AS USE_AUTOMATIC_PAYMENT"
				+" FROM cdm.subscriber_mask_def_tx f,cdm.collection_type_def_tx td,cdm.subscriber_mask_detail_tx d"
				+" WHERE f.tx_no = '%s'"
				+" AND f.oid = d.mask_oid AND f.corporate_oid=td.corporate_oid  and td.COLLECTION_TYPE=f.COLLECTION_TYPE order by collection_type,view_order";
		
		public static String CONTACT_INFO_LIST="SELECT cc.name_surname,cc.department department_id,"
				+" (SELECT TEXT FROM BNSPR.V_ML_GNL_PARAM_TEXT WHERE KOD = 'CDM_DEPARTMAN' and KEY1 = cc.department )as department, cc.phone_number, cc.mobile, cc.email, cc.fax,cc.note "
				+" FROM cdm.corporate_contact_info%s cc"
				+" WHERE cc.corporate_oid ='%s' AND cc.status = 1 ORDER BY 1";
		public static String CONTACT_INFO_LIST_TX="SELECT cc.name_surname,cc.department department_id,"
				+" (SELECT TEXT FROM BNSPR.V_ML_GNL_PARAM_TEXT WHERE KOD = 'CDM_DEPARTMAN' and KEY1 = cc.department )as department, cc.phone_number, cc.mobile, cc.email, cc.fax,cc.note "
				+" FROM cdm.corporate_contact_info_tx cc"
				+" WHERE cc.tx_no=%s ORDER BY 1";
		public static String ACCOUNT_LIST="select * from( SELECT distinct DECODE(m.account_definition_type,'TH','Tahsilat Hesab�' ,'KH','Kullan�m Hesab�','EH','EFT Hesab�','BH','Bloke Hesabi',NULL) AS account_definition_name,"
			+" m.account_definition_type , DECODE(m.account_type,'VL','Vadeli','VS','Vadesiz',NULL) AS account_name, m.account_type,"
			+" m.account_number, m.account_owner, m.concentration_type, m.default_amount, m.iban,"
			+" (SELECT listagg(z.account_match_def_id, ',') within group (order by account_match_def_id) FROM (SELECT distinct r.account_match_def_id,r.account_master_oid FROM cdm.account_collection_type_rel%s"
			+" r WHERE r.status = 1) z WHERE z.account_master_oid = m.oid ) AS tree_list,"
			+" (SELECT listagg(z.collection_name, ',')  within group (order by z.collection_type) FROM  (SELECT distinct %s, p.collection_type, r.account_master_oid FROM cdm.account_collection_type_rel%s"
			+" r,%s p WHERE r.collection_type  = p.collection_type AND r.status = 1) z WHERE z.account_master_oid = m.oid ) AS collection_name,"
			+" (SELECT listagg(z.collection_type, ',')  within group (order by z.collection_type) FROM ( SELECT distinct r.collection_type, r.account_master_oid FROM cdm.account_collection_type_rel%s"
			+" r WHERE r.status= 1) z WHERE z.account_master_oid = m.oid )AS collection_type,"
			+" (SELECT listagg(z.source_name||'<->'||z.aciklama, ',') within group (order by z.source_code, to_number(z.channel_code)) FROM  (SELECT distinct k.aciklama, s.source_name, r.account_master_oid, r.source_code, r.channel_code FROM cdm.account_collection_type_rel%s"
			+" r,cdm.source_param s, BNSPR.gnl_kanal_grup_kod_pr k WHERE s.source_code = r.source_code AND k.kod = r.channel_code AND r.status = 1 ) z WHERE z.account_master_oid = m.oid )  AS channel_source_name,"
			+" (SELECT listagg(z.source_code||'<->'||z.channel_code, ',') within group (order by z.source_code, z.channel_code) FROM  ( SELECT distinct r.channel_code, r.source_code ,r.account_master_oid FROM cdm.account_collection_type_rel%s"
			+" r WHERE r.status = 1 ) z WHERE z.account_master_oid = m.oid )  AS channel_source_code"
			+" FROM cdm.corporation_account_master%s m"
			+" WHERE m.corporate_oid = '%s' AND m.status = 1  order by account_definition_type,account_number)";
		public static String ACCOUNT_LIST_TX="select * from( SELECT distinct DECODE(m.account_definition_type,'TH','Tahsilat Hesab�' ,'KH','Kullan�m Hesab�','EH','EFT Hesab�','BH','Bloke Hesabi',NULL) AS account_definition_name,"
				+" m.account_definition_type , DECODE(m.account_type,'VL','Vadeli','VS','Vadesiz',NULL) AS account_name, m.account_type,"
				+" m.account_number, m.account_owner, m.concentration_type, m.default_amount, m.iban,"
				+" (SELECT listagg(z.account_match_def_id, ',') within group (order by account_match_def_id) FROM (SELECT distinct r.account_match_def_id,r.account_master_oid FROM cdm.account_collection_type_rel_tx"
				+" r WHERE r.status = 1) z WHERE z.account_master_oid = m.oid ) AS tree_list,"
				+" (SELECT listagg(z.collection_name, ',')  within group (order by z.collection_type) FROM  (SELECT distinct %s, p.collection_type, r.account_master_oid FROM cdm.account_collection_type_rel_tx"
				+" r,%s p WHERE r.collection_type  = p.collection_type AND r.tx_no = %s) z WHERE z.account_master_oid = m.oid ) AS collection_name,"
				+" (SELECT listagg(z.collection_type, ',')  within group (order by z.collection_type) FROM ( SELECT distinct r.collection_type, r.account_master_oid FROM cdm.account_collection_type_rel_tx"
				+" r WHERE r.tx_no= %s) z WHERE z.account_master_oid = m.oid )AS collection_type,"
				+" (SELECT listagg(z.source_name||'<->'||z.aciklama, ',') within group (order by z.source_code, to_number(z.channel_code)) FROM  (SELECT distinct k.aciklama, s.source_name, r.account_master_oid, r.source_code, r.channel_code FROM cdm.account_collection_type_rel_tx"
				+" r,cdm.source_param s, BNSPR.gnl_kanal_grup_kod_pr k WHERE s.source_code = r.source_code AND k.kod = r.channel_code AND r.tx_no = %s ) z WHERE z.account_master_oid = m.oid )  AS channel_source_name,"
				+" (SELECT listagg(z.source_code||'<->'||z.channel_code, ',') within group (order by z.source_code, z.channel_code) FROM  ( SELECT distinct r.channel_code, r.source_code ,r.account_master_oid FROM cdm.account_collection_type_rel_tx"
				+" r WHERE r.tx_no = %s ) z WHERE z.account_master_oid = m.oid )  AS channel_source_code"
				+" FROM cdm.corporation_account_master_tx m"
				+" WHERE m.tx_no = %s  order by account_definition_type,account_number)";
		
		public static final String ACCOUNT_TRANSFER_MASTER_COUNT = "select * FROM cdm.corporation_account_master_tx m where m.status = 1 and m.corporate_oid ='%s' and rownum<2";
		public static final String ACCOUNT_TRANSFER_MASTER_COUNT_TX = "select * FROM cdm.corporation_account_master_tx m where m.tx_no =%s and rownum<2";
		public static final String ACCOUNT_TRANSFER_LIST = "SELECT DISTINCT f.oid as FOID,f.TRANSFER_DESC,f.transfer_day_type DAY_TYPE_ID,f.TRANSFER_TYPE TRANSFER_TYPE_ID,(select TEXT from bnspr.v_ml_gnl_param_text where kod ='CDM_TRANSFER_TIPI' and key1=f.TRANSFER_TYPE) TRANSFER_TYPE,"
			+" DECODE(f.from_account_type,'TH','Tahsilat Hesab�-'||f.from_account_no,'KH','Kullan�m Hesab�-'||f.from_account_no,'BH','Bloke Hesabi-'||f.from_account_no,NULL) AS SOURCE_ACCOUNT_NO,"
			+" DECODE(f.to_account_type,'EH','EFT Hesab�-'||f.to_account_iban,'KH','Kullan�m Hesab�-'||f.to_account_no,'BH','Bloke Hesabi-'||f.from_account_no,NULL) AS TRANSFUSION_ACCOUNT_NO,"
			+" f.from_account_type||'-'||f.from_account_no AS SOURCE_ACCOUNT_NO_ID,"
			+" f.to_account_type||'-'||DECODE(f.to_account_type,'EH',f.to_account_iban,f.to_account_no) AS TRANSFUSION_ACCOUNT_NO_ID,"
			+" f.transfer_collections_inholiday VACATION_TYPE_ID,f.transfer_day_option,f.transfer_month_option,"
			+" CASE WHEN f.transfer_day_option = 2 THEN "
			+" (SELECT ListAgg('('|| d.in_day_of_each_week||'->'||d.out_day_of_each_week||')',',') within GROUP(ORDER BY d.in_day_of_each_week ASC)"
			+" FROM cdm.balance_transfer_days%s d WHERE d.balance_transfer_oid = f.oid )"
			+" WHEN f.transfer_day_option = 1 THEN "
			+" ('('||f.transfer_day_count||' '||(SELECT g.text FROM BNSPR.v_ml_gnl_param_text g"
			+" WHERE kod = 'CDM_AKTARIM_GUN_TIPI' AND key1  = f.transfer_day_type)"
			+" ||' sonra aktar�ls�n)') END AS transfer_day_rule,"
			+" (SELECT ListAgg('(' || d.in_day_of_each_week ||'->' ||d.out_day_of_each_week ||'->' ||d.next_week ||')',',') within GROUP( ORDER BY d.in_day_of_each_week ASC) from cdm.balance_transfer_days%s d where d.balance_transfer_oid = f.oid) as transfer_day_rule_id,"
			+" CASE WHEN f.transfer_month_option = 1 THEN DECODE(f.day_of_each_month, null, '', f.day_of_each_month||'. g�n� yapilsin')"
			+" WHEN f.transfer_month_option = 2 THEN DECODE(f.in_day_of_each_month, null, '', f.in_day_of_each_month||'. g�n� gelen ay�n '||f.out_day_of_each_month||'. g�n� yap�ls�n') END AS TRANSFER_MONTH_RULE,"
			+" (SELECT g.text FROM BNSPR.v_ml_gnl_param_text g WHERE kod = 'CDM_AKTARIM_TATIL_GUNU' AND key1 = f.transfer_collections_inholiday ) VACATION_TYPE"
			+" FROM cdm.balance_transfer_def%s f where F.CORPORATE_OID = '%s' and F.STATUS = 1 and"
			+" (f.from_account_no||'' in "
			+" (select m.account_number from cdm.corporation_account_master%s m"
			+" where m.corporate_oid = '%s' and m.status = 1) and f.to_account_no||'' in"
			+" (select m.account_number from cdm.corporation_account_master%s m"
			+" where m.corporate_oid = '%s' and m.status = 1) or"
			+" f.to_account_iban||'' in"
			+" (select m.iban"
			+" from cdm.CORPORATION_ACCOUNT_MASTER%s M where m.corporate_oid = '%s' and m.status = 1)) order by source_account_no_id,transfusion_account_no_id";
		public static final String ACCOUNT_TRANSFER_LIST_TX = "SELECT DISTINCT f.oid as FOID,f.TRANSFER_DESC,f.transfer_day_type DAY_TYPE_ID,f.TRANSFER_TYPE TRANSFER_TYPE_ID,(select TEXT from bnspr.v_ml_gnl_param_text where kod ='CDM_TRANSFER_TIPI' and key1=f.TRANSFER_TYPE) TRANSFER_TYPE,"
				+" DECODE(f.from_account_type,'TH','Tahsilat Hesab�-'||f.from_account_no,'KH','Kullan�m Hesab�-'||f.from_account_no,'BH','Bloke Hesabi-'||f.from_account_no,NULL) AS SOURCE_ACCOUNT_NO,"
				+" DECODE(f.to_account_type,'EH','EFT Hesab�-'||f.to_account_iban,'KH','Kullan�m Hesab�-'||f.to_account_no,'BH','Bloke Hesabi-'||f.from_account_no,NULL) AS TRANSFUSION_ACCOUNT_NO,"
				+" f.from_account_type||'-'||f.from_account_no AS SOURCE_ACCOUNT_NO_ID,"
				+" f.to_account_type||'-'||DECODE(f.to_account_type,'EH',f.to_account_iban,f.to_account_no) AS TRANSFUSION_ACCOUNT_NO_ID,"
				+" f.transfer_collections_inholiday VACATION_TYPE_ID,f.transfer_day_option,f.transfer_month_option,"
				+" CASE WHEN f.transfer_day_option = 2 THEN "
				+" (SELECT ListAgg('('|| d.in_day_of_each_week||'->'||d.out_day_of_each_week||')',',') within GROUP(ORDER BY d.in_day_of_each_week ASC)"
				+" FROM cdm.balance_transfer_days_tx d WHERE d.balance_transfer_oid = f.oid )"
				+" WHEN f.transfer_day_option = 1 THEN "
				+" ('('||f.transfer_day_count||' '||(SELECT g.text FROM BNSPR.v_ml_gnl_param_text g"
				+" WHERE kod = 'CDM_AKTARIM_GUN_TIPI' AND key1  = f.transfer_day_type)"
				+" ||' sonra aktar�ls�n)') END AS transfer_day_rule,"
				+" (SELECT ListAgg('(' || d.in_day_of_each_week ||'->' ||d.out_day_of_each_week ||'->' ||d.next_week ||')',',') within GROUP( ORDER BY d.in_day_of_each_week ASC) from cdm.balance_transfer_days_tx d where d.balance_transfer_oid = f.oid) as transfer_day_rule_id,"
				+" CASE WHEN f.transfer_month_option = 1 THEN DECODE(f.day_of_each_month, null, '', f.day_of_each_month||'. g�n� yapilsin')"
				+" WHEN f.transfer_month_option = 2 THEN DECODE(f.in_day_of_each_month, null, '', f.in_day_of_each_month||'. g�n� gelen ay�n '||f.out_day_of_each_month||'. g�n� yap�ls�n') END AS TRANSFER_MONTH_RULE,"
				+" (SELECT g.text FROM BNSPR.v_ml_gnl_param_text g WHERE kod = 'CDM_AKTARIM_TATIL_GUNU' AND key1 = f.transfer_collections_inholiday ) VACATION_TYPE"
				+" FROM cdm.balance_transfer_def_tx f where F.TX_NO = %s and"
				+" (f.from_account_no||'' in "
				+" (select m.account_number from cdm.corporation_account_master_tx m"
				+" where m.tx_no = %s) and f.to_account_no||'' in"
				+" (select m.account_number from cdm.corporation_account_master_tx m"
				+" where m.tx_no = %s) or"
				+" f.to_account_iban||'' in"
				+" (select m.iban"
				+" from cdm.CORPORATION_ACCOUNT_MASTER_TX M where m.tx_no = %s)) order by source_account_no_id,transfusion_account_no_id";
		public static final String ACCOUNT_TRANSFER_COLLECTION_CHANNEL_SOURCE=" SELECT '('||%s||'<->'||s.source_name||'<->'||k.aciklama||')' as COLLECTION_CHANNEL_SOURCE"
				+" FROM cdm.account_collection_type_rel%s a,cdm.collection_transfer_rel%s r,cdm.source_param s,"
				+" BNSPR.gnl_kanal_grup_kod_pr k,%s p"
				+" WHERE r.account_collection_oid = a.oid AND a.status= 1 AND s.source_code= a.source_code AND k.kod= a.channel_code"
				+" AND p.collection_type= a.collection_type AND r.transfer_param_oid= '%s' AND r.status= 1  %s ORDER BY %s ASC ";
		public static final String ACCOUNT_TRANSFER_COLLECTION_CHANNEL_SOURCE_TX = " SELECT '('||%s||'<->'||s.source_name||'<->'||k.aciklama||')' as COLLECTION_CHANNEL_SOURCE"
				+" FROM cdm.account_collection_type_rel_tx a,cdm.collection_transfer_rel_tx r,cdm.source_param s,"
				+" BNSPR.gnl_kanal_grup_kod_pr k,%s p"
				+" WHERE r.tx_no = %s AND a.tx_no= %s AND s.source_code= a.source_code AND k.kod= a.channel_code and r.account_collection_oid=a.oid"
				+" AND p.collection_type= a.collection_type %s ORDER BY %s ASC ";
		
		public static final String ACCOUNT_TRANSFER_COLLECTION_CHANNEL_SOURCE_ID=" SELECT actr.collection_type||'<->'||actr.source_code||'<->'||actr.channel_code||'<->'||actr.account_match_def_id AS collection_channel_source_id"
				+" FROM cdm.account_collection_type_rel%s actr,cdm.collection_transfer_rel%s r,%s p"
				+" WHERE r.account_collection_oid = actr.oid  AND actr.status=1 AND r.status=1 AND p.collection_type= actr.collection_type "
				+" AND r.transfer_param_oid='%s' AND r.status= 1  %s ORDER BY %s ASC   ";
		public static final String ACCOUNT_TRANSFER_COLLECTION_CHANNEL_SOURCE_ID_TX=" SELECT actr.collection_type||'<->'||actr.source_code||'<->'||actr.channel_code||'<->'||actr.account_match_def_id AS collection_channel_source_id"
				+" FROM cdm.account_collection_type_rel_tx actr,cdm.collection_transfer_rel_tx r,%s p"
				+" WHERE r.account_collection_oid = actr.oid  AND actr.status=1 AND r.status=1 AND p.collection_type= actr.collection_type "
				+" AND r.tx_no=%s  %s ORDER BY %s ASC   ";
		
		public static final String  CHECK_ACCOUNT_NUMBER=" select count(*) from bnspr.muh_hesap h, bnspr.v_gnl_musteri_aktif m where h.modul_tur_kod = '%s' and h.doviz_kodu='%s' and h.hesap_no=%s";
		
		public static final String ACCOUNT_CHANNELS_SOURCES="SELECT DISTINCT p.aciklama channel_name, s.source_name, p.kod channel_code, s.source_code"
			+" FROM cdm.channel_source_def%s cs, bnspr.gnl_kanal_grup_kod_pr p, cdm.source_param s"
			+" WHERE cs.channel_code = p.kod AND cs.source_code= s.source_code AND cs.status= 1"
			+" AND cs.corporate_oid = '%s'";
		public static final String ACCOUNT_COLLECTION_TYPES = "SELECT DISTINCT p.collection_name ,p.collection_type"
			+" FROM cdm.collection_type_def%s d,cdm.collection_type_prm p"
			+" ,cdm.subscriber_mask_def%s smd"
			+" WHERE d.corporate_oid = '%s'"
			+" AND smd.collection_type=p.collection_type AND smd.status=1 AND smd.corporate_oid=d.corporate_oid"
			+" AND p.collection_type= d.collection_type AND d.status=1 AND (d.allow_auto_collection=1 OR d.is_appearance_payment_screen=1)";
		public static final String TEMERKUZ_SUBSCRIBER_IF = " SELECT distinct m.oid label,t.subscriber_no, t.child_corporate_name,t.definition_id,collection_name label_name"
				+" from cdm.collection_type_prm ef,cdm.subscriber_mask_def  d,cdm.subscriber_mask_detail m ,cdm.account_matching_tree t "
				+" where ef.collection_type=d.collection_type "
				+" and m.mask_oid=d.oid and  d.corporate_oid='%s' and m.oid=t.label"
				+" and t.corporate_oid=d.corporate_oid AND t.status = 1 ";
		public static final String TEMERKUZ_SUBSCRIBER_ELSE = "SELECT distinct m.oid label,t.subscriber_no, t.child_corporate_name,t.definition_id,collection_name label_name"
				+" from cdm.collection_type_prm ef,cdm.subscriber_mask_def_tx  d,cdm.subscriber_mask_detail_tx m ,cdm.account_matching_tree_tx t "
				+" where ef.collection_type=d.collection_type "
				+" and m.mask_oid=d.oid and  d.corporate_oid='%s' and m.oid=t.label"
				+" and t.corporate_oid=d.corporate_oid AND t.status = 1 ";
		public static final String MATCHING_SUBSCRIBER_IF = "SELECT distinct d.collection_type||'-'||m.label label,t.subscriber_no, t.child_corporate_name,t.definition_id,collection_name label_name"
				+" from cdm.collection_type_prm ef,cdm.subscriber_mask_def  d,cdm.subscriber_mask_detail m ,cdm.account_matching_tree t "
				+" where ef.collection_type=d.collection_type "
				+" and m.mask_oid=d.oid and  d.corporate_oid='%s' and m.oid=t.label"
				+" and t.corporate_oid=d.corporate_oid AND t.status = 1 ";
		public static final String MATCHING_SUBSCRIBER_ELSE = "SELECT distinct d.collection_type||'-'||m.label label,t.subscriber_no, t.child_corporate_name,t.definition_id,collection_name label_name"
				+" from cdm.collection_type_prm ef,cdm.subscriber_mask_def_tx  d,cdm.subscriber_mask_detail_tx m ,cdm.account_matching_tree_tx t "
				+" where ef.collection_type=d.collection_type "
				+" and m.mask_oid=d.oid and  d.corporate_oid='%s' and m.oid=t.label"
				+" and t.corporate_oid=d.corporate_oid AND t.status = 1 ";
	}
	
	
	public static final class FtmDefinitionServicesRepository{
		public static final String GET_FTM_PLATFORM="SELECT oid, name FROM ftm.ftm_platform ORDER BY oid";
		public static final String FTM_CONNECTION_TYPE="SELECT oid, connection_type FROM ftm.connection_type ORDER BY oid";
		public static final String FTM_FILE_DEF_TYPE="SELECT oid, file_definition_type FROM ftm.ftm_file_definition_type ORDER BY oid";
		public static final String FTM_FILE_TYPE="SELECT oid, file_type FROM ftm.file_type ORDER BY oid";
		public static final String FTM_CONNECTION_NAMES="SELECT oid, conn_name FROM ftm.gm_connection ORDER BY oid";
		public static final String FTM_FILE_ENCODING="SELECT oid, encoding FROM ftm.file_encoding ORDER BY oid";
		public static final String FTM_FTP_DEFINITIONS_PLATFORM_NAME="SELECT name FROM ftm.ftm_platform WHERE oid = %s";
		public static final String FTM_FTP_DEFINITIONS_CONNECTION_TYPE="SELECT connection_type FROM ftm.connection_type WHERE oid = %s";
		public static final String FTM_FILE_DEFINITIONS_FILE_DEF_TYPE_NAME="SELECT file_definition_type FROM ftm.ftm_file_definition_type WHERE oid = %s";
		public static final String FTM_FILE_DEFINITIONS_FILE_TYPE_NAME ="SELECT file_type FROM ftm.file_type WHERE oid = %s";
		public static final String FTM_FILE_DEFINITIONS_ENCODING_NAME="SELECT encoding FROM ftm.file_encoding WHERE oid = %s";
		public static final String FTM_FTP_FILE_RELATIONS="SELECT ftp_source.oid source_oid,"
			+" ftp_dest.oid dest_oid,"	
			+" ftp_archive.oid archive_oid,"
			+" (select f.name from ftm.ftm_file_definition f where f.oid = ftp_dest.ftm_file_definition_oid) ftm_file_name,"
			+" (select s.name from ftm.ftm_ftp_definition s where s.oid = ftp_source.ftm_ftp_definition_oid) source_ftp," 
			+" (select d.name from ftm.ftm_ftp_definition d where d.oid = ftp_dest.ftm_ftp_definition_oid) dest_ftp," 
			+" (select a.name from ftm.ftm_ftp_definition a where a.oid = ftp_archive.ftm_ftp_definition_oid) archive_ftp,"              
			+" ftp_source.path source_path, ftp_dest.path dest_path, ftp_archive.path archive_path"
			+" FROM   ftm.ftm_file_definition_ftp ftp_dest" 
			+" LEFT JOIN ftm.ftm_file_definition_ftp ftp_source"
			+" ON ftp_dest.ftm_file_definition_oid = ftp_source.ftm_file_definition_oid AND ftp_source.ftm_file_def_ftp_type_oid = 1"
			+" LEFT JOIN ftm.ftm_file_definition_ftp ftp_archive" 
			+" ON ftp_dest.ftm_file_definition_oid = ftp_archive.ftm_file_definition_oid AND ftp_archive.ftm_file_def_ftp_type_oid = 3" 
			+" WHERE  ftp_dest.ftm_file_def_ftp_type_oid = 2"
			+" ORDER BY 1";
		public static final String FTM_FTP_FILE_TX_RELATIONS="SELECT ftp_source.oid source_oid,"
				+" ftp_dest.oid dest_oid,"	
				+" ftp_archive.oid archive_oid,"
				+" (select f.name from ftm.ftm_file_definition f where f.oid = ftp_dest.ftm_file_definition_oid) ftm_file_name,"
				+" (select s.name from ftm.ftm_ftp_definition s where s.oid = ftp_source.ftm_ftp_definition_oid) source_ftp," 
				+" (select d.name from ftm.ftm_ftp_definition d where d.oid = ftp_dest.ftm_ftp_definition_oid) dest_ftp," 
				+" (select a.name from ftm.ftm_ftp_definition a where a.oid = ftp_archive.ftm_ftp_definition_oid) archive_ftp,"              
				+" ftp_source.path source_path, ftp_dest.path dest_path, ftp_archive.path archive_path"
				+" FROM   ftm.ftm_file_definition_ftp_tx ftp_dest" 
				+" LEFT JOIN ftm.ftm_file_definition_ftp_tx ftp_source"
				+" ON ftp_dest.ftm_file_definition_oid = ftp_source.ftm_file_definition_oid AND ftp_source.ftm_file_def_ftp_type_oid = 1 AND ftp_source.status = 1 AND ftp_source.tx_no = %s"
				+" LEFT JOIN ftm.ftm_file_definition_ftp_tx ftp_archive" 
				+" ON ftp_dest.ftm_file_definition_oid = ftp_archive.ftm_file_definition_oid AND ftp_archive.ftm_file_def_ftp_type_oid = 3  AND ftp_archive.status = 1 AND ftp_archive.tx_no = %s" 
				+" WHERE  ftp_dest.ftm_file_def_ftp_type_oid = 2  AND ftp_dest.status = 1 AND ftp_dest.tx_no = %s"
				+" ORDER BY 1";				
		public static final String FTM_FTP_FILE_REL="SELECT name FROM ftm.ftm_file_definition WHERE oid = %s";
		public static final String CONTROL_SOURCE_ARCHIVE_CONDITIONS="SELECT name FROM ftm.ftm_file_definition WHERE oid = %s";
		public static final String GET_FTM_GM_CONNECTION_NAME="SELECT CONN_NAME FROM ftm.gm_connection WHERE oid = %s";
	}
	
	public static final class CorporationServiceUtilRepository {
		public static final String COLLECTION_TYPES="select  case collection_type when 0 then 0 when 1 then 1 when 2 then 2 else 4 end as SIRA, ctp.*  from CDM.COLLECTION_TYPE_PRM ctp order by sira,ctp.collect�on_name asc";
		public static final String TAX_GENERAL_VALUE="SELECT TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD ='%s'";
	}
	
	public static final class StandingOrderTransactionServicesRepository {
		public static final String STO_CHECK_FIELDS="select h.hesap_no from bnspr.muh_hesap h where h.doviz_kodu='TRY' and h.musteri_no = nvl('%s',h.musteri_no) and h.hesap_no = nvl('%s',h.hesap_no)";
		public static final String CITIES_FRONTEND_WITH_SELECTION_OPTION="SELECT DISTINCT c.kod, c.il_adi FROM bnspr.gnl_il_kod_pr c ORDER BY c.int_sira, c.kod";
		public static final String CORPORATES_FRONTEND_WITH_SELECTION_OPTION="SELECT m.oid, m.corporate_name"
			+" FROM   cdm.corporate_master m INNER JOIN cdm.corporate_city_rel c ON m.oid = c.corporate_oid"
			+" WHERE  m.status=1 AND c.status = 1 AND (c.is_public_corporate = 1 OR c.kod = %s)"
			+" ORDER BY m.corporate_name";
		public static final String COLLECTION_TYPES_FRONTEND_WTIH_SELECTION_OPTION="SELECT ctp.collection_type, ctp.collection_name FROM cdm.collection_type_def ctd INNER JOIN "
			+" cdm.collection_type_prm ctp ON ctd.collection_type = ctp.collection_type "
			+" WHERE ctd.status=1 and ctd.ALLOW_AUTO_COLLECTION=nvl(%s,ctd.ALLOW_AUTO_COLLECTION)"
			+" AND ctd.corporate_oid='%s'"
			+" and exists(select * from cdm.subscriber_mask_detail smdet "
			+" where smdet.mask_oid in(select OID from cdm.subscriber_mask_def smdef "
			+" where smdef.collection_type=ctd.collection_type and smdef.status=1 and smdef.corporate_oid=ctd.corporate_oid) "
			+" and status=1 and use_for_standing_order='1')";
		public static final String CUSTOMER_STANDING_ORDER_INVOICE_LIST="SELECT im.SUBSCRIBER_NO1, im.SUBSCRIBER_NO2, im.SUBSCRIBER_NO3, im.SUBSCRIBER_NO4, im.INVOICE_DUE_DATE, im.AMOUNT," 
				+"som.STANDING_ORDER_STATUS, cm.SHORT_CODE " 
				+" FROM ICS.INVOICE_MAIN im INNER JOIN " 
				+" STO.STANDING_ORDER_MAIN som ON im.STANDING_ORDER_OID=som.OID " 
				+" INNER JOIN CDM.CORPORATE_MASTER cm ON im.CORPORATE_CODE = cm.CORPORATE_CODE " 
				+" WHERE im.STATUS=1 AND som.STATUS=1 AND som.STANDING_ORDER_STATUS='%s' AND im.PAYMENT_STATUS='%s' AND som.STANDING_ORDER_TYPE='%s' " 
				+" AND som.CUSTOMER_NO='%s' AND cm.STATUS=1 AND cm.CORPORATE_ACTIVENESS='%s'";
		public static final String CUSTOMER_TOTAL_AMOUNT_STANDING_ORDER_INVOICES= "select sum (amount) from	 ( SELECT distinct bl.SUBSCRIBER_NO1, bl.SUBSCRIBER_NO2, bl.SUBSCRIBER_NO3, bl.SUBSCRIBER_NO4,  bl.AMOUNT "  
				+" FROM ICS.standing_order_backlog bl INNER JOIN  "
				+" STO.STANDING_ORDER_MAIN som ON bl.STANDING_ORDER_OID=som.OID "  
				+" INNER JOIN CDM.CORPORATE_MASTER cm ON bl.CORPORATE_CODE = cm.CORPORATE_CODE " 
				+" WHERE bl.STATUS=1 AND som.STATUS=1 AND som.STANDING_ORDER_STATUS=1 AND bl.is_paid='0' AND som.STANDING_ORDER_TYPE='KFT' "
				+" AND cm.STATUS=1 AND cm.CORPORATE_ACTIVENESS='A'  AND som.CUSTOMER_NO='%s' ) ";
		
		public static final String CUSTOMER_FAILED_STANDING_ORDER_LIST= "SELECT im.SUBSCRIBER_NO1, im.SUBSCRIBER_NO2, im.SUBSCRIBER_NO3, im.SUBSCRIBER_NO4, im.INVOICE_DUE_DATE, im.AMOUNT," 
				+" som.STANDING_ORDER_STATUS, cm.SHORT_CODE, iso.PROCESS_DATE " 
				+" FROM ICS.INVOICE_MAIN im INNER JOIN " 
				+" STO.STANDING_ORDER_MAIN som ON im.STANDING_ORDER_OID=som.OID " 
				+" INNER JOIN CDM.CORPORATE_MASTER cm ON im.CORPORATE_CODE = cm.CORPORATE_CODE " 
				+" INNER JOIN ICS.ICS_STD_ORDER_PROCESS_LOG iso ON im.OID = iso.INVOICE_MAIN_OID AND som.OID=iso.STANDING_ORDER_OID " 
				+" WHERE im.STATUS=1 AND som.STATUS=1 AND som.STANDING_ORDER_STATUS='%s' AND im.PAYMENT_STATUS='%s' AND som.STANDING_ORDER_TYPE='%s' " 
				+" AND som.CUSTOMER_NO=%s AND som.CHANNEL_CODE='%s' AND cm.STATUS=1 AND cm.CORPORATE_ACTIVENESS='%s' AND iso.PROCESS_STATUS='2'";
		public static final String CORPORATE_LIST_FOR_STANDING_ORDER="SELECT distinct cm.OID, cm.CORPORATE_CODE, cm.CORPORATE_NAME, cm.CORPORATE_ACTIVENESS, cm.SHORT_CODE,ctf.IS_APPEARANCE_PAYMENT_SCREEN "
			+" FROM cdm.CORPORATE_MASTER cm INNER JOIN cdm.CHANNEL_SOURCE_DEF csd "
			+" ON cm.OID = csd.CORPORATE_OID INNER JOIN cdm.COLLECTION_TYPE_DEF ctf ON cm.OID=ctf.CORPORATE_OID "
			+" WHERE cm.STATUS = 1 and csd.STATUS=1 and ctf.ALLOW_AUTO_COLLECTION=1 and ctf.STATUS=1"
			+" AND cm.SECTOR_CODE = '%s' "
			+" AND cm.CORPORATE_ACTIVENESS = '%s' " 
			+" AND csd.CHANNEL_CODE='%s' ORDER BY cm.short_code";
	}
	
	
	public static final class CollectionReconciliationSameDayStarterHandlerRepository {
		public static final String FETCH_RECON_CORPORATES = "SELECT CM.CORPORATE_CODE, CM.CORPORATE_BANK_CODE, BP.BATCH_NAME, BP.OID AS BATCH_PROCESS_OID FROM CDM.CORPORATE_MASTER CM,CDM.CORPORATE_BATCH_PROCESS BP, CDM.BATCH_DEF BD " +
				"WHERE CM.STATUS =1 AND BP.STATUS =1 AND CM.CORPORATE_CODE = BP.CORPORATE_CODE " +
				"AND BD.BATCH_NAME = BP.BATCH_NAME  AND bd.batch_service_name = 'ICS_COLLECTION_RECONCILIATION_SAME_DAY_STARTER'";
	}
	
	public static final class CollectionReconciliationStarterHandlerRepository {
		public static final String FETCH_RECON_CORPORATES = "SELECT CM.CORPORATE_CODE, CM.CORPORATE_BANK_CODE, BP.BATCH_NAME, BP.OID AS BATCH_PROCESS_OID FROM CDM.CORPORATE_MASTER CM,CDM.CORPORATE_BATCH_PROCESS BP, CDM.BATCH_DEF BD " +
				"WHERE CM.STATUS =1 AND BP.STATUS =1 AND CM.CORPORATE_ACTIVENESS='A' AND CM.CORPORATE_CODE = BP.CORPORATE_CODE " +
				"AND BD.BATCH_NAME = BP.BATCH_NAME  AND bd.batch_service_name = 'ICS_COLLECTION_RECONCILIATION_STARTER'";
		public static final String FETCH_RECON_STATUSES = "select cm.CORPORATE_code,cm.short_code,rl.recon_status,rl.recon_type,rl.bank_count,rl.bank_amount,rl.corporate_count,rl.corporate_amount,rl.bank_cancel_count," +
				"rl.bank_cancel_amount,rl.corporate_cancel_count,rl.corporate_cancel_amount,rl.error_code,rl.error_desc from ics.recon_log rl, cdm.corporate_master cm" +
				" where rl.recon_date like ? and rl.corporate_code=cm.corporate_code and rl.status=1 and cm.status=1";
	}
	
	public static final class CommonBusinessOperationsRepository {
		public static final String GET_COLLECTION_TYPE_NAME_QUERY = "SELECT collection_name FROM cdm.collection_type_prm WHERE collection_type=%s";
		public static final String GET_CHANNEL_NAME_QUERY = "SELECT g.aciklama FROM bnspr.gnl_kanal_grup_kod_pr g WHERE g.kod = %s";
		public static final String GET_PAYMENT_SOURCE_NAME_QUERY = "SELECT source_name FROM cdm.source_param WHERE source_code = %s";
		public static final String GET_CORPORATE_NAME_QUERY = "SELECT corporate_name FROM cdm.corporate_master WHERE corporate_code='%s' and status=1";
		public static final String GET_CORPORATE_SHORT_CODE_QUERY = "SELECT short_code FROM cdm.corporate_master WHERE corporate_code='%s' AND status=1";
		public static final String GET_CORPORATE_NAME_OID_QUERY = "SELECT corporate_name FROM cdm.corporate_master WHERE oid='%s'";
		public static final String GET_CORPORATE_CODE_OID_QUERY = "SELECT corporate_code FROM cdm.corporate_master WHERE oid='%s'";
		public static final String GET_CORPORATE_OID_CODE_QUERY = "SELECT oid FROM cdm.corporate_master WHERE status=1 and corporate_code='%s'";
		public static final String GET_BRANCH_NAME_QUERY = "SELECT sube_adi FROM bnspr.gnl_sube_kod_pr WHERE kod='%s'";
		public static final String GET_PREV_TX_NO_QUERY = "select max(cm.tx_no) from %s cm join bnspr.muh_islem mi on cm.tx_no=mi.numara " +
				"where cm.tx_no < %s and mi.durum in ('P','3') and cm.corporate_code='%s'";
		public static final String GET_MERCHANT_CODE = "SELECT value FROM cdm.corporate_parameters WHERE status=1 AND corporate_code='%s' AND key='CC_MERCHANT_CODE'";
		public static final String GET_SOURCE_NAME = "SELECT source_name FROM cdm.source_param WHERE source_code='%s'";
	}
	
	public static final class ControlInvoiceCollectionHandlerRepository {
		public static final String GET_SECTOR_CODE_QUERY = "SELECT cm.sector_code FROM cdm.corporate_master cm WHERE cm.corporate_code = '%s' and status=1";
	}
	
	public static final class CorporateAccountControlHandlerRepository {
		public static final String FETCH_CONCENTRATION_QUERY = "SELECT SUBSCRIBER_NO, VIEW_ORDER, DEFINITION_ID " +
				"FROM CDM.ACCOUNT_MATCHING_TREE amt INNER JOIN CDM.SUBSCRIBER_MASK_DETAIL smd " +
				"ON amt.LABEL = smd.OID WHERE amt.STATUS=1 AND amt.DEFINITION_ID IN (SELECT ACCOUNT_MATCH_DEF_ID FROM CDM.ACCOUNT_COLLECTION_TYPE_REL " +
				"WHERE ACCOUNT_MASTER_OID IN (SELECT OID FROM CDM.CORPORATION_ACCOUNT_MASTER WHERE CORPORATE_OID = '%s' AND STATUS=1) AND STATUS=1)";
		public static final String GET_ACCOUNT_NO_QUERY = "select cam.ACCOUNT_NUMBER from CDM.CORPORATION_ACCOUNT_MASTER cam INNER JOIN CDM.ACCOUNT_COLLECTION_TYPE_REL act ON cam.OID = act.ACCOUNT_MASTER_OID "
				+ "WHERE cam.CORPORATE_OID = :oid AND cam.ACCOUNT_DEFINITION_TYPE = :acttype AND "
				+ "cam.STATUS = 1 AND act.STATUS = 1 AND act.COLLECTION_TYPE = :cotype AND act.SOURCE_CODE = :scode AND act.CHANNEL_CODE = :chcode";
	}
	
	public static final class DailyPaymentTransactionReportHandlerRepository {
		public static final String FETCH_DAILY_PAYMENT_REPORT_QUERY = "SELECT count(*),sum(payment_amount),corporate_code FROM ICS.INVOICE_PAYMENT WHERE  payment_date LIKE :currentDate and payment_status = 'T' and status = 1 " +
				" GROUP BY substr(payment_date,0,8),corporate_code order by count(*) desc";
	}
	
	public static final class DeleteWaitedInvoiceHandlerRepository {
		public static final String UPDATE_INVOICE_STATUS_COMMAND = "UPDATE ics.invoice_main SET status=0, deleted_transfer_id = %s WHERE corporate_code='%s' AND payment_status='%s' AND status=1";
	}
	
	public static final class FTSGetTotalCancelledStandingOrderCountHandlerRepository {
		public static final String GET_COUNT_OF_CANCELLED_STD_ORD_QUERY = "SELECT COUNT(*) AS TOTAL_COUNT " +
				"FROM sto.STANDING_ORDER_MAIN som INNER JOIN ics.ICS_STANDING_ORDERS iso ON som.OID = iso.STANDING_ORDER_OID " +
				"WHERE som.STATUS=1 AND iso.STATUS=1 AND som.CANCEL_DATE LIKE '%s%%' AND iso.CORPORATE_CODE = '%s' AND som.STANDING_ORDER_STATUS = '%s'";
	}
	
	public static final class FTSGetTotalStandingOrderCountHandlerRepository {
		public static final String GET_COUNT_OF_STD_ORD_QUERY = "SELECT COUNT(*) AS TOTAL_COUNT " +
				"FROM sto.STANDING_ORDER_MAIN som INNER JOIN ics.ICS_STANDING_ORDERS iso ON som.OID = iso.STANDING_ORDER_OID " +
				"WHERE som.STATUS=1 AND iso.STATUS=1 AND som.CANCEL_DATE LIKE '%s%%' AND iso.CORPORATE_CODE = '%s' AND som.STANDING_ORDER_STATUS = '%s'";
	}
	
	public static final class InvoiceDebtLoadingHandlerRepository {
		public static final String CONTROL_DUPLICATE_LINE_QUERY = "SELECT COUNT(DISTINCT(LINE)) FROM ftm.ftm_file_content WHERE ftm_process_oid = %s and " +
				"(line is not null or line != '')";
		public static final String UPDATE_INVOICE_STATUS_ACTIVE_COMMAND = "UPDATE ICS.INVOICE_MAIN SET STATUS = 1 WHERE CORPORATE_CODE = '%s' AND FTM_SEQUENCE_NUMBER = %s AND STATUS = 0";
		public static final String ROLLBACK_INVOICE_STATUS_COMMAND = "UPDATE ICS.INVOICE_MAIN SET STATUS = 1, DELETED_TRANSFER_ID = null WHERE DELETED_TRANSFER_ID = %s";
		public static final String NOT_EMPTY_LINE_COUNT_QUERY = "SELECT COUNT(LINE) FROM ftm.ftm_file_content WHERE ftm_process_oid = %s and " +
				"(line is not null or line != '')";
	}
	
	public static final class MoneyLoadReconciliationStarterHandlerRepository {
		public static final String FETCH_RECON_CORPORATES = "SELECT CM.CORPORATE_CODE, CM.CORPORATE_BANK_CODE, BP.BATCH_NAME, BP.OID AS BATCH_PROCESS_OID FROM CDM.CORPORATE_MASTER CM,CDM.CORPORATE_BATCH_PROCESS BP, CDM.BATCH_DEF BD " +
				"WHERE CM.STATUS =1 AND BP.STATUS =1 AND CM.CORPORATE_CODE = BP.CORPORATE_CODE " +
				"AND BD.BATCH_NAME = BP.BATCH_NAME  AND bd.batch_serv�ce_name = 'ICS_MONEY_LOAD_RECONCILIATION_STARTER'";
	}
	
	public static final class MonthlyPaymentTransactionReportHandlerRepository {
		public static final String GET_MONTHLY_REPORT_SUMMARY_QUERY = "SELECT count(*), sum(payment_amount) FROM ICS.INVOICE_PAYMENT WHERE payment_date LIKE :lastMonth and payment_status = 'T' and status = 1 " +
				" GROUP BY substr(payment_date,0,6)";
		public static final String GET_MONTHLY_REPORT_DETAIL_QUERY = "SELECT count(*),sum(payment_amount),corporate_code FROM ICS.INVOICE_PAYMENT WHERE  payment_date LIKE :lastMonth and payment_status = 'T' and status = 1 " +
				" GROUP BY substr(payment_date,0,6),corporate_code order by count(*) desc";
	}
	
	public static final class OnlineStandingOrderDebtLoadingRepository {
		public static final String GET_STD_ORD_CORPORATES_QUERY = "SELECT CM.CORPORATE_CODE, CM.SHORT_CODE, CM.CORPORATE_BANK_CODE, BP.BATCH_NAME, BP.OID AS BATCH_PROCESS_OID FROM CDM.CORPORATE_MASTER CM," +
				"CDM.CORPORATE_BATCH_PROCESS BP, CDM.BATCH_DEF BD WHERE CM.STATUS =1 AND BP.STATUS =1 AND CM.CORPORATE_CODE = BP.CORPORATE_CODE " +
				"AND BD.BATCH_NAME = BP.BATCH_NAME  AND bd.batch_serv�ce_name = 'ICS_ONLINE_STANDING_ORDER_DEBT_LOADING'";
		public static final String GET_STD_ORD_CORPORATE_CODE_QUERY=" AND CM.CORPORATE_CODE='%s'";
	}
	
	public static final class SameDayCorporateAccountTransferHandlerRepository {
		public static final String GET_BRANCH_CODE_QUERY = "SELECT h.sube_kodu FROM muh_hesap h WHERE h.hesap_no = %s";
	}
	
	public static final class SequenceCodeResetHandlerRepository {
		public static final String FETCH_SEQ_CODES_QUERY = "SELECT ID, KEY1, TEXT FROM bnspr.v_ml_gnl_param_text WHERE KOD='CDM_SEQUENCE_CODES'";
		public static final String UPDATE_SEQ_CODE_COMMAND = "UPDATE�BNSPR.GNL_GENEL_KOD�SET�KOD_DEGER=0�WHERE�KOD_ADI='%s'";
		public static final String UPDATE_PARAM_TEXT_COMMAND = "UPDATE bnspr.v_ml_gnl_param_text SET TEXT = '%s|%s|%s' WHERE ID=%s";
	}
	
	public static final class StandingOrderInvoiceCollectionHandlerRepository {
		public static final String FETCH_INVOICES_COLLECTION_QUERY = "SELECT SA.ACCOUNT_NUMBER,  SA.CARD_NUMBER,  M.OID AS INVOICE_MAIN_OID,  M.STATUS,  M.CORPORATE_CODE,  " +
				"M.CUSTOMER_NO ,  M.COLLECTION_TYPE ,  M.SUB_COLLECTION_TYPE ,  M.INVOICE_NO , " +
				"M.AMOUNT ,  M.CURRENCY_CODE ,  M.SUBSCRIBER_NO1,  M.SUBSCRIBER_NO2,  M.SUBSCRIBER_NO3,  M.SUBSCRIBER_NO4,  M.SUBSCRIBER_NAME ,  M.STANDING_ORDER_OID , " +
				"M.INVOICE_DATE ,  M.INVOICE_DUE_DATE ,  M.INVOICE_STATUS,  M.PAYMENT_STATUS,  M.PAYMENT_METHOD,  M.INSTALLMENT_NO,  M.BRANCH_CODE ,  M.ZONE_CODE ,  M.TERM_YEAR , " +
				"M.TERM_MONTH ,  M.FTM_SEQUENCE_NUMBER ,  M.LOADING_DATE ,  M.LOADING_USER ,  M.CANCEL_DATE ,  M.CANCEL_USER ,  M.TX_NO ,  M.REC_DATE ,  M.REC_OWNER ,  M.SUBSCRIBER_PIDNO , " +
				"M.SUBSCRIBER_EMAIL ,  M.SUBSCRIBER_PHONE ,  M.SUBSCRIBER_MOBILE ,  M.PARAMETER1 ,  M.PARAMETER2 ,  M.PARAMETER3 ,  M.PARAMETER4 ,  M.PARAMETER5 ,  M.PARAMETER6 , " +
				"M.PARAMETER7 ,M.PARAMETER8 ,M.PARAMETER9 ,M.PARAMETER10 ,  M.CORPORATE_PAYMENT_ID ,  M.PAYMENT_AMOUNT, " +
				"M.PARAMETER11 ,M.PARAMETER12 ,M.PARAMETER13 ,M.PARAMETER14,M.PARAMETER15 ,M.PARAMETER16 ,M.PARAMETER17 ,M.PARAMETER18," +
				"M.PARAMETER19 ,M.PARAMETER20, CM.ALLOW_PART_PAYMENT " +
				"FROM ICS.INVOICE_MAIN M,  ICS.ICS_STANDING_ORDERS S,  STO.STANDING_ORDER_MAIN SM,  STO.STANDING_ORDER_ACCOUNT SA, " +
				"CDM.CORPORATE_MASTER CM " +
				"WHERE M.STATUS = 1 AND S.STATUS = 1 AND SM.STATUS = 1 AND M.STANDING_ORDER_OID = S.STANDING_ORDER_OID AND CM.STATUS=1 AND  " +
				"CM.CORPORATE_ACTIVENESS='A' AND S.CORPORATE_CODE = CM.CORPORATE_CODE " +
				"AND S.STANDING_ORDER_OID   = SM.OID AND SM.STANDING_ORDER_STATUS = '1' AND SA.STATUS=1 AND SA.STANDING_ORDER_OID     = SM.OID " +
				"AND SA.IS_USED = '1' AND (M.PAYMENT_STATUS='B' OR M.PAYMENT_STATUS='K')  AND M.INVOICE_STATUS ='A' " +
				"AND M.INVOICE_DUE_DATE = TO_CHAR(SYSDATE, 'YYYYMMDD') AND M.CORPORATE_CODE ='%s'";
	}
	
	public static final class StandingOrderInvoiceCollectionStarterHandlerRepository {
		public static final String FETCH_CORPORATES_QUERY = "SELECT CM.CORPORATE_CODE, CM.SHORT_CODE, CM.CORPORATE_BANK_CODE, CM.CORPORATE_ACTIVENESS, CM.CORPORATE_NAME," +
				"CM.COUNT_TYPE_AFTER_DUE, CM.CREATE_DATE, CM.CREATE_USER, CM.CUSTOMER_NUMBER, CM.IF_DUE_DATE_HOLIDAY, " +
				"CM.IS_ONLINE_CORPORATE, CM.MARKETING_EXPERT, CM.OID AS CORPORATE_OID, CM.PROTOCOL_START_DATE, CM.PROTOCOL_END_DATE, CM.SECTOR_CODE, CM.SHORT_CODE, CM.TX_NO, " +
				"CM.TX_STATUS, CM.ALLOW_PART_AFTER_DUE,CM.COUNT_AFTER_DUE, BP.BATCH_NAME, BP.OID AS BATCH_PROCESS_OID " +
				"FROM CDM.CORPORATE_MASTER CM,CDM.CORPORATE_BATCH_PROCESS BP, CDM.BATCH_DEF BD WHERE CM.STATUS =1 AND BP.STATUS =1 AND CM.CORPORATE_CODE = BP.CORPORATE_CODE " +
				"AND BD.BATCH_NAME = BP.BATCH_NAME  AND bd.batch_service_name = 'ICS_STANDING_ORDER_INVOICE_COLLECTION' AND CM.IS_ONLINE_CORPORATE = '%s'";
		public static final String FETCH_REPORT_QUERY = "SELECT im.CORPORATE_CODE, soa.ACCOUNT_NUMBER, som.CUSTOMER_NO, som.STANDING_ORDER_NUMBER, im.SUBSCRIBER_NO1, im.SUBSCRIBER_NO2, im.SUBSCRIBER_NO3, " +
				"im.SUBSCRIBER_NO4, im.SUBSCRIBER_NAME, im.INVOICE_DUE_DATE, im.AMOUNT, isopl.PROCESS_STATUS, isopl.ERROR_CODE, isopl.ERROR_DESC " +
				"FROM ICS.ics_std_order_process_log isopl INNER JOIN ICS.invoice_main im " +
				"ON isopl.invoice_main_oid = im.oid " +
				"INNER JOIN STO.standing_order_main som " +
				"ON isopl.standing_order_oid = som.oid " +
				"INNER JOIN STO.standing_order_account soa " +
				"ON som.oid = soa.standing_order_oid " +
				"WHERE isopl.status=1 AND isopl.master_submit_id = ? " +
				"ORDER BY im.CORPORATE_CODE ASC";
	}
	
	public static final class StartStandingOrderReconciliationBacthHandlerRepository {
		public static final String FETCH_CORPORATES_QUERY = "SELECT CM.CORPORATE_CODE, CM.CORPORATE_BANK_CODE, BP.BATCH_NAME, BP.OID AS BATCH_PROCESS_OID " +
				"FROM CDM.CORPORATE_MASTER CM,CDM.CORPORATE_BATCH_PROCESS BP, CDM.BATCH_DEF BD " +
				"WHERE CM.STATUS =1 AND BP.STATUS =1  AND CM.CORPORATE_ACTIVENESS='A' AND CM.CORPORATE_CODE = BP.CORPORATE_CODE " +
				"AND BD.BATCH_NAME = BP.BATCH_NAME  AND bd.batch_service_name = 'STO_STANDING_ORDER_RECONCILIATION_STARTER'";
	}
	
	public static final class TransferCorporateAccountHandlerRepository {
		public static final String GET_BRANCH_CODE_QUERY = "SELECT h.sube_kodu FROM muh_hesap h WHERE h.hesap_no = %s";
	}
	
	public static final class TTSReconciliationLineParserRepository {
		public static final String GET_STAN_NO_QUERY = "Select stan_no From ics.invoice_payment where (corporate_code = :corporateCode1 or corporate_code = :corporateCode2) and status = 1 and payment_date like :paymentDate";
	}
	
	public static final class CorporationChannelParameterServicesRepository{
		public static final String CHANNELS_QUERY = "SELECT g.kod, g.aciklama FROM bnspr.gnl_kanal_grup_kod_pr g WHERE g.aciklama IS NOT NULL ORDER BY to_number(g.kod)";
		public static final String CHANNELS_BY_CORPORATE_OID_QUERY = "select p.kod,p.aciklama " +
																	 "from   (select distinct(channel_code) from cdm.channel_source_def where status =1 and corporate_oid = \'%s\') d, " +
																	 "       bnspr.gnl_kanal_grup_kod_pr p " + 
																	 "where  p.kod = d.channel_code " + 
																	 "order by to_number(p.kod)";
		public static final String SOURCES_QUERY = "SELECT s.source_code, s.source_name FROM cdm.source_param s";
		public static final String SOURCES_BY_CHANNEL_QUERY = 	"SELECT s.source_code, s.source_name " +
																"FROM   cdm.channel_source_def d, cdm.source_param s " + 
																"WHERE  d.status =1 AND d.source_code = s.source_code " +
																"		AND d.corporate_oid = \'%s\' " +
																"		AND d.channel_code = \'%s\'";
	}
	
	public static final class CorporationFileTransferServicesRepository{
		public static final String FTM_FILE_DEFS_QUERY = "SELECT to_char(d.oid) oid, d.name FROM ftm.ftm_file_definition d ORDER BY d.oid";
		public static final String FILE_TRANSFER_TYPES_QUERY = "SELECT to_char(t.transfer_type) transfer_type, t.transfer_name FROM cdm.file_transfer_type_prm t";
		public static final String BATCH_NAMES_QUERY = "SELECT distinct c.batch_name, c.batch_name FROM cdm.corporate_batch_process c WHERE  c.status = 1 and c.corporate_code = ?";
		public static final String CDM_TRANSFER_NAME_QUERY = "select p.transfer_name from cdm.file_transfer_type_prm p where p.transfer_type = %s";
		public static final String COS_TRANSFER_NAME_QUERY = "select p.transfer_name from cos.order_transfer_type_prm p where p.transfer_type = %s";
		public static final String FTM_FILE_DEF_NAME_BY_OID_QUERY = "select d.name from ftm.ftm_file_definition d where d.oid = %s";
	}
	
	public static final class CreateLoadingConfirmationFileBatchRepository{
		public static final String FILE_QUERY = 
			"SELECT  M.ACCOUNT_NO, M.AMOUNT, M.COMMISSION_ACCOUNT_NO, M.COMMISSION_AMOUNT, M.CURRENCY_CODE, M.CUSTOMER_NAME, M.CUSTOMER_NO, M.EFT_REF_NO,\n" +
			"        M.ERROR_DESC, M.EXPLANATION, M.LOADING_DATE, M.LOADING_USER, M.ORDER_DATE, M.ORDER_STATUS, M.ORDER_TYPE, M.RECIPIENT_ACCOUNT_NO,\n" +
			"        M.RECIPIENT_ADDRESS, M.RECIPIENT_BANK, M.RECIPIENT_BRANCH, M.RECIPIENT_CC_NO, M.RECIPIENT_DATE_OF_BIRTH, M.RECIPIENT_EMAIL, M.RECIPIENT_FATHER_NAME,\n" +
			"        M.RECIPIENT_IBAN, M.RECIPIENT_MOTHER_NAME, M.RECIPIENT_NAME, M.RECIPIENT_PHONE_NUMBER, M.RECIPIENT_REF_NO, M.RECIPIENT_TCKN, M.RECIPIENT_VKN,\n" +
			"        M.TAX_OFFICE, M.TRANSFER_AMOUNT, M.TRANSFER_TYPE, M.TX_NO, SUBSTR(M.TRANSFER_DATE,0,8) TRANSFER_DATE, SUBSTR(M.TRANSFER_DATE,9,6) TRANSFER_TIME, M.EFT_SORGU_NO, M.FIS_NO, M.ORDER_STATUS,\n" +
			"        L.BATCH_SUBMIT_ID, L.TRY_AMOUNT TOTAL_TRY_AMOUNT, L.USD_AMOUNT TOTAL_USD_AMOUNT, L.EUR_AMOUNT TOTAL_EUR_AMOUNT,\n" +
			"        L.TRY_LINE_COUNT TOTAL_TRY_RECORD_COUNT, L.USD_LINE_COUNT TOTAL_USD_RECORD_COUNT, L.EUR_LINE_COUNT TOTAL_EUR_RECORD_COUNT,\n" +
			"        L.CUSTOMER_ACCOUNT_NO, L.CUSTOMER_BANK, L.CUSTOMER_BRANCH, L.ORDER_DATE, L.CUSTOMER_NO\n" +
			"FROM    COS.ORDER_MAIN M, COS.ORDER_FILE_LOG L\n" +
			"WHERE   M.STATUS = 1 AND L.STATUS = 1 AND L.LOADING_STATUS = 99\n" +
			"        AND M.BATCH_SUBMIT_ID = L.BATCH_SUBMIT_ID AND M.FTM_SEQUENCE_NUMBER = L.FTM_SEQUENCE_NUMBER\n" +
			"        AND M.BATCH_SUBMIT_ID = '%s' AND M.FTM_SEQUENCE_NUMBER = %s\n" +
			"ORDER BY M.LINE_NUMBER";
	}

	public static final class CreatePaymentsConfirmationFileBatchRepository{
		public static final String FILE_QUERY = 
			"SELECT  M.ACCOUNT_NO, M.AMOUNT, M.COMMISSION_ACCOUNT_NO, M.COMMISSION_AMOUNT, M.CURRENCY_CODE, M.CUSTOMER_NAME, M.CUSTOMER_NO, M.EFT_REF_NO,\n" +
			"        M.ERROR_DESC, M.EXPLANATION, M.LOADING_DATE, M.LOADING_USER, M.ORDER_DATE, M.ORDER_STATUS, M.ORDER_TYPE, M.RECIPIENT_ACCOUNT_NO,\n" +
			"        M.RECIPIENT_ADDRESS, M.RECIPIENT_BANK, M.RECIPIENT_BRANCH, M.RECIPIENT_CC_NO, M.RECIPIENT_DATE_OF_BIRTH, M.RECIPIENT_EMAIL, M.RECIPIENT_FATHER_NAME,\n" +
			"        M.RECIPIENT_IBAN, M.RECIPIENT_MOTHER_NAME, M.RECIPIENT_NAME, M.RECIPIENT_PHONE_NUMBER, M.RECIPIENT_REF_NO, M.RECIPIENT_TCKN, M.RECIPIENT_VKN,\n" +
			"        M.TAX_OFFICE, M.TRANSFER_AMOUNT, M.TRANSFER_TYPE, M.TX_NO, SUBSTR(M.TRANSFER_DATE,0,8) TRANSFER_DATE, SUBSTR(M.TRANSFER_DATE,9,6) TRANSFER_TIME, M.EFT_SORGU_NO, M.FIS_NO, M.ORDER_STATUS,\n" +
			"        L.BATCH_SUBMIT_ID, L.TRY_AMOUNT TOTAL_TRY_AMOUNT, L.USD_AMOUNT TOTAL_USD_AMOUNT, L.EUR_AMOUNT TOTAL_EUR_AMOUNT,\n" +
			"        L.TRY_LINE_COUNT TOTAL_TRY_RECORD_COUNT, L.USD_LINE_COUNT TOTAL_USD_RECORD_COUNT, L.EUR_LINE_COUNT TOTAL_EUR_RECORD_COUNT,\n" +
			"        L.CUSTOMER_ACCOUNT_NO, L.CUSTOMER_BANK, L.CUSTOMER_BRANCH, L.ORDER_DATE, L.CUSTOMER_NO\n" +
			"FROM    COS.ORDER_MAIN M, COS.ORDER_FILE_LOG L\n" +
			"WHERE   M.STATUS = 1 AND L.STATUS = 1 AND L.LOADING_STATUS = 99\n" +
			"        AND M.BATCH_SUBMIT_ID = L.BATCH_SUBMIT_ID AND M.FTM_SEQUENCE_NUMBER = L.FTM_SEQUENCE_NUMBER\n" +
			"        AND M.BATCH_SUBMIT_ID = '%s' AND M.FTM_SEQUENCE_NUMBER = %s\n" +
			"ORDER BY M.LINE_NUMBER";	
	}
	
	public static final class CreateEodPaymentsConfirmationFileBatchRepository{
		public static final String FILE_QUERY = 	
			"SELECT  M.ACCOUNT_NO, M.AMOUNT, M.COMMISSION_ACCOUNT_NO, M.COMMISSION_AMOUNT, M.CURRENCY_CODE, M.CUSTOMER_NAME, M.CUSTOMER_NO, M.EFT_REF_NO,\n" +
			"        M.ERROR_DESC, M.EXPLANATION, M.LOADING_DATE, M.LOADING_USER, M.ORDER_DATE, M.ORDER_STATUS, M.ORDER_TYPE, M.RECIPIENT_ACCOUNT_NO,\n" +
			"        M.RECIPIENT_ADDRESS, M.RECIPIENT_BANK, M.RECIPIENT_BRANCH, M.RECIPIENT_CC_NO, M.RECIPIENT_DATE_OF_BIRTH, M.RECIPIENT_EMAIL, M.RECIPIENT_FATHER_NAME,\n" +
			"        M.RECIPIENT_IBAN, M.RECIPIENT_MOTHER_NAME, M.RECIPIENT_NAME, M.RECIPIENT_PHONE_NUMBER, M.RECIPIENT_REF_NO, M.RECIPIENT_TCKN, M.RECIPIENT_VKN,\n" +
			"        M.TAX_OFFICE, M.TRANSFER_AMOUNT, M.TRANSFER_TYPE, M.TX_NO, SUBSTR(M.TRANSFER_DATE,0,8) TRANSFER_DATE, SUBSTR(M.TRANSFER_DATE,9,6) TRANSFER_TIME, M.EFT_SORGU_NO, M.FIS_NO, M.ORDER_STATUS\n" +
			"FROM    COS.ORDER_MAIN M\n" +
			"WHERE   M.STATUS = 1\n" +
			"        AND M.BATCH_SUBMIT_ID IN (SELECT L.BATCH_SUBMIT_ID\n" +
			"                                  FROM   COS.ORDER_FILE_LOG L\n" +
			"                                  WHERE  L.STATUS = 1 AND SUBSTR(L.LOG_DATE,0,8) = \'%s\'\n" +
			"                                         AND L.CORPORATE_CODE = \'%s\'\n" +
			"                                         AND L.TRANSFER_TYPE = 1 AND L.LOADING_STATUS = 99 AND L.FILE_STATUS != -1 )\n" +        
			"ORDER BY M.BATCH_SUBMIT_ID DESC, M.LINE_NUMBER";
	}
	
	public static final class OrderCorporationDefinitionServicesRepository{
		public static final String COS_ACCOUNT_TYPE_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_ACCOUNT_TYPE' AND key1 = \'%s\'";
		public static final String COS_ORDER_TYPE_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_ORDER_TYPE' AND key1 = \'%s\'";
		public static final String MUSTERI_NO_BY_HESAP_NO_QUERY = "SELECT musteri_no FROM bnspr.muh_hesap WHERE hesap_no = %s";
		public static final String HESAP_NO_BY_IBAN_QUERY = "SELECT hesap_no FROM bnspr.muh_hesap WHERE iban = \'%s\'";
		public static final String SUBE_KODU_BY_HESAP_NO_QUERY = "SELECT sube_kodu FROM bnspr.muh_hesap WHERE hesap_no = %s";
		public static final String BRANCH_CODE_VALIDITY_BY_BANK_CODE_QUERY = "SELECT sube_kod FROM bnspr.gnl_banka_sube_kod_pr WHERE banka_kod = '%s' AND sube_kod = '%s' AND kapanma_tarihi IS NULL";
		public static final String BRANCH_CODE_VALIDITY_QUERY = "SELECT kod FROM bnspr.gnl_sube_kod_pr WHERE kod = '%s' AND kapanma_tar IS NULL";
		public static final String ERROR_MESSAGE_QUERY = "SELECT m.mesaj FROM BNSPR.gnl_mesaj_pr m WHERE m.dil_kod = 'TR' AND m.kanal_kod = 1 AND m.mesaj_no = %s";
	}
	
	public static final class OrderLoadingServicesRepository{
		public static final String COS_ORDER_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_ORDER_STATUS' AND key1 = \'%s\'";
		public static final String COS_ORDER_TYPE_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_ORDER_TYPE' AND key1 = \'%s\'";
		public static final String GET_FILE_NAME_QUERY = "SELECT file_name FROM ftm.ftm_process WHERE ftm_file_definition_oid = %s AND oid = %s";
		public static final String SEARCH_FILE_NAME_QUERY = "SELECT file_name FROM ftm.ftm_process WHERE ftm_file_definition_oid = %s AND oid = %s AND upper(file_name) LIKE upper(\'%%%s%%\')";
		public static final String COS_LOADING_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_LOADING_STATUS' AND key1 = \'%s\'";
		public static final String COS_FILE_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_FILE_STATUS' AND key1 = \'%s\'";
	}
	
	public static final class OrderTransferServicesRepository{
		public static final String COS_ORDER_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_ORDER_STATUS' AND key1 = \'%s\'";
		public static final String COS_ORDER_TYPE_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_ORDER_TYPE' AND key1 = \'%s\'";
		public static final String COS_LOADING_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_LOADING_STATUS' AND key1 = \'%s\'";
		public static final String COS_FILE_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_FILE_STATUS' AND key1 = \'%s\'";
	}
	
	public static final class ReportServicesRepository{
		public static final String GET_FILE_NAME_QUERY = "SELECT file_name FROM ftm.ftm_process WHERE ftm_file_definition_oid = %s AND oid = %s";
		public static final String SEARCH_FILE_NAME_QUERY = "SELECT file_name FROM ftm.ftm_process WHERE ftm_file_definition_oid = %s AND oid = %s AND upper(file_name) LIKE upper(\'%%%s%%\')";		
		public static final String GET_BRANCH_CODE_QUERY = "SELECT mus.sube_kodu\n" +
														   "FROM   cos.corporation_def cdef, bnspr.v_gnl_musteri_aktif mus\n" +
														   "WHERE  cdef.status = 1 AND cdef.customer_no = mus.musteri_no AND cdef.corporate_code = '%s'";
		public static final String COS_LOADING_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_LOADING_STATUS' AND key1 = \'%s\'";
		public static final String COS_FILE_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_FILE_STATUS' AND key1 = \'%s\'";
		public static final String ORDER_FILES_SUMMARY_QUERY = 
			"SELECT lg.corporate_code,\n" +
			"       cdef.short_name CORPORATE_SHORT_NAME,\n" +
			"       SUM(lg.try_line_count) TOTAL_TRY_LINE_COUNT,\n" +
			"       SUM(lg.try_amount) TOTAL_TRY_AMOUNT,\n" +
			"       SUM(lg.usd_line_count) TOTAL_USD_LINE_COUNT,\n" +
			"       SUM(lg.usd_amount) TOTAL_USD_AMOUNT,\n" +
			"       SUM(lg.eur_line_count) TOTAL_EUR_LINE_COUNT,\n" +
			"       SUM(lg.eur_amount) TOTAL_EUR_AMOUNT,\n" +
			"       COUNT(*) TOTAL_FILE_COUNT,\n" +
			"       (SELECT COUNT(*)\n" +
			"        FROM   cos.order_main m, cos.order_file_log l, cos.corporation_def cdef, ftm.ftm_process p\n" +
			"        WHERE  m.status = 1 AND m.batch_submit_id = l.batch_submit_id AND m.currency_code = 'TRY'\n" +
			"               AND m.order_status = '99'\n" +
			"               AND l.status = 1 AND l.loading_status = '99' AND l.file_status != -1\n" +
			"               AND cdef.status = 1 AND cdef.corporate_code = l.corporate_code \n" +
			"               AND l.ftm_sequence_number = p.oid(+) \n" +
			"               AND l.corporate_code = lg.corporate_code \n"	 +
			"               AND (l.corporate_code = nvl(%s, l.corporate_code) or l.corporate_code is null)\n" +
			"               AND trunc(to_date(l.log_date, 'YYYYMMDDHH24MISS')) >= \'%s\'\n" +
			"               AND trunc(to_date(l.log_date, 'YYYYMMDDHH24MISS')) <= \'%s\'\n" +
			"               AND (p.file_name(+) = NVL(%s, p.file_name(+)) OR upper(p.file_name(+)) LIKE upper(%s))\n" +
			"               AND (l.file_status = nvl(%s, l.file_status) or l.file_status is null)) TRANSFERED_TRY_LINE_COUNT,\n" +
			"       (SELECT SUM(m.amount)\n" +
			"        FROM   cos.order_main m, cos.order_file_log l, cos.corporation_def cdef, ftm.ftm_process p\n" +
			"        WHERE  m.status = 1 AND m.batch_submit_id = l.batch_submit_id AND m.currency_code = 'TRY'\n" +
			"               AND m.order_status = '99'\n" +
			"               AND l.status = 1 AND l.loading_status = '99' AND l.file_status != -1\n" +
			"               AND cdef.status = 1 AND cdef.corporate_code = l.corporate_code \n" +
			"               AND l.ftm_sequence_number = p.oid(+) \n" +
			"               AND l.corporate_code = lg.corporate_code \n"	 +
			"               AND (l.corporate_code = nvl(%s, l.corporate_code) or l.corporate_code is null)\n" +
			"               AND trunc(to_date(l.log_date, 'YYYYMMDDHH24MISS')) >= \'%s\'\n" +
			"               AND trunc(to_date(l.log_date, 'YYYYMMDDHH24MISS')) <= \'%s\'\n" +
			"               AND (p.file_name(+) = NVL(%s, p.file_name(+)) OR upper(p.file_name(+)) LIKE upper(%s))\n" +
			"               AND (l.file_status = nvl(%s, l.file_status) or l.file_status is null)) TRANSFERED_TRY_AMOUNT,\n" +
			"       (SELECT COUNT(*)\n" +
			"        FROM   cos.order_main m, cos.order_file_log l, cos.corporation_def cdef, ftm.ftm_process p\n" +
			"        WHERE  m.status = 1 AND m.batch_submit_id = l.batch_submit_id AND m.currency_code = 'TRY'\n" +
			"               AND m.order_status != '99'\n" +
			"               AND l.status = 1 AND l.loading_status = '99' AND l.file_status != -1\n" +
			"               AND cdef.status = 1 AND cdef.corporate_code = l.corporate_code \n" +
			"               AND l.ftm_sequence_number = p.oid(+) \n" +
			"               AND l.corporate_code = lg.corporate_code \n" +
			"               AND (l.corporate_code = nvl(%s, l.corporate_code) or l.corporate_code is null)\n" +
			"               AND trunc(to_date(l.log_date, 'YYYYMMDDHH24MISS')) >= \'%s\'\n" +
			"               AND trunc(to_date(l.log_date, 'YYYYMMDDHH24MISS')) <= \'%s\'\n" +
			"               AND (p.file_name(+) = NVL(%s, p.file_name(+)) OR upper(p.file_name(+)) LIKE upper(%s))\n" +
			"               AND (l.file_status = nvl(%s, l.file_status) or l.file_status is null)) NOT_TRANSFERED_TRY_LINE_COUNT,\n" +
			"       (SELECT SUM(m.amount)\n" +
			"        FROM   cos.order_main m, cos.order_file_log l, cos.corporation_def cdef, ftm.ftm_process p\n" +
			"        WHERE  m.status = 1 AND m.batch_submit_id = l.batch_submit_id AND m.currency_code = 'TRY'\n" +
			"               AND m.order_status != '99'\n" +
			"               AND l.status = 1 AND l.loading_status = '99' AND l.file_status != -1\n" +
			"               AND cdef.status = 1 AND cdef.corporate_code = l.corporate_code \n" +
			"               AND l.ftm_sequence_number = p.oid(+) \n" +
			"               AND l.corporate_code = lg.corporate_code \n" +
			"               AND (l.corporate_code = nvl(%s, l.corporate_code) or l.corporate_code is null)\n" +
			"               AND trunc(to_date(l.log_date, 'YYYYMMDDHH24MISS')) >= \'%s\'\n" +
			"               AND trunc(to_date(l.log_date, 'YYYYMMDDHH24MISS')) <= \'%s\'\n" +
			"               AND (p.file_name(+) = NVL(%s, p.file_name(+)) OR upper(p.file_name(+)) LIKE upper(%s))\n" +
			"               AND (l.file_status = nvl(%s, l.file_status) or l.file_status is null)) NOT_TRANSFERED_TRY_AMOUNT\n" +
			"FROM   cos.order_file_log lg, cos.corporation_def cdef, ftm.ftm_process p\n" +
			"WHERE  lg.status = 1 AND lg.loading_status = '99' AND lg.file_status != -1\n" +
			"       AND cdef.status = 1 AND cdef.corporate_code = lg.corporate_code \n" +
			"       AND lg.ftm_sequence_number = p.oid(+) \n" +
			"       AND (lg.corporate_code = nvl(%s, lg.corporate_code) or lg.corporate_code is null)\n" +
			"       AND trunc(to_date(lg.log_date, 'YYYYMMDDHH24MISS')) >= \'%s\'\n" +
			"       AND trunc(to_date(lg.log_date, 'YYYYMMDDHH24MISS')) <= \'%s\'\n" +
			"       AND (p.file_name(+) = NVL(%s, p.file_name(+)) OR upper(p.file_name(+)) LIKE upper(%s))\n" +
			"       AND (lg.file_status = nvl(%s, lg.file_status) or lg.file_status is null)\n" +
			"GROUP BY lg.corporate_code, cdef.short_name";
		
		public static final String DETAIL_TRANSACTION_REPORT_QUERY =
			"select t.corporate_code,\n" + 
			"       sum(t.amount) try_amount, count(*) try_count,\n" +
			"       sum(decode(t.order_type, 1, t.amount, 0)) eft_amount, sum(decode(t.order_type, 1, 1, 0)) eft_count,\n" +
			"       sum(decode(t.order_type, 2, t.amount, 0)) havale_amount, sum(decode(t.order_type, 2, 1, 0)) havale_count,\n" +
			"       sum(decode(t.order_type, 3, t.amount, 0)) virman_amount, sum(decode(t.order_type, 3, 1, 0)) virman_count,\n" +
			"       sum(decode(t.order_type, 4, t.amount, 0)) ptt_amount, sum(decode(t.order_type, 4, 1, 0)) ptt_count,\n" +
			"       sum(decode(t.order_type, null, t.amount, 0)) unk_amount, sum(decode(t.order_type, null, 1, 0)) unk_count\n" +       
			"from  cos.order_main t \n" +
			"where t.status = 1 and (t.order_status = '99' or t.order_type is null)\n" +
			"      and t.transfer_date >= \'%s\' and t.transfer_date <= \'%s\'\n" +
			"group by t.corporate_code\n" +
			"order by t.corporate_code";
	}

	public static final class CosBatchUtilitiesRepository{
		public static final String BATCH_NAME_QUERY = "SELECT BATCH_NAME FROM COS.ORDER_BATCH_DEF WHERE STATUS = 1";
		public static final String TRANSFER_TYPES_QUERY = "SELECT TRANSFER_TYPE, TRANSFER_NAME FROM COS.ORDER_TRANSFER_TYPE_PRM";
	}
	
	public static final class CPSReportsRepository{
		public static final String SUBE_LIST_QUERY = 
	        "select a.sube_kodu, b.sube_adi " +
	        "from gnl_erisim a, gnl_sube_kod_pr b " +
	        "where a.kullanici_kodu = PKG_GLOBAL.GET_KULLANICIKOD " +
	        "and  a.sube_kodu = b.kod " +
	        "and ( pkg_muhasebe.Banka_Tarihi_Bul >= a.baslangic_tarihi OR a.baslangic_tarihi is null) " +
	        "and  a.sube_kodu = b.kod " +
	        "and ( pkg_muhasebe.Banka_Tarihi_Bul < a.bitis_tarihi OR a.bitis_tarihi is null)";
		
		public static final String FILE_TRANSFER_DETAILS_QUERY = 
			"SELECT ftrLog.Corporate_Code,\n" +
			"       (select a.corporate_name from cdm.corporate_master a where a.status = 1 and a.corporate_code = ftrLog.corporate_code) corporate_name,\n" +
			"       (select b.transfer_name from cdm.file_transfer_type_prm b where b.transfer_type = ftrLog.transfer_type) transfer_type_detail,\n" +
			"       trunc(to_date(ftrLog.Log_Date, 'YYYYMMDDHH24MISS')) log_date,\n" +
			"       substr(ftrLog.Log_Date,9,6) log_time, ftrLog.Log_Date,\n" +
			"       decode(file_def_type_oid, 1, 'Gelen', 2, 'Giden') transfer_type,\n" +
			"       (select a.text from bnspr.v_ml_gnl_param_text a where a.kod = 'CDM_FILE_TRANSFER_STATUS' and a.KEY1 = ftrLog.Transfer_Status) transfer_status,\n" +
			"       ftm_file_def.file_name_mask, p.file_name, ftp_folder,\n" +
			"       ftm_file_def.duration, ftrLog.Error_Desc err_desc \n" +
			"FROM   cdm.file_transfer_log ftrLog,\n" +
			"       cdm.corporate_file_transfer ftr,\n" +
			"       ftm.ftm_process p,\n" +
			"       cdm.corporate_master m,\n" +
			"       (SELECT ftm_file_def_type.oid file_def_type_oid, ftm_file_def.name, ftm_file_def.oid, ftm_file_def.file_name_mask,\n" +
			"               ftp_source_def.name source_name, ftp_source_def.url source_url, ftp_source.path source_path,\n" +
			"               ftp_dest_def.name dest_name, ftp_dest_def.url dest_url, ftp_dest.path dest_path,\n" +
			"               ftm_file_def_type.file_definition_type, ftm_file_def.duration,\n" +
			"               decode(ftm_file_def_type.oid, 1, ftp_dest.path, 2, ftp_source.path) ftp_folder\n" +
			"        FROM   ftm.ftm_file_definition_ftp ftp_source,\n" +
			"               ftm.ftm_file_definition_ftp ftp_dest,\n" +
			"               ftm.ftm_file_definition ftm_file_def,\n" +
			"               ftm.ftm_file_definition_type ftm_file_def_type,\n" +
			"               ftm.ftm_ftp_definition ftp_source_def,\n" +
			"               ftm.ftm_ftp_definition ftp_dest_def\n" +
			"        WHERE  ftm_file_def.ftm_state_oid = 1 AND ftp_source_def.ftm_state_oid = 1 AND ftp_dest_def.ftm_state_oid = 1\n" +
			"               AND ftp_source.ftm_file_definition_oid = ftp_dest.ftm_file_definition_oid\n" +
			"               AND ftp_source.ftm_file_definition_oid = ftm_file_def.oid \n" +
			"               AND ftp_source.ftm_ftp_definition_oid = ftp_source_def.oid\n" +
			"               AND ftp_dest.ftm_ftp_definition_oid = ftp_dest_def.oid\n" +
			"               AND ftp_source.ftm_file_def_ftp_type_oid = 1\n" +
			"               AND ftp_dest.ftm_file_def_ftp_type_oid = 2\n" +
			"               AND ftm_file_def.ftm_file_definition_type_oid = ftm_file_def_type.oid) ftm_file_def\n" +
			"WHERE  ftrLog.Status = 1 AND ftr.status = 1 AND m.status = 1\n" +
			"       AND ftr.file_transfer_id = ftrLog.File_Transfer_Id\n" +
			"       AND ftm_file_def.oid = ftrLog.Ftm_Id\n" +
			"       AND p.oid = ftrLog.Ftm_Sequence_Number\n" +
			"       AND ftrLog.Corporate_Code = m.corporate_code\n" +
			"       AND ftrLog.corporate_code = nvl(%s, ftrLog.corporate_code)\n" +
			"       AND m.sector_code = nvl(%s, m.sector_code)\n" +
			"       AND ftm_file_def.file_def_type_oid = %s\n" +
			"       AND ftrLog.Transfer_Status = nvl(%s, ftrLog.Transfer_Status)\n" +
			"       AND upper(ftp_folder) like upper('%%%s%%')\n" +
			"       AND substr(ftrLog.Log_Date,1,8) between %s and %s\n" +
			"ORDER BY trunc(to_date(ftrLog.Log_Date, 'YYYYMMDDHH24MISS')), corporate_name, ftrLog.Log_Date";
			
		public static final String PAYMENT_MONITORING_REPORT_QUERY = 
			  "select ip.payment_channel, " +
			  " 	ip.corporate_code, " +
			  " 	sum(ip.payment_amount) payment_amount, " +
			  " 	max(cm.short_code) corporate_name," +
			  "		count(ip.payment_channel) channel_count " +
			  " from ics.invoice_payment ip, cdm.corporate_master cm " +
			  " where ip.payment_status = 'T' " +
			  " 	and ip.status = '1' " +
			  " 	and cm.corporate_code = ip.corporate_code " +
			  " 	and cm.status = '1' " +
			  " 	and ip.payment_date like to_char(sysdate, 'YYYYMMDD') || '%'  " + // '20131213%'
			  "		and ip.payment_channel in ('21','32') " +  // 32 FOM/YIM 21 EPOS/Aktif Nokta
			  "group by ip.payment_channel, ip.corporate_code " +
			  "order by payment_amount desc, ip.corporate_code, ip.payment_channel";
			  
		public static final String YIM_RECEIPT_QUERY = 
			 "Select Pkg_IBAN.IBAN_GECIS_KONTROL iban_kontrol,decode(v.musteri_no,null,null,pkg_musteri.tur(v.musteri_no)) as mustur, " + 
			 "       d.vergi_d_adi, " + 
			 "       v.islem_turu , " + 
			 "       Decode ( v.hitap , null ,  v.isl_adi , v.hitap || ' ' || v.isl_adi ) ISL_ADI, " + 
			 "       v.isl_adres , " + 
			 "       v.isl_vergino , " + 
			 "       d.vergi_d_adi , " + 
			 "       v.musteri_no , " + 
			 "       v.isl_tckimlik ISL_TCKIMLIK, " + 
			 "       To_char ( v.islem_tarihi , 'dd/mm/yyyy' ) || '    Val�r : ' || To_char ( v.valor , 'dd/mm/yyyy' ) TARIH , " + 
			 "       Decode ( v.sube_kodu , Null , Null , v.sube_kodu || ' / ' || pkg_genel_pr.sube_adi(v.sube_kodu)) SUBE_ADI, " + 
			 "       Decode ( v.musteri_no , Null , v.musteri_adi , v.musteri_no || ' / ' || v.musteri_adi ) MUSTERI_ADI , " + 
			 "       decode(Pkg_IBAN.IBAN_GECIS_KONTROL,'E',pkg_hesap.iban_formatli ( v.musteri_hesap_no),v.musteri_hesap_no || '    IBAN : ' || pkg_hesap.iban_formatli ( v.musteri_hesap_no)) HESAP_IBAN , " + 
			 "       v.islemi_yapan_ack , " + 
			 "       v.tutari , " + 
			 "       v.doviz_kodu , " + 
			 "       v.kur , " + 
			 "       v.tutar_lc , " + 
			 "       v.masraf_komisyon , " + 
			 "       v.vergi , " + 
			 "       v.aciklama , " + 
			 "       v.aciklama1 , " + 
			 "       v.aciklama2 , " + 
			 "       v.aciklama3 , " + 
			 "       v.aciklama4 , " + 
			 "       v.bankamiz_kisa_adi , " + 
			 "       v.Amir_sube_adi , " + 
			 "       v.kasa_kodu , " + 
			 "       v.kayit_kullanici_kodu ||  " + 
			 "          ' Saat : ' || To_char ( v.kayit_sistem_tarihi , 'HH24:mi' ) || ' / ' ||  " + 
			 "          ' Fis No : ' || '99000' || v.tx_no || ' / ' ||  " + 
			 "          ' Islem No : ' || v.tx_no || ' / ' ||  " + 
			 "          ' Kasa : ' || v.kasa_kodu ISLEM_DETAYI , " + 
			 "       Decode ( v.tutar_lc , Null , Null , pkg_genel_pr.Basim_Doviz_Kodu ( PKG_GENEL_PR.LC_AL )) TL_KOD , " + 
			 "       pkg_parametre.Deger_Al_K('DEKONT_ACIKLAMA_1') REKLAM_1,  " + 
			 "       pkg_parametre.Deger_Al_K('DEKONT_ACIKLAMA_2') REKLAM_2 " + 
			 "  From BNSPR.v_muh_dekont_yim v , " + 
			 "       BNSPR.gnl_vergi_daire_kod_pr d  " + 
			 " Where d.vergi_d_kod(+) = v.Musteri_vergi_d " + 
			 "   and v.tx_no = nvl(%s,203934) " + 
			 "   and v.sira_no = nvl ( null , v.sira_no ) " +
			 "   and v.musteri_no NOT IN (%s)";
		
		public static final String ECCPS_MIN_AMOUNT_CRITERIA = "       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n";
		public static final String ECCPS_MAX_AMOUNT_CRITERIA = "       and p.loaded_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n";
		public static final String MIN_AMOUNT_CRITERIA = "       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) >= %s\n";
		public static final String MAX_AMOUNT_CRITERIA = "       and p.payment_amount + decode(comm.commission_amount, null, 0, comm.commission_amount) + decode(comm.bsmv_amount, null, 0, comm.bsmv_amount) <= %s\n";
	}
	
	public static final class CheckRepeatedFileHandlerRepository{
		public static final String REPEATED_FILE_CONTENT_COUNT_QUERY = 	
			"SELECT count(*) COUNT\n" + 
			"FROM ftm.ftm_file_content f, cos.order_main m\n" +
			"WHERE f.ftm_process_oid = m.ftm_sequence_number AND f.line_number = m.line_number AND m.status = 1\n" +
			"      AND f.ftm_process_oid IN (%s) and m.loading_date LIKE '%s%%'\n" +
			"      AND f.line IN\n" +       
			"       (SELECT line\n" + 
			"        FROM ftm.ftm_file_content f, cos.order_main m\n" +
			"        WHERE f.ftm_process_oid = m.ftm_sequence_number AND f.line_number = m.line_number AND m.status = 1\n" +
			"              AND f.ftm_process_oid IN (%s) and m.loading_date LIKE '%s%%')";
	}				
	
	public static final class CheckRepeatedOrderHandlerRepository{
		public static final String REPEATED_ORDERS_QUERY = 
			"SELECT ListAgg(m.oid||' ') WITHIN GROUP (ORDER BY m.oid) repeated_oids, f.line, count(*) count\n" +
			"FROM   ftm.ftm_file_content f, cos.order_main m\n" +
			"WHERE  f.ftm_process_oid = m.ftm_sequence_number AND f.line_number = m.line_number\n" +
			"       AND m.status = 1 AND m.order_status >= '%s'\n" +
			"       AND substr(m.loading_date,0,8) = '%s' AND m.corporate_code = '%s'\n" +
			"GROUP BY f.line\n" +
			"HAVING count(*) > 1";		
	}
	
	public static final class CosCommonBusinessOperationsRepository{
		public static final String COLLECTION_TYPE_NAME_QUERY = "SELECT collection_name FROM cdm.collection_type_prm WHERE collection_type=%s";
		public static final String PREVIOUS_TX_NO_QUERY =
			"select max(cm.tx_no) from %s cm join bnspr.muh_islem mi on cm.tx_no=mi.numara " +
			"where cm.tx_no < %s " +
			"and mi.durum in ('P','3') " +
			"and cm.corporate_code='%s'";
	}
	
	public static final class ComposeEmailHandlerRepository{
		public static final String COS_ORDER_STATUS_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_ORDER_STATUS' AND key1 = \'%s\'";
		public static final String COS_ORDER_TYPE_PARAM_TEXT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_ORDER_TYPE' AND key1 = \'%s\'";
		public static final String IBAN_BY_HESAP_NO_QUERY = "SELECT iban FROM bnspr.muh_hesap WHERE hesap_no = %s";
	}
	
	public static final class CreateOutgoingFileByFtmCallHandlerRepository{
		public static final String THREAD_SLEEP_SECONDS_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_PARAMETERS' AND key1 = 'OUTGOING_FILE_THREAD_SLEEP_SECONDS'";
		public static final String FILE_TRY_COUNT_QUERY = "SELECT text FROM bnspr.v_ml_gnl_param_text WHERE kod = 'COS_PARAMETERS' AND key1 = 'OUTGOING_FILE_TRY_COUNT'";
	}
	
	public static final class DoLoadingAndPaymentControlsHandlerRepository{
		public static final String MODUL_TUR_KOD_BY_HESAP_NO_QUERY = "SELECT modul_tur_kod FROM bnspr.muh_hesap WHERE hesap_no = %s";;
		public static final String DURUM_KODU_BY_HESAP_NO_QUERY = "SELECT durum_kodu FROM bnspr.muh_hesap WHERE hesap_no = %s";
		public static final String HESAP_HAREKET_KODU_BY_HESAP_NO_QUERY = "SELECT hesap_hareket_kodu FROM bnspr.muh_hesap WHERE hesap_no = %s";
		public static final String MUSTERI_NO_BY_HESAP_NO_QUERY = "SELECT musteri_no FROM bnspr.muh_hesap WHERE hesap_no = %s";
		public static final String MUSTERI_NO_BY_IBAN_QUERY = "SELECT musteri_no FROM bnspr.muh_hesap WHERE iban = \'%s\'";
		public static final String HESAP_NO_BY_IBAN_QUERY = "SELECT hesap_no FROM bnspr.muh_hesap WHERE iban = \'%s\'";
		public static final String DOVIZ_KODU_BY_HESAP_NO_QUERY = "SELECT doviz_kodu FROM bnspr.muh_hesap WHERE hesap_no = %s";
		public static final String ACCOUNT_NAME_BY_HESAP_NO_QUERY = "SELECT kisa_isim FROM bnspr.muh_hesap WHERE hesap_no = %s";
		public static final String DOVIZ_KODU_VALIDITY_QUERY = "SELECT kod FROM bnspr.gnl_doviz_kod_pr WHERE kod = '%s'";
		public static final String BANKA_KODU_VALIDITY_QUERY = "SELECT kod FROM bnspr.gnl_banka_kod_pr WHERE kod = '%s' AND kapanma_tarihi IS NULL";
		public static final String SUBE_KODU_VALIDITY_BY_BANKA_KODU_QUERY = "SELECT sube_kod FROM bnspr.gnl_banka_sube_kod_pr WHERE banka_kod = '%s' AND sube_kod = '%s' AND kapanma_tarihi IS NULL";
		public static final String SUBE_KODU_VALIDITY_QUERY = "SELECT kod FROM bnspr.gnl_sube_kod_pr WHERE kod = '%s' AND kapanma_tar IS NULL";
		public static final String SUBE_KODU_BY_HESAP_NO_QUERY = "SELECT sube_kodu FROM bnspr.muh_hesap WHERE hesap_no = %s";
		public static final String TC_KIMLIK_NO_BY_MUSTERI_NO_QUERY = "SELECT tc_kimlik_no FROM bnspr.gnl_musteri WHERE musteri_no = %s AND durum_kodu = 'A'";
		public static final String VERGI_NO_BY_MUSTERI_NO_QUERY = "SELECT vergi_no FROM bnspr.gnl_musteri WHERE musteri_no = %s AND durum_kodu = 'A'";
		public static final String MUSTERI_TUR_KOD_BY_MUSTERI_NO_QUERY = "SELECT musteri_tur_kod FROM bnspr.gnl_musteri WHERE musteri_no = %s AND durum_kodu = 'A'";
	}
	
	public static final class GetOrderBatchDetailHandlerRepository{
		public static final String BATCH_SERVICE_NAME_QUERY = "SELECT BATCH_SERVICE_NAME FROM COS.ORDER_BATCH_DEF WHERE BATCH_NAME = \'%s\'";
	}
	
	public static final class CosStartCorporateBatchHandlerRepository{
		public static final String FILE_NAME_BY_PROCESS_OID_QUERY = "SELECT file_name FROM ftm.ftm_process WHERE oid = %s";
		public static final String FTM_PROCESS_NEXTVAL_QUERY = "SELECT ftm.seq_ftm_process.nextval FROM dual";
	}
	public static final class CommisionDefinitionServicesRepository{
		public static final String GET_CHANNEL_LIST = "SELECT p.kod, p.aciklama FROM bnspr.gnl_kanal_grup_kod_pr p,"+
			" (SELECT DISTINCT (c.channel_code) FROM cdm.channel_source_def c, cdm.corporate_master m"+
			" WHERE m.status = 1 AND c.status = 1 AND c.corporate_oid = m.oid AND m.corporate_code = '%s') cc"+
			" WHERE p.kod = cc.channel_code";
		public static final String GET_COMMISSION_DEFS = "SELECT cd.corporate_code,cd.channel_code,cd.payer payer_code,cd.commission_type commission_type_code,cd.bsmw bsmv_code,cd.customer_exemption,cd.group_exemption,cd.account_exemption,cd.segment_exemption,cd.oid,cd.status,cd.commission,"+
			" (SELECT corporate_name FROM cdm.corporate_master cm WHERE cm.corporate_code=cd.corporate_code AND cm.status='1') corporate_name,"+
			" (SELECT p.aciklama FROM bnspr.gnl_kanal_grup_kod_pr p WHERE p.kod=cd.channel_code) channel_name ,"+
			" (SELECT vpt.text FROM  bnspr.v_ml_gnl_param_text vpt WHERE vpt.kod='CDM_KOMISYON_ODEYEN' AND vpt.key1=cd.payer) payer,"+
			" (SELECT vpt.text FROM  bnspr.v_ml_gnl_param_text vpt WHERE vpt.kod='CDM_MASRAF_TIPI' AND vpt.key1=cd.commission_type) commission_type,"+
			" (SELECT vpt.text FROM  bnspr.v_ml_gnl_param_text vpt WHERE vpt.kod='CDM_BSMV' AND vpt.key1=cd.bsmw) bsmv"+
			" FROM cdm.commission_def%s cd WHERE cd.status=1 ";
		public static final String GET_COMMISSION_DEFS_CORPORATE_CODE=" AND cd.corporate_code='%s'";
		public static final String GET_COMMISSION_DEFS_TX_NO=" AND cd.tx_no='%s' AND cd.ACTIVENESS='A'";
		
		public static final String GET_DEFINED_CHANNEL_LIST="SELECT kod, aciklama FROM bnspr.gnl_kanal_grup_kod_pr"+
				" WHERE kod IN (select distinct (channel_code) FROM cdm.commission_def WHERE status = 1 AND corporate_code = '%s')";
	}
	
	public static final class CorporationReportServicesRepository{
		public static final String CORPORATION_REPORT = "SELECT CM.TX_NO,CORPORATE_CODE,CORPORATE_NAME ,decode(CM.CORPORATE_ACTIVENESS,'A',1,0) CORPORATE_ACTIVENESS,CORPORATE_BANK_CODE ,(select TEXT from BNSPR. v_ml_gnl_param_text where kod='CDM_TARIH_TURU' and KEY1=CM.COUNT_TYPE_AFTER_DUE) COUNT_TYPE_AFTER_DUE ,CUSTOMER_NUMBER ,(select TEXT from BNSPR. v_ml_gnl_param_text where kod='CDM_IS_GUNU' and KEY1=CM.IF_DUE_DATE_HOLIDAY) IF_DUE_DATE_HOLIDAY ,PROTOCOL_START_DATE PROTOCOL_DATE,"
				+ "CM.SECTOR_CODE,(select SECTOR_NAME FROM CDM.SECTOR_DEF SD WHERE SD.SECTOR_CODE=CM.SECTOR_CODE AND SD.STATUS=1) SECTOR_NAME,SHORT_CODE ,CM.ALLOW_PART_AFTER_DUE ,CM.COUNT_AFTER_DUE ,CM.ALLOW_AFTER_DUE_DATE ,"
				+" nvl((SELECT LISTAGG(p.kod||'-'||p.IL_ADI, ',') WITHIN GROUP (ORDER BY p.IL_ADI ) from cdm.corporate_city_rel_tx ccr,BNSPR.Gnl_Il_Kod_Pr p WHERE ccr.corporate_oid =CM.CORPORATE_OID AND CCR.REC_DATE=CM.REC_DATE AND ccr.kod= p.kod ),'T�m �ller') CITIES,"
				+ "CM.ALLOW_PART_PAYMENT ,CM.IS_ONLINE_CORPORATE,CREATE_USER,REC_DATE   from CDM.CORPORATE_MASTER_TX CM where CM.CORPORATE_OID='%s' and CM.STATUS=0 ORDER BY CREATE_DATE DESC";
		
	}
}
