package tr.com.aktifbank.bnspr.cps.session;

public interface ISessionHolder {
	String getSession(Object parameter) throws Exception;
	void renewSession(Object parameter);
}
