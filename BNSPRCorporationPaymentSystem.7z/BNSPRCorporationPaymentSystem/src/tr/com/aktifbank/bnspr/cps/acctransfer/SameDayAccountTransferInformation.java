package tr.com.aktifbank.bnspr.cps.acctransfer;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.dto.TransferInformation;

public class SameDayAccountTransferInformation extends CorporateAccountTransferInformation 
		implements IDateCalcManipulationInformation {

	public SameDayAccountTransferInformation(TransferInformation information) {
		super(information);
		this.processBefore = true;
	}

	@Override
	public Date calculateDate() {
		return super.information.getCollectionDate();
	}

}
