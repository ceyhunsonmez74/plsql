package tr.com.aktifbank.bnspr.cps.multithreading.implementations;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileCorporateInformation;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileStarterInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.PartialParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ServiceBasedMultiThreading;

public final class OutgoingFileByCorporateImplementation extends ServiceBasedMultiThreading {

	private OutgoingFileStarterInformation information;
	
	public OutgoingFileByCorporateImplementation(OutgoingFileStarterInformation information){
		super();
		this.information = information;
	}
	
	@Override
	protected void prepareCall() throws Throwable {
		for(OutgoingFileCorporateInformation corporateInformation : this.information.getInvoiceCollectionInformation()){
			GMMap input = new GMMap();
			input.put(TransactionConstants.StartCorporateBatch.Input.BATCH_NAME, corporateInformation.getBatchName());
			input.put(TransactionConstants.StartCorporateBatch.Input.CORPORATE_CODE, corporateInformation.getCorporateCode());
			input.put(TransactionConstants.StartCorporateBatch.Input.FORMAT_ID, corporateInformation.getFormatId());
			input.put(TransactionConstants.StartCorporateBatch.Input.FTM_ID, corporateInformation.getFtmId());
			input.put(TransactionConstants.StartCorporateBatch.Input.PROCESS_DATE, information.getProcessDate());
			input.put(TransactionConstants.StartCorporateBatch.Input.INFORM_INDICATOR, information.getInformIndicator());
			input.put(TransactionConstants.StartCorporateBatch.Input.FILE_TRANSFER_ID, corporateInformation.getFileTransferId());
			input.put(TransactionConstants.StartCorporateBatch.Input.TRANSFER_TYPE, corporateInformation.getTransferType());
			super.registerService(this.information.getServiceName(), input);
		}
	}
	
	@Override
	protected ParallelCallBehaviour getParallelCallBehaviour() {
		return new PartialParallelCallBehaviour(this.information.getMaxParallelThreadCount(), true);
	}
	
	@Override
	protected void afterCall() throws Throwable {
		if (!this.isHasError()) {
			StringBuilder builder = new StringBuilder();
			for (GMMap output : super.getServiceOutputs()) {
				if (!output.getBoolean(TransactionConstants.StartCorporateBatch.Output.RESULT, false)) {
					this.setHasError(true);
					this.setErrorCode("0");
					builder.append(String.format("An exception occured while informing information for %s corporate code, %s transfer id and %s submit id. ", 
							output.getString(TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE),
							information.getInformIndicator(),
							output.getString(TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID)));
				}
			}
			
			if(this.isHasError()){
				this.setErrorMessage(builder.toString());
			}
		}
	}
}
