package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;


import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.TransferTypes;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;

import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;

import tr.com.aktifbank.bnspr.dao.FileTransferLog;

import com.graymound.util.GMMap;

public final class FtmBatchStarterHandler extends RequestHandler {

	private static final class BagKeys {
		public static final short CORPORATECODE = 1;
		public static final short FILETRANSFERID = 2;
		public static final short BATCHNAME = 3;
		public static final short TRANSFERTYPE = 4;
		public static final short FTMID = 5;
		public static final short FTMTRANSFERID = 6;
		public static final short ERRORCODE = 8;
		public static final short ERRORMESSAGE = 9;
		public static final short TRANSFERSTATUS = 10;
		public static final short SUBMIT_ID = 11;
	}
	
	private static final String NOPARAMETER = "-1";

	public FtmBatchStarterHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String ftmId = getFtmIdFromGMMap(input);
		bag.put(BagKeys.FTMID, ftmId);
		BigDecimal ftmTransferId = getFtmTransferIdFromInputMap(input);
		super.bag.put(BagKeys.FTMTRANSFERID, ftmTransferId);

		CorporateFileTransfer corporateFileTransfer = getCorporateFileTransfers(ftmId);
		if(corporateFileTransfer == null){
			throw new BatchComponentException(BusinessException.CORPORATEFILETRANSFERNOTFOUND, ftmId);
		}
		String fileTransferId = corporateFileTransfer.getFileTransferId();
		super.bag.put(BagKeys.FILETRANSFERID, fileTransferId);
		short transferType = corporateFileTransfer.getTransferType();
		bag.put(BagKeys.TRANSFERTYPE, transferType);

		String corporateCode = corporateFileTransfer.getCorporateCode();
		bag.put(BagKeys.CORPORATECODE, corporateCode);
		if (isCorporateActive(corporateCode)) {
			// No problem
		} else {
			throw new BatchComponentException(BusinessException.CORPORATEISNOTACTIVE, corporateCode);
		}
		String batchName = corporateFileTransfer.getBatchName();
		bag.put(BagKeys.BATCHNAME, batchName);
		GMMap batchDetails = getBatchDetails(corporateCode, batchName);
		String batchOid = getBatchOidFromBatchDetails(batchDetails);
		GMMap batchParameters = getBatchParameters(batchOid);
		String serviceName = getServiceNameFromBatchDetail(batchDetails);
		
		String submitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		bag.put(BagKeys.SUBMIT_ID, submitId);
		
		GMMap submitMap = new GMMap();
		
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME, batchName);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE, corporateCode);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID, submitId);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.COMMIT_COUNT, getCommitCountFromBatchDetail(batchDetails));
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.FORMAT_OID, corporateFileTransfer.getFormatId());
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.FTM_ID, ftmId);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.FTM_TRANSFER_ID, ftmTransferId);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.THREAD_COUNT, getThreadCountFromBatchDetail(batchDetails));
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.THRESHOLD, batchDetails.getInt(TransactionConstants.GetBatchDetail.Output.THRESHOLD));
		String composedBatchParameters = getComposedBatchParameters(batchParameters);
		if (!composedBatchParameters.equals(NOPARAMETER)) {
			submitMap.put(
					TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS,
					composedBatchParameters);
		}
		insertFileTransferLog();
		callBatchSubmitService(serviceName, submitMap);
		bag.put(BagKeys.TRANSFERSTATUS, DatabaseConstants.TransferStatuses.SUBMITTED);
		
		output.put(TransactionConstants.FtmBatchStarter.Output.SUBMIT_ID,
				submitId);
	}

	private void insertFileTransferLog() {
		try {
			FileTransferLog fileTransferLog = new FileTransferLog();
			fileTransferLog.setStatus(true);
			if(bag.containsKey(BagKeys.CORPORATECODE)){
				fileTransferLog.setCorporateCode((String)bag.get(BagKeys.CORPORATECODE));
			}
			if(bag.containsKey(BagKeys.FILETRANSFERID)){
				fileTransferLog.setFileTransferId((String)bag.get(BagKeys.FILETRANSFERID));
			}
			if(bag.containsKey(BagKeys.BATCHNAME)){
				fileTransferLog.setBatchName((String)bag.get(BagKeys.BATCHNAME));
			}
			if(bag.containsKey(BagKeys.TRANSFERTYPE)){
				fileTransferLog.setTransferType((Short)bag.get(BagKeys.TRANSFERTYPE));
			}
			if(bag.containsKey(BagKeys.TRANSFERSTATUS)){
				fileTransferLog.setTransferStatus((Byte)bag.get(BagKeys.TRANSFERSTATUS));
			}
			if(bag.containsKey(BagKeys.FTMID)){
				fileTransferLog.setFtmId((String)bag.get(BagKeys.FTMID));
			}
			if(bag.containsKey(BagKeys.FTMTRANSFERID)){
				fileTransferLog.setFtmSequenceNumber((BigDecimal)bag.get(BagKeys.FTMTRANSFERID));
			}
			if(bag.containsKey(BagKeys.ERRORCODE)){
				fileTransferLog.setErrorCode((String)bag.get(BagKeys.ERRORCODE));
			}
			if(bag.containsKey(BagKeys.ERRORMESSAGE)){
				fileTransferLog.setErrorDesc((String)bag.get(BagKeys.ERRORMESSAGE));
			}
			fileTransferLog.setLogDate(CommonHelper.getLongDateTimeString(new Date()));
			fileTransferLog.setBatchSubmitId((String) bag.get(BagKeys.SUBMIT_ID));

			super.getHibernateSession().save(fileTransferLog);
			super.getHibernateSession().flush();
		} catch (HibernateException e) {
			logger.error(e);
		}
	}
	
	@Override
	protected void handleError(Throwable e, GMMap output){
		logger.error(System.currentTimeMillis(), e);
		bag.put(BagKeys.TRANSFERSTATUS, DatabaseConstants.TransferStatuses.SUBMITFAILURE);
		bag.put(BagKeys.ERRORMESSAGE, CommonHelper.getStringifiedException(e));
		if (e instanceof BatchComponentException) {
			bag.put(BagKeys.ERRORCODE, BigDecimal.valueOf(((BatchComponentException)e).getCode()));
		}
		insertFileTransferLog();
	}

	private String getComposedBatchParameters(GMMap batchParameters) {
		return batchParameters
				.getString(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS, NOPARAMETER);
	}

	private void callBatchSubmitService(String serviceName, GMMap submitMap) throws Exception {
		super.callGraymoundServiceAsync(serviceName, submitMap);
	}

	private int getCommitCountFromBatchDetail(GMMap batchDetails) {
		return batchDetails
				.getInt(TransactionConstants.GetBatchDetail.Output.COMMIT_COUNT);
	}

	private int getThreadCountFromBatchDetail(GMMap batchDetails) {
		return batchDetails
				.getInt(TransactionConstants.GetBatchDetail.Output.THREAD_COUNT);
	}

	private BigDecimal getFtmTransferIdFromInputMap(GMMap fTMMap) {
		return fTMMap
				.getBigDecimal(TransactionConstants.FtmBatchStarter.Input.FTM_TRANSFER_ID);
	}

	private String getServiceNameFromBatchDetail(GMMap batchDetails) {
		return batchDetails
				.getString(TransactionConstants.GetBatchDetail.Output.SERVICE_NAME);
	}

	private GMMap getBatchParameters(String batchOid) {
		GMMap getBatchParametersRequest = new GMMap();
		getBatchParametersRequest
				.put(TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID,
						batchOid);
		return super.callGraymoundServiceInSession(
				TransactionConstants.GetBatchParameters.SERVICE_NAME,
				getBatchParametersRequest);
	}

	private String getBatchOidFromBatchDetails(GMMap batchDetails) {
		return batchDetails
				.getString(TransactionConstants.GetBatchDetail.Output.CORPORATE_BATCH_PROCESS_OID);
	}

	private GMMap getBatchDetails(String corporateCode, String batchName) {
		GMMap getBatchDetailRequest = new GMMap();
		getBatchDetailRequest
				.put(TransactionConstants.GetBatchDetail.Input.BATCH_NAME,
						batchName);
		getBatchDetailRequest.put(
				TransactionConstants.GetBatchDetail.Input.CORPORATE_CODE,
				corporateCode);
		return super.callGraymoundServiceInSession(
				TransactionConstants.GetBatchDetail.SERVICE_NAME,
				getBatchDetailRequest);
	}

	private Boolean isCorporateActive(String corporateCode) {
		return CommonBusinessOperations.isCorporateActive(corporateCode);
	}

	private CorporateFileTransfer getCorporateFileTransfers(String ftmId)
			throws SQLException {
		Criteria criteria = super.getHibernateSession().createCriteria(CorporateFileTransfer.class);
		criteria.add(Restrictions.eq("ftmId", new BigDecimal(ftmId)));
		criteria.add(Restrictions.eq("transferType", (short)TransferTypes.InvoiceLoading));
		criteria.add(Restrictions.eq("status", true));
		criteria.add(Restrictions.or(Restrictions.eq("complexFileTransfer", false), Restrictions.isNull("complexFileTransfer")));
		return (CorporateFileTransfer)criteria.uniqueResult();
	}

	private String getFtmIdFromGMMap(GMMap inputMap) throws Exception {
		String ftmId = "";
		if (inputMap
				.containsKey(TransactionConstants.FtmBatchStarter.Input.FTM_ID)) {
			Object notCastedFtmId = inputMap
					.get(TransactionConstants.FtmBatchStarter.Input.FTM_ID);
			if (notCastedFtmId.getClass() == String.class) {
				ftmId = (String) notCastedFtmId;
			} else {
				throw new Exception(
						String.format(
								"Type of input parameter FTM_ID is %s instead of String",
								notCastedFtmId.getClass().getName()));
			}
		} else {
			throw new Exception("FTM_ID has not been specified in request map.");
		}
		return ftmId;
	}
}
