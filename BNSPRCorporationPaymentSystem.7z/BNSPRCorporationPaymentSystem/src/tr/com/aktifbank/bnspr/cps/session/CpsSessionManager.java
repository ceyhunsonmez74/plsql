package tr.com.aktifbank.bnspr.cps.session;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class CpsSessionManager {

	private static final CpsSessionManager instance;
	
	static {
		instance = new CpsSessionManager();
	}
	
	public static final CpsSessionManager getInstance(){
		return instance;
	}
	
	private Map<String, ISessionHolder> sessionHolderMap;
	
	private CpsSessionManager() {
		this.sessionHolderMap = new ConcurrentHashMap<String, ISessionHolder>();
		this.sessionHolderMap.put(SessionHolderKeys.TURKCELL_SESSION_HOLDER, new TurkcellSessionHolder());
	}
	
	public String getSession(String key, Object parameter) throws Exception {
		ISessionHolder holder = this.sessionHolderMap.get(key);
		if(holder != null){
			return holder.getSession(parameter);
		}
		else{
			throw new Exception(String.format("Session holder not found with %s key", key));
		}
	}
	
	public void renewSession(String key, Object parameter) throws Exception{
		ISessionHolder holder = this.sessionHolderMap.get(key);
		if(holder != null){
			holder.renewSession(parameter);
		}
		else{
			throw new Exception(String.format("Session holder not found with %s key", key));
		}
	}

}
