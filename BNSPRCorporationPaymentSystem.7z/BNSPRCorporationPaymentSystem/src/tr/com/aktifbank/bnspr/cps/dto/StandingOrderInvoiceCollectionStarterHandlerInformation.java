package tr.com.aktifbank.bnspr.cps.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.graymound.util.GMMap;

public class StandingOrderInvoiceCollectionStarterHandlerInformation extends
		BaseTransferObject {

	public StandingOrderInvoiceCollectionStarterHandlerInformation() {
	}

	private GMMap corporateMap = new GMMap();
	private int maxParallelThreadCount;
	private Date processDate;
	private String serviceName;
	private BigDecimal masterSubmitId;

	public BigDecimal getMasterSubmitId() {
		return masterSubmitId;
	}

	public void setMasterSubmitId(BigDecimal masterSubmitId) {
		this.masterSubmitId = masterSubmitId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Date getProcessDate() {
		return processDate;
	}

	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}

	public int getMaxParallelThreadCount() {
		return maxParallelThreadCount;
	}

	public void setMaxParallelThreadCount(int maxParallelThreadCount) {
		this.maxParallelThreadCount = maxParallelThreadCount;
	}

	public GMMap getCorporateMap() {
		return corporateMap;
	}

	public void setCorporateMap(GMMap corporateMap) {
		this.corporateMap = corporateMap;
	}

}
