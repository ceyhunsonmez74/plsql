package tr.com.aktifbank.bnspr.cps.transactions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;

import com.graymound.util.GMMap;

public final class ControlSectorActivenessHandler extends RequestHandler {

	public ControlSectorActivenessHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String sectorCode = input.getString(TransactionConstants.ControlSectorActiveness.Input.SECTOR_CODE, null);
		String sectorOid = input.getString(TransactionConstants.ControlSectorActiveness.Input.SECTOR_OID, null);
		
		GMMap result = super.callServiceWithParams(TransactionConstants.GetSectorDefinition.SERVICE_NAME,
				TransactionConstants.GetSectorDefinition.Input.SECTOR_CODE, sectorCode,
				TransactionConstants.GetSectorDefinition.Input.SECTOR_OID, sectorOid);
		
		if(result.getBoolean(TransactionConstants.GetSectorDefinition.Output.IS_SECTOR_ACTIVE)){
			output.put(TransactionConstants.ControlSectorActiveness.Output.RESULT, true);
		}
		else{
			throw new BatchComponentException(BusinessException.SECTORISNOTACTIVE, result.getString(TransactionConstants.GetSectorDefinition.Output.SECTOR_NAME));
		}
	}

}
