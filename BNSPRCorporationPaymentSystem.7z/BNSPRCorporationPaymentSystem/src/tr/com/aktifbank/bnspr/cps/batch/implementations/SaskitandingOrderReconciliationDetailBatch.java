package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.HashMap;
import java.util.Map;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.adasu.AdasuClient;
import tr.gov.adasu.service.talimat.xsd.TalimatDetayMutabakat;
import tr.gov.adasu.service.xsd.Abone;

import com.graymound.util.GMMap;

public class SaskitandingOrderReconciliationDetailBatch extends StandingOrderReconciliationDetailBatch {

	private AdasuClient client;
	
	private Abone[] details;
	
	private Map<String,Abone> indexedCorporateRecords;
	
	
	public SaskitandingOrderReconciliationDetailBatch(GMMap input, AdasuClient client) {
		super(input);
		this.client = client;
		indexedCorporateRecords = new HashMap<String, Abone>();
	}

	@Override
	protected void setCancelStandingOrderExtraParameters(GMMap cancelStandingOrderRequest, int corporateRecordIndex) {
		
	}

	@Override
	protected void setCorporateParametersToReconProcessLogInput(GMMap reconProcessDataLogInput, int corporateRecordIndex) {
		
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(icsStandingOrders bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getSubscriberNo1());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()throws Exception {
	
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		 
		String reconcilationDate = CommonHelper.getDateString(input.getDate(MapKeys.RECON_DATE),"yyyyMMdd");
		
		TalimatDetayMutabakat stoReconSummaryResponse = client.otomatikOdemeDetayMutabakat(changeDate2CorpDate(reconcilationDate));
		if( null != stoReconSummaryResponse ){
			details = stoReconSummaryResponse.getAbone();
		}
		
		result.setSuccessfulCall(true);
		
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordsSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(String.valueOf(super.getBankRecordAtIndex(i).getSubscriberNo1()), super.getBankRecordAtIndex(i));
		}
		
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for( Abone detail : details ){
			indexedCorporateRecords.put(detail.getAboneNo().toString(), detail);
		}
		
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(details[corporateRecordIndex].getAboneNo().toString());
	}
	
	private static String changeDate2CorpDate(String parsedDate) throws Exception{
		return CommonHelper.formatDateString(parsedDate, "yyyyMMdd", "dd.MM.yyyy");
	}


}
