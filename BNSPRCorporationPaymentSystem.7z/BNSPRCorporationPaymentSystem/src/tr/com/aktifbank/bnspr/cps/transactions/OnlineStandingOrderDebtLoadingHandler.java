package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.BatchParameters;
import tr.com.aktifbank.bnspr.dao.icsOnlineDebtLoadingLog;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoiceMain;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OnlineStandingOrderDebtLoadingHandler extends ParallelRequestHandler{
	private static String ERROR_CODE_CONTROL_DATE = "0";
	private static String ERROR_DESC_CONTROL_DATE = "Tarih Uygun De�il";
	private static String ERROR_CODE_STANDING_ORDER_NOT_ACTIVE = "1";
	private static String ERROR_DESC_STANDING_ORDER_NOT_ACTIVE = "Aktif Talimat� bulunamad�";
	private static String ERROR_CODE_INVOICE_EXISTS = "2";
	private static String ERROR_DESC_INVOICE_EXISTS = "Fatura veritaban�nda bulunuyor.";
	private static String DEFAULT_BRANCH_CODE = "444";

    private static final class ParameterKeys{
       public static final String DELETEPENDINGS = "BEKLEYENLERI_SIL";
       public static final String DATE_CONTROL = "TARIH_KONTROL";
    }
    
    private static final class BagKeys{
    	public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
    	public static final String MASTER_SUBMIT_ID = "MASTER_SUBMIT_ID";
    }
    
    public OnlineStandingOrderDebtLoadingHandler() {
                   super();
    }

    @SuppressWarnings("unchecked")
    @Override
    protected void handleInternal(GMMap input, GMMap output) throws Throwable {
    	Session hibernateSession = super.getHibernateSession();
    	Criteria criteriaParameter = hibernateSession.createCriteria(BatchParameters.class)
				.add(Restrictions.eq("batchName", input.getString(MapKeys.BATCH_NAME)))
				.add(Restrictions.eq("status", true));
    	
    	BigDecimal masterSubmitId = input.getBigDecimal("MASTER_SUBMIT_ID");
    	
    	bag.put(BagKeys.MASTER_SUBMIT_ID, masterSubmitId);
				
		
		List<BatchParameters> batchParameterList = criteriaParameter.list();
		for (BatchParameters batchParameters : batchParameterList) {
			input.put(batchParameters.getParamKey(),batchParameters.getParamKeyValue());			
		}
		
    	
		if(input.containsKey(ParameterKeys.DELETEPENDINGS) && input.getString(ParameterKeys.DELETEPENDINGS).equals("1")){
			GMMap deleteWaitedInvoice = new GMMap();
			deleteWaitedInvoice.put(TransactionConstants.DeleteWaitedInvoice.Input.CORPORATE_CODE, input.getString(MapKeys.CORPORATE_CODE));
			super.callGraymoundServiceInSession(TransactionConstants.DeleteWaitedInvoice.SERVICE_NAME, deleteWaitedInvoice);
		}
		boolean dateControl= false;
		if(input.containsKey(ParameterKeys.DATE_CONTROL) && input.getBoolean(ParameterKeys.DATE_CONTROL)){
			dateControl = true;
		}
		   
        String batchSubmitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		bag.put(BagKeys.BATCH_SUBMIT_ID, batchSubmitId);
		String corporateCode =  input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE);
		String batchName = input.getString(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME);
		String batchServiceName = "ICS_ONLINE_STANDING_ORDER_DEBT_LOADING";
		String ftmId = "";
		String formatId = "";
		
		CommonBusinessOperations.insertBatchSubmitLog(corporateCode, batchName, ftmId, formatId, batchSubmitId, batchServiceName, input);
			
		input.put(MapKeys.BANK_CODE, input.getString(MapKeys.BANK_CODE));
		input.put(MapKeys.CORPORATE_CODE, input.getString(MapKeys.CORPORATE_CODE));
		input.put(MapKeys.GM_SERVICE_NAME, "ICS_ONLINE_STANDING_ORDER_DEBT_LOADING");
		input.put(MapKeys.IS_MANDATORY_SERVICE, true);
		input.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
		output= GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", input);
		int tableSize = output.getInt(MapKeys.TABLE_SIZE);
		
		for (int i = 0; i < tableSize; i++) {
			String dueDate = output.getString(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE); 
			String processDate = input.getString(MapKeys.PROCESS_DATE);
			String subscriberNo1 = output.getString(MapKeys.INVOICE_LIST,i,MapKeys.SUBSCRIBER_NO1);
			String subscriberNo2 = output.getString(MapKeys.INVOICE_LIST,i,MapKeys.SUBSCRIBER_NO2);
			String subscriberNo3 = output.getString(MapKeys.INVOICE_LIST,i,MapKeys.SUBSCRIBER_NO3);
			String subscriberNo4 = output.getString(MapKeys.INVOICE_LIST,i,MapKeys.SUBSCRIBER_NO4);
			GMMap standingOrderMap = getStandingOrderActive(subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4, corporateCode); 
			short collectionType = (short)output.getInt(MapKeys.INVOICE_LIST, i, MapKeys.COLLECTION_TYPE);
			BigDecimal amount = output.getBigDecimal(MapKeys.INVOICE_LIST, i, MapKeys.AMOUNT);
			String invoiceNo = output.getString(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_NO);
			String invoiceDueDate = output.getString(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DUE_DATE);
			if (controlDateParamter(dateControl, dueDate, processDate)) {
				
				if(standingOrderMap.getBoolean(MapKeys.IS_STANDING_ORDER_ACTIVE)){	
					
					invoiceMain invoiceMainDebtLoading = new invoiceMain();
					invoiceMainDebtLoading.setAmount(amount);
					invoiceMainDebtLoading.setBranchCode(DEFAULT_BRANCH_CODE); //default olarak 444 atan�yor �ube kodu olarak
					invoiceMainDebtLoading.setCollectionType(collectionType);// kurum taraf�ndan yoksa boom 
					invoiceMainDebtLoading.setCorporateCode(corporateCode);
					invoiceMainDebtLoading.setCurrencyCode(MapKeys.CURRENCY_CODE_DEFAULT);
					invoiceMainDebtLoading.setCustomerNo(standingOrderMap.getBigDecimal(MapKeys.CUSTOMER_NO));//isStandingOrderActive bu servisten
					invoiceMainDebtLoading.setInstallmentNo(output.getInt(MapKeys.INVOICE_LIST, i, MapKeys.INSTALLMENT_NO));// contains 
					invoiceMainDebtLoading.setInvoiceDate(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.INVOICE_DATE));// contains 
					invoiceMainDebtLoading.setInvoiceDueDate(invoiceDueDate);// contains 
					invoiceMainDebtLoading.setInvoiceNo(invoiceNo);//kurum taraf�ndan yoksa boom 
					invoiceMainDebtLoading.setInvoiceStatus(GeneralConstants.INVOICE_STATUS_DEFAULT);
					invoiceMainDebtLoading.setLoadingDate(CommonHelper.getShortDateTimeString(new Date()));// new date
					invoiceMainDebtLoading.setLoadingUser(CommonHelper.getCurrentUser());// CommonHelper e bak
					invoiceMainDebtLoading.setParameter1(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER1));//contains
					invoiceMainDebtLoading.setParameter2(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER2));//contains
					invoiceMainDebtLoading.setParameter3(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER3));//contains
					invoiceMainDebtLoading.setParameter4(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER4));//contains
					invoiceMainDebtLoading.setParameter5(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER5));//contains
					invoiceMainDebtLoading.setParameter6(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER6));//contains
					invoiceMainDebtLoading.setParameter7(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER7));//contains
					invoiceMainDebtLoading.setParameter8(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER8));//contains
					invoiceMainDebtLoading.setParameter9(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER9));//contains
					invoiceMainDebtLoading.setParameter10(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER10));//contains
					invoiceMainDebtLoading.setParameter11(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER11));//contains
					invoiceMainDebtLoading.setParameter12(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER12));//contains
					invoiceMainDebtLoading.setParameter13(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER13));//contains
					invoiceMainDebtLoading.setParameter14(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER14));//contains
					invoiceMainDebtLoading.setParameter15(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER15));//contains
					invoiceMainDebtLoading.setParameter16(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER16));//contains
					invoiceMainDebtLoading.setParameter17(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER17));//contains
					invoiceMainDebtLoading.setParameter18(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER18));//contains
					invoiceMainDebtLoading.setParameter19(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER19));//contains
					invoiceMainDebtLoading.setParameter20(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.PARAMETER20));//contains
					invoiceMainDebtLoading.setPaymentMethod(GeneralConstants.PAYMENT_METHOD_DEFAULT);//""
					invoiceMainDebtLoading.setPaymentStatus(GeneralConstants.PAYMENT_STATUS_DEFAULT);// A
					invoiceMainDebtLoading.setStandingOrderOid(standingOrderMap.getString(MapKeys.STANDING_ORDER_OID));//isStandingOrderActive bu servisten 
					invoiceMainDebtLoading.setStatus(true);//true
					invoiceMainDebtLoading.setSubCollectionType(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.SUB_COLLECTION_TYPE));//contains
					invoiceMainDebtLoading.setSubscriberEmail(GeneralConstants.DEFAULT_STRING);//""
					invoiceMainDebtLoading.setSubscriberMobile(GeneralConstants.DEFAULT_STRING);//""
					invoiceMainDebtLoading.setSubscriberName(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NAME));//contains
					invoiceMainDebtLoading.setSubscriberNo1(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO1));
					invoiceMainDebtLoading.setSubscriberNo2(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO2));//contains
					invoiceMainDebtLoading.setSubscriberNo3(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO3));//contains
					invoiceMainDebtLoading.setSubscriberNo4(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.SUBSCRIBER_NO4));//contains
					invoiceMainDebtLoading.setSubscriberPhone(GeneralConstants.DEFAULT_STRING);//"
					invoiceMainDebtLoading.setSubscriberPidno(GeneralConstants.DEFAULT_STRING);//"
					invoiceMainDebtLoading.setTermMonth(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.TERM_MONTH));//contains
					invoiceMainDebtLoading.setTermYear(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.TERM_YEAR));//contains
					invoiceMainDebtLoading.setTxNo(new BigDecimal((String)GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get(MapKeys.TRX_NO)));//0
					invoiceMainDebtLoading.setZoneCode(output.getString(MapKeys.INVOICE_LIST, i, MapKeys.ZONE_CODE));//contains
					invoiceMainDebtLoading.setCancelDate(GeneralConstants.DEFAULT_STRING);//""
					invoiceMainDebtLoading.setCancelUser(GeneralConstants.DEFAULT_STRING);//""
					invoiceMainDebtLoading.setFtmSequenceNumber(GeneralConstants.FTM_SEQUENCE_NUMBER_DEFAULT);//0
					invoiceMainDebtLoading.setPaymentAmount(GeneralConstants.PAYMENT_AMOUNT_DEFAULT);
					
					if(invoiceExists(invoiceMainDebtLoading)){
						insertOnlineDebtLoadingLog(batchSubmitId, 
								collectionType, 
								corporateCode, 
								ERROR_CODE_INVOICE_EXISTS, 
								ERROR_DESC_INVOICE_EXISTS, 
								amount, 
								invoiceNo, 
								invoiceDueDate, 
								processDate, 
								subscriberNo1,
								subscriberNo2,
								subscriberNo3,
								subscriberNo4);
						continue;
					}
					else{
						hibernateSession.save(invoiceMainDebtLoading);
						hibernateSession.flush();
						GMMap logMap = new GMMap();
						logMap.put(MapKeys.PROCESS_STATUS, DatabaseConstants.StandingOrderProcessLogStatuses.Successful);
						logMap.put(MapKeys.INVOICE_MAIN_OID, invoiceMainDebtLoading.getOid());
						logMap.put(MapKeys.PROCESS_DATE, processDate);
						logMap.put(MapKeys.STANDING_ORDER_OID, standingOrderMap.getString(MapKeys.STANDING_ORDER_OID));
						CommonHelper.callGraymoundServiceOutsideSession("ICS_CREATE_STANDING_ORDER_PROCESS_LOG", logMap);
					}

				}else{//standingOrderActive
					insertOnlineDebtLoadingLog(batchSubmitId, 
							collectionType, 
							corporateCode, 
							ERROR_CODE_STANDING_ORDER_NOT_ACTIVE, 
							ERROR_DESC_STANDING_ORDER_NOT_ACTIVE, 
							amount, 
							invoiceNo, 
							invoiceDueDate, 
							processDate, 
							subscriberNo1,
							subscriberNo2,
							subscriberNo3,
							subscriberNo4);
				}
			}else{//control date 
				insertOnlineDebtLoadingLog(batchSubmitId, 
						collectionType, 
						corporateCode, 
						ERROR_CODE_CONTROL_DATE, 
						ERROR_DESC_CONTROL_DATE, 
						amount, 
						invoiceNo, 
						invoiceDueDate, 
						processDate, 
						subscriberNo1,
						subscriberNo2,
						subscriberNo3,
						subscriberNo4);
			}
		}
		
		CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId, DatabaseConstants.SubmitStatuses.SUCESSFUL, new Date(), null, null);
				
	}
				

    private boolean invoiceExists(invoiceMain invoiceMainDebtLoading) {
		Criteria criteria = super.getHibernateSession().createCriteria(invoiceMain.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", invoiceMainDebtLoading.getCorporateCode()));
//				.add(Restrictions.eq("amount", invoiceMainDebtLoading.getAmount()))
//				.add(Restrictions.or(
//						Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected), 
//						Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Waiting)));
		if(!StringUtil.isEmpty(invoiceMainDebtLoading.getInvoiceNo())){
			criteria = criteria.add(Restrictions.eq("invoiceNo", invoiceMainDebtLoading.getInvoiceNo()));
		}
		
		if(!StringUtil.isEmpty(invoiceMainDebtLoading.getInvoiceDueDate())){
			criteria = criteria.add(Restrictions.eq("invoiceDueDate", invoiceMainDebtLoading.getInvoiceDueDate()));
		}
		
		if(!StringUtil.isEmpty(invoiceMainDebtLoading.getSubscriberNo1())){
			criteria = criteria.add(Restrictions.eq("subscriberNo1", invoiceMainDebtLoading.getSubscriberNo1()));
		}
		
		if(!StringUtil.isEmpty(invoiceMainDebtLoading.getSubscriberNo2())){
			criteria = criteria.add(Restrictions.eq("subscriberNo2", invoiceMainDebtLoading.getSubscriberNo2()));
		}
		
		if(!StringUtil.isEmpty(invoiceMainDebtLoading.getSubscriberNo3())){
			criteria = criteria.add(Restrictions.eq("subscriberNo3", invoiceMainDebtLoading.getSubscriberNo3()));
		}
		
		if(!StringUtil.isEmpty(invoiceMainDebtLoading.getSubscriberNo4())){
			criteria = criteria.add(Restrictions.eq("subscriberNo4", invoiceMainDebtLoading.getSubscriberNo4()));
		}
		
		return ((Number)criteria.setProjection(Projections.rowCount()).uniqueResult()).intValue() > 0;
	}

	@Override
	protected void handleError(Throwable e, GMMap output) {
		Long errorId = System.currentTimeMillis();
		logger.error("System exception is occured, updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(), "0",
				CommonHelper.getStringifiedException(e));
	}

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		Long errorId = System.currentTimeMillis();

		logger.error("Business exception is occured. Updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(),
				String.valueOf(e.getCode()), e.toString());
	}
    
    @SuppressWarnings("unchecked")
	private GMMap getStandingOrderActive(String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4, String corporateCode){ 
    	GMMap outMap = new GMMap();

    	Criteria criteria = super.getHibernateSession().createCriteria(icsStandingOrders.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.add(Restrictions.eq("standingOrderStatus", DatabaseConstants.StandingOrderStatus.Active));
    	
    	if(!StringUtil.isEmpty(subscriberNo1)){
    		criteria = criteria.add(Restrictions.eq("subscriberNo1", subscriberNo1));
    	}
    	
    	if(!StringUtil.isEmpty(subscriberNo2)){
    		criteria = criteria.add(Restrictions.eq("subscriberNo2", subscriberNo2));
    	}
    	
    	if(!StringUtil.isEmpty(subscriberNo3)){
    		criteria = criteria.add(Restrictions.eq("subscriberNo3", subscriberNo3));
    	}
    	
    	if(!StringUtil.isEmpty(subscriberNo4)){
    		criteria = criteria.add(Restrictions.eq("subscriberNo4", subscriberNo4));
    	}
    	
		List<icsStandingOrders> icsStandingOrdersList = criteria
				.list();
		
		if (icsStandingOrdersList.size() > 0) {
			outMap.put(MapKeys.CUSTOMER_NO, icsStandingOrdersList.get(0).getCustomerNo());
			outMap.put(MapKeys.STANDING_ORDER_OID, icsStandingOrdersList.get(0).getStandingOrderOid());
			outMap.put(MapKeys.STANDING_ORDER_STATUS, icsStandingOrdersList.get(0).getStandingOrderStatus());
			outMap.put(MapKeys.COLLECTION_TYPE, icsStandingOrdersList.get(0).getCollectionType());
			outMap.put(MapKeys.IS_STANDING_ORDER_ACTIVE, true);
		}else{
			outMap.put(MapKeys.IS_STANDING_ORDER_ACTIVE, false);
		}
		return outMap;
    }
    
    public void insertOnlineDebtLoadingLog(String submitId,short collectionType,String corporateCode,String errorCode,String errorDesc,BigDecimal invoiceAmount,String invoiceNo,
    		String invoiceDueDate,String processDate,String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4){
    	Session hibernateSession = CommonHelper.getHibernateSession();
    	icsOnlineDebtLoadingLog debtLoadingLog = new icsOnlineDebtLoadingLog();
		debtLoadingLog.setBatchSubmitId(submitId);
		debtLoadingLog.setCollectionType(collectionType);
		debtLoadingLog.setCorporateCode(corporateCode);
		debtLoadingLog.setErrorCode(errorCode);
		debtLoadingLog.setErrorDesc(errorDesc);
		debtLoadingLog.setInvoiceAmount(invoiceAmount);
		debtLoadingLog.setInvoiceDueDate(invoiceDueDate);
		debtLoadingLog.setInvoiceNo(invoiceNo);
		debtLoadingLog.setProcessDate(processDate);
		debtLoadingLog.setStatus(true);
		debtLoadingLog.setSubscriberNo1(subscriberNo1);
		debtLoadingLog.setSubscriberNo2(subscriberNo2);
		debtLoadingLog.setSubscriberNo3(subscriberNo3);
		debtLoadingLog.setSubscriberNo4(subscriberNo4);
		debtLoadingLog.setMasterSubmitId((BigDecimal)bag.get(BagKeys.MASTER_SUBMIT_ID));
		hibernateSession.save(debtLoadingLog);
		hibernateSession.flush();
    }
    
    private boolean controlDateParamter(boolean dateControl, String dueDateString, String processDateString) throws ParseException{
    	boolean result=false;
    	if(dateControl){
    		if(CommonHelper.getDateTime(dueDateString, "yyyyMMdd").after(CommonHelper.getDateTime(processDateString, "yyyyMMdd"))){
    		 result = true;
    		}    			
    	}else{
    		result = true;
    	}
		return result;
    }
}



