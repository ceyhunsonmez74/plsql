package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.DailyPaymentTransactionReportHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant.Email.DailyReportMessageConstant;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class DailyPaymentTransactionReportHandler extends RequestHandler {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String currentDate = CommonHelper.getDateString(new Date(), "yyyyMMdd");
		Session hibernateSession = CommonHelper.getHibernateSession();
		
		int paymentCount = 0;
		BigDecimal paymentAmount = new BigDecimal(0);
		
		List list = hibernateSession.createSQLQuery(DailyPaymentTransactionReportHandlerRepository.FETCH_DAILY_PAYMENT_REPORT_QUERY).setParameter("currentDate",currentDate + "%").list();
		List<Map<String,String>> mapList = new ArrayList<Map<String,String>>();
		
		List<String> corporateCodes = new ArrayList<String>();
		if( null != list ){
			Iterator resultIterator = list.iterator();
			while( resultIterator.hasNext() ){
				Object[] row = (Object[])resultIterator.next();
				Map<String,String> columnMap = new HashMap<String,String>();
				if( null != row[0] ){
					columnMap.put("PAYMENT_COUNT", CommonHelper.applyDecimalFormat(row[0].toString()));
					paymentCount += Integer.valueOf(row[0].toString());
				}
				if(null != row[1] ){
					columnMap.put("TOTAL_PAYMENT_AMOUNT", CommonHelper.applyDecimalFormat(row[1].toString()));
					paymentAmount = paymentAmount.add(new BigDecimal(row[1].toString()));
				}
				if( null != row[2] ){
					columnMap.put("KURUM_KODU", row[2].toString());
					corporateCodes.add(row[2].toString());
					GMMap corporateDefMap = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, new GMMap().put("CORPORATE_CODE",row[2].toString()));
					if( null != corporateDefMap ){
						columnMap.put("KURUM_ADI", corporateDefMap.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE));
					}
				}
				
				mapList.add(columnMap);
			}
		}
		
//		List<CorporateMaster> notAddedCorporates = hibernateSession.createCriteria(CorporateMaster.class)
//				.add(Restrictions.eq("status", true))
//				.add(Restrictions.eq("corporateActiveness", "A"))
//				.add(Restrictions.not(Restrictions.in("corporateCode", corporateCodes)))
//				.list();
//		
//		for (CorporateMaster master : notAddedCorporates) {
//			Map<String,String> columnMap = new HashMap<String,String>();
//			columnMap.put("PAYMENT_COUNT", "0");
//			columnMap.put("TOTAL_PAYMENT_AMOUNT", "0");
//			columnMap.put("KURUM_KODU", master.getCorporateCode());
//			columnMap.put("KURUM_ADI", master.getShortCode());
//			mapList.add(columnMap);
//		}
//		

		GMMap messageMap = new GMMap();
		messageMap.put("ENVIRONMENT", GMServiceExecuter.call("BNSPR_CORE_GET_SISTEM_ADI", input).getString("SISTEM_ADI"));
		messageMap.put("CURRENT_DATE",CommonHelper.formatDateString(currentDate, "yyyyMMdd", "dd/MM/yyyy"));
		messageMap.put("TOTAL_PAYMENT_COUNT", CommonHelper.applyDecimalFormat(String.valueOf(paymentCount)));
		messageMap.put("SUMMARY_PAYMENT_AMOUNT", CommonHelper.applyDecimalFormat(paymentAmount.toPlainString()));
		messageMap.put("MAP_TABLE", mapList);
		
		String receiptList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST","EMAIL_RECEIPT_LIST_4_DAILY_COLLECTION");
		
		EmailMessage emailMessage = CommonHelper.prepareEmailBody("", messageMap,DailyReportMessageConstant.MESSAGE_BODY,
				DailyReportMessageConstant.SUBJECT, receiptList);
		
		CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
	
		
	}

}
