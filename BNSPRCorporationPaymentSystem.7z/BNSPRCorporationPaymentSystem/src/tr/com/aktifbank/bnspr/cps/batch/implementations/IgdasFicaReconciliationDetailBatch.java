package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.igdas.IgdasFicaClient;
import tr.com.aktifbank.integration.igdas.ServiceMessage;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.sap.document.sap.rfc.functions.ZPIFICADOSYATALEPResponse;
import com.sap.xi.fica.global.testing.P3CashPointOpenItemFault;

public final class IgdasFicaReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(IgdasFicaReconciliationDetailBatch.class);
	Session session;
	List<ReconDetailData> details;
	ServiceMessage message;
	Map<String, ReconDetailData> indexedCorporateRecords;
	
	public IgdasFicaReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, ReconDetailData>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getParameter4());
	}

	@SuppressWarnings("unchecked")
	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		Session session = CommonHelper.getHibernateSession();
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String bankaKodu = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			
			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			
			String collectionTypeId = "0";
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			String reconLogOid = input.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
			String reconDate = input.getString(MapKeys.RECON_DATE);
			Calendar now = Calendar.getInstance();
			String time = Integer.toString(now.get(Calendar.HOUR)).concat(Integer.toString(now.get(Calendar.MINUTE))).concat(Integer.toString(now.get(Calendar.SECOND)));
			
			Session hibernateSession = CommonHelper.getHibernateSession();
			List<ReconDetailData> reconDetailData = (List<ReconDetailData>) hibernateSession.createCriteria(ReconDetailData.class).add(Restrictions.eq("status", true))
							.add(Restrictions.eq("reconLogOid", reconLogOid)).add(Restrictions.eq("corporateCode", corporateCode)).setMaxResults(1).list();
			
			if(reconDetailData != null && reconDetailData.size() > 0){
				String dosyaId = reconDetailData.get(0).getParameter1();
				ZPIFICADOSYATALEPResponse response2 = IgdasFicaClient.dosyaTalep(connTimeout,reqTimeout, url, username, password, bankaKodu, dosyaId , this.message);
				if(response2.getDOSYA() != null){
					byte[] dosya = response2.getDOSYA();
					if (loadReconDetailDataTable(dosya, corporateCode, collectionTypeId, reconLogOid, reconDate, time)) {
						logger.info("...loadReconDeatilDataTable returned true");
						// mutabakatlar tabloya yuklendi. simdi bizdeki kayitlar alinarak kurumdan gelen. recordset icerisinde aranacak once kurum verilerini, recon_detail_data dan al
						logger.info("...ICS_IGDAS_FICA_GET_COLLECTION_RECONCILIATION_DETAIL detail logs are inserted temp table successfully...");
						details = (List<ReconDetailData>) session.createCriteria(ReconDetailData.class).add(Restrictions.eq("status", true))
								.add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("parameter1", "S"))
								.add(Restrictions.eq("parameter2", "T")).add(Restrictions.eq("reconLogOid", reconLogOid)).list();
						
						//FIXME iadeler icin gelecek degerler handle edilmeli
					}
				}
			}
			result.setSuccessfulCall(true);
		} catch (P3CashPointOpenItemFault f) {
			logger.error("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY".concat(f.getFaultInfo().getStandard().getFaultDetail().get(0).getId()));
			logger.error("ICS_IGDAS_FICA_INVOICE_DEBT_INQUIRY".concat(f.getFaultInfo().getStandard().getFaultDetail().get(0).getText()));
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getInvoiceNo());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getInvoiceNo(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getInvoiceNo());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		ReconDetailData corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Abone Numaras� : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getSubscriberNo1(), 
				corporateDetail.getInvoiceNo(), 
				corporateDetail.getPaymentAmount()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(CommonHelper.trimStart(corporateDetail.getSubscriberNo1(), '0'));
		payment.setInvoiceNo(corporateDetail.getInvoiceNo());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setParameter2(corporateDetail.getParameter4());//transactionId
		payment.setInvoiceAmount(corporateDetail.getPaymentAmount());
		payment.setPaymentAmount(corporateDetail.getPaymentAmount());
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getSubscriberNo1());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getInvoiceNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getPaymentAmount());
	}
	
	public static boolean loadReconDetailDataTable(byte[] dosyaByteArray, String corporateCode, String collectionTypeId, String reconLogOid,
			String reconDate, String reconTime) {
		boolean result = false;
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			logger.info("...loadReconDeatilDataTable has just started...");
			int a = 0;
			String dosyaString = new String(dosyaByteArray);
			String kayitTipiHeader = dosyaString.substring(0, 1);
			int bankaKodu = Integer.parseInt((String) (dosyaString.subSequence(1, 5)));
			String siraNumarasi = (String) dosyaString.subSequence(5, 21);
			int islemTarihi = Integer.parseInt((String) (dosyaString.subSequence(21, 29)));
			String kayitTipiFooter = "";
			int base = 31;
			addNewReconDetailData(session, Short.parseShort(collectionTypeId), corporateCode, "", kayitTipiHeader, Integer.toString(bankaKodu),
					Integer.toString(islemTarihi), "Mutabakat detay dosya yuklemesi basliyor", siraNumarasi, "", "", "", "", "", new BigDecimal(0), "", "", "",
					"", "", reconLogOid, reconDate, reconTime);
			
			do {
				String kayitTipiDetail = dosyaString.substring(base, base + 1);
				String islemTipi = dosyaString.substring(base + 1, base + 2);
				int subeKodu = Integer.parseInt((String) dosyaString.substring(base + 2, base + 7));
				String islemNo = dosyaString.substring(base + 7, base + 42);
				String tesisatNumarasi = dosyaString.substring(base + 42, base + 54);
				String faturaNo = dosyaString.substring(base + 54, base + 66);
				BigDecimal tahsilatVeyaIptalTutari = new BigDecimal(dosyaString.substring(base + 66, base + 81));
				String paraBirimi = dosyaString.substring(base + 81, base + 84);
				kayitTipiFooter = dosyaString.substring(base + 86, base + 87);
				base = base + 86;
				ReconDetailData rdd = new ReconDetailData();
				rdd.setCollectionType(Short.parseShort(collectionTypeId));
				rdd.setCorporateCode(corporateCode);
				rdd.setInvoiceNo(faturaNo);
				rdd.setParameter1(kayitTipiDetail);
				rdd.setParameter2(islemTipi);
				rdd.setParameter3(Integer.toString(subeKodu));
				rdd.setParameter4(islemNo);
				rdd.setParameter5(paraBirimi);
				rdd.setPaymentAmount(tahsilatVeyaIptalTutari);
				rdd.setStatus(true);
				rdd.setSubscriberNo1(tesisatNumarasi);
				rdd.setSubscriberNo2("");
				rdd.setSubscriberNo3("");
				rdd.setSubscriberNo4("");
				rdd.setTransactionType(islemTipi);
				rdd.setReconLogOid(reconLogOid);
				rdd.setReconDate(reconDate);
				rdd.setReconTime(reconTime);
				session.saveOrUpdate(rdd);
				a++;
			} while (kayitTipiFooter.equals("S"));
			session.flush();
			logger.info("...loadReconDeatilDataTable has just parsed first part...");
			BigDecimal toplamTahsilatAdedi = new BigDecimal(dosyaString.substring(base + 1, base + 11));
			BigDecimal toplamTahsilatTutari = new BigDecimal(dosyaString.substring(base + 11, base + 26));
			BigDecimal toplamIptalAdedi = new BigDecimal(dosyaString.substring(base + 26, base + 36));
			BigDecimal toplamIptalTutari = new BigDecimal(dosyaString.substring(base + 36, base + 51));
			
			BigDecimal toplamIadeAdedi = new BigDecimal(dosyaString.substring(base + 51, base + 61));
			BigDecimal toplamIadeTutari = new BigDecimal(dosyaString.substring(base + 61, base + 76));
			BigDecimal toplamIptalIadeAdedi = new BigDecimal(dosyaString.substring(base + 76, base + 86));
			BigDecimal toplamIptalIadeTutari = new BigDecimal(dosyaString.substring(base + 86, base + 101));
			
			addNewReconDetailData(session, Short.parseShort(collectionTypeId), corporateCode, Integer.toString(a), 
					toplamTahsilatAdedi.toString(), toplamTahsilatTutari.toString(), 
					toplamIptalAdedi.toString(), toplamIptalTutari.toString(),
					toplamIadeAdedi.toString(), toplamIadeTutari.toString(),
					toplamIptalIadeAdedi.toString(), toplamIptalIadeTutari.toString(),
					"", "", new BigDecimal(0), Integer.toString(bankaKodu), Integer.toString(islemTarihi), "", "", kayitTipiFooter, reconLogOid, reconDate, reconTime);
			
			result = true;
		} catch (Exception e) {
			logger.info("...loadReconDeatilDataTable �al���rken hata meydana geldi...".concat(e.getMessage()));
			return result;
		}

		return result;
	}
	
	public static boolean addNewReconDetailData(Session session, Short collectionType, String corporateCode, String invoiceNo, String parameter1, String parameter2,
			String parameter3, String parameter4, String parameter5, String parameter6, String parameter7, String parameter8, String parameter9,
			String parameter10, BigDecimal paymentAmount, String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4,
			String transactionType, String reconLogOid, String reconDate, String reconTime) {
		try {
			ReconDetailData rdd = new ReconDetailData();
			rdd.setCollectionType(collectionType);
			rdd.setCorporateCode(corporateCode);
			rdd.setInvoiceNo(invoiceNo);
			rdd.setParameter1(parameter1);
			rdd.setParameter2(parameter2);
			rdd.setParameter3(parameter3);
			rdd.setParameter4(parameter4);
			rdd.setParameter5(parameter5);
			rdd.setParameter6(parameter6);
			rdd.setParameter7(parameter7);
			rdd.setParameter8(parameter8);
			rdd.setParameter9(parameter9);
			rdd.setParameter10(parameter10);
			rdd.setPaymentAmount(paymentAmount);
			rdd.setStatus(true);
			rdd.setSubscriberNo1(subscriberNo1);
			rdd.setSubscriberNo2(subscriberNo2);
			rdd.setSubscriberNo3(subscriberNo3);
			rdd.setSubscriberNo4(subscriberNo4);
			rdd.setTransactionType(transactionType);
			rdd.setReconLogOid(reconLogOid);
			rdd.setReconDate(reconDate);
			rdd.setReconTime(reconTime);
			session.saveOrUpdate(rdd);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
