package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.math.RoundingMode;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;

import com.graymound.util.GMMap;

public final class CalculateCommissionHandler extends RequestHandler {

	public CalculateCommissionHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		String corporateCode = input.getString(TransactionConstants.CalculateCommission.Input.CORPORATE_CODE);
		String channelCode = input.getString(TransactionConstants.CalculateCommission.Input.CHANNEL_CODE, null);
		BigDecimal paymentAmount = input.getBigDecimal(TransactionConstants.CalculateCommission.Input.PAYMENT_AMOUNT);
		
		if(channelCode == null){
			channelCode = CommonHelper.getChannelId();
		}
		
		GMMap commissionDefOutput = super.callServiceWithParams(TransactionConstants.GetCommissionDef.SERVICE_NAME,
				TransactionConstants.GetCommissionDef.Input.CHANNEL_CODE, channelCode,
				TransactionConstants.GetCommissionDef.Input.CORPORATE_CODE, corporateCode);
		
		if(commissionDefOutput.containsKey(TransactionConstants.GetCommissionDef.Output.COMMISSION)){
			BigDecimal commission = commissionDefOutput.getBigDecimal(TransactionConstants.GetCommissionDef.Output.COMMISSION);
			
			if(commission.compareTo(BigDecimal.ZERO) != 0){
				
				String doesExemptionExist = "H";
				
				if (input.getString(MapKeys.CHECK_EXEMPTION).equals("1")) {
					
					int customerNo = 0;
					int accountNo = 0;
					if(commissionDefOutput.getBoolean(TransactionConstants.GetCommissionDef.Output.CUSTOMER_EXEMPTION) ||
						commissionDefOutput.getBoolean(TransactionConstants.GetCommissionDef.Output.GROUP_EXEMPTION) ||
						commissionDefOutput.getBoolean(TransactionConstants.GetCommissionDef.Output.SEGMENT_EXEMPTION)){
						
						customerNo = input.getInt(TransactionConstants.CalculateCommission.Input.CUSTOMER_NO);
					}
					
					if(commissionDefOutput.getBoolean(TransactionConstants.GetCommissionDef.Output.ACCOUNT_EXEMPTION)){
						accountNo = 	input.getInt(TransactionConstants.CalculateCommission.Input.ACCOUNT_NO);				
					}
					
					GMMap exMap = new GMMap();
					exMap.put(MapKeys.CUSTOMER_NO, customerNo);
					exMap.put(MapKeys.ACCOUNT_NO, accountNo);
					exMap.put(MapKeys.PROCESS_DEF_ID, "7010");
					
					//exMap = (GMMap) GMServiceExecuter.execute("BNSPR_ACCOUNTIING_CHECK_MASKOM_EXEMPTION", exMap);
					
					//doesExemptionExist = exMap.getString("EXEMPTION");
					doesExemptionExist = "H";
					
				}
				
				
				if(doesExemptionExist.equals("E")){
					output.put(TransactionConstants.CalculateCommission.Output.COMMISSION_AMOUNT, 0);
					output.put(TransactionConstants.CalculateCommission.Output.BSMV_AMOUNT, 0);
					output.put(TransactionConstants.CalculateCommission.Output.TOTAL_AMOUNT, 0);
				}
				else{
					BigDecimal commissionAmount = BigDecimal.ZERO;
					BigDecimal bSMVAmount = BigDecimal.ZERO;
					
					if(commissionDefOutput.getString(TransactionConstants.GetCommissionDef.Output.COMMISSION_TYPE).equals(DatabaseConstants.CommissionTypes.FixedAmount)){
						commissionAmount = commission;
					}
					else if(commissionDefOutput.getString(TransactionConstants.GetCommissionDef.Output.COMMISSION_TYPE).equals(DatabaseConstants.CommissionTypes.Rate)){
						commissionAmount = paymentAmount.multiply(commission.divide(new BigDecimal(100))).setScale(2, RoundingMode.HALF_UP);
					}
					else{
						// TODO throw exception
					}
					
					if(commissionDefOutput.getString(TransactionConstants.GetCommissionDef.Output.BSMV).equals(DatabaseConstants.BSMVTypes.Inside)){
						bSMVAmount = CommonHelper.getBsmvAmount(commissionAmount);
						commissionAmount = commissionAmount.subtract(bSMVAmount);
					}
					else if(commissionDefOutput.getString(TransactionConstants.GetCommissionDef.Output.BSMV).equals(DatabaseConstants.BSMVTypes.Outside)){
						bSMVAmount = CommonHelper.getBsmvAmount(commissionAmount);
					}
					else{
						// TODO throw exception
					}
					
					output.put(TransactionConstants.CalculateCommission.Output.COMMISSION_AMOUNT, commissionAmount);
					output.put(TransactionConstants.CalculateCommission.Output.BSMV_AMOUNT, bSMVAmount);
					output.put(TransactionConstants.CalculateCommission.Output.TOTAL_AMOUNT, commissionAmount.add(bSMVAmount));
				}
			}
			else{
				output.put(TransactionConstants.CalculateCommission.Output.COMMISSION_AMOUNT, 0);
				output.put(TransactionConstants.CalculateCommission.Output.BSMV_AMOUNT, 0);
				output.put(TransactionConstants.CalculateCommission.Output.TOTAL_AMOUNT, 0);
			}
		}
		else{
			output.put(TransactionConstants.CalculateCommission.Output.COMMISSION_AMOUNT, 0);
			output.put(TransactionConstants.CalculateCommission.Output.BSMV_AMOUNT, 0);
			output.put(TransactionConstants.CalculateCommission.Output.TOTAL_AMOUNT, 0);
		}
	}

}
