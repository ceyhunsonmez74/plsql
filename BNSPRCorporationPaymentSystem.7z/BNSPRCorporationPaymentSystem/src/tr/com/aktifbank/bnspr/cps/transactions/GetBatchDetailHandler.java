package tr.com.aktifbank.bnspr.cps.transactions;



import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.BatchDef;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;

import com.graymound.util.GMMap;

public final class GetBatchDetailHandler extends RequestHandler {

	public GetBatchDetailHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String batchName = CommonHelper.getValueOrThrow(input, TransactionConstants.GetBatchDetail.Input.BATCH_NAME);
		String corporateCode = CommonHelper.getValueOrThrow(input, TransactionConstants.GetBatchDetail.Input.CORPORATE_CODE);
		
		CorporateBatchProcess corporateBatchProcessResult = (CorporateBatchProcess)super.getHibernateSession().
				createCriteria(CorporateBatchProcess.class).
				add(Restrictions.eq("batchName", batchName)).
				add(Restrictions.eq("corporateCode", corporateCode)).
				add(Restrictions.eq("status", true)).
				uniqueResult();
		
		if(corporateBatchProcessResult == null){
			throw new BatchComponentException(BusinessException.CORPORATEBATCHPROCESSRECORDISNOTFOUND, batchName, corporateCode);
		}
		
		int commitCount = corporateBatchProcessResult.getCommitCount();
		int threadCount = corporateBatchProcessResult.getThreadCount();
		
		BatchDef batchDefResults = (BatchDef)super.getHibernateSession().
				createCriteria(BatchDef.class)
				.add(Restrictions.eq("batchName", batchName))
				.add(Restrictions.eq("status", true))
				.uniqueResult();
		
		if(batchDefResults == null){
			throw new BatchComponentException(BusinessException.BATCHDEFRECORDISNOTFOUND, batchName);
		}
		
		output.put(TransactionConstants.GetBatchDetail.Output.BATCH_OID, batchDefResults.getOid());
		output.put(TransactionConstants.GetBatchDetail.Output.COMMIT_COUNT, commitCount);
		output.put(TransactionConstants.GetBatchDetail.Output.SERVICE_NAME, batchDefResults.getBatchServiceName());
		output.put(TransactionConstants.GetBatchDetail.Output.THREAD_COUNT, threadCount);
		output.put(TransactionConstants.GetBatchDetail.Output.THRESHOLD, corporateBatchProcessResult.getTryCount());
		output.put(TransactionConstants.GetBatchDetail.Output.CORPORATE_BATCH_PROCESS_OID, corporateBatchProcessResult.getOid());
	}

}
