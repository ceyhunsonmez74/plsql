package tr.com.aktifbank.bnspr.cps.multithreading.implementations;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CollectionReconciliationSameDayStarterInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.PartialParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ServiceBasedMultiThreading;

import com.graymound.util.GMMap;

public class CollectionReconciliationSameDayImplementation extends ServiceBasedMultiThreading {
	private CollectionReconciliationSameDayStarterInformation information;
	
    public CollectionReconciliationSameDayImplementation(CollectionReconciliationSameDayStarterInformation p_information){
    	super();
    	this.information = p_information;
    }
    
    @Override
    protected void prepareCall() throws Throwable {
       
       int s = information.getCorporateMap().getSize(MapKeys.CORPORATE_LIST);
       String dateParam = information.getCorporateMap().getString(MapKeys.PROCESS_DATE);
       
      
       
       for (int i = 0; i < s; i++) {
    	   GMMap input = new GMMap();
    	   input.put(MapKeys.CORPORATE_BATCH_PROCESS_OID, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST,i,MapKeys.CORPORATE_BATCH_PROCESS_OID));
    	   
    	   input = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GET_CORPORATE_BATCH_PARAMETERS",input);
    	   
    	   input.put(MapKeys.PROCESS_DATE, dateParam);
    	   input.put(MapKeys.CORPORATE_CODE, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST,i,MapKeys.CORPORATE_CODE));
    	   input.put(MapKeys.BANK_CODE, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.BANK_CODE));
    	   input.put(MapKeys.BATCH_NAME, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.BATCH_NAME));
    	   input.put(MapKeys.RECON_DATE, CommonHelper.getShortDateTimeString(new Date())); 
           super.registerService(this.information.getServiceName(), input);
           
          
       }
    }
        
    @Override
    protected ParallelCallBehaviour getParallelCallBehaviour() {
         return new PartialParallelCallBehaviour(this.information.getMaxParallelThreadCount(), true);
    }
    
    @Override
    protected void afterCall() throws Throwable {
       if (!this.isHasError()) {
           StringBuilder builder = new StringBuilder();
           for (GMMap output : super.getServiceOutputs()) {
               if (!output.getBoolean(TransactionConstants.StartCorporateBatch.Output.RESULT, false)) {
                  this.setHasError(true);
                  this.setErrorCode("0");
                  builder.append(String.format("An exception occured while informing invoice collections for %s corporate code and %s submit id. ", 
                                                  output.getString(TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE),
                                                  output.getString(TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID)));
               }
           }
           
           if(this.isHasError()){
               this.setErrorMessage(builder.toString());
           }
       }
    }
}

