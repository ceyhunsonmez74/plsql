package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.integration.luleburgaz.LuleburgazClient;
import tr.com.aktifbank.integration.luleburgaz.ServiceMessage;
import tr.com.aktifbank.luleburgaz.ArrayOfMutabakatRaporMakbuzResult;
import tr.com.aktifbank.luleburgaz.MutabakatRaporMakbuzResult;

import com.graymound.util.GMMap;

public class LuleburgazReconciliationDetailBatch extends CollectionReconciliationDetailBatch{
	private static final Log logger = LogFactory.getLog(LuleburgazReconciliationDetailBatch.class);
	Session session;
	ServiceMessage message;
	Map<String, MutabakatRaporMakbuzResult> indexedCorporateRecords;
	List<MutabakatRaporMakbuzResult> details = new ArrayList<MutabakatRaporMakbuzResult>();
	
	public LuleburgazReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, MutabakatRaporMakbuzResult>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
	
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER_6, details.get(corporateRecordIndex).getTahakkukOdemeID());
		cancelCollectionRequest.put(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON, details.get(corporateRecordIndex).getTahsilatIptalAciklama());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.PARAMETER_6));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try{
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 		
			String reconDate = input.getString(MapKeys.RECON_DATE);
			Date dateTime = CommonHelper.getDateTime(CommonHelper.formatDateString(input.getString(MapKeys.RECON_DATE), "yyyyMMdd", "yyyy-MM-dd"), "yyyy-MM-dd");
			
			GregorianCalendar c = new GregorianCalendar();
			c.setTime(dateTime);
			XMLGregorianCalendar date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
			
			ArrayOfMutabakatRaporMakbuzResult response = LuleburgazClient.getGunlukIslemRaporMakbuzDetay(reqTimeout, connTimeout, url, username, password, this.message, date);
					
			for(MutabakatRaporMakbuzResult tahsilat: response.getMutabakatRaporMakbuzResult()){
				if(tahsilat.getTahsilatIptalAciklama().getValue() == null){
					this.details.add(tahsilat);
				}
			}			
			
			result.setSuccessfulCall(true);

		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.PARAMETER_6), super.getBankRecordAtIndex(i));
		}		
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getTahakkukOdemeID().toString(), this.details.get(i));
		}		
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getTahakkukOdemeID().toString());
	}
	
	
	
}
