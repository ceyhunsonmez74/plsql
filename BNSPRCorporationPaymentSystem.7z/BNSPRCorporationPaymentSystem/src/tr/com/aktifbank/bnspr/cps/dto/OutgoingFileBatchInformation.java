package tr.com.aktifbank.bnspr.cps.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import com.graymound.util.GMMap;

public final class OutgoingFileBatchInformation extends BaseTransferObject {

	public OutgoingFileBatchInformation() {
		super();
	}

	String corporateCode;
	List<FormatDetail> headerDetails;
	List<FormatDetail> bodyDetails;
	List<FormatDetail> footerDetails;
	Date processDate;
	BigDecimal ftmProcessId;
	GMMap databaseFields;
	GMMap serviceFields;
	GMMap outgoingFileBatchInput;
	Session hibernateSession;
	int lineNumber;
	int afterProcessLineNumber;
	boolean processWeekend;
	boolean isShowPaymentDateAsToday;
	boolean informOnlyStandingOrderPayments;
	boolean deleteDecimalPart;
	String fieldLimitationPattern;
	
	
	
	
	public String getFieldLimitationPattern() {
		return fieldLimitationPattern;
	}
	public void setFieldLimitationPattern(String fieldLimitationPattern) {
		this.fieldLimitationPattern = fieldLimitationPattern;
	}
	public boolean isDeleteDecimalPart() {
		return deleteDecimalPart;
	}
	public void setDeleteDecimalPart(boolean deleteDecimalPart) {
		this.deleteDecimalPart = deleteDecimalPart;
	}
	public boolean isInformOnlyStandingOrderPayments() {
		return informOnlyStandingOrderPayments;
	}
	public void setInformOnlyStandingOrderPayments(
			boolean informOnlyStandingOrderPayments) {
		this.informOnlyStandingOrderPayments = informOnlyStandingOrderPayments;
	}
	public boolean isShowPaymentDateAsToday() {
		return isShowPaymentDateAsToday;
	}
	public void setShowPaymentDateAsToday(boolean isShowPaymentDateAsToday) {
		this.isShowPaymentDateAsToday = isShowPaymentDateAsToday;
	}
	public boolean isProcessWeekend() {
		return processWeekend;
	}
	public void setProcessWeekend(boolean processWeekend) {
		this.processWeekend = processWeekend;
	}
	public int getAfterProcessLineNumber() {
		return afterProcessLineNumber;
	}
	public void setAfterProcessLineNumber(int afterProcessLineNumber) {
		this.afterProcessLineNumber = afterProcessLineNumber;
	}
	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public Session getHibernateSession() {
		return hibernateSession;
	}
	public void setHibernateSession(Session hibernateSession) {
		this.hibernateSession = hibernateSession;
	}
	public String getCorporateCode() {
		return corporateCode;
	}
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	public List<FormatDetail> getHeaderDetails() {
		return headerDetails;
	}
	public void setHeaderDetails(List<FormatDetail> headerDetails) {
		this.headerDetails = headerDetails;
	}
	public List<FormatDetail> getBodyDetails() {
		return bodyDetails;
	}
	public void setBodyDetails(List<FormatDetail> bodyDetails) {
		this.bodyDetails = bodyDetails;
	}
	public List<FormatDetail> getFooterDetails() {
		return footerDetails;
	}
	public void setFooterDetails(List<FormatDetail> footerDetails) {
		this.footerDetails = footerDetails;
	}
	public Date getProcessDate() {
		return processDate;
	}
	public void setProcessDate(Date invoiceDate) {
		this.processDate = invoiceDate;
	}
	public BigDecimal getFtmProcessId() {
		return ftmProcessId;
	}
	public void setFtmProcessId(BigDecimal ftmProcessId) {
		this.ftmProcessId = ftmProcessId;
	}
	public GMMap getDatabaseFields() {
		return databaseFields;
	}
	public void setDatabaseFields(GMMap databaseFields) {
		this.databaseFields = databaseFields;
	}
	public GMMap getServiceFields() {
		return serviceFields;
	}
	public void setServiceFields(GMMap serviceFields) {
		this.serviceFields = serviceFields;
	}
	public GMMap getOutgoingFileBatchInput() {
		return outgoingFileBatchInput;
	}
	public void setOutgoingFileBatchInput(GMMap outgoingFileBatchInput) {
		this.outgoingFileBatchInput = outgoingFileBatchInput;
	}
	
	
}
