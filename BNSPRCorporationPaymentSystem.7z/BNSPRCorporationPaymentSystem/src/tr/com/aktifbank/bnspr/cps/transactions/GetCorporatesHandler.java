package tr.com.aktifbank.bnspr.cps.transactions;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class GetCorporatesHandler extends RequestHandler {

	public GetCorporatesHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String sectorCode = input.getString(TransactionConstants.GetCorporates.Inputs.SECTOR_CODE, null);
		String channelCode = input.getString(TransactionConstants.GetCorporates.Inputs.CHANNEL_CODE, null);
		boolean isActivenessFilterExists = input.containsKey(TransactionConstants.GetCorporates.Inputs.ACTIVENESS);
		boolean activeness = input.getBoolean(TransactionConstants.GetCorporates.Inputs.ACTIVENESS, true);
		
		StringBuilder queryBuilder = new StringBuilder();
		
		queryBuilder.append("SELECT distinct cm.OID, cm.CORPORATE_CODE, cm.CORPORATE_NAME, cm.CORPORATE_ACTIVENESS, cm.SHORT_CODE,ctf.IS_APPEARANCE_PAYMENT_SCREEN ");
		queryBuilder.append("FROM cdm.CORPORATE_MASTER cm INNER JOIN cdm.CHANNEL_SOURCE_DEF csd ");
		queryBuilder.append("ON cm.OID = csd.CORPORATE_OID INNER JOIN cdm.COLLECTION_TYPE_DEF ctf ON cm.OID=ctf.CORPORATE_OID ");
		queryBuilder.append("WHERE cm.STATUS = 1 and ctf.IS_APPEARANCE_PAYMENT_SCREEN=1 and ctf.STATUS=1 and csd.STATUS=1 ");
		
		if(!StringUtil.isEmpty(sectorCode)){
			queryBuilder.append(String.format("AND cm.SECTOR_CODE = '%s' ", sectorCode));
		}
		if(!StringUtil.isEmpty(channelCode)){
			queryBuilder.append(String.format("AND csd.CHANNEL_CODE = '%s' ", channelCode));
		}
		if(isActivenessFilterExists){
			queryBuilder.append(String.format("AND cm.CORPORATE_ACTIVENESS = '%s' ", activeness ? DatabaseConstants.CorporateActiveness.Active : DatabaseConstants.CorporateActiveness.Passive));
		}
		queryBuilder.append(" ORDER BY cm.short_code");
		String tableName = TransactionConstants.GetCorporates.Output.CORPORATE_TABLE;
		GMMap results = DALUtil.getResults(queryBuilder.toString().trim(), tableName);
		for (int i = 0; i < results.getSize(tableName); i++) {
			output.put(tableName, i, TransactionConstants.GetCorporates.Output.CORPORATE_OID, 
					results.getString(tableName, i, "OID"));
			output.put(tableName, i, TransactionConstants.GetCorporates.Output.CORPORATE_ACTIVENESS, 
					results.getString(tableName, i, "CORPORATE_ACTIVENESS").equals(DatabaseConstants.CorporateActiveness.Active));
			output.put(tableName, i, TransactionConstants.GetCorporates.Output.CORPORATE_CODE, 
					results.getString(tableName, i, "CORPORATE_CODE"));
			output.put(tableName, i, TransactionConstants.GetCorporates.Output.CORPORATE_NAME, 
					results.getString(tableName, i, "CORPORATE_NAME"));
			output.put(tableName, i, TransactionConstants.GetCorporates.Output.SHORT_CODE, 
					results.getString(tableName, i, "SHORT_CODE"));
		}
	}

}
