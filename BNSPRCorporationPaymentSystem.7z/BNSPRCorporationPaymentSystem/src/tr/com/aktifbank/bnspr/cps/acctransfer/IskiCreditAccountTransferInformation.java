package tr.com.aktifbank.bnspr.cps.acctransfer;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.dto.TransferInformation;
import tr.com.aktifbank.bnspr.dao.CreditLoad;

public final class IskiCreditAccountTransferInformation implements
		IAccountTransferInformation {

	protected TransferInformation information;
	Date currentDate;
	
	public IskiCreditAccountTransferInformation(TransferInformation information) {
		this.information = information;
		this.currentDate = new Date();
	}

	@Override
	public int getCount() {
		return (Integer) this.information.getHibernateSession().createCriteria(CreditLoad.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
							.add(Restrictions.eq("customerType", "1"))
							.add(Restrictions.like("paymentDate", CommonHelper.getShortDateTimeString(this.information.getCollectionDate()), MatchMode.START))
							.setProjection(Projections.rowCount())
							.uniqueResult();
	}

	@Override
	public BigDecimal getTotalAmount() {
		BigDecimal amount = (BigDecimal) this.information.getHibernateSession().createCriteria(CreditLoad.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
								.add(Restrictions.eq("customerType", "1"))
								.add(Restrictions.isNull("balanceTransferDate"))
								.add(Restrictions.like("paymentDate", CommonHelper.getShortDateTimeString(this.information.getCollectionDate()), MatchMode.START))
								.setProjection(Projections.sum("loadedAmount"))
								.uniqueResult();
		
		if(amount != null){
			return amount;
		}
		else{
			return new BigDecimal(0);
		}
	}

	@Override
	public void updateRecords() {
		this.information.getHibernateSession().createSQLQuery(String.format(QueryRepository.IskiCreditAccountTransferInformationRepository.BALANCE_TRANSFER_UPDATE_QUERY, 
				CommonHelper.getLongDateTimeString(currentDate), CommonHelper.getShortDateTimeString(this.information.getCollectionDate())))
				.executeUpdate();
	}

}
