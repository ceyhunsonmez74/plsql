package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.ChannelSourceDef;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class CorporateChannelWorkingHourControlHandler extends
		RequestHandler {
	
	private static final String timeFormat = "hhmm";
	private static final String dateFormat = "yyyyMMddhhmm";

	public CorporateChannelWorkingHourControlHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateOid = input.getString(TransactionConstants.CorporateChannelWorkingHourControl.Input.CORPORATE_OID, null);
		String sourceCode = input.getString(TransactionConstants.CorporateChannelWorkingHourControl.Input.SOURCE_CODE);
		String channelCode = input.getString(TransactionConstants.CorporateChannelWorkingHourControl.Input.CHANNEL_CODE);
		Date inputDate = input.getDate(TransactionConstants.CorporateChannelWorkingHourControl.Input.DATE);
		String corporateName = input.getString(TransactionConstants.CorporateChannelWorkingHourControl.Input.CORPORATE_NAME, null);
		
		if(corporateOid == null){
			String corporateCode = input.getString(TransactionConstants.CorporateChannelWorkingHourControl.Input.CORPORATE_CODE);
			corporateOid = CommonBusinessOperations.getCorporateOidFromCorporateCode(corporateCode);
		}
		
		@SuppressWarnings("unchecked")
		List<ChannelSourceDef> channelSourceDefinitions = super.getHibernateSession()
				.createCriteria(ChannelSourceDef.class)
				.add(Restrictions.eq("corporateOid", corporateOid))
				.add(Restrictions.eq("channelCode", channelCode))
				.add(Restrictions.eq("status", true))
				.list();
		
		if(channelSourceDefinitions.size() > 0){
			ChannelSourceDef channelSourceDefinition = null;
			for(ChannelSourceDef def : channelSourceDefinitions){
				if(def.getSourceCode().equals(sourceCode)){
					channelSourceDefinition = def;
					break;
				}
			}
			if (channelSourceDefinition != null) {
				Date currentDate = inputDate;
				if (CommonHelper.isTodayWorkingDay()) {
					Date startTime = CommonHelper.getCurrentDateWithTime(
							channelSourceDefinition.getWorkingdayStartTime(),
							timeFormat);
					Date endTime = CommonHelper.getCurrentDateWithTime(
							channelSourceDefinition.getWorkingdayEndTime(),
							timeFormat);
					if (!CommonHelper.isBetweenDates(currentDate, startTime,
							endTime)) {
						throw new BatchComponentException(
								BusinessException.NOTWORKINGHOURS, getCorporateName(corporateName, corporateOid));
					}
				} else {
					Date startTime = CommonHelper.getCurrentDateWithTime(
							channelSourceDefinition.getHolidayStartTime(),
							timeFormat);
					Date endTime = CommonHelper.getCurrentDateWithTime(
							channelSourceDefinition.getHolidayEndTime(),
							timeFormat);
					if (!CommonHelper.isBetweenDates(currentDate, startTime,
							endTime)) {
						throw new BatchComponentException(
								BusinessException.NOTWORKINGHOURS, getCorporateName(corporateName, corporateOid));
					}
				}
				if (!StringUtil.isEmpty(channelSourceDefinition.getClosedDateStart()) && !StringUtil.isEmpty(channelSourceDefinition.getClosedDateEnd())) {
					Date startDate = CommonHelper.getDateTime(
							channelSourceDefinition.getClosedDateStart(),
							dateFormat);
					Date endDate = CommonHelper.getDateTime(
							channelSourceDefinition.getClosedDateEnd(),
							dateFormat);
					if (CommonHelper.isBetweenDates(currentDate, startDate,
							endDate)) {
						throw new BatchComponentException(
								BusinessException.NOTWORKINGDAYS,
								getCorporateName(corporateName, corporateOid));
					}
				}
			}
			else{
				throw new BatchComponentException(BusinessException.SOURCEISNOTDEFINEDFORCORPORATE, getCorporateName(corporateName, corporateOid), getSourceName(sourceCode));
			}
		}
		else{
			throw new BatchComponentException(BusinessException.CHANNELISNOTDEFINEDFORCORPORATE, getCorporateName(corporateName, corporateOid), getChannelName(channelCode));
		}
		
		output.put(TransactionConstants.CorporateChannelWorkingHourControl.Output.RESULT, true);
	}

	private String getChannelName(String channelCode) {
		return channelCode;
	}

	private String getSourceName(String sourceCode) {
		return CommonBusinessOperations.getPaymentSourceName(sourceCode);
	}

	private String getCorporateName(String corporateName, String corporateOid) {
		if(corporateName != null){
			return corporateName;
		}
		else{
			GMMap outMap = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME,
					TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid);
			return outMap.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE);
		}
	}

}
