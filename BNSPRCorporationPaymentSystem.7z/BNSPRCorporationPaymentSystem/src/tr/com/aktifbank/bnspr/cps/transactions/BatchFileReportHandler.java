package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.collections.map.HashedMap;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant.Email.BatchFileReportMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.dao.BatchSubmitLog;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class BatchFileReportHandler extends RequestHandler{

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		String batchName = null;
		String processDate = null;
		Integer duration = null;
		String subject = null;
		String from,receipts,cc = null;
		List<String> corporateExceptionList = new ArrayList<String>();
		
		if(input.containsKey("EXCEPTION_LIST")){
			corporateExceptionList.addAll(Arrays.asList(input.getString("EXCEPTION_LIST").split(",")));
		}
			
		if( input.containsKey(TransactionConstants.BatchFileReporter.Input.BATCH_NAME) ){
			batchName = input.getString(TransactionConstants.BatchFileReporter.Input.BATCH_NAME);
		}
		
		if( input.containsKey(TransactionConstants.BatchFileReporter.Input.PROCESS_DATE) ){
			processDate = input.getString(TransactionConstants.BatchFileReporter.Input.PROCESS_DATE);
		}
		
		if( input.containsKey(TransactionConstants.BatchFileReporter.Input.DURATION) ){
			duration = input.getInt(TransactionConstants.BatchFileReporter.Input.DURATION);
		}
		
		if( input.containsKey(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_SUBJECT) ){
			subject = input.getString(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_SUBJECT);
			if( null == subject ){
				subject = NotificationMessageConstant.Email.BatchFileReportMessageConstant.SUBJECT;
			}
		}
		else{
			subject = NotificationMessageConstant.Email.BatchFileReportMessageConstant.SUBJECT;
		}
		
		if( input.containsKey(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_FROM) ){
			from = input.getString(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_FROM);
			if( null == from ){
				from = NotificationMessageConstant.Email.FROM;
			}
		}
		else{
			from = NotificationMessageConstant.Email.FROM;
		}
		
		if( input.containsKey(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_TO) ){
			receipts = input.getString(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_TO);
			if( null == receipts ){
				receipts = NotificationMessageConstant.Email.BatchFileReportMessageConstant.RECEIPT_LIST;
			}
		}
		else{
			receipts = NotificationMessageConstant.Email.BatchFileReportMessageConstant.RECEIPT_LIST;
		}
			
		if( input.containsKey(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_CC) ){
			cc = input.getString(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_CC);
			if( null == cc ){
				cc = NotificationMessageConstant.Email.BatchFileReportMessageConstant.CC;
				
			}
		}
		else{
			cc = NotificationMessageConstant.Email.BatchFileReportMessageConstant.CC;
		}
		
		Session hibernateSession = CommonHelper.getHibernateSession();
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT count(*),submit_status,corporate_code FROM CDM.BATCH_SUBMIT_LOG WHERE submit_date LIKE :processDate and batch_name = :batchName and status = 1 ");
		if(corporateExceptionList.size() > 0){
			sql.append("and corporate_code not in (");
			for (String exc : corporateExceptionList) {
				sql.append(String.format("'%s'", exc));
				if(corporateExceptionList.indexOf(exc) != corporateExceptionList.size() - 1){
					sql.append(",");
				}
			}
			sql.append(")"); 
		}
		sql.append(" group by batch_name, substr(submit_date,0,8),corporate_code,submit_status");
				
		List<Object[]> returnList = hibernateSession.createSQLQuery(sql.toString()).setParameter("processDate",processDate + "%")
		 				  	.setParameter("batchName", batchName)
		 				  	.list();

		Set<String> corporates = new HashSet<String>();
		int succesStatusCounter = 0;
		int failureStatusCounter = 0;
		
		if( null != returnList ){
			for( Object [] rows : returnList){
				if( null != rows[0]){
					int count = Integer.parseInt(rows[0].toString());
					if( null != rows[1] && count > 0 ){
						String status = rows[1].toString();
						if( DatabaseConstants.SubmitStatuses.SUCESSFUL.equals(status) ){
							succesStatusCounter += count;
						}
						else if( DatabaseConstants.SubmitStatuses.FAILURE.equals(status) ){
							failureStatusCounter += count;
						}
					}
				}
				
				if( null != rows[2] ){
					corporates.add(rows[2].toString());
				}
				
			}
			
		}
		
		List<BatchSubmitLog> detailList = hibernateSession.createCriteria(BatchSubmitLog.class).add(Restrictions.ilike("submitDate", processDate, MatchMode.START))
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("batchName", batchName))
							.list();
		
		List<Map<String,String>> detailMapList = new ArrayList<Map<String,String>>();
		if( null != detailList ){
			for( BatchSubmitLog detail : detailList ){
				Map<String,String> columnMap = new HashedMap();
				
				if( null != detail.getCorporateCode() ){
					columnMap.put("ROW_CORPORATE_CODE", detail.getCorporateCode());
					String shortName = CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(detail.getCorporateCode());
					columnMap.put("ROW_CORPORATE_NAME", shortName);
				}
				
				if( null != detail.getSubmitStatus() ){
					String submitStatus = detail.getSubmitStatus();
					String submitStatusName = "";
					if( DatabaseConstants.SubmitStatuses.SUCESSFUL.equals(submitStatus) ){
						submitStatusName = "Ba�ar�l�";
						columnMap.put("ROW_ERROR_CODE", "");
						columnMap.put("ROW_ERROR_DESC", "");
					}
					else if( DatabaseConstants.SubmitStatuses.FAILURE.equals(submitStatus) ){
						submitStatusName = "Ba�ar�s�z";
						columnMap.put("ROW_ERROR_CODE", detail.getErrorCode());
						if( null != detail.getErrorDesc() ){
							columnMap.put("ROW_ERROR_DESC", detail.getErrorDesc().getSubString(1, (int) detail.getErrorDesc().length()));
						}
					}
					columnMap.put("ROW_STATUS", submitStatusName);
				}
				
				Date startTime = null, endTime = null;
				if( null != detail.getStartTime() ){
					startTime = CommonHelper.getDateTime(detail.getStartTime(), "yyyyMMddhhmmss");
					columnMap.put("ROW_START_TIME", CommonHelper.formatDateString(detail.getStartTime(), "yyyyMMddhhmmss", "dd/MM/yyyy hh:mm:ss"));
				}
				if( null != detail.getEndTime() ){
					endTime = CommonHelper.getDateTime(detail.getEndTime(), "yyyyMMddhhmmss");
					columnMap.put("ROW_END_TIME", CommonHelper.formatDateString(detail.getEndTime(), "yyyyMMddhhmmss", "dd/MM/yyyy hh:mm:ss"));
				}
				
				if( null != endTime && null != startTime ){
					columnMap.put("ROW_DURATION", String.valueOf((endTime.getTime() - startTime.getTime())));
				}
				else{
					columnMap.put("ROW_DURATION", "0");
				}
				
				detailMapList.add(columnMap);
			}
		}
		
		GMMap messageMap = new GMMap();
		messageMap.put("ENVIRONMENT", GMServiceExecuter.call("BNSPR_CORE_GET_SISTEM_ADI", input).getString("SISTEM_ADI"));
		messageMap.put("PROCESS_DATE",CommonHelper.formatDateString(processDate, "yyyyMMdd", "dd/MM/yyyy"));
		messageMap.put("COUNT", corporates.size());
		messageMap.put("TOTAL_DURATION", duration);
		messageMap.put("SUCCESS_STATUS", succesStatusCounter);
		messageMap.put("FAILURE_STATUS", failureStatusCounter);
		messageMap.put("BATCH_NAME", batchName);
		messageMap.put("MAP_TABLE", detailMapList);
		
		GMMap subjectMap = new GMMap();
		subjectMap.put("BATCH_NAME", batchName);
		subjectMap.put("PROCESS_DATE",CommonHelper.formatDateString(processDate, "yyyyMMdd", "dd/MM/yyyy"));
		
		EmailMessage emailMessage = CommonHelper.prepareEmailBody("", messageMap,BatchFileReportMessageConstant.MESSAGE_BODY,
				generateSubject(subject,subjectMap),receipts);
		
		CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
		
	}

	private String generateSubject(String subject, GMMap input){
		
		Set<Entry<Object, Object>> entrySet = input.entrySet();
		Iterator<Entry<Object, Object>> iterator = entrySet.iterator();
		while( iterator.hasNext() ){
			Entry<Object, Object> nextElement = iterator.next();
			if( input.containsKey(nextElement.getKey()) ){
				subject = subject.replaceAll(nextElement.getKey().toString(), nextElement.getValue().toString());
			}
		}
		
		return subject;
	}
}
