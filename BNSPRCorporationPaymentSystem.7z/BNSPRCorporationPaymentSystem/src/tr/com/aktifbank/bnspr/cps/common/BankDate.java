package tr.com.aktifbank.bnspr.cps.common;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class BankDate extends Date {

	private static final Log logger = LogFactory.getLog(BankDate.class);
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2080184299254160336L;

	public BankDate() {
		super(getBankDate());
	}

	private static long getBankDate() {
		GMMap output = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap());
		Date outDate;
		try {
			outDate = output.getDate("BANKA_TARIH");
		} catch (ParseException e) {
			logger.error(System.currentTimeMillis(), e);
			outDate = new Date();
		}
		Date currentDate = new Date();
		Calendar currentCalendar = Calendar.getInstance();
		currentCalendar.setTime(currentDate);
		Calendar cal = Calendar.getInstance();
		cal.setTime(outDate);
		cal.set(Calendar.HOUR_OF_DAY, currentCalendar.get(Calendar.HOUR_OF_DAY));
		cal.set(Calendar.MINUTE, currentCalendar.get(Calendar.MINUTE));
		cal.set(Calendar.SECOND, currentCalendar.get(Calendar.SECOND));
		return cal.getTimeInMillis();
	}

}
