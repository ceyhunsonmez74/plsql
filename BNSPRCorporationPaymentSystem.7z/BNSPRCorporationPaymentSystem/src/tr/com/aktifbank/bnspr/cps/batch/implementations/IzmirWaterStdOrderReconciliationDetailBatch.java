package tr.com.aktifbank.bnspr.cps.batch.implementations;

import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;

import com.graymound.util.GMMap;

public class IzmirWaterStdOrderReconciliationDetailBatch extends
		StandingOrderReconciliationDetailBatch {

	public IzmirWaterStdOrderReconciliationDetailBatch(GMMap input) {
		super(input);
	}

	@Override
	protected void setCancelStandingOrderExtraParameters(
			GMMap cancelStandingOrderRequest, int corporateRecordIndex) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void setCorporateParametersToReconProcessLogInput(
			GMMap reconProcessDataLogInput, int corporateRecordIndex) {
		// TODO Auto-generated method stub

	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(
			icsStandingOrders bankRecord) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(
			int corporateRecordIndex) {
		// TODO Auto-generated method stub
		return false;
	}

}
