package tr.com.aktifbank.bnspr.cps.util;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.EmailConstants;
import tr.com.aktifbank.bnspr.cps.common.BatchParameterEngine;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.transactions.BatchFileReportHandler;
import tr.com.aktifbank.bnspr.cps.transactions.BedasCheckSubscriberNumberChange;
import tr.com.aktifbank.bnspr.cps.transactions.CalculateTransferDatesHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CheckDuplicatePaymentsHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CheckStandingOrderBillsHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CollectionReconciliationHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CollectionReconciliationSameDayStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CollectionReconciliationStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.transactions.CorporateStandingOrderTransferStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.ExecuteCorporateBatchHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetBatchDetailHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetBatchParametersHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InformInvoiceCollectionStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InformInvoiceCollectionWithExcelStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InformStandingOrdersCancelStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InformStandingOrdersStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InsertBatchSubmitLogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InsertCorporateAccountBlockedLogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InsertFileErrorLogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.MoneyLoadReconciliationHandler;
import tr.com.aktifbank.bnspr.cps.transactions.MoneyLoadReconciliationStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.OnlineStandingOrderDebtLoading;
import tr.com.aktifbank.bnspr.cps.transactions.OnlineStandingOrderDebtLoadingHandler;
import tr.com.aktifbank.bnspr.cps.transactions.PaymentTransactionsDetailReportHandler;
import tr.com.aktifbank.bnspr.cps.transactions.ProcessStandingOrderBacklogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.QueryBalanceTrasferLogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cps.transactions.SafReporterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.SameDayCorporateAccountTransferHandler;
import tr.com.aktifbank.bnspr.cps.transactions.SameDayInformInvoiceCollectionStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.SendComplexFileBatch;
import tr.com.aktifbank.bnspr.cps.transactions.SequenceCodeResetHandler;
import tr.com.aktifbank.bnspr.cps.transactions.StandingOrderInvoiceCollectionHandler;
import tr.com.aktifbank.bnspr.cps.transactions.StandingOrderInvoiceCollectionStarterHandler;
import tr.com.aktifbank.bnspr.cps.transactions.StartComplexFileBatchHandler;
import tr.com.aktifbank.bnspr.cps.transactions.StartCorporateAccountTransferHandler;
import tr.com.aktifbank.bnspr.cps.transactions.StartCorporateBatchHandler;
import tr.com.aktifbank.bnspr.cps.transactions.TTSReconciliationLineParser;
import tr.com.aktifbank.bnspr.cps.transactions.TransferCorporateAccountHandler;
import tr.com.aktifbank.bnspr.cps.transactions.UpdateBalanceTransferInformationHandler;
import tr.com.aktifbank.bnspr.dao.BatchParameters;
import tr.com.aktifbank.bnspr.dao.BatchUsedParam;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.aktifbank.bnspr.dao.CorporateParameters;
import tr.com.aktifbank.bnspr.dao.FileTransferLog;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.StandingOrderComm;
import tr.com.aktifbank.bnspr.dao.StandingOrderMain;
import tr.com.aktifbank.bnspr.dao.StdBulkEmailDef;
import tr.com.aktifbank.bnspr.dao.icsStdOrderProcessLog;
import tr.com.aktifbank.bnspr.dao.invoiceMain;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class BatchUtilities {
	private static final Log logger = LogFactory.getLog(BatchUtilities.class);

	
	@GraymoundService("ICS_INSERT_BATCH_SUBMIT_LOG")
	public static GMMap insertBatchSubmitLog(GMMap logMap) {
		return RequestProcessor.getInstance().process(logMap,
				new InsertBatchSubmitLogHandler());
	}

	@GraymoundService("ICS_INSERT_FILE_ERROR_LOG")
	public static GMMap insertFileErrorLog(GMMap logMap) {
		return RequestProcessor.getInstance().process(logMap,
				new InsertFileErrorLogHandler());
	}

	@GraymoundService("ICS_GET_CORPORATE_BATCH_DETAIL")
	public static GMMap getBatchDetail(GMMap input) {
		return RequestProcessor.getInstance().process(input,
				new GetBatchDetailHandler());
	}

	@GraymoundService("ICS_GET_CORPORATE_BATCH_PARAMETERS")
	public static GMMap getBatchParameters(GMMap input) {
		return RequestProcessor.getInstance().process(input,
				new GetBatchParametersHandler());
	}
	
	@GraymoundService("ICS_INFORM_INVOICE_COLLECTION_SAME_DAY_STARTER")
	public static GMMap informInvoiceCollectionSameDayStarter(GMMap input) {
		return RequestProcessor.getInstance().process(input,
				new SameDayInformInvoiceCollectionStarterHandler());
	}
	
	@GraymoundService("ICS_INFORM_INVOICE_COLLECTION_STARTER")
	public static GMMap informInvoiceCollectionStarter(GMMap input) {
		input.put(TransactionConstants.InformInvoiceCollectionStarter.Input.INDICATOR, GeneralConstants.INFORM_COLLECTIONS);
		return RequestProcessor.getInstance().process(input,
				new InformInvoiceCollectionStarterHandler());
	}
	
	@GraymoundService("ICS_INFORM_INVOICE_COLLECTION_WITH_EXCEL_STARTER")
	public static GMMap informInvoiceCollectionWithExcelStarter(GMMap input) {
		input.put(TransactionConstants.InformInvoiceCollectionStarter.Input.INDICATOR, GeneralConstants.INFORM_COLLECTIONS_WITH_EXCEL);
		return RequestProcessor.getInstance().process(input,
				new InformInvoiceCollectionWithExcelStarterHandler());
	}
	
	@GraymoundService("ICS_INFORM_STANDING_ORDERS_STARTER")
	public static GMMap informStandingOrdersStarter(GMMap input) {
		input.put(TransactionConstants.InformStandingOrdersStarter.Input.INDICATOR, GeneralConstants.INFORM_STANDING_ORDERS);
		return RequestProcessor.getInstance().process(input,
				new InformStandingOrdersStarterHandler());
	}
	
	@GraymoundService("ICS_INFORM_STANDING_ORDERS_CANCEL_STARTER")
	public static GMMap informStandingOrdersCancelStarter(GMMap input){
		input.put(TransactionConstants.InformStandingOrdersCancelStarter.Input.INDICATOR, GeneralConstants.INFORM_STANDING_ORDERS_CANCEL);
		return RequestProcessor.getInstance().process(input, new InformStandingOrdersCancelStarterHandler());
	}
	
	@GraymoundService("ICS_CORPORATE_BATCH_STARTER")
	public static GMMap startCorporateBatch(GMMap input) {
		return RequestProcessor.getInstance().process(input,
				new StartCorporateBatchHandler());
	}
	
    @GraymoundService("ICS_ONLINE_STANDING_ORDER_DEBT_LOADING_STARTER")
    public static GMMap onlineStandingOrderDebtLoadingStart(GMMap input) {
                  return RequestProcessor.getInstance().process(input,
                          new OnlineStandingOrderDebtLoading());
    }
    
    @GraymoundService("ICS_ONLINE_STANDING_ORDER_DEBT_LOADING")
    public static GMMap onlineStandingOrderDebtLoading(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new OnlineStandingOrderDebtLoadingHandler());
    }
    
    
    @GraymoundService("ICS_COLLECTION_RECONCILIATION_STARTER")
    public static GMMap collectionReconciliationStart(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new CollectionReconciliationStarterHandler());
    }
    
    @GraymoundService("ICS_COLLECTION_RECONCILIATION_SAME_DAY_STARTER")
    public static GMMap collectionReconciliationSameDayStart(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new CollectionReconciliationSameDayStarterHandler());
    }
    
    @GraymoundService("ICS_COLLECTION_RECONCILIATION")
    public static GMMap collectionReconciliation(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new CollectionReconciliationHandler());
    }
    
    @GraymoundService("ICS_MONEY_LOAD_RECONCILIATION")
    public static GMMap moneyLoadReconciliation(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new MoneyLoadReconciliationHandler());
    }
    
    @GraymoundService("ICS_MONEY_LOAD_RECONCILIATION_STARTER")
    public static GMMap moneyLoadReconciliationStart(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new MoneyLoadReconciliationStarterHandler());
    }
    
    @GraymoundService("ICS_STANDING_ORDER_OFFLINE_INVOICE_COLLECTION_STARTER")
    public static GMMap sandingOrderOfflineDoInvoiceOnline(GMMap input) {
    	try {
			input.put("IS_ONLINE_CORPORATE", "0");
			logger.error("CDM_EXTRA_PARAMETERS"+CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STD_ORD_INV_COLL_SW"));
			if("1".equals(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STD_ORD_INV_COLL_SW"))){
        		return CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.AUTO_PAY_CHANNEL_CONN_NAME, "ICS_STANDING_ORDER_ONLINE_INVOICE_COLLECTION_CHANNEL_STARTER", input);
        	}else{
        		return CommonHelper.callGraymoundServiceInHibernateSession("ICS_STANDING_ORDER_ONLINE_INVOICE_COLLECTION_CHANNEL_STARTER", input);
        	}
		} catch (IOException e) {
			throw ExceptionHandler.convertException(e);
		}
    }
    
    @GraymoundService("ICS_STANDING_ORDER_OFFLINE_INVOICE_COLLECTION_CHANNEL_STARTER")
    public static GMMap sandingOrderOfflineChannelDoInvoiceOnline(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new StandingOrderInvoiceCollectionStarterHandler());
    }
    
    @GraymoundService("ICS_STANDING_ORDER_ONLINE_INVOICE_COLLECTION_CHANNEL_STARTER")
    public static GMMap standingOrderOnlineChannelDoInvoiceOffline(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new StandingOrderInvoiceCollectionStarterHandler());
    }
    
    @GraymoundService("ICS_STANDING_ORDER_ONLINE_INVOICE_COLLECTION_STARTER")
    public static GMMap standingOrderOnlineDoInvoiceOffline(GMMap input) {
    	input.put("IS_ONLINE_CORPORATE", "1");
        try{
			logger.error("CDM_EXTRA_PARAMETERS" +CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STD_ORD_INV_COLL_SW"));
        	if("1".equals(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STD_ORD_INV_COLL_SW"))){
        		return CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.AUTO_PAY_CHANNEL_CONN_NAME, "ICS_STANDING_ORDER_ONLINE_INVOICE_COLLECTION_CHANNEL_STARTER", input);
        	}else{
        		return CommonHelper.callGraymoundServiceInHibernateSession("ICS_STANDING_ORDER_ONLINE_INVOICE_COLLECTION_CHANNEL_STARTER", input);
        	}
        	
        }
        catch(Exception e){
        	throw ExceptionHandler.convertException(e);
        }
    }

    @GraymoundService("ICS_STANDING_ORDER_INVOICE_COLLECTION")
    public static GMMap standingOrderDoInvoiceCollection(GMMap input) {
                   return RequestProcessor.getInstance().process(input,
                                                   new StandingOrderInvoiceCollectionHandler());
    }

    
	@GraymoundService("ICS_CORPORATE_EXECUTE_BATCH")
	public static GMMap executeCorporateBatch(GMMap input) {
		return RequestProcessor.getInstance().process(input,
				new ExecuteCorporateBatchHandler());
	}
	
	@GraymoundService("CDM_CORPORATE_STANDING_ORDER_TRANSFER_STARTER")
	public static GMMap startCorporateStandingOrderTransfer(GMMap input){
		return RequestProcessor.getInstance().process(input, new CorporateStandingOrderTransferStarterHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_CORPORATE_ACCOUNT_BATCH_STARTER")
	public static GMMap startCorporateAccountTransfer(GMMap input){
		input.put("BATCH_NAME", DatabaseConstants.BatchNames.AccountTransferBatch);
		input.put("TRANSFER_TYPE", DatabaseConstants.AccountTransferTypes.CorporateTransfer);
		return RequestProcessor.getInstance().process(input, new StartCorporateAccountTransferHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_GSM_CORPORATE_ACCOUNT_BATCH_STARTER")
	public static GMMap startGsmCorporateAccountTransfer(GMMap input){
		input.put("BATCH_NAME", DatabaseConstants.BatchNames.GSMCorporateAccountTransferBatch);
		input.put("TRANSFER_TYPE", DatabaseConstants.AccountTransferTypes.GSMCorporateTransfer);
		return RequestProcessor.getInstance().process(input, new StartCorporateAccountTransferHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_EKS_CORPORATE_ACCOUNT_BATCH_STARTER")
	public static GMMap startEksCorporateAccountTransfer(GMMap input){
		input.put("BATCH_NAME", DatabaseConstants.BatchNames.EKSCorporateAccountTransferBatch);
		input.put("TRANSFER_TYPE", DatabaseConstants.AccountTransferTypes.EKSCorporateTransfer);
		return RequestProcessor.getInstance().process(input, new StartCorporateAccountTransferHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_BLOCKED_ACCOUNT_BATCH_STARTER")
	public static GMMap startBlockedAccountTransfer(GMMap input){
		input.put("BATCH_NAME", DatabaseConstants.BatchNames.BlockedAccountTransferBatch);
		input.put("TRANSFER_TYPE", DatabaseConstants.AccountTransferTypes.BlockedAccountTransfer);
		input.put("FROM_ACCOUNT_TYPE", DatabaseConstants.AccountDefinitionTypes.BlockedAccount);
		return RequestProcessor.getInstance().process(input, new StartCorporateAccountTransferHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_SAME_DAY_ACCOUNT_BATCH_STARTER")
	public static GMMap startSameDayAccountTransfer(GMMap input){
		Date currentDate = new Date();
		input.put("BATCH_NAME", DatabaseConstants.BatchNames.SameDayDefinedAccountTransferBatch);
		input.put("TRANSFER_TYPE", DatabaseConstants.AccountTransferTypes.SameDayTransfer);
		input.put("INPUT_DATE", currentDate);
		input.put("PROCESS_DATE", currentDate);
		return RequestProcessor.getInstance().process(input, new StartCorporateAccountTransferHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_GAME_OF_CHANCE_ACCOUNT_BATCH_STARTER")
	public static GMMap startGameOfChanceAccountTransfer(GMMap input){
		input.put("BATCH_NAME", DatabaseConstants.BatchNames.GameOfChanceAccountTransferBatch);
		input.put("TRANSFER_TYPE", DatabaseConstants.AccountTransferTypes.GameOfChanceTransfer);
		return RequestProcessor.getInstance().process(input, new StartCorporateAccountTransferHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_ACCOUNT_EXTERNAL_BATCH_STARTER")
	public static GMMap startAccountTransferExternal(GMMap input){
		return RequestProcessor.getInstance().process(input, new StartCorporateAccountTransferHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_CORPORATE_ACCOUNT_SAME_DAY_BATCH_STARTER")
	public static GMMap startCorporateAccountTransferSameDay(GMMap input){
		return RequestProcessor.getInstance().process(input, new SameDayCorporateAccountTransferHandler());
	}
	
	@GraymoundService("CDM_CALCULATE_TRANSFER_DATES")
	public static GMMap calculateTransferDates(GMMap input){
		return RequestProcessor.getInstance().process(input, new CalculateTransferDatesHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_CORPORATE_ACCOUNT")
	public static GMMap transferCorporateAccount(GMMap input){
		return RequestProcessor.getInstance().process(input, new TransferCorporateAccountHandler());
	}
	
	@GraymoundService("CDM_TRANSFER_CORPORATE_ACCOUNT_WRAPPER")
	public static GMMap transferCorporateAccountWrapper(GMMap input){
		GMMap output = new GMMap();
		GMMap batchRemoteSubmitRequest = new GMMap();
		if(input.getString("TRANSFER_TYPE").equals(DatabaseConstants.AccountTransferTypes.BlockedAccountTransfer)){
        	input.put("FROM_ACCOUNT_TYPE", DatabaseConstants.AccountDefinitionTypes.BlockedAccount);
        }
        batchRemoteSubmitRequest.put("INPUT_MAP", input);
        batchRemoteSubmitRequest.put("BATCH_SERVICE_NAME", "CDM_TRANSFER_CORPORATE_ACCOUNT");
        try {
			CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CDM_EXECUTE_ASYNC_BATCH_SUBMIT",
			             batchRemoteSubmitRequest);
		} catch (IOException e) {
			ExceptionHandler.convertException(e);
			output.put("MESSAGE", e.toString());
		}

        return output;
	}
	
	@GraymoundService("CDM_EXECUTE_ASYNC_BATCH_SUBMIT")
	public static GMMap executeAsyncBatchSubmit(GMMap input){
		GMMap output = new GMMap();
		
		try{
			GMMap batchInput = input.getMap("INPUT_MAP");
			String serviceName = input.getString("BATCH_SERVICE_NAME");
			
			GMServiceExecuter.executeAsync(serviceName, batchInput);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_INSERT_CORPORATE_ACCOUNT_BLOCKED_LOG")
	public static GMMap insertCorporateAccountBlockedLog(GMMap input){
		return RequestProcessor.getInstance().process(input, new InsertCorporateAccountBlockedLogHandler());
	}
	
	@GraymoundService("ICS_FINISH_FTM_PROCESS")
	public static GMMap finishFtmProcess(GMMap input){
		GMMap map = new GMMap();
		
		try{
			boolean errorExists = input.containsKey("ERROR");
			Session hibSession = CommonHelper.getHibernateSession();
			if(!errorExists){
				long processId = Long.valueOf(input.getString("READ_PROCESS_ID"));
				FileTransferLog log = (FileTransferLog)hibSession.createCriteria(FileTransferLog.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("ftmSequenceNumber", new BigDecimal(processId)))
						.uniqueResult();
				String batchSubmitId = log.getBatchSubmitId();
				CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId,
						DatabaseConstants.SubmitStatuses.SUCESSFUL, new Date(), null,
						null);
			}
			else{
				long processId = Long.valueOf(input.getString("READ_FILE_LIST", 0, "READ_PROCESS_ID"));
				FileTransferLog log = (FileTransferLog)hibSession.createCriteria(FileTransferLog.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("ftmSequenceNumber", new BigDecimal(processId)))
						.uniqueResult();
				String batchSubmitId = log.getBatchSubmitId();
				String errorMessage = input.getString("ERROR");
				CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId,
						DatabaseConstants.SubmitStatuses.FAILURE, new Date(), "0",
						"Dosya aktar�l�rken FTP'de bir hata olu�tu : " + errorMessage);
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return map;
	}
	
	@GraymoundService("CDM_INSERT_FILE_TRANSFER_LOG")
	public static GMMap insertFileTransferLog(GMMap input){
		GMMap map = new GMMap();
		
		try{
			boolean isUpdate = input.getBoolean("IS_UPDATE");
			Session hibSession = CommonHelper.getHibernateSession();
			if(isUpdate){
				Byte newStatus = Byte.valueOf(input.getString("TRANSFER_STATUS"));
				String errorCode = input.getString("ERROR_CODE", null);
				String errorDesc = input.getString("ERROR_MESSAGE", null);
				String recordOid = input.getString("RECORD_ID");
				FileTransferLog log = (FileTransferLog)hibSession.createCriteria(FileTransferLog.class)
						.add(Restrictions.eq("oid", recordOid))
						.uniqueResult();
				
				if(!StringUtil.isEmpty(errorDesc) && errorDesc.length() > 3800){
					errorDesc = errorDesc.substring(0, 3800);
				}
				
				if(input.containsKey("TOTAL_COUNT")){
					log.setTotalLineCount(input.getLong("TOTAL_COUNT"));
				}
				if(input.containsKey("TOTAL_AMOUNT")){
					log.setTotalAmount(input.getBigDecimal("TOTAL_AMOUNT"));
				}
				
				log.setTransferStatus(newStatus);
				log.setErrorCode(errorCode);
				log.setErrorDesc(errorDesc);
				
				hibSession.saveOrUpdate(log);
			}
			else{
				FileTransferLog log = new FileTransferLog();
				log.setStatus(true);
				log.setBatchName(input.getString("BATCH_NAME"));
				log.setCorporateCode(input.getString("CORPORATE_CODE"));
				log.setFileTransferId(input.getString("FILE_TRANSFER_ID"));
				log.setFtmId(input.getString("FTM_ID"));
				log.setFtmSequenceNumber(input.getBigDecimal("PROCESS_ID"));
				log.setLogDate(CommonHelper.getLongDateTimeString(new Date()));
				log.setTransferStatus(Byte.valueOf(input.getString("TRANSFER_STATUS")));
				log.setTransferType(Short.valueOf(input.getString("TRANSFER_TYPE")));
				log.setBatchSubmitId(input.getString("BATCH_SUBMIT_ID"));
				if(input.containsKey("TOTAL_COUNT")){
					log.setTotalLineCount(input.getLong("TOTAL_COUNT"));
				}
				if(input.containsKey("TOTAL_AMOUNT")){
					log.setTotalAmount(input.getBigDecimal("TOTAL_AMOUNT"));
				}
				hibSession.save(log);
				
				map.put("RECORD_ID", log.getOid());
			}
			
			hibSession.flush();
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return map;
	}
	
	@GraymoundService("FTM_CREATE_FTM_FILE_CONTENT")
	public static GMMap createFtmFileContent(GMMap input){
		GMMap output = new GMMap();
		
		try{
			BigDecimal ftmProcessId = input.getBigDecimal("FTM_PROCESS_OID");
			Session hibSession = CommonHelper.getHibernateSession();
			
			for (int i = 0; i < input.getSize("FILE_CONTENTS"); i++) {
				FtmFileContent content = new FtmFileContent();
				content.setOid(String.valueOf(i));
				content.setFtmProcessOid(ftmProcessId);
				content.setLine(input.getString("FILE_CONTENTS", i, "LINE"));
				content.setLineNumber(input.getBigDecimal("FILE_CONTENTS", i, "LINE_NUMBER"));
				
				hibSession.save(content);
			}
			
			hibSession.flush();
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_START_COMPLEX_FILE_BATCH")
	public static GMMap startComplexFileBatch(GMMap input){
		return RequestProcessor.getInstance().process(input, new StartComplexFileBatchHandler());
	}
	
	@GraymoundService("ICS_SEND_COMPLEX_FILE_BATCH")
	public static GMMap sendComplexFileBatch(GMMap input){
		return RequestProcessor.getInstance().process(input, new SendComplexFileBatch());
	}
	
	@GraymoundService("CDM_UPDATE_BALANCE_TRANSFER_INFORMATION")
	public static GMMap updateBalanceTransferInformation(GMMap input){
		return RequestProcessor.getInstance().process(input, new UpdateBalanceTransferInformationHandler());
	}
	
	@GraymoundService("CDM_QUERY_BALANCE_TRANSFER_LOG")
	public static GMMap queryBalanceTransferLog(GMMap input){
		return RequestProcessor.getInstance().process(input, new QueryBalanceTrasferLogHandler());
	}
	
	@GraymoundService("ICS_TT_RECON_DETAIL_PARSE")
	public static GMMap reconDetailParse(GMMap input){
		return RequestProcessor.getInstance().process(input, new TTSReconciliationLineParser());
	}
	
	@GraymoundService("CDM_NOTIFY_BATCH_FILE_REPORTER")
	public static GMMap notifyBatchFileReporter(GMMap input){
		return RequestProcessor.getInstance().process(input, new BatchFileReportHandler());
	}
	
	@GraymoundService("CDM_FAILED_SAF_RECORDS_REPORTER")
	public static GMMap failedSafRecordsReporter(GMMap input){
		return RequestProcessor.getInstance().process(input, new SafReporterHandler());
	}
	
	@GraymoundService("CDM_RESET_SEQUNCE_CODE")
	public static GMMap resetSequenceCode(GMMap input){
		return RequestProcessor.getInstance().process(input, new SequenceCodeResetHandler());
	}
	
	@GraymoundService("ICS_NOTIFY_PAYMENT_BATCH") 
	public static GMMap notifyPaymentBach(GMMap input){
		GMMap output = new GMMap();
		CommonHelper.callGraymoundServiceOutsideSession("ICS_NOTIFY_BEFORE_PAYMENT_BATCH", input);
		CommonHelper.callGraymoundServiceOutsideSession("ICS_NOTIFY_AFTER_PAYMENT_BATCH", input);
		return output;
	}
	
	@GraymoundService("ICS_NOTIFY_BEFORE_PAYMENT_BATCH")
	public static GMMap notifyBeforePayment(GMMap input) {
		GMMap output = new GMMap();
		try {
			notifyStandingOrders(true);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	private static String createNotifySubject(boolean isBeforePayment) {
		StringBuilder builder = new StringBuilder();
		builder.append("Aktif Bank �deme Bilgileriniz");
		return builder.toString();
	}

	private static String createNotifyContent(invoiceMain invoice, boolean isSms, boolean isBeforePayment) {
		StringBuilder builder = new StringBuilder();
		builder.append("De�erli m��terimiz, son �deme tarihi bug�n olan ");
		builder.append(CommonHelper.applyDecimalFormatWithDefaultCurrency(invoice.getAmount().toPlainString()));
		builder.append("'lik ");
		builder.append(CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(invoice.getCorporateCode()));
		builder.append(" kurumuna y�nelik borcunuz ");
		if(isBeforePayment){
			builder.append("g�n i�erisinde hesab�n�zdan tahsil edilecektir. AKT�F BANK A.�.");
		}
		else{
			builder.append("hesab�n�zdan tahsil edilmi�tir. AKT�F BANK A.�.");
		}
		return builder.toString();
	}
	
	@SuppressWarnings("unchecked")
	private static void notifyStandingOrders(boolean isBeforePayment) throws Exception {
		Date currentDate = new Date();
		String dateStr = CommonHelper.getShortDateTimeString(currentDate);
		Session session = CommonHelper.getHibernateSession();
		List<StandingOrderMain> mainList = session.createCriteria(StandingOrderMain.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("standingOrderStatus", DatabaseConstants.StandingOrderStatus.Active))
				.add(Restrictions.eq("standingOrderType", "KFT"))
				.add(Restrictions.eq(isBeforePayment ? "notifyBeforePayment" : "notifyAfterPayment", "1"))
				.list();
		
		for (StandingOrderMain main : mainList) {
			List<invoiceMain> invoiceMainList = session.createCriteria(invoiceMain.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("paymentStatus", isBeforePayment ? DatabaseConstants.PaymentStatuses.Waiting : DatabaseConstants.PaymentStatuses.Collected))
					.add(Restrictions.eq("invoiceDueDate", dateStr))
					.add(Restrictions.eq("standingOrderOid", main.getOid()))
					.list();
			
			if(invoiceMainList.size() > 0){
				StandingOrderComm comm = (StandingOrderComm) session.createCriteria(StandingOrderComm.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("standingOrderOid", main.getOid()))
						.uniqueResult();
				
				for (invoiceMain invoice : invoiceMainList) {
					try{
						if(main.getNotifyBySms().equals("1")){
							if(!StringUtil.isEmpty(comm.getPhoneNumber())){
								CommonHelper.sendSMS(comm.getPhoneNumber(), createNotifyContent(invoice, true, isBeforePayment));
							}
							else{
								insertStandingOrderNotifyLog(invoice.getOid(), main.getOid(), comm.getOid(), "1", "Telefon bilgisi bulunamad�", currentDate, 
										DatabaseConstants.StdOrderCommProcessStatuses.UNABLE_TO_SEND, invoice.getPaymentStatus());
							}
						}
						if(main.getNotfyByEmail().equals("1")){
							if(!StringUtil.isEmpty(comm.getEMail())){
								CommonHelper.sendMail(Arrays.asList(comm.getEMail()), null, CommonHelper.getValueOfParameter("EMAIL_STANDING_ORDER_NOTIFY", "SENDER_EMAIL_ADRESS"),
										true, createNotifySubject(isBeforePayment), createNotifyContent(invoice, false, isBeforePayment));
							}
							else{
								insertStandingOrderNotifyLog(invoice.getOid(), main.getOid(), comm.getOid(), "2", "Email bilgisi bulunamad�", currentDate, 
										DatabaseConstants.StdOrderCommProcessStatuses.UNABLE_TO_SEND, invoice.getPaymentStatus());
							}
						}
						if(!main.getNotfyByEmail().equals("1") && !main.getNotifyBySms().equals("1")){
							insertStandingOrderNotifyLog(invoice.getOid(), main.getOid(), comm.getOid(), "3", "SMS veya Email ile bildirim se�ilmemi�tir.", currentDate, 
									DatabaseConstants.StdOrderCommProcessStatuses.UNABLE_TO_SEND, invoice.getPaymentStatus());
						}
					}
					catch(Exception e){
						logger.error(String.format("An exception occured while sending notification for invoice with %s id", invoice.getOid()));
						logger.error(System.currentTimeMillis(), e);
						insertStandingOrderNotifyLog(invoice.getOid(), main.getOid(), comm.getOid(), "4", 
								String.format("SMS/Email bildiriminde bir hata olu�tu : %s", e.getMessage()), currentDate, 
								DatabaseConstants.StdOrderCommProcessStatuses.UNABLE_TO_SEND, invoice.getPaymentStatus());
					}
				}
			}
			else{
				continue;
			}
		}
	}

	@GraymoundService("ICS_NOTIFY_AFTER_PAYMENT_BATCH")
	public static GMMap notifyAfterPayment(GMMap input) {
		GMMap output = new GMMap();
		try {
			notifyStandingOrders(false);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	private static String insertStandingOrderNotifyLog(String invoiceMainOid, String standingOrderOid, String commOid, String errorCode, String errorDesc, Date processDate,
			String processStatus, String paymentStatus) throws Exception {
		GMMap standingOrderNotifyProcessLogInputMap=new GMMap();
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.STATUS, true);
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.INVOICE_MAIN_OID, invoiceMainOid);
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.STANDING_ORDER_OID,standingOrderOid);
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.STANDING_ORDER_COMM_OID, commOid);
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.ERROR_CODE, errorCode);
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.ERROR_DESC, errorDesc);
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.PROCESS_DATE, CommonHelper.getLongDateTimeString(processDate));
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.PROCESS_STATUS, processStatus);
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.IS_UPDATE, false);
		standingOrderNotifyProcessLogInputMap.put(TransactionConstants.StandingOrderNotifyProcesLog.Input.PAYMENT_STATUS, paymentStatus);
		
		GMMap output = CommonHelper.callGraymoundServiceOutsideSession("ICS_STANDING_ORDER_NOTIFY_LOG_INSERT", standingOrderNotifyProcessLogInputMap);
		
		return output.getString(TransactionConstants.StandingOrderNotifyProcesLog.Output.STANDING_ORDER_NOTIFY_PROCESS_LOG_OID);
	}
	
	@GraymoundService("CPS_WEEKLY_DETAIL_TRANSACTION_REPORT_SERVICE")
	public static GMMap weeklyDetailTransactionReport(GMMap input) {
		Date currentDate = new Date();
		Date startDate = CommonHelper.addDay(currentDate, -7);
		Date endDate = CommonHelper.addDay(currentDate, -1);
		
		input.put("START_DATE", CommonHelper.getShortDateTimeString(startDate));
		input.put("END_DATE", CommonHelper.getShortDateTimeString(endDate));
		input.put("RECEIPIENT_LIST_KEY", "EMAIL_RECEIPT_LIST_4_WEEKLY_DETAIL_REPORT");
		input.put("SUBJECT", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "WEEKLY_DETAIL_REPORT_SUBJECT"));
		input.put("CC_LIST_KEY", "EMAIL_CC_LIST_4_WEEKLY_DETAIL_REPORT");

		return RequestProcessor.getInstance().process(input, new PaymentTransactionsDetailReportHandler());
	}
	
	@GraymoundService("CPS_MONTHLY_DETAIL_TRANSACTION_REPORT_SERVICE")
	public static GMMap monthlyDetailTransactionReport(GMMap input) {
		Date currentDate = new Date();
		Date startDate = CommonHelper.addMonth(currentDate, -1);
		Date endDate = CommonHelper.addDay(currentDate, -1);
		
		input.put("START_DATE", CommonHelper.getShortDateTimeString(startDate));
		input.put("END_DATE", CommonHelper.getShortDateTimeString(endDate));
		input.put("RECEIPIENT_LIST_KEY", "EMAIL_RECEIPT_LIST_4_MONTHLY_DETAIL_REPORT");
		input.put("SUBJECT", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "MONTHLY_DETAIL_REPORT_SUBJECT"));
		input.put("CC_LIST_KEY", "EMAIL_CC_LIST_4_MONTHLY_DETAIL_REPORT");
		
		return RequestProcessor.getInstance().process(input, new PaymentTransactionsDetailReportHandler());
	}
	
	@GraymoundService("ICS_CHECK_STANDING_ORDER_BILLS")
	public static GMMap checkStandingOrderBills(GMMap input){
		return RequestProcessor.getInstance().process(input, new CheckStandingOrderBillsHandler());
	}
	
	@GraymoundService("ICS_PROCESS_STANDING_ORDER_BACKLOG")
	public static GMMap processStandingOrderBacklog(GMMap input){
		return RequestProcessor.getInstance().process(input, new ProcessStandingOrderBacklogHandler());
	}
	
	@GraymoundService("ICS_BEDAS_CHECK_SUBSCRIBER_NUMBER_CHANGE")
	public static GMMap checkSubscriberNumberChange(GMMap input){
		return RequestProcessor.getInstance().process(input, new BedasCheckSubscriberNumberChange());
	}
	
	@GraymoundService("ICS_CHECK_DUPLICATE_PAYMENTS")
	public static GMMap checkDuplicatePayments(GMMap input){
		return RequestProcessor.getInstance().process(input, new CheckDuplicatePaymentsHandler());
	}
	
	@GraymoundService("CDM_CREATE_MULTI_DAY_FILE_SERVICE")
	public static GMMap createMultiDayFileService(GMMap input){
		GMMap output = new GMMap();
		String paramOid = "";
		try{
			Session session = CommonHelper.getHibernateSession();
			
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			short transferType = DatabaseConstants.TransferTypes.CollectionInform;
			String startDate = input.getString("START_DATE");
			String endDate = input.getString("END_DATE");
			
			CorporateFileTransfer transfer = (CorporateFileTransfer) session.createCriteria(CorporateFileTransfer.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("transferType", transferType))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.uniqueResult();
			
			GMMap setFieldLimitRequest = new GMMap();
			setFieldLimitRequest.put("START_DATE", startDate);
			setFieldLimitRequest.put("END_DATE", endDate);
			setFieldLimitRequest.put(MapKeys.CORPORATE_CODE, corporateCode);
			
			GMMap setFieldLimitResponse = CommonHelper.callGraymoundServiceOutsideSession("CDM_SET_FIELD_LIMITATION_PARAM", setFieldLimitRequest);
			
			paramOid = setFieldLimitResponse.getString("PARAM_OID");
			
			GMMap fileRequest = new GMMap();
			fileRequest.put("BATCH_NAME", DatabaseConstants.BatchNames.InformInvoiceCollectionBatch);
			fileRequest.put("CORPORATE_CODE", corporateCode);
			fileRequest.put("FORMAT_ID", transfer.getFormatId());
			fileRequest.put("FTM_ID", transfer.getFtmId());
			fileRequest.put("PROCESS_DATE", CommonHelper.addDay(new Date(), -1));
			fileRequest.put("INFORM_INDICATOR", GeneralConstants.INFORM_BULK_COLLECTIONS);
			fileRequest.put("FILE_TRANSFER_ID", transfer.getFileTransferId());
			fileRequest.put("TRANSFER_TYPE", transferType);
			
			GMServiceExecuter.executeNT("ICS_CORPORATE_BATCH_STARTER", fileRequest);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally{
			if(!StringUtil.isEmpty(paramOid)){
				GMServiceExecuter.executeAsync("CDM_DELETE_FIELD_LIMITATION_PARAM", new GMMap().put("OID", paramOid));
			}
		}
		
		return output;
	}
	
	@GraymoundService("CDM_DELETE_FIELD_LIMITATION_PARAM")
	public static GMMap deleteFieldLimitationParam(GMMap input){
		GMMap output = new GMMap();
		
		String oid = input.getString("OID");
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			BatchUsedParam param = (BatchUsedParam) session.createCriteria(BatchUsedParam.class)
					.add(Restrictions.eq("oid", oid))
					.uniqueResult();
			
			param.setStatus(false);
			
			session.update(param);
			
			BatchParameters batchParam = (BatchParameters) session.createCriteria(BatchParameters.class)
					.add(Restrictions.eq("oid", param.getBatchParamOid()))
					.uniqueResult();
			
			batchParam.setStatus(false);
			
			session.update(batchParam);
			session.flush();
		}
		catch(Exception e){
			logger.error(String.format("An exception occured while deleting field limitation param with %s oid", oid));
			logger.error(System.currentTimeMillis(), e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_SET_FIELD_LIMITATION_PARAM")
	public static GMMap updateFieldLimitationParam(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String startDate = input.getString("START_DATE");
			String endDate = input.getString("END_DATE");
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			
			Session session = CommonHelper.getHibernateSession();
			
			CorporateBatchProcess corporateBatchProcessResult = (CorporateBatchProcess)session.createCriteria(CorporateBatchProcess.class)
					.add(Restrictions.eq("batchName", DatabaseConstants.BatchNames.InformInvoiceCollectionBatch))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.eq("status", true))
					.uniqueResult();
			
			BatchParameters param = new BatchParameters();
			param.setStatus(true);
			param.setBatchName(DatabaseConstants.BatchNames.InformInvoiceCollectionBatch);
			param.setKeyValueDescription("AUTO_DESC");
			param.setParamKey("ALAN_KISITLAMASI");
			param.setParamKeyValue(String.format("AND PAYMENT_DATE >= %s000000 AND PAYMENT_DATE <= %s235959", startDate, endDate));
			
			session.save(param);
			
			BatchUsedParam usedParam = new BatchUsedParam();
			usedParam.setBatchParamOid(param.getOid());
			usedParam.setBatchProcessOid(corporateBatchProcessResult.getOid());
			usedParam.setCreateDate(CommonHelper.getLongDateTimeString(new Date()));
			usedParam.setCreateUser("BNSPR");
			usedParam.setStatus(true);
			
			session.save(usedParam);
			
			output.put("PARAM_OID", usedParam.getOid());
			
			session.flush();
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_CHANGE_PASSWORD_OF_DEFINED_CORPORATES")
	public static GMMap changePasswordOfDefinedCorporates(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			Date currentDate = new Date();
			
			List<CorporateBatchProcess> processList = session.createCriteria(CorporateBatchProcess.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("batchName", DatabaseConstants.BatchNames.ChangeCorporatePasswordBatch))
					.list();
			
			for (CorporateBatchProcess process : processList) {
				String batchSubmitId = "";
				try {
					int dayCount = Integer.valueOf(process.getTextParameter());
					String lastChangeDay = CommonBusinessOperations.getCorporateParameterValue(process.getCorporateCode(), "LAST_PWD_CHANGE");
					boolean shouldChange = false;
					if(!StringUtil.isEmpty(lastChangeDay)){
						Date last = CommonHelper.getDateTime(lastChangeDay, "yyyyMMdd");
						int count = (int) CommonHelper.subtractDatesToDays(currentDate, last);
						if(count >= dayCount){
							shouldChange = true;
						}
					}
					else{
						shouldChange = true;
					}
					
					if(shouldChange){
						batchSubmitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
						GMMap changePasswordRequest = new GMMap();
						CommonBusinessOperations.insertBatchSubmitLog(process.getCorporateCode(), process.getBatchName(), "-1", "-1", batchSubmitId, "ICS_CHANGE_CORPORATE_PASSWORD", 
								changePasswordRequest);
						GMMap getBatchParamsRequest = new GMMap();
						getBatchParamsRequest.put("CORPORATE_BATCH_PROCESS_OID", process.getOid());
						
						GMMap response = CommonHelper.callGraymoundServiceOutsideSession("ICS_GET_CORPORATE_BATCH_PARAMETERS", getBatchParamsRequest);
						
						String composedParameters = response.getString("COMPOSED_PARAMETERS");
						
						BatchParameterEngine engine = new BatchParameterEngine(composedParameters);
						Map<String, String> parameters = engine.getDecomposedParameters();
						
						changePasswordRequest.put("CORPORATE_CODE", process.getCorporateCode());
						
						if(parameters.containsKey("ALFABETIK_KARAKTER") && parameters.get("ALFABETIK_KARAKTER").equals("1")){
							changePasswordRequest.put("INCL_ALPHA", true);
						}
						else if(parameters.containsKey("ALFABETIK_KARAKTER") && parameters.get("ALFABETIK_KARAKTER").equals("0")){
							changePasswordRequest.put("INCL_ALPHA", false);
						}

						if(parameters.containsKey("NUMERIK_KARAKTER") && parameters.get("NUMERIK_KARAKTER").equals("1")){
							changePasswordRequest.put("INCL_NUM", true);
						}
						else if(parameters.containsKey("NUMERIK_KARAKTER") && parameters.get("NUMERIK_KARAKTER").equals("0")){
							changePasswordRequest.put("INCL_NUM", false);
						}
						
						if(parameters.containsKey("OZEL_KARAKTER") && parameters.get("OZEL_KARAKTER").equals("1")){
							changePasswordRequest.put("INCL_SPEC", true);
						}
						else if(parameters.containsKey("OZEL_KARAKTER") && parameters.get("OZEL_KARAKTER").equals("0")){
							changePasswordRequest.put("INCL_SPEC", false);
						}
						
						CommonHelper.callGraymoundServiceOutsideSession("ICS_CHANGE_CORPORATE_PASSWORD", changePasswordRequest);
						
						if(!StringUtil.isEmpty(lastChangeDay)){
							String query = "UPDATE cdm.corporate_parameters SET value=? WHERE status=1 AND corporate_code=? AND key='LAST_PWD_CHANGE'";
							CommonHelper.executeQuery(query, BnsprType.STRING, CommonHelper.getShortDateTimeString(currentDate),  
									BnsprType.STRING, process.getCorporateCode());
						}
						else{
							CorporateParameters parameter = new CorporateParameters();
							parameter.setCorporateCode(process.getCorporateCode());
							parameter.setCreateDate(CommonHelper.getShortDateTimeString(currentDate));
							parameter.setCreateUser("BNSPR");
							parameter.setKey("LAST_PWD_CHANGE");
							parameter.setStatus(true);
							parameter.setValue(CommonHelper.getShortDateTimeString(currentDate));
							
							session.save(parameter);
						}
						
						CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId, DatabaseConstants.SubmitStatuses.SUCESSFUL, currentDate, "", "");
					}
					
				} catch (Exception e) {
					logger.error(String.format("An exception occured while changing password for %s corporate", process.getCorporateCode()));
					logger.error(System.currentTimeMillis(), e);
					if(!StringUtil.isEmpty(batchSubmitId)){
						CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId, DatabaseConstants.SubmitStatuses.FAILURE, currentDate, "-1", 
								CommonHelper.getStringifiedException(e));
					}
				}
			}
			
			session.flush();
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("STO_SEND_NOTIFICATION_FOR_PASSIVE_STD_ORDERS")
	public static GMMap sendNotificationForPassiveStdOrders(GMMap input){
		GMMap output = new GMMap();
		final String TABLE_NAME = "STO_TABLE";
		try{
			Session session = CommonHelper.getHibernateSession();
			boolean anyErrorOccured = false;
			
			List<Map<Integer, String>> mailInfo = new ArrayList<Map<Integer,String>>();
			
			Date currentDate = new Date();
			
			int count = 0;
			
			long maxDays = Long.valueOf(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STO_PASSIVE_DAYS"));
			
			String query = "SELECT cm.short_code as corporate_name, iso.customer_no, som.oid as standing_order_oid, " +
					"iso.subscriber_no1, iso.subscriber_no2, iso.subscriber_no3, iso.subscriber_no4, soa.account_number " +
					"FROM sto.standing_order_main som LEFT JOIN sto.standing_order_account soa " +
					"ON som.oid = soa.standing_order_oid LEFT JOIN ics.ics_standing_orders iso " +
					"ON som.oid = iso.standing_order_oid LEFT JOIN cdm.corporate_master cm " +
					"ON iso.corporate_code = cm.corporate_code " +
					"WHERE som.status=1 AND soa.status=1 AND iso.status=1 AND cm.status=1 AND " +
					"som.standing_order_status='1' AND iso.standing_order_status='1' AND cm.corporate_activeness='A' AND " +
					"som.start_date < SYSDATE - %s AND som.standing_order_type='KFT'";
			
			GMMap list = CommonHelper.queryData(String.format(query, maxDays), TABLE_NAME);
			
			for (int i = 0; i < list.getSize(TABLE_NAME); i++) {
				Map<Integer, String> info = new HashMap<Integer, String>();
				int step = 0;
				String corporateName = list.getString(TABLE_NAME, i, "CORPORATE_NAME");
				String customerNo = list.getString(TABLE_NAME, i, "CUSTOMER_NO");
				String accountNo = list.getString(TABLE_NAME, i, "ACCOUNT_NUMBER");
				String subscriberNo = "";
				String subscriberName = "";
				String lastPaymentDate = "";
				String error = "";
				String standingOrderOid = list.getString(TABLE_NAME, i, "STANDING_ORDER_OID");
				boolean shouldSend = false;
				boolean paymentRecordFound = false;
				try {
					step = 1;
					invoicePayment payRecord = (invoicePayment) session.createCriteria(invoicePayment.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("standingOrderOid", standingOrderOid))
							.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
							.addOrder(Order.desc("paymentDate"))
							.setMaxResults(1)
							.uniqueResult();
					
					if(payRecord != null){
						paymentRecordFound = true;
						step = 2;
						Date paymentDate = CommonHelper.getDateTime(payRecord.getPaymentDate().substring(0, 8), "yyyyMMdd");
						
						lastPaymentDate = CommonHelper.getDateString(paymentDate, "dd/MM/yyyy");
						
						if(CommonHelper.subtractDatesToDays(currentDate, paymentDate) > maxDays){
							shouldSend = true;
						}
					}
					else{
						shouldSend = true;
					}
					
					if(shouldSend){
						subscriberName = payRecord == null ? "" : payRecord.getSubscriberName();
						
						step = 3;
						subscriberNo = buildSubscriberNo(list.getString(TABLE_NAME, i, "SUBSCRIBER_NO1"),
								list.getString(TABLE_NAME, i, "SUBSCRIBER_NO2"),
								list.getString(TABLE_NAME, i, "SUBSCRIBER_NO3"),
								list.getString(TABLE_NAME, i, "SUBSCRIBER_NO4"));
					}
				} catch (Exception e) {
					logger.error(String.format("An exception occured while calculating passive sto for standing order main with %s id", standingOrderOid));
					logger.error(System.currentTimeMillis(), e);
					error = getErrorMessage(step, e);
					anyErrorOccured = true;
					shouldSend = true;
				}
				
				if(shouldSend){
					info.put(0, corporateName);
					info.put(1, customerNo);
					info.put(2, accountNo);
					info.put(3, subscriberNo);
					info.put(4, subscriberName);
					info.put(5, paymentRecordFound ? lastPaymentDate : "Ba�ar�l� otomatik �deme bulunmamaktad�r.");
					info.put(6, error);
					mailInfo.add(info);
				}
			}
			
			StringBuilder email = new StringBuilder();
			email.append("<html><title></title><body>");
			
			email.append("<table border=2>");
			
			email.append("<tr>");
			
			email.append("<td><b>Kurum Ad�</b></td>");
			email.append("<td><b>M��teri Numaras�</b></td>");
			email.append("<td><b>M��teri Hesap No</b></td>");
			email.append("<td><b>Abone No</b></td>");
			email.append("<td><b>Abone Ad�</b></td>");
			email.append("<td><b>Son �denme Tarihi</b></td>");
			if(anyErrorOccured){
				email.append("<td><b>Hata</b></td>");
			}
			
			email.append("</tr>");
			
			for (Map<Integer,String> map : mailInfo) {
				count++;
				email.append("<tr>");
				
				email.append(String.format("<td>%s</td>", map.get(0)));
				email.append(String.format("<td>%s</td>", map.get(1)));
				email.append(String.format("<td>%s</td>", map.get(2)));
				email.append(String.format("<td>%s</td>", map.get(3)));
				email.append(String.format("<td>%s</td>", map.get(4)));
				email.append(String.format("<td>%s</td>", map.get(5)));
				if(anyErrorOccured){
					email.append(String.format("<td>%s</td>", map.get(6)));
				}
				
				email.append("</tr>");
			}
			
			email.append("</table>");
			
			email.append("</body></html>");
			
			logger.info(email.toString());
			
			if(count > 0){
				String subject = String.format(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "PASSIVE_STD_ORDER_NOT_SUBJ"), maxDays);
				List<String> recipients = Arrays.asList(CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "RECEIPT_LIST_4_STD_ORD_PASSIVE").split(","));
				
				CommonHelper.sendMail(recipients, null, EmailConstants.FROM_CASH_MANAGEMENT_ANALYSTS_GROUP, true, subject, email.toString());
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

	private static String getErrorMessage(int step, Exception e) {
		switch(step){
			case 1:
				return String.format("Son talimatl� �deme kayd� al�n�rken bir hata olu�tu: %s", e.getMessage());
			case 2:
				return String.format("Son talimatl� �deme tarihi kar��la�t�rmas�nda bir hata olu�tu: %s", e.getMessage());
			case 3:
				return String.format("Abone numaralar� birle�tirilirken bir hata olu�tu: %s", e.getMessage());
			default:
				return String.format("Bilinmeyen bir ad�mda hata olu�tu: %s", e.getMessage());
		}
	}

	private static String buildSubscriberNo(String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4) {
		StringBuilder builder = new StringBuilder();
		
		boolean hasAddedBefore = false;
		
		if(!StringUtil.isEmpty(subscriberNo1)){
			builder.append(subscriberNo1);
			hasAddedBefore = true;
		}
		
		if(!StringUtil.isEmpty(subscriberNo2)){
			if(hasAddedBefore){
				builder.append("-");
			}
			builder.append(subscriberNo2);
			hasAddedBefore = true;
		}
		
		if(!StringUtil.isEmpty(subscriberNo3)){
			if(hasAddedBefore){
				builder.append("-");
			}
			builder.append(subscriberNo3);
			hasAddedBefore = true;
		}
		
		if(!StringUtil.isEmpty(subscriberNo4)){
			if(hasAddedBefore){
				builder.append("-");
			}
			builder.append(subscriberNo4);
		}
		
		return builder.toString();
	}
	
	@GraymoundService("ICS_CONTROL_OFFLINE_CANCELLED_PAYMENTS")
	public static GMMap controlOfflineCancelledPayments(GMMap input){
		GMMap output = new GMMap();
		
		final String TABLE_NAME = "PAYMENT_TABLE";
		
		Connection connection = null;
		Statement statement = null;
		
		try{
			connection = CommonHelper.getConnection();
			statement = connection.createStatement();
			String paymentChannelFilter = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "PAYMENT_CHANNEL_FILTER");
			Date currentDate = new Date();
			
			String query = "SELECT im.oid " +
					"FROM ics.invoice_main im LEFT JOIN ics.invoice_payment ip " +
					"ON im.oid = ip.invoice_main_oid " +
					"WHERE im.status=1 AND im.payment_status='B' AND im.payment_amount != 0 AND ip.status=1 AND ip.payment_status='I' AND ip.payment_channel IN (%s) " +
					"AND ip.invoice_main_oid != '0                               ' AND ip.payment_date like '%s%%'";
			
			StringBuilder countQuery = new StringBuilder();
			
			countQuery.append(String.format("SELECT invoice_main_oid, COUNT(invoice_main_oid) AS main_count FROM ics.invoice_payment WHERE status=1 AND payment_status='T' AND payment_date like '%s%%' AND ",
					CommonHelper.getShortDateTimeString(currentDate)));
			
			countQuery.append("invoice_main_oid in (");
			
			countQuery.append(String.format(query, paymentChannelFilter, CommonHelper.getShortDateTimeString(currentDate)));
			
			countQuery.append(") GROUP BY invoice_main_oid");
			
			String updateQuery = "UPDATE ics.invoice_main SET payment_amount = 0 WHERE oid = '%s'";
			
			GMMap list = DALUtil.getResults(String.format(query, paymentChannelFilter, CommonHelper.getShortDateTimeString(currentDate)), TABLE_NAME);
			
			GMMap countList = DALUtil.getResults(countQuery.toString(), TABLE_NAME);
			
			Map<String, Integer> countMap = new HashMap<String, Integer>();
			
			for (int i = 0; i < countList.getSize(TABLE_NAME); i++) {
				countMap.put(countList.getString(TABLE_NAME, i, "INVOICE_MAIN_OID"), countList.getInt(TABLE_NAME, i, "MAIN_COUNT"));
			}
			
			for (int i = 0; i < list.getSize(TABLE_NAME); i++) {
				String oid = list.getString(TABLE_NAME, i, "OID");
				
				int count = 0;
				
				if(countMap.containsKey(oid)){
					count = countMap.get(oid);
				}
				
				if(count > 1){
					continue;
				}
				else{
					statement.addBatch(String.format(updateQuery, oid));
				}
			}
			
			statement.executeBatch();
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally{
			try {
				if(statement != null){
					statement.close();
				}
				if(connection != null){
					connection.close();
				}
			} catch (SQLException e) {
				logger.error(System.currentTimeMillis(), e);
			}
		}
		
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("STO_SEND_BULK_EMAIL_INVOICES_BEFORE")
	public static GMMap sendBulkEmailInvoicesBefore(GMMap input){
		GMMap output = new GMMap();
		final String TABLE_NAME = "INVOICE_TABLE";
		try{
			Session session = CommonHelper.getHibernateSession();
			Date currentDate = new Date();
			
			List<StdBulkEmailDef> emailDefList = session.createCriteria(StdBulkEmailDef.class)
					.add(Restrictions.eq("status", true))
					.list();
			
			String emailSubject = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STO_BULK_EMAIL_BEFORE_SUBJECT");
			String from = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STO_BULK_EMAIL_BEFORE_FROM");
			
			for (StdBulkEmailDef def : emailDefList) {
				try{
					String query = String.format(QueryRepository.CPSBatchUtilitiesRepository.BULK_EMAIL_BEFORE_QUERY,
							def.getCustomerNo().toPlainString(), def.getAccountNo().toPlainString(), CommonHelper.getShortDateTimeString(currentDate));
					
					GMMap results = DALUtil.getResults(query, TABLE_NAME);
					
					if(results.getSize(TABLE_NAME) > 0){
						StringBuilder builder = new StringBuilder();
						builder.append("<html><title></title><body>");
						builder.append("De�erli M��terimiz <br />");
						builder.append("<br />");
						builder.append(String.format("%s Nolu Hesab�n�za ait %s son �deme tarihli toplam [TOTAL_AMOUNT] tutar�ndaki faturalar hesab�n�z�n m�sait olmas� durumunda g�n i�inde �denecektir.",
								def.getAccountNo().toPlainString(),
								CommonHelper.getDateString(currentDate, "dd/MM/yyyy")));
						builder.append("<br />");
						CommonHelper.fillBuilderWithTable(builder, true, "Kurum Ad�", "M��teri Hesap No", "M��teri Numaras�", "Abone No", "Abone Ad�", "Son �deme Tarihi", 
								"Fatura Tutar�");
						BigDecimal totalAmount = BigDecimal.ZERO;
						String subscriberName = "";
						for (int i = 0; i < results.getSize(TABLE_NAME); i++) {
							builder.append("<tr>");
							builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "SHORT_CODE")));
							builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "ACCOUNT_NUMBER")));
							builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "CUSTOMER_NO")));
							builder.append(String.format("<td>%s</td>", CommonHelper.concatStrings("-", 
									results.getString(TABLE_NAME, i, "SUBSCRIBER_NO1"),
									results.getString(TABLE_NAME, i, "SUBSCRIBER_NO2"),
									results.getString(TABLE_NAME, i, "SUBSCRIBER_NO3"))));
							if(StringUtil.isEmpty(subscriberName)){
								subscriberName = results.getString(TABLE_NAME, i, "SUBSCRIBER_NAME");
							}
							builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "SUBSCRIBER_NAME")));
							builder.append(String.format("<td>%s</td>", CommonHelper.formatDateString(results.getString(TABLE_NAME, i, "INVOICE_DUE_DATE"), "yyyyMMdd", "dd/MM/yyyy")));
							BigDecimal amount = results.getBigDecimal(TABLE_NAME, i, "AMOUNT");
							totalAmount = totalAmount.add(amount);
							builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(amount.toPlainString())));
							builder.append("</tr>");
						}
						
						builder.append("<tr>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td>�denecek Toplam</td>");
						builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalAmount.toPlainString())));
						builder.append("</tr>");
						
						CommonHelper.closeBuilder(builder);
						
						builder.append("</body></html>");
						
						String email = builder.toString().replace("[TOTAL_AMOUNT]", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalAmount.toPlainString()));
						
						GMMap customerNameMap=new GMMap();
						
						customerNameMap.put("MUSTERI_NO", def.getCustomerNo());
						
						customerNameMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_CUST_GET_UNVAN", customerNameMap);
						
						String subjectCustomerName=customerNameMap.getString("UNVAN");
						
						String subject = String.format(emailSubject, def.getCustomerNo().toPlainString(), subjectCustomerName, CommonHelper.getDateString(currentDate, "dd/MM/yyyy"));
						
						CommonHelper.sendMail(Arrays.asList(def.getEmail().split(",")), null, from, true, subject, email, false);
					}
					
				}
				catch(Exception e){
					logger.error(String.format("An exception occured while sending bulk email notification for %s account no", def.getAccountNo().toPlainString()));
					logger.error(System.currentTimeMillis(), e);
				}
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("STO_SEND_BULK_EMAIL_INVOICES_AFTER")
	public static GMMap sendBulkEmailInvoicesAfter(GMMap input){
		GMMap output = new GMMap();
		final String TABLE_NAME = "INVOICE_TABLE";
		
		try{
			Session session = CommonHelper.getHibernateSession();
			Date currentDate = new Date();
			
			List<StdBulkEmailDef> emailDefList = session.createCriteria(StdBulkEmailDef.class)
					.add(Restrictions.eq("status", true))
					.list();
			
			String emailSubject = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STO_BULK_EMAIL_AFTER_SUBJECT");
			String from = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "STO_BULK_EMAIL_AFTER_FROM");
			
			for (StdBulkEmailDef def : emailDefList) {
				try{
					GMMap results = DALUtil.getResults(String.format(QueryRepository.CPSBatchUtilitiesRepository.BULK_EMAIL_AFTER_QUERY,
							def.getCustomerNo().toPlainString(), def.getAccountNo().toPlainString(), CommonHelper.getShortDateTimeString(currentDate)), TABLE_NAME);
					
					if(results.getSize(TABLE_NAME) > 0){
						StringBuilder builder = new StringBuilder();
						builder.append("<html><title></title><body>");
						builder.append("De�erli M��terimiz <br />");
						builder.append("<br />");
						builder.append(String.format("%s Nolu Hesab�n�za ait %s son �deme tarihli toplam [TOTAL_AMOUNT] tutar�ndaki faturalar hesab�n�zdan �denmi�tir.",
								def.getAccountNo().toPlainString(),
								CommonHelper.getDateString(currentDate, "dd/MM/yyyy")));
						builder.append("<br />");
						CommonHelper.fillBuilderWithTable(builder, true, "Kurum Ad�", "M��teri Hesap No", "M��teri Numaras�", "Abone No", "Abone Ad�", "Son �deme Tarihi", 
								"Fatura Tutar�", "�deme Tutar�", "�deme Durumu", "Hata Mesaj�");
						BigDecimal totalAmount = BigDecimal.ZERO;
						BigDecimal totalFailedAmount = BigDecimal.ZERO;
						String subscriberName = "";
						for (int i = 0; i < results.getSize(TABLE_NAME); i++) {
							builder.append("<tr>");
							builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "SHORT_CODE")));
							builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "ACCOUNT_NUMBER")));
							builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "CUSTOMER_NO")));
							builder.append(String.format("<td>%s</td>", CommonHelper.concatStrings("-", 
									results.getString(TABLE_NAME, i, "SUBSCRIBER_NO1"),
									results.getString(TABLE_NAME, i, "SUBSCRIBER_NO2"),
									results.getString(TABLE_NAME, i, "SUBSCRIBER_NO3"))));
							if(StringUtil.isEmpty(subscriberName)){
								subscriberName = results.getString(TABLE_NAME, i, "SUBSCRIBER_NAME");
							}
							builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "SUBSCRIBER_NAME")));
							builder.append(String.format("<td>%s</td>", CommonHelper.formatDateString(results.getString(TABLE_NAME, i, "INVOICE_DUE_DATE"), "yyyyMMdd", "dd/MM/yyyy")));
							BigDecimal amount = results.getBigDecimal(TABLE_NAME, i, "AMOUNT");
							String status = results.getString(TABLE_NAME, i, "PAYMENT_STATUS");
							if(status.equals(DatabaseConstants.PaymentStatuses.Collected)){
								totalAmount = totalAmount.add(amount);
								builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(amount.toPlainString())));
								builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(amount.toPlainString())));
								builder.append("<td>�dendi.</td>");
								builder.append("<td></td>");
							}
							else if(status.equals(DatabaseConstants.PaymentStatuses.PartialCollected)){
								GMMap getInfoRequest = new GMMap();
								getInfoRequest.put("MAIN_OID", results.getString(TABLE_NAME,i,"OID"));
								getInfoRequest.put("IS_PAYMENT_AMOUNT_INFO", true);
								
								GMMap getInfoResponse = CommonHelper.callGraymoundServiceOutsideSession("STO_GET_STANDING_ORDER_DEBT_INFO", getInfoRequest);
								
								BigDecimal currentAmount = getInfoResponse.getBigDecimal("PAYMENT_AMOUNT");
								totalAmount = totalAmount.add(currentAmount);
								totalFailedAmount = totalFailedAmount.add(amount.subtract(currentAmount));
								
								builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(amount.toPlainString())));
								builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(currentAmount.toPlainString())));
								builder.append("<td>K�smi �dendi.</td>");
								builder.append("<td></td>");
							}
							else{
								GMMap getInfoRequest = new GMMap();
								getInfoRequest.put("MAIN_OID", results.getString(TABLE_NAME,i,"OID"));
								getInfoRequest.put("IS_PAYMENT_AMOUNT_INFO", false);
								
								GMMap getInfoResponse = CommonHelper.callGraymoundServiceOutsideSession("STO_GET_STANDING_ORDER_DEBT_INFO", getInfoRequest);
								
								totalFailedAmount = totalFailedAmount.add(amount);
								builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(amount.toPlainString())));
								builder.append("<td>0 TL</td>");
								builder.append("<td>�deme Hata Ald�.</td>");
								builder.append(String.format("<td>%s</td>", getInfoResponse.getString("ERROR_DESC")));
							}
							builder.append("</tr>");
						}
						
						builder.append("<tr>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td>�denemeyen Toplam</td>");
						builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalFailedAmount.toPlainString())));
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("</tr>");
						
						builder.append("<tr>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("<td>�denen Toplam</td>");
						builder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalAmount.toPlainString())));
						builder.append("<td></td>");
						builder.append("<td></td>");
						builder.append("</tr>");
						
						CommonHelper.closeBuilder(builder);
						
						builder.append("</body></html>");
						
						String email = builder.toString().replace("[TOTAL_AMOUNT]", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalAmount.toPlainString()));
						
						logger.info(email);
						
						GMMap customerNameMap=new GMMap();
						
						customerNameMap.put("MUSTERI_NO", def.getCustomerNo());
						
						customerNameMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_CUST_GET_UNVAN", customerNameMap);
						
						String subjectCustomerName=customerNameMap.getString("UNVAN");
						
						String subject = String.format(emailSubject, def.getCustomerNo().toPlainString(), subjectCustomerName, CommonHelper.getDateString(currentDate, "dd/MM/yyyy"));
						
						CommonHelper.sendMail(Arrays.asList(def.getEmail().split(",")), null, from, true, subject, email, false);
					}
					
				}
				catch(Exception e){
					logger.error(String.format("An exception occured while sending bulk email notification for %s account no", def.getAccountNo().toPlainString()));
					logger.error(System.currentTimeMillis(), e);
				}
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("STO_GET_STANDING_ORDER_DEBT_INFO")
	public static GMMap getStandingOrderDebtInfo(GMMap input){
		GMMap output = new GMMap();
		
		try{
			boolean isPaymentAmountInfo = input.getBoolean("IS_PAYMENT_AMOUNT_INFO");
			Session session = CommonHelper.getHibernateSession();
			if(isPaymentAmountInfo){
				String oid = input.getString("MAIN_OID");
				invoicePayment payment = (invoicePayment) session.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("invoiceMainOid", oid))
						.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
						.uniqueResult();
				
				if(payment != null){
					output.put("PAYMENT_AMOUNT", payment.getPaymentAmount());
				}
				else{
					CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, "�lgili �deme kayd� bulunamam��t�r.");
				}
			}
			else{
				String oid = input.getString("MAIN_OID");
				icsStdOrderProcessLog log = (icsStdOrderProcessLog) session.createCriteria(icsStdOrderProcessLog.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("invoiceMainOid", oid))
						.addOrder(Order.desc("processDate"))
						.setMaxResults(1)
						.uniqueResult();
				
				if(log != null){
					output.put("ERROR_DESC", log.getErrorDesc());
				}
				else{
					CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, "�lgili log kayd� bulunamam��t�r.");
				}
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_DEFINE_FOM_CORPORATE_FOR_RECEIPT")
	public static GMMap defineFomCorporateForReceipt(GMMap input){
		GMMap output = new GMMap();
		
		final String TABLE_NAME = "TABLE_NAME";
		
		try{
			GMMap results = DALUtil.getResults(QueryRepository.CPSBatchUtilitiesRepository.DISTINCT_YIM_CORPORATES_QUERY, TABLE_NAME);
			
			for (int i = 0; i < results.getSize(TABLE_NAME); i++) {
				String oid = results.getString(TABLE_NAME, i, "OID");
				String value = CommonHelper.getValueOfParameter("CS_KURUM_OID", oid);
				if(StringUtil.isEmpty(value)){
					CommonHelper.executeQuery(QueryRepository.CPSBatchUtilitiesRepository.INSERT_YIM_CORPORATE_FOR_RECEIPT_QUERY, 
							BnsprType.STRING, oid, 
							BnsprType.STRING, results.getString(TABLE_NAME, i, "SECTOR_CODE"), 
							BnsprType.STRING, results.getString(TABLE_NAME, i, "SHORT_CODE"));
				}
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_SEND_MAIL_FOR_UNFINISHED_PAYMENTS")
	public static GMMap sendMailForUnfinishedPayments(GMMap input){
		GMMap output = new GMMap();
		
		final String TABLE_NAME = "PAYMENT_RECORDS";
		
		try{
			Date currentDate = new Date();
			
			String query = "SELECT cm.short_code, ip.oid, ip.subscriber_no1, ip.subscriber_no2, ip.payment_amount, ip.invoice_no, cgc.aciklama " +
					"FROM ics.invoice_payment ip INNER JOIN cdm.corporate_master cm " +
					"ON ip.corporate_code = cm.corporate_code " +
					"INNER JOIN bnspr.gnl_kanal_grup_kod_pr cgc " +
					"ON ip.payment_channel = cgc.kod " +
					"WHERE ip.status=1 AND cm.status=1 AND cm.corporate_activeness = 'A' AND ip.payment_status = 'C' AND ip.payment_date like '%s%%'";
			
			GMMap results = DALUtil.getResults(String.format(query, CommonHelper.getShortDateTimeString(currentDate)), TABLE_NAME);
			
			if(results.getSize(TABLE_NAME) > 0){
				StringBuilder builder = new StringBuilder();
				builder.append("<html><title></title><body><table border=1>");
				
				builder.append("<tr>");
				builder.append("<td><b>OID</b></td>");
				builder.append("<td><b>Kurum Ad�</b></td>");
				builder.append("<td><b>Abone No 1</b></td>");
				builder.append("<td><b>Abone No 2</b></td>");
				builder.append("<td><b>�deme Tutar�</b></td>");
				builder.append("<td><b>Fatura No</b></td>");
				builder.append("<td><b>Kanal</b></td>");
				builder.append("<td><b>Durum</b></td>");
				builder.append("</tr>");
				
				for (int i = 0; i < results.getSize(TABLE_NAME); i++) {
					builder.append("<tr>");
					builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "OID")));
					builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "SHORT_CODE")));
					builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "SUBSCRIBER_NO1")));
					builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "SUBSCRIBER_NO2") == null ? "" : results.getString(TABLE_NAME, i, "SUBSCRIBER_NO2")));
					builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "PAYMENT_AMOUNT")));
					builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "INVOICE_NO")));
					builder.append(String.format("<td>%s</td>", results.getString(TABLE_NAME, i, "ACIKLAMA")));
					builder.append(String.format("<td>Bo�</td>"));
					builder.append("</tr>");
				}
				
				
				builder.append("</table></body></html>");
				
				logger.info(builder.toString());
				
				List<String> receipients = Arrays.asList(CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "RECEIPT_LIST_4_UNFINISHED_PAYMENTS").split(","));
				
				CommonHelper.sendMail(receipients, null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "Durumu Bo� Olan �demeler", builder.toString());
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_CANCEL_UNFINISHED_PAYMENTS")
	public static GMMap cancelUnfinishedPayments(GMMap input){
		GMMap output = new GMMap();
		final String TABLE_NAME = "PAYMENT_RECORDS";
		
		try{
			int checkInterval = Integer.valueOf(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "CANCEL_UNFINISHED_PAYMENTS_INTERVAL"));
			int checkHoursBefore = Integer.valueOf(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "CANCEL_UNFINISHED_PAYMENTS_BEFORE"));
		
			Date currentDate = new Date();			
			Calendar startTime = Calendar.getInstance();
			startTime.setTime(currentDate);
			startTime.add(Calendar.HOUR_OF_DAY, -1*checkHoursBefore);
			startTime.set(Calendar.MINUTE, 0);  
			startTime.set(Calendar.SECOND, 0);  
			startTime.set(Calendar.MILLISECOND, 0);
			
			Calendar endTime = Calendar.getInstance();
			endTime.setTime(startTime.getTime());
			endTime.add(Calendar.HOUR_OF_DAY, checkInterval);
			endTime.add(Calendar.SECOND, -1);
			
			String startDate = CommonHelper.getLongDateTimeString(startTime.getTime());
			String endDate = CommonHelper.getLongDateTimeString(endTime.getTime());		
			String query = "SELECT /*+ full(p) +*/p.tx_no FROM ics.invoice_payment p WHERE p.payment_status = 'C' AND status = 1 AND p.rec_date BETWEEN to_date('%s','yyyymmddhh24miss') AND to_date('%s','yyyymmddhh24miss')"; 
			
			GMMap results = DALUtil.getResults(String.format(query, startDate, endDate), TABLE_NAME);
			
			for (int i = 0; i < results.getSize(TABLE_NAME); i++) {

				GMMap cancelPaymentRequest = new GMMap();
				cancelPaymentRequest.put("TRX_NO", results.getString(TABLE_NAME, i, "TX_NO"));
				cancelPaymentRequest.put("CALL_CORPORATE", false);
				cancelPaymentRequest.put("DO_NOT_CHECK_CODE", true);
				cancelPaymentRequest.put("BYPASS_APPROVE", true);
				cancelPaymentRequest.put("IGNORE_PAYMENT", true);
				
				try{
					CommonHelper.callGraymoundServiceOutsideSession("ICS_CANCEL_PAYMENTS_BY_TRX_NO_FRONTEND", cancelPaymentRequest);
				}catch (Exception innerEx) {/*IF ERROR OCCURED WHILE REVERSE ACCOUNTING MAIL NOTIFICATION SHOULD BE SENT*/
					CommonHelper.callGraymoundServiceAsync("ICS_SEND_REVERSE_ACCOUNTING_FAIL_MAIL", input);
					CommonHelper.callGraymoundServiceOutsideSession("ICS_SAVE_REVERSE_ACCOUNTING_FAIL_ON_SAF", cancelPaymentRequest);
				}
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}