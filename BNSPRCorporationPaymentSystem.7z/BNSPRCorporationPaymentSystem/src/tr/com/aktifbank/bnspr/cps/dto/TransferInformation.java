package tr.com.aktifbank.bnspr.cps.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;

public class TransferInformation extends BaseTransferObject {

	public TransferInformation() {
		super();
		this.channelCodes = new ArrayList<String>();
		this.collectionTypes = new ArrayList<Short>();
		this.sourceCodes = new ArrayList<String>();
	}
	
	private String corporateCode;
	private Date collectionDate;
	private BigDecimal corporateAccountNo;
	private List<String> channelCodes;
	private List<Short> collectionTypes;
	private List<String> sourceCodes;
	Session hibernateSession;
	
	public List<Short> getCollectionTypes() {
		return collectionTypes;
	}
	public void setCollectionTypes(List<Short> collectionTypes) {
		this.collectionTypes = collectionTypes;
	}
	public Session getHibernateSession() {
		return hibernateSession;
	}
	public void setHibernateSession(Session hibernateSession) {
		this.hibernateSession = hibernateSession;
	}
	public String getCorporateCode() {
		return corporateCode;
	}
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	public Date getCollectionDate() {
		return collectionDate;
	}
	public void setCollectionDate(Date collectionDate) {
		this.collectionDate = collectionDate;
	}
	public BigDecimal getCorporateAccountNo() {
		return corporateAccountNo;
	}
	public void setCorporateAccountNo(BigDecimal corporateAccountNo) {
		this.corporateAccountNo = corporateAccountNo;
	}
	public List<String> getChannelCodes() {
		return channelCodes;
	}
	public void setChannelCodes(List<String> channelCodes) {
		this.channelCodes = channelCodes;
	}
	public List<String> getSourceCodes() {
		return sourceCodes;
	}
	public void setSourceCodes(List<String> sourceCodes) {
		this.sourceCodes = sourceCodes;
	}
	public void addToChannelCodes(String channelCode){
		if(!this.channelCodes.contains(channelCode)){
			this.channelCodes.add(channelCode);
		}
	}
	public void addToSourceCodes(String sourceCode){
		if(!this.sourceCodes.contains(sourceCode)){
			this.sourceCodes.add(sourceCode);
		}
	}
	public void addToCollectionTypes(Short collectionType){
		if(!this.collectionTypes.contains(collectionType)){
			this.collectionTypes.add(collectionType);
		}
	}

}
