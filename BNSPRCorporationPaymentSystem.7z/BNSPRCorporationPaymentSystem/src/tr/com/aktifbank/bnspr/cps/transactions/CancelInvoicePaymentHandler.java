package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.dao.invoicePaymentLog;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class CancelInvoicePaymentHandler extends RequestHandler {

	public CancelInvoicePaymentHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		BigDecimal transactionNo = input.getBigDecimal(TransactionConstants.CancelInvoicePayment.Input.TRX_NO);
		String corporateCode = input.getString(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_CODE);							

		String paymentDateStr = input.getString(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_DATE);
		Date paymentDate = CommonHelper.getDateTime(paymentDateStr, "yyyyMMddHHmmss");
		Date currentDate = new Date();		

		String paymentDateShortStr = CommonHelper.getShortDateTimeString(paymentDate);
		String currentDateShortStr = CommonHelper.getShortDateTimeString(currentDate);
	
		GMMap corpMap = new GMMap();
		corpMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corporateDefinitionOutput = super.callGraymoundServiceInSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, corpMap);
		
		if(!corporateDefinitionOutput.getBoolean(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_ACTIVENESS)){
			throw new BatchComponentException(BusinessException.CORPORATEISNOTACTIVE, corporateCode);
		}
		
		if (!paymentDateShortStr.equals(currentDateShortStr)) {
			CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOTVALIDCANCELPAYMENTDAY));			
		}

		insertInvoicePaymentLog(input);
		
		input.put(MapKeys.TRX_NAME, "7011");
		input.put(MapKeys.TRX_NO, transactionNo);
				
		GMMap transactionMap = super.callGraymoundServiceInSession("BNSPR_TRX_SEND_TRANSACTION", input);
		output.put("MESSAGE", transactionMap.getString("MESSAGE"));
	}

	private void insertInvoicePaymentLog(GMMap input) {
		invoicePaymentLog log = new invoicePaymentLog();
		if(input.containsKey(MapKeys.TRX_NO) && input.get(MapKeys.TRX_NO)!=null){
			BigDecimal transactionNo = input.getBigDecimal(MapKeys.TRX_NO);
			log.setTxNo(transactionNo);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.INVOICE_MAIN_OID) && input.get(TransactionConstants.CancelInvoicePayment.Input.INVOICE_MAIN_OID)!=null){
			String invoiceMainOid = input.getString(TransactionConstants.CancelInvoicePayment.Input.INVOICE_MAIN_OID);
			log.setInvoiceMainOid(invoiceMainOid);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.INVOICE_PAYMENT_OID) && input.get(TransactionConstants.CancelInvoicePayment.Input.INVOICE_PAYMENT_OID)!=null){
			String invoicePaymentOid = input.getString(TransactionConstants.CancelInvoicePayment.Input.INVOICE_PAYMENT_OID);
			log.setInvoicePaymentOid(invoicePaymentOid);
		}		
		if(input.containsKey(MapKeys.COLLECTION_TYPE) && input.get(MapKeys.COLLECTION_TYPE)!=null){
			short collectionType = Short.parseShort(input.getString(MapKeys.COLLECTION_TYPE));
			log.setCollectionType(collectionType);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_AMOUNT) && input.get(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_AMOUNT)!=null){
			BigDecimal paymentAmount = input.getBigDecimal(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_AMOUNT);
			log.setPaymentAmount(paymentAmount);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.AMOUNT) && input.get(TransactionConstants.CancelInvoicePayment.Input.AMOUNT)!=null){
			BigDecimal amount = input.getBigDecimal(TransactionConstants.CancelInvoicePayment.Input.AMOUNT);
			log.setInvoiceAmount(amount);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_ACCOUNT_NO) && input.get(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_ACCOUNT_NO)!=null){
			BigDecimal paymentAccountNo = input.getBigDecimal(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_ACCOUNT_NO, null);
			log.setPaymentAccountNo(paymentAccountNo);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.IBAN_NO) && input.get(TransactionConstants.CancelInvoicePayment.Input.IBAN_NO)!=null){
			String iban = input.getString(TransactionConstants.CancelInvoicePayment.Input.IBAN_NO, null);
			log.setIban(iban);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.ACCOUNT_BALANCE) && input.get(TransactionConstants.CancelInvoicePayment.Input.ACCOUNT_BALANCE)!=null){
			BigDecimal accountBalance = input.getBigDecimal(TransactionConstants.CancelInvoicePayment.Input.ACCOUNT_BALANCE, null);
			log.setAccountBalance(accountBalance);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_CARD_NO) && input.get(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_CARD_NO)!=null){
			String paymentCardNo = input.getString(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_CARD_NO, null);
			log.setPaymentCardNo(paymentCardNo);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_ACCOUNT_NO) && input.get(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_ACCOUNT_NO)!=null){
			BigDecimal accountNo = input.getBigDecimal(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_ACCOUNT_NO, null);
			log.setCorporateAccountNo(accountNo);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_SOURCE) && input.get(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_SOURCE)!=null){
			String sourceCode = input.getString(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_SOURCE);
			log.setSourceCode(sourceCode);
		}
		if(input.containsKey(MapKeys.CORPORATE_NAME) && input.get(MapKeys.CORPORATE_NAME)!=null){
			String corporateName = input.getString(MapKeys.CORPORATE_NAME);
			log.setCorporateName(corporateName);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.BRANCH_CODE) && input.get(TransactionConstants.CancelInvoicePayment.Input.BRANCH_CODE)!=null){
			String branchCode = input.getString(TransactionConstants.CancelInvoicePayment.Input.BRANCH_CODE);
			log.setBranchCode(branchCode);
		}
		if(input.containsKey(MapKeys.CUSTOMER_NO) && input.get(MapKeys.CUSTOMER_NO)!=null){
			BigDecimal payerCustomer = input.getBigDecimal(MapKeys.CUSTOMER_NO, null);
			log.setPayerCustomer(payerCustomer);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_PHONE) && input.get(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_PHONE)!=null){
			String payerPhone = input.getString(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_PHONE, null);
			log.setPayerPhone(payerPhone);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_ID_NO) && input.get(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_ID_NO)!=null){
			String payerPidno = input.getString(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_ID_NO, null);
			log.setPayerPidno(payerPidno);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_TAX_NO) && input.get(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_TAX_NO)!=null){
			String payerTaxNo = input.getString(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_TAX_NO, null);
			log.setPayerTaxNo(payerTaxNo);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.ACCOUNT_CURRENCY_CODE) && input.get(TransactionConstants.CancelInvoicePayment.Input.ACCOUNT_CURRENCY_CODE)!=null){
			String accountCurrencyCode = input.getString(TransactionConstants.CancelInvoicePayment.Input.ACCOUNT_CURRENCY_CODE);
			log.setAccountCurrencyCode(accountCurrencyCode);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.COLLECTION_TYPE_NAME) && input.get(TransactionConstants.CancelInvoicePayment.Input.COLLECTION_TYPE_NAME)!=null){
			String collectionName = input.getString(TransactionConstants.CancelInvoicePayment.Input.COLLECTION_TYPE_NAME);
			log.setCollectionTypeText(collectionName);
		}
		if(input.containsKey(MapKeys.INVOICE_NO) && input.get(MapKeys.INVOICE_NO)!=null){
			String invoiceNo = input.getString(MapKeys.INVOICE_NO);
			log.setInvoiceNo(invoiceNo);
		}
		if(input.containsKey(MapKeys.INVOICE_DUE_DATE) && input.get(MapKeys.INVOICE_DUE_DATE)!=null){
			String invoiceDueDate = input.getString(MapKeys.INVOICE_DUE_DATE);
			log.setInvoiceDueDate(invoiceDueDate);
		}
		if(input.containsKey(MapKeys.SUBSCRIBER_NO1) && input.get(MapKeys.SUBSCRIBER_NO1)!=null){
			String subscriberNo1 = input.getString(MapKeys.SUBSCRIBER_NO1);
			log.setSubscriberNo1(subscriberNo1);
		}
		if(input.containsKey(MapKeys.SUBSCRIBER_NO2) && input.get(MapKeys.SUBSCRIBER_NO2)!=null){
			String subscriberNo2 = input.getString(MapKeys.SUBSCRIBER_NO2);
			log.setSubscriberNo2(subscriberNo2);
		}
		if(input.containsKey(MapKeys.SUBSCRIBER_NO3) && input.get(MapKeys.SUBSCRIBER_NO3)!=null){
			String subscriberNo3 = input.getString(MapKeys.SUBSCRIBER_NO3);
			log.setSubscriberNo3(subscriberNo3);
		}
		if(input.containsKey(MapKeys.SUBSCRIBER_NO4) && input.get(MapKeys.SUBSCRIBER_NO4)!=null){
			String subscriberNo4 = input.getString(MapKeys.SUBSCRIBER_NO4);
			log.setSubscriberNo4(subscriberNo4);
		}
		if(input.containsKey(MapKeys.INVOICE_DATE) && input.get(MapKeys.INVOICE_DATE)!=null){
			String invoiceDate = input.getString(MapKeys.INVOICE_DATE);
			log.setInvoiceDate(invoiceDate);
		}
		if(input.containsKey(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_CODE) && input.get(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_CODE)!=null){
			String corporateCode = input.getString(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_CODE);
			log.setCorporateCode(corporateCode);
		}
		
		if( input.containsKey(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON_CODE) && input.get(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON_CODE) != null ){
			String rejectedReasonCode = input.getString(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON_CODE);
			log.setRejectedReasonCode(rejectedReasonCode);
		}
		
		if( input.containsKey(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON) && input.get(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON) != null ){
			String rejectedReason = input.getString(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON);
			log.setRejectedReason(rejectedReason);
		}
		
		if(input.containsKey("CASHBACK_TRX_NO") && !StringUtil.isEmpty(input.getString("CASHBACK_TRX_NO"))){
			log.setCashbackTrxNo(input.getBigDecimal("CASHBACK_TRX_NO"));
		}
		
		if(input.containsKey("CASHBACK_BRANCH_CODE") && !StringUtil.isEmpty(input.getString("CASHBACK_BRANCH_CODE"))){
			log.setCashbackBranchCode(input.getString("CASHBACK_BRANCH_CODE"));
		}
		
		if(input.containsKey("CALL_CORPORATE")){
			log.setCallCorporate(input.getBoolean("CALL_CORPORATE"));
		}
		else{
			log.setCallCorporate(true);
		}
		
		
		String channelId = CommonHelper.getChannelId();
		log.setChannelCode(channelId);
		
		log.setStatus(true);
		log.setPaymentStatus(PaymentStatuses.Cancelled);
		log.setTransactionStatus(DatabaseConstants.TransactionStatuses.New);
		
		log.setUserCode(CommonHelper.getCurrentUser());
		log.setProcessDate(CommonHelper.getLongDateTimeString(new Date()));
		log.setCancelStatus(DatabaseConstants.PaymentCancelStatuses.WaitingApproval);
		
		
		super.getHibernateSession().save(log);
		super.getHibernateSession().flush();
	}
}
