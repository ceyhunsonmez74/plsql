package tr.com.aktifbank.bnspr.cps.transactions;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CommissionDef;

import com.graymound.util.GMMap;

public final class GetCorporateCommissionDefHandler extends RequestHandler {

	public GetCorporateCommissionDefHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String channelCode = input.getString(TransactionConstants.GetCommissionDef.Input.CHANNEL_CODE);
		String corporateCode = input.getString(TransactionConstants.GetCommissionDef.Input.CORPORATE_CODE);
		
		CommissionDef commission = (CommissionDef) super.getHibernateSession().createCriteria(CommissionDef.class)
									.add(Restrictions.eq("corporateCode", corporateCode))
									.add(Restrictions.eq("channelCode", channelCode))
									.add(Restrictions.eq("status", true))
									.uniqueResult();
		if(commission != null){
			output.put(TransactionConstants.GetCommissionDef.Output.ACCOUNT_EXEMPTION, commission.getAccountExemption());
			output.put(TransactionConstants.GetCommissionDef.Output.BSMV, commission.getBsmw());
			output.put(TransactionConstants.GetCommissionDef.Output.COMMISSION, commission.getCommission());
			output.put(TransactionConstants.GetCommissionDef.Output.COMMISSION_TYPE, commission.getCommissionType());
			output.put(TransactionConstants.GetCommissionDef.Output.CUSTOMER_EXEMPTION, commission.getCustomerExemption());
			output.put(TransactionConstants.GetCommissionDef.Output.GROUP_EXEMPTION, commission.getGroupExemption());
			output.put(TransactionConstants.GetCommissionDef.Output.SEGMENT_EXEMPTION, commission.getSegmentExemption());
			output.put("OID", commission.getOid());
		}
	}

}
