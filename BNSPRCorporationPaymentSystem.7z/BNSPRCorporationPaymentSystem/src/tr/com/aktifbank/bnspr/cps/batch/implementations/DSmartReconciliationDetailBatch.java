package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.tempuri.OnlinePayment_DomainName;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.client.dsmart.DSmartClient;
import tr.com.aktifbank.integration.client.dsmart.PaymentDetailResponse;
import tr.com.aktifbank.integration.client.dsmart.ServiceMessage;

import com.graymound.util.GMMap;

public final class DSmartReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(DSmartReconciliationDetailBatch.class);
	Session session;
	List<PaymentDetailResponse> details;
	ServiceMessage message;
	Map<String, PaymentDetailResponse> indexedCorporateRecords;
	OnlinePayment_DomainName domain = OnlinePayment_DomainName.DSmart;

	public DSmartReconciliationDetailBatch(GMMap input, ServiceMessage message, OnlinePayment_DomainName domain) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, PaymentDetailResponse>();
		session = CommonHelper.getHibernateSession();
		this.domain = domain;
	}
	
	@Override
	protected void callBankReconDetail() throws Exception {
		GMMap output = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", this.input);
		reconBankMap = new GMMap();
		
		for(int i = 0 ; i < output.getSize("BANK"); i++){
			reconBankMap.put("BANK", i, MapKeys.SUBSCRIBER_NO1, output.get("BANK", i, MapKeys.SUBSCRIBER_NO1));
			reconBankMap.put("BANK", i, MapKeys.SUBSCRIBER_NO2, output.get("BANK", i, MapKeys.SUBSCRIBER_NO2));
			reconBankMap.put("BANK", i, MapKeys.PAYMENT_AMOUNT, output.get("BANK", i, MapKeys.PAYMENT_AMOUNT));
			reconBankMap.put("BANK", i, MapKeys.TRX_NO, output.get("BANK", i, MapKeys.TRX_NO));
			reconBankMap.put("BANK", i, MapKeys.INVOICE_NO, output.get("BANK", i, MapKeys.INVOICE_NO));
			reconBankMap.put("BANK", i, MapKeys.CORPORATE_CODE, output.get("BANK", i, MapKeys.CORPORATE_CODE));
			reconBankMap.put("BANK", i, MapKeys.INSTALLMENT_NO, output.get("BANK", i, MapKeys.INSTALLMENT_NO));
			reconBankMap.put("BANK", i, MapKeys.ACCOUNT_CURRENCY_CODE, output.get("BANK", i, MapKeys.ACCOUNT_CURRENCY_CODE));
			reconBankMap.put("BANK", i, MapKeys.CANCEL_DATE, output.get("BANK", i, MapKeys.CANCEL_DATE));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER1, output.get("BANK", i, MapKeys.PARAMETER1));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER2, output.get("BANK", i, MapKeys.PARAMETER2));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER3, output.get("BANK", i, MapKeys.PARAMETER3));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER4, output.get("BANK", i, MapKeys.PARAMETER4));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER5, output.get("BANK", i, MapKeys.PARAMETER5));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER6, output.get("BANK", i, MapKeys.PARAMETER6));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER7, output.get("BANK", i, MapKeys.PARAMETER7));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER8, output.get("BANK", i, MapKeys.PARAMETER8));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER9, output.get("BANK", i, MapKeys.PARAMETER9));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER10, output.get("BANK", i, MapKeys.PARAMETER10));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER11, output.get("BANK", i, MapKeys.PARAMETER11));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER12, output.get("BANK", i, MapKeys.PARAMETER12));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER13, output.get("BANK", i, MapKeys.PARAMETER13));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER14, output.get("BANK", i, MapKeys.PARAMETER14));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER15, output.get("BANK", i, MapKeys.PARAMETER15));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER16, output.get("BANK", i, MapKeys.PARAMETER16));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER17, output.get("BANK", i, MapKeys.PARAMETER17));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER18, output.get("BANK", i, MapKeys.PARAMETER18));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER19, output.get("BANK", i, MapKeys.PARAMETER19));
			reconBankMap.put("BANK", i, MapKeys.PARAMETER20, output.get("BANK", i, MapKeys.PARAMETER20));
			reconBankMap.put("BANK", i, MapKeys.PAYMENT_BRANCH, output.get("BANK", i, MapKeys.PAYMENT_BRANCH));
			reconBankMap.put("BANK", i, MapKeys.TERM_YEAR, output.get("BANK", i, MapKeys.TERM_YEAR));
			reconBankMap.put("BANK", i, MapKeys.PAYMENT_SOURCE, output.get("BANK", i, MapKeys.PAYMENT_SOURCE));
			reconBankMap.put("BANK", i, MapKeys.BRANCH_CODE, output.get("BANK", i, MapKeys.BRANCH_CODE));
			reconBankMap.put("BANK", i, MapKeys.INVOICE_DUE_DATE, output.get("BANK", i, MapKeys.INVOICE_DUE_DATE));
			reconBankMap.put("BANK", i, MapKeys.STAN_NO, output.get("BANK", i, MapKeys.STAN_NO));
		}
		
		for(int i = 0 ; i < output.getSize("BANK_CANCEL"); i++){
			reconBankMap.put("BANK_CANCEL", output.get("BANK_CANCEL"));
			
			reconBankMap.put("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1, output.get("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2, output.get("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT, output.get("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.TRX_NO, output.get("BANK_CANCEL", i, MapKeys.TRX_NO));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.INVOICE_NO, output.get("BANK_CANCEL", i, MapKeys.INVOICE_NO));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.CORPORATE_CODE, output.get("BANK_CANCEL", i, MapKeys.CORPORATE_CODE));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.INSTALLMENT_NO, output.get("BANK_CANCEL", i, MapKeys.INSTALLMENT_NO));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.ACCOUNT_CURRENCY_CODE, output.get("BANK_CANCEL", i, MapKeys.ACCOUNT_CURRENCY_CODE));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.CANCEL_DATE, output.get("BANK_CANCEL", i, MapKeys.CANCEL_DATE));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER1, output.get("BANK_CANCEL", i, MapKeys.PARAMETER1));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER2, output.get("BANK_CANCEL", i, MapKeys.PARAMETER2));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER3, output.get("BANK_CANCEL", i, MapKeys.PARAMETER3));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER4, output.get("BANK_CANCEL", i, MapKeys.PARAMETER4));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER5, output.get("BANK_CANCEL", i, MapKeys.PARAMETER5));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER6, output.get("BANK_CANCEL", i, MapKeys.PARAMETER6));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER7, output.get("BANK_CANCEL", i, MapKeys.PARAMETER7));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER8, output.get("BANK_CANCEL", i, MapKeys.PARAMETER8));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER9, output.get("BANK_CANCEL", i, MapKeys.PARAMETER9));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER10, output.get("BANK_CANCEL", i, MapKeys.PARAMETER10));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER11, output.get("BANK_CANCEL", i, MapKeys.PARAMETER11));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER12, output.get("BANK_CANCEL", i, MapKeys.PARAMETER12));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER13, output.get("BANK_CANCEL", i, MapKeys.PARAMETER13));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER14, output.get("BANK_CANCEL", i, MapKeys.PARAMETER14));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER15, output.get("BANK_CANCEL", i, MapKeys.PARAMETER15));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER16, output.get("BANK_CANCEL", i, MapKeys.PARAMETER16));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER17, output.get("BANK_CANCEL", i, MapKeys.PARAMETER17));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER18, output.get("BANK_CANCEL", i, MapKeys.PARAMETER18));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER19, output.get("BANK_CANCEL", i, MapKeys.PARAMETER19));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PARAMETER20, output.get("BANK_CANCEL", i, MapKeys.PARAMETER20));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PAYMENT_BRANCH, output.get("BANK_CANCEL", i, MapKeys.PAYMENT_BRANCH));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.TERM_YEAR, output.get("BANK_CANCEL", i, MapKeys.TERM_YEAR));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.PAYMENT_SOURCE, output.get("BANK_CANCEL", i, MapKeys.PAYMENT_SOURCE));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.BRANCH_CODE, output.get("BANK_CANCEL", i, MapKeys.BRANCH_CODE));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.INVOICE_DUE_DATE, output.get("BANK_CANCEL", i, MapKeys.INVOICE_DUE_DATE));
			reconBankMap.put("BANK_CANCEL", i, MapKeys.STAN_NO, output.get("BANK_CANCEL", i, MapKeys.STAN_NO));
		}

		reconBankMap.put(MapKeys.RECON_COLLECTION_TOTAL, output.get(MapKeys.RECON_COLLECTION_TOTAL));
		reconBankMap.put(MapKeys.RECON_COLLECTION_COUNT, output.get(MapKeys.RECON_COLLECTION_COUNT));
		reconBankMap.put(MapKeys.RECON_COLLECTION_CANCEL_COUNT, output.get(MapKeys.RECON_COLLECTION_CANCEL_COUNT));
		reconBankMap.put(MapKeys.RECON_COLLECTION_CANCEL_TOTAL, output.get(MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
	}
	
	/**RECON_COUNT CANCEL COUNT ICERDIGINDEN OVERRIDE EDILDI*/
	@Override
	public GMMap runBatch(){
		GMMap output = new GMMap();
		outputMap = output;
		logger.info("Started to run reconciliation detail batch");
		try {
			CorporateReconciliationDetailCallResult result = this.callCorporateReconDetail();
			logger.info("Corporate Recon Detail Service Result : Is Successfull : " + String.valueOf(result.isSuccessfulCall()) + " Return Code : " + result.getReturnCode());
			if(result.isSuccessfulCall()){
				logger.info("Indexing corporate records");
				this.indexCorporateRecords();
				logger.info("Calling Bank Recon Detail");
				this.callBankReconDetail();
				logger.info("Indexing bank records");
				this.indexBankRecords();
				
				int corporateRecordCount = this.details.size(); // detail corporate tarafindan gelen degerlerle doluyor
				int bankRecordCount = this.reconBankMap.getSize("BANK"); // banka tarafindan gelen degerlerle doluyor
				
				logger.info("Bank Record Count : " + String.valueOf(bankRecordCount) + " Corporate Record Count : " + String.valueOf(corporateRecordCount));
				
				if(bankRecordCount > corporateRecordCount){
					for(int i = 0; i < bankRecordCount; i++){
						boolean found = this.doesBankRecordExistInCorporateRecords(i);
						if(!found){
							logger.info(String.format("Bank Record Not Found In Corporate Records For Bank Record Index : %s", i));
							this.onBankRecordNotFound(i);
						}
					}
				}
				else if(corporateRecordCount > bankRecordCount) {
					for(int i = 0; i < corporateRecordCount; i++){
						boolean found = this.doesCorporateRecordExistInBankRecords(i);
						if(!found){
							logger.info(String.format("Corporate Record Not Found In Bank Records For Corporate Record Index : %s", i));
							this.onCorporateRecordNotFound(i);
						}
					}
				}
				else{
					// Do nothing for equal record counts
				}
			}
			else{
				onFailedCorporateServiceCall(output, result);
			}
			output.put(MapKeys.WS_SEND_STATUS, WS_SEND_SUCCESSFUL);
		} 
		catch (Exception e) {
			onError(output, e);
		}
		finally{
			onFinally(output);
		}
		
		return output;
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getInvoiceNo());
		cancelCollectionRequest.put(MapKeys.SUBSCRIBER_NO1, details.get(corporateRecordIndex).getSubscriberNo());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String agreementDate = formatDate(input.getString(MapKeys.RECON_DATE));
		String userName = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
		String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
		String authUsername = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
		String authPassword = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		int bankCode = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
		details = DSmartClient.paymentAllListDetail(url, bankCode, agreementDate, this.domain, userName, password, this.message, authUsername, authPassword);
		result.setSuccessfulCall(true);
		return result;
	}

	private String formatDate(String str) {
		String returnDate="";
		try {
			returnDate=CommonHelper.getDateString(CommonHelper.getDateTime(str, "yyyyMMdd"), "yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return returnDate;
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getInvoiceNo(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getInvoiceNo());
	}
	
	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getInvoiceNo());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		PaymentDetailResponse corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Subscriber No : %s, Fatura Kodu : %s, Miktar : %s ", 
				corporateDetail.getSubscriberNo(), 
				corporateDetail.getInvoiceNo(), 
				corporateDetail.getAmount()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(corporateDetail.getSubscriberNo());
		payment.setInvoiceNo(corporateDetail.getInvoiceNo());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getAmount()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getAmount()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getSubscriberNo());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getInvoiceNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getAmount());
	}
}
