package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileBatchInformation;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class InformInvoiceCollectionFileBatch extends OutgoingFileBatch {

	protected static final String tableName = "PAYMENTS";
	
	public InformInvoiceCollectionFileBatch(
			OutgoingFileBatchInformation information) {
		super(information);
	}

	@Override
	protected Object getRecords() throws Throwable {
		Date processDate = super.getInformation().getProcessDate();
		StringBuilder query = new StringBuilder();
		query.append("SELECT * ");
		query.append("FROM ics.invoice_payment ip ");
		query.append(String.format("WHERE ip.status=1 AND ip.corporate_code = '%s' AND ip.payment_status = '%s' AND (ip.payment_date LIKE '%s%%'", 
				super.getInformation().getCorporateCode(), 
				DatabaseConstants.PaymentStatuses.Collected,
				CommonHelper.getShortDateTimeString(processDate)));
		if(super.getInformation().isProcessWeekend()){
			Date oneBefore = CommonHelper.addDay(processDate, -1);
			Date twoBefore = CommonHelper.addDay(processDate, -2);
			query.append(String.format(" OR ip.payment_date LIKE '%s%%' OR ip.payment_date LIKE '%s%%'", 
					CommonHelper.getShortDateTimeString(oneBefore), CommonHelper.getShortDateTimeString(twoBefore)));
			
		}
		query.append(")");
		if(super.getInformation().isInformOnlyStandingOrderPayments()){
			query.append(" AND ip.STANDING_ORDER_OID is not null");
		}
		if(!StringUtil.isEmpty(super.getInformation().getFieldLimitationPattern())){
			query.append(" ");
			query.append(super.getInformation().getFieldLimitationPattern());
		}
		query.append(" ORDER BY ip.oid");
		
		return DALUtil.getResults(query.toString(), tableName);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Object getDataFromSource(String fieldName, Object records,
			int index) throws Throwable {
		GMMap paymentRecords = (GMMap)records; 
		Object data = null;
		List<HashMap<Object, Object>> mapList = (List<HashMap<Object, Object>>)paymentRecords.get(tableName);
		HashMap<Object, Object> currentIndex = mapList.get(index);
		if(currentIndex.containsKey(fieldName)){
			data = currentIndex.get(fieldName);
		}
		else{
			throw new Exception(String.format("Field %s cannot be found on both invoice payment and invoice main tables", fieldName));
		}
		return data;
	}

	@Override
	protected int getRecordsSize(Object records) throws Throwable {
		GMMap paymentRecords = (GMMap)records;
		return paymentRecords.getSize(tableName);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected GMMap getCurrentRow(Object records, int index) throws Exception {
		GMMap recordSet = (GMMap)records;
		List<HashMap<Object, Object>> recordList = (List<HashMap<Object, Object>>)recordSet.get(tableName);
		HashMap<Object, Object> currentIndex = recordList.get(index);
		return CommonHelper.convertMapToGMMap(currentIndex);
	}

}
