package tr.com.aktifbank.bnspr.cps.transactions;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.QueryBalanceTransferInformation;
import tr.com.aktifbank.bnspr.dao.BalanceTransferLog;

import com.graymound.util.GMMap;

public class QueryBalanceTrasferLogHandler extends RequestHandler{

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		String balanceTransferProcessId = input.getString(QueryBalanceTransferInformation.Input.BALANCE_TRANSFER_PROCESS_ID);
		
		BalanceTransferLog balanceTransferLog =(BalanceTransferLog) super.getHibernateSession().createCriteria(BalanceTransferLog.class)
				.add(Restrictions.eq("transferProcessOid", balanceTransferProcessId))
				.uniqueResult();
		
		if( null == balanceTransferLog ){
			logger.error("There is no data supplied by balance transfer process id value.");
		}
		
		output.put(QueryBalanceTransferInformation.Output.ACTUAL_TRANSFER_AMOUNT, balanceTransferLog.getActualAmount());
		output.put(QueryBalanceTransferInformation.Output.CONSTANT_AMOUNT,balanceTransferLog.getConstantAmount());
		output.put(QueryBalanceTransferInformation.Output.ERROR_CODE, balanceTransferLog.getErrorCode());
		output.put(QueryBalanceTransferInformation.Output.ERROR_MESSAGE,balanceTransferLog.getErrorDesc());
		output.put(QueryBalanceTransferInformation.Output.TRANSFER_STATUS,balanceTransferLog.getTransferStatus());
		
	}

}
