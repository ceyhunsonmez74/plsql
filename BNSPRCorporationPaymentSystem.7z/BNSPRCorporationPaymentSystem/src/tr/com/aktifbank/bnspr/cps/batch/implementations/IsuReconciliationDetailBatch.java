package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.isu.IsuClient;
import tr.com.aktifbank.integration.isu.ServiceMessage;
import tr.gov.isu.www.services.Dokum;

import com.graymound.util.GMMap;

public final class IsuReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(IsuReconciliationDetailBatch.class);
	public static final String BNKKD = "143";
	public static final String BNODK = "06";
	Session session;
	List<Dokum> details;
	ServiceMessage message;
	Map<String, Dokum> indexedCorporateRecords;

	public IsuReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, Dokum>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER4, details.get(corporateRecordIndex).getDekontNo());	
		cancelCollectionRequest.put(MapKeys.PARAMETER5, CommonHelper.getDateString(details.get(corporateRecordIndex).getTahsilatTarihi().getTime(), "dd/MM/yyyy HH:mm:ss"));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String subeNo = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String giseNo = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String reconDate = CommonHelper.getDateString(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			
			Dokum[] response = IsuClient.gunSonuDetayTahakkuk(url, username, password, subeNo, giseNo, reconDate, this.message);
			details = new ArrayList<Dokum>();
			for(Dokum md : response){
				if(md.getIptalTarihi() == null)
					details.add(md);
			}			
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getTahakkukNo());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(String.valueOf(this.details.get(i).getTahakkukNo()), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(String.valueOf(this.details.get(corporateRecordIndex).getTahakkukNo()));
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		Dokum corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Abone Numaras� : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getAboneNo(), 
				corporateDetail.getTahakkukNo(), 
				corporateDetail.getToplam()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(String.valueOf(corporateDetail.getAboneNo()));
		payment.setSubscriberNo2(String.valueOf(corporateDetail.getSicilNo()));
		payment.setInvoiceNo(String.valueOf(corporateDetail.getTahakkukNo()));
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal(corporateDetail.getDekontNo()));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getToplam()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getToplam()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getAboneNo());
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO2, corporateDetail.getSicilNo());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getTahakkukNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, corporateDetail.getDekontNo());
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getToplam());
	}

}
