package tr.com.aktifbank.bnspr.cps.acctransfer;

import org.hibernate.Criteria;

import tr.com.aktifbank.bnspr.cps.dto.TransferInformation;
import tr.com.aktifbank.bnspr.dao.GsmMoneyLoad;

public final class GSMCorporateAccountTransferInformation extends
	CorporateAccountTransferInformation {
	
	public GSMCorporateAccountTransferInformation(TransferInformation information) {
		super(information);
	}
	
	@Override
	protected Criteria createCriteria() {
		return this.information.getHibernateSession().createCriteria(GsmMoneyLoad.class);
	}
	
	@Override
	protected String getUpdatePart() {
		return "UPDATE ics.GSM_MONEY_LOAD ";
	}

}
