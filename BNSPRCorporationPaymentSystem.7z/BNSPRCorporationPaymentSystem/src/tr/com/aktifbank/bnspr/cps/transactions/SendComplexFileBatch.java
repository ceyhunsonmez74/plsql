package tr.com.aktifbank.bnspr.cps.transactions;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchParameterEngine;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.TransferTypes;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.ComplexBatchSubmit;
import tr.com.aktifbank.bnspr.cps.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cps.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cps.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;

import com.graymound.util.GMMap;

public final class SendComplexFileBatch extends ParallelRequestHandler {

	private static class BagKeys{
		public static final String SUBMIT_ID = "SUBMIT_ID";
		public static final String SUBMIT_STEP = "SUBMIT_STEP"; 
	}
	
	public SendComplexFileBatch() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(ComplexBatchSubmit.Input.CORPORATE_CODE);
		Date fileDate = input.getDate(ComplexBatchSubmit.Input.PROCESS_DATE, new Date());
		Date processDate = CommonHelper.addDay(fileDate, -1);
		String submitId = CorporationServiceUtil
				.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		
		input.put(ComplexBatchSubmit.Input.PROCESS_DATE, fileDate);
		
		bag.put(BagKeys.SUBMIT_ID, submitId);
		
		CommonBusinessOperations.insertBatchSubmitLog(corporateCode, 
				DatabaseConstants.BatchNames.ComplexFileSendBatch,
				null, null, submitId, "ICS_SEND_COMPLEX_FILE_BATCH", input);
		
		bag.put(BagKeys.SUBMIT_STEP, "Batch bilgileri alma");
		
		List<CorporateFileTransfer> transferList = super.getHibernateSession().createCriteria(CorporateFileTransfer.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.add(Restrictions.ne("transferType", DatabaseConstants.TransferTypes.InvoiceLoading))
				.addOrder(Order.asc("lineSequence"))
				.list();
		
		if(transferList.size() == 0){
			throw new Exception(String.format("No file transfer definition found for %s corporate", corporateCode));
		}
		
		String fileTransferId = transferList.get(0).getFileTransferId();
		BigDecimal ftmId = transferList.get(0).getFtmId();
		
		List<String> batchNames = new ArrayList<String>();
		
		for (CorporateFileTransfer transfer : transferList) {
			if(!batchNames.contains(transfer.getBatchName())){
				batchNames.add(transfer.getBatchName());
			}
		}
		
		List<CorporateBatchProcess> batchProcesses = super.getHibernateSession().createCriteria(CorporateBatchProcess.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.add(Restrictions.in("batchName", batchNames))
				.list();
		
		List<ItemDatabaseField> databaseFields = (List<ItemDatabaseField>) super
				.callServiceWithParams(
						TransactionConstants.GetDatabaseFields.SERVICE_NAME)
				.get(TransactionConstants.GetDatabaseFields.Output.FIELDS);

		List<ItemServiceField> serviceFields = (List<ItemServiceField>) super
				.callServiceWithParams(
						TransactionConstants.GetServiceFields.SERVICE_NAME)
				.get(TransactionConstants.GetServiceFields.Output.FIELDS);
		
		GMMap dbFieldsMap = new GMMap();
		for (ItemDatabaseField field : databaseFields) {
			dbFieldsMap.put(field.getOid(), field);
		}

		GMMap serviceFieldsMap = new GMMap();
		for (ItemServiceField field : serviceFields) {
			serviceFieldsMap.put(field.getOid(), field);
		}
		
		BigDecimal ftmProcessId = getNextValueOfProcessSequence();
		
		CommonBusinessOperations.updateBatchSubmitLog(submitId,
				DatabaseConstants.SubmitStatuses.EXECUTING, 
				new Date(), null, null);
		
		int lineCounter = 1;
		
		for (CorporateFileTransfer transfer : transferList) {
			CorporateBatchProcess process = null;
			for(CorporateBatchProcess loopProcess:batchProcesses){
				if(transfer.getBatchName().equals(loopProcess.getBatchName())){
					process = loopProcess;
					break;
				}
			}
			GMMap batchParameters = super.callServiceWithParams(TransactionConstants.GetBatchParameters.SERVICE_NAME, 
					TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID,
					process.getOid());
			GMMap parameterMap = new GMMap();
			if(batchParameters.containsKey(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS)){
				BatchParameterEngine engine = new BatchParameterEngine(batchParameters.getString(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS));
				parameterMap = CommonHelper.convertMapToGMMap(engine.getDecomposedParameters());
			}
			GMMap batchDetails = super.callServiceWithParams(
					TransactionConstants.GetBatchDetail.SERVICE_NAME,
					TransactionConstants.GetBatchDetail.Input.BATCH_NAME,
					process.getBatchName(),
					TransactionConstants.GetBatchDetail.Input.CORPORATE_CODE,
					corporateCode);
			List<FormatDetail> headerDetails = callFormatServices(
					TransactionConstants.GetFileHeaderFormat.SERVICE_NAME,
					transfer.getFormatId(),
					TransactionConstants.GetFileHeaderFormat.Output.HEADER_FORMATS);
			List<FormatDetail> bodyDetails = callFormatServices(
					TransactionConstants.GetFileDetailFormat.SERVICE_NAME,
					transfer.getFormatId(),
					TransactionConstants.GetFileDetailFormat.Output.DETAIL_FORMAT);
			List<FormatDetail> footerDetails = callFormatServices(
					TransactionConstants.GetFileFooterFormat.SERVICE_NAME,
					transfer.getFormatId(),
					TransactionConstants.GetFileFooterFormat.Output.FOOTER_FORMATS);
			
			GMMap complexFileSubmitMap = new GMMap();
			complexFileSubmitMap.
				put(TransactionConstants.CorporateGeneralBatchSubmit.Input.BATCH_PARAMETERS, parameterMap);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.DATABASE_FIELDS,
					dbFieldsMap);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.SERVICE_FIELDS,
					serviceFieldsMap);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.BODY_DETAILS,
					bodyDetails);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE,
					corporateCode);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.FOOTER_DETAILS,
					footerDetails);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.FTM_PROCESS_ID,
					ftmProcessId);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.HEADER_DETAILS,
					headerDetails);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE,
					processDate);
			complexFileSubmitMap.put(
					TransactionConstants.CorporateGeneralBatchSubmit.Input.INFORM_INDICATOR,
					getInformIndicator(transfer.getTransferType()));
			complexFileSubmitMap.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.LINE_NUMBER,
					lineCounter);
			
			GMMap fileSubmitOutput = super.callGraymoundServiceOutsideSession(
					batchDetails.getString(TransactionConstants.GetBatchDetail.Output.SERVICE_NAME), 
					complexFileSubmitMap);
			
			lineCounter = fileSubmitOutput.getInt(TransactionConstants.CorporateGeneralBatchSubmit.Output.AFTER_PROCESS_LINE_NUMBER);
		}
		
		GMMap insertOutput = super.callServiceWithSessionOption("CDM_INSERT_FILE_TRANSFER_LOG", false,
				"IS_UPDATE", false,
				"BATCH_NAME", DatabaseConstants.BatchNames.ComplexFileSendBatch,
				"CORPORATE_CODE", corporateCode,
				"FILE_TRANSFER_ID", fileTransferId,
				"FTM_ID", ftmId,
				"PROCESS_ID", ftmProcessId,
				"TRANSFER_STATUS", DatabaseConstants.TransferStatuses.SUBMITTED,
				"TRANSFER_TYPE", DatabaseConstants.TransferTypes.ComplexInform,
				"BATCH_SUBMIT_ID", submitId);
		
		input.put("PROCESS_DATE_DAY", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getDay(processDate)), "0", 2, true));
		input.put("PROCESS_DATE_MONTH", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getMonth(processDate)), "0", 2, true));
		input.put("PROCESS_DATE_YEAR", CommonHelper.getYear(processDate));
		input.put("PROCESS_DATE_YEAR_SHORT", String.valueOf(CommonHelper.getYear(processDate)).substring(2, 4));
		
		input.put("FILE_DATE_DAY", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getDay(fileDate)), "0", 2, true));
		input.put("FILE_DATE_MONTH", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getMonth(fileDate)), "0", 2, true));
		input.put("FILE_DATE_YEAR", CommonHelper.getYear(fileDate));
		input.put("FILE_DATE_YEAR_SHORT", String.valueOf(CommonHelper.getYear(fileDate)).substring(2, 4));
		
		try {
			callFtmForFileTransfer(input, String.valueOf(ftmId.intValue()), ftmProcessId);
		} catch (Exception e) {
			logger.error("An exception occured while calling ftm for file transfer");
			logger.error(System.currentTimeMillis(), e);
			super.callServiceWithSessionOption("CDM_INSERT_FILE_TRANSFER_LOG", false,
					"IS_UPDATE", true,
					"ERROR_CODE", "0",
					"ERROR_MESSAGE", CommonHelper.getStringifiedException(e),
					"RECORD_ID", insertOutput.getString("RECORD_ID"),
					"TRANSFER_STATUS", DatabaseConstants.TransferStatuses.SUBMITFAILURE);
			throw e;
		}
		
		CommonBusinessOperations.updateBatchSubmitLog(submitId,
				DatabaseConstants.SubmitStatuses.SUCESSFUL, 
				new Date(), null, null);		
	}
	
	private void callFtmForFileTransfer(GMMap input, String ftmId, BigDecimal ftmProcessId) throws IOException {
		input.put("FILE_DEF_ID", Long.valueOf(ftmId));
		input.put("PROCESS_ID", ftmProcessId.longValue());
		
		CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.FTM_CONNECTION_NAME, "BNSPR_FTM_CREATE_AND_TRANSFER_FILE", input);
	}

	private short getInformIndicator(Short transferType) throws Exception {
		if(TransferTypes.CollectionInform == transferType){
			return GeneralConstants.INFORM_COLLECTIONS;
		}
		else if(TransferTypes.StandingOrderCancelInform == transferType){
			return GeneralConstants.INFORM_STANDING_ORDERS_CANCEL;
		}
		else if(TransferTypes.StandingOrderInform == transferType){
			return GeneralConstants.INFORM_STANDING_ORDERS;
		}
		else{
			throw new Exception(String.format("%s transfer type has not been implemented", transferType));
		}
	}

	@Override
	protected void handleError(Throwable e, GMMap output) {
		CommonBusinessOperations.updateBatchSubmitLog((String)bag.get(BagKeys.SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, 
				new Date(), "0", String.format("%s ad�m�nda hata olu�tu : %s", 
						bag.get(BagKeys.SUBMIT_STEP), CommonHelper.getStringifiedException(e)));
		super.handleError(e, output);
	}
	
	private BigDecimal getNextValueOfProcessSequence() {
		return new BigDecimal(((Number) super.getHibernateSession()
				.createSQLQuery("SELECT ftm.seq_ftm_process.nextval FROM dual")
				.uniqueResult()).longValue());
	}
	
	private List<FormatDetail> callFormatServices(String serviceName,
			String formatOid, String outputKey) {
		GMMap formatDetails = super.callGraymoundServiceInSession(serviceName,
				new GMMap().put(TransactionConstants.FORMAT_ID_GENERAL_KEY,
						formatOid));
		@SuppressWarnings("unchecked")
		List<FormatDetail> detail = (List<FormatDetail>) formatDetails
				.get(outputKey);
		return detail;
	}
	
}
