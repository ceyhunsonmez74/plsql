package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.HashMap;
import java.util.Map;

import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.iski.client.IskiClient;
import tr.gov.iski.ths.bankaonline.webservices.BnkTalimatMutabakatDetayResponseReturn;


import com.graymound.util.GMMap;

public class IskiStandingOrderReconciliationDetailBatch extends
		StandingOrderReconciliationDetailBatch {

	private static final String STANDING_ORDER_RECONCILIATION_DETAIL_FAILED = "414"; 
	
	IskiClient client;
	BnkTalimatMutabakatDetayResponseReturn[] records;
	Map<String, BnkTalimatMutabakatDetayResponseReturn> indexedCorporateRecords;
	
	public IskiStandingOrderReconciliationDetailBatch(GMMap input, IskiClient client) {
		super(input);
		this.client = client;
		indexedCorporateRecords = new HashMap<String, BnkTalimatMutabakatDetayResponseReturn>();
	}

	@Override
	protected void setCancelStandingOrderExtraParameters(
			GMMap cancelStandingOrderRequest, int corporateRecordIndex) {
		cancelStandingOrderRequest.put(MapKeys.TRX_NO, this.records[corporateRecordIndex].getReferansNo());
		cancelStandingOrderRequest.put(MapKeys.SUBSCRIBER_NO1, this.records[corporateRecordIndex].getSozlesmeNo());
	}

	@Override
	protected void setCorporateParametersToReconProcessLogInput(
			GMMap reconProcessDataLogInput, int corporateRecordIndex) {
		reconProcessDataLogInput.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, this.records[0].getSozlesmeNo());
		reconProcessDataLogInput.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1, this.records[0].getReferansNo());
		reconProcessDataLogInput.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2, this.records[0].getTalimatNo());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()
			throws Exception {
		CorporateReconciliationDetailCallResult callResult = new CorporateReconciliationDetailCallResult();
		BnkTalimatMutabakatDetayResponseReturn[] records = this.client.getStandingOrderReconDetail(input.getDate(MapKeys.RECON_DATE));
		
		if(records.length == 1){
			if(records[0].getIslemKodu().equals(STANDING_ORDER_RECONCILIATION_DETAIL_FAILED)){
				callResult.setSuccessfulCall(false);
				callResult.setReturnCode(records[0].getIslemKodu());
			}
			else{
				callResult.setSuccessfulCall(true);
			}
		}
		else{
			callResult.setSuccessfulCall(true);
		}
		
		return callResult;
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(icsStandingOrders bankRecord) {
		return this.indexedCorporateRecords.containsKey(String.valueOf(bankRecord.getTxNo()));
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordsSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(String.valueOf(super.getBankRecordAtIndex(i).getTxNo()), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < records.length; i++) {
			this.indexedCorporateRecords.put(this.records[i].getReferansNo(), this.records[i]);
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.records[corporateRecordIndex].getReferansNo());
	}

}
