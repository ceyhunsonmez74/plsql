package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CancelStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CancelStandingOrderAccount;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CancelStandingOrderComm;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CancelStandingOrderMain;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.IcsCancelStandingOrder;
import tr.com.aktifbank.bnspr.dao.StandingOrderMainTx;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class CancelStandingOrderHandler extends RequestHandler {

	public CancelStandingOrderHandler() {
		super();
	}

	@SuppressWarnings("unused")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		GMMap outputMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String corporateCode = "";
		String subscriberNo1 = "";
		String subscriberNo2 = "";
		String subscriberNo3 = "";
		String subscriberNo4 = "";
		String collectionType = "";
		String customerNo = input.getString(MapKeys.CUSTOMER_NO);
		// /////////get inputs
		Byte orderStatus;
		String standingOrderOid = input.getString(CancelStandingOrder.Input.OID);// man
		
		int count = ((Number)super.getHibernateSession().createCriteria(StandingOrderMainTx.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("recordOid", standingOrderOid))
				.add(Restrictions.eq("txStatus", DatabaseConstants.TransactionStatuses.New))
				.setProjection(Projections.rowCount())
				.uniqueResult()).intValue();
		
		if(count > 0){
			CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, 
					"��lem yapmak istedi�iniz talimat i�in daha �nce yap�lm�� bir g�ncelleme onayda beklemektedir.");
		}
		
		String oid = input.getString(CancelStandingOrder.Input.OID);
		if(oid.contains("|~|")){
			standingOrderOid = oid.split("\\|~\\|")[0];
		}
		
		String type = input.getString(CancelStandingOrder.Input.TYPE);// man
		String trxNo = input.getString(CancelStandingOrder.Input.TRX_NO);// man
		String corporateOid = input.getString(CancelStandingOrder.Input.CORPORATE_OID, null);

		icsStandingOrders icsGetOptional = (icsStandingOrders) session.createCriteria(icsStandingOrders.class)
				.add(Restrictions.eq("standingOrderOid", standingOrderOid)).add(Restrictions.eq("status", true)).uniqueResult();

		if (icsGetOptional != null) {
			if (input.getString(CancelStandingOrder.Input.CORPORATE_CODE, null) != null) {
				corporateCode = input.getString(CancelStandingOrder.Input.CORPORATE_CODE, null);
			} else {
				corporateCode = icsGetOptional.getCorporateCode();
			}
			if (input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO1, null) != null) {
				subscriberNo1 = input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO1, null);
			} else {
				subscriberNo1 = icsGetOptional.getSubscriberNo1();
			}
			if (input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO2, null) != null) {
				subscriberNo2 = input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO2, null);
			} else {
				subscriberNo2 = icsGetOptional.getSubscriberNo2();
			}
			if (input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO3, null) != null) {
				subscriberNo3 = input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO3, null);
			} else {
				subscriberNo3 = icsGetOptional.getSubscriberNo3();
			}
			if (input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO4, null) != null) {
				subscriberNo4 = input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO4, null);
			} else {
				subscriberNo4 = icsGetOptional.getSubscriberNo4();
			}
			if (input.getString(CancelStandingOrder.Input.COLLECTION_TYPE) != null) {
				collectionType = input.getString(CancelStandingOrder.Input.COLLECTION_TYPE);
			} else {
				collectionType = String.valueOf(icsGetOptional.getCollectionType());
			}

		} else {
			corporateOid = input.getString(CancelStandingOrder.Input.CORPORATE_OID, null);
			corporateCode = input.getString(CancelStandingOrder.Input.CORPORATE_CODE, null);
			subscriberNo1 = input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO1, null);
			subscriberNo2 = input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO2, null);
			subscriberNo3 = input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO3, null);
			subscriberNo4 = input.getString(CancelStandingOrder.Input.SUBSCRIBER_NO4, null);
			collectionType = input.getString(CancelStandingOrder.Input.COLLECTION_TYPE);
		}

		if (input.containsKey("ORDER_STATUS")) {
			orderStatus = Byte.valueOf(String.valueOf(input.getInt(CancelStandingOrder.Input.ORDER_STATUS)));
		} else {
			orderStatus = null;
		}
		String orderNumber = input.getString(CancelStandingOrder.Input.ORDER_NUMBER, null);
		// /////////

		// /////////variable definitions
		String corporateActiveness = "";
		String corporateName = "";
		String bankCode = "";
		String username = "";
		String updDate = "";
		String updUser = "";
		GMMap corpDefMap = null;
		GMMap cdMap = null;
		GMMap somCancelInputMap = null;
		GMMap somCancelOutMap = null;
		GMMap commInputMap = null;
		GMMap soaCancelInputMap = null;
		GMMap soaCancelOutMap = null;
		GMMap transactionImputMap = null;
		GMMap icsOutputMap = null;
		GMMap transactionOutputMap = null;
		boolean isOnlineCorporate = false;
		// /////////

		// /////////get corporate definition to get corporateCode
		corpDefMap = new GMMap();
		if (!StringUtil.isEmpty(corporateOid)) {
			corpDefMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid);
		} else {
			corpDefMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
		}
		cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", corpDefMap);
		corporateCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
		corporateActiveness = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_ACTIVENESS);
		corporateName = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_NAME);
		if (cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.IS_ONLINE_CORPORATE).equals("1")) {
			isOnlineCorporate = true;
		} else {
			isOnlineCorporate = false;
		}
		bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
		// /////////

		if (type.equals("KFT")) {
			GMMap checkSubscriberInputMap = new GMMap();
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.BANK_CODE, bankCode);
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.CORPORATE_CODE, corporateCode);
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.OPERATION, "CANCEL");
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.COLLECTION_TYPE, collectionType);
			GMMap checkSubscriberMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_CHECK_SUBSCRIBER_PRE_STANDING_ORDER",
					checkSubscriberInputMap);
		}

		username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		updDate = CommonHelper.getLongDateTimeString(new Date());
		updUser = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();

		// /////////cancel standing order main
		somCancelInputMap = new GMMap();
		somCancelOutMap = new GMMap();
		somCancelInputMap.put(CancelStandingOrderMain.Input.ORDER_STATUS, orderStatus);
		somCancelInputMap.put(CancelStandingOrderMain.Input.TRX_NO, trxNo);
		somCancelInputMap.put(CancelStandingOrderMain.Input.TYPE, type);
		somCancelInputMap.put(CancelStandingOrderMain.Input.USER_NAME, username);
		somCancelInputMap.put(CancelStandingOrderMain.Input.STANDING_ORDER_OID, standingOrderOid);
		somCancelInputMap.put(CancelStandingOrderMain.Input.UPDATE_DATE, updDate);
		somCancelInputMap.put(CancelStandingOrderMain.Input.UPDATE_USER, updUser);
		somCancelOutMap = super.callGraymoundServiceInSession("CDM_CANCEL_STANDING_ORDER_MAIN", somCancelInputMap);

		// /////////

		// /////////cancel standing order account
		soaCancelInputMap = new GMMap();
		soaCancelOutMap = new GMMap();
		soaCancelInputMap.put(CancelStandingOrderAccount.Input.STANDING_ORDER_OID, standingOrderOid);
		soaCancelInputMap.put(CancelStandingOrderAccount.Input.UPDATE_DATE, updDate);
		soaCancelInputMap.put(CancelStandingOrderAccount.Input.UPDATE_USER, updUser);
		soaCancelInputMap.put(MapKeys.TRX_NO, trxNo);
		soaCancelOutMap = super.callGraymoundServiceInSession("CDM_CANCEL_STANDING_ORDER_ACCOUNT", soaCancelInputMap);
		// /////////

		if (type.equals("KFT")) {
			// /////////cancel ics standing order
			GMMap icsInputMap = new GMMap();
			icsInputMap.put(IcsCancelStandingOrder.Input.STANDING_ORDER_OID, standingOrderOid);
			icsInputMap.put(IcsCancelStandingOrder.Input.TRX_NO, trxNo);
			icsInputMap.put(IcsCancelStandingOrder.Input.UPDATE_DATE, updDate);
			icsInputMap.put(IcsCancelStandingOrder.Input.UPDATE_USER, updUser);
			icsInputMap.put(IcsCancelStandingOrder.Input.STANDING_ORDER_STATUS, orderStatus);
			icsOutputMap = super.callGraymoundServiceInSession("ICS_CANCEL_STANDING_ORDER", icsInputMap);
			// /////////

			// /////////cancel standing order comm
			commInputMap = new GMMap();
			commInputMap.put(CancelStandingOrderComm.Input.STANDING_ORDER_OID, standingOrderOid);
			commInputMap.put(CancelStandingOrderComm.Input.UPDATE_DATE, updDate);
			commInputMap.put(CancelStandingOrderComm.Input.UPDATE_USER, updUser);
			commInputMap.put(MapKeys.TRX_NO, trxNo);
			GMMap commOutputMap = super.callGraymoundServiceInSession("STO_CANCEL_STANDING_ORDER_COMM", commInputMap);
			// /////////

		}

		// /////////send transaction
		transactionImputMap = new GMMap();
		transactionImputMap.put(MapKeys.TRX_NAME, "7003");
		transactionImputMap.put(MapKeys.TRX_NO, trxNo);
		transactionOutputMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", transactionImputMap);
		// /////////
		
		output.put("RESULT_MSG", transactionOutputMap.getString("MESSAGE"));
		//output.put("RESULT_MSG", "TEST");

	}
}
