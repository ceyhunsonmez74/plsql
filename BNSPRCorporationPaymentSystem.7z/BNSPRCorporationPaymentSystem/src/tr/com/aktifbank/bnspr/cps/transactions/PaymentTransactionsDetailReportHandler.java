package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.EmailConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class PaymentTransactionsDetailReportHandler extends RequestHandler {

	@SuppressWarnings("unused")
	private class CorporateTransactionInfo {
		private String corporateCode;
		private String corporateOid;
		private String corporateName;
		private Map<String, TransactionInfo> transactionInfoMap;
		private BigDecimal balanceAverage;
		private String customerNumber;
		private List<String> yimCorporateCommExceptionList;
		private BigDecimal yimBankCommissionAmountPerTransaction;
		
		public BigDecimal getYimBankCommissionAmountPerTransaction() {
			return yimBankCommissionAmountPerTransaction;
		}

		public void setYimBankCommissionAmountPerTransaction(
				BigDecimal yimBankCommissionAmountPerTransaction) {
			this.yimBankCommissionAmountPerTransaction = yimBankCommissionAmountPerTransaction;
		}

		public List<String> getYimCorporateCommExceptionList() {
			return yimCorporateCommExceptionList;
		}

		public void setYimCorporateCommExceptionList(List<String> yimCorporateCommExceptionList) {
			this.yimCorporateCommExceptionList = yimCorporateCommExceptionList;
		}

		public String getCustomerNumber() {
			return customerNumber;
		}

		public void setCustomerNumber(String customerNumber) {
			this.customerNumber = customerNumber;
		}

		public CorporateTransactionInfo(){
			this.transactionInfoMap = new HashMap<String, TransactionInfo>();
			this.balanceAverage = BigDecimal.ZERO;
		}
		
		public String getCorporateOid() {
			return corporateOid;
		}

		public void setCorporateOid(String corporateOid) {
			this.corporateOid = corporateOid;
		}
		
		public BigDecimal getTotalCommissionAmount() {
			BigDecimal amount = BigDecimal.ZERO;
			
			for (TransactionInfo info : this.transactionInfoMap.values()) {
				amount = amount.add(info.getCommissionAmount());
			}
			
			return amount;
		}

		public BigDecimal getBalanceAverage() {
			return balanceAverage;
		}

		public void setBalanceAverage(BigDecimal balanceAverage) {
			this.balanceAverage = balanceAverage;
		}
		
		public String getCorporateCode() {
			return corporateCode;
		}
		public void setCorporateCode(String corporateCode) {
			this.corporateCode = corporateCode;
		}
		public String getCorporateName() {
			return corporateName;
		}
		public void setCorporateName(String corporateName) {
			this.corporateName = corporateName;
		}
		public Map<String, TransactionInfo> getTransactionInfoMap() {
			return transactionInfoMap;
		}
		
		public void addToTransactionInfoMap(String channelCode, TransactionInfo info){
			this.transactionInfoMap.put(channelCode, info);
		}
		
		public long getTotalTransactionCount(){
			long count = 0;
			
			for (TransactionInfo info : this.transactionInfoMap.values()) {
				count += info.getTransactionCount();
			}
			
			return count;
		}
		
		public BigDecimal getTotalTransactionAmount() {
			BigDecimal amount = BigDecimal.ZERO;
			
			for (TransactionInfo info : this.transactionInfoMap.values()) {
				amount = amount.add(info.getTransactionAmount());
			}
			
			return amount;
		}
		
		public BigDecimal getYimBankCommissionAmount() {
			if(this.yimCorporateCommExceptionList.contains(this.corporateCode)){
				return BigDecimal.ZERO;
			}
			else{
				TransactionInfo info = this.transactionInfoMap.get("32");
				if(info == null){
					return BigDecimal.ZERO;
				}
				else{
					return new BigDecimal(info.getTransactionCount()).multiply(this.yimBankCommissionAmountPerTransaction);
				}
			}
		}
		
	}
	
	private class TransactionInfo {
		private String channelCode;
		private long transactionCount;
		private BigDecimal transactionAmount;
		private BigDecimal commissionAmount;
		
		public BigDecimal getCommissionAmount() {
			return commissionAmount;
		}
		public void setCommissionAmount(BigDecimal commissionAmount) {
			this.commissionAmount = commissionAmount;
		}
		@SuppressWarnings("unused")
		public String getChannelCode() {
			return channelCode;
		}
		public void setChannelCode(String channelCode) {
			this.channelCode = channelCode;
		}
		public long getTransactionCount() {
			return transactionCount;
		}
		public void setTransactionCount(long transactionCount) {
			this.transactionCount = transactionCount;
		}
		public BigDecimal getTransactionAmount() {
			return transactionAmount;
		}
		public void setTransactionAmount(BigDecimal transactionAmount) {
			this.transactionAmount = transactionAmount;
		}
		
		
	}
	
	
	private static final String TABLE_NAME = "TABLE";
	private static final String OTHER_CHANNEL_CODE = "-1";
	
	public PaymentTransactionsDetailReportHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String startDate = input.getString("START_DATE");
		String endDate = input.getString("END_DATE");
		
		String detailQuery = "SELECT ip.corporate_code, cm.short_code, cm.oid, count(1) as total_count, sum(ip.payment_amount) as total_amount, " +
				"sum(ic.commission_amount) + sum(ic.bsmv_amount) as total_commission, cm.customer_number " +
				"FROM ics.invoice_payment ip LEFT JOIN cdm.corporate_master cm ON ip.corporate_code=cm.corporate_code " +
				"INNER JOIN ics.invoice_commission ic ON ip.oid=ic.invoice_payment_oid " +
				"WHERE cm.status=1 AND cm.corporate_activeness='A' AND ip.status=1 AND ip.payment_status='T' AND ip.payment_date BETWEEN '%s' AND '%s'";
		String groupAndOrderSuffix = "GROUP BY ip.corporate_code, cm.short_code, cm.oid, cm.customer_number ORDER BY cm.short_code";
		
		String channelSpecQuery = detailQuery.concat(" AND ip.payment_channel = '%s' ").concat(groupAndOrderSuffix);
		String restQuery = detailQuery.concat(" AND ip.payment_channel not in (%s) ").concat(groupAndOrderSuffix);
		
		List<String> channelList = new ArrayList<String>();
		
		channelList.add("1");
		channelList.add("4");
		channelList.add("21");
		channelList.add("32");
		
		String notInPart = "";
		int counter = 0;
		
		for (String channel : channelList) {
			notInPart = notInPart.concat(String.format("'%s'", channel));
			if(counter++ < channelList.size() - 1){
				notInPart = notInPart.concat(",");
			}
		}
		
		channelList.add(OTHER_CHANNEL_CODE);
		
		Map<String, BigDecimal> channelCommMapping = new HashMap<String, BigDecimal>();
		channelCommMapping.put("21", BigDecimal.ONE);
		channelCommMapping.put("32", new BigDecimal("1.25"));
		
		Map<String, BigDecimal> corporateCommMapping = new HashMap<String, BigDecimal>();
		corporateCommMapping.put(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "ISKI_CORPORATE_CODE").concat("32"), BigDecimal.ONE);
		
		List<String> yimBankCommissionExceptionList = Arrays.asList(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "YIM_COMM_EXC_LIST").split(","));
		BigDecimal yimBankCommAmountPerTrx = new BigDecimal(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "YIM_COMM_AMOUNT_PER_TRX"));
		
		Map<String, CorporateTransactionInfo> infoList = new HashMap<String, CorporateTransactionInfo>();
		
		for (String channel : channelList) {
			GMMap detailResults = null;
			if(!channel.equals(OTHER_CHANNEL_CODE)){
				detailResults = DALUtil.getResults(String.format(channelSpecQuery, startDate.concat("000000"), endDate.concat("235959"), channel), TABLE_NAME);
			}
			else{
				detailResults = DALUtil.getResults(String.format(restQuery, startDate.concat("000000"), endDate.concat("235959"), notInPart), TABLE_NAME);
			}
			for (int i = 0; i < detailResults.getSize(TABLE_NAME); i++) {
				String corporateOid = detailResults.getString(TABLE_NAME, i, "OID");
				String corporateCode = detailResults.getString(TABLE_NAME, i, "CORPORATE_CODE");
				String corporateName = detailResults.getString(TABLE_NAME, i, "SHORT_CODE");
				String customerNumber = detailResults.getString(TABLE_NAME, i, "CUSTOMER_NUMBER");
				long totalCount = detailResults.getInt(TABLE_NAME, i, "TOTAL_COUNT");
				BigDecimal totalAmount = detailResults.getBigDecimal(TABLE_NAME, i, "TOTAL_AMOUNT");
				BigDecimal totalCommission = detailResults.getBigDecimal(TABLE_NAME, i, "TOTAL_COMMISSION");
				
				if(totalCommission == null){
					totalCommission = BigDecimal.ZERO;
				}
				
				CorporateTransactionInfo info = null;
				
				if(infoList.containsKey(corporateCode)){
					info = infoList.get(corporateCode);
				}
				else{
					info = new CorporateTransactionInfo();
					infoList.put(corporateCode, info);
					info.setCorporateCode(corporateCode);
					info.setCorporateName(corporateName);
					info.setCorporateOid(corporateOid);
					info.setCustomerNumber(customerNumber);
					info.setYimBankCommissionAmountPerTransaction(yimBankCommAmountPerTrx);
					info.setYimCorporateCommExceptionList(yimBankCommissionExceptionList);
				}
				
				TransactionInfo trInfo = new TransactionInfo();
				trInfo.setChannelCode(channel);
				trInfo.setTransactionCount(totalCount);
				trInfo.setTransactionAmount(totalAmount == null ? BigDecimal.ZERO : totalAmount);
				
				BigDecimal comm = channelCommMapping.get(channel);
				if(comm != null){
					BigDecimal exception = corporateCommMapping.get(corporateCode.concat(channel));
					if(exception != null){
						comm = exception;
					}
					totalCommission = totalCommission.add(comm.multiply(new BigDecimal(totalCount)));
				}
				trInfo.setCommissionAmount(totalCommission);
				
				info.addToTransactionInfoMap(channel, trInfo);
			}
		}
		
		StringBuilder email = new StringBuilder();
		email.append("<html><head></head><body><table border=2>");
		email.append("<tr>");
		
		email.append("<td>");
		
		email.append(String.format("<center>Tarih Aral���<br/>%s-<br/>%s</center>", CommonHelper.formatDateString(startDate, "yyyyMMdd", "dd/MM/yyyy"), 
				CommonHelper.formatDateString(endDate, "yyyyMMdd", "dd/MM/yyyy")));
		
		email.append("</td>");
		
		email.append("<td colspan=2>");
		
		email.append("<center><b>Y�M</b></center>");
		
		email.append("</td>");
		
		email.append("<td colspan=2>");
		
		email.append("<center><b>AKT�F NOKTA</b></center>");
		
		email.append("</td>");
		
		email.append("<td colspan=2>");
		
		email.append("<center><b>�UBE</b></center>");
		
		email.append("</td>");
		
		email.append("<td colspan=2>");
		
		email.append("<center><b>�NTERNET</b></center>");
		
		email.append("</td>");
		
		email.append("<td colspan=2>");
		
		email.append("<center><b>D��ER</b></center>");
		
		email.append("</td>");
		
		email.append("<td colspan=2>");
		
		email.append("<center><b>TOPLAM</b></center>");
		
		email.append("</td>");
		
		email.append("<td>");
		
		email.append("<center><b>TOPLAM<br/>KOM�SYON<br/>TUTARI</b></center>");
		
		email.append("</td>");
		
		email.append("<td>");
		
		email.append("<center><b>TOPLAM<br/>Y�M-BANKA<br/>KOM�SYON<br/>TUTARI</b></center>");
		
		email.append("</td>");
		
		email.append("<td>");
		
		email.append("<center><b>VADES�Z<br/>ORTALAMA</b></center>");
		
		email.append("</td>");
		
		email.append("</tr>");
		
		email.append("<tr>");
		
		email.append("<td></td>");
		
		email.append("<td><b>Tahsilat Adeti</b></td><td><b>Tahsilat Tutar�</b></td>");
		
		email.append("<td><b>Tahsilat Adeti</b></td><td><b>Tahsilat Tutar�</b></td>");
		
		email.append("<td><b>Tahsilat Adeti</b></td><td><b>Tahsilat Tutar�</b></td>");
		
		email.append("<td><b>Tahsilat Adeti</b></td><td><b>Tahsilat Tutar�</b></td>");
		
		email.append("<td><b>Tahsilat Adeti</b></td><td><b>Tahsilat Tutar�</b></td>");
		
		email.append("<td><b>Toplam Tahsilat Adeti</b></td><td><b>Toplam Tahsilat Tutar�</b></td>");
		
		email.append("<td></td>");
		
		email.append("<td></td>");
		
		email.append("<td></td>");
		
		email.append("</tr>");
		
		long yimTotalTrCount = 0;
		BigDecimal yimTotalTrAmount = BigDecimal.ZERO;
		long eposTotalTrCount = 0;
		BigDecimal eposTotalTrAmount = BigDecimal.ZERO;
		long branchTotalTrCount = 0;
		BigDecimal branchTotalTrAmount = BigDecimal.ZERO;
		long internetTotalTrCount = 0;
		BigDecimal internetTotalTrAmount = BigDecimal.ZERO;
		long otherTotalTrCount = 0;
		BigDecimal otherTotalTrAmount = BigDecimal.ZERO;
		long totalTrCount = 0;
		BigDecimal totalTrAmount = BigDecimal.ZERO;
		BigDecimal totalCommAmount = BigDecimal.ZERO;
		BigDecimal totalAvgBalanceAmount = BigDecimal.ZERO;
		BigDecimal totalYimBankCommAmount = BigDecimal.ZERO;
		int coloredIndex = 0;
			for (Map.Entry<String, CorporateTransactionInfo> infoMapping : infoList.entrySet()) {
							
					if((coloredIndex % 2) == 0)
					{
						email.append("<tr ");
						email.append("bgcolor=\"");
						email.append("#00FFFF\"");
						email.append(">");				
					}
					
					else
						email.append("<tr>");
								
				CorporateTransactionInfo info = infoMapping.getValue();
				TransactionInfo yimTrInfo = info.getTransactionInfoMap().get("32");
				TransactionInfo eposTrInfo = info.getTransactionInfoMap().get("21");
				TransactionInfo branchTrInfo = info.getTransactionInfoMap().get("1");
				TransactionInfo internetTrInfo = info.getTransactionInfoMap().get("4");
				TransactionInfo otherTrInfo = info.getTransactionInfoMap().get(OTHER_CHANNEL_CODE);
				
				yimTotalTrCount += yimTrInfo == null ? 0 : yimTrInfo.getTransactionCount();
				eposTotalTrCount += eposTrInfo == null ? 0 : eposTrInfo.getTransactionCount();
				branchTotalTrCount += branchTrInfo == null ? 0 : branchTrInfo.getTransactionCount();
				internetTotalTrCount += internetTrInfo == null ? 0 : internetTrInfo.getTransactionCount();
				otherTotalTrCount += otherTrInfo == null ? 0 : otherTrInfo.getTransactionCount();
				
				yimTotalTrAmount = yimTotalTrAmount.add(yimTrInfo == null ? BigDecimal.ZERO : yimTrInfo.getTransactionAmount());
				eposTotalTrAmount = eposTotalTrAmount.add(eposTrInfo == null ? BigDecimal.ZERO : eposTrInfo.getTransactionAmount());
				branchTotalTrAmount = branchTotalTrAmount.add(branchTrInfo == null ? BigDecimal.ZERO : branchTrInfo.getTransactionAmount());
				internetTotalTrAmount = internetTotalTrAmount.add(internetTrInfo == null ? BigDecimal.ZERO : internetTrInfo.getTransactionAmount());
				otherTotalTrAmount = otherTotalTrAmount.add(otherTrInfo == null ? BigDecimal.ZERO : otherTrInfo.getTransactionAmount());
				
				long corporateTotalTrCount = info.getTotalTransactionCount();
				BigDecimal corporateTotalTrAmount = info.getTotalTransactionAmount();
				BigDecimal corporateTotalCommAmount = info.getTotalCommissionAmount();
				BigDecimal corporateYimBankCommAmount = info.getYimBankCommissionAmount();
				
				totalTrCount += corporateTotalTrCount;
				totalTrAmount = totalTrAmount.add(corporateTotalTrAmount);
				totalCommAmount = totalCommAmount.add(corporateTotalCommAmount);
				
				BigDecimal avgBalance = getAverageBalanceOfCorporate(info, startDate, endDate);
				
				totalAvgBalanceAmount = totalAvgBalanceAmount.add(avgBalance);
				
				totalYimBankCommAmount = totalYimBankCommAmount.add(corporateYimBankCommAmount);
				
				email.append(String.format("<td>%s</td>", info.getCorporateName()));
				email.append(String.format("<td>%s</td>", yimTrInfo == null ? 0 : yimTrInfo.getTransactionCount()));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(yimTrInfo == null ? BigDecimal.ZERO.toPlainString() : yimTrInfo.getTransactionAmount().toPlainString())));
				email.append(String.format("<td>%s</td>", eposTrInfo == null ? 0 : eposTrInfo.getTransactionCount()));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(eposTrInfo == null ? BigDecimal.ZERO.toPlainString() : eposTrInfo.getTransactionAmount().toPlainString())));
				email.append(String.format("<td>%s</td>", branchTrInfo == null ? 0 : branchTrInfo.getTransactionCount()));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(branchTrInfo == null ? BigDecimal.ZERO.toPlainString() : branchTrInfo.getTransactionAmount().toPlainString())));
				email.append(String.format("<td>%s</td>", internetTrInfo == null ? 0 : internetTrInfo.getTransactionCount()));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(internetTrInfo == null ? BigDecimal.ZERO.toPlainString() : internetTrInfo.getTransactionAmount().toPlainString())));
				email.append(String.format("<td>%s</td>", otherTrInfo == null ? 0 : otherTrInfo.getTransactionCount()));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(otherTrInfo == null ? BigDecimal.ZERO.toPlainString() : otherTrInfo.getTransactionAmount().toPlainString())));
				email.append(String.format("<td>%s</td>", corporateTotalTrCount));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corporateTotalTrAmount.toPlainString())));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corporateTotalCommAmount.toPlainString())));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corporateYimBankCommAmount.toPlainString())));
				email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(avgBalance.toPlainString())));
				
				email.append("</tr>");
				
				coloredIndex++;
			}
		
		email.append("<tr bgcolor=\"Yellow\">");
		
		email.append("<td><b>Genel Toplam</b></td>");
		email.append(String.format("<td>%s</td>", yimTotalTrCount));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(yimTotalTrAmount.toPlainString())));
		email.append(String.format("<td>%s</td>", eposTotalTrCount));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(eposTotalTrAmount.toPlainString())));
		email.append(String.format("<td>%s</td>", branchTotalTrCount));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(branchTotalTrAmount.toPlainString())));
		email.append(String.format("<td>%s</td>", internetTotalTrCount));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(internetTotalTrAmount.toPlainString())));
		email.append(String.format("<td>%s</td>", otherTotalTrCount));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(otherTotalTrAmount.toPlainString())));
		email.append(String.format("<td>%s</td>", totalTrCount));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalTrAmount.toPlainString())));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalCommAmount.toPlainString())));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalYimBankCommAmount.toPlainString())));
		email.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(totalAvgBalanceAmount.toPlainString())));
		
		email.append("</tr>");
		
		email.append("</table></body></html>");
		
		String receipientList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", input.getString("RECEIPIENT_LIST_KEY"));
		String ccKey = input.getString("CC_LIST_KEY", "");
		List<String> ccList = null;
		if(!StringUtil.isEmpty(ccKey)){
			String cc = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", ccKey);
			if(!StringUtil.isEmpty(cc)){
				ccList = Arrays.asList(cc.split(","));
			}
		}
		
		List<String> receipients = CommonHelper.fillReceiptList(receipientList);
	//	System.out.print(email.toString());
		CommonHelper.sendMail(receipients, ccList, EmailConstants.FROM_CASH_MANAGEMENT_ANALYSTS_GROUP, true, input.getString("SUBJECT"), email.toString(), false);
	}

	@SuppressWarnings("unchecked")
	private BigDecimal getAverageBalanceOfCorporate(CorporateTransactionInfo info, String startDate, String endDate) throws Exception {
		BigDecimal amount = BigDecimal.ZERO;
		
		Date balanceStartDate = CommonHelper.getDateTime(startDate.concat("000000"), "yyyyMMddHHmmss");
		Date balanceEndDate = CommonHelper.getDateTime(endDate.concat("235959"), "yyyyMMddHHmmss");
		
		GMMap avgBalanceRequest = new GMMap();
		avgBalanceRequest.put("BAS_TARIHI", balanceStartDate);
		avgBalanceRequest.put("BIT_TARIHI", balanceEndDate);
		avgBalanceRequest.put("HESAP_TURU", "VS");
		avgBalanceRequest.put("MUSTERI_NO_ILK", info.getCustomerNumber());
		avgBalanceRequest.put("MUSTERI_NO_SON", info.getCustomerNumber());
		avgBalanceRequest.put("SIFIR_BAKIYELER", false);
		avgBalanceRequest.put("EVAL_YAPILSIN_MI", false);
		avgBalanceRequest.put("DOVIZ_KODU", "");
		avgBalanceRequest.put("SUBE_KODU", "");
		
		GMMap avgBalanceResponse = CommonHelper.callGraymoundServiceOutsideSession("BNSPR_QRY2046_GET_AVERAGE_LIST", avgBalanceRequest);
		
		Map<BigDecimal, Integer> accountNoIndexMapping = new HashMap<BigDecimal, Integer>();
		
		for (int i = 0; i < avgBalanceResponse.getSize("RESULTS"); i++) {
			accountNoIndexMapping.put(avgBalanceResponse.getBigDecimal("RESULTS", i, "HESAP_NO"), i);
		}
		
		
		List<CorporationAccountMaster> accList = CommonHelper.getHibernateSession().createCriteria(CorporationAccountMaster.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateOid", info.getCorporateOid()))
				.add(Restrictions.eq("accountDefinitionType", DatabaseConstants.AccountDefinitionTypes.CollectionAccount))
				.list();
		
		for (CorporationAccountMaster master : accList) {
			if(!accountNoIndexMapping.containsKey(master.getAccountNumber())){
				logger.warn(String.format("%s account number info has not returned from average balance service.", master.getAccountNumber().toString()));
				continue;
			}
			Integer index = accountNoIndexMapping.get(master.getAccountNumber());
			
			amount = amount.add(avgBalanceResponse.getBigDecimal("RESULTS", index, "BAKIYE"));
		}

		return amount;
	}

}
