package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.SequenceCodeResetHandlerRepository;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public final class SequenceCodeResetHandler extends RequestHandler {

	private static final String PARAM_TABLE_NAME = "PARAM_TABLE";
	
	private static final class TimeType {
		public static final String DAY = "D";
		public static final String MONTH = "M";
		public static final String YEAR = "Y";
	}
	
	public SequenceCodeResetHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Date processDate = new Date();
		
		GMMap results = DALUtil.getResults(SequenceCodeResetHandlerRepository.FETCH_SEQ_CODES_QUERY, PARAM_TABLE_NAME);
		
		for (int i = 0; i < results.getSize(PARAM_TABLE_NAME); i++) {
			String key = results.getString(PARAM_TABLE_NAME, i, "KEY1");
			String text = results.getString(PARAM_TABLE_NAME, i, "TEXT");
			try {
				String[] commands = text.split("\\|");
				int countOfTime = Integer.valueOf(commands[0]);
				String timeType = commands[1];
				Date lastUpdated = CommonHelper.getDateTime(commands[2], "yyyyMMddHHmmss");
				boolean shouldRenew = false;
				if(timeType.equals(TimeType.DAY)){
					Date compareDate = CommonHelper.addDay(processDate, -1 * countOfTime);
					if(compareDate.compareTo(lastUpdated) > 0){
						shouldRenew = true;
					}
				}
				else if(timeType.equals(TimeType.MONTH)){
					Date compareDate = CommonHelper.addMonth(processDate, -1 * countOfTime);
					if(compareDate.compareTo(lastUpdated) > 0){
						shouldRenew = true;
					}
				}
				else if(timeType.equals(TimeType.YEAR)){
					Date compareDate = CommonHelper.addYear(processDate, -1 * countOfTime);
					if(compareDate.compareTo(lastUpdated) > 0){
						shouldRenew = true;
					}
				}
				else{
					throw new Exception(timeType.concat(" time type has not been implemented"));
				}
				
				if(shouldRenew){
					String sequenceCodeUpdateQuery = String.format(SequenceCodeResetHandlerRepository.UPDATE_SEQ_CODE_COMMAND, key);
					String paramTextUpdateQuery = String.format(SequenceCodeResetHandlerRepository.UPDATE_PARAM_TEXT_COMMAND, 
							countOfTime, timeType, CommonHelper.getLongDateTimeString(processDate), results.getString(PARAM_TABLE_NAME, i, "ID"));
					
					super.getHibernateSession().createSQLQuery(sequenceCodeUpdateQuery).executeUpdate();
					super.getHibernateSession().createSQLQuery(paramTextUpdateQuery).executeUpdate();
				}
			} catch (Exception e) {
				logger.error("An exception occured while resetting sequence code for ".concat(key));
				logger.error(System.currentTimeMillis(), e);
			}
		}
	}

}
