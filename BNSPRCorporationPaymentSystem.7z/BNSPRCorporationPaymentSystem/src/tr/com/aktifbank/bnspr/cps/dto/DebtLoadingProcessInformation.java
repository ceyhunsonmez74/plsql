package tr.com.aktifbank.bnspr.cps.dto;

import java.math.BigDecimal;
import java.util.List;

public class DebtLoadingProcessInformation extends BaseTransferObject {
	
	public DebtLoadingProcessInformation() {
		super();
	}
	
	private int threadCount;
	private int commitCount;
	private BigDecimal ftmTransferId;
	private int errorThreshold;
	private List<FormatDetail> headerDetails;
	private List<FormatDetail> bodyDetails;
	private List<FormatDetail> footerDetails;
	private List<ItemDatabaseField> databaseFields;
	private List<ItemServiceField> serviceFields;
	private String corporateCode;
	private String serviceName;
	private int totalLineCount;
	private String batchSubmitId;
	private String ftmId;
	private int controlLoopCount;
	private boolean controlInvoiceNo;
	private boolean loadOnlyStandingOrderExists;
	private boolean controlInvoiceDueDate;
	
	
	public boolean isControlInvoiceDueDate() {
		return controlInvoiceDueDate;
	}

	public void setControlInvoiceDueDate(boolean controlInvoiceDueDate) {
		this.controlInvoiceDueDate = controlInvoiceDueDate;
	}

	public List<ItemServiceField> getServiceFields() {
		return serviceFields;
	}

	public void setServiceFields(List<ItemServiceField> serviceFields) {
		this.serviceFields = serviceFields;
	}

	public boolean isControlInvoiceNo() {
		return controlInvoiceNo;
	}

	public void setControlInvoiceNo(boolean controlInvoiceNo) {
		this.controlInvoiceNo = controlInvoiceNo;
	}

	public boolean isLoadOnlyStandingOrderExists() {
		return loadOnlyStandingOrderExists;
	}

	public void setLoadOnlyStandingOrderExists(boolean loadOnlyStandingOrderExists) {
		this.loadOnlyStandingOrderExists = loadOnlyStandingOrderExists;
	}

	public int getControlLoopCount() {
		return controlLoopCount;
	}

	public void setControlLoopCount(int controlLoopCount) {
		this.controlLoopCount = controlLoopCount;
	}

	public String getFtmId() {
		return ftmId;
	}

	public void setFtmId(String ftmId) {
		this.ftmId = ftmId;
	}

	public String getBatchSubmitId() {
		return batchSubmitId;
	}

	public void setBatchSubmitId(String batchSubmitId) {
		this.batchSubmitId = batchSubmitId;
	}

	public int getTotalLineCount() {
		return totalLineCount;
	}

	public void setTotalLineCount(int totalLineCount) {
		this.totalLineCount = totalLineCount;
	}

	public BigDecimal getFtmTransferId() {
		return ftmTransferId;
	}

	public void setFtmTransferId(BigDecimal ftmTransferId) {
		this.ftmTransferId = ftmTransferId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public List<ItemDatabaseField> getDatabaseFields() {
		return databaseFields;
	}

	public void setDatabaseFields(List<ItemDatabaseField> databaseFields) {
		this.databaseFields = databaseFields;
	}
	
	public String getCorporateCode() {
		return corporateCode;
	}

	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	
	public List<FormatDetail> getHeaderDetails() {
		return headerDetails;
	}

	public void setHeaderDetails(List<FormatDetail> headerDetails) {
		this.headerDetails = headerDetails;
	}

	public List<FormatDetail> getBodyDetails() {
		return bodyDetails;
	}

	public void setBodyDetails(List<FormatDetail> bodyDetails) {
		this.bodyDetails = bodyDetails;
	}

	public List<FormatDetail> getFooterDetails() {
		return footerDetails;
	}

	public void setFooterDetails(List<FormatDetail> footerDetails) {
		this.footerDetails = footerDetails;
	}
	
	public void setErrorThreshold(int errorThreshold) {
		this.errorThreshold = errorThreshold;
	}
	
	public int getThreadCount(){
		return this.threadCount;
	}
	
	public void setThreadCount(int threadCount){
		this.threadCount = threadCount;
	}
	
	public int getCommitCount(){
		return this.commitCount;
	}
	
	public void setCommitCount(int commitCount){
		this.commitCount = commitCount;
	}

	public int getErrorThreshold() {
		return this.errorThreshold;
	}

}
