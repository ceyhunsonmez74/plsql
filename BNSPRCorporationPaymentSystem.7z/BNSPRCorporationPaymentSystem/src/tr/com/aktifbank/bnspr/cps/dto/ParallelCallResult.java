package tr.com.aktifbank.bnspr.cps.dto;

import java.util.List;

import com.graymound.util.GMMap;

public final class ParallelCallResult extends BaseTransferObject {

	public ParallelCallResult() {
		super();
	}

	private boolean allSuccessful;
	private List<GMMap> results;
	
	public boolean isAllSuccessful() {
		return allSuccessful;
	}
	public void setAllSuccessful(boolean allSuccessful) {
		this.allSuccessful = allSuccessful;
	}
	public List<GMMap> getResults() {
		return results;
	}
	public void setResults(List<GMMap> results) {
		this.results = results;
	}
	
	
}
