package tr.com.aktifbank.bnspr.cps.filetransfer.services;


import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;

import com.graymound.connection.GMConnection;
import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class FtmServices {
	
	@GraymoundService("BNSPR_FTM_GET_PROCESS_LOGS_AKUSTIK")
	public static GMMap bnsprFtmGetProcessLogs(GMMap input) {
		
		GMMap output = new GMMap();
		try {		
			//GMConnection gmConnection;
			//gmConnection = GMConnection.getConnection("FTM");
			
	        //output.putAll(gmConnection.serviceCall("BNSPR_FTM_GET_PROCESS_LOGS", input));
			System.out.println(GMConnection.class.getResource("/configuration/GMConnection.xml").getPath());
	        output = CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.FTM_CONNECTION_NAME, "BNSPR_FTM_GET_PROCESS_LOGS", input);
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}
	
	@GraymoundService("BNSPR_FTM_GET_PROCESS_DETAIL_AKUSTIK")
	public static GMMap bnsprFtmGetProcessDetail(GMMap input) {
		GMMap output = new GMMap();
		try {		
			GMConnection gmConnection;
			gmConnection = GMConnection.getConnection("FTM");
			
	        output.putAll(gmConnection.serviceCall("BNSPR_FTM_GET_PROCESS_DETAIL", input));
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}
	
	@GraymoundService("BNSPR_FTM_GET_REAL_TIME_PROCESS_AKUSTIK")
	public static GMMap bnsprFtmGetRealTimeProcess(GMMap input) {
		GMMap output = new GMMap();
		try {		
			GMConnection gmConnection;
			gmConnection = GMConnection.getConnection("FTM");
			
	        output.putAll(gmConnection.serviceCall("BNSPR_FTM_GET_REAL_TIME_PROCESS", input));
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}
	
}
