package tr.com.aktifbank.bnspr.cps.transactions;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.SectorDef;

import com.graymound.util.GMMap;

public final class GetSectorDefinitionHandler extends RequestHandler {

	public GetSectorDefinitionHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String sectorCode = input.getString(TransactionConstants.GetSectorDefinition.Input.SECTOR_CODE, null);
		String sectorId = input.getString(TransactionConstants.GetSectorDefinition.Input.SECTOR_OID, null);
		
		SectorDef sector = null;
		
		if(sectorCode != null){
			sector = (SectorDef)super.getHibernateSession().createCriteria(SectorDef.class)
					.add(Restrictions.eq("sectorCode", sectorCode))
					.add(Restrictions.eq("status", true))
					.uniqueResult();
		}
		else if(sectorId != null){
			sector = (SectorDef)super.getHibernateSession().createCriteria(SectorDef.class)
					.add(Restrictions.eq("oid", sectorId))
					.add(Restrictions.eq("status", true))
					.uniqueResult();
		}
		else{
			// TODO
		}
		
		output.put(TransactionConstants.GetSectorDefinition.Output.IS_SECTOR_ACTIVE, sector.getSectorActiveness().equals(DatabaseConstants.SectorActiveness.Active));
		output.put(TransactionConstants.GetSectorDefinition.Output.SECTOR_NAME, sector.getSectorName());
		output.put(TransactionConstants.GetSectorDefinition.Output.STATUS, sector.isStatus());
		output.put(TransactionConstants.GetSectorDefinition.Output.SECTOR_CODE, sector.getSectorCode());
		output.put(TransactionConstants.GetSectorDefinition.Output.SECTOR_OID, sector.getOid());
	}

}
