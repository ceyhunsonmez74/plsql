package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.ObjectMapper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.dao.FileFormatUtilServices;

import com.graymound.util.GMMap;

public final class GetServiceFieldsHandler extends RequestHandler {

	public GetServiceFieldsHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Criteria criteria = super.getHibernateSession().createCriteria(FileFormatUtilServices.class);
		if(!input.getBoolean(TransactionConstants.GetServiceFields.Input.GET_ALL_FIELDS, false)){
			criteria = criteria.add(Restrictions.eq("status", true));
		}
		@SuppressWarnings("unchecked")
		List<FileFormatUtilServices> dbFieldList = criteria.list();
		List<ItemServiceField> fields = new ArrayList<ItemServiceField>();
		for(FileFormatUtilServices field : dbFieldList){
			ObjectMapper<ItemServiceField> mapper = new ObjectMapper<ItemServiceField>(ItemServiceField.class);
			ItemServiceField dtoField = mapper.map(field);
			fields.add(dtoField);
		}
		output.put(TransactionConstants.GetDatabaseFields.Output.FIELDS, fields);
	}

}
