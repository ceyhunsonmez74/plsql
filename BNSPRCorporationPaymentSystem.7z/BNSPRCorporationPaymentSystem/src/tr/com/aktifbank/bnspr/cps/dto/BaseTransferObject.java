package tr.com.aktifbank.bnspr.cps.dto;

public class BaseTransferObject {
	public BaseTransferObject(){
		
	}
}
