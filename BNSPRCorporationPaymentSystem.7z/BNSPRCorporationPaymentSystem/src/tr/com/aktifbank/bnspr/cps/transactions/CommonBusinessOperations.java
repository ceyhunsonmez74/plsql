package tr.com.aktifbank.bnspr.cps.transactions;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.axis.utils.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Junction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationTypes;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.ObjectMapper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileCorporateInformation;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileStarterInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.implementations.OutgoingFileByCorporateImplementation;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CollectionTypeDef;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.aktifbank.bnspr.dao.CorporateParameters;
import tr.com.aktifbank.bnspr.dao.FileFormatDef;
import tr.com.aktifbank.bnspr.dao.FileFormatDetail;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class CommonBusinessOperations {
	
	private static final Log logger = LogFactory.getLog(CommonBusinessOperations.class);
	
	public static Boolean isCorporateActive(String corporateCode){
		GMMap getCorporateDefinition = new GMMap();
		getCorporateDefinition.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corporateDefinitionResults = callGraymoundService(getCorporateDefinition, TransactionConstants.GetCorporateDefinition.SERVICE_NAME, true);
		return corporateDefinitionResults.getBoolean(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_ACTIVENESS, false);
	}
	
	public static GMMap callGraymoundService(GMMap input, String serviceName, Boolean keepSession){
		if(keepSession){
			return CommonHelper.callGraymoundServiceInHibernateSession(serviceName, input);
		}
		else{
			return GMServiceExecuter.call(serviceName, input);	
		}
	}
	
	public static List<FormatDetail> getFormatDetails(String lineType, String formatId, Session hibernateSession) throws Exception{
		FileFormatDef definition = (FileFormatDef)hibernateSession.createCriteria(FileFormatDef.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("fileFormatId", formatId))
				.uniqueResult();
		if (definition != null) {
			@SuppressWarnings("unchecked")
			List<FileFormatDetail> details = hibernateSession
					.createCriteria(FileFormatDetail.class)
					.add(Restrictions.eq("fileFormatOid", definition.getOid()))
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("lineType", lineType))
					.addOrder(Order.asc("startIndis"))
					.list();
			List<FormatDetail> domainDetails = new ArrayList<FormatDetail>();
			for (FileFormatDetail detail : details) {
				ObjectMapper<FormatDetail> mapper = new ObjectMapper<FormatDetail>(
						FormatDetail.class);
				domainDetails.add(mapper.map(detail));
			}
			return domainDetails;
		}
		else{
			throw new BatchComponentException(BusinessException.FORMATDEFINITIONNOTFOUND, formatId, getLineTypeName(lineType));
		}
	}
	
	public static int getMetadataHash(String corporateCode, Short collectionType, String channelCode) throws Exception {
		GMMap getSubscriberMetadataRequest = new GMMap();
		getSubscriberMetadataRequest.put(MapKeys.CORPORATE_CODE, corporateCode);
		getSubscriberMetadataRequest.put(MapKeys.COLLECTION_TYPE, collectionType);
		if(!StringUtil.isEmpty(channelCode)){
			getSubscriberMetadataRequest.put(MapKeys.CHANNEL_CODE, channelCode);
		}
		
		GMMap getSubscriberMetadataResponse = CommonHelper.callGraymoundServiceOutsideSession("CDM_GET_SUBSCRIBER_METADATA", getSubscriberMetadataRequest);
		
		StringBuilder metadataHashBuilder = new StringBuilder();
		
		for (int j = 0; j < getSubscriberMetadataResponse.getSize("SUBSCRIBER_METADATA_TABLE"); j++) {
			String prefix = getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "PREFIX");
			String suffix = getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "SUFFIX");
			String viewOrder = getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "VIEW_ORDER");
			String useForInquiry = getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "USE_FOR_INQUIRY");
			String useForCollection = getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "USE_FOR_COLLECTION");
			String prefixUseCollection = getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "PREFIX_USE_COLLECTION");
			String suffixUseCollection = getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "SUFFIX_USE_COLLECTION");
			
			metadataHashBuilder.append(getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "INDEX").concat(":("));
			metadataHashBuilder.append(getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "LABEL").concat("-"));
			metadataHashBuilder.append(getSubscriberMetadataResponse.getString("SUBSCRIBER_METADATA_TABLE", j, "MASK"));
			if(!StringUtil.isEmpty(prefix)){
				metadataHashBuilder.append("-".concat(prefix));
			}
			if(!StringUtil.isEmpty(suffix)){
				metadataHashBuilder.append("-".concat(suffix));
			}
			if(!StringUtil.isEmpty(viewOrder)){
				metadataHashBuilder.append("-".concat(viewOrder));
			}
			if(!StringUtil.isEmpty(useForInquiry)){
				metadataHashBuilder.append("-".concat(useForInquiry));
			}
			if(!StringUtil.isEmpty(useForCollection)){
				metadataHashBuilder.append("-".concat(useForCollection));
			}
			if(!StringUtil.isEmpty(prefixUseCollection)){
				metadataHashBuilder.append("-".concat(prefixUseCollection));
			}
			if(!StringUtil.isEmpty(suffixUseCollection)){
				metadataHashBuilder.append("-".concat(suffixUseCollection));
			}
			
			metadataHashBuilder.append(")");
		}
		
		return metadataHashBuilder.toString().hashCode();
	}
	
	public static String getCollectionTypeName(Short collectionType) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_COLLECTION_TYPE_NAME_QUERY, collectionType));
	}
	
	public static String getChannelName(String channelCode) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_CHANNEL_NAME_QUERY, channelCode));
	}
	
	public static String getPaymentSourceName(String paymentSource) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_PAYMENT_SOURCE_NAME_QUERY, paymentSource));
	}	

	public static String getCorporateNameFromCorporateCode(String corporateCode) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_CORPORATE_NAME_QUERY, corporateCode));
	}
	
	public static String getCorporateShortCodeFromCorporateCode(String corporateCode) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_CORPORATE_SHORT_CODE_QUERY, corporateCode));
	}
	
	public static String getCorporateNameFromCorporateOid(String corporateOid) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_CORPORATE_NAME_OID_QUERY, corporateOid));
	}

	public static String getCorporateCodeFromCorporateOid(String corporateOid) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_CORPORATE_CODE_OID_QUERY, corporateOid));
	}
	public static String getCorporateOidFromCorporateCode(String corporateCode) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_CORPORATE_OID_CODE_QUERY, corporateCode));
	}
	public static String getBranchNameFromBranchCode(String branchCode) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_BRANCH_NAME_QUERY, branchCode));
	}
	
	private static String getLineTypeName(String lineType) {
		if(lineType == DatabaseConstants.LineType.Detail){
			return "Detail(Detay)";
		}
		else if(lineType == DatabaseConstants.LineType.Footer){
			return "Footer(Alt Bilgi)";
		}
		else if(lineType == DatabaseConstants.LineType.Header){
			return "Header(Ba�l�k)";
		}
		else{
			return "";
		}
	}
	
	public static int getTotalCollectionCount(Session hibernateSession, String corporateCode, Date processDate) {
		return getTotalCollectionCount(hibernateSession, corporateCode, Arrays.asList(processDate));
	}
	
	public static int getTotalCollectionCount(Session hibernateSession, String corporateCode, List<Date> processDate){
		return getTotalCollectionCount(hibernateSession, corporateCode, processDate, false);
	}
	
	public static int getTotalCollectionCount(Session hibernateSession, String corporateCode, List<Date> processDate, boolean onlyStandingOrderPayments) {
		Criteria criteria = hibernateSession.createCriteria(invoicePayment.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
				.add(Restrictions.eq("corporateCode", corporateCode));
		Junction disjunction = Restrictions.disjunction();
		for (Date date : processDate) {
			String paymentDateString = CommonHelper.getShortDateTimeString(date);
			disjunction = disjunction.add(Restrictions.like("paymentDate", paymentDateString, MatchMode.START));
		}
		criteria = criteria.add(disjunction);
		if(onlyStandingOrderPayments){
			criteria = criteria.add(Restrictions.isNotNull("standingOrderOid")); 
		}
		return ((Number)criteria
						.setProjection(Projections.rowCount())
						.uniqueResult()).intValue();
	}

	public static BigDecimal getTotalCollectionAmount(Session hibernateSession, String corporateCode, Date invoiceDate) {
		return getTotalCollectionAmount(hibernateSession, corporateCode, Arrays.asList(invoiceDate));
	}
	
	public static BigDecimal getTotalCollectionAmount(Session hibernateSession, String corporateCode, List<Date> invoiceDate) {
		Criteria criteria = hibernateSession.createCriteria(invoicePayment.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
				.add(Restrictions.eq("corporateCode", corporateCode));
		
		Junction disjunction = Restrictions.disjunction();
		for (Date date : invoiceDate) {
			String paymentDateString = CommonHelper.getShortDateTimeString(date);
			disjunction = disjunction.add(Restrictions.like("paymentDate", paymentDateString, MatchMode.START));
		}
		criteria = criteria.add(disjunction);
		
		Object result = criteria 
				.setProjection(Projections.sum("paymentAmount"))
				.uniqueResult();
		if(result != null){
			return new BigDecimal(((Number)result).doubleValue()).setScale(2, RoundingMode.HALF_UP);
		}
		else{
			return new BigDecimal(0);
		}
	}
	
	public static void executeBatchStarterHandler(GMMap input, GMMap output, short transferType, Session hibernateSession) throws Exception{
		logger.info("Starting for batch starter");
		Date processDate = input.getDate(TransactionConstants.INFORM_BATCH_DATE_GENERAL_KEY, null);
		String corporateCode = input.getString(TransactionConstants.INFORM_BATCH_CORPORATE_CODE_GENERAL_KEY, null);
		short informIndicator = (short)input.getInt(TransactionConstants.INFORM_BATCH_INDICATOR_GENERAL_KEY);
		long startMilis = System.currentTimeMillis();
		OutgoingFileStarterInformation information = null;
		
		List<CorporateFileTransfer> fileTransferDefinitions = null;
		
		if(processDate == null){
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			processDate = cal.getTime();
		}
		logger.info("Getting file transfer definitions");
		if(corporateCode == null){
			fileTransferDefinitions = getFileTransferDefinitions(hibernateSession, transferType);
		}
		else{
			fileTransferDefinitions = getFileTransferDefinition(corporateCode, hibernateSession, transferType);
		}
		
		information = getInformation(fileTransferDefinitions);
		information.setProcessDate(processDate);
		information.setServiceName(TransactionConstants.StartCorporateBatch.SERVICE_NAME);
		information.setInformIndicator(informIndicator);
		
		OutgoingFileByCorporateImplementation implementation = new OutgoingFileByCorporateImplementation(information);
		logger.info("Starting for outgoing file by corporate implementation");
		implementation.execute();
		
		String batchName = "";
		
		if(informIndicator == GeneralConstants.INFORM_COLLECTIONS){
			batchName = DatabaseConstants.BatchNames.InformInvoiceCollectionBatch;
		}
		else if(informIndicator == GeneralConstants.INFORM_STANDING_ORDERS){
			batchName = DatabaseConstants.BatchNames.InformStandingOrdersBatch;
		}
		else if(informIndicator == GeneralConstants.INFORM_STANDING_ORDERS_CANCEL){
			batchName = DatabaseConstants.BatchNames.InformStandingOrdersCancelBatch;
		}
		else if(informIndicator == GeneralConstants.INFORM_COLLECTIONS_WITH_EXCEL){
			batchName = DatabaseConstants.BatchNames.InformInvoiceCollectionWithExcelBatch;
		}
		else{
			throw new Exception("Unknown inform indicator " + informIndicator);
		}
		
		long endMilis = System.currentTimeMillis();
		
		if (StringUtil.isEmpty(corporateCode)) {
			Thread.sleep(10 * 60 * 1000);
			GMMap sendReportRequest = new GMMap();
			sendReportRequest.put(
					TransactionConstants.BatchFileReporter.Input.BATCH_NAME,
					batchName);
			sendReportRequest.put(
					TransactionConstants.BatchFileReporter.Input.PROCESS_DATE,
					new Date());
			sendReportRequest.put(
					TransactionConstants.BatchFileReporter.Input.DURATION,
					endMilis - startMilis);
			String exceptionList = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "EXCEPTION_LIST_4_INFORM_COLL");
			if(!StringUtil.isEmpty(exceptionList)){
				sendReportRequest.put("EXCEPTION_LIST", exceptionList);
			}
			sendReportRequest
					.put(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_TO,
							CommonHelper.getValueOfParameter(
									"CDM_EMAIL_RECEIPT_LIST",
									"EMAIL_RECEIPT_LIST_4_INFORM_REPORT"));
			GMServiceExecuter.executeAsync(
					TransactionConstants.BatchFileReporter.SERVICE_NAME,
					sendReportRequest);
		}
		
		if(implementation.isHasError()){
			logger.info("Outgoing file by corporate implementation has error : " + implementation.getErrorMessage());
			output.put(TransactionConstants.InformInvoiceCollectionStarter.Output.RESULT, false);
			output.put(TransactionConstants.InformInvoiceCollectionStarter.Output.ERROR_CODE, implementation.getErrorCode());
			output.put(TransactionConstants.InformInvoiceCollectionStarter.Output.ERROR_MESSAGE, implementation.getErrorMessage());
		}
		else{
			logger.info("Outgoing file by corporate implementation has no error.");
			output.put(TransactionConstants.InformInvoiceCollectionStarter.Output.RESULT, true);
		}
	}
	
	private static OutgoingFileStarterInformation getInformation(
			List<CorporateFileTransfer> fileTransferDefinitions) throws BatchComponentException {
		OutgoingFileStarterInformation information = new OutgoingFileStarterInformation();
		
		information.setMaxParallelThreadCount(Integer.valueOf(CommonHelper.getValueOfParameter("CDM_INFORM_COLLECTION_MAX_PARALLEL_COUNT", "COUNT")));
		
		List<String> addedCorporates = new ArrayList<String>();
		
		for(CorporateFileTransfer transfer : fileTransferDefinitions){
			if (!addedCorporates.contains(transfer.getCorporateCode())) {
				OutgoingFileCorporateInformation corporateInformation = new OutgoingFileCorporateInformation();
				corporateInformation.setBatchName(transfer.getBatchName());
				corporateInformation.setCorporateCode(transfer
						.getCorporateCode());
				corporateInformation.setFormatId(transfer.getFormatId());
				corporateInformation.setFtmId(String.valueOf(transfer.getFtmId().intValue()));
				corporateInformation.setFileTransferId(transfer.getFileTransferId());
				corporateInformation.setTransferType(transfer.getTransferType().toString());
				information
						.addToInvoiceCollectionInformation(corporateInformation);
			}
			else{
				throw new BatchComponentException(BusinessException.INFORMINVOICECOLLECTIONAMBIGIOUSCORPORATE, transfer.getCorporateCode());
			}
		}
		
		return information;
	}

	@SuppressWarnings("unchecked")
	private static List<CorporateFileTransfer> getFileTransferDefinitions(Session hibernateSession, short transferType) {
		return hibernateSession.createCriteria(CorporateFileTransfer.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("transferType", transferType))
				.add(Restrictions.or(Restrictions.eq("complexFileTransfer", false), Restrictions.isNull("complexFileTransfer")))
				.list();
	}
	
	@SuppressWarnings("unchecked")
	private static List<CorporateFileTransfer> getFileTransferDefinition(String corporateCode, Session hibernateSession, short transferType) {
		return hibernateSession.createCriteria(CorporateFileTransfer.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("transferType", transferType))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.add(Restrictions.or(Restrictions.eq("complexFileTransfer", false), Restrictions.isNull("complexFileTransfer")))
				.list();
	}
	
	public static void insertBatchSubmitLog(String corporateCode, String batchName,
			String ftmId, String formatId, String batchSubmitId, String batchServiceName, GMMap input) throws IOException {
		try {
			input.put(MapKeys.BATCH_SERVICE_NAME_FOR_RESUBMIT, batchServiceName);
			GMMap insertRequest = new GMMap();
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.BATCH_NAME,
					batchName);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.CORPORATE_CODE,
					corporateCode);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.IS_UPDATE,
					false);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.START_TIME,
					CommonHelper.getLongDateTimeString(new Date()));
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_DATE,
					CommonHelper.getLongDateTimeString(new Date()));
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_ID,
					batchSubmitId);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_STATUS,
					DatabaseConstants.SubmitStatuses.START);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_USER,
					CommonHelper.getCurrentUser());
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.PARAMETERS,
					CommonHelper.serializeRequest(input));
			GMServiceExecuter.executeNT(TransactionConstants.InsertBatchSubmitLog.SERVICE_NAME, insertRequest);
		} catch (Exception e) {
			logger.error(String.format("An exception occured while inserting batch submit log with params : Corporate Code : %s," +
					" Batch Name : %s, Ftm Id : %s, Format Id : %s, Batch Submit Id : %s, Batch Service Name %s, Input : %s",
					corporateCode, batchName, ftmId, formatId, batchSubmitId, batchServiceName, input.toString()));
			logger.error(System.currentTimeMillis(), e);
		}
	}
	
	public static void updateBatchSubmitLog(String submitId, String submitStatus,
			Date date, String errorCode, String errorDescription) {
		try {
			GMMap updateRequest = new GMMap();
			updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.IS_UPDATE,
					true);
			updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_STATUS,
					submitStatus);
			if (date != null) {
				updateRequest.put(
						TransactionConstants.InsertBatchSubmitLog.Input.END_TIME,
						CommonHelper.getLongDateTimeString(date));
			}
			if (!StringUtil.isEmpty(errorCode)) {
				updateRequest.put(
						TransactionConstants.InsertBatchSubmitLog.Input.ERROR_CODE,
						errorCode);
			}
			if (!StringUtil.isEmpty(errorDescription)) {
				updateRequest
						.put(TransactionConstants.InsertBatchSubmitLog.Input.ERROR_DESCRIPTION,
								errorDescription);
			}
			updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_ID,
					submitId);
			GMServiceExecuter.executeNT(TransactionConstants.InsertBatchSubmitLog.SERVICE_NAME, updateRequest);
		} catch (Exception e) {
			logger.error(String.format("An exception occured while updating batch submit log with Submit Id : %s, Submit Status : %s, Date : %s, " +
					"Error Code : %s, Error Description : %s", submitId, submitStatus, date, errorCode, errorDescription));
			logger.error(System.currentTimeMillis(), e);
		}

	}
	
	public static String getBatchSubmitLogId() throws Exception{
		return CorporationServiceUtil
				.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
	}
	
	public static String getMask(String mask) {
		String patternCharacterList = "#X0*Q";
		StringBuilder maskBuilder = new StringBuilder();
		for (int i = 0; i < mask.length(); i++) {
			char character = mask.charAt(i);
			if (patternCharacterList.contains(Character.toString(character))) {
				maskBuilder.append('-');
			} else {
				maskBuilder.append(character);
			}
		}

		return maskBuilder.toString();
	}
	

	public static String getPreviousTxNo(String tableName, BigDecimal txNo, String corpCode) {
		String s = String.format(QueryRepository.CommonBusinessOperationsRepository.GET_PREV_TX_NO_QUERY, tableName, txNo, corpCode);
		return DALUtil.getResult(s);
	}
	
	@SuppressWarnings("unchecked")
	public static short manipulateCollectionTypeForChannels(short collectionType, String corporateOid) throws Exception {
		if(collectionType == GeneralConstants.COLLECTION_TYPE_NOT_MENTIONED){
			List<CollectionTypeDef> collectionTypeList = CommonHelper.getHibernateSession().createCriteria(CollectionTypeDef.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("corporateOid", corporateOid))
							.addOrder(Order.asc("collectionType"))
							.list();
			if(collectionTypeList.size() == 1){
				return collectionTypeList.get(0).getCollectionType();
			}
			else if(collectionTypeList.size() > 0){
				return 0;
			}
			else{
				throw new BatchComponentException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, "Kurum i�in �deme tipi tan�m� yap�lmam��t�r.");
			}
		}
		else{
			return collectionType;
		}
	}
	
	public static String insertReconLog(String corporateCode, String reconDate, String reconTime, String resubmitType) throws Exception {
		GMMap reconLogInsert = new GMMap();
		
		reconLogInsert.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS, ReconciliationStatus.Started);
		reconLogInsert.put(TransactionConstants.ReconLogInsert.Input.RECON_TYPE, ReconciliationTypes.Collection);
		reconLogInsert.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_CODE, corporateCode);
		reconLogInsert.put(TransactionConstants.ReconLogUpdate.Input.RECON_DATE, reconDate);
		reconLogInsert.put(TransactionConstants.ReconLogUpdate.Input.RECON_TIME, reconTime);
		reconLogInsert.put(TransactionConstants.ReconLogUpdate.Input.SUB_TYPE, resubmitType);
		GMMap reconLogOutput = CommonHelper.callGraymoundServiceOutsideSession("ICS_RECON_LOG_INSERT", reconLogInsert);
		
		return reconLogOutput.getString(TransactionConstants.ReconLogInsert.Output.RECON_LOG_OID);
	}
	
	public static void updateReconLog(String reconLogOid, String reconStatus, BigDecimal bankAmount, BigDecimal bankCancelAmount, 
			BigDecimal corporateAmount, BigDecimal corporateCancelAmount, Date processDate, String reconDate, String corporateCode,
			int bankCount, int bankCancelCount, int corporateCount, int corporateCancelCount, String subType, String errorCode, String errorDesc) throws Exception {
		GMMap reconLogUpdate = new GMMap();
		
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, reconStatus);
		
		if( !StringUtil.isEmpty(errorCode)){
			reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.ERROR_CODE, errorCode);	
		}
		if( !StringUtil.isEmpty(errorDesc)){
			reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.ERROR_DESC, errorDesc);	
		}
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.BANK_AMOUNT, bankAmount);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_AMOUNT, bankCancelAmount);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_AMOUNT, corporateAmount);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_AMOUNT, corporateCancelAmount);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.PROCESS_DATE, CommonHelper.getShortDateTimeString(processDate));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.PROCESS_TIME,  CommonHelper.getStringTimeNow());
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_DATE, reconDate);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_TIME, CommonHelper.getStringTimeNow());
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CODE, corporateCode);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT, bankCount);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT, corporateCount);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT, corporateCancelCount);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT, bankCancelCount);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_TYPE, DatabaseConstants.ReconciliationTypes.Collection);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.SUB_TYPE, subType);
		
		CommonHelper.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", reconLogUpdate);
	}
	
	public static String getSectorNameFromCorporateCode(String corporateCode) throws Exception {
		String sectorCode = getSectorCodeFromCorporateCode(corporateCode);
		return DALUtil.getResult(String.format("SELECT sector_name FROM cdm.sector_def WHERE status=1 and sector_code='%s'", sectorCode));
	}
	
	public static String getSectorCodeFromCorporateCode(String corporateCode) throws Exception {
		return DALUtil.getResult(String.format("SELECT sector_code FROM cdm.corporate_master WHERE status=1 AND corporate_code='%s'", corporateCode));
	}
	
	public static GMMap doCreditCardCollection(String cardNo, String txCode, BigDecimal txNo, String merchantCode,
			BigDecimal amount, String currencyCode, BigDecimal commissionAmount) throws Exception {
		GMMap cardCollectionRequest = new GMMap();
		cardCollectionRequest.put("CARD_NO", cardNo);
		cardCollectionRequest.put("TX_CODE", txCode);
		cardCollectionRequest.put("TX_NO", txNo);
		cardCollectionRequest.put("MERCHANT_CODE", merchantCode);
		cardCollectionRequest.put("AMOUNT", amount);
		cardCollectionRequest.put("CURRENCY_CODE", currencyCode);
		cardCollectionRequest.put("COMMISSION_AMOUNT", commissionAmount);
		
		return CommonHelper.callGraymoundServiceOutsideSession("BNSPR_OCEAN_COLLECTION_FROM_CARD", cardCollectionRequest);
	}
	
	public static GMMap cancelCreditCardCollection(String cardNo, String txCode, BigDecimal txNo, String merchantCode,
			BigDecimal amount, String currencyCode, BigDecimal commissionAmount, BigDecimal collectedTxNo) throws Exception {
		GMMap cardCollectionRequest = new GMMap();
		cardCollectionRequest.put("CARD_NO", cardNo);
		cardCollectionRequest.put("TX_CODE", txCode);
		cardCollectionRequest.put("TX_NO", txNo);
		cardCollectionRequest.put("MERCHANT_CODE", merchantCode);
		cardCollectionRequest.put("AMOUNT", amount);
		cardCollectionRequest.put("CURRENCY_CODE", currencyCode);
		cardCollectionRequest.put("COMMISSION_AMOUNT", commissionAmount);
		cardCollectionRequest.put("CANCEL_TX_NO", collectedTxNo);
		
		return CommonHelper.callGraymoundServiceOutsideSession("BNSPR_OCEAN_CANCEL_COLLECTION_FROM_CARD", cardCollectionRequest);
	}

	public static String getMerchantCode(String corporateCode) {
		return DALUtil.getResult(String.format(QueryRepository.CommonBusinessOperationsRepository.GET_MERCHANT_CODE, corporateCode));
	}
	
	public static String getCorporateParameterValue(String corporateCode, String key) throws Exception {
		return (String) CommonHelper.getHibernateSession().createCriteria(CorporateParameters.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.add(Restrictions.eq("key", key))
				.setProjection(Projections.property("value"))
				.uniqueResult();
	}

	public static BigDecimal getCustomerNoOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.MUSTERI_NO_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return new BigDecimal(result);
		else 
			return null;
	}
}
