package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.clk.CLKClient;
import tr.com.corumGas.CariHareketType;
import tr.com.corumGas.EnumIslemKanali;
import tr.com.corumGas.TahsilatlarResultType;
import tr.com.integration.corumGas.CorumGasClient;
import tr.com.integration.corumGas.ServiceMessage;

import com.graymound.util.GMMap;

public class CorumGasReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(CorumGasReconciliationDetailBatch.class);
	Session session;
	List<CariHareketType> details= new ArrayList<CariHareketType>();
	ServiceMessage message;
	Map<String, CariHareketType> indexedCorporateRecords;

	public CorumGasReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, CariHareketType>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getTahakkukID());
		cancelCollectionRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getBankaReferansNo());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String bankCode = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");
					
			TahsilatlarResultType allDetails = CorumGasClient.ws108TahsilatListesi(reqTimeout, connTimeout, serviceUrl, username, password, this.message, true , EnumIslemKanali.BANKA_ONLINE, reconDate);
			TahsilatlarResultType allDetailsCancel = CorumGasClient.ws108IptalEdilenTahsilatListesi(reqTimeout, connTimeout, serviceUrl, username, password, this.message, true , EnumIslemKanali.BANKA_ONLINE, reconDate);

			List<CariHareketType> paymentList= allDetails.getTahsilatlar().getCariHareketler().getCariHareketType();
			List<CariHareketType> cancelList= allDetailsCancel.getTahsilatlar().getCariHareketler().getCariHareketType();

			details = paymentList;
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	
	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getBankaReferansNo());
		collectionDetailRequest.put(MapKeys.PARAMETER4, details.get(corporateRecordIndex).getParaBirimi());
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getTahakkukID());
		collectionDetailRequest.put(MapKeys.INVOICE_AMOUNT, details.get(corporateRecordIndex).getTutar());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getBankaReferansNo(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getBankaReferansNo().toString());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		CariHareketType corporateDetail = details.get(corporateRecordIndex);
		String aboneNo = corporateDetail.getSozlesmeNo().toString();
		
				
		logger.info(String.format("Following corporate record has not been found in database. Tahakkuk ID : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getTahakkukID().toString(), 
				corporateDetail.getBankaReferansNo(), 
				corporateDetail.getTutar().toString()));
		
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo3(aboneNo);
		payment.setInvoiceNo("1");
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setParameter1(aboneNo);
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO3, aboneNo);
		collectionDetailResponse.put(MapKeys.INVOICE_NO, "");
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getTutar());
	}
	
	private static XMLGregorianCalendar stringToXMLGregorianCalendar(String datetime, String dateFormat) {

	    try {

	    	Date date = CommonHelper.getDateTime(datetime, dateFormat);	        
	        GregorianCalendar cal = (GregorianCalendar) GregorianCalendar
	                .getInstance();

	        cal.setTime(date);

	        return  DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);


	    } catch (Exception e) {

	        System.out.print(e.getMessage());

	        return null;

	    }
	}

}
