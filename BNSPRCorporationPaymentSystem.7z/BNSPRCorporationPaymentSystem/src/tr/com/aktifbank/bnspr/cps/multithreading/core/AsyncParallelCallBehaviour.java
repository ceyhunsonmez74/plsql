package tr.com.aktifbank.bnspr.cps.multithreading.core;

import java.util.ArrayList;
import java.util.List;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.ParallelCallResult;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class AsyncParallelCallBehaviour implements ParallelCallBehaviour {

	public AsyncParallelCallBehaviour() {
		this.result = new ParallelCallResult();
	}
	
	ParallelCallResult result;

	@Override
	public void call(List<GMMap> tasks) {
		List<GMMap> resultList = new ArrayList<GMMap>();
		for (GMMap map : tasks) {
			String serviceName = map.getString(TransactionConstants.ParallelCall.Input.T_SERVICE_NAME);
			GMServiceExecuter.executeAsync(serviceName, map);
			resultList.add(new GMMap()
				.put(TransactionConstants.ParallelCall.Output.T_SUCCESSFUL, true)
				.put(TransactionConstants.ParallelCall.Output.T_TASK_INDEX, tasks.indexOf(map))
				.put(TransactionConstants.ParallelCall.Output.T_SERVICE_NAME, serviceName));
		}
		this.result.setAllSuccessful(true);
		this.result.setResults(resultList);
	}

	@Override
	public ParallelCallResult getResult() {
		return result;
	}

}
