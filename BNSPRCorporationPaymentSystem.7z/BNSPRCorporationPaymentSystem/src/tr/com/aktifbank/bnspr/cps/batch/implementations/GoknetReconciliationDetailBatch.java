package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import service.BankLogin;
import service.SyncPaymentsDetails;
import service.UserSyncPaymentsDetails;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.goknet.GoknetClient;
import tr.com.aktifbank.integration.goknet.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;

import tr.com.palmet.dto.MutabakatDetay;
import tr.com.palmet.dto.MutabakatDetayResult;

import com.graymound.util.GMMap;

public class GoknetReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final String LOGIN_SUCCESS_CODE="1";
	private static final String CANCEL="2";


	private static final Log logger = LogFactory.getLog(GoknetReconciliationDetailBatch.class);
	Session session;
	List<SyncPaymentsDetails> details= new ArrayList<SyncPaymentsDetails>();
	ServiceMessage message;
	Map<String, SyncPaymentsDetails> indexedCorporateRecords;

	public GoknetReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, SyncPaymentsDetails>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getFaturaID());
		cancelCollectionRequest.put(MapKeys.INVOICE_AMOUNT, details.get(corporateRecordIndex).getTutar());
		cancelCollectionRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getReferansID());

	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			String firmCode = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			String pSyncdate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			if (!StringUtil.isEmpty(input.getString(MapKeys.RECON_DATE))) {
				pSyncdate= CommonHelper.getDateString(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			} else {
				pSyncdate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			
			ServiceMessage serviceMessageLogin = new ServiceMessage();
			BankLogin  login = GoknetClient.checkBankLogin(reqTimeout, connTimeout, url, username, password, serviceMessageLogin, firmCode);
			
			input.put("REQUEST_XML_LOGIN", serviceMessageLogin.getRequest());
			input.put("RESPONSE_XML_LOGIN", serviceMessageLogin.getResponse());
				
			if(LOGIN_SUCCESS_CODE.equals(login.getPResult())){
				
			String pTokenid= login.getPTokenid();
			UserSyncPaymentsDetails allDetails = GoknetClient.getSyncPaymentsDetails(reqTimeout, connTimeout, url, username, password, this.message, pTokenid, pSyncdate);

			List<SyncPaymentsDetails> paymentList= allDetails.getSyncPaymentsDetails();
			for (int i = 0; i < paymentList.size(); i++) {
				if (CANCEL.equals(paymentList.get(i).getDurumID())) {
					paymentList.remove(i);
				}
				
			}

			details = paymentList;
			}
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	
	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getReferansID());
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getFaturaID());
		collectionDetailRequest.put(MapKeys.INVOICE_AMOUNT, details.get(corporateRecordIndex).getTutar());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getFaturaID(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getFaturaID());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		SyncPaymentsDetails corporateDetail = details.get(corporateRecordIndex);
		String aboneNo = corporateDetail.getFaturaID();
		
				
		logger.info(String.format("Following corporate record has not been found in database. Tahakkuk ID : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getFaturaID(), 
				corporateDetail.getReferansID(), 
				corporateDetail.getTutar()));
		
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(aboneNo);
		payment.setInvoiceNo("1");
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setParameter1(aboneNo);
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, aboneNo);
		collectionDetailResponse.put(MapKeys.INVOICE_NO, "");
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getTutar());
	}
	



}
