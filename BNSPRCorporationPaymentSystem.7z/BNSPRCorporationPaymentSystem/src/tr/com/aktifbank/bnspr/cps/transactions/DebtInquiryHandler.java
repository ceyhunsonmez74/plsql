package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoiceMain;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class DebtInquiryHandler extends RequestHandler {
/***
 * !!!!!!!!!!!!!! KULLANILMIYOR S�L�NECEK !!!!!!!!!!!!!!!!!!!!!!!!!!
 */
	public DebtInquiryHandler() {
		// TODO Auto-generated constructor stub
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.DebtInquiry.Input.CORPORATE_CODE);
		String subscriberNo1 = input.getString(TransactionConstants.DebtInquiry.Input.SUBSCRIBER_NO1);
		String subscriberNo2 = input.getString(TransactionConstants.DebtInquiry.Input.SUBSCRIBER_NO2, null);
		String subscriberNo3 = input.getString(TransactionConstants.DebtInquiry.Input.SUBSCRIBER_NO3, null);
		String subscriberNo4 = input.getString(TransactionConstants.DebtInquiry.Input.SUBSCRIBER_NO4, null);
		
		
		input.put("GM_SERVICE_NAME", "ICS_INVOICE_DEBT_INQUIRY");
		output = (GMMap) GMServiceExecuter.call("CDM_ONLINE_SERVICE_CALL", input);
				
		
		GMMap boundServiceResult = super.callServiceWithParams(TransactionConstants.GetCorporateServiceBoundGmService.SERVICE_NAME, 
				TransactionConstants.GetCorporateServiceBoundGmService.Input.CORPORATE_CODE, corporateCode,
				TransactionConstants.GetCorporateServiceBoundGmService.Input.GM_SERVICE_NAME, TransactionConstants.DoInvoiceCollection.SERVICE_NAME);
		
		Criteria criteria = super.getHibernateSession().createCriteria(invoiceMain.class)
			.add(Restrictions.eq("corporateCode", corporateCode))
			.add(Restrictions.eq("subscriberNo1", subscriberNo1));
		
		if(subscriberNo2 != null){
			criteria = criteria.add(Restrictions.eq("subscriberNo2", subscriberNo2));
		}
		
		if(subscriberNo3 != null){
			criteria = criteria.add(Restrictions.eq("subscriberNo3", subscriberNo3));
		}
		
		if(subscriberNo4 != null){
			criteria = criteria.add(Restrictions.eq("subscriberNo4", subscriberNo4));
		}
		
		List<invoiceMain> invoiceList = criteria.list();
		if(invoiceList.size() != 0) {
			GMMap getCorporateDefinitionMap = new GMMap();
			getCorporateDefinitionMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
			GMMap result = super.callGraymoundServiceInSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, getCorporateDefinitionMap);
			String corporateName = result.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_NAME);
			for(invoiceMain invoice : invoiceList){
				
			}
		}
		else {
			throw new BatchComponentException(BusinessException.NODEBTFOUND, String.format("%s %s %s %s", subscriberNo1, 
					getStringOrDefault(subscriberNo2),
					getStringOrDefault(subscriberNo3),
					getStringOrDefault(subscriberNo4)));
		}
	}

	private String getStringOrDefault(String subscriberNo) {
		if(subscriberNo != null){
			return subscriberNo;
		}
		else{
			return "";
		}
	}

}
