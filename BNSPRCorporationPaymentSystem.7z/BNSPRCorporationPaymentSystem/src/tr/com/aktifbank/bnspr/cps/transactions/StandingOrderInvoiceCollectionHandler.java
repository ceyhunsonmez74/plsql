package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.AccountHelper;
import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.StandingOrderInvoiceCollectionHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.DoInvoiceCollection;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.BatchParameters;
import tr.com.aktifbank.bnspr.dao.StandingOrderAccount;
import tr.com.aktifbank.bnspr.dao.icsStdOrderProcessLog;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class StandingOrderInvoiceCollectionHandler extends ParallelRequestHandler {
	private static final String tableName = "INVOICES";
	private static final class BagKeys{
		public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Session hibernateSession = CommonHelper.getHibernateSession();
		
		BigDecimal masterSubmitId = input.getBigDecimal("MASTER_SUBMIT_ID");
		
		Criteria criteriaParameter = hibernateSession.createCriteria(BatchParameters.class)
				.add(Restrictions.eq("batchName", input.getString(MapKeys.BATCH_NAME)))
				.add(Restrictions.eq("status", true));
				
		
		List<BatchParameters> batchParameterList = criteriaParameter.list();
		for (BatchParameters batchParameters : batchParameterList) {
			input.put(batchParameters.getParamKey(),batchParameters.getParamKeyValue());			
		}
		
        
        String batchSubmitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		bag.put(BagKeys.BATCH_SUBMIT_ID, batchSubmitId);
		String corporateCode =  input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE);
		String batchName = input.getString(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME);
		String batchServiceName = "ICS_STANDING_ORDER_INVOICE_COLLECTION";
		String ftmId = "";
		String formatId = "";
		
		CommonBusinessOperations.insertBatchSubmitLog(corporateCode, batchName, ftmId, formatId, batchSubmitId, batchServiceName, input);
		
		GMMap invoiceList = DALUtil.getResults(String.format(StandingOrderInvoiceCollectionHandlerRepository.FETCH_INVOICES_COLLECTION_QUERY, corporateCode), tableName);
		int invoicesListLength = invoiceList.getSize(tableName);
		
		for (int i = 0; i < invoicesListLength; i++) {
			GMMap logMap = new GMMap();
			logMap.put(MapKeys.INVOICE_MAIN_OID, invoiceList.getString(tableName, i, MapKeys.INVOICE_MAIN_OID));
			logMap.put(MapKeys.PROCESS_DATE, CommonHelper.getLongDateTimeString(new Date()));
			logMap.put(MapKeys.STANDING_ORDER_OID, invoiceList.getString(tableName, i, MapKeys.STANDING_ORDER_OID));
			logMap.put("MASTER_SUBMIT_ID", masterSubmitId);
			try {
				StandingOrderAccount soaRecord = (StandingOrderAccount) super.getHibernateSession().createCriteria(StandingOrderAccount.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("standingOrderOid", invoiceList.getString(tableName, i, MapKeys.STANDING_ORDER_OID)))
						.uniqueResult();
				
				String priority = String.valueOf(soaRecord.getPriority());
				String sourceCode = null;
				BigDecimal cardNo = soaRecord.getCardNumber();
				BigDecimal paymentAccountNo = soaRecord.getAccountNumber();
				boolean allowPartPayment = invoiceList.getString(tableName, i, "ALLOW_PART_PAYMENT").equals("1");
				
				if(priority.equals(DatabaseConstants.StandingOrderSourcePriorities.AccountFirst)){
					sourceCode = DatabaseConstants.SourceCodes.Account;
				}
				else{
					sourceCode = DatabaseConstants.SourceCodes.CreditCard;
				}
				String currencyCode = invoiceList.getString(tableName, i, MapKeys.CURRENCY_CODE);
				BigDecimal customerNo = invoiceList.getBigDecimal(tableName, i, MapKeys.CUSTOMER_NO);
				BigDecimal paymentAmount = invoiceList.getBigDecimal(tableName, i, MapKeys.AMOUNT).subtract(invoiceList.getBigDecimal(tableName, i, MapKeys.PAYMENT_AMOUNT));
				
				if (paymentAmount.compareTo(BigDecimal.ZERO) == 0) {
					continue;    // K�smi �demede fatura tamamen �dendi�i zaman i�in konuldu
				}
				
				BigDecimal availableBalance = AccountHelper.getAvailableBalance(customerNo, currencyCode, paymentAccountNo);
				
				if(sourceCode.equals(DatabaseConstants.SourceCodes.Account) && availableBalance.compareTo(paymentAmount) < 0 && allowPartPayment && 
						availableBalance.compareTo(BigDecimal.ZERO) != 0){
					paymentAmount = availableBalance;
				}
				
				if(sourceCode.equals(DatabaseConstants.SourceCodes.Account) && availableBalance.equals(BigDecimal.ZERO)){
					if(cardNo != null && cardNo.compareTo(BigDecimal.ZERO) != 0){
						sourceCode = DatabaseConstants.SourceCodes.CreditCard;
					}
				}
				
				GMMap paymentMap = new GMMap();
				paymentMap.put(MapKeys.INVOICE_AMOUNT, invoiceList.getBigDecimal(tableName, i, MapKeys.AMOUNT));
				paymentMap.put(MapKeys.PAYMENT_AMOUNT, paymentAmount);
				paymentMap.put(MapKeys.BRANCH_CODE, invoiceList.getString(tableName, i, MapKeys.BRANCH_CODE));
				paymentMap.put(MapKeys.COLLECTION_TYPE, invoiceList.getString(tableName, i, MapKeys.COLLECTION_TYPE));
				paymentMap.put(MapKeys.CORPORATE_CODE, invoiceList.getString(tableName, i, MapKeys.CORPORATE_CODE));
				paymentMap.put(MapKeys.CURRENCY_CODE,currencyCode);
				paymentMap.put(MapKeys.CUSTOMER_NO, customerNo);
				paymentMap.put(MapKeys.INSTALLMENT_NO,invoiceList.getString(tableName, i, MapKeys.INSTALLMENT_NO));
				paymentMap.put(MapKeys.INVOICE_DATE, invoiceList.getString(tableName, i, MapKeys.INVOICE_DATE));
				paymentMap.put(MapKeys.INVOICE_DUE_DATE, invoiceList.getString(tableName, i, MapKeys.INVOICE_DUE_DATE));
				paymentMap.put(MapKeys.INVOICE_NO,invoiceList.getString(tableName, i, MapKeys.INVOICE_NO));
				paymentMap.put(MapKeys.INVOICE_STATUS,invoiceList.getString(tableName, i, MapKeys.INVOICE_STATUS));
				paymentMap.put(MapKeys.LOADING_DATE, invoiceList.getString(tableName, i, MapKeys.LOADING_DATE));
				paymentMap.put(MapKeys.LOADING_USER, invoiceList.getString(tableName, i, MapKeys.LOADING_USER));
				paymentMap.put(MapKeys.PARAMETER1,invoiceList.getString(tableName, i, MapKeys.PARAMETER1));
				paymentMap.put(MapKeys.PARAMETER2, invoiceList.getString(tableName, i, MapKeys.PARAMETER2));
				paymentMap.put(MapKeys.PARAMETER3, invoiceList.getString(tableName, i, MapKeys.PARAMETER3));
				paymentMap.put(MapKeys.PARAMETER4, invoiceList.getString(tableName, i, MapKeys.PARAMETER4));
				paymentMap.put(MapKeys.PARAMETER5, invoiceList.getString(tableName, i, MapKeys.PARAMETER5));
				paymentMap.put(MapKeys.PARAMETER6, invoiceList.getString(tableName, i, MapKeys.PARAMETER6));
				paymentMap.put(MapKeys.PARAMETER7, invoiceList.getString(tableName, i, MapKeys.PARAMETER7));
				paymentMap.put(MapKeys.PARAMETER8, invoiceList.getString(tableName, i, MapKeys.PARAMETER8));
				paymentMap.put(MapKeys.PARAMETER9, invoiceList.getString(tableName, i, MapKeys.PARAMETER9));
				paymentMap.put(MapKeys.PARAMETER10, invoiceList.getString(tableName, i, MapKeys.PARAMETER10));
				paymentMap.put(MapKeys.PARAMETER11, invoiceList.getString(tableName, i, MapKeys.PARAMETER11));
				paymentMap.put(MapKeys.PARAMETER12, invoiceList.getString(tableName, i, MapKeys.PARAMETER12));
				paymentMap.put(MapKeys.PARAMETER13, invoiceList.getString(tableName, i, MapKeys.PARAMETER13));
				paymentMap.put(MapKeys.PARAMETER14, invoiceList.getString(tableName, i, MapKeys.PARAMETER14));
				paymentMap.put(MapKeys.PARAMETER15, invoiceList.getString(tableName, i, MapKeys.PARAMETER15));
				paymentMap.put(MapKeys.PARAMETER16, invoiceList.getString(tableName, i, MapKeys.PARAMETER16));
				paymentMap.put(MapKeys.PARAMETER17, invoiceList.getString(tableName, i, MapKeys.PARAMETER17));
				paymentMap.put(MapKeys.PARAMETER18, invoiceList.getString(tableName, i, MapKeys.PARAMETER18));
				paymentMap.put(MapKeys.PARAMETER19, invoiceList.getString(tableName, i, MapKeys.PARAMETER19));
				paymentMap.put(MapKeys.PARAMETER20, invoiceList.getString(tableName, i, MapKeys.PARAMETER20));
				paymentMap.put(MapKeys.PAYMENT_METHOD, invoiceList.getString(tableName, i, MapKeys.PAYMENT_METHOD));
				paymentMap.put(MapKeys.PAYMENT_STATUS,invoiceList.getString(tableName, i, MapKeys.PAYMENT_STATUS));
				paymentMap.put(MapKeys.STANDING_ORDER_OID, invoiceList.getString(tableName, i, MapKeys.STANDING_ORDER_OID));
				paymentMap.put(MapKeys.SUB_COLLECTION_TYPE, invoiceList.getString(tableName, i, MapKeys.SUB_COLLECTION_TYPE));
				paymentMap.put(MapKeys.SUBSCRIBER_EMAIL, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_EMAIL));
				paymentMap.put(MapKeys.SUBSCRIBER_MOBILE, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_MOBILE));
				paymentMap.put(MapKeys.SUBSCRIBER_NAME, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_NAME));
				paymentMap.put(MapKeys.SUBSCRIBER_NO1, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_NO1));
				paymentMap.put(MapKeys.SUBSCRIBER_NO2, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_NO2));
				paymentMap.put(MapKeys.SUBSCRIBER_NO3, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_NO3));
				paymentMap.put(MapKeys.SUBSCRIBER_NO4, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_NO4));
				paymentMap.put(MapKeys.SUBSCRIBER_PHONE, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_PHONE));
				paymentMap.put(MapKeys.SUBSCRIBER_PIDNO, invoiceList.getString(tableName, i, MapKeys.SUBSCRIBER_PIDNO));
				paymentMap.put(MapKeys.TERM_MONTH, invoiceList.getString(tableName, i, MapKeys.TERM_MONTH));
				paymentMap.put(MapKeys.TERM_YEAR, invoiceList.getString(tableName, i, MapKeys.TERM_YEAR));
				paymentMap.put(MapKeys.TRX_NO, getNewTransactionNo());
				paymentMap.put(MapKeys.ZONE_CODE, invoiceList.getString(tableName, i, MapKeys.ZONE_CODE));
				paymentMap.put(MapKeys.SOURCE, sourceCode);
				paymentMap.put(MapKeys.CHANNEL_CODE, CommonHelper.getChannelId());
				paymentMap.put(MapKeys.INVOICE_MAIN_OID,invoiceList.getString(tableName, i, MapKeys.INVOICE_MAIN_OID));
				paymentMap.put(MapKeys.CALCULATE_COMMISSION, GeneralConstants.COMMISSION_DEFAULT);
				paymentMap.put(MapKeys.PAYMENT_ACCOUNT_NO, paymentAccountNo);
				paymentMap.put(MapKeys.CALCULATE_COMMISSION, GeneralConstants.COMMISSION_DEFAULT);
				paymentMap.put(MapKeys.IS_STANDING_ORDER_COLLECTION, true);
				paymentMap.put(DoInvoiceCollection.Input.PAYMENT_CARD_NO, cardNo);
				paymentMap.put("CHECK_HASH", false);
				CommonHelper.callGraymoundServiceOutsideSession("ICS_DO_INVOICE_COLLECTION", paymentMap);
				
				logMap.put(MapKeys.PROCESS_STATUS, DatabaseConstants.StandingOrderProcessLogStatuses.Successful);
				
			} catch (Exception e) {
				logger.error("An exception occured while collecting invoice for id " + logMap.getString(MapKeys.INVOICE_MAIN_OID));
				logger.error(System.currentTimeMillis(), e);
				
				logMap.put(MapKeys.PROCESS_STATUS, DatabaseConstants.StandingOrderProcessLogStatuses.Failed);
				logMap.put(MapKeys.ERROR_CODE, "1");
				logMap.put(MapKeys.ERROR_DESC, e.getMessage());
			}
			finally{
				CommonHelper.callGraymoundServiceOutsideSession("ICS_CREATE_STANDING_ORDER_PROCESS_LOG", logMap);
			}
		

		}	
		CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId, DatabaseConstants.SubmitStatuses.SUCESSFUL, new Date(), null, null);

	}
	
    @Override
	protected void handleError(Throwable e, GMMap output) {
		Long errorId = System.currentTimeMillis();
		logger.error("System exception is occured updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(), "0",
				e.toString());
	}

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		Long errorId = System.currentTimeMillis();

		logger.error("Business exception is occured. Updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(),
				String.valueOf(e.getCode()), e.toString());
	}
	
	@GraymoundService("ICS_CREATE_STANDING_ORDER_PROCESS_LOG")
    public static GMMap crateStdOrderPorcessLog(GMMap inMap) {
		GMMap outMap = new GMMap();
		Session hibSession = null;
		try {
			hibSession = CommonHelper.getHibernateSession();
			icsStdOrderProcessLog stdOrderProcessLog = new icsStdOrderProcessLog();
			stdOrderProcessLog.setErrorCode(inMap.getString(MapKeys.ERROR_CODE, null));
			String errorDesc = inMap.getString(MapKeys.ERROR_DESC, null);
			if(!StringUtil.isEmpty(errorDesc) && errorDesc.length() > 4000){
				errorDesc = errorDesc.substring(0, 3988);
			}
			
			if(!StringUtil.isEmpty(errorDesc) && errorDesc.startsWith("com.graymound.util.GMRuntimeException:")){
				errorDesc = errorDesc.replaceAll("com.graymound.util.GMRuntimeException:", "");
			}
			stdOrderProcessLog.setErrorDesc(errorDesc);
			stdOrderProcessLog.setInvoiceMainOid(inMap.getString(MapKeys.INVOICE_MAIN_OID));
			stdOrderProcessLog.setProcessDate(inMap.getString(MapKeys.PROCESS_DATE));
			stdOrderProcessLog.setProcessStatus(inMap.getString(MapKeys.PROCESS_STATUS));
			stdOrderProcessLog.setProcessTime(inMap.getString(MapKeys.PROCESS_TIME, ""));
			stdOrderProcessLog.setStandingOrderOid(inMap.getString(MapKeys.STANDING_ORDER_OID));
			stdOrderProcessLog.setStatus(true);
			stdOrderProcessLog.setMasterSubmitId(inMap.getBigDecimal("MASTER_SUBMIT_ID"));
			
			hibSession.save(stdOrderProcessLog);
			hibSession.flush();
		} catch (Exception e) {
			logger.error("An exception occured while creating process log with parameters : " + inMap.toString());
			logger.error(System.currentTimeMillis(), e);
		}
		return outMap;
	}
	
	private static BigDecimal getNewTransactionNo() {
		return new BigDecimal(CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString(MapKeys.TRX_NO));
	}


}	


