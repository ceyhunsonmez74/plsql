package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.List;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class ControlSubscriberMetaDataHandler extends RequestHandler {

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		String corporateCode = input.getString(TransactionConstants.ControlSubscriberMetaData.Input.CORPORATE_CODE);
		String channelCode = input.getString(TransactionConstants.ControlSubscriberMetaData.Input.CHANNEL_CODE, null);
		int collectionType = input.getInt(TransactionConstants.ControlSubscriberMetaData.Input.COLLECTION_TYPE, GeneralConstants.COLLECTION_TYPE_NOT_MENTIONED);
		String metadataType = input.getString("METADATA_TYPE", DatabaseConstants.MetadataTypes.Collection);
		List<String> resultSubscriberNoList = new ArrayList<String>();
		
		GMMap subscriberMetaDataMap = super.callServiceWithParams(TransactionConstants.GetSubscriberMetadata.SERVICE_NAME, 
				TransactionConstants.GetSubscriberMetadata.Input.CHANNEL_CODE, channelCode,
				TransactionConstants.GetSubscriberMetadata.Input.COLLECTION_TYPE, collectionType,
				TransactionConstants.GetSubscriberMetadata.Input.CORPORATE_CODE,corporateCode,
				TransactionConstants.GetSubscriberMetadata.Input.CALLER_SCREEN,"ICS");
		
		for (int i = 0; i < subscriberMetaDataMap.getSize(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE); i++) {
			int length = subscriberMetaDataMap.getInt(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i, TransactionConstants.GetSubscriberMetadata.Output.LENGTH);
			String prefix = subscriberMetaDataMap.getString(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i, TransactionConstants.GetSubscriberMetadata.Output.PREFIX);
			String suffix = subscriberMetaDataMap.getString(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i, TransactionConstants.GetSubscriberMetadata.Output.SUFFIX);
			int index = subscriberMetaDataMap.getInt(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i, TransactionConstants.GetSubscriberMetadata.Output.INDEX);
			String prefixUseForStandingOrder = subscriberMetaDataMap.getString(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i, "PREFIX_USE_STD_ORDER");
			String suffixUseForStandingOrder = subscriberMetaDataMap.getString(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, i, "SUFFIX_USE_STD_ORDER");
			
			boolean prefixUseStdOrder = StringUtil.isEmpty(prefixUseForStandingOrder) ? true : (prefixUseForStandingOrder.equals("1") ? true : false);
			boolean suffixUseStdOrder = StringUtil.isEmpty(suffixUseForStandingOrder) ? true : (suffixUseForStandingOrder.equals("1") ? true : false);
			
			String subscriberNo = getSubscriberNoOfIndex(input, index);
			
			if(!StringUtil.isEmpty(subscriberNo)){
				StringBuilder tmpBuilder = new StringBuilder(subscriberNo);
				int remainingLength = length - subscriberNo.length();
				
				if( remainingLength > 0 ){
					if( null != prefix && !"".equals(prefix) ){	
						if(metadataType.equals(DatabaseConstants.MetadataTypes.Collection)){
							addPrefix2SubscriberNo(remainingLength, prefix, tmpBuilder);
						}
						else{
							if(prefixUseStdOrder){
								addPrefix2SubscriberNo(remainingLength, prefix, tmpBuilder);
							}
						}
					}
					if( null != suffix && !"".equals(suffix) ){
						if(metadataType.equals(DatabaseConstants.MetadataTypes.Collection)){
							addSuffix2SubscriberNo(remainingLength, suffix, tmpBuilder);
						}
						else{
							if(suffixUseStdOrder){
								addSuffix2SubscriberNo(remainingLength, suffix, tmpBuilder);
							}
						}
					}
				}
				resultSubscriberNoList.add(tmpBuilder.toString());
			}
			else{
				resultSubscriberNoList.add(subscriberNo);
			}
		}
			
		output.put(TransactionConstants.ControlSubscriberMetaData.Output.SUBSCRIBER_NO_LIST, resultSubscriberNoList);

	}

	private String getSubscriberNoOfIndex(GMMap input, int index) {
		return input.getString("SUBSCRIBER_NO" + index, null);
	}

	private void addSuffix2SubscriberNo(int remainingLength, String suffix, StringBuilder builder){
		
		for( int i=0; i < remainingLength; i++){
			builder.append(suffix);
		}
	}
	
	private void addPrefix2SubscriberNo(int remainingLength, String prefix, StringBuilder builder){
			
		for( int i=0; i < remainingLength; i++){
			builder.insert(0, prefix);
		}
	}
}
