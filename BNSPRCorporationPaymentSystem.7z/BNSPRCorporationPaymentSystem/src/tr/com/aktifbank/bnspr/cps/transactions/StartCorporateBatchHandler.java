package tr.com.aktifbank.bnspr.cps.transactions;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BatchParameterEngine;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CorporateBatchInformation;
import tr.com.aktifbank.bnspr.cps.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cps.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cps.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;

import com.graymound.util.GMMap;

public class StartCorporateBatchHandler extends
		ParallelRequestHandler {

	private static class BagKeys {
		public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
		public static final String CORPORATE_CODE = "CORPORATE_CODE";
		public static final String NOT_PROCESSED_DUE_TO_PARAMETER = "FTM_CAGRISI_YAPMA";
	}
	
	private static final class ParameterKeys {
		public static final String DO_NOT_CALL_FTM = "FTM_CAGRISI_YAPMA"; 
		public static final String DO_NOT_CALL_FTM_WITH_EMTY_FILE = "FTM_BOS_DOSYA_CAGRISI_YAPMA";
	}

	public StartCorporateBatchHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		logger.info("Corporate batch start is beginning to prepare start for batch");
		String corporateCode = input
				.getString(TransactionConstants.StartCorporateBatch.Input.CORPORATE_CODE);
		super.bag.put(BagKeys.CORPORATE_CODE, corporateCode);
		String batchName = input
				.getString(TransactionConstants.StartCorporateBatch.Input.BATCH_NAME);
		String ftmId = input
				.getString(TransactionConstants.StartCorporateBatch.Input.FTM_ID);
		String formatId = input
				.getString(TransactionConstants.StartCorporateBatch.Input.FORMAT_ID);
		Date processDate = input
				.getDate(TransactionConstants.StartCorporateBatch.Input.PROCESS_DATE);
		Date fileDate = CommonHelper.addDay(processDate, 1);
		String fileTransferId = input.getString(TransactionConstants.StartCorporateBatch.Input.FILE_TRANSFER_ID);
		String transferType = input.getString(TransactionConstants.StartCorporateBatch.Input.TRANSFER_TYPE);
		short informIndicator = (short)input.getInt(TransactionConstants.StartCorporateBatch.Input.INFORM_INDICATOR);

		String batchSubmitId = CorporationServiceUtil
				.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		super.bag.put(BagKeys.BATCH_SUBMIT_ID, batchSubmitId);

		logger.info("Inserting batch submit log");
		
		CommonBusinessOperations.insertBatchSubmitLog(corporateCode, batchName, ftmId, formatId,
				batchSubmitId, TransactionConstants.StartCorporateBatch.SERVICE_NAME, input);
		
		GMMap corporateDetails = super.callGraymoundServiceInSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
				new GMMap().put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode));
		
		addFileNameParams(input, corporateCode, processDate, fileDate, corporateDetails);

		logger.info("Getting batch details");
		GMMap batchDetails = super.callServiceWithParams(
				TransactionConstants.GetBatchDetail.SERVICE_NAME,
				TransactionConstants.GetBatchDetail.Input.BATCH_NAME,
				batchName,
				TransactionConstants.GetBatchDetail.Input.CORPORATE_CODE,
				corporateCode);
		
		GMMap batchParameters = super.callServiceWithParams(TransactionConstants.GetBatchParameters.SERVICE_NAME, 
				TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID, 
					batchDetails.getString(TransactionConstants.GetBatchDetail.Output.CORPORATE_BATCH_PROCESS_OID));

		String serviceName = batchDetails
				.getString(TransactionConstants.GetBatchDetail.Output.SERVICE_NAME);

		List<FormatDetail> headerDetails = callFormatServices(
				TransactionConstants.GetFileHeaderFormat.SERVICE_NAME,
				formatId,
				TransactionConstants.GetFileHeaderFormat.Output.HEADER_FORMATS);
		List<FormatDetail> bodyDetails = callFormatServices(
				TransactionConstants.GetFileDetailFormat.SERVICE_NAME,
				formatId,
				TransactionConstants.GetFileDetailFormat.Output.DETAIL_FORMAT);
		List<FormatDetail> footerDetails = callFormatServices(
				TransactionConstants.GetFileFooterFormat.SERVICE_NAME,
				formatId,
				TransactionConstants.GetFileFooterFormat.Output.FOOTER_FORMATS);

		List<ItemDatabaseField> databaseFields = (List<ItemDatabaseField>) super
				.callServiceWithParams(
						TransactionConstants.GetDatabaseFields.SERVICE_NAME)
				.get(TransactionConstants.GetDatabaseFields.Output.FIELDS);

		List<ItemServiceField> serviceFields = (List<ItemServiceField>) super
				.callServiceWithParams(
						TransactionConstants.GetServiceFields.SERVICE_NAME)
				.get(TransactionConstants.GetServiceFields.Output.FIELDS);
		BigDecimal ftmProcessId = getNextValueOfProcessSequence();

		CorporateBatchInformation information = new CorporateBatchInformation();
		information.setCorporateCode(corporateCode);
		information.setServiceName(serviceName);
		information.setBodyDetails(bodyDetails);
		information.setFooterDetails(footerDetails);
		information.setHeaderDetails(headerDetails);
		information.setInvoiceDate(processDate);
		information.setFtmProcessId(ftmProcessId);
		information.setDatabaseFields(databaseFields);
		information.setServiceFields(serviceFields);
		information.setInformIndicator(informIndicator);
		information.setBatchInput(input);
		if(batchParameters.containsKey(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS)){
			BatchParameterEngine engine = new BatchParameterEngine(batchParameters.getString(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS));
			information.setBatchParameters(CommonHelper.convertMapToGMMap(engine.getDecomposedParameters()));
		}

		logger.info("Updating batch submit log");
		
		CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId,
				DatabaseConstants.SubmitStatuses.EXECUTING, null, null, null);

		logger.info("Executing corporate batch");
		
		executeInformCollection(information);

		logger.info("Calling ftm for file transfer");
		
		GMMap insertOutput = super.callServiceWithSessionOption("CDM_INSERT_FILE_TRANSFER_LOG", false,
				"IS_UPDATE", false,
				"BATCH_NAME", batchName,
				"CORPORATE_CODE", corporateCode,
				"FILE_TRANSFER_ID", fileTransferId,
				"FTM_ID", ftmId,
				"PROCESS_ID", ftmProcessId,
				"TRANSFER_STATUS", DatabaseConstants.TransferStatuses.SUBMITTED,
				"TRANSFER_TYPE", transferType,
				"BATCH_SUBMIT_ID", batchSubmitId,
				"TOTAL_COUNT", information.getTotalCount(),
				"TOTAL_AMOUNT", information.getTotalAmount());
		
		if(bag.containsKey(BagKeys.NOT_PROCESSED_DUE_TO_PARAMETER) && 
				((String)bag.get(BagKeys.NOT_PROCESSED_DUE_TO_PARAMETER)).equals("1")){
			logger.info("File not processed due to the parameter");
			CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId,
					DatabaseConstants.SubmitStatuses.SUCESSFUL, new Date(), null,
					null);
		}
		else{
			boolean callFTM = true;
			
			if(information.getBatchParameters() != null && information.getBatchParameters().getString(ParameterKeys.DO_NOT_CALL_FTM, "2").equals(DatabaseConstants.BatchParameterValues.DoNotCallFtmEnabled)){
				callFTM = false;
			} else if(information.getBatchParameters() != null && information.getBatchParameters().getString(ParameterKeys.DO_NOT_CALL_FTM_WITH_EMTY_FILE, "2").equals(DatabaseConstants.BatchParameterValues.DoNotCallFtmWithEmtyFileEnabled)){
				/* eger bu parametre set eidlmisse INVOICE_PAYMENT deki satir sayisinin 0 satirdan fazla olmasina bakilacak ve ona gore FTM servisi cagrilacak*/
				int paidInvoiceCount = CommonBusinessOperations.getTotalCollectionCount(CommonHelper.getHibernateSession(), corporateCode, processDate);
				callFTM = paidInvoiceCount > 0 ? true : false; 
			}			
			
			if(callFTM){
				try {
					callFtmForFileTransfer(input, ftmId, information.getFtmProcessId(), information.getTotalCount(), informIndicator);
				} catch (Exception e) {
					logger.error("An exception occured while calling ftm for file transfer");
					logger.error(System.currentTimeMillis(), e);
					super.callServiceWithSessionOption("CDM_INSERT_FILE_TRANSFER_LOG", false,
							"IS_UPDATE", true,
							"ERROR_CODE", "0",
							"ERROR_MESSAGE", CommonHelper.getStringifiedException(e),
							"RECORD_ID", insertOutput.getString("RECORD_ID"),
							"TRANSFER_STATUS", DatabaseConstants.TransferStatuses.SUBMITFAILURE);
					throw e;
				}
			}
		}
		
		output.put(
				TransactionConstants.StartCorporateBatch.Output.RESULT,
				true);
		output.put(
				TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID,
				batchSubmitId);
		output.put(
				TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE,
				corporateCode);

	}

	private void addFileNameParams(GMMap input, String corporateCode,
			Date processDate, Date fileDate, GMMap corporateDetails)
			throws Exception {
		Date beforeWorkingDate = getBeforeWorkingDate(fileDate);
		Date nextWorkingDate = getNextWorkingDate(fileDate);
		String uniqueNumberByCorporate = getUniqueNumberByCorporate(corporateCode);
		input.put("BANK_CODE", corporateDetails.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE));
		input.put("SHORT_PROCESS_DATE", CommonHelper.getDateString(processDate, "yyMMdd"));
		
		input.put("PROCESS_DATE_DAY", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getDay(processDate)), "0", 2, true));
		input.put("PROCESS_DATE_MONTH", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getMonth(processDate)), "0", 2, true));
		input.put("PROCESS_DATE_YEAR", CommonHelper.getYear(processDate));
		input.put("PROCESS_DATE_YEAR_SHORT", String.valueOf(CommonHelper.getYear(processDate)).substring(2, 4));
		
		input.put("FILE_DATE_DAY", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getDay(fileDate)), "0", 2, true));
		input.put("FILE_DATE_MONTH", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getMonth(fileDate)), "0", 2, true));
		input.put("FILE_DATE_YEAR", CommonHelper.getYear(fileDate));
		input.put("FILE_DATE_YEAR_SHORT", String.valueOf(CommonHelper.getYear(fileDate)).substring(2, 4));
		
		input.put("BEF_WORKING_DATE_DAY", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getDay(beforeWorkingDate)), "0", 2, true));
		input.put("BEF_WORKING_DATE_MONTH", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getMonth(beforeWorkingDate)), "0", 2, true));
		input.put("BEF_WORKING_DATE_YEAR", CommonHelper.getYear(beforeWorkingDate));
		input.put("BEF_WORKING_DATE_YEAR_SHORT", String.valueOf(CommonHelper.getYear(beforeWorkingDate)).substring(2, 4));
		
		input.put("AFT_WORKING_DATE_DAY", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getDay(nextWorkingDate)), "0", 2, true));
		input.put("AFT_WORKING_DATE_MONTH", CommonHelper.fillCharacters(String.valueOf(CommonHelper.getMonth(nextWorkingDate)), "0", 2, true));
		input.put("AFT_WORKING_DATE_YEAR", CommonHelper.getYear(nextWorkingDate));
		input.put("AFT_WORKING_DATE_YEAR_SHORT", String.valueOf(CommonHelper.getYear(nextWorkingDate)).substring(2, 4));
		
		String uniqueNumber = getNextNumberForCorporate(corporateCode, processDate);
		input.put("UNQ_NUMBER_BY_DATE", uniqueNumber);
		if(uniqueNumber.length() == 1){
			uniqueNumber = "0".concat(uniqueNumber);
		}
		input.put("UNQ_NUMBER_BY_DATE_TWO", uniqueNumber);
		input.put("UNQ_NUMBER_BY_CORP", uniqueNumberByCorporate);
		input.put("UNQ_NUMBER_BY_CORP_TWO", CommonHelper.fillCharacters(uniqueNumberByCorporate, "0", 2, true));
		input.put("UNQ_NUMBER_BY_CORP_THREE", CommonHelper.fillCharacters(uniqueNumberByCorporate, "0", 3, true));
		input.put("UNQ_NUMBER_BY_CORP_FOUR", CommonHelper.fillCharacters(uniqueNumberByCorporate, "0", 4, true));
	}

	private String getUniqueNumberByCorporate(String corporateCode) throws Exception {
		return CorporationServiceUtil.getSequenceCode("NO_BY_CORP".concat(corporateCode.replaceAll("-", "")));
	}

	private Date getNextWorkingDate(Date fileDate) {
		Date processedDate = fileDate;
		
		do{
			processedDate = CommonHelper.addDay(processedDate, 1);
		}while(!CommonHelper.isWorkingDay(processedDate));
		
		return processedDate;
	}

	private Date getBeforeWorkingDate(Date fileDate) {
		Date processedDate = fileDate;
		
		do{
			processedDate = CommonHelper.addDay(processedDate, -1);
		}while(!CommonHelper.isWorkingDay(processedDate));
		
		return processedDate;
	}

	private String getNextNumberForCorporate(String corporateCode, Date processDate) throws Exception {
		return CorporationServiceUtil.getSequenceCode("NO_BY_CORP".concat(corporateCode.replaceAll("-", "")).concat(String.valueOf(CommonHelper.getDay(processDate))));
	}

	private void executeInformCollection(
			CorporateBatchInformation information) throws Exception {
		GMMap dbFieldsMap = new GMMap();
		for (ItemDatabaseField field : information.getDatabaseFields()) {
			dbFieldsMap.put(field.getOid(), field);
		}

		GMMap serviceFieldsMap = new GMMap();
		for (ItemServiceField field : information.getServiceFields()) {
			serviceFieldsMap.put(field.getOid(), field);
		}
		GMMap input = new GMMap();
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.DATABASE_FIELDS,
				dbFieldsMap);
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.SERVICE_FIELDS,
				serviceFieldsMap);
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.BODY_DETAILS,
				information.getBodyDetails());
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE,
				information.getCorporateCode());
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.FOOTER_DETAILS,
				information.getFooterDetails());
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.FTM_PROCESS_ID,
				information.getFtmProcessId());
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.HEADER_DETAILS,
				information.getHeaderDetails());
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE,
				information.getInvoiceDate());
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.INFORM_INDICATOR,
				information.getInformIndicator());
		input.put(
				TransactionConstants.CorporateGeneralBatchSubmit.Input.BATCH_INPUT,
				information.getBatchInput());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.BATCH_PARAMETERS, 
				information.getBatchParameters());
		
		logger.info("Calling corporate batch service for batch process");
		
		GMMap output = super.callGraymoundServiceOutsideSession(
				information.getServiceName(), input);
		if (!output
				.getBoolean(
						TransactionConstants.CorporateGeneralBatchSubmit.Output.RESULT,
						false)) {
			if (output
					.containsKey(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_CODE)
					&& output
							.containsKey(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_MESSAGE)) {
				if(GeneralConstants.NOT_PROCESS_WEEKEND_CODE.equals(output.getString(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_CODE))){
					bag.put(BagKeys.NOT_PROCESSED_DUE_TO_PARAMETER, "1");
				}
				else{
					throw new BatchComponentException(output.getString(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_MESSAGE),
							output.getInt(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_CODE));
				}
			} else {
				throw new Exception(
						String.format(
								"Generic inform invoice collection error for corporate with %s code. Please see logs for details.",
								information.getCorporateCode()));
			}
		}
		else{
			information.setTotalCount(output.getInt("TOTAL_COUNT"));
			information.setTotalAmount(output.getBigDecimal("TOTAL_AMOUNT"));
		}
	}

	private void callFtmForFileTransfer(GMMap input, String ftmId, BigDecimal ftmProcessId, int totalLineCount, short informIndicator) throws IOException {
		input.put("FILE_DEF_ID", Long.valueOf(ftmId));
		input.put("PROCESS_ID", ftmProcessId.longValue());
		
		if (informIndicator == GeneralConstants.INFORM_COLLECTIONS_WITH_EXCEL) {
			input.put("FILE_PART",0,"ID", 0);
			input.put("FILE_PART",0,"NAME", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "INVOICE_COLLECTION_WITH_EXCEL_SHEET_NAME"));
			input.put("FILE_PART",0,"ROW_COUNT", totalLineCount);
		}
		
		CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.FTM_CONNECTION_NAME, "BNSPR_FTM_CREATE_AND_TRANSFER_FILE", input);
	}

	private BigDecimal getNextValueOfProcessSequence() {
		return new BigDecimal(((Number) super.getHibernateSession()
				.createSQLQuery("SELECT ftm.seq_ftm_process.nextval FROM dual")
				.uniqueResult()).longValue());
	}

	private List<FormatDetail> callFormatServices(String serviceName,
			String formatOid, String outputKey) {
		GMMap formatDetails = super.callGraymoundServiceInSession(serviceName,
				new GMMap().put(TransactionConstants.FORMAT_ID_GENERAL_KEY,
						formatOid));
		@SuppressWarnings("unchecked")
		List<FormatDetail> detail = (List<FormatDetail>) formatDetails
				.get(outputKey);
		return detail;
	}

	@Override
	protected void handleError(Throwable e, GMMap output) {
		Long errorId = System.currentTimeMillis();
		logger.error("System exception is occured updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(), "0",
				e.toString());
		output.put(
				TransactionConstants.StartCorporateBatch.Output.RESULT,
				false);
		output.put(
				TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID,
				(String) super.bag.get(BagKeys.BATCH_SUBMIT_ID));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE,
				(String) super.bag.get(BagKeys.CORPORATE_CODE));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_CODE,
				"0");
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_MESSAGE,
				e.toString());
	}

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		Long errorId = System.currentTimeMillis();

		logger.error("Business exception is occured. Updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(),
				String.valueOf(e.getCode()), e.toString());
		output.put(
				TransactionConstants.StartCorporateBatch.Output.RESULT,
				false);
		output.put(
				TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID,
				(String) super.bag.get(BagKeys.BATCH_SUBMIT_ID));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE,
				(String) super.bag.get(BagKeys.CORPORATE_CODE));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_CODE,
				String.valueOf(e.getCode()));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_MESSAGE,
				e.toString());
	}
}
