package tr.com.aktifbank.bnspr.cps.transactions;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePaymentLog;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class InsertInvoicePaymentLogHandler extends RequestHandler {
	
	private static final Map<String, Method> paymentLogMethods;
	private static final Map<String, Method> gmMapMethods;
	
	static{
		paymentLogMethods = new ConcurrentHashMap<String, Method>();
		gmMapMethods = new ConcurrentHashMap<String, Method>();
		for (Method method : Arrays.asList(invoicePaymentLog.class.getMethods())) {
			paymentLogMethods.put(method.getName(), method);
		}
		for (Method method : Arrays.asList(GMMap.class.getMethods())) {
			if(method.getParameterTypes().length == 1){
				gmMapMethods.put(method.getName(), method);
			}
		}
	}

	public InsertInvoicePaymentLogHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		invoicePaymentLog log = new invoicePaymentLog();
		
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.TRX_NO, log, "TxNo");
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.INVOICE_MAIN_OID, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.COLLECTION_TYPE, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PAYMENT_AMOUNT, log);
		if(!"0".equals(input.getString(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_ACCOUNT_NO))){
			this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PAYMENT_ACCOUNT_NO, log);
		}
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.IBAN_NO, log, "Iban");
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.ACCOUNT_BALANCE, log);
		this.controlAndSet(input, "CASH_IDENTITY_TYPE", log);		
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PAYMENT_CARD_NO, log);
		this.controlAndSet(input, MapKeys.ACCOUNT_NO, log, "CorporateAccountNo");
		
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.SOURCE, log, "SourceCode");
		this.controlAndSet(input, MapKeys.CORPORATE_NAME, log);
		this.controlAndSet(input, MapKeys.COMMISION_AMOUNT, log);
		this.controlAndSet(input, MapKeys.BSMV_AMOUNT, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.BRANCH_CODE, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.CUSTOMER_NO, log, "PayerCustomer");
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.ACCOUNT_CURRENCY_CODE, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.COLLECTION_TYPE_NAME, log, "CollectionTypeText");
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.INVOICE_NO, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.INVOICE_DUE_DATE, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.INSTALLMENT_NO, log);
		
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.SUB_COLLECTION_TYPE, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO1, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO2, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO3, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO4, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.STANDING_ORDER_OID, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.INVOICE_AMOUNT, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PARAMETER1, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PARAMETER2, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PARAMETER3, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PARAMETER4, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PARAMETER5, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PARAMETER6, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PARAMETER7, log);
		this.controlAndSet(input, MapKeys.PARAMETER8, log);
		this.controlAndSet(input, MapKeys.PARAMETER9, log);
		this.controlAndSet(input, MapKeys.PARAMETER10, log);
		this.controlAndSet(input, MapKeys.PARAMETER11, log);
		this.controlAndSet(input, MapKeys.PARAMETER12, log);
		this.controlAndSet(input, MapKeys.PARAMETER13, log);
		this.controlAndSet(input, MapKeys.PARAMETER14, log);
		this.controlAndSet(input, MapKeys.PARAMETER15, log);
		this.controlAndSet(input, MapKeys.PARAMETER16, log);
		this.controlAndSet(input, MapKeys.PARAMETER17, log);
		this.controlAndSet(input, MapKeys.PARAMETER18, log);
		this.controlAndSet(input, MapKeys.PARAMETER19, log);
		this.controlAndSet(input, MapKeys.PARAMETER20, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.CORPORATE_CODE, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.TERM_YEAR, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.TERM_MONTH, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.ACCOUNT_AVAILABLE_BALANCE, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.PAYER_NAME, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NAME, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.QUERY_REF_NO, log);
		this.controlAndSet(input, TransactionConstants.DoInvoiceCollection.Input.INVOICE_DATE, log);
		this.controlAndSet(input, "CRD_MERCHANT_CODE", log);
		
		log.setStatus(true);

		log.setTransactionStatus(DatabaseConstants.TransactionStatuses.New);
		
		String channelId = null;
		
		if(input.containsKey(TransactionConstants.DoInvoiceCollection.Input.CHANNEL_CODE)){
			channelId = input.getString(TransactionConstants.DoInvoiceCollection.Input.CHANNEL_CODE);
		}
		else{
			channelId = CommonHelper.getChannelId();
		}
		
//		if(input.getString(TransactionConstants.DoInvoiceCollection.Input.SOURCE).equals(DatabaseConstants.SourceCodes.Cash)){
//			log.setPaymentInput(new ClobImpl(CommonHelper.serializeRequest(input)));
//		}
		
		if(!StringUtil.isEmpty(input.getString("AGENT_CODE", null))){
			log.setAgentCode(input.getString("AGENT_CODE"));
		}
		
		if(input.containsKey("CASH_TRX_NO")){
			log.setCashTrxNo(input.getBigDecimal("CASH_TRX_NO"));
		}
		
		log.setChannelCode(channelId);
		
		log.setUserCode(CommonHelper.getCurrentUser());
		log.setProcessDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
		log.setCallCorporate(false);
		
		super.getHibernateSession().save(log);
		super.getHibernateSession().flush();

	}
	
	private void controlAndSet(GMMap input, String key, Object pojo){
		this.controlAndSet(input, key, pojo, null);
	}
	
	private void controlAndSet(GMMap input, String key, Object pojo, String pojoProperty){
		try {
			if(input.containsKey(key)){
				String setMethodName = "";
				if(!StringUtil.isEmpty(pojoProperty)){
					setMethodName = String.format("set%s", pojoProperty);
				}
				else{
					setMethodName = "set";
					String[] splittedString = key.split("_");
					for (int i = 0; i < splittedString.length; i++) {
						String currentString = splittedString[i].toLowerCase(Locale.ROOT);
						setMethodName += String.valueOf(currentString.charAt(0)).toUpperCase(Locale.ROOT).concat(currentString.substring(1));
					}
				}
				Method currentMethod = paymentLogMethods.get(setMethodName);
				if(currentMethod != null){
					Class<?> parameterType = currentMethod.getParameterTypes()[0];
					if(parameterType != null){
						Object value = getValueFromGMMap(input, key, parameterType);
						if(value != null){
							currentMethod.invoke(pojo, value);
						}
					}
				}
			}
		}
		catch (Exception e) {
			logger.error(String.format("An exception occured while setting %s property of pojo", key));
			logger.error(System.currentTimeMillis(), e);
		}
	}

	private Object getValueFromGMMap(GMMap input, String key,
			Class<?> parameterType) throws Exception {
		String simpleName = parameterType.getSimpleName();
		String methodModifiedName = String.valueOf(simpleName.charAt(0)).toUpperCase(Locale.ROOT).concat(simpleName.substring(1));
		boolean shortValue = false;
		if(methodModifiedName.equals("Integer")){
			methodModifiedName = "Int";
		}
		else if(methodModifiedName.equals("Short")){
			shortValue = true;
			methodModifiedName = "Int";
		}
		Method currentMethod = gmMapMethods.get(String.format("get%s", methodModifiedName));
		if (currentMethod != null) {
			Object value = currentMethod.invoke(input, key);
			if(shortValue){
				return Short.valueOf(value.toString());
			}
			else{
				return value;
			}
		}
		else{
			return null;
		}
	}

}
