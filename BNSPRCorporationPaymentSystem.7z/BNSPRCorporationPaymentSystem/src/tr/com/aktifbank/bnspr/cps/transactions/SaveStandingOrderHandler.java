package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.SaveStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.SaveStandingOrderComm;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class SaveStandingOrderHandler extends RequestHandler {

	public SaveStandingOrderHandler() {
		super();
	}

	@SuppressWarnings("unused")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		GMMap outputMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		// /////////get inputs
		String corporateOid = input.getString(SaveStandingOrder.Input.CORPORATE_OID, null);
		String corporateCode = input.getString(SaveStandingOrder.Input.CORPORATE_CODE, null);
		String type = input.getString(SaveStandingOrder.Input.TYPE);
		String trxNo = input.getString(SaveStandingOrder.Input.TRX_NO);
		String customerNo = input.getString(SaveStandingOrder.Input.CUSTOMER_NO);
		String orderOwner = input.getString(SaveStandingOrder.Input.ORDER_OWNER);
		String city = input.getString(SaveStandingOrder.Input.CITY);
		String collectionType = input.getString(SaveStandingOrder.Input.COLLECTION_TYPE, String.valueOf(GeneralConstants.COLLECTION_TYPE_NOT_MENTIONED));
		String paymentChannel = input.getString(SaveStandingOrder.Input.PAYMENT_CHANNEL);
		String accountNumber = input.getString(SaveStandingOrder.Input.ACCOUNT_NUMBER);
		String standingOrderName = input.getString(SaveStandingOrder.Input.STANDING_ORDER_NAME);
		String startDate = input.getString(SaveStandingOrder.Input.START_DATE);
		String endDate = input.getString(SaveStandingOrder.Input.END_DATE);
		String orderStatus = input.getString(SaveStandingOrder.Input.ORDER_STATUS);
		String iban = input.getString(SaveStandingOrder.Input.IBAN);
		String orderNumber = input.getString(SaveStandingOrder.Input.ORDER_NUMBER);
		String phoneNumber = input.getString(SaveStandingOrder.Input.PHONE_NUMBER);
		String email = input.getString(SaveStandingOrder.Input.EMAIL);
		String beforePayment = input.getString(SaveStandingOrder.Input.BEFORE_PAYMENT);
		String afterPayment = input.getString(SaveStandingOrder.Input.AFTER_PAYMENT);
		String notifyBySms = input.getString(SaveStandingOrder.Input.NOTIFY_BY_SMS);
		String notifyByEmail = input.getString(SaveStandingOrder.Input.NOTIFY_BY_EMAIL);
		String checkResult = input.getString(SaveStandingOrder.Input.CHECK_RESULT);
		String channelCode = input.getString(SaveStandingOrder.Input.CHANNEL_CODE, null);
		String cardNo = input.getString("CARD_NUMBER", null);
		boolean accFirst = input.getBoolean("ACC_FIRST", true);
		boolean cardFirst = input.getBoolean("CARD_FIRST", false);
		// /////////

		// /////////variable definitions
		String standingOrderMainOid = "";
		String corporateActiveness = "";
		String corporateName = "";
		String bankCode = "";
		String username = "";
		String crDate = "";
		String nextStatus = DatabaseConstants.StandingOrderStatus.Active;
		GMMap corpDefMap = null;
		GMMap cdMap = null;
		GMMap somSaveInputMap = null;
		GMMap somSaveOutMap = null;
		GMMap commInputMap = null;
		GMMap soaSaveInputMap = null;
		GMMap soaSaveOutMap = null;
		GMMap transactionImputMap = null;
		GMMap icsOutputMap = null;
		GMMap transactionOutputMap = null;
		boolean isOnlineCorporate = false;
		String icsStandingOrderOid = "";
		// /////////

		BigDecimal customerNoOfAccount = CommonBusinessOperations.getCustomerNoOfAccount(new BigDecimal(accountNumber));
		if (customerNoOfAccount == null || customerNoOfAccount.compareTo(new BigDecimal(customerNo)) != 0)
			CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.EMPTYMESSAGE, 
					String.format("%s nolu hesap %s nolu m��teriye ait de�ildir", accountNumber, customerNo)));			
		
		// /////////get corporate definition to get corporateCode
		corpDefMap = new GMMap();
		if (!StringUtil.isEmpty(corporateOid)) {
			corpDefMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid);
		} else {
			corpDefMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
		}
		cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", corpDefMap);
		collectionType = String.valueOf(CommonBusinessOperations.manipulateCollectionTypeForChannels(Short.valueOf(collectionType), cdMap.getString(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID)));

		corporateCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
		corporateActiveness = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_ACTIVENESS);
		corporateName = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_NAME);

		GMMap inputControlSubscriberMap = new GMMap();
		inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.CHANNEL_CODE, channelCode);
		inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.COLLECTION_TYPE, collectionType);
		inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.CORPORATE_CODE, corporateCode);
		inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO1, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO1));
		inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO2, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO2));
		inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO3, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO3));
		inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO4, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO4));
		inputControlSubscriberMap.put("METADATA_TYPE", DatabaseConstants.MetadataTypes.StandingOrder);

		GMMap outputControlSubscriberMetaDataMap = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.ControlSubscriberMetaData.SERVICE_NAME, inputControlSubscriberMap);

		CommonHelper.makeSubscriberNoMask(input, outputControlSubscriberMetaDataMap);

		if (cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.IS_ONLINE_CORPORATE).equals("1")) {
			isOnlineCorporate = true;
		} else {
			isOnlineCorporate = false;
		}

		bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
		// /////////

		if (type.equals("KFT")) {
			GMMap checkSubscriberInputMap = new GMMap();
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.BANK_CODE, bankCode);
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.CORPORATE_CODE, corporateCode);
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.OPERATION, "INSERT");
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.COLLECTION_TYPE, collectionType);
			checkSubscriberInputMap.put(MapKeys.SUBSCRIBER_NO1, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO1));
			checkSubscriberInputMap.put(MapKeys.SUBSCRIBER_NO2, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO2));
			checkSubscriberInputMap.put(MapKeys.SUBSCRIBER_NO3, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO3));
			checkSubscriberInputMap.put(MapKeys.SUBSCRIBER_NO4, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO4));
			GMMap checkSubscriberMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_CHECK_SUBSCRIBER_PRE_STANDING_ORDER", checkSubscriberInputMap);
		}

		username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		crDate = CommonHelper.getLongDateTimeString(new Date());

		// /////////save standing order main
		somSaveInputMap = new GMMap();
		somSaveOutMap = new GMMap();
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.AFTER_PAYMENT, afterPayment);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.BEFORE_PAYMENT, beforePayment);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.CITY, city);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.CR_DATE, crDate);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.CUSTOMER_NO, customerNo);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.END_DATE, endDate);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.NOTIFY_BY_EMAIL, notifyByEmail);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.NOTIFY_BY_SMS, notifyBySms);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.ORDER_STATUS, orderStatus);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.PAYMENT_CHANNEL, paymentChannel);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.STANDING_ORDER_NAME, standingOrderName);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.START_DATE, startDate);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.TRX_NO, trxNo);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.TYPE, type);
		somSaveInputMap.put(TransactionConstants.SaveStandingOrderMain.Input.USER_NAME, username);
		somSaveOutMap = super.callGraymoundServiceInSession("CDM_SAVE_STANDING_ORDER_MAIN", somSaveInputMap);
		standingOrderMainOid = somSaveOutMap.getString(TransactionConstants.SaveStandingOrderMain.Output.STANDING_ORDER_MAIN_OID);
		// /////////

		// /////////save standing order account
		soaSaveInputMap = new GMMap();
		soaSaveOutMap = new GMMap();
		soaSaveInputMap.put(TransactionConstants.SaveStandingOrderAccount.Input.ACCOUNT_NUMBER, accountNumber);
		soaSaveInputMap.put(TransactionConstants.SaveStandingOrderAccount.Input.IBAN, iban);
		soaSaveInputMap.put(TransactionConstants.SaveStandingOrderAccount.Input.STANDING_ORDER_MAIN_OID, standingOrderMainOid);
		soaSaveInputMap.put("COLLECTION_CARD_NO", cardNo);
		soaSaveInputMap.put("PRIORITY", accFirst ? DatabaseConstants.StandingOrderSourcePriorities.AccountFirst : DatabaseConstants.StandingOrderSourcePriorities.CardFirst);
		soaSaveInputMap.put(MapKeys.TRX_NO, trxNo);
		soaSaveOutMap = super.callGraymoundServiceInSession("CDM_SAVE_STANDING_ORDER_ACCOUNT", soaSaveInputMap);
		// /////////

		if (type.equals("KFT")) {
			// /////////save ics standing order
			GMMap icsInputMap = new GMMap();
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.CORPORATE_CODE, corporateCode);
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.CUSTOMER_NO, customerNo);
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.COLLECTION_TYPE, collectionType);
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.STANDING_ORDER_MAIN_OID, standingOrderMainOid);
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.SUBSCRIBER_NO1, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO1));
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.SUBSCRIBER_NO2, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO2));
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.SUBSCRIBER_NO3, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO3));
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.SUBSCRIBER_NO4, input.getString(SaveStandingOrder.Input.SUBSCRIBER_NO4));
			icsInputMap.put(TransactionConstants.IcsSaveStandingOrder.Input.TRX_NO, trxNo);
			icsOutputMap = super.callGraymoundServiceInSession("ICS_SAVE_STANDING_ORDER", icsInputMap);
			icsStandingOrderOid = icsOutputMap.getString("ICS_STANDING_ORDER_OID");
			// /////////

			// /////////save standing order comm
			commInputMap = new GMMap();
			commInputMap.put(SaveStandingOrderComm.Input.E_MAIL, email);
			commInputMap.put(SaveStandingOrderComm.Input.PHONE_NUMBER, phoneNumber);
			commInputMap.put(SaveStandingOrderComm.Input.STANDING_ORDER_MAIN_OID, standingOrderMainOid);
			commInputMap.put(MapKeys.TRX_NO, trxNo);
			GMMap commOutputMap = super.callGraymoundServiceInSession("SAVE_STANDING_ORDER_COMM", commInputMap);
		}

		// /////////send transaction
		transactionImputMap = new GMMap();
		transactionImputMap.put("TRX_NAME", "7003");
		transactionImputMap.put("TRX_NO", trxNo);
		transactionOutputMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", transactionImputMap);
		// /////////

		output.put(SaveStandingOrder.Output.STANDING_ORDER_MAIN_OID, standingOrderMainOid);
		output.put("RESULT_MSG", transactionOutputMap.getString("MESSAGE"));
	}
}
