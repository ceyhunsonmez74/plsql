package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.dao.WsSaf;

import com.graymound.util.GMMap;

public final class SafReporterHandler extends RequestHandler {

	public SafReporterHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Date processDate = new Date();
		
		int minutesToCheck = -1 * Integer.valueOf(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "SAF_REPORT_MINUTES"));
		
		Calendar defaultCalendar = Calendar.getInstance();
		defaultCalendar.setTime(processDate);
		defaultCalendar.add(Calendar.MINUTE, minutesToCheck);
		processDate = defaultCalendar.getTime();
		
		long timeToCheck = Long.valueOf(CommonHelper.getLongDateTimeString(processDate));
		
		List<WsSaf> safRecords = super.getHibernateSession().createCriteria(WsSaf.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("sendStatus", "88"))
				.add(Restrictions.ge("firstSendDate", timeToCheck))
				.list();
		
		if(safRecords.size() > 0){
			GMMap mailMap = new GMMap();
			mailMap.put("PROCESS_DATE", CommonHelper.getDateString(processDate, "dd/MM/yyyy"));
			List<Map<String, String>> detailMapList = new ArrayList<Map<String,String>>();
			for (WsSaf wsSaf : safRecords) {
				Map<String, String> detailMap = new HashMap<String, String>();
				String corporateName = CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(wsSaf.getCorporateCode());
				detailMap.put("ROW_CORPORATE_NAME", corporateName);
				detailMap.put("ROW_SERVICE_NAME", wsSaf.getWebServiceName());
				detailMap.put("ROW_ERROR_CODE", wsSaf.getErrorCode());
				detailMap.put("ROW_ERROR_DESC", wsSaf.getErrorDesc());
				int clobLength = (int)wsSaf.getParametersString().length();
				detailMap.put("ROW_PARAMETERS", wsSaf.getParametersString().getSubString(1, clobLength));
				detailMapList.add(detailMap);
			}
			
			mailMap.put("MAP_TABLE", detailMapList);
			
			EmailMessage emailMessage = CommonHelper.prepareEmailBody("", mailMap, NotificationMessageConstant.Email.SafReporterMessageConstant.MESSAGE_BODY, 
					CommonHelper.generateSubject(NotificationMessageConstant.Email.SafReporterMessageConstant.SUBJECT,mailMap), 
					CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST","EMAIL_RECEIPT_LIST_4_SAF_REPORT"));
			
			CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
		}
	}

}
