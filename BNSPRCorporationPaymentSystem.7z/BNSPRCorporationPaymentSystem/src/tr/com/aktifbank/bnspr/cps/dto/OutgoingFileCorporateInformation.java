package tr.com.aktifbank.bnspr.cps.dto;

public final class OutgoingFileCorporateInformation extends
		BaseTransferObject {

	public OutgoingFileCorporateInformation() {
		super();
	}

	private String corporateCode;
	private String ftmId;
	private String formatId;
	private String batchName;
	private String transferType;
	private String fileTransferId;
	
	public String getTransferType() {
		return transferType;
	}
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}
	public String getFileTransferId() {
		return fileTransferId;
	}
	public void setFileTransferId(String fileTransferId) {
		this.fileTransferId = fileTransferId;
	}
	public String getCorporateCode() {
		return corporateCode;
	}
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	public String getFtmId() {
		return ftmId;
	}
	public void setFtmId(String ftmId) {
		this.ftmId = ftmId;
	}
	public String getFormatId() {
		return formatId;
	}
	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}
	public String getBatchName() {
		return batchName;
	}
	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}
}
