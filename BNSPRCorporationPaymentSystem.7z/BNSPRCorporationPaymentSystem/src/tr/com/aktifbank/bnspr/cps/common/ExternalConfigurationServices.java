package tr.com.aktifbank.bnspr.cps.common;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.Channelinformation;
import tr.com.aktifbank.bnspr.dao.ChannelinformationDetail;
import tr.com.aktifbank.bnspr.dao.ExtChannelConfiguration;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class ExternalConfigurationServices {
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_EXTERNAL_GET_CHANNEL_CONFIGURATION")
	public static GMMap getChannelConfiguration(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String channel = input.getString("CHANNEL");
			String domain = input.getString("DOMAIN");
			String methodName = input.getString("METHOD");
			
			Session session = CommonHelper.getHibernateSession();
			
			ExtChannelConfiguration chConfiguration = (ExtChannelConfiguration) session.createCriteria(ExtChannelConfiguration.class)
					.add(Restrictions.eq("channelKey", channel))
					.add(Restrictions.eq("domainName", domain))
					.uniqueResult();
			
			if(chConfiguration != null){
				session.setReadOnly(chConfiguration, true);
				
				output.put("CONN_NAME", chConfiguration.getConnName());
				output.put("HANDLER_QUALIFIED_NAME", chConfiguration.getHandlerQuName());
				
				Channelinformation info = (Channelinformation) session.createCriteria(Channelinformation.class)
						.add(Restrictions.eq("channelKey", channel))
						.add(Restrictions.eq("domainName", domain))
						.add(Restrictions.eq("methodName", methodName))
						.uniqueResult();
				
				if(info != null){
					session.setReadOnly(info, true);
					
					List<ChannelinformationDetail> details = session.createCriteria(ChannelinformationDetail.class)
							.add(Restrictions.eq("channelInfOid", info.getOid()))
							.list();
					GMMap keyValueMap = new GMMap();
					
					for (ChannelinformationDetail detail : details) {
						session.setReadOnly(detail, true);
						
						keyValueMap.put(detail.getKey(), detail.getValue());
					}
					
					if(keyValueMap.keySet().size() > 0){
						output.put("KEY_VALUE_MAP", keyValueMap);
					}
					
				}
			}
			else{
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, String.format("%s kanal ve %s domain'i i�in kanal konfig�rasyonu bulunamam��t�r.",
						channel, domain));
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}
