package tr.com.aktifbank.bnspr.cps.multithreading.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.KeyValuePair;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.ParallelCallResult;

import com.graymound.util.GMMap;

public abstract class ServiceBasedMultiThreading {
	
	protected static final Log logger = LogFactory.getLog(ServiceBasedMultiThreading.class);
	
	private Map<Integer, KeyValuePair<String, GMMap>> serviceInputMap;
	private Map<Integer, KeyValuePair<String, GMMap>> serviceOutputMap;
	private boolean hasError;
	private String errorCode;
	private String errorMessage;
	private int index;
	
	protected List<GMMap> getServiceOutputs(){
		List<GMMap> outputs = new ArrayList<GMMap>();
		
		for(Map.Entry<Integer, KeyValuePair<String, GMMap>> entry : serviceOutputMap.entrySet()){
			outputs.add(entry.getValue().getValue());
		}
		
		return outputs;
	}
	
	protected List<KeyValuePair<String, GMMap>> getServiceOutputMap() {
		return new ArrayList<KeyValuePair<String, GMMap>>(this.serviceOutputMap.values());
	}

	protected void setHasError(boolean hasError) {
		this.hasError = hasError;
	}

	protected void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	protected void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public boolean isHasError() {
		return hasError;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public ServiceBasedMultiThreading() {
		this.serviceInputMap = new HashMap<Integer, KeyValuePair<String, GMMap>>();
		this.serviceOutputMap = new HashMap<Integer, KeyValuePair<String, GMMap>>();
		this.hasError = false;
		this.index = 0;
	}
	
	protected int registerService(String serviceName, GMMap input){
		this.serviceInputMap.put(index, new KeyValuePair<String, GMMap>(serviceName, input));;
		return index++;
	}
	
	protected abstract void prepareCall() throws Throwable;
	
	protected void afterCall() throws Throwable{
		
	}
	
	protected ParallelCallBehaviour getParallelCallBehaviour(){
		return new DefaultParallelCallBehaviour(); 
	}
	
	public void execute(){
		try {
			logger.info("Starting for prepare call");
			this.prepareCall();
			logger.info("Prepare call succeed");
		} catch (Throwable e) {
			logger.error("An exception occured while preparing parallel call");
			logger.error(e);
			this.hasError = true;
			this.errorCode = String.valueOf(BusinessException.PARALLELCALLPREPAREFAILED.getCode());
			this.errorMessage = e.toString();
			return;
		}
		
		List<GMMap> tasks = new ArrayList<GMMap>();
		for(Map.Entry<Integer, KeyValuePair<String, GMMap>> entry : this.serviceInputMap.entrySet()){
			entry.getValue().getValue().put(TransactionConstants.ParallelCall.Input.T_SERVICE_NAME, entry.getValue().getKey());
			tasks.add(entry.getValue().getValue());
		}
		
		ParallelCallBehaviour behaviour = this.getParallelCallBehaviour();
		logger.info("Starting for parallel call");
		behaviour.call(tasks);
		logger.info("Parallel call is finished");
		ParallelCallResult result = behaviour.getResult();
		
		if(result.isAllSuccessful()){
			logger.info("Parallel call is successful");
			this.hasError = false;
		}
		else{
			logger.info("Parallel call has error");
			this.hasError = true;
			this.errorCode = String.valueOf(BusinessException.SYSTEM.getCode());
			this.errorMessage = "Generic parallel service exception. See log for details";
		}
		
		if (!hasError) {
			List<GMMap> outputs = result.getResults();
			for (GMMap output : outputs) {
				this.serviceOutputMap.put(output.getInt(TransactionConstants.ParallelCall.Output.T_TASK_INDEX), 
						new KeyValuePair<String, GMMap>(output.getString(TransactionConstants.ParallelCall.Output.T_SERVICE_NAME),
						output));
			}
		}
		try {
			logger.info("Starting for after call");
			this.afterCall();
			logger.info("After call finished");
		} catch (Throwable e) {
			logger.error("An exception occured while executing after call");
			logger.error(e);
			this.hasError = true;
			this.errorCode = String.valueOf(BusinessException.PARALLELCALLAFTERCALLFAILED.getCode());
			this.errorMessage = e.toString();
		}
	}
}
