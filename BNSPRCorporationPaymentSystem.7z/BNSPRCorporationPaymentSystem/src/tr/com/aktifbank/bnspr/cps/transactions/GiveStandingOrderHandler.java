package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.invoicePaymentLog;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public final class GiveStandingOrderHandler extends RequestHandler {

	public GiveStandingOrderHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		
	}

	private String getCollectionName(short collectionType) {
		return DALUtil.getResult(String.format("SELECT COLLECTION_NAME FROM COLLECTION_TYPE_PRM WHERE COLLECTION_TYPE = %s", collectionType));
	}

	private void insertInvoicePaymentLog(String sourceCode, String channelId,
			short collectionType, BigDecimal transactionNo,
			String invoiceMainOid, BigDecimal paymentAmount,
			BigDecimal paymentAccountNo, String iban,
			BigDecimal accountBalance, String paymentCardNo,
			BigDecimal commissionAmount, String branchCode,
			BigDecimal payerCustomer, String payerPhone, String payerPidno,
			String payerTaxNo, GMMap accountControlResult, BigDecimal bsmvAmount, String accountCurrencyCode,
			String collectionTypeText, String corporateName) {
		invoicePaymentLog log = new invoicePaymentLog();
		log.setStatus(true);
		log.setTxNo(transactionNo);
		log.setInvoiceMainOid(invoiceMainOid);
		log.setCollectionType(collectionType);
		log.setTransactionStatus(DatabaseConstants.TransactionStatuses.New);
		log.setPaymentAmount(paymentAmount);
		log.setPaymentAccountNo(paymentAccountNo);
		log.setIban(iban);
		log.setAccountBalance(accountBalance);
		log.setPaymentCardNo(paymentCardNo);
		log.setCommissionAmount(commissionAmount);
		log.setCorporateAccountNo(accountControlResult.getBigDecimal(TransactionConstants.CorporateAccountControl.Output.ACCOUNT_NO));
		log.setChannelCode(channelId);
		log.setBranchCode(branchCode);
		log.setSourceCode(sourceCode);
		log.setUserCode(CommonHelper.getCurrentUser());
		log.setProcessDate(CommonHelper.getLongDateTimeString(new Date()));
		log.setPayerCustomer(payerCustomer);
		log.setPayerPhone(payerPhone);
		log.setPayerPidno(payerPidno);
		log.setPayerTaxNo(payerTaxNo);
		log.setBsmvAmount(bsmvAmount);
		log.setAccountCurrencyCode(accountCurrencyCode);
		log.setCollectionTypeText(collectionTypeText);
		log.setCorporateName(corporateName);
		
		super.getHibernateSession().save(log);
		super.getHibernateSession().flush();
	}

}
