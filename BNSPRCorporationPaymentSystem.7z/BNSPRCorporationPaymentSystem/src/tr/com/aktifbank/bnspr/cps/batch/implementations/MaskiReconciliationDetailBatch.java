package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.maski.MaskiClient;
import tr.com.aktifbank.integration.maski.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.maski.MakbuzBilgisiApi;
import tr.com.maski.TahsilatGunlukListeApiCType;

import com.graymound.util.GMMap;

public final class MaskiReconciliationDetailBatch extends CollectionReconciliationDetailBatch{
	private static final Log logger = LogFactory.getLog(CLKReconciliationDetailBatch.class);
	Session session;
	TahsilatGunlukListeApiCType gunlukListe = new TahsilatGunlukListeApiCType();
	List<MakbuzBilgisiApi> detailsMakbuzBilgisi = new ArrayList<MakbuzBilgisiApi>();
	ServiceMessage message;
	Map<String, MakbuzBilgisiApi> indexedCorporateRecords;
	
	public MaskiReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, MakbuzBilgisiApi>();
		session = CommonHelper.getHibernateSession();
	}
	
	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.SUBSCRIBER_NO1, detailsMakbuzBilgisi.get(corporateRecordIndex).getAboneKodu());
		cancelCollectionRequest.put(MapKeys.SUBSCRIBER_NO2, detailsMakbuzBilgisi.get(corporateRecordIndex).getSicilKodu());
		cancelCollectionRequest.put(MapKeys.PARAMETER2, detailsMakbuzBilgisi.get(corporateRecordIndex).getTahsilatId());//getPaymentId
		cancelCollectionRequest.put(MapKeys.TRX_NO, detailsMakbuzBilgisi.get(corporateRecordIndex).getOdemeNo());
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, detailsMakbuzBilgisi.get(corporateRecordIndex).getOdemeNo());		
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
//			Integer bankCode = Integer.parseInt(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
//			Integer companyCode = Integer.parseInt(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			Long kurumKodu = Long.parseLong(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			String apiKey = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String serviceUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			Date reconDate = new Date();
			if (!StringUtil.isEmpty(input.getString(MapKeys.RECON_DATE)))
				reconDate = input.getDate(MapKeys.RECON_DATE);

//			Date date = new Date();
			Calendar calendar = new GregorianCalendar();
			calendar.setTime(reconDate);
			Integer yil = calendar.get(Calendar.YEAR);
			Integer ay = calendar.get(Calendar.MONTH) + 1;
			Integer gun = calendar.get(Calendar.DAY_OF_MONTH);
			
//			Date collectionDate = new SimpleDateFormat("dd/MM/yyyy").parse("COLLECTION_DATE");
//			Date reconDate = new Date();
//			if (!StringUtil.isEmpty(input.getString(MapKeys.RECON_DATE)))
//				reconDate= input.getDate(MapKeys.RECON_DATE);
			
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			
			String responseCode = "";
			String responseMessage = "";
			TahsilatGunlukListeApiCType response = new TahsilatGunlukListeApiCType();
			List<MakbuzBilgisiApi> makbuzBilgisiApiList = null;


			response = MaskiClient.collectionReconciliationDetail(serviceUrl, apiKey, kurumKodu, yil, ay, gun, serviceMessage);
			responseCode = response.getGeriBildirim().getKodu().toString();
			responseMessage = response.getGeriBildirim().getAciklama();
			
			makbuzBilgisiApiList = response.getMakbuzBilgisiApiList();
			List<MakbuzBilgisiApi> paymentList= new ArrayList<MakbuzBilgisiApi>();
			List<MakbuzBilgisiApi> cancelList= new ArrayList<MakbuzBilgisiApi>();

			for (int i = 0; i < makbuzBilgisiApiList.size(); i++) {
				if (makbuzBilgisiApiList.get(i).getIptalDurumu().isEmpty() || makbuzBilgisiApiList.get(i).getIptalDurumu() == null) {
					paymentList.add(makbuzBilgisiApiList.get(i));
				}
			}
			for (int i = 0; i < makbuzBilgisiApiList.size(); i++) {
				if (!makbuzBilgisiApiList.get(i).getIptalDurumu().isEmpty() && makbuzBilgisiApiList.get(i).getIptalDurumu() != null) {
					cancelList.add(makbuzBilgisiApiList.get(i));
				}
			}
			
//			for (int i = 0; i < makbuzBilgisiApiList.size(); i++) {
//				if (makbuzBilgisiApiList.get(i).getIptalDurumu().equals("IPTAL")) {
//					cancelList.add(makbuzBilgisiApiList.get(i));
//				}	
//			}
//			
//			
//			for (int i = 0; i < paymentList.size(); i++) {
//				for (int j = 0; j < cancelList.size(); j++) {
//					if (paymentList.get(i).getIslemReferansNo().equals(cancelList.get(j).getIslemReferansNo())) {
//						paymentList.remove(i);
//					}
//				}		
//			}
			
			detailsMakbuzBilgisi = paymentList;
			result.setSuccessfulCall(true);
		}
		catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < detailsMakbuzBilgisi.size(); i++) {
			this.indexedCorporateRecords.put(this.detailsMakbuzBilgisi.get(i).getTahsilatId().toString(), this.detailsMakbuzBilgisi.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.detailsMakbuzBilgisi.get(corporateRecordIndex).getTahsilatId().toString());
	}
	
    @Override
    protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
                throws Exception {
    	  MakbuzBilgisiApi corporateDetail = detailsMakbuzBilgisi.get(corporateRecordIndex);
          String aboneNo = corporateDetail.getAboneKodu().toString();
          String sicilNo = corporateDetail.getSicilKodu().toString();
          
                      
          logger.info(String.format("Following corporate record has not been found in database. Referans No : %s, Miktar : %s ",  
                      corporateDetail.getTahsilatId(), 
                      corporateDetail.getMakbuzToplam()));
          
          invoicePayment payment = new invoicePayment();
          payment.setStatus(true);
          payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
          payment.setCollectionType(Short.valueOf("0"));
          payment.setInvoiceMainOid("0");
          payment.setSubscriberNo1(aboneNo);
          payment.setSubscriberNo2(sicilNo);
          payment.setInvoiceNo("1");
          payment.setPaymentStatus(PaymentStatuses.Cancelled);
          payment.setTxNo(new BigDecimal("-1"));
          payment.setInvoiceAmount(corporateDetail.getMakbuzToplam());
          payment.setPaymentAmount(corporateDetail.getMakbuzToplam());
          payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
          payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
          payment.setParameter1(aboneNo);
          payment.setParameter2(corporateDetail.getTahsilatId().toString());
          
          session.saveOrUpdate(payment);
          session.flush();
          
          collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, aboneNo);
          collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO2, sicilNo);
          collectionDetailResponse.put(MapKeys.INVOICE_NO, "");
          collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
          collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getMakbuzToplam());
    }
}
