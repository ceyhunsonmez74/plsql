package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ControlEndOfDayHandler extends RequestHandler {
	private static final Log logger = LogFactory.getLog(ControlEndOfDayHandler.class);

	public ControlEndOfDayHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		try {
			String isEodControlActive = CommonHelper.getValueOfParameter("ICS_COLLECTION_CONTROLLER_PARAMS", "IS_EOD_CONTROL_ACTIVE");
			String eodStartTime = CommonHelper.getValueOfParameter("ICS_COLLECTION_CONTROLLER_PARAMS", "EOD_START_TIME");
			if ("YES".equals(isEodControlActive)) {
				logger.info(String.format("ICS_CONTROL_END_OF_DAY_CHECK -> inputs > EOD_START_TIME=%s - IS_EOD_CONTROL_ACTIVE=%s ",eodStartTime,isEodControlActive));
				GregorianCalendar calendar = new GregorianCalendar();
				String controlSql = "select * from gnl_sistem_bilgi_pr";
				String TABLE_NAME = "END_OF_DAY_CHECK";
				String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
				String eodFlag = "1";
				String instOid = input.getString("INSTITUTION_OID");
				CorporateMaster corpMaster = null;
				boolean useOid = false;
				if (instOid != null) {
					if (!"".equals(instOid)) {
						if (instOid.contains("|")) {
							String[] dizi = instOid.split("\\|");
							instOid = dizi[0];
							logger.info("ICS_CONTROL_END_OF_DAY_CHECK will use oid = ".concat(instOid));
						}else{
							instOid = input.getString("INSTITUTION_OID");
						}
						useOid = true;
					}
				}
				Session session = DAOSession.getSession("BNSPRDal");
				if (useOid) {
					logger.info("ICS_CONTROL_END_OF_DAY_CHECK will use OID");
					corpMaster = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("oid", instOid)).add(Restrictions.eq("eodFlag", eodFlag)).uniqueResult();
				}else{
					logger.info("ICS_CONTROL_END_OF_DAY_CHECK will use Corporate Code");
					corpMaster = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("eodFlag", eodFlag)).uniqueResult();					
				}
				// if eod flag is 0 means dont care to EOD
				if (corpMaster == null) {
					output.put("EOD_CHECK", true);
					logger.info("ICS_CONTROL_END_OF_DAY_CHECK corporate master is null so return value is true");
				} else {
					// else check if EOD is started and its before midnight
					GMMap returnMap = DALUtil.getResults(controlSql, TABLE_NAME);
					if (returnMap.getString(TABLE_NAME,0, "EOD_MUHASEBE").equals("H")) {
						output.put("EOD_CHECK", true);
						logger.info("ICS_CONTROL_END_OF_DAY_CHECK EOD_MUHASEBE equals H so return value is true");
					} else {
						if (calendar.get(Calendar.HOUR_OF_DAY) > Integer.parseInt(eodStartTime)) {
							output.put("EOD_CHECK", false);
							logger.info("ICS_CONTROL_END_OF_DAY_CHECK HOUR_OF_DAY is greater than eodStartTime so return value is false");
						} else {
							output.put("EOD_CHECK", true);
							logger.info("ICS_CONTROL_END_OF_DAY_CHECK HOUR_OF_DAY is less than eodStartTime so return value is false");
						}
					}
				}
			} else {
				output.put("EOD_CHECK", true);
				logger.info("ICS_CONTROL_END_OF_DAY_CHECK IS_EOD_CONTROL_ACTIVE is not YES so return value is true");
			}
		} catch (Exception e) {
			logger.error("ControlEndOfDayHandler da hata meydana geldi-> input map ".concat(input.toString()));
			logger.error("ControlEndOfDayHandler da hata meydana geldi-> output map ".concat(output.toString()));
			logger.error("ControlEndOfDayHandler da hata meydana geldi->".concat(CommonHelper.getStringifiedException(e)));
		}
	}
}
