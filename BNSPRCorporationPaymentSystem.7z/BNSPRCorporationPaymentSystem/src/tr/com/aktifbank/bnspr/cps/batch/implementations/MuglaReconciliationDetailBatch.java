package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.client.MuglaClient;
import tr.com.aktifbank.integration.client.ServiceMessage;
import tr.com.mugla.BgsTahsilSonucMakbuzDetayDto;
import tr.com.mugla.BgsTahsilSonucMakbuzDto;
import tr.com.mugla.TahsilIcmalDetayResponse;

import com.graymound.util.GMMap;

public final class MuglaReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(MuglaReconciliationDetailBatch.class);
	Session session;
	List<BgsTahsilSonucMakbuzDto> details= new ArrayList<BgsTahsilSonucMakbuzDto>();
	ServiceMessage message;
	Map<String, BgsTahsilSonucMakbuzDto> indexedCorporateRecords;

	public MuglaReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, BgsTahsilSonucMakbuzDto>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.SUBSCRIBER_NO1, details.get(corporateRecordIndex).getListBgsTahsilSonucMakbuzDetayDto().get(0).getSbsMuhatapId());
		cancelCollectionRequest.put(MapKeys.SUBSCRIBER_NO2, details.get(corporateRecordIndex).getListBgsTahsilSonucMakbuzDetayDto().get(0).getBgsBeyanId());
		cancelCollectionRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getBgsTahsilGenelId());
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getMakbuzNo());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String applicationKey = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String securityCode = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String vezneId = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String DATE = formatDate(input.getString(MapKeys.RECON_DATE));
					
			TahsilIcmalDetayResponse allDetails = MuglaClient.tahsilIcmaliDetay(url, applicationKey, securityCode,  DATE, vezneId,  this.message);
			details.addAll(allDetails.getTahsilSonucMakbuzDtos());
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	private String formatDate(String str) {
		String returnDate="";
		try {
			returnDate=CommonHelper.getDateString(CommonHelper.getDateTime(str, "yyyyMMdd"), "yyyy-MM-dd");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return returnDate;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getMakbuzNo());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getListBgsTahsilSonucMakbuzDetayDto().get(i).getBgsTahakId().toString(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getMakbuzNo().toString());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		BgsTahsilSonucMakbuzDto corporateDetail = details.get(corporateRecordIndex);
		String sbsMuhatabId = String.format("%011d", corporateDetail.getListBgsTahsilSonucMakbuzDetayDto().get(0).getSbsMuhatapId());
		String bgsBeyanId = String.format("%011d", corporateDetail.getListBgsTahsilSonucMakbuzDetayDto().get(0).getBgsBeyanId());
		
		BigDecimal tutar = new BigDecimal("0");// tutar detay da gecikme zammi ile birlikte tutuluyor		
		for (BgsTahsilSonucMakbuzDetayDto dty : corporateDetail.getListBgsTahsilSonucMakbuzDetayDto()) {
			tutar = tutar.add(dty.getTutar());
		}	
		
		logger.info(String.format("Following corporate record has not been found in database. Seri Numaras� : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getSeriNo(), 
				corporateDetail.getMakbuzNo(), 
				tutar));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(sbsMuhatabId);
		payment.setSubscriberNo2(bgsBeyanId);
		payment.setInvoiceNo(corporateDetail.getMakbuzNo().toString());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(tutar);
		payment.setPaymentAmount(tutar);
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setParameter1(sbsMuhatabId);
		payment.setParameter2(corporateDetail.getBgsTahsilGenelId().toString());
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, sbsMuhatabId);
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getMakbuzNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, tutar);
	}

}
