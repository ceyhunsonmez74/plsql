package tr.com.aktifbank.bnspr.cps.common;

public class NotificationMessageConstant {

	public static class Email{
		
		public final static String FROM = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr";
		
		public static class TransferBalanceMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = " Kurumunun Hesap Aktar�m�nda Hata";
			
			public static class Body{
				
				public final static String MESSAGE_BODY_4_USAGE_ACCOUNT ="<html><head></head><body> <b>Kurum Ad� : </b> KURUM_ADI <br /> <b>Kurum Kodu : " +
						"</b> KURUM_KODU <br /> <b> Kaynak Hesap : </b> KAYNAK_HESAP <br /> <b> Hedef Hesap : </b> HEDEF_HESAP <br /> " +
						"<b>Hata : </b> HATA </body></html>";
				public final static String MESSAGE_BODY_4_EFT_ACCOUNT ="<html><head></head><body> <b>Kurum Ad� : </b> KURUM_ADI <br /> <b>Kurum Kodu : " +
						"</b> KURUM_KODU <br /> <b> Kaynak Hesap : </b> KAYNAK_HESAP <br /> <b> Hedef IBAN : </b> HEDEF_IBAN <br /> " +
						"<b>Hata : </b> HATA </body></html>";
			}	
		}
		
		public static class SameDayTransferBalanceMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = " Kurumunun Ayn� G�n Hesap Aktar�m�nda Hata";
			
			public static class Body{
				public final static String MESSAGE_BODY_4_EFT_ACCOUNT ="<html><head></head><body> <b>Kurum Ad� : </b> KURUM_ADI <br /> <b>Kurum Kodu : " +
						"</b> KURUM_KODU <br /> <b> Kaynak Hesap : </b> KAYNAK_HESAP <br /> <b> Hedef IBAN : </b> HEDEF_IBAN <br /> " +
						"<b>Hata : </b> HATA </body></html>";
			}	
		}
		
		public static class DailyReportMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = "NYS Fatura Tahsilatlar� G�nl�k Otomatik Mail Raporu";
			
			public final static String MESSAGE_BODY_OLD = "<html><head></head><body> --ENVIRONMENT-- ortaminda CURRENT_DATE tarihli NYS Tahsilat islemlerinde " +
					"TOTAL_PAYMENT_COUNT  adet,  SUMMARY_PAYMENT_AMOUNT TL " +
					"tutar�nda  fatura tahsilat� muhasebele�tirilmi�tir<br /> " +
					"<ul> <li>" +
					"<b>Kurum Ad� :</b> KURUM_ADI , <b>Toplam Fatura Adeti :</b> PAYMENT_COUNT  adet, <b>Toplam Tahsilat Tutar� :</b> TOTAL_PAYMENT_AMOUNT TL" +
					"</li> </ul>";
			
			public final static String MESSAGE_BODY = "<html><head></head><body>--ENVIRONMENT-- ortaminda CURRENT_DATE tarihli NYS Tahsilat islemlerinde " +
					"TOTAL_PAYMENT_COUNT  adet,  SUMMARY_PAYMENT_AMOUNT TL tutar�nda  fatura tahsilat� muhasebele�tirilmi�tir<br /> <br/>" +
					"<table border=2> "+
					"<tr>" +
					"<th>Kurum Ad�</th>" +
					"<th>Toplam Fatura Adedi</th>" +
					"<th>Toplam Tahsilat Tutar� (TL)</th>" +
					"</tr>"+
					"<tr>"+
					"<td>KURUM_ADI</td>"+
					"<td>PAYMENT_COUNT</td>"+
					"<td>TOTAL_PAYMENT_AMOUNT</td>"+
					"</tr>"+
					"</table>";
		}
		
		public static class MonthlyReportMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = "NYS Fatura Tahsilatlar� Ayl�k Otomatik Mail Raporu";
			
			public final static String MESSAGE_BODY_OLD = "<html><head></head><body> --ENVIRONMENT-- ortaminda LAST_MONTH tarihli ge�en ay�n NYS Tahsilat islemlerinde " +
					"TOTAL_PAYMENT_COUNT  adet,  SUMMARY_PAYMENT_AMOUNT TL " +
					"tutar�nda  fatura tahsilat� muhasebele�tirilmi�tir<br /> " +
					"<ul> <li>" +
					"<b>Kurum Ad� :</b> KURUM_ADI , <b>Toplam Fatura Adeti :</b> PAYMENT_COUNT  adet, <b>Toplam Tahsilat Tutar� :</b> TOTAL_PAYMENT_AMOUNT TL" +
					"</li> </ul>";
			
			public final static String MESSAGE_BODY = "<html><head></head><body>--ENVIRONMENT-- ortaminda LAST_MONTH tarihli ge�en ay�n NYS Tahsilat islemlerinde" +
					"TOTAL_PAYMENT_COUNT  adet,  SUMMARY_PAYMENT_AMOUNT TL tutar�nda  fatura tahsilat� muhasebele�tirilmi�tir<br /> " +
					"<table border=2> "+
					"<tr>" +
					"<th>Kurum Ad�</th>" +
					"<th>Toplam Fatura Adedi</th>" +
					"<th>Toplam Tahsilat Tutar� (TL)</th>" +
					"</tr>"+
					"<tr>"+
					"<td>KURUM_ADI</td>"+
					"<td>PAYMENT_COUNT</td>"+
					"<td>TOTAL_PAYMENT_AMOUNT</td>"+
					"</tr>"+
					"</table>";
		}
		
		public static class BatchFileReportMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr";
			public final static String SUBJECT = "BATCH_NAME batch'i i�in PROCESS_DATE tarihli �al��ma raporu";
			public final static String CC ="";
			
			public final static String MESSAGE_BODY = "<html><head></head><body>BATCH_NAME isimli batch COUNT kurum i�in TOTAL_DURATION ms s�rede " +
					"�al��t�r�lm��t�r. Ba�ar�l� olan batch say�s� SUCCESS_STATUS , Ba�ar�s�z olan batch say�s� FAILURE_STATUS. " +
					"<table border=2> "+
					"<tr>" +
					"<th>Kurum Ad�</th>" +
					"<th>Kurum Kodu</th>" +
					"<th>Ba�lang�� Zaman�</th>" +
					"<th>Biti� Zaman�</th>" +
					"<th>Toplam �al��ma S�resi(ms)</th>" +
					"<th>Stat�</th>" +
					"<th>Hata Kodu</th>" +
					"<th>Hata Mesaj�</th>" +
					"</tr>"+
					"<tr>"+
					"<td>ROW_CORPORATE_NAME</td>"+
					"<td>ROW_CORPORATE_CODE</td>"+
					"<td>ROW_START_TIME</td>"+
					"<td>ROW_END_TIME</td>"+
					"<td>ROW_DURATION</td>"+
					"<td>ROW_STATUS</td>"+
					"<td>ROW_ERROR_CODE</td>"+
					"<td>ROW_ERROR_DESC</td>"+
					"</tr>"+
					"</table>";
		}
		
		public static class OnlineStandingOrderDebtLoadingMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = "PROCESS_DATE Tarihi ��in Talimatl� Borcu Y�klenemeyen Abonelerin Detaylar�";
			public final static String CC ="";
			
			public final static String MESSAGE_BODY = "<html><head></head><body><table border=2> " +
					"<tr>" +
					"<th>Kurum Ad�</th>" +
					"<th>Kurum Kodu</th>" +
					"<th>�deme Tipi</th>" +
					"<th>Abone No 1</th>" +
					"<th>Abone No 2</th>" +
					"<th>Abone No 3</th>" +
					"<th>Abone No 4</th>" +
					"<th>Son �deme Tarihi</th>" +
					"<th>Fatura Tutar�</th>" +
					"<th>Hata Kodu</th>" +
					"<th>Hata Mesaj�</th>" +
					"</tr>"+
					"<tr>"+
					"<td>ROW_CORPORATE_NAME</td>"+
					"<td>ROW_CORPORATE_CODE</td>"+
					"<td>ROW_COL_TYPE</td>"+
					"<td>ROW_SUB_NO1</td>"+
					"<td>ROW_SUB_NO2</td>"+
					"<td>ROW_SUB_NO3</td>"+
					"<td>ROW_SUB_NO4</td>"+
					"<td>ROW_DUE_DATE</td>"+
					"<td>ROW_INV_AMOUNT</td>"+
					"<td>ROW_ERR_CODE</td>"+
					"<td>ROW_ERR_MESSAGE</td>"+
					"</tr>"+
					"</table></body></html>";
		}
		
		public static class StandingOrderCollectionMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = "PROCESS_DATE Tarihi ��in Talimatl� Tahsilat Detaylar�";
			public final static String CC ="";
			
			public final static String MESSAGE_BODY = "<html><head></head><body><table border=2> " +
					"<tr>" +
					"<th>Kurum Ad�</th>" +
					"<th>M��teri Hesap No</th>" +
					"<th>M��teri Numaras�</th>" +
					"<th>Talimat Numaras�</th>" +
					"<th>Abone No</th>" +
					"<th>Abone Ad�</th>" +
					"<th>Son �deme Tarihi</th>" +
					"<th>Fatura Tutar�</th>" +
					"<th>�denme Durumu</th>" +
					"<th>Hata Kodu</th>" +
					"<th>Hata Mesaj�</th>" +
					"</tr>"+
					"<tr>"+
					"<td>ROW_CORPORATE_NAME</td>"+
					"<td>ROW_CUST_ACC_NO</td>"+
					"<td>ROW_CUST_NO</td>"+
					"<td>ROW_STD_ORD_NO</td>"+
					"<td>ROW_SUB_NO</td>"+
					"<td>ROW_SUB_NAME</td>"+
					"<td>ROW_DUE_DATE</td>"+
					"<td>ROW_INV_AMOUNT</td>"+
					"<td>ROW_STATUS</td>"+
					"<td>ROW_ERR_CODE</td>"+
					"<td>ROW_ERR_MESSAGE</td>"+
					"</tr>"+
					"</table></body></html>";
		}
		
		public static class CollectionReconciliationMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr";
			public final static String SUBJECT = "PROCESS_DATE Tarihi ��in Tahsilat Mutabakat Detaylar�";
			public final static String CC ="";
			
			public final static String MESSAGE_BODY = "<html><head></head><body><table border=2> " +
					"<tr>" +
					"<th>Kurum Ad�</th>" +
					"<th>Kurum Kodu</th>" +
					"<th>Mutabakat Durumu</th>" +
					"<th>Mutabakat Tipi</th>" +
					"<th>Banka Tahsilat Adedi</th>" +
					"<th>Banka Tahsilat Tutar�</th>" +
					"<th>Kurum Tahsilat Adedi</th>" +
					"<th>Kurum Tahsilat Tutar�</th>" +
					"<th>Banka �ptal Adedi</th>" +
					"<th>Banka �ptal Tutar�</th>" +
					"<th>Kurum �ptal Adedi</th>" +
					"<th>Kurum �ptal Tutar�</th>" +
					"<th>Hata Kodu</th>" +
					"<th>Hata A��klamas�</th>" +
					"</tr>"+
					"<tr>"+
					"<td>ROW_CORPORATE_NAME</td>"+
					"<td>ROW_CORPORATE_CODE</td>"+
					"<td>ROW_RECON_STATUS</td>"+
					"<td>ROW_RECON_TYPE</td>"+
					"<td>ROW_BANK_COLLECTION_COUNT</td>"+
					"<td>ROW_BANK_COLLECTION_AMOUNT</td>"+
					"<td>ROW_CORPORATE_COLLECTION_COUNT</td>"+
					"<td>ROW_CORPORATE_COLLECTION_AMOUNT</td>"+
					"<td>ROW_BANK_COLLECTION_CANCEL_COUNT</td>"+
					"<td>ROW_BANK_COLLECTION_CANCEL_AMOUNT</td>"+
					"<td>ROW_CORPORATE_COLLECTION_CANCEL_COUNT</td>"+
					"<td>ROW_CORPORATE_COLLECTION_CANCEL_AMOUNT</td>"+
					"<td>ROW_ERROR_CODE</td>"+
					"<td>ROW_ERROR_DESC</td>"+
					"</tr>"+
					"</table></body></html>";
		}
		
		public static class OfflineDebtLoadingErrorMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = " Kurumunun Bor� Y�klemesinde Hata";
			
			public final static String MESSAGE_BODY="<html><head></head><body> <b>Kurum Ad� : </b> CORPORATE_NAME <br /> <b>Kurum Kodu : " +
					"</b> CORPORATE_CODE <br /> <b> Hata Kodu : </b> ERROR_CODE <br /> <b> Hata Mesaj� : </b> ERROR_MESSAGE <br /> </body></html>";
		}
		
		public static class NewStandingOrderRequestMessageConstant{
			
			public final static String RECEIPT_LIST = "akin.garagon@aktifbank.com.tr";
			public final static String SUBJECT = "Yeni Talimat Giri�i";
			
			public final static String MESSAGE_BODY_OLD = "<html><head></head><body> --ENVIRONMENT-- ortaminda CURRENT_DATE tarihinde yap�lan talimat giri�i</br>" +
					"<ul> <li>" +
					"<b>Kurum Ad� :</b> KURUM_ADI , <b>Toplam Fatura Adeti :</b> PAYMENT_COUNT  adet, <b>Toplam Tahsilat Tutar� :</b> TOTAL_PAYMENT_AMOUNT TL" +
					"</li> </ul>";
			
			public final static String MESSAGE_BODY = "<html><head></head><body>--ENVIRONMENT-- ortaminda CURRENT_DATE tarihinde yap�lan talimat giri�i</br>" +
					"<table border=2> "+
					"<tr>" +
					"<th>Kurum Ad�</th>" +
					"<th>Abone No</th>" +
					"<th>Hesap Id</th>" +
					"</tr>"+
					"<tr>"+
					"<td>KURUM_ADI</td>"+
					"<td>ABONE_NO</td>"+
					"<td>HESAP_ID</td>"+
					"</tr>"+
					"</table>";
		}
		
		public static class SafReporterMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = "PROCESS_DATE Tarihi ��in Hata Alan SAF Kay�tlar�";
			public final static String CC ="";
			
			public final static String MESSAGE_BODY = "<html><head></head><body><table border=2> " +
					"<tr>" +
					"<th>Kurum Ad�</th>" +
					"<th>Servis Ad�</th>" +
					"<th>Hata Kodu</th>" +
					"<th>Hata A��klamas�</th>" +
					"<th>Parametreler</th>" +
					"</tr>"+
					"<tr>"+
					"<td>ROW_CORPORATE_NAME</td>"+
					"<td>ROW_SERVICE_NAME</td>"+
					"<td>ROW_ERROR_CODE</td>"+
					"<td>ROW_ERROR_DESC</td>"+
					"<td>ROW_PARAMETERS</td>"+
					"</tr>"+
					"</table></body></html>";
		}
		
	}
	
	public static class SMS{
		
	}
}
