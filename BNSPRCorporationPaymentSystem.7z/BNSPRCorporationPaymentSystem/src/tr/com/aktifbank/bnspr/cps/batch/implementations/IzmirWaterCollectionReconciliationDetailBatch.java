package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.integration.izmirwater.client.IzmirWaterClient;

import com.graymound.util.GMMap;

public class IzmirWaterCollectionReconciliationDetailBatch extends
		CollectionReconciliationDetailBatch {
	
	private List<String> txNoList;

	public IzmirWaterCollectionReconciliationDetailBatch(GMMap input) {
		super(input);
		this.txNoList = new ArrayList<String>();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, this.txNoList.get(corporateRecordIndex));
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.TRX_NO, this.txNoList.get(corporateRecordIndex));
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.txNoList.contains(bankRecord.getString(MapKeys.TRX_NO));
	}

	@SuppressWarnings("unchecked")
	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()
			throws Exception {
		Session session = CommonHelper.getHibernateSession();
		BigDecimal processOid = super.input.getBigDecimal("PROCESS_ID");
		
		List<FtmFileContent> contentList = session.createCriteria(FtmFileContent.class)
				.add(Restrictions.eq("ftmProcessOid", processOid))
				.addOrder(Order.asc("lineNumber"))
				.list();
		
		for (FtmFileContent content : contentList) {
			String type = content.getLine().substring(46, 47);
			if(type.equals("G")){
				String txNo = content.getLine().substring(22, 46);
				txNo = CommonHelper.trimStart(txNo, '0');
				this.txNoList.add(txNo);
			}
		}
		
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		result.setSuccessfulCall(true);
		
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			GMMap bankRecord = super.getBankRecordAtIndex(i);
			super.setBankRecordIndex(bankRecord.getString(MapKeys.TRX_NO), bankRecord);
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.txNoList.get(corporateRecordIndex));
	}

}
