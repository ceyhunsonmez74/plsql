package tr.com.aktifbank.bnspr.cps.multithreading.implementations;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.ComplexBatchSubmitInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.PartialParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ServiceBasedMultiThreading;

public class ComplexBatchSubmitImplementation extends
		ServiceBasedMultiThreading {

	ComplexBatchSubmitInformation information;
	
	public ComplexBatchSubmitImplementation(ComplexBatchSubmitInformation information) {
		super();
		this.information = information;
	}

	@Override
	protected void prepareCall() throws Throwable {
		for (String corporateCode : this.information.getCorporateCodes()) {
			GMMap submitMap = new GMMap();
			submitMap.put(TransactionConstants.ComplexBatchSubmit.Input.CORPORATE_CODE, corporateCode);
			super.registerService(this.information.getServiceName(), submitMap);
		}
	}
	
	@Override
	protected ParallelCallBehaviour getParallelCallBehaviour() {
		return new PartialParallelCallBehaviour(this.information.getParallelLoopCount(), true);
	}

}
