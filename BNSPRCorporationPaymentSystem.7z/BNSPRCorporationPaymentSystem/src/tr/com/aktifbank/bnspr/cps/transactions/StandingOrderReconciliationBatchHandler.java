package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationResubmitType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationTypes;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class StandingOrderReconciliationBatchHandler extends ParallelRequestHandler {

	private static final class BagKeys {
		public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
		public static final String CORPORATE_CODE = "CORPORATE_CODE";
	}

	public StandingOrderReconciliationBatchHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		GMMap reconLogInput = new GMMap();
		GMMap reconLogOutput = new GMMap();
		String corporateCode=input.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE);
		String submitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		String screenReconciliation = input.getString("SCREEN_RECONCILIATION");
		String resubmitType = (input.containsKey(StandingOrderReconciliationBatch.Input.RESUBMIT_TYPE) ? input
				.getString(StandingOrderReconciliationBatch.Input.RESUBMIT_TYPE) : ReconciliationResubmitType.ReconciliationClose); //2 G�NSONU
		reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS, ReconciliationStatus.Started);
		reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_TYPE, ReconciliationTypes.StandingOrder);
		reconLogInput.put(TransactionConstants.ReconLogInsert.Input.SUB_TYPE, resubmitType);
		reconLogInput.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_CODE, corporateCode);
		bag.put(BagKeys.BATCH_SUBMIT_ID, submitId);
		input.put("SUBMIT_ID", submitId);
		String reconLogOid="";
		CommonBusinessOperations.insertBatchSubmitLog(corporateCode, input.getString(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME), null, null, submitId, StandingOrderReconciliationBatch.SERVICE_NAME , reconLogInput);
		//insertBatchSubmitLog(input);
		try {
			String reconDate = "";
			String processDate = "";
			// PROCESS_DATE bo� geldi ise reconDate i bug�ne e�itle
			if (input.getString(StandingOrderReconciliationBatch.Input.PROCESS_DATE) != null) {
				reconDate = input.getString(StandingOrderReconciliationBatch.Input.PROCESS_DATE);
				processDate = input.getString(StandingOrderReconciliationBatch.Input.PROCESS_DATE);
			} else {
				reconDate = new Date().toString();
				processDate = "";
			}

			reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_DATE, reconDate);
			reconLogOutput = super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_INSERT", reconLogInput);
			reconLogOid = reconLogOutput.getString(TransactionConstants.ReconLogInsert.Output.RECON_LOG_OID);

			// batch ekrandan m� tetiklendi?
			if (input.containsKey(StandingOrderReconciliationBatch.Input.SCREEN_RECONCILIATION)) {
				// batch ekrandan tetiklendi ise
				if (screenReconciliation.equals("1")) {
					if (resubmitType.equals(ReconciliationResubmitType.FindDifferences)) {
						// ekrandan "farklari bul bildirim yap se�ilmi� ise"
						GMMap reconInMap = new GMMap();
						GMMap rcInput = new GMMap();
						GMMap reconOutMap = new GMMap();
						reconInMap.put(MapKeys.RECON_DATE, (reconDate));
						reconInMap.put(MapKeys.CORPORATE_CODE, corporateCode);
						reconInMap.put(MapKeys.PROCESS_DATE, input.getString(StandingOrderReconciliationBatch.Input.PROCESS_DATE));
						reconInMap.put(MapKeys.GM_SERVICE_NAME, "STO_STANDING_ORDER_RECONCILIATION");
						reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
						reconInMap.put(MapKeys.STAN_NO, submitId);
						reconInMap.put("SCREEN_RECONCILIATION", "1");
						reconOutMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", reconInMap);

						int bankStandingOrderRecordCount = reconOutMap.getInt(MapKeys.RECON_BANK_COUNT);
						int corporateStandingOrderRecordCount = reconOutMap.getInt(MapKeys.RECON_CORPORATE_COUNT);
						int bankStandingOrderCancelCount = reconOutMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
						int corporateStandingOrderCancelCount = reconOutMap.getInt(MapKeys.RECON_CORPORATE_CANCEL_COUNT);

						// mutabakat basarili
						if (bankStandingOrderRecordCount == corporateStandingOrderRecordCount
								&& bankStandingOrderCancelCount == corporateStandingOrderCancelCount) {
							// ak�� gere�i kapama i�lemi yap�lmad�
							rcInput = new GMMap();
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT, bankStandingOrderRecordCount);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT, corporateStandingOrderRecordCount);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
							super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", rcInput);
						} else {
							// ba�ar�s�z ise detay mutabakat yap
							rcInput = new GMMap();
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT, bankStandingOrderRecordCount);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT, corporateStandingOrderRecordCount);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
							super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", rcInput);
							reconInMap.put(MapKeys.CORPORATE_CODE, input.getString(MapKeys.CORPORATE_CODE));
							reconInMap.put(MapKeys.RECON_DATE, reconDate);
							reconInMap.put(MapKeys.PROCESS_DATE, processDate);
							reconInMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
							reconInMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderRecordCount);
							reconInMap.put(MapKeys.RECON_CORPORATE_COUNT, corporateStandingOrderRecordCount);
							reconInMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
							reconInMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
							reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							reconInMap.put(MapKeys.RECON_LOG_OID, reconLogOid);
							reconInMap.put(MapKeys.GM_SERVICE_NAME, "STO_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
							reconInMap.put(MapKeys.STAN_NO, submitId);
							reconOutMap = super.callGraymoundServiceInSession("ICS_ONLINE_SERVICE_CALL", reconInMap);

							// detay mutabakat yap�ld�ktan sonra tekrar
							// mutabakat yap�l�r
							// detay mutabakat�n ba�ar�l� oldu�u kontrol edilir.

							reconInMap = new GMMap();
							rcInput = new GMMap();
							reconOutMap = new GMMap();

							reconInMap.put(MapKeys.RECON_DATE, (reconDate));
							reconInMap.put(MapKeys.CORPORATE_CODE, input.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
							reconInMap.put(MapKeys.PROCESS_DATE, input.getString(StandingOrderReconciliationBatch.Input.PROCESS_DATE));
							reconInMap.put(MapKeys.GM_SERVICE_NAME, "STO_STANDING_ORDER_RECONCILIATION");
							reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
							reconInMap.put(MapKeys.STAN_NO, submitId);
							reconInMap.put("SCREEN_RECONCILIATION", "1");
							reconOutMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", reconInMap);

							bankStandingOrderRecordCount = reconOutMap.getInt(MapKeys.RECON_BANK_COUNT);
							corporateStandingOrderRecordCount = reconOutMap.getInt(MapKeys.RECON_CORPORATE_COUNT);
							bankStandingOrderCancelCount = reconOutMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
							corporateStandingOrderCancelCount = reconOutMap.getInt(MapKeys.RECON_CORPORATE_CANCEL_COUNT);
							
							reconLogInput = new GMMap();
							reconLogInput.put(TransactionConstants.ReconLogInsert.Input.BANK_COUNT, bankStandingOrderRecordCount);
							reconLogInput.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_COUNT, corporateStandingOrderRecordCount);
							reconLogInput.put(TransactionConstants.ReconLogInsert.Input.BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
							reconLogInput.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
							reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_DATE, reconDate);
							reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_TYPE, ReconciliationTypes.StandingOrder);
							reconLogInput.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_CODE, corporateCode);
							reconLogInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
							
							if (bankStandingOrderRecordCount == corporateStandingOrderRecordCount
									&& bankStandingOrderCancelCount == corporateStandingOrderCancelCount) {
								reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS,ReconciliationStatus.ReconciliationSucceeded);
								reconLogOutput = super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", reconLogInput);
							} else {
								reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);								
								reconLogOutput = super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", reconLogInput);
							}
						}
				 } else {
					// istek sadece mutabakat kapatma iste�i ise
					GMMap reconInMap = new GMMap();
					GMMap reconOutMap = new GMMap();
					reconInMap.put(MapKeys.CORPORATE_CODE, input.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
					reconInMap.put(MapKeys.RECON_DATE, reconDate);
					reconInMap.put(MapKeys.PROCESS_DATE, processDate);
					reconInMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					reconInMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, 0);
					reconInMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, 0);
					reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, false);
					reconInMap.put(MapKeys.GM_SERVICE_NAME, "STO_STANDING_ORDER_RECONCILIATION_CLOSE");
					reconInMap.put(MapKeys.STAN_NO, submitId);
					reconInMap.put("SCREEN_RECONCILIATION", "1");
					reconOutMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", reconInMap);
					
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_DATE, reconDate);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_TYPE, ReconciliationTypes.StandingOrder);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_CODE, corporateCode);
					reconLogInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS,ReconciliationStatus.ReconciliationSucceeded);
					reconLogOutput = super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", reconLogInput);
				 }
			  }
			} else {
				//batch ekrandan de�ilde normal olarak �al��t�r�ld� ise
				GMMap reconInMap = new GMMap();
				GMMap rcInput = new GMMap();
				GMMap reconOutMap = new GMMap();
				reconInMap.put(MapKeys.RECON_DATE, (reconDate));
				reconInMap.put(MapKeys.CORPORATE_CODE, input.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
				reconInMap.put(MapKeys.PROCESS_DATE, input.getString(StandingOrderReconciliationBatch.Input.PROCESS_DATE));
				reconInMap.put(MapKeys.GM_SERVICE_NAME, "STO_STANDING_ORDER_RECONCILIATION");
				reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
				reconInMap.put(MapKeys.STAN_NO, submitId);
				reconOutMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", reconInMap);

				int bankStandingOrderRecordCount = reconOutMap.getInt(MapKeys.RECON_BANK_COUNT);
				int corporateStandingOrderRecordCount = reconOutMap.getInt(MapKeys.RECON_CORPORATE_COUNT);
				int bankStandingOrderCancelCount = reconOutMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
				int corporateStandingOrderCancelCount = reconOutMap.getInt(MapKeys.RECON_CORPORATE_CANCEL_COUNT);

				if (bankStandingOrderRecordCount == corporateStandingOrderRecordCount
						&& bankStandingOrderCancelCount == corporateStandingOrderCancelCount) {

					reconInMap.put(MapKeys.CORPORATE_CODE, input.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
					reconInMap.put(MapKeys.RECON_DATE, reconDate);
					reconInMap.put(MapKeys.PROCESS_DATE, processDate);
					reconInMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
					reconInMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderRecordCount);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT, bankStandingOrderRecordCount);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT, corporateStandingOrderRecordCount);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
					reconInMap.put(MapKeys.RECON_CORPORATE_COUNT, corporateStandingOrderRecordCount);
					reconInMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
					reconInMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
					reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, false);
					reconInMap.put(MapKeys.GM_SERVICE_NAME, "STO_STANDING_ORDER_RECONCILIATION_CLOSE");
					reconInMap.put(MapKeys.STAN_NO, submitId);
					reconOutMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", reconInMap);
					rcInput.put(TransactionConstants.ReconLogInsert.Input.SUB_TYPE, "2");
					
					if (reconOutMap.containsKey("ERROR_CODE")) {
						if (reconOutMap.getString("ERROR_CODE").equals("0")) {
//							rcInput = new GMMap();
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
							super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", rcInput);
						} else {
							rcInput = new GMMap();
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.ERROR_CODE,
									reconOutMap.getString(TransactionConstants.ReconLogUpdate.Input.ERROR_CODE));
							rcInput.put(TransactionConstants.ReconLogUpdate.Input.ERROR_DESC,
									reconOutMap.getString(TransactionConstants.ReconLogUpdate.Input.ERROR_DESC));
							super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", rcInput);
						}
					} else {
						rcInput = new GMMap();
						rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
						rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
						super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", rcInput);
					}
				} else {
					rcInput = new GMMap();
					rcInput.put(TransactionConstants.ReconLogInsert.Input.SUB_TYPE, "2");
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, ReconciliationStatus.Continues);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT, bankStandingOrderRecordCount);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT, corporateStandingOrderRecordCount);
					rcInput.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
					super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", rcInput);
					reconInMap.put(MapKeys.CORPORATE_CODE, input.getString(MapKeys.CORPORATE_CODE));
					reconInMap.put(MapKeys.RECON_DATE, reconDate);
					reconInMap.put(MapKeys.PROCESS_DATE, processDate);
					reconInMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					reconInMap.put(MapKeys.RECON_BANK_COUNT, bankStandingOrderRecordCount);
					reconInMap.put(MapKeys.RECON_CORPORATE_COUNT, corporateStandingOrderRecordCount);
					reconInMap.put(MapKeys.RECON_BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
					reconInMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
					reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					reconInMap.put(MapKeys.RECON_LOG_OID, reconLogOid);
					reconInMap.put(MapKeys.GM_SERVICE_NAME, "STO_GET_STANDING_ORDER_RECONCILIATION_DETAIL");
					reconInMap.put(MapKeys.STAN_NO, submitId);
					reconOutMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", reconInMap);

					// detay mutabakat yap�ld�ktan sonra tekrar mutabakat yap�l�r
					// detay mutabakat�n ba�ar�l� oldu�u kontrol edilir.

					reconInMap = new GMMap();
					rcInput = new GMMap();
					reconOutMap = new GMMap();

					reconInMap.put(MapKeys.RECON_DATE, (reconDate));
					reconInMap.put(MapKeys.CORPORATE_CODE, input.getString(StandingOrderReconciliationBatch.Input.CORPORATE_CODE));
					reconInMap.put(MapKeys.PROCESS_DATE, input.getString(StandingOrderReconciliationBatch.Input.PROCESS_DATE));
					reconInMap.put(MapKeys.GM_SERVICE_NAME, "STO_STANDING_ORDER_RECONCILIATION");
					reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
					reconInMap.put(MapKeys.STAN_NO, submitId);
					reconOutMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", reconInMap);

					bankStandingOrderRecordCount = reconOutMap.getInt(MapKeys.RECON_BANK_COUNT);
					corporateStandingOrderRecordCount = reconOutMap.getInt(MapKeys.RECON_CORPORATE_COUNT);
					bankStandingOrderCancelCount = reconOutMap.getInt(MapKeys.RECON_BANK_CANCEL_COUNT);
					corporateStandingOrderCancelCount = reconOutMap.getInt(MapKeys.RECON_CORPORATE_CANCEL_COUNT);

					reconLogInput = new GMMap();
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.BANK_COUNT, bankStandingOrderRecordCount);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_COUNT, corporateStandingOrderRecordCount);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.BANK_CANCEL_COUNT, bankStandingOrderCancelCount);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_CANCEL_COUNT, corporateStandingOrderCancelCount);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_DATE, reconDate);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_TYPE, ReconciliationTypes.StandingOrder);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_CODE, corporateCode);
					reconLogInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
					reconLogInput.put(TransactionConstants.ReconLogInsert.Input.SUB_TYPE, "2");
					if (bankStandingOrderRecordCount == corporateStandingOrderRecordCount
							&& bankStandingOrderCancelCount == corporateStandingOrderCancelCount) {
						reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);
						reconLogOutput = super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", reconLogInput);
					} else {
						reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						reconLogOutput = super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", reconLogInput);
					}
				}
			}
			
		CommonBusinessOperations.updateBatchSubmitLog(submitId, DatabaseConstants.SubmitStatuses.SUCESSFUL, new Date(), null, null);
		
		} catch (Exception e) {
			String errorMessage = e.getMessage();
			reconLogInput.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, reconLogOid);
			reconLogInput.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			reconLogInput.put(TransactionConstants.ReconLogInsert.Input.SUB_TYPE, "2");
			reconLogOutput = super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", reconLogInput);
			CommonBusinessOperations.updateBatchSubmitLog(submitId, DatabaseConstants.SubmitStatuses.FAILURE, new Date(), null, errorMessage);
		}
		
	}

	@Override
	protected void handleError(Throwable e, GMMap output) {
		Long errorId = System.currentTimeMillis();
		logger.error("System exception is occured updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(), "0",
				e.toString());
		output.put(
				TransactionConstants.StartCorporateBatch.Output.RESULT,
				false);
		output.put(
				TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID,
				(String) super.bag.get(BagKeys.BATCH_SUBMIT_ID));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE,
				(String) super.bag.get(BagKeys.CORPORATE_CODE));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_CODE,
				"0");
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_MESSAGE,
				e.toString());
	}

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		Long errorId = System.currentTimeMillis();

		logger.error("Business exception is occured. Updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(),
				String.valueOf(e.getCode()), e.toString());
		output.put(
				TransactionConstants.StartCorporateBatch.Output.RESULT,
				false);
		output.put(
				TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID,
				(String) super.bag.get(BagKeys.BATCH_SUBMIT_ID));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE,
				(String) super.bag.get(BagKeys.CORPORATE_CODE));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_CODE,
				String.valueOf(e.getCode()));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_MESSAGE,
				e.toString());
	}

	private void callReconciliation(GMMap input) {

	}

}
