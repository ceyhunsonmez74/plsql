package tr.com.aktifbank.bnspr.cps.filetransfer.services;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CompressType;
import tr.com.aktifbank.bnspr.dao.FtmFileDefinition;
import tr.com.aktifbank.bnspr.dao.FtmFileDefinitionFtp;
import tr.com.aktifbank.bnspr.dao.FtmFileDefinitionFtpTx;
import tr.com.aktifbank.bnspr.dao.FtmFileDefinitionTx;
import tr.com.aktifbank.bnspr.dao.FtmFileExecutionSchedule;
import tr.com.aktifbank.bnspr.dao.FtmFileExecutionScheduleTx;
import tr.com.aktifbank.bnspr.dao.FtmFileExecutionTime;
import tr.com.aktifbank.bnspr.dao.FtmFileExecutionTimeTx;
import tr.com.aktifbank.bnspr.dao.FtmFtpDefinition;
import tr.com.aktifbank.bnspr.dao.FtmFtpDefinitionTx;
import tr.com.aktifbank.bnspr.dao.FtmInstance;
import tr.com.aktifbank.bnspr.dao.FtmMailProcessDef;
import tr.com.aktifbank.bnspr.dao.FtmMailProcessDefTx;
import tr.com.aktifbank.bnspr.dao.FtmNotification;
import tr.com.aktifbank.bnspr.dao.FtmNotificationTx;
import tr.com.aktifbank.bnspr.dao.FtmNotificationType;
import tr.com.aktifbank.bnspr.dao.FtmTransactionDef;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class FtmDefinitionServices {
	
	@GraymoundService("CDM_GET_FTM_PLATFORM")
	public static GMMap getFtmPlatform(GMMap input) {
		GMMap output = new GMMap();
		try {
			String listName = "LIST";
			GMMap listOutput = DALUtil.getResults(QueryRepository.FtmDefinitionServicesRepository.GET_FTM_PLATFORM, listName);

			for (int i = 0; i < listOutput.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(output, listName, listOutput.get(listName, i, "OID").toString(), listOutput.get(listName, i, "NAME").toString());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_GET_FTM_CONNECTION_TYPE")
	public static GMMap getFtmConnectionType(GMMap input) {
		GMMap output = new GMMap();
		try {
			String listName = "LIST";
			GMMap listOutput = DALUtil.getResults(QueryRepository.FtmDefinitionServicesRepository.FTM_CONNECTION_TYPE, listName);

			for (int i = 0; i < listOutput.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(output, listName, listOutput.get(listName, i, "OID").toString(), listOutput.get(listName, i, "CONNECTION_TYPE").toString());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_GET_FTM_FILE_DEF_TYPE")
	public static GMMap getFtmFileDefType(GMMap input) {

		GMMap output = new GMMap();
		try {
			String listName = "LIST";
			GMMap listOutput = DALUtil.getResults(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEF_TYPE, listName);

			for (int i = 0; i < listOutput.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(output, listName, listOutput.get(listName, i, "OID").toString(), listOutput.get(listName, i, "FILE_DEFINITION_TYPE").toString());
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_GET_FTM_FILE_TYPE")
	public static GMMap getFtmFileType(GMMap input) {
		GMMap output = new GMMap();
		try {
			String listName = "LIST";
			GMMap listOutput = DALUtil.getResults(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_TYPE, listName);

			for (int i = 0; i < listOutput.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(output, listName, listOutput.get(listName, i, "OID").toString(), listOutput.get(listName, i, "FILE_TYPE").toString());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_GET_FTM_CONN_NAMES_FOR_FILE_DEF")
	public static GMMap getFtmConnectionNamesForFileDef(GMMap input) {
		GMMap output = new GMMap();
		try {
			String listName = "LIST";
			GMMap listOutput = DALUtil.getResults(QueryRepository.FtmDefinitionServicesRepository.FTM_CONNECTION_NAMES, listName);

			for (int i = 0; i < listOutput.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(output, listName, listOutput.get(listName, i, "OID").toString(), listOutput.get(listName, i, "CONN_NAME").toString());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_GET_FTM_FILE_ENCODING")
	public static GMMap getFtmFileEncoding(GMMap input) {
		GMMap output = new GMMap();
		try {
			String listName = "LIST";
			GMMap listOutput = DALUtil.getResults(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_ENCODING, listName);

			for (int i = 0; i < listOutput.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(output, listName, listOutput.get(listName, i, "OID").toString(), listOutput.get(listName, i, "ENCODING").toString());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_FTM_FTPS_FOR_COMBO")
	public static GMMap getFtmFtpsForCombo(GMMap input) {
		GMMap output = new GMMap();
		try {
			String sourceListName = "SOURCE_LIST";
			String destListName = "DEST_LIST";
			String archiveListName = "ARCHIVE_LIST";
			Session hibernateSession = CommonHelper.getHibernateSession();

			List<FtmFtpDefinition> ftmFtps = hibernateSession.createCriteria(FtmFtpDefinition.class).add(Restrictions.eq("ftmStateOid", Short.parseShort("1"))).addOrder(Order.asc("oid")).list();

			GuimlUtil.wrapMyCombo(output, sourceListName, "0", "-- FTP Se�ilmedi");
			for (FtmFtpDefinition ftmFtp : ftmFtps)
				GuimlUtil.wrapMyCombo(output, sourceListName, ftmFtp.getOid().toString(), ftmFtp.getName());

			GuimlUtil.wrapMyCombo(output, destListName, "0", "-- L�tfen FTP Se�iniz");
			for (FtmFtpDefinition ftmFtp : ftmFtps)
				GuimlUtil.wrapMyCombo(output, destListName, ftmFtp.getOid().toString(), ftmFtp.getName());

			GuimlUtil.wrapMyCombo(output, archiveListName, "0", "-- FTP Se�ilmedi");
			for (FtmFtpDefinition ftmFtp : ftmFtps)
				GuimlUtil.wrapMyCombo(output, archiveListName, ftmFtp.getOid().toString(), ftmFtp.getName());

			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_FTM_FILES_FOR_COMBO")
	public static GMMap getFtmFilesForCombo(GMMap input) {
		GMMap output = new GMMap();
		try {
			String listName = "LIST";
			Session hibernateSession = CommonHelper.getHibernateSession();

			List<FtmFileDefinition> ftmFiles = hibernateSession.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("ftmStateOid", Short.parseShort("1"))).addOrder(Order.asc("oid")).list();

			for (FtmFileDefinition ftmFile : ftmFiles)
				GuimlUtil.wrapMyCombo(output, listName, ftmFile.getOid().toString(), ftmFile.getName());

			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_FTM_FTP_DEFINITIONS")
	public static GMMap getFtmFtpDefinitions(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = "TABLE_DATA";
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			String platformName = null, connectionTypeName = null;

			if (trxNo == null) {
				List<FtmFtpDefinition> ftmFtps = hibernateSession.createCriteria(FtmFtpDefinition.class).addOrder(Order.asc("oid")).list();
				int count = 0;
				for (FtmFtpDefinition ftmFtp : ftmFtps) {
					platformName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FTP_DEFINITIONS_PLATFORM_NAME, ftmFtp.getFtmPlatformOid()));
					connectionTypeName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FTP_DEFINITIONS_CONNECTION_TYPE, ftmFtp.getConnectionTypeOid()));
	
					output.put(tableName, count, "CONNECTION_TYPE_NAME", connectionTypeName);
					output.put(tableName, count, "DESCRIPTION", ftmFtp.getDescription());
					output.put(tableName, count, "FTM_PLATFORM_NAME", platformName);
					output.put(tableName, count, "NAME", ftmFtp.getName());
					output.put(tableName, count, "PORT", ftmFtp.getPort());
					output.put(tableName, count, "STATE", String.valueOf(ftmFtp.getFtmStateOid()));
					output.put(tableName, count, "URL", ftmFtp.getUrl());
					output.put(tableName, count, "USERNAME", ftmFtp.getUsername());
					output.put(tableName, count, "OID", ftmFtp.getOid());
					count++;
				}
			} else {
				FtmFtpDefinitionTx ftmFtpTx = (FtmFtpDefinitionTx)hibernateSession.createCriteria(FtmFtpDefinitionTx.class).add(Restrictions.eq("txNo", trxNo)).uniqueResult();
				int count = 0;
				platformName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FTP_DEFINITIONS_PLATFORM_NAME, ftmFtpTx.getFtmPlatformOid()));
				connectionTypeName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FTP_DEFINITIONS_CONNECTION_TYPE, ftmFtpTx.getConnectionTypeOid()));

				output.put(tableName, count, "CONNECTION_TYPE_NAME", connectionTypeName);
				output.put(tableName, count, "DESCRIPTION", ftmFtpTx.getDescription());
				output.put(tableName, count, "FTM_PLATFORM_NAME", platformName);
				output.put(tableName, count, "NAME", ftmFtpTx.getName());
				output.put(tableName, count, "PORT", ftmFtpTx.getPort());
				output.put(tableName, count, "STATE", String.valueOf(ftmFtpTx.getFtmStateOid()));
				output.put(tableName, count, "URL", ftmFtpTx.getUrl());
				output.put(tableName, count, "USERNAME", ftmFtpTx.getUsername());
				output.put(tableName, count, "OID", ftmFtpTx.getOid());
			}
			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_FTM_FILE_DEFINITIONS")
	public static GMMap getFtmFileDefinitions(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = "TABLE_DATA";
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			Boolean mailManagement = input.getBoolean("MAIL_MANAGEMENT");

			List<FtmFileDefinition> ftmFiles = hibernateSession.createCriteria(FtmFileDefinition.class).addOrder(Order.asc("oid")).list();
			String fileDefTypeName = null, encodingName = null, fileTypeName = null, fileNameMask = null;
			
			if (mailManagement) {
				FtmTransactionDef txDef = (FtmTransactionDef) hibernateSession.createCriteria(FtmTransactionDef.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", trxNo)).uniqueResult();
				FtmFileDefinition ftmFile = null;
				if (txDef.getTxType().equals(DatabaseConstants.FtmTransactionTypes.MAIL_PROCESS_DEF)) {
					List<FtmMailProcessDefTx> processDefList = hibernateSession.createCriteria(FtmMailProcessDefTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", trxNo)).list();					
					ftmFile = (FtmFileDefinition)hibernateSession.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("oid", processDefList.get(0).getFtmFileDefinitionOid())).uniqueResult();
				} else if (txDef.getTxType().equals(DatabaseConstants.FtmTransactionTypes.MAIL_NOTIFICATION)) {
					List<FtmNotificationTx> notificationList = hibernateSession.createCriteria(FtmNotificationTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", trxNo)).list();					
					ftmFile = (FtmFileDefinition)hibernateSession.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("oid", notificationList.get(0).getFtmFileDefinitionOid())).uniqueResult();
				}
				
				fileDefTypeName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_FILE_DEF_TYPE_NAME, ftmFile.getFtmFileDefinitionTypeOid()));
				fileTypeName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_FILE_TYPE_NAME, ftmFile.getFileTypeOid()));
				encodingName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_ENCODING_NAME, ftmFile.getFileEncodingOid()));
				fileNameMask = ftmFile.getFileNameMask();
				int count = 0;
				output.put(tableName, count, "CONTINUAL", ftmFile.isContinual());
				output.put(tableName, count, "DURATION", ftmFile.getDuration());
				output.put(tableName, count, "ENCODING_NAME", encodingName);
				output.put(tableName, count, "FILE_DEF_TYPE_NAME", fileDefTypeName);
				output.put(tableName, count, "FILE_NAME_MASK", fileNameMask);
				output.put(tableName, count, "FILE_TYPE_NAME", fileTypeName);
				output.put(tableName, count, "NAME", ftmFile.getName());
				output.put(tableName, count, "SERVICE", ftmFile.getService());
				output.put(tableName, count, "STATE", String.valueOf(ftmFile.getFtmStateOid()));
				output.put(tableName, count, "OVERWRITE", ftmFile.isOverwrite());
				output.put(tableName, count, "READ_FILE", ftmFile.isReadFile());
				output.put(tableName, count, "DUPLICATE", ftmFile.isDuplicate());
				output.put(tableName, count, "DELETE_FILE", ftmFile.isDeleteFile());
				output.put(tableName, count, "ARCHIVE_FILE", ftmFile.isArchiveFile());
				output.put(tableName, count, "DESTINATION_FILE", ftmFile.isDestinationFile());
				output.put(tableName, count, "OID", ftmFile.getOid());
				output.put(tableName, count, "ERROR_SERVICE", ftmFile.getErrorService());
				output.put(tableName, count, "GM_CONN_OID", ftmFile.getGmConnectionOid());
				output.put(tableName, count, "COMPRESS_TYPE", ftmFile.getCompressTypeOid().toString());
				output.put(tableName, count, "GM_CONN_NAME", getConnectionName(ftmFile.getGmConnectionOid()));
				output.put(tableName, count, "INSTANCE_OID", ftmFile.getInstanceOid().toString());
				output.put(tableName, count, "IS_XML_ACTIVE", ftmFile.isRedesignFormat());
				output.put(tableName, count, "XML_FORMAT", ftmFile.getFileFormat());
			} else if (trxNo == null) {
				
				int count = 0;
				for (FtmFileDefinition ftmFile : ftmFiles) {
					
					fileDefTypeName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_FILE_DEF_TYPE_NAME, ftmFile.getFtmFileDefinitionTypeOid()));
					fileTypeName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_FILE_TYPE_NAME, ftmFile.getFileTypeOid()));
					encodingName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_ENCODING_NAME, ftmFile.getFileEncodingOid()));
					fileNameMask = ftmFile.getFileNameMask();
					
					output.put(tableName, count, "CONTINUAL", ftmFile.isContinual());
					output.put(tableName, count, "DURATION", ftmFile.getDuration());
					output.put(tableName, count, "ENCODING_NAME", encodingName);
					output.put(tableName, count, "FILE_DEF_TYPE_NAME", fileDefTypeName);
					output.put(tableName, count, "FILE_NAME_MASK", fileNameMask);
					output.put(tableName, count, "FILE_TYPE_NAME", fileTypeName);
					output.put(tableName, count, "NAME", ftmFile.getName());
					output.put(tableName, count, "SERVICE", ftmFile.getService());
					output.put(tableName, count, "STATE", String.valueOf(ftmFile.getFtmStateOid()));
					output.put(tableName, count, "OVERWRITE", ftmFile.isOverwrite());
					output.put(tableName, count, "READ_FILE", ftmFile.isReadFile());
					output.put(tableName, count, "DUPLICATE", ftmFile.isDuplicate());
					output.put(tableName, count, "DELETE_FILE", ftmFile.isDeleteFile());
					output.put(tableName, count, "ARCHIVE_FILE", ftmFile.isArchiveFile());
					output.put(tableName, count, "DESTINATION_FILE", ftmFile.isDestinationFile());
					output.put(tableName, count, "OID", ftmFile.getOid());
					output.put(tableName, count, "ERROR_SERVICE", ftmFile.getErrorService());
					output.put(tableName, count, "GM_CONN_OID", ftmFile.getGmConnectionOid());
					output.put(tableName, count, "COMPRESS_TYPE", ftmFile.getCompressTypeOid().toString());
					output.put(tableName, count, "GM_CONN_NAME", getConnectionName(ftmFile.getGmConnectionOid()));
					output.put(tableName, count, "INSTANCE_OID", ftmFile.getInstanceOid().toString());
					output.put(tableName, count, "IS_XML_ACTIVE", ftmFile.isRedesignFormat());
					output.put(tableName, count, "XML_FORMAT", ftmFile.getFileFormat());
					
					count++;
				}
			} else {
					FtmFileDefinitionTx ftmFile = (FtmFileDefinitionTx)hibernateSession.createCriteria(FtmFileDefinitionTx.class).add(Restrictions.eq("txNo", trxNo)).uniqueResult();
					
					fileDefTypeName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_FILE_DEF_TYPE_NAME, ftmFile.getFtmFileDefinitionTypeOid()));
					fileTypeName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_FILE_TYPE_NAME, ftmFile.getFileTypeOid()));
					encodingName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FILE_DEFINITIONS_ENCODING_NAME, ftmFile.getFileEncodingOid()));
					fileNameMask = ftmFile.getFileNameMask();
					int count = 0;
					output.put(tableName, count, "CONTINUAL", ftmFile.isContinual());
					output.put(tableName, count, "DURATION", ftmFile.getDuration());
					output.put(tableName, count, "ENCODING_NAME", encodingName);
					output.put(tableName, count, "FILE_DEF_TYPE_NAME", fileDefTypeName);
					output.put(tableName, count, "FILE_NAME_MASK", fileNameMask);
					output.put(tableName, count, "FILE_TYPE_NAME", fileTypeName);
					output.put(tableName, count, "NAME", ftmFile.getName());
					output.put(tableName, count, "SERVICE", ftmFile.getService());
					output.put(tableName, count, "STATE", String.valueOf(ftmFile.getFtmStateOid()));
					output.put(tableName, count, "OVERWRITE", ftmFile.isOverwrite());
					output.put(tableName, count, "READ_FILE", ftmFile.isReadFile());
					output.put(tableName, count, "DUPLICATE", ftmFile.isDuplicate());
					output.put(tableName, count, "DELETE_FILE", ftmFile.isDeleteFile());
					output.put(tableName, count, "ARCHIVE_FILE", ftmFile.isArchiveFile());
					output.put(tableName, count, "DESTINATION_FILE", ftmFile.isDestinationFile());
					output.put(tableName, count, "OID", ftmFile.getOid());
					output.put(tableName, count, "ERROR_SERVICE", ftmFile.getErrorService());
					output.put(tableName, count, "GM_CONN_OID", ftmFile.getGmConnectionOid());
					output.put(tableName, count, "COMPRESS_TYPE", ftmFile.getCompressTypeOid().toString());
					output.put(tableName, count, "GM_CONN_NAME", getConnectionName(ftmFile.getGmConnectionOid()));
					output.put(tableName, count, "INSTANCE_OID", ftmFile.getInstanceOid().toString());
					output.put(tableName, count, "IS_XML_ACTIVE", ftmFile.isRedesignFormat());
					output.put(tableName, count, "XML_FORMAT", ftmFile.getFileFormat());
			}
			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	private static String getConnectionName(BigDecimal gmConnectionOid) {
		String gmConnectionName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.GET_FTM_GM_CONNECTION_NAME, gmConnectionOid));
		return gmConnectionName;

	}

	@GraymoundService("CDM_GET_FTM_FTP_FILE_RELATIONS")
	public static GMMap getFtmFtpFileRelations(GMMap input) {
		GMMap output = new GMMap();
		try {
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			String tableName = "TABLE_DATA";
			if (trxNo == null)
				output = DALUtil.getResults(QueryRepository.FtmDefinitionServicesRepository.FTM_FTP_FILE_RELATIONS, tableName);
			else 
				output = DALUtil.getResults(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FTP_FILE_TX_RELATIONS, trxNo, trxNo, trxNo), tableName);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_FTM_FILE_EXEC_DATES")
	public static GMMap getFtmFileExecDates(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = "TABLE_DATA";
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			Boolean mailManagement = input.getBoolean("MAIL_MANAGEMENT");

			if (trxNo == null || mailManagement) {
				List<FtmFileExecutionTime> execDates = hibernateSession.createCriteria(FtmFileExecutionTime.class).add(Restrictions.eq("ftmFileDefinitionTypeOid", input.getBigDecimal("FTM_FILE_OID"))).addOrder(Order.asc("oid")).list();
				int count = 0;
				for (FtmFileExecutionTime execDate : execDates) {
					output.put(tableName, count, "BEGIN_DATE", execDate.getBeginDate());
					output.put(tableName, count, "END_DATE", execDate.getEndDate());
					output.put(tableName, count, "STATE", String.valueOf(execDate.getFtmStateOid()));
					output.put(tableName, count, "OID", execDate.getOid());
					count++;
				}				
			} else {
				FtmFileDefinitionTx ftmFile = (FtmFileDefinitionTx)hibernateSession.createCriteria(FtmFileDefinitionTx.class).add(Restrictions.eq("txNo", trxNo)).uniqueResult();
				FtmFileExecutionTimeTx execDate = (FtmFileExecutionTimeTx)hibernateSession.createCriteria(FtmFileExecutionTimeTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("ftmFileDefinitionTxOid", ftmFile.getTxOid())).uniqueResult();
				int count = 0;
				output.put(tableName, count, "BEGIN_DATE", execDate.getBeginDate());
				output.put(tableName, count, "END_DATE", execDate.getEndDate());
				output.put(tableName, count, "STATE", String.valueOf(execDate.getFtmStateOid()));
				output.put(tableName, count, "OID", execDate.getOid());
			}

			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_FTM_FILE_EXEC_SCHEDULE")
	public static GMMap getFtmFileExecSchedule(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = "TABLE_DATA";
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			Boolean mailManagement = input.getBoolean("MAIL_MANAGEMENT");
			String workingDayName = null;

			if (trxNo == null || mailManagement) {
				List<FtmFileExecutionSchedule> execSchedules = hibernateSession.createCriteria(FtmFileExecutionSchedule.class).add(Restrictions.eq("ftmFileExecutionTimeOid", input.getBigDecimal("FTM_FILE_EXEC_TIME_OID"))).addOrder(Order.asc("workingDayOid")).list();
				int count = 0;
				for (FtmFileExecutionSchedule execSchedule : execSchedules) {
					workingDayName = CommonHelper.getValueOfParameter("CDM_FTM_EXEC_SCHEDULE_DAYS", String.valueOf(execSchedule.getWorkingDayOid()));
					output.put(tableName, count, "WORKING_DAY_NAME", workingDayName);
					output.put(tableName, count, "WORKING_DAY", String.valueOf(execSchedule.getWorkingDayOid()));
					output.put(tableName, count, "SELECTION", true);
					output.put(tableName, count, "BEGIN_TIME", execSchedule.getBeginTime());
					output.put(tableName, count, "END_TIME", execSchedule.getEndTime());
					output.put(tableName, count, "OID", execSchedule.getOid());
					count++;
				}
			} else {
				FtmFileDefinitionTx ftmFile = (FtmFileDefinitionTx)hibernateSession.createCriteria(FtmFileDefinitionTx.class).add(Restrictions.eq("txNo", trxNo)).uniqueResult();
				FtmFileExecutionTimeTx execDate = (FtmFileExecutionTimeTx)hibernateSession.createCriteria(FtmFileExecutionTimeTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("ftmFileDefinitionTxOid", ftmFile.getTxOid())).uniqueResult();			
				List<FtmFileExecutionScheduleTx> execSchedules = hibernateSession.createCriteria(FtmFileExecutionScheduleTx.class).add(Restrictions.eq("ftmFileExecutionTimeTxOid", execDate.getTxOid())).addOrder(Order.asc("workingDayOid")).list();
				int count = 0;
				for (FtmFileExecutionScheduleTx execSchedule : execSchedules) {
					workingDayName = CommonHelper.getValueOfParameter("CDM_FTM_EXEC_SCHEDULE_DAYS", String.valueOf(execSchedule.getWorkingDayOid()));
					output.put(tableName, count, "WORKING_DAY_NAME", workingDayName);
					output.put(tableName, count, "WORKING_DAY", String.valueOf(execSchedule.getWorkingDayOid()));
					output.put(tableName, count, "SELECTION", true);
					output.put(tableName, count, "BEGIN_TIME", execSchedule.getBeginTime());
					output.put(tableName, count, "END_TIME", execSchedule.getEndTime());
					output.put(tableName, count, "OID", execSchedule.getOid());
					count++;
				}
			}
			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_SAVE_FTM_FTP_DEF")
	public static GMMap saveFtmFtpDef(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			
			BigDecimal ftmPlatformOid = input.getBigDecimal("FTM_PLATFORM_OID");
			String ftpName = input.getString("FTP_NAME");
			String ftpUrl = input.getString("FTP_URL");
			String ftpPort = input.getString("FTP_PORT");
			BigDecimal connectionTypeOid = input.getBigDecimal("CONNECTION_TYPE_OID");
			String ftpUserName = input.getString("FTP_USER_NAME");
			String ftpPassword = input.getString("FTP_PASSWORD");
			String ftpDescription = input.getString("FTP_DESCRIPTION");
			Short state = input.getBoolean("STATE") ? Short.valueOf("1") : Short.valueOf("0");
			String oid = input.getString("OID");
			String action = input.getString("ACTION");
			GMMap encryptInputMap = new GMMap(), encryptOutputMap = new GMMap();

			if (StringUtils.isEmpty(ftpName))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "FTP Ad�"));
			if (StringUtils.isEmpty(ftpUrl))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "URL"));
			if (StringUtils.isEmpty(ftpPort))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Port"));

			if (action.equals(DatabaseConstants.FtmOperationTypes.UPDATE) && StringUtils.isNotEmpty(oid)) {
				List<FtmFileDefinitionFtp> ftmFtpFileRels = hibernateSession.createCriteria(FtmFileDefinitionFtp.class).add(Restrictions.eq("ftmFtpDefinitionOid", new BigDecimal(oid))).list();
				if (ftmFtpFileRels.size() > 0) {
					if (!input.getBoolean("STATE"))
						throw new GMRuntimeException(0, "Mevcut FTP i�in tan�ml� dosya tipleri var. Pasife �ekmek i�in �nce bu FTP i�in tan�ml� olan dosya tipi ili�kileri silinmeli.");
				}
			}
			
			BigDecimal txNo = new BigDecimal(CommonHelper.getNewTransactionNo());
			
			FtmFtpDefinitionTx ftmFtpDefinitionTx = new FtmFtpDefinitionTx();
			if (action.equals(DatabaseConstants.FtmOperationTypes.INSERT))
				ftmFtpDefinitionTx.setOid(new BigDecimal(-1));	
			else if (action.equals(DatabaseConstants.FtmOperationTypes.UPDATE))
				ftmFtpDefinitionTx.setOid(new BigDecimal(oid));	
			ftmFtpDefinitionTx.setFtmPlatformOid(ftmPlatformOid);
			ftmFtpDefinitionTx.setName(ftpName);
			ftmFtpDefinitionTx.setUrl(ftpUrl);
			ftmFtpDefinitionTx.setPort(Integer.valueOf(ftpPort));
			ftmFtpDefinitionTx.setConnectionTypeOid(connectionTypeOid);
			ftmFtpDefinitionTx.setUsername(ftpUserName);
			if (StringUtils.isNotEmpty(ftpPassword)) {
				encryptInputMap.put("PLAIN_DATA", ftpPassword);
				encryptOutputMap = CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.FTM_CONNECTION_NAME, "BNSPR_FTM_ENCRYPT_DATA", encryptInputMap);
				ftmFtpDefinitionTx.setPassword(encryptOutputMap.getString("ENCRYPT_DATA"));
			}			
			ftmFtpDefinitionTx.setDescription(ftpDescription);
			ftmFtpDefinitionTx.setFtmStateOid(state);
			ftmFtpDefinitionTx.setTxNo(txNo);
			ftmFtpDefinitionTx.setStatus(true);
			hibernateSession.save(ftmFtpDefinitionTx);
			
			FtmTransactionDef ftmTransaction = new FtmTransactionDef();
			ftmTransaction.setTxNo(txNo);
			ftmTransaction.setTxType(DatabaseConstants.FtmTransactionTypes.FTP);
			ftmTransaction.setTxOperation(action);
			ftmTransaction.setStatus(true);
			ftmTransaction.setRecUser(CommonHelper.getCurrentUser());
			hibernateSession.save(ftmTransaction);
			
			input.put("TRX_NAME", "7018");
			input.put("TRX_NO", txNo);
			GMMap transactionMap = CommonBusinessOperations.callGraymoundService(input, "BNSPR_TRX_SEND_TRANSACTION", true);
			output.put("MESSAGE", transactionMap.getString("MESSAGE"));	

			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_SAVE_FTM_FILE_DEF")
	public static GMMap saveFtmFileDef(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			String fileDefTxOid = null, fileExecTimeTxOid = null;
			final String FILE_EXEC_TIME = "FILE_EXEC_TIME";
			final String FILE_EXEC_SCHEDULE = "FILE_EXEC_SCHEDULE";

			String fileName = input.getString("FILE_NAME");
			String fileNameMask = input.getString("FILE_NAME_MASK").replace("tilda", "~");
			String serviceName = input.getString("SERVICE_NAME");
			BigDecimal duration = input.getBigDecimal("DURATION");
			BigDecimal fileDefTypeOid = input.getBigDecimal("FILE_DEF_TYPE_OID");
			String fileTypeOid = input.getString("FILE_TYPE_OID");
			String fileEncodingOid = input.getString("FILE_ENCODING_OID");
			Short state = input.getBoolean("STATE") ? Short.valueOf("1") : Short.valueOf("0");
			Boolean continual = input.getBoolean("CONTINUAL");
			Boolean overWrite = input.getBoolean("OVERWRITE");
			Boolean readFile = input.getBoolean("READ_FILE");
			Boolean duplicate = input.getBoolean("DUPLICATE");
			Boolean deleteFile = input.getBoolean("DELETE_FILE");
			Boolean archiveFile = input.getBoolean("ARCHIVE_FILE");
			Boolean destinationFile = input.getBoolean("DESTINATION_FILE");
			String oid = input.getString("OID");
			String action = input.getString("ACTION");
			String errorService = input.getString("ERROR_SERVICE");
			BigDecimal gmConnectionOid = input.getBigDecimal("GM_CONN_OID");
			String compressType = input.getString("COMPRESS_TYPE");
			String instanceId = input.getString("INSTANCE_OID");
			Boolean isXmlActive = input.getBoolean("IS_XML_ACTIVE");
			String xmlFormat = input.getString("XML_FORMAT");

			if (StringUtils.isEmpty(fileName))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Dosya Tipi Ad�"));
			if (StringUtils.isEmpty(fileNameMask))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Dosya Mask�"));

			if (continual)
				if (duration == null)
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kontrol periyodu s�resi"));

			if (action.equals(DatabaseConstants.FtmOperationTypes.UPDATE) && StringUtils.isNotEmpty(oid)) {
				
				List<FtmFileDefinitionFtp> ftmFtpFileRels = hibernateSession.createCriteria(FtmFileDefinitionFtp.class).add(Restrictions.eq("ftmFileDefinitionOid", new BigDecimal(oid))).list();
				if (ftmFtpFileRels.size() > 0) {
					if (fileDefTypeOid.compareTo(new BigDecimal(1)) == 0) {
						List<FtmFileDefinitionFtp> ftmFtpFileSourceRels = hibernateSession.createCriteria(FtmFileDefinitionFtp.class).add(Restrictions.eq("ftmFileDefinitionOid", new BigDecimal(oid))).add(Restrictions.eq("ftmFileDefFtpTypeOid", new BigDecimal(1))).list();
						if (ftmFtpFileSourceRels.size() == 0)
							throw new GMRuntimeException(0, "\"Otomatik Dosya Transferi\"'ni se�ebilmek i�in �nce ilgili dosya tipine Kaynak FTP'si tan�mlay�n�z.");
					}

					if (archiveFile) {
						List<FtmFileDefinitionFtp> ftmFtpFileArchiveRels = hibernateSession.createCriteria(FtmFileDefinitionFtp.class).add(Restrictions.eq("ftmFileDefinitionOid", new BigDecimal(oid))).add(Restrictions.eq("ftmFileDefFtpTypeOid", new BigDecimal(3))).list();
						if (ftmFtpFileArchiveRels.size() == 0)
							throw new GMRuntimeException(0, "\"Ar�iv\" se�ene�ini se�ebilmek i�in �nce ilgili dosya tipine Ar�iv FTP'si tan�mlay�n�z.");
					}
					//if (!input.getBoolean("STATE"))
					//	throw new GMRuntimeException(0, "Mevcut dosya tipi i�in FTP tan�mlar� var. Pasife �ekmek i�in �nce FTP tan�mlar� silinmeli.");
				}
			}
			
			BigDecimal txNo = new BigDecimal(CommonHelper.getNewTransactionNo());
			
			FtmFileDefinitionTx ftmFileDefinitionTx = new FtmFileDefinitionTx();
			
			if (action.equals(DatabaseConstants.FtmOperationTypes.INSERT))
				ftmFileDefinitionTx.setOid(new BigDecimal(-1));	
			else if (action.equals(DatabaseConstants.FtmOperationTypes.UPDATE))
				ftmFileDefinitionTx.setOid(new BigDecimal(oid));	
			ftmFileDefinitionTx.setName(fileName);
			ftmFileDefinitionTx.setFileNameMask(fileNameMask);
			ftmFileDefinitionTx.setService(serviceName);
			ftmFileDefinitionTx.setDuration(duration);
			ftmFileDefinitionTx.setFtmFileDefinitionTypeOid(fileDefTypeOid);
			ftmFileDefinitionTx.setFileTypeOid(Byte.valueOf(fileTypeOid));
			ftmFileDefinitionTx.setFileEncodingOid(Byte.valueOf(fileEncodingOid));
			ftmFileDefinitionTx.setFtmStateOid(state);
			ftmFileDefinitionTx.setContinual(continual);
			ftmFileDefinitionTx.setOverwrite(overWrite);
			ftmFileDefinitionTx.setReadFile(readFile);
			ftmFileDefinitionTx.setDuplicate(duplicate);
			ftmFileDefinitionTx.setDeleteFile(deleteFile);
			ftmFileDefinitionTx.setArchiveFile(archiveFile);
			ftmFileDefinitionTx.setRedesignFormat(false);
			ftmFileDefinitionTx.setDestinationFile(destinationFile);
			ftmFileDefinitionTx.setErrorService(errorService);
			ftmFileDefinitionTx.setGmConnectionOid(gmConnectionOid);
			ftmFileDefinitionTx.setCompressTypeOid(new BigDecimal(compressType));
			ftmFileDefinitionTx.setInstanceOid(new BigDecimal(instanceId));
			ftmFileDefinitionTx.setErrorTryCount(true);
			if (fileTypeOid.equals("3") || fileTypeOid.equals("4")) {
				ftmFileDefinitionTx.setRedesignFormat(isXmlActive);
				ftmFileDefinitionTx.setFileFormat(xmlFormat);
			}
			ftmFileDefinitionTx.setTxNo(txNo);
			ftmFileDefinitionTx.setStatus(true);
			hibernateSession.save(ftmFileDefinitionTx);			
			fileDefTxOid = ftmFileDefinitionTx.getTxOid();
			
			for(int i = 0; i < input.getSize(FILE_EXEC_TIME); i++) {
				Short execTimeState = input.getBoolean(FILE_EXEC_TIME, i, "STATE") ? Short.valueOf("1") : Short.valueOf("0");
				
				FtmFileExecutionTimeTx ftmFileExecutionTimeTx = new FtmFileExecutionTimeTx();
				ftmFileExecutionTimeTx.setBeginDate(CommonHelper.getDateTime(input.getString(FILE_EXEC_TIME, i, "BEGIN_DATE"), "yyyyMMdd"));
				ftmFileExecutionTimeTx.setEndDate(CommonHelper.getDateTime(input.getString(FILE_EXEC_TIME, i, "END_DATE"), "yyyyMMdd"));
				ftmFileExecutionTimeTx.setFtmStateOid(execTimeState);
				ftmFileExecutionTimeTx.setStatus(true);
				ftmFileExecutionTimeTx.setFtmFileDefinitionTxOid(fileDefTxOid);
				hibernateSession.save(ftmFileExecutionTimeTx);	
				fileExecTimeTxOid = ftmFileExecutionTimeTx.getTxOid();
				
				for(int j = 0; j < input.getSize(FILE_EXEC_SCHEDULE); j++) {
					FtmFileExecutionScheduleTx ftmFileExecutionScheduleTx = new FtmFileExecutionScheduleTx();
					ftmFileExecutionScheduleTx.setBeginTime(input.getString(FILE_EXEC_SCHEDULE, j, "BEGIN_TIME"));
					ftmFileExecutionScheduleTx.setEndTime(input.getString(FILE_EXEC_SCHEDULE, j, "END_TIME"));
					ftmFileExecutionScheduleTx.setWorkingDayOid(Byte.valueOf(input.getString(FILE_EXEC_SCHEDULE, j, "WORKING_DAY")));
					ftmFileExecutionScheduleTx.setStatus(true);
					ftmFileExecutionScheduleTx.setFtmFileExecutionTimeTxOid(fileExecTimeTxOid);
					hibernateSession.save(ftmFileExecutionScheduleTx);
				}
			}
			
			FtmTransactionDef ftmTransaction = new FtmTransactionDef();
			ftmTransaction.setTxNo(txNo);
			ftmTransaction.setTxType(DatabaseConstants.FtmTransactionTypes.FILE);
			ftmTransaction.setTxOperation(action);
			ftmTransaction.setStatus(true);
			ftmTransaction.setRecUser(CommonHelper.getCurrentUser());
			hibernateSession.save(ftmTransaction);
			
			input.put("TRX_NAME", "7018");
			input.put("TRX_NO", txNo);
			GMMap transactionMap = CommonBusinessOperations.callGraymoundService(input, "BNSPR_TRX_SEND_TRANSACTION", true);
			output.put("MESSAGE", transactionMap.getString("MESSAGE"));	
			
			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_SAVE_FTM_FTP_FILE_REL")
	public static GMMap saveFtmFtpFileRel(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();

			BigDecimal sourceFtpOid = input.getBigDecimal("SOURCE_FTP_OID");
			BigDecimal destFtpOid = input.getBigDecimal("DEST_FTP_OID");
			BigDecimal archiveFtpOid = input.getBigDecimal("ARCHIVE_FTP_OID");
			String sourcePath = input.getString("SOURCE_PATH");
			String destPath = input.getString("DEST_PATH");
			String archivePath = input.getString("ARCHIVE_PATH");
			String sourceOid = input.getString("SOURCE_OID");
			String destOid = input.getString("DEST_OID");
			String archiveOid = input.getString("ARCHIVE_OID");
			BigDecimal ftmFileOid = input.getBigDecimal("FTM_FILE_OID");
			String action = input.getString("ACTION");
			String fileName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.FTM_FTP_FILE_REL, ftmFileOid));

			if (ftmFileOid == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Dosya Tipi"));

			if (destFtpOid == null || destFtpOid.compareTo(new BigDecimal(0)) == 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Hedef FTP"));

			if ("".equals(destPath) || destPath == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Hedef FTP Dizini"));

			controlSourceArchiveConditions(input);

			BigDecimal txNo = new BigDecimal(CommonHelper.getNewTransactionNo());
			
			if (action.equals(DatabaseConstants.FtmOperationTypes.INSERT)) {

				List<FtmFileDefinitionFtp> ftmFtpFileRels = hibernateSession.createCriteria(FtmFileDefinitionFtp.class).add(Restrictions.eq("ftmFileDefinitionOid", ftmFileOid)).list();

				for (FtmFileDefinitionFtp ftmFtpFileRel : ftmFtpFileRels) {
					if (ftmFtpFileRel.getFtmFileDefFtpTypeOid().compareTo(new BigDecimal(1)) == 0)
						throw new GMRuntimeException(0, String.format("\"%s\" dosya tipi i�in tan�ml� Kaynak FTP vard�r. �kinci kez tan�m yap�lamaz.", fileName));
					if (ftmFtpFileRel.getFtmFileDefFtpTypeOid().compareTo(new BigDecimal(2)) == 0)
						throw new GMRuntimeException(0, String.format("\"%s\" dosya tipi i�in tan�ml� Hedef FTP vard�r. �kinci kez tan�m yap�lamaz.", fileName));
					if (ftmFtpFileRel.getFtmFileDefFtpTypeOid().compareTo(new BigDecimal(3)) == 0)
						throw new GMRuntimeException(0, String.format("\"%s\" dosya tipi i�in tan�ml� Ar�iv FTP vard�r. �kinci kez tan�m yap�lamaz.", fileName));
				}

				if (sourceFtpOid != null && sourceFtpOid.compareTo(new BigDecimal(0)) != 0) {
					if ("".equals(sourcePath) || sourcePath == null)
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kaynak FTP Dizini"));
					FtmFileDefinitionFtpTx ftmSourceFtpTx = new FtmFileDefinitionFtpTx();
					ftmSourceFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmSourceFtpTx.setFtmFtpDefinitionOid(sourceFtpOid);
					ftmSourceFtpTx.setPath(sourcePath);
					ftmSourceFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(1));
					ftmSourceFtpTx.setTxNo(txNo);
					ftmSourceFtpTx.setStatus(true);
					hibernateSession.save(ftmSourceFtpTx);
				}

				if (destFtpOid != null && destFtpOid.compareTo(new BigDecimal(0)) != 0) {
					FtmFileDefinitionFtpTx ftmDestinationFtpTx = new FtmFileDefinitionFtpTx();
					ftmDestinationFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmDestinationFtpTx.setFtmFtpDefinitionOid(destFtpOid);
					ftmDestinationFtpTx.setPath(destPath);
					ftmDestinationFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(2));
					ftmDestinationFtpTx.setTxNo(txNo);
					ftmDestinationFtpTx.setStatus(true);					
					hibernateSession.save(ftmDestinationFtpTx);
				}

				if (archiveFtpOid != null && archiveFtpOid.compareTo(new BigDecimal(0)) != 0) {
					if ("".equals(archivePath) || archivePath == null)
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ar�iv FTP Dizini"));
					FtmFileDefinitionFtpTx ftmArchiveFtpTx = new FtmFileDefinitionFtpTx();
					ftmArchiveFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmArchiveFtpTx.setFtmFtpDefinitionOid(archiveFtpOid);
					ftmArchiveFtpTx.setPath(archivePath);
					ftmArchiveFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(3));
					ftmArchiveFtpTx.setTxNo(txNo);
					ftmArchiveFtpTx.setStatus(true);					
					hibernateSession.save(ftmArchiveFtpTx);
				}
			}
			else if (action.equals(DatabaseConstants.FtmOperationTypes.UPDATE)) {
				
				if (StringUtils.isNotBlank(sourceOid)) {
					if (sourceFtpOid != null && sourceFtpOid.compareTo(new BigDecimal(0)) != 0) {
						// UPDATE SOURCE
						if ("".equals(sourcePath) || sourcePath == null)
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kaynak FTP Dizini"));
						FtmFileDefinitionFtpTx ftmSourceFtpTx = new FtmFileDefinitionFtpTx();
						ftmSourceFtpTx.setOid(new BigDecimal(sourceOid));					
						ftmSourceFtpTx.setFtmFileDefinitionOid(ftmFileOid);
						ftmSourceFtpTx.setFtmFtpDefinitionOid(sourceFtpOid);
						ftmSourceFtpTx.setPath(sourcePath);
						ftmSourceFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(1));
						ftmSourceFtpTx.setTxNo(txNo);
						ftmSourceFtpTx.setStatus(true);
						hibernateSession.save(ftmSourceFtpTx);
					}
					else if (sourceFtpOid != null && sourceFtpOid.compareTo(new BigDecimal(0)) == 0) {
						// DELETE SOURCE
						controlSourceArchiveConditions(input);
						FtmFileDefinitionFtpTx ftmSourceFtpTx = new FtmFileDefinitionFtpTx();
						ftmSourceFtpTx.setOid(new BigDecimal(sourceOid));					
						ftmSourceFtpTx.setFtmFileDefinitionOid(ftmFileOid);
						ftmSourceFtpTx.setFtmFtpDefinitionOid(null);
						ftmSourceFtpTx.setPath(null);
						ftmSourceFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(1));
						ftmSourceFtpTx.setTxNo(txNo);
						ftmSourceFtpTx.setStatus(true);
						hibernateSession.save(ftmSourceFtpTx);	
					}
				}
				else if (StringUtils.isBlank(sourceOid) && (sourceFtpOid != null && sourceFtpOid.compareTo(new BigDecimal(0)) != 0)) {
					// INSERT SOURCE
					if ("".equals(sourcePath) || sourcePath == null)
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kaynak FTP Dizini"));
					FtmFileDefinitionFtpTx ftmSourceFtpTx = new FtmFileDefinitionFtpTx();
					ftmSourceFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmSourceFtpTx.setFtmFtpDefinitionOid(sourceFtpOid);
					ftmSourceFtpTx.setPath(sourcePath);
					ftmSourceFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(1));
					ftmSourceFtpTx.setTxNo(txNo);
					ftmSourceFtpTx.setStatus(true);
					hibernateSession.save(ftmSourceFtpTx);
				}

				if (StringUtils.isNotBlank(destOid) && (destFtpOid != null && destFtpOid.compareTo(new BigDecimal(0)) != 0)) {
					// UPDATE DESTINATION
					FtmFileDefinitionFtpTx ftmDestinationFtpTx = new FtmFileDefinitionFtpTx();
					ftmDestinationFtpTx.setOid(new BigDecimal(destOid));	
					ftmDestinationFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmDestinationFtpTx.setFtmFtpDefinitionOid(destFtpOid);
					ftmDestinationFtpTx.setPath(destPath);
					ftmDestinationFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(2));
					ftmDestinationFtpTx.setTxNo(txNo);
					ftmDestinationFtpTx.setStatus(true);					
					hibernateSession.save(ftmDestinationFtpTx);
				}

				if (StringUtils.isNotBlank(archiveOid)) {
					if (archiveFtpOid != null && archiveFtpOid.compareTo(new BigDecimal(0)) != 0) {
						// UPDATE ARCHIVE
						if ("".equals(archivePath) || archivePath == null)
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ar�iv FTP Dizini"));
						FtmFileDefinitionFtpTx ftmArchiveFtpTx = new FtmFileDefinitionFtpTx();
						ftmArchiveFtpTx.setOid(new BigDecimal(archiveOid));					
						ftmArchiveFtpTx.setFtmFileDefinitionOid(ftmFileOid);
						ftmArchiveFtpTx.setFtmFtpDefinitionOid(archiveFtpOid);
						ftmArchiveFtpTx.setPath(archivePath);
						ftmArchiveFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(3));
						ftmArchiveFtpTx.setTxNo(txNo);
						ftmArchiveFtpTx.setStatus(true);
						hibernateSession.save(ftmArchiveFtpTx);
					}
					else if (archiveFtpOid != null && archiveFtpOid.compareTo(new BigDecimal(0)) == 0) {
						// DELETE ARCHIVE
						controlSourceArchiveConditions(input);
						FtmFileDefinitionFtpTx ftmArchiveFtpTx = new FtmFileDefinitionFtpTx();
						ftmArchiveFtpTx.setOid(new BigDecimal(archiveOid));					
						ftmArchiveFtpTx.setFtmFileDefinitionOid(ftmFileOid);
						ftmArchiveFtpTx.setFtmFtpDefinitionOid(null);
						ftmArchiveFtpTx.setPath(null);
						ftmArchiveFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(3));
						ftmArchiveFtpTx.setTxNo(txNo);
						ftmArchiveFtpTx.setStatus(true);
						hibernateSession.save(ftmArchiveFtpTx);
					}
				}
				else if (StringUtils.isBlank(archiveOid) && (archiveFtpOid != null && archiveFtpOid.compareTo(new BigDecimal(0)) != 0)) {
					// INSERT ARCHIVE
					if ("".equals(archivePath) || archivePath == null)
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ar�iv FTP Dizini"));
					FtmFileDefinitionFtpTx ftmArchiveFtpTx = new FtmFileDefinitionFtpTx();
					ftmArchiveFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmArchiveFtpTx.setFtmFtpDefinitionOid(archiveFtpOid);
					ftmArchiveFtpTx.setPath(archivePath);
					ftmArchiveFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(3));
					ftmArchiveFtpTx.setTxNo(txNo);
					ftmArchiveFtpTx.setStatus(true);					
					hibernateSession.save(ftmArchiveFtpTx);
				}
			}
			else if (action.equals(DatabaseConstants.FtmOperationTypes.DELETE)) {
				if (StringUtils.isNotBlank(sourceOid)) {
					FtmFileDefinitionFtpTx ftmSourceFtpTx = new FtmFileDefinitionFtpTx();
					ftmSourceFtpTx.setOid(new BigDecimal(sourceOid));					
					ftmSourceFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmSourceFtpTx.setFtmFtpDefinitionOid(null);
					ftmSourceFtpTx.setPath(null);
					ftmSourceFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(1));
					ftmSourceFtpTx.setTxNo(txNo);
					ftmSourceFtpTx.setStatus(true);
					hibernateSession.save(ftmSourceFtpTx);	
				}

				if (StringUtils.isNotBlank(destOid)) {
					FtmFileDefinitionFtpTx ftmDestinationFtpTx = new FtmFileDefinitionFtpTx();
					ftmDestinationFtpTx.setOid(new BigDecimal(destOid));					
					ftmDestinationFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmDestinationFtpTx.setFtmFtpDefinitionOid(null);
					ftmDestinationFtpTx.setPath(null);
					ftmDestinationFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(2));
					ftmDestinationFtpTx.setTxNo(txNo);
					ftmDestinationFtpTx.setStatus(true);
					hibernateSession.save(ftmDestinationFtpTx);	
				}

				if (StringUtils.isNotBlank(archiveOid)) {
					FtmFileDefinitionFtpTx ftmArchiveFtpTx = new FtmFileDefinitionFtpTx();
					ftmArchiveFtpTx.setOid(new BigDecimal(archiveOid));					
					ftmArchiveFtpTx.setFtmFileDefinitionOid(ftmFileOid);
					ftmArchiveFtpTx.setFtmFtpDefinitionOid(null);
					ftmArchiveFtpTx.setPath(null);
					ftmArchiveFtpTx.setFtmFileDefFtpTypeOid(new BigDecimal(3));
					ftmArchiveFtpTx.setTxNo(txNo);
					ftmArchiveFtpTx.setStatus(true);
					hibernateSession.save(ftmArchiveFtpTx);	
				}
			}
			
			FtmTransactionDef ftmTransaction = new FtmTransactionDef();
			ftmTransaction.setTxNo(txNo);
			ftmTransaction.setTxType(DatabaseConstants.FtmTransactionTypes.FTP_FILE_REL);
			ftmTransaction.setTxOperation(action);			
			ftmTransaction.setStatus(true);
			ftmTransaction.setRecUser(CommonHelper.getCurrentUser());
			hibernateSession.save(ftmTransaction);
			
			input.put("TRX_NAME", "7018");
			input.put("TRX_NO", txNo);
			GMMap transactionMap = CommonBusinessOperations.callGraymoundService(input, "BNSPR_TRX_SEND_TRANSACTION", true);
			output.put("MESSAGE", transactionMap.getString("MESSAGE"));	
			
			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	private static void controlSourceArchiveConditions(GMMap input) {
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();

			BigDecimal sourceFtpOid = input.getBigDecimal("SOURCE_FTP_OID");
			BigDecimal archiveFtpOid = input.getBigDecimal("ARCHIVE_FTP_OID");
			String sourcePath = input.getString("SOURCE_PATH");
			String archivePath = input.getString("ARCHIVE_PATH");
			BigDecimal ftmFileOid = input.getBigDecimal("FTM_FILE_OID");
			String fileName = DALUtil.getResult(String.format(QueryRepository.FtmDefinitionServicesRepository.CONTROL_SOURCE_ARCHIVE_CONDITIONS, ftmFileOid));

			FtmFileDefinition ftmFileDefinition = (FtmFileDefinition) hibernateSession.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("oid", ftmFileOid)).uniqueResult();

			if (ftmFileDefinition != null) {
				if (ftmFileDefinition.getFtmFileDefinitionTypeOid().compareTo(new BigDecimal(1)) == 0) {
					if (sourceFtpOid == null || sourceFtpOid.compareTo(new BigDecimal(0)) == 0)
						throw new GMRuntimeException(0, String.format("\"%s\" dosya tipi i�in Kaynak FTP se�imi zorunludur", fileName));

					if ("".equals(sourcePath) || sourcePath == null)
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Kaynak FTP Dizini"));
				}

				if (ftmFileDefinition.isArchiveFile()) {
					if (archiveFtpOid == null || archiveFtpOid.compareTo(new BigDecimal(0)) == 0)
						throw new GMRuntimeException(0, String.format("\"%s\" dosya tipi i�in Ar�iv FTP se�imi zorunludur", fileName));

					if ("".equals(archivePath) || archivePath == null)
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ar�iv FTP Dizini"));
				}
			}
			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_SAVE_FTM_FILE_EXEC_TIME")
	public static GMMap saveFtmFileExecTime(GMMap input) {
		GMMap output = new GMMap();
		try {
			String beginDate = input.getString("BEGIN_DATE");
			String endDate = input.getString("END_DATE");
			String oid = input.getString("OID");
			String action = input.getString("ACTION");
			final String FILE_EXEC_TIME = "FILE_EXEC_TIME";
			int selectedRow = input.getInt("SELECTED_ROW");

			if (input.getDate("BEGIN_DATE") == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));

			if (input.getDate("END_DATE") == null)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));

			
			if (action.equals(DatabaseConstants.FtmOperationTypes.INSERT)) {
				int insertRow = input.getSize(FILE_EXEC_TIME);
				if (insertRow > 0)
					throw new GMRuntimeException(0, "Ayn� anda en fazla bir tane kontrol zaman tarih aral��� tan�mlayabilirsiniz");
				output.put(FILE_EXEC_TIME, input.get(FILE_EXEC_TIME));
				output.put(FILE_EXEC_TIME, insertRow, "BEGIN_DATE", beginDate);
				output.put(FILE_EXEC_TIME, insertRow, "END_DATE", endDate);
				output.put(FILE_EXEC_TIME, insertRow, "STATE", input.getBoolean("STATE"));
				output.put(FILE_EXEC_TIME, insertRow, "OID", "");
			}
			else if (action.equals(DatabaseConstants.FtmOperationTypes.UPDATE)) {
				output.put(FILE_EXEC_TIME, input.get(FILE_EXEC_TIME));
				output.put(FILE_EXEC_TIME, selectedRow, "BEGIN_DATE", beginDate);
				output.put(FILE_EXEC_TIME, selectedRow, "END_DATE", endDate);
				output.put(FILE_EXEC_TIME, selectedRow, "STATE", input.getBoolean("STATE"));
				output.put(FILE_EXEC_TIME, selectedRow, "OID", oid);
			}
			else if (action.equals(DatabaseConstants.FtmOperationTypes.DELETE)) {
				int rowCount = 0;
				for (int i = 0; i < input.getSize(FILE_EXEC_TIME); i++ ) {
					if (i != selectedRow) {
						output.put(FILE_EXEC_TIME, rowCount, "BEGIN_DATE", input.getString(FILE_EXEC_TIME, i, "BEGIN_DATE"));
						output.put(FILE_EXEC_TIME, rowCount, "END_DATE", input.getString(FILE_EXEC_TIME, i, "END_DATE"));
						output.put(FILE_EXEC_TIME, rowCount, "STATE", input.getString(FILE_EXEC_TIME, i, "STATE"));
						output.put(FILE_EXEC_TIME, rowCount, "OID", input.getString(FILE_EXEC_TIME, i, "OID"));
						rowCount++;
					}
				}					
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_SAVE_FTM_FILE_EXEC_SCHEDULE")
	public static GMMap saveFtmFileExecSchedule(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();

			String beginTime = input.getString("BEGIN_TIME");
			String endTime = input.getString("END_TIME");
			String workingDay = input.getString("WORKING_DAY");
			String oid = input.getString("OID");
			String action = input.getString("ACTION");
			final String FILE_EXEC_SCHEDULE = "FILE_EXEC_SCHEDULE";
			int selectedRow = input.getInt("SELECTED_ROW");
			String workingDayName = null;

			if (StringUtils.isEmpty(beginTime) || beginTime.length() < 4)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Saati"));
			if (StringUtils.isEmpty(endTime) || endTime.length() < 4)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Saati"));
			if (StringUtils.isEmpty(workingDay))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "G�n"));

			String beginTimeColon = beginTime.substring(0, 2) + ":" + beginTime.substring(2, 4);
			String endTimeColon = endTime.substring(0, 2) + ":" + endTime.substring(2, 4);

			if (action.equals(DatabaseConstants.FtmOperationTypes.INSERT)) {
				
				for (int i = 0; i < input.getSize(FILE_EXEC_SCHEDULE); i++ ) {
					if (input.getString(FILE_EXEC_SCHEDULE, i, "WORKING_DAY").equals(workingDay))
						throw new GMRuntimeException(0, "Se�ilen g�n i�in tan�mlanm�� bilgiler mevcuttur. Ayn� g�n yeniden eklenemez.");
				}	

				if (input.getSize(FILE_EXEC_SCHEDULE) == 1 && input.getString(FILE_EXEC_SCHEDULE, 0, "WORKING_DAY").equals("0"))
					throw new GMRuntimeException(0, "\"Herg�n\" se�ilmi�tir. Ba�ka g�n eklenemez.");
				
				if (!"0".equals(workingDay))
					output.put(FILE_EXEC_SCHEDULE, input.get(FILE_EXEC_SCHEDULE));
				
				workingDayName = CommonHelper.getValueOfParameter("CDM_FTM_EXEC_SCHEDULE_DAYS", workingDay);
				int insertRow = input.getSize(FILE_EXEC_SCHEDULE);
				output.put(FILE_EXEC_SCHEDULE, insertRow, "BEGIN_TIME", beginTimeColon);
				output.put(FILE_EXEC_SCHEDULE, insertRow, "END_TIME", endTimeColon);
				output.put(FILE_EXEC_SCHEDULE, insertRow, "WORKING_DAY", workingDay); 
				output.put(FILE_EXEC_SCHEDULE, insertRow, "WORKING_DAY_NAME", workingDayName); 
				output.put(FILE_EXEC_SCHEDULE, insertRow, "OID", "");
			}
			else if (action.equals(DatabaseConstants.FtmOperationTypes.UPDATE)) {
				
				if (!input.getString(FILE_EXEC_SCHEDULE, selectedRow, "WORKING_DAY").equals(workingDay)) {
					for (int i = 0; i < input.getSize(FILE_EXEC_SCHEDULE); i++ ) {
						if (input.getString(FILE_EXEC_SCHEDULE, i, "WORKING_DAY").equals(workingDay))
							throw new GMRuntimeException(0, "Se�ilen g�n i�in tan�mlanm�� bilgiler mevcuttur. Ayn� g�n yeniden eklenemez.");
					}	
				}
				
				if (!"0".equals(workingDay))
					output.put(FILE_EXEC_SCHEDULE, input.get(FILE_EXEC_SCHEDULE));
				else
					selectedRow = 0;
				
				workingDayName = CommonHelper.getValueOfParameter("CDM_FTM_EXEC_SCHEDULE_DAYS", workingDay);
				output.put(FILE_EXEC_SCHEDULE, selectedRow, "BEGIN_TIME", beginTimeColon);
				output.put(FILE_EXEC_SCHEDULE, selectedRow, "END_TIME", endTimeColon);
				output.put(FILE_EXEC_SCHEDULE, selectedRow, "WORKING_DAY", workingDay); 
				output.put(FILE_EXEC_SCHEDULE, selectedRow, "WORKING_DAY_NAME", workingDayName); 
				output.put(FILE_EXEC_SCHEDULE, selectedRow, "OID", oid);
			}
			else if (action.equals(DatabaseConstants.FtmOperationTypes.DELETE)) {
				int rowCount = 0;
				for (int i = 0; i < input.getSize(FILE_EXEC_SCHEDULE); i++ ) {
					if (i != selectedRow) {
						output.put(FILE_EXEC_SCHEDULE, rowCount, "BEGIN_TIME", input.getString(FILE_EXEC_SCHEDULE, i, "BEGIN_TIME"));
						output.put(FILE_EXEC_SCHEDULE, rowCount, "END_TIME", input.getString(FILE_EXEC_SCHEDULE, i, "END_TIME"));
						output.put(FILE_EXEC_SCHEDULE, rowCount, "WORKING_DAY", input.getString(FILE_EXEC_SCHEDULE, i, "WORKING_DAY"));
						output.put(FILE_EXEC_SCHEDULE, rowCount, "WORKING_DAY_NAME", input.getString(FILE_EXEC_SCHEDULE, i, "WORKING_DAY_NAME"));
						output.put(FILE_EXEC_SCHEDULE, rowCount, "OID", input.getString(FILE_EXEC_SCHEDULE, i, "OID"));
						rowCount++;
					}
				}		
			}

			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_RESTART_FTM")
	public static GMMap restartFtm(GMMap input) {
		GMMap output = new GMMap();
		try {
			GMMap serviceInputMap = new GMMap();

			output = CommonHelper.callGraymoundServiceWithExternalConnection(getFtmInstanceConnectionName(input.getString("INSTANCE_OID")), "BNSPR_FTM_RESTART", serviceInputMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_REFRESH_FTM_CACHE")
	public static GMMap refreshFtmCache(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			BigDecimal txNo = new BigDecimal(CommonHelper.getNewTransactionNo());
			FtmTransactionDef ftmTransaction = new FtmTransactionDef();
			ftmTransaction.setTxNo(txNo);
			ftmTransaction.setTxType(DatabaseConstants.FtmTransactionTypes.REFRESH_FTM);
			ftmTransaction.setInstanceOid(input.getString("INSTANCE_OID"));
			ftmTransaction.setStatus(true);
			ftmTransaction.setRecUser(CommonHelper.getCurrentUser());
			session.save(ftmTransaction);
			
			input.put("TRX_NAME", "7018");
			input.put("TRX_NO", txNo);
			GMMap transactionMap = CommonBusinessOperations.callGraymoundService(input, "BNSPR_TRX_SEND_TRANSACTION", true);
			output.put("MESSAGE", transactionMap.getString("MESSAGE"));	
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	private static String getFtmInstanceConnectionName(String instanceId){
		if(!StringUtils.isEmpty(instanceId)){
			if(instanceId.equals("2")){
				return GeneralConstants.FTM_EXT_CONNECTION_NAME;
			}
		}
		return GeneralConstants.FTM_CONNECTION_NAME;
	}
	
	@GraymoundService("CDM_TRIGGER_FTM_FILE_DEFINITIONS")
	public static GMMap triggerFtmFileDefinitions(GMMap input) {
		GMMap output = new GMMap();
		try {
			String ftmDefId = input.getString("OID");
			String instanceId = input.getString("INSTANCE_OID");
			GMMap ftmTriggerFileMap = new GMMap();
			ftmTriggerFileMap.put("FILE_DEF_ID", ftmDefId);
			ftmTriggerFileMap.put("USE_SCHEDULE", false);
			ftmTriggerFileMap.put("INSTANCE_OID", instanceId);
			
			GMServiceExecuter.executeAsync("CDM_TRIGGER_FTM_FILE_DEFINITION_WRAPPER", ftmTriggerFileMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("CDM_TRIGGER_FTM_FILE_DEFINITION_WRAPPER")
	public static GMMap triggerFtmFileDefinitionWrapper(GMMap input) {
		GMMap output = new GMMap();

		try {
			output = CommonHelper.callGraymoundServiceWithExternalConnection(getFtmInstanceConnectionName(input.getString("INSTANCE_OID")), "BNSPR_FTM_TRIGGER_AUTO_TRANSFER_FILE", input);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("FTM_SAVE_EMAIL_NOTIFICATION")
	public static GMMap ftmSaveEmailNotification(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			BigDecimal currentParameterFtmID = input.getBigDecimal("FTM_OID");
			BigDecimal txNo = new BigDecimal(CommonHelper.getNewTransactionNo());

			for (int i = 0; i < input.getSize("TABLE_DATA"); i++) {
				Short stateOid = 0;
				FtmNotificationTx ftmNotificationTx = new FtmNotificationTx();
				ftmNotificationTx.setOid(new BigDecimal(-1));
				ftmNotificationTx.setFtmFileDefinitionOid(currentParameterFtmID);
				ftmNotificationTx.setFtmNotificationOid(new Byte(input.getString("TABLE_DATA", i, "TYPE")));
				if ("Aktif".equals(input.getString("TABLE_DATA", i, "STATUS"))) {
					stateOid = 1;
				}
				ftmNotificationTx.setFtmStateOid(stateOid);
				ftmNotificationTx.setMailCc(input.getString("TABLE_DATA", i, "CC"));
				ftmNotificationTx.setMailTo(input.getString("TABLE_DATA", i, "TO"));
				ftmNotificationTx.setName(input.getString("TABLE_DATA", i, "TITLE"));
				ftmNotificationTx.setCron(input.getString("TABLE_DATA", i, "CRON"));
				ftmNotificationTx.setStatus(true);
				ftmNotificationTx.setTxNo(txNo);
				session.saveOrUpdate(ftmNotificationTx);
			}
			
			FtmTransactionDef ftmTransaction = new FtmTransactionDef();
			ftmTransaction.setTxNo(txNo);
			ftmTransaction.setTxType(DatabaseConstants.FtmTransactionTypes.MAIL_NOTIFICATION);
			ftmTransaction.setStatus(true);
			ftmTransaction.setRecUser(CommonHelper.getCurrentUser());
			session.save(ftmTransaction);
			
			input.put("TRX_NAME", "7018");
			input.put("TRX_NO", txNo);
			GMMap transactionMap = CommonBusinessOperations.callGraymoundService(input, "BNSPR_TRX_SEND_TRANSACTION", true);
			output.put("MESSAGE", transactionMap.getString("MESSAGE"));	
		}
		catch (Exception e) {
			output.put("RESPONSE", "-1");
			output.put("RESPONSE_MESSAGE", "G�ncelleme s�ras�nda hata meydana geldi(".concat(e.toString()).concat(")"));
		}
		return output;
	}

	@GraymoundService("FTM_GET_NAME_FOR_MAIL_NOTIFICATION")
	public static GMMap ftmGetNameForMailNotification(GMMap input) {
		GMMap output = new GMMap();
		try {
			BigDecimal ftmOid = input.getBigDecimal("FTM_OID");
			Session hibernateSession = CommonHelper.getHibernateSession();
			FtmFileDefinition ftmFileDef = (FtmFileDefinition) hibernateSession.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("oid", ftmOid)).uniqueResult();
			output.put("FTM_NAME", ftmFileDef.getName());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("FTM_GET_NOTIFICATION_TYPES")
	public static GMMap ftmGetNotificationTypes(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			List<FtmNotificationType> ftmNotifType = hibernateSession.createCriteria(FtmNotificationType.class).list();
			int i = 0;
			for (FtmNotificationType ftmNotificationType : ftmNotifType) {
				output.put("NOTIFICATION_TYPE", i, "VALUE", ftmNotificationType.getOid());
				output.put("NOTIFICATION_TYPE", i++, "NAME", ftmNotificationType.getNotificationType());
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("FTM_GET_NOTIFICATION_DEFINITION")
	public static GMMap ftmGetNotificationDefinition(GMMap input) {
		GMMap output = new GMMap();
		try {
			BigDecimal ftmOid = input.getBigDecimal("FTM_OID");
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			
			if (trxNo == null) {
				List<FtmNotification> notification = hibernateSession.createCriteria(FtmNotification.class).add(Restrictions.eq("ftmFileDefinitionOid", ftmOid)).list();
				int i = 0;
				for (FtmNotification ftmNotification : notification) {
					output.put("RESULT_TABLE", i, "CRON", ftmNotification.getCron());
					output.put("RESULT_TABLE", i, "CC", ftmNotification.getMailCc());
					output.put("RESULT_TABLE", i, "TO", ftmNotification.getMailTo());
					output.put("RESULT_TABLE", i, "TITLE", ftmNotification.getName());
					if (ftmNotification.getFtmStateOid() == 0) {
						output.put("RESULT_TABLE", i, "STATUS", "Pasif");
					}
					else {
						output.put("RESULT_TABLE", i, "STATUS", "Aktif");
					}
					output.put("RESULT_TABLE", i, "TYPE", ftmNotification.getFtmNotificationOid());
					i++;
				}
			} else {
				List<FtmNotificationTx> notification = hibernateSession.createCriteria(FtmNotificationTx.class).add(Restrictions.eq("ftmFileDefinitionOid", ftmOid))
													 .add(Restrictions.eq("txNo", trxNo)).list();
				int i = 0;
				for (FtmNotificationTx ftmNotification : notification) {
					output.put("RESULT_TABLE", i, "CRON", ftmNotification.getCron());
					output.put("RESULT_TABLE", i, "CC", ftmNotification.getMailCc());
					output.put("RESULT_TABLE", i, "TO", ftmNotification.getMailTo());
					output.put("RESULT_TABLE", i, "TITLE", ftmNotification.getName());
					if (ftmNotification.getFtmStateOid() == 0) {
						output.put("RESULT_TABLE", i, "STATUS", "Pasif");
					}
					else {
						output.put("RESULT_TABLE", i, "STATUS", "Aktif");
					}
					output.put("RESULT_TABLE", i, "TYPE", ftmNotification.getFtmNotificationOid());
					i++;
				}				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("FTM_GET_CUSTOMER_MAIL_DEFINITION")
	public static GMMap getFtmCustomerMailDefinition(GMMap input) {
		GMMap output = new GMMap();
		try {
			BigDecimal ftmOid = input.getBigDecimal("FTM_OID");
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			
			if (trxNo == null) {
				List<FtmMailProcessDef> processDefList = hibernateSession.createCriteria(FtmMailProcessDef.class).add(Restrictions.eq("ftmFileDefinitionOid", ftmOid)).list();
				int i = 0;
				for (FtmMailProcessDef ftmMailProcessDef : processDefList) {
					output.put("TABLE_DATA", i, "DETAIL", ftmMailProcessDef.getContent());
					output.put("TABLE_DATA", i, "CC", ftmMailProcessDef.getMailCc());
					output.put("TABLE_DATA", i, "TO", ftmMailProcessDef.getMailTo());
					output.put("TABLE_DATA", i, "SUBJECT", ftmMailProcessDef.getSubject());
					if (ftmMailProcessDef.getFtmStateOid() == 1) {
						output.put("TABLE_DATA", i, "STATUS", "Aktif");
					}
					else {
						output.put("TABLE_DATA", i, "STATUS", "Pasif");
					}
					if (ftmMailProcessDef.isAttachFile()) {
						output.put("TABLE_DATA", i, "ATTACHMENT", "Evet");
					}
					else {
						output.put("TABLE_DATA", i, "ATTACHMENT", "Hay�r");
					}
					i++;
				}
			} else {
				List<FtmMailProcessDefTx> processDefList = hibernateSession.createCriteria(FtmMailProcessDefTx.class).add(Restrictions.eq("ftmFileDefinitionOid", ftmOid))
															.add(Restrictions.eq("txNo", trxNo)).list();
				int i = 0;
				for (FtmMailProcessDefTx ftmMailProcessDef : processDefList) {
					output.put("TABLE_DATA", i, "DETAIL", ftmMailProcessDef.getContent());
					output.put("TABLE_DATA", i, "CC", ftmMailProcessDef.getMailCc());
					output.put("TABLE_DATA", i, "TO", ftmMailProcessDef.getMailTo());
					output.put("TABLE_DATA", i, "SUBJECT", ftmMailProcessDef.getSubject());
					if (ftmMailProcessDef.getFtmStateOid() == 1) {
						output.put("TABLE_DATA", i, "STATUS", "Aktif");
					}
					else {
						output.put("TABLE_DATA", i, "STATUS", "Pasif");
					}
					if (ftmMailProcessDef.isAttachFile()) {
						output.put("TABLE_DATA", i, "ATTACHMENT", "Evet");
					}
					else {
						output.put("TABLE_DATA", i, "ATTACHMENT", "Hay�r");
					}
					i++;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("FTM_SAVE_CUSTOMER_MAIL_DEFINITION")
	public static GMMap ftmSaveCustomerMailNotification(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			BigDecimal currentParameterFtmID = input.getBigDecimal("FTM_OID");
			BigDecimal txNo = new BigDecimal(CommonHelper.getNewTransactionNo());
			
			for (int i = 0; i < input.getSize("TABLE_DATA"); i++) {
				FtmMailProcessDefTx mailProcessDefTx = new FtmMailProcessDefTx();
				mailProcessDefTx.setOid(new BigDecimal(-1));
				if (input.getString("TABLE_DATA", i, "ATTACHMENT").equals("Evet")) {
					mailProcessDefTx.setAttachFile(true);
				}
				else {
					mailProcessDefTx.setAttachFile(false);
				}
				mailProcessDefTx.setContent(input.getString("TABLE_DATA", i, "DETAIL"));
				mailProcessDefTx.setFtmFileDefinitionOid(currentParameterFtmID);
				if (input.getString("TABLE_DATA", i, "STATUS").equals("Aktif")) {
					mailProcessDefTx.setFtmStateOid(new Short("1"));
				}
				else {
					mailProcessDefTx.setFtmStateOid(new Short("0"));
				}
				mailProcessDefTx.setMailCc(input.getString("TABLE_DATA", i, "CC"));
				mailProcessDefTx.setMailTo(input.getString("TABLE_DATA", i, "TO"));
				mailProcessDefTx.setSubject(input.getString("TABLE_DATA", i, "SUBJECT"));
				mailProcessDefTx.setStatus(true);
				mailProcessDefTx.setTxNo(txNo);
				session.save(mailProcessDefTx);
			}
			
			FtmTransactionDef ftmTransaction = new FtmTransactionDef();
			ftmTransaction.setTxNo(txNo);
			ftmTransaction.setTxType(DatabaseConstants.FtmTransactionTypes.MAIL_PROCESS_DEF);
			ftmTransaction.setStatus(true);
			ftmTransaction.setRecUser(CommonHelper.getCurrentUser());
			session.save(ftmTransaction);
			
			input.put("TRX_NAME", "7018");
			input.put("TRX_NO", txNo);
			GMMap transactionMap = CommonBusinessOperations.callGraymoundService(input, "BNSPR_TRX_SEND_TRANSACTION", true);
			output.put("MESSAGE", transactionMap.getString("MESSAGE"));	
			
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_FTM_GET_COMPRESS_TYPE")
	public static GMMap cdmFtmGetZipType(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			List<CompressType> compressTypeList = hibernateSession.createCriteria(CompressType.class).list();
			int i = 0;
			for (CompressType compressType : compressTypeList) {
				output.put("COMPRESS_TYPE", i, "VALUE", compressType.getOid());
				output.put("COMPRESS_TYPE", i++, "NAME", compressType.getCompressType());
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_FTM_GET_INSTANCES")
	public static GMMap cdmFtmGetInstances(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			List<FtmInstance> instanceList = hibernateSession.createCriteria(FtmInstance.class).addOrder(Order.asc("oid")).list();
			int i = 0;
			for (FtmInstance instance : instanceList) {
				output.put("INSTANCE_LIST", i, "VALUE", instance.getOid());
				output.put("INSTANCE_LIST", i++, "NAME", instance.getInstanceName());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("CDM_FTM_CONTROL_HOST_KEY")
	public static GMMap cdmFtmControlHostKey(GMMap input) {
		GMMap output = new GMMap();
		try {
			output = CommonHelper.callGraymoundServiceWithExternalConnection("FTM", "BNSPR_FTM_CHECK_FTP_CONNECTION", input);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("CDM_FTM_REMOVE_HOST_KEY")
	public static GMMap cdmFtmRemoveHostKey(GMMap input) {
		GMMap output = new GMMap();
		try {
			output = CommonHelper.callGraymoundServiceWithExternalConnection("FTM", "BNSPR_FTM_REMOVE_HOSTKEY", input);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("FTM_SAVE_XML_FORMAT")
	public static GMMap ftmSaveXmlFormat(GMMap input) {
		GMMap output = new GMMap();
		try {
			boolean isActive = input.getBoolean("IS_ACTIVE");
			BigDecimal ftmOid = input.getBigDecimal("FTM_OID");
			String xmlFormat = input.getString("XML_FORMAT");
			Session hibernateSession = CommonHelper.getHibernateSession();
			FtmFileDefinition ftmFileDef = (FtmFileDefinition) hibernateSession.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("oid", ftmOid)).uniqueResult();
			ftmFileDef.setRedesignFormat(isActive);
			ftmFileDef.setFileFormat(xmlFormat);
			hibernateSession.saveOrUpdate(ftmFileDef);
			hibernateSession.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("FTM_GET_XML_FORMAT")
	public static GMMap ftmGetXmlFormat(GMMap input) {
		GMMap output = new GMMap();
		try {
			BigDecimal ftmOid = input.getBigDecimal("FTM_OID");
			Session hibernateSession = CommonHelper.getHibernateSession();
			FtmFileDefinition ftmFileDef = (FtmFileDefinition) hibernateSession.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("oid", ftmOid)).uniqueResult();
			output.put("IS_ACTIVE", ftmFileDef.isRedesignFormat());
			output.put("XML_FORMAT", ftmFileDef.getFileFormat());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("FTM_MAIL_MANAGEMENT_CHECK_TABLE_DATA")
	public static GMMap checkTableData(GMMap input) {
		GMMap output = new GMMap();
		try {
			String cronStm=input.getString("CRON");
			String cronType=input.getString("TYPE");
			cronStm=cronStm.replace(" ", "");
			if (cronStm.length()<7 && (cronType.equals("4") || cronType.equals("5"))) {
				output.put("RESPONSE", "-2");
				return output;
			}
			output.put("RESPONSE", "0");
			for (int i = 0; i < input.getSize("TABLE_DATA"); i++) {
				if (input.getString("TABLE_DATA", i, "TYPE").equals(input.getString("TYPE"))) {
					output.put("RESPONSE", "-1");
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_TRN7018_AFTER_APPROVAL")
	public static GMMap trn7018AfterApproval(GMMap input) {
		GMMap output = new GMMap();
		final String APPROVE_CANCEL = "OR";
		
		try {
			Session session = CommonHelper.getHibernateSession();
			BigDecimal txNo = input.getBigDecimal("ISLEM_NO");
			String trxType = input.getString("ISLEM_TURU");
			BigDecimal ftmFileDefinitionOid = null;
			BigDecimal fileExecutionTimeOid = null;
			
			FtmTransactionDef transactionDef = (FtmTransactionDef) session.createCriteria(FtmTransactionDef.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", txNo)).uniqueResult();

			if(trxType.equals(APPROVE_CANCEL)) {
				transactionDef.setStatus(false);
				session.update(transactionDef);
				return output;
			}
			
			if (transactionDef.getTxType().equals(DatabaseConstants.FtmTransactionTypes.FTP)) {
				FtmFtpDefinitionTx ftmFtpDefinitionTx = (FtmFtpDefinitionTx) session.createCriteria(FtmFtpDefinitionTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", txNo)).uniqueResult();

				if (transactionDef.getTxOperation().equals(DatabaseConstants.FtmOperationTypes.INSERT)) {
					FtmFtpDefinition ftmFtpDefinition = new FtmFtpDefinition();
					CommonHelper.mapObjects(ftmFtpDefinitionTx, ftmFtpDefinition, CommonHelper.getPojoExceptionalFields());
					ftmFtpDefinition.setOid(new BigDecimal(-1));
					session.save(ftmFtpDefinition);
				} else if (transactionDef.getTxOperation().equals(DatabaseConstants.FtmOperationTypes.UPDATE)) {
					FtmFtpDefinition ftmFtpDefinition = (FtmFtpDefinition) session.createCriteria(FtmFtpDefinition.class).add(Restrictions.eq("oid", ftmFtpDefinitionTx.getOid())).uniqueResult();
					CommonHelper.mapObjects(ftmFtpDefinitionTx, ftmFtpDefinition, CommonHelper.getPojoExceptionalFields());
					session.update(ftmFtpDefinition);
				}
				ftmFtpDefinitionTx.setStatus(false);
				session.update(ftmFtpDefinitionTx);	
				
			} else if (transactionDef.getTxType().equals(DatabaseConstants.FtmTransactionTypes.FILE)) {
				FtmFileDefinitionTx ftmFileDefinitionTx = (FtmFileDefinitionTx) session.createCriteria(FtmFileDefinitionTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", txNo)).uniqueResult();
				
				if (transactionDef.getTxOperation().equals(DatabaseConstants.FtmOperationTypes.INSERT)) {
					
					GMMap insertFileDefinitionMap = new GMMap();
					insertFileDefinitionMap.put("TX_NO", txNo);
					CommonHelper.callGraymoundServiceInHibernateSession("CDM_INSERT_FTM_FILE_DEFINITION", insertFileDefinitionMap);
					
					FtmFileDefinition ftmFileDefinition = (FtmFileDefinition) session.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("txNo", txNo)).uniqueResult();					
					ftmFileDefinitionOid = ftmFileDefinition.getOid();	

					List<FtmFileExecutionTimeTx> fileExecTimeTxList = session.createCriteria(FtmFileExecutionTimeTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("ftmFileDefinitionTxOid", ftmFileDefinitionTx.getTxOid())).list();
					for (FtmFileExecutionTimeTx fileExecTimeTx : fileExecTimeTxList) {

						GMMap insertFileExecTimeMap = new GMMap();
						insertFileExecTimeMap.put("FILE_DEFINITION_OID", ftmFileDefinitionOid);
						insertFileExecTimeMap.put("FILE_EXEC_TIME_TX_OID", fileExecTimeTx.getTxOid());
						CommonHelper.callGraymoundServiceInHibernateSession("CDM_INSERT_FTM_FILE_EXEC_TIME", insertFileExecTimeMap);
						
						FtmFileExecutionTime fileExecTime = (FtmFileExecutionTime) session.createCriteria(FtmFileExecutionTime.class).add(Restrictions.eq("ftmFileDefinitionTypeOid", ftmFileDefinition.getOid())).uniqueResult();					
						fileExecutionTimeOid = fileExecTime.getOid();			
						
						List<FtmFileExecutionScheduleTx> fileExecScheduleTxList = session.createCriteria(FtmFileExecutionScheduleTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("ftmFileExecutionTimeTxOid", fileExecTimeTx.getTxOid())).list();
						
						BigDecimal currentOid = new BigDecimal(-1);
						for (FtmFileExecutionScheduleTx fileExecScheduleTx : fileExecScheduleTxList) {
							GMMap insertFileExecScheduleMap = new GMMap();
							insertFileExecScheduleMap.put("FILE_EXECUTION_TIME_OID", fileExecutionTimeOid);
							insertFileExecScheduleMap.put("FILE_EXEC_SCHEDULE_TX_OID", fileExecScheduleTx.getTxOid());
							insertFileExecScheduleMap.put("CURRENT_OID", currentOid);
							CommonHelper.callGraymoundServiceInHibernateSession("CDM_INSERT_FTM_FILE_EXEC_SCHEDULE", insertFileExecScheduleMap);
							currentOid = currentOid.subtract(new BigDecimal(1));

							fileExecScheduleTx.setStatus(false);
							session.update(fileExecScheduleTx);
						}
						fileExecTimeTx.setStatus(false);
						session.update(fileExecTimeTx);
					}
				} else if (transactionDef.getTxOperation().equals(DatabaseConstants.FtmOperationTypes.UPDATE)) {
					FtmFileDefinition ftmFileDefinition = (FtmFileDefinition) session.createCriteria(FtmFileDefinition.class).add(Restrictions.eq("oid", ftmFileDefinitionTx.getOid())).uniqueResult();
					CommonHelper.mapObjects(ftmFileDefinitionTx, ftmFileDefinition, CommonHelper.getPojoExceptionalFields());
					session.update(ftmFileDefinition);
					
					//delete existing fileExecutionTime and fileExecutionSchedule
					List<FtmFileExecutionTime> fileExecTimeList = session.createCriteria(FtmFileExecutionTime.class).add(Restrictions.eq("ftmFileDefinitionTypeOid", ftmFileDefinitionTx.getOid())).list();
					for (FtmFileExecutionTime fileExecTime : fileExecTimeList) {
						List<FtmFileExecutionSchedule> fileExecScheduleList = session.createCriteria(FtmFileExecutionSchedule.class).add(Restrictions.eq("ftmFileExecutionTimeOid", fileExecTime.getOid())).list();
						for (FtmFileExecutionSchedule fileExecSchedule : fileExecScheduleList) {
							session.delete(fileExecSchedule);
						}
						session.delete(fileExecTime);
					}
					
					List<FtmFileExecutionTimeTx> fileExecTimeTxList = session.createCriteria(FtmFileExecutionTimeTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("ftmFileDefinitionTxOid", ftmFileDefinitionTx.getTxOid())).list();
					for (FtmFileExecutionTimeTx fileExecTimeTx : fileExecTimeTxList) {

						GMMap insertFileExecTimeMap = new GMMap();
						insertFileExecTimeMap.put("FILE_DEFINITION_OID", ftmFileDefinition.getOid());
						insertFileExecTimeMap.put("FILE_EXEC_TIME_TX_OID", fileExecTimeTx.getTxOid());
						CommonHelper.callGraymoundServiceInHibernateSession("CDM_INSERT_FTM_FILE_EXEC_TIME", insertFileExecTimeMap);
						
						FtmFileExecutionTime fileExecTime = (FtmFileExecutionTime) session.createCriteria(FtmFileExecutionTime.class).add(Restrictions.eq("ftmFileDefinitionTypeOid", ftmFileDefinition.getOid())).uniqueResult();					
						fileExecutionTimeOid = fileExecTime.getOid();						
						
						List<FtmFileExecutionScheduleTx> fileExecScheduleTxList = session.createCriteria(FtmFileExecutionScheduleTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("ftmFileExecutionTimeTxOid", fileExecTimeTx.getTxOid())).list();
						
						BigDecimal currentOid = new BigDecimal(-1);
						for (FtmFileExecutionScheduleTx fileExecScheduleTx : fileExecScheduleTxList) {
							GMMap insertFileExecScheduleMap = new GMMap();
							insertFileExecScheduleMap.put("FILE_EXECUTION_TIME_OID", fileExecutionTimeOid);
							insertFileExecScheduleMap.put("FILE_EXEC_SCHEDULE_TX_OID", fileExecScheduleTx.getTxOid());
							insertFileExecScheduleMap.put("CURRENT_OID", currentOid);
							CommonHelper.callGraymoundServiceInHibernateSession("CDM_INSERT_FTM_FILE_EXEC_SCHEDULE", insertFileExecScheduleMap);
							currentOid = currentOid.subtract(new BigDecimal(1));
							
							fileExecScheduleTx.setStatus(false);
							session.update(fileExecScheduleTx);
						}
						fileExecTimeTx.setStatus(false);
						session.update(fileExecTimeTx);
					}
				}
				ftmFileDefinitionTx.setStatus(false);
				session.update(ftmFileDefinitionTx);

			} else if (transactionDef.getTxType().equals(DatabaseConstants.FtmTransactionTypes.FTP_FILE_REL)) {
				
				List<FtmFileDefinitionFtpTx> ftmFileDefFtpTxList = session.createCriteria(FtmFileDefinitionFtpTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", txNo)).list();
				if (transactionDef.getTxOperation().equals(DatabaseConstants.FtmOperationTypes.INSERT)) {
					BigDecimal currentOid = new BigDecimal(-1);
					for (FtmFileDefinitionFtpTx ftmFileDefFtpTx : ftmFileDefFtpTxList) {
						FtmFileDefinitionFtp ftmFileDefFtp = new FtmFileDefinitionFtp();
						CommonHelper.mapObjects(ftmFileDefFtpTx, ftmFileDefFtp, CommonHelper.getPojoExceptionalFields());
						ftmFileDefFtp.setOid(currentOid);
						session.save(ftmFileDefFtp);
						currentOid = currentOid.subtract(new BigDecimal(1));

						ftmFileDefFtpTx.setStatus(false);
						session.update(ftmFileDefFtpTx);
					}
				} else if (transactionDef.getTxOperation().equals(DatabaseConstants.FtmOperationTypes.UPDATE)) {
					BigDecimal currentOid = new BigDecimal(-1);
					for (FtmFileDefinitionFtpTx ftmFileDefFtpTx : ftmFileDefFtpTxList) {
						if (ftmFileDefFtpTx.getOid() != null) {
							FtmFileDefinitionFtp ftmFileDefFtp = (FtmFileDefinitionFtp) session.createCriteria(FtmFileDefinitionFtp.class).add(Restrictions.eq("oid", ftmFileDefFtpTx.getOid())).uniqueResult();
							if (ftmFileDefFtpTx.getFtmFtpDefinitionOid() != null) {
								CommonHelper.mapObjects(ftmFileDefFtpTx, ftmFileDefFtp, CommonHelper.getPojoExceptionalFields());	
								session.update(ftmFileDefFtp);
							} else 
								session.delete(ftmFileDefFtp);
						} else {
							FtmFileDefinitionFtp ftmFileDefFtp = new FtmFileDefinitionFtp();
							CommonHelper.mapObjects(ftmFileDefFtpTx, ftmFileDefFtp, CommonHelper.getPojoExceptionalFields());
							ftmFileDefFtp.setOid(currentOid);
							session.save(ftmFileDefFtp);
							currentOid = currentOid.subtract(new BigDecimal(1));
						}
						
						ftmFileDefFtpTx.setStatus(false);
						session.update(ftmFileDefFtpTx);
					}					
				} else if (transactionDef.getTxOperation().equals(DatabaseConstants.FtmOperationTypes.DELETE)) {
					for (FtmFileDefinitionFtpTx ftmFileDefFtpTx : ftmFileDefFtpTxList) {
						FtmFileDefinitionFtp ftmFileDefFtp = (FtmFileDefinitionFtp) session.createCriteria(FtmFileDefinitionFtp.class).add(Restrictions.eq("oid", ftmFileDefFtpTx.getOid())).uniqueResult();
						session.delete(ftmFileDefFtp);

						ftmFileDefFtpTx.setStatus(false);
						session.update(ftmFileDefFtpTx);
					}
				}
				
			} else if (transactionDef.getTxType().equals(DatabaseConstants.FtmTransactionTypes.REFRESH_FTM)) {
				
				CommonHelper.callGraymoundServiceWithExternalConnection(getFtmInstanceConnectionName(transactionDef.getInstanceOid()), "BNSPR_FTM_REFRESH_CACHES", new GMMap());
				
			} else if (transactionDef.getTxType().equals(DatabaseConstants.FtmTransactionTypes.MAIL_PROCESS_DEF)) {
				List<FtmMailProcessDefTx> processDefTxList = session.createCriteria(FtmMailProcessDefTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", txNo)).list();
				if (processDefTxList != null && processDefTxList.size() > 0) {
					List<FtmMailProcessDef> processDefList = session.createCriteria(FtmMailProcessDef.class).add(Restrictions.eq("ftmFileDefinitionOid", processDefTxList.get(0).getFtmFileDefinitionOid())).list();
					for (FtmMailProcessDef ftmMailProcessDef : processDefList) {
						session.delete(ftmMailProcessDef);
					}
					
					BigDecimal currentOid = new BigDecimal(-1);
					for (FtmMailProcessDefTx processDefTx : processDefTxList) {
						FtmMailProcessDef processDef = new FtmMailProcessDef();
						CommonHelper.mapObjects(processDefTx, processDef, CommonHelper.getPojoExceptionalFields());
						processDef.setOid(currentOid);
						session.save(processDef);
						currentOid = currentOid.subtract(new BigDecimal(1));
						
						processDefTx.setStatus(false);
						session.update(processDefTx);
					}
				}
				
			} else if (transactionDef.getTxType().equals(DatabaseConstants.FtmTransactionTypes.MAIL_NOTIFICATION)) {
				List<FtmNotificationTx> ftmNotificationTxList = session.createCriteria(FtmNotificationTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", txNo)).list();
				if (ftmNotificationTxList != null && ftmNotificationTxList.size() > 0) {
					List<FtmNotification> ftmNotificationList = session.createCriteria(FtmNotification.class).add(Restrictions.eq("ftmFileDefinitionOid", ftmNotificationTxList.get(0).getFtmFileDefinitionOid())).list();
					for (FtmNotification ftmNotification : ftmNotificationList) {
						session.delete(ftmNotification);
					}
					
					BigDecimal currentOid = new BigDecimal(-1);
					for (FtmNotificationTx ftmNotificationTx : ftmNotificationTxList) {
						FtmNotification ftmNotification = new FtmNotification();
						CommonHelper.mapObjects(ftmNotificationTx, ftmNotification, CommonHelper.getPojoExceptionalFields());
						ftmNotification.setOid(currentOid);
						session.save(ftmNotification);
						currentOid = currentOid.subtract(new BigDecimal(1));
						
						ftmNotificationTx.setStatus(false);
						session.update(ftmNotificationTx);
					}
				}
				
			}	
			
			transactionDef.setStatus(false);
			session.update(transactionDef);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("CDM_FTM_GET_APPROVAL_STATUS")
	public static GMMap getCorpApprovalStatus(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			FtmTransactionDef txDef = (FtmTransactionDef) session.createCriteria(FtmTransactionDef.class).add(Restrictions.eq("status", true)).uniqueResult();	
										
			if (txDef != null) 
				output.put("WAITING_APPROVAL", true);
			else 
				output.put("WAITING_APPROVAL", false);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@GraymoundService("CDM_INSERT_FTM_FILE_DEFINITION")
	public static GMMap insertFtmFileDefinition(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			
			FtmFileDefinitionTx ftmFileDefinitionTx = (FtmFileDefinitionTx) session.createCriteria(FtmFileDefinitionTx.class).add(Restrictions.eq("txNo", input.getBigDecimal("TX_NO"))).uniqueResult();
			FtmFileDefinition ftmFileDefinition = new FtmFileDefinition();
			CommonHelper.mapObjects(ftmFileDefinitionTx, ftmFileDefinition, CommonHelper.getPojoExceptionalFields());
			ftmFileDefinition.setOid(new BigDecimal(-1));
			session.save(ftmFileDefinition);

			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("CDM_INSERT_FTM_FILE_EXEC_TIME")
	public static GMMap insertFtmFileExecTime(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			FtmFileExecutionTimeTx fileExecTimeTx = (FtmFileExecutionTimeTx) session.createCriteria(FtmFileExecutionTimeTx.class).add(Restrictions.eq("txOid", input.getString("FILE_EXEC_TIME_TX_OID"))).uniqueResult();
			FtmFileExecutionTime fileExecTime = new FtmFileExecutionTime();
			CommonHelper.mapObjects(fileExecTimeTx, fileExecTime, CommonHelper.getPojoExceptionalFields());
			fileExecTime.setFtmFileDefinitionTypeOid(input.getBigDecimal("FILE_DEFINITION_OID"));
			fileExecTime.setOid(new BigDecimal(-1));
			session.save(fileExecTime);

			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("CDM_INSERT_FTM_FILE_EXEC_SCHEDULE")
	public static GMMap insertFtmFileExecSchedule(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			FtmFileExecutionScheduleTx fileExecScheduleTx = (FtmFileExecutionScheduleTx) session.createCriteria(FtmFileExecutionScheduleTx.class).add(Restrictions.eq("txOid", input.getString("FILE_EXEC_SCHEDULE_TX_OID"))).uniqueResult();
			FtmFileExecutionSchedule fileExecSchedule = new FtmFileExecutionSchedule();
			CommonHelper.mapObjects(fileExecScheduleTx, fileExecSchedule, CommonHelper.getPojoExceptionalFields());
			fileExecSchedule.setFtmFileExecutionTimeOid(input.getBigDecimal("FILE_EXECUTION_TIME_OID"));
			fileExecSchedule.setOid(input.getBigDecimal("CURRENT_OID"));
			session.save(fileExecSchedule);

			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("CDM_FTM_GET_FTM_TRANSACTION_TYPE")
	public static GMMap getFtmTransactionType(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			BigDecimal txNo = input.getBigDecimal("TRX_NO");
			
			FtmTransactionDef txDef = (FtmTransactionDef) session.createCriteria(FtmTransactionDef.class)
									.add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", txNo)).uniqueResult();	
			output.put("FTM_TRANSACTION_TYPE", txDef.getTxType());
			output.put("INSTANCE_OID", txDef.getInstanceOid());
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	

}