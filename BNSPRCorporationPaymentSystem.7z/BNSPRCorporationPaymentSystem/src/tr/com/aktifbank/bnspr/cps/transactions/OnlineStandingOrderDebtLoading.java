
package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.OnlineStandingOrderDebtLoadingRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.cps.dto.OnlineStandingOrderDebtLoadingStarterInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.implementations.OnlineStandingOrderDebtLoadingImplementation;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CollectionTypePrm;
import tr.com.aktifbank.bnspr.dao.icsOnlineDebtLoadingLog;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class OnlineStandingOrderDebtLoading extends RequestHandler {

    @Override
    protected void handleInternal(GMMap input, GMMap output) throws Throwable {
    	
    	long startMilis = System.currentTimeMillis();
    	
    	Map<String,String> corporateCodes = new HashMap<String, String>();
    	String processDate = "";
    	
    	String tableNameCorporates = "BATCH_CORPORATES";
    	String query=OnlineStandingOrderDebtLoadingRepository.GET_STD_ORD_CORPORATES_QUERY;
    	if (input.containsKey(MapKeys.CORPORATE_CODE)) {
    		query=String.format(query+OnlineStandingOrderDebtLoadingRepository.GET_STD_ORD_CORPORATE_CODE_QUERY, input.getString(MapKeys.CORPORATE_CODE));
    	}
		GMMap batchCorporateList = DALUtil.getResults(query, tableNameCorporates);
	
		OnlineStandingOrderDebtLoadingStarterInformation information = new OnlineStandingOrderDebtLoadingStarterInformation();
		
		if (input.containsKey("PROCESS_DATE")) {
			information.getCorporateMap().put("PROCESS_DATE", input.getString("PROCESS_DATE"));
			processDate = input.getString("PROCESS_DATE");
		}else {
			information.getCorporateMap().put("PROCESS_DATE",CommonHelper.getShortDateTimeString(new Date()));
			processDate = CommonHelper.getShortDateTimeString(new Date());
		}
		
		information.setServiceName("ICS_ONLINE_STANDING_ORDER_DEBT_LOADING");
		information.setMaxParallelThreadCount(Integer.valueOf(CommonHelper.getValueOfParameter("CDM_PARALLEL_THREAD_COUNT_DEF", "ONLINE_STD_ORDER_LOAD"))); //paramtext den al�nabilir
		information.setProcessDate(new Date());
		information.setMasterSubmitId(new BigDecimal(CorporationServiceUtil.getSequenceCode("ICS_ONL_STD_ORD_DEBT_LOAD_ID")));
		
		for (int i = 0; i < batchCorporateList.getSize(tableNameCorporates); i++) {
			corporateCodes.put(batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_CODE), batchCorporateList.getString(tableNameCorporates, i, MapKeys.SHORT_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_BATCH_PROCESS_OID, batchCorporateList.getString(tableNameCorporates, i, MapKeys.BATCH_PROCESS_OID) );
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.BANK_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_BANK_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.BATCH_NAME, batchCorporateList.getString(tableNameCorporates, i, MapKeys.BATCH_NAME));
		}
		
		OnlineStandingOrderDebtLoadingImplementation implementation = new OnlineStandingOrderDebtLoadingImplementation(information);
		implementation.execute();
		
		long endMilis = System.currentTimeMillis();
		
		GMMap sendReportRequest = new GMMap();
        sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.BATCH_NAME, DatabaseConstants.BatchNames.OnlineStandingOrderDebtLoading);
        sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.PROCESS_DATE, new Date());
        sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.DURATION, endMilis - startMilis);
        sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_TO, CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_STD_ORDER_LOAD_REPORT"));
        
        GMServiceExecuter.executeAsync(TransactionConstants.BatchFileReporter.SERVICE_NAME, sendReportRequest);
        
        sendEmailNotificationForStandingOrderLog(corporateCodes, processDate, information.getMasterSubmitId());
		
    }

	@SuppressWarnings("unchecked")
	private void sendEmailNotificationForStandingOrderLog(Map<String, String> corporateCodes, String processDate, BigDecimal masterSubmitId) {
		try{
			List<icsOnlineDebtLoadingLog> logs = super.getHibernateSession().createCriteria(icsOnlineDebtLoadingLog.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("masterSubmitId", masterSubmitId))
					.addOrder(Order.asc("corporateCode"))
					.list();
			
			if(logs.size() > 0){
				List<Map<String,String>> detailMapList = new ArrayList<Map<String,String>>();
				
				List<CollectionTypePrm> collectionTypes = super.getHibernateSession().createCriteria(CollectionTypePrm.class).list();
				
				Map<Short, String> collectionTypeMapping = new HashMap<Short, String>();
				
				for (CollectionTypePrm prm : collectionTypes) {
					collectionTypeMapping.put(prm.getCollectionType(), prm.getCollectionName());
				}
				
				for (icsOnlineDebtLoadingLog log : logs) {
					Map<String, String> logMap = new HashMap<String, String>();
					logMap.put("ROW_CORPORATE_NAME", corporateCodes.get(log.getCorporateCode()));
					logMap.put("ROW_CORPORATE_CODE", log.getCorporateCode());
					logMap.put("ROW_COL_TYPE", collectionTypeMapping.get(log.getCollectionType()));
					logMap.put("ROW_SUB_NO1", log.getSubscriberNo1());
					logMap.put("ROW_SUB_NO2", log.getSubscriberNo2());
					logMap.put("ROW_SUB_NO3", log.getSubscriberNo3());
					logMap.put("ROW_SUB_NO4", log.getSubscriberNo4());
					logMap.put("ROW_DUE_DATE", CommonHelper.formatDateString(log.getInvoiceDueDate(), "yyyyMMdd", "dd/MM/yyyy"));
					logMap.put("ROW_INV_AMOUNT", CommonHelper.applyDecimalFormat(log.getInvoiceAmount().toPlainString()));
					logMap.put("ROW_ERR_CODE", log.getErrorCode());
					logMap.put("ROW_ERR_MESSAGE", log.getErrorDesc());
					
					detailMapList.add(logMap);
				}
				
				String receiptList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST","EMAIL_RECEIPT_LIST_4_STD_ORDER_LOAD");
				
				GMMap messageMap = new GMMap();
				messageMap.put("MAP_TABLE", detailMapList);
				
				GMMap subjectMap = new GMMap();
				subjectMap.put("PROCESS_DATE",CommonHelper.formatDateString(processDate, "yyyyMMdd", "dd/MM/yyyy"));
				
				EmailMessage emailMessage = CommonHelper.prepareEmailBody("", messageMap,NotificationMessageConstant.Email.OnlineStandingOrderDebtLoadingMessageConstant.MESSAGE_BODY,
						CommonHelper.generateSubject(NotificationMessageConstant.Email.OnlineStandingOrderDebtLoadingMessageConstant.SUBJECT,subjectMap),receiptList);
				
				CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
			}
		}
		catch(Exception e){
			logger.error("An exception occured while sending email notification for standing order loading logs");
			logger.error(System.currentTimeMillis(), e);
		}
	}
}


