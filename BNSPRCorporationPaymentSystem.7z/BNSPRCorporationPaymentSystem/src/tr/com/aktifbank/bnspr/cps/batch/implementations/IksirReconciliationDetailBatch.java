package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.iksir.IksirClient;
import tr.com.aktifbank.integration.iksir.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.iksir.LoginResponse;
import tr.com.iksir.Reconciliation;
import tr.com.iksir.ReconciliationDetailResponse;

import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;

public class IksirReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final String SUCCESS_CODE="2";
	private static final String CANCEL="2";


	private static final Log logger = LogFactory.getLog(IksirReconciliationDetailBatch.class);
	Session session;
	List<Reconciliation> details= new ArrayList<Reconciliation>();
	ServiceMessage message;
	Map<String, Reconciliation> indexedCorporateRecords;

	public IksirReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, Reconciliation>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getSERVICE_PROVIDER_REFERENCE_NUMBER());
		cancelCollectionRequest.put(MapKeys.INVOICE_AMOUNT, details.get(corporateRecordIndex).getPAYMENT_AMOUNT());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			String productOid = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String iksirChannel = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String dealerCode = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);
			String agentCode = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			String reconDate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			if (!StringUtil.isEmpty(input.getString(MapKeys.RECON_DATE))) {
				reconDate= CommonHelper.getDateString(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			} else {
				reconDate = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
			}
			tr.com.aktifbank.integration.iksir.ServiceMessage serviceMessageLogin = new tr.com.aktifbank.integration.iksir.ServiceMessage();
			LoginResponse  loginResponse = IksirClient.login(serviceUrl, serviceMessageLogin, iksirChannel, dealerCode, username, password);
	
			
			if(SUCCESS_CODE.equals(loginResponse.getResult().getRESPONSE_CODE())){

	
				String cANCEL_DESCRIPTION = input.getString("REJECTED_REASON");
				String agentUser = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
				String cLIENT_TRX_ID_RESERVED = loginResponse.getResult().getCORE_TRX_ID_RESERVED();
				String clientSessionId = loginResponse.getResult().getSessionId();
				String sessionId = loginResponse.getResult().getSessionId();

				ReconciliationDetailResponse response = IksirClient.reconciliationDeatil(serviceUrl, this.message, sessionId, agentCode, agentUser, iksirChannel, clientSessionId, cLIENT_TRX_ID_RESERVED, dealerCode, productOid, reconDate);
				List<Reconciliation> paymentList = new ArrayList<Reconciliation>();
				List<Reconciliation> cancelList = response.getResult().getCANCEL_LIST();

				if (SUCCESS_CODE.equals(response.getResult().getRESPONSE_CODE())) {
					paymentList = response.getResult().getPAYMENT_LIST();
					cancelList = response.getResult().getCANCEL_LIST();
					details = paymentList;
				}
			
			}
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	
	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getSERVICE_PROVIDER_REFERENCE_NUMBER());
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getINVOICE_NUMBER());
		collectionDetailRequest.put(MapKeys.INVOICE_AMOUNT, details.get(corporateRecordIndex).getPAYMENT_AMOUNT());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.PARAMETER2));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.PARAMETER2), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getSERVICE_PROVIDER_REFERENCE_NUMBER(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getSERVICE_PROVIDER_REFERENCE_NUMBER());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		Reconciliation corporateDetail = details.get(corporateRecordIndex);
		String aboneNo = corporateDetail.getSUBSCRIBER_NO1();

				
//		logger.info(String.format("Following corporate record has not been found in database. Tahakkuk ID : %s, Referans No : %s, Miktar : %s ", 
//				corporateDetail.getINVOICE_NUMBER()), 
//				corporateDetail.getSERVICE_PROVIDER_REFERENCE_NUMBER(), 
//				corporateDetail.getPAYMENT_AMOUNT());
		
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(corporateDetail.getSUBSCRIBER_NO1());
		payment.setSubscriberNo2(corporateDetail.getSUBSCRIBER_NO2());
		payment.setSubscriberNo3(corporateDetail.getSUBSCRIBER_NO3());
		payment.setInvoiceNo("1");
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getPAYMENT_AMOUNT()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getPAYMENT_AMOUNT()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setParameter2(corporateDetail.getSERVICE_PROVIDER_REFERENCE_NUMBER());
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getSUBSCRIBER_NO1());
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO2, corporateDetail.getSUBSCRIBER_NO2());
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO3, corporateDetail.getSUBSCRIBER_NO3());

		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getINVOICE_NUMBER());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getPAYMENT_AMOUNT());
	}
	



}
