package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.List;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.FormatDetail;

import com.graymound.util.GMMap;

public final class GetFileFooterFormatHandler extends RequestHandler {

	public GetFileFooterFormatHandler() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String formatId = input.getString(TransactionConstants.GetFileFooterFormat.Input.FORMAT_ID);
		List<FormatDetail> details = CommonBusinessOperations.getFormatDetails(DatabaseConstants.LineType.Footer, formatId, super.getHibernateSession());
		output.put(TransactionConstants.GetFileFooterFormat.Output.FOOTER_FORMATS, details);
	}

}
