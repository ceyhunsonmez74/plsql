package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentSkipListSet;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.SingleInstanceMemory;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.StandingOrderMain;
import tr.com.aktifbank.bnspr.dao.icsOnlineDebtLoadingLog;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class InsertInvoiceWithStandingOrderHandler extends RequestHandler {

	private static final String COLLECTION_TYPE_COLUMN = "COLLECTION_TYPE";
	private static final String AMOUNT_COLUMN = "AMOUNT";
	private static final String SUBSCRIBER_NO1_COLUMN = "SUBSCRIBER_NO1";
	private static final String SUBSCRIBER_NO2_COLUMN = "SUBSCRIBER_NO2";
	private static final String SUBSCRIBER_NO3_COLUMN = "SUBSCRIBER_NO3";
	private static final String SUBSCRIBER_NO4_COLUMN = "SUBSCRIBER_NO4";
	private static final String INVOICE_NO_COLUMN = "INVOICE_NO";
	private static final String INVOICE_DUE_DATE_COLUMN = "INVOICE_DUE_DATE";

	private static String ERROR_CODE_STANDING_ORDER_NOT_ACTIVE = "1";
	private static String ERROR_DESC_STANDING_ORDER_NOT_ACTIVE = "Aktif Talimat� bulunamad�";
	private static String ERROR_CODE_INVOICE_EXISTS = "2";
	private static String ERROR_DESC_INVOICE_EXISTS = "Fatura veritaban�nda bulunuyor.";

	private static final class BagKeys {
		public static final Short OPENED_CONNECTION = 1;
		public static final Short OPENED_STATEMENT = 2;
	}

	public InsertInvoiceWithStandingOrderHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String step = "";
		String subMessage = "";
		Date currentDate = new Date();
		try {
			if (input.containsKey(TransactionConstants.InsertStandingOrderInvoice.Input.DIRECT_INSERT) && input.getBoolean(TransactionConstants.InsertStandingOrderInvoice.Input.DIRECT_INSERT)) {

				Connection connection = null;
				Statement statement = null;

				int notLoadedCount = 0;
				BigDecimal notLoadedAmount = BigDecimal.ZERO;

				connection = CommonHelper.getConnection();
				super.bag.put(BagKeys.OPENED_CONNECTION, connection);
				statement = connection.createStatement();
				super.bag.put(BagKeys.OPENED_STATEMENT, statement);

				String submitId = input.getString(TransactionConstants.InsertStandingOrderInvoice.Input.SUBMIT_ID);
				boolean loadOnlyWithStandingOrder = input.getBoolean(TransactionConstants.InsertStandingOrderInvoice.Input.LOAD_ONLY_WITH_STANDING_ORDER);
				boolean controlInvoiceNo = input.getBoolean(TransactionConstants.InsertStandingOrderInvoice.Input.CONTROL_INVOICE_NO);
				boolean controlInvoiceDueDate = input.getBoolean(TransactionConstants.InsertStandingOrderInvoice.Input.CONTROL_INVOICE_DUE_DATE);

				ConcurrentSkipListSet<String> indicatorList = (ConcurrentSkipListSet<String>) SingleInstanceMemory.getInstance().getCacheObject(submitId);
				step = "Started";
				for (int i = 0; i < input.getSize(TransactionConstants.InsertStandingOrderInvoice.Input.INSERT_PAIR_TABLE); i++) {
					GMMap directInsertMap = (GMMap) input.get(TransactionConstants.InsertStandingOrderInvoice.Input.INSERT_PAIR_TABLE, i, TransactionConstants.InsertStandingOrderInvoice.Input.INSERT_KEYVALUE_PAIRS);
					subMessage = directInsertMap.toString();

					String corporateCode = input.getString(TransactionConstants.InsertStandingOrderInvoice.Input.CORPORATE_CODE);
					String subscriberNo1 = directInsertMap.getString(SUBSCRIBER_NO1_COLUMN);
					String subscriberNo2 = directInsertMap.getString(SUBSCRIBER_NO2_COLUMN, null);
					String subscriberNo3 = directInsertMap.getString(SUBSCRIBER_NO3_COLUMN, null);
					String subscriberNo4 = directInsertMap.getString(SUBSCRIBER_NO4_COLUMN, null);

					List<String> result = getStandingOrderOid(corporateCode, subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4);

					String standingOrderOid = "";

					if (result.size() == 1) {
						standingOrderOid = result.get(0);
					}
					else if (result.size() == 2) {
						standingOrderOid = result.get(0);
						subscriberNo1 = result.get(1);
						directInsertMap.put("SUBSCRIBER_NO1", result.get(1));
					}

					String customerNo = "";
					if (!StringUtil.isEmpty(standingOrderOid)) {
						customerNo = getCustomerNoFromStandingOrderOid(standingOrderOid);
					}


					if (loadOnlyWithStandingOrder) {
						if (StringUtil.isEmpty(standingOrderOid)) {
							insertOnlineDebtLoadingLog(submitId, Short.valueOf(directInsertMap.getString(COLLECTION_TYPE_COLUMN, "0")), corporateCode, ERROR_CODE_STANDING_ORDER_NOT_ACTIVE, ERROR_DESC_STANDING_ORDER_NOT_ACTIVE, directInsertMap.getBigDecimal(AMOUNT_COLUMN), directInsertMap.getString(INVOICE_NO_COLUMN, null), directInsertMap.getString(INVOICE_DUE_DATE_COLUMN, null), CommonHelper.getLongDateTimeString(currentDate), subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4);
							logger.info(String.format("Standing order not found for map %s", directInsertMap.toString()));
							notLoadedCount++;
							notLoadedAmount = notLoadedAmount.add(directInsertMap.getBigDecimal("AMOUNT"));
							continue;
						}
					}

					String indicator = "";

					if (controlInvoiceNo) {
						if (directInsertMap.containsKey("INVOICE_NO")) {
							indicator = indicator.concat(directInsertMap.getString("INVOICE_NO"));
						}
						else {
							throw new Exception("Fatura kay�t bilgilerinde fatura numaras� bulunamad�. E�er kurumun dosyas�nda fatura numaras� bilgisi bulunmuyorsa l�tfen " + "Batch Y�netim Ekran�nda FATURA_NO_KONTROL_ET parametresini HAYIR olarak ekleyiniz.");
						}
					}

					if (controlInvoiceDueDate) {
						if (directInsertMap.containsKey("INVOICE_DUE_DATE")) {
							indicator = indicator.concat(directInsertMap.getString("INVOICE_DUE_DATE"));
						}
						else {
							throw new Exception("Fatura kay�t bilgilerinde son �deme tarihi bulunamad�. E�er kurumun dosyas�nda son �deme tarihi bilgisi bulunmuyorsa l�tfen " + "Batch Y�netim Ekran�nda SON_ODEME_TARIHI_KONTROL_ET parametresini HAYIR olarak ekleyiniz.");
						}
					}
					indicator = indicator.concat(directInsertMap.getString("AMOUNT"));
					indicator = indicator.concat(subscriberNo1);

					if (!StringUtil.isEmpty(subscriberNo2)) {
						indicator = indicator.concat(subscriberNo2);
					}

					if (!StringUtil.isEmpty(subscriberNo3)) {
						indicator = indicator.concat(subscriberNo3);
					}

					if (!StringUtil.isEmpty(subscriberNo4)) {
						indicator = indicator.concat(subscriberNo4);
					}

					if (indicatorList.contains(indicator)) {
						insertOnlineDebtLoadingLog(submitId, Short.valueOf(directInsertMap.getString(COLLECTION_TYPE_COLUMN, "0")), corporateCode, ERROR_CODE_INVOICE_EXISTS, ERROR_DESC_INVOICE_EXISTS, directInsertMap.getBigDecimal(AMOUNT_COLUMN), directInsertMap.getString(INVOICE_NO_COLUMN, null), directInsertMap.getString(INVOICE_DUE_DATE_COLUMN, null), CommonHelper.getLongDateTimeString(currentDate), subscriberNo1, subscriberNo2, subscriberNo3, subscriberNo4);
						logger.info(String.format("Invoice with %s map exists on database", directInsertMap.toString()));
						notLoadedCount++;
						notLoadedAmount = notLoadedAmount.add(directInsertMap.getBigDecimal("AMOUNT"));
						continue;
					}

					StringBuilder columnNameBuilder = new StringBuilder();
					StringBuilder valueBuilder = new StringBuilder();
					boolean collectionTypeExists = false;
					for (Object key : directInsertMap.keySet()) {
						if (((String) key).equals(COLLECTION_TYPE_COLUMN)) {
							collectionTypeExists = true;
						}
						columnNameBuilder.append(String.format("%s,", key));
						Object value = directInsertMap.get(key);
						if (value instanceof String) {
							valueBuilder.append(String.format("'%s',", value));
						}
						else if (value instanceof Date) {
							valueBuilder.append(String.format("'%s',", CommonHelper.getShortDateTimeString((Date) value)));
						}
						else {
							valueBuilder.append(String.format("%s,", value));
						}
					}
					String query = String.format("INSERT INTO ICS.INVOICE_MAIN(OID, CUSTOMER_NO, CORPORATE_CODE,%s,STATUS,PAYMENT_METHOD,LOADING_DATE,LOADING_USER,FTM_SEQUENCE_NUMBER," + "PAYMENT_STATUS,INVOICE_STATUS,PAYMENT_AMOUNT,STANDING_ORDER_OID%s) VALUES('%s','%s','%s' ,%s ,0 ,'S','%s','%s',%s,'%s','%s',0,'%s'%s)", 
							CommonHelper.trimEnd(columnNameBuilder.toString(), ','), collectionTypeExists ? "" : String.format(",%s", COLLECTION_TYPE_COLUMN), 
									UUID.randomUUID().toString().substring(0, 32), 
									customerNo, 
									corporateCode, 
									CommonHelper.trimEnd(valueBuilder.toString(), ','), 
									CommonHelper.getLongDateTimeString(new Date()), 
									CommonHelper.getCurrentUser(), 
									input.getBigDecimal(TransactionConstants.InsertStandingOrderInvoice.Input.FTM_TRANSFER_ID), 
									DatabaseConstants.PaymentStatuses.Waiting, 
									DatabaseConstants.InvoiceStatuses.Active, 
									standingOrderOid, 
									collectionTypeExists ? "" : String.format(",%s", DatabaseConstants.CollectionTypes.InvoiceLoad));
					// logger.info(query);
					statement.addBatch(query);
				}
				step = "Executing batch";
				statement.executeBatch();

				output.put(TransactionConstants.InsertStandingOrderInvoice.Output.RETURN_CODE, 0);
				output.put("NOT_INSERTED_COUNT", notLoadedCount);
				output.put("NOT_INSERTED_AMOUNT", notLoadedAmount);
			}
			else {
				throw new BatchComponentException("No implementation found other than direct insert at inser invoice handler", BusinessException.SYSTEM);
			}
		}
		catch (Exception e) {
			logger.error(String.format("An exception occured while inserting invoices with subMessage : %s, step : %s .", subMessage, step));
			logger.error(System.currentTimeMillis(), e);
			output.put(TransactionConstants.InsertStandingOrderInvoice.Output.RETURN_CODE, 1);
			output.put(TransactionConstants.InsertStandingOrderInvoice.Output.RETURN_MESSAGE, "Talimatlu fatura kay�tlar� veritaban�na eklenirken bir hata olu�tu : " + e.toString());
		}
	}

	public void insertOnlineDebtLoadingLog(String submitId, short collectionType, String corporateCode, String errorCode, String errorDesc, BigDecimal invoiceAmount, String invoiceNo, String invoiceDueDate, String processDate, String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4) {
		Session hibernateSession = CommonHelper.getHibernateSession();
		icsOnlineDebtLoadingLog debtLoadingLog = new icsOnlineDebtLoadingLog();
		debtLoadingLog.setBatchSubmitId(submitId);
		debtLoadingLog.setCollectionType(collectionType);
		debtLoadingLog.setCorporateCode(corporateCode);
		debtLoadingLog.setErrorCode(errorCode);
		debtLoadingLog.setErrorDesc(errorDesc);
		debtLoadingLog.setInvoiceAmount(invoiceAmount);
		debtLoadingLog.setInvoiceDueDate(invoiceDueDate);
		debtLoadingLog.setInvoiceNo(invoiceNo);
		debtLoadingLog.setProcessDate(processDate);
		debtLoadingLog.setStatus(true);
		debtLoadingLog.setSubscriberNo1(subscriberNo1);
		debtLoadingLog.setSubscriberNo2(subscriberNo2);
		debtLoadingLog.setSubscriberNo3(subscriberNo3);
		debtLoadingLog.setSubscriberNo4(subscriberNo4);
		hibernateSession.save(debtLoadingLog);
		hibernateSession.flush();
	}

	private List<String> getStandingOrderOid(String corporateCode, String subscriberNo1, String subscriberNo2, String subscriberNo3, String subscriberNo4) {
		StringBuilder query = new StringBuilder();

		query.append("SELECT som.OID FROM sto.STANDING_ORDER_MAIN som INNER JOIN ics.ICS_STANDING_ORDERS iso ON som.OID = iso.STANDING_ORDER_OID ");
		query.append("WHERE som.STATUS = 1 AND iso.STATUS = 1 AND ");
		query.append(String.format("som.STANDING_ORDER_STATUS='%s' AND iso.STANDING_ORDER_STATUS='%s' AND ", DatabaseConstants.StandingOrderStatus.Active, DatabaseConstants.StandingOrderStatus.Active));
		query.append(String.format("iso.CORPORATE_CODE = '%s' AND iso.SUBSCRIBER_NO1 = '%s'", corporateCode, subscriberNo1));
		if (!StringUtil.isEmpty(subscriberNo2)) {
			query.append(String.format(" AND iso.SUBSCRIBER_NO2 = '%s'", subscriberNo2));
		}

		if (!StringUtil.isEmpty(subscriberNo3)) {
			query.append(String.format(" AND iso.SUBSCRIBER_NO3 = '%s'", subscriberNo3));
		}

		if (!StringUtil.isEmpty(subscriberNo4)) {
			query.append(String.format(" AND iso.SUBSCRIBER_NO4 = '%s'", subscriberNo4));
		}

		String oid = DALUtil.getResult(query.toString());

		if (StringUtil.isEmpty(oid) && !StringUtil.isEmpty(subscriberNo4)) {
			// This part is written for Turk Telekom Standing Order Debt Inquiry
			query = new StringBuilder();
			query.append("SELECT som.OID, iso.SUBSCRIBER_NO1 FROM sto.STANDING_ORDER_MAIN som INNER JOIN ics.ICS_STANDING_ORDERS iso ON som.OID = iso.STANDING_ORDER_OID ");
			query.append("WHERE som.STATUS = 1 AND iso.STATUS = 1 AND ");
			query.append(String.format("som.STANDING_ORDER_STATUS='%s' AND iso.STANDING_ORDER_STATUS='%s' AND ", DatabaseConstants.StandingOrderStatus.Active, DatabaseConstants.StandingOrderStatus.Active));
			query.append(String.format("iso.CORPORATE_CODE = '%s' AND iso.SUBSCRIBER_NO4 = '%s'", corporateCode, subscriberNo4));

			GMMap resultList = DALUtil.getResults(query.toString(), "TEMP_TABLE");
			if (resultList.getSize("TEMP_TABLE") != 0) {
				return Arrays.asList(resultList.getString("TEMP_TABLE", 0, "OID"), resultList.getString("TEMP_TABLE", 0, "SUBSCRIBER_NO1"));
			}
			else {
				return new ArrayList<String>();
			}
		}
		else {
			return Arrays.asList(oid);
		}
	}

	private String getCustomerNoFromStandingOrderOid(String oid) {
		 Session session = CommonHelper.getHibernateSession();
		 Criteria criteria = session.createCriteria(StandingOrderMain.class).add(Restrictions.eq("oid", oid));
		 StandingOrderMain stoMain = (StandingOrderMain) criteria.uniqueResult();
		 String customerNo = stoMain.getCustomerNo().toString();

		if (StringUtil.isEmpty(customerNo))
			customerNo = "";

		return customerNo;
	}

	@Override
	protected void handleFinally(GMMap output) {
		try {
			CommonHelper.closeAll(super.bag.get(BagKeys.OPENED_STATEMENT), super.bag.get(BagKeys.OPENED_CONNECTION));
		}
		catch (Exception e) {
			logger.error("An exception occured while closing statement and connection");
			logger.error(System.currentTimeMillis(), e);
		}
	}

}
