package tr.com.aktifbank.bnspr.cps.session;

public final class SessionHolderKeys {
	public static final String TURKCELL_SESSION_HOLDER = "TURKCELL_SESSION_HOLDER";
}
