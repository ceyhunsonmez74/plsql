package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.tempuri.Borc;
import org.tempuri.TahsilatIslemi;
import org.tempuri.TahsilatListeTipleri;
import org.tempuri.TahsilatListeleSonucu;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.deski.DeskiClient;
import tr.com.aktifbank.integration.deski.ServiceMessage;

import com.graymound.util.GMMap;


public final class DeskiReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	class BorcExtended{
		public Borc borc;
		public String bankaReferans;
		public String belediyeReferans;
		public Calendar bankaTahsilatTarihi;
	}
	
	private static final Log logger = LogFactory.getLog(DeskiReconciliationDetailBatch.class);
	Session session;
	List<BorcExtended> details = new ArrayList<DeskiReconciliationDetailBatch.BorcExtended>();
	ServiceMessage message;
	Map<String, BorcExtended> indexedCorporateRecords;
	
	public DeskiReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, BorcExtended>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER9, details.get(corporateRecordIndex).bankaReferans);
		cancelCollectionRequest.put(MapKeys.PARAMETER10, details.get(corporateRecordIndex).belediyeReferans);
		cancelCollectionRequest.put(MapKeys.PAYMENT_DATE, CommonHelper.getShortDateTimeString(details.get(corporateRecordIndex).bankaTahsilatTarihi.getTime()));
		cancelCollectionRequest.put(MapKeys.PARAMETER11, CommonHelper.getShortDateTimeString(details.get(corporateRecordIndex).bankaTahsilatTarihi.getTime()));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String webIp = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String bankaKodu = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String subeKodu = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER3);

			Calendar reconDate = CommonHelper.getCalendarWithYYYYMMDD(input.getString(MapKeys.RECON_DATE)); 
			TahsilatListeleSonucu response = DeskiClient.tahsilatListeleV2(url, username, password, webIp, bankaKodu, subeKodu, TahsilatListeTipleri.Tamamlananlar, true, "TahsilatKaydet", null, reconDate, this.message);
			
			for(TahsilatIslemi  tahsilat: response.getTahsilatIslemleri()){
				if(!tahsilat.isIptalMi()){
					for(Borc b : tahsilat.getBorclar()){
						BorcExtended be = new BorcExtended();
						be.bankaReferans = tahsilat.getBankaReferans();
						be.belediyeReferans = tahsilat.getBelediyeReferans();
						be.bankaTahsilatTarihi = tahsilat.getBankaTahsilatTarihi();
						be.borc = b;						
						details.add(be);
					}
				}
			}			
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex));
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).borc.getTahakNo(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).borc.getTahakNo());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		BorcExtended corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Abone Numaras� : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.borc.getAboneNo(), 
				corporateDetail.borc.getTahakNo(), 
				corporateDetail.borc.getToplam()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(String.valueOf(corporateDetail.borc.getAboneNo()));
		payment.setInvoiceNo(corporateDetail.borc.getTahakNo());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setParameter1(String.valueOf(corporateDetail.borc.getSicilNo()));
		payment.setParameter2(String.valueOf(corporateDetail.borc.getGelirKoduId()));
		payment.setParameter3(String.valueOf(corporateDetail.borc.getPaketId()));
		payment.setParameter4(String.valueOf(corporateDetail.borc.getBakiye()));
		payment.setParameter5(String.valueOf(corporateDetail.borc.getZam()));
		payment.setParameter6(String.valueOf(corporateDetail.borc.getIhbarNo()));
		payment.setParameter7(CommonHelper.getShortDateTimeString(corporateDetail.borc.getTahakkukTarihi().getTime()));
		payment.setParameter8(CommonHelper.getShortDateTimeString(corporateDetail.borc.getSonOdemeTarihi().getTime()));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.borc.getToplam()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.borc.getToplam()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.borc.getAboneNo());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.borc.getTahakNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.borc.getToplam());
	}

}
