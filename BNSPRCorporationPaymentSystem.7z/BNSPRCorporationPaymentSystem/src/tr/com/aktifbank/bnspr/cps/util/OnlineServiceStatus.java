package tr.com.aktifbank.bnspr.cps.util;

public interface OnlineServiceStatus {
	
	public static String SAF_SUCCESFUL = "99";
	public static String SAF_FAILED = "88";
	public static String SAF_WAITED = "10";

}
