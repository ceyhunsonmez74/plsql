package tr.com.aktifbank.bnspr.cps.transactions;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.TransferTypes;

import com.graymound.util.GMMap;

public final class InformStandingOrdersStarterHandler extends RequestHandler {

	public InformStandingOrdersStarterHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		CommonBusinessOperations.executeBatchStarterHandler(input, output, TransferTypes.StandingOrderInform, super.getHibernateSession());
	}

}
