package tr.com.aktifbank.bnspr.cps.multithreading.implementations;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.StandingOrderInvoiceCollectionStarterHandlerInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.PartialParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ServiceBasedMultiThreading;

import com.graymound.util.GMMap;

public class StandingOrderInvoiceCollectionStarterImplementation  extends ServiceBasedMultiThreading {
	private StandingOrderInvoiceCollectionStarterHandlerInformation information;
	
    public StandingOrderInvoiceCollectionStarterImplementation(StandingOrderInvoiceCollectionStarterHandlerInformation p_information){
    	super();
    	this.information = p_information;
    }
    
    @Override
    protected void prepareCall() throws Throwable {
       
       int s = information.getCorporateMap().getSize(MapKeys.CORPORATE_LIST);
       String dateParam = information.getCorporateMap().getString(MapKeys.PROCESS_DATE);
       
      
       
       for (int i = 0; i < s; i++) {
		   GMMap input = new GMMap();
		   input.put(MapKeys.CORPORATE_BATCH_PROCESS_OID, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST,i,MapKeys.CORPORATE_BATCH_PROCESS_OID));
		   
		   input = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GET_CORPORATE_BATCH_PARAMETERS",input);
		   
		   input.put(MapKeys.PROCESS_DATE, dateParam);
		   input.put(MapKeys.CORPORATE_CODE, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST,i,MapKeys.CORPORATE_CODE));
		   input.put(MapKeys.BANK_CODE, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.BANK_CODE));
		   input.put(MapKeys.BATCH_NAME, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.BATCH_NAME));  	 
		   input.put(MapKeys.CORPORATE_ACTIVENESS,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_ACTIVENESS));
		   input.put(MapKeys.CORPORATE_BANK_CODE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_BANK_CODE));
		   input.put(MapKeys.CORPORATE_CODE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_CODE));
		   input.put(MapKeys.CORPORATE_NAME,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_NAME));
		   input.put(MapKeys.COUNT_TYPE_AFTER_DUE, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.COUNT_TYPE_AFTER_DUE));
		   input.put(MapKeys.CREATE_DATE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.CREATE_DATE));
		   input.put(MapKeys.CREATE_USER,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.CREATE_USER));
		   input.put(MapKeys.CUSTOMER_NUMBER,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.CUSTOMER_NUMBER));
		   input.put(MapKeys.IF_DUE_DATE_HOLIDAY,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.IF_DUE_DATE_HOLIDAY));
		   input.put(MapKeys.IS_ONLINE_CORPORATE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.IS_ONLINE_CORPORATE));
		   input.put(MapKeys.MARKETING_EXPERT,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.MARKETING_EXPERT));
		   input.put(MapKeys.CORPORATE_OID,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_OID));
		   input.put(MapKeys.PROTOCOL_START_DATE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.PROTOCOL_START_DATE));
		   input.put(MapKeys.PROTOCOL_END_DATE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.PROTOCOL_END_DATE));
		   input.put(MapKeys.SECTOR_CODE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.SECTOR_CODE));
		   input.put(MapKeys.SHORT_CODE, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.SHORT_CODE));
		   input.put(MapKeys.TRX_NO,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.TRX_NO));
		   input.put(MapKeys.TX_STATUS,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.TX_STATUS));
		   input.put(MapKeys.ALLOW_PART_AFTER_DUE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.ALLOW_PART_AFTER_DUE));
		   input.put(MapKeys.COUNT_AFTER_DUE,information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.COUNT_AFTER_DUE));
		   input.put("MASTER_SUBMIT_ID", information.getMasterSubmitId());
		   super.registerService(this.information.getServiceName(), input);
       }
    }
        
    @Override
    protected ParallelCallBehaviour getParallelCallBehaviour() {
         return new PartialParallelCallBehaviour(this.information.getMaxParallelThreadCount(), true);
    }
}
