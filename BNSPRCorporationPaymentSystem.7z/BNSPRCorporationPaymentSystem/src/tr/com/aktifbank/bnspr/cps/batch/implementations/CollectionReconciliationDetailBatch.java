package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationProcessType;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public abstract class CollectionReconciliationDetailBatch extends
		ReconciliationDetailBatch {
	
	private static final Log logger = LogFactory.getLog(CollectionReconciliationDetailBatch.class);
	
	protected GMMap reconBankMap;
	protected Map<String, GMMap> indexedBankRecords;

	public CollectionReconciliationDetailBatch(GMMap input) {
		super(input);
		indexedBankRecords = new HashMap<String, GMMap>();
	}
	
	protected abstract void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex);
	protected abstract void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex);
	protected abstract boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord);

	@Override
	protected void callBankReconDetail() throws Exception {
		reconBankMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS", this.input);
	}
	
	protected void setBankRecordIndex(String key, GMMap bankRecordValue){
		this.indexedBankRecords.put(key, bankRecordValue);
	}
	
	@SuppressWarnings("unchecked")
	protected GMMap getBankRecordAtIndex(int index){
		List<HashMap<String, Object>> bankKeyList = (List<HashMap<String, Object>>)this.reconBankMap.get("BANK");
		HashMap<String, Object> bankMap = bankKeyList.get(index);
		return CommonHelper.convertMapToGMMap(bankMap);
	}
	
	protected boolean doesExistWithKey(String key){
		return this.indexedBankRecords.containsKey(key);
	}
	
	@Override
	protected boolean doesBankRecordExistInCorporateRecords(int bankRecordIndex) {
		GMMap bankGMMap = this.getBankRecordAtIndex(bankRecordIndex);
		return this.doesBankRecordExistInCorporateRecords(bankGMMap);
	}
	
	protected int getBankRecordSize(){
		return this.reconBankMap.getSize("BANK");
	}

	@Override
	protected void onBankRecordNotFound(int bankRecordIndex) throws Exception {
		String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
		String reconLogOid = input.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		GMMap collectionDetailRequest = new GMMap();
		collectionDetailRequest.put(MapKeys.CORPORATE_CODE, corporateCode);
		collectionDetailRequest.put(MapKeys.SUBSCRIBER_NO1, reconBankMap.getString("BANK", bankRecordIndex, MapKeys.SUBSCRIBER_NO1));
		collectionDetailRequest.put(MapKeys.SUBSCRIBER_NO2, reconBankMap.getString("BANK", bankRecordIndex, MapKeys.SUBSCRIBER_NO2));
		collectionDetailRequest.put(MapKeys.SUBSCRIBER_NO3, reconBankMap.getString("BANK", bankRecordIndex, MapKeys.SUBSCRIBER_NO3));
		collectionDetailRequest.put(MapKeys.SUBSCRIBER_NO4, reconBankMap.getString("BANK", bankRecordIndex, MapKeys.SUBSCRIBER_NO4));
		collectionDetailRequest.put(MapKeys.INVOICE_NO, reconBankMap.getString("BANK", bankRecordIndex, MapKeys.INVOICE_NO));
		collectionDetailRequest.put(MapKeys.TRX_NO, reconBankMap.getString("BANK", bankRecordIndex, MapKeys.TRX_NO));
		collectionDetailRequest.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Collected);
		
		logger.info(String.format("Not found bank record details : %s", collectionDetailRequest.toString()));
		GMMap collectionDetailResponse = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", collectionDetailRequest);
		logger.info(String.format("Not found bank record with more details : %s", collectionDetailResponse.toString()));
		
		GMMap onlineCorporateServiceCallInputMap = new GMMap();
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NO1));
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO2, collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NO2));
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO3, collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NO3));
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO4, collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NO4));
		onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NAME, collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NAME));
		onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_NO, collectionDetailResponse.getString(MapKeys.INVOICE_NO));
		onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_AMOUNT, collectionDetailResponse.getString(MapKeys.INVOICE_AMOUNT));
		onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_AMOUNT, collectionDetailResponse.getString(MapKeys.PAYMENT_AMOUNT));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER1, collectionDetailResponse.getString(MapKeys.PARAMETER1));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER2, collectionDetailResponse.getString(MapKeys.PARAMETER2));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER3, collectionDetailResponse.getString(MapKeys.PARAMETER3));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER4, collectionDetailResponse.getString(MapKeys.PARAMETER4));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER5, collectionDetailResponse.getString(MapKeys.PARAMETER5));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER6, collectionDetailResponse.getString(MapKeys.PARAMETER6));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER7, collectionDetailResponse.getString(MapKeys.PARAMETER7));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER8, collectionDetailResponse.getString(MapKeys.PARAMETER8));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER9, collectionDetailResponse.getString(MapKeys.PARAMETER9));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER10, collectionDetailResponse.getString(MapKeys.PARAMETER10));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER11, collectionDetailResponse.getString(MapKeys.PARAMETER11));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER12, collectionDetailResponse.getString(MapKeys.PARAMETER12));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER13, collectionDetailResponse.getString(MapKeys.PARAMETER13));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER14, collectionDetailResponse.getString(MapKeys.PARAMETER14));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER15, collectionDetailResponse.getString(MapKeys.PARAMETER15));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER16, collectionDetailResponse.getString(MapKeys.PARAMETER16));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER17, collectionDetailResponse.getString(MapKeys.PARAMETER17));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER18, collectionDetailResponse.getString(MapKeys.PARAMETER18));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER19, collectionDetailResponse.getString(MapKeys.PARAMETER19));
		onlineCorporateServiceCallInputMap.put(MapKeys.PARAMETER20, collectionDetailResponse.getString(MapKeys.PARAMETER20));
		onlineCorporateServiceCallInputMap.put(MapKeys.COLLECTION_TYPE, collectionDetailResponse.getString(MapKeys.COLLECTION_TYPE));
		onlineCorporateServiceCallInputMap.put(MapKeys.TRX_NO, collectionDetailResponse.getString(MapKeys.TRX_NO));
		onlineCorporateServiceCallInputMap.put(MapKeys.INSTALLMENT_NO, collectionDetailResponse.getString(MapKeys.INSTALLMENT_NO));
		onlineCorporateServiceCallInputMap.put(MapKeys.INVOICE_DUE_DATE, collectionDetailResponse.getString(MapKeys.INVOICE_DUE_DATE));
		onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_DATE, collectionDetailResponse.getString(MapKeys.CANCEL_DATE));
		onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, collectionDetailResponse.getString(MapKeys.PAYMENT_DATE));
		onlineCorporateServiceCallInputMap.put(MapKeys.TERM_YEAR, collectionDetailResponse.getString(MapKeys.TERM_YEAR));
		onlineCorporateServiceCallInputMap.put(MapKeys.TERM_MONTH, collectionDetailResponse.getString(MapKeys.TERM_MONTH));
		onlineCorporateServiceCallInputMap.put(MapKeys.SOURCE, collectionDetailResponse.getString(MapKeys.SOURCE));
		onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, collectionDetailResponse.getString(MapKeys.CORPORATE_CODE));
		onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
		onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
		onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
		
		logger.info(String.format("Invoice collection request for the not found record on corporate side : %s", onlineCorporateServiceCallInputMap.toString()));
		
		GMMap onlineCorporateServiceCallOutputMap = new GMMap();
		
		try {
			onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
		} catch (Exception e) {
			logger.error("An exception occured while collecting invoice for reconciliation");
			logger.error(System.currentTimeMillis(), e);
			onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.toString());
			onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
		}
		
		insertReconProcessLog(stanNoSequenceKey, corporateCode, reconLogOid,
				collectionDetailResponse, onlineCorporateServiceCallOutputMap);
	}

	private void insertReconProcessLog(String stanNoSequenceKey,
			String corporateCode, String reconLogOid,
			GMMap collectionDetailResponse,
			GMMap onlineCorporateServiceCallOutputMap) {
		try {
			GMMap reconProcessDataLogInsertInputMap = new GMMap();
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE, DatabaseConstants.CollectionTypes.InvoiceLoad);
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE, corporateCode);
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID, reconLogOid);
			if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_CODE)) {
				reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_CODE));
			}
			if (onlineCorporateServiceCallOutputMap.containsKey(MapKeys.ERROR_DESC)) {
				reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC,onlineCorporateServiceCallOutputMap.getString(MapKeys.ERROR_DESC));
			}
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO, stanNoSequenceKey);
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE, ReconciliationProcessType.collectionMessageSent);
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1,collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NO1, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2,collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NO2, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3,collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NO3, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_4,collectionDetailResponse.getString(MapKeys.SUBSCRIBER_NO4, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO, 0);
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT,collectionDetailResponse.getString(MapKeys.INVOICE_AMOUNT, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE,collectionDetailResponse.getString(MapKeys.INVOICE_DUE_DATE, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO,collectionDetailResponse.getString(MapKeys.INVOICE_NO, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1,collectionDetailResponse.getString(MapKeys.PARAMETER1, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2,collectionDetailResponse.getString(MapKeys.PARAMETER2, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3,collectionDetailResponse.getString(MapKeys.PARAMETER3, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4,collectionDetailResponse.getString(MapKeys.PARAMETER4, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5,collectionDetailResponse.getString(MapKeys.PARAMETER5, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6,collectionDetailResponse.getString(MapKeys.PARAMETER6, null));
			reconProcessDataLogInsertInputMap.put(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7,collectionDetailResponse.getString(MapKeys.PARAMETER7, null));

			CommonHelper.callGraymoundServiceOutsideSession("ICS_RECON_PROCESS_DATA_LOG_INSERT", reconProcessDataLogInsertInputMap);
		} catch (Exception e) {
			logger.error("An exception occured while inserting recon process data log.");
			logger.error(System.currentTimeMillis(), e);
		}
	}
	
	@Override
	protected void onCorporateRecordNotFound(int corporateRecordIndex)
			throws Exception {
		String stanNoSequenceKey = CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey);
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
		String reconLogOid = input.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID);
		GMMap collectionDetailRequest = new GMMap();
		this.setPaymentDetailsRequestExtraParameters(collectionDetailRequest, corporateRecordIndex);
		collectionDetailRequest.put(MapKeys.PAYMENT_STATUS, PaymentStatuses.Cancelled);
		collectionDetailRequest.put(MapKeys.CORPORATE_CODE, corporateCode);
		
		logger.info(String.format("Not found corporate record details : %s", collectionDetailRequest.toString()));
		GMMap collectionDetailResponse = CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION", collectionDetailRequest);
		logger.info(String.format("Not found corporate record with more details : %s", collectionDetailResponse.toString()));
		
		if (!collectionDetailResponse.getString(MapKeys.RESPONSE_CODE)
				.equals("0")) {
			onCancelRecordNotFound(collectionDetailResponse, corporateRecordIndex);
		}
		
		GMMap onlineCorporateServiceCallInputMap = new GMMap();
		
		
		onlineCorporateServiceCallInputMap.put(MapKeys.PAYMENT_DATE, collectionDetailResponse.getString(MapKeys.PAYMENT_DATE, input.getString(MapKeys.RECON_DATE)));
		onlineCorporateServiceCallInputMap.put(MapKeys.CANCEL_DATE, collectionDetailResponse.getString(MapKeys.CANCEL_DATE, input.getString(MapKeys.RECON_DATE) + "120000"));
		onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
		onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
		onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
		onlineCorporateServiceCallInputMap.put(MapKeys.STAN_NO, stanNoSequenceKey);
		onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);
		this.setCancelCollectionExtraParameters(onlineCorporateServiceCallInputMap, corporateRecordIndex,collectionDetailResponse);
		this.setCancelCollectionExtraParameters(onlineCorporateServiceCallInputMap, corporateRecordIndex);
		logger.info(String.format("Invoice cancel request for the not found record on bank side : %s", onlineCorporateServiceCallInputMap.toString()));
		GMMap onlineCorporateServiceCallOutputMap = new GMMap();
		try {
			onlineCorporateServiceCallOutputMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
		} catch (Exception e) {
			logger.error("An exception occured while cancelling invoice for reconciliation");
			logger.error(System.currentTimeMillis(), e);
			onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_DESC, e.getMessage());
			onlineCorporateServiceCallOutputMap.put(MapKeys.ERROR_CODE, 9999);
		}
		
		insertReconProcessLog(stanNoSequenceKey, corporateCode, reconLogOid, collectionDetailResponse, onlineCorporateServiceCallOutputMap);		
	}
	
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex) throws Exception{
		throw new Exception("Cancel record not found for " + String.valueOf(corporateRecordIndex) + " index corporate reecord");
	}

}
