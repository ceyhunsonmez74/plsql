package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.turksat.ws.ServiceMessageWs;
import tr.com.aktifbank.integration.turksat.ws.TurksatClientWs;
import tr.com.turksat.kodsis.ws.MutabakatDetay;

import com.graymound.util.GMMap;

public class TurksatCollectionReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(TurksatCollectionReconciliationDetailBatch.class);
	Session session;
	MutabakatDetay[] details;
	ArrayList<MutabakatDetay> listRapor = new ArrayList<MutabakatDetay>();
	ServiceMessageWs message;
	Map<String, MutabakatDetay> indexedCorporateRecords;

	public TurksatCollectionReconciliationDetailBatch(GMMap input, ServiceMessageWs message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, MutabakatDetay>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, this.details[corporateRecordIndex].getDekontNo());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex, GMMap collectionDetailResponse) {
		cancelCollectionRequest.put(MapKeys.CANCEL_SUBSCRIBER_NO1, details[corporateRecordIndex].getHizmetNo());
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details[corporateRecordIndex].getFaturaNo());
		cancelCollectionRequest.put(MapKeys.PAYMENT_AMOUNT, details[corporateRecordIndex].getToplamTutar());
		cancelCollectionRequest.put(MapKeys.CANCEL_PARAMETER6, details[corporateRecordIndex].getReferansNo());
		cancelCollectionRequest.put(MapKeys.TRX_NO, collectionDetailResponse.getString(MapKeys.TRX_NO));
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			details = TurksatClientWs.listeleMutabakatDetay(getReconStartDateTime(CommonHelper.getDateString(input.getDate(MapKeys.RECON_DATE), "yyyyMMdd")), getReconEndDateTime(CommonHelper.getDateString(input.getDate(MapKeys.RECON_DATE), "yyyyMMdd")), Integer.parseInt("1"), "555", input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), message).getDetayList();
			result.setSuccessfulCall(true);
		}
		catch (Exception e) {
			logger.error("An exception occured while calling agri recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;

	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		if (details != null) {
			for (int i = 0; i < details.length; i++) {
				this.indexedCorporateRecords.put(this.details[i].getDekontNo(), this.details[i]);
			}
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details[corporateRecordIndex].getDekontNo());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		// TODO Auto-generated method stub
	}

	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex) throws Exception {
		MutabakatDetay corporateDetail = details[corporateRecordIndex];
		logger.info(String.format("Following corporate record has not been found in database. Hizmet Numaras� : %s, Ref No : %s ,Miktar : %s ", corporateDetail.getHizmetNo(), corporateDetail.getReferansNo(), corporateDetail.getToplamTutar()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(corporateDetail.getHizmetNo());
		payment.setParameter20("MANUEL_IPTAL_MUTABAKAT");
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(corporateDetail.getToplamTutar());
		payment.setPaymentAmount(corporateDetail.getToplamTutar());
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");

		session.saveOrUpdate(payment);
		session.flush();

		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getHizmetNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getToplamTutar());
	}

	public static Calendar getReconStartDateTime(String dateString) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		dateString = dateString + "000000";
		Date date = sdf.parse(dateString);
		SimpleDateFormat gregorianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
		String gregorianDateString = gregorianFormat.format(date);
		Date gregorianDate = gregorianFormat.parse(gregorianDateString);
		Calendar calendarDate = new GregorianCalendar();
		calendarDate.setTime(gregorianDate);
		return calendarDate;

	}

	public static Calendar getReconEndDateTime(String dateString) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		dateString = dateString + "235959";
		Date date = sdf.parse(dateString);
		SimpleDateFormat gregorianFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+hh:mm");
		String gregorianDateString = gregorianFormat.format(date);
		Date gregorianDate = gregorianFormat.parse(gregorianDateString);
		Calendar calendarDate = new GregorianCalendar();
		calendarDate.setTime(gregorianDate);
		return calendarDate;

	}

}
