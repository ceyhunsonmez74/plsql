package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CollectionReconciliationStarterInformation;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.cps.multithreading.implementations.CollectionReconciliationImplementation;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CollectionReconciliationStarterHandler extends RequestHandler {

	private static final String TABLE_NAME = "TABLE_NAME";

    @Override
    protected void handleInternal(GMMap input, GMMap output) throws Throwable {
    	long startMilis = System.currentTimeMillis();
    	String tableNameCorporates = "BATCH_CORPORATES";
		GMMap batchCorporateList = DALUtil.getResults(QueryRepository.CollectionReconciliationStarterHandlerRepository.FETCH_RECON_CORPORATES, tableNameCorporates);
    	Map<String,String> corporateCodes = new HashMap<String, String>();
		CollectionReconciliationStarterInformation information = new CollectionReconciliationStarterInformation();
    	String processDate = "";
		if (input.containsKey("PROCESS_DATE")) {
			information.getCorporateMap().put("PROCESS_DATE", input.getString("PROCESS_DATE"));
			processDate = input.getString("PROCESS_DATE");
		}else {
			information.getCorporateMap().put("PROCESS_DATE",CommonHelper.getShortDateTimeString(new Date()));
			processDate = CommonHelper.getShortDateTimeString(new Date());
		}
		
		information.setServiceName("ICS_COLLECTION_RECONCILIATION");
		information.setMaxParallelThreadCount(5); //paramtext den al�nabilir
		information.setProcessDate(new Date());
		
		for (int i = 0; i < batchCorporateList.getSize(tableNameCorporates); i++) {
			corporateCodes.put(batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_CODE), batchCorporateList.getString(tableNameCorporates, i, MapKeys.SHORT_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_ACTIVENESS, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_ACTIVENESS));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_BANK_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_BANK_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_NAME, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_NAME));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.COUNT_TYPE_AFTER_DUE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.COUNT_TYPE_AFTER_DUE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CREATE_DATE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.CREATE_DATE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CREATE_USER,batchCorporateList.getString(tableNameCorporates, i, MapKeys.CREATE_USER));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CUSTOMER_NUMBER,batchCorporateList.getString(tableNameCorporates, i, MapKeys.CUSTOMER_NUMBER));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.IF_DUE_DATE_HOLIDAY,batchCorporateList.getString(tableNameCorporates, i, MapKeys.IF_DUE_DATE_HOLIDAY));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.IS_ONLINE_CORPORATE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.IS_ONLINE_CORPORATE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.MARKETING_EXPERT,batchCorporateList.getString(tableNameCorporates, i, MapKeys.MARKETING_EXPERT));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_OID,batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_OID));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.PROTOCOL_START_DATE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.PROTOCOL_START_DATE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.PROTOCOL_END_DATE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.PROTOCOL_END_DATE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.SECTOR_CODE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.SECTOR_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.SHORT_CODE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.SHORT_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.TRX_NO,batchCorporateList.getString(tableNameCorporates, i, MapKeys.TRX_NO));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.TX_STATUS,batchCorporateList.getString(tableNameCorporates, i, MapKeys.TX_STATUS));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.ALLOW_PART_AFTER_DUE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.ALLOW_PART_AFTER_DUE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.COUNT_AFTER_DUE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.COUNT_AFTER_DUE));

			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_BATCH_PROCESS_OID, batchCorporateList.getString(tableNameCorporates, i, MapKeys.BATCH_PROCESS_OID) );
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.BANK_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_BANK_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.BATCH_NAME, batchCorporateList.getString(tableNameCorporates, i, MapKeys.BATCH_NAME));
		}
		
		CollectionReconciliationImplementation implementation = new CollectionReconciliationImplementation(information);
		implementation.execute();
		
		long endMilis = System.currentTimeMillis();
		
		GMMap sendReportRequest = new GMMap();
        sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.BATCH_NAME, DatabaseConstants.BatchNames.CollectionReconciliation);
        sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.PROCESS_DATE, new Date());
        sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.DURATION, endMilis - startMilis);
        sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_TO, CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_STD_ORDER_LOAD_REPORT"));
        
        GMServiceExecuter.executeAsync(TransactionConstants.BatchFileReporter.SERVICE_NAME, sendReportRequest);
        
        sendEmailNotificationForCollectionReconciliation(corporateCodes, processDate);
		
    }
    
	private void sendEmailNotificationForCollectionReconciliation(Map<String, String> corporateNameMapping, String processDate) {
		try{
			Date previosDate=CommonHelper.addDay(CommonHelper.getDateTime(processDate, "yyyyMMdd"), -1);
			String previousDateStr=CommonHelper.getDateString(previosDate, "yyyyMMdd");
			GMMap results = CommonHelper.queryData(QueryRepository.CollectionReconciliationStarterHandlerRepository.FETCH_RECON_STATUSES, 
					TABLE_NAME, BnsprType.STRING, previousDateStr + "%");
			
			if(results.getSize(TABLE_NAME) > 0){
				List<Map<String,String>> detailMapList = new ArrayList<Map<String,String>>();
				
				for (int i = 0; i < results.getSize(TABLE_NAME); i++) {
					Map<String, String> logMap = new HashMap<String, String>();
					logMap.put("ROW_CORPORATE_NAME", results.getString(TABLE_NAME, i, "SHORT_CODE"));
					logMap.put("ROW_CORPORATE_CODE", results.getString(TABLE_NAME, i, "CORPORATE_CODE"));
					logMap.put("ROW_RECON_STATUS", getReconStatus(results.getString(TABLE_NAME, i, "RECON_STATUS")));
					logMap.put("ROW_RECON_TYPE", getReconType(results.getString(TABLE_NAME, i,"RECON_TYPE")));
					logMap.put("ROW_BANK_COLLECTION_COUNT", results.getString(TABLE_NAME, i,"BANK_COUNT"));
					logMap.put("ROW_BANK_COLLECTION_AMOUNT", results.getString(TABLE_NAME, i, "BANK_AMOUNT"));
					logMap.put("ROW_CORPORATE_COLLECTION_COUNT", results.getString(TABLE_NAME, i, "CORPORATE_COUNT"));
					logMap.put("ROW_CORPORATE_COLLECTION_AMOUNT", results.getString(TABLE_NAME, i, "CORPORATE_AMOUNT"));
					logMap.put("ROW_BANK_COLLECTION_CANCEL_COUNT", results.getString(TABLE_NAME, i, "BANK_CANCEL_COUNT"));
					logMap.put("ROW_BANK_COLLECTION_CANCEL_AMOUNT", results.getString(TABLE_NAME, i, "BANK_CANCEL_AMOUNT"));
					logMap.put("ROW_CORPORATE_COLLECTION_CANCEL_COUNT", results.getString(TABLE_NAME, i, "CORPORATE_CANCEL_COUNT"));
					logMap.put("ROW_CORPORATE_COLLECTION_CANCEL_AMOUNT", results.getString(TABLE_NAME, i, "CORPORATE_CANCEL_AMOUNT"));
					logMap.put("ROW_ERROR_CODE", results.getString(TABLE_NAME, i, "ERROR_CODE"));
					logMap.put("ROW_ERROR_DESC", results.getString(TABLE_NAME, i, "ERROR_DESC"));
					detailMapList.add(logMap);
				}
				
				String receiptList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST","EMAIL_RECEIPT_LIST_4_COL_RECON");
				
				GMMap messageMap = new GMMap();
				messageMap.put("MAP_TABLE", detailMapList);
				
				GMMap subjectMap = new GMMap();
				subjectMap.put("PROCESS_DATE",CommonHelper.getDateString(CommonHelper.getDateTime(processDate, "yyyyMMdd"), "dd/MM/yyyy"));
				
				EmailMessage emailMessage = CommonHelper.prepareEmailBody("", messageMap,NotificationMessageConstant.Email.CollectionReconciliationMessageConstant.MESSAGE_BODY,
						CommonHelper.generateSubject(NotificationMessageConstant.Email.CollectionReconciliationMessageConstant.SUBJECT,subjectMap),receiptList);
				
				CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
			}
			
			
		}
		catch(Exception e){
			logger.error("An exception occured while sending collection reconciliation detail report");
			logger.error(System.currentTimeMillis(), e);
		}
	}
	private String getReconStatus(String status)
	{
		String statusStr="";
		if (status.equals(DatabaseConstants.ReconciliationStatus.Continues)) {
			statusStr="Devam Ediyor";
		}
		if (status.equals(DatabaseConstants.ReconciliationStatus.ReconciliationFailed)) {
			statusStr="Ba�ar�s�z Oldu";
		}
		if (status.equals(DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded)) {
			statusStr="Ba�ar�l� Bitti";
		}
		if (status.equals(DatabaseConstants.ReconciliationStatus.Started)) {
			statusStr="Ba�lad�";
		}
		return statusStr;
	}
	private String getReconType(String status)
	{
		String typeStr="";
		if (status.equals(String.valueOf(DatabaseConstants.ReconciliationTypes.Collection))) {
			typeStr="Tahsilat";
		}
		if (status.equals(String.valueOf(DatabaseConstants.ReconciliationTypes.General))) {
			typeStr="Genel";
		}
		if (status.equals(String.valueOf(DatabaseConstants.ReconciliationTypes.MoneyLoad))) {
			typeStr="TL Y�kleme";
		}
		if (status.equals(String.valueOf(DatabaseConstants.ReconciliationTypes.StandingOrder))) {
			typeStr="Talimat";
		}
		return typeStr;
	}

}
