package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.FTSGetTotalCancelledStandingOrderCountHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public final class FTSGetTotalCancelledStandingOrderCountHandler extends
		RequestHandler {

	public FTSGetTotalCancelledStandingOrderCountHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Date processDate = input.getDate(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE);
		String dateString = CommonHelper.getShortDateTimeString(processDate);
		
		GMMap result = DALUtil.getResults(String.format(FTSGetTotalCancelledStandingOrderCountHandlerRepository.GET_COUNT_OF_CANCELLED_STD_ORD_QUERY, 
				dateString, 
				input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE),
				DatabaseConstants.StandingOrderStatus.Canelled), "COUNT_TABLE");
		
		output.put(MapKeys.FTS_OUTPUT_DATA, result.getInt("COUNT_TABLE", 0, "TOTAL_COUNT"));
	}

}
