package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.GetPaymentsByCustomerNumber;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class GetPaymentsByCustomerNumberHandler extends RequestHandler {

	private static final String RESULT_TABLE = "RESULT_TABLE";
	
	public GetPaymentsByCustomerNumberHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String customerNo = input.getString(GetPaymentsByCustomerNumber.Input.CUSTOMER_NO);
		String channelCode = input.getString(GetPaymentsByCustomerNumber.Input.PAY_CHANNEL_CODE, null);
		
		String currentDate = CommonHelper.getShortDateTimeString(new Date());
		
		StringBuilder query = new StringBuilder();
		
		query.append("SELECT cm.CORPORATE_NAME, ip.INVOICE_AMOUNT, ip.INVOICE_NO, ip.PAYMENT_AMOUNT, ip.OID, sd.SECTOR_NAME, ip.SUBSCRIBER_NAME, ");
		query.append("ip.SUBSCRIBER_NO1, ip.SUBSCRIBER_NO2, ip.SUBSCRIBER_NO3, ip.SUBSCRIBER_NO4 ");
		query.append("FROM ICS.INVOICE_PAYMENT ip INNER JOIN CDM.CORPORATE_MASTER cm ");
		query.append("ON ip.CORPORATE_CODE = cm.CORPORATE_CODE ");
		query.append("INNER JOIN CDM.SECTOR_DEF sd ");
		query.append("ON cm.SECTOR_CODE = sd.SECTOR_CODE ");
		query.append(String.format("WHERE ip.STATUS = 1 AND ip.PAYMENT_STATUS = '%s' AND ip.PAYER_CUSTOMER = '%s' AND ", 
				DatabaseConstants.PaymentStatuses.Collected, customerNo));
		query.append(String.format("ip.PAYMENT_DATE like '%s%%' AND ", currentDate));
		query.append("sd.STATUS = 1 AND cm.STATUS = 1");
		if(!StringUtil.isEmpty(channelCode)){
			query.append(String.format(" AND ip.PAYMENT_CHANNEL = '%s'", channelCode));
		}
		
		logger.info(query.toString());
		
		GMMap results = DALUtil.getResults(query.toString(), RESULT_TABLE);
		
		for (int i = 0; i < results.getSize(RESULT_TABLE); i++) {
			output.put(GetPaymentsByCustomerNumber.Output.PAYMENTS_TABLE, i, GetPaymentsByCustomerNumber.Output.CORPORATE_NAME, 
					results.getString(RESULT_TABLE, i, "CORPORATE_NAME"));
			
			output.put(GetPaymentsByCustomerNumber.Output.PAYMENTS_TABLE, i, GetPaymentsByCustomerNumber.Output.INVOICE_AMOUNT, 
					results.getBigDecimal(RESULT_TABLE, i, "INVOICE_AMOUNT"));
			
			output.put(GetPaymentsByCustomerNumber.Output.PAYMENTS_TABLE, i, GetPaymentsByCustomerNumber.Output.INVOICE_NO, 
					results.getString(RESULT_TABLE, i, "INVOICE_NO"));
			
			output.put(GetPaymentsByCustomerNumber.Output.PAYMENTS_TABLE, i, GetPaymentsByCustomerNumber.Output.PAID_AMOUNT, 
					results.getBigDecimal(RESULT_TABLE, i, "PAYMENT_AMOUNT"));
			
			output.put(GetPaymentsByCustomerNumber.Output.PAYMENTS_TABLE, i, GetPaymentsByCustomerNumber.Output.PAYMENT_OID, 
					results.getString(RESULT_TABLE, i, "OID"));
			
			output.put(GetPaymentsByCustomerNumber.Output.PAYMENTS_TABLE, i, GetPaymentsByCustomerNumber.Output.SECTOR_NAME, 
					results.getString(RESULT_TABLE, i, "SECTOR_NAME"));
			
			output.put(GetPaymentsByCustomerNumber.Output.PAYMENTS_TABLE, i, GetPaymentsByCustomerNumber.Output.SUBSCRIBER_NAME, 
					results.getString(RESULT_TABLE, i, "SUBSCRIBER_NAME"));
			
			output.put(GetPaymentsByCustomerNumber.Output.PAYMENTS_TABLE, i, GetPaymentsByCustomerNumber.Output.SUBSCRIBER_NO, 
					getSubscriberNo(results, i));
		}
		
	}

	private String getSubscriberNo(GMMap results, int index) {
		StringBuilder subscriberNoBuilder = new StringBuilder();
		
		if(!StringUtil.isEmpty(results.getString(RESULT_TABLE, index, "SUBSCRIBER_NO1"))) {
			subscriberNoBuilder.append(String.format("%s, ", results.getString(RESULT_TABLE, index, "SUBSCRIBER_NO1")));
		}
		
		if(!StringUtil.isEmpty(results.getString(RESULT_TABLE, index, "SUBSCRIBER_NO2"))) {
			subscriberNoBuilder.append(String.format("%s, ", results.getString(RESULT_TABLE, index, "SUBSCRIBER_NO2")));
		}
		
		if(!StringUtil.isEmpty(results.getString(RESULT_TABLE, index, "SUBSCRIBER_NO3"))) {
			subscriberNoBuilder.append(String.format("%s, ", results.getString(RESULT_TABLE, index, "SUBSCRIBER_NO3")));
		}
		
		if(!StringUtil.isEmpty(results.getString(RESULT_TABLE, index, "SUBSCRIBER_NO4"))) {
			subscriberNoBuilder.append(String.format("%s, ", results.getString(RESULT_TABLE, index, "SUBSCRIBER_NO4")));
		}
		
		String subscriberNo = subscriberNoBuilder.toString();
		
		return !StringUtil.isEmpty(subscriberNo) ? "" : subscriberNo.substring(0, subscriberNo.length() - 2);
	}

}
