package tr.com.aktifbank.bnspr.cps.util;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.dao.AccountCollectionTypeRel;
import tr.com.aktifbank.bnspr.dao.AccountCollectionTypeRelTx;
import tr.com.aktifbank.bnspr.dao.ChannelSourceDef;
import tr.com.aktifbank.bnspr.dao.ChannelSourceDefTx;
import tr.com.aktifbank.bnspr.dao.CollectionTypeDef;
import tr.com.aktifbank.bnspr.dao.CollectionTypeDefTx;
import tr.com.aktifbank.bnspr.dao.CorporateCityRel;
import tr.com.aktifbank.bnspr.dao.CorporateCityRelTx;
import tr.com.aktifbank.bnspr.dao.CorporateContactinfo;
import tr.com.aktifbank.bnspr.dao.CorporateContactinfoTx;
import tr.com.aktifbank.bnspr.dao.CorporateMasterTx;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMasterTx;
import tr.com.aktifbank.bnspr.dao.SourceParam;
import tr.com.aktifbank.bnspr.dao.SubscriberMaskDef;
import tr.com.aktifbank.bnspr.dao.SubscriberMaskDefTx;
import tr.com.aktifbank.bnspr.dao.SubscriberMaskDetail;
import tr.com.aktifbank.bnspr.dao.SubscriberMaskDetailTx;
import tr.com.aktifbank.bnspr.dao.TaxTypeCollectionType;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.dao.GnlilKodPr;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.obss.adc.core.services.transaction.ServiceExecuter;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CorporationServiceUtil {

	public static String getSequenceCode(String tableName) throws Exception {

		try {
			GMMap iMap = new GMMap();
			iMap.put("TABLE_NAME", tableName);
			Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap);
			return oMap.get("ID").toString();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}

	}

	@GraymoundService("CDM_INSTANCE_SERVICE_LOAD")
	public static GMMap instanceServiceLoad(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("SECTOR_DEF", ServiceExecuter.call("CDM_TRN7000_GET_SECTORS_COMBO", (new GMMap()).put("TABLE_NAME", "SECTOR_DEF").put("PLEASE_SELECT", "true")).get("SECTOR_DEF"));
			oMap.putAll(ServiceExecuter.call("CDM_GET_GENERAL_CITIES", iMap));
			oMap.putAll(ServiceExecuter.call("CDM_GET_COLLECTION_TYPES", iMap));
			oMap.putAll(ServiceExecuter.call("CDM_GET_SOURCES", iMap));
			oMap.putAll(ServiceExecuter.call("CDM_GET_CHANNELS", iMap));
			oMap.put("END_PAYMENT_DATE_TYPE", ServiceExecuter.call("CDM_GET_DATE_TYPES", (new GMMap()).put("KOD", iMap.getString("CDM_TARIH_TURU"))).get("RESULTS"));
			oMap.put("END_PAYMENT_VACATION_DAY", ServiceExecuter.call("CDM_GET_WORK_DAY_STATUS", (new GMMap()).put("KOD", iMap.getString("CDM_IS_GUNU"))).get("RESULTS"));
			oMap.put("ACCOUNT_TYPE", ServiceExecuter.call("CDM_GET_ACCOUNT_ORDERS", (new GMMap()).put("KOD", iMap.getString("CDM_TEMERKUZ_HESAP_TURU"))).get("RESULTS"));
			oMap.put("TRANSFER_TYPE", ServiceExecuter.call("CDM_GET_TRANSFER_TYPES", (new GMMap()).put("KOD", iMap.getString("CDM_TRANSFER_TIPI"))).get("RESULTS"));
			oMap.put("TRANSFER_DAY_TYPE", ServiceExecuter.call("CDM_GET_TRANSFER_DAY_TYPES", (new GMMap()).put("KOD", iMap.getString("CDM_AKTARIM_GUN_TIPI"))).get("RESULTS"));
			oMap.put("TRANSFER_VACATION", ServiceExecuter.call("CDM_GET_TRANSFER_HOLIDAY_TYPES", (new GMMap()).put("KOD", iMap.getString("CDM_AKTARIM_TATIL_GUNU"))).get("RESULTS"));
			GMMap oMapMatching = ServiceExecuter.call("CDM_GET_TRANSFER_DAY_MATCHINGS", (new GMMap()).put("KOD", iMap.getString("CDM_AKTARIM_GUNLERI")));
			oMap.put("DAY_MATCHING_EXIT_DAY", oMapMatching.get("RESULTS"));
			oMap.put("DAY_MATCHING", oMapMatching.get("DAY_MATCHING"));
			oMap.put("DEPARTMENT", ServiceExecuter.call("CDM_GET_DEPARTMENTS", (new GMMap()).put("KOD", iMap.getString("CDM_DEPARTMAN"))).get("RESULTS"));
			oMap.put("INSTANCE_ACCOUNT_DEF_TYPE", DatabaseConstants.AccountDefinitionTypes.CollectionAccount);
			oMap.put("INSTANCE_ACCOUNT_CONCENTRATION_TYPE", DatabaseConstants.ConcentrationTypes.SingleConcentration);
			oMap.put("INSTANCE_ACCOUNT_ACCOUNT_TYPE", DatabaseConstants.AccountTypes.CheckingAccount);
			oMap.put("TAX_DEFAULT_SECTOR_VALUE", ServiceExecuter.call("TCS_GET_SECTOR_TAX_DEFAULT_VALUE", (new GMMap()).put("KOD", iMap.getString("V_GENERAL_TAX_SECTOR_VALUE"))).get("TAX_DEFAULT_SECTOR_VALUE"));
			oMap.put("DDS_DEFAULT_SECTOR_NAME", ServiceExecuter.call("DDS_GET_GENERAL_PARAMETERS", new GMMap()).get("DEFAULT_SECTOR_NAME"));
			oMap.put("GAME_OF_CHANCE_DEFAULT_SECTOR_NAME", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "GAME_OF_CHANCE_SECTOR_NAME"));
			return oMap;			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_GENERAL_CITIES")
	public static GMMap getGeneralCities(GMMap iMap) {

		GMMap oMap = new GMMap();
		List<GnlilKodPr> listContactInfo = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			listContactInfo = (List<GnlilKodPr>) session.createCriteria(GnlilKodPr.class).addOrder(Order.asc("ilAdi")).list();

			if (listContactInfo != null) {
				for (int row = 0; row <= listContactInfo.size() - 1; row++) {
					GnlilKodPr gilPr = listContactInfo.get(row);
					oMap.put("CITIES", row, "KOD", gilPr.getKod());
					oMap.put("CITIES", row, "IL_ADI", gilPr.getIlAdi());
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_SOURCES")
	public static GMMap getSources(GMMap iMap) {
		GMMap oMap = new GMMap();
		List<SourceParam> listSourceParam = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			listSourceParam = (List<SourceParam>) session.createCriteria(SourceParam.class).addOrder(Order.asc("sourceName")).list();

			if (listSourceParam != null) {
				for (int row = 0; row <= listSourceParam.size() - 1; row++) {
					SourceParam gilPr = listSourceParam.get(row);
					oMap.put("SOURCES", row, "SOURCE_CODE", gilPr.getSourceCode());
					oMap.put("SOURCES", row, "SOURCE_NAME", gilPr.getSourceName());
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_GET_CHANNELS")
	public static GMMap getChannels(GMMap iMap) {
		GMMap oMap = new GMMap();
		List<GnlKanalGrupKodPr> listGnlKanalGrupKodPr = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			listGnlKanalGrupKodPr = (List<GnlKanalGrupKodPr>) session.createCriteria(GnlKanalGrupKodPr.class).addOrder(Order.asc("aciklama")).list();

			if (listGnlKanalGrupKodPr != null) {
				for (int row = 0; row <= listGnlKanalGrupKodPr.size() - 1; row++) {
					GnlKanalGrupKodPr gilPr = listGnlKanalGrupKodPr.get(row);
					oMap.put("CHANNELS", row, "CHANNEL_CODE", gilPr.getKod());
					oMap.put("CHANNELS", row, "CHANNEL_NAME", gilPr.getAciklama());
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("CDM_GET_DATE_TYPES")
	public static GMMap getDateTypes(GMMap iMap) {

		return getComboValues(iMap);
	}

	@GraymoundService("CDM_GET_WORK_DAY_STATUS")
	public static GMMap getWorkDayStatus(GMMap iMap) {

		return getComboValues(iMap);
	}

	public static GMMap getComboValues(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			oMap = (GMMap) GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}

	@GraymoundService("CDM_GET_DEPARTMENTS")
	public static GMMap getDepartments(GMMap iMap) {

		return getComboValues(iMap);
	}

	@GraymoundService("CDM_GET_ACCOUNT_ORDERS")
	public static GMMap getAccountOrders(GMMap iMap) {

		return getComboValues(iMap);
	}

	@GraymoundService("CDM_GET_ACCOUNT_TYPES")
	public static GMMap getAccountTypes(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap resultMap = new GMMap();
		boolean operation = false;
		int sayac = 0;
		try {
			oMap = getComboValues(iMap);
			if ("TH".equals(iMap.getString("ACCOUNT_ORDER"))) {
				for (int index = 0; index < oMap.getSize("RESULTS"); index++) {
					if ("VS".equals(oMap.getString("RESULTS", index, "VALUE"))) {
						resultMap.put("RESULTS", sayac, "NAME", oMap.getString("RESULTS", index, "NAME"));
						resultMap.put("RESULTS", sayac, "VALUE", oMap.getString("RESULTS", index, "VALUE"));
						sayac++;
					}
				}
				operation = true;
			} else if ("KH".equals(iMap.getString("ACCOUNT_ORDER"))) {
				sayac = 0;
				for (int index = 0; index < oMap.getSize("RESULTS"); index++) {
					if (oMap.getString("RESULTS", index, "VALUE").startsWith("V")) {
						resultMap.put("RESULTS", sayac, "NAME", oMap.getString("RESULTS", index, "NAME"));
						resultMap.put("RESULTS", sayac, "VALUE", oMap.getString("RESULTS", index, "VALUE"));
						sayac++;
					}
				}
				operation = true;
			}
			resultMap.put("OPERATION", operation);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ExceptionHandler.convertException(ex);
		}
		return resultMap;
	}

	@GraymoundService("CDM_GET_TRANSFER_TYPES")
	public static GMMap getTransferTypes(GMMap iMap) {

		return getComboValues(iMap);
	}

	@GraymoundService("CDM_GET_TRANSFER_DAY_TYPES")
	public static GMMap getTransferDayTypes(GMMap iMap) {

		return getComboValues(iMap);
	}

	@GraymoundService("CDM_GET_TRANSFER_HOLIDAY_TYPES")
	public static GMMap getTransferHolidayTypes(GMMap iMap) {

		return getComboValues(iMap);
	}

	@GraymoundService("CDM_GET_TRANSFER_DAY_MATCHINGS")
	public static GMMap getTransferDayMatchings(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap resultMap = getComboValues(iMap);

		oMap.putAll(resultMap);

		if (resultMap != null) {
			for (int index = 0; index < resultMap.getSize("RESULTS"); index++) {
				oMap.put("DAY_MATCHING", index, "GELEN_GUN", resultMap.getString("RESULTS", index, "NAME"));
				oMap.put("DAY_MATCHING", index, "SONRAKI_HAFTA", false);
				oMap.put("DAY_MATCHING", index, "GUN_SAYISI", 0);
			}
			oMap.put("DAY_MATCHING", 5, "SONRAKI_HAFTA", false);
			oMap.put("DAY_MATCHING", 5, "GUN_SAYISI", 0);
			oMap.put("DAY_MATCHING", 5, "GELEN_GUN", "Cumartesi");
			oMap.put("DAY_MATCHING", 6, "SONRAKI_HAFTA", false);
			oMap.put("DAY_MATCHING", 6, "GUN_SAYISI", 0);
			oMap.put("DAY_MATCHING", 6, "GELEN_GUN", "Pazar");
		}
		return oMap;
	}

	@GraymoundService("CDM_GET_SUBSCRIBE_DEFINITON_ID")
	public static GMMap getSubscribeDefinitionId(GMMap iMap) throws Exception {

		GMMap oMap = new GMMap();
		oMap.put("DEFINITION_ID", getSequenceCode(iMap.getString("TABLE_NAME")));

		return oMap;
	}

	// @GraymoundService("CUSTOMER_TYPE_CHANGE")
	// public static GMMap customerTypeChange(GMMap iMap) throws Exception {
	//
	// GMMap oMap = new GMMap();
	// Session session = DAOSession.getSession("BNSPRDal");
	//
	// SubscriberMaskDetail sbd=(SubscriberMaskDetail) session.createCriteria(SubscriberMaskDetail.class)
	// .add(Restrictions.eq("oid", iMap.getString("MASK_OID"))).add(Restrictions.eq("status", true)).uniqueResult();
	// oMap.put("SUBSCRIBER_1_MASK",CommonBusinessOperations.getMask(sbd.getMask()));
	// oMap.put("SUBSCRIBER_1_PATTERN",sbd.getMask());
	// return oMap;
	// }

	/**
	 * Converts the currency value to comma delimited format. e.g. 17452.45 TL -> 17,452.45 TL
	 */
	@GraymoundService("ICS_FORMAT_BALANCE")
	public static GMMap formatCurrency(GMMap iMap) {
		GMMap outMap = new GMMap();

		String balance = iMap.getString("BALANCE");
		balance = NumberFormat.getInstance(Locale.ENGLISH).format(Double.parseDouble(balance));

		outMap.put("BALANCE", balance);

		return outMap;
	}

	/**
	 * Checks the sector name if it is already existing in the list.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GraymoundService("CDM_CHECK_SECTOR_DUPLICATION")
	public static GMMap isExistingSector(GMMap iMap) {
		try {
			GMMap outMap = new GMMap();

			ArrayList<HashMap> list = (ArrayList<HashMap>) iMap.get("SECTOR_LIST");

			for (Map<String, String> m : list) {
				if (iMap.getString("SECTOR_NAME").toUpperCase().equals((m.get("SECTOR_NAME").toUpperCase()))) {
					CommonHelper.throwBusinessException(BusinessException.DUPLICATESECTOR.getCode());
				}
			}

			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_CHECK_SECTOR_NAME")
	public static GMMap isSuitableSectorName(GMMap iMap) {
		try {
			GMMap outMap = new GMMap();
			String sectorName = "";
			if (iMap.containsKey("SECTOR_NAME")) {
				sectorName = iMap.getString("SECTOR_NAME").trim();
			}

			if (sectorName.length() < 2 || sectorName.length() > 50) {
				CommonHelper.throwBusinessException(BusinessException.INVALIDSECTORNAME.getCode());
			}

			for (char ch : sectorName.toCharArray()) {
				if (!(Character.isLetter(ch) || Character.isDigit(ch)|| "_".equalsIgnoreCase(String.valueOf(ch)))) {
					CommonHelper.throwBusinessException(BusinessException.INVALIDSECTORNAME.getCode());
				}
			}
			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("PREPARE_ACCOUNT_TABLE_TO_UPDATE")
	public static GMMap prepareAcountTable(GMMap iMap) {
		try {
			GMMap outMap = new GMMap();
			// Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "TABLO_HESAP_AKTARIM";
			String tableNameNew = "TABLO_HESAP_AKTARIM_YENI";
			// GMMap tableMap=new GMMap();
			// tableMap=iMap.getMap(tableName);

			for (int row = 0; row < iMap.getSize(tableName); row++) {
				outMap.put(tableNameNew, row, "DAY_TRANSFER_TYPE_ID", iMap.getString(tableName, row, "DAY_TRANSFER_TYPE_ID"));
				outMap.put(tableNameNew, row, "FROM_ACCOUNT_NO", iMap.getString(tableName, row, "FROM_ACCOUNT_NO"));
				outMap.put(tableNameNew, row, "TRANSFER_RULE_HOLIDAY", iMap.getString(tableName, row, "TRANSFER_RULE_HOLIDAY"));
				outMap.put(tableNameNew, row, "TRANSFER_RULE_DAY", iMap.getString(tableName, row, "TRANSFER_RULE_DAY"));
				outMap.put(tableNameNew, row, "TRANSFER_RULE_AY", iMap.getString(tableName, row, "TRANSFER_RULE_AY"));
				outMap.put(tableNameNew, row, "TRANSFER_MONTH_OPTION", iMap.getString(tableName, row, "TRANSFER_MONTH_OPTION"));
				outMap.put(tableNameNew, row, "TRANSFER_DAY_OPTION", iMap.getString(tableName, row, "TRANSFER_DAY_OPTION"));
				outMap.put(tableNameNew, row, "TO_ACCOUNT_NO_ID", iMap.getString(tableName, row, "TO_ACCOUNT_NO_ID"));
				outMap.put(tableNameNew, row, "TO_ACCOUNT_NO", iMap.getString(tableName, row, "TO_ACCOUNT_NO"));
				outMap.put(tableNameNew, row, "KANAL_KAYNAK_ODEME_ID", iMap.getString(tableName, row, "KANAL_KAYNAK_ODEME_ID"));
				outMap.put(tableNameNew, row, "KANAL_KAYNAK_ODEME", iMap.getString(tableName, row, "KANAL_KAYNAK_ODEME"));
				outMap.put(tableNameNew, row, "HOLIDAY_TRANSFER_TYPE_ID", iMap.getString(tableName, row, "HOLIDAY_TRANSFER_TYPE_ID"));
				outMap.put(tableNameNew, row, "FROM_ACCOUNT_NO_ID", iMap.getString(tableName, row, "FROM_ACCOUNT_NO_ID"));
				outMap.put(tableNameNew, row, "UPDATE_ROW", iMap.getString(tableName, row, ""));
			}

			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_CHECK_IF_ANY_UPDATE")
	public static GMMap checkIfAnyUpdate(GMMap iMap) {
		try {
			GMMap outMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			@SuppressWarnings("unchecked")
			List<CorporateMasterTx> cmtx = session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).add(Restrictions.isNotNull("txNo")).add(Restrictions.eq("txStatus", "N")).add(Restrictions.eq("status", true)).list();
			if (cmtx.size() > 0) {
				outMap.put("WAITING_ON_APPROVAL", true);
			} else {
				outMap.put("WAITING_ON_APPROVAL", false);
			}
			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("ON_LOST_MAX_DAY_CONTROL")
	public static GMMap onLostMaxDayControl(GMMap iMap) {
		try {
			GMMap outMap = new GMMap();
			int val = iMap.getInt("VAL_INT");
			if (val > 31) {
				outMap.put("VALUE_INT", "YES");
			} else {
				outMap.put("VALUE_INT", "NO");
			}
			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CDM_CHECK_TEXT_LETTERS")
	public static GMMap isLetters(GMMap iMap) {
		try {
			GMMap outMap = new GMMap();
			String text = "";
			String label = "";
			List<String> keys = new ArrayList<String>();
			if (iMap.containsKey("TEXT")) {
				text = iMap.getString("TEXT").trim();
			}
			if (iMap.containsKey("LABEL")) {
				label = iMap.getString("LABEL").trim();
			}
			if (iMap.containsKey("EXCEPTIONAL_KEYS")) {
				keys = Arrays.asList(iMap.getString("EXCEPTIONAL_KEYS").split(","));
			}
			if (text.length() > 0) {
				for (char ch : text.toCharArray()) {
					if (!Character.isLetter(ch) && !keys.contains(String.valueOf(ch))) {
						CommonHelper.throwBusinessException(BusinessException.INVALIDCHARACTERNOTLETTER.getCode(), label);
					}
				}
			}
			return outMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_GENEL_RENKLENDIRME")
	public static GMMap renklendirme(GMMap iMap) {
		GMMap outMap = new GMMap();

		BigDecimal txNo = iMap.getBigDecimal(MapKeys.TRX_NO);
		String tableName = "cdm.corporate_master_tx";

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			CorporateMasterTx newCorporateTx = (CorporateMasterTx) session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("txNo", txNo)).addOrder(Order.desc("createDate")).setMaxResults(1).uniqueResult();

			BigDecimal previousTxNo = BigDecimal.valueOf(Long.parseLong(CommonBusinessOperations.getPreviousTxNo(tableName, txNo, newCorporateTx.getCorporateCode())));

			CorporateMasterTx oldCorporateTx = (CorporateMasterTx) session.createCriteria(CorporateMasterTx.class).add(Restrictions.eq("txNo", previousTxNo)).addOrder(Order.desc("createDate")).setMaxResults(1).uniqueResult();

			outMap.putAll(BeanSetProperties.reflectDifference(newCorporateTx, oldCorporateTx, null, null));

			// ILLER LISTESINDEKI FARKLAR
			List<CorporateCityRelTx> newListCityDef = (List<CorporateCityRelTx>) session.createCriteria(CorporateCityRelTx.class).add(Restrictions.eq("corporateOid", newCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			List<CorporateCityRel> oldListCityDef = (List<CorporateCityRel>) session.createCriteria(CorporateCityRel.class).add(Restrictions.eq("corporateOid", oldCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			String newTableName = "NEW_CITIES";
			String oldTableName = "OLD_CITIES";

			for (int row = 0; row < newListCityDef.size(); row++) {
				CorporateCityRelTx cityDef = newListCityDef.get(row);

				outMap.put(newTableName, row, "IL_SEC", cityDef.getKod());
				outMap.put(newTableName, row, "IL_ADI", cityDef.getKod());

			}
			for (int row = 0; row < oldListCityDef.size(); row++) {
				CorporateCityRel cityDef = oldListCityDef.get(row);

				outMap.put(oldTableName, row, "IL_SEC", cityDef.getKod());
				outMap.put(oldTableName, row, "IL_ADI", cityDef.getKod());

			}

			outMap.put("CITY_REL", BeanSetProperties.tableDifference((ArrayList<?>) outMap.get(oldTableName), (ArrayList<?>) outMap.get(newTableName), "IL_SEC").get("COLOR_DATA"));

			// KANAL-KAYNAK YONETIMI FARKLAR
			List<ChannelSourceDefTx> newListChannelSourceDef = (List<ChannelSourceDefTx>) session.createCriteria(ChannelSourceDefTx.class).add(Restrictions.eq("corporateOid", newCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			List<ChannelSourceDef> oldListChannelSourceDef = (List<ChannelSourceDef>) session.createCriteria(ChannelSourceDef.class).add(Restrictions.eq("corporateOid", oldCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			newTableName = "NEW_CHANNELS_SOURCES";
			oldTableName = "OLD_CHANNELS_SOURCES";

			for (int row = 0; row < newListChannelSourceDef.size(); row++) {
				ChannelSourceDefTx chDef = newListChannelSourceDef.get(row);

				outMap.put(newTableName, row, "CHANNEL_NAME", chDef.getChannelCode());
				outMap.put(newTableName, row, "CLOSED_DATE_END", chDef.getClosedDateEnd());
				outMap.put(newTableName, row, "CLOSED_DATE_START", chDef.getClosedDateStart());
				outMap.put(newTableName, row, "HOLIDAY_END_TIME", chDef.getHolidayEndTime());
				outMap.put(newTableName, row, "HOLIDAY_START_TIME", chDef.getHolidayStartTime());
				outMap.put(newTableName, row, "SOURCE_NAME", chDef.getSourceCode());
				outMap.put(newTableName, row, "WORKINGDAY_END_TIME", chDef.getWorkingdayEndTime());
				outMap.put(newTableName, row, "WORKINGDAY_START_TIME", chDef.getWorkingdayStartTime());

			}
			for (int row = 0; row < oldListChannelSourceDef.size(); row++) {
				ChannelSourceDef chDef = oldListChannelSourceDef.get(row);

				outMap.put(oldTableName, row, "CHANNEL_NAME", chDef.getChannelCode());
				outMap.put(oldTableName, row, "CLOSED_DATE_END", chDef.getClosedDateEnd());
				outMap.put(oldTableName, row, "CLOSED_DATE_START", chDef.getClosedDateStart());
				outMap.put(oldTableName, row, "HOLIDAY_END_TIME", chDef.getHolidayEndTime());
				outMap.put(oldTableName, row, "HOLIDAY_START_TIME", chDef.getHolidayStartTime());
				outMap.put(oldTableName, row, "SOURCE_NAME", chDef.getSourceCode());
				outMap.put(oldTableName, row, "WORKINGDAY_END_TIME", chDef.getWorkingdayEndTime());
				outMap.put(oldTableName, row, "WORKINGDAY_START_TIME", chDef.getWorkingdayStartTime());
			}

			ArrayList<String> channelSourceKeyColumns = new ArrayList<String>();
			channelSourceKeyColumns.add("CHANNEL_NAME");
			channelSourceKeyColumns.add("SOURCE_NAME");

			outMap.put("CHANNELS_SOURCES_REL", BeanSetProperties.tableDifference((ArrayList<?>) outMap.get(oldTableName), (ArrayList<?>) outMap.get(newTableName), channelSourceKeyColumns).get("COLOR_DATA"));

			// ODEME TIPLERI YONETIMI FARKLAR
			List<CollectionTypeDefTx> newListCollectionTypeDef = (List<CollectionTypeDefTx>) session.createCriteria(CollectionTypeDefTx.class).add(Restrictions.eq("corporateOid", newCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			List<CollectionTypeDef> oldListCollectionTypeDef = (List<CollectionTypeDef>) session.createCriteria(CollectionTypeDef.class).add(Restrictions.eq("corporateOid", oldCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			newTableName = "NEW_COLLECTION_TYPES";
			oldTableName = "OLD_COLLECTION_TYPES";

			for (int row = 0; row < newListCollectionTypeDef.size(); row++) {
				CollectionTypeDefTx colDef = newListCollectionTypeDef.get(row);

				outMap.put(newTableName, row, "COLLECTION_NAME", colDef.getCollectionType());
				outMap.put(newTableName, row, "ALLOW_AUTO_COLLECTION", colDef.isAllowAutoCollection());
				outMap.put(newTableName, row, "IS_APPEARANCE_PAYMENT_SCREEN", colDef.isIsAppearancePaymentScreen());

			}
			for (int row = 0; row < oldListCollectionTypeDef.size(); row++) {
				CollectionTypeDef colDef = oldListCollectionTypeDef.get(row);

				outMap.put(oldTableName, row, "COLLECTION_NAME", colDef.getCollectionType());
				outMap.put(oldTableName, row, "ALLOW_AUTO_COLLECTION", colDef.isAllowAutoCollection());
				outMap.put(oldTableName, row, "IS_APPEARANCE_PAYMENT_SCREEN", colDef.isIsAppearancePaymentScreen());
			}

			outMap.put("COLLECTION_TYPES_REL", BeanSetProperties.tableDifference((ArrayList<?>) outMap.get(oldTableName), (ArrayList<?>) outMap.get(newTableName), "COLLECTION_NAME").get("COLOR_DATA"));

			// REFERANS NUMARALARI YONETIMI FARKLAR
			List<SubscriberMaskDefTx> newListSubscribeMaskDef = (List<SubscriberMaskDefTx>) session.createCriteria(SubscriberMaskDefTx.class).add(Restrictions.eq("corporateOid", newCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			List<SubscriberMaskDef> oldListSubscribeMaskDef = (List<SubscriberMaskDef>) session.createCriteria(SubscriberMaskDef.class).add(Restrictions.eq("corporateOid", oldCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			newTableName = "NEW_SUBSCRIBER_DEFS";
			oldTableName = "OLD_SUBSCRIBER_DEFS";

			for (int row = 0; row < newListSubscribeMaskDef.size(); row++) {
				SubscriberMaskDefTx subsMaskDef = newListSubscribeMaskDef.get(row);

				SubscriberMaskDetailTx subscribeMaskDetail = (SubscriberMaskDetailTx) session.createCriteria(SubscriberMaskDetailTx.class).add(Restrictions.eq("maskOid", subsMaskDef.getOid())).add(Restrictions.eq("status", true)).uniqueResult();

				outMap.put(newTableName, row, "COLLECTION_NAME", subsMaskDef.getCollectionType());
				outMap.put(newTableName, row, "EXAMPLE", subscribeMaskDetail.getExample());
				outMap.put(newTableName, row, "LABEL", subscribeMaskDetail.getLabel());
				outMap.put(newTableName, row, "MASK", subscribeMaskDetail.getMask());
				outMap.put(newTableName, row, "PREFIX", subscribeMaskDetail.getPrefix());
				outMap.put(newTableName, row, "SUFFIX", subscribeMaskDetail.getSuffix());
				outMap.put(newTableName, row, "USE_FOR_INQUIRY", subscribeMaskDetail.getUseForInquiry());

			}
			for (int row = 0; row < oldListSubscribeMaskDef.size(); row++) {
				SubscriberMaskDef subsMaskDef = oldListSubscribeMaskDef.get(row);

				SubscriberMaskDetail subscribeMaskDetail = (SubscriberMaskDetail) session.createCriteria(SubscriberMaskDetail.class).add(Restrictions.eq("maskOid", subsMaskDef.getOid())).add(Restrictions.eq("status", true)).uniqueResult();

				outMap.put(oldTableName, row, "COLLECTION_NAME", subsMaskDef.getCollectionType());
				outMap.put(oldTableName, row, "EXAMPLE", subscribeMaskDetail.getExample());
				outMap.put(oldTableName, row, "LABEL", subscribeMaskDetail.getLabel());
				outMap.put(oldTableName, row, "MASK", subscribeMaskDetail.getMask());
				outMap.put(oldTableName, row, "PREFIX", subscribeMaskDetail.getPrefix());
				outMap.put(oldTableName, row, "SUFFIX", subscribeMaskDetail.getSuffix());
				outMap.put(oldTableName, row, "USE_FOR_INQUIRY", subscribeMaskDetail.getUseForInquiry());

			}

			outMap.put("SUBSCRIBER_MASK_DEFS_REL", BeanSetProperties.tableDifference((ArrayList<?>) outMap.get(oldTableName), (ArrayList<?>) outMap.get(newTableName), "COLLECTION_NAME").get("COLOR_DATA"));

			// HESAP YONETIMI FARKLAR
			List<CorporationAccountMasterTx> newListTemerkuzAccount = (List<CorporationAccountMasterTx>) session.createCriteria(CorporationAccountMasterTx.class).add(Restrictions.eq("corporateOid", newCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			List<CorporationAccountMaster> oldListTemerkuzAccount = (List<CorporationAccountMaster>) session.createCriteria(CorporationAccountMaster.class).add(Restrictions.eq("corporateOid", oldCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			newTableName = "NEW_CORP_ACCOUNTS";
			oldTableName = "OLD_CORP_ACCOUNTS";

			for (int row = 0; row < newListTemerkuzAccount.size(); row++) {
				CorporationAccountMasterTx corpAccount = newListTemerkuzAccount.get(row);

				Map<?, ?> propMaps = getCollectionTypeChannelSource(corpAccount.getOid(), session, AccountCollectionTypeRelTx.class);

				outMap.put(newTableName, row, "ACCOUNT_DEFINITION_NAME", corpAccount.getAccountDefinitionType());
				outMap.put(newTableName, row, "ACCOUNT_NAME", corpAccount.getAccountType());
				outMap.put(newTableName, row, "ACCOUNT_NUMBER", corpAccount.getAccountNumber());
				outMap.put(newTableName, row, "ACCOUNT_OWNER", corpAccount.getAccountOwner());
				outMap.put(newTableName, row, "CHANNEL_SOURCE_NAME", propMaps.get("CHANNEL_SOURCE_NAME"));
				outMap.put(newTableName, row, "COLLECTION_NAME", propMaps.get("COLLECTION_NAME"));
				outMap.put(newTableName, row, "DEFAULT_AMOUNT", corpAccount.getDefaultAmount());
				outMap.put(newTableName, row, "IBAN", corpAccount.getIban());

			}
			for (int row = 0; row < oldListTemerkuzAccount.size(); row++) {
				CorporationAccountMaster corpAccount = oldListTemerkuzAccount.get(row);

				Map<?, ?> propMaps = getCollectionTypeChannelSource(corpAccount.getOid(), session, AccountCollectionTypeRel.class);

				outMap.put(oldTableName, row, "ACCOUNT_DEFINITION_NAME", corpAccount.getAccountDefinitionType());
				outMap.put(oldTableName, row, "ACCOUNT_NAME", corpAccount.getAccountType());
				outMap.put(oldTableName, row, "ACCOUNT_NUMBER", corpAccount.getAccountNumber());
				outMap.put(oldTableName, row, "ACCOUNT_OWNER", corpAccount.getAccountOwner());
				outMap.put(oldTableName, row, "CHANNEL_SOURCE_NAME", propMaps.get("CHANNEL_SOURCE_NAME"));
				outMap.put(oldTableName, row, "COLLECTION_NAME", propMaps.get("COLLECTION_NAME"));
				outMap.put(oldTableName, row, "DEFAULT_AMOUNT", corpAccount.getDefaultAmount());
				outMap.put(oldTableName, row, "IBAN", corpAccount.getIban());

			}

			ArrayList<String> accountsKeyColumns = new ArrayList<String>();
			accountsKeyColumns.add("ACCOUNT_DEFINITION_NAME");
			accountsKeyColumns.add("CHANNEL_SOURCE_NAME");
			accountsKeyColumns.add("COLLECTION_NAME");

			outMap.put("CORPORATION_ACCOUNTS_REL", BeanSetProperties.tableDifference((ArrayList<?>) outMap.get(oldTableName), (ArrayList<?>) outMap.get(newTableName), accountsKeyColumns).get("COLOR_DATA"));

			// ILETISIM BILGILERI FARKLAR
			List<CorporateContactinfoTx> newListContactInfo = (List<CorporateContactinfoTx>) session.createCriteria(CorporateContactinfoTx.class).add(Restrictions.eq("corporateOid", newCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			List<CorporateContactinfo> oldListContactInfo = (List<CorporateContactinfo>) session.createCriteria(CorporateContactinfo.class).add(Restrictions.eq("corporateOid", oldCorporateTx.getCorporateOid())).add(Restrictions.eq("status", true)).list();

			newTableName = "NEW_CONTACT_INFOS";
			oldTableName = "OLD_CONTACT_INFOS";

			for (int row = 0; row < newListContactInfo.size(); row++) {
				CorporateContactinfoTx contactInfo = newListContactInfo.get(row);

				outMap.put(newTableName, row, "DEPARTMENT", contactInfo.getDepartment());
				outMap.put(newTableName, row, "EMAIL", contactInfo.getEmail());
				outMap.put(newTableName, row, "FAX", contactInfo.getFax());
				outMap.put(newTableName, row, "MOBILE", contactInfo.getMobile());
				outMap.put(newTableName, row, "NAME_SURNAME", contactInfo.getNameSurname());
				outMap.put(newTableName, row, "PHONE_NUMBER", contactInfo.getPhoneNumber());

			}
			for (int row = 0; row < oldListContactInfo.size(); row++) {
				CorporateContactinfo contactInfo = oldListContactInfo.get(row);

				// outMap.put(oldTableName, row, "DEPARTMENT", contactInfo.getdepartment());
				outMap.put(oldTableName, row, "EMAIL", contactInfo.getEmail());
				outMap.put(oldTableName, row, "FAX", contactInfo.getFax());
				outMap.put(oldTableName, row, "MOBILE", contactInfo.getMobile());
				outMap.put(oldTableName, row, "NAME_SURNAME", contactInfo.getNameSurname());
				outMap.put(oldTableName, row, "PHONE_NUMBER", contactInfo.getPhoneNumber());
			}

			outMap.put("CONTACT_INFO_REL", BeanSetProperties.tableDifference((ArrayList<?>) outMap.get(oldTableName), (ArrayList<?>) outMap.get(newTableName), "NAME_SURNAME").get("COLOR_DATA"));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}

	private static <T> Map<?, ?> getCollectionTypeChannelSource(String accountMasterOid, Session session, Class c) {
		Map<String, String> outMap = new HashMap<String, String>();

		@SuppressWarnings("unchecked")
		List<T> listColTypeRel = (List<T>) session.createCriteria(c).add(Restrictions.eq("accountMasterOid", accountMasterOid)).add(Restrictions.eq("status", true)).addOrder(Order.asc("collectionType")).addOrder(Order.asc("sourceCode")).addOrder(Order.asc("channelCode")).list();

		ArrayList<Short> collectionTypes = new ArrayList<Short>();
		ArrayList<String> sourceChannelList = new ArrayList<String>();

		for (T colTypeRel : listColTypeRel) {
			if (c == AccountCollectionTypeRelTx.class) {
				if (!collectionTypes.contains(((AccountCollectionTypeRelTx) colTypeRel).getCollectionType())) {
					collectionTypes.add(((AccountCollectionTypeRelTx) colTypeRel).getCollectionType());
				}

				String chSource = ((AccountCollectionTypeRelTx) colTypeRel).getSourceCode() + "<->" + ((AccountCollectionTypeRelTx) colTypeRel).getChannelCode();

				if (!sourceChannelList.contains(chSource)) {
					sourceChannelList.add(chSource);
				}
			} else if (c == AccountCollectionTypeRel.class) {
				if (!collectionTypes.contains(((AccountCollectionTypeRel) colTypeRel).getCollectionType())) {
					collectionTypes.add(((AccountCollectionTypeRel) colTypeRel).getCollectionType());
				}

				String chSource = ((AccountCollectionTypeRel) colTypeRel).getSourceCode() + "<->" + ((AccountCollectionTypeRel) colTypeRel).getChannelCode();

				if (!sourceChannelList.contains(chSource)) {
					sourceChannelList.add(chSource);
				}
			}

		}

		String stringList = sourceChannelList.toString();
		String stringOut = stringList.substring(1, stringList.length() - 1).replace(", ", ",");

		outMap.put("CHANNEL_SOURCE_NAME", stringOut);

		stringList = collectionTypes.toString();
		stringOut = stringList.substring(1, stringList.length() - 1).replace(", ", ",");

		outMap.put("COLLECTION_NAME", stringOut);

		return outMap;
	}

	@GraymoundService("CDM_GET_COLLECTION_TYPES")
	public static GMMap getSubscribeCollectionTypes(GMMap iMap) {
		GMMap returnMap = new GMMap();
		GMMap oMap = new GMMap();
		try {
			String TABLE_NAME = "COLLECTION_TYPES";
			returnMap = DALUtil.getResults(QueryRepository.CorporationServiceUtilRepository.COLLECTION_TYPES, TABLE_NAME);
			for (int row = 0; row < returnMap.getSize(TABLE_NAME); row++) {
				GuimlUtil.wrapMyCombo(oMap, TABLE_NAME, returnMap.getString(TABLE_NAME, row, "COLLECTION_TYPE"), returnMap.getString(TABLE_NAME, row, "COLLECTION_NAME"));
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("TCS_GET_TAX_TYPE")
	public static GMMap getTaxType(GMMap iMap) {

		GMMap oMap = new GMMap();
		List<TaxTypeCollectionType> taxTypes = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			taxTypes = (List<TaxTypeCollectionType>) session.createCriteria(TaxTypeCollectionType.class).add(Restrictions.eq("status", true)).addOrder(Order.asc("taxTypeCode")).list();

			if (taxTypes != null) {
				for (int row = 0; row <= taxTypes.size() - 1; row++) {
					TaxTypeCollectionType taxType = taxTypes.get(row);
					oMap.put("TAX_TYPES", row, "TAX_TYPE_CODE", taxType.getCollectionType());
					oMap.put("TAX_TYPES", row, "TAX_TYPE_NAME", taxType.getTaxTypeCode()+" - "+taxType.getTaxTypeName());
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("TCS_GET_SECTOR_TAX_DEFAULT_VALUE")
	public static GMMap getTaxGeneralValue(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
			oMap.put("TAX_DEFAULT_SECTOR_VALUE",DALUtil.getResult(String.format(QueryRepository.CorporationServiceUtilRepository.TAX_GENERAL_VALUE, iMap.getString("KOD"))));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	
	}
}