package tr.com.aktifbank.bnspr.cps.batch.implementations;

import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileBatchInformation;

public class OutgoingFileBatchFactory {

	private static final OutgoingFileBatchFactory instance = new OutgoingFileBatchFactory();
	
	public static OutgoingFileBatchFactory getInstance(){
		return instance;
	}
	
	private OutgoingFileBatchFactory() {
		
	}
	
	public OutgoingFileBatch createBatch(short factoryCommand, OutgoingFileBatchInformation information){
		if(factoryCommand == GeneralConstants.INFORM_COLLECTIONS){
			return new InformInvoiceCollectionFileBatch(information);
		}
		else if(factoryCommand == GeneralConstants.INFORM_STANDING_ORDERS){
			return new InformStandingOrdersFileBatch(information);
		}
		else if(factoryCommand == GeneralConstants.INFORM_STANDING_ORDERS_CANCEL){
			return new InformStandingOrdersCancelFileBatch(information);
		}
		else if(factoryCommand == GeneralConstants.INFORM_BULK_COLLECTIONS){
			return new InformBulkInvoiceCollectionFileBatch(information);
		}
		else if(factoryCommand == GeneralConstants.INFORM_COLLECTIONS_WITH_EXCEL){
			return new InformInvoiceCollectionExcelFileBatch(information);
		}
		else{
			return null;
		}
	}

}
