package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.FTSGetTotalStandingOrderCountHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public final class FTSGetTotalStandingOrderCountHandler extends RequestHandler {

	public FTSGetTotalStandingOrderCountHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Date processDate = input.getDate(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE);
		String dateString = CommonHelper.getShortDateTimeString(processDate);
		
		GMMap result = DALUtil.getResults(String.format(FTSGetTotalStandingOrderCountHandlerRepository.GET_COUNT_OF_STD_ORD_QUERY, 
				dateString, 
				input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE),
				DatabaseConstants.StandingOrderStatus.Active), "COUNT_TABLE");
		
		output.put(MapKeys.FTS_OUTPUT_DATA, result.getInt("COUNT_TABLE", 0, "TOTAL_COUNT"));
		
	}

}
