package tr.com.aktifbank.bnspr.cps.batch.implementations;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileBatchInformation;

public final class InformStandingOrdersCancelFileBatch extends InformStandingOrdersFileBatch {

	public InformStandingOrdersCancelFileBatch(
			OutgoingFileBatchInformation information) {
		super(information);
		standingOrderStatus = DatabaseConstants.StandingOrderStatus.Canelled;
	}

}
