package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchParameterEngine;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.BatchParameters;
import tr.com.aktifbank.bnspr.dao.BatchUsedParam;

import com.graymound.util.GMMap;

public class GetBatchParametersHandler extends RequestHandler {
	
	public GetBatchParametersHandler(){
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String batchProcessOid = input.getString(TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID);
		
		@SuppressWarnings("unchecked")
		List<BatchUsedParam> batchUsedParamResult = super.getHibernateSession().createCriteria(BatchUsedParam.class)
				.add(Restrictions.eq("batchProcessOid", batchProcessOid))
				.add(Restrictions.eq("status", true))
				.list();
		
		Map<String, String> parameterMap = new HashMap<String, String>();
		
		Boolean hasValue = batchUsedParamResult.size() > 0;
		
		for(BatchUsedParam item : batchUsedParamResult){
			String batchParameterOid = item.getBatchParamOid();
			BatchParameters batchParameterResult = (BatchParameters)super.getHibernateSession()
					.createCriteria(BatchParameters.class)
					.add(Restrictions.eq("oid", batchParameterOid))
					.uniqueResult();
	    	if (batchParameterResult != null) {
				parameterMap.put(batchParameterResult.getParamKey(),
						batchParameterResult.getParamKeyValue());
			}
		}
		
		if (hasValue) {
			BatchParameterEngine engine = new BatchParameterEngine(parameterMap);
			output.put(
					TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS,
					engine.getComposedParameters());
		}
	}

}
