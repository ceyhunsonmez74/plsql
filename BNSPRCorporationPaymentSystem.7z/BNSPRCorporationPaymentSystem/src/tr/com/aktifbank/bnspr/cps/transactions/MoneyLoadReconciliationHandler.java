package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationResubmitType;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationStatus;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.ReconciliationTypes;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;

import com.graymound.util.GMMap;

public class MoneyLoadReconciliationHandler extends ParallelRequestHandler {
	

	private static final class BagKeys {
		public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
		public static final String CORPORATE_CODE = "CORPORATE_CODE";
		public static final String SCREEN_RECON = "SCREEN_RECON";
		public static final String RESUBMIT_TYPE ="RESUBMIT_TYPE";
		public static final String RECON_DATE = "RECON_DATE";
		public static final String RECON_TIME = "RECON_TIME";
		public static final String BATCH_NAME = "BATCH_NAME";
		public static final String RECON_LOG_OID = "RECON_LOG_OID";
		public static final String PROCESS_DATE = "PROCESS_DATE";
	}

	public MoneyLoadReconciliationHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		GMMap reconLogInsert=new GMMap();
		GMMap reconLogOutput=new GMMap();
		String batchSubmitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		bag.put(BagKeys.BATCH_SUBMIT_ID, batchSubmitId);
		String corporateCode =  input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE);
		bag.put(BagKeys.CORPORATE_CODE, corporateCode);
		String batchName = input.getString(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME);
		bag.put(BagKeys.BATCH_NAME, batchName);
		String batchServiceName = "ICS_MONEY_LOAD_RECONCILIATION";
		String ftmId = "";
		String formatId = "";
		
		String screenReconciliation = input.getString("SCREEN_RECONCILIATION","0");
		bag.put(BagKeys.SCREEN_RECON, screenReconciliation);
		String resubmitType = (input.containsKey(StandingOrderReconciliationBatch.Input.RESUBMIT_TYPE) ? input
				.getString(StandingOrderReconciliationBatch.Input.RESUBMIT_TYPE) : ReconciliationResubmitType.ReconciliationClose); //2 GÜNSONU
		bag.put(BagKeys.RESUBMIT_TYPE, resubmitType);
		

		String reconDate = "";
		String processDate = CommonHelper.getShortDateTimeString(new Date());
		bag.put(BagKeys.PROCESS_DATE, processDate);
		String reconTime = CommonHelper.getStringTimeNow();
		if (input.getString(TransactionConstants.MoneyLoadReconciliationBatch.Input.RECON_DATE) != null) {
				reconDate = input.getString(TransactionConstants.MoneyLoadReconciliationBatch.Input.RECON_DATE);	
		} else {
				reconDate = CommonHelper.getShortDateTimeString(CommonHelper.addDay(new Date(),-1));
		}
		
		bag.put(BagKeys.RECON_DATE, reconDate);
		bag.put(BagKeys.RECON_TIME, reconTime);
		
		reconLogInsert.put(TransactionConstants.ReconLogInsert.Input.RECON_STATUS, ReconciliationStatus.Started);
		reconLogInsert.put(TransactionConstants.ReconLogInsert.Input.RECON_TYPE, ReconciliationTypes.MoneyLoad);
		reconLogInsert.put(TransactionConstants.ReconLogInsert.Input.CORPORATE_CODE, corporateCode);
		reconLogInsert.put(TransactionConstants.ReconLogUpdate.Input.RECON_DATE, reconDate);
		reconLogInsert.put(TransactionConstants.ReconLogUpdate.Input.RECON_TIME, reconTime);
		reconLogInsert.put(TransactionConstants.ReconLogUpdate.Input.SUB_TYPE, resubmitType);
		reconLogOutput = super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_INSERT", reconLogInsert);
		String reconLogOid=reconLogOutput.getString(TransactionConstants.ReconLogInsert.Output.RECON_LOG_OID);
		bag.put(BagKeys.RECON_LOG_OID, reconLogOid);
		
		if (screenReconciliation.equals("1")) {
			
			if (resubmitType.equals(ReconciliationResubmitType.ReconciliationClose)) {
				
				GMMap reconClosedOutMap;
				try {
					reconClosedOutMap = closeReconciliation(DatabaseConstants.ReconciliationStatus.ReconciliationSucceeded, true);
				} catch (Exception e) {
					logger.error("An exception occured while closing reconciliation");
					logger.error(System.currentTimeMillis(), e);
					reconClosedOutMap = new GMMap();
					reconClosedOutMap.put(MapKeys.ERROR_CODE, "-1");
					reconClosedOutMap.put(MapKeys.ERROR_DESC, "Mutabakat kapamada sistemsel bir hata olu�tu : " + e.getMessage());
				}
				
				updateReconLog(reconClosedOutMap);
				
			}else {
				boolean reconFailed = false;
				GMMap reconOutMap;
				try {
					reconOutMap = doReconciliation();
				} catch (Exception e) {
					logger.error("An exception occured while doing reconciliation");
					logger.error(System.currentTimeMillis(), e);
					reconFailed = true;
					reconOutMap = new GMMap();
					reconOutMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
					reconOutMap.put(MapKeys.ERROR_CODE, "-2");
					reconOutMap.put(MapKeys.ERROR_DESC, "Mutabakat yap�l�rken sistemsel bir hata olu�tu : " + e.getMessage());
				}

				if (!reconFailed && reconOutMap.getString(MapKeys.RECON_STATUS).equals(ReconciliationStatus.ReconciliationFailed)) {
					boolean detailFailed = false;
					
					try {
						doReconciliationDetail(reconOutMap, ReconciliationStatus.ReconciliationFailed);
					} catch (Exception e) {
						logger.error("An exception occured while doing reconciliation detail");
						logger.error(System.currentTimeMillis(), e);
						detailFailed = true;
						reconOutMap = new GMMap();
						reconOutMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						reconOutMap.put(MapKeys.ERROR_CODE, "-3");
						reconOutMap.put(MapKeys.ERROR_DESC, "Mutabakat detay yap�l�rken sistemsel bir hata olu�tu : " + e.getMessage());
					}
					
					if(!detailFailed){
						try {
							reconOutMap = doReconciliation();
						} catch (Exception e) {
							logger.error("An exception occured while doing reconciliation");
							logger.error(System.currentTimeMillis(), e);
							reconOutMap = new GMMap();
							reconOutMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
							reconOutMap.put(MapKeys.ERROR_CODE, "-2");
							reconOutMap.put(MapKeys.ERROR_DESC, "Mutabakat yap�l�rken sistemsel bir hata olu�tu : " + e.getMessage());
						}
					}
					
					updateReconLog(reconOutMap);

				}else {
					updateReconLog(reconOutMap);
				}
				
			}
		}else {
			CommonBusinessOperations.insertBatchSubmitLog(corporateCode, batchName, ftmId, formatId, batchSubmitId, batchServiceName, input);
			
			boolean reconFailed = false;
			
			GMMap reconOutMap;
			try {
				reconOutMap = doReconciliation();
			} catch (Exception e) {
				logger.error("An exception occured while doing reconciliation");
				logger.error(System.currentTimeMillis(), e);
				reconFailed = true;
				reconOutMap = new GMMap();
				reconOutMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
				reconOutMap.put(MapKeys.ERROR_CODE, "-2");
				reconOutMap.put(MapKeys.ERROR_DESC, "Mutabakat yap�l�rken sistemsel bir hata olu�tu : " + e.getMessage());
			}
			
			if(reconFailed){
				updateReconLog(reconOutMap);
			}
			else{
				if (reconOutMap.getString(MapKeys.RECON_STATUS).equals(ReconciliationStatus.ReconciliationSucceeded)) {

					try {
						closeReconciliation(ReconciliationStatus.ReconciliationSucceeded, false);
					} catch (Exception e) {
						logger.error("An exception occured while closing reconciliation");
						logger.error(System.currentTimeMillis(), e);
						reconOutMap = new GMMap();
						reconOutMap.put(MapKeys.ERROR_CODE, "-1");
						reconOutMap.put(MapKeys.ERROR_DESC, "Mutabakat kapamada sistemsel bir hata olu�tu : " + e.getMessage());
					}
					
					updateReconLog(reconOutMap);

				} else {
					boolean detailFailed = false;
					try {
						doReconciliationDetail(reconOutMap, ReconciliationStatus.ReconciliationFailed);
					} catch (Exception e) {
						logger.error("An exception occured while doing reconciliation detail");
						logger.error(System.currentTimeMillis(), e);
						detailFailed = true;
						reconOutMap = new GMMap();
						reconOutMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
						reconOutMap.put(MapKeys.ERROR_CODE, "-3");
						reconOutMap.put(MapKeys.ERROR_DESC, "Mutabakat detay yap�l�rken sistemsel bir hata olu�tu : " + e.getMessage());
					}
					
					if(!detailFailed){
						try {
							reconOutMap = doReconciliation();
						} catch (Exception e) {
							logger.error("An exception occured while doing reconciliation");
							logger.error(System.currentTimeMillis(), e);
							reconOutMap = new GMMap();
							reconOutMap.put(MapKeys.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
							reconOutMap.put(MapKeys.ERROR_CODE, "-2");
							reconOutMap.put(MapKeys.ERROR_DESC, "Mutabakat yap�l�rken sistemsel bir hata olu�tu : " + e.getMessage());
						}
						
						if (reconOutMap.getString(MapKeys.RECON_STATUS).equals(ReconciliationStatus.ReconciliationSucceeded)) {
							closeReconciliation(ReconciliationStatus.ReconciliationSucceeded, false);
						}
					}
					
					updateReconLog(reconOutMap);
				}
			}
			
			CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId, DatabaseConstants.SubmitStatuses.SUCESSFUL, new Date(), null, null);
		}	
	}
	
	private GMMap doReconciliationDetail(GMMap reconOutMap, String reconStatus) throws Exception {
		GMMap reconInMap = new GMMap();
		reconInMap.put("SCREEN_RECONCILIATION", "1");
		reconInMap.put(MapKeys.CORPORATE_CODE, bag.get(BagKeys.CORPORATE_CODE));
		reconInMap.put(MapKeys.RECON_DATE, bag.get(BagKeys.RECON_DATE));
		reconInMap.put(MapKeys.PROCESS_DATE, bag.get(BagKeys.PROCESS_DATE));
		reconInMap.put(MapKeys.RECON_STATUS, reconStatus);
		reconInMap.put(MapKeys.RECON_BANK_COUNT, reconOutMap.get("BANK",0,MapKeys.RECON_COLLECTION_COUNT) );
		reconInMap.put(MapKeys.RECON_COLLECTION_TOTAL, reconOutMap.get("BANK",0,MapKeys.RECON_COLLECTION_TOTAL));
		reconInMap.put(MapKeys.RECON_CORPORATE_TOTAL, reconOutMap.get("CORPORATE",0,MapKeys.RECON_COLLECTION_TOTAL));
		reconInMap.put(MapKeys.RECON_CORPORATE_COUNT, reconOutMap.get("CORPORATE",0,MapKeys.RECON_COLLECTION_COUNT));
		reconInMap.put(MapKeys.RECON_CORPORATE_CANCEL_TOTAL, reconOutMap.get("CORPORATE",0,MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
		reconInMap.put(MapKeys.RECON_CORPORATE_CANCEL_COUNT, reconOutMap.get("CORPORATE",0,MapKeys.RECON_COLLECTION_CANCEL_COUNT));
		reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
		reconInMap.put(MapKeys.RECON_LOG_OID, bag.get(BagKeys.RECON_LOG_OID));
		reconInMap.put(MapKeys.GM_SERVICE_NAME, "ICS_MONEY_LOAD_RECONCILIATION_DETAIL");
		reconInMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
		return CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", reconInMap);
	}
	
	private GMMap doReconciliation() throws Exception {
		GMMap reconInMap = new GMMap();
		if("1".equals((String)bag.get(BagKeys.SCREEN_RECON))){
			reconInMap.put("SCREEN_RECONCILIATION", "1");	
		}
		reconInMap.put(MapKeys.RECON_DATE, bag.get(BagKeys.RECON_DATE));
		reconInMap.put(MapKeys.CORPORATE_CODE, bag.get(BagKeys.CORPORATE_CODE));
		reconInMap.put(MapKeys.PROCESS_DATE, bag.get(BagKeys.PROCESS_DATE));
		reconInMap.put(MapKeys.GM_SERVICE_NAME, "ICS_MONEY_LOAD_RECONCILIATION");
		reconInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
		reconInMap.put("RETURN_SERVICE_MAP", true);
		reconInMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
		return CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", reconInMap);
	}
	
	private GMMap closeReconciliation(String reconStatus, boolean returnServiceMap) throws Exception{
		GMMap cMap = new GMMap();
		
		if("1".equals((String)bag.get(BagKeys.SCREEN_RECON))){
			cMap.put("SCREEN_RECONCILIATION", "1");
		}
		cMap.put(MapKeys.CORPORATE_CODE, bag.get(BagKeys.CORPORATE_CODE));
		cMap.put(MapKeys.RECON_DATE, bag.get(BagKeys.RECON_DATE));
		cMap.put(MapKeys.PROCESS_DATE, bag.get(BagKeys.PROCESS_DATE));
		cMap.put(MapKeys.RECON_STATUS, reconStatus);
		cMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
		if(returnServiceMap){
			cMap.put("RETURN_SERVICE_MAP", true);
		}
		cMap.put(MapKeys.GM_SERVICE_NAME, "ICS_MONEY_LOAD_RECONCILIATION_CLOSED");
		cMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
		return CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", cMap);
	}
	
	
	private GMMap updateReconLog(GMMap reconOutMap) throws Exception {
		GMMap reconLogUpdate = new GMMap();
		if (reconOutMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
			reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, ReconciliationStatus.ReconciliationSucceeded);	
		}else {
			reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS, ReconciliationStatus.ReconciliationFailed);
			reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.ERROR_CODE, reconOutMap.getString(MapKeys.ERROR_CODE));
			reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.ERROR_DESC, reconOutMap.getString(MapKeys.ERROR_DESC));						
		}				
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID, bag.get(BagKeys.RECON_LOG_OID));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.BANK_AMOUNT, reconOutMap.getString("BANK",0,MapKeys.RECON_COLLECTION_TOTAL));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_AMOUNT, reconOutMap.getString("BANK",0,MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_AMOUNT, reconOutMap.getString("CORPORATE",0,MapKeys.RECON_COLLECTION_TOTAL));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_AMOUNT, reconOutMap.getString("CORPORATE",0,MapKeys.RECON_COLLECTION_CANCEL_TOTAL));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.PROCESS_DATE, bag.get(BagKeys.PROCESS_DATE));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.PROCESS_TIME,  CommonHelper.getStringTimeNow());
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_DATE, bag.get(BagKeys.RECON_DATE));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_TIME, bag.get(BagKeys.RECON_TIME));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CODE, bag.get(BagKeys.CORPORATE_CODE));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT, reconOutMap.get("BANK",0,MapKeys.RECON_COLLECTION_COUNT));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT, reconOutMap.get("CORPORATE",0,MapKeys.RECON_COLLECTION_COUNT));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT, reconOutMap.get("CORPORATE",0,MapKeys.RECON_COLLECTION_CANCEL_COUNT));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT, reconOutMap.get("BANK",0,MapKeys.RECON_COLLECTION_CANCEL_COUNT));
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.RECON_TYPE, DatabaseConstants.ReconciliationTypes.MoneyLoad);
		reconLogUpdate.put(TransactionConstants.ReconLogUpdate.Input.SUB_TYPE, bag.get(BagKeys.RESUBMIT_TYPE));
		
		return super.callGraymoundServiceOutsideSession("ICS_RECON_LOG_UPDATE", reconLogUpdate);	
	}
	

	@Override
	protected void handleError(Throwable e, GMMap output) {
		Long errorId = System.currentTimeMillis();
		logger.error("System exception is occured updating batch submit log");
		logger.error(errorId, e);
		if ("0".equals((String)bag.get(BagKeys.SCREEN_RECON))) {
			CommonBusinessOperations.updateBatchSubmitLog(
					(String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
					DatabaseConstants.SubmitStatuses.FAILURE, new Date(), "0",
					e.toString());
		}
	}

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		Long errorId = System.currentTimeMillis();
		logger.error("Business exception is occured. Updating batch submit log");
		logger.error(errorId, e);
		if ("0".equals((String)bag.get(BagKeys.SCREEN_RECON))) {
			CommonBusinessOperations.updateBatchSubmitLog(
					(String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
					DatabaseConstants.SubmitStatuses.FAILURE, new Date(),
					String.valueOf(e.getCode()), e.toString());
		}
	}

}
