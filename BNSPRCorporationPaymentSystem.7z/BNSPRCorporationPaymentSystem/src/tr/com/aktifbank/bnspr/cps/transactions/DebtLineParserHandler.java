package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cps.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cps.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.dao.FileErrorLog;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class DebtLineParserHandler extends ParallelRequestHandler {
	
	
	private static final int SUCCESSFUL_INSERT = 0;
	
	public DebtLineParserHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.DebtLineParser.Input.CORPORATE_CODE);
		BigDecimal ftmTransferId = input.getBigDecimal(TransactionConstants.DebtLineParser.Input.FTM_TRANSFER_ID);
		String ftmId = input.getString(TransactionConstants.DebtLineParser.Input.FTM_ID);
		String batchSubmitId = input.getString(TransactionConstants.DebtLineParser.Input.BATCH_SUBMIT_ID);
		int startLineNumber = input.getInt(TransactionConstants.DebtLineParser.Input.START_LINE_NUMBER);
		int endLineNumber = input.getInt(TransactionConstants.DebtLineParser.Input.END_LINE_NUMBER);
		GMMap databaseFieldMaps = input.getMap(TransactionConstants.DebtLineParser.Input.DATABASE_FIELD_MAPS);
		GMMap serviceFieldMaps = input.getMap(TransactionConstants.DebtLineParser.Input.SERVICE_FIELD_MAPS);
		List<FormatDetail> headerFormatDetails = (List<FormatDetail>)input.get(TransactionConstants.DebtLineParser.Input.HEADER_FORMAT_DETAILS);
		List<FormatDetail> detailFormatDetails = (List<FormatDetail>)input.get(TransactionConstants.DebtLineParser.Input.DETAIL_FORMAT_DETAILS);
		List<FormatDetail> footerFormatDetails = (List<FormatDetail>)input.get(TransactionConstants.DebtLineParser.Input.FOOTER_FORMAT_DETAILS);
		int commitCount = input.getInt(TransactionConstants.DebtLineParser.Input.COMMIT_COUNT);
		int errorThreshold = input.getInt(TransactionConstants.DebtLineParser.Input.ERROR_THRESHOLD);
		String serviceName = input.getString(TransactionConstants.DebtLineParser.Input.SERVICE_NAME);
		int controlLoopCount = input.getInt(TransactionConstants.DebtLineParser.Input.CONTROL_LOOP_COUNT);
		boolean controlInvoiceNo = input.getBoolean(TransactionConstants.DebtLineParser.Input.CONTROL_INVOICE_NO);
		boolean loadOnlyWithStandingOrder = input.getBoolean(TransactionConstants.DebtLineParser.Input.LOAD_ONLY_WITH_STANDING_ORDER);
		boolean controlInvoiceDueDate = input.getBoolean(TransactionConstants.DebtLineParser.Input.CONTROL_INVOICE_DUE_DATE);
		int controlCounter = 1;
		boolean footerAmountControl = false;
		boolean footerLineCountControl = false;
		boolean isInsertStep = false;
		BigDecimal footerTotalAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		int footerTotalLineCount = 0;
		int processedLineCount = 0;
		int failedLineCount = 0;
		boolean exceptionOccured = false;
		String exception = "";
		BigDecimal processedAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		int totalNotInsertedLineCount = 0;
		BigDecimal totalNotInsertedAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		
		String headerConstant = null;
		String footerConstant = null;
		String bodyConstant = null;
		if(headerFormatDetails.size() > 0){
			headerConstant = headerFormatDetails.get(0).getInitialConstant();
		}
		if(footerFormatDetails.size() > 0){
			footerConstant = footerFormatDetails.get(0).getInitialConstant();
		}
		if(detailFormatDetails.size() > 0){
			bodyConstant = detailFormatDetails.get(0).getInitialConstant();
		}
		
		List<FtmFileContent> lines = getDebtLines(ftmTransferId, startLineNumber, endLineNumber);
		
		List<GMMap> serviceMaps = new ArrayList<GMMap>();
		
		for(FtmFileContent content : lines){
			BigDecimal tempAmount = null;
			try {
				if(controlCounter++ % controlLoopCount == 0){
					failedLineCount = getFailedLineCount(batchSubmitId, ftmId, ftmTransferId);
					if(failedLineCount >= errorThreshold){
						exceptionOccured = true;
						break;
					}
				}
				if(content.getLine() == null || StringUtil.isEmpty(content.getLine().trim())){
					continue;
				}
				Boolean footerLine = false;
				if(!StringUtil.isEmpty(footerConstant)){
					footerLine = content.getLine().startsWith(footerConstant);
				}
				Boolean headerLine = false;
				if(!StringUtil.isEmpty(headerConstant)){
					headerLine = content.getLine().startsWith(headerConstant);
				}
				Boolean bodyLine = false;
				if(!StringUtil.isEmpty(bodyConstant)){
					bodyLine = content.getLine().startsWith(bodyConstant);
				}
				
				if(!headerLine && !footerLine && !bodyLine){
					continue;
				}
				
				if (bodyLine) {
					processedLineCount++;
				}
				
				if (headerLine) {
					
				} else {
					List<FormatDetail> formatDetails = bodyLine ? detailFormatDetails : footerFormatDetails;
					GMMap serviceMap = new GMMap();
					for (FormatDetail detail : formatDetails) {
						int startIndex = detail.getStartIndis().intValue();
						int length = detail.getLength().intValue();
						int substringStart = startIndex - 1;
						int substringEnd = startIndex - 1 + length;
						if(content.getLine().length() < substringEnd){
							throw new Exception(String.format("S�ra numaras� %s olan desen tan�m�n�n biti� indexi %s, %s uzunlu�undaki sat�r� a�maktad�r.", 
									detail.getLineNumber().intValue(), substringEnd, content.getLine().length()));
						}
						String currentLine = content.getLine().substring(substringStart, substringEnd);
						String fieldType = detail.getDataType();
						String format = detail.getDataPattern();
						String constant = detail.getConstant();
						String source = detail.getDatasourceType();
						if(detail.getTrimEmptyCharacters() != null && detail.getTrimEmptyCharacters()){
							currentLine = currentLine.trim();
							StringBuilder buffer = new StringBuilder();
							
							while( currentLine.indexOf(" ") > 0 ){
								String temp = currentLine;
								
								int beginEmptyIndex = currentLine.indexOf(" ");
								currentLine= currentLine.substring(0, beginEmptyIndex).trim();
								
								buffer.append(currentLine+" " );
								
								currentLine = temp.substring(beginEmptyIndex).trim();	
							}
							buffer.append(currentLine);
							currentLine = buffer.toString();
						}
						ItemDatabaseField databaseFieldInformation = (ItemDatabaseField) databaseFieldMaps.get(detail.getDatasourceReference());
						Object parsedData;
						try {
							parsedData = getObject(currentLine, fieldType, format, constant);
						}
						catch (BatchComponentException e) {
							throw e;
						}
						catch (Exception e) {
							logger.error(String.format("An exception occured while parsing data from %s, with format code %s, start index %s, length %s, type %s, constant %s",
									currentLine, format, startIndex, length, fieldType, constant));
							logger.error(System.currentTimeMillis(), e);
							throw new Exception(String.format("Sat�rdaki %s alan�ndan veriyi parse ederken bir hata olu�tu. Format kodu %s, ba�lang�� index'i: %s, " +
									"uzunlu�u %s, tipi %s, sabiti %s, hata : %s",
									currentLine, format, startIndex, length, fieldType, constant, CommonHelper.getStringifiedException(e)));
						}
						
						if(source.equals(DatabaseConstants.DataSourceTypes.DatabaseAndService)){
							parsedData = this.callServiceWithData(parsedData, (ItemServiceField)serviceFieldMaps.get(detail.getDatasourceReference2()), input);
						}
						
						if (bodyLine) {
							setDataToField(serviceMap, databaseFieldInformation, parsedData);
							if (fieldType.equals(DatabaseConstants.FieldType.Amount)) {
								tempAmount = new BigDecimal(((Number) parsedData).doubleValue());
								processedAmount = processedAmount.add(tempAmount).setScale(2, RoundingMode.HALF_UP);
							}
						}
						else{
							if(!fieldType.equals(DatabaseConstants.FieldType.Constant)){
								if(databaseFieldInformation.getDbField().equals(DatabaseConstants.FooterIndicators.TOTAL_AMOUNT)){
									footerAmountControl = true;
									footerTotalAmount = new BigDecimal(((Number)parsedData).doubleValue()).setScale(2, RoundingMode.HALF_UP);
								}
								else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.FooterIndicators.TOTAL_RECORD_COUNT)){
									footerLineCountControl = true;
									footerTotalLineCount = ((Number)parsedData).intValue();
								}
								else{
									// TODO
								}
							}
						}
					}
					if (bodyLine && !exceptionOccured) {
						serviceMaps.add(serviceMap);
					}
					if (bodyLine && !exceptionOccured && serviceMaps.size() % commitCount == 0) {
						try {
							isInsertStep = true;
							GMMap insertInvoicesRequest = new GMMap();
							insertInvoicesRequest.put(TransactionConstants.CORPORATE_CODE_GENERAL_KEY, corporateCode);
							insertInvoicesRequest.put(TransactionConstants.DIRECT_INSERT_GENERAL_KEY, true);
							insertInvoicesRequest.put(TransactionConstants.FTM_TRANSFER_ID_GENERAL_KEY, ftmTransferId);
							insertInvoicesRequest.put(TransactionConstants.SUBMIT_ID__GENERAL_KEY, batchSubmitId);
							insertInvoicesRequest.put(TransactionConstants.CONTROL_INVOICE_NO_GENERAL_KEY, controlInvoiceNo);
							insertInvoicesRequest.put(TransactionConstants.CONTROL_INVOICE_DUE_DATE_GENERAL_KEY, controlInvoiceDueDate);
							insertInvoicesRequest.put(TransactionConstants.LOAD_ONLY_WITH_STANDING_ORDER_GENERAL_KEY, loadOnlyWithStandingOrder);
							int submitMapCounter = 0;
							for (GMMap submitMap : serviceMaps) {
								insertInvoicesRequest.put(TransactionConstants.INSERT_PAIR_TABLE_GENERAL_KEY, submitMapCounter++,
										TransactionConstants.INSERT_KEYVALUE_PAIRS_GENERAL_KEY, submitMap);
							}
							GMMap insertInvoiceOutput = super.callGraymoundServiceOutsideSession(serviceName, insertInvoicesRequest);
							if(insertInvoiceOutput.getInt(TransactionConstants.RETURN_CODE_GENERAL_KEY) == SUCCESSFUL_INSERT){
								int notInsertedCount = insertInvoiceOutput.getInt("NOT_INSERTED_COUNT", 0);
								BigDecimal notInsertedAmount = insertInvoiceOutput.getBigDecimal("NOT_INSERTED_AMOUNT", new BigDecimal(0));
								totalNotInsertedLineCount += notInsertedCount;
								totalNotInsertedAmount = totalNotInsertedAmount.add(notInsertedAmount);
								isInsertStep = false;
							}
							else{
								throw new Exception(insertInvoiceOutput.getString(TransactionConstants.RETURN_MESSAGE_GENERAL_KEY));
							}
						} catch (Exception e) {
							logger.error("An exception occured while inserting invoice main records");
							logger.error(System.currentTimeMillis(), e);
							throw new Exception(String.format("Fatura kay�tlar� veritaban�na eklenirken bir hata olu�tu. Hata %s, kay�t ekleme istekleri %s",
									CommonHelper.getStringifiedException(e), getStringifiedMap(serviceMaps)));
						}
						finally{
							serviceMaps.clear();
						}
					}
				}
			} catch (Exception e) {
				exceptionOccured = true;
				if(isInsertStep){
					exception = CommonHelper.getStringifiedException(e);
					insertFileErrorLog(batchSubmitId, ftmId, ftmTransferId, new BigDecimal(-1), "", "0", CommonHelper.getStringifiedException(e));
					break;
				}
				else{
					logger.error(String.format("An exception occured while parsing line : %s", content.getLine()));
					logger.error(System.currentTimeMillis(), e);
					insertFileErrorLog(batchSubmitId, ftmId, ftmTransferId, content.getLineNumber(), content.getLine(), "0", CommonHelper.getStringifiedException(e));
					totalNotInsertedLineCount++;
					if(tempAmount != null){
						totalNotInsertedAmount = totalNotInsertedAmount.add(tempAmount);
					}
					failedLineCount = getFailedLineCount(batchSubmitId, ftmId, ftmTransferId);
					if(failedLineCount >= errorThreshold){
						exception = CommonHelper.getStringifiedException(e);
						break;
					}
				}
			}
		}
		
		if(!exceptionOccured && serviceMaps.size() > 0){
			try {
				GMMap insertInvoicesRequest = new GMMap();
				insertInvoicesRequest.put(TransactionConstants.CORPORATE_CODE_GENERAL_KEY, corporateCode);
				insertInvoicesRequest.put(TransactionConstants.DIRECT_INSERT_GENERAL_KEY, true);
				insertInvoicesRequest.put(TransactionConstants.FTM_TRANSFER_ID_GENERAL_KEY, ftmTransferId);
				insertInvoicesRequest.put(TransactionConstants.SUBMIT_ID__GENERAL_KEY, batchSubmitId);
				insertInvoicesRequest.put(TransactionConstants.CONTROL_INVOICE_NO_GENERAL_KEY, controlInvoiceNo);
				insertInvoicesRequest.put(TransactionConstants.CONTROL_INVOICE_DUE_DATE_GENERAL_KEY, controlInvoiceDueDate);
				insertInvoicesRequest.put(TransactionConstants.LOAD_ONLY_WITH_STANDING_ORDER_GENERAL_KEY, loadOnlyWithStandingOrder);
				int submitMapCounter = 0;
				for (GMMap submitMap : serviceMaps) {
					insertInvoicesRequest.put(TransactionConstants.INSERT_PAIR_TABLE_GENERAL_KEY, submitMapCounter++,
							TransactionConstants.INSERT_KEYVALUE_PAIRS_GENERAL_KEY, submitMap);
				}
				GMMap insertInvoiceOutput = super.callGraymoundServiceOutsideSession(serviceName, insertInvoicesRequest);
				if(insertInvoiceOutput.getInt(TransactionConstants.RETURN_CODE_GENERAL_KEY) == SUCCESSFUL_INSERT){
					int notInsertedCount = insertInvoiceOutput.getInt("NOT_INSERTED_COUNT", 0);
					BigDecimal notInsertedAmount = insertInvoiceOutput.getBigDecimal("NOT_INSERTED_AMOUNT", new BigDecimal(0));
					totalNotInsertedLineCount += notInsertedCount;
					totalNotInsertedAmount = totalNotInsertedAmount.add(notInsertedAmount);
				}
				else{
					throw new Exception(insertInvoiceOutput.getString(TransactionConstants.RETURN_MESSAGE_GENERAL_KEY));
				}
			} catch (Exception e) {
				logger.error("An exception occured while inserting invoice main records");
				logger.error(System.currentTimeMillis(), e);
				insertFileErrorLog(batchSubmitId, ftmId, ftmTransferId, new BigDecimal(-1), "", "0", CommonHelper.getStringifiedException(e));
				exceptionOccured = true;
				exception = "Fatura kay�tlar� veritaban�na eklenirken bir hata olu�tu : " + e.toString();
			}
			finally{
				serviceMaps.clear();
			}
		}
		
		if(!exceptionOccured){
			output.put(TransactionConstants.DebtLineParser.Output.ISSUCCESSFUL, true);
			output.put(TransactionConstants.DebtLineParser.Output.PROCESSED_AMOUNT, processedAmount);
			output.put(TransactionConstants.DebtLineParser.Output.PROCESSED_LINE_COUNT, processedLineCount);
			output.put("NOT_INSERTED_COUNT", totalNotInsertedLineCount);
			output.put("NOT_INSERTED_AMOUNT", totalNotInsertedAmount);
			if(footerAmountControl){
				output.put(TransactionConstants.DebtLineParser.Output.FOOTER_AMOUNT, footerTotalAmount);
			}
			if(footerLineCountControl){
				output.put(TransactionConstants.DebtLineParser.Output.FOOTER_LINE_COUNT, footerTotalLineCount);
			}
		}
		else{
			output.put(TransactionConstants.DebtLineParser.Output.ISSUCCESSFUL, false);
			if(failedLineCount == errorThreshold){
				output.put(TransactionConstants.DebtLineParser.Output.ERROR_CODE, "0");
				output.put(TransactionConstants.DebtLineParser.Output.ERROR_MESSAGE, "Error threshold exceeded");
			}
			else{
				output.put(TransactionConstants.DebtLineParser.Output.ERROR_CODE, "0");
				output.put(TransactionConstants.DebtLineParser.Output.ERROR_MESSAGE, exception);
			}
			
			output.put(TransactionConstants.DebtLineParser.Output.PROCESSED_AMOUNT, processedAmount);
			output.put(TransactionConstants.DebtLineParser.Output.PROCESSED_LINE_COUNT, processedLineCount);
			output.put("NOT_INSERTED_COUNT", totalNotInsertedLineCount);
			output.put("NOT_INSERTED_AMOUNT", totalNotInsertedAmount);
			if(footerAmountControl){
				output.put(TransactionConstants.DebtLineParser.Output.FOOTER_AMOUNT, footerTotalAmount);
			}
			if(footerLineCountControl){
				output.put(TransactionConstants.DebtLineParser.Output.FOOTER_LINE_COUNT, footerTotalLineCount);
			}
		}
	}
	
	private Object callServiceWithData(Object parsedData,
			ItemServiceField itemServiceField, GMMap input) {
		GMMap serviceMap = new GMMap();
		serviceMap.put("CURRENT_ROW", input);
		serviceMap.put("PARAMETER", parsedData);
		return super.callGraymoundServiceOutsideSession(itemServiceField.getServiceName(), serviceMap).get(MapKeys.FTS_OUTPUT_DATA);
	}

	private Object getStringifiedMap(List<GMMap> serviceMaps) {
		StringBuilder builder = new StringBuilder();
		
		for (GMMap map : serviceMaps) {
			builder.append(map.toString());
		}
		
		return builder.toString();
	}

	private int getFailedLineCount(String batchSubmitId, String ftmId,
			BigDecimal ftmTransferId) {
		return ((Number)super.getHibernateSession()
				.createCriteria(FileErrorLog.class)
				.add(Restrictions.eq("batchSubmitId", batchSubmitId))
				.add(Restrictions.eq("ftmId", ftmId))
				.add(Restrictions.eq("ftmSequenceNumber", ftmTransferId))
				.setProjection(Projections.rowCount())
				.uniqueResult()).intValue();
	}

	private void insertFileErrorLog(String batchSubmitId, String ftmId,
			BigDecimal ftmTransferId, BigDecimal lineNumber, String line,
			String errorCode,
			String errorMessage) {
		super.callServiceWithSessionAndAsyncOptions(TransactionConstants.InsertFileErrorLog.SERVICE_NAME, false, true,
				TransactionConstants.InsertFileErrorLog.Input.BATCH_SUBMIT_ID, batchSubmitId,
				TransactionConstants.InsertFileErrorLog.Input.ERROR_CODE, errorCode,
				TransactionConstants.InsertFileErrorLog.Input.ERROR_MESSAGE, errorMessage,
				TransactionConstants.InsertFileErrorLog.Input.FTM_ID, ftmId,
				TransactionConstants.InsertFileErrorLog.Input.FTM_TRANSFER_ID, ftmTransferId,
				TransactionConstants.InsertFileErrorLog.Input.LINE, line,
				TransactionConstants.InsertFileErrorLog.Input.LINE_NUMBER, lineNumber);
	}

	private void setDataToField(GMMap serviceMap, ItemDatabaseField itemDatabaseField, Object parsedData) {
		serviceMap.put(itemDatabaseField.getDbField(), parsedData);
	}
	
	private Object getObject(String content, String fieldType, String format,
			String constant) throws Exception {
		if (fieldType.equals(DatabaseConstants.FieldType.Constant)) {
			return CommonHelper.replaceCharacters(constant, "'", " ");
		} else if (fieldType.equals(DatabaseConstants.FieldType.AlphaNumeric)) {
			return CommonHelper.replaceCharacters(content, "'", " ");
		} else if (fieldType.equals(DatabaseConstants.FieldType.Amount)) {
			if(!(format.contains(",") | format.contains("."))){
				int length = content.length();
				content = content.substring(0, length - 2).concat(".").concat(content.substring(length - 2, length));
				format = format.substring(0, length - 2).concat(".").concat(format.substring(length - 2, length));
			}
			DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.ROOT);
			DecimalFormat decimalFormat = new DecimalFormat(format, symbols);
			Number number = decimalFormat.parse(content.replaceAll(",", "."));
			return number;
		} else if (fieldType.equals(DatabaseConstants.FieldType.Date)
				|| fieldType.equals(DatabaseConstants.FieldType.Time)) {
			return CommonHelper.getDateTime(content, format);
		} else if (fieldType.equals(DatabaseConstants.FieldType.Numeric)) {
			return Long.valueOf(content);
		} else {
			throw new BatchComponentException(
					String.format(
							"Field type implementation for %s field type indicator is not found",
							fieldType), BusinessException.UNKNOWNFILEFORMAT);
		}
	}
	
	@SuppressWarnings("unchecked")
	private List<FtmFileContent> getDebtLines(BigDecimal ftmTransferId,
			int startLineNumber, int endLineNumber) {
		return super.getHibernateSession().createCriteria(FtmFileContent.class)
				.add(Restrictions.eq("ftmProcessOid", ftmTransferId))
				.add(Restrictions.between("lineNumber", new BigDecimal(startLineNumber), new BigDecimal(endLineNumber)))
				.list();
	}

}
