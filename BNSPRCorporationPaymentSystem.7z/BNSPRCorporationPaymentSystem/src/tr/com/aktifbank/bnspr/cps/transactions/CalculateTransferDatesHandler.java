package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.NotImplementedException;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.acctransfer.AccountTransferInfoFactory;
import tr.com.aktifbank.bnspr.cps.acctransfer.IAccountTransferInformation;
import tr.com.aktifbank.bnspr.cps.acctransfer.IDateCalcManipulationInformation;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CalculateTransferDates;
import tr.com.aktifbank.bnspr.cps.dto.TransferInformation;
import tr.com.aktifbank.bnspr.dao.AccountCollectionTypeRel;
import tr.com.aktifbank.bnspr.dao.BalanceTransferDays;
import tr.com.aktifbank.bnspr.dao.BalanceTransferDef;
import tr.com.aktifbank.bnspr.dao.CollectionTransferRel;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class CalculateTransferDatesHandler extends RequestHandler {

	public CalculateTransferDatesHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Date collectionDate = input.getDate(CalculateTransferDates.Input.COLLECTION_DATE);
		Date processDate = input.getDate(CalculateTransferDates.Input.PROCESS_DATE, new Date());
		String corporateCode = input.getString(CalculateTransferDates.Input.CORPORATE_CODE, null);
		String corporateOid = input.getString(CalculateTransferDates.Input.CORPORATE_OID, null);
		String transferType = input.getString("TRANSFER_TYPE");
		String fromAccountType = input.getString("FROM_ACCOUNT_TYPE", null);
		
		if(StringUtil.isEmpty(corporateOid) || StringUtil.isEmpty(corporateCode)){
			GMMap getCorporateResponse = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME,
					TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode,
					TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid);
			corporateOid = getCorporateResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID);
			corporateCode = getCorporateResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
		}
		
		List<BalanceTransferDef> transferDefinitionList = super.getHibernateSession().createCriteria(BalanceTransferDef.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateOid", corporateOid))
				.add(Restrictions.eq("fromAccountType", StringUtil.isEmpty(fromAccountType) ? DatabaseConstants.AccountDefinitionTypes.CollectionAccount : 
					fromAccountType))
				.add(Restrictions.eq("transferType", transferType))
				.list();
		
		for (BalanceTransferDef transferDef : transferDefinitionList) {
			String balanceTransferProcessId = super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
					TransactionConstants.InsertBalanceTransferProcess.Input.COLLECTION_DATE, collectionDate,
					TransactionConstants.InsertBalanceTransferProcess.Input.CORPORATE_CODE, corporateCode,
					TransactionConstants.InsertBalanceTransferProcess.Input.CORPORATE_OID, corporateOid,
					TransactionConstants.InsertBalanceTransferProcess.Input.FROM_ACCOUNT, transferDef.getFromAccountNo(),
					TransactionConstants.InsertBalanceTransferProcess.Input.IS_EFT_TRANSFER, transferDef.getToAccountType().equals(DatabaseConstants.AccountDefinitionTypes.EftAccount),
					TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, false,
					TransactionConstants.InsertBalanceTransferProcess.Input.PROCESS_DATE, processDate,
					TransactionConstants.InsertBalanceTransferProcess.Input.TO_ACCOUNT, transferDef.getToAccountNo(),
					TransactionConstants.InsertBalanceTransferProcess.Input.TO_IBAN, transferDef.getToAccountIban(),
					TransactionConstants.InsertBalanceTransferProcess.Input.TO_IBAN_OWNER, getIbanOwner(corporateOid, transferDef.getToAccountIban()),
					TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Waiting,
					TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_DEF_OID, transferDef.getOid(),
					TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_TYPE, transferType)
					.getString(TransactionConstants.InsertBalanceTransferProcess.Output.RECORD_ID);
			String balanceTransferLogId = super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
					TransactionConstants.InsertBalanceTransferLog.Input.CORPORATE_CODE, corporateCode,
					TransactionConstants.InsertBalanceTransferLog.Input.CORPORATE_OID, corporateOid,
					TransactionConstants.InsertBalanceTransferLog.Input.PROCESS_DATE, processDate,
					TransactionConstants.InsertBalanceTransferLog.Input.PROCESS_USER, CommonHelper.getCurrentUser(),
					TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_PROCESS_OID, balanceTransferProcessId,
					TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.WaitingTransferDateCalculation)
					.getString(TransactionConstants.InsertBalanceTransferLog.Output.RECORD_ID);
			try {
				List<CollectionTransferRel> transferRelList = super.getHibernateSession().createCriteria(CollectionTransferRel.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("transferParamOid", transferDef.getOid()))
						.list();
				
				TransferInformation information = new TransferInformation();
				information.setCollectionDate(collectionDate);
				information.setCorporateAccountNo(transferDef.getFromAccountNo());
				information.setCorporateCode(corporateCode);
				information.setHibernateSession(super.getHibernateSession());
				
				for (CollectionTransferRel transferRel : transferRelList) {
					AccountCollectionTypeRel collectionTypeRel = (AccountCollectionTypeRel)super.getHibernateSession().createCriteria(AccountCollectionTypeRel.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("oid", transferRel.getAccountCollectionOid()))
							.uniqueResult();
					if(collectionTypeRel != null){
						information.addToCollectionTypes(collectionTypeRel.getCollectionType());
						information.addToChannelCodes(collectionTypeRel.getChannelCode());
						information.addToSourceCodes(collectionTypeRel.getSourceCode());
					}
				}
				
				IAccountTransferInformation infoImplementation = AccountTransferInfoFactory.getInstance().createInformation(transferType, information);
				
				if(infoImplementation.getCount() == 0){
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.NoPaymentFound);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.NoPaymentFound);
					logger.warn(String.format("No invoice collection found for balance transfer definition with %s id", transferDef.getOid()));
					continue;
				}
				
				Date transferDate = null;
				
				if(infoImplementation instanceof IDateCalcManipulationInformation){
					transferDate = ((IDateCalcManipulationInformation)infoImplementation).calculateDate();
				}
				else{
					transferDate = calculateTransferDate(transferDef, collectionDate, processDate);
				}
				
				super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
						TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Waiting,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_DATE, transferDate);
				super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
						TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferDateCalculatedSuccessfully);
			} catch (Exception e) {
				super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
						TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Failed);
				super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
						TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferDateCalculationFailed,
						TransactionConstants.InsertBalanceTransferLog.Input.ERROR_CODE, "1",
						TransactionConstants.InsertBalanceTransferLog.Input.ERROR_MESSAGE, String.format("Transfer tarihi hesaplan�rken bir hata olu�tu : %s", e));
			}
		}
	}
	
	private String getIbanOwner(String corporateOid, String toAccountIban) {
		if(!StringUtil.isEmpty(toAccountIban)){
			CorporationAccountMaster record = (CorporationAccountMaster)super.getHibernateSession().createCriteria(CorporationAccountMaster.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateOid", corporateOid))
					.add(Restrictions.eq("iban", toAccountIban))
					.uniqueResult();
			if(record != null){
				return record.getAccountOwner();
			}
			else{
				return null;
			}
		}
		else{
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private Date calculateTransferDate(BalanceTransferDef transferDef, Date collectionDate, Date processDate) throws Exception {
		Date transferDate = null;
		
		if(transferDef.getTransferDayCount() != null){
			if(StringUtil.isEmpty(transferDef.getTransferDayType())){
				throw new Exception(String.format("Transfer g�n tipi bo� olamaz"));
			}
			Short transferDayCount = transferDef.getTransferDayCount();
			String transferDayType = transferDef.getTransferDayType();
			if(transferDayType.equals(DatabaseConstants.BalanceTransferDayTypes.Day)){
				transferDate = CommonHelper.addDay(collectionDate, transferDayCount);
			}
			else if(transferDayType.equals(DatabaseConstants.BalanceTransferDayTypes.WorkingDay)){
				transferDate = collectionDate;
				while(transferDayCount >= 0){
					transferDate = CommonHelper.addDay(transferDate, 1);
					while(!CommonHelper.isWorkingDay(transferDate)){
						transferDate = CommonHelper.addDay(transferDate, 1);
					}
					--transferDayCount;
				}
			}
			else{
				throw new NotImplementedException(String.format("Balance transfer day type for %s parameter has not been implemented", transferDayType));
			}
		}
		else{
			List<BalanceTransferDays> days = super.getHibernateSession().createCriteria(BalanceTransferDays.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("balanceTransferOid", transferDef.getOid()))
					.list();
			if(days.size() == 0){
				throw new Exception("Transfer aktar�m�nda ka� g�n sonra yap�laca�� veya hangi g�n�n hangi g�n yap�laca�� tan�mlanmam��t�r.");
			}
			int dayOfWeek = CommonHelper.getDayOfWeekInTurkishLocale(collectionDate);
			int dayOfWeekForTransfer = 0;
			boolean isNextWeek = false;
			boolean transferDayFound = false;
			for (BalanceTransferDays transferDay : days) {
				if(Integer.valueOf(transferDay.getInDayOfEachWeek()) == dayOfWeek){
					transferDayFound = true;
					isNextWeek = transferDay.getNextWeek();
					dayOfWeekForTransfer = Integer.valueOf(transferDay.getOutDayOfEachWeek());
				}
			}
			
			if(transferDayFound){
				int daysToBeAdded = 0;
				if(dayOfWeek > dayOfWeekForTransfer){
					daysToBeAdded = dayOfWeekForTransfer - dayOfWeek + 7;
				}
				else{
					daysToBeAdded = dayOfWeekForTransfer - dayOfWeek;
					if(isNextWeek){
						daysToBeAdded += 7;
					}
					else{
						if(daysToBeAdded == 0){
							daysToBeAdded = 7;
						}
					}
				}
				transferDate = CommonHelper.addDay(collectionDate, daysToBeAdded);
			}
			else{
				throw new Exception(String.format("Haftan�n %s g�n� i�in transfer g�n� bulunamam��t�r.", dayOfWeek));
			}
		}
		
		if(transferDef.getInDayOfEachMonth() != null){
			if(transferDef.getOutDayOfEachMonth() == null){
				throw new Exception(String.format("Ay�n %s g�n�ne gelen aktar�mlar�n aktar�laca�� g�n i�in tan�m yap�lmam��t�r.", transferDef.getInDayOfEachMonth()));
			}
			int dayOfMonth = CommonHelper.getDayOfMonth(transferDate);
			if(dayOfMonth == (int)transferDef.getInDayOfEachMonth()){
				int outDayOfMonth = transferDef.getOutDayOfEachMonth();
				int dayCount = outDayOfMonth - dayOfMonth;
				transferDate = CommonHelper.addDay(transferDate, dayCount);
			}
		}
		
		if(!StringUtil.isEmpty(transferDef.getTransferCollectionsInholiday())){
			if(transferDef.getTransferCollectionsInholiday().equals(DatabaseConstants.BalanceTransferCollectionsInHoliday.MustWorkingDay)){
				while(!CommonHelper.isWorkingDay(transferDate)){
					transferDate = CommonHelper.addDay(transferDate, 1);
				}
			}
			else if(transferDef.getTransferCollectionsInholiday().equals(DatabaseConstants.BalanceTransferCollectionsInHoliday.BeforeHoliday)){
				while(!CommonHelper.isWorkingDay(transferDate)){
					transferDate = CommonHelper.addDay(transferDate, -1);
				}
				if(Long.valueOf(CommonHelper.getShortDateTimeString(processDate)) > Long.valueOf(CommonHelper.getShortDateTimeString(transferDate))){
					if(CommonHelper.isWorkingDay(processDate)){
						transferDate = processDate;
					}
					else{
						transferDate = CommonHelper.getDateTime(CommonHelper.getShortDateTimeString(processDate), "yyyyMMdd");
						while(!CommonHelper.isWorkingDay(transferDate)){
							transferDate = CommonHelper.addDay(transferDate, 1);
						}
					}
				}
			}
			else if(transferDef.getTransferCollectionsInholiday().equals(DatabaseConstants.BalanceTransferCollectionsInHoliday.HolidayAllowed)){
				// No need to modify date
			}
			else{
				throw new Exception("Unknown value for transfer of holidays : ".concat(transferDef.getTransferCollectionsInholiday()));
			}
		}
		
		return transferDate;
	}

}
