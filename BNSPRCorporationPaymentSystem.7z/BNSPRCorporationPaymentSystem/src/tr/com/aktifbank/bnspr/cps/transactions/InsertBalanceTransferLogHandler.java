package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.InsertBalanceTransferLog;
import tr.com.aktifbank.bnspr.dao.BalanceTransferLog;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class InsertBalanceTransferLogHandler extends RequestHandler {

	public InsertBalanceTransferLogHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		boolean isUpdate = input.getBoolean(InsertBalanceTransferLog.Input.IS_UPDATE, false);
		if(isUpdate){
			String recordId = input.getString(InsertBalanceTransferLog.Input.RECORD_ID);
			BigDecimal transferAmount = input.getBigDecimal(InsertBalanceTransferLog.Input.TRANSFER_AMOUNT, null);
			byte transferStatus = (byte)input.getInt(InsertBalanceTransferLog.Input.TRANSFER_STATUS);
			String errorCode = input.getString(InsertBalanceTransferLog.Input.ERROR_CODE, null);
			String errorMessage = input.getString(InsertBalanceTransferLog.Input.ERROR_MESSAGE, null);
			BigDecimal currentAvailableBalance = input.getBigDecimal(InsertBalanceTransferLog.Input.CURRENT_AVAILABLE_BALANCE, null);
			BigDecimal actualTransferAmount = input.getBigDecimal(InsertBalanceTransferLog.Input.ACTUAL_TRANSFER_AMOUNT, null);
			BigDecimal constantAmount = input.getBigDecimal(InsertBalanceTransferLog.Input.CONSTANT_AMOUNT, null);
			BalanceTransferLog log = (BalanceTransferLog)super.getHibernateSession().createCriteria(BalanceTransferLog.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("oid", recordId))
					.uniqueResult();
			if(log != null){
				if(transferAmount != null){
					log.setTransferAmount(transferAmount);
				}
				log.setTransferStatus(transferStatus);
				if (!StringUtil.isEmpty(errorCode)) {
					log.setErrorCode(errorCode);
				}
				if (!StringUtil.isEmpty(errorMessage)) {
					log.setErrorDesc(errorMessage);
				}
				if(currentAvailableBalance != null){
					log.setAvailBalBefTransfer(currentAvailableBalance);
				}
				if(actualTransferAmount != null){
					log.setActualAmount(actualTransferAmount);
				}
				if(constantAmount != null){
					log.setConstantAmount(constantAmount);
				}
				super.getHibernateSession().saveOrUpdate(log);
				super.getHibernateSession().flush();
			}
			else{ 
				throw new Exception(String.format("No balance transfer log record found for %s id", recordId));
			}
		}
		else{
			String corporateCode = input.getString(InsertBalanceTransferLog.Input.CORPORATE_CODE, null);
			String corporateOid = input.getString(InsertBalanceTransferLog.Input.CORPORATE_OID, null);
			String transferProcessOid = input.getString(InsertBalanceTransferLog.Input.TRANSFER_PROCESS_OID);
			BigDecimal transferAmount = input.getBigDecimal(InsertBalanceTransferLog.Input.TRANSFER_AMOUNT, null);
			byte transferStatus = (byte)input.getInt(InsertBalanceTransferLog.Input.TRANSFER_STATUS);
			String processUser = input.getString(InsertBalanceTransferLog.Input.PROCESS_USER, null);
			
			if(StringUtil.isEmpty(corporateCode)){
				GMMap getCorporateDefinitionResponse = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
						TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid);
				corporateCode = getCorporateDefinitionResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
			}
			
			BalanceTransferLog log = new BalanceTransferLog();
			log.setStatus(true);
			log.setCorporateCode(corporateCode);
			log.setTransferProcessOid(transferProcessOid);
			log.setTransferAmount(transferAmount != null ? transferAmount : new BigDecimal(0));
			log.setProcessDate(CommonHelper.getLongDateTimeString(new Date()));
			log.setTransferStatus(transferStatus);
			log.setProcessUser(processUser);
			super.getHibernateSession().save(log);
			output.put(InsertBalanceTransferLog.Output.RECORD_ID, log.getOid());
			super.getHibernateSession().flush();
		}
	}

}
