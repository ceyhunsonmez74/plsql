package tr.com.aktifbank.bnspr.cps.transactions;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CommitInvoices;

import com.graymound.util.GMMap;

public class CommitInvoicesHandler extends RequestHandler {

	public CommitInvoicesHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String serviceName = input.getString(CommitInvoices.Input.SERVICE_NAME);
		for (int i = 0; i < input.getSize(CommitInvoices.Input.INSERT_TABLE); i++) {
			GMMap currentSubmitMap = (GMMap) input.get(CommitInvoices.Input.INSERT_TABLE, i, CommitInvoices.Input.INSERT_REQUEST);
			super.callGraymoundServiceInSession(serviceName, currentSubmitMap);
		}
	}

}
