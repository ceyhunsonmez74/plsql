package tr.com.aktifbank.bnspr.cps.dto;

public final class CorporateReconciliationDetailCallResult extends
		BaseTransferObject {

	public CorporateReconciliationDetailCallResult() {
		super();
	}
	
	boolean isSuccessfulCall;
	String returnCode;
	
	public boolean isSuccessfulCall() {
		return isSuccessfulCall;
	}
	public void setSuccessfulCall(boolean isSuccessfulCall) {
		this.isSuccessfulCall = isSuccessfulCall;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	
	

}
