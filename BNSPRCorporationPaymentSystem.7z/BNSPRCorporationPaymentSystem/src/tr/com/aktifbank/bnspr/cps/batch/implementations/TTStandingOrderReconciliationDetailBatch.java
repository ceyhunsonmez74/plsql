package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.cps.dto.TTSReconciliationDetail;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;

import com.graymound.util.GMMap;

public class TTStandingOrderReconciliationDetailBatch extends StandingOrderReconciliationDetailBatch {

	private List<TTSReconciliationDetail> details;
	private Map<String, TTSReconciliationDetail> indexedCorporateRecords;
	
	public TTStandingOrderReconciliationDetailBatch(GMMap input, List<TTSReconciliationDetail> details) {
		super(input);
		this.details = details;
		indexedCorporateRecords = new HashMap<String, TTSReconciliationDetail>();
	}

	@Override
	protected void setCancelStandingOrderExtraParameters(
			GMMap cancelStandingOrderRequest, int corporateRecordIndex) {
		
	}

	@Override
	protected void setCorporateParametersToReconProcessLogInput(
			GMMap reconProcessDataLogInput, int corporateRecordIndex) {
		reconProcessDataLogInput.put(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1, this.details.get(0).getServiceNo());
		
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(
			icsStandingOrders bankRecord) {
		String subscriberNo = bankRecord.getSubscriberNo1();
		if( null != bankRecord.getSubscriberNo2() && !"".equals(bankRecord.getSubscriberNo2()) ){
			subscriberNo = subscriberNo.concat(bankRecord.getSubscriberNo2());
		}
		return this.indexedCorporateRecords.containsKey(subscriberNo);
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()
			throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		result.setSuccessfulCall(true);
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int bankRecordSize = super.getBankRecordsSize();
		for( int i =0; i< bankRecordSize; i++){
			String subscriberNo = super.getBankRecordAtIndex(i).getSubscriberNo1();
			if( null != super.getBankRecordAtIndex(i).getSubscriberNo2() && !"".equals(super.getBankRecordAtIndex(i).getSubscriberNo2()) ){
				subscriberNo = subscriberNo.concat(super.getBankRecordAtIndex(i).getSubscriberNo2());
			}
			super.setBankRecordIndex(subscriberNo, super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for( TTSReconciliationDetail detail : details){
			indexedCorporateRecords.put(detail.getServiceNo(), detail);
		}
		
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getServiceNo());
	}

}
