package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.kahramanmaras.su.KahramanmarasSuClient;
import tr.com.aktifbank.integration.kahramanmaras.su.ServiceMessage;
import webservices.TahsilatDetay;

import com.graymound.util.GMMap;


public final class KaskiReconciliationDetailBatch extends CollectionReconciliationDetailBatch {
	
	private static final Log logger = LogFactory.getLog(KaskiReconciliationDetailBatch.class);
	Session session;
	List<TahsilatDetay> details;
	ServiceMessage message;
	Map<String, TahsilatDetay> indexedCorporateRecords;
	
	public KaskiReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, TahsilatDetay>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER2, CommonHelper.getHugeDateTimeString(details.get(corporateRecordIndex).getTarih().getTime()));
		cancelCollectionRequest.put(MapKeys.PARAMETER3, details.get(corporateRecordIndex).getToplam());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);

			Calendar reconDate = Calendar.getInstance(); 
			reconDate.setTime(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"));
			TahsilatDetay[] response = KahramanmarasSuClient.tahsilatListesi(url, Integer.valueOf(username), password, reconDate, this.message);
			details = new ArrayList<TahsilatDetay>();
			if(response != null){
				for(TahsilatDetay  tahsilat: response){
					details.add(tahsilat);
				}
			}
			result.setSuccessfulCall(true);
			
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex));
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getKarsiReferansNo(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getKarsiReferansNo());
	}

	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		TahsilatDetay corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Abone Numaras� : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getAbone(), 
				corporateDetail.getKarsiReferansNo(), 
				corporateDetail.getToplam()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(String.valueOf(corporateDetail.getAbone()));
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal(corporateDetail.getKarsiReferansNo()));
		payment.setParameter2(CommonHelper.getHugeDateTimeString(corporateDetail.getTarih().getTime()));
		payment.setParameter3(String.valueOf(corporateDetail.getToplam()));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getToplam()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getToplam()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getAbone());
		collectionDetailResponse.put(MapKeys.TRX_NO, new BigDecimal(corporateDetail.getKarsiReferansNo()));
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getToplam());
	}

}
