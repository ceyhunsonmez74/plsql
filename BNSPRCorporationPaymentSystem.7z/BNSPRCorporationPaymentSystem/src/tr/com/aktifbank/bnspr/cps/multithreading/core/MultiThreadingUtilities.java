package tr.com.aktifbank.bnspr.cps.multithreading.core;

import java.util.LinkedHashMap;
import java.util.Map;

public final class MultiThreadingUtilities {
	public static Map<Integer, Integer> getIndexStartMappings(int threadCount, int recordCount){
		Map<Integer, Integer> indexStartMappings = new LinkedHashMap<Integer, Integer>();
		if(threadCount >= recordCount){
			for(int i = 1; i <= threadCount; i++){
				indexStartMappings.put(i, i);
			}
		}
		else{
			int bufferSize = (int)Math.ceil(((double)recordCount) / ((double)threadCount));
			int remainder = recordCount % threadCount;
			int lastStartIndex = 0;
			for (int i = 1; i <= threadCount; i++) {
				if(i==1){
					indexStartMappings.put(i, 1);
					lastStartIndex = 1;
				}
				else{
					int currentStartIndex = lastStartIndex + bufferSize;
					if(remainder != 0){
						currentStartIndex += remainder--;
					}
					indexStartMappings.put(i, currentStartIndex);
					lastStartIndex = currentStartIndex;
				}
			}
		}
		
		return indexStartMappings;
	}
}
