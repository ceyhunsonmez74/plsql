package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;

import com.graymound.util.GMMap;

public final class FTSGetTotalInvoiceCountHandler extends RequestHandler {

	private static final class ParameterKeys{
		//public static final String WEEKEND_TO_WEEKDAY = "HAFTA_SONUNU_PTESI_CIK";
		//public static final String SHOW_PAYMENT_DATE_AS_PROCESS_DATE = "BUGUN_ODENMIS_GIBI_GOSTER";
		public static final String INFORM_ONLY_STANDING_ORDER_PAYMENTS = "SADECE_TALIMATLI_ODEMELERI_GONDER";
	}
	
	public FTSGetTotalInvoiceCountHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		List<Date> dates = new ArrayList<Date>();
		Date invoiceDate = input.getDate(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE);
		GMMap parameters = input.getMap(TransactionConstants.CorporateGeneralBatchSubmit.Input.BATCH_PARAMETERS, null);
		boolean onlyStandingOrderTransactions = false;
		if(parameters != null && parameters.containsKey(ParameterKeys.INFORM_ONLY_STANDING_ORDER_PAYMENTS) &&
				parameters.getString(ParameterKeys.INFORM_ONLY_STANDING_ORDER_PAYMENTS).equals(DatabaseConstants.BatchParameterValues.InformOnlyStandingOrderPaymentsEnabled)){
			onlyStandingOrderTransactions = true;
		}
		dates.add(invoiceDate);
		if(input.containsKey("EXTRA_PROCESS_DATES")){
			for (int i = 0; i < input.getSize("EXTRA_PROCESS_DATES"); i++) {
				dates.add(input.getDate("EXTRA_PROCESS_DATES", i, "DATE"));
			}
		}
		String corporateCode = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE);
		output.put(MapKeys.FTS_OUTPUT_DATA, new Integer(CommonBusinessOperations.getTotalCollectionCount(super.getHibernateSession(), corporateCode, dates, onlyStandingOrderTransactions)));
	}

}
