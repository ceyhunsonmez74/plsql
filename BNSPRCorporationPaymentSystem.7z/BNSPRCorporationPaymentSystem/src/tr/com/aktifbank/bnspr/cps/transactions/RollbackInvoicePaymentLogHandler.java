package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.invoicePayment;

import com.graymound.util.GMMap;

public final class RollbackInvoicePaymentLogHandler extends RequestHandler {

	public RollbackInvoicePaymentLogHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		BigDecimal txNo = input.getBigDecimal(MapKeys.TRX_NO);
		
		invoicePayment payment = (invoicePayment) super.getHibernateSession().createCriteria(invoicePayment.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("txNo", txNo))
				.uniqueResult();
		
		payment.setTxNo(txNo.multiply(new BigDecimal(-1)));
		
		super.getHibernateSession().saveOrUpdate(payment);
		super.getHibernateSession().flush();
	}
	
	@Override
	protected void handleError(Throwable e, GMMap output) {
		logger.error("An exception occured while rolling back payment log");
		logger.error(System.currentTimeMillis(), e);
	}

}
