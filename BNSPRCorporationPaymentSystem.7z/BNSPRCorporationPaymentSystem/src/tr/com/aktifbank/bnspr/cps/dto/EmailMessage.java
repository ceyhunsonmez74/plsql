package tr.com.aktifbank.bnspr.cps.dto;


import java.util.List;

public class EmailMessage {

	private final List<String> receiptList;
	private final String body;
	private final String subject;
	private final String from;

	private EmailMessage(MessageBuilder builder) {
		receiptList = builder.receiptList;
		body = builder.body;
		subject = builder.subject;
		from = builder.from;
	}

	public List<String> getReceiptList() {
		return receiptList;
	}

	public String getBody() {
		return body;
	}

	public String getSubject() {
		return subject;
	}

	public String getFrom() {
		return from;
	}

	public static class MessageBuilder {

		private List<String> receiptList;
		private final String subject;
		private String body;
		private String from;

		public MessageBuilder(String subject) {

			this.subject = subject;
		}

		public MessageBuilder receiptList(List<String> receiptList) {

			this.receiptList = receiptList;
			return this;
		}

		public MessageBuilder from(String from) {
			this.from = from;
			return this;
		}

		public MessageBuilder body(String body) {
			this.body = body;
			return this;
		}

		public EmailMessage getEmail() {
			return new EmailMessage(this);
		}

	}
}
