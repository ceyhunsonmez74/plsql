package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;

import com.graymound.util.GMMap;

public final class ControlCollectionAmountHandler extends RequestHandler {

	public ControlCollectionAmountHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String invoiceOid = input.getString(TransactionConstants.ControlCollectionAmount.Input.INVOICE_MASTER_OID);
		BigDecimal collectionAmount = input.getBigDecimal(TransactionConstants.ControlCollectionAmount.Input.COLLECTION_AMOUNT);
		BigDecimal amount = input.getBigDecimal(TransactionConstants.ControlCollectionAmount.Input.AMOUNT);
		String corporateCode = input.getString(TransactionConstants.ControlCollectionAmount.Input.CORPORATE_CODE);
		boolean throwsException = input.getBoolean(TransactionConstants.ControlCollectionAmount.Input.THROWS_EXCEPTION, true);
		
		
		if(amount != null){
			if(amount.compareTo(collectionAmount) !=0 ){
				CorporateMaster corporateResult = (CorporateMaster)super.getHibernateSession().createCriteria(CorporateMaster.class)
						.add(Restrictions.eq("corporateCode", corporateCode))
						.add(Restrictions.eq("status", true))
						.uniqueResult();
				if(corporateResult != null){
					if(corporateResult.isAllowPartPayment()){
						output.put(TransactionConstants.ControlCollectionAmount.Output.RESULT, BusinessException.UNDEFINED.getCode());
					}
					else{
						if(throwsException){
							throw new BatchComponentException(BusinessException.CORPORATENOTALLOWPARTPAYMENT, corporateResult.getShortCode());
						}
						else{
							output.put(TransactionConstants.ControlCollectionAmount.Output.RESULT, BusinessException.CORPORATENOTALLOWPARTPAYMENT.getCode());
						}
					}
				}
				else{
					if(throwsException){
						throw new BatchComponentException(BusinessException.CORPORATENOTFOUND, corporateCode);
					}
					else{
						output.put(TransactionConstants.ControlCollectionAmount.Output.RESULT, BusinessException.CORPORATENOTFOUND.getCode());
					}
				}
			}
			else if(amount.compareTo(collectionAmount) == 0){
				output.put(TransactionConstants.ControlCollectionAmount.Output.RESULT, BusinessException.UNDEFINED.getCode());
			}
			else{
				if(throwsException){
					throw new BatchComponentException(BusinessException.COLLECTIONAMOUNTCANNOTBEBIGGERTHANINVOICEAMOUNT);
				}
				else{
					output.put(TransactionConstants.ControlCollectionAmount.Output.RESULT, BusinessException.COLLECTIONAMOUNTCANNOTBEBIGGERTHANINVOICEAMOUNT.getCode());
				}
			}
		}
		else{
			if(throwsException){
				throw new BatchComponentException(BusinessException.INVOICERECORDISNOTFOUND, invoiceOid);
			}
			else{
				output.put(TransactionConstants.ControlCollectionAmount.Output.RESULT, BusinessException.INVOICERECORDISNOTFOUND.getCode());
			}
		}
	}

}
