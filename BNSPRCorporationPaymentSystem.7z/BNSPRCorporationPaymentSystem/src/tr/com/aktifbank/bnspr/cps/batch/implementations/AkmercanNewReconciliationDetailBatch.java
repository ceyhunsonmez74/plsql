package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.akmercan.AboneTahsilat;
import tr.com.akmercan.ResultOfListOfAboneTahsilat;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.integration.akmercanNew.AkmercanNewClient;
import tr.com.aktifbank.integration.akmercanNew.ServiceMessage;

import com.graymound.util.GMMap;

public class AkmercanNewReconciliationDetailBatch extends CollectionReconciliationDetailBatch{
	
	private static final Log logger = LogFactory.getLog(AkmercanNewReconciliationDetailBatch.class);
	List<AboneTahsilat> details= new ArrayList<AboneTahsilat>();
	Map<String, AboneTahsilat> indexedCorporateRecords;
	Session session;
	ServiceMessage message;

	public AkmercanNewReconciliationDetailBatch(GMMap input, ServiceMessage serviceMessage) {
		super(input);
		this.message = serviceMessage;
		this.indexedCorporateRecords = new HashMap<String, AboneTahsilat>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.PARAMETER3, details.get(corporateRecordIndex).getMakbuzNo());		
		collectionDetailRequest.put(MapKeys.PAYMENT_AMOUNT, details.get(corporateRecordIndex).getTutar());		
		collectionDetailRequest.put(MapKeys.SUBSCRIBER_NO1, details.get(corporateRecordIndex).getAboneNo());		
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER_3, details.get(corporateRecordIndex).getMakbuzNo().getValue());
		cancelCollectionRequest.put(MapKeys.PAYMENT_AMOUNT, details.get(corporateRecordIndex).getTutar());		
		cancelCollectionRequest.put(MapKeys.CANCEL_SUBSCRIBER_NO1, details.get(corporateRecordIndex).getAboneNo());		
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String clientId = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 			
			String date = CommonHelper.getDateString(new Date(), "dd.MM.yyyy");
			String type = "Hepsi";
			
			ResultOfListOfAboneTahsilat tahsilatResult = AkmercanNewClient.yapilanTahsilatlar(reqTimeout, connTimeout, serviceUrl, username, password, message, clientId, date, type);
			
			List<AboneTahsilat> paymentList = new ArrayList<AboneTahsilat>();
			
			if(tahsilatResult != null){
				paymentList = tahsilatResult.getKayit().getValue().getAboneTahsilat();
			}
			
			details = paymentList;
			result.setSuccessfulCall(true);
			
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.INVOICE_NO), super.getBankRecordAtIndex(i));
		}
		
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getMakbuzNo().getValue(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getMakbuzNo().getValue());
	}
}
