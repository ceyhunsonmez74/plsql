package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.arsan.ArsanClient;
import tr.com.aktifbank.integration.arsan.ServiceMessage;
import tr.com.arsan.AgreementDetailResponse;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.clkenerji.schema.abcs_ccnb_payment_operat�ons.ReconPaymentTransactionType;

import com.graymound.util.GMMap;

public final class ArsanReconciliationDetailBatch extends CollectionReconciliationDetailBatch {
	private static final Log logger = LogFactory.getLog(CLKReconciliationDetailBatch.class);
	Session session;
	List<AgreementDetailResponse> details= new ArrayList<AgreementDetailResponse>();
	ServiceMessage message;
	Map<String, AgreementDetailResponse> indexedCorporateRecords;
	
	public ArsanReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, AgreementDetailResponse>();
		session = CommonHelper.getHibernateSession();
	}
	
	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.SUBSCRIBER_NO3, details.get(corporateRecordIndex).getAboneNo());
		cancelCollectionRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getSozlesmeNo());//getPaymentId
		cancelCollectionRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getIslemReferansNo());
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getIslemReferansNo());		
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			Integer bankCode = Integer.parseInt(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			Integer companyCode = Integer.parseInt(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
//			Date collectionDate = new SimpleDateFormat("dd/MM/yyyy").parse("COLLECTION_DATE");
			Date reconDate = new Date();
			if (!StringUtil.isEmpty(input.getString(MapKeys.RECON_DATE)))
				reconDate= input.getDate(MapKeys.RECON_DATE);
			String serviceUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			
			String responseCode = "";
			String responseMessage = "";
			ArrayList<AgreementDetailResponse> agreementDetailResponseList = null;


			agreementDetailResponseList = ArsanClient.collectionReconciliationDetail(serviceUrl, 
					bankCode, companyCode, username, password, reconDate, serviceMessage);
			responseCode = agreementDetailResponseList.get(0).getErrorCode().toString();
			responseMessage = agreementDetailResponseList.get(0).getErrorMessage();
			
			List<AgreementDetailResponse> allDetailsList= agreementDetailResponseList;
			List<AgreementDetailResponse> paymentList= new ArrayList<AgreementDetailResponse>();
			List<AgreementDetailResponse> cancelList= new ArrayList<AgreementDetailResponse>();

			for (int i = 0; i < allDetailsList.size(); i++) {
				if (allDetailsList.get(i).getIslemTipi().equals("G")) {
					paymentList.add(allDetailsList.get(i));
				}	
			}
			
			for (int i = 0; i < allDetailsList.size(); i++) {
				if (allDetailsList.get(i).getIslemTipi().equals("I")) {
					cancelList.add(allDetailsList.get(i));
				}	
			}
			
			
			for (int i = 0; i < paymentList.size(); i++) {
				for (int j = 0; j < cancelList.size(); j++) {
					if (paymentList.get(i).getIslemReferansNo().equals(cancelList.get(j).getIslemReferansNo())) {
						paymentList.remove(i);
					}
				}		
			}
			
			details = paymentList;
			result.setSuccessfulCall(true);
		}
		catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getIslemReferansNo().toString(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getIslemReferansNo().toString());
	}
	
    @Override
    protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
                throws Exception {
          AgreementDetailResponse corporateDetail = details.get(corporateRecordIndex);
          String aboneNo = corporateDetail.getAboneNo().toString();
          
                      
          logger.info(String.format("Following corporate record has not been found in database. Referans No : %s, Miktar : %s ",  
                      corporateDetail.getIslemReferansNo(), 
                      corporateDetail.getTahsilTutari()));
          
          invoicePayment payment = new invoicePayment();
          payment.setStatus(true);
         payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
          payment.setCollectionType(Short.valueOf("0"));
          payment.setInvoiceMainOid("0");
          payment.setSubscriberNo3(aboneNo);
          payment.setInvoiceNo("1");
          payment.setPaymentStatus(PaymentStatuses.Cancelled);
          payment.setTxNo(new BigDecimal("-1"));
          payment.setInvoiceAmount(corporateDetail.getTahsilTutari());
          payment.setPaymentAmount(corporateDetail.getTahsilTutari());
          payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
          payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
          payment.setParameter1(aboneNo);
          payment.setParameter2(corporateDetail.getIslemReferansNo().toString());
          
          session.saveOrUpdate(payment);
          session.flush();
          
          collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO3, aboneNo);
          collectionDetailResponse.put(MapKeys.INVOICE_NO, "");
          collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
          collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getTahsilTutari());
    }

}
