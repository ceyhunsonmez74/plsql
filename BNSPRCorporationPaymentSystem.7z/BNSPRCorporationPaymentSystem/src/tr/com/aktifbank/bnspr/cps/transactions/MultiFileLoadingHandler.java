package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.TransferTypes;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.MultiFileLoading;
import tr.com.aktifbank.bnspr.cps.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class MultiFileLoadingHandler extends RequestHandler {
	
	private static final String NOPARAMETER = "-1";

	public MultiFileLoadingHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String ftmId = input.getString(MultiFileLoading.Input.FTM_ID);
		BigDecimal ftmTransferId = input.getBigDecimal(MultiFileLoading.Input.FTM_TRANSFER_ID);
		
		List<CorporateFileTransfer> fileTransfers = getCorporateFileTransfers(ftmId);
		
		for (CorporateFileTransfer fileTransfer : fileTransfers) {
			String formatId = fileTransfer.getFormatId();
			List<FormatDetail> headerDetails = 
					CommonBusinessOperations.getFormatDetails(DatabaseConstants.LineType.Header, formatId, super.getHibernateSession());
			List<FormatDetail> bodyDetails = 
					CommonBusinessOperations.getFormatDetails(DatabaseConstants.LineType.Detail, formatId, super.getHibernateSession());
			List<FormatDetail> footerDetails = 
					CommonBusinessOperations.getFormatDetails(DatabaseConstants.LineType.Footer, formatId, super.getHibernateSession());
			
			String headerConstant = null;
			String bodyConstant = null;
			String footerConstant = null;
			
			if(headerDetails.size() > 0){
				headerConstant = headerDetails.get(0).getInitialConstant();
			}
			
			if(bodyDetails.size() > 0){
				bodyConstant = bodyDetails.get(0).getInitialConstant();
			}
			
			if(footerDetails.size() > 0){
				footerConstant = footerDetails.get(0).getInitialConstant();
			}
			
			List<FtmFileContent> currentTransferContents = new ArrayList<FtmFileContent>();
			
			if(!StringUtil.isEmpty(headerConstant)){
				List<FtmFileContent> headerLines = super.getHibernateSession().createCriteria(FtmFileContent.class)
						.add(Restrictions.like("line", headerConstant, MatchMode.START))
						.add(Restrictions.eq("ftmProcessOid", ftmTransferId))
						.list();
				if(headerLines.size() > 0){
					currentTransferContents.addAll(headerLines);
				}
			}
			
			if(!StringUtil.isEmpty(bodyConstant)){
				List<FtmFileContent> bodyLines = super.getHibernateSession().createCriteria(FtmFileContent.class)
						.add(Restrictions.like("line", bodyConstant, MatchMode.START))
						.add(Restrictions.eq("ftmProcessOid", ftmTransferId))
						.list();
				if(bodyLines.size() > 0){
					currentTransferContents.addAll(bodyLines);
				}
			}
			
			if(!StringUtil.isEmpty(footerConstant)){
				List<FtmFileContent> footerLines = super.getHibernateSession().createCriteria(FtmFileContent.class)
						.add(Restrictions.like("line", footerConstant, MatchMode.START))
						.add(Restrictions.eq("ftmProcessOid", ftmTransferId))
						.list();
				if(footerLines.size() > 0){
					currentTransferContents.addAll(footerLines);
				}
			}
			
			BigDecimal tempProcessOid = getNextValueOfProcessSequence();
			
			GMMap fileContentInsertServiceMap = new GMMap();
			fileContentInsertServiceMap.put("FTM_PROCESS_OID", tempProcessOid);
			for (FtmFileContent content : currentTransferContents) {
				fileContentInsertServiceMap.put("FILE_CONTENTS", currentTransferContents.indexOf(content), "LINE_NUMBER", content.getLineNumber());
				fileContentInsertServiceMap.put("FILE_CONTENTS", currentTransferContents.indexOf(content), "LINE", content.getLine());
			}
			
			super.callGraymoundServiceOutsideSession("FTM_CREATE_FTM_FILE_CONTENT", fileContentInsertServiceMap);
			
			GMMap batchDetails = super.callServiceWithParams(TransactionConstants.GetBatchDetail.SERVICE_NAME, 
					TransactionConstants.GetBatchDetail.Input.BATCH_NAME, fileTransfer.getBatchName(),
					TransactionConstants.GetBatchDetail.Input.CORPORATE_CODE, fileTransfer.getCorporateCode());
			
			GMMap batchParameters = super.callServiceWithParams(TransactionConstants.GetBatchParameters.SERVICE_NAME,
					TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID, batchDetails.getString(TransactionConstants.GetBatchDetail.Output.CORPORATE_BATCH_PROCESS_OID));
			
			String composedParameters = batchParameters.getString(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS, NOPARAMETER);
			
			GMMap batchSubmitRequest = new GMMap();
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME, fileTransfer.getBatchName());
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.COMMIT_COUNT, batchDetails.getInt(TransactionConstants.GetBatchDetail.Output.COMMIT_COUNT));
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE, fileTransfer.getCorporateCode());
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.FORMAT_OID, fileTransfer.getFormatId());
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.FTM_ID, ftmId);
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.FTM_TRANSFER_ID, tempProcessOid);
			if (!composedParameters.equals(NOPARAMETER)) {
				batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS, composedParameters);
			}
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID, CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey));
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.THREAD_COUNT, batchDetails.getInt(TransactionConstants.GetBatchDetail.Output.THREAD_COUNT));
			batchSubmitRequest.put(TransactionConstants.GeneralBatchSubmit.Input.THRESHOLD, batchDetails.getInt(TransactionConstants.GetBatchDetail.Output.THRESHOLD));
			
			super.callGraymoundServiceAsync(batchDetails.getString(TransactionConstants.GetBatchDetail.Output.SERVICE_NAME), batchSubmitRequest);
		}
	}
	
	private BigDecimal getNextValueOfProcessSequence() {
		return new BigDecimal(((Number) super.getHibernateSession()
				.createSQLQuery("SELECT ftm.seq_ftm_process.nextval FROM dual")
				.uniqueResult()).longValue());
	}
	
	@SuppressWarnings("unchecked")
	private List<CorporateFileTransfer> getCorporateFileTransfers(String ftmId) throws SQLException {
		Criteria criteria = super.getHibernateSession().createCriteria(CorporateFileTransfer.class);
		criteria.add(Restrictions.eq("ftmId", new BigDecimal(ftmId)));
		criteria.add(Restrictions.eq("transferType", (short)TransferTypes.InvoiceLoading));
		criteria.add(Restrictions.eq("status", true));
		criteria.add(Restrictions.eq("complexFileTransfer", true));
		return criteria.list();
	}

}
