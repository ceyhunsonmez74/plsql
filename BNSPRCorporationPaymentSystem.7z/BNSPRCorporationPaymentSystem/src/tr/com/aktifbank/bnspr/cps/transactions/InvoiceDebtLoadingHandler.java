package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentSkipListSet;

import org.hibernate.Criteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BatchParameterEngine;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.TransferTypes;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.InvoiceDebtLoadingHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.SingleInstanceMemory;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.DebtLoadingProcessInformation;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.cps.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cps.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cps.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.cps.multithreading.implementations.DebtLineParserImplementation;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.BatchSubmitLog;
import tr.com.aktifbank.bnspr.dao.CollectionTypePrm;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.aktifbank.bnspr.dao.FileTransferLog;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.icsOnlineDebtLoadingLog;
import tr.com.aktifbank.bnspr.dao.invoiceMain;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class InvoiceDebtLoadingHandler extends RequestHandler {

	private static final int PAGING_SIZE = 100000;
	private static final int MAXIMUM_PAGING_LOOP_COUNT = 10000000;
	private static final String NOPARAMETER = "-1";
	
	private static final class ParameterKeys{
		public static final String DELETEPENDINGS = "BEKLEYENLERI_SIL";
		public static final String STANDINGORDER = "TALIMATLI_YUKLEME";
		public static final String LOADONLYWITHSTANDINGORDER = "SADECE_TALIMAT_VARSA_YUKLE";
		public static final String CONTROLINVOICENO = "FATURA_NO_KONTROL_ET";
		public static final String PROCESSINVOICEWITHCOMMAND = "FATURALARI_KOMUTA_GORE_YUKLE";
		public static final String DELETEWAITINGCOMMANDONHEADER = "BASLIKTA_BEKLEYENLERI_SIL_KOMUTU_VAR";
		public static final String CONTROLINVOICEDUEDATE = "SON_ODEME_TARIHI_KONTROL_ET";
	}
	
	private static final class BagKeys{
		public static final short SubmitId = 1;
		public static final short WaitingInvoicesDeleted = 2;
		public static final short OperationSucceeded = 3;
		public static final short FtmTransferId = 4;
		public static final short CorporateCode = 5;
		public static final short ErrorCode = 6;
		public static final short ErrorMessage = 7;
	}
	
	Date currentDate;
	
	public InvoiceDebtLoadingHandler() {
		super();
		currentDate = new Date();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		if( input.containsKey("IS_TRIGGER_AGAIN") ){
			if( input.getBoolean("IS_TRIGGER_AGAIN") ){
				checkBatchSubmit(input);
			}
		}
		
		String submitId = input.getString(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID);
		String newSubmitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		input.put(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID, newSubmitId);
		bag.put(BagKeys.SubmitId, submitId);
		bag.put(BagKeys.OperationSucceeded, false);
		bag.put(BagKeys.WaitingInvoicesDeleted, false);
		
		BigDecimal ftmTransferId = input.getBigDecimal(TransactionConstants.GeneralBatchSubmit.Input.FTM_TRANSFER_ID);
		bag.put(BagKeys.FtmTransferId, ftmTransferId);
		bag.put(BagKeys.CorporateCode, input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE));
		
		if(isSubmitIdExists(submitId)){
			logger.warn(String.format("Tried to call service with existing submit id : %s", submitId));
			return;
		}
		
		CommonBusinessOperations.insertBatchSubmitLog(input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE), 
				input.getString(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME), null, null, 
				submitId,
				TransactionConstants.InvoiceDebtLoading.SERVICE_NAME, input);
		if(!CommonBusinessOperations.isCorporateActive(input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE))){
			throw new BatchComponentException(BusinessException.CORPORATEISNOTACTIVE, input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE));
		}
		
		int totalLineCount = controlDuplicateLine(ftmTransferId);
		
		String formatOid = input.getString(TransactionConstants.GeneralBatchSubmit.Input.FORMAT_OID);
		
		GMMap headerFormats = callFormatServices(TransactionConstants.GetFileHeaderFormat.SERVICE_NAME, formatOid);
		GMMap detailFormat = callFormatServices(TransactionConstants.GetFileDetailFormat.SERVICE_NAME, formatOid);
		GMMap footerFormats = callFormatServices(TransactionConstants.GetFileFooterFormat.SERVICE_NAME, formatOid);
		
		List<FormatDetail> headerDetails = (List<FormatDetail>)headerFormats.get(TransactionConstants.GetFileHeaderFormat.Output.HEADER_FORMATS);
		List<FormatDetail> bodyDetail = (List<FormatDetail>)detailFormat.get(TransactionConstants.GetFileDetailFormat.Output.DETAIL_FORMAT);
		List<FormatDetail> footerDetails = (List<FormatDetail>)footerFormats.get(TransactionConstants.GetFileFooterFormat.Output.FOOTER_FORMATS);
		
		List<ItemDatabaseField> databaseFields = this.getDatabaseFields();
		List<ItemServiceField> serviceFields = this.getServiceFields();
		
		String corporateCode = input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE);
		String serviceName = TransactionConstants.InsertInvoice.SERVICE_NAME;
		boolean loadOnlyStandingOrderExists = false;
		boolean controlInvoiceNo = true;
		boolean controlInvoiceDueDate = true;
		if(input.containsKey(TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS)){
			BatchParameterEngine engine = new BatchParameterEngine(input.getString(TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS));
			Map<String, String> decomposedParameters = engine.getDecomposedParameters();
			if(decomposedParameters.containsKey(ParameterKeys.DELETEPENDINGS) && 
					DatabaseConstants.BatchParameterValues.DeleteAndLoadEnabled.equals(decomposedParameters.get(ParameterKeys.DELETEPENDINGS))){
				GMMap deleteWaitedInvoice = new GMMap();
				deleteWaitedInvoice.put(TransactionConstants.DeleteWaitedInvoice.Input.CORPORATE_CODE, corporateCode);
				deleteWaitedInvoice.put(TransactionConstants.DeleteWaitedInvoice.Input.FTM_TRANSFER_ID, ftmTransferId);
				super.callGraymoundServiceOutsideSession(TransactionConstants.DeleteWaitedInvoice.SERVICE_NAME, deleteWaitedInvoice);
				bag.put(BagKeys.WaitingInvoicesDeleted, true);
			}
			
			if(decomposedParameters.containsKey(ParameterKeys.STANDINGORDER) && 
					DatabaseConstants.BatchParameterValues.LoadWithStandingOrderEnabled.equals(decomposedParameters.get(ParameterKeys.STANDINGORDER))){
				serviceName = TransactionConstants.InsertStandingOrderInvoice.SERVICE_NAME;
			}
			
			if(decomposedParameters.containsKey(ParameterKeys.LOADONLYWITHSTANDINGORDER) && 
					DatabaseConstants.BatchParameterValues.LoadOnlyWithStandingOrder.equals(decomposedParameters.get(ParameterKeys.LOADONLYWITHSTANDINGORDER))){
				loadOnlyStandingOrderExists = true;
			}
			else{
				loadOnlyStandingOrderExists = false;
			}
			
			if(decomposedParameters.containsKey(ParameterKeys.CONTROLINVOICENO)){
				if(DatabaseConstants.BatchParameterValues.ControlInvoiceNoEnabled.equals(decomposedParameters.get(ParameterKeys.CONTROLINVOICENO))){
					controlInvoiceNo = true;
				}
				else{
					controlInvoiceNo = false;
				}
			}
			
			if(decomposedParameters.containsKey(ParameterKeys.PROCESSINVOICEWITHCOMMAND)){
				if(DatabaseConstants.BatchParameterValues.ProcessInvoiceWithCommandEnabled.equals(decomposedParameters.get(ParameterKeys.PROCESSINVOICEWITHCOMMAND))){
					serviceName = TransactionConstants.ProcessInvoiceWithCommand.SERVICE_NAME;
				}
			}
			
			if(decomposedParameters.containsKey(ParameterKeys.DELETEWAITINGCOMMANDONHEADER)){
				if(!(Boolean)bag.get(BagKeys.WaitingInvoicesDeleted)){
					if(DatabaseConstants.BatchParameterValues.DeleteWaitingCommandOnHeaderEnabled.equals(decomposedParameters.get(ParameterKeys.DELETEWAITINGCOMMANDONHEADER))){
						String commandOnHeader = this.getCommandFromHeader(ftmTransferId, headerDetails, databaseFields);
						GMMap conversionRequest = new GMMap();
						conversionRequest.put("CURRENT_ROW", new GMMap().put("CORPORATE_CODE", corporateCode));
						conversionRequest.put("PARAMETER", commandOnHeader);
						conversionRequest.put("THROW_EXCEPTION", false);
						String convertedCommand = super.callGraymoundServiceInSession("CPS_FTS_GET_CORPORATE_PARAMETER_VALUE", conversionRequest).getString(MapKeys.FTS_OUTPUT_DATA);
						
						if(DatabaseConstants.InvoicePreProcessCommands.DeletePendings.equals(convertedCommand)){
							GMMap deleteWaitedInvoice = new GMMap();
							deleteWaitedInvoice.put(TransactionConstants.DeleteWaitedInvoice.Input.CORPORATE_CODE, corporateCode);
							deleteWaitedInvoice.put(TransactionConstants.DeleteWaitedInvoice.Input.FTM_TRANSFER_ID, ftmTransferId);
							super.callGraymoundServiceOutsideSession(TransactionConstants.DeleteWaitedInvoice.SERVICE_NAME, deleteWaitedInvoice);
							bag.put(BagKeys.WaitingInvoicesDeleted, true);
						}
					}
				}
			}
			
			if(decomposedParameters.containsKey(ParameterKeys.CONTROLINVOICEDUEDATE)){
				if(!DatabaseConstants.BatchParameterValues.ControlInvoiceDueDateEnabled.equals(decomposedParameters.get(ParameterKeys.CONTROLINVOICEDUEDATE))){
					controlInvoiceDueDate = false;
				}
			}
		}
		
		this.setActiveInvoicesToCache(corporateCode, (String)bag.get(BagKeys.SubmitId));
		
		DebtLoadingProcessInformation information = new DebtLoadingProcessInformation();
		information.setBodyDetails(bodyDetail);
		information.setCommitCount(input.getInt(TransactionConstants.GeneralBatchSubmit.Input.COMMIT_COUNT));
		information.setCorporateCode(corporateCode);
		information.setDatabaseFields(databaseFields);
		information.setErrorThreshold(input.getInt(TransactionConstants.GeneralBatchSubmit.Input.THRESHOLD));
		information.setFooterDetails(footerDetails);
		information.setFtmTransferId(ftmTransferId);
		information.setHeaderDetails(headerDetails);
		information.setServiceFields(serviceFields);
		information.setServiceName(serviceName);
		information.setThreadCount(input.getInt(TransactionConstants.GeneralBatchSubmit.Input.THREAD_COUNT));
		information.setTotalLineCount(totalLineCount);
		information.setBatchSubmitId(submitId);
		information.setFtmId(input.getString(TransactionConstants.GeneralBatchSubmit.Input.FTM_ID));
		information.setLoadOnlyStandingOrderExists(loadOnlyStandingOrderExists);
		information.setControlInvoiceNo(controlInvoiceNo);
		information.setControlInvoiceDueDate(controlInvoiceDueDate);
		if(information.getErrorThreshold() < information.getTotalLineCount()){
			if(information.getErrorThreshold() < information.getThreadCount()){
				information.setControlLoopCount(1);
			}
			else{
				information.setControlLoopCount(information.getErrorThreshold() / information.getThreadCount());
			}
		}
		else{
			information.setControlLoopCount(-1);
		}
		
		DebtLineParserImplementation implementation = new DebtLineParserImplementation(information);
		implementation.execute();
		
		processResult(ftmTransferId, corporateCode, implementation, submitId);
	}
	
	private void checkBatchSubmit(GMMap input) {
		
		String ftmId = input.getString("FTM_ID");
		String ftmTransferId = input.getString("FTM_TRANSFER_ID");
		CorporateFileTransfer corporateFileTransfer = getCorporateFileTransfers(ftmId);
		String corporateCode = corporateFileTransfer.getCorporateCode();
		String batchName = corporateFileTransfer.getBatchName();
		GMMap batchDetailMap = getBatchDetails(corporateCode, batchName);
		
		if( batchDetailMap.containsKey(TransactionConstants.GetBatchDetail.Output.COMMIT_COUNT) ){
			input.put(TransactionConstants.GeneralBatchSubmit.Input.COMMIT_COUNT, batchDetailMap.getString(TransactionConstants.GetBatchDetail.Output.COMMIT_COUNT));
		}
		
		if( batchDetailMap.containsKey(TransactionConstants.GetBatchDetail.Output.THREAD_COUNT) ){
			input.put(TransactionConstants.GeneralBatchSubmit.Input.THREAD_COUNT, batchDetailMap.getString(TransactionConstants.GetBatchDetail.Output.THREAD_COUNT));
		}
		
		if( batchDetailMap.containsKey(TransactionConstants.GetBatchDetail.Output.THRESHOLD) ){
			input.put(TransactionConstants.GeneralBatchSubmit.Input.THRESHOLD, batchDetailMap.getString(TransactionConstants.GetBatchDetail.Output.THRESHOLD));
		}
		
		input.put(TransactionConstants.GeneralBatchSubmit.Input.FORMAT_OID, corporateFileTransfer.getFormatId());
		
		String batchOid = batchDetailMap.getString("CORPORATE_BATCH_PROCESS_OID");
		GMMap batchParameters = getBatchParameters(batchOid);
		String composedBatchParameters = getComposedBatchParameters(batchParameters);
		if (!composedBatchParameters.equals(NOPARAMETER)) {
			input.put(
					TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS,
					composedBatchParameters);
		}
		else{
			input.put(
					TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS,
					composedBatchParameters);
			input.put("PARAMETERS_EXISTS", false);
		}
		
		updateInvoiceByFtmSequenceNumber(ftmTransferId);
		
		
	}

	private void updateInvoiceByFtmSequenceNumber(String ftmId) {
		
		GMMap input = new GMMap();
		input.put(TransactionConstants.UpdateInvoiceDebtProces.Input.FTM_SEQUENCE_NUMBER, ftmId);
		
		CommonHelper.callGraymoundServiceOutsideSession(TransactionConstants.UpdateInvoiceDebtProces.SERVICE_NAME, input);
		
		
	}

	private CorporateFileTransfer getCorporateFileTransfers(String ftmId) {
		Criteria criteria = super.getHibernateSession().createCriteria(CorporateFileTransfer.class);
		criteria.add(Restrictions.eq("ftmId", new BigDecimal(ftmId)));
		criteria.add(Restrictions.eq("transferType", (short)TransferTypes.InvoiceLoading));
		criteria.add(Restrictions.eq("status", true));
		criteria.add(Restrictions.or(Restrictions.eq("complexFileTransfer", false), Restrictions.isNull("complexFileTransfer")));
		return (CorporateFileTransfer)criteria.uniqueResult();
	}
	
	private GMMap getBatchDetails(String corporateCode, String batchName) {
		GMMap getBatchDetailRequest = new GMMap();
		getBatchDetailRequest
				.put(TransactionConstants.GetBatchDetail.Input.BATCH_NAME,
						batchName);
		getBatchDetailRequest.put(
				TransactionConstants.GetBatchDetail.Input.CORPORATE_CODE,
				corporateCode);
		return super.callGraymoundServiceInSession(
				TransactionConstants.GetBatchDetail.SERVICE_NAME,
				getBatchDetailRequest);
	}
	
	private GMMap getBatchParameters(String batchOid) {
		GMMap getBatchParametersRequest = new GMMap();
		getBatchParametersRequest
				.put(TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID,
						batchOid);
		return super.callGraymoundServiceInSession(
				TransactionConstants.GetBatchParameters.SERVICE_NAME,
				getBatchParametersRequest);
	}
	
	private String getComposedBatchParameters(GMMap batchParameters) {
		return batchParameters
				.getString(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS, NOPARAMETER);
	}

	private String getCommandFromHeader(BigDecimal ftmTransferId, List<FormatDetail> headerDetails, List<ItemDatabaseField> databaseFields) throws Exception {
		if(headerDetails != null && headerDetails.size() > 0){
			String headerConstant = headerDetails.get(0).getInitialConstant();
			FtmFileContent content = (FtmFileContent)super.getHibernateSession().createCriteria(FtmFileContent.class)
					.add(Restrictions.eq("ftmProcessOid", ftmTransferId))
					.add(Restrictions.like("line", headerConstant, MatchMode.START))
					.uniqueResult();
			
			if(content != null){
				FormatDetail commandDetailFound = null;
				for (FormatDetail detail : headerDetails) {
					String databaseFieldNameFound = null;
					for (ItemDatabaseField field : databaseFields) {
						if(field.getOid().equals(detail.getDatasourceReference())){
							databaseFieldNameFound = field.getDbField();
							break;
						}
					}
					
					if(!StringUtil.isEmpty(databaseFieldNameFound)){
						if(databaseFieldNameFound.equals(DatabaseConstants.HeaderIndicators.HEADER_PROCESS_COMMAND)){
							commandDetailFound = detail;
							break;
						}
					}
				}
				
				if(commandDetailFound != null){
					int startIndex = commandDetailFound.getStartIndis().intValue();
					int length = commandDetailFound.getLength().intValue();
					return content.getLine().substring(startIndex - 1, startIndex - 1 + length);
				}
				else{
					throw new Exception("No header process command found in detail formats");
				}
			}
			else{
				throw new Exception("No header line found to extract command for ftmTransferId : " + ftmTransferId);
			}
		}
		else{
			throw new Exception("No header line found to extract command for ftmTransferId : " + ftmTransferId);
		}
	}

	@SuppressWarnings("unchecked")
	private List<ItemServiceField> getServiceFields() {
		return (List<ItemServiceField>)super.callServiceWithParams(TransactionConstants.GetServiceFields.SERVICE_NAME)
				.get(TransactionConstants.GetServiceFields.Output.FIELDS);
	}

	@SuppressWarnings("unchecked")
	private void setActiveInvoicesToCache(String corporateCode, String submitId) throws Exception {
		ConcurrentSkipListSet<String> existingInvoiceList = new ConcurrentSkipListSet<String>();
		int pageNumber = 0;
		boolean nextPageExists = true;
		while(nextPageExists && pageNumber < MAXIMUM_PAGING_LOOP_COUNT){
			List<invoiceMain> buffer = super.getHibernateSession().createCriteria(invoiceMain.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.disjunction()
							.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Waiting))
							.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
							.add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.PartialCollected)))
					.setFirstResult(pageNumber * PAGING_SIZE)
					.setMaxResults((pageNumber + 1) * PAGING_SIZE)
					.list();
			for (invoiceMain main : buffer) {
				String indicatorString = StringUtil.isEmpty(main.getInvoiceNo()) ? "" : main.getInvoiceNo();
				indicatorString = StringUtil.isEmpty(main.getInvoiceDueDate()) ? indicatorString : indicatorString.concat(main.getInvoiceDueDate());
				indicatorString = indicatorString.concat(new GMMap().put("TEMP", main.getAmount()).getString("TEMP"));
				indicatorString = indicatorString.concat(main.getSubscriberNo1());
				if(!StringUtil.isEmpty(main.getSubscriberNo2())){
					indicatorString = indicatorString.concat(main.getSubscriberNo2());
				}
				if(!StringUtil.isEmpty(main.getSubscriberNo3())){
					indicatorString = indicatorString.concat(main.getSubscriberNo3());
				}
				if(!StringUtil.isEmpty(main.getSubscriberNo4())){
					indicatorString = indicatorString.concat(main.getSubscriberNo4());
				}
				existingInvoiceList.add(indicatorString);
			}
			if(buffer.size() < PAGING_SIZE){
				nextPageExists = false;
			}
			pageNumber++;
		}
		
		SingleInstanceMemory.getInstance().createNewCache(submitId, existingInvoiceList);
		
		super.getHibernateSession().flush();
		
	}

	private int controlDuplicateLine(BigDecimal transferId) throws Exception {
		int totalLineCount = getTotalLineCountFromFileContent(transferId);
		int notEmptyLineCount = Integer.valueOf(DALUtil.getResult(String.format(InvoiceDebtLoadingHandlerRepository.NOT_EMPTY_LINE_COUNT_QUERY, transferId)));
		int distinctLineCount = Integer.valueOf(DALUtil.getResult(String.format(InvoiceDebtLoadingHandlerRepository.CONTROL_DUPLICATE_LINE_QUERY,
				transferId)));
		if(notEmptyLineCount != distinctLineCount){
			throw new Exception("Dosyada iki ayn� sat�r bulunmaktad�r.");
		}
		else{
			return totalLineCount;
		}
	}

	private boolean isSubmitIdExists(String submitId) {
		int count = CommonHelper.getCountOfRows(super.getHibernateSession(), BatchSubmitLog.class, "batchSubmitId", submitId);
		return count > 0;
	}

	private int getTotalLineCountFromFileContent(BigDecimal ftmTransferId) {
		return CommonHelper.getCountOfRows(super.getHibernateSession(), FtmFileContent.class, "ftmProcessOid", ftmTransferId);
	}
	
	private void processResult(BigDecimal ftmTransferId, String corporateCode, DebtLineParserImplementation implementation, String submitId) {
		updateFileTransferLog(implementation, submitId);
		if(implementation.isHasError()){
			CommonBusinessOperations.updateBatchSubmitLog(bag.get(BagKeys.SubmitId).toString(), 
					DatabaseConstants.SubmitStatuses.FAILURE, 
					new Date(),
					implementation.getErrorCode(), 
					implementation.getErrorMessage());
			bag.put(BagKeys.ErrorCode, implementation.getErrorCode());
			bag.put(BagKeys.ErrorMessage, implementation.getErrorMessage());
		}
		else{
			bag.put(BagKeys.OperationSucceeded, true);
			updateInvoiceItemStatusToActive(corporateCode, ftmTransferId);
			CommonBusinessOperations.updateBatchSubmitLog(bag.get(BagKeys.SubmitId).toString(), DatabaseConstants.SubmitStatuses.SUCESSFUL, new Date(), null, null);
		}
	}

	private void updateFileTransferLog(DebtLineParserImplementation implementation, String submitId) {
		final int maxTryCount = 3;
		int count = 0;
		FileTransferLog log = (FileTransferLog) super.getHibernateSession().createCriteria(FileTransferLog.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("batchSubmitId", submitId))
				.uniqueResult();
		
		while(log == null && count++ < maxTryCount){
			try {
				Thread.sleep(10000);
			} catch (Exception e) {
				logger.error(System.currentTimeMillis(), e);
			}
			log = (FileTransferLog) super.getHibernateSession().createCriteria(FileTransferLog.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("batchSubmitId", submitId))
					.uniqueResult();
		}
		
		if(log != null){
			log.setTotalAmount(implementation.getTotalAmount());
			log.setTotalLineCount((long)implementation.getTotalLineCount());
			log.setTotalLoadAmount(implementation.getLoadedAmount());
			log.setTotalLoadCount((long)implementation.getLoadedCount());
			super.getHibernateSession().saveOrUpdate(log);
			super.getHibernateSession().flush();
		}
		
	}

	@SuppressWarnings("unchecked")
	private List<ItemDatabaseField> getDatabaseFields() throws Exception {
		return (List<ItemDatabaseField>)super.callServiceWithParams(TransactionConstants.GetDatabaseFields.SERVICE_NAME)
				.get(TransactionConstants.GetDatabaseFields.Output.FIELDS);
	}

	private void updateInvoiceItemStatusToActive(String corporateCode,
			BigDecimal ftmTransferId) {
		String query = String.format(InvoiceDebtLoadingHandlerRepository.UPDATE_INVOICE_STATUS_ACTIVE_COMMAND, corporateCode, ftmTransferId);
		CommonHelper.getHibernateSession().createSQLQuery(query).executeUpdate();
	}

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		this.handleError(e, output);
	}

	@Override
	protected void handleError(Throwable e, GMMap output) {
		logger.error(System.currentTimeMillis(), e);
		String errorCode = "1";
		String errorMessage = String.format("An exception occured while executing invoice debt loading. %s", CommonHelper.getStringifiedException(e));
		if(e instanceof BatchComponentException){
			BatchComponentException exception = (BatchComponentException)e;
			errorCode = String.valueOf(exception.getCode());
			errorMessage = exception.getMessage();
		}
		bag.put(BagKeys.ErrorCode, errorCode);
		bag.put(BagKeys.ErrorMessage, errorMessage);
		CommonBusinessOperations.updateBatchSubmitLog(bag.get(BagKeys.SubmitId).toString(), DatabaseConstants.SubmitStatuses.FAILURE, new Date(), errorCode, errorMessage);
	}
	
	@Override
	protected void handleFinally(GMMap output) {
		try{
			SingleInstanceMemory.getInstance().removeCache((String)bag.get(BagKeys.SubmitId));
		}
		catch(Exception e){
			logger.error("An exception occured while removing invoice cache");
			logger.error(System.currentTimeMillis(), e);
		}
		if(!(Boolean)bag.get(BagKeys.OperationSucceeded)){
			if((Boolean)bag.get(BagKeys.WaitingInvoicesDeleted)){
				try{
					rollbackWaitingInvoicesDeletion();
				}
				catch(Exception e){
					logger.error(String.format("An error occured while rollbacking waiting invoices with transfer id %s", bag.get(BagKeys.FtmTransferId)));
					logger.error(System.currentTimeMillis(), e);
				}
			}
			sendEmailOfFailedOperation();
		}
		else{
			sendEmailNotificationForStandingOrderLog(CommonHelper.getShortDateTimeString(currentDate), (String)bag.get(BagKeys.SubmitId));
		}
	}
	
	@SuppressWarnings("unchecked")
	private void sendEmailNotificationForStandingOrderLog(String processDate, String submitId) {
		try{
			List<icsOnlineDebtLoadingLog> logs = super.getHibernateSession().createCriteria(icsOnlineDebtLoadingLog.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("batchSubmitId", submitId))
					.list();
			
			if(logs.size() > 0){
				String corporateCode = logs.get(0).getCorporateCode();
				String corporateName = CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(corporateCode);
				
				List<Map<String,String>> detailMapList = new ArrayList<Map<String,String>>();
				
				List<CollectionTypePrm> collectionTypes = super.getHibernateSession().createCriteria(CollectionTypePrm.class).list();
				
				Map<Short, String> collectionTypeMapping = new HashMap<Short, String>();
				
				for (CollectionTypePrm prm : collectionTypes) {
					collectionTypeMapping.put(prm.getCollectionType(), prm.getCollectionName());
				}
				
				for (icsOnlineDebtLoadingLog log : logs) {
					Map<String, String> logMap = new HashMap<String, String>();
					logMap.put("ROW_CORPORATE_NAME", corporateName);
					logMap.put("ROW_CORPORATE_CODE", log.getCorporateCode());
					logMap.put("ROW_COL_TYPE", collectionTypeMapping.get(log.getCollectionType()));
					logMap.put("ROW_SUB_NO1", log.getSubscriberNo1());
					logMap.put("ROW_SUB_NO2", log.getSubscriberNo2());
					logMap.put("ROW_SUB_NO3", log.getSubscriberNo3());
					logMap.put("ROW_SUB_NO4", log.getSubscriberNo4());
					logMap.put("ROW_DUE_DATE", CommonHelper.formatDateString(log.getInvoiceDueDate(), "yyyyMMdd", "dd/MM/yyyy"));
					logMap.put("ROW_INV_AMOUNT", CommonHelper.applyDecimalFormat(log.getInvoiceAmount().toPlainString()));
					logMap.put("ROW_ERR_CODE", log.getErrorCode());
					logMap.put("ROW_ERR_MESSAGE", log.getErrorDesc());
					
					detailMapList.add(logMap);
				}
				
				String receiptList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST","EMAIL_RECEIPT_LIST_4_STD_ORDER_LOAD");
				
				GMMap messageMap = new GMMap();
				messageMap.put("MAP_TABLE", detailMapList);
				
				GMMap subjectMap = new GMMap();
				subjectMap.put("PROCESS_DATE",CommonHelper.formatDateString(processDate, "yyyyMMdd", "dd/MM/yyyy"));
				subjectMap.put("CORPORATE_NAME", corporateName);
				
				EmailMessage emailMessage = CommonHelper.prepareEmailBody("", messageMap,NotificationMessageConstant.Email.OnlineStandingOrderDebtLoadingMessageConstant.MESSAGE_BODY,
						CommonHelper.generateSubject("CORPORATE_NAME Offline Kurumu ��in PROCESS_DATE G�n� Talimatl� Bor�lar� Y�klenemeyen Aboneler Raporu",subjectMap),receiptList);
				
				CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
			}
		}
		catch(Exception e){
			logger.error("An exception occured while sending email notification for standing order loading logs");
			logger.error(System.currentTimeMillis(), e);
		}
	}

	private void sendEmailOfFailedOperation() {
		try {
			String corporateCode = (String) bag.get(BagKeys.CorporateCode);
			String corporateName = CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(corporateCode);
			
			GMMap messageBodyMap = new GMMap();
			messageBodyMap.put("CORPORATE_NAME", corporateName);
			messageBodyMap.put("CORPORATE_CODE", corporateCode);
			messageBodyMap.put("ERROR_CODE", bag.get(BagKeys.ErrorCode));
			messageBodyMap.put("ERROR_MESSAGE", bag.get(BagKeys.ErrorMessage));
			
			EmailMessage message = CommonHelper.prepareEmailBody(corporateName, 
					messageBodyMap, 
					NotificationMessageConstant.Email.OfflineDebtLoadingErrorMessageConstant.MESSAGE_BODY, 
					NotificationMessageConstant.Email.OfflineDebtLoadingErrorMessageConstant.SUBJECT, 
					CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_DEBT_LOAD_FAIL"));
			
			CommonHelper.sendMail(message.getReceiptList(), null, message.getFrom(), true, message.getSubject(), message.getBody(), true);
		} catch (Exception e) {
			logger.error("An exception occured while sending failed debt loading mail for corporate code : " + (String) bag.get(BagKeys.CorporateCode));
			logger.error(System.currentTimeMillis(), e);
		}
	}

	private void rollbackWaitingInvoicesDeletion() {
		String query = String.format(InvoiceDebtLoadingHandlerRepository.ROLLBACK_INVOICE_STATUS_COMMAND, bag.get(BagKeys.FtmTransferId));
		super.getHibernateSession().createSQLQuery(query).executeUpdate();
	}

	private GMMap callFormatServices(String serviceName, String formatOid) {
		return super.callGraymoundServiceInSession(serviceName, new GMMap().put(TransactionConstants.FORMAT_ID_GENERAL_KEY, formatOid));
	}
}
