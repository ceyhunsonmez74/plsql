package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.karamanli.KaramanliClient;
import tr.com.aktifbank.integration.karamanli.ServiceMessage;
import tr.com.karamanli.ArrayOfTahsilat;
import tr.com.karamanli.Tahsilat;
import tr.com.karamanli.TahsilatServiceGetMutabakatByStartAndEndDateInvalidOperationFaultFaultFaultMessage;

import com.graymound.util.GMMap;

public class KaramanliReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(IgdasFicaReconciliationDetailBatch.class);
	Session session;
	List<Tahsilat> details;
	ServiceMessage message;
	Map<String, Tahsilat> indexedCorporateRecords;
	
	public KaramanliReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, Tahsilat>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getBankaReferansNo());
		cancelCollectionRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getReferansNo());
	}

	@SuppressWarnings("unchecked")
	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		Session session = CommonHelper.getHibernateSession();
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String kurumKodu = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			
			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6); 
			
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar reconDate = CommonHelper.convertDate2GregorianCalendar(reconDateString, "yyyy-MM-dd");

			ArrayOfTahsilat response = KaramanliClient.getMutabakatByStartAndEndDate(reqTimeout, connTimeout, url, username, password, this.message, kurumKodu, reconDate, reconDate);
			details = response.getTahsilat();
			result.setSuccessfulCall(true);
		} catch (TahsilatServiceGetMutabakatByStartAndEndDateInvalidOperationFaultFaultFaultMessage f) {
			logger.error("ICS_KARAMANLI_GET_COLLECTION_RECONCILIATION_DETAIL".concat(f.getFaultInfo().getErrorCode().toString()));
			logger.error("ICS_KARAMANLI_GET_COLLECTION_RECONCILIATION_DETAIL".concat(f.getFaultInfo().getErrorMessage().getValue()));
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getBankaReferansNo());
		collectionDetailRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getReferansNo());

	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getBankaReferansNo().getValue(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getBankaReferansNo().getValue());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		Tahsilat corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Abone Numaras� : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getSicilNo(), 
				corporateDetail.getTahsilatNo(), 
				corporateDetail.getToplamTutar()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(CommonHelper.trimStart(corporateDetail.getSicilNo().toString(), '0'));
		payment.setInvoiceNo(corporateDetail.getTahsilatNo().toString());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setParameter2(corporateDetail.getReferansNo().getValue());//transactionId
		payment.setInvoiceAmount(corporateDetail.getToplamTutar());
		payment.setPaymentAmount(corporateDetail.getToplamTutar());
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getSicilNo());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getTahsilatNo());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getToplamTutar());
	}
}
