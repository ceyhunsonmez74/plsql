
package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.StartStandingOrderReconciliationBacthHandlerRepository;
import tr.com.aktifbank.bnspr.cps.dto.StandingOrderReconciliationStarterInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.implementations.StandingOrderReconciliationImplementation;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;


public class StartStandingOrderReconciliationBacthHandler extends RequestHandler {

    @Override
    protected void handleInternal(GMMap input, GMMap output) throws Throwable {
    	
    	String tableNameCorporates = "BATCH_CORPORATES";
		GMMap batchCorporateList = DALUtil.getResults(StartStandingOrderReconciliationBacthHandlerRepository.FETCH_CORPORATES_QUERY, tableNameCorporates);
	
		StandingOrderReconciliationStarterInformation information = new StandingOrderReconciliationStarterInformation();
		
		if (input.containsKey("PROCESS_DATE")) {
			information.getCorporateMap().put("PROCESS_DATE", input.getString("PROCESS_DATE"));
		}else {
			information.getCorporateMap().put("PROCESS_DATE",CommonHelper.getShortDateTimeString(new Date()));
		}
		
		information.setServiceName("STO_STANDING_ORDER_RECONCILIATION");
		information.setMaxParallelThreadCount(5); //paramtext den al�nabilir
		information.setProcessDate(new Date());
		
		for (int i = 0; i < batchCorporateList.getSize(tableNameCorporates); i++) {

			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_BATCH_PROCESS_OID, batchCorporateList.getString(tableNameCorporates, i, MapKeys.BATCH_PROCESS_OID) );
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.BANK_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_BANK_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.BATCH_NAME, batchCorporateList.getString(tableNameCorporates, i, MapKeys.BATCH_NAME));
		}
		
		StandingOrderReconciliationImplementation implementation = new StandingOrderReconciliationImplementation(information);
		implementation.execute();
		
    }
}


