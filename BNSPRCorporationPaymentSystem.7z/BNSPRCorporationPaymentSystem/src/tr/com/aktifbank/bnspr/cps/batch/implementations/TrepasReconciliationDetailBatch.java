package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.trepas.ServiceMessage;
import tr.com.aktifbank.integration.trepas.TrepasClient;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.trepas.ZFICABNKMUTDETAILResponse;
import tr.com.trepas.ZFICASMTBKTDETAILS;
import tr.com.trepas.ZFICATTMTBKTDETAILS;

import com.graymound.util.GMMap;

public final class TrepasReconciliationDetailBatch extends CollectionReconciliationDetailBatch {
	private static final Log logger = LogFactory.getLog(TrepasReconciliationDetailBatch.class);
	Session session;
	List<ZFICASMTBKTDETAILS> details = new ArrayList<ZFICASMTBKTDETAILS>();
	ServiceMessage message;
	Map<String, ZFICASMTBKTDETAILS> indexedCorporateRecords;

	public TrepasReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, ZFICASMTBKTDETAILS>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.SUBSCRIBER_NO1, details.get(corporateRecordIndex).getCONTRACTACCOUNTID());
		cancelCollectionRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getPAYMENTTRANSACTIONID()); // ?
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details.get(corporateRecordIndex).getINVOICEREFERENCEID());
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.PARAMETER2, details.get(corporateRecordIndex).getPAYMENTTRANSACTIONID());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.PARAMETER2));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		ServiceMessage serviceMessage = new ServiceMessage();
		try {
			// Integer bankCode = Integer.parseInt(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1));
			// Integer companyCode = Integer.parseInt(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2));
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String serviceUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			String cashPointRefId = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String cashPointPaymentGroupReferenceID = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER4);

			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6);
			
			Date reconDate = new Date();
			if (!StringUtil.isEmpty(input.getString(MapKeys.RECON_DATE)))
				reconDate = input.getDate(MapKeys.RECON_DATE);

			String groupInId = getUniqueNumberByDateForRecon(cashPointPaymentGroupReferenceID, reconDate);

			String responseCode = "";
			String responseMessage = "";
			ZFICATTMTBKTDETAILS responseTList = null;

			ZFICABNKMUTDETAILResponse zFICABNKMUTDETAILResponse = null;

			zFICABNKMUTDETAILResponse = TrepasClient.zFICABNKMUTDETAIL(reqTimeout, connTimeout, serviceUrl, username, password, serviceMessage, cashPointRefId, groupInId);

			responseCode = zFICABNKMUTDETAILResponse.getEMSGID();
			responseMessage = zFICABNKMUTDETAILResponse.getEMSGTEXT();
			responseTList = zFICABNKMUTDETAILResponse.getTLIST();

			ZFICATTMTBKTDETAILS allDetailsList = responseTList;
			List<ZFICASMTBKTDETAILS> paymentList = new ArrayList<ZFICASMTBKTDETAILS>();
			List<ZFICASMTBKTDETAILS> cancelList = new ArrayList<ZFICASMTBKTDETAILS>();

			for (int i = 0; i < allDetailsList.getItem().size(); i++) {
				String processType = allDetailsList.getItem().get(i).getPROCESSTYPE();

				if (processType.equals("P")) {
					paymentList.add(allDetailsList.getItem().get(i));
				}
				else if (processType.equals("C")) {
					cancelList.add(allDetailsList.getItem().get(i));
				}

			}
			
//			for (int i = 0; i < allDetailsList.getItem().size(); i++) {
//				if (allDetailsList.getItem().get(i).getPROCESSTYPE().equals("P")) {
//					paymentList.add(allDetailsList.getItem().get(i));
//				}
//			}

//			for (int i = 0; i < allDetailsList.getItem().size(); i++) {
//				if (allDetailsList.getItem().get(i).getPROCESSTYPE().equals("C")) {
//					cancelList.add(allDetailsList.getItem().get(i));
//				}
//			}
//
//			for (ZFICASMTBKTDETAILS payment : paymentList) {
//				for (ZFICASMTBKTDETAILS cancel : cancelList) {
//					if (payment.getINVOICEREFERENCEID().equals(cancel.getINVOICEREFERENCEID())) {
//						paymentList.remove(payment);
//					}
//				}
//			}

			details = paymentList;
			result.setSuccessfulCall(true);
		}
		catch (Exception e) {
			logger.error("An exception occured while calling trepas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.PARAMETER2), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getPAYMENTTRANSACTIONID(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getPAYMENTTRANSACTIONID());
	}

	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex) throws Exception {
		ZFICASMTBKTDETAILS corporateDetail = details.get(corporateRecordIndex);
		String aboneNo = corporateDetail.getCONTRACTACCOUNTID();

		logger.info(String.format("Following corporate record has not been found in database. Referans No : %s, Miktar : %s ", corporateDetail.getCONTRACTACCOUNTID(), corporateDetail.getPAYMENTAMOUNT()));

		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo3(aboneNo);
		payment.setInvoiceNo("1");
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setInvoiceAmount(corporateDetail.getPAYMENTAMOUNT());
		payment.setPaymentAmount(corporateDetail.getPAYMENTAMOUNT());
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setParameter1(aboneNo);
		payment.setParameter2(corporateDetail.getCONTRACTACCOUNTID().toString());

		session.saveOrUpdate(payment);
		session.flush();

		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO3, aboneNo);
		collectionDetailResponse.put(MapKeys.INVOICE_NO, "");
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getPAYMENTAMOUNT());
	}

	// mutabakat i�in tekil mutabakat g�n�ne �zel kod
	private static String getUniqueNumberByDateForRecon(String cashPointPaymentGroupReferenceID, Date reconDate) {
		String number = "";
		try {
			// istenilen format -> E30 + Tarih + 001

			SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMdd");
			String activeDate = format1.format(reconDate);
			number = cashPointPaymentGroupReferenceID + activeDate + "001";
			return number;
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return number;
	}

}
