package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.InsertBalanceTransferProcess;
import tr.com.aktifbank.bnspr.dao.BalanceTransferProcess;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class InsertBalanceTransferProcessHandler extends RequestHandler {

	public InsertBalanceTransferProcessHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		boolean isUpdate = input.getBoolean(InsertBalanceTransferProcess.Input.IS_UPDATE, false);
		if(isUpdate){
			byte transferStatus = (byte)input.getInt(InsertBalanceTransferProcess.Input.TRANSFER_STATUS);
			BigDecimal transferAmount = input.getBigDecimal(InsertBalanceTransferProcess.Input.TRANSFER_AMOUNT, null);
			Date transferDate = input.getDate(InsertBalanceTransferProcess.Input.TRANSFER_DATE, null);
			String recordId = input.getString(InsertBalanceTransferProcess.Input.RECORD_ID);
			String transactionNo = input.getString(InsertBalanceTransferProcess.Input.TRANSACTION_NO, null);
			BalanceTransferProcess process = (BalanceTransferProcess)super.getHibernateSession().createCriteria(BalanceTransferProcess.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("oid", recordId))
					.uniqueResult();
			if(process != null){
				process.setTransferStatus(transferStatus);
				if(transferAmount != null){
					process.setTransferAmount(transferAmount);
				}
				if(transferDate != null){
					process.setTransferDate(CommonHelper.getShortDateTimeString(transferDate));
				}
				if(!StringUtil.isEmpty(transactionNo)){
					process.setTxNo(new BigDecimal(transactionNo));
				}
				super.getHibernateSession().saveOrUpdate(process);
				super.getHibernateSession().flush();
			}
			else{
				throw new Exception(String.format("Balance Transfer Process with %s id has not been found", recordId));
			}
		}
		else{
			String corporateCode = input.getString(InsertBalanceTransferProcess.Input.CORPORATE_CODE, null);
			String corporateOid = input.getString(InsertBalanceTransferProcess.Input.CORPORATE_OID, null);
			byte transferStatus = (byte)input.getInt(InsertBalanceTransferProcess.Input.TRANSFER_STATUS);
			BigDecimal transferAmount = input.getBigDecimal(InsertBalanceTransferProcess.Input.TRANSFER_AMOUNT, null);
			Date transferDate = input.getDate(InsertBalanceTransferProcess.Input.TRANSFER_DATE, null);
			Date collectionDate = input.getDate(InsertBalanceTransferProcess.Input.COLLECTION_DATE, null);
			BigDecimal fromAccount = input.getBigDecimal(InsertBalanceTransferProcess.Input.FROM_ACCOUNT, null);
			BigDecimal toAccount = input.getBigDecimal(InsertBalanceTransferProcess.Input.TO_ACCOUNT, null);
			String toIban = input.getString(InsertBalanceTransferProcess.Input.TO_IBAN, null);
			String toIbanOwner = input.getString(InsertBalanceTransferProcess.Input.TO_IBAN_OWNER, null);
			boolean isEftTransfer = input.getBoolean(InsertBalanceTransferProcess.Input.IS_EFT_TRANSFER);
			String transferDefOid = input.getString(InsertBalanceTransferProcess.Input.TRANSFER_DEF_OID);
			String transferType = input.getString(InsertBalanceTransferProcess.Input.TRANSFER_TYPE);
			
			if(StringUtil.isEmpty(corporateCode)){
				GMMap getCorporateResponse = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
						TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid);
				corporateCode = getCorporateResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
			}
			
			BalanceTransferProcess process = new BalanceTransferProcess();
			process.setCorporateCode(corporateCode);
			process.setCollectionDate(CommonHelper
					.getShortDateTimeString(collectionDate));
			process.setFromAccount(fromAccount);
			process.setIsEftTransfer(isEftTransfer ? DatabaseConstants.IsEftTransfers.EFTTransfer : DatabaseConstants.IsEftTransfers.NonEFTTransfer);
			process.setProcessDate(CommonHelper
						.getLongDateTimeString(new Date()));
			process.setStatus(true);
			process.setToAccount(toAccount);
			process.setToIban(toIban);
			process.setToIbanOwner(toIbanOwner);
			process.setTransferAmount(transferAmount != null ? transferAmount : new BigDecimal(0));
			if (transferDate != null) {
				process.setTransferDate(CommonHelper
						.getShortDateTimeString(transferDate));
			}
			process.setTransferStatus(transferStatus);
			process.setTransferDefOid(transferDefOid);
			process.setTransferType(transferType);
			super.getHibernateSession().save(process);
			output.put(InsertBalanceTransferProcess.Output.RECORD_ID, process.getOid());
			super.getHibernateSession().flush();
		}
	}

}
