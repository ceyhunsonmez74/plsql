package tr.com.aktifbank.bnspr.cps.acctransfer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.dao.BalanceTransferDays;
import tr.com.aktifbank.bnspr.dao.BalanceTransferDef;
import tr.com.aktifbank.bnspr.dao.BalanceTransferProcess;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class SendEftTransactionsMailServices {
	
	@GraymoundService("CDM_SENT_EFT_TRANSACTIONS_MAIL_NEXT_DAY")
	public static GMMap sendEftMailNextDay(GMMap input){
		GMMap output = new GMMap();
		
		try{		
			GMMap gtbOutMap = CommonHelper.callGraymoundServiceInHibernateSession("GTB_CALCULATE_EFT_AMOUNT_NEXT_DAY", input);
			GMMap tcsOutMap = CommonHelper.callGraymoundServiceInHibernateSession("TCS_CALCULATE_EFT_AMOUNT_NEXT_DAY", input);
			GMMap cpsOutMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_CALCULATE_EFT_AMOUNT_NEXT_DAY", input);
			GMMap sgkOutMap = CommonHelper.callGraymoundServiceInHibernateSession("SGK_CALCULATE_EFT_AMOUNT_NEXT_DAY", input);	
			Date today = new Date();
			Date nextDay;
			BigDecimal totalAmount = BigDecimal.ZERO;
			
//			List<String> toList = new ArrayList<String>();
			String receiptList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST","EMAIL_RECEIPT_LIST_4_HIGH_AMOUNT_EFT_TRANSACTION");
//			toList.add(receiptList);			
			
			if(CommonHelper.getDayOfWeekInTurkishLocale(today) == 5)
				nextDay = CommonHelper.addDay(today, 3);
			else
				nextDay = CommonHelper.addDay(today, 1);			
			
			String todayStr = CommonHelper.getDateString(today, "dd/MM/yyyy");
			String nextDayStr = CommonHelper.getDateString(nextDay, "dd/MM/yyyy");
			
			
			totalAmount = cpsOutMap.getBigDecimal("TOTAL_AMOUNT").add(tcsOutMap.getBigDecimal("TOTAL_AMOUNT")).add(sgkOutMap.getBigDecimal("TOTAL_AMOUNT")).add(gtbOutMap.getBigDecimal("TOTAL_AMOUNT"));
			
			StringBuilder builder = new StringBuilder();
			builder.append("<html><head><title></title></head><body>");
			builder.append("<table border=\"1\"");
			builder.append(String.format("<tr><td>Aktar�m Tarihi</td><td>Kurum</td><td>Tutar</td></tr>"));
			builder.append(String.format("<tr><td>%s</td><td>Fatura Tahsilatlar�</td><td>%s</td></tr>", nextDayStr, cpsOutMap.getBigDecimal("TOTAL_AMOUNT")));
			builder.append(String.format("<tr><td>%s</td><td>Genel Vergi</td><td>%s</td></tr>", nextDayStr, tcsOutMap.getBigDecimal("TOTAL_AMOUNT")));
			builder.append(String.format("<tr><td>%s</td><td>SGK Tahsilatlar�</td><td>%s</td></tr>", nextDayStr, sgkOutMap.getBigDecimal("TOTAL_AMOUNT")));
			builder.append(String.format("<tr><td>%s</td><td>G�mr�k Vergisi</td><td>%s</td></tr>", nextDayStr, gtbOutMap.getBigDecimal("TOTAL_AMOUNT")));
			builder.append(String.format("<tr><td></td><td>TOPLAM</td><td>%s</td></tr>", totalAmount));
			builder.append("</table></body></html>");
			
			CommonHelper.sendMail(Arrays.asList(receiptList.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, todayStr + " tarihinde tahsilat� yap�lm�� EFT i�lemleri", builder.toString());
			
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_SENT_EFT_TRANSACTIONS_MAIL_TOTAL")
	public static GMMap sendEftMailTotal(GMMap input){
		GMMap output = new GMMap();
		
		try{		
			GMMap gtbOutMap = CommonHelper.callGraymoundServiceInHibernateSession("GTB_CALCULATE_EFT_AMOUNT_TOTAL", input);
			GMMap tcsOutMap = CommonHelper.callGraymoundServiceInHibernateSession("TCS_CALCULATE_EFT_AMOUNT_TOTAL", input);
			GMMap cpsOutMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_CALCULATE_EFT_AMOUNT_TOTAL", input);
			GMMap sgkOutMap = CommonHelper.callGraymoundServiceInHibernateSession("SGK_CALCULATE_EFT_AMOUNT_TOTAL", input);
			Date nextDay = CommonHelper.addDay(new Date(), 1);
			BigDecimal totalAmount = BigDecimal.ZERO;
			String nextDayStr = CommonHelper.getDateString(nextDay, "dd/MM/yyyy");
//			List<String> toList = new ArrayList<String>();
			String receiptList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST","EMAIL_RECEIPT_LIST_4_HIGH_AMOUNT_EFT_TRANSACTION");
//			toList.add(receiptList);
			
			totalAmount = cpsOutMap.getBigDecimal("TOTAL_AMOUNT").add(tcsOutMap.getBigDecimal("TOTAL_AMOUNT")).add(sgkOutMap.getBigDecimal("TOTAL_AMOUNT")).add(gtbOutMap.getBigDecimal("TOTAL_AMOUNT"));
			
			StringBuilder builder = new StringBuilder();
			builder.append("<html><head><title></title></head><body>");
			builder.append("<table border=\"1\"");
			builder.append(String.format("<tr><td>Aktar�m Tarihi</td><td>Kurum</td><td>Tutar</td></tr>"));
			builder.append(String.format("<tr><td>%s</td><td>Fatura Tahsilatlar�</td><td>%s</td></tr>", nextDayStr, cpsOutMap.getBigDecimal("TOTAL_AMOUNT")));
			builder.append(String.format("<tr><td>%s</td><td>Genel Vergi</td><td>%s</td></tr>", nextDayStr, tcsOutMap.getBigDecimal("TOTAL_AMOUNT")));
			builder.append(String.format("<tr><td>%s</td><td>SGK Tahsilatlar�</td><td>%s</td></tr>", nextDayStr, sgkOutMap.getBigDecimal("TOTAL_AMOUNT")));
			builder.append(String.format("<tr><td>%s</td><td>G�mr�k Vergisi</td><td>%s</td></tr>", nextDayStr, gtbOutMap.getBigDecimal("TOTAL_AMOUNT")));
			builder.append(String.format("<tr><td></td><td>TOPLAM</td><td>%s</td></tr>", totalAmount));
			builder.append("</table></body></html>");
			
			CommonHelper.sendMail(Arrays.asList(receiptList.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, nextDayStr + " tarihinde yap�lacak EFT ��k�� i�lemleri", builder.toString());
			
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CALCULATE_EFT_AMOUNT_NEXT_DAY")
	public static GMMap calculateEftAmountNextDay(GMMap input){
		GMMap output = new GMMap();
		
		try{			
			Session session = CommonHelper.getHibernateSession();
			Date today = new Date();
			String todayStr = CommonHelper.getShortDateTimeString(today);
			List<BalanceTransferDef> eftBalanceTransferDefList = new ArrayList<BalanceTransferDef>();
			List<BigDecimal> nonEftFromAccountNoList = new ArrayList<BigDecimal>();
			List<BalanceTransferDef> nonEftBalanceTransferDefList = new ArrayList<BalanceTransferDef>();
			List<BalanceTransferDef> eftTransferAfterDayList = new ArrayList<BalanceTransferDef>();		
			List<BalanceTransferDef> nonEftTransferAfterDayList = new ArrayList<BalanceTransferDef>();	
			BigDecimal totalAmount = BigDecimal.ZERO;			
			int dayOfWeek = CommonHelper.getDayOfWeekInTurkishLocale(today);
			int nextDay;
			
			if(dayOfWeek == 5){
				nextDay = 1;
			}else{
				nextDay = dayOfWeek + 1;
			}
			
			eftBalanceTransferDefList = getBalanceTransferDefList(DatabaseConstants.AccountDefinitionTypes.CollectionAccount, DatabaseConstants.AccountDefinitionTypes.EftAccount);			
			
			nonEftFromAccountNoList = session.createCriteria(BalanceTransferDef.class)
											 .add(Restrictions.eq("status", true))
											 .add(Restrictions.eq("fromAccountType", DatabaseConstants.AccountDefinitionTypes.UsageAccount))
											 .add(Restrictions.eq("toAccountType", DatabaseConstants.AccountDefinitionTypes.EftAccount))
											 .setProjection(Projections.property("fromAccountNo"))
											 .list();	
			
			if(!nonEftFromAccountNoList.isEmpty()){
				nonEftBalanceTransferDefList = session.createCriteria(BalanceTransferDef.class)
													  .add(Restrictions.eq("status", true))
													  .add(Restrictions.eq("fromAccountType", DatabaseConstants.AccountDefinitionTypes.CollectionAccount))
													  .add(Restrictions.eq("toAccountType", DatabaseConstants.AccountDefinitionTypes.UsageAccount))
													  .add(Restrictions.in("toAccountNo", nonEftFromAccountNoList))
													  .add(Restrictions.eq("transferDayCount", new BigDecimal("1").shortValue()))
													  .list();	
			}
			
			nonEftBalanceTransferDefList.addAll(eftBalanceTransferDefList);
			
            List<String> transferAfterDayList =  session.createCriteria(BalanceTransferDays.class)
            									.add(Restrictions.eq("status", true))
            									.add(Restrictions.eq("inDayOfEachWeek", new Integer(dayOfWeek).toString()))
            									.add(Restrictions.eq("outDayOfEachWeek", new Integer(nextDay).toString()))
            									.setProjection(Projections.property("balanceTransferOid"))
            									.list();
            
            if(transferAfterDayList != null && !transferAfterDayList.isEmpty()){
                eftTransferAfterDayList = session.createCriteria(BalanceTransferDef.class)
            				 .add(Restrictions.eq("status", true))
            				 .add(Restrictions.eq("fromAccountType", DatabaseConstants.AccountDefinitionTypes.CollectionAccount))
            				 .add(Restrictions.eq("toAccountType", DatabaseConstants.AccountDefinitionTypes.EftAccount))
            				 .add(Restrictions.eq("transferDayOption", new Byte("2").byteValue()))
            				 .add(Restrictions.in("oid", transferAfterDayList))                        				
            				 .list();
            }
            
            if(transferAfterDayList != null && !transferAfterDayList.isEmpty() && !nonEftFromAccountNoList.isEmpty()){
                nonEftTransferAfterDayList = session.createCriteria(BalanceTransferDef.class)
            				      .add(Restrictions.eq("status", true))
            				      .add(Restrictions.eq("fromAccountType", DatabaseConstants.AccountDefinitionTypes.CollectionAccount))
            				      .add(Restrictions.eq("toAccountType", DatabaseConstants.AccountDefinitionTypes.UsageAccount))
            				      .add(Restrictions.eq("transferDayOption", new Byte("2").byteValue()))			
            				      .add(Restrictions.in("toAccountNo", nonEftFromAccountNoList))
            				      .add(Restrictions.in("oid", transferAfterDayList))
            				      .list();
            }		
            
            nonEftTransferAfterDayList.addAll(eftTransferAfterDayList);
			
			nonEftBalanceTransferDefList.addAll(nonEftTransferAfterDayList);
			
			List<BalanceTransferDef> transferDefList = removeDuplicateDefRecords(nonEftBalanceTransferDefList);
			
			for(Iterator it = transferDefList.iterator(); it.hasNext();){
				Object[] row = (Object[]) it.next();
				String corporateCode = getCorporateCode(row[1].toString());
				BigDecimal corporateAccountNo = (BigDecimal) row[0];
				
				BigDecimal invoicePayment = (BigDecimal) session.createCriteria(invoicePayment.class)
																		.add(Restrictions.like("paymentDate", todayStr + "%"))
																		.add(Restrictions.eq("corporateCode", corporateCode))
																		.add(Restrictions.eq("corporateAccountNo", corporateAccountNo))
																		.setProjection(Projections.sum("paymentAmount"))
																		.uniqueResult();
				
				if(invoicePayment != null){
					totalAmount = totalAmount.add(invoicePayment);
				}
			}
			
			output.put("TOTAL_AMOUNT", totalAmount);

		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("CDM_CALCULATE_EFT_AMOUNT_TOTAL")
	public static GMMap calculateEftAmountTotal(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session session = CommonHelper.getHibernateSession();
			Date nextDay = CommonHelper.addDay(new Date(), 1);
			String nextDayStr = CommonHelper.getDateString(nextDay, "yyyyMMdd");
			BigDecimal totalAmount = BigDecimal.ZERO;
			List<BalanceTransferProcess> processList = new ArrayList<BalanceTransferProcess>();
				
			processList = session.createCriteria(BalanceTransferProcess.class)
							     .add(Restrictions.eq("status", true))				
							     .add(Restrictions.eq("transferStatus", DatabaseConstants.BalanceTransferProcessStatuses.Waiting))	
							     .add(Restrictions.eq("transferDate", nextDayStr))
							     .list();
			
			for(BalanceTransferProcess process: processList){
				CorporateMaster corporateMaster = (CorporateMaster)session.createCriteria(CorporateMaster.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", process.getCorporateCode())).uniqueResult();
				String corporateOid=corporateMaster.getOid();		
				
			    BalanceTransferDef transferDef = (BalanceTransferDef) session.createCriteria(BalanceTransferDef.class)
                                                    				       .add(Restrictions.eq("status", true))	
                                                    				       .add(Restrictions.eq("transferType", DatabaseConstants.AccountTransferTypes.CorporateTransfer))
                                                    				       .add(Restrictions.eq("oid", process.getTransferDefOid()))
                                                    				       .uniqueResult();
			    
			    if(transferDef != null){
					if(transferDef.getFromAccountType().equals(DatabaseConstants.AccountDefinitionTypes.CollectionAccount) && transferDef.getToAccountType().equals(DatabaseConstants.AccountDefinitionTypes.EftAccount)){
					    BigDecimal paymentAmount = (BigDecimal) session.createCriteria(invoicePayment.class)
						    					   .add(Restrictions.like("paymentDate", process.getCollectionDate() + "%"))
						    					   .add(Restrictions.eq("corporateAccountNo", transferDef.getFromAccountNo()))
						    					   .add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
						    					   .setProjection(Projections.sum("paymentAmount"))
						    					   .uniqueResult();
					    
					    if(paymentAmount != null){
							totalAmount = totalAmount.add(paymentAmount);
						}    
					    
					}else if(transferDef.getFromAccountType().equals(DatabaseConstants.AccountDefinitionTypes.CollectionAccount) && transferDef.getToAccountType().equals(DatabaseConstants.AccountDefinitionTypes.UsageAccount)){
					    BalanceTransferDef accTransferDef = (BalanceTransferDef) session.createCriteria(BalanceTransferDef.class)
	                            						      .add(Restrictions.eq("status", true))
	                            						      .add(Restrictions.eq("transferType", DatabaseConstants.AccountTransferTypes.CorporateTransfer))
	                            						      .add(Restrictions.eq("fromAccountType", DatabaseConstants.AccountDefinitionTypes.UsageAccount))
	                            						      .add(Restrictions.eq("toAccountType", DatabaseConstants.AccountDefinitionTypes.EftAccount))
	                            						      .add(Restrictions.eq("fromAccountNo", transferDef.getToAccountNo()))
	                            						      .add(Restrictions.eq("corporateOid", corporateOid))
	                            						      .uniqueResult();
					    
					    if(accTransferDef != null){
						BigDecimal paymentAmount = (BigDecimal) session.createCriteria(invoicePayment.class)
	                                    	    					       .add(Restrictions.like("paymentDate", process.getCollectionDate() + "%"))
	                                    	    					       .add(Restrictions.eq("corporateAccountNo", transferDef.getFromAccountNo()))
	                                    	    					       .add(Restrictions.eq("paymentStatus", DatabaseConstants.PaymentStatuses.Collected))
	                                    	    					       .setProjection(Projections.sum("paymentAmount"))
	                                    	    					       .uniqueResult();
	 
							if(paymentAmount != null){
								totalAmount = totalAmount.add(paymentAmount);
						    }
					    }
					}
			    }
			}
			
			output.put("TOTAL_AMOUNT", totalAmount);	
			
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@SuppressWarnings("unchecked")
	public static ArrayList<BalanceTransferDef> getBalanceTransferDefList(String fromAccountType, String toAccountType){
		Session session = CommonHelper.getHibernateSession();
		List<BalanceTransferDef> balanceTransferDefList = new ArrayList<BalanceTransferDef>();
		
		balanceTransferDefList = session.createCriteria(BalanceTransferDef.class)
									    .add(Restrictions.eq("status", true))
									    .add(Restrictions.eq("fromAccountType", fromAccountType))
									    .add(Restrictions.eq("toAccountType", toAccountType))
									    .add(Restrictions.eq("transferDayCount", new BigDecimal("1").shortValue()))
									    .list();
		
		return (ArrayList<BalanceTransferDef>) balanceTransferDefList;
	}
	
	public static String getCorporateCode(String corporateOid){
		Session session = CommonHelper.getHibernateSession();
		String corporateCode = (String) session.createCriteria(CorporateMaster.class)
											   .add(Restrictions.eq("oid", corporateOid))
											   .setProjection(Projections.property("corporateCode"))
											   .uniqueResult();
		
		return corporateCode;
	}
	
	@SuppressWarnings("unchecked")
	public static List<BalanceTransferDef> removeDuplicateDefRecords(List<BalanceTransferDef> nonEftBalanceTransferDefList){		
		HashSet<String> oidSet = new HashSet<String>();
		Session session = CommonHelper.getHibernateSession();
		List<BalanceTransferDef> balanceTransferDefList = new ArrayList<BalanceTransferDef>();
		
		for(BalanceTransferDef transferDef: nonEftBalanceTransferDefList){
			oidSet.add(transferDef.getOid());
		}
		
		ArrayList<String> balanceTransferDefOidList = new ArrayList<String>(oidSet);
		
		if(balanceTransferDefOidList != null && !balanceTransferDefOidList.isEmpty()){
			balanceTransferDefList = session.createCriteria(BalanceTransferDef.class)
										 .setProjection(Projections.projectionList()
												  				   .add(Projections.distinct(Projections.property("fromAccountNo")))
												  				   .add(Projections.property("corporateOid")))
										 .add(Restrictions.eq("status", true))
										 .add(Restrictions.in("oid", balanceTransferDefOidList))
										 .add(Restrictions.eq("transferType", DatabaseConstants.AccountTransferTypes.CorporateTransfer))
										 .list();
		}
		
		
		return balanceTransferDefList;
	}

}
