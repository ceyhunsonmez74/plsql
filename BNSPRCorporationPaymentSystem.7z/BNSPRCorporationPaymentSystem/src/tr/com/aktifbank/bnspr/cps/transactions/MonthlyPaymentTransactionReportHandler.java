package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant.Email.MonthlyReportMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.MonthlyPaymentTransactionReportHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class MonthlyPaymentTransactionReportHandler extends RequestHandler {

	private static final int LAST_MONTH_INDEX = -1;
	
	@SuppressWarnings("rawtypes")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String lastMonth =  CommonHelper.getDateString(CommonHelper.addMonth(new Date(), LAST_MONTH_INDEX), "yyyyMM");;
		Session hibernateSession = CommonHelper.getHibernateSession();
		Object [] queryResult = (Object[]) hibernateSession.createSQLQuery(MonthlyPaymentTransactionReportHandlerRepository.GET_MONTHLY_REPORT_SUMMARY_QUERY)
				.setParameter("lastMonth",lastMonth + "%").uniqueResult();
		
		String totalPaymentCount = "0";
		String summaryPaymentAmount = "0.0";
		if( null != queryResult ){
			
			if( null != queryResult[0] ){
				totalPaymentCount =CommonHelper.applyDecimalFormat(queryResult[0].toString());
			}
				
			if( null != queryResult[1] ){
				summaryPaymentAmount = CommonHelper.applyDecimalFormat(queryResult[1].toString());
			}
			
		}
		
		List list = hibernateSession.createSQLQuery(MonthlyPaymentTransactionReportHandlerRepository.GET_MONTHLY_REPORT_DETAIL_QUERY)
				.setParameter("lastMonth",lastMonth + "%").list();
		List<Map<String,String>> mapList = new ArrayList<Map<String,String>>();
		if( null != list ){
			Iterator resultIterator = list.iterator();
			while( resultIterator.hasNext() ){
				Object[] row = (Object[])resultIterator.next();
				Map<String,String> columnMap = new HashMap<String,String>();
				if( null != row[0] ){
					columnMap.put("PAYMENT_COUNT", CommonHelper.applyDecimalFormat(row[0].toString()));
				}
				if(null != row[1] ){
					columnMap.put("TOTAL_PAYMENT_AMOUNT", CommonHelper.applyDecimalFormat(row[1].toString()));
				}
				if( null != row[2] ){
					columnMap.put("KURUM_KODU", row[2].toString());
					GMMap corporateDefMap = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, new GMMap().put("CORPORATE_CODE",row[2].toString()));
					if( null != corporateDefMap ){
						columnMap.put("KURUM_ADI", corporateDefMap.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE));
					}
				}
				
				mapList.add(columnMap);
			}
		}
		

		GMMap messageMap = new GMMap();
		messageMap.put("ENVIRONMENT", GMServiceExecuter.call("BNSPR_CORE_GET_SISTEM_ADI", input).getString("SISTEM_ADI"));
		messageMap.put("LAST_MONTH",CommonHelper.formatDateString(lastMonth, "yyyyMM", "MM/yyyy"));
		messageMap.put("TOTAL_PAYMENT_COUNT", totalPaymentCount);
		messageMap.put("SUMMARY_PAYMENT_AMOUNT", summaryPaymentAmount);
		messageMap.put("MAP_TABLE", mapList);
		
		String receiptList = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST","EMAIL_RECEIPT_LIST_4_MONTHLY_COLLECTION");
		
		EmailMessage emailMessage = CommonHelper.prepareEmailBody("", messageMap,MonthlyReportMessageConstant.MESSAGE_BODY,
				MonthlyReportMessageConstant.SUBJECT,receiptList);
		
		CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
	
		
		
	}

}
