package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;

import com.graymound.util.GMMap;

public final class FTSGetTotalInvoiceAmountHandler extends RequestHandler {

	public FTSGetTotalInvoiceAmountHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		List<Date> dates = new ArrayList<Date>();
		Date invoiceDate = input.getDate(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE);
		dates.add(invoiceDate);
		if(input.containsKey("EXTRA_PROCESS_DATES")){
			for (int i = 0; i < input.getSize("EXTRA_PROCESS_DATES"); i++) {
				dates.add(input.getDate("EXTRA_PROCESS_DATES", i, "DATE"));
			}
		}
		String corporateCode = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE);
		output.put(MapKeys.FTS_OUTPUT_DATA, CommonBusinessOperations.getTotalCollectionAmount(super.getHibernateSession(), corporateCode, dates));
	}

}
