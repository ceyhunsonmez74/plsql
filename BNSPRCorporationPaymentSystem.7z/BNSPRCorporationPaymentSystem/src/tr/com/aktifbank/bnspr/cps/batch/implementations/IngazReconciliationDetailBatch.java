package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.integration.ingaz.GazTahsilatDetay;
import tr.com.aktifbank.integration.ingaz.GunSonuYekunReturn;
import tr.com.aktifbank.integration.ingaz.services.IngazOnlineClient;

import com.graymound.util.GMMap;

public class IngazReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(IngazReconciliationDetailBatch.class);
	Session session;
	List<GazTahsilatDetay> details;
	Map<String, GazTahsilatDetay> indexedCorporateRecords;

	public IngazReconciliationDetailBatch(GMMap input) {
		super(input);
		this.indexedCorporateRecords = new HashMap<String, GazTahsilatDetay>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, this.details.get(corporateRecordIndex).getDekontNo());
		collectionDetailRequest.put(MapKeys.PAYMENT_DATE,this.input.getString(MapKeys.RECON_DATE));
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.TRX_NO, details.get(corporateRecordIndex).getDekontNo());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex, GMMap collectionDetailResponse) {
		cancelCollectionRequest.put(MapKeys.TRX_NO, collectionDetailResponse.getString(MapKeys.TRX_NO));
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			GregorianCalendar c = new GregorianCalendar();
			c.setTime(CommonHelper.getDateTime(CommonHelper.formatDateString(input.getString(MapKeys.RECON_DATE), "yyyyMMdd", "yyyy-MM-dd"), "yyyy-MM-dd"));
			XMLGregorianCalendar tarih = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
			details=IngazOnlineClient.getMutabakatIstek(input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), tarih, "0", "0", input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT)).getDetay();
			result.setSuccessfulCall(true);
		}
		catch (Exception e) {
			logger.error("An exception occured while calling agri recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getDekontNo(), this.details.get(i));
		}
		input.put(MapKeys.RECON_CORPORATE_COUNT, details.size());
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getDekontNo());
	}
}
