package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.IcsUpdateStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.SaveStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.UpdateStandingOrder;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.UpdateStandingOrderAccount;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.UpdateStandingOrderComm;
import tr.com.aktifbank.bnspr.dao.StandingOrderMainTx;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class UpdateStandingOrderHandler extends RequestHandler {

	public UpdateStandingOrderHandler() {
		super();
	}

	@SuppressWarnings("unused")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		GMMap outputMap = new GMMap();

		String standingOrderOid = input.getString(UpdateStandingOrder.Input.OID, null);
		
		int count = ((Number)super.getHibernateSession().createCriteria(StandingOrderMainTx.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("recordOid", standingOrderOid))
				.add(Restrictions.eq("txStatus", DatabaseConstants.TransactionStatuses.New))
				.setProjection(Projections.rowCount())
				.uniqueResult()).intValue();
		
		if(count > 0){
			CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, 
					"��lem yapmak istedi�iniz talimat i�in daha �nce yap�lm�� bir g�ncelleme onayda beklemektedir.");
		}
		
		// /////////get inputs
		Byte orderStatus;
		String corporateOid = input.getString(UpdateStandingOrder.Input.CORPORATE_OID, null);
		String corporateCode = input.getString(UpdateStandingOrder.Input.CORPORATE_CODE, null);
		String type = input.getString(UpdateStandingOrder.Input.TYPE, null);
		String trxNo = input.getString(UpdateStandingOrder.Input.TRX_NO, null);
		String customerNo = input.getString(UpdateStandingOrder.Input.CUSTOMER_NO, null);
		String orderOwner = input.getString(UpdateStandingOrder.Input.ORDER_OWNER, null);
		String corporate = input.getString(UpdateStandingOrder.Input.CORPORATE, null);
		String paymentChannel = input.getString(UpdateStandingOrder.Input.PAYMENT_CHANNEL, null);
		String accountNumber = input.getString(UpdateStandingOrder.Input.ACCOUNT_NUMBER, null);
		String standingOrderName = input.getString(UpdateStandingOrder.Input.STANDING_ORDER_NAME, null);
		String collectionType = input.getString(SaveStandingOrder.Input.COLLECTION_TYPE, String.valueOf(GeneralConstants.COLLECTION_TYPE_NOT_MENTIONED));
		String endDate = input.getString(UpdateStandingOrder.Input.END_DATE, null);
		if (input.containsKey("ORDER_STATUS")) {
			orderStatus = Byte.valueOf(String.valueOf(input.getInt(UpdateStandingOrder.Input.ORDER_STATUS)));
		} else {
			orderStatus = null;
		}
		String iban = input.getString(UpdateStandingOrder.Input.IBAN, null);
		String orderNumber = input.getString(UpdateStandingOrder.Input.ORDER_NUMBER, null);
		String phoneNumber = input.getString(UpdateStandingOrder.Input.PHONE_NUMBER, null);
		String email = input.getString(UpdateStandingOrder.Input.EMAIL, null);
		String beforePayment = input.getString(UpdateStandingOrder.Input.BEFORE_PAYMENT, null);
		String afterPayment = input.getString(UpdateStandingOrder.Input.AFTER_PAYMENT, null);
		String notifyBySms = input.getString(UpdateStandingOrder.Input.NOTIFY_BY_SMS, null);
		String notifyByEmail = input.getString(UpdateStandingOrder.Input.NOTIFY_BY_EMAIL, null);
		String checkResult = input.getString(UpdateStandingOrder.Input.CHECK_RESULT, null);
		String cardNo = input.getString("CARD_NUMBER", null);
		boolean accFirst = input.getBoolean("ACC_FIRST", true);
		boolean cardFirst = input.getBoolean("CARD_FIRST", false);
		// /////////

		// /////////variable definitions
		String corporateActiveness = "";
		String corporateName = "";
		String bankCode = "";
		String username = "";
		String updDate = "";
		String updUser = "";
		byte nextStatus = orderStatus;
		GMMap corpDefMap = null;
		GMMap cdMap = null;
		GMMap somUpdateInputMap = null;
		GMMap somUpdateOutMap = null;
		GMMap commInputMap = null;
		GMMap soaUpdateInputMap = null;
		GMMap soaUpdateOutMap = null;
		GMMap transactionImputMap = null;
		GMMap icsOutputMap = null;
		GMMap transactionOutputMap = null;
		boolean isOnlineCorporate = false;
		// /////////
		
		if(StringUtil.isEmpty(corporateOid) && StringUtil.isEmpty(corporateCode)){
			icsStandingOrders order = (icsStandingOrders)super.getHibernateSession().createCriteria(icsStandingOrders.class)
					.add(Restrictions.eq("standingOrderOid", standingOrderOid))
					.add(Restrictions.eq("status", true))
					.uniqueResult();
			if(order != null){
				corporateCode = order.getCorporateCode();
			}
			else{
				throw new Exception(String.format("No standing order found with %s id", standingOrderOid));
			}
		}
		
		BigDecimal customerNoOfAccount = CommonBusinessOperations.getCustomerNoOfAccount(new BigDecimal(accountNumber));
		if (customerNoOfAccount == null || customerNoOfAccount.compareTo(new BigDecimal(customerNo)) != 0)
			CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.EMPTYMESSAGE, 
					String.format("%s nolu hesap %s nolu m��teriye ait de�ildir", accountNumber, customerNo)));

		// /////////get corporate definition to get corporateCode
		corpDefMap = new GMMap();
		if (!StringUtil.isEmpty(corporateOid)) {
			corpDefMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, corporateOid);
		} else {
			corpDefMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
		}
		cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", corpDefMap);
		
		collectionType = String.valueOf(CommonBusinessOperations.manipulateCollectionTypeForChannels(Short.valueOf(collectionType), 
				cdMap.getString(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID)));
		
		corporateCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
		corporateActiveness = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_ACTIVENESS);
		corporateName = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_NAME);
		if (cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.IS_ONLINE_CORPORATE).equals("1")) {
			isOnlineCorporate = true;
		} else {
			isOnlineCorporate = false;
		}
		bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);
		// /////////

		if (type.equals("KFT")) {
			GMMap checkSubscriberInputMap = new GMMap();
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.BANK_CODE, bankCode);
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.CORPORATE_CODE, corporateCode);
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.OPERATION, "UPDATE");
			checkSubscriberInputMap.put(TransactionConstants.CheckSubscriberPreStandingOrder.Input.COLLECTION_TYPE, collectionType);
			GMMap checkSubscriberMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_CHECK_SUBSCRIBER_PRE_STANDING_ORDER",
					checkSubscriberInputMap);
		}

		username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		updDate = CommonHelper.getLongDateTimeString(new Date());
		updUser = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		;

		// /////////update standing order main
		somUpdateInputMap = new GMMap();
		somUpdateOutMap = new GMMap();
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.AFTER_PAYMENT, afterPayment);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.BEFORE_PAYMENT, beforePayment);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.CUSTOMER_NO, customerNo);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.END_DATE, endDate);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.NOTIFY_BY_EMAIL, notifyByEmail);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.NOTIFY_BY_SMS, notifyBySms);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.ORDER_STATUS, orderStatus);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.PAYMENT_CHANNEL, paymentChannel);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.STANDING_ORDER_NAME, standingOrderName);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.TRX_NO, trxNo);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.TYPE, type);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.USER_NAME, username);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.STANDING_ORDER_OID, standingOrderOid);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.UPDATE_DATE, updDate);
		somUpdateInputMap.put(TransactionConstants.UpdateStandingOrderMain.Input.UPDATE_USER, updUser);
		somUpdateOutMap = super.callGraymoundServiceInSession("CDM_UPDATE_STANDING_ORDER_MAIN", somUpdateInputMap);

		// /////////

		// /////////update standing order account
		soaUpdateInputMap = new GMMap();
		soaUpdateOutMap = new GMMap();
		soaUpdateInputMap.put(UpdateStandingOrderAccount.Input.ACCOUNT_NUMBER, accountNumber);
		soaUpdateInputMap.put(UpdateStandingOrderAccount.Input.IBAN, iban);
		soaUpdateInputMap.put(UpdateStandingOrderAccount.Input.STANDING_ORDER_OID, standingOrderOid);
		soaUpdateInputMap.put(UpdateStandingOrderAccount.Input.UPDATE_DATE, updDate);
		soaUpdateInputMap.put(UpdateStandingOrderAccount.Input.UPDATE_USER, updUser);
		soaUpdateInputMap.put("COLLECTION_CARD_NO", cardNo);
		soaUpdateInputMap.put("PRIORITY", accFirst ? DatabaseConstants.StandingOrderSourcePriorities.AccountFirst : DatabaseConstants.StandingOrderSourcePriorities.CardFirst);
		soaUpdateInputMap.put(MapKeys.TRX_NO, trxNo);
		soaUpdateOutMap = super.callGraymoundServiceInSession("CDM_UPDATE_STANDING_ORDER_ACCOUNT", soaUpdateInputMap);
		// /////////

		if (type.equals("KFT")) {
			// /////////save ics standing order
			GMMap icsInputMap = new GMMap();
			icsInputMap.put(IcsUpdateStandingOrder.Input.STANDING_ORDER_OID, standingOrderOid);
			icsInputMap.put(IcsUpdateStandingOrder.Input.TRX_NO, trxNo);
			icsInputMap.put(IcsUpdateStandingOrder.Input.UPDATE_DATE, updDate);
			icsInputMap.put(IcsUpdateStandingOrder.Input.UPDATE_USER, updUser);
			icsInputMap.put(IcsUpdateStandingOrder.Input.STANDING_ORDER_STATUS, orderStatus);
			icsOutputMap = super.callGraymoundServiceInSession("ICS_UPDATE_STANDING_ORDER", icsInputMap);
			// /////////

			// /////////save standing order comm
			commInputMap = new GMMap();
			commInputMap.put(UpdateStandingOrderComm.Input.E_MAIL, email);
			commInputMap.put(UpdateStandingOrderComm.Input.PHONE_NUMBER, phoneNumber);
			commInputMap.put(UpdateStandingOrderComm.Input.STANDING_ORDER_OID, standingOrderOid);
			commInputMap.put(UpdateStandingOrderComm.Input.UPDATE_DATE, updDate);
			commInputMap.put(UpdateStandingOrderComm.Input.UPDATE_USER, updUser);
			commInputMap.put(MapKeys.TRX_NO, trxNo);
			GMMap commOutputMap = super.callGraymoundServiceInSession("STO_UPDATE_STANDING_ORDER_COMM", commInputMap);
			// /////////

		}

		// /////////send transaction
		transactionImputMap = new GMMap();
		transactionImputMap.put(MapKeys.TRX_NAME, "7003");
		transactionImputMap.put(MapKeys.TRX_NO, trxNo);
		transactionOutputMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", transactionImputMap);
		// /////////
		
		output.put("RESULT_MSG", transactionOutputMap.getString("MESSAGE"));

	}
}
