package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.integration.patnos.PatnosClient;
import tr.com.aktifbank.integration.patnos.ServiceMessage;
import tr.com.patnos.BeanTahsilatRapor;
import tr.com.patnos.BeanTahsilatRaporSorgu;

import com.graymound.util.GMMap;

public class PatnosWaterReconciliationDetailBatch extends CollectionReconciliationDetailBatch {


	private static final Log logger = LogFactory.getLog(PatnosWaterReconciliationDetailBatch.class);
	Session session;
	ArrayList<BeanTahsilatRapor> details;
	ArrayList<BeanTahsilatRapor> details2;
	ArrayList<BeanTahsilatRapor> listRapor = new ArrayList<BeanTahsilatRapor>();
	ServiceMessage message;
	Map<String, BeanTahsilatRapor> indexedCorporateRecords;

	public PatnosWaterReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, BeanTahsilatRapor>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, this.details.get(corporateRecordIndex).getTahsilatReferansNo());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex, GMMap collectionDetailResponse) {
		cancelCollectionRequest.put(MapKeys.PARAMETER_7, details.get(corporateRecordIndex).getIslemNo());
		cancelCollectionRequest.put(MapKeys.PARAMETER_9, details.get(corporateRecordIndex).getTahsilatTarihiGun());
		cancelCollectionRequest.put(MapKeys.PARAMETER_10, details.get(corporateRecordIndex).getTahsilatTarihiAy());
		cancelCollectionRequest.put(MapKeys.PARAMETER_11, details.get(corporateRecordIndex).getTahsilatTarihiYil());
		cancelCollectionRequest.put(MapKeys.PARAMETER_20, details.get(corporateRecordIndex).getMakbuzNo());
		cancelCollectionRequest.put(MapKeys.TRX_NO, collectionDetailResponse.getString(MapKeys.TRX_NO));
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String tarih = input.getString(MapKeys.RECON_DATE);
			
			String username = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER);
			String password = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			int reqTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			int connTimeout = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2); 

			BeanTahsilatRaporSorgu rapor = new BeanTahsilatRaporSorgu();
			int tahsilatBtsTarihiGun = Integer.parseInt(tarih.substring(6, 8));
			int tahsilatBslTarihiGun = Integer.parseInt(tarih.substring(6, 8));
			int tahsilatBslTarihiAy = Integer.parseInt(tarih.substring(4, 6));
			int tahsilatBtsTarihiAy = Integer.parseInt(tarih.substring(4, 6));
			int tahsilatBslTarihiYil = Integer.parseInt(tarih.substring(0, 4));
			int tahsilatBtsTarihiYil = Integer.parseInt(tarih.substring(0, 4));
			rapor.setTahsilatBslTarihiAy(tahsilatBslTarihiAy);
			rapor.setTahsilatBslTarihiGun(tahsilatBslTarihiGun);
			rapor.setTahsilatBslTarihiYil(tahsilatBslTarihiYil);
			rapor.setTahsilatBtsTarihiAy(tahsilatBtsTarihiAy);
			rapor.setTahsilatBtsTarihiGun(tahsilatBtsTarihiGun);
			rapor.setTahsilatBtsTarihiYil(tahsilatBtsTarihiYil);
			details2 = (ArrayList<BeanTahsilatRapor>) PatnosClient.tahsilatSuRaporDetay(reqTimeout, connTimeout, Long.parseLong(username), rapor, password, username, password, url, this.message).getBeanTahsilatRapor();
			for (int i = 0; i < details2.size(); i++) {
				if (!details2.get(i).isIptal()) {
					listRapor.add(details2.get(i));
				}
			}
			details = listRapor;

			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling agri recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getTahsilatReferansNo(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getTahsilatReferansNo());
	}


}
