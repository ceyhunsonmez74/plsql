package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.ComplexBatchSubmitInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.implementations.ComplexBatchSubmitImplementation;
import tr.com.aktifbank.bnspr.dao.BatchDef;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class StartComplexFileBatchHandler extends RequestHandler {

	public StartComplexFileBatchHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		long startMilis = System.currentTimeMillis();
		
		List<CorporateBatchProcess> corporateBatchProcessList = super.getHibernateSession().createCriteria(CorporateBatchProcess.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("batchName", DatabaseConstants.BatchNames.ComplexFileSendBatch))
				.list();
		
		BatchDef complexBatchDefintiion = (BatchDef)super.getHibernateSession().createCriteria(BatchDef.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("batchName", DatabaseConstants.BatchNames.ComplexFileSendBatch))
				.uniqueResult();
		
		ComplexBatchSubmitInformation information = new ComplexBatchSubmitInformation();
		
		information.setServiceName(complexBatchDefintiion.getBatchServiceName());
		for (CorporateBatchProcess process : corporateBatchProcessList) {
			information.addCorporateCode(process.getCorporateCode());
		}
		
		information.setParallelLoopCount(Integer.valueOf(CommonHelper.getValueOfParameter("CDM_INFORM_COLLECTION_MAX_PARALLEL_COUNT", "COUNT")));
		
		ComplexBatchSubmitImplementation implementation = new ComplexBatchSubmitImplementation(information);
		implementation.execute();
		
		long endMilis = System.currentTimeMillis();
		
		Thread.sleep(10 * 60 * 1000);
		
		GMMap sendReportRequest = new GMMap();
		sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.BATCH_NAME, DatabaseConstants.BatchNames.ComplexFileSendBatch);
		sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.PROCESS_DATE, new Date());
		sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.DURATION, endMilis - startMilis);
		sendReportRequest.put(TransactionConstants.BatchFileReporter.Input.NOTIFICATION_TO, CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_COMPLEX_INFORM_REPORT"));
		
		GMServiceExecuter.executeAsync(TransactionConstants.BatchFileReporter.SERVICE_NAME, sendReportRequest);
		
	}

}
