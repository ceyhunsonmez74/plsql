package tr.com.aktifbank.bnspr.cps.common;

public interface DatabaseConstants {
	public static final class SubmitStatuses{
		public static final String START = "00";
		public static final String EXECUTING = "11";
		public static final String FAILURE = "88";
		public static final String SUCESSFUL = "99";
	}
	
	public static final class TransferStatuses{
		public static final byte SUBMITTED = 10;
		public static final byte SUBMITFAILURE = 20;
	}
	
	public static final class CorporateActiveness{
		public static final String Active = "A";
		public static final String Passive = "P";
	}
	
	public static final class FileType{
		public static final String Input = "I";
		public static final String Output = "O";
	}
	
	public static final class LineType{
		public static final String Header = "H";
		public static final String Detail = "D";
		public static final String Footer = "F";
	}
	
	public static final class FieldType{
		public static final String Date = "D";
		public static final String Numeric = "N";
		public static final String AlphaNumeric = "A";
		public static final String Constant = "C";
		public static final String Amount = "T";
		public static final String Time = "S";
	}
	
	public static final class FooterIndicators{
		public static final String TOTAL_AMOUNT = "TOTAL_AMOUNT";
		public static final String TOTAL_RECORD_COUNT = "TOTAL_RECORD_COUNT";
	}
	
	public static final class HeaderIndicators{
		public static final String HEADER_PROCESS_COMMAND = "HEADER_PROCESS_COMMAND";
	}
	
	public static final class SourceCodes{
		public static final String Cash = "1";
		public static final String Account = "2";
		public static final String CreditCard = "3";
	}
	
	public static final class ConcentrationTypes{
		public static final String SingleConcentration = "T";
		public static final String MultiConcentration = "C";
	}
	
	public static final class AccountDefinitionTypes{
		public static final String CollectionAccount = "TH";
		public static final String UsageAccount = "KH";
		public static final String EftAccount = "EH";
		public static final String BlockedAccount = "BH";
	}
	
	public static final class AccountTypes{
		public static final String DepositAccount = "VL";
		public static final String CheckingAccount = "VS";
	}
	
	public static final class CollectionTypes{
		public static final String InvoiceLoad = "0";
		public static final String TLLoad = "1";
		public static final String WaterAssessment = "2";
		public static final String InstallmentSaleOfGoods = "3";
		public static final String InternetPackages = "18";
		public static final String VoicePackages = "19";
	}
	
	public static final class TransactionStatuses {
		public static final String New = "N";
		public static final String AfterApproval = "A";
		public static final String Booking = "B";
		public static final String Finished = "F";
	}
	
	public static final class CommissionTypes{
		public static final String FixedAmount = "S";
		public static final String Rate = "O";
		public static final String WageScale = "B";
	}
	
	public static final class BSMVTypes{
		public static final String Inside = "I";
		public static final String Outside = "D";
	}
	
	public static final class PaymentStatuses {
		public static final String Waiting = "B";
		public static final String Collected = "T";
		public static final String Error = "H";
		public static final String Cancelled = "I";
		public static final String PartialCollected = "K";
	}
	
	public static final class InvoiceStatuses {
		public static final String Active = "A";
		public static final String Cancelled = "I"; 
	}
	
	public static final class InvoiceMainTable{
		public static final String INVOICE_DUE_DATE = "INVOICE_DUE_DATE"; 
	}
	
	public static final class AfterDueCountTypes{
		public static final String Day = "D";
		public static final String Week = "W";
		public static final String Month = "M";
		public static final String Year = "Y";
	}
	
	public static final class SectorActiveness{
		public static final String Active = "1";
		public static final String Passive = "0";
	}
	
	public static final class TransferTypes{
		public static final short InvoiceLoading = 1;
		public static final short CollectionInform = 2;
		public static final short StandingOrderInform = 3;
		public static final short StandingOrderCancelInform = 4;
		public static final short ComplexInform = 5;
		public static final short SameDayCollectionInform = 6;
		public static final short CollectionInformWithExcel = 10;
	}
	
	public static final class DataSourceTypes {
		public static final String Database = "D";
		public static final String Service = "S";
		public static final String DatabaseAndService = "B";
	}
	
	public static final class Alignments {
		public static final String Left = "L";
		public static final String Right = "R";
	}
	
	public static final class UsedAllCollections {
		public static final String OneMandatory = "0";
		public static final String AllMandatory = "1";
	}
	
	public static final class ReconciliationStatus {
		public static final String Started = "1";
		public static final String Continues = "2";
		public static final String ReconciliationFailed = "3";
		public static final String ReconciliationSucceeded = "4";
		public static final String ClosedManually = "6";
	}
	
	public static final class ReconciliationProcessType {
		public static final String collectionMessageSent = "10";
		public static final String cancelCollectionMessageSent = "20";
		public static final String standingOrderMessageSent = "30";
		public static final String cancelStandingOrderMessageSent = "40";		
	}
	
	public static final class ReconciliationTypes {
		public static final byte Collection = 1;
		public static final byte StandingOrder = 2;
		public static final byte MoneyLoad = 3;
		public static final byte General = 4;		
	}
	
	public static final class StandingOrderStatus {
		public static final String Active = "1";
		public static final String Passive = "2";
		public static final String Canelled = "3";	
		public static final String Succeeded = "4";	
	}
	
	public static final class BatchNames{
		public static final String AccountTransferBatch = "Hesap Aktarim";
		public static final String CalculateTransferDates = "Transfer Gunleri Hesaplama";
		public static final String ComplexFileSendBatch = "Kompleks Dosya Gonderme";
		public static final String InformInvoiceCollectionBatch = "Tahsilat Bildirim";
		public static final String InformStandingOrdersBatch = "Talimat Bildirim";
		public static final String InformStandingOrdersCancelBatch = "Talimat Iptal Bildirim";
		public static final String OnlineStandingOrderDebtLoading = "Online Talimatli Borc Yukleme";
		public static final String StandingOrderInvoiceCollection = "Talimatli Tahsilat";
		public static final String CollectionReconciliation = "Tahsilat Mutabakat";
		public static final String GSMCorporateAccountTransferBatch = "GSM Kurumu Hesap Aktarim";
		public static final String EKSCorporateAccountTransferBatch = "EKS Kurumu Hesap Aktarim";
		public static final String SameDayInformInvoiceCollectionBatch = "Ayni Gun Tahsilat Bildirim";
		public static final String SameDayAccountTransferBatch = "Ayni Gun Hesap Aktarim";
		public static final String BlockedAccountTransferBatch = "Blokeli Hesap Aktarim";
		public static final String SameDayDefinedAccountTransferBatch = "Ayni Gun Tanimli Hesap Aktarim";
		public static final String ChangeCorporatePasswordBatch = "Kurum Sifre Degisim";
		public static final String GameOfChanceAccountTransferBatch = "�ans Oyunlar� Hesap Aktar�m";
		public static final String InformInvoiceCollectionWithExcelBatch = "Excel Format�nda Mail �le Tahsilat Bildirim";
	}
	
	public static final class IsEftTransfers{
		public static final String EFTTransfer = "1";
		public static final String NonEFTTransfer = "0";
	}
	
	public static final class BalanceTransferProcessStatuses{
		public static final byte Waiting = 0;
		public static final byte Executing = 1;
		public static final byte Successful = 2;
		public static final byte Failed = 3;
		public static final byte NoPaymentFound = 4;
	}
	
	public static final class BalanceTransferLogStatuses{
		public static final byte WaitingTransferDateCalculation = 0;
		public static final byte TransferDateCalculatedSuccessfully = 1;
		public static final byte TransferDateCalculationFailed = 2;
		public static final byte TransferStarted = 3;
		public static final byte TransferExecutedSuccessfully = 4;
		public static final byte TransferFailed = 5;
		public static final byte NoPaymentFound = 6;
	}
	
	public static final class BalanceTransferDayTypes{
		public static final String Day = "2";
		public static final String WorkingDay = "1";
	}
	
	public static final class BalanceTransferCollectionsInHoliday{
		public static final String HolidayAllowed = "0";
		public static final String MustWorkingDay = "1";
		public static final String BeforeHoliday = "2";
	}
	
	public static final class ReconciliationResubmitType {
		public static final String FindDifferences = "1";
		public static final String ReconciliationClose = "2";
	}
	
	public static final class CorporateAccountBlockStatuses{
		public static final String Blocking = "0";
		public static final String Blocked = "1";
		public static final String BlockFailed = "2";
		public static final String Unblocking = "3";
		public static final String Unblocked = "4";
		public static final String UnblockFailed = "5";
	}
	
	public static final class CommissionCollectionStatuses{
		public static final String Collected = "A";
		public static final String Cancelled = "I";
	}
	
	public static final class BatchParameterValues {
		public static final String DeleteAndLoadEnabled = "1";
		public static final String LoadWithStandingOrderEnabled = "1";
		public static final String LoadOnlyWithStandingOrder = "1";
		public static final String ControlInvoiceNoEnabled = "1";
		public static final String ProcessInvoiceWithCommandEnabled = "1";
		public static final String DeleteWaitingInvoicesEnabled = "1";
		public static final String ControlInvoiceDueDateEnabled = "1";
		public static final String DeleteWaitingCommandOnHeaderEnabled = "1";
		public static final String WeekendToWeekdayEnabled = "1";
		public static final String ShowPaymentDateAsProcessDate = "1";
		public static final String InformOnlyStandingOrderPaymentsEnabled = "1";
		public static final String DeleteDecimalPartEnabled = "1";
		public static final String DoNotCallFtmEnabled = "1";
		public static final String DoNotCallFtmWithEmtyFileEnabled = "1";
	}
	
	public static final class InvoiceProcessingCommands{
		public static final String Insert = "I";
		public static final String Delete = "D";
		public static final String Update = "U";
	}
	
	public static final class InvoicePreProcessCommands{
		public static final String Normal = "N";
		public static final String DeletePendings = "D";
	}
	
	public static final class StdOrderCommProcessStatuses {
		public static final String SENT = "1";
		public static final String SENDING = "2";
		public static final String UNABLE_TO_SEND = "3";

	}
	
	public static final class UserForInquiry {
		public static final String No = "0";
		public static final String Yes = "1";
	}
	
	public static final class StandingOrderProcessLogStatuses {
		public static final String Successful = "1";
		public static final String Failed = "2";
	}

	public static final class PaymentCancelStatuses {
		public static final String WaitingApproval = "B";
		public static final String Approved = "O";
		public static final String Rejected = "R";
	}
	
	public static final class AccountTransferTypes {
		public static final String CorporateTransfer = "KFT";
		public static final String GSMCorporateTransfer = "GSM";
		public static final String EKSCorporateTransfer = "EKS";
		public static final String IskiCreditTransfer = "ICR";
		public static final String BlockedAccountTransfer = "BAT";
		public static final String TaxTransfer = "GVT";
		public static final String SameDayTransfer = "SDT";
		public static final String GameOfChanceTransfer = "SOT";
	}
	
	public static final class StandingOrderSourcePriorities {
		public static final String AccountFirst = "1";
		public static final String CardFirst = "2";
	}
	
	public static final class MetadataTypes{
		public static final String Collection = "C";
		public static final String StandingOrder = "S";
	}
	
	public static final class FtmTransactionTypes {
		public static final String FTP = "1";
		public static final String FILE = "2";
		public static final String FTP_FILE_REL = "3";
		public static final String REFRESH_FTM = "4";
		public static final String MAIL_PROCESS_DEF = "5";
		public static final String MAIL_NOTIFICATION = "6";
	}
	
	public static final class FtmOperationTypes {
		public static final String INSERT = "I";
		public static final String DELETE = "D";
		public static final String UPDATE = "U";
	}
}
