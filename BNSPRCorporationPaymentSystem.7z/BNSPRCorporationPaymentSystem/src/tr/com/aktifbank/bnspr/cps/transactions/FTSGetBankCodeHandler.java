package tr.com.aktifbank.bnspr.cps.transactions;

import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;

import com.graymound.util.GMMap;

public final class FTSGetBankCodeHandler extends RequestHandler {

	public FTSGetBankCodeHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE);
		GMMap corporateResults = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
				TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
		output.put(MapKeys.FTS_OUTPUT_DATA, corporateResults.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE));
	}

}
