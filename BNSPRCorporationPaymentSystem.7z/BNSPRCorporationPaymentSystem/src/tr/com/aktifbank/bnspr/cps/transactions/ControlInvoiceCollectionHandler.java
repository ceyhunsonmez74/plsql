package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.ControlInvoiceCollectionHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public class ControlInvoiceCollectionHandler extends RequestHandler {

	public ControlInvoiceCollectionHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.ControlInvoiceCollection.Input.CORPORATE_CODE);
		BigDecimal collectionAmount = input.getBigDecimal(TransactionConstants.ControlInvoiceCollection.Input.PAYMENT_AMOUNT);
		BigDecimal amount = input.getBigDecimal(TransactionConstants.ControlInvoiceCollection.Input.AMOUNT);
		String invoiceDueDate = input.getString(TransactionConstants.ControlInvoiceCollection.Input.INVOICE_DUE_DATE);
		String channelId = input.getString(TransactionConstants.ControlInvoiceCollection.Input.CHANNEL_CODE);
		String sourceCode = input.getString(TransactionConstants.ControlInvoiceCollection.Input.SOURCE);
		short collectionType = (short)input.getInt(TransactionConstants.ControlInvoiceCollection.Input.COLLECTION_TYPE);
		String subscriberNo1 = input.getString(TransactionConstants.ControlInvoiceCollection.Input.SUBSCRIBER_NO1);
		String subscriberNo2 = input.getString(TransactionConstants.ControlInvoiceCollection.Input.SUBSCRIBER_NO2);
		String subscriberNo3 = input.getString(TransactionConstants.ControlInvoiceCollection.Input.SUBSCRIBER_NO3);
		String subscriberNo4 = input.getString(TransactionConstants.ControlInvoiceCollection.Input.SUBSCRIBER_NO4);
		Date currentDate = new Date();
		
		String corporateSectorCode = DALUtil.getResult(String.format(ControlInvoiceCollectionHandlerRepository.GET_SECTOR_CODE_QUERY, corporateCode));
		
		GMMap sectorOutput = super.callServiceWithParams(TransactionConstants.ControlSectorActiveness.SERVICE_NAME,
				TransactionConstants.ControlSectorActiveness.Input.SECTOR_CODE, corporateSectorCode);
		if(!sectorOutput.getBoolean(TransactionConstants.ControlSectorActiveness.Output.RESULT)){
			throw new BatchComponentException(String.format("When controlling sector with %s code an unexpected exception has occured. Result is false.", corporateSectorCode),
					BusinessException.SYSTEM);
		}
		
		super.callServiceWithParams(TransactionConstants.ControlCollectionAmount.SERVICE_NAME,				//19 haftasonu icin kapatt�m partial �deme hangi durumlarda olcak online kurumlarda dtabase yerine nereden kontrol edicez
				TransactionConstants.ControlCollectionAmount.Input.COLLECTION_AMOUNT, collectionAmount,
				TransactionConstants.ControlCollectionAmount.Input.AMOUNT, amount,
				TransactionConstants.ControlCollectionAmount.Input.CORPORATE_CODE, corporateCode);
		
		super.callServiceWithParams(TransactionConstants.ControlDueDate.SERVICE_NAME,						//19 haftasonu icin kapatt�m duedate �deme hangi durumlarda olcak online kurumlarda dtabase yerine nereden kontrol edicez
				TransactionConstants.ControlDueDate.Input.CURRENT_DATE, currentDate,
				TransactionConstants.ControlDueDate.Input.INVOICE_DUE_DATE, invoiceDueDate,
				TransactionConstants.ControlDueDate.Input.CORPORATE_CODE, corporateCode);
		
		GMMap channelWorkingDayControlResult = super.callServiceWithParams(TransactionConstants.CorporateChannelWorkingHourControl.SERVICE_NAME, 
				TransactionConstants.CorporateChannelWorkingHourControl.Input.CHANNEL_CODE, channelId,
				TransactionConstants.CorporateChannelWorkingHourControl.Input.CORPORATE_CODE, corporateCode,
				TransactionConstants.CorporateChannelWorkingHourControl.Input.SOURCE_CODE, sourceCode,
				TransactionConstants.CorporateChannelWorkingHourControl.Input.DATE, currentDate);
		if(channelWorkingDayControlResult.getBoolean(TransactionConstants.CorporateChannelWorkingHourControl.Output.RESULT)){
			// No Problem
		}
		
		GMMap accountControlResult = super.callServiceWithParams(TransactionConstants.CorporateAccountControl.SERVICE_NAME, 
				TransactionConstants.CorporateAccountControl.Input.CHANNEL_CODE, channelId,
				TransactionConstants.CorporateAccountControl.Input.CORPORATE_CODE, corporateCode,
				TransactionConstants.CorporateAccountControl.Input.SOURCE_CODE, sourceCode,
				TransactionConstants.CorporateAccountControl.Input.COLLECTION_TYPE, collectionType,
				TransactionConstants.CorporateAccountControl.Input.SUBSCRIBER_NO1, subscriberNo1,
				TransactionConstants.CorporateAccountControl.Input.SUBSCRIBER_NO2, subscriberNo2,
				TransactionConstants.CorporateAccountControl.Input.SUBSCRIBER_NO3, subscriberNo3,
				TransactionConstants.CorporateAccountControl.Input.SUBSCRIBER_NO4, subscriberNo4);
		if(accountControlResult.getBoolean(TransactionConstants.CorporateAccountControl.Output.RESULT)){
			// NO PROBLEM
		}
		
		output.put(TransactionConstants.ControlInvoiceCollection.Output.ACCOUNT_NO, accountControlResult.getBigDecimal(TransactionConstants.CorporateAccountControl.Output.ACCOUNT_NO));
	}

}
