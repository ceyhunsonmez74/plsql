package tr.com.aktifbank.bnspr.cps.dto;

import java.io.Serializable;

public final class ItemServiceField extends BaseTransferObject implements Serializable {

	private static final long serialVersionUID = -9174938332557137688L;

	public ItemServiceField() {
		super();
	}
	
	private String oid;
	private boolean status;
	private String serviceName;
	private String explanation;

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public boolean isStatus() {
		return this.status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getServiceName() {
		return this.serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getExplanation() {
		return this.explanation;
	}

	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}

}
