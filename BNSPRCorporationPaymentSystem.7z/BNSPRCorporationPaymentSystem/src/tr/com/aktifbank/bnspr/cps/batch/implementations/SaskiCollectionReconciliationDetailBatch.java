package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.adasu.AdasuClient;
import tr.gov.adasu.service.tahsilat.xsd.TahsilatDetayMutabakat;
import tr.gov.adasu.service.xsd.FaturaMutabakat;


public class SaskiCollectionReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(SaskiCollectionReconciliationDetailBatch.class);
	
	private static final String ALL = "T";
	
	private AdasuClient client;
	
	private FaturaMutabakat[] details;
	
	private Map<String, FaturaMutabakat> indexedCorporateRecords;
	
	public SaskiCollectionReconciliationDetailBatch(GMMap input, AdasuClient client) {
		super(input);
		this.client = client;
		indexedCorporateRecords = new HashMap<String, FaturaMutabakat>();
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)throws Exception {
		
		FaturaMutabakat invoice = details[corporateRecordIndex];
		logger.info(String.format("Following corporate record has not been found in database. Subscriber No : %s, Bill Cycle  : %s, Amount  : %s, Due Date : %s, Invoice No : %s ", 
				invoice.getAboneNo(), 
				invoice.getDonem(), 
				invoice.getTutar(), 
				invoice.getVade(),
				invoice.getId()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(invoice.getAboneNo().toString());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal(1));
		payment.setInvoiceNo(invoice.getId().toString());
		payment.setInvoiceAmount(new BigDecimal(invoice.getTutar()));
		payment.setPaymentAmount(new BigDecimal(invoice.getTutar()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		Session session = CommonHelper.getHibernateSession();
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, invoice.getAboneNo().toString());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, invoice.getId());
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, invoice.getTutar());
	}


	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()
			throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		
		String reconcilationDate = CommonHelper.getDateString(input.getDate(MapKeys.RECON_DATE),"yyyyMMdd");
			
		TahsilatDetayMutabakat detail = client.tahsilatDetayMutabakat(changeDate2CorpDate(reconcilationDate), ALL);
		if( null != detail ){
			if( null != detail.getFaturas() ){
				details = detail.getFaturas();
			}
			else{
				details = new FaturaMutabakat[0];
			}
		}
		
		result.setSuccessfulCall(true);
		
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for( int i = 0; i< size; i++ ){
			GMMap currentRecord = super.getBankRecordAtIndex(i);
			super.setBankRecordIndex(currentRecord.getString(MapKeys.INVOICE_NO), currentRecord);
		}
		
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for( FaturaMutabakat detail : details ){
			indexedCorporateRecords.put(detail.getId().toString(), detail);
		}
		
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(details[corporateRecordIndex].getId().toString());
	}
	
	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put("SUBSCRIBER_NO_1", details[corporateRecordIndex].getAboneNo());
		collectionDetailRequest.put(MapKeys.PAYMENT_DATE, input.getString(MapKeys.RECON_DATE));
		collectionDetailRequest.put(MapKeys.PAYMENT_AMOUNT, details[corporateRecordIndex].getTutar());
		collectionDetailRequest.put(MapKeys.INVOICE_NO, details[corporateRecordIndex].getId());
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put("SUBSCRIBER_NO_1", details[corporateRecordIndex].getAboneNo());
		cancelCollectionRequest.put(MapKeys.PAYMENT_DATE, input.getString(MapKeys.RECON_DATE));
		cancelCollectionRequest.put(MapKeys.PAYMENT_AMOUNT, details[corporateRecordIndex].getTutar());
		cancelCollectionRequest.put(MapKeys.INVOICE_NO, details[corporateRecordIndex].getId());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.INVOICE_NO));
	}

	private static String changeDate2CorpDate(String parsedDate) throws Exception{
		return CommonHelper.formatDateString(parsedDate, "yyyyMMdd", "dd.MM.yyyy");
	}

}
