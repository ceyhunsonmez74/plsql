package tr.com.aktifbank.bnspr.cps.cache;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.dao.CsCollectionTypeMapping;

import com.graymound.cache.GMCacheLoader;

public final class CPSCollectionTypeMappingLoader implements GMCacheLoader {

	private static final Log logger = LogFactory.getLog(CPSCollectionTypeMappingLoader.class);
	
	public CPSCollectionTypeMappingLoader() {
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> load() {
		Map<String, Object> map = new ConcurrentHashMap<String, Object>();
		try{
			List<CsCollectionTypeMapping> mappings = CommonHelper.getHibernateSession().createCriteria(CsCollectionTypeMapping.class)
					.list();
			for (CsCollectionTypeMapping csCollectionTypeMapping : mappings) {
				map.put(csCollectionTypeMapping.getCsCollectionTypeCode(), csCollectionTypeMapping);
				map.put(String.valueOf(csCollectionTypeMapping.getKftCollectionTypeCode()), csCollectionTypeMapping);
			}
		}
		catch(Exception e){
			logger.error("An exception occured while loading CollectionTypeMapping cache");
			logger.error(System.currentTimeMillis(), e);
		}
		
		return map;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object lookup(String arg0) {
		try{
			Short kftCollectionTypeCode = null;
			try{
				kftCollectionTypeCode = Short.valueOf(arg0);
			}
			catch(Exception e){
				kftCollectionTypeCode = null;
			}
			
			Criteria criteria = CommonHelper.getHibernateSession().createCriteria(CsCollectionTypeMapping.class);
			Disjunction disjunction = Restrictions.disjunction();
			disjunction.add(Restrictions.eq("csCollectionTypeCode", arg0));
			
			if(kftCollectionTypeCode != null){
				disjunction.add(Restrictions.eq("kftCollectionTypeCode", kftCollectionTypeCode));
			}
			
			
			List<CsCollectionTypeMapping> mappings = criteria
					.add(disjunction)
					.list();
			if(mappings.size() > 0){
				if(mappings.size() == 1){
					return mappings.get(0);
				}
				else{
					logger.warn(String.format("More than one record returned for %s argument.", arg0));
					return null;
				}
			}
			else{
				logger.warn(String.format("No mapping returned for %s argument", arg0));
				return null;
			}
		}
		catch(Exception e){
			logger.error(String.format("An exception occured while looking up for %s argument", arg0));
			logger.error(System.currentTimeMillis(), e);
			return null;
		}
	}

}
