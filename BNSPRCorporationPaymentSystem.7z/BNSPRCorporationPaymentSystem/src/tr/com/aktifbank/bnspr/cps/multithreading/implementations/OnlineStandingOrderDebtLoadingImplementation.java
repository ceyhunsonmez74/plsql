package tr.com.aktifbank.bnspr.cps.multithreading.implementations;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.OnlineStandingOrderDebtLoadingStarterInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.PartialParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cps.multithreading.core.ServiceBasedMultiThreading;

import com.graymound.util.GMMap;

public  class OnlineStandingOrderDebtLoadingImplementation extends ServiceBasedMultiThreading {
	private OnlineStandingOrderDebtLoadingStarterInformation information;
	
    public OnlineStandingOrderDebtLoadingImplementation(OnlineStandingOrderDebtLoadingStarterInformation p_information){
    	super();
    	this.information = p_information;
    }
    
    @Override
    protected void prepareCall() throws Throwable {
       
       int s = information.getCorporateMap().getSize(MapKeys.CORPORATE_LIST);
       String dateParam = information.getCorporateMap().getString(MapKeys.PROCESS_DATE);
       
      
       
       for (int i = 0; i < s; i++) {
    	   GMMap input = new GMMap();
    	   input.put(MapKeys.CORPORATE_BATCH_PROCESS_OID, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST,i,MapKeys.CORPORATE_BATCH_PROCESS_OID));
    	   
    	   input = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GET_CORPORATE_BATCH_PARAMETERS",input);
    	   
    	   input.put(MapKeys.PROCESS_DATE, dateParam);
    	   input.put(MapKeys.CORPORATE_CODE, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST,i,MapKeys.CORPORATE_CODE));
    	   input.put(MapKeys.BANK_CODE, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.BANK_CODE));
    	   input.put(MapKeys.BATCH_NAME, information.getCorporateMap().getString(MapKeys.CORPORATE_LIST, i, MapKeys.BATCH_NAME));  	  
    	   input.put("MASTER_SUBMIT_ID", information.getMasterSubmitId());
           super.registerService(this.information.getServiceName(), input);
           
          
       }
    }
        
    @Override
    protected ParallelCallBehaviour getParallelCallBehaviour() {
         return new PartialParallelCallBehaviour(this.information.getMaxParallelThreadCount(), true);
    }
}
