package tr.com.aktifbank.bnspr.cps.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class GMMapImposer {
	public static String pharantesisStart = "{";
	public static String pharantesisFinish = "}";
	public static String commaChar = ",";
	public static String equalChar = "=";
	public static String pharantesisFinishAndComma ="},";
	public static String teqelChar ="-";
	public static String bracketStart ="[";
	public static String bracketFinish ="]";
	public static String hashMapStarter = "=[{";
	public static String hashMapFinisher = "}]";
	public static String destroyer = "";
	public static String regularExpression = "\\[(.*?)\\]";
	
	public  static String[] removeNull(String[] a) {
		ArrayList<String> removed = new ArrayList();
	    for (String str : a)
	      if (str != null){
	    	  removed.add(str);
	      }
		return removed.toArray(new String[0]);
	}
	
	
	public static String[] returnParentKeyValue (String parsedString,String[] HashMapParentNames) {
		parsedString=parsedString.substring(1);
		for (int i = 0; i < HashMapParentNames.length; i++) {			
			parsedString = parsedString.replace(HashMapParentNames[i], "");	
		}
		
		String[] splitedString = parsedString.split(commaChar);
		String[] returnValue = new String[splitedString.length];
		
		for (int i = 0; i < splitedString.length; i++) {	
			if (!splitedString[i].contains(pharantesisStart) && !splitedString[i].contains(pharantesisFinish)&&!splitedString[i].contains(bracketStart) && !splitedString[i].contains(bracketFinish)) 
				returnValue[i] = splitedString[i];
		}
		
		return returnValue;
	} 
	
	public static GMMap fillGMMapChildKeyValues(String childKeyValueString,String childName,GMMap inMap) {
		childKeyValueString = childKeyValueString.replace(pharantesisFinishAndComma,teqelChar).trim();
		childKeyValueString = childKeyValueString.replace(hashMapFinisher,teqelChar).trim();
		String [] keyValuesRows =childKeyValueString.split(teqelChar);
		keyValuesRows=removeNull(keyValuesRows);
		for (int i = 0; i < keyValuesRows.length; i++) {
			String [] keyValues =keyValuesRows[i].replace(bracketStart,destroyer).replace(pharantesisStart,destroyer).replace(pharantesisFinish, destroyer).split(commaChar);
			keyValues=removeNull(keyValues);
			for (int j = 0; j < keyValues.length; j++) {
				String[] keysValues = keyValues[j].split(equalChar);
				keysValues=removeNull(keysValues);
				try {
					inMap.put(childName,i,keysValues[0].trim(),keysValues[1].trim());	
				} catch (Exception e) {
					inMap.put(childName,i,keysValues[0].trim(),"");
				}
								
			}
		}
		return inMap;
	}
	
	public static GMMap fillKeyValuePairs(String KeyValueString,GMMap inMap) {
		String[] keysValues = KeyValueString.split(equalChar);
		try {
			inMap.put(keysValues[0], keysValues[1]);	
		} catch (Exception e) {
			inMap.put(keysValues[0], "");
		}
		
		return inMap;	
	}

	
	@GraymoundService("BNSPR_CPS_GET_GMMAP_FROM_STRING")
	public static GMMap getGMMapfromStringService(GMMap iMap) {
		
		try {
			return (GMMap)CommonHelper.deserializeRequest(iMap.getString("FROM_STRING"));
		} catch (IOException e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static GMMap getGMMapfromString(String gmMaptoString) {
		GMMap outMap = new GMMap();
		String parsedString = gmMaptoString; 
		gmMaptoString = gmMaptoString.replace(hashMapStarter, teqelChar);
		gmMaptoString = gmMaptoString.replace(hashMapFinisher, teqelChar);
		gmMaptoString = gmMaptoString.replace(pharantesisStart, "");
		gmMaptoString = gmMaptoString.replace(pharantesisFinish, "");	

		String toBeParsedArraywithoutComma[] = gmMaptoString.split(commaChar);
		String[] HashMapPairs = new String[toBeParsedArraywithoutComma.length];			
		String[] KeyValuePairs = new String[toBeParsedArraywithoutComma.length];
		String[] HashMapParentNames =  new String[toBeParsedArraywithoutComma.length];
		
			
			for (int j = 0; j < toBeParsedArraywithoutComma.length; j++) {
				if (toBeParsedArraywithoutComma[j].contains(teqelChar)) {
					String toBeParsedArraywithoutCommaAndDelimeter[] =  toBeParsedArraywithoutComma[j].split(teqelChar);
					if(!toBeParsedArraywithoutCommaAndDelimeter[0].contains("=")){						
						HashMapPairs[j] = toBeParsedArraywithoutCommaAndDelimeter[0];	
					}
										
				}
			}			
			Pattern p = Pattern.compile(regularExpression);
			Matcher m = p.matcher(parsedString);
			int index = 0;
			HashMapPairs = removeNull(HashMapPairs);			
			while(m.find()) {				
				HashMapParentNames[index] = m.group(1);
			    index = index+1;			    
			}	
			HashMapParentNames = removeNull(HashMapParentNames);
			KeyValuePairs =	returnParentKeyValue(parsedString, HashMapParentNames);
			KeyValuePairs = removeNull(KeyValuePairs);
			for (int i = 0; i < HashMapParentNames.length; i++) {
				outMap = fillGMMapChildKeyValues(HashMapParentNames[i].trim(),HashMapPairs[i].trim(),outMap);								
			}
			
			for (int i = 0; i < KeyValuePairs.length; i++) {
				outMap = fillKeyValuePairs(KeyValuePairs[i],outMap);
			}
			return outMap;
		}
}
