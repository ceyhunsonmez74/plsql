package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import tr.com.aktifbank.bnspr.cps.batch.implementations.OutgoingFileBatch;
import tr.com.aktifbank.bnspr.cps.batch.implementations.OutgoingFileBatchFactory;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileBatchInformation;

import com.graymound.util.GMMap;

public final class ExecuteCorporateBatchHandler extends
		RequestHandler {
	
	private static final class ParameterKeys{
		public static final String WEEKEND_TO_WEEKDAY = "HAFTA_SONUNU_PTESI_CIK";
		public static final String SHOW_PAYMENT_DATE_AS_PROCESS_DATE = "BUGUN_ODENMIS_GIBI_GOSTER";
		public static final String INFORM_ONLY_STANDING_ORDER_PAYMENTS = "SADECE_TALIMATLI_ODEMELERI_GONDER";
		public static final String DELETE_DECIMAL_PART_FROM_AMOUNT = "TUTARDAN_KUSURATI_KALDIR";
		public static final String FIELD_LIMITATION = "ALAN_KISITLAMASI";
	}
	
	private static final class Days {
		public static final int SATURDAY = 6;
		public static final int SUNDAY = 7;
		public static final int MONDAY = 1;
	}
	
	public ExecuteCorporateBatchHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE);
		List<FormatDetail> bodyDetails = (List<FormatDetail>) input.get(TransactionConstants.CorporateGeneralBatchSubmit.Input.BODY_DETAILS);
		List<FormatDetail> headerDetails = (List<FormatDetail>) input.get(TransactionConstants.CorporateGeneralBatchSubmit.Input.HEADER_DETAILS);
		List<FormatDetail> footerDetails = (List<FormatDetail>) input.get(TransactionConstants.CorporateGeneralBatchSubmit.Input.FOOTER_DETAILS);
		Date invoiceDate = input.getDate(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE);
		BigDecimal ftmProcessId = input.getBigDecimal(TransactionConstants.CorporateGeneralBatchSubmit.Input.FTM_PROCESS_ID);
		GMMap databaseFields = input.getMap(TransactionConstants.CorporateGeneralBatchSubmit.Input.DATABASE_FIELDS);
		GMMap serviceFields = input.getMap(TransactionConstants.CorporateGeneralBatchSubmit.Input.SERVICE_FIELDS);
		GMMap batchParameters = input.getMap(TransactionConstants.CorporateGeneralBatchSubmit.Input.BATCH_PARAMETERS, null);
		short informIndicator = (short)input.getInt(TransactionConstants.CorporateGeneralBatchSubmit.Input.INFORM_INDICATOR);
		int lineNumber = input.getInt(TransactionConstants.CorporateGeneralBatchSubmit.Input.LINE_NUMBER, 1);
		
		OutgoingFileBatchInformation information = new OutgoingFileBatchInformation();
		information.setCorporateCode(corporateCode);
		information.setBodyDetails(bodyDetails);
		information.setHeaderDetails(headerDetails);
		information.setFooterDetails(footerDetails);
		information.setProcessDate(invoiceDate);
		information.setFtmProcessId(ftmProcessId);
		information.setDatabaseFields(databaseFields);
		information.setServiceFields(serviceFields);
		information.setOutgoingFileBatchInput(input);
		information.setHibernateSession(super.getHibernateSession());
		information.setLineNumber(lineNumber);
		
		if(batchParameters != null){
			logger.info("Batch parameters is not null : " + batchParameters.toString());
			if(batchParameters.containsKey(ParameterKeys.WEEKEND_TO_WEEKDAY) && 
					batchParameters.getString(ParameterKeys.WEEKEND_TO_WEEKDAY).equals(DatabaseConstants.BatchParameterValues.WeekendToWeekdayEnabled)){
				int currentDay = CommonHelper.getDayOfWeekInTurkishLocale(invoiceDate);
				logger.info("WEEKEND_TO_WEEKDAY parameter is active. Current day number is : " + String.valueOf(currentDay) + " invoice date : " + CommonHelper.getShortDateTimeString(invoiceDate));
				if(currentDay == Days.SATURDAY || currentDay == Days.SUNDAY){
					logger.info("Current day is sunday or saturday, batch will pass today.");
					output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.RESULT, false);
					output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_CODE, GeneralConstants.NOT_PROCESS_WEEKEND_CODE);
					output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_MESSAGE, "");
					return;
				}
				else if(currentDay == Days.MONDAY){
					logger.info("Current day is monday. Batch will process whole weekend if parameter exists");
					information.setProcessWeekend(true);
					if(batchParameters.containsKey(ParameterKeys.SHOW_PAYMENT_DATE_AS_PROCESS_DATE) &&
							batchParameters.getString(ParameterKeys.SHOW_PAYMENT_DATE_AS_PROCESS_DATE).
								equals(DatabaseConstants.BatchParameterValues.ShowPaymentDateAsProcessDate)){
						logger.info("SHOW_PAYMENT_DATE_AS_PROCESS_DATE parameter active. Batch will show payment day as today");
						information.setShowPaymentDateAsToday(true);
					}
					else{
						information.setShowPaymentDateAsToday(false);
					}
				}
				else{
					information.setProcessWeekend(false);
				}
			}
			if(batchParameters.containsKey(ParameterKeys.INFORM_ONLY_STANDING_ORDER_PAYMENTS) &&
					batchParameters.getString(ParameterKeys.INFORM_ONLY_STANDING_ORDER_PAYMENTS).equals(DatabaseConstants.BatchParameterValues.InformOnlyStandingOrderPaymentsEnabled)){
				information.setInformOnlyStandingOrderPayments(true);
			}
			if(batchParameters.containsKey(ParameterKeys.DELETE_DECIMAL_PART_FROM_AMOUNT) &&
					batchParameters.getString(ParameterKeys.DELETE_DECIMAL_PART_FROM_AMOUNT).equals(DatabaseConstants.BatchParameterValues.DeleteDecimalPartEnabled)){
				information.setDeleteDecimalPart(true);
			}
			if(batchParameters.containsKey(ParameterKeys.FIELD_LIMITATION)){
				information.setFieldLimitationPattern(batchParameters.getString(ParameterKeys.FIELD_LIMITATION));
			}
		}
		
		logger.info("Creating outgoing file batch instance with factory command : " + informIndicator);
		
		OutgoingFileBatch batch = OutgoingFileBatchFactory.getInstance().createBatch(informIndicator, information);
		logger.info("Executing outgoing file batch");
		batch.execute();
		
		if( batch.isErrorExist() ){
			String errorMessage = batch.getErrorMessage();
			String errorCode = batch.getErrorCode();
			
			logger.error(String.format("An exception occurred while executing outgoing file batch was prepared. Details [Error Code : %s ], [Error Description : %s ]"
					, errorCode
					, errorMessage));
			
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.RESULT, false);
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_CODE, errorCode);
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_MESSAGE, errorMessage);
		}
		else{
			logger.info("Flushing lines to database");
			super.getHibernateSession().flush();
			
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.RESULT, true);
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.AFTER_PROCESS_LINE_NUMBER, information.getAfterProcessLineNumber());
			output.put("TOTAL_COUNT", batch.getDetailLineCount());
			output.put("TOTAL_AMOUNT", batch.getTotalAmount());
		}
		
	}
}
