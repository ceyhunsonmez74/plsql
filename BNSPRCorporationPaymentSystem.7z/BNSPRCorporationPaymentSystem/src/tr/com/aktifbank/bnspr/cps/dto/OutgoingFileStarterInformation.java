package tr.com.aktifbank.bnspr.cps.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public final class OutgoingFileStarterInformation extends
		BaseTransferObject {

	public OutgoingFileStarterInformation() {
		this.invoiceCollectionInformation = new ArrayList<OutgoingFileCorporateInformation>();
	}

	private List<OutgoingFileCorporateInformation> invoiceCollectionInformation;
	private int maxParallelThreadCount;
	private Date processDate;
	private String serviceName;
	private short informIndicator;

	public short getInformIndicator() {
		return informIndicator;
	}

	public void setInformIndicator(short informIndicator) {
		this.informIndicator = informIndicator;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Date getProcessDate() {
		return processDate;
	}

	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}

	public int getMaxParallelThreadCount() {
		return maxParallelThreadCount;
	}

	public void setMaxParallelThreadCount(int maxParallelThreadCount) {
		this.maxParallelThreadCount = maxParallelThreadCount;
	}

	public List<OutgoingFileCorporateInformation> getInvoiceCollectionInformation() {
		return invoiceCollectionInformation;
	}

	public void setInvoiceCollectionInformation(
			List<OutgoingFileCorporateInformation> invoiceCollectionInformation) {
		this.invoiceCollectionInformation = invoiceCollectionInformation;
	}
	
	public void addToInvoiceCollectionInformation(OutgoingFileCorporateInformation information){
		this.invoiceCollectionInformation.add(information);
	}
	
}
