package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.dao.StandingOrderBacklog;
import tr.com.aktifbank.bnspr.dao.StandingOrderMain;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class CheckStandingOrderBillsHandler extends RequestHandler {

	final String INVOICES = "INVOICES";
	
	public CheckStandingOrderBillsHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Date currentDate = new Date();
		
		Criteria criteria = super.getHibernateSession().createCriteria(icsStandingOrders.class).add(Restrictions.eq("status", true));
		
		DetachedCriteria subSelect = DetachedCriteria.forClass(StandingOrderMain.class).setProjection(Property.forName("oid"))
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("standingOrderType", "KFT"))				
									.add(Restrictions.eq("standingOrderStatus", DatabaseConstants.StandingOrderStatus.Active));		
		
		criteria.add(Property.forName("standingOrderOid").in(subSelect));		
		List<icsStandingOrders> stdOrderList = criteria.list();
		
		for (icsStandingOrders order : stdOrderList) {
			try {
				GMMap debtInquiryRequest = new GMMap();
				debtInquiryRequest.put(MapKeys.CORPORATE_CODE, order.getCorporateCode());
				debtInquiryRequest.put(MapKeys.COLLECTION_TYPE, order.getCollectionType());
				if(!StringUtil.isEmpty(order.getSubscriberNo1())){
					debtInquiryRequest.put(MapKeys.SUBSCRIBER_NO1, order.getSubscriberNo1());
				}
				if(!StringUtil.isEmpty(order.getSubscriberNo2())){
					debtInquiryRequest.put(MapKeys.SUBSCRIBER_NO2, order.getSubscriberNo2());
				}
				if(!StringUtil.isEmpty(order.getSubscriberNo3())){
					debtInquiryRequest.put(MapKeys.SUBSCRIBER_NO3, order.getSubscriberNo3());
				}
				if(!StringUtil.isEmpty(order.getSubscriberNo4())){
					debtInquiryRequest.put(MapKeys.SUBSCRIBER_NO4, order.getSubscriberNo4());
				}
				
				GMMap response = super.callGraymoundServiceOutsideSession("ICS_SEARCH_INVOICE", debtInquiryRequest);
				
				for (int i = 0; i < response.getSize(INVOICES); i++) {
					String dueDate = response.getString(INVOICES, i, "INVOICE_DUE_DATE");
					if(!StringUtil.isEmpty(dueDate)){
						if(isDueDateBeforeCurrentDate(dueDate, currentDate)){
							continue;
						}
					}
					String invoiceNo = response.getString(INVOICES, i, "INVOICE_NO");
					String subscriberName = response.getString(INVOICES, i, "SUBSCRIBER_NAME");
					BigDecimal amount = response.getBigDecimal(INVOICES, i, "INVOICE_AMOUNT");
					if(doesInvoiceExistOnDb(order, dueDate, invoiceNo, subscriberName, amount)){
						continue;
					}
					
					StandingOrderBacklog log = new StandingOrderBacklog();
					log.setStatus(true);
					log.setCorporateCode(order.getCorporateCode());
					log.setStandingOrderOid(order.getStandingOrderOid());
					log.setSubscriberNo1(order.getSubscriberNo1());
					log.setSubscriberNo2(order.getSubscriberNo2());
					log.setSubscriberNo3(order.getSubscriberNo3());
					log.setSubscriberNo4(order.getSubscriberNo4());
					log.setSubscriberName(subscriberName);
					log.setInvoiceNo(invoiceNo);
					log.setInvoiceDueDate(dueDate);
					log.setAmount(amount);
					log.setIsLoaded(false);
					log.setIsPaid(false);
					log.setEstLoadDate(dueDate);
					super.getHibernateSession().save(log);
				}
			} catch (Exception e) {
				logger.error(String.format("An exception occured while searching invoice for %s standing order oid", order.getStandingOrderOid()));
				logger.error(System.currentTimeMillis(), e);
			}
		}
	}

	private boolean doesInvoiceExistOnDb(icsStandingOrders order, String dueDate, String invoiceNo, String subscriberName, BigDecimal amount) {
		if(StringUtil.isEmpty(dueDate) && StringUtil.isEmpty(invoiceNo) && StringUtil.isEmpty(subscriberName)){
			return false;
		}
		
		Criteria criteria = super.getHibernateSession().createCriteria(StandingOrderBacklog.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", order.getCorporateCode()))
				.add(Restrictions.eq("standingOrderOid", order.getStandingOrderOid()));
		
		if(!StringUtil.isEmpty(order.getSubscriberNo1())){
			criteria = criteria.add(Restrictions.eq("subscriberNo1", order.getSubscriberNo1()));
		}
		if(!StringUtil.isEmpty(order.getSubscriberNo2())){
			criteria = criteria.add(Restrictions.eq("subscriberNo2", order.getSubscriberNo2()));
		}
		if(!StringUtil.isEmpty(order.getSubscriberNo3())){
			criteria = criteria.add(Restrictions.eq("subscriberNo3", order.getSubscriberNo3()));
		}
		if(!StringUtil.isEmpty(order.getSubscriberNo4())){
			criteria = criteria.add(Restrictions.eq("subscriberNo4", order.getSubscriberNo4()));
		}
		
		if(!StringUtil.isEmpty(subscriberName)){
			criteria = criteria.add(Restrictions.eq("subscriberName", subscriberName));
		}
		
		if(!StringUtil.isEmpty(dueDate)){
			criteria = criteria.add(Restrictions.eq("invoiceDueDate", dueDate));
		}
		
		if(!StringUtil.isEmpty(invoiceNo)){
			criteria = criteria.add(Restrictions.eq("invoiceNo", invoiceNo));
		}
		
		criteria = criteria.add(Restrictions.eq("amount", amount));
		
		return ((Number)criteria.setProjection(Projections.rowCount()).uniqueResult()).intValue() > 0;
	}

	private boolean isDueDateBeforeCurrentDate(String dueDate, Date currentDate) {
		long date = Long.valueOf(dueDate);
		long curDate = Long.valueOf(CommonHelper.getShortDateTimeString(currentDate));
		
		return curDate > date;
	}

}
