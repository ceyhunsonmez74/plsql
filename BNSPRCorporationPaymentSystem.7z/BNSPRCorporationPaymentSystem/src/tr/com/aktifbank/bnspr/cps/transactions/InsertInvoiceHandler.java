package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Date;
import java.util.UUID;
import java.util.concurrent.ConcurrentSkipListSet;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.SingleInstanceMemory;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class InsertInvoiceHandler extends RequestHandler {

	private static final String COLLECTION_TYPE_COLUMN = "COLLECTION_TYPE";
	
	private static final class BagKeys{
		public static final Short OPENED_CONNECTION = 1;
		public static final Short OPENED_STATEMENT = 2;
	}
	
	public InsertInvoiceHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String step = ""; 
		String subMessage = "";
		try {
			if(input.containsKey(TransactionConstants.InsertInvoice.Input.DIRECT_INSERT) && input.getBoolean(TransactionConstants.InsertInvoice.Input.DIRECT_INSERT)){
				Connection connection = null;
				Statement statement = null;
				
				int notLoadedCount = 0;
				BigDecimal notLoadedAmount = BigDecimal.ZERO;
				
				connection = CommonHelper.getConnection();
				super.bag.put(BagKeys.OPENED_CONNECTION, connection);
				statement = connection.createStatement();
				super.bag.put(BagKeys.OPENED_STATEMENT, statement);
				
				String submitId = input.getString(TransactionConstants.InsertInvoice.Input.SUBMIT_ID);
				boolean controlInvoiceNo = input.getBoolean(TransactionConstants.InsertInvoice.Input.CONTROL_INVOICE_NO);
				boolean controlInvoiceDueDate = input.getBoolean(TransactionConstants.InsertInvoice.Input.CONTROL_INVOICE_DUE_DATE);
				
				ConcurrentSkipListSet<String> indicatorList = (ConcurrentSkipListSet<String>)SingleInstanceMemory.getInstance().getCacheObject(submitId);
				step = "Started";
				for (int i = 0; i < input.getSize(TransactionConstants.InsertInvoice.Input.INSERT_PAIR_TABLE); i++) {
					GMMap directInsertMap = (GMMap)input.get(TransactionConstants.InsertInvoice.Input.INSERT_PAIR_TABLE, 
							i, 
							TransactionConstants.InsertInvoice.Input.INSERT_KEYVALUE_PAIRS);
					subMessage = directInsertMap.toString();
					
					String corporateCode = input.getString(TransactionConstants.InsertInvoice.Input.CORPORATE_CODE);
					
					String indicator = "";
					
					if(controlInvoiceNo){
						if(directInsertMap.containsKey("INVOICE_NO")){
							indicator = indicator.concat(directInsertMap.getString("INVOICE_NO"));
						}
						else{
							throw new Exception("Fatura kay�t bilgilerinde fatura numaras� bulunamad�. E�er kurumun dosyas�nda fatura numaras� bilgisi bulunmuyorsa l�tfen " +
									"Batch Y�netim Ekran�nda FATURA_NO_KONTROL_ET parametresini HAYIR olarak ekleyiniz.");
						}
					}

					if (controlInvoiceDueDate) {
						if (directInsertMap.containsKey("INVOICE_DUE_DATE")) {
							indicator = indicator.concat(directInsertMap
									.getString("INVOICE_DUE_DATE"));
						}
						else{
							throw new Exception("Fatura kay�t bilgilerinde son �deme tarihi bulunamad�. E�er kurumun dosyas�nda son �deme tarihi bilgisi bulunmuyorsa l�tfen " +
									"Batch Y�netim Ekran�nda SON_ODEME_TARIHI_KONTROL_ET parametresini HAYIR olarak ekleyiniz.");
						}
					}
					indicator = indicator.concat(directInsertMap.getString("AMOUNT"));
					indicator = indicator.concat(directInsertMap.getString("SUBSCRIBER_NO1"));
					
					if(directInsertMap.containsKey("SUBSCRIBER_NO2") && !StringUtil.isEmpty(directInsertMap.getString("SUBSCRIBER_NO2"))){
						indicator = indicator.concat(directInsertMap.getString("SUBSCRIBER_NO2"));
					}
					
					if(directInsertMap.containsKey("SUBSCRIBER_NO3") && !StringUtil.isEmpty(directInsertMap.getString("SUBSCRIBER_NO3"))){
						indicator = indicator.concat(directInsertMap.getString("SUBSCRIBER_NO3"));
					}
					
					if(directInsertMap.containsKey("SUBSCRIBER_NO4") && !StringUtil.isEmpty(directInsertMap.getString("SUBSCRIBER_NO4"))){
						indicator = indicator.concat(directInsertMap.getString("SUBSCRIBER_NO4"));
					}
					
					if(indicatorList.contains(indicator)){
						logger.info(String.format("Invoice with %s map exists on database", directInsertMap.toString()));
						notLoadedCount++;
						notLoadedAmount = notLoadedAmount.add(directInsertMap.getBigDecimal("AMOUNT"));
						continue;
					}
					
					StringBuilder columnNameBuilder = new StringBuilder();
					StringBuilder valueBuilder = new StringBuilder();
					boolean collectionTypeExists = false;
					for(Object key : directInsertMap.keySet()){
						if(((String)key).equals(COLLECTION_TYPE_COLUMN)){
							collectionTypeExists = true;
						}
						columnNameBuilder.append(String.format("%s,", key));
						Object value = directInsertMap.get(key);
						if(value instanceof String){
							valueBuilder.append(String.format("'%s',", value));
						}
						else if(value instanceof Date){
							valueBuilder.append(String.format("'%s',", CommonHelper.getShortDateTimeString((Date)value)));
						}
						else{
							valueBuilder.append(String.format("%s,", value));
						}
					}
					String query = String.format("INSERT INTO ICS.INVOICE_MAIN(OID,CORPORATE_CODE,%s,STATUS,PAYMENT_METHOD,LOADING_DATE,LOADING_USER,FTM_SEQUENCE_NUMBER,PAYMENT_STATUS,INVOICE_STATUS,PAYMENT_AMOUNT%s) VALUES('%s','%s',%s,0,'S','%s','%s',%s,'%s','%s',0%s)", 
							CommonHelper.trimEnd(columnNameBuilder.toString(), ','), 
							collectionTypeExists ? "" : String.format(",%s", COLLECTION_TYPE_COLUMN),
							UUID.randomUUID().toString().substring(0, 32),
							corporateCode,
							CommonHelper.trimEnd(valueBuilder.toString(), ','),
							CommonHelper.getLongDateTimeString(new Date()),
							CommonHelper.getCurrentUser(),
							input.getBigDecimal(TransactionConstants.InsertInvoice.Input.FTM_TRANSFER_ID),
							DatabaseConstants.PaymentStatuses.Waiting,
							DatabaseConstants.InvoiceStatuses.Active,
							collectionTypeExists ? "" : String.format(",%s", DatabaseConstants.CollectionTypes.InvoiceLoad));
					//logger.info(query);
					statement.addBatch(query);
				}
				step = "Executing batch";
				statement.executeBatch();
				
				output.put(TransactionConstants.InsertInvoice.Output.RETURN_CODE, 0);
				output.put("NOT_INSERTED_COUNT", notLoadedCount);
				output.put("NOT_INSERTED_AMOUNT", notLoadedAmount);
			}
			else{
				throw new BatchComponentException("No implementation found other than direct insert at inser invoice handler", BusinessException.SYSTEM);
			}
		} catch (Exception e) {
			logger.error(String.format("An exception occured while inserting invoices with subMessage : %s, step : %s .", subMessage, step));
			logger.error(System.currentTimeMillis(), e);
			output.put(TransactionConstants.InsertInvoice.Output.RETURN_CODE, 1);
			output.put(TransactionConstants.InsertInvoice.Output.RETURN_MESSAGE, "Fatura kay�tlar�n� eklerken bir hata olu�tu : " + e.toString());
		}
	}
	
	@Override
	protected void handleFinally(GMMap output) {
		try{
			CommonHelper.closeAll(super.bag.get(BagKeys.OPENED_STATEMENT), super.bag.get(BagKeys.OPENED_CONNECTION));
		}
		catch(Exception e){
			logger.error("An exception occured while closing statement and connection");
			logger.error(System.currentTimeMillis(), e);
		}
	}

}
