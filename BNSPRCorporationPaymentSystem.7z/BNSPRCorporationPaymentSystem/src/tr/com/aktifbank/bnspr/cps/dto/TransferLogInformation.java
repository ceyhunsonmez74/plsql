package tr.com.aktifbank.bnspr.cps.dto;

import java.math.BigDecimal;
import java.util.List;

public final class TransferLogInformation extends BaseTransferObject {

	public TransferLogInformation() {
		super();
	}
	
	private BigDecimal transferredAmount;
	private BigDecimal actualAmount;
	private BigDecimal constantAmount;
	private BigDecimal availableBalance;
	private List<String> channels;
	private String branchCode;
	private String branchName;
	private String description;
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public List<String> getChannels() {
		return channels;
	}
	public void setChannels(List<String> channels) {
		this.channels = channels;
	}
	public BigDecimal getTransferredAmount() {
		return transferredAmount;
	}
	public void setTransferredAmount(BigDecimal transferredAmount) {
		this.transferredAmount = transferredAmount;
	}
	public BigDecimal getActualAmount() {
		return actualAmount;
	}
	public void setActualAmount(BigDecimal actualAmount) {
		this.actualAmount = actualAmount;
	}
	public BigDecimal getConstantAmount() {
		return constantAmount;
	}
	public void setConstantAmount(BigDecimal constantAmount) {
		this.constantAmount = constantAmount;
	}
	public BigDecimal getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(BigDecimal availableBalance) {
		this.availableBalance = availableBalance;
	}
	
	

}
