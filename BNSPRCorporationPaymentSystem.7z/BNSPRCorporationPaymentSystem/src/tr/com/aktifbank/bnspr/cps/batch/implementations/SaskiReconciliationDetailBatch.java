package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.ReconDetailData;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.saski.SaskiClient;
import tr.com.aktifbank.integration.saski.ServiceMessage;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.saski.ReconciliationDailyDetailDto;
import tr.com.saski.ReconciliationDailyDetailResponse;

import com.graymound.util.GMMap;

public final class SaskiReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(SamgazReconciliationDetailBatch.class);
	Session session;
	List<ReconciliationDailyDetailDto> details = new ArrayList<ReconciliationDailyDetailDto>();
	ServiceMessage message;
	Map<String, ReconciliationDailyDetailDto> indexedCorporateRecords;

	public SaskiReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, ReconciliationDailyDetailDto>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER_3, details.get(corporateRecordIndex).getBankReceiptNumber());
		cancelCollectionRequest.put(MapKeys.PAYMENT_DATE, details.get(corporateRecordIndex).getBankPaymentDate());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String wsUserName = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER); 
			String wsPassword = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD);
			String wsUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			
			String cashCode=wsUserName; //Vezne (cashCode) parametresi 0(s�f�r) olarak verilirseilgili bankan�n t�m veznelerinin �zetini verir.

			
			String paymentDate ="";
			Long bankOfficeNumber=new Long(0);
			
	
			Long bankDeskNumber=new Long(0);
			Boolean forDischarge=false;
			
			SaskiClient client = new SaskiClient(wsUrl, wsUserName, wsPassword);
			
			if(!StringUtil.isEmpty(input.getString(MapKeys.RECON_DATE))){
				paymentDate = CommonHelper.getDateString(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "dd/MM/yyyy");
			}else{
				paymentDate = CommonHelper.getDateString(new Date(), "dd/MM/yyyy");
			}
			ServiceMessage serviceMessage= new ServiceMessage();
			Long groupByMethod = new Long(0);
			ReconciliationDailyDetailResponse  response = client.reconciliationDailyDetail(serviceMessage, cashCode, paymentDate, bankOfficeNumber, bankDeskNumber, groupByMethod, forDischarge);
			
			

			for (ReconciliationDailyDetailDto detail : response.getList()) {
					details.add(detail);
			}
			result.setSuccessfulCall(true);
		}
		catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.PARAMETER3, details.get(corporateRecordIndex).getBankReceiptNumber());

	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.PARAMETER3) );
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.PARAMETER3) , super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getBankReceiptNumber() , this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getBankReceiptNumber());
	}

	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex) throws Exception {
		ReconciliationDailyDetailDto corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Abone Numaras� : %s, Referans No : %s, Miktar : %s ", 
				corporateDetail.getAgreementNumber(), 
				corporateDetail.getBankReceiptNumber(), 
				corporateDetail.getTotalPay()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(CommonHelper.trimStart(corporateDetail.getAgreementNumber(), '0'));
		payment.setInvoiceNo(corporateDetail.getBillNumber().toString());
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setParameter3(corporateDetail.getBankReceiptNumber());//transactionId
		payment.setParameter1(corporateDetail.getAccrueId().toString());//transactionId
		payment.setInvoiceAmount(corporateDetail.getTotalPay());
		payment.setPaymentAmount(corporateDetail.getTotalPay());
		payment.setPaymentDate(CommonHelper.formatDateString(input.getString(MapKeys.RECON_DATE), "dd/MM/yyyy", "yyyyMMdd") + "120000");
		payment.setCancelDate(CommonHelper.formatDateString(input.getString(MapKeys.RECON_DATE), "dd/MM/yyyy", "yyyyMMdd") + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getAgreementNumber());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, corporateDetail.getBillNumber());
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getTotalPay());
	}

}
