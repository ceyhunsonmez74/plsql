package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CollectionTypePrm;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class DoGSMMoneyLoad extends RequestHandler {
	
	private static class BagKeys{
		public static final String TRANSACTION_NO = "TRANSACTION_NO"; 
	}
	
	public DoGSMMoneyLoad() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Session session = CommonHelper.getHibernateSession();
		String corporateCode = input.getString(TransactionConstants.DoGSMMoneyLoad.Input.CORPORATE_CODE);
		String transactionNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString("TRX_NO");
		input.put(TransactionConstants.DoGSMMoneyLoad.Output.TRX_NO, transactionNo);
		
		if(corporateCode == null || corporateCode == ""){
			CorporateMaster cm = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("status", true)).
										add(Restrictions.eq("oid", input.getString(TransactionConstants.DoGSMMoneyLoad.Input.CORPORATE_OID))).uniqueResult();
			corporateCode = cm.getCorporateCode();
			input.put(TransactionConstants.DoGSMMoneyLoad.Input.CORPORATE_CODE, corporateCode);
		}
		input.put(TransactionConstants.DoGSMMoneyLoad.Input.BRANCH_CODE, String.valueOf(CommonHelper.getUserBranch()));
		
		String channelId = input.getString(TransactionConstants.DoGSMMoneyLoad.Input.CHANNEL_CODE); 
		if(channelId == null || channelId == ""){
			channelId = CommonHelper.getChannelId();
		}
		channelId = Integer.parseInt(channelId) +"";//tablodaki kayit sekli 1,2,3 seklinde
		input.put(TransactionConstants.DoGSMMoneyLoad.Input.CHANNEL_CODE, channelId);
		
		String source = input.getString(TransactionConstants.DoGSMMoneyLoad.Input.SOURCE);
		if(source == null || source == ""){//odeme kanali eger null ise default secilir 
			source = "1";
			input.put(TransactionConstants.DoGSMMoneyLoad.Input.SOURCE, source);
		}
		source = Integer.parseInt(source) +"";//tablodaki kayit sekli 1,2,3 seklinde
		
		// Get CollectionTypeText
		input.put("INVOICE_MAIN_OID", "0"); // online kurumlar icin invoice_main_oid = 0
		String collectionType = input.getString(TransactionConstants.DoGSMMoneyLoad.Input.COLLECTION_TYPE);
		if(collectionType == null || collectionType.isEmpty()){
			collectionType = DatabaseConstants.CollectionTypes.TLLoad; 
			input.put(TransactionConstants.DoGSMMoneyLoad.Input.COLLECTION_TYPE, Short.valueOf(collectionType)); // COLLECTION_TYPE = 1 TL Yukleme
		}
		
		if(input.containsKey(TransactionConstants.DoGSMMoneyLoad.Input.COLLECTION_TYPE)){
			CollectionTypePrm collectionTypePrm=(CollectionTypePrm) session.createCriteria(CollectionTypePrm.class)
					.add(Restrictions.eq("collectionType", Short.valueOf(collectionType))).uniqueResult();
			
			String collectionTypeName = collectionTypePrm.getCollectionName();
			input.put(TransactionConstants.DoGSMMoneyLoad.Input.COLLECTION_TYPE_NAME, collectionTypeName);
		}
		bag.put(BagKeys.TRANSACTION_NO, transactionNo);
		
		//Control corporate is active
		GMMap corpMap = new GMMap();
		corpMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corporateDefinitionOutput = super.callGraymoundServiceInSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, corpMap);
		
		if(!corporateDefinitionOutput.getBoolean(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_ACTIVENESS)){
			throw new BatchComponentException(BusinessException.CORPORATEISNOTACTIVE, corporateCode);
		}

		// COMISSION_AMOUNT = 0
		input.put(MapKeys.COMMISION_AMOUNT, BigDecimal.ZERO);
		input.put(MapKeys.BSMV_AMOUNT, BigDecimal.ZERO);
		if (input.getString("OBJECT")==null) {
			input.put(TransactionConstants.DoGSMMoneyLoad.Input.PACKAGE_ID, input.getString(TransactionConstants.DoGSMMoneyLoad.Input.PACKAGE_ID));
		}else{
			input.put(TransactionConstants.DoGSMMoneyLoad.Input.PACKAGE_ID, input.getString("OBJECT"));
		}
		
		if(!input.containsKey(TransactionConstants.DoGSMMoneyLoad.Input.QUERY_REF_NO)){
			input.put(TransactionConstants.DoGSMMoneyLoad.Input.QUERY_REF_NO, transactionNo);
		}
		
		GMMap channelWorkingDayControlResult = super.callServiceWithParams(TransactionConstants.CorporateChannelWorkingHourControl.SERVICE_NAME, 
				TransactionConstants.CorporateChannelWorkingHourControl.Input.CHANNEL_CODE, channelId,
				TransactionConstants.CorporateChannelWorkingHourControl.Input.CORPORATE_CODE, corporateCode,
				TransactionConstants.CorporateChannelWorkingHourControl.Input.SOURCE_CODE, source,
				TransactionConstants.CorporateChannelWorkingHourControl.Input.DATE, new Date());
		if(channelWorkingDayControlResult.getBoolean(TransactionConstants.CorporateChannelWorkingHourControl.Output.RESULT)){
			// No Problem
		}
		
		//CORPORATE_ACCOUNT_NO alanini doldurmak icin
		GMMap accountControlResult = super.callServiceWithParams(TransactionConstants.CorporateAccountControl.SERVICE_NAME, 
				TransactionConstants.CorporateAccountControl.Input.CHANNEL_CODE, channelId,
				TransactionConstants.CorporateAccountControl.Input.CORPORATE_CODE, corporateCode,
				TransactionConstants.CorporateAccountControl.Input.SOURCE_CODE, source,
				TransactionConstants.CorporateAccountControl.Input.COLLECTION_TYPE, collectionType);
		if(accountControlResult.getBoolean(TransactionConstants.CorporateAccountControl.Output.RESULT)){
			// NO PROBLEM
		}		
		input.put(TransactionConstants.DoGSMMoneyLoad.Input.CORPORATE_ACCOUNT_NO, accountControlResult.getBigDecimal(TransactionConstants.CorporateAccountControl.Output.ACCOUNT_NO));
				
		insertGsmMoneyLoadLog(input);
		
		if(source.equals(DatabaseConstants.SourceCodes.Account) && CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "DEBIT_EMV_SWITCH").equals("1")){
			GMMap map = new GMMap();
			map.put(TransactionConstants.DoGSMMoneyLoad.Output.ACCOUNT_NO, input.getBigDecimal(TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_ACCOUNT_NO));
			map.put("AMOUNT", input.get(TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_AMOUNT));
			map.put(TransactionConstants.DoGSMMoneyLoad.Output.TRX_NO, transactionNo);
			super.callGraymoundServiceInSession("DEBIT_EMV_TRANSACTION", map);
		}
		
		input.put(MapKeys.TRX_NAME, "7030");
		input.put(MapKeys.TRX_NO, transactionNo);
		output.put(TransactionConstants.DoGSMMoneyLoad.Output.TRX_NO, transactionNo);
		
		GMMap transactionMap = super.callGraymoundServiceInSession("BNSPR_TRX_SEND_TRANSACTION", input);
		output.put("MESSAGE", transactionMap.getString("MESSAGE"));
		
		//Online kurum
		input.put(MapKeys.BANK_CODE, corporateDefinitionOutput.getString(MapKeys.BANK_CODE));
		input.put(MapKeys.CORPORATE_CODE, corporateDefinitionOutput.getString(MapKeys.CORPORATE_CODE));
		input.put(MapKeys.IS_MANDATORY_SERVICE, true);
		
		if(collectionType.equals(DatabaseConstants.CollectionTypes.TLLoad))
			input.put(MapKeys.GM_SERVICE_NAME, TransactionConstants.DoGSMMoneyLoad.SERVICE_NAME);
		else if (collectionType.equals(DatabaseConstants.CollectionTypes.InternetPackages))
			input.put(MapKeys.GM_SERVICE_NAME, TransactionConstants.DoGSMMoneyLoad.SERVICE_NAME_INTERNET_PACKAGE);
		else if(collectionType.equals(DatabaseConstants.CollectionTypes.VoicePackages))
			input.put(MapKeys.GM_SERVICE_NAME, TransactionConstants.DoGSMMoneyLoad.SERVICE_NAME_VOICE_PACKAGE);
		
		input.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
		GMMap oMap = GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", input);
		
		//gelen degerleri return map e doldur
		output.put("STATUS_CODE", oMap.getString("STATUS_CODE"));
		output.put("STATUS_DESC", oMap.getString("STATUS_DESC"));
		output.put(MapKeys.ERROR_CODE, oMap.getString(MapKeys.ERROR_CODE));
		output.put(MapKeys.ERROR_DESC, oMap.getString(MapKeys.ERROR_DESC));		
	}

	private void insertGsmMoneyLoadLog(GMMap input) {
		super.callGraymoundServiceOutsideSession("ICS_INSERT_GSM_MONEY_LOAD_LOG", input);
	}
	
	@Override
	protected void handleError(Throwable e, GMMap output) {
		//super.callServiceWithParams("ICS_ROLLBACK_INVOICE_PAYMENT_LOG", false, MapKeys.TRX_NO, (BigDecimal)bag.get(BagKeys.TRANSACTION_NO));
		super.handleError(e, output);
	}

}
