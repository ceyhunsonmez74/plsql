package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.MoneyLoadReconciliationStarterHandlerRepository;
import tr.com.aktifbank.bnspr.cps.dto.CollectionReconciliationStarterInformation;
import tr.com.aktifbank.bnspr.cps.multithreading.implementations.CollectionReconciliationImplementation;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public class MoneyLoadReconciliationStarterHandler extends RequestHandler {


    @Override
    protected void handleInternal(GMMap input, GMMap output) throws Throwable {
    	
    	String tableNameCorporates = "BATCH_CORPORATES";
		GMMap batchCorporateList = DALUtil.getResults(MoneyLoadReconciliationStarterHandlerRepository.FETCH_RECON_CORPORATES, tableNameCorporates);
	
		CollectionReconciliationStarterInformation information = new CollectionReconciliationStarterInformation();
		
		if (input.containsKey("PROCESS_DATE")) {
			information.getCorporateMap().put("PROCESS_DATE", input.getString("PROCESS_DATE"));
		}else {
			information.getCorporateMap().put("PROCESS_DATE",CommonHelper.getShortDateTimeString(new Date()));
		}
		
		information.setServiceName("ICS_MONEY_LOAD_RECONCILIATION");
		information.setMaxParallelThreadCount(5); //paramtext den al�nabilir
		information.setProcessDate(new Date());
		
		for (int i = 0; i < batchCorporateList.getSize(tableNameCorporates); i++) {
			
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_ACTIVENESS, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_ACTIVENESS));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_BANK_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_BANK_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_NAME, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_NAME));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.COUNT_TYPE_AFTER_DUE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.COUNT_TYPE_AFTER_DUE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CREATE_DATE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.CREATE_DATE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CREATE_USER,batchCorporateList.getString(tableNameCorporates, i, MapKeys.CREATE_USER));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CUSTOMER_NUMBER,batchCorporateList.getString(tableNameCorporates, i, MapKeys.CUSTOMER_NUMBER));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.IF_DUE_DATE_HOLIDAY,batchCorporateList.getString(tableNameCorporates, i, MapKeys.IF_DUE_DATE_HOLIDAY));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.IS_ONLINE_CORPORATE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.IS_ONLINE_CORPORATE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.MARKETING_EXPERT,batchCorporateList.getString(tableNameCorporates, i, MapKeys.MARKETING_EXPERT));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_OID,batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_OID));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.PROTOCOL_START_DATE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.PROTOCOL_START_DATE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.PROTOCOL_END_DATE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.PROTOCOL_END_DATE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.SECTOR_CODE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.SECTOR_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.SHORT_CODE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.SHORT_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.TRX_NO,batchCorporateList.getString(tableNameCorporates, i, MapKeys.TRX_NO));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.TX_STATUS,batchCorporateList.getString(tableNameCorporates, i, MapKeys.TX_STATUS));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.ALLOW_PART_AFTER_DUE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.ALLOW_PART_AFTER_DUE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.COUNT_AFTER_DUE,batchCorporateList.getString(tableNameCorporates, i, MapKeys.COUNT_AFTER_DUE));

			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.CORPORATE_BATCH_PROCESS_OID, batchCorporateList.getString(tableNameCorporates, i, MapKeys.BATCH_PROCESS_OID) );
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.BANK_CODE, batchCorporateList.getString(tableNameCorporates, i, MapKeys.CORPORATE_BANK_CODE));
			information.getCorporateMap().put(MapKeys.CORPORATE_LIST, i, MapKeys.BATCH_NAME, batchCorporateList.getString(tableNameCorporates, i, MapKeys.BATCH_NAME));
		}
		
		CollectionReconciliationImplementation implementation = new CollectionReconciliationImplementation(information);
		implementation.execute();
		
    }


}
