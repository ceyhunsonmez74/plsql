package tr.com.aktifbank.bnspr.cps.filetransfer.services;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CorporateGeneralBatchSubmit;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StartCorporateBatch;
import tr.com.aktifbank.bnspr.cps.transactions.FTSGetBankCodeHandler;
import tr.com.aktifbank.bnspr.cps.transactions.FTSGetTotalCancelledStandingOrderCountHandler;
import tr.com.aktifbank.bnspr.cps.transactions.FTSGetTotalInvoiceAmountHandler;
import tr.com.aktifbank.bnspr.cps.transactions.FTSGetTotalInvoiceCountHandler;
import tr.com.aktifbank.bnspr.cps.transactions.FTSGetTotalStandingOrderCountHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporateChannelPrm;
import tr.com.aktifbank.bnspr.dao.CorporateParameters;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.FtmFileDefinition;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class FileTransferServices {
	
	private static final String FILE_NAME_SEPERATOR = "~";
	
	@GraymoundService("CPS_FTS_GET_SYSTEM_DATE")
	public static GMMap getSystemDate(GMMap input) {
		GMMap output = new GMMap();
		output.put(MapKeys.FTS_OUTPUT_DATA, new Date());
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_PROCESS_DATE")
	public static GMMap getProcessDate(GMMap input) {
		GMMap output = new GMMap();
		try {
			output.put(MapKeys.FTS_OUTPUT_DATA, input.getDate(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_BANKCODE")
	public static GMMap getBankCode(GMMap input) {
		return RequestProcessor.getInstance().process(input, new FTSGetBankCodeHandler());
	}
	
	@GraymoundService("CPS_FTS_GET_TOTAL_INVOICE_AMOUNT")
	public static GMMap getTotalInvoiceAmount(GMMap input) {
		return RequestProcessor.getInstance().process(input, new FTSGetTotalInvoiceAmountHandler());
	}
	
	@GraymoundService("CPS_FTS_GET_TOTAL_INVOICE_COUNT")
	public static GMMap getTotalInvoiceCount(GMMap input) {
		return RequestProcessor.getInstance().process(input, new FTSGetTotalInvoiceCountHandler());
	}
	
	@GraymoundService("CPS_FTS_GET_CORPORATE_CODE")
	public static GMMap getCorporateCode(GMMap input) {
		GMMap output = new GMMap();
		output.put(MapKeys.FTS_OUTPUT_DATA, input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE));
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_TOTAL_STANDING_ORDER_COUNT")
	public static GMMap getTotalStandingOrderCount(GMMap input){
		return RequestProcessor.getInstance().process(input, new FTSGetTotalStandingOrderCountHandler());
	}
	
	@GraymoundService("CPS_FTS_GET_TOTAL_CANCELLED_STANDING_ORDER_COUNT")
	public static GMMap getTotalCancelledStandingOrderCount(GMMap input){
		return RequestProcessor.getInstance().process(input, new FTSGetTotalCancelledStandingOrderCountHandler());
	}
	
	@GraymoundService("CPS_FTS_CORPORATE_CHANNEL_CONVERSION")
	public static GMMap convertCorporateChannel(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session hibernateSession = CommonHelper.getHibernateSession();
			GMMap paymentInput = input.getMap("CURRENT_ROW");
			String corporateCode = paymentInput.getString("CORPORATE_CODE");
			String sourceCode = paymentInput.getString("PAYMENT_SOURCE");
			String channelCode = paymentInput.getString("PAYMENT_CHANNEL");
			Short collectionType = paymentInput.getBigDecimal("COLLECTION_TYPE").shortValue();
			
			CorporateChannelPrm channelParameter = (CorporateChannelPrm)hibernateSession.createCriteria(CorporateChannelPrm.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.eq("sourceCode", sourceCode))
					.add(Restrictions.eq("channelCode", channelCode))
					.add(Restrictions.or(Restrictions.eq("collectionType", collectionType), Restrictions.isNull("collectionType")))
					.uniqueResult();
			
			if(channelParameter != null){
				output.put(MapKeys.FTS_OUTPUT_DATA, channelParameter.getCorporateConstant());
			}
			else{
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, 
						String.format("Kurumun %s kayna��, %s kanal kodu, %s �deme tipine ait kanal sabiti bulunamad�.", sourceCode, channelCode, collectionType));
			}
			
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_OUTGOING_CORPORATE_PARAMETER_VALUE")
	public static GMMap getOutgoingCorporateParameterValue(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session hibernateSession = CommonHelper.getHibernateSession();
			GMMap paymentInput = input.getMap("CURRENT_ROW");
			String corporateCode = paymentInput.getString("CORPORATE_CODE");
			String fieldName = input.getString("FIELD_NAME");
			String parameter = paymentInput.getString(fieldName, null);
			boolean throwExceptionOnNotFound = input.getBoolean("THROW_EXCEPTION", true);
			
			if(StringUtil.isEmpty(parameter)){
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, 
						"Parameter is null on ".concat(fieldName).concat(" field"));
			}
			
			CorporateParameters corpParameter = (CorporateParameters)hibernateSession.createCriteria(CorporateParameters.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.eq("key", parameter))
					.uniqueResult();
			
			if(corpParameter != null){
				output.put(MapKeys.FTS_OUTPUT_DATA, corpParameter.getValue());
			}
			else{
				if(throwExceptionOnNotFound){
					CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, 
							String.format("Corporate Parameter not found for %s corporate code and %s key", corporateCode, parameter));
				}
				else{
					output.put(MapKeys.FTS_OUTPUT_DATA, parameter);
				}
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_STAN_NO_BY_FIELD_NAME")
	public static GMMap getStanNoByFieldName(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String corporateCode = input.getMap("INPUT_MAP").getString(MapKeys.CORPORATE_CODE);
			String fieldName = input.getString("FIELD_NAME");
			
			output.put(MapKeys.FTS_OUTPUT_DATA, CorporationServiceUtil.getSequenceCode("SNBF".concat(corporateCode).concat(fieldName)));
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_OUTGOING_FILE_NAME")
	public static GMMap getOutgoingFileName(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session hibernateSession = CommonHelper.getHibernateSession();
			GMMap batchInput = input.getMap(CorporateGeneralBatchSubmit.Input.BATCH_INPUT);
			BigDecimal ftmId = batchInput.getBigDecimal(StartCorporateBatch.Input.FTM_ID);
			FtmFileDefinition definition = (FtmFileDefinition) hibernateSession.createCriteria(FtmFileDefinition.class)
					.add(Restrictions.eq("oid", ftmId))
					.uniqueResult();
			
			if(definition != null){
				String mask = definition.getFileNameMask();
				String fileName = new String(mask);
				while(fileName.indexOf(FILE_NAME_SEPERATOR) > -1){
					int startIndex = fileName.indexOf(FILE_NAME_SEPERATOR);
					int endIndex = fileName.indexOf(FILE_NAME_SEPERATOR, startIndex + 1);
					String mapGetterKey = fileName.substring(startIndex + 1, endIndex);
					String value = batchInput.getString(mapGetterKey);
					fileName = fileName.replaceAll(FILE_NAME_SEPERATOR + mapGetterKey + FILE_NAME_SEPERATOR, value);
				}
				
				output.put(MapKeys.FTS_OUTPUT_DATA, fileName);
			}
			else{
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, 
						String.format("Ftm File Definition couldn't be found with following id : %s", ftmId));
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_CORPORATE_PARAMETER_VALUE")
	public static GMMap getCorporateParameterValue(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session hibernateSession = CommonHelper.getHibernateSession();
			GMMap paymentInput = input.getMap("CURRENT_ROW");
			String corporateCode = paymentInput.getString("CORPORATE_CODE");
			String parameter = input.getString("PARAMETER");
			boolean throwExceptionOnNotFound = input.getBoolean("THROW_EXCEPTION", true);
			
			CorporateParameters corpParameter = (CorporateParameters)hibernateSession.createCriteria(CorporateParameters.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.eq("key", parameter))
					.uniqueResult();
			
			if(corpParameter != null){
				output.put(MapKeys.FTS_OUTPUT_DATA, corpParameter.getValue());
			}
			else{
				if(throwExceptionOnNotFound){
					CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, 
							String.format("Corporate Parameter not found for %s corporate code and %s key", corporateCode, parameter));
				}
				else{
					output.put(MapKeys.FTS_OUTPUT_DATA, parameter);
				}
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_SEQUENCE_CODE_FOR_FILE")
	public static GMMap getSequenceCodeForFile(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String corporateCode = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE);
			String informIndicator = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.INFORM_INDICATOR);
			
			String sequenceCode = CorporationServiceUtil.getSequenceCode(String.format("CPS_FTS_SEQ_CODE_%s_%s", corporateCode, informIndicator));
			
			output.put(MapKeys.FTS_OUTPUT_DATA, sequenceCode);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_FILE_LINE_COUNT")
	public static GMMap getFileLineCount(GMMap input){
		GMMap output = new GMMap();
		
		try{
			BigDecimal ftmProcessId = input.getBigDecimal(TransactionConstants.CorporateGeneralBatchSubmit.Input.FTM_PROCESS_ID);
			
			int lineCount = ((Number)CommonHelper.getHibernateSession().createCriteria(FtmFileContent.class)
					.add(Restrictions.eq("ftmProcessOid", ftmProcessId))
					.setProjection(Projections.rowCount())
					.uniqueResult()).intValue();
			
			output.put(MapKeys.FTS_OUTPUT_DATA, lineCount + 1);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_TERM_MONTH")
	public static GMMap getTermMonth(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String processDate = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE);
			
			String termMonth = processDate.substring(4, 6);
			
			if(termMonth.startsWith("0")){
				termMonth = termMonth.substring(1,2);
			}
			
			output.put(MapKeys.FTS_OUTPUT_DATA, termMonth);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CPS_FTS_GET_TERM_YEAR")
	public static GMMap getTermYear(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String processDate = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE);
			
			String termYear = processDate.substring(0, 4);
			
			output.put(MapKeys.FTS_OUTPUT_DATA, termYear);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}
