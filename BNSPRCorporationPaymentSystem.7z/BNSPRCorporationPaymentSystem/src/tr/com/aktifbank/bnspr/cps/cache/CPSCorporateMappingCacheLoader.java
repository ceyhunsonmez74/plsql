package tr.com.aktifbank.bnspr.cps.cache;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.dao.CsCorporateMapping;

import com.graymound.cache.GMCacheLoader;

public final class CPSCorporateMappingCacheLoader implements GMCacheLoader {

	private static final Log logger = LogFactory.getLog(CPSCorporateMappingCacheLoader.class);
	
	public CPSCorporateMappingCacheLoader() {
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> load() {
		Map<String, Object> map = new ConcurrentHashMap<String, Object>();
		
		try {
			List<CsCorporateMapping> corporates = CommonHelper.getHibernateSession()
					.createCriteria(CsCorporateMapping.class)
					.list();
			
			for (CsCorporateMapping csCorporateMapping : corporates) {
				if (!map.containsKey(csCorporateMapping.getCsCorporateOid())) {
					map.put(csCorporateMapping.getCsCorporateOid(), csCorporateMapping);
				}
				if (!map.containsKey(csCorporateMapping.getKftCorporateCode())) {
					map.put(csCorporateMapping.getKftCorporateCode(), csCorporateMapping);
				}
			}
		} catch (Exception e) {
			logger.error("An exception occured while loading CorporateMapping cache");
			logger.error(System.currentTimeMillis(), e);
		}
		
		return map;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object lookup(String arg0) {
		try {
			List<CsCorporateMapping> corporateMappings = CommonHelper.getHibernateSession()
					.createCriteria(CsCorporateMapping.class)
					.add(Restrictions.disjunction()
							.add(Restrictions.eq("csCorporateOid", arg0))
							.add(Restrictions.eq("kftCorporateCode", arg0)))
					.list();
			
			if(corporateMappings != null){
				if(corporateMappings.size() == 1){
					return corporateMappings.get(0);
				}
				else{
					if(corporateMappings.size() > 1){
						logger.error(String.format("More than one record returned for %s argument", arg0));
						return null;
					}
					else{
						logger.warn(String.format("No record returned for %s argument", arg0));
						return null;
					}
				}
			}
			else{
				return null;
			}
		} catch (Exception e) {
			logger.error(String.format("An exception occured while looking up for %s argument", arg0));
			logger.error(System.currentTimeMillis(), e);
			return null;
		}
	}

}
