package tr.com.aktifbank.bnspr.cps.session;


public abstract class AbstractSessionHolder implements ISessionHolder {

	public AbstractSessionHolder() {
		this.shouldRenewSession = true;
	}
	
	protected abstract String getSessionFromSource(Object parameter) throws Exception;
	
	private boolean shouldRenewSession;
	private String session;

	@Override
	public String getSession(Object parameter) throws Exception {
		if(this.shouldRenewSession){
			synchronized(this) {
				if(this.shouldRenewSession){
					this.session = getSessionFromSource(parameter);
					this.shouldRenewSession = false;
				}
			}
		}
		return this.session;
	}

	@Override
	public void renewSession(Object parameter) {
		synchronized(this){
			if(!this.shouldRenewSession){
				this.shouldRenewSession = true;
			}
		}
	}

}
