package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.SubscriberMaskDef;
import tr.com.aktifbank.bnspr.dao.SubscriberMaskDetail;
import tr.com.aktifbank.bnspr.dao.invoiceimage;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class GetSubscriberMetadataHandler extends RequestHandler {

	
	
	public GetSubscriberMetadataHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateOid = input.getString(TransactionConstants.GetSubscriberMetadata.Input.CORPORATE_OID, null);
		String corporateCode = input.getString(TransactionConstants.GetSubscriberMetadata.Input.CORPORATE_CODE, null);
		int collectionType = input.getInt(TransactionConstants.GetSubscriberMetadata.Input.COLLECTION_TYPE, GeneralConstants.COLLECTION_TYPE_NOT_MENTIONED);
		@SuppressWarnings("unused")
		String channelCode = input.getString(TransactionConstants.GetSubscriberMetadata.Input.CHANNEL_CODE, null);
		@SuppressWarnings("unused")
		String languageCode = input.getString(TransactionConstants.GetSubscriberMetadata.Input.LANGUAGE_CODE, null);

		if (StringUtil.isEmpty(corporateOid)) {
			corporateOid = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME,
					TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode).getString(
					TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID);
		}
		
		collectionType = CommonBusinessOperations.manipulateCollectionTypeForChannels((short)collectionType, corporateOid);

		SubscriberMaskDef subscriberMask = (SubscriberMaskDef) super.getHibernateSession().createCriteria(SubscriberMaskDef.class)
				.add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateOid", corporateOid))
				.add(Restrictions.eq("collectionType", (short) collectionType)).uniqueResult();
		if (subscriberMask != null) {

			Criteria c = super.getHibernateSession().createCriteria(SubscriberMaskDetail.class);
			c.add(Restrictions.eq("status", true));
			c.add(Restrictions.eq("maskOid", subscriberMask.getOid()));

			if (!StringUtil.isEmpty(input.getString("CALLER_SCREEN", null))) {
				String callerScreen = input.getString("CALLER_SCREEN");
				if (callerScreen.equals("STO")) {
					c.add(Restrictions.eq("useForStandingOrder", "1"));
				}
				if(callerScreen.equals("ICS")){
					c.add(Restrictions.eq("useForCollection", "1"));
				}
			}

			c.addOrder(Order.asc("viewOrder"));
			List<SubscriberMaskDetail> details = c.list();

			if (details.size() > 0) {
				String usedAllCollection = subscriberMask.getUsedAllCollection();
				if (StringUtil.isEmpty(usedAllCollection)) {
					usedAllCollection = DatabaseConstants.UsedAllCollections.AllMandatory;
				}
				output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_NO_VALIDATION, usedAllCollection);
				boolean isAllFieldsMandatory = true;
				int counter = 0;
				for (SubscriberMaskDetail subscriberMaskDetail : details) {
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.INDEX, counter + 1);
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.LENGTH, subscriberMaskDetail.getMask().length());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.LABEL, subscriberMaskDetail.getLabel());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.MASK, CommonBusinessOperations.getMask(subscriberMaskDetail.getMask()));
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.PATTERN, subscriberMaskDetail.getMask());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.TYPE, "A");
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.SUFFIX, subscriberMaskDetail.getSuffix());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.PREFIX, subscriberMaskDetail.getPrefix());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							TransactionConstants.GetSubscriberMetadata.Output.EXAMPLE, subscriberMaskDetail.getExample());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							"IMAGE_OID", getSubscriberInvoiceImageOid(subscriberMaskDetail.getOid()));
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							"VIEW_ORDER", subscriberMaskDetail.getViewOrder());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							"USE_FOR_INQUIRY", subscriberMaskDetail.getUseForInquiry());
					
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							"USE_FOR_COLLECTION", subscriberMaskDetail.getUseForCollection());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							"PREFIX_USE_COLLECTION", subscriberMaskDetail.getPrefixUseForCollection());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							"SUFFIX_USE_COLLECTION", subscriberMaskDetail.getSuffixUseForCollection());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							"PREFIX_USE_STD_ORDER", subscriberMaskDetail.getPrefixUseForStandingOrder());
					output.put(TransactionConstants.GetSubscriberMetadata.Output.SUBSCRIBER_METADATA_TABLE, counter,
							"SUFFIX_USE_STD_ORDER", subscriberMaskDetail.getSuffixUseForStandingOrder());
					
					if(DatabaseConstants.UserForInquiry.Yes.equals(subscriberMaskDetail.getUseForInquiry())){
						isAllFieldsMandatory = isAllFieldsMandatory & true;
					}
					else{
						isAllFieldsMandatory = isAllFieldsMandatory & false;
					}
					counter++;
				}
				
				output.put(TransactionConstants.GetSubscriberMetadata.Output.IS_ALL_FIELDS_MANDATORY, isAllFieldsMandatory);
			} else {
				throw new BatchComponentException(BusinessException.NOSUBSCRIBERPATTERNDETAILFOUND,
						CommonBusinessOperations.getCorporateNameFromCorporateOid(corporateOid),
						CommonBusinessOperations.getCollectionTypeName((short) collectionType));
			}
		} else {
			throw new BatchComponentException(BusinessException.NOSUBSCRIBERPATTERNFOUND,
					CommonBusinessOperations.getCorporateNameFromCorporateOid(corporateOid),
					CommonBusinessOperations.getCollectionTypeName((short) collectionType));
		}

	}

	private String getSubscriberInvoiceImageOid(String maskDetailOid) {
		invoiceimage  invoiceimg= (invoiceimage) super.getHibernateSession().createCriteria(invoiceimage.class).add(Restrictions.eq("maskOid", maskDetailOid)).add(Restrictions.eq("status", true)).uniqueResult();
		return invoiceimg!=null?invoiceimg.getOid():"";
	}

}
