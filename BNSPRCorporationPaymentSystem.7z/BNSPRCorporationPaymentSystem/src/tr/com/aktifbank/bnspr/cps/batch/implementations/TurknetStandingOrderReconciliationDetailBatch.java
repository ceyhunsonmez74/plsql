package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.turknet.client.TurknetClient;
import tr.com.aktifbank.integration.turknet.dto.reconciliation.detail.StandingOrderReconciliationDetailDto;
import tr.com.aktifbank.integration.turknet.wrapper.StandingOrderReconciliationDetailResponse;

import com.graymound.util.GMMap;

public class TurknetStandingOrderReconciliationDetailBatch extends StandingOrderReconciliationDetailBatch {

	private TurknetClient client;
	
	private List<StandingOrderReconciliationDetailDto> details;
	
	private Map<String,StandingOrderReconciliationDetailDto> indexedCorporateRecords;
	
	public TurknetStandingOrderReconciliationDetailBatch(GMMap input, TurknetClient client) {
		super(input);
		this.client = client;
		indexedCorporateRecords = new HashMap<String, StandingOrderReconciliationDetailDto>();
	}

	@Override
	protected void setCancelStandingOrderExtraParameters(GMMap cancelStandingOrderRequest, int corporateRecordIndex) {
		
	}

	@Override
	protected void setCorporateParametersToReconProcessLogInput(GMMap reconProcessDataLogInput, int corporateRecordIndex) {
		
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(icsStandingOrders bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getSubscriberNo1());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()throws Exception {
	
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		 
		String reconcilationDate = CommonHelper.getDateString(input.getDate(MapKeys.RECON_DATE),"yyyyMMdd");
		
		StandingOrderReconciliationDetailResponse reconciliationDetailsResponse = client.getReconciliationDetails4StandingOrders(reconcilationDate);
		if( null != reconciliationDetailsResponse ){
			List<StandingOrderReconciliationDetailDto> details = reconciliationDetailsResponse.getDetails();
			if( null != details ){
				this.details = details;
				result.setSuccessfulCall(true);
			}
		}
		
		return result;
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordsSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(String.valueOf(super.getBankRecordAtIndex(i).getSubscriberNo1()), super.getBankRecordAtIndex(i));
		}
		
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for( StandingOrderReconciliationDetailDto detail : details ){
			indexedCorporateRecords.put(detail.getSubscriberNo(), detail);
		}
		
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(details.get(corporateRecordIndex).getSubscriberNo());
	}
}
