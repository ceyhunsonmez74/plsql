package tr.com.aktifbank.bnspr.cps.dto;

import java.util.ArrayList;
import java.util.List;

public final class ComplexBatchSubmitInformation extends BaseTransferObject {

	public ComplexBatchSubmitInformation() {
		super();
		this.corporateCodes = new ArrayList<String>();
	}
	
	String serviceName;
	List<String> corporateCodes;
	int parallelLoopCount;
	
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public List<String> getCorporateCodes() {
		return corporateCodes;
	}
	public void setCorporateCodes(List<String> corporateCodes) {
		this.corporateCodes = corporateCodes;
	}
	public void addCorporateCode(String corporateCode){
		this.corporateCodes.add(corporateCode);
	}
	public int getParallelLoopCount() {
		return parallelLoopCount;
	}
	public void setParallelLoopCount(int parallelLoopCount) {
		this.parallelLoopCount = parallelLoopCount;
	}
	
	

}
