package tr.com.aktifbank.bnspr.cps.common;

import java.math.BigDecimal;

import com.graymound.util.GMMap;

public class AccountHelper {
	public static BigDecimal getAvailableBalance(BigDecimal customerNo, String currencyCode, BigDecimal accountNo) throws Exception {
		GMMap customerInfoRequest = new GMMap();
		customerInfoRequest.put("MUSTERI_NO", customerNo);
		customerInfoRequest.put("DOVIZ_KODU", currencyCode);
		customerInfoRequest.put("HESAP_NO", accountNo);
		
		return CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", customerInfoRequest)
				.getBigDecimal("KULLANILABILIR_BAKIYE");
	}
}
