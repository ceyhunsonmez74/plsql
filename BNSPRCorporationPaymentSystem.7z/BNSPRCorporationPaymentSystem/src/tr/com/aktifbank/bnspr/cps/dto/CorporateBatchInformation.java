package tr.com.aktifbank.bnspr.cps.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.graymound.util.GMMap;

public final class CorporateBatchInformation extends BaseTransferObject {

	public CorporateBatchInformation() {
		super();
	}

	private String corporateCode;
	private String serviceName;
	private List<FormatDetail> headerDetails;
	private List<FormatDetail> bodyDetails;
	private List<FormatDetail> footerDetails;
	private Date invoiceDate;
	private BigDecimal ftmProcessId;
	private List<ItemDatabaseField> databaseFields;
	private List<ItemServiceField> serviceFields;
	private GMMap batchParameters;
	private short informIndicator;
	private GMMap batchInput;
	private int totalCount;
	private BigDecimal totalAmount;
	
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	public GMMap getBatchInput() {
		return batchInput;
	}
	public void setBatchInput(GMMap batchInput) {
		this.batchInput = batchInput;
	}
	public short getInformIndicator() {
		return informIndicator;
	}
	public void setInformIndicator(short informIndicator) {
		this.informIndicator = informIndicator;
	}
	public GMMap getBatchParameters() {
		return batchParameters;
	}
	public void setBatchParameters(GMMap batchParameters) {
		this.batchParameters = batchParameters;
	}
	public List<ItemDatabaseField> getDatabaseFields() {
		return databaseFields;
	}
	public void setDatabaseFields(List<ItemDatabaseField> databaseFields) {
		this.databaseFields = databaseFields;
	}
	public List<ItemServiceField> getServiceFields() {
		return serviceFields;
	}
	public void setServiceFields(List<ItemServiceField> serviceFields) {
		this.serviceFields = serviceFields;
	}
	public BigDecimal getFtmProcessId() {
		return ftmProcessId;
	}
	public void setFtmProcessId(BigDecimal ftmProcessId) {
		this.ftmProcessId = ftmProcessId;
	}
	public Date getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getCorporateCode() {
		return corporateCode;
	}
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public List<FormatDetail> getHeaderDetails() {
		return headerDetails;
	}
	public void setHeaderDetails(List<FormatDetail> headerDetails) {
		this.headerDetails = headerDetails;
	}
	public List<FormatDetail> getBodyDetails() {
		return bodyDetails;
	}
	public void setBodyDetails(List<FormatDetail> bodyDetails) {
		this.bodyDetails = bodyDetails;
	}
	public List<FormatDetail> getFooterDetails() {
		return footerDetails;
	}
	public void setFooterDetails(List<FormatDetail> footerDetails) {
		this.footerDetails = footerDetails;
	}
	
	
	
}
