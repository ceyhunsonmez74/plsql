package tr.com.aktifbank.bnspr.cps.transactions;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.GsmMoneyLoadLog;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class InsertMoneyLoadLogHandler extends RequestHandler {
	
	private static final Map<String, Method> moneyLoadLogMethods;
	private static final Map<String, Method> gmMapMethods;
	
	static{
		moneyLoadLogMethods = new ConcurrentHashMap<String, Method>();
		gmMapMethods = new ConcurrentHashMap<String, Method>();
		for (Method method : Arrays.asList(GsmMoneyLoadLog.class.getMethods())) {
			moneyLoadLogMethods.put(method.getName(), method);
		}
		for (Method method : Arrays.asList(GMMap.class.getMethods())) {
			if(method.getParameterTypes().length == 1){
				gmMapMethods.put(method.getName(), method);
			}
		}
	}

	public InsertMoneyLoadLogHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		GsmMoneyLoadLog log = new GsmMoneyLoadLog();
		
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.TRX_NO, log, "TxNo");
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.INVOICE_MAIN_OID, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.COLLECTION_TYPE, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_AMOUNT, log);
		if(!"0".equals(input.getString(TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_ACCOUNT_NO))){
			this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_ACCOUNT_NO, log);
		}
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.IBAN_NO, log, "Iban");
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.ACCOUNT_BALANCE, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PAYMENT_CARD_NO, log);
		this.controlAndSet(input, MapKeys.ACCOUNT_NO, log, "CorporateAccountNo");
		
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.SOURCE, log, "SourceCode");
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.SOURCE, log, "PaymentSource");
		this.controlAndSet(input, MapKeys.COMMISION_AMOUNT, log);
		this.controlAndSet(input, MapKeys.BSMV_AMOUNT, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.BRANCH_CODE, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.CUSTOMER_NO, log, "PayerCustomer");
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.CUSTOMER_PHONE, log, "PayerPhone");
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.CUSTOMER_ID_NO, log, "PayerPidno");
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.CUSTOMER_TAX_NO, log, "PayerTaxNo");
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.ACCOUNT_CURRENCY_CODE, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.COLLECTION_TYPE_NAME, log, "CollectionTypeText");
		
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.SUBSCRIBER_NO1, log, "SubscriberNo");
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.STANDING_ORDER_OID, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER1, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER2, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER3, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER4, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER5, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER6, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER7, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER8, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER9, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PARAMETER10, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.CORPORATE_CODE, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.CORPORATE_ACCOUNT_NO, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.SUBSCRIBER_NAME, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.QUERY_REF_NO, log);
		this.controlAndSet(input, TransactionConstants.DoGSMMoneyLoad.Input.PACKAGE_ID, log);
		
		
		log.setStatus(true);

		log.setTransactionStatus(DatabaseConstants.TransactionStatuses.New);
		
		String channelId = null;
		
		if(input.containsKey(TransactionConstants.DoGSMMoneyLoad.Input.CHANNEL_CODE)){
			channelId = input.getString(TransactionConstants.DoGSMMoneyLoad.Input.CHANNEL_CODE);
		}
		else{
			channelId = CommonHelper.getChannelId();
		}
		
		if(!StringUtil.isEmpty(input.getString("AGENT_CODE", null))){
			log.setAgentCode(input.getString("AGENT_CODE"));
		}
		
		log.setChannelCode(channelId);
		log.setUserCode(CommonHelper.getCurrentUser());
		log.setPaymentDate(CommonHelper.getDateString(new Date(), "yyyyMMddhhmmss"));
		
		super.getHibernateSession().save(log);
		super.getHibernateSession().flush();

	}
	
	private void controlAndSet(GMMap input, String key, Object pojo){
		this.controlAndSet(input, key, pojo, null);
	}
	
	private void controlAndSet(GMMap input, String key, Object pojo, String pojoProperty){
		try {
			if(input.containsKey(key)){
				String setMethodName = "";
				if(!StringUtil.isEmpty(pojoProperty)){
					setMethodName = String.format("set%s", pojoProperty);
				}
				else{
					setMethodName = "set";
					String[] splittedString = key.split("_");
					for (int i = 0; i < splittedString.length; i++) {
						String currentString = splittedString[i].toLowerCase(Locale.ROOT);
						setMethodName += String.valueOf(currentString.charAt(0)).toUpperCase(Locale.ROOT).concat(currentString.substring(1));
					}
				}
				Method currentMethod = moneyLoadLogMethods.get(setMethodName);
				if(currentMethod != null){
					Class<?> parameterType = currentMethod.getParameterTypes()[0];
					if(parameterType != null){
						Object value = getValueFromGMMap(input, key, parameterType);
						if(value != null){
							currentMethod.invoke(pojo, value);
						}
					}
				}
			}
		}
		catch (Exception e) {
			logger.error(String.format("An exception occured while setting %s property of pojo", pojoProperty));
			logger.error(System.currentTimeMillis(), e);
		}
	}

	private Object getValueFromGMMap(GMMap input, String key,
			Class<?> parameterType) throws Exception {
		String simpleName = parameterType.getSimpleName();
		String methodModifiedName = String.valueOf(simpleName.charAt(0)).toUpperCase(Locale.ROOT).concat(simpleName.substring(1));
		boolean shortValue = false;
		if(methodModifiedName.equals("Integer")){
			methodModifiedName = "Int";
		}
		else if(methodModifiedName.equals("Short")){
			shortValue = true;
			methodModifiedName = "Int";
		}
		Method currentMethod = gmMapMethods.get(String.format("get%s", methodModifiedName));
		if (currentMethod != null) {
			Object value = currentMethod.invoke(input, key);
			if(shortValue){
				return Short.valueOf(value.toString());
			}
			else{
				return value;
			}
		}
		else{
			return null;
		}
	}

}
