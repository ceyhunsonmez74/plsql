package tr.com.aktifbank.bnspr.cps.dto;

import java.io.Serializable;

public class ItemDatabaseField extends BaseTransferObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5284143899267279153L;

	public ItemDatabaseField() {
		// TODO Auto-generated constructor stub
	}
	
	private String oid;
	private boolean status;
	private String dbField;
	private String userLabel;
	private String explanation;
	private String createUser;
	private String createDate;
	private String updateUser;
	private String updateDate;

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public boolean isStatus() {
		return this.status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getDbField() {
		return this.dbField;
	}

	public void setDbField(String dbField) {
		this.dbField = dbField;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public String getExplanation() {
		return this.explanation;
	}

	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}

	public String getCreateUser() {
		return this.createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateUser() {
		return this.updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
}
