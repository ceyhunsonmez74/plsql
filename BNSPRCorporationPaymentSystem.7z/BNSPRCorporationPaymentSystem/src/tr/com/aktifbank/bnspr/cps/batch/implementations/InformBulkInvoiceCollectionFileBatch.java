package tr.com.aktifbank.bnspr.cps.batch.implementations;

import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileBatchInformation;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

public class InformBulkInvoiceCollectionFileBatch extends InformInvoiceCollectionFileBatch {

	public InformBulkInvoiceCollectionFileBatch(OutgoingFileBatchInformation info) {
		super(info);
	}
	
	@Override
	protected Object getRecords() throws Throwable {
		StringBuilder query = new StringBuilder();
		query.append("SELECT * ");
		query.append("FROM ics.invoice_payment ip ");
		query.append(String.format("WHERE ip.status=1 AND ip.corporate_code = '%s' AND ip.payment_status = '%s'", 
				super.getInformation().getCorporateCode(), 
				DatabaseConstants.PaymentStatuses.Collected));
		if(super.getInformation().isInformOnlyStandingOrderPayments()){
			query.append(" AND ip.STANDING_ORDER_OID is not null");
		}
		if(!StringUtil.isEmpty(super.getInformation().getFieldLimitationPattern())){
			query.append(" ");
			query.append(super.getInformation().getFieldLimitationPattern());
		}
		query.append(" ORDER BY ip.oid");
		
		return DALUtil.getResults(query.toString(), tableName);
	}

}
