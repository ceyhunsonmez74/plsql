package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.ObjectMapper;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.dao.FileFormatDbField;

import com.graymound.util.GMMap;

public final class GetDatabaseFieldsHandler extends RequestHandler {

	public GetDatabaseFieldsHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Criteria criteria = super.getHibernateSession().createCriteria(FileFormatDbField.class);
		if(!input.getBoolean(TransactionConstants.GetDatabaseFields.Input.GET_ALL_FIELDS, false)){
			criteria = criteria.add(Restrictions.eq("status", true));
		}
		@SuppressWarnings("unchecked")
		List<FileFormatDbField> dbFieldList = criteria.list();
		List<ItemDatabaseField> fields = new ArrayList<ItemDatabaseField>();
		for(FileFormatDbField field : dbFieldList){
			ObjectMapper<ItemDatabaseField> mapper = new ObjectMapper<ItemDatabaseField>(ItemDatabaseField.class);
			ItemDatabaseField dtoField = mapper.map(field);
			fields.add(dtoField);
		}
		output.put(TransactionConstants.GetDatabaseFields.Output.FIELDS, fields);
	}

}
