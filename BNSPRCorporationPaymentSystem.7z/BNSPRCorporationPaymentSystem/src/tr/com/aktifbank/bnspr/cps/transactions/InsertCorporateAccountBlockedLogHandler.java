package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.InsertCorporateAccountBlockedLog;
import tr.com.aktifbank.bnspr.dao.CorporateAccountBlockedLog;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class InsertCorporateAccountBlockedLogHandler extends
		RequestHandler {

	public InsertCorporateAccountBlockedLogHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		boolean isUpdate = input.getBoolean(InsertCorporateAccountBlockedLog.Input.IS_UPDATE, false);
		String blockReference = input.getString(InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE);
		String blockedStatus = input.getString(InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS);
		String blockedUser = input.getString(InsertCorporateAccountBlockedLog.Input.BLOCKED_USER, null);
		String blockedDate = input.getString(InsertCorporateAccountBlockedLog.Input.BLOCKED_DATE, null);
		String unblockedUser = input.getString(InsertCorporateAccountBlockedLog.Input.UNBLOCKED_USER, null);
		String unblockedDate = input.getString(InsertCorporateAccountBlockedLog.Input.UNBLOCKED_DATE, null);
		if(isUpdate){
			CorporateAccountBlockedLog log = (CorporateAccountBlockedLog)super.getHibernateSession().createCriteria(CorporateAccountBlockedLog.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("blokeReferans", blockReference))
					.uniqueResult();
			if(log != null){
				String errorCode = input.getString(InsertCorporateAccountBlockedLog.Input.ERROR_CODE, null);
				String errorMessage = input.getString(InsertCorporateAccountBlockedLog.Input.ERROR_MESSAGE, null);
				boolean setInactive = input.getBoolean(InsertCorporateAccountBlockedLog.Input.SET_INACTIVE, false);
				
				if (!StringUtil.isEmpty(blockedStatus)) {
					log.setBlockedStatus(blockedStatus);
				}
				if (!StringUtil.isEmpty(blockedUser)) {
					log.setBlockedUser(blockedUser);
				}
				if (!StringUtil.isEmpty(blockedDate)) {
					log.setBlockedDate(blockedDate);
				}
				if (!StringUtil.isEmpty(unblockedUser)) {
					log.setUnblockedUser(unblockedUser);
				}
				if (!StringUtil.isEmpty(unblockedDate)) {
					log.setUnbloeckedDate(unblockedDate);
				}
				if (!StringUtil.isEmpty(errorCode)) {
					log.setErrorCode(errorCode);
				}
				if (!StringUtil.isEmpty(errorMessage)) {
					log.setErrorDesc(errorMessage);
				}
				if(setInactive){
					log.setStatus(false);
				}
				super.getHibernateSession().saveOrUpdate(log);
				super.getHibernateSession().flush();
				
			}
			else{
				throw new Exception(String.format("Corporate Account Blocked Log cannot be found with %s block reference id", blockReference));
			}
		}
		else{
			String corporateCode = input.getString(InsertCorporateAccountBlockedLog.Input.CORPORATE_CODE);
			BigDecimal accountNumber = input.getBigDecimal(InsertCorporateAccountBlockedLog.Input.ACCOUNT_NUMBER);
			
			CorporateAccountBlockedLog log = new CorporateAccountBlockedLog();
			log.setStatus(true);
			log.setBlockedStatus(blockedStatus);
			log.setCorporateCode(corporateCode);
			log.setAccountNumber(accountNumber);
			log.setBlokeReferans(blockReference);
			log.setBlockedUser(blockedUser);
			log.setBlockedDate(blockedDate);
			log.setUnblockedUser(unblockedUser);
			log.setUnbloeckedDate(unblockedDate);
			
			super.getHibernateSession().save(log);
			super.getHibernateSession().flush();
			
		}
	}

}
