package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.corporation.services.EskomNewServices;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.eskomNew.EskomNewClient;
import tr.com.aktifbank.integration.eskomNew.ServiceMessage;
import tr.com.eskom.ws.tahsilatservice.BeyanTurType;
import tr.com.eskom.ws.tahsilatservice.MakbuzType;
import tr.com.eskom.ws.tahsilatservice.MutabakatDetayResponseType;


import com.graymound.util.GMMap;

public class EskomNewReconciliationDetailBatch extends CollectionReconciliationDetailBatch {


	private static final Log logger = LogFactory.getLog(BedasCampaignReconciliationDetailBatch.class);
	Session session;
	List<MakbuzType>  details;
	ServiceMessage message;
	Map<String, MakbuzType> indexedCorporateRecords;

	public EskomNewReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, MakbuzType>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER5, details.get(corporateRecordIndex).getReferansNo());
		cancelCollectionRequest.put(MapKeys.PARAMETER11, details.get(corporateRecordIndex).getTahsilatId());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {

		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String reconDateString = CommonHelper.getDateString(CommonHelper.getDateTime(input.getString(MapKeys.RECON_DATE), "yyyyMMdd"), "yyyy-MM-dd");
			XMLGregorianCalendar tarih = EskomNewServices.stringToXMLGregorianCalendar(reconDateString, "yyyy-MM-dd");

//			details= EskomJaxWSClient.mutabakatDetay(input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5), input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), input.getString(MapKeys.RECON_DATE), this.message);
			MutabakatDetayResponseType mutabakatDetayResponse= EskomNewClient.mutabakatDetay(input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5), input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER6), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_USER), input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD), this.message, input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1), BeyanTurType.HEPSI, "" , tarih);
			details = mutabakatDetayResponse.getMakbuzlar();
					
			if (!"0000".equals(mutabakatDetayResponse.getKod())) {
				result.setSuccessfulCall(false);
				result.setReturnCode("0");
				return result;
			}
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling eskom recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	private Date formatDate(String str) {
		Date returnDate = new Date();
		try {
			returnDate = CommonHelper.getDateTime(str, "yyyyMMdd");
			;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return returnDate;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.TRX_NO), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		int counter=0;
		for (int i = 0; i < details.size(); i++) {
			if (!details.get(i).isIptal()) {
				this.indexedCorporateRecords.put(this.details.get(i).getReferansNo(), this.details.get(i));
				counter++;
			}
		}
		input.put("RECON_CORPORATE_COUNT", counter);
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getReferansNo());
	}

	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex) throws Exception {
		MakbuzType corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. ��letme Kodu : %s, Abone Numaras� : %s, ThsIs : %s, ThsNo : %s, Miktar : %s "));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setParameter20("MANUEL_IPTAL_MUTABAKAT");
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		session.saveOrUpdate(payment);
		session.flush();
	}


}
