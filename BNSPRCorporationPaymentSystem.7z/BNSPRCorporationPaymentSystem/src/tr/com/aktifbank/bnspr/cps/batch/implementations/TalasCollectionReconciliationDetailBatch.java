package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.Map;

import org.seras.webservice.server.WsMakbuz;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.integration.talasbel.client.TalasbelSOAPClient;

import com.graymound.util.GMMap;

public final class TalasCollectionReconciliationDetailBatch extends
		CollectionReconciliationDetailBatch {
	
	static final String TALAS_SUCCESSFUL_CODE = "100";
	
	TalasbelSOAPClient client;
	WsMakbuz[] reconDetail;
	Map<String, WsMakbuz> indexedCorporateRecords;

	public TalasCollectionReconciliationDetailBatch(GMMap input, TalasbelSOAPClient client) {
		super(input);
		this.client = client;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.TRX_NO, CommonHelper.trimStart(this.reconDetail[corporateRecordIndex].getDekontNo(), '0'));
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		WsMakbuz record = this.reconDetail[corporateRecordIndex];
		cancelCollectionRequest.put("PARAMETER_2", record.getMakbuzNo());
		cancelCollectionRequest.put("PARAMETER_3", record.getDekontNo());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.TRX_NO));
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail()
			throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		
		this.reconDetail = client.getReconciliationDetail("", "", super.input.getString(MapKeys.RECON_DATE));
		
		if(reconDetail.length == 1){
			WsMakbuz recon = reconDetail[0];
			if(!TALAS_SUCCESSFUL_CODE.equals(recon.getAciklama())){
				result.setSuccessfulCall(false);
				result.setReturnCode(recon.getAciklama());
				return result;
			}
			else{
				result.setSuccessfulCall(true);
				return result;
			}
		}
		else{
			result.setSuccessfulCall(true);
			return result;
		}
	}

	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			GMMap bankRecord = super.getBankRecordAtIndex(i);
			super.setBankRecordIndex(bankRecord.getString(MapKeys.TRX_NO), bankRecord);
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < reconDetail.length; i++) {
			WsMakbuz currentRecord = reconDetail[i];
			this.indexedCorporateRecords.put(CommonHelper.trimStart(currentRecord.getDekontNo(), '0'), currentRecord);
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(CommonHelper.trimStart(this.reconDetail[corporateRecordIndex].getDekontNo(), '0'));
	}

}
