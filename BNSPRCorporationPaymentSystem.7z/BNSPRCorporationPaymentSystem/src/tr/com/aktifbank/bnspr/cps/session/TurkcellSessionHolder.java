package tr.com.aktifbank.bnspr.cps.session;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import logonoff.model.collgw.turkcelltech.com.WebserviceLogonResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.integration.turkcellPCG.ServiceMessage;
import tr.com.aktifbank.integration.turkcellPCG.TurkcellPCGClient;

import com.graymound.util.GMMap;


public final class TurkcellSessionHolder extends AbstractSessionHolder {
	
	private static final Log logger = LogFactory.getLog(TurkcellSessionHolder.class);
	
	private static final String RESPONSE_CODE_APPROVE = "00";

	public TurkcellSessionHolder() {
		super();
	}

	@Override
	protected String getSessionFromSource(Object parameter) throws Exception {
		GMMap input = (GMMap)parameter;
		logger.error("logonMessage service started");
		String wsUrl = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
		String password =input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_PASSWORD); 
		int bankId = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
		String responseCode = "";
		String sessionID = "";
		String msgDate = getMsgDate();
		ServiceMessage serviceMessage = new ServiceMessage();
		int timeOut = input.getInt(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER5);

		Long stan = Long.parseLong(getStanNo());
		logger.error("webServiceLogOn service started");
		WebserviceLogonResponse logonResponse = TurkcellPCGClient.webServiceLogOn(wsUrl, bankId, msgDate, password, stan, serviceMessage, timeOut);
		logger.error("logonMessage service request: "+serviceMessage.getRequest() + " response: " + serviceMessage.getResponse() );
		logger.error("webServiceLogOn service finished");
		input.put("REQUEST_XML", serviceMessage.getRequest());
		input.put("RESPONSE_XML", serviceMessage.getResponse());
		responseCode = logonResponse.getRespCode();
		logger.error(responseCode + " returned by Corporate for logonMessage.");
		if(RESPONSE_CODE_APPROVE.equals(responseCode)){
			sessionID = logonResponse.getSessionId();
		}
		input.put(MapKeys.RESPONSE_CODE, responseCode);
		input.put(MapKeys.ERROR_CODE, responseCode);
		input.put(MapKeys.ERROR_DESC, responseCode);
		input.put("SESSION_ID", sessionID);
		logger.error("logonMessage service finished");
		
		return sessionID;
	}
	
	public static String getMsgDate() {

		final DateFormat msgDateTimeFormat = new SimpleDateFormat("MMddHHmmss");

		return msgDateTimeFormat.format(new Date());
	}
	
	public static String getStanNo() throws Exception{
		String tableName="ICS_TURKCELL_STAN";
		return CorporationServiceUtil.getSequenceCode(tableName);	
	}

}
