package tr.com.aktifbank.bnspr.cps.transactions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.dao.WebServices;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.integration.bedas.campaign.BedasCampaignClient;
import tr.com.aktifbank.integration.bedas.campaign.ServiceMessage;
import campaign.entity.GetAboneIsletmeDegisiklikListeResult;

import com.graymound.util.GMMap;

public class BedasCheckSubscriberNumberChange extends RequestHandler {

	public BedasCheckSubscriberNumberChange() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		WebServices webServiceInfo = (WebServices) super.getHibernateSession().createCriteria(WebServices.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("serviceName", "ICS_BEDAS_CHECK_SUBSCRIBER_NUMBER_CHANGE")).uniqueResult();
		String sBaslangicTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
		String sBitisTarihi = CommonHelper.getDateString(new Date(), "yyyy-MM-dd");
		if (input.containsKey("START_DATE")) {
			sBaslangicTarihi = input.getString("START_DATE");
		}
		if (input.containsKey("END_DATE")) {
			sBitisTarihi = input.getString("END_DATE");
		}
		String corporateCode = webServiceInfo.getCorporateCode();
		String p_sLoginName = webServiceInfo.getParameter1();
		String p_sPassword = webServiceInfo.getParameter2();
		String p_sBankaKodu = webServiceInfo.getParameter3();
		int timeOut = Integer.valueOf(webServiceInfo.getParameter5());
		String username = webServiceInfo.getWsUser();
		String password = webServiceInfo.getWsPassword();
		String url = webServiceInfo.getWsEndPoint();
		ServiceMessage serviceMessage = new ServiceMessage();
		ArrayList<GetAboneIsletmeDegisiklikListeResult> result = BedasCampaignClient.getAboneIsletmeDegisiklikIste(sBaslangicTarihi, sBitisTarihi, p_sBankaKodu, p_sLoginName, p_sPassword, username, password, url, serviceMessage, timeOut);
		input.put("REQUEST_XML", serviceMessage.getRequest());
		output.put("RESPONSE_XML", serviceMessage.getResponse());

		List<icsStandingOrders> standingOrderListForFormatCheck = super.getHibernateSession().createCriteria(icsStandingOrders.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("standingOrderStatus", "1")).add(Restrictions.like("subscriberNo1", ".0",MatchMode.ANYWHERE)).list();
		for (icsStandingOrders standingOrder : standingOrderListForFormatCheck) {
			String subNo1=standingOrder.getSubscriberNo1().replace(".00", ".0");
			subNo1=subNo1.replace(".01", ".1");
			subNo1=subNo1.replace(".02", ".2");
			subNo1=subNo1.replace(".03", ".3");
			subNo1=subNo1.replace(".04", ".4");
			subNo1=subNo1.replace(".05", ".5");
			subNo1=subNo1.replace(".06", ".6");
			subNo1=subNo1.replace(".07", ".7");
			subNo1=subNo1.replace(".08", ".8");
			subNo1=subNo1.replace(".09", ".9");
			icsStandingOrders standingOrderForUpdate = standingOrder;
			standingOrder.setSubscriberNo1(subNo1);
			super.getHibernateSession().update(standingOrderForUpdate);
		}
		
		List<icsStandingOrders> standingOrderList = super.getHibernateSession().createCriteria(icsStandingOrders.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("standingOrderStatus", "1")).list();
		
		for (int i = 0; i < result.size(); i++) {
			for (icsStandingOrders standingOrder : standingOrderList) {
				if (result.get(i).getEskiIsletme().equals(standingOrder.getSubscriberNo1()) && result.get(i).getEskiAboneNo().equals(standingOrder.getSubscriberNo2())) {
					icsStandingOrders standingOrderForUpdate = standingOrder;
					standingOrder.setSubscriberNo1(result.get(i).getYeniIsletme());
					standingOrder.setSubscriberNo2(result.get(i).getYeninAboneNo());
					super.getHibernateSession().update(standingOrderForUpdate);
				}
			}
		}
	}
}
