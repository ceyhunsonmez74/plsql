package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.EmailConstants;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.dto.TransferLogInformation;
import tr.com.aktifbank.bnspr.dao.BalanceTransferEftEmailDef;
import tr.com.aktifbank.bnspr.dao.CorporateAccountBlockedLog;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.aktifbank.bnspr.dao.CsAccountingTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class TransferCorporateBalanceHandler extends RequestHandler {
	
	private static final String SUCCESSFUL = "2";

	public TransferCorporateBalanceHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
		BigDecimal fromAccountNo = input.getBigDecimal("FROM_ACCOUNT_NO");
		String description = input.getString("DESCRIPTION");
		String branchCode = input.getString(MapKeys.BRANCH_CODE);
		String branchName = input.getString("BRANCH_NAME");
		BigDecimal amount = input.getBigDecimal(MapKeys.AMOUNT);
		String corporateOid = input.getString(MapKeys.CORPORATE_OID);
		String isEftTransfer = input.getString("IS_EFT_TRANSFER");
		BigDecimal transactionNo = input.getBigDecimal(MapKeys.TRX_NO);
		String toIban = input.getString("TO_IBAN", null);
		String ibanOwner = input.getString("TO_IBAN_OWNER", null);
		BigDecimal toAccountNo = input.getBigDecimal("TO_ACCOUNT_NO", null);
		String transferType = input.getString("TRANSFER_TYPE", null);
		String collectionDate = input.getString("COLLECTION_DATE", null);
				
		
		CorporateAccountBlockedLog logRecord = (CorporateAccountBlockedLog)super.getHibernateSession().createCriteria(CorporateAccountBlockedLog.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.add(Restrictions.eq("accountNumber", fromAccountNo))
				.add(Restrictions.disjunction()
						.add(Restrictions.eq("blockedStatus", DatabaseConstants.CorporateAccountBlockStatuses.Blocked))
						.add(Restrictions.eq("blockedStatus", DatabaseConstants.CorporateAccountBlockStatuses.UnblockFailed)))
				.uniqueResult();
		
		if(logRecord == null){
			CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, String.format("%s kurumu i�in hesap bloke kay�d� bulunamam��t�r.", corporateCode));
		}
		
		super.callServiceWithSessionOption(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, false,
				TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, logRecord.getBlokeReferans(),
				TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS, DatabaseConstants.CorporateAccountBlockStatuses.Unblocking,
				TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true);
		
		try {
			DALUtil.callOracleProcedure("{call PKG_CS.CS_ACC_UNBLOCK_MONEY(?,?)}", new Object[] { BnsprType.STRING, fromAccountNo.toString(), 
					BnsprType.NUMBER, new BigDecimal(logRecord.getBlokeReferans()) }, new Object[0]);
			super.callServiceWithSessionOption(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, false,
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, logRecord.getBlokeReferans(),
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS, DatabaseConstants.CorporateAccountBlockStatuses.Unblocked,
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true,
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.UNBLOCKED_USER, CommonHelper.getCurrentUser(),
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.UNBLOCKED_DATE, CommonHelper.getLongDateTimeString(new Date()),
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.SET_INACTIVE, true);
		} catch (Exception e) {
			logger.error(String.format("An exception occured while unblocking account with number %s", fromAccountNo));
			logger.error(System.currentTimeMillis(), e);
			super.callServiceWithSessionOption(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, false,
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, logRecord.getBlokeReferans(),
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS, DatabaseConstants.CorporateAccountBlockStatuses.UnblockFailed,
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true,
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.ERROR_CODE, "0",
					TransactionConstants.InsertCorporateAccountBlockedLog.Input.ERROR_MESSAGE, e.toString());
			
			throw e;
		}
		try {
			
			output.put("ACTUAL_AMOUNT", amount.toPlainString());
			
			TransferLogInformation information = new TransferLogInformation();
			
			amount = modifyAmount(corporateOid, fromAccountNo, amount, information);
			
			output.put("TRANSFERRED_AMOUNT", amount.toPlainString());
			output.put("AVAILABLE_BALANCE", information.getAvailableBalance());
			output.put("CONSTANT_AMOUNT", information.getConstantAmount());
			
			if(isEftTransfer.equals(DatabaseConstants.IsEftTransfers.EFTTransfer)){
				if(StringUtil.isEmpty(description)){
					if("GVT".equals(transferType)){
						description= "#";
						String eftRealDate="";
						Date realDate = CommonHelper.getDateTime(collectionDate,"yyyyMMdd");
						if (!CommonHelper.isWorkingDay(realDate)) {		
							realDate = CommonHelper.getNextWorkingDay(realDate);
	                    	eftRealDate = CommonHelper.getShortDateTimeString(realDate);
	                    }else{
	                    	eftRealDate=collectionDate;
	                    }
						description=description+collectionDate+"-N-";
					}else{
						description = "";
					}
					
				}
				
				GMMap eftTransferRequest = new GMMap();
				eftTransferRequest.put("REFERENCE_ID", transactionNo);
				eftTransferRequest.put("AMOUNT", amount);
				eftTransferRequest.put("RCVR_IBAN", toIban.trim());
				eftTransferRequest.put("RCVR_FULL_NAME", ibanOwner);
				eftTransferRequest.put("SNDR_ACC_CODE", fromAccountNo);
				eftTransferRequest.put("RCVR_EXPLANATION", description);
				GMMap eftResponse = super.callGraymoundServiceInSession("CS_EFT_DO", eftTransferRequest);
				if(eftResponse.getString("RESULT").equals(SUCCESSFUL)){
					// No problem
					BalanceTransferEftEmailDef emailDef = (BalanceTransferEftEmailDef)super.getHibernateSession().createCriteria(BalanceTransferEftEmailDef.class)
														.add(Restrictions.eq("status", true))
														.add(Restrictions.eq("corporateCode", corporateCode))
														.uniqueResult();
					if(emailDef != null && emailDef.isEmailEftTransfer()) {
						GMMap getCorporateDefResponse = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
								TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
						try {							
							CommonHelper.sendMail(
									Arrays.asList(emailDef.getEftEmailList().split("[,]")), null, CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "EFT_TRANSFER_EMAIL_FROM"), true, 
									String.format("%s Tarihli %s Nolu hesab�n�zdan yap�lan EFT tutar aktar�m�n� bilgilerinize sunar�z", CommonHelper.shortTimeStringToViewDateString(CommonHelper.getShortDateTimeString(new Date())), fromAccountNo), 
									String.format("<html><head></head><body><br/><br/>" + 
									"<b>M��TER� NO :</b> %s<br/>" + 
									"<b>M��TER� �NVANI :</b> %s<br/>" +
									"<b>HESAP NO :</b> %s<br/>" + 
									"<b>HESAP ADI :</b> %s<br/>" + 
									"<b>HESAP D�V�Z KODU :</b> %s<br/>" + 
									"<b>EFT BAK�YES� :</b> %s<br/>" + 
									"</body></html>", getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CUSTOMER_NUMBER), 
													  getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE),
													  fromAccountNo, CommonHelper.getNameOfAccount(fromAccountNo), CommonHelper.getCurrencyOfAccount(fromAccountNo), 
													  amount)
									);
						} catch (Exception e) {
							logger.error("Mail g�nderilirken hata meydana geldi...");
							logger.error(e.toString());
						}
					}
				}
				else{
					CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, eftResponse.getString("ERROR_DESC"));
				}
			}
			else{
				if(StringUtil.isEmpty(description)){
					description = getDescription(branchCode, branchName);
				}
				
				CsAccountingTx acc = new CsAccountingTx();
				acc.setProcessId(new BigDecimal("7020"));
				acc.setReferenceId(transactionNo);
				acc.setValorDate(new Date());
				acc.setUserCode(CommonHelper.getCurrentUser());
				acc.setOrgCode("444");
				acc.setSourceAccCode(fromAccountNo);
				acc.setTargetAccCode(toAccountNo);
				acc.setAmount(amount);
				acc.setAmountMt("TRY");
				acc.setChannelCode(CommonHelper.getChannelId());
				acc.setVoucherDesc("");
				acc.setPaymentSource("2");
				acc.setVoucherDesc(description);
				
				super.getHibernateSession().save(acc);
				super.getHibernateSession().flush();
				
				GMMap txInput = new GMMap();
				
				txInput.put(MapKeys.TRX_NAME, "7020");
				txInput.put(MapKeys.TRX_NO, transactionNo);
				
				GMMap transactionMap = super.callGraymoundServiceInSession("BNSPR_TRX_SEND_TRANSACTION", txInput);
				
				logger.info(transactionMap.getString("MESSAGE", ""));
			}
		} finally{
			try{
				
				super.callServiceWithSessionOption(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, false,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, transactionNo,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS, DatabaseConstants.CorporateAccountBlockStatuses.Blocking,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.ACCOUNT_NUMBER, fromAccountNo,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.CORPORATE_CODE, corporateCode,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, false);
				DALUtil.callOracleProcedure("{call PKG_CS.CS_ACC_BLOCK_MONEY(?,?,?,?,?)}", new Object[] { BnsprType.STRING, fromAccountNo.toString(),  
						BnsprType.NUMBER,  new BigDecimal(10000000), BnsprType.STRING, "25", BnsprType.DATE, null, 
						BnsprType.NUMBER, transactionNo }, new Object[0]);
				super.callServiceWithSessionOption(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, false,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, transactionNo,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS, DatabaseConstants.CorporateAccountBlockStatuses.Blocked,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_USER, CommonHelper.getCurrentUser(),
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_DATE, CommonHelper.getLongDateTimeString(new Date()));
			} catch (Exception e) {
				logger.error(String.format("An exception occured while blocking account with number %s", fromAccountNo));
				logger.error(System.currentTimeMillis(), e);
				super.callServiceWithSessionOption(TransactionConstants.InsertCorporateAccountBlockedLog.SERVICE_NAME, false,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCK_REFERENCE, transactionNo,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.BLOCKED_STATUS, DatabaseConstants.CorporateAccountBlockStatuses.BlockFailed,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.IS_UPDATE, true,
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.ERROR_CODE, "0",
						TransactionConstants.InsertCorporateAccountBlockedLog.Input.ERROR_MESSAGE, e.toString());
			}	
		}
	}
	
	private String getDescription(String branchCode, String branchName) {
		StringBuilder builder = new StringBuilder();
		
		builder.append(String.format("%s-%s Fatura �demesi Kurum Hesaplar Aras� Aktar�m", branchCode, branchName)); 
		
		return builder.toString();
	}
	
	private BigDecimal modifyAmount(String corporateOid, BigDecimal fromAccount, BigDecimal amount, TransferLogInformation information) throws Exception {
		BigDecimal modifiedAmount = amount;
		
		CorporationAccountMaster accMaster = (CorporationAccountMaster)super.getHibernateSession().createCriteria(CorporationAccountMaster.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateOid", corporateOid))
				.add(Restrictions.eq("accountNumber", fromAccount))
				.uniqueResult();
		
		if(accMaster != null){
			BigDecimal constantAmount = accMaster.getDefaultAmount();
			if(constantAmount == null){
				constantAmount = new BigDecimal(0);
			}
			GMMap getAvailableBalanceRequest = new GMMap();
			getAvailableBalanceRequest.put("HESAP_NO", fromAccount);
			
			GMMap getAvailableBalanceResponse = GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", getAvailableBalanceRequest);
			
			BigDecimal availableBalance = getAvailableBalanceResponse.getBigDecimal("KULLANILABILIR_BAKIYE");
			information.setAvailableBalance(new BigDecimal(availableBalance.toPlainString()));
			
			information.setConstantAmount(new BigDecimal(constantAmount.toPlainString()));
			
			BigDecimal remainingAmountAfterTransfer = availableBalance.subtract(modifiedAmount);
			
			if (remainingAmountAfterTransfer.compareTo(new BigDecimal("0")) >= 0) {
				
				if (remainingAmountAfterTransfer.compareTo(constantAmount) < 0) {
					modifiedAmount = modifiedAmount.subtract(constantAmount
							.subtract(remainingAmountAfterTransfer));
				}
			}
			else{
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE,
						String.format("Available Balance %s is not enough to afford %s amount. Insufficient funds.", availableBalance, modifiedAmount));
			}
			
		}
		else{
			// TODO think about this
		}
		
		return modifiedAmount;
	}

}
