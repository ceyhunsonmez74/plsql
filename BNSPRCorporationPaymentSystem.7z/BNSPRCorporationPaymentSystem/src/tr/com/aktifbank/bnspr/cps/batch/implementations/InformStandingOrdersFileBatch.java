package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.util.HashMap;
import java.util.List;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.dto.OutgoingFileBatchInformation;
import tr.com.calikbank.bnspr.util.DALUtil;

public class InformStandingOrdersFileBatch extends OutgoingFileBatch {

	private static final String tableName = "STANDING_ORDERS";
	private static final String standingOrdersSuffix = "_1";
	
	protected String standingOrderStatus;
	
	public InformStandingOrdersFileBatch(
			OutgoingFileBatchInformation information) {
		super(information);
		standingOrderStatus = DatabaseConstants.StandingOrderStatus.Active;
	}

	@Override
	protected Object getRecords() throws Throwable {
		return DALUtil.getResults(String.format(QueryRepository.InformStandingOrdersFileBatchRepository.RECORD_FETCH_QUERY,
				standingOrderStatus.equals(DatabaseConstants.StandingOrderStatus.Active) ? "CREATE_DATE" : "CANCEL_DATE",
						CommonHelper.getShortDateTimeString(information.getProcessDate()),
						information.getCorporateCode(),
						standingOrderStatus), tableName);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Object getDataFromSource(String fieldName, Object records,
			int index) throws Throwable {
		GMMap recordSet = (GMMap)records;
		List<HashMap<Object, Object>> recordList = (List<HashMap<Object, Object>>)recordSet.get(tableName);
		HashMap<Object, Object> currentIndex = recordList.get(index);
		if(currentIndex.containsKey(fieldName)){
			Object data = currentIndex.get(fieldName);
			if(data == null){
				if(currentIndex.containsKey(String.format("%s%s", fieldName, standingOrdersSuffix))){
					data = currentIndex.get(String.format("%s%s", fieldName, standingOrdersSuffix));
				}
			}
			return data;
		}
		else{
			throw new Exception(String.format("Field %s cannot be found on both standing order main and ics standing orders tables", fieldName));
		}
	}

	@Override
	protected int getRecordsSize(Object records) throws Throwable {
		return ((GMMap)records).getSize(tableName);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected GMMap getCurrentRow(Object records, int index) throws Exception {
		GMMap recordSet = (GMMap)records;
		List<HashMap<Object, Object>> recordList = (List<HashMap<Object, Object>>)recordSet.get(tableName);
		HashMap<Object, Object> currentIndex = recordList.get(index);
		return CommonHelper.convertMapToGMMap(currentIndex);
	}

}
