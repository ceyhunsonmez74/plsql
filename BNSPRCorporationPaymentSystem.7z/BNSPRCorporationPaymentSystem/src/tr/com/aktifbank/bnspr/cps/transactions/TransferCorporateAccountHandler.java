package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.EmailConstants;
import tr.com.aktifbank.bnspr.cps.acctransfer.AccountTransferInfoFactory;
import tr.com.aktifbank.bnspr.cps.acctransfer.IAccountTransferInformation;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.NotificationMessageConstant.Email.TransferBalanceMessageConstant;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.TransferCorporateAccountHandlerRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.TransferCorporateAccount;
import tr.com.aktifbank.bnspr.cps.dto.EftAtOnceInformation;
import tr.com.aktifbank.bnspr.cps.dto.EmailMessage;
import tr.com.aktifbank.bnspr.cps.dto.TransferInformation;
import tr.com.aktifbank.bnspr.cps.dto.TransferLogInformation;
import tr.com.aktifbank.bnspr.dao.AccountCollectionTypeRel;
import tr.com.aktifbank.bnspr.dao.BalanceTransferDef;
import tr.com.aktifbank.bnspr.dao.BalanceTransferEftEmailDef;
import tr.com.aktifbank.bnspr.dao.BalanceTransferLog;
import tr.com.aktifbank.bnspr.dao.BalanceTransferProcess;
import tr.com.aktifbank.bnspr.dao.CollectionTransferRel;
import tr.com.aktifbank.bnspr.dao.CorporationAccountMaster;
import tr.com.aktifbank.bnspr.dao.CsAccountingTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class TransferCorporateAccountHandler extends
		ParallelRequestHandler {

	private static final String SUCCESSFUL = "2";
	//private static final String ERROR = "0";

	public TransferCorporateAccountHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransferCorporateAccount.Input.CORPORATE_CODE);
		String corporateOid = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
				TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode)
				.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID);
		String corporateName = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
				TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode)
				.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE);
		Date processDate = input.getDate(TransferCorporateAccount.Input.PROCESS_DATE);
		Date currentDate = new Date();
		String transferType = input.getString(TransferCorporateAccount.Input.TRANSFER_TYPE);
		String fromAccountType = input.getString("FROM_ACCOUNT_TYPE", null);
		String doEftOneTimeValue = CommonBusinessOperations.getCorporateParameterValue(corporateCode, "EFT_TEK_KALEM");
		boolean shouldDoEftAtOneTime = StringUtil.isEmpty(doEftOneTimeValue) ? false : doEftOneTimeValue.equals("1");
		Map<String, EftAtOnceInformation> eftAtOnceMap = new HashMap<String, EftAtOnceInformation>();
		
		List<BalanceTransferDef> transferDefList = super.getHibernateSession().createCriteria(BalanceTransferDef.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateOid", corporateOid))
				.add(Restrictions.eq("fromAccountType", StringUtil.isEmpty(fromAccountType) ? DatabaseConstants.AccountDefinitionTypes.CollectionAccount : 
					fromAccountType))
				.add(Restrictions.eq("transferType", transferType))
				.list();
		
		List<BalanceTransferDef> usageToUsageTransferDefList = super.getHibernateSession().createCriteria(BalanceTransferDef.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateOid", corporateOid))
				.add(Restrictions.eq("fromAccountType", DatabaseConstants.AccountDefinitionTypes.UsageAccount))
				.add(Restrictions.eq("toAccountType", DatabaseConstants.AccountDefinitionTypes.UsageAccount))
				.add(Restrictions.eq("transferType", transferType))
				.list();
		
		List<BalanceTransferDef> usageToEftTransferDefList = super.getHibernateSession().createCriteria(BalanceTransferDef.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateOid", corporateOid))
				.add(Restrictions.eq("fromAccountType", DatabaseConstants.AccountDefinitionTypes.UsageAccount))
				.add(Restrictions.eq("toAccountType", DatabaseConstants.AccountDefinitionTypes.EftAccount))
				.add(Restrictions.eq("transferType", transferType))
				.list();
		
		Map<BigDecimal, BigDecimal> accountTransferInfo = new HashMap<BigDecimal, BigDecimal>();
		
		for (BalanceTransferDef transferDef : transferDefList) {
			Criteria processCriteria = super.getHibernateSession().createCriteria(BalanceTransferProcess.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.eq("fromAccount", transferDef.getFromAccountNo()))
					.add(Restrictions.eq("transferDefOid", transferDef.getOid()))
					.add(Restrictions.eq("transferStatus", DatabaseConstants.BalanceTransferProcessStatuses.Waiting))
					.add(Restrictions.eq("transferType", transferType));
			if(transferDef.getDayOfEachMonth() != null){
				if(transferDef.getDayOfEachMonth() == CommonHelper.getDayOfMonth(processDate)){
					// do not add transfer date criteria
				}
				else{
					processCriteria = processCriteria.add(Restrictions.eq("transferDate", CommonHelper.getShortDateTimeString(processDate)));
				}
			}
			else{
				processCriteria = processCriteria.add(Restrictions.eq("transferDate", CommonHelper.getShortDateTimeString(processDate)));
			}
			
			List<BalanceTransferProcess> transferProcessList = processCriteria.list();
			
			List<CollectionTransferRel> transferRelList = super.getHibernateSession().createCriteria(CollectionTransferRel.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("transferParamOid", transferDef.getOid()))
					.list();
			
			int eftTransferCount = 0;
			
			for (BalanceTransferProcess process : transferProcessList) {
				if(process.getIsEftTransfer().equals(DatabaseConstants.IsEftTransfers.EFTTransfer)){
					eftTransferCount++;
				}
			}
			
			boolean checkEftTransfer = eftTransferCount > 1;
			
			for (BalanceTransferProcess process : transferProcessList) {
				String transactionNo = CommonHelper.getNewTransactionNo();
				BalanceTransferLog logRecord = (BalanceTransferLog)super.getHibernateSession().createCriteria(BalanceTransferLog.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("transferProcessOid", process.getOid()))
						.uniqueResult();
				super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
						TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, process.getOid(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSACTION_NO, transactionNo,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Executing);
				super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
						TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, logRecord.getOid(),
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferStarted);
				try {
					String collectionDate = process.getCollectionDate();
					
					TransferInformation transferInformation = new TransferInformation();
					transferInformation.setCollectionDate(CommonHelper.getDateTime(collectionDate, "yyyyMMdd"));
					transferInformation.setCorporateAccountNo(transferDef.getFromAccountNo());
					transferInformation.setCorporateCode(corporateCode);
					transferInformation.setHibernateSession(super.getHibernateSession());
					
					for (CollectionTransferRel transferRel : transferRelList) {
						AccountCollectionTypeRel collectionTypeRel = (AccountCollectionTypeRel)super.getHibernateSession().createCriteria(AccountCollectionTypeRel.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("oid", transferRel.getAccountCollectionOid()))
								.uniqueResult();
						if(collectionTypeRel != null){
							transferInformation.addToCollectionTypes(collectionTypeRel.getCollectionType());
							transferInformation.addToChannelCodes(collectionTypeRel.getChannelCode());
							transferInformation.addToSourceCodes(collectionTypeRel.getSourceCode());
						}
					}
					
					IAccountTransferInformation infoImplementation = AccountTransferInfoFactory.getInstance().createInformation(transferType, transferInformation);
					
					BigDecimal amount = infoImplementation.getTotalAmount();
					
					if(amount == BigDecimal.ZERO) {
						throw new Exception("Hesap aktar�m� yapmak i�in herhangi bir tahsilat i�lemi bulunamad�.");
					}
					
					TransferLogInformation information = new TransferLogInformation();
					
					information.setChannels(transferInformation.getChannelCodes());
					
					String branchCodeQuery = String.format(TransferCorporateAccountHandlerRepository.GET_BRANCH_CODE_QUERY, process.getFromAccount());
					
					String branchCode = DALUtil.getResult(branchCodeQuery);
					
					String branchName = CommonBusinessOperations.getBranchNameFromBranchCode(branchCode);
					
					information.setBranchCode(branchCode);
					information.setBranchName(branchName);
					information.setDescription(transferDef.getTransferDesc());
					
					if(shouldDoEftAtOneTime && checkEftTransfer && process.getIsEftTransfer().equals(DatabaseConstants.IsEftTransfers.EFTTransfer)){
						String key = process.getFromAccount().toPlainString().concat("-").concat(process.getToIban());
						if(eftAtOnceMap.containsKey(key)){
							EftAtOnceInformation info = eftAtOnceMap.get(key);
							info.setAmount(info.getAmount().add(amount));
							info.addToProcessList(logRecord.getOid(), process);
						}
						else{
							EftAtOnceInformation info = new EftAtOnceInformation();
							info.setAmount(amount);
							info.setInformation(information);
							info.setLogRecordOid(logRecord.getOid());
							info.addToProcessList(logRecord.getOid(), process);
							info.setTransferInformation(infoImplementation);
							eftAtOnceMap.put(key, info);
						}
						continue;
					}
					
					transferAccount(process, amount, transactionNo, corporateOid, information);
					
					infoImplementation.updateRecords();
					
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, process.getOid(),
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Successful,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_AMOUNT, information.getTransferredAmount());
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, logRecord.getOid(),
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferExecutedSuccessfully,
							TransactionConstants.InsertBalanceTransferLog.Input.ACTUAL_TRANSFER_AMOUNT, information.getActualAmount(),
							TransactionConstants.InsertBalanceTransferLog.Input.CONSTANT_AMOUNT, information.getConstantAmount(),
							TransactionConstants.InsertBalanceTransferLog.Input.CURRENT_AVAILABLE_BALANCE, information.getAvailableBalance(),
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_AMOUNT, information.getTransferredAmount());
					
					if(process.getIsEftTransfer().equals(DatabaseConstants.IsEftTransfers.NonEFTTransfer)){
						if(accountTransferInfo.containsKey(process.getToAccount())){
							BigDecimal lastTransferredAmount = accountTransferInfo.get(process.getToAccount());
							accountTransferInfo.put(process.getToAccount(), lastTransferredAmount.add(information.getTransferredAmount()));
						}
						else{
							accountTransferInfo.put(process.getToAccount(), information.getTransferredAmount());
						}
					}
					
				} catch (Exception e) {
					logger.error(String.format("An exception occured while transferring balances between accounts for balance transfer process with %s id", process.getOid()));
					logger.error(System.currentTimeMillis(), e);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, process.getOid(),
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Failed);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, logRecord.getOid(),
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferFailed,
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_CODE, "1",
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_MESSAGE, String.format("Transfer yap�l�rken bir hata olu�tu : %s", e));
					
					GMMap messageBodyMap = new GMMap();
					messageBodyMap.put("KURUM_ADI", corporateName);
					messageBodyMap.put("KURUM_KODU", corporateCode);
					messageBodyMap.put("KAYNAK_HESAP", process.getFromAccount());
					messageBodyMap.put("HEDEF_HESAP", process.getToAccount());
					messageBodyMap.put("HATA", e.getMessage());
					
					EmailMessage emailMessage = CommonHelper.prepareEmailBody(corporateName, messageBodyMap, 
							TransferBalanceMessageConstant.Body.MESSAGE_BODY_4_USAGE_ACCOUNT,TransferBalanceMessageConstant.SUBJECT,
							CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_TRANSFER_ERRORS"));
					
					CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
				}
			}
		}
		
		for (Map.Entry<String, EftAtOnceInformation> entry : eftAtOnceMap.entrySet()) {
			EftAtOnceInformation info = entry.getValue();
			BalanceTransferProcess firstProcess = null;
			for (Map.Entry<String, BalanceTransferProcess> logProcess : info.getProcessList().entrySet()) {
				firstProcess = logProcess.getValue();
				break;
			}
			String transactionNo = CommonHelper.getNewTransactionNo();
			try{
				transferAccount(firstProcess, info.getAmount(), transactionNo, corporateOid, info.getInformation());
				
				info.getTransferInformation().updateRecords();
				
				for (Map.Entry<String, BalanceTransferProcess> logProcess : info.getProcessList().entrySet()) {
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, logProcess.getValue().getOid(),
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSACTION_NO, transactionNo,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Successful,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_AMOUNT, info.getInformation().getTransferredAmount());
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, logProcess.getKey(),
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferExecutedSuccessfully,
							TransactionConstants.InsertBalanceTransferLog.Input.ACTUAL_TRANSFER_AMOUNT, info.getInformation().getActualAmount(),
							TransactionConstants.InsertBalanceTransferLog.Input.CONSTANT_AMOUNT, info.getInformation().getConstantAmount(),
							TransactionConstants.InsertBalanceTransferLog.Input.CURRENT_AVAILABLE_BALANCE, info.getInformation().getAvailableBalance(),
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_AMOUNT, info.getInformation().getTransferredAmount());
				}
			}
			catch(Exception e){
				for (Map.Entry<String, BalanceTransferProcess> process : info.getProcessList().entrySet()) {
					logger.error(String.format("An exception occured while transferring balances between accounts for balance transfer process with %s id", 
							process.getValue().getOid()));
					logger.error(System.currentTimeMillis(), e);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, process.getValue().getOid(),
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSACTION_NO, transactionNo,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Failed);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, process.getKey(),
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferFailed,
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_CODE, "1",
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_MESSAGE, String.format("Transfer yap�l�rken bir hata olu�tu : %s", e));
				}
				
				GMMap messageBodyMap = new GMMap();
				messageBodyMap.put("KURUM_ADI", corporateName);
				messageBodyMap.put("KURUM_KODU", corporateCode);
				messageBodyMap.put("KAYNAK_HESAP", firstProcess.getFromAccount());
				messageBodyMap.put("HEDEF_HESAP", firstProcess.getToIban());
				messageBodyMap.put("HATA", e.getMessage());
				
				EmailMessage emailMessage = CommonHelper.prepareEmailBody(corporateName, messageBodyMap, 
						TransferBalanceMessageConstant.Body.MESSAGE_BODY_4_USAGE_ACCOUNT,TransferBalanceMessageConstant.SUBJECT,
						CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_TRANSFER_ERRORS"));
				
				CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
			}
		}
		
		for (BalanceTransferDef def : usageToUsageTransferDefList) {
			if(accountTransferInfo.containsKey(def.getFromAccountNo())){
				String balanceTransferProcessId = super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferProcess.Input.COLLECTION_DATE, processDate,
						TransactionConstants.InsertBalanceTransferProcess.Input.CORPORATE_CODE, corporateCode,
						TransactionConstants.InsertBalanceTransferProcess.Input.CORPORATE_OID, corporateOid,
						TransactionConstants.InsertBalanceTransferProcess.Input.FROM_ACCOUNT, def.getFromAccountNo(),
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_EFT_TRANSFER, false,
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, false,
						TransactionConstants.InsertBalanceTransferProcess.Input.PROCESS_DATE, processDate,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_DATE, currentDate,
						TransactionConstants.InsertBalanceTransferProcess.Input.TO_ACCOUNT, def.getToAccountNo(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Executing,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_DEF_OID, def.getOid(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_TYPE, transferType)
						.getString(TransactionConstants.InsertBalanceTransferProcess.Output.RECORD_ID);
				String balanceTransferLogId = super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferLog.Input.CORPORATE_CODE, corporateCode,
						TransactionConstants.InsertBalanceTransferLog.Input.CORPORATE_OID, corporateOid,
						TransactionConstants.InsertBalanceTransferLog.Input.PROCESS_DATE, processDate,
						TransactionConstants.InsertBalanceTransferLog.Input.PROCESS_USER, CommonHelper.getCurrentUser(),
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_PROCESS_OID, balanceTransferProcessId,
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferStarted)
						.getString(TransactionConstants.InsertBalanceTransferLog.Output.RECORD_ID);
				try {
					String branchCodeQuery = String.format(TransferCorporateAccountHandlerRepository.GET_BRANCH_CODE_QUERY, def.getFromAccountNo());
					
					String branchCode = DALUtil.getResult(branchCodeQuery);
					
					String branchName = CommonBusinessOperations.getBranchNameFromBranchCode(branchCode);
					
					String transactionNo = CommonHelper.getNewTransactionNo();
					BigDecimal transferredAmount = accountTransferInfo.get(def
							.getFromAccountNo());
					CsAccountingTx acc = new CsAccountingTx();
					acc.setProcessId(new BigDecimal("7020"));
					acc.setReferenceId(new BigDecimal(transactionNo));
					acc.setValorDate(new Date());
					acc.setUserCode(CommonHelper.getCurrentUser());
					acc.setOrgCode("444");
					acc.setSourceAccCode(def.getFromAccountNo());
					acc.setTargetAccCode(def.getToAccountNo());
					acc.setAmount(transferredAmount);
					acc.setAmountMt("TRY");
					acc.setChannelCode(CommonHelper.getChannelId());
					acc.setVoucherDesc("");
					acc.setPaymentSource("2");
					acc.setVoucherDesc(StringUtil.isEmpty(def.getTransferDesc()) ? 
							String.format("%s-%s Fatura �demesi Kurum Hesaplar Aras� Aktar�m", branchCode, branchName) : def.getTransferDesc());
					
					super.getHibernateSession().save(acc);
					super.getHibernateSession().flush();
					
					GMMap txInput = new GMMap();
					
					txInput.put(MapKeys.TRX_NAME, "7020");
					txInput.put(MapKeys.TRX_NO, transactionNo);
					
					GMMap transactionMap = super.callGraymoundServiceInSession("BNSPR_TRX_SEND_TRANSACTION", txInput);
					
					logger.info(transactionMap.getString("MESSAGE", ""));
					
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Successful,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_AMOUNT, transferredAmount);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferExecutedSuccessfully,
							TransactionConstants.InsertBalanceTransferLog.Input.ACTUAL_TRANSFER_AMOUNT, transferredAmount,
							TransactionConstants.InsertBalanceTransferLog.Input.CONSTANT_AMOUNT, 0,
							TransactionConstants.InsertBalanceTransferLog.Input.CURRENT_AVAILABLE_BALANCE, 0,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_AMOUNT, transferredAmount);
				} catch (Exception e) {
					logger.error("An exception occured while executing usage account to eft account transfer.");
					logger.error(System.currentTimeMillis(), e);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Failed);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferFailed,
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_CODE, "1",
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_MESSAGE, String.format("Transfer yap�l�rken bir hata olu�tu : %s", e));
					
					GMMap messageBodyMap = new GMMap();
					messageBodyMap.put("KURUM_ADI", corporateName);
					messageBodyMap.put("KURUM_KODU", corporateCode);
					messageBodyMap.put("KAYNAK_HESAP", def.getFromAccountNo());
					messageBodyMap.put("HEDEF_IBAN", def.getToAccountIban());
					messageBodyMap.put("HATA", e.getMessage());
					
					EmailMessage emailMessage = CommonHelper.prepareEmailBody(corporateName, messageBodyMap, 
							TransferBalanceMessageConstant.Body.MESSAGE_BODY_4_EFT_ACCOUNT,TransferBalanceMessageConstant.SUBJECT,
							CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_TRANSFER_ERRORS"));
					
					CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
				}
			}
			else{
				continue;
			}
		}
		
		for (BalanceTransferDef def : usageToEftTransferDefList) {
			if(accountTransferInfo.containsKey(def.getFromAccountNo())){
				String ibanOwner = getIbanOwner(corporateOid, def.getToAccountIban());
				String balanceTransferProcessId = super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferProcess.Input.COLLECTION_DATE, processDate,
						TransactionConstants.InsertBalanceTransferProcess.Input.CORPORATE_CODE, corporateCode,
						TransactionConstants.InsertBalanceTransferProcess.Input.CORPORATE_OID, corporateOid,
						TransactionConstants.InsertBalanceTransferProcess.Input.FROM_ACCOUNT, def.getFromAccountNo(),
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_EFT_TRANSFER, true,
						TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, false,
						TransactionConstants.InsertBalanceTransferProcess.Input.PROCESS_DATE, processDate,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_DATE, currentDate,
						TransactionConstants.InsertBalanceTransferProcess.Input.TO_ACCOUNT, def.getToAccountNo(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TO_IBAN, def.getToAccountIban(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TO_IBAN_OWNER, ibanOwner,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Executing,
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_DEF_OID, def.getOid(),
						TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_TYPE, transferType)
						.getString(TransactionConstants.InsertBalanceTransferProcess.Output.RECORD_ID);
				String balanceTransferLogId = super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
						TransactionConstants.InsertBalanceTransferLog.Input.CORPORATE_CODE, corporateCode,
						TransactionConstants.InsertBalanceTransferLog.Input.CORPORATE_OID, corporateOid,
						TransactionConstants.InsertBalanceTransferLog.Input.PROCESS_DATE, processDate,
						TransactionConstants.InsertBalanceTransferLog.Input.PROCESS_USER, CommonHelper.getCurrentUser(),
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_PROCESS_OID, balanceTransferProcessId,
						TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferStarted)
						.getString(TransactionConstants.InsertBalanceTransferLog.Output.RECORD_ID);
				try {
					String transactionNo = CommonHelper.getNewTransactionNo();
					BigDecimal transferredAmount = accountTransferInfo.get(def
							.getFromAccountNo());
					GMMap eftTransferRequest = new GMMap();
					eftTransferRequest.put("REFERENCE_ID", transactionNo);
					eftTransferRequest.put("AMOUNT", transferredAmount);
					eftTransferRequest.put("RCVR_IBAN", def.getToAccountIban());
					eftTransferRequest.put("RCVR_FULL_NAME", ibanOwner);
					eftTransferRequest.put("SNDR_ACC_CODE",
							def.getFromAccountNo());
					eftTransferRequest.put("RCVR_EXPLANATION", StringUtil.isEmpty(def.getTransferDesc()) ? 
							"" : def.getTransferDesc());
					GMMap eftResponse = super.callGraymoundServiceInSession(
							"CS_EFT_DO", eftTransferRequest);
					if (eftResponse.getString("RESULT").equals(SUCCESSFUL)) {
						// No problem
						BalanceTransferEftEmailDef emailDef = (BalanceTransferEftEmailDef)super.getHibernateSession().createCriteria(BalanceTransferEftEmailDef.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("corporateCode", corporateCode))
															.uniqueResult();
						if(emailDef != null && emailDef.isEmailEftTransfer()) {
							GMMap getCorporateDefResponse = super.callServiceWithParams(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
															TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
							try {
								CommonHelper.sendMail(
										Arrays.asList(emailDef.getEftEmailList().split("[,]")), null, CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "EFT_TRANSFER_EMAIL_FROM"), true, 
										String.format("%s Tarihli %s Nolu hesab�n�zdan yap�lan EFT tutar aktar�m�n� bilgilerinize sunar�z", CommonHelper.shortTimeStringToViewDateString(CommonHelper.getShortDateTimeString(currentDate)), def.getFromAccountNo()), 
										String.format("<html><head></head><body><br/><br/>" + 
										"<b>M��TER� NO :</b> %s<br/>" + 
										"<b>M��TER� �NVANI :</b> %s<br/>" +
										"<b>HESAP NO :</b> %s<br/>" + 
										"<b>HESAP ADI :</b> %s<br/>" + 
										"<b>HESAP D�V�Z KODU :</b> %s<br/>" + 
										"<b>EFT BAK�YES� :</b> %s<br/>" + 
										"</body></html>", getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.CUSTOMER_NUMBER), 
														  getCorporateDefResponse.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE),
														  def.getFromAccountNo(), CommonHelper.getNameOfAccount(def.getFromAccountNo()), CommonHelper.getCurrencyOfAccount(def.getFromAccountNo()), 
														  transferredAmount)
										);
							} catch (Exception e) {
								logger.error("Mail g�nderilirken hata meydana geldi...");
								logger.error(e.toString());
							}
						}
					} else {
						throw new Exception(eftResponse.getString("ERROR_DESC"));
					}
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Successful,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_AMOUNT, transferredAmount,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSACTION_NO, transactionNo);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferExecutedSuccessfully,
							TransactionConstants.InsertBalanceTransferLog.Input.ACTUAL_TRANSFER_AMOUNT, transferredAmount,
							TransactionConstants.InsertBalanceTransferLog.Input.CONSTANT_AMOUNT, 0,
							TransactionConstants.InsertBalanceTransferLog.Input.CURRENT_AVAILABLE_BALANCE, 0,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_AMOUNT, transferredAmount);
				} catch (Exception e) {
					logger.error("An exception occured while executing usage account to eft account transfer.");
					logger.error(System.currentTimeMillis(), e);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferProcess.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferProcess.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferProcess.Input.RECORD_ID, balanceTransferProcessId,
							TransactionConstants.InsertBalanceTransferProcess.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferProcessStatuses.Failed);
					super.callServiceWithSessionOption(TransactionConstants.InsertBalanceTransferLog.SERVICE_NAME, false, 
							TransactionConstants.InsertBalanceTransferLog.Input.IS_UPDATE, true,
							TransactionConstants.InsertBalanceTransferLog.Input.RECORD_ID, balanceTransferLogId,
							TransactionConstants.InsertBalanceTransferLog.Input.TRANSFER_STATUS, DatabaseConstants.BalanceTransferLogStatuses.TransferFailed,
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_CODE, "1",
							TransactionConstants.InsertBalanceTransferLog.Input.ERROR_MESSAGE, String.format("Transfer yap�l�rken bir hata olu�tu : %s", e));
					
					GMMap messageBodyMap = new GMMap();
					messageBodyMap.put("KURUM_ADI", corporateName);
					messageBodyMap.put("KURUM_KODU", corporateCode);
					messageBodyMap.put("KAYNAK_HESAP", def.getFromAccountNo());
					messageBodyMap.put("HEDEF_IBAN", def.getToAccountIban());
					messageBodyMap.put("HATA", e.getMessage());
					
					EmailMessage emailMessage = CommonHelper.prepareEmailBody(corporateName, messageBodyMap, 
							TransferBalanceMessageConstant.Body.MESSAGE_BODY_4_EFT_ACCOUNT,TransferBalanceMessageConstant.SUBJECT,
							CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_TRANSFER_ERRORS"));
					
					CommonHelper.sendMail(emailMessage.getReceiptList(), null, emailMessage.getFrom(), true, emailMessage.getSubject(), emailMessage.getBody(),true);
				}
			}
			else{
				continue;
			}
		}
	}
	
	private String getIbanOwner(String corporateOid, String toAccountIban) {
		if(!StringUtil.isEmpty(toAccountIban)){
			CorporationAccountMaster record = (CorporationAccountMaster)super.getHibernateSession().createCriteria(CorporationAccountMaster.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateOid", corporateOid))
					.add(Restrictions.eq("iban", toAccountIban))
					.uniqueResult();
			if(record != null){
				return record.getAccountOwner();
			}
			else{
				return null;
			}
		}
		else{
			return null;
		}
	}

	private void transferAccount(BalanceTransferProcess process,
			BigDecimal amount, String transactionNo, String corporateOid, TransferLogInformation information) throws Exception {
		
		GMMap transferCorporateBalanceRequest = new GMMap();
		transferCorporateBalanceRequest.put(MapKeys.CORPORATE_CODE, process.getCorporateCode());
		transferCorporateBalanceRequest.put("FROM_ACCOUNT_NO", process.getFromAccount());
		transferCorporateBalanceRequest.put("DESCRIPTION", information.getDescription());
		transferCorporateBalanceRequest.put(MapKeys.BRANCH_CODE, information.getBranchCode());
		transferCorporateBalanceRequest.put("BRANCH_NAME", information.getBranchName());
		transferCorporateBalanceRequest.put(MapKeys.AMOUNT, amount);
		transferCorporateBalanceRequest.put(MapKeys.CORPORATE_OID, corporateOid);
		transferCorporateBalanceRequest.put("IS_EFT_TRANSFER", process.getIsEftTransfer());
		transferCorporateBalanceRequest.put(MapKeys.TRX_NO, transactionNo);
		transferCorporateBalanceRequest.put("TO_IBAN", process.getToIban());
		transferCorporateBalanceRequest.put("TO_IBAN_OWNER", process.getToIbanOwner());
		transferCorporateBalanceRequest.put("TO_ACCOUNT_NO", process.getToAccount());
		transferCorporateBalanceRequest.put("TRANSFER_TYPE", process.getTransferType());
		transferCorporateBalanceRequest.put("COLLECTION_DATE", process.getCollectionDate());

		
		
		GMMap transferBalanceResponse = CommonHelper.callGraymoundServiceOutsideSession("CDM_TRANSFER_CORPORATE_BALANCE", transferCorporateBalanceRequest);
		
		information.setActualAmount(transferBalanceResponse.getBigDecimal("ACTUAL_AMOUNT"));
		information.setTransferredAmount(transferBalanceResponse.getBigDecimal("TRANSFERRED_AMOUNT"));
		information.setAvailableBalance(transferBalanceResponse.getBigDecimal("AVAILABLE_BALANCE"));
		information.setConstantAmount(transferBalanceResponse.getBigDecimal("CONSTANT_AMOUNT"));
	}

}
