package tr.com.aktifbank.bnspr.cps.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class TTSReconciliationDetail extends	BaseTransferObject  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String processCode;
	
	private BigDecimal collectionAmount;
	
	private String stan;
	
	private String paymentDate;
	
	private String invoiceNo;
	
	private String serviceNo;

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}

	public BigDecimal getCollectionAmount() {
		return collectionAmount;
	}

	public void setCollectionAmount(BigDecimal collectionAmount) {
		this.collectionAmount = collectionAmount;
	}

	public String getStan() {
		return stan;
	}

	public void setStan(String stan) {
		this.stan = stan;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	@Override
	public String toString() {
		return "TTSReconciliationDetail [processCode=" + processCode
				+ ", collectionAmount=" + collectionAmount + ", stan=" + stan
				+ ", paymentDate=" + paymentDate + ", invoiceNo=" + invoiceNo
				+ ", serviceNo=" + serviceNo + "]";
	}

	
}
