package tr.com.aktifbank.bnspr.cps.batch.implementations;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.dto.CorporateReconciliationDetailCallResult;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.integration.sibeskiNew.ServiceMessage;
import tr.com.aktifbank.integration.sibeskiNew.SibeskiNewClient;
import tr.com.aktifbank.sibeskiNew.ws.services.DetayMutabakatResultModel;

import com.graymound.util.GMMap;


public final class SibeskiReconciliationDetailBatch extends CollectionReconciliationDetailBatch {

	private static final Log logger = LogFactory.getLog(SibeskiReconciliationDetailBatch.class);
	Session session;
	List<DetayMutabakatResultModel> details = new ArrayList<DetayMutabakatResultModel>();
	ServiceMessage message;
	Map<String, DetayMutabakatResultModel> indexedCorporateRecords;
	
	public SibeskiReconciliationDetailBatch(GMMap input, ServiceMessage message) {
		super(input);
		this.message = message;
		this.indexedCorporateRecords = new HashMap<String, DetayMutabakatResultModel>();
		session = CommonHelper.getHibernateSession();
	}

	@Override
	protected void setCancelCollectionExtraParameters(GMMap cancelCollectionRequest, int corporateRecordIndex) {
		cancelCollectionRequest.put(MapKeys.PARAMETER3, details.get(corporateRecordIndex).getMakbuzNo());
		cancelCollectionRequest.put(MapKeys.PARAMETER4, details.get(corporateRecordIndex).getMakbuzSeri());
	}

	@Override
	protected CorporateReconciliationDetailCallResult callCorporateReconDetail() throws Exception {
		CorporateReconciliationDetailCallResult result = new CorporateReconciliationDetailCallResult();
		try {
			String vezneNo = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER1);
			String sifre = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.PARAMETER2);
			String url = input.getString(MapKeys.WS_PARAMETERS, 0, MapKeys.WS_ENDPOINT);
			Calendar reconDate = CommonHelper.getCalendarWithYYYYMMDD(input.getString(MapKeys.RECON_DATE)); 
			
			DetayMutabakatResultModel[] makbuzList = SibeskiNewClient.detayMutabakat(reconDate, vezneNo, sifre, url,this.message);
			
			for(DetayMutabakatResultModel  tahsilat: makbuzList){
				if(tahsilat.getIptalTutar() == 0){
					details.add(tahsilat);
				}
			}			
			result.setSuccessfulCall(true);
		} catch (Exception e) {
			logger.error("An exception occured while calling edas recon detail service");
			logger.error(System.currentTimeMillis(), e);
			result.setSuccessfulCall(false);
			result.setReturnCode("0");
		}
		return result;
	}

	@Override
	protected void setPaymentDetailsRequestExtraParameters(GMMap collectionDetailRequest, int corporateRecordIndex) {
		collectionDetailRequest.put(MapKeys.SUBSCRIBER_NO1, details.get(corporateRecordIndex).getAboneNo());
		collectionDetailRequest.put(MapKeys.PARAMETER3, details.get(corporateRecordIndex).getMakbuzNo());
		collectionDetailRequest.put(MapKeys.PARAMETER4, details.get(corporateRecordIndex).getMakbuzSeri());
	}

	@Override
	protected boolean doesBankRecordExistInCorporateRecords(GMMap bankRecord) {
		return this.indexedCorporateRecords.containsKey(bankRecord.getString(MapKeys.PARAMETER4) + bankRecord.getString(MapKeys.PARAMETER3));
	}
	
	@Override
	protected void indexBankRecords() throws Exception {
		int size = super.getBankRecordSize();
		for (int i = 0; i < size; i++) {
			super.setBankRecordIndex(super.getBankRecordAtIndex(i).getString(MapKeys.PARAMETER4) + super.getBankRecordAtIndex(i).getString(MapKeys.PARAMETER3), super.getBankRecordAtIndex(i));
		}
	}

	@Override
	protected void indexCorporateRecords() throws Exception {
		for (int i = 0; i < details.size(); i++) {
			this.indexedCorporateRecords.put(this.details.get(i).getMakbuzSeri() + this.details.get(i).getMakbuzNo(), this.details.get(i));
		}
	}

	@Override
	protected boolean doesCorporateRecordExistInBankRecords(int corporateRecordIndex) {
		return super.doesExistWithKey(this.details.get(corporateRecordIndex).getMakbuzSeri() + this.details.get(corporateRecordIndex).getMakbuzNo());
	}
	
	@Override
	protected void onCancelRecordNotFound(GMMap collectionDetailResponse, int corporateRecordIndex)
			throws Exception {
		DetayMutabakatResultModel corporateDetail = details.get(corporateRecordIndex);
		logger.info(String.format("Following corporate record has not been found in database. Abone Numaras� : %s, Miktar : %s ", 
				corporateDetail.getAboneNo(), 
				corporateDetail.getTutar()));
		invoicePayment payment = new invoicePayment();
		payment.setStatus(true);
		payment.setCorporateCode(input.getString(MapKeys.CORPORATE_CODE));
		payment.setCollectionType(Short.valueOf("0"));
		payment.setInvoiceMainOid("0");
		payment.setSubscriberNo1(String.valueOf(corporateDetail.getAboneNo()));
		payment.setInvoiceNo("0");
		payment.setPaymentStatus(PaymentStatuses.Cancelled);
		payment.setTxNo(new BigDecimal("-1"));
		payment.setParameter3(String.valueOf(corporateDetail.getMakbuzNo()));
		payment.setParameter4(String.valueOf(corporateDetail.getMakbuzSeri()));
		payment.setTermYear(String.valueOf(corporateDetail.getYil()));
		payment.setTermMonth(String.valueOf(corporateDetail.getDonem()));
		payment.setInvoiceAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentAmount(new BigDecimal(corporateDetail.getTutar()));
		payment.setPaymentDate(input.getString(MapKeys.RECON_DATE) + "120000");
		payment.setCancelDate(input.getString(MapKeys.RECON_DATE) + "120000");
		
		session.saveOrUpdate(payment);
		session.flush();
		
		collectionDetailResponse.put(MapKeys.SUBSCRIBER_NO1, corporateDetail.getAboneNo());
		collectionDetailResponse.put(MapKeys.INVOICE_NO, "0");
		collectionDetailResponse.put(MapKeys.TRX_NO, "-1");
		collectionDetailResponse.put(MapKeys.INVOICE_AMOUNT, corporateDetail.getTutar());
	}

}
