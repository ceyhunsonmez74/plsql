package tr.com.aktifbank.bnspr.cps.transactions;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository.CorporateAccountControlHandlerRepository;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class CorporateAccountControlHandler extends RequestHandler {

	private static final String RESULT_TABLE = "RESULT_TABLE";
	
	public CorporateAccountControlHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateOid = input.getString(TransactionConstants.CorporateAccountControl.Input.CORPORATE_OID, null);
		String sourceCode = input.getString(TransactionConstants.CorporateAccountControl.Input.SOURCE_CODE);
		String channelCode = input.getString(TransactionConstants.CorporateAccountControl.Input.CHANNEL_CODE);
		short collectionType = (short)input.getInt(TransactionConstants.CorporateAccountControl.Input.COLLECTION_TYPE);
		
		if(corporateOid == null){
			String corporateCode = input.getString(TransactionConstants.CorporateAccountControl.Input.CORPORATE_CODE);
			corporateOid = CommonBusinessOperations.getCorporateOidFromCorporateCode(corporateCode);
		}
		
		String concentrationQuery = String.format(CorporateAccountControlHandlerRepository.FETCH_CONCENTRATION_QUERY, corporateOid);
		
		GMMap concentration = DALUtil.getResults(concentrationQuery, RESULT_TABLE);
		
		int concentrationSize = concentration.getSize(RESULT_TABLE);
		
		String definitionId = null;
		
		for (int i = 0; i < concentrationSize; i++) {
			String subNoStart = concentration.getString(RESULT_TABLE, i, "SUBSCRIBER_NO");
			int viewOrder = concentration.getInt(RESULT_TABLE, i, "VIEW_ORDER");
			
			String currentSubNo = input.getString(String.format("SUBSCRIBER_NO%s", viewOrder));
			
			if(currentSubNo.startsWith(subNoStart)){
				definitionId = concentration.getString(RESULT_TABLE, i, "DEFINITION_ID");
				break;
			}
		}
		
		if(concentrationSize > 0 && StringUtil.isEmpty(definitionId)){
			CommonHelper.throwBusinessException(BusinessException.CONCENTRATIONISNOTCOMPATIBLE.getCode());
		}
		
		String accountQuery = CorporateAccountControlHandlerRepository.GET_ACCOUNT_NO_QUERY;
		
		BigDecimal account = null;
		
		if(!StringUtil.isEmpty(definitionId)){
			accountQuery = accountQuery.concat(" AND act.ACCOUNT_MATCH_DEF_ID = :did");
			account = (BigDecimal)CommonHelper.queryUniqueResultWithHibernate(super.getHibernateSession(), 
					accountQuery, 
					"oid", corporateOid, 
					"acttype", DatabaseConstants.AccountDefinitionTypes.CollectionAccount,
					"cotype", collectionType,
					"scode", sourceCode,
					"chcode", channelCode,
					"did", definitionId);
		}
		else{
			account = (BigDecimal)CommonHelper.queryUniqueResultWithHibernate(super.getHibernateSession(), 
					accountQuery, 
					"oid", corporateOid, 
					"acttype", DatabaseConstants.AccountDefinitionTypes.CollectionAccount,
					"cotype", collectionType,
					"scode", sourceCode,
					"chcode", channelCode);
		}
		
		if (account == null) {
			throw new BatchComponentException(
					BusinessException.CORPORATIONACCOUNTNOTFOUND);
		}
		else{
			output.put(TransactionConstants.CorporateAccountControl.Output.ACCOUNT_NO, account);
		}
		output.put(TransactionConstants.CorporateAccountControl.Output.RESULT, true);
	}

}
