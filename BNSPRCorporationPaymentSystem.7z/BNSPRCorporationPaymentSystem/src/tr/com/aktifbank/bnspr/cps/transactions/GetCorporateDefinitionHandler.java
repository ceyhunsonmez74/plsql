package tr.com.aktifbank.bnspr.cps.transactions;



import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class GetCorporateDefinitionHandler extends RequestHandler {

	public GetCorporateDefinitionHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, null);
		String corporateOid = input.getString(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_OID, null);
		boolean throwsException = input.getBoolean(TransactionConstants.GetCorporateDefinition.Inputs.THROWS_EXCEPTION, true);
		boolean getChannelDefinitions = input.getBoolean(TransactionConstants.GetCorporateDefinition.Inputs.GET_CHANNEL_DEFINITIONS, false);
		Criteria query = super.getHibernateSession().
				createCriteria(CorporateMaster.class)
				.add(Restrictions.eq("status", true));
		CorporateMaster masterResult = null;
		if(corporateCode != null){
			masterResult = (CorporateMaster)query
					.add(Restrictions.eq("corporateCode", corporateCode))
					.uniqueResult();
		}
		else if(corporateOid != null){
			masterResult = (CorporateMaster)query
					.add(Restrictions.eq("oid", corporateOid))
					.uniqueResult();
		}
		else{
			throw new Exception("Neither corporate code and nor corporate oid is present in request");
		}
		
		if (masterResult != null) {
			String activenessResult = masterResult.getCorporateActiveness()
					.toLowerCase(Locale.UK);
			String actualActiveLowerCase = DatabaseConstants.CorporateActiveness.Active
					.toLowerCase(Locale.UK);
			output.put(TransactionConstants.GetCorporateDefinition.Output.RESULT, true);
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.CORPORATE_ACTIVENESS,
					activenessResult.equals(actualActiveLowerCase));
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.CORPORATE_NAME,
					masterResult.getCorporateName());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE,
					masterResult.getShortCode());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE,
					masterResult.getCorporateCode());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID,
					masterResult.getOid());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.IS_ONLINE_CORPORATE,
					masterResult.getIsOnlineCorporate());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.BANK_CODE,
					masterResult.getCorporateBankCode());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.ALLOW_PART_AFTER_DUE,
					masterResult.getAllowPartAfterDue());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.ALLOW_PART_PAYMENT,
					masterResult.isAllowPartPayment());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.SECTOR_CODE,
					masterResult.getSectorCode());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.ALLOW_AFTER_DUE,
					masterResult.isAllowAfterDueDate());
			output.put(
					TransactionConstants.GetCorporateDefinition.Output.CUSTOMER_NUMBER,
					masterResult.getCustomerNumber());
			if(getChannelDefinitions){
				GMMap channelOutput = super.callServiceWithParams(TransactionConstants.GetCorporateChannelDefinitions.SERVICE_NAME,
						TransactionConstants.GetCorporateChannelDefinitions.Input.CORPORATE_OID, masterResult.getOid());
				List<String> distinctChannels = new ArrayList<String>();
				for (int i = 0; i < channelOutput.getSize(TransactionConstants.GetCorporateChannelDefinitions.Output.CHANNEL_TABLE); i++) {
					String channelCode = channelOutput.getString(
							TransactionConstants.GetCorporateChannelDefinitions.Output.CHANNEL_TABLE, 
							i, 
							TransactionConstants.GetCorporateChannelDefinitions.Output.CHANNEL_CODE);
					if(!distinctChannels.contains(channelCode)){
						output.put(TransactionConstants.GetCorporateDefinition.Output.CHANNELS, 
								i, 
								TransactionConstants.GetCorporateDefinition.Output.CHANNEL_ID,
								channelCode);
					}
				}
			}
		}
		else{
			if(throwsException){
				throw new BatchComponentException(BusinessException.CORPORATENOTFOUND, StringUtil.isEmpty(corporateCode) ? corporateOid : corporateCode);
			}
			else{
				output.put(TransactionConstants.GetCorporateDefinition.Output.RESULT, false);
			}
		}

	}

}
