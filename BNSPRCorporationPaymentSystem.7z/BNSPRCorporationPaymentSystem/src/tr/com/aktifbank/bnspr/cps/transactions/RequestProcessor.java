package tr.com.aktifbank.bnspr.cps.transactions;

import com.graymound.util.GMMap;

public final class RequestProcessor {
	private RequestProcessor(){
		
	}
	
	private static final RequestProcessor instance = new RequestProcessor();
	
	public static RequestProcessor getInstance(){
		return instance;
	}
	
	public GMMap process(GMMap input, RequestHandler handler){
		return handler.handle(input);
	}
}
