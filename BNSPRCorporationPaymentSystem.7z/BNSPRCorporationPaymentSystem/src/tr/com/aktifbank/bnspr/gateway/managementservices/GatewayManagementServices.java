package tr.com.aktifbank.bnspr.gateway.managementservices;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.util.GMMap;

public class GatewayManagementServices {
	private static final Log logger = LogFactory.getLog(GatewayManagementServices.class);
	private static GMMap parameterMap = new GMMap();
	private static String tableName = "INPUT_TABLE";
	private static String colParent = "COL_PARENT";
	private static String colIndex = "COL_INDEX";
	private static String colKey = "COL_KEY";
	private static String colValue = "COL_VALUE";
	private static String GW_CON = "GW_CON";
	private static String TABLE_NAME = "RESULT_TABLE";

	@GraymoundService("ICS_GET_GW_COMMUNICATION_LOG")
	public static GMMap getGatewayCommunicationLog(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		String date_format = "yyyymmdd";
		String corporate_oid = inputMap.getString("CORPORATE_OID");
		String operation_oid = inputMap.getString("OPERATION_OID");
		String state = inputMap.getString("STATE");
		String from_date = inputMap.getString("START_DATE");
		String to_date = inputMap.getString("END_DATE");
		if (from_date.equals(to_date)) {
			Date current_date;
			try {
				current_date = CommonHelper.getDateTime(from_date, date_format);
				Date next_day = CommonHelper.addDay(current_date, 1);
				to_date = CommonHelper.getDateString(next_day, date_format);
			} catch (ParseException e) {
				logger.info(e.getMessage());
				throw ExceptionHandler.convertException(e);
			}
		}

		from_date = CommonHelper.shortTimeStringToViewDateString(from_date);
		to_date = CommonHelper.shortTimeStringToViewDateString(to_date);
		String strSQL = "";
		strSQL = "SELECT L.OID,D.CORPORATION_NAME,L.STAN,L.ERROR,L.FAILED,L.REQUEST_DATE,L.REQUEST,L.response_date,L.RESPONSE,L.TRY_COUNT,O.OPERATION_NAME " + "FROM ICS.GW_COMMUNICATION_LOG L,ICS.GW_CORPORATION_DEFINITION D,ICS.GW_CORPORATION_OPERATION_CODE OC,ICS.GW_OPERATION_CODE O "
				+ "WHERE L.CORPORATION_DEFINITION_OID=D.OID AND OC.OID=L.OPERATION_CODE_OID AND OC.OPERATION_CODE_OID=O.OID AND " + "L.REQUEST_DATE>=TO_DATE('" + from_date + "','DD/MM/YYYY') and L.REQUEST_DATE<TO_DATE('" + to_date + "','DD/MM/YYYY')";
		if (!corporate_oid.equals("0")) {
			strSQL = strSQL.concat(" AND D.OID=".concat(corporate_oid));
		}
		if (!operation_oid.equals("0")) {
			strSQL = strSQL.concat(" AND O.OID=".concat(operation_oid));
		}
		if (state.equals("1")) {
			strSQL = strSQL.concat(" AND L.ERROR=0");
		}
		if (state.equals("2")) {
			strSQL = strSQL.concat(" AND L.ERROR=1");
		}

		strSQL = strSQL.concat(" ORDER BY L.STAN DESC");
		returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
		return returnMap;
	}

	@GraymoundService("ICS_BNSPR_GW_COMPONENTS_REFRESH_CALLER")
	public static GMMap gatewayComponentsRefresh(GMMap inputMap) {
		GMMap returnMap = new GMMap();
		GMMap outMap = new GMMap();
		GMConnection gmConnection;
		try {
			gmConnection = GMConnection.getConnection(GW_CON);
			returnMap.putAll(gmConnection.serviceCall("BNSPR_GW_COMPONENTS_REFRESH", inputMap));
			if (returnMap.containsKey("GW_RESULT")) {
				if (returnMap.getString("GW_RESULT").equals("1")) {
					logger.info("ICS_BNSPR_GW_COMPONENTS_REFRESH_CALLER -> cache basarili olarak refresh edildi...");
					outMap.put("REFRESH_RESULT", "SUCCESS");
				}
			}
			if (returnMap.containsKey("GW_INTERNAL_ERROR_CODE")) {
				if (returnMap.getString("GW_INTERNAL_ERROR_CODE") != null) {
					logger.info("ICS_BNSPR_GW_COMPONENTS_REFRESH_CALLER -> BNSPR_GW_COMPONENTS_REFRESH -> GW_INTERNAL_ERROR_CODE -> ".concat(returnMap.getString("GW_INTERNAL_ERROR_CODE")));
					logger.info("ICS_BNSPR_GW_COMPONENTS_REFRESH_CALLER -> BNSPR_GW_COMPONENTS_REFRESH -> GW_INTERNAL_ERROR_DESC -> ".concat(returnMap.getString("GW_INTERNAL_ERROR_DESC")));
					logger.info("ICS_BNSPR_GW_COMPONENTS_REFRESH_CALLER -> BNSPR_GW_COMPONENTS_REFRESH -> GW_INTERNAL_ERROR_DESC -> - Gateway Hata Aciklamasi = ".concat(returnMap.getString("GW_INTERNAL_ERROR_DESC")));
					outMap.put("REFRESH_RESULT", "FAIL");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}

	@GraymoundService("ICS_BNSPR_GW_GET_SOCKETS_INFO")
	public static GMMap gatewaySocketInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMConnection gmConnection;
		try {
			gmConnection = GMConnection.getConnection(GW_CON);
			oMap.putAll(gmConnection.serviceCall("BNSPR_GW_GET_SOCKETS_INFO", iMap));
		} catch (IOException e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		} finally {
			System.out.println("ICS_BNSPR_GW_GET_SOCKETS_INFO called BNSPR_GW_GET_SOCKETS_INFO and return map is -> ".concat(oMap.toString()));
		}
		return oMap;
	}

	@GraymoundService("ICS_BNSPR_GW_GET_CLIENTS_CACHE_INFO")
	public static GMMap gatewayClientCacheInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMConnection gmConnection;
		try {
			gmConnection = GMConnection.getConnection(GW_CON);
			oMap.putAll(gmConnection.serviceCall("BNSPR_GW_GET_CLIENTS_CACHE_INFO", iMap));
		} catch (IOException e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("ICS_LOAD_GATEWAY_CORPORATES")
	public static GMMap gatewayLoadGatewayCorporates(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap returnMap = new GMMap();
		try {
			String TABLE_NAME_CORPORATE = "RESULT_TABLE_CORPORATE";
			String strSQL = "";
			// strSQL =
			// "SELECT OID,corporation_name FROM ICS.GW_CORPORATION_DEFINITION";
			strSQL = QueryRepository.GatewayManagementServicesRepository.GET_CORPORATE_DEFINITION;
			returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
			oMap.put(TABLE_NAME, 0, "VALUE", "0");
			oMap.put(TABLE_NAME, 0, "NAME", "Hepsi");
			oMap.put(TABLE_NAME_CORPORATE, 0, "VALUE", "0");
			oMap.put(TABLE_NAME_CORPORATE, 0, "NAME", "Se�iniz");
			for (int i = 1; i < returnMap.getSize(TABLE_NAME) + 1; i++) {
				oMap.put(TABLE_NAME, i, "VALUE", returnMap.getString(TABLE_NAME, i - 1, "OID"));
				oMap.put(TABLE_NAME, i, "NAME", returnMap.getString(TABLE_NAME, i - 1, "CORPORATION_NAME"));
				oMap.put(TABLE_NAME_CORPORATE, i, "VALUE", returnMap.getString(TABLE_NAME, i - 1, "OID"));
				oMap.put(TABLE_NAME_CORPORATE, i, "NAME", returnMap.getString(TABLE_NAME, i - 1, "CORPORATION_NAME"));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("ICS_LOAD_GATEWAY_OPERATIONS")
	public static GMMap gatewayLoadOperations(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap returnMap = new GMMap();
		try {
			String strSQL = "";
			// strSQL = "SELECT OID,operation_name FROM ICS.GW_OPERATION_CODE";
			strSQL = QueryRepository.GatewayManagementServicesRepository.GET_GW_OPERATION_CODE;
			returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
			oMap.put(TABLE_NAME, 0, "VALUE", "0");
			oMap.put(TABLE_NAME, 0, "NAME", "Hepsi");
			for (int i = 1; i < returnMap.getSize(TABLE_NAME) + 1; i++) {
				oMap.put(TABLE_NAME, i, "VALUE", returnMap.getString(TABLE_NAME, i - 1, "OID"));
				oMap.put(TABLE_NAME, i, "NAME", returnMap.getString(TABLE_NAME, i - 1, "OPERATION_NAME"));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("SEND_DIRECT_GATEWAY_MESSAGE")
	public static GMMap sendDirectGatewayMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap returnMap = new GMMap();
		GMMap inputMap = new GMMap();
		try {
			for (int i = 0; i < iMap.getSize("INPUT_TABLE"); i++) {
				if (iMap.getString("INPUT_TABLE", i, colIndex).isEmpty()) {
					if (!iMap.getString("INPUT_TABLE", i, colValue).isEmpty()) {
						inputMap.put(iMap.getString("INPUT_TABLE", i, colKey), iMap.getString("INPUT_TABLE", i, colValue));
					}
				} else {
					if (!iMap.getString("INPUT_TABLE", i, colValue).isEmpty()) {
						inputMap.put(iMap.getString("INPUT_TABLE", i, colParent), Integer.parseInt(iMap.getString("INPUT_TABLE", i, colIndex)), iMap.getString("INPUT_TABLE", i, colKey), iMap.getString("INPUT_TABLE", i, colValue));
					}
				}
			}
			// asagidakiler kapanacak
			// logger.info("ICS_VF_INVOICE_DEBT_INQUIRY will get GW_CON connection...");
			// GMConnection gmConnection = GMConnection.getConnection(GW_CON);
			// logger.info("ICS_VF_INVOICE_DEBT_INQUIRY got GW_CON connection successfully...");
			// returnMap.putAll(gmConnection.serviceCall("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE",
			// inputMap));
			// asagidaki acilacak
			logger.info("SEND_DIRECT_GATEWAY_MESSAGE -> inputMap = ".concat(inputMap.toString()));
			returnMap = CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_SEND_AND_RECIEVE_ISO_MESSAGE", inputMap);
			returnMap.put("RESULT", "SUCCESFUL");
		} catch (Exception e) {
			returnMap.put("RESULT", "FAIL");
			throw ExceptionHandler.convertException(e);
		} finally {
			returnMap.put("RESULT_STR", returnMap.toString());
			logger.info("SEND_DIRECT_GATEWAY_MESSAGE -> inputMap = ".concat(returnMap.toString()));
		}
		return returnMap;
	}

	@GraymoundService("ICS_GATEWAY_ADD_TEMPLATE_MESSAGE")
	public static GMMap addTemplateMessage(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap returnMap = new GMMap();
		String operationOid = iMap.getString("OPERATION_OID");
		String corporationCode = iMap.getString("CORPORATION_CODE");
		String corporateOperationCode = iMap.getString("CORPORATE_OPERATION_CODE");
		int counter = 0;
		int counter2 = 0;
		try {
			parameterMap = new GMMap();
			String strSQL = "";
			String[] operationCodeArray = corporateOperationCode.split("-");
			// strSQL =
			// "select mf.map_name from ics.gw_message_structure ms,ics.gw_message_field mf where ms.operation_code_oid='".concat(operationOid).concat("' and ms.message_field_oid=mf.oid and message_type_oid=1 and mf.oid not in(select root from ics.gw_message_field)");
			strSQL = String.format(QueryRepository.GatewayManagementServicesRepository.GW_TEMPLATE_MESSAGE, operationOid);
			returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
			for (int i = 0; i < returnMap.getSize(TABLE_NAME); i++) {
				addParameter("", "", returnMap.getString(TABLE_NAME, i, "MAP_NAME"), "", i);
				counter++;
			}
			// strSQL =
			// "select mf2.map_name parent_name,mf.map_name from ics.gw_message_field mf,ics.gw_message_field mf2 where mf.root in(select mf.oid from ics.gw_message_structure ms,ics.gw_message_field mf where ms.operation_code_oid='".concat(operationOid)
			// .concat("' and ms.message_field_oid=mf.oid and message_type_oid=1 and mf.oid in(select root from ics.gw_message_field)) and mf.root=mf2.oid");
			strSQL = String.format(QueryRepository.GatewayManagementServicesRepository.GW_ADD_TEMPLATE_MESSAGE, operationOid);
			returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
			for (int i = 0; i < returnMap.getSize(TABLE_NAME); i++) {
				addParameter(returnMap.getString(TABLE_NAME, i, "PARENT_NAME"), "0", returnMap.getString(TABLE_NAME, i, "MAP_NAME"), "", i + counter);
				counter2++;
			}
			counter = counter + counter2;
			addParameter("", "", "OPERATION_CODE_ID", operationCodeArray[1].toString(), counter);
			addParameter("", "", "CORPORATION_ID", corporationCode, ++counter);
			oMap.putAll(parameterMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

		}
		return oMap;
	}

	public static void addParameter(String pColParent, String pColIndex, String pColKey, String pColValue, int pIndex) {
		parameterMap.put(tableName, pIndex, colParent, pColParent);
		parameterMap.put(tableName, pIndex, colIndex, pColIndex);
		parameterMap.put(tableName, pIndex, colKey, pColKey);
		parameterMap.put(tableName, pIndex, colValue, pColValue);
	}

	@GraymoundService("ICS_LOAD_CORPORATE_OPERATIONS")
	public static GMMap loadCorporateOperations(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap returnMap = new GMMap();
		try {
			String TABLE_NAME = "CORPORATION_OPERATIONS";
			String strSQL = "";
			String corporateOid = iMap.getString("CORPORATION_CODE");
			// strSQL =
			// "select coc.oid,oc.operation_name,oc.oid OCS_OID from ics.gw_corporation_operation_code coc,ics.gw_corporation_definition cd,ics.gw_operation_code oc ";
			// strSQL =
			// strSQL.concat("where coc.corporation_definition_oid=cd.oid and oc.oid=coc.operation_code_oid and coc.corporation_definition_oid=").concat(corporateOid);
			strSQL = String.format(QueryRepository.GatewayManagementServicesRepository.LOAD_CORPORATE_OPERATIONS, corporateOid);
			returnMap = DALUtil.getResults(strSQL, TABLE_NAME);
			for (int i = 0; i < returnMap.getSize(TABLE_NAME); i++) {
				oMap.put(TABLE_NAME, i, "VALUE", returnMap.getString(TABLE_NAME, i, "OID"));
				oMap.put(TABLE_NAME, i, "NAME", returnMap.getString(TABLE_NAME, i, "OPERATION_NAME").concat("-").concat(returnMap.getString(TABLE_NAME, i, "OCS_OID")));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("ICS_GW_LOAD_FROM_FILE")
	public static GMMap loadFromFile(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap returnMap = new GMMap();
		try {
			String fileName = iMap.getString("PATH");
			String bankaLine = "";
			BufferedReader bankaBufferReader = new BufferedReader(new FileReader(fileName));
			bankaLine = bankaBufferReader.readLine();
			while (bankaLine != null) {
				bankaLine = bankaBufferReader.readLine();
				logger.info(bankaLine);
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
