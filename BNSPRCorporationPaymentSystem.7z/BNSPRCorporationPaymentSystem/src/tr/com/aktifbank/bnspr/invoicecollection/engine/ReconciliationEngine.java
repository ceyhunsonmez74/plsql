package tr.com.aktifbank.bnspr.invoicecollection.engine;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Clob;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.StandingOrderStatus;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CollectionReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.MoneyLoadReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.ReconciliationResubmit;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.StandingOrderReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.TaxReconciliationBatch;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cps.transactions.StandingOrderReconciliationBatchHandler;
import tr.com.aktifbank.bnspr.cps.transactions.StartStandingOrderReconciliationBacthHandler;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CollectionTypeDef;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.aktifbank.bnspr.dao.ReconProcessDataLog;
import tr.com.aktifbank.bnspr.dao.ReconProcessTypePrm;
import tr.com.aktifbank.bnspr.dao.ReconStatusPrm;
import tr.com.aktifbank.bnspr.dao.ReconSubTypePrm;
import tr.com.aktifbank.bnspr.dao.ReconTypePrm;
import tr.com.aktifbank.bnspr.dao.StandingOrderMain;
import tr.com.aktifbank.bnspr.dao.StandingOrderNtfyPrcesslog;
import tr.com.aktifbank.bnspr.dao.icsStandingOrders;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ReconciliationEngine {

	private static final String STANDING_ORDER_PAYMENT_CHANNEL = "45";
	private static final Log logger = LogFactory.getLog(ReconciliationEngine.class);
	private static final String  recon_all_status = "5";

	@GraymoundService("ICS_RECON_LOAD_RECON_TYPES")
	public static GMMap loadReconTypes(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<ReconTypePrm> reconTypeList = session.createCriteria(ReconTypePrm.class).addOrder(Order.asc("reconType")).list();
		int i = 0;
		for (ReconTypePrm reconType : reconTypeList) {
			oMap.put("RECON_TYPES", i, "NAME", reconType.getTypeDesc());
			oMap.put("RECON_TYPES", i, "VALUE", reconType.getReconType());
			i++;
		}
		return oMap;
	}

	@GraymoundService("ICS_RECON_LOAD_RECON_WORK_TYPE")
	public static GMMap loadReconWorkType(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<ReconSubTypePrm> reconWorkTypeList = session.createCriteria(ReconSubTypePrm.class).list();
		int i = 0;
		for (ReconSubTypePrm reconWorkType : reconWorkTypeList) {
			oMap.put("RECON_WORK_TYPE", i, "NAME", reconWorkType.getDescription());
			oMap.put("RECON_WORK_TYPE", i, "VALUE", reconWorkType.getSubType());
			i++;
		}
		return oMap;
	}

	@GraymoundService("ICS_RECON_PROCESS")
	public static GMMap reconProcess(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean sendAll = iMap.getBoolean("SEND_ALL");

		if (sendAll) {
			for (int j = 0; j < iMap.getInt("DETAIL_TABLE_COUNT"); j++) {
				iMap.put("SUBSCRIBER_NO1", iMap.get("DETAIL_TABLE", j, "SUBSCRIBER_NO1"));
				oMap = sendReconProcess(iMap);
			}
		} else {
			oMap = sendReconProcess(iMap);
		}
		return oMap;
	}

	public static GMMap sendReconProcess(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rcInput = new GMMap();
		try {
			String reconProcessType = iMap.getString("RECON_PROCESS_TYPE");
			String subscriberNo1 = iMap.getString("SUBSCRIBER_NO1");
			rcInput.put(MapKeys.CORPORATE_CODE, iMap.getString(MapKeys.CORPORATE_CODE));
			GMMap cdMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", rcInput);
			String corporateCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_CODE);
			String bankCode = cdMap.getString(TransactionConstants.GetCorporateDefinition.Output.BANK_CODE);

			GMMap onlineCorporateServiceCallInputMap = new GMMap();

			onlineCorporateServiceCallInputMap.put(MapKeys.SUBSCRIBER_NO1, subscriberNo1);
			onlineCorporateServiceCallInputMap.put(MapKeys.BANK_CODE, bankCode);
			onlineCorporateServiceCallInputMap.put(MapKeys.CORPORATE_CODE, corporateCode);
			onlineCorporateServiceCallInputMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
			onlineCorporateServiceCallInputMap.put(MapKeys.RECON_CALL, true);

			oMap.put("ERROR_MESSAGE", "-");

			if (DatabaseConstants.ReconciliationProcessType.standingOrderMessageSent.equals(reconProcessType)) {
				// talimat yapilmasi isteniyorsa
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_SAVE_STANDING_ORDER");
			} else if (DatabaseConstants.ReconciliationProcessType.cancelStandingOrderMessageSent.equals(reconProcessType)) {
				// talimat iptal yapilmasi isteniyorsa
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "STO_CANCEL_STANDING_ORDERS");
			} else if (DatabaseConstants.ReconciliationProcessType.collectionMessageSent.equals(reconProcessType)) {
				// tahsilat yapilmasi isteniyorsa
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_DO_INVOICE_COLLECTION");
			} else if (DatabaseConstants.ReconciliationProcessType.cancelCollectionMessageSent.equals(reconProcessType)) {
				// tahsilat iptal yapilmasi isteniyorsa
				onlineCorporateServiceCallInputMap.put(MapKeys.GM_SERVICE_NAME, "ICS_INVOICE_COLLECTION_CANCEL");
			}
			GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", onlineCorporateServiceCallInputMap);
		} catch (GMRuntimeException e) {
			oMap.put("ERROR_MESSAGE", e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("ICS_RECON_LOAD_RECON_PROCESS_TYPES")
	public static GMMap loadReconProcessTypes(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<ReconProcessTypePrm> reconProcessTypeList = session.createCriteria(ReconProcessTypePrm.class).list();
		int i = 0;
		for (ReconProcessTypePrm reconProcessType : reconProcessTypeList) {
			if((iMap.getString("TAX_DEFAULT_SECTOR_VALUE").equalsIgnoreCase(iMap.getString("SECTOR_NAME"))&&reconProcessType.getProcessDesc().contains("Tahsilat"))||!iMap.getString("TAX_DEFAULT_SECTOR_VALUE").equalsIgnoreCase(iMap.getString("SECTOR_NAME"))){
				oMap.put("RECON_PROCESS_TYPE", i, "NAME", reconProcessType.getProcessDesc());
				oMap.put("RECON_PROCESS_TYPE", i, "VALUE", reconProcessType.getProcessType());
				i++;
			}
		}
		return oMap;
	}

	@GraymoundService("ICS_RECON_LOAD_RECON_STATUS")
	public static GMMap loadReconStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<ReconStatusPrm> reconStatusList = session.createCriteria(ReconStatusPrm.class).list();
		int i = 0;
		for (ReconStatusPrm reconStatus : reconStatusList) {
			oMap.put("RECON_STATUS", i, "NAME", reconStatus.getDescription());
			oMap.put("RECON_STATUS", i, "VALUE", reconStatus.getStatus());
			i++;
		}
		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_RECON_LOAD_RECONS")
	public static GMMap loadRecons(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");
		List<ReconLog> reconLogList = new ArrayList<ReconLog>();
		Criteria reconStatusCriteria = session.createCriteria(ReconLog.class);
		if (iMap.getString("RECON_STATUS").equals(recon_all_status)
				&& iMap.getString("CORPORATE_CODE") != null) {
			if (!StringUtil.isEmpty(iMap.getString("CORPORATE_CODE"))) {
				reconStatusCriteria.add(Restrictions.eq("corporateCode",
						iMap.getString("CORPORATE_CODE")));
			}
			reconLogList = reconStatusCriteria
					.add(Restrictions.eq("reconType",
							(byte) iMap.getInt("RECON_TYPE")))
					.add(Restrictions.eq("status", true))
					.add(Restrictions.between("reconDate",
							iMap.getString("DATE"), iMap.getString("END_DATE")))
					.add(Restrictions.eq("subType",
							iMap.getString("RECON_WORK_TYPE")))
					.addOrder(Order.desc("reconDate")).list();
		} else {
			if (!StringUtil.isEmpty(iMap.getString("CORPORATE_CODE"))) {
				reconStatusCriteria.add(Restrictions.eq("corporateCode",
						iMap.getString("CORPORATE_CODE")));
			}
			reconLogList = reconStatusCriteria
					.add(Restrictions.eq("reconStatus",
							iMap.getString("RECON_STATUS")))
					.add(Restrictions.eq("reconType",
							(byte) iMap.getInt("RECON_TYPE")))
					.add(Restrictions.eq("status", true))
					.add(Restrictions.between("reconDate",
							iMap.getString("DATE"), iMap.getString("END_DATE")))
					.add(Restrictions.eq("subType",
							iMap.getString("RECON_WORK_TYPE")))
					.addOrder(Order.desc("reconDate")).list();

		}
		if (reconLogList.size() == 0) {
			return oMap;
		}
		int i = 0;
		GMMap oMap2 = new GMMap();
		for (ReconLog reconLog : reconLogList) {
			String corporateName = CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(reconLog.getCorporateCode());
			oMap2.put("RESULT_TABLE", i, "OID", reconLog.getOid());
			oMap2.put("RESULT_TABLE", i, "STATUS", reconLog.isStatus());
			oMap2.put("RESULT_TABLE", i, "CORPORATE_CODE", reconLog.getCorporateCode());
			oMap2.put("RESULT_TABLE", i, "CORPORATE_NAME", corporateName);

			oMap2.put("RESULT_TABLE", i, "RECON_STATUS", CommonHelper.getValueOfParameter("CDM_RECON_STATUSES", reconLog.getReconStatus()));

			oMap2.put("RESULT_TABLE", i, "RECON_TYPE", CommonHelper.getValueOfParameter("CDM_RECON_TYPES", String.valueOf(reconLog.getReconType())));
						
			oMap2.put("RESULT_TABLE", i, "PROCESS_DATE", CommonHelper.convertToDate(reconLog.getProcessDate(), "yyyyMMdd", "ddMMyyyy", "/"));
			oMap2.put("RESULT_TABLE", i, "PROCESS_TIME", reconLog.getProcessTime());
			oMap2.put("RESULT_TABLE", i, "PROCESS_USER", reconLog.getProcessUser());
			oMap2.put("RESULT_TABLE", i, "BANK_COUNT", reconLog.getBankCount());
			oMap2.put("RESULT_TABLE", i, "BANK_AMOUNT", reconLog.getBankAmount());
			oMap2.put("RESULT_TABLE", i, "CORPORATE_COUNT", reconLog.getCorporateCount());
			oMap2.put("RESULT_TABLE", i, "CORPORATE_AMOUNT", reconLog.getCorporateAmount());
			oMap2.put("RESULT_TABLE", i, "BANK_CANCEL_COUNT", reconLog.getBankCancelCount());
			oMap2.put("RESULT_TABLE", i, "BANK_CANCEL_AMOUNT", reconLog.getBankCancelAmount());
			oMap2.put("RESULT_TABLE", i, "CORPORATE_CANCEL_COUNT", reconLog.getCorporateCancelCount());
			oMap2.put("RESULT_TABLE", i, "CORPORATE_CANCEL_AMOUNT", reconLog.getCorporateCancelAmount());
			oMap2.put("RESULT_TABLE", i, "ERROR_DESC", reconLog.getErrorDesc());
			oMap2.put("RESULT_TABLE", i, "ERROR_CODE", reconLog.getErrorCode());
			oMap2.put("RESULT_TABLE", i, "RECON_DATE", CommonHelper.convertToDate(reconLog.getReconDate(), "yyyyMMdd", "ddMMyyyy", "/"));

			oMap2.put("RESULT_TABLE_STO", i, "OID", reconLog.getOid());
			oMap2.put("RESULT_TABLE_STO", i, "STATUS", reconLog.isStatus());
			oMap2.put("RESULT_TABLE_STO", i, "CORPORATE_CODE", reconLog.getCorporateCode());
			oMap2.put("RESULT_TABLE_STO", i, "CORPORATE_NAME", corporateName);

			oMap2.put("RESULT_TABLE_STO", i, "RECON_STATUS",  CommonHelper.getValueOfParameter("CDM_RECON_STATUSES", reconLog.getReconStatus()));
			
			oMap2.put("RESULT_TABLE_STO", i, "RECON_TYPE", CommonHelper.getValueOfParameter("CDM_RECON_TYPES", String.valueOf(reconLog.getReconType())));
						
			oMap2.put("RESULT_TABLE_STO", i, "PROCESS_DATE", CommonHelper.convertToDate(reconLog.getProcessDate(), "yyyyMMdd", "ddMMyyyy", "/"));
			oMap2.put("RESULT_TABLE_STO", i, "PROCESS_TIME", reconLog.getProcessTime());
			oMap2.put("RESULT_TABLE_STO", i, "PROCESS_USER", reconLog.getProcessUser());
			oMap2.put("RESULT_TABLE_STO", i, "BANK_COUNT", reconLog.getBankCount());
			oMap2.put("RESULT_TABLE_STO", i, "CORPORATE_COUNT", reconLog.getCorporateCount());
			oMap2.put("RESULT_TABLE_STO", i, "BANK_CANCEL_COUNT", reconLog.getBankCancelCount());
			oMap2.put("RESULT_TABLE_STO", i, "CORPORATE_CANCEL_COUNT", reconLog.getCorporateCancelCount());
			oMap2.put("RESULT_TABLE_STO", i, "ERROR_DESC", reconLog.getErrorDesc());
			oMap2.put("RESULT_TABLE_STO", i, "ERROR_CODE", reconLog.getErrorCode());
			oMap2.put("RESULT_TABLE_STO", i, "RECON_DATE", CommonHelper.convertToDate(reconLog.getReconDate(), "yyyyMMdd", "ddMMyyyy", "/"));

			i++;
			
		}
		String[][] data = new String[oMap2.getSize("RESULT_TABLE_STO")][2];
		for (int index = 0; index < oMap2.getSize("RESULT_TABLE_STO"); index++) {
			data[index][0]=CommonHelper.convertTurkishCharacter(oMap2.getString("RESULT_TABLE_STO", index,"CORPORATE_NAME"));
			data[index][1]=String.valueOf(index);
		}
		Arrays.sort(data, new Comparator<String[]>() {
			@Override
			public int compare(final String[] entry1, final String[] entry2) {
				final String row1 = entry1[0];
				final String row2 = entry2[0];
				return row1.compareTo(row2);
			}
		});
		for (int j = 0; j < data.length; j++) {
			oMap.put("RESULT_TABLE_STO", j, oMap2.getMap("RESULT_TABLE_STO", Integer.valueOf(data[j][1]).intValue()));	
		}
		
		data = new String[oMap2.getSize("RESULT_TABLE")][2];
		for (int index = 0; index < oMap2.getSize("RESULT_TABLE"); index++) {
			data[index][0]=CommonHelper.convertTurkishCharacter(oMap2.getString("RESULT_TABLE", index,"CORPORATE_NAME"));
			data[index][1]=String.valueOf(index);
		}
		Arrays.sort(data, new Comparator<String[]>() {
			@Override
			public int compare(final String[] entry1, final String[] entry2) {
				final String row1 = entry1[0];
				final String row2 = entry2[0];
				return row1.compareTo(row2);
			}
		});
		for (int j = 0; j < data.length; j++) {
			oMap.put("RESULT_TABLE", j, oMap2.getMap("RESULT_TABLE", Integer.valueOf(data[j][1]).intValue()));	
		}
		return oMap;
	}



	@GraymoundService("ICS_RECON_GET_REPORTS")
	public static GMMap reconGetReports(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			String collectionTableName = "RESULT_TABLE";
			String stoTableName = "RESULT_TABLE_STO";
			HashMap<String, Object> parameters = new HashMap<String, Object>();

			GMMap reconsInputMap = new GMMap();
			reconsInputMap.put("CORPORATE_CODE", iMap.getString("CORPORATE_CODE"));
			reconsInputMap.put("RECON_STATUS", iMap.getString("RECON_STATUS"));
			reconsInputMap.put("RECON_TYPE", iMap.getInt("RECON_TYPE"));
			reconsInputMap.put("DATE", iMap.getString("DATE"));
			reconsInputMap.put("RECON_WORK_TYPE", iMap.getString("RECON_WORK_TYPE"));
			reconsInputMap.put("CORPORATE_NAME", iMap.getString("CORPORATE_NAME"));
			reconsInputMap.put("END_DATE", iMap.getString("END_DATE"));
			GMMap reconsOutputMap = CommonHelper.callGraymoundServiceInHibernateSession("ICS_RECON_LOAD_RECONS", reconsInputMap);
			ArrayDeque<String> reports = new ArrayDeque<String>();

			if(iMap.getString(TaxReconciliationBatch.Input.SECTOR_NAME).equalsIgnoreCase(iMap.getString(TaxReconciliationBatch.Input.TAX_DEFAULT_SECTOR_VALUE))){
				//vergi i�in
			}else if (iMap.getInt("RECON_TYPE") == DatabaseConstants.ReconciliationTypes.Collection) {
				List<?> collectionReconList = (List<?>) reconsOutputMap.get(collectionTableName);
				parameters.put("COLLECTION_RECONS", collectionReconList);
				reports.add("ICS_COLLECTION_RECON_REPORT");
			} else if (iMap.getInt("RECON_TYPE") == DatabaseConstants.ReconciliationTypes.StandingOrder) {
				List<?> stoReconList = (List<?>) reconsOutputMap.get(stoTableName);
				parameters.put("STO_RECONS", stoReconList);
				reports.add("ICS_STO_RECON_REPORT");
			}

			JasperPrint jasperPrint = new JasperPrint();
			jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
			jasperPrint.removePage(0);
			jasperPrint.removePage(jasperPrint.getPages().size() - 1);
			oMap.put("REPORT", jasperPrint);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return oMap;
	}

	@GraymoundService("ICS_RECON_LOAD_ERROR_DETAILS")
	public static GMMap loadErrorDetails(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<ReconProcessDataLog> rpdList = session.createCriteria(ReconProcessDataLog.class)
				.add(Restrictions.eq("reconLogOid", iMap.getString("OID"))).add(Restrictions.eq("status", true)).list();

		int i = 0;
		for (ReconProcessDataLog reconProcessDataLog : rpdList) {
			oMap.put("RESULTS", i, "COLLECTION_TYPE", reconProcessDataLog.getCollectionType());
			oMap.put("RESULTS", i, "ERROR_CODE", reconProcessDataLog.getErrorCode());
			oMap.put("RESULTS", i, "ERROR_DESC", reconProcessDataLog.getErrorDesc());
			oMap.put("RESULTS", i, "INVOICE_AMOUNT", reconProcessDataLog.getInvoiceAmount());
			oMap.put("RESULTS", i, "INVOICE_DUE_DATE", reconProcessDataLog.getInvoiceDueDate());
			oMap.put("RESULTS", i, "INVOICE_NO", reconProcessDataLog.getInvoiceNo());
			oMap.put("RESULTS", i, "PROCESS_STAN_NO", reconProcessDataLog.getProcessStanNo());
			
			oMap.put("RESULTS", i, "PROCESS_TYPE", CommonHelper.getValueOfParameter("CDM_RECON_PROCESS_TYPES", String.valueOf(reconProcessDataLog.getProcessType())));
			
			String referenceNumber = reconProcessDataLog.getSubscriberNo1();

			if (reconProcessDataLog.getSubscriberNo2() != null) {
				referenceNumber += "-" + reconProcessDataLog.getSubscriberNo2();
			}
			if (reconProcessDataLog.getSubscriberNo3() != null) {
				referenceNumber += "-" + reconProcessDataLog.getSubscriberNo3();
			}
			if (reconProcessDataLog.getSubscriberNo4() != null) {
				referenceNumber += "-" + reconProcessDataLog.getSubscriberNo4();
			}
			oMap.put("RESULTS", i, "SUBSCRIBER_NO1", referenceNumber);
			// oMap.put("RESULTS", i, "SUBSCRIBER_NO2",
			// reconProcessDataLog.getSubscriberNo2());
			// oMap.put("RESULTS", i, "SUBSCRIBER_NO3",
			// reconProcessDataLog.getSubscriberNo3());
			// oMap.put("RESULTS", i, "SUBSCRIBER_NO4",
			// reconProcessDataLog.getSubscriberNo4());

			oMap.put("RESULTS_STO", i, "ERROR_CODE", reconProcessDataLog.getErrorCode());
			oMap.put("RESULTS_STO", i, "ERROR_DESC", reconProcessDataLog.getErrorDesc());
			oMap.put("RESULTS_STO", i, "PROCESS_STAN_NO", reconProcessDataLog.getProcessStanNo());
			
			oMap.put("RESULTS_STO", i, "PROCESS_TYPE", CommonHelper.getValueOfParameter("CDM_RECON_PROCESS_TYPES", String.valueOf(reconProcessDataLog.getProcessType())));
						
			oMap.put("RESULTS_STO", i, "SUBSCRIBER_NO1", reconProcessDataLog.getSubscriberNo1());
			oMap.put("RESULTS_STO", i, "SUBSCRIBER_NO2", reconProcessDataLog.getSubscriberNo2());
			oMap.put("RESULTS_STO", i, "SUBSCRIBER_NO3", reconProcessDataLog.getSubscriberNo3());
			oMap.put("RESULTS_STO", i, "SUBSCRIBER_NO4", reconProcessDataLog.getSubscriberNo4());

			i++;
		}
		return oMap;

	}

	@GraymoundService("STO_STANDING_ORDER_RECONCILIATION_STARTER")
	public static GMMap startStandingOrderReconciliationBacth(GMMap input) {
		return RequestProcessor.getInstance().process(input, new StartStandingOrderReconciliationBacthHandler());
	}

	@GraymoundService("STO_STANDING_ORDER_RECONCILIATION")
	public static GMMap standingOrderReconciliationBatch(GMMap input) {
		return RequestProcessor.getInstance().process(input, new StandingOrderReconciliationBatchHandler());
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER_COUNT")
	public static GMMap getStandingOrderCount(GMMap input) {
		GMMap outMap = new GMMap();
		
		List<String> corporateCodes = new ArrayList<String>();
		if( null != input.getString(MapKeys.CORPORATE_CODE) ){
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			if( corporateCode.contains(",")){
				String [] corporateCodeList = corporateCode.split(",");
				for( String corpCode : corporateCodeList ){
					corporateCodes.add(corpCode);
				}
			}
			else{
				corporateCodes.add(corporateCode);
			}
		}
		
		Session session = DAOSession.getSession("BNSPRDal");

		Criteria criteria = session.createCriteria(icsStandingOrders.class)
				.add(Restrictions.in("corporateCode", corporateCodes))
				.add(Restrictions.eq("standingOrderStatus", StandingOrderStatus.Active)).add(Restrictions.eq("status", true));

		if (input.containsKey("RECON_DATE")) { // TODO change back to constant
			criteria.add(Restrictions.like("createDate", input.getString("RECON_DATE"), MatchMode.START));
		}

		List<icsStandingOrders> bankStandingOrderList = criteria.list();
		outMap.put(TransactionConstants.GetStandingOrderCount.Output.RECORD_COUNT, bankStandingOrderList.size());

		Criteria criteria2 = session.createCriteria(icsStandingOrders.class)
				.add(Restrictions.in("corporateCode", corporateCodes))
				.add(Restrictions.eq("standingOrderStatus", StandingOrderStatus.Canelled)).add(Restrictions.eq("status", true));

		if (input.containsKey("RECON_DATE")) {
			criteria2.add(Restrictions.like("updateDate", input.getString("RECON_DATE"), MatchMode.START));
		}

		List<icsStandingOrders> bankStandingOrderCancelList = criteria2.list();
		outMap.put("CANCEL_COUNT", bankStandingOrderCancelList.size());
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("STO_STANDING_ORDER_RECONCILIATION_GET_STANDING_ORDER")
	public static GMMap getStandingOrdersForReconciliation(GMMap input) {
		GMMap outMap = new GMMap();
		
		List<String> corporateCodes = new ArrayList<String>();
		if( null != input.getString(MapKeys.CORPORATE_CODE) ){
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			if( corporateCode.contains(",")){
				String [] corporateCodeList = corporateCode.split(",");
				for( String corpCode : corporateCodeList ){
					corporateCodes.add(corpCode);
				}
			}
			else{
				corporateCodes.add(corporateCode);
			}
		}
		
		Session session = DAOSession.getSession("BNSPRDal");
		Criteria criteria = session.createCriteria(icsStandingOrders.class)
				.add(Restrictions.in("corporateCode", corporateCodes))
				.add(Restrictions.eq("standingOrderStatus", StandingOrderStatus.Active)).add(Restrictions.eq("status", true));

		if (input.containsKey("RECON_DATE")) {
			criteria.add(Restrictions.like("createDate", input.getString("RECON_DATE"), MatchMode.START));
		}

		List<icsStandingOrders> bankStandingOrderList = criteria.list();

		Criteria criteria2 = session.createCriteria(icsStandingOrders.class)
				.add(Restrictions.in("corporateCode", corporateCodes))
				.add(Restrictions.eq("standingOrderStatus", StandingOrderStatus.Canelled)).add(Restrictions.eq("status", true));

		if (input.containsKey("RECON_DATE")) {
			criteria2.add(Restrictions.like("updateDate", input.getString("RECON_DATE"), MatchMode.START));
		}

		List<icsStandingOrders> bankStandingOrderCancelList = criteria2.list();

		outMap.put("LIST_ACTIVE", bankStandingOrderList);
		List<icsStandingOrders> allList = criteria.list();
		allList.addAll(bankStandingOrderCancelList);
		outMap.put("LIST", allList);
		outMap.put("LIST_CANCELED", bankStandingOrderCancelList);
		return outMap;
	}

	@GraymoundService("ICS_RECON_PROCESS_DATA_LOG_INSERT")
	public static GMMap reconProcessDataLogInsert(GMMap input) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		ReconProcessDataLog rpdl = new ReconProcessDataLog();
		// get parameters
		String corporateCode = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.CORPORATE_CODE) : null));
		String errorCode = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.ERROR_CODE) : null));
		String errorDesc = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.ERROR_DESC) : null));
		String invoiceDueDate = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.INVOICE_DUE_DATE) : null));
		String invoiceNo = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.INVOICE_NO) : null));
		String parameter1 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_1) : null));
		String parameter2 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_2) : null));
		String parameter3 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_3) : null));
		String parameter4 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_4) : null));
		String parameter5 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_5) : null));
		String parameter6 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_6) : null));
		String parameter7 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.PARAMETER_7) : null));
		String processStanNo = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.PROCESS_STAN_NO) : null));
		String reconLogOid = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.RECON_LOG_OID) : null));
		String subscriberNo1 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_1) : null));
		String subscriberNo2 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_2) : null));
		String subscriberNo3 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_3) : null));
		String subscriberNo4 = ((input.containsKey(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_4) ? input
				.getString(TransactionConstants.ReconProcessDataLog.Input.SUBSCRIBER_NO_4) : null));
		//
		// set values
		rpdl.setCorporateCode(corporateCode);
		rpdl.setErrorCode(errorCode);
		rpdl.setErrorDesc(errorDesc);
		rpdl.setInvoiceDueDate(invoiceDueDate);
		rpdl.setInvoiceNo(invoiceNo);
		rpdl.setParameter1(parameter1);
		rpdl.setParameter2(parameter2);
		rpdl.setParameter3(parameter3);
		rpdl.setParameter4(parameter4);
		rpdl.setParameter5(parameter5);
		rpdl.setParameter6(parameter6);
		rpdl.setParameter7(parameter7);
		rpdl.setProcessStanNo(processStanNo);
		rpdl.setReconLogOid(reconLogOid);
		rpdl.setSubscriberNo1(subscriberNo1);
		rpdl.setSubscriberNo2(subscriberNo2);
		rpdl.setSubscriberNo3(subscriberNo3);
		rpdl.setSubscriberNo4(subscriberNo4);

		// non string values
		if (input.containsKey(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE)) {
			byte processType = Byte.valueOf(input.getString(TransactionConstants.ReconProcessDataLog.Input.PROCESS_TYPE));
			rpdl.setProcessType(processType);
		}
		if (input.containsKey(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT)) {
			BigDecimal invoiceAmount = input.getBigDecimal(TransactionConstants.ReconProcessDataLog.Input.INVOICE_AMOUNT);
			rpdl.setInvoiceAmount(invoiceAmount);
		}
		if (input.containsKey(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO)) {
			int installmentNo = input.getInt(TransactionConstants.ReconProcessDataLog.Input.INSTALLMENT_NO);
			rpdl.setInstallmentNo(installmentNo);
		}
		if (input.containsKey(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE)) {
			short collectionType = Short.valueOf(input.getString(TransactionConstants.ReconProcessDataLog.Input.COLLECTION_TYPE));
			rpdl.setCollectionType(collectionType);
		}
		//

		boolean status = true;
		rpdl.setStatus(status);

		// insert log
		session.save(rpdl);

		return oMap;

	}

	@GraymoundService("ICS_RECON_LOG_INSERT")
	public static GMMap reconLogInsert(GMMap input) {
		GMMap output = new GMMap();
		String username = GMContext.getCurrentContext().getSession().get("USER_NAME").toString();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		Session hibernateSession = CommonHelper.getHibernateSession();
		ReconLog reconLog = new ReconLog();
		reconLog.setStatus(true);
		reconLog.setCorporateCode(input.getString(TransactionConstants.ReconLogInsert.Input.CORPORATE_CODE));
		reconLog.setReconStatus(input.getString(TransactionConstants.ReconLogInsert.Input.RECON_STATUS));
		reconLog.setReconType((byte) input.getInt(TransactionConstants.ReconLogInsert.Input.RECON_TYPE));
		reconLog.setSubType(input.getString(TransactionConstants.ReconLogInsert.Input.SUB_TYPE));
		reconLog.setProcessDate(df.format(new Date()));
		reconLog.setProcessTime(CommonHelper.getStringTimeNow());
		reconLog.setReconDate(df.format(new Date()));
		reconLog.setReconTime(CommonHelper.getStringTimeNow());
		reconLog.setProcessUser(username);
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT)) {
			reconLog.setBankCount(new BigDecimal(input.getInt(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT)));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.BANK_AMOUNT)) {
			reconLog.setBankAmount(new BigDecimal(input.getInt(TransactionConstants.ReconLogUpdate.Input.BANK_AMOUNT)));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT)) {
			reconLog.setCorporateCount(new BigDecimal(input.getInt(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT)));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.CORPORATE_AMOUNT)) {
			reconLog.setCorporateAmount(new BigDecimal(input.getInt(TransactionConstants.ReconLogUpdate.Input.CORPORATE_AMOUNT)));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT)) {
			reconLog.setBankCancelCount(new BigDecimal(input.getInt(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT)));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_AMOUNT)) {
			reconLog.setBankCancelAmount(new BigDecimal(input.getInt(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_AMOUNT)));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT)) {
			reconLog.setCorporateCancelCount(new BigDecimal(input.getInt(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT)));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_AMOUNT)) {
			reconLog.setCorporateCancelAmount(new BigDecimal(input.getInt(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_AMOUNT)));
		}
		reconLog.setErrorDesc(input.getString(TransactionConstants.ReconLogUpdate.Input.ERROR_DESC, null));
		reconLog.setErrorCode(input.getString(TransactionConstants.ReconLogUpdate.Input.ERROR_CODE, null));
		reconLog.setSubType(input.getString(TransactionConstants.ReconLogUpdate.Input.SUB_TYPE, null));
		reconLog.setReconDate(input.getString(TransactionConstants.ReconLogUpdate.Input.RECON_DATE, null));
		reconLog.setReconTime(input.getString(TransactionConstants.ReconLogUpdate.Input.RECON_TIME, null));
		hibernateSession.save(reconLog);
		hibernateSession.flush();
		output.put(TransactionConstants.ReconLogInsert.Output.RECON_LOG_OID, reconLog.getOid());
		return output;
	}

	@GraymoundService("ICS_RECON_LOG_UPDATE")
	public static GMMap reconLogUpdate(GMMap input) {
		GMMap output = new GMMap();
		Session hibernateSession = CommonHelper.getHibernateSession();
		ReconLog recLog = (ReconLog) hibernateSession.createCriteria(ReconLog.class)
				.add(Restrictions.eq("oid", input.getString(TransactionConstants.ReconLogUpdate.Input.RECON_LOG_OID)))
				.add(Restrictions.eq("status", true)).uniqueResult();
		recLog.setReconStatus(input.getString(TransactionConstants.ReconLogUpdate.Input.RECON_STATUS));
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.ERROR_DESC)) {
			recLog.setErrorDesc(input.getString(TransactionConstants.ReconLogUpdate.Input.ERROR_DESC));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.ERROR_CODE)) {
			recLog.setErrorCode(input.getString(TransactionConstants.ReconLogUpdate.Input.ERROR_CODE));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT)
				&& input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT) != null) {
			recLog.setBankCount(input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.BANK_COUNT));
		}
		else{
			recLog.setBankCount(BigDecimal.ZERO);
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.BANK_AMOUNT)
				&& input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.BANK_AMOUNT) != null) {
			recLog.setBankAmount(input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.BANK_AMOUNT));
		}
		else{
			recLog.setBankAmount(BigDecimal.ZERO);
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT)
				&& input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT) != null) {
			recLog.setCorporateCount(input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.CORPORATE_COUNT));
		}
		else{
			recLog.setCorporateCount(BigDecimal.ZERO);
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.CORPORATE_AMOUNT)
				&& input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.CORPORATE_AMOUNT) != null) {
			recLog.setCorporateAmount(input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.CORPORATE_AMOUNT));
		}
		else{
			recLog.setCorporateAmount(BigDecimal.ZERO);
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT)
				&& input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT) != null) {
			recLog.setBankCancelCount(input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_COUNT));
		}
		else{
			recLog.setBankCancelCount(BigDecimal.ZERO);
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_AMOUNT)
				&& input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_AMOUNT) != null) {
			recLog.setBankCancelAmount(input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.BANK_CANCEL_AMOUNT));
		}
		else{
			recLog.setBankCancelAmount(BigDecimal.ZERO);
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT)
				&& input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT) != null) {
			recLog.setCorporateCancelCount(input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_COUNT));
		}
		else{
			recLog.setCorporateCancelCount(BigDecimal.ZERO);
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_AMOUNT)
				&& input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_AMOUNT) != null) {
			recLog.setCorporateCancelAmount(input.getBigDecimal(TransactionConstants.ReconLogUpdate.Input.CORPORATE_CANCEL_AMOUNT));
		}
		else{
			recLog.setCorporateCancelAmount(BigDecimal.ZERO);
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.SUB_TYPE)) {
			recLog.setSubType(input.getString(TransactionConstants.ReconLogUpdate.Input.SUB_TYPE));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.RECON_DATE)) {
			recLog.setReconDate(input.getString(TransactionConstants.ReconLogUpdate.Input.RECON_DATE));
		}
		if (input.containsKey(TransactionConstants.ReconLogUpdate.Input.RECON_TIME)) {
			recLog.setReconTime(input.getString(TransactionConstants.ReconLogUpdate.Input.RECON_TIME));
		}
		hibernateSession.update(recLog);
		hibernateSession.flush();
		return output;
	}

	@GraymoundService("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION_COUNT")
	public static GMMap getCollectionCountForReconciliation(GMMap input) {
		GMMap outMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		@SuppressWarnings("unchecked")
		List<invoicePayment> bankInvoicePaymentList = session.createCriteria(invoicePayment.class)
				.add(Restrictions.eq("CORPORATE_CODE", input.getString(MapKeys.CORPORATE_CODE)))
				.add(Restrictions.eq("standi ngOrderStatus", PaymentStatuses.Collected)).add(Restrictions.eq("status", true)).list();

		outMap.put(MapKeys.RECON_COLLECTION_COUNT, bankInvoicePaymentList.size());

		@SuppressWarnings("unchecked")
		List<invoicePayment> bankInvoicePaymentCancelList = session.createCriteria(invoicePayment.class)
				.add(Restrictions.eq("CORPORATE_CODE", input.getString(MapKeys.CORPORATE_CODE)))
				.add(Restrictions.eq("standingOrderStatus", PaymentStatuses.Cancelled)).add(Restrictions.eq("status", true)).list();

		outMap.put(MapKeys.RECON_COLLECTION_CANCEL_COUNT, bankInvoicePaymentCancelList.size());

		return outMap;
	}

	@GraymoundService("ICS_COLLECTION_RECONCILIATION_GET_BANK_COLLECTIONS")
	public static GMMap getBankCollectionsForReconciliation(GMMap input) {
		GMMap outMap = new GMMap();
		
		List<String> corporateCodes = new ArrayList<String>();
		if( null != input.getString(MapKeys.CORPORATE_CODE) ){
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			if( corporateCode.contains(",")){
				String [] corporateCodeList = corporateCode.split(",");
				for( String corpCode : corporateCodeList ){
					corporateCodes.add(corpCode);
				}
			}
			else{
				corporateCodes.add(corporateCode);
			}
		}
		
		BigDecimal collectedTotalAmount = new BigDecimal(0);
		BigDecimal cancelledTotalAmount = new BigDecimal(0);
		Session session = DAOSession.getSession("BNSPRDal");
		String paymentDate = input.getString(MapKeys.RECON_DATE);
		String paymentDateStart = paymentDate + "000000";
		String paymentDateFinish = paymentDate + "235959";
		Boolean reconAccToCollType = false;
		int collectionTypeCount = 0;

		if (input.containsKey("RECON_ACCORDING_TO_COLLECTION_TYPE")) {
			if (input.getString("RECON_ACCORDING_TO_COLLECTION_TYPE") != null) {
				if (input.getString("RECON_ACCORDING_TO_COLLECTION_TYPE").equals("YES")) {
					reconAccToCollType = true;
				} else {
					reconAccToCollType = false;
				}
			}
		}

		if (!reconAccToCollType) {
			// mutabakat odeme tipi dikkate alinmadan yapilacaksa

			Criteria bankInvoicePaymentCriteria = session.createCriteria(invoicePayment.class)
					.add(Restrictions.in("corporateCode",corporateCodes))
					.add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected))
					.add(Restrictions.between("paymentDate", paymentDateStart, paymentDateFinish)).add(Restrictions.eq("status", true));
			
			Criteria bankInvoiceCancelPaymentCriteria = session.createCriteria(invoicePayment.class)
					.add(Restrictions.in("corporateCode",corporateCodes))
					.add(Restrictions.eq("paymentStatus", PaymentStatuses.Cancelled))
					.add(Restrictions.between("paymentDate", paymentDateStart, paymentDateFinish)).add(Restrictions.eq("status", true));

			if( input.containsKey(MapKeys.TT_RECON_FLAG) && input.getBoolean(MapKeys.TT_RECON_FLAG) ){
				bankInvoicePaymentCriteria = bankInvoicePaymentCriteria.add(Restrictions.ne("paymentChannel", STANDING_ORDER_PAYMENT_CHANNEL));
			}
			
			
			if( input.containsKey(MapKeys.CHANNEL_CODE) && !StringUtil.isEmpty(input.getString(MapKeys.CHANNEL_CODE)) ){
				bankInvoicePaymentCriteria = bankInvoicePaymentCriteria.add(Restrictions.eq("paymentChannel", input.getString(MapKeys.CHANNEL_CODE)));
				bankInvoiceCancelPaymentCriteria = bankInvoiceCancelPaymentCriteria.add(Restrictions.eq("paymentChannel", input.getString(MapKeys.CHANNEL_CODE)));
			}
			
			@SuppressWarnings("unchecked")
			List<invoicePayment> bankInvoicePaymentList = bankInvoicePaymentCriteria.list();
			
			@SuppressWarnings("unchecked")
			List<invoicePayment> bankInvoicePaymentCancelList = bankInvoiceCancelPaymentCriteria.list();
			
			for (int i = 0; i < bankInvoicePaymentList.size(); i++) {
				invoicePayment invoice = bankInvoicePaymentList.get(i);
				collectedTotalAmount = collectedTotalAmount.add(invoice.getPaymentAmount());
				outMap.put("BANK", i, MapKeys.SUBSCRIBER_NO1, invoice.getSubscriberNo1());
				outMap.put("BANK", i, MapKeys.SUBSCRIBER_NO2, invoice.getSubscriberNo2());
				outMap.put("BANK", i, MapKeys.PAYMENT_DATE, invoice.getPaymentDate());
				outMap.put("BANK", i, MapKeys.PAYMENT_AMOUNT, invoice.getPaymentAmount());
				outMap.put("BANK", i, MapKeys.TRX_NO, invoice.getTxNo());
				outMap.put("BANK", i, MapKeys.INVOICE_NO, invoice.getInvoiceNo());
				outMap.put("BANK", i, MapKeys.CORPORATE_CODE, invoice.getCorporateCode());
				outMap.put("BANK", i, MapKeys.INSTALLMENT_NO, invoice.getInstallmentNo());
				outMap.put("BANK", i, MapKeys.ACCOUNT_BALANCE, invoice.getAccountBalance());

				outMap.put("BANK", i, MapKeys.ACCOUNT_CURRENCY_CODE, invoice.getAccountCurrencyCode());

				outMap.put("BANK", i, MapKeys.CANCEL_DATE, invoice.getCancelDate());

				outMap.put("BANK", i, MapKeys.PARAMETER1, invoice.getParameter1());
				outMap.put("BANK", i, MapKeys.PARAMETER2, invoice.getParameter2());
				outMap.put("BANK", i, MapKeys.PARAMETER3, invoice.getParameter3());
				outMap.put("BANK", i, MapKeys.PARAMETER4, invoice.getParameter4());
				outMap.put("BANK", i, MapKeys.PARAMETER5, invoice.getParameter5());
				outMap.put("BANK", i, MapKeys.PARAMETER6, invoice.getParameter6());
				outMap.put("BANK", i, MapKeys.PARAMETER7, invoice.getParameter7());
				outMap.put("BANK", i, MapKeys.PARAMETER8, invoice.getParameter8());
				outMap.put("BANK", i, MapKeys.PARAMETER9, invoice.getParameter9());
				outMap.put("BANK", i, MapKeys.PARAMETER10, invoice.getParameter10());
				outMap.put("BANK", i, MapKeys.PARAMETER11, invoice.getParameter11());
				outMap.put("BANK", i, MapKeys.PARAMETER12, invoice.getParameter12());
				outMap.put("BANK", i, MapKeys.PARAMETER13, invoice.getParameter13());
				outMap.put("BANK", i, MapKeys.PARAMETER14, invoice.getParameter14());
				outMap.put("BANK", i, MapKeys.PARAMETER15, invoice.getParameter15());
				outMap.put("BANK", i, MapKeys.PARAMETER16, invoice.getParameter16());
				outMap.put("BANK", i, MapKeys.PARAMETER17, invoice.getParameter17());
				outMap.put("BANK", i, MapKeys.PARAMETER18, invoice.getParameter18());
				outMap.put("BANK", i, MapKeys.PARAMETER19, invoice.getParameter19());
				outMap.put("BANK", i, MapKeys.PARAMETER20, invoice.getParameter20());
				outMap.put("BANK", i, MapKeys.PAYMENT_BRANCH, invoice.getPaymentBranch());
				outMap.put("BANK", i, MapKeys.TERM_YEAR, invoice.getTermYear());
				outMap.put("BANK", i, MapKeys.PAYMENT_SOURCE, invoice.getPaymentSource());
				outMap.put("BANK", i, MapKeys.BRANCH_CODE, invoice.getPaymentBranch());
				outMap.put("BANK", i, MapKeys.INVOICE_DUE_DATE, invoice.getInvoiceDueDate());
				outMap.put("BANK", i, MapKeys.STAN_NO, invoice.getStanNo());
				outMap.put("BANK", i, MapKeys.AGENT_CODE, invoice.getAgentCode());
				outMap.put("BANK", i, MapKeys.QUERY_REF_NO, invoice.getQueryRefNo());

			}

			for (int i = 0; i < bankInvoicePaymentCancelList.size(); i++) {
				invoicePayment invoice = bankInvoicePaymentCancelList.get(i);
				cancelledTotalAmount = cancelledTotalAmount.add(invoice.getPaymentAmount());
				outMap.put("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1, invoice.getSubscriberNo1());
				outMap.put("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2, invoice.getSubscriberNo2());
				outMap.put("BANK_CANCEL", i, MapKeys.PAYMENT_AMOUNT, invoice.getPaymentAmount());
				outMap.put("BANK_CANCEL", i, MapKeys.PAYMENT_DATE, invoice.getPaymentDate());
				outMap.put("BANK_CANCEL", i, MapKeys.TRX_NO, invoice.getTxNo());
				outMap.put("BANK_CANCEL", i, MapKeys.INVOICE_NO, invoice.getInvoiceNo());
				outMap.put("BANK_CANCEL", i, MapKeys.CORPORATE_CODE, invoice.getCorporateCode());
				outMap.put("BANK_CANCEL", i, MapKeys.INSTALLMENT_NO, invoice.getInstallmentNo());

				outMap.put("BANK_CANCEL", i, MapKeys.ACCOUNT_CURRENCY_CODE, invoice.getAccountCurrencyCode());

				outMap.put("BANK_CANCEL", i, MapKeys.CANCEL_DATE, invoice.getCancelDate());

				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER1, invoice.getParameter1());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER2, invoice.getParameter2());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER3, invoice.getParameter3());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER4, invoice.getParameter4());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER5, invoice.getParameter5());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER6, invoice.getParameter6());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER7, invoice.getParameter7());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER8, invoice.getParameter8());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER9, invoice.getParameter9());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER10, invoice.getParameter10());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER11, invoice.getParameter11());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER12, invoice.getParameter12());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER13, invoice.getParameter13());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER14, invoice.getParameter14());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER15, invoice.getParameter15());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER16, invoice.getParameter16());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER17, invoice.getParameter17());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER18, invoice.getParameter18());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER19, invoice.getParameter19());
				outMap.put("BANK_CANCEL", i, MapKeys.PARAMETER20, invoice.getParameter20());
				
				outMap.put("BANK_CANCEL", i, MapKeys.PAYMENT_BRANCH, invoice.getPaymentBranch());
				outMap.put("BANK_CANCEL", i, MapKeys.TERM_YEAR, invoice.getTermYear());
				outMap.put("BANK_CANCEL", i, MapKeys.PAYMENT_SOURCE, invoice.getPaymentSource());
				outMap.put("BANK_CANCEL", i, MapKeys.BRANCH_CODE, invoice.getPaymentBranch());
				outMap.put("BANK_CANCEL", i, MapKeys.INVOICE_DUE_DATE, invoice.getInvoiceDueDate());
				outMap.put("BANK_CANCEL", i, MapKeys.STAN_NO, invoice.getStanNo());
				outMap.put("BANK_CANCEL", i, MapKeys.AGENT_CODE, invoice.getAgentCode());
				outMap.put("BANK_CANCEL", i, MapKeys.QUERY_REF_NO, invoice.getQueryRefNo());

			}

			outMap.put(MapKeys.RECON_COLLECTION_TOTAL, collectedTotalAmount);
			outMap.put(MapKeys.RECON_COLLECTION_COUNT, bankInvoicePaymentList.size());
			outMap.put(MapKeys.RECON_COLLECTION_CANCEL_COUNT, bankInvoicePaymentCancelList.size());
			outMap.put(MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelledTotalAmount);
		} else {
			// Mutabakat odeme tipine gore yapilacaksa
			// Kuruma ait odeme tiplerini al
			@SuppressWarnings("unchecked")
			List<CollectionTypeDef> collectionList = session.createCriteria(CollectionTypeDef.class)
					.add(Restrictions.eq("corporateOid", input.getString(MapKeys.CORPORATE_OID))).add(Restrictions.eq("status", true)).list();
			collectionTypeCount = collectionList.size();
			// t�m odeme tipleri icin ayri ayri toplamlar al
			for (int i = 0; i < collectionList.size(); i++) {
				collectedTotalAmount = new BigDecimal(0);
				cancelledTotalAmount = new BigDecimal(0);

				short collectionType = collectionList.get(i).getCollectionType();

				@SuppressWarnings("unchecked")
				List<invoicePayment> bankInvoicePaymentList = session.createCriteria(invoicePayment.class)
						.add(Restrictions.in("corporateCode",corporateCodes))
						.add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected))
						.add(Restrictions.between("paymentDate", paymentDateStart, paymentDateFinish))
						.add(Restrictions.eq("collectionType", collectionType)).add(Restrictions.eq("status", true)).list();

				@SuppressWarnings("unchecked")
				List<invoicePayment> bankInvoicePaymentCancelList = session.createCriteria(invoicePayment.class)
						.add(Restrictions.in("corporateCode",corporateCodes))
						.add(Restrictions.eq("paymentStatus", PaymentStatuses.Cancelled))
						.add(Restrictions.between("paymentDate", paymentDateStart, paymentDateFinish))
						.add(Restrictions.eq("collectionType", collectionType)).add(Restrictions.eq("status", true)).list();

				for (int j = 0; j < bankInvoicePaymentList.size(); j++) {
					invoicePayment invoice = bankInvoicePaymentList.get(j);
					collectedTotalAmount = collectedTotalAmount.add(invoice.getPaymentAmount());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.SUBSCRIBER_NO1, invoice.getSubscriberNo1());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.SUBSCRIBER_NO2, invoice.getSubscriberNo2());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PAYMENT_AMOUNT, invoice.getPaymentAmount());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.TRX_NO, invoice.getTxNo());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.INVOICE_NO, invoice.getInvoiceNo());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.CORPORATE_CODE, invoice.getCorporateCode());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.INSTALLMENT_NO, invoice.getInstallmentNo());

					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.ACCOUNT_CURRENCY_CODE, invoice.getAccountCurrencyCode());

					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.CANCEL_DATE, invoice.getCancelDate());

					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER1, invoice.getParameter1());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER2, invoice.getParameter2());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER3, invoice.getParameter3());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER4, invoice.getParameter4());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER5, invoice.getParameter5());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER6, invoice.getParameter6());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER7, invoice.getParameter7());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER8, invoice.getParameter8());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER9, invoice.getParameter9());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER10, invoice.getParameter10());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER11, invoice.getParameter11());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER12, invoice.getParameter12());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER13, invoice.getParameter13());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER14, invoice.getParameter14());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER15, invoice.getParameter15());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER16, invoice.getParameter16());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER17, invoice.getParameter17());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER18, invoice.getParameter18());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER19, invoice.getParameter19());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PARAMETER20, invoice.getParameter20());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PAYMENT_BRANCH, invoice.getPaymentBranch());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.TERM_YEAR, invoice.getTermYear());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.PAYMENT_SOURCE, invoice.getPaymentSource());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.BRANCH_CODE, invoice.getPaymentBranch());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.INVOICE_DUE_DATE, invoice.getInvoiceDueDate());
					outMap.put(Integer.toString(collectionType).concat("_BANK"), j, MapKeys.STAN_NO, invoice.getStanNo());

				}

				for (int k = 0; k < bankInvoicePaymentCancelList.size(); k++) {
					invoicePayment invoice = bankInvoicePaymentCancelList.get(k);
					cancelledTotalAmount = cancelledTotalAmount.add(invoice.getPaymentAmount());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.SUBSCRIBER_NO1, invoice.getSubscriberNo1());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.SUBSCRIBER_NO2, invoice.getSubscriberNo2());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PAYMENT_AMOUNT, invoice.getPaymentAmount());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.TRX_NO, invoice.getTxNo());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.INVOICE_NO, invoice.getInvoiceNo());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.CORPORATE_CODE, invoice.getCorporateCode());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.INSTALLMENT_NO, invoice.getInstallmentNo());

					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.ACCOUNT_CURRENCY_CODE,
							invoice.getAccountCurrencyCode());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.CANCEL_DATE, invoice.getCancelDate());

					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER1, invoice.getParameter1());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER2, invoice.getParameter2());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER3, invoice.getParameter3());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER4, invoice.getParameter4());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER5, invoice.getParameter5());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER6, invoice.getParameter6());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER7, invoice.getParameter7());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER8, invoice.getParameter8());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER9, invoice.getParameter9());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER10, invoice.getParameter10());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER11, invoice.getParameter11());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER12, invoice.getParameter12());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER13, invoice.getParameter13());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER14, invoice.getParameter14());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER15, invoice.getParameter15());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER16, invoice.getParameter16());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER17, invoice.getParameter17());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER18, invoice.getParameter18());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER19, invoice.getParameter19());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PARAMETER20, invoice.getParameter20());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PAYMENT_BRANCH, invoice.getPaymentBranch());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.TERM_YEAR, invoice.getTermYear());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.PAYMENT_SOURCE, invoice.getPaymentSource());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.BRANCH_CODE, invoice.getPaymentBranch());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.INVOICE_DUE_DATE, invoice.getInvoiceDueDate());
					outMap.put(Integer.toString(collectionType).concat("_BANK_CANCEL"), k, MapKeys.STAN_NO, invoice.getStanNo());
				}

				outMap.put(Integer.toString(collectionType), 0, MapKeys.RECON_COLLECTION_TOTAL, collectedTotalAmount);
				outMap.put(Integer.toString(collectionType), 0, MapKeys.RECON_COLLECTION_COUNT, bankInvoicePaymentList.size());
				outMap.put(Integer.toString(collectionType), 0, MapKeys.RECON_COLLECTION_CANCEL_COUNT, bankInvoicePaymentCancelList.size());
				outMap.put(Integer.toString(collectionType), 0, MapKeys.RECON_COLLECTION_CANCEL_TOTAL, cancelledTotalAmount);
				outMap.put(MapKeys.COLLECTION_TYPE_COUNT, collectionTypeCount);
			}

		}
		return outMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_GET_BANK_STANDING_ORDERS_COLLECTION_RECONCILIATION")
	public static GMMap getStandingOrderBankCollectionsForReconciliation(GMMap input) {
		GMMap outMap = new GMMap();
		
		List<String> corporateCodes = new ArrayList<String>();
		if( null != input.getString(MapKeys.CORPORATE_CODE) ){
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			if( corporateCode.contains(",")){
				String [] corporateCodeList = corporateCode.split(",");
				for( String corpCode : corporateCodeList ){
					corporateCodes.add(corpCode);
				}
			}
			else{
				corporateCodes.add(corporateCode);
			}
		}
		
		Session session = DAOSession.getSession("BNSPRDal");
		String paymentDate = input.getString(MapKeys.RECON_DATE);
		String paymentDateStart = paymentDate + "000000";
		String paymentDateFinish = paymentDate + "235959";
		@SuppressWarnings("unused")
		Criteria cr = null;
		List<icsStandingOrders> standingOrderList = null;
		List<icsStandingOrders> standingOrderCancelList = null;
		List<String> standingOrderIDList = null;

		List<StandingOrderMain> bankStandingOrderList = session.createCriteria(StandingOrderMain.class)
				.add(Restrictions.between("createDate", paymentDateStart, paymentDateFinish))
				.add(Restrictions.eq("standingOrderStatus", StandingOrderStatus.Active)).add(Restrictions.eq("status", true)).list();
		if (bankStandingOrderList.size() > 0) {
			standingOrderIDList = new ArrayList<String>();
			for (StandingOrderMain standingOrderMain : bankStandingOrderList) {
				standingOrderIDList.add(standingOrderMain.getOid());
			}
			standingOrderList = session.createCriteria(icsStandingOrders.class)
					.add(Restrictions.in("corporateCode", corporateCodes))
					.add(Restrictions.in("standingOrderOid", standingOrderIDList))
					.add(Restrictions.eq("standingOrderStatus", StandingOrderStatus.Active)).add(Restrictions.eq("status", true)).list();
			int i = 0;
			for (icsStandingOrders icsStandingOrder : standingOrderList) {
				outMap.put("BANK", i, MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				outMap.put("BANK", i, MapKeys.SUBSCRIBER_NO2, icsStandingOrder.getSubscriberNo2());
				outMap.put("BANK", i, MapKeys.COLLECTION_TYPE, icsStandingOrder.getCollectionType());
				outMap.put("BANK", i, MapKeys.STANDING_ORDER_OID, icsStandingOrder.getStandingOrderOid());
				outMap.put("BANK", i, MapKeys.TRX_NO, icsStandingOrder.getTxNo());
				i++;
			}
		}

		List<StandingOrderMain> bankStandingOrderCancelList = session.createCriteria(StandingOrderMain.class)
				.add(Restrictions.between("cancelDate", paymentDateStart, paymentDateFinish))
				.add(Restrictions.eq("standingOrderStatus", StandingOrderStatus.Canelled)).add(Restrictions.eq("status", true)).list();
		standingOrderIDList = new ArrayList<String>();
		if (bankStandingOrderCancelList.size() > 0) {
			for (StandingOrderMain standingOrderMain : bankStandingOrderCancelList) {
				standingOrderIDList.add(standingOrderMain.getOid());
			}
			standingOrderCancelList = session.createCriteria(icsStandingOrders.class)
					.add(Restrictions.in("corporateCode", corporateCodes))
					.add(Restrictions.in("standingOrderOid", standingOrderIDList))
					.add(Restrictions.eq("standingOrderStatus", StandingOrderStatus.Canelled)).add(Restrictions.eq("status", true)).list();
			int i = 0;
			for (icsStandingOrders icsStandingOrder : standingOrderCancelList) {
				outMap.put("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO1, icsStandingOrder.getSubscriberNo1());
				outMap.put("BANK_CANCEL", i, MapKeys.SUBSCRIBER_NO2, icsStandingOrder.getSubscriberNo2());
				outMap.put("BANK_CANCEL", i, MapKeys.COLLECTION_TYPE, icsStandingOrder.getCollectionType());
				outMap.put("BANK_CANCEL", i, MapKeys.STANDING_ORDER_OID, icsStandingOrder.getStandingOrderOid());
				outMap.put("BANK_CANCEL", i, MapKeys.TRX_NO, icsStandingOrder.getTxNo());
				i++;
			}
		}
		outMap.put(MapKeys.RECON_COLLECTION_COUNT, standingOrderList == null ? 0 : standingOrderList.size());
		outMap.put(MapKeys.RECON_COLLECTION_CANCEL_COUNT, standingOrderCancelList == null ? 0 : standingOrderCancelList.size());

		return outMap;
	}

	@GraymoundService("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION")
	public static GMMap getcancelCollectionForReconciliation(GMMap input) {
		GMMap output = new GMMap();
		
		List<String> corporateCodes = new ArrayList<String>();
		if( null != input.getString(MapKeys.CORPORATE_CODE) ){
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			if( corporateCode.contains(",")){
				String [] corporateCodeList = corporateCode.split(",");
				for( String corpCode : corporateCodeList ){
					corporateCodes.add(corpCode);
				}
			}
			else{
				corporateCodes.add(corporateCode);
			}
		}
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria cr = session.createCriteria(invoicePayment.class);
			cr.add(Restrictions.in("corporateCode", corporateCodes))
					.add(Restrictions.eq("paymentStatus", input.getString(MapKeys.PAYMENT_STATUS))).add(Restrictions.eq("status", true))
					.setMaxResults(1);

			if (!StringUtil.isEmpty(input.getString(MapKeys.SUBSCRIBER_NO1))) {
				cr.add(Restrictions.eq("subscriberNo1", input.getString(MapKeys.SUBSCRIBER_NO1)));
			}

			if (!StringUtil.isEmpty(input.getString(MapKeys.SUBSCRIBER_NO2))) {
				cr.add(Restrictions.eq("subscriberNo2", input.getString(MapKeys.SUBSCRIBER_NO2)));
			}

			if (!StringUtil.isEmpty(input.getString(MapKeys.SUBSCRIBER_NO3))) {
				cr.add(Restrictions.eq("subscriberNo3", input.getString(MapKeys.SUBSCRIBER_NO3)));
			}

			if (!StringUtil.isEmpty(input.getString(MapKeys.SUBSCRIBER_NO4))) {
				cr.add(Restrictions.eq("subscriberNo4", input.getString(MapKeys.SUBSCRIBER_NO4)));
			}

			if (!StringUtil.isEmpty(input.getString(MapKeys.TRX_NO))) {
				cr.add(Restrictions.eq("txNo", input.getBigDecimal(MapKeys.TRX_NO)));
			}

			if (!StringUtil.isEmpty(input.getString(MapKeys.INVOICE_NO))) {
				cr.add(Restrictions.eq("invoiceNo", input.getString(MapKeys.INVOICE_NO)));
			}

			/*
			 * TX nosuz gelen kayitlarda, yukaridaki restrictionlara gore birden
			 * fazla kayit gelebilir(ayni fatura 1den fazla tahsil ve iptal
			 * edilirse). Dolayisiyla son kayit bizim ilgilendigimiz kayit
			 * olmali. Tarihe gore siraliyoruz, yukarida da max resulti 1 e
			 * esitliyoruz.
			 */
			if (DatabaseConstants.PaymentStatuses.Collected.equals(input.getString(MapKeys.PAYMENT_STATUS))) {
				cr.addOrder(Order.desc("paymentDate"));
			} else if (DatabaseConstants.PaymentStatuses.Cancelled.equals(input.getString(MapKeys.PAYMENT_STATUS))) {
				cr.addOrder(Order.desc("cancelDate"));
			}

			invoicePayment bankInvoicePayment = (invoicePayment) cr.uniqueResult();
			if (bankInvoicePayment != null) {
				output.put(MapKeys.SUBSCRIBER_NO1, bankInvoicePayment.getSubscriberNo1());
				output.put(MapKeys.SUBSCRIBER_NO2, bankInvoicePayment.getSubscriberNo2());
				output.put(MapKeys.SUBSCRIBER_NO3, bankInvoicePayment.getSubscriberNo3());
				output.put(MapKeys.SUBSCRIBER_NO4, bankInvoicePayment.getSubscriberNo4());
				output.put(MapKeys.SUBSCRIBER_NAME, bankInvoicePayment.getSubscriberName());
				output.put(MapKeys.PAYMENT_DATE, bankInvoicePayment.getPaymentDate());
				output.put(MapKeys.TRX_NO, bankInvoicePayment.getTxNo());
				output.put(MapKeys.INVOICE_NO, bankInvoicePayment.getInvoiceNo());
				output.put(MapKeys.PARAMETER1, bankInvoicePayment.getParameter1());
				output.put(MapKeys.PARAMETER2, bankInvoicePayment.getParameter2());
				output.put(MapKeys.PARAMETER3, bankInvoicePayment.getParameter3());
				output.put(MapKeys.PARAMETER4, bankInvoicePayment.getParameter4());
				output.put(MapKeys.PARAMETER5, bankInvoicePayment.getParameter5());
				output.put(MapKeys.PARAMETER6, bankInvoicePayment.getParameter6());
				output.put(MapKeys.PARAMETER7, bankInvoicePayment.getParameter7());
				output.put(MapKeys.PARAMETER8, bankInvoicePayment.getParameter8());
				output.put(MapKeys.PARAMETER9, bankInvoicePayment.getParameter9());
				output.put(MapKeys.PARAMETER10, bankInvoicePayment.getParameter10());
				output.put(MapKeys.PARAMETER11, bankInvoicePayment.getParameter11());
				output.put(MapKeys.PARAMETER12, bankInvoicePayment.getParameter12());
				output.put(MapKeys.PARAMETER13, bankInvoicePayment.getParameter13());
				output.put(MapKeys.PARAMETER14, bankInvoicePayment.getParameter14());
				output.put(MapKeys.PARAMETER15, bankInvoicePayment.getParameter15());
				output.put(MapKeys.PARAMETER16, bankInvoicePayment.getParameter16());
				output.put(MapKeys.PARAMETER17, bankInvoicePayment.getParameter17());
				output.put(MapKeys.PARAMETER18, bankInvoicePayment.getParameter18());
				output.put(MapKeys.PARAMETER19, bankInvoicePayment.getParameter19());
				output.put(MapKeys.PARAMETER20, bankInvoicePayment.getParameter20());
				output.put(MapKeys.COLLECTION_TYPE, bankInvoicePayment.getCollectionType());
				output.put(MapKeys.SOURCE, bankInvoicePayment.getPaymentSource());
				output.put(MapKeys.CORPORATE_PAYMENT_ID, bankInvoicePayment.getCorporatePaymentId());
				output.put(MapKeys.INVOICE_AMOUNT, bankInvoicePayment.getInvoiceAmount());
				output.put(MapKeys.PAYMENT_AMOUNT, bankInvoicePayment.getPaymentAmount());
				output.put(MapKeys.INSTALLMENT_NO, bankInvoicePayment.getInstallmentNo());
				output.put(MapKeys.INVOICE_DUE_DATE, bankInvoicePayment.getInvoiceDueDate());
				output.put(MapKeys.CANCEL_DATE, bankInvoicePayment.getCancelDate());
				output.put(MapKeys.STAN_NO, bankInvoicePayment.getStanNo());
				output.put(MapKeys.CORPORATE_CODE, bankInvoicePayment.getCorporateCode());
				output.put(MapKeys.TERM_MONTH, bankInvoicePayment.getTermMonth());
				output.put(MapKeys.TERM_YEAR, bankInvoicePayment.getTermYear());
				output.put(MapKeys.RESPONSE_CODE, 0);
			} else {
				throw new Exception("No record found for input map : " + input.toString());
			}
		} catch (Exception e) {
			logger.error("An exception occured while getting collection for the input map : " + input.toString());
			logger.error(System.currentTimeMillis(), e);
			output.put(MapKeys.RESPONSE_CODE, 1);
		}

		return output;

	}

	@GraymoundService("ICS_RECON_RESUBMIT")
	public static GMMap reconResubmit(GMMap input) {
		GMMap outMap = new GMMap();
		try {
			String corporateCode = input.getString(ReconciliationResubmit.Input.CORPORATE_CODE);
			String date = input.getString(ReconciliationResubmit.Input.DATE);
			byte reconType = Byte.valueOf(input.getString(ReconciliationResubmit.Input.RECON_TYPE));
			String findDifferences = input.getString(ReconciliationResubmit.Input.FIND_DIFFERENCES);
			String reconClose = input.getString(ReconciliationResubmit.Input.RECON_CLOSE);
			String resubmitType = "0";
			if (findDifferences.equals("true")) {
				resubmitType = DatabaseConstants.ReconciliationResubmitType.FindDifferences;
			} else if (reconClose.equals("true")) {
				resubmitType = DatabaseConstants.ReconciliationResubmitType.ReconciliationClose;
			}
			// vergi tahsilat mutabakat
			if(input.getString(TaxReconciliationBatch.Input.SECTOR_NAME).equalsIgnoreCase(input.getString(TaxReconciliationBatch.Input.TAX_DEFAULT_SECTOR_VALUE))){
				GMMap reconCallInputMap = new GMMap();
				reconCallInputMap.put(TaxReconciliationBatch.Input.PROCESS_DATE, date);
				reconCallInputMap.put("BATCH_NAME", "Tahsilat Mutabakat");
				reconCallInputMap.put(StandingOrderReconciliationBatch.Input.RESUBMIT_TYPE, resubmitType);

				GMMap batchRemoteSubmitRequest = new GMMap();
				batchRemoteSubmitRequest.put("INPUT_MAP", reconCallInputMap);
				batchRemoteSubmitRequest.put("BATCH_SERVICE_NAME", TaxReconciliationBatch.SERVICE_NAME);

				CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CDM_EXECUTE_ASYNC_BATCH_SUBMIT",
						batchRemoteSubmitRequest);
				// mutabakat tipi talimat ise
			}else if (reconType == DatabaseConstants.ReconciliationTypes.StandingOrder) {
				GMMap reconCallInputMap = new GMMap();
				reconCallInputMap.put(StandingOrderReconciliationBatch.Input.SCREEN_RECONCILIATION, "1");
				reconCallInputMap.put(StandingOrderReconciliationBatch.Input.CORPORATE_CODE, corporateCode);
				reconCallInputMap.put(StandingOrderReconciliationBatch.Input.PROCESS_DATE, date);
				reconCallInputMap.put(StandingOrderReconciliationBatch.Input.RESUBMIT_TYPE, resubmitType);
				reconCallInputMap.put("BATCH_NAME", "Talimat Mutabakat");

				GMMap batchRemoteSubmitRequest = new GMMap();
				batchRemoteSubmitRequest.put("INPUT_MAP", reconCallInputMap);
				batchRemoteSubmitRequest.put("BATCH_SERVICE_NAME", StandingOrderReconciliationBatch.SERVICE_NAME);
				
//				CommonHelper.callGraymoundServiceInHibernateSession("STO_STANDING_ORDER_RECONCILIATION", reconCallInputMap);

				CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CDM_EXECUTE_ASYNC_BATCH_SUBMIT",
						batchRemoteSubmitRequest);
				
			} else if (reconType == DatabaseConstants.ReconciliationTypes.Collection) {
				// mutabakat tipi tahsilat ise
				GMMap reconCallInputMap = new GMMap();
				reconCallInputMap.put(CollectionReconciliationBatch.Input.SCREEN_RECONCILIATION, "1");
				reconCallInputMap.put(CollectionReconciliationBatch.Input.CORPORATE_CODE, corporateCode);
				reconCallInputMap.put(CollectionReconciliationBatch.Input.RECON_DATE, date);
				reconCallInputMap.put(CollectionReconciliationBatch.Input.RESUBMIT_TYPE, resubmitType);
				reconCallInputMap.put("BATCH_NAME", "Tahsilat Mutabakat");
				
				GMMap batchRemoteSubmitRequest = new GMMap();
				batchRemoteSubmitRequest.put("INPUT_MAP", reconCallInputMap);
				batchRemoteSubmitRequest.put("BATCH_SERVICE_NAME", CollectionReconciliationBatch.SERVICE_NAME);
				
//				CommonHelper.callGraymoundServiceInHibernateSession("ICS_COLLECTION_RECONCILIATION", reconCallInputMap);
				
				CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CDM_EXECUTE_ASYNC_BATCH_SUBMIT",
						batchRemoteSubmitRequest);

			} else if (reconType == DatabaseConstants.ReconciliationTypes.MoneyLoad) {
				// TL yukleme tipi tahsilat ise
				GMMap reconCallInputMap = new GMMap();
				reconCallInputMap.put(MoneyLoadReconciliationBatch.Input.SCREEN_RECONCILIATION, "1");
				reconCallInputMap.put(MoneyLoadReconciliationBatch.Input.CORPORATE_CODE, corporateCode);
				reconCallInputMap.put(MoneyLoadReconciliationBatch.Input.RECON_DATE, date);
				reconCallInputMap.put(MoneyLoadReconciliationBatch.Input.RESUBMIT_TYPE, resubmitType);
				reconCallInputMap.put("BATCH_NAME", "TL Y�kleme Mutabakat");
				
				GMMap batchRemoteSubmitRequest = new GMMap();
				batchRemoteSubmitRequest.put("INPUT_MAP", reconCallInputMap);
				batchRemoteSubmitRequest.put("BATCH_SERVICE_NAME", MoneyLoadReconciliationBatch.SERVICE_NAME);
				
				CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.JOB_CONNECTION_NAME, "CDM_EXECUTE_ASYNC_BATCH_SUBMIT",
						batchRemoteSubmitRequest);
			}
			
			outMap.put("MESSAGE", "s");
		} catch (Exception e) {
			ExceptionHandler.convertException(e);
			outMap.put("MESSAGE", "f");
		}
		return outMap;
	}
	
	@GraymoundService("ICS_CLOSE_RECONCILIATION_MANUALLY")
	public static GMMap closeReconManually(GMMap input) {
		GMMap output = new GMMap();
		
		try{
			Date reconDate = input.getDate("DATE");
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			
			GMMap reconCloseInMap = new GMMap();
			reconCloseInMap.put(MapKeys.RECON_DATE, reconDate);
			reconCloseInMap.put(MapKeys.CORPORATE_CODE, corporateCode);
			reconCloseInMap.put(MapKeys.PROCESS_DATE, new Date());
			reconCloseInMap.put(MapKeys.GM_SERVICE_NAME, "ICS_CLOSE_RECONCILIATION_MANUALLY");
			reconCloseInMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
			reconCloseInMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
			output = CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", reconCloseInMap);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

	@GraymoundService("ICS_STANDING_ORDER_NOTIFY_LOG_INSERT")
	public static GMMap standingOrderNotifyLogInsert(GMMap input) {

		GMMap output = new GMMap();
		try {
			Session session = CommonHelper.getHibernateSession();
			boolean isUpdate = input.getBoolean(TransactionConstants.StandingOrderNotifyProcesLog.Input.IS_UPDATE, false);
			StandingOrderNtfyPrcesslog standingOrderNotifyProcessLog;
			if (isUpdate) {
				Criteria crit = session.createCriteria(StandingOrderNtfyPrcesslog.class).add(
						Restrictions.eq("oid",
								input.getString(TransactionConstants.StandingOrderNotifyProcesLog.Output.STANDING_ORDER_NOTIFY_PROCESS_LOG_OID)));
				standingOrderNotifyProcessLog = (StandingOrderNtfyPrcesslog) crit.uniqueResult();
			} else {
				standingOrderNotifyProcessLog = new StandingOrderNtfyPrcesslog();
			}

			// get parameters
			boolean status = ((input.containsKey(TransactionConstants.StandingOrderNotifyProcesLog.Input.STATUS) ? input
					.getBoolean(TransactionConstants.StandingOrderNotifyProcesLog.Input.STATUS) : null));
			String invoiceMainOid = ((input.containsKey(TransactionConstants.StandingOrderNotifyProcesLog.Input.INVOICE_MAIN_OID) ? input
					.getString(TransactionConstants.StandingOrderNotifyProcesLog.Input.INVOICE_MAIN_OID) : null));
			String standingOrderCommOid = ((input.containsKey(TransactionConstants.StandingOrderNotifyProcesLog.Input.STANDING_ORDER_COMM_OID) ? input
					.getString(TransactionConstants.StandingOrderNotifyProcesLog.Input.STANDING_ORDER_COMM_OID) : null));
			String standingOrderOid = ((input.containsKey(TransactionConstants.StandingOrderNotifyProcesLog.Input.STANDING_ORDER_OID) ? input
					.getString(TransactionConstants.StandingOrderNotifyProcesLog.Input.STANDING_ORDER_OID) : null));
			String errorCode = ((input.containsKey(TransactionConstants.StandingOrderNotifyProcesLog.Input.ERROR_CODE) ? input
					.getString(TransactionConstants.StandingOrderNotifyProcesLog.Input.ERROR_CODE) : null));
			String errorDescString = input.getString(TransactionConstants.StandingOrderNotifyProcesLog.Input.ERROR_DESC);
			Clob errorDesc = new ClobImpl(errorDescString);
			String processStatus = ((input.containsKey(TransactionConstants.StandingOrderNotifyProcesLog.Input.PROCESS_STATUS) ? input
					.getString(TransactionConstants.StandingOrderNotifyProcesLog.Input.PROCESS_STATUS) : null));
			String processDate = ((input.containsKey(TransactionConstants.StandingOrderNotifyProcesLog.Input.PROCESS_DATE) ? input
					.getString(TransactionConstants.StandingOrderNotifyProcesLog.Input.PROCESS_DATE) : null));
			String paymentStatus = ((input.containsKey(TransactionConstants.StandingOrderNotifyProcesLog.Input.PAYMENT_STATUS) ? input
					.getString(TransactionConstants.StandingOrderNotifyProcesLog.Input.PAYMENT_STATUS) : null));

			// set values
			standingOrderNotifyProcessLog.setErrorCode(errorCode);
			standingOrderNotifyProcessLog.setErrorDesc(errorDesc);
			standingOrderNotifyProcessLog.setInvoiceMainOid(invoiceMainOid);
			standingOrderNotifyProcessLog.setProcessDate(processDate);
			standingOrderNotifyProcessLog.setProcessStatus(processStatus);
			standingOrderNotifyProcessLog.setStandingOrderCommOid(standingOrderCommOid);
			standingOrderNotifyProcessLog.setStandingOrderOid(standingOrderOid);
			standingOrderNotifyProcessLog.setStatus(status);
			standingOrderNotifyProcessLog.setPaymentStatus(paymentStatus);

			if (isUpdate) {
				session.update(standingOrderNotifyProcessLog);
			} else {
				session.save(standingOrderNotifyProcessLog);
				session.flush();
			}
			output.put(TransactionConstants.StandingOrderNotifyProcesLog.Output.STANDING_ORDER_NOTIFY_PROCESS_LOG_OID,
					standingOrderNotifyProcessLog.getOid());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return output;
	}
	
	@GraymoundService("ICS_DO_CHANNEL_RECONCILIATION")
	public static GMMap doChannelReconciliation(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			String channelCode = CommonHelper.getChannelId();
			String reconDate = input.getString(MapKeys.RECON_DATE);
			int channelPaymentCount = input.getInt("PAYMENT_COUNT");
			BigDecimal channelPaymentAmount = input.getBigDecimal("PAYMENT_AMOUNT");
			int channelCancelCount = input.getInt("CANCEL_COUNT");
			BigDecimal channelCancelAmount = input.getBigDecimal("CANCEL_AMOUNT");
			
			int bankPaymentCount = getReconInfo(session, channelCode, reconDate, DatabaseConstants.PaymentStatuses.Collected, Projections.rowCount()).intValue();
			Number pAmount = getReconInfo(session, channelCode, reconDate, DatabaseConstants.PaymentStatuses.Collected, Projections.sum("paymentAmount"));
			BigDecimal bankPaymentAmount = BigDecimal.ZERO;
			if(pAmount != null){
				bankPaymentAmount = new BigDecimal(pAmount.doubleValue()).setScale(2, RoundingMode.HALF_UP);
			}
			
			int bankCancelCount = getReconInfo(session, channelCode, reconDate, DatabaseConstants.PaymentStatuses.Cancelled, Projections.rowCount()).intValue();
			Number cAmount = getReconInfo(session, channelCode, reconDate, DatabaseConstants.PaymentStatuses.Cancelled, Projections.sum("paymentAmount"));
			BigDecimal bankCancelAmount = BigDecimal.ZERO;
			if(cAmount != null){
				bankCancelAmount = new BigDecimal(cAmount.doubleValue()).setScale(2, RoundingMode.HALF_UP);
			}
			
			if(bankPaymentCount == channelPaymentCount && bankPaymentAmount.compareTo(channelPaymentAmount) == 0 
					&& bankCancelCount == channelCancelCount && bankCancelAmount.compareTo(channelCancelAmount) == 0){
				output.put("RECON_RESULT", "1");
			}
			else{
				output.put("RECON_RESULT", "0");
			}
			
			output.put("PAYMENT_COUNT", bankPaymentCount);
			output.put("PAYMENT_AMOUNT", bankPaymentAmount);
			output.put("CANCEL_COUNT", bankCancelCount);
			output.put("CANCEL_AMOUNT", bankCancelAmount);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_COLLECTION_RECONCILIATION_GET_COLLECTION_SUMMARY")
	public static GMMap getCollectionForReconciliationSummary(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			String channelCode = CommonHelper.getChannelId();
			String reconDate = input.getString(MapKeys.RECON_DATE);
			String corporateCode = input.getString(MapKeys.CORPORATE_CODE);
			
			int bankPaymentCount = getReconInfoCorporate(session, channelCode, reconDate, DatabaseConstants.PaymentStatuses.Collected, corporateCode, Projections.rowCount()).intValue();
			Number pAmount = getReconInfoCorporate(session, channelCode, reconDate, DatabaseConstants.PaymentStatuses.Collected, corporateCode, Projections.sum("paymentAmount"));
			BigDecimal bankPaymentAmount = BigDecimal.ZERO;
			if(pAmount != null){
				bankPaymentAmount = new BigDecimal(pAmount.doubleValue()).setScale(2, RoundingMode.HALF_UP);
			}
			
			int bankCancelCount = getReconInfoCorporate(session, channelCode, reconDate, DatabaseConstants.PaymentStatuses.Cancelled, corporateCode, Projections.rowCount()).intValue();
			Number cAmount = getReconInfoCorporate(session, channelCode, reconDate, DatabaseConstants.PaymentStatuses.Cancelled, corporateCode, Projections.sum("paymentAmount"));
			BigDecimal bankCancelAmount = BigDecimal.ZERO;
			if(cAmount != null){
				bankCancelAmount = new BigDecimal(cAmount.doubleValue()).setScale(2, RoundingMode.HALF_UP);
			}
		
			
			output.put("RECON_COLLECTION_COUNT", bankPaymentCount);
			output.put("RECON_COLLECTION_TOTAL", bankPaymentAmount);
			output.put("RECON_COLLECTION_CANCEL_COUNT", bankCancelCount);
			output.put("RECON_COLLECTION_CANCEL_TOTAL", bankCancelAmount);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	private static Number getReconInfo(Session session, String channelCode, String reconDate, String paymentStatus, Projection projection) {
		return (Number) session.createCriteria(invoicePayment.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("paymentChannel", channelCode))
				.add(Restrictions.like("paymentDate", reconDate, MatchMode.START))
				.add(Restrictions.eq("paymentStatus", paymentStatus))
				.setProjection(projection)
				.uniqueResult();
	}
	
	private static Number getReconInfoCorporate(Session session, String channelCode, String reconDate, String paymentStatus, String corporateCode, Projection projection) {
		return (Number) session.createCriteria(invoicePayment.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("paymentChannel", channelCode))
				.add(Restrictions.like("paymentDate", reconDate, MatchMode.START))
				.add(Restrictions.eq("paymentStatus", paymentStatus))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.setProjection(projection)
				.uniqueResult();
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_DO_CHANNEL_RECONCILIATION_DETAIL")
	public static GMMap doChannelReconciliationDetail(GMMap input){
		GMMap output = new GMMap();
		final int MAX_NUMBER_OF_RESULTS = 10000;
		final String TRANSACTION_LIST = "TRANSACTION_LIST";
		final String CORPORATE_CODE_LIST = "CORPORATE_CODE_LIST";
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			String channelCode = CommonHelper.getChannelId();
			String reconDate = input.getString(MapKeys.RECON_DATE);
			int pageNumber = input.getInt("PAGE_NUMBER");
			
			List<invoicePayment> paymentList = session.createCriteria(invoicePayment.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.in("paymentStatus", Arrays.asList(DatabaseConstants.PaymentStatuses.Collected, DatabaseConstants.PaymentStatuses.Cancelled)))
					.add(Restrictions.like("paymentDate", reconDate, MatchMode.START))
					.add(Restrictions.eq("paymentChannel", channelCode))
					.addOrder(Order.asc("paymentDate"))
					.setFirstResult(pageNumber * MAX_NUMBER_OF_RESULTS)
					.setMaxResults(MAX_NUMBER_OF_RESULTS)
					.list();
			
			GMMap corporateCodeMappingResults = DALUtil.getResults("SELECT corporate_code,oid FROM cdm.corporate_master WHERE status=1 and corporate_activeness='A'", CORPORATE_CODE_LIST);
			
			Map<String, String> codeOidMapping = new HashMap<String, String>();
			
			for (int i = 0; i < corporateCodeMappingResults.getSize(CORPORATE_CODE_LIST); i++) {
				codeOidMapping.put(corporateCodeMappingResults.getString(CORPORATE_CODE_LIST, i, MapKeys.CORPORATE_CODE), 
						corporateCodeMappingResults.getString(CORPORATE_CODE_LIST, i, "OID").concat("|~|KFT_CORPORATE_OID"));
			}
			
			int counter = 0;
			for (invoicePayment payment : paymentList) {
				output.put(TRANSACTION_LIST, counter, "CORPORATE_OID", codeOidMapping.get(payment.getCorporateCode()));
				output.put(TRANSACTION_LIST, counter, MapKeys.SUBSCRIBER_NO1, payment.getSubscriberNo1());
				if(!StringUtil.isEmpty(payment.getSubscriberNo2())){
					output.put(TRANSACTION_LIST, counter, MapKeys.SUBSCRIBER_NO2, payment.getSubscriberNo2());
				}
				if(!StringUtil.isEmpty(payment.getSubscriberNo3())){
					output.put(TRANSACTION_LIST, counter, MapKeys.SUBSCRIBER_NO3, payment.getSubscriberNo3());
				}
				if(!StringUtil.isEmpty(payment.getSubscriberNo4())){
					output.put(TRANSACTION_LIST, counter, MapKeys.SUBSCRIBER_NO4, payment.getSubscriberNo4());
				}
				output.put(TRANSACTION_LIST, counter, "QUERY_REFERENCE_ID", payment.getQueryRefNo());
				output.put(TRANSACTION_LIST, counter, "TRX_REFERENCE_ID", payment.getTxNo());
				output.put(TRANSACTION_LIST, counter, "INVOICE_NO", payment.getInvoiceNo());
				output.put(TRANSACTION_LIST, counter, "AMOUNT", payment.getPaymentAmount());
				output.put(TRANSACTION_LIST, counter, "PAYMENT_STATUS", payment.getPaymentStatus());
				counter++;
			}
			
			output.put("RECORD_COUNT", paymentList.size());
			output.put("MAX_RECORD_COUNT", MAX_NUMBER_OF_RESULTS);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}
