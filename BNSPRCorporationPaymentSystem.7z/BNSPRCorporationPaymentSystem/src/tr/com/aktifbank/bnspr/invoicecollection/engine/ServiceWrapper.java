package tr.com.aktifbank.bnspr.invoicecollection.engine;


import java.awt.Color;
import java.io.BufferedReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Clob;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.axis.utils.StringUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.cps.common.BankDate;
import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cps.common.BusinessException;
import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.DatabaseConstants.PaymentStatuses;
import tr.com.aktifbank.bnspr.cps.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.cps.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.transactions.CancelInvoicePaymentHandler;
import tr.com.aktifbank.bnspr.cps.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.transactions.DailyPaymentTransactionReportHandler;
import tr.com.aktifbank.bnspr.cps.transactions.DoInvoiceCollectionHandler;
import tr.com.aktifbank.bnspr.cps.transactions.GetPaymentsByCustomerNumberHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InsertInvoicePaymentLogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.MonthlyPaymentTransactionReportHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cps.transactions.RollbackInvoicePaymentLogHandler;
import tr.com.aktifbank.bnspr.cps.transactions.TransferCorporateBalanceHandler;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.ChannelSourceDef;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.CorporateServices;
import tr.com.aktifbank.bnspr.dao.StandingOrderBacklog;
import tr.com.aktifbank.bnspr.dao.WebServices;
import tr.com.aktifbank.bnspr.dao.WsSaf;
import tr.com.aktifbank.bnspr.dao.invoiceCommission;
import tr.com.aktifbank.bnspr.dao.invoiceMain;
import tr.com.aktifbank.bnspr.dao.invoicePayment;
import tr.com.aktifbank.bnspr.dao.invoicePaymentLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ServiceWrapper {
	private static final Log logger = LogFactory.getLog(ServiceWrapper.class);
	public static final String SAF_STATUS_PRM="CDM_SAF_STATUS";
	public static final String SAF_STATUS_NEW="Yeni Kay�t";
	public static final int WS_NOT_FOUND_ERROR_CODE=2800;
	public static final int NEGATIVE_VALUE = -1;
	private static final String DEFAULT_CHANNEL = "1";
	//private static final String INTERNET_BANKING_CHANNEL = "10";
	
	@SuppressWarnings("unchecked")
	@GraymoundService("ICS_ONLINE_SERVICE_CALL")
	public static GMMap onlineServicecall( GMMap iMap) {
		GMMap outMap = new GMMap();	
		try {
			outMap.put(MapKeys.ERROR_CODE, GeneralConstants.ERROR_CODE_APPROVE);
			Session hibernateSession = CommonHelper.getHibernateSession();
			Criteria criteria = hibernateSession.createCriteria(CorporateServices.class);
			Criterion status = Restrictions.eq("status", true);
			Criterion corporateCode = Restrictions.eq("corporateCode", iMap.getString(MapKeys.CORPORATE_CODE));
			Criterion gmServiceName = Restrictions.eq("gmServiceName", iMap.getString(MapKeys.GM_SERVICE_NAME));// wrapper dan gelecek 
			criteria.add(status).add(corporateCode).add(gmServiceName);
			
			List<CorporateServices> serviceList = (List<CorporateServices>)criteria.list();
		
			if ((serviceList.size() > 1 || serviceList.size()== 0) && iMap.getBoolean(MapKeys.IS_MANDATORY_SERVICE)) {
				CommonHelper.throwBusinessException(WS_NOT_FOUND_ERROR_CODE);
			}else if(iMap.getBoolean(MapKeys.IS_MANDATORY_SERVICE)){
				
				iMap.put("WS_SERVICE_NAME", serviceList.get(0).getWebServiceName());
				
				Criteria criteriaWs = hibernateSession.createCriteria(WebServices.class);
				Criterion statusWS = Restrictions.eq("status", true);
				Criterion corporateCodeWS = Restrictions.eq("corporateCode", iMap.getString(MapKeys.CORPORATE_CODE));
				Criterion webServiceName = Restrictions.eq("serviceName", serviceList.get(0).getWebServiceName());// wrapper dan// gelecek
				criteriaWs.add(statusWS).add(corporateCodeWS).add(webServiceName);
				
				List<WebServices> wsServiceList = criteriaWs.list();
				if (wsServiceList.size() > 0) {
					int wsServiceListSize = wsServiceList.size();
					for (int i=0;i<wsServiceListSize;i++){
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.WS_PASSWORD, wsServiceList.get(i).getWsPassword());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.WS_ENDPOINT, wsServiceList.get(i).getWsEndPoint());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.WS_USER, wsServiceList.get(i).getWsUser());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.SERVICE_OID, wsServiceList.get(i).getOid());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER1, wsServiceList.get(i).getParameter1());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER2, wsServiceList.get(i).getParameter2());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER3, wsServiceList.get(i).getParameter3());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER4, wsServiceList.get(i).getParameter4());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER5, wsServiceList.get(i).getParameter5());
						iMap.put(MapKeys.WS_PARAMETERS, i, MapKeys.PARAMETER6, wsServiceList.get(i).getParameter6());
					}
					
				}
				
				boolean isReconciliationCall = iMap.containsKey(MapKeys.RECON_CALL)?iMap.getBoolean(MapKeys.RECON_CALL):false;
				boolean returnServiceMap = iMap.containsKey("RETURN_SERVICE_MAP")?iMap.getBoolean("RETURN_SERVICE_MAP"):false;
				
				if (!isReconciliationCall &&
					serviceList.get(0).getIsSafService().equals("1")) {
					iMap.put("IS_SAF_CALL", true);
				
					WsSaf wsSaf = new WsSaf();
					String firstSendDate = CommonHelper.getLongDateTimeString(new Date());
					wsSaf.setFirstSendDate(Long.parseLong(firstSendDate));
					wsSaf.setNextSendDate(0);
					wsSaf.setFirstSendUser(CommonHelper.getCurrentUser());
					wsSaf.setGmServiceName(serviceList.get(0).getGmServiceName());
					Clob parameters =new ClobImpl(CommonHelper.serializeRequest(iMap));
					Clob parametersString =new ClobImpl(iMap.toString());
					wsSaf.setParameters(parameters);
					wsSaf.setParametersString(parametersString);
					wsSaf.setSubscriberNo1(iMap.getString(MapKeys.SUBSCRIBER_NO1));
					wsSaf.setSubscriberNo2(iMap.getString(MapKeys.SUBSCRIBER_NO2));
					wsSaf.setSubscriberNo3(iMap.getString(MapKeys.SUBSCRIBER_NO3));
					wsSaf.setSubscriberNo4(iMap.getString(MapKeys.SUBSCRIBER_NO4));
					String sendStatus = CommonHelper.getNameOfParameter(SAF_STATUS_PRM, SAF_STATUS_NEW);
					wsSaf.setSendStatus(sendStatus);
					wsSaf.setStatus(true);
					wsSaf.setWebServiceName(serviceList.get(0).getWebServiceName());
					wsSaf.setTryCount((short) 10);
					wsSaf.setCorporateCode(iMap.getString(MapKeys.CORPORATE_CODE));
					wsSaf.setRunning((byte)0);
					wsSaf.setPriority((byte)0);
					String waitTime = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", iMap.getString(MapKeys.CORPORATE_CODE).concat("_WAIT_TIME"));
					if(!StringUtil.isEmpty(waitTime)){
						wsSaf.setWaitTime(Long.valueOf(waitTime));
					}
					hibernateSession.save(wsSaf);
					hibernateSession.flush();
				}else {
					outMap = GMServiceExecuter.call(serviceList.get(0).getWebServiceName(), iMap);
					if (!returnServiceMap && outMap.getString(MapKeys.ERROR_CODE) != null) {
						if (!outMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.ERROR_CODE_APPROVE)) {
							if(outMap.getString(MapKeys.ERROR_CODE).equals(GeneralConstants.CORPORATE_REMOTE_SERVICE_ERROR_CODE)){
								String corporateName = CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(iMap.getString(MapKeys.CORPORATE_CODE));
								String errorMessage = String.format("%s kurumu kaynakl� bir problem ya�anmaktad�r. L�tfen bir s�re sonra tekrar deneyiniz.", corporateName);
								CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, errorMessage);
							}
							else{
								int errorCode = outMap.getInt(MapKeys.ERROR_CODE);
								int size = outMap.getSize(MapKeys.ERROR_PARAMETERS_TABLE);
								if(size == 0){
									CommonHelper.throwBusinessException(errorCode);
								}
								else if(size == 1){
									CommonHelper.throwBusinessException(errorCode, outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM));
								}
								else if(size == 2){
									CommonHelper.throwBusinessException(errorCode, outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM),
											outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 1, MapKeys.ERROR_PARAM));
								}
								else if(size == 3){
									CommonHelper.throwBusinessException(errorCode, outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM),
											outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 1, MapKeys.ERROR_PARAM),
											outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 2, MapKeys.ERROR_PARAM));
								}
								else if(size == 4){
									CommonHelper.throwBusinessException(errorCode, outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 0, MapKeys.ERROR_PARAM),
											outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 1, MapKeys.ERROR_PARAM),
											outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 2, MapKeys.ERROR_PARAM),
											outMap.getString(MapKeys.ERROR_PARAMETERS_TABLE, 3, MapKeys.ERROR_PARAM));
								}
								else{
									CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, 
											String.format("%s kodlu hata mesaj�na en fazla 4 parametre ge�ilebilir. Ge�ilen parametre say�s� : %s", errorCode, size));
								}
							}
						}
					}			
				}
				
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return outMap;
	}
	
	@GraymoundService("ICS_SEARCH_INVOICE")
	public static GMMap searchInvoices(GMMap iMap){
		GMMap outMap = new GMMap();
		final String INVOICES = "INVOICES";
		final String SEARCHED_RESULTS = "SEARCHED_RESULTS";
		final String PROPERTIES = "PROPERTIES";
		try{
			int foundInvoiceCount = 0;
			
			String subscriberNo1 = iMap.getString("SUBSCRIBER_NO1");
			String subscriberNo2 = iMap.getString("SUBSCRIBER_NO2");
			String subscriberNo3 = iMap.getString("SUBSCRIBER_NO3");
			String subscriberNo4 = iMap.getString("SUBSCRIBER_NO4");
			String channelCode = iMap.getString("CHANNEL_CODE",null);
	
			Short collectionType = Short.parseShort(iMap.getString("COLLECTION_TYPE", String.valueOf(GeneralConstants.COLLECTION_TYPE_NOT_MENTIONED)));
			String corporateCode = iMap.getString("CORPORATE_CODE", null);
			
			GMMap corpMap = new GMMap();
			corpMap = CommonHelper.callGraymoundServiceInHibernateSession("CDM_GET_CORPORATE_DEFINITION", iMap);
			if (StringUtil.isEmpty(corporateCode)) {
				corporateCode = corpMap.getString(MapKeys.CORPORATE_CODE);
			}
			
			if ("".equals(subscriberNo1)&&"".equals(subscriberNo2)&&"".equals(subscriberNo3)&&"".equals(subscriberNo4)) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Abone No"));
			
			Session hibernateSession = CommonHelper.getHibernateSession();
			if (StringUtil.isEmpty(channelCode)) {
				channelCode = CommonHelper.getChannelId();
			}	
//			GnlKanalGrupKodPr codeChannelBranch=(GnlKanalGrupKodPr) hibernateSession.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("aciklama", "�ube")).uniqueResult();
			DateFormat longDateTimeFormat = new SimpleDateFormat("yyyyMMddHHmm");
			@SuppressWarnings("unchecked")
			List<ChannelSourceDef> channelSourceDefs=hibernateSession.createCriteria(ChannelSourceDef.class)
					.add(Restrictions.eq("channelCode", channelCode))
					.add(Restrictions.eq("corporateOid",corpMap.getString("CORPORATE_OID")))
					.add(Restrictions.and(Restrictions.isNotNull("closedDateStart"),Restrictions.le("closedDateStart", longDateTimeFormat.format(new Date()))))
					.add(Restrictions.and(Restrictions.isNotNull("closedDateEnd"),Restrictions.ge("closedDateEnd", longDateTimeFormat.format(new Date()))))
					.add(Restrictions.eq("status", true))
					.list();
			
			if(channelSourceDefs.size()>0){
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE,channelSourceDefs.get(0).getExplanation());
			}
			
			
			GMMap inputControlSubscriberMap = new GMMap();
			inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.CHANNEL_CODE, channelCode );
			inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.COLLECTION_TYPE, collectionType);
			inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.CORPORATE_CODE, corporateCode);
			inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO1, subscriberNo1);
			inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO2, subscriberNo2);
			inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO3, subscriberNo3);
			inputControlSubscriberMap.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO4, subscriberNo4);
			
			GMMap outputControlSubscriberMetaDataMap = CommonHelper.callGraymoundServiceInHibernateSession(
					TransactionConstants.ControlSubscriberMetaData.SERVICE_NAME, 
					inputControlSubscriberMap);
			
			CommonHelper.makeSubscriberNoMask(iMap, outputControlSubscriberMetaDataMap);
			
			collectionType = CommonBusinessOperations.manipulateCollectionTypeForChannels(collectionType, corpMap.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID));
			
			iMap.put("COLLECTION_TYPE", collectionType);
			
			int counter = 0;
			
			GMMap staticColorMap = new GMMap();
			staticColorMap.put("setBackground", Color.WHITE);
			staticColorMap.put("setForeground", Color.BLACK);
			
			GMMap colorMap = new GMMap();
			colorMap.put("setBackground", Color.GREEN);
			colorMap.put("setForeground", Color.BLACK);
			
			for (int i = 0; i < iMap.getSize(INVOICES); i++) {
				
				outMap.put(INVOICES, counter, "COLLECTION_AMOUNT", iMap.get(INVOICES, i, "COLLECTION_AMOUNT"));
				outMap.put(INVOICES, counter, "COMMISSION_AMOUNT", iMap.get(INVOICES, i, "COMMISSION_AMOUNT"));
				outMap.put(INVOICES, counter, "CORPORATE_CODE", iMap.get(INVOICES, i, "CORPORATE_CODE"));
				outMap.put(INVOICES, counter, "CORPORATE_NAME", iMap.get(INVOICES, i, "CORPORATE_NAME"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_HASH", iMap.get(INVOICES, i, "SUBSCRIBER_HASH"));
				outMap.put(INVOICES, counter, "INVOICE_AMOUNT", iMap.get(INVOICES, i, "INVOICE_AMOUNT"));
				outMap.put(INVOICES, counter, "INVOICE_DUE_DATE", iMap.get(INVOICES, i, "INVOICE_DUE_DATE"));
				outMap.put(INVOICES, counter, "INVOICE_NO", iMap.get(INVOICES, i, "INVOICE_NO"));
				outMap.put(INVOICES, counter, "INVOICE_DATE", iMap.get(INVOICES, i, "INVOICE_DATE"));
				String month = iMap.getString(INVOICES, i, "INVOICE_TERM_MONTH");
				String year = iMap.getString(INVOICES, i, "INVOICE_TERM_YEAR");
				outMap.put(INVOICES, counter, "INVOICE_TERM_MONTH", month);
				outMap.put(INVOICES, counter, "INVOICE_TERM_YEAR", year);
				String term = (StringUtil.isEmpty(year) ? "" : year) + (StringUtil.isEmpty(month) ? "" : month);
				outMap.put(INVOICES, counter, "INVOICE_TERM", term);
				outMap.put(INVOICES, counter, "PAYMENT_TYPE", iMap.get(INVOICES, i, "PAYMENT_TYPE"));
				outMap.put(INVOICES, counter, "PAYMENT_TYPE_NAME", iMap.get(INVOICES, i, "PAYMENT_TYPE_NAME"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NAME", iMap.get(INVOICES, i, "SUBSCRIBER_NAME"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NO", iMap.get(INVOICES, i, "SUBSCRIBER_NO"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NO1", iMap.get(INVOICES, i, "SUBSCRIBER_NO1"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NO2", iMap.get(INVOICES, i, "SUBSCRIBER_NO2"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NO3", iMap.get(INVOICES, i, "SUBSCRIBER_NO3"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NO4", iMap.get(INVOICES, i, "SUBSCRIBER_NO4"));
				outMap.put(INVOICES, counter, "SELECT", iMap.get(INVOICES, i, "SELECT"));
				outMap.put(INVOICES, counter, "OID", iMap.get(INVOICES, i, "OID"));
				outMap.put(INVOICES, counter, MapKeys.INSTALLMENT_NO, iMap.get(INVOICES, i, MapKeys.INSTALLMENT_NO));
				outMap.put(INVOICES, counter, "IS_PAID", iMap.get(INVOICES, i, "IS_PAID"));
				outMap.put(INVOICES, counter, "STATE_TEXT", iMap.get(INVOICES, i, "STATE_TEXT"));
				if(!StringUtil.isEmpty(iMap.getString(INVOICES, i, "CORPORATE_STAN_KEY"))){
					outMap.put(INVOICES, counter, "CORPORATE_STAN_KEY", iMap.getString(INVOICES, i, "CORPORATE_STAN_KEY"));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER1)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER1, iMap.get(INVOICES, i, MapKeys.PARAMETER1));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER2)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER2, iMap.get(INVOICES, i, MapKeys.PARAMETER2));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER3)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER3, iMap.get(INVOICES, i, MapKeys.PARAMETER3));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER4)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER4, iMap.get(INVOICES, i, MapKeys.PARAMETER4));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER5)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER5, iMap.get(INVOICES, i, MapKeys.PARAMETER5));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER6)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER6, iMap.get(INVOICES, i, MapKeys.PARAMETER6));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER7)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER7, iMap.get(INVOICES, i, MapKeys.PARAMETER7));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER8)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER8, iMap.get(INVOICES, i, MapKeys.PARAMETER8));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER9)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER9, iMap.get(INVOICES, i, MapKeys.PARAMETER9));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER10)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER10, iMap.get(INVOICES, i, MapKeys.PARAMETER10));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER11)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER11, iMap.get(INVOICES, i, MapKeys.PARAMETER11));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER12)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER12, iMap.get(INVOICES, i, MapKeys.PARAMETER12));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER13)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER13, iMap.get(INVOICES, i, MapKeys.PARAMETER13));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER14)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER14, iMap.get(INVOICES, i, MapKeys.PARAMETER14));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER15)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER15, iMap.get(INVOICES, i, MapKeys.PARAMETER15));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER16)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER16, iMap.get(INVOICES, i, MapKeys.PARAMETER16));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER17)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER17, iMap.get(INVOICES, i, MapKeys.PARAMETER17));
				}

				if(iMap.get(INVOICES, i, MapKeys.PARAMETER18)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER18, iMap.get(INVOICES, i, MapKeys.PARAMETER18));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER19)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER19, iMap.get(INVOICES, i, MapKeys.PARAMETER19));
				}
				
				if(iMap.get(INVOICES, i, MapKeys.PARAMETER20)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER20, iMap.get(INVOICES, i, MapKeys.PARAMETER20));
				}
				
				if(iMap.get(INVOICES, i, "DESCRIPTION")!=null){
					outMap.put(INVOICES, counter, "DESCRIPTION", iMap.get(INVOICES, i, "DESCRIPTION"));
				}
				
				if("1".equals(iMap.get(INVOICES, i, "IS_PAID"))){
					outMap.put(PROPERTIES, counter, "COLLECTION_AMOUNT", colorMap);
					outMap.put(PROPERTIES, counter, "COMMISSION_AMOUNT", colorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_CODE", colorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_NAME", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_AMOUNT", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DUE_DATE", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DATE", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_NO", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_MONTH", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_YEAR", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM", colorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE_NAME", colorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE", colorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NAME", colorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NO", colorMap);
					outMap.put(PROPERTIES, counter, "SELECT", colorMap);
					outMap.put(PROPERTIES, counter, "OID", colorMap);
					outMap.put(PROPERTIES, counter, "ALLOW_PART_PAYMENT", colorMap);
					outMap.put(PROPERTIES, counter, "STATE_TEXT", colorMap);
					outMap.put(PROPERTIES, counter, "DESCRIPTION", colorMap);
				}
				else{
					outMap.put(PROPERTIES, counter, "COLLECTION_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "COMMISSION_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_CODE", staticColorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DUE_DATE", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DATE", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_NO", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_MONTH", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_YEAR", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM", staticColorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE", staticColorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NO", staticColorMap);
					outMap.put(PROPERTIES, counter, "SELECT", staticColorMap);
					outMap.put(PROPERTIES, counter, "OID", staticColorMap);
					outMap.put(PROPERTIES, counter, "ALLOW_PART_PAYMENT", staticColorMap);
					outMap.put(PROPERTIES, counter, "STATE_TEXT", staticColorMap);
					outMap.put(PROPERTIES, counter, "DESCRIPTION", staticColorMap);
				}
				
				counter++;
				
			}
			
			boolean existingSearchExists = false;
			int existingSearchInvoiceCount = 0;
			
			for (int i = 0; i < iMap.getSize(SEARCHED_RESULTS); i++) {
				String alreadySearchedSubscriberNo1 = iMap.getString(SEARCHED_RESULTS, i, "SUBSCRIBER_NO1");
				String alreadySearchedSubscriberNo2 = iMap.getString(SEARCHED_RESULTS, i, "SUBSCRIBER_NO2");
				String alreadySearchedSubscriberNo3 = iMap.getString(SEARCHED_RESULTS, i, "SUBSCRIBER_NO3");
				String alreadySearchedSubscriberNo4 = iMap.getString(SEARCHED_RESULTS, i, "SUBSCRIBER_NO4");
				Short alreadySearchedCollectionType = Short.parseShort(iMap.getString(SEARCHED_RESULTS, i, "COLLECTION_TYPE"));
				String alreadySearchedCorporateCode = iMap.getString(SEARCHED_RESULTS, i, "CORPORATE_CODE");
				int alreadySearchedInvoiceCount = iMap.getInt(SEARCHED_RESULTS, i, "INVOICE_COUNT");
				
				outMap.put(SEARCHED_RESULTS, i, "SUBSCRIBER_NO1", alreadySearchedSubscriberNo1);
				outMap.put(SEARCHED_RESULTS, i, "SUBSCRIBER_NO2", alreadySearchedSubscriberNo2);
				outMap.put(SEARCHED_RESULTS, i, "SUBSCRIBER_NO3", alreadySearchedSubscriberNo3);
				outMap.put(SEARCHED_RESULTS, i, "SUBSCRIBER_NO4", alreadySearchedSubscriberNo4);
				outMap.put(SEARCHED_RESULTS, i, "COLLECTION_TYPE", alreadySearchedCollectionType);
				outMap.put(SEARCHED_RESULTS, i, "CORPORATE_CODE", alreadySearchedCorporateCode);
				outMap.put(SEARCHED_RESULTS, i, "INVOICE_COUNT", alreadySearchedInvoiceCount);
				
				if(alreadySearchedSubscriberNo1.equals(iMap.getString("SUBSCRIBER_NO1")) &&
						(
								(!StringUtil.isEmpty(alreadySearchedSubscriberNo2) && alreadySearchedSubscriberNo2.equals(iMap.getString("SUBSCRIBER_NO2"))) ||
								(StringUtils.isEmpty(alreadySearchedSubscriberNo2) && StringUtil.isEmpty(subscriberNo2))
						) &&
						(
								(!StringUtil.isEmpty(alreadySearchedSubscriberNo3) && alreadySearchedSubscriberNo2.equals(iMap.getString("SUBSCRIBER_NO3"))) ||
								(StringUtils.isEmpty(alreadySearchedSubscriberNo3) && StringUtil.isEmpty(subscriberNo3))
						) &&
						(
								(!StringUtil.isEmpty(alreadySearchedSubscriberNo4) && alreadySearchedSubscriberNo2.equals(iMap.getString("SUBSCRIBER_NO4"))) ||
								(StringUtils.isEmpty(alreadySearchedSubscriberNo4) && StringUtil.isEmpty(subscriberNo4))
						) &&
						alreadySearchedCollectionType.equals(collectionType) &&
						alreadySearchedCorporateCode.equals(corporateCode)){
					existingSearchExists = true;
					existingSearchInvoiceCount = alreadySearchedInvoiceCount;
					break;
				}
			}
			
			if(existingSearchExists){
				if(existingSearchInvoiceCount > 0){
					outMap.put("FOUND_INVOICE_COUNT", foundInvoiceCount);
					outMap.put("SEARCH_STATUS", "E");
					return outMap;
				}
				else{
					outMap.put("FOUND_INVOICE_COUNT", foundInvoiceCount);
					outMap.put("SEARCH_STATUS", "N");
					return outMap;
				}
			}
			
			int metadataHash = CommonBusinessOperations.getMetadataHash(corporateCode, collectionType, CommonHelper.getChannelId());
			
			Date bankDate = new Date();
			
			if (corpMap.getString(MapKeys.IS_ONLINE_CORPORATE).equals("1")) {
				//Online kurum
				iMap.put(MapKeys.BANK_CODE, corpMap.getString(MapKeys.BANK_CODE));
				iMap.put(MapKeys.CORPORATE_CODE, corpMap.getString(MapKeys.CORPORATE_CODE));
				iMap.put(MapKeys.STAN_NO, CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
				iMap.put(MapKeys.GM_SERVICE_NAME, "ICS_SEARCH_INVOICE");
				iMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
				GMMap invoiceMap = new GMMap();
				
				invoiceMap = (GMMap) GMServiceExecuter.call("ICS_ONLINE_SERVICE_CALL", iMap);
				//BEDAS CAMPAIGN
				outMap.put(MapKeys.ELIGIBLE_CONSUMER, invoiceMap.getString(MapKeys.ELIGIBLE_CONSUMER,""));
				outMap.put(MapKeys.MISSING_INFORMATION, invoiceMap.getString(MapKeys.MISSING_INFORMATION,""));
				outMap.put(MapKeys.OFFER, invoiceMap.getString(MapKeys.OFFER,""));
				outMap.put(MapKeys.CUSTOMER_PERSONAL_NUMBER, invoiceMap.getString(MapKeys.CUSTOMER_PERSONAL_NUMBER,""));
				
				for (int i = 0; i < invoiceMap.getSize(INVOICES); i++) {
					
					Date dueDate = invoiceMap.getDate(INVOICES, i, "INVOICE_DUE_DATE");
					if(!corpMap.getBoolean(TransactionConstants.GetCorporateDefinition.Output.ALLOW_AFTER_DUE)){
						if(CommonHelper.addDay(dueDate, 1).compareTo(bankDate) >= 0){
							continue;
						}
					}
					
					String subscriberNo = "";
					if(!StringUtil.isEmpty(invoiceMap.getString(INVOICES, i, MapKeys.SUBSCRIBER_NO1))){
						subscriberNo += invoiceMap.getString(INVOICES, i, MapKeys.SUBSCRIBER_NO1);
					}
					subscriberNo = subscriberNo.concat(" ");
					if(!StringUtil.isEmpty(invoiceMap.getString(INVOICES, i, MapKeys.SUBSCRIBER_NO2))){
						subscriberNo += invoiceMap.getString(INVOICES, i, MapKeys.SUBSCRIBER_NO2);
					}
					subscriberNo = subscriberNo.concat(" ");
					if(!StringUtil.isEmpty(invoiceMap.getString(INVOICES, i, MapKeys.SUBSCRIBER_NO3))){
						subscriberNo += invoiceMap.getString(INVOICES, i, MapKeys.SUBSCRIBER_NO3);
					}
					subscriberNo = subscriberNo.concat(" ");
					if(!StringUtil.isEmpty(invoiceMap.getString(INVOICES, i, MapKeys.SUBSCRIBER_NO4))){
						subscriberNo += " " + invoiceMap.getString(INVOICES, i, MapKeys.SUBSCRIBER_NO4);
					}
					
					outMap.put(INVOICES, counter, "COLLECTION_AMOUNT", invoiceMap.get(INVOICES, i, MapKeys.AMOUNT));
					outMap.put(INVOICES, counter, "SUBSCRIBER_HASH", metadataHash);
					outMap.put(INVOICES, counter, "COMMISSION_AMOUNT", calculateCommission(corporateCode, invoiceMap.getBigDecimal(INVOICES, i, MapKeys.AMOUNT)));
					outMap.put(INVOICES, counter, "CORPORATE_CODE", corporateCode);
					outMap.put(INVOICES, counter, "CORPORATE_NAME", corpMap.getString(TransactionConstants.GetCorporateDefinition.Output.SHORT_CODE));
					outMap.put(INVOICES, counter, "INVOICE_AMOUNT", invoiceMap.get(INVOICES, i, MapKeys.AMOUNT));
					outMap.put(INVOICES, counter, "INVOICE_DUE_DATE", dueDate);
					outMap.put(INVOICES, counter, "INVOICE_DATE", invoiceMap.getDate(INVOICES, i, "INVOICE_DATE"));
					outMap.put(INVOICES, counter, "INVOICE_NO", invoiceMap.get(INVOICES, i, "INVOICE_NO"));
					String month = invoiceMap.getString(INVOICES, i, "INVOICE_TERM_MONTH");
					String year = invoiceMap.getString(INVOICES, i, "INVOICE_TERM_YEAR");
					outMap.put(INVOICES, counter, "INVOICE_TERM_MONTH", month);
					outMap.put(INVOICES, counter, "INVOICE_TERM_YEAR", year);
					String term = (StringUtil.isEmpty(year) ? "" : year) + (StringUtil.isEmpty(month) ? "" : month);
					outMap.put(INVOICES, counter, "INVOICE_TERM", term);
					outMap.put(INVOICES, counter, "PAYMENT_TYPE", invoiceMap.get(INVOICES, i, "PAYMENT_TYPE"));
					outMap.put(INVOICES, counter, "PAYMENT_TYPE_NAME", invoiceMap.get(INVOICES, i, "PAYMENT_TYPE_NAME"));
					outMap.put(INVOICES, counter, MapKeys.SUBSCRIBER_NAME, invoiceMap.get(INVOICES, i, MapKeys.SUBSCRIBER_NAME));
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO", subscriberNo);
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO1", invoiceMap.get(INVOICES, i, "SUBSCRIBER_NO1"));
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO2", invoiceMap.get(INVOICES, i, "SUBSCRIBER_NO2"));
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO3", invoiceMap.get(INVOICES, i, "SUBSCRIBER_NO3"));
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO4", invoiceMap.get(INVOICES, i, "SUBSCRIBER_NO4"));
					outMap.put(INVOICES, counter, "SELECT", false);
					outMap.put(INVOICES, counter, "OID", "0");
					outMap.put(INVOICES, counter, MapKeys.INSTALLMENT_NO, invoiceMap.get(INVOICES, i, MapKeys.INSTALLMENT_NO));
					if(!StringUtil.isEmpty(invoiceMap.getString(INVOICES, i, "CORPORATE_STAN_KEY"))){
						outMap.put(INVOICES, counter, "CORPORATE_STAN_KEY", invoiceMap.getString(INVOICES, i, "CORPORATE_STAN_KEY"));
					}
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER1)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER1, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER1));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER2)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER2, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER2));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER3)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER3, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER3));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER4)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER4, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER4));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER5)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER5, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER5));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER6)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER6, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER6));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER7)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER7, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER7));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER8)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER8, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER8));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER9)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER9, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER9));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER10)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER10, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER10));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER11)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER11, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER11));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER12)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER12, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER12));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER13)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER13, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER13));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER14)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER14, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER14));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER15)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER15, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER15));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER16)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER16, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER16));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER17)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER17, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER17));
					}

					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER18)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER18, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER18));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER19)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER19, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER19));
					}
					
					if(invoiceMap.get(INVOICES, i, MapKeys.PARAMETER20)!=null){
						outMap.put(INVOICES, counter, MapKeys.PARAMETER20, invoiceMap.get(INVOICES, i, MapKeys.PARAMETER20));
					}
					
					if(invoiceMap.getString(INVOICES, i, "DESCRIPTION") != null){
						outMap.put(INVOICES, counter, "DESCRIPTION", invoiceMap.getString(INVOICES, i, "DESCRIPTION"));
					}
					
					outMap.put(INVOICES, counter, "ALLOW_PART_PAYMENT", corpMap.getBoolean(TransactionConstants.GetCorporateDefinition.Output.ALLOW_PART_PAYMENT));
					outMap.put(INVOICES, counter, "IS_PAID", "0");
					outMap.put(INVOICES, counter, "STATE_TEXT", "�denecek");
					outMap.put(INVOICES, counter, "GROUP_ID", invoiceMap.get(INVOICES, i, "GROUP_ID"));
					
					outMap.put(PROPERTIES, counter, "COLLECTION_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "COMMISSION_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_CODE", staticColorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DUE_DATE", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DATE", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_NO", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_MONTH", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_YEAR", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM", staticColorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE", staticColorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NO", staticColorMap);
					outMap.put(PROPERTIES, counter, "SELECT", staticColorMap);
					outMap.put(PROPERTIES, counter, "OID", staticColorMap);
					outMap.put(PROPERTIES, counter, "ALLOW_PART_PAYMENT", staticColorMap);
					outMap.put(PROPERTIES, counter, "STATE_TEXT", staticColorMap);
					outMap.put(PROPERTIES, counter, "DESCRIPTION", staticColorMap);
					++foundInvoiceCount;
					counter++;
					
				}
			
			 }else {
					//Offline kurum
				
				Criteria criteria = hibernateSession.createCriteria(invoiceMain.class)
						.add(Restrictions.eq("corporateCode", corporateCode))
						.add(Restrictions.eq("collectionType", collectionType))
						.add(Restrictions.eq("status", true))
						.add(Restrictions.disjunction()
								.add(Restrictions.eq("paymentStatus", PaymentStatuses.Waiting))
								.add(Restrictions.eq("paymentStatus", PaymentStatuses.PartialCollected)));
				
				if(subscriberNo1 != null && !subscriberNo1.trim().isEmpty()){
					criteria = criteria.add(Restrictions.eq("subscriberNo1", iMap.getString("SUBSCRIBER_NO1")));
				}
				if(subscriberNo2 != null && !subscriberNo2.trim().isEmpty()){
					criteria = criteria.add(Restrictions.eq("subscriberNo2", iMap.getString("SUBSCRIBER_NO2")));
				}
				
				if(subscriberNo3 != null && !subscriberNo3.trim().isEmpty()){
					criteria = criteria.add(Restrictions.eq("subscriberNo3", iMap.getString("SUBSCRIBER_NO3")));
				}
				
				if(subscriberNo4 != null && !subscriberNo4.trim().isEmpty()){
					criteria = criteria.add(Restrictions.eq("subscriberNo4", iMap.getString("SUBSCRIBER_NO4")));
				}
				
				@SuppressWarnings("unchecked")
				List<invoiceMain> invoiceList = criteria.list();
			
				
				for(invoiceMain invoice : invoiceList){
					
					String dueDateString = invoice.getInvoiceDueDate();
					
					if(StringUtil.isEmpty(dueDateString)){
						dueDateString = CommonHelper.getDateString(new Date(), "yyyyMMdd");
					}
					
					Date dueDate = CommonHelper.getDateTime(dueDateString, "yyyyMMdd");
					if(!corpMap.getBoolean(TransactionConstants.GetCorporateDefinition.Output.ALLOW_AFTER_DUE)){
						if(CommonHelper.addDay(dueDate, 1).compareTo(bankDate) < 0){
							continue;
						}
					}
					
					String subscriberNo = invoice.getSubscriberNo1();
					if(invoice.getSubscriberNo2() != null && !invoice.getSubscriberNo2().trim().isEmpty()){
						subscriberNo += " " + invoice.getSubscriberNo2();
					}
					if(invoice.getSubscriberNo3() != null && !invoice.getSubscriberNo3().trim().isEmpty()){
						subscriberNo += " " + invoice.getSubscriberNo3();
					}
					if(invoice.getSubscriberNo4() != null && !invoice.getSubscriberNo4().trim().isEmpty()){
						subscriberNo += " " + invoice.getSubscriberNo4();
					}
					
					BigDecimal invoiceAmount = invoice.getAmount();
					if(invoice.getPaymentAmount() != null){
						invoiceAmount = invoiceAmount.subtract(invoice.getPaymentAmount());
					}
					
					outMap.put(INVOICES, counter, "COMMISSION_AMOUNT", calculateCommission(corporateCode, invoiceAmount));
					outMap.put(INVOICES, counter, "SUBSCRIBER_HASH", metadataHash);
					outMap.put(INVOICES, counter, "CORPORATE_CODE", invoice.getCorporateCode());
					outMap.put(INVOICES, counter, "CORPORATE_NAME", CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(invoice.getCorporateCode()));
					outMap.put(INVOICES, counter, "INVOICE_AMOUNT", invoiceAmount);
					outMap.put(INVOICES, counter, "COLLECTION_AMOUNT", invoiceAmount);
					outMap.put(INVOICES, counter, "INVOICE_DUE_DATE", dueDate);
					outMap.put(INVOICES, counter, "INVOICE_DATE", invoice.getInvoiceDate());
					outMap.put(INVOICES, counter, "INVOICE_NO", invoice.getInvoiceNo());
					String month = invoice.getTermMonth();
					String year = invoice.getTermYear();
					outMap.put(INVOICES, counter, "INVOICE_TERM_MONTH", month);
					outMap.put(INVOICES, counter, "INVOICE_TERM_YEAR", year);
					String term = (StringUtil.isEmpty(year) ? "" : year) + (StringUtil.isEmpty(month) ? "" : month);
					outMap.put(INVOICES, counter, "INVOICE_TERM", term);
					outMap.put(INVOICES, counter, "PAYMENT_TYPE_NAME", CommonBusinessOperations.getCollectionTypeName(invoice.getCollectionType()));
					outMap.put(INVOICES, counter, "PAYMENT_TYPE", invoice.getCollectionType());
					outMap.put(INVOICES, counter, "SUBSCRIBER_NAME", invoice.getSubscriberName());
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO", subscriberNo);
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO1", iMap.getString("SUBSCRIBER_NO1"));
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO2", iMap.getString("SUBSCRIBER_NO2"));
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO3", iMap.getString("SUBSCRIBER_NO3"));
					outMap.put(INVOICES, counter, "SUBSCRIBER_NO4", iMap.getString("SUBSCRIBER_NO4"));
					outMap.put(INVOICES, counter, "SELECT", false);
					outMap.put(INVOICES, counter, "OID", invoice.getOid());
					outMap.put(INVOICES, counter, "ALLOW_PART_PAYMENT", corpMap.getBoolean(TransactionConstants.GetCorporateDefinition.Output.ALLOW_PART_PAYMENT));
					outMap.put(INVOICES, counter, "IS_PAID", "0");
					outMap.put(INVOICES, counter, "STATE_TEXT", "�denecek");
					outMap.put(INVOICES, counter, "PARAMETER1", invoice.getParameter1());
					outMap.put(INVOICES, counter, "PARAMETER2", invoice.getParameter2());
					outMap.put(INVOICES, counter, "PARAMETER3", invoice.getParameter3());
					outMap.put(INVOICES, counter, "PARAMETER4", invoice.getParameter4());
					outMap.put(INVOICES, counter, "PARAMETER5", invoice.getParameter5());
					outMap.put(INVOICES, counter, "PARAMETER6", invoice.getParameter6());
					outMap.put(INVOICES, counter, "PARAMETER7", invoice.getParameter7());
					
					outMap.put(INVOICES, counter, "PARAMETER8", invoice.getParameter8());
					outMap.put(INVOICES, counter, "PARAMETER9", invoice.getParameter9());
					outMap.put(INVOICES, counter, "PARAMETER10", invoice.getParameter10());
					outMap.put(INVOICES, counter, "PARAMETER11", invoice.getParameter11());
					outMap.put(INVOICES, counter, "PARAMETER12", invoice.getParameter12());
					outMap.put(INVOICES, counter, "PARAMETER13", invoice.getParameter13());
					outMap.put(INVOICES, counter, "PARAMETER14", invoice.getParameter14());
					
					outMap.put(INVOICES, counter, "PARAMETER15", invoice.getParameter15());
					outMap.put(INVOICES, counter, "PARAMETER16", invoice.getParameter16());
					outMap.put(INVOICES, counter, "PARAMETER17", invoice.getParameter17());
					outMap.put(INVOICES, counter, "PARAMETER18", invoice.getParameter18());
					outMap.put(INVOICES, counter, "PARAMETER19", invoice.getParameter19());
					outMap.put(INVOICES, counter, "PARAMETER20", invoice.getParameter20());
					
					outMap.put(PROPERTIES, counter, "COLLECTION_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "COMMISSION_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_CODE", staticColorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DUE_DATE", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DATE", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_NO", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_MONTH", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_YEAR", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM", staticColorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE", staticColorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NO", staticColorMap);
					outMap.put(PROPERTIES, counter, "SELECT", staticColorMap);
					outMap.put(PROPERTIES, counter, "OID", staticColorMap);
					outMap.put(PROPERTIES, counter, "ALLOW_PART_PAYMENT", staticColorMap);
					outMap.put(PROPERTIES, counter, "STATE_TEXT", staticColorMap);
					outMap.put(PROPERTIES, counter, "DESCRIPTION", staticColorMap);
					++foundInvoiceCount;
					counter++;
					
				}
				
			}
			
			outMap.put(SEARCHED_RESULTS, iMap.getSize(SEARCHED_RESULTS), "SUBSCRIBER_NO1", iMap.getString("SUBSCRIBER_NO1"));
			outMap.put(SEARCHED_RESULTS, iMap.getSize(SEARCHED_RESULTS), "SUBSCRIBER_NO2", iMap.getString("SUBSCRIBER_NO2"));
			outMap.put(SEARCHED_RESULTS, iMap.getSize(SEARCHED_RESULTS), "SUBSCRIBER_NO3", iMap.getString("SUBSCRIBER_NO3"));
			outMap.put(SEARCHED_RESULTS, iMap.getSize(SEARCHED_RESULTS), "SUBSCRIBER_NO4", iMap.getString("SUBSCRIBER_NO4"));
			outMap.put(SEARCHED_RESULTS, iMap.getSize(SEARCHED_RESULTS), "COLLECTION_TYPE", collectionType);
			outMap.put(SEARCHED_RESULTS, iMap.getSize(SEARCHED_RESULTS), "CORPORATE_CODE", corporateCode);
			outMap.put(SEARCHED_RESULTS, iMap.getSize(SEARCHED_RESULTS), "INVOICE_COUNT", foundInvoiceCount);
			outMap.put("FOUND_INVOICE_COUNT", foundInvoiceCount);
			if(foundInvoiceCount > 0){
				outMap.put("SEARCH_STATUS", "F");
			}
			else{
				outMap.put("SEARCH_STATUS", "N");
			}
			
		} catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return outMap;
	}
	
	@GraymoundService("ICS_SEARCH_COLLECTED_PAYMENTS")
	public static GMMap searchCollectedPayments(GMMap iMap){
		GMMap outMap = new GMMap();
		String tableName = "PAYMENTS";
		try{
			
			String radioButtonSelection = iMap.getString("RADIO_BUTTON_SELECTION");
			BigDecimal referenceNo = iMap.getBigDecimal("REFERENCE_NO");
			BigDecimal customerNo = iMap.getBigDecimal("CUSTOMER_NO");
			String corporateOid = iMap.getString("CORPORATE_OID");
			Short paymentType = null;
			String paymentTypeStr = iMap.getString("PAYMENT_TYPE");
			if (paymentTypeStr != null)			
				paymentType = Short.parseShort(paymentTypeStr);
			//String channel = iMap.getString("CHANNEL");
			String paymentSource = iMap.getString("PAYMENT_SOURCE");
			Date startDate = null, endDate = null, date = null;
			String subscriberNo1 = "";
			String subscriberNo2 = "";
			String subscriberNo3 = "";
			String subscriberNo4 = "";
			String currentCorporateCode = null, currentPaymentType = null, currentChannel = null, currentPaymentSource = null, currentSubscriberName = null,
				   startDatestr = null, endDatestr = null, currentInvoiceNo = null, paymentDate = null, payerBranchName = null, paymentRecOwner = null;
			BigDecimal paymentAmount = null, invoiceAmount = null;
			
			if (iMap.getDate("PAYMENT_DATE") != null) {
				startDate = new java.sql.Date(iMap.getDate("PAYMENT_DATE").getTime());
				startDatestr = CommonHelper.getShortDateTimeString(startDate);
				startDatestr += "000000";
				
				endDate = new java.sql.Date(iMap.getDate("PAYMENT_DATE").getTime());
				endDatestr = CommonHelper.getShortDateTimeString(endDate);
				endDatestr += "235959";
			}
			
			String userBranch = iMap.getString("BRANCH_ID");
			String userChannel = CommonHelper.getChannelId();
						
			Session hibernateSession = CommonHelper.getHibernateSession();
		
			Criteria criteria = null;
			if(radioButtonSelection.equals("ISLEM_NO")) {				
				if (referenceNo == null) 
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "��lem No"));	
				
				criteria = hibernateSession.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("txNo", referenceNo))
						.add(Restrictions.between("paymentDate", startDatestr, endDatestr))						
						.add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected))
						.add(Restrictions.eq("status", true));		
			}
			else if(radioButtonSelection.equals("MUSTERI_NO")) {				
				if (customerNo == null) 
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "M��teri No"));	
				
				criteria = hibernateSession.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("payerCustomer", customerNo))
						.add(Restrictions.between("paymentDate", startDatestr, endDatestr))						
						.add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected))
						.add(Restrictions.eq("status", true));		
			}
			else if(radioButtonSelection.equals("REFERANS_NO")) {				
				
				CorporateMaster corporateMaster = ((CorporateMaster)hibernateSession.createCriteria(CorporateMaster.class)
						.add(Restrictions.eq("oid", corporateOid))
						.add(Restrictions.eq("status", true))
						.uniqueResult());
				String corporateCode = corporateMaster.getCorporateCode();
				//String isOnlineCorporate = corporateMaster.getIsOnlineCorporate();
				
//				if (isOnlineCorporate.equals("1")) {
//					subscriberNo1 = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO1),'0');
//					subscriberNo2 = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO2),'0');
//					subscriberNo3 = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO3),'0');
//					subscriberNo4 = CommonHelper.trimStart(iMap.getString(MapKeys.SUBSCRIBER_NO4),'0');
//				} else {
					subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1);
					subscriberNo2 = iMap.getString(MapKeys.SUBSCRIBER_NO2);
					subscriberNo3 = iMap.getString(MapKeys.SUBSCRIBER_NO3);
					subscriberNo4 = iMap.getString(MapKeys.SUBSCRIBER_NO4);
//				}
				
				criteria = hibernateSession.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("corporateCode", corporateCode))
						.add(Restrictions.eq("collectionType", paymentType))
						.add(Restrictions.between("paymentDate", startDatestr, endDatestr))
						.add(Restrictions.eq("paymentStatus", PaymentStatuses.Collected))
						.add(Restrictions.eq("status", true))
						.addOrder(Order.asc("paymentDate"));	
				
//				if (channel != null)
//					criteria = criteria.add(Restrictions.eq("paymentChannel", channel));
				
				if (paymentSource != null)
					criteria = criteria.add(Restrictions.eq("paymentSource", paymentSource));
					
				if (subscriberNo1 != null && !subscriberNo1.trim().isEmpty())
					criteria = criteria.add(Restrictions.eq("subscriberNo1", subscriberNo1));
					
				if (subscriberNo2 != null && !subscriberNo2.trim().isEmpty())
					criteria = criteria.add(Restrictions.eq("subscriberNo2", subscriberNo2));
				
				if (subscriberNo3 != null && !subscriberNo3.trim().isEmpty())
					criteria = criteria.add(Restrictions.eq("subscriberNo3", subscriberNo3));
				
				if (subscriberNo4 != null && !subscriberNo4.trim().isEmpty())
					criteria = criteria.add(Restrictions.eq("subscriberNo4", subscriberNo4));
				
			}
			
			if( null != userChannel ){ 
	            if (userChannel.equals(GeneralConstants.BRANCH_CHANNEL_CODE)) {
	                   //�ube kullan�c�s�
	                   if (!userBranch.equals(GeneralConstants.GM_BRANCH_CODE))                          
	                	   criteria = criteria.add(Restrictions.eq("paymentBranch", userBranch));
	            }
	             
	            logger.info("ServiceWrapper[searchCollectedPayments] User Channel : " + userChannel);
	            if( !userChannel.equals(DEFAULT_CHANNEL) ){
	            	 criteria = criteria.add(Restrictions.eq("paymentChannel", userChannel));
	            }
			}
						
			@SuppressWarnings("unchecked")
			List<invoicePayment> invoicePayment = criteria.list();
			
			int counter = 0;
			for(invoicePayment payment : invoicePayment) {
				String subscriberNo = payment.getSubscriberNo1();
				if(payment.getSubscriberNo2() != null && !payment.getSubscriberNo2().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo2();
				
				if(payment.getSubscriberNo3() != null && !payment.getSubscriberNo3().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo3();
				
				if(payment.getSubscriberNo4() != null && !payment.getSubscriberNo4().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo4();
				
				currentCorporateCode = payment.getCorporateCode();
				currentPaymentType = CommonBusinessOperations.getCollectionTypeName(Short.valueOf(payment.getCollectionType()));
				currentChannel = CommonBusinessOperations.getChannelName(payment.getPaymentChannel());
				currentPaymentSource = CommonBusinessOperations.getPaymentSourceName(payment.getPaymentSource());
				paymentAmount = payment.getPaymentAmount();
				invoiceAmount = payment.getInvoiceAmount();
				currentSubscriberName = null;				
				invoiceMain getInvoice = ((invoiceMain)hibernateSession.createCriteria(invoiceMain.class)
										.add(Restrictions.eq("oid", payment.getInvoiceMainOid()))
										.uniqueResult());
				if (getInvoice != null)
					currentSubscriberName = getInvoice.getSubscriberName();
		
				
				currentInvoiceNo = payment.getInvoiceNo();
				date = CommonHelper.getDateTime(payment.getPaymentDate(), "yyyyMMddHHmmss");
				paymentDate = CommonHelper.getShortDateTimeString(date);				
				
				paymentRecOwner = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_REC_OWNER_QUERY, payment.getOid()));	
				
				if (paymentRecOwner != null || !"".equals(paymentRecOwner)) {
					payerBranchName = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_BRANCH_CODE_QUERY, payment.getPaymentBranch()));
				}
				
				BigDecimal commissionAmount = new BigDecimal(0);
				
				if("1".equals(payment.getIsCommissionExist())){
					invoiceCommission commissionRecord = (invoiceCommission)hibernateSession.createCriteria(invoiceCommission.class)
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("invoicePaymentOid", payment.getOid()))
							.add(Restrictions.eq("collectionStatus", DatabaseConstants.CommissionCollectionStatuses.Collected))
							.uniqueResult();
					if(commissionRecord != null){
						if(commissionRecord.getCommissionAmount() != null && commissionRecord.getBsmvAmount() != null){
							commissionAmount = commissionAmount.add(commissionRecord.getCommissionAmount()).add(commissionRecord.getBsmvAmount());
						}
					}
				}
				
				outMap.put(tableName, counter, "PAYER_BRANCH_NAME", payerBranchName);				
				outMap.put(tableName, counter, "PAYMENT_ACCOUNT_NO", payment.getPaymentAccountNo());	
				outMap.put(tableName, counter, "PAYMENT_REC_OWNER", paymentRecOwner);	
				outMap.put(tableName, counter, "COLLECTION_AMOUNT", paymentAmount);
				outMap.put(tableName, counter, "COMMISSION_AMOUNT", commissionAmount);
				outMap.put(tableName, counter, "CORPORATE_CODE", currentCorporateCode);
				outMap.put(tableName, counter, "CORPORATE_NAME", CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(currentCorporateCode));
				outMap.put(tableName, counter, "INVOICE_AMOUNT", invoiceAmount);
				outMap.put(tableName, counter, "INVOICE_NO", currentInvoiceNo);
				outMap.put(tableName, counter, "PAYMENT_TYPE", currentPaymentType);
				outMap.put(tableName, counter, "PAYMENT_DATE", paymentDate);
				outMap.put(tableName, counter, "PAYMENT_SOURCE", currentPaymentSource);
				outMap.put(tableName, counter, "CHANNEL", currentChannel);
				outMap.put(tableName, counter, "SUBSCRIBER_NAME", currentSubscriberName);
				outMap.put(tableName, counter, "SUBSCRIBER_NO", subscriberNo);
				outMap.put(tableName, counter, "SELECT", false);
				outMap.put(tableName, counter, "OID", payment.getOid());
				
				/**
				 * Add Code For 189
				 */
				outMap.put(tableName, counter, "REFERENCE_NO", payment.getTxNo());
				
				counter++;			
			}
			
			
		} catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return outMap;
	}	
	
	/**
	 * Add Code For 192
	 * @param iMap
	 * @return
	 */
	@GraymoundService("ICS_CORPORATE_PAYMENT_REVERSE_REASON_CODE")
	public static GMMap getCorporatePaymentReverseReasonCode(GMMap iMap){
		return CommonHelper.getAllParametersByCode("BNSPR_CORPORATE_INVOICE_PAYMENT_REVERSE_REASON_CODE", iMap);
	}
	
	@GraymoundService("ICS_SEARCH_PAYMENT_VIEW_INIT")
	public static GMMap searchPaymentsViewInit(GMMap iMap){
		GMMap outMap = new GMMap();
		String tableName = "PAYMENTS";
		try{
			BigDecimal trxNo = iMap.getBigDecimal(MapKeys.TRX_NO);		
			
			Session hibernateSession = CommonHelper.getHibernateSession();
			String currentCorporateCode = null, currentPaymentType = null, currentChannel = null, currentPaymentSource = null, currentSubscriberName = null,
				   currentInvoiceNo = null, paymentDate = null, payerBranchName = null, paymentRecOwner = null;
			BigDecimal paymentAmount = null, invoiceAmount = null;
			
			invoicePaymentLog paymentLog = (invoicePaymentLog)hibernateSession.createCriteria(invoicePaymentLog.class)
											.add(Restrictions.eq("txNo", trxNo))
											.uniqueResult();
					
			invoicePayment payment = null;
			if (paymentLog != null)	{
				payment = (invoicePayment)hibernateSession.createCriteria(invoicePayment.class)
							.add(Restrictions.eq("oid", paymentLog.getInvoicePaymentOid()))
							.uniqueResult();
			}
								
			int rowCount = 0;
			if (payment != null) {
				
				String subscriberNo = payment.getSubscriberNo1();
				if(payment.getSubscriberNo2() != null && !payment.getSubscriberNo2().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo2();
				
				if(payment.getSubscriberNo3() != null && !payment.getSubscriberNo3().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo3();
				
				if(payment.getSubscriberNo4() != null && !payment.getSubscriberNo4().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo4();
				
				
				currentCorporateCode = payment.getCorporateCode();
				currentPaymentType = CommonBusinessOperations.getCollectionTypeName(Short.valueOf(payment.getCollectionType()));
				currentChannel = CommonBusinessOperations.getChannelName(payment.getPaymentChannel());
				currentPaymentSource = CommonBusinessOperations.getPaymentSourceName(payment.getPaymentSource());
				paymentAmount = payment.getPaymentAmount();
				invoiceAmount = payment.getInvoiceAmount();
				currentSubscriberName = null;				
				invoiceMain getInvoice = ((invoiceMain)hibernateSession.createCriteria(invoiceMain.class)
										.add(Restrictions.eq("oid", payment.getInvoiceMainOid()))
										.uniqueResult());
				if (getInvoice != null)
					currentSubscriberName = getInvoice.getSubscriberName();
				
				currentInvoiceNo = payment.getInvoiceNo();
				Date date = CommonHelper.getDateTime(payment.getPaymentDate(), "yyyyMMddHHmmss");
				paymentDate = CommonHelper.getShortDateTimeString(date);
				
				paymentRecOwner = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_REC_OWNER_QUERY, payment.getOid()));	
				
				if (paymentRecOwner != null || !"".equals(paymentRecOwner)) {
					payerBranchName = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_BRANCH_CODE_QUERY, payment.getPaymentBranch()));
				}
				
				outMap.put(tableName, rowCount, "PAYER_BRANCH_NAME", payerBranchName);				
				outMap.put(tableName, rowCount, "PAYMENT_ACCOUNT_NO", payment.getPaymentAccountNo());	
				outMap.put(tableName, rowCount, "PAYMENT_REC_OWNER", paymentRecOwner);	
				outMap.put(tableName, rowCount, "COLLECTION_AMOUNT", paymentAmount);
				outMap.put(tableName, rowCount, "COMMISSION_AMOUNT", calculateCommission(currentCorporateCode, paymentAmount));
				outMap.put(tableName, rowCount, "CORPORATE_CODE", currentCorporateCode);
				outMap.put(tableName, rowCount, "CORPORATE_NAME", CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(currentCorporateCode));
				outMap.put(tableName, rowCount, "INVOICE_AMOUNT", invoiceAmount);
				outMap.put(tableName, rowCount, "INVOICE_NO", currentInvoiceNo);
				outMap.put(tableName, rowCount, "PAYMENT_TYPE", currentPaymentType);
				outMap.put(tableName, rowCount, "PAYMENT_DATE", paymentDate);
				outMap.put(tableName, rowCount, "PAYMENT_SOURCE", currentPaymentSource);
				outMap.put(tableName, rowCount, "CHANNEL", currentChannel);
				outMap.put(tableName, rowCount, "SUBSCRIBER_NAME", currentSubscriberName);
				outMap.put(tableName, rowCount, "SUBSCRIBER_NO", subscriberNo);
				outMap.put(tableName, rowCount, "SELECT", true);
				outMap.put(tableName, rowCount, "OID", payment.getOid());	
				outMap.put(tableName, rowCount, "ERROR_CODE",payment.getRejectedReasonCode());
				outMap.put(tableName, rowCount, "ERROR_CODE_DESC", payment.getRejectedReason());
			}
						
		} catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return outMap;
	}			
	
	@GraymoundService("ICS_CALCULATE_TOTAL_INVOICE_AMOUNT")
	public static GMMap calcutateTotalInvoiceAmount(GMMap iMap) {

		GMMap oMap = new GMMap();
		final String tableName = "PAYMENTS";
		
		try{
			int size = iMap.getSize(tableName);
			BigDecimal totalAmount = BigDecimal.ZERO;
			
			for(int i = 0; i < size; i++){
				if(iMap.getBoolean(tableName, i, "SELECT")) {
					totalAmount = totalAmount.add(iMap.getBigDecimal(tableName, i, "COLLECTION_AMOUNT"));
					totalAmount = totalAmount.add(iMap.getBigDecimal(tableName, i, "COMMISSION_AMOUNT"));
				}
			}
			
			oMap.put("TOTAL_AMOUNT", totalAmount);
			return oMap;
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static BigDecimal calculateCommission(String corporateCode, BigDecimal amount) {	
		GMMap commissionMap = new GMMap();
		commissionMap.put(TransactionConstants.CalculateCommission.Input.CORPORATE_CODE, corporateCode);
		commissionMap.put(TransactionConstants.CalculateCommission.Input.CHANNEL_CODE, CommonHelper.getChannelId());
		commissionMap.put(TransactionConstants.CalculateCommission.Input.PAYMENT_AMOUNT, amount);
		commissionMap.put(TransactionConstants.CalculateCommission.Input.CHECK_EXEMPTION, "0");
		
		GMMap result = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.CalculateCommission.SERVICE_NAME, commissionMap);
		
		return result.getBigDecimal(TransactionConstants.CalculateCommission.Output.COMMISSION_AMOUNT).add(result.getBigDecimal(TransactionConstants.CalculateCommission.Output.BSMV_AMOUNT));
		
	}
	
	@GraymoundService("ICS_SEND_CANCEL_COLLECTION_MESSAGE_AFTER_APPROVAL")
	public static GMMap sendCancelCollectionMessageAfterApproval (GMMap iMap)
	{
		GMMap oMap = new GMMap();
		try {
			
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal txNo = iMap.getBigDecimal("ISLEM_NO");
			
			invoicePaymentLog paymentLog = ((invoicePaymentLog)hibernateSession.createCriteria(invoicePaymentLog.class)
					.add(Restrictions.eq("txNo", txNo)).uniqueResult());
			
			invoicePayment payment = ((invoicePayment)hibernateSession.createCriteria(invoicePayment.class)
					.add(Restrictions.eq("oid", paymentLog.getInvoicePaymentOid())).uniqueResult());
			
			invoiceCommission commissionRecord = (invoiceCommission) hibernateSession.createCriteria(invoiceCommission.class)
					.add(Restrictions.eq("invoicePaymentOid", paymentLog.getInvoicePaymentOid()))
					.add(Restrictions.eq("status", true))
					.uniqueResult();
			
			
			GMMap corpMap = new GMMap();
			corpMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, payment.getCorporateCode());
			corpMap = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, corpMap);
			
			if(payment.getPaymentSource().equals(DatabaseConstants.SourceCodes.CreditCard)){
				CommonBusinessOperations.cancelCreditCardCollection(payment.getPaymentCardNo(), "7011", txNo, payment.getCrdMerchantCode(), 
						payment.getPaymentAmount(), "TRY", commissionRecord.getCommissionAmount().add(commissionRecord.getBsmvAmount()), payment.getTxNo());
			}
			
			if (corpMap.getString(MapKeys.IS_ONLINE_CORPORATE).equals("1") && paymentLog.isCallCorporate()) {
				//Online kurum
				oMap.put(MapKeys.BANK_CODE, corpMap.getString(MapKeys.BANK_CODE));
				oMap.put(MapKeys.CORPORATE_CODE, corpMap.getString(MapKeys.CORPORATE_CODE));
				oMap.put(MapKeys.GM_SERVICE_NAME, TransactionConstants.CancelInvoicePayment.SERVICE_NAME);
				oMap.put(MapKeys.IS_MANDATORY_SERVICE, true);
				
				oMap.put("OID", payment.getOid());
				oMap.put("STATUS", payment.isStatus());
				oMap.put("CORPORATE_CODE", payment.getCorporateCode());
				oMap.put("INVOICE_MAIN_OID", payment.getInvoiceMainOid());
				oMap.put("COLLECTION_TYPE", payment.getCollectionType());			
				oMap.put("SUB_COLLECTION_TYPE", payment.getSubCollectionType());
				oMap.put("SUBSCRIBER_NO_1", payment.getSubscriberNo1());
				oMap.put("SUBSCRIBER_NO_2", payment.getSubscriberNo2());
				oMap.put("SUBSCRIBER_NO_3", payment.getSubscriberNo3());
				oMap.put("SUBSCRIBER_NO_4", payment.getSubscriberNo4());			
				oMap.put("STANDING_ORDER_ID", payment.getStandingOrderOid());
				oMap.put("PAYMENT_STATUS", payment.getPaymentStatus());
				oMap.put("INVOICE_NO", payment.getInvoiceNo());
				oMap.put("INVOICE_DATE", payment.getInvoiceDate());
				oMap.put("INVOICE_AMOUNT", payment.getInvoiceAmount());			
				oMap.put("PAYMENT_AMOUNT", payment.getPaymentAmount());
				oMap.put("CORPORATE_ACCOUNT_NO", payment.getCorporateAccountNo());
				oMap.put("IS_COMMISSION_EXIST", payment.getIsCommissionExist());
				oMap.put("PAYMENT_SOURCE", payment.getPaymentSource());
				oMap.put("PAYMENT_ACCOUNT_NO", payment.getPaymentAccountNo());			
				oMap.put("IBAN", payment.getIban());
				oMap.put("ACCOUNT_BALANCE", payment.getAccountBalance());
				oMap.put("PAYMENT_CARD_NO", payment.getPaymentCardNo());
				oMap.put("PAYMENT_CHANNEL", payment.getPaymentChannel());
				oMap.put("PAYMENT_BRANCH", payment.getPaymentBranch());			
				oMap.put("STAN_NO", payment.getStanNo());
				oMap.put("CORPORATE_PAYMENT_ID", payment.getCorporatePaymentId());
				oMap.put("INVOICE_CURRENCY_CODE", payment.getInvoiceCurrencyCode());
				oMap.put("ACCOUNT_CURRENCY_CODE", payment.getAccountCurrencyCode());
				oMap.put("EXCHANGE_RATE", payment.getExchangeRate());			
				oMap.put("PAYMENT_DATE", payment.getPaymentDate());
				oMap.put("CANCEL_DATE", payment.getCancelDate());
				oMap.put("CANCEL_TRX_NUMBER", payment.getCancelTrxNumber());
				oMap.put("PARAMETER_1", payment.getParameter1());
				oMap.put("PARAMETER_2", payment.getParameter2());			
				oMap.put("PARAMETER_3", payment.getParameter3());
				oMap.put("PARAMETER_4", payment.getParameter4());
				oMap.put("PARAMETER_5", payment.getParameter5());
				oMap.put("PARAMETER_6", payment.getParameter6());
				oMap.put("PARAMETER_7", payment.getParameter7());
				
				oMap.put("PARAMETER_8", payment.getParameter8());
				oMap.put("PARAMETER_9", payment.getParameter9());
				oMap.put("PARAMETER_10", payment.getParameter10());
				oMap.put("PARAMETER_11", payment.getParameter11());
				oMap.put("PARAMETER_12", payment.getParameter12());
				oMap.put("PARAMETER_13", payment.getParameter13());
				oMap.put("PARAMETER_14", payment.getParameter14());
				oMap.put("PARAMETER_15", payment.getParameter15());
				oMap.put("PARAMETER_16", payment.getParameter16());
				oMap.put("PARAMETER_17", payment.getParameter17());
				oMap.put("PARAMETER_18", payment.getParameter18());
				oMap.put("PARAMETER_19", payment.getParameter19());
				oMap.put("PARAMETER_20", payment.getParameter20());
				
				oMap.put(MapKeys.TRX_NO, payment.getTxNo());
				oMap.put("PAYER_PHONE", payment.getPayerPhone());
				oMap.put("PAYER_CUSTOMER", payment.getPayerCustomer());
				oMap.put("PAYER_PID_NO", payment.getPayerPidno());
				oMap.put("PAYER_TAX_NO", payment.getPayerTaxNo());			
				oMap.put("INSTALLMENT_NO", payment.getInstallmentNo());
				oMap.put("INVOICE_DUE_DATE", payment.getInvoiceDueDate());
				oMap.put("TERM_MONTH", payment.getTermMonth());
				oMap.put("TERM_YEAR", payment.getTermYear());
				oMap.put("ZONE_CODE", payment.getZoneCode());			
				oMap.put("SUBSCRIBER_NAME", payment.getSubscriberName());
				oMap.put("CANCEL_USER", payment.getCancelUser());
				oMap.put("REJECTED_REASON_CODE", payment.getRejectedReasonCode());
				oMap.put("REJECTED_REASON", payment.getRejectedReason());
				oMap.put(MapKeys.STAN_NO,CorporationServiceUtil.getSequenceCode(GeneralConstants.StanNoSequenceKey));
				
				CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", oMap);
			}
			
			paymentLog.setCancelStatus(DatabaseConstants.PaymentCancelStatuses.Approved);
			hibernateSession.saveOrUpdate(paymentLog);
			hibernateSession.flush();
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}		
	
	@GraymoundService("ICS_AFTER_CANCEL_REJECTED")
	public static GMMap afterCancelRejected(GMMap input) {
		GMMap output = new GMMap();
		
		try{
			// Code block deleted because of reverting payment of multi invoices with cash
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_COLLECT_INVOICES_FRONTEND")
	public static GMMap collectInvoicesFrontend(GMMap input){
		GMMap output = new GMMap();
		
		final String INVOICES = "INVOICES";
		final String PROPERTIES = "PROPERTIES";
		
		try{
			int size = input.getSize(INVOICES);
			
			String source = input.getString("SOURCE_CODE");			
			Object currentDate = new Date();
			String channelId = CommonHelper.getChannelId();
			BigDecimal totalAmount = BigDecimal.ZERO;
			BigDecimal trxNo = input.getBigDecimal(MapKeys.TRX_NO);
			
			List<String> controlledCorporates = new ArrayList<String>();
			
			for(int i = 0; i < size; i++){
				if(input.getBoolean(INVOICES, i, "SELECT")){
					String corporateCode = input.getString(INVOICES, i, "CORPORATE_CODE");
					if(!controlledCorporates.contains(corporateCode)){
						GMMap corporateDefinitionResult = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
								new GMMap().put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode));
						String corporateOid = corporateDefinitionResult.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID);
						GMMap controlMap = new GMMap();
						controlMap.put(TransactionConstants.CorporateChannelWorkingHourControl.Input.CHANNEL_CODE,
								channelId);
						controlMap.put(TransactionConstants.CorporateChannelWorkingHourControl.Input.CORPORATE_OID,
								corporateOid);
						controlMap.put(TransactionConstants.CorporateChannelWorkingHourControl.Input.SOURCE_CODE,
								source);
						controlMap.put(TransactionConstants.CorporateChannelWorkingHourControl.Input.DATE,
								currentDate);
						CommonHelper.callGraymoundServiceInHibernateSession(
										TransactionConstants.CorporateChannelWorkingHourControl.SERVICE_NAME,
										controlMap);
						controlledCorporates.add(corporateCode);
					}
					totalAmount = totalAmount.add(input.getBigDecimal(INVOICES, i, "COLLECTION_AMOUNT"));
					if(input.getBigDecimal(INVOICES, i, "COMMISSION_AMOUNT") != null && input.getBigDecimal(INVOICES, i, "COMMISSION_AMOUNT") != BigDecimal.ZERO){
						totalAmount = totalAmount.add(input.getBigDecimal(INVOICES, i, "COMMISSION_AMOUNT"));
					}
				}
			}
			
			String accountNo = "0";
			if(source.equals(DatabaseConstants.SourceCodes.Account)){
				accountNo = input.getString("ACCOUNT_NO");
			}
			
//			if(source.equals(DatabaseConstants.SourceCodes.Cash)){
//				CommonHelper.callGraymoundServiceOutsideSession("ICS_FRONTEND_INVOICE_COLLECTION_CASH_CONTROL", new GMMap().put("TRX_NO", trxNo).put("AMOUNT", totalAmount));
//			}
			
			String iban = input.getString("IBAN");
			String balance = input.getString("BALANCE");
			String currencyCode = input.getString("CURRENCY_CODE");
			String branchCode = String.valueOf(CommonHelper.getUserBranch()); //input.getString("BRANCH");
			String customerNo = input.getString("CUSTOMER_NO");
			String customerName = input.getString("CUSTOMER_NAME", null);
			BigDecimal availableBalance = input.getBigDecimal("AVAILABLE_BALANCE", null);
			
			if(!"0".equals(accountNo) && input.getString("RECALCULATE_BALANCES", "0").equals("1")){
				GMMap balanceResponse = CommonHelper.callGraymoundServiceInHibernateSession("ICS_GET_ACCOUNT_INFORMATION_FRONTEND", 
						new GMMap().put("ACCOUNT_NO", accountNo));
				availableBalance = balanceResponse.getBigDecimal("AVAILABLE_BALANCE");
				balance = balanceResponse.getString("BALANCE");
			}
			
			GMMap staticColorMap = new GMMap();
			staticColorMap.put("setBackground", Color.WHITE);
			staticColorMap.put("setForeground", Color.BLACK);
			//staticColorMap.put("setEnabled", true);
			
			GMMap colorMap = new GMMap();
			colorMap.put("setBackground", Color.GREEN);
			colorMap.put("setForeground", Color.BLACK);
			//colorMap.put("setEnabled", false);
			
			BigDecimal totalCashPaymentFailedAmount = BigDecimal.ZERO;
			
			StringBuilder messageBuilder = new StringBuilder();
			int counter = 0;
			messageBuilder.append("<html><center>��lem Sonu�lar�n�z A�a��daki Gibidir:<br>");
			StringBuilder connTxNosBuilder = new StringBuilder();
			connTxNosBuilder.append("Bu sayfada yer alan kasa k�p�rleri ");
			for(int i = 0; i < size; i++){
				Date dueDate = input.getDate(INVOICES, i,MapKeys.INVOICE_DUE_DATE);
				Date date = input.getDate(INVOICES, i,MapKeys.INVOICE_DATE);
				String subscriberNo = input.getString(INVOICES, i,"SUBSCRIBER_NO");
				output.put(INVOICES, i, "COLLECTION_AMOUNT", input.getBigDecimal(INVOICES, i, "COLLECTION_AMOUNT"));
				output.put(INVOICES, i, "COMMISSION_AMOUNT", input.getBigDecimal(INVOICES, i, "COMMISSION_AMOUNT"));
				output.put(INVOICES, i, "CORPORATE_CODE", input.getString(INVOICES, i, "CORPORATE_CODE"));
				output.put(INVOICES, i, "CORPORATE_NAME", input.getString(INVOICES, i, "CORPORATE_NAME"));
				output.put(INVOICES, i, "INVOICE_AMOUNT", input.getBigDecimal(INVOICES, i, "INVOICE_AMOUNT"));
				output.put(INVOICES, i, "INVOICE_DUE_DATE", dueDate);
				output.put(INVOICES, i, "INVOICE_DATE", date);
				output.put(INVOICES, i, "INVOICE_NO", input.getString(INVOICES, i, "INVOICE_NO"));
				output.put(INVOICES, i, "INVOICE_TERM_MONTH", input.getString(INVOICES, i, "INVOICE_TERM_MONTH"));
				output.put(INVOICES, i, "INVOICE_TERM_YEAR", input.getString(INVOICES, i, "INVOICE_TERM_YEAR"));
				output.put(INVOICES, i, "INVOICE_TERM", input.getString(INVOICES, i, "INVOICE_TERM"));
				output.put(INVOICES, i, "PAYMENT_TYPE_NAME", input.getString(INVOICES, i, "PAYMENT_TYPE_NAME"));
				output.put(INVOICES, i, "PAYMENT_TYPE", input.getString(INVOICES, i, "PAYMENT_TYPE"));
				output.put(INVOICES, i, "SUBSCRIBER_NAME", input.getString(INVOICES, i, "SUBSCRIBER_NAME"));
				output.put(INVOICES, i, "SUBSCRIBER_NO", subscriberNo);
				output.put(INVOICES, i, "SELECT", input.getBoolean(INVOICES, i, "SELECT"));
				output.put(INVOICES, i, "OID", input.getString(INVOICES, i, "OID"));
				output.put(INVOICES, i, "ALLOW_PART_PAYMENT", input.getString(INVOICES, i, "ALLOW_PART_PAYMENT"));
				output.put(INVOICES, i, "CORPORATE_STAN_KEY", input.getString(INVOICES, i, "CORPORATE_STAN_KEY"));
				output.put(INVOICES, i, "SUBSCRIBER_HASH", input.getString(INVOICES, i, "SUBSCRIBER_HASH"));
				output.put(INVOICES, i, MapKeys.INSTALLMENT_NO, input.getString(INVOICES, i, MapKeys.INSTALLMENT_NO));
				output.put(INVOICES, i, MapKeys.PARAMETER1, input.getString(INVOICES, i, MapKeys.PARAMETER1));
				output.put(INVOICES, i, MapKeys.PARAMETER2, input.getString(INVOICES, i, MapKeys.PARAMETER2));
				output.put(INVOICES, i, MapKeys.PARAMETER3, input.getString(INVOICES, i, MapKeys.PARAMETER3));
				output.put(INVOICES, i, MapKeys.PARAMETER4, input.getString(INVOICES, i, MapKeys.PARAMETER4));
				output.put(INVOICES, i, MapKeys.PARAMETER5, input.getString(INVOICES, i, MapKeys.PARAMETER5));
				output.put(INVOICES, i, MapKeys.PARAMETER6, input.getString(INVOICES, i, MapKeys.PARAMETER6));
				output.put(INVOICES, i, MapKeys.PARAMETER7, input.getString(INVOICES, i, MapKeys.PARAMETER7));
				
				output.put(INVOICES, i, MapKeys.PARAMETER8, input.getString(INVOICES, i, MapKeys.PARAMETER8));
				output.put(INVOICES, i, MapKeys.PARAMETER9, input.getString(INVOICES, i, MapKeys.PARAMETER9));
				output.put(INVOICES, i, MapKeys.PARAMETER10, input.getString(INVOICES, i, MapKeys.PARAMETER10));
				output.put(INVOICES, i, MapKeys.PARAMETER11, input.getString(INVOICES, i, MapKeys.PARAMETER11));
				output.put(INVOICES, i, MapKeys.PARAMETER12, input.getString(INVOICES, i, MapKeys.PARAMETER12));
				output.put(INVOICES, i, MapKeys.PARAMETER13, input.getString(INVOICES, i, MapKeys.PARAMETER13));
				output.put(INVOICES, i, MapKeys.PARAMETER14, input.getString(INVOICES, i, MapKeys.PARAMETER14));
				
				output.put(INVOICES, i, MapKeys.PARAMETER15, input.getString(INVOICES, i, MapKeys.PARAMETER15));
				output.put(INVOICES, i, MapKeys.PARAMETER16, input.getString(INVOICES, i, MapKeys.PARAMETER16));
				output.put(INVOICES, i, MapKeys.PARAMETER17, input.getString(INVOICES, i, MapKeys.PARAMETER17));
				output.put(INVOICES, i, MapKeys.PARAMETER18, input.getString(INVOICES, i, MapKeys.PARAMETER18));
				output.put(INVOICES, i, MapKeys.PARAMETER19, input.getString(INVOICES, i, MapKeys.PARAMETER19));
				output.put(INVOICES, i, MapKeys.PARAMETER20, input.getString(INVOICES, i, MapKeys.PARAMETER20));
				
				if (input.getBoolean(INVOICES, i, "SELECT")) {
					BigDecimal currentCollectionAmount = input.getBigDecimal(INVOICES, i, "COLLECTION_AMOUNT");
					BigDecimal currentCommissionAmount = input.getBigDecimal(INVOICES, i, "COMMISSION_AMOUNT");
					try {
						GMMap invoiceCollectionMap = new GMMap();
						if (source.equals(DatabaseConstants.SourceCodes.Account)) {
							invoiceCollectionMap
									.put(TransactionConstants.DoInvoiceCollection.Input.ACCOUNT_CURRENCY_CODE,
											currencyCode);
							invoiceCollectionMap
								.put(TransactionConstants.DoInvoiceCollection.Input.ACCOUNT_BALANCE,
										new BigDecimal(balance));
							invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.IBAN_NO,
									iban);
						}
						
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.BRANCH_CODE,
								branchCode);

						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.COLLECTION_TYPE_NAME,input.get(INVOICES, i, MapKeys.PAYMENT_TYPE_NAME).toString());
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.COLLECTION_TYPE,input.get(INVOICES, i, MapKeys.PAYMENT_TYPE).toString()); 
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.COMMISSION_AMOUNT,
								currentCommissionAmount);
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.CORPORATE_CODE,
								input.getString(INVOICES, i, "CORPORATE_CODE"));
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.CUSTOMER_NO,
								customerNo);
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.INVOICE_MAIN_OID,
								input.getString(INVOICES, i, "OID"));
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_ACCOUNT_NO,
								new BigDecimal(accountNo));
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PAYMENT_AMOUNT,
								currentCollectionAmount);
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.SOURCE,
								source);
						
						Map<Integer, String> subscriberNoMap = getSubscriberNoMap(input.getString(INVOICES, i,"SUBSCRIBER_NO"));
						
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.INVOICE_AMOUNT,input.getBigDecimal(INVOICES, i, "INVOICE_AMOUNT"));
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.INVOICE_NO,input.getString(INVOICES, i, "INVOICE_NO"));
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.TERM_MONTH,input.getString(INVOICES, i, "INVOICE_TERM_MONTH"));
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.TERM_YEAR,input.getString(INVOICES, i, "INVOICE_TERM_YEAR"));
						invoiceCollectionMap.put(MapKeys.INSTALLMENT_NO,input.getString(INVOICES, i, MapKeys.INSTALLMENT_NO));//? installment filan nas�l olcak
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NAME, input.getString(INVOICES, i, "SUBSCRIBER_NAME"));
						for (Map.Entry<Integer, String> entry : subscriberNoMap.entrySet()) {
							switch(entry.getKey()){
							case 1: 
								invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO1, entry.getValue());
								break;
							case 2:
								invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO2, entry.getValue());
								break;
							case 3:
								invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO3, entry.getValue());
								break;
							case 4:
								invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.SUBSCRIBER_NO4, entry.getValue());
								break;
							default:
								break;
							}
						}
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.INVOICE_DUE_DATE, input.getString(INVOICES, i,MapKeys.INVOICE_DUE_DATE));
						if(!StringUtil.isEmpty(input.getString(INVOICES, i, "CORPORATE_STAN_KEY"))){
							invoiceCollectionMap.put("CORPORATE_STAN_KEY", input.getString(INVOICES, i, "CORPORATE_STAN_KEY"));
						}
						if (input.getString(INVOICES, i, MapKeys.PARAMETER1)!=null) {
							invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PARAMETER1,input.getString(INVOICES, i, MapKeys.PARAMETER1));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER2)!=null) {
							invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PARAMETER2,input.getString(INVOICES, i, MapKeys.PARAMETER2));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER3)!=null) {
							invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PARAMETER3,input.getString(INVOICES, i, MapKeys.PARAMETER3));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER4)!=null) {
							invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PARAMETER4,input.getString(INVOICES, i, MapKeys.PARAMETER4));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER5)!=null) {
							invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PARAMETER5,input.getString(INVOICES, i, MapKeys.PARAMETER5));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER6)!=null) {
							invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PARAMETER6,input.getString(INVOICES, i, MapKeys.PARAMETER6));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER7)!=null) {
							invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PARAMETER7,input.getString(INVOICES, i, MapKeys.PARAMETER7));
						}
						


						if (input.getString(INVOICES, i, MapKeys.PARAMETER8)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER8,input.getString(INVOICES, i, MapKeys.PARAMETER8));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER9)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER9,input.getString(INVOICES, i, MapKeys.PARAMETER9));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER10)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER10,input.getString(INVOICES, i, MapKeys.PARAMETER10));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER11)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER11,input.getString(INVOICES, i, MapKeys.PARAMETER11));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER12)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER12,input.getString(INVOICES, i, MapKeys.PARAMETER12));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER13)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER13,input.getString(INVOICES, i, MapKeys.PARAMETER13));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER14)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER14,input.getString(INVOICES, i, MapKeys.PARAMETER14));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER15)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER15,input.getString(INVOICES, i, MapKeys.PARAMETER15));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER16)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER16,input.getString(INVOICES, i, MapKeys.PARAMETER16));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER17)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER17,input.getString(INVOICES, i, MapKeys.PARAMETER17));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER18)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER18,input.getString(INVOICES, i, MapKeys.PARAMETER18));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER19)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER19,input.getString(INVOICES, i, MapKeys.PARAMETER19));
						}
						
						if (input.getString(INVOICES, i, MapKeys.PARAMETER20)!=null) {
							invoiceCollectionMap.put(MapKeys.PARAMETER20,input.getString(INVOICES, i, MapKeys.PARAMETER20));
						}
						
						invoiceCollectionMap.put("SUBSCRIBER_HASH",input.getString(INVOICES, i, "SUBSCRIBER_HASH"));				
						
						BigDecimal transactionNo = null;
						
						if(source.equals(DatabaseConstants.SourceCodes.Cash)){
							transactionNo = trxNo;
						}
						else{
							transactionNo = getNewTransactionNo();
						}
						
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.TRX_NO, transactionNo);
						
						if(source.equals(DatabaseConstants.SourceCodes.Cash)){
							invoiceCollectionMap.put("CASH_TRX_NO", trxNo);
						}
						
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.CALCULATE_COMMISSION, "1");
						invoiceCollectionMap.put("CASH_IDENTITY_TYPE",input.getBigDecimal("CASH_IDENTITY_TYPE"));								
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.ACCOUNT_AVAILABLE_BALANCE, availableBalance);
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.PAYER_NAME, customerName);
						invoiceCollectionMap.put(TransactionConstants.DoInvoiceCollection.Input.INVOICE_DATE, input.getString(INVOICES, i, "INVOICE_DATE"));
						
						GMMap collectionOutput = CommonHelper.callGraymoundServiceOutsideSession(TransactionConstants.DoInvoiceCollection.SERVICE_NAME, invoiceCollectionMap);
						
						if(collectionOutput.getBoolean("WAITING_APPROVAL")){
							messageBuilder.append(transactionNo + " numaral� i�lem onay beklemektedir.");
							messageBuilder.append("<br>");
							
							output.put(INVOICES, i, "SELECT", false);
							output.put(INVOICES, i, "IS_PAID", "1");
							output.put(INVOICES, i, "STATE_TEXT", "Onaya G�nderildi");
						}
						else{
							messageBuilder.append(transactionNo + " numaral� i�lem tamamlanm��t�r.");
							output.put("TRANSACTION_TABLE", counter++, "TRANSACTION_NO", transactionNo);
							messageBuilder.append("<br>");
							connTxNosBuilder.append(transactionNo.toPlainString().concat("-"));
							
							output.put(INVOICES, i, "SELECT", false);
							output.put(INVOICES, i, "IS_PAID", "1");
							output.put(INVOICES, i, "STATE_TEXT", "�dendi");
						}
						
						output.put(PROPERTIES, i, "COLLECTION_AMOUNT", colorMap);
						output.put(PROPERTIES, i, "COMMISSION_AMOUNT", colorMap);
						output.put(PROPERTIES, i, "CORPORATE_CODE", colorMap);
						output.put(PROPERTIES, i, "CORPORATE_NAME", colorMap);
						output.put(PROPERTIES, i, "INVOICE_AMOUNT", colorMap);
						output.put(PROPERTIES, i, "INVOICE_DUE_DATE", colorMap);
						output.put(PROPERTIES, i, "INVOICE_DATE", colorMap);
						output.put(PROPERTIES, i, "INVOICE_NO", colorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM_MONTH", colorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM_YEAR", colorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM", colorMap);
						output.put(PROPERTIES, i, "PAYMENT_TYPE_NAME", colorMap);
						output.put(PROPERTIES, i, "PAYMENT_TYPE", colorMap);
						output.put(PROPERTIES, i, "SUBSCRIBER_NAME", colorMap);
						output.put(PROPERTIES, i, "SUBSCRIBER_NO", colorMap);
						output.put(PROPERTIES, i, "SELECT", colorMap);
						output.put(PROPERTIES, i, "OID", colorMap);
						output.put(PROPERTIES, i, "ALLOW_PART_PAYMENT", colorMap);
						output.put(PROPERTIES, i, "STATE_TEXT", colorMap);
						output.put(PROPERTIES, i, "DESCRIPTION", colorMap);
					} catch (Exception e) {
						logger.error(System.currentTimeMillis(), e);
						output.put(PROPERTIES, i, "COLLECTION_AMOUNT", staticColorMap);
						output.put(PROPERTIES, i, "COMMISSION_AMOUNT", staticColorMap);
						output.put(PROPERTIES, i, "CORPORATE_CODE", staticColorMap);
						output.put(PROPERTIES, i, "CORPORATE_NAME", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_AMOUNT", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_DUE_DATE", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_DATE", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_NO", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM_MONTH", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM_YEAR", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM", staticColorMap);
						output.put(PROPERTIES, i, "PAYMENT_TYPE_NAME", staticColorMap);
						output.put(PROPERTIES, i, "PAYMENT_TYPE", staticColorMap);
						output.put(PROPERTIES, i, "SUBSCRIBER_NAME", staticColorMap);
						output.put(PROPERTIES, i, "SUBSCRIBER_NO", staticColorMap);
						output.put(PROPERTIES, i, "SELECT", staticColorMap);
						output.put(PROPERTIES, i, "OID", staticColorMap);
						output.put(PROPERTIES, i, "ALLOW_PART_PAYMENT", staticColorMap);
						output.put(PROPERTIES, i, "STATE_TEXT", staticColorMap);
						output.put(PROPERTIES, i, "DESCRIPTION", staticColorMap);
						output.put(INVOICES, i, "IS_PAID", "0");
						messageBuilder.append(String.format("%s fatura numaras�na ait i�lem hata alm��t�r : %s", input.getString(INVOICES, i, MapKeys.INVOICE_NO), e.getMessage()));
						messageBuilder.append("<br>");
					}
					
				}
				else{
					if("0".equals(input.getString(INVOICES, i, "IS_PAID"))){
						output.put(PROPERTIES, i, "COLLECTION_AMOUNT", staticColorMap);
						output.put(PROPERTIES, i, "COMMISSION_AMOUNT", staticColorMap);
						output.put(PROPERTIES, i, "CORPORATE_CODE", staticColorMap);
						output.put(PROPERTIES, i, "CORPORATE_NAME", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_AMOUNT", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_DUE_DATE", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_DATE", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_NO", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM_MONTH", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM_YEAR", staticColorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM", staticColorMap);
						output.put(PROPERTIES, i, "PAYMENT_TYPE_NAME", staticColorMap);
						output.put(PROPERTIES, i, "PAYMENT_TYPE", staticColorMap);
						output.put(PROPERTIES, i, "SUBSCRIBER_NAME", staticColorMap);
						output.put(PROPERTIES, i, "SUBSCRIBER_NO", staticColorMap);
						output.put(PROPERTIES, i, "SELECT", staticColorMap);
						output.put(PROPERTIES, i, "OID", staticColorMap);
						output.put(PROPERTIES, i, "ALLOW_PART_PAYMENT", staticColorMap);
						output.put(PROPERTIES, i, "STATE_TEXT", staticColorMap);
						output.put(PROPERTIES, i, "DESCRIPTION", staticColorMap);
						output.put(INVOICES, i, "IS_PAID", "0");
					}
					else{
						output.put(PROPERTIES, i, "COLLECTION_AMOUNT", colorMap);
						output.put(PROPERTIES, i, "COMMISSION_AMOUNT", colorMap);
						output.put(PROPERTIES, i, "CORPORATE_CODE", colorMap);
						output.put(PROPERTIES, i, "CORPORATE_NAME", colorMap);
						output.put(PROPERTIES, i, "INVOICE_AMOUNT", colorMap);
						output.put(PROPERTIES, i, "INVOICE_DUE_DATE", colorMap);
						output.put(PROPERTIES, i, "INVOICE_DATE", colorMap);
						output.put(PROPERTIES, i, "INVOICE_NO", colorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM_MONTH", colorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM_YEAR", colorMap);
						output.put(PROPERTIES, i, "INVOICE_TERM", colorMap);
						output.put(PROPERTIES, i, "PAYMENT_TYPE_NAME", colorMap);
						output.put(PROPERTIES, i, "PAYMENT_TYPE", colorMap);
						output.put(PROPERTIES, i, "SUBSCRIBER_NAME", colorMap);
						output.put(PROPERTIES, i, "SUBSCRIBER_NO", colorMap);
						output.put(PROPERTIES, i, "SELECT", colorMap);
						output.put(PROPERTIES, i, "OID", colorMap);
						output.put(PROPERTIES, i, "ALLOW_PART_PAYMENT", colorMap);
						output.put(INVOICES, i, "SELECT", false);
						output.put(INVOICES, i, "IS_PAID", "1");
						output.put(PROPERTIES, i, "STATE_TEXT", colorMap);
						output.put(PROPERTIES, i, "DESCRIPTION", colorMap);
					}
				}
			}
			connTxNosBuilder.deleteCharAt(connTxNosBuilder.toString().length() - 1);
			connTxNosBuilder.append(" numaral� i�lemler i�in al�nm��t�r.");
			messageBuilder.append("Ba�ar�l� i�lemleriniz i�in dekontlar�n�z yaz�c�ya g�nderilmi�tir.</center></html>");
			
			
			output.put("MUST_PAYBACK_FAILED_PAYMENTS", false);
			output.put("TOTAL_FAILED_AMOUNT", totalCashPaymentFailedAmount);
			
			output.put("CONN_TX_NO_MESSAGE", connTxNosBuilder.toString());
			
			output.put("MESSAGE", "Tahsilat i�lem(ler)iniz ba�ar�yla tamamlanm��t�r.");
			
			output.put("COLLECTION_MESSAGES", messageBuilder.toString());
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_FRONTEND_INVOICE_COLLECTION_CASH_CONTROL")
	public static GMMap controlCashPaymentFrontendCollection(GMMap input){
		GMMap output = new GMMap();
		
		try{
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			BigDecimal amount = input.getBigDecimal("AMOUNT");
			DALUtil.callOracleProcedure("{call Pkg_TRN2021.Kontrol_Sonrasi(?,?,?,?,?)}", 
					new Object[] {BnsprType.NUMBER, trxNo, BnsprType.NUMBER, new BigDecimal(7010), 
									BnsprType.NUMBER, amount, BnsprType.STRING, "TRY", BnsprType.STRING, "Y" }, new Object[0]);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_PAYBACK_AFTER_FAILED_CASH_PAYMENTS")
	public static GMMap paybackAfterFailedCashPayments(GMMap input){
		GMMap output = new GMMap();
		String accountNo = CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "MULTI_CASH_ACC_NO");
		try{
			GMMap cashBackRequest = new GMMap();
			cashBackRequest.put("ACIKLAMA", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "MULTI_CASH_CANCEL_DESC"));
			cashBackRequest.put("TUTAR", input.getBigDecimal("CASHBACK_AMOUNT"));
			cashBackRequest.put("DK_NO", accountNo);
			cashBackRequest.put("DOVIZ_KODU", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "MULTI_CASH_CUR_CODE"));
			cashBackRequest.put("REFERANS_NO", CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_TRN2017_GET_REFERANCE_NO", new GMMap()).getString("REFERANS_NO"));
			cashBackRequest.put("VALOR_TARIHI", new BankDate());
			cashBackRequest.put("MUSTERI_NO", "");
			cashBackRequest.put("ISLEM_SEKLI", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "MULTI_CASH_TRX_TYPE"));
			cashBackRequest.put("TRX_NO", input.getBigDecimal("CASHBACK_TRX_NO"));
			cashBackRequest.put("SUBE_KODU", input.getBigDecimal("BRANCH_CODE"));
			cashBackRequest.put("KIMLIK_TIPI", CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "MULTI_CASH_ID_TYPE"));
			cashBackRequest.put("HESAP_NO", "");
			cashBackRequest.put("TRX_ONAYSIZ_ISLEM", "E");
			GMServiceExecuter.execute("BNSPR_TRN2017_SAVE", cashBackRequest);
			output.put("RESULT", true);
		}
		catch(Exception e) {
			logger.error("An exception occured while doing cashback transaction");
			logger.error(System.currentTimeMillis(), e);
			output.put("ERROR_MESSAGE", String.format("Para ��k��� i�leminde bir hata olu�tu : %s. L�tfen hata ��z�mlendikten sonra %s numaral� DK hesab�ndan para ��k��� yap�n�z",
					e.getMessage(), accountNo));
			output.put("RESULT", false);
		}
		
		return output;
	}
	
	private static Map<Integer, String> getSubscriberNoMap(String string) {
		String[] subscriberNos = string.split(" ");
		Map<Integer, String> map = new HashMap<Integer, String>();
		for (int i = 0; i < subscriberNos.length; i++) {
			map.put(i + 1, subscriberNos[i]);
		}
		return map;
	}
	
	@GraymoundService("ICS_CONTROL_CANCEL_PAYMENTS")
	public static GMMap controlCancelPayments(GMMap input) {
		GMMap output = new GMMap();
		final String tableName = "PAYMENTS";
		
		try{
			String channel = CommonHelper.getChannelId();
			
			Session hibSession = CommonHelper.getHibernateSession();
			BigDecimal cashTotalAmount = BigDecimal.ZERO;
			for (int i = 0; i < input.getSize(tableName); i++) {
				if(input.getBoolean(tableName, i, "SELECT")){
					if(channel.equals("1")){
						String errorCodeDesc = input.getString(tableName,i,"ERROR_CODE_DESC");
						String errorCodeValue = input.getString(tableName,i,"ERROR_CODE");
						
						if(null == errorCodeDesc || null == errorCodeValue ){
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOENTERREASONCODEANDREASONDESC));
						}
					}
					String currentPaymentOid = input.getString(tableName, i, "OID");
					invoicePayment currentPayment = ((invoicePayment)hibSession.createCriteria(invoicePayment.class)
							.add(Restrictions.eq("oid", currentPaymentOid)).uniqueResult());
					
					if(currentPayment.getPaymentSource().equals(DatabaseConstants.SourceCodes.Cash)){
						cashTotalAmount = cashTotalAmount.add(currentPayment.getPaymentAmount());
						invoiceCommission commRecord = (invoiceCommission) hibSession.createCriteria(invoiceCommission.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("invoicePaymentOid", currentPaymentOid))
								.uniqueResult();
						
						if(commRecord != null){
							cashTotalAmount = cashTotalAmount.add(commRecord.getBsmvAmount().add(commRecord.getCommissionAmount()));
						}
					}
				}
			}
			
			output.put("CASH_PAYMENT_AMOUNT", cashTotalAmount);
			
			
			output.put("CASH_PAYMENT_EXISTS", false);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

	@GraymoundService("ICS_CANCEL_PAYMENTS_FRONTEND")
	public static GMMap cancePaymentsFrontend(GMMap iMap){
		GMMap output = new GMMap();
		
		final String tableName = "PAYMENTS";
		
		try{
			int size = iMap.getSize(tableName);
			
			String channel = CommonHelper.getChannelId();
			Session hibernateSession = CommonHelper.getHibernateSession();
						
			List<String> controlledCorporates = new ArrayList<String>();
			
			boolean cashPaymentExists = iMap.getBoolean("CASH_PAYMENT_EXISTS", false);
			if(cashPaymentExists){
				BigDecimal totalAmount = iMap.getBigDecimal("CASH_TOTAL_AMOUNT");
				DALUtil.callOracleProcedure("{call Pkg_TRN2021.Kontrol_Sonrasi(?,?,?,?,?)}", 
						new Object[] {BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"), BnsprType.NUMBER, new BigDecimal(2017), 
										BnsprType.NUMBER, totalAmount, BnsprType.STRING, "TRY", BnsprType.STRING, "C" }, new Object[0]);
			}
			
			for(int i = 0; i < size; i++){				
				if(iMap.getBoolean(tableName, i, "SELECT")) {
					if(channel.equals("1") && !iMap.getBoolean("DO_NOT_CHECK_CODE", false)){
						String errorCodeDesc = iMap.getString(tableName,i,"ERROR_CODE_DESC");
						String errorCodeValue = iMap.getString(tableName,i,"ERROR_CODE");
					
						if( null == errorCodeDesc || null == errorCodeValue ){
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOENTERREASONCODEANDREASONDESC));
						}
					}
					
					String oid = iMap.getString(tableName, i, "OID");
					
					Object currentDate = new Date();
					
					invoicePayment payment = ((invoicePayment)hibernateSession.createCriteria(invoicePayment.class)
												.add(Restrictions.eq("oid", oid)).uniqueResult());					
					
					String source = payment.getPaymentSource();
					String channelId = payment.getPaymentChannel();
					String corporateCode = payment.getCorporateCode();
					
					if(!controlledCorporates.contains(corporateCode)){
						GMMap corporateDefinitionResult = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, 
								new GMMap().put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode));
						String corporateOid = corporateDefinitionResult.getString(TransactionConstants.GetCorporateDefinition.Output.CORPORATE_OID);
						GMMap controlMap = new GMMap();
						controlMap.put(TransactionConstants.CorporateChannelWorkingHourControl.Input.CHANNEL_CODE,
								channelId);
						controlMap.put(TransactionConstants.CorporateChannelWorkingHourControl.Input.CORPORATE_OID,
								corporateOid);
						controlMap.put(TransactionConstants.CorporateChannelWorkingHourControl.Input.SOURCE_CODE,
								source);
						controlMap.put(TransactionConstants.CorporateChannelWorkingHourControl.Input.DATE,
								currentDate);
						CommonHelper.callGraymoundServiceInHibernateSession(
										TransactionConstants.CorporateChannelWorkingHourControl.SERVICE_NAME,
										controlMap);
						controlledCorporates.add(corporateCode);
					}
				}
			}
						
			for(int i = 0; i < size; i++){
				if (iMap.getBoolean(tableName, i, "SELECT")) {
					GMMap invoiceCancelationMap = new GMMap();
					
					String currentPaymentOid = iMap.getString(tableName, i, "OID");					
					
					invoicePayment currentPayment = ((invoicePayment)hibernateSession.createCriteria(invoicePayment.class)
							.add(Restrictions.eq("oid", currentPaymentOid)).uniqueResult());
					
					invoicePaymentLog currentPaymentLog = ((invoicePaymentLog)hibernateSession.createCriteria(invoicePaymentLog.class)
							.add(Restrictions.eq("txNo", currentPayment.getTxNo()))
							.add(Restrictions.eq("status", true))
							.add(Restrictions.eq("paymentStatus",  PaymentStatuses.Collected))
							.uniqueResult());					

					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.TRX_NO, getNewTransactionNo());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.INVOICE_MAIN_OID, currentPaymentLog.getInvoiceMainOid());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.INVOICE_PAYMENT_OID, currentPaymentOid);
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_CODE, currentPaymentLog.getCorporateCode());	
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_NAME, CommonBusinessOperations.getCorporateNameFromCorporateCode(currentPaymentLog.getCorporateCode()));
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.COLLECTION_TYPE, currentPaymentLog.getCollectionType());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.COLLECTION_TYPE_NAME, CommonBusinessOperations.getCollectionTypeName(currentPaymentLog.getCollectionType()));
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_AMOUNT, currentPaymentLog.getPaymentAmount());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.AMOUNT, currentPaymentLog.getInvoiceAmount());					
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_ACCOUNT_NO, currentPaymentLog.getPaymentAccountNo());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.IBAN_NO, currentPaymentLog.getIban());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.ACCOUNT_BALANCE, currentPaymentLog.getAccountBalance());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_CARD_NO, currentPaymentLog.getPaymentCardNo());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_ACCOUNT_NO, currentPaymentLog.getCorporateAccountNo());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CHANNEL_CODE, currentPaymentLog.getChannelCode());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.BRANCH_CODE, currentPaymentLog.getBranchCode());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_SOURCE, currentPaymentLog.getSourceCode());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_NO, currentPaymentLog.getPayerCustomer());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_PHONE, currentPaymentLog.getPayerPhone());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_ID_NO, currentPaymentLog.getPayerPidno());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CUSTOMER_TAX_NO, currentPaymentLog.getPayerTaxNo());								
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.ACCOUNT_CURRENCY_CODE, currentPaymentLog.getAccountCurrencyCode());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PAYMENT_DATE, currentPayment.getPaymentDate());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.CORPORATE_ACCOUNT_NO, currentPaymentLog.getCorporateAccountNo());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.INVOICE_NO, currentPaymentLog.getInvoiceNo());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.INVOICE_DATE, currentPaymentLog.getInvoiceDate());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.INVOICE_DUE_DATE, currentPaymentLog.getInvoiceDueDate());					
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.SUBSCRIBER_NO1, currentPaymentLog.getSubscriberNo1());					
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.SUBSCRIBER_NO2, currentPaymentLog.getSubscriberNo2());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.SUBSCRIBER_NO3, currentPaymentLog.getSubscriberNo3());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.SUBSCRIBER_NO4, currentPaymentLog.getSubscriberNo4());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PARAMETER1, currentPaymentLog.getParameter1());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PARAMETER2, currentPaymentLog.getParameter2());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PARAMETER3, currentPaymentLog.getParameter3());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PARAMETER4, currentPaymentLog.getParameter4());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PARAMETER5, currentPaymentLog.getParameter5());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PARAMETER6, currentPaymentLog.getParameter6());
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.PARAMETER7, currentPaymentLog.getParameter7());
					invoiceCancelationMap.put("CASHBACK_TRX_NO", iMap.getString("TRX_NO"));
					invoiceCancelationMap.put("CASHBACK_BRANCH_CODE", iMap.getString("SUBE_KODU"));
					invoiceCancelationMap.put("CASH_TOTAL_AMOUNT", iMap.getString("CASH_TOTAL_AMOUNT"));
					invoiceCancelationMap.put("CALL_CORPORATE", StringUtil.isEmpty(iMap.getString(tableName, i, "CALL_CORPORATE")) ?
							true : iMap.getBoolean(tableName, i, "CALL_CORPORATE"));
					
					/**
					 * Add Code For 189 issue 
					 */
					String errorCodeDesc = iMap.getString(tableName,i,"ERROR_CODE_DESC");
					String errorCodeValue = iMap.getString(tableName,i,"ERROR_CODE");
					
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON, errorCodeDesc);
					invoiceCancelationMap.put(TransactionConstants.CancelInvoicePayment.Input.REJECTED_REASON_CODE, errorCodeValue);
					if(iMap.getBoolean("BYPASS_APPROVE", false)){
						invoiceCancelationMap.put("TRX_ONAYSIZ_ISLEM", "E");
					}
					
					output = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.CancelInvoicePayment.SERVICE_NAME, invoiceCancelationMap);
				}
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}	
	
	private static BigDecimal getNewTransactionNo() {
		return new BigDecimal(CommonHelper.callGraymoundServiceInHibernateSession("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString(MapKeys.TRX_NO));
	}
	
	@GraymoundService("ICS_GET_PAYMENTS_BY_TRX_NO_FRONTEND")
	public static final GMMap getPaymentsByTxNo(GMMap input){
		GMMap output = new GMMap();
		try{
			if( null == input.getBigDecimal("TRX_NO") ){
				
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.REFERENCENOMUSTBESUPPLIED));
			}
			BigDecimal transactionNo = input.getBigDecimal("TRX_NO");
			String channelCode = input.getString("CHANNEL_CODE");
			
		    invoicePayment payment = (invoicePayment)CommonHelper.getHibernateSession().createCriteria(invoicePayment.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("queryRefNo", transactionNo))
					.add(Restrictions.eq("paymentChannel", channelCode))
					.uniqueResult();	
			
			if( null != payment ){
				output.put("CORPORATE_CODE", payment.getCorporateCode());
				output.put("PAY_STATUS", payment.getPaymentStatus());
				output.put("TRX_NO", payment.getTxNo());
				output.put("SUBSCRIBER_NAME", payment.getSubscriberName());
			}
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_CANCEL_PAYMENTS_BY_TRX_NO_FRONTEND")
	public static final GMMap cancelPaymentsByTxNo(GMMap input){
		GMMap output = new GMMap();
		
		final String PAYMENTS="PAYMENTS";
		
		try{
			BigDecimal transactionNo = input.getBigDecimal("TRX_NO");
			Session session = CommonHelper.getHibernateSession();
			invoicePayment payment = (invoicePayment)session.createCriteria(invoicePayment.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txNo", transactionNo))
					.uniqueResult();
			
			if(payment != null){
				GMMap cancelPaymentRequest = new GMMap();
				cancelPaymentRequest.put(PAYMENTS, 0, "SELECT", true);
				cancelPaymentRequest.put(PAYMENTS, 0, "OID", payment.getOid());
				cancelPaymentRequest.put(PAYMENTS, 0, "CALL_CORPORATE", input.getBoolean("CALL_CORPORATE", true));
				cancelPaymentRequest.put("DO_NOT_CHECK_CODE", input.getBoolean("DO_NOT_CHECK_CODE", false));
				cancelPaymentRequest.put("BYPASS_APPROVE", input.getBoolean("BYPASS_APPROVE", false));
				
				
				output = CommonHelper.callGraymoundServiceInHibernateSession("ICS_CANCEL_PAYMENTS_FRONTEND", cancelPaymentRequest);
				
				if(input.getBoolean("IGNORE_PAYMENT", false)){
					session.flush();
					payment = (invoicePayment)session.createCriteria(invoicePayment.class)
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("txNo", transactionNo))
									.uniqueResult();
					payment.setStatus(false);
					session.saveOrUpdate(payment);
					session.flush();
				}
			}
			else{
				CommonHelper.throwBusinessException(BusinessException.NOPAYMENTRECORDFOUND.getCode(), transactionNo);
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

	/**
	 * @description
	 * @param GMMap logMap
	 * @return GMMap outMap
	 * @history 
	 * 	@author erdogan.demir		
	 *  @date 10.06.2013
	 *  @specification
	 *		
	 */
	@GraymoundService("ICS_DO_INVOICE_COLLECTION")
	public static GMMap doInvoiceCollectionService(GMMap input){
		return RequestProcessor.getInstance().process(input, new DoInvoiceCollectionHandler());
	}
	
	@GraymoundService("ICS_INVOICE_COLLECTION_CANCEL")
	public static GMMap invoiceCollectionCancelService (GMMap iMap) {
		return RequestProcessor.getInstance().process(iMap, new CancelInvoicePaymentHandler());
	}
	
	@GraymoundService("ICS_GET_PAYMENTS_BY_CUSTOMER_NUMBER")
	public static GMMap getPaymentsByCustomerNumber (GMMap iMap) {
		return RequestProcessor.getInstance().process(iMap, new GetPaymentsByCustomerNumberHandler());
	}
	
	@GraymoundService("ICS_GET_ACCOUNT_INFORMATION_FRONTEND")
	public static GMMap getAccountInformationFrontEnd(GMMap input){
		GMMap outMap = new GMMap();
		
		try{
			final String tableName = "ACCOUNT";
			String accountNo = input.getString("ACCOUNT_NO");
			
			GMMap accountResults = DALUtil.getResults(String.format(QueryRepository.ServiceWrapperRepository.FETCH_ACCOUNT_INFO_QUERY, accountNo), tableName);
			
			if(accountResults.getSize(tableName) <= 0){
				outMap.put("CUSTOMER_NAME", "");
				outMap.put("BRANCH_CODE", "");
				outMap.put("CURRENCY_CODE", "");
				outMap.put("CUSTOMER_NO", "");
				outMap.put("IBAN", "");
				outMap.put("BALANCE", "");
				outMap.put("AVAILABLE_BALANCE", "");
			}
			
			GMMap getCustomerInfoRequest = new GMMap();
			getCustomerInfoRequest.put("HESAP_NO", accountNo);
			
			GMMap getCustomerInfoResponse = new GMMap();
			boolean errorOccured = false;
			
			try{
				getCustomerInfoResponse = GMServiceExecuter.call("BNSPR_COMMON_GET_DEFTER_BAKIYE", getCustomerInfoRequest);
			}
			catch(Exception e){
				errorOccured = true;
				logger.error("An exception occured while obtaining balance.");
				logger.error(System.currentTimeMillis(), e);
			}
			
			if(errorOccured || StringUtil.isEmpty(getCustomerInfoResponse.getString("DEFTER_BAKIYE", null))){
				outMap.put("CUSTOMER_NAME", "");
				outMap.put("BRANCH_CODE", "");
				outMap.put("CURRENCY_CODE", "");
				outMap.put("CUSTOMER_NO", "");
				outMap.put("IBAN", "");
				outMap.put("BALANCE", "");
				outMap.put("AVAILABLE_BALANCE", "");
				return outMap;
			}
			
			GMMap getAvailableBalanceRequest = new GMMap();
			getAvailableBalanceRequest.put("HESAP_NO", accountNo);
			
			GMMap getAvailableBalanceResponse = GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", getAvailableBalanceRequest);
			
			if(StringUtil.isEmpty(getAvailableBalanceResponse.getString("KULLANILABILIR_BAKIYE", null))){
				outMap.put("CUSTOMER_NAME", "");
				outMap.put("BRANCH_CODE", "");
				outMap.put("CURRENCY_CODE", "");
				outMap.put("CUSTOMER_NO", "");
				outMap.put("IBAN", "");
				outMap.put("BALANCE", "");
				outMap.put("AVAILABLE_BALANCE", "");
				return outMap;
			}
			
			outMap.put("CUSTOMER_NAME", accountResults.getString(tableName, 0, "KISA_ISIM"));
			outMap.put("BRANCH_CODE", accountResults.getString(tableName, 0, "SUBE_KODU"));
			outMap.put("CURRENCY_CODE", accountResults.getString(tableName, 0, "DOVIZ_KODU"));
			outMap.put("CUSTOMER_NO", accountResults.getString(tableName, 0, "MUSTERI_NO"));
			outMap.put("IBAN", accountResults.getString(tableName, 0, "IBAN"));
			outMap.put("BALANCE", getCustomerInfoResponse.getString("DEFTER_BAKIYE", null));
			outMap.put("AVAILABLE_BALANCE", getAvailableBalanceResponse.getString("KULLANILABILIR_BAKIYE", null));
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return outMap;
	}
	
	@GraymoundService("ICS_INVOICE_COLLECTION_GET_CORPORATES_FRONTEND")
	public static GMMap getCorporatesFrontEndInvoiceColleciton(GMMap input){
		GMMap output = new GMMap();
		
		try{
			final String corporateTableName = "CORPORATES";
			String sectorCode = input.getString("SECTOR_CODE");
			
			output.put(corporateTableName,0, "NAME","L�tfen Kurum Se�iniz");
			output.put(corporateTableName,0, "VALUE","SECIMYOK");
			
			GMMap getCorporatesRequest = new GMMap();
			getCorporatesRequest.put(TransactionConstants.GetCorporates.Inputs.ACTIVENESS, true);
			getCorporatesRequest.put(TransactionConstants.GetCorporates.Inputs.SECTOR_CODE, sectorCode);
			
			GMMap getCorporatesResponse = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporates.SERVICE_NAME, getCorporatesRequest);
			
			final String outputCorporateTableName = TransactionConstants.GetCorporates.Output.CORPORATE_TABLE;
			
			for (int i = 0; i < getCorporatesResponse.getSize(outputCorporateTableName); i++) {
				output.put(corporateTableName, i+1, "VALUE", getCorporatesResponse.getString(outputCorporateTableName, i, TransactionConstants.GetCorporates.Output.CORPORATE_OID));
				output.put(corporateTableName, i+1, "NAME", getCorporatesResponse.getString(outputCorporateTableName, i, TransactionConstants.GetCorporates.Output.SHORT_CODE));
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_INVOICE_COLLECTION_SET_SELECTION_FOR_ROWS")
	public static GMMap setSelectionForRows(GMMap input){
		try{
			final String invoiceTableName = "INVOICES";
			boolean selection = input.getBoolean("SELECTION");
			BigDecimal totalAmount = new BigDecimal(0);
			int selectedRowCount = 0;
			for (int i = 0; i < input.getSize(invoiceTableName); i++) {
				if("0".equals(input.getString(invoiceTableName, i, "IS_PAID"))){
					input.put(invoiceTableName, i, "SELECT", selection);
					if (selection) {
						totalAmount = totalAmount.add(input.getBigDecimal(
								invoiceTableName, i, "COLLECTION_AMOUNT").add(
								input.getBigDecimal(invoiceTableName, i,
										"COMMISSION_AMOUNT")));
						++selectedRowCount;
					}
				}
			}
			input.put("TOTAL_AMOUNT", totalAmount);
			input.put("SELECTED_ROW_COUNT", selectedRowCount);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return input;
	}
	
	@GraymoundService("ICS_VIEW_INVOICES")
	public static GMMap viewInvoices(GMMap iMap){
		GMMap outMap = new GMMap();
		final String INVOICES = "INVOICES";		
		
		try{
			String corporateOid = iMap.getString("CORPORATE_OID");
			Date dueStartDate = iMap.getDate("DUE_DATE_START");
			Date dueEndDate = iMap.getDate("DUE_DATE_END");
			String corporateCode = CommonBusinessOperations.getCorporateCodeFromCorporateOid(corporateOid);
			
			Session hibernateSession = CommonHelper.getHibernateSession();
			
			Criteria criteria = hibernateSession.createCriteria(invoiceMain.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateCode", corporateCode))
					.add(Restrictions.between("invoiceDueDate", CommonHelper.getShortDateTimeString(dueStartDate), CommonHelper.getShortDateTimeString(dueEndDate)));
			
			if (iMap.getString("SUBSCRIBER_NO1") != null && !"".equals(iMap.getString("SUBSCRIBER_NO1"))) {
				criteria.add(Restrictions.eq("subscriberNo1", iMap.getString("SUBSCRIBER_NO1")));
			}
			
			if (iMap.getString("INVOICE_NO") != null && !"".equals(iMap.getString("INVOICE_NO"))) {
				criteria.add(Restrictions.eq("invoiceNo", iMap.getString("INVOICE_NO")));
			}

			String invoiceType = iMap.getString("INVOICE_TYPE");
			if(invoiceType != null){
				Short collectionType = Short.parseShort(invoiceType);
				criteria.add(Restrictions.eq("collectionType", collectionType));
			}
			
			BigDecimal amountMin = iMap.getBigDecimal("AMOUNT_MIN");
			BigDecimal amountMax = iMap.getBigDecimal("AMOUNT_MAX");
			int gTZero = amountMax.compareTo(new BigDecimal(0.00));
			
			if(gTZero == 1){
				criteria.add(Restrictions.between("amount", amountMin, amountMax));
			}

			@SuppressWarnings("unchecked")
			List<invoiceMain> invoiceList = criteria.list();
			
			int counter = 0;
			for(invoiceMain invoice : invoiceList){

				invoicePayment payment = (invoicePayment) hibernateSession.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("invoiceMainOid", invoice.getOid()))
						.addOrder(Order.desc("paymentDate")).setMaxResults(1).uniqueResult();
				
				outMap.put(INVOICES, counter, "CORPORATE_NAME", CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(invoice.getCorporateCode()));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NO", invoice.getSubscriberNo1());
				outMap.put(INVOICES, counter, "INVOICE_NO", invoice.getInvoiceNo());
				outMap.put(INVOICES, counter, "INVOICE_DUE_DATE", CommonHelper.getDateTime(invoice.getInvoiceDueDate(), "yyyyMMdd"));
				outMap.put(INVOICES, counter, "INVOICE_AMOUNT", invoice.getAmount());
				outMap.put(INVOICES, counter, "LOADING_DATE", CommonHelper.longTimeStringToViewTimeString(invoice.getLoadingDate()) + " " + CommonHelper.longTimeStringToViewDateString(invoice.getLoadingDate()));
				outMap.put(INVOICES, counter, "COLLECTION_TYPE", CommonBusinessOperations.getCollectionTypeName(invoice.getCollectionType()));
				if(payment != null){
					outMap.put(INVOICES, counter, "PAYMENT_DATE", CommonHelper.longTimeStringToViewDateString(payment.getPaymentDate()));
					outMap.put(INVOICES, counter,"PAYMENT_ACCOUNT_NO",payment.getPaymentAccountNo());
					String paymentRecOwner = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_REC_OWNER_QUERY, payment.getOid()));	
					if (paymentRecOwner != null || !"".equals(paymentRecOwner)) {
						String payerBranchName = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_BRANCH_CODE_QUERY, payment.getPaymentBranch()));
						outMap.put(INVOICES, counter,"BRANCH_CODE",payerBranchName);
					}
					if( null != payment.getStandingOrderOid() ){
						int totalCount =Integer.parseInt(DALUtil.getResult(
								String.format(QueryRepository.ServiceWrapperRepository.GET_STANDING_ORDER_COUNT_QUERY, payment.getStandingOrderOid(),
										payment.getCollectionType())));
						
						if( totalCount > 0 ){
							outMap.put(INVOICES, counter,"IS_STANDING_ORDER",true);
						}
					}
				}
				outMap.put(INVOICES, counter, "PAYMENT_AMOUNT", invoice.getPaymentAmount());

				counter++;
			}
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_CALCULATE_TOTAL_AMOUNT")
	public static GMMap calculateTotalAmount(GMMap iMap){
		final String INVOICES = "INVOICES";
		final String PROPERTIES = "PROPERTIES";
		
		GMMap outMap = new GMMap();
		
		try{
			BigDecimal totalAmount = new BigDecimal(0);
			
			GMMap staticColorMap = new GMMap();
			staticColorMap.put("setBackground", Color.WHITE);
			staticColorMap.put("setForeground", Color.BLACK);
			
			GMMap colorMap = new GMMap();
			colorMap.put("setBackground", Color.GREEN);
			colorMap.put("setForeground", Color.BLACK);
			
			for (int counter = 0; counter < iMap.getSize(INVOICES); counter++) {
				
				if(iMap.getBoolean(INVOICES, counter, "SELECT")){
					BigDecimal collectionAmount = iMap.getBigDecimal(INVOICES, counter, "COLLECTION_AMOUNT");
					BigDecimal commissionAmount = calculateCommission(iMap.getString(INVOICES, counter, "CORPORATE_CODE"), collectionAmount);
					totalAmount = totalAmount.add(collectionAmount).add(commissionAmount);
					outMap.put(INVOICES, counter, "COMMISSION_AMOUNT", commissionAmount);
				}
				else{
					outMap.put(INVOICES, counter, "COMMISSION_AMOUNT", iMap.get(INVOICES, counter, "COMMISSION_AMOUNT"));
				}
				
				outMap.put(INVOICES, counter, "COLLECTION_AMOUNT", iMap.get(INVOICES, counter, "COLLECTION_AMOUNT"));
				outMap.put(INVOICES, counter, "CORPORATE_CODE", iMap.get(INVOICES, counter, "CORPORATE_CODE"));
				outMap.put(INVOICES, counter, "CORPORATE_NAME", iMap.get(INVOICES, counter, "CORPORATE_NAME"));
				outMap.put(INVOICES, counter, "INVOICE_AMOUNT", iMap.get(INVOICES, counter, "INVOICE_AMOUNT"));
				outMap.put(INVOICES, counter, "INVOICE_DUE_DATE", iMap.get(INVOICES, counter, "INVOICE_DUE_DATE"));
				outMap.put(INVOICES, counter, "INVOICE_NO", iMap.get(INVOICES, counter, "INVOICE_NO"));
				String month = iMap.getString(INVOICES, counter, "INVOICE_TERM_MONTH");
				String year = iMap.getString(INVOICES, counter, "INVOICE_TERM_YEAR");
				outMap.put(INVOICES, counter, "INVOICE_TERM_MONTH", month);
				outMap.put(INVOICES, counter, "INVOICE_TERM_YEAR", year);
				String term = (StringUtil.isEmpty(year) ? "" : year) + (StringUtil.isEmpty(month) ? "" : month);
				outMap.put(INVOICES, counter, "INVOICE_TERM", term);
				outMap.put(INVOICES, counter, "PAYMENT_TYPE", iMap.get(INVOICES, counter, "PAYMENT_TYPE"));
				outMap.put(INVOICES, counter, "PAYMENT_TYPE_NAME", iMap.get(INVOICES, counter, "PAYMENT_TYPE_NAME"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NAME", iMap.get(INVOICES, counter, "SUBSCRIBER_NAME"));
				outMap.put(INVOICES, counter, "SUBSCRIBER_NO", iMap.get(INVOICES, counter, "SUBSCRIBER_NO"));
				outMap.put(INVOICES, counter, "SELECT", iMap.get(INVOICES, counter, "SELECT"));
				outMap.put(INVOICES, counter, "OID", iMap.get(INVOICES, counter, "OID"));
				outMap.put(INVOICES, counter, MapKeys.INSTALLMENT_NO, iMap.get(INVOICES, counter, MapKeys.INSTALLMENT_NO));
				outMap.put(INVOICES, counter, "IS_PAID", iMap.get(INVOICES, counter, "IS_PAID"));
				outMap.put(INVOICES, counter, "STATE_TEXT", iMap.get(INVOICES, counter, "STATE_TEXT"));
				if(iMap.get(INVOICES, counter, MapKeys.PARAMETER1)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER1, iMap.get(INVOICES, counter, MapKeys.PARAMETER1));
				}
				
				if(iMap.get(INVOICES, counter, MapKeys.PARAMETER2)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER2, iMap.get(INVOICES, counter, MapKeys.PARAMETER2));
				}

				if(iMap.get(INVOICES, counter, MapKeys.PARAMETER3)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER3, iMap.get(INVOICES, counter, MapKeys.PARAMETER3));
				}

				if(iMap.get(INVOICES, counter, MapKeys.PARAMETER4)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER4, iMap.get(INVOICES, counter, MapKeys.PARAMETER4));
				}

				if(iMap.get(INVOICES, counter, MapKeys.PARAMETER5)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER5, iMap.get(INVOICES, counter, MapKeys.PARAMETER5));
				}
				
				if(iMap.get(INVOICES, counter, MapKeys.PARAMETER6)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER6, iMap.get(INVOICES, counter, MapKeys.PARAMETER6));
				}
				
				if(iMap.get(INVOICES, counter, MapKeys.PARAMETER7)!=null){
					outMap.put(INVOICES, counter, MapKeys.PARAMETER7, iMap.get(INVOICES, counter, MapKeys.PARAMETER7));
				}
				
				if("1".equals(iMap.get(INVOICES, counter, "IS_PAID"))){
					outMap.put(PROPERTIES, counter, "COLLECTION_AMOUNT", colorMap);
					outMap.put(PROPERTIES, counter, "COMMISSION_AMOUNT", colorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_CODE", colorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_NAME", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_AMOUNT", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DUE_DATE", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_NO", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_MONTH", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_YEAR", colorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM", colorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE_NAME", colorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE", colorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NAME", colorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NO", colorMap);
					outMap.put(PROPERTIES, counter, "SELECT", colorMap);
					outMap.put(PROPERTIES, counter, "OID", colorMap);
					outMap.put(PROPERTIES, counter, "ALLOW_PART_PAYMENT", colorMap);
					outMap.put(PROPERTIES, counter, "STATE_TEXT", colorMap);
				}
				else{
					outMap.put(PROPERTIES, counter, "COLLECTION_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "COMMISSION_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_CODE", staticColorMap);
					outMap.put(PROPERTIES, counter, "CORPORATE_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_AMOUNT", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_DUE_DATE", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_NO", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_MONTH", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM_YEAR", staticColorMap);
					outMap.put(PROPERTIES, counter, "INVOICE_TERM", staticColorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "PAYMENT_TYPE", staticColorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NAME", staticColorMap);
					outMap.put(PROPERTIES, counter, "SUBSCRIBER_NO", staticColorMap);
					outMap.put(PROPERTIES, counter, "SELECT", staticColorMap);
					outMap.put(PROPERTIES, counter, "OID", staticColorMap);
					outMap.put(PROPERTIES, counter, "ALLOW_PART_PAYMENT", staticColorMap);
					outMap.put(PROPERTIES, counter, "STATE_TEXT", staticColorMap);
				}
				
			}
			
			outMap.put("TOTAL_AMOUNT", totalAmount);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}
	
	@GraymoundService("ICS_INSERT_INVOICE_PAYMENT_LOG")
	public static GMMap insertInvoicePaymentLog(GMMap input){
		return RequestProcessor.getInstance().process(input, new InsertInvoicePaymentLogHandler());
	}
	
	@GraymoundService("ICS_ROLLBACK_INVOICE_PAYMENT_LOG")
	public static GMMap rollbackInvoicePaymentLog(GMMap input){
		return RequestProcessor.getInstance().process(input, new RollbackInvoicePaymentLogHandler());
	}

	@GraymoundService("ICS_DAILY_PAYMENT_TRANSACTIONS_REPORT")
	public static GMMap dailyPaymentTransactionReport(GMMap input){
		return RequestProcessor.getInstance().process(input, new DailyPaymentTransactionReportHandler());
	}

	@GraymoundService("ICS_UPDATE_INVOICE_DEBT_PROCESS")
	public static GMMap updateInvoiceDebtProcess(GMMap input){
		
		GMMap output = new GMMap();
		try {
			String ftmId = input.getString(TransactionConstants.UpdateInvoiceDebtProces.Input.FTM_SEQUENCE_NUMBER);
			BigDecimal negativeVal = new BigDecimal(NEGATIVE_VALUE);
			Session hibernateSession = CommonHelper.getHibernateSession();
			
			hibernateSession.createQuery(QueryRepository.ServiceWrapperRepository.UPDATE_INV_MAIN_QUERY)
					.setParameter("newFtmSeqeunceNumber", negativeVal.multiply(new BigDecimal(ftmId)))
					.setParameter("oldFtmSequenceNumber", new BigDecimal(ftmId))
					.executeUpdate();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		
		return output;
	}
	
	@GraymoundService("ICS_SEARCH_ALL_PAYMENTS")
	public static GMMap searchAllPayments(GMMap iMap){
		GMMap outMap = new GMMap();
		String tableName = "PAYMENTS";
		try{
			
			String radioButtonSelection = iMap.getString("RADIO_BUTTON_SELECTION");
			BigDecimal referenceNo = iMap.getBigDecimal("REFERENCE_NO");
			BigDecimal customerNo = iMap.getBigDecimal("CUSTOMER_NO");
			String corporateOid = iMap.getString("CORPORATE_OID");
			Short paymentType = null;
			String paymentTypeStr = iMap.getString("PAYMENT_TYPE");
			if (paymentTypeStr != null)			
				paymentType = Short.parseShort(paymentTypeStr);
			Date startDate = null, endDate = null, date = null;
			
			String currentCorporateCode = null, currentPaymentType = null, currentChannel = null, currentPaymentSource = null, currentSubscriberName = null,
				   startDatestr = null, endDatestr = null, currentInvoiceNo = null, paymentRecOwner = null;
			
			if (iMap.getDate("START_DATE") != null) {
				startDate = new java.sql.Date(iMap.getDate("START_DATE").getTime());
				
				
				if (iMap.getDate("END_DATE") != null) {
					endDate = new java.sql.Date(iMap.getDate("END_DATE").getTime());
					
					
					if( startDate.compareTo(endDate) > 0 ){
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));	
					}
					
					startDatestr = CommonHelper.getShortDateTimeString(startDate);
					startDatestr += "000000";
				
					endDatestr = CommonHelper.getShortDateTimeString(endDate);
					endDatestr += "235959";
				}
				
			}
						
			Session hibernateSession = CommonHelper.getHibernateSession();
		
			Criteria criteria = hibernateSession.createCriteria(invoicePayment.class)
					.add(Restrictions.eq("paymentChannel", GeneralConstants.YIM_CHANNEL_CODE));
			if(radioButtonSelection.equals("ISLEM_NO")) {				
				if (referenceNo == null) 
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "��lem No"));	
				
				criteria = criteria
						.add(Restrictions.eq("queryRefNo", referenceNo))
						.add(Restrictions.between("paymentDate", startDatestr, endDatestr))						
						.add(Restrictions.eq("status", true));		
			}
			else if(radioButtonSelection.equals("MUSTERI_NO")) {				
				if (customerNo == null) 
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "M��teri No"));	
				
				criteria = criteria
						.add(Restrictions.eq("payerCustomer", customerNo))
						.add(Restrictions.between("paymentDate", startDatestr, endDatestr))						
						.add(Restrictions.eq("status", true));		
			}
			else if(radioButtonSelection.equals("REFERANS_NO")) {		
				String subscriberNo1 = iMap.getString(MapKeys.SUBSCRIBER_NO1, null);
				String subscriberNo2 = iMap.getString(MapKeys.SUBSCRIBER_NO2, null);
				String subscriberNo3 = iMap.getString(MapKeys.SUBSCRIBER_NO3, null);
				String subscriberNo4 = iMap.getString(MapKeys.SUBSCRIBER_NO4, null);
				
				CorporateMaster corporateMaster = ((CorporateMaster)hibernateSession.createCriteria(CorporateMaster.class)
						.add(Restrictions.eq("oid", corporateOid))
						.add(Restrictions.eq("status", true))
						.uniqueResult());
				String corporateCode = corporateMaster.getCorporateCode();
				
				criteria = criteria
						.add(Restrictions.eq("corporateCode", corporateCode))
						.add(Restrictions.eq("collectionType", paymentType))
						.add(Restrictions.between("paymentDate", startDatestr, endDatestr))
						.add(Restrictions.eq("status", true))
						.addOrder(Order.asc("paymentDate"));	
				
				GMMap controlSubscriberMetadataInput = new GMMap();
				controlSubscriberMetadataInput.put(TransactionConstants.ControlSubscriberMetaData.Input.CHANNEL_CODE, GeneralConstants.YIM_CHANNEL_CODE);
				controlSubscriberMetadataInput.put(TransactionConstants.ControlSubscriberMetaData.Input.COLLECTION_TYPE, paymentType);
				controlSubscriberMetadataInput.put(TransactionConstants.ControlSubscriberMetaData.Input.CORPORATE_CODE, corporateCode);
				if(!StringUtil.isEmpty(subscriberNo1)){
					controlSubscriberMetadataInput.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO1, subscriberNo1);
				}
				if(!StringUtil.isEmpty(subscriberNo2)){
					controlSubscriberMetadataInput.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO2, subscriberNo2);
				}
				if(!StringUtil.isEmpty(subscriberNo3)){
					controlSubscriberMetadataInput.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO3, subscriberNo3);
				}
				if(!StringUtil.isEmpty(subscriberNo4)){
					controlSubscriberMetadataInput.put(TransactionConstants.ControlSubscriberMetaData.Input.SUBSCRIBER_NO4, subscriberNo4);
				}
				
				GMMap controlSubscriberMetaDataMap =  CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.ControlSubscriberMetaData.SERVICE_NAME,
						controlSubscriberMetadataInput);
				
				CommonHelper.makeSubscriberNoMask(iMap, controlSubscriberMetaDataMap);
				
				if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO1, null))){
					criteria = criteria.add(Restrictions.eq("subscriberNo1", iMap.getString(MapKeys.SUBSCRIBER_NO1)));
				}
				if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO2, null))){
					criteria = criteria.add(Restrictions.eq("subscriberNo2", iMap.getString(MapKeys.SUBSCRIBER_NO2)));
				}
				if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO3, null))){
					criteria = criteria.add(Restrictions.eq("subscriberNo3", iMap.getString(MapKeys.SUBSCRIBER_NO3)));
				}
				if(!StringUtil.isEmpty(iMap.getString(MapKeys.SUBSCRIBER_NO4, null))){
					criteria = criteria.add(Restrictions.eq("subscriberNo4", iMap.getString(MapKeys.SUBSCRIBER_NO4)));
				}
			}
						
			@SuppressWarnings("unchecked")
			List<invoicePayment> invoicePayment = criteria.list();
			
			int counter = 0;
			for(invoicePayment payment : invoicePayment) {
				String subscriberNo = payment.getSubscriberNo1();
				if(payment.getSubscriberNo2() != null && !payment.getSubscriberNo2().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo2();
				
				if(payment.getSubscriberNo3() != null && !payment.getSubscriberNo3().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo3();
				
				if(payment.getSubscriberNo4() != null && !payment.getSubscriberNo4().trim().isEmpty())
					subscriberNo += "-" + payment.getSubscriberNo4();
				
				currentCorporateCode = payment.getCorporateCode();
				currentPaymentType = CommonBusinessOperations.getCollectionTypeName(Short.valueOf(payment.getCollectionType()));
				currentChannel = CommonBusinessOperations.getChannelName(payment.getPaymentChannel());
				currentPaymentSource = CommonBusinessOperations.getPaymentSourceName(payment.getPaymentSource());
				currentSubscriberName = payment.getSubscriberName();
		
				
				currentInvoiceNo = payment.getInvoiceNo();
				date = CommonHelper.getDateTime(payment.getPaymentDate(), "yyyyMMddHHmmss");			
								
				outMap.put(tableName, counter, "PAYMENT_ACCOUNT_NO", payment.getPaymentAccountNo());	
				outMap.put(tableName, counter, "PAYMENT_REC_OWNER", paymentRecOwner);	
				outMap.put(tableName, counter, "CORPORATE_NAME", CommonBusinessOperations.getCorporateShortCodeFromCorporateCode(currentCorporateCode));
				outMap.put(tableName, counter, "INVOICE_NO", currentInvoiceNo);
				outMap.put(tableName, counter, "PAYMENT_TYPE", currentPaymentType);
				outMap.put(tableName, counter, "PROCESS_DATE", date);
				outMap.put(tableName, counter, "PAYMENT_SOURCE", currentPaymentSource);
				outMap.put(tableName, counter, "CHANNEL", currentChannel);
				outMap.put(tableName, counter, "SUBSCRIBER_NAME", currentSubscriberName);
				outMap.put(tableName, counter, "SUBSCRIBER_NO", subscriberNo);
				outMap.put(tableName, counter, "SELECT", false);
				outMap.put(tableName, counter, "OID", payment.getOid());
				outMap.put(tableName, counter, "REFERENCE_NO", payment.getTxNo());
				outMap.put(tableName, counter, "PAY_CUSTOMER_NO", payment.getPayerCustomer());
				outMap.put(tableName, counter, "CANCELLED_REF_NO", payment.getCancelTrxNumber());
				outMap.put(tableName, counter, "INVOICE_NO", payment.getInvoiceNo());
				outMap.put(tableName, counter, "INVOICE_DUE_DATE", payment.getInvoiceDueDate());
				outMap.put(tableName, counter, "INVOICE_AMOUNT", payment.getInvoiceAmount());
				outMap.put(tableName, counter, "PAYMENT_AMOUNT", payment.getPaymentAmount());
				outMap.put(tableName, counter, "QUERY_REF_NO", payment.getQueryRefNo());

				
				if( null != payment.getTxNo() ){
					String receiptNo = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_RECEIPT_NO_QUERY, payment.getTxNo().toString()));	
					outMap.put(tableName, counter, "RECEIPT_NO", receiptNo);
				}
				
				if( DatabaseConstants.PaymentStatuses.Cancelled.equals(payment.getPaymentStatus()) ){
					String paymentOid =payment.getOid();
					String cancelledChannelName = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_CHANNEL_NAME_QUERY, paymentOid));
					outMap.put(tableName, counter, "CANCELLED_CHANNEL_NAME", cancelledChannelName);
					
					String cancellUserName = DALUtil.getResult(String.format(QueryRepository.ServiceWrapperRepository.FETCH_USER_NAME_QUERY, paymentOid));
					outMap.put(tableName, counter, "CANCELLED_USER", cancellUserName);
				}
				
				counter++;			
			}
			
			
		} catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return outMap;
	}	
	
	@GraymoundService("ICS_MONTHLY_PAYMENT_TRANSACTIONS_REPORT")
	public static GMMap monthlyPaymentTransactionReport(GMMap input){
		return RequestProcessor.getInstance().process(input, new MonthlyPaymentTransactionReportHandler());
	}
	
	@GraymoundService("ICS_DO_INVOICE_COLLECTION_AFTER_APPROVAL")
	public static GMMap doInvoiceCollectionAfterApproval(GMMap input){
		GMMap output = new GMMap();
		
		final String CANCEL = "I";
		final String APPROVE = "O";
		final String VERIFY = "D";
		final String CANCEL_APPROVAL = "IO";
		
		BigDecimal txNo = input.getBigDecimal("ISLEM_NO");
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			String trxType = input.getString("ISLEM_TURU");
			
			if(trxType.equals(CANCEL) || trxType.equals(CANCEL_APPROVAL)){
				invoicePaymentLog log = (invoicePaymentLog) session.createCriteria(invoicePaymentLog.class)
						.add(Restrictions.eq("txNo", txNo))
						.add(Restrictions.eq("status", true))
						.uniqueResult();
				if(log != null){
					log.setStatus(false);
					session.saveOrUpdate(log);
				}
			}
			else if(trxType.equals(APPROVE)){
				invoicePaymentLog log = (invoicePaymentLog) session.createCriteria(invoicePaymentLog.class)
						.add(Restrictions.eq("txNo", txNo))
						.add(Restrictions.eq("status", true))
						.uniqueResult();
				
				if(!log.isCallCorporate()){
					return output;
				}
				
				String corporateCode = log.getCorporateCode();
				GMMap corpMap = new GMMap();
				corpMap.put(TransactionConstants.GetCorporateDefinition.Inputs.CORPORATE_CODE, corporateCode);
				GMMap corporateDefinitionOutput = CommonHelper.callGraymoundServiceInHibernateSession(TransactionConstants.GetCorporateDefinition.SERVICE_NAME, corpMap);
				
				Clob clob = log.getPaymentInput();
				Reader reader = clob.getCharacterStream();
				BufferedReader bReader = new BufferedReader(reader);
				StringBuilder builder = new StringBuilder();
				int b;
				
				while(-1 != (b = bReader.read())){
					builder.append((char)b);
				}
				
				bReader.close();
				reader.close();
				GMMap invoiceCollectionInput = CommonHelper.deserializeRequest(builder.toString());
				
				if (corporateDefinitionOutput.getString(MapKeys.IS_ONLINE_CORPORATE).equals("1")) {
					
					CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", invoiceCollectionInput);
				}
				else{
					String invoiceMainOid = invoiceCollectionInput.getString(TransactionConstants.DoInvoiceCollection.Input.INVOICE_MAIN_OID, null);
					if(!StringUtil.isEmpty(invoiceMainOid) && !log.getPaymentAmount().equals(log.getInvoiceAmount())){
						invoiceMain mainRecord = (invoiceMain)session.createCriteria(invoiceMain.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("oid", invoiceMainOid))
								.uniqueResult();
						mainRecord.setPaymentStatus(DatabaseConstants.PaymentStatuses.PartialCollected);
						session.saveOrUpdate(mainRecord);
					}
				}
				
				invoicePayment paymentRecord = (invoicePayment) session.createCriteria(invoicePayment.class)
						.add(Restrictions.eq("status", true))
						.add(Restrictions.eq("txNo", txNo))
						.uniqueResult();
				
				paymentRecord.setPaymentStatus(DatabaseConstants.PaymentStatuses.Collected);
				session.saveOrUpdate(paymentRecord);
			}
			else if(trxType.equals(VERIFY)){
				// Do nothing for verify
			}
			else{
				CommonHelper.throwBusinessException(GeneralConstants.HARDCODED_STRING_ERROR_MESSAGE_CODE, trxType + " i�lem tipi 7010 i�lemi i�in tan�ml� de�ildir.");
			}
			
			session.flush();
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_CONTROL_RECEIPT_KFT_TRANSACTION")
	public static GMMap controlReceiptKftTransaction(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session session = CommonHelper.getHibernateSession();
			
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");
			
			invoicePayment paymentRecord = (invoicePayment) session.createCriteria(invoicePayment.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("txNo", trxNo))
					.uniqueResult();
			
			if(paymentRecord == null){
				output.put("IS_KFT_RECORD", false);
			}
			else{
				output.put("IS_KFT_RECORD", true);
				output.put("IS_CASH_TRANSACTION", false);
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_TRANSFER_CORPORATE_BALANCE")
	public static GMMap transferCorporateBalance(GMMap input){
		return RequestProcessor.getInstance().process(input, new TransferCorporateBalanceHandler());
	}
	
	@GraymoundService("CPS_FETCH_CORPORATE_ACCOUNT_BALANCE")
	public static GMMap fetchCorporateAccountBalance(GMMap input) {
		GMMap output = new GMMap();
		final String TABLE_NAME = "INFO_TABLE";
		
		try{
			String query = "select sum(decode(satir.b_a,'B',dv_tutar,0)) as DEBT_TOTAL,sum(decode(satir.b_a,'A',dv_tutar,0)) as CLAIM_TOTAL," +
					"sum(decode(satir.b_a,'B',-dv_tutar,dv_tutar)) NET_TOTAL " +
					"FROM muh_islem islem, MUH_FIS FIS, MUH_FIS_SATIR SATIR " +
					"WHERE SATIR.Hesap_Numara  = ? " +
					"and satir.hesap_tur_kodu != 'DK' " +
					"and fis.numara = satir.fis_numara " +
					"and fis.islem_numara = islem.numara " +
					"and FIS.MUH_TARIH   >= ? " +
					"and FIS.MUH_TARIH   <= ? " +
					"and FIS.TUR      =  'G' " +
					"and  islem.ISLEM_KOD not between 5301 and 5306";
			
			GMMap results = CommonHelper.queryData(query, TABLE_NAME, BnsprType.STRING, input.getString("ACCOUNT_NO"), BnsprType.DATE, input.getDate("START_DATE"),
					BnsprType.DATE, input.getDate("END_DATE"));
			
			BigDecimal debtTotal = results.getBigDecimal(TABLE_NAME, 0, "DEBT_TOTAL");
			BigDecimal claimTotal = results.getBigDecimal(TABLE_NAME, 0, "CLAIM_TOTAL");
			BigDecimal netTotal = results.getBigDecimal(TABLE_NAME, 0, "NET_TOTAL");
			
			output.put("DEBT_TOTAL", debtTotal == null ? BigDecimal.ZERO : debtTotal);
			output.put("CLAIM_TOTAL", claimTotal == null ? BigDecimal.ZERO : claimTotal);
			output.put("NET_TOTAL", netTotal == null ? BigDecimal.ZERO : netTotal);
			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("CDM_CONTROL_CASH_PAYMENT_COUNT")
	public static GMMap controlCashPaymentCount(GMMap input){
		GMMap output = new GMMap();
		
		try{
			int paymentsSize = input.getSize("PAYMENT_LIST");
			String selectedSource = input.getString("SELECTED_SOURCE");
			
			if(selectedSource.equals(DatabaseConstants.SourceCodes.Cash)){
				int count = 0;
				for (int i = 0; i < paymentsSize; i++) {
					if(input.getBoolean("PAYMENT_LIST", i, "SELECT") || 
							input.getString("PAYMENT_LIST", i, "SELECT").equals("1")){
						count++;
					}
				}
				
				if(count > 1){
					output.put("IS_ELIGIBLE", "0");
				}
				else{
					output.put("IS_ELIGIBLE", "1");
				}
			}
			else{
				output.put("IS_ELIGIBLE", "1");
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
	
	@GraymoundService("ICS_GET_STANDING_ORDER_BACKLOG")
	public static GMMap getStandingOrderBackLog(GMMap input){
		GMMap returnMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		try{
			String corporateCode=input.getString("CORPORATE_CODE");
			boolean isPaid=input.getBoolean("IS_PAID",false);
			boolean isLoaded=input.getBoolean("ID_LOADED",false);
			String invoiceDueDate=input.getString("INVOICE_DUE_DATE");
			
			Criteria cr = session.createCriteria(StandingOrderBacklog.class).add(Restrictions.eq("status", true));
			if (corporateCode!=null) {
				if (!"".equals(corporateCode)) {
					cr.add(Restrictions.eq("corporateCode", corporateCode));	
				}
			}
			if (isPaid) {
					cr.add(Restrictions.eq("isPaid", isPaid));	
			}
			if (isLoaded) {
					cr.add(Restrictions.eq("isLoaded", isLoaded));	
			}
			if (invoiceDueDate!=null) {
				if (!"".equals(invoiceDueDate)) {
					cr.add(Restrictions.eq("invoiceDueDate", invoiceDueDate));	
				}
			}

			@SuppressWarnings("unchecked")
			List<StandingOrderBacklog> standingOrderBackLogList = (List<StandingOrderBacklog>) cr.list();
			int row = 0;
			for (StandingOrderBacklog stoBackLog : standingOrderBackLogList) {
				returnMap.put("BILL_LIST", row, "AMOUNT", stoBackLog.getAmount());
				returnMap.put("BILL_LIST", row, "CORPORATE_CODE", stoBackLog.getCorporateCode());
				returnMap.put("BILL_LIST", row, "EST_LOAD_DATE", stoBackLog.getEstLoadDate());
				returnMap.put("BILL_LIST", row, "INVOICE_DUE_DATE", stoBackLog.getInvoiceDueDate());
				returnMap.put("BILL_LIST", row, "INVOICE_NO", stoBackLog.getInvoiceNo());
				returnMap.put("BILL_LIST", row, "IS_LOADED", stoBackLog.isIsLoaded()?"Evet":"Hay�r");
				returnMap.put("BILL_LIST", row, "IS_PAID", stoBackLog.isIsPaid()?"Evet":"Hay�r");
				returnMap.put("BILL_LIST", row, "LOAD_DATE", stoBackLog.getLoadDate());
				returnMap.put("BILL_LIST", row, "PAYMENT_DATE", stoBackLog.getPaymentDate());
				returnMap.put("BILL_LIST", row, "PAYMENT_ERROR", stoBackLog.getPaymentError());
				returnMap.put("BILL_LIST", row, "SUBSCRIBER_NAME", stoBackLog.getSubscriberName());
				returnMap.put("BILL_LIST", row, "SUBSCRIBER_NO1", stoBackLog.getSubscriberNo1());
				returnMap.put("BILL_LIST", row, "SUBSCRIBER_NO2", stoBackLog.getSubscriberNo2());
				row++;
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return returnMap;
	}
	
	@GraymoundService("ICS_SEND_REVERSE_ACCOUNTING_FAIL_MAIL")
	public static GMMap sendReverseAccountingFailMail(GMMap input){
		GMMap returnMap = new GMMap();
		try{
			String subscriberNo1 = input.getString("SUBSCRIBER_NO1");
			String subscriberNo2 = input.getString("SUBSCRIBER_NO2");
			BigDecimal transactionNo = input.getBigDecimal("TRX_NO");
			String emails = CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_REVERSE_ACCOUNTING_ERROR");
			String body = "Abone no 1 : " + subscriberNo1 + ", Abone no 2 : " + subscriberNo2 + ", Islem no : " + transactionNo.toString();
			CommonHelper.sendMail(Arrays.asList(emails.split(",")), null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", true, "Ters Muhasebe Hata Bildirim Maili", body);
		}catch (Exception e) {
			
		}
		return returnMap;
	}
	
	@GraymoundService("ICS_SAVE_REVERSE_ACCOUNTING_FAIL_ON_SAF")
	public static GMMap savereverseAccountingFailOnSaf(GMMap input) {
		GMMap returnMap = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			WsSaf wsSaf = new WsSaf();
			String firstSendDate = CommonHelper.getLongDateTimeString(new Date());
			wsSaf.setFirstSendDate(Long.parseLong(firstSendDate));
			wsSaf.setNextSendDate(0);
			wsSaf.setCorporateCode("C-X");
			wsSaf.setFirstSendUser(CommonHelper.getCurrentUser());
			wsSaf.setGmServiceName("ICS_CANCEL_PAYMENTS_BY_TRX_NO_FRONTEND");
			Clob parameters = new ClobImpl(CommonHelper.serializeRequest(input));
			Clob parametersString = new ClobImpl(input.toString());
			wsSaf.setParameters(parameters);
			wsSaf.setParametersString(parametersString);
			wsSaf.setSubscriberNo1("");
			wsSaf.setSubscriberNo2("");
			wsSaf.setSubscriberNo3("");
			wsSaf.setSubscriberNo4("");
			String sendStatus = CommonHelper.getNameOfParameter(SAF_STATUS_PRM, SAF_STATUS_NEW);
			wsSaf.setSendStatus(sendStatus);
			wsSaf.setStatus(true);
			wsSaf.setWebServiceName("ICS_CANCEL_PAYMENTS_BY_TRX_NO_FRONTEND");
			wsSaf.setTryCount((short) 2);
			wsSaf.setRunning((byte) 0);
			wsSaf.setPriority((byte) 0);
			hibernateSession.save(wsSaf);
			hibernateSession.flush();
		} catch (Exception e) {
			logger.info("ICS_SAVE_REVERSE_ACCOUNTING_FAIL_ON_SAF -> servis hata aldi");
		}
		return returnMap;
	}
	
	@GraymoundService("ICS_CHANGE_CORPORATE_PASSWORD")
	public static GMMap changeCorporatePassword(GMMap input){
		GMMap output = new GMMap();
		
		try{
			String corporateCode = input.getString("CORPORATE_CODE");
			int characterCount = 10;
			boolean includeAlpha = input.getBoolean("INCL_ALPHA", true);
			boolean includeNumeric = input.getBoolean("INCL_NUM", true);
			boolean includeSpecial = input.getBoolean("INCL_SPEC", true);
			
			String charCount = CommonBusinessOperations.getCorporateParameterValue(corporateCode, "PASS_CHAR_COUNT");
			
			if(!StringUtil.isEmpty(charCount)){
				characterCount = Integer.valueOf(charCount);
			}
			
			String newPassword = createPassword(corporateCode, characterCount, includeAlpha, includeNumeric, includeSpecial);
			
			StringBuilder updateQuery = new StringBuilder();
			updateQuery.append("UPDATE cdm.web_services ");
			updateQuery.append(String.format("SET ws_password='%s' ", newPassword));
			updateQuery.append(String.format("WHERE status=1 AND corporate_code = '%s'", corporateCode));
			
			GMMap onlineServiceCall = new GMMap();
			onlineServiceCall.put("NEW_PASSWORD", newPassword);
			onlineServiceCall.put(MapKeys.CORPORATE_CODE, corporateCode);
			onlineServiceCall.put(MapKeys.GM_SERVICE_NAME, "ICS_CHANGE_CORPORATE_PASSWORD");
			onlineServiceCall.put(MapKeys.IS_MANDATORY_SERVICE, true);
			onlineServiceCall.put("RECON_CALL", false);
			
			output = CommonHelper.callGraymoundServiceInHibernateSession("ICS_ONLINE_SERVICE_CALL", onlineServiceCall);
			
			CommonHelper.executeQuery(updateQuery.toString());
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}

	private static String createPassword(String corporateCode, int characterCount, boolean includeAlpha, boolean includeNumeric, boolean includeSpecial) 
			throws Exception {
		StringBuilder passwordBuilder = new StringBuilder();
		
		int alphabeticCount = 0;
		int numericCount = 0;
		int specialCount = 0;
		
		if(includeAlpha && includeNumeric && includeSpecial){
			alphabeticCount = characterCount / 3;
			numericCount = characterCount / 3;
			specialCount = characterCount - (alphabeticCount + numericCount); 
		}
		else if(includeAlpha && includeNumeric && !includeSpecial){
			alphabeticCount = characterCount / 2;
			numericCount = characterCount - alphabeticCount;
		}
		else if(includeAlpha && !includeNumeric && includeSpecial){
			alphabeticCount = characterCount / 2;
			specialCount = characterCount - alphabeticCount;
		}
		else if(includeAlpha && !includeNumeric && !includeSpecial){
			alphabeticCount = characterCount;
		}
		else if(!includeAlpha && includeNumeric && includeSpecial){
			numericCount = characterCount / 2;
			specialCount = characterCount - numericCount;
		}
		else if(!includeAlpha && !includeNumeric && includeSpecial){
			specialCount = characterCount;
		}
		else if(!includeAlpha && includeNumeric && !includeSpecial){
			numericCount = characterCount;
		}
		else{
			throw new Exception("No character has been specified for including in password");
		}
		
		if(alphabeticCount != 0){
			passwordBuilder.append(RandomStringUtils.randomAlphabetic(alphabeticCount));
		}
		
		if(numericCount != 0){
			passwordBuilder.append(RandomStringUtils.randomNumeric(numericCount));
		}
		
		if(specialCount != 0){
			Random random = new Random();
			char[] specChars = new char[] { '!', '#', '/', '*', '+', '%', '&' };
			for (int i = 0; i < specialCount; i++) {
				passwordBuilder.append(specChars[random.nextInt(specChars.length - 1)]);
			}
		}
		
		
		return passwordBuilder.toString();
	}
	
	@GraymoundService("CPS_GET_VALUE_OF_GENERAL_PARAMETER")
	public static GMMap getValueOfGeneralParameter(GMMap input){
		GMMap output = new GMMap();
		
		try{
			Session session = CommonHelper.getHibernateSession();
			String code = input.getString("CODE");
			String key1 = input.getString("KEY1");
			
			String text = (String)CommonHelper.queryUniqueResultWithHibernate(session, "SELECT text FROM v_ml_gnl_param_text WHERE kod=:code AND key1=:key1", "code", code, "key1", key1);
			
			output.put("RESULT", text);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}
