package tr.com.aktifbank.bnspr.invoicecollection.engine;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.dao.CorporateMaster;
import tr.com.aktifbank.bnspr.dao.ExtChannelReconciliation;
import tr.com.aktifbank.bnspr.dao.ReconLog;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ExternalChannelReconciliationServices {

	@GraymoundService("ICS_EXTERNAL_CHANNEL_RECONCILIATION")
	public static GMMap externalChannelReconciliation(GMMap iMap) {
		// burada tablo kayit ve hesaplama islemlerini yap
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap returnMap = new GMMap();
		GMMap returnCancelMap = new GMMap();
		
		

		
		String institutionOid = iMap.getString("INSTITUTION_OID");
		
		int collectionCount = iMap.getInt("COLLECTION_COUNT");
		BigDecimal collectionAmount = iMap.getBigDecimal("COLLECTION_AMOUNT");
		BigDecimal cancelCount = iMap.getBigDecimal("CANCEL_COUNT");
		BigDecimal cancelAmount = iMap.getBigDecimal("CANCEL_AMOUNT");
		BigDecimal corporateCollectionCount = new BigDecimal("0");
		BigDecimal corporateCollectionAmount = new BigDecimal("0");
		BigDecimal corporateCancelCount = new BigDecimal("0");
		BigDecimal corporateCancelAmount = new BigDecimal("0");
		String collectionDate = iMap.getString("COLLECTION_DATE");
		CorporateMaster corporateMaster = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("oid", institutionOid)).uniqueResult();
		if (corporateMaster == null) {
			returnMap.put("RESULT", "Kurum kodu bulunamad�!");
			return returnMap;
		}
		ReconLog reconLog = (ReconLog) session.createCriteria(ReconLog.class).add(Restrictions.eq("corporateCode", corporateMaster.getCorporateCode())).add(Restrictions.eq("reconDate", collectionDate)).add(Restrictions.eq("reconStatus", "S")).uniqueResult();
		if (reconLog != null) {
			returnMap.put("RESULT", "Bu kurum i�in banka taraf�nda mutabakat ba�ar�l� olarak kapanm��. Tekrar mutabakat yapamazs�n�z!");
			return returnMap;
		}
		ExtChannelReconciliation extChRecon = (ExtChannelReconciliation) session.createCriteria(ExtChannelReconciliation.class).add(Restrictions.eq("corporateOid", institutionOid)).add(Restrictions.eq("reconStatus", "S")).add(Restrictions.eq("reconDate", collectionDate)).uniqueResult();
		if (extChRecon != null) {
			returnMap.put("RESULT", "Bu kurum i�in daha �nce ba�ar�l� olarak mutabakat kanal baz�nda yap�lm��. Tekrar mutabakat bildirimi yapamazs�n�z!");
			return returnMap;
		}
		
		ExtChannelReconciliation extChReconFail = (ExtChannelReconciliation) session.createCriteria(ExtChannelReconciliation.class).add(Restrictions.eq("corporateOid", institutionOid)).add(Restrictions.eq("reconStatus", "F")).add(Restrictions.eq("reconDate", collectionDate)).uniqueResult();

		// BigDecimal transferredAmount = (BigDecimal) session.createCriteria(BalanceTransferProcess.class).add(Restrictions.eq("collectionDate", collectionDate)).add(Restrictions.eq("status", true)).add(Restrictions.eq("corporateCode", corporateMaster.getCorporateCode())).add(Restrictions.eq("transferStatus", "2")).setProjection(Projections.sum("transferAmount"));
		String strSQL = "select SUM(ADET) AS ADET ,SUM(TUTAR) AS TUTAR  from bnspr.FOM_TAHSILAT_TX where INSTUTION_OID ='" +institutionOid+"|~|KFT_CORPORATE_OID" +"' " + " and rec_date between TO_DATE('".concat(collectionDate).concat(" 000001', 'YYYYMMDD HH24MISS') and TO_DATE('".concat(collectionDate).concat(" 235959', 'YYYYMMDD HH24MISS')"));
		returnMap = DALUtil.getResults(strSQL, "RESULT_TABLE");
		BigDecimal transferredAmount = new BigDecimal("0");
		if (returnMap.getBigDecimal("RESULT_TABLE", 0, "TUTAR") != null) {
			transferredAmount = returnMap.getBigDecimal("RESULT_TABLE", 0, "TUTAR");

		}
		int transferredCount = returnMap.getInt("RESULT_TABLE", 0, "ADET");


		String channelCode = CommonHelper.getChannelId();

		strSQL = "select count(payment_amount) C,sum(payment_amount) S from ics.invoice_payment where corporate_code='" + corporateMaster.getCorporateCode() + "' and payment_status='T' and status=1 and payment_channel=32 and payment_date like '" + collectionDate + "%'";
		returnMap = DALUtil.getResults(strSQL, "RESULT_TABLE");
		BigDecimal bankPaymentAmount = new BigDecimal("0");
		if (returnMap.getBigDecimal("RESULT_TABLE", 0, "S") != null) {
			bankPaymentAmount = returnMap.getBigDecimal("RESULT_TABLE", 0, "S");

		}

		BigDecimal bankPaymentCount = new BigDecimal("0");
		if (returnMap.getBigDecimal("RESULT_TABLE", 0, "C") != null) {
			bankPaymentCount = returnMap.getBigDecimal("RESULT_TABLE", 0, "C");
		}
		
		
		strSQL = "select count(payment_amount) C,sum(payment_amount) S from ics.invoice_payment where corporate_code='" + corporateMaster.getCorporateCode() + "' and payment_status='I' and status=1 and payment_channel=32 and payment_date like '" + collectionDate + "%'";
		returnCancelMap = DALUtil.getResults(strSQL, "RESULT_TABLE");
		BigDecimal bankPaymentCancelAmount = new BigDecimal("0");
		if (returnMap.getBigDecimal("RESULT_TABLE", 0, "S") != null) {
			bankPaymentCancelAmount = returnCancelMap.getBigDecimal("RESULT_TABLE", 0, "S");

		}

		BigDecimal bankPaymentCancelCount = new BigDecimal("0");
		if (returnMap.getBigDecimal("RESULT_TABLE", 0, "C") != null) {
			bankPaymentCancelCount = returnCancelMap.getBigDecimal("RESULT_TABLE", 0, "C");
		}
		
		BigDecimal commissionAmount = new BigDecimal(0);
		BigDecimal commissionCont = new BigDecimal(0);
		
		strSQL = "select pp.key1 from bnspr.gnl_param_text pp where pp.kod='CS_KURUM_KOMISYONSUZ' AND KEY1='" + institutionOid + "'";
		GMMap returnMapCommission = DALUtil.getResults(strSQL, "COMMISION_TABLE");
		if (returnMapCommission.get("COMMISION_TABLE") == null) {
			commissionAmount = new BigDecimal(transferredCount).multiply(new BigDecimal("0.05"));
			commissionCont = new BigDecimal(transferredCount);
		}
		


		if (Integer.parseInt(bankPaymentCount.toString()) == transferredCount && transferredCount == collectionCount && bankPaymentAmount.equals(transferredAmount) && transferredAmount.equals(collectionAmount)) {
			if (extChReconFail != null) {
				extChReconFail.setExtChannelCount(new BigDecimal(collectionCount));
				extChReconFail.setExtChannelAmount(collectionAmount);
				extChReconFail.setExtChannelCancelCount(cancelCount);
				extChReconFail.setExtChannelCancelAmount(cancelAmount);
				extChReconFail.setReconDate(collectionDate);
				extChReconFail.setCorporateOid(institutionOid);
				extChReconFail.setServiceCallDate(CommonHelper.getDateString(new Date(), "yyyyMMddHHmmss"));
				extChReconFail.setCreateDate(new Date());
				extChReconFail.setCreateUser(CommonHelper.getCurrentUser());
				extChReconFail.setBankAmount(bankPaymentAmount);
				extChReconFail.setBankCancelAmount(bankPaymentCancelAmount);
				extChReconFail.setBankCancelCount(bankPaymentCancelCount);
				extChReconFail.setBankCount(bankPaymentCount);
				extChReconFail.setTransferredAmount(transferredAmount);
				extChReconFail.setTransferredCount(new BigDecimal(transferredCount));
				extChReconFail.setCommissionAmount(commissionAmount);
				extChReconFail.setCommissionCount(commissionCont);
				extChReconFail.setReconStatus("S");
				returnMap.put("RESULT", "S");
				session.saveOrUpdate(extChReconFail);
			}else {
				ExtChannelReconciliation extRecon = new ExtChannelReconciliation();
				extRecon.setExtChannelCount(new BigDecimal(collectionCount));
				extRecon.setExtChannelAmount(collectionAmount);
				extRecon.setExtChannelCancelCount(cancelCount);
				extRecon.setExtChannelCancelAmount(cancelAmount);
				extRecon.setReconDate(collectionDate);
				extRecon.setCorporateOid(institutionOid);
				extRecon.setServiceCallDate(CommonHelper.getDateString(new Date(), "yyyyMMddHHmmss"));
				extRecon.setCreateDate(new Date());
				extRecon.setCreateUser(CommonHelper.getCurrentUser());
				extRecon.setBankAmount(bankPaymentAmount);
				extRecon.setBankCancelAmount(bankPaymentCancelAmount);
				extRecon.setBankCancelCount(bankPaymentCancelCount);
				extRecon.setBankCount(bankPaymentCount);
				extRecon.setTransferredAmount(transferredAmount);
				extRecon.setTransferredCount(new BigDecimal(transferredCount));
				extRecon.setCommissionAmount(commissionAmount);
				extRecon.setCommissionCount(commissionCont);
				extRecon.setReconStatus("S");
				returnMap.put("RESULT", "S");
				session.saveOrUpdate(extRecon);
			}
			
		}
		else {
			if (extChReconFail != null) {
				extChReconFail.setExtChannelCount(new BigDecimal(collectionCount));
				extChReconFail.setExtChannelAmount(collectionAmount);
				extChReconFail.setExtChannelCancelCount(cancelCount);
				extChReconFail.setExtChannelCancelAmount(cancelAmount);
				extChReconFail.setReconDate(collectionDate);
				extChReconFail.setCorporateOid(institutionOid);
				extChReconFail.setServiceCallDate(CommonHelper.getDateString(new Date(), "yyyyMMddHHmmss"));
				extChReconFail.setCreateDate(new Date());
				extChReconFail.setCreateUser(CommonHelper.getCurrentUser());
				extChReconFail.setBankAmount(bankPaymentAmount);
				extChReconFail.setBankCancelAmount(bankPaymentCancelAmount);
				extChReconFail.setBankCancelCount(bankPaymentCancelCount);
				extChReconFail.setBankCount(bankPaymentCount);
				extChReconFail.setTransferredAmount(transferredAmount);
				extChReconFail.setTransferredCount(new BigDecimal(transferredCount));
				extChReconFail.setCommissionAmount(commissionAmount);
				extChReconFail.setCommissionCount(commissionCont);
				extChReconFail.setReconStatus("F");
				returnMap.put("RESULT", "F");
				session.saveOrUpdate(extChReconFail);
			}else {
				ExtChannelReconciliation extRecon = new ExtChannelReconciliation();
				extRecon.setExtChannelCount(new BigDecimal(collectionCount));
				extRecon.setExtChannelAmount(collectionAmount);
				extRecon.setExtChannelCancelCount(cancelCount);
				extRecon.setExtChannelCancelAmount(cancelAmount);
				extRecon.setReconDate(collectionDate);
				extRecon.setCorporateOid(institutionOid);
				extRecon.setServiceCallDate(CommonHelper.getDateString(new Date(), "yyyyMMddHHmmss"));
				extRecon.setCreateDate(new Date());
				extRecon.setCreateUser(CommonHelper.getCurrentUser());
				extRecon.setBankAmount(bankPaymentAmount);
				extRecon.setBankCancelAmount(bankPaymentCancelAmount);
				extRecon.setBankCancelCount(bankPaymentCancelCount);
				extRecon.setBankCount(bankPaymentCount);
				extRecon.setTransferredAmount(transferredAmount);
				extRecon.setTransferredCount(new BigDecimal(transferredCount));
				extRecon.setCommissionAmount(commissionAmount);
				extRecon.setCommissionCount(commissionCont);
				extRecon.setReconStatus("F");
				returnMap.put("RESULT", "F");
				session.saveOrUpdate(extRecon);
			}
			
			
			
			// mutabakat basarisiz
		
		}



		

		return returnMap;
	}

	@GraymoundService("ICS_EXT_CHANNEL_SEARCH_RECON")
	public static GMMap extChannelSearchRecon(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		String startDate = iMap.getString("START_DATE");
		String endDate = iMap.getString("END_DATE");
		String status = iMap.getString("RECON_STATUS");
		GMMap outMap = new GMMap();
		try {
			Criteria cr = session.createCriteria(ExtChannelReconciliation.class);
			if (status != null) {
				if (!status.equals("0")) {
					cr.add(Restrictions.eq("reconStatus", status));
				}
			}
			if (startDate != null && iMap.getString("END_DATE") != null) {
				cr.add(Restrictions.between("reconDate", iMap.getString("START_DATE"), iMap.getString("END_DATE")));
			}
			if (endDate != null && startDate == null) {
				cr.add(Restrictions.le("reconDate", iMap.getDate("END_DATE")));
			}
			if (endDate == null && startDate != null) {
				cr.add(Restrictions.ge("reconDate", startDate));
			}
			String reconStatus = "-";
			List<ExtChannelReconciliation> extChannelRecon = cr.list();
			int i = 0;
			for (ExtChannelReconciliation extChannelReconciliation : extChannelRecon) {
				outMap.put("RECON_LIST", i, "BANK_AMOUNT", extChannelReconciliation.getBankAmount());
				outMap.put("RECON_LIST", i, "BANK_COUNT", extChannelReconciliation.getBankCount());
				outMap.put("RECON_LIST", i, "COMMISSION_AMOUNT", extChannelReconciliation.getCommissionAmount());
				outMap.put("RECON_LIST", i, "COMMISSION_COUNT", extChannelReconciliation.getCommissionCount());
				outMap.put("RECON_LIST", i, "EX_CH_AMOUNT", extChannelReconciliation.getExtChannelAmount());
				outMap.put("RECON_LIST", i, "EX_CH_COUNT", extChannelReconciliation.getExtChannelCount());
				outMap.put("RECON_LIST", i, "PROCESS_DATE", extChannelReconciliation.getCreateDate());
				outMap.put("RECON_LIST", i, "PROCESS_TIME", extChannelReconciliation.getReconTime());
				outMap.put("RECON_LIST", i, "RECON_DATE", extChannelReconciliation.getReconDate());
				outMap.put("RECON_LIST", i, "STATUS", extChannelReconciliation.getReconStatus());
				outMap.put("RECON_LIST", i, "TRANSFERRED_AMOUNT", extChannelReconciliation.getTransferredAmount());
				outMap.put("RECON_LIST", i, "TRANSFERRED_COUNT", extChannelReconciliation.getTransferredCount());
				outMap.put("RECON_LIST", i, "OID", extChannelReconciliation.getOid());
				CorporateMaster cm = (CorporateMaster) session.createCriteria(CorporateMaster.class).add(Restrictions.eq("oid", extChannelReconciliation.getCorporateOid())).uniqueResult();
				outMap.put("RECON_LIST", i, "CORPORATE_NAME", cm.getShortCode());
				if (extChannelReconciliation.getReconStatus().equals("F")) {
					reconStatus = "Ba�ar�s�z";
				}
				if (extChannelReconciliation.getReconStatus().equals("S")) {
					reconStatus = "Ba�ar�l�";
				}
				outMap.put("RECON_LIST", i, "RECON_STATUS", reconStatus);
				i++;
			}
		}
		catch (Exception e) {
		}

		return outMap;
	}

	@GraymoundService("ICS_EXT_CHANNEL_GET_SUMMARY")
	public static GMMap getChannelSummary(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		String searchDate = iMap.getString("SEARCH_DATE");
		GMMap outMap = new GMMap();
		try {
			String strSQL = "SELECT sum(transferred_count) TC,SUM(transferred_amount) TA," + "sum(bank_count) BC,SUM(bank_amount) BA," + "sum(ext_channel_count) EC,SUM(ext_channel_amount) EA," + "sum(commission_count) CC,SUM(commission_amount) CA " + "from cdm.ext_channel_reconciliation where " + "recon_status='S' and recon_Date ='".concat(searchDate).concat("'");
			GMMap returnMap = DALUtil.getResults(strSQL, "RESULT_TABLE");
			outMap.put("TC", (returnMap.getString("RESULT_TABLE", 0, "TC") != null) ? returnMap.getString("RESULT_TABLE", 0, "TC") : "0");
			outMap.put("TA", (returnMap.getString("RESULT_TABLE", 0, "TA") != null) ? returnMap.getString("RESULT_TABLE", 0, "TA") : "0");
			outMap.put("BC", (returnMap.getString("RESULT_TABLE", 0, "BC") != null) ? returnMap.getString("RESULT_TABLE", 0, "BC") : "0");
			outMap.put("BA", (returnMap.getString("RESULT_TABLE", 0, "BA") != null) ? returnMap.getString("RESULT_TABLE", 0, "BA") : "0");
			outMap.put("EC", (returnMap.getString("RESULT_TABLE", 0, "EC") != null) ? returnMap.getString("RESULT_TABLE", 0, "EC") : "0");
			outMap.put("EA", (returnMap.getString("RESULT_TABLE", 0, "EA") != null) ? returnMap.getString("RESULT_TABLE", 0, "EA") : "0");
			outMap.put("CC", (returnMap.getString("RESULT_TABLE", 0, "CC") != null) ? returnMap.getString("RESULT_TABLE", 0, "CC") : "0");
			outMap.put("CA", (returnMap.getString("RESULT_TABLE", 0, "CA") != null) ? returnMap.getString("RESULT_TABLE", 0, "CA") : "0");

		}
		catch (Exception e) {
		}

		return outMap;
	}

	@GraymoundService("ICS_EXT_CHANNEL_OPEN_RECON")
	public static GMMap openRecon(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		String oid = iMap.getString("OID");
		GMMap outMap = new GMMap();
		try {
			ExtChannelReconciliation extrecon = (ExtChannelReconciliation) session.createCriteria(ExtChannelReconciliation.class).add(Restrictions.eq("oid", oid)).uniqueResult();
			extrecon.setReconStatus("X");
			session.saveOrUpdate(extrecon);
		}
		catch (Exception e) {
		}
		return outMap;
	}

	@GraymoundService("ICS_EXT_CHANNEL_CLOSE_RECON")
	public static GMMap closeRecon(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		String oid = iMap.getString("OID");
		GMMap outMap = new GMMap();
		try {
			ExtChannelReconciliation extrecon = (ExtChannelReconciliation) session.createCriteria(ExtChannelReconciliation.class).add(Restrictions.eq("oid", oid)).uniqueResult();
			extrecon.setReconStatus("S");
			session.saveOrUpdate(extrecon);
		}
		catch (Exception e) {
		}
		return outMap;
	}

	 @GraymoundService("ICS_EXT_CHANNEL_UPDATE_RECON")
	 public static GMMap extChannelUpdateRecon(GMMap iMap) {
	
	 Session session = DAOSession.getSession("BNSPRDal");
	 GMMap returnMap = new GMMap();
	 BigDecimal bankPaymentAmount = iMap.getBigDecimal("BANK_AMOUNT");
	 BigDecimal bankPaymentCount = iMap.getBigDecimal("BANK_COUNT");
	 BigDecimal commissionAmount = iMap.getBigDecimal("COMMISSION_AMOUNT");
	 BigDecimal commissionCont = iMap.getBigDecimal("COMMISSION_COUNT");
	 BigDecimal collectionAmount = iMap.getBigDecimal("EX_CH_AMOUNT");
	 BigDecimal collectionCount = iMap.getBigDecimal("EX_CH_COUNT");
	 BigDecimal transferredAmount = iMap.getBigDecimal("TRANSFERRED_AMOUNT");
	 BigDecimal transferredCount = iMap.getBigDecimal("TRANSFERRED_COUNT");
	 
	 String  oid = iMap.getString("OID");
	 String reconStatus = iMap.getString("RECON_STATUS");
	 
	 if (reconStatus.equals("Ba�ar�s�z")) {
			reconStatus = "F";
		}
		if (reconStatus.equals("Ba�ar�l�")) {
			reconStatus = "S";
		}

		ExtChannelReconciliation extChRecon = (ExtChannelReconciliation) session.createCriteria(ExtChannelReconciliation.class).add(Restrictions.eq("oid", oid)).uniqueResult();
 	
		extChRecon.setExtChannelCount(collectionCount);
		extChRecon.setExtChannelAmount(collectionAmount);
		extChRecon.setCreateUser(CommonHelper.getCurrentUser());
		extChRecon.setBankAmount(bankPaymentAmount);
		extChRecon.setBankCount(bankPaymentCount);
		extChRecon.setTransferredAmount(transferredAmount);
		extChRecon.setTransferredCount(transferredCount);
		extChRecon.setCommissionAmount(commissionAmount);
		extChRecon.setCommissionCount(commissionCont);
		extChRecon.setReconStatus(reconStatus);
		returnMap.put("RESULT", reconStatus);
	
		session.saveOrUpdate(extChRecon);
	
	 return returnMap;
	
	 }

	public static Date getStartOfDate(Date date) throws Exception {
		return parseLongDateString(getShortDateString(date).concat("000000"));
	}

	public static Date getEndOfDate(Date date) throws Exception {
		return parseLongDateString(getShortDateString(date).concat("235959"));
	}

	public static String getShortDateString(Date date) {
		DateFormat shortDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
		return shortDateTimeFormat.format(date);
	}

	public static Date parseLongDateString(String date) throws Exception {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		return dateFormat.parse(date);
	}

}
