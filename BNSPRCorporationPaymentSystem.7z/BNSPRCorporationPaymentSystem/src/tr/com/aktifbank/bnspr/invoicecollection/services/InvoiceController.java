package tr.com.aktifbank.bnspr.invoicecollection.services;

import tr.com.aktifbank.bnspr.cps.transactions.ControlCollectionAmountHandler;
import tr.com.aktifbank.bnspr.cps.transactions.ControlDueDateHandler;
import tr.com.aktifbank.bnspr.cps.transactions.ControlEndOfDayHandler;
import tr.com.aktifbank.bnspr.cps.transactions.ControlInvoiceCollectionHandler;
import tr.com.aktifbank.bnspr.cps.transactions.ControlSubscriberMetaDataHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;


public class InvoiceController {
	@GraymoundService("ICS_INVOICE_COLLECTION_AMOUNT_CONTROL")
	public static GMMap controlCollectionAmount(GMMap input){
		return RequestProcessor.getInstance().process(input, new ControlCollectionAmountHandler());
	}
	
	@GraymoundService("ICS_INVOICE_DUE_DATE_CONTROL")
	public static GMMap controlDueDate(GMMap input){
		return RequestProcessor.getInstance().process(input, new ControlDueDateHandler());
	}
	
	@GraymoundService("ICS_CONTROL_INVOICE_COLLECTION")
	public static GMMap controlInvoiceCollection(GMMap input){
		return RequestProcessor.getInstance().process(input, new ControlInvoiceCollectionHandler());
	}
	
	@GraymoundService("ICS_CONTROL_SUBSCRIBER_META_DATA")
	public static GMMap controlSubscriberMetaData(GMMap input){
		return RequestProcessor.getInstance().process(input, new ControlSubscriberMetaDataHandler());
	}
	
	@GraymoundService("ICS_CONTROL_END_OF_DAY_CHECK")
	public static GMMap controlEndOfDayCheck(GMMap input){
		return RequestProcessor.getInstance().process(input, new ControlEndOfDayHandler());
	}
}
