package tr.com.aktifbank.bnspr.invoicecollection.services;

import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.transactions.CalculateCommissionHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class Accounting {
	@GraymoundService("ICS_DO_INVOICE_ACCOUNTING")
	public static GMMap doInvoiceAccounting(GMMap iMap) {
		
		GMMap outMap = new GMMap(); 
		try {
			
			GMMap accMap = new GMMap();
			accMap.put("CORPORATE_CODE", 	iMap.getString("CORPORATE_CODE"));
			accMap.put("COLLECTION_TYPE", 	iMap.getString("COLLECTION_TYPE"));
			accMap.put("CHANNEL_CODE", 		iMap.getString("CHANNEL_CODE"));
			accMap.put("SOURCE_CODE", 		iMap.getString("SOURCE_CODE"));
			
			accMap = (GMMap) GMServiceExecuter.execute("CDM_GET_CORPORATE_COLLECTION_ACCOUNT", accMap);
			
			GMMap accoutingMap = new GMMap();
			
			accoutingMap = calculateCommission(iMap);
			
			insertCommissionLog(accoutingMap,iMap.getString("INVOICE_MAIN_OID"), 
											 iMap.getString("INVOICE_COLLECTION_OID"));
			
			accoutingMap.put("REFERENCE_ID", iMap.getString(MapKeys.TRX_NO));
			accoutingMap.put("PROCESS_ID", 	"160051");
			accoutingMap.put("VALOR_DATE", 	iMap.getString(""));
			accoutingMap.put("USER_CODE", 	iMap.getString(""));
			accoutingMap.put("ORG_CODE",	iMap.getString(""));
			accoutingMap.put("SOURCE_ACC_CODE", iMap.getString(""));
			accoutingMap.put("TARGET_ACC_CODE", iMap.getString(""));
			accoutingMap.put("AMOUNT", 			iMap.getString(""));
			accoutingMap.put("CHANNEL_CODE", 	iMap.getString(""));
			accoutingMap.put("VOUCHER_DESC", 	iMap.getString(""));
			accoutingMap.put("PAYMENT_SOURCE", 	iMap.getString(""));
			accoutingMap.put("CREDIT_CARD_NUMBER", iMap.getString(""));
			accoutingMap.put("AMOUNT_MT", 		iMap.getString(""));
			accoutingMap.put("CREATOR_USER", 	iMap.getString(""));
			accoutingMap.put("STATEMENT_DESC1", iMap.getString(""));
			accoutingMap.put("STATEMENT_DESC2", iMap.getString(""));
			accoutingMap.put("STATEMENT_DESC3", iMap.getString(""));
			accoutingMap.put("PAYMENT_TYPE", 	iMap.getString(""));
			
			accoutingMap.put("AGENT_CODE", iMap.getString(""));
			accoutingMap.put("INSTITUTION_OID", iMap.getString(""));

			GMMap returnMap = (GMMap) GMServiceExecuter.execute("CS_DO_ACCOUNTING_NEW", accoutingMap);
			
			if (returnMap.getString("RESULT").equals("2")) {
				outMap.put("RESULT", returnMap.getString("RESULT"));
				outMap.put("VOUCHER_NO", returnMap.getString("VOUCHER_NO"));
			}else {
				outMap.put("RESULT", returnMap.getString("RESULT"));
				outMap.put("ERROR_DESC", returnMap.getString("ERROR_DESC"));
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
		
	}
	
	private static void insertCommissionLog(GMMap accoutingMap, String invoiceMainOid,
			String invoiceCollectionOid) {

		
	}
	
	@GraymoundService("ICS_CALCULATE_COMMISSION")
	public static GMMap calculateCommission(GMMap iMap) {
		return RequestProcessor.getInstance().process(iMap, new CalculateCommissionHandler());
	}
}
