package tr.com.aktifbank.bnspr.invoicecollection.engine;

import java.sql.Clob;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.CommonHelper;
import tr.com.aktifbank.bnspr.cps.common.MapKeys;
import tr.com.aktifbank.bnspr.cps.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.cps.util.OnlineServiceStatus;
import tr.com.aktifbank.bnspr.dao.OnlineGmServices;
import tr.com.aktifbank.bnspr.dao.WebServices;
import tr.com.aktifbank.bnspr.dao.WsSaf;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SAFEngine implements OnlineServiceStatus {

	@GraymoundService("CDM_SAF_MANAGEMENT_LOAD_COMBO")
	public static GMMap loadCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {

			@SuppressWarnings("unchecked")
			List<OnlineGmServices> onlineGmServiceList = session.createCriteria(OnlineGmServices.class).add(Restrictions.eq("status", true)).list();

			for (int i = 0; i < onlineGmServiceList.size(); i++) {
				oMap.put("CORPORATE_SERVICE_NAME_LIST", i, "NAME", onlineGmServiceList.get(i).getGmServiceName());
				oMap.put("CORPORATE_SERVICE_NAME_LIST", i, "VALUE", onlineGmServiceList.get(i).getOid());

				@SuppressWarnings("unchecked")
				List<WebServices> webServicesList = session.createCriteria(WebServices.class).add(Restrictions.eq("status", true))
						.add(Restrictions.eq("corporateCode", iMap.getString("CORPORATE_CODE"))).list();

				for (int j = 0; j < webServicesList.size(); j++) {
					oMap.put("WEB_SERVICE_NAME_LIST", j, "NAME", webServicesList.get(j).getServiceName());
					oMap.put("WEB_SERVICE_NAME_LIST", j, "VALUE", webServicesList.get(j).getOid());

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	@GraymoundService("CDM_SAF_GET_SERVICE_STATUS_COMBO")
	public static GMMap getServiceStatusCombo(GMMap iMap) {
		return CorporationServiceUtil.getComboValues(iMap);
	}

	@GraymoundService("CDM_SAF_GET_RECORD_DETAIL")
	public static GMMap getRecordDetail(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap pMap = new GMMap();
		WsSaf wsSaf = getWsSafInstance(iMap.getString("OID"));
		String dateTime;
		String[] splits;

		if (iMap.getString("LAST_SEND_DATE") == null) {
			// dateTime = iMap.getString("FIRST_SEND_DATE");
			oMap.put("DATE", "");
			oMap.put("TIME", "");
		} else {
			dateTime = iMap.getString("LAST_SEND_DATE");
			splits = dateTime.split(" ");
			try {
				oMap.put("DATE", convertToDate(splits[0].toString(), "dd/MM/yyyy", "yyyyMMdd"));
				oMap.put("TIME", splits[1].toString().replace(":", ""));
			} catch (Exception e) {
				oMap.put("DATE", "");
				oMap.put("TIME", "");
			}
		}

		Clob clob = wsSaf.getParameters();

		if (clob != null) {
			try {
				pMap = CommonHelper.deserializeRequest(clob.getSubString(1, (int) clob.length()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		for (int i = 0; i < pMap.size(); i++) {
			oMap.put("RESULTS", i, "INPUT", pMap.keySet().toArray()[i].toString());
			oMap.put("RESULTS", i, "VALUE", pMap.get(pMap.keySet().toArray()[i].toString()));
		}

		return oMap;
	}

	public static String convertToDate(String strDate, String pattern, String newPattern) {
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		SimpleDateFormat sdf = new SimpleDateFormat(newPattern);
		Date date = null;
		try {
			date = format.parse(strDate);
			return sdf.format(date).toString();
		} catch (Exception e) {
			return strDate;
		}
	}

	@GraymoundService("CDM_SAF_GET_SERVICE_LIST")
	public static GMMap getSafServiceList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String tableName = "SAF_SERVICE_LIST";
		int row = 0;

		iMap.put("KOD", "CDM_SAF_STATUS");
		GMMap statusMap = CorporationServiceUtil.getComboValues(iMap);

		@SuppressWarnings("unchecked")
		List<WsSaf> wsSafList = session.createCriteria(WsSaf.class).add(Restrictions.eq("status", true))
				.add(Restrictions.eq("gmServiceName", iMap.getString("GM_SERVICE_NAME")))
				.add(Restrictions.eq("webServiceName", iMap.getString("CORPORATE_WEB_SERVICE_NAME")))
				.add(Restrictions.like("firstSendDate", iMap.getString("FIRST_DATE"), MatchMode.START))
				.add(Restrictions.eq("sendStatus", iMap.getString("SERVICE_STATUS"))).list();

		for (WsSaf wsSaf : wsSafList) {
			oMap.put(tableName, row, "OID", wsSaf.getOid());
			oMap.put(tableName, row, "CORPORATE_CODE", wsSaf.getCorporateCode());
			oMap.put(tableName, row, "ERROR_CODE", wsSaf.getErrorCode());
			oMap.put(tableName, row, "ERROR_DESC", wsSaf.getErrorDesc());
			oMap.put(tableName, row, "GM_SERVICE_NAME", wsSaf.getGmServiceName());
			oMap.put(tableName, row, "FIRST_SEND_DATE", convertToDate(String.valueOf(wsSaf.getFirstSendDate()), "yyyyMMddHHmmssSSSS", "dd/MM/yyyy HH:mm:ss"));
			oMap.put(tableName, row, "LAST_SEND_DATE", convertToDate(String.valueOf(wsSaf.getLastSendDate()), "yyyyMMddHHmmssSSSS", "dd/MM/yyyy HH:mm:ss"));
			oMap.put(tableName, row, "OID", wsSaf.getOid());
			oMap.put(tableName, row, "LAST_SEND_USER", wsSaf.getLastSendUser());
			for (int i = 0; i < statusMap.getSize("RESULTS"); i++) {
				if (statusMap.get("RESULTS", i, "VALUE").equals(wsSaf.getSendStatus())) {
					oMap.put(tableName, row, "SEND_STATUS", statusMap.get("RESULTS", i, "NAME"));
					oMap.put(tableName, row, "SEND_STATUS_CODE", statusMap.get("RESULTS", i, "VALUE"));
					break;
				}
			}
			oMap.put(tableName, row, "TRY_COUNT", wsSaf.getTryCount());
			oMap.put(tableName, row, "WEB_SERVICE_NAME", wsSaf.getWebServiceName());
			row++;
		}
		return oMap;
	}

	@GraymoundService("CDM_SAF_RESEND_SELECTED")
	public static GMMap resendSelected(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap resendMap = new GMMap();
		for (int i = 0; i < iMap.getSize("TABLE"); i++) {
			if (iMap.getString("TABLE", i, "CHECKED").equals("1")) {
				resendMap.put("OID", iMap.getString("TABLE", i, "OID"));
				resend(resendMap);
			}
		}
		return oMap;
	}

	@GraymoundService("CDM_SAF_RESEND")
	public static GMMap resend(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap serviceInputMap = new GMMap();

		WsSaf wsSaf = getWsSafInstance(iMap.getString("OID"));
		try {		
		if (wsSaf.getSendStatus().equals(SAF_FAILED)) {// V_ML_GNL_PARAM_TEXT tablosundan CDM_SAF_STATUS kodu ile geliyor
				Clob clob = wsSaf.getParameters();
				if (clob != null) {
						serviceInputMap =CommonHelper.deserializeRequest(clob.getSubString(1, (int) clob.length()));
						serviceInputMap.put("SAF", 1);
						GMMap returnMap = GMServiceExecuter.call(wsSaf.getWebServiceName(), serviceInputMap);
						if (returnMap.getInt(MapKeys.ERROR_CODE) == 0) {
							//ba�ar�l�
							wsSaf.setSendStatus(SAF_SUCCESFUL);
							oMap.put("RUNNING_RESULT", "S");
						}else {
							//bussines hata
							wsSaf.setSendStatus(SAF_FAILED);
							wsSaf.setErrorCode(returnMap.getString(MapKeys.ERROR_CODE));
							wsSaf.setErrorDesc(returnMap.getString(MapKeys.ERROR_DESC) );
							oMap.put("RUNNING_RESULT", "F");
						}
						wsSaf.setLastSendDate(Long.parseLong(CommonHelper.getHugeDateTimeString(new Date())));
						wsSaf.setLastSendUser(GMContext.getCurrentContext().getSession().get("USER_NAME").toString());
				}
			}
		} catch (Exception e) {
			wsSaf.setSendStatus(SAF_FAILED);
			wsSaf.setErrorCode("1005");
			wsSaf.setErrorDesc(e.getMessage());
			wsSaf.setLastSendDate(Long.parseLong(CommonHelper.getHugeDateTimeString(new Date())));
			wsSaf.setLastSendUser(GMContext.getCurrentContext().getSession().get("USER_NAME").toString());
			e.printStackTrace();
			oMap.put("RUNNING_RESULT", "F");
		}finally{
			Session session = DAOSession.getSession("BNSPRDal");
			session.update(wsSaf);			
		}
		return oMap;
	}

	public static WsSaf getWsSafInstance(String oId) {

		Session session = DAOSession.getSession("BNSPRDal");
		WsSaf wsSaf = (WsSaf) session.createCriteria(WsSaf.class).add(Restrictions.eq("status", true)).add(Restrictions.eq("oid", oId))
				.uniqueResult();
		return wsSaf;

	}

}
