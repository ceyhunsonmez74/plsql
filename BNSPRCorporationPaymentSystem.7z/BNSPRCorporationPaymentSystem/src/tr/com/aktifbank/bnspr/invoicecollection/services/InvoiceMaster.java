package tr.com.aktifbank.bnspr.invoicecollection.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cps.common.TransactionConstants.CancelAllWaitingInvoices;
import tr.com.aktifbank.bnspr.cps.transactions.DeleteWaitedInvoiceHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InsertInvoiceHandler;
import tr.com.aktifbank.bnspr.cps.transactions.InsertInvoiceWithStandingOrderHandler;
import tr.com.aktifbank.bnspr.cps.transactions.ProcessInvoiceWithCommandHandler;
import tr.com.aktifbank.bnspr.cps.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.dao.invoiceMain;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class InvoiceMaster {
	
	
	@GraymoundService("ICS_UPDATE_INVOICE_AFTER_COLLECTION")
	public static GMMap updateInvoiceAfterCollection(GMMap iMap) {
		
		return iMap;
	}
	
	
	@GraymoundService("ICS_CREATE_INVOICE_RECORD_FOR_DECLARATION_PAYMENT")
	public static GMMap createInvoiceRecordForDeclarationPayment(GMMap iMap) {
		
		return iMap;
	}

	
	@GraymoundService("ICS_INSERT_INVOICE_COLLECTION_RECORD")
	public static GMMap createInvoiceCollectionRecord(GMMap iMap) {
		
		return iMap;
	}
	
	
	@GraymoundService("ICS_INSERT_INVOICE_COLLECTION_LOG")
	public static GMMap createInvoiceCollectionLog(GMMap iMap) {
		
		return iMap;
	}
	
	@GraymoundService("ICS_INSERT_INVOICE")
	public static GMMap insertInvoice(GMMap input){
		return RequestProcessor.getInstance().process(input, new InsertInvoiceHandler());
	}
	
	@GraymoundService("ICS_INSERT_INVOICE_WITH_STANDING_ORDER")
	public static GMMap insertInvoiceWithStandingOrder(GMMap input){
		return RequestProcessor.getInstance().process(input, new InsertInvoiceWithStandingOrderHandler());
	}
	
	@GraymoundService("ICS_DELETE_WAITED_INVOICE")
	public static GMMap deletePendingInvoices(GMMap input){
		return RequestProcessor.getInstance().process(input, new DeleteWaitedInvoiceHandler());
	}
	
	@GraymoundService("ICS_PROCESS_INVOICE_WITH_COMMAND")
	public static GMMap processInvoiceWithCommand(GMMap input){
		return RequestProcessor.getInstance().process(input, new ProcessInvoiceWithCommandHandler());
	}
	
	@GraymoundService("STO_CANCEL_ALL_WAITING_INVOICES")
	public static GMMap cancelAllWaitingInvoices(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap outMap = new GMMap();
		try {
			@SuppressWarnings("unchecked")
			List<invoiceMain> somList = (List<invoiceMain>) session.createCriteria(invoiceMain.class)
					.add(Restrictions.eq("standingOrderOid", iMap.getString(CancelAllWaitingInvoices.Input.STANDING_ORDER_MAIN_OID)))
					.add(Restrictions.eq("status", true)).add(Restrictions.eq("invoiceStatus", "A")).add(Restrictions.eq("paymentStatus", "B"))
					.list();
			for (invoiceMain invoiceMain : somList) {
				invoiceMain.setStatus(false);
				session.update(invoiceMain);
			}
			session.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return outMap;
	}
	
}
