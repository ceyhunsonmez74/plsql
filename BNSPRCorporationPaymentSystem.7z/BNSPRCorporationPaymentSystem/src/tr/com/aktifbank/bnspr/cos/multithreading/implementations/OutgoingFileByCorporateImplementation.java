package tr.com.aktifbank.bnspr.cos.multithreading.implementations;

import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.OutgoingFileLoadingInformation;
import tr.com.aktifbank.bnspr.cos.dto.OutgoingFileStarterInformation;
import tr.com.aktifbank.bnspr.cos.multithreading.core.ParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cos.multithreading.core.PartialParallelCallBehaviour;
import tr.com.aktifbank.bnspr.cos.multithreading.core.ServiceBasedMultiThreading;

import com.graymound.util.GMMap;

public final class OutgoingFileByCorporateImplementation extends ServiceBasedMultiThreading {

	private OutgoingFileStarterInformation information;
	
	public OutgoingFileByCorporateImplementation(OutgoingFileStarterInformation information){
		super();
		this.information = information;
	}
	
	@Override
	protected void prepareCall() throws Throwable {
		for(OutgoingFileLoadingInformation loadingInformation : this.information.getFileLoadingInformation()){
			GMMap input = new GMMap();
			input.put(TransactionConstants.StartCorporateBatch.Input.BATCH_NAME, loadingInformation.getBatchName());
			input.put(TransactionConstants.StartCorporateBatch.Input.CORPORATE_CODE, loadingInformation.getCorporateCode());
			input.put(TransactionConstants.StartCorporateBatch.Input.FORMAT_ID, loadingInformation.getFormatId());			
			input.put(TransactionConstants.StartCorporateBatch.Input.FTM_ID, loadingInformation.getFtmId());
			input.put(TransactionConstants.StartCorporateBatch.Input.PROCESS_DATE, information.getProcessDate());
			input.put(TransactionConstants.StartCorporateBatch.Input.PROCESS_DATE_LONG_DATE_TIME_FORMAT, information.getProcessDateLongDateTimeFormat());
			input.put(TransactionConstants.StartCorporateBatch.Input.INFORM_INDICATOR, information.getInformIndicator());
			input.put(TransactionConstants.StartCorporateBatch.Input.FILE_TRANSFER_ID, loadingInformation.getFileTransferId());
			input.put(TransactionConstants.StartCorporateBatch.Input.TRANSFER_TYPE, loadingInformation.getTransferType());
			input.put(TransactionConstants.StartCorporateBatch.Input.LOADING_BATCH_SUBMIT_ID, loadingInformation.getLoadingBatchSubmitId());
			input.put(TransactionConstants.StartCorporateBatch.Input.LOADING_FTM_SEQUENCE_NUMBER, loadingInformation.getLoadingFtmSequenceNumber());
			input.put(TransactionConstants.StartCorporateBatch.Input.FILE_CONSTANT, loadingInformation.getFileTypeConstant());			
			input.put(TransactionConstants.StartCorporateBatch.Input.FILE_NAME, loadingInformation.getFileName());			
			super.registerService(this.information.getServiceName(), input);
		}
	}
	
	@Override
	protected ParallelCallBehaviour getParallelCallBehaviour() {
		return new PartialParallelCallBehaviour(this.information.getMaxParallelThreadCount(), true);
	}
	
	@Override
	protected void afterCall() throws Throwable {
		if (!this.isHasError()) {
			StringBuilder builder = new StringBuilder();
			for (GMMap output : super.getServiceOutputs()) {
				if (!output.getBoolean(TransactionConstants.StartCorporateBatch.Output.RESULT, false)) {
					this.setHasError(true);
					this.setErrorCode("0");
					builder.append(String.format("An exception occured while informing information for %s corporate code, %s transfer id and %s submit id. ", 
							output.getString(TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE),
							information.getInformIndicator(),
							output.getString(TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID)));
				}
			}
			
			if(this.isHasError()){
				this.setErrorMessage(builder.toString());
			}
		}
	}
}
