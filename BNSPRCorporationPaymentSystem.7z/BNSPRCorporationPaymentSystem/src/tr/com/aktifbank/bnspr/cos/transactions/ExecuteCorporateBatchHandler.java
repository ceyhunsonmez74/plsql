package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import tr.com.aktifbank.bnspr.cos.batch.implementations.OutgoingFileBatch;
import tr.com.aktifbank.bnspr.cos.batch.implementations.OutgoingFileBatchFactory;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cos.dto.OutgoingFileBatchInformation;

import com.graymound.util.GMMap;

public final class ExecuteCorporateBatchHandler extends
		RequestHandler {
	
	public ExecuteCorporateBatchHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE);
		List<FormatDetail> bodyDetails = (List<FormatDetail>) input.get(TransactionConstants.CorporateGeneralBatchSubmit.Input.BODY_DETAILS);
		List<FormatDetail> headerDetails = (List<FormatDetail>) input.get(TransactionConstants.CorporateGeneralBatchSubmit.Input.HEADER_DETAILS);
		List<FormatDetail> footerDetails = (List<FormatDetail>) input.get(TransactionConstants.CorporateGeneralBatchSubmit.Input.FOOTER_DETAILS);		
		Date processDate = input.getDate(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE);
		BigDecimal ftmProcessId = input.getBigDecimal(TransactionConstants.CorporateGeneralBatchSubmit.Input.FTM_PROCESS_ID);
		GMMap databaseFields = input.getMap(TransactionConstants.CorporateGeneralBatchSubmit.Input.DATABASE_FIELDS);
		GMMap serviceFields = input.getMap(TransactionConstants.CorporateGeneralBatchSubmit.Input.SERVICE_FIELDS);
		GMMap batchParameters = input.getMap(TransactionConstants.CorporateGeneralBatchSubmit.Input.BATCH_PARAMETERS, null);
		short informIndicator = (short)input.getInt(TransactionConstants.CorporateGeneralBatchSubmit.Input.INFORM_INDICATOR);
		String loadingBatchSubmitId = input.getString(TransactionConstants.CorporateGeneralBatchSubmit.Input.LOADING_BATCH_SUBMIT_ID);
		BigDecimal loadingFtmSequenceNumber = input.getBigDecimal(TransactionConstants.CorporateGeneralBatchSubmit.Input.LOADING_FTM_SEQUENCE_NUMBER);
		int lineNumber = input.getInt(TransactionConstants.CorporateGeneralBatchSubmit.Input.LINE_NUMBER, 1);
		
		OutgoingFileBatchInformation information = new OutgoingFileBatchInformation();
		information.setCorporateCode(corporateCode);
		information.setHeaderDetails(headerDetails);		
		information.setBodyDetails(bodyDetails);
		information.setFooterDetails(footerDetails);		
		information.setProcessDate(processDate);
		information.setFtmProcessId(ftmProcessId);
		information.setDatabaseFields(databaseFields);
		information.setServiceFields(serviceFields);		
		information.setOutgoingFileBatchInput(input);
		information.setHibernateSession(super.getHibernateSession());
		information.setLineNumber(lineNumber);
		information.setLoadingBatchSubmitId(loadingBatchSubmitId);
		information.setLoadingFtmSequenceNumber(loadingFtmSequenceNumber);
		
		if(batchParameters != null){
			// TODO Parameter Implementation
		}
		
		logger.info("Creating outgoing file batch instance with factory command : " + informIndicator);
		
		OutgoingFileBatch batch = OutgoingFileBatchFactory.getInstance().createBatch(informIndicator, information);
		logger.info("Executing outgoing file batch");
		batch.execute();

		if( batch.isErrorExist() ){
			String errorMessage = batch.getErrorMessage();
			String errorCode = batch.getErrorCode();
			
			logger.error(String.format("An exception occurred while executing outgoing file batch was prepared. Details [Error Code : %s ], [Error Description : %s ]"
					, errorCode
					, errorMessage));
			
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.RESULT, false);
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_CODE, errorCode);
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_MESSAGE, errorMessage);
		}
		else{
			logger.info("Flushing lines to database");
			super.getHibernateSession().flush();
			
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.RESULT, true);
			output.put(TransactionConstants.CorporateGeneralBatchSubmit.Output.AFTER_PROCESS_LINE_NUMBER, information.getAfterProcessLineNumber());
		}		
	}
}
