package tr.com.aktifbank.bnspr.cos.util;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.transactions.ApprovedPaymentTransferHandler;
import tr.com.aktifbank.bnspr.cos.transactions.CheckRepeatedFileHandler;
import tr.com.aktifbank.bnspr.cos.transactions.CheckRepeatedOrderHandler;
import tr.com.aktifbank.bnspr.cos.transactions.ComposeEmailHandler;
import tr.com.aktifbank.bnspr.cos.transactions.ComposeEodPaymentsConfirmationEmailHandler;
import tr.com.aktifbank.bnspr.cos.transactions.CreateEodPaymentsConfirmationStarterHandler;
import tr.com.aktifbank.bnspr.cos.transactions.CreateLoadingConfirmationStarterHandler;
import tr.com.aktifbank.bnspr.cos.transactions.CreateOutgoingFileByFtmCallHandler;
import tr.com.aktifbank.bnspr.cos.transactions.CreateOutgoingFileHandler;
import tr.com.aktifbank.bnspr.cos.transactions.CreatePaymentsConfirmationStarterHandler;
import tr.com.aktifbank.bnspr.cos.transactions.DoLoadingAndPaymentControlsHandler;
import tr.com.aktifbank.bnspr.cos.transactions.DoTransferAndUpdateHandler;
import tr.com.aktifbank.bnspr.cos.transactions.ExecuteCorporateBatchHandler;
import tr.com.aktifbank.bnspr.cos.transactions.ExtOrderLoadingHandler;
import tr.com.aktifbank.bnspr.cos.transactions.FailedPaymentTransferHandler;
import tr.com.aktifbank.bnspr.cos.transactions.GetFailedLineCountStatusAtControlsHandler;
import tr.com.aktifbank.bnspr.cos.transactions.GetOrderBatchDetailHandler;
import tr.com.aktifbank.bnspr.cos.transactions.GetOrderBatchParametersHandler;
import tr.com.aktifbank.bnspr.cos.transactions.InsertExtOrderMainHandler;
import tr.com.aktifbank.bnspr.cos.transactions.LockOrdersForProcessHandler;
import tr.com.aktifbank.bnspr.cos.transactions.OrderFtmBatchStarterHandler;
import tr.com.aktifbank.bnspr.cos.transactions.OrderLoadingControlsHandler;
import tr.com.aktifbank.bnspr.cos.transactions.OrderLoadingHandler;
import tr.com.aktifbank.bnspr.cos.transactions.OrderTransferHandler;
import tr.com.aktifbank.bnspr.cos.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cos.transactions.StartCorporateBatchHandler;
import tr.com.aktifbank.bnspr.cos.transactions.UpdateOrderFileLogHandler;
import tr.com.aktifbank.bnspr.cos.transactions.UpdateOrderMainHandler;
import tr.com.aktifbank.bnspr.cos.transactions.UpdateOrderMainStatusHandler;
import tr.com.aktifbank.bnspr.cos.transactions.UpdateOutgoingFileStatusHandler;
import tr.com.aktifbank.bnspr.cos.transactions.UpdateTransactionStatusHandler;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class BatchUtilities {
	
	@GraymoundService("COS_ORDER_FTM_BATCH_STARTER")
	public static GMMap ftmBatchStarter(GMMap FTMMap) {
		return RequestProcessor.getInstance().process(FTMMap, new OrderFtmBatchStarterHandler());
	}
	
	 @GraymoundService("COS_BATCH_ORDER_LOADING")
	 public static GMMap batchOrderLoading (GMMap iMap) {
		 return RequestProcessor.getInstance().process(iMap, new OrderLoadingHandler());
	 }
	 
	 @GraymoundService("COS_INSERT_EXT_ORDER_MAIN")
	 public static GMMap insertExtOrderMain(GMMap input) {
		return RequestProcessor.getInstance().process(input, new InsertExtOrderMainHandler());
	}
	 
	 @GraymoundService("COS_EXT_BATCH_ORDER_LOADING")
	 public static GMMap extOrderLoading (GMMap iMap) {
		 return RequestProcessor.getInstance().process(iMap, new ExtOrderLoadingHandler());
	 }

	@GraymoundService("COS_GET_CORPORATE_BATCH_DETAIL")
	public static GMMap getBatchDetail(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetOrderBatchDetailHandler());
	}
	
	@GraymoundService("COS_GET_CORPORATE_BATCH_PARAMETERS")
	public static GMMap getBatchParameters(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetOrderBatchParametersHandler());
	}
	
	@GraymoundService("COS_UPDATE_ORDER_MAIN_AND_TRANSFER_LOG")
	public static GMMap updateOrderMain(GMMap input) {
		return RequestProcessor.getInstance().process(input, new UpdateOrderMainHandler());
	}
	
	@GraymoundService("COS_GET_FAILED_LINE_COUNT_AND_FILE_STATUS")
	public static GMMap getFailedLineCountStatus(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetFailedLineCountStatusAtControlsHandler());
	}
	
	@GraymoundService("COS_UPDATE_ORDER_MAIN_STATUS")
	public static GMMap updateOrderMainStatus(GMMap input) {
		return RequestProcessor.getInstance().process(input, new UpdateOrderMainStatusHandler());
	}
	
	@GraymoundService("COS_UPDATE_TRANSACTION_STATUS")
	public static GMMap updateTransactionStatus(GMMap input) {
		return RequestProcessor.getInstance().process(input, new UpdateTransactionStatusHandler());
	}
	
	@GraymoundService("COS_UPDATE_ORDER_FILE_LOG")
	public static GMMap updateOrderFileLog(GMMap input) {
		return RequestProcessor.getInstance().process(input, new UpdateOrderFileLogHandler());
	}
	
	@GraymoundService("COS_ORDER_LOADING_CONTROLS")
	public static GMMap orderLoadingControls(GMMap input) {
		return RequestProcessor.getInstance().process(input, new OrderLoadingControlsHandler());
	}
		
	@GraymoundService("COS_CHECK_REPEATED_FILE")
	public static GMMap checkRepeatedFile(GMMap input) {
		return RequestProcessor.getInstance().process(input, new CheckRepeatedFileHandler());
	}
	
	@GraymoundService("COS_CHECK_REPEATED_ORDER")
	public static GMMap checkRepeatedOrder(GMMap input) {
		return RequestProcessor.getInstance().process(input, new CheckRepeatedOrderHandler());
	}
	
	@GraymoundService("COS_DO_LOADING_AND_PAYMENT_CONTROLS")
	public static GMMap doLoadingAndPaymentControls(GMMap input) {
		return RequestProcessor.getInstance().process(input, new DoLoadingAndPaymentControlsHandler());
	}
	
	@GraymoundService("COS_DO_TRANSFER_AND_UPDATE")
	public static GMMap doTransferAndUpdate(GMMap input) {
		return RequestProcessor.getInstance().process(input, new DoTransferAndUpdateHandler());
	}
	
	@GraymoundService("COS_ORDER_TRANSFERS_APPROVED")
	public static GMMap orderTransfersApproved(GMMap input) {
		return RequestProcessor.getInstance().process(input, new OrderTransferHandler());
	}
	
	@GraymoundService("COS_FAILED_PAYMENT_TRANSFER")
	public static GMMap failedPaymentTransfer(GMMap input) {
		return RequestProcessor.getInstance().process(input, new FailedPaymentTransferHandler());
	}
	
	@GraymoundService("COS_APPROVED_PAYMENT_TRANSFER")
	public static GMMap approvedPaymentTransfer(GMMap input) {
		return RequestProcessor.getInstance().process(input, new ApprovedPaymentTransferHandler());
	}
	
	@GraymoundService("COS_COMPOSE_EMAIL")
	public static GMMap composeEmail(GMMap input) {
		return RequestProcessor.getInstance().process(input, new ComposeEmailHandler());
	}	
	
	@GraymoundService("COS_CREATE_OUTGOING_FILE")
	public static GMMap createOutgoingFile(GMMap input){
		return RequestProcessor.getInstance().process(input, new CreateOutgoingFileHandler());
	}
	
	@GraymoundService("COS_CREATE_OUTGOING_FILE_BY_FTM_CALL")
	public static GMMap createOutgoingFileByFtmCall(GMMap input){
		return RequestProcessor.getInstance().process(input, new CreateOutgoingFileByFtmCallHandler());
	}
	
	@GraymoundService("COS_UPDATE_OUTGOING_FILE_STATUS")
	public static GMMap updateOutgoingFileStatus(GMMap input){
		return RequestProcessor.getInstance().process(input, new UpdateOutgoingFileStatusHandler());
	}
	
	@GraymoundService("COS_CREATE_LOADING_CONFIRMATION_STARTER")
	public static GMMap createLoadingConfirmationStarter(GMMap input) {
		input.put(TransactionConstants.CreateLoadingConfirmationStarter.Input.INDICATOR, GeneralConstants.LOADING_CONFIRMATION);
		return RequestProcessor.getInstance().process(input, new CreateLoadingConfirmationStarterHandler());
	}
	
	@GraymoundService("COS_CREATE_PAYMENTS_CONFIRMATION_STARTER")
	public static GMMap createPaymentsConfirmationStarter(GMMap input) {
		input.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.INDICATOR, GeneralConstants.PAYMENTS_CONFIRMATION);
		return RequestProcessor.getInstance().process(input, new CreatePaymentsConfirmationStarterHandler());
	}
	
	@GraymoundService("COS_CREATE_EOD_PAYMENTS_CONFIRMATION_STARTER")
	public static GMMap createEodPaymentsConfirmationStarter(GMMap input){
		input.put(TransactionConstants.CreateEodPaymentsConfirmationStarter.Input.INDICATOR, GeneralConstants.EOD_PAYMENTS_CONFIRMATION);
		return RequestProcessor.getInstance().process(input, new CreateEodPaymentsConfirmationStarterHandler());
	}
	
	@GraymoundService("COS_CREATE_EOD_PAYMENTS_CONFIRMATION")
	public static GMMap composeEodPaymentsConfirmationEmail(GMMap input){
		return RequestProcessor.getInstance().process(input, new ComposeEodPaymentsConfirmationEmailHandler());
	}
	
	@GraymoundService("COS_CORPORATE_BATCH_STARTER")
	public static GMMap startCorporateBatch(GMMap input) {
		return RequestProcessor.getInstance().process(input, new StartCorporateBatchHandler());
	}
	
	@GraymoundService("COS_CORPORATE_EXECUTE_BATCH")
	public static GMMap executeCorporateBatch(GMMap input) {
		return RequestProcessor.getInstance().process(input, new ExecuteCorporateBatchHandler());
	}
	
	@GraymoundService("COS_GET_BATCH_NAMES_COMBO")
	public static GMMap getBatchNamesCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "BATCH_NAMES";
		try {
			String query = QueryRepository.CosBatchUtilitiesRepository.BATCH_NAME_QUERY; 
			
			GMMap resultMap = DALUtil.getResults(query, tableName);

			for(int index = 0 ; index < resultMap.getSize(tableName); index++) {
				GuimlUtil.wrapMyCombo(oMap, tableName , resultMap.getString(tableName, index, "BATCH_NAME"),
														resultMap.getString(tableName, index, "BATCH_NAME"));				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("COS_GET_TRANSFER_TYPES_COMBO")
	public static GMMap getTransferTypesCombo(GMMap iMap) {		
		GMMap oMap = new GMMap();
		try {			
			String func = QueryRepository.CosBatchUtilitiesRepository.TRANSFER_TYPES_QUERY;			
			
			oMap = DALUtil.fillComboBox(iMap, "TRANSFER_TYPES", false, func);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("COS_LOCK_ORDERS_FOR_PROCESS")
	public static GMMap lockOrdersForProcess(GMMap input) {
		return RequestProcessor.getInstance().process(input, new LockOrdersForProcessHandler());
	}
	
	@GraymoundService("COS_WEEKLY_DETAIL_TRANSACTION_REPORT_SERVICE")
	public static GMMap weeklyDetailTransactionReport(GMMap input){
		Date currentDate = new Date();
		Date endDate = CommonHelper.addDay(currentDate, -1);
		Date startDate = CommonHelper.addDay(currentDate, -7);
		
		input.put("START_DATE", CommonHelper.getShortDateTimeString(startDate));
		input.put("END_DATE", CommonHelper.getShortDateTimeString(endDate));
		input.put("RECEIPIENT_LIST_KEY", "EMAIL_RECEIPT_LIST_4_COS_WEEKLY_REPORT");
		input.put("SUBJECT", String.format(CommonHelper.getValueOfParameter("CDM_EXTRA_PARAMETERS", "COS_WEEKLY_REPORT_SUBJECT"), 
				CommonHelper.getDateString(startDate, "dd/MM/yyyy"), CommonHelper.getDateString(endDate, "dd/MM/yyyy")));
		
		return getDetailTransactionReport(input);
	}
	
	private static GMMap getDetailTransactionReport(GMMap input){
		GMMap output = new GMMap();
		
		final String tableName = "RESULTS";
		
		try{
			GMMap reportResult = CommonHelper.callGraymoundServiceOutsideSession("COS_GET_DETAIL_TRANSACTION_REPORT", input);
			
			if(reportResult.getSize(tableName) == 0){
				CommonHelper.sendMail(Arrays.asList(input.getString("RECEIPIENT_LIST_KEY").split(",")), null, 
						"nakityonetimiisanaliziekibi@aktifbank.com.tr", false, input.getString("SUBJECT"),
						"Belirtilen tarihler aras� herhangi bir i�leme rastlanmam��t�r.");
			}
			
			StringBuilder emailBuilder = new StringBuilder();
			
			emailBuilder.append("<html><head></head><body>");
			
			emailBuilder.append("<table border=2>");
			
			emailBuilder.append("<tr>");
			
			emailBuilder.append("<td><b>Firma K�sa Ad�</b></td>");
			
			emailBuilder.append("<td><b>EFT Adet</b></td>");
			
			emailBuilder.append("<td><b>EFT Tutar</b></td>");
			
			emailBuilder.append("<td><b>Havale Adet</b></td>");
			
			emailBuilder.append("<td><b>Havale Tutar</b></td>");
			
			emailBuilder.append("<td><b>Virman Adet</b></td>");
			
			emailBuilder.append("<td><b>Virman Tutar</b></td>");
			
			emailBuilder.append("<td><b>PTT'ye G�nd. Adet</b></td>");
			
			emailBuilder.append("<td><b>PTT'ye G�nd. Tutar</b></td>");
			
			emailBuilder.append("<td><b>�deme Tipi Belirlenemeyen Tutar</b></td>");
			
			emailBuilder.append("<td><b>TRY Adet</b></td>");
			
			emailBuilder.append("<td><b>TRY Tutar</b></td>");
			
			emailBuilder.append("</tr>");
			
			int eftCount = 0;
			BigDecimal eftAmount = BigDecimal.ZERO;
			
			int transferCount = 0;
			BigDecimal transferAmount = BigDecimal.ZERO;
			
			int virmanCount = 0;
			BigDecimal virmanAmount = BigDecimal.ZERO;
			
			int pttTransferCount = 0;
			BigDecimal pttTransferAmount = BigDecimal.ZERO;
			
			BigDecimal unknownSourceTransferAmount = BigDecimal.ZERO;
			
			int tryCount = 0;
			BigDecimal tryAmount = BigDecimal.ZERO;
			
			for (int i = 0; i < reportResult.getSize(tableName); i++) {
				int corpEftCount = reportResult.getInt(tableName, i, "EFT_COUNT");
				int corpTransferCount = reportResult.getInt(tableName, i, "TRANSFER_COUNT");
				int corpVirmanCount = reportResult.getInt(tableName, i, "VIRMAN_COUNT");
				int corpPttTransferCount = reportResult.getInt(tableName, i, "PTT_TRANSFER_COUNT");
				int corpTryCount = reportResult.getInt(tableName, i, "TRY_COUNT");
				
				eftCount += corpEftCount;
				transferCount += corpTransferCount;
				virmanCount += corpVirmanCount;
				pttTransferCount += corpPttTransferCount;
				tryCount += corpTryCount;
				
				BigDecimal corpEftAmount = reportResult.getBigDecimal(tableName, i, "EFT_AMOUNT");
				BigDecimal corpTransferAmount = reportResult.getBigDecimal(tableName, i, "TRANSFER_AMOUNT");
				BigDecimal corpVirmanAmount = reportResult.getBigDecimal(tableName, i, "VIRMAN_AMOUNT");
				BigDecimal corpPttTransferAmount = reportResult.getBigDecimal(tableName, i, "PTT_TRANSFER_AMOUNT");
				BigDecimal corpUnknownSourceTransferAmount = reportResult.getBigDecimal(tableName, i, "UNK_SOURCE_AMOUNT");
				BigDecimal corpTryAmount = reportResult.getBigDecimal(tableName, i, "TRY_AMOUNT");
				
				eftAmount = eftAmount.add(corpEftAmount);
				transferAmount = transferAmount.add(corpTransferAmount);
				virmanAmount = virmanAmount.add(corpVirmanAmount);
				pttTransferAmount = pttTransferAmount.add(corpPttTransferAmount);
				unknownSourceTransferAmount = unknownSourceTransferAmount.add(corpUnknownSourceTransferAmount);
				tryAmount = tryAmount.add(corpTryAmount);
				
				emailBuilder.append("<tr>");
				
				emailBuilder.append(String.format("<td>%s</td>", reportResult.getString(tableName, i, "CORP_NAME")));
				emailBuilder.append(String.format("<td>%s</td>", corpEftCount));
				emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corpEftAmount.toPlainString())));
				emailBuilder.append(String.format("<td>%s</td>", corpTransferCount));
				emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corpTransferAmount.toPlainString())));
				emailBuilder.append(String.format("<td>%s</td>", corpVirmanCount));
				emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corpVirmanAmount.toPlainString())));
				emailBuilder.append(String.format("<td>%s</td>", corpPttTransferCount));
				emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corpPttTransferAmount.toPlainString())));
				emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corpUnknownSourceTransferAmount.toPlainString())));
				emailBuilder.append(String.format("<td>%s</td>", corpTryCount));
				emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(corpTryAmount.toPlainString())));
				
				emailBuilder.append("</tr>");
			}
			
			emailBuilder.append("<tr>");
			
			emailBuilder.append("<td>TOPLAM</td>");
			emailBuilder.append(String.format("<td>%s</td>", eftCount));
			emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(eftAmount.toPlainString())));
			emailBuilder.append(String.format("<td>%s</td>", transferCount));
			emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(transferAmount.toPlainString())));
			emailBuilder.append(String.format("<td>%s</td>", virmanCount));
			emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(virmanAmount.toPlainString())));
			emailBuilder.append(String.format("<td>%s</td>", pttTransferCount));
			emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(pttTransferAmount.toPlainString())));
			emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(unknownSourceTransferAmount.toPlainString())));
			emailBuilder.append(String.format("<td>%s</td>", tryCount));
			emailBuilder.append(String.format("<td>%s</td>", CommonHelper.applyDecimalFormatWithDefaultCurrency(tryAmount.toPlainString())));
			
			emailBuilder.append("</tr>");
			
			emailBuilder.append("</table>");
			
			emailBuilder.append("</body></html>");
			
			CommonHelper.sendMail(Arrays.asList(CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", input.getString("RECEIPIENT_LIST_KEY")).split(",")), null, 
					"nakityonetimiisanaliziekibi@aktifbank.com.tr", true, input.getString("SUBJECT"), emailBuilder.toString());
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}
}
