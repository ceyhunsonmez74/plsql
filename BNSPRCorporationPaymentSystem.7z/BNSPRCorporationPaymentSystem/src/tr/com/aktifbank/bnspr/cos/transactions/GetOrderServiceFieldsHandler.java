package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.ObjectMapper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.dao.OrderFileUtilServices;

import com.graymound.util.GMMap;

public final class GetOrderServiceFieldsHandler extends RequestHandler {

	public GetOrderServiceFieldsHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Criteria criteria = super.getHibernateSession().createCriteria(OrderFileUtilServices.class);
		if(!input.getBoolean(TransactionConstants.GetOrderServiceFields.Input.GET_ALL_FIELDS, false)){
			criteria = criteria.add(Restrictions.eq("status", true));
		}
		@SuppressWarnings("unchecked")
		List<OrderFileUtilServices> dbFieldList = criteria.list();
		List<ItemServiceField> fields = new ArrayList<ItemServiceField>();
		for(OrderFileUtilServices field : dbFieldList){
			ObjectMapper<ItemServiceField> mapper = new ObjectMapper<ItemServiceField>(ItemServiceField.class);
			ItemServiceField dtoField = mapper.map(field);
			fields.add(dtoField);
		}
		output.put(TransactionConstants.GetOrderDatabaseFields.Output.FIELDS, fields);
	}

}
