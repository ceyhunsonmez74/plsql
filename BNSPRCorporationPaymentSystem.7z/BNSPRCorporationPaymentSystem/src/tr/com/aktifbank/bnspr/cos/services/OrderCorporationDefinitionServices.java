package tr.com.aktifbank.bnspr.cos.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cos.transactions.GetOrderCorpDefHandler;
import tr.com.aktifbank.bnspr.cos.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.aktifbank.bnspr.dao.CorporateOrderParameters;
import tr.com.aktifbank.bnspr.dao.CorporateOrderParametersTx;
import tr.com.aktifbank.bnspr.dao.CorporationAccountDef;
import tr.com.aktifbank.bnspr.dao.CorporationAccountDefTx;
import tr.com.aktifbank.bnspr.dao.CorporationDef;
import tr.com.aktifbank.bnspr.dao.CorporationDefTx;
import tr.com.aktifbank.bnspr.dao.FtmFileDefinition;
import tr.com.aktifbank.bnspr.dao.OrderCorpContactinfo;
import tr.com.aktifbank.bnspr.dao.OrderCorpContactinfoTx;
import tr.com.aktifbank.bnspr.dao.RecipientDef;
import tr.com.aktifbank.bnspr.dao.RecipientDefTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class OrderCorporationDefinitionServices {
	
	static final Log logger = LogFactory.getLog(OrderCorporationDefinitionServices.class);
	
	@GraymoundService("COS_GET_ACCOUNT_TYPE_COMBO")
	public static GMMap getAccountTypesCombo(GMMap iMap) {
		
		return CorporationServiceUtil.getComboValues(iMap);
	}		
	
	@GraymoundService("COS_GET_ORDER_TYPE_COMBO")
	public static GMMap getTransferTypesCombo(GMMap iMap) {
		
		return CorporationServiceUtil.getComboValues(iMap);
	}
		
	@GraymoundService("COS_GET_ORDER_STATUS_COMBO")
	public static GMMap getTransferStatusCombo(GMMap iMap) {
		
		return CorporationServiceUtil.getComboValues(iMap);
	}			
	
	@GraymoundService("COS_GET_CORP_DEF")
	public static GMMap getCorpDef(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetOrderCorpDefHandler());
	}	
	
	@GraymoundService("COS_GET_CORP_DEF_TX")
	public static GMMap getCorpDefTx(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			CorporationDefTx corpDefTx = null;
			BigDecimal trxNo = input.getBigDecimal("TRX_NO");		
			corpDefTx = (CorporationDefTx) hibernateSession.createCriteria(CorporationDefTx.class)
										  .add(Restrictions.eq("status", true))
										  .add(Restrictions.eq("txNo", trxNo)).uniqueResult();	
			if (corpDefTx != null) {
				output.put(TransactionConstants.CorporationDef.CUSTOMER_NO, corpDefTx.getCustomerNo());
				output.put(TransactionConstants.CorporationDef.CUSTOMER_TITLE, corpDefTx.getCorporateName());
				output.put(TransactionConstants.CorporationDef.SHORT_NAME, corpDefTx.getShortName());
				output.put(TransactionConstants.CorporationDef.ACTIVENESS, corpDefTx.getActiveness());
				output.put(TransactionConstants.CorporationDef.CORPORATE_CODE, corpDefTx.getCorporateCode());
				output.put(TransactionConstants.CorporationDef.OID, corpDefTx.getOid());
			}			
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_CORPORATE_LIST")
	public static GMMap getCorporateList(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.CorporationDef.tableName;
			
			String corporateCode = input.getString(TransactionConstants.CorporationDef.CORPORATE_CODE);
			String shortName = input.getString(TransactionConstants.CorporationDef.SHORT_NAME);
			String customerNo = input.getString(TransactionConstants.CorporationDef.CUSTOMER_NO);
			String activeness = null;
			CorporateFileTransfer corporateFileTransfer = null;
			
			Criteria criteria = hibernateSession.createCriteria(CorporationDef.class)
											.add(Restrictions.eq("status", true))
											.addOrder(Order.asc("corporateCode"));
	
			if (StringUtils.isNotBlank(corporateCode))
				criteria = criteria.add(Restrictions.ilike("corporateCode", "%"+corporateCode+"%"));
			if (StringUtils.isNotBlank(shortName))
				criteria = criteria.add(Restrictions.ilike("shortName", "%"+shortName+"%"));
			if (StringUtils.isNotBlank(customerNo))
				criteria = criteria.add(Restrictions.eq("customerNo", new BigDecimal(customerNo)));
				
			List<CorporationDef> corps = criteria.list();					
			
			int count = 0;
			for (CorporationDef corp : corps) {		
				activeness = corp.getActiveness()? "Aktif" : "Pasif";
				output.put(tableName, count, TransactionConstants.CorporationDef.ACTIVENESS, activeness);				
				output.put(tableName, count, TransactionConstants.CorporationDef.CUSTOMER_NO, corp.getCustomerNo());								
				output.put(tableName, count, TransactionConstants.CorporationDef.CUSTOMER_TITLE, corp.getCorporateName());					
				output.put(tableName, count, TransactionConstants.CorporationDef.OID, corp.getOid());
				output.put(tableName, count, TransactionConstants.CorporationDef.CORPORATE_CODE, corp.getCorporateCode());						
				output.put(tableName, count, TransactionConstants.CorporationDef.SHORT_NAME, corp.getShortName());
				
				corporateFileTransfer = (CorporateFileTransfer) hibernateSession.createCriteria(CorporateFileTransfer.class)
																.add(Restrictions.eq("status", true))
																.add(Restrictions.eq("corporateCode", corp.getCorporateCode()))
																.add(Restrictions.eq("transferType", new Short(DatabaseConstants.TransferTypes.OrderLoading))).uniqueResult();			
				if (corporateFileTransfer != null)
					output.put(tableName, count, TransactionConstants.CorporationDef.FTM_FILE_DEF_OID, corporateFileTransfer.getFtmId());

				count++;
			}						
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}			
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_SAVE_CORP_DEF")
	public static GMMap saveCorpDef(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			String username = CommonHelper.getCurrentUser();
			String newCorporateCode = null, newOid = null, corpOid = null, smsOrderType = null;
			CorporationDef corpDef = null;
			CorporationDefTx corpDefTx = null, newCorpDefTx = null;			
			CorporationAccountDefTx newCorpAccDefTx = null; 
			String accountType = null; 
			StringBuilder smsOrderTypeBuilder = null;
			Boolean defaultAccount = null;
			boolean atLeastOneKHAccount = false, atLeastOneMHAccount = false;
			boolean defaultKHAccountExists = false, defaultMHAccountExists = false; 			
			CorporateOrderParametersTx corpParamTx = null, newCorpParamTx = null;			
			RecipientDefTx newRecDefTx = null;
			OrderCorpContactinfoTx newContactInfoTx = null;
			
			// SAVE CORPORATION DEFINITION
			BigDecimal customerNo = input.getBigDecimal(TransactionConstants.CorporationDef.CUSTOMER_NO);					
			String customerTitle = input.getString(TransactionConstants.CorporationDef.CUSTOMER_TITLE);
			String shortName = input.getString(TransactionConstants.CorporationDef.SHORT_NAME);
			Boolean activeness = input.getBoolean(TransactionConstants.CorporationDef.ACTIVENESS);
			String corporateCode = input.getString(TransactionConstants.CorporationDef.CORPORATE_CODE);
			String oid = input.getString(TransactionConstants.CorporationDef.OID);
			
			if (customerNo == null) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "M��teri No"));

			if (StringUtils.isBlank(shortName)) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Firma K�sa Ad�"));			
			
			if (StringUtils.isBlank(oid)) { 
				// SAVE CORPORATION FOR THE FIRST TIME
				newCorpDefTx = new CorporationDefTx();			
				newCorpDefTx.setStatus(true);
				newCorpDefTx.setActiveness(activeness);		
				newCorporateCode = "F-" + CorporationServiceUtil.getSequenceCode("ORDER_CORPORATE_DEF");
				newCorpDefTx.setCorporateCode(newCorporateCode);
				newCorpDefTx.setShortName(shortName);
				newCorpDefTx.setCustomerNo(customerNo);
				newCorpDefTx.setCorporateName(customerTitle);
				newCorpDefTx.setCreateUser(username);
				newCorpDefTx.setCreateDate(CommonHelper.getLongDateTimeString(new Date()));				
				hibernateSession.save(newCorpDefTx);
				
				newOid = newCorpDefTx.getOid();
				newCorpDefTx.setCorporateOid(newOid);
				hibernateSession.update(newCorpDefTx);	
				
				output.put(TransactionConstants.CorporationDef.OID, newOid);
				output.put(TransactionConstants.CorporationDef.CORPORATE_CODE, newCorporateCode);		
				corpOid = newOid;
			} else {				
				corpDefTx = (CorporationDefTx) hibernateSession.createCriteria(CorporationDefTx.class)
												.add(Restrictions.eq("corporateOid", oid))
												.add(Restrictions.eq("status", true)).uniqueResult();				
				if (corpDefTx != null) {
					corpDefTx.setStatus(false);
					hibernateSession.update(corpDefTx);			
				
					// SAVE CORPORATION DEFINITION IN TX
					newCorpDefTx = new CorporationDefTx();			
					newCorpDefTx.setStatus(true);
					newCorpDefTx.setActiveness(activeness);		
					newCorpDefTx.setCorporateCode(corpDefTx.getCorporateCode());
					newCorpDefTx.setShortName(shortName);
					newCorpDefTx.setCustomerNo(customerNo);
					newCorpDefTx.setCorporateName(customerTitle);
					newCorpDefTx.setCreateUser(username);
					newCorpDefTx.setCreateDate(CommonHelper.getLongDateTimeString(new Date()));		
					newCorpDefTx.setCorporateOid(oid);
					hibernateSession.save(newCorpDefTx);
					
					output.put(TransactionConstants.CorporationDef.OID, oid);
					output.put(TransactionConstants.CorporationDef.CORPORATE_CODE, corporateCode);	
					corpOid = oid;
				} 
				else { 
					// COPY EXISTING CORPORATE DEFINITION TO TX TABLE AND GET NEW CORPORATION OID
					corpDef = (CorporationDef) hibernateSession.createCriteria(CorporationDef.class)
												.add(Restrictions.eq("oid",oid))
												.add(Restrictions.eq("status",true)).uniqueResult();			
					newCorpDefTx = new CorporationDefTx();		
					newCorpDefTx.setStatus(true);
					newCorpDefTx.setActiveness(corpDef.getActiveness());		
					newCorpDefTx.setCorporateCode(corpDef.getCorporateCode());
					newCorpDefTx.setShortName(corpDef.getShortName());
					newCorpDefTx.setCustomerNo(corpDef.getCustomerNo());
					newCorpDefTx.setCorporateName(corpDef.getCorporateName());
					newCorpDefTx.setCreateUser(corpDef.getCreateUser());
					newCorpDefTx.setCreateDate(corpDef.getCreateDate());
					hibernateSession.save(newCorpDefTx);
					
					newOid = newCorpDefTx.getOid();
					newCorpDefTx.setCorporateOid(newOid);					
					newCorpDefTx.setActiveness(activeness);		
					newCorpDefTx.setShortName(shortName);
					newCorpDefTx.setCustomerNo(customerNo);
					newCorpDefTx.setCorporateName(customerTitle);				
					hibernateSession.update(newCorpDefTx);
					
					output.put(TransactionConstants.CorporationDef.OID, newOid);
					output.put(TransactionConstants.CorporationDef.CORPORATE_CODE, corporateCode);
					corpOid = newOid;
				}
			}
			
			//SAVE CORP ACCOUNTS
			String accountTableName = TransactionConstants.CorpAccount.tableName;
			
			//account no, customer no consistency control
			for (int count = 0; count < input.getSize(accountTableName); count++) {
				if (!input.getBoolean(accountTableName, count, "DK_ACCOUNT_SELECTED"))
					if (input.getBigDecimal(accountTableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO).compareTo(customerNo) != 0)
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.CUSTOMERNOACCOUNTNOMISMATCH));
			}
			
			for (int count = 0; count < input.getSize(accountTableName); count++) {
				if (atLeastOneKHAccount && atLeastOneMHAccount)
					break;
				accountType = input.getString(accountTableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE);
				if (accountType.equals(DatabaseConstants.OrderAccountType.UsageAccount))
					atLeastOneKHAccount = true;
				else if (accountType.equals(DatabaseConstants.OrderAccountType.CommissionAccount))
					atLeastOneMHAccount = true;
			}		
			//at least one usage account check
			if (!atLeastOneKHAccount)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ATLEASTONEKHACCOUNT));

			for (int count = 0; count < input.getSize(accountTableName); count++) {
				if (defaultKHAccountExists && defaultMHAccountExists)
					break;
				defaultAccount = input.getBoolean(accountTableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT);
				accountType = input.getString(accountTableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE);
				if (defaultAccount && accountType.equals(DatabaseConstants.OrderAccountType.UsageAccount))
					defaultKHAccountExists = true;
				else if (defaultAccount && accountType.equals(DatabaseConstants.OrderAccountType.CommissionAccount))
					defaultMHAccountExists = true;
			}
			// default selection check
			if (!defaultKHAccountExists)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NODEFAULTKHACCOUNT));			
			if (atLeastOneMHAccount && !defaultMHAccountExists)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NODEFAULTMHACCOUNT));					
						
			List<CorporationAccountDefTx> corpAccDefTxList = hibernateSession.createCriteria(CorporationAccountDefTx.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("corporateOid", corpOid)).list();		
			if (corpAccDefTxList.size() > 0)
				for (CorporationAccountDefTx corpAccDefTx : corpAccDefTxList) {
					corpAccDefTx.setStatus(false);
					hibernateSession.update(corpAccDefTx);
				}
			
			for (int count = 0; count < input.getSize(accountTableName); count++) {
				newCorpAccDefTx = new CorporationAccountDefTx();
				newCorpAccDefTx.setStatus(true);
				newCorpAccDefTx.setAccountType(input.getString(accountTableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE));
				if (input.getBoolean(accountTableName, count, "DK_ACCOUNT_SELECTED"))
					newCorpAccDefTx.setAccountNo(input.getBigDecimal(accountTableName, count, "DK_ACCOUNT_NO"));
				else
					newCorpAccDefTx.setAccountNo(input.getBigDecimal(accountTableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO));
				newCorpAccDefTx.setDefaultAccount(input.getBoolean(accountTableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT));
				newCorpAccDefTx.setAccountName(input.getString(accountTableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME));
				newCorpAccDefTx.setAccountProductType(input.getString(accountTableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE));
				newCorpAccDefTx.setAccountBranch(input.getString(accountTableName, count, TransactionConstants.CorpAccount.BRANCH_NAME));
				newCorpAccDefTx.setAccountCurrencyCode(input.getString(accountTableName, count, TransactionConstants.CorpAccount.CURRENCY));
				newCorpAccDefTx.setIsDkAccount(input.getBoolean(accountTableName, count, "DK_ACCOUNT_SELECTED"));
				newCorpAccDefTx.setCorporateOid(corpOid);
				hibernateSession.save(newCorpAccDefTx);						
			}		
			
			// SAVE CORPORATE PARAMETERS
			Boolean checkVkn = input.getBoolean(TransactionConstants.CorpParameter.CHECK_VKN);
			Boolean checkTckn = input.getBoolean(TransactionConstants.CorpParameter.CHECK_TCKN);
			Boolean checkNameConsistency = false;
			String amountOrder = input.getString(TransactionConstants.CorpParameter.AMOUNT_ORDER);
			Boolean checkRecipients = input.getBoolean(TransactionConstants.CorpParameter.CHECK_RECIPIENTS);
			Boolean smsToRecipient = input.getBoolean(TransactionConstants.CorpParameter.SMS_TO_RECIPIENT);
			Boolean smsForEft = input.getBoolean(TransactionConstants.CorpParameter.SMS_FOR_EFT);
			Boolean smsForHavale = input.getBoolean(TransactionConstants.CorpParameter.SMS_FOR_HAVALE);
			Boolean smsForVirman = input.getBoolean(TransactionConstants.CorpParameter.SMS_FOR_VIRMAN);
			Boolean smsForPttIsmeHavale = input.getBoolean(TransactionConstants.CorpParameter.SMS_FOR_PTT_ISME_HAVALE);
			Boolean emailToRecipient = input.getBoolean(TransactionConstants.CorpParameter.EMAIL_TO_RECIPIENT);
			Boolean emailLoadingStatus = input.getBoolean(TransactionConstants.CorpParameter.EMAIL_LOADING_STATUS);
			Boolean emailTransferStatus = input.getBoolean(TransactionConstants.CorpParameter.EMAIL_TRANSFER_STATUS);
			Boolean emailEodStatus = input.getBoolean(TransactionConstants.CorpParameter.EMAIL_EOD_STATUS);
			Boolean makeLoadingStatusFile = input.getBoolean(TransactionConstants.CorpParameter.MAKE_LOADING_STATUS_FILE);
			Boolean makeTransferStatusFile = input.getBoolean(TransactionConstants.CorpParameter.MAKE_TRANSFER_STATUS_FILE);
			String makeEodStatusFile = input.getString(TransactionConstants.CorpParameter.MAKE_EOD_STATUS_FILE);
			Boolean allowTransferToValid = input.getBoolean(TransactionConstants.CorpParameter.ALLOW_TRANSFER_TO_VALID);
			Boolean transferWithoutApproval = input.getBoolean(TransactionConstants.CorpParameter.TRANSFER_WITHOUT_APPROVAL);
			String loadingEmail = input.getString(TransactionConstants.CorpParameter.LOADING_EMAIL);
			String transferEmail = input.getString(TransactionConstants.CorpParameter.TRANSFER_EMAIL);
			String eodEmail = input.getString(TransactionConstants.CorpParameter.EOD_EMAIL);
			String eodStatusEmailTime = input.getString(TransactionConstants.CorpParameter.EOD_STATUS_EMAIL_TIME);
			Boolean emailReceiptToRecipient = input.getBoolean(TransactionConstants.CorpParameter.EMAIL_RECEIPT_TO_RECIPIENT);

			List<String> mailList = null;
			if (emailLoadingStatus) {
				if (StringUtils.isEmpty(loadingEmail))
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOEMAILADDRESSFOUND, "\"Dosya y�kleme bildirimi\""));
				
				mailList = Arrays.asList(loadingEmail.split("[,;]"));				
				for (String mail : mailList) {
					mail = mail.trim();
					if (!CommonHelper.isValidEmailAddress(mail))
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.INVALIDEMAILADDRESS, String.format(" \"%s\"", mail)));
				}
			}
			if (emailTransferStatus) {
				if (StringUtils.isEmpty(transferEmail))
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOEMAILADDRESSFOUND, "\"�deme bildirimi\""));
				
				mailList = Arrays.asList(transferEmail.split("[,;]"));				
				for (String mail : mailList) {
					mail = mail.trim();
					if (!CommonHelper.isValidEmailAddress(mail))
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.INVALIDEMAILADDRESS, String.format(" \"%s\"", mail)));
				}
			}
			if (emailEodStatus) {
				if (StringUtils.isEmpty(eodEmail))
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOEMAILADDRESSFOUND, "\"G�n sonu �deme toplu bildirimi\""));
				
				mailList = Arrays.asList(eodEmail.split("[,;]"));
				for (String mail : mailList) {
					mail = mail.trim();
					if (!CommonHelper.isValidEmailAddress(mail))
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.INVALIDEMAILADDRESS, String.format(" \"%s\"", mail)));
				}
			}
			if (StringUtils.isNotEmpty(eodStatusEmailTime)) {
				if (eodStatusEmailTime.length() != 4)
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.INVALIDTIMEFORMAT));
				else if ((new BigDecimal(eodStatusEmailTime.substring(0, 2)).compareTo(new BigDecimal(23)) > 0) || (new BigDecimal(eodStatusEmailTime.substring(2, 4)).compareTo(new BigDecimal(59)) > 0))
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.INVALIDTIMEFORMAT));
			}
			if (smsToRecipient) {
				smsOrderTypeBuilder = new StringBuilder();
				if (smsForEft)
					smsOrderTypeBuilder.append("1");
				else
					smsOrderTypeBuilder.append("0");
				if (smsForHavale)
					smsOrderTypeBuilder.append("1");
				else
					smsOrderTypeBuilder.append("0");
				if (smsForVirman)
					smsOrderTypeBuilder.append("1");
				else
					smsOrderTypeBuilder.append("0");
				if (smsForPttIsmeHavale)
					smsOrderTypeBuilder.append("1");
				else
					smsOrderTypeBuilder.append("0");
				smsOrderType = smsOrderTypeBuilder.toString();
			}
			
			corpParamTx = (CorporateOrderParametersTx) hibernateSession.createCriteria(CorporateOrderParametersTx.class)
														.add(Restrictions.eq("corporateOid",corpOid))
														.add(Restrictions.eq("status",true)).uniqueResult();			
			if (corpParamTx != null) {							
				corpParamTx.setStatus(false);		
				hibernateSession.update(corpParamTx);					
			}
			
			newCorpParamTx = new CorporateOrderParametersTx();								
			newCorpParamTx.setStatus(true);
			newCorpParamTx.setCorporateOid(corpOid);
			newCorpParamTx.setCheckVkn(checkVkn);
			newCorpParamTx.setCheckTckn(checkTckn);
			newCorpParamTx.setCheckNameConsistency(checkNameConsistency);			
			newCorpParamTx.setAmountOrder(amountOrder);			
			newCorpParamTx.setCheckRecipients(checkRecipients);
			newCorpParamTx.setSmsToRecipient(smsToRecipient);
			newCorpParamTx.setSmsOrderType(smsOrderType);
			newCorpParamTx.setEmailToRecipient(emailToRecipient);
			newCorpParamTx.setEmailLoadingStatus(emailLoadingStatus);
			newCorpParamTx.setEmailTransferStatus(emailTransferStatus);
			newCorpParamTx.setEmailEodStatus(emailEodStatus);			
			newCorpParamTx.setMakeLoadingStatusFile(makeLoadingStatusFile);
			newCorpParamTx.setMakeTransferStatusFile(makeTransferStatusFile);
			newCorpParamTx.setMakeEodStatusFile(makeEodStatusFile);
			newCorpParamTx.setAllowTransferToValid(allowTransferToValid);
			newCorpParamTx.setEmailReceiptToRecipient(emailReceiptToRecipient);
			newCorpParamTx.setTransferWithoutApproval(transferWithoutApproval);
			newCorpParamTx.setLoadingEmail(loadingEmail);
			newCorpParamTx.setTransferEmail(transferEmail);
			newCorpParamTx.setEodEmail(eodEmail);
			newCorpParamTx.setEodEmailTime(eodStatusEmailTime);			
			hibernateSession.save(newCorpParamTx);			
			
			// SAVE RECIPIENTS
			String recipientTableName = TransactionConstants.RecipientDef.tableName;
			
			if (checkRecipients && input.getSize(recipientTableName) == 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NORECIPIENTDEFINED));
								
			List<RecipientDefTx> recDefTxList = hibernateSession.createCriteria(RecipientDefTx.class)
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("corporateOid", corpOid)).list();		
			if (recDefTxList.size() > 0)
				for (RecipientDefTx recDefTx : recDefTxList) {
					recDefTx.setStatus(false);
					hibernateSession.update(recDefTx);
				}
			
			for (int count = 0; count < input.getSize(recipientTableName); count++) {					
				newRecDefTx = new RecipientDefTx();				
				newRecDefTx.setStatus(true);
				newRecDefTx.setRecipientAccountNo(input.getString(recipientTableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO));
				newRecDefTx.setRecipientIban(input.getString(recipientTableName, count, TransactionConstants.RecipientDef.IBAN));
				newRecDefTx.setRecipientName(input.getString(recipientTableName, count, TransactionConstants.RecipientDef.NAME_TITLE));
				newRecDefTx.setRecipientTckn(input.getString(recipientTableName, count, TransactionConstants.RecipientDef.TCKN));
				newRecDefTx.setRecipientBank(input.getString(recipientTableName, count, TransactionConstants.RecipientDef.BANK));
				newRecDefTx.setRecipientBranch(input.getString(recipientTableName, count, TransactionConstants.RecipientDef.BRANCH));
				newRecDefTx.setOrderType(input.getString(recipientTableName, count, TransactionConstants.RecipientDef.ORDER_TYPE));
				newRecDefTx.setCorporateOid(corpOid);		
				hibernateSession.save(newRecDefTx);
			}					
			
			// SAVE CORP CONTACT INFO
			String contactInfoTableName = TransactionConstants.CorpContactInfo.tableName;
			
			List<OrderCorpContactinfoTx> contactInfoTxList = hibernateSession.createCriteria(OrderCorpContactinfoTx.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("corporateOid", corpOid)).list();		
			if (contactInfoTxList.size() > 0)
				for (OrderCorpContactinfoTx contactInfoTx : contactInfoTxList) {
					contactInfoTx.setStatus(false);
					hibernateSession.update(contactInfoTx);
				}
			
			for (int count = 0; count < input.getSize(contactInfoTableName); count++) {
				newContactInfoTx = new OrderCorpContactinfoTx();				
				newContactInfoTx.setStatus(true);
				newContactInfoTx.setEmail(input.getString(contactInfoTableName, count, TransactionConstants.CorpContactInfo.EMAIL));
				newContactInfoTx.setFax(input.getString(contactInfoTableName, count, TransactionConstants.CorpContactInfo.FAX));
				newContactInfoTx.setMobile(input.getString(contactInfoTableName, count, TransactionConstants.CorpContactInfo.MOBILE));
				newContactInfoTx.setNameSurname(input.getString(contactInfoTableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME));
				newContactInfoTx.setPhoneNumber(input.getString(contactInfoTableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER));
				newContactInfoTx.setExtensionNumber(input.getString(contactInfoTableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER));
				newContactInfoTx.setCorporateOid(corpOid);		
				hibernateSession.save(newContactInfoTx);
			}			
			
			
			hibernateSession.flush();						
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_CORP_ACCOUNTS")
	public static GMMap getCorpAccounts(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.CorpAccount.tableName;
			String corpOid = input.getString(TransactionConstants.CorpAccount.CORP_OID);
			String accountTypeName = null, query = null;
			BigDecimal customerNo = null;
							
			List<CorporationAccountDef> corpAccDefList = hibernateSession.createCriteria(CorporationAccountDef.class)
														.add(Restrictions.eq("status", true))
														.add(Restrictions.eq("corporateOid", corpOid)).list();							
			int count = 0;
			for (CorporationAccountDef corpAccDef : corpAccDefList) {
				query = QueryRepository.OrderCorporationDefinitionServicesRepository.COS_ACCOUNT_TYPE_PARAM_TEXT_QUERY;			
				accountTypeName = DALUtil.getResult(String.format(query, corpAccDef.getAccountType()));				
				customerNo = getCustomerNoOfAccount(corpAccDef.getAccountNo());
				
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE, corpAccDef.getAccountType());	
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME, accountTypeName);		
				if (corpAccDef.getIsDkAccount() != null && corpAccDef.getIsDkAccount())
					output.put(tableName, count, "DK_ACCOUNT_NO", corpAccDef.getAccountNo());
				else
					output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO, corpAccDef.getAccountNo());		
				output.put(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT, corpAccDef.getDefaultAccount());			
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME, corpAccDef.getAccountName());									
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE, corpAccDef.getAccountProductType());					
				output.put(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME, corpAccDef.getAccountBranch());						
				output.put(tableName, count, TransactionConstants.CorpAccount.CURRENCY, corpAccDef.getAccountCurrencyCode());
				output.put(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO, customerNo);
				if (corpAccDef.getIsDkAccount() != null)
					output.put(tableName, count, "DK_ACCOUNT_SELECTED", corpAccDef.getIsDkAccount());
				else
					output.put(tableName, count, "DK_ACCOUNT_SELECTED", false);
				count++;
			}						
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}		
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_CORP_ACCOUNTS_TX")
	public static GMMap getCorpAccountsTx(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.CorpAccount.tableName;
			String corpOid = input.getString(TransactionConstants.CorpAccount.CORP_OID);
			String accountTypeName = null, query = null;
			BigDecimal customerNo = null;				
			
			List<CorporationAccountDefTx> corpAccDefTxList = hibernateSession.createCriteria(CorporationAccountDefTx.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("corporateOid", corpOid)).list();							
			int count = 0;
			for (CorporationAccountDefTx corpAccDefTx : corpAccDefTxList) {		
				query = QueryRepository.OrderCorporationDefinitionServicesRepository.COS_ACCOUNT_TYPE_PARAM_TEXT_QUERY;
				accountTypeName = DALUtil.getResult(String.format(query, corpAccDefTx.getAccountType()));
				customerNo = getCustomerNoOfAccount(corpAccDefTx.getAccountNo());
				
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE, corpAccDefTx.getAccountType());
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME, accountTypeName);
				if (corpAccDefTx.getIsDkAccount() != null && corpAccDefTx.getIsDkAccount())
					output.put(tableName, count, "DK_ACCOUNT_NO", corpAccDefTx.getAccountNo());
				else
					output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO, corpAccDefTx.getAccountNo());			
				output.put(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT, corpAccDefTx.getDefaultAccount());			
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME, corpAccDefTx.getAccountName());									
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE, corpAccDefTx.getAccountProductType());					
				output.put(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME, corpAccDefTx.getAccountBranch());						
				output.put(tableName, count, TransactionConstants.CorpAccount.CURRENCY, corpAccDefTx.getAccountCurrencyCode());
				output.put(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO, customerNo);
				if (corpAccDefTx.getIsDkAccount() != null)
					output.put(tableName, count, "DK_ACCOUNT_SELECTED", corpAccDefTx.getIsDkAccount());
				else
					output.put(tableName, count, "DK_ACCOUNT_SELECTED", false);
				count++;
			}						
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}		
	
	private static BigDecimal getCustomerNoOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.OrderCorporationDefinitionServicesRepository.MUSTERI_NO_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return new BigDecimal(result);
		else 
			return null;
	}
	
	@GraymoundService("COS_EDIT_CORP_ACCOUNTS")
	public static GMMap editCorpAccount(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.CorpAccount.tableName;
			int count;
			
			String accountType = input.getString(TransactionConstants.CorpAccount.ACCOUNT_TYPE);
			String accountTypeName = input.getString(TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME);
			BigDecimal accountNo = input.getBigDecimal(TransactionConstants.CorpAccount.ACCOUNT_NO);
			Boolean defaultAccount = input.getBoolean(TransactionConstants.CorpAccount.DEFAULT_ACCOUNT);
			String accountName = input.getString(TransactionConstants.CorpAccount.ACCOUNT_NAME);
			String accountCurrency = input.getString(TransactionConstants.CorpAccount.CURRENCY);
			String accountProductType = input.getString(TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE);
			String accountBranch = input.getString(TransactionConstants.CorpAccount.BRANCH_NAME);
			BigDecimal dkAccountNo = input.getBigDecimal("DK_ACCOUNT_NO");
			Boolean dkAccountSelected = input.getBoolean("DK_ACCOUNT_SELECTED");
			
			String action = input.getString("TAB_ACTION");
			int selectedRow = input.getInt("SELECTED_ROW");
			BigDecimal customerNo = null;
			
			if ("ADD".equals(action) || "UPDATE".equals(action)) {
				if (dkAccountSelected) {
					if (dkAccountNo == null) 
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "DK No"));				
				} else { 
					if (accountNo == null) 
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Hesap No"));
				}
				
				//CHECK THAT ONLY ONE KH OR MH ACCOUNT IS SET AS DEFAULT
				multipleDefaultAccountNoCheck(input, tableName, selectedRow);					
				//CHECK WHETHER USAGE ACCOUNT NO IS ALREADY USED IN DATAGRID
				uniqueAccountNoCheck(input, tableName, accountNo, dkAccountNo, dkAccountSelected, accountType);
				
				customerNo = getCustomerNoOfAccount(accountNo);
			}
						
			if ("ADD".equals(action)) {			
				for (count = 0; count < input.getSize(tableName); count++ ) {
					output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE));
					output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME));
					output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO));
					output.put(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT, input.getString(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT));
					output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME));
					output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE));
					output.put(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME));
					output.put(tableName, count, TransactionConstants.CorpAccount.CURRENCY, input.getString(tableName, count, TransactionConstants.CorpAccount.CURRENCY));
					output.put(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO, input.getString(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO));
					output.put(tableName, count, "DK_ACCOUNT_NO", input.getString(tableName, count, "DK_ACCOUNT_NO"));
					output.put(tableName, count, "DK_ACCOUNT_SELECTED", input.getString(tableName, count, "DK_ACCOUNT_SELECTED"));
				}
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE, accountType);
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME, accountTypeName);
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO, accountNo);
				output.put(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT, defaultAccount);
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME, accountName);
				output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE, accountProductType);
				output.put(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME, accountBranch);
				output.put(tableName, count, TransactionConstants.CorpAccount.CURRENCY, accountCurrency);
				output.put(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO, customerNo);
				output.put(tableName, count, "DK_ACCOUNT_NO", dkAccountNo);
				output.put(tableName, count, "DK_ACCOUNT_SELECTED", dkAccountSelected);
				
			} else if ("UPDATE".equals(action)) {				
				for (count = 0; count < input.getSize(tableName); count++ ) {
					if (count == selectedRow) {
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE, accountType);
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME, accountTypeName);
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO, accountNo);
						output.put(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT, defaultAccount);
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME, accountName);
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE, accountProductType);
						output.put(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME, accountBranch);
						output.put(tableName, count, TransactionConstants.CorpAccount.CURRENCY, accountCurrency);
						output.put(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO, customerNo);
						output.put(tableName, count, "DK_ACCOUNT_NO", dkAccountNo);
						output.put(tableName, count, "DK_ACCOUNT_SELECTED", dkAccountSelected);						
					} else {
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE));
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME));
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO));
						output.put(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT, input.getString(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT));
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME));
						output.put(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE));
						output.put(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME));
						output.put(tableName, count, TransactionConstants.CorpAccount.CURRENCY, input.getString(tableName, count, TransactionConstants.CorpAccount.CURRENCY));
						output.put(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO, input.getString(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO));
						output.put(tableName, count, "DK_ACCOUNT_NO", input.getString(tableName, count, "DK_ACCOUNT_NO"));
						output.put(tableName, count, "DK_ACCOUNT_SELECTED", input.getString(tableName, count, "DK_ACCOUNT_SELECTED"));						
					}
				}				
			} else if ("REMOVE".equals(action)) {
				int removeCount = 0;
				for (count = 0; count < input.getSize(tableName); count++ ) {
					if (count == selectedRow) {
						removeCount--;
					} else {
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.ACCOUNT_TYPE, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE));
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE_NAME));
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.ACCOUNT_NO, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO));
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT, input.getString(tableName, count, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT));
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.ACCOUNT_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NAME));
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE, input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_PRODUCT_TYPE));
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.BRANCH_NAME, input.getString(tableName, count, TransactionConstants.CorpAccount.BRANCH_NAME));
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.CURRENCY, input.getString(tableName, count, TransactionConstants.CorpAccount.CURRENCY));
						output.put(tableName, removeCount, TransactionConstants.CorpAccount.CUSTOMER_NO, input.getString(tableName, count, TransactionConstants.CorpAccount.CUSTOMER_NO));
						output.put(tableName, removeCount, "DK_ACCOUNT_NO", input.getString(tableName, count, "DK_ACCOUNT_NO"));
						output.put(tableName, removeCount, "DK_ACCOUNT_SELECTED", input.getString(tableName, count, "DK_ACCOUNT_SELECTED"));
					}
					removeCount++;
				}					
			}
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	}	
	
	private static void multipleDefaultAccountNoCheck(GMMap input, String tableName, int selectedRow) {
		boolean defaultKH = false, defaultMH = false;	
		String newAccountType = input.getString(TransactionConstants.CorpAccount.ACCOUNT_TYPE);
		Boolean defaultAccount = input.getBoolean(TransactionConstants.CorpAccount.DEFAULT_ACCOUNT);
		int defaultKHRow = -1, defaultMHRow = -1;
		
		if (defaultAccount) {			
			for (int i = 0; i < input.getSize(tableName); i++ ) {
				if (input.getBoolean(tableName, i, TransactionConstants.CorpAccount.DEFAULT_ACCOUNT))
					if (input.getString(tableName, i, TransactionConstants.CorpAccount.ACCOUNT_TYPE).equals(DatabaseConstants.OrderAccountType.UsageAccount)) {
						defaultKH = true;
						defaultKHRow = i;
					} else { 
						defaultMH = true;
						defaultMHRow = i;
					}
			}
			if (defaultKH && defaultKHRow != selectedRow && newAccountType.equals(DatabaseConstants.OrderAccountType.UsageAccount))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.DEFAULTKHACCOUNTEXISTS));	
			if (defaultMH && defaultMHRow != selectedRow && newAccountType.equals(DatabaseConstants.OrderAccountType.CommissionAccount))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.DEFAULTMHACCOUNTEXISTS));			
		}
	}	
	
	private static void uniqueAccountNoCheck(GMMap input, String tableName, BigDecimal accountNo, BigDecimal dkAccountNo, Boolean dkAccountSelected, String accountType) {
		String corporateCode = input.getString(TransactionConstants.CorpAccount.CORPORATE_CODE);
		int count;		
		// mevcut datagrid'te var m�?
		if ("ADD".equals(input.getString("TAB_ACTION")))
			for (count = 0; count < input.getSize(tableName); count++ ) {
				if (dkAccountSelected) {
					if (dkAccountNo.toString().equals(input.getString(tableName, count, "DK_ACCOUNT_NO")) &&
							accountType.equals(input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE)) )
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ACCOUNTNOALREADYUSED, corporateCode));
				} else {
					if (accountNo.toString().equals(input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_NO)) &&
							accountType.equals(input.getString(tableName, count, TransactionConstants.CorpAccount.ACCOUNT_TYPE)) )
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ACCOUNTNOALREADYUSED, corporateCode));
				}
			}
	}		
	
	@GraymoundService("COS_GET_CORP_PARAMETERS")
	public static GMMap getCorpParameters(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();				
			String corpOid = input.getString(TransactionConstants.CorpParameter.CORP_OID);
					
			CorporateOrderParameters corpParam = (CorporateOrderParameters) hibernateSession.createCriteria(CorporateOrderParameters.class)
																			.add(Restrictions.eq("status", true))
																			.add(Restrictions.eq("corporateOid", corpOid)).uniqueResult();
			if (corpParam != null) {
				output.put(TransactionConstants.CorpParameter.CHECK_VKN, corpParam.isCheckVkn());
				output.put(TransactionConstants.CorpParameter.CHECK_TCKN, corpParam.isCheckTckn());
				output.put(TransactionConstants.CorpParameter.CHECK_NAME_CONSISTENCY, corpParam.isCheckNameConsistency());
				Boolean transferWithoutApproval = corpParam.getTransferWithoutApproval();
				if(transferWithoutApproval == null)
					transferWithoutApproval = false;
				
				String amountOrder = corpParam.getAmountOrder();
				if (StringUtils.isNotBlank(amountOrder)) {
					output.put(TransactionConstants.CorpParameter.ORDER_BY_AMOUNT, true);				
					if ("A".equals(amountOrder)) {
						output.put(TransactionConstants.CorpParameter.DESC_ORDER, false);
						output.put(TransactionConstants.CorpParameter.ASC_ORDER, true);					
					} else if ("D".equals(amountOrder)) {
						output.put(TransactionConstants.CorpParameter.DESC_ORDER, true);
						output.put(TransactionConstants.CorpParameter.ASC_ORDER, false);					
					}					
				} else {
					output.put(TransactionConstants.CorpParameter.ORDER_BY_AMOUNT, false);
					output.put(TransactionConstants.CorpParameter.DESC_ORDER, false);
					output.put(TransactionConstants.CorpParameter.ASC_ORDER, false);					
				}
				
				String makeEodStatusFile = corpParam.getMakeEodStatusFile();
				if (StringUtils.isNotBlank(makeEodStatusFile)) {
					output.put(TransactionConstants.CorpParameter.MAKE_EOD_STATUS_FILE, true);				
					if ("S".equals(makeEodStatusFile)) {
						output.put(TransactionConstants.CorpParameter.CUMULATIVE_EOD_STATUS_FILE, false);
						output.put(TransactionConstants.CorpParameter.SEPARATE_EOD_STATUS_FILE, true);					
					} else if ("C".equals(makeEodStatusFile)) {
						output.put(TransactionConstants.CorpParameter.CUMULATIVE_EOD_STATUS_FILE, true);
						output.put(TransactionConstants.CorpParameter.SEPARATE_EOD_STATUS_FILE, false);					
					}					
				} else {
					output.put(TransactionConstants.CorpParameter.MAKE_EOD_STATUS_FILE, false);
					output.put(TransactionConstants.CorpParameter.CUMULATIVE_EOD_STATUS_FILE, false);
					output.put(TransactionConstants.CorpParameter.SEPARATE_EOD_STATUS_FILE, false);					
				}
				
				if (StringUtils.isNotEmpty(corpParam.getSmsOrderType())) {
					output.put(TransactionConstants.CorpParameter.SMS_FOR_EFT, corpParam.getSmsOrderType().substring(0,1) );
					output.put(TransactionConstants.CorpParameter.SMS_FOR_HAVALE, corpParam.getSmsOrderType().substring(1,2) );
					output.put(TransactionConstants.CorpParameter.SMS_FOR_VIRMAN, corpParam.getSmsOrderType().substring(2,3) );
					output.put(TransactionConstants.CorpParameter.SMS_FOR_PTT_ISME_HAVALE, corpParam.getSmsOrderType().substring(3,4) );
				} else {
					output.put(TransactionConstants.CorpParameter.SMS_FOR_EFT, false);
					output.put(TransactionConstants.CorpParameter.SMS_FOR_HAVALE, false);
					output.put(TransactionConstants.CorpParameter.SMS_FOR_VIRMAN, false);
					output.put(TransactionConstants.CorpParameter.SMS_FOR_PTT_ISME_HAVALE, false);					
				}
				
				output.put(TransactionConstants.CorpParameter.CHECK_RECIPIENTS, corpParam.isCheckRecipients());
				output.put(TransactionConstants.CorpParameter.SMS_TO_RECIPIENT, corpParam.isSmsToRecipient());
				output.put(TransactionConstants.CorpParameter.EMAIL_TO_RECIPIENT, corpParam.isEmailToRecipient());
				output.put(TransactionConstants.CorpParameter.EMAIL_LOADING_STATUS, corpParam.isEmailLoadingStatus());
				output.put(TransactionConstants.CorpParameter.EMAIL_TRANSFER_STATUS, corpParam.isEmailTransferStatus());
				output.put(TransactionConstants.CorpParameter.EMAIL_EOD_STATUS, corpParam.isEmailEodStatus());
				output.put(TransactionConstants.CorpParameter.MAKE_LOADING_STATUS_FILE, corpParam.isMakeLoadingStatusFile());
				output.put(TransactionConstants.CorpParameter.MAKE_TRANSFER_STATUS_FILE, corpParam.isMakeTransferStatusFile());
				output.put(TransactionConstants.CorpParameter.ALLOW_TRANSFER_TO_VALID, corpParam.isAllowTransferToValid());
				output.put(TransactionConstants.CorpParameter.EMAIL_RECEIPT_TO_RECIPIENT, corpParam.getEmailReceiptToRecipient());
				output.put(TransactionConstants.CorpParameter.TRANSFER_WITHOUT_APPROVAL, transferWithoutApproval);
				output.put(TransactionConstants.CorpParameter.LOADING_EMAIL, corpParam.getLoadingEmail());
				output.put(TransactionConstants.CorpParameter.TRANSFER_EMAIL, corpParam.getTransferEmail());
				output.put(TransactionConstants.CorpParameter.EOD_EMAIL, corpParam.getEodEmail());
				output.put(TransactionConstants.CorpParameter.EOD_STATUS_EMAIL_TIME, corpParam.getEodEmailTime());
			} else {
				output.put(TransactionConstants.CorpParameter.CHECK_VKN, false);
				output.put(TransactionConstants.CorpParameter.CHECK_TCKN, false);
				output.put(TransactionConstants.CorpParameter.CHECK_NAME_CONSISTENCY, false);
				output.put(TransactionConstants.CorpParameter.ORDER_BY_AMOUNT, false);								
				output.put(TransactionConstants.CorpParameter.DESC_ORDER, false);
				output.put(TransactionConstants.CorpParameter.ASC_ORDER, false);						
				output.put(TransactionConstants.CorpParameter.CHECK_RECIPIENTS, false);
				output.put(TransactionConstants.CorpParameter.SMS_TO_RECIPIENT, false);
				output.put(TransactionConstants.CorpParameter.SMS_FOR_EFT, false);
				output.put(TransactionConstants.CorpParameter.SMS_FOR_HAVALE, false);
				output.put(TransactionConstants.CorpParameter.SMS_FOR_VIRMAN, false);
				output.put(TransactionConstants.CorpParameter.SMS_FOR_PTT_ISME_HAVALE, false);
				output.put(TransactionConstants.CorpParameter.EMAIL_TO_RECIPIENT, false);
				output.put(TransactionConstants.CorpParameter.EMAIL_LOADING_STATUS, false);
				output.put(TransactionConstants.CorpParameter.EMAIL_TRANSFER_STATUS, false);
				output.put(TransactionConstants.CorpParameter.EMAIL_EOD_STATUS, false);
				output.put(TransactionConstants.CorpParameter.MAKE_LOADING_STATUS_FILE, false);
				output.put(TransactionConstants.CorpParameter.MAKE_TRANSFER_STATUS_FILE, false);
				output.put(TransactionConstants.CorpParameter.MAKE_EOD_STATUS_FILE, false);
				output.put(TransactionConstants.CorpParameter.CUMULATIVE_EOD_STATUS_FILE, false);
				output.put(TransactionConstants.CorpParameter.SEPARATE_EOD_STATUS_FILE, false);			
				output.put(TransactionConstants.CorpParameter.ALLOW_TRANSFER_TO_VALID, false);
				output.put(TransactionConstants.CorpParameter.TRANSFER_WITHOUT_APPROVAL, false);
				output.put(TransactionConstants.CorpParameter.LOADING_EMAIL, "");
				output.put(TransactionConstants.CorpParameter.TRANSFER_EMAIL, "");
				output.put(TransactionConstants.CorpParameter.EOD_EMAIL, "");
				output.put(TransactionConstants.CorpParameter.EOD_STATUS_EMAIL_TIME, "");	
			}
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}					
	
	@GraymoundService("COS_GET_CORP_PARAMETERS_TX")
	public static GMMap getCorpParametersTx(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();				
			String corpOid = input.getString(TransactionConstants.CorpParameter.CORP_OID);
					
			CorporateOrderParametersTx corpParamTx = (CorporateOrderParametersTx) hibernateSession.createCriteria(CorporateOrderParametersTx.class)
																				.add(Restrictions.eq("status", true))
																				.add(Restrictions.eq("corporateOid", corpOid)).uniqueResult();
			if (corpParamTx != null) {
				output.put(TransactionConstants.CorpParameter.CHECK_VKN, corpParamTx.isCheckVkn());
				output.put(TransactionConstants.CorpParameter.CHECK_TCKN, corpParamTx.isCheckTckn());
				output.put(TransactionConstants.CorpParameter.CHECK_NAME_CONSISTENCY, corpParamTx.isCheckNameConsistency());
				
				String amountOrder = corpParamTx.getAmountOrder();
				if (StringUtils.isNotBlank(amountOrder)) {
					output.put(TransactionConstants.CorpParameter.ORDER_BY_AMOUNT, true);				
					if ("A".equals(amountOrder)) {
						output.put(TransactionConstants.CorpParameter.DESC_ORDER, false);
						output.put(TransactionConstants.CorpParameter.ASC_ORDER, true);					
					} else if ("D".equals(amountOrder)) {
						output.put(TransactionConstants.CorpParameter.DESC_ORDER, true);
						output.put(TransactionConstants.CorpParameter.ASC_ORDER, false);					
					}					
				} else {
					output.put(TransactionConstants.CorpParameter.ORDER_BY_AMOUNT, false);
					output.put(TransactionConstants.CorpParameter.DESC_ORDER, false);
					output.put(TransactionConstants.CorpParameter.ASC_ORDER, false);					
				}
				
				String makeEodStatusFile = corpParamTx.getMakeEodStatusFile();
				if (StringUtils.isNotBlank(makeEodStatusFile)) {
					output.put(TransactionConstants.CorpParameter.MAKE_EOD_STATUS_FILE, true);				
					if ("S".equals(makeEodStatusFile)) {
						output.put(TransactionConstants.CorpParameter.CUMULATIVE_EOD_STATUS_FILE, false);
						output.put(TransactionConstants.CorpParameter.SEPARATE_EOD_STATUS_FILE, true);					
					} else if ("C".equals(makeEodStatusFile)) {
						output.put(TransactionConstants.CorpParameter.CUMULATIVE_EOD_STATUS_FILE, true);
						output.put(TransactionConstants.CorpParameter.SEPARATE_EOD_STATUS_FILE, false);					
					}					
				} else {
					output.put(TransactionConstants.CorpParameter.MAKE_EOD_STATUS_FILE, false);
					output.put(TransactionConstants.CorpParameter.CUMULATIVE_EOD_STATUS_FILE, false);
					output.put(TransactionConstants.CorpParameter.SEPARATE_EOD_STATUS_FILE, false);					
				}
				
				if (StringUtils.isNotEmpty(corpParamTx.getSmsOrderType())) {
					output.put(TransactionConstants.CorpParameter.SMS_FOR_EFT, corpParamTx.getSmsOrderType().substring(0,1) );
					output.put(TransactionConstants.CorpParameter.SMS_FOR_HAVALE, corpParamTx.getSmsOrderType().substring(1,2) );
					output.put(TransactionConstants.CorpParameter.SMS_FOR_VIRMAN, corpParamTx.getSmsOrderType().substring(2,3) );
					output.put(TransactionConstants.CorpParameter.SMS_FOR_PTT_ISME_HAVALE, corpParamTx.getSmsOrderType().substring(3,4) );
				} else {
					output.put(TransactionConstants.CorpParameter.SMS_FOR_EFT, false);
					output.put(TransactionConstants.CorpParameter.SMS_FOR_HAVALE, false);
					output.put(TransactionConstants.CorpParameter.SMS_FOR_VIRMAN, false);
					output.put(TransactionConstants.CorpParameter.SMS_FOR_PTT_ISME_HAVALE, false);					
				}
				
				output.put(TransactionConstants.CorpParameter.CHECK_RECIPIENTS, corpParamTx.isCheckRecipients());
				output.put(TransactionConstants.CorpParameter.SMS_TO_RECIPIENT, corpParamTx.isSmsToRecipient());
				output.put(TransactionConstants.CorpParameter.EMAIL_TO_RECIPIENT, corpParamTx.isEmailToRecipient());
				output.put(TransactionConstants.CorpParameter.EMAIL_LOADING_STATUS, corpParamTx.isEmailLoadingStatus());
				output.put(TransactionConstants.CorpParameter.EMAIL_TRANSFER_STATUS, corpParamTx.isEmailTransferStatus());
				output.put(TransactionConstants.CorpParameter.EMAIL_EOD_STATUS, corpParamTx.isEmailEodStatus());
				output.put(TransactionConstants.CorpParameter.MAKE_LOADING_STATUS_FILE, corpParamTx.isMakeLoadingStatusFile());
				output.put(TransactionConstants.CorpParameter.MAKE_TRANSFER_STATUS_FILE, corpParamTx.isMakeTransferStatusFile());
				output.put(TransactionConstants.CorpParameter.ALLOW_TRANSFER_TO_VALID, corpParamTx.isAllowTransferToValid());
				output.put(TransactionConstants.CorpParameter.EMAIL_RECEIPT_TO_RECIPIENT, corpParamTx.getEmailReceiptToRecipient());
				output.put(TransactionConstants.CorpParameter.TRANSFER_WITHOUT_APPROVAL, corpParamTx.getTransferWithoutApproval());
				output.put(TransactionConstants.CorpParameter.LOADING_EMAIL, corpParamTx.getLoadingEmail());
				output.put(TransactionConstants.CorpParameter.TRANSFER_EMAIL, corpParamTx.getTransferEmail());
				output.put(TransactionConstants.CorpParameter.EOD_EMAIL, corpParamTx.getEodEmail());
				output.put(TransactionConstants.CorpParameter.EOD_STATUS_EMAIL_TIME, corpParamTx.getEodEmailTime());
			} else {
				output.put(TransactionConstants.CorpParameter.CHECK_VKN, false);
				output.put(TransactionConstants.CorpParameter.CHECK_TCKN, false);
				output.put(TransactionConstants.CorpParameter.CHECK_NAME_CONSISTENCY, false);
				output.put(TransactionConstants.CorpParameter.ORDER_BY_AMOUNT, false);								
				output.put(TransactionConstants.CorpParameter.DESC_ORDER, false);
				output.put(TransactionConstants.CorpParameter.ASC_ORDER, false);						
				output.put(TransactionConstants.CorpParameter.CHECK_RECIPIENTS, false);
				output.put(TransactionConstants.CorpParameter.SMS_TO_RECIPIENT, false);
				output.put(TransactionConstants.CorpParameter.SMS_FOR_EFT, false);
				output.put(TransactionConstants.CorpParameter.SMS_FOR_HAVALE, false);
				output.put(TransactionConstants.CorpParameter.SMS_FOR_VIRMAN, false);
				output.put(TransactionConstants.CorpParameter.SMS_FOR_PTT_ISME_HAVALE, false);
				output.put(TransactionConstants.CorpParameter.EMAIL_TO_RECIPIENT, false);
				output.put(TransactionConstants.CorpParameter.EMAIL_LOADING_STATUS, false);
				output.put(TransactionConstants.CorpParameter.EMAIL_TRANSFER_STATUS, false);
				output.put(TransactionConstants.CorpParameter.EMAIL_EOD_STATUS, false);
				output.put(TransactionConstants.CorpParameter.MAKE_LOADING_STATUS_FILE, false);
				output.put(TransactionConstants.CorpParameter.MAKE_TRANSFER_STATUS_FILE, false);
				output.put(TransactionConstants.CorpParameter.MAKE_EOD_STATUS_FILE, false);
				output.put(TransactionConstants.CorpParameter.CUMULATIVE_EOD_STATUS_FILE, false);
				output.put(TransactionConstants.CorpParameter.SEPARATE_EOD_STATUS_FILE, false);						
				output.put(TransactionConstants.CorpParameter.ALLOW_TRANSFER_TO_VALID, false);
				output.put(TransactionConstants.CorpParameter.TRANSFER_WITHOUT_APPROVAL, false);
				output.put(TransactionConstants.CorpParameter.LOADING_EMAIL, "");
				output.put(TransactionConstants.CorpParameter.TRANSFER_EMAIL, "");
				output.put(TransactionConstants.CorpParameter.EOD_EMAIL, "");
				output.put(TransactionConstants.CorpParameter.EOD_STATUS_EMAIL_TIME, "");	
			}
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}		
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_RECIPIENTS")
	public static GMMap getRecipients(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.RecipientDef.tableName;
			String corpOid = input.getString(TransactionConstants.RecipientDef.CORP_OID);
			String query = null, orderTypeName = null;
			
			List<RecipientDef> recDefList = hibernateSession.createCriteria(RecipientDef.class)
											.add(Restrictions.eq("status", true))
											.add(Restrictions.eq("corporateOid", corpOid)).list();							
			int count = 0;
			for (RecipientDef recDef : recDefList) {		
				query = QueryRepository.OrderCorporationDefinitionServicesRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
				orderTypeName = DALUtil.getResult(String.format(query, recDef.getOrderType()));
				
				output.put(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO, recDef.getRecipientAccountNo());				
				output.put(tableName, count, TransactionConstants.RecipientDef.IBAN, recDef.getRecipientIban());								
				output.put(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE, recDef.getRecipientName());					
				output.put(tableName, count, TransactionConstants.RecipientDef.TCKN, recDef.getRecipientTckn());
				output.put(tableName, count, TransactionConstants.RecipientDef.BANK, recDef.getRecipientBank());
				output.put(tableName, count, TransactionConstants.RecipientDef.BRANCH, recDef.getRecipientBranch());		
				output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE, recDef.getOrderType());		
				output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, orderTypeName);	
				count++;
			}	
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_RECIPIENTS_BY_CUSTOMER_NO")
	public static GMMap getRecipientsByCustomerNo(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.RecipientDef.tableName;
			BigDecimal customerNo = input.getBigDecimal(TransactionConstants.CorporationDef.CUSTOMER_NO);
			String orderType = input.getString(TransactionConstants.RecipientDef.ORDER_TYPE);
			String query = null, orderTypeName = null, corpOid = null;
			Criteria recDefListCriteria = null;
			
			List<CorporationDef> corpList = hibernateSession.createCriteria(CorporationDef.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("customerNo", customerNo)).list();								
			if(corpList.size() > 0) {
				corpOid = corpList.get(0).getOid();
			
				recDefListCriteria = hibernateSession.createCriteria(RecipientDef.class)
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("corporateOid", corpOid));
				if (StringUtils.isNotEmpty(orderType))
					recDefListCriteria = recDefListCriteria.add(Restrictions.eq("orderType", orderType));
				
				List<RecipientDef> recDefList = recDefListCriteria.list();							
				int count = 0;
				for (RecipientDef recDef : recDefList) {							
					query = QueryRepository.OrderCorporationDefinitionServicesRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
					orderTypeName = DALUtil.getResult(String.format(query, recDef.getOrderType()));
					
					output.put(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO, recDef.getRecipientAccountNo());				
					output.put(tableName, count, TransactionConstants.RecipientDef.IBAN, recDef.getRecipientIban());								
					output.put(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE, recDef.getRecipientName());					
					output.put(tableName, count, TransactionConstants.RecipientDef.TCKN, recDef.getRecipientTckn());
					output.put(tableName, count, TransactionConstants.RecipientDef.BANK, recDef.getRecipientBank());
					output.put(tableName, count, TransactionConstants.RecipientDef.BRANCH, recDef.getRecipientBranch());		
					output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE, recDef.getOrderType());		
					output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, orderTypeName);	
					count++;
				}	
			}
			
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_RECIPIENTS_TX")
	public static GMMap getRecipientsTx(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.RecipientDef.tableName;
			String corpOid = input.getString(TransactionConstants.RecipientDef.CORP_OID);
			String query = null, orderTypeName = null;
			
			List<RecipientDefTx> recDefTxList = hibernateSession.createCriteria(RecipientDefTx.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("corporateOid", corpOid)).list();							
			int count = 0;
			for (RecipientDefTx recDefTx : recDefTxList) {	
				query = QueryRepository.OrderCorporationDefinitionServicesRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
				orderTypeName = DALUtil.getResult(String.format(query, recDefTx.getOrderType()));
				
				output.put(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO, recDefTx.getRecipientAccountNo());				
				output.put(tableName, count, TransactionConstants.RecipientDef.IBAN, recDefTx.getRecipientIban());								
				output.put(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE, recDefTx.getRecipientName());					
				output.put(tableName, count, TransactionConstants.RecipientDef.tableName, recDefTx.getRecipientTckn());
				output.put(tableName, count, TransactionConstants.RecipientDef.BANK, recDefTx.getRecipientBank());
				output.put(tableName, count, TransactionConstants.RecipientDef.BRANCH, recDefTx.getRecipientBranch());			
				output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE, recDefTx.getOrderType());	
				output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, orderTypeName);	
				count++;
			}	
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@GraymoundService("COS_EDIT_RECIPIENTS")
	public static GMMap editRecipients(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = TransactionConstants.RecipientDef.tableName;
			int count;
			
			String accountNo = input.getString(TransactionConstants.RecipientDef.ACCOUNT_NO);
			String iban = input.getString(TransactionConstants.RecipientDef.IBAN);
			String customerNameTitle = input.getString(TransactionConstants.RecipientDef.NAME_TITLE);
			String tckn = input.getString(TransactionConstants.RecipientDef.TCKN);
			String bank = input.getString(TransactionConstants.RecipientDef.BANK);
			String branch = input.getString(TransactionConstants.RecipientDef.BRANCH);
			String orderType = input.getString(TransactionConstants.RecipientDef.ORDER_TYPE);
			String orderTypeText = input.getString(TransactionConstants.RecipientDef.ORDER_TYPE_TEXT);
			String action = input.getString("TAB_ACTION");
			int selectedRow = input.getInt("SELECTED_ROW");
			BigDecimal recipientAccountNoFromIban = null;
			boolean repeatedIban = false, repeatedTckn = false;
			
			if ("ADD".equals(action) || "UPDATE".equals(action)) {
				if (StringUtils.isEmpty(customerNameTitle)) {
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.RECIPIENTDEFNAMEISMUSTFIELD));
				}
							
				for (int i = 0; i < input.getSize(tableName); i++ ) {		
					if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {
						if (!StringUtils.isEmpty(tckn) && tckn.equals(input.getString(tableName, i, TransactionConstants.RecipientDef.TCKN)) ) {
							repeatedTckn = true;
						}
					} else {
						if (!StringUtils.isEmpty(iban) && iban.equals(input.getString(tableName, i, TransactionConstants.RecipientDef.IBAN)) ) {
							repeatedIban = true;
						}						
					}
				}
				
				if (repeatedIban || repeatedTckn) {
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.REPEATEDRECIPIENTDEF));
				}
								
				if (orderType.equals(DatabaseConstants.OrderType.EFT) || orderType.equals(DatabaseConstants.OrderType.Havale) || orderType.equals(DatabaseConstants.OrderType.Virman)) {
					if (!StringUtils.isEmpty(iban)) {
						String dummy = null;
						Object[] inputValues = new Object[] {BnsprType.STRING, iban};
						Object[] outputValues = new Object[] {BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY"};
						try {
							GMMap procedureOutputMap = (GMMap) DALUtil.callOracleProcedure("{call BNSPR.PKG_EFT.EFT_IBAN_BANKA_SUBE_SEHIR_AL(?,?,?,?,?,?,?)}", inputValues, outputValues);	
							dummy = (String) procedureOutputMap.get("DUMMY");
						} catch (Exception e) {
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.INVALIDIBAN));
						}
					}				
				}								

				if (orderType.equals(DatabaseConstants.OrderType.EFT)) {
					if (StringUtils.isEmpty(iban) && ( StringUtils.isEmpty(accountNo) || StringUtils.isEmpty(branch) || StringUtils.isEmpty(bank) ) )
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.RECIPIENTDEFEFTMUSTFIELDS));
				}
				else if (orderType.equals(DatabaseConstants.OrderType.Havale)) {
					if (StringUtils.isEmpty(iban) && ( StringUtils.isEmpty(accountNo) ) )
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.RECIPIENTDEFHAVALEMUSTFIELDS));
				}
				else if (orderType.equals(DatabaseConstants.OrderType.Virman)) {
					if (StringUtils.isEmpty(iban) && ( StringUtils.isEmpty(accountNo) ) )					
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.RECIPIENTDEFVIRMANMUSTFIELDS));
				}
				else if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {
					if (StringUtils.isEmpty(customerNameTitle) || StringUtils.isEmpty(tckn) )
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.RECIPIENTDEFPTTHAVALEMUSTFIELDS));
				}
				
				if (orderType.equals(DatabaseConstants.OrderType.EFT)) {
					if (!StringUtils.isEmpty(bank) && !StringUtils.isEmpty(branch)) {
						if (!isValidBranch(bank, branch))
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.BANKBRANCHNOTDEFINED));
					}
				}
				
				if (orderType.equals(DatabaseConstants.OrderType.Havale) || orderType.equals(DatabaseConstants.OrderType.Virman)) {
					if (!StringUtils.isEmpty(iban)) {
						recipientAccountNoFromIban = getAccountNoFromIban(iban);
						if (recipientAccountNoFromIban == null)
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOSUCHIBANFOUND, iban));
						else {
							if (!StringUtils.isEmpty(accountNo)) {
								if (recipientAccountNoFromIban.compareTo(new BigDecimal(accountNo)) != 0 )
									CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.IBANACCOUNTNOMISMATCH));
							}
						}
					}					
					
					if (!StringUtils.isEmpty(branch) && !StringUtils.isEmpty(accountNo)) {
						if (!isValidAccountNo(branch, new BigDecimal(accountNo)))
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.BRACHACCOUNTNONOTDEFINED));
					} else if (!StringUtils.isEmpty(accountNo)) {
						if (!isValidAccountNo(new BigDecimal(accountNo)))
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.BRACHACCOUNTNONOTDEFINED));
					}		
				}
			}
		
			if ("ADD".equals(action)) {
				for (count = 0; count < input.getSize(tableName); count++ ) {
					output.put(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO, input.getString(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO));
					output.put(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE, input.getString(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE));
					output.put(tableName, count, TransactionConstants.RecipientDef.IBAN, input.getString(tableName, count, TransactionConstants.RecipientDef.IBAN));
					output.put(tableName, count, TransactionConstants.RecipientDef.TCKN, input.getString(tableName, count, TransactionConstants.RecipientDef.TCKN));
					output.put(tableName, count, TransactionConstants.RecipientDef.BANK, input.getString(tableName, count, TransactionConstants.RecipientDef.BANK));
					output.put(tableName, count, TransactionConstants.RecipientDef.BRANCH, input.getString(tableName, count, TransactionConstants.RecipientDef.BRANCH));
					output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE, input.getString(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE));
					output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, input.getString(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT));
				}
				output.put(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO, accountNo);
				output.put(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE, customerNameTitle);
				output.put(tableName, count, TransactionConstants.RecipientDef.IBAN, iban);
				output.put(tableName, count, TransactionConstants.RecipientDef.TCKN, tckn);
				output.put(tableName, count, TransactionConstants.RecipientDef.BANK, bank);
				output.put(tableName, count, TransactionConstants.RecipientDef.BRANCH, branch);
				output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE, orderType);
				output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, orderTypeText);
				
			} else if ("UPDATE".equals(action)) {
				for (count = 0; count < input.getSize(tableName); count++ ) {
					if (count == selectedRow) {
						output.put(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO, accountNo);
						output.put(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE, customerNameTitle);
						output.put(tableName, count, TransactionConstants.RecipientDef.IBAN, iban);
						output.put(tableName, count, TransactionConstants.RecipientDef.TCKN, tckn);
						output.put(tableName, count, TransactionConstants.RecipientDef.BANK, bank);
						output.put(tableName, count, TransactionConstants.RecipientDef.BRANCH, branch);
						output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE, orderType);
						output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, orderTypeText);
					} else {
						output.put(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO, input.getString(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO));
						output.put(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE, input.getString(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE));
						output.put(tableName, count, TransactionConstants.RecipientDef.IBAN, input.getString(tableName, count, TransactionConstants.RecipientDef.IBAN));
						output.put(tableName, count, TransactionConstants.RecipientDef.TCKN, input.getString(tableName, count, TransactionConstants.RecipientDef.TCKN));
						output.put(tableName, count, TransactionConstants.RecipientDef.BANK, input.getString(tableName, count, TransactionConstants.RecipientDef.BANK));
						output.put(tableName, count, TransactionConstants.RecipientDef.BRANCH, input.getString(tableName, count, TransactionConstants.RecipientDef.BRANCH));
						output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE, input.getString(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE));
						output.put(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, input.getString(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT));
					}
				}				
			} else if ("REMOVE".equals(action)) {
				int removeCount = 0;
				for (count = 0; count < input.getSize(tableName); count++ ) {
					if (count == selectedRow) {
						removeCount--;
					} else {
						output.put(tableName, removeCount, TransactionConstants.RecipientDef.ACCOUNT_NO, input.getString(tableName, count, TransactionConstants.RecipientDef.ACCOUNT_NO));
						output.put(tableName, removeCount, TransactionConstants.RecipientDef.NAME_TITLE, input.getString(tableName, count, TransactionConstants.RecipientDef.NAME_TITLE));
						output.put(tableName, removeCount, TransactionConstants.RecipientDef.IBAN, input.getString(tableName, count, TransactionConstants.RecipientDef.IBAN));
						output.put(tableName, removeCount, TransactionConstants.RecipientDef.TCKN, input.getString(tableName, count, TransactionConstants.RecipientDef.TCKN));
						output.put(tableName, removeCount, TransactionConstants.RecipientDef.BANK, input.getString(tableName, count, TransactionConstants.RecipientDef.BANK));
						output.put(tableName, removeCount, TransactionConstants.RecipientDef.BRANCH, input.getString(tableName, count, TransactionConstants.RecipientDef.BRANCH));
						output.put(tableName, removeCount, TransactionConstants.RecipientDef.ORDER_TYPE, input.getString(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE));
						output.put(tableName, removeCount, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, input.getString(tableName, count, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT));
					}
					removeCount++;
				}	
			}	
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	}		
	
	@GraymoundService("COS_LOAD_RECIPIENTS")
	public static GMMap loadRecipients(GMMap input) {
		GMMap output = new GMMap();
		String tableName = TransactionConstants.RecipientDef.tableName;
		int initialTableSize = input.getSize(tableName);
        
		try {
			String filePath = input.getString(TransactionConstants.RecipientDef.FILE_PATH);
			String orderTypeQuery = QueryRepository.OrderCorporationDefinitionServicesRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
			String getErrorDescQuery = QueryRepository.OrderCorporationDefinitionServicesRepository.ERROR_MESSAGE_QUERY;
            String fileLineStr = null, errorDesc = null;            
			String orderTypeField = null, orderType = null, orderTypeText = null;
			String customerNameTitle = null, iban = null, accountNo = null, branch = null, bank = null, tckn = null;
			BigDecimal recipientAccountNoFromIban = null;
			boolean repeatedIban = false, repeatedTckn = false;
	        int lineCounter=0;   
			
			logger.info(String.format("COS_LOAD_RECIPIENTS service, filePath: %s", filePath));
			
			if (StringUtils.isEmpty(filePath))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Dosya se�iniz"));				

			List<String> pathParts = Arrays.asList(filePath.split("[.]"));			
			String fileExt = pathParts.get(pathParts.size()-1);
			if (!StringUtils.equalsIgnoreCase(GeneralConstants.CsvExtension, fileExt))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.FILETYPEMUSTBECSV));	
	      
            File file = FileUtil.createTempDirFile("csvread");
            OutputStream writer = new FileOutputStream(file);
            writer.write((byte[]) input.get(TransactionConstants.RecipientDef.FILE));
            writer.flush();

            BufferedReader fileReader = new BufferedReader(new FileReader(file));
            // first line is header. skip first line. Start erroneous line counter from 2
            fileReader.readLine();
	        int erroneousLineCounter = 2;
            
			for (lineCounter = 0; lineCounter < initialTableSize; lineCounter++ ) {
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.ACCOUNT_NO, input.getString(tableName, lineCounter, TransactionConstants.RecipientDef.ACCOUNT_NO));
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.NAME_TITLE, input.getString(tableName, lineCounter, TransactionConstants.RecipientDef.NAME_TITLE));
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.IBAN, input.getString(tableName, lineCounter, TransactionConstants.RecipientDef.IBAN));
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.TCKN, input.getString(tableName, lineCounter, TransactionConstants.RecipientDef.TCKN));
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.BANK, input.getString(tableName, lineCounter, TransactionConstants.RecipientDef.BANK));
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.BRANCH, input.getString(tableName, lineCounter, TransactionConstants.RecipientDef.BRANCH));
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.ORDER_TYPE, input.getString(tableName, lineCounter, TransactionConstants.RecipientDef.ORDER_TYPE));
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, input.getString(tableName, lineCounter, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT));
			}
			
            while ((fileLineStr =fileReader.readLine()) != null) {
				List<String> lineParts = Arrays.asList(fileLineStr.split("[,;]"));	
				for (int currentIndex = 0; currentIndex < lineParts.size(); currentIndex++) {
					if (currentIndex == 0) {
						orderTypeField = lineParts.get(currentIndex);
						if (!StringUtils.isEmpty(orderTypeField)) {
							if (StringUtils.equalsIgnoreCase(DatabaseConstants.OrderTypePlainText.EFT, orderTypeField))
								orderType = DatabaseConstants.OrderType.EFT;
							else if (StringUtils.equalsIgnoreCase(DatabaseConstants.OrderTypePlainText.Havale, orderTypeField))
								orderType = DatabaseConstants.OrderType.Havale;
							else if (StringUtils.equalsIgnoreCase(DatabaseConstants.OrderTypePlainText.Virman, orderTypeField))
								orderType = DatabaseConstants.OrderType.Virman;
							else if (StringUtils.equalsIgnoreCase(DatabaseConstants.OrderTypePlainText.PTTIsmeHavale, orderTypeField))
								orderType = DatabaseConstants.OrderType.PTTIsmeHavale;							
						}									
					} else if (currentIndex == 1) {
						customerNameTitle = lineParts.get(currentIndex);
					} else if (currentIndex == 2) {
						iban = lineParts.get(currentIndex);
					} else if (currentIndex == 3) {
						accountNo = lineParts.get(currentIndex);
					} else if (currentIndex == 4) {
						branch = lineParts.get(currentIndex);
					} else if (currentIndex == 5) {
						bank = lineParts.get(currentIndex);
					} else if (currentIndex == 6) {
						tckn = lineParts.get(currentIndex);
					}
				}

				if (StringUtils.isEmpty(orderType)) {
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, "��lem t�r� belirlenemedi. Ge�ersiz i�lem t�r�"));
				}
				
				if (StringUtils.isEmpty(customerNameTitle)) {
					errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.RECIPIENTDEFNAMEISMUSTFIELD.getCode()));				
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
				}
				
				repeatedIban = false; 
				repeatedTckn = false;				
				for (int i = 0; i < output.getSize(tableName); i++ ) {		
					if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {
						if (!StringUtils.isEmpty(tckn) && tckn.equals(output.getString(tableName, i, TransactionConstants.RecipientDef.TCKN)) ) {
							repeatedTckn = true;
						}
					} else {
						if (!StringUtils.isEmpty(iban) && iban.equals(output.getString(tableName, i, TransactionConstants.RecipientDef.IBAN)) ) {
							repeatedIban = true;
						}						
					}
				}
				
				if (repeatedIban || repeatedTckn) {
					errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.REPEATEDRECIPIENTDEF.getCode()));				
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
				}
						
				if (orderType.equals(DatabaseConstants.OrderType.EFT) || orderType.equals(DatabaseConstants.OrderType.Havale) || orderType.equals(DatabaseConstants.OrderType.Virman)) {
					if (!StringUtils.isEmpty(iban)) {
						String dummy = null;
						Object[] inputValues = new Object[] {BnsprType.STRING, iban};
						Object[] outputValues = new Object[] {BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY"};
						try {
							GMMap procedureOutputMap = (GMMap) DALUtil.callOracleProcedure("{call BNSPR.PKG_EFT.EFT_IBAN_BANKA_SUBE_SEHIR_AL(?,?,?,?,?,?,?)}", inputValues, outputValues);	
							dummy = (String) procedureOutputMap.get("DUMMY");
						} catch (Exception e) {
							errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.INVALIDIBAN.getCode()));
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
						}
					}				
				}								

				if (orderType.equals(DatabaseConstants.OrderType.EFT)) {
					if (StringUtils.isEmpty(iban) && ( StringUtils.isEmpty(accountNo) || StringUtils.isEmpty(branch) || StringUtils.isEmpty(bank) ) ) {
						errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.RECIPIENTDEFEFTMUSTFIELDS.getCode()));
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
					}
				}
				else if (orderType.equals(DatabaseConstants.OrderType.Havale)) {
					if (StringUtils.isEmpty(iban) && ( StringUtils.isEmpty(accountNo) ) ) {						
						errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.RECIPIENTDEFHAVALEMUSTFIELDS.getCode()));
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
					}
				}
				else if (orderType.equals(DatabaseConstants.OrderType.Virman)) {
					if (StringUtils.isEmpty(iban) && ( StringUtils.isEmpty(accountNo) ) ) {						
						errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.RECIPIENTDEFVIRMANMUSTFIELDS.getCode()));
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
					}
				}
				else if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {
					if (StringUtils.isEmpty(customerNameTitle) || StringUtils.isEmpty(tckn) ) {
						errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.RECIPIENTDEFPTTHAVALEMUSTFIELDS.getCode()));
						CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
					}
				}
				
				if (orderType.equals(DatabaseConstants.OrderType.EFT)) {
					if (!StringUtils.isEmpty(bank) && !StringUtils.isEmpty(branch)) {
						if (!isValidBranch(bank, branch)) {
							errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.BANKBRANCHNOTDEFINED.getCode()));
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
						}
					}
				}
				
				if (orderType.equals(DatabaseConstants.OrderType.Havale) || orderType.equals(DatabaseConstants.OrderType.Virman)) {
					if (!StringUtils.isEmpty(iban)) {
						recipientAccountNoFromIban = getAccountNoFromIban(iban);
						if (recipientAccountNoFromIban == null) {
							errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.NOSUCHIBANFOUND.getCode()));
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc.replace("#1", iban)));
						}
						else {
							if (!StringUtils.isEmpty(accountNo)) {
								if (recipientAccountNoFromIban.compareTo(new BigDecimal(accountNo)) != 0 ) {
									errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.IBANACCOUNTNOMISMATCH.getCode()));
									CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
								}
							}
						}
					}					
					
					if (!StringUtils.isEmpty(branch) && !StringUtils.isEmpty(accountNo)) {
						if (!isValidAccountNo(branch, new BigDecimal(accountNo))) {
							errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.BRACHACCOUNTNONOTDEFINED.getCode()));
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
						}
					} else if (!StringUtils.isEmpty(accountNo)) {
						if (!isValidAccountNo(new BigDecimal(accountNo))) {
							errorDesc = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.BRACHACCOUNTNONOTDEFINED.getCode()));
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ERRORATFILELOADING, erroneousLineCounter, errorDesc));
						}
					}			
				}
				
				orderTypeText = DALUtil.getResult(String.format(orderTypeQuery, orderType));
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.ACCOUNT_NO, accountNo);
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.NAME_TITLE, customerNameTitle);
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.IBAN, iban);
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.TCKN, tckn);
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.BANK, bank);
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.BRANCH, branch);
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.ORDER_TYPE, orderType);
				output.put(tableName, lineCounter, TransactionConstants.RecipientDef.ORDER_TYPE_TEXT, orderTypeText);      				        			
				
				customerNameTitle = "";
				iban = ""; 
				accountNo = "";
				branch = "";
				bank = ""; 
				tckn = "";
				orderType = "";
				orderTypeText = "";
				
                lineCounter++;
                erroneousLineCounter++;
            }

            if(fileReader!=null){
                fileReader.close();
            }

		} catch (FileNotFoundException e) {
			logger.error("FileNotFoundException exception occured while loading recipients from file");
			logger.error(System.currentTimeMillis(), e);			
		} catch (IOException e) {
			logger.error("IOException exception occured while loading recipients from file");
			logger.error(System.currentTimeMillis(), e);					
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return output;
	}				
	
	private static BigDecimal getAccountNoFromIban(String iban) {
		String query = QueryRepository.OrderCorporationDefinitionServicesRepository.HESAP_NO_BY_IBAN_QUERY;
		String result = DALUtil.getResult(String.format(query, iban));
		
		if (!StringUtils.isEmpty(result))
			return new BigDecimal(result);
		else 
			return null;
	}
	
	private static boolean isValidBranch(String bankCode, String branchCode) {
		String query = null, result = null;
		if (!bankCode.equals(GeneralConstants.AktifBankCode)) {
			query = QueryRepository.OrderCorporationDefinitionServicesRepository.BRANCH_CODE_VALIDITY_BY_BANK_CODE_QUERY;
			result = DALUtil.getResult(String.format(query, bankCode, String.format("%5s", branchCode).replace(' ','0')));
		} else {
			query = QueryRepository.OrderCorporationDefinitionServicesRepository.BRANCH_CODE_VALIDITY_QUERY;
			result = DALUtil.getResult(String.format(query, branchCode));			
		}
		
		if (!StringUtils.isEmpty(result))
			return true;
		else 
			return false;
	}
	
	private static boolean isValidAccountNo(String branchCode, BigDecimal accountNo) {
		String query = QueryRepository.OrderCorporationDefinitionServicesRepository.SUBE_KODU_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result) && result.equals(branchCode))
			return true;
		else 
			return false;
	}
	
	private static boolean isValidAccountNo(BigDecimal accountNo) {
		String query = QueryRepository.OrderCorporationDefinitionServicesRepository.SUBE_KODU_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return true;
		else 
			return false;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_CONTACT_INFO")
	public static GMMap getContactInfo(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.CorpContactInfo.tableName;
			String corpOid = input.getString(TransactionConstants.CorpContactInfo.CORP_OID);
			
			List<OrderCorpContactinfo> contactInfoList = hibernateSession.createCriteria(OrderCorpContactinfo.class)
														.add(Restrictions.eq("status", true))
														.add(Restrictions.eq("corporateOid", corpOid)).list();							
			int count = 0;
			
			for (OrderCorpContactinfo contactInfo : contactInfoList) {		
				output.put(tableName, count, TransactionConstants.CorpContactInfo.EMAIL, contactInfo.getEmail());				
				output.put(tableName, count, TransactionConstants.CorpContactInfo.FAX, contactInfo.getFax());								
				output.put(tableName, count, TransactionConstants.CorpContactInfo.MOBILE, contactInfo.getMobile());					
				output.put(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME, contactInfo.getNameSurname());
				output.put(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER, contactInfo.getPhoneNumber());	
				output.put(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER, contactInfo.getExtensionNumber());		
				count++;
			}	
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_CONTACT_INFO_TX")
	public static GMMap getContactInfoTx(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.CorpContactInfo.tableName;
			String corpOid = input.getString(TransactionConstants.CorpContactInfo.CORP_OID);
			
			List<OrderCorpContactinfoTx> contactInfoTxList = hibernateSession.createCriteria(OrderCorpContactinfoTx.class)
														.add(Restrictions.eq("status", true))
														.add(Restrictions.eq("corporateOid", corpOid)).list();							
			int count = 0;
			
			for (OrderCorpContactinfoTx contactInfoTx : contactInfoTxList) {		
				output.put(tableName, count, TransactionConstants.CorpContactInfo.EMAIL, contactInfoTx.getEmail());				
				output.put(tableName, count, TransactionConstants.CorpContactInfo.FAX, contactInfoTx.getFax());								
				output.put(tableName, count, TransactionConstants.CorpContactInfo.MOBILE, contactInfoTx.getMobile());					
				output.put(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME, contactInfoTx.getNameSurname());
				output.put(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER, contactInfoTx.getPhoneNumber());		
				output.put(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER, contactInfoTx.getExtensionNumber());		
				count++;
			}	
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}		
	
	@GraymoundService("COS_EDIT_CONTACT_INFO")
	public static GMMap editContactInfo(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = TransactionConstants.CorpContactInfo.tableName;
			int count;

			String email = input.getString(TransactionConstants.CorpContactInfo.EMAIL);
			String fax = input.getString(TransactionConstants.CorpContactInfo.FAX);
			String mobile = input.getString(TransactionConstants.CorpContactInfo.MOBILE);
			String nameSurname = input.getString(TransactionConstants.CorpContactInfo.NAME_SURNAME);
			String phoneNumber = input.getString(TransactionConstants.CorpContactInfo.PHONE_NUMBER);
			String extensionNumber = input.getString(TransactionConstants.CorpContactInfo.EXTENSION_NUMBER);
			String action = input.getString("TAB_ACTION");
			int selectedRow = input.getInt("SELECTED_ROW");
						
			if ("ADD".equals(action) || "UPDATE".equals(action))
				if (StringUtils.isBlank(nameSurname)) 
					CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ad Soyad"));	
			
			if ("ADD".equals(action)) {
				for (count = 0; count < input.getSize(tableName); count++ ) {
					output.put(tableName, count, TransactionConstants.CorpContactInfo.EMAIL, input.getString(tableName, count, TransactionConstants.CorpContactInfo.EMAIL));
					output.put(tableName, count, TransactionConstants.CorpContactInfo.FAX, input.getString(tableName, count, TransactionConstants.CorpContactInfo.FAX));
					output.put(tableName, count, TransactionConstants.CorpContactInfo.MOBILE, input.getString(tableName, count, TransactionConstants.CorpContactInfo.MOBILE));
					output.put(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME, input.getString(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME));
					output.put(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER, input.getString(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER));
					output.put(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER, input.getString(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER));					
				}
				output.put(tableName, count, TransactionConstants.CorpContactInfo.EMAIL, email);
				output.put(tableName, count, TransactionConstants.CorpContactInfo.FAX, fax);
				output.put(tableName, count, TransactionConstants.CorpContactInfo.MOBILE, mobile);
				output.put(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME, nameSurname);
				output.put(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER, phoneNumber);
				output.put(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER, extensionNumber);
				
			} else if ("UPDATE".equals(action)) {
				for (count = 0; count < input.getSize(tableName); count++ ) {
					if (count == selectedRow) {
						output.put(tableName, count, TransactionConstants.CorpContactInfo.EMAIL, email);
						output.put(tableName, count, TransactionConstants.CorpContactInfo.FAX, fax);
						output.put(tableName, count, TransactionConstants.CorpContactInfo.MOBILE, mobile);
						output.put(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME, nameSurname);
						output.put(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER, phoneNumber);			
						output.put(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER, extensionNumber);
					} else {
						output.put(tableName, count, TransactionConstants.CorpContactInfo.EMAIL, input.getString(tableName, count, TransactionConstants.CorpContactInfo.EMAIL));
						output.put(tableName, count, TransactionConstants.CorpContactInfo.FAX, input.getString(tableName, count, TransactionConstants.CorpContactInfo.FAX));
						output.put(tableName, count, TransactionConstants.CorpContactInfo.MOBILE, input.getString(tableName, count, TransactionConstants.CorpContactInfo.MOBILE));
						output.put(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME, input.getString(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME));
						output.put(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER, input.getString(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER));
						output.put(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER, input.getString(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER));
					}
				}				
			} else if ("REMOVE".equals(action)) {
				int removeCount = 0;
				for (count = 0; count < input.getSize(tableName); count++ ) {
					if (count == selectedRow) {
						removeCount--;
					} else {
						output.put(tableName, removeCount, TransactionConstants.CorpContactInfo.EMAIL, input.getString(tableName, count, TransactionConstants.CorpContactInfo.EMAIL));
						output.put(tableName, removeCount, TransactionConstants.CorpContactInfo.FAX, input.getString(tableName, count, TransactionConstants.CorpContactInfo.FAX));
						output.put(tableName, removeCount, TransactionConstants.CorpContactInfo.MOBILE, input.getString(tableName, count, TransactionConstants.CorpContactInfo.MOBILE));
						output.put(tableName, removeCount, TransactionConstants.CorpContactInfo.NAME_SURNAME, input.getString(tableName, count, TransactionConstants.CorpContactInfo.NAME_SURNAME));
						output.put(tableName, removeCount, TransactionConstants.CorpContactInfo.PHONE_NUMBER, input.getString(tableName, count, TransactionConstants.CorpContactInfo.PHONE_NUMBER));
						output.put(tableName, removeCount, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER, input.getString(tableName, count, TransactionConstants.CorpContactInfo.EXTENSION_NUMBER));
					}
					removeCount++;
				}	
			}
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	}		
	
	@GraymoundService("COS_GET_CORP_APPROVAL_STATUS")
	public static GMMap getCorpApprovalStatus(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			String corporateCode = input.getString("CORPORATE_CODE");
			
			@SuppressWarnings("unchecked")
			List<CorporationDefTx> corpDefTxList = hibernateSession.createCriteria(CorporationDefTx.class)
													.add(Restrictions.eq("corporateCode", corporateCode))
													.add(Restrictions.isNotNull("txNo"))
													.add(Restrictions.eq("status", true)).list();
			if (corpDefTxList.size() > 0) {
				output.put("APPROVAL_STATUS", true);
			} else {
				output.put("APPROVAL_STATUS", false);
			}
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_TRN7201_AFTER_APPROVAL")
	public static GMMap trn7201AfterApproval(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal txNo = input.getBigDecimal("ISLEM_NO");
			CorporationDef corpDef = null, newCorpDef = null;
			CorporationDefTx corpDefTx = null;
			CorporationAccountDef newCorpAccDef = null;
			CorporateOrderParameters corpParam = null, newCorpParam = null;
			CorporateOrderParametersTx corpParamTx = null;
			RecipientDef newRecDef = null;
			OrderCorpContactinfo newContactInfo = null;
			String corpOid = null, corporateCode = null, oldCorpOid = null;
			
			logger.info(String.format("COS_TRN7201_AFTER_APPROVAL service, txNo: %s", txNo));
			
			corpDefTx = (CorporationDefTx) hibernateSession.createCriteria(CorporationDefTx.class)
											.add(Restrictions.eq("txNo", txNo))
											.add(Restrictions.eq("status", true)).uniqueResult();
			if (corpDefTx != null) {
				corpOid = corpDefTx.getCorporateOid();
				corporateCode = corpDefTx.getCorporateCode();
				//check if the corporation already exists
				corpDef = (CorporationDef) hibernateSession.createCriteria(CorporationDef.class)
											.add(Restrictions.eq("corporateCode", corporateCode))
											.add(Restrictions.eq("status", true)).uniqueResult();	
				if (corpDef != null) {
					corpDef.setStatus(false);				
					hibernateSession.update(corpDef);
					
					oldCorpOid = corpDef.getOid();
				}
				//insert new corporation
				newCorpDef = new CorporationDef();		
				newCorpDef.setStatus(true);
				newCorpDef.setTxNo(txNo);
				newCorpDef.setActiveness(corpDefTx.getActiveness());		
				newCorpDef.setCorporateCode(corpDefTx.getCorporateCode());
				newCorpDef.setShortName(corpDefTx.getShortName());
				newCorpDef.setCustomerNo(corpDefTx.getCustomerNo());
				newCorpDef.setCorporateName(corpDefTx.getCorporateName());
				newCorpDef.setCreateUser(corpDefTx.getCreateUser());
				newCorpDef.setCreateDate(corpDefTx.getCreateDate());
				newCorpDef.setOid(corpOid);
				hibernateSession.save(newCorpDef);
				
				corpDefTx.setStatus(false);				
				hibernateSession.update(corpDefTx);
				
				// if corporation activeness is true, then set ftm_file_definition state to active. Otherwise set ftm_file_definition state to passive
				CorporateFileTransfer incomingFileTransferDef = (CorporateFileTransfer) hibernateSession.createCriteria(CorporateFileTransfer.class)
																.add(Restrictions.eq("status", true))
																.add(Restrictions.eq("corporateCode", corpDefTx.getCorporateCode()))
																.add(Restrictions.eq("transferType", new Short(DatabaseConstants.TransferTypes.OrderLoading)))  
																.add(Restrictions.or(Restrictions.eq("complexFileTransfer", false), Restrictions.isNull("complexFileTransfer"))).uniqueResult();				
				if (incomingFileTransferDef != null) {
					FtmFileDefinition ftmFileDef = (FtmFileDefinition) hibernateSession.createCriteria(FtmFileDefinition.class)
													.add(Restrictions.eq("oid", incomingFileTransferDef.getFtmId())).uniqueResult();
					if (ftmFileDef != null) {
						if (corpDefTx.getActiveness())
							ftmFileDef.setFtmStateOid(DatabaseConstants.FtmState.Active);
						else
							ftmFileDef.setFtmStateOid(DatabaseConstants.FtmState.Passive);						
						hibernateSession.update(ftmFileDef);
						try {
							GMMap serviceInputMap = new GMMap();
							CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.FTM_CONNECTION_NAME, "BNSPR_FTM_REFRESH_CACHES", serviceInputMap);
						} catch (Throwable e) {
							logger.error("An exception occured while refreshing ftm caches");
							logger.error(System.currentTimeMillis(), e);								
						}						
					}
				}
				
				//insert accounts and set status to false in both tables
				List<CorporationAccountDefTx> corpAccDefTxList = hibernateSession.createCriteria(CorporationAccountDefTx.class)
																.add(Restrictions.eq("status", true))
																.add(Restrictions.eq("corporateOid", corpOid)).list();		
				if (corpAccDefTxList.size() > 0) {
					List<CorporationAccountDef> corpAccDefList = hibernateSession.createCriteria(CorporationAccountDef.class)
																.add(Restrictions.eq("status", true))
																.add(Restrictions.eq("corporateOid", oldCorpOid)).list();		
					if (corpAccDefList.size() > 0)
						for (CorporationAccountDef corpAccDef : corpAccDefList) {
							corpAccDef.setStatus(false);
							hibernateSession.update(corpAccDef);
						}
					
					for (CorporationAccountDefTx corpAccDefTx : corpAccDefTxList) {
						newCorpAccDef = new CorporationAccountDef();
						newCorpAccDef.setStatus(true);
						newCorpAccDef.setAccountType(corpAccDefTx.getAccountType());
						newCorpAccDef.setAccountNo(corpAccDefTx.getAccountNo());
						newCorpAccDef.setDefaultAccount(corpAccDefTx.getDefaultAccount());
						newCorpAccDef.setAccountName(corpAccDefTx.getAccountName());
						newCorpAccDef.setAccountProductType(corpAccDefTx.getAccountProductType());
						newCorpAccDef.setAccountBranch(corpAccDefTx.getAccountBranch());
						newCorpAccDef.setAccountCurrencyCode(corpAccDefTx.getAccountCurrencyCode());
						newCorpAccDef.setIsDkAccount(corpAccDefTx.getIsDkAccount());
						newCorpAccDef.setCorporateOid(corpOid);
						hibernateSession.save(newCorpAccDef);		
					}
					
					for (CorporationAccountDefTx corpAccDefTx : corpAccDefTxList) {
						corpAccDefTx.setStatus(false);
						hibernateSession.update(corpAccDefTx);		
					}										
				}
								
				//insert parameters and set status to false in both tables
				corpParamTx = (CorporateOrderParametersTx) hibernateSession.createCriteria(CorporateOrderParametersTx.class)
															.add(Restrictions.eq("corporateOid",corpOid))
															.add(Restrictions.eq("status",true)).uniqueResult();	
				if (corpParamTx != null) {
					corpParam = (CorporateOrderParameters) hibernateSession.createCriteria(CorporateOrderParameters.class)
															.add(Restrictions.eq("corporateOid",oldCorpOid))
															.add(Restrictions.eq("status",true)).uniqueResult();	
					if (corpParam != null) {
						corpParam.setStatus(false);
						hibernateSession.update(corpParam);
					}
					
					newCorpParam = new CorporateOrderParameters();								
					newCorpParam.setStatus(true);
					newCorpParam.setCorporateOid(corpOid);
					newCorpParam.setCheckVkn(corpParamTx.isCheckVkn());
					newCorpParam.setCheckTckn(corpParamTx.isCheckTckn());
					newCorpParam.setCheckNameConsistency(corpParamTx.isCheckNameConsistency());			
					newCorpParam.setAmountOrder(corpParamTx.getAmountOrder());			
					newCorpParam.setCheckRecipients(corpParamTx.isCheckRecipients());
					newCorpParam.setSmsToRecipient(corpParamTx.isSmsToRecipient());
					newCorpParam.setSmsOrderType(corpParamTx.getSmsOrderType());
					newCorpParam.setEmailToRecipient(corpParamTx.isEmailToRecipient());
					newCorpParam.setEmailLoadingStatus(corpParamTx.isEmailLoadingStatus());
					newCorpParam.setEmailTransferStatus(corpParamTx.isEmailTransferStatus());
					newCorpParam.setEmailEodStatus(corpParamTx.isEmailEodStatus());			
					newCorpParam.setMakeLoadingStatusFile(corpParamTx.isMakeLoadingStatusFile());
					newCorpParam.setMakeTransferStatusFile(corpParamTx.isMakeTransferStatusFile());
					newCorpParam.setMakeEodStatusFile(corpParamTx.getMakeEodStatusFile());
					newCorpParam.setAllowTransferToValid(corpParamTx.isAllowTransferToValid());
					newCorpParam.setEmailReceiptToRecipient(corpParamTx.getEmailReceiptToRecipient());
					newCorpParam.setTransferWithoutApproval(corpParamTx.getTransferWithoutApproval());
					newCorpParam.setLoadingEmail(corpParamTx.getLoadingEmail());
					newCorpParam.setTransferEmail(corpParamTx.getTransferEmail());
					newCorpParam.setEodEmail(corpParamTx.getEodEmail());
					newCorpParam.setEodEmailTime(corpParamTx.getEodEmailTime());			
					hibernateSession.save(newCorpParam);	
					
					corpParamTx.setStatus(false);
					hibernateSession.update(corpParamTx);					
				}
				
				//insert recipients and set status to false in both tables				
				List<RecipientDefTx> recDefTxList = hibernateSession.createCriteria(RecipientDefTx.class)
													.add(Restrictions.eq("status", true))
													.add(Restrictions.eq("corporateOid", corpOid)).list();	
				if (recDefTxList.size() > 0) {
					List<RecipientDef> recDefList = hibernateSession.createCriteria(RecipientDef.class)
													.add(Restrictions.eq("status", true))
													.add(Restrictions.eq("corporateOid", oldCorpOid)).list();						
					if (recDefList.size() > 0) 
						for (RecipientDef recDef : recDefList) {
							recDef.setStatus(false);
							hibernateSession.update(recDef);
						}
					
					for (RecipientDefTx recDefTx : recDefTxList) {
						newRecDef = new RecipientDef();				
						newRecDef.setStatus(true);
						newRecDef.setRecipientAccountNo(recDefTx.getRecipientAccountNo());
						newRecDef.setRecipientIban(recDefTx.getRecipientIban());
						newRecDef.setRecipientName(recDefTx.getRecipientName());
						newRecDef.setRecipientTckn(recDefTx.getRecipientTckn());
						newRecDef.setRecipientBank(recDefTx.getRecipientBank());
						newRecDef.setRecipientBranch(recDefTx.getRecipientBranch());
						newRecDef.setOrderType(recDefTx.getOrderType());
						newRecDef.setCorporateOid(corpOid);		
						hibernateSession.save(newRecDef);						
					}
					
					for (RecipientDefTx recDefTx : recDefTxList) {
						recDefTx.setStatus(false);
						hibernateSession.save(recDefTx);						
					}
				}
				
				//insert contact info and set status to false in both tables				
				List<OrderCorpContactinfoTx> contactInfoTxList = hibernateSession.createCriteria(OrderCorpContactinfoTx.class)
																.add(Restrictions.eq("status", true))
																.add(Restrictions.eq("corporateOid", corpOid)).list();	
				if (contactInfoTxList.size() > 0) {
					List<OrderCorpContactinfo> contactInfoList = hibernateSession.createCriteria(OrderCorpContactinfo.class)
																.add(Restrictions.eq("status", true))
																.add(Restrictions.eq("corporateOid", oldCorpOid)).list();						
					if (contactInfoList.size() > 0) 
						for (OrderCorpContactinfo contactInfo : contactInfoList) {
							contactInfo.setStatus(false);
							hibernateSession.update(contactInfo);
						}
					
					for (OrderCorpContactinfoTx contactInfoTx : contactInfoTxList) {
						newContactInfo = new OrderCorpContactinfo();				
						newContactInfo.setStatus(true);
						newContactInfo.setEmail(contactInfoTx.getEmail());
						newContactInfo.setFax(contactInfoTx.getFax());
						newContactInfo.setMobile(contactInfoTx.getMobile());
						newContactInfo.setNameSurname(contactInfoTx.getNameSurname());
						newContactInfo.setPhoneNumber(contactInfoTx.getPhoneNumber());
						newContactInfo.setExtensionNumber(contactInfoTx.getExtensionNumber());
						newContactInfo.setCorporateOid(corpOid);	
						hibernateSession.save(newContactInfo);							
					}
					
					for (OrderCorpContactinfoTx contactInfoTx : contactInfoTxList) {
						contactInfoTx.setStatus(false);
						hibernateSession.save(contactInfoTx);						
					}
				}				
			}
			
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_TRN7201_AFTER_CANCELATION")
	public static GMMap trn7201AfterCancelation(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal txNo = input.getBigDecimal("ISLEM_NO");
			CorporationDefTx corpDefTx = null;
			CorporateOrderParametersTx corpParamTx = null;
			String corpOid = null;
			
			//set status to false in tx tables
			corpDefTx = (CorporationDefTx) hibernateSession.createCriteria(CorporationDefTx.class)
											.add(Restrictions.eq("txNo", txNo))
											.add(Restrictions.eq("status", true)).uniqueResult();
			if (corpDefTx != null) {
				corpOid = corpDefTx.getCorporateOid();
				
				corpDefTx.setStatus(false);				
				hibernateSession.update(corpDefTx);
				
				List<CorporationAccountDefTx> corpAccDefTxList = hibernateSession.createCriteria(CorporationAccountDefTx.class)
																.add(Restrictions.eq("status", true))
																.add(Restrictions.eq("corporateOid", corpOid)).list();						
				for (CorporationAccountDefTx corpAccDefTx : corpAccDefTxList) {
					corpAccDefTx.setStatus(false);
					hibernateSession.update(corpAccDefTx);		
				}										

				corpParamTx = (CorporateOrderParametersTx) hibernateSession.createCriteria(CorporateOrderParametersTx.class)
															.add(Restrictions.eq("corporateOid",corpOid))
															.add(Restrictions.eq("status",true)).uniqueResult();	
				if (corpParamTx != null) {
					corpParamTx.setStatus(false);
					hibernateSession.update(corpParamTx);
				}
							
				List<RecipientDefTx> recDefTxList = hibernateSession.createCriteria(RecipientDefTx.class)
													.add(Restrictions.eq("status", true))
													.add(Restrictions.eq("corporateOid", corpOid)).list();	
				for (RecipientDefTx recDefTx : recDefTxList) {
					recDefTx.setStatus(false);
					hibernateSession.save(recDefTx);						
				}
			}
			
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@GraymoundService("COS_SEND_CORP_DEF_TRANSACTION")
	public static GMMap sendCorpDefTransaction(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal transactionNo = null;
			GMMap transactionMap = null;
			
			String corpOid = input.getString("CORP_OID");					
			CorporationDefTx corpDefTx = (CorporationDefTx) hibernateSession.createCriteria(CorporationDefTx.class)
											.add(Restrictions.eq("corporateOid", corpOid))
											.add(Restrictions.eq("status", true)).uniqueResult();			
			if (corpDefTx != null) { 
				transactionNo = new BigDecimal(CommonHelper.getNewTransactionNo());
				corpDefTx.setTxNo(transactionNo);				
				hibernateSession.update(corpDefTx);
			}			
			hibernateSession.flush();
			
			input.put("TRX_NAME", "7201");
			input.put("TRX_NO", transactionNo);
					
			transactionMap = CommonBusinessOperations.callGraymoundService(input, "BNSPR_TRX_SEND_TRANSACTION", true);
			output.put("MESSAGE", transactionMap.getString("MESSAGE"));		
			hibernateSession.flush();		
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	}		
}