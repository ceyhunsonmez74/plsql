package tr.com.aktifbank.bnspr.cos.transactions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants.LockOrdersForProcess;
import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;

import com.graymound.util.GMMap;

public class LockOrdersForProcessHandler extends RequestHandler {

	public LockOrdersForProcessHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String updateCommand = input.getString(LockOrdersForProcess.Input.UPDATE_COMMAND);
		
		StringBuilder orderMainQueryBuilder = new StringBuilder();
		orderMainQueryBuilder.append(String.format("UPDATE COS.ORDER_MAIN SET ORDER_STATUS='%s' WHERE ", DatabaseConstants.OrderStatuses.AfterApprovalProcessStarted));
		
		StringBuilder orderTransferLogBuilder = new StringBuilder();
		orderTransferLogBuilder.append(String.format("UPDATE COS.ORDER_TRANSFER_LOG SET ORDER_STATUS='%s' WHERE ", DatabaseConstants.OrderStatuses.AfterApprovalProcessStarted));
		
		if(updateCommand.equals(GeneralConstants.AFTER_APP_UPDATE_COMMAND)){
			String mainTxNo = input.getString(LockOrdersForProcess.Input.MAIN_TX_NO);
			orderMainQueryBuilder.append(String.format("STATUS=1 AND MAIN_TX_NO='%s' AND ORDER_STATUS='%s'", mainTxNo, DatabaseConstants.OrderStatuses.Approved));
			orderTransferLogBuilder.append(String.format("STATUS=1 AND MAIN_TX_NO='%s' AND ORDER_STATUS='%s'", mainTxNo, DatabaseConstants.OrderStatuses.Approved));	
		}
		else if(updateCommand.equals(GeneralConstants.FAILED_UPDATE_COMMAND)){
			String processDate = input.getString(LockOrdersForProcess.Input.PROCESS_DATE);
			orderMainQueryBuilder.append(String.format("STATUS=1 AND ORDER_DATE is not null AND ORDER_STATUS >= '%s' AND ORDER_STATUS < '%s' AND ORDER_DATE='%s'",
					DatabaseConstants.OrderStatuses.InsufficientBalance, DatabaseConstants.OrderStatuses.Transfered, processDate));
			orderTransferLogBuilder.append(String.format("STATUS=1 AND ORDER_DATE is not null AND ORDER_STATUS >= '%s' AND ORDER_STATUS < '%s' AND ORDER_DATE='%s'",
					DatabaseConstants.OrderStatuses.InsufficientBalance, DatabaseConstants.OrderStatuses.Transfered, processDate));
		}
		else{
			throw new BatchComponentException(660, String.format("%s g�ncelleme komutu anla��lamad�.", updateCommand));
		}
		
		CommonHelper.getHibernateSession().createSQLQuery(orderMainQueryBuilder.toString()).executeUpdate();
		CommonHelper.getHibernateSession().createSQLQuery(orderTransferLogBuilder.toString()).executeUpdate();
	}

}
