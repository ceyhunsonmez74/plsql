package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.OutgoingFileLog;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public class CreateOutgoingFileByFtmCallHandler extends RequestHandler {

	public CreateOutgoingFileByFtmCallHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		String createFileType = input.getString(TransactionConstants.CreateOutgoingFileByFtmCall.Input.FILE_TYPE);
		String fileName = null;
		BigDecimal ftmSequenceNumber = null, ftmFileDefId = null;
		
		String threadSleepSecondsQuery = QueryRepository.CreateOutgoingFileByFtmCallHandlerRepository.THREAD_SLEEP_SECONDS_QUERY;
		String threadSleepSeconds = DALUtil.getResult(threadSleepSecondsQuery);
		long threadSleepMillis = Long.valueOf(threadSleepSeconds) * 1000;
		
		String fileTryCountQuery = QueryRepository.CreateOutgoingFileByFtmCallHandlerRepository.FILE_TRY_COUNT_QUERY;
		int fileTryCount = Integer.valueOf(DALUtil.getResult(fileTryCountQuery));

		List<OutgoingFileLog> fileList = super.getHibernateSession().createCriteria(OutgoingFileLog.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("fileType", createFileType)).list();	
		
		GMMap updateOutgoingFileStatus = new GMMap();			
		updateOutgoingFileStatus.put(TransactionConstants.UpdateOutgoingFileStatus.Input.SET_STATUS_FALSE, true);
		updateOutgoingFileStatus.put(TransactionConstants.UpdateOutgoingFileStatus.Input.FILE_TYPE, createFileType);
		super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateOutgoingFileStatus.SERVICE_NAME, updateOutgoingFileStatus);
				
		for (OutgoingFileLog outgoingFile : fileList) {
			int ftmResult = 0, tryCount = 0;
			fileName = outgoingFile.getFileName();
			ftmSequenceNumber = outgoingFile.getOutgoingFtmSequenceNumber();
			ftmFileDefId = outgoingFile.getFtmFileDefId();			
			do {
				try {
					GMMap ftmCreateTransferFileRequest = new GMMap();
					ftmCreateTransferFileRequest.put("FILE_DEF_ID", ftmFileDefId.longValue());
					ftmCreateTransferFileRequest.put("PROCESS_ID", ftmSequenceNumber.longValue());
					ftmCreateTransferFileRequest.put("FILE_NAME", fileName);
					logger.info("File transfer input map : " + ftmCreateTransferFileRequest.toString());
					
					GMMap ftmCreateTransferFileResponse = CommonHelper.callGraymoundServiceWithExternalConnection(GeneralConstants.FTM_CONNECTION_NAME, "BNSPR_FTM_CREATE_AND_TRANSFER_FILE", ftmCreateTransferFileRequest);
					ftmResult = ftmCreateTransferFileResponse.getInt("FTM_RESULT");
					logger.info("File transfer output map : " + ftmCreateTransferFileResponse.toString());
					tryCount++;
					if (ftmResult == 0) {
						Thread.sleep(threadSleepMillis);
					}
				} catch (Exception e) {
					logger.error("An exception occured while calling ftm file transfer service");
					logger.error(System.currentTimeMillis(), e);
					tryCount++;
				}
			} while (ftmResult == 0 && tryCount <= fileTryCount);

			updateOutgoingFileStatus = new GMMap();			
			updateOutgoingFileStatus.put(TransactionConstants.UpdateOutgoingFileStatus.Input.OUTGOING_FILE_OID, outgoingFile.getOid());
			super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateOutgoingFileStatus.SERVICE_NAME, updateOutgoingFileStatus);
		}	
		super.getHibernateSession().flush();
	}
}
