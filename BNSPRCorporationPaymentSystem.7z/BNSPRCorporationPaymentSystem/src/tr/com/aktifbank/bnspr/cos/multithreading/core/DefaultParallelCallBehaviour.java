package tr.com.aktifbank.bnspr.cos.multithreading.core;

import java.util.List;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.ParallelCallResult;

public final class DefaultParallelCallBehaviour implements
		ParallelCallBehaviour {

	ParallelCallResult result;
	
	public DefaultParallelCallBehaviour() {
		result = new ParallelCallResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void call(List<GMMap> tasks) {
		GMMap parallelCallResult = CommonHelper.callParallel(tasks);
		this.result.setAllSuccessful(parallelCallResult.getBoolean(TransactionConstants.ParallelCall.Output.T_SUCCESSFUL));
		this.result.setResults((List<GMMap>)parallelCallResult.get(TransactionConstants.ParallelCall.Output.T_RESULTS));
	}

	@Override
	public ParallelCallResult getResult() {
		return this.result;
	}

}
