package tr.com.aktifbank.bnspr.cos.dto;

public class BaseTransferObject {
	public BaseTransferObject(){
		
	}
}
