package tr.com.aktifbank.bnspr.cos.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Comparator;

public final class FormatDetail extends BaseTransferObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 904161784277562598L;

	public FormatDetail() {
		super();
	}
	
	private String oid;
    private boolean status;
    private String fileFormatOid;
    private String isMust;
    private String lineType;
    private String dataType;
    private BigDecimal startIndis;
    private BigDecimal length;
    private BigDecimal lineNumber;
    private String constant;
    private String initialConstant;
    private String datasourceType;
    private String datasourceReference;
    private Byte lineCount;
    private String alignment;
    private String fillingCharacter;
    private String dataPattern;
    private String explanation;
    private Boolean trimEmptyCharacters;
    private String datasourceReference2;
	
    public String getOid() {
        return this.oid;
    }
    
    public void setOid(String oid) {
        this.oid = oid;
    }
    public boolean isStatus() {
        return this.status;
    }
    
    public void setStatus(boolean status) {
        this.status = status;
    }
    public String getFileFormatOid() {
        return this.fileFormatOid;
    }
    
    public void setFileFormatOid(String fileFormatOid) {
        this.fileFormatOid = fileFormatOid;
    }
    public String getIsMust() {
        return this.isMust;
    }
    
    public void setIsMust(String isMust) {
        this.isMust = isMust;
    }
    public String getLineType() {
        return this.lineType;
    }
    
    public void setLineType(String lineType) {
        this.lineType = lineType;
    }
    public String getDataType() {
        return this.dataType;
    }
    
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    public BigDecimal getStartIndis() {
        return this.startIndis;
    }
    
    public void setStartIndis(BigDecimal startIndis) {
        this.startIndis = startIndis;
    }
    public BigDecimal getLength() {
        return this.length;
    }
    
    public void setLength(BigDecimal length) {
        this.length = length;
    }
    public BigDecimal getLineNumber() {
        return this.lineNumber;
    }
    
    public void setLineNumber(BigDecimal lineNumber) {
        this.lineNumber = lineNumber;
    }
    public String getConstant() {
        return this.constant;
    }
    
    public void setConstant(String constant) {
        this.constant = constant;
    }
    public String getInitialConstant() {
        return this.initialConstant;
    }
    
    public void setInitialConstant(String initialConstant) {
        this.initialConstant = initialConstant;
    }
    public String getDatasourceType() {
        return this.datasourceType;
    }
    
    public void setDatasourceType(String datasourceType) {
        this.datasourceType = datasourceType;
    }
    public String getDatasourceReference() {
        return this.datasourceReference;
    }
    
    public void setDatasourceReference(String datasourceReference) {
        this.datasourceReference = datasourceReference;
    }
    public Byte getLineCount() {
        return this.lineCount;
    }
    
    public void setLineCount(Byte lineCount) {
        this.lineCount = lineCount;
    }
    public String getAlignment() {
        return this.alignment;
    }
    
    public void setAlignment(String alignment) {
        this.alignment = alignment;
    }
    public String getFillingCharacter() {
        return this.fillingCharacter;
    }
    
    public void setFillingCharacter(String fillingCharacter) {
        this.fillingCharacter = fillingCharacter;
    }
    public String getDataPattern() {
        return this.dataPattern;
    }
    
    public void setDataPattern(String dataPattern) {
        this.dataPattern = dataPattern;
    }
    public String getExplanation() {
        return this.explanation;
    }
    
    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }
    public Boolean getTrimEmptyCharacters() {
        return this.trimEmptyCharacters;
    }
    
    public void setTrimEmptyCharacters(Boolean trimEmptyCharacters) {
        this.trimEmptyCharacters = trimEmptyCharacters;
    }
    public String getDatasourceReference2() {
        return this.datasourceReference2;
    }
    
    public void setDatasourceReference2(String datasourceReference2) {
        this.datasourceReference2 = datasourceReference2;
    }
	
	public static class FormatDetailStartIndisComparator implements Comparator<FormatDetail> {

		@Override
		public int compare(FormatDetail o1, FormatDetail o2) {
			return o1.getStartIndis().compareTo(o2.getStartIndis());
		}
		
	}

}
