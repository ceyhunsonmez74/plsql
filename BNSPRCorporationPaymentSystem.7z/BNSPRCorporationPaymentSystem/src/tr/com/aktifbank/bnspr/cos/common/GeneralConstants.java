package tr.com.aktifbank.bnspr.cos.common;


public final class GeneralConstants {
	public static final String DataAccessSessionName = "BNSPRDal";
	public static final String BatchSubmitIdSequenceKey = "BATCH_SUBMIT_ID";
	public static final String FTM_CONNECTION_NAME = "FTM";
	public static final String AktifBankCode = "143";
	public static final String CsvExtension = "csv";
	
	public static final short LOADING_CONFIRMATION = 0;
	public static final short PAYMENTS_CONFIRMATION = 1;
	public static final short EOD_PAYMENTS_CONFIRMATION = 2;
	
	public static final String APPROVALTRANSFER = "7210_APPROVAL_TRANSFER";
	public static final String FAILEDPAYMENTTRANSFER = "FAILED_PAYMENT_TRANSFER";
	
	public static final String AFTER_APP_UPDATE_COMMAND = "A";
	public static final String FAILED_UPDATE_COMMAND = "F";
}
