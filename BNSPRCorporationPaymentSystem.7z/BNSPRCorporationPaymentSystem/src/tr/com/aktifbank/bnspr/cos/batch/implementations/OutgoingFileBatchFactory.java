package tr.com.aktifbank.bnspr.cos.batch.implementations;

import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.dto.OutgoingFileBatchInformation;

public class OutgoingFileBatchFactory {

	private static final OutgoingFileBatchFactory instance = new OutgoingFileBatchFactory();
	
	public static OutgoingFileBatchFactory getInstance(){
		return instance;
	}
	
	private OutgoingFileBatchFactory() {
		
	}
	
	public OutgoingFileBatch createBatch(short factoryCommand, OutgoingFileBatchInformation information){
		if(factoryCommand == GeneralConstants.LOADING_CONFIRMATION){
			information.setFactoryCommand(GeneralConstants.LOADING_CONFIRMATION);
			return new CreateLoadingConfirmationFileBatch(information);
		}
		else if(factoryCommand == GeneralConstants.PAYMENTS_CONFIRMATION){
			information.setFactoryCommand(GeneralConstants.PAYMENTS_CONFIRMATION);
			return new CreatePaymentsConfirmationFileBatch(information);
		}
		else if(factoryCommand == GeneralConstants.EOD_PAYMENTS_CONFIRMATION){
			information.setFactoryCommand(GeneralConstants.EOD_PAYMENTS_CONFIRMATION);
			return new CreateEodPaymentsConfirmationFileBatch(information);
		}
		else{
			return null;
		}
	}

}
