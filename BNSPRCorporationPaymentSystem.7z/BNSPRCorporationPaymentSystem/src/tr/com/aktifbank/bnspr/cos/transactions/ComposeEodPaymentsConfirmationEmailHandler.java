package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;
import org.apache.commons.lang.StringUtils;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CorporationDef;

import com.graymound.util.GMMap;

public class ComposeEodPaymentsConfirmationEmailHandler extends RequestHandler {

	public ComposeEodPaymentsConfirmationEmailHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		Date processDate = new Date();
		String processDateStr = CommonHelper.getLongDateTimeString(processDate);
		String processTime = processDateStr.substring(8, 12);
		String eodEmailTime = null;
		GMMap getCorpDefinitionMap = null;
		GMMap eodPaymentConfirmation = null;
		
		List<CorporationDef> corpList = super.getHibernateSession().createCriteria(CorporationDef.class)
										.add(Restrictions.eq("status", true))								
										.add(Restrictions.eq("activeness", true)).list();
								
		for (CorporationDef corp : corpList) {
			getCorpDefinitionMap = new GMMap();
			getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corp.getCorporateCode());
			GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
			eodEmailTime = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.EOD_EMAIL_TIME);
			
			if (StringUtils.isNotEmpty(eodEmailTime) && eodEmailTime.equals(processTime)) {
				eodPaymentConfirmation = new GMMap();
				eodPaymentConfirmation.put(TransactionConstants.CreateEodPaymentsConfirmationStarter.Input.CORPORATE_CODE, corp.getCorporateCode());
				super.callGraymoundServiceAsync(TransactionConstants.CreateEodPaymentsConfirmationStarter.SERVICE_NAME, eodPaymentConfirmation);
			}
		}
	}
}
