package tr.com.aktifbank.bnspr.cos.util;

import java.util.Map;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class CorporationServiceUtil {	
	public static String getSequenceCode(String  tableName) throws Exception{		
		try{
			GMMap iMap = new GMMap();
			iMap.put("TABLE_NAME", tableName);
			Map<?,?> oMap  =   GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap);
			return oMap.get("ID").toString();
		}catch(Exception ex){
			ex.printStackTrace();
			throw ex;
		}			
	} 
	
	public static GMMap getComboValues(GMMap iMap){		
		GMMap oMap = new GMMap();
		try{
			 oMap  =  (GMMap) GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap);	
		}catch(Exception ex){
			ex.printStackTrace();
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}	
}