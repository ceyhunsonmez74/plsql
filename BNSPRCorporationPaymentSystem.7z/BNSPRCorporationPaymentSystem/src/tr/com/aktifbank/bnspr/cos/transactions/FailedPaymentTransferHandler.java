package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.Date;

import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;

import com.graymound.util.GMMap;

public class FailedPaymentTransferHandler extends RequestHandler {

	public FailedPaymentTransferHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		Date processDate = new Date();
		
		GMMap transferRequestMap = new GMMap();
		transferRequestMap.put(TransactionConstants.OrderTransfersApproved.Input.TRANSFER_TYPE, GeneralConstants.FAILEDPAYMENTTRANSFER);
		transferRequestMap.put(TransactionConstants.OrderTransfersApproved.Input.PROCESS_DATE, processDate);
		super.callGraymoundServiceOutsideSession(TransactionConstants.OrderTransfersApproved.SERVICE_NAME, transferRequestMap);
		
		CommonBusinessOperations.sendDuplicatePaymentEmail(processDate);
	}

}
