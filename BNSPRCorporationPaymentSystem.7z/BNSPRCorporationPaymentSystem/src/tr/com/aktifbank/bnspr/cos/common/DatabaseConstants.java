package tr.com.aktifbank.bnspr.cos.common;

public interface DatabaseConstants {
	public static final class SubmitStatuses{
		public static final String START = "00";
		public static final String EXECUTING = "11";
		public static final String FAILURE = "88";
		public static final String SUCESSFUL = "99";
	}
	
	public static final class LoadingStatuses{
		public static final String START = "00";
		public static final String EXECUTING = "11";
		public static final String FAILURE = "88";
		public static final String SUCESSFUL = "99";
	}

	public static final class FileStatuses{
		public static final String CONTROLSFAILED = "48";
		public static final String CONTROLSSUCCESSFUL = "49";		
		public static final String SOMEOFTHELINESFAILED = "98";
		
		public static final String CONTROLSFAILED_REPEATEDFILE = "50";
		public static final String CONTROLSSUCCESSFUL_REPEATEDFILE = "51";		
		public static final String SOMEOFTHELINESFAILED_REPEATEDFILE = "52";
		
		public static final String SOMEPAYMENTSFAILED = "97";		
		public static final String PAYMENTSSUCCESSFUL = "99";
		public static final String LOADINGROLLBACK = "-1";
		public static final String LOADINGFAILURE = "88";
	}
	
	public static final class TransactionStatus{
		public static final String NOT_APPROVED = "00";
		public static final String APPROVED = "50";
		public static final String PROCESSING_STARTED = "98";
		public static final String PROCESSING_FINISHED = "99";
	}
	
	public static final class ErrorTypes{
		public static final String NOERROR = "NO_ERROR";
		public static final String LOADINGERROR = "LOADING_ERROR";
		public static final String CONTROLORTRANSFERERROR = "CONTROL_OR_TRANSFER_ERROR";
	}
	
	public static final class OrderLineTypes{
		public static final String CONTROLSFAILED = "48";
		public static final String CONTROLSSUCCESSFUL = "49";
		public static final String WAITINGAPPROVAL = "50";
		public static final String TRANSFERFAILED = "98";
		public static final String TRANSFERSUCCESSFUL = "99";
	}	
	
	public static final class ControlTypes{
		public static final String LOADING = "LOADING";
		public static final String PAYMENT = "PAYMENT";
	}
	
	public static final class EmailType {
		public static final String LOADINGFAILURE = "LOADING_FAILURE";
		public static final String LOADINGCONFIRMATION = "LOADING_CONFIRMATION";
		public static final String PAYMENTSCONFIRMATION = "PAYMENTS_CONFIRMATION";		
		public static final String EODPAYMENTSCONFIRMATION = "EOD_PAYMENTS_CONFIRMATION";
		public static final String RECIPIENTINFORMATION = "RECIPIENT_INFORMATION";		
	}

	public static final class ConfirmationFileTypeConstants{
		public static final String LOADING = "ODT";
		public static final String PAYMENT = "ODA";
	}
	
	public static final class EodFileType{
		public static final String CUMULATIVE = "C";
		public static final String SEPARATE = "S";
	}

	public static final class OutgoingFileType{
		public static final String LOADING = "LOADING";
		public static final String PAYMENT = "PAYMENT";
		public static final String EOD = "EOD";
	}
	
	public static final class OrderStatuses {
		public static final String RecipientBankCodeError = "01";
		public static final String RecipientBranchCodeError = "02";
		public static final String RecipientAccountNoError = "03";		
		public static final String IBANError = "04";
		public static final String IBANMissing = "05";
		public static final String CurrencyMismatch = "06";
		public static final String RecipientNotDefined = "07";
		public static final String CannotTransferForeignCurrency = "08";
		public static final String RecipientAccountClosedToAssetTransfer = "09";
		public static final String SourceAccountBlocked = "10";
		public static final String AccountTCKNorVKNMismatch = "11";
		public static final String RecipientNameMissing = "12";
		public static final String OrderTypeCannotBeDefined = "13";		
		public static final String UsageAccountNotDefined = "14";
		public static final String CommissionAccountNotDefined = "15";
		public static final String ControlError = "16";
		public static final String AmountCannotBeZero = "17";
		public static final String HeaderDateError = "18";
		public static final String CurrencyError = "19";
		public static final String RecipientIsDepositAccount = "20";
		public static final String SourceIsDepositAccount = "21";
		public static final String RecipientAccountClosed = "22";
		public static final String SourceAccountClosed = "23";
		public static final String SourceAccountClosedToLiabilityTransfer = "26";
		public static final String TCKNMissingForPTTTransfer = "27";
		public static final String RecipientDateOfBirthMissingForPTTTransfer = "28";
		public static final String RecipientFatherMotherNameMissingForPTTTransfer = "29";
		public static final String RecipientPhoneNumberMissingForPTTTransfer = "30";
		public static final String Waiting = "49";
		public static final String RepeatedOrder = "50";
		public static final String WaitingApproval = "51";
		public static final String Approved = "52";
		public static final String AfterApprovalProcessStarted = "53";
		public static final String NotValidEftTime = "54";
		public static final String InsufficientBalance = "60";	
		public static final String RecipientIsDepositAccount_Payment = "61";
		public static final String SourceIsDepositAccount_Payment = "62";
		public static final String RecipientAccountClosed_Payment = "63";
		public static final String SourceAccountClosed_Payment = "64";
		public static final String RecipientAccountClosedToAssetTransfer_Payment = "65";
		public static final String SourceAccountBlocked_Payment = "66";
		public static final String PaymentError = "67";
		public static final String SourceAccountClosedToLiabilityTransfer_Payment = "68";
		public static final String ForwardPayment = "69";
		public static final String Eod = "70";
		public static final String Transfered = "99";
		public static final String ReadyToTransfer = "100";
	}	
	
	public static final class OrderType{
		public static final String EFT = "1";
		public static final String Havale = "2";
		public static final String Virman = "3";
		public static final String PTTIsmeHavale = "4";
	}

	public static final class OrderTypePlainText{
		public static final String EFT = "eft";
		public static final String Havale = "havale";
		public static final String Virman = "virman";
		public static final String PTTIsmeHavale = "ptt isme havale";
	}
	
	public static final class EftType{
		public static final String EFT_1 = "1";
		public static final String EFT_2 = "2";
	}
	
	public static final class OrderAccountType{
		public static final String UsageAccount = "KH";
		public static final String CommissionAccount = "MH";
	}
	
	public static final class TransferStatuses{
		public static final byte SUBMITTED = 10;
		public static final byte SUBMITFAILURE = 20;
	}
	
	public static final class CurrencyCodes{
		public static final String TRY = "TRY";
		public static final String USD = "USD";
		public static final String EUR = "EUR";
	}
	
	public static final class TransferTypes{
		public static final short OrderLoading = 1;
		public static final short LoadingConfirmation = 2;
		public static final short PaymentsConfirmation = 3;
		public static final short EODPaymentsConfirmation = 4;
	}
	
	public static final class FtmState{
		public static final short Passive = 0;
		public static final short Active = 1;
	}
	
	public static final class CustomerType{
		public static final String Bank = "B";
		public static final String Person = "G";
		public static final String Corporation = "T";
		public static final String Broken = "A";
		public static final String JointAccount = "O";
	}
	
	public static final class LineType{
		public static final String Header = "H";
		public static final String Detail = "D";
		public static final String Footer = "F";
	}
	
	public static final class FieldType{
		public static final String Date = "D";
		public static final String Numeric = "N";
		public static final String AlphaNumeric = "A";
		public static final String Constant = "C";
		public static final String Amount = "T";
		public static final String Time = "S";
	}
	
	public static final class DataSourceTypes {
		public static final String Database = "D";
		public static final String Service = "S";
		public static final String DatabaseAndService = "B";
	}
	
	public static final class Alignments {
		public static final String Left = "L";
		public static final String Right = "R";
	}
	
	public static final class HeaderIndicators{
		public static final String ORDER_DATE = "ORDER_DATE";
		public static final String CUSTOMER_NO = "CUSTOMER_NO";
		public static final String CUSTOMER_BANK = "CUSTOMER_BANK";
		public static final String CUSTOMER_BRANCH = "CUSTOMER_BRANCH";
		public static final String CUSTOMER_ACCOUNT_NO = "CUSTOMER_ACCOUNT_NO";
	}
	
	public static final class DetailIndicators{
		public static final String CURRENCY_CODE = "CURRENCY_CODE";
		public static final String AMOUNT = "AMOUNT";
		public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
	}
	
	public static final class FooterIndicators{
		public static final String TOTAL_TRY_AMOUNT = "TOTAL_TRY_AMOUNT";
		public static final String TOTAL_USD_AMOUNT = "TOTAL_USD_AMOUNT";
		public static final String TOTAL_EUR_AMOUNT = "TOTAL_EUR_AMOUNT";
		public static final String TOTAL_TRY_RECORD_COUNT = "TOTAL_TRY_RECORD_COUNT";
		public static final String TOTAL_USD_RECORD_COUNT = "TOTAL_USD_RECORD_COUNT";
		public static final String TOTAL_EUR_RECORD_COUNT = "TOTAL_EUR_RECORD_COUNT";
	}
}
