package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public abstract class RequestHandler {
	
	protected static final Log logger = LogFactory.getLog(RequestHandler.class);
	
	private Session hibernateSession;
	
	private boolean hibernateSessionCreated;
	
	protected Map<Object, Object> bag;
	
	public RequestHandler(){
		bag = new HashMap<Object, Object>();
	}
	
	protected boolean isHibernateSessionCreated(){
		return this.hibernateSessionCreated;
	}
	
	protected Session getHibernateSession(){
		if(this.hibernateSession == null){
			this.hibernateSession = CommonHelper.getHibernateSession();
			this.hibernateSessionCreated = true;
		}
		
		return this.hibernateSession;
	}
	
	public GMMap handle(GMMap input){
		GMMap output = new GMMap();
		try{
			handleInternal(input, output);
		}
		catch(BatchComponentException e){
			handleBusinessError(e, output);
		}
		catch (Throwable e) {
			handleError(e, output);
		}
		finally{
			handleFinally(output);
		}
		
		return output;
	}

	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		logger.error(String.format("An exception occured while executing handler : %s", this.getClass().getName()), e);
		if(e.getCode() == BusinessException.UNDEFINED.getCode() || e.getCode() == BusinessException.SYSTEM.getCode()
				|| e.getCode() == BusinessException.FILEHASHMISMATCH.getCode()){
			handleError(e, output);
		}
		else{
			GMMap errorMap = new GMMap();
			errorMap.put("HATA_NO", e.getCode());
			if(e.getParameters() != null && e.getParameters().size() != 0){
				int currentCount = 1;
				for(Object parameter : e.getParameters()){
					errorMap.put(String.format("P%s", currentCount++), parameter);
				}
			}
			this.callGraymoundServiceInSession("BNSPR_COMMON_HATA_YAZ", errorMap);
		}
	}

	protected void handleFinally(GMMap output) {
		
	}

	protected void handleError(Throwable e, GMMap output) {
		throw ExceptionHandler.convertException(e);
	}
	
	protected abstract void handleInternal(GMMap input, GMMap output) throws Throwable;
	
	protected GMMap callGraymoundServiceInSession(String serviceName, GMMap input){
		return CommonBusinessOperations.callGraymoundService(input, serviceName, true);
	}
	
	protected GMMap callGraymoundServiceOutsideSession(String serviceName, GMMap input){
		return CommonHelper.callGraymoundServiceOutsideSession(serviceName, input);
	}
	
	protected GMMap callServiceWithParams(String serviceName, Object... input){
		return callServiceWithSessionOption(serviceName, true, input);
	}
	
	protected GMMap callServiceWithSessionOption(String serviceName, boolean inSession, Object... input){
		return callServiceWithSessionAndAsyncOptions(serviceName, inSession, false, input);
	}
	
	protected GMMap callServiceWithSessionAndAsyncOptions(String serviceName, boolean inSession, boolean async, Object... input){
		GMMap inputMap = new GMMap();
		if(input != null && input.length != 0){
			for(int i = 0; i < input.length; i+=2){
				inputMap.put(input[i], input[i+1]);
			}
		}
		
		if (inSession) {
			return this.callGraymoundServiceInSession(serviceName, inputMap);
		}
		else{
			if(async){
				this.callGraymoundServiceAsync(serviceName, inputMap);
				return null;
			}
			else{
				return this.callGraymoundServiceOutsideSession(serviceName, inputMap);
			}
		}
	}
	
	protected void callGraymoundServiceAsync(String serviceName, GMMap input){
		GMServiceExecuter.executeAsync(serviceName, input);
	}
}
