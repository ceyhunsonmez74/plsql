package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;

import com.graymound.util.GMMap;

public class UpdateOrderFileLogHandler extends RequestHandler {

	public UpdateOrderFileLogHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
				
		String oid = input.getString(TransactionConstants.UpdateOrderFileLog.Input.OID);
		String batchSubmitId = input.getString(TransactionConstants.UpdateOrderFileLog.Input.SUBMIT_ID);
		BigDecimal totalDetailLineCount = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.TOTAL_DETAIL_LINE_COUNT);
		BigDecimal erroneousLineCount = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.ERRONEOUS_LINE_COUNT);
		String loadingStatus = input.getString(TransactionConstants.UpdateOrderFileLog.Input.LOADING_STATUS);
		String errorCode = input.getString(TransactionConstants.UpdateOrderFileLog.Input.ERROR_CODE);
		String errorMessage = input.getString(TransactionConstants.UpdateOrderFileLog.Input.ERROR_MESSAGE);
		BigDecimal tryAmount = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.TRY_AMOUNT);
		BigDecimal usdAmount = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.USD_AMOUNT);
		BigDecimal eurAmount = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.EUR_AMOUNT);
		BigDecimal tryLineCount = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.TRY_LINE_COUNT);
		BigDecimal udsLineCount = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.USD_LINE_COUNT);
		BigDecimal eurLineCount = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.EUR_LINE_COUNT);
		String orderDate = input.getString(TransactionConstants.UpdateOrderFileLog.Input.ORDER_DATE);
		BigDecimal customerNo = input.getBigDecimal(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_NO);
		String customerBank = input.getString(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_BANK);
		String customerBranch = input.getString(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_BRANCH);
		String customerAccountNo = input.getString(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_ACCOUNT_NO);
		String fileLoadingDate = null;
				
		OrderFileLog incomingOrderFile = (OrderFileLog) super.getHibernateSession().createCriteria(OrderFileLog.class)
														.add(Restrictions.eq("oid", oid)).uniqueResult();
		if (incomingOrderFile != null) {			
			fileLoadingDate = incomingOrderFile.getLogDate(); 
			
			incomingOrderFile.setBatchSubmitId(batchSubmitId);
			incomingOrderFile.setTotalLineCount(totalDetailLineCount);
			incomingOrderFile.setErroneousLineCount(erroneousLineCount);
			incomingOrderFile.setLoadingStatus(loadingStatus);
			incomingOrderFile.setTryAmount(tryAmount);
			incomingOrderFile.setUsdAmount(usdAmount);
			incomingOrderFile.setEurAmount(eurAmount);
			incomingOrderFile.setTryLineCount(tryLineCount);
			incomingOrderFile.setUsdLineCount(udsLineCount);
			incomingOrderFile.setEurLineCount(eurLineCount);
			incomingOrderFile.setOrderDate(orderDate);
			incomingOrderFile.setCustomerNo(customerNo);
			incomingOrderFile.setCustomerBank(customerBank);
			incomingOrderFile.setCustomerBranch(customerBranch);
			incomingOrderFile.setCustomerAccountNo(customerAccountNo);
			incomingOrderFile.setErrorCode(errorCode);
			incomingOrderFile.setErrorDesc(errorMessage);
					
			super.getHibernateSession().update(incomingOrderFile);				
		}
		output.put(TransactionConstants.UpdateOrderFileLog.Output.FILE_LOADING_DATE, fileLoadingDate);
		output.put("FILE_STATUS", incomingOrderFile.getFileStatus());		
		super.getHibernateSession().flush();
	}

}
