package tr.com.aktifbank.bnspr.cos.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import com.graymound.util.GMMap;

public final class OutgoingFileBatchInformation extends BaseTransferObject {

	public OutgoingFileBatchInformation() {
		super();
	}

	String corporateCode;
	List<FormatDetail> headerDetails;
	List<FormatDetail> bodyDetails;
	List<FormatDetail> footerDetails;	
	Date processDate;
	BigDecimal ftmProcessId;
	GMMap databaseFields;
	GMMap serviceFields;	
	GMMap outgoingFileBatchInput;
	Session hibernateSession;
	int lineNumber;
	String loadingBatchSubmitId;
	BigDecimal loadingFtmSequenceNumber;
	int afterProcessLineNumber;
	Short factoryCommand;
	
	public int getAfterProcessLineNumber() {
		return afterProcessLineNumber;
	}
	public void setAfterProcessLineNumber(int afterProcessLineNumber) {
		this.afterProcessLineNumber = afterProcessLineNumber;
	}
	public int getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}
	public Session getHibernateSession() {
		return hibernateSession;
	}
	public void setHibernateSession(Session hibernateSession) {
		this.hibernateSession = hibernateSession;
	}
	public String getCorporateCode() {
		return corporateCode;
	}
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	public Date getProcessDate() {
		return processDate;
	}
	public void setProcessDate(Date invoiceDate) {
		this.processDate = invoiceDate;
	}
	public BigDecimal getFtmProcessId() {
		return ftmProcessId;
	}
	public void setFtmProcessId(BigDecimal ftmProcessId) {
		this.ftmProcessId = ftmProcessId;
	}
	public GMMap getOutgoingFileBatchInput() {
		return outgoingFileBatchInput;
	}
	public void setOutgoingFileBatchInput(GMMap outgoingFileBatchInput) {
		this.outgoingFileBatchInput = outgoingFileBatchInput;
	}
	public String getLoadingBatchSubmitId() {
		return loadingBatchSubmitId;
	}
	public void setLoadingBatchSubmitId(String loadingBatchSubmitId) {
		this.loadingBatchSubmitId = loadingBatchSubmitId;
	}
	public BigDecimal getLoadingFtmSequenceNumber() {
		return loadingFtmSequenceNumber;
	}
	public void setLoadingFtmSequenceNumber(BigDecimal loadingFtmSequenceNumber) {
		this.loadingFtmSequenceNumber = loadingFtmSequenceNumber;
	}
	public Short getFactoryCommand() {
		return factoryCommand;
	}
	public void setFactoryCommand(Short factoryCommand) {
		this.factoryCommand = factoryCommand;
	}
	public List<FormatDetail> getHeaderDetails() {
		return headerDetails;
	}
	public void setHeaderDetails(List<FormatDetail> headerDetails) {
		this.headerDetails = headerDetails;
	}
	public List<FormatDetail> getBodyDetails() {
		return bodyDetails;
	}
	public void setBodyDetails(List<FormatDetail> bodyDetails) {
		this.bodyDetails = bodyDetails;
	}
	public List<FormatDetail> getFooterDetails() {
		return footerDetails;
	}
	public void setFooterDetails(List<FormatDetail> footerDetails) {
		this.footerDetails = footerDetails;
	}
	public GMMap getDatabaseFields() {
		return databaseFields;
	}
	public void setDatabaseFields(GMMap databaseFields) {
		this.databaseFields = databaseFields;
	}
	public GMMap getServiceFields() {
		return serviceFields;
	}
	public void setServiceFields(GMMap serviceFields) {
		this.serviceFields = serviceFields;
	}	
}
