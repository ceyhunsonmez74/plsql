package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.Date;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OutgoingFileLog;

import com.graymound.util.GMMap;

public class UpdateOutgoingFileStatusHandler extends RequestHandler {

	public UpdateOutgoingFileStatusHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		String oid = input.getString(TransactionConstants.UpdateOutgoingFileStatus.Input.OUTGOING_FILE_OID);
		String fileType = input.getString(TransactionConstants.UpdateOutgoingFileStatus.Input.FILE_TYPE);
		Boolean setStatusFalse = input.getBoolean(TransactionConstants.UpdateOutgoingFileStatus.Input.SET_STATUS_FALSE);		
		
		if (setStatusFalse != null && setStatusFalse) {
			String query = "UPDATE COS.OUTGOING_FILE_LOG SET STATUS = 0, UPDATE_DATE = NULL WHERE STATUS = 1 AND FILE_TYPE = '%s'";			
			CommonHelper.getHibernateSession().createSQLQuery(String.format(query, fileType)).executeUpdate();			
		} else {		
			OutgoingFileLog outgoingFile = (OutgoingFileLog) super.getHibernateSession().createCriteria(OutgoingFileLog.class)
														   .add(Restrictions.eq("oid", oid)).uniqueResult();
			if (outgoingFile != null) {
				outgoingFile.setUpdateDate(CommonHelper.getLongDateTimeString(new Date()));;
				super.getHibernateSession().update(outgoingFile);
			}
			super.getHibernateSession().flush();
		}
	}
}
