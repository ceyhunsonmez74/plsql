package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.ObjectMapper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.dao.OrderFileDbField;

import com.graymound.util.GMMap;

public final class GetOrderDatabaseFieldsHandler extends RequestHandler {

	public GetOrderDatabaseFieldsHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		Criteria criteria = super.getHibernateSession().createCriteria(OrderFileDbField.class);
		if(!input.getBoolean(TransactionConstants.GetOrderDatabaseFields.Input.GET_ALL_FIELDS, false)){
			criteria = criteria.add(Restrictions.eq("status", true));
		}
		@SuppressWarnings("unchecked")
		List<OrderFileDbField> dbFieldList = criteria.list();
		List<ItemDatabaseField> fields = new ArrayList<ItemDatabaseField>();
		for(OrderFileDbField field : dbFieldList){
			ObjectMapper<ItemDatabaseField> mapper = new ObjectMapper<ItemDatabaseField>(ItemDatabaseField.class);
			ItemDatabaseField dtoField = mapper.map(field);
			fields.add(dtoField);
		}
		output.put(TransactionConstants.GetOrderDatabaseFields.Output.FIELDS, fields);
	}

}
