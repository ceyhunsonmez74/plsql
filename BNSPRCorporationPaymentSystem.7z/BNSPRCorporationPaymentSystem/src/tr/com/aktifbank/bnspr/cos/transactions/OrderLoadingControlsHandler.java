package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.aktifbank.bnspr.dao.OrderMain;

import com.graymound.util.GMMap;

public class OrderLoadingControlsHandler extends RequestHandler {

	public OrderLoadingControlsHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		String batchSubmitId = input.getString(TransactionConstants.OrderLoadingControls.Input.BATCH_SUBMIT_ID);		
		BigDecimal ftmSequenceNumber = input.getBigDecimal(TransactionConstants.OrderLoadingControls.Input.FTM_SEQUENCE_NUMBER);
		String fileLogOid = input.getString(TransactionConstants.OrderLoadingControls.Input.ORDER_FILE_LOG_OID);
		String headerOrderDate = input.getString(TransactionConstants.OrderLoadingControls.Input.HEADER_ORDER_DATE);
		String headerCustomerAccountNo = input.getString(TransactionConstants.OrderLoadingControls.Input.HEADER_CUSTOMER_ACCOUNT_NO);
		boolean allowTransferToValid = input.getBoolean(TransactionConstants.OrderLoadingControls.Input.ALLOW_TRANSFER_TO_VALID);
		boolean visibleToApprover = true;
				
		String fileStatus = null;
		boolean allControlsFailed = true;
		boolean someControlsFailed = false;
		
		List<OrderMain> orderList = super.getHibernateSession().createCriteria(OrderMain.class)
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("ftmSequenceNumber", ftmSequenceNumber))
									.add(Restrictions.eq("batchSubmitId", batchSubmitId))
									.addOrder(Order.asc("lineNumber")).list();
		for (OrderMain order : orderList) {
			GMMap doControlsRequest = new GMMap();
			doControlsRequest.put(TransactionConstants.DoLoadingAndPaymentControls.Input.CONTROL_TYPE, DatabaseConstants.ControlTypes.LOADING);
			doControlsRequest.put(TransactionConstants.DoLoadingAndPaymentControls.Input.CONTROL_OBJECT, order);
			doControlsRequest.put(TransactionConstants.DoLoadingAndPaymentControls.Input.HEADER_CUSTOMER_ACCOUNT_NO, headerCustomerAccountNo);				
			GMMap doControlsResponse = super.callGraymoundServiceInSession(TransactionConstants.DoLoadingAndPaymentControls.SERVICE_NAME, doControlsRequest);
			
			if (doControlsResponse.getBoolean(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_EXCEPTION))
				order.setErrorDesc(doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ERROR_DESC));
			order.setOrderStatus(doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS));
			order.setOrderType(doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_TYPE));
			order.setPaymentAccountNo(doControlsResponse.getBigDecimal(TransactionConstants.DoLoadingAndPaymentControls.Output.PAYMENT_ACCOUNT));
			order.setPaymentCommissionAccountNo(doControlsResponse.getBigDecimal(TransactionConstants.DoLoadingAndPaymentControls.Output.COMMISSION_ACCOUNT));
			order.setOrderDate(headerOrderDate);
			
			super.getHibernateSession().update(order);
			
			if (!order.getOrderStatus().equals(DatabaseConstants.OrderStatuses.Waiting))
				someControlsFailed = true;
			else
				allControlsFailed = false;					
		}
		
		if (allControlsFailed)	
			fileStatus = DatabaseConstants.FileStatuses.CONTROLSFAILED;
		else if (someControlsFailed)
			fileStatus = DatabaseConstants.FileStatuses.SOMEOFTHELINESFAILED;
		else
			fileStatus = DatabaseConstants.FileStatuses.CONTROLSSUCCESSFUL;
		
		OrderFileLog incomingOrderFile = (OrderFileLog) super.getHibernateSession().createCriteria(OrderFileLog.class)
										.add(Restrictions.eq("oid", fileLogOid)).uniqueResult();
		if (incomingOrderFile != null) {

			if (fileStatus.equals(DatabaseConstants.FileStatuses.CONTROLSFAILED))
				visibleToApprover = false;					
			
			if (!allowTransferToValid && fileStatus.equals(DatabaseConstants.FileStatuses.SOMEOFTHELINESFAILED))
				visibleToApprover = false;					
			
			incomingOrderFile.setErroneousLineCount(new BigDecimal((Integer)CommonHelper.getFailedLineCountAtControls(batchSubmitId)));
			incomingOrderFile.setFileStatus(fileStatus);
			incomingOrderFile.setVisibleToApprover(visibleToApprover);
			super.getHibernateSession().update(incomingOrderFile);
		}
		output.put(TransactionConstants.OrderLoadingControls.Output.FILE_STATUS, fileStatus);
		super.getHibernateSession().flush();
	}
}
