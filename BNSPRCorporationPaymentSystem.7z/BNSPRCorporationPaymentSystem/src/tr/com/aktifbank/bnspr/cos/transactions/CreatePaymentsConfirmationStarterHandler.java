package tr.com.aktifbank.bnspr.cos.transactions;

import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;

import com.graymound.util.GMMap;

public class CreatePaymentsConfirmationStarterHandler extends RequestHandler {

	public CreatePaymentsConfirmationStarterHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		CommonBusinessOperations.executeBatchStarterHandler(input, output, DatabaseConstants.TransferTypes.PaymentsConfirmation, super.getHibernateSession());
	}

}
