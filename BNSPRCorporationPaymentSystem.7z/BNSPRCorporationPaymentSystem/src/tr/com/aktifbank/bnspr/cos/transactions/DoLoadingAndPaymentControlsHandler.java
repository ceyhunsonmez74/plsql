package tr.com.aktifbank.bnspr.cos.transactions;



import java.math.BigDecimal;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.axis.utils.StringUtils;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CorporationAccountDef;
import tr.com.aktifbank.bnspr.dao.CorporationDef;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.aktifbank.bnspr.dao.OrderTransferLog;
import tr.com.aktifbank.bnspr.dao.RecipientDef;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public final class DoLoadingAndPaymentControlsHandler extends RequestHandler {

	public DoLoadingAndPaymentControlsHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		String controlType = input.getString(TransactionConstants.DoLoadingAndPaymentControls.Input.CONTROL_TYPE);
		Object controlObject = input.get(TransactionConstants.DoLoadingAndPaymentControls.Input.CONTROL_OBJECT);
		String eftCutOff = (String) DALUtil.callNoParameterFunction("{? = call pkg_eft_saat.cutoff_gectimi}", Types.VARCHAR);
		GMMap loadingControlsResultMap = new GMMap();
		GMMap paymentControlsResultMap = new GMMap();		
		String orderStatus = null;
		String orderType = null;
		String errorMessage = null;
		BigDecimal paymentAccount = null, paymentCommissionAccount = null;
		boolean exceptionOccured = false;
		
		if (controlType.equals(DatabaseConstants.ControlTypes.LOADING)) {
			if (controlObject instanceof OrderMain) {
				OrderMain order = (OrderMain) controlObject;			
				
				String headerCustomerAccountNo = input.getString(TransactionConstants.DoLoadingAndPaymentControls.Input.HEADER_CUSTOMER_ACCOUNT_NO);
				
				loadingControlsResultMap = doLoadingControls(order, headerCustomerAccountNo);
				if (loadingControlsResultMap.getBoolean(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_SUCCESSFUL)) {
					orderType = loadingControlsResultMap.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_TYPE);
					orderStatus = loadingControlsResultMap.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS);
					paymentAccount = loadingControlsResultMap.getBigDecimal(TransactionConstants.DoLoadingAndPaymentControls.Output.PAYMENT_ACCOUNT);
					paymentCommissionAccount = loadingControlsResultMap.getBigDecimal(TransactionConstants.DoLoadingAndPaymentControls.Output.COMMISSION_ACCOUNT);
					
				} else {
					orderType = loadingControlsResultMap.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_TYPE);
					orderStatus = loadingControlsResultMap.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS);
					paymentAccount = loadingControlsResultMap.getBigDecimal(TransactionConstants.DoLoadingAndPaymentControls.Output.PAYMENT_ACCOUNT);
					paymentCommissionAccount = loadingControlsResultMap.getBigDecimal(TransactionConstants.DoLoadingAndPaymentControls.Output.COMMISSION_ACCOUNT);
					exceptionOccured = loadingControlsResultMap.getBoolean(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_EXCEPTION);
					errorMessage = loadingControlsResultMap.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ERROR_DESC);					
				}		
			}
		} 
		else if (controlType.equals(DatabaseConstants.ControlTypes.PAYMENT)) {
			if (controlObject instanceof OrderTransferLog) {				
				OrderTransferLog transferLog = (OrderTransferLog) controlObject;
				
				paymentControlsResultMap = doPaymentControls(transferLog, eftCutOff);	
				if (paymentControlsResultMap.getBoolean(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_SUCCESSFUL)) {
					orderStatus = paymentControlsResultMap.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS);					
				} else {
					orderStatus = paymentControlsResultMap.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS);
					exceptionOccured = paymentControlsResultMap.getBoolean(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_EXCEPTION);
					errorMessage = paymentControlsResultMap.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ERROR_DESC);	
				}				
			}			
		}
		output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_TYPE, orderType);	
		output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS, orderStatus);
		output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.PAYMENT_ACCOUNT, paymentAccount);
		output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.COMMISSION_ACCOUNT, paymentCommissionAccount);
		output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_EXCEPTION, exceptionOccured);		
		output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.ERROR_DESC, errorMessage);
	}
	
	
	@SuppressWarnings({ "unchecked", "finally" })
	private GMMap doLoadingControls(OrderMain order, String headerCustomerAccountNo) {
		GMMap output = new GMMap();
		String orderStatus = DatabaseConstants.OrderStatuses.Waiting;
		String orderType = null, errorMessage = null;
		boolean isSuccessful = true, exceptionOccured = false, isPaymentAccountDK = false;		
		BigDecimal paymentAccount = null;
		BigDecimal paymentCommissionAccount = null;
		
		try {
			BigDecimal amount = order.getAmount();
			String corporateCode = order.getCorporateCode();
			String accountNo = order.getAccountNo();
			String commissionAccountNo = order.getCommissionAccountNo();
			String currencyCode = order.getCurrencyCode();
			String recipientIban = order.getRecipientIban();
			String recipientAccountNo = order.getRecipientAccountNo();
			String recipientTckn = order.getRecipientTckn();
			String recipientVkn = order.getRecipientVkn();
			String recipientBranchCode = order.getRecipientBranch();
			String recipientBank = order.getRecipientBank();
			String recipientName = order.getRecipientName();
			String recipientDateOfBirth = order.getRecipientDateOfBirth();
			String recipientFatherName = order.getRecipientFatherName();
			String recipientMotherName = order.getRecipientMotherName();
			String recipientPhoneNumber = order.getRecipientPhoneNumber();
			String recipientAccountCurrency = null, paymentAccountCurrency = null;
			BigDecimal customerNo = new BigDecimal(order.getCustomerNo());
			BigDecimal recipientCustomerNo = null;
			BigDecimal recipientAccountNoFromIban = null;
			boolean recipientFromIban = false;
			
			GMMap getCorpDefinitionMap = new GMMap();
			getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
			GMMap corpDefDetailsMap = super.callGraymoundServiceInSession(TransactionConstants.GetOrderCorpDef.SERVICE_NAME, getCorpDefinitionMap);			
			
			//PTT �SME HAVALE M� ? 
			if (StringUtils.isEmpty(recipientBank) && StringUtils.isEmpty(recipientIban) && StringUtils.isEmpty(recipientAccountNo) && StringUtils.isEmpty(recipientBranchCode)) {
				orderType = DatabaseConstants.OrderType.PTTIsmeHavale;
				//ptt isme havale zorunlu alanlar�
				if (StringUtils.isEmpty(recipientTckn)) {
					orderStatus = DatabaseConstants.OrderStatuses.TCKNMissingForPTTTransfer;
					isSuccessful = false;
				}
				if (isSuccessful && StringUtils.isEmpty(recipientDateOfBirth)) {
					orderStatus = DatabaseConstants.OrderStatuses.RecipientDateOfBirthMissingForPTTTransfer;
					isSuccessful = false;
				}	
				if (isSuccessful && (StringUtils.isEmpty(recipientMotherName) && StringUtils.isEmpty(recipientFatherName))) {
					orderStatus = DatabaseConstants.OrderStatuses.RecipientFatherMotherNameMissingForPTTTransfer;
					isSuccessful = false;
				}	
				if (isSuccessful && StringUtils.isEmpty(recipientPhoneNumber)) {
					orderStatus = DatabaseConstants.OrderStatuses.RecipientPhoneNumberMissingForPTTTransfer;
					isSuccessful = false;
				}
				if (isSuccessful && StringUtils.isEmpty(recipientName)) {
					orderStatus = DatabaseConstants.OrderStatuses.RecipientNameMissing;
					isSuccessful = false;
				}			
				if (isSuccessful && ( StringUtils.isEmpty(currencyCode) || !isValidCurrency(currencyCode) ) ) {
					orderStatus = DatabaseConstants.OrderStatuses.CurrencyError;
					isSuccessful = false;
				}
				if (isSuccessful && (amount == null || (amount != null && (amount.compareTo(new BigDecimal(0)) == 0 || amount.compareTo(new BigDecimal(0)) < 0))) ) {
					orderStatus = DatabaseConstants.OrderStatuses.AmountCannotBeZero;
					isSuccessful = false;
				}	
			}
			
			// D��ER ��LEM T�RLER�
			if (orderType == null) {				
				if (isSuccessful && ( StringUtils.isEmpty(recipientBank) || !isValidBank(recipientBank) ) ) {
					orderStatus = DatabaseConstants.OrderStatuses.RecipientBankCodeError;
					isSuccessful = false;
				}
				
				if (isSuccessful && !recipientBank.equals(GeneralConstants.AktifBankCode)) {
					orderType = DatabaseConstants.OrderType.EFT;
					if (!StringUtils.isEmpty(recipientIban)) 
						recipientFromIban = true;								
					
				} else if (isSuccessful && recipientBank.equals(GeneralConstants.AktifBankCode)) {		
					
					if (!StringUtils.isEmpty(recipientIban)) {
						recipientFromIban = true;
						recipientCustomerNo = getCustomerNoFromIban(recipientIban);
						recipientAccountNoFromIban = getAccountNoFromIban(recipientIban);
						if (recipientAccountNoFromIban != null)
							recipientAccountNo = recipientAccountNoFromIban.toString();
						else {
							orderStatus = DatabaseConstants.OrderStatuses.IBANError;
							isSuccessful = false;						
						}
					}
					else if (!StringUtils.isEmpty(recipientAccountNo))
						recipientCustomerNo = getCustomerNoOfAccount(new BigDecimal(recipientAccountNo));
					
					if (isSuccessful && recipientCustomerNo != null) {
						if (customerNo.compareTo(recipientCustomerNo) == 0)
							orderType = DatabaseConstants.OrderType.Virman;
						else
							orderType = DatabaseConstants.OrderType.Havale;	
					} else if (isSuccessful) {
						orderStatus = DatabaseConstants.OrderStatuses.OrderTypeCannotBeDefined;
						isSuccessful = false;
					}
				}
				
				// zorunlu alanlar�n kontrol�
				if (isSuccessful && StringUtils.isEmpty(recipientName)) {
					orderStatus = DatabaseConstants.OrderStatuses.RecipientNameMissing;
					isSuccessful = false;
				}			
				if (isSuccessful && ( StringUtils.isEmpty(currencyCode) || !isValidCurrency(currencyCode) ) ) {
					orderStatus = DatabaseConstants.OrderStatuses.CurrencyError;
					isSuccessful = false;
				}
				if (isSuccessful && (amount == null || (amount != null && (amount.compareTo(new BigDecimal(0)) == 0 || amount.compareTo(new BigDecimal(0)) < 0))) ) {
					orderStatus = DatabaseConstants.OrderStatuses.AmountCannotBeZero;
					isSuccessful = false;
				}	
				if (isSuccessful) {
					if (orderType.equals(DatabaseConstants.OrderType.EFT)) {
						if (StringUtils.isEmpty(recipientIban) && ( StringUtils.isEmpty(recipientAccountNo) || StringUtils.isEmpty(recipientBranchCode) ) ) {
							orderStatus = DatabaseConstants.OrderStatuses.IBANMissing;
							isSuccessful = false;
						}
					}	
				}
				
				if (isSuccessful && orderType.equals(DatabaseConstants.OrderType.EFT) && !currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
					orderStatus = DatabaseConstants.OrderStatuses.CannotTransferForeignCurrency;
					isSuccessful = false;					
				}					
				
				if (isSuccessful && recipientFromIban) {
					String dummy = null;
					Object[] inputValues = new Object[] {BnsprType.STRING, recipientIban};
					Object[] outputValues = new Object[] {BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY",BnsprType.STRING,"DUMMY"};
					try {
						GMMap procedureOutputMap = (GMMap) DALUtil.callOracleProcedure("{call BNSPR.PKG_EFT.EFT_IBAN_BANKA_SUBE_SEHIR_AL(?,?,?,?,?,?,?)}", inputValues, outputValues);	
						dummy = (String) procedureOutputMap.get("DUMMY");
					} catch (Exception e) {
						orderStatus = DatabaseConstants.OrderStatuses.IBANError;
						isSuccessful = false;
					}
				}
				
				// al�c� hesab�n durumu
				if (recipientBank.equals(GeneralConstants.AktifBankCode))
					if (isSuccessful && !StringUtils.isEmpty(recipientAccountNo)) {
						if (isSuccessful && !getModulTurKodOfAccount(new BigDecimal(recipientAccountNo)).equals("VADESIZ")) {
							orderStatus = DatabaseConstants.OrderStatuses.RecipientIsDepositAccount;
							isSuccessful = false;	
						}
						if (isSuccessful && ( StringUtils.isEmpty(getDurumKoduOfAccount(new BigDecimal(recipientAccountNo))) || !getDurumKoduOfAccount(new BigDecimal(recipientAccountNo)).equals("A") )) {
							orderStatus = DatabaseConstants.OrderStatuses.RecipientAccountClosed;
							isSuccessful = false;	
						}
						BigDecimal hesapHareketKodu = getHesapHareketKoduOfAccount(new BigDecimal(recipientAccountNo));
						if (isSuccessful && hesapHareketKodu != null && (hesapHareketKodu.compareTo(new BigDecimal(3)) == 0 ||  hesapHareketKodu.compareTo(new BigDecimal(4)) == 0)) {
							orderStatus = DatabaseConstants.OrderStatuses.RecipientAccountClosedToAssetTransfer;
							isSuccessful = false;	
						}					
					}

				// �ube, hesap no do�ru mu
				if (!recipientFromIban) {
					if (isSuccessful && ( !StringUtils.isEmpty(recipientBranchCode) && !isValidBranch(recipientBank, recipientBranchCode) ) ) {
						orderStatus = DatabaseConstants.OrderStatuses.RecipientBranchCodeError;
						isSuccessful = false;	
					}
					if (recipientBank.equals(GeneralConstants.AktifBankCode))
						if (isSuccessful && ( StringUtils.isEmpty(recipientAccountNo) || 
												( !StringUtils.isEmpty(recipientBranchCode) && !isValidAccountNo(recipientBranchCode, new BigDecimal(recipientAccountNo)) ) || 
												!isValidAccountNo(new BigDecimal(recipientAccountNo)) ) ) {
							orderStatus = DatabaseConstants.OrderStatuses.RecipientAccountNoError;
							isSuccessful = false;	
						}
				}
			}				
			
			// payment account'un belirlenmesi		
			if (!StringUtils.isEmpty(accountNo))
				paymentAccount = new BigDecimal(accountNo);
			else {
				if (!StringUtils.isEmpty(headerCustomerAccountNo))
					paymentAccount = new BigDecimal(headerCustomerAccountNo);
				else {
					BigDecimal defaultAccount = getDefaultAccount(corporateCode, DatabaseConstants.OrderAccountType.UsageAccount);
					if (defaultAccount.compareTo(new BigDecimal(-1)) == 0) {
						orderStatus = DatabaseConstants.OrderStatuses.UsageAccountNotDefined;
						isSuccessful = false;	
					}
					else 
						paymentAccount = defaultAccount;					
				}				
			}			
			
			// payment account DK hesap m� belirlenmesi
			if (paymentAccount != null) 
				isPaymentAccountDK = CommonHelper.isDKAccount(paymentAccount, corporateCode);
			
			// komisyon g�ndeme geldi�i zaman bu k�s�m a��lacak
			/* 
			// commission account'un belirlenmesi
			if (!StringUtils.isEmpty(commissionAccountNo))
				paymentCommissionAccount = new BigDecimal(commissionAccountNo);
			else {
				BigDecimal defaultAccount = getDefaultAccount(corporateCode, DatabaseConstants.OrderAccountType.CommissionAccount);
				if (defaultAccount.compareTo(new BigDecimal(-1)) == 0) {
					orderStatus = DatabaseConstants.OrderStatuses.CommissionAccountNotDefined;
					isSuccessful = false;	
				}
				else 
					paymentCommissionAccount = defaultAccount;					
			}		
			*/	
		
			// tan�ml� hesaplar�n aras�nda var m�
			if (isSuccessful && !StringUtils.isEmpty(accountNo) && paymentAccount.compareTo(new BigDecimal(accountNo)) == 0) {
				if (!isAccountDefined(new BigDecimal(accountNo), corporateCode, DatabaseConstants.OrderAccountType.UsageAccount)) {
					orderStatus = DatabaseConstants.OrderStatuses.UsageAccountNotDefined;
					isSuccessful = false;								
				}
			}
			if (isSuccessful && !StringUtils.isEmpty(commissionAccountNo) && !isAccountDefined(new BigDecimal(commissionAccountNo), corporateCode, DatabaseConstants.OrderAccountType.CommissionAccount)) {
				orderStatus = DatabaseConstants.OrderStatuses.CommissionAccountNotDefined;
				isSuccessful = false;								
			}
			
			// kaynak hesab�n durumu			
			if (paymentAccount != null && !isPaymentAccountDK) {
				if (isSuccessful && !getModulTurKodOfAccount(paymentAccount).equals("VADESIZ")) {
					orderStatus = DatabaseConstants.OrderStatuses.SourceIsDepositAccount;
					isSuccessful = false;	
				}
				if (isSuccessful && ( StringUtils.isEmpty(getDurumKoduOfAccount(paymentAccount)) || !getDurumKoduOfAccount(paymentAccount).equals("A") )) {
					orderStatus = DatabaseConstants.OrderStatuses.SourceAccountClosed;
					isSuccessful = false;	
				}
				BigDecimal hesapHareketKodu = getHesapHareketKoduOfAccount(paymentAccount);
				if (isSuccessful && hesapHareketKodu != null && (hesapHareketKodu.compareTo(new BigDecimal(2)) == 0 ||  hesapHareketKodu.compareTo(new BigDecimal(4)) == 0)) {
					orderStatus = DatabaseConstants.OrderStatuses.SourceAccountClosedToLiabilityTransfer;
					isSuccessful = false;	
				}
			}			
			
			if (!StringUtils.isEmpty(orderType) && !orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {
				// para birimi kontrolleri
				if (isSuccessful && paymentAccount != null && !isPaymentAccountDK)
					paymentAccountCurrency = getCurrencyOfAccount(paymentAccount);
				if (isSuccessful && !StringUtils.isEmpty(recipientAccountNo))
					recipientAccountCurrency = getCurrencyOfAccount(new BigDecimal(recipientAccountNo));			
				if (isSuccessful && !StringUtils.isEmpty(paymentAccountCurrency) && !isPaymentAccountDK)
					if (!paymentAccountCurrency.equals(currencyCode)) {
						orderStatus = DatabaseConstants.OrderStatuses.CurrencyError;
						isSuccessful = false;						
					}
				if (isSuccessful && !StringUtils.isEmpty(paymentAccountCurrency) && !isPaymentAccountDK && !StringUtils.isEmpty(recipientAccountCurrency))
					if (!paymentAccountCurrency.equals(recipientAccountCurrency)) {
						orderStatus = DatabaseConstants.OrderStatuses.CurrencyMismatch;
						isSuccessful = false;						
					}

				// banka m��terisi ise tckn vkn kontrol�
				if (isSuccessful && corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.CHECK_TCKN)) { 
					if (recipientBank.equals(GeneralConstants.AktifBankCode) && !StringUtils.isEmpty(recipientAccountNo)) {
						recipientCustomerNo = getCustomerNoOfAccount(new BigDecimal(recipientAccountNo));
						if (recipientCustomerNo != null) {
							String customerTckn = getTcknOfCustomer(recipientCustomerNo);
							String customerType = getCustomerType(recipientCustomerNo);
							if (customerType.equals(DatabaseConstants.CustomerType.Person) && !StringUtils.isEmpty(customerTckn) && !customerTckn.equals(recipientTckn)) {
								orderStatus = DatabaseConstants.OrderStatuses.AccountTCKNorVKNMismatch;
								isSuccessful = false;	
							}
						}
					}
				}
				if (isSuccessful && corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.CHECK_VKN)) { 
					if (recipientBank.equals(GeneralConstants.AktifBankCode) && !StringUtils.isEmpty(recipientAccountNo)) {
						recipientCustomerNo = getCustomerNoOfAccount(new BigDecimal(recipientAccountNo));
						if (recipientCustomerNo != null) {
							String customerVkn = getVknOfCustomer(recipientCustomerNo);
							String customerType = getCustomerType(recipientCustomerNo);
							if (customerType.equals(DatabaseConstants.CustomerType.Corporation) && !StringUtils.isEmpty(customerVkn) && !customerVkn.equals(recipientVkn)) {
								orderStatus = DatabaseConstants.OrderStatuses.AccountTCKNorVKNMismatch;
								isSuccessful = false;	
							}
						}
					}
				}
			}
			
			// tan�ml� al�c�lar kontrol�
			if (isSuccessful && corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.CHECK_RECIPIENTS) && orderType != null) {
				List<RecipientDef> recipientDefList = super.getHibernateSession().createCriteria(RecipientDef.class)
													   .add(Restrictions.eq("status", true))
													   .add(Restrictions.eq("corporateOid", corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.CORPORATE_OID)))
													   .add(Restrictions.eq("orderType", orderType)).list();	
				boolean validRecipient = false;
				for (RecipientDef recipientDef : recipientDefList) {
					if (validRecipient) 
						break;
					if (orderType.equals(DatabaseConstants.OrderType.EFT) ) {
						if (recipientFromIban) {
							if (recipientIban.equals(recipientDef.getRecipientIban()))
								validRecipient = true;							
						} else {
							if (recipientAccountNo.equals(recipientDef.getRecipientAccountNo()) && recipientBranchCode.equals(recipientDef.getRecipientBranch()) &&
									 															   recipientBank.equals(recipientDef.getRecipientBank()))
								validRecipient = true;							
						}	
					} else if (orderType.equals(DatabaseConstants.OrderType.Havale) || orderType.equals(DatabaseConstants.OrderType.Virman)) {
						if (recipientFromIban) {
							if (recipientIban.equals(recipientDef.getRecipientIban()))
								validRecipient = true;							
						} else {
							if (recipientAccountNo.equals(recipientDef.getRecipientAccountNo()) )
								validRecipient = true;							
						}																
					} else if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {
						if (recipientName.equals(recipientDef.getRecipientName()) && recipientTckn.equals(recipientDef.getRecipientTckn()))
							validRecipient = true;					
					}					
				}
				if (!validRecipient) {
					orderStatus = DatabaseConstants.OrderStatuses.RecipientNotDefined;
					isSuccessful = false;
				}
			}
			
		} catch (Throwable e) {
			logger.error(String.format("An exception occured while doing loading controls in DoLoadingAndPaymentControlsHandler for order id: %s", order.getOid()));
			logger.error(System.currentTimeMillis(), e);
			exceptionOccured = true;
			orderStatus = DatabaseConstants.OrderStatuses.ControlError;
			isSuccessful = false;
			errorMessage = CommonHelper.getStringifiedException(e);			
			if(errorMessage != null && errorMessage.length() > 1000){
				errorMessage = errorMessage.substring(0 ,950);
			}
		} finally {		
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_TYPE, orderType);
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS, orderStatus);	
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.PAYMENT_ACCOUNT, paymentAccount);	
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.COMMISSION_ACCOUNT, paymentCommissionAccount);	
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_SUCCESSFUL, isSuccessful);		
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_EXCEPTION, exceptionOccured);		
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.ERROR_DESC, errorMessage);
			return output;
		}
	}	
	
	@SuppressWarnings("finally")
	private GMMap doPaymentControls(OrderTransferLog orderLog, String eftCutOff) {
		GMMap output = new GMMap();
		String orderStatus = null, orderMainOrderStatus = null;
		String errorMessage = null;
		OrderMain order = null;
		boolean isSuccessful = true, exceptionOccured = false, isPaymentAccountDK = false;
		try {			
			order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("oid", orderLog.getOrderMainOid())).uniqueResult();
			if (order != null) {
				orderMainOrderStatus = order.getOrderStatus();
			}	
						
			if (!StringUtils.isEmpty(orderMainOrderStatus) &&  orderMainOrderStatus.equals(DatabaseConstants.OrderStatuses.Transfered)) {
				orderStatus = DatabaseConstants.OrderStatuses.Transfered;
			}
			else {	
				orderStatus = DatabaseConstants.OrderStatuses.ReadyToTransfer;
				String orderType = orderLog.getOrderType();
				BigDecimal amount = orderLog.getAmount();
				BigDecimal paymentAccount = orderLog.getPaymentAccountNo();
				String recipientAccountNo = orderLog.getRecipientAccountNo();
				String recipientBank = orderLog.getRecipientBank();			
				String recipientIban = orderLog.getRecipientIban();
				BigDecimal recipientAccountNoFromIban = null;		
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
				Date fileOrderDate = null, bankDate = null;
					
				// onay an�nda hen�z �deme tarihi gelmemi� i�lemler dikkate al�nmayacak, ileri vadeli i�lem stat�s�ne d��ecek
				bankDate = dateFormat.parse(CommonHelper.getShortDateTimeString(new Date()));
				if (!StringUtils.isEmpty(orderLog.getOrderDate()))
					fileOrderDate = dateFormat.parse(orderLog.getOrderDate());					
				if(fileOrderDate != null && fileOrderDate.compareTo(bankDate) > 0) {
					orderStatus = DatabaseConstants.OrderStatuses.ForwardPayment;
					isSuccessful = false;						
				}
				
				// eft cut off saati ge�tiyse eft saati ge�mi�tir hatas� verecek
				if (isSuccessful && !StringUtils.isEmpty(eftCutOff) && eftCutOff.equals("E") && orderType.equals(DatabaseConstants.OrderType.EFT)) {
					orderStatus = DatabaseConstants.OrderStatuses.NotValidEftTime;
					isSuccessful = false;								
				}
				
				// payment account DK hesap m� belirlenmesi
				if (paymentAccount != null) 
					isPaymentAccountDK = CommonHelper.isDKAccount(paymentAccount, orderLog.getCorporateCode());
				
				// bakiye kontrol�
				if (!isPaymentAccountDK) {
					BigDecimal availableBalance = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_hesap.Kullanilabilir_Bakiye_Al(?)}", Types.NUMERIC, paymentAccount);
					if (isSuccessful && amount.compareTo(availableBalance) > 0) {
						orderStatus = DatabaseConstants.OrderStatuses.InsufficientBalance;
						isSuccessful = false;						
					}
				}
				
				// kaynak hesab�n durumu			
				if (isSuccessful && paymentAccount != null && !isPaymentAccountDK) {
					if (isSuccessful && !getModulTurKodOfAccount(paymentAccount).equals("VADESIZ")) {
						orderStatus = DatabaseConstants.OrderStatuses.SourceIsDepositAccount_Payment;
						isSuccessful = false;	
					}
					if (isSuccessful && ( StringUtils.isEmpty(getDurumKoduOfAccount(paymentAccount)) || !getDurumKoduOfAccount(paymentAccount).equals("A") )) {
						orderStatus = DatabaseConstants.OrderStatuses.SourceAccountClosed_Payment;
						isSuccessful = false;	
					}
					BigDecimal hesapHareketKodu = getHesapHareketKoduOfAccount(paymentAccount);
					if (isSuccessful && hesapHareketKodu != null && (hesapHareketKodu.compareTo(new BigDecimal(2)) == 0 ||  hesapHareketKodu.compareTo(new BigDecimal(4)) == 0)) {
						orderStatus = DatabaseConstants.OrderStatuses.SourceAccountClosedToLiabilityTransfer_Payment;
						isSuccessful = false;	
					}		
				}
				
				if (isSuccessful && !StringUtils.isEmpty(orderType) && !orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {
					// al�c� hesab�n durumu
					if (recipientBank.equals(GeneralConstants.AktifBankCode)) {
						
						if (!StringUtils.isEmpty(recipientIban)) {
							recipientAccountNoFromIban = getAccountNoFromIban(recipientIban);
							if (recipientAccountNoFromIban != null)
								recipientAccountNo = recipientAccountNoFromIban.toString();
						}
						
						if (!StringUtils.isEmpty(recipientAccountNo)) {
							if (!getModulTurKodOfAccount(new BigDecimal(recipientAccountNo)).equals("VADESIZ")) {
								orderStatus = DatabaseConstants.OrderStatuses.RecipientIsDepositAccount_Payment;
								isSuccessful = false;	
							}
							if (isSuccessful && ( StringUtils.isEmpty(getDurumKoduOfAccount(new BigDecimal(recipientAccountNo))) || !getDurumKoduOfAccount(new BigDecimal(recipientAccountNo)).equals("A") )) {
								orderStatus = DatabaseConstants.OrderStatuses.RecipientAccountClosed_Payment;
								isSuccessful = false;	
							}
							BigDecimal hesapHareketKodu = getHesapHareketKoduOfAccount(new BigDecimal(recipientAccountNo));
							if (isSuccessful && hesapHareketKodu != null && (hesapHareketKodu.compareTo(new BigDecimal(3)) == 0 ||  hesapHareketKodu.compareTo(new BigDecimal(4)) == 0)) {
								orderStatus = DatabaseConstants.OrderStatuses.RecipientAccountClosedToAssetTransfer_Payment;
								isSuccessful = false;	
							}					
						}
					}
				}
			}
		} catch (Throwable e) {
			logger.error(String.format("An exception occured while doing payment controls in DoLoadingAndPaymentControlsHandler for orderLog id: %s", orderLog.getOid()));
			logger.error(System.currentTimeMillis(), e);
			exceptionOccured = true;
			orderStatus = DatabaseConstants.OrderStatuses.PaymentError;
			isSuccessful = false;
			errorMessage = CommonHelper.getStringifiedException(e);			
			if(errorMessage != null && errorMessage.length() > 1000){
				errorMessage = errorMessage.substring(0 ,950);
			}
		} finally {		
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS, orderStatus);	
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_SUCCESSFUL, isSuccessful);		
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.IS_EXCEPTION, exceptionOccured);		
			output.put(TransactionConstants.DoLoadingAndPaymentControls.Output.ERROR_DESC, errorMessage);
			return output;
		}
	}
	
	private boolean isAccountDefined(BigDecimal accountNo, String corporateCode, String accountType) {
		CorporationDef corp = (CorporationDef) super.getHibernateSession().createCriteria(CorporationDef.class)
												 .add(Restrictions.eq("status", true))
												 .add(Restrictions.eq("corporateCode", corporateCode))
												 .uniqueResult();
		CorporationAccountDef acc = null;
		if (corp != null) 
			acc = (CorporationAccountDef) super.getHibernateSession().createCriteria(CorporationAccountDef.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("corporateOid", corp.getOid()))
												.add(Restrictions.eq("accountNo", accountNo))	
												.add(Restrictions.eq("accountType", accountType))												
												.uniqueResult();
		if (acc != null)
			return true;
		else
			return false;
	}
	
	private BigDecimal getDefaultAccount(String corporateCode, String accountType) {
		BigDecimal defaultAccountNo = new BigDecimal(-1);
		CorporationDef corp = (CorporationDef) super.getHibernateSession().createCriteria(CorporationDef.class)
												 .add(Restrictions.eq("status", true))
												 .add(Restrictions.eq("corporateCode", corporateCode))
												 .uniqueResult();
		CorporationAccountDef acc = null;
		if (corp != null) 
			acc = (CorporationAccountDef) super.getHibernateSession().createCriteria(CorporationAccountDef.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("corporateOid", corp.getOid()))
												.add(Restrictions.eq("defaultAccount", true))	
												.add(Restrictions.eq("accountType", accountType))												
												.uniqueResult();
		if (acc != null)
			defaultAccountNo = acc.getAccountNo();
		return defaultAccountNo;
	}
	
	private String getModulTurKodOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.MODUL_TUR_KOD_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}
	
	private String getDurumKoduOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.DURUM_KODU_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}	
	
	private BigDecimal getHesapHareketKoduOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.HESAP_HAREKET_KODU_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return new BigDecimal(result);
		else 
			return null;
	}	
	
	private BigDecimal getCustomerNoOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.MUSTERI_NO_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return new BigDecimal(result);
		else 
			return null;
	}

	private BigDecimal getCustomerNoFromIban(String iban) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.MUSTERI_NO_BY_IBAN_QUERY;
		String result = DALUtil.getResult(String.format(query, iban));
		
		if (!StringUtils.isEmpty(result))
			return new BigDecimal(result);
		else 
			return null;
	}
	
	private BigDecimal getAccountNoFromIban(String iban) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.HESAP_NO_BY_IBAN_QUERY;
		String result = DALUtil.getResult(String.format(query, iban));
		
		if (!StringUtils.isEmpty(result))
			return new BigDecimal(result);
		else 
			return null;
	}	
	
	private String getCurrencyOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.DOVIZ_KODU_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}
	
	private boolean isValidCurrency(String currencyCode) {				
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.DOVIZ_KODU_VALIDITY_QUERY;
		String result = DALUtil.getResult(String.format(query, currencyCode));

		if (!StringUtils.isEmpty(result))
			return true;
		else 
			return false;				
	}
	
	private boolean isValidBank(String bankCode) {		
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.BANKA_KODU_VALIDITY_QUERY;
		String result = DALUtil.getResult(String.format(query, bankCode));
		
		if (!StringUtils.isEmpty(result))
			return true;
		else 
			return false;
	}
	
	private boolean isValidBranch(String bankCode, String branchCode) {
		String query = null, result = null;
		if (!bankCode.equals(GeneralConstants.AktifBankCode)) {
			query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.SUBE_KODU_VALIDITY_BY_BANKA_KODU_QUERY;
			result = DALUtil.getResult(String.format(query, bankCode, String.format("%5s", branchCode).replace(' ','0')));
		} else {
			query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.SUBE_KODU_VALIDITY_QUERY;
			result = DALUtil.getResult(String.format(query, branchCode));			
		}
		
		if (!StringUtils.isEmpty(result))
			return true;
		else 
			return false;
	}
	
	private boolean isValidAccountNo(String branchCode, BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.SUBE_KODU_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result) && result.equals(branchCode))
			return true;
		else 
			return false;
	}
	
	private boolean isValidAccountNo(BigDecimal accountNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.SUBE_KODU_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return true;
		else 
			return false;
	}
	
	private String getTcknOfCustomer(BigDecimal customerNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.TC_KIMLIK_NO_BY_MUSTERI_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, customerNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}
		
	private String getVknOfCustomer(BigDecimal customerNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.VERGI_NO_BY_MUSTERI_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, customerNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}
	
	private String getCustomerType(BigDecimal customerNo) {
		String query = QueryRepository.DoLoadingAndPaymentControlsHandlerRepository.MUSTERI_TUR_KOD_BY_MUSTERI_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, customerNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}
}








