package tr.com.aktifbank.bnspr.cos.common;


public final class TransactionConstants {
	
	public static final class CorporationDef {
		public static final String tableName = "CORP_LIST";
		public static final String ACTIVENESS = "ACTIVENESS";
		public static final String CUSTOMER_NO = "CUSTOMER_NO";
		public static final String CUSTOMER_TITLE = "CUSTOMER_TITLE";
		public static final String CORPORATE_CODE = "CORPORATE_CODE";
		public static final String SHORT_NAME = "SHORT_NAME";
		public static final String OID = "OID";
		public static final String FTM_FILE_DEF_OID = "FTM_FILE_DEF_OID";
	}
	
	public static final class CorpAccount {
		public static final String tableName = "ACCOUNT_LIST";
		public static final String ACCOUNT_TYPE = "ACCOUNT_TYPE";
		public static final String ACCOUNT_TYPE_NAME = "ACCOUNT_TYPE_NAME";
		public static final String ACCOUNT_NO = "ACCOUNT_NO";
		public static final String DEFAULT_ACCOUNT = "DEFAULT_ACCOUNT";
		public static final String ACCOUNT_NAME = "ACCOUNT_NAME";
		public static final String ACCOUNT_PRODUCT_TYPE = "ACCOUNT_PRODUCT_TYPE";
		public static final String BRANCH_NAME = "BRANCH_NAME";
		public static final String CURRENCY = "CURRENCY";
		public static final String CORP_OID = "CORP_OID";
		public static final String CORPORATE_CODE = "CORPORATE_CODE";
		public static final String CUSTOMER_NO = "CUSTOMER_NO";
	}

	public static final class CorpParameter {
		public static final String CHECK_VKN = "CHECK_VKN";
		public static final String CHECK_TCKN = "CHECK_TCKN";
		public static final String CHECK_NAME_CONSISTENCY = "CHECK_NAME_CONSISTENCY";
		public static final String ORDER_BY_AMOUNT = "ORDER_BY_AMOUNT";
		public static final String DESC_ORDER = "DESC_ORDER";
		public static final String ASC_ORDER = "ASC_ORDER";
		public static final String AMOUNT_ORDER = "AMOUNT_ORDER";
		public static final String CHECK_RECIPIENTS = "CHECK_RECIPIENTS";
		public static final String SMS_TO_RECIPIENT = "SMS_TO_RECIPIENT";
		public static final String SMS_FOR_EFT = "SMS_FOR_EFT";
		public static final String SMS_FOR_HAVALE = "SMS_FOR_HAVALE";
		public static final String SMS_FOR_VIRMAN = "SMS_FOR_VIRMAN";
		public static final String SMS_FOR_PTT_ISME_HAVALE = "SMS_FOR_PTT_ISME_HAVALE";
		public static final String EMAIL_TO_RECIPIENT = "EMAIL_TO_RECIPIENT";
		public static final String EMAIL_LOADING_STATUS = "EMAIL_LOADING_STATUS";
		public static final String EMAIL_TRANSFER_STATUS = "EMAIL_TRANSFER_STATUS";
		public static final String EMAIL_EOD_STATUS = "EMAIL_EOD_STATUS";
		public static final String MAKE_LOADING_STATUS_FILE = "MAKE_LOADING_STATUS_FILE";
		public static final String MAKE_TRANSFER_STATUS_FILE = "MAKE_TRANSFER_STATUS_FILE";
		public static final String MAKE_EOD_STATUS_FILE = "MAKE_EOD_STATUS_FILE";
		public static final String SEPARATE_EOD_STATUS_FILE = "SEPARATE_EOD_STATUS_FILE";
		public static final String CUMULATIVE_EOD_STATUS_FILE = "CUMULATIVE_EOD_STATUS_FILE";		
		public static final String ALLOW_TRANSFER_TO_VALID = "ALLOW_TRANSFER_TO_VALID";
		public static final String TRANSFER_WITHOUT_APPROVAL = "TRANSFER_WITHOUT_APPROVAL";
		public static final String LOADING_EMAIL = "LOADING_EMAIL";
		public static final String TRANSFER_EMAIL = "TRANSFER_EMAIL";
		public static final String EOD_EMAIL = "EOD_EMAIL";
		public static final String EOD_STATUS_EMAIL_TIME = "EOD_STATUS_EMAIL_TIME";
		public static final String EMAIL_RECEIPT_TO_RECIPIENT = "EMAIL_RECEIPT_TO_RECIPIENT";
		public static final String CORP_OID = "CORP_OID";
	}
	
	public static final class RecipientDef {
		public static final String tableName = "RECIPIENT_LIST";
		public static final String tableProperties = "RECIPIENT_PROPERTIES";
		public static final String ACCOUNT_NO = "ACCOUNT_NO";
		public static final String IBAN = "IBAN";
		public static final String NAME_TITLE = "NAME_TITLE";
		public static final String TCKN = "TCKN";
		public static final String BANK = "BANK";
		public static final String BRANCH = "BRANCH";
		public static final String ORDER_TYPE = "ORDER_TYPE";
		public static final String ORDER_TYPE_TEXT = "ORDER_TYPE_TEXT";
		public static final String EFT_TYPE = "EFT_TYPE";
		public static final String FILE_PATH = "FILE_PATH";
		public static final String FILE = "FILE";
		public static final String CORP_OID = "CORP_OID";
	}
	
	public static final class CorpContactInfo {
		public static final String tableName = "CONTACT_LIST";
		public static final String EMAIL = "EMAIL";
		public static final String FAX = "FAX";
		public static final String MOBILE = "MOBILE";
		public static final String NAME_SURNAME = "NAME_SURNAME";
		public static final String PHONE_NUMBER = "PHONE_NUMBER";
		public static final String CORP_OID = "CORP_OID";
		public static final String EXTENSION_NUMBER = "EXTENSION_NUMBER";
	}
	
	public static final class GetOrderFiles{
		public static final String tableName = "FILE_LIST";
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String BEGIN_DATE = "BEGIN_DATE";
			public static final String END_DATE = "END_DATE";
			public static final String FILE_NAME = "FILE_NAME";
			public static final String IS_APPROVER = "IS_APPROVER";
			public static final String TRX_NO = "TRX_NO";
		}
		public static final class Output{
			public static final String PATH = "PATH";
			public static final String FILE_NAME = "FILE_NAME";
			public static final String LOADING_DATE = "LOADING_DATE";
			public static final String LOADING_TIME = "LOADING_TIME";
			public static final String ORDER_DATE = "ORDER_DATE";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String STATUS = "STATUS";
			public static final String FTM_SEQUENCE_NUMBER = "FTM_SEQUENCE_NUMBER";
			public static final String FTM_FILE_DEF_OID = "FTM_FILE_DEF_OID";
			public static final String FILE_TRANSFER_LOG_OID = "FILE_TRANSFER_LOG_OID";	
			public static final String TOTAL_LINE_COUNT = "TOTAL_LINE_COUNT";
			public static final String ERRONEOUS_LINE_COUNT = "ERRONEOUS_LINE_COUNT";
			public static final String LOADING_STATUS = "LOADING_STATUS";
			public static final String FILE_STATUS = "FILE_STATUS";
			public static final String TRY_AMOUNT = "TRY_AMOUNT";
			public static final String USD_AMOUNT = "USD_AMOUNT";
			public static final String EUR_AMOUNT = "EUR_AMOUNT";
			public static final String TRY_LINE_COUNT = "TRY_LINE_COUNT";
			public static final String USD_LINE_COUNT = "USD_LINE_COUNT";
			public static final String EUR_LINE_COUNT = "EUR_LINE_COUNT";
			public static final String TRANSFER_DEF_EXISTS = "TRANSFER_DEF_EXISTS";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_DESC = "ERROR_DESC";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CORPORATE_SHORT_NAME = "CORPORATE_SHORT_NAME";
		}
	}
	
	public static final class GetErrorLines{
		public static final String SERVICE_NAME = "COS_GET_ERROR_LINES";
		public static final String tableName = "ERROR_LINE_LIST";
		public static final class Input{
			public static final String SUBMIT_ID = "SUBMIT_ID";
			public static final String ERROR_TYPE = "ERROR_TYPE";
		}
		public static final class Output{
			public static final String LINE_NUMBER = "LINE_NUMBER";
			public static final String LINE_CONTENT = "LINE_CONTENT";
			public static final String ERROR_DESCRIPTION = "ERROR_DESCRIPTION";
		}
	}
	
	public static final class GetOrderFileContent{
		public static final String SERVICE_NAME = "COS_GET_ORDER_FILE_CONTENT";
		public static final String tableName = "FILE_CONTENT_LIST";
		public static final class Input{
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String FTM_SEQUENCE_NUMBER = "FTM_SEQUENCE_NUMBER";
			public static final String LINE_TYPE = "LINE_TYPE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String SELECT_ALL = "SELECT_ALL";
			public static final String LOADING_STATUS = "LOADING_STATUS";
			public static final String FILE_STATUS = "FILE_STATUS";
			public static final String TRX_NO = "TRX_NO";
			public static final String QUERY_SCREEN = "QUERY_SCREEN";
		}
		public static final class Output{
			public static final String SELECT = "SELECT";
			public static final String MAIN_OID = "MAIN_OID";
			public static final String RECIPIENT_NAME = "RECIPIENT_NAME";
			public static final String RECIPIENT_ADDRESS = "RECIPIENT_ADDRESS";
			public static final String RECIPIENT_MOTHER_NAME = "RECIPIENT_MOTHER_NAME";
			public static final String RECIPIENT_FATHER_NAME = "RECIPIENT_FATHER_NAME";
			public static final String RECIPIENT_BANK = "RECIPIENT_BANK";
			public static final String RECIPIENT_DATE_OF_BIRTH = "RECIPIENT_DATE_OF_BIRTH";
			public static final String RECIPIENT_EMAIL = "RECIPIENT_EMAIL";			
			public static final String RECIPIENT_ACCOUNT_NO = "RECIPIENT_ACCOUNT_NO";
			public static final String RECIPIENT_IBAN = "RECIPIENT_IBAN";
			public static final String RECIPIENT_CC_NO = "RECIPIENT_CC_NO";
			public static final String RECIPIENT_REF_NO = "RECIPIENT_REF_NO";
			public static final String RECIPIENT_BRANCH = "RECIPIENT_BRANCH";
			public static final String RECIPIENT_TCKN = "RECIPIENT_TCKN";
			public static final String RECIPIENT_PHONE_NUMBER = "RECIPIENT_PHONE_NUMBER";			
			public static final String RECIPIENT_VKN = "RECIPIENT_VKN";
			public static final String BLOCKAGE_DATE = "BLOCKAGE_DATE";
			public static final String EFT_REF_NO = "EFT_REF_NO";
			public static final String ACCOUNT_NO = "ACCOUNT_NO";
			public static final String ERROR_DESCRIPTION = "ERROR_DESCRIPTION";
			public static final String EXPLANATION = "EXPLANATION";
			public static final String ORDER_STATUS = "ORDER_STATUS";			
			public static final String ORDER_STATUS_CODE = "ORDER_STATUS_CODE";	
			public static final String TX_NO = "TX_NO";
			public static final String ORDER_TYPE = "ORDER_TYPE";
			public static final String COMMISSION_ACCOUNT_NO = "COMMISSION_ACCOUNT_NO";
			public static final String COMMISSION_AMOUNT = "COMMISSION_AMOUNT";
			public static final String CUSTOMER_NAME = "CUSTOMER_NAME";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String TRANSFER_DATE = "TRANSFER_DATE";
			public static final String TRANSFER_TIME = "TRANSFER_TIME";
			public static final String CURRENCY_CODE = "CURRENCY_CODE";
			public static final String TRANSFER_AMOUNT = "TRANSFER_AMOUNT";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
			public static final String AMOUNT = "AMOUNT";
			public static final String TAX_OFFICE = "TAX_OFFICE";
			public static final String LOADING_DATE = "LOADING_DATE";
			public static final String EFT_SORGU_NO = "EFT_SORGU_NO";
			public static final String FIS_NO = "FIS_NO";
			public static final String PAYMENT_ACCOUNT_NO = "PAYMENT_ACCOUNT_NO";
			public static final String PAYMENT_COMMISSION_ACCOUNT_NO = "PAYMENT_COMMISSION_ACCOUNT_NO";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String ORDER_DATE = "ORDER_DATE";
			public static final String ERROR_TYPE = "ERROR_TYPE";
			public static final String TRANSACTION_CREATE_USER = "TRANSACTION_CREATE_USER";
			public static final String TRANSACTION_APPROVE_USER = "TRANSACTION_APPROVE_USER";			
		}
	}
	
	public static final class OrderLineSelection{
		public static final String tableName = "FILE_CONTENT_LIST";
		public static final class Input{
			public static final String SELECTED_ROW = "SELECTED_ROW";
		}
		public static final class Output{
			public static final String SELECTED_TRY_COUNT = "SELECTED_TRY_COUNT";
			public static final String SELECTED_TRY_AMOUNT = "SELECTED_TRY_AMOUNT";
			public static final String SELECTED_USD_COUNT = "SELECTED_USD_COUNT";
			public static final String SELECTED_USD_AMOUNT = "SELECTED_USD_AMOUNT";
			public static final String SELECTED_EUR_COUNT = "SELECTED_EUR_COUNT";
			public static final String SELECTED_EUR_AMOUNT = "SELECTED_EUR_AMOUNT";
			public static final String ENABLE_TRANSFER = "ENABLE_TRANSFER";
		}
	}	
	
	public static final class OrderTransaction{
		public static final String tableName = "FILE_CONTENT_LIST";
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String TRY_AMOUNT = "TRY_AMOUNT";
			public static final String USD_AMOUNT = "USD_AMOUNT";
			public static final String EUR_AMOUNT = "EUR_AMOUNT";
			public static final String TRY_RECORD_COUNT = "TRY_RECORD_COUNT";
			public static final String USD_RECORD_COUNT = "USD_RECORD_COUNT";
			public static final String EUR_RECORD_COUNT = "EUR_RECORD_COUNT";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String ORDER_DATE = "ORDER_DATE";
			public static final String TRANSFER_WITHOUT_APPROVAL = "TRANSFER_WITHOUT_APPROVAL";
		}
	}	
	
	public static final class InsertOrderTransferLog{
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String MAIN_OID = "MAIN_OID";
			public static final String RECIPIENT_NAME = "RECIPIENT_NAME";
			public static final String RECIPIENT_ADDRESS = "RECIPIENT_ADDRESS";
			public static final String RECIPIENT_MOTHER_NAME = "RECIPIENT_MOTHER_NAME";
			public static final String RECIPIENT_FATHER_NAME = "RECIPIENT_FATHER_NAME";
			public static final String RECIPIENT_BANK = "RECIPIENT_BANK";
			public static final String RECIPIENT_DATE_OF_BIRTH = "RECIPIENT_DATE_OF_BIRTH";
			public static final String RECIPIENT_EMAIL = "RECIPIENT_EMAIL";			
			public static final String RECIPIENT_ACCOUNT_NO = "RECIPIENT_ACCOUNT_NO";
			public static final String RECIPIENT_IBAN = "RECIPIENT_IBAN";
			public static final String RECIPIENT_CC_NO = "RECIPIENT_CC_NO";
			public static final String RECIPIENT_REF_NO = "RECIPIENT_REF_NO";
			public static final String RECIPIENT_BRANCH = "RECIPIENT_BRANCH";
			public static final String RECIPIENT_TCKN = "RECIPIENT_TCKN";
			public static final String RECIPIENT_PHONE_NUMBER = "RECIPIENT_PHONE_NUMBER";			
			public static final String RECIPIENT_VKN = "RECIPIENT_VKN";
			public static final String BLOCKAGE_DATE = "BLOCKAGE_DATE";
			public static final String EFT_REF_NO = "EFT_REF_NO";
			public static final String ACCOUNT_NO = "ACCOUNT_NO";
			public static final String EXPLANATION = "EXPLANATION";
			public static final String ORDER_STATUS = "ORDER_STATUS";			
			public static final String MAIN_TX_NO = "MAIN_TX_NO";
			public static final String ORDER_TYPE = "ORDER_TYPE";
			public static final String COMMISSION_ACCOUNT_NO = "COMMISSION_ACCOUNT_NO";
			public static final String COMMISSION_AMOUNT = "COMMISSION_AMOUNT";
			public static final String CUSTOMER_NAME = "CUSTOMER_NAME";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String CURRENCY_CODE = "CURRENCY_CODE";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
			public static final String AMOUNT = "AMOUNT";
			public static final String TAX_OFFICE = "TAX_OFFICE";
			public static final String LOADING_DATE = "LOADING_DATE";
			public static final String ORDER_DATE = "ORDER_DATE";
			public static final String PAYMENT_ACCOUNT_NO = "PAYMENT_ACCOUNT_NO";
			public static final String PAYMENT_COMMISSION_ACCOUNT_NO = "PAYMENT_COMMISSION_ACCOUNT_NO";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String LINE_NUMBER = "LINE_NUMBER";			
		}
	}
	
	public static final class OrderTransfersApproved{
		public static final String SERVICE_NAME = "COS_ORDER_TRANSFERS_APPROVED";
		public static final class Input{
			public static final String TX_NO = "ISLEM_NO";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String TRANSACTION_TX_LIST = "TRANSACTION_TX_LIST";
		}
		public static final class Output{
			public static final String FIS_NO = "FIS_NO";
			public static final String EFT_SORGU_NO = "EFT_SORGU_NO";			
		}
	}	

	public static final class OrderTransfersCancelled{
		public static final String SERVICE_NAME = "COS_ORDER_TRANSFERS_CANCELLED";
		public static final class Input{
			public static final String TX_NO = "ISLEM_NO";
		}
	}	
	
	public static final class FtmBatchStarter{
		public static final class Input{
			public static final String FTM_ID = "FILE_DEF_ID";
			public static final String FTM_TRANSFER_ID = "PROCESS_ID";
		}
		public static final class Output{
			public static final String SUBMIT_ID = "SUBMIT_ID"; 
		}
		public static final String SERVICE_NAME = "ICS_FTM_BATCH_STARTER";
	}
	
	public static final class GetOrderCorpDef{
		public static final String SERVICE_NAME = "COS_GET_CORP_DEF";
		public static final class Inputs{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String THROWS_EXCEPTION = "THROWS_EXCEPTION";
		}
		public static final class Output{
			public static final String CORPORATE_ACTIVENESS = "CORPORATE_ACTIVENESS";
			public static final String CORPORATE_NAME = "CORPORATE_NAME";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String CORPORATE_OID = "CORPORATE_OID";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String RESULT = "RESULT";
			public static final String SHORT_NAME = "SHORT_NAME";
			public static final String MAKE_LOADING_STATUS_FILE = "MAKE_LOADING_STATUS_FILE";
			public static final String MAKE_TRANSFER_STATUS_FILE = "MAKE_TRANSFER_STATUS_FILE";
			public static final String MAKE_EOD_STATUS_FILE = "MAKE_EOD_STATUS_FILE";
			public static final String SMS_TO_RECIPIENT = "SMS_TO_RECIPIENT";
			public static final String SMS_FOR_EFT = "SMS_FOR_EFT";
			public static final String SMS_FOR_HAVALE = "SMS_FOR_HAVALE";
			public static final String SMS_FOR_VIRMAN = "SMS_FOR_VIRMAN";
			public static final String SMS_FOR_PTT_ISME_HAVALE = "SMS_FOR_PTT_ISME_HAVALE";			
			public static final String EMAIL_TO_RECIPIENT = "EMAIL_TO_RECIPIENT";
			public static final String EMAIL_LOADING_STATUS = "EMAIL_LOADING_STATUS";
			public static final String EMAIL_TRANSFER_STATUS = "EMAIL_TRANSFER_STATUS";
			public static final String EMAIL_EOD_STATUS = "EMAIL_EOD_STATUS";
			public static final String LOADING_EMAIL = "LOADING_EMAIL";
			public static final String TRANSFER_EMAIL = "TRANSFER_EMAIL";
			public static final String EOD_EMAIL = "EOD_EMAIL";
			public static final String EOD_EMAIL_TIME = "EOD_EMAIL_TIME";
			public static final String CHECK_VKN = "CHECK_VKN";
			public static final String CHECK_TCKN = "CHECK_TCKN";
			public static final String ALLOW_TRANSFER_TO_VALID = "ALLOW_TRANSFER_TO_VALID";
			public static final String TRANSFER_WITHOUT_APPROVAL = "TRANSFER_WITHOUT_APPROVAL";
			public static final String AMOUNT_ORDERING = "AMOUNT_ORDERING";
			public static final String CHECK_RECIPIENTS = "CHECK_RECIPIENTS";
			public static final String EMAIL_RECEIPT_TO_RECIPIENT = "EMAIL_RECEIPT_TO_RECIPIENT";
		}
	}
	
	public static final class GetOrderBatchDetail{
		public static final String SERVICE_NAME ="COS_GET_CORPORATE_BATCH_DETAIL";
		public static final class Input{
			public static final String BATCH_NAME = "BATCH_NAME";	
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}
		public static final class Output{
			//public static final String BATCH_OID = "BATCH_OID";
			public static final String SERVICE_NAME = "SERVICE_NAME";
			public static final String THREAD_COUNT = "THREAD_COUNT";
			public static final String COMMIT_COUNT = "COMMIT_COUNT";
			public static final String THRESHOLD = "THRESHOLD";
			public static final String CORPORATE_BATCH_PROCESS_OID = "CORPORATE_BATCH_PROCESS_OID";
		}
	}
		
	public static final class GetBatchParameters{
		public static final String SERVICE_NAME ="COS_GET_CORPORATE_BATCH_PARAMETERS";
		public static final class Input{
			public static final String CORPORATE_BATCH_PROCESS_OID = "CORPORATE_BATCH_PROCESS_OID";
		}
		public static final class Output{
			public static final String COMPOSED_PARAMETERS = "COMPOSED_PARAMETERS";
		}
	}

	public static final class OrderLoadingControls{
		public static final String SERVICE_NAME ="COS_ORDER_LOADING_CONTROLS";
		public static final class Input{
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String FTM_SEQUENCE_NUMBER = "FTM_SEQUENCE_NUMBER";			
			public static final String ORDER_FILE_LOG_OID = "ORDER_FILE_LOG_OID";
			public static final String HEADER_ORDER_DATE = "HEADER_ORDER_DATE";
			public static final String HEADER_CUSTOMER_ACCOUNT_NO = "HEADER_CUSTOMER_ACCOUNT_NO";
			public static final String ALLOW_TRANSFER_TO_VALID = "ALLOW_TRANSFER_TO_VALID";
		}
		public static final class Output{
			public static final String FILE_STATUS = "FILE_STATUS";			
		}
	}	
	
	public static final class CheckRepeatedOrder{
		public static final String SERVICE_NAME ="COS_CHECK_REPEATED_ORDER";
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
		}
	}	
	
	public static final class DoLoadingAndPaymentControls{
		public static final String SERVICE_NAME ="COS_DO_LOADING_AND_PAYMENT_CONTROLS";
		public static final class Input{
			public static final String CONTROL_TYPE = "CONTROL_TYPE";
			public static final String CONTROL_OBJECT = "CONTROL_OBJECT";
			public static final String HEADER_ORDER_DATE = "HEADER_ORDER_DATE";
			public static final String HEADER_CUSTOMER_NO = "HEADER_CUSTOMER_NO";
			public static final String HEADER_CUSTOMER_BANK = "HEADER_CUSTOMER_BANK";
			public static final String HEADER_CUSTOMER_BRANCH = "HEADER_CUSTOMER_BRANCH";
			public static final String HEADER_CUSTOMER_ACCOUNT_NO = "HEADER_CUSTOMER_ACCOUNT_NO";
		}
		public static final class Output{
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String ORDER_TYPE = "ORDER_TYPE";
			public static final String PAYMENT_ACCOUNT = "PAYMENT_ACCOUNT";
			public static final String COMMISSION_ACCOUNT = "COMMISSION_ACCOUNT";
			public static final String IS_SUCCESSFUL = "IS_SUCCESSFUL";
			public static final String IS_EXCEPTION = "IS_EXCEPTION";
			public static final String ERROR_DESC = "ERROR_DESC";
		}
	}

	public static final class DoTransferAndUpdate{
		public static final String SERVICE_NAME ="COS_DO_TRANSFER_AND_UPDATE";
		public static final class Input{
			public static final String TRANSFER_LOG_OBJECT = "TRANSFER_LOG_OBJECT";
			public static final String TRANSFER_TX_NO = "TRANSFER_TX_NO";
		}
		public static final class Output{
			public static final String IS_TRANSFER_SUCCESSFUL = "IS_TRANSFER_SUCCESSFUL";
		}
	}
	
	public static final class UpdateOrderMainAndTransferLog{
		public static final String SERVICE_NAME ="COS_UPDATE_ORDER_MAIN_AND_TRANSFER_LOG";
		public static final class Input{
			public static final String OID = "OID";
			public static final String TX_NO = "TX_NO";
			public static final String ORDER_STATUS = "ORDER_STATUS";
			public static final String SET_FAILED_PAYMENT_TO_NULL = "SET_FAILED_PAYMENT_TO_NULL";
			public static final String TRANSFER_DATE = "TRANSFER_DATE";
			public static final String TRANSFER_AMOUNT = "TRANSFER_AMOUNT";
			public static final String EFT_SORGU_NO = "EFT_SORGU_NO";
			public static final String FIS_NO = "FIS_NO";
			public static final String ERROR_DESC = "ERROR_DESC";			
		}
	}
	
	public static final class GetFailedLineCountAndFileStatus{
		public static final String SERVICE_NAME ="COS_GET_FAILED_LINE_COUNT_AND_FILE_STATUS";
		public static final class Input{
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
		}
		public static final class Output{
			public static final String FAILED_LINE_COUNT = "FAILED_LINE_COUNT";
			public static final String FILE_STATUS = "FILE_STATUS";
		}
	}
		
	public static final class UpdateOrderMainStatus{
		public static final String SERVICE_NAME ="COS_UPDATE_ORDER_MAIN_STATUS";
		public static final class Input{
			public static final String FTM_SEQUENCE_NUMBER = "FTM_SEQUENCE_NUMBER";			
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}
		public static final class Output{

		}
	}
	
	public static final class UpdateTransactionStatus{
		public static final String SERVICE_NAME ="COS_UPDATE_TRANSACTION_STATUS";
		public static final class Input{
			public static final String TX_NO = "TX_NO";		
			public static final String TRANSACTION_STATUS = "TRANSACTION_STATUS";
			public static final String SET_PROCESSING_STARTED = "SET_PROCESSING_STARTED";	
		}
		public static final class Output{

		}
	}
	
	public static final class CreateOutgoingFileByFtmCall {
		public static final String SERVICE_NAME ="COS_CREATE_OUTGOING_FILE_BY_FTM_CALL";
		public static final class Input{
			public static final String FILE_TYPE = "FILE_TYPE";		
		}
	}
	
	public static final class UpdateOutgoingFileStatus{
		public static final String SERVICE_NAME ="COS_UPDATE_OUTGOING_FILE_STATUS";
		public static final class Input{
			public static final String OUTGOING_FILE_OID = "OUTGOING_FILE_OID";		
			public static final String SET_STATUS_FALSE = "SET_STATUS_FALSE";
			public static final String FILE_TYPE = "FILE_TYPE";	
		}
		public static final class Output{

		}
	}
	
	public static final class UpdateOrderFileLog{
		public static final String SERVICE_NAME ="COS_UPDATE_ORDER_FILE_LOG";
		public static final class Input{
			public static final String OID = "OID";
			public static final String SUBMIT_ID = "SUBMIT_ID";
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String TOTAL_DETAIL_LINE_COUNT = "TOTAL_DETAIL_LINE_COUNT";
			public static final String ERRONEOUS_LINE_COUNT = "ERRONEOUS_LINE_COUNT";
			public static final String LOADING_STATUS = "LOADING_STATUS";
			public static final String FILE_STATUS = "FILE_STATUS";
			public static final String TRY_AMOUNT = "TRY_AMOUNT";
			public static final String USD_AMOUNT = "USD_AMOUNT";
			public static final String EUR_AMOUNT = "EUR_AMOUNT";
			public static final String TRY_LINE_COUNT = "TRY_LINE_COUNT";
			public static final String USD_LINE_COUNT = "USD_LINE_COUNT";
			public static final String EUR_LINE_COUNT = "EUR_LINE_COUNT";
			public static final String ORDER_DATE = "ORDER_DATE";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String CUSTOMER_BANK = "CUSTOMER_BANK";
			public static final String CUSTOMER_BRANCH = "CUSTOMER_BRANCH";
			public static final String CUSTOMER_ACCOUNT_NO = "CUSTOMER_ACCOUNT_NO";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
		}
		public static final class Output{
			public static final String FILE_LOADING_DATE = "FILE_LOADING_DATE";
		}
	}
	
	public static final class ComposeEmail{
		public static final String SERVICE_NAME ="COS_COMPOSE_EMAIL";
		public static final class Input{
			public static final String EMAIL_TYPE = "EMAIL_TYPE";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String LOADING_BATCH_SUBMIT_ID = CONFIRMATION_EMAIL_LOADING_SUBMIT_ID_GENERAL_KEY;
			public static final String LOADING_FTM_SEQUENCE_NUMBER = CONFIRMATION_EMAIL_LOADING_FTM_SEQUENCE_NUMBER_GENERAL_KEY;	
			public static final String LOADING_FTM_ID = CONFIRMATION_EMAIL_LOADING_FTM_ID_GENERAL_KEY;		
			public static final String LOADING_DATE = "LOADING_DATE";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String HEADER_ORDER_DATE = "HEADER_ORDER_DATE";
			public static final String FILE_STATUS = "FILE_STATUS";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
			public static final String ORDER_OID = "ORDER_OID";
		}
		public static final class Output{
			public static final String ORDER_STATUS = "ORDER_STATUS";
		}
	}
	
	public static final class GeneralBatchSubmit{
		public static final class Input{
			public static final String BATCH_NAME = "BATCH_NAME";	
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";
			public static final String THREAD_COUNT = "THREAD_COUNT";
			public static final String COMMIT_COUNT = "COMMIT_COUNT";
			public static final String FTM_ID = "FTM_ID";
			public static final String SUBMIT_ID = "SUBMIT_ID"; 
			public static final String FORMAT_OID = "FORMAT_OID";
			public static final String PARAMETERS = "PARAMETERS";
			public static final String THRESHOLD = "THRESHOLD";
			public static final String ORDER_FILE_LOG_OID = "ORDER_FILE_LOG_OID";
		}
	}	
	
	public static final class InsertBatchSubmitLog{
		public static final String SERVICE_NAME ="ICS_INSERT_BATCH_SUBMIT_LOG";
		public static final class Input{
			public static final String BATCH_NAME = "BATCH_NAME";	
			public static final String CORPORATE_CODE = "CORPORATE_CODE"; 	
			public static final String SUBMIT_STATUS = "SUBMIT_STATUS"; 
			public static final String SUBMIT_USER = "SUBMIT_USER"; 	
			public static final String SUBMIT_DATE = "SUBMIT_DATE"; 	
			public static final String PARAMETERS = "PARAMETERS";
			public static final String SUBMIT_ID = "SUBMIT_ID";
			public static final String IS_UPDATE = "IS_UPDATE";
			public static final String ERROR_CODE = "ERROR_CODE"; 
			public static final String ERROR_DESCRIPTION = "ERROR_DESCRIPTION";
			public static final String START_TIME = "START_TIME";
			public static final String END_TIME = "END_TIME"; 
		}
		public static final class Output{
			 
		}
	}
	
	public static final class GetOrderFilesDetailReport{
		public static final String tableName = "FILE_LIST";
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String BEGIN_DATE = "BEGIN_DATE";
			public static final String END_DATE = "END_DATE";
			public static final String FILE_NAME = "FILE_NAME";
			public static final String FILE_STATUS = "FILE_STATUS";
			public static final String BRANCH = "BRANCH";
			public static final String SHOW_TRANSFERED = "SHOW_TRANSFERED";
		}
		public static final class Output{
			public static final String CORPORATE_SHORT_NAME = "CORPORATE_SHORT_NAME";
			public static final String FILE_NAME = "FILE_NAME";
			public static final String STATUS = "STATUS";			
			public static final String LOADING_DATE = "LOADING_DATE";
			public static final String LOADING_TIME = "LOADING_TIME";
			public static final String ORDER_DATE = "ORDER_DATE";
			public static final String TOTAL_LINE_COUNT = "TOTAL_LINE_COUNT";
			public static final String ERRONEOUS_LINE_COUNT = "ERRONEOUS_LINE_COUNT";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String FTM_SEQUENCE_NUMBER = "FTM_SEQUENCE_NUMBER";
			public static final String TRY_LINE_COUNT = "TRY_LINE_COUNT";
			public static final String TRY_AMOUNT = "TRY_AMOUNT";
			public static final String USD_LINE_COUNT = "USD_LINE_COUNT";
			public static final String USD_AMOUNT = "USD_AMOUNT";
			public static final String EUR_LINE_COUNT = "EUR_LINE_COUNT";
			public static final String EUR_AMOUNT = "EUR_AMOUNT";
			public static final String EFT_TRY_LINE_COUNT = "EFT_TRY_LINE_COUNT";
			public static final String EFT_TRY_AMOUNT = "EFT_TRY_AMOUNT";
			public static final String HAVALE_TRY_LINE_COUNT = "HAVALE_TRY_LINE_COUNT";
			public static final String HAVALE_TRY_AMOUNT = "HAVALE_TRY_AMOUNT";
			public static final String VIRMAN_TRY_LINE_COUNT = "VIRMAN_TRY_LINE_COUNT";
			public static final String VIRMAN_TRY_AMOUNT = "VIRMAN_TRY_AMOUNT";
			public static final String PTT_ISME_HAVALE_TRY_LINE_COUNT = "PTT_ISME_HAVALE_TRY_LINE_COUNT";
			public static final String PTT_ISME_HAVALE_TRY_AMOUNT = "PTT_ISME_HAVALE_TRY_AMOUNT";
			public static final String NO_ORDER_TYPE_TRY_LINE_COUNT = "NO_ORDER_TYPE_TRY_LINE_COUNT";
			public static final String NO_ORDER_TYPE_TRY_AMOUNT = "NO_ORDER_TYPE_TRY_AMOUNT";
		}
	}
	
	public static final class GetOrderFilesSummaryReport{
		public static final String tableName = "FILES_SUMMARY";
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String BEGIN_DATE = "BEGIN_DATE";
			public static final String END_DATE = "END_DATE";
			public static final String FILE_NAME = "FILE_NAME";
			public static final String FILE_STATUS = "FILE_STATUS";
			public static final String BRANCH = "BRANCH";
		}
		public static final class Output{
			public static final String CORPORATE_SHORT_NAME = "CORPORATE_SHORT_NAME";
			public static final String TOTAL_FILE_COUNT = "TOTAL_FILE_COUNT";
			public static final String TOTAL_TRY_LINE_COUNT = "TOTAL_TRY_LINE_COUNT";
			public static final String TOTAL_TRY_AMOUNT = "TOTAL_TRY_AMOUNT";
			public static final String TOTAL_USD_LINE_COUNT = "TOTAL_USD_LINE_COUNT";			
			public static final String TOTAL_USD_AMOUNT = "TOTAL_USD_AMOUNT";
			public static final String TOTAL_EUR_LINE_COUNT = "TOTAL_EUR_LINE_COUNT";
			public static final String TOTAL_EUR_AMOUNT = "TOTAL_EUR_AMOUNT";
			public static final String TRANSFERED_TRY_LINE_COUNT = "TRANSFERED_TRY_LINE_COUNT";
			public static final String TRANSFERED_TRY_AMOUNT = "TRANSFERED_TRY_AMOUNT";
			public static final String NOT_TRANSFERED_TRY_LINE_COUNT = "NOT_TRANSFERED_TRY_LINE_COUNT";		
			public static final String NOT_TRANSFERED_TRY_AMOUNT = "NOT_TRANSFERED_TRY_AMOUNT";
		}
	}
	
	public static final class GetDetailTransactionReport{
		public static final String tableName = "RESULTS";
		public static final class Input{
			public static final String START_DATE = "START_DATE";
			public static final String END_DATE = "END_DATE";
		}
		public static final class Output{
			public static final String CORP_NAME = "CORP_NAME";
			public static final String EFT_COUNT = "EFT_COUNT";
			public static final String EFT_AMOUNT = "EFT_AMOUNT";
			public static final String TRANSFER_COUNT = "TRANSFER_COUNT";
			public static final String TRANSFER_AMOUNT = "TRANSFER_AMOUNT";
			public static final String VIRMAN_COUNT = "VIRMAN_COUNT";
			public static final String VIRMAN_AMOUNT = "VIRMAN_AMOUNT";
			public static final String PTT_TRANSFER_COUNT = "PTT_TRANSFER_COUNT";
			public static final String PTT_TRANSFER_AMOUNT = "PTT_TRANSFER_AMOUNT";
			public static final String TRY_COUNT = "TRY_COUNT";
			public static final String TRY_AMOUNT = "TRY_AMOUNT";			
			public static final String UNK_SOURCE_AMOUNT = "UNK_SOURCE_AMOUNT";
		}
	}
	
	public static final class GetOrderFileHeaderFormat{
		public static final String SERVICE_NAME = "COS_GET_ORDER_FILE_FORMAT_HEADER";
		public static final class Input{
			public static final String FORMAT_ID = TransactionConstants.FORMAT_ID_GENERAL_KEY;
		}
		public static final class Output{
			public static final String HEADER_FORMATS = "HEADER_FORMATS";
			
		}
	}
	
	public static final class GetOrderFileDetailFormat{
		public static final String SERVICE_NAME = "COS_GET_ORDER_FILE_FORMAT_DETAIL";
		public static final class Input{
			public static final String FORMAT_ID = TransactionConstants.FORMAT_ID_GENERAL_KEY;
		}
		public static final class Output{
			public static final String DETAIL_FORMAT = "DETAIL_FORMAT"; 
		}
	}
	
	public static final class GetOrderFileFooterFormat{
		public static final String SERVICE_NAME = "COS_GET_ORDER_FILE_FORMAT_FOOTER";
		public static final class Input{
			public static final String FORMAT_ID = TransactionConstants.FORMAT_ID_GENERAL_KEY;
		}
		public static final class Output{
			public static final String FOOTER_FORMATS = "FOOTER_FORMATS"; 
		}
	}
	
	public static final class GetOrderDatabaseFields {
		public static final String SERVICE_NAME = "COS_GET_ORDER_FILE_DATABASE_FIELDS";
		public static final class Input{
			public static final String GET_ALL_FIELDS = "GET_ALL_FIELDS";
		}
		public static final class Output{
			public static final String FIELDS = "FIELDS";
		}
	}
	
	public static final class GetOrderServiceFields {
		public static final String SERVICE_NAME = "COS_GET_ORDER_FILE_SERVICE_FIELDS";
		public static final class Input{
			public static final String GET_ALL_FIELDS = "GET_ALL_FIELDS";
		}
		public static final class Output{
			public static final String FIELDS = "FIELDS";
		}
	}
	
	public static final class InsertOrderMain{
		public static final String SERVICE_NAME = "COS_INSERT_ORDER_MAIN";
		public static final class Input{
			public static final String DIRECT_INSERT = TransactionConstants.DIRECT_INSERT_GENERAL_KEY;
			public static final String INSERT_KEYVALUE_PAIRS = TransactionConstants.INSERT_KEYVALUE_PAIRS_GENERAL_KEY;
			public static final String INSERT_PAIR_TABLE = TransactionConstants.INSERT_PAIR_TABLE_GENERAL_KEY;
			public static final String CORPORATE_CODE = CORPORATE_CODE_GENERAL_KEY;
			public static final String FTM_TRANSFER_ID = FTM_TRANSFER_ID_GENERAL_KEY; 
			public static final String SUBMIT_ID = SUBMIT_ID__GENERAL_KEY;
			public static final String CONTROL_INVOICE_NO = CONTROL_INVOICE_NO_GENERAL_KEY;
			public static final String CUSTOMER_NO = CUSTOMER_NO_GENERAL_KEY;
			public static final String CUSTOMER_NAME = CUSTOMER_NAME_GENERAL_KEY;
		}
		public static final class Output{
			public static final String RETURN_CODE = RETURN_CODE_GENERAL_KEY;
			public static final String RETURN_MESSAGE = RETURN_MESSAGE_GENERAL_KEY;
		}
	}
	
	public static final class OrderLineParser {
		public static final String SERVICE_NAME = "COS_ORDER_LINE_PARSER";
		public static final class SharedAspectKeys {
			public static final String ERROR_COUNTER = "ERROR_COUNTER";
		}
		public static final class Input{
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";
			public static final String START_LINE_NUMBER = "START_LINE_NUMBER";
			public static final String END_LINE_NUMBER = "END_LINE_NUMBER";
			public static final String DATABASE_FIELD_MAPS = "DATABASE_FIELD_MAPS";
			public static final String SERVICE_FIELD_MAPS = "SERVICEC_FIELD_MAPS";
			public static final String HEADER_FORMAT_DETAILS = "HEADER_FORMAT_DETAILS";
			public static final String DETAIL_FORMAT_DETAILS = "DETAIL_FORMAT_DETAILS";
			public static final String FOOTER_FORMAT_DETAILS = "FOOTER_FORMAT_DETAILS";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String COMMIT_COUNT = "COMMIT_COUNT";
			public static final String ERROR_THRESHOLD = "ERROR_THRESHOLD";
			public static final String FTM_ID = "FTM_ID";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String SERVICE_NAME = "SERVICE_NAME";
			public static final String CONTROL_LOOP_COUNT = "CONTROL_LOOP_COUNT";
			public static final String LAST_FIELD_HAS_DYNAMIC_LENGTH = "LAST_FIELD_HAS_DYNAMIC_LENGTH";
			//public static final String CONTROL_INVOICE_NO = "CONTROL_INVOICE_NO";
			//public static final String LOAD_ONLY_WITH_STANDING_ORDER = "LOAD_ONLY_WITH_STANDING_ORDER";
		}
		public static final class Output{
			public static final String ISSUCCESSFUL = "ISSUCCESSFUL";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
			public static final String INFORMATION = "INFORMATION";
			public static final String HEADER_ORDER_DATE = "HEADER_ORDER_DATE";
			public static final String HEADER_CUSTOMER_NO = "HEADER_CUSTOMER_NO";
			public static final String HEADER_CUSTOMER_BANK = "HEADER_CUSTOMER_BANK";
			public static final String HEADER_CUSTOMER_BRANCH = "HEADER_CUSTOMER_BRANCH";
			public static final String HEADER_CUSTOMER_ACCOUNT_NO = "HEADER_CUSTOMER_ACCOUNT_NO";
			public static final String PROCESSED_LINE_COUNT = "PROCESSED_LINE_COUNT";
			public static final String PROCESSED_TRY_LINE_COUNT = "PROCESSED_TRY_LINE_COUNT";
			public static final String PROCESSED_USD_LINE_COUNT = "PROCESSED_USD_LINE_COUNT";
			public static final String PROCESSED_EUR_LINE_COUNT = "PROCESSED_EUR_LINE_COUNT";
			public static final String PROCESSED_TRY_AMOUNT = "PROCESSED_TRY_AMOUNT";
			public static final String PROCESSED_USD_AMOUNT = "PROCESSED_USD_AMOUNT";
			public static final String PROCESSED_EUR_AMOUNT = "PROCESSED_EUR_AMOUNT";
			public static final String FOOTER_TRY_AMOUNT = "FOOTER_TRY_AMOUNT";
			public static final String FOOTER_USD_AMOUNT = "FOOTER_USD_AMOUNT";
			public static final String FOOTER_EUR_AMOUNT = "FOOTER_EUR_AMOUNT";
			public static final String FOOTER_TRY_LINE_COUNT = "FOOTER_TRY_LINE_COUNT";
			public static final String FOOTER_USD_LINE_COUNT = "FOOTER_USD_LINE_COUNT";
			public static final String FOOTER_EUR_LINE_COUNT = "FOOTER_EUR_LINE_COUNT";
			public static final String CUSTOMER_NO = "CUSTOMER_NO";
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
		}
	}	
	
	public static final class OrderMainLoading{
		public static final String SERVICE_NAME = "COS_BATCH_ORDER_LOADING";
	}
	
	public static final class DeleteWaitedInvoice{
		public static final String SERVICE_NAME = "ICS_DELETE_WAITED_INVOICE";
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";
			
		}
		public static final class Output{
			
		}
	}
	
	public static final class InsertFileErrorLog {
		public static final String SERVICE_NAME = "ICS_INSERT_FILE_ERROR_LOG";
		public static final class Input {
			public static final String FTM_ID = "FTM_ID";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String FTM_TRANSFER_ID = "FTM_TRANSFER_ID";
			public static final String LINE_NUMBER = "LINE_NUMBER";
			public static final String LINE = "LINE";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
		}
		public static final class Output {
			
		}
	}
	
	public static final class CorporateGeneralBatchSubmit {
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String HEADER_DETAILS = "HEADER_DETAILS";
			public static final String BODY_DETAILS = "BODY_DETAILS";
			public static final String FOOTER_DETAILS = "FOOTER_DETAILS";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String FTM_PROCESS_ID = "FTM_PROCESS_ID";
			public static final String DATABASE_FIELDS = "DATABASE_FIELDS";
			public static final String SERVICE_FIELDS = "SERVICE_FIELDS";
			public static final String BATCH_PARAMETERS = "BATCH_PARAMETERS";
			public static final String INFORM_INDICATOR = "INFORM_INDICATOR";
			public static final String LINE_NUMBER = "LINE_NUMBER";
			public static final String LOADING_BATCH_SUBMIT_ID = "LOADING_BATCH_SUBMIT_ID";
			public static final String LOADING_FTM_SEQUENCE_NUMBER = "LOADING_FTM_SEQUENCE_NUMBER";		
		}
		public static final class Output{
			public static final String RESULT = "RESULT";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
			public static final String AFTER_PROCESS_LINE_NUMBER = "AFTER_PROCESS_LINE_NUMBER";
		}
	}
	
	public static final class StartCorporateBatch {
		public static final String SERVICE_NAME = "COS_CORPORATE_BATCH_STARTER";
		public static final class Input{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String FORMAT_ID = "FORMAT_ID";			
			public static final String FTM_ID = "FTM_ID";			
			public static final String BATCH_NAME = "BATCH_NAME";
			public static final String PROCESS_DATE = "PROCESS_DATE";
			public static final String PROCESS_DATE_LONG_DATE_TIME_FORMAT = "PROCESS_DATE_LONG_DATE_TIME_FORMAT";
			public static final String INFORM_INDICATOR = "INFORM_INDICATOR";
			public static final String FILE_TRANSFER_ID = "FILE_TRANSFER_ID";
			public static final String TRANSFER_TYPE = "TRANSFER_TYPE";
			public static final String LOADING_BATCH_SUBMIT_ID = "LOADING_BATCH_SUBMIT_ID";
			public static final String LOADING_FTM_SEQUENCE_NUMBER = "LOADING_FTM_SEQUENCE_NUMBER";
			public static final String FILE_CONSTANT = "FILE_CONSTANT";
			public static final String FILE_NAME = "FILE_NAME";
		}
		public static final class Output{
			public static final String CORPORATE_CODE = "CORPORATE_CODE";
			public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
			public static final String RESULT = "RESULT";
			public static final String ERROR_CODE = "ERROR_CODE";
			public static final String ERROR_MESSAGE = "ERROR_MESSAGE";
		}
	}
	
	public static final class CreateLoadingConfirmationStarter {
		public static final String SERVICE_NAME = "COS_CREATE_LOADING_CONFIRMATION_STARTER";
		public static final class Input{
			public static final String DATE = CONFIRMATION_BATCH_DATE_GENERAL_KEY;
			public static final String CORPORATE_CODE = CONFIRMATION_BATCH_CORPORATE_CODE_GENERAL_KEY;
			public static final String LOADING_BATCH_SUBMIT_ID = CONFIRMATION_BATCH_LOADING_SUBMIT_ID_GENERAL_KEY;
			public static final String LOADING_FTM_SEQUENCE_NUMBER = CONFIRMATION_BATCH_LOADING_FTM_SEQUENCE_NUMBER_GENERAL_KEY;
			public static final String INDICATOR = CONFIRMATION_BATCH_INDICATOR_GENERAL_KEY;
			public static final String FILE_TYPE_CONSTANT = CONFIRMATION_BATCH_FILE_TYPE_CONSTANT_GENERAL_KEY;
			public static final String FILE_NAME = CONFIRMATION_FILE_NAME_GENERAL_KEY; 
		}
		public static final class Output{
			public static final String RESULT = CONFIRMATION_BATCH_RESPONSE_RESULT_GENERAL_KEY;
			public static final String ERROR_CODE = CONFIRMATION_BATCH_RESPONSE_ERROR_CODE_GENERAL_KEY;
			public static final String ERROR_MESSAGE = CONFIRMATION_BATCH_RESPONSE_ERROR_MESSAGE_GENERAL_KEY;			
		}
	}
	
	public static final class CreatePaymentsConfirmationStarter {
		public static final String SERVICE_NAME = "COS_CREATE_PAYMENTS_CONFIRMATION_STARTER";
		public static final class Input{
			public static final String DATE = CONFIRMATION_BATCH_DATE_GENERAL_KEY;
			public static final String CORPORATE_CODE = CONFIRMATION_BATCH_CORPORATE_CODE_GENERAL_KEY;
			public static final String LOADING_BATCH_SUBMIT_ID = CONFIRMATION_BATCH_LOADING_SUBMIT_ID_GENERAL_KEY;
			public static final String LOADING_FTM_SEQUENCE_NUMBER = CONFIRMATION_BATCH_LOADING_FTM_SEQUENCE_NUMBER_GENERAL_KEY;
			public static final String INDICATOR = CONFIRMATION_BATCH_INDICATOR_GENERAL_KEY;
			public static final String FILE_TYPE_CONSTANT = CONFIRMATION_BATCH_FILE_TYPE_CONSTANT_GENERAL_KEY;
			public static final String SEQUENCE_NUMBER = "SEQUENCE_NUMBER";
			public static final String FILE_NAME = CONFIRMATION_FILE_NAME_GENERAL_KEY; 
		}
		public static final class Output{
			public static final String RESULT = CONFIRMATION_BATCH_RESPONSE_RESULT_GENERAL_KEY;
			public static final String ERROR_CODE = CONFIRMATION_BATCH_RESPONSE_ERROR_CODE_GENERAL_KEY;
			public static final String ERROR_MESSAGE = CONFIRMATION_BATCH_RESPONSE_ERROR_MESSAGE_GENERAL_KEY;			
		}
	}
	
	public static final class CreateEodPaymentsConfirmationStarter {
		public static final String SERVICE_NAME = "COS_CREATE_EOD_PAYMENTS_CONFIRMATION_STARTER";
		public static final class Input{
			public static final String DATE = CONFIRMATION_BATCH_DATE_GENERAL_KEY;
			public static final String CORPORATE_CODE = CONFIRMATION_BATCH_CORPORATE_CODE_GENERAL_KEY;
			public static final String LOADING_BATCH_SUBMIT_ID = CONFIRMATION_BATCH_LOADING_SUBMIT_ID_GENERAL_KEY;
			public static final String LOADING_FTM_SEQUENCE_NUMBER = CONFIRMATION_BATCH_LOADING_FTM_SEQUENCE_NUMBER_GENERAL_KEY;
			public static final String INDICATOR = CONFIRMATION_BATCH_INDICATOR_GENERAL_KEY;
			public static final String FILE_TYPE_CONSTANT = CONFIRMATION_BATCH_FILE_TYPE_CONSTANT_GENERAL_KEY;
			public static final String FILE_NAME = CONFIRMATION_FILE_NAME_GENERAL_KEY;
		}
		public static final class Output{
			public static final String RESULT = CONFIRMATION_BATCH_RESPONSE_RESULT_GENERAL_KEY;
			public static final String ERROR_CODE = CONFIRMATION_BATCH_RESPONSE_ERROR_CODE_GENERAL_KEY;
			public static final String ERROR_MESSAGE = CONFIRMATION_BATCH_RESPONSE_ERROR_MESSAGE_GENERAL_KEY;			
		}
	}
	
	public static final class ParallelCall {
		public static final class Input {
			public static final String T_SERVICE_NAME = "T_SERVICE_NAME";
			public static final String T_TASKS = "T_TASKS";
			public static final String T_TASK_INDEX = "T_TASK_INDEX"; 
		}
		
		public static final class Output {
			public static final String T_SERVICE_NAME = "T_SERVICE_NAME";
			public static final String T_TASK_INDEX = "T_TASK_INDEX";
			public static final String T_SUCCESSFUL = "T_SUCCESSFUL";
			public static final String T_RESULTS = "T_RESULTS";
		}
	}
	
	public static final class LockOrdersForProcess {
		public static final String SERVICE_NAME = "COS_LOCK_ORDERS_FOR_PROCESS";
		public static final class Input{
			public static final String MAIN_TX_NO = "MAIN_TX_NO";
			public static final String UPDATE_COMMAND = "UPDATE_COMMAND";
			public static final String PROCESS_DATE = "PROCESS_DATE";
		}
		public static final class Output{			
		}
	}
	
	//LockOrdersForProcess

	public static final String DIRECT_INSERT_GENERAL_KEY = "DIRECT_INSERT";
	public static final String INSERT_KEYVALUE_PAIRS_GENERAL_KEY = "INSERT_KEYVALUE_PAIRS";
	public static final String INSERT_PAIR_TABLE_GENERAL_KEY = "INSERT_PAIR_TABLE";
	public static final String SUBMIT_ID__GENERAL_KEY = "SUBMIT_ID";
	public static final String COMMAND_GENERAL_KEY = "COMMAND";
	
	public static final String FORMAT_ID_GENERAL_KEY = "FORMAT_ID";
	
	public static final String CONFIRMATION_BATCH_DATE_GENERAL_KEY = "DATE";
	public static final String CONFIRMATION_BATCH_CORPORATE_CODE_GENERAL_KEY = "CORPORATE_CODE";
	public static final String CONFIRMATION_BATCH_LOADING_SUBMIT_ID_GENERAL_KEY = "LOADING_BATCH_SUBMIT_ID";
	public static final String CONFIRMATION_BATCH_LOADING_FTM_SEQUENCE_NUMBER_GENERAL_KEY = "LOADING_FTM_SEQUENCE_NUMBER";
	public static final String CONFIRMATION_BATCH_INDICATOR_GENERAL_KEY = "INDICATOR";
	public static final String CONFIRMATION_BATCH_RESPONSE_RESULT_GENERAL_KEY = "RESULT";
	public static final String CONFIRMATION_BATCH_RESPONSE_ERROR_CODE_GENERAL_KEY = "ERROR_CODE";
	public static final String CONFIRMATION_BATCH_RESPONSE_ERROR_MESSAGE_GENERAL_KEY = "ERROR_MESSAGE";
	public static final String CONFIRMATION_BATCH_FILE_TYPE_CONSTANT_GENERAL_KEY = "FILE_TYPE_CONSTANT";
	public static final String CONFIRMATION_FILE_NAME_GENERAL_KEY = "FILE_NAME";
	
	public static final String CONFIRMATION_EMAIL_LOADING_SUBMIT_ID_GENERAL_KEY = "LOADING_BATCH_SUBMIT_ID";
	public static final String CONFIRMATION_EMAIL_LOADING_FTM_SEQUENCE_NUMBER_GENERAL_KEY = "LOADING_FTM_SEQUENCE_NUMBER";
	public static final String CONFIRMATION_EMAIL_LOADING_FTM_ID_GENERAL_KEY = "LOADING_FTM_ID";
	
	public static final String CONTROL_INVOICE_NO_GENERAL_KEY = "CONTROL_INVOICE_NO";
	public static final String LOAD_ONLY_WITH_STANDING_ORDER_GENERAL_KEY = "LOAD_ONLY_WITH_STANDING_ORDER";
	
	public static final String RETURN_CODE_GENERAL_KEY = "RETURN_CODE";
	public static final String RETURN_MESSAGE_GENERAL_KEY = "RETURN_MESSAGE";
	
	public static final String KeepSession = "KeepSession";
	public static final String CORPORATE_CODE_GENERAL_KEY = "CORPORATE_CODE";
	public static final String CUSTOMER_NO_GENERAL_KEY = "CUSTOMER_NO";
	public static final String CUSTOMER_NAME_GENERAL_KEY = "CUSTOMER_NAME";
	public static final String FTM_TRANSFER_ID_GENERAL_KEY = "FTM_TRANSFER_ID";
}
