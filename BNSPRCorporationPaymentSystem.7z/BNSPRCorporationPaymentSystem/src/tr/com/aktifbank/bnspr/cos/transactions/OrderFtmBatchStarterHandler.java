package tr.com.aktifbank.bnspr.cos.transactions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.sql.SQLException;
import java.util.Date;

import javax.net.ssl.HttpsURLConnection;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public final class OrderFtmBatchStarterHandler extends RequestHandler {

	private static final class BagKeys {
		public static final short CORPORATECODE = 1;
		public static final short FILETRANSFERID = 2;
		public static final short BATCHNAME = 3;
		public static final short TRANSFERTYPE = 4;
		public static final short FTMID = 5;
		public static final short FTMTRANSFERID = 6;
		public static final short ERRORCODE = 8;
		public static final short ERRORMESSAGE = 9;
		public static final short TRANSFERSTATUS = 10;
		public static final short BATCHSUBMITID = 11;
		public static final short ORDERFILELOGOID = 12;		
	} 
	
	private static final String NOPARAMETER = "-1";
	private static final String IS_BITOSIT = "Y";

	public OrderFtmBatchStarterHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		logger.info("Order FTM Starter Input Map : ".concat(input.toString()));
		String ftmId = getFtmIdFromGMMap(input);
		logger.info("Get FTM Id Step Succeeded.");
		bag.put(BagKeys.FTMID, ftmId);
		BigDecimal ftmTransferId = getFtmTransferIdFromInputMap(input);
		logger.info("Get FTM Transfer Id Step Succeeded.");
		super.bag.put(BagKeys.FTMTRANSFERID, ftmTransferId);

		CorporateFileTransfer corporateFileTransfer = getCorporateFileTransfers(ftmId);
		logger.info("Corporate File Transfer Fetch Step Succeeded");
		if(corporateFileTransfer == null){
			throw new BatchComponentException(BusinessException.CORPORATEFILETRANSFERNOTFOUND, ftmId);
		}
		String fileTransferId = corporateFileTransfer.getFileTransferId();
		logger.info("File Transfer Id Step Succeeded. File Transfer Id : ".concat(fileTransferId));
		super.bag.put(BagKeys.FILETRANSFERID, fileTransferId);
		short transferType = corporateFileTransfer.getTransferType();
		logger.info("Transfer Type Step Succeeded. Transfer Type : ".concat(String.valueOf(transferType)));
		bag.put(BagKeys.TRANSFERTYPE, transferType);

		String corporateCode = corporateFileTransfer.getCorporateCode();
		logger.info("Corporate Code Step Succeeded. Corporate Code : ".concat(corporateCode));
		bag.put(BagKeys.CORPORATECODE, corporateCode);
		
		
		if (isCorporateActive(corporateCode)) {
			logger.info("Corporate is active.");
			// No problem
		} else {
			throw new BatchComponentException(BusinessException.CORPORATEISNOTACTIVE, corporateCode);			
		}
		
		if (IS_BITOSIT.equals(CommonHelper.getValueOfParameter("BITOSIT_CORPORATE_CODE", corporateCode))) {
			String serviceUrl =CommonHelper.getValueOfParameter("BITOSIT_SERVICE_URL", corporateCode);
			String fileName =input.getString("FILE_NAME");
			String hash =input.getMap("HASHCODES")!=null ? input.getMap("HASHCODES").getString("SHA-256").toUpperCase():"";

			if (verifyFileHashForBitosit(serviceUrl, fileName, hash)) {
				logger.info("File Hash is ok");

			}else {
				throw new BatchComponentException(BusinessException.FILEHASHMISMATCH);			
			}
		}
		
		String batchName = corporateFileTransfer.getBatchName();
		bag.put(BagKeys.BATCHNAME, batchName);
		GMMap batchDetails = getBatchDetails(corporateCode, batchName);
		String batchOid = getBatchOidFromBatchDetails(batchDetails);
		GMMap batchParameters = getBatchParameters(batchOid);
		logger.info("Batch information fetch step completed.");
		String serviceName = getServiceNameFromBatchDetail(batchDetails);
		
		String submitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		bag.put(BagKeys.BATCHSUBMITID, submitId);
		
		GMMap submitMap = new GMMap();
		
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME, batchName);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE, corporateCode);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID, submitId);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.COMMIT_COUNT, getCommitCountFromBatchDetail(batchDetails));
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.FORMAT_OID, corporateFileTransfer.getFormatId());
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.FTM_ID, ftmId);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.FTM_TRANSFER_ID, ftmTransferId);
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.THREAD_COUNT, getThreadCountFromBatchDetail(batchDetails));
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.THRESHOLD, batchDetails.getInt(TransactionConstants.GetOrderBatchDetail.Output.THRESHOLD));
		String composedBatchParameters = getComposedBatchParameters(batchParameters);
		if (!composedBatchParameters.equals(NOPARAMETER)) {
			submitMap.put(
					TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS,
					composedBatchParameters);
		}
		bag.put(BagKeys.TRANSFERSTATUS, DatabaseConstants.TransferStatuses.SUBMITTED);
		insertOrderFileLog();
		submitMap.put(TransactionConstants.GeneralBatchSubmit.Input.ORDER_FILE_LOG_OID, (String)bag.get(BagKeys.ORDERFILELOGOID));
		logger.info("Calling batch submit service");
		callBatchSubmitService(serviceName, submitMap);
		
		logger.info("Batch submit succeeded.");
		
		output.put(TransactionConstants.FtmBatchStarter.Output.SUBMIT_ID,
				submitId);
	}

	private void insertOrderFileLog() {
		try {
			OrderFileLog incomingOrderFile = new OrderFileLog();
			incomingOrderFile.setStatus(true);
			if(bag.containsKey(BagKeys.CORPORATECODE)){
				incomingOrderFile.setCorporateCode((String)bag.get(BagKeys.CORPORATECODE));
			}
			if(bag.containsKey(BagKeys.FILETRANSFERID)){
				incomingOrderFile.setFileTransferId((String)bag.get(BagKeys.FILETRANSFERID));
			}
			if(bag.containsKey(BagKeys.BATCHNAME)){
				incomingOrderFile.setBatchName((String)bag.get(BagKeys.BATCHNAME));
			}
			if(bag.containsKey(BagKeys.TRANSFERTYPE)){
				incomingOrderFile.setTransferType((Short)bag.get(BagKeys.TRANSFERTYPE));
			}
			if(bag.containsKey(BagKeys.TRANSFERSTATUS)){
				incomingOrderFile.setTransferStatus((Byte)bag.get(BagKeys.TRANSFERSTATUS));
			}
			if(bag.containsKey(BagKeys.FTMID)){
				incomingOrderFile.setFtmId((String)bag.get(BagKeys.FTMID));
			}
			if(bag.containsKey(BagKeys.FTMTRANSFERID)){
				incomingOrderFile.setFtmSequenceNumber((BigDecimal)bag.get(BagKeys.FTMTRANSFERID));
			}
			if(bag.containsKey(BagKeys.BATCHSUBMITID)){
				incomingOrderFile.setBatchSubmitId((String)bag.get(BagKeys.BATCHSUBMITID));
			}
			if(bag.containsKey(BagKeys.ERRORCODE)){
				incomingOrderFile.setErrorCode((String)bag.get(BagKeys.ERRORCODE));
			}
			if(bag.containsKey(BagKeys.ERRORMESSAGE)){
				incomingOrderFile.setErrorDesc((String)bag.get(BagKeys.ERRORMESSAGE));
			}
			incomingOrderFile.setLogDate(CommonHelper.getLongDateTimeString(new Date()));

			super.getHibernateSession().save(incomingOrderFile);
			bag.put(BagKeys.ORDERFILELOGOID, incomingOrderFile.getOid());
			super.getHibernateSession().flush();
		} catch (Exception e) {
			logger.error(System.currentTimeMillis(), e);
		}
	}
	
	@Override
	protected void handleError(Throwable e, GMMap output){
		logger.error(System.currentTimeMillis(), e);
		bag.put(BagKeys.TRANSFERSTATUS, DatabaseConstants.TransferStatuses.SUBMITFAILURE);
		
		String errorMessage = null;
		if (((BatchComponentException)e).getCode() == BusinessException.FILEHASHMISMATCH.getCode()) {
			String getErrorDescQuery = QueryRepository.OrderCorporationDefinitionServicesRepository.ERROR_MESSAGE_QUERY;
			errorMessage = DALUtil.getResult(String.format(getErrorDescQuery, BusinessException.FILEHASHMISMATCH.getCode()));	
		} else {
			errorMessage = CommonHelper.getStringifiedException(e);
		}
		
		if(errorMessage != null && errorMessage.length() >= 4000)
			errorMessage = errorMessage.substring(0 ,3950);
		bag.put(BagKeys.ERRORMESSAGE, errorMessage);
		
		if (e instanceof BatchComponentException) {
			bag.put(BagKeys.ERRORCODE, String.valueOf(((BatchComponentException)e).getCode()));
		}
		insertOrderFileLog();
	}

	private String getComposedBatchParameters(GMMap batchParameters) {
		return batchParameters
				.getString(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS, NOPARAMETER);
	}

	private void callBatchSubmitService(String serviceName, GMMap submitMap) throws Exception {
		super.callGraymoundServiceAsync(serviceName, submitMap);
	}

	private int getCommitCountFromBatchDetail(GMMap batchDetails) {
		return batchDetails
				.getInt(TransactionConstants.GetOrderBatchDetail.Output.COMMIT_COUNT);
	}

	private int getThreadCountFromBatchDetail(GMMap batchDetails) {
		return batchDetails
				.getInt(TransactionConstants.GetOrderBatchDetail.Output.THREAD_COUNT);
	}

	private BigDecimal getFtmTransferIdFromInputMap(GMMap fTMMap) {
		return fTMMap
				.getBigDecimal(TransactionConstants.FtmBatchStarter.Input.FTM_TRANSFER_ID);
	}

	private String getServiceNameFromBatchDetail(GMMap batchDetails) {
		return batchDetails
				.getString(TransactionConstants.GetOrderBatchDetail.Output.SERVICE_NAME);
	}

	private GMMap getBatchParameters(String batchOid) {
		GMMap getBatchParametersRequest = new GMMap();
		getBatchParametersRequest
				.put(TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID,
						batchOid);
		return super.callGraymoundServiceInSession(
				TransactionConstants.GetBatchParameters.SERVICE_NAME,
				getBatchParametersRequest);
	}

	private String getBatchOidFromBatchDetails(GMMap batchDetails) {
		return batchDetails
				.getString(TransactionConstants.GetOrderBatchDetail.Output.CORPORATE_BATCH_PROCESS_OID);
	}

	private GMMap getBatchDetails(String corporateCode, String batchName) {
		GMMap getBatchDetailRequest = new GMMap();
		getBatchDetailRequest
				.put(TransactionConstants.GetOrderBatchDetail.Input.BATCH_NAME,
						batchName);
		getBatchDetailRequest.put(
				TransactionConstants.GetOrderBatchDetail.Input.CORPORATE_CODE,
				corporateCode);
		return super.callGraymoundServiceInSession(
				TransactionConstants.GetOrderBatchDetail.SERVICE_NAME,
				getBatchDetailRequest);
	}

	private Boolean isCorporateActive(String corporateCode) {
		return CommonBusinessOperations.isCorporateActive(corporateCode);
	}

	private CorporateFileTransfer getCorporateFileTransfers(String ftmId)
			throws SQLException {
		Criteria criteria = super.getHibernateSession().createCriteria(CorporateFileTransfer.class);
		criteria.add(Restrictions.eq("ftmId",  new BigDecimal(ftmId)));
		criteria.add(Restrictions.eq("transferType", (short)DatabaseConstants.TransferTypes.OrderLoading));
		criteria.add(Restrictions.eq("status", true));
		criteria.add(Restrictions.or(Restrictions.eq("complexFileTransfer", false), Restrictions.isNull("complexFileTransfer")));
		return (CorporateFileTransfer)criteria.uniqueResult();
	}

	private String getFtmIdFromGMMap(GMMap inputMap) throws Exception {
		String ftmId = "";
		if (inputMap
				.containsKey(TransactionConstants.FtmBatchStarter.Input.FTM_ID)) {
			Object notCastedFtmId = inputMap
					.get(TransactionConstants.FtmBatchStarter.Input.FTM_ID);
			if (notCastedFtmId.getClass() == String.class) {
				ftmId = (String) notCastedFtmId;
			} else {
				throw new Exception(
						String.format(
								"Type of input parameter FTM_ID is %s instead of String",
								notCastedFtmId.getClass().getName()));
			}
		} else {
			throw new Exception("FTM_ID has not been specified in request map.");
		}
		return ftmId;
	}
	
    public static boolean verifyFileHashForBitosit(String serviceUrl, String fileName, String hash) {

        String verifyUrl = serviceUrl + "/" + fileName + "/" + hash;
        String result = "";

        try {
              URL url = new URL(verifyUrl);
      		URLConnection conn ;

              if (url.openConnection() instanceof HttpsURLConnection ) {
      			conn = (HttpsURLConnection) url.openConnection();
      			((HttpURLConnection) conn).setRequestMethod("GET");
      			
      		}else {
      			conn = (HttpURLConnection) url.openConnection();
      			((HttpURLConnection) conn).setRequestMethod("GET");
      		}
      		
              conn.setDoOutput(true);
              conn.setDoInput(true);
              conn.setUseCaches(false);

              BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
              result = reader.readLine();
              reader.close();

              System.out.println(result);
        } catch (Exception e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
        }
        if ("true".equals(result)) {
              return true;
        } else {
              return false;
        }
  }

}
