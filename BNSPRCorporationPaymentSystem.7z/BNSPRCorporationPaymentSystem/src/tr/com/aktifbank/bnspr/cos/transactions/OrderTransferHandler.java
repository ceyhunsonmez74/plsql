package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CariSubelerarasiHavGirisTx;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.aktifbank.bnspr.dao.OrderTransaction;
import tr.com.aktifbank.bnspr.dao.OrderTransfer;
import tr.com.aktifbank.bnspr.dao.OrderTransferLog;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

final class ProcessedFile {
	private Boolean anyTransfer;
	private String corporateCode;
	private String batchSubmitId;
	private List<String> transferedOrderOidList = new ArrayList<String>();	
	
	public Boolean isAnyTransfer() {
		return anyTransfer;
	}
	public void setAnyTransfer(Boolean anyTransfer) {
		this.anyTransfer = anyTransfer;
	}
	public String getCorporateCode() {
		return corporateCode;
	}
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	public String getBatchSubmitId() {
		return batchSubmitId;
	}
	public void setBatchSubmitId(String batchSubmitId) {
		this.batchSubmitId = batchSubmitId;
	}
	public List<String> getTransferedOrderOidList() {
		return transferedOrderOidList;
	}
	public void setTransferedOrderOidList(List<String> transferedOrderOidList) {
		this.transferedOrderOidList = transferedOrderOidList;
	}
	public void addToTransferedOrderOidList(String oid) {
		this.transferedOrderOidList.add(oid);
	}
}

public class OrderTransferHandler extends RequestHandler {

	public OrderTransferHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
	
		String transferType = input.getString(TransactionConstants.OrderTransfersApproved.Input.TRANSFER_TYPE);
		Date processDate = input.getDate(TransactionConstants.OrderTransfersApproved.Input.PROCESS_DATE);
		List<BigDecimal> transactionTxList = (List<BigDecimal>)input.get(TransactionConstants.OrderTransfersApproved.Input.TRANSACTION_TX_LIST);
		String transferTxNo = null, shortProcessDate = null;
		List<OrderTransferLog> approvedTransferLogList = null;
		List<OrderTransferLog> failedTransferLogList = null;
		List<OrderMain> previouslyFailedOrderList = null;
		Map<String, ProcessedFile> processedFileMap = new HashMap<String, ProcessedFile>();
		String batchSubmitId = null; 
		String amountOrder = null;
		ProcessedFile processedFile = null, newProcessedFile = null;
		GMMap updateTransactionStatusRequest = new GMMap();	
		
		//Boolean isEndOfDay = (Boolean) DALUtil.callNoParameterFunction("{? = call pkg_batch.gun_sonu_mu}", Types.BOOLEAN);
		//String endOfDay = DALUtil.getResult(String.format("SELECT end_of_day FROM bnspr.gnl_sistem_bilgi_pr"));	
		
		if (transferType.equals(GeneralConstants.APPROVALTRANSFER)) {				
			
			for (BigDecimal transactionTx : transactionTxList) {
				OrderTransaction orderTransaction = (OrderTransaction)super.getHibernateSession().createCriteria(OrderTransaction.class)
												   .add(Restrictions.eq("status", true))
												   .add(Restrictions.eq("txNo", transactionTx)).uniqueResult();
				
				try {										
					// get amount order param of corporation
					GMMap getCorpDefinitionMap = new GMMap();
					getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, orderTransaction.getCorporateCode());
					GMMap corpDefDetailsMap = super.callGraymoundServiceInSession(TransactionConstants.GetOrderCorpDef.SERVICE_NAME, getCorpDefinitionMap);
					amountOrder = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING);
					
					Criteria criteria = super.getHibernateSession().createCriteria(OrderTransferLog.class)
											   .add(Restrictions.eq("status", true))
											   .add(Restrictions.eq("mainTxNo", orderTransaction.getTxNo()))
											   .add(Restrictions.eq("orderStatus", DatabaseConstants.OrderStatuses.Approved));
					if (StringUtils.isNotBlank(amountOrder)) {
						if (amountOrder.equals("D"))
							criteria = criteria.addOrder(Order.desc("amount"));
						else if (amountOrder.equals("A"))
							criteria = criteria.addOrder(Order.asc("amount"));	
					} else 
						criteria = criteria.addOrder(Order.asc("lineNumber"));					
					
					approvedTransferLogList = criteria.list();
					
					super.callServiceWithSessionOption(TransactionConstants.LockOrdersForProcess.SERVICE_NAME, false, 
							TransactionConstants.LockOrdersForProcess.Input.MAIN_TX_NO, orderTransaction.getTxNo(),
							TransactionConstants.LockOrdersForProcess.Input.UPDATE_COMMAND, GeneralConstants.AFTER_APP_UPDATE_COMMAND);
					
					List<String> transferedOrderOidList = new ArrayList<String>();	
					
					for (OrderTransferLog transferLog : approvedTransferLogList) {
						try {
							// g�n sonu ise hi�bir i�lemi ger�ekle�tirme
							//if (!StringUtils.isEmpty(endOfDay) && endOfDay.equals("E"))
							//	continue;
							
							GMMap doControlsRequest = new GMMap();
							doControlsRequest.put(TransactionConstants.DoLoadingAndPaymentControls.Input.CONTROL_TYPE, DatabaseConstants.ControlTypes.PAYMENT);
							doControlsRequest.put(TransactionConstants.DoLoadingAndPaymentControls.Input.CONTROL_OBJECT, transferLog);			
							GMMap doControlsResponse = super.callGraymoundServiceInSession(TransactionConstants.DoLoadingAndPaymentControls.SERVICE_NAME, doControlsRequest);
								
							if (doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS).equals(DatabaseConstants.OrderStatuses.ReadyToTransfer)) {
								try {
									transferTxNo = CommonHelper.getNewTransactionNo();					
									// pkg_cs.cs_das_islem kulland��� tablolar� lock'lamams� i�in her toplu �deme i�lemi i�in tek tek �a��r�lmal� ve ��k��ta commit'lemeli 
									GMMap doTransferAndUpdateRequest = new GMMap();			
									doTransferAndUpdateRequest.put(TransactionConstants.DoTransferAndUpdate.Input.TRANSFER_LOG_OBJECT, transferLog);
									doTransferAndUpdateRequest.put(TransactionConstants.DoTransferAndUpdate.Input.TRANSFER_TX_NO, transferTxNo);
									GMMap doTransferAndUpdateResponse = super.callGraymoundServiceOutsideSession(TransactionConstants.DoTransferAndUpdate.SERVICE_NAME, doTransferAndUpdateRequest);
									
									if (doTransferAndUpdateResponse.getBoolean(TransactionConstants.DoTransferAndUpdate.Output.IS_TRANSFER_SUCCESSFUL))
										transferedOrderOidList.add(transferLog.getOrderMainOid());	
									
								} catch (Throwable e) {
									String errorMessage = CommonHelper.getStringifiedException(e);
									
									if(errorMessage != null && errorMessage.length() > 1000){
										errorMessage = errorMessage.substring(0 ,950);
									}
									transferLog.setOrderStatus(DatabaseConstants.OrderStatuses.PaymentError);
									transferLog.setFailedPaymentDate(CommonHelper.getLongDateTimeString(new Date()));
									transferLog.setErrorDesc(errorMessage);
									super.getHibernateSession().update(transferLog);
									
									OrderMain order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
														.add(Restrictions.eq("status", true))
														.add(Restrictions.eq("oid", transferLog.getOrderMainOid())).uniqueResult();
									if (order != null) {
										order.setOrderStatus(DatabaseConstants.OrderStatuses.PaymentError);
										order.setFailedPaymentStatus(true);
										order.setErrorDesc(errorMessage);	
									}
									throw e;
								}
							} else if (!doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS).equals(DatabaseConstants.OrderStatuses.Transfered)) {						
								GMMap updateOrderMainAndTransferLogRequest = new GMMap();			
								updateOrderMainAndTransferLogRequest.put(TransactionConstants.UpdateOrderMainAndTransferLog.Input.OID, transferLog.getOrderMainOid());
								updateOrderMainAndTransferLogRequest.put(TransactionConstants.UpdateOrderMainAndTransferLog.Input.ORDER_STATUS, doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS));
								updateOrderMainAndTransferLogRequest.put(TransactionConstants.UpdateOrderMainAndTransferLog.Input.ERROR_DESC, doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ERROR_DESC));
								super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateOrderMainAndTransferLog.SERVICE_NAME, updateOrderMainAndTransferLogRequest);	
							}								
						} catch (Throwable e) {
							logger.error(String.format("An exception occured at OrderTransferHandler while doing transfer for order_main_oid: %s", transferLog.getOrderMainOid()));
							logger.error(System.currentTimeMillis(), e);	
						}
					}	
					
					// set transaction status to processing finished
					updateTransactionStatusRequest = new GMMap();
					updateTransactionStatusRequest.put(TransactionConstants.UpdateTransactionStatus.Input.TX_NO, orderTransaction.getTxNo());
					updateTransactionStatusRequest.put(TransactionConstants.UpdateTransactionStatus.Input.TRANSACTION_STATUS, DatabaseConstants.TransactionStatus.PROCESSING_FINISHED);
					super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateTransactionStatus.SERVICE_NAME, updateTransactionStatusRequest);
					
					batchSubmitId = orderTransaction.getBatchSubmitId();
					if (!processedFileMap.containsKey(batchSubmitId)) {
						newProcessedFile = new ProcessedFile();
						newProcessedFile.setAnyTransfer(null);
						newProcessedFile.setBatchSubmitId(batchSubmitId);
						newProcessedFile.setCorporateCode(orderTransaction.getCorporateCode());
						newProcessedFile.setTransferedOrderOidList(transferedOrderOidList);
						processedFileMap.put(batchSubmitId, newProcessedFile);
					} else {
						processedFile = processedFileMap.get(batchSubmitId);
						processedFile.setTransferedOrderOidList(transferedOrderOidList);
						processedFileMap.put(batchSubmitId, processedFile);
					}
					
				} catch (Throwable e) {
					logger.error(String.format("An exception occured at OrderTransferHandler while doing order transfer transaction for tx no: %s", orderTransaction.getTxNo()));
					logger.error(System.currentTimeMillis(), e);
				}
			}
			
			afterPaymentAction(processedFileMap.get(batchSubmitId), transferType, processDate);
			
		}
		else if (transferType.equals(GeneralConstants.FAILEDPAYMENTTRANSFER)) {
			
			previouslyFailedOrderList = super.getHibernateSession().createCriteria(OrderMain.class)
											   .add(Restrictions.eq("status", true))
											   .add(Restrictions.eq("failedPaymentStatus", true)).list();
			
			for (OrderMain orderMain : previouslyFailedOrderList) {
				try {
					// if the order had a payment error in the previous try, check whether it was successfully paid or not
					// if it was successful, set failed_payment_status to null
					if (orderMain.getOrderStatus().equals(DatabaseConstants.OrderStatuses.Transfered)) {
						GMMap updateOrderMainAndTransferLogRequest = new GMMap();			
						updateOrderMainAndTransferLogRequest.put(TransactionConstants.UpdateOrderMainAndTransferLog.Input.OID, orderMain.getOid());
						updateOrderMainAndTransferLogRequest.put(TransactionConstants.UpdateOrderMainAndTransferLog.Input.SET_FAILED_PAYMENT_TO_NULL, true);
						super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateOrderMainAndTransferLog.SERVICE_NAME, updateOrderMainAndTransferLogRequest);
					}
					
				} catch (Throwable e) {
					logger.error(String.format("An exception occured at OrderTransferHandler while doing failure transfer"));
					logger.error(System.currentTimeMillis(), e);
				}
			}			
			
			if (processDate != null)
				shortProcessDate = CommonHelper.getShortDateTimeString(processDate);	
			else 
				shortProcessDate = CommonHelper.getShortDateTimeString(new Date());	
			failedTransferLogList = super.getHibernateSession().createCriteria(OrderTransferLog.class)
										   .add(Restrictions.eq("status", true))
										   .add(Restrictions.isNotNull("orderDate"))										   
										   .add(Restrictions.ge("orderDate", shortProcessDate))
										   .add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.InsufficientBalance))
										   .add(Restrictions.lt("orderStatus", DatabaseConstants.OrderStatuses.Transfered))
										   .addOrder(Order.desc("mainTxNo")).list();
			
			super.callServiceWithSessionOption(TransactionConstants.LockOrdersForProcess.SERVICE_NAME, false, 
					TransactionConstants.LockOrdersForProcess.Input.PROCESS_DATE, shortProcessDate,
					TransactionConstants.LockOrdersForProcess.Input.UPDATE_COMMAND, GeneralConstants.FAILED_UPDATE_COMMAND);
			
			for (OrderTransferLog transferLog : failedTransferLogList) {
				try {
					// does transferLog belong to an already processed transaction
					OrderMain orderMain = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("oid", transferLog.getOrderMainOid())).uniqueResult();
					if (orderMain != null) {
						batchSubmitId = orderMain.getBatchSubmitId();
						if (!processedFileMap.containsKey(batchSubmitId)) {
							newProcessedFile = new ProcessedFile();
							newProcessedFile.setAnyTransfer(false);
							newProcessedFile.setCorporateCode(transferLog.getCorporateCode());
							newProcessedFile.setBatchSubmitId(batchSubmitId);
							
							processedFileMap.put(orderMain.getBatchSubmitId(), newProcessedFile);
							processedFile = newProcessedFile;
						} else 
							processedFile = processedFileMap.get(batchSubmitId);
					}

					// g�n sonu ise hi�bir i�lemi ger�ekle�tirme
					//if (!StringUtils.isEmpty(endOfDay) && endOfDay.equals("E"))
					//	continue;
					
					GMMap doControlsRequest = new GMMap();
					doControlsRequest.put(TransactionConstants.DoLoadingAndPaymentControls.Input.CONTROL_TYPE, DatabaseConstants.ControlTypes.PAYMENT);
					doControlsRequest.put(TransactionConstants.DoLoadingAndPaymentControls.Input.CONTROL_OBJECT, transferLog);				
					GMMap doControlsResponse = super.callGraymoundServiceInSession(TransactionConstants.DoLoadingAndPaymentControls.SERVICE_NAME, doControlsRequest);
						
					if (doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS).equals(DatabaseConstants.OrderStatuses.ReadyToTransfer)) {
						try {
							transferTxNo = CommonHelper.getNewTransactionNo();					
							// pkg_cs.cs_das_islem kulland��� tablolar� lock'lamams� i�in her toplu �deme i�lemi i�in tek tek �a��r�lmal� ve ��k��ta commit'lemeli 
							GMMap doTransferAndUpdateRequest = new GMMap();			
							doTransferAndUpdateRequest.put(TransactionConstants.DoTransferAndUpdate.Input.TRANSFER_LOG_OBJECT, transferLog);
							doTransferAndUpdateRequest.put(TransactionConstants.DoTransferAndUpdate.Input.TRANSFER_TX_NO, transferTxNo);
							GMMap doTransferAndUpdateResponse = super.callGraymoundServiceOutsideSession(TransactionConstants.DoTransferAndUpdate.SERVICE_NAME, doTransferAndUpdateRequest);
							
							//if (!processedFile.isAnyTransfer())
							if (doTransferAndUpdateResponse.getBoolean(TransactionConstants.DoTransferAndUpdate.Output.IS_TRANSFER_SUCCESSFUL)) {
								processedFile.setAnyTransfer(true);
								processedFile.addToTransferedOrderOidList(transferLog.getOrderMainOid());
								processedFileMap.put(batchSubmitId, processedFile);
							}
						} catch (Throwable e) {
							String errorMessage = CommonHelper.getStringifiedException(e);
							
							if(errorMessage != null && errorMessage.length() > 1000){
								errorMessage = errorMessage.substring(0 ,950);
							}
							transferLog.setOrderStatus(DatabaseConstants.OrderStatuses.PaymentError);
							transferLog.setFailedPaymentDate(CommonHelper.getLongDateTimeString(new Date()));
							transferLog.setErrorDesc(errorMessage);
							super.getHibernateSession().update(transferLog);
							
							OrderMain order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("oid", transferLog.getOrderMainOid())).uniqueResult();
							if (order != null) {
								order.setOrderStatus(DatabaseConstants.OrderStatuses.PaymentError);
								order.setFailedPaymentStatus(true);
								order.setErrorDesc(errorMessage);	
							}
							throw e;
						}							
					} else if (!doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS).equals(DatabaseConstants.OrderStatuses.Transfered)) {
						GMMap updateOrderMainAndTransferLogRequest = new GMMap();			
						updateOrderMainAndTransferLogRequest.put(TransactionConstants.UpdateOrderMainAndTransferLog.Input.OID, transferLog.getOrderMainOid());
						updateOrderMainAndTransferLogRequest.put(TransactionConstants.UpdateOrderMainAndTransferLog.Input.ORDER_STATUS, doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ORDER_STATUS));
						updateOrderMainAndTransferLogRequest.put(TransactionConstants.UpdateOrderMainAndTransferLog.Input.ERROR_DESC, doControlsResponse.getString(TransactionConstants.DoLoadingAndPaymentControls.Output.ERROR_DESC));
						super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateOrderMainAndTransferLog.SERVICE_NAME, updateOrderMainAndTransferLogRequest);	
					}		
				} catch (Throwable e) {
					logger.error(String.format("An exception occured at OrderTransferHandler while doing failure transfer for order_main_oid: %s", transferLog.getOrderMainOid()));
					logger.error(System.currentTimeMillis(), e);
				}
			}
			
			for (ProcessedFile pFile : processedFileMap.values()) {
				afterPaymentAction(pFile, transferType, processDate);
			}
		}
		
		super.getHibernateSession().flush();
	}

	protected void afterPaymentAction(ProcessedFile pFile, String transferType, Date processDate) {

		BigDecimal ftmSequenceNumber = null, amount = null;
		String headerOrderDate = null;
		String orderType = null, currencyCode = null, recipientName = null, recipientPhone = null, pttReferansNo = null;

		try {
			
			OrderFileLog fileLog = (OrderFileLog) super.getHibernateSession().createCriteria(OrderFileLog.class)
													.add(Restrictions.eq("status", true))
													.add(Restrictions.eq("batchSubmitId", pFile.getBatchSubmitId())).uniqueResult();
			if (fileLog != null) {
				ftmSequenceNumber = fileLog.getFtmSequenceNumber();
				headerOrderDate = fileLog.getOrderDate();
				
				GMMap failedLineCountAndFileStatusRequest = new GMMap();			
				failedLineCountAndFileStatusRequest.put(TransactionConstants.GetFailedLineCountAndFileStatus.Input.BATCH_SUBMIT_ID, pFile.getBatchSubmitId());
				GMMap failedLineCountAndFileStatusResponse = super.callGraymoundServiceOutsideSession(TransactionConstants.GetFailedLineCountAndFileStatus.SERVICE_NAME, failedLineCountAndFileStatusRequest);
				int erroneousLineCount = failedLineCountAndFileStatusResponse.getInt(TransactionConstants.GetFailedLineCountAndFileStatus.Output.FAILED_LINE_COUNT);
				String currentFileStatus = failedLineCountAndFileStatusResponse.getString(TransactionConstants.GetFailedLineCountAndFileStatus.Output.FILE_STATUS);
				
				fileLog.setErroneousLineCount(new BigDecimal((Integer)erroneousLineCount));
				fileLog.setFileStatus(currentFileStatus);
				super.getHibernateSession().update(fileLog);
			}				
		} catch (Throwable e) {
			logger.error("An exception occured while setting new file status in OrderTransferHandler");
			logger.error(System.currentTimeMillis(), e);			
		}		
		
		try {
			GMMap getCorpDefinitionMap = new GMMap();
			getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, pFile.getCorporateCode());
			GMMap corpDefDetailsMap = super.callGraymoundServiceInSession(TransactionConstants.GetOrderCorpDef.SERVICE_NAME, getCorpDefinitionMap);
			
			if (transferType.equals(GeneralConstants.APPROVALTRANSFER) || ( transferType.equals(GeneralConstants.FAILEDPAYMENTTRANSFER) && pFile.isAnyTransfer() ) ) {
				
				// ak�bet dosyas� olu�turulmas�
				if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.MAKE_TRANSFER_STATUS_FILE)) {						
					try {
						GMMap confirmationFileInputMap = new GMMap();
						confirmationFileInputMap.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.CORPORATE_CODE, pFile.getCorporateCode());
						confirmationFileInputMap.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.DATE, new Date());
						confirmationFileInputMap.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.LOADING_BATCH_SUBMIT_ID, pFile.getBatchSubmitId());
						confirmationFileInputMap.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.LOADING_FTM_SEQUENCE_NUMBER, ftmSequenceNumber);					
						super.callGraymoundServiceOutsideSession(TransactionConstants.CreatePaymentsConfirmationStarter.SERVICE_NAME, confirmationFileInputMap);		
					} catch (Exception e) {
						logger.error("An exception occured while creating content of payment confirmation file");
						logger.error(System.currentTimeMillis(), e);
					}												
				}	
				
				// ak�bet maili g�nderilmesi
				if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.EMAIL_TRANSFER_STATUS)) {
					GMMap composeEmailInputMap = new GMMap();
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.EMAIL_TYPE, DatabaseConstants.EmailType.PAYMENTSCONFIRMATION);
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.TRANSFER_TYPE, transferType);
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.CORPORATE_CODE, pFile.getCorporateCode());
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_BATCH_SUBMIT_ID, pFile.getBatchSubmitId());
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_FTM_SEQUENCE_NUMBER, ftmSequenceNumber);
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.HEADER_ORDER_DATE, headerOrderDate);
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.PROCESS_DATE, processDate);
					super.callGraymoundServiceOutsideSession(TransactionConstants.ComposeEmail.SERVICE_NAME, composeEmailInputMap);	
				}		
				
				 // al�c�lara email g�nderilmesi
				if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.EMAIL_TO_RECIPIENT)) {
					for (String transferedOrderOid : pFile.getTransferedOrderOidList()) {
						OrderMain orderMain = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("oid", transferedOrderOid)).uniqueResult();
						if (orderMain != null) {								
							GMMap composeEmailInputMap = new GMMap();
							composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.EMAIL_TYPE, DatabaseConstants.EmailType.RECIPIENTINFORMATION);
							composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.CORPORATE_CODE, pFile.getCorporateCode());
							composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.HEADER_ORDER_DATE, headerOrderDate);
							composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.PROCESS_DATE, processDate);
							composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.ORDER_OID, transferedOrderOid);
							super.callGraymoundServiceOutsideSession(TransactionConstants.ComposeEmail.SERVICE_NAME, composeEmailInputMap);									
						}
					}
				}			
				
				if(corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.EMAIL_RECEIPT_TO_RECIPIENT)){
					for (String transferedOrderOid : pFile.getTransferedOrderOidList()) {
						OrderMain orderMain = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("oid", transferedOrderOid)).uniqueResult();
						if (orderMain != null) {
							OrderTransfer orderTransfer = (OrderTransfer) super.getHibernateSession().createCriteria(OrderTransfer.class)
																		   .add(Restrictions.eq("status", true))
																		   .add(Restrictions.eq("orderMainOid", orderMain.getOid())).uniqueResult();

							if(orderTransfer != null){
								if(!StringUtil.isEmpty(orderTransfer.getRecipientEmail())){
									List<String> emailList = Arrays.asList(orderTransfer.getRecipientEmail().split(";"));
									
									for(String email: emailList){
										GMMap composeReceiptMailInput = new GMMap();
										String fileNo = orderTransfer.getExplanation().substring(0,10);
										String subjectStr = "[EvrimRef:%s]";
										String subject = String.format(subjectStr, fileNo);
										composeReceiptMailInput.put("TRX_NO", orderTransfer.getTxNo());
										composeReceiptMailInput.put("EPOSTA", email);
										composeReceiptMailInput.put("MUSTERI_ADI", orderTransfer.getCustomerName());
										composeReceiptMailInput.put("MAIL_SUBJECT", subject);
										super.callGraymoundServiceOutsideSession("COS_EXT_SEND_RECEIPT", composeReceiptMailInput);
									}
								}
							}
						}
					}
				}

				// al�c�lara sms g�nderilmesi
				if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.SMS_TO_RECIPIENT)) {
					String corporateShortName = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.SHORT_NAME);
					String recipientInfoEft = "Say�n %s %s tarihinde %s firmas�ndan hesab�n�za %s %s tutar�nda EFT emri verilmi�tir.";
					String recipientInfoHavale = "Say�n %s %s tarihinde %s firmas�ndan hesab�n�za %s %s tutar�nda havale i�lemi ger�ekle�mi�tir.";
					String recipientInfoVirman = "Say�n %s %s tarihinde %s firmas�ndan hesab�n�za %s %s tutar�nda virman i�lemi ger�ekle�mi�tir.";
					String recipientInfoPttHavale = "Say�n %s %s tarihinde %s firmas�ndan %s %s tutar�nda PTT isme havale i�lemi ger�ekle�mi�tir. PTT referans no: %s";
					String recipientSmsContent = null;
					boolean sendSms = false;
					if (!StringUtils.isEmpty(headerOrderDate))
						headerOrderDate = CommonHelper.shortTimeStringToViewDateString(headerOrderDate);
					
					for (String transferedOrderOid : pFile.getTransferedOrderOidList()) {
						OrderMain order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("oid", transferedOrderOid)).uniqueResult();
						if (order != null) {
							orderType = order.getOrderType();
							currencyCode = order.getCurrencyCode();
							amount = order.getAmount();
							if (amount != null)
								amount = order.getAmount().setScale(2, RoundingMode.HALF_UP);
							recipientName = order.getRecipientName();	
							recipientPhone = order.getRecipientPhoneNumber();
							sendSms = false;
							
							if (!StringUtils.isEmpty(recipientPhone)) {
								
								if (orderType.equals(DatabaseConstants.OrderType.EFT) && corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_EFT)) {
									recipientSmsContent = String.format(recipientInfoEft.toString(), recipientName, headerOrderDate, corporateShortName, amount, currencyCode);
									sendSms = true;
								} else if (orderType.equals(DatabaseConstants.OrderType.Havale) && corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_HAVALE)) {
									recipientSmsContent = String.format(recipientInfoHavale.toString(), recipientName, headerOrderDate, corporateShortName, amount, currencyCode);
									sendSms = true;
								} else if (orderType.equals(DatabaseConstants.OrderType.Virman) && corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_VIRMAN)) {
									recipientSmsContent = String.format(recipientInfoVirman.toString(), recipientName, headerOrderDate, corporateShortName, amount, currencyCode);
									sendSms = true;
								} else if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale) && corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_PTT_ISME_HAVALE)) {
									CariSubelerarasiHavGirisTx cariSubelerarasiHavGirisTx = (CariSubelerarasiHavGirisTx) super.getHibernateSession().get(CariSubelerarasiHavGirisTx.class, order.getTxNo());
									if (cariSubelerarasiHavGirisTx != null)
										pttReferansNo = cariSubelerarasiHavGirisTx.getReferans();
									else
										pttReferansNo = "";
									recipientSmsContent = String.format(recipientInfoPttHavale.toString(), recipientName, headerOrderDate, corporateShortName, amount, currencyCode, pttReferansNo);
									sendSms = true;
								}
								
								if (sendSms) {
									GMMap smsServiceMap = new GMMap();
									smsServiceMap.put("MSISDN", recipientPhone);
									smsServiceMap.put("CONTENT", recipientSmsContent);
									GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsServiceMap);
								}
							}
						}
					}
				}
			}
		} catch (Throwable e) {
			logger.error("An exception occured while getting corporate definition / calling make transfer status file or email transfer status in OrderTransferHandler");
			logger.error(System.currentTimeMillis(), e);	
		}				
		
	}
}
