package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;

import com.graymound.util.GMMap;

public class CreateEodPaymentsConfirmationStarterHandler extends RequestHandler {

	public CreateEodPaymentsConfirmationStarterHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		String corporateCode = input.getString(TransactionConstants.CreateEodPaymentsConfirmationStarter.Input.CORPORATE_CODE);
		String shortProcessDate = null, batchSubmitId = null, headerOrderDate = null;
		BigDecimal ftmSequenceNumber = null;		
		Date processDate = new Date();
		
		GMMap getCorpDefinitionMap = new GMMap();
		getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
		String eodFileStatus = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.MAKE_EOD_STATUS_FILE);
				
		if (StringUtils.isNotBlank(eodFileStatus)) {

			if (eodFileStatus.equals(DatabaseConstants.EodFileType.CUMULATIVE)) {
				// toplu ak�bet dosyas� olu�tur		
				try {
					input.put(TransactionConstants.CreateEodPaymentsConfirmationStarter.Input.DATE, new Date());
					CommonBusinessOperations.executeBatchStarterHandler(input, output, DatabaseConstants.TransferTypes.EODPaymentsConfirmation, super.getHibernateSession());
				} catch (Exception e) {
					logger.error("An exception occured while creating content of eod payment confirmation file");
					logger.error(System.currentTimeMillis(), e);
				}
				
				// toplu ak�bet emaili g�nder
				if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.EMAIL_EOD_STATUS)) {
					GMMap composeEmailInputMap = new GMMap();
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.EMAIL_TYPE, DatabaseConstants.EmailType.EODPAYMENTSCONFIRMATION);
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.CORPORATE_CODE, corporateCode);
					composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.PROCESS_DATE, processDate);
					super.callGraymoundServiceInSession(TransactionConstants.ComposeEmail.SERVICE_NAME, composeEmailInputMap);	
				}
			} 
			else if (eodFileStatus.equals(DatabaseConstants.EodFileType.SEPARATE)) {
				
				shortProcessDate = CommonHelper.getShortDateTimeString(processDate);					
				List<OrderFileLog> fileList = super.getHibernateSession().createCriteria(OrderFileLog.class)
											.add(Restrictions.eq("status", true))
											.add(Restrictions.between("logDate", shortProcessDate + "000000", shortProcessDate + "235959"))
											.add(Restrictions.eq("transferType", new Short("1")))
											.add(Restrictions.eq("loadingStatus", "99"))
											.add(Restrictions.ne("fileStatus", "-1"))									
											.addOrder(Order.desc("logDate")).list();
															
				for (OrderFileLog file : fileList) {
					
					// ayr� ayr� ak�bet dosyas� olu�tur
					batchSubmitId = file.getBatchSubmitId();
					ftmSequenceNumber = file.getFtmSequenceNumber();
					headerOrderDate = file.getOrderDate();					
					try {
						GMMap confirmationFileInputMap = new GMMap();
						confirmationFileInputMap.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.CORPORATE_CODE, corporateCode);
						confirmationFileInputMap.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.DATE, new Date());
						confirmationFileInputMap.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.LOADING_BATCH_SUBMIT_ID, batchSubmitId);
						confirmationFileInputMap.put(TransactionConstants.CreatePaymentsConfirmationStarter.Input.LOADING_FTM_SEQUENCE_NUMBER, ftmSequenceNumber);					
						super.callGraymoundServiceOutsideSession(TransactionConstants.CreatePaymentsConfirmationStarter.SERVICE_NAME, confirmationFileInputMap);		
					} catch (Exception e) {
						logger.error("An exception occured while creating content of payment confirmation file");
						logger.error(System.currentTimeMillis(), e);
					}
					
					// ayr� ayr� ak�bet emaili g�nder
					if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.EMAIL_EOD_STATUS)) {
						GMMap composeEmailInputMap = new GMMap();
						composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.EMAIL_TYPE, DatabaseConstants.EmailType.PAYMENTSCONFIRMATION);
						composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.TRANSFER_TYPE, GeneralConstants.APPROVALTRANSFER);
						composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.CORPORATE_CODE, corporateCode);
						composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_BATCH_SUBMIT_ID, batchSubmitId);
						composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_FTM_SEQUENCE_NUMBER, ftmSequenceNumber);
						composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.HEADER_ORDER_DATE, headerOrderDate);
						composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.PROCESS_DATE, processDate);
						super.callGraymoundServiceInSession(TransactionConstants.ComposeEmail.SERVICE_NAME, composeEmailInputMap);	
					}
				}										
			}
			super.getHibernateSession().flush();
		}
	}
}
