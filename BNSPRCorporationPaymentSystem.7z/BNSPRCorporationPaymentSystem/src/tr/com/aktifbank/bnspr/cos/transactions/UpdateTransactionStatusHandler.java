package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OrderTransaction;

import com.graymound.util.GMMap;

public class UpdateTransactionStatusHandler extends RequestHandler {

	public UpdateTransactionStatusHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		BigDecimal txNo = input.getBigDecimal(TransactionConstants.UpdateTransactionStatus.Input.TX_NO);
		String transactionStatus = input.getString(TransactionConstants.UpdateTransactionStatus.Input.TRANSACTION_STATUS);
		Boolean setProcessingStarted = input.getBoolean(TransactionConstants.UpdateTransactionStatus.Input.SET_PROCESSING_STARTED);		
		
		if (setProcessingStarted != null && setProcessingStarted) {
			String query = "UPDATE COS.ORDER_TRANSACTION SET TRANSACTION_STATUS = '98' WHERE STATUS = 1 AND TRANSACTION_STATUS = '50'";
			CommonHelper.getHibernateSession().createSQLQuery(query).executeUpdate();			
		} else {		
			OrderTransaction orderTransaction = (OrderTransaction) super.getHibernateSession().createCriteria(OrderTransaction.class)
														   .add(Restrictions.eq("status", true))
														   .add(Restrictions.eq("txNo", txNo)).uniqueResult();
			if (orderTransaction != null) {
				orderTransaction.setTransactionStatus(transactionStatus);
				super.getHibernateSession().update(orderTransaction);
			}
			super.getHibernateSession().flush();
		}
	}
}
