package tr.com.aktifbank.bnspr.cos.dto;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.cos.dto.BaseTransferObject;

public final class OutgoingFileLoadingInformation extends
		BaseTransferObject {

	public OutgoingFileLoadingInformation() {
		super();
	}

	private String corporateCode;
	private String ftmId;
	private String formatId;	
	private String batchName;
	private String transferType;
	private String fileTransferId;
	private BigDecimal loadingFtmSequenceNumber;
	private String loadingBatchSubmitId;
	private String fileTypeConstant;
	private String fileName;
	private String outgoingFileOid;
	
	public String getTransferType() {
		return transferType;
	}
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}
	public String getFileTransferId() {
		return fileTransferId;
	}
	public void setFileTransferId(String fileTransferId) {
		this.fileTransferId = fileTransferId;
	}
	public String getCorporateCode() {
		return corporateCode;
	}
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	public String getFtmId() {
		return ftmId;
	}
	public void setFtmId(String ftmId) {
		this.ftmId = ftmId;
	}
	public String getFormatId() {
		return formatId;
	}
	public void setFormatId(String formatId) {
		this.formatId = formatId;
	}
	public String getBatchName() {
		return batchName;
	}
	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}
	public BigDecimal getLoadingFtmSequenceNumber() {
		return loadingFtmSequenceNumber;
	}
	public void setLoadingFtmSequenceNumber(BigDecimal loadingFtmSequenceNumber) {
		this.loadingFtmSequenceNumber = loadingFtmSequenceNumber;
	}
	public String getLoadingBatchSubmitId() {
		return loadingBatchSubmitId;
	}
	public void setLoadingBatchSubmitId(String loadingBatchSubmitId) {
		this.loadingBatchSubmitId = loadingBatchSubmitId;
	}
	public String getFileTypeConstant() {
		return fileTypeConstant;
	}
	public void setFileTypeConstant(String fileTypeConstant) {
		this.fileTypeConstant = fileTypeConstant;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getOutgoingFileOid() {
		return outgoingFileOid;
	}
	public void setOutgoingFileOid(String outgoingFileOid) {
		this.outgoingFileOid = outgoingFileOid;
	}
}
