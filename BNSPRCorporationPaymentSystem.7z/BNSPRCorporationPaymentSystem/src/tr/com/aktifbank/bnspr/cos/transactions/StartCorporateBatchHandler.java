package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BatchParameterEngine;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.CorporateBatchInformation;
import tr.com.aktifbank.bnspr.cos.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cos.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cos.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.OutgoingFileLog;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public class StartCorporateBatchHandler extends
		ParallelRequestHandler {

	private static class BagKeys {
		public static final String BATCH_SUBMIT_ID = "BATCH_SUBMIT_ID";
		public static final String CORPORATE_CODE = "CORPORATE_CODE";
	}

	public StartCorporateBatchHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		logger.info("Corporate batch start is beginning to prepare start for batch");
		String corporateCode = input.getString(TransactionConstants.StartCorporateBatch.Input.CORPORATE_CODE);
		super.bag.put(BagKeys.CORPORATE_CODE, corporateCode);
		String batchName = input.getString(TransactionConstants.StartCorporateBatch.Input.BATCH_NAME);
		String ftmId = input.getString(TransactionConstants.StartCorporateBatch.Input.FTM_ID);
		String formatId = input.getString(TransactionConstants.StartCorporateBatch.Input.FORMAT_ID);
		Date processDate = input.getDate(TransactionConstants.StartCorporateBatch.Input.PROCESS_DATE);
		String processDateLongDateTimeFormat = input.getString(TransactionConstants.StartCorporateBatch.Input.PROCESS_DATE_LONG_DATE_TIME_FORMAT);
		BigDecimal loadingFtmSequenceNumber = input.getBigDecimal(TransactionConstants.StartCorporateBatch.Input.LOADING_FTM_SEQUENCE_NUMBER);
		String loadingBatchSubmitId = input.getString(TransactionConstants.StartCorporateBatch.Input.LOADING_BATCH_SUBMIT_ID);
		Short informIndicator = (short)input.getInt(TransactionConstants.StartCorporateBatch.Input.INFORM_INDICATOR);

		String batchSubmitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
		super.bag.put(BagKeys.BATCH_SUBMIT_ID, batchSubmitId);

		logger.info("Inserting batch submit log");
		
		CommonBusinessOperations.insertBatchSubmitLog(corporateCode, batchName, ftmId, "", batchSubmitId, TransactionConstants.StartCorporateBatch.SERVICE_NAME, input);

		logger.info("Getting batch details");
		GMMap batchDetails = super.callServiceWithParams(
				TransactionConstants.GetOrderBatchDetail.SERVICE_NAME,
				TransactionConstants.GetOrderBatchDetail.Input.BATCH_NAME,
				batchName,
				TransactionConstants.GetOrderBatchDetail.Input.CORPORATE_CODE,
				corporateCode);
		
		GMMap batchParameters = super.callServiceWithParams(TransactionConstants.GetBatchParameters.SERVICE_NAME, 
				TransactionConstants.GetBatchParameters.Input.CORPORATE_BATCH_PROCESS_OID, 
					batchDetails.getString(TransactionConstants.GetOrderBatchDetail.Output.CORPORATE_BATCH_PROCESS_OID));

		String serviceName = batchDetails.getString(TransactionConstants.GetOrderBatchDetail.Output.SERVICE_NAME);
		
		List<FormatDetail> headerDetails = callFormatServices(TransactionConstants.GetOrderFileHeaderFormat.SERVICE_NAME, formatId, TransactionConstants.GetOrderFileHeaderFormat.Output.HEADER_FORMATS);
		List<FormatDetail> bodyDetails = callFormatServices(TransactionConstants.GetOrderFileDetailFormat.SERVICE_NAME, formatId, TransactionConstants.GetOrderFileDetailFormat.Output.DETAIL_FORMAT);
		List<FormatDetail> footerDetails = callFormatServices(TransactionConstants.GetOrderFileFooterFormat.SERVICE_NAME, formatId, TransactionConstants.GetOrderFileFooterFormat.Output.FOOTER_FORMATS);
		List<ItemDatabaseField> databaseFields = (List<ItemDatabaseField>) super.callServiceWithParams(TransactionConstants.GetOrderDatabaseFields.SERVICE_NAME).get(TransactionConstants.GetOrderDatabaseFields.Output.FIELDS);
		List<ItemServiceField> serviceFields = (List<ItemServiceField>) super.callServiceWithParams(TransactionConstants.GetOrderServiceFields.SERVICE_NAME).get(TransactionConstants.GetOrderServiceFields.Output.FIELDS);
		BigDecimal ftmProcessId = getNextValueOfProcessSequence();
				
		CorporateBatchInformation information = new CorporateBatchInformation();
		information.setCorporateCode(corporateCode);
		information.setServiceName(serviceName);
		information.setBodyDetails(bodyDetails);
		information.setFooterDetails(footerDetails);
		information.setHeaderDetails(headerDetails);
		information.setDatabaseFields(databaseFields);
		information.setServiceFields(serviceFields);
		information.setFtmProcessId(ftmProcessId);
		information.setLoadingBatchSubmitId(loadingBatchSubmitId);
		information.setLoadingFtmSequenceNumber(loadingFtmSequenceNumber);
		information.setInformIndicator(informIndicator.shortValue());
		information.setProcessDate(processDate);
		if(batchParameters.containsKey(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS)){
			BatchParameterEngine engine = new BatchParameterEngine(batchParameters.getString(TransactionConstants.GetBatchParameters.Output.COMPOSED_PARAMETERS));
			information.setBatchParameters(CommonHelper.convertMapToGMMap(engine.getDecomposedParameters()));
		}

		logger.info("Updating batch submit log");
		
		CommonBusinessOperations.updateBatchSubmitLog(batchSubmitId, DatabaseConstants.SubmitStatuses.EXECUTING, null, null, null);

		logger.info("Executing corporate batch");
		
		executeInformCollection(information);
		
		String fileType = null, ftmFileName = null;
		String getFileNameQuery = QueryRepository.CosStartCorporateBatchHandlerRepository.FILE_NAME_BY_PROCESS_OID_QUERY;
		
		if (informIndicator != null && informIndicator.compareTo(new Short(GeneralConstants.LOADING_CONFIRMATION)) == 0 ) {
			ftmFileName = DALUtil.getResult(String.format(getFileNameQuery, loadingFtmSequenceNumber)).replaceFirst("ODM", DatabaseConstants.ConfirmationFileTypeConstants.LOADING);
			fileType = DatabaseConstants.OutgoingFileType.LOADING;
		}
		else if (informIndicator != null && informIndicator.compareTo(new Short(GeneralConstants.PAYMENTS_CONFIRMATION)) == 0 ) {
			ftmFileName = DALUtil.getResult(String.format(getFileNameQuery, loadingFtmSequenceNumber)).replaceFirst("ODM", DatabaseConstants.ConfirmationFileTypeConstants.PAYMENT);
			fileType = DatabaseConstants.OutgoingFileType.PAYMENT;
		}
		else if (informIndicator != null && informIndicator.compareTo(new Short(GeneralConstants.EOD_PAYMENTS_CONFIRMATION)) == 0 ) {			
			GMMap getCorpDefinitionMap = new GMMap();
			getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
			GMMap corpDefDetailsMap = super.callGraymoundServiceInSession(TransactionConstants.GetOrderCorpDef.SERVICE_NAME, getCorpDefinitionMap);
					
			String corporateName = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.SHORT_NAME);
			if(corporateName != null && corporateName.length() > 10)
				corporateName = corporateName.substring(0 ,10).replace(' ', '_');
			else
				corporateName = corporateName.replace(' ', '_');
			
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'S');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'I');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'O');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'C');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'U');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'G');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 's');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'o');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'c');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'u');
			if (corporateName.contains("�"))
				corporateName = corporateName.replace('�', 'g');
						
			String createDateStr = processDateLongDateTimeFormat;
			String dateStr = CommonHelper.longTimeStringToViewDateString(createDateStr).replace("/", "");
			String timeStr = CommonHelper.longTimeStringToViewTimeString(createDateStr).replace(":", "");

			ftmFileName = DatabaseConstants.ConfirmationFileTypeConstants.PAYMENT.concat(dateStr).concat(timeStr).concat(corporateName).concat(".TXT");
			fileType = DatabaseConstants.OutgoingFileType.EOD;
		}
		
		OutgoingFileLog confirmationFile = new OutgoingFileLog();		
		confirmationFile.setStatus(true);
		confirmationFile.setCorporateCode(corporateCode);
		confirmationFile.setFileType(fileType);		
		confirmationFile.setFileName(ftmFileName);
		confirmationFile.setLoadingBatchSubmitId(loadingBatchSubmitId);
		confirmationFile.setLoadingFtmSequenceNumber(loadingFtmSequenceNumber);				
		confirmationFile.setCreateDate(processDateLongDateTimeFormat);
		confirmationFile.setFtmFileDefId(new BigDecimal(ftmId));
		confirmationFile.setOutgoingFtmSequenceNumber(ftmProcessId);

		super.getHibernateSession().save(confirmationFile);
		super.getHibernateSession().flush();
		
		output.put(TransactionConstants.StartCorporateBatch.Output.RESULT, true);
		output.put(TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID, batchSubmitId);
		output.put(TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE, corporateCode);

	}

	private void executeInformCollection(CorporateBatchInformation information) throws Exception {
		GMMap dbFieldsMap = new GMMap();
		for (ItemDatabaseField field : information.getDatabaseFields()) {
			dbFieldsMap.put(field.getOid(), field);
		}

		GMMap serviceFieldsMap = new GMMap();
		for (ItemServiceField field : information.getServiceFields()) {
			serviceFieldsMap.put(field.getOid(), field);
		}
		
		GMMap input = new GMMap();
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.CORPORATE_CODE, information.getCorporateCode());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.HEADER_DETAILS, information.getHeaderDetails());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.BODY_DETAILS, information.getBodyDetails());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.FOOTER_DETAILS, information.getFooterDetails());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.FTM_PROCESS_ID, information.getFtmProcessId());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.PROCESS_DATE, information.getProcessDate());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.DATABASE_FIELDS, dbFieldsMap);
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.SERVICE_FIELDS, serviceFieldsMap);		
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.INFORM_INDICATOR, information.getInformIndicator());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.BATCH_PARAMETERS, information.getBatchParameters());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.LOADING_BATCH_SUBMIT_ID, information.getLoadingBatchSubmitId());
		input.put(TransactionConstants.CorporateGeneralBatchSubmit.Input.LOADING_FTM_SEQUENCE_NUMBER, information.getLoadingFtmSequenceNumber());
		logger.info("Calling corporate batch service for batch process");
		
		GMMap output = super.callGraymoundServiceInSession(information.getServiceName(), input);
		if (!output.getBoolean(TransactionConstants.CorporateGeneralBatchSubmit.Output.RESULT, false)) {
			if (output.containsKey(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_CODE)
			 && output.containsKey(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_MESSAGE)) {
				throw new BatchComponentException(output.getString(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_MESSAGE),
						output.getInt(TransactionConstants.CorporateGeneralBatchSubmit.Output.ERROR_CODE));
			} else {
				throw new Exception(
						String.format("Generic inform invoice collection error for corporate with %s code. Please see logs for details.",
									  information.getCorporateCode()));
			}
		}
	}

	private BigDecimal getNextValueOfProcessSequence() {
		return new BigDecimal(((Number) super.getHibernateSession()
				.createSQLQuery(QueryRepository.CosStartCorporateBatchHandlerRepository.FTM_PROCESS_NEXTVAL_QUERY)
				.uniqueResult()).longValue());
	}

	private List<FormatDetail> callFormatServices(String serviceName,
			String formatOid, String outputKey) {
		GMMap formatDetails = super.callGraymoundServiceInSession(serviceName,
				new GMMap().put(TransactionConstants.FORMAT_ID_GENERAL_KEY,
						formatOid));
		@SuppressWarnings("unchecked")
		List<FormatDetail> detail = (List<FormatDetail>) formatDetails
				.get(outputKey);
		return detail;
	}	
	
	@Override
	protected void handleError(Throwable e, GMMap output) {
		Long errorId = System.currentTimeMillis();
		logger.error("System exception is occured updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(), "0",
				e.toString());
		output.put(
				TransactionConstants.StartCorporateBatch.Output.RESULT,
				false);
		output.put(
				TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID,
				(String) super.bag.get(BagKeys.BATCH_SUBMIT_ID));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE,
				(String) super.bag.get(BagKeys.CORPORATE_CODE));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_CODE,
				"0");
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_MESSAGE,
				e.toString());
	}

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		Long errorId = System.currentTimeMillis();

		logger.error("Business exception is occured. Updating batch submit log");
		logger.error(errorId, e);
		CommonBusinessOperations.updateBatchSubmitLog((String) super.bag.get(BagKeys.BATCH_SUBMIT_ID),
				DatabaseConstants.SubmitStatuses.FAILURE, new Date(),
				String.valueOf(e.getCode()), e.toString());
		output.put(
				TransactionConstants.StartCorporateBatch.Output.RESULT,
				false);
		output.put(
				TransactionConstants.StartCorporateBatch.Output.BATCH_SUBMIT_ID,
				(String) super.bag.get(BagKeys.BATCH_SUBMIT_ID));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.CORPORATE_CODE,
				(String) super.bag.get(BagKeys.CORPORATE_CODE));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_CODE,
				String.valueOf(e.getCode()));
		output.put(
				TransactionConstants.StartCorporateBatch.Output.ERROR_MESSAGE,
				e.toString());
	}
}
