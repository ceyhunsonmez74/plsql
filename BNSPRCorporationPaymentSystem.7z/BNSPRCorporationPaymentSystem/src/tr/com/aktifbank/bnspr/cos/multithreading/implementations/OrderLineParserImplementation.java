package tr.com.aktifbank.bnspr.cos.multithreading.implementations;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cos.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.cos.dto.OrderLoadingProcessInformation;
import tr.com.aktifbank.bnspr.cos.multithreading.core.MultiThreadingUtilities;
import tr.com.aktifbank.bnspr.cos.multithreading.core.ServiceBasedMultiThreading;

import com.graymound.util.GMMap;


public class OrderLineParserImplementation extends ServiceBasedMultiThreading {
	public OrderLoadingProcessInformation information;
	
	public OrderLineParserImplementation(OrderLoadingProcessInformation information){
		super();
		this.information = information;
	}

	@Override
	protected void prepareCall() throws Throwable {
		int threadCount = information.getThreadCount();
		int rowCount = information.getTotalLineCount();
		GMMap databaseFieldMaps = new GMMap();
		for(ItemDatabaseField field : information.getDatabaseFields()){
			databaseFieldMaps.put(field.getOid(), field);
		}
		GMMap serviceFieldMaps = new GMMap();
		for (ItemServiceField field : information.getServiceFields()) {
			serviceFieldMaps.put(field.getOid(), field);
		}
		Map<Integer, Integer> indexStartMappings = MultiThreadingUtilities.getIndexStartMappings(threadCount, rowCount);
		int counter = 1;
		for(Map.Entry<Integer, Integer> entry : indexStartMappings.entrySet()){
			GMMap inputMap = new GMMap();
			inputMap.put(TransactionConstants.OrderLineParser.Input.BATCH_SUBMIT_ID, information.getBatchSubmitId());
			inputMap.put(TransactionConstants.OrderLineParser.Input.COMMIT_COUNT, information.getCommitCount());
			inputMap.put(TransactionConstants.OrderLineParser.Input.CORPORATE_CODE, information.getCorporateCode());
			inputMap.put(TransactionConstants.OrderLineParser.Input.DATABASE_FIELD_MAPS, databaseFieldMaps);
			inputMap.put(TransactionConstants.OrderLineParser.Input.DETAIL_FORMAT_DETAILS, information.getBodyDetails());
			if (indexStartMappings.containsKey(counter + 1)) {
				inputMap.put(
						TransactionConstants.OrderLineParser.Input.END_LINE_NUMBER,
						indexStartMappings.get(counter + 1) - 1);
			}
			else{
				inputMap.put(
						TransactionConstants.OrderLineParser.Input.END_LINE_NUMBER,
						rowCount);
			}
			inputMap.put(TransactionConstants.OrderLineParser.Input.ERROR_THRESHOLD, information.getErrorThreshold());
			inputMap.put(TransactionConstants.OrderLineParser.Input.CONTROL_LOOP_COUNT, information.getControlLoopCount());
			inputMap.put(TransactionConstants.OrderLineParser.Input.FOOTER_FORMAT_DETAILS, information.getFooterDetails());
			inputMap.put(TransactionConstants.OrderLineParser.Input.LAST_FIELD_HAS_DYNAMIC_LENGTH, information.getLastFieldHasDynamicLength());
			inputMap.put(TransactionConstants.OrderLineParser.Input.FTM_ID, information.getFtmId());
			inputMap.put(TransactionConstants.OrderLineParser.Input.FTM_TRANSFER_ID, information.getFtmTransferId());
			inputMap.put(TransactionConstants.OrderLineParser.Input.HEADER_FORMAT_DETAILS, information.getHeaderDetails());
			inputMap.put(TransactionConstants.OrderLineParser.Input.SERVICE_FIELD_MAPS, serviceFieldMaps);
			inputMap.put(TransactionConstants.OrderLineParser.Input.SERVICE_NAME, information.getServiceName());
			inputMap.put(TransactionConstants.OrderLineParser.Input.START_LINE_NUMBER, entry.getValue());
			super.registerService(TransactionConstants.OrderLineParser.SERVICE_NAME, inputMap);
			counter++;
		}
	}
	
	@Override
	protected void afterCall() throws Throwable {
		if (!this.isHasError()) {
			List<GMMap> resultList = super.getServiceOutputs();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			String headerCustomerAccountNo = null, headerOrderDateStr = null, headerCustomerBank = null, headerCustomerBranch = null;
			BigDecimal headerCustomerNo = null, customerNo = null;
			boolean headerCustomerAccountNoControl = false, headerOrderDateControl = false, headerCustomerBankControl = false, headerCustomerBranchControl = false, headerCustomerNoControl = false;
			BigDecimal footerTRYAmount = new BigDecimal(0), footerUSDAmount = new BigDecimal(0), footerEURAmount = new BigDecimal(0);
			int footerTRYLineCount = 0, footerUSDLineCount = 0, footerEURLineCount = 0;			
			boolean footerTRYAmountControl = false, footerUSDAmountControl = false, footerEURAmountControl = false;
			boolean footerTRYLineCountControl = false, footerUSDLineCountControl = false, footerEURLineCountControl = false;
			int totalLineCount = 0, totalTRYLineCount = 0, totalUSDLineCount = 0, totalEURLineCount = 0;
			BigDecimal totalTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal totalEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal totalUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			String corporateCode = null;
			
			for(GMMap out : resultList){
				if(out.getBoolean(TransactionConstants.OrderLineParser.Output.ISSUCCESSFUL)){
					totalTRYAmount = totalTRYAmount.add(out.getBigDecimal(TransactionConstants.OrderLineParser.Output.PROCESSED_TRY_AMOUNT)).setScale(2, RoundingMode.HALF_UP);
					totalUSDAmount = totalUSDAmount.add(out.getBigDecimal(TransactionConstants.OrderLineParser.Output.PROCESSED_USD_AMOUNT)).setScale(2, RoundingMode.HALF_UP);
					totalEURAmount = totalEURAmount.add(out.getBigDecimal(TransactionConstants.OrderLineParser.Output.PROCESSED_EUR_AMOUNT)).setScale(2, RoundingMode.HALF_UP);
					totalLineCount += out.getInt(TransactionConstants.OrderLineParser.Output.PROCESSED_LINE_COUNT);
					totalTRYLineCount += out.getInt(TransactionConstants.OrderLineParser.Output.PROCESSED_TRY_LINE_COUNT);
					totalUSDLineCount += out.getInt(TransactionConstants.OrderLineParser.Output.PROCESSED_USD_LINE_COUNT);
					totalEURLineCount += out.getInt(TransactionConstants.OrderLineParser.Output.PROCESSED_EUR_LINE_COUNT);
					
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BANK)){
						headerCustomerBankControl = true;
						headerCustomerBank = out.getString(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BANK);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BRANCH)){
						headerCustomerBranchControl = true;
						headerCustomerBranch = out.getString(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BRANCH);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_NO)){
						headerCustomerNoControl = true;
						headerCustomerNo = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_NO);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_ORDER_DATE)){
						headerOrderDateControl = true;
						headerOrderDateStr = out.getString(TransactionConstants.OrderLineParser.Output.HEADER_ORDER_DATE);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_ACCOUNT_NO)){
						headerCustomerAccountNoControl = true;
						headerCustomerAccountNo = out.getString(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_ACCOUNT_NO);
					}					
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_AMOUNT)){
						footerTRYAmountControl = true;
						footerTRYAmount = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_AMOUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_LINE_COUNT)){
						footerTRYLineCountControl = true;
						footerTRYLineCount = out.getInt(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_LINE_COUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_USD_AMOUNT)){
						footerUSDAmountControl = true;
						footerUSDAmount = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.FOOTER_USD_AMOUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_USD_LINE_COUNT)){
						footerUSDLineCountControl = true;
						footerUSDLineCount = out.getInt(TransactionConstants.OrderLineParser.Output.FOOTER_USD_LINE_COUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_AMOUNT)){
						footerEURAmountControl = true;
						footerEURAmount = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_AMOUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_LINE_COUNT)){
						footerEURLineCountControl = true;
						footerEURLineCount = out.getInt(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_LINE_COUNT);
					}
				
					customerNo = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.CUSTOMER_NO);
					corporateCode = out.getString(TransactionConstants.OrderLineParser.Output.CORPORATE_CODE);
				}
				else{
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BANK)){
						headerCustomerBankControl = false;
						headerCustomerBank = out.getString(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BANK);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BRANCH)){
						headerCustomerBranchControl = false;
						headerCustomerBranch = out.getString(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BRANCH);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_NO)){
						headerCustomerNoControl = false;
						headerCustomerNo = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_NO);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_ORDER_DATE)){
						headerOrderDateControl = false;
						headerOrderDateStr = out.getString(TransactionConstants.OrderLineParser.Output.HEADER_ORDER_DATE);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_ACCOUNT_NO)){
						headerCustomerAccountNoControl = false;
						headerCustomerAccountNo = out.getString(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_ACCOUNT_NO);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_AMOUNT)){
						footerTRYAmountControl = false;
						footerTRYAmount = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_AMOUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_LINE_COUNT)){
						footerTRYLineCountControl = false;
						footerTRYLineCount = out.getInt(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_LINE_COUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_USD_AMOUNT)){
						footerUSDAmountControl = false;
						footerUSDAmount = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.FOOTER_USD_AMOUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_USD_LINE_COUNT)){
						footerUSDLineCountControl = false;
						footerUSDLineCount = out.getInt(TransactionConstants.OrderLineParser.Output.FOOTER_USD_LINE_COUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_AMOUNT)){
						footerEURAmountControl = false;
						footerEURAmount = out.getBigDecimal(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_AMOUNT);
					}
					if(out.containsKey(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_LINE_COUNT)){
						footerEURLineCountControl = false;
						footerEURLineCount = out.getInt(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_LINE_COUNT);
					}
					
					totalLineCount += out.getInt(TransactionConstants.OrderLineParser.Output.PROCESSED_LINE_COUNT);
					
					super.setHasError(true);
					super.setErrorCode(out.getString(TransactionConstants.OrderLineParser.Output.ERROR_CODE));
					super.setErrorMessage(out.getString(TransactionConstants.OrderLineParser.Output.ERROR_MESSAGE));
					break;
				}
			}
			
			if(!this.isHasError()){
				
				if (headerOrderDateControl) {
					String bankDateStr = CommonHelper.getShortDateTimeString(new Date());
					Date bankDate = dateFormat.parse(bankDateStr);
					Date headerOrderDate = null;
					if (StringUtils.isNotEmpty(headerOrderDateStr))
						headerOrderDate = dateFormat.parse(headerOrderDateStr);
					
					if(headerOrderDate != null && headerOrderDate.compareTo(bankDate) >= 0) {

					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.HEADERORDERDATECONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Header �deme tarihi bug�n�n tarihinden k���k olamaz. Header �deme Tarihi : %s, Tarih : %s", CommonHelper.shortTimeStringToViewDateString(headerOrderDateStr), 
																																						 CommonHelper.shortTimeStringToViewDateString(bankDateStr)));
					}					
				} else{
					super.setHasError(true);
					super.setErrorCode(String.valueOf(BusinessException.HEADERORDERDATECONTROLFAILED.getCode()));
					super.setErrorMessage("Header �deme tarihi alan� bo� olamaz.");
				}					
				if (headerCustomerNoControl) {
					if (headerCustomerNo != null && headerCustomerNo.compareTo(customerNo) == 0) {

					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.HEADERCUSTOMERNOCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Header m��teri numaras� ger�ek m��teri numaras�ndan farkl�. Header M��teri Numaras� : %s, M��teri Numaras� : %s", headerCustomerNo.toString(), customerNo.toString()));
					}					
				}				
				if (headerCustomerBankControl) {
					if (StringUtils.isNotEmpty(headerCustomerBank) && headerCustomerBank.equals(GeneralConstants.AktifBankCode)) {

					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.HEADERBANKCODECONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Header banka kodu Aktifbank de�il. Header Banka Kodu : %s, Aktifbank Banka Kodu : %s", headerCustomerBank, GeneralConstants.AktifBankCode));
					}					
				}					
				if (headerCustomerBranchControl) {
					if (StringUtils.isNotEmpty(headerCustomerBranch) && CommonHelper.isValidBranch(GeneralConstants.AktifBankCode, headerCustomerBranch)) {

					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.HEADERBRANCHCODECONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Header �ube kodu Aktifbank'a ait de�il. Header �ube Kodu : %s", headerCustomerBranch));
					}					
				}				
				if (headerCustomerAccountNoControl) {
					if (headerCustomerBranchControl) {
						if (!CommonHelper.isDKAccount(new BigDecimal(headerCustomerAccountNo), corporateCode)) {
							if (StringUtils.isNotEmpty(headerCustomerAccountNo) && CommonHelper.isValidAccountNo(headerCustomerBranch, new BigDecimal(headerCustomerAccountNo))) {
								
							}
							else{
								super.setHasError(true);
								super.setErrorCode(String.valueOf(BusinessException.HEADERACCOUNTNOCONTROLFAILED.getCode()));
								super.setErrorMessage(String.format("Header hesap numaras� %s �ubesine ait de�il. Header Hesap Numaras� : %s", headerCustomerBranch, headerCustomerAccountNo));
							}					
						}
					}
					
					if (StringUtils.isNotEmpty(headerCustomerAccountNo) && CommonHelper.isUsageAccount(new BigDecimal(headerCustomerAccountNo), corporateCode)) {
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.HEADERACCOUNTNOCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Header hesap numaras� %s kodlu firman�n tan�ml� hesaplar� aras�nda de�il. Header Hesap Numaras� : %s", corporateCode, headerCustomerAccountNo));
					}	
				}
				
				if(footerTRYAmountControl){
					if(footerTRYAmount.compareTo(totalTRYAmount) == 0){
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.FOOTERAMOUNTCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Footer TRY tutar kontrol� ba�ar�s�z oldu. Hesaplanan tutar : %s, Footer'da yazan tutar : %s", totalTRYAmount, footerTRYAmount));
					}
				}
				if(footerTRYLineCountControl){
					if(footerTRYLineCount == totalTRYLineCount){
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.FOOTERLINECOUNTCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Footer TRY sat�r say�s� kontrol� ba�ar�s�z oldu. Hesaplanan sat�r say�s� : %s, Footer'da yazan sat�r say�s� : %s", totalTRYLineCount, footerTRYLineCount));
					}
				}
				if(footerUSDAmountControl){
					if(footerUSDAmount.compareTo(totalUSDAmount) == 0){
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.FOOTERAMOUNTCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Footer USD tutar kontrol� ba�ar�s�z oldu. Hesaplanan tutar : %s, Footer'da yazan tutar : %s", totalUSDAmount, footerUSDAmount));
					}
				}
				if(footerUSDLineCountControl){
					if(footerUSDLineCount == totalUSDLineCount){
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.FOOTERLINECOUNTCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Footer USD sat�r say�s� kontrol� ba�ar�s�z oldu. Hesaplanan sat�r say�s� : %s, Footer'da yazan sat�r say�s� : %s", totalUSDLineCount, footerUSDLineCount));
					}
				}
				if(footerEURAmountControl){
					if(footerEURAmount.compareTo(totalEURAmount) == 0){
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.FOOTERAMOUNTCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Footer EUR tutar kontrol� ba�ar�s�z oldu. Hesaplanan tutar : %s, Footer'da yazan tutar : %s", totalEURAmount, footerEURAmount));
					}
				}
				if(footerEURLineCountControl){
					if(footerEURLineCount == totalEURLineCount){
						
					}
					else{
						super.setHasError(true);
						super.setErrorCode(String.valueOf(BusinessException.FOOTERLINECOUNTCONTROLFAILED.getCode()));
						super.setErrorMessage(String.format("Footer EUR sat�r say�s� kontrol� ba�ar�s�z oldu. Hesaplanan sat�r say�s� : %s, Footer'da yazan sat�r say�s� : %s", totalEURLineCount, footerEURLineCount));
					}
				}				
			}
			
			this.information.setHeaderCustomerAccountNo(headerCustomerAccountNo);
			this.information.setHeaderCustomerBank(headerCustomerBank);
			this.information.setHeaderCustomerBranch(headerCustomerBranch);
			this.information.setHeaderCustomerNo(headerCustomerNo);
			this.information.setHeaderOrderDate(headerOrderDateStr);
			this.information.setTotalTRYAmount(totalTRYAmount);
			this.information.setTotalTRYLineCount(totalTRYLineCount);
			this.information.setTotalUSDAmount(totalUSDAmount);
			this.information.setTotalUSDLineCount(totalUSDLineCount);
			this.information.setTotalEURAmount(totalEURAmount);
			this.information.setTotalEURLineCount(totalEURLineCount);
			this.information.setTotalLineCount(totalLineCount);
		}
	}
}
