package tr.com.aktifbank.bnspr.cos.services;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.apache.axis.utils.StringUtils;

import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.MapKeys;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class FileTransferServices {
	
	private static final String tableName = "Orders";
	
	@GraymoundService("COS_GET_LINE_STATUS_FOR_LOADING_FILE")
	public static GMMap getLineStatusForLoadingFile(GMMap input) {
		GMMap output = new GMMap();
		try {			
			GMMap currentRowData = input.getMap("CURRENT_ROW");			
			String orderStatus = currentRowData.getString("ORDER_STATUS");
			String noErrorStatus = "HATASIZ", errorStatus = "HATALI";
			
			if ( !orderStatus.equals(DatabaseConstants.OrderStatuses.Waiting) && !orderStatus.equals(DatabaseConstants.OrderStatuses.RepeatedOrder) )
				output.put(MapKeys.FTS_OUTPUT_DATA, errorStatus);
			else 
				output.put(MapKeys.FTS_OUTPUT_DATA, noErrorStatus);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("COS_GET_LINE_STATUS_FOR_PAYMENT_FILE")
	public static GMMap getLineStatusForPaymentFile(GMMap input) {
		GMMap output = new GMMap();
		try {
			GMMap currentRowData = input.getMap("CURRENT_ROW");			
			String orderStatus = currentRowData.getString("ORDER_STATUS");
			String transferCompleted = "TAMAMLANDI", noErrorStatus = "HATASIZ", errorStatus = "HATALI";		
			
			if (!StringUtils.isEmpty(orderStatus) && orderStatus.equals(DatabaseConstants.OrderStatuses.Transfered))	
				output.put(MapKeys.FTS_OUTPUT_DATA, transferCompleted);
			else if (!StringUtils.isEmpty(orderStatus) && ( orderStatus.equals(DatabaseConstants.OrderStatuses.Waiting) || orderStatus.equals(DatabaseConstants.OrderStatuses.RepeatedOrder)
				     || orderStatus.equals(DatabaseConstants.OrderStatuses.WaitingApproval) || orderStatus.equals(DatabaseConstants.OrderStatuses.Approved) 
				     || orderStatus.equals(DatabaseConstants.OrderStatuses.AfterApprovalProcessStarted)) )
				output.put(MapKeys.FTS_OUTPUT_DATA, noErrorStatus);
			else 
				output.put(MapKeys.FTS_OUTPUT_DATA, errorStatus);
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("COS_GET_TRY_LINE_COUNT_FOR_EOD_PAYMENT_FILE")
	public static GMMap getTryLineCountForEodPaymentFile(GMMap input) {
		GMMap output = new GMMap();
		try {		
			Object records = input.get("RECORDS");
			GMMap orderRecords = (GMMap)records;
			int processedTRYLineCount = 0;
			
			for (int i = 0; i < orderRecords.getSize(tableName); i++) {
				String currencyCode = orderRecords.getString(tableName, i, "CURRENCY_CODE");	
				
				if (currencyCode != null && currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY))
					processedTRYLineCount++;
			}			
			output.put(MapKeys.FTS_OUTPUT_DATA, processedTRYLineCount);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("COS_GET_TRY_AMOUNT_FOR_EOD_PAYMENT_FILE")
	public static GMMap getTryAmountForEodPaymentFile(GMMap input) {
		GMMap output = new GMMap();
		try {		
			Object records = input.get("RECORDS");
			GMMap orderRecords = (GMMap)records;					
			BigDecimal processedTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			
			for (int i = 0; i < orderRecords.getSize(tableName); i++) {
				BigDecimal amount = orderRecords.getBigDecimal(tableName, i, "AMOUNT");
				String currencyCode = orderRecords.getString(tableName, i, "CURRENCY_CODE");	
				if (currencyCode != null && amount != null) { 
					if (currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
						processedTRYAmount = processedTRYAmount.add(amount);
					}
				}
			}			
			output.put(MapKeys.FTS_OUTPUT_DATA, processedTRYAmount);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}

	@GraymoundService("COS_GET_USD_LINE_COUNT_FOR_EOD_PAYMENT_FILE")
	public static GMMap getUsdLineCountForEodPaymentFile(GMMap input) {
		GMMap output = new GMMap();
		try {		
			Object records = input.get("RECORDS");
			GMMap orderRecords = (GMMap)records;
			int processedUSDLineCount = 0;
			
			for (int i = 0; i < orderRecords.getSize(tableName); i++) {
				String currencyCode = orderRecords.getString(tableName, i, "CURRENCY_CODE");	
				
				if (currencyCode != null && currencyCode.equals(DatabaseConstants.CurrencyCodes.USD))
					processedUSDLineCount++;
			}			
			output.put(MapKeys.FTS_OUTPUT_DATA, processedUSDLineCount);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("COS_GET_USD_AMOUNT_FOR_EOD_PAYMENT_FILE")
	public static GMMap getUsdAmountForEodPaymentFile(GMMap input) {
		GMMap output = new GMMap();
		try {		
			Object records = input.get("RECORDS");
			GMMap orderRecords = (GMMap)records;					
			BigDecimal processedUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			
			for (int i = 0; i < orderRecords.getSize(tableName); i++) {
				BigDecimal amount = orderRecords.getBigDecimal(tableName, i, "AMOUNT");
				String currencyCode = orderRecords.getString(tableName, i, "CURRENCY_CODE");	
				if (currencyCode != null && amount != null) { 
					if (currencyCode.equals(DatabaseConstants.CurrencyCodes.USD)) {
						processedUSDAmount = processedUSDAmount.add(amount);
					}
				}
			}			
			output.put(MapKeys.FTS_OUTPUT_DATA, processedUSDAmount);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("COS_GET_EUR_LINE_COUNT_FOR_EOD_PAYMENT_FILE")
	public static GMMap getEurLineCountForEodPaymentFile(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Object records = input.get("RECORDS");
			GMMap orderRecords = (GMMap)records;
			int processedEURLineCount = 0;
			
			for (int i = 0; i < orderRecords.getSize(tableName); i++) {
				String currencyCode = orderRecords.getString(tableName, i, "CURRENCY_CODE");	
				
				if (currencyCode != null && currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR))
					processedEURLineCount++;
			}			
			output.put(MapKeys.FTS_OUTPUT_DATA, processedEURLineCount);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	@GraymoundService("COS_GET_EUR_AMOUNT_FOR_EOD_PAYMENT_FILE")
	public static GMMap getEurAmountForEodPaymentFile(GMMap input) {
		GMMap output = new GMMap();
		try {		
			Object records = input.get("RECORDS");
			GMMap orderRecords = (GMMap)records;					
			BigDecimal processedEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			
			for (int i = 0; i < orderRecords.getSize(tableName); i++) {
				BigDecimal amount = orderRecords.getBigDecimal(tableName, i, "AMOUNT");
				String currencyCode = orderRecords.getString(tableName, i, "CURRENCY_CODE");	
				if (currencyCode != null && amount != null) { 
					if (currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR)) {
						processedEURAmount = processedEURAmount.add(amount);
					}
				}
			}			
			output.put(MapKeys.FTS_OUTPUT_DATA, processedEURAmount);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
}
