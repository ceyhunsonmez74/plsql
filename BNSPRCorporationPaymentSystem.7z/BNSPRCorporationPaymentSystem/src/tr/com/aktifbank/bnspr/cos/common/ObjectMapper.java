package tr.com.aktifbank.bnspr.cos.common;

import java.lang.reflect.Method;
import java.util.HashMap;

public final class ObjectMapper<T> {
	private Class<T> type;
	
	public ObjectMapper(Class<T> outputObjectClass){
		this.type = outputObjectClass;
	}
	
	@SuppressWarnings("unchecked")
	public T map(Object inputObject) throws Exception{
		Method[] methodsOfOutput = type.getMethods();
		HashMap<String, Method> inputMethodNameMethodHashMap = getMethodNameMethodMappings(inputObject.getClass());
		Object output = type.newInstance();
		for(Method method : methodsOfOutput){
			String methodName = method.getName();
			if(methodName.startsWith("set")){
				String propertyName = methodName.substring(3);
				String getMethodName = String.format("get%s", propertyName);
				if(inputMethodNameMethodHashMap.containsKey(getMethodName)){
					Method getMethod = inputMethodNameMethodHashMap.get(getMethodName);
					method.invoke(output, getMethod.invoke(inputObject, new Object[0]));
				}
			}
			else{
				continue;
			}
		}
		return (T)output;
	}

	private HashMap<String, Method> getMethodNameMethodMappings(
			Class<? extends Object> inputType) {
		Method[] methods = inputType.getMethods();
		HashMap<String, Method> hashMap = new HashMap<String, Method>();
		for(Method method : methods){
			hashMap.put(method.getName(), method);
		}
		
		return hashMap;
	}
}
