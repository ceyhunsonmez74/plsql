package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public class CheckRepeatedFileHandler extends RequestHandler {

	public CheckRepeatedFileHandler() {
		super();
	}

	String tableName = "REPEATED_FILE_CONTENT_COUNT";
	
	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		String corporateCode = input.getString("CORPORATE_CODE");
		BigDecimal tryLineCount = input.getBigDecimal("TRY_LINE_COUNT");
		BigDecimal tryAmount = input.getBigDecimal("TRY_AMOUNT");
		BigDecimal eurLineCount = input.getBigDecimal("EUR_LINE_COUNT");
		BigDecimal eurAmount = input.getBigDecimal("EUR_AMOUNT");
		BigDecimal usdLineCount = input.getBigDecimal("USD_LINE_COUNT");
		BigDecimal usdAmount = input.getBigDecimal("USD_AMOUNT");
		String shortLogDate = CommonHelper.getShortDateTimeString(input.getDate("LOG_DATE"));
		String batchSubmitId = input.getString("BATCH_SUBMIT_ID");
		BigDecimal ftmSequenceNumber = input.getBigDecimal("FTM_SEQUENCE_NUMBER");
		String query = null;

		List<OrderFileLog> repeatedFiles = super.getHibernateSession().createCriteria(OrderFileLog.class)
									.add(Restrictions.eq("corporateCode", corporateCode))
									.add(Restrictions.eq("tryLineCount", tryLineCount))
									.add(Restrictions.eq("tryAmount", tryAmount))
									.add(Restrictions.eq("eurLineCount", eurLineCount))
									.add(Restrictions.eq("eurAmount", eurAmount))
									.add(Restrictions.eq("usdLineCount", usdLineCount))
									.add(Restrictions.eq("usdAmount", usdAmount))
									.add(Restrictions.like("logDate", shortLogDate, MatchMode.START))
									.add(Restrictions.ne("batchSubmitId", batchSubmitId))
									.add(Restrictions.ne("fileStatus", "-1"))
									.list();
		
		for (OrderFileLog repeatedFile : repeatedFiles) {
			query = String.format(QueryRepository.CheckRepeatedFileHandlerRepository.REPEATED_FILE_CONTENT_COUNT_QUERY, ftmSequenceNumber, shortLogDate, repeatedFile.getFtmSequenceNumber(), shortLogDate);
			GMMap repeatedContentCount =  DALUtil.getResults(query, tableName);
			if(repeatedContentCount.getBigDecimal(tableName, 0, "COUNT").compareTo(tryLineCount.add(eurLineCount).add(usdLineCount)) == 0) {
				
				OrderFileLog controlFile = (OrderFileLog) super.getHibernateSession().createCriteria(OrderFileLog.class)
										.add(Restrictions.eq("corporateCode", corporateCode))
				 						.add(Restrictions.eq("batchSubmitId", batchSubmitId))
				 						.add(Restrictions.eq("ftmSequenceNumber", ftmSequenceNumber))
										.uniqueResult();
				
				// SET FILE STATUS AS REPEATED FILE
				if (controlFile.getFileStatus().equals(DatabaseConstants.FileStatuses.CONTROLSSUCCESSFUL))
					controlFile.setFileStatus(DatabaseConstants.FileStatuses.CONTROLSSUCCESSFUL_REPEATEDFILE);
				else if (controlFile.getFileStatus().equals(DatabaseConstants.FileStatuses.SOMEOFTHELINESFAILED))
					controlFile.setFileStatus(DatabaseConstants.FileStatuses.SOMEOFTHELINESFAILED_REPEATEDFILE);
				else if (controlFile.getFileStatus().equals(DatabaseConstants.FileStatuses.CONTROLSFAILED))
					controlFile.setFileStatus(DatabaseConstants.FileStatuses.CONTROLSFAILED_REPEATEDFILE);
				
				super.getHibernateSession().update(controlFile);
				break;
			}			
		}
		
		super.getHibernateSession().flush();												
	}


}
