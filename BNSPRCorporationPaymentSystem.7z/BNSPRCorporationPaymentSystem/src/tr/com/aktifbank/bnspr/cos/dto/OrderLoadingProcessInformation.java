package tr.com.aktifbank.bnspr.cos.dto;

import java.math.BigDecimal;
import java.util.List;

import tr.com.aktifbank.bnspr.cos.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cos.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cos.dto.ItemServiceField;

public class OrderLoadingProcessInformation extends BaseTransferObject {
	
	public OrderLoadingProcessInformation() {
		super();
	}
	
	private int threadCount;
	private int commitCount;
	private BigDecimal ftmTransferId;
	private int errorThreshold;
	private List<FormatDetail> headerDetails;
	private List<FormatDetail> bodyDetails;
	private List<FormatDetail> footerDetails;
	private List<ItemDatabaseField> databaseFields;
	private List<ItemServiceField> serviceFields;
	private String corporateCode;
	private String serviceName;
	private int totalLineCount;
	private int totalTRYLineCount;
	private int totalUSDLineCount;
	private int totalEURLineCount;
	private BigDecimal totalTRYAmount;
	private BigDecimal totalUSDAmount;
	private BigDecimal totalEURAmount;
	private String headerCustomerAccountNo; 
	private String headerOrderDate; 
	private String headerCustomerBank;
	private String headerCustomerBranch;
	private BigDecimal headerCustomerNo;
	private Boolean lastFieldHasDynamicLength;
	private String batchSubmitId;
	private String ftmId;
	private int controlLoopCount;
	

	
	public List<ItemServiceField> getServiceFields() {
		return serviceFields;
	}

	public void setServiceFields(List<ItemServiceField> serviceFields) {
		this.serviceFields = serviceFields;
	}

	public int getControlLoopCount() {
		return controlLoopCount;
	}

	public void setControlLoopCount(int controlLoopCount) {
		this.controlLoopCount = controlLoopCount;
	}

	public String getFtmId() {
		return ftmId;
	}

	public void setFtmId(String ftmId) {
		this.ftmId = ftmId;
	}

	public String getBatchSubmitId() {
		return batchSubmitId;
	}

	public void setBatchSubmitId(String batchSubmitId) {
		this.batchSubmitId = batchSubmitId;
	}

	public int getTotalLineCount() {
		return totalLineCount;
	}

	public void setTotalLineCount(int totalLineCount) {
		this.totalLineCount = totalLineCount;
	}

	public int getTotalTRYLineCount() {
		return totalTRYLineCount;
	}

	public void setTotalTRYLineCount(int totalTRYLineCount) {
		this.totalTRYLineCount = totalTRYLineCount;
	}

	public int getTotalUSDLineCount() {
		return totalUSDLineCount;
	}

	public void setTotalUSDLineCount(int totalUSDLineCount) {
		this.totalUSDLineCount = totalUSDLineCount;
	}

	public int getTotalEURLineCount() {
		return totalEURLineCount;
	}

	public void setTotalEURLineCount(int totalEURLineCount) {
		this.totalEURLineCount = totalEURLineCount;
	}
	
	public BigDecimal getTotalTRYAmount() {
		return totalTRYAmount;
	}

	public void setTotalTRYAmount(BigDecimal totalTRYAmount) {
		this.totalTRYAmount = totalTRYAmount;
	}

	public BigDecimal getTotalUSDAmount() {
		return totalUSDAmount;
	}

	public void setTotalUSDAmount(BigDecimal totalUSDAmount) {
		this.totalUSDAmount = totalUSDAmount;
	}

	public BigDecimal getTotalEURAmount() {
		return totalEURAmount;
	}

	public void setTotalEURAmount(BigDecimal totalEURAmount) {
		this.totalEURAmount = totalEURAmount;
	}
	
	public String getHeaderCustomerAccountNo() {
		return headerCustomerAccountNo;
	}

	public void setHeaderCustomerAccountNo(String headerCustomerAccountNo) {
		this.headerCustomerAccountNo = headerCustomerAccountNo;
	}

	public String getHeaderOrderDate() {
		return headerOrderDate;
	}

	public void setHeaderOrderDate(String headerOrderDate) {
		this.headerOrderDate = headerOrderDate;
	}

	public String getHeaderCustomerBank() {
		return headerCustomerBank;
	}

	public void setHeaderCustomerBank(String headerCustomerBank) {
		this.headerCustomerBank = headerCustomerBank;
	}

	public String getHeaderCustomerBranch() {
		return headerCustomerBranch;
	}

	public void setHeaderCustomerBranch(String headerCustomerBranch) {
		this.headerCustomerBranch = headerCustomerBranch;
	}

	public BigDecimal getHeaderCustomerNo() {
		return headerCustomerNo;
	}

	public void setHeaderCustomerNo(BigDecimal headerCustomerNo) {
		this.headerCustomerNo = headerCustomerNo;
	}

	public BigDecimal getFtmTransferId() {
		return ftmTransferId;
	}

	public void setFtmTransferId(BigDecimal ftmTransferId) {
		this.ftmTransferId = ftmTransferId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public List<ItemDatabaseField> getDatabaseFields() {
		return databaseFields;
	}

	public void setDatabaseFields(List<ItemDatabaseField> databaseFields) {
		this.databaseFields = databaseFields;
	}
	
	public String getCorporateCode() {
		return corporateCode;
	}

	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	
	public List<FormatDetail> getHeaderDetails() {
		return headerDetails;
	}

	public void setHeaderDetails(List<FormatDetail> headerDetails) {
		this.headerDetails = headerDetails;
	}

	public List<FormatDetail> getBodyDetails() {
		return bodyDetails;
	}

	public void setBodyDetails(List<FormatDetail> bodyDetails) {
		this.bodyDetails = bodyDetails;
	}

	public List<FormatDetail> getFooterDetails() {
		return footerDetails;
	}

	public void setFooterDetails(List<FormatDetail> footerDetails) {
		this.footerDetails = footerDetails;
	}
	
	public void setErrorThreshold(int errorThreshold) {
		this.errorThreshold = errorThreshold;
	}
	
	public int getThreadCount(){
		return this.threadCount;
	}
	
	public void setThreadCount(int threadCount){
		this.threadCount = threadCount;
	}
	
	public int getCommitCount(){
		return this.commitCount;
	}
	
	public void setCommitCount(int commitCount){
		this.commitCount = commitCount;
	}

	public int getErrorThreshold() {
		return this.errorThreshold;
	}

	public Boolean getLastFieldHasDynamicLength() {
		return lastFieldHasDynamicLength;
	}

	public void setLastFieldHasDynamicLength(Boolean lastFieldHasDynamicLength) {
		this.lastFieldHasDynamicLength = lastFieldHasDynamicLength;
	}
}
