package tr.com.aktifbank.bnspr.cos.services;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.transactions.GetOrderDatabaseFieldsHandler;
import tr.com.aktifbank.bnspr.cos.transactions.GetOrderFileDetailFormatHandler;
import tr.com.aktifbank.bnspr.cos.transactions.GetOrderFileFooterFormatHandler;
import tr.com.aktifbank.bnspr.cos.transactions.GetOrderFileHeaderFormatHandler;
import tr.com.aktifbank.bnspr.cos.transactions.GetOrderServiceFieldsHandler;
import tr.com.aktifbank.bnspr.cos.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.OrderFileDef;
import tr.com.aktifbank.bnspr.dao.OrderFileDetail;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OrderFileFormatDefinitionServices {	
		
	private static boolean controlField(String textField) {

		boolean control = false;		
									
	    if (StringUtils.isBlank(textField)) {
			control = true; 
			return control;
		}	
		return control;
	}		
	
	private static boolean controlMustFields(GMMap iMap) {
				
		boolean control = false;
		
		String siraNo = iMap.getString("SIRA_NO");			
		String format = iMap.getString("FORMAT");
		String sabit = iMap.getString("SABIT");
		String baslangicSatir = iMap.getString("BASLANGIC_SATIR");
		String uzunluk = iMap.getString("UZUNLUK");	
		String dataType = iMap.getString("DATA_TYPE");
		
		if(controlField(siraNo) || controlField(baslangicSatir) || controlField(uzunluk))			    
			control = true; 
		else if("C".equals(dataType) && "".equals(sabit))
			control = true; 			
		else if(("T".equals(dataType) || "S".equals(dataType) || "D".equals(dataType)) && controlField(format))
			control = true;
		 
		return control;
	}
	
	@GraymoundService("COS_GET_DB_FIELD_NAMES_COMBO")
	public static GMMap getDbFieldCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "DB_FIELD_LIST";
		try {					     
			String func = "{? = call PKG_ORDER_FILE_FORMAT.GET_DB_FIELD}";				
			
			GMMap resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, new Object[0]);		

			for(int index = 0 ; index < resultMap.getSize(tableName); index++) {
				GuimlUtil.wrapMyCombo(oMap, tableName , resultMap.getString(tableName, index, "OID"),
														resultMap.getString(tableName, index, "USER_LABEL"));				
			}			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}
	
	@GraymoundService("COS_GET_UTIL_SERVICES_COMBO")
	public static GMMap getUtilServicesCombo(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "UTIL_SERVICES_LIST";
		try {			
			String func="{? = call PKG_ORDER_FILE_FORMAT.GET_UTIL_SERVICES}";
			
			GMMap resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, new Object[0]);

			for(int index = 0 ; index < resultMap.getSize(tableName); index++) {
				GuimlUtil.wrapMyCombo(oMap, tableName , resultMap.getString(tableName, index, "OID"),
														resultMap.getString(tableName, index, "EXPLANATION"));				
			}			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}			
	}		

	@GraymoundService("COS_GET_FILE_FORMAT_LIST")
	public static GMMap getFileFormatList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Object[] inputValues	= new Object[6];
		try {
			
			String func = "{? = call PKG_ORDER_FILE_FORMAT.GET_FORMAT_LIST(?,?,?)}";
			
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DOSYA_TIPI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DESEN_ADI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DESEN_ID");
			
			oMap = DALUtil.callOracleRefCursorFunction(func, "FORMAT_LIST", inputValues);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}		
	
	@GraymoundService("COS_GET_FILE_FORMAT_DETAILS_LIST")
	public static GMMap getFileFormatDetailList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Object[] inputValues	= new Object[2];
		try {
			
			String func = "{? = call PKG_ORDER_FILE_FORMAT.GET_FORMAT_DETAIL_LIST(?)}";
			
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("FORMAT_OID");
			
			oMap = DALUtil.callOracleRefCursorFunction(func, "FORMAT_DETAIL_LIST", inputValues);
			
			for (int j = 0; j < oMap.getSize("FORMAT_DETAIL_LIST"); j++) {
				String constant = oMap.getString("FORMAT_DETAIL_LIST", j, "SABIT");
				if(constant != null && constant.equals("~")){
					oMap.put("FORMAT_DETAIL_LIST", j, "SABIT", "tilda");
				}
			}			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}				
	}			
	
	@GraymoundService("COS_SAVE_FILE_FORMAT")
	public static GMMap saveFileDef(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		DateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");		
		String username = CommonHelper.getCurrentUser();
		
		try {
			Session session = CommonHelper.getHibernateSession();
			
			String oId = iMap.getString("OID");
			String newoId = null;
			String dosyaTipi = iMap.getString("DOSYA_TIPI");
			String desenAdi = iMap.getString("DESEN_ADI");
			String desenID = iMap.getString("DESEN_ID");
			String islemTipi = iMap.getString("ISLEM_TIPI");
			boolean lastFieldHasDynamicLength = iMap.getBoolean("LAST_FIELD_HAS_DYNAMIC_LENGTH");
			
			if("GUNCELLE".equals(islemTipi) || "EKLE".equals(islemTipi)) {
			    if(controlField(desenAdi)) {
			    	oMap.put("HATA", true);
			    	oMap.put("MESSAGE", "Dosya Desen Ad� alan� bo� b�rak�lamaz.");
					return oMap;
				}			
			}
			else if("SIL".equals(islemTipi)) {
				
				Object[] inputValues	= new Object[2];
				BigDecimal count	= null;		
				
				String func = "{? = call PKG_ORDER_FILE_FORMAT.GET_FORMAT_DETAIL_COUNT(?)}";
				
				int i = 0;
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = oId;
				
				count = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
				
				if (count.compareTo(BigDecimal.ZERO) > 0) {
			    	oMap.put("HATA", true);
			    	oMap.put("MESSAGE", "Dosyaya ba�l� desen detay tan�mlar� mevcuttur. Dosyay� silmek i�in �nce ba�l� tan�mlar� siliniz.");
					return oMap;				    	
				}				
			}			
			
			if("GUNCELLE".equals(islemTipi)) {
				if (StringUtils.isNotBlank(oId)) {			    
					OrderFileDef fileFormatDef = (OrderFileDef) session.createCriteria(OrderFileDef.class).add(Restrictions.eq("oid", oId)).uniqueResult();												
					fileFormatDef.setStatus(false);
					fileFormatDef.setUpdateDate(sdf.format(new Date()));
					fileFormatDef.setUpdateUser(username);
					
					session.saveOrUpdate(fileFormatDef);
					
					OrderFileDef newFileFormatDef = new OrderFileDef();
					newFileFormatDef.setStatus(true);					
					newFileFormatDef.setFileFormatId(desenID);
					newFileFormatDef.setFileType(dosyaTipi);
					newFileFormatDef.setFileFormatLabel(desenAdi);
					newFileFormatDef.setLastFieldHasDynamicLength(lastFieldHasDynamicLength);
					newFileFormatDef.setCreateDate(sdf.format(new Date()));
					newFileFormatDef.setCreateUser(username);
					
					session.saveOrUpdate(newFileFormatDef);
					newoId = newFileFormatDef.getOid();
					oMap.put("NEW_FORMAT_ID", desenID);
					oMap.put("NEW_OID", newoId);
				}						
			}
			else if("SIL".equals(islemTipi)) {
				if (StringUtils.isNotBlank(oId)) {			    
					OrderFileDef fileFormatDef = (OrderFileDef) session.createCriteria(OrderFileDef.class).add(Restrictions.eq("oid", oId)).uniqueResult();												
					fileFormatDef.setStatus(false);
					fileFormatDef.setUpdateDate(sdf.format(new Date()));
					fileFormatDef.setUpdateUser(username);
					
					session.saveOrUpdate(fileFormatDef);
					oMap.put("NEW_FORMAT_ID", "");
					oMap.put("NEW_OID", "");
				}
			}
			else if("EKLE".equals(islemTipi)) {
				OrderFileDef newFileFormatDef = new OrderFileDef();
				newFileFormatDef.setStatus(true);									
				newFileFormatDef.setFileFormatId(CorporationServiceUtil.getSequenceCode("ORDER_FILE_FORMAT_DEF"));
				newFileFormatDef.setFileType(dosyaTipi);
				newFileFormatDef.setFileFormatLabel(desenAdi);
				newFileFormatDef.setLastFieldHasDynamicLength(lastFieldHasDynamicLength);				
				newFileFormatDef.setCreateDate(sdf.format(new Date()));
				newFileFormatDef.setCreateUser(username);
				
				session.saveOrUpdate(newFileFormatDef);
				newoId = newFileFormatDef.getOid();
				oMap.put("NEW_FORMAT_ID", newFileFormatDef.getFileFormatId());
				oMap.put("NEW_OID", newoId);
			}								
			
			if (StringUtils.isNotBlank(oId)) {
				
				GMMap resultMap = new GMMap();
				Object[] inputValues	= new Object[2];
				
				String tableName = "FORMAT_DETAILS";
				String func = "{? = call PKG_ORDER_FILE_FORMAT.GET_FORMAT_DETAIL_LIST_FOR_UPD(?)}";
					
				int i = 0;
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = oId;
					
				resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
				
				for (int row = 0; row < resultMap.getSize(tableName); row++) {
						
					String detailoId = resultMap.getString(tableName, row, "OID");					
					String isMust = resultMap.getString(tableName, row, "IS_MUST");
					String lineType = resultMap.getString(tableName, row, "LINE_TYPE");
					String dataType = resultMap.getString(tableName, row, "DATA_TYPE");
					BigDecimal startIndis = resultMap.getBigDecimal(tableName, row, "START_INDIS");
					BigDecimal length = resultMap.getBigDecimal(tableName, row, "LENGTH");
					BigDecimal lineNumber = resultMap.getBigDecimal(tableName, row, "LINE_NUMBER");
					String constant = resultMap.getString(tableName, row, "CONSTANT");
					String initialConstant = resultMap.getString(tableName, row, "INITIAL_CONSTANT");
					String datasourceType = resultMap.getString(tableName, row, "DATASOURCE_TYPE");
					String datasourceReference = resultMap.getString(tableName, row, "DATASOURCE_REFERENCE");											
					Byte lineCount = null;			
					if(resultMap.getString(tableName, row, "LINE_COUNT") != null)
						lineCount = Byte.parseByte(resultMap.getString(tableName, row, "LINE_COUNT"));						
					String alignment = resultMap.getString(tableName, row, "ALIGNMENT");
					String fillingCharacter = resultMap.getString(tableName, row, "FILLING_CHARACTER");
					String dataPattern = resultMap.getString(tableName, row, "DATA_PATTERN");
					String explanation = resultMap.getString(tableName, row, "EXPLANATION");							
					
					if("SIL".equals(islemTipi)) {
						OrderFileDetail fileFormatDetail = (OrderFileDetail) session.createCriteria(OrderFileDetail.class).add(Restrictions.eq("oid", detailoId)).uniqueResult();
						fileFormatDetail.setStatus(false);
						
						session.saveOrUpdate(fileFormatDetail);
					}
					else if("GUNCELLE".equals(islemTipi)) {
						OrderFileDetail fileFormatDetail = (OrderFileDetail) session.createCriteria(OrderFileDetail.class).add(Restrictions.eq("oid", detailoId)).uniqueResult();
						fileFormatDetail.setStatus(false);
						
						session.saveOrUpdate(fileFormatDetail);
						
						OrderFileDetail newFileFormatDetail = new OrderFileDetail();						
						newFileFormatDetail.setStatus(true);					
						newFileFormatDetail.setFileFormatOid(newoId);
						newFileFormatDetail.setIsMust(isMust);
						newFileFormatDetail.setLineType(lineType);
						newFileFormatDetail.setDataType(dataType);
						newFileFormatDetail.setStartIndis(startIndis);
						newFileFormatDetail.setLength(length);
						newFileFormatDetail.setLineNumber(lineNumber);
						newFileFormatDetail.setConstant(constant);
						newFileFormatDetail.setInitialConstant(initialConstant);
						newFileFormatDetail.setDatasourceType(datasourceType);
						newFileFormatDetail.setDatasourceReference(datasourceReference);
						newFileFormatDetail.setLineCount(lineCount);
						newFileFormatDetail.setAlignment(alignment);
						newFileFormatDetail.setFillingCharacter(fillingCharacter);
						newFileFormatDetail.setDataPattern(dataPattern);			
						newFileFormatDetail.setExplanation(explanation);
						
						session.saveOrUpdate(newFileFormatDetail);	
					}								
				}						
			}

			session.flush();
			oMap.put("HATA", false);
			oMap.put("MESSAGE", "��leminiz tamamlanm��t�r.");			
			return oMap;
			
		}catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
	}		

	@GraymoundService("COS_SAVE_FILE_FORMAT_DETAILS")
	public static GMMap saveFileFormatDetail(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			Session session = CommonHelper.getHibernateSession();
					
			String oId = iMap.getString("OID");
			String fileFormatoId = iMap.getString("FILE_FORMAT_OID");						
			String lineType = iMap.getString("LINE_TYPE");
			String kurumSabit = iMap.getString("KURUM_SABIT");
			Byte satirSayisi;			
			if("".equals(iMap.getString("SATIR_SAYISI")))
				satirSayisi = null;
			else
				satirSayisi = Byte.parseByte(iMap.getString("SATIR_SAYISI"));				
			BigDecimal siraNo = iMap.getBigDecimal("SIRA_NO");			
			String datasourceType = iMap.getString("DATASOURCE_TYPE");
			String fieldDatasource = iMap.getString("FIELD_DATASOURCE");
			String serviceDatasource = iMap.getString("SERVICE_DATASOURCE");		
			String dataType = iMap.getString("DATA_TYPE");
			String format = iMap.getString("FORMAT");
			String sabit = iMap.getString("SABIT");
			Boolean trimEmptyCharacters = iMap.getBoolean("TRIM_EMPTY_CHARACTERS");
			if("tilda".equals(sabit)){
				sabit = "~";
			}
			BigDecimal baslangicSatir = iMap.getBigDecimal("BASLANGIC_SATIR");
			BigDecimal uzunluk = iMap.getBigDecimal("UZUNLUK");		
			String alanHizalama = iMap.getString("ALAN_HIZALAMA");
			String doldurmaKarakteri = iMap.getString("DOLDURMA_KARAKTERI");
			String aciklama = iMap.getString("ACIKLAMA");			
			String islemTipi = iMap.getString("ISLEM_TIPI");		
			String dosyaTipi = iMap.getString("DOSYA_TIPI");

			if("EKLE".equals(islemTipi) || "GUNCELLE".equals(islemTipi)) {
				
			    if(controlMustFields(iMap)) {
			    	oMap.put("HATA", true);
			    	if("O".equalsIgnoreCase(dosyaTipi))
			    		oMap.put("MESSAGE", "A��klama ve Doldurma Karakteri d���ndaki alanlar bo� b�rak�lamaz.");
			    	else
			    		oMap.put("MESSAGE", "A��klama d���ndaki alanlar bo� b�rak�lamaz.");
					return oMap;
				}			
			    
				GMMap xMap = new GMMap();				
				
				if("EKLE".equals(islemTipi)) { 
					try{
						 xMap  =  (GMMap) GMServiceExecuter.call("COS_CHECK_COUNT_FOR_LINE_TYPE", iMap);	
					}catch(Exception ex){
						ex.printStackTrace();
						throw ExceptionHandler.convertException(ex);
					}
					if (xMap.getBoolean("HATA"))					
						return xMap;
				}
			}
						
			if("O".equalsIgnoreCase(dosyaTipi)) {					
				
				if("GUNCELLE".equals(islemTipi)) {	
					if (StringUtils.isNotBlank(oId)) {
						OrderFileDetail fileFormatDetail = (OrderFileDetail) session.createCriteria(OrderFileDetail.class).add(Restrictions.eq("oid", oId)).uniqueResult();						
						fileFormatDetail.setStatus(false);
						
						session.saveOrUpdate(fileFormatDetail);
						
						OrderFileDetail newFileFormatDetail = new OrderFileDetail();						
						newFileFormatDetail.setStatus(true);					
						newFileFormatDetail.setFileFormatOid(fileFormatoId);					
						newFileFormatDetail.setLineType(lineType);
						newFileFormatDetail.setDataType(dataType);
						newFileFormatDetail.setStartIndis(baslangicSatir);
						newFileFormatDetail.setLength(uzunluk);
						newFileFormatDetail.setLineNumber(siraNo);
						newFileFormatDetail.setConstant(sabit);
						newFileFormatDetail.setInitialConstant(kurumSabit);
						newFileFormatDetail.setDatasourceType(datasourceType);		
						newFileFormatDetail.setLineCount(satirSayisi);
						newFileFormatDetail.setAlignment(alanHizalama);
						newFileFormatDetail.setFillingCharacter(doldurmaKarakteri);
						newFileFormatDetail.setDataPattern(format);
						newFileFormatDetail.setExplanation(aciklama);
						newFileFormatDetail.setTrimEmptyCharacters(trimEmptyCharacters);
						if("D".equals(datasourceType))
							newFileFormatDetail.setDatasourceReference(fieldDatasource);
						else if("S".equals(datasourceType))
							newFileFormatDetail.setDatasourceReference(serviceDatasource);	
						else if("B".equals(datasourceType)) {
							newFileFormatDetail.setDatasourceReference(fieldDatasource);							
							newFileFormatDetail.setDatasourceReference2(serviceDatasource);							
						}
							
						session.saveOrUpdate(newFileFormatDetail);
						oMap.put("SELECTED_OID", newFileFormatDetail.getOid());
					}
				}
				else if("SIL".equals(islemTipi)) {
					if (StringUtils.isNotBlank(oId)) {
						OrderFileDetail fileFormatDetail = (OrderFileDetail) session.createCriteria(OrderFileDetail.class).add(Restrictions.eq("oid", oId)).uniqueResult();
						fileFormatDetail.setStatus(false);
						
						session.saveOrUpdate(fileFormatDetail);
					}
				}
				else if("EKLE".equals(islemTipi)) {
					OrderFileDetail newFileFormatDetail = new OrderFileDetail();					
					newFileFormatDetail.setStatus(true);					
					newFileFormatDetail.setFileFormatOid(fileFormatoId);					
					newFileFormatDetail.setLineType(lineType);
					newFileFormatDetail.setDataType(dataType);
					newFileFormatDetail.setStartIndis(baslangicSatir);
					newFileFormatDetail.setLength(uzunluk);
					newFileFormatDetail.setLineNumber(siraNo);
					newFileFormatDetail.setConstant(sabit);
					newFileFormatDetail.setInitialConstant(kurumSabit);
					newFileFormatDetail.setDatasourceType(datasourceType);		
					newFileFormatDetail.setLineCount(satirSayisi);
					newFileFormatDetail.setAlignment(alanHizalama);
					newFileFormatDetail.setFillingCharacter(doldurmaKarakteri);
					newFileFormatDetail.setDataPattern(format);
					newFileFormatDetail.setExplanation(aciklama);	
					newFileFormatDetail.setTrimEmptyCharacters(trimEmptyCharacters);
					if("D".equals(datasourceType))
						newFileFormatDetail.setDatasourceReference(fieldDatasource);
					else if("S".equals(datasourceType))
						newFileFormatDetail.setDatasourceReference(serviceDatasource);	
					else if("B".equals(datasourceType)) {
						newFileFormatDetail.setDatasourceReference(fieldDatasource);							
						newFileFormatDetail.setDatasourceReference2(serviceDatasource);							
					}	
					
					session.saveOrUpdate(newFileFormatDetail);
					oMap.put("SELECTED_OID", "");
				}						
			}
			else if("I".equalsIgnoreCase(dosyaTipi)) {
				
				if("GUNCELLE".equals(islemTipi)) {
					if (StringUtils.isNotBlank(oId)) {
						OrderFileDetail fileFormatDetail = (OrderFileDetail) session.createCriteria(OrderFileDetail.class).add(Restrictions.eq("oid", oId)).uniqueResult();						
						fileFormatDetail.setStatus(false);

						session.saveOrUpdate(fileFormatDetail);
						
						OrderFileDetail newFileFormatDetail = new OrderFileDetail();						
						newFileFormatDetail.setStatus(true);					
						newFileFormatDetail.setFileFormatOid(fileFormatoId);					
						newFileFormatDetail.setLineType(lineType);
						newFileFormatDetail.setDataType(dataType);
						newFileFormatDetail.setStartIndis(baslangicSatir);						
						newFileFormatDetail.setLength(uzunluk);
						newFileFormatDetail.setLineNumber(siraNo);
						newFileFormatDetail.setConstant(sabit);
						newFileFormatDetail.setInitialConstant(kurumSabit);
						newFileFormatDetail.setDatasourceType(datasourceType);
						newFileFormatDetail.setLineCount(satirSayisi);
						newFileFormatDetail.setDataPattern(format);			
						newFileFormatDetail.setDatasourceReference(fieldDatasource);
						newFileFormatDetail.setExplanation(aciklama);
						newFileFormatDetail.setTrimEmptyCharacters(trimEmptyCharacters);
						if("D".equals(datasourceType))
							newFileFormatDetail.setDatasourceReference(fieldDatasource);
						else if("S".equals(datasourceType))
							newFileFormatDetail.setDatasourceReference(serviceDatasource);	
						else if("B".equals(datasourceType)) {
							newFileFormatDetail.setDatasourceReference(fieldDatasource);							
							newFileFormatDetail.setDatasourceReference2(serviceDatasource);							
						}

						session.saveOrUpdate(newFileFormatDetail);
						oMap.put("SELECTED_OID", newFileFormatDetail.getOid());
					}
				}
				else if("SIL".equals(islemTipi)) {
					if (StringUtils.isNotBlank(oId)) {
						OrderFileDetail fileFormatDetail = (OrderFileDetail) session.createCriteria(OrderFileDetail.class).add(Restrictions.eq("oid", oId)).uniqueResult();
						fileFormatDetail.setStatus(false);

						session.saveOrUpdate(fileFormatDetail);
					}
				}
				else if("EKLE".equals(islemTipi)) {
					OrderFileDetail newFileFormatDetail = new OrderFileDetail();					
					newFileFormatDetail.setStatus(true);					
					newFileFormatDetail.setFileFormatOid(fileFormatoId);					
					newFileFormatDetail.setLineType(lineType);
					newFileFormatDetail.setDataType(dataType);
					newFileFormatDetail.setStartIndis(baslangicSatir);					
					newFileFormatDetail.setLength(uzunluk);
					newFileFormatDetail.setLineNumber(siraNo);
					newFileFormatDetail.setConstant(sabit);
					newFileFormatDetail.setInitialConstant(kurumSabit);
					newFileFormatDetail.setDatasourceType(datasourceType);
					newFileFormatDetail.setLineCount(satirSayisi);
					newFileFormatDetail.setDataPattern(format);			
					newFileFormatDetail.setDatasourceReference(fieldDatasource);
					newFileFormatDetail.setExplanation(aciklama);
					newFileFormatDetail.setTrimEmptyCharacters(trimEmptyCharacters);
					if("D".equals(datasourceType))
						newFileFormatDetail.setDatasourceReference(fieldDatasource);
					else if("S".equals(datasourceType))
						newFileFormatDetail.setDatasourceReference(serviceDatasource);	
					else if("B".equals(datasourceType)) {
						newFileFormatDetail.setDatasourceReference(fieldDatasource);							
						newFileFormatDetail.setDatasourceReference2(serviceDatasource);							
					}

					session.saveOrUpdate(newFileFormatDetail);
					oMap.put("SELECTED_OID", "");
				}				
			}
			
			session.flush();
	    	oMap.put("HATA", false);
			oMap.put("MESSAGE", "i�leminiz tamamlanm��t�r.");
			return oMap;
			
		}catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}		
	}
	
	
	@GraymoundService("COS_CHECK_COUNT_FOR_LINE_TYPE")
	public static GMMap checkCountForLineType(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Object[] inputValues	= new Object[6];
		BigDecimal existing_number	= null;		
		try {
			
			String func = "{? = call PKG_ORDER_FILE_FORMAT.CHECK_COUNT_FOR_LINE_TYPE(?,?,?)}";
			
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("FILE_FORMAT_OID");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("LINE_TYPE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SIRA_NO");
			
			existing_number = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			
			if (existing_number.compareTo(BigDecimal.ZERO) > 0) {
				oMap.put("HATA", true);
				oMap.put("MESSAGE", "Mevcut sat�r tipi i�in \""+ iMap.getString("SIRA_NO") + "\" s�ra numaras� olarak daha �nce verilmi�tir. L�tfen s�ra numaras�n� de�i�tiriniz.");	
			}
			else
				oMap.put("HATA", false);
						
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}		
	
	@GraymoundService("COS_GET_ORDER_FILE_FORMAT_HEADER")
	public static GMMap getFileHeaderFormat(GMMap input){
		return RequestProcessor.getInstance().process(input, new GetOrderFileHeaderFormatHandler());
	}
	
	@GraymoundService("COS_GET_ORDER_FILE_FORMAT_DETAIL")
	public static GMMap getFileDetailFormat(GMMap input){
		return RequestProcessor.getInstance().process(input, new GetOrderFileDetailFormatHandler());
	}
	
	@GraymoundService("COS_GET_ORDER_FILE_FORMAT_FOOTER")
	public static GMMap getFileFooterFormat(GMMap input){
		return RequestProcessor.getInstance().process(input, new GetOrderFileFooterFormatHandler());
	}
	
	@GraymoundService("COS_GET_ORDER_FILE_DATABASE_FIELDS")
	public static GMMap getDatabaseFields(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetOrderDatabaseFieldsHandler());
	}

	@GraymoundService("COS_GET_ORDER_FILE_SERVICE_FIELDS")
	public static GMMap getServiceFields(GMMap input) {
		return RequestProcessor.getInstance().process(input, new GetOrderServiceFieldsHandler());
	}
}
