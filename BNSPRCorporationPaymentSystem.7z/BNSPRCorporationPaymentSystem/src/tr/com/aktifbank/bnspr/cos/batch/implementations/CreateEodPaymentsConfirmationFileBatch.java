package tr.com.aktifbank.bnspr.cos.batch.implementations;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.dto.OutgoingFileBatchInformation;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public final class CreateEodPaymentsConfirmationFileBatch extends OutgoingFileBatch {

	private static final String tableName = "Orders";
	
	public CreateEodPaymentsConfirmationFileBatch(
			OutgoingFileBatchInformation information) {
		super(information);
	}

	@Override
	protected Object getRecords() throws Throwable {
		String query = null, shortProcessDate = null;
		
		shortProcessDate = CommonHelper.getShortDateTimeString(information.getProcessDate());	
		query = String.format(QueryRepository.CreateEodPaymentsConfirmationFileBatchRepository.FILE_QUERY, shortProcessDate, information.getCorporateCode());

		return DALUtil.getResults(query, tableName);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Object getDataFromSource(String fieldName, Object records, int index) throws Throwable {
		GMMap orderRecords = (GMMap)records; 
		Object data = null;
		List<HashMap<Object, Object>> mapList = (List<HashMap<Object, Object>>)orderRecords.get(tableName);
		HashMap<Object, Object> currentIndex = mapList.get(index);
		if(currentIndex.containsKey(fieldName.toUpperCase(Locale.ROOT))){
			data = currentIndex.get(fieldName.toUpperCase(Locale.ROOT));
		}
		else{
			throw new Exception(String.format("Field %s cannot be found on both order_main and ftm_file_content", fieldName));
		}
		return data;
	}

	@Override
	protected int getRecordsSize(Object records) throws Throwable {
		GMMap paymentRecords = (GMMap)records;
		return paymentRecords.getSize(tableName);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected GMMap getCurrentRow(Object records, int index) throws Exception {
		GMMap recordSet = (GMMap)records;
		List<HashMap<Object, Object>> recordList = (List<HashMap<Object, Object>>)recordSet.get(tableName);
		HashMap<Object, Object> currentIndex = recordList.get(index);
		return CommonHelper.convertMapToGMMap(currentIndex);
	}

}
