package tr.com.aktifbank.bnspr.cos.common;

public final class Enums {
	public enum ResultSetSpecification {
		Undefined,
		UniqueRecord,
		NoRecord,
		MoreThanOneRecord,
		NotScrollable
	}
}
