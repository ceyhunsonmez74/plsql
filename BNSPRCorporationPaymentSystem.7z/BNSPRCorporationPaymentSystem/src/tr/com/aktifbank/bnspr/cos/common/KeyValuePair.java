package tr.com.aktifbank.bnspr.cos.common;

public class KeyValuePair<K, V> {

	private K key;
	private V value;
	
	public KeyValuePair() {
		
	}
	
	public KeyValuePair(K key, V value){
		this.key = key;
		this.value = value;
	}
	
	public void set(K key, V value){
		this.key = key;
		this.value = value;
	}
	
	public void setKey(K key){
		this.key = key;
	}
	
	public void setValue(V value){
		this.value = value;
	}
	
	public V getValue(){
		return this.value;
	}
	
	public K getKey(){
		return this.key;
	}
}
