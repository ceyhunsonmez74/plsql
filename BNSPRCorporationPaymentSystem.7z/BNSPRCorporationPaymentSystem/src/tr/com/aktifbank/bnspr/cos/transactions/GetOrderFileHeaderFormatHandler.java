package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.List;

import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.FormatDetail;

import com.graymound.util.GMMap;

public final class GetOrderFileHeaderFormatHandler extends RequestHandler {

	public GetOrderFileHeaderFormatHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String formatId = input.getString(TransactionConstants.GetOrderFileHeaderFormat.Input.FORMAT_ID);
		
		List<FormatDetail> details = CommonBusinessOperations.getFormatDetails(DatabaseConstants.LineType.Header, formatId, super.getHibernateSession());
		
		output.put(TransactionConstants.GetOrderFileHeaderFormat.Output.HEADER_FORMATS, details);
	}

}
