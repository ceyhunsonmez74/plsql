package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.SingleInstanceMemory;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cos.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cos.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.cos.dto.OrderLoadingProcessInformation;
import tr.com.aktifbank.bnspr.cos.multithreading.implementations.OrderLineParserImplementation;
import tr.com.aktifbank.bnspr.dao.BatchSubmitLog;
import tr.com.aktifbank.bnspr.dao.FileErrorLog;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.OrderFileDef;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.aktifbank.bnspr.dao.OrderMain;

import com.graymound.util.GMMap;

public class OrderLoadingHandler extends RequestHandler {
	
	private static final class BagKeys{
		public static final short SubmitId = 1;
		public static final short WaitingOrdersDeleted = 2;
		public static final short OperationSucceeded = 3;
		public static final short FtmTransferId = 4;
		public static final short CorporateCode = 5;	
		public static final short TotalDetailLineCount = 6;	
		public static final short ErrorneousLineCount = 7;	
		public static final short LoadingStatus = 8;	
		public static final short ErrorCode = 9;	
		public static final short ErrorMessage = 10;	
	}
	
	public OrderLoadingHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		bag.put(BagKeys.SubmitId, input.getString(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID));
		bag.put(BagKeys.OperationSucceeded, false);
		bag.put(BagKeys.WaitingOrdersDeleted, false);
		
		BigDecimal ftmTransferId = input.getBigDecimal(TransactionConstants.GeneralBatchSubmit.Input.FTM_TRANSFER_ID);
		bag.put(BagKeys.FtmTransferId, ftmTransferId);
		bag.put(BagKeys.CorporateCode, input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE));
		
		if(isSubmitIdExists(input.getString(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID))){
			logger.warn(String.format("Tried to call service with existing submit id : %s", input.getString(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID)));
			return;
		}
		
		CommonBusinessOperations.insertBatchSubmitLog(input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE), 
				input.getString(TransactionConstants.GeneralBatchSubmit.Input.BATCH_NAME), null, null, 
				input.getString(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID),
				TransactionConstants.OrderMainLoading.SERVICE_NAME, input);
		if(!CommonBusinessOperations.isCorporateActive(input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE))){
			throw new BatchComponentException(BusinessException.CORPORATEISNOTACTIVE, input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE));
		}
		
		//int totalLineCount = controlDuplicateLine(ftmTransferId);
		
		String fileLogOid = input.getString(TransactionConstants.GeneralBatchSubmit.Input.ORDER_FILE_LOG_OID);
		int totalLineCount = getTotalLineCountFromFileContent(ftmTransferId);
		
		String formatOid = input.getString(TransactionConstants.GeneralBatchSubmit.Input.FORMAT_OID);
		
		
		GMMap headerFormats = callFormatServices(TransactionConstants.GetOrderFileHeaderFormat.SERVICE_NAME, formatOid);
		GMMap detailFormat = callFormatServices(TransactionConstants.GetOrderFileDetailFormat.SERVICE_NAME, formatOid);
		GMMap footerFormats = callFormatServices(TransactionConstants.GetOrderFileFooterFormat.SERVICE_NAME, formatOid);
		Boolean lastFieldHasDynamicLength = null;
		
		OrderFileDef fileDef = (OrderFileDef) super.getHibernateSession().createCriteria(OrderFileDef.class)
												.add(Restrictions.eq("status", true))
												.add(Restrictions.eq("fileFormatId", formatOid)).uniqueResult();
		if (fileDef != null) {
			lastFieldHasDynamicLength = fileDef.getLastFieldHasDynamicLength();
		}
		
		List<FormatDetail> headerDetails = (List<FormatDetail>)headerFormats.get(TransactionConstants.GetOrderFileHeaderFormat.Output.HEADER_FORMATS);
		List<FormatDetail> bodyDetail = (List<FormatDetail>)detailFormat.get(TransactionConstants.GetOrderFileDetailFormat.Output.DETAIL_FORMAT);
		List<FormatDetail> footerDetails = (List<FormatDetail>)footerFormats.get(TransactionConstants.GetOrderFileFooterFormat.Output.FOOTER_FORMATS);
		
		List<ItemDatabaseField> databaseFields = this.getDatabaseFields();
		List<ItemServiceField> serviceFields = this.getServiceFields();
		
		String corporateCode = input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE);
		String serviceName = TransactionConstants.InsertOrderMain.SERVICE_NAME;
		
		/*if(input.containsKey(TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS)){
			BatchParameterEngine engine = new BatchParameterEngine(input.getString(TransactionConstants.GeneralBatchSubmit.Input.PARAMETERS));
			Map<String, String> decomposedParameters = engine.getDecomposedParameters();
			//....
		}*/
		
		OrderLoadingProcessInformation information = new OrderLoadingProcessInformation();
		information.setBodyDetails(bodyDetail);
		information.setCommitCount(input.getInt(TransactionConstants.GeneralBatchSubmit.Input.COMMIT_COUNT));
		information.setCorporateCode(corporateCode);
		information.setDatabaseFields(databaseFields);
		information.setErrorThreshold(input.getInt(TransactionConstants.GeneralBatchSubmit.Input.THRESHOLD));
		information.setFooterDetails(footerDetails);
		information.setFtmTransferId(ftmTransferId);
		information.setHeaderDetails(headerDetails);
		information.setServiceFields(serviceFields);
		information.setServiceName(serviceName);
		information.setLastFieldHasDynamicLength(lastFieldHasDynamicLength);
		information.setThreadCount(input.getInt(TransactionConstants.GeneralBatchSubmit.Input.THREAD_COUNT));
		information.setTotalLineCount(totalLineCount);
		information.setBatchSubmitId(input.getString(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID));
		information.setFtmId(input.getString(TransactionConstants.GeneralBatchSubmit.Input.FTM_ID));
		if(information.getErrorThreshold() < information.getTotalLineCount()){
			if(information.getErrorThreshold() < information.getThreadCount()){
				information.setControlLoopCount(1);
			}
			else{
				information.setControlLoopCount(information.getErrorThreshold() / information.getThreadCount());
			}
		}
		else{
			information.setControlLoopCount(-1);
		}
		
		OrderLineParserImplementation implementation = new OrderLineParserImplementation(information);
		implementation.execute();
		
		processResult(ftmTransferId, corporateCode, implementation);
		
		GMMap updateOrderFileLogRequest = new GMMap();		
		if(bag.containsKey(BagKeys.SubmitId))
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.SUBMIT_ID, (String)bag.get(BagKeys.SubmitId));
		if(bag.containsKey(BagKeys.TotalDetailLineCount))
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.TOTAL_DETAIL_LINE_COUNT, new BigDecimal((Integer)bag.get(BagKeys.TotalDetailLineCount)));
		if(bag.containsKey(BagKeys.ErrorneousLineCount))
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.ERRONEOUS_LINE_COUNT, new BigDecimal((Integer)bag.get(BagKeys.ErrorneousLineCount)));
		if(bag.containsKey(BagKeys.LoadingStatus))
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.LOADING_STATUS, (String)bag.get(BagKeys.LoadingStatus));
		if(bag.containsKey(BagKeys.ErrorCode))
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.ERROR_CODE, (String)bag.get(BagKeys.ErrorCode));
		if(bag.containsKey(BagKeys.ErrorMessage))
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.ERROR_MESSAGE, (String)bag.get(BagKeys.ErrorMessage));
		
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.OID, fileLogOid);
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.TRY_AMOUNT, implementation.information.getTotalTRYAmount());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.USD_AMOUNT, implementation.information.getTotalUSDAmount());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.EUR_AMOUNT, implementation.information.getTotalEURAmount());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.TRY_LINE_COUNT, implementation.information.getTotalTRYLineCount());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.USD_LINE_COUNT, implementation.information.getTotalUSDLineCount());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.EUR_LINE_COUNT, implementation.information.getTotalEURLineCount());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.ORDER_DATE, implementation.information.getHeaderOrderDate());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_NO, implementation.information.getHeaderCustomerNo());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_BANK, implementation.information.getHeaderCustomerBank());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_BRANCH, implementation.information.getHeaderCustomerBranch());
		updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_ACCOUNT_NO, implementation.information.getHeaderCustomerAccountNo());		
		GMMap updateOrderFileLogResponse = super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateOrderFileLog.SERVICE_NAME, updateOrderFileLogRequest);	
		String fileLoadingDate = updateOrderFileLogResponse.getString(TransactionConstants.UpdateOrderFileLog.Output.FILE_LOADING_DATE);
		
		GMMap getCorpDefinitionMap = new GMMap();
		getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corpDefDetailsMap = super.callGraymoundServiceInSession(TransactionConstants.GetOrderCorpDef.SERVICE_NAME, getCorpDefinitionMap);
		
		if(implementation.isHasError()){
			// y�kleme hatas� durumunda hatay� bildiren teyit maili g�nderilmesi
			if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.EMAIL_LOADING_STATUS)) {
				GMMap composeEmailInputMap = new GMMap();
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.EMAIL_TYPE, DatabaseConstants.EmailType.LOADINGFAILURE);
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.CORPORATE_CODE, corporateCode);
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_BATCH_SUBMIT_ID, information.getBatchSubmitId());
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_FTM_SEQUENCE_NUMBER, information.getFtmTransferId());
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_FTM_ID, information.getFtmId());
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_DATE, fileLoadingDate);				
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.HEADER_ORDER_DATE, information.getHeaderOrderDate());				
				super.callGraymoundServiceInSession(TransactionConstants.ComposeEmail.SERVICE_NAME, composeEmailInputMap);						
			}
		}
		else{
			// y�kleme a�amas� kontrolleri
			GMMap orderLoadingControlsRequest = new GMMap();
			orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.BATCH_SUBMIT_ID, information.getBatchSubmitId());
			orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.FTM_SEQUENCE_NUMBER, information.getFtmTransferId());
			orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.ORDER_FILE_LOG_OID, fileLogOid);
			orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.HEADER_ORDER_DATE, implementation.information.getHeaderOrderDate());
			orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.HEADER_CUSTOMER_ACCOUNT_NO, implementation.information.getHeaderCustomerAccountNo());
			orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.ALLOW_TRANSFER_TO_VALID, corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.ALLOW_TRANSFER_TO_VALID));			
			GMMap orderLoadingControlsResponse = super.callGraymoundServiceOutsideSession(TransactionConstants.OrderLoadingControls.SERVICE_NAME, orderLoadingControlsRequest);			
			String fileStatus = orderLoadingControlsResponse.getString(TransactionConstants.OrderLoadingControls.Output.FILE_STATUS);
			
			// m�kkerrer dosya kontrol�
			GMMap checkRepeatedFileRequest = new GMMap();
			checkRepeatedFileRequest.put("CORPORATE_CODE", corporateCode);
			checkRepeatedFileRequest.put("TRY_LINE_COUNT", information.getTotalTRYLineCount());
			checkRepeatedFileRequest.put("TRY_AMOUNT", information.getTotalTRYAmount());
			checkRepeatedFileRequest.put("EUR_LINE_COUNT", information.getTotalEURLineCount());
			checkRepeatedFileRequest.put("EUR_AMOUNT", information.getTotalEURAmount());
			checkRepeatedFileRequest.put("USD_LINE_COUNT", information.getTotalUSDLineCount());
			checkRepeatedFileRequest.put("USD_AMOUNT", information.getTotalUSDAmount());
			checkRepeatedFileRequest.put("LOG_DATE", new Date());
			checkRepeatedFileRequest.put("BATCH_SUBMIT_ID", information.getBatchSubmitId());
			checkRepeatedFileRequest.put("FTM_SEQUENCE_NUMBER", information.getFtmTransferId());
			super.callGraymoundServiceOutsideSession("COS_CHECK_REPEATED_FILE", checkRepeatedFileRequest);			

			// m�kkerrer kay�t kontrol�
			GMMap checkRepeatedOrderRequest = new GMMap();
			checkRepeatedOrderRequest.put(TransactionConstants.CheckRepeatedOrder.Input.CORPORATE_CODE, corporateCode);
			checkRepeatedOrderRequest.put(TransactionConstants.CheckRepeatedOrder.Input.PROCESS_DATE, new Date());
			checkRepeatedOrderRequest.put(TransactionConstants.CheckRepeatedOrder.Input.BATCH_SUBMIT_ID, information.getBatchSubmitId());
			super.callGraymoundServiceOutsideSession(TransactionConstants.CheckRepeatedOrder.SERVICE_NAME, checkRepeatedOrderRequest);			
			
			// teyit dosyas� olu�turulmas�			
			if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.MAKE_LOADING_STATUS_FILE)) {
				try {
					GMMap confirmationFileInputMap = new GMMap();
					confirmationFileInputMap.put(TransactionConstants.CreateLoadingConfirmationStarter.Input.CORPORATE_CODE, corporateCode);
					confirmationFileInputMap.put(TransactionConstants.CreateLoadingConfirmationStarter.Input.DATE, new Date());
					confirmationFileInputMap.put(TransactionConstants.CreateLoadingConfirmationStarter.Input.LOADING_BATCH_SUBMIT_ID, information.getBatchSubmitId());
					confirmationFileInputMap.put(TransactionConstants.CreateLoadingConfirmationStarter.Input.LOADING_FTM_SEQUENCE_NUMBER, information.getFtmTransferId());
					super.callGraymoundServiceOutsideSession(TransactionConstants.CreateLoadingConfirmationStarter.SERVICE_NAME, confirmationFileInputMap);										
				} catch (Exception e) {
					logger.error("An exception occured while creating content of loading confirmation file");
					logger.error(System.currentTimeMillis(), e);
				}
			}
			
			// teyit maili g�nderilmesi
			if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.EMAIL_LOADING_STATUS)) {
				GMMap composeEmailInputMap = new GMMap();
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.EMAIL_TYPE, DatabaseConstants.EmailType.LOADINGCONFIRMATION);
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.CORPORATE_CODE, corporateCode);
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_BATCH_SUBMIT_ID, information.getBatchSubmitId());
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_FTM_SEQUENCE_NUMBER, information.getFtmTransferId());
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_FTM_ID, information.getFtmId());
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.LOADING_DATE, fileLoadingDate);				
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.HEADER_ORDER_DATE, information.getHeaderOrderDate());
				composeEmailInputMap.put(TransactionConstants.ComposeEmail.Input.FILE_STATUS, fileStatus);
				super.callGraymoundServiceInSession(TransactionConstants.ComposeEmail.SERVICE_NAME, composeEmailInputMap);		
			}
			
			// onays�z �deme burada yap�lacak
			if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.TRANSFER_WITHOUT_APPROVAL)) {
				
				int transferTRYCount = 0, transferUSDCount = 0, transferEURCount = 0;
				BigDecimal transferTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
				BigDecimal transferUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
				BigDecimal transferEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
				String tableName = TransactionConstants.GetOrderFileContent.tableName;
				
				String amountOrder = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING);	
				//BigDecimal customerNo = corpDefDetailsMap.getBigDecimal(TransactionConstants.GetOrderCorpDef.Output.CUSTOMER_NO);
				GMMap withoutApprovalTransferMap = new GMMap();
								
				Criteria criteria = super.getHibernateSession().createCriteria(OrderMain.class)
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("ftmSequenceNumber", information.getFtmTransferId()))
									.add(Restrictions.eq("batchSubmitId", information.getBatchSubmitId()))
									.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.Waiting))
									.add(Restrictions.le("orderStatus", DatabaseConstants.OrderStatuses.RepeatedOrder));				
				if (StringUtils.isNotBlank(amountOrder)) {				
					if (amountOrder.equals("D"))
						criteria = criteria.addOrder(Order.desc("amount"));
					else if (amountOrder.equals("A"))
						criteria = criteria.addOrder(Order.asc("amount"));
				} else 
					criteria = criteria.addOrder(Order.asc("lineNumber"));				
				List<OrderMain> orderList = criteria.list();
					
				int count = 0;
				for (OrderMain order : orderList) {					
				
					withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT, true);
					withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE, order.getOrderStatus());
					withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.MAIN_OID, order.getOid());
					count++;
											
					if (order.getCurrencyCode().equals(DatabaseConstants.CurrencyCodes.TRY)) {
						transferTRYCount++;
						transferTRYAmount = transferTRYAmount.add(order.getAmount()); 						
					} else if (order.getCurrencyCode().equals(DatabaseConstants.CurrencyCodes.USD)) {
						transferUSDCount++;
						transferUSDAmount = transferUSDAmount.add(order.getAmount()); 						
					} else if (order.getCurrencyCode().equals(DatabaseConstants.CurrencyCodes.EUR)) {
						transferEURCount++;
						transferEURAmount = transferEURAmount.add(order.getAmount()); 						
					}
				}
				
				if (transferTRYCount > 0 || transferUSDCount > 0 || transferEURCount > 0) {	

					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.CORPORATE_CODE, corporateCode);
					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.TRY_AMOUNT, transferTRYAmount);
					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.USD_AMOUNT, transferUSDAmount);
					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.EUR_AMOUNT, transferEURAmount);
					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.TRY_RECORD_COUNT, transferTRYCount);
					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.USD_RECORD_COUNT, transferUSDCount);
					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.EUR_RECORD_COUNT, transferEURCount);
					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.BATCH_SUBMIT_ID, information.getBatchSubmitId());
					withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.TRANSFER_WITHOUT_APPROVAL, true);

					OrderFileLog fileLog = (OrderFileLog) super.getHibernateSession().createCriteria(OrderFileLog.class)
															.add(Restrictions.eq("status", true)).add(Restrictions.eq("batchSubmitId", information.getBatchSubmitId())).uniqueResult();
					if (fileLog != null) {
						withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.ORDER_DATE, fileLog.getOrderDate());
						withoutApprovalTransferMap.put("FILE_STATUS", fileLog.getFileStatus());
					}
					
					CommonHelper.callGraymoundServiceOutsideSession("COS_ORDER_TRANSACTION", withoutApprovalTransferMap);
				}
			
			}
		} 
	}

	@SuppressWarnings("unchecked")
	private List<ItemDatabaseField> getDatabaseFields() throws Exception {
		return (List<ItemDatabaseField>)super.callServiceWithParams(TransactionConstants.GetOrderDatabaseFields.SERVICE_NAME)
				.get(TransactionConstants.GetOrderDatabaseFields.Output.FIELDS);
	}
	
	@SuppressWarnings("unchecked")
	private List<ItemServiceField> getServiceFields() {
		return (List<ItemServiceField>)super.callServiceWithParams(TransactionConstants.GetOrderServiceFields.SERVICE_NAME)
				.get(TransactionConstants.GetOrderServiceFields.Output.FIELDS);
	}
	
	private boolean isSubmitIdExists(String submitId) {
		int count = CommonHelper.getCountOfRows(super.getHibernateSession(), BatchSubmitLog.class, "batchSubmitId", submitId);
		return count > 0;
	}

	private int getTotalLineCountFromFileContent(BigDecimal ftmTransferId) {
		return CommonHelper.getCountOfRows(super.getHibernateSession(), FtmFileContent.class, "ftmProcessOid", ftmTransferId);
	}
	
	private void processResult(BigDecimal ftmTransferId, String corporateCode, OrderLineParserImplementation implementation) {
		if(implementation.isHasError()){
			CommonBusinessOperations.updateBatchSubmitLog(bag.get(BagKeys.SubmitId).toString(), 
					DatabaseConstants.SubmitStatuses.FAILURE, 
					new Date(),
					implementation.getErrorCode(), 
					implementation.getErrorMessage());
			bag.put(BagKeys.LoadingStatus, DatabaseConstants.LoadingStatuses.FAILURE);
			bag.put(BagKeys.ErrorCode, implementation.getErrorCode());
			bag.put(BagKeys.ErrorMessage, implementation.getErrorMessage());
			
			int erroneousLineCount = getFailedLineCountAtLoading(implementation.information.getBatchSubmitId(), implementation.information.getFtmId(), ftmTransferId);
			int totalDetailLineCount = implementation.information.getTotalLineCount() + erroneousLineCount;
			bag.put(BagKeys.ErrorneousLineCount, erroneousLineCount);	
			bag.put(BagKeys.TotalDetailLineCount, totalDetailLineCount);
		}
		else{
			bag.put(BagKeys.OperationSucceeded, true);
			GMMap updateOrderMainStatusRequest = new GMMap();			
			updateOrderMainStatusRequest.put(TransactionConstants.UpdateOrderMainStatus.Input.FTM_SEQUENCE_NUMBER, ftmTransferId);
			updateOrderMainStatusRequest.put(TransactionConstants.UpdateOrderMainStatus.Input.CORPORATE_CODE, corporateCode);
			super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateOrderMainStatus.SERVICE_NAME, updateOrderMainStatusRequest);		
			
			CommonBusinessOperations.updateBatchSubmitLog(bag.get(BagKeys.SubmitId).toString(), DatabaseConstants.SubmitStatuses.SUCESSFUL, new Date(), null, null);
			bag.put(BagKeys.LoadingStatus, DatabaseConstants.LoadingStatuses.SUCESSFUL);
			
			int totalDetailLineCount = implementation.information.getTotalLineCount();
			bag.put(BagKeys.TotalDetailLineCount, totalDetailLineCount);
		}
	}

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		this.handleError(e, output);
	}

	@Override
	protected void handleError(Throwable e, GMMap output) {
		logger.error(System.currentTimeMillis(), e);
		String errorCode = "1";
		String errorMessage = String.format("An exception occured while executing order loading. %s", CommonHelper.getStringifiedException(e));
		if(e instanceof BatchComponentException){
			BatchComponentException exception = (BatchComponentException)e;
			errorCode = String.valueOf(exception.getCode());
			errorMessage = exception.getMessage();
		}
		CommonBusinessOperations.updateBatchSubmitLog(bag.get(BagKeys.SubmitId).toString(), DatabaseConstants.SubmitStatuses.FAILURE, new Date(), errorCode, errorMessage);
	}
	
	@Override
	protected void handleFinally(GMMap output) {
		try{
			SingleInstanceMemory.getInstance().removeCache((String)bag.get(BagKeys.SubmitId));
		}
		catch(Exception e){
			logger.error("An exception occured while removing order cache");
			logger.error(System.currentTimeMillis(), e);
		}
		if(!(Boolean)bag.get(BagKeys.OperationSucceeded) && (Boolean)bag.get(BagKeys.WaitingOrdersDeleted)){
			try{
				rollbackWaitingOrdersDeletion();
			}
			catch(Exception e){
				logger.error(String.format("An error occured while rollbacking waiting orders with transfer id %s", bag.get(BagKeys.FtmTransferId)));
				logger.error(System.currentTimeMillis(), e);
			}
		}
	}

	private void rollbackWaitingOrdersDeletion() {
		String query = String.format("UPDATE COS.ORDER_MAIN SET STATUS = 1, DELETED_TRANSFER_ID = null WHERE DELETED_TRANSFER_ID = %s", bag.get(BagKeys.FtmTransferId));
		super.getHibernateSession().createSQLQuery(query).executeUpdate();
	}

	private GMMap callFormatServices(String serviceName, String formatOid) {
		return super.callGraymoundServiceInSession(serviceName, new GMMap().put(TransactionConstants.FORMAT_ID_GENERAL_KEY, formatOid));
	}
	
	private int getFailedLineCountAtLoading(String batchSubmitId, String ftmId, BigDecimal ftmTransferId) {
		return ((Number)super.getHibernateSession()
				.createCriteria(FileErrorLog.class)
				.add(Restrictions.eq("batchSubmitId", batchSubmitId))
				.add(Restrictions.eq("ftmId", ftmId))
				.add(Restrictions.eq("ftmSequenceNumber", ftmTransferId))
				.setProjection(Projections.rowCount())
				.uniqueResult()).intValue();
	}
}
