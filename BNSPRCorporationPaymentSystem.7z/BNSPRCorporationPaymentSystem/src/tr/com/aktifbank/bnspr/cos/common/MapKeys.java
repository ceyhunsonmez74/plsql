package tr.com.aktifbank.bnspr.cos.common;

public interface MapKeys {
	public static String TRX_NO = "TRX_NO";
	public static String TRX_NAME = "TRX_NAME";
    public static final String FTS_OUTPUT_DATA = "DATA"; 
	public static final String BATCH_SERVICE_NAME_FOR_RESUBMIT  = "BATCH_SERVICE_NAME_FOR_RESUBMIT ";

}