package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OrderTransaction;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ApprovedPaymentTransferHandler extends RequestHandler {

	public ApprovedPaymentTransferHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		Date processDate = new Date();
		
		@SuppressWarnings("unchecked")
		List<OrderTransaction> orderTransactionList = super.getHibernateSession().createCriteria(OrderTransaction.class)
													   .add(Restrictions.eq("status", true))
													   .add(Restrictions.eq("transactionStatus", DatabaseConstants.TransactionStatus.APPROVED))
													   .addOrder(Order.asc("createDate")).list();
		
		// set transaction status to processing started
		GMMap updateTransactionStatusRequest = new GMMap();			
		updateTransactionStatusRequest.put(TransactionConstants.UpdateTransactionStatus.Input.SET_PROCESSING_STARTED, true);
		super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateTransactionStatus.SERVICE_NAME, updateTransactionStatusRequest);	
		
		Map<String, List<BigDecimal>> batchSubmitIdTransactionMap = new LinkedHashMap<String, List<BigDecimal>>();
		for (OrderTransaction orderTransaction : orderTransactionList) {			
			if (!batchSubmitIdTransactionMap.containsKey(orderTransaction.getBatchSubmitId())) {
				List<BigDecimal> txList = new ArrayList<BigDecimal>();
				txList.add(orderTransaction.getTxNo());
				batchSubmitIdTransactionMap.put(orderTransaction.getBatchSubmitId(), txList);
			} else {
				List<BigDecimal> txList = batchSubmitIdTransactionMap.get(orderTransaction.getBatchSubmitId());
				txList.add(orderTransaction.getTxNo());
				batchSubmitIdTransactionMap.put(orderTransaction.getBatchSubmitId(), txList);
			}
		}
		
		String maxParallelFilePaymentCount = CommonHelper.getValueOfParameter("COS_PARAMETERS", "MAX_PARALLEL_FILE_PAYMENT_COUNT");
		List<GMMap> parallelTransferTaskList = new ArrayList<GMMap>();
		
		for (Map.Entry<String, List<BigDecimal>> entry : batchSubmitIdTransactionMap.entrySet()) {
			GMMap parallelCallInput = new GMMap();
			parallelCallInput.put(TransactionConstants.OrderTransfersApproved.Input.TRANSFER_TYPE, GeneralConstants.APPROVALTRANSFER);
			parallelCallInput.put(TransactionConstants.OrderTransfersApproved.Input.PROCESS_DATE, processDate);
			parallelCallInput.put(TransactionConstants.OrderTransfersApproved.Input.TRANSACTION_TX_LIST, entry.getValue());
			parallelCallInput.put("T_SERVICE_NAME", TransactionConstants.OrderTransfersApproved.SERVICE_NAME);
			
			parallelTransferTaskList.add(parallelCallInput);
			if(parallelTransferTaskList.size() == Integer.valueOf(maxParallelFilePaymentCount)){
				GMMap parallelTransferMap = new GMMap();
				parallelTransferMap.put("T_TASKS", parallelTransferTaskList);
				GMServiceExecuter.callParallel(parallelTransferMap);
				parallelTransferTaskList.clear();
			}
		}
		
		if(parallelTransferTaskList.size() > 0){
			GMMap parallelTransferMap = new GMMap();
			parallelTransferMap.put("T_TASKS", parallelTransferTaskList);
			GMServiceExecuter.callParallel(parallelTransferMap);
			parallelTransferTaskList.clear();
		}
		
		CommonBusinessOperations.sendDuplicatePaymentEmail(processDate);
	}
}
