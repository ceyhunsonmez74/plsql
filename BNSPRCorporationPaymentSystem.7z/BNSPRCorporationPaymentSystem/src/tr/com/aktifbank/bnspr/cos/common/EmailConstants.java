package tr.com.aktifbank.bnspr.cos.common;

public interface EmailConstants {

	public final static String FROM = "NakitYonetimiopbirimi@aktifbank.com.tr";
	public final static String FROM_CASH_MANAGEMENT_ANALYSTS_GROUP = "nakityonetimiisanaliziekibi@aktifbank.com.tr";
	public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
	public final static String SUBJECT = "Kurumunun Hesap Aktar�m�nda Hata";
	public final static String MESSAGE_BODY_4_USAGE_ACCOUNT ="<html><head></head><body> <b>Kurum Ad� : </b> KURUM_ADI <br /> <b>Kurum Kodu : " +
			"</b> KURUM_KODU <br /> <b> Kaynak Hesap : </b> KAYNAK_HESAP <br /> <b> Hedef Hesap : </b> HEDEF_HESAP <br /> " +
			"<b>Hata : </b> HATA </body></html>";
	public final static String MESSAGE_BODY_4_EFT_ACCOUNT ="<html><head></head><body> <b>Kurum Ad� : </b> KURUM_ADI <br /> <b>Kurum Kodu : " +
			"</b> KURUM_KODU <br /> <b> Kaynak Hesap : </b> KAYNAK_HESAP <br /> <b> Hedef IBAN : </b> HEDEF_IBAN <br /> " +
			"<b>Hata : </b> HATA </body></html>";
	
	
	
	
	
	public static class Email{
		
		public final static String FROM = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr";
		
		public static class TransferBalanceMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = " Kurumunun Hesap Aktar�m�nda Hata";
			
			public static class Body{
				
				public final static String MESSAGE_BODY_4_USAGE_ACCOUNT ="<html><head></head><body> <b>Kurum Ad� : </b> KURUM_ADI <br /> <b>Kurum Kodu : " +
						"</b> KURUM_KODU <br /> <b> Kaynak Hesap : </b> KAYNAK_HESAP <br /> <b> Hedef Hesap : </b> HEDEF_HESAP <br /> " +
						"<b>Hata : </b> HATA </body></html>";
				public final static String MESSAGE_BODY_4_EFT_ACCOUNT ="<html><head></head><body> <b>Kurum Ad� : </b> KURUM_ADI <br /> <b>Kurum Kodu : " +
						"</b> KURUM_KODU <br /> <b> Kaynak Hesap : </b> KAYNAK_HESAP <br /> <b> Hedef IBAN : </b> HEDEF_IBAN <br /> " +
						"<b>Hata : </b> HATA </body></html>";
			}	
		}
		
		public static class DailyReportMessageConstant{
			
			public final static String RECEIPT_LIST = "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr,NakitYonetimiopbirimi@aktifbank.com.tr";
			public final static String SUBJECT = "NYS Fatura Tahsilatlar� G�nl�k Otomatik Mail Raporu";
			
			public final static String MESSAGE_BODY = "<html><head></head><body> --ENVIRONMENT-- ortaminda CURRENT_DATE tarihli NYS Tahsilat islemlerinde " +
					"TOTAL_PAYMENT_COUNT  adet,  SUMMARY_PAYMENT_AMOUNT TL " +
					"tutar�nda  fatura tahsilat� muhasebele�tirilmi�tir<br /> " +
					"<ul> <li>" +
					"<b>Kurum Ad� :</b> KURUM_ADI , <b>Toplam Fatura Adeti :</b> PAYMENT_COUNT  adet, <b>Toplam Tahsilat Tutar� :</b> TOTAL_PAYMENT_AMOUNT TL" +
					"</li> </ul>";
		}
		
		
	}
	
}
