package tr.com.aktifbank.bnspr.cos.services;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.FtmProcess;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.aktifbank.bnspr.dao.OrderTransaction;
import tr.com.aktifbank.bnspr.dao.OrderTransferLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class OrderTransferServices {
	 
	 @GraymoundService("COS_ORDER_LINE_SELECTED")
	 public static GMMap getOrderLineSelected (GMMap input) {
		GMMap output = new GMMap();
		try {	
			String tableName = TransactionConstants.OrderLineSelection.tableName;
			int selectedTRYCount = 0, selectedUSDCount = 0, selectedEURCount = 0;
			BigDecimal selectedTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal selectedUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal selectedEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			
			for (int count = 0; count < input.getSize(tableName); count++) {
				if (input.getBoolean(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT)) {
					if (input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.CURRENCY_CODE).equals(DatabaseConstants.CurrencyCodes.TRY)) {
						selectedTRYCount++;
						selectedTRYAmount = selectedTRYAmount.add(input.getBigDecimal(tableName, count, TransactionConstants.GetOrderFileContent.Output.AMOUNT)); 						
					} else if (input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.CURRENCY_CODE).equals(DatabaseConstants.CurrencyCodes.USD)) {
						selectedUSDCount++;
						selectedUSDAmount = selectedUSDAmount.add(input.getBigDecimal(tableName, count, TransactionConstants.GetOrderFileContent.Output.AMOUNT)); 						
					} else if (input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.CURRENCY_CODE).equals(DatabaseConstants.CurrencyCodes.EUR)) {
						selectedEURCount++;
						selectedEURAmount = selectedEURAmount.add(input.getBigDecimal(tableName, count, TransactionConstants.GetOrderFileContent.Output.AMOUNT)); 						
					}										
				}
			}		
			if (selectedTRYCount > 0 || selectedUSDCount > 0 || selectedEURCount > 0)
				output.put(TransactionConstants.OrderLineSelection.Output.ENABLE_TRANSFER, true);
			else
				output.put(TransactionConstants.OrderLineSelection.Output.ENABLE_TRANSFER, false);
			output.put(TransactionConstants.OrderLineSelection.Output.SELECTED_TRY_COUNT, selectedTRYCount);
			output.put(TransactionConstants.OrderLineSelection.Output.SELECTED_TRY_AMOUNT, selectedTRYAmount);
			output.put(TransactionConstants.OrderLineSelection.Output.SELECTED_USD_COUNT, selectedUSDCount);
			output.put(TransactionConstants.OrderLineSelection.Output.SELECTED_USD_AMOUNT, selectedUSDAmount);
			output.put(TransactionConstants.OrderLineSelection.Output.SELECTED_EUR_COUNT, selectedEURCount);
			output.put(TransactionConstants.OrderLineSelection.Output.SELECTED_EUR_AMOUNT, selectedEURAmount);
			output.put(tableName, input.get(tableName));
			
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }	  
	 
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_ORDER_TRANSACTION")
	public static GMMap orderTransaction(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			OrderMain order = null;
			OrderTransaction orderTransaction = null;
			
			String tableName = TransactionConstants.OrderTransaction.tableName;
			String corporateCode = input.getString(TransactionConstants.OrderTransaction.Input.CORPORATE_CODE);
			BigDecimal TRYAmount = input.getBigDecimal(TransactionConstants.OrderTransaction.Input.TRY_AMOUNT);
			BigDecimal USDAmount = input.getBigDecimal(TransactionConstants.OrderTransaction.Input.USD_AMOUNT);
			BigDecimal EURAmount = input.getBigDecimal(TransactionConstants.OrderTransaction.Input.EUR_AMOUNT);
			BigDecimal TRYRecordCount = input.getBigDecimal(TransactionConstants.OrderTransaction.Input.TRY_RECORD_COUNT);
			BigDecimal USDRecordCount = input.getBigDecimal(TransactionConstants.OrderTransaction.Input.USD_RECORD_COUNT);
			BigDecimal EURRecordCount = input.getBigDecimal(TransactionConstants.OrderTransaction.Input.EUR_RECORD_COUNT);
			String batchSubmitId = input.getString(TransactionConstants.OrderTransaction.Input.BATCH_SUBMIT_ID);
			String fileOrderDateStr = input.getString(TransactionConstants.OrderTransaction.Input.ORDER_DATE);
			Boolean transferWithoutApproval = input.getBoolean(TransactionConstants.OrderTransaction.Input.TRANSFER_WITHOUT_APPROVAL);
			String fileStatus = input.getString("FILE_STATUS");
			String username = CommonHelper.getCurrentUser();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			GMMap transactionMap = null;			
			BigDecimal transactionNo = new BigDecimal(CommonHelper.getNewTransactionNo());
			String orderStatus = null;
			Boolean _7209Transaction = false;
			if (fileStatus.equals(DatabaseConstants.FileStatuses.CONTROLSSUCCESSFUL_REPEATEDFILE) ||
					fileStatus.equals(DatabaseConstants.FileStatuses.SOMEOFTHELINESFAILED_REPEATEDFILE)) {
				_7209Transaction = true;
			}
			
			Date bankDate = dateFormat.parse(CommonHelper.getShortDateTimeString(new Date()));
			Date fileOrderDate = null;
			if (StringUtils.isNotEmpty(fileOrderDateStr))
				fileOrderDate = dateFormat.parse(fileOrderDateStr);
			
			if(fileOrderDate != null && fileOrderDate.compareTo(bankDate) < 0) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.NOTVALIDORDERDATE));
			
			List<OrderTransaction> approvedTransactionList = hibernateSession.createCriteria(OrderTransaction.class)
						   .add(Restrictions.eq("status", true))
						   .add(Restrictions.eq("batchSubmitId", batchSubmitId))
						   .add(Restrictions.eq("transactionStatus", DatabaseConstants.TransactionStatus.APPROVED)).list();
			for (OrderTransaction approvedTransaction : approvedTransactionList) {	
				List<OrderMain> approvedOrderList = hibernateSession.createCriteria(OrderMain.class)
											   .add(Restrictions.eq("status", true))
											   .add(Restrictions.eq("mainTxNo", approvedTransaction.getTxNo()))
											   .add(Restrictions.eq("orderStatus", DatabaseConstants.OrderStatuses.Approved)).list();
				for (OrderMain approvedOrder : approvedOrderList) {
					for (int count = 0; count < input.getSize(tableName); count++) {
						if (input.getBoolean(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT) &&
								( input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE).equals(DatabaseConstants.OrderStatuses.Waiting)
										|| input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE).equals(DatabaseConstants.OrderStatuses.RepeatedOrder) ) 
								&& approvedOrder.getOid().equals(input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.MAIN_OID)) )
							CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.SOMEOFTHEORDERSALREADYAPPROVED));
					}
				}
			}
			
			if (transferWithoutApproval && !_7209Transaction)
				orderStatus = DatabaseConstants.OrderStatuses.Approved;
			else
				orderStatus = DatabaseConstants.OrderStatuses.WaitingApproval;
			
			// calculate commission
			BigDecimal commissionAmount = new BigDecimal(0);
			
			for (int count = 0; count < input.getSize(tableName); count++) {
				if (input.getBoolean(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT) &&
					( input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE).equals(DatabaseConstants.OrderStatuses.Waiting)
					  || input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE).equals(DatabaseConstants.OrderStatuses.RepeatedOrder) ) ) {
					
					order = (OrderMain) hibernateSession.createCriteria(OrderMain.class)
										.add(Restrictions.eq("status", true))
										.add(Restrictions.eq("oid", input.getString(tableName, count, TransactionConstants.GetOrderFileContent.Output.MAIN_OID))).uniqueResult();						
					if (order != null) {
						GMMap orderTransferMap = new GMMap();
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_NAME, order.getRecipientName());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_ADDRESS, order.getRecipientAddress());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_MOTHER_NAME, order.getRecipientMotherName());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_FATHER_NAME, order.getRecipientFatherName());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_BANK, order.getRecipientBank());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_DATE_OF_BIRTH, order.getRecipientDateOfBirth());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_EMAIL, order.getRecipientEmail());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_ACCOUNT_NO, order.getRecipientAccountNo());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_IBAN, order.getRecipientIban());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_CC_NO, order.getRecipientCcNo());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_REF_NO, order.getRecipientRefNo());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_BRANCH, order.getRecipientBranch());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_TCKN, order.getRecipientTckn());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_PHONE_NUMBER, order.getRecipientPhoneNumber());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_VKN, order.getRecipientVkn());				
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.ACCOUNT_NO, order.getAccountNo());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.EXPLANATION, order.getExplanation());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.ORDER_STATUS, orderStatus);
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.ORDER_TYPE, order.getOrderType());					
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.MAIN_TX_NO, transactionNo);					
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.COMMISSION_ACCOUNT_NO, order.getCommissionAccountNo());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.COMMISSION_AMOUNT, commissionAmount);
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.CUSTOMER_NAME, order.getCustomerName());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.CUSTOMER_NO, order.getCustomerNo());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.CURRENCY_CODE, order.getCurrencyCode());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.TRANSFER_TYPE, order.getTransferType());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.AMOUNT, order.getAmount());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.TAX_OFFICE, order.getTaxOffice());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.MAIN_OID, order.getOid());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.CORPORATE_CODE, order.getCorporateCode());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.ORDER_DATE, order.getOrderDate());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.PAYMENT_ACCOUNT_NO, order.getPaymentAccountNo());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.PAYMENT_COMMISSION_ACCOUNT_NO, order.getPaymentCommissionAccountNo());
						orderTransferMap.put(TransactionConstants.InsertOrderTransferLog.Input.LINE_NUMBER, order.getLineNumber());
						
						insertOrderTransferLog(orderTransferMap, hibernateSession);
						
						order.setOrderStatus(orderStatus);
						order.setMainTxNo(transactionNo);				
						order.setCommissionAmount(commissionAmount);
						order.setTransactionCreateUser(username);
						hibernateSession.update(order);
					}
				}
			}
			
			GMMap getCorpDefinitionMap = new GMMap();
			getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
			GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
			BigDecimal customerNo = corpDefDetailsMap.getBigDecimal(TransactionConstants.GetOrderCorpDef.Output.CUSTOMER_NO);
			
			orderTransaction = new OrderTransaction();
			orderTransaction.setStatus(true);
			orderTransaction.setTransactionStatus(DatabaseConstants.TransactionStatus.NOT_APPROVED);
			orderTransaction.setTxNo(transactionNo);
			orderTransaction.setCorporateCode(corporateCode);
			orderTransaction.setCustomerNo(customerNo);
			orderTransaction.setTryAmount(TRYAmount);
			orderTransaction.setUsdAmount(USDAmount);
			orderTransaction.setEurAmount(EURAmount);
			orderTransaction.setTryRecordCount(TRYRecordCount);
			orderTransaction.setUsdRecordCount(USDRecordCount);
			orderTransaction.setEurRecordCount(EURRecordCount);
			orderTransaction.setBatchSubmitId(batchSubmitId);
			orderTransaction.setCreateUser(username);
			orderTransaction.setCreateDate(CommonHelper.getLongDateTimeString(new Date()));				
			hibernateSession.save(orderTransaction);
			
			hibernateSession.flush();				
			
			if (_7209Transaction)
				input.put("TRX_NAME", "7209");
			else 
				input.put("TRX_NAME", "7210");
			input.put("TRX_NO", transactionNo);
			if(transferWithoutApproval && !_7209Transaction)
				input.put("TRX_ONAYSIZ_ISLEM", "E");
					
			transactionMap = CommonBusinessOperations.callGraymoundService(input, "BNSPR_TRX_SEND_TRANSACTION", true);
			output.put("MESSAGE", transactionMap.getString("MESSAGE"));					
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	}	
	
	private static void insertOrderTransferLog(GMMap input, Session hibernateSession) {	
		String recipientName = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_NAME);
		String recipientAddress = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_ADDRESS);
		String recipientFatherName = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_FATHER_NAME);
		String recipientMotherName = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_MOTHER_NAME);
		String recipientBank = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_BANK);
		String recipientDateOfBirth = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_DATE_OF_BIRTH);
		String recipientEmail = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_EMAIL);
		String recipientAccountNo = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_ACCOUNT_NO);
		String recipientIban = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_IBAN);
		String recipientCcNo = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_CC_NO);
		String recipientRefNo = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_REF_NO);
		String recipientBranch = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_BRANCH);
		String recipientTckn = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_TCKN);
		String recipientPhoneNumber = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_PHONE_NUMBER);
		String recipientVkn = input.getString(TransactionConstants.InsertOrderTransferLog.Input.RECIPIENT_VKN);				
		String accountNo = input.getString(TransactionConstants.InsertOrderTransferLog.Input.ACCOUNT_NO);
		String explanation = input.getString(TransactionConstants.InsertOrderTransferLog.Input.EXPLANATION);
		String orderStatus = input.getString(TransactionConstants.InsertOrderTransferLog.Input.ORDER_STATUS);
		String orderType = input.getString(TransactionConstants.InsertOrderTransferLog.Input.ORDER_TYPE);
		BigDecimal mainTxNo = input.getBigDecimal(TransactionConstants.InsertOrderTransferLog.Input.MAIN_TX_NO);
		String commissionAccountNo = input.getString(TransactionConstants.InsertOrderTransferLog.Input.COMMISSION_ACCOUNT_NO);
		BigDecimal commissionAmount = input.getBigDecimal(TransactionConstants.InsertOrderTransferLog.Input.COMMISSION_AMOUNT);
		String customerName = input.getString(TransactionConstants.InsertOrderTransferLog.Input.CUSTOMER_NAME);
		String customerNo = input.getString(TransactionConstants.InsertOrderTransferLog.Input.CUSTOMER_NO);
		String currencyCode = input.getString(TransactionConstants.InsertOrderTransferLog.Input.CURRENCY_CODE);
		String transferType = input.getString(TransactionConstants.InsertOrderTransferLog.Input.TRANSFER_TYPE);
		BigDecimal amount = input.getBigDecimal(TransactionConstants.InsertOrderTransferLog.Input.AMOUNT);
		String taxOffice = input.getString(TransactionConstants.InsertOrderTransferLog.Input.TAX_OFFICE);
		String mainOid = input.getString(TransactionConstants.InsertOrderTransferLog.Input.MAIN_OID);
		String corporateCode = input.getString(TransactionConstants.InsertOrderTransferLog.Input.CORPORATE_CODE);
		String orderDate = input.getString(TransactionConstants.InsertOrderTransferLog.Input.ORDER_DATE);
		BigDecimal paymentAccountNo = input.getBigDecimal(TransactionConstants.InsertOrderTransferLog.Input.PAYMENT_ACCOUNT_NO);
		BigDecimal paymentCommissionAccountNo = input.getBigDecimal(TransactionConstants.InsertOrderTransferLog.Input.PAYMENT_COMMISSION_ACCOUNT_NO);
		BigDecimal lineNumber = input.getBigDecimal(TransactionConstants.InsertOrderTransferLog.Input.LINE_NUMBER);
		
		OrderTransferLog log = new OrderTransferLog();
		log.setStatus(true);
		log.setCorporateCode(corporateCode);
		log.setOrderMainOid(mainOid);
		log.setRecipientName(recipientName);
		log.setRecipientAddress(recipientAddress);
		log.setRecipientFatherName(recipientFatherName);
		log.setRecipientMotherName(recipientMotherName);
		log.setRecipientBank(recipientBank);
		log.setRecipientDateOfBirth(recipientDateOfBirth);
		log.setRecipientEmail(recipientEmail);
		log.setRecipientAccountNo(recipientAccountNo);
		log.setRecipientIban(recipientIban);
		log.setRecipientCcNo(recipientCcNo);
		log.setRecipientRefNo(recipientRefNo);
		log.setRecipientBranch(recipientBranch);
		log.setRecipientTckn(recipientTckn);
		log.setRecipientPhoneNumber(recipientPhoneNumber);
		log.setRecipientVkn(recipientVkn);
		if (accountNo != null && StringUtils.isNotBlank(accountNo.trim()))
			log.setAccountNo(new BigDecimal(accountNo));
		log.setExplanation(explanation);
		log.setOrderStatus(orderStatus);
		log.setOrderType(orderType);
		log.setMainTxNo(mainTxNo);
		if (commissionAccountNo != null && StringUtils.isNotBlank(commissionAccountNo.trim()))
			log.setCommissionAccountNo(new BigDecimal(commissionAccountNo));
		log.setCommissionAmount(commissionAmount);
		log.setCustomerName(customerName);
		if (customerNo != null && StringUtils.isNotBlank(customerNo.trim()))
			log.setCustomerNo(new BigDecimal(customerNo));
		log.setCurrencyCode(currencyCode);
		log.setTransferType(transferType);
		log.setAmount(amount);
		log.setTaxOffice(taxOffice);
		log.setOrderDate(orderDate);
		log.setPaymentAccountNo(paymentAccountNo);
		log.setPaymentCommissionAccountNo(paymentCommissionAccountNo);
		log.setLineNumber(lineNumber);
				
		hibernateSession.save(log);		
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_TRN7210_AFTER_APPROVAL")
	public static GMMap trn7210AfterApproval(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal txNo = input.getBigDecimal(TransactionConstants.OrderTransfersApproved.Input.TX_NO);
			String username = CommonHelper.getCurrentUser();
						
			OrderTransaction orderTransaction = (OrderTransaction) hibernateSession.createCriteria(OrderTransaction.class)
																	.add(Restrictions.eq("status", true))
																	.add(Restrictions.eq("txNo", txNo)).uniqueResult();
			if (orderTransaction != null) {
				orderTransaction.setTransactionStatus(DatabaseConstants.TransactionStatus.APPROVED);	
				hibernateSession.update(orderTransaction);		
				
				List<OrderTransferLog> approvedTransferLogList =  hibernateSession.createCriteria(OrderTransferLog.class)
																   .add(Restrictions.eq("status", true))
																   .add(Restrictions.eq("mainTxNo", orderTransaction.getTxNo()))
																   .add(Restrictions.eq("orderStatus", DatabaseConstants.OrderStatuses.WaitingApproval)).list();
				for (OrderTransferLog transferLog : approvedTransferLogList) {
					transferLog.setOrderStatus(DatabaseConstants.OrderStatuses.Approved);
					hibernateSession.update(transferLog);
					
					OrderMain order = (OrderMain) hibernateSession.createCriteria(OrderMain.class)
													.add(Restrictions.eq("oid", transferLog.getOrderMainOid())).uniqueResult();
					if (order != null) {
						order.setOrderStatus(DatabaseConstants.OrderStatuses.Approved);
						order.setTransactionApproveUser(username);
						hibernateSession.update(order);
					}
				}
				
			}			
			hibernateSession.flush();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@GraymoundService("COS_TRN7210_AFTER_CANCELATION")
	public static GMMap trn7210AfterCancelation(GMMap input) {
		GMMap output = new GMMap();
		try {
			GMServiceExecuter.executeAsync(TransactionConstants.OrderTransfersCancelled.SERVICE_NAME, input);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}	
	
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_ORDER_TRANSFERS_CANCELLED")
	public static GMMap orderTransfersCancelled(GMMap input) {
		GMMap output = new GMMap();
		try {
			Session hibernateSession = CommonHelper.getHibernateSession();
			BigDecimal mainTxNo = input.getBigDecimal(TransactionConstants.OrderTransfersCancelled.Input.TX_NO);
			OrderMain order = null;
			OrderTransaction orderTr = null;
			
			orderTr = (OrderTransaction) hibernateSession.createCriteria(OrderTransaction.class)
										.add(Restrictions.eq("status", true))
										.add(Restrictions.eq("txNo", mainTxNo)).uniqueResult();
			if (orderTr != null) {
				orderTr.setStatus(false);
				hibernateSession.update(orderTr);						
			}
			
			List<OrderTransferLog> orderLogList = hibernateSession.createCriteria(OrderTransferLog.class)
												  .add(Restrictions.eq("status", true))
												  .add(Restrictions.eq("mainTxNo", mainTxNo)).list();
			for (OrderTransferLog orderLog : orderLogList) {
				orderLog.setStatus(false);
				hibernateSession.update(orderLog);
				
				order = (OrderMain) hibernateSession.createCriteria(OrderMain.class)
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("oid", orderLog.getOrderMainOid())).uniqueResult();
				if (order != null) {
					order.setOrderStatus(DatabaseConstants.OrderStatuses.Waiting);
					order.setMainTxNo(null);
					hibernateSession.update(order);					
				}
			}			
			hibernateSession.flush();		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return output;
	}
	
	 @SuppressWarnings("unchecked")
	 @GraymoundService("COS_GET_ORDER_FILE_FOR_VIEW_INIT")
	 public static GMMap getOrderFileForViewInit (GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String tableName = TransactionConstants.GetOrderFiles.tableName;
			FtmProcess ftmProcess = null;
			String path = null, ftmFileName = null, query = null, loadingStatus = null, fileStatus = null, statusText = null, loadingTime = null;
			String corporateShortName = null;
			Date loadingDate = null, orderDate = null;
			
			BigDecimal trxNo = input.getBigDecimal(TransactionConstants.GetOrderFiles.Input.TRX_NO);	
			
			OrderTransaction orderTransaction = (OrderTransaction) hibernateSession.createCriteria(OrderTransaction.class)
																   .add(Restrictions.eq("txNo", trxNo)).uniqueResult();
			if (orderTransaction != null) {
				String batchSubmitId = orderTransaction.getBatchSubmitId();
				
				List<OrderFileLog> incomingFiles = hibernateSession.createCriteria(OrderFileLog.class)
													.add(Restrictions.eq("status", true))
													.add(Restrictions.eq("batchSubmitId", batchSubmitId))
													.add(Restrictions.eq("transferStatus", DatabaseConstants.TransferStatuses.SUBMITTED))
													.add(Restrictions.eq("transferType",  new Short(DatabaseConstants.TransferTypes.OrderLoading))).list();
				
				int count = 0;
				for (OrderFileLog incomingFile : incomingFiles) {
					
					Criteria ftmProcessCriteria = hibernateSession.createCriteria(FtmProcess.class)
													.add(Restrictions.eq("ftmFileDefinitionOid", new BigDecimal(incomingFile.getFtmId())))
													.add(Restrictions.eq("oid", incomingFile.getFtmSequenceNumber()));
					ftmProcess = (FtmProcess) ftmProcessCriteria.uniqueResult(); 
					if (ftmProcess != null)
						ftmFileName = ftmProcess.getFileName();
					
					GMMap getCorpDefinitionMap = new GMMap();
					getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, incomingFile.getCorporateCode());
					GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
					corporateShortName = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.SHORT_NAME);
					
					loadingStatus = incomingFile.getLoadingStatus();
					fileStatus = incomingFile.getFileStatus();
				
					if (!StringUtils.isBlank(loadingStatus) && !loadingStatus.equals(DatabaseConstants.LoadingStatuses.SUCESSFUL)) {
						query = QueryRepository.OrderTransferServicesRepository.COS_LOADING_STATUS_PARAM_TEXT_QUERY;
						statusText = DALUtil.getResult(String.format(query, loadingStatus));
					} else if (!StringUtils.isBlank(fileStatus)){
						query = QueryRepository.OrderTransferServicesRepository.COS_FILE_STATUS_PARAM_TEXT_QUERY;
						statusText = DALUtil.getResult(String.format(query, fileStatus));
					}

					loadingDate = dateFormat.parse(CommonHelper.longTimeStringToViewDateString(incomingFile.getLogDate()));
					loadingTime = CommonHelper.longTimeStringToViewTimeString(incomingFile.getLogDate());
					
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.PATH, path);
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.FILE_NAME, ftmFileName);
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.LOADING_DATE, loadingDate);
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.LOADING_TIME, loadingTime.replace(":",""));
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.BATCH_SUBMIT_ID, incomingFile.getBatchSubmitId());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.FTM_SEQUENCE_NUMBER, incomingFile.getFtmSequenceNumber());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.FILE_TRANSFER_LOG_OID, incomingFile.getOid());	
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.LOADING_STATUS, loadingStatus);
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.FILE_STATUS, fileStatus);
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.STATUS, statusText);					
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.TOTAL_LINE_COUNT, incomingFile.getTotalLineCount());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.ERRONEOUS_LINE_COUNT, incomingFile.getErroneousLineCount());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.TRY_AMOUNT, incomingFile.getTryAmount());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.USD_AMOUNT, incomingFile.getUsdAmount());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.EUR_AMOUNT, incomingFile.getEurAmount());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.TRY_LINE_COUNT, incomingFile.getTryLineCount());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.USD_LINE_COUNT, incomingFile.getUsdLineCount());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.EUR_LINE_COUNT, incomingFile.getEurLineCount());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.ERROR_CODE, incomingFile.getErrorCode());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.ERROR_DESC, incomingFile.getErrorDesc());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.CORPORATE_CODE, incomingFile.getCorporateCode());
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.CORPORATE_SHORT_NAME, corporateShortName);
					if (incomingFile.getOrderDate() != null) {
						orderDate = dateFormat.parse(CommonHelper.shortTimeStringToViewDateString(incomingFile.getOrderDate()));
						output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.ORDER_DATE, orderDate);
					}	
					count++;
				}
			}

			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }
	 
	 @SuppressWarnings("unchecked")
	 @GraymoundService("COS_GET_ORDER_FILE_CONTENT_FOR_VIEW_INIT")
	 public static GMMap getOrderFileContentForViewInit (GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String tableName = TransactionConstants.GetOrderFileContent.tableName;
			String query = null, orderType = null, orderStatus = null, transferTime = null, amountOrder = null, corporateCode = null;
			Date transferDate = null;
			
			BigDecimal trxNo = input.getBigDecimal(TransactionConstants.GetOrderFiles.Input.TRX_NO);	
			
			OrderTransaction orderTransaction = (OrderTransaction) hibernateSession.createCriteria(OrderTransaction.class)
								   									.add(Restrictions.eq("txNo", trxNo)).uniqueResult();
			if (orderTransaction != null) {
				corporateCode = orderTransaction.getCorporateCode();
			}
			
			if (!StringUtils.isBlank(corporateCode)) {
				GMMap getCorpDefinitionMap = new GMMap();
				getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
				GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
				amountOrder = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING);				
			}
			
			Criteria criteria = hibernateSession.createCriteria(OrderMain.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("mainTxNo", trxNo))
								.add(Restrictions.eq("orderStatus", DatabaseConstants.OrderStatuses.WaitingApproval));
			
			if (StringUtils.isNotBlank(amountOrder)) {				
				if (amountOrder.equals("D"))
					criteria = criteria.addOrder(Order.desc("amount"));
				else if (amountOrder.equals("A"))
					criteria = criteria.addOrder(Order.asc("amount"));
			} else 
				criteria = criteria.addOrder(Order.asc("lineNumber"));
			
			List<OrderMain> orderList = criteria.list();
			
			int count = 0;
			for (OrderMain order : orderList) {
				query = QueryRepository.OrderTransferServicesRepository.COS_ORDER_STATUS_PARAM_TEXT_QUERY;
				orderStatus = DALUtil.getResult(String.format(query, order.getOrderStatus()));
				query = QueryRepository.OrderTransferServicesRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
				orderType = DALUtil.getResult(String.format(query, order.getOrderType()));
				
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT, true); 				
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_NAME, order.getRecipientName()); 
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_ADDRESS, order.getRecipientAddress());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_MOTHER_NAME, order.getRecipientMotherName());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_FATHER_NAME, order.getRecipientFatherName());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_BANK, order.getRecipientBank());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_DATE_OF_BIRTH, order.getRecipientDateOfBirth());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_EMAIL, order.getRecipientEmail());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_ACCOUNT_NO, order.getRecipientAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_IBAN, order.getRecipientIban());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_CC_NO, order.getRecipientCcNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_REF_NO, order.getRecipientRefNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_BRANCH, order.getRecipientBranch());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_TCKN, order.getRecipientTckn());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_PHONE_NUMBER, order.getRecipientPhoneNumber());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_VKN, order.getRecipientVkn());				
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ACCOUNT_NO, order.getAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ERROR_DESCRIPTION, order.getErrorDesc());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.EXPLANATION, order.getExplanation());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS, orderStatus);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE, order.getOrderStatus());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_TYPE, orderType);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TX_NO, order.getTxNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.COMMISSION_ACCOUNT_NO, order.getCommissionAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.COMMISSION_AMOUNT, order.getCommissionAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.CURRENCY_CODE, order.getCurrencyCode());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_AMOUNT, order.getTransferAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_TYPE, order.getTransferType());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.AMOUNT, order.getAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TAX_OFFICE, order.getTaxOffice());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.MAIN_OID, order.getOid());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.EFT_SORGU_NO, order.getEftSorguNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.FIS_NO, order.getFisNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.PAYMENT_ACCOUNT_NO, order.getPaymentAccountNo());
				if (order.getTransferDate() != null) {
					transferDate = dateFormat.parse(CommonHelper.longTimeStringToViewDateString(order.getTransferDate()));
					transferTime = CommonHelper.longTimeStringToViewTimeString(order.getTransferDate());					
					output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_DATE, transferDate);
					output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_TIME, transferTime.replace(":", ""));
				}
				count++;
			}				
			
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }
	 
	 @GraymoundService("COS_EXT_SEND_RECEIPT")
	    public static GMMap dekontMailGonder(GMMap iMap){
	    	GMMap oMap = new GMMap();
	    	try {
	    		Object[] inputValues = new Object[4];
				inputValues[0] = BnsprType.STRING;
				inputValues[1] = iMap.getString("EPOSTA");
				Object[] outputValues = new Object[0];
				String proc = "{ call pkg_trn10011.e_mail_check(?) }";
				DALUtil.callOracleProcedure(proc, inputValues, outputValues);
				oMap.putAll(GMServiceExecuter.execute("BNSPR_MAIL_ICIN_DEKONT_OLUSTUR", iMap));
				GMMap servisMap = new GMMap();
				servisMap.put("FROM", "Aktifbank@aktifbank.com.tr");
				servisMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(iMap.getString("EPOSTA")));
				servisMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				servisMap.put("SUBJECT", iMap.getString("MAIL_SUBJECT"));
				servisMap.put("MESSAGE_BODY", "Say�n <b>"+iMap.getString("MUSTERI_ADI")+"</b><br>��lem dekontunuza ekte ula�abilirsiniz.<br> Sayg�lar�m�zla<br><b>Aktif Bank</b>");
				servisMap.put("IS_BODY_HTML", true);
				servisMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
				servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", oMap.getString("FILENAME"));
				servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", FileUtil.readFileToByteArray(new File(oMap.getString("FILENAMEPATH"))));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap));
				oMap.put("MESSAGE", "Mail ba�ar�l� �ekilde g�nderilmi�tir.");
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
	    	return oMap;
	    }
}