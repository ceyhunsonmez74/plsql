package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.dao.CorporationDef;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.aktifbank.bnspr.dao.OrderMain;

import com.graymound.util.GMMap;

public class InsertExtOrderMainHandler extends RequestHandler {
	
	public InsertExtOrderMainHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String spName = input.getString("SPName");
        String paymentAccountId = input.getString("AccountFrom", 0, "AccountID");        
        String batchSubmitId = CorporationServiceUtil.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
        String orderDateStr = CommonHelper.getShortDateTimeString(new Date());
        CorporationDef corpDef = (CorporationDef) super.getHibernateSession().createCriteria(CorporationDef.class)        											
												       .add(Restrictions.eq("status", true))
												       .add(Restrictions.eq("shortName", spName))
												       .uniqueResult();
        
        if(corpDef != null){
	        OrderFileLog orderFileLog = new OrderFileLog();
        	orderFileLog.setCustomerAccountNo(paymentAccountId);
        	orderFileLog.setCustomerNo(corpDef.getCustomerNo());
        	orderFileLog.setCorporateCode(corpDef.getCorporateCode());
        	orderFileLog.setBatchSubmitId(batchSubmitId);
        	orderFileLog.setFtmId("0");
        	orderFileLog.setFtmSequenceNumber(BigDecimal.ZERO);
        	orderFileLog.setLogDate(CommonHelper.getLongDateTimeString(new Date()));
        	orderFileLog.setOrderDate(orderDateStr);
        	orderFileLog.setTransferStatus(DatabaseConstants.TransferStatuses.SUBMITTED);
        	orderFileLog.setTransferType(new Short(DatabaseConstants.TransferTypes.OrderLoading));
        	orderFileLog.setStatus(true);
        	
	        for(int i = 0; i < input.getSize("AccountTo"); i++){        	
		        OrderMain orderMain = new OrderMain();
		        orderMain.setAccountNo(paymentAccountId);
		        orderMain.setAmount(input.getBigDecimal("TrfInfo", i, "Amount"));
		        orderMain.setBatchSubmitId(batchSubmitId);
		        orderMain.setFtmSequenceNumber(BigDecimal.ZERO);
		        orderMain.setCustomerNo(corpDef.getCustomerNo().toString());
		        orderMain.setCustomerName(corpDef.getCorporateName());
		        orderMain.setCurrencyCode(input.getString("TrfInfo", i, "CurrCode"));        
		        orderMain.setCorporateCode(corpDef.getCorporateCode());
		        orderMain.setExplanation(input.getString("TrfInfo", i, "TrfExplanation"));
		        orderMain.setOrderDate(orderDateStr);
		        orderMain.setLoadingUser(CommonHelper.getCurrentUser());
		        orderMain.setLoadingDate(CommonHelper.getLongDateTimeString(new Date()));
		        orderMain.setLineNumber(new BigDecimal(i+1));
		        
		        orderMain.setRecipientAccountNo(input.getString("AccountTo", i, "AccountID"));
		        orderMain.setRecipientAddress(input.getString("AccountTo", i, "Addres"));
		        if(!StringUtils.isEmpty(input.getString("AccountTo", i, "BankID")))
		        	orderMain.setRecipientBank(StringUtils.stripStart(input.getString("AccountTo", i, "BankID"), "0"));
		        orderMain.setRecipientBranch(input.getString("AccountTo", i, "BranchID"));
		        orderMain.setRecipientDateOfBirth(input.getString("AccountTo", i, "BirthDate"));
		        orderMain.setRecipientEmail(input.getString("AccountTo", i, "Email"));
		        orderMain.setRecipientFatherName(input.getString("AccountTo", i, "FatherName"));
		        orderMain.setRecipientIban(input.getString("AccountTo", i, "IBAN"));
		        orderMain.setRecipientName(input.getString("AccountTo", i, "Name"));
		        orderMain.setRecipientPhoneNumber(input.getString("AccountTo", i, "TelNum"));
		        orderMain.setRecipientTckn(input.getString("AccountTo", i, "Mernis"));
		        orderMain.setRecipientVkn(input.getString("AccountTo", i, "Tax_Num"));
		        orderMain.setStatus(true);        
		       
		        super.getHibernateSession().save(orderMain);
		        output.put("MAIN_OID", orderMain.getOid());
		        
	        }
	        super.getHibernateSession().save(orderFileLog);
	        super.getHibernateSession().flush();
        	
	        output.put(TransactionConstants.OrderLoadingControls.Input.HEADER_ORDER_DATE, orderDateStr);
	        output.put(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID, batchSubmitId);
	        output.put(TransactionConstants.GeneralBatchSubmit.Input.ORDER_FILE_LOG_OID, orderFileLog.getOid());
	        output.put(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE, corpDef.getCorporateCode());
        }               
    }
}
