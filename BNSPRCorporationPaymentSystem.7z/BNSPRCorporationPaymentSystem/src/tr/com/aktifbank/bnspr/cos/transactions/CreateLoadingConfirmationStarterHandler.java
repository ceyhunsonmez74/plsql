package tr.com.aktifbank.bnspr.cos.transactions;

import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;

import com.graymound.util.GMMap;

public class CreateLoadingConfirmationStarterHandler extends RequestHandler {

	public CreateLoadingConfirmationStarterHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		CommonBusinessOperations.executeBatchStarterHandler(input, output, DatabaseConstants.TransferTypes.LoadingConfirmation, super.getHibernateSession());
	}

}
