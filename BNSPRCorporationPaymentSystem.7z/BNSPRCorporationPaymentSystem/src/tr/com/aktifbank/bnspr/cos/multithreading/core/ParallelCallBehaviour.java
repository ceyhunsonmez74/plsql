package tr.com.aktifbank.bnspr.cos.multithreading.core;

import java.util.List;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.cos.dto.ParallelCallResult;

public interface ParallelCallBehaviour {
	void call(List<GMMap> tasks);
	ParallelCallResult getResult();
}
