package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.MapKeys;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cos.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cos.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.dao.FileErrorLog;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public class OrderLineParserHandler extends ParallelRequestHandler {	
	
	private static final int SUCCESSFUL_INSERT = 0;
	
	public OrderLineParserHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.OrderLineParser.Input.CORPORATE_CODE);
		BigDecimal ftmTransferId = input.getBigDecimal(TransactionConstants.OrderLineParser.Input.FTM_TRANSFER_ID);
		String ftmId = input.getString(TransactionConstants.OrderLineParser.Input.FTM_ID);
		String batchSubmitId = input.getString(TransactionConstants.OrderLineParser.Input.BATCH_SUBMIT_ID);
		int startLineNumber = input.getInt(TransactionConstants.OrderLineParser.Input.START_LINE_NUMBER);
		int endLineNumber = input.getInt(TransactionConstants.OrderLineParser.Input.END_LINE_NUMBER);
		GMMap databaseFieldMaps = input.getMap(TransactionConstants.OrderLineParser.Input.DATABASE_FIELD_MAPS);
		GMMap serviceFieldMaps = input.getMap(TransactionConstants.OrderLineParser.Input.SERVICE_FIELD_MAPS);
		List<FormatDetail> headerFormatDetails = (List<FormatDetail>)input.get(TransactionConstants.OrderLineParser.Input.HEADER_FORMAT_DETAILS);
		List<FormatDetail> detailFormatDetails = (List<FormatDetail>)input.get(TransactionConstants.OrderLineParser.Input.DETAIL_FORMAT_DETAILS);
		List<FormatDetail> footerFormatDetails = (List<FormatDetail>)input.get(TransactionConstants.OrderLineParser.Input.FOOTER_FORMAT_DETAILS);
		Boolean lastFieldHasDynamicLength = input.getBoolean(TransactionConstants.OrderLineParser.Input.LAST_FIELD_HAS_DYNAMIC_LENGTH);
		int commitCount = input.getInt(TransactionConstants.OrderLineParser.Input.COMMIT_COUNT);
		int errorThreshold = input.getInt(TransactionConstants.OrderLineParser.Input.ERROR_THRESHOLD);
		String serviceName = input.getString(TransactionConstants.OrderLineParser.Input.SERVICE_NAME);
		int controlLoopCount = input.getInt(TransactionConstants.OrderLineParser.Input.CONTROL_LOOP_COUNT);
		int controlCounter = 1;
		Date headerOrderDate = null;
		boolean headerCustomerAccountNoControl = false, headerOrderDateControl = false, headerCustomerBankControl = false, headerCustomerBranchControl = false, headerCustomerNoControl = false;    
		String headerCustomerAccountNo = null, headerOrderDateString = null, headerCustomerBank = null, headerCustomerBranch = null, headerCustomerNo = null;
		boolean footerTRYAmountControl = false, footerUSDAmountControl = false, footerEURAmountControl = false;
		boolean footerTRYLineCountControl = false, footerUSDLineCountControl = false, footerEURLineCountControl = false;
		boolean isInsertStep = false;
		BigDecimal footerTotalTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		BigDecimal footerTotalUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		BigDecimal footerTotalEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		int footerTotalTRYLineCount = 0, footerTotalUSDLineCount = 0, footerTotalEURLineCount = 0;
		int processedLineCount = 0, failedLineCount = 0, processedTRYLineCount = 0, processedUSDLineCount = 0, processedEURLineCount = 0;
		boolean exceptionOccured = false;
		String exception = "";
		
		BigDecimal processedTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		BigDecimal processedUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		BigDecimal processedEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		String headerConstant = null;
		String footerConstant = null;
		String bodyConstant = null;
		if(headerFormatDetails.size() > 0){
			headerConstant = headerFormatDetails.get(0).getInitialConstant();
		}
		if(footerFormatDetails.size() > 0){
			footerConstant = footerFormatDetails.get(0).getInitialConstant();
		}
		if(detailFormatDetails.size() > 0){
			bodyConstant = detailFormatDetails.get(0).getInitialConstant();
		}		
		List<FtmFileContent> lines = getOrderLines(ftmTransferId, startLineNumber, endLineNumber);		
		List<GMMap> serviceMaps = new ArrayList<GMMap>();
		
		GMMap getCorpDefinitionMap = new GMMap();
		getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corpDefDetailsMap = super.callGraymoundServiceInSession(TransactionConstants.GetOrderCorpDef.SERVICE_NAME, getCorpDefinitionMap);
		BigDecimal customerNo = corpDefDetailsMap.getBigDecimal(TransactionConstants.GetOrderCorpDef.Output.CUSTOMER_NO);
		String customerName = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.CORPORATE_NAME);
		
		for(FtmFileContent content : lines){
			try {
				String currencyCode = null;
				BigDecimal amount = null;
				
				if(controlCounter++ % controlLoopCount == 0){
					failedLineCount = getFailedLineCount(batchSubmitId, ftmId, ftmTransferId);
					if(failedLineCount >= errorThreshold){
						exceptionOccured = true;
						break;
					}
				}
				Boolean footerLine = false;
				if(!StringUtil.isEmpty(footerConstant)){
					footerLine = content.getLine().startsWith(footerConstant);
				}
				Boolean headerLine = false;
				if(!StringUtil.isEmpty(headerConstant)){
					headerLine = content.getLine().startsWith(headerConstant);
				}
				Boolean bodyLine = false;
				if(!StringUtil.isEmpty(bodyConstant)){
					bodyLine = content.getLine().startsWith(bodyConstant);
				}
				
				if(!headerLine && !footerLine && !bodyLine){
					continue;
				}
				
				if (headerLine) {
					List<FormatDetail> formatDetails = headerFormatDetails;
					for (FormatDetail detail : formatDetails) {
						int startIndex = detail.getStartIndis().intValue();
						int length = detail.getLength().intValue();
						String currentLine = content.getLine().substring(startIndex - 1, startIndex - 1 + length);						
						String fieldType = detail.getDataType();
						String format = detail.getDataPattern();
						String constant = detail.getConstant();
						ItemDatabaseField databaseFieldInformation = (ItemDatabaseField) databaseFieldMaps.get(detail.getDatasourceReference());
						Object parsedData;
						try {
							parsedData = getObject(currentLine, fieldType, format, constant);
						}
						catch (BatchComponentException e) {
							throw e;
						}
						catch (Exception e) {
							logger.error(String.format("An exception occured while parsing data from %s, with format code %s, start index %s, length %s, type %s, constant %s",
									currentLine, format, startIndex, length, fieldType, constant));
							logger.error(System.currentTimeMillis(), e);
							throw new Exception(String.format("Sat�rdaki %s alan�ndan veriyi parse ederken bir hata olu�tu. Format kodu %s, ba�lang�� index'i: %s, " +
									"uzunlu�u %s, tipi %s, sabiti %s, hata : %s",
									currentLine, format, startIndex, length, fieldType, constant, CommonHelper.getStringifiedException(e)));
						}
						
						if(!fieldType.equals(DatabaseConstants.FieldType.Constant)){
							if(databaseFieldInformation.getDbField().equals(DatabaseConstants.HeaderIndicators.ORDER_DATE)){
								headerOrderDateControl = true;
								headerOrderDate = (Date) parsedData;
								if (parsedData instanceof Date)
									headerOrderDateString = CommonHelper.getShortDateTimeString(headerOrderDate);
							}
							else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.HeaderIndicators.CUSTOMER_NO)){	
								headerCustomerNoControl = true;
								headerCustomerNo = (String) parsedData;
							}
							else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.HeaderIndicators.CUSTOMER_BANK)){	
								headerCustomerBankControl = true;
								headerCustomerBank = (String) parsedData;
							}
							else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.HeaderIndicators.CUSTOMER_BRANCH)){
								headerCustomerBranchControl = true;
								headerCustomerBranch = (String) parsedData;
							}
							else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.HeaderIndicators.CUSTOMER_ACCOUNT_NO)){	
								headerCustomerAccountNoControl = true;
								headerCustomerAccountNo = (String) parsedData;
							}
						}						
					}
					
				} else {
					List<FormatDetail> formatDetails = bodyLine ? detailFormatDetails : footerFormatDetails;
					int numberOfDetails = formatDetails.size();
					GMMap serviceMap = new GMMap();
					int currentDetailNum = 1;
					for (FormatDetail detail : formatDetails) {
						int startIndex = detail.getStartIndis().intValue();
						int length = detail.getLength().intValue();
						String currentLine = null;
						if (bodyLine && currentDetailNum == numberOfDetails && lastFieldHasDynamicLength != null && lastFieldHasDynamicLength) {
							int fullLineLength = content.getLine().length();
							int lastFieldLength = fullLineLength - startIndex + 1;
							currentLine = content.getLine().substring(startIndex - 1, startIndex - 1 + lastFieldLength);	
						}
						else
							currentLine = content.getLine().substring(startIndex - 1, startIndex - 1 + length);						
						
						String fieldType = detail.getDataType();
						String format = detail.getDataPattern();
						String constant = detail.getConstant();
						String source = detail.getDatasourceType();
						if(detail.getTrimEmptyCharacters() != null && detail.getTrimEmptyCharacters()){
							currentLine = currentLine.trim();
						}
						ItemDatabaseField databaseFieldInformation = (ItemDatabaseField) databaseFieldMaps.get(detail.getDatasourceReference());
						Object parsedData;
						try {
							parsedData = getObject(currentLine, fieldType, format, constant);
						}
						catch (BatchComponentException e) {
							throw e;
						}
						catch (Exception e) {
							logger.error(String.format("An exception occured while parsing data from %s, with format code %s, start index %s, length %s, type %s, constant %s",
									currentLine, format, startIndex, length, fieldType, constant));
							logger.error(System.currentTimeMillis(), e);
							throw new Exception(String.format("Sat�rdaki %s alan�ndan veriyi parse ederken bir hata olu�tu. Format kodu %s, ba�lang�� index'i: %s, " +
									"uzunlu�u %s, tipi %s, sabiti %s, hata : %s",
									currentLine, format, startIndex, length, fieldType, constant, CommonHelper.getStringifiedException(e)));
						}
						
						if(source.equals(DatabaseConstants.DataSourceTypes.DatabaseAndService)){
							parsedData = this.callServiceWithData(parsedData, (ItemServiceField)serviceFieldMaps.get(detail.getDatasourceReference2()), input);
						}
						
						if (bodyLine) {														
							if(!fieldType.equals(DatabaseConstants.FieldType.Constant)){
								if(databaseFieldInformation.getDbField().equals(DatabaseConstants.DetailIndicators.CURRENCY_CODE)){
									currencyCode = (String) parsedData;
								}
								else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.DetailIndicators.AMOUNT)){								
									//amount = (BigDecimal) parsedData;
									amount = new BigDecimal(parsedData.toString());
								}
								else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.DetailIndicators.TRANSFER_TYPE)){								
									String transferType = (String) parsedData;
									if (transferType.length() == 1)
										parsedData = "0".concat(transferType);
								}
							}
							
							setDataToField(serviceMap, databaseFieldInformation, parsedData);
						}
						else{
							if(!fieldType.equals(DatabaseConstants.FieldType.Constant)){
								if(databaseFieldInformation.getDbField().equals(DatabaseConstants.FooterIndicators.TOTAL_TRY_AMOUNT)){
									footerTRYAmountControl = true;
									footerTotalTRYAmount = new BigDecimal(((Number)parsedData).doubleValue()).setScale(2, RoundingMode.HALF_UP);
								}
								else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.FooterIndicators.TOTAL_USD_AMOUNT)){
									footerUSDAmountControl = true;
									footerTotalUSDAmount = new BigDecimal(((Number)parsedData).doubleValue()).setScale(2, RoundingMode.HALF_UP);
								}
								else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.FooterIndicators.TOTAL_EUR_AMOUNT)){
									footerEURAmountControl = true;
									footerTotalEURAmount = new BigDecimal(((Number)parsedData).doubleValue()).setScale(2, RoundingMode.HALF_UP);
								}
								else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.FooterIndicators.TOTAL_TRY_RECORD_COUNT)){
									footerTRYLineCountControl = true;
									footerTotalTRYLineCount = ((Number)parsedData).intValue();
								}
								else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.FooterIndicators.TOTAL_USD_RECORD_COUNT)){
									footerUSDLineCountControl = true;
									footerTotalUSDLineCount = ((Number)parsedData).intValue();
								}
								else if(databaseFieldInformation.getDbField().equals(DatabaseConstants.FooterIndicators.TOTAL_EUR_RECORD_COUNT)){
									footerEURLineCountControl = true;
									footerTotalEURLineCount = ((Number)parsedData).intValue();
								}								
								else{
									// TODO
								}
							}
						}
						currentDetailNum++;
					}					
					if (bodyLine && !exceptionOccured) {
						serviceMap.put("LINE_NUMBER", (Object)content.getLineNumber());
						if(!StringUtil.isEmpty(headerOrderDateString)){
							serviceMap.put("ORDER_DATE", (Object)headerOrderDateString);
						}
						
						if (currencyCode != null && amount != null) { 
							if (currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
								processedTRYAmount = processedTRYAmount.add(amount);
								processedTRYLineCount++;
							}
							else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.USD)) {
								processedUSDAmount = processedUSDAmount.add(amount);
								processedUSDLineCount++;
							}
							else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR)) {
								processedEURAmount = processedEURAmount.add(amount);
								processedEURLineCount++;
							}
						}
						
						serviceMaps.add(serviceMap);
					}
					if (bodyLine && !exceptionOccured && serviceMaps.size() % commitCount == 0) {
						try {
							isInsertStep = true;
							GMMap insertInvoicesRequest = new GMMap();
							insertInvoicesRequest.put(TransactionConstants.CORPORATE_CODE_GENERAL_KEY, corporateCode);
							insertInvoicesRequest.put(TransactionConstants.CUSTOMER_NO_GENERAL_KEY, customerNo);
							insertInvoicesRequest.put(TransactionConstants.CUSTOMER_NAME_GENERAL_KEY, customerName);
							insertInvoicesRequest.put(TransactionConstants.DIRECT_INSERT_GENERAL_KEY, true);
							insertInvoicesRequest.put(TransactionConstants.FTM_TRANSFER_ID_GENERAL_KEY, ftmTransferId);
							insertInvoicesRequest.put(TransactionConstants.SUBMIT_ID__GENERAL_KEY, batchSubmitId);
							int submitMapCounter = 0;
							for (GMMap submitMap : serviceMaps) {
								insertInvoicesRequest.put(TransactionConstants.INSERT_PAIR_TABLE_GENERAL_KEY, submitMapCounter++,
										TransactionConstants.INSERT_KEYVALUE_PAIRS_GENERAL_KEY, submitMap);
							}
							GMMap insertInvoiceOutput = super.callGraymoundServiceOutsideSession(serviceName, insertInvoicesRequest);
							if(insertInvoiceOutput.getInt(TransactionConstants.RETURN_CODE_GENERAL_KEY) == SUCCESSFUL_INSERT){
								isInsertStep = false;
							}
							else{
								throw new Exception(insertInvoiceOutput.getString(TransactionConstants.RETURN_MESSAGE_GENERAL_KEY));
							}
						} catch (Exception e) {
							logger.error("An exception occured while inserting order main records");
							logger.error(System.currentTimeMillis(), e);
							throw new Exception(String.format("�deme talimat� kay�tlar� veritaban�na eklenirken bir hata olu�tu. Hata %s, kay�t ekleme istekleri %s",
									CommonHelper.getStringifiedException(e), getStringifiedMap(serviceMaps)));
						}
						finally{
							serviceMaps.clear();
						}
					}
				}
				if (bodyLine) {
					processedLineCount++;
				}
			} catch (Exception e) {
				exceptionOccured = true;
				if(isInsertStep){
					exception = CommonHelper.getStringifiedException(e);
					insertFileErrorLog(batchSubmitId, ftmId, ftmTransferId, new BigDecimal(-1), "", "0", CommonHelper.getStringifiedException(e));
					break;
				}
				else{
					logger.error(String.format("An exception occured while parsing line : %s", content.getLine()));
					logger.error(System.currentTimeMillis(), e);
					insertFileErrorLog(batchSubmitId, ftmId, ftmTransferId, content.getLineNumber(), content.getLine(), "0", CommonHelper.getStringifiedException(e));
					failedLineCount = getFailedLineCount(batchSubmitId, ftmId, ftmTransferId);
					if(failedLineCount >= errorThreshold){
						exception = CommonHelper.getStringifiedException(e);
						break;
					}
				}
			}
		}
			
		if(!exceptionOccured && serviceMaps.size() > 0){
			try {
				GMMap insertInvoicesRequest = new GMMap();
				insertInvoicesRequest.put(TransactionConstants.CORPORATE_CODE_GENERAL_KEY, corporateCode);
				insertInvoicesRequest.put(TransactionConstants.DIRECT_INSERT_GENERAL_KEY, true);
				insertInvoicesRequest.put(TransactionConstants.FTM_TRANSFER_ID_GENERAL_KEY, ftmTransferId);
				insertInvoicesRequest.put(TransactionConstants.SUBMIT_ID__GENERAL_KEY, batchSubmitId);
				int submitMapCounter = 0;
				for (GMMap submitMap : serviceMaps) {
					insertInvoicesRequest.put(TransactionConstants.INSERT_PAIR_TABLE_GENERAL_KEY, submitMapCounter++,
							TransactionConstants.INSERT_KEYVALUE_PAIRS_GENERAL_KEY, submitMap);
				}
				GMMap insertInvoiceOutput = super.callGraymoundServiceOutsideSession(serviceName, insertInvoicesRequest);
				if(insertInvoiceOutput.getInt(TransactionConstants.RETURN_CODE_GENERAL_KEY) == SUCCESSFUL_INSERT){
					
				}
				else{
					throw new Exception(insertInvoiceOutput.getString(TransactionConstants.RETURN_MESSAGE_GENERAL_KEY));
				}
			} catch (Exception e) {
				logger.error("An exception occured while inserting order main records");
				logger.error(System.currentTimeMillis(), e);
				insertFileErrorLog(batchSubmitId, ftmId, ftmTransferId, new BigDecimal(-1), "", "0", CommonHelper.getStringifiedException(e));
				exceptionOccured = true;
				exception = "�deme talimat� kay�tlar� veritaban�na eklenirken bir hata olu�tu : " + e.toString();
			}
			finally{
				serviceMaps.clear();
			}
		}
		
		if(!exceptionOccured){
			output.put(TransactionConstants.OrderLineParser.Output.ISSUCCESSFUL, true);
			if (headerCustomerBankControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BANK, headerCustomerBank);				
			}
			if (headerCustomerBranchControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BRANCH, headerCustomerBranch);				
			}
			if (headerCustomerNoControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_NO, headerCustomerNo);				
			}
			if (headerOrderDateControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_ORDER_DATE, headerOrderDateString);
			}
			if (headerCustomerAccountNoControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_ACCOUNT_NO, headerCustomerAccountNo);				
			}
			if(footerTRYAmountControl){
				output.put(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_AMOUNT, footerTotalTRYAmount);
			}
			if(footerTRYLineCountControl){
				output.put(TransactionConstants.OrderLineParser.Output.FOOTER_TRY_LINE_COUNT, footerTotalTRYLineCount);
			}
			if(footerUSDAmountControl){
				output.put(TransactionConstants.OrderLineParser.Output.FOOTER_USD_AMOUNT, footerTotalUSDAmount);
			}
			if(footerUSDLineCountControl){
				output.put(TransactionConstants.OrderLineParser.Output.FOOTER_USD_LINE_COUNT, footerTotalUSDLineCount);
			}
			if(footerEURAmountControl){
				output.put(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_AMOUNT, footerTotalEURAmount);
			}
			if(footerEURLineCountControl){
				output.put(TransactionConstants.OrderLineParser.Output.FOOTER_EUR_LINE_COUNT, footerTotalEURLineCount);
			}
			output.put(TransactionConstants.OrderLineParser.Output.PROCESSED_TRY_AMOUNT, processedTRYAmount);
			output.put(TransactionConstants.OrderLineParser.Output.PROCESSED_USD_AMOUNT, processedUSDAmount);
			output.put(TransactionConstants.OrderLineParser.Output.PROCESSED_EUR_AMOUNT, processedEURAmount);
			output.put(TransactionConstants.OrderLineParser.Output.PROCESSED_LINE_COUNT, processedLineCount);
			output.put(TransactionConstants.OrderLineParser.Output.PROCESSED_TRY_LINE_COUNT, processedTRYLineCount);
			output.put(TransactionConstants.OrderLineParser.Output.PROCESSED_USD_LINE_COUNT, processedUSDLineCount);
			output.put(TransactionConstants.OrderLineParser.Output.PROCESSED_EUR_LINE_COUNT, processedEURLineCount);
			output.put(TransactionConstants.OrderLineParser.Output.CUSTOMER_NO, customerNo);
			output.put(TransactionConstants.OrderLineParser.Output.CORPORATE_CODE, corporateCode);
		}
		else{
			output.put(TransactionConstants.OrderLineParser.Output.ISSUCCESSFUL, false);
			output.put(TransactionConstants.OrderLineParser.Output.PROCESSED_LINE_COUNT, processedLineCount);
			if (headerCustomerBankControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BANK, headerCustomerBank);				
			}
			if (headerCustomerBranchControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_BRANCH, headerCustomerBranch);				
			}
			if (headerCustomerNoControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_NO, headerCustomerNo);				
			}
			if (headerOrderDateControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_ORDER_DATE, headerOrderDateString);
			}
			if (headerCustomerAccountNoControl) {
				output.put(TransactionConstants.OrderLineParser.Output.HEADER_CUSTOMER_ACCOUNT_NO, headerCustomerAccountNo);				
			}
			if(failedLineCount == errorThreshold){
				output.put(TransactionConstants.OrderLineParser.Output.ERROR_CODE, "0");
				output.put(TransactionConstants.OrderLineParser.Output.ERROR_MESSAGE, "Error threshold exceeded");
			}
			else{
				output.put(TransactionConstants.OrderLineParser.Output.ERROR_CODE, "0");
				output.put(TransactionConstants.OrderLineParser.Output.ERROR_MESSAGE, exception);
			}
		}
	}
	
	private Object callServiceWithData(Object parsedData,
			ItemServiceField itemServiceField, GMMap input) {
		GMMap serviceMap = new GMMap();
		serviceMap.put("CURRENT_ROW", input);
		serviceMap.put("PARAMETER", parsedData);
		return super.callGraymoundServiceOutsideSession(itemServiceField.getServiceName(), serviceMap).get(MapKeys.FTS_OUTPUT_DATA);
	}

	private Object getStringifiedMap(List<GMMap> serviceMaps) {
		StringBuilder builder = new StringBuilder();
		
		for (GMMap map : serviceMaps) {
			builder.append(map.toString());
		}
		
		return builder.toString();
	}

	private int getFailedLineCount(String batchSubmitId, String ftmId,
			BigDecimal ftmTransferId) {
		return ((Number)super.getHibernateSession()
				.createCriteria(FileErrorLog.class)
				.add(Restrictions.eq("batchSubmitId", batchSubmitId))
				.add(Restrictions.eq("ftmId", ftmId))
				.add(Restrictions.eq("ftmSequenceNumber", ftmTransferId))
				.setProjection(Projections.rowCount())
				.uniqueResult()).intValue();
	}

	private void insertFileErrorLog(String batchSubmitId, String ftmId,
			BigDecimal ftmTransferId, BigDecimal lineNumber, String line,
			String errorCode,
			String errorMessage) {
		super.callServiceWithSessionAndAsyncOptions(TransactionConstants.InsertFileErrorLog.SERVICE_NAME, false, true,
				TransactionConstants.InsertFileErrorLog.Input.BATCH_SUBMIT_ID, batchSubmitId,
				TransactionConstants.InsertFileErrorLog.Input.ERROR_CODE, errorCode,
				TransactionConstants.InsertFileErrorLog.Input.ERROR_MESSAGE, errorMessage,
				TransactionConstants.InsertFileErrorLog.Input.FTM_ID, ftmId,
				TransactionConstants.InsertFileErrorLog.Input.FTM_TRANSFER_ID, ftmTransferId,
				TransactionConstants.InsertFileErrorLog.Input.LINE, line,
				TransactionConstants.InsertFileErrorLog.Input.LINE_NUMBER, lineNumber);
	}

	private void setDataToField(GMMap serviceMap, ItemDatabaseField itemDatabaseField, Object parsedData) {
		serviceMap.put(itemDatabaseField.getDbField(), parsedData);
	}
	
	private Object getObject(String content, String fieldType, String format,
			String constant) throws Exception {
		if (fieldType.equals(DatabaseConstants.FieldType.Constant)) {
			return CommonHelper.replaceCharacters(constant, "'", " ");
		} else if (fieldType.equals(DatabaseConstants.FieldType.AlphaNumeric)) {
			content = content.replaceFirst("^0*", "");
			content = content.trim();
			return CommonHelper.replaceCharacters(content, "'", " ");
		} else if (fieldType.equals(DatabaseConstants.FieldType.Amount)) {
			DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.ROOT);
			DecimalFormat decimalFormat = new DecimalFormat(format, symbols);
			Number number = decimalFormat.parse(content);
			return number;
		} else if (fieldType.equals(DatabaseConstants.FieldType.Date)
				|| fieldType.equals(DatabaseConstants.FieldType.Time)) {
			return CommonHelper.getDateTime(content, format);
		} else if (fieldType.equals(DatabaseConstants.FieldType.Numeric)) {
			return Long.valueOf(content);
		} else {
			throw new BatchComponentException(
					String.format(
							"Field type implementation for %s field type indicator is not found",
							fieldType), BusinessException.UNKNOWNFILEFORMAT);
		}
	}
	
	@SuppressWarnings("unchecked")
	private List<FtmFileContent> getOrderLines(BigDecimal ftmTransferId,
			int startLineNumber, int endLineNumber) {
		return super.getHibernateSession().createCriteria(FtmFileContent.class)
				.add(Restrictions.eq("ftmProcessOid", ftmTransferId))
				.add(Restrictions.between("lineNumber", new BigDecimal(startLineNumber), new BigDecimal(endLineNumber)))
				.list();
	}

}
