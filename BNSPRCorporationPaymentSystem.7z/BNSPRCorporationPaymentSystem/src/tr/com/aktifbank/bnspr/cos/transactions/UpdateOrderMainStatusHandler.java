package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;

import com.graymound.util.GMMap;

public class UpdateOrderMainStatusHandler extends RequestHandler {

	public UpdateOrderMainStatusHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		BigDecimal ftmSequenceNumber = input.getBigDecimal(TransactionConstants.UpdateOrderMainStatus.Input.FTM_SEQUENCE_NUMBER);
		String corporateCode = input.getString(TransactionConstants.UpdateOrderMainStatus.Input.CORPORATE_CODE);
		
		String query = String.format("UPDATE COS.ORDER_MAIN SET STATUS = 1 WHERE CORPORATE_CODE = '%s' AND FTM_SEQUENCE_NUMBER = %s AND STATUS = 0", corporateCode, ftmSequenceNumber);
		CommonHelper.getHibernateSession().createSQLQuery(query).executeUpdate();	
	}
}
