package tr.com.aktifbank.bnspr.cos.transactions;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.MapKeys;
import tr.com.aktifbank.bnspr.cos.common.ObjectMapper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cos.dto.OutgoingFileLoadingInformation;
import tr.com.aktifbank.bnspr.cos.dto.OutgoingFileStarterInformation;
import tr.com.aktifbank.bnspr.cos.multithreading.implementations.OutgoingFileByCorporateImplementation;
import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CorporateFileTransfer;
import tr.com.aktifbank.bnspr.dao.OrderFileDef;
import tr.com.aktifbank.bnspr.dao.OrderFileDetail;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public final class CommonBusinessOperations {
	
	private static final Log logger = LogFactory.getLog(CommonBusinessOperations.class);
	
	public static Boolean isCorporateActive(String corporateCode) {
		GMMap getCorporateDefinition = new GMMap();
		getCorporateDefinition.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corporateDefinitionResults = callGraymoundService(getCorporateDefinition, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
		return corporateDefinitionResults.getBoolean(TransactionConstants.GetOrderCorpDef.Output.CORPORATE_ACTIVENESS, false);
	}
	
	public static GMMap callGraymoundService(GMMap input, String serviceName, Boolean keepSession){
		if(keepSession){
			return CommonHelper.callGraymoundServiceInHibernateSession(serviceName, input);
		}
		else{
			return GMServiceExecuter.call(serviceName, input);	
		}
	}
	
	public static List<FormatDetail> getFormatDetails(String lineType, String formatId, Session hibernateSession) throws Exception{
		OrderFileDef definition = (OrderFileDef)hibernateSession.createCriteria(OrderFileDef.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("fileFormatId", formatId))
				.uniqueResult();
		if (definition != null) {
			@SuppressWarnings("unchecked")
			List<OrderFileDetail> details = hibernateSession
					.createCriteria(OrderFileDetail.class)
					.add(Restrictions.eq("fileFormatOid", definition.getOid()))
					.add(Restrictions.eq("status", true))
					.add(Restrictions.eq("lineType", lineType))
					.addOrder(Order.asc("startIndis"))
					.list();
			List<FormatDetail> domainDetails = new ArrayList<FormatDetail>();
			for (OrderFileDetail detail : details) {
				ObjectMapper<FormatDetail> mapper = new ObjectMapper<FormatDetail>(
						FormatDetail.class);
				domainDetails.add(mapper.map(detail));
			}
			return domainDetails;
		}
		else{
			throw new BatchComponentException(BusinessException.FORMATDEFINITIONNOTFOUND, formatId, getLineTypeName(lineType));
		}
	}
	
	public static String getCollectionTypeName(Short collectionType) {
		return DALUtil.getResult(String.format(QueryRepository.CosCommonBusinessOperationsRepository.COLLECTION_TYPE_NAME_QUERY, collectionType));
	}
	
	private static String getLineTypeName(String lineType) {
		if(lineType == DatabaseConstants.LineType.Detail){
			return "Detail(Detay)";
		}
		else if(lineType == DatabaseConstants.LineType.Footer){
			return "Footer(Alt Bilgi)";
		}
		else if(lineType == DatabaseConstants.LineType.Header){
			return "Header(Ba�l�k)";
		}
		else{
			return "";
		}
	}
		
	public static void executeBatchStarterHandler(GMMap input, GMMap output, short transferType, Session hibernateSession) throws Exception{
		logger.info("Starting for batch starter");
		Date processDate = input.getDate(TransactionConstants.CONFIRMATION_BATCH_DATE_GENERAL_KEY, null);
		String corporateCode = input.getString(TransactionConstants.CONFIRMATION_BATCH_CORPORATE_CODE_GENERAL_KEY, null);
		BigDecimal loadingFtmSequenceNumber = input.getBigDecimal(TransactionConstants.CONFIRMATION_BATCH_LOADING_FTM_SEQUENCE_NUMBER_GENERAL_KEY);
		String loadingBatchSubmitId = input.getString(TransactionConstants.CONFIRMATION_BATCH_LOADING_SUBMIT_ID_GENERAL_KEY);
		short informIndicator = (short)input.getInt(TransactionConstants.CONFIRMATION_BATCH_INDICATOR_GENERAL_KEY);
		String fileTypeConstant = input.getString(TransactionConstants.CONFIRMATION_BATCH_FILE_TYPE_CONSTANT_GENERAL_KEY);
		String fileName = input.getString(TransactionConstants.CONFIRMATION_FILE_NAME_GENERAL_KEY);
		
		if(processDate == null){
			processDate = new Date();
		}
		
		List<CorporateFileTransfer> fileTransferDefinitions = null;
		logger.info("Getting file transfer definitions");
		if(corporateCode == null){
			fileTransferDefinitions = getFileTransferDefinitions(hibernateSession, transferType);
		}
		else{
			fileTransferDefinitions = getFileTransferDefinition(corporateCode, hibernateSession, transferType);
		}
		
		OutgoingFileStarterInformation information = new OutgoingFileStarterInformation();		
		information.setMaxParallelThreadCount(Integer.valueOf(CommonHelper.getValueOfParameter("CDM_INFORM_COLLECTION_MAX_PARALLEL_COUNT", "COUNT")));
		information.setProcessDate(processDate);
		information.setProcessDateLongDateTimeFormat(CommonHelper.getLongDateTimeString(processDate));
		information.setServiceName(TransactionConstants.StartCorporateBatch.SERVICE_NAME);
		information.setInformIndicator(informIndicator);
		
		List<String> addedCorporates = new ArrayList<String>();
		
		for(CorporateFileTransfer transfer : fileTransferDefinitions){
			if (!addedCorporates.contains(transfer.getCorporateCode())) {
				OutgoingFileLoadingInformation loadingInformation = new OutgoingFileLoadingInformation();
				loadingInformation.setBatchName(transfer.getBatchName());
				loadingInformation.setCorporateCode(transfer.getCorporateCode());
				loadingInformation.setFtmId(String.valueOf(transfer.getFtmId().intValue()));
				loadingInformation.setFormatId(transfer.getFormatId());
				loadingInformation.setFileTransferId(transfer.getFileTransferId());
				loadingInformation.setTransferType(transfer.getTransferType().toString());
				loadingInformation.setLoadingBatchSubmitId(loadingBatchSubmitId);
				loadingInformation.setLoadingFtmSequenceNumber(loadingFtmSequenceNumber);
				loadingInformation.setFileTypeConstant(fileTypeConstant);	
				loadingInformation.setFileName(fileName);	
				information.addToFileLoadingInformation(loadingInformation);
			}
			else{
				throw new BatchComponentException(BusinessException.INFORMINVOICECOLLECTIONAMBIGIOUSCORPORATE, transfer.getCorporateCode());
			}
		}
		
		OutgoingFileByCorporateImplementation implementation = new OutgoingFileByCorporateImplementation(information);
		logger.info("Starting for outgoing file by corporate implementation");
		implementation.execute();
		
		if(implementation.isHasError()){
			logger.info("Outgoing file by corporate implementation has error : " + implementation.getErrorMessage());
			output.put(TransactionConstants.CreateLoadingConfirmationStarter.Output.RESULT, false);
			output.put(TransactionConstants.CreateLoadingConfirmationStarter.Output.ERROR_CODE, implementation.getErrorCode());
			output.put(TransactionConstants.CreateLoadingConfirmationStarter.Output.ERROR_MESSAGE, implementation.getErrorMessage());
		}
		else{
			logger.info("Outgoing file by corporate implementation has no error.");
			output.put(TransactionConstants.CreateLoadingConfirmationStarter.Output.RESULT, true);
		}
	}

	@SuppressWarnings("unchecked")
	private static List<CorporateFileTransfer> getFileTransferDefinitions(Session hibernateSession, short transferType) {
		return hibernateSession.createCriteria(CorporateFileTransfer.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("transferType", transferType))
				.add(Restrictions.or(Restrictions.eq("complexFileTransfer", false), Restrictions.isNull("complexFileTransfer")))
				.list();
	}
	
	@SuppressWarnings("unchecked")
	private static List<CorporateFileTransfer> getFileTransferDefinition(String corporateCode, Session hibernateSession, short transferType) {
		return hibernateSession.createCriteria(CorporateFileTransfer.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("transferType", transferType))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.add(Restrictions.or(Restrictions.eq("complexFileTransfer", false), Restrictions.isNull("complexFileTransfer")))
				.list();
	}
	
	public static void insertBatchSubmitLog(String corporateCode, String batchName,
			String ftmId, String formatId, String batchSubmitId, String batchServiceName, GMMap input) throws IOException {
		try {
			input.put(MapKeys.BATCH_SERVICE_NAME_FOR_RESUBMIT, batchServiceName);
			GMMap insertRequest = new GMMap();
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.BATCH_NAME, batchName);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.CORPORATE_CODE, corporateCode);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.IS_UPDATE, false);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.START_TIME, CommonHelper.getLongDateTimeString(new Date()));
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_DATE, CommonHelper.getLongDateTimeString(new Date()));
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_ID, batchSubmitId);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_STATUS, DatabaseConstants.SubmitStatuses.START);
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_USER, CommonHelper.getCurrentUser());
			insertRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.PARAMETERS,CommonHelper.serializeRequest(input));
			GMServiceExecuter.executeNT(TransactionConstants.InsertBatchSubmitLog.SERVICE_NAME, insertRequest);
		} catch (Exception e) {
			logger.error(String.format("An exception occured while inserting batch submit log with params : Corporate Code : %s," +
					" Batch Name : %s, Ftm Id : %s, Format Id : %s, Batch Submit Id : %s, Batch Service Name %s, Input : %s",
					corporateCode, batchName, ftmId, formatId, batchSubmitId, batchServiceName, input.toString()));
			logger.error(System.currentTimeMillis(), e);
		}
	}
	
	public static void updateBatchSubmitLog(String submitId, String submitStatus,
			Date date, String errorCode, String errorDescription) {
		try {
			GMMap updateRequest = new GMMap();
			updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.IS_UPDATE, true);
			updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_STATUS, submitStatus);
			if (date != null) {
				updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.END_TIME, CommonHelper.getLongDateTimeString(date));
			}
			if (!StringUtil.isEmpty(errorCode)) {
				updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.ERROR_CODE, errorCode);
			}
			if (!StringUtil.isEmpty(errorDescription)) {
				updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.ERROR_DESCRIPTION, errorDescription);
			}
			updateRequest.put(TransactionConstants.InsertBatchSubmitLog.Input.SUBMIT_ID, submitId);
			GMServiceExecuter.executeNT(TransactionConstants.InsertBatchSubmitLog.SERVICE_NAME, updateRequest);
		} catch (Exception e) {
			logger.error(String.format("An exception occured while updating batch submit log with Submit Id : %s, Submit Status : %s, Date : %s, " +
					"Error Code : %s, Error Description : %s", submitId, submitStatus, date, errorCode, errorDescription));
			logger.error(System.currentTimeMillis(), e);
		}
	}
	
	public static String getBatchSubmitLogId() throws Exception{
		return CorporationServiceUtil
				.getSequenceCode(GeneralConstants.BatchSubmitIdSequenceKey);
	}
	
	public static String getMask(String mask) {
		String patternCharacterList = "#X0*Q";
		StringBuilder maskBuilder = new StringBuilder();
		for (int i = 0; i < mask.length(); i++) {
			char character = mask.charAt(i);
			if (patternCharacterList.contains(Character.toString(character))) {
				maskBuilder.append('-');
			} else {
				maskBuilder.append(character);
			}
		}

		return maskBuilder.toString();
	}
	

	public static String getPreviousTxNo(String tableName, BigDecimal txNo, String corpCode) {
		String s = String.format(QueryRepository.CosCommonBusinessOperationsRepository.PREVIOUS_TX_NO_QUERY, tableName, txNo, corpCode);
		return DALUtil.getResult(s);
	}
	
	private static final String DECIMAL_FORMAT_PATTERN = "###,###.##";
	
	public static void sendDuplicatePaymentEmail(Date processDate) {
		String duplicateRecordQuery = "select order_main_oid,t.amount, t.payment_account_no, t.recipient_account_no, t.recipient_iban, count(*) AS DUPLICATE_COUNT, LISTAGG(t.tx_no, '-') WITHIN GROUP (ORDER BY t.tx_no) \"DUPLICATE_TX_NOS\" , " +
				"decode(t.order_type,1,'EFT',2,'Havale',3,'Virman',4,'PTT �sme Havale') as ORDER_TYPE " +
				"from COS.ORDER_TRANSFER t " +
				"where t.transfer_date like '" + CommonHelper.getShortDateTimeString(processDate) + "%' " +
				"group by t.order_main_oid, t.amount, t.payment_account_no, t.recipient_account_no, t.recipient_iban, decode(t.order_type,1,'EFT',2,'Havale',3,'Virman',4,'PTT �sme Havale') " +
				"having count(*) > 1";
		
		final String RESULT_TABLE_NAME = "DUPLICATE_RECORDS";
		
		GMMap results = DALUtil.getResults(duplicateRecordQuery, RESULT_TABLE_NAME);
		
		if(results.getSize(RESULT_TABLE_NAME) > 0){
			StringBuilder mailBodyBuilder = new StringBuilder();
			mailBodyBuilder.append(String.format("<html><head></head><body>%s tarihli yap�lan toplu �demeler i�in m�kerrerlik tespit kay�tlar a�a��daki gibidir.<br/><table border=\"2\">", 
					CommonHelper.getShortDateTimeString(processDate)));
			
			mailBodyBuilder.append("<tr><td><b>��LEM T�P�</b></td><td><b>��LEM NUMARALARI</b></td><td><b>KAYNAK HESAP</b></td><td><b>ALICI HESAP</b></td><td><b>ALICI IBAN</b></td><td><b>TUTAR</b></td><td><b>M�KERRER �DEME SAYISI</b></td></tr>");
			
			for (int i = 0; i < results.getSize(RESULT_TABLE_NAME); i++) {
				DecimalFormat format = new DecimalFormat(DECIMAL_FORMAT_PATTERN);
                String amount = format.format(Double.parseDouble(results.getString(RESULT_TABLE_NAME, i, "AMOUNT")));
				mailBodyBuilder.append(String.format("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",
						results.getString(RESULT_TABLE_NAME, i, "ORDER_TYPE"),
						results.getString(RESULT_TABLE_NAME, i, "DUPLICATE_TX_NOS"),
						results.getString(RESULT_TABLE_NAME, i, "PAYMENT_ACCOUNT_NO"),
						results.getString(RESULT_TABLE_NAME, i, "RECIPIENT_ACCOUNT_NO"),
						results.getString(RESULT_TABLE_NAME, i, "RECIPIENT_IBAN"),
						amount,
						results.getString(RESULT_TABLE_NAME, i, "DUPLICATE_COUNT")));
			}
			
			mailBodyBuilder.append("</table></body></html>");
			
			try {
				CommonHelper.sendMail(Arrays.asList(CommonHelper.getValueOfParameter("CDM_EMAIL_RECEIPT_LIST", "EMAIL_RECEIPT_LIST_4_DUPLICATE_PAYMENT").split(",")), 
						null, "nakityonetimiuygulamagelistirmebirimi@aktifbank.com.tr", 
						true, String.format("%s Tarihli M�kerrer �demeler - Toplu �deme Sistemi", CommonHelper.getShortDateTimeString(processDate)),
						mailBodyBuilder.toString(), true);
			} catch (Exception e) {
				logger.error("An exception occured while sending email for duplicate payment records");
				logger.error(System.currentTimeMillis(), e);
			}
			
			
		}
	}

}
