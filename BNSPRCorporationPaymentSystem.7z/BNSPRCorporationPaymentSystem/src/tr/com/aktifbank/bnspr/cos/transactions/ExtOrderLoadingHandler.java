package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.SingleInstanceMemory;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OrderMain;

import com.graymound.util.GMMap;

public class ExtOrderLoadingHandler extends RequestHandler {
	
	private static final class BagKeys{
		public static final short SubmitId = 1;
		public static final short WaitingOrdersDeleted = 2;
		public static final short OperationSucceeded = 3;
		public static final short FtmTransferId = 4;
		public static final short CorporateCode = 5;	
	}
	
	public ExtOrderLoadingHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.GeneralBatchSubmit.Input.CORPORATE_CODE);		
		String batchSubmitId = input.getString(TransactionConstants.GeneralBatchSubmit.Input.SUBMIT_ID);
		BigDecimal ftmTransferId = BigDecimal.ZERO;
		
		bag.put(BagKeys.SubmitId, batchSubmitId);
		bag.put(BagKeys.OperationSucceeded, false);
		bag.put(BagKeys.WaitingOrdersDeleted, false);
		bag.put(BagKeys.FtmTransferId, ftmTransferId);
		bag.put(BagKeys.CorporateCode, corporateCode);
		
		GMMap getCorpDefinitionMap = new GMMap();
		getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corpDefDetailsMap = super.callGraymoundServiceInSession(TransactionConstants.GetOrderCorpDef.SERVICE_NAME, getCorpDefinitionMap);
		
		String fileLogOid = input.getString(TransactionConstants.GeneralBatchSubmit.Input.ORDER_FILE_LOG_OID);
		String orderDate = input.getString(TransactionConstants.OrderLoadingControls.Input.HEADER_ORDER_DATE);
		// y�kleme a�amas� kontrolleri
		GMMap orderLoadingControlsRequest = new GMMap();
		orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.BATCH_SUBMIT_ID, batchSubmitId);
		orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.HEADER_ORDER_DATE, orderDate);
		orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.ORDER_FILE_LOG_OID, fileLogOid);		
		orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.FTM_SEQUENCE_NUMBER, ftmTransferId);
		orderLoadingControlsRequest.put(TransactionConstants.OrderLoadingControls.Input.ALLOW_TRANSFER_TO_VALID, corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.ALLOW_TRANSFER_TO_VALID));			
		super.callGraymoundServiceOutsideSession(TransactionConstants.OrderLoadingControls.SERVICE_NAME, orderLoadingControlsRequest);			
		
		// onays�z �deme burada yap�lacak
		if (corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.TRANSFER_WITHOUT_APPROVAL)) {
			
			int transferTRYCount = 0, transferUSDCount = 0, transferEURCount = 0;
			BigDecimal transferTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal transferUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal transferEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			String tableName = TransactionConstants.GetOrderFileContent.tableName;
			
			String amountOrder = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING);	
			GMMap withoutApprovalTransferMap = new GMMap();
							
			Criteria criteria = super.getHibernateSession().createCriteria(OrderMain.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("ftmSequenceNumber", ftmTransferId))
								.add(Restrictions.eq("batchSubmitId", batchSubmitId))
								.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.Waiting))
								.add(Restrictions.le("orderStatus", DatabaseConstants.OrderStatuses.RepeatedOrder));				
			if (StringUtils.isNotBlank(amountOrder)) {				
				if (amountOrder.equals("D"))
					criteria = criteria.addOrder(Order.desc("amount"));
				else if (amountOrder.equals("A"))
					criteria = criteria.addOrder(Order.asc("amount"));
			} else 
				criteria = criteria.addOrder(Order.asc("lineNumber"));				
			List<OrderMain> orderList = criteria.list();
				
			int count = 0;
			for (OrderMain order : orderList) {					
				String recipientDateOfBirth = null;
				if (!StringUtils.isEmpty(order.getRecipientDateOfBirth()))
					recipientDateOfBirth = CommonHelper.shortTimeStringToViewDateString(order.getRecipientDateOfBirth());
				
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT, true);
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_NAME, order.getRecipientName()); 
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_ADDRESS, order.getRecipientAddress());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_MOTHER_NAME, order.getRecipientMotherName());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_FATHER_NAME, order.getRecipientFatherName());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_BANK, order.getRecipientBank());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_DATE_OF_BIRTH, recipientDateOfBirth);
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_EMAIL, order.getRecipientEmail());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_ACCOUNT_NO, order.getRecipientAccountNo());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_IBAN, order.getRecipientIban());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_CC_NO, order.getRecipientCcNo());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_REF_NO, order.getRecipientRefNo());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_BRANCH, order.getRecipientBranch());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_TCKN, order.getRecipientTckn());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_PHONE_NUMBER, order.getRecipientPhoneNumber());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_VKN, order.getRecipientVkn());		
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ACCOUNT_NO, order.getAccountNo());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.EXPLANATION, order.getExplanation());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE, order.getOrderStatus());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_TYPE, order.getOrderType());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.COMMISSION_ACCOUNT_NO, order.getCommissionAccountNo());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.COMMISSION_AMOUNT, order.getCommissionAmount());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.CUSTOMER_NAME, order.getCustomerName());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.CUSTOMER_NO, order.getCustomerNo());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.CURRENCY_CODE, order.getCurrencyCode());										
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_TYPE, order.getTransferType());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.AMOUNT, order.getAmount());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TAX_OFFICE, order.getTaxOffice());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.MAIN_OID, order.getOid());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.CORPORATE_CODE, order.getCorporateCode());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_DATE, order.getOrderDate());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.PAYMENT_ACCOUNT_NO, order.getPaymentAccountNo());
				withoutApprovalTransferMap.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.PAYMENT_COMMISSION_ACCOUNT_NO, order.getPaymentCommissionAccountNo());
				count++;
										
				if (order.getCurrencyCode().equals(DatabaseConstants.CurrencyCodes.TRY)) {
					transferTRYCount++;
					transferTRYAmount = transferTRYAmount.add(order.getAmount()); 						
				} else if (order.getCurrencyCode().equals(DatabaseConstants.CurrencyCodes.USD)) {
					transferUSDCount++;
					transferUSDAmount = transferUSDAmount.add(order.getAmount()); 						
				} else if (order.getCurrencyCode().equals(DatabaseConstants.CurrencyCodes.EUR)) {
					transferEURCount++;
					transferEURAmount = transferEURAmount.add(order.getAmount()); 						
				}
			}
			
			GMMap updateOrderFileLogRequest = new GMMap();
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.OID, fileLogOid);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.SUBMIT_ID, batchSubmitId);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.OID, fileLogOid);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.LOADING_STATUS, DatabaseConstants.LoadingStatuses.SUCESSFUL);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.TRY_AMOUNT, transferTRYAmount);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.USD_AMOUNT, transferUSDAmount);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.EUR_AMOUNT, transferEURAmount);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.TRY_LINE_COUNT, transferTRYCount);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.USD_LINE_COUNT, transferUSDCount);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.EUR_LINE_COUNT, transferEURCount);
			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.ORDER_DATE, orderDate);
//			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_NO, implementation.information.getHeaderCustomerNo());
//			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_BANK, implementation.information.getHeaderCustomerBank());
//			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_BRANCH, implementation.information.getHeaderCustomerBranch());
//			updateOrderFileLogRequest.put(TransactionConstants.UpdateOrderFileLog.Input.CUSTOMER_ACCOUNT_NO, implementation.information.getHeaderCustomerAccountNo());		
			GMMap updateOrderFileLogResponse = super.callGraymoundServiceOutsideSession(TransactionConstants.UpdateOrderFileLog.SERVICE_NAME, updateOrderFileLogRequest);	
			
			if (transferTRYCount > 0 || transferUSDCount > 0 || transferEURCount > 0) {	

				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.CORPORATE_CODE, corporateCode);
				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.TRY_AMOUNT, transferTRYAmount);
				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.USD_AMOUNT, transferUSDAmount);
				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.EUR_AMOUNT, transferEURAmount);
				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.TRY_RECORD_COUNT, transferTRYCount);
				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.USD_RECORD_COUNT, transferUSDCount);
				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.EUR_RECORD_COUNT, transferEURCount);
				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.BATCH_SUBMIT_ID, batchSubmitId);
				withoutApprovalTransferMap.put(TransactionConstants.OrderTransaction.Input.TRANSFER_WITHOUT_APPROVAL, true);
				withoutApprovalTransferMap.put("FILE_STATUS", updateOrderFileLogResponse.getString("FILE_STATUS"));
				//TODO: ONLINE EFT ISLEMIDIR PARAMETRESI KOY
				
				output = CommonHelper.callGraymoundServiceOutsideSession("COS_ORDER_TRANSACTION", withoutApprovalTransferMap);
			}
		
		}
	} 

	@Override
	protected void handleBusinessError(BatchComponentException e, GMMap output) {
		this.handleError(e, output);
	}

	@Override
	protected void handleError(Throwable e, GMMap output) {
		logger.error(System.currentTimeMillis(), e);
		String errorCode = "1";
		String errorMessage = String.format("An exception occured while executing order loading. %s", CommonHelper.getStringifiedException(e));
		if(e instanceof BatchComponentException){
			BatchComponentException exception = (BatchComponentException)e;
			errorCode = String.valueOf(exception.getCode());
			errorMessage = exception.getMessage();
		}
		CommonBusinessOperations.updateBatchSubmitLog(bag.get(BagKeys.SubmitId).toString(), DatabaseConstants.SubmitStatuses.FAILURE, new Date(), errorCode, errorMessage);
	}
	
	@Override
	protected void handleFinally(GMMap output) {
		try{
			SingleInstanceMemory.getInstance().removeCache((String)bag.get(BagKeys.SubmitId));
		}
		catch(Exception e){
			logger.error("An exception occured while removing order cache");
			logger.error(System.currentTimeMillis(), e);
		}
		if(!(Boolean)bag.get(BagKeys.OperationSucceeded) && (Boolean)bag.get(BagKeys.WaitingOrdersDeleted)){
			try{
				rollbackWaitingOrdersDeletion();
			}
			catch(Exception e){
				logger.error(String.format("An error occured while rollbacking waiting orders with transfer id %s", bag.get(BagKeys.FtmTransferId)));
				logger.error(System.currentTimeMillis(), e);
			}
		}
	}

	private void rollbackWaitingOrdersDeletion() {
		String query = String.format("UPDATE COS.ORDER_MAIN SET STATUS = 1, DELETED_TRANSFER_ID = null WHERE DELETED_TRANSFER_ID = %s", bag.get(BagKeys.FtmTransferId));
		super.getHibernateSession().createSQLQuery(query).executeUpdate();
	}

}
