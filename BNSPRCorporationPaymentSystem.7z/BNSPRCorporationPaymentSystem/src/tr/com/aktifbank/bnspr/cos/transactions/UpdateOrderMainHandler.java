package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.util.Date;

import org.apache.axis.utils.StringUtils;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.aktifbank.bnspr.dao.OrderTransferLog;

import com.graymound.util.GMMap;

public class UpdateOrderMainHandler extends RequestHandler {

	public UpdateOrderMainHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
				
		String oid = input.getString(TransactionConstants.UpdateOrderMainAndTransferLog.Input.OID);
		String orderStatus = input.getString(TransactionConstants.UpdateOrderMainAndTransferLog.Input.ORDER_STATUS);
		Boolean setFailedPaymentToNull = input.getBoolean(TransactionConstants.UpdateOrderMainAndTransferLog.Input.SET_FAILED_PAYMENT_TO_NULL);
		String errorDesc = input.getString(TransactionConstants.UpdateOrderMainAndTransferLog.Input.ERROR_DESC);		

		OrderMain order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
										.add(Restrictions.eq("status", true))
										.add(Restrictions.eq("oid", oid)).uniqueResult();
		if (order != null) {
			if (!StringUtils.isEmpty(orderStatus)) {
				order.setOrderStatus(orderStatus);
				if ( ( new BigDecimal(orderStatus).compareTo(new BigDecimal(DatabaseConstants.OrderStatuses.InsufficientBalance)) >= 0 ) && 
					 ( new BigDecimal(orderStatus).compareTo(new BigDecimal(DatabaseConstants.OrderStatuses.Transfered)) < 0 ) )
					order.setFailedPaymentStatus(true);
				else if (new BigDecimal(orderStatus).compareTo(new BigDecimal(DatabaseConstants.OrderStatuses.NotValidEftTime)) == 0)
					order.setFailedPaymentStatus(null);
			}
			if (setFailedPaymentToNull != null && setFailedPaymentToNull)
				order.setFailedPaymentStatus(null);			
			if (!StringUtils.isEmpty(errorDesc))
				order.setErrorDesc(errorDesc);			
			super.getHibernateSession().update(order);
		}			
		
		OrderTransferLog transferLog = (OrderTransferLog) super.getHibernateSession().createCriteria(OrderTransferLog.class)
															.add(Restrictions.eq("status", true))
															.add(Restrictions.eq("orderMainOid", oid)).uniqueResult();
		if (transferLog != null) {
			if (!StringUtils.isEmpty(orderStatus))
				transferLog.setOrderStatus(orderStatus);
			if (!StringUtils.isEmpty(errorDesc)) {
				transferLog.setErrorDesc(errorDesc);
				transferLog.setFailedPaymentDate(CommonHelper.getLongDateTimeString(new Date()));
			}
			super.getHibernateSession().update(transferLog);
		}
		super.getHibernateSession().flush();	
	}
}