package tr.com.aktifbank.bnspr.cos.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public final class OutgoingFileStarterInformation extends
		BaseTransferObject {

	public OutgoingFileStarterInformation() {
		this.fileLoadingInformation = new ArrayList<OutgoingFileLoadingInformation>();
	}

	private List<OutgoingFileLoadingInformation> fileLoadingInformation;
	private int maxParallelThreadCount;
	private Date processDate;
	private String processDateLongDateTimeFormat;
	private String serviceName;
	private short informIndicator;

	public short getInformIndicator() {
		return informIndicator;
	}

	public void setInformIndicator(short informIndicator) {
		this.informIndicator = informIndicator;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Date getProcessDate() {
		return processDate;
	}

	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}

	public String getProcessDateLongDateTimeFormat() {
		return processDateLongDateTimeFormat;
	}

	public void setProcessDateLongDateTimeFormat(
			String processDateLongDateTimeFormat) {
		this.processDateLongDateTimeFormat = processDateLongDateTimeFormat;
	}
	
	public int getMaxParallelThreadCount() {
		return maxParallelThreadCount;
	}

	public void setMaxParallelThreadCount(int maxParallelThreadCount) {
		this.maxParallelThreadCount = maxParallelThreadCount;
	}

	public List<OutgoingFileLoadingInformation> getFileLoadingInformation() {
		return fileLoadingInformation;
	}

	public void setFileLoadingInformation(
			List<OutgoingFileLoadingInformation> fileLoadingInformation) {
		this.fileLoadingInformation = fileLoadingInformation;
	}
	
	public void addToFileLoadingInformation(OutgoingFileLoadingInformation information){
		this.fileLoadingInformation.add(information);
	}
	
}
