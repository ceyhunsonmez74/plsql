package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.List;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OrderMain;

import com.graymound.util.GMMap;

public class GetFailedLineCountStatusAtControlsHandler extends RequestHandler {

	public GetFailedLineCountStatusAtControlsHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
				
		String batchSubmitId = input.getString(TransactionConstants.GetFailedLineCountAndFileStatus.Input.BATCH_SUBMIT_ID);
		
		String orderStatus = null, fileStatus = null;
		int failedLineCount = 0;
		boolean somePaymentsFailed = false;
		
		List<OrderMain> orderList = super.getHibernateSession().createCriteria(OrderMain.class)
									.add(Restrictions.eq("status", true))								
									.add(Restrictions.eq("batchSubmitId", batchSubmitId)).list();
		for (OrderMain order : orderList) {
			orderStatus = order.getOrderStatus();
			if ( !orderStatus.equals(DatabaseConstants.OrderStatuses.Waiting) && !orderStatus.equals(DatabaseConstants.OrderStatuses.RepeatedOrder) &&
				!orderStatus.equals(DatabaseConstants.OrderStatuses.WaitingApproval) && !orderStatus.equals(DatabaseConstants.OrderStatuses.Approved) && 
				!orderStatus.equals(DatabaseConstants.OrderStatuses.Transfered) && !orderStatus.equals(DatabaseConstants.OrderStatuses.AfterApprovalProcessStarted) )
				failedLineCount++;
			
			if (!orderStatus.equals(DatabaseConstants.OrderStatuses.Transfered))
				somePaymentsFailed = true;
		}		
	
		if (somePaymentsFailed)
			fileStatus = DatabaseConstants.FileStatuses.SOMEPAYMENTSFAILED;
		else	
			fileStatus = DatabaseConstants.FileStatuses.PAYMENTSSUCCESSFUL;
		
		output.put(TransactionConstants.GetFailedLineCountAndFileStatus.Output.FAILED_LINE_COUNT, failedLineCount);
		output.put(TransactionConstants.GetFailedLineCountAndFileStatus.Output.FILE_STATUS, fileStatus);		
	}

}
