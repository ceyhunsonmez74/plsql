package tr.com.aktifbank.bnspr.cos.batch.implementations;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.axis.utils.StringUtils;
import org.apache.commons.lang.NotImplementedException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.MapKeys;
import tr.com.aktifbank.bnspr.cos.dto.FormatDetail;
import tr.com.aktifbank.bnspr.cos.dto.ItemDatabaseField;
import tr.com.aktifbank.bnspr.cos.dto.ItemServiceField;
import tr.com.aktifbank.bnspr.cos.dto.OutgoingFileBatchInformation;
import tr.com.aktifbank.bnspr.cps.common.BatchComponentException;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;

import com.graymound.util.GMMap;

public abstract class OutgoingFileBatch {

	protected static Log logger = LogFactory.getLog(OutgoingFileBatch.class);
	
	OutgoingFileBatchInformation information;
	boolean errorExist;
	String errorMessage;
	String errorCode;
	
	protected OutgoingFileBatchInformation getInformation(){
		return this.information;
	}
	
	public boolean isErrorExist() {
		return errorExist;
	}

	protected void setErrorExist(boolean errorExist) {
		this.errorExist = errorExist;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	protected void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	protected void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public OutgoingFileBatch(OutgoingFileBatchInformation information) {
		this.information = information;
	}

	public void execute() throws Throwable{
		try {
			Object records = getRecords();
					
			String headerInitialConstant = null;
			if(this.information.getHeaderDetails().size() > 0){
				headerInitialConstant = this.information.getHeaderDetails().get(0).getInitialConstant();
			}
			String bodyInitialConstant = null;
			if(this.information.getBodyDetails().size() > 0){
				bodyInitialConstant = this.information.getBodyDetails().get(0).getInitialConstant();
			}
			String footerInitialConstant = null;
			if(this.information.getFooterDetails().size() > 0){
				footerInitialConstant = this.information.getFooterDetails().get(0).getInitialConstant();
			}
			
			int totalLengthOfHeaderLine = this.getTotalLengthOfLine(this.information.getHeaderDetails());
			int totalLengthOfBodyLine = this.getTotalLengthOfLine(this.information.getBodyDetails());
			int totalLengthOfFooterLine = this.getTotalLengthOfLine(this.information.getFooterDetails());
			
			logger.info("Getting records from inherited class");
			
			int currentLineIndex = this.getInformation().getLineNumber();
			
			logger.info("Creating header lines");
			currentLineIndex = createLines(this.information.getHeaderDetails(), headerInitialConstant, totalLengthOfHeaderLine, records, currentLineIndex, true, false);		
			logger.info("Creating detail lines");
			currentLineIndex = createLines(this.information.getBodyDetails(), bodyInitialConstant, totalLengthOfBodyLine, records, currentLineIndex, false, false);		
			logger.info("Creating footer lines");
			currentLineIndex = createLines(this.information.getFooterDetails(), footerInitialConstant, totalLengthOfFooterLine, records, currentLineIndex, false, true);
			
			this.information.setAfterProcessLineNumber(currentLineIndex);
		}
		catch(BatchComponentException ex){
			logger.error(String.format("[OutgoingFileBatch] An exception occured while prepared a batch file. Details %s ", ex.getMessage()));
			logger.error(System.currentTimeMillis(), ex);
			
			this.setErrorExist(true);
			this.setErrorMessage(ex.getMessage());
			//TODO make diversities about error codes
			this.setErrorCode("0");
		}
		catch(Exception ex){
			logger.error(String.format("[OutgoingFileBatch] An exception occured while prepared a batch file. Details : %s ", 
					ex.getMessage()));
			logger.error(System.currentTimeMillis(), ex);
			
			this.setErrorExist(true);
			this.setErrorMessage(CommonHelper.getStringifiedException(ex));
			this.setErrorCode("0");

		}
		catch (Throwable ex) {
			logger.error(String.format("[OutgoingFileBatch] An exception occured while prepared a batch file. Details : %s ", 
					ex.getMessage()));
			logger.error(System.currentTimeMillis(), ex);
			
			this.setErrorExist(true);
			this.setErrorMessage(CommonHelper.getStringifiedException(ex));
			this.setErrorCode("0");
		}		
	}
	
	protected abstract Object getRecords() throws Throwable;
	protected abstract Object getDataFromSource(String fieldName, Object records, int index) throws Throwable;
	protected abstract GMMap getCurrentRow(Object records, int index) throws Exception;
	protected abstract int getRecordsSize(Object records) throws Throwable;

	private int getTotalLengthOfLine(List<FormatDetail> details) {
		if (details.size() > 0) {
			FormatDetail lastElement = Collections.max(details,
					new FormatDetail.FormatDetailStartIndisComparator());
			return lastElement.getStartIndis().intValue()
					+ lastElement.getLength().intValue();
		}
		else{
			return 0;
		}
	}
	
	private int createLines(List<FormatDetail> formatDetails, String initialConstant, int totalLengthOfLine, Object records, int currentLineIndex, boolean headerLine, boolean footerLine) throws Throwable{
		if(formatDetails.size() == 0){
			return currentLineIndex;
		}
		if(headerLine || footerLine){
			currentLineIndex = createLine(formatDetails, initialConstant, totalLengthOfLine, records, currentLineIndex, 0);
			return currentLineIndex;
		}
		else{
			int recordsSize = this.getRecordsSize(records);
			for (int i = 0; i < recordsSize; i++) {
				currentLineIndex = createLine(formatDetails, initialConstant, totalLengthOfLine, records, currentLineIndex, i);
			}
			return currentLineIndex;
		}
	}

	private int createLine(List<FormatDetail> formatDetails, String initialConstant, int totalLengthOfLine, Object records, int currentLineIndex, int i) throws Throwable {
		StringBuilder lineBuilder = new StringBuilder(totalLengthOfLine);
		lineBuilder.insert(0, initialConstant);
		for(FormatDetail detail : formatDetails){
			try {
				int startIndex = detail.getStartIndis().intValue() + initialConstant.length() - 1;
				int length = detail.getLength().intValue();
				String fieldType = detail.getDataType();
				String pattern = detail.getDataPattern();
				String constant = detail.getConstant();
				String dataItemSource = detail.getDatasourceType();
				String dataItemReference = detail.getDatasourceReference();
				String dataItemReference2 = detail.getDatasourceReference2();
				String fillingCharacter = detail.getFillingCharacter();
				String position = detail.getAlignment();
				if(fieldType.equals(DatabaseConstants.FieldType.Constant)){
					lineBuilder.insert(startIndex, constant);
				}
				else{
					Object data;
					try {
						data = getData(dataItemSource, dataItemReference, dataItemReference2, records, i);
					} catch (Exception e) {
						logger.error(String.format("An exception occured while getting data from source : %s with reference : %s with id %s", dataItemSource,
								dataItemReference, i));
						throw e;
					}
					String stringData;
					try {
						stringData = getStringifiedData(data, fieldType, pattern, length, fillingCharacter, position);
					} catch (Exception e) {
						logger.error(String.format("An exception occured while stringify data : %s with field type : %s with pattern %s, length : %s, filling character : %s, position : %s", 
								data, fieldType, pattern, length, fillingCharacter, position));
						throw e;
					}
					if(stringData == null){
						throw new Exception(String.format("Data from %s source with %s reference is longer than the specified %s length", dataItemSource, dataItemReference, length));
					}
					lineBuilder.insert(startIndex, stringData);
				}
			} catch (Exception e) {
				logger.error(String.format("An exception occured while building line for index : %s for details with id : %s", 
						i, detail.getOid()));
				logger.error(System.currentTimeMillis(), e);
				throw e;
			}
		}
		
		String result = lineBuilder.toString();
		
		insertFtmFileContent(currentLineIndex, result);
		
		currentLineIndex++;
		return currentLineIndex;
	}

	private void insertFtmFileContent(int lineCounter, String line) {
		FtmFileContent content = new FtmFileContent();
		content.setOid(String.valueOf(lineCounter));
		content.setFtmProcessOid(this.information.getFtmProcessId());
		content.setLine(line);
		content.setLineNumber(new BigDecimal(lineCounter));
		
		this.information.getHibernateSession().save(content);
	}

	private String getStringifiedData(Object data, String fieldType, String pattern, int length, String fillingCharacter, String position) throws Throwable {
		String pureStringifiedData = getStringOfData(data, fieldType, pattern);
		if(pureStringifiedData.length() == length){
			return CommonHelper.replaceCharacters(pureStringifiedData, "'", " ");
		}
		else{
			if(length > pureStringifiedData.length()){
				if (StringUtils.isEmpty(pureStringifiedData))
					fillingCharacter = " ";
				StringBuilder builder = new StringBuilder(length);
				int fillingCount = length - pureStringifiedData.length();
				if(position.equals(DatabaseConstants.Alignments.Left)) {
					builder.insert(0, pureStringifiedData);
					int counter = pureStringifiedData.length();
					while(fillingCount-- > 0){
						builder.insert(counter++, fillingCharacter);
					}
				}
				else{
					int counter = 0;
					while(fillingCount-- > 0){
						builder.insert(counter++, fillingCharacter);
					}
					builder.insert(counter, pureStringifiedData);
				}
				
				return CommonHelper.replaceCharacters(builder.toString(), "'", " ");
			}
			else{
				return null;
			}
		}
	}

	protected String getStringOfData(Object data, String fieldType, String pattern) throws Throwable {
		if(fieldType.equals(DatabaseConstants.FieldType.AlphaNumeric)){
			if(data instanceof GMMap){
				return ((GMMap)data).getString(MapKeys.FTS_OUTPUT_DATA);
			}
			else{
				if (data != null)
					return data.toString();
				else
					return "";
			}
		}
		else if(fieldType.equals(DatabaseConstants.FieldType.Amount)){
			BigDecimal insideData = null;
			if (data instanceof GMMap) {
				insideData = ((GMMap)data).getBigDecimal(MapKeys.FTS_OUTPUT_DATA);
			}
			else{
				insideData = (BigDecimal)data;
			}
			DecimalFormatSymbols symbolse = new DecimalFormatSymbols(
					Locale.ROOT);
			DecimalFormat format = new DecimalFormat(pattern, symbolse);
			format.setMinimumFractionDigits(2);
			format.setMaximumFractionDigits(2);
			return format.format(((BigDecimal) insideData).doubleValue());
		}
		else if(fieldType.equals(DatabaseConstants.FieldType.Date)){
			if(data instanceof GMMap){
				Date dateData = ((GMMap)data).getDate(MapKeys.FTS_OUTPUT_DATA);
				return CommonHelper.getDateString(dateData, pattern);
			}
			else{
				String insideData = (String)data;
				String format = "yyyyMMddhhmmss";
				if(insideData.length() == 8){
					format = "yyyyMMdd";
				}
				Date dateData = CommonHelper.getDateTime(insideData, format);
				return CommonHelper.getDateString(dateData, pattern);
			}
		}
		else if(fieldType.equals(DatabaseConstants.FieldType.Numeric)){
			Number insideData = null;
			if(data instanceof GMMap){
				insideData = ((GMMap)data).getBigDecimal(MapKeys.FTS_OUTPUT_DATA);
			}
			else{
				insideData = (Number)data;
			}
			return insideData.toString();
		}
		else if(fieldType.equals(DatabaseConstants.FieldType.Time)){
			String insideData = null;
			if(data instanceof GMMap){
				insideData = ((GMMap)data).getString(MapKeys.FTS_OUTPUT_DATA);
			}
			else{
				insideData = (String)data;
			}
			Date dateData = CommonHelper.getDateTime(insideData, "hhmmss");
			return CommonHelper.getDateString(dateData, pattern);
		}
		else{
			throw new NotImplementedException(String.format("Field type %s is not implemented", fieldType));
		}
	}

	protected Object getData(String dataItemSource, String dataItemReference, String dataItemReference2, Object records, int index) throws Throwable {
		if(dataItemSource.equals(DatabaseConstants.DataSourceTypes.Database)){
			String fieldName = ((ItemDatabaseField)this.information.getDatabaseFields().get(dataItemReference)).getDbField();
			Object data = getDataFromSource(fieldName, records, index);
			return data;
		}
		else if(dataItemSource.equals(DatabaseConstants.DataSourceTypes.Service)){
			String serviceName = ((ItemServiceField)this.information.getServiceFields().get(dataItemReference)).getServiceName();
			GMMap serviceMap = new GMMap();
			serviceMap.put("INPUT_MAP", this.information.getOutgoingFileBatchInput());
			serviceMap.put("CURRENT_ROW", this.getCurrentRow(records, index));
			serviceMap.put("RECORDS", records);
			return CommonHelper.callGraymoundServiceInHibernateSession(serviceName, serviceMap);
		}
		else if(dataItemSource.equals(DatabaseConstants.DataSourceTypes.DatabaseAndService)){
			String fieldName = ((ItemDatabaseField)this.information.getDatabaseFields().get(dataItemReference)).getDbField();
			String serviceName = ((ItemServiceField)this.information.getServiceFields().get(dataItemReference2)).getServiceName();
			GMMap serviceMap = new GMMap();
			serviceMap.put("INPUT_MAP", this.information.getOutgoingFileBatchInput());
			serviceMap.put("CURRENT_ROW", this.getCurrentRow(records, index));
			serviceMap.put("FIELD_NAME", "IP".concat(fieldName));
			return CommonHelper.callGraymoundServiceInHibernateSession(serviceName, serviceMap);
		}
		else{
			throw new NotImplementedException(String.format("Data source type %s has not been implemented", dataItemSource));
		}
	}	
}
