package tr.com.aktifbank.bnspr.cos.transactions;



import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CorporateBatchProcess;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public final class GetOrderBatchDetailHandler extends RequestHandler {

	public GetOrderBatchDetailHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String batchName = CommonHelper.getValueOrThrow(input, TransactionConstants.GetOrderBatchDetail.Input.BATCH_NAME);
		String corporateCode = CommonHelper.getValueOrThrow(input, TransactionConstants.GetOrderBatchDetail.Input.CORPORATE_CODE);
		String query = null, batchServiceName = null;
		
		CorporateBatchProcess corporateBatchProcessResult = (CorporateBatchProcess)super.getHibernateSession().
				createCriteria(CorporateBatchProcess.class).
				add(Restrictions.eq("batchName", batchName)).
				add(Restrictions.eq("corporateCode", corporateCode)).
				add(Restrictions.eq("status", true)).
				uniqueResult();
		
		if(corporateBatchProcessResult == null){
			throw new BatchComponentException(BusinessException.CORPORATEBATCHPROCESSRECORDISNOTFOUND, batchName, corporateCode);
		}
		
		int commitCount = corporateBatchProcessResult.getCommitCount();
		int threadCount = corporateBatchProcessResult.getThreadCount();
		
		try {
			query = QueryRepository.GetOrderBatchDetailHandlerRepository.BATCH_SERVICE_NAME_QUERY;
			batchServiceName = DALUtil.getResult(String.format(query, batchName));
		}
		catch (Exception e) {
			throw new BatchComponentException(BusinessException.BATCHDEFRECORDISNOTFOUND, batchName);
		}
		
		//output.put(TransactionConstants.GetBatchDetail.Output.BATCH_OID, batchDefResults.getOid());
		output.put(TransactionConstants.GetOrderBatchDetail.Output.COMMIT_COUNT, commitCount);
		output.put(TransactionConstants.GetOrderBatchDetail.Output.SERVICE_NAME, batchServiceName);
		output.put(TransactionConstants.GetOrderBatchDetail.Output.THREAD_COUNT, threadCount);
		output.put(TransactionConstants.GetOrderBatchDetail.Output.THRESHOLD, corporateBatchProcessResult.getTryCount());
		output.put(TransactionConstants.GetOrderBatchDetail.Output.CORPORATE_BATCH_PROCESS_OID, corporateBatchProcessResult.getOid());
	}

}
