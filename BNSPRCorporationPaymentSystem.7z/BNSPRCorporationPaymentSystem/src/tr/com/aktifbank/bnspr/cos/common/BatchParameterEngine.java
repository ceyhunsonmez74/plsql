package tr.com.aktifbank.bnspr.cos.common;

import java.util.Map;

import java.lang.String;

public class BatchParameterEngine {
	private Boolean argIsComposedParameter;
	
	private Boolean isProcessed;
	
	private String composedParameters;
	
	private Map<String, String> decomposedParameters;
	
	public BatchParameterEngine(String composedParameters) throws Exception {
		this((Object)composedParameters);
	}
	
	public BatchParameterEngine(Map<String, String> decomposedParameters) throws Exception{
		this((Object)decomposedParameters);
	}
	
	@SuppressWarnings("unchecked")
	private BatchParameterEngine(Object args) throws Exception{
		isProcessed = false;
		if(args instanceof String){
			composedParameters = (String)args;
			argIsComposedParameter = true;
		}
		else if(args instanceof Map<?, ?>){
			decomposedParameters = (Map<String, String>)args;
			argIsComposedParameter = false;
		}
		else{
			throw new Exception(String.format("Constructor argument's type of BatchParmeterEngine is unexpected : %s", args.getClass().getName()));
		}
	}
	
	private String composeParameters() {
		return CommonHelper.composeParameters(this.decomposedParameters);
	}

	private Map<String, String> decomposeParameters() {
		return CommonHelper.decomposeParameters(this.composedParameters);
	}

	public String getComposedParameters(){
		if(!argIsComposedParameter && !isProcessed){
			this.composedParameters = composeParameters();
			isProcessed = true;
		}
		return this.composedParameters;
	}
	
	public Map<String, String> getDecomposedParameters(){
		if(argIsComposedParameter && !isProcessed){
			this.decomposedParameters = this.decomposeParameters();
			this.isProcessed = true;
		}
		return this.decomposedParameters;
	}
}
