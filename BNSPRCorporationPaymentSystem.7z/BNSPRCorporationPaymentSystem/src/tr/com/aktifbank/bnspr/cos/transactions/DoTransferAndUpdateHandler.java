package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CorporationAccountDef;
import tr.com.aktifbank.bnspr.dao.CorporationDef;
import tr.com.aktifbank.bnspr.dao.CsDasTx;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.aktifbank.bnspr.dao.OrderTransfer;
import tr.com.aktifbank.bnspr.dao.OrderTransferLog;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public class DoTransferAndUpdateHandler extends RequestHandler {

	public DoTransferAndUpdateHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		OrderTransferLog transferLog = (OrderTransferLog) input.get(TransactionConstants.DoTransferAndUpdate.Input.TRANSFER_LOG_OBJECT);
		String transferTxNo = input.getString(TransactionConstants.DoTransferAndUpdate.Input.TRANSFER_TX_NO);
		String orderType = transferLog.getOrderType();
		
		OrderMain order = null;
		String newOrderTransferOid = null, errorMessage = null, islemTuru = null;
		boolean transferSuccessful = false;
		
		try {		
			insertCsDasTx(super.getHibernateSession(), transferLog, transferTxNo);
			
			if (orderType.equals(DatabaseConstants.OrderType.Havale) || orderType.equals(DatabaseConstants.OrderType.Virman))
				islemTuru = "HAVALE";
		    else if (orderType.equals(DatabaseConstants.OrderType.EFT))
		    	islemTuru = "EFT";
		    else if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale))
		    	islemTuru = "PTT";
			
			/*Procedure CS_DAS_ISLEM(pn_reference_id in number, ps_islem in varchar2, pn_fisno out number, pn_eft_sorguno out number)*/
			Object[] inputValues = new Object[] {BnsprType.NUMBER, new BigDecimal(transferTxNo), BnsprType.STRING, islemTuru};
			Object[] outputValues = new Object[] {BnsprType.NUMBER, TransactionConstants.OrderTransfersApproved.Output.FIS_NO, BnsprType.NUMBER, TransactionConstants.OrderTransfersApproved.Output.EFT_SORGU_NO};
			GMMap procedureOutputMap = (GMMap) DALUtil.callOracleProcedure("{call BNSPR.PKG_CS.CS_DAS_ISLEM(?,?,?,?)}", inputValues, outputValues);	
			
			BigDecimal fisNo = (BigDecimal) procedureOutputMap.get(TransactionConstants.OrderTransfersApproved.Output.FIS_NO);
			BigDecimal eftSorguNo = (BigDecimal) procedureOutputMap.get(TransactionConstants.OrderTransfersApproved.Output.EFT_SORGU_NO);
	
			transferLog.setTxNo(new BigDecimal(transferTxNo));
			transferLog.setOrderStatus(DatabaseConstants.OrderStatuses.Transfered);
			transferLog.setTransferDate(CommonHelper.getLongDateTimeString(new Date()));
			transferLog.setTransferAmount(transferLog.getAmount());
			transferLog.setEftSorguNo(eftSorguNo);
			transferLog.setFisNo(fisNo);					
			newOrderTransferOid = insertOrderTransfer(super.getHibernateSession(), transferLog);
			transferLog.setOrderTransferOid(newOrderTransferOid);
			super.getHibernateSession().update(transferLog);		
			
			order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("oid", transferLog.getOrderMainOid())).uniqueResult();
			if (order != null) {
				order.setTxNo(new BigDecimal(transferTxNo));
				order.setOrderStatus(DatabaseConstants.OrderStatuses.Transfered);
				order.setTransferDate(CommonHelper.getLongDateTimeString(new Date()));
				order.setTransferAmount(transferLog.getTransferAmount());
				order.setEftSorguNo(eftSorguNo);
				order.setFisNo(fisNo);	
			}			
			transferSuccessful = true;
			
		} catch (Throwable e) {
			String recipientAccountInfo = String.format("(Recipient bank: %s, Recipient IBAN: %s, Recipient branch: %s, Recipient account no: %s)", transferLog.getRecipientBank(), 
															  	transferLog.getRecipientIban(), transferLog.getRecipientBranch(), transferLog.getRecipientAccountNo());
			logger.error(String.format("An exception occured while doing %s transfer from account %s to %s, Amount: %s", islemTuru, transferLog.getPaymentAccountNo(), recipientAccountInfo, transferLog.getAmount()));
			logger.error(System.currentTimeMillis(), e);
			errorMessage = CommonHelper.getStringifiedException(e);
			
			if(errorMessage != null && errorMessage.length() > 1000){
				errorMessage = errorMessage.substring(0 ,950);
			}
			transferLog.setOrderStatus(DatabaseConstants.OrderStatuses.PaymentError);
			transferLog.setFailedPaymentDate(CommonHelper.getLongDateTimeString(new Date()));
			transferLog.setErrorDesc(errorMessage);
			super.getHibernateSession().update(transferLog);
			
			order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("oid", transferLog.getOrderMainOid())).uniqueResult();
			if (order != null) {
				order.setOrderStatus(DatabaseConstants.OrderStatuses.PaymentError);
				order.setFailedPaymentStatus(true);
				order.setErrorDesc(errorMessage);	
			}
			
		} finally {
			output.put(TransactionConstants.DoTransferAndUpdate.Output.IS_TRANSFER_SUCCESSFUL, transferSuccessful);
			super.getHibernateSession().flush();
		}
	}
	
	private void insertCsDasTx(Session hibernateSession, OrderTransferLog transferLog, String transactionNo) throws ParseException {	
		
		String defaultEftTransferType = "99", defaultHavaleTransferType = "99";
		Date recipientDateOfBirth = null;		
		
		String orderType = transferLog.getOrderType();						
		String transferType = transferLog.getTransferType();
		String recipientDateOfBirthStr = transferLog.getRecipientDateOfBirth();
		boolean isPaymentAccountDK = CommonHelper.isDKAccount(transferLog.getPaymentAccountNo(), transferLog.getCorporateCode());		
		
		if (recipientDateOfBirthStr != null)
			recipientDateOfBirth = CommonHelper.getDateTime(recipientDateOfBirthStr, "yyyyMMdd");

		if ( ( orderType.equals(DatabaseConstants.OrderType.Havale) || orderType.equals(DatabaseConstants.OrderType.Virman) ) && transferType == null )
			transferType = defaultHavaleTransferType;				
		else if ( orderType.equals(DatabaseConstants.OrderType.EFT) && transferType == null )	
			transferType = defaultEftTransferType;
	
		CsDasTx dasTx = new CsDasTx();
		dasTx.setReferenceId(new BigDecimal(transactionNo));
		dasTx.setProcessId(new BigDecimal("7210"));
		dasTx.setRcvrAccCode(transferLog.getRecipientAccountNo());
		dasTx.setAmount(transferLog.getAmount());
		dasTx.setAmountMt(transferLog.getCurrencyCode());
		dasTx.setVoucherDesc(transferLog.getExplanation());
		dasTx.setRcvrBankCode(transferLog.getRecipientBank());
		dasTx.setRcvrBranchCode(transferLog.getRecipientBranch());
		dasTx.setRcvrIbanNumber(transferLog.getRecipientIban());
		dasTx.setRcvrCardNumber(transferLog.getRecipientCcNo());
		dasTx.setRcvrFullName(transferLog.getRecipientName());
		dasTx.setRcvrAddress(transferLog.getRecipientAddress());
		dasTx.setRcvrPhoneNumber(transferLog.getRecipientPhoneNumber());
		dasTx.setRcvrFatherName(transferLog.getRecipientFatherName());
		dasTx.setRcvrMotherName(transferLog.getRecipientMotherName());
		dasTx.setRcvrBirthDate(recipientDateOfBirth);
		dasTx.setRcvrNationalId(transferLog.getRecipientTckn());
		dasTx.setRcvrTaxId(transferLog.getRecipientVkn());
		dasTx.setTransferType(transferType);
		dasTx.setDeductionAmount(new BigDecimal(0));
		dasTx.setDeductionAmountMt(transferLog.getCurrencyCode());
		dasTx.setDeductionAmountBsmv(new BigDecimal(0));
		dasTx.setSourceAccCustomerNo(transferLog.getCustomerNo());
		
		if (!isPaymentAccountDK) {
			dasTx.setSourceAccCode(transferLog.getPaymentAccountNo());
			if (transferLog.getPaymentCommissionAccountNo() != null)
				dasTx.setDeductionAccCode(transferLog.getPaymentCommissionAccountNo());
			else
				dasTx.setDeductionAccCode(transferLog.getPaymentAccountNo());					
		} else {
			dasTx.setGlAccCode(transferLog.getPaymentAccountNo().toString());
			dasTx.setGlAccBranchCode(getBranchCodeOfDKAccount(transferLog.getPaymentAccountNo(), transferLog.getCorporateCode()));
		}
		
		hibernateSession.save(dasTx);
		hibernateSession.flush();	
	}
	
	private static String insertOrderTransfer(Session hibernateSession, OrderTransferLog transferLog) {	
		OrderTransfer transfer = new OrderTransfer();
		transfer.setStatus(true);
		transfer.setCorporateCode(transferLog.getCorporateCode());
		transfer.setOrderMainOid(transferLog.getOrderMainOid());
		transfer.setRecipientName(transferLog.getRecipientName());
		transfer.setRecipientAddress(transferLog.getRecipientAddress());
		transfer.setRecipientFatherName(transferLog.getRecipientFatherName());
		transfer.setRecipientMotherName(transferLog.getRecipientMotherName());
		transfer.setRecipientBank(transferLog.getRecipientBank());
		transfer.setRecipientDateOfBirth(transferLog.getRecipientDateOfBirth());
		transfer.setRecipientEmail(transferLog.getRecipientEmail());
		transfer.setRecipientAccountNo(transferLog.getRecipientAccountNo());
		transfer.setRecipientIban(transferLog.getRecipientIban());
		transfer.setRecipientCcNo(transferLog.getRecipientCcNo());
		transfer.setRecipientRefNo(transferLog.getRecipientRefNo());
		transfer.setRecipientBranch(transferLog.getRecipientBranch());
		transfer.setRecipientTckn(transferLog.getRecipientTckn());
		transfer.setRecipientPhoneNumber(transferLog.getRecipientPhoneNumber());
		transfer.setRecipientVkn(transferLog.getRecipientVkn());
		transfer.setAccountNo(transferLog.getAccountNo());
		transfer.setExplanation(transferLog.getExplanation());
		transfer.setOrderStatus(DatabaseConstants.OrderStatuses.Transfered);
		transfer.setOrderType(transferLog.getOrderType());
		transfer.setTxNo(transferLog.getTxNo());
		transfer.setCommissionAccountNo(transferLog.getCommissionAccountNo());
		transfer.setCommissionAmount(transferLog.getCommissionAmount());
		transfer.setCustomerName(transferLog.getCustomerName());
		transfer.setCustomerNo(transferLog.getCustomerNo());
		transfer.setCurrencyCode(transferLog.getCurrencyCode());
		transfer.setTransferType(transferLog.getTransferType());
		transfer.setAmount(transferLog.getAmount());
		transfer.setTaxOffice(transferLog.getTaxOffice());		
		transfer.setTransferDate(transferLog.getTransferDate());
		transfer.setTransferAmount(transferLog.getTransferAmount());
		transfer.setOrderDate(transferLog.getOrderDate());
		transfer.setMainTxNo(transferLog.getMainTxNo());
		transfer.setEftSorguNo(transferLog.getEftSorguNo());
		transfer.setFisNo(transferLog.getFisNo());
		transfer.setPaymentAccountNo(transferLog.getPaymentAccountNo());
		transfer.setPaymentCommissionAccountNo(transferLog.getPaymentCommissionAccountNo());
		hibernateSession.save(transfer);	
		
		return transfer.getOid();
	}
	
	private String getBranchCodeOfDKAccount(BigDecimal accountNo, String corporateCode) {
		CorporationDef corp = (CorporationDef) super.getHibernateSession().createCriteria(CorporationDef.class)
				.add(Restrictions.eq("status", true))
				.add(Restrictions.eq("corporateCode", corporateCode))
				.uniqueResult();
		CorporationAccountDef acc = null;
		if (corp != null) 
			acc = (CorporationAccountDef) super.getHibernateSession().createCriteria(CorporationAccountDef.class)
			.add(Restrictions.eq("status", true))
			.add(Restrictions.eq("corporateOid", corp.getOid()))
			.add(Restrictions.eq("accountNo", accountNo))	
			.add(Restrictions.eq("isDkAccount", true))	
			.uniqueResult();
		if (acc != null && StringUtils.isNotEmpty(acc.getAccountBranch()))
			return acc.getAccountBranch().substring(0,3);
		else
			return "";
	}
}