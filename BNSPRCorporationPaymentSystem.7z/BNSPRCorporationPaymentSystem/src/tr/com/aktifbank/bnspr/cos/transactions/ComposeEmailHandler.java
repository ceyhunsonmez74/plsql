package tr.com.aktifbank.bnspr.cos.transactions;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.GeneralConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CariSubelerarasiHavGirisTx;
import tr.com.aktifbank.bnspr.dao.FileErrorLog;
import tr.com.aktifbank.bnspr.dao.FtmProcess;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public class ComposeEmailHandler extends RequestHandler {

	public ComposeEmailHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		logger.info("ComposeEmailHandler input Map : " + input.toString());
		
		String emailType = input.getString(TransactionConstants.ComposeEmail.Input.EMAIL_TYPE);
		String transferType = input.getString(TransactionConstants.ComposeEmail.Input.TRANSFER_TYPE);
		String corporateCode = input.getString(TransactionConstants.ComposeEmail.Input.CORPORATE_CODE);
		BigDecimal ftmSequenceNumber = input.getBigDecimal(TransactionConstants.CONFIRMATION_EMAIL_LOADING_FTM_SEQUENCE_NUMBER_GENERAL_KEY);
		String batchSubmitId = input.getString(TransactionConstants.CONFIRMATION_EMAIL_LOADING_SUBMIT_ID_GENERAL_KEY);
		String ftmId = input.getString(TransactionConstants.CONFIRMATION_EMAIL_LOADING_FTM_ID_GENERAL_KEY);
		String loadingDate = input.getString(TransactionConstants.ComposeEmail.Input.LOADING_DATE);
		Date processDate = input.getDate(TransactionConstants.ComposeEmail.Input.PROCESS_DATE);
		String fileStatus = input.getString(TransactionConstants.ComposeEmail.Input.FILE_STATUS);
		String headerOrderDate = input.getString(TransactionConstants.ComposeEmail.Input.HEADER_ORDER_DATE);
		String orderOid = input.getString(TransactionConstants.ComposeEmail.Input.ORDER_OID);
		if (!StringUtils.isEmpty(headerOrderDate))
			headerOrderDate = CommonHelper.shortTimeStringToViewDateString(headerOrderDate);
		String shortProcessDate = null;
		if (processDate != null)
			shortProcessDate = CommonHelper.getShortDateTimeString(processDate);
		else
			shortProcessDate = CommonHelper.getShortDateTimeString(new Date());
		String orderStatusText = null, orderTypeText = null, query = null, orderStatus = null, orderType = null, currencyCode = null, recipientBank = null, 
				recipientIban = null, recipientBranch = null, recipientAccountNo = null, amountText = null, loadingExplanation = null, recipientName = null,
				recipientTcknNo = null, recipientFatherName = null, recipientMotherName = null, pttReferansNo = null;
		String failureBodyPart = null, successBodyPart = null, fileName = null, introBodyPart = null, failureSummaryBodyPart = null, successSummaryBodyPart = null;
		String loadingDateDate = null, loadingDateTime = null, loadingDateStr = null, processDateDate = null, processDateTime = null, processDateStr = null;
		BigDecimal amount = null;
		int totalLineCount = 0, successfulLineCount = 0, failedLineCount = 0;
		BigDecimal successfulTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		BigDecimal successfulUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		BigDecimal successfulEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		int successfulTRYLineCount = 0, successfulUSDLineCount = 0, successfulEURLineCount = 0;
		BigDecimal failedTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		BigDecimal failedUSDAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		BigDecimal failedEURAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
		int failedTRYLineCount = 0, failedUSDLineCount = 0, failedEURLineCount = 0;		
		BigDecimal loadingFailureTotalLineCount = null, loadingFailureErroneousLineCount = null, errorLogLineNumber = null;
		String loadingFailureErrorDescription = null, errorLogErrorDesc = null, errorLogLine = null;
		
		List<String> receiverList = null;
		String receivers = null;
		StringBuilder message = new StringBuilder();
		final String messageFrom = "tahsilatprojesi-noreply@aktifbank.com.tr";
		String messageSubject = null;
				
		String htmlStart = "<html>", htmlEnd = "</html>", head = "<head></head>", bodyStart = "<body>", bodyEnd = "</body>";
		String codeStart = "<code>", codeEnd = "</code>";
		
		GMMap getCorpDefinitionMap = new GMMap();
		getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
		GMMap corpDefDetailsMap = super.callGraymoundServiceInSession(TransactionConstants.GetOrderCorpDef.SERVICE_NAME, getCorpDefinitionMap);
		String amountOrder = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING);
		String corporateShortName = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.SHORT_NAME);
		BigDecimal customerNo = corpDefDetailsMap.getBigDecimal(TransactionConstants.GetOrderCorpDef.Output.CUSTOMER_NO);
		boolean allowTransferToValid = corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.ALLOW_TRANSFER_TO_VALID);
		boolean emailReceiptToRecipients = corpDefDetailsMap.getBoolean(TransactionConstants.GetOrderCorpDef.Output.EMAIL_RECEIPT_TO_RECIPIENT);
		
		if (emailType.equals(DatabaseConstants.EmailType.LOADINGFAILURE) || emailType.equals(DatabaseConstants.EmailType.LOADINGCONFIRMATION))
			receivers = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.LOADING_EMAIL);
		else if (emailType.equals(DatabaseConstants.EmailType.PAYMENTSCONFIRMATION))
			receivers = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.TRANSFER_EMAIL);
		else if (emailType.equals(DatabaseConstants.EmailType.EODPAYMENTSCONFIRMATION))
			receivers = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.EOD_EMAIL);
		
		if (!StringUtils.isEmpty(receivers)) {
			receiverList = Arrays.asList(receivers.split("[,;]"));
			for (int i = 0; i < receiverList.size(); i++) {
				String receiverMail = receiverList.get(i).trim();
				receiverList.set(i, receiverMail);
			}
		}
		
		if (emailType.equals(DatabaseConstants.EmailType.LOADINGFAILURE)) {
			StringBuilder loadingFailureIntro = new StringBuilder();
			StringBuilder loadingFailureSummary = new StringBuilder();
			StringBuilder loadingFailureDetail = new StringBuilder();
			String loadingFailureDetailHeader = "<h4>Hata Alan Sat�rlar:</h4>\n";
			
			StringBuilder loadingFailureBody = new StringBuilder();		
			StringBuilder loadingFailureBodyDetailPart = new StringBuilder();
			loadingFailureBodyDetailPart.append(loadingFailureDetailHeader);
			
			loadingFailureIntro.append("<p>\n");
			loadingFailureIntro.append("Alacakl� dosyas� y�kleme i�lemi s�ras�nda y�kleme hatas� al�nd�.</br></br>\n");
			loadingFailureIntro.append("Okunan Dosya&nbsp;:&nbsp;%s</br>\n");
			loadingFailureIntro.append("Okuma Zaman�&nbsp;:&nbsp;%s</br>\n");
			loadingFailureIntro.append("</p>\n");
			loadingFailureIntro.append("<p>\n");
			loadingFailureIntro.append("Okunan Detay Kay�t Say�s�&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			loadingFailureIntro.append("Hata Alan Detay Kay�t Say�s�&nbsp;:&nbsp;%s</br>\n");
			loadingFailureIntro.append("</p>\n");
			
			loadingFailureSummary.append("<h4>HATA B�LG�LER�:</h4>\n");
			loadingFailureSummary.append("<p>\n");
			loadingFailureSummary.append("Hata A��klamas�&nbsp;:&nbsp;%s</br>\n");
			loadingFailureSummary.append("</p>\n");
			
			loadingFailureDetail.append("<p>\n");
			loadingFailureDetail.append("SATIR NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");						
			loadingFailureDetail.append("SATIR DETAYI&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingFailureDetail.append("HATA DETAYI&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingFailureDetail.append("</p>\n");
						
			OrderFileLog fileLog = (OrderFileLog) super.getHibernateSession().createCriteria(OrderFileLog.class)
												   .add(Restrictions.eq("status", true))
												   .add(Restrictions.eq("batchSubmitId", batchSubmitId)).uniqueResult();
			if (fileLog != null) {
				loadingFailureTotalLineCount = fileLog.getTotalLineCount();
				loadingFailureErroneousLineCount = fileLog.getErroneousLineCount();
				loadingFailureErrorDescription = fileLog.getErrorDesc();
			}
			
			if (loadingFailureErroneousLineCount.compareTo(new BigDecimal(0)) > 0 || StringUtils.isEmpty(loadingFailureErrorDescription)) {
				loadingFailureErrorDescription = "Detay sat�rlar�nda format hatas� al�nd�";
				
				List<FileErrorLog> loadingErrorList = super.getHibernateSession().createCriteria(FileErrorLog.class)
														.add(Restrictions.eq("status", true))
									  					.add(Restrictions.eq("batchSubmitId", batchSubmitId))
														.addOrder(Order.asc("lineNumber")).list();	
				for (FileErrorLog loadingError : loadingErrorList) {
					errorLogLineNumber = loadingError.getLineNumber();
					errorLogLine = loadingError.getErroneousLine().replace(" ", "&nbsp;");
					errorLogErrorDesc = loadingError.getErrorDesc();
					
					failureBodyPart = String.format(loadingFailureDetail.toString(),errorLogLineNumber.toString(),errorLogLine,errorLogErrorDesc);
					loadingFailureBodyDetailPart.append(failureBodyPart);
				}		
			}
			
			FtmProcess ftmProcess = (FtmProcess) super.getHibernateSession().createCriteria(FtmProcess.class)
												.add(Restrictions.eq("ftmFileDefinitionOid", new BigDecimal(ftmId)))
												.add(Restrictions.eq("oid", ftmSequenceNumber)).uniqueResult();
			if (ftmProcess != null)
				fileName = ftmProcess.getFileName();			
			
			if (!StringUtils.isEmpty(loadingDate)) {
				loadingDateDate = CommonHelper.longTimeStringToViewDateString(loadingDate);
				loadingDateTime = CommonHelper.longTimeStringToViewTimeString(loadingDate);
				loadingDateStr = String.format("%s %s", loadingDateDate, loadingDateTime);
			}

			introBodyPart = String.format(loadingFailureIntro.toString(),fileName,loadingDateStr,loadingFailureTotalLineCount,loadingFailureErroneousLineCount);
			failureSummaryBodyPart = String.format(loadingFailureSummary.toString(),loadingFailureErrorDescription);
			
			loadingFailureBody.append(introBodyPart);
			loadingFailureBody.append(failureSummaryBodyPart);
			if (loadingFailureErroneousLineCount.compareTo(new BigDecimal(0)) > 0 || StringUtils.isEmpty(loadingFailureErrorDescription))
				loadingFailureBody.append(loadingFailureBodyDetailPart);			
			
			message.append(htmlStart);
			message.append(head);			
			message.append(bodyStart);
			message.append(codeStart);
			message.append(loadingFailureBody.toString());
			message.append(codeEnd);
			message.append(bodyEnd);
			message.append(htmlEnd);				
			
			messageSubject = String.format("%s Bor� Bilgileri Y�kleme", corporateShortName);
			CommonHelper.sendMail(receiverList, null, messageFrom, true, messageSubject, message.toString(), true);
			
		} 
		else if (emailType.equals(DatabaseConstants.EmailType.LOADINGCONFIRMATION)) {
			StringBuilder loadingConfirmationIntro = new StringBuilder();
			StringBuilder loadingConfirmationSuccessSummary = new StringBuilder();
			StringBuilder loadingConfirmationFailureSummary = new StringBuilder();
			StringBuilder loadingConfirmationSuccessDetail = new StringBuilder();
			StringBuilder loadingConfirmationFailureDetail = new StringBuilder();
			StringBuilder loadingConfirmationPttHavaleSuccessDetail = new StringBuilder();
			StringBuilder loadingConfirmationPttHavaleFailureDetail = new StringBuilder();
			String loadingConfirmationSuccessDetailHeader = "<h4>�DEMES� GER�EKLE�ECEK KAYITLAR:</h4>\n";
			String loadingConfirmationFailureDetailHeader = "<h4>�DEMES� GER�EKLE�MEYECEK KAYITLAR:</h4>\n";
			String someLinesFailedExplanation = "��kar�lan kay�tlar mevcut";
			String noLoadingExplanation = "Hatal� kay�tlar oldu�u i�in dosya y�klenememi�tir";
			String successExplanation = "Dosya ba�ar�l� bir �ekilde y�klenmi�tir";
			
			StringBuilder loadingConfirmationBody = new StringBuilder();
			StringBuilder loadingConfirmationBodySuccessPart = new StringBuilder();
			StringBuilder loadingConfirmationBodyFailurePart = new StringBuilder();
			loadingConfirmationBodySuccessPart.append(loadingConfirmationSuccessDetailHeader);
			loadingConfirmationBodyFailurePart.append(loadingConfirmationFailureDetailHeader);
			
			loadingConfirmationIntro.append("<p>\n");
			loadingConfirmationIntro.append("Alacakl� dosyas� y�kleme i�lemi tamamland�.</br>\n");
			loadingConfirmationIntro.append("Okunan Dosya&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationIntro.append("Okuma Zaman�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationIntro.append("A��klama&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationIntro.append("</p>\n");
			loadingConfirmationIntro.append("<p>Y�klenen Kay�t Say�s�&nbsp;:&nbsp;%s</br></p>\n");
			
			loadingConfirmationSuccessSummary.append("<p>Toplam Ba�ar�l� Kay�t Say�s�&nbsp;:&nbsp;%s</br></p>\n");
			loadingConfirmationSuccessSummary.append("<p>\n");
			loadingConfirmationSuccessSummary.append("TRY Ba�ar�l� Kay�t Say�s�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessSummary.append("USD Ba�ar�l� Kay�t Say�s�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessSummary.append("EUR Ba�ar�l� Kay�t Say�s�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessSummary.append("</p>\n");
			loadingConfirmationSuccessSummary.append("<p>\n");
			loadingConfirmationSuccessSummary.append("TRY Ba�ar�l� Kay�t Tutar�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessSummary.append("USD Ba�ar�l� Kay�t Tutar�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessSummary.append("EUR Ba�ar�l� Kay�t Tutar�&nbsp;:&nbsp;%s</br>\n");	
			loadingConfirmationSuccessSummary.append("</p>\n");
			
			loadingConfirmationFailureSummary.append("<p>Toplam Ba�ar�s�z Kay�t Say�s�&nbsp;:&nbsp;%s</br></p>\n");
			loadingConfirmationFailureSummary.append("<p>\n");
			loadingConfirmationFailureSummary.append("TRY Ba�ar�s�z Kay�t Say�s�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureSummary.append("USD Ba�ar�s�z Kay�t Say�s�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureSummary.append("EUR Ba�ar�s�z Kay�t Say�s�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureSummary.append("</p>\n");
			loadingConfirmationFailureSummary.append("<p>\n");
			loadingConfirmationFailureSummary.append("TRY Ba�ar�s�z Kay�t Tutar�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureSummary.append("USD Ba�ar�s�z Kay�t Tutar�&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureSummary.append("EUR Ba�ar�s�z Kay�t Tutar�&nbsp;:&nbsp;%s</br>\n");		
			loadingConfirmationFailureSummary.append("</p>\n");
						
			loadingConfirmationSuccessDetail.append("<p>\n");
			loadingConfirmationSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI BANKA KODU&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;��LEM T�R�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;IBAN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�UBE KODU&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;HESAP NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�DEME TUTARI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�DEME TAR�H�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");		
			loadingConfirmationSuccessDetail.append("</p>\n");
			
			loadingConfirmationFailureDetail.append("<p>\n");
			loadingConfirmationFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI BANKA KODU&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;��LEM T�R�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;IBAN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�UBE KODU&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;HESAP NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�DEME TUTARI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�DEME TAR�H�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			loadingConfirmationFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;HATA SEBEB�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationFailureDetail.append("</p>\n");			
			
			loadingConfirmationPttHavaleSuccessDetail.append("<p>\n");
			loadingConfirmationPttHavaleSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI BANKA KODU&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;��LEM T�R�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			loadingConfirmationPttHavaleSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI �S�M/�NVAN&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;TCKN NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI BABA ADI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			loadingConfirmationPttHavaleSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI ANNE ADI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�DEME TUTARI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleSuccessDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�DEME TAR�H�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");		
			loadingConfirmationPttHavaleSuccessDetail.append("</p>\n");
						
			loadingConfirmationPttHavaleFailureDetail.append("<p>\n");
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI BANKA KODU&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;��LEM T�R�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI �S�M/�NVAN&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;TCKN NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI BABA ADI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;ALACAKLI ANNE ADI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�DEME TUTARI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;�DEME TAR�H�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			loadingConfirmationPttHavaleFailureDetail.append("&nbsp;&nbsp;&nbsp;&nbsp;HATA SEBEB�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			loadingConfirmationPttHavaleFailureDetail.append("</p>\n");
			
			logger.info("Batch submit id : " + batchSubmitId);
			logger.info("Ftm sequence number : " + ftmSequenceNumber.toString());
			logger.info("Amount order : " + amountOrder);
			
			Criteria criteria = super.getHibernateSession().createCriteria(OrderMain.class)
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("ftmSequenceNumber", ftmSequenceNumber))
									.add(Restrictions.eq("batchSubmitId", batchSubmitId));
			
			if (StringUtils.isNotBlank(amountOrder)) {				
				if (amountOrder.equals("D"))
					criteria = criteria.addOrder(Order.desc("amount"));
				else if (amountOrder.equals("A"))
					criteria = criteria.addOrder(Order.asc("amount"));
			} else 
				criteria = criteria.addOrder(Order.asc("lineNumber"));

			List<OrderMain> orderList = criteria.list();			
			logger.info("orderList.size() : " + orderList.size());
			
			for (OrderMain order : orderList) {
				orderStatus = order.getOrderStatus();
				orderType = order.getOrderType();
				currencyCode = order.getCurrencyCode();
				amount = order.getAmount();
				if (amount != null)
					amount = order.getAmount().setScale(2, RoundingMode.HALF_UP);
				recipientBank = order.getRecipientBank();
				recipientIban = order.getRecipientIban();
				recipientBranch = order.getRecipientBranch();
				recipientAccountNo = order.getRecipientAccountNo();
				recipientName = order.getRecipientName();
				recipientTcknNo = order.getRecipientTckn();
				recipientFatherName = order.getRecipientFatherName();
				recipientMotherName = order.getRecipientMotherName();				
								
				query = QueryRepository.ComposeEmailHandlerRepository.COS_ORDER_STATUS_PARAM_TEXT_QUERY;
				orderStatusText = DALUtil.getResult(String.format(query, orderStatus));
				query = QueryRepository.ComposeEmailHandlerRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
				orderTypeText = DALUtil.getResult(String.format(query, orderType));			
				
				if (!StringUtils.isEmpty(orderType) && !orderType.equals(DatabaseConstants.OrderType.EFT) && !orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale) && StringUtils.isEmpty(recipientIban))
					recipientIban = getIbanOfAccount(new BigDecimal(recipientAccountNo));
				if (StringUtils.isEmpty(recipientIban))
					recipientIban = "";
				if (StringUtils.isEmpty(recipientBank))
					recipientBank = "";				
				if (StringUtils.isEmpty(recipientBranch))
					recipientBranch = "";
				if (StringUtils.isEmpty(recipientAccountNo))
					recipientAccountNo = "";				
				if (StringUtils.isEmpty(recipientName))
					recipientName = "";
				if (StringUtils.isEmpty(recipientTcknNo))
					recipientTcknNo = "";				
				if (StringUtils.isEmpty(recipientFatherName))
					recipientFatherName = "";
				if (StringUtils.isEmpty(recipientMotherName))
					recipientMotherName = "";					
								
				if ( !orderStatus.equals(DatabaseConstants.OrderStatuses.Waiting) && !orderStatus.equals(DatabaseConstants.OrderStatuses.RepeatedOrder) ) {
					
					if (!StringUtils.isEmpty(currencyCode) && amount != null) {
						if (currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
							failedTRYAmount = failedTRYAmount.add(amount);
							failedTRYLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.TRY);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.USD)) {
							failedUSDAmount = failedUSDAmount.add(amount);
							failedUSDLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.USD);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR)) {
							failedEURAmount = failedEURAmount.add(amount);
							failedEURLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.EUR);
						}
					}
					if (!StringUtils.isEmpty(orderType) && orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale))
						failureBodyPart = String.format(loadingConfirmationPttHavaleFailureDetail.toString(),recipientBank,orderTypeText,recipientName,recipientTcknNo,recipientFatherName,recipientMotherName,amountText,headerOrderDate,orderStatusText);
					else
						failureBodyPart = String.format(loadingConfirmationFailureDetail.toString(),recipientBank,orderTypeText,recipientIban,recipientBranch,recipientAccountNo,amountText,headerOrderDate,orderStatusText);
					loadingConfirmationBodyFailurePart.append(failureBodyPart);
					failedLineCount++;
				} else {
					if (!StringUtils.isEmpty(currencyCode) && amount != null) {
						if (currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
							successfulTRYAmount = successfulTRYAmount.add(amount);
							successfulTRYLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.TRY);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.USD)) {
							successfulUSDAmount = successfulUSDAmount.add(amount);
							successfulUSDLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.USD);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR)) {
							successfulEURAmount = successfulEURAmount.add(amount);
							successfulEURLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.EUR);
						}
					}
					if (!StringUtils.isEmpty(orderType) && orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale))
						successBodyPart = String.format(loadingConfirmationPttHavaleSuccessDetail.toString(),recipientBank,orderTypeText,recipientName,recipientTcknNo,recipientFatherName,recipientMotherName,amountText,headerOrderDate);
					else	
						successBodyPart = String.format(loadingConfirmationSuccessDetail.toString(),recipientBank,orderTypeText,recipientIban,recipientBranch,recipientAccountNo,amountText,headerOrderDate);
					loadingConfirmationBodySuccessPart.append(successBodyPart);
					successfulLineCount++;
				}
				totalLineCount++;
			}
			
			FtmProcess ftmProcess = (FtmProcess) super.getHibernateSession().createCriteria(FtmProcess.class)
												.add(Restrictions.eq("ftmFileDefinitionOid", new BigDecimal(ftmId)))
												.add(Restrictions.eq("oid", ftmSequenceNumber)).uniqueResult();
			if (ftmProcess != null)
				fileName = ftmProcess.getFileName();			
			
			if (!StringUtils.isEmpty(loadingDate)) {
				loadingDateDate = CommonHelper.longTimeStringToViewDateString(loadingDate);
				loadingDateTime = CommonHelper.longTimeStringToViewTimeString(loadingDate);
				loadingDateStr = String.format("%s %s", loadingDateDate, loadingDateTime);
			}
			
			if (fileStatus.equals(DatabaseConstants.FileStatuses.CONTROLSFAILED) || (!allowTransferToValid && fileStatus.equals(DatabaseConstants.FileStatuses.SOMEOFTHELINESFAILED)))
				loadingExplanation = noLoadingExplanation;
			else if (allowTransferToValid && fileStatus.equals(DatabaseConstants.FileStatuses.SOMEOFTHELINESFAILED))
				loadingExplanation = someLinesFailedExplanation;
			else
				loadingExplanation = successExplanation;
				
			introBodyPart = String.format(loadingConfirmationIntro.toString(),fileName,loadingDateStr,loadingExplanation,totalLineCount);
			successSummaryBodyPart = String.format(loadingConfirmationSuccessSummary.toString(),successfulLineCount,successfulTRYLineCount,successfulUSDLineCount,successfulEURLineCount,
													String.format("%s %s", successfulTRYAmount.toString(), DatabaseConstants.CurrencyCodes.TRY),
													String.format("%s %s", successfulUSDAmount.toString(), DatabaseConstants.CurrencyCodes.USD),
													String.format("%s %s", successfulEURAmount.toString(), DatabaseConstants.CurrencyCodes.EUR));
			failureSummaryBodyPart = String.format(loadingConfirmationFailureSummary.toString(),failedLineCount,failedTRYLineCount,failedUSDLineCount,failedEURLineCount,
													String.format("%s %s", failedTRYAmount.toString(), DatabaseConstants.CurrencyCodes.TRY),
													String.format("%s %s", failedUSDAmount.toString(), DatabaseConstants.CurrencyCodes.USD),
													String.format("%s %s", failedEURAmount.toString(), DatabaseConstants.CurrencyCodes.EUR));				
			
			loadingConfirmationBody.append(introBodyPart);
			loadingConfirmationBody.append(successSummaryBodyPart);
			loadingConfirmationBody.append(failureSummaryBodyPart);
			if (successfulLineCount > 0)
				loadingConfirmationBody.append(loadingConfirmationBodySuccessPart);
			if (failedLineCount > 0)
				loadingConfirmationBody.append(loadingConfirmationBodyFailurePart);
			
			message.append(htmlStart);
			message.append(head);			
			message.append(bodyStart);
			message.append(codeStart);
			message.append(loadingConfirmationBody.toString());
			message.append(codeEnd);
			message.append(bodyEnd);
			message.append(htmlEnd);				
			
			messageSubject = String.format("%s Bor� Bilgileri Y�kleme", corporateShortName);
			CommonHelper.sendMail(receiverList, null, messageFrom, true, messageSubject, message.toString(), true);
						
		} 
		else if (emailType.equals(DatabaseConstants.EmailType.PAYMENTSCONFIRMATION)) {
						
			StringBuilder paymentConfirmationIntro = new StringBuilder();
			StringBuilder paymentConfirmationSuccessSummary = new StringBuilder();
			StringBuilder paymentConfirmationFailureSummary = new StringBuilder();
			StringBuilder paymentConfirmationFailureDetail = new StringBuilder();
			StringBuilder paymentConfirmationPttHavaleFailureDetail = new StringBuilder();
			String paymentConfirmationFailureDetailHeader = "<h4>�DEMES� ALINAMAYAN TAL�MATLAR:</h4>\n";
			
			StringBuilder paymentConfirmationBody = new StringBuilder();
			StringBuilder paymentConfirmationBodyFailurePart = new StringBuilder();
			paymentConfirmationBodyFailurePart.append(paymentConfirmationFailureDetailHeader);
			
			paymentConfirmationIntro.append("<p>\n");
			paymentConfirmationIntro.append("��lenen Tarih&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationIntro.append("Batch �al��ma Tarihi&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationIntro.append("</p>\n");
			
			paymentConfirmationSuccessSummary.append("<p>Toplam Ba�ar�l� Transfer Say�s�&nbsp;:&nbsp;%s</br></p>\n");
			paymentConfirmationSuccessSummary.append("<p>\n");
			paymentConfirmationSuccessSummary.append("TRY Ba�ar�l� Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("USD Ba�ar�l� Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("EUR Ba�ar�l� Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("</p>\n");
			paymentConfirmationSuccessSummary.append("<p>\n");
			paymentConfirmationSuccessSummary.append("TRY Ba�ar�l� Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("USD Ba�ar�l� Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("EUR Ba�ar�l� Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");	
			paymentConfirmationSuccessSummary.append("</p>\n");
			
			paymentConfirmationFailureSummary.append("<p>Toplam Ba�ar�s�z Transfer Say�s�&nbsp;:&nbsp;%s</br></p>\n");
			paymentConfirmationFailureSummary.append("<p>\n");
			paymentConfirmationFailureSummary.append("TRY Ba�ar�s�z Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("USD Ba�ar�s�z Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("EUR Ba�ar�s�z Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("</p>\n");
			paymentConfirmationFailureSummary.append("<p>\n");
			paymentConfirmationFailureSummary.append("TRY Ba�ar�s�z Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("USD Ba�ar�s�z Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("EUR Ba�ar�s�z Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");		
			paymentConfirmationFailureSummary.append("</p>\n");
			
			paymentConfirmationFailureDetail.append("<p>\n");
			paymentConfirmationFailureDetail.append("F�RMA KODU&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("F�RMA ADI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("F�RMA M��TER� NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("�DEME TUTARI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("�DEME TAR�H�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("ALACAKLI BANKA KODU&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("��LEM T�R�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("ALACAKLI IBAN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("ALACAKLI �UBE KODU&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("ALACAKLI HESAP KODU&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("�DENMEME SEBEB�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("</p>\n");
			
			paymentConfirmationPttHavaleFailureDetail.append("<p>\n");
			paymentConfirmationPttHavaleFailureDetail.append("F�RMA KODU&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("F�RMA ADI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("F�RMA M��TER� NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("�DEME TUTARI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("�DEME TAR�H�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("ALACAKLI BANKA KODU&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("��LEM T�R�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			paymentConfirmationPttHavaleFailureDetail.append("ALACAKLI �S�M/�NVAN&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("TCKN NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("ALACAKLI BABA ADI&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("ALACAKLI ANNE ADI&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			paymentConfirmationPttHavaleFailureDetail.append("�DENMEME SEBEB�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("</p>\n");
			
			// onay sonras� b�t�n y�kleme hatas� stat�s�nde olmayan kay�tlar dikkate al�nacak			
			// toplu �deme batch'i sadece yetersiz bakiye gibi �deme hatas� alan kay�tlar�n durumu g�z �n�ne almal� 
		
			Criteria criteria = super.getHibernateSession().createCriteria(OrderMain.class)
										.add(Restrictions.eq("status", true))
										.add(Restrictions.eq("ftmSequenceNumber", ftmSequenceNumber))
										.add(Restrictions.eq("batchSubmitId", batchSubmitId));
			
			if (transferType.equals(GeneralConstants.APPROVALTRANSFER))
				criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.Waiting));
			else if (transferType.equals(GeneralConstants.FAILEDPAYMENTTRANSFER))
				criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.InsufficientBalance))
				   				   .add(Restrictions.eq("failedPaymentStatus", true));					
				
			if (StringUtils.isNotBlank(amountOrder)) {				
				if (amountOrder.equals("D"))
					criteria = criteria.addOrder(Order.desc("amount"));
				else if (amountOrder.equals("A"))
					criteria = criteria.addOrder(Order.asc("amount"));
			} else 
				criteria = criteria.addOrder(Order.asc("lineNumber"));
			
			List<OrderMain> orderList = criteria.list();
			
			for (OrderMain order : orderList) {
				orderStatus = order.getOrderStatus();
				orderType = order.getOrderType();
				currencyCode = order.getCurrencyCode();
				amount = order.getAmount();
				if (amount != null)
					amount = order.getAmount().setScale(2, RoundingMode.HALF_UP);
				recipientBank = order.getRecipientBank();
				recipientIban = order.getRecipientIban();
				recipientBranch = order.getRecipientBranch();
				recipientAccountNo = order.getRecipientAccountNo();
				recipientName = order.getRecipientName();
				recipientTcknNo = order.getRecipientTckn();
				recipientFatherName = order.getRecipientFatherName();
				recipientMotherName = order.getRecipientMotherName();	
								
				query = QueryRepository.ComposeEmailHandlerRepository.COS_ORDER_STATUS_PARAM_TEXT_QUERY;
				orderStatusText = DALUtil.getResult(String.format(query, orderStatus));
				query = QueryRepository.ComposeEmailHandlerRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
				orderTypeText = DALUtil.getResult(String.format(query, orderType));			
				
				if (!StringUtils.isEmpty(orderType) && !orderType.equals(DatabaseConstants.OrderType.EFT) && !orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale) && StringUtils.isEmpty(recipientIban))
					recipientIban = getIbanOfAccount(new BigDecimal(recipientAccountNo));
				if (StringUtils.isEmpty(recipientIban))
					recipientIban = "";
				if (StringUtils.isEmpty(recipientBank))
					recipientBank = "";				
				if (StringUtils.isEmpty(recipientBranch))
					recipientBranch = "";
				if (StringUtils.isEmpty(recipientAccountNo))
					recipientAccountNo = "";		
				if (StringUtils.isEmpty(recipientName))
					recipientName = "";
				if (StringUtils.isEmpty(recipientTcknNo))
					recipientTcknNo = "";				
				if (StringUtils.isEmpty(recipientFatherName))
					recipientFatherName = "";
				if (StringUtils.isEmpty(recipientMotherName))
					recipientMotherName = "";						
				
				if (orderStatus.equals(DatabaseConstants.OrderStatuses.Transfered)) {
					
					if (!StringUtils.isEmpty(currencyCode) && amount != null) {
						if (currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
							successfulTRYAmount = successfulTRYAmount.add(amount);
							successfulTRYLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.TRY);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.USD)) {
							successfulUSDAmount = successfulUSDAmount.add(amount);
							successfulUSDLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.USD);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR)) {
							successfulEURAmount = successfulEURAmount.add(amount);
							successfulEURLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.EUR);
						}
					}								
					successfulLineCount++;
				} else {
					if (!StringUtils.isEmpty(currencyCode) && amount != null) {
						if (currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
							failedTRYAmount = failedTRYAmount.add(amount);
							failedTRYLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.TRY);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.USD)) {
							failedUSDAmount = failedUSDAmount.add(amount);
							failedUSDLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.USD);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR)) {
							failedEURAmount = failedEURAmount.add(amount);
							failedEURLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.EUR);
						}
					}						
					if (!StringUtils.isEmpty(orderType) && orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale))
						failureBodyPart = String.format(paymentConfirmationPttHavaleFailureDetail.toString(),corporateCode,corporateShortName,customerNo,amountText,headerOrderDate,recipientBank,orderTypeText,recipientName,recipientTcknNo,recipientFatherName,recipientMotherName,orderStatusText);
					else
						failureBodyPart = String.format(paymentConfirmationFailureDetail.toString(),corporateCode,corporateShortName,customerNo,amountText,headerOrderDate,recipientBank,orderTypeText,recipientIban,recipientBranch,recipientAccountNo,orderStatusText);
					paymentConfirmationBodyFailurePart.append(failureBodyPart);
					failedLineCount++;
				}
				totalLineCount++;
			}			
			
			if (processDate != null) {
				try {
					processDateDate = CommonHelper.longTimeStringToViewDateString(CommonHelper.getLongDateTimeString(processDate));
					processDateTime = CommonHelper.longTimeStringToViewTimeString(CommonHelper.getLongDateTimeString(processDate));
					processDateStr = processDateDate.concat(" ").concat(processDateTime);
				}
				catch(Exception e) {
					
				}
			}
			
			introBodyPart = String.format(paymentConfirmationIntro.toString(),headerOrderDate,processDateStr);
			successSummaryBodyPart = String.format(paymentConfirmationSuccessSummary.toString(),successfulLineCount,successfulTRYLineCount,successfulUSDLineCount,successfulEURLineCount,
													String.format("%s %s", successfulTRYAmount.toString(), DatabaseConstants.CurrencyCodes.TRY),
													String.format("%s %s", successfulUSDAmount.toString(), DatabaseConstants.CurrencyCodes.USD),
													String.format("%s %s", successfulEURAmount.toString(), DatabaseConstants.CurrencyCodes.EUR));
			failureSummaryBodyPart = String.format(paymentConfirmationFailureSummary.toString(),failedLineCount,failedTRYLineCount,failedUSDLineCount,failedEURLineCount,
													String.format("%s %s", failedTRYAmount.toString(), DatabaseConstants.CurrencyCodes.TRY),
													String.format("%s %s", failedUSDAmount.toString(), DatabaseConstants.CurrencyCodes.USD),
													String.format("%s %s", failedEURAmount.toString(), DatabaseConstants.CurrencyCodes.EUR));		
			
			paymentConfirmationBody.append(introBodyPart);
			paymentConfirmationBody.append(successSummaryBodyPart);
			paymentConfirmationBody.append(failureSummaryBodyPart);
			if (failedLineCount > 0)
				paymentConfirmationBody.append(paymentConfirmationBodyFailurePart);
			
			message.append(htmlStart);
			message.append(head);			
			message.append(bodyStart);
			message.append(codeStart);
			message.append(paymentConfirmationBody.toString());
			message.append(codeEnd);
			message.append(bodyEnd);
			message.append(htmlEnd);
					
			messageSubject = String.format("%s Toplu �deme Transferleri", corporateShortName);
			CommonHelper.sendMail(receiverList, null, messageFrom, true, messageSubject, message.toString(), true);
			
		} else if (emailType.equals(DatabaseConstants.EmailType.EODPAYMENTSCONFIRMATION)) {
			
			
			StringBuilder paymentConfirmationIntro = new StringBuilder();
			StringBuilder paymentConfirmationSuccessSummary = new StringBuilder();
			StringBuilder paymentConfirmationFailureSummary = new StringBuilder();
			StringBuilder paymentConfirmationFailureDetail = new StringBuilder();
			StringBuilder paymentConfirmationPttHavaleFailureDetail = new StringBuilder();
			String paymentConfirmationFailureDetailHeader = "<h4>�DEMES� ALINAMAYAN TAL�MATLAR:</h4>\n";
			
			StringBuilder paymentConfirmationBody = new StringBuilder();
			StringBuilder paymentConfirmationBodyFailurePart = new StringBuilder();
			paymentConfirmationBodyFailurePart.append(paymentConfirmationFailureDetailHeader);
			
			paymentConfirmationIntro.append("<p>\n");
			paymentConfirmationIntro.append("��lenen Tarih&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationIntro.append("Batch �al��ma Tarihi&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationIntro.append("</p>\n");
			
			paymentConfirmationSuccessSummary.append("<p>Toplam Ba�ar�l� Transfer Say�s�&nbsp;:&nbsp;%s</br></p>\n");
			paymentConfirmationSuccessSummary.append("<p>\n");
			paymentConfirmationSuccessSummary.append("TRY Ba�ar�l� Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("USD Ba�ar�l� Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("EUR Ba�ar�l� Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("</p>\n");
			paymentConfirmationSuccessSummary.append("<p>\n");
			paymentConfirmationSuccessSummary.append("TRY Ba�ar�l� Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("USD Ba�ar�l� Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationSuccessSummary.append("EUR Ba�ar�l� Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");	
			paymentConfirmationSuccessSummary.append("</p>\n");
			
			paymentConfirmationFailureSummary.append("<p>Toplam Ba�ar�s�z Transfer Say�s�&nbsp;:&nbsp;%s</br></p>\n");
			paymentConfirmationFailureSummary.append("<p>\n");
			paymentConfirmationFailureSummary.append("TRY Ba�ar�s�z Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("USD Ba�ar�s�z Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("EUR Ba�ar�s�z Transfer Say�s�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("</p>\n");
			paymentConfirmationFailureSummary.append("<p>\n");
			paymentConfirmationFailureSummary.append("TRY Ba�ar�s�z Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("USD Ba�ar�s�z Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureSummary.append("EUR Ba�ar�s�z Transfer Tutar�&nbsp;:&nbsp;%s</br>\n");		
			paymentConfirmationFailureSummary.append("</p>\n");
			
			paymentConfirmationFailureDetail.append("<p>\n");
			paymentConfirmationFailureDetail.append("F�RMA KODU&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("F�RMA ADI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("F�RMA M��TER� NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("�DEME TUTARI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("�DEME TAR�H�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("ALACAKLI BANKA KODU&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("��LEM T�R�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("ALACAKLI IBAN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("ALACAKLI �UBE KODU&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("ALACAKLI HESAP KODU&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("�DENMEME SEBEB�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationFailureDetail.append("</p>\n");
			
			paymentConfirmationPttHavaleFailureDetail.append("<p>\n");
			paymentConfirmationPttHavaleFailureDetail.append("F�RMA KODU&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("F�RMA ADI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("F�RMA M��TER� NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("�DEME TUTARI&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("�DEME TAR�H�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("ALACAKLI BANKA KODU&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("��LEM T�R�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			paymentConfirmationPttHavaleFailureDetail.append("ALACAKLI �S�M/�NVAN&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("TCKN NO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("ALACAKLI BABA ADI&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("ALACAKLI ANNE ADI&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");			
			paymentConfirmationPttHavaleFailureDetail.append("�DENMEME SEBEB�&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;%s</br>\n");
			paymentConfirmationPttHavaleFailureDetail.append("</p>\n");
			
			Criteria criteria = super.getHibernateSession().createCriteria(OrderMain.class)
										.add(Restrictions.eq("status", true))
										.add(Restrictions.between("loadingDate", shortProcessDate + "000000", shortProcessDate + "235959"))
										.add(Restrictions.eq("corporateCode", corporateCode))
										.addOrder(Order.desc("loadingDate"))
										.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.Waiting));			

			if (StringUtils.isNotBlank(amountOrder)) {				
				if (amountOrder.equals("D"))
					criteria = criteria.addOrder(Order.desc("amount"));
				else if (amountOrder.equals("A"))
					criteria = criteria.addOrder(Order.asc("amount"));
			} else 
				criteria = criteria.addOrder(Order.asc("lineNumber"));
			
			List<OrderMain> orderList = criteria.list();
			
			for (OrderMain order : orderList) {
				orderStatus = order.getOrderStatus();
				orderType = order.getOrderType();
				currencyCode = order.getCurrencyCode();
				amount = order.getAmount();
				if (amount != null)
					amount = order.getAmount().setScale(2, RoundingMode.HALF_UP);
				recipientBank = order.getRecipientBank();
				recipientIban = order.getRecipientIban();
				recipientBranch = order.getRecipientBranch();
				recipientAccountNo = order.getRecipientAccountNo();
				recipientName = order.getRecipientName();
				recipientTcknNo = order.getRecipientTckn();
				recipientFatherName = order.getRecipientFatherName();
				recipientMotherName = order.getRecipientMotherName();	
								
				query = QueryRepository.ComposeEmailHandlerRepository.COS_ORDER_STATUS_PARAM_TEXT_QUERY;
				orderStatusText = DALUtil.getResult(String.format(query, orderStatus));
				query = QueryRepository.ComposeEmailHandlerRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
				orderTypeText = DALUtil.getResult(String.format(query, orderType));			
				
				if (!StringUtils.isEmpty(orderType) && !orderType.equals(DatabaseConstants.OrderType.EFT) && !orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale) && StringUtils.isEmpty(recipientIban))
					recipientIban = getIbanOfAccount(new BigDecimal(recipientAccountNo));
				if (StringUtils.isEmpty(recipientIban))
					recipientIban = "";
				if (StringUtils.isEmpty(recipientBank))
					recipientBank = "";				
				if (StringUtils.isEmpty(recipientBranch))
					recipientBranch = "";
				if (StringUtils.isEmpty(recipientAccountNo))
					recipientAccountNo = "";	
				if (StringUtils.isEmpty(recipientName))
					recipientName = "";
				if (StringUtils.isEmpty(recipientTcknNo))
					recipientTcknNo = "";				
				if (StringUtils.isEmpty(recipientFatherName))
					recipientFatherName = "";
				if (StringUtils.isEmpty(recipientMotherName))
					recipientMotherName = "";					
				
				if (orderStatus.equals(DatabaseConstants.OrderStatuses.Transfered)) {
					
					if (!StringUtils.isEmpty(currencyCode) && amount != null) {
						if (currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
							successfulTRYAmount = successfulTRYAmount.add(amount);
							successfulTRYLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.TRY);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.USD)) {
							successfulUSDAmount = successfulUSDAmount.add(amount);
							successfulUSDLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.USD);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR)) {
							successfulEURAmount = successfulEURAmount.add(amount);
							successfulEURLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.EUR);
						}
					}								
					successfulLineCount++;
				} else {
					if (!StringUtils.isEmpty(currencyCode) && amount != null) {
						if (currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY)) {
							failedTRYAmount = failedTRYAmount.add(amount);
							failedTRYLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.TRY);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.USD)) {
							failedUSDAmount = failedUSDAmount.add(amount);
							failedUSDLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.USD);
						}
						else if (currencyCode.equals(DatabaseConstants.CurrencyCodes.EUR)) {
							failedEURAmount = failedEURAmount.add(amount);
							failedEURLineCount++;
							amountText = String.format("%s %s", amount.toString(), DatabaseConstants.CurrencyCodes.EUR);
						}
					}								
					if (!StringUtils.isEmpty(orderType) && orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale))
						failureBodyPart = String.format(paymentConfirmationPttHavaleFailureDetail.toString(),corporateCode,corporateShortName,customerNo,amountText,headerOrderDate,recipientBank,orderTypeText,recipientName,recipientTcknNo,recipientFatherName,recipientMotherName,orderStatusText);
					else
						failureBodyPart = String.format(paymentConfirmationFailureDetail.toString(),corporateCode,corporateShortName,customerNo,amountText,headerOrderDate,recipientBank,orderTypeText,recipientIban,recipientBranch,recipientAccountNo,orderStatusText);
					paymentConfirmationBodyFailurePart.append(failureBodyPart);
					failedLineCount++;
				}
				totalLineCount++;
			}			
			
			if (processDate != null) {
				try {
					processDateDate = CommonHelper.longTimeStringToViewDateString(CommonHelper.getLongDateTimeString(processDate));
					processDateTime = CommonHelper.longTimeStringToViewTimeString(CommonHelper.getLongDateTimeString(processDate));
					processDateStr = processDateDate.concat(" ").concat(processDateTime);
				}
				catch(Exception e) {
					
				}
			}
			
			introBodyPart = String.format(paymentConfirmationIntro.toString(),"",processDateStr);
			successSummaryBodyPart = String.format(paymentConfirmationSuccessSummary.toString(),successfulLineCount,successfulTRYLineCount,successfulUSDLineCount,successfulEURLineCount,
													String.format("%s %s", successfulTRYAmount.toString(), DatabaseConstants.CurrencyCodes.TRY),
													String.format("%s %s", successfulUSDAmount.toString(), DatabaseConstants.CurrencyCodes.USD),
													String.format("%s %s", successfulEURAmount.toString(), DatabaseConstants.CurrencyCodes.EUR));
			failureSummaryBodyPart = String.format(paymentConfirmationFailureSummary.toString(),failedLineCount,failedTRYLineCount,failedUSDLineCount,failedEURLineCount,
													String.format("%s %s", failedTRYAmount.toString(), DatabaseConstants.CurrencyCodes.TRY),
													String.format("%s %s", failedUSDAmount.toString(), DatabaseConstants.CurrencyCodes.USD),
													String.format("%s %s", failedEURAmount.toString(), DatabaseConstants.CurrencyCodes.EUR));		
			
			paymentConfirmationBody.append(introBodyPart);
			paymentConfirmationBody.append(successSummaryBodyPart);
			paymentConfirmationBody.append(failureSummaryBodyPart);
			if (failedLineCount > 0)
				paymentConfirmationBody.append(paymentConfirmationBodyFailurePart);
			
			message.append(htmlStart);
			message.append(head);			
			message.append(bodyStart);
			message.append(codeStart);
			message.append(paymentConfirmationBody.toString());
			message.append(codeEnd);
			message.append(bodyEnd);
			message.append(htmlEnd);
					
			messageSubject = String.format("%s Toplu �deme Transferleri Toplu Ak�bet", corporateShortName);
			CommonHelper.sendMail(receiverList, null, messageFrom, true, messageSubject, message.toString(), true);
			
		} else if (emailType.equals(DatabaseConstants.EmailType.RECIPIENTINFORMATION)) {
			
			StringBuilder recipientInfoEft = new StringBuilder();
			StringBuilder recipientInfoHavale = new StringBuilder();
			StringBuilder recipientInfoVirman = new StringBuilder();
			StringBuilder recipientInfoPttHavale = new StringBuilder();
	
			StringBuilder recipientInformationBody = new StringBuilder();		
			String recipientInformationBodyPart = null;
			
			recipientInfoEft.append("<p>\n");
			recipientInfoEft.append("Say�n %s %s tarihinde %s firmas�ndan hesab�n�za %s %s tutar�nda EFT emri verilmi�tir.</br>\n");
			recipientInfoEft.append("</p>\n");
			
			recipientInfoHavale.append("<p>\n");
			recipientInfoHavale.append("Say�n %s %s tarihinde %s firmas�ndan hesab�n�za %s %s tutar�nda havale i�lemi ger�ekle�mi�tir.</br>\n");
			recipientInfoHavale.append("</p>\n");
			
			recipientInfoVirman.append("<p>\n");
			recipientInfoVirman.append("Say�n %s %s tarihinde %s firmas�ndan hesab�n�za %s %s tutar�nda virman i�lemi ger�ekle�mi�tir.</br>\n");
			recipientInfoVirman.append("</p>\n");
			
			recipientInfoPttHavale.append("<p>\n");
			recipientInfoPttHavale.append("Say�n %s %s tarihinde %s firmas�ndan %s %s tutar�nda PTT isme havale i�lemi ger�ekle�mi�tir. PTT referans no: %s</br>\n");
			recipientInfoPttHavale.append("</p>\n");
			
			OrderMain order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
											   .add(Restrictions.eq("status", true))
											   .add(Restrictions.eq("oid", orderOid)).uniqueResult();			
			if (order != null) {
				orderStatus = order.getOrderStatus();
				orderType = order.getOrderType();
				currencyCode = order.getCurrencyCode();
				amount = order.getAmount();
				if (amount != null)
					amount = order.getAmount().setScale(2, RoundingMode.HALF_UP);
				recipientBank = order.getRecipientBank();
				recipientIban = order.getRecipientIban();
				recipientBranch = order.getRecipientBranch();
				recipientAccountNo = order.getRecipientAccountNo();
				recipientName = order.getRecipientName();
				recipientTcknNo = order.getRecipientTckn();
				recipientFatherName = order.getRecipientFatherName();
				recipientMotherName = order.getRecipientMotherName();	
				receivers = order.getRecipientEmail();
				
				if (orderType.equals(DatabaseConstants.OrderType.EFT))
					recipientInformationBodyPart = String.format(recipientInfoEft.toString(), recipientName, headerOrderDate, corporateShortName, amount, currencyCode);
				else if (orderType.equals(DatabaseConstants.OrderType.Havale))
					recipientInformationBodyPart = String.format(recipientInfoHavale.toString(), recipientName, headerOrderDate, corporateShortName, amount, currencyCode);
				else if (orderType.equals(DatabaseConstants.OrderType.Virman))
					recipientInformationBodyPart = String.format(recipientInfoVirman.toString(), recipientName, headerOrderDate, corporateShortName, amount, currencyCode);
				else if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {					
					CariSubelerarasiHavGirisTx cariSubelerarasiHavGirisTx = (CariSubelerarasiHavGirisTx) super.getHibernateSession().get(CariSubelerarasiHavGirisTx.class, order.getTxNo());
					if (cariSubelerarasiHavGirisTx != null)
						pttReferansNo = cariSubelerarasiHavGirisTx.getReferans();
					else
						pttReferansNo = "";					
					recipientInformationBodyPart = String.format(recipientInfoPttHavale.toString(), recipientName, headerOrderDate, corporateShortName, amount, currencyCode, pttReferansNo);
				}
			}
			
			recipientInformationBody.append(recipientInformationBodyPart);		
			
			message.append(htmlStart);
			message.append(head);			
			message.append(bodyStart);
			message.append(codeStart);
			message.append(recipientInformationBody.toString());
			message.append(codeEnd);
			message.append(bodyEnd);
			message.append(htmlEnd);				
				
			if (!StringUtils.isEmpty(receivers)) {
				receiverList = Arrays.asList(receivers.split("[,;]"));
				for (int i = 0; i < receiverList.size(); i++) {
					String receiverMail = receiverList.get(i).trim();
					receiverList.set(i, receiverMail);
				}
				messageSubject = String.format("%s Para Transferi Bilgisi", corporateShortName);
				CommonHelper.sendMail(receiverList, null, messageFrom, true, messageSubject, message.toString(), true);			
			}
			
		}
	}
	
	private String getIbanOfAccount(BigDecimal accountNo) {
		String query = QueryRepository.ComposeEmailHandlerRepository.IBAN_BY_HESAP_NO_QUERY;
		String result = DALUtil.getResult(String.format(query, accountNo));
		
		if (!StringUtils.isEmpty(result))
			return result;
		else 
			return null;
	}
}
