package tr.com.aktifbank.bnspr.cos.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.CorporationDef;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ReportServices {
	 	
	 @SuppressWarnings("unchecked")
	 @GraymoundService("COS_ORDER_FILES_DETAIL_REPORT")
	 public static GMMap orderFileDetailReport (GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String tableName = TransactionConstants.GetOrderFilesDetailReport.tableName;
			String corporateCode = input.getString(TransactionConstants.GetOrderFilesDetailReport.Input.CORPORATE_CODE);
			String beginDateStr = input.getString(TransactionConstants.GetOrderFilesDetailReport.Input.BEGIN_DATE);
			String endDateStr = input.getString(TransactionConstants.GetOrderFilesDetailReport.Input.END_DATE);
			String searchFileName = input.getString(TransactionConstants.GetOrderFilesDetailReport.Input.FILE_NAME);
			String searchFileStatus = input.getString(TransactionConstants.GetOrderFilesDetailReport.Input.FILE_STATUS);
			String searchBranchCode = input.getString(TransactionConstants.GetOrderFilesDetailReport.Input.BRANCH);
			Boolean showTransfered = input.getBoolean(TransactionConstants.GetOrderFilesDetailReport.Input.SHOW_TRANSFERED);
			
			String ftmFileName = null, loadingStatus = null, fileStatus = null, statusText = null, loadingTime = null;
			String corporateShortName = null, branchCode = null, orderType = null, currencyCode = null, orderStatus = null;
			Date loadingDate = null, orderDate = null;
			int eftTRYCount = 0, havaleTRYCount = 0, virmanTRYCount = 0, pttIsmeHavaleTRYCount = 0, noOrderTypeTRYCount = 0, TRYCountInt = 0;
			BigDecimal eftTRYAmount = null, havaleTRYAmount = null, virmanTRYAmount = null, pttIsmeHavaleTRYAmount = null, noOrderTypeTRYAmount = null;
			BigDecimal amount = null, TRYAmount = null, TRYCount = null;
			int eftTRYCountSum = 0, havaleTRYCountSum = 0, virmanTRYCountSum = 0, pttIsmeHavaleTRYCountSum = 0, noOrderTypeTRYCountSum = 0;
			BigDecimal totalLineCountSum = new BigDecimal(0); 
			BigDecimal erroneousLineCountSum = new BigDecimal(0);
			BigDecimal tryLineCountSum = new BigDecimal(0); 
			BigDecimal usdLineCountSum = new BigDecimal(0); 
			BigDecimal eurLineCountSum = new BigDecimal(0);
			BigDecimal tryAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP); 
			BigDecimal usdAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP); 
			BigDecimal eurAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);			
			BigDecimal eftTRYAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP); 
			BigDecimal havaleTRYAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal virmanTRYAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP); 
			BigDecimal pttIsmeHavaleTRYAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP); 
			BigDecimal noOrderTypeTRYAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			
			String getFileNameQuery = QueryRepository.ReportServicesRepository.GET_FILE_NAME_QUERY;  
			String searchFileNameQuery = QueryRepository.ReportServicesRepository.SEARCH_FILE_NAME_QUERY; 
			String getBranchCodeQuery = QueryRepository.ReportServicesRepository.GET_BRANCH_CODE_QUERY;
			String loadingStatusQuery = QueryRepository.ReportServicesRepository.COS_LOADING_STATUS_PARAM_TEXT_QUERY;
			String fileStatusQuery = QueryRepository.ReportServicesRepository.COS_FILE_STATUS_PARAM_TEXT_QUERY;
			
			if (StringUtils.isBlank(beginDateStr)) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));			
			if (StringUtils.isBlank(endDateStr))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			Date beginDate = CommonHelper.getDateTime(beginDateStr, "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(endDateStr, "yyyyMMdd");	
			if (beginDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));				
						
			Criteria criteria = hibernateSession.createCriteria(OrderFileLog.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("transferStatus", DatabaseConstants.TransferStatuses.SUBMITTED))
								.add(Restrictions.eq("transferType",  new Short(DatabaseConstants.TransferTypes.OrderLoading)))
								.add(Restrictions.between("logDate", beginDateStr + "000000", endDateStr + "235959"))
								.addOrder(Order.desc("logDate"));
			if (!StringUtils.isBlank(corporateCode))
				criteria = criteria.add(Restrictions.eq("corporateCode", corporateCode));			
			if (!StringUtils.isBlank(searchFileStatus)) {
				if (searchFileStatus.equals(DatabaseConstants.FileStatuses.LOADINGFAILURE))			
					criteria = criteria.add(Restrictions.eq("loadingStatus", searchFileStatus));
				else
					criteria = criteria.add(Restrictions.eq("fileStatus", searchFileStatus));	
			}
				
			List<OrderFileLog> incomingFiles = criteria.list();
			
			int count = 0;
			for (OrderFileLog incomingFile : incomingFiles) {				
			
				if(incomingFile.getFtmSequenceNumber() != null && incomingFile.getFtmSequenceNumber().compareTo(BigDecimal.ZERO) != 0){
					if (!StringUtils.isEmpty(searchFileName))
						ftmFileName = DALUtil.getResult(String.format(searchFileNameQuery, new BigDecimal(incomingFile.getFtmId()), incomingFile.getFtmSequenceNumber(), searchFileName.trim()));					
					else
						ftmFileName = DALUtil.getResult(String.format(getFileNameQuery, new BigDecimal(incomingFile.getFtmId()), incomingFile.getFtmSequenceNumber()));				
					if (StringUtils.isEmpty(ftmFileName))
						continue;				
				}

				if (!StringUtils.isEmpty(searchBranchCode)) {	
					branchCode = DALUtil.getResult(String.format(getBranchCodeQuery, incomingFile.getCorporateCode()));
					if (!StringUtils.isEmpty(branchCode) && !branchCode.equals(searchBranchCode))
						continue;
				}
					
				GMMap getCorpDefinitionMap = new GMMap();
				getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, incomingFile.getCorporateCode());
				GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
				corporateShortName = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.SHORT_NAME);
								
				loadingStatus = incomingFile.getLoadingStatus();
				fileStatus = incomingFile.getFileStatus();
			
				if (!StringUtils.isBlank(loadingStatus) && !loadingStatus.equals(DatabaseConstants.LoadingStatuses.SUCESSFUL))
					statusText = DALUtil.getResult(String.format(loadingStatusQuery, loadingStatus));
				else if (!StringUtils.isBlank(fileStatus))
					statusText = DALUtil.getResult(String.format(fileStatusQuery, fileStatus));
				else
					statusText = "";

				loadingDate = dateFormat.parse(CommonHelper.longTimeStringToViewDateString(incomingFile.getLogDate()));
				loadingTime = CommonHelper.longTimeStringToViewTimeString(incomingFile.getLogDate());
				
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.FILE_NAME, ftmFileName);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.LOADING_DATE, loadingDate);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.LOADING_TIME, loadingTime.replace(":",""));
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.BATCH_SUBMIT_ID, incomingFile.getBatchSubmitId());
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.FTM_SEQUENCE_NUMBER, incomingFile.getFtmSequenceNumber());
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.STATUS, statusText);					
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.TOTAL_LINE_COUNT, incomingFile.getTotalLineCount());
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.ERRONEOUS_LINE_COUNT, incomingFile.getErroneousLineCount());
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.CORPORATE_CODE, incomingFile.getCorporateCode());
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.CORPORATE_SHORT_NAME, corporateShortName);
				if (incomingFile.getOrderDate() != null) {
					orderDate = dateFormat.parse(CommonHelper.shortTimeStringToViewDateString(incomingFile.getOrderDate()));
					output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.ORDER_DATE, orderDate);
				}					
				
				eftTRYCount = 0; 
				havaleTRYCount = 0; 
				virmanTRYCount = 0; 
				pttIsmeHavaleTRYCount = 0; 
				noOrderTypeTRYCount = 0;
				eftTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
				havaleTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
				virmanTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
				pttIsmeHavaleTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
				noOrderTypeTRYAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
				
				List<OrderMain> orderList = hibernateSession.createCriteria(OrderMain.class)
											.add(Restrictions.eq("status", true))
											.add(Restrictions.eq("ftmSequenceNumber", incomingFile.getFtmSequenceNumber()))
											.add(Restrictions.eq("batchSubmitId", incomingFile.getBatchSubmitId())).list();				
				for (OrderMain order : orderList) {
					orderType = order.getOrderType();
					orderStatus = order.getOrderStatus();
					currencyCode = order.getCurrencyCode();
					amount = order.getAmount();
					
					if (showTransfered && !orderStatus.equals(DatabaseConstants.OrderStatuses.Transfered))
						;
					else {	
						if (!StringUtils.isEmpty(currencyCode) && currencyCode.equals(DatabaseConstants.CurrencyCodes.TRY) && amount != null) {
							if (StringUtils.isEmpty(orderType)) {
								noOrderTypeTRYCount++;
								noOrderTypeTRYAmount = noOrderTypeTRYAmount.add(amount); 						
							} else if (orderType.equals(DatabaseConstants.OrderType.EFT)) {
								eftTRYCount++;
								eftTRYAmount = eftTRYAmount.add(amount); 													
							} else if (orderType.equals(DatabaseConstants.OrderType.Havale)) {
								havaleTRYCount++;
								havaleTRYAmount = havaleTRYAmount.add(amount); 													
							} else if (orderType.equals(DatabaseConstants.OrderType.Virman)) {
								virmanTRYCount++;
								virmanTRYAmount = virmanTRYAmount.add(amount); 													
							} else if (orderType.equals(DatabaseConstants.OrderType.PTTIsmeHavale)) {
								pttIsmeHavaleTRYCount++;
								pttIsmeHavaleTRYAmount = pttIsmeHavaleTRYAmount.add(amount); 													
							} 						
						}
					}
				}
				
				TRYCountInt = 0;
				TRYCount = new BigDecimal(0);
				TRYAmount = new BigDecimal(0);
				if (showTransfered) {
					TRYCountInt = noOrderTypeTRYCount + eftTRYCount + havaleTRYCount + virmanTRYCount + pttIsmeHavaleTRYCount;
					TRYCount = new BigDecimal(TRYCountInt);
					TRYAmount = TRYAmount.add(noOrderTypeTRYAmount).add(eftTRYAmount).add(havaleTRYAmount).add(virmanTRYAmount).add(pttIsmeHavaleTRYAmount);		
				}
				else {
					TRYCount = incomingFile.getTryLineCount();
					TRYAmount = incomingFile.getTryAmount();		
				}
					
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.TRY_AMOUNT, TRYAmount);				
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.USD_AMOUNT, incomingFile.getUsdAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.EUR_AMOUNT, incomingFile.getEurAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.TRY_LINE_COUNT, TRYCount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.USD_LINE_COUNT, incomingFile.getUsdLineCount());
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.EUR_LINE_COUNT, incomingFile.getEurLineCount());
				
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.EFT_TRY_LINE_COUNT, eftTRYCount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.EFT_TRY_AMOUNT, eftTRYAmount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.HAVALE_TRY_LINE_COUNT, havaleTRYCount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.HAVALE_TRY_AMOUNT, havaleTRYAmount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.VIRMAN_TRY_LINE_COUNT, virmanTRYCount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.VIRMAN_TRY_AMOUNT, virmanTRYAmount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.PTT_ISME_HAVALE_TRY_LINE_COUNT, pttIsmeHavaleTRYCount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.PTT_ISME_HAVALE_TRY_AMOUNT, pttIsmeHavaleTRYAmount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.NO_ORDER_TYPE_TRY_LINE_COUNT, noOrderTypeTRYCount);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.NO_ORDER_TYPE_TRY_AMOUNT, noOrderTypeTRYAmount);

				//totalLineCountSum = totalLineCountSum.add(incomingFile.getTotalLineCount()); 
				//erroneousLineCountSum = erroneousLineCountSum.add(incomingFile.getErroneousLineCount());
				tryAmountSum = tryAmountSum.add(TRYAmount); 
				usdAmountSum = usdAmountSum.add(incomingFile.getUsdAmount()); 
				eurAmountSum = eurAmountSum.add(incomingFile.getEurAmount());	
				tryLineCountSum = tryLineCountSum.add(TRYCount); 
				usdLineCountSum = usdLineCountSum.add(incomingFile.getUsdLineCount()); 
				eurLineCountSum = eurLineCountSum.add(incomingFile.getEurLineCount());
				
				eftTRYCountSum = eftTRYCountSum + eftTRYCount; 
				eftTRYAmountSum = eftTRYAmountSum.add(eftTRYAmount);
				havaleTRYCountSum = havaleTRYCountSum + havaleTRYCount; 								
				havaleTRYAmountSum = havaleTRYAmountSum.add(havaleTRYAmount);
				virmanTRYCountSum = virmanTRYCountSum + virmanTRYCount; 				
				virmanTRYAmountSum = virmanTRYAmountSum.add(virmanTRYAmount);
				pttIsmeHavaleTRYCountSum = pttIsmeHavaleTRYCountSum + pttIsmeHavaleTRYCount; 				
				pttIsmeHavaleTRYAmountSum = pttIsmeHavaleTRYAmountSum.add(pttIsmeHavaleTRYAmount);
				noOrderTypeTRYCountSum = noOrderTypeTRYCountSum + noOrderTypeTRYCount;								
				noOrderTypeTRYAmountSum = noOrderTypeTRYAmountSum.add(noOrderTypeTRYAmount);				
				
				count++;
			}
			
			if (incomingFiles.size() > 0) {			
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.TOTAL_LINE_COUNT, totalLineCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.ERRONEOUS_LINE_COUNT, erroneousLineCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.TRY_AMOUNT, tryAmountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.USD_AMOUNT, usdAmountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.EUR_AMOUNT, eurAmountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.TRY_LINE_COUNT, tryLineCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.USD_LINE_COUNT, usdLineCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.EUR_LINE_COUNT, eurLineCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.CORPORATE_SHORT_NAME, "TOPLAM");
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.EFT_TRY_LINE_COUNT, eftTRYCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.EFT_TRY_AMOUNT, eftTRYAmountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.HAVALE_TRY_LINE_COUNT, havaleTRYCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.HAVALE_TRY_AMOUNT, havaleTRYAmountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.VIRMAN_TRY_LINE_COUNT, virmanTRYCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.VIRMAN_TRY_AMOUNT, virmanTRYAmountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.PTT_ISME_HAVALE_TRY_LINE_COUNT, pttIsmeHavaleTRYCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.PTT_ISME_HAVALE_TRY_AMOUNT, pttIsmeHavaleTRYAmountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.NO_ORDER_TYPE_TRY_LINE_COUNT, noOrderTypeTRYCountSum);
				output.put(tableName, count, TransactionConstants.GetOrderFilesDetailReport.Output.NO_ORDER_TYPE_TRY_AMOUNT, noOrderTypeTRYAmountSum);		
			}
			
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }
	
	 @GraymoundService("COS_ORDER_FILES_SUMMARY_REPORT")
	 public static GMMap orderFilesSummaryReport (GMMap input) {
		GMMap output = new GMMap();
		try {	
			String tableName = TransactionConstants.GetOrderFilesSummaryReport.tableName;
			String query = null;

			String corporateCode = input.getString(TransactionConstants.GetOrderFilesSummaryReport.Input.CORPORATE_CODE);
			String beginDateStr = input.getString(TransactionConstants.GetOrderFilesSummaryReport.Input.BEGIN_DATE);
			String endDateStr = input.getString(TransactionConstants.GetOrderFilesSummaryReport.Input.END_DATE);
			String beginDateFormatStr = CommonHelper.shortTimeStringToViewDateString(beginDateStr);
			String endDateFormatStr = CommonHelper.shortTimeStringToViewDateString(endDateStr);
			String searchFileName = input.getString(TransactionConstants.GetOrderFilesSummaryReport.Input.FILE_NAME);
			String searchFileStatus = input.getString(TransactionConstants.GetOrderFilesSummaryReport.Input.FILE_STATUS);
			String totalTryAmountStr = null, totalUsdAmountStr = null, totalEurAmountStr = null, transferedTryAmountStr = null, notTransferedTryAmountStr = null; 
			String totalFileCountStr = null, totalTryCountStr = null, totalUsdCountStr = null, totalEurCountStr = null, transferedTryCountStr = null, notTransferedTryCountStr = null;
			BigDecimal totalTryAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal totalUsdAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal totalEurAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal transferedTryAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal notTransferedTryAmount = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);			
			int totalFileCount = 0, totalTryCount = 0, totalUsdCount = 0, totalEurCount = 0, transferedTryCount = 0, notTransferedTryCount = 0;
			
			BigDecimal totalTryAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal totalUsdAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal totalEurAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal transferedTryAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);
			BigDecimal notTransferedTryAmountSum = new BigDecimal(0).setScale(2, RoundingMode.HALF_UP);			
			int totalFileCountSum = 0, totalTryCountSum = 0, totalUsdCountSum = 0, totalEurCountSum = 0, transferedTryCountSum = 0, notTransferedTryCountSum = 0;
						
			if (!StringUtils.isBlank(searchFileStatus)) {
				if (searchFileStatus.equals(DatabaseConstants.FileStatuses.LOADINGROLLBACK) || searchFileStatus.equals(DatabaseConstants.FileStatuses.LOADINGFAILURE))			
					return output;
			}
			
			if (StringUtils.isBlank(beginDateStr)) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));			
			if (StringUtils.isBlank(endDateStr))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			Date beginDate = CommonHelper.getDateTime(beginDateStr, "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(endDateStr, "yyyyMMdd");	
			if (beginDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));				
					
			if (StringUtils.isEmpty(corporateCode))
				corporateCode = null;
			else 
				corporateCode = String.format("\'%s\'", corporateCode);	
			if (StringUtils.isEmpty(searchFileName))
				searchFileName = null;
			else
				searchFileName = String.format("\'%%%s%%\'", searchFileName);
			if (StringUtils.isEmpty(searchFileStatus))
				searchFileStatus = null;
			else
				searchFileStatus = String.format("\'%s\'", searchFileStatus);							
						
			query = String.format(QueryRepository.ReportServicesRepository.ORDER_FILES_SUMMARY_QUERY, 
								  corporateCode, beginDateFormatStr, endDateFormatStr, searchFileName, searchFileName, searchFileStatus,
								  corporateCode, beginDateFormatStr, endDateFormatStr, searchFileName, searchFileName, searchFileStatus,
								  corporateCode, beginDateFormatStr, endDateFormatStr, searchFileName, searchFileName, searchFileStatus,
								  corporateCode, beginDateFormatStr, endDateFormatStr, searchFileName, searchFileName, searchFileStatus,
								  corporateCode, beginDateFormatStr, endDateFormatStr, searchFileName, searchFileName, searchFileStatus);
					
			GMMap orderFilesSummary = DALUtil.getResults(query, tableName);

			int i = 0;
			for (i = 0; i < orderFilesSummary.getSize(tableName); i++) {
				
				totalFileCountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_FILE_COUNT); 
				totalTryCountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_TRY_LINE_COUNT);
				totalUsdCountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_USD_LINE_COUNT); 
				totalEurCountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_EUR_LINE_COUNT); 				
				transferedTryCountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TRANSFERED_TRY_LINE_COUNT); 
				notTransferedTryCountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.NOT_TRANSFERED_TRY_LINE_COUNT);
				totalTryAmountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_TRY_AMOUNT);
				totalUsdAmountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_USD_AMOUNT);
				totalEurAmountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_EUR_AMOUNT);
				transferedTryAmountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TRANSFERED_TRY_AMOUNT); 
				notTransferedTryAmountStr = orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.NOT_TRANSFERED_TRY_AMOUNT);
								
				if (!StringUtils.isEmpty(totalFileCountStr)) 
					totalFileCount = Integer.valueOf(totalFileCountStr);
				else 
					totalFileCount = 0;
				if (!StringUtils.isEmpty(totalTryCountStr)) 
					totalTryCount = Integer.valueOf(totalTryCountStr);
				else 
					totalTryCount = 0;
				if (!StringUtils.isEmpty(totalUsdCountStr)) 
					totalUsdCount = Integer.valueOf(totalUsdCountStr);
				else 
					totalUsdCount = 0;
				if (!StringUtils.isEmpty(totalEurCountStr)) 
					totalEurCount = Integer.valueOf(totalEurCountStr);
				else 
					totalEurCount = 0;		
				if (!StringUtils.isEmpty(transferedTryCountStr)) 
					transferedTryCount = Integer.valueOf(transferedTryCountStr);
				else 
					transferedTryCount = 0;
				if (!StringUtils.isEmpty(notTransferedTryCountStr)) 
					notTransferedTryCount = Integer.valueOf(notTransferedTryCountStr);
				else 
					notTransferedTryCount = 0;					
				
				if (!StringUtils.isEmpty(totalTryAmountStr)) 
					totalTryAmount = new BigDecimal(totalTryAmountStr).setScale(2, RoundingMode.HALF_UP);
				else 
					totalTryAmount = new BigDecimal(0);
				if (!StringUtils.isEmpty(totalUsdAmountStr)) 
					totalUsdAmount = new BigDecimal(totalUsdAmountStr).setScale(2, RoundingMode.HALF_UP);
				else 
					totalUsdAmount = new BigDecimal(0);				
				if (!StringUtils.isEmpty(totalEurAmountStr)) 
					totalEurAmount = new BigDecimal(totalEurAmountStr).setScale(2, RoundingMode.HALF_UP);
				else 
					totalEurAmount = new BigDecimal(0);							
				if (!StringUtils.isEmpty(transferedTryAmountStr)) 
					transferedTryAmount = new BigDecimal(transferedTryAmountStr).setScale(2, RoundingMode.HALF_UP);
				else 
					transferedTryAmount = new BigDecimal(0);						
				if (!StringUtils.isEmpty(notTransferedTryAmountStr)) 
					notTransferedTryAmount = new BigDecimal(notTransferedTryAmountStr).setScale(2, RoundingMode.HALF_UP);
				else 
					notTransferedTryAmount = new BigDecimal(0);						
				
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.CORPORATE_SHORT_NAME, orderFilesSummary.getString(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.CORPORATE_SHORT_NAME));
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_FILE_COUNT, totalFileCount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_TRY_LINE_COUNT, totalTryCount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_TRY_AMOUNT, totalTryAmount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_USD_LINE_COUNT, totalUsdCount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_USD_AMOUNT, totalUsdAmount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_EUR_LINE_COUNT, totalEurCount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_EUR_AMOUNT, totalEurAmount);							
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TRANSFERED_TRY_LINE_COUNT, transferedTryCount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TRANSFERED_TRY_AMOUNT, transferedTryAmount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.NOT_TRANSFERED_TRY_LINE_COUNT, notTransferedTryCount);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.NOT_TRANSFERED_TRY_AMOUNT, notTransferedTryAmount);

				totalFileCountSum = totalFileCountSum + totalFileCount;
				totalTryCountSum = totalTryCountSum + totalTryCount;
				totalUsdCountSum = totalUsdCountSum + totalUsdCount;
				totalEurCountSum = totalEurCountSum + totalEurCount;
				transferedTryCountSum = transferedTryCountSum + transferedTryCount;
				notTransferedTryCountSum = notTransferedTryCountSum+ notTransferedTryCount;
				
				totalTryAmountSum = totalTryAmountSum.add(totalTryAmount); 
				totalUsdAmountSum = totalUsdAmountSum.add(totalUsdAmount);
				totalEurAmountSum = totalEurAmountSum.add(totalEurAmount);
				transferedTryAmountSum = transferedTryAmountSum.add(transferedTryAmount);
				notTransferedTryAmountSum = notTransferedTryAmountSum.add(notTransferedTryAmount);			
			}			
			
			if (orderFilesSummary.getSize(tableName) > 0) {
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.CORPORATE_SHORT_NAME, "TOPLAM");
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_FILE_COUNT, totalFileCountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_TRY_LINE_COUNT, totalTryCountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_TRY_AMOUNT, totalTryAmountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_USD_LINE_COUNT, totalUsdCountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_USD_AMOUNT, totalUsdAmountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_EUR_LINE_COUNT, totalEurCountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TOTAL_EUR_AMOUNT, totalEurAmountSum);							
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TRANSFERED_TRY_LINE_COUNT, transferedTryCountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.TRANSFERED_TRY_AMOUNT, transferedTryAmountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.NOT_TRANSFERED_TRY_LINE_COUNT, notTransferedTryCountSum);
				output.put(tableName, i, TransactionConstants.GetOrderFilesSummaryReport.Output.NOT_TRANSFERED_TRY_AMOUNT, notTransferedTryAmountSum);
			}
			
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }	 
	 
	@GraymoundService("COS_GET_DETAIL_TRANSACTION_REPORT")
	 public static GMMap getDetailTransactionReport (GMMap input) {
		GMMap output = new GMMap();
		try {						
			String tableName = TransactionConstants.GetDetailTransactionReport.tableName;
			String startDateStr = input.getString(TransactionConstants.GetDetailTransactionReport.Input.START_DATE);
			String endDateStr = input.getString(TransactionConstants.GetDetailTransactionReport.Input.END_DATE);
			String detailTransactionQuery = QueryRepository.ReportServicesRepository.DETAIL_TRANSACTION_REPORT_QUERY;

			if (StringUtils.isBlank(startDateStr)) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));			
			if (StringUtils.isBlank(endDateStr))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			Date startDate = CommonHelper.getDateTime(startDateStr, "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(endDateStr, "yyyyMMdd");	
			if (startDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));				
			
			GMMap detailTransactionMap = DALUtil.getResults(String.format(detailTransactionQuery, startDateStr+"000000", endDateStr+"235959"), tableName);

			int i = 0;
			for (i = 0; i < detailTransactionMap.getSize(tableName); i++) {
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.CORP_NAME, getCorporateName(detailTransactionMap.getString(tableName, i, "CORPORATE_CODE")));		
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.EFT_AMOUNT, detailTransactionMap.getString(tableName, i, "EFT_AMOUNT"));
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.EFT_COUNT, detailTransactionMap.getString(tableName, i, "EFT_COUNT"));
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.TRANSFER_AMOUNT, detailTransactionMap.getString(tableName, i, "HAVALE_AMOUNT"));
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.TRANSFER_COUNT, detailTransactionMap.getString(tableName, i, "HAVALE_COUNT"));				
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.VIRMAN_AMOUNT, detailTransactionMap.getString(tableName, i, "VIRMAN_AMOUNT"));
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.VIRMAN_COUNT, detailTransactionMap.getString(tableName, i, "VIRMAN_COUNT"));				
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.PTT_TRANSFER_AMOUNT, detailTransactionMap.getString(tableName, i, "PTT_AMOUNT"));
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.PTT_TRANSFER_COUNT, detailTransactionMap.getString(tableName, i, "PTT_COUNT"));				
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.UNK_SOURCE_AMOUNT, detailTransactionMap.getString(tableName, i, "UNK_AMOUNT"));
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.TRY_AMOUNT, detailTransactionMap.getString(tableName, i, "TRY_AMOUNT"));
				output.put(tableName, i, TransactionConstants.GetDetailTransactionReport.Output.TRY_COUNT, detailTransactionMap.getString(tableName, i, "TRY_COUNT"));
			}
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }	 

	public static String getCorporateName(String corporateCode){
		String corporateName = "";
		Session session = DAOSession.getSession("BNSPRDal");
		
		if(StringUtils.isNotEmpty(corporateCode)){
			CorporationDef corpDef = (CorporationDef) session.createCriteria(CorporationDef.class).add(Restrictions.eq("corporateCode", corporateCode)).add(Restrictions.eq("status", true)).uniqueResult();
			if (corpDef != null)
				corporateName = corpDef.getShortName();
		}
		
		return corporateName;
	}
	 
	@GraymoundService("COS_GET_FILE_STATUS_COMBO")
	public static GMMap getFileStatusCombo(GMMap iMap) {		
		return CorporationServiceUtil.getComboValues(iMap);
	}
}