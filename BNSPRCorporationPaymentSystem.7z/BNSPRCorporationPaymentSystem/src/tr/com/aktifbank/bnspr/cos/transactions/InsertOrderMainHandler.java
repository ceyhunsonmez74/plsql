package tr.com.aktifbank.bnspr.cos.transactions;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Date;
import java.util.UUID;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;

import com.graymound.util.GMMap;

public final class InsertOrderMainHandler extends RequestHandler {
	
	private static final class BagKeys{
		public static final Short OPENED_CONNECTION = 1;
		public static final Short OPENED_STATEMENT = 2;
	}
	
	public InsertOrderMainHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		if(input.containsKey(TransactionConstants.InsertOrderMain.Input.DIRECT_INSERT) && input.getBoolean(TransactionConstants.InsertOrderMain.Input.DIRECT_INSERT)){
			Connection connection = null;
			Statement statement = null;
			
			connection = CommonHelper.getConnection();
			super.bag.put(BagKeys.OPENED_CONNECTION, connection);
			statement = connection.createStatement();
			super.bag.put(BagKeys.OPENED_STATEMENT, statement);
			
			String submitId = input.getString(TransactionConstants.InsertOrderMain.Input.SUBMIT_ID);
			
			for (int i = 0; i < input.getSize(TransactionConstants.InsertOrderMain.Input.INSERT_PAIR_TABLE); i++) {
				GMMap directInsertMap = (GMMap)input.get(TransactionConstants.InsertOrderMain.Input.INSERT_PAIR_TABLE, 
						i, 
						TransactionConstants.InsertOrderMain.Input.INSERT_KEYVALUE_PAIRS);
				
				String corporateCode = input.getString(TransactionConstants.InsertOrderMain.Input.CORPORATE_CODE);
				String customerNo = input.getBigDecimal(TransactionConstants.InsertOrderMain.Input.CUSTOMER_NO).toString();
				String customerName = input.getString(TransactionConstants.InsertOrderMain.Input.CUSTOMER_NAME);
				
				/*String indicator = "";				
				if(indicatorList.contains(indicator)){
					logger.info(String.format("Invoice with %s map exists on database", directInsertMap.toString()));
					continue;
				}*/
				
				StringBuilder columnNameBuilder = new StringBuilder();
				StringBuilder valueBuilder = new StringBuilder();
				for(Object key : directInsertMap.keySet()){
					columnNameBuilder.append(String.format("%s,", key));
					Object value = directInsertMap.get(key);
					if(value instanceof String){
						valueBuilder.append(String.format("'%s',", value));
					}
					else if(value instanceof Date){
						valueBuilder.append(String.format("'%s',", CommonHelper.getShortDateTimeString((Date)value)));
					}
					else{
						valueBuilder.append(String.format("%s,", value));
					}
				}
				String query = String.format("INSERT INTO COS.ORDER_MAIN(OID,CORPORATE_CODE,CUSTOMER_NO,CUSTOMER_NAME,STATUS,%s,LOADING_DATE,LOADING_USER,FTM_SEQUENCE_NUMBER,BATCH_SUBMIT_ID) VALUES('%s','%s','%s','%s',0,%s,'%s','%s',%s,'%s')",
						CommonHelper.trimEnd(columnNameBuilder.toString(), ','), 
						UUID.randomUUID().toString().substring(0, 32),
						corporateCode,
						customerNo,
						customerName,
						CommonHelper.trimEnd(valueBuilder.toString(), ','),
						CommonHelper.getLongDateTimeString(new Date()),
						CommonHelper.getCurrentUser(),
						input.getBigDecimal(TransactionConstants.InsertOrderMain.Input.FTM_TRANSFER_ID),
						submitId);
				logger.info(query);
				statement.addBatch(query);				
			}
			
			statement.executeBatch();
			
			output.put(TransactionConstants.InsertOrderMain.Output.RETURN_CODE, 0);
		}
		else{
			throw new BatchComponentException("No implementation found other than direct insert at insert order main handler", BusinessException.SYSTEM);
		}
	}
	
	@Override
	protected void handleError(Throwable e, GMMap output) {
		logger.error("An exception occured while inserting orders.");
		logger.error(System.currentTimeMillis(), e);
		output.put(TransactionConstants.InsertOrderMain.Output.RETURN_CODE, 1);
		output.put(TransactionConstants.InsertOrderMain.Output.RETURN_MESSAGE, "�deme talimat� kay�tlar�n� eklerken bir hata olu�tu : " + e.toString());
	}
	
	@Override
	protected void handleFinally(GMMap output) {
		try{
			CommonHelper.closeAll(super.bag.get(BagKeys.OPENED_STATEMENT), super.bag.get(BagKeys.OPENED_CONNECTION));
		}
		catch(Exception e){
			logger.error("An exception occured while closing statement and connection");
			logger.error(System.currentTimeMillis(), e);
		}
	}

}
