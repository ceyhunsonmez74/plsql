package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.List;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.OutgoingFileLog;

import com.graymound.util.GMMap;

public class CreateOutgoingFileHandler extends RequestHandler {

	public CreateOutgoingFileHandler() {
		super();
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		
		boolean loadingFileExists = false, paymentFileExists = false, eodFileExists = false;
		String fileType = null;
		
		List<OutgoingFileLog> fileList = super.getHibernateSession().createCriteria(OutgoingFileLog.class)
												.add(Restrictions.eq("status", true)).list();
		for (OutgoingFileLog outgoingFile : fileList) {
			if (loadingFileExists && paymentFileExists && eodFileExists)
				break;
			
			fileType = outgoingFile.getFileType();
			if (!loadingFileExists && fileType.equals(DatabaseConstants.OutgoingFileType.LOADING))
				loadingFileExists = true;
			else if (!paymentFileExists && fileType.equals(DatabaseConstants.OutgoingFileType.PAYMENT))
				paymentFileExists = true;
			else if (!eodFileExists && fileType.equals(DatabaseConstants.OutgoingFileType.EOD))
				eodFileExists = true;
		}
		
		if (loadingFileExists) {
			GMMap createOutgoingFileByFtmCallRequest = new GMMap();			
			createOutgoingFileByFtmCallRequest.put(TransactionConstants.CreateOutgoingFileByFtmCall.Input.FILE_TYPE, DatabaseConstants.OutgoingFileType.LOADING);
			super.callGraymoundServiceAsync(TransactionConstants.CreateOutgoingFileByFtmCall.SERVICE_NAME, createOutgoingFileByFtmCallRequest);
		}
		if (paymentFileExists) {
			GMMap createOutgoingFileByFtmCallRequest = new GMMap();			
			createOutgoingFileByFtmCallRequest.put(TransactionConstants.CreateOutgoingFileByFtmCall.Input.FILE_TYPE, DatabaseConstants.OutgoingFileType.PAYMENT);
			super.callGraymoundServiceAsync(TransactionConstants.CreateOutgoingFileByFtmCall.SERVICE_NAME, createOutgoingFileByFtmCallRequest);
		}
		if (eodFileExists) {
			GMMap createOutgoingFileByFtmCallRequest = new GMMap();			
			createOutgoingFileByFtmCallRequest.put(TransactionConstants.CreateOutgoingFileByFtmCall.Input.FILE_TYPE, DatabaseConstants.OutgoingFileType.EOD);
			super.callGraymoundServiceAsync(TransactionConstants.CreateOutgoingFileByFtmCall.SERVICE_NAME, createOutgoingFileByFtmCallRequest);
		}
	}
}
