package tr.com.aktifbank.bnspr.cos.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cos.transactions.InsertOrderMainHandler;
import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.transactions.CommonBusinessOperations;
import tr.com.aktifbank.bnspr.cos.transactions.OrderLineParserHandler;
import tr.com.aktifbank.bnspr.cos.transactions.RequestProcessor;
import tr.com.aktifbank.bnspr.cos.util.CorporationServiceUtil;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.FileErrorLog;
import tr.com.aktifbank.bnspr.dao.FtmFileDefinitionFtp;
import tr.com.aktifbank.bnspr.dao.OrderFileLog;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class OrderLoadingServices {

	@GraymoundService("COS_INSERT_ORDER_MAIN")
	public static GMMap insertInvoice(GMMap input){
		return RequestProcessor.getInstance().process(input, new InsertOrderMainHandler());
	}
	
	 @GraymoundService("COS_ORDER_LINE_PARSER")
	 public static GMMap parseDebtLines (GMMap iMap) {
		 return RequestProcessor.getInstance().process(iMap, new OrderLineParserHandler());
	 }
	 
	 @SuppressWarnings("unchecked")
	 @GraymoundService("COS_GET_ORDER_FILES")
	 public static GMMap getLoadedFiles (GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String tableName = TransactionConstants.GetOrderFiles.tableName;
			FtmFileDefinitionFtp ftmFileDefFtp = null; 
			String path = null, ftmFileName = null, loadingStatus = null, fileStatus = null, statusText = null, loadingTime = null;
			String corporateShortName = null;
			Date loadingDate = null, orderDate = null;
			boolean isApprover = false;
			String getFileNameQuery = QueryRepository.OrderLoadingServicesRepository.GET_FILE_NAME_QUERY;
			String searchFileNameQuery = QueryRepository.OrderLoadingServicesRepository.SEARCH_FILE_NAME_QUERY; 
			String loadingStatusQuery = QueryRepository.OrderLoadingServicesRepository.COS_LOADING_STATUS_PARAM_TEXT_QUERY;
			String fileStatusQuery = QueryRepository.OrderLoadingServicesRepository.COS_FILE_STATUS_PARAM_TEXT_QUERY;
			
			String corporateCode = input.getString(TransactionConstants.GetOrderFiles.Input.CORPORATE_CODE);
			String beginDateStr = input.getString(TransactionConstants.GetOrderFiles.Input.BEGIN_DATE);
			String endDateStr = input.getString(TransactionConstants.GetOrderFiles.Input.END_DATE);
			String searchFileName = input.getString(TransactionConstants.GetOrderFiles.Input.FILE_NAME);
			if (input.containsKey(TransactionConstants.GetOrderFiles.Input.IS_APPROVER))
				isApprover = true;
								
			if (StringUtils.isBlank(beginDateStr)) 
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Ba�lang�� Tarihi"));			
			if (StringUtils.isBlank(endDateStr))
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.MUSTFIELDEMPTY, "Biti� Tarihi"));
			
			Date beginDate = CommonHelper.getDateTime(beginDateStr, "yyyyMMdd");
			Date endDate = CommonHelper.getDateTime(endDateStr, "yyyyMMdd");	
			if (beginDate.compareTo(endDate) > 0)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.STARTENDDATEERROR));				
						
			Criteria criteria = hibernateSession.createCriteria(OrderFileLog.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("transferStatus", DatabaseConstants.TransferStatuses.SUBMITTED))
								.add(Restrictions.eq("transferType",  new Short(DatabaseConstants.TransferTypes.OrderLoading)))
								.add(Restrictions.between("logDate", beginDateStr + "000000", endDateStr + "235959"))
								.addOrder(Order.desc("logDate"));
			if (!StringUtils.isBlank(corporateCode))
				criteria = criteria.add(Restrictions.eq("corporateCode", corporateCode));	
			
			if (isApprover) {
				criteria = criteria.add(Restrictions.eq("loadingStatus", DatabaseConstants.LoadingStatuses.SUCESSFUL))
								   .add(Restrictions.eq("visibleToApprover", true));			
			}					
						
			List<OrderFileLog> incomingFiles = criteria.list();
			
			int count = 0;
			for (OrderFileLog incomingFile : incomingFiles) {				
				
				if(incomingFile.getFtmSequenceNumber() != null && incomingFile.getFtmSequenceNumber().compareTo(BigDecimal.ZERO) != 0){
					if (!StringUtils.isEmpty(searchFileName))
						ftmFileName = DALUtil.getResult(String.format(searchFileNameQuery, new BigDecimal(incomingFile.getFtmId()), incomingFile.getFtmSequenceNumber(), searchFileName.trim()));					
					else
						ftmFileName = DALUtil.getResult(String.format(getFileNameQuery, new BigDecimal(incomingFile.getFtmId()), incomingFile.getFtmSequenceNumber()));
					if (StringUtils.isEmpty(ftmFileName))
						continue;	
				}
				
				if (!isApprover) {
					ftmFileDefFtp = (FtmFileDefinitionFtp) hibernateSession.createCriteria(FtmFileDefinitionFtp.class)
															.add(Restrictions.eq("ftmFileDefinitionOid", new BigDecimal(incomingFile.getFtmId())))
															.add(Restrictions.eq("ftmFileDefFtpTypeOid", new BigDecimal(2))).uniqueResult();	
					if (ftmFileDefFtp != null)
						path = ftmFileDefFtp.getPath();
				}
				
				GMMap getCorpDefinitionMap = new GMMap();
				getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, incomingFile.getCorporateCode());
				GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
				corporateShortName = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.SHORT_NAME);
								
				loadingStatus = incomingFile.getLoadingStatus();
				fileStatus = incomingFile.getFileStatus();
			
				if (!StringUtils.isBlank(loadingStatus) && !loadingStatus.equals(DatabaseConstants.LoadingStatuses.SUCESSFUL))
					statusText = DALUtil.getResult(String.format(loadingStatusQuery, loadingStatus));
				else if (!StringUtils.isBlank(fileStatus))
					statusText = DALUtil.getResult(String.format(fileStatusQuery, fileStatus));
				else
					statusText = "";

				loadingDate = dateFormat.parse(CommonHelper.longTimeStringToViewDateString(incomingFile.getLogDate()));
				loadingTime = CommonHelper.longTimeStringToViewTimeString(incomingFile.getLogDate());
				
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.PATH, path);
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.FILE_NAME, ftmFileName);
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.LOADING_DATE, loadingDate);
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.LOADING_TIME, loadingTime.replace(":",""));
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.BATCH_SUBMIT_ID, incomingFile.getBatchSubmitId());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.FTM_SEQUENCE_NUMBER, incomingFile.getFtmSequenceNumber());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.FILE_TRANSFER_LOG_OID, incomingFile.getOid());	
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.LOADING_STATUS, loadingStatus);
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.FILE_STATUS, fileStatus);
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.STATUS, statusText);					
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.TOTAL_LINE_COUNT, incomingFile.getTotalLineCount());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.ERRONEOUS_LINE_COUNT, incomingFile.getErroneousLineCount());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.TRY_AMOUNT, incomingFile.getTryAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.USD_AMOUNT, incomingFile.getUsdAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.EUR_AMOUNT, incomingFile.getEurAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.TRY_LINE_COUNT, incomingFile.getTryLineCount());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.USD_LINE_COUNT, incomingFile.getUsdLineCount());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.EUR_LINE_COUNT, incomingFile.getEurLineCount());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.ERROR_CODE, incomingFile.getErrorCode());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.ERROR_DESC, incomingFile.getErrorDesc());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.CORPORATE_CODE, incomingFile.getCorporateCode());
				output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.CORPORATE_SHORT_NAME, corporateShortName);
				if (incomingFile.getOrderDate() != null) {
					orderDate = dateFormat.parse(CommonHelper.shortTimeStringToViewDateString(incomingFile.getOrderDate()));
					output.put(tableName, count, TransactionConstants.GetOrderFiles.Output.ORDER_DATE, orderDate);
				}	
				count++;
			}
			
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }
	 
	 @SuppressWarnings("unchecked")
	 @GraymoundService("COS_GET_ORDER_FILE_CONTENT")
	 public static GMMap getOrderFileContent (GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String tableName = TransactionConstants.GetOrderFileContent.tableName;
			String query = null, orderType = null, orderStatus = null, transferTime = null, amountOrder = null, recipientDateOfBirth = null;
			BigDecimal ftmSequenceNumber = input.getBigDecimal(TransactionConstants.GetOrderFileContent.Input.FTM_SEQUENCE_NUMBER);
			String batchSubmitId = input.getString(TransactionConstants.GetOrderFileContent.Input.BATCH_SUBMIT_ID);
			String lineType = input.getString(TransactionConstants.GetOrderFileContent.Input.LINE_TYPE);
			String corporateCode = input.getString(TransactionConstants.GetOrderFileContent.Input.CORPORATE_CODE);
			String loadingStatus = input.getString(TransactionConstants.GetOrderFileContent.Input.LOADING_STATUS);
			String fileStatus = input.getString(TransactionConstants.GetOrderFileContent.Input.FILE_STATUS);		
			Date transferDate = null;
			String errorType = null;
			
			GMMap getCorpDefinitionMap = new GMMap();
			getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
			GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
			amountOrder = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING);
						
			Criteria criteria = hibernateSession.createCriteria(OrderMain.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("ftmSequenceNumber", ftmSequenceNumber))
								.add(Restrictions.eq("batchSubmitId", batchSubmitId));
			if (StringUtils.isNotBlank(lineType)) {				
				if (lineType.equals(DatabaseConstants.OrderLineTypes.CONTROLSSUCCESSFUL))
					criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.Waiting))
									   .add(Restrictions.le("orderStatus", DatabaseConstants.OrderStatuses.RepeatedOrder));
				else if (lineType.equals(DatabaseConstants.OrderLineTypes.TRANSFERSUCCESSFUL))
					criteria = criteria.add(Restrictions.eq("orderStatus", DatabaseConstants.OrderStatuses.Transfered));
				else if (lineType.equals(DatabaseConstants.OrderLineTypes.WAITINGAPPROVAL))
					criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.WaitingApproval))
									   .add(Restrictions.le("orderStatus", DatabaseConstants.OrderStatuses.AfterApprovalProcessStarted));
				else if (lineType.equals(DatabaseConstants.OrderLineTypes.CONTROLSFAILED))
					criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.RecipientBankCodeError))
									   .add(Restrictions.lt("orderStatus", DatabaseConstants.OrderStatuses.Waiting));
				else if (lineType.equals(DatabaseConstants.OrderLineTypes.TRANSFERFAILED))
					criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.InsufficientBalance))
									   .add(Restrictions.lt("orderStatus", DatabaseConstants.OrderStatuses.Transfered));				
			}
			
			if (StringUtils.isNotBlank(amountOrder)) {				
				if (amountOrder.equals("D"))
					criteria = criteria.addOrder(Order.desc("amount"));
				else if (amountOrder.equals("A"))
					criteria = criteria.addOrder(Order.asc("amount"));
			} else 
				criteria = criteria.addOrder(Order.asc("lineNumber"));
			
			List<OrderMain> orderList = criteria.list();
			
			int count = 0;
			for (OrderMain order : orderList) {
				query = QueryRepository.OrderLoadingServicesRepository.COS_ORDER_STATUS_PARAM_TEXT_QUERY;
				orderStatus = DALUtil.getResult(String.format(query, order.getOrderStatus()));
				query = QueryRepository.OrderLoadingServicesRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
				orderType = DALUtil.getResult(String.format(query, order.getOrderType()));
				if (!StringUtils.isEmpty(order.getRecipientDateOfBirth()))
					recipientDateOfBirth = CommonHelper.shortTimeStringToViewDateString(order.getRecipientDateOfBirth());
				
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT, true); 
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_NAME, order.getRecipientName()); 
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_ADDRESS, order.getRecipientAddress());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_MOTHER_NAME, order.getRecipientMotherName());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_FATHER_NAME, order.getRecipientFatherName());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_BANK, order.getRecipientBank());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_DATE_OF_BIRTH, recipientDateOfBirth);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_EMAIL, order.getRecipientEmail());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_ACCOUNT_NO, order.getRecipientAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_IBAN, order.getRecipientIban());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_CC_NO, order.getRecipientCcNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_REF_NO, order.getRecipientRefNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_BRANCH, order.getRecipientBranch());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_TCKN, order.getRecipientTckn());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_PHONE_NUMBER, order.getRecipientPhoneNumber());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_VKN, order.getRecipientVkn());				
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ACCOUNT_NO, order.getAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ERROR_DESCRIPTION, order.getErrorDesc());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.EXPLANATION, order.getExplanation());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS, orderStatus);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE, order.getOrderStatus());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_TYPE, orderType);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TX_NO, order.getTxNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.COMMISSION_ACCOUNT_NO, order.getCommissionAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.COMMISSION_AMOUNT, order.getCommissionAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.CURRENCY_CODE, order.getCurrencyCode());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_AMOUNT, order.getTransferAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_TYPE, order.getTransferType());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.AMOUNT, order.getAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TAX_OFFICE, order.getTaxOffice());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.MAIN_OID, order.getOid());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.EFT_SORGU_NO, order.getEftSorguNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.FIS_NO, order.getFisNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.PAYMENT_ACCOUNT_NO, order.getPaymentAccountNo());
				if (order.getTransferDate() != null) {
					transferDate = dateFormat.parse(CommonHelper.longTimeStringToViewDateString(order.getTransferDate()));
					transferTime = CommonHelper.longTimeStringToViewTimeString(order.getTransferDate());					
					output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_DATE, transferDate);
					output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_TIME, transferTime.replace(":", ""));
				}
				count++;
			}	
			
			if (DatabaseConstants.LoadingStatuses.FAILURE.equals(loadingStatus)) {
				errorType = DatabaseConstants.ErrorTypes.LOADINGERROR;
			} else if (!DatabaseConstants.FileStatuses.CONTROLSSUCCESSFUL.equals(fileStatus) || !DatabaseConstants.FileStatuses.PAYMENTSSUCCESSFUL.equals(fileStatus)) {
				errorType = DatabaseConstants.ErrorTypes.CONTROLORTRANSFERERROR;
			} else 
				errorType = DatabaseConstants.ErrorTypes.NOERROR;
			output.put(TransactionConstants.GetOrderFileContent.Output.ERROR_TYPE, errorType);
			
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }	 
	 
	 @SuppressWarnings("unchecked")
	 @GraymoundService("COS_GET_ORDER_FILE_CONTENT_FOR_APPROVER")
	 public static GMMap getOrderFileContentForApprover (GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String tableName = TransactionConstants.GetOrderFileContent.tableName;
			String query = null, orderType = null, orderStatus = null, transferTime = null, amountOrder = null, recipientDateOfBirth = null;
			BigDecimal ftmSequenceNumber = input.getBigDecimal(TransactionConstants.GetOrderFileContent.Input.FTM_SEQUENCE_NUMBER);
			String batchSubmitId = input.getString(TransactionConstants.GetOrderFileContent.Input.BATCH_SUBMIT_ID);
			String lineType = input.getString(TransactionConstants.GetOrderFileContent.Input.LINE_TYPE);
			String corporateCode = input.getString(TransactionConstants.GetOrderFileContent.Input.CORPORATE_CODE);
			Boolean queryScreen = input.getBoolean(TransactionConstants.GetOrderFileContent.Input.QUERY_SCREEN);
			Date transferDate = null;
			
			GMMap getCorpDefinitionMap = new GMMap();
			getCorpDefinitionMap.put(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, corporateCode);
			GMMap corpDefDetailsMap = CommonBusinessOperations.callGraymoundService(getCorpDefinitionMap, TransactionConstants.GetOrderCorpDef.SERVICE_NAME, true);
			amountOrder = corpDefDetailsMap.getString(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING);
			
			Criteria criteria = hibernateSession.createCriteria(OrderMain.class)
								.add(Restrictions.eq("status", true))
								.add(Restrictions.eq("ftmSequenceNumber", ftmSequenceNumber))
								.add(Restrictions.eq("batchSubmitId", batchSubmitId));
			if (StringUtils.isNotBlank(lineType)) {				
				if (lineType.equals(DatabaseConstants.OrderLineTypes.CONTROLSSUCCESSFUL))
					criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.Waiting))
									   .add(Restrictions.le("orderStatus", DatabaseConstants.OrderStatuses.RepeatedOrder));
				else if (lineType.equals(DatabaseConstants.OrderLineTypes.TRANSFERSUCCESSFUL))
					criteria = criteria.add(Restrictions.eq("orderStatus", DatabaseConstants.OrderStatuses.Transfered));
				else if (lineType.equals(DatabaseConstants.OrderLineTypes.WAITINGAPPROVAL))
					criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.WaitingApproval))
									   .add(Restrictions.le("orderStatus", DatabaseConstants.OrderStatuses.AfterApprovalProcessStarted));
				else if (lineType.equals(DatabaseConstants.OrderLineTypes.CONTROLSFAILED))
					criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.RecipientBankCodeError))
									   .add(Restrictions.lt("orderStatus", DatabaseConstants.OrderStatuses.Waiting));
				else if (lineType.equals(DatabaseConstants.OrderLineTypes.TRANSFERFAILED))
					criteria = criteria.add(Restrictions.ge("orderStatus", DatabaseConstants.OrderStatuses.InsufficientBalance))
									   .add(Restrictions.lt("orderStatus", DatabaseConstants.OrderStatuses.Transfered));				
			}
			
			if (StringUtils.isNotBlank(amountOrder)) {				
				if (amountOrder.equals("D"))
					criteria = criteria.addOrder(Order.desc("amount"));
				else if (amountOrder.equals("A"))
					criteria = criteria.addOrder(Order.asc("amount"));
			} else 
				criteria = criteria.addOrder(Order.asc("lineNumber"));
			
			List<OrderMain> orderList = criteria.list();
			
			int count = 0;
			for (OrderMain order : orderList) {
				query = QueryRepository.OrderLoadingServicesRepository.COS_ORDER_STATUS_PARAM_TEXT_QUERY;
				orderStatus = DALUtil.getResult(String.format(query, order.getOrderStatus()));
				query = QueryRepository.OrderLoadingServicesRepository.COS_ORDER_TYPE_PARAM_TEXT_QUERY;
				orderType = DALUtil.getResult(String.format(query, order.getOrderType()));
				if (!StringUtils.isEmpty(order.getRecipientDateOfBirth()))
					recipientDateOfBirth = CommonHelper.shortTimeStringToViewDateString(order.getRecipientDateOfBirth());
				
				if (StringUtils.isNotBlank(lineType) && lineType.equals(DatabaseConstants.OrderLineTypes.CONTROLSSUCCESSFUL) && !queryScreen.booleanValue())
					output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT, false);
				else
					output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.SELECT, true);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_NAME, order.getRecipientName()); 
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_ADDRESS, order.getRecipientAddress());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_MOTHER_NAME, order.getRecipientMotherName());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_FATHER_NAME, order.getRecipientFatherName());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_BANK, order.getRecipientBank());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_DATE_OF_BIRTH, recipientDateOfBirth);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_EMAIL, order.getRecipientEmail());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_ACCOUNT_NO, order.getRecipientAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_IBAN, order.getRecipientIban());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_CC_NO, order.getRecipientCcNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_REF_NO, order.getRecipientRefNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_BRANCH, order.getRecipientBranch());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_TCKN, order.getRecipientTckn());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_PHONE_NUMBER, order.getRecipientPhoneNumber());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.RECIPIENT_VKN, order.getRecipientVkn());				
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ACCOUNT_NO, order.getAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ERROR_DESCRIPTION, order.getErrorDesc());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.EXPLANATION, order.getExplanation());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS, orderStatus);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_STATUS_CODE, order.getOrderStatus());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.ORDER_TYPE, orderType);
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TX_NO, order.getTxNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.COMMISSION_ACCOUNT_NO, order.getCommissionAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.COMMISSION_AMOUNT, order.getCommissionAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.CURRENCY_CODE, order.getCurrencyCode());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_AMOUNT, order.getTransferAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_TYPE, order.getTransferType());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.AMOUNT, order.getAmount());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TAX_OFFICE, order.getTaxOffice());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.MAIN_OID, order.getOid());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.EFT_SORGU_NO, order.getEftSorguNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.FIS_NO, order.getFisNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.PAYMENT_ACCOUNT_NO, order.getPaymentAccountNo());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSACTION_CREATE_USER, order.getTransactionCreateUser());
				output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSACTION_APPROVE_USER, order.getTransactionApproveUser());				
				if (order.getTransferDate() != null) {
					transferDate = dateFormat.parse(CommonHelper.longTimeStringToViewDateString(order.getTransferDate()));
					transferTime = CommonHelper.longTimeStringToViewTimeString(order.getTransferDate());					
					output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_DATE, transferDate);
					output.put(tableName, count, TransactionConstants.GetOrderFileContent.Output.TRANSFER_TIME, transferTime.replace(":", ""));
				}
				count++;
			}	
						
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }
	 
	@GraymoundService("COS_SELECT_DESELECT_ALL_ORDERS")
	public static GMMap editCorpAccount(GMMap input) {
		GMMap output = new GMMap();
		try {
			String tableName = TransactionConstants.GetOrderFileContent.tableName;
			boolean selectAll = input.getBoolean(TransactionConstants.GetOrderFileContent.Input.SELECT_ALL);
			output.put(tableName, input.get(tableName));
			if (selectAll)
				for (int i = 0; i < input.getSize(tableName); i++ ) {
					output.put(tableName, i, TransactionConstants.GetOrderFileContent.Output.SELECT, true);
				}
			else
				for (int i = 0; i < input.getSize(tableName); i++ ) {
					output.put(tableName, i, TransactionConstants.GetOrderFileContent.Output.SELECT, false);
				}
			
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	}			

	 
	 @SuppressWarnings("unchecked")
	 @GraymoundService("COS_ROLLBACK_LOADING")
	 public static GMMap rollbackLoading (GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			OrderFileLog fileLog = null;
			String submitId = input.getString(TransactionConstants.GetErrorLines.Input.SUBMIT_ID);
			String orderStatus = null;
			boolean isRollbackAllowed = true;
			
			List<OrderMain> orderList = hibernateSession.createCriteria(OrderMain.class)
										.add(Restrictions.eq("status", true))
										.add(Restrictions.eq("batchSubmitId", submitId)).list();
			for (OrderMain order : orderList) {
				orderStatus = order.getOrderStatus();
				if (isRollbackAllowed && !StringUtils.isEmpty(orderStatus) && new BigDecimal(orderStatus).compareTo(new BigDecimal(DatabaseConstants.OrderStatuses.RepeatedOrder)) > 0 )
					isRollbackAllowed = false;
			}
			
			if (!isRollbackAllowed)
				CommonHelper.throwBusinessException(new BatchComponentException(BusinessException.ROLLBACKISNOTALLOWED));
			
			for (OrderMain order : orderList) {
				order.setStatus(false);
				hibernateSession.update(order);
			}			
			fileLog = (OrderFileLog) hibernateSession.createCriteria(OrderFileLog.class)
											.add(Restrictions.eq("status", true))
						  					.add(Restrictions.eq("batchSubmitId", submitId)).uniqueResult();
			if (fileLog != null) {
				fileLog.setFileStatus(DatabaseConstants.FileStatuses.LOADINGROLLBACK);
				hibernateSession.update(fileLog);
			}			
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }
	 
	@SuppressWarnings("unchecked")
	@GraymoundService("COS_GET_ERROR_LINES")
	 public static GMMap getErrorLines(GMMap input) {
		GMMap output = new GMMap();
		try {	
			Session hibernateSession = CommonHelper.getHibernateSession();
			String tableName = TransactionConstants.GetErrorLines.tableName;
			
			String submitId = input.getString(TransactionConstants.GetErrorLines.Input.SUBMIT_ID);
			String errorType = input.getString(TransactionConstants.GetErrorLines.Input.ERROR_TYPE);
			int count = 0;
			
			if (errorType.equals(DatabaseConstants.ErrorTypes.LOADINGERROR)) {
				List<FileErrorLog> loadingErrorList = hibernateSession.createCriteria(FileErrorLog.class)
													.add(Restrictions.eq("status", true))
								  					.add(Restrictions.eq("batchSubmitId", submitId))
													.addOrder(Order.asc("lineNumber")).list();	
				for (FileErrorLog loadingError : loadingErrorList) {
					output.put(tableName, count, TransactionConstants.GetErrorLines.Output.LINE_NUMBER, loadingError.getLineNumber());
					output.put(tableName, count, TransactionConstants.GetErrorLines.Output.LINE_CONTENT, loadingError.getErroneousLine());
					output.put(tableName, count, TransactionConstants.GetErrorLines.Output.ERROR_DESCRIPTION, loadingError.getErrorDesc());
				}				
			}
			
			hibernateSession.flush();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
		return output;
	 }
	
	@GraymoundService("COS_GET_LINE_TYPE_COMBO")
	public static GMMap getLineTypeCombo(GMMap iMap) {		
		return CorporationServiceUtil.getComboValues(iMap);
	}
	
	@GraymoundService("COS_GET_LINE_TYPE_COMBO_FOR_APPROVER")
	public static GMMap getLineTypeComboForApprover(GMMap iMap) {		
		return CorporationServiceUtil.getComboValues(iMap);
	}
}

