package tr.com.aktifbank.bnspr.cos.transactions;

import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;

import com.graymound.util.GMMap;

public abstract class ParallelRequestHandler extends RequestHandler {

	public ParallelRequestHandler() {
		super();
	}
	
	@Override
	public GMMap handle(GMMap input) {
		GMMap output = super.handle(input);
		output.put(TransactionConstants.ParallelCall.Output.T_SERVICE_NAME, input.getString(TransactionConstants.ParallelCall.Input.T_SERVICE_NAME, null));
		output.put(TransactionConstants.ParallelCall.Output.T_TASK_INDEX, input.getString(TransactionConstants.ParallelCall.Input.T_TASK_INDEX, null));
		
		return output;
	}
}
