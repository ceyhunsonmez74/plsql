package tr.com.aktifbank.bnspr.cos.transactions;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.CommonHelper;
import tr.com.aktifbank.bnspr.cos.common.DatabaseConstants;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.cps.common.QueryRepository;
import tr.com.aktifbank.bnspr.dao.OrderMain;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

public class CheckRepeatedOrderHandler extends RequestHandler {

	public CheckRepeatedOrderHandler() {
		super();
	}

	String tableName = "REPEATED_ORDER_GROUPS";
	
	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {

		String corporateCode = input.getString(TransactionConstants.CheckRepeatedOrder.Input.CORPORATE_CODE);
		Date processDate = input.getDate(TransactionConstants.CheckRepeatedOrder.Input.PROCESS_DATE);
		String batchSubmitId = input.getString(TransactionConstants.CheckRepeatedOrder.Input.BATCH_SUBMIT_ID);
		String query = null, shortProcessDate = null;
		OrderMain order = null;

		if (processDate != null)
			shortProcessDate = CommonHelper.getShortDateTimeString(processDate);	
		
		query = String.format(QueryRepository.CheckRepeatedOrderHandlerRepository.REPEATED_ORDERS_QUERY, DatabaseConstants.OrderStatuses.Waiting, shortProcessDate, corporateCode);

		GMMap repeatedOrderGroups =  DALUtil.getResults(query, tableName);
				
		for (int i = 0; i < repeatedOrderGroups.getSize(tableName); i++) {
			String repeatedOids = repeatedOrderGroups.getString(tableName, i, "REPEATED_OIDS");
			List<String> repeatedOidList = Arrays.asList(repeatedOids.split("[ ]"));
			
			for (String repeatedOid : repeatedOidList) {
				order = (OrderMain) super.getHibernateSession().createCriteria(OrderMain.class)
									.add(Restrictions.eq("status", true))
									.add(Restrictions.eq("oid", repeatedOid)).uniqueResult();						
				if (order != null) {
					if (batchSubmitId.equals(order.getBatchSubmitId()) && order.getOrderStatus().equals(DatabaseConstants.OrderStatuses.Waiting)) {
						order.setOrderStatus(DatabaseConstants.OrderStatuses.RepeatedOrder);
						super.getHibernateSession().update(order);												
					}
				}
			}	
		}
		
		super.getHibernateSession().flush();												
	}


}
