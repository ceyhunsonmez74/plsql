package tr.com.aktifbank.bnspr.cos.transactions;



import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.cos.common.BatchComponentException;
import tr.com.aktifbank.bnspr.cos.common.BusinessException;
import tr.com.aktifbank.bnspr.cos.common.TransactionConstants;
import tr.com.aktifbank.bnspr.dao.CorporateOrderParameters;
import tr.com.aktifbank.bnspr.dao.CorporationDef;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.util.GMMap;

public final class GetOrderCorpDefHandler extends RequestHandler {

	public GetOrderCorpDefHandler() {
		super();
	}

	@Override
	protected void handleInternal(GMMap input, GMMap output) throws Throwable {
		String corporateCode = input.getString(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_CODE, null);
		String corporateOid = input.getString(TransactionConstants.GetOrderCorpDef.Inputs.CORPORATE_OID, null);
		boolean throwsException = input.getBoolean(TransactionConstants.GetOrderCorpDef.Inputs.THROWS_EXCEPTION, true);
		Criteria query = super.getHibernateSession().createCriteria(CorporationDef.class)
													.add(Restrictions.eq("status", true));
		CorporationDef corpDef = null;
		if(corporateCode != null){
			corpDef = (CorporationDef)query.add(Restrictions.eq("corporateCode", corporateCode)).uniqueResult();
		}
		else if(corporateOid != null){
			corpDef = (CorporationDef)query.add(Restrictions.eq("oid", corporateOid)).uniqueResult();
		}
		else{
			throw new Exception("Neither corporate code and nor corporate oid is present in request");
		}
		
		if (corpDef != null) {
			output.put(TransactionConstants.GetOrderCorpDef.Output.RESULT, true);
			output.put(TransactionConstants.GetOrderCorpDef.Output.CORPORATE_ACTIVENESS, corpDef.getActiveness());
			output.put(TransactionConstants.GetOrderCorpDef.Output.CORPORATE_NAME, corpDef.getCorporateName());
			output.put(TransactionConstants.GetOrderCorpDef.Output.SHORT_NAME, corpDef.getShortName());
			output.put(TransactionConstants.GetOrderCorpDef.Output.CORPORATE_CODE, corpDef.getCorporateCode());
			output.put(TransactionConstants.GetOrderCorpDef.Output.CORPORATE_OID, corpDef.getOid());
			output.put(TransactionConstants.GetOrderCorpDef.Output.CUSTOMER_NO, corpDef.getCustomerNo());
			
			CorporateOrderParameters corpParam = (CorporateOrderParameters) super.getHibernateSession().createCriteria(CorporateOrderParameters.class)
														.add(Restrictions.eq("status", true))
														.add(Restrictions.eq("corporateOid", corpDef.getOid())).uniqueResult();

			if (corpParam != null) {
				output.put(TransactionConstants.GetOrderCorpDef.Output.MAKE_LOADING_STATUS_FILE, corpParam.isMakeLoadingStatusFile());
				output.put(TransactionConstants.GetOrderCorpDef.Output.MAKE_TRANSFER_STATUS_FILE, corpParam.isMakeTransferStatusFile());
				output.put(TransactionConstants.GetOrderCorpDef.Output.MAKE_EOD_STATUS_FILE, corpParam.getMakeEodStatusFile());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_TO_RECIPIENT, corpParam.isSmsToRecipient());							
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_TO_RECIPIENT, corpParam.isEmailToRecipient());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_LOADING_STATUS, corpParam.isEmailLoadingStatus());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_TRANSFER_STATUS, corpParam.isEmailTransferStatus());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_EOD_STATUS, corpParam.isEmailEodStatus());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.CHECK_VKN, corpParam.isCheckVkn());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.CHECK_TCKN, corpParam.isCheckTckn());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.ALLOW_TRANSFER_TO_VALID, corpParam.isAllowTransferToValid());
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_RECEIPT_TO_RECIPIENT, corpParam.getEmailReceiptToRecipient());
				output.put(TransactionConstants.GetOrderCorpDef.Output.TRANSFER_WITHOUT_APPROVAL, corpParam.getTransferWithoutApproval());	
				output.put(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING, corpParam.getAmountOrder());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.CHECK_RECIPIENTS, corpParam.isCheckRecipients());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.LOADING_EMAIL, corpParam.getLoadingEmail());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.TRANSFER_EMAIL, corpParam.getTransferEmail());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EOD_EMAIL, corpParam.getEodEmail());		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EOD_EMAIL_TIME, corpParam.getEodEmailTime());
				if (!StringUtils.isEmpty(corpParam.getSmsOrderType())) {
					output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_EFT, corpParam.getSmsOrderType().substring(0,1).equals("1") ? true : false );
					output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_HAVALE, corpParam.getSmsOrderType().substring(1,2).equals("1") ? true : false );
					output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_VIRMAN, corpParam.getSmsOrderType().substring(2,3).equals("1") ? true : false );
					output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_PTT_ISME_HAVALE, corpParam.getSmsOrderType().substring(3,4).equals("1") ? true : false );
				} else {
					output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_EFT, false);
					output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_HAVALE, false);
					output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_VIRMAN, false);
					output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_PTT_ISME_HAVALE, false);					
				}
			} else {
				output.put(TransactionConstants.GetOrderCorpDef.Output.MAKE_LOADING_STATUS_FILE, false);
				output.put(TransactionConstants.GetOrderCorpDef.Output.MAKE_TRANSFER_STATUS_FILE, false);
				output.put(TransactionConstants.GetOrderCorpDef.Output.MAKE_EOD_STATUS_FILE, "");		
				output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_TO_RECIPIENT, false);
				output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_EFT, false);
				output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_HAVALE, false);
				output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_VIRMAN, false);
				output.put(TransactionConstants.GetOrderCorpDef.Output.SMS_FOR_PTT_ISME_HAVALE, false);
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_TO_RECIPIENT, false);		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_LOADING_STATUS, false);		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_TRANSFER_STATUS, false);		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EMAIL_EOD_STATUS, false);		
				output.put(TransactionConstants.GetOrderCorpDef.Output.CHECK_VKN, false);		
				output.put(TransactionConstants.GetOrderCorpDef.Output.CHECK_TCKN, false);		
				output.put(TransactionConstants.GetOrderCorpDef.Output.ALLOW_TRANSFER_TO_VALID, false);
				output.put(TransactionConstants.GetOrderCorpDef.Output.TRANSFER_WITHOUT_APPROVAL, false);		
				output.put(TransactionConstants.GetOrderCorpDef.Output.AMOUNT_ORDERING, "");		
				output.put(TransactionConstants.GetOrderCorpDef.Output.CHECK_RECIPIENTS, false);		
				output.put(TransactionConstants.GetOrderCorpDef.Output.LOADING_EMAIL, "");		
				output.put(TransactionConstants.GetOrderCorpDef.Output.TRANSFER_EMAIL, "");		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EOD_EMAIL, "");		
				output.put(TransactionConstants.GetOrderCorpDef.Output.EOD_EMAIL_TIME, "");		
			}
		}
		else{
			if(throwsException){
				throw new BatchComponentException(BusinessException.ORDERCORPORATENOTFOUND, StringUtil.isEmpty(corporateCode) ? corporateOid : corporateCode);
			}
			else{
				output.put(TransactionConstants.GetOrderCorpDef.Output.RESULT, false);
			}
		}

	}

}
