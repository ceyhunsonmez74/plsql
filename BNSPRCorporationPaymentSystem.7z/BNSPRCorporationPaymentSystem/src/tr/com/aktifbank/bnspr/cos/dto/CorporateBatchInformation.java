package tr.com.aktifbank.bnspr.cos.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.graymound.util.GMMap;

public final class CorporateBatchInformation extends BaseTransferObject {

	public CorporateBatchInformation() {
		super();
	}

	private String corporateCode;
	private String serviceName;
	private List<FormatDetail> headerDetails;
	private List<FormatDetail> bodyDetails;
	private List<FormatDetail> footerDetails;
	private Date orderDate;
	private BigDecimal ftmProcessId;
	private List<ItemDatabaseField> databaseFields;
	private List<ItemServiceField> serviceFields;
	private GMMap batchParameters;
	private short informIndicator;
	private BigDecimal loadingFtmSequenceNumber;
	private String loadingBatchSubmitId;
	private Date processDate;
	
	public short getInformIndicator() {
		return informIndicator;
	}
	public void setInformIndicator(short informIndicator) {
		this.informIndicator = informIndicator;
	}
	public GMMap getBatchParameters() {
		return batchParameters;
	}
	public void setBatchParameters(GMMap batchParameters) {
		this.batchParameters = batchParameters;
	}
	public BigDecimal getFtmProcessId() {
		return ftmProcessId;
	}
	public void setFtmProcessId(BigDecimal ftmProcessId) {
		this.ftmProcessId = ftmProcessId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public String getCorporateCode() {
		return corporateCode;
	}
	public void setCorporateCode(String corporateCode) {
		this.corporateCode = corporateCode;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}	
	public List<FormatDetail> getHeaderDetails() {
		return headerDetails;
	}
	public void setHeaderDetails(List<FormatDetail> headerDetails) {
		this.headerDetails = headerDetails;
	}
	public List<FormatDetail> getBodyDetails() {
		return bodyDetails;
	}
	public void setBodyDetails(List<FormatDetail> bodyDetails) {
		this.bodyDetails = bodyDetails;
	}
	public List<FormatDetail> getFooterDetails() {
		return footerDetails;
	}
	public void setFooterDetails(List<FormatDetail> footerDetails) {
		this.footerDetails = footerDetails;
	}	
	public List<ItemDatabaseField> getDatabaseFields() {
		return databaseFields;
	}
	public void setDatabaseFields(List<ItemDatabaseField> databaseFields) {
		this.databaseFields = databaseFields;
	}
	public List<ItemServiceField> getServiceFields() {
		return serviceFields;
	}
	public void setServiceFields(List<ItemServiceField> serviceFields) {
		this.serviceFields = serviceFields;
	}	
	public BigDecimal getLoadingFtmSequenceNumber() {
		return loadingFtmSequenceNumber;
	}
	public void setLoadingFtmSequenceNumber(BigDecimal loadingFtmSequenceNumber) {
		this.loadingFtmSequenceNumber = loadingFtmSequenceNumber;
	}
	public String getLoadingBatchSubmitId() {
		return loadingBatchSubmitId;
	}
	public void setLoadingBatchSubmitId(String loadingBatchSubmitId) {
		this.loadingBatchSubmitId = loadingBatchSubmitId;
	}
	public Date getProcessDate() {
		return processDate;
	}
	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}
}
