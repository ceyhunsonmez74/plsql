package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.AdkKategori;
import tr.com.aktifbank.bnspr.dao.AdkKategoriislem;
import tr.com.aktifbank.bnspr.dao.AdkKategoriislemId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcIslemKategoriTanimlamaServices {
	@GraymoundService("ISLEM_KATEGORI_TANIMLAMA_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			oMap.putAll(GMServiceExecuter.execute("GET_PROCESS_LIST", iMap));
			List<?> listProcess = (List<?>) oMap.get("PROCESS_LIST");
			oMap.remove("PROCESS_LIST");
			List<AdkKategori> kategoriList = (List<AdkKategori>) session.createCriteria(AdkKategori.class).list();
			List<AdkKategoriislem> kategoriislemList = (List<AdkKategoriislem>) session.createCriteria(AdkKategoriislem.class).list();
			for(int j=0;j<kategoriislemList.size();j++){
				int temp = 0;							
				for(int k=1;k<listProcess.size();k++){
					GMMap row = new GMMap((HashMap<?, ?>)listProcess.get(k));
					if((kategoriislemList.get(j).getId().getIslemOid().equals(row.getString("OID")))){
						temp = 1;
					}
				}if(temp==0){
					session.delete(kategoriislemList.remove(j--));
				}
			}
			for(int i=0;i<kategoriList.size();i++){
				String kategoriOid = kategoriList.get(i).getOid();
				oMap.put("KATEGORI_LIST",i,"OID",kategoriOid);
				oMap.put("KATEGORI_LIST",i,"MAIN",kategoriList.get(i).getMain());
				oMap.put("KATEGORI_LIST",i,"NAME",kategoriList.get(i).getName());
				oMap.put("KATEGORI_LIST",i,"SIL",0);
				for(int k=1;k<listProcess.size();k++){
					GMMap row = new GMMap((HashMap<?, ?>)listProcess.get(k));
					int temp = 0;
					String islemOid = row.getString("OID");
					oMap.put("TEMP",k-1,"OID", islemOid);
					oMap.put("TEMP",k-1,"CODE", row.get("CODE"));
					oMap.put("TEMP",k-1,"NAME", row.get("NAME"));				
					for(int j=0;j<kategoriislemList.size();j++){
						if((kategoriislemList.get(j).getId().getIslemOid().equals(islemOid)) && (kategoriislemList.get(j).getId().getKategoriOid().equals(kategoriOid))){
							temp = 1;
						}
					}
					oMap.put("TEMP",k-1,"SEC", temp);
					oMap.put("TEMP",k-1,"SEC_ILK", temp);
				}
				oMap.put("KATEGORI_LIST",i,"MODEL_DATA",oMap.get("TEMP"));
				oMap.remove("TEMP");
			}
			for(int k=1;k<listProcess.size();k++){  // 0 Se�iniz oldu�undan 1 kullan�ld�.
				GMMap row = new GMMap((HashMap<?, ?>)listProcess.get(k));
				oMap.put("PROCESS_LIST",k-1,"OID",  row.get("OID"));
				oMap.put("PROCESS_LIST",k-1,"CODE", row.get("CODE"));
				oMap.put("PROCESS_LIST",k-1,"NAME", row.get("NAME"));				
				oMap.put("PROCESS_LIST",k-1,"SEC", 0);
				oMap.put("PROCESS_LIST",k-1,"SEC_ILK", 0);
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("ISLEM_KATEGORI_TANIMLAMA_ADD_ROW")
	public static GMMap addRow(GMMap iMap) {
		try {
			int size = iMap.getSize("KATEGORI_LIST");
			iMap.put("KATEGORI_LIST",size,"OID","");
			iMap.put("KATEGORI_LIST",size,"NAME","");
			iMap.put("KATEGORI_LIST",size,"SIL",0);
			iMap.put("KATEGORI_LIST",size,"MAIN",0);		
			iMap.put("KATEGORI_LIST",size,"MODEL_DATA",iMap.get("PROCESS_LIST"));
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("ISLEM_KATEGORI_TANIMLAMA_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			int size = iMap.getSize("KATEGORI_LIST");
			for(int i=0;i<size;i++){
				if("AGENT".equals(iMap.getString("KATEGORI_LIST",i,"NAME"))){
					if(iMap.getInt("KATEGORI_LIST",i,"SIL") == 1){
						iMap.put("HATA_NO", new BigDecimal(1729));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					if(iMap.getInt("KATEGORI_LIST",i,"MAIN") == 1){
						iMap.put("HATA_NO", new BigDecimal(1730));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
				if("SONON".equals(iMap.getString("KATEGORI_LIST",i,"NAME"))){
					if(iMap.getInt("KATEGORI_LIST",i,"SIL") == 1){
						iMap.put("HATA_NO", new BigDecimal(1761));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					if(iMap.getInt("KATEGORI_LIST",i,"MAIN") == 1){
						iMap.put("HATA_NO", new BigDecimal(1762));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
				if("SONONDLR".equals(iMap.getString("KATEGORI_LIST",i,"NAME"))){
					if(iMap.getInt("KATEGORI_LIST",i,"SIL") == 1){
						iMap.put("HATA_NO", new BigDecimal(1790));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					if(iMap.getInt("KATEGORI_LIST",i,"MAIN") == 1){
						iMap.put("HATA_NO", new BigDecimal(1791));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
				if("INBOUNDCALL".equals(iMap.getString("KATEGORI_LIST",i,"NAME"))){
					if(iMap.getInt("KATEGORI_LIST",i,"SIL") == 1){
						iMap.put("HATA_NO", new BigDecimal(1781));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					if(iMap.getInt("KATEGORI_LIST",i,"MAIN") == 1){
						iMap.put("HATA_NO", new BigDecimal(1782));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
				if("OUTBOUNDCALL".equals(iMap.getString("KATEGORI_LIST",i,"NAME"))){
					if(iMap.getInt("KATEGORI_LIST",i,"SIL") == 1){
						iMap.put("HATA_NO", new BigDecimal(1822));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					if(iMap.getInt("KATEGORI_LIST",i,"MAIN") == 1){
						iMap.put("HATA_NO", new BigDecimal(1823));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
				if("ACCTRNS".equals(iMap.getString("KATEGORI_LIST",i,"NAME"))){
					if(iMap.getInt("KATEGORI_LIST",i,"SIL") == 1){
						iMap.put("HATA_NO", new BigDecimal(1783));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					if(iMap.getInt("KATEGORI_LIST",i,"MAIN") == 1){
						iMap.put("HATA_NO", new BigDecimal(1784));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
				if((iMap.getInt("KATEGORI_LIST",i,"SIL") == 0) && (iMap.getInt("KATEGORI_LIST",i,"MAIN") == 1)){
					for(int k=i+1;k<size;k++){
						if((iMap.getInt("KATEGORI_LIST",k,"SIL") == 0) && (iMap.getInt("KATEGORI_LIST",k,"MAIN") == 1)){
							List<?> listProcess = (List<?>) iMap.get("KATEGORI_LIST",i,"MODEL_DATA");
							for(int j=0;j<listProcess.size();j++){
								GMMap row = new GMMap((HashMap<?, ?>)listProcess.get(j));
								if(row.getInt("SEC")==1){
									String oid = row.getString("OID");
									List<?> listProcess2 = (List<?>) iMap.get("KATEGORI_LIST",k,"MODEL_DATA");
									for(int m=0;m<listProcess2.size();m++){
										GMMap row2 = new GMMap((HashMap<?, ?>)listProcess2.get(m));
										if(row2.getInt("SEC")==1 && oid.equals(row2.getString("OID"))){
											iMap.put("HATA_NO", new BigDecimal(1727));
											GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
										}
									}
								}
							}							
						}
					}
				}
			}
			for(int i=0;i<size;i++){
				if(iMap.getInt("KATEGORI_LIST",i,"SIL") == 1){
					if("" != iMap.getString("KATEGORI_LIST",i,"OID")){
						AdkKategori adkKategori = (AdkKategori)session.get(AdkKategori.class, iMap.getString("KATEGORI_LIST",i,"OID"));
						session.delete(adkKategori);
					}
				}else{
					String kategoriOid =  iMap.getString("KATEGORI_LIST",i,"OID");
					if("".equals(kategoriOid) ){
						AdkKategori adkKategori = new AdkKategori();
						adkKategori.setName(iMap.getString("KATEGORI_LIST",i,"NAME"));
						adkKategori.setMain(iMap.getInt("KATEGORI_LIST",i,"MAIN"));
						session.save(adkKategori);
						kategoriOid = adkKategori.getOid();
					}else{
						AdkKategori adkKategori = (AdkKategori)session.get(AdkKategori.class, iMap.getString("KATEGORI_LIST",i,"OID"));
						adkKategori.setName(iMap.getString("KATEGORI_LIST",i,"NAME"));
						adkKategori.setMain(iMap.getInt("KATEGORI_LIST",i,"MAIN"));
						session.save(adkKategori);
					}
					List<?> listProcess = (List<?>) iMap.get("KATEGORI_LIST",i,"MODEL_DATA");
					for(int k=0;k<listProcess.size();k++){
						GMMap row = new GMMap((HashMap<?, ?>)listProcess.get(k));
						if(row.getInt("SEC") != row.getInt("SEC_ILK")){
							if(row.getInt("SEC") == 1){
								AdkKategoriislemId adkKategoriislemId = new AdkKategoriislemId();
								adkKategoriislemId.setKategoriOid(kategoriOid);
								adkKategoriislemId.setIslemOid(row.getString("OID"));
								AdkKategoriislem adkKategoriislem = new AdkKategoriislem();
								adkKategoriislem.setId(adkKategoriislemId);
								session.save(adkKategoriislem);
							}else{
								AdkKategoriislem adkKategoriislem = (AdkKategoriislem) session.createCriteria(AdkKategoriislem.class).add(Restrictions.eq("id.kategoriOid", kategoriOid))
								.add(Restrictions.eq("id.islemOid", row.getString("OID")))
								.uniqueResult();
								session.delete(adkKategoriislem);
							}
						}
					}
				} 
			}
			iMap.put("MESSAGE_NO", new BigDecimal(711));
			iMap.put("MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
