package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKanalOtpTanimPrTx;
import tr.com.calikbank.bnspr.dao.GnlKanalOtpTanimPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4151Services {
	
	
	@GraymoundService("BNSPR_TRN4151_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			GuimlUtil.wrapMyCombo(oMap, "OTP_KONTROL_YONTEM", 0, "S", "Session�da 1 Tane");
			GuimlUtil.wrapMyCombo(oMap, "OTP_KONTROL_YONTEM", 1, "H", "Her ��lemde");	

			DALUtil.fillComboBox(oMap, "KANAL_KOD", true, "SELECT KOD ,ACIKLAMA FROM V_ML_GNL_KANAL_GRUP_KOD_PR ORDER BY TO_NUMBER(KOD)"); 
		
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY4151_KANAL_OTP_PARAMETRE")
	public static GMMap KanalOTPParametre(GMMap iMap)throws ParseException{

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try{
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call  PKG_RC_ADC.RC_QRY4151_Kanal_OTP_Parametre}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "KULLANICI_ROLLERI";

			int row = 0;
			while (rSet.next()) {

				oMap.put(tableName, row, "KANAL_KOD", rSet.getBigDecimal("KANAL_KOD"));
				oMap.put(tableName, row, "OTP_MI", rSet.getString("OTP_UYGULAMASI"));
				oMap.put(tableName, row, "OTP_KONTROL_YONTEM", rSet.getString("OTP_KONTROL_YONTEMI"));
				oMap.put(tableName, row, "OTP_GIRIS_SURE",rSet.getBigDecimal("OTP_GIRIS_SURESI"));
				oMap.put(tableName, row, "OTP_DENEME_SAYISI",rSet.getBigDecimal("OTP_DENEME_SAYISI"));
			    oMap.put(tableName, row, "OTP_TALEP_ADET", rSet.getBigDecimal("OTP_TALEP_ADEDI"));
		
							
				row++;
			}
			return oMap;
		} catch (SQLException e) {
		  throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			

		}
	}

	@GraymoundService("BNSPR_4151_SAVE_KANAL_OTP_PAREMETRE")
	public static Map<?, ?> saveTRN4151saveKanalOTPParemetre(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "KULLANICI_ROLLERI";
			List<String> kanalList = new ArrayList<String>();
			String kanalKodu;
			List<?> list = (List<?>) iMap.get(tableName);
			for(int i=0; i<list.size();i++) {
				kanalKodu = iMap.getString(tableName, i, "KANAL_KOD");
				if(kanalKodu == null || kanalKodu.isEmpty())
				{
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Kanal Kodu");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}	
				GnlKanalOtpTanimPrTxId id = new GnlKanalOtpTanimPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKanalKod(kanalKodu);
				
				GnlKanalOtpTanimPrTx gnlKanalOtpTanimPrTx = (GnlKanalOtpTanimPrTx) session.get(GnlKanalOtpTanimPrTx.class, id);
				if (gnlKanalOtpTanimPrTx == null) {
				    gnlKanalOtpTanimPrTx = new GnlKanalOtpTanimPrTx();
				    gnlKanalOtpTanimPrTx.setId(id);
				    kanalList.add(kanalKodu);
				} else{
					if (kanalList.contains(kanalKodu)) {
						iMap.put("HATA_NO", new BigDecimal(716));
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					} 
					kanalList.add(kanalKodu);
				}

				gnlKanalOtpTanimPrTx.setOtpUygulamasi(iMap.getString(tableName, i, "OTP_MI"));
				gnlKanalOtpTanimPrTx.setOtpKontrolYontemi(iMap.getString(tableName, i, "OTP_KONTROL_YONTEM"));
				gnlKanalOtpTanimPrTx.setOtpGirisSuresi(iMap.getBigDecimal(tableName, i, "OTP_GIRIS_SURE"));
				gnlKanalOtpTanimPrTx.setOtpDenemeSayisi(iMap.getBigDecimal(tableName, i,"OTP_DENEME_SAYISI"));
				gnlKanalOtpTanimPrTx.setOtpTalepAdedi(iMap.getBigDecimal(tableName, i, "OTP_TALEP_ADET"));
				session.saveOrUpdate(gnlKanalOtpTanimPrTx);
		     }
		
			session.flush();

			iMap.put("TRX_NAME", "4151");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		/*catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(715));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}*/
		catch (Exception e) {
			System.out.println(e);
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN4151_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(GnlKanalOtpTanimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			String tableName = "KULLANICI_ROLLERI";
		
			int row = 0;
			GMMap oMap = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlKanalOtpTanimPrTx gnlKanalOtpTanimPrTx = (GnlKanalOtpTanimPrTx) iterator.next();
				oMap.put(tableName, row, "KANAL_KOD", gnlKanalOtpTanimPrTx.getId().getKanalKod());
				oMap.put(tableName, row, "OTP_MI", gnlKanalOtpTanimPrTx.getOtpUygulamasi());
				oMap.put(tableName, row, "OTP_KONTROL_YONTEM", gnlKanalOtpTanimPrTx.getOtpKontrolYontemi());
				oMap.put(tableName, row, "OTP_GIRIS_SURE", gnlKanalOtpTanimPrTx.getOtpGirisSuresi());
				oMap.put(tableName, row, "OTP_DENEME_SAYISI", gnlKanalOtpTanimPrTx.getOtpDenemeSayisi());
				oMap.put(tableName, row, "OTP_TALEP_ADET", gnlKanalOtpTanimPrTx.getOtpTalepAdedi());
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4151_AFTER_APPROVAL")
		public static GMMap AfterAproval(GMMap iMap) {
			try {
				Session session = DAOSession.getSession("BNSPRDal");
				List<?> list = (List<?>) session.createCriteria(GnlKanalOtpTanimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
				DALUtil.fillComboBox(iMap, "KANAL_KOD", true, "SELECT KOD,INTEGRATION_ID FROM V_ML_GNL_KANAL_GRUP_KOD_PR ORDER BY TO_NUMBER(KOD)");
				GMMap channelMap = new GMMap();
				for(int i=0;i<iMap.getSize("KANAL_KOD");i++){
					channelMap.put(iMap.getString("KANAL_KOD",i,"VALUE"),iMap.getString("KANAL_KOD",i,"NAME"));
				}
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					GnlKanalOtpTanimPrTx gnlKanalOtpTanimPrTx = (GnlKanalOtpTanimPrTx) iterator.next();
					String channel = channelMap.getString(gnlKanalOtpTanimPrTx.getId().getKanalKod());
					GMMap xMap = new GMMap();
					xMap.put("CHANNEL"		, channel);
					xMap.put("KEY"			, "ADC_OTP_ACTIVE");
					xMap.put("VALUE"		, "E".equals(gnlKanalOtpTanimPrTx.getOtpUygulamasi()));
					GMServiceExecuter.executeNT("ADC_CORE_CHANNEL_PARAMETER_REMOTE_UPDATE", (GMMap)xMap.clone());
					xMap.clear();
					xMap.put("CHANNEL"		, channel);
					xMap.put("KEY"			, "ADC_OTP_FAIL_COUNT");
					xMap.put("VALUE"		, gnlKanalOtpTanimPrTx.getOtpDenemeSayisi());
					GMServiceExecuter.executeNT("ADC_CORE_CHANNEL_PARAMETER_REMOTE_UPDATE", (GMMap)xMap.clone());
					xMap.clear();
					xMap.put("CHANNEL"		, channel);
					xMap.put("KEY"			, "ADC_OTP_UNUSED_COUNT");
					xMap.put("VALUE"		, gnlKanalOtpTanimPrTx.getOtpTalepAdedi());
					GMServiceExecuter.executeNT("ADC_CORE_CHANNEL_PARAMETER_REMOTE_UPDATE", (GMMap)xMap.clone());
					xMap.clear();
					xMap.put("CHANNEL"		, channel);
					xMap.put("KEY"			, "SNGL_OTP_PER_SESSN");
					xMap.put("VALUE"		, "S".equals(gnlKanalOtpTanimPrTx.getOtpKontrolYontemi()));
					GMServiceExecuter.executeNT("ADC_CORE_CHANNEL_PARAMETER_REMOTE_UPDATE", (GMMap)xMap.clone());
					xMap.clear();
					xMap.put("CHANNEL"		, channel);
					xMap.put("KEY"			, "ADC_OTP_TIMEOUT");
					xMap.put("VALUE"		, gnlKanalOtpTanimPrTx.getOtpGirisSuresi());
					GMServiceExecuter.executeNT("ADC_CORE_CHANNEL_PARAMETER_REMOTE_UPDATE", (GMMap)xMap.clone());
					xMap.put("SERVICE_NAME"	, "ADC_PARAMETER_REFRESH");
					xMap.put("CHANNEL_CODE"		, channel);					
					try{
						GMServiceExecuter.call("ADK_CALL_SERVICE", xMap);
					}catch(GMRuntimeException e){
						if(e.getCode()!=101) throw e;
					}	
				}
				return iMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			
	     }
	
}


