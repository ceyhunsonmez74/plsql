package tr.com.calikbank.bnspr.adc.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AdcQRY4210Services {
	
	
	@GraymoundService("BNSPR_TRN4210_SET_TABLE")
	public static GMMap adcOzetTablosu(GMMap iMap)throws ParseException{
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_RC4210.RC_QRY4210_Sifre_Sorgula (?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "LISTE_TABLOSU");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}
		
}
