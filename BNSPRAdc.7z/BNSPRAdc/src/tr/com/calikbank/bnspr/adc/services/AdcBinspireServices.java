package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcBinspireServices {
	@GraymoundService("BNSPR_KREDI_FAIZ_ORAN_TO_TURKLINE")
	public static GMMap krediFaizOranToTurkline(GMMap iMap) {
		Connection oracleConn = null;
		Connection sqlConn = null;
		CallableStatement oracleStmt = null;
		PreparedStatement sqlStmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			oracleConn = DALUtil.getGMConnection();
			sqlConn = DALUtil.getTurklineConnection();

			sqlStmt = sqlConn.prepareStatement("delete from KrediFaizOranlari");
			sqlStmt.execute();
			
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("insert into KrediFaizOranlari (ID,KrediTuru,DovizCinsi,Vade1,Vade2,Vade3,Vade4) ");
			sqlQuery.append("values (?,?,?,?,?,?,?)");
			sqlStmt = sqlConn.prepareStatement(sqlQuery.toString());
			
			oracleStmt = oracleConn.prepareCall("{? = call PKG_RC_ADC_TURKLINE.BNSPR_KREDI_FAIZ_ORAN_TURKLINE()}");
			oracleStmt.registerOutParameter(1, -10);
			oracleStmt.execute();
			rSet = (ResultSet)oracleStmt.getObject(1);
			int size = 0;
			while(rSet.next()) size++;
			
			oracleStmt.execute();
			rSet = (ResultSet)oracleStmt.getObject(1);
			String[][] matris = new String[size][7];
			
			String krediTuru;
			String doviz;
			String krediTurKod;
			int row = 0;
			boolean flag;
			while(rSet.next()){
				flag = false;
				krediTuru =  rSet.getString("KREDITURU");
				doviz = rSet.getString("DOVIZ");
				krediTurKod = rSet.getString("KRD_TUR_KOD");
				for(int i=0; i<row;i++){
					if(krediTuru.equals(matris[i][0])&&doviz.equals(matris[i][1])&&krediTurKod.equals(matris[i][2])){
						flag = true;
						if(rSet.getString("VADE").equals("VADE1")){
							matris[i][3] = rSet.getString("ORAN");
						}else if(rSet.getString("VADE").equals("VADE2")){
							matris[i][4] = rSet.getString("ORAN");
						}else if(rSet.getString("VADE").equals("VADE3")){
							matris[i][5] = rSet.getString("ORAN");
						}else if(rSet.getString("VADE").equals("VADE4")){
							matris[i][6] = rSet.getString("ORAN");
						}
						break;
					}
				}
				if(!flag){
					matris[row][0] = krediTuru;
					matris[row][1] = doviz;
					matris[row][2] = krediTurKod;
					if(rSet.getString("VADE").equals("VADE1")){
						matris[row][3] = rSet.getString("ORAN");
					}else if(rSet.getString("VADE").equals("VADE2")){
						matris[row][4] = rSet.getString("ORAN");
					}else if(rSet.getString("VADE").equals("VADE3")){
						matris[row][5] = rSet.getString("ORAN");
					}else if(rSet.getString("VADE").equals("VADE4")){
						matris[row][6] = rSet.getString("ORAN");
					}
					row++;
				}			
			}
			
			
			for(int i=0; i<row; i++){ 
				int j = 1;
				sqlStmt.setInt(j++,i);
				sqlStmt.setString(j++, matris[i][0]);
				sqlStmt.setString(j++, matris[i][1]);
				sqlStmt.setString(j++, matris[i][3]);
				sqlStmt.setString(j++, matris[i][4]);
				sqlStmt.setString(j++, matris[i][5]);
				sqlStmt.setString(j++, matris[i][6]);
				
				sqlStmt.execute();
			}
		} catch (Exception e) {
			throw new GMRuntimeException(0, "TurkLine Aktar�m�nda hata al�nd�");
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(oracleStmt);
			GMServerDatasource.close(sqlStmt);
			GMServerDatasource.close(sqlConn);
			GMServerDatasource.close(oracleConn);
			
		}
		return oMap;
	}
	@GraymoundService("BNSPR_DOVIZ_KURLARI_TO_TURKLINE")
	public static GMMap dovizKurlariToTurkline(GMMap iMap) {
		Connection oracleConn = null;
		Connection sqlConn = null;
		CallableStatement oracleStmt = null;
		PreparedStatement sqlStmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
            oracleConn = DALUtil.getGMConnection();
            sqlConn = DALUtil.getTurklineConnection();
			
			sqlStmt = sqlConn.prepareStatement("delete from DovizKurlari ");
			sqlStmt.execute();
			
			StringBuilder sqlQuery = new StringBuilder()
			.append("insert into DovizKurlari (DovizCinsi,AlisKuru,SatisKuru) ")
			.append("values (?,?,?) ");
			sqlStmt = sqlConn.prepareStatement(sqlQuery.toString());
			
			oracleStmt = oracleConn.prepareCall("{? = call PKG_RC_ADC_TURKLINE.BNSPR_DOVIZ_KURLARI_TURKLINE()}");
			oracleStmt.registerOutParameter(1, -10);
			oracleStmt.execute();
			oracleStmt.getMoreResults();
			rSet = (ResultSet)oracleStmt.getObject(1);
			while(rSet.next()){
				int i = 1;
				sqlStmt.setString(i++, rSet.getString("DOVIZ_KOD"));
				sqlStmt.setObject(i++, rSet.getBigDecimal("ALIS_DEGERI"),Types.DECIMAL);
				sqlStmt.setObject(i++, rSet.getBigDecimal("SATIS_DEGERI"),Types.DECIMAL);
				
				sqlStmt.execute();
			}
		} catch (Exception e) {
			throw new GMRuntimeException(0, "TurkLine Doviz Kurlar� aktar�m�nda hata al�nd� ");
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(oracleStmt);
			GMServerDatasource.close(sqlStmt);
			GMServerDatasource.close(oracleConn);
			GMServerDatasource.close(sqlConn);
			
		}
		return oMap;
	}
	@GraymoundService("BNSPR_SET_TURKLINE_KREDITUR_DATA")
	public static GMMap setTurklineKrediTurData(GMMap iMap) {
		Connection oracleConn = null;
		Connection sqlConn = null;
		CallableStatement oracleStmt = null;
		PreparedStatement sqlStmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
            oracleConn = DALUtil.getGMConnection();
            sqlConn = DALUtil.getTurklineConnection();
			
			StringBuilder sqlInsertQuery = new StringBuilder()
				.append("insert into KrediTur (UstKod,KrediTurID,Tur,MinVade,MaxVade,MinTutar,MaxTutar) ")
				.append("values (?,?,?,?,?,?,?) ");
			
			oracleStmt = oracleConn.prepareCall("{? = call PKG_RC_ADC_TURKLINE.BNSPR_TURKLINE_KREDITUR_DATA()}");		
			oracleStmt.registerOutParameter(1, -10);
			oracleStmt.execute();
			rSet = (ResultSet)oracleStmt.getObject(1);
			while(rSet.next()){
				int i = 1;
	
				sqlStmt = sqlConn.prepareStatement(sqlInsertQuery.toString());
				sqlStmt.setString(i++, rSet.getString("UST_KOD"));
				sqlStmt.setObject(i++, rSet.getBigDecimal("KREDITUR_ID"),Types.DECIMAL);
				sqlStmt.setString(i++, rSet.getString("TUR"));
				sqlStmt.setObject(i++, rSet.getBigDecimal("MIN_VADE"),Types.DECIMAL);
				sqlStmt.setObject(i++, rSet.getBigDecimal("MAX_VADE"),Types.DECIMAL);
				sqlStmt.setObject(i++, rSet.getBigDecimal("MIN_TUTAR"),Types.DECIMAL);
				sqlStmt.setObject(i++, rSet.getBigDecimal("MAX_TUTAR"),Types.DECIMAL);
			
				sqlStmt.execute();
			}
		} catch (Exception e) {
			throw new GMRuntimeException(0, "TurkLine aktar�mda hata al�nd�");
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(oracleStmt);
			GMServerDatasource.close(sqlStmt);
			GMServerDatasource.close(sqlConn);
			GMServerDatasource.close(oracleConn);
			
		}
		return oMap;
	}
	@GraymoundService("BNSPR_SET_TURKLINE_KREDI_DATA")
	public static GMMap setTurklineKrediData(GMMap iMap) {
		Connection oracleConn = null;
		Connection sqlConn = null;
		CallableStatement oracleStmt = null;
		PreparedStatement sqlStmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
            oracleConn = DALUtil.getGMConnection();
            sqlConn = DALUtil.getTurklineConnection();
			
			StringBuilder sqlQuery = new StringBuilder()
				.append("insert into Kredi (KrediID,UstKod,KrediTurID,KrediDovizID,Faiz,MinTutar,MaxTutar,MinVade,MaxVade,KrediTipID) ")
				.append("values (?,?,?,?,?,?,?,?,?,?) ");
			
			sqlStmt = sqlConn.prepareStatement(sqlQuery.toString());

			oracleStmt = oracleConn.prepareCall("{? = call PKG_RC_ADC_TURKLINE.BNSPR_TURKLINE_KREDI_DATA()}");
			oracleStmt.registerOutParameter(1, -10);
			oracleStmt.execute();
			rSet = (ResultSet)oracleStmt.getObject(1);
			int j = 1;
			while(rSet.next()){
				
				int i = 1;
				sqlStmt.setObject(i++, new BigDecimal(j++),Types.DECIMAL);
				sqlStmt.setString(i++, rSet.getString("UST_KOD"));
				sqlStmt.setObject(i++, rSet.getBigDecimal("KREDITUR_ID"),Types.DECIMAL);
				sqlStmt.setString(i++, rSet.getString("KREDIDOVIZID"));
				sqlStmt.setString(i++, rSet.getString("FAIZ")); 
				sqlStmt.setObject(i++, rSet.getBigDecimal("MIN_TUTAR"),Types.DECIMAL);
				sqlStmt.setObject(i++, rSet.getBigDecimal("MAX_TUTAR"),Types.DECIMAL);
				sqlStmt.setObject(i++, rSet.getBigDecimal("MIN_VADE"),Types.DECIMAL);
				sqlStmt.setObject(i++, rSet.getBigDecimal("MAX_VADE"),Types.DECIMAL);
				sqlStmt.setObject(i++, new BigDecimal(1),Types.DECIMAL);
				sqlStmt.execute();
			}
		} catch (Exception e) {
			throw new GMRuntimeException(0, "TurkLine aktar�mda hata al�nd�");
		} finally {
			GMServerDatasource.close(rSet);			
			GMServerDatasource.close(oracleStmt);
			GMServerDatasource.close(sqlStmt);
			GMServerDatasource.close(sqlConn);
			GMServerDatasource.close(oracleConn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_DELETE_TURKLINE_KREDI_DATA")
	public static GMMap deleteTurklineKrediData(GMMap iMap) {
		Connection sqlConn = null;
		PreparedStatement sqlStmt = null;
		GMMap oMap = new GMMap();
		try {
            sqlConn = DALUtil.getTurklineConnection();
			sqlStmt = sqlConn.prepareStatement("delete from Kredi ");
			sqlStmt.execute();
			sqlStmt = sqlConn.prepareStatement("delete from KrediTur ");
			sqlStmt.execute();
			
		} catch (Exception e) {
			throw new GMRuntimeException(0, "TurkLine aktar�mda hata al�nd�");
		} finally {
			GMServerDatasource.close(sqlStmt);
			GMServerDatasource.close(sqlConn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_GET_BAYI_KUR_DATA")
	public static GMMap getBayiKurData(GMMap iMap) {
		Connection oracleConn = null;
		Connection sqlConn = null;
		CallableStatement oracleStmt = null;
		PreparedStatement sqlStmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
            oracleConn = DALUtil.getGMConnection();
            sqlConn = DALUtil.getMatriksConnection();
			
			oracleStmt = oracleConn.prepareCall("{? = call PKG_RC_ADC_TURKLINE.BNSPR_DOVIZ_KURLARI_BANKA_TCMB()}");
			oracleStmt.registerOutParameter(1, -10);
			oracleStmt.execute();
			oracleStmt.getMoreResults();
			rSet = (ResultSet)oracleStmt.getObject(1);
			int row=0;
			String tableName = "RESULTS";
			while(rSet.next()){
				if(rSet.getString("DOVIZ_KOD").equals("EUR"))oMap.put(tableName, row, "DOVIZ_KOD", "EURO");
				else oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString("DOVIZ_KOD"));
				oMap.put(tableName, row, "ALIS_DEGERI", StringUtil.rPad(rSet.getBigDecimal("ALIS_DEGERI"),5));
				oMap.put(tableName, row, "SATIS_DEGERI", StringUtil.rPad(rSet.getBigDecimal("SATIS_DEGERI"),5));
				oMap.put(tableName, row, "T_ALIS_DEGERI", StringUtil.rPad(rSet.getBigDecimal("TCMB_ALIS"),5));
				oMap.put(tableName, row, "T_SATIS_DEGERI", StringUtil.rPad(rSet.getBigDecimal("TCMB_SATIS"),5));
				row++;
			}
			
			GMServerDatasource.close(rSet);
			
			StringBuilder sqlQuery = new StringBuilder()
					.append("Select SEMBOL,ALIS,SATIS ")
					.append("from YUZEYSEL ")
					.append("where SEMBOL in ('SAUD','SCAD','SCHF','SDKK',")
					.append("'SEURO','SGBP','SJPY','SNOK',")
					.append("'SSAR','SSEK','STRL','SUSD') ");
			sqlStmt = sqlConn.prepareStatement(sqlQuery.toString());
			rSet = sqlStmt.executeQuery();
			String dovizKod;
			BigDecimal alisDegeri;
			BigDecimal satisDegeri;
			while(rSet.next()){
				dovizKod = rSet.getString("SEMBOL").substring(1);
				alisDegeri = StringUtil.rPad(rSet.getBigDecimal("ALIS"),5);
				satisDegeri = StringUtil.rPad(rSet.getBigDecimal("SATIS"),5);
				for(int i=0; i<oMap.getSize("RESULTS"); i++){
					if(oMap.getString(tableName, i, "DOVIZ_KOD").equals(dovizKod)){
						oMap.put(tableName, i, "S_ALIS_DEGERI",alisDegeri);
						oMap.put(tableName, i, "S_SATIS_DEGERI",satisDegeri);
					}
				}
			} 
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e.getMessage());
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(oracleStmt);
			GMServerDatasource.close(sqlStmt);
			GMServerDatasource.close(sqlConn);
			GMServerDatasource.close(oracleConn);
		}
	}
}
