package tr.com.calikbank.bnspr.adc.services;

import static tr.com.aktifbank.bnspr.clks.util.BnsprAdcUtil.getCalendarDate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.clks.util.ClksConstants.BasvuruDurum;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants.BelgeKontrol;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBasvuru;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBelge;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBelgeHavuz;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBelgeHavuzId;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBelgeKilit;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBelgeTx;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBelgeTxId;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepTx;
import tr.com.aktifbank.bnspr.dao.ClksBonoTlpBlgKtrlTx;
import tr.com.aktifbank.bnspr.dao.DysBarkodBelge;
import tr.com.aktifbank.bnspr.dao.DysBarkodBelgeAlan;
import tr.com.aktifbank.bnspr.dao.GnlDokumanKodPr;
import tr.com.aktifbank.bnspr.pdfViewerPanelBean.ByteArrayType;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMToolkit;

public class AdcTRN4801Services {

	private static Logger logger = Logger.getLogger(AdcTRN4801Services.class);
	private static String PROJECT_TYPE_BONO = "CLKSDYSBONO";
	private static final String IPAZ_KONTROL = "IPAZ_IMZA_KONTROL";
	private static final String KVKK_KONTROL = "KVKK_IMZA_KONTROL";
	
	@GraymoundService("BNSPR_TRN4801_INITIALIZE")
	public static GMMap init(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		// Banka Tarih
		oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap));
		
		oMap.put("EVET_HAYIR", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap.put("KOD", "EVET_HAYIR")).get("RESULTS"));
		oMap.put("VAR_YOK", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap.put("KOD", "VAR_YOK")).get("RESULTS"));
		oMap.put("BELGE_KONTROL_KOD", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap.put("KOD", "BELGE_KONTROL_KOD")).get("RESULTS"));
		oMap.put("BIR_BELGE_HATA", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap.put("KOD", /*"BIR_BELGE_HATA"*/"DYS_BELGE_ALT_STATU").put("ADD_EMPTY_KEY", "E")).get("RESULTS"));
		oMap.put("GNL_BELGE_GELEN_EVRAK", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap.put("KOD", "GNL_BELGE_GELEN_EVRAK").put("ADD_EMPTY_KEY", "E")).get("RESULTS"));
		
		GuimlUtil.wrapMyCombo(oMap, "BELGE_KONTROL", "1", "H");
		GuimlUtil.wrapMyCombo(oMap, "BELGE_KONTROL", "2", "E");
		GuimlUtil.wrapMyCombo(oMap, "BELGE_KONTROL", "3", "E");
		GuimlUtil.wrapMyCombo(oMap, "BELGE_KONTROL", "4", "E");
		GuimlUtil.wrapMyCombo(oMap, "BELGE_KONTROL", "5", "H");
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4801_GET_BASVURU_INFO")
	public static GMMap getBasvuruInfo(GMMap iMap) {

		GMMap oMap = new GMMap();
		boolean izinliPazarlama = false;
		boolean kvkk = false;

		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksBonoTalepBasvuru basvuru = (ClksBonoTalepBasvuru) session.get(ClksBonoTalepBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			ClksBonoTalepBelgeTx basvuruBelgeTx = (ClksBonoTalepBelgeTx) session.createCriteria(ClksBonoTalepBelgeTx.class).add(Restrictions.eq("id.txNo", basvuru.getTxNo())).setMaxResults(1).uniqueResult();
			ClksBonoTalepTx basvuruTalepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class, basvuruBelgeTx.getTalepTx()); 
			if(!basvuru.getTxNo().equals(basvuru.getGuncelTxNo())) {
				ClksBonoTalepBelgeTx guncelBelgeTx = (ClksBonoTalepBelgeTx) session.createCriteria(ClksBonoTalepBelgeTx.class).add(Restrictions.eq("id.txNo", basvuru.getGuncelTxNo())).setMaxResults(1).uniqueResult();
				oMap.put("GUNCEL_BELGE_TARIHI", guncelBelgeTx.getBelgeTarihi());
			}
				
			try {
				GMServiceExecuter.call("BNSPR_CUSTOMER_GET_MARKETING_PERMISSION_LIST", new GMMap().put("CUSTOMER_NO", basvuruTalepTx.getMusteriNo()));
				izinliPazarlama = true;
			} catch(Exception e) {
				logger.error("BNSPR_TRN4801_GET_BASVURU_INFO > BNSPR_CUSTOMER_GET_MARKETING_PERMISSION_LIST err(continue):", e);
				izinliPazarlama = false;
			}
			
			oMap.put("TC_KIMLIK_NO", basvuruTalepTx.getTcKimlikNo());
			oMap.put("MUSTERI_NO", basvuruTalepTx.getMusteriNo());
			oMap.put("MUSTERI_ADI", DALUtil.callOracleFunction("{ ? = call pkg_musteri.unvan(?) }", BnsprType.STRING, BnsprType.NUMBER, basvuruTalepTx.getMusteriNo()));
			oMap.put("IZINLI_PAZARLAMA", izinliPazarlama);
			oMap.put("BASVURU_TARIHI", basvuruBelgeTx.getBelgeTarihi());
			oMap.put("GUNCEL_BELGE_TARIHI", oMap.getDate("GUNCEL_BELGE_TARIHI", basvuruBelgeTx.getBelgeTarihi()));
			oMap.put("DURUM_KODU", BasvuruDurum.getEnum(basvuru.getDurumKodu()).name());
			oMap.put("KAZANIM_KANALI", DALUtil.callOracleFunction("{? = call pkg_musteri_ek.Kazanim_Kanali(?)}", BnsprType.STRING, BnsprType.NUMBER, basvuruTalepTx.getMusteriNo()));
			oMap.put("KAZANIM_URUNU", DALUtil.callOracleFunction("{? = call pkg_musteri_ek.Kazanim_Urunu(?)}", BnsprType.STRING, BnsprType.NUMBER, basvuruTalepTx.getMusteriNo()));
			
			ClksBonoTlpBlgKtrlTx kontrolTx = (ClksBonoTlpBlgKtrlTx) session.get(ClksBonoTlpBlgKtrlTx.class, basvuru.getGuncelTxNo());
			
			if(kontrolTx != null) {
				oMap.put("HOBIM_HATA_VAR_YOK", "E".equals(kontrolTx.getHobimHata()) ? "VAR" : "YOK");
				oMap.put("HOBIM_KONTROL", GuimlUtil.convertToCheckBoxValue(kontrolTx.getHobimKontrol()));
				oMap.put("KVKK", GuimlUtil.convertToCheckBoxValue(kontrolTx.getKvkk()));
			}
			
		}
		catch (Exception e) {
			logger.error("BNSPR_TRN4801_GET_BASVURU_INFO err:", e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4801_GET_BELGE_LIST")
	public static GMMap getBelgeList(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "BELGELER", musteriNo = "";
		int row = 0;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			@SuppressWarnings("unchecked")
			List<ClksBonoTalepBelge> list = session.createCriteria(ClksBonoTalepBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			
			for(Iterator<ClksBonoTalepBelge> iterator = list.iterator(); iterator.hasNext();) {
				
				ClksBonoTalepBelge belge = iterator.next();
				
				if(musteriNo.isEmpty()) {
					ClksBonoTalepTx talepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class, belge.getTalepTx());
					musteriNo = talepTx.getMusteriNo().toString();
				}
				
				oMap.put(tableName, row, "BASVURU_NO", belge.getId().getBasvuruNo());
				oMap.put(tableName, row, "BELGE_KOD", belge.getId().getDokumanKod());
				oMap.put(tableName, row, "KIMDEN", "M��teri");
				oMap.put(tableName, row, "KIMDEN_KOD", "M");
			
				GnlDokumanKodPr gnlDokumanKodPr = (GnlDokumanKodPr) session.get(GnlDokumanKodPr.class, belge.getId().getDokumanKod().toString());
				oMap.put(tableName, row, "BELGE_ADI", gnlDokumanKodPr.getAciklama());
				oMap.put(tableName, row, "DOKUMAN_TIP_KOD", gnlDokumanKodPr.getDokumanTipKod());
				oMap.put(tableName, row, "DOSYA_YOL", ""/*belge.getBelgeYeri()*/);

				if(BelgeKontrol.UYGUN.toString().equals(belge.getBelgeKontrol())) {
					oMap.put(tableName, row, "DOSYA_ADI", "MUST_IMAJ_" + musteriNo + "_" + belge.getId().getDokumanKod().toString() + "_1.pdf");					
				} else  {
					HashMap<String, String> restrictions = new HashMap<String, String>();
					restrictions.put("barkod", belge.getBarkod());
					restrictions.put("projectType", PROJECT_TYPE_BONO);
					restrictions.put("dokumanKod", belge.getId().getDokumanKod().toString());
					
					DysBarkodBelge dysBelge = (DysBarkodBelge) session.createCriteria(DysBarkodBelge.class).add(Restrictions.allEq(restrictions)).uniqueResult();
					if(dysBelge != null) {
						oMap.put(tableName, row, "DOSYA_ADI", dysBelge.getPath());
					}
				}
					
				try {
					oMap.put(tableName, row, "URL", GMServiceExecuter.call("DYS_CMIS_GET_CUSTOMER_DOC_INFO_BY_FILENAME", new GMMap().put("DOKUMAN_ADI", oMap.getString(tableName, row, "DOSYA_ADI")).put("DOKUMAN_CLASS", "Musteri")).getString("DOKUMAN_LINK"));
				}
				catch (Exception e) {
					logger.error("BNSPR_TRN4801_GET_BELGE_LIST > DYS_CMIS_GET_CUSTOMER_DOC_INFO_BY_FILENAME err(continue):", e);
				}
				
				oMap.put(tableName, row, "BELGE_ESKI_STATU", belge.getBelgeKontrol());
				oMap.put(tableName, row, "BELGE_KONTROL", belge.getBelgeKontrol());
				oMap.put(tableName, row, "BELGE_HATA", belge.getBelgeKontrolAltStatu());
				oMap.put(tableName, row, "GELIS_TARIHI", belge.getGelisTarihi());
				oMap.put(tableName, row, "ORJINAL_EVRAK_MI", GuimlUtil.convertToCheckBoxValue(BelgeKontrol.UYGUN.toString().equals(belge.getBelgeKontrol()) && belge.getGelisTarihi() != null ? "E" : "H"));
				oMap.put(tableName, row, "KAYIT", "ESKI");
				oMap.put(tableName, row, "BELGE_TAMAMLAMA_TARIHI", iMap.getDate("BELGE_TAMAMLAMA_TARIHI"));
				//oMap.put(tableName, row, "KONTROL_NEDENI", belge.getKontrolNedeni());
				oMap.put(tableName, row, "BARKOD", belge.getBarkod());
				oMap.put(tableName, row, "UYUMSUZ_ACIKLAMA", belge.getBelgeKontrolAciklama());
				oMap.put(tableName, row, "TALEP_TRX_NO", belge.getTalepTx());
				oMap.put(tableName, row, "BELGE_TARIHI", belge.getBelgeTarihi());
				
				row++;
			}
			
			return oMap;
		}
		
		catch (Exception e) {
			logger.error("BNSPR_TRN4801_GET_BELGE_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4801_GET_BELGE_PDF")
	public static GMMap getBelgePdf(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		try {
			
			String dokumanAdi = iMap.getString("DOSYA_ADI"); //"MUST_IMAJ_" + iMap.getString("MUSTERI_NO") + "_" + iMap.getString("BELGE_KOD") + "_1.pdf";
			
			ByteArrayType file = new ByteArrayType();
			file.setData((byte[]) GMServiceExecuter.call("DYS_CMIS_GET_DOKUMAN_LINK_BY_FILENAME", new GMMap()
				.put("GET_ALL_VERSIONS", false)
				.put("DOKUMAN_BYTE_ARRAY_NEEDED", true)
				.put("DOKUMAN_ADI", dokumanAdi)
				.put("DOKUMAN_CLASS", "Musteri")).get("DOKUMAN_BYTE_ARRAY"));

			oMap.put("FILE", file);
		}
		catch (Exception e) {
			logger.error("BNSPR_TRN4801_GET_BELGE_PDF err:", e);
		}

		return oMap;
	}
	
	private static GMMap getUyumBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> dysBarkodBelgeList = session.createCriteria(DysBarkodBelge.class).add(Restrictions.eq("barkod", iMap.getString("BARCODE"))).add(Restrictions.eq("projectType", iMap.getString("PROJECT_TYPE"))).add(Restrictions.eq("reference", iMap.getString("BASVURU_NO"))).add(Restrictions.eq("dokumanKod", iMap.getString("DOKUMAN_KOD"))).list();
			if (dysBarkodBelgeList.size() == 0) {
				return oMap;
			}
			// unique'lik yok, ilkini al
			DysBarkodBelge dysBarkodBelge = (DysBarkodBelge) dysBarkodBelgeList.get(0);

			List<?> uyumsuzList = session.createCriteria(DysBarkodBelgeAlan.class).add(Restrictions.eq("dysBarkodBelgeId", dysBarkodBelge.getId())).list();
			for (int i = 0; i < uyumsuzList.size(); i++) {
				DysBarkodBelgeAlan dysBarkodBelgeAlan = (DysBarkodBelgeAlan) uyumsuzList.get(i);
				oMap.put("UYUM_" + dysBarkodBelgeAlan.getKey(), Arrays.asList(IPAZ_KONTROL, KVKK_KONTROL).contains(dysBarkodBelgeAlan.getKey()) ? dysBarkodBelgeAlan.getValue() : "UYUMSUZ");
				oMap.put("ACIKLAMA_" + dysBarkodBelgeAlan.getKey(), Arrays.asList(IPAZ_KONTROL, KVKK_KONTROL).contains(dysBarkodBelgeAlan.getKey()) ? "" : dysBarkodBelge.getAciklama());
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4801_GET_BELGE_KONTROL_LIST")
	public static GMMap getBelgeKontrolList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String tableName = "DOKUMAN_DETAY", kontrolTableName = "KONTROL_NOKTALARI";

		try {
			
			if(iMap.get("BELGE_KOD") == null || iMap.get("BARKOD") == null) {
				return oMap;
			}
			
			iMap.put("DOKUMAN_KOD", iMap.getString("BELGE_KOD"));
			iMap.put("BARCODE", iMap.getString("BARKOD"));
			iMap.put("PROJECT_TYPE", PROJECT_TYPE_BONO);
			
			if(!BelgeKontrol.UYGUN.toString().equals(iMap.getString("BELGE_KONTROL"))) {
				oMap = getUyumBilgileri(iMap);
			}
			
			// Ba�vuru Bilgileri
			oMap.putAll(GMServiceExecuter.call("BNSPR_DYS_GET_INFO", iMap));
			oMap.put("DOKUMAN_ACIKLAMA", oMap.getString(tableName, 0, "AD"));
			
			@SuppressWarnings("unchecked")
			List<HashMap<String, Object>> list = (List<HashMap<String, Object>>) oMap.get(tableName, 0, kontrolTableName);
			
			if(list != null && list.size() > 0) {
				
				int index = 0;
				for(HashMap<String, Object>	tMap : list) {
					
					oMap.put(kontrolTableName, index, "ALAN", tMap.get("ALAN_ADI").toString());
					oMap.put(kontrolTableName, index, "SORU", tMap.get("ACIKLAMA") != null ? tMap.get("ACIKLAMA").toString() : null);
					oMap.put(kontrolTableName, index, "BASVURU_DEGER", tMap.get("DEGER") != null ? tMap.get("DEGER").toString() : null);
					oMap.put(kontrolTableName, index, "UYGUN_MU", "UYUMSUZ".equals(oMap.getString("UYUM_" + tMap.get("ALAN_ADI").toString())) ? "H" : "E");
					oMap.put(kontrolTableName, index, "ACIKLAMA", oMap.getString("ACIKLAMA_" + tMap.get("ALAN_ADI").toString()));
					index++;
				}
			}
			oMap.remove(tableName);
		}
		catch (Exception e) {
			logger.error("BNSPR_TRN4801_GET_BELGE_KONTROL_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4801_SAVE")
	public static GMMap save(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			if(iMap.containsKey("BELGELER")) {
				
				for(int i=0; i<iMap.getSize("BELGELER"); i++) {
					
					if(iMap.get("BELGELER", i, "BELGE_ESKI_STATU").equals(iMap.get("BELGELER", i, "BELGE_KONTROL"))) {
						continue;
					}
					
					ClksBonoTalepBelgeTxId belgeTxId = new ClksBonoTalepBelgeTxId(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("BELGELER", i, "BELGE_KOD"));
					ClksBonoTalepBelgeTx belgeTx = (ClksBonoTalepBelgeTx) session.get(ClksBonoTalepBelgeTx.class, belgeTxId);
					
					if(belgeTx == null) {
						belgeTx = new ClksBonoTalepBelgeTx(belgeTxId, iMap.getString("TC_KIMLIK_NO"));
					}
					
					belgeTx.setTcKimlikNo(iMap.containsKey("TC_KIMLIK_NO") ? iMap.getString("TC_KIMLIK_NO") : belgeTx.getTcKimlikNo());
					belgeTx.setAlindi("E");
					belgeTx.setBarkod(iMap.get("BELGELER", i, "BARKOD") != null ? iMap.getString("BELGELER", i, "BARKOD") : belgeTx.getBarkod());
					belgeTx.setBasvuruNo(iMap.get("BELGELER", i, "BASVURU_NO") != null ? iMap.getBigDecimal("BELGELER", i, "BASVURU_NO") : belgeTx.getBasvuruNo());
					belgeTx.setBelgeKontrol(iMap.get("BELGELER", i, "BELGE_KONTROL") != null ? iMap.getString("BELGELER", i, "BELGE_KONTROL") : belgeTx.getBelgeKontrol());
					belgeTx.setBelgeKontrolAltStatu(iMap.get("BELGELER", i, "BELGE_HATA") != null ? iMap.getString("BELGELER", i, "BELGE_HATA") : belgeTx.getBelgeKontrolAltStatu());
					belgeTx.setBelgeKontrolAciklama(iMap.get("BELGELER", i, "UYUMSUZ_ACIKLAMA") != null ? iMap.getString("BELGELER", i, "UYUMSUZ_ACIKLAMA") : belgeTx.getBelgeKontrolAciklama());
					belgeTx.setBelgeTarihi(iMap.get("BELGELER", i, "BELGE_TARIHI") != null ? iMap.getDate("BELGELER", i, "BELGE_TARIHI") : belgeTx.getBelgeTarihi());
					belgeTx.setGelisTarihi(iMap.get("BELGELER", i, "GELIS_TARIHI") != null && !iMap.getString("BELGELER", i, "GELIS_TARIHI").isEmpty() ? iMap.getDate("BELGELER", i, "GELIS_TARIHI") : belgeTx.getGelisTarihi());
					belgeTx.setTalepTx(iMap.get("BELGELER", i, "TALEP_TRX_NO") != null ? iMap.getBigDecimal("BELGELER", i, "TALEP_TRX_NO") : belgeTx.getTalepTx());
					belgeTx.setData(iMap.get("BELGELER", i, "BELGE_KEY_VALUE") != null ? Hibernate.createBlob(GMToolkit.serialize(iMap.get("BELGELER", i, "BELGE_KEY_VALUE"))) : belgeTx.getData());
					session.saveOrUpdate(belgeTx);
				}
				iMap.put("TRX_NAME", "4801");
				
			} else {
			
				ClksBonoTalepBelgeTxId belgeTxId = new ClksBonoTalepBelgeTxId(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("DOKUMAN_KOD"));
				ClksBonoTalepBelgeTx belgeTx = (ClksBonoTalepBelgeTx) session.get(ClksBonoTalepBelgeTx.class, belgeTxId);
				
				if(belgeTx == null) {
					belgeTx = new ClksBonoTalepBelgeTx(belgeTxId, iMap.getString("TC_KIMLIK_NO"));
				}
				
				belgeTx.setTcKimlikNo(iMap.containsKey("TC_KIMLIK_NO") ? iMap.getString("TC_KIMLIK_NO") : belgeTx.getTcKimlikNo());
				belgeTx.setAlindi(iMap.containsKey("ALINDI") ? iMap.getString("ALINDI") : belgeTx.getAlindi());
				belgeTx.setBarkod(iMap.containsKey("BARKOD") ? iMap.getString("BARKOD") : belgeTx.getBarkod());
				belgeTx.setBelgeKontrol(iMap.containsKey("BELGE_KONTROL") ? iMap.getString("BELGE_KONTROL") : belgeTx.getBelgeKontrol());
				belgeTx.setBelgeKontrolAltStatu(iMap.containsKey("BELGE_KONTROL_ALT_STATU") ? iMap.getString("BELGE_KONTROL_ALT_STATU") : belgeTx.getBelgeKontrolAltStatu());
				belgeTx.setBelgeKontrolAciklama(iMap.containsKey("BELGE_KONTROL_ACIKLAMA") ? iMap.getString("BELGE_KONTROL_ACIKLAMA") : belgeTx.getBelgeKontrolAciklama());
				belgeTx.setBelgeTarihi(iMap.containsKey("BELGE_TARIHI") ? iMap.getDate("BELGE_TARIHI") : belgeTx.getBelgeTarihi());
				belgeTx.setGelisTarihi(iMap.containsKey("GELIS_TARIHI") ? iMap.getDate("GELIS_TARIHI") : belgeTx.getGelisTarihi());
				belgeTx.setTalepTx(iMap.containsKey("TALEP_TRX_NO") ? iMap.getBigDecimal("TALEP_TRX_NO") : belgeTx.getTalepTx());
				belgeTx.setIsleminYapildigiSubeId(iMap.get("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE_ID") != null ? 
					iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE_ID") : belgeTx.getIsleminYapildigiSubeId());
				belgeTx.setIslemiYapanKullanici(iMap.get("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI") != null ? 
					iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI") : belgeTx.getIslemiYapanKullanici());
				belgeTx.setIslemiYapanKullaniciSicil(iMap.get("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL") != null ? 
					iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL") : belgeTx.getIslemiYapanKullaniciSicil());
				belgeTx.setBasvuruNo(iMap.containsKey("BASVURU_NO") ? iMap.getBigDecimal("BASVURU_NO") : belgeTx.getBasvuruNo());
				
				// List<HashMap<String, String>> belgeKeyValueList = (ArrayList<HashMap<String, String>>) iMap.get("BELGE_KEY_VALUE");
				/*GMMap logMap = null;
				if (belgeKeyValueList != null && belgeKeyValueList.size() > 0) {
				Iterator<HashMap<String, String>> iterKeyValue = belgeKeyValueList.iterator();
					logMap = new GMMap();
					int i = 0;
				while (iterKeyValue.hasNext()) {
					logMap.putAll(belgeKeyValueList.get(i));
					i++;
				}
				}
				*/
				// HashMap<String, String> belgeKeyValueMap = belgeKeyValueList != null ? belgeKeyValueList.get(0) : null;
				belgeTx.setData(iMap.get("BELGE_KEY_VALUE") != null ? Hibernate.createBlob(GMToolkit.serialize(iMap.get("BELGE_KEY_VALUE"))) : belgeTx.getData());

				iMap.put("BASVURU_NO", belgeTx.getBasvuruNo());
				
				session.saveOrUpdate(belgeTx);
			}
			
			ClksBonoTlpBlgKtrlTx kontrolTx = (ClksBonoTlpBlgKtrlTx) session.get(ClksBonoTlpBlgKtrlTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(kontrolTx == null) {
				kontrolTx = new ClksBonoTlpBlgKtrlTx(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("BASVURU_NO"));
			}
			
			kontrolTx.setHobimKontrol(iMap.getString("HOBIM_RANDOM_CHECK_EH", "H"));
			kontrolTx.setHobimHata("VAR".equals(iMap.getString("HOBIM_HATA_VAR_YOK", "YOK")) ? "E" : "H");
			kontrolTx.setGuncelTxNo(iMap.getBigDecimal("HOBIM_RANDOM_TX_NO"));
			kontrolTx.setIslemTarihi(getCalendarDate());
			kontrolTx.setIzinliPazarlama(iMap.getBoolean("F_IPAZ") ? "E" : "H");
			kontrolTx.setKvkk(iMap.getBoolean("F_KVKK") ? "E" : "H");
			
			ClksBonoTalepBasvuru basvuru = (ClksBonoTalepBasvuru) session.get(ClksBonoTalepBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			
			if(basvuru == null) {
				kontrolTx.setDurumKodu(BasvuruDurum.BASVURU.toString());
			} else {
				kontrolTx.setDurumKodu(basvuru.getDurumKodu());
			}
			
			session.saveOrUpdate(kontrolTx);
			session.flush();
			
			if(iMap.containsKey("TRX_NAME")) {
				return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			} else {
				return new GMMap().put("RESPONSE", 2);
			}
		}
		
		catch(Exception e) {
			logger.error("BNSPR_TRN4801_SAVE err: ", e);
            throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4801_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		BasvuruDurum durum = BasvuruDurum.CEPTE;
		List<ClksBonoTalepBelgeTx> trxBelgeList = new ArrayList<ClksBonoTalepBelgeTx>();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");

			ClksBonoTlpBlgKtrlTx kontrolTx = (ClksBonoTlpBlgKtrlTx) session.get(ClksBonoTlpBlgKtrlTx.class, iMap.getBigDecimal("ISLEM_NO"));
			
			if(kontrolTx != null) {
				if("E".equals(kontrolTx.getHobimKontrol())) {
					ClksBonoTalepBelgeHavuzId havuzId = new ClksBonoTalepBelgeHavuzId(kontrolTx.getGuncelTxNo(), kontrolTx.getBasvuruNo());
					ClksBonoTalepBelgeHavuz havuz = (ClksBonoTalepBelgeHavuz) session.get(ClksBonoTalepBelgeHavuz.class, havuzId);
					havuz.setDurumKodu("K");
					session.saveOrUpdate(havuz);
				}
			}
			
			@SuppressWarnings("unchecked")
			List<ClksBonoTalepBelgeTx> listBelgeTx = session.createCriteria(ClksBonoTalepBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			
			if(listBelgeTx.size() == 0) {
				session.flush();
				return oMap;
			}
			
			ClksBonoTalepTx talepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class, listBelgeTx.get(0).getTalepTx());
			
			GMMap kontakt = new GMMap();
			kontakt.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRN1040_CREATE_TRX_NO", new GMMap().put("MUSTERI_NO", talepTx.getMusteriNo()).put("DURUM_KODU", "A")).getBigDecimal("TRX_NO"));
			kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", new GMMap().put("TRX_NO", kontakt.getBigDecimal("TRX_NO"))));
			
			if (kontakt.getBoolean("F_SAHTE")) {
				kontakt.remove("F_SAHTE");
				kontakt.put("F_SAHTE", "1");
			}
			else {
				kontakt.remove("F_SAHTE");
				kontakt.put("F_SAHTE", "0");
			}
			
			if (kontakt.getBoolean("F_MUSTERIYE_CEVRILEBILIR")) {
				kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "1");
			}
			else {
				kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "0");
			}
			
			GMMap pMap = new GMMap();
			pMap.put("KOD", "BHS_DOKUMAN_KODLARI");
			for (Iterator<ClksBonoTalepBelgeTx> iterator = listBelgeTx.iterator(); iterator.hasNext();) {
				
				ClksBonoTalepBelgeTx belgeTx = iterator.next();
				trxBelgeList.add(belgeTx);
				
				pMap.put("KEY", belgeTx.getId().getDokumanKod().toString());
				pMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI", pMap));

				if(BelgeKontrol.UYGUN.toString().equals(belgeTx.getBelgeKontrol())) {
					for(int i = 0; i < kontakt.getSize("CBS_MUSTERI_BASVURU_DOKUMAN"); i++) {
						if(belgeTx.getId().getDokumanKod().toString().equals(kontakt.getString("CBS_MUSTERI_BASVURU_DOKUMAN", i, "DOKUMAN_KODU"))) {
							kontakt.put("CBS_MUSTERI_BASVURU_DOKUMAN", i, "ALINDI_KUTUSU_F", "1");
							if(pMap.getString("IS_EXIST").equals("E")) {
								kontakt.put("ADK_MUSTERISIMI", "E");
								kontakt.put("ORIJINAL_EVRAKLIMI", "E");
							}
							break;
						}
					}
					
				} else if(BelgeKontrol.EKSIK.toString().equals(belgeTx.getBelgeKontrol()) || BelgeKontrol.UYUMSUZ.toString().equals(belgeTx.getBelgeKontrol())) {
					for(int i = 0; i < kontakt.getSize("CBS_MUSTERI_BASVURU_DOKUMAN"); i++) {
						if(belgeTx.getId().getDokumanKod().toString().equals(kontakt.getString("CBS_MUSTERI_BASVURU_DOKUMAN", i, "DOKUMAN_KODU"))) {
							kontakt.put("CBS_MUSTERI_BASVURU_DOKUMAN", i, "ALINDI_KUTUSU_F", "0");
							if(pMap.getString("IS_EXIST").equals("E")) {
								kontakt.put("ADK_MUSTERISIMI", "H");
								kontakt.put("ORIJINAL_EVRAKLIMI", "H");
							}
							break;
						}
					}
				}
			}

			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_SAVE", kontakt));
			
			// Update Application Status
			@SuppressWarnings("unchecked")
			List<ClksBonoTalepBelge> listBelge = session.createCriteria(ClksBonoTalepBelge.class).add(Restrictions.eq("id.basvuruNo", talepTx.getBasvuruNo())).list();
			
			boolean statusApproved = false, fileExists = false;
			for (Iterator<ClksBonoTalepBelge> iterator = listBelge.iterator(); iterator.hasNext();) {
				statusApproved = false;
				ClksBonoTalepBelge belge = iterator.next();
				
				for(int i=0; i<trxBelgeList.size(); i++) {
					if(trxBelgeList.get(i).getId().getDokumanKod().equals(belge.getId().getDokumanKod())) {
						if(BelgeKontrol.UYGUN.toString().equals(trxBelgeList.get(i).getBelgeKontrol())) {
							
							HashMap<String, String> searchMap = new HashMap<String, String>();
							searchMap.put("barkod", trxBelgeList.get(i).getBarkod());
							searchMap.put("projectType", PROJECT_TYPE_BONO);
							searchMap.put("dokumanKod", trxBelgeList.get(i).getId().getDokumanKod().toString());
							
							DysBarkodBelge barkodBelgeList = (DysBarkodBelge) session.createCriteria(DysBarkodBelge.class).add(Restrictions.allEq(searchMap)).uniqueResult();
							
							if(barkodBelgeList != null && barkodBelgeList.getPath() != null) {
								try {
									GMServiceExecuter.call("DYS_CMIS_GET_CUSTOMER_DOC_INFO_BY_FILENAME", new GMMap().put("DOKUMAN_ADI", barkodBelgeList.getPath()).put("DOKUMAN_CLASS", "Musteri"));
									fileExists = true;
								}
								catch (Exception e) {
									logger.error("BNSPR_TRN4801_AFTER_APPROVAL > DYS_CMIS_GET_CUSTOMER_DOC_INFO_BY_FILENAME err(continue):", e);
									fileExists = false;
								}
								
								if(fileExists) {
									
									String filename = "MUST_IMAJ_" + talepTx.getMusteriNo() + "_" + trxBelgeList.get(i).getId().getDokumanKod().toString() + "_1.pdf";
									
									GMMap dysMap=new GMMap();
									dysMap.put("DOKUMAN_ADI", filename);
									dysMap.put("DOKUMAN_KODU", trxBelgeList.get(i).getId().getDokumanKod().toString());
									dysMap.put("UST_DOKUMAN_TIPI", "MUSTERI_DOKUMAN");
									dysMap.put("MUSTERI_NO", talepTx.getMusteriNo());
									dysMap.put("REFERANS_NO", talepTx.getBasvuruNo());
									dysMap.put("DOKUMAN_BYTE_ARRAY", GMServiceExecuter.call("DYS_CMIS_GET_DOKUMAN_LINK_BY_FILENAME", new GMMap()
										.put("GET_ALL_VERSIONS", false)
										.put("DOKUMAN_BYTE_ARRAY_NEEDED", true)
										.put("DOKUMAN_ADI", barkodBelgeList.getPath())
										.put("DOKUMAN_CLASS", "Musteri")).get("DOKUMAN_BYTE_ARRAY"));
									
									GMServiceExecuter.call("DYS_CMIS_CREATE_OR_UPDATE_MUSTERI_DOKUMAN", dysMap);
									
									DALUtil.callOracleProcedure("{call PKG_TRN10011.Hobim_gelen_dokuman(?,?,?,?,?,?,?)}", 
										new Object[]{ BnsprType.NUMBER, talepTx.getMusteriNo(),
											BnsprType.STRING, trxBelgeList.get(i).getId().getDokumanKod().toString(),
											BnsprType.STRING, filename,
											BnsprType.STRING, talepTx.getBasvuruNo().toString(),
											BnsprType.STRING, null,
											BnsprType.STRING, null,
											BnsprType.STRING, null}, 
										new Object[]{});
								}
							}
							
							statusApproved = true;
							break;
						}
					}
				}
				
				if(!BelgeKontrol.UYGUN.toString().equals(belge.getBelgeKontrol()) && !statusApproved) {
					durum = BasvuruDurum.EVRAKSIZ;
					break;
				}
			}
			
			ClksBonoTalepBasvuru basvuru = (ClksBonoTalepBasvuru) session.get(ClksBonoTalepBasvuru.class, talepTx.getBasvuruNo());
			
			if(basvuru == null) {
				durum = BasvuruDurum.BASVURU;
				basvuru = new ClksBonoTalepBasvuru(talepTx.getBasvuruNo(), durum.toString(), iMap.getBigDecimal("ISLEM_NO"), iMap.getBigDecimal("ISLEM_NO"));
				basvuru.setRecDate(new Date());
			} else {
				basvuru.setDurumKodu(durum.toString());
				basvuru.setGuncelTxNo(iMap.getBigDecimal("ISLEM_NO"));
			}
			
			kontrolTx = (ClksBonoTlpBlgKtrlTx) session.get(ClksBonoTlpBlgKtrlTx.class, iMap.getBigDecimal("ISLEM_NO"));
			kontrolTx.setIslemSonrasiDurumKodu(durum.toString());
			
			session.saveOrUpdate(basvuru);
			session.saveOrUpdate(kontrolTx);
			session.flush();
			
			oMap.put("DURUM", durum.toString());
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_TRN4801_AFTER_APPROVAL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4801_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			// DYS Entegrasyonu
			if(iMap.containsKey("BARCODE_NO")) {
				oMap = (GMMap) DALUtil.callOracleProcedure("{ call pkg_trn4801.get_info(?,?,?,?,?,?,?,?,?,?) }", 
					new Object[] { BnsprType.STRING, iMap.getString("BARCODE_NO") },
					new Object[] { BnsprType.NUMBER, "MUSTERI_NO",
						BnsprType.STRING, "ADI",
						BnsprType.STRING, "IKINCI_ADI",
						BnsprType.STRING, "SOYADI",
						BnsprType.DATE, "GONDERIM_TARIHI",
						BnsprType.STRING, "GONDERIM_DURUMU",
						BnsprType.STRING, "SUBE",
						BnsprType.STRING, "MERKEZ",
						BnsprType.STRING, "SICIL"
				});
			} else {
				// TBI
			}
			
			return oMap;
		}
		catch(Exception e) {
			logger.error("BNSPR_TRN4801_GET_INFO err: ", e);
            throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4801_BELGE_TARIHCE")
	public static GMMap belgeTarihce(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_trn4801.belge_tarihce(?,?)}", "BELGE_LIST", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.NUMBER, iMap.getBigDecimal("DOKUMAN_KOD")));
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_TRN4801_BELGE_TARIHCE err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN4801_HAVUZ_BELGE_GETIR")
	public static GMMap havuzBelgeGetir(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
		
			oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_trn4801.rasgele_basvuru_belge_list(?,?,?,?,?)}", "BASVURU_BILGILERI", 
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"),
				BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"),
				BnsprType.DATE, iMap.getDate("BASLANGIC_TAR"),
				BnsprType.DATE, iMap.getDate("BITIS_TAR"),
				BnsprType.STRING, iMap.getString("HOBIM_RANDOM_EH")));
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_TRN4801_BELGE_TARIHCE err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4801_KILITLE")
	public static GMMap kilitle(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			
			GMServiceExecuter.call("BNSPR_TRN4801_KILIT_KONTROL", iMap);
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksBonoTalepBelgeKilit kilit = (ClksBonoTalepBelgeKilit) session.get(ClksBonoTalepBelgeKilit.class, iMap.getBigDecimal("BASVURU_NO"));
			
			if(kilit == null) {
				kilit = new ClksBonoTalepBelgeKilit(iMap.getBigDecimal("BASVURU_NO"));
			}
			
			kilit.setIslemTarihi(getCalendarDate());
			session.saveOrUpdate(kilit);
			session.flush();
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_TRN4801_KILITLE err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4801_KILIT_COZ")
	public static GMMap kilitCoz(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			if(iMap.get("BASVURU_NO") == null || iMap.getString("BASVURU_NO").isEmpty()) {
				return oMap;
			}
			
			try {
				GMServiceExecuter.call("BNSPR_TRN4801_KILIT_KONTROL", iMap).getString("KULLANICI_KOD");
			} catch(Exception e) {
				return oMap;
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksBonoTalepBelgeKilit kilit = (ClksBonoTalepBelgeKilit) session.get(ClksBonoTalepBelgeKilit.class, iMap.getBigDecimal("BASVURU_NO"));
			
			if(kilit == null) {
				return oMap;
			}
			
			session.delete(kilit);
			session.flush();
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_TRN4801_KILIT_COZ err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4801_KILIT_KONTROL")
	public static GMMap kilitKontrol(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			
			oMap.put("KULLANICI_KOD", DALUtil.callOracleFunction("{? = call pkg_trn4801.belge_kilit_kontrol(?)}", BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")));
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_TRN4801_KILIT_KONTROL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
