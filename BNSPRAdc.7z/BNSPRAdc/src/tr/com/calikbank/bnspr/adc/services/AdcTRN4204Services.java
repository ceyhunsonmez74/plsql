package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.calikbank.bnspr.dao.KibKullaniciHesapKisitTx;
import tr.com.calikbank.bnspr.dao.KibKullaniciHesapKisitTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class AdcTRN4204Services {
	
	@GraymoundService("BNSPR_TRN4204_SET_TABLE")
	public static GMMap listele(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			
			conn = DALUtil.getGMConnection();
		
			stmt = conn.prepareCall("{? = call PKG_TRN4204.TRN4204_Sorgulama(?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor			
			
			if ( iMap.getBigDecimal ( "FIRMA_KODU" ) == null ) {
				iMap.put("MESSAGE_NO", new BigDecimal(330));
				iMap.put("P1", "FIRMA_KODU");
				oMap.put("MESSAGE",(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				return oMap;
			}
			
			if ( iMap.getBigDecimal ( "KULLANICI_KODU" ) == null ) {
				iMap.put("MESSAGE_NO", new BigDecimal(330));
				iMap.put("P1", "KULLANICI_KODU");
				oMap.put("MESSAGE",(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				return oMap;
			}
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("V_TX"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			String tableName = "LISTE_TABLOSU" ; 
			int var = 0 ;
				
			while(rSet.next()){
				oMap.put(tableName,var,"DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
				oMap.put(tableName,var,"HESAP_NO", rSet.getString("HESAP_NO"));
				oMap.put(tableName,var,"KISA_ISIM", rSet.getString("KISA_ISIM"));
				oMap.put(tableName,var,"SUBE", rSet.getString("SUBE"));
				oMap.put(tableName,var,"SUBE_ADI", rSet.getString("SUBE_ADI"));
				oMap.put(tableName,var,"YETKILI", rSet.getString("YETKILI"));
				oMap.put(tableName,var,"HESAP_DURUM_KODU", rSet.getString("HESAP_DURUM_KODU"));
				var++;
        	}
			

		return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN4204_SAVE")
	public static Map<?, ?> Save (GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			conn = DALUtil.getGMConnection();

			Session session = DAOSession.getSession("BNSPRDal");
					
			String tableName = "LISTE_TABLOSU";
			List<?> recordList = (List<?>)iMap.get(tableName);
			
			
			for(int i = 0; i < recordList.size(); i++) {
				if ((  iMap.getBoolean(tableName, i, "YETKILI") == true )) { 
					KibKullaniciHesapKisitTxId id = new KibKullaniciHesapKisitTxId();
					
					id.setFirmaNo(iMap.getBigDecimal("FIRMA_NO"));
					id.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
					id.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU"));
					id.setTxNo(iMap.getBigDecimal("TX_NO"));
					
					KibKullaniciHesapKisitTx kibKullaniciHesapKisitTx = (KibKullaniciHesapKisitTx)session.get(KibKullaniciHesapKisitTx.class, id);
					
					if(kibKullaniciHesapKisitTx == null) {
						kibKullaniciHesapKisitTx = new KibKullaniciHesapKisitTx();
					}
					
					//session.delete(kibKullaniciHesapKisitTx);
					//session.flush();
					
					kibKullaniciHesapKisitTx.setYetkili("1");
					kibKullaniciHesapKisitTx.setId(id);
					
					session.saveOrUpdate(kibKullaniciHesapKisitTx);
					session.flush();
					
				}
				
				if (iMap.getBoolean(tableName, i, "YETKILI") == false) { 
					KibKullaniciHesapKisitTxId id = new KibKullaniciHesapKisitTxId();
					
					id.setFirmaNo(iMap.getBigDecimal("FIRMA_NO"));
					id.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
					id.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU"));
					id.setTxNo(iMap.getBigDecimal("TX_NO"));
					
					KibKullaniciHesapKisitTx kibKullaniciHesapKisitTx = (KibKullaniciHesapKisitTx)session.get(KibKullaniciHesapKisitTx.class, id);
					
					if(kibKullaniciHesapKisitTx == null) {
						kibKullaniciHesapKisitTx = new KibKullaniciHesapKisitTx();
					}
					 
					kibKullaniciHesapKisitTx.setYetkili("0");
					kibKullaniciHesapKisitTx.setId(id);
										
					session.saveOrUpdate(kibKullaniciHesapKisitTx);
					session.flush();
					
				}
			}
			iMap.put("TRX_NO"	, iMap.getBigDecimal("TX_NO"));
			iMap.put("TRX_NAME", "4204");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN4204_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			GMMap oMap = new GMMap();
					BigDecimal txNo = iMap.getBigDecimal("TX_NO");
					Session session = DAOSession.getSession("BNSPRDal");
					
					List<?> recordList = (List<?>)session.createCriteria(KibKullaniciHesapKisitTx.class)
					.add(Restrictions.eq("id.txNo", txNo))
					.list();
			
					
					for (int row = 0; row < 1; row++) {
						KibKullaniciHesapKisitTx id = (KibKullaniciHesapKisitTx)recordList.get(row);
						oMap.put("TX_NO", id.getId().getTxNo());
						oMap.put("KULLANICI_KODU", id.getId().getKullaniciNo());
						oMap.put("FIRMA_KODU", id.getId().getFirmaNo());
						
						oMap.put("FIRMA_UNVANI", LovHelper.diLov(id.getId().getFirmaNo(), "4202/LOV_FIRMA_UNVANI", "MUSTERI_ADI" ));
						oMap.put("KULLANICI_UNVANI", LovHelper.diLov(id.getId().getKullaniciNo(),id.getId().getFirmaNo(), "4202/LOV_KULLANICI" , "MUSTERI_ADI" ));
						
					}
					
					
					
				return oMap;
		} catch (Exception e) {

			throw new GMRuntimeException(0, e);
		} finally {
				
		}
		
	}
	
}