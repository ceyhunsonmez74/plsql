package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KibFirmaYetkiLimitDetay;
import tr.com.aktifbank.bnspr.dao.KibFirmaYetkiLimitDetayTx;
import tr.com.aktifbank.bnspr.dao.KibFirmaYetkiLimitDetayTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KibFirmaYetkiLimit;
import tr.com.calikbank.bnspr.dao.KibFirmaYetkiLimitTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4200Services {

	@GraymoundService("BNSPR_TRN4200_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try {
			GMMap oMap = new GMMap();

			iMap.put("KOD", "FIRMA_YETKI_TANIM_YETKI_TUR");
			oMap.put("YETKI_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "FIRMA_YETKI_LIMIT_FIRMA_ONAY_SISTEMI");
			oMap.put("FIRMA_ONAY_SISTEMI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
 
	}

	@GraymoundService("BNSPR_TRN4200_SAVE")
	public static Map<?, ?> trn4200Save(GMMap iMap) {
		try {
			
			/*if(!validateIP(iMap.getString("IPBAS")) || !validateIP(iMap.getString("IPSON"))) {
				iMap.put("HATA_NO", new BigDecimal(1489));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				return null;
			}*/
			Session session = DAOSession.getSession("BNSPRDal");

			KibFirmaYetkiLimitTx  kibFirmaYetkiLimitTx = (KibFirmaYetkiLimitTx)session.get(KibFirmaYetkiLimitTx.class, iMap.getBigDecimal("TRX_NO"));

			if(kibFirmaYetkiLimitTx == null) {
				kibFirmaYetkiLimitTx = new KibFirmaYetkiLimitTx();
			}
			kibFirmaYetkiLimitTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kibFirmaYetkiLimitTx.setFirmaNo(iMap.getBigDecimal("FIRMA_NO"));
			if (iMap.getBoolean("INTERNETBANKACILIGI") == true ){
				kibFirmaYetkiLimitTx.setInternetBankaciligi("1");
			}else{
				kibFirmaYetkiLimitTx.setInternetBankaciligi("0");
			};

			if (iMap.getBoolean("CAGRIMERKEZI") == true ){
				kibFirmaYetkiLimitTx.setCagriMerkezi("1");
			}else{
				kibFirmaYetkiLimitTx.setCagriMerkezi("0");
			};


			kibFirmaYetkiLimitTx.setFirmaYetkiTuru(iMap.getString("FIRMAYETKITURU"));
			if(!("2").equals(iMap.getString("FIRMAYETKITURU"))){
				if(iMap.getString("FIRMAONAYSISTEMI_YEDEK")!= null && !iMap.getString("FIRMAONAYSISTEMI_YEDEK").equals(iMap.getString("FIRMAONAYSISTEMI"))){
					GMServiceExecuter.call("BNSPR_TRN4200_KULLANICI_KONTROL",iMap);
				}
			}
			kibFirmaYetkiLimitTx.setFirmaOnaySistemi(iMap.getString("FIRMAONAYSISTEMI"));
			if(iMap.getString("FIRMAYETKITURU")!= null && iMap.getString("FIRMAYETKITURU_YEDEK")!= null && ("2").equals(iMap.getString("FIRMAYETKITURU")) && ("1").equals(iMap.getString("FIRMAYETKITURU_YEDEK"))){
					GMServiceExecuter.call("BNSPR_TRN4200_YETKI_KONTROL",iMap);
				}
			kibFirmaYetkiLimitTx.setIpAraligiBas(iMap.getString("IPBAS"));
			kibFirmaYetkiLimitTx.setIpAraligiSon(iMap.getString("IPSON"));
			
			String tableName = "TBL_ISLEM_YETKISI";
			List<?> recordList = (List<?>)iMap.get(tableName);
			
			for(int i = 0; i < recordList.size(); i++) {
				KibFirmaYetkiLimitDetayTxId id = new KibFirmaYetkiLimitDetayTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setFirmaNo(iMap.getBigDecimal("FIRMA_NO"));
				id.setIslemKod(iMap.getString(tableName, i,"ISLEM"));
				KibFirmaYetkiLimitDetayTx kibFirmaYetkiLimitDetayTx = new KibFirmaYetkiLimitDetayTx();
				kibFirmaYetkiLimitDetayTx.setId(id);
				kibFirmaYetkiLimitDetayTx.setDovizCinsi(iMap.getString(tableName, i,"DOVIZ_CINSI"));
				kibFirmaYetkiLimitDetayTx.setGunlukLimit(iMap.getBigDecimal(tableName, i,"GUNLUK_LIMITI")!= null ? iMap.getBigDecimal(tableName, i,"GUNLUK_LIMITI"):new BigDecimal(0));
				kibFirmaYetkiLimitDetayTx.setProsesKod(iMap.getString(tableName, i,"PROSES_KOD"));
				session.saveOrUpdate(kibFirmaYetkiLimitDetayTx);
				session.flush();
			}
			

			session.saveOrUpdate(kibFirmaYetkiLimitTx);
			session.flush();

			iMap.put("TRX_NAME", "4200");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN4200_GET_INFO")
	public static Map<?, ?> trn4200GetInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
        
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			KibFirmaYetkiLimitTx kibFirmaYetkiLimitTx = (KibFirmaYetkiLimitTx)session.createCriteria(KibFirmaYetkiLimitTx.class)
			.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
			.uniqueResult();			

			oMap.put("FIRMA_NO"				, kibFirmaYetkiLimitTx.getFirmaNo());
			oMap.put("INTERNETBANKACILIGI"  , kibFirmaYetkiLimitTx.getInternetBankaciligi());
			oMap.put("CAGRIMERKEZI"			, kibFirmaYetkiLimitTx.getCagriMerkezi());
			oMap.put("FIRMAYETKITURU"		, kibFirmaYetkiLimitTx.getFirmaYetkiTuru());
			oMap.put("FIRMAONAYSISTEMI"			, kibFirmaYetkiLimitTx.getFirmaOnaySistemi());
			//oMap.put("DOVIZCINSI", kibFirmaYetkiLimitTx.getDovizCinsi());
			oMap.put("GUNLUKLIMIT"					, kibFirmaYetkiLimitTx.getGunlukLimit());
			oMap.put("IPBAS"			, kibFirmaYetkiLimitTx.getIpAraligiBas());
			oMap.put("IPSON"	, kibFirmaYetkiLimitTx.getIpAraligiSon());
			oMap.put("TRX_NO"		, kibFirmaYetkiLimitTx.getTxNo());

			oMap.put("FIRMAADI", LovHelper.diLov(kibFirmaYetkiLimitTx.getFirmaNo(), "4200/LOV_MUSTERI_NO", "UNVAN"));
			//oMap.put("DOVIZADI", LovHelper.diLov(kibFirmaYetkiLimitTx.getDovizCinsi(), "4200/LOV_DOVIZ", "ACIKLAMA"));
			
			int row = 0;
			conn = DALUtil.getGMConnection();
			List<?> kibFirmaYetkiDetayList = session.createCriteria(KibFirmaYetkiLimitDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "TBL_ISLEM_YETKISI";
			for (Iterator<?> iterator = kibFirmaYetkiDetayList.iterator(); iterator.hasNext();row++) {
				KibFirmaYetkiLimitDetayTx kibFirmaYetkiDetay = (KibFirmaYetkiLimitDetayTx) iterator.next();
				oMap.put(tableName, row,"ISLEM",kibFirmaYetkiDetay.getId().getIslemKod());
				oMap.put(tableName, row,"GUNLUK_LIMITI",kibFirmaYetkiDetay.getGunlukLimit());
				oMap.put(tableName, row,"DOVIZ_CINSI", kibFirmaYetkiDetay.getDovizCinsi());

				/*stmt = conn.prepareCall("{? = call PKG_TRN4203.get_islem_Aciklama(?)}");
				stmt.registerOutParameter (1, Types.VARCHAR); 
				stmt.setString( 2,kibFirmaYetkiDetay.getId().getIslemKod());					
				stmt.execute();
				*/
				oMap.put(tableName, row,"ACIKLAMA", 
						AdcWinspireServices.getProcessName(kibFirmaYetkiDetay.getProsesKod())/*stmt.getObject(1)*/);
			}	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN4200_GET_FIRMA_DETAY")
	public static Map<?, ?> trn4200GetFirmaDetay(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			KibFirmaYetkiLimit kibFirmaYetkiLimit = (KibFirmaYetkiLimit)session.createCriteria(KibFirmaYetkiLimit.class)
			.add(Restrictions.eq("firmaNo", iMap.getBigDecimal("FIRMA_NO")))
			.uniqueResult();	

			oMap.put("INTERNETBANKACILIGI"  , true);
			oMap.put("CAGRIMERKEZI"			, false);
			oMap.put("GUNLUKLIMIT"	,0);
			
			List<?> islemYetkiListTemp = (List<?>)iMap.get("TBL_ISLEM_YETKISI");
			for(int j = 0; j < islemYetkiListTemp.size(); j++) {
				oMap.put("TBL_ISLEM_YETKISI",j,"ISLEM",iMap.getString("TBL_ISLEM_YETKISI",j,"ISLEM"));
				oMap.put("TBL_ISLEM_YETKISI",j,"ACIKLAMA",iMap.getString("TBL_ISLEM_YETKISI",j,"ACIKLAMA"));
				oMap.put("TBL_ISLEM_YETKISI",j,"PROSES_KOD",iMap.getString("TBL_ISLEM_YETKISI",j,"PROSES_KOD"));
				oMap.put("TBL_ISLEM_YETKISI",j,"GUNLUK_LIMIT",iMap.getString("TBL_ISLEM_YETKISI",j,"GUNLUK_LIMIT"));
				oMap.put("TBL_ISLEM_YETKISI",j,"DOVIZ_CINSI",iMap.getString("TBL_ISLEM_YETKISI",j,"DOVIZ_CINSI"));
			}
			
			if(kibFirmaYetkiLimit != null) {

				oMap.put("INTERNETBANKACILIGI"  , kibFirmaYetkiLimit.getInternetBankacigi());
				oMap.put("CAGRIMERKEZI"			, kibFirmaYetkiLimit.getCagriMerkezi());
				oMap.put("FIRMAYETKITURU"		, kibFirmaYetkiLimit.getFirmaYetkiTuru());
				oMap.put("FIRMAONAYSISTEMI"			, kibFirmaYetkiLimit.getFirmaOnaySistemi());
				oMap.put("IPBAS"			, kibFirmaYetkiLimit.getIpAraligiBas());
				oMap.put("IPSON"	, kibFirmaYetkiLimit.getIpAraligiSon());

				GMMap sMap = new GMMap();
				sMap.put("ACTION", "LIST");
				sMap.put("CHANNEL_CODE", "CINT");
				sMap.put("USERNAME", AdcWinspireServices.getUserName(iMap.getString("FIRMA_NO"),iMap.getString("FIRMA_NO")));
				sMap.put("PROCESS_CODE", "*");
				sMap.put("LIMIT_TYPE", new BigDecimal(1));
				
				GMMap pAmountLimitMap = GMServiceExecuter.call("ADK_LIST_USER_PROCESS_AMOUNT_LIMITS" , sMap);
				
							
				String tableName = "USER_PROCESS_AMOUNT_LIMITS";
				List<?> recordList = (List<?>)pAmountLimitMap.get(tableName);

				for(int i = 0; recordList != null && i < recordList.size(); i++) {
					
					List<?> islemYetkiList = (List<?>)iMap.get("TBL_ISLEM_YETKISI");
					for(int j = 0; j < islemYetkiList.size(); j++) {
						if(iMap.getString("TBL_ISLEM_YETKISI",j,"PROSES_KOD").equals(pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"PROCESS_CODE")) && 
						   iMap.getString("TBL_ISLEM_YETKISI",j,"DOVIZ_CINSI").equals(pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"CURRENCY_CODE")))
						{
							oMap.put("TBL_ISLEM_YETKISI",j,"GUNLUK_LIMITI",pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"MAX_AMOUNT"));
						}
					}
				}	
			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4200_CREATE_COMPANY")
	public static GMMap createAdk(GMMap iMap){
		
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN4200.ADK_user_create_check(?, ?, ?)}");

			stmt.registerOutParameter	(1, Types.NUMERIC);
			stmt.setBigDecimal			(2, iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter	(3, Types.VARCHAR);
			stmt.registerOutParameter	(4, Types.NUMERIC);
			
			stmt.execute();

			iMap.put("USERNAME"		, AdcWinspireServices.getUserName(stmt.getString(4),stmt.getString(4)));
	        
			iMap.put("MUSTERI_NO", stmt.getBigDecimal(4));
			
//			iMap.put("INTEGRATION"	, 0, "KEY"	, "MUSTERI_NO");
//			iMap.put("INTEGRATION"	, 0, "VALUE", stmt.getBigDecimal(4));

			iMap.put("INTEGRATION"	, 0, "KEY"	, "SEGMENT");
			iMap.put("INTEGRATION"	, 0, "VALUE", stmt.getString(3));

			iMap.put("CHANNELS"	, 0 , "CODE"	, "CINT");
			iMap.put("CHANNEL_CODE", "CINT");
			 
			GMServiceExecuter.call("ADK_CREATE_USER" , iMap);
			return new GMMap();

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN4200_SET_LIMIT")
	public static GMMap setLimit(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			KibFirmaYetkiLimitTx kibFirmaYetkiLimitTx = (KibFirmaYetkiLimitTx)session.createCriteria(KibFirmaYetkiLimitTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();	
			GMMap serviceMap = new GMMap();
			if(("1").equals(kibFirmaYetkiLimitTx.getFirmaYetkiTuru())){
				List<?> FirmaYetkiLimitDetay = session.createCriteria(KibFirmaYetkiLimitDetay.class).add(Restrictions.eq("id.firmaNo",kibFirmaYetkiLimitTx.getFirmaNo())).list();
				if (FirmaYetkiLimitDetay!= null && !FirmaYetkiLimitDetay.isEmpty()){
					int row = 0;
					String tableName = "LIMITS";
					for (Iterator<?> iterator = FirmaYetkiLimitDetay.iterator(); iterator.hasNext();) {	
					  KibFirmaYetkiLimitDetay firmaYetkiLimitDetay = (KibFirmaYetkiLimitDetay) iterator.next();
					    serviceMap.put(tableName, row,"PROCESS_CODE",firmaYetkiLimitDetay.getProsesKod());
						serviceMap.put("OTP_TYPE", new BigDecimal(0));
						serviceMap.put("CHANNEL_CODE", "CINT");
						serviceMap.put("USERNAME",AdcWinspireServices.getUserName(kibFirmaYetkiLimitTx.getFirmaNo(),kibFirmaYetkiLimitTx.getFirmaNo()));
						serviceMap.put("ACTION", "UPDATE");
						serviceMap.put(tableName, row,"LIMIT_TYPE", new BigDecimal(1));
						serviceMap.put(tableName, row,"CURRENCY_CODE", firmaYetkiLimitDetay.getDovizCinsi());
						serviceMap.put(tableName, row,"MAX_AMOUNT", firmaYetkiLimitDetay.getGunlukLimit());
						serviceMap.put(tableName, row,"MIN_AMOUNT", new BigDecimal(0));
						GMServiceExecuter.call("ADC_CORE_PROCESS_REMOTE_UPDATE", serviceMap);
					}
				}
		   }
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}

	@GraymoundService("BNSPR_TRN4200_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMServiceExecuter.call("BNSPR_TRN4200_CREATE_COMPANY", iMap);
			/*conn = GMServerDatasource.getConnection("java:/GraymoundDS");
			stmt = conn.prepareCall("{ call Pkg_TRN4203.Sorgula (?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.execute();
			ResultSet rSet = (ResultSet)stmt.getObject(1);
			
			while(rSet.next()){
		    iMap.put("DOVIZ_CINSI",rSet.getString("DOVIZ_CINSI")) ;
		    iMap.put("PROSES_KOD",rSet.getString("PROSES_KOD")) ;
			GMServiceExecuter.call("BNSPR_TRN4200_SET_LIMIT", iMap);
            }*/
			GMServiceExecuter.call("BNSPR_TRN4200_SET_LIMIT", iMap);
			GMServiceExecuter.call("BNSPR_TRN4200_FLOW_MANAGMENT", iMap);
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN4200_FLOW_MANAGMENT")
	public static GMMap flowManagment(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			KibFirmaYetkiLimitTx kibFirmaYetkiLimitTx = (KibFirmaYetkiLimitTx)session.createCriteria(KibFirmaYetkiLimitTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();	
			GMMap serviceMap = new GMMap();
			if(("1").equals(kibFirmaYetkiLimitTx.getFirmaYetkiTuru())){
			serviceMap.put("ACTION", "SAVE");
			serviceMap.put("PROCESS_CODE","*");
			serviceMap.put("CHANNEL_CODE", "CINT");
			serviceMap.put("USERNAME",AdcWinspireServices.getUserName(kibFirmaYetkiLimitTx.getFirmaNo(),kibFirmaYetkiLimitTx.getFirmaNo()));
			if(("2").equals(kibFirmaYetkiLimitTx.getFirmaOnaySistemi())){
				serviceMap.put("LIST"	, 0, "APPROVE_ORDER",new BigDecimal(1));
				serviceMap.put("LIST"	, 0, "APPROVE_COUNT",new BigDecimal(1));
			}else if(("3").equals(kibFirmaYetkiLimitTx.getFirmaOnaySistemi())){
				serviceMap.put("LIST"	, 0, "APPROVE_ORDER",new BigDecimal(1));
				serviceMap.put("LIST"	, 0, "APPROVE_COUNT",new BigDecimal(1));
				
				serviceMap.put("LIST"	, 1, "APPROVE_ORDER",new BigDecimal(2));
				serviceMap.put("LIST"	, 1, "APPROVE_COUNT",new BigDecimal(1));
	     	}else if(("4").equals(kibFirmaYetkiLimitTx.getFirmaOnaySistemi())){
	     		serviceMap.put("LIST"	, 0, "APPROVE_ORDER",new BigDecimal(1));
				serviceMap.put("LIST"	, 0, "APPROVE_COUNT",new BigDecimal(1));
				
				serviceMap.put("LIST"	, 1, "APPROVE_ORDER",new BigDecimal(2));
				serviceMap.put("LIST"	, 1, "APPROVE_COUNT",new BigDecimal(2));
	     	}
			return GMServiceExecuter.call("ADC_CORE_PROCESS_APPROVAL_FLOW_MANAGMENT", serviceMap);
			}else return new GMMap();

		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/*public static boolean validateIP(String ip){;
	try {
		if( ip == null || ip.equals("") ) return true;

		StringTokenizer tok = new StringTokenizer(ip,".");
		if(ip.startsWith(".") || ip.endsWith(".") || ip.contains("..")){
			return false;
		}
		//if(ip.)
		int numberOfToken = 1;
		while(tok.hasMoreTokens()){
			String strTok = tok.nextToken();
			try{
				Integer.parseInt(strTok);
			}catch (Exception e) {
				return false;
			}
			if(strTok.length()>3){
				return false;
			}
			numberOfToken ++;
			
		}
		if(numberOfToken !=5)
			return false;
	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	} 
	return true;
}*/
	
	@GraymoundService("BNSPR_TRN4200_KULLANICI_KONTROL")
	public static GMMap kullaniciVarmiKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap sMap = new GMMap();
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KIB.RC_QRY4201_Sorgula(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_NO"));
			stmt.setBigDecimal(i++, null);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			int j = 0 ;
			while(rSet.next()){
					sMap = new GMMap();
					sMap.put("ACTION", "LIST");
					sMap.put("CHANNEL_CODE", "CINT");
					sMap.put("PARENT_USERNAME", AdcWinspireServices.getUserName(iMap.getString("FIRMA_NO"),iMap.getString("FIRMA_NO")) );
					sMap.put("USERNAME", AdcWinspireServices.getUserName(rSet.getString("KULLANICI_KODU"),iMap.getString("FIRMA_NO")));
					sMap.put("PROCESS_CODE", "*");
			
			GMMap rMap = GMServiceExecuter.call("ADC_CORE_PROCESS_APPROVAL_USER_MANAGMENT" , sMap);
			String tableName = "APPROVALS";
			List<?> recordList = (List<?>)rMap.get(tableName);
			for(int k = 0;recordList != null && k < recordList.size(); k++) {
				sMap.put("HATA_NO", "1509");
				sMap.put("P1", 	 rSet.getString("KULLANICI_KODU"));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			    j++;
        	}
		}
		return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}

	@GraymoundService("BNSPR_QRY4200_TABLO")
	public static GMMap setTables(GMMap iMap)throws ParseException{
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call Pkg_TRN4200.Sorgula (?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "TBL_ISLEM_YETKISI" ; 
			int var = 0 ;
				
			while(rSet.next()){
				oMap.put(tableName,var,"ISLEM", rSet.getString("ISLEM"));
				oMap.put(tableName,var,"KULLANICI_LIMIT", rSet.getString("KULLANICI_LIMIT"));
				oMap.put(tableName,var,"DOVIZ_CINSI", rSet.getString("DOVIZ_CINSI"));
		    	
				oMap.put(tableName,var,"ACIKLAMA", AdcWinspireServices.getProcessName(rSet.getString("PROSES_KOD"))/*rSet.getString("ACIKLAMA")*/);

		    	oMap.put(tableName,var,"PROSES_KOD",rSet.getString("PROSES_KOD"));
			var++;
        	}
			
		return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

		
/*	@GraymoundService("BNSPR_TRN4200_YETKI_KONTROL")
	public static Map<?, ?> trn4201GetLimitVarmiKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap sMap = new GMMap();
		ResultSet rSet = null;
		try{
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");
			stmt = conn.prepareCall("{? = call PKG_KIB.RC_QRY4201_Sorgula(?,?)}");
			stmt.registerOutParameter(1, -10); //ref cursor			
			stmt.setBigDecimal(2, iMap.getBigDecimal("FIRMA_NO"));
			stmt.setBigDecimal(3, null);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			while(rSet.next()){	
					
					sMap = new GMMap();
					sMap.put("ACTION", "LIST");
					sMap.put("CHANNEL_CODE", "CINT");
					sMap.put("PARENT_USERNAME", AdcWinspireServices.getUserName(iMap.getString("FIRMA_NO"),iMap.getString("FIRMA_NO")));
					sMap.put("USERNAME", AdcWinspireServices.getUserName(rSet.getString("KULLANICI_KODU"),iMap.getString("FIRMA_NO")));
					sMap.put("PROCESS_CODE", "*");
		
					GMMap rMap = GMServiceExecuter.call("ADC_CORE_PROCESS_APPROVAL_USER_MANAGMENT" , sMap);
			   		
					sMap.put("LIMIT_TYPE", new BigDecimal(1));
					GMMap pAmountLimitMap = GMServiceExecuter.call("ADK_LIST_USER_PROCESS_AMOUNT_LIMITS" , sMap);
			
					GMMap xxMap = new GMMap();
					xxMap.put("FIRMA_NO", iMap.getString("FIRMA_NO"));
					GMMap xMap = GMServiceExecuter.call("BNSPR_QRY4203_TABLO",xxMap);
					
					
					List<?> islemYetkiList = (List<?>)xMap.get("TBL_ISLEM_YETKISI");
					for(int j = 0; j < islemYetkiList.size(); j++) {
						oMap.put("TBL_ISLEM_YETKISI",j,"PROSES_KOD",xMap.getString("TBL_ISLEM_YETKISI",j,"PROSES_KOD"));
					}
								
					String tableName = "USER_PROCESS_AMOUNT_LIMITS";
					List<?> recordList = (List<?>)pAmountLimitMap.get(tableName);
					int say = 0; 		
					for(int i = 0; recordList != null && i < recordList.size(); i++) {
						for(int j = 0; j < islemYetkiList.size(); j++) {
							if(oMap.getString("TBL_ISLEM_YETKISI",j,"PROSES_KOD").equals(pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"PROCESS_CODE")))
							{
							    if(new Double(pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"MAX_AMOUNT"))>0)
									say++;	
							}
						}
						
					}
					
					tableName = "APPROVALS";
					recordList = (List<?>)rMap.get(tableName);
					
					int flowType = GMServiceExecuter.call("ADK_GET_APPROVAL_FLOW_TYPE", xxMap).getInt("APPROVAL_FLOW_TYPE");
					int sayonay =0;
					int sayononay =0;
					
					for(int i = 0;recordList != null && i < recordList.size(); i++) {
						
						if(rMap.getString(tableName,i,"APPROVE_ORDER").equals("2"))
						{
							List<?> onayList = (List<?>)xMap.get("tblONAY");
							for(int j = 0; j < onayList.size(); j++) {
								if(xMap.getString("tblONAY",j,"PROSES_KOD").equals(rMap.getString("APPROVALS",i,"PROCESS_CODE")))
									sayonay++;
							}
						}
						else if(rMap.getString(tableName,i,"APPROVE_ORDER").equals("1"))
						{
							if (flowType==2) {
								List<?> onOnayList = (List<?>)xMap.get("tblON_ONAY");
								for(int j = 0; j < onOnayList.size(); j++) {
									if(xMap.getString("tblON_ONAY",j,"PROSES_KOD").equals(rMap.getString("APPROVALS",i,"PROCESS_CODE")))
										sayononay++;
								}
							} else if (flowType==1) {
								List<?> onayList = (List<?>)xMap.get("tblONAY");
								for(int j = 0; j < onayList.size(); j++) {
									if(xMap.getString("tblONAY",j,"PROSES_KOD").equals(rMap.getString("APPROVALS",i,"PROCESS_CODE")))
										sayonay++;
								}
							}
						}
					}
			
			if (say + sayonay + sayononay != 0){
				iMap.put("HATA_NO", "1518");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}	
			return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
*/
	@GraymoundService("BNSPR_TRN4200_YETKI_KONTROL")
	public static Map<?, ?> IslemYetkiliKullaniciVarmiKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN4200.firmaninIslemciKullVarmi(?)}");
			stmt.registerOutParameter(1, Types.DECIMAL); 			
			stmt.setBigDecimal(2, iMap.getBigDecimal("FIRMA_NO"));
			stmt.execute();
			if (stmt.getBoolean(1)){
				iMap.put("HATA_NO", "1525");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
