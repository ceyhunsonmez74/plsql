package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKanalislemTanimPrTx;
import tr.com.calikbank.bnspr.dao.GnlKanalislemTanimPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4154Services {
	@GraymoundService("BNSPR_QRY4154_GET_KANAL_ISLEM_TANIMLAMA")
	public static GMMap getBlokeList(GMMap iMap)throws ParseException{

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call  PKG_RC_ADC.RC_QRY4154_get_Kanal_Islem_Sor(?,?,?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KOD"));
			stmt.setString(i++, iMap.getString("MODUL_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.setString(i++,GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("F_ONLINE")));
			stmt.setString(i++,GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("F_TALIMATLI")));
			stmt.setString(i++,GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("F_HEPSI")));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "KANAL_ISLEM_TANIMLAMA";

			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "KANAL_KOD", rSet.getBigDecimal("kanal_kod"));
				oMap.put(tableName, row, "MODUL_KOD", rSet.getString("modul_kod"));
				oMap.put(tableName, row, "ISLEM_KOD", rSet.getString("islem_kod"));
				oMap.put(tableName, row, "ISLEM_ACIKLAMA", LovHelper.diLov(oMap.getBigDecimal(tableName, row, "ISLEM_KOD"), oMap.getString(tableName, row, "MODUL_KOD"), "4154/LOV_ISLEM_GRUBU", "ACIKLAMA"));
				oMap.put(tableName, row, "F_ONLINE",GuimlUtil.convertToCheckBoxValue(rSet.getString("f_online")));
				oMap.put(tableName, row, "F_TALIMATLI",GuimlUtil.convertToCheckBoxValue(rSet.getString("f_talimatli")));
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", rSet.getString("iptal_edilebilir_mi"));
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", rSet.getString("geri_cevrilebilir_mi"));
				oMap.put(tableName, row, "ID", rSet.getBigDecimal("ID"));
				oMap.put(tableName, row, "G_D_S",false);
				oMap.put(tableName, row, "DURUM" ,"E");
				oMap.put(tableName, row, "PROSES_KOD" ,rSet.getString("proses_kod"));
				row++;
			}
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_TRN4154_SAVE_KANAL_ISLEM_TANIMLAMA")
	public static GMMap saveTRN4154EsaveKanalIslemTanim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "KANAL_ISLEM_TANIMLAMA";
			List<?> list = (List<?>) iMap.get(tableName);
			for(int i=0; i<list.size();i++) {
				GnlKanalislemTanimPrTxId id = new GnlKanalislemTanimPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setId(iMap.getBigDecimal(tableName, i, "ID"));
				GnlKanalislemTanimPrTx gnlKanalIslemTanimPrTx = new GnlKanalislemTanimPrTx();
				gnlKanalIslemTanimPrTx.setId(id);
				gnlKanalIslemTanimPrTx.setModulKod(iMap.getString(tableName, i,"MODUL_KOD"));
				gnlKanalIslemTanimPrTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				gnlKanalIslemTanimPrTx.setIslemKod(iMap.getBigDecimal(tableName, i, "ISLEM_KOD"));
				gnlKanalIslemTanimPrTx.setProsesKod(iMap.getString(tableName, i,"PROSES_KOD"));
				gnlKanalIslemTanimPrTx.setIptalEdilebilirMi(iMap.getString(tableName, i, "IPTAL_EDILEBILIR_MI"));
				gnlKanalIslemTanimPrTx.setGeriCevrilebilirMi(iMap.getString(tableName, i, "GERI_CEVRILEBILIR_MI"));
				gnlKanalIslemTanimPrTx.setFOnline(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "F_ONLINE")));
				gnlKanalIslemTanimPrTx.setFTalimatli(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "F_TALIMATLI")));
				gnlKanalIslemTanimPrTx.setGDS(iMap.getBoolean(tableName, i, "G_D_S") ? "S" : "G");
			

				session.saveOrUpdate(gnlKanalIslemTanimPrTx);
			}

			session.flush();

			iMap.put("TRX_NAME", "4154");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	
	
	/*catch (ConstraintViolationException e) {
	GMMap myMap = new GMMap();
	myMap.put("MESSAGE_NO", new BigDecimal(715));
	throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
}*/

	@GraymoundService("BNSPR_TRN4154_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(GnlKanalislemTanimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "KANAL_ISLEM_TANIMLAMA";
			int row = 0;
			GMMap oMap = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlKanalislemTanimPrTx gnlKanalIslemTanimPrTx = (GnlKanalislemTanimPrTx) iterator.next();
				oMap.put(tableName, row, "ID", gnlKanalIslemTanimPrTx.getId().getId());
				oMap.put(tableName, row, "KANAL_KOD", gnlKanalIslemTanimPrTx.getKanalKod());
				oMap.put(tableName, row, "MODUL_KOD", gnlKanalIslemTanimPrTx.getModulKod());
				oMap.put(tableName, row, "ISLEM_KOD", gnlKanalIslemTanimPrTx.getIslemKod());
				oMap.put(tableName, row, "ISLEM_ACIKLAMA", LovHelper.diLov(gnlKanalIslemTanimPrTx.getIslemKod(), gnlKanalIslemTanimPrTx.getModulKod(), "4154/LOV_ISLEM_GRUBU", "ACIKLAMA")); 
				oMap.put(tableName, row, "F_ONLINE", GuimlUtil.convertToCheckBoxValue(gnlKanalIslemTanimPrTx.getFOnline()));
				oMap.put(tableName, row, "F_TALIMATLI",GuimlUtil.convertToCheckBoxValue(gnlKanalIslemTanimPrTx.getFTalimatli()));	
				oMap.put(tableName, row, "IPTAL_EDILEBILIR_MI", gnlKanalIslemTanimPrTx.getIptalEdilebilirMi());
				oMap.put(tableName, row, "GERI_CEVRILEBILIR_MI", gnlKanalIslemTanimPrTx.getGeriCevrilebilirMi());
				oMap.put(tableName, row, "G_D_S", "S".equals(gnlKanalIslemTanimPrTx.getGDS()));
				oMap.put(tableName, row, "PROSES_KOD", gnlKanalIslemTanimPrTx.getProsesKod());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}


