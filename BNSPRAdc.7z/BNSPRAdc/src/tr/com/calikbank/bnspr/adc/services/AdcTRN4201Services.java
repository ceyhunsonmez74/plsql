package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4201Services {
		
	@GraymoundService("BNSPR_TRN4201_GET_KULLANICI")
	public static GMMap listele(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			 
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KIB.RC_QRY4201_Sorgula(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor			
			if ( iMap.getBigDecimal ( "FIRMA_KODU" ) == null ) {
				iMap.put("MESSAGE_NO", new BigDecimal(330));
				iMap.put("P1", "FIRMA_KODU");
				oMap.put("MESSAGE",(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				return oMap;
			}
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			String tableName = "KULLANICI_LISTESI" ; 
			int var = 0 ;
			
			GMConnection gmConn = GMConnection.getConnection("CINT");
			while(rSet.next()){
				oMap.put(tableName,var,"KULLANICI_KODU", rSet.getString("KULLANICI_KODU"));
				oMap.put(tableName,var,"KULLANICI_UNVANI", rSet.getString("KULLANICI_UNVANI"));
				oMap.put(tableName,var,"TANIMLANMA_TARIHI", rSet.getString("TANIMLANMA_TARIHI"));
				oMap.put(tableName,var,"TANIMLAYAN_KULLANICI", rSet.getString("TANIMLAYAN_KULLANICI"));
				oMap.put(tableName,var,"YETKI_TURU", rSet.getString("YETKI_TURU"));
				oMap.put(tableName,var,"MUSTERI_TIPI", rSet.getString("MUSTERI_TIPI"));
				oMap.put(tableName,var,"KULLANICI_TIPI",rSet.getString("KULLANICI_TIPI"));
				oMap.put(tableName,var,"SERI_NO",rSet.getString("SERI_NO"));
			   iMap.put("USER_CODE",AdcWinspireServices.getUserName(rSet.getBigDecimal("KULLANICI_KODU"),iMap.getBigDecimal("FIRMA_KODU")));
			   GMMap myMap = new GMMap(gmConn.serviceCall("ADC_CINT_GET_USER_APPROVAL_AUTHORITIES", iMap));
			  	if (myMap.getBoolean("2")){
	                if (myMap.getBoolean("1")){
	                oMap.put(tableName,var,"KULLANICI_YETKI", "�n Onayc� - Onayc�");
				  	}else{	
		            oMap.put(tableName,var,"KULLANICI_YETKI", "Onayc�");
 				  	}
			  	}else if (myMap.getBoolean("1")){
		            oMap.put(tableName,var,"KULLANICI_YETKI", "�n Onayc�");
			  	}
			  	if (myMap.getBoolean("3")){
		            oMap.put(tableName,var,"KULLANICI_YETKI", "�naktif M��teri");
			  	}
			  
			  	GMMap sMap =  new GMMap();
			  	sMap.put("MUSTERI_NO",iMap.getBigDecimal("FIRMA_KODU"));
			  	sMap.put("KULLANICI_KOD",rSet.getString("KULLANICI_KODU"));
				myMap = new GMMap(GMServiceExecuter.call("BNSPR_TRN4131_GET_KANAL_BLOKE", sMap));
				if(myMap.getSize("BLOKE_BILGI") > 0){
			    	oMap.put(tableName,var,"BLOKE_DURUMU", "Blokeli");
			    }else{
					oMap.put(tableName,var,"BLOKE_DURUMU", "Blokesiz");
				}
				
				var++;
        	}
		return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}
	
	@GraymoundService("BNSPR_TRN4201_KULLANICI_KONTROL")
	public static GMMap kullaniciKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			
			if ( iMap.getBigDecimal ( "KULLANICI_KODU" ) == null ) {
				iMap.put("MESSAGE_NO", new BigDecimal(1398));
				oMap.put("K_MESSAGE",(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				return oMap;
			}
				return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
		}
	}
	
	@GraymoundService("BNSPR_TRN4203_YETKI_KONTROL")
	public static GMMap yetkiLimitKontrol(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			 
			String yetki = DALUtil.getResult("select nvl(f_sifre_tanimi,'H') from kib_kullanici_tanim t where t.kullanici_no = " + iMap.getBigDecimal ( "KULLANICI_KODU" )+
											 " and firma_no = " +  iMap.getBigDecimal ( "FIRMA_KODU" ));
			
			if ( yetki.equals("H") ) {
				iMap.put("MESSAGE_NO", new BigDecimal(1502));
				oMap.put("K_MESSAGE",(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
		}
	}

	@GraymoundService("BNSPR_TRN4201_SIFRE_DURUMU")
	public static GMMap sifreDurumu(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC4207.kib_kullanici_sifre_durumu(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC); //ref cursor			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.execute();
			if (!new BigDecimal(0).equals(stmt.getObject(1))){
				iMap.put("HATA_NO", "1510");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	     	}
		return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
			
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	

	@GraymoundService("BNSPR_TRN4201_LIMIT_VARMI_KONTROL")
	public static Map<?, ?> trn4201GetLimitVarmiKontrol(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			GMMap sMap = new GMMap();
			sMap.put("ACTION", "LIST");
			sMap.put("CHANNEL_CODE", "CINT");
			sMap.put("PARENT_USERNAME", AdcWinspireServices.getUserName(iMap.getString("FIRMA_NO"),iMap.getString("FIRMA_NO")) );
			sMap.put("USERNAME", AdcWinspireServices.getUserName(iMap.getString("KULLANICI_KOD"),iMap.getString("FIRMA_NO")));
			sMap.put("PROCESS_CODE", "*");
			sMap.put("LIMIT_TYPE", new BigDecimal(1));
			GMMap pAmountLimitMap = GMServiceExecuter.call("ADK_LIST_USER_PROCESS_AMOUNT_LIMITS" , sMap);
			if(pAmountLimitMap.isEmpty()){
			iMap.put("HATA_NO", "1513");
			return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
		
	@GraymoundService("BNSPR_TRN4201_SIFRE_TANIMI_VARMI")
	public static GMMap sifreTanimiVarMi(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC4207.kib_kullanici_sifre_durumu(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC); //ref cursor			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.execute();
			if (new BigDecimal(0).equals(stmt.getObject(1))){
				iMap.put("MESSAGE_NO", new BigDecimal(1699));
				oMap.put("K_MESSAGE",(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
	     	}
		return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	
}