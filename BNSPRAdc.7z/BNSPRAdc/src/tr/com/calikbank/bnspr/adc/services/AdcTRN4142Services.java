package tr.com.calikbank.bnspr.adc.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkBannerUserTx;
import tr.com.calikbank.bnspr.dao.AdkBannerUserTxId;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4142Services {

	@GraymoundService("BNSPR_TRN4142_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			GMMap xMap = new GMMap();
	        if(("CINT").equals(iMap.getString("KANAL_KOD"))){
				iMap.put("KOD", "MUSTERI_TUZEL_SEGMENT");
				iMap.put("ADD_EMPTY_KEY", "E");
				oMap.put("MUSTERI_SEGMENTI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		  } else if(("INT").equals(iMap.getString("KANAL_KOD"))){
			    iMap.put("KOD", "MUSTERI_GERCEK_SEGMENT");
				iMap.put("ADD_EMPTY_KEY", "E");
				oMap.put("MUSTERI_SEGMENTI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		  } else if (iMap.getString("KANAL_KOD") == null ||iMap.getString("KANAL_KOD").isEmpty()){
		        iMap.put("KOD", "MUSTERI_GERCEK_SEGMENT");
				iMap.put("ADD_EMPTY_KEY", "E");
				oMap.put("MUSTERI_SEGMENTI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
				iMap.put("KOD", "MUSTERI_TUZEL_SEGMENT");
				iMap.put("ADD_EMPTY_KEY", "H");
				xMap.put("MUSTERI_SEGMENTI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
				int size = oMap.getSize("MUSTERI_SEGMENTI");
				for (int i= 0; i < xMap.getSize("MUSTERI_SEGMENTI");i++){
					oMap.put("MUSTERI_SEGMENTI",size ,"VALUE", xMap.getString("MUSTERI_SEGMENTI",i,"VALUE"));
					oMap.put("MUSTERI_SEGMENTI",size ,"NAME", xMap.getString("MUSTERI_SEGMENTI",i,"NAME"));
					size ++;
				}
		}
		return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
    @GraymoundService("BNSPR_TRN4142_BANNER_LIST")
    public static GMMap BannerList(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	try {
   		GMMap myMap = new GMMap(GMServiceExecuter.execute("ADC_MAN_BANNER_LIST", iMap));
		
		for(int i = 0;i < myMap.getSize("LIST");i++) {
            oMap.put("T_BANNER",i,"BANNER_KEY",myMap.get("LIST",i,"BANNER_KEY"));
            oMap.put("T_BANNER",i,"BANNER_PAGE",LovHelper.diLov(myMap.get("LIST",i,"BANNER_KEY"), "4141/LOV_BANNER_TYPE", "BANNER_PAGE"));
            oMap.put("T_BANNER",i,"BANNER_TYPE",myMap.get("LIST",i,"BANNER_TYPE"));
            oMap.put("T_BANNER",i,"PRIORITY",myMap.get("LIST",i,"PRIORITY"));
            oMap.put("T_BANNER",i,"DESTINATION_TYPE",myMap.get("LIST",i,"DESTINATION_TYPE"));
            oMap.put("T_BANNER",i,"DESTINATION_URL",myMap.get("LIST",i,"DESTINATION_URL"));
            oMap.put("T_BANNER",i,"TITLE",myMap.get("LIST",i,"TITLE"));
            oMap.put("T_BANNER",i,"END_DATE",myMap.get("LIST",i,"END_DATE"));
            oMap.put("T_BANNER",i,"START_DATE",myMap.get("LIST",i,"START_DATE"));
            oMap.put("T_BANNER",i,"G_D_S",myMap.get("LIST",i,"G_D_S"));
            oMap.put("T_BANNER",i,"INT_ID",myMap.get("LIST",i,"INT_ID"));
            oMap.put("T_BANNER",i,"KANAL_KOD",myMap.get("LIST",i,"CHANNEL_CODE"));
            oMap.put("T_BANNER",i,"SOURCE_URL",myMap.get("LIST",i,"SOURCE_URL"));
            oMap.put("T_BANNER",i,"LANGUAGE",myMap.get("LIST",i,"LANGUAGE"));
	            }
	        return oMap;
		    }
			 catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}  
	    }
		
    @GraymoundService("BNSPR_TRN4142_USER_LIST")
    public static GMMap UserList(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	try {
    	iMap.getBigDecimal("INT_ID");
   		GMMap myMap = new GMMap(GMServiceExecuter.execute("ADC_MAN_BANNER_USER_LIST", iMap));
		
		for(int i = 0;i < myMap.getSize("LIST");i++) {
                oMap.put("T_USER",i,"OID",myMap.get("LIST",i,"OID"));
                oMap.put("T_USER",i,"BANNER_KEY",myMap.get("LIST",i,"BANNER_OID"));
                oMap.put("T_USER",i,"GROUP_KEY",myMap.get("LIST",i,"GROUP_KEY"));
                oMap.put("T_USER",i,"GROUP",LovHelper.diLov(myMap.get("LIST",i,"GROUP_KEY"), "4142/LOV_MUSTERI_GRUBU", "ACIKLAMA"));
                oMap.put("T_USER",i,"SEGMENT_KEY",myMap.get("LIST",i,"SEGMENT_KEY"));
                oMap.put("T_USER",i,"INT_ID",myMap.get("LIST",i,"INT_ID"));
                oMap.put("T_USER",i,"MUSTERI_NO",myMap.get("LIST",i,"USER_OID"));
                oMap.put("T_USER",i,"CUSTOMER_NO",myMap.get("LIST",i,"CUSTOMER_NO"));
	            }
	        return oMap;
		    }catch (Exception e) {
			   throw ExceptionHandler.convertException(e);
			}  
	    }

	@GraymoundService("BNSPR_TRN4142_LOAD_DATA_FROM_EXCEL_FILE")
	public static Map<?, ?> loadDataFromExcelFile(GMMap iMap) {
		GMMap oMap = new GMMap();
		int colCount = 0;
		int rowCount = 0;
		try {
			if (iMap.get("DOSYA") == null)
				throw new GMRuntimeException(0, "Dosya bulunamad�");
			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")));
			Sheet musteriSheet = workbook.getSheet(0);
			String tableName = "MUSTERI_DATA";

			for (rowCount = 0; rowCount < musteriSheet.getRows(); rowCount++) {
				if(musteriSheet.getCell(0, rowCount).getContents() == null || musteriSheet.getCell(0, rowCount).getContents().isEmpty()) // 0. column bo�sa atla 
					continue;
			    colCount = 0;
				String musteriNo = musteriSheet.getCell(colCount++, rowCount).getContents().trim();
				oMap.put(tableName, rowCount  ,"MUSTERI_NO", musteriNo);
			  //oMap.put(tableName, rowCount  ,"UNVAN", musteriSheet.getCell(colCount++, rowCount).getContents());
				oMap.put(tableName, rowCount  ,"UNVAN", LovHelper.diLov(musteriNo, "4142/LOV_MUSTERI_NO", "MUSTERI_ADI"));
			}
			workbook.close();
			return oMap;
		} catch (Exception e) {
			GMMap servisMap = new GMMap();
			servisMap.put("MESSAGE_NO", new BigDecimal(1019));
			servisMap.put("P1", rowCount + "");
			servisMap.put("P2", colCount + "");
			//"Excel format�nda hata. Sat�r: " + rowCount + " S�tun: " + colCount);
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", servisMap).get("ERROR_MESSAGE"));
		}
	}
    
	@GraymoundService("BNSPR_TRN4142_SAVE")
	public static GMMap saveTRN4142(GMMap iMap){
	try {
		Session session = DAOSession.getSession("BNSPRDal");
		AdkBannerUserTxId id = new AdkBannerUserTxId();
		id.setTxNo(iMap.getBigDecimal("TRX_NO"));
		String musteriGrubu = iMap.getString("MUSTERI_GRUBU");
		String musteriSegmenti = iMap.getString("MUSTERI_SEGMENTI");
		BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
		char GDS = iMap.getString("G_D_S").toCharArray()[0];
		String kanalKod = iMap.getString("KANAL_KOD");
		BigDecimal intId = iMap.getBigDecimal("INT_ID");
		String oid = iMap.getString("OID");
		AdkBannerUserTx adkBannerUserTx = new AdkBannerUserTx();
			
		if(iMap.getBoolean("rdbMUSTERIGRUP") || iMap.getBoolean("rdbMUSTERISEGMENT") || iMap.getBoolean("rdbTEKMUSTERI") ){
			      if(iMap.getBoolean("rdbMUSTERIGRUP")){	
			    	if(musteriGrubu == null || musteriGrubu.isEmpty())
					{
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "M��teri Grubu");
						return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
					}	
			      }
			      if(iMap.getBoolean("rdbMUSTERISEGMENT")){	
					if(musteriSegmenti == null || musteriSegmenti.isEmpty())
					{
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "M��teri Segmenti");
						return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
					}
			      }
			      if(iMap.getBoolean("rdbTEKMUSTERI")){	
					if(musteriNo == null)
					{
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "M��teri No");
						return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
					}	
			      }
				id.setSiraNo(new BigDecimal(1));
				adkBannerUserTx.setId(id);
		    	adkBannerUserTx.setGroupKey(musteriGrubu);
		    	adkBannerUserTx.setMusSegment(musteriSegmenti);
		    	adkBannerUserTx.setMusteriNo(musteriNo);
		    	adkBannerUserTx.setGDS(GDS);
		    	adkBannerUserTx.setKanalKod(kanalKod);
		    	adkBannerUserTx.setIntId(intId);
		    	adkBannerUserTx.setOid(oid);
		    	session.saveOrUpdate(adkBannerUserTx);
			   }
	 
	   if(iMap.getBoolean("rbdBIRDENFAZLAMUSTERI")){	
		   
				String tableName = "MUSTERI_DATA";
				List<?> list = (List<?>) iMap.get(tableName);
				if(list.size() == 0)
				{
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "M��teri No");
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}	 
		     for(int i=0; i<list.size();i++) {
				if(("").equals(iMap.getString(tableName,i,"UNVAN")))
				{
					iMap.put("HATA_NO", new BigDecimal(1456));
					iMap.put("P1", iMap.getBigDecimal(tableName,i,"MUSTERI_NO"));
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}	
					
			   id = new AdkBannerUserTxId();
			   id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			   id.setSiraNo(new BigDecimal(i+1));
			   adkBannerUserTx = new AdkBannerUserTx();    
			   adkBannerUserTx.setId(id);
			   adkBannerUserTx.setMusteriNo(iMap.getBigDecimal(tableName,i,"MUSTERI_NO"));
			   adkBannerUserTx.setGDS(GDS);
			   adkBannerUserTx.setKanalKod(kanalKod);
			   adkBannerUserTx.setIntId(intId);
			   adkBannerUserTx.setOid(oid);
			   session.saveOrUpdate(adkBannerUserTx);	
			     }
	       }	  
			session.flush();
			iMap.put("TRX_NAME", "4142");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
 	  }
		catch (Exception e) {
			System.out.println(e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN4142_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
	try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			int i =0;
			List<?> list = (List<?>) session.createCriteria(AdkBannerUserTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			AdkBannerUserTx adkBannerUserTx = new AdkBannerUserTx();
			if (list.size()<=1){
				adkBannerUserTx = (AdkBannerUserTx) list.get(0);
				oMap.put("TRX_NO", adkBannerUserTx.getId().getTxNo());
				oMap.put("KANAL_KOD", adkBannerUserTx.getKanalKod());
				oMap.put("MUSTERI_GRUBU", adkBannerUserTx.getGroupKey());
				oMap.put("DI_MUSTERI_GRUBU", LovHelper.diLov( adkBannerUserTx.getGroupKey(), "4142/LOV_MUSTERI_GRUBU", "ACIKLAMA")); 
				oMap.put("MUSTERI_SEGMENTI", adkBannerUserTx.getMusSegment());
				oMap.put("MUSTERI_NO", adkBannerUserTx.getMusteriNo());
				oMap.put("G_D_S", adkBannerUserTx.getGDS());
				oMap.put("INT_ID", adkBannerUserTx.getIntId());
				oMap.put("OID", adkBannerUserTx.getOid());
			}else if (list.size() > 1){
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					adkBannerUserTx = (AdkBannerUserTx) iterator.next();
            		oMap.put("MUSTERI_DATA", i,"MUSTERI_NO",adkBannerUserTx.getMusteriNo());
            		oMap.put("MUSTERI_DATA", i,"UNVAN",LovHelper.diLov(adkBannerUserTx.getMusteriNo(),"4142/LOV_MUSTERI_NO", "MUSTERI_ADI"));
            		oMap.put("TRX_NO", adkBannerUserTx.getId().getTxNo());
    				oMap.put("KANAL_KOD", adkBannerUserTx.getKanalKod());
    				oMap.put("G_D_S", adkBannerUserTx.getGDS());
    				oMap.put("INT_ID", adkBannerUserTx.getIntId());
    				oMap.put("OID", adkBannerUserTx.getOid());
    				i++;
            	}
			}
	return oMap;
	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}
 }	

	@GraymoundService("BNSPR_TRN4142_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(AdkBannerUserTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			GMMap serviceMap;
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				AdkBannerUserTx adkBannerUserTx = (AdkBannerUserTx) iterator.next();
				serviceMap = new GMMap();
				serviceMap.put("INT_ID",adkBannerUserTx.getIntId().toString());
				serviceMap.put("GROUP_KEY", adkBannerUserTx.getGroupKey());
				serviceMap.put("SEGMENT_KEY", adkBannerUserTx.getMusSegment());
				serviceMap.put("OID", adkBannerUserTx.getOid());
				if(adkBannerUserTx.getMusteriNo() != null){
				serviceMap.put("USERNAME", adkBannerUserTx.getMusteriNo().toString());
				}
				if(("").equals(adkBannerUserTx.getOid())|| adkBannerUserTx.getOid() == null){
				GMServiceExecuter.execute("ADC_MAN_BANNER_USER_CREATE",serviceMap);
				}else if(("S").equals(adkBannerUserTx.getGDS().toString())){
				GMServiceExecuter.execute("ADC_MAN_BANNER_USER_DELETE",serviceMap);
				}else{
				GMServiceExecuter.execute("ADC_MAN_BANNER_USER_UPDATE",serviceMap);
				}
			}				
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
