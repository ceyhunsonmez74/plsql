package tr.com.calikbank.bnspr.adc.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.aktifbank.bnspr.dao.GnlBlokeNedenKodTx;
import tr.com.aktifbank.bnspr.dao.GnlBlokeNedenKodTxId;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcTRN4191Services {
	
	@GraymoundService("BNSPR_TRN4191_SAVE")
    public static Map<?, ?> saveAccounts(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        String tableName = "TBL_V_ML_GNL_BLOKE_NEDEN";
      
            try{
                
                conn = DALUtil.getGMConnection();
                Session session = DAOSession.getSession("BNSPRDal");
                
                ArrayList<?> list = (ArrayList<?>) session.createCriteria(GnlBlokeNedenKodTx.class).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).list();
                for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                    GnlBlokeNedenKodTx gnlBlokeNedenKodTx = (GnlBlokeNedenKodTx) iterator.next();
                    session.delete(gnlBlokeNedenKodTx);
                }
                session.flush();
                
                int rowCount = iMap.getSize(tableName);
                for (int i = 0; i < rowCount; i++){
                   
                	GnlBlokeNedenKodTx gnlBlokeNedenKodTx = new GnlBlokeNedenKodTx();
                	GnlBlokeNedenKodTxId gnlBlokeNedenKodTxId = new GnlBlokeNedenKodTxId();
                    
                	 
                    if (!(("S").equals(iMap.getString(tableName, i, "G_D_S"))&&iMap.getString(tableName, i,"KOD")==null))
                    {
                   
                	gnlBlokeNedenKodTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                	gnlBlokeNedenKodTxId.setKod(iMap.getString(tableName, i, "KOD"));
                	gnlBlokeNedenKodTx.setId(gnlBlokeNedenKodTxId);
                	gnlBlokeNedenKodTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
                    
                	String aciklama = DALUtil.getResult("select aciklama from gnl_bloke_neden_kod_pr where kod = '"+iMap.getString(tableName, i, "KOD")+"'");
                   
                	if(("S").equals(iMap.getString(tableName,i,"G_D_S")))
                    	gnlBlokeNedenKodTx.setGDS("S");
                    else if (("G").equals(iMap.getString(tableName, i, "G_D_S")))
                    	gnlBlokeNedenKodTx.setGDS("G");
                    else if ((!(aciklama.equals(iMap.getString(tableName, i, "ACIKLAMA")))&&!((aciklama==null)||("").equals(aciklama))))
                    {
                    	gnlBlokeNedenKodTx.setGDS("D");
                    }
                    else gnlBlokeNedenKodTx.setGDS("");
                    
                  
                    session.saveOrUpdate(gnlBlokeNedenKodTx);
                }
                }
                session.flush();
                
               iMap.put("TRX_NAME","4191");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } finally{
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
    }
            @GraymoundService("BNSPR_TRN4191_IS_RECORDS_UNIQUE")
            public static GMMap isRecordsUnique(GMMap iMap) {
                
                GMMap oMap = new GMMap();
                
                String tableName = "TBL_V_ML_GNL_BLOKE_NEDEN";
                int rowCount = iMap.getSize(tableName);
                
                for (int i = 0; i < rowCount; i++){
                	 
                    if (!(("S").equals(iMap.getString(tableName, i, "G_D_S"))&&iMap.getString(tableName, i,"KOD")==null))
                    {
                 
                    for (int j = 0; j < rowCount; j++){
                     
                        if (iMap.getString(tableName , i , "KOD") == (null) || iMap.getString(tableName , i , "KOD").equals("")){
                            iMap.put("HATA_NO" , new BigDecimal(330));
                            iMap.put("P1" , "KOD");
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                        }
                        
                        if (iMap.getString(tableName , i , "ACIKLAMA") == (null) || iMap.getString(tableName , i , "ACIKLAMA").equals("")){
                            iMap.put("HATA_NO" , new BigDecimal(330));
                            iMap.put("P1" , "ACIKLAMA");
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                        }
                      
                        if (i != j){
                            if (iMap.getString(tableName , i , "KOD").equals(iMap.getString(tableName , j , "KOD"))){
                                iMap.put("HATA_NO" , new BigDecimal(932));
                                GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                            }
                        }
                    }
                }
                }
                return oMap;
            }
    

@GraymoundService("BNSPR_TRN4191_GET_BLOKE_NEDEN_LIST")
public static Map<?, ?> getYetkiList(GMMap iMap) {
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rSet = null;
    GMMap oMap = new GMMap();
    try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{? = call PKG_TRN4191.GET_BLOKE_NEDEN_LISTE}");
        int i = 1;
        
        stmt.registerOutParameter(i++, -10);
        stmt.execute();
        rSet = (ResultSet) stmt.getObject(1);
        String tableName1 = "TBL_V_ML_GNL_BLOKE_NEDEN";
        for (int row = 0; rSet.next(); row++) {
            oMap.put(tableName1, row, "KOD", rSet.getString("KOD"));
            oMap.put(tableName1, row, "ACIKLAMA", rSet.getString("ACIKLAMA"));
            oMap.put(tableName1, row, "G_D_S", rSet.getString("G_D_S"));
            oMap.put(tableName1, row, "SIL", rSet.getString("SIL"));
        }
            
        return oMap;
    }
        catch (Exception e) {
            
            throw ExceptionHandler.convertException(e);
        
        } finally {
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        
        }
    }
@GraymoundService("BNSPR_TRN4191_GET_INFO")
public static GMMap getTransactionNo(GMMap iMap) {
    
    Connection conn = null;
    
    try{
        
    GMMap oMap = new GMMap();
    conn = DALUtil.getGMConnection();
    Session session = DAOSession.getSession("BNSPRDal");
    String tableName    = "TBL_V_ML_GNL_BLOKE_NEDEN";
    String colorTableName = "TBL_COLOR";
    

    List<?> list = (List<?>) session.createCriteria(GnlBlokeNedenKodTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
        .list();
    
     for (int row = 0; row < list.size(); row++){
    	 GnlBlokeNedenKodTx gnlBlokeNedenKodTx = (GnlBlokeNedenKodTx) list.get(row);
       
        oMap.put("TRX_NO", gnlBlokeNedenKodTx.getId().getTxNo());
        oMap.put(tableName, row, "KOD", gnlBlokeNedenKodTx.getId().getKod());
        oMap.put(tableName, row, "ACIKLAMA", gnlBlokeNedenKodTx.getAciklama());
        oMap.put(tableName, row, "SIL", ("S").equals(gnlBlokeNedenKodTx.getGDS()) ? true : false);
    
      if ("G".equals(gnlBlokeNedenKodTx.getGDS()) ) {
         
          oMap.put(colorTableName, row, "KOD",getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ACIKLAMA", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.GREEN));
          
      }
      else if ("S".equals(gnlBlokeNedenKodTx.getGDS())) {
          
          
          oMap.put(colorTableName, row, "KOD",getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ACIKLAMA", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.RED));
      }
      
      else if ("D".equals(gnlBlokeNedenKodTx.getGDS())) {
          
          
          oMap.put(colorTableName, row, "KOD",getTableCellColorData(Color.BLUE));
          oMap.put(colorTableName, row, "ACIKLAMA", getTableCellColorData(Color.BLUE));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.BLUE));
      }
      else
      {
          
          oMap.put(colorTableName, row, "KOD",getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ACIKLAMA", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.WHITE));
      }
    
    }
        
    return oMap;
        
    }catch (Exception e){
        throw ExceptionHandler.convertException(e);
    }finally{
        
        GMServerDatasource.close(conn);
    }
    
}
 private static GMMap getTableCellColorData(Color backgroundColor){
        GMMap oMap = new GMMap();
        oMap.put("setBackground", backgroundColor);
        return oMap;
    }
}
