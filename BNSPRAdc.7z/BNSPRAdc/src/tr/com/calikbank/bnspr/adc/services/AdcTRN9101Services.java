package tr.com.calikbank.bnspr.adc.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.dao.WnsprSysPr;
import tr.com.calikbank.bnspr.dao.WnsprSysPrTx;
import tr.com.calikbank.bnspr.dao.WnsprSysPrTxId;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN9101Services {
	@GraymoundService("BNSPR_TRN9101_GET_PARAMETRE_TANIM")
	public static GMMap getParametreTanim(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> paremetrePersistentList = session.createCriteria(WnsprSysPr.class).list();
			int row = 0;
			String tableName = "PARAMETRE_TANIM";
			for (Iterator<?> iterator = paremetrePersistentList.iterator(); iterator.hasNext(); row++) {
				WnsprSysPr wnsprSysPr = (WnsprSysPr) iterator.next();
				oMap.put(tableName, row, "channel", wnsprSysPr.getChannel());
				oMap.put(tableName, row, "maxpinduration", wnsprSysPr.getMaxpinduration());
				oMap.put(tableName, row, "maxpinrtrycnt", wnsprSysPr.getMaxpinrtrycnt());
				oMap.put(tableName, row, "maxunusedotpcnt", wnsprSysPr.getMaxunusedotpcnt());
				oMap.put(tableName, row, "minphonechangeduration", wnsprSysPr.getMinphonechangeduration());
				oMap.put(tableName, row, "otpcontroltype", wnsprSysPr.getOtpcontroltype());
				oMap.put(tableName, row, "timeoutduration", wnsprSysPr.getTimeoutduration());
				oMap.put(tableName, row, "virtualkeyboard", wnsprSysPr.getVirtualkeyboard());
				oMap.put(tableName, row, "inactivityduration", wnsprSysPr.getInactivityduration());
				oMap.put(tableName, row, "securitypictureask", wnsprSysPr.getSecuritypictureask());
				oMap.put(tableName, row, "channel_name", LovHelper.diLov(wnsprSysPr.getChannel(), "9101/LOV_KANAL", "ACIKLAMA") );
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9101_GET_COMBO_MODEL")
	public static GMMap getComboModel(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String listName = "E_H";
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
			listName = "OPT";
			GuimlUtil.wrapMyCombo(oMap, listName, "1", "Session'da 1 tane");
			GuimlUtil.wrapMyCombo(oMap, listName, "2", "Her i�lem ");

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_TRN9101_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> paremetrePersistentList = session.createCriteria(WnsprSysPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "PARAMETRE_TANIM";
			int row = 0;
			for (Iterator<?> iterator = paremetrePersistentList.iterator(); iterator.hasNext();row++) {
				WnsprSysPrTx wnsprSysPrTx = (WnsprSysPrTx) iterator.next();
				oMap.put(tableName, row, "channel", wnsprSysPrTx.getId().getChannel());
				oMap.put(tableName, row, "maxpinduration", wnsprSysPrTx.getMaxpinduration());
				oMap.put(tableName, row, "maxpinrtrycnt", wnsprSysPrTx.getMaxpinrtrycnt());
				oMap.put(tableName, row, "maxunusedotpcnt", wnsprSysPrTx.getMaxunusedotpcnt());
				oMap.put(tableName, row, "minphonechangeduration", wnsprSysPrTx.getMinphonechangeduration());
				oMap.put(tableName, row, "otpcontroltype", wnsprSysPrTx.getOtpcontroltype());
				oMap.put(tableName, row, "timeoutduration", wnsprSysPrTx.getTimeoutduration());
				oMap.put(tableName, row, "virtualkeyboard", wnsprSysPrTx.getVirtualkeyboard());
				oMap.put(tableName, row, "inactivityduration", wnsprSysPrTx.getInactivityduration());
				oMap.put(tableName, row, "securitypictureask", wnsprSysPrTx.getSecuritypictureask());
				oMap.put(tableName, row, "channel_name", LovHelper.diLov(wnsprSysPrTx.getId().getChannel(), "9101/LOV_KANAL", "ACIKLAMA") );
			}

			oMap.put("TRX_NO", iMap.get("TRX_NO"));

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN9101_SAVE_PARAMETRE_TANIM")
	public static Map<?, ?> saveParametreTanim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "PARAMETRE_TANIM";
			List<?> paremetreGuiList = (List<?>)iMap.get(tableName);
			for (int i = 0; i < paremetreGuiList.size(); i++) {
				WnsprSysPrTx wnsprSysPrTx = (WnsprSysPrTx)session.get(WnsprSysPrTx.class, new WnsprSysPrTxId(iMap.getBigDecimal("TRX_NO"), iMap.getString(tableName, i, "channel")));
				if(wnsprSysPrTx == null){
					wnsprSysPrTx = new WnsprSysPrTx();
					WnsprSysPrTxId id = new WnsprSysPrTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setChannel(iMap.getString(tableName, i, "channel"));
					wnsprSysPrTx.setId(id);
				}
				wnsprSysPrTx.setInactivityduration(iMap.getBigDecimal(tableName, i, "inactivityduration"));
				wnsprSysPrTx.setMaxpinduration(iMap.getBigDecimal(tableName, i, "maxpinduration"));
				wnsprSysPrTx.setMaxpinrtrycnt(iMap.getBigDecimal(tableName, i, "maxpinrtrycnt"));
				wnsprSysPrTx.setMaxunusedotpcnt(iMap.getBigDecimal(tableName, i, "maxunusedotpcnt"));
				wnsprSysPrTx.setMinphonechangeduration(iMap.getBigDecimal(tableName, i, "minphonechangeduration"));
				wnsprSysPrTx.setOtpcontroltype(iMap.getString(tableName, i, "otpcontroltype"));
				wnsprSysPrTx.setTimeoutduration(iMap.getBigDecimal(tableName, i, "timeoutduration"));
				wnsprSysPrTx.setVirtualkeyboard(iMap.getString(tableName, i, "virtualkeyboard"));
				wnsprSysPrTx.setSecuritypictureask(iMap.getBigDecimal(tableName, i, "securitypictureask"));
				session.saveOrUpdate(wnsprSysPrTx);
			}
			session.flush();
			iMap.put("TRX_NAME", "9101");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
}
