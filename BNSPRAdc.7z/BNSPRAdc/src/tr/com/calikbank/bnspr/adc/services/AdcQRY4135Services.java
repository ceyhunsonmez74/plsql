package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcQRY4135Services {

	@GraymoundService("BNSPR_TRN4135_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			GuimlUtil.wrapMyCombo(oMap, "DURUM_KODU", 0, "", " ");
			GuimlUtil.wrapMyCombo(oMap, "DURUM_KODU", 1, "K", "Blokeli");
			GuimlUtil.wrapMyCombo(oMap, "DURUM_KODU", 2, "C", "��z�ld�");
			GuimlUtil.wrapMyCombo(oMap, "DURUM_KODU", 3, "ITB", "�leri Tarihli Bloke");		
			DALUtil.fillComboBox(oMap, "BLOKE_NEDEN_KOD", true, "SELECT KOD,ACIKLAMA FROM V_ML_GNL_BLOKE_NEDEN_KOD_PR ORDER BY to_number(KOD)");

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_4135_FILL_COMBOBOX_INITIAL_VALUE2")
	public static GMMap fillComboBox2InitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "BLOKE_ALT_NEDEN_KOD", true, "SELECT KOD,ACIKLAMA FROM V_ML_GNLBLOKEALTNEDENKOD_PR WHERE BLOKE_NEDEN = '"+iMap.getString("BLOKE_NEDEN_KOD")+"' ORDER BY to_number(KOD)"); 
            if (oMap.get("BLOKE_ALT_NEDEN_KOD")== null){ 
            GMServiceExecuter.call("BNSPR_TRN4131_GET_BLOKE_ACIKLAMA",iMap);
            }

         return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY4135_KANAL_BLOKE_IZMELEME")
	public static GMMap listele(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{

			//////////////////////////////////////////////////////////////////////////////////////////////
			// ADC_MAN_USER_BLOCK tablosunda olup ADK_KANAL_BLOKE tablosuna atilmamis kayitlari senkronize et
			
			if(iMap.getString("KULLANICI_KOD")!= null && !iMap.getString("KULLANICI_KOD").trim().isEmpty()){
				iMap.put("USER_CODE", AdcWinspireServices.getUserName(iMap.getString("KULLANICI_KOD"),iMap.getString("MUSTERI_NO")));
			}else{
				GMMap localMap = new GMMap().put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
				String userCode = GMServiceExecuter.call("BNSPR_CUST_GET_ADK_USERNAME", localMap).getString("USER_NAME");
				if (StringUtils.isBlank(userCode)) {
					iMap.put("HATA_NO", new BigDecimal(660));
	                iMap.put("P1", "M��terinin Kulan�c� Ad� Bulunamad�!!!");
	                return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				iMap.put("USER_CODE", userCode);
			}
			
			GMServiceExecuter.call("BNSPR_TRN4131_SYNCHRONIZE_USER_CHANNEL_BLOCKS", iMap);
			
			//////////////////////////////////////////////////////////////////////////////////////////////
			
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_4135.RC_QRY4135_Kanal_Bloke_Izleme(?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("KANAL_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("KULLANICI_KOD"));
			stmt.setString(i++, iMap.getString("BLOKE_NEDEN_KOD"));	
			stmt.setString(i++, iMap.getString("BLOKE_ALT_NEDEN_KOD"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));	
			if (!(iMap.get("BAS_TARIH") == null)) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			if (!(iMap.get("SON_TARIH") == null)) {
				stmt.setDate(i++, new Date(iMap.getDate("SON_TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			stmt.execute();
		    rSet = (ResultSet)stmt.getObject(1);
			String tableName = "KANAL_BLOKE";
            int row = 0;
            java.util.Date now = new java.util.Date();
            SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd.MM.yyyy");
            SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			while(rSet.next()){
				oMap.put(tableName, row, "KANAL_KOD", rSet.getString("KANAL_KOD"));
				//oMap.put(tableName, row, "ACIKLAMA",  LovHelper.diLov(iMap.getString("KANAL_KOD"), "4135/LOV_KANAL", "ACIKLAMA"));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
				if(rSet.getBigDecimal("KULLANICI_KOD")!= null){
				  oMap.put(tableName, row, "KULLANICI_KOD", rSet.getBigDecimal("KULLANICI_KOD"));
				}
				oMap.put(tableName, row, "KULLANICI_ACIKLAMA", LovHelper.diLov(rSet.getBigDecimal("KULLANICI_KOD"),rSet.getBigDecimal("MUSTERI_NO"), "4131/LOV_KULLANICI_2", "UNVAN"));
				oMap.put(tableName, row, "MUSTERI_ACIKLAMA", rSet.getString("UNVAN"));				
				oMap.put(tableName, row, "BLOKE_NEDEN_KOD", rSet.getString("BLOKE_NEDEN_KOD"));
				oMap.put(tableName, row, "BLOKE_ALT_NEDEN_KOD", rSet.getString("BLOKE_ALT_NEDEN_KOD"));
				if ((rSet.getString("DURUM_KODU").equals("K"))&& (rSet.getDate("BASLANGIC_TARIHI") != null)&& (rSet.getDate("BASLANGIC_TARIHI").after(now))){	
				 	oMap.put(tableName, row, "DURUM_KODU","ITB" );
				}else {
					oMap.put(tableName, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				}
				oMap.put(tableName, row, "BLOKE_ACIKLAMASI", rSet.getString("BLOKE_ACIKLAMASI"));

//				if  (rSet.getString("DURUM_KODU").equals("K")){				
//					oMap.put(tableName, row, "SON_STATU_TARIHI", rSet.getDate("bloke_koyma_sistem_tarihi")==null?null:sdf.format(rSet.getDate("bloke_koyma_sistem_tarihi")));
//				}else if (rSet.getString("DURUM_KODU").equals("C")){	
//					oMap.put(tableName, row, "SON_STATU_TARIHI", rSet.getDate("bloke_cozme_sistem_tarihi")==null?null:sdf.format(rSet.getDate("bloke_cozme_sistem_tarihi")));
//				}

                oMap.put(tableName, row, "SON_STATU_TARIHI", rSet.getDate("SON_STATU_TARIHI")==null?null:sdf.format(rSet.getTimestamp("SON_STATU_TARIHI")));

				oMap.put(tableName, row, "BASLANGIC_TARIHI", rSet.getDate("BASLANGIC_TARIHI"));
				if(rSet.getDate("BITIS_TARIHI")!= null && simpleDateFormat1.parse("24.01.2989").getTime() == 
					simpleDateFormat2.parse(rSet.getDate("BITIS_TARIHI").toString()).getTime())
				{
					oMap.put(tableName, row, "BITIS_TARIHI", "");
					oMap.put(tableName, row, "BITIS_SAAT", "");
				}
				else
				{
					oMap.put(tableName, row, "BITIS_TARIHI", rSet.getDate("BITIS_TARIHI"));
					oMap.put(tableName, row, "BITIS_SAAT", rSet.getString("BITIS_SAAT"));
				}
				oMap.put(tableName, row, "BASLANGIC_SAAT", rSet.getString("BASLANGIC_SAAT"));
				
				oMap.put(tableName, row, "BLOKE_COZME_ACIKLAMASI", rSet.getString("BLOKE_COZME_ACIKLAMASI"));
				oMap.put(tableName, row, "BLOKE_TARIHI", rSet.getDate("bloke_koyma_sistem_tarihi"));
				oMap.put(tableName, row, "BLOKE_COZME_TARIHI", rSet.getDate("bloke_cozme_sistem_tarihi"));
				oMap.put(tableName, row, "BLOKE_TARIHI_SAAT", rSet.getString("BLOKE_TARIHI_SAAT"));
				oMap.put(tableName, row, "BLOKE_COZME_TARIHI_SAAT", rSet.getString("BLOKE_COZME_TARIHI_SAAT"));
				oMap.put(tableName, row, "BLOKE_KOYAN_KULLANICI", rSet.getString("BLOKE_KOYAN_KULLANICI"));
				oMap.put(tableName, row, "BLOKE_COZEN_KULLANICI", rSet.getString("BLOKE_COZEN_KULLANICI"));
				row++;
        	}
		return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}
}