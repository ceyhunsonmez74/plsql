package tr.com.calikbank.bnspr.adc.services;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcGeneralServices {

	
	@GraymoundService("BNSPR_TFF_LINK_SEND_VALIDATION")
	public static GMMap toEmailGSMNumberValid (GMMap iMap) {
		String to=iMap.getString("TO");
		String firstParam = iMap.getString("FIRST_INPUT");
		String secondParam = iMap.getString("SECOND_INPUT");
		boolean isToValid = false;
		try {
			
			if(iMap.getString("TYPE").equals("EMAIL")){
				if(to==null)
				{to=firstParam+"@"+secondParam;}
				isToValid = isValidEmailAddress(to);
			}else if (iMap.getString("TYPE").equals("SMS")){
				if(to==null)
				{to=firstParam+""+secondParam;}
				Pattern pattern = Pattern.compile("5\\d{9}");
				Matcher matcher = pattern.matcher(to);
				isToValid = matcher.matches();
			}
			if(!isToValid)
				iMap.put("TO_VALID", "1");//to address is not valid
			else{
				iMap.put("TO_VALID", "0");//valid
				iMap.put("TO", to);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return iMap;
	}


	
	public static boolean isValidEmailAddress(String email) {
		   boolean result = true;
		   try {
		      InternetAddress emailAddr = new InternetAddress(email);
		      emailAddr.validate();
		   } catch (AddressException ex) {
		      result = false;
		   }
		   return result;
		}

    public static String getKanalKod(String integrationId) {
        Session session = DAOSession.getSession("BNSPRDal");
    	GnlKanalGrupKodPr gnlKanalGrupKodPr = (GnlKanalGrupKodPr) session
    	        .createCriteria(GnlKanalGrupKodPr.class)
    	        .add(Restrictions.eq("integrationId", integrationId))
    	        .uniqueResult();
    	
    	return gnlKanalGrupKodPr.getKod();
    }
    
	@GraymoundService("BNSPR_BLOCK_USER_CHANNEL_SMS")
	public static GMMap blockUSerChannelSms (GMMap iMap) {
		GMMap blockUserChannelSMSMap = new GMMap();
		blockUserChannelSMSMap.put("KOD", "ADC_BLOCK_USER_CHANNEL_SMS");
		blockUserChannelSMSMap.put("KEY1", iMap.getString("CHANNEL_OID"));
		blockUserChannelSMSMap.put("KEY2", iMap.getString("BLOCK_TYPE"));
		blockUserChannelSMSMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_KEY", blockUserChannelSMSMap);
		if(blockUserChannelSMSMap.getSize("RESULTS") > 0){
			GMMap phoneNumberMap = new GMMap();
			phoneNumberMap.put("CUSTOMER_ID", iMap.getString("CUSTOMER_ID"));
			phoneNumberMap = GMServiceExecuter.call("CNSPR_GET_PHONE_NUMBER", phoneNumberMap);
			for (int i = 0; i < blockUserChannelSMSMap.getSize("RESULTS"); i++) {
				GMMap smsMap = new GMMap();
				smsMap.put("CONTENT", blockUserChannelSMSMap.getString("RESULTS", i, "NAME"));
				smsMap.put("FILTER", true);
				smsMap.put("SECURE_CONTENT", true);
				smsMap.put("MUSTERI_NO", iMap.getString("CUSTOMER_ID"));
				smsMap.put("HEADER", "Aktifbank");
				smsMap.put("MSISDN", phoneNumberMap.getString("OTP_PHONE_NUMBER"));
				GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", smsMap);
			}
		}
		return iMap;	
	}
}