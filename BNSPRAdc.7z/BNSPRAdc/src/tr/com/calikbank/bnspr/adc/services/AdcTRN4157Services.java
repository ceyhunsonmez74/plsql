package tr.com.calikbank.bnspr.adc.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlYonetimPrTx;
import tr.com.calikbank.bnspr.dao.GnlYonetimPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.referencedata.GMReferenceDataFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4157Services {
	@GraymoundService("BNSPR_TRN4157_GET_PARAMETER")
	public static GMMap getParameter(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			GMMap servisMap = new GMMap();
			String kanalKodu = iMap.getString("KANAL_KOD");
			servisMap.put("CHANNEL", kanalKodu.equals("*")?"*":GMServiceExecuter.execute("BNSPR_COMMON_GET_CHANNEL_CODE", new GMMap().put("KANAL_KOD", kanalKodu)).get("CHANNEL_CODE"));
			servisMap.put("SERVICE_NAME", "ADC_CORE_REMOTE_CHANNEL_PARAMETER_LIST");
			servisMap = GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap); 
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call  PKG_RC_ADC.RC_QRY4157_PARAMETRE_YONETIM(?)}");
			
			int i = 1;	
			stmt.registerOutParameter(i++, -10); 
			stmt.setString(i++, kanalKodu);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "T_PARAMETRE";
			int row = 0;
			String kod = "";
			while (rSet.next()) {
				kod = rSet.getString("KEY1");
				oMap.put(tableName, row, "KOD", kod);
				oMap.put(tableName, row, "PARAMETRE_KOD", rSet.getString("text"));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString("EK"));
				for(i=0; i<servisMap.getSize("LIST");i++){
					if(kod.equals(servisMap.getString("LIST",i,"NAME"))){
						oMap.put(tableName, row, "DEGER", servisMap.getString("LIST",i,"VALUE"));
						break;
					}
				}
				
				row++;
			}
		    return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN4157_SAVE")
	public static GMMap saveTRN4152(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "T_PARAMETRE";
			
			List<?> list = (List<?>) iMap.get(tableName);
			for(int i=0; i<list.size();i++) {
				GnlYonetimPrTxId id = new GnlYonetimPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKod (iMap.getString(tableName,i ,"KOD"));
				id.setKanalKod (iMap.getString("KANAL_KOD"));
				GnlYonetimPrTx gnlYonetimPrTx = (GnlYonetimPrTx) session.get(GnlYonetimPrTx.class, id);
				if (gnlYonetimPrTx == null) {
					gnlYonetimPrTx = new GnlYonetimPrTx();
					gnlYonetimPrTx.setId(id);
		      }
				gnlYonetimPrTx.setId(id);
				if (iMap.getString(tableName, i, "DEGER")!= null){
				
				gnlYonetimPrTx.setDeger(iMap.getString(tableName, i, "DEGER"));
				
				session.saveOrUpdate(gnlYonetimPrTx);
				}
		}
			session.flush();

			iMap.put("TRX_NAME", "4157");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
	        catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_TRN4157_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(GnlYonetimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        String tableName = "T_PARAMETRE";
			int row = 0;
			GMMap oMap = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlYonetimPrTx gnlYonetimPrTx = (GnlYonetimPrTx) iterator.next();
				oMap.put("TRX_NO", gnlYonetimPrTx.getId().getTxNo());
				oMap.put(tableName, row, "KOD", gnlYonetimPrTx.getId().getKod());
				oMap.put(tableName, row, "PARAMETRE_KOD", LovHelper.diLov(gnlYonetimPrTx.getId().getKod(), "4152/LOV_PARAMETRE", "TEXT")); 
				oMap.put(tableName, row, "DEGER", gnlYonetimPrTx.getDeger());
				oMap.put(tableName, row, "ACIKLAMA", LovHelper.diLov(gnlYonetimPrTx.getId().getKod(), "4152/LOV_PARAMETRE", "EK")); 
				oMap.put("KANAL_KOD", gnlYonetimPrTx.getId().getKanalKod());
				oMap.put("DI_KANAL_KOD", LovHelper.diLov(gnlYonetimPrTx.getId().getKanalKod(), "4152/LOV_KANAL_GRUBU", "ACIKLAMA")); 
									
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
			
		
	@GraymoundService("BNSPR_TRN4157_AFTER_APPROVAL")
		public static GMMap AfterAproval(GMMap iMap) {
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call  PKG_RC_ADC.RC_QRY4152_get_parametre_tx(?)}");	
				int j = 1;	
				stmt.registerOutParameter(j++, -10); //ref cursor
				stmt.setBigDecimal(j++, iMap.getBigDecimal("ISLEM_NO"));
				stmt.execute();
				rSet = (ResultSet)stmt.getObject(1);
				while (rSet.next()) {
					GMMap xMap = new GMMap();
					xMap.put("CHANNEL"		, rSet.getString("Channel"));
					xMap.put("KEY"			, rSet.getString("KOD"));
					xMap.put("VALUE"		, rSet.getString("DEGER"));					
					if ("*".equals(rSet.getString("Channel"))) {
						GMServiceExecuter.executeNT("ADC_CORE_CHANNEL_PARAMETER_REMOTE_UPDATE", xMap);
						iMap.put("CHANNEL_LIST",GMReferenceDataFactory.getReferenceData("PARAMETER_REFRESH_CHANNELS"));
						for(int i=0;i<iMap.getSize("CHANNEL_LIST");i++){
							xMap.clear();
							xMap.put("CHANNEL_CODE", iMap.get("CHANNEL_LIST",i,"CODE"));
							xMap.put("SERVICE_NAME"	, "ADC_PARAMETER_REFRESH");
							try{
								GMServiceExecuter.call("ADK_CALL_SERVICE", xMap);
							}catch(GMRuntimeException e){
								if(e.getCode()!=101) throw e;
							}						
						}
					}else{
						xMap.put("SERVICE_NAME"	, "ADC_CORE_CHANNEL_PARAMETER_REMOTE_UPDATE");
						xMap.put("CHANNEL_CODE"	, rSet.getString("Channel"));
						GMServiceExecuter.call("ADK_CALL_SERVICE", xMap);
					} 				
					
				}
				return new GMMap();
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
				
			
		    }
			
	     }	
    }
	
	

