package tr.com.calikbank.bnspr.adc.services;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.AdcbiFraudintegration;
import tr.com.aktifbank.bnspr.dao.AdcbiFraudintegrationFields;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.pojo.Channel;
import tr.com.obss.adc.core.pojo.Process;
import tr.com.obss.adc.core.pojo.ProcessLog;
import tr.com.obss.adc.core.pojo.ProcessLogDetail;
import tr.com.obss.adc.core.pojo.User;
import tr.com.obss.adc.core.pojo.UserActionLog;
import tr.com.obss.adc.core.util.ADCCore;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcEventServices {

    public static final String  ADC_PROCESS_PREFIX    = "PRC";
    public static final String  EVENT_REF_NO          = "EVENT_REF_NO";
    public static final String  ACTION                = "ACTION";
    public static final String  ACTION_GROUP          = "ACTION_GROUP";
    public static final String  TRANSACTION_TIME      = "TRANSACTION_TIME";
    public static final String  RESULT                = "RESULT";
    public static final String  RESULT_DATA           = "RESULT_DATA";
    public static final String  LASTUPDATED           = "LASTUPDATED";
    public static final String  SESSION_ID            = "SESSION_ID";
    public static final String  USER_IP               = "USER_IP";

    public static final String  CC                    = "CC";

    public final static String  EVENT_DATA_TABLE_NAME = "EVENT_DATA_LIST";

    /** <b>YYYYMMDDHHmmssSSS</b> **/
    private static final String TIMESTAMP_FORMAT      = "yyyyMMddHHmmss";
    
    private static final ThreadLocal<SimpleDateFormat> timeFormat = new ThreadLocal<SimpleDateFormat>() {
        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat(TIMESTAMP_FORMAT);
        };
    };

    /** ZORUNLU ALANLAR **/
    /**
     * M��teri no (Bireysel ki�i ise kendi, kurumsal m��teri i�lemi ise kurumsal m��terinin numaras�)
     **/
    public static final String  MUSTERI_NO            = "MUSTERI_NO";
    /** ��lem numaras� (��lem ad�) **/
    public static final String  ISLEM_TIPI            = "ISLEM_TIPI";
    /**
     * �nternet ve Web Kanal� ��lemleri i�in �30� - Telefon bankac�l��� i�in �20� - IVR i�in 40
     **/
    public static final String  CHANNEL_CODE          = "CHANNEL_CODE";
    /** "��lemi e�er ki�i internet bankac�l���ndan ya da CC'den kendisi yap�yor ise  (�ster bireysel - �ster Kurumsal bir m��teri i�in yaps�n) i�lemi yapan bireysel ki�inin kulllan�c� kodu" **/
    public static final String  KULLANICI_KODU        = "KULLANICI_KODU";
    /** ��lem� (Ba�ar�l�/Ba�ar�s�z) (Hata kodlar�n� ne olarak ats�n bilemedim.) **/
    public static final String  ISLEM_SONUCU          = "ISLEM_SONUCU";
    /** i�lem zaman� **/
    private static final String ISLEM_TS              = "ISLEM_TS";

    /** OPTIONAL ALANLAR **/
    /** �p numaras� (�nternet i�leminde, bu alan� beslemeliyiz.) **/
    public static final String  IP                    = "IP";
    /** Dil Se�imi (Sadece �nternet Login'de i�leminde, bu bilgi beslenecek.) **/
    public static final String  LANG                  = "LANG";

    /**
     * CC i�lemlerinde, m��teri �a�r� merkezini bir numaradan ar�yor sonu�ta.Bu numaray� CC i�lemleri i�in koyabiliyor isek, ekleyelim. cagr� merkezi
     * i�in, ivr daki durumuna bakal�m
     **/
    public static final String  TEL                   = "TEL";
    /** i�lem hatal� ise ��lem Hata Nedeni **/
    public static final String  FAIL_REASON           = "FAIL_REASON";
    /** g�ncelleme i�lemlerinde zorunlu. Hangi alan� g�ncelliyor bilgisi **/
    public static final String  UPDATE_FIELD_NAME     = "UPDATE_FIELD_NAME";
    /** bu 3 alan sadece hesap k�s�tlamada. K�s�tlanan hesap no **/
    public static final String  KISIT_HESAP_NO        = "KISIT_HESAP_NO";
    /** G�ncelleme i�lemlerinde yolluycaks�n. �ifre yi kesin yollam�yosun **/
    public static final String  UPDATE_OLD_VALUE      = "UPDATE_OLD_VALUE";
    /** G�ncelleme i�lemlerinde yolluycaks�n. �ifre yi kesin yollam�yosun **/
    public static final String  UPDATE_NEW_VALUE      = "UPDATE_NEW_VALUE";
    private static final String LIMIT_UPDATE_VAL      = "LIMIT_UPDATE_VAL";

    /** OPTIONAL ALANLAR END **/

    @GraymoundService("BNSPR_ADC_FRAUD_COLLECT_DATA")
    public static GMMap collectData(GMMap iMap) {
        GMMap required = GMServiceExecuter.call("BNSPR_ADC_FRAUD_COLLECT_REQUIRED_DATA", iMap);

        // GMMap optional =
        // GMServiceExecuter.call("BNSPR_ADC_FRAUD_COLLECT_OPTIONAL_DATA",
        // iMap);

        GMMap oMap = new GMMap();
        oMap.putAll(required);
        // oMap.putAll(optional);

        return oMap;
    }

    @GraymoundService("BNSPR_ADC_FRAUD_COLLECT_REQUIRED_DATA")
    public static GMMap collectRequiredData(GMMap iMap) {

        String refNo = iMap.getString(EVENT_REF_NO);

        if (refNo.startsWith(ADC_PROCESS_PREFIX)) {
            GMMap processLogDetails = GMServiceExecuter.call("BNSPR_ADC_FRAUD_COLLECT_PROCESS_LOG_DETAILS", iMap);

            return processLogDetails;
        } else {
            GMMap userLogDetails = new GMMap();
            GMMap logMap = GMServiceExecuter.call("BNSPR_ADC_FRAUD_COLLECT_USER_LOG", iMap);
            userLogDetails.put(EVENT_DATA_TABLE_NAME, 0, logMap);

            return userLogDetails;
        }

    }

    @GraymoundService("BNSPR_ADC_FRAUD_COLLECT_OPTIONAL_DATA")
    public static GMMap collectOptionalData(GMMap iMap) {
        String refNo = iMap.getString(EVENT_REF_NO);

        if (StringUtil.isEmpty(refNo))
            return null;

        if (refNo.startsWith(ADC_PROCESS_PREFIX)) {
            GMMap processLogDetails = GMServiceExecuter.call("BNSPR_ADC_FRAUD_COLLECT_PROCESS_LOG_DETAILS", iMap);
            return processLogDetails;
        } else {
            GMMap userLogDetails = GMServiceExecuter.call("BNSPR_ADC_FRAUD_COLLECT_USER_LOG", iMap);
            return userLogDetails;
        }
    }

    @GraymoundService("BNSPR_ADC_FRAUD_COLLECT_PROCESS_LOG_DETAILS")
    public static GMMap getAprocessLogDetail(GMMap iMap) {

        String refNo = iMap.getString(EVENT_REF_NO);
        refNo = refNo.substring(ADC_PROCESS_PREFIX.length());

        Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

        ProcessLog pl = (ProcessLog) session.createCriteria(ProcessLog.class).add(Restrictions.eq("oid", refNo)).uniqueResult();
        User user = (User) session.createCriteria(User.class).add(Restrictions.eq("oid", pl.getUserOid())).uniqueResult(); // user can be null. ie (
                                                                                                                           // user.oid can be
                                                                                                                           // INTERNET,CARD etc.)
        User parentUser = null;
        if (!StringUtil.isEmpty(pl.getParentUserOid())) {
            parentUser = (User) session.get(User.class, pl.getParentUserOid()); // same as above. just in case tho. no recent bug
        }
        Channel ch = (Channel) session.load(Channel.class, pl.getChannelOid());
        Process pr = (Process) session.load(tr.com.obss.adc.core.pojo.Process.class, pl.getProcessOid());
        List<?> logDetailList = session.createCriteria(ProcessLogDetail.class).add(Restrictions.eq("processLogOid", refNo)).list();

        GMMap processLogDetailMap = new GMMap();
        for (int i = 0; i < logDetailList.size(); i++) {
            ProcessLogDetail processLogDetail = (ProcessLogDetail) logDetailList.get(i);
            processLogDetailMap.put(processLogDetail.getKey(), processLogDetail.getValue());
        }

        GMMap reqMap = new GMMap();

        reqMap.putAll(getJointFields(user, parentUser, ch, pl, pr, iMap, processLogDetailMap));
        reqMap.put(EVENT_REF_NO, iMap.getString(EVENT_REF_NO));

        iMap.put(LANG, ADCSession.getLanguage());

        if (pl.getStatus().trim().equals("0")) {
            iMap.put(FAIL_REASON, pl.getStatusMessage());
        }

        GMMap generalOptionalMap = fillOptionalFields(iMap);

        GMMap processMap = new GMMap();

        if (pr.getCode().equals("CODE_CHNG")) {
            processMap = getUserCodeChangeDetails(processLogDetailMap);
        } else if (pr.getCode().equals("PASS_CHNG")) {
            processMap = getPassChngDetails(processLogDetailMap);
        } else if (pr.getCode().equals("IP_RSTRCTC") || pr.getCode().equals("IP_RSTRCT")) {
            processMap = getIpRestrictionDetails(processLogDetailMap);
        } else if (pr.getCode().equals("PRCS_LIMIT")) {
            processMap = getProcessLimitDetails(processLogDetailMap);
        } else if (pr.getCode().equals("PRCS_RSTRC")) {
            processMap = getProcessRestrictionDetails(processLogDetailMap);
        } else if (pr.getCode().equals("ACC_RSTRCT") || "CCACCRSTRC".equals(pr.getCode())) {
            processMap = getAccountRestriction(processLogDetailMap);
        } else if (pr.getCode().equals("CARD_PWCHG")) {
            processMap = getPassChngDetails(processLogDetailMap);
        } else if (CCEventConfiguration.isCCEvent(pr.getCode())) {
            getCCEventDetails(pr.getCode(), processLogDetailMap, reqMap);
        }

        GMMap oMap = new GMMap();

        int i = 0;
        do {
            GMMap tmp = new GMMap();
            tmp.putAll(reqMap);
            tmp.putAll(generalOptionalMap);

            oMap.put(EVENT_DATA_TABLE_NAME, i, tmp);
            i++;
        } while (i < processMap.getSize(EVENT_DATA_TABLE_NAME));

        for (int j = 0; j < processMap.getSize(EVENT_DATA_TABLE_NAME); j++) {
            oMap.getMap(EVENT_DATA_TABLE_NAME, j).putAll(processMap.getMap(EVENT_DATA_TABLE_NAME, j));
        }

        return oMap;

    }

    private static GMMap getAccountRestriction(GMMap processLogDetailMap) {
        GMMap iMap = new GMMap();
        GMMap oMap = new GMMap();

        String hList = processLogDetailMap.getString("HESAP_LISTESI");

        String[] hesapList = hList.split(",");

        for (int i = 0; i < hesapList.length; i++) {
            iMap.put(UPDATE_FIELD_NAME, "HESAP_LISTESI");
            iMap.put(KISIT_HESAP_NO, hesapList[i]);

            oMap.put(EVENT_DATA_TABLE_NAME, i, fillOptionalFields(iMap));
        }

        return oMap;
    }

    private static GMMap getProcessRestrictionDetails(GMMap processLogDetailMap) {

        String bannedMenuList = processLogDetailMap.getString("BANNED_MENU_LIST");

        // get rid of [
        if (bannedMenuList.startsWith("[")) {
            bannedMenuList = bannedMenuList.substring(1);
        }
        // get rid of ]
        if (bannedMenuList.endsWith("]")) {
            bannedMenuList = bannedMenuList.substring(0, bannedMenuList.length() - 1);
        }

        String[] bannedMenuAr = bannedMenuList.split(",");
        GMMap iMap = new GMMap();
        GMMap oMap = new GMMap();

        for (int i = 0; i < bannedMenuAr.length; i++) {
            iMap.put(UPDATE_FIELD_NAME, "BANNED_MENU_LIST");
            iMap.put(UPDATE_NEW_VALUE, bannedMenuAr[i]);

            oMap.put(EVENT_DATA_TABLE_NAME, i, fillOptionalFields(iMap));
        }

        return oMap;

    }

    private static GMMap getProcessLimitDetails(GMMap processLogDetailMap) {
        GMMap iMap = new GMMap();
        GMMap oMap = new GMMap();

        iMap.put(UPDATE_FIELD_NAME, "EFT_USER_MAX_DAY");
        iMap.put(LIMIT_UPDATE_VAL, processLogDetailMap.getString("EFT_USER_MAX_DAY"));
        oMap.put(EVENT_DATA_TABLE_NAME, 0, fillOptionalFields(iMap));

        iMap.put(UPDATE_FIELD_NAME, "TRN_USER_MAX_DAY");
        iMap.put(LIMIT_UPDATE_VAL, processLogDetailMap.getString("TRN_USER_MAX_DAY"));
        oMap.put(EVENT_DATA_TABLE_NAME, 1, fillOptionalFields(iMap));

        iMap.put(UPDATE_FIELD_NAME, "EXC_BUY_USER_MAX_DAY");
        iMap.put(LIMIT_UPDATE_VAL, processLogDetailMap.getString("EXC_BUY_USER_MAX_DAY"));
        oMap.put(EVENT_DATA_TABLE_NAME, 2, fillOptionalFields(iMap));

        iMap.put(UPDATE_FIELD_NAME, "EXC_SELL_USER_MAX_DAY");
        iMap.put(LIMIT_UPDATE_VAL, processLogDetailMap.getString("EXC_SELL_USER_MAX_DAY"));
        oMap.put(EVENT_DATA_TABLE_NAME, 3, fillOptionalFields(iMap));

        iMap.put(UPDATE_FIELD_NAME, "EXC_ARB_USER_MAX_DAY");
        iMap.put(LIMIT_UPDATE_VAL, processLogDetailMap.getString("EXC_ARB_USER_MAX_DAY"));
        oMap.put(EVENT_DATA_TABLE_NAME, 4, fillOptionalFields(iMap));

        iMap.put(UPDATE_FIELD_NAME, "CARD_TRN_USER_MAX_DAY");
        iMap.put(LIMIT_UPDATE_VAL, processLogDetailMap.getString("CARD_TRN_USER_MAX_DAY"));
        oMap.put(EVENT_DATA_TABLE_NAME, 5, fillOptionalFields(iMap));

        return oMap;
    }

    private static GMMap getIpRestrictionDetails(GMMap processLogDetailMap) {
        GMMap iMap = new GMMap();
        iMap.put(UPDATE_FIELD_NAME, "IP_LIST");
        iMap.put(UPDATE_OLD_VALUE, processLogDetailMap.getString(""));
        iMap.put(UPDATE_NEW_VALUE, processLogDetailMap.getString("IP_LIST"));
        GMMap oMap = new GMMap();
        oMap.put(EVENT_DATA_TABLE_NAME, 0, fillOptionalFields(iMap));

        return oMap;
    }

    private static GMMap getPassChngDetails(GMMap processLogDetailMap) {
        GMMap iMap = new GMMap();
        iMap.put(UPDATE_FIELD_NAME, "PASSWORD");
        iMap.put(UPDATE_OLD_VALUE, processLogDetailMap.getString(""));
        iMap.put(UPDATE_NEW_VALUE, processLogDetailMap.getString(""));
        GMMap oMap = new GMMap();
        oMap.put(EVENT_DATA_TABLE_NAME, 0, fillOptionalFields(iMap));

        return oMap;
    }

    private static GMMap getCCEventDetails(String processCode, GMMap processLogDetailMap, GMMap eventRequestMap) {
        GMMap iMap = new GMMap();
        iMap.put(UPDATE_FIELD_NAME, CCEventConfiguration.getUpdateFieldName(processCode));
        iMap.put(UPDATE_OLD_VALUE, processLogDetailMap.get(CCEventConfiguration.getProcessLogOldValueKey(processCode)));
        iMap.put(UPDATE_NEW_VALUE, processLogDetailMap.get(CCEventConfiguration.getProcessLogNewValueKey(processCode)));
        GMMap oMap = new GMMap();
        oMap.put(EVENT_DATA_TABLE_NAME, 0, fillOptionalFields(iMap));

        // Process exception ile cikmamis, status basarili gozukse bile,
        // result field ile hata mesaji gonderilmis olabiliyor,
        String processStatus = eventRequestMap.getString("ISLEM_SONUCU");
        boolean isProcessFail = "0".equals(processStatus);

        String result = processLogDetailMap.getString(CCEventConfiguration.getProcessLogSuccessKey(processCode));
        boolean isProcessDetailSuccess = result == null || // failure aninda zaten dolu olmali
                                         ("1".equals(result) || "2".equals(result))
                                         || // degeri 1 veya 2 ise (RESPONSE alani genelde)
                                         ("OK".equalsIgnoreCase(result))
                                         || // OK / FAIL olabiliyor
                                         ("SUCCESS".equalsIgnoreCase(result))
                                         || (processLogDetailMap.getBoolean(CCEventConfiguration.getProcessLogSuccessKey(processCode))) // true set
                                                                                                                                        // edilmis
                                                                                                                                        // olabilir
        ;

        if (!isProcessFail && !isProcessDetailSuccess) {
            eventRequestMap.put(ISLEM_SONUCU, "0");
            eventRequestMap.put(FAIL_REASON, CCEventConfiguration.getProcessLogFailReasonKey(processCode));
        }

        return oMap;
    }

    private static GMMap getUserCodeChangeDetails(GMMap processLogDetailMap) {
        GMMap iMap = new GMMap();
        iMap.put(UPDATE_FIELD_NAME, "USERCODE");
        iMap.put(UPDATE_OLD_VALUE, processLogDetailMap.getString("USERCODE"));
        iMap.put(UPDATE_NEW_VALUE, processLogDetailMap.getString("SUCCEED_NEW_USERCODE"));

        GMMap oMap = new GMMap();
        oMap.put(EVENT_DATA_TABLE_NAME, 0, fillOptionalFields(iMap));

        return oMap;
    }

    private static GMMap getJointFields(User user, User parentUser, Channel ch, ProcessLog pl, tr.com.obss.adc.core.pojo.Process pr, GMMap iMap, GMMap processLogDetailMap) {
        GMMap reqMap = new GMMap();

        if (iMap != null) {
            reqMap.putAll(iMap);
        }

        reqMap.put("CALL_ID_GLOBAL", "");
        if (processLogDetailMap.containsKey("CALL_ID_GLOBAL")) {
            reqMap.put("CALL_ID_GLOBAL", processLogDetailMap.getString("CALL_ID_GLOBAL"));
        }

        // agent'a baglanip islem yapan musteri user bilgisi parentuser
        if (CC.equals(ch.getCode()) && parentUser != null) {
            reqMap.put(MUSTERI_NO, parentUser.getCustomerId());
            reqMap.put(KULLANICI_KODU, user == null || user.getUsername() == null ? pl.getUserOid() : user.getUsername());
        } else {
            reqMap.put(MUSTERI_NO, user == null || user.getCustomerId() == null ? "0" : user.getCustomerId());
            reqMap.put(KULLANICI_KODU, user == null || user.getUserCustomerId() == null ? pl.getUserOid() : user.getUserCustomerId());
        }

        if (CC.equals(ch.getCode()) && (reqMap.getString(MUSTERI_NO) == null || reqMap.getString(MUSTERI_NO).trim().length() == 0)) {
            reqMap.put(MUSTERI_NO, "0");
        }

        reqMap.put(ISLEM_SONUCU, pl.getStatus());
        reqMap.put(ISLEM_TS, timeFormat.get().format(pl.getLastupdated()));
        reqMap.put(ISLEM_TIPI, pr.getCode());
        reqMap.put(CHANNEL_CODE, AdcGeneralServices.getKanalKod(ch.getCode()));

        GMMap oMap = fillRequiredFields(reqMap);

        return oMap;
    }

    public static GMMap fillRequiredFields(GMMap iMap) {
        GMMap oMap = new GMMap();

        oMap.put("CM_CUST_NUM", iMap.getString(MUSTERI_NO));
        oMap.put("TRX_TRAN_CDE2", iMap.getString(ISLEM_TIPI));
        oMap.put("TRX_CHANNEL_CDE", iMap.getString(CHANNEL_CODE));
        oMap.put("TRX_USER_CDE", iMap.getString(KULLANICI_KODU));
        oMap.put("TRX_STAT", iMap.getString(ISLEM_SONUCU));

        if (iMap.containsKey("CALL_ID_GLOBAL")) {
            oMap.put("TRX_TEL2", iMap.getString("CALL_ID_GLOBAL"));
        }

        // ��lem tarihi YYYYMMDDHH24MISSsss format�nda - logdaki zaman
        oMap.put("TRX_TRAN_DATE", iMap.getString(ISLEM_TS));

        // ��lem s�ra numaras�,� fi� numaras�. ��lemin uniqueli�ini sa�layacak
        // referans numaras�
        String refNo = iMap.getString(EVENT_REF_NO);
        if (refNo.startsWith(ADC_PROCESS_PREFIX)) {
            refNo = refNo.substring(ADC_PROCESS_PREFIX.length());
        }

        oMap.put("TRX_SEQ_NUM", refNo);

        // Sistem tarihi�� YYYYMMDDHH24MISS
        oMap.put("TRX_SYSTEM_DATE", timeFormat.get().format(new Date()));

        // //////////////////////
        oMap.put("TRX_MSG_TYPE", "700");
        oMap.put("TRX_DEB_CRE_IND", "N");
        oMap.put("TRX_RESP_CDE", "000");
        oMap.put("TRX_TRAN_CDE", "89");
        oMap.put("TRX_TRAN_TYP", "01");
        oMap.put("ORGANIZATION_CODE", "C");
        oMap.put("CM_CUST_MERCHNT_IND", "C");
        oMap.put("RECORD_TYPE", "500");
        oMap.put("CORPORATION_CODE", "0143");

        return oMap;
    }

    public static GMMap fillOptionalFields(GMMap iMap) {
        GMMap oMap = new GMMap();

        if (iMap.get(IP) != null && iMap.getString(IP).length() > 0) {
            oMap.put("TRX_TRAN_IP", iMap.getString(IP));
        }

        if (iMap.get(LANG) != null && iMap.getString(LANG).length() > 0) {
            oMap.put("TRX_LANG_ID", iMap.getString(LANG));
        }

        if (iMap.get(TEL) != null && iMap.getString(TEL).length() > 0) {
            oMap.put("TRX_TEL1", iMap.getString(TEL));
        }

        if (iMap.get(FAIL_REASON) != null && iMap.getString(FAIL_REASON).length() > 0) {
            oMap.put("TRX_FAIL_REASON", iMap.getString(FAIL_REASON));
        }

        if (iMap.get(UPDATE_FIELD_NAME) != null && iMap.getString(UPDATE_FIELD_NAME).length() > 0) {
            oMap.put("TRX_FIELD_NAME", iMap.getString(UPDATE_FIELD_NAME));
        }

        if (iMap.get(KISIT_HESAP_NO) != null && iMap.getString(KISIT_HESAP_NO).length() > 0) {
            oMap.put("TRX_ACCT_NUM", iMap.getString(KISIT_HESAP_NO));
            oMap.put("PR_ACCT_NUM", iMap.getString(KISIT_HESAP_NO));
            oMap.put("PR_PROD_NUM", iMap.getString(KISIT_HESAP_NO));
        }

        if (iMap.get(LIMIT_UPDATE_VAL) != null && iMap.getString(LIMIT_UPDATE_VAL).length() > 0) {
            oMap.put("TRX_AMT3", iMap.get(LIMIT_UPDATE_VAL));
        }

        if (iMap.get(UPDATE_OLD_VALUE) != null && iMap.getString(UPDATE_OLD_VALUE).length() > 0) {
            oMap.put("TRX_OLD_VALUE", iMap.getString(UPDATE_OLD_VALUE));
        }

        if (iMap.get(UPDATE_NEW_VALUE) != null && iMap.getString(UPDATE_NEW_VALUE).length() > 0) {
            oMap.put("TRX_NEW_VALUE", iMap.getString(UPDATE_NEW_VALUE));
        }

        return oMap;

    }

    @GraymoundService("BNSPR_ADC_FRAUD_COLLECT_USER_LOG")
    public static GMMap getUserLog(GMMap iMap) {
        String refNo = iMap.getString(EVENT_REF_NO);

        Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

        UserActionLog ual = (UserActionLog) session.load(UserActionLog.class, refNo);

        User user = (User) session.load(User.class, ual.getUserOid());
        Channel ch = (Channel) session.load(Channel.class, ual.getChannelOid());
        GMMap reqMap = new GMMap();

        reqMap.put(MUSTERI_NO, user.getCustomerId());
        reqMap.put(KULLANICI_KODU, user.getUserCustomerId());
        reqMap.put(ISLEM_SONUCU, ual.getResult());
        reqMap.put(ISLEM_TS, timeFormat.get().format(ual.getLastupdated()));
        reqMap.put(ISLEM_TIPI, ual.getActionGroup() + "_" + ual.getAction());
        reqMap.put(EVENT_REF_NO, iMap.getString(EVENT_REF_NO));
        reqMap.put(CHANNEL_CODE, AdcGeneralServices.getKanalKod(ch.getCode()));

        GMMap fraudMap = new GMMap();

        fraudMap.putAll(fillRequiredFields(reqMap));

        iMap.put(IP, ual.getUserIP());

        iMap.put(LANG, ADCSession.getLanguage());

        if (ual.getResult().trim().equals("0")) {
            iMap.put(FAIL_REASON, ual.getResultData());
        }

        // if it is an update operation
        // i.e. expiredPasswordChange
        if (ual.getActionGroup().equals("SECURITY_UPDATE")) {
            iMap.put(UPDATE_FIELD_NAME, ual.getAction());
            iMap.put(UPDATE_OLD_VALUE, "");
            iMap.put(UPDATE_NEW_VALUE, "");
        }

        fraudMap.putAll(fillOptionalFields(iMap));
        GMMap oMap = new GMMap();

        oMap.put(EVENT_DATA_TABLE_NAME, 0, fraudMap);

        return fraudMap;
    }
    
    @GraymoundService("BNSPR_ADC_BI_FRAUD_COLLECT_DATA")
    public static GMMap collectAdcBiFraudData(GMMap iMap) {
        GMMap oMap = new GMMap();

        AdcbiFraudintegration integration = findIntegration(iMap.getString("PROCESS_CODE"));
        GMMap fraudMap = prepareCommonFraudMap(integration, iMap);
        
        int index = 0;
        int size = iMap.getSize("FIELD_TABLE");
        
        for (int i = 0; i < size; i++) {
            String fieldName = iMap.getString("FIELD_TABLE", i, "FIELD_NAME");
            String value = iMap.getString("FIELD_TABLE", i, "VALUE");
            String newValue = iMap.getString("FIELD_TABLE", i, "NEW_VALUE");
            
            for(AdcbiFraudintegrationFields fields : integration.getFields()) {
                if (fields.getUpdateFieldName().equals(fieldName)) {
                    GMMap fieldMap = new GMMap();
                    
                    if (!StringUtil.isEmpty(fields.getValueField())) {
                        fieldMap.put(fields.getValueField(), value);
                    }
                    
                    if (!StringUtil.isEmpty(fields.getNewValueField())) {
                        fieldMap.put(fields.getNewValueField(), newValue);
                    }
                    
                    fieldMap.putAll(fraudMap);
                    putTrxNo(fieldMap);
                    
                    oMap.put(EVENT_DATA_TABLE_NAME, index++, fieldMap);
                }
            }
        }

        if (oMap.getSize(EVENT_DATA_TABLE_NAME) == 0) {
            putTrxNo(fraudMap);
            oMap.put(EVENT_DATA_TABLE_NAME, index, fraudMap);
        }
        
        return oMap;
    }

    private static GMMap prepareCommonFraudMap(AdcbiFraudintegration integration, GMMap iMap) {
        GMMap fraudMap = new GMMap();
        
        String failReason = integration.getDefaultResultData();
        if (StringUtil.isEmpty(failReason)) {
            failReason = iMap.getString("RESULT_DATA");
        }
        
        String time = timeFormat.get().format(Calendar.getInstance().getTime());
        
        fraudMap.put("CM_CUST_NUM"      , iMap.get("CUSTOMER_NO"));
        fraudMap.put("TRX_TRAN_CDE2"    , integration.getProcessType());
        fraudMap.put("TRX_CHANNEL_CDE"  , AdcGeneralServices.getKanalKod(iMap.getString("CHANNEL_CODE")));
        fraudMap.put("TRX_USER_CDE"     , iMap.get("USER_CODE"));
        fraudMap.put("TRX_STAT"         , iMap.get("RESULT"));
        fraudMap.put("TRX_FAIL_REASON"  , failReason);
        fraudMap.put("TRX_LANG_ID"      , ADCSession.getLanguage());
        fraudMap.put("TRX_TRAN_IP"      , iMap.get(IP));
        fraudMap.put("TRX_TEL2"         , iMap.getString("CALL_ID_GLOBAL"));
        fraudMap.put("TRX_TRAN_DATE"    , time);
        fraudMap.put("TRX_SYSTEM_DATE"  , time);
        fraudMap.put("TRX_MSG_TYPE"     , "700");
        fraudMap.put("TRX_DEB_CRE_IND"  , "N");
        fraudMap.put("TRX_RESP_CDE"     , "000");
        fraudMap.put("TRX_TRAN_CDE"     , "89");
        fraudMap.put("TRX_TRAN_TYP"     , "01");
        fraudMap.put("ORGANIZATION_CODE", "C");
        fraudMap.put("CM_CUST_MERCHNT_IND", "C");
        fraudMap.put("RECORD_TYPE"      , "500");
        fraudMap.put("CORPORATION_CODE" , "0143");

        return fraudMap;
    }

    private static void putTrxNo(GMMap fraudMap) {
        fraudMap.put("TRX_SEQ_NUM"      , UUID.randomUUID().toString());
    }
    
    private static AdcbiFraudintegration findIntegration(String processCode) {
        Session session = DAOSession.getSession("BNSPRDal");
        
        AdcbiFraudintegration integration = (AdcbiFraudintegration) session.createCriteria(AdcbiFraudintegration.class)
                .add(Restrictions.eq("processCode", processCode))
                .uniqueResult();

        if (integration == null) {
            throw ExceptionHandler.convertException(new GMRuntimeException(0, "Integration not found"));
        }
        
        return integration;
    }

    @GraymoundService("BNSPR_ADC_CREATE_EVENT")
    public static GMMap createEvent(GMMap iMap) {
        try {

            boolean isProcess = iMap.getBoolean("IS_PROCESS");
            String logNo = iMap.getString("LOG_ID");

            if (isProcess) {
                iMap.put("EVENT_REF_NO", ADC_PROCESS_PREFIX + logNo);
            } else {
                iMap.put("EVENT_REF_NO", logNo);
            }

            iMap.put("EVENT_TYPE_NO", "5");
            iMap.put("INTEGRATION_TYPE", "S"); // call immediately

            GMMap oMap = GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
            oMap.put("RESPONSE", "2");
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_ADC_CREATE_EVENT_ASYNC")
    public static GMMap createEventAsync(GMMap iMap) {
        GMServiceExecuter.executeAsync("BNSPR_ADC_CREATE_EVENT", iMap);
        
        return iMap;
    }

    @GraymoundService(value = "BNSPR_ADC_GET_LAST_RECORD_FROM_USER_ACTION_LOG")
    public static GMMap getLastRecordFromUserActionLog(GMMap iMap) {

        Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

        Map<String, String> rest = new HashMap<String, String>();
        rest.put("userOid", iMap.getString("USER_OID"));
        rest.put("channelOid", iMap.getString("CHANNEL_OID"));
        rest.put("actionGroup", iMap.getString("ACTION_GROUP"));
        rest.put("action", iMap.getString("ACTION"));

        List<?> list = (List<?>) session.createCriteria(UserActionLog.class).add(Restrictions.allEq(rest)).addOrder(Order.desc("lastupdated")).setMaxResults(2).list();

        GMMap oMap = new GMMap();
        if (list != null && list.size() > 1 && list.get(1) != null) {
            UserActionLog userActionLog = (UserActionLog) list.get(1);
            oMap.put(LASTUPDATED, String.valueOf(userActionLog.getLastupdated()).substring(0,19));
            oMap.put(RESULT, userActionLog.getResult());
            oMap.put(RESULT_DATA, userActionLog.getResultData());

        }
        return oMap;
    }
    
    @GraymoundService(value = "BNSPR_ADC_GET_LAST_FAIL_TIME_FROM_USER_ACTION_LOG")
    public static GMMap getLastFailTimeFromUserActionLog(GMMap iMap) {
        Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

        Map<String, String> rest = new HashMap<String, String>();
        rest.put("userOid", iMap.getString("USER_OID"));
        rest.put("channelOid", iMap.getString("CHANNEL_OID"));
        rest.put("result", "0");
        List<?> list = (List<?>) session.createCriteria(UserActionLog.class).add(Restrictions.allEq(rest)).addOrder(Order.desc("lastupdated")).setMaxResults(1).list();
        GMMap oMap = new GMMap();
        if (list != null && list.size() > 0 && list.get(0) != null) {
            UserActionLog userActionLog = (UserActionLog) list.get(0);
            oMap.put(LASTUPDATED, String.valueOf(userActionLog.getLastupdated()).substring(0,19));
        }
        return oMap;
    }

}
