package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkKanalBloke;
import tr.com.calikbank.bnspr.dao.AdkKanalBlokeTmp;
import tr.com.calikbank.bnspr.dao.AdkKanalBlokeTmpId;
import tr.com.calikbank.bnspr.dao.AdkKanalBlokeTx;
import tr.com.calikbank.bnspr.dao.AdkKanalBlokeTxId;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

@SuppressWarnings("deprecation")
public class AdcTRN4131Services {

	@GraymoundService("BNSPR_TRN4131_GET_KANAL_LIST")
	public static GMMap GetKanalList(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_ADC.RC_QRY4131_Kanal_List }");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.execute();
			String tableName = "KANAL_LIST";
			rSet = (ResultSet)stmt.getObject(1);
			/*	oMap = DALUtil.rSetResults(rSet, tableName);*/
			int row = 0;
			while (rSet.next()){
				oMap.put(tableName, row,"KANAL_KOD",rSet.getString("KOD"));
				oMap.put(tableName, row, "KANAL", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, row, "SEC", false);
				row ++;
			}
			return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}			

	@GraymoundService("BNSPR_4131_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBox1InitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			if (iMap.getString("ACTION").equals("BLOKE_KOY")){
				DALUtil.fillComboBox(oMap, "BLOKE_NEDENI", true, "SELECT KOD,ACIKLAMA FROM V_ML_GNL_BLOKE_NEDEN_KOD_PR WHERE pkg_trn4131.NedenKodDoldurma(KOD,('"+prepareKanalKod(iMap)+"')) = 'E' ORDER BY to_number(KOD)");
			}else{
				DALUtil.fillComboBox(oMap, "BLOKE_NEDENI", true, "SELECT KOD,ACIKLAMA FROM V_ML_GNL_BLOKE_NEDEN_KOD_PR ORDER BY to_number(KOD)");
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static String prepareKanalKod(GMMap iMap){
		StringBuilder kanalKod = new StringBuilder();
		kanalKod.append("-1");
		String tableName = "KANAL_LIST";
		List<?> list = (List<?>)iMap.get(tableName);
		for (int i=0; i<list.size();i++) {
			if(iMap.getBoolean(tableName,i,"SEC")){
				kanalKod.append(",");
				kanalKod.append(iMap.get(tableName, i, "KANAL_KOD"));
			}
		}
		return kanalKod.toString();
	}

	@GraymoundService("BNSPR_4131_FILL_COMBOBOX_INITIAL_VALUE2")
	public static GMMap fillComboBox2InitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "BLOKE_ALT_NEDENI", true, "SELECT KOD,ACIKLAMA FROM V_ML_GNLBLOKEALTNEDENKOD_PR WHERE BLOKE_NEDEN = '"+iMap.getString("BLOKE_NEDENI")+"' ORDER BY KOD"); 
			if (oMap.get("BLOKE_ALT_NEDENI")== null){ 
				GMServiceExecuter.call("BNSPR_TRN4131_GET_BLOKE_ACIKLAMA",iMap);
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

    @GraymoundService("BNSPR_TRN4131_SAVE_BLOKE_KOYMA")
	public static GMMap saveTRN4131(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "KANAL_LIST";
			String kanalKodu = null;
			List<?> list = (List<?>) iMap.get(tableName);

			boolean error = true;
			for (int i = 0; i < list.size(); i++) {
				if (iMap.getBoolean(tableName, i, "SEC"))
					error = false;
			}

			if (error) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kanal Kodu");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			List<?> adkKanalBlokeList = (List<?>) session.createCriteria(
					AdkKanalBlokeTx.class).add(
							Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
							.list();
			for (Iterator<?> iterator = adkKanalBlokeList.iterator(); iterator.hasNext();) {
				session.delete((AdkKanalBlokeTx) iterator.next());
			}
			session.flush();

			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date dt;
			String saat;
			for (int i = 0; i < list.size(); i++) {
				if (iMap.getBoolean(tableName, i, "SEC")) {
					kanalKodu = iMap.getString(tableName, i, "KANAL_KOD");
					AdkKanalBlokeTx adkKanalBlokeTx = new AdkKanalBlokeTx();
					AdkKanalBlokeTxId id = new AdkKanalBlokeTxId();
					GMMap aMap = new GMMap();
					aMap.put("TABLE_NAME", "KANAL_BLOKE");
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setKanalKod(kanalKodu);
					adkKanalBlokeTx.setId(id);
					adkKanalBlokeTx.setBlokeNedenKod(iMap.getString("BLOKE_NEDENI"));
					adkKanalBlokeTx.setBlokeAltNedenKod(iMap.getString("BLOKE_ALT_NEDENI"));
					adkKanalBlokeTx.setBlokeAciklamasi(iMap.getString("BLOKE_KOYMA_ACIKLAMA"));
					
                    if (StringUtils.isNotBlank(iMap.getString("BASLANGIC_TARIHI"))) {
                        saat = iMap.getString("BASLANGIC_TARIHI_SAAT")==null?"000000":iMap.getString("BASLANGIC_TARIHI_SAAT");
                        dt =
                            sdf.parse(sdf.format(iMap.getDate("BASLANGIC_TARIHI"))
                                .replaceAll("[0-9]{2}:[0-9]{2}:[0-9]{2}", saat.substring(0, 2) + ":" + saat.substring(2, 4) + ":" + saat.substring(4)));
                        adkKanalBlokeTx.setBaslangicTarihi(dt);
                    }

                    if (StringUtils.isNotBlank(iMap.getString("BITIS_TARIHI"))) {
                        saat = iMap.getString("BITIS_TARIHI_SAAT")==null?"235900":iMap.getString("BITIS_TARIHI_SAAT");
                        dt = sdf.parse(sdf.format(iMap.getDate("BITIS_TARIHI")).replaceAll("[0-9]{2}:[0-9]{2}:[0-9]{2}", saat.substring(0, 2) + ":" + saat.substring(2, 4) + ":" + saat.substring(4)));
                        adkKanalBlokeTx.setBitisTarihi(dt);
                    }

					adkKanalBlokeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
					adkKanalBlokeTx.setDurumKodu(iMap.getString("DURUM_KODU"));
					adkKanalBlokeTx.setKullaniciKod(iMap.getString("KULLANICI_KOD"));
					if ((iMap.getString("BLOKE_ID")) == null || (iMap.getString("BLOKE_ID")).isEmpty()) {
						id.setBlokeId((BigDecimal) (GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID",aMap).get("ID")));
					} else {
						id.setBlokeId(iMap.getBigDecimal("BLOKE_ID"));
					}
					if ((iMap.getString("BLOKE_COZME_ACIKLAMA")) != null) {
						adkKanalBlokeTx.setBlokeCozmeAciklamasi(iMap.getString("BLOKE_COZME_ACIKLAMA"));
						if (iMap.getString("BLOKE_NEDENI")!= null) {	
							if (iMap.getString("BLOKE_NEDENI").equals("8") || iMap.getString("BLOKE_NEDENI").equals("9")){
								adkKanalBlokeTx.setFYeniSifre(iMap.getBoolean("F_YENI_SIFRE")? "E" : "H");
						    }
						}
					}
					session.saveOrUpdate(adkKanalBlokeTx);
				}
			}
			session.flush();

			iMap.put("TRX_NAME", "4131");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	

	@GraymoundService("BNSPR_TRN4131_GET_BLOKE_ACIKLAMA")
	public static GMMap GetBlokeAciklama(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN4131.RC_QRY4131_Kanal_Aciklama(?,?,?) }");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++,prepareKanalKod(iMap));
			stmt.setString(i++,iMap.getString("BLOKE_NEDENI"));
			stmt.setString(i++,iMap.getString("BLOKE_ALT_NEDENI"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			if (rSet.next()){
				oMap.put("BLOKE_ACIKLAMA",rSet.getString("ACIKLAMA"));
			} 
			return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}		

	@GraymoundService("BNSPR_TRN4131_GET_KANAL_BLOKE")
	public static GMMap GetKanalBloke(GMMap iMap) {
		
		GMMap oMap = new GMMap();		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try{
			
			if(iMap.getString("KULLANICI_KOD")!= null && !iMap.getString("KULLANICI_KOD").trim().isEmpty()){
				iMap.put("USER_CODE", AdcWinspireServices.getUserName(iMap.getString("KULLANICI_KOD"),iMap.getString("MUSTERI_NO")));
			}else{
				GMMap localMap = new GMMap().put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
				String userCode = GMServiceExecuter.call("BNSPR_CUST_GET_ADK_USERNAME", localMap).getString("USER_NAME");
				if (StringUtils.isBlank(userCode)) {
					iMap.put("HATA_NO", new BigDecimal(660));
	                iMap.put("P1", "M��terinin Kulan�c� Ad� Bulunamad�!!!");
	                return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				iMap.put("USER_CODE", userCode);
			}
			
			GMServiceExecuter.call("BNSPR_TRN4131_SYNCHRONIZE_USER_CHANNEL_BLOCKS", iMap);
			
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC_ADC.RC_QRY4131_Get_Kanal_Bloke(?,?,?) }");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++,iMap.getString("MUSTERI_NO"));
			stmt.setString(i++,iMap.getString("KULLANICI_KOD"));
			stmt.setBigDecimal(i++,null);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "BLOKE_BILGI";
			int row = 0;

			oMap.put("INTERNET", false);
			oMap.put("CAGRI_MERKEZI", false);
			oMap.put("IVR", false);
			oMap.put("MOBIL", false);
			oMap.put("PTT", false);
			oMap.put("WEB", false);
			
			while (rSet.next()){
			    String channelCode = rSet.getString("KANAL_KOD");
			    
				oMap.put(tableName,	row,"KOD",						channelCode);
				oMap.put(tableName,	row,"ACIKLAMA",					rSet.getString("KANAL_ACIKLAMA"));
				oMap.put(tableName, row,"BLOKE_NEDENI", 			rSet.getString("BLOKE_NEDEN_KOD"));
				oMap.put(tableName, row,"BLOKE_NEDENI_ACIKLAMA", 	rSet.getString("BLOKE_NEDEN_ACIKLAMA"));
				oMap.put(tableName, row,"BLOKE_ALT_NEDENI", 		rSet.getString("BLOKE_ALT_NEDEN_KOD"));
				oMap.put(tableName, row,"BLOKE_ALT_NEDENI_ACIKLAMA",rSet.getString("BLOKE_ALT_NEDEN_ACIKLAMA"));
				oMap.put(tableName, row,"BLOKE_ACIKLAMA", 			rSet.getString("BLOKE_ACIKLAMASI"));
				oMap.put(tableName, row,"BLOKE_TARIHI", 			rSet.getDate("BLOKE_TARIHI"));
				oMap.put(tableName, row,"KULLANICI", 				rSet.getString("BLOKE_KOYAN_KULLANICI"));
				oMap.put(tableName, row,"BLOKE_ID", 				rSet.getString("BLOKE_ID"));
				oMap.put(tableName, row,"BLOKE_TARIH_SAAT",			rSet.getString("BLOKE_KOYMA_SISTEM_TARIHI"));
				
				if(!oMap.getBoolean("INTERNET") && (("4").equals(channelCode) || ("10").equals(channelCode))){
					oMap.put("INTERNET", true);
				}
				if(!oMap.getBoolean("CAGRI_MERKEZI") && ("5").equals(channelCode)){
					oMap.put("CAGRI_MERKEZI", true);
				}
				if(!oMap.getBoolean("IVR") && ("6").equals(channelCode)){
					oMap.put("IVR", true);
				}
				if(!oMap.getBoolean("PTT") && ("7").equals(channelCode)){
					oMap.put("PTT", true);
				}
				if(!oMap.getBoolean("MOBIL") && ("13").equals(channelCode)){
					oMap.put("MOBIL", true);
				}
				if(!oMap.getBoolean("WEB") && ("71").equals(channelCode)){
				    oMap.put("WEB", true);
				}
				row++;
			} 
			return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}		

	//kullanicinin adc_man_user_block tablosunda olup da akustige atilamamis (suresi gecmemis)bloke kaydi varsa, ekrandan calisilabilmesi icin onlari akustige atar
    @GraymoundService("BNSPR_TRN4131_SYNCHRONIZE_USER_CHANNEL_BLOCKS")
	public static GMMap synchronizeUserChannelBlocks(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
        
		try{
			oMap = GMServiceExecuter.call("ADC_REMOTE_LIST_USER_CHANNEL_BLOCKS", iMap);
			
			String tableName = "BLOCK_LIST";

            Session session = DAOSession.getSession("BNSPRDal");
            String kanalKod;

			for(int i=0; i<oMap.getSize(tableName); i++){
				if(( (Calendar)oMap.get(tableName, i, "END_DATE") ).getTime().after(new Date())){ //suresi dolmus kayitlarla ilgilenme
				    kanalKod = null;

		            if (StringUtils.isNotBlank(oMap.getString(tableName, i, "CHANNEL_CODE"))) {
                        GnlKanalGrupKodPr kanalGrupKodPr = (GnlKanalGrupKodPr)session.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("integrationId", oMap.getString(tableName, i, "CHANNEL_CODE"))).uniqueResult();
                        if(kanalGrupKodPr!=null)
                            kanalKod = kanalGrupKodPr.getKod();
		            }
		            
                    /*
                     * A�a��daki sql'in �rne�i:
                     * 
                     * select count(*) from bnspr.adk_kanal_bloke where
                     * musteri_no = '1003231' and kanal_kod='4' and '42' =
                     * decode(bloke_neden_kod,null,
                     * null,decode(bloke_alt_neden_kod, null, bloke_neden_kod,
                     * bloke_neden_kod||bloke_alt_neden_kod)) and durum_kodu =
                     * 'K' and (bitis_tarihi is null or bitis_tarihi >= SYSDATE)
                     */

                    boolean akustikRecordExists =
                        ((BigDecimal) session.createSQLQuery(
                            "select count(*) from bnspr.adk_kanal_bloke where musteri_no = '" + iMap.getBigDecimal("MUSTERI_NO") + "'" + (kanalKod == null ? "" : " and kanal_kod='" + kanalKod + "'")
                                + (iMap.getBigDecimal("KULLANICI_KOD") == null ? "" : " and kullanici_kod='" + iMap.getBigDecimal("KULLANICI_KOD") + "'")
                                + " and '" + oMap.getString(tableName, i, "BLOCK_TYPE") + "' = decode(bloke_neden_kod,null, null,decode(bloke_alt_neden_kod, null, bloke_neden_kod, bloke_neden_kod||bloke_alt_neden_kod))"
                                + " and durum_kodu = 'K' and (bitis_tarihi is null or bitis_tarihi >= SYSDATE)").uniqueResult()).compareTo(new BigDecimal("0")) == 1;

					if(!akustikRecordExists){ //adc_man_user_block'a atilan bloke kaydi adk_kanal_bloke'ye atilamamissa
	
						AdkKanalBlokeTmp adkKanalBlokeTmp = new AdkKanalBlokeTmp();
						AdkKanalBlokeTmpId id = new AdkKanalBlokeTmpId();
						BigDecimal blokeId = (BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "KANAL_BLOKE")).get("ID");
						id.setBlokeTmpId(blokeId);
						id.setSiraNo(new BigDecimal(0));
		
						adkKanalBlokeTmp.setId(id);
						adkKanalBlokeTmp.setBlokeAciklamasi(oMap.getString(tableName, i, "NOTE"));
						adkKanalBlokeTmp.setBlokeTip(oMap.getString(tableName, i, "BLOCK_TYPE"));
						adkKanalBlokeTmp.setKanalKod(oMap.getString(tableName, i, "CHANNEL_CODE"));
						adkKanalBlokeTmp.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
						if(iMap.getBigDecimal("KULLANICI_KOD") != null){
							adkKanalBlokeTmp.setKullaniciKodu(iMap.getBigDecimal("KULLANICI_KOD"));
						}
						SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd kkmmss");
		
						if (oMap.getString(tableName, i, "START_DATE")!=null && oMap.getString(tableName, i, "START_DATE").length()>0){
							adkKanalBlokeTmp.setBaslangicTarihi(sdf.parse(oMap.getString(tableName, i, "START_DATE")));
						}
		
						if (oMap.getString(tableName, i, "END_DATE")!=null && oMap.getString(tableName, i, "END_DATE").length()>0){
							adkKanalBlokeTmp.setBitisTarihi(sdf.parse(oMap.getString(tableName, i, "END_DATE")));
						}
		
						if(oMap.getCalendar(tableName, i, "PROCESS_DATE") != null){
							adkKanalBlokeTmp.setProcessDate(oMap.getCalendar(tableName, i, "PROCESS_DATE").getTime());
						}
						session.save(adkKanalBlokeTmp);
						
						Object[] rSet = (Object[]) session.createSQLQuery(
                            "(SELECT KOD bk, null bak FROM V_ML_GNL_BLOKE_NEDEN_KOD_PR where KOD = '"+adkKanalBlokeTmp.getBlokeTip()+"' and KOD not in (SELECT BLOKE_NEDEN||KOD  bloke_neden_kod FROM V_ML_GNLBLOKEALTNEDENKOD_PR)) "+
                            "union "+
                            "(SELECT BLOKE_NEDEN bk, KOD bak FROM V_ML_GNLBLOKEALTNEDENKOD_PR where BLOKE_NEDEN||KOD='"+adkKanalBlokeTmp.getBlokeTip()+"')").uniqueResult();

						AdkKanalBloke adkKanalBloke = new AdkKanalBloke();
						adkKanalBloke.setBlokeId(blokeId);
						adkKanalBloke.setMusteriNo(adkKanalBlokeTmp.getMusteriNo());
						if(adkKanalBlokeTmp.getKullaniciKodu()!=null)
							adkKanalBloke.setKullaniciKod(adkKanalBlokeTmp.getKullaniciKodu().toString());
						adkKanalBloke.setKanalKod(kanalKod);
						if (rSet !=null ) {
                            adkKanalBloke.setBlokeNedenKod((String) rSet[0]);    
                            adkKanalBloke.setBlokeAltNedenKod((String) rSet[1]);
						}
						adkKanalBloke.setBlokeAciklamasi(adkKanalBlokeTmp.getBlokeAciklamasi());
						adkKanalBloke.setBlokeTarihi(adkKanalBlokeTmp.getBaslangicTarihi());
						adkKanalBloke.setBlokeKoyanKullanici("SYS");
						adkKanalBloke.setBaslangicTarihi(adkKanalBlokeTmp.getBaslangicTarihi());
						adkKanalBloke.setBitisTarihi(adkKanalBlokeTmp.getBitisTarihi());
						adkKanalBloke.setDurumKodu("K");
						adkKanalBloke.setBlokeKoymaSistemTarihi(adkKanalBlokeTmp.getBaslangicTarihi());
						session.save(adkKanalBloke);
						session.flush();
					}	
				}	

			}
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
            GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);			
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4131_GET_KANAL_BLOKE_COZME")
	public static GMMap GetKanalBlokeCozme(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_ADC.RC_QRY4131_Get_Kanal_Bloke(?,?,?) }");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++,iMap.getString("MUSTERI_NO"));
			stmt.setString(i++,iMap.getString("KULLANICI_KOD"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("BLOKE_ID"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);

			SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd.MM.yyyy");
            SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HHmmss");

			while(rSet.next())
			{
				oMap.put("BLOKE_KOYAN_KULLANICI", rSet.getString("BLOKE_KOYAN_KULLANICI"));
                oMap.put("BITIS_TARIHI", rSet.getDate("BITIS_TARIHI"));
                oMap.put("BASLANGIC_TARIHI", rSet.getDate("BASLANGIC_TARIHI"));
                
                oMap.put("BITIS_TARIHI", rSet.getDate("BITIS_TARIHI"));
                oMap.put("BASLANGIC_TARIHI", rSet.getDate("BASLANGIC_TARIHI"));

                oMap.put("BASLANGIC_TARIHI_SAATI", rSet.getDate("BASLANGIC_TARIHI")==null ? "000000":sdf.format(rSet.getDate("BASLANGIC_TARIHI")).split(" ")[1]);
                oMap.put("BITIS_TARIHI_SAATI", rSet.getDate("BITIS_TARIHI")==null ? "235900":sdf.format(rSet.getDate("BITIS_TARIHI")).split(" ")[1]);

                oMap.put("BLOKE_NEDEN_KOD", rSet.getString("BLOKE_NEDEN_KOD"));
				oMap.put("BLOKE_ALT_NEDEN_KOD", rSet.getString("BLOKE_ALT_NEDEN_KOD"));

				oMap.put("BLOKE_TARIHI", rSet.getDate("BLOKE_TARIHI"));
                oMap.put("BLOKE_TARIHI_SAAT",rSet.getDate("BITIS_TARIHI")==null ? "000000": sdf.format(rSet.getDate("BLOKE_TARIHI")).split(" ")[1]);

				oMap.put("BLOKE_ACIKLAMASI", rSet.getString("BLOKE_ACIKLAMASI"));
				if(rSet.getDate("BITIS_TARIHI")!= null && simpleDateFormat1.parse("24.01.2989").getTime() == 
					simpleDateFormat2.parse(rSet.getDate("BITIS_TARIHI").toString()).getTime())
				{
					oMap.put("BITIS_TARIHI", "");
				}
				else
				{
					oMap.put("BITIS_TARIHI", rSet.getDate("BITIS_TARIHI"));
				}
			}
			return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}		

    @GraymoundService("BNSPR_TRN4131_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = (List<?>) session.createCriteria(AdkKanalBlokeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			List<String> kanalList = new ArrayList<String>();

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HHmmss");
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				AdkKanalBlokeTx adkKanalBlokeTx = (AdkKanalBlokeTx) iterator.next();
				kanalList.add(adkKanalBlokeTx.getId().getKanalKod());
				oMap.put("MUSTERI_NO", adkKanalBlokeTx.getMusteriNo());
				oMap.put("DI_MUSTERI_NO", LovHelper.diLov(adkKanalBlokeTx.getMusteriNo(), "4131/LOV_MUSTERI", "UNVAN")); 
				oMap.put("BLOKE_ID", adkKanalBlokeTx.getId().getBlokeId());
				oMap.put("DURUM_KODU", adkKanalBlokeTx.getDurumKodu());
				oMap.put("BLOKE_NEDENI", adkKanalBlokeTx.getBlokeNedenKod());
				oMap.put("BLOKE_ALT_NEDENI", adkKanalBlokeTx.getBlokeAltNedenKod());
				oMap.put("BASLANGIC_TARIHI", adkKanalBlokeTx.getBaslangicTarihi()); 
                oMap.put("BITIS_TARIHI", adkKanalBlokeTx.getBitisTarihi());
 
				oMap.put("BASLANGIC_TARIHI_SAAT", adkKanalBlokeTx.getBaslangicTarihi()==null?null:sdf.format(adkKanalBlokeTx.getBaslangicTarihi()).split(" ")[1]); 
                oMap.put("BITIS_TARIHI_SAAT", adkKanalBlokeTx.getBitisTarihi()==null?null:sdf.format(adkKanalBlokeTx.getBitisTarihi()).split(" ")[1]);

                oMap.put("BLOKE_KOYMA_ACIKLAMA", adkKanalBlokeTx.getBlokeAciklamasi());
				if (adkKanalBlokeTx.getBlokeKoyanKullanici()!= null){
					oMap.put("BLOKE_KOYAN_KULLANICI",adkKanalBlokeTx.getBlokeKoyanKullanici());
				}
				if (adkKanalBlokeTx.getBlokeTarihi()!= null){
                    oMap.put("BLOKE_TARIHI",adkKanalBlokeTx.getBlokeTarihi());
                    oMap.put("BLOKE_TARIHI_SAAT",adkKanalBlokeTx.getBlokeTarihi()==null?null:sdf.format(adkKanalBlokeTx.getBlokeTarihi()).split(" ")[1]);
				}
				if (adkKanalBlokeTx.getBlokeCozmeAciklamasi()!= null){
					oMap.put("BLOKE_COZME_ACIKLAMA", adkKanalBlokeTx.getBlokeCozmeAciklamasi()); 
				}
				if (adkKanalBlokeTx.getFYeniSifre()!= null){
					oMap.put("F_YENI_SIFRE", "E". equals(adkKanalBlokeTx.getFYeniSifre()));
				}else{
					oMap.put("F_YENI_SIFRE", false); 
				}
			}

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN4131_GET_KANAL_LIST", new GMMap()));

			String tableName = "KANAL_LIST";
			for(int i=0; i<kanalList.size(); i++){
				for(int j=0; j<oMap.getSize(tableName); j++){
					if(kanalList.get(i).toString().equals(oMap.getString(tableName, j, "KANAL_KOD"))){
						oMap.put(tableName, j, "SEC", true);
					}
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	

	@GraymoundService("BNSPR_TRN4131_BLOKE_COZME_YETKI_KONTROL")
	public static GMMap BlokeCozmeYetkiKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN4131.Yetki_Kontrol(?,?,?,?) }");
			int i = 1;	
			stmt.setString(i++,"KA");
			stmt.setString(i++,iMap.getString("KOD"));
			stmt.setString(i++,iMap.getString("BLOKE_NEDENI"));
			stmt.setString(i++,iMap.getString("BLOKE_ALT_NEDENI"));
			stmt.execute();
			return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	

	@GraymoundService("BNSPR_TRN4131_ADK_INFO_MAIL")
	public static GMMap ADKInfoMail(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN4131.ADK_infomail(?,?) }");
			int i = 1;	
			stmt.setBigDecimal(i++,iMap.getBigDecimal("BLOKE_ID"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("KOYMA_COZME"));
			stmt.execute();
			return oMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	

	@GraymoundService("BNSPR_TRN4131_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(AdkKanalBlokeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			GMMap serviceMap;
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
			SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd.MM.yyyy");
			Calendar startDate = Calendar.getInstance();
			Calendar endDate = Calendar.getInstance();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				AdkKanalBlokeTx adkKanalBlokeTx = (AdkKanalBlokeTx) iterator.next();
				serviceMap = new GMMap();
				if(adkKanalBlokeTx.getKullaniciKod()!= null && !("").equals(adkKanalBlokeTx.getKullaniciKod())){
					serviceMap.put("USER_CODE", AdcWinspireServices.getUserName(adkKanalBlokeTx.getKullaniciKod(),adkKanalBlokeTx.getMusteriNo().toString()));

				}else{
					GMMap sMap = new GMMap().put("MUSTERI_NO", adkKanalBlokeTx.getMusteriNo());
					sMap = GMServiceExecuter.call("BNSPR_CUST_GET_ADK_USERNAME", sMap);
					String userCode = sMap.getString("USER_NAME");
					serviceMap.put("USER_CODE", userCode);
				}
				serviceMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_CHANNEL_CODE", new GMMap().put("KANAL_KOD", adkKanalBlokeTx.getId().getKanalKod())));
				if(adkKanalBlokeTx.getBlokeAltNedenKod()==null || "".equals(adkKanalBlokeTx.getBlokeAltNedenKod()))serviceMap.put("BLOCK_TYPE",adkKanalBlokeTx.getBlokeNedenKod());
				else serviceMap.put("BLOCK_TYPE",Integer.parseInt(adkKanalBlokeTx.getBlokeNedenKod())*10+Integer.parseInt(adkKanalBlokeTx.getBlokeAltNedenKod()));
				if(adkKanalBlokeTx.getDurumKodu().equals("K")){
					if(adkKanalBlokeTx.getBaslangicTarihi()==null){
						startDate.setTimeInMillis(simpleDateFormat.parse((String)GMServiceExecuter.execute("BNSPR_GET_SYSDATE", new GMMap()).get("SYS_DATE")).getTime());
					}else {
						startDate.setTime(adkKanalBlokeTx.getBaslangicTarihi());
					}
					serviceMap.put("START_DATE",startDate);
					if(adkKanalBlokeTx.getBitisTarihi()==null){
						endDate.setTime(simpleDateFormat1.parse("01.01.2989"));
					}else {
						endDate.setTime(adkKanalBlokeTx.getBitisTarihi());
					}
					serviceMap.put("END_DATE", endDate);
					serviceMap.put("NOTE", adkKanalBlokeTx.getBlokeAciklamasi());
					serviceMap.put("KEEP_SESSION_ALIVE", true); // bloke koyma servisi lokalden cagriliyor, kendi sessionimizi kill edip topugumuza sikmayalim

					
					GMServiceExecuter.call("ADC_REMOTE_BLOCK_USER_CHANNEL", serviceMap);
					serviceMap = new GMMap();
					serviceMap.put("BLOKE_ID",adkKanalBlokeTx.getId().getBlokeId());
					serviceMap.put("KOYMA_COZME",1);
					GMServiceExecuter.call("BNSPR_TRN4131_ADK_INFO_MAIL",serviceMap);
				}
				else if(adkKanalBlokeTx.getDurumKodu().equals("C")){
					
//					GMMap i2Map = new GMMap();
//					i2Map.put("UID", serviceMap.getString("USER_CODE"));
//					i2Map.put("LDAP_USER", GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_INT", i2Map).get("LDAP_USER"));
//					if(i2Map.getBoolean("LDAP_USER")){
//						i2Map.put("USER_STATUS", "Active");
//						GMServiceExecuter.execute("BNSPR_SYSTEM_LDAP_SET_USER_STATUS_INT", i2Map);
//					}
					
					GMServiceExecuter.call("ADC_REMOTE_UNBLOCK_USER_CHANNEL", serviceMap);
					//kanal internet ise mobil kanal� i�in de userchannel kayd�n�n password fail count'u s�f�rlanmal�
					if(adkKanalBlokeTx.getId().getKanalKod().equals("4")){
						serviceMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_CHANNEL_CODE", new GMMap().put("KANAL_KOD", "13")));
						GMServiceExecuter.call("ADC_REMOTE_UNBLOCK_USER_CHANNEL", serviceMap);
					}
					
					if (("8").equals(adkKanalBlokeTx.getBlokeNedenKod()) || ("9").equals(adkKanalBlokeTx.getBlokeNedenKod())){
						if(("E").equals(adkKanalBlokeTx.getFYeniSifre())){
							GMServiceExecuter.call("BNSPR_TRN4131_PAROLA_PASSWORD", iMap);	
						}
					}
					serviceMap = new GMMap();
					serviceMap.put("BLOKE_ID",adkKanalBlokeTx.getId().getBlokeId());
					serviceMap.put("KOYMA_COZME",0);
					GMServiceExecuter.call("BNSPR_TRN4131_ADK_INFO_MAIL",serviceMap);
				}
			}
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}


	@GraymoundService("BNSPR_TRN4131_PAROLA_PASSWORD")
	public static GMMap parolaPassword(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		CallableStatement stmt3 = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			AdkKanalBlokeTx adkKanalBlokeTx = (AdkKanalBlokeTx) session.createCriteria(AdkKanalBlokeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN4131.otpTel_AnneKizlikSayadi(?,?,?,?)}");

			stmt.setBigDecimal			(1, adkKanalBlokeTx.getMusteriNo());
			stmt.registerOutParameter	(2, Types.VARCHAR); //TCKN
			stmt.registerOutParameter	(3, Types.VARCHAR); //TEL NO
			stmt.registerOutParameter	(4, Types.VARCHAR); //AKS
			stmt.execute();
			
			String kanalKod = adkKanalBlokeTx.getId().getKanalKod();
			
			String phoneNumber = stmt.getString(3);
			JGMPasswordField passwordField = new JGMPasswordField();
			if (adkKanalBlokeTx.getFYeniSifre().equals("E")){	
				Integer pass = (new Random().nextInt(900000)+100000);
				passwordField.setText(pass.toString());

				GMMap servisMap = new GMMap();
				servisMap.put("USER_CODE", stmt.getString(2));
				servisMap.put("CUSTOMER_ID", adkKanalBlokeTx.getMusteriNo());
				servisMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_CHANNEL_CODE", new GMMap().put("KANAL_KOD", kanalKod)));
				servisMap.put("PASSWORD", new String(passwordField.getPassword()));
				servisMap.put("SERVICE_NAME","ADC_REMOTE_USER_UPDATE_PASSWORD");
				GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap); 
		
				if (("4").equals(kanalKod)){
					servisMap = new GMMap();
					servisMap.put("USER_CODE", stmt.getString(2));
					servisMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_CHANNEL_CODE", new GMMap().put("KANAL_KOD", "13"))); //mobil kanal�n�n sifreside update edilmeli
					servisMap.put("PASSWORD", new String(passwordField.getPassword()));
					servisMap.put("SERVICE_NAME","ADC_REMOTE_USER_UPDATE_PASSWORD");	
					GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap); 
				}
				
				if (("13").equals(kanalKod)){
					servisMap = new GMMap();
					servisMap.put("USER_CODE", stmt.getString(2));
					servisMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_CHANNEL_CODE", new GMMap().put("KANAL_KOD", "4")));//internet kanal�n�n sifreside update edilmeli
					servisMap.put("PASSWORD", new String(passwordField.getPassword()));
					servisMap.put("SERVICE_NAME","ADC_REMOTE_USER_UPDATE_PASSWORD");
					GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap); 
				}
			
                if (!"53".equals(kanalKod)
                        && !"55".equals(kanalKod)) {
    				stmt2 = conn.prepareCall("{? = call PKG_TRN4131.Musteri_mesaj(?,?,?)}");
    
    				stmt2.registerOutParameter(1, Types.VARCHAR);
    				stmt2.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
    				stmt2.setInt(3, pass );
    				stmt2.setString(4, kanalKod);
    				stmt2.execute();		
    							
    				String mesaj  = stmt2.getString(1);						
    				
    				
    				GMMap iMap1 = new GMMap();
    				//iMap1.put("MESSAGE_NO", new BigDecimal("1357"));
    				//iMap1.put("P1",pass);
    				//iMap1.put("P5",adkKanalBlokeTx.getId().getKanalKod());
    				//String mesaj = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap1).get("ERROR_MESSAGE");
    				
    				iMap1.put("CONTENT", mesaj);
    				iMap1.put("MSISDN", phoneNumber);
    				iMap1.put("SECURE_CONTENT", true);
    				iMap1.put("FILTER", true);
    
    				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap1);
                }
				
//				if(kanalKod.equals("4"));{
//				    GMMap iMap2 = new GMMap();
//				    
//				    iMap2.put("UID", stmt.getString(2));
//				    iMap2.put("PASSWORD", pass.toString());
//				    
//				    GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_INT", iMap2);
//				}
			}
			
	

			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_KANAL_BLOKE_ISLEM")
	public static GMMap kanalBlokeIslem(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try{			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_KANAL_BLOKE.KANAL_BLOKE(?,?,?,?,?,?)}");
			String tableName = "KANAL_LIST";
			for(int j = 0; j< iMap.getSize(tableName);j++){
				int i= 1;
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
				stmt.setString(i++, iMap.getString(tableName, j, "KANAL_KOD"));
				stmt.setString(i++, iMap.getString("BLOKE_NEDEN"));
				stmt.setString(i++, iMap.getString("DURUM_KOD"));
				stmt.setString(i++, iMap.getString("BLOKE_COZME_ACIKLAMASI"));
				stmt.execute();
			}
			iMap.put("ISLEM_NO", iMap.getBigDecimal("TX_NO"));
			GMServiceExecuter.execute("BNSPR_TRN4131_AFTER_APPROVAL", iMap);
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}

