package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KibSifreBasim;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;

public class AdcQRY4206Services {
	
	
	@GraymoundService("BNSPR_QRY4206_TABLO")
	public static GMMap adcOzetTablosu(GMMap iMap)throws ParseException{
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		 
		try{
			if (iMap.getString("CHBOX_INTERNET") == "false" & iMap.getString("CHBOX_CAGRI_MERKEZI") == "false") {
				iMap.put("MESSAGE_NO", new BigDecimal(330));
				iMap.put("P1", "SIFRE KANALI");
				oMap.put("MESSAGE",(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				return oMap;
			}
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_RC4206.RC_QRY4206_Sifre_Uretme (?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SIFRE_ADEDI"));
			stmt.setString(i++, iMap.getString("CHBOX_INTERNET"));
			stmt.setString(i++, iMap.getString("CHBOX_CAGRI_MERKEZI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("STATUS"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "TBL_SIFRE_BASIM");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY4206_YAZICI")
	public static GMMap adcYaziciyaGonder(GMMap iMap)throws ParseException{
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		String tableName = "TBL_SIFRE_BASIM";
		String userPassword;
		List<?> list = (List<?>) iMap.get(tableName);
		Session session = DAOSession.getSession("BNSPRDal");
		try{
			conn = DALUtil.getGMConnection();
			
			for (int i=0;i<list.size();i++){
				
				KibSifreBasim kibSifreBasim = (KibSifreBasim)session.get(KibSifreBasim.class, iMap.getBigDecimal(tableName,i, "TBL_ZARF_NO"));
				
				JGMPasswordField passwordField = new JGMPasswordField();
				userPassword = (new BigDecimal(100000).add(new BigDecimal(new Random().nextInt(900000)))).toString();
				passwordField.setText(userPassword);
				Calendar cal = Calendar.getInstance();
				DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
				
				String password = new String(passwordField.getPassword());
				
				kibSifreBasim.setSifreNo(password);
				iMap.put(tableName,i, "TBL_SIFRE_NO",userPassword);
				kibSifreBasim.setSifreZarfNo(iMap.getBigDecimal(tableName,i, "TBL_ZARF_NO"));
				kibSifreBasim.setDurumKodu( "B");
				kibSifreBasim.setBasimTarihi(dateFormat.parse(dateFormat.format(cal.getTime())));
				
				iMap.put(tableName,i, "TBL_ZARF_NO",iMap.getString(tableName,i, "TBL_ZARF_NO"));
				
				session.saveOrUpdate(kibSifreBasim);
				session.flush();
				
			}
			oMap.put("REPORT_DATA",list);

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}
	
	
}
