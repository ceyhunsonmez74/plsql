package tr.com.calikbank.bnspr.adc.services;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDkGrupUrunSinifPr;
import tr.com.calikbank.bnspr.dao.GnlDkGrupUrunSinifPrId;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcQRY4194Services {
	
	
	@GraymoundService("BNSPR_QRY4194_UPDATE")
	public static Map<?, ?> Update (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
					
			String tableName = "GRUP_URUN_SINIF";
			List<?> recordList = (List<?>)iMap.get(tableName);

			for(int i = 0; i < recordList.size(); i++) {
			  if ((iMap.getString(tableName,i,"INT") == null) && (iMap.getString(tableName,i,"INT_ISLEM") == null)) continue;
			  if((iMap.getString(tableName,i,"INT") == null)) iMap.put(tableName,i,"INT",0);
			  if((iMap.getString(tableName,i,"INT_ISLEM") == null)) iMap.put(tableName,i,"INT_ISLEM",0);
				if (!iMap.getString(tableName, i, "INT").equals(iMap.getString(tableName, i, "INT_ORG")) ||
				    !iMap.getString(tableName, i, "INT_ISLEM").equals(iMap.getString(tableName, i, "INT_ISLEM_ORG"))) 
				{ 
					GnlDkGrupUrunSinifPrId dkGrupUrunSinifPrId = new GnlDkGrupUrunSinifPrId();

					dkGrupUrunSinifPrId.setGrupKod(iMap.getBigDecimal("DK_GRUP_KODU"));
					dkGrupUrunSinifPrId.setModulTurKod(iMap.getString(tableName, i, "MODUL_TUR_KOD"));
					dkGrupUrunSinifPrId.setUrunTurKod(iMap.getString(tableName, i, "URUN_TUR_KOD"));
					dkGrupUrunSinifPrId.setUrunSinifKod(iMap.getString(tableName, i, "URUN_SINIF_KOD"));
					
					GnlDkGrupUrunSinifPr dkGrupUrunSinifPr = (GnlDkGrupUrunSinifPr)session.get(GnlDkGrupUrunSinifPr.class, dkGrupUrunSinifPrId);
					
					dkGrupUrunSinifPr.setId(dkGrupUrunSinifPrId);
					dkGrupUrunSinifPr.setIntBankGoruntuF(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "INT")));
					dkGrupUrunSinifPr.setIntBankIslemYapilsinF(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "INT_ISLEM")));
					
					session.saveOrUpdate(dkGrupUrunSinifPr);
					session.flush();
				}
			
			}
			
			return new GMMap().put("MESSAGE", "��lem tamamland�.");//GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} 
	}
	
	@GraymoundService("BNSPR_QRY4194_GET_GRUP_URUN_SINIF")
	public static GMMap getGrupUrunSinif(GMMap iMap){
		try{
			GMMap oMap = new GMMap(); 
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(
					GnlDkGrupUrunSinifPr.class).add(
					Restrictions.eq("id.grupKod", iMap
							.getBigDecimal("DK_GRUP_KODU"))).addOrder(
					Order.asc("id.modulTurKod")).addOrder(
					Order.asc("id.urunTurKod")).addOrder(
					Order.asc("id.urunSinifKod")).list();

			String tableName = "GRUP_URUN_SINIF";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlDkGrupUrunSinifPr dkGrupUrunSinifPr = (GnlDkGrupUrunSinifPr)iterator.next();
				oMap.put(tableName, row, "MODUL_TUR_KOD", dkGrupUrunSinifPr.getId().getModulTurKod());
                oMap.put(tableName, row, "URUN_TUR_KOD", dkGrupUrunSinifPr.getId().getUrunTurKod());
                oMap.put(tableName, row, "URUN_SINIF_KOD", dkGrupUrunSinifPr.getId().getUrunSinifKod());
                oMap.put(tableName, row, "DK_HESABI_1", dkGrupUrunSinifPr.getDkAna());
                oMap.put(tableName, row, "INT", GuimlUtil.convertToCheckBoxValue(dkGrupUrunSinifPr.getIntBankGoruntuF()));
                oMap.put(tableName, row, "INT_ORG", GuimlUtil.convertToCheckBoxValue(dkGrupUrunSinifPr.getIntBankGoruntuF()));
                oMap.put(tableName, row, "INT_ISLEM", GuimlUtil.convertToCheckBoxValue(dkGrupUrunSinifPr.getIntBankIslemYapilsinF()));
                oMap.put(tableName, row, "INT_ISLEM_ORG", GuimlUtil.convertToCheckBoxValue(dkGrupUrunSinifPr.getIntBankIslemYapilsinF()));
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
