package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksMutabakatHesapDetayPr;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatHesapDetayPrId;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatTanimPr;
import tr.com.aktifbank.bnspr.dao.ClksislemAlanDetayPr;
import tr.com.aktifbank.bnspr.dao.ClksislemAlanDetayPrId;
import tr.com.aktifbank.bnspr.dao.ClksislemHesapDetayPr;
import tr.com.aktifbank.bnspr.dao.ClksislemHesapDetayPrId;
import tr.com.aktifbank.bnspr.dao.ClksislemTanimPr;
import tr.com.aktifbank.bnspr.dao.ClksislemiliskiPr;
import tr.com.aktifbank.bnspr.dao.ClksislemiliskiPrId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class AdcPAR4025Services {

	private static Logger logger = Logger.getLogger(AdcPAR4025Services.class);
	private static String kaynakListe = "BNSPR_PAR4025.guiml";
	private static String kaynakTanim = "BNSPR_PAR4025_ISLEM_TANIMLAMA.guiml";

	@GraymoundService("BNSPR_PAR4025_ISLEM_SAVE")
	public static GMMap islemSave(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		String listTrn = "LISTE";
		String listCriteria = "KOSUL_LISTE";
		String listTrnAccountDetails = "ISLEM_HESAP_LISTE";
		String listReconAccountDetails = "MUTABAKAT_HESAP_LISTE";
		
		boolean contains = false;
		
		try {
		
			Session session = DAOSession.getSession("BNSPRDal");
		
			if(kaynakTanim.equals(iMap.getString("KAYNAK"))) {
				
				// Table: clks_islem_tanim_pr
				if(iMap.getString("CLKS_ISLEM_KOD").isEmpty()) {
					iMap.put("CLKS_ISLEM_KOD", new BigDecimal(DALUtil.getResult("select seq_clks_islem_tanim.nextval from dual")));
				}
				
				// Insert or update record(s).
				ClksislemTanimPr clksIslemTanimPr = (ClksislemTanimPr) session.get(ClksislemTanimPr.class, iMap.getBigDecimal("CLKS_ISLEM_KOD"));
			
				if(clksIslemTanimPr == null) {
					clksIslemTanimPr = new ClksislemTanimPr();
				}
				
				clksIslemTanimPr.setKod(iMap.getBigDecimal("CLKS_ISLEM_KOD"));
				clksIslemTanimPr.setAciklama(iMap.getString("ISLEM_ACIKLAMA"));
				clksIslemTanimPr.setAktif("E");
				clksIslemTanimPr.setIslemKod(iMap.getBigDecimal("ISLEM_KOD"));
				clksIslemTanimPr.setTabloAdi(iMap.getString("TABLO_ADI"));
				clksIslemTanimPr.setTahsilatOdeme(iMap.getString("TAHSILAT_ODEME"));
				clksIslemTanimPr.setOnayServisi(iMap.getString("ONAY_SERVISI"));
				clksIslemTanimPr.setLastModified(new java.sql.Date(System.currentTimeMillis()));
				session.saveOrUpdate(clksIslemTanimPr);
				
				// Table: clks_islem_hesap_detay_pr
				List<?> list = session.createCriteria(ClksislemHesapDetayPr.class).add(Restrictions.eq("id.clksIslemKod", iMap.getBigDecimal("CLKS_ISLEM_KOD"))).list();
				Iterator<?> iterator = list.iterator();
				
				// Delete record(s).
				while(iterator.hasNext()) {
					
					contains = false;
					ClksislemHesapDetayPr clksIslemHesapDetayPr = (ClksislemHesapDetayPr) iterator.next();
					
					for(int i = 0; i < iMap.getSize(listTrnAccountDetails); i++) {
						
						ClksislemHesapDetayPrId clksIslemHesapDetayPrId = new ClksislemHesapDetayPrId(
								iMap.getBigDecimal("CLKS_ISLEM_KOD"), 
								iMap.getBigDecimal(listTrnAccountDetails, i, "HESAP_NO"),
								iMap.getString(listTrnAccountDetails, i, "F_MASRAF"));
						
						if(clksIslemHesapDetayPr.getId().equals(clksIslemHesapDetayPrId)) {
							contains = true;
						}
					}
					
					if(!contains) {
						session.delete(clksIslemHesapDetayPr);
					}
				}
				
				// Insert or update record(s).
				for(int i = 0; i < iMap.getSize(listTrnAccountDetails); i++) {
					
					ClksislemHesapDetayPrId clksIslemHesapDetayPrId = new ClksislemHesapDetayPrId(
						iMap.getBigDecimal("CLKS_ISLEM_KOD"),
						iMap.getBigDecimal(listTrnAccountDetails, i, "HESAP_NO"),
						iMap.getString(listTrnAccountDetails, i, "F_MASRAF"));
					
					ClksislemHesapDetayPr clksIslemHesapDetayPr = (ClksislemHesapDetayPr) session.get(ClksislemHesapDetayPr.class, clksIslemHesapDetayPrId);
					
					if(clksIslemHesapDetayPr == null) {
						clksIslemHesapDetayPr = new ClksislemHesapDetayPr();
					}
					
					clksIslemHesapDetayPr.setId(clksIslemHesapDetayPrId);
					clksIslemHesapDetayPr.setDovizKod(iMap.getString(listTrnAccountDetails, i, "DOVIZ_KOD"));
					clksIslemHesapDetayPr.setAlanAdi(iMap.getString(listTrnAccountDetails, i, "ALAN_ADI"));
					clksIslemHesapDetayPr.setDovizAlanAdi(iMap.getString(listTrnAccountDetails, i, "DOVIZ_ALAN_ADI"));
					clksIslemHesapDetayPr.setLastModified(new java.sql.Date(System.currentTimeMillis()));
					session.saveOrUpdate(clksIslemHesapDetayPr);
				}
	
				// Table: clks_islem_alan_detay_pr
				list = session.createCriteria(ClksislemAlanDetayPr.class).add(Restrictions.eq("id.clksIslemKod", iMap.getBigDecimal("CLKS_ISLEM_KOD"))).list();
				iterator = list.iterator();
				
				// Delete record(s).
				while(iterator.hasNext()) {
					
					contains = false;
					ClksislemAlanDetayPr clksIslemAlanDetayPr = (ClksislemAlanDetayPr) iterator.next();
					
					for(int i = 0; i < iMap.getSize(listCriteria); i++) {
						
						ClksislemAlanDetayPrId clksIslemAlanDetayPrId = new ClksislemAlanDetayPrId(
							iMap.getBigDecimal("CLKS_ISLEM_KOD"), 
							iMap.getString(listCriteria, i, "ALAN_ADI"),
							iMap.getString(listCriteria, i, "DEGER"));
						
						if(clksIslemAlanDetayPr.getId().equals(clksIslemAlanDetayPrId)) {
							contains = true;
						}
					}
					
					if(!contains) {
						session.delete(clksIslemAlanDetayPr);
					}
				}
				
				// Insert or update record(s).
				for(int i = 0; i < iMap.getSize(listCriteria); i++) {
					
					ClksislemAlanDetayPrId clksIslemAlanDetayPrId = new ClksislemAlanDetayPrId(
						iMap.getBigDecimal("CLKS_ISLEM_KOD"), 
						iMap.getString(listCriteria, i, "ALAN_ADI"),
						iMap.getString(listCriteria, i, "DEGER"));
					
					ClksislemAlanDetayPr clksIslemAlanDetayPr = (ClksislemAlanDetayPr) session.get(ClksislemAlanDetayPr.class, clksIslemAlanDetayPrId);
					
					if(clksIslemAlanDetayPr == null) {
						clksIslemAlanDetayPr = new ClksislemAlanDetayPr();
					}
					
					clksIslemAlanDetayPr.setId(clksIslemAlanDetayPrId);
					clksIslemAlanDetayPr.setAlanTipi(iMap.getString(listCriteria, i, "ALAN_TIPI"));
					clksIslemAlanDetayPr.setLastModified(new java.sql.Date(System.currentTimeMillis()));
					session.saveOrUpdate(clksIslemAlanDetayPr);
				}
				
				// Table: clks_mutabakat_tanim_pr
				// Insert or update record(s).
				ClksMutabakatTanimPr clksMutabakatTanimPr = (ClksMutabakatTanimPr) session.createCriteria(ClksMutabakatTanimPr.class)
					.add(Restrictions.and(
						Restrictions.eq("islemTuru", iMap.getBigDecimal("ISLEM_TURU")), 
						Restrictions.eq("islemAltTuru", iMap.getBigDecimal("ISLEM_ALT_TURU")))).uniqueResult();
				
				
				if(clksMutabakatTanimPr == null) {
					clksMutabakatTanimPr = new ClksMutabakatTanimPr();
					iMap.put("CLKS_MUTABAKAT_KOD", new BigDecimal(DALUtil.getResult("select seq_clks_mutabakat_tanim.nextval from dual")));
				} 
				
				// Case: Mevcut Kayit
				else {
					iMap.put("CLKS_MUTABAKAT_KOD", clksMutabakatTanimPr.getKod());
				}
				
				/*
				clksMutabakatTanimPr.setKod(iMap.getBigDecimal("CLKS_MUTABAKAT_KOD"));
				clksMutabakatTanimPr.setAciklama(iMap.getString("MUTABAKAT_ACIKLAMA","Tan�ms�z"));
				clksMutabakatTanimPr.setIslemTuru(iMap.getBigDecimal("ISLEM_TURU"));
				clksMutabakatTanimPr.setIslemAltTuru(iMap.getBigDecimal("ISLEM_ALT_TURU"));
				clksMutabakatTanimPr.setLastModified(new java.sql.Date(System.currentTimeMillis()));
				session.saveOrUpdate(clksMutabakatTanimPr);
				*/
				
				// Table: clks_mutabakat_hesap_detay_pr
				list = session.createCriteria(ClksMutabakatHesapDetayPr.class).add(Restrictions.eq("id.clksMutabakatKod", iMap.getBigDecimal("CLKS_MUTABAKAT_KOD"))).list();
				iterator = list.iterator();
				
				// Delete record(s).
				while(iterator.hasNext()) {
					
					contains = false;
					ClksMutabakatHesapDetayPr clksMutabakatHesapDetayPr = (ClksMutabakatHesapDetayPr) iterator.next();
					
					for(int i = 0; i < iMap.getSize(listReconAccountDetails); i++) {
						
						ClksMutabakatHesapDetayPrId clksMutabakatHesapDetayPrId = new ClksMutabakatHesapDetayPrId(
								iMap.getBigDecimal("CLKS_MUTABAKAT_KOD"), 
								iMap.getBigDecimal(listReconAccountDetails, i, "HESAP_NO"),
								iMap.getString(listReconAccountDetails, i, "F_MASRAF"));
						
						if(clksMutabakatHesapDetayPr.getId().equals(clksMutabakatHesapDetayPrId)) {
							contains = true;
						}
					}
					
					if(!contains) {
						session.delete(clksMutabakatHesapDetayPr);
					}
				}
				
				// Insert or update record(s).
				for(int i = 0; i < iMap.getSize(listReconAccountDetails); i++) {
					
					ClksMutabakatHesapDetayPrId clksMutabakatHesapDetayPrId = new ClksMutabakatHesapDetayPrId(
						iMap.getBigDecimal("CLKS_MUTABAKAT_KOD"),
						iMap.getBigDecimal(listReconAccountDetails, i, "HESAP_NO"),
						iMap.getString(listReconAccountDetails, i, "F_MASRAF"));
					
					ClksMutabakatHesapDetayPr clksMutabakatHesapDetayPr = (ClksMutabakatHesapDetayPr) session.get(ClksMutabakatHesapDetayPr.class, clksMutabakatHesapDetayPrId);
					
					if(clksMutabakatHesapDetayPr == null) {
						clksMutabakatHesapDetayPr = new ClksMutabakatHesapDetayPr();
					}
					
					clksMutabakatHesapDetayPr.setId(clksMutabakatHesapDetayPrId);
					clksMutabakatHesapDetayPr.setDovizKod(iMap.getString(listReconAccountDetails, i, "DOVIZ_KOD"));
					clksMutabakatHesapDetayPr.setAlanAdi(iMap.getString(listReconAccountDetails, i, "ALAN_ADI"));
					clksMutabakatHesapDetayPr.setLastModified(new java.sql.Date(System.currentTimeMillis()));
					session.saveOrUpdate(clksMutabakatHesapDetayPr);
				}
	
				
				// Table: clks_islem_iliski_pr
				// Insert or update record(s).
				ClksislemiliskiPrId clksIslemIliskiPrId = new ClksislemiliskiPrId(
					iMap.getBigDecimal("CLKS_ISLEM_KOD"), 
					iMap.getBigDecimal("CLKS_MUTABAKAT_KOD"));
				
				ClksislemiliskiPr clksIslemIliskiPr = (ClksislemiliskiPr) session.get(ClksislemiliskiPr.class, clksIslemIliskiPrId);
				
				if(clksIslemIliskiPr == null) {
					clksIslemIliskiPr = new ClksislemiliskiPr();
				}
						
				clksIslemIliskiPr.setId(clksIslemIliskiPrId);
				clksIslemIliskiPr.setMutabakatTipi(iMap.getString("MUTABAKAT_TIPI"));
				clksIslemIliskiPr.setLastModified(new java.sql.Date(System.currentTimeMillis()));
				session.saveOrUpdate(clksIslemIliskiPr);
				session.flush();
			}
			
			// Case:
			else if(kaynakListe.equals(iMap.getString("KAYNAK"))) {
				
				// Table: clks_islem_alan_detay_pr
				List<?> list = session.createCriteria(ClksislemAlanDetayPr.class)/*.add(Restrictions.eq("id.clksIslemKod", iMap.getBigDecimal("CLKS_ISLEM_KOD")))*/.list();
				Iterator<?> iterator = list.iterator();
				
				// Delete record(s).
				while(iterator.hasNext()) {
					
					contains = false;
					ClksislemAlanDetayPr clksIslemAlanDetayPr = (ClksislemAlanDetayPr) iterator.next();
					
					for(int i = 0; i < iMap.getSize(listTrn); i++) {
						
						if(clksIslemAlanDetayPr.getId().getClksIslemKod().equals(iMap.getBigDecimal(listTrn, i, "CLKS_ISLEM_KOD"))) {
							contains = true;
						}
					}
					
					if(!contains) {
						session.delete(clksIslemAlanDetayPr);
					}
				}
				
				// Table: clks_islem_hesap_detay_pr
				list = session.createCriteria(ClksislemHesapDetayPr.class)/*.add(Restrictions.eq("id.clksIslemKod", iMap.getBigDecimal("CLKS_ISLEM_KOD")))*/.list();
				iterator = list.iterator();
				
				// Delete record(s).
				while(iterator.hasNext()) {
					
					contains = false;
					ClksislemHesapDetayPr clksIslemHesapDetayPr = (ClksislemHesapDetayPr) iterator.next();
					
					for(int i = 0; i < iMap.getSize(listTrn); i++) {
						
						if(clksIslemHesapDetayPr.getId().getClksIslemKod().equals(iMap.getBigDecimal(listTrn, i, "CLKS_ISLEM_KOD"))) {
							contains = true;
						}
					}
					
					if(!contains) {
						session.delete(clksIslemHesapDetayPr);
					}
				}
				
				// Table: clks_islem_iliski_pr
				list = session.createCriteria(ClksislemiliskiPr.class)/*.add(Restrictions.eq("id.clksIslemKod", iMap.getBigDecimal("CLKS_ISLEM_KOD")))*/.list();
				iterator = list.iterator();
				
				// Delete record(s).
				while(iterator.hasNext()) {
					
					contains = false;
					ClksislemiliskiPr clksIslemIliskiPr = (ClksislemiliskiPr) iterator.next();
					
					for(int i = 0; i < iMap.getSize(listTrn); i++) {
						
						ClksislemiliskiPrId clksIslemIliskiPrId = new ClksislemiliskiPrId(iMap.getBigDecimal(listTrn, i, "CLKS_ISLEM_KOD"), iMap.getBigDecimal(listTrn, i, "CLKS_MUTABAKAT_KOD"));
						
						if(clksIslemIliskiPr.getId().equals(clksIslemIliskiPrId)) {
							contains = true;
						}
					}
					
					if(!contains) {
						session.delete(clksIslemIliskiPr);
					}
				}
				
				// Table: clks_islem_tanim_pr
				list = session.createCriteria(ClksislemTanimPr.class)/*.add(Restrictions.eq("kod", iMap.getBigDecimal("CLKS_ISLEM_KOD")))*/.list();
				iterator = list.iterator();
				
				// Delete record(s).
				while(iterator.hasNext()) {
					
					contains = false;
					ClksislemTanimPr clksIslemTanimPr = (ClksislemTanimPr) iterator.next();
					
					for(int i = 0; i < iMap.getSize(listTrn); i++) {
						
						if(clksIslemTanimPr.getKod().equals(iMap.getBigDecimal(listTrn, i, "CLKS_ISLEM_KOD"))) {
							contains = true;
						}
					}
					
					if(!contains) {
						session.delete(clksIslemTanimPr);
					}
				}
				
				session.flush();
			}
			
			oMap.put("MESSAGE", "��lem Tamamland�.");
		}
		
		catch(Exception e) {
			logger.error("BNSPR_PAR4025_ISLEM_SAVE err: " + e);
			throw ExceptionHandler.convertException(e);
		}
			
		return oMap;
	}
	
	/*
	@GraymoundService("BNSPR_PAR4025_ILISKI_SAVE")
	public static GMMap iliskiSave(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			String listIliski = "LIST_ILISKI";
			String listIslem = "LIST_ISLEM";
			String listMutabakat = "LIST_MUTABAKAT";
			
			List<?> clksIslemMutabakatTanimPrList = session.createCriteria(ClksislemMutabakatTanimPr.class).list();
			Iterator<?> iterator = clksIslemMutabakatTanimPrList.iterator();
			
			boolean contains = false;
			
			// Delete record(s).
			while(iterator.hasNext()) {
				
				contains = false;
				ClksislemMutabakatTanimPr clksislemMutabakatTanimPr = (ClksislemMutabakatTanimPr) iterator.next();
				
				for(int i = 0; i < iMap.getSize(listIliski); i++) {
					
					ClksislemMutabakatTanimPrId clksislemMutabakatTanimPrId = new ClksislemMutabakatTanimPrId(
							iMap.getBigDecimal(listIliski, i, "CLKS_ISLEM_KOD"), 
							iMap.getBigDecimal(listIliski, i, "CLKS_MUTABAKAT_KOD"));
					
					if(clksislemMutabakatTanimPr.getId().equals(clksislemMutabakatTanimPrId)) {
						contains = true;
					}
				}
				
				if(!contains) {
					session.delete(clksislemMutabakatTanimPr);
				}
			}
			
			session.flush();
			
			// Insert or update record(s).
			for(int rowIslem = 0; rowIslem < iMap.getSize(listIslem); rowIslem++) {
				
				if(!iMap.getBoolean(listIslem, rowIslem, "CHECK")) {
					continue;
				}
				
				for(int rowMutabakat = 0; rowMutabakat < iMap.getSize(listMutabakat); rowMutabakat++) {
				
					if(!iMap.getBoolean(listMutabakat, rowMutabakat, "CHECK")) {
						continue;
					}
					
					ClksislemMutabakatTanimPrId clksislemMutabakatTanimPrId = new ClksislemMutabakatTanimPrId(
							iMap.getBigDecimal(listIslem, rowIslem, "KOD"), 
							iMap.getBigDecimal(listMutabakat, rowMutabakat, "KOD"));
					
					ClksislemMutabakatTanimPr clksislemMutabakatTanimPr = (ClksislemMutabakatTanimPr) session.get(ClksislemMutabakatTanimPr.class, clksislemMutabakatTanimPrId);
					
					if(clksislemMutabakatTanimPr == null) {
						clksislemMutabakatTanimPr = new ClksislemMutabakatTanimPr();
					}
					
					clksislemMutabakatTanimPr.setId(clksislemMutabakatTanimPrId);
					clksislemMutabakatTanimPr.setLastModified(new java.util.Date());
					session.saveOrUpdate(clksislemMutabakatTanimPr);
				}
			}
			
			session.flush();
			
			oMap.put("MESSAGE", "��lem Tamamland�.");
		}
		
		catch(Exception e) {
			logger.error("BNSPR_PAR4025_ILISKI_SAVE err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	*/
	
	public static void main(String[] args) {
	
		
	}
	
}
