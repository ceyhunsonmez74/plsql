package tr.com.calikbank.bnspr.adc.services;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.pojo.Language;
import tr.com.obss.adc.core.pojo.LanguageData;
import tr.com.obss.adc.core.util.ADCCore;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class AdcLanguageDataEditServices {
	
	@GraymoundService("ADK_GET_DATA_LIST")
	public static GMMap getDataList(GMMap iMap){
		try {
			GMMap 	oMap 		= new GMMap();
			Session session 	= DAOSession.getSession(ADCCore.SESSION_FACTORY);
			Query 	query		= null;
			String 	ownerTable 	= iMap.getString("OWNER_TABLE");
			
			if("Menu".equals(ownerTable) || "Channel".equals(ownerTable)) {
				query = session.createQuery("from LanguageData as ld " +
											"where ld.code = ? " +
											"and ld.ownerOid in (select t.oid from " + 
													ownerTable + " as t) ")
							.setString(0, iMap.getString("LANGUAGE"));
			}
			else if("ReferenceDataItem".equals(ownerTable)){
				query = session.createQuery("from LanguageData as ld " +
											"where ld.code = ? " +
											"and ld.ownerOid in (select t.oid from " + 
													ownerTable + " as t, ReferenceData rd  " +
													"where rd.moduleOid = ? " +
													"and rd.oid = t.parentOid) ")
								.setString(0, iMap.getString("LANGUAGE"))
								.setString(1, iMap.getString("MODULE_OID"));
			}
			else {
				query = session.createQuery("from LanguageData as ld " +
											"where ld.code = ? " +
											"and ld.ownerOid in (select t.oid from " + 
													ownerTable + " as t " +
													"where t.moduleOid = ? ) ")
								.setString(0, iMap.getString("LANGUAGE"))
								.setString(1, iMap.getString("MODULE_OID"));
			}
			
			List<?> list = query.list();
			
		    String tableName = "LISTE";
		    for(int i = 0; i < list.size(); i++) {
		    	LanguageData languageData = (LanguageData)list.get(i);
		    	oMap.put(tableName, i, "OID"			, languageData.getOid());
		    	oMap.put(tableName, i, "LANGUAGE_CODE"	, languageData.getCode());
		    	oMap.put(tableName, i, "LANGUAGE_DATA"	, languageData.getData());
		    	oMap.put(tableName, i, "OWNER_KEY"		, languageData.getOwnerKey());
		    	oMap.put(tableName, i, "OWNER_OID"		, languageData.getOwnerOid());
		    }
		    return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("ADK_GET_LANGUAGE_DATA_LIST")
	public static GMMap getLanguageDataList(GMMap iMap){
		try {
			Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
			
			Query query = session.createQuery("from LanguageData as ld " +
									"where ld.ownerOid = ? " +
									"and ld.ownerKey = ? " +
									"and ld.code in (select l.code from Language l) ")
							.setString(0, iMap.getString("OWNER_OID"))
							.setString(1, iMap.getString("OWNER_KEY"));
			List<?> list = query.list();
			
		    GMMap oMap = new GMMap();
		    String tableName = "LISTE";
		    int i = 0;
		    for(;i < list.size(); i++) {
		    	LanguageData languageData = (LanguageData)list.get(i);
		    	oMap.put(tableName, i, "OID"			, languageData.getOid());
		    	oMap.put(tableName, i, "LANGUAGE_CODE"	, languageData.getCode());
		    	oMap.put(tableName, i, "LANGUAGE_DATA"	, languageData.getData());
		    	oMap.put(tableName, i, "OWNER_KEY"		, languageData.getOwnerKey());
		    	oMap.put(tableName, i, "OWNER_OID"		, languageData.getOwnerOid());
		    	oMap.put(tableName, i, "FLAG_CHANGED"	, false);
		    	oMap.put(tableName, i, "LANGUAGE_DATA_TEMP"	, languageData.getData()==null?"":languageData.getData());
		    }
		    
		    List<?> languageList = session.createCriteria(Language.class).list();		    
		    for(int k = 0; k < languageList.size(); k++) {
		    	Language lang = (Language)languageList.get(k);
		    	boolean buDildeKayitYok = true;
			    for(int j = 0; j < list.size(); j++) {
			    	LanguageData languageData = (LanguageData)list.get(j);
			    	if(lang.getCode().equals(languageData.getCode())) {
			    		buDildeKayitYok = false;
			    	}
			    }
			    if(buDildeKayitYok) {
			    	oMap.put(tableName, i, "LANGUAGE_CODE"	, lang.getCode());
			    	oMap.put(tableName, i, "FLAG_CHANGED"	, false);
			    	i++;
			    }
		    }
		    	
		    return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("ADK_UPDATE_LANGUAGE_DATA_LIST")
	public static GMMap updateLanguageDataList(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
			String tableName = "LANGUAGE_DATA_LIST";
			for(int i=0; i<iMap.getSize(tableName); i++) {
				LanguageData languageData = (LanguageData)session.createCriteria(LanguageData.class)
											.add(Restrictions.eq("oid", iMap.getString(tableName, i, "OID")))
											.uniqueResult();
				
				String text = iMap.getString(tableName, i, "LANGUAGE_DATA");
				
				if(languageData == null) {
					languageData = new LanguageData();
					languageData.setCode(iMap.getString(tableName, i, "LANGUAGE_CODE"));
					languageData.setOwnerOid(iMap.getString("OWNER_OID"));
					languageData.setOwnerKey(iMap.getString("OWNER_KEY"));
					// yeni bir kay�t i�in metin bo� veya null ise bunu kaydetmeden gec
					if("".equals(text) || text == null)
						continue;
				}
				else {
					// mevcut bir kay�t i�in metin null veya dbdekine e�itse ise bunu kaydetmeden gec
					if(text == null || text.equals(languageData.getData())) {
						continue;
					}
				}
				languageData.setLastupdated(Calendar.getInstance().getTime());
				languageData.setData(iMap.getString(tableName, i, "LANGUAGE_DATA"));
				
				session.saveOrUpdate(languageData);
				session.flush();
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("ADK_GET_LANGUAGE_COMBO_DATA")
	public static GMMap getLangComboData(GMMap iMap) {
		try {
			GMMap 	oMap 	= new GMMap();
			Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
			
			List<?> languageList = session.createCriteria(Language.class).list();
			for (int i = 0; i<languageList.size(); i++) {
				Language language = (Language)languageList.get(i);
				oMap.put("LANG_LIST", i, "CODE", language.getCode());
				oMap.put("LANG_LIST", i, "NAME", language.getName());
			}

			Query query = session.createQuery("from LanguageData as ld " +
						"where ld.ownerOid in (select t.oid from Module as t) " +
						"and ld.code = 'tr'");
			List<?> moduleList = query.list();
			for (int i = 0; i<moduleList.size(); i++) {
				LanguageData module = (LanguageData)moduleList.get(i);
				oMap.put("MODULE_LIST", i, "CODE"		, module.getCode());
				oMap.put("MODULE_LIST", i, "NAME"		, module.getData());
				oMap.put("MODULE_LIST", i, "MODULE_OID"	, module.getOwnerOid());
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("ADK_GET_PAGE_LANGUAGE_DATA_LIST")
	public static GMMap getPageLanguageData(GMMap iMap) {
		Connection 			conn = null;
		PreparedStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select * from wnspr_language_data ");
			sqlQuery.append("where page_name = NVL(?,page_name) " +
					"and key like ? and language = NVL(?,language) and value like ? " +
					"order by page_name");
			stmt = conn.prepareStatement(sqlQuery.toString());
			stmt.setString(1, iMap.getString("PAGE_NAME"));
			stmt.setString(2, "%" + iMap.getString("KEY") + "%");
			stmt.setString(3, iMap.getString("LANGUAGE"));
			stmt.setString(4, "%" + iMap.getString("VALUE") + "%");
			
			rSet =stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "PAGE_LANGUAGE_DATA_LIST");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("ADK_SAVE_PAGE_LANGUAGE_DATA")
	public static GMMap savePageLanguageData(GMMap iMap) {
		Connection 			conn = null;
		PreparedStatement 	stmt = null;
		GMMap				oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			StringBuilder sqlQuery = new StringBuilder();

			String oid = iMap.getString("OID");
			if( oid == null || oid.trim().length() == 0) {
				oid = (String)DALUtil.callNoParameterFunction("{? = call genoid() }", Types.VARCHAR);
				sqlQuery.append("insert into wnspr_language_data(oid, page_name, key, language, value) ");
				sqlQuery.append("values (?,?,?,?,?) ");
				stmt = conn.prepareStatement(sqlQuery.toString());
				stmt.setString(1, oid);
				stmt.setString(2, iMap.getString("PAGE_NAME"));
				stmt.setString(3, iMap.getString("KEY"));
				stmt.setString(4, iMap.getString("LANGUAGE"));
				stmt.setString(5, iMap.getString("VALUE"));
			}
			else {
				sqlQuery.append("update wnspr_language_data set key = ?, value = ?");
				sqlQuery.append("where oid = ? ");
				stmt = conn.prepareStatement(sqlQuery.toString());
				stmt.setString(1, iMap.getString("KEY"));
				stmt.setString(2, iMap.getString("VALUE"));
				stmt.setString(3, oid);
			}
			
			stmt.execute();
			
			oMap.put("OID", oid);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("ADK_GET_SQL_SCRIPT")
	public static GMMap getSQLScript(GMMap iMap) {
		Connection 			conn = null;
		PreparedStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap				oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("select 'DELETE graymound.wnspr_language_data WHERE oid = ' || ? || ';' SCRIPT " +
					"FROM DUAL " + 
					"UNION ALL " + 
					"select 'INSERT INTO graymound.wnspr_language_data (oid, page_name, key, language, value) " +
							"VALUES (''' || m.oid || ''', ''' || m.page_name || ''', ''' || m.key || ''', " +
							"''' || m.language || ''', ''' || m.value || ''');' SCRIPT " + 
					"from graymound.wnspr_language_data m where m.oid = ? ");
			
						
			stmt = conn.prepareStatement(sqlQuery.toString());
			stmt.setString(1, "'" + iMap.getString("OID") + "'" );
			stmt.setString(2, iMap.getString("OID"));
			rSet = stmt.executeQuery();
			
			oMap = DALUtil.rSetResults(rSet, "SCRIPT_LIST");
			
			StringBuffer sb = new StringBuffer();
			for(int i = 0; i<oMap.getSize("SCRIPT_LIST");i++) {
				sb.append(oMap.getString("SCRIPT_LIST", i, "SCRIPT"));
				sb.append("\n");
			}
			
			oMap.put("SCRIPT_TEXT", sb.toString());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("ADK_GET_SQL_SCRIPT_ALL")
	public static GMMap getSQLScriptAll(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			StringBuffer sb = new StringBuffer();
			for(int i=0; i<iMap.getSize("TABLE_DATA");i++) {
				String oid = iMap.getString("TABLE_DATA", i, "OID");
				iMap.put("OID", oid);
				
				sb.append(getSQLScript(iMap).getString("SCRIPT_TEXT"));
			}			
			oMap.put("SCRIPT_TEXT", sb.toString());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("ADK_INSERT_TOPLU")
	public static GMMap ADK_INSERT_TOPLU(GMMap iMap) throws BiffException, IOException{
		GMMap oMap = new GMMap();
		File excelFile = new File("C:\\Documents and Settings\\recepa\\Desktop\\Kurumsal_Internet_Ingilizce_Ekranlar-1.xls");
		
		Workbook workbook = Workbook.getWorkbook(excelFile);
		Sheet sheet = workbook.getSheet(1);
		
		for(int i = 0; i < sheet.getRows(); i++) {
			String pageName = sheet.getCell(0, i).getContents();
			String key = sheet.getCell(1, i).getContents();
			String value = sheet.getCell(2, i).getContents();
			
			save(pageName, key, value);
		}
		workbook.close(); 
		
		return oMap;
	}
	private static void save(String pageName, String key, String value){
		Connection 			conn = null;
		PreparedStatement 	stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			
			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery.append("INSERT INTO graymound.wnspr_language_data (oid, page_name, key, language, value) " +
						"VALUES (genoid(), ?, ?, 'en', ?) ");
			
			stmt = conn.prepareStatement(sqlQuery.toString());
			stmt.setString(1, pageName);
			stmt.setString(2, key);
			stmt.setString(3, value);
			stmt.execute();
			
			System.out.println("OK");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
