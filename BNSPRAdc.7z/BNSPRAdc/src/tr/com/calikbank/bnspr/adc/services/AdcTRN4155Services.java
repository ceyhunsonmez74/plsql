package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriKanalKisitPrTx;
import tr.com.calikbank.bnspr.dao.GnlMusteriKanalKisitPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcTRN4155Services {

	@GraymoundService("BNSPR_TRN4155_TABLE_INITIAL_VALUE")
	public static GMMap InitialValues(GMMap iMap){

		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt1 = null;
		ResultSet rSet = null;
		ResultSet rSet1 = null;

		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call  PKG_RC_ADC.RC_QRY4155_Musteri_Kanal}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			BigDecimal musteriNo ;
			musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			if(musteriNo == null)
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Musteri No");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}	
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "MUSTERI_KANAL_KISIT";
			int row = 0;
			while (rSet.next()) {

				oMap.put(tableName, row, "KANAL_KOD", rSet.getString("KOD"));
				oMap.put(tableName, row, "KANAL", rSet.getString("ACIKLAMA"));
		  
			    stmt1 = conn.prepareCall("{? = call  PKG_RC_ADC.RC_QRY4155_Musteri_Kanal_Kisit(?,?)}");	
				int j = 1;	
				stmt1.registerOutParameter(j++, -10); //ref cursor
				stmt1.setString(j++, iMap.getString("MUSTERI_NO"));
			    stmt1.setString(j++, rSet.getString("KOD"));
				stmt1.execute();
				rSet1 = (ResultSet)stmt1.getObject(1);
				if ( rSet1.next()) oMap.put(tableName, row, "KISITLI_MI", true);
				else  oMap.put(tableName, row, "KISITLI_MI", false);	
				row++;
			}
		    return oMap;
		} catch (SQLException e) {
		  throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(conn);
		}
	
    }
	
	@GraymoundService("BNSPR_TRN4155_SAVE")
	public static GMMap saveTRN4155(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUSTERI_KANAL_KISIT";
			
			List<?> list = (List<?>) iMap.get(tableName);
			for(int i=0; i<list.size();i++) {
				GnlMusteriKanalKisitPrTxId id = new GnlMusteriKanalKisitPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				id.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				GnlMusteriKanalKisitPrTx gnlMusteriKanalKisitPrTx = new GnlMusteriKanalKisitPrTx();
				gnlMusteriKanalKisitPrTx.setId(id);
				gnlMusteriKanalKisitPrTx.setFKisit(iMap.getBoolean(tableName, i, "KISITLI_MI") ? "E" : "H");
				session.saveOrUpdate(gnlMusteriKanalKisitPrTx);
			}
			
			session.flush();

			iMap.put("TRX_NAME", "4155");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
	        catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN4155_GET_INFO")
		public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(GnlMusteriKanalKisitPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        String tableName = "MUSTERI_KANAL_KISIT";
			int row = 0;
			GMMap oMap = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlMusteriKanalKisitPrTx gnlMusteriKanalKisitPrTx = (GnlMusteriKanalKisitPrTx) iterator.next();
			    oMap.put(tableName, row, "KANAL_KOD", gnlMusteriKanalKisitPrTx.getId().getKanalKod());
			    oMap.put(tableName, row, "KANAL", LovHelper.diLov(gnlMusteriKanalKisitPrTx.getId().getKanalKod(), "4155/LOV_KANAL", "ACIKLAMA")); 
				oMap.put(tableName, row, "KISITLI_MI","E". equals(gnlMusteriKanalKisitPrTx.getFKisit()));
				oMap.put("TRX_NO", gnlMusteriKanalKisitPrTx.getId().getTxNo());
				oMap.put("MUSTERI_NO", gnlMusteriKanalKisitPrTx.getId().getMusteriNo());
			    oMap.put("DI_MUSTERI_UNVAN", LovHelper.diLov(gnlMusteriKanalKisitPrTx.getId().getMusteriNo(), "4155/LOV_MUSTERI_NO", "MUSTERI_ADI")); 

               
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
				
}