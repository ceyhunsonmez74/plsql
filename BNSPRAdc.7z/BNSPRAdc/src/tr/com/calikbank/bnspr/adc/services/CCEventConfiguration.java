package tr.com.calikbank.bnspr.adc.services;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;


/**
 *
 *	@author		Olcay Yuce
 *	@version 	1.0
 *
 */

public class CCEventConfiguration {

	
	private static Map<String,CCFraudProcessInfo> ccProcessMap  = new HashMap<String,CCFraudProcessInfo>();
	
	static {
		ccProcessMap.put("IVR_CHPASS", new CCFraudProcessInfo("PASSWORD", "", "", "RESULT", "RESULT"));
		ccProcessMap.put("CCCHCRDPWD", new CCFraudProcessInfo("PASSWORD", "", "", "RESPONSE", "RESPONSE_DATA"));
		ccProcessMap.put("CCTRIVRCRD", new CCFraudProcessInfo("CARD_PWD_TRANSFER", "", "", "", ""));
		ccProcessMap.put("SASR_CCBT", new CCFraudProcessInfo("PASSWORD", "", "", "RESULT", "ERROR"));
		ccProcessMap.put("CCVALIDOTP", new CCFraudProcessInfo("CHECK_OTP", "", "", "RESPONSE", "RESPONSE_DATA"));
		ccProcessMap.put("SECAPPROVE", new CCFraudProcessInfo("SEC_Q1_VALIDATE", "", "", "", ""));
		ccProcessMap.put("SECENTER", new CCFraudProcessInfo("SEC_Q2_VALIDATE", "", "", "", ""));
		ccProcessMap.put("SECPARAM", new CCFraudProcessInfo("SEC_Q3_VALIDATE", "", "", "", ""));
		ccProcessMap.put("SECLEVSET", new CCFraudProcessInfo("SEC_LEVEL_SET", "", "", "", ""));
		ccProcessMap.put("EXCRATES", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_GET_CURRENCY_RATES_PROCESS
		ccProcessMap.put("IVR_EXCB", new CCFraudProcessInfo("", "", "", "RESULT", ""));	//GM_IBANK_IVR_CURRENCY_EXCHANGE_PROCESS
		ccProcessMap.put("IVR_EXCS", new CCFraudProcessInfo("", "", "", "RESULT", ""));	//GM_IBANK_IVR_CURRENCY_EXCHANGE_PROCESS
		ccProcessMap.put("IVR_EXC", new CCFraudProcessInfo("", "", "", "RESULT", ""));	//GM_IBANK_IVR_CURRENCY_EXCHANGE_PROCESS
		ccProcessMap.put("IVRFNDBUY", new CCFraudProcessInfo("", "", "", "RESULT", ""));	//IVR_FUND_BUY_PROCESS
		ccProcessMap.put("IVRFNDBCK", new CCFraudProcessInfo("", "", "", "RESULT", ""));	//IVR_FUND_BUY_CHECK_PROCESS
		ccProcessMap.put("IVRFNDINFO", new CCFraudProcessInfo("", "", "", "", ""));	//IVR_FUND_INFO_PROCESS
		ccProcessMap.put("IVRFNDTIME", new CCFraudProcessInfo("", "", "", "", ""));	//IVR_FUND_TIME_PROCESS
		ccProcessMap.put("IVRFNDINF", new CCFraudProcessInfo("", "", "", "", ""));	//IVR_FUND_ACCOUNT_LIST_PROCESS
		ccProcessMap.put("IVRFNDSEL", new CCFraudProcessInfo("", "", "", "RESULT", ""));	//IVR_FUND_SELL_PROCESS
		ccProcessMap.put("IVRFNDSCK", new CCFraudProcessInfo("", "", "", "RESULT", ""));	//IVR_FUND_SELL_CHECK_PROCESS
		ccProcessMap.put("IVR_TRNINT", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_TRANSFER_BETWEEN_ACCOUNTS_PROCESS
		ccProcessMap.put("CRDT_INFO", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_CREDIT_INFO_PROCESS
		ccProcessMap.put("CRDT_RATES", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_GET_CREDIT_INTEREST_RATES_PROCESS
		ccProcessMap.put("CRDT_QRY", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_GET_CREDIT_QUERY_PROCESS
		ccProcessMap.put("CRDT_PYMNT", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_GET_CREDIT_PAYMENT_PROCESS
		ccProcessMap.put("CRDT_TYP", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_GET_CREDIT_TYPES_PROCESS
		ccProcessMap.put("CRDT_LIMS", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_GET_CREDIT_MIN_MAX_PROCESS
		ccProcessMap.put("IVR_BLKUSR", new CCFraudProcessInfo("", "", "", "RESULT", ""));	//GM_IBANK_IVR_BLOCK_USER_CHANNEL_PROCESS
		ccProcessMap.put("USR_STAT", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_USER_STATUS_PROCESS
		ccProcessMap.put("LST_ACC", new CCFraudProcessInfo("", "", "", "", ""));	//GM_IBANK_IVR_LIST_CUSTOMER_ACCOUNTS_PROCESS
		ccProcessMap.put("CCALTSCRT", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_CREATE_ALTERNATE_SECURITY_QUESTION
		ccProcessMap.put("CCALTSQSV", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_MAN_SECURITY_QUESTIONS_MATCH_SAVE
		ccProcessMap.put("CCCALLOUT", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CALPOLQRY", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_OUTBOUND_CALL_POOL_QUERY
		ccProcessMap.put("RSCCONFCHK", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_GET_CUSTOMER_RISC_CONFIRMATION_STATUS
		ccProcessMap.put("QRYDLRMEMO", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_DEALER_MEMO_GET_ALL_MEMO
		ccProcessMap.put("PWRNDLRLST", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_DEALER_WARNING_GET_CUSTOMER_PASSIVE_WARNINGS
		ccProcessMap.put("WARNDLRLST", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_DEALER_WARNING_GET_CUSTOMER_WARNINGS
		ccProcessMap.put("SUCIVRPARA", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_PROCESS_SAVE_IVR_SEC_LEVEL_PARAMETER
		ccProcessMap.put("CCINCSEC", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_SECURITY_QUESTION_INC_FAIL_COUNT
		ccProcessMap.put("CCHOLD", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CCACCRSTRC", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_LIMIT_ACCOUNTS_EXECUTE_PROCESS
		ccProcessMap.put("CBACKDIAL", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_CALLBACK_DIAL
		ccProcessMap.put("CALLBACK", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CALLBSUCC", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CBFAIL", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CBACKCON", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CBACKKAPAT", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CCDBTSRCH", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_DEBITX_CUSTOMER_SEARCH
		ccProcessMap.put("CCRESUME", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CALHISTORY", new CCFraudProcessInfo("", "", "", "", ""));	//XXX BNSPR_EXT_DIALER_GET_CALL_HISTORY
		ccProcessMap.put("SECCATSAVE", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_SECURITY_CATEGORY_SAVE
		ccProcessMap.put("SECCONTROL", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_CONTROL_SECURITY_LEVEL
		ccProcessMap.put("SECCREATE", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_CREATE_SECURITY_QUESTION_PAGE
		ccProcessMap.put("SECBLOCK", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_BLOCK_CUSTOMER_IVR_CHANNEL
		ccProcessMap.put("SECEXTR", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_CREATE_EXT_SECURITY_QUESTION_PAGE
		ccProcessMap.put("CCSECTRIVR", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_TRANSFER_TO_IVR
		ccProcessMap.put("CCSECCBCK", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CCVALIDCB", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_VALID_CALLBACK
		ccProcessMap.put("SECQUESAVE", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_MAN_SECURITY_QUESTION_SAVE
		ccProcessMap.put("SECQUELOG", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_SECURITY_QUESTIONS_GET_QUESTION_LOG
		ccProcessMap.put("SECQUEREP", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_SECURITY_QUESTIONS_REPORT
		ccProcessMap.put("IVRTRANS", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CHANNELNFO", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_CUSTOMER_CHANNEL_INFO
		ccProcessMap.put("CALLRPHONE", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_LOG_CUSTOMER_INFO
		ccProcessMap.put("CODESAVE", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_CODE_SAVE_CODE
		ccProcessMap.put("CODREST", new CCFraudProcessInfo("", "", "", "RESPONSE_DATA", ""));	//CNSPR_MAN_CODE_UPDATE_ACTION_CODE_SAVE_ACTION_PROFILES
		ccProcessMap.put("CODEDEL", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_MAN_CODE_DELETE_CODE
		ccProcessMap.put("USERADD", new CCFraudProcessInfo("", "", "", "RESPONSE_DATA", ""));	//CNSPR_MAN_USER_ADD_USER
		ccProcessMap.put("USERINFO", new CCFraudProcessInfo("", "", "", "RESPONSE_DATA", ""));	//CNSPR_MAN_USER_USER_INFO
		ccProcessMap.put("LOGWATCH", new CCFraudProcessInfo("", "", "", "", ""));	//GET_PROCESS_LOG
		ccProcessMap.put("MEMOACTION", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_MEMO_SAVE_MEMO_ACTION
		ccProcessMap.put("MEMODETAIL", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_MEMO_GET_MEMO_ACTIONS
		ccProcessMap.put("MEMORPRTOT", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_MAN_MEMO_REPORT_NOTICE
		ccProcessMap.put("MEMO_GETIR", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_MEMO_INITIALIZE
		ccProcessMap.put("MEMOREPORT", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_MAN_MEMO_REPORT
		ccProcessMap.put("QUERYMEMO", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_MEMO_GET_ALL_MEMO
		ccProcessMap.put("MI4B_CRMEM", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//MI4BIZ_CREATE_MEMO_PROCESS
		ccProcessMap.put("MI4B_CSRCH", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//MI4BIZ_SEARCH_CUSTOMER_PROCESS
		ccProcessMap.put("MI4B_CDET", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//MI4BIZ_CUSTOMER_DETAIL_PROCESS
		ccProcessMap.put("MI4B_INTG", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_GET_MI4BIZ_INTEGRATION
		ccProcessMap.put("CUSTSEARCH", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_CUSTOMER_SEARCH
		ccProcessMap.put("AGENTCUST", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_GET_CUSTOMER_INFO
		ccProcessMap.put("CLEARSESS", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_CLEAN_AGENT_SESSION
		ccProcessMap.put("AGENTMERGE", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_MERGE_CUSTOMER_INFO
		ccProcessMap.put("CCEXTINFO", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_GET_CUSTOMER_EXT_INFO
		ccProcessMap.put("AGTCUSTCRD", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_GET_CUSTOMER_CARD_LIST		
		ccProcessMap.put("AGNTSTATU", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("WARNNON", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_WARNING_GET_NONAPPROVED_WARNINGS
		ccProcessMap.put("OUTBNDCALL", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_OUTBOUND_CALL_EMPTY_SERVICE
		ccProcessMap.put("OUTBNDRSLT", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_OUTBOUND_CALL_EMPTY_SERVICE
		ccProcessMap.put("PARENT_KOD", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_PARENT_CODE_GENERATE_CODE
		ccProcessMap.put("PWARNLIST", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_WARNING_GET_CUSTOMER_PASSIVE_WARNINGS
		ccProcessMap.put("CCROLMRST", new CCFraudProcessInfo("", "", "", "RESPONSE", ""));	//CNSPR_MAN_PROCESS_SAVE_MENU_RESTRICTION
		ccProcessMap.put("SMSLOGWTCH", new CCFraudProcessInfo("", "", "", "", ""));	//XXX GET_ADC_OTP_LOG
		ccProcessMap.put("UNMUTE", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("MUTE", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CCINSPLTC", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_INSURANCE_POLICY_LIST_BY_TCKN
		ccProcessMap.put("CCINSPLVKN", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_INSURANCE_POLICY_LIST_BY_VKN
		ccProcessMap.put("SASR_GCNCN", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR"));	//SMART_TOBANK_WS_GET_CUSTOMER_NO_BY_CARD_NO_PROCESS
		ccProcessMap.put("SASR_GCBCN", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR"));	//SMART_TOBANK_WS_GET_CARD_BY_CARD_NO_PROCESS
		ccProcessMap.put("SASR_CAPC", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR"));	//SMART_TOBANK_WS_CARD_PASSWORD_CHECK_PROCESS
		ccProcessMap.put("SASR_LMTC", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR"));	//SMART_TOBANK_WS_LOAD_MONEY_TO_CARD_PROCESS
		ccProcessMap.put("SASR_GCBCU", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR"));	//SMART_TOBANK_WS_GET_CARDS_BY_CUSTOMER_NO_PROCESS
		ccProcessMap.put("SASR_GASTR", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR_MESSAGE"));	//SMART_APPSERVER_WS_GET_APPLICATION_START_PROCESS
		ccProcessMap.put("SASR_SAPPF", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR_MESSAGE"));	//SMART_APPSERVER_WS_SET_APPLICATION_FINISH_PROCESS
		ccProcessMap.put("SASR_CSPWS", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR"));	//SMART_TOBANK_WS_CARD_SEND_PIN_WITH_SMS_PROCESS
		ccProcessMap.put("SASR_GATCN", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR_MESSAGE"));	//SMART_APPSERVER_WS_GET_ALL_APPLICATIONS_BY_TCNO_PROCESS
		ccProcessMap.put("SASR_UAMNO", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR_MESSAGE"));	//SMART_APPSERVER_WS_UPDATE_APPLICATION_MOBILE_NO_PROCESS
		ccProcessMap.put("SASR_GPRD", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR_MESSAGE"));	//SMART_APPSERVER_WS_GET_PRODUCTS_PROCESS
		ccProcessMap.put("SASR_PFAPP", new CCFraudProcessInfo("", "", "", "RESULT", "ERROR_MESSAGE"));	//SMART_APPSERVER_WS_PAYMENT_FOR_APPLICATION_PROCESS
		ccProcessMap.put("LASTTENCAL", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_GET_CUSTOMER_LAST_TEN_CALL
		ccProcessMap.put("LASTTENPRO", new CCFraudProcessInfo("", "", "", "RESPONSE", ""));	//CNSPR_AGENT_GET_CUSTOMER_LAST_TEN_PROCESS
		ccProcessMap.put("ATIUPD_PAS", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_TEL_INT_UPDATE_PASSWORD_LOG
		ccProcessMap.put("CLOSEMEM", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_NEW_ACTION_SAVE
		ccProcessMap.put("REPORTMEMO", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_MAN_OPEN_MEMO_REPORT
		ccProcessMap.put("TRANSPHONE", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_TRANSFER_PHONE_NUMBERS_ADD_AND_REFRESH
		ccProcessMap.put("TRANPHNDEL", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_TRANSFER_PHONE_NUMBERS_DELETE
		ccProcessMap.put("WARNDETAIL", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("WARNCATADD", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_WARNING_SAVE_WARNING_CATEGORY
		ccProcessMap.put("WARNCATDEL", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_WARNING_DELETE_WARNING_CATEGORY
		ccProcessMap.put("WARNLIST", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_WARNING_GET_CUSTOMER_WARNINGS
		ccProcessMap.put("WARNAPROVE", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_WARNING_APPROVE_WARNINGS
		ccProcessMap.put("PASSWARN", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_WARNING_DO_PASSIVE_WARNING
		ccProcessMap.put("WARNREPORT", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_WARNING_SEARCH_WARNING
		ccProcessMap.put("DELETEWARN", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_WARNING_DELETE_WARNING
		ccProcessMap.put("WCHATHOLD", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("WCHATRSM", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("WEBCHCON", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("WEBCHAT", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("WCHATCLOSE", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("WEBCUSTCHK", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_GET_CUSTOMER_WEB_BHS_STATUS
		ccProcessMap.put("NEWDLRMEMO", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_DEALER_MEMO_SAVE_MEMO
		ccProcessMap.put("NEWDLRWARN", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_DEALER_WARNING_SAVE_WARNING
		ccProcessMap.put("NEWMEMO", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_MEMO_SAVE_MEMO
		ccProcessMap.put("NEWWARN", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_WARNING_SAVE_WARNING
		ccProcessMap.put("CCCALLCONN", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CCCALLDISC", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CALLHIST", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_GET_CUSTOMER_LAST_TEN_AGENT_CALL
		ccProcessMap.put("CALLTRANS", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("CCCNSLT", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("MEMO_ADD_M", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_AGENT_MEMO_UPLOAD
		ccProcessMap.put("MEMO_ADD_S", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_MEMO_SAVE
		ccProcessMap.put("WARN_ADD_M", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_WARNING_UPLOAD
		ccProcessMap.put("WARN_ADD_S", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_MAN_WARNING_SAVE
		ccProcessMap.put("PRDDETAIL", new CCFraudProcessInfo("", "", "", "", ""));	//CNPSR_PROCESS_EXECUTE_JUST_FOR_LOG
		ccProcessMap.put("PRODSRCH", new CCFraudProcessInfo("", "", "", "RESPONSE", "RESPONSE_DATA"));	//CNSPR_AGENT_CUSTOMER_PRODUCTS_SEARCH
		ccProcessMap.put("PROCREST", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_SAVE_PROCESS_RESTRICTION
		ccProcessMap.put("PROC_LOGOB", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_PROCESS_GET_PROCESS_LOG
		ccProcessMap.put("SCRIPTSAVE", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_PROCESS_SAVE_SCRIPT
		ccProcessMap.put("SCRIPTUPDA", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_PROCESS_UPDATE_SCRIPT
		ccProcessMap.put("SCRIPT_DEL", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_PROCESS_DELETE_SCRIPT
		ccProcessMap.put("PROCESSRPT", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_PROCESS_GET_PROCESS_REPORT
		ccProcessMap.put("PROCESSSEC", new CCFraudProcessInfo("", "", "", "", ""));	//CNSPR_MAN_PROCESS_SAVE_PROCESS
	
	}
	
	private static class CCFraudProcessInfo implements Serializable {
		
		String updateFieldName;
		String processLogOldValueKey;
		String processLogNewValueKey;
		String processLogSuccessKey;
		String processLogFailReasonKey;
		
		public CCFraudProcessInfo(String updateFieldName,
				String processLogOldValueKey, String processLogNewValueKey,
				String processLogSuccessKey, String processLogFailReasonKey) {
			super();
			this.updateFieldName = updateFieldName;
			this.processLogOldValueKey = processLogOldValueKey;
			this.processLogNewValueKey = processLogNewValueKey;
			this.processLogSuccessKey = processLogSuccessKey;
			this.processLogFailReasonKey = processLogFailReasonKey;
		}
		
		
	}
	
	protected static String getUpdateFieldName(String processCode) {
		return ccProcessMap.get(processCode).updateFieldName;
	}

	protected static String getProcessLogOldValueKey(String processCode) {
		return ccProcessMap.get(processCode).processLogOldValueKey;
	}

	protected static String getProcessLogNewValueKey(String processCode) {
		return ccProcessMap.get(processCode).processLogNewValueKey;
	}

	protected static String getProcessLogSuccessKey(String processCode) {
		return ccProcessMap.get(processCode).processLogSuccessKey;
	}

	protected static String getProcessLogFailReasonKey(String processCode) {
		return ccProcessMap.get(processCode).processLogFailReasonKey;
	}	
	
	protected static boolean isCCEvent(String processcode) {
		return ccProcessMap.containsKey(processcode);
	}
	
	
}


