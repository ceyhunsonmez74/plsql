package tr.com.calikbank.bnspr.adc.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.aktifbank.bnspr.dao.GnlBlokeAltNedenKodTx;
import tr.com.aktifbank.bnspr.dao.GnlBlokeAltNedenKodTxId;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcTRN4192Services {
	
	@GraymoundService("BNSPR_TRN4192_SAVE")
    public static Map<?, ?> saveAccounts(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        String tableName = "TBL_GNLBLOKEALTNEDENKOD_PR";
      
            try{
                
                conn = DALUtil.getGMConnection();
                Session session = DAOSession.getSession("BNSPRDal");
                
                ArrayList<?> list = (ArrayList<?>) session.createCriteria(GnlBlokeAltNedenKodTx.class).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).list();
                for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                    GnlBlokeAltNedenKodTx gnlBlokeAltNedenKodTx = (GnlBlokeAltNedenKodTx) iterator.next();
                    session.delete(gnlBlokeAltNedenKodTx);
                }
                session.flush();
                
                int rowCount = iMap.getSize(tableName);
                for (int i = 0; i < rowCount; i++){
                   
                	GnlBlokeAltNedenKodTx gnlBlokeAltNedenKodTx = new GnlBlokeAltNedenKodTx();
                	GnlBlokeAltNedenKodTxId id = new GnlBlokeAltNedenKodTxId();
                    
                    if (!(("S").equals(iMap.getString(tableName, i, "G_D_S"))&&iMap.getString(tableName, i,"KOD")==null))
                    {
                 
                    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                	id.setKod(iMap.getString(tableName, i, "KOD"));
                	id.setBlokeNedenKod(iMap.getString(tableName, i, "BLOKE_NEDEN"));
                	gnlBlokeAltNedenKodTx.setId(id);
                	
                	gnlBlokeAltNedenKodTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
                    
                	String aciklama = DALUtil.getResult("select aciklama from GNL_BLOKE_ALT_NEDEN_KOD_PR where kod = '"+iMap.getString(tableName, i, "KOD")+"' and bloke_neden = '"+iMap.getString(tableName, i, "BLOKE_NEDEN")+"'");
                	
                    if(("S").equals(iMap.getString(tableName,i,"G_D_S")))
                    	gnlBlokeAltNedenKodTx.setGDS("S");
                    else if (("G").equals(iMap.getString(tableName, i, "G_D_S")))
                    	gnlBlokeAltNedenKodTx.setGDS("G");
                   
                    else if ((!(aciklama.equals(iMap.getString(tableName, i, "ACIKLAMA")))&&!((aciklama==null)||("").equals(aciklama))))
                    {
                    	gnlBlokeAltNedenKodTx.setGDS("D");
                    }
                    else gnlBlokeAltNedenKodTx.setGDS("");
                    
                  
                    session.saveOrUpdate(gnlBlokeAltNedenKodTx);
                }
                }
            
                session.flush();
                
               iMap.put("TRX_NAME","4192");

              return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);    
                     
        } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } finally{
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
    }
	
            @GraymoundService("BNSPR_TRN4192_IS_RECORDS_UNIQUE")
            public static GMMap isRecordsUnique(GMMap iMap) {
                
                GMMap oMap = new GMMap();
                
                String tableName = "TBL_GNLBLOKEALTNEDENKOD_PR";
                int rowCount = iMap.getSize(tableName);
                
                for (int i = 0; i < rowCount; i++){

                    if (!(("S").equals(iMap.getString(tableName, i, "G_D_S"))&&iMap.getString(tableName, i,"KOD")==null))
                    {
                    for (int j = 0; j < rowCount; j++){
                     
                        if (iMap.getString(tableName , i , "BLOKE_NEDEN") == (null) || iMap.getString(tableName , i , "BLOKE_NEDEN").equals("")){
                            iMap.put("HATA_NO" , new BigDecimal(330));
                            iMap.put("P1" , "BLOKE_NEDEN");
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                        }
                        
                        
                        if (iMap.getString(tableName , i , "KOD") == (null) || iMap.getString(tableName , i , "KOD").equals("")){
                            iMap.put("HATA_NO" , new BigDecimal(330));
                            iMap.put("P1" , "BLOKE_ALT_NEDEN_KOD");
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                        }
                        
                        if (iMap.getString(tableName , i , "ACIKLAMA") == (null) || iMap.getString(tableName , i , "ACIKLAMA").equals("")){
                            iMap.put("HATA_NO" , new BigDecimal(330));
                            iMap.put("P1" , "ACIKLAMA");
                            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                        }
               
               
                      
                        if (i != j){
                            if (iMap.getString(tableName , i , "KOD").equals(iMap.getString(tableName , j , "KOD"))&&iMap.getString(tableName, i, "BLOKE_NEDEN").equals(iMap.getString(tableName, j, "BLOKE_NEDEN"))){
                                iMap.put("HATA_NO" , new BigDecimal(932));
                                GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                            }
                        }
                    }
                }
                } 
                return oMap;
            }
    

@GraymoundService("BNSPR_TRN4192_GET_BLOKE_NEDEN_LIST")
public static Map<?, ?> getYetkiList(GMMap iMap) {
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rSet = null;
    GMMap oMap = new GMMap();
    try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{? = call PKG_TRN4192.GET_BLOKE_ALT_NEDEN_LISTE}");
        int i = 1;
        
        stmt.registerOutParameter(i++, -10);
        stmt.execute();
        rSet = (ResultSet) stmt.getObject(1);
        String tableName1 = "TBL_GNLBLOKEALTNEDENKOD_PR";
        for (int row = 0; rSet.next(); row++) {
            oMap.put(tableName1, row, "KOD", rSet.getString("KOD"));
            oMap.put(tableName1, row, "BLOKE_NEDEN", rSet.getString("BLOKE_NEDEN"));
            oMap.put(tableName1, row, "ACIKLAMA", rSet.getString("ACIKLAMA"));
            oMap.put(tableName1, row, "G_D_S", rSet.getString("G_D_S"));
            oMap.put(tableName1, row, "SIL", rSet.getString("SIL"));
        }
            
        return oMap;
    }
        catch (Exception e) {
            
            throw ExceptionHandler.convertException(e);
        
        } finally {
            
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        
        }
    }
@GraymoundService("BNSPR_TRN4192_GET_INFO")
public static GMMap getTransactionNo(GMMap iMap) {
    
    Connection conn = null;
    
    try{
        
    GMMap oMap = new GMMap();
    conn = DALUtil.getGMConnection();
    Session session = DAOSession.getSession("BNSPRDal");
    String tableName    = "TBL_GNLBLOKEALTNEDENKOD_PR";
    String colorTableName = "TBL_COLOR";
    

    List<?> list = (List<?>) session.createCriteria(GnlBlokeAltNedenKodTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
        .list();
    
     for (int row = 0; row < list.size(); row++){
    	 GnlBlokeAltNedenKodTx gnlBlokeAltNedenKodTx = (GnlBlokeAltNedenKodTx) list.get(row);
       
        oMap.put("TRX_NO", gnlBlokeAltNedenKodTx.getId().getTxNo());
        oMap.put(tableName, row, "KOD", gnlBlokeAltNedenKodTx.getId().getKod());
        oMap.put(tableName, row, "BLOKE_NEDEN", gnlBlokeAltNedenKodTx.getId().getBlokeNedenKod());
        oMap.put(tableName, row, "ACIKLAMA", gnlBlokeAltNedenKodTx.getAciklama());
        oMap.put(tableName, row, "SIL", ("S").equals(gnlBlokeAltNedenKodTx.getGDS()) ? true : false);
    
      if ("G".equals(gnlBlokeAltNedenKodTx.getGDS()) ) {
         
          oMap.put(colorTableName, row, "KOD",getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "BLOKE_NEDEN",getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "ACIKLAMA", getTableCellColorData(Color.GREEN));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.GREEN));
          
      }
      else if ("S".equals(gnlBlokeAltNedenKodTx.getGDS())) {
          
          
          oMap.put(colorTableName, row, "KOD",getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "BLOKE_NEDEN",getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "ACIKLAMA", getTableCellColorData(Color.RED));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.RED));
      }
      
      else if ("D".equals(gnlBlokeAltNedenKodTx.getGDS())) {
          
          
          oMap.put(colorTableName, row, "KOD",getTableCellColorData(Color.BLUE));
          oMap.put(colorTableName, row, "BLOKE_NEDEN",getTableCellColorData(Color.BLUE));
          oMap.put(colorTableName, row, "ACIKLAMA", getTableCellColorData(Color.BLUE));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.BLUE));
      }
      else
      {
          
          oMap.put(colorTableName, row, "KOD",getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "BLOKE_NEDEN",getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "ACIKLAMA", getTableCellColorData(Color.WHITE));
          oMap.put(colorTableName, row, "SIL", getTableCellColorData(Color.WHITE));
      }
    
    }
        
    return oMap;
        
    }catch (Exception e){
        throw ExceptionHandler.convertException(e);
    }finally{
        
        GMServerDatasource.close(conn);
    }
    
}
 private static GMMap getTableCellColorData(Color backgroundColor){
        GMMap oMap = new GMMap();
        oMap.put("setBackground", backgroundColor);
        return oMap;
    }
}
