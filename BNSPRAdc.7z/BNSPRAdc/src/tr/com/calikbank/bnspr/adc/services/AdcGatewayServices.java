package tr.com.calikbank.bnspr.adc.services;

import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.obss.adc.core.util.ADCParameters;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcGatewayServices {

	private static Logger logger = Logger.getLogger(AdcGatewayServices.class);
	
	/**
	 * Description : TBA
	 * 
	 * @param iMap GMMap
	 * 		{...}
	 * @return GMMap
	 *      {...}
	 */
	@GraymoundService("ADC_SERVICE_GATEWAY")
	public static GMMap serviceGateway(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			long sTime = System.currentTimeMillis();
			int timeout = ADCParameters.getInt("ADC_SERVICE_TIMEOUT");
			int init_diff = (iMap.get("GP_INIT_TIME_DIFF") != null) ? iMap.getInt("GP_INIT_TIME_DIFF") : 0;
			int tolerance = 5;
			String channelName = iMap.getString("GP_CHANNEL", ADCSession.getString("CHANNEL"));
			String serviceName = channelName + "_" + (String) iMap.remove("GP_SERVICE_NAME");
			
			// Service Call
			oMap = GMServiceExecuter.call(serviceName, iMap);
			long eTime = System.currentTimeMillis();
			
			// Case: Timeout/Rollback
			if(iMap.getBoolean("GP_SERVICE_TIMEOUT") && (eTime - sTime) / 1000L >= timeout - init_diff - tolerance) {
				logger.error("ADC_SERVICE_GATEWAY: " + serviceName + " timed out, transaction will be rolledback.");
				throw new GMRuntimeException(0, "Talep zaman a��m�na u�ram��t�r.", true);
			}
			
		} catch (Exception e) {
			
			logger.error("ADC_SERVICE_GATEWAY err:" + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
}
