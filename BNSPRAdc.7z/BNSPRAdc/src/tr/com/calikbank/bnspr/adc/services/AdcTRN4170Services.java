package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.AdkSifreParolaDegistirTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4170Services {
    
    private static class RemovableBlocks {
        
        public static RemovableBlocks instance = new RemovableBlocks();
        
        private final Configurator configurator;
        private final HashMap<String, HashSet<String>> removableBlocks;
        private String property;
        
        private RemovableBlocks() {
            configurator = Configurator.createConfiguratorFromProperties("removableChannelBlocks.properties");
            removableBlocks = new HashMap<String, HashSet<String>>();
            
            read();
        }
        
        private void read() {
            String property = configurator.getProperty("channelsAndBlocks");
            if (!property.equals(this.property)) {
                setRemovableBlocks(property);
                this.property = property;
            }
        }
        
        private void setRemovableBlocks(String property) {
            removableBlocks.clear();

            // channel1#block1-block2&channel2#block1-block2-...
            String[] channelsAndBlocks = property.split("&");
            
            for (int i = 0; i < channelsAndBlocks.length; i++) {
                String[] channelAndBlocks = channelsAndBlocks[i].split("#");
                String channel = channelAndBlocks[0];
                String[] blocks = channelAndBlocks[1].split("-");

                HashSet<String> blockSet = removableBlocks.get(channel);
                if (blockSet == null) {
                    blockSet = new HashSet<String>();
                }
                
                for (int j = 0; j < blocks.length; j++) {
                    blockSet.add(blocks[j]);
                }
                
                removableBlocks.put(channel, blockSet);
            }
        }
        
        synchronized public HashMap<String, HashSet<String>> getBlocks() {
            read();
            
            return removableBlocks;
        }

    }
    
	
	@GraymoundService("BNSPR_TRN4170_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
		    GMServiceExecuter.executeNT("BNSPR_TRN4170_REMOVE_BLOCKS", iMap);
		    
			Session session = DAOSession.getSession("BNSPRDal");
			
			AdkSifreParolaDegistirTx adkSifreParolaDegistirTx = new AdkSifreParolaDegistirTx();
			
		
			adkSifreParolaDegistirTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			adkSifreParolaDegistirTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			adkSifreParolaDegistirTx.setInternet(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("INTERNET")));
			adkSifreParolaDegistirTx.setCagriMerkezi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("CAGRI_MERKEZI")));
			adkSifreParolaDegistirTx.setInternetNg(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("INTERNET_NG")));
			adkSifreParolaDegistirTx.setPassoligNg(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("PASSOLIG_NG")));
		
			session.saveOrUpdate(adkSifreParolaDegistirTx);
			session.flush();
			

			iMap.put("TRX_NAME", "4170");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}

		catch (Exception e) {
			System.out.println(e);
			throw ExceptionHandler.convertException(e);
		}

	}	
	
	@GraymoundService("BNSPR_TRN4170_REMOVE_BLOCKS")
	public static GMMap removeBlocks(GMMap iMap) {
	    GMMap blockMap = GMServiceExecuter.call("BNSPR_TRN4131_GET_KANAL_BLOKE", iMap);
	    int size = blockMap.getSize("BLOKE_BILGI");
	    
	    for (int i = 0; i < size; i++) {
	        String channelCode = blockMap.getString("BLOKE_BILGI", i, "KOD");
	        String blockCode = blockMap.getString("BLOKE_BILGI", i, "BLOKE_NEDENI");
	        
	        if (isRemovable(channelCode, blockCode)) {
	            GMMap sMap = new GMMap();
	            
	            sMap.put("KANAL_LIST", 0, "SEC", true);
	            sMap.put("KANAL_LIST", 0, "KANAL_KOD", channelCode);
	            sMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO"));
	            sMap.put("BLOKE_NEDENI", blockCode);
	            sMap.put("BLOKE_ALT_NEDENI", blockMap.getString("BLOKE_BILGI", i, "BLOKE_ALT_NEDENI"));
	            sMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
	            sMap.put("DURUM_KODU", "C");
	            sMap.put("BLOKE_ID", blockMap.getString("BLOKE_BILGI", i, "BLOKE_ID"));
	            sMap.put("BLOKE_COZME_ACIKLAMA", iMap.getString("BLOKE_COZME_ACIKLAMA", "4170 otomatik bloke ��zme"));

	            GMServiceExecuter.call("BNSPR_TRN4131_SAVE_BLOKE_KOYMA", sMap);
	        }
        }
	    
	    return iMap;
    }

    private static boolean isRemovable(String channelCode, String blockCode) {
        HashMap<String, HashSet<String>> removableBlocks = RemovableBlocks.instance.getBlocks();
        
        return removableBlocks.containsKey(channelCode)
                && removableBlocks.get(channelCode).contains(blockCode);
    }

    @GraymoundService("BNSPR_TRN4170_GET_INFO")
	public static Map<?, ?> trn2801GetInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			AdkSifreParolaDegistirTx adkSifreParolaDegistirTx = (AdkSifreParolaDegistirTx)session.createCriteria(AdkSifreParolaDegistirTx.class)
													.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
													.uniqueResult();
			if(adkSifreParolaDegistirTx == null) {
				adkSifreParolaDegistirTx = new AdkSifreParolaDegistirTx();
			}
			
			oMap.put("TRX_NO"			, adkSifreParolaDegistirTx.getTxNo());
			oMap.put("MUSTERI_NO"				, adkSifreParolaDegistirTx.getMusteriNo());
			oMap.put("INTERNET"		, GuimlUtil.convertToCheckBoxSelected(adkSifreParolaDegistirTx.getInternet()));
			oMap.put("CAGRI_MERKEZI"		,GuimlUtil.convertToCheckBoxSelected(adkSifreParolaDegistirTx.getCagriMerkezi()));
			oMap.put("INTERNET_NG"		,GuimlUtil.convertToCheckBoxSelected(adkSifreParolaDegistirTx.getInternetNg()));
			oMap.put("PASSOLIG_NG"		,GuimlUtil.convertToCheckBoxSelected(adkSifreParolaDegistirTx.getPassoligNg()));
			oMap.put("MUSTERI_ADI", LovHelper.diLov(adkSifreParolaDegistirTx.getMusteriNo(),"4170/LOV_MUSTERI" , "UNVAN"));
			oMap.put("TCKN",LovHelper.diLov(adkSifreParolaDegistirTx.getMusteriNo(), "4170/LOV_MUSTERI", "TC_KIMLIK_NO"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	   @GraymoundService("BNSPR_TRN4170_AFTER_APPROVAL")
	    public static GMMap afterApproval(GMMap iMap) {
	        try {
	        	
	            GMServiceExecuter.execute("BNSPR_TRN4170_PAROLA_PASSWORD", iMap);

	            return new GMMap();
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }
	    }
	

	@GraymoundService("BNSPR_TRN4170_PAROLA_PASSWORD")
	public static GMMap parolaPassword(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			 
	        Session session = DAOSession.getSession("BNSPRDal");
			
			AdkSifreParolaDegistirTx adkSifreParolaDegistirTx = (AdkSifreParolaDegistirTx) session.get(AdkSifreParolaDegistirTx.class, iMap.getBigDecimal("ISLEM_NO"));
			
			Boolean internetEH = GuimlUtil.convertToCheckBoxSelected(adkSifreParolaDegistirTx.getInternet());
			Boolean cagriMerkeziEH = GuimlUtil.convertToCheckBoxSelected(adkSifreParolaDegistirTx.getCagriMerkezi());
			Boolean internetNgEH = GuimlUtil.convertToCheckBoxSelected(adkSifreParolaDegistirTx.getInternetNg());
			Boolean passoligNgEH = GuimlUtil.convertToCheckBoxSelected(adkSifreParolaDegistirTx.getPassoligNg());
			BigDecimal musteriNo = adkSifreParolaDegistirTx.getMusteriNo();

			checkBlock(musteriNo, internetEH, cagriMerkeziEH, internetNgEH, passoligNgEH);
			
		      stmt = conn
				.prepareCall("{call PKG_TRN4131.otpTel_AnneKizlikSayadi(?,?,?,?)}");
		      
		      
		    stmt.setBigDecimal(1, musteriNo);  
			stmt.registerOutParameter(2, Types.VARCHAR); // TCKN
			stmt.registerOutParameter(3, Types.VARCHAR); // TEL NO
			stmt.registerOutParameter(4, Types.VARCHAR); // AKS
			stmt.execute();
			
			String userCode = stmt.getString(2);
			String phoneNumber = stmt.getString(3);
			
			if (internetEH) {
    			processInternet(conn, userCode, musteriNo, phoneNumber);
			}
				
			if (cagriMerkeziEH) {
				processCC(conn, musteriNo, userCode, phoneNumber);
			}
            
            if (internetNgEH) {
                processInternetNg(musteriNo, userCode, "INTNG");
            }

            if (passoligNgEH) {
                processInternetNg(musteriNo, userCode, "INTPSL");
            }

			return iMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

    private static void processCC(Connection conn,
            BigDecimal musteriNo, String userCode, String phoneNumber) {
        CallableStatement stmt = null;

        try {
            Integer pass = (new Random().nextInt(900000) + 100000);
            JGMPasswordField passwordField = new JGMPasswordField();
            passwordField.setText(pass.toString());
    
            GMMap servisMap = new GMMap();
            servisMap.put("USER_CODE", userCode);
            servisMap.put("CHANNEL_CODE", "IVR");
            servisMap.put("PASSWORD", passwordField.getPasswordWithAlgorithm("SHA-1"));
            servisMap.put("SERVICE_NAME",
            		"ADC_REMOTE_USER_UPDATE_PASSWORD");
    
            
            stmt = conn.prepareCall("{? = call PKG_TRN4131.Musteri_mesaj(?,?,?)}");
    
            stmt.registerOutParameter(1, Types.VARCHAR);
            //stmt3.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(2, musteriNo);
            stmt.setInt(3, pass );
            stmt.setBigDecimal(4, new BigDecimal(6));
            stmt.execute();		
            			
            String mesaj  = stmt.getString(1);						
            
            GMMap iMap1 = new GMMap();
            //iMap1.put("MESSAGE_NO", new BigDecimal("1357"));
            //iMap1.put("P1", pass);
            //iMap1.put("P5", new BigDecimal(6));
            //String mesaj = (String) GMServiceExecuter.execute(
            	//	"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap1).get(
            	//	"ERROR_MESSAGE");
            
    
            iMap1.put("CONTENT", mesaj);
            iMap1.put("MSISDN", phoneNumber);
            iMap1.put("SECURE_CONTENT", true);
            iMap1.put("FILTER", true);
            
            GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap);
            GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap1);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
        }
    }

    private static void processInternet(Connection conn,
            String userCode, BigDecimal musteriNo, String phoneNumber) {
        CallableStatement stmt = null;
        
        try {
            Integer pass = (new Random().nextInt(900000) + 100000);
            JGMPasswordField passwordField = new JGMPasswordField();
            passwordField.setText(pass.toString());
    
            GMMap servisMap = new GMMap();
            servisMap.put("USER_CODE", userCode);
            servisMap.put("CHANNEL_CODE", "INT");
            servisMap.put("PASSWORD", new String(passwordField
            		.getPassword()));
            servisMap.put("SERVICE_NAME",
            		"ADC_REMOTE_USER_UPDATE_PASSWORD");
            
            GMMap servisMapMBL = new GMMap();
            servisMapMBL.put("USER_CODE", userCode);
            servisMapMBL.put("CHANNEL_CODE", "MBL");
            servisMapMBL.put("PASSWORD", new String(passwordField.getPassword()));
            servisMapMBL.put("SERVICE_NAME", "ADC_REMOTE_USER_UPDATE_PASSWORD");
    
            stmt = conn.prepareCall("{? = call PKG_TRN4131.Musteri_mesaj(?,?,?)}");
    
            stmt.registerOutParameter(1, Types.VARCHAR);
            stmt.setBigDecimal(2, musteriNo);
            stmt.setInt(3, pass );
            stmt.setBigDecimal(4, new BigDecimal(4));
            stmt.execute();		
            			
            String mesaj  = stmt.getString(1);					
            
            GMMap iMap1 = new GMMap();
            //iMap1.put("MESSAGE_NO", new BigDecimal("1357"));
            //iMap1.put("P1", pass);
            //iMap1.put("P5", new BigDecimal(4));
            //String mesaj = (String) GMServiceExecuter.execute(
            	//	"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap1).get(
            	//	"ERROR_MESSAGE");
    
            iMap1.put("CONTENT", mesaj);
            iMap1.put("MSISDN", phoneNumber);
            iMap1.put("SECURE_CONTENT", true);
            iMap1.put("FILTER", true);
            
//            GMMap iMap2 = new GMMap();
//            
//            iMap2.put("UID", userCode);
//            iMap2.put("PASSWORD", pass.toString());
//            
//            GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_INT", iMap2);
            
            GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap);
            try{
            	GMServiceExecuter.call("ADK_CALL_SERVICE", servisMapMBL);
            }
            catch(GMRuntimeException e){
            	// bono talimat musterisi durumunda mobil kanalinda kayit olmayacagindan USRNOTCHNLAUTH hatasi gelecektir, bu durumda hata firlatmayalim, aksi halde atalim hatayi
            	if(!GMMessageFactory.getMessage("USRNOTCHNLAUTH", null).equals(e.getMessage()))  
            		throw e;
            }
            GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap1);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
        }
    }
    
    private static void processInternetNg(BigDecimal customerNo, String userCode, String channelCode) {
        GMMap serviceInMap = new GMMap();
        serviceInMap.put("CHANNEL_CODE", channelCode);
        serviceInMap.put("CUSTOMER_ID", customerNo);
        serviceInMap.put("USER_CODE", userCode);
        
        GMServiceExecuter.call("ADC_REMOTE_USER_UPDATE_PASSWORD", serviceInMap);
    }

    private static void checkBlock(BigDecimal customerNo, Boolean internet, Boolean callCenter,
            Boolean internetNg, Boolean passoligNg) {
        
    	GMMap iMap = new GMMap();
        iMap.put("MUSTERI_NO", customerNo);
        
        boolean block41 = false;
        boolean block42 = false;
        boolean block40 = false;
        boolean blockOther = false;
        GMMap blockMap = GMServiceExecuter.call("BNSPR_TRN4131_GET_KANAL_BLOKE", iMap);
        
        for(int i=0;i < blockMap.getSize("BLOKE_BILGI"); i++)
        {
    		if("41".equals(blockMap.getString("BLOKE_BILGI",i,"BLOKE_NEDENI")))	        	
    			block41 = true;
    		else if("42".equals(blockMap.getString("BLOKE_BILGI",i,"BLOKE_NEDENI")))
    			block42 = true;
    		else if("40".equals(blockMap.getString("BLOKE_BILGI",i,"BLOKE_NEDENI")))
    			block40 = true;
    		else
    			blockOther = true;
        }
	         
        if ((internet || internetNg || passoligNg) && blockMap.getBoolean("INTERNET")){
	        if(block41 && block42)
	        	throw new GMRuntimeException(0, "M��terinin N Kolay Mobil ve �nternet �ube kanallar� kullan�ma kapal�, kullanmak istiyorsa �nce bloke ��zme men�s�nden i�lem yap�lmal�d�r.");
	        else if(block40 && !blockOther){}
	        else if(block41 && !blockOther){}
	        else if(block42 && !blockOther){}
	        else
	        	throw new GMRuntimeException(0, "M��terinin kanal blokesi var");		        	
        }
        if (callCenter  && (blockMap.getBoolean("CAGRI_MERKEZI") || blockMap.getBoolean("IVR")))
            throw new GMRuntimeException(0, "M��terinin kanal blokesi var");

    }
}