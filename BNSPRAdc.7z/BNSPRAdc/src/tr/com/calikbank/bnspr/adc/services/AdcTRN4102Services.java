package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkStandCalisanTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4102Services {
	@GraymoundService("BNSPR_TRN4102_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			AdkStandCalisanTx adkStandCalisanTx = (AdkStandCalisanTx) session.get(AdkStandCalisanTx.class, iMap
					.getBigDecimal("TRX_NO"));
			if (adkStandCalisanTx == null)
				adkStandCalisanTx = new AdkStandCalisanTx();
	
			adkStandCalisanTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			adkStandCalisanTx.setKod(iMap.getString("KULLANICI_KODU"));
			adkStandCalisanTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			adkStandCalisanTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			adkStandCalisanTx.setIseBaslamaTar(iMap.getDate("ISE_BASLAMA_TAR"));
			adkStandCalisanTx.setPozisyonKod(iMap.getString("POZISYON_KOD"));
			adkStandCalisanTx.setTuttuguTakimKod(iMap.getString("TUTTUGU_TAKIM_KOD"));
			adkStandCalisanTx.setCalStatuKod("A");
			adkStandCalisanTx.setHobiler(prepareHobiKod(iMap));
			adkStandCalisanTx.setYetkiSeviyeKod(iMap.getString("YETKI_SEVIYE_KOD"));

			session.save(adkStandCalisanTx);
			session.flush();

			iMap.put("TRX_NAME", "4102");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(715));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		} catch (Exception e) {
			 throw new GMRuntimeException(0,e);	
		}
	}
	@GraymoundService("BNSPR_TRN4102_GET_HOBILER")
	public static GMMap getHobiler(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_rc_adc.RC_QRY4102_GET_HOBILER}");
            stmt.registerOutParameter(1, -10);
            stmt.execute();
        	rSet = (ResultSet)stmt.getObject(1);
			return DALUtil.rSetResults(rSet,"HOBILER");
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	public static String prepareHobiKod(GMMap iMap){
		StringBuilder hobiKod = new StringBuilder();
		String tableName = "HOBI_KOD";
		List<?> list = (List<?>)iMap.get(tableName);
		for (int i=0; i<list.size();i++) {
			if(iMap.getString(tableName,i,"SEC").equals("1")){
				hobiKod.append(iMap.get(tableName, i, "HOBI_KOD"));
				hobiKod.append(",");
			}
		}
		//hobiKod.deleteCharAt(hobiKod.lastIndexOf(",")).toString();
		return hobiKod.toString();
	}
	@GraymoundService("BNSPR_TRN4102_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			AdkStandCalisanTx adkStandCalisanTx = (AdkStandCalisanTx) session.get(AdkStandCalisanTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("TRX_NO", adkStandCalisanTx.getTxNo());
			oMap.put("KULLANICI_KODU", adkStandCalisanTx.getKod());
			oMap.put("MUSTERI_NO", adkStandCalisanTx.getMusteriNo());
			oMap.put("HESAP_NO", adkStandCalisanTx.getHesapNo());
			oMap.put("ISE_BASLAMA_TAR", adkStandCalisanTx.getIseBaslamaTar());
			oMap.put("POZISYON_KOD", adkStandCalisanTx.getPozisyonKod());
			oMap.put("TUTTUGU_TAKIM_KOD", adkStandCalisanTx.getTuttuguTakimKod());
			iMap.putAll(getHobiler(iMap));
			parseHobiler(iMap, "SECILEN_HOBILER", adkStandCalisanTx.getHobiler());
			oMap.putAll(AdcTRN4103Services.getHobilerforUpdate(iMap));
			oMap.put("YETKI_SEVIYE_KOD", adkStandCalisanTx.getYetkiSeviyeKod());

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	public static void parseHobiler(GMMap iMap, String tableName, String hobiler){
		try{
			StringTokenizer stringTokenizer = new StringTokenizer(hobiler==null?"":hobiler,",");
			String token="";
			for(int row = 0; stringTokenizer.hasMoreTokens(); row++){
				token = stringTokenizer.nextToken();
				iMap.put(tableName, row, "HOBI_KOD", token);
				iMap.put(tableName, row, "SEC", "1");
			}
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}









