package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksBonoTalepTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcTRN4800Services {

	private static Logger logger = Logger.getLogger(AdcTRN4800Services.class);
	private static final String source = "0123456789_abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final int idLength = 8;
	
	private static String getIdentifier() {
		
		SecureRandom random = new SecureRandom();
		
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < idLength; i++) {
			sb.append(source.charAt(random.nextInt(source.length())));
		}
		
		return sb.toString();
	}
	
	@GraymoundService("BNSPR_TRN4800_GET_APPLICATION_NO")
	public static GMMap getApplicationNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BASVURU_NO", new BigDecimal(DALUtil.getResult("select seq_clks_bono_talep_basvuru.nextval from dual")));
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4800_SAVE")
	public static GMMap save(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksBonoTalepTx clksBonoTalepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(clksBonoTalepTx == null) {
				clksBonoTalepTx = new ClksBonoTalepTx();
				clksBonoTalepTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}

			clksBonoTalepTx.setTcKimlikNo(iMap.containsKey("TC_KIMLIK_NO") ? iMap.getString("TC_KIMLIK_NO") : clksBonoTalepTx.getTcKimlikNo());
			clksBonoTalepTx.setMusteriTxNo(iMap.containsKey("MUSTERI_TRX_NO") ? iMap.getBigDecimal("MUSTERI_TRX_NO") : clksBonoTalepTx.getMusteriTxNo());
			clksBonoTalepTx.setHavaleTxNo(iMap.containsKey("HAVALE_TRX_NO") ? iMap.getBigDecimal("HAVALE_TRX_NO") : clksBonoTalepTx.getHavaleTxNo());
			clksBonoTalepTx.setMusteriNo(iMap.containsKey("MUSTERI_NO") ? iMap.getBigDecimal("MUSTERI_NO") : clksBonoTalepTx.getMusteriNo());
			clksBonoTalepTx.setIsleminYapildigiSubeId(iMap.get("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE_ID") != null ? iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE_ID") : clksBonoTalepTx.getIsleminYapildigiSubeId());
			clksBonoTalepTx.setIslemiYapanKullanici(iMap.get("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI") != null ? iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI") : clksBonoTalepTx.getIslemiYapanKullanici());
			clksBonoTalepTx.setIslemiYapanKullaniciSicil(iMap.get("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL") != null ? iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL") : clksBonoTalepTx.getIslemiYapanKullaniciSicil());
			clksBonoTalepTx.setPostaCekiHesapNumarasi(iMap.containsKey("POSTA_CEKI_HESAP_NUMARASI") ? iMap.getBigDecimal("POSTA_CEKI_HESAP_NUMARASI") : clksBonoTalepTx.getPostaCekiHesapNumarasi());
			clksBonoTalepTx.setPttIslemNo(iMap.get("ISYERI_VE_KULLANICI_BILGILERI", 0, "PTT_ISLEM_NO") != null ? iMap.getBigDecimal("ISYERI_VE_KULLANICI_BILGILERI", 0, "PTT_ISLEM_NO") : clksBonoTalepTx.getPttIslemNo());
			clksBonoTalepTx.setLinkIdentifier(clksBonoTalepTx.getLinkIdentifier() != null ? clksBonoTalepTx.getLinkIdentifier() : getIdentifier());
			clksBonoTalepTx.setLinkTtl(iMap.containsKey("LINK_TTL") ? iMap.getBigDecimal("LINK_TTL") : clksBonoTalepTx.getLinkTtl());
			clksBonoTalepTx.setLinkStatus("P");
			clksBonoTalepTx.setDurumKodu("G");
			clksBonoTalepTx.setCepTelNo(iMap.containsKey("CEP_TEL_NO") ? iMap.getString("CEP_TEL_NO") : clksBonoTalepTx.getCepTelNo());
			clksBonoTalepTx.setHesapNo(iMap.containsKey("HESAP_NO") ? iMap.getBigDecimal("HESAP_NO") : clksBonoTalepTx.getHesapNo());
			clksBonoTalepTx.setBasvuruNo(iMap.containsKey("BASVURU_NO") ? iMap.getBigDecimal("BASVURU_NO") : clksBonoTalepTx.getBasvuruNo());
			clksBonoTalepTx.setYatirimEkstresiKod(iMap.containsKey("YATIRIM_EKSTRE") ? iMap.getString("YATIRIM_EKSTRE") : clksBonoTalepTx.getYatirimEkstresiKod());
			clksBonoTalepTx.setHesapEkstresiKod(iMap.containsKey("HESAP_EKSTRE") ? iMap.getString("HESAP_EKSTRE") : clksBonoTalepTx.getHesapEkstresiKod());
			clksBonoTalepTx.setFBeyanAdres(iMap.containsKey("F_BEYAN_ADRES") ? iMap.getString("F_BEYAN_ADRES") : "H");
			clksBonoTalepTx.setEvAdres(iMap.containsKey("EV_ADRES") ? iMap.getString("EV_ADRES") : clksBonoTalepTx.getEvAdres());
			clksBonoTalepTx.setEvAdrIlceKod(iMap.containsKey("EV_ADR_ILCE_KOD") ? iMap.getString("EV_ADR_ILCE_KOD") : clksBonoTalepTx.getEvAdrIlceKod());
			clksBonoTalepTx.setEvAdrIlKod(iMap.containsKey("EV_ADR_IL_KOD") ? iMap.getString("EV_ADR_IL_KOD") : clksBonoTalepTx.getEvAdrIlKod());
			clksBonoTalepTx.setEvPostakod(iMap.containsKey("EV_POSTA_KOD") ? iMap.getString("EV_POSTA_KOD") : clksBonoTalepTx.getEvPostakod());
			clksBonoTalepTx.setEmail(iMap.containsKey("EMAIL") ? iMap.getString("EMAIL") : clksBonoTalepTx.getEmail());
			session.saveOrUpdate(clksBonoTalepTx);
			session.flush();
			
			if(iMap.containsKey("TRX_NAME")) {
				return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			} else {
				return new GMMap().put("RESPONSE", 2);
			}
		}
		
		catch(Exception e) {
			logger.error("BNSPR_TRN4800_SAVE err: ", e);
            throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4800_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String telefonTipGsm = "3", telefonFormatTumKod = "+UAT";
		
		try {
			
			if(iMap.containsKey("LINK_ID")) {
				
				Session session = DAOSession.getSession("BNSPRDal");
				
				ClksBonoTalepTx talepTx = (ClksBonoTalepTx) session.createCriteria(ClksBonoTalepTx.class).add(
					Restrictions.and(Restrictions.eq("linkIdentifier", iMap.getString("LINK_ID")), 
					Restrictions.isNotNull("linkTimestamp"))).uniqueResult();
				
				if(talepTx == null) {
					// TODO Parametrik mesaj
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 660).put("P1", "Uygun Kay�t Bulunamam��t�r."));
				} else if (talepTx.getLinkStatus().equalsIgnoreCase("S")){
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 660).put("P1", "Bono Al�� i�in bu link kullan�lm��t�r. Tekrar kullanamazs�n�z."));
				}
				
				Calendar cal = Calendar.getInstance(), currentCal = Calendar.getInstance();
				cal.setTime(talepTx.getLinkTimestamp());
				cal.add(Calendar.MINUTE, talepTx.getLinkTtl().intValue());
				currentCal.setTime(new java.util.Date());
				
				// Link TTL dolmu�, uygun mesaj gonderilecek.
				if(cal.compareTo(currentCal) < 0) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 660).put("P1", "Talebiniz zaman a��m�na u�ram��t�r."));
				}
				
				ClksHavaleGirisTx havaleGirisTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, talepTx.getHavaleTxNo());
				
				oMap.put("TX_NO", talepTx.getTxNo());
				oMap.put("TC_KIMLIK_NO", talepTx.getTcKimlikNo());
				oMap.put("MUSTERI_NO", talepTx.getMusteriNo());
				oMap.put("TUTAR", havaleGirisTx.getTutar());
				oMap.put("HESAP_NO", havaleGirisTx.getAliciHesapNo());
				oMap.put("EMAIL", (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.email_kisisel(?) }", 
					BnsprType.STRING, 
					BnsprType.NUMBER, talepTx.getMusteriNo()));
				oMap.put("CEP_TEL_NO", talepTx.getCepTelNo() != null ? talepTx.getCepTelNo() : (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.telefon(?,?,?) }", 
					BnsprType.STRING, 
					BnsprType.NUMBER, talepTx.getMusteriNo(), 
					BnsprType.STRING, telefonTipGsm,
					BnsprType.STRING, telefonFormatTumKod));
				oMap.put("UNVAN", (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.unvan(?) }", BnsprType.STRING, BnsprType.NUMBER, talepTx.getMusteriNo()));
				
				talepTx.setLinkStatus("S");
				session.saveOrUpdate(talepTx);
				session.flush();
				
				oMap.put("RESPONSE", 2);
				oMap.put("RESPONSE_DATA", "");
				
			} 
			
			else if(iMap.containsKey("TRX_NO")) {
				
				Session session = DAOSession.getSession("BNSPRDal");
				
				ClksBonoTalepTx talepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class, iMap.getBigDecimal("TRX_NO"));
				
				if(talepTx == null) {
					// TODO Parametrik mesaj
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 660).put("P1", "Uygun Kay�t Bulunamam��t�r."));
				}
				
				oMap.put("TC_KIMLIK_NO", talepTx.getTcKimlikNo());
				oMap.put("MUSTERI_NO", talepTx.getMusteriNo());
				oMap.put("CEP_TEL_NO", talepTx.getCepTelNo());
			}
			
			else {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 330).put("P1", "LINK_ID"));
			}
		} 
		
		catch(HibernateException he) {
			
			logger.error("BNSPR_TRN4800_GET_INFO err: ", he);
			
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 1803)).getString("ERROR_MESSAGE"));
		}
		
		catch(Exception e) {
			
			logger.error("BNSPR_TRN4800_GET_INFO err: ", e);
			
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4800_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		return new GMMap();
	}
}
