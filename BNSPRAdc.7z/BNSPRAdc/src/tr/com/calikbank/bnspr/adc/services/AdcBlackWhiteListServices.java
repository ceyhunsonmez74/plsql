package tr.com.calikbank.bnspr.adc.services;

import java.util.Date;
import java.util.List;

import tr.com.aktifbank.bnspr.adc.dal.AdcBlackWhiteListDAL;
import tr.com.aktifbank.bnspr.dao.AdcBlackWhiteList;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcBlackWhiteListServices {

	@GraymoundService("ADK_GET_BLACK_OR_WHITE_LIST")
	public static GMMap getList(GMMap iMap) {

		GMMap oMap = new GMMap();
		if(iMap.containsKey("VALUE")){
			AdcBlackWhiteList adcBlackWhiteList = AdcBlackWhiteListDAL.get("", iMap.getString("BLACK_OR_WHITE"), iMap.getString("LIST_TYPE"), iMap.getString("VALUE"));
			if(adcBlackWhiteList != null){
				oMap.put("LIST", 0, "BLACK_OR_WHITE", 	adcBlackWhiteList.getBlackOrWhite());
				oMap.put("LIST", 0, "DESCRIPTION", 		adcBlackWhiteList.getDescription());
				oMap.put("LIST", 0, "LIST_TYPE", 		adcBlackWhiteList.getListType());
				oMap.put("LIST", 0, "OID", 				adcBlackWhiteList.getOid());
				oMap.put("LIST", 0, "REC_DATE",		 	adcBlackWhiteList.getRecDate());
				oMap.put("LIST", 0, "REC_OWNER", 		adcBlackWhiteList.getRecOwner());
				oMap.put("LIST", 0, "VALUE", 			adcBlackWhiteList.getValue());
			}
		}else{
			List<AdcBlackWhiteList> adcBlackWhiteList = AdcBlackWhiteListDAL.getList(iMap);

			for (int i = 0; i < adcBlackWhiteList.size(); i++) {
				oMap.put("LIST", i, "BLACK_OR_WHITE", 	adcBlackWhiteList.get(i).getBlackOrWhite());
				oMap.put("LIST", i, "DESCRIPTION", 		adcBlackWhiteList.get(i).getDescription());
				oMap.put("LIST", i, "LIST_TYPE", 		adcBlackWhiteList.get(i).getListType());
				oMap.put("LIST", i, "OID", 				adcBlackWhiteList.get(i).getOid());
				oMap.put("LIST", i, "REC_DATE",		 	adcBlackWhiteList.get(i).getRecDate());
				oMap.put("LIST", i, "REC_OWNER", 		adcBlackWhiteList.get(i).getRecOwner());
				oMap.put("LIST", i, "VALUE", 			adcBlackWhiteList.get(i).getValue());
			}			
		}

		return oMap;
	}

	
	@GraymoundService("ADK_SAVE_BLACK_OR_WHITE_LIST")
	public static GMMap save(GMMap iMap) {

		GMMap oMap = new GMMap();
		AdcBlackWhiteList adcBlackWhiteList = AdcBlackWhiteListDAL.get(
				iMap.getString("OID"), 
				iMap.getString("BLACK_OR_WHITE"),
				iMap.getString("LIST_TYPE"), 
				iMap.getString("VALUE"));
		
		if(adcBlackWhiteList == null){
			adcBlackWhiteList = new AdcBlackWhiteList();
		}
		
		AdcBlackWhiteList adcBlackWhiteListOther = AdcBlackWhiteListDAL.get("", iMap.getString("BLACK_OR_WHITE"), iMap.getString("LIST_TYPE"), iMap.getString("VALUE"));
		
		if(adcBlackWhiteListOther != null){
			if(iMap.getString("OID") != adcBlackWhiteListOther.getOid())
				throw new GMRuntimeException(0, "Girdi�iniz de�erlerle bir kay�t mevcut. �lgili kayd� g�ncelleyiniz.");
		}
		
		adcBlackWhiteList.setBlackOrWhite(iMap.getString("BLACK_OR_WHITE"));
		adcBlackWhiteList.setDescription(iMap.getString("DESCRIPTION"));
		adcBlackWhiteList.setListType(iMap.getString("LIST_TYPE"));
		adcBlackWhiteList.setValue(iMap.getString("VALUE"));
		adcBlackWhiteList.setRecOwner(ADCSession.getString("USER_NAME"));
		adcBlackWhiteList.setRecDate(new Date());
		
		AdcBlackWhiteListDAL.save(adcBlackWhiteList);
		return oMap;
	}
	@GraymoundService("ADK_DELETE_BLACK_OR_WHITE_LIST")
	public static GMMap delete(GMMap iMap) {
		GMMap oMap = new GMMap();
		AdcBlackWhiteList adcBlackWhiteList = AdcBlackWhiteListDAL.get(iMap.getString("OID"),"","","");
		AdcBlackWhiteListDAL.delete(adcBlackWhiteList);
		return oMap;
	}

}
