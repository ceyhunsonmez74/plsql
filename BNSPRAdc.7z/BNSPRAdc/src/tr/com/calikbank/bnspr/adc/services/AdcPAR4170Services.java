package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Random;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcPAR4170Services {

	@GraymoundService("BNSPR_PAR4170_PAROLA_PASSWORD")
	public static GMMap parolaPassword(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		
		CallableStatement stmt2 = null;
		CallableStatement stmt3 = null;
		try {
		    
		    checkBlock(iMap);

			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_TRN4131.otpTel_AnneKizlikSayadi(?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.registerOutParameter(2, Types.VARCHAR); // TCKN
			stmt.registerOutParameter(3, Types.VARCHAR); // TEL NO
			stmt.registerOutParameter(4, Types.VARCHAR); // AKS
			stmt.execute();
			

						
			String phoneNumber = stmt.getString(3);
			JGMPasswordField passwordField = new JGMPasswordField();

			if (iMap.getBoolean("INTERNET")) {

					Integer pass = (new Random().nextInt(900000) + 100000);
					passwordField.setText(pass.toString());

					GMMap servisMap = new GMMap();
					servisMap.put("USER_CODE", stmt.getString(2));
					servisMap.put("CHANNEL_CODE", "INT");
					servisMap.put("PASSWORD", new String(passwordField
							.getPassword()));
					servisMap.put("SERVICE_NAME",
							"ADC_REMOTE_USER_UPDATE_PASSWORD");
					
					GMMap servisMapMBL = new GMMap();
					servisMapMBL.put("USER_CODE", stmt.getString(2));
					servisMapMBL.put("CHANNEL_CODE", "MBL");
					servisMapMBL.put("PASSWORD", new String(passwordField.getPassword()));
					servisMapMBL.put("SERVICE_NAME", "ADC_REMOTE_USER_UPDATE_PASSWORD");

					
					stmt2 = conn.prepareCall("{? = call PKG_TRN4131.Musteri_mesaj(?,?,?)}");

					stmt2.registerOutParameter(1, Types.VARCHAR);
					stmt2.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
					stmt2.setInt(3, pass );
					stmt2.setBigDecimal(4, new BigDecimal(4));
					stmt2.execute();		
								
					String mesaj  = stmt2.getString(1);					
					
					GMMap iMap1 = new GMMap();
					//iMap1.put("MESSAGE_NO", new BigDecimal("1357"));
					//iMap1.put("P1", pass);
					//iMap1.put("P5", new BigDecimal(4));
					//String mesaj = (String) GMServiceExecuter.execute(
						//	"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap1).get(
						//	"ERROR_MESSAGE");

					iMap1.put("CONTENT", mesaj);
					iMap1.put("MSISDN", phoneNumber);
					iMap1.put("SECURE_CONTENT", true);
					iMap1.put("FILTER", true);
					
//					GMMap iMap2 = new GMMap();
//					
//					iMap2.put("UID", stmt.getString(2));
//					iMap2.put("PASSWORD", pass.toString());
//					
//					GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_INT", iMap2);
					
					GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap);
					try{
						GMServiceExecuter.call("ADK_CALL_SERVICE", servisMapMBL);
					}
					catch(GMRuntimeException e){
						// bono talimat musterisi durumunda mobil kanalinda kayit olmayacagindan USRNOTCHNLAUTH hatasi gelecektir, bu durumda hata firlatmayalim, aksi halde atalim hatayi
						if(!GMMessageFactory.getMessage("USRNOTCHNLAUTH", null).equals(e.getMessage()))  
							throw e;
					}
					GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap1);
				}
				
	
			if (iMap.getBoolean("CAGRI_MERKEZI")) {

					Integer pass = (new Random().nextInt(900000) + 100000);
					passwordField.setText(pass.toString());

					GMMap servisMap = new GMMap();
					servisMap.put("USER_CODE", stmt.getString(2));
					servisMap.put("CHANNEL_CODE", "IVR");
					servisMap.put("PASSWORD", passwordField.getPassword());
					servisMap.put("SERVICE_NAME",
							"ADC_REMOTE_USER_UPDATE_PASSWORD");

					
					stmt3 = conn.prepareCall("{? = call PKG_TRN4131.Musteri_mesaj(?,?,?)}");

					stmt3.registerOutParameter(1, Types.VARCHAR);
					stmt3.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
					stmt3.setInt(3, pass );
					stmt3.setBigDecimal(4, new BigDecimal(6));
					stmt3.execute();		
								
					String mesaj  = stmt3.getString(1);						
					
					GMMap iMap1 = new GMMap();
					//iMap1.put("MESSAGE_NO", new BigDecimal("1357"));
					//iMap1.put("P1", pass);
					//iMap1.put("P5", new BigDecimal(6));
					//String mesaj = (String) GMServiceExecuter.execute(
						//	"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap1).get(
						//	"ERROR_MESSAGE");
					
		
					iMap1.put("CONTENT", mesaj);
					iMap1.put("MSISDN", phoneNumber);
					iMap1.put("SECURE_CONTENT", true);
					iMap1.put("FILTER", true);
					
					GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap);
					GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap1);
				}
			

			return new GMMap();

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(conn);
		}
	}

    private static void checkBlock(GMMap iMap) {
        GMMap blockMap = GMServiceExecuter.call("BNSPR_TRN4131_GET_KANAL_BLOKE", iMap);
        
        if ((iMap.getBoolean("INTERNET")
                && blockMap.getBoolean("INTERNET"))
            ||
            (iMap.getBoolean("CAGRI_MERKEZI")
                    && (blockMap.getBoolean("CAGRI_MERKEZI")
                            || blockMap.getBoolean("IVR")))) {
            throw new GMRuntimeException(0, "M��terinin kanal blokesi var");
        }
    }

}
