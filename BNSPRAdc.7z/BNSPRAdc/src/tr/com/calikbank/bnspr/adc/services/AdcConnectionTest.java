package tr.com.calikbank.bnspr.adc.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AdcConnectionTest {
	@GraymoundService(value="ADC_VERITABANI_KONTROL", authenticationRequired=false)
	public static GMMap checkRemoteDatabase(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {		
			conn = DALUtil.getGMConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select 1 from dual");
			rs.next();
			if (1 == rs.getInt(1)) {
				oMap.put("RESPONSE", 2);
				oMap.put("RESPONSE_DATA", "Remote veritabani test BA�ARILI!");
			}
			else {
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", "Remote veritabani testte sorun!");
			}
		}
		catch (Exception e) {
			e.printStackTrace();		
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", "Remote veritabani ba�lant�s�nda sorun!");
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rs);
		}
		
		return oMap;
	}
}
