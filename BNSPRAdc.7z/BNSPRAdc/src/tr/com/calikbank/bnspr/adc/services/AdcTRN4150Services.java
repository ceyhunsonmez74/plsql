package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKanalislemDetayPrTx;
import tr.com.calikbank.bnspr.dao.GnlKanalislemDetayPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class AdcTRN4150Services {
	@GraymoundService("BNSPR_TRN4150_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			iMap.put("KOD", "ONAY_OTP_ZAMANI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("ONAY_OTP_ZAMANI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "EVET_HAYIR");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("EVET_HAYIR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4153_SAVE")
	public static GMMap saveTRN4153(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String kanalKodu;
			String modulKodu;
			BigDecimal islemKodu;
			String prosesKodu;
			GnlKanalislemDetayPrTx gnlKanalIslemDetayPrTx = new GnlKanalislemDetayPrTx();
			GnlKanalislemDetayPrTxId id = new GnlKanalislemDetayPrTxId();
			
			/*id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setModulKod(iMap.getString("MODUL_KOD"));
			id.setKanalKod(iMap.getString("KANAL_KOD"));
			id.setIslemKod(iMap.getBigDecimal("ISLEM_KOD"));*/
			kanalKodu = iMap.getString("KANAL_KOD");
			modulKodu =  iMap.getString("MODUL_KOD");
			islemKodu = iMap.getBigDecimal("ISLEM_KOD");
			prosesKodu = iMap.getString("PROSES_KOD");
			if(kanalKodu == null || kanalKodu.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kanal Kodu");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}	
			if(modulKodu == null || modulKodu.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Mod�l Kodu");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}	
			if(islemKodu == null)
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "��lem Kodu");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}	
			if(prosesKodu == null || prosesKodu.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Proses Kodu");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setModulKod(modulKodu);
			id.setKanalKod(kanalKodu);
			id.setIslemKod(islemKodu);
			id.setProsesKod(prosesKodu);
			gnlKanalIslemDetayPrTx.setId(id);
			gnlKanalIslemDetayPrTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			gnlKanalIslemDetayPrTx.setAnlikMinTutar(iMap.getBigDecimal("ANLIK_MIN_TUTAR"));
			gnlKanalIslemDetayPrTx.setAnlikMaxTutar(iMap.getBigDecimal("ANLIK_MAX_TUTAR"));
			gnlKanalIslemDetayPrTx.setGunlukLimit(iMap.getBigDecimal("GUNLUK_LIMIT"));
			gnlKanalIslemDetayPrTx.setAylikLimit(iMap.getBigDecimal("AYLIK_LIMIT"));
			gnlKanalIslemDetayPrTx.setMusteriGunlukLimit(iMap.getBigDecimal("MUSTERI_GUNLUK_LIMIT"));
			gnlKanalIslemDetayPrTx.setMusteriAylikLimit(iMap.getBigDecimal("MUSTERI_AYLIK_LIMIT"));
			gnlKanalIslemDetayPrTx.setMusteriGunlukAdet(iMap.getBigDecimal("MUSTERI_GUNLUK_ADET"));
			gnlKanalIslemDetayPrTx.setMusteriAylikAdet(iMap.getBigDecimal("MUSTERI_AYLIK_ADET"));
			gnlKanalIslemDetayPrTx.setIslemBitisSaat(iMap.getString("ISLEM_BITIS_SAAT"));
			gnlKanalIslemDetayPrTx.setIslemOnayOtp(iMap.getString("ISLEM_ONAY_OTP"));
			gnlKanalIslemDetayPrTx.setOnayOtpZamani(iMap.getString("ONAY_OTP_ZAMANI"));
			gnlKanalIslemDetayPrTx.setTalimatBilgiSms(iMap.getString("TALIMAT_BILGI_SMS"));
			gnlKanalIslemDetayPrTx.setIslemSonucSms(iMap.getString("ISLEM_SONUC_SMS"));                  
			gnlKanalIslemDetayPrTx.setOncelikKatsayisi(iMap.getBigDecimal("ONCELIK_KATSAYISI"));  
			gnlKanalIslemDetayPrTx.setKritikSaatKatsayisi(iMap.getBigDecimal("KRITIK_SAAT_KATSAYISI"));  
			gnlKanalIslemDetayPrTx.setGDS(iMap.getString("G_D_S"));
			gnlKanalIslemDetayPrTx.setIslemBaslangicSaat(iMap.getString("ISLEM_BASLANGIC_SAAT"));
			session.saveOrUpdate(gnlKanalIslemDetayPrTx);
			session.flush();

			iMap.put("TRX_NAME", "4153");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		/*catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(715));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}*/
		catch (Exception e) {
//			System.out.println(e);
			//throw new GMRuntimeException(0,e);
			throw ExceptionHandler.convertException(e);
		}

	}	
	
	@GraymoundService("BNSPR_QRY4150_GET_KANAL_ISLEM_DETAY")
	public static GMMap getKanalIslemDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_rc_adc.RC_QRY4150_Kanal_Islem_Detay(?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++,iMap.getString("KANAL_KOD"));
			stmt.setString(i++,iMap.getString("MODUL_KOD"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("ISLEM_KOD"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			String tableName = "KANAL_ISLEM_DETAY";
			oMap = DALUtil.rSetResults(rSet, tableName);
			
			for (int row = 0; row < oMap.getSize(tableName); row++) {
				String 		kanalKod 	= oMap.getString(tableName, row, "KANAL_KOD");
				BigDecimal islemKod 	= oMap.getBigDecimal(tableName, row, "ISLEM_KOD");
				String 		modulKod 	= oMap.getString(tableName, row, "MODUL_KOD");
				oMap.put(tableName, row, "ISLEM_ACIKLAMA", LovHelper.diLov(islemKod, kanalKod, modulKod, "4153/LOV_ISLEM_GRUBU", "ACIKLAMA"));
				
			}
			
			
//			while (rSet.next()) {
//			
//				oMap.put(tableName, row, "KANAL_KOD", rSet.getBigDecimal("kanal_kod"));
//				oMap.put(tableName, row, "MODUL_KOD", rSet.getString("modul_kod"));
//				oMap.put(tableName, row, "ISLEM_KOD", rSet.getString("islem_kod"));
//				oMap.put(tableName, row, "ISLEM_ACIKLAMA", rSet.getString("islem_kod")); 
//				
//			}
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	}	

	@GraymoundService("BNSPR_TRN4153_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
	
				Session session = DAOSession.getSession("BNSPRDal");

				GMMap oMap = new GMMap();
				
				List<?> list = (List<?>) session.createCriteria(GnlKanalislemDetayPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
				
				GnlKanalislemDetayPrTx gnlKanalIslemDetayPrTx = (GnlKanalislemDetayPrTx) list.get(0);
				
				oMap.put("TRX_NO", gnlKanalIslemDetayPrTx.getId().getTxNo());
				oMap.put("KANAL_KOD", gnlKanalIslemDetayPrTx.getId().getKanalKod());
				oMap.put("KANAL_ACIKLAMA", LovHelper.diLov(gnlKanalIslemDetayPrTx.getId().getKanalKod(), "4153/LOV_KANAL_GRUBU", "ACIKLAMA")); 
				oMap.put("MODUL_KOD", gnlKanalIslemDetayPrTx.getId().getModulKod());
				oMap.put("MODUL_ACIKLAMA", LovHelper.diLov(gnlKanalIslemDetayPrTx.getId().getModulKod(),gnlKanalIslemDetayPrTx.getId().getKanalKod(), "4153/LOV_MODUL_GRUBU", "ACIKLAMA")); 
				oMap.put("ISLEM_KOD", gnlKanalIslemDetayPrTx.getId().getIslemKod());
				oMap.put("ISLEM_ACIKLAMA", LovHelper.diLov(gnlKanalIslemDetayPrTx.getId().getIslemKod(),gnlKanalIslemDetayPrTx.getId().getKanalKod(), gnlKanalIslemDetayPrTx.getId().getModulKod(), "4153/LOV_ISLEM_GRUBU", "ACIKLAMA")); 
				oMap.put("PROSES_KOD", gnlKanalIslemDetayPrTx.getId().getProsesKod());
				oMap.put("PROSES_ACIKLAMA", LovHelper.diLov(gnlKanalIslemDetayPrTx.getId().getProsesKod(),gnlKanalIslemDetayPrTx.getId().getKanalKod(),gnlKanalIslemDetayPrTx.getId().getModulKod(),gnlKanalIslemDetayPrTx.getId().getIslemKod(), "4153/LOV_PROSES", "ACIKLAMA")); 
				oMap.put("DOVIZ_KODU",gnlKanalIslemDetayPrTx.getDovizKodu());
				oMap.put("DOVIZ_ACIKLAMA", LovHelper.diLov(gnlKanalIslemDetayPrTx.getDovizKodu(), "4153/LOV_DOVIZ", "ACIKLAMA")); 
				oMap.put("ANLIK_MIN_TUTAR",gnlKanalIslemDetayPrTx.getAnlikMinTutar());
				oMap.put("ANLIK_MAX_TUTAR",gnlKanalIslemDetayPrTx.getAnlikMaxTutar());
				oMap.put("GUNLUK_LIMIT",gnlKanalIslemDetayPrTx.getGunlukLimit());
				oMap.put("AYLIK_LIMIT",gnlKanalIslemDetayPrTx.getAylikLimit());
				oMap.put("MUSTERI_GUNLUK_LIMIT",gnlKanalIslemDetayPrTx.getMusteriGunlukLimit());
				oMap.put("MUSTERI_AYLIK_LIMIT",gnlKanalIslemDetayPrTx.getMusteriAylikLimit());
				oMap.put("MUSTERI_GUNLUK_ADET",gnlKanalIslemDetayPrTx.getMusteriGunlukAdet());
				oMap.put("MUSTERI_AYLIK_ADET",gnlKanalIslemDetayPrTx.getMusteriAylikAdet());
				oMap.put("ISLEM_BITIS_SAAT",gnlKanalIslemDetayPrTx.getIslemBitisSaat());
				oMap.put("ISLEM_ONAY_OTP",gnlKanalIslemDetayPrTx.getIslemOnayOtp());
				oMap.put("ONAY_OTP_ZAMANI",gnlKanalIslemDetayPrTx.getOnayOtpZamani());
				oMap.put("TALIMAT_BILGI_SMS",gnlKanalIslemDetayPrTx.getTalimatBilgiSms());
				oMap.put("ISLEM_SONUC_SMS",gnlKanalIslemDetayPrTx.getIslemSonucSms());
				oMap.put("ONCELIK_KATSAYISI",gnlKanalIslemDetayPrTx.getOncelikKatsayisi());
                oMap.put("KRITIK_SAAT_KATSAYISI",gnlKanalIslemDetayPrTx.getKritikSaatKatsayisi());
                oMap.put("ISLEM_BASLANGIC_SAAT",gnlKanalIslemDetayPrTx.getIslemBaslangicSaat());
				oMap.put("G_D_S",gnlKanalIslemDetayPrTx.getGDS());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
	
	@GraymoundService("BNSPR_TRN4153_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GnlKanalislemDetayPrTx gnlKanalislemDetayPrTx = (GnlKanalislemDetayPrTx)session.createCriteria(GnlKanalislemDetayPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			int otpType;
			if("H".equals(gnlKanalislemDetayPrTx.getIslemOnayOtp()))otpType = 0;
			else if ("O".equals(gnlKanalislemDetayPrTx.getOnayOtpZamani()))otpType = 1;
			else otpType = 2;
			
			GMMap serviceMap = new GMMap();
			serviceMap.put("PROCESS_CODE", gnlKanalislemDetayPrTx.getId().getProsesKod());
			serviceMap.put("OTP_TYPE", otpType);
			serviceMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_CHANNEL_CODE", new GMMap().put("KANAL_KOD", gnlKanalislemDetayPrTx.getId().getKanalKod())));
			serviceMap.put("USERNAME", "*");
			serviceMap.put("ACTION", gnlKanalislemDetayPrTx.getGDS().equals("S")?"DELETE":"UPDATE");
			
			String tableName = "LIMITS";
			int row = 0;
			String dovizKodu = gnlKanalislemDetayPrTx.getDovizKodu();
			serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(0));
			serviceMap.put(tableName, row, "CURRENCY_CODE", dovizKodu);
			serviceMap.put(tableName, row, "MAX_AMOUNT", gnlKanalislemDetayPrTx.getAnlikMaxTutar());
			serviceMap.put(tableName, row, "PROCESS_CODE", gnlKanalislemDetayPrTx.getId().getProsesKod());
			serviceMap.put(tableName, row++, "MIN_AMOUNT", gnlKanalislemDetayPrTx.getAnlikMinTutar());

			serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(1));
			serviceMap.put(tableName, row, "CURRENCY_CODE", dovizKodu);
			serviceMap.put(tableName, row, "MAX_AMOUNT", gnlKanalislemDetayPrTx.getGunlukLimit());
			serviceMap.put(tableName, row, "PROCESS_CODE", gnlKanalislemDetayPrTx.getId().getProsesKod());
			serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
			
			if(gnlKanalislemDetayPrTx.getAylikLimit()!=null)
			{
				serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(2));
				serviceMap.put(tableName, row, "CURRENCY_CODE", dovizKodu);
				serviceMap.put(tableName, row, "MAX_AMOUNT", gnlKanalislemDetayPrTx.getAylikLimit());
				serviceMap.put(tableName, row, "PROCESS_CODE", gnlKanalislemDetayPrTx.getId().getProsesKod());
				serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
			}
			if(gnlKanalislemDetayPrTx.getMusteriGunlukLimit()!=null)
			{
				serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(3));
				serviceMap.put(tableName, row, "CURRENCY_CODE", dovizKodu);
				serviceMap.put(tableName, row, "MAX_AMOUNT", gnlKanalislemDetayPrTx.getMusteriGunlukLimit());
				serviceMap.put(tableName, row, "PROCESS_CODE", gnlKanalislemDetayPrTx.getId().getProsesKod());
				serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
			}
			if(gnlKanalislemDetayPrTx.getMusteriAylikLimit()!=null)
			{
				serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(4));
				serviceMap.put(tableName, row, "CURRENCY_CODE", dovizKodu);
				serviceMap.put(tableName, row, "MAX_AMOUNT", gnlKanalislemDetayPrTx.getMusteriAylikLimit());
				serviceMap.put(tableName, row, "PROCESS_CODE", gnlKanalislemDetayPrTx.getId().getProsesKod());
				serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
			}
			if(gnlKanalislemDetayPrTx.getMusteriGunlukAdet()!=null)
			{
				serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(96));
				serviceMap.put(tableName, row, "CURRENCY_CODE", "ADT");
				serviceMap.put(tableName, row, "MAX_AMOUNT", gnlKanalislemDetayPrTx.getMusteriGunlukAdet());
				serviceMap.put(tableName, row, "PROCESS_CODE", gnlKanalislemDetayPrTx.getId().getProsesKod());
				serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
			}
			if(gnlKanalislemDetayPrTx.getMusteriAylikAdet()!=null)
			{
				serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(97));
				serviceMap.put(tableName, row, "CURRENCY_CODE", "ADT");
				serviceMap.put(tableName, row, "MAX_AMOUNT", gnlKanalislemDetayPrTx.getMusteriAylikAdet());
				serviceMap.put(tableName, row, "PROCESS_CODE", gnlKanalislemDetayPrTx.getId().getProsesKod());
				serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
			}
			row=0;

			GMMap tMap= new GMMap();
			tMap.put("CHANNEL_CODE", serviceMap.get("CHANNEL_CODE"));
			String channelOID= GMServiceExecuter.execute("ADC_CORE_GET_CHANNEL_BY_CODE", tMap).get("CHANNEL_OID").toString();
			serviceMap.put("TIME_"+tableName , row, "CHANNEL_OID"	, channelOID);
			serviceMap.put("TIME_"+tableName , row, "PROCESS_CODE"	, gnlKanalislemDetayPrTx.getId().getProsesKod());
			serviceMap.put("TIME_"+tableName , row, "S_TIME"		, gnlKanalislemDetayPrTx.getIslemBaslangicSaat()==null?"000000":gnlKanalislemDetayPrTx.getIslemBaslangicSaat());
			serviceMap.put("TIME_"+tableName , row, "E_TIME"		, gnlKanalislemDetayPrTx.getIslemBitisSaat()==null?"235959":gnlKanalislemDetayPrTx.getIslemBitisSaat());

			GMServiceExecuter.call("ADK_PROCESS_REMOTE_UPDATE", serviceMap);
			
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
