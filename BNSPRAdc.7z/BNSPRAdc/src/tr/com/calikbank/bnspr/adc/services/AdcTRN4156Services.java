package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusislAdetKisitPrTx;
import tr.com.calikbank.bnspr.dao.GnlMusislAdetKisitPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4156Services {
	@GraymoundService("BNSPR_QRY4156_KANAL_ISLEM_ADET_KISIT")
	public static GMMap KanalIslemAdetKisitlama(GMMap iMap)throws ParseException{

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try{
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call  PKG_RC_ADC.RC_QRY4156_Musteri_Islem_Kisit(?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			BigDecimal musteriNo ;
			musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			if(musteriNo == null)
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Musteri No");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}		
			stmt.setBigDecimal(i++,musteriNo);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KOD"));
			stmt.setString(i++, iMap.getString("MODUL_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			GMMap xMap = new GMMap();
			String tableName = "MUSTERI_ISLEM_ADET_KISITLAMA";

			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "KANAL_KOD", rSet.getBigDecimal("kanal_kod"));
				oMap.put(tableName, row, "MODUL_KOD", rSet.getString("modul_kod"));
				oMap.put(tableName, row, "ISLEM_KOD", rSet.getString("islem_kod"));
				oMap.put(tableName, row, "ISLEM_ACIKLAMA", LovHelper.diLov(oMap.getBigDecimal(tableName, row, "ISLEM_KOD"), oMap.getString(tableName, row, "MODUL_KOD"), "4156/LOV_ISLEM_GRUBU", "ACIKLAMA"));
				oMap.put(tableName, row, "MUSTERI_GUNLUK_LIMIT",rSet.getBigDecimal("musteri_gunluk_limit"));
				oMap.put(tableName, row, "MUSTERI_AYLIK_LIMIT",rSet.getBigDecimal("musteri_aylik_limit"));
				oMap.put(tableName, row, "MUSTERI_GUNLUK_ADET",rSet.getBigDecimal("musteri_gunluk_adet"));
				oMap.put(tableName, row, "MUSTERI_AYLIK_ADET",rSet.getBigDecimal("musteri_aylik_adet"));
				oMap.put(tableName, row, "G_D_S",false);
				oMap.put(tableName, row, "DURUM" ,"E");
				oMap.put(tableName, row, "ID", rSet.getBigDecimal("KISIT_NO"));
				oMap.put(tableName, row, "PROSES_KOD", rSet.getString("PROSES_KOD"));
				
				iMap.put("KANAL_KOD", rSet.getBigDecimal("kanal_kod"));
				iMap.put("MODUL_KOD", rSet.getString("modul_kod"));
				iMap.put("ISLEM_KOD", rSet.getString("islem_kod"));
				iMap.put("PROSES_KOD",rSet.getString("PROSES_KOD"));
				xMap.putAll(GMServiceExecuter.execute("BNSPR_ORY4156_KANAL_ISLEM_ADET_KISIT_INFO", iMap));
				oMap.put(tableName, row, "MUSTERI_AYLIK_ADET1",xMap.get("MUSTERI_AYLIK_ADET") );
			    oMap.put(tableName, row, "MUSTERI_GUNLUK_ADET1", xMap.get("MUSTERI_GUNLUK_ADET") );
			    oMap.put(tableName, row, "MUSTERI_AYLIK_LIMIT1", xMap.get("MUSTERI_AYLIK_LIMIT") );
			    oMap.put(tableName, row, "MUSTERI_GUNLUK_LIMIT1",xMap.get("MUSTERI_GUNLUK_LIMIT") );
			    oMap.put(tableName, row, "DOVIZ_KODU",xMap.get("DOVIZ_KODU") );
	
				row++;
			}
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN4156_SAVE")
	public static GMMap saveTRN4156(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUSTERI_ISLEM_ADET_KISITLAMA";
			
			List<?> list = (List<?>) iMap.get(tableName);
			for(int i=0; i<list.size();i++) {
				//GnlMusIslAdetKisitPrTx gnlMusIslAdetKisitPrTx = (GnlMusIslAdetKisitPrTx) session.get(GnlMusIslAdetKisitPrTx.class, id);
				GnlMusislAdetKisitPrTx gnlMusIslAdetKisitPrTx = (GnlMusislAdetKisitPrTx) session.createCriteria(GnlMusislAdetKisitPrTx.class).add(
						Restrictions.and(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")), 
								         Restrictions.eq("id.kisitNo", iMap.getBigDecimal(tableName, i, "ID")))).uniqueResult();
				if (gnlMusIslAdetKisitPrTx == null) {
					gnlMusIslAdetKisitPrTx = new GnlMusislAdetKisitPrTx();
					GnlMusislAdetKisitPrTxId id = new GnlMusislAdetKisitPrTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setKisitNo(iMap.getBigDecimal(tableName, i, "ID"));
					gnlMusIslAdetKisitPrTx.setId(id);
				}
				gnlMusIslAdetKisitPrTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				gnlMusIslAdetKisitPrTx.setModulKod(iMap.getString(tableName, i,"MODUL_KOD"));
				gnlMusIslAdetKisitPrTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				gnlMusIslAdetKisitPrTx.setIslemKod(iMap.getBigDecimal(tableName, i, "ISLEM_KOD"));
				gnlMusIslAdetKisitPrTx.setProsesKod(iMap.getString(tableName, i, "PROSES_KOD"));
				
				if (iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_ADET")== null ){
					iMap.put(tableName, i,"MUSTERI_AYLIK_ADET",new BigDecimal(0));
					}
				if (iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_ADET")== null ){
					iMap.put(tableName, i,"MUSTERI_GUNLUK_ADET",new BigDecimal(0));
					}
				if (iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_LIMIT")== null ){
					iMap.put(tableName, i,"MUSTERI_AYLIK_LIMIT",new BigDecimal(0));
					}
				if (iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_LIMIT")== null ){
					iMap.put(tableName, i,"MUSTERI_GUNLUK_LIMIT",new BigDecimal(0));
					}
				
				if (iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_ADET").compareTo(iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_ADET1"))== 1) {

					iMap.put("HATA_NO", new BigDecimal(846));
					iMap.put("P1", "MUSTERI ADET - AYLIK");
					iMap.put("P2", iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_ADET1"));
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}else{
				gnlMusIslAdetKisitPrTx.setMusteriAylikAdet(iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_ADET"));
				}
				
				if (iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_ADET").compareTo(iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_ADET1"))== 1) {

					iMap.put("HATA_NO", new BigDecimal(846));
					iMap.put("P1", "MUSTERI ADET - GUNLUK");
					iMap.put("P2", iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_ADET1"));
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}else{
				gnlMusIslAdetKisitPrTx.setMusteriGunlukAdet(iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_ADET"));
				}
				
				if (iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_LIMIT").compareTo(iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_LIMIT1"))== 1) {

					iMap.put("HATA_NO", new BigDecimal(846));
					iMap.put("P1", "MUSTERI LIMIT - AYLIK");
					iMap.put("P2", iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_LIMIT1"));
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}else{
				gnlMusIslAdetKisitPrTx.setMusteriAylikLimit(iMap.getBigDecimal(tableName, i,"MUSTERI_AYLIK_LIMIT"));
				}
				if (iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_LIMIT").compareTo(iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_LIMIT1"))== 1) {

					iMap.put("HATA_NO", new BigDecimal(846));
					iMap.put("P1", "MUSTERI LIMIT - GUNLUK");
					iMap.put("P2", iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_LIMIT1"));
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}else{
				gnlMusIslAdetKisitPrTx.setMusteriGunlukLimit(iMap.getBigDecimal(tableName, i,"MUSTERI_GUNLUK_LIMIT"));
				}
				gnlMusIslAdetKisitPrTx.setDovizKod(iMap.getString(tableName, i,"DOVIZ_KODU"));
				gnlMusIslAdetKisitPrTx.setGDS(iMap.getBoolean(tableName, i, "G_D_S") ? "S" : "G");
				session.saveOrUpdate(gnlMusIslAdetKisitPrTx);
			}
			
			session.flush();

			iMap.put("TRX_NAME", "4156");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}
	        catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN4156_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(GnlMusislAdetKisitPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "MUSTERI_ISLEM_ADET_KISITLAMA";
			int row = 0;
			GMMap oMap = new GMMap();
			GMMap xMap = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				GnlMusislAdetKisitPrTx gnlMusIslAdetKisitPrTx = (GnlMusislAdetKisitPrTx) iterator.next();
				oMap.put(tableName, row, "KANAL_KOD", gnlMusIslAdetKisitPrTx.getKanalKod());
				oMap.put(tableName, row, "MODUL_KOD", gnlMusIslAdetKisitPrTx.getModulKod());
				oMap.put(tableName, row, "ISLEM_KOD", gnlMusIslAdetKisitPrTx.getIslemKod());
				oMap.put(tableName, row, "PROSES_KOD", gnlMusIslAdetKisitPrTx.getProsesKod());
				oMap.put(tableName, row, "DOVIZ_KODU", gnlMusIslAdetKisitPrTx.getDovizKod());
				oMap.put(tableName, row, "ISLEM_ACIKLAMA", LovHelper.diLov(gnlMusIslAdetKisitPrTx.getIslemKod(), gnlMusIslAdetKisitPrTx.getModulKod(), "4156/LOV_ISLEM_GRUBU", "ACIKLAMA")); 
				oMap.put(tableName, row, "MUSTERI_AYLIK_ADET", gnlMusIslAdetKisitPrTx.getMusteriAylikAdet());
			    oMap.put(tableName, row, "MUSTERI_GUNLUK_ADET", gnlMusIslAdetKisitPrTx.getMusteriGunlukAdet());
			    oMap.put(tableName, row, "MUSTERI_AYLIK_LIMIT", gnlMusIslAdetKisitPrTx.getMusteriAylikLimit());
			    oMap.put(tableName, row, "MUSTERI_GUNLUK_LIMIT", gnlMusIslAdetKisitPrTx.getMusteriGunlukLimit());
			    oMap.put(tableName, row, "G_D_S", "S".equals(gnlMusIslAdetKisitPrTx.getGDS()));
			    oMap.put(tableName, row, "ID", gnlMusIslAdetKisitPrTx.getId().getKisitNo());
				oMap.put("MUSTERI_NO", gnlMusIslAdetKisitPrTx.getMusteriNo());

				iMap.put("KANAL_KOD", gnlMusIslAdetKisitPrTx.getKanalKod());
				iMap.put("MODUL_KOD", gnlMusIslAdetKisitPrTx.getModulKod());
				iMap.put("ISLEM_KOD", gnlMusIslAdetKisitPrTx.getIslemKod());
				iMap.put("PROSES_KOD", gnlMusIslAdetKisitPrTx.getProsesKod());
				xMap.putAll(GMServiceExecuter.execute("BNSPR_ORY4156_KANAL_ISLEM_ADET_KISIT_INFO", iMap));
				oMap.put(tableName, row, "MUSTERI_AYLIK_ADET1",xMap.get("MUSTERI_AYLIK_ADET") );
			    oMap.put(tableName, row, "MUSTERI_GUNLUK_ADET1", xMap.get("MUSTERI_GUNLUK_ADET") );
			    oMap.put(tableName, row, "MUSTERI_AYLIK_LIMIT1", xMap.get("MUSTERI_AYLIK_LIMIT") );
			    oMap.put(tableName, row, "MUSTERI_GUNLUK_LIMIT1",xMap.get("MUSTERI_GUNLUK_LIMIT") );
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_ORY4156_KANAL_ISLEM_ADET_KISIT_INFO")
	public static GMMap KanalIslemAdetKisitlamaInfo(GMMap iMap)throws ParseException{
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call  PKG_TRN4156.RC_QRY4156_Kanal_Islem_Kisit(?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("KANAL_KOD"));
			stmt.setString(i++, iMap.getString("MODUL_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.setString(i++, iMap.getString("PROSES_KOD"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN4156_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(GnlMusislAdetKisitPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			GMMap serviceMap;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlMusislAdetKisitPrTx gnlMusislAdetKisitPrTx = (GnlMusislAdetKisitPrTx) iterator.next();

				serviceMap = new GMMap();
				serviceMap.put("PROCESS_CODE", gnlMusislAdetKisitPrTx.getProsesKod());
				serviceMap.put("OTP_TYPE", "0");
				serviceMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_CHANNEL_CODE", new GMMap().put("KANAL_KOD", gnlMusislAdetKisitPrTx.getKanalKod())));
				serviceMap.put("USERNAME", GMServiceExecuter.execute("BNSPR_COMMON_GET_TCKN", new GMMap().put("MUSTERI_NO", gnlMusislAdetKisitPrTx.getMusteriNo())).get("TCKN"));
				serviceMap.put("ACTION", gnlMusislAdetKisitPrTx.getGDS().equals("S")?"DELETE":"UPDATE");
				
				String tableName = "LIMITS";
				int row = 0;
				String dovizKodu = gnlMusislAdetKisitPrTx.getDovizKod();
				if(gnlMusislAdetKisitPrTx.getMusteriGunlukLimit()!=null)
				{
					serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(3));
					serviceMap.put(tableName, row, "CURRENCY_CODE", dovizKodu);
					serviceMap.put(tableName, row, "MAX_AMOUNT", gnlMusislAdetKisitPrTx.getMusteriGunlukLimit());
					serviceMap.put(tableName, row, "PROCESS_CODE", gnlMusislAdetKisitPrTx.getProsesKod());
					serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
				}
				if(gnlMusislAdetKisitPrTx.getMusteriAylikLimit()!=null)
				{
					serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(4));
					serviceMap.put(tableName, row, "CURRENCY_CODE", dovizKodu);
					serviceMap.put(tableName, row, "MAX_AMOUNT", gnlMusislAdetKisitPrTx.getMusteriAylikLimit());
					serviceMap.put(tableName, row, "PROCESS_CODE", gnlMusislAdetKisitPrTx.getProsesKod());
					serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
				}
				if(gnlMusislAdetKisitPrTx.getMusteriGunlukAdet()!=null)
				{
					serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(96));
					serviceMap.put(tableName, row, "CURRENCY_CODE", "ADT");
					serviceMap.put(tableName, row, "MAX_AMOUNT", gnlMusislAdetKisitPrTx.getMusteriGunlukAdet());
					serviceMap.put(tableName, row, "PROCESS_CODE", gnlMusislAdetKisitPrTx.getProsesKod());
					serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
				}
				if(gnlMusislAdetKisitPrTx.getMusteriAylikAdet()!=null)
				{
					serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(97));
					serviceMap.put(tableName, row, "CURRENCY_CODE", "ADT");
					serviceMap.put(tableName, row, "MAX_AMOUNT", gnlMusislAdetKisitPrTx.getMusteriAylikAdet());
					serviceMap.put(tableName, row, "PROCESS_CODE", gnlMusislAdetKisitPrTx.getProsesKod());
					serviceMap.put(tableName, row++, "MIN_AMOUNT", new BigDecimal(0));
				}
				GMServiceExecuter.call("ADK_PROCESS_REMOTE_UPDATE", serviceMap);
			}
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}