package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KibIzlemeEkran;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KibKullOnOnayTx;
import tr.com.calikbank.bnspr.dao.KibKullOnOnayTxId;
import tr.com.calikbank.bnspr.dao.KibKullOnayTx;
import tr.com.calikbank.bnspr.dao.KibKullOnayTxId;
import tr.com.calikbank.bnspr.dao.KibKullislemTx;
import tr.com.calikbank.bnspr.dao.KibKullislemTxId;
import tr.com.calikbank.bnspr.dao.KibKullizlemeTx;
import tr.com.calikbank.bnspr.dao.KibKullizlemeTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.obss.adc.core.pojo.Process;
import tr.com.obss.adc.core.pojo.ProcessLog;
import tr.com.obss.adc.core.pojo.User;
import tr.com.obss.adc.core.pojo.UserMenu;
import tr.com.obss.adc.core.util.ADCCore;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4203Services {
	
	@GraymoundService("BNSPR_QRY4203_TABLO")
	public static GMMap setTables(GMMap iMap)throws ParseException{
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call Pkg_TRN4203.Sorgula (?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_NO"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = iMap.getString("TABLENAME_TBL_ISLEM_YETKISI", "TBL_ISLEM_YETKISI"); 
			int var = 0 ;
				
			while(rSet.next()){
				oMap.put(tableName,var,"ISLEM", rSet.getString("ISLEM"));
				oMap.put(tableName,var,"KULLANICI_LIMIT", rSet.getString("KULLANICI_LIMIT"));
				oMap.put(tableName,var,"YETKI", rSet.getString("YETKI"));
				oMap.put(tableName,var,"DOVIZ_CINSI", rSet.getString("DOVIZ_CINSI"));
				oMap.put(tableName,var,"KANAL_LIMITI", rSet.getString("KANAL_LIMITI"));
				oMap.put(tableName,var,"ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName,var,"PROSES_KOD", rSet.getString("PROSES_KOD"));
				var++;
        	}
			
			rSet = (ResultSet)stmt.getObject(2);
			tableName = iMap.getString("TABLENAME_tblONAY", "tblONAY"); 
			var = 0 ;
				
			while(rSet.next()){
				oMap.put(tableName,var,"ISLEM", rSet.getString("ISLEM"));
				oMap.put(tableName,var,"YETKI", rSet.getString("YETKI"));
				oMap.put(tableName,var,"PROSES_KOD", rSet.getString("PROSES_KOD"));
				oMap.put(tableName,var,"ACIKLAMA", rSet.getString("ACIKLAMA"));
				var++;
        	}
			
			rSet = (ResultSet)stmt.getObject(3);
			tableName = iMap.getString("TABLENAME_tblON_ONAY", "tblON_ONAY"); 
			var = 0 ;
				
			while(rSet.next()){
				oMap.put(tableName,var,"ISLEM", rSet.getString("ISLEM"));
				oMap.put(tableName,var,"YETKI", rSet.getString("YETKI"));
				oMap.put(tableName,var,"PROSES_KOD", rSet.getString("PROSES_KOD"));
				oMap.put(tableName,var,"ACIKLAMA", rSet.getString("ACIKLAMA"));
				var++;
        	}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN4203_SAVE")
	public static Map<?, ?> Save (GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		try {
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");
					
			String tableName = "TBL_ISLEM_YETKISI";
			List<?> recordList = (List<?>)iMap.get(tableName);
			
			for(int i = 0; i < recordList.size(); i++) {
				KibKullislemTxId id = new KibKullislemTxId();
				
				id.setFirmaNo(iMap.getBigDecimal("FIRMA_NO"));
				id.setIslemTanimKod(iMap.getBigDecimal(tableName, i, "ISLEM"));
				id.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU"));
				id.setTxNo(iMap.getBigDecimal("TX_NO"));
				
				KibKullislemTx kibKullislemTx = new KibKullislemTx();
				kibKullislemTx = (KibKullislemTx)session.get(KibKullislemTx.class, id);
				
				if(kibKullislemTx == null) {
					kibKullislemTx = new KibKullislemTx();
				}
				if(iMap.getString(tableName, i, "YETKI")== null || !iMap.getBoolean(tableName, i, "YETKI"))
					kibKullislemTx.setYetkiliEh("0");
				else
					kibKullislemTx.setYetkiliEh("1");
				
			    BigDecimal kullaniciLimiti =iMap.getBigDecimal(tableName, i, "KULLANICI_LIMITI")!= null ? iMap.getBigDecimal(tableName, i, "KULLANICI_LIMITI"):new BigDecimal(0);
			    BigDecimal gunlukLimiti =iMap.getBigDecimal(tableName, i, "KANAL_LIMITI")!= null ? iMap.getBigDecimal(tableName, i, "KANAL_LIMITI"):new BigDecimal(0);
			    
				if(iMap.getString(tableName, i, "YETKI")!= null && iMap.getBoolean(tableName, i, "YETKI") && (iMap.getString(tableName, i, "YETKI") != "0")){
					    if(kullaniciLimiti.compareTo(new BigDecimal(0))==0){
					    	iMap.put("HATA_NO", "1515");
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					    }
			   
				    	if(kullaniciLimiti.compareTo(gunlukLimiti)== 1){
							iMap.put("HATA_NO", "1514");
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						 }
			       } else{
			    	 if(kullaniciLimiti.compareTo(new BigDecimal(0))== 1 ){
					    	iMap.put("HATA_NO", "1517");
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					    }
			       } 
				
				kibKullislemTx.setKullLimit(iMap.getBigDecimal(tableName, i, "KULLANICI_LIMITI")!= null ? iMap.getBigDecimal(tableName, i, "KULLANICI_LIMITI"):new BigDecimal(0));
				kibKullislemTx.setDovizKod(iMap.getString(tableName, i, "DOVIZ_CINSI"));
				kibKullislemTx.setProsesKod(iMap.getString(tableName, i, "PROSES_KOD"));
				kibKullislemTx.setId(id);
				session.saveOrUpdate(kibKullislemTx);
				session.flush();
			}
			
			tableName = "tblON_ONAY";
			recordList = (List<?>)iMap.get(tableName);
			
			for(int i = 0; i < recordList.size(); i++) {
				
					KibKullOnOnayTxId id = new KibKullOnOnayTxId();
					
					id.setFirmaNo(iMap.getBigDecimal("FIRMA_NO"));
					id.setIslemTanimKod(iMap.getBigDecimal(tableName, i, "ISLEM"));
					id.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU"));
					id.setTxNo(iMap.getBigDecimal("TX_NO"));
					
					KibKullOnOnayTx kibKullOnOnayTx = (KibKullOnOnayTx)session.get(KibKullOnOnayTx.class, id);
					
					if(kibKullOnOnayTx == null) {
						kibKullOnOnayTx = new KibKullOnOnayTx();
					}
					if(iMap.getString(tableName, i, "YETKI")== null || !iMap.getBoolean(tableName, i, "YETKI"))
						kibKullOnOnayTx.setYetkiliEh("0");
					else
						kibKullOnOnayTx.setYetkiliEh("1");
					kibKullOnOnayTx.setId(id);
										
					session.saveOrUpdate(kibKullOnOnayTx);
					session.flush();
				}
			
			tableName = "tblONAY";
			recordList = (List<?>)iMap.get(tableName);
			
			for(int i = 0; i < recordList.size(); i++) {
				
					KibKullOnayTxId id = new KibKullOnayTxId();
					
					id.setFirmaNo(iMap.getBigDecimal("FIRMA_NO"));
					id.setIslemTanimKod(iMap.getBigDecimal(tableName, i, "ISLEM"));
					id.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU"));
					id.setTxNo(iMap.getBigDecimal("TX_NO"));
					
					KibKullOnayTx kibKullOnayTx = (KibKullOnayTx)session.get(KibKullOnayTx.class, id);
					
					if(kibKullOnayTx == null) {
						kibKullOnayTx = new KibKullOnayTx();
					}
					if(iMap.getString(tableName, i, "YETKI")== null || !iMap.getBoolean(tableName, i, "YETKI"))
						kibKullOnayTx.setYetkiliEh("0");
					else
						kibKullOnayTx.setYetkiliEh("1");
					kibKullOnayTx.setId(id);
										
					session.saveOrUpdate(kibKullOnayTx);
					session.flush();
			}

			tableName = "tblIZLEME";
			
			for(int i = 0; i < iMap.getSize(tableName); i++) {
				
				KibKullizlemeTxId id = new KibKullizlemeTxId();
				
				id.setFirmaNo(iMap.getBigDecimal("FIRMA_NO"));
				id.setMenuOid(iMap.getString(tableName, i, "MENU_OID"));
				id.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU"));
				id.setTxNo(iMap.getBigDecimal("TX_NO"));
				
				KibKullizlemeTx kibKullIzlemeTx = (KibKullizlemeTx)session.get(KibKullizlemeTx.class, id);
				
				if(kibKullIzlemeTx == null) {
					kibKullIzlemeTx = new KibKullizlemeTx();
				}
				if(iMap.getString(tableName, i, "YETKI")== null || !iMap.getBoolean(tableName, i, "YETKI"))
					kibKullIzlemeTx.setYetkiliEh("0");
				else
					kibKullIzlemeTx.setYetkiliEh("1");
				kibKullIzlemeTx.setId(id);
									
				session.saveOrUpdate(kibKullIzlemeTx);
				session.flush();
		}

			iMap.put("TRX_NO"	, iMap.getBigDecimal("TX_NO"));
			iMap.put("TRX_NAME", "4203");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN4203_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		Connection conn = null;
		CallableStatement stmt = null;
		BigDecimal kullaniciNo = null; 
		BigDecimal firmaNo = null;
		try{
			int row = 0;
			conn = DALUtil.getGMConnection();
			List<?> islemYetkiList = session.createCriteria(KibKullislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "TBL_ISLEM_YETKISI";
			for (Iterator<?> iterator = islemYetkiList.iterator(); iterator.hasNext();row++) {
				KibKullislemTx kullaniciIslem = (KibKullislemTx) iterator.next();
				if(kullaniciIslem.getYetkiliEh()==null || kullaniciIslem.getYetkiliEh().equals("0"))
					oMap.put(tableName, row,"YETKI",false);
				else
									
				    oMap.put(tableName, row,"YETKI",true);
				oMap.put(tableName, row,"ISLEM",kullaniciIslem.getId().getIslemTanimKod());
				oMap.put(tableName, row,"KULLANICI_LIMITI",kullaniciIslem.getKullLimit());
				
				firmaNo = kullaniciIslem.getId().getFirmaNo();
				kullaniciNo = kullaniciIslem.getId().getKullaniciNo();
				oMap.put("FIRMA_NO", firmaNo);
				oMap.put("KULLANICI_KOD", kullaniciNo);
				oMap.put(tableName, row,"DOVIZ_CINSI", kullaniciIslem.getDovizKod());
				oMap.put(tableName, row, "ACIKLAMA",AdcWinspireServices.getProcessName(kullaniciIslem.getProsesKod()));
				oMap.put(tableName, row,"PROSES_KOD",kullaniciIslem.getProsesKod());
				
				
		    	stmt = conn.prepareCall("{ ? = call Pkg_TRN4203.getKanalLimiti(?,?)}");
				int i = 1;	
				stmt.registerOutParameter(i++, Types.DECIMAL); //ref cursor
				stmt.setBigDecimal(i++, firmaNo);
				stmt.setString(i++, kullaniciIslem.getProsesKod());
				stmt.execute();
				if (stmt.getObject(1)!= null)
				oMap.put(tableName, row,"KANAL_LIMITI", stmt.getObject(1));
				
				/*stmt = conn.prepareCall("{? = call PKG_TRN4203.get_islem_Aciklama(?)}");
				stmt.registerOutParameter (1, Types.VARCHAR); 
				stmt.setBigDecimal( 2, kullaniciIslem.getId().getIslemTanimKod());					
				stmt.execute();
				
				oMap.put(tableName, row,"ACIKLAMA", stmt.getObject(1));*/
			}
			if (kullaniciNo != null && firmaNo != null ){
				stmt = conn.prepareCall("{call pkg_trn4203.get_yetkituru(?,?,?,?,?)}");
				stmt.setBigDecimal			(1, firmaNo);
				stmt.setBigDecimal			(2, kullaniciNo);
				stmt.registerOutParameter	(3, Types.CHAR);
				stmt.registerOutParameter	(4, Types.CHAR);
				stmt.registerOutParameter	(5, Types.CHAR);
				stmt.execute();
				oMap.put("FIRMA_YETKI_KOD",stmt.getObject(3));
				oMap.put("FIRMA_ONAY_NO",stmt.getObject(4));
				oMap.put("YETKI_TURU",stmt.getObject(5));
			}
			row=0;
			tableName = "tblON_ONAY";
			List<?>  onOnayList = session.createCriteria(KibKullOnOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = onOnayList.iterator(); iterator.hasNext();row++) {
				KibKullOnOnayTx kullaniciOnay = (KibKullOnOnayTx) iterator.next();
				if(kullaniciOnay.getYetkiliEh()==null || kullaniciOnay.getYetkiliEh().equals("0"))
					oMap.put(tableName, row,"YETKI",false);
				else
					oMap.put(tableName, row,"YETKI",true);
				oMap.put(tableName, row,"ISLEM",kullaniciOnay.getId().getIslemTanimKod());
				
				stmt = conn.prepareCall("{? = call PKG_TRN4203.get_islem_Aciklama(?)}");
				stmt.registerOutParameter (1, Types.VARCHAR); 
				stmt.setBigDecimal( 2, kullaniciOnay.getId().getIslemTanimKod());					
				stmt.execute();
				
				oMap.put(tableName, row,"ACIKLAMA", stmt.getObject(1));
			}
			
			row=0;
			tableName = "tblONAY";
			List<?>  onayList = session.createCriteria(KibKullOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = onayList.iterator(); iterator.hasNext();row++) {
				KibKullOnayTx kullanicionOnay = (KibKullOnayTx) iterator.next();
				if(kullanicionOnay.getYetkiliEh()==null || kullanicionOnay.getYetkiliEh().equals("0"))
					oMap.put(tableName, row,"YETKI",false);
				else
					oMap.put(tableName, row,"YETKI",true);
				oMap.put(tableName, row,"ISLEM",kullanicionOnay.getId().getIslemTanimKod());
				
				stmt = conn.prepareCall("{? = call PKG_TRN4203.get_islem_Aciklama(?)}");
				stmt.registerOutParameter (1, Types.VARCHAR); 
				stmt.setBigDecimal( 2, kullanicionOnay.getId().getIslemTanimKod());					
				stmt.execute();
				
				oMap.put(tableName, row,"ACIKLAMA", stmt.getObject(1));
			}
			
			row=0;
			tableName = "tblIZLEME";
			KibKullizlemeTx kullaniciIzleme = null;
			List<?> izlemeYetkiList = session.createCriteria(KibKullizlemeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = izlemeYetkiList.iterator(); iterator.hasNext();) {
				kullaniciIzleme = (KibKullizlemeTx) iterator.next();
				if(kullaniciIzleme.getYetkiliEh()==null || kullaniciIzleme.getYetkiliEh().equals("0"))
					oMap.put(tableName, row,"YETKI",false);
				else
					oMap.put(tableName, row,"YETKI",true);
				GMMap sMap = new GMMap();
				sMap.put("MENU_OID", kullaniciIzleme.getId().getMenuOid());
				oMap.put(tableName, row++, "EKRAN_ADI", GMServiceExecuter.call("ADK_GET_MENU_NAME", sMap).getString("MENU_NAME"));
			}
			
			GMMap sMap = new GMMap();
			sMap.put("ACTION", "SAVE");
			sMap.put("CHANNEL_CODE", "CINT");
			
			

		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	
	}
	
	@GraymoundService("BNSPR_TRN4203_GET_USER_ONAY_LIST")
	public static GMMap getUserOnayList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			GMMap sMap = new GMMap();
			sMap.put("ACTION", "LIST");
			sMap.put("CHANNEL_CODE", "CINT");
			sMap.put("PARENT_USERNAME", AdcWinspireServices.getUserName(iMap.getString("FIRMA_NO"),iMap.getString("FIRMA_NO")) );
			
			sMap.put("USERNAME", AdcWinspireServices.getUserName(iMap.getString("KULLANICI_KOD"),iMap.getString("FIRMA_NO")));
			sMap.put("PROCESS_CODE", "*");
		
			GMMap rMap = GMServiceExecuter.call("ADC_CORE_PROCESS_APPROVAL_USER_MANAGMENT" , sMap);
			
			sMap.put("LIMIT_TYPE", new BigDecimal(1));
			GMMap pAmountLimitMap = GMServiceExecuter.call("ADK_LIST_USER_PROCESS_AMOUNT_LIMITS" , sMap);
			
			List<?> islemYetkiListTemp = (List<?>)iMap.get("TBL_ISLEM_YETKISI");
			for(int j = 0; j < islemYetkiListTemp.size(); j++) {
				oMap.put("TBL_ISLEM_YETKISI",j,"YETKI",false);
				oMap.put("TBL_ISLEM_YETKISI",j,"ISLEM",iMap.getString("TBL_ISLEM_YETKISI",j,"ISLEM"));
				oMap.put("TBL_ISLEM_YETKISI",j,"ACIKLAMA", AdcWinspireServices.getProcessName(iMap.getString("TBL_ISLEM_YETKISI",j,"PROSES_KOD")));
				/*oMap.put("TBL_ISLEM_YETKISI",j,"ACIKLAMA",iMap.getString("TBL_ISLEM_YETKISI",j,"ACIKLAMA"));*/
				oMap.put("TBL_ISLEM_YETKISI",j,"PROSES_KOD",iMap.getString("TBL_ISLEM_YETKISI",j,"PROSES_KOD"));
				oMap.put("TBL_ISLEM_YETKISI",j,"KULLANICI_LIMIT",iMap.getString("TBL_ISLEM_YETKISI",j,"KULLANICI_LIMIT"));
				oMap.put("TBL_ISLEM_YETKISI",j,"DOVIZ_CINSI",iMap.getString("TBL_ISLEM_YETKISI",j,"DOVIZ_CINSI"));
				oMap.put("TBL_ISLEM_YETKISI",j,"KANAL_LIMITI",iMap.getString("TBL_ISLEM_YETKISI",j,"KANAL_LIMITI"));
				
			}
						
			String tableName = "USER_PROCESS_AMOUNT_LIMITS";
			List<?> recordList = (List<?>)pAmountLimitMap.get(tableName);
			
			
			
			for(int i = 0; recordList != null && i < recordList.size(); i++) {
				
				List<?> islemYetkiList = (List<?>)iMap.get("TBL_ISLEM_YETKISI");
				for(int j = 0; j < islemYetkiList.size(); j++) {
					if(iMap.getString("TBL_ISLEM_YETKISI",j,"PROSES_KOD").equals(pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"PROCESS_CODE")))
					{
						if(new Double(pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"MAX_AMOUNT"))>0)
							oMap.put("TBL_ISLEM_YETKISI",j,"YETKI",true);
						else
							oMap.put("TBL_ISLEM_YETKISI",j,"YETKI",false);
						
						oMap.put("TBL_ISLEM_YETKISI",j,"DOVIZ_CINSI",pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"CURRENCY_CODE"));
						oMap.put("TBL_ISLEM_YETKISI",j,"KULLANICI_LIMITI",pAmountLimitMap.getString("USER_PROCESS_AMOUNT_LIMITS",i,"MAX_AMOUNT"));
					}
				}
				
			}
			
			tableName = "APPROVALS";
			recordList = (List<?>)rMap.get(tableName);
			// E�er firma yetki onay tipi 1
			GMMap xxMap = new GMMap();
			xxMap.put("FIRMA_NO",AdcWinspireServices.getUserName(iMap.getString("FIRMA_NO"),iMap.getString("FIRMA_NO")));
			int flowType = GMServiceExecuter.call("ADK_GET_APPROVAL_FLOW_TYPE", xxMap).getInt("APPROVAL_FLOW_TYPE");
			for(int i = 0;recordList != null && i < recordList.size(); i++) {
				
				if(rMap.getString(tableName,i,"APPROVE_ORDER").equals("2"))
				{
					
					List<?> onayList = (List<?>)iMap.get("ONAY");
					for(int j = 0; j < onayList.size(); j++) {
						if(iMap.getString("ONAY",j,"PROSES_KOD").equals(rMap.getString("APPROVALS",i,"PROCESS_CODE")))
							iMap.put("ONAY",j,"YETKI",true);
					}
				}
				else if(rMap.getString(tableName,i,"APPROVE_ORDER").equals("1"))
				{
					if (flowType==2) {
						List<?> onOnayList = (List<?>)iMap.get("ON_ONAY");
						for(int j = 0; j < onOnayList.size(); j++) {
							if(iMap.getString("ON_ONAY",j,"PROSES_KOD").equals(rMap.getString("APPROVALS",i,"PROCESS_CODE")))
								iMap.put("ON_ONAY",j,"YETKI",true);
						}
					} else if (flowType==1) {
						List<?> onayList = (List<?>)iMap.get("ON_ONAY");
						for(int j = 0; j < onayList.size(); j++) {
							if(iMap.getString("ONAY",j,"PROSES_KOD").equals(rMap.getString("APPROVALS",i,"PROCESS_CODE")))
								iMap.put("ONAY",j,"YETKI",true);
						}
					}
				}
			}
			oMap.put("FIRMA_YETKI_KOD", LovHelper.diLov(iMap.getString("FIRMA_NO"), "4203/LOV_FIRMA_UNVANI", "FIRMA_YETKI_KOD"));
			oMap.put("FIRMA_ONAY", LovHelper.diLov(iMap.getString("FIRMA_NO"), "4203/LOV_FIRMA_UNVANI", "FIRMA_ONAY"));
			oMap.put("ON_ONAY",iMap.get("ON_ONAY"));
			oMap.put("ONAY",iMap.get("ONAY"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	
	}
	
	@GraymoundService("BNSPR_TRN4203_CHECK_APPROVAL_PERMISSION")
	public static GMMap checkApprovalPermission(GMMap iMap) {
		
		if(iMap.getBigDecimal("KULLANICI_KOD").equals(iMap.getBigDecimal("ONAYLAYAN_KULLANICI_KOD")))
			throw new GMRuntimeException(0, "Yetkisiz islem");
		
		String processLogOID=iMap.getString("PROCESS_LOG_OID");
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		ProcessLog processLog = (ProcessLog) session.createCriteria(ProcessLog.class).
		add(Restrictions.eq("oid", processLogOID)).uniqueResult();		
		
		session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		User user = (User)session.createCriteria(User.class).add(Restrictions.eq("oid", processLog.getUserOid())).uniqueResult();
		GMMap onayMap1 = new GMMap();
		onayMap1.put("FIRMA_NO", 					iMap.getBigDecimal("FIRMA_NO", user.getCustomerId()));
		
		onayMap1.put("TABLENAME_TBL_ISLEM_YETKISI", 	"TBL_ISLEM_YETKISI");
		onayMap1.put("TABLENAME_tblONAY", 			"ONAY");
		onayMap1.put("TABLENAME_tblON_ONAY", 		"ON_ONAY");
		onayMap1.putAll(GMServiceExecuter.call("BNSPR_QRY4203_TABLO", onayMap1));
		
		onayMap1.put("KULLANICI_KOD", 				iMap.getBigDecimal("KULLANICI_KOD", user.getUserCustomerId()));
		onayMap1.put("TABLENAME_TBL_ISLEM_YETKISI", 	"TBL_ISLEM_YETKISI");
		onayMap1.put("TABLENAME_tblONAY", 			"ONAY");
		onayMap1.put("TABLENAME_tblON_ONAY", 		"ON_ONAY");
		GMMap onayMap = GMServiceExecuter.call("BNSPR_TRN4203_GET_USER_ONAY_LIST", onayMap1);
		
		boolean onayYetki = false; 
		Process process  = (Process)session.createCriteria(Process.class).add(Restrictions.eq("oid", processLog.getProcessOid())).uniqueResult();
		
		String onayTuru = "ON_ONAY";
		for (int i = 0; i < onayMap.getSize(onayTuru); i++) {
			if(!onayYetki)
				if(onayMap.get(onayTuru, i, "YETKI") != null){
					if(onayMap.getString(onayTuru, i, "PROSES_KOD").equals(process.getCode()) && onayMap.getBoolean(onayTuru, i, "YETKI"))
						onayYetki = true;
				}
		}
		
		onayTuru = "ONAY";
		for (int i = 0; i < onayMap.getSize(onayTuru); i++) {
			if(!onayYetki)
				if(onayMap.get(onayTuru, i, "YETKI") != null){
					if(onayMap.getString(onayTuru, i, "PROSES_KOD").equals(process.getCode()) && onayMap.getBoolean(onayTuru, i, "YETKI"))
						onayYetki = true;
				}
		}
		
		if(!onayYetki)
			throw new GMRuntimeException(0, "Yetkisiz islem");
		
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN4203_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		try {
				conn = DALUtil.getGMConnection();
				
				String tableName = "SELECT_ALL";
				List<?> recordList = (List<?>)iMap.get(tableName);
				String check = iMap.getString("CHECK");
				
				for(int i = 0; i < recordList.size(); i++) {
					
					iMap.put(tableName,i,"YETKI",check);
				}
				
				return iMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	}
	
	@GraymoundService("BNSPR_TRN4203_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		
		GMServiceExecuter.execute("BNSPR_TRN4203_USER_APPROVAL", iMap);
		GMServiceExecuter.execute("BNSPR_TRN4203_LIMIT_APPROVAL", iMap);
		GMServiceExecuter.execute("BNSPR_TRN4203_IZLEME_APPROVAL", iMap);
				
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_TRN4203_USER_APPROVAL")
	public static GMMap userApproval(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
				conn = DALUtil.getGMConnection();
				
				GMMap sMap = new GMMap();
				sMap.put("ACTION", "SAVE");
				sMap.put("CHANNEL_CODE", "CINT");
				
				stmt = conn.prepareCall("{call  PKG_TRN4203.After_Approval_Service_Query(?,?,?,?,?,?)}");
				
				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
				stmt.registerOutParameter(2, java.sql.Types.NUMERIC);
				stmt.registerOutParameter(3, java.sql.Types.NUMERIC);
				stmt.registerOutParameter(4, java.sql.Types.NUMERIC);
				stmt.registerOutParameter(5, -10); //ref cursor
				stmt.registerOutParameter(6, -10); //ref cursor
				stmt.execute();
				
				BigDecimal firmaNo = stmt.getBigDecimal(2);
				BigDecimal kullaniciNo = stmt.getBigDecimal(3);
				BigDecimal yetkiTuru = stmt.getBigDecimal(4);
				
				rSetMSet= (ResultSet)stmt.getObject(5);
				GMMap onay = DALUtil.rSetResults(rSetMSet,"ONAY");
				
				rSetMSet= (ResultSet)stmt.getObject(6);
				GMMap onOnay = DALUtil.rSetResults(rSetMSet,"ON_ONAY");
				
				sMap.put("PARENT_USERNAME", AdcWinspireServices.getUserName(firmaNo,firmaNo) );
				
				sMap.put("USERNAME", AdcWinspireServices.getUserName(kullaniciNo,firmaNo));
				int listRow=0;
				if(yetkiTuru!=null){
					if(yetkiTuru.toString().equals("1")||yetkiTuru.toString().equals("2"))
					{
						String tableName = "ONAY";
						List<?> recordList = (List<?>)onay.get(tableName);
						if(recordList != null)
						for(int i = 0; i < recordList.size(); i++) {
							sMap.put("LIST"	, listRow, "APPROVE_ORDER",new BigDecimal(1));
							sMap.put("LIST"	, listRow, "APPROVE_COUNT",new BigDecimal(1));
							sMap.put("LIST"	, listRow, "PROCESS_CODE",onay.getString(tableName,i,"PROSES_KOD"));
							listRow++;
						}
					}
					else
					{
						String tableName = "ONAY";
						List<?> recordList = (List<?>)onay.get(tableName);
						if(recordList != null)
						for(int i = 0; i < recordList.size(); i++) {
							if(yetkiTuru.toString().equals("4"))
								sMap.put("LIST"	, listRow, "APPROVE_COUNT",new BigDecimal(2));
							else
								sMap.put("LIST"	, listRow, "APPROVE_COUNT",new BigDecimal(1));
							sMap.put("LIST"	, listRow, "APPROVE_ORDER",new BigDecimal(2));
							sMap.put("LIST"	, listRow, "PROCESS_CODE",onay.getString(tableName,i,"PROSES_KOD"));
							listRow++;
						}
						
						tableName = "ON_ONAY";
						recordList = (List<?>)onOnay.get(tableName);
						
						if(recordList != null)
						for(int i = 0; i < recordList.size(); i++) {
							
							if(yetkiTuru.toString().equals("4"))
								sMap.put("LIST"	, listRow, "APPROVE_COUNT",new BigDecimal(2));
							else
								sMap.put("LIST"	, listRow, "APPROVE_COUNT",new BigDecimal(1));
							sMap.put("LIST"	, listRow, "APPROVE_ORDER",new BigDecimal(1));
							sMap.put("LIST"	, listRow, "PROCESS_CODE",onOnay.getString(tableName,i,"PROSES_KOD"));
							listRow++;
						}
					}
					GMServiceExecuter.call("ADC_CORE_PROCESS_APPROVAL_USER_MANAGMENT" , sMap);
				}

				return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN4203_LIMIT_APPROVAL")
	public static GMMap limitApproval(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap serviceMap = new GMMap();
			int row = 0;
			KibKullislemTx kullaniciIslem = null;
			List<?> islemYetkiList = session.createCriteria(KibKullislemTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			String tableName = "LIMITS";
			if (islemYetkiList!= null && !islemYetkiList.isEmpty()){
				for (Iterator<?> iterator = islemYetkiList.iterator(); iterator.hasNext();) {
					kullaniciIslem = (KibKullislemTx) iterator.next();
					if(kullaniciIslem.getYetkiliEh() !=null && kullaniciIslem.getYetkiliEh().equals("1"))
					{
						serviceMap.put(tableName, row, "MAX_AMOUNT", kullaniciIslem.getKullLimit());
					}
					else
					{
						serviceMap.put(tableName, row, "MAX_AMOUNT", new BigDecimal(0));
					}
						serviceMap.put(tableName, row, "FLAG", "S");
						serviceMap.put(tableName, row, "LIMIT_TYPE", new BigDecimal(1));
						serviceMap.put(tableName, row, "CURRENCY_CODE", kullaniciIslem.getDovizKod());
						serviceMap.put(tableName, row, "MIN_AMOUNT", new BigDecimal(0));
						serviceMap.put(tableName, row, "PROCESS_CODE", kullaniciIslem.getProsesKod());
					
						row++;
		
				}
				serviceMap.put("USERNAME",AdcWinspireServices.getUserName(kullaniciIslem.getId().getKullaniciNo(),kullaniciIslem.getId().getFirmaNo()) );
				serviceMap.put("CHANNEL_CODE", "CINT");
				serviceMap.put("ACTION", "UPDATE");
				GMServiceExecuter.call("ADK_PROCESS_REMOTE_UPDATE", serviceMap);
			}
			return new GMMap();

		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN4203_IZLEME_APPROVAL")
	public static GMMap izlemeApproval(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			Session adcSession = DAOSession.getSession("ADCCore");
			String userOid = null;
			
			KibKullizlemeTx kullaniciIzleme = null;
			List<?> izlemeYetkiList = session.createCriteria(KibKullizlemeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
			for (Iterator<?> iterator = izlemeYetkiList.iterator(); iterator.hasNext();) {
				kullaniciIzleme = (KibKullizlemeTx) iterator.next();
				if(userOid==null){
					String kullaniciNo = AdcWinspireServices.getUserName(kullaniciIzleme.getId().getKullaniciNo(),
																		 kullaniciIzleme.getId().getFirmaNo());
					User user = (User)(adcSession.createCriteria(User.class).add(Restrictions.eq("username", kullaniciNo)).uniqueResult());						
					userOid = user.getOid();
				}
				UserMenu bannedMenu = (UserMenu)adcSession.createCriteria(UserMenu.class)
													.add(Restrictions.eq("userOid", userOid))
													.add(Restrictions.eq("menuOid", kullaniciIzleme.getId().getMenuOid())).uniqueResult();
				if("0".equals(kullaniciIzleme.getYetkiliEh())){
					if(bannedMenu == null){
						bannedMenu = new UserMenu();
						bannedMenu.setMenuOid(kullaniciIzleme.getId().getMenuOid());
						bannedMenu.setUserOid(userOid);
						adcSession.save(bannedMenu);						
					}
				}
				else if("1".equals(kullaniciIzleme.getYetkiliEh())){
					if(bannedMenu != null)
						adcSession.delete(bannedMenu);						
				}
			}
			return new GMMap();

		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN4203_GET_IZLEME_LIST")
	public static GMMap getIzlemeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
				
		try{
			int row = 0;
			List<?> izlemeEkranList = session.createCriteria(KibIzlemeEkran.class).list();
			String tableName = "TBL_IZLEME";
			for (Iterator<?> iterator = izlemeEkranList.iterator(); iterator.hasNext();row++) {
				KibIzlemeEkran izlemeEkran = (KibIzlemeEkran) iterator.next();
				GMMap sMap = new GMMap();
				sMap.put("MENU_OID", izlemeEkran.getMenuOid());
				String menuName = GMServiceExecuter.call("ADK_GET_MENU_NAME", sMap).getString("MENU_NAME");
				sMap.clear();
				sMap.put("MENU_OID", izlemeEkran.getMenuOid());
				sMap.put("USERNAME", AdcWinspireServices.getUserName(iMap.getString("KULLANICI_KODU"),iMap.getString("FIRMA_NO")));
				boolean kisitli = GMServiceExecuter.call("ADK_IS_USER_MENU_RESTRICTED", sMap).getBoolean("RESTRICTED");
				if(kisitli){
					oMap.put(tableName, row, "YETKI", false);					
				}
				else{
					oMap.put(tableName, row, "YETKI", true);					
				}
				oMap.put(tableName, row, "EKRAN_ADI", menuName);
				oMap.put(tableName, row, "MENU_OID", izlemeEkran.getMenuOid());
			}
			
		} 
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally { 
			
		}
		
		return oMap;
	
	}
}