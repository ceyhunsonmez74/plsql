package tr.com.calikbank.bnspr.adc.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkStandTanimTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4101Services {
	@GraymoundService("BNSPR_TRN4101_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			iMap.put("KOD", "STAND_ONEM_DERECE_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("STAND_ONEM_DERECE_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "STAND_STATU_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("DURUM_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "STAND_RISK_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("STAND_RISK_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "STAND_TUR_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("STAND_TUR_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "STAND_LOKASYON_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("STAND_LOKASYON_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "STAND_KRE_TURU");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KRD_TUR_KODLARI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			
			iMap.put("KOD", "CALISMA_SEKLI_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("STAND_CALISMA_SEKLI_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "STAND_KAPANMA_NEDEN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KAPAMA_NEDEN_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "YETKI_SEVIYE_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("YETKI_SEVIYE_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
		

	@GraymoundService("BNSPR_TRN4101_GET_KRD_TUR_KODLARI")
	public static GMMap getKrediTurKodlari(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
		    GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
	        stmt = conn.prepareCall("{? = call pkg_rc_adc.RC_QRY4101_Kredi_Turleri}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); // ref cursor
			String tableName = "KRD_TUR_KODLARI";
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);
		return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}	
	}

	@GraymoundService("BNSPR_TRN4101_GET_KISMI_KAPAMA_NEDEN_KOD")
	public static GMMap getKismiKapamaNedenKod(GMMap iMap){
		if (iMap.getString("DURUM_KOD").equals("KK"))
			return DALUtil.fillComboBox(iMap, "KAPAMA_NEDEN_KOD", true, " SELECT key1,text FROM v_ml_gnl_param_text WHERE KOD = 'STAND_KISMI_KAPANMA_NEDEN_KOD'");
		else if (iMap.getString("DURUM_KOD").equals("K"))return DALUtil.fillComboBox(iMap, "KAPAMA_NEDEN_KOD", true, "SELECT key1,text FROM v_ml_gnl_param_text WHERE KOD = 'STAND_KAPANMA_NEDEN_KOD'");
		else return new GMMap();
	}
	
  @GraymoundService("BNSPR_QRY4101_GET_STANDMOBO")
	public static GMMap getStandMobo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_rc_adc.RC_QRY4101_GET_STANDMOBO(?,?,?,?,?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++,iMap.getString("KOD"));
			stmt.setString(i++,iMap.getString("KANAL_KOD"));
			stmt.setString(i++,iMap.getString("STAND_TUR_KOD"));                              
			stmt.setString(i++,iMap.getString("STAND_RISK_KOD"));   
			stmt.setString(i++,iMap.getString("STAND_ONEM_DERECE_KOD"));  
			stmt.setString(i++,iMap.getString("IL_KOD"));  
			stmt.setString(i++,iMap.getString("BAGLI_OLD_BOLGE_KOD"));  
			stmt.setString(i++,iMap.getString("DURUM_KOD"));  
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			String tableName = "STANDMOBO";
			oMap = DALUtil.rSetResults(rSet, tableName);
			for (int row = 0; row < oMap.getSize(tableName); row++) {
				oMap.put(tableName, row, "BOLGE_ADI", LovHelper.diLov(oMap.get(tableName,row,"BAGLI_OLD_BOLGE_KOD"), "4101/LOV_BOLGE_GRUBU", "TEXT"));
				
			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	}	
  
  
  public static void parseKrediTurKod(GMMap iMap, String tableName, String krediTurKod){
		try{ 
		 	char[]   chars =  krediTurKod.toCharArray() ;
			for(int i = 0 ;i<chars.length; i++){
				if (chars[i] == '1'){
				iMap.put(tableName, i, "SEC", "1");
				}else iMap.put(tableName, i, "SEC", "0");
			}
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
  
	
  @GraymoundService("BNSPR_QRY4101_GET_GUNCELLEME")
	public static GMMap getGuncelleme(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_rc_adc.RC_QRY4101_GET_GUNCELLEME(?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++,iMap.getString("KOD"));
			stmt.execute();
			rSetMSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSetMSet);
			if (oMap.getString("KAPAMA_NEDEN_KOD") != null)
		     	oMap.put("KAPAMA_NEDEN_KOD", oMap.get("KAPAMA_NEDEN_KOD").toString());
			if (oMap.getString("TEL_NO") != null){
				oMap.put("TEL_KOD",oMap.getString("TEL_NO").substring(0,3));
			    oMap.put("TELEFON_NO",oMap.getString("TEL_NO").substring(3));
			}
		    if (oMap.getString("FAKS_NO") != null){
			   oMap.put("FAKS_TEL_KOD",oMap.getString("FAKS_NO").substring(0,3));
			   oMap.put("FAKS_TELEFON_NO",oMap.getString("FAKS_NO").substring(3));
		    }
            oMap.put("DI_KANAL_KOD", LovHelper.diLov(oMap.getString("KANAL_KOD"), "4101/LOV_KANAL_GRUBU", "ACIKLAMA")); 
            oMap.put("DI_BOLGE_KOD", LovHelper.diLov(oMap.getString("BAGLI_OLD_BOLGE_KOD"), "4101/LOV_BOLGE_GRUBU", "TEXT")); 
            oMap.put("DI_BAGLI_OLDUGU_YER_KOD", LovHelper.diLov(oMap.getString("STAND_BAGLI_OLD_YER_KOD"), "4101/LOV_KANAL_GRUBU", "ACIKLAMA")); 
            oMap.put("DI_AYLIK_KREDI_HACMI_DC", LovHelper.diLov(oMap.getString("AYLIK_KREDI_HACMI_DOV"), "4101/LOV_DOVIZ_CINSI", "ACIKLAMA")); 
            oMap.put("DI_GUNLUK_KREDI_HACMI_DC", LovHelper.diLov(oMap.getString("GUNLUK_KREDI_HACMI_DOV"), "4101/LOV_DOVIZ_CINSI", "ACIKLAMA")); 
            oMap.put("DI_IL_KOD", LovHelper.diLov(oMap.getString("IL_KOD"), "4101/LOV_ADRES_IL", "IL_ADI")); 
            oMap.put("DI_ILCE_KOD", LovHelper.diLov(oMap.getString("ILCE_KOD"),oMap.getString("IL_KOD"),"4101/LOV_ADRES_ILCE", "ILCE_ADI")); 
            oMap.put("TEMP_ILKOD", oMap.get("IL_KOD"));
            String degisken =oMap.getString("KRD_TUR_KODLARI");
            oMap.putAll(getKrediTurKodlari(new GMMap()));
            parseKrediTurKod(oMap,"KRD_TUR_KODLARI",degisken);
            
           
          
            
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	}	
	
	@GraymoundService("BNSPR_QRY4101_GET_BAYILER")
	public static GMMap getBayiler(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_rc_adc.RC_QRY4101_BAYILER}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			String tableName = "BAYILER";
			//oMap = DALUtil.rSetResults(rSet, tableName);
			int row = 0;	
			while (rSet.next()) {
			
			oMap.put(tableName, row, "KOD", rSet.getBigDecimal("kod"));
			oMap.put(tableName, row, "SATICI_ADI", rSet.getString("satici_adi"));
			oMap.put(tableName, row, "ILGILIBAYI", false);
			row++;
			
		}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	}	

	public static String prepareKrediTurKod(GMMap iMap){
		StringBuilder krediTurKod = new StringBuilder();
		String tableName = "KRD_TUR_KODLARI";
		List<?> list = (List<?>)iMap.get(tableName);
		for (int i=0; i<list.size();i++) {
			if (iMap.getString(tableName,i,"SEC") == null)
			  krediTurKod.append("0");
			else if(iMap.getString(tableName,i,"SEC").equals("1")){
			  krediTurKod.append("1");
			}
			else krediTurKod.append("0");
		}
			return krediTurKod.toString();
	}
	
	
	
	@GraymoundService("BNSPR_TRN4101_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			AdkStandTanimTx adkStandTanimTx = (AdkStandTanimTx) session.get(AdkStandTanimTx.class, iMap
					.getBigDecimal("TRX_NO"));
			if (adkStandTanimTx == null)
				adkStandTanimTx = new AdkStandTanimTx();
			
			adkStandTanimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			adkStandTanimTx.setKanalKod(iMap.getString("KANAL_KOD"));
			adkStandTanimTx.setKod(iMap.getBigDecimal("KOD"));
			adkStandTanimTx.setAciklama(iMap.getString("ACIKLAMA"));
			adkStandTanimTx.setOrjEvrakGonderimSure(iMap.getBigDecimal("ORJ_EVRAK_GONDERIM_SURE"));
			adkStandTanimTx.setStandTurKod(iMap.getString("STAND_TUR_KOD"));
			adkStandTanimTx.setStandCalismaSekliKod(iMap.getString("STAND_CALISMA_SEKLI_KOD"));
			adkStandTanimTx.setStandOnemDereceKod(iMap.getString("STAND_ONEM_DERECE_KOD"));
			adkStandTanimTx.setStandRiskKod(iMap.getString("STAND_RISK_KOD"));
			adkStandTanimTx.setBagliOldBolgeKod(iMap.getString("BAGLI_OLD_BOLGE_KOD"));
			adkStandTanimTx.setStandBagliOldYerKod(iMap.getString("STAND_BAGLI_OLD_YER_KOD"));
			adkStandTanimTx.setStandLokasyonKod(iMap.getString("STAND_LOKASYON_KOD"));
			adkStandTanimTx.setKrdTurKodlari(prepareKrediTurKod(iMap));
			adkStandTanimTx.setAylikKrediHacmi(iMap.getBigDecimal("AYLIK_KREDI_HACMI"));
			adkStandTanimTx.setAylikKrediHacmiDov(iMap.getString("AYLIK_KREDI_HACMI_DOV"));
			adkStandTanimTx.setGunlukKrediHacmi(iMap.getBigDecimal("GUNLUK_KREDI_HACMI"));
			adkStandTanimTx.setGunlukKrediHacmiDov(iMap.getString("GUNLUK_KREDI_HACMI_DOV"));
			adkStandTanimTx.setAdres(iMap.getString("ADRES"));
			adkStandTanimTx.setIlKod(iMap.getString("IL_KOD"));
			adkStandTanimTx.setIlceKod(iMap.getString("ILCE_KOD"));
			adkStandTanimTx.setSemt(iMap.getString("SEMT"));
			if (iMap.getString("TELEFON_NO") != null && !iMap.getString("TELEFON_NO").equals(""))
			adkStandTanimTx.setTelNo(iMap.getString("TEL_KOD") + iMap.getString("TELEFON_NO"));
			if (iMap.getString("FAKS_TELEFON_NO") != null && !iMap.getString("FAKS_TELEFON_NO").equals(""))
			adkStandTanimTx.setFaksNo(iMap.getString("FAKS_TEL_KOD") + iMap.getString("FAKS_TELEFON_NO"));
			adkStandTanimTx.setEmail(iMap.getString("EMAIL"));
			adkStandTanimTx.setDurumKod(iMap.getString("DURUM_KOD"));
			adkStandTanimTx.setKapamaNedenKod(iMap.getString("KAPAMA_NEDEN_KOD"));
			adkStandTanimTx.setTarih(iMap.getDate("TARIH"));
			adkStandTanimTx.setKapanisSaati(iMap.getString("KAPANIS_SAATI"));
			adkStandTanimTx.setYetkiSeviyeKod(iMap.getString("YETKI_SEVIYE_KOD"));
			session.saveOrUpdate(adkStandTanimTx);
			session.flush();

			iMap.put("TRX_NAME", "4101");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (ConstraintViolationException e) {
			throw new GMRuntimeException(0,e.getCause().getMessage());
		} catch (Exception e) {
			 throw new GMRuntimeException(0,e);	
		}
	}
	
	@GraymoundService("BNSPR_TRN4101_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
	
				Session session = DAOSession.getSession("BNSPRDal");

				GMMap oMap = new GMMap();
				
				AdkStandTanimTx adkStandTanimTx = (AdkStandTanimTx) session.createCriteria(AdkStandTanimTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
				
				oMap.put("KOD", adkStandTanimTx.getKod());
				oMap.put("KANAL_KOD", adkStandTanimTx.getKanalKod());
				oMap.put("DI_KANAL_KOD", LovHelper.diLov(adkStandTanimTx.getKanalKod(), "4101/LOV_KANAL_GRUBU", "ACIKLAMA")); 
				oMap.put("KOD", adkStandTanimTx.getKod());
				oMap.put("ACIKLAMA", adkStandTanimTx.getAciklama());
				oMap.put("ORJ_EVRAK_GONDERIM_SURE", adkStandTanimTx.getOrjEvrakGonderimSure()); 
				oMap.put("STAND_TUR_KOD", adkStandTanimTx.getStandTurKod());
				oMap.put("STAND_CALISMA_SEKLI_KOD", adkStandTanimTx.getStandCalismaSekliKod()); 
				oMap.put("STAND_ONEM_DERECE_KOD",adkStandTanimTx.getStandOnemDereceKod());
				oMap.put("STAND_RISK_KOD",adkStandTanimTx.getStandRiskKod());
				oMap.put("BAGLI_OLD_BOLGE_KOD",adkStandTanimTx.getBagliOldBolgeKod());
				oMap.put("DI_BOLGE_KOD", LovHelper.diLov(adkStandTanimTx.getBagliOldBolgeKod(), "4101/LOV_BOLGE_GRUBU", "TEXT")); 
				oMap.put("STAND_BAGLI_OLD_YER_KOD",adkStandTanimTx.getStandBagliOldYerKod());
				oMap.put("DI_BAGLI_OLDUGU_YER_KOD", LovHelper.diLov(adkStandTanimTx.getStandBagliOldYerKod(), "4101/LOV_KANAL_GRUBU", "ACIKLAMA")); 
				oMap.put("STAND_LOKASYON_KOD",adkStandTanimTx.getStandLokasyonKod());
				oMap.put("KRD_TUR_KODLARI",adkStandTanimTx.getKrdTurKodlari());				
				oMap.put("AYLIK_KREDI_HACMI",adkStandTanimTx.getAylikKrediHacmi());
				oMap.put("AYLIK_KREDI_HACMI_DOV",adkStandTanimTx.getAylikKrediHacmiDov());
				oMap.put("DI_AYLIK_KREDI_HACMI_DC", LovHelper.diLov(adkStandTanimTx.getAylikKrediHacmiDov(), "4101/LOV_DOVIZ_CINSI", "ACIKLAMA")); 
				oMap.put("GUNLUK_KREDI_HACMI",adkStandTanimTx.getGunlukKrediHacmi());
				oMap.put("GUNLUK_KREDI_HACMI_DOV",adkStandTanimTx.getGunlukKrediHacmiDov());
				oMap.put("DI_GUNLUK_KREDI_HACMI_DC", LovHelper.diLov(adkStandTanimTx.getGunlukKrediHacmiDov(), "4101/LOV_DOVIZ_CINSI", "ACIKLAMA")); 
				oMap.put("ADRES",adkStandTanimTx.getAdres());
				oMap.put("IL_KOD",adkStandTanimTx.getIlKod());
				oMap.put("DI_IL_KOD", LovHelper.diLov(adkStandTanimTx.getIlKod(), "4101/LOV_ADRES_IL", "IL_ADI")); 
				oMap.put("ILCE_KOD",adkStandTanimTx.getIlceKod());
				oMap.put("DI_ILCE_KOD", LovHelper.diLov(adkStandTanimTx.getIlceKod(),adkStandTanimTx.getIlKod(), "4101/LOV_ADRES_ILCE", "ILCE_ADI")); 
				oMap.put("SEMT",adkStandTanimTx.getSemt());
				if (adkStandTanimTx.getTelNo()!= null){
				oMap.put("TEL_KOD",adkStandTanimTx.getTelNo().substring(0,3));
				oMap.put("TELEFON_NO",adkStandTanimTx.getTelNo().substring(3));
				}
				if (adkStandTanimTx.getFaksNo() != null){
				oMap.put("FAKS_TEL_KOD",adkStandTanimTx.getFaksNo().substring(0,3));
				oMap.put("FAKS_TELEFON_NO",adkStandTanimTx.getFaksNo().substring(3));
				}
				oMap.put("EMAIL",adkStandTanimTx.getEmail());
				oMap.put("DURUM_KOD",adkStandTanimTx.getDurumKod());
				oMap.put("KAPAMA_NEDEN_KOD",adkStandTanimTx.getKapamaNedenKod());
				oMap.put("TARIH",adkStandTanimTx.getTarih());
				oMap.put("KAPANIS_SAATI",adkStandTanimTx.getKapanisSaati());
				oMap.put("YETKI_SEVIYE_KOD",adkStandTanimTx.getYetkiSeviyeKod());
				String degisken = adkStandTanimTx.getKrdTurKodlari();
	            oMap.putAll(getKrediTurKodlari(new GMMap()));
	            parseKrediTurKod(oMap,"KRD_TUR_KODLARI",degisken);
						
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
	
	 @GraymoundService("BNSPR_QRY4101_GET_TARIHCE")
		public static GMMap getTarihce(GMMap iMap) {
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			try {
				GMMap oMap = new GMMap();
				conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call pkg_rc_adc.RC_QRY4101_GET_TARIHCE(?)}");
				int i = 1;	
				stmt.registerOutParameter(i++, -10); //ref cursor
				stmt.setString(i++,iMap.getString("KOD"));
				stmt.execute();
				String tableName = "STAND_STATU_TARIHCESI";
				rSet = (ResultSet)stmt.getObject(1);
				oMap = DALUtil.rSetResults(rSet, tableName);
				
				return oMap;

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
				
			}
		
		}	
	
	
}

