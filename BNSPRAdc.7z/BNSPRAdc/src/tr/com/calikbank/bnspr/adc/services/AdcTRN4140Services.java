package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkBannerPageTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcTRN4140Services {
	
    @GraymoundService("BNSPR_TRN4140_BANNER_PAGE_LIST")
    public static GMMap BannerPageList(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	try {
   		GMMap myMap = new GMMap(GMServiceExecuter.execute("ADC_MAN_BANNER_PAGE_LIST", iMap));
		
		for(int i = 0;i < myMap.getSize("LIST");i++) {
			
              //oMap.put(TableName,i,"OID",myMap.get("OID"));
                oMap.put("T_BANNERPAGE",i,"BANNER_KEY",myMap.get("LIST",i,"BANNER_KEY"));
                oMap.put("T_BANNERPAGE",i,"BANNER_PAGE",myMap.get("LIST",i,"BANNER_PAGE_NAME"));
           }
        return oMap;
	    }
		 catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}  
		    	
    }

    @GraymoundService("BNSPR_TRN4140_SAVE")
    public static GMMap saveTRN4140(GMMap iMap){
    	try {
    		Session session = DAOSession.getSession("BNSPRDal");
    		AdkBannerPageTx adkBannerPageTx = new AdkBannerPageTx();

    		String bannerKey = iMap.getString("BANNER_KEY");
    		String GDS = iMap.getString("G_D_S");

    		if(bannerKey == null || bannerKey.isEmpty())
    		{
    			iMap.put("HATA_NO", new BigDecimal(330));
    			iMap.put("P1", "Banner Key");
    			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
    		}	

    		if (("G").equals(GDS)) {
    			GMMap myMap = new GMMap(GMServiceExecuter.execute(
    					"ADC_MAN_BANNER_PAGE_LIST", iMap));
    			for (int i = 0; i < myMap.getSize("LIST"); i++) {
    				if ((iMap.getString("BANNER_KEY")).equals(myMap.get("LIST",
    						i, "BANNER_KEY"))) {
    					iMap.put("HATA_NO", new BigDecimal(716));
    					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ",
    							iMap);
    				}
    			}
    		}
    		if("S".equals(GDS)){
    			GMMap serviceMap = new GMMap();
    				serviceMap.put("BANNER_PAGE_KEY", bannerKey);
    				serviceMap.put("SERVICE_NAME","ADC_MAN_BANNER_PAGE_DELETE_CONTROL");
				GMServiceExecuter.call("ADK_CALL_SERVICE", serviceMap); 

    		}

    		adkBannerPageTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
    		adkBannerPageTx.setBannerKey(bannerKey);
    		adkBannerPageTx.setBannerPage(iMap.getString("BANNER_PAGE"));
    		adkBannerPageTx.setGDS(GDS);

    		session.saveOrUpdate(adkBannerPageTx);
    		session.flush();

    		iMap.put("TRX_NAME", "4140");
    		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
    	}
    	catch (Exception e) {
    		System.out.println(e);
    		throw ExceptionHandler.convertException(e);
    	}

    }	

  	@GraymoundService("BNSPR_TRN4140_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
  	   try{
			Session session = DAOSession.getSession("BNSPRDal");
			AdkBannerPageTx adkBannerPageTx = (AdkBannerPageTx) session.createCriteria(AdkBannerPageTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			GMMap serviceMap = new GMMap();
				serviceMap.put("BANNER_PAGE_KEY", adkBannerPageTx.getBannerKey());
				serviceMap.put("BANNER_PAGE_NAME", adkBannerPageTx.getBannerPage());
				if ("G".equals(adkBannerPageTx.getGDS())){
				serviceMap.put("SERVICE_NAME","ADC_MAN_BANNER_PAGE_CREATE");
				}else if("D".equals(adkBannerPageTx.getGDS())){
			    serviceMap.put("BANNER_PAGE", adkBannerPageTx.getBannerPage());
				serviceMap.put("SERVICE_NAME","ADC_MAN_BANNER_PAGE_UPDATE");
				}else if("S".equals(adkBannerPageTx.getGDS())){
				serviceMap.put("SERVICE_NAME","ADC_MAN_BANNER_PAGE_DELETE");
				}
				GMServiceExecuter.call("ADK_CALL_SERVICE", serviceMap); 
	   
	     return new GMMap();
	     }
		 catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
  	}
  	
  	@GraymoundService("BNSPR_TRN4140_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GMMap oMap = new GMMap();
			List<?> list = (List<?>) session.createCriteria(AdkBannerPageTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				AdkBannerPageTx adkBannerPageTx = (AdkBannerPageTx) iterator.next();
				oMap.put("BANNER_KEY", adkBannerPageTx.getBannerKey());
				oMap.put("BANNER_PAGE", adkBannerPageTx.getBannerPage());
				oMap.put("G_D_S", adkBannerPageTx.getGDS());
				oMap.put("TRX_NO", adkBannerPageTx.getTxNo());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
}
