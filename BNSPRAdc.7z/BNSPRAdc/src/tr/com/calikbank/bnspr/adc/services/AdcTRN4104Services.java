package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkStandCalisaniliskiTx;
import tr.com.calikbank.bnspr.dao.AdkStandCalisaniliskiTxId;
import tr.com.calikbank.bnspr.dao.AdkStandRoliliskiTx;
import tr.com.calikbank.bnspr.dao.AdkStandRoliliskiTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


/**
 * @author obss2
 *
 */
public class AdcTRN4104Services {
	
	@GraymoundService("BNSPR_TRN4104_SET_RECORDS")
	public static GMMap getTransactionNo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN4104.Stand_Cal_Iliski(?,?) }");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(2, iMap.getString("KULLANICI_KODU"));
			stmt.execute();
		return oMap;
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN4104_GET_MASTER")
	public static GMMap getMasterRecords(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			String tableName = "STANDMOBO_MASTER";
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(AdkStandCalisaniliskiTx.class)
											.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
											.add(Restrictions.eq("id.calisanKod", iMap.getString("KULLANICI_KOD")));
			List<?> recordList = (List<?>) criteria.list();

			for (int row = 0; row < recordList.size(); row++){
				AdkStandCalisaniliskiTx adkStandCalisaniliskiTx = (AdkStandCalisaniliskiTx) recordList.get(row);

				//oMap.put(tableName, row, "KULLANICI_KODU"		, adkStandCalisaniliskiTx.getId().getCalisanKod());
				oMap.put(tableName, row, "KOD"		, adkStandCalisaniliskiTx.getId().getStandKod());
				oMap.put(tableName, row, "BASLANGIC_TAR"	, adkStandCalisaniliskiTx.getBaslangicTar());
				oMap.put(tableName, row, "BITIS_TAR"		, adkStandCalisaniliskiTx.getBitisTar());
				oMap.put(tableName, row, "SIL"				, false);
				oMap.put(tableName, row, "ACIKLAMA", 
											LovHelper.diLov(adkStandCalisaniliskiTx.getId().getStandKod(), "4104/LOV_STANDMOBO", "ACIKLAMA"));
				
				oMap.put(tableName, row, "DETAIL_DATA",	new ArrayList<GMMap>());				
				oMap.put(tableName, row, "FLAG",		false);				
				oMap.put(tableName, row, "F_NEW",		false);
				
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4104_GET_DETAIL")
	public static GMMap getDetailRecords(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			String tableName = "ROL_DETAIL";
			Session session = DAOSession.getSession("BNSPRDal"); 
			
			Criteria criteria = session.createCriteria(AdkStandRoliliskiTx.class)
										.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
										.add(Restrictions.eq("id.calisanKod", iMap.getString("KULLANICI_KOD")))
										.add(Restrictions.eq("id.standKod", iMap.getBigDecimal("STANDMOBO_KOD")));
			List<?> recordList = (List<?>) criteria.list();
			

			for (int row = 0; row < recordList.size(); row++){
				AdkStandRoliliskiTx adkStandRoliliskiTx = (AdkStandRoliliskiTx) recordList.get(row);

				oMap.put(tableName, row, "ROL_NUMARA", adkStandRoliliskiTx.getId().getRolKod());
				oMap.put(tableName, row, "BASLANGIC_TAR",	adkStandRoliliskiTx.getBaslangicTar());
				oMap.put(tableName, row, "BITIS_TAR", 	adkStandRoliliskiTx.getBitisTar());
				oMap.put(tableName, row, "ROL_ADI",
														LovHelper.diLov(adkStandRoliliskiTx.getId().getRolKod(), "4104/LOV_ROL", "TANIM"));
				oMap.put(tableName, row, "SIL_DETAIL",		(adkStandRoliliskiTx.getSil().equals("S")) ? true : false);				
				oMap.put(tableName, row, "F_NEW_DETAIL",		false);
			}
			
		
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN4104_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
	
		try {
			Session session 	= DAOSession.getSession("BNSPRDal");
			String tableName 	= "STANDMOBO_MASTER";

			List<?> recordList = (List<?>)iMap.get(tableName);
			
			for (int row = 0;row<recordList.size();row++) {
				String kullaniciKodu_FK = iMap.getString("KULLANICI_KODU");
				BigDecimal standmoboKodu_FK = iMap.getBigDecimal(tableName, row, "KOD");
				
				AdkStandCalisaniliskiTxId id = new AdkStandCalisaniliskiTxId();
				id.setCalisanKod	(kullaniciKodu_FK);
				id.setTxNo		(iMap.getBigDecimal("TRX_NO"));
				id.setStandKod(standmoboKodu_FK);
				
				AdkStandCalisaniliskiTx adkStandCalisaniliskiTx = (AdkStandCalisaniliskiTx)session.get(AdkStandCalisaniliskiTx.class, id);
				if(adkStandCalisaniliskiTx == null) {
					adkStandCalisaniliskiTx = new AdkStandCalisaniliskiTx();
				}
				
				adkStandCalisaniliskiTx.setId			(id);
				adkStandCalisaniliskiTx.setBaslangicTar(iMap.getDate(tableName, row, "BASLANGIC_TAR"));
				adkStandCalisaniliskiTx.setBitisTar(iMap.getDate(tableName, row, "BITIS_TAR"));
				adkStandCalisaniliskiTx.setSil(iMap.getBoolean(tableName, row, "SIL")? "S" : "G");
				session.saveOrUpdate(adkStandCalisaniliskiTx);
				session.flush();
			
				if(iMap.getBoolean(tableName, row, "FLAG")) {
					
					List<?> temAltList 	= session.createCriteria(AdkStandRoliliskiTx.class)
													.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
													.add(Restrictions.eq("id.calisanKod",kullaniciKodu_FK ))
													.add(Restrictions.eq("id.standKod", standmoboKodu_FK))
													.list();
					
					for (int i = 0; i < temAltList.size(); i++) {
						AdkStandRoliliskiTx deleted = (AdkStandRoliliskiTx) temAltList.get(i);
						session.delete(deleted);
					}
					session.flush();
					
					List<?> ekList 	= (List<?>) iMap.get(tableName, row, "DETAIL_DATA");
					if(ekList !=null){
						for(int i=0;i<ekList.size();i++) {
							GMMap xMap = new GMMap((HashMap<?, ?>) ekList.get(i));
							
							AdkStandRoliliskiTxId id_Ek = new AdkStandRoliliskiTxId();
							id_Ek.setTxNo(iMap.getBigDecimal("TRX_NO"));
							id_Ek.setCalisanKod(kullaniciKodu_FK);
							id_Ek.setStandKod(standmoboKodu_FK);
							id_Ek.setRolKod(xMap.getBigDecimal("ROL_NUMARA"));
							AdkStandRoliliskiTx adkStandRoliliskiTx = (AdkStandRoliliskiTx)session.get(AdkStandRoliliskiTx.class, id_Ek);
							
							if(adkStandRoliliskiTx == null) {
								adkStandRoliliskiTx = new AdkStandRoliliskiTx();
							}
							adkStandRoliliskiTx.setId(id_Ek);
							adkStandRoliliskiTx.setBaslangicTar(xMap.getDate("BASLANGIC_TAR"));
							adkStandRoliliskiTx.setBitisTar(xMap.getDate("BITIS_TAR"));
							adkStandRoliliskiTx.setSil(xMap.getBoolean("SIL_DETAIL")? "S" : "G");
							session.saveOrUpdate(adkStandRoliliskiTx);
							session.flush();
						}
					}
				}
			}
			
			iMap.put("TRX_NAME", "4104");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		}catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(715));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		} catch (Exception e) {
			 throw new GMRuntimeException(0,e);	
		}
	}

	@GraymoundService("BNSPR_TRN4104_GET_INFO")
      public static GMMap getInfo(GMMap iMap) {
            GMMap oMap = new GMMap();
            
            try {
                  //  Get Master
                  String            tableName   = "STANDMOBO_MASTER";
                  Session     session     = DAOSession.getSession("BNSPRDal");
                  Criteria    criteria    = session.createCriteria(AdkStandCalisaniliskiTx.class)
                                                                  .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));
                  
                  List<?>     recordList = (List<?>) criteria.list();
                 
                                  
                  
                  for (int row = 0; row < recordList.size(); row++){
                        AdkStandCalisaniliskiTx adkStandCalisaniliskiTx = (AdkStandCalisaniliskiTx) recordList.get(row);
                        oMap.put("TX_NO",iMap.getBigDecimal("TRX_NO"));
                        
                        oMap.put("KULLANICI_KODU"                       , adkStandCalisaniliskiTx.getId().getCalisanKod());
                        oMap.put(tableName, row, "KOD"                  , adkStandCalisaniliskiTx.getId().getStandKod());
                        oMap.put(tableName, row, "BASLANGIC_TAR", adkStandCalisaniliskiTx.getBaslangicTar());
                        oMap.put(tableName, row, "BITIS_TAR"      , adkStandCalisaniliskiTx.getBitisTar());
                        oMap.put(tableName, row, "SIL"                  ,(adkStandCalisaniliskiTx.getSil().equals("S")) ? true : false);
                        oMap.put(tableName, row,"ACIKLAMA", 
                                          LovHelper.diLov(adkStandCalisaniliskiTx.getId().getStandKod(), "4104/LOV_STANDMOBO", "ACIKLAMA"));
                        oMap.put("MUSTERI_NO", 
                                LovHelper.diLov(adkStandCalisaniliskiTx.getId().getCalisanKod(), "4104/LOV_MUSTERI", "MUSTERI_NO"));
                        oMap.put("UNVAN", 
                                LovHelper.diLov(adkStandCalisaniliskiTx.getId().getCalisanKod(), "4104/LOV_MUSTERI", "UNVAN"));
                        oMap.put("GOREV_KODU", 
                                LovHelper.diLov(adkStandCalisaniliskiTx.getId().getCalisanKod(), "4104/LOV_MUSTERI", "POZISYON"));
                       	oMap.put(tableName, row, "DETAIL_DATA",	new ArrayList<GMMap>());				
						oMap.put(tableName, row, "FLAG",		false);				
						oMap.put(tableName, row, "F_NEW",		false);		
                  } 
                  //Get Detail
                  tableName = "ROL_DETAIL"; 
                  
                  Criteria criteriaEk = session.createCriteria(AdkStandRoliliskiTx.class)
                                                            .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));
                  
                  recordList = (List<?>) criteriaEk.list();
                  for (int row = 0; row < recordList.size(); row++){
                        AdkStandRoliliskiTx adkStandRoliliskiTx = (AdkStandRoliliskiTx) recordList.get(row);

                        oMap.put(tableName, row, "ROL_NUMARA", adkStandRoliliskiTx.getId().getRolKod());
                        oMap.put(tableName, row, "BASLANGIC_TAR",      adkStandRoliliskiTx.getBaslangicTar());
                        oMap.put(tableName, row, "BITIS_TAR",       adkStandRoliliskiTx.getBitisTar());
                        oMap.put(tableName, row, "ROL_ADI",
									LovHelper.diLov(adkStandRoliliskiTx.getId().getRolKod(), "4104/LOV_ROL", "TANIM"));
                        oMap.put(tableName, row, "SIL_DETAIL",	(adkStandRoliliskiTx.getSil().equals("S")) ? true : false);			
          				oMap.put(tableName, row, "F_NEW_DETAIL",		false);
                  }
                 
                  return oMap;
            } catch (Exception e) {
                  throw ExceptionHandler.convertException(e);
            }
      }
}
