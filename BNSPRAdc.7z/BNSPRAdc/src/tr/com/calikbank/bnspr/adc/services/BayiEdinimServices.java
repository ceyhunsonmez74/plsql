package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BayiEdinimBayi;
import tr.com.aktifbank.bnspr.dao.BayiEdinimBayiFaaliyet;
import tr.com.aktifbank.bnspr.dao.BayiEdinimBayiFaaliyetId;
import tr.com.aktifbank.bnspr.dao.BayiEdinimEmail;
import tr.com.aktifbank.bnspr.dao.BayiEdinimTalep;
import tr.com.aktifbank.bnspr.dao.BpmProcessDetail;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisan;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.referencedata.GMReferenceDataFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


/**
 *
 *	@author		Olcay Yuce
 *	@version 	1.0.1
 *
 */

public class BayiEdinimServices {
	
	public static final String BAYI_EDINIM_CAMPAIGN_CATEGORY	=	"Bayi_Kazanim_IsAkisi_1";

	public static final String BAYI_STATUS_WEB_SUBMIT				=	"WEB_SUBMIT";
	public static final String BAYI_STATUS_VALIDATED				=	"DOGRULANDI";
	public static final String BAYI_STATUS_FINISHED				=	"BITTI";
	public static final String BAYI_STATUS_FINISHED_WO_EMPLOYEE	=	"BITTI_CALISAN_YOK";
	
	public static final String TIMESTAMP_FORMAT	=	"dd/MM/yyyy hh:mm:ss:SSS";


	private static Logger logger = Logger.getLogger(BayiEdinimServices.class);

	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_GET_MAIL_INFO")
	public static GMMap getEmailInformations(GMMap iMap)
	{
		GMMap oMap= new GMMap();
		oMap.put("RESPONSE", "1");
		oMap.put("RESPONSE_DATA", "");
		try {
			String mailId= iMap.getString("ID");
			if(mailId==null)
			{
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", "Mail id is null.");
			}
			else{
				DateFormat df  = new SimpleDateFormat(TIMESTAMP_FORMAT);

				Session session = DAOSession.getSession("BNSPRDal");
				BayiEdinimEmail email = (BayiEdinimEmail) session.createCriteria(BayiEdinimEmail.class)
						.add(Restrictions.eq("id", mailId)).uniqueResult();
				
				if(email!=null){
					oMap.put("MUSTERI_NO", 	email.getMusteriNo());
					oMap.put("EMAIL_TARIHI", email.getEpostaTarihi());
					oMap.put("EMAIL_TIPI", email.getEpostaTipi());
					oMap.put("SONUC", email.getSonuc());
					oMap.put("SONUC_TARIHI", email.getSonucTarihi() == null ? "" : df.format(email.getSonucTarihi()));
					oMap.put("REC_DATE", email.getRecDate() == null ? "" : df.format(email.getRecDate()));
				}
				else{
					oMap.put("RESPONSE", "0");
					oMap.put("RESPONSE_DATA", "Mail can not found.");
				}
			
			}
		} catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		

		return oMap;
	}
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_GET_CONTACT_INFO")
	public static GMMap getContactInformations(GMMap iMap){
		GMMap oMap= new GMMap();
		
		oMap.put("RESPONSE", "1");
		oMap.put("RESPONSE_DATA", "");
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal customerNo= iMap.getBigDecimal("MUSTERI_NO");
			
			if(customerNo==null){
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", "Customer no is null.");
			}
			else{
				BayiEdinimBayi bayi =(BayiEdinimBayi) session.createCriteria(BayiEdinimBayi.class)
						.add(Restrictions.eq("musteriNo", customerNo)).uniqueResult();
				
				if(bayi==null){
					oMap.put("RESPONSE", "0");
					oMap.put("RESPONSE_DATA", "Bayi can not found.");
				}
				else{
					oMap.put("TIP",bayi.getTip() );
					oMap.put("ADI_UNVANI",bayi.getAdiUnvani());
					oMap.put("BAYI_SAHIBI_ADI",bayi.getBayiSahibiAdi());
					oMap.put("DISTRIBUTOR",bayi.getDistributor() );
					oMap.put("BAYI_SAHIBI_IKINCI_ADI",bayi.getBayiSahibiIkinciAdi() );
					oMap.put("BAYI_SAHIBI_SOYADI",bayi.getBayiSahibiSoyadi());
					oMap.put("ADRES",bayi.getAdres());
					oMap.put("IL_KOD",bayi.getIlKod());
					oMap.put("ILCE_KOD",bayi.getIlceKod());
					oMap.put("EPOSTA",bayi.getEposta());
					oMap.put("BAYI_SAHIBI_EPOSTA",bayi.getBayiSahibiEposta());
					oMap.put("TELEFON1_KOD",bayi.getIsTelefon1Kod());
					oMap.put("TELEFON1_NO",bayi.getIsTelefon1No());
					oMap.put("TELEFON1_DAHILI",bayi.getIsTelefon1Dahili());
					oMap.put("TELEFON2_KOD",bayi.getIsTelefon2Kod());
					oMap.put("TELEFON2_NO",bayi.getIsTelefon2No());
					oMap.put("TELEFON2_DAHILI",bayi.getIsTelefon2Dahili());
					oMap.put("TELEFON3_KOD",bayi.getIsTelefon3Kod());
					oMap.put("TELEFON3_NO",bayi.getIsTelefon3No());
					oMap.put("TELEFON3_DAHILI",bayi.getIsTelefon3Dahili());
					oMap.put("CEP1_KOD",bayi.getCepTelefon1Kod());
					oMap.put("CEP1_NO",bayi.getCepTelefon1No());
					oMap.put("CEP2_KOD",bayi.getCepTelefon2Kod());
					oMap.put("CEP2_NO",bayi.getCepTelefon2No());
					oMap.put("BAYI_DURUM_KOD",bayi.getBayiDurumKod());
				}
				
			}
			
		} catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		
		
		return oMap;
	
	}
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_GET_MAIL_INFO_CUSTOMER_NO")
	public static GMMap getEmailInformationsByCustomerNo(GMMap iMap)
	{
		List<GMMap> mapList = new ArrayList<GMMap>();
		GMMap oMap= new GMMap();
		oMap.put("RESPONSE", "1");
		oMap.put("RESPONSE_DATA", "");
		
		try {
			String customerNo= iMap.getString("MUSTERI_NO");
			if(customerNo==null)
			{
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", "customerNo id is null.");
			}
			else{
				
				DateFormat df  = new SimpleDateFormat(TIMESTAMP_FORMAT);
				
				Session session = DAOSession.getSession("BNSPRDal");
						
				Criteria crit =session.createCriteria(BayiEdinimEmail.class)
						.add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO")))
						.addOrder(Order.desc("recDate"));
			
				List<?> emailList=crit.list();
				
				Iterator<?> emailIterator = emailList.iterator();
				
				while (emailIterator.hasNext()) {
					
					BayiEdinimEmail email = (BayiEdinimEmail) emailIterator.next();
					GMMap map = new GMMap();
					
					map.put("ID", email.getId());
					map.put("EMAIL_TARIHI", email.getEpostaTarihi());
					map.put("EMAIL_TIPI", email.getEpostaTipi());
					map.put("SONUC", email.getSonuc());
					map.put("SONUC_TARIHI", email.getSonucTarihi() == null ? "" : df.format(email.getSonucTarihi()) );
					map.put("REC_DATE", email.getRecDate() == null ? "" : df.format(email.getRecDate()) );
					
					mapList.add(map);
				
				}
			}
			oMap.put("MAIL_LIST", mapList );
		} catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_EMAIL_RECORD_SAVE")
	public static GMMap loadContactList(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_MAILSV");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_EMAIL_RECORD_SAVE_PROCESS")
	public static GMMap bayiEdinimEmailRecordSaveProcess(GMMap iMap) {

        GMMap oMap = new GMMap();
        try {
			Session session = DAOSession.getSession("BNSPRDal");

        	BayiEdinimEmail emailRecord = new BayiEdinimEmail();
        	
        	emailRecord.setId(iMap.getString("EMAIL_ID"));
        	emailRecord.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
        	emailRecord.setEpostaTarihi(iMap.getDate("EMAIL_DATE"));
        	emailRecord.setEpostaTipi(iMap.getString("EMAIL_TYPE"));
        	
			session.saveOrUpdate(emailRecord);
			session.flush();

			
        	oMap.put("RESPONSE", "1");
            return oMap;
        } catch (Exception e) {
        	oMap.put("RESPONSE", "0");
        	oMap.put("RESPONSE_DATA", e.getMessage());
        } finally {

        }
	
        return oMap;
        
	}
	
	/**
	 * updates the record
	 * @param iMap
	 * 				-CUSTOMER_NUMBER
	 * 				-UNVAN
	 * 				-SAHIP_AD
	 * 				-SAHIP_EPOSTA
	 * 				-SAHIP_IKINCI_AD
	 * 				-SAHIP_SOYAD
	 * 				-SAHIP_CEP_ALAN
	 * 				-SAHIP_CEP_NO
	 * 				-DISTRIBUTOR
	 * 				-EPOSTA
	 * 				-TCKN
	 * 				-TICARI_SICIL_NO
	 * 				-VERGI_DAIRESI
	 * 				-VKN
	 * 				-TEL_ALAN
	 * 				-TEL_NO
	 * 				-TIP
	 * @return
	 */
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_TALEP_SAVE")
	public static GMMap bayiEdinimSaveRecord(GMMap iMap){
		GMServiceExecuter.execute("BNSPR_DLR_BAYI_EDINIM_VALIDATE", iMap);

		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmtByTCKN = null;
		CallableStatement 	stmtByVKN = null;
		ResultSet 			rSet = null;
		try {
			iMap.put("BAYI_DURUM_KOD", "WEB_TALEP");

			Session session = DAOSession.getSession("BNSPRDal");
			
			BayiEdinimTalep bayiTalep = new BayiEdinimTalep();

			bayiTalep.setMusteriNo				(iMap.getBigDecimal("MUSTERI_NO")	);

			bayiTalep.setAdiUnvani				(iMap.getString("UNVAN")			);
			bayiTalep.setBayiSahibiAdi			(iMap.getString("SAHIP_AD")			);
			bayiTalep.setBayiSahibiEposta		(iMap.getString("SAHIP_EPOSTA")		);
			bayiTalep.setBayiSahibiIkinciAdi	(iMap.getString("SAHIP_IKINCI_AD")	);
			bayiTalep.setBayiSahibiSoyadi		(iMap.getString("SAHIP_SOYAD")		);
			bayiTalep.setCepTelefon1Kod			(iMap.getString("SAHIP_CEP_ALAN")	);
			bayiTalep.setCepTelefon1No			(iMap.getString("SAHIP_CEP_NO")		);
			bayiTalep.setDistributor			(iMap.getString("DISTRIBUTOR")		);
			bayiTalep.setEposta					(iMap.getString("EPOSTA")			);
			bayiTalep.setTckn					(iMap.getString("TCKN")				);
			bayiTalep.setTicariSicilNo			(iMap.getString("TICARI_SICIL_NO")	);
			bayiTalep.setVergiDairesi			(iMap.getString("VERGI_DAIRESI")	);
			bayiTalep.setVkn					(iMap.getString("VKN")				);
			bayiTalep.setIsTelefon1Kod			(iMap.getString("TEL_ALAN")			);
			bayiTalep.setIsTelefon1No			(iMap.getString("TEL_NO")			);
			bayiTalep.setTip					(iMap.getString("TIP")				);
			bayiTalep.setBayiDurumKod			(iMap.getString("BAYI_DURUM_KOD")	);

			conn = DALUtil.getGMConnection();

        	stmtByTCKN = conn.prepareCall("{? = call PKG_MUSTERI.Musteri_Varmi_TCKN(?)}");
        	stmtByVKN = conn.prepareCall("{? = call PKG_MUSTERI.Musteri_Varmi_VKN(?)}");

        	stmtByTCKN.registerOutParameter(1, Types.NUMERIC);
        	stmtByVKN.registerOutParameter(1, Types.NUMERIC);

        	stmtByTCKN.setBigDecimal(2, iMap.getBigDecimal("TCKN"));
        	stmtByVKN.setBigDecimal(2, iMap.getBigDecimal("VKN"));

        	stmtByTCKN.execute();
        	stmtByVKN.execute();

			bayiTalep.setTcknSahibiMusteriNo	(stmtByTCKN.getBigDecimal(1)		);
			bayiTalep.setVknSahibiMusteriNo		(stmtByVKN.getBigDecimal(1)			);

			session.save(bayiTalep);
			session.flush();
		} catch (org.hibernate.exception.ConstraintViolationException e) {
			throw new GMRuntimeException(0, "Kay\u0131tl\u0131 bir talimat\u0131n\u0131z bulunmaktad\u0131r.");
		} catch (Exception e) {
			throw new GMRuntimeException(0, e.getMessage());
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmtByVKN);
			GMServerDatasource.close(stmtByTCKN);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_TALEP_GET_PARAMETER")
	public static GMMap getGnlParameter(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
        GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", iMap.getString("PARAMETER"))).uniqueResult();

		return oMap.put("DEGER", parametre.getDeger());
	}

	
	/**
	 * Gets the record of bayi_edinim
	 * @param iMap
	 * 				-CUSTOMER_NUMBER
	 * @return
	 */
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_GET")
	public static GMMap bayiEdinimGetRecord(GMMap iMap){
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			BayiEdinimBayi bayi = (BayiEdinimBayi) session.createCriteria(BayiEdinimBayi.class)
					.add(Restrictions.eq("musteriNo", iMap.getBigDecimal("CUSTOMER_NUMBER")))
					.uniqueResult();
			
			if(bayi == null){
				oMap.put("RESPONSE"			, "0");
				oMap.put("RESPONSE_MESSAGE"	,  GMMessageFactory.getMessage("WPK_CUST_INFO_NOT_FOUND", null));
				return oMap;
			}
			
			oMap.put("UNVAN"			, bayi.getAdiUnvani()			);
			oMap.put("ADRES"			, bayi.getAdres()				);
			oMap.put("SAHIP_AD"			, bayi.getBayiSahibiAdi()		);
			oMap.put("SAHIP_EPOSTA"		, bayi.getBayiSahibiEposta()	);
			oMap.put("SAHIP_IKINCI_AD"	, bayi.getBayiSahibiIkinciAdi()	);
			oMap.put("SAHIP_SOYAD"		, bayi.getBayiSahibiSoyadi()	);
			oMap.put("SAHIP_CEP_ALAN"	, bayi.getCepTelefon1Kod()		);
			oMap.put("SAHIP_CEP_NO"		, bayi.getCepTelefon1No()		);
			oMap.put("DISTRIBUTOR"		, bayi.getDistributor()			);
			oMap.put("EPOSTA"			, bayi.getEposta()				);
			oMap.put("TCKN"				, bayi.getTckn()				);
			oMap.put("TICARI_SICIL_NO"	, bayi.getTicariSicilNo()		);
			oMap.put("VERGI_DAIRESI"	, bayi.getVergiDairesi()		);
			oMap.put("VKN"				, bayi.getVkn()					);
			oMap.put("TEL_ALAN"			, bayi.getIsTelefon1Kod()		);
			oMap.put("TEL_NO"			, bayi.getIsTelefon1No()		);
			oMap.put("TIP"				, bayi.getTip()					);
            oMap.put("BAYI_DURUM_KOD"   , bayi.getBayiDurumKod()        );
            oMap.put("IL"               , bayi.getIlKod()               );
            oMap.put("ILCE"             , bayi.getIlceKod()             );
            oMap.put("ADRES"            , bayi.getAdres()               );
            oMap.put("IL_2"             , bayi.getIlKod2()               );
            oMap.put("ILCE_2"           , bayi.getIlceKod2()             );
            oMap.put("ADRES_2"          , bayi.getAdres2()               );

            oMap.put("MAKBUZ_ULASTI_MI"         , bayi.getMektupUlasti()  );
            oMap.put("INCELEMEYE_FIRSAT_OLDU_MU", bayi.getIncelendi()     );
            oMap.put("INCELENMEME_NEDENI"       , bayi.getRedSebebi()==null ? "" : null);
            oMap.put("DIGER_NEDEN"              , bayi.getRedSebebiDiger());

			oMap.put("DOGRULANDI_MI"	, BAYI_STATUS_VALIDATED.equals(bayi.getBayiDurumKod()));
			
		} catch (Exception e) {
			oMap.put("RESPONSE"			, "0"							);
        	oMap.put("RESPONSE_DATA"	, e.getMessage()				);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_UPDATE_WEB")
	public static GMMap methodName(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("BAYI_DURUM_KOD", BAYI_STATUS_WEB_SUBMIT);
		GMServiceExecuter.execute("BNSPR_DLR_BAYI_EDINIM_UPDATE", iMap);

		GMMap kampanyaIMap = new GMMap();

		kampanyaIMap.put("CUSTOMER_NO"	, iMap.getBigDecimal("CUSTOMER_NUMBER"));
		kampanyaIMap.put("CAMPAIGN_CODE", BAYI_EDINIM_CAMPAIGN_CATEGORY);
		kampanyaIMap.put("CHANNEL", "WEB");
		
		GMMap kampanyaOMap = GMServiceExecuter.call("BNSPR_KAMPANYA_MUSTERI_KAMPANYA_LISTELE", kampanyaIMap);
		
		if(kampanyaOMap.getString("CAMPAIGN_NAME") != null) {
			String finishResult = null;
			
			for(int i=0, n=kampanyaOMap.getSize("RESULTS"); i<n; i++) {
				if(!kampanyaOMap.getBoolean("RESULTS",i,"HIDDEN")) {
					finishResult = kampanyaOMap.getString("RESULTS",i,"NAME");
				}
			}

			if(finishResult != null) {

				GMMap kampanyaSaveIMap = new GMMap();
				kampanyaSaveIMap.put("CUSTOMER_NO", kampanyaIMap.get("CUSTOMER_NO"));
				kampanyaSaveIMap.put("OFFER", kampanyaOMap.getString("CAMPAIGN_NAME"));
				kampanyaSaveIMap.put("EVENT", finishResult);
				kampanyaSaveIMap.put("CHANNEL", "WEB");

				GMServiceExecuter.call("BNSPR_KAMPANYA_SONUCUNU_KAYDET", kampanyaSaveIMap);
			}
		}

		return oMap;
	}

	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_UPDATE")
	public static GMMap bayiEdinimUpdateRecord(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_UPDT");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};

	/**
	 * updates the record
	 * @param iMap
	 * 				-CUSTOMER_NUMBER
	 * 				-UNVAN
	 * 				-SAHIP_AD
	 * 				-SAHIP_EPOSTA
	 * 				-SAHIP_IKINCI_AD
	 * 				-SAHIP_SOYAD
	 * 				-SAHIP_CEP_ALAN
	 * 				-SAHIP_CEP_NO
	 * 				-DISTRIBUTOR
	 * 				-EPOSTA
	 * 				-TCKN
	 * 				-TICARI_SICIL_NO
	 * 				-VERGI_DAIRESI
	 * 				-VKN
	 * 				-TEL_ALAN
	 * 				-TEL_NO
	 * 				-TIP
	 * @return
	 */
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_UPDATE_PROCESS")
	public static GMMap bayiEdinimUpdateRecordProcess(GMMap iMap){
		GMServiceExecuter.execute("BNSPR_DLR_BAYI_EDINIM_VALIDATE", iMap);

		GMMap oMap = new GMMap();
		oMap.put("RESPONSE"			, "2");

		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			BayiEdinimBayi bayi = (BayiEdinimBayi) session.createCriteria(BayiEdinimBayi.class)
					.add(Restrictions.eq("musteriNo", iMap.getBigDecimal("CUSTOMER_NUMBER")))
					.uniqueResult();
			
			if(bayi == null){
				
				oMap.put("RESPONSE"			, "0");
				oMap.put("RESPONSE_MESSAGE"	, GMMessageFactory.getMessage("WPK_CUST_INFO_NOT_FOUND", null));
				return oMap;
			}
			
			if(iMap.getBoolean("DOGRULANDI_MI")) {
				iMap.put("BAYI_DURUM_KOD", BAYI_STATUS_VALIDATED);
			}
			
			bayi.setAdiUnvani				(iMap.getString("UNVAN")			);
			bayi.setBayiSahibiAdi			(iMap.getString("SAHIP_AD")			);
			bayi.setBayiSahibiEposta		(iMap.getString("SAHIP_EPOSTA")		);
			bayi.setBayiSahibiIkinciAdi		(iMap.getString("SAHIP_IKINCI_AD")	);
			bayi.setBayiSahibiSoyadi		(iMap.getString("SAHIP_SOYAD")		);
			bayi.setCepTelefon1Kod			(iMap.getString("SAHIP_CEP_ALAN")	);
			bayi.setCepTelefon1No			(iMap.getString("SAHIP_CEP_NO")		);
			bayi.setDistributor				(iMap.getString("DISTRIBUTOR")		);
			bayi.setEposta					(iMap.getString("EPOSTA")			);
			bayi.setTckn					(iMap.getString("TCKN")				);
			bayi.setTicariSicilNo			(iMap.getString("TICARI_SICIL_NO")	);
			bayi.setVergiDairesi			(iMap.getString("VERGI_DAIRESI")	);
			bayi.setVkn						(iMap.getString("VKN")				);
			bayi.setIsTelefon1Kod			(iMap.getString("TEL_ALAN")			);
			bayi.setIsTelefon1No			(iMap.getString("TEL_NO")			);
            bayi.setTip                     (iMap.getString("TIP")              );

            bayi.setIlKod                   (iMap.getString("IL", bayi.getIlKod())          );
            bayi.setIlceKod                 (iMap.getString("ILCE", bayi.getIlceKod())      );
            bayi.setAdres                   (iMap.getString("ADRES", bayi.getAdres())       );

            bayi.setIlKod2                  (iMap.getString("IL_2", bayi.getIlKod2())        );
            bayi.setIlceKod2                (iMap.getString("ILCE_2", bayi.getIlceKod2())   );
            bayi.setAdres2                  (iMap.getString("ADRES_2", bayi.getAdres2())    );

            bayi.setMektupUlasti            (iMap.getString("MAKBUZ_ULASTI_MI")             );
            bayi.setIncelendi               (iMap.getString("INCELEMEYE_FIRSAT_OLDU_MU")    );
            bayi.setRedSebebi               (StringUtils.isBlank(iMap.getString("INCELENMEME_NEDENI")) ? null : iMap.getString("INCELENMEME_NEDENI"));
            bayi.setRedSebebiDiger          (iMap.getString("DIGER_NEDEN")                  );

			if (iMap.containsKey("BAYI_DURUM_KOD")) {
				bayi.setBayiDurumKod		(iMap.getString("BAYI_DURUM_KOD")	);
			}
			

			session.update(bayi);
			
			if (iMap.containsKey("FAALIYET_KONULARI")) {
			    @SuppressWarnings("unchecked")
                List<BayiEdinimBayiFaaliyet> list = session.createCriteria(BayiEdinimBayiFaaliyet.class)
			        .add(Restrictions.eq("id.musteriNo" , bayi.getMusteriNo()))
			        .list();
			    if (list!=null) {
			        for (BayiEdinimBayiFaaliyet bayiEdinimBayiFaaliyet : list){
	                    session.delete(bayiEdinimBayiFaaliyet);                        
                    }
    			    session.flush();
			    }

			    BayiEdinimBayiFaaliyet birFaaliyet;
			    int size=iMap.getSize("FAALIYET_KONULARI");

			    for (int i = 0; i < size; i++){
			        if (iMap.getBoolean("FAALIYET_KONULARI", i, "SEC")) {
			            birFaaliyet = new BayiEdinimBayiFaaliyet(
			                    new BayiEdinimBayiFaaliyetId(bayi.getMusteriNo() , iMap.getString("FAALIYET_KONULARI", i, "FAALIYET_KODU"))
			            );
		                session.save(birFaaliyet);
			        }
                }
			    session.flush();
			}
			
		} catch (Exception e) {
			oMap.put("RESPONSE"			, "0"							);
        	oMap.put("RESPONSE_DATA"	, e.getMessage()				);
		}
		
		return oMap;
	}

	/**
     * updates the record
     * @param iMap
     *              -CUSTOMER_NUMBER
     *              -UNVAN
     *              -SAHIP_AD
     *              -SAHIP_EPOSTA
     *              -SAHIP_IKINCI_AD
     *              -SAHIP_SOYAD
     *              -SAHIP_CEP_ALAN
     *              -SAHIP_CEP_NO
     *              -DISTRIBUTOR
     *              -EPOSTA
     *              -TCKN
     *              -TICARI_SICIL_NO
     *              -VERGI_DAIRESI
     *              -VKN
     *              -TEL_ALAN
     *              -TEL_NO
     *              -TIP
     * @return
     */
    @GraymoundService("BNSPR_DLR_BAYI_EDINIM_VALIDATE")
    public static GMMap bayiEdinimValidateRecord(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap messageMap = new GMMap();
        

        
        if (StringUtils.isBlank(iMap.getString("TIP"))){
            messageMap.put("FIELD" , "Firma tipi");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        }

        boolean isRealCus = "G".equals(iMap.getString("TIP"));
        
        if (StringUtils.isBlank(iMap.getString("UNVAN"))){
            messageMap.put("FIELD" , "�nvan");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        }
        if (StringUtils.isBlank(iMap.getString("DISTRIBUTOR"))){
            messageMap.put("FIELD" , "distrib�t�r");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        }
        if (!isRealCus && iMap.containsKey("VERGI_DAIRESI") && StringUtils.isBlank(iMap.getString("VERGI_DAIRESI"))){
            messageMap.put("FIELD" , "Vergi Dairesi");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        }
        if (!isRealCus && StringUtils.isBlank(iMap.getString("VKN"))){
            messageMap.put("FIELD" , "vergi kimlik numaras�");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        } else if (!StringUtils.isBlank(iMap.getString("VKN"))) {
        	messageMap.put("VERGI_NO" , iMap.getString("VKN"));
        	if(GMServiceExecuter.call("BNSPR_COMMON_VKN_CHECK_DIGIT", messageMap).getInt("SONUC")==0) {
                GMMap param = new GMMap();
                param.put("FIELD" , "'Vergi Kimlik Num.'");
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC10" , param) , true);
        	}
        }
        if (StringUtils.isBlank(iMap.getString("TEL_ALAN"))){
            messageMap.put("FIELD" , "i� telefonu alan kodunu");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("INT03" , messageMap) , true);
        } else{
            if (!isValidNumericTel(iMap.getString("TEL_ALAN") , 3)){
                GMMap param = new GMMap();
                param.put("FIELD" , "'�� telefonu alan kodu'");
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC10" , param) , true);
            }
        }
        if (StringUtils.isBlank(iMap.getString("TEL_NO"))){
            messageMap.put("FIELD" , "telefon");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        } else{
            if (!isValidNumericTel(iMap.getString("TEL_NO") , 7)){
                GMMap param = new GMMap();
                param.put("FIELD" , "'�� telefonu'");
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC10" , param) , true);
            }
        }
        if (StringUtils.isBlank(iMap.getString("EPOSTA"))){
            messageMap.put("FIELD" , "e-posta");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        } else{
            if (!isValidEmail(iMap.getString("EPOSTA"))){
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC05" , null) , true);
            }
        }
        if (StringUtils.isBlank(iMap.getString("SAHIP_AD"))){
            messageMap.put("FIELD" , "isim");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        }
        if (StringUtils.isBlank(iMap.getString("SAHIP_SOYAD"))){
            messageMap.put("FIELD" , "soy isim");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        }
        if (StringUtils.isBlank(iMap.getString("TCKN"))){
            messageMap.put("FIELD" , "TC kimlik no");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        } else {
        	messageMap.put("TC_KIMLIK_NO" , iMap.getString("TCKN"));
        	if(GMServiceExecuter.call("BNSPR_COMMON_TCKN_CHECK_DIGIT", messageMap).getInt("SONUC")==0) {
                GMMap param = new GMMap();
                param.put("FIELD" , "'TCKN'");
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC10" , param) , true);
        	}
        }
        if (StringUtils.isBlank(iMap.getString("SAHIP_CEP_ALAN"))){
            messageMap.put("FIELD" , "cep telefonu alan kod");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("INT03" , messageMap) , true);
        } else{
            if (!isValidNumericTel(iMap.getString("SAHIP_CEP_ALAN") , 3)){
                GMMap param = new GMMap();
                param.put("FIELD" , "'Cep telefonu alan kodu'");
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC10" , param) , true);
            }
        }
        if (StringUtils.isBlank(iMap.getString("SAHIP_CEP_NO"))){
            messageMap.put("FIELD" , "cep telefon");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        } else{
            if (!isValidNumericTel(iMap.getString("SAHIP_CEP_NO") , 7)){
                GMMap param = new GMMap();
                param.put("FIELD" , "'Cep telefonu'");
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC10" , param) , true);
            }
        }
        if (StringUtils.isBlank(iMap.getString("SAHIP_EPOSTA"))){
            messageMap.put("FIELD" , "e-posta");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        } else{
            if (!isValidEmail(iMap.getString("SAHIP_EPOSTA"))){
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC05" , null) , true);
            }
        }
        if (iMap.containsKey("TICARI_SICIL_NO") && StringUtils.isBlank(iMap.getString("TICARI_SICIL_NO"))){
            messageMap.put("FIELD" , "ticari sicil no");
            throw new GMRuntimeException(0 , GMMessageFactory.getMessage("TRNORD03" , messageMap) , true);
        } else if (iMap.containsKey("TICARI_SICIL_NO")){
            if (!isMatchPattern(iMap.getString("TICARI_SICIL_NO"), "^([0-9]|[0-9]+([0-9\\-])*[0-9]+)$")){
                GMMap param = new GMMap();
                param.put("FIELD" , "'Ticari Sicil Numaras�'");
                throw new GMRuntimeException(0 , GMMessageFactory.getMessage("CUSINFC10" , param) , true);
            }
        }
        oMap.put("RESPONSE" , "2");
        return oMap;
    }

	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_EMAIL_UPDATE")
	public static GMMap emailUpdate(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_UPMAIL");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};

	/**
	 * update emails of record
	 * @param iMap
	 * 				-CUSTOMER_NUMBER
	 * 				-SAHIP_EPOSTA
	 * 				-EPOSTA
	 * @return
	 */
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_EMAIL_UPDATE_PROCESS")
	public static GMMap emailUpdateProcess(GMMap iMap){
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			BayiEdinimBayi bayi = (BayiEdinimBayi) session.createCriteria(BayiEdinimBayi.class)
					.add(Restrictions.eq("musteriNo", iMap.getBigDecimal("CUSTOMER_NUMBER")))
					.uniqueResult();
			
			if(bayi == null){
				
				oMap.put("RESPONSE"			, "0");
				oMap.put("RESPONSE_MESSAGE"	, "M��teri kayd� bulunamad�");
				return oMap;
			}
			
//			bayi.setBayiSahibiEposta		(iMap.getString("SAHIP_EPOSTA")	);
			bayi.setEposta					(iMap.getString("EPOSTA")		);
			
			session.update(bayi);
		} catch (Exception e) {
			oMap.put("RESPONSE"			, "0"							);
        	oMap.put("RESPONSE_DATA"	, e.getMessage()				);
		}
		
		return oMap;
	}
	

	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_UPDATE_CUSTOMER_START_BPM_PROCESS")
	public static GMMap bayiEdinimUpdateCustomerStartBPMProcess(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_STBPM");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};	
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_UPDATE_CUSTOMER_START_BPM_PROCESS_PROCESS")
	public static GMMap bayiEdinimUpdateCustomerStartBPMProcessProcess(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		String processDefinitionKey = "bayiEdinimServisAkisi";
		oMap.put("PROCESS_DEFINITION_KEY", processDefinitionKey);
		oMap.put("PROCESS_NAME", processDefinitionKey);
		oMap.put("REFERENCE_NO", iMap.getString("CUSTOMER_NUMBER"));
		
        oMap.putAll(GMServiceExecuter.call("BNSPR_START_NEW_BPM_PROCESS_INSTANCE", oMap));
		
		return oMap;		
	}
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_DOGRULAMA_BASLAT")
	public static GMMap bayiEdinimDogrulamaBaslat(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_STMUH");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};		

	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_DOGRULAMA_BASLAT_PROCESS")
	public static GMMap bayiEdinimDogrulamaBaslatProcess(GMMap iMap) throws SQLException {
		GMMap oMap = new GMMap();

		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			
			BigDecimal musteriNo = getMusteriNoFromProcessInstanceId(iMap);

			conn = DALUtil.getGMConnection();
        	stmt = conn.prepareCall("{call PKG_SIGORTA_MUSTERI.Bayi_Dogrulama(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, musteriNo);
			stmt.execute();
			
			oMap.put("RESPONSE", "2");
			return oMap;
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_UPDATE_CUSTOMER")
	public static GMMap bayiEdinimUpdateCustomer(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_CUSTUP");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};		
	

	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_UPDATE_CUSTOMER_PROCESS")
	public static GMMap bayiEdinimUpdateCustomerProcess(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		BigDecimal musteriNo = getMusteriNoFromProcessInstanceId(iMap);

		Session session = DAOSession.getSession("BNSPRDal");
		BayiEdinimBayi bayiEdinimInfo = (BayiEdinimBayi) session.get(BayiEdinimBayi.class, musteriNo);
		
		GMMap existingCustomer = "G".equals(bayiEdinimInfo.getTip() )
				? searchCustomer(bayiEdinimInfo.getTckn(), null, null)
				: searchCustomer(null, null, bayiEdinimInfo.getVkn());
		
		if(existingCustomer != null 
				&& existingCustomer.getString("MUSTERI_NO") != null  
				&& bayiEdinimInfo.getTip().equals(existingCustomer.getString("MUSTERI_TUR_KOD"))
				&& ( "T".equals(existingCustomer.getString("MUSTERI_TUR_KOD")) || "4".equals(existingCustomer.getString("MUSTERI_STAT1")) ) // tuzel icin ekstra kontrol yok, G ise stat da kontrol et
				) {
			bayiEdinimInfo.setVarolanMusteriNo(existingCustomer.getBigDecimal("MUSTERI_NO"));
			bayiEdinimInfo.setVarolanMusteriKontak(existingCustomer.getString("MUSTERI_KONTAKT"));
		}
		
		session.save(bayiEdinimInfo);
		
		
		if(bayiEdinimInfo.getVarolanMusteriNo() == null || bayiEdinimInfo.getVarolanMusteriNo() != null && "K".equals(bayiEdinimInfo.getVarolanMusteriKontak())) {
			
			GMMap custUpdateMap = new GMMap();
			custUpdateMap.put("MUSTERI_NO", bayiEdinimInfo.getAkisMusteriNo());
			custUpdateMap.put("TICARI_UNVAN", bayiEdinimInfo.getAdiUnvani());
			custUpdateMap.put("KISA_AD", bayiEdinimInfo.getBayiSahibiAdi() +" " +bayiEdinimInfo.getBayiSahibiSoyadi());
			
			custUpdateMap.put("ISIM", bayiEdinimInfo.getBayiSahibiAdi());
			custUpdateMap.put("IKINCI_ISIM", bayiEdinimInfo.getBayiSahibiIkinciAdi());
			custUpdateMap.put("SOYADI", bayiEdinimInfo.getBayiSahibiSoyadi());

			custUpdateMap.put("VERGI_NO", bayiEdinimInfo.getVkn());
			custUpdateMap.put("TC_KIMLIK_NO", bayiEdinimInfo.getTckn());
			custUpdateMap.put("TCKNO_IN", bayiEdinimInfo.getTckn());
			custUpdateMap.put("VERGI_DAIRE_KODU", bayiEdinimInfo.getVergiDairesi());
			custUpdateMap.put("VERGI_DAIRE_IL_KODU", getVergiDairesi(bayiEdinimInfo.getVergiDairesi()).getString("IL_KOD"));
			custUpdateMap.put("TICARI_SICIL_NO", bayiEdinimInfo.getTicariSicilNo());
			custUpdateMap.put("EMAIL_IS", bayiEdinimInfo.getEposta());
			custUpdateMap.put("EMAIL_KISISEL", bayiEdinimInfo.getBayiSahibiEposta());
			

			String adresList = "ADRES_LIST";
			int size=custUpdateMap.getSize(adresList);

            custUpdateMap.put(adresList, size, "ADRES_KOD", "I");
            custUpdateMap.put(adresList, size, "ISYERI_UNVANI", "TICARI_UNVAN");
            custUpdateMap.put(adresList, size, "ADRES", bayiEdinimInfo.getAdres());
            custUpdateMap.put(adresList, size, "ADRES_IL_KOD", bayiEdinimInfo.getIlKod());
            custUpdateMap.put(adresList, size, "ADRES_ILCE_KOD", bayiEdinimInfo.getIlceKod());
            custUpdateMap.put(adresList, size, "ULKE_KOD", "TR");
            custUpdateMap.put(adresList, size, "EXTRE_ADRES_KOD_F", "E");

            size=custUpdateMap.getSize(adresList);

            custUpdateMap.put(adresList, size, "ADRES_KOD", "I1");
            custUpdateMap.put(adresList, size, "ISYERI_UNVANI", "TICARI_UNVAN");
            custUpdateMap.put(adresList, size, "ADRES", bayiEdinimInfo.getAdres2());
            custUpdateMap.put(adresList, size, "ADRES_IL_KOD", bayiEdinimInfo.getIlKod2());
            custUpdateMap.put(adresList, size, "ADRES_ILCE_KOD", bayiEdinimInfo.getIlceKod2());
            custUpdateMap.put(adresList, size, "ULKE_KOD", "TR");

			int telefonRow = 0;
			String telefonList = "TELEFON_LIST";
			custUpdateMap.put(telefonList, telefonRow, "TEL_TIP", "2");
			custUpdateMap.put(telefonList, telefonRow, "ULKE_KODU", "90");
			custUpdateMap.put(telefonList, telefonRow, "ALAN_KOD", bayiEdinimInfo.getIsTelefon1Kod());
			custUpdateMap.put(telefonList, telefonRow, "TEL_NO", bayiEdinimInfo.getIsTelefon1No());
			custUpdateMap.put(telefonList, telefonRow++, "DAH_NO", bayiEdinimInfo.getIsTelefon1Dahili());

			if(bayiEdinimInfo.getIsTelefon2Kod() != null ){
				custUpdateMap.put(telefonList, telefonRow, "TEL_TIP", "2");
				custUpdateMap.put(telefonList, telefonRow, "ULKE_KODU", "90");
				custUpdateMap.put(telefonList, telefonRow, "ALAN_KOD", bayiEdinimInfo.getIsTelefon2Kod());
				custUpdateMap.put(telefonList, telefonRow, "TEL_NO", bayiEdinimInfo.getIsTelefon2No());
				custUpdateMap.put(telefonList, telefonRow++, "DAH_NO", bayiEdinimInfo.getIsTelefon2Dahili());
			}

			if(bayiEdinimInfo.getIsTelefon3Kod() != null ){
				custUpdateMap.put(telefonList, telefonRow, "TEL_TIP", "2");
				custUpdateMap.put(telefonList, telefonRow, "ULKE_KODU", "90");
				custUpdateMap.put(telefonList, telefonRow, "ALAN_KOD", bayiEdinimInfo.getIsTelefon3Kod());
				custUpdateMap.put(telefonList, telefonRow, "TEL_NO", bayiEdinimInfo.getIsTelefon3No());
				custUpdateMap.put(telefonList, telefonRow++, "DAH_NO", bayiEdinimInfo.getIsTelefon3Dahili());
			}
			if(bayiEdinimInfo.getCepTelefon1Kod() != null ) {
				custUpdateMap.put(telefonList, telefonRow, "TEL_TIP", "3");
				custUpdateMap.put(telefonList, telefonRow, "ULKE_KODU", "90");
				custUpdateMap.put(telefonList, telefonRow, "ALAN_KOD", bayiEdinimInfo.getCepTelefon1Kod());
				custUpdateMap.put(telefonList, telefonRow++, "TEL_NO", bayiEdinimInfo.getCepTelefon1No());
			}
			if(bayiEdinimInfo.getCepTelefon2Kod() != null ) {
				custUpdateMap.put(telefonList, telefonRow, "TEL_TIP", "3");
				custUpdateMap.put(telefonList, telefonRow, "ULKE_KODU", "90");
				custUpdateMap.put(telefonList, telefonRow, "ALAN_KOD", bayiEdinimInfo.getCepTelefon2Kod());
				custUpdateMap.put(telefonList, telefonRow++, "TEL_NO", bayiEdinimInfo.getCepTelefon2No());
			}
			

			GMServiceExecuter.call("BNSPR_CUST_UPDATE_GERCEK_MUSTERI", custUpdateMap);
			
		}

		oMap.put("RESPONSE", "2");
		return oMap;
	}
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_CREATE_ACCOUNT_AND_KMH")
	public static GMMap bayiEdinimCreateAccountAndKmh(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_ACC");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};		
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_CREATE_ACCOUNT_AND_KMH_PROCESS")
	public static GMMap bayiEdinimCreateAccountAndKmhProcess(GMMap iMap) throws SQLException {
		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		CallableStatement 	stmt2 = null;
		ResultSet 			rSet = null;
		try {
			
			BigDecimal musteriNo = getMusteriNoFromProcessInstanceId(iMap);
			
			Session session = DAOSession.getSession("BNSPRDal");
        	BayiEdinimBayi bayiEdinimInfo = (BayiEdinimBayi) session.get(BayiEdinimBayi.class, musteriNo);
        	
        	conn = DALUtil.getGMConnection();
        	stmt = conn.prepareCall("{? = call PKG_SIGORTA_MUSTERI.Hesap_Process(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, bayiEdinimInfo.getAkisMusteriNo());
			stmt.setString(i++, bayiEdinimInfo.getTip());
			stmt.setString(i++, bayiEdinimInfo.getVarolanMusteriNo() == null ? "H" : "E"); // Varolan bir musteri mi kullaniliyor
			stmt.execute();
			
			BigDecimal hesapNo = stmt.getBigDecimal(1);
			
			stmt2 = conn.prepareCall("{call PKG_KMH_UTIL.KMH_Kayit_Insert(?)}");
			i = 1;
			stmt2.setBigDecimal(i++, hesapNo);
			stmt2.execute();
			
			oMap.put("RESPONSE", "2");
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_CREATE_DEALER")
	public static GMMap bayiEdinimCreateDealer(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_CRTDLR");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};		
	
    @GraymoundService("BNSPR_DLR_BAYI_EDINIM_CREATE_DEALER_PROCESS")
	public static GMMap bayiEdinimCreateDealerProcess(GMMap iMap) {
		GMMap oMap = new GMMap();

		BigDecimal musteriNo = getMusteriNoFromProcessInstanceId(iMap);
		
		Session session = DAOSession.getSession("BNSPRDal");
		BayiEdinimBayi bayiEdinimInfo = (BayiEdinimBayi) session.get(BayiEdinimBayi.class, musteriNo);

		GMMap hesapSearchIMap = new GMMap();
		hesapSearchIMap.put("MUSTERI_NO", bayiEdinimInfo.getAkisMusteriNo());
		hesapSearchIMap.put("TABLE_NAME", "ACCOUNT_LIST");
		GMMap hesapSearchOMap = GMServiceExecuter.call("INTERNET_GET_HESAP_LIST", hesapSearchIMap);

        BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
		
		GMMap dealerInfoMap = new GMMap();
		dealerInfoMap.put("TRX_NO", txNo);
		dealerInfoMap.put("SATICI_KOD", GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME","BIR_SATICI")).getString("ID"));
		dealerInfoMap.put("SATICI_TIP", "M");
		dealerInfoMap.put("DI_SATICI_KOD", bayiEdinimInfo.getAdiUnvani());
		dealerInfoMap.put("BAGLI_OLDUGU_BOLGE", "I");
//		dealerInfoMap.put("DOKUMAN_YOLLAMA_TIPI", "2");
		dealerInfoMap.put("DURUM", "G");
		dealerInfoMap.put("MUSTERI_NO", bayiEdinimInfo.getAkisMusteriNo());
		dealerInfoMap.put("DI_MUSTERI_NO", bayiEdinimInfo.getAdiUnvani());
		dealerInfoMap.put("SIRKET_TIPI", "7");
		dealerInfoMap.put("VERGI_TCK_NO", bayiEdinimInfo.getVkn());
		dealerInfoMap.put("VERGI_DAIRESI", bayiEdinimInfo.getVergiDairesi());
		dealerInfoMap.put("IL", bayiEdinimInfo.getIlKod());
		dealerInfoMap.put("ILCE", bayiEdinimInfo.getIlceKod());
		dealerInfoMap.put("TELEFON_ALAN", bayiEdinimInfo.getIsTelefon1Kod());
		dealerInfoMap.put("TELEFON", bayiEdinimInfo.getIsTelefon1No());
		dealerInfoMap.put("MUSTERI_HESAP_NO", hesapSearchOMap.get("ACCOUNT_LIST",0,"HESAP_NO"));

		BirSatici satici = (BirSatici)session.createCriteria(BirSatici.class)
				.add(Restrictions.eq("drm", "G"))
				.add(Restrictions.eq("musteriNo", bayiEdinimInfo.getAkisMusteriNo()))
				.add(Restrictions.eq("saticiTipKod", "M")).uniqueResult();
		
		if(satici != null) {
			dealerInfoMap.put("SATICI_TIP", "S");
			dealerInfoMap.put("SUBE_MUSTERI_NO", bayiEdinimInfo.getMusteriNo());
			
			
			dealerInfoMap.put("BAGLI_OLDUGU_MERKEZ_BAYI_KOD", satici.getKod());

			dealerInfoMap.put("SATICI_ADRES",bayiEdinimInfo.getAdres());
			dealerInfoMap.put("SATICI_IL",bayiEdinimInfo.getIlKod());
			dealerInfoMap.put("SATICI_ILCE",bayiEdinimInfo.getIlceKod());			
			
			dealerInfoMap.put("SATICI_TELEFON_ALAN",bayiEdinimInfo.getIsTelefon1Kod());			
			dealerInfoMap.put("SATICI_TELEFON",bayiEdinimInfo.getIsTelefon1No());
			
		}
		

		String eposta = bayiEdinimInfo.getEposta();
		if(eposta != null){
			String[] epostaArray = eposta.split("@");
			if(epostaArray.length == 2){
				dealerInfoMap.put("E_POSTA_NAME", epostaArray[0]);
				dealerInfoMap.put("E_POSTA_NET", epostaArray[1]);
			}
		}

		dealerInfoMap.put("PARA_CIKISI", "E");
		dealerInfoMap.put("SATICI_GORUSU", "2");
		dealerInfoMap.put("KREDI_TURU", "0000");
		dealerInfoMap.put("ADRES", bayiEdinimInfo.getAdres());
		dealerInfoMap.put("BAYI_SORUMLU_KISI", "127");
		dealerInfoMap.put("SIGORTA_SATISI", true);
		dealerInfoMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getString("BANKA_TARIH"));

		dealerInfoMap.put("BAGLI_OLDUGU_DAGITICI_FIRMALAR", 0, "VALUE", bayiEdinimInfo.getDistributor());
		dealerInfoMap.put("BAGLI_OLDUGU_DAGITICI_FIRMALAR", 0, "SEC", true);

		
		boolean calisanTanimlimi = calisanZatenTanimlimi(bayiEdinimInfo.getTckn());
		
		if(calisanTanimlimi) {
			
			dealerInfoMap.put("CALISANLAR", new ArrayList<GMMap>());			
			
		} else {
		
			String calisanlarList = "CALISANLAR";
			dealerInfoMap.put(calisanlarList, 0, "TCK_NO", bayiEdinimInfo.getTckn());
	
			iMap.put("tckno_in", bayiEdinimInfo.getTckn());
			GMMap calisanKpsMap = GMServiceExecuter.call("BNSPR_TRN10011_KPS_KIMLIK_SORGULAMA", iMap);
	
			dealerInfoMap.put(calisanlarList, 0, "ADI", calisanKpsMap.getString("ad1"));
			dealerInfoMap.put(calisanlarList, 0, "IKINCI_ADI", calisanKpsMap.getString("ad2"));
			dealerInfoMap.put(calisanlarList, 0, "SOYADI", calisanKpsMap.getString("soyad"));
			dealerInfoMap.put(calisanlarList, 0, "DOGUM_TARIHI", calisanKpsMap.getString("dogumTarihi"));
			dealerInfoMap.put(calisanlarList, 0, "DOGUM_YERI", calisanKpsMap.getString("dogumyeri"));
			dealerInfoMap.put(calisanlarList, 0, "BABA_ADI", calisanKpsMap.getString("babaad"));
	
			eposta = bayiEdinimInfo.getBayiSahibiEposta();
			if(eposta != null){
				String[] epostaArray = eposta.split("@");
				if(epostaArray.length == 2){
					dealerInfoMap.put(calisanlarList, 0, "EPOSTA_NAME", epostaArray[0]);
					dealerInfoMap.put(calisanlarList, 0, "EPOSTA_NET", epostaArray[1]);
				}
			}
			
	    	GMMap calisanMusteriOMap = searchCustomer(bayiEdinimInfo.getTckn(), null, null);
	    	
			if(calisanMusteriOMap.getString("MUSTERI_NO") != null) {
	        	dealerInfoMap.put(calisanlarList, 0, "MUSTERI_NO", calisanMusteriOMap.getString("MUSTERI_NO"));
	        	dealerInfoMap.put(calisanlarList, 0, "YENI_MUSTERI_MI", false);
	    	} else {
	    		dealerInfoMap.put(calisanlarList, 0, "TCK_NO", bayiEdinimInfo.getTckn());
	        	dealerInfoMap.put(calisanlarList, 0, "YENI_MUSTERI_MI", true);
	    	}
	    	
	    	
	    	dealerInfoMap.put(calisanlarList, 0, "CEP_TEL_ALAN", bayiEdinimInfo.getCepTelefon1Kod());
			dealerInfoMap.put(calisanlarList, 0, "CEP_TEL", bayiEdinimInfo.getCepTelefon1No());
			dealerInfoMap.put(calisanlarList, 0, "ORTAK_MI", "H");
			dealerInfoMap.put(calisanlarList, 0, "TUTTUGU_TAKIM", "D");
			dealerInfoMap.put(calisanlarList, 0, "ORTAKLIK_PAYI", "0.00");
			dealerInfoMap.put(calisanlarList, 0, "POZISYONU", "SS");
			dealerInfoMap.put(calisanlarList, 0, "CALISAN_STATUSU", "A");
			dealerInfoMap.put(calisanlarList, 0, "YETKI_SEVIYESI", "SS");
			dealerInfoMap.put(calisanlarList, 0, "UYRUK", "TR");
			
		}

		dealerInfoMap.put("YETKI_SEVIYESI", "SS");

		GMMap dealerRole = getDealerRole("SS");
		if(dealerRole.get("OID") != null) {
			DefaultMutableTreeNode root = new DefaultMutableTreeNode(new GMMap());
			dealerRole.put("SELECTED", Boolean.TRUE);
			root.add(new DefaultMutableTreeNode(dealerRole));
			
			dealerInfoMap.put("YETKI_SEVIYE_TREE", root);
		}
		
        @SuppressWarnings("unchecked")
        List<BayiEdinimBayiFaaliyet> list = session.createCriteria(BayiEdinimBayiFaaliyet.class)
            .add(Restrictions.eq("id.musteriNo" , bayiEdinimInfo.getMusteriNo()))
            .list();

        if(list == null || list.size() == 0) {
        	dealerInfoMap.put("FAALIYET_KONUSU", new ArrayList());
        } else {
         
			int i=0;
	
			for (BayiEdinimBayiFaaliyet faaliyet: list){
	            dealerInfoMap.put("FAALIYET_KONUSU", i, "FAALIYET_KODU", faaliyet.getId().getFaaliyetKodu());
	            dealerInfoMap.put("FAALIYET_KONUSU", i, "SEC", true);
	            i++;
	        }
        }

        GMServiceExecuter.execute("BNSPR_TRN3247_SAVE_AND_CREATE_CONTAKT", dealerInfoMap);
		
		session.save(bayiEdinimInfo);

		oMap.put("RESPONSE", "2");
		return oMap;
	}
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_CREATE_DEALER_USER")
	public static GMMap bayiEdinimCreateDealerUser(GMMap iMap)  {
		GMMap oMap = new GMMap();
		iMap.put("PROCESS_KEY", "0");
		iMap.put("PROCESS_CODE", "BYED_CRTDLRUSR");
		oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
		return oMap;
	};		
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_CREATE_DEALER_USER_PROCESS")
	public static GMMap bayiEdinimCreateDealerUserProcess(GMMap iMap) {
		GMMap oMap = new GMMap();

		BigDecimal musteriNo = getMusteriNoFromProcessInstanceId(iMap);
		
		Session session = DAOSession.getSession("BNSPRDal");
		BayiEdinimBayi bayiEdinimInfo = (BayiEdinimBayi) session.get(BayiEdinimBayi.class, musteriNo);

		BirSatici satici = (BirSatici) session.createCriteria(BirSatici.class)
				.add(Restrictions.eq("drm", "G"))
				.add(Restrictions.eq("musteriNo", bayiEdinimInfo.getAkisMusteriNo()))
				.add(Restrictions.eq("subeMusteriNo", bayiEdinimInfo.getMusteriNo())).uniqueResult();
		
		if(satici == null) {
			satici = (BirSatici) session.createCriteria(BirSatici.class)
					.add(Restrictions.eq("drm", "G"))
					.add(Restrictions.eq("musteriNo", bayiEdinimInfo.getAkisMusteriNo()))
					.add(Restrictions.isNull("subeMusteriNo")).uniqueResult();
		}

		
		iMap.put("SATICI_KOD", satici.getKod());

		iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3166_GET_CALISAN_LIST", iMap));

		String calisanList = "CALISAN_LIST";
		for(int i=0;i<iMap.getSize(calisanList); i++){
			iMap.put(calisanList, i, "SEC", "1");
		}
		
		if(iMap.get("CALISAN_LIST") != null && iMap.getSize("CALISAN_LIST") > 0) {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			GMServiceExecuter.execute("BNSPR_TRN3166_SAVE", iMap);
			bayiEdinimInfo.setBayiDurumKod(BAYI_STATUS_FINISHED);
		} else {
			bayiEdinimInfo.setBayiDurumKod(BAYI_STATUS_FINISHED_WO_EMPLOYEE);
		}

		oMap.put("RESPONSE", "2");
		return oMap;
	}
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_SEND_TO_EVAM")
	public static GMMap bayiEdinimSendToEvam(GMMap iMap) {
		GMMap oMap = new GMMap();

//		BigDecimal musteriNo = getMusteriNoFromProcessInstanceId(iMap);

		// TODO EVAM Beslemece

		
		
		oMap.put("RESPONSE", "2");
		return oMap;
	}
	
	private static GMMap searchCustomer(String tckn, String ykn, String vkn) {
		
    	GMMap searchIMap = new GMMap();
    	if(tckn != null) {
    		searchIMap.put("TCKN", tckn);
    	}
    	if(ykn != null) {
    		searchIMap.put("YKN", ykn);
    	}
    	if(vkn != null) {
    		searchIMap.put("VKN", vkn);
    	}
    	
    	GMMap searchOMap = GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", searchIMap);
    	
    	return searchOMap;
    	
	}
	
	private static GMMap getDealerRole(String roleCode) {
		GMMap roleMap = new GMMap();

		GMMap channelSearchIMap = new GMMap();
		channelSearchIMap.put("CHANNEL_CODE", "DLR");
		GMMap channelSearchOMap = GMServiceExecuter.call("ADC_CORE_GET_CHANNEL_BY_CODE", channelSearchIMap);
		
		GMMap roleSearchIMap = new GMMap();
		roleSearchIMap.put("CHANNEL_OID", channelSearchOMap.get("CHANNEL_OID"));
		GMMap roleSearchOMap = GMServiceExecuter.call("ADC_CORE_ROLE_LIST", roleSearchIMap);
		
		
		for(int i=0, n=roleSearchOMap.getSize("LIST"); i<n; i++) {
			if(roleCode.equals(roleSearchOMap.get("LIST",i, "CODE"))) {
				roleMap.put("OID", roleSearchOMap.get("LIST",i, "OID"));
				roleMap.put("CODE", roleSearchOMap.get("LIST",i, "CODE"));
				roleMap.put("NAME", roleSearchOMap.get("LIST",i, "NAME"));
				break;
			}
		}
		
		return roleMap;
	}	
	
	private static GMMap getVergiDairesi(String dairekod){
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select vergi_d_kod, vergi_d_adi, il_kod from gnl_vergi_daire_kod_pr where vergi_d_kod = ?");
			
			stmt.setString(1, dairekod);
			rSet = stmt.executeQuery();

			if(rSet.next()) {
				oMap.put("VERGI_D_KOD", rSet.getString("vergi_d_kod"));
				oMap.put("VERGI_D_ADI", rSet.getString("vergi_d_adi"));
				oMap.put("IL_KOD", rSet.getString("il_kod"));
			}
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	@SuppressWarnings("unchecked")
	private static boolean calisanZatenTanimlimi(String tckn) {
		Session session = DAOSession.getSession("BNSPRDal");

		List<BirSaticiCalisan> calisanlar  = session.createCriteria(BirSaticiCalisan.class)
				.add(Restrictions.eq("tcKimlikNo", tckn))
					.add(Restrictions.ne("calStatuKod", "K"))
					.add(Restrictions.isNotNull("calStatuKod"))
				.add(Restrictions.eq("durum","ONAY")).list();
		
		return calisanlar != null && calisanlar.size() > 0;
	}
	
	private static BigDecimal getMusteriNoFromProcessInstanceId(GMMap iMap){
		String processInstanceId = iMap.getString("PROCESS_INSTANCE_ID");
		Session session = DAOSession.getSession("BNSPRDal");
		BpmProcessDetail bpmProcessDetail = (BpmProcessDetail) session.get(BpmProcessDetail.class, processInstanceId);
		return new BigDecimal(bpmProcessDetail.getBpmProcess().getId().getTrxNo());
	}
	
	/**
	 * WebDealer Init
	 * @param 
	 * @return
	 * 			--DISTRIBUTOR_LIST
	 * 			--TEL_ALAN_KOD
	 * 			--CEP_TEL_ALAN_KOD
	 */
	@GraymoundService("BNSPR_WEB_DEALER_APPLICATION_INIT")
	public static GMMap webDealerInitialize(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			iMap.put("COMBO", "DAGITICI_ALL");
			
			List<?> distributorList = GMReferenceDataFactory.getReferenceData("BAYI_EDINIM_DISTRIBUTOR");
			
			for(int i=0, n=distributorList.size(); i<n; i++){
				HashMap<?,?> distributor = (HashMap<?,?>) distributorList.get(i);

				oMap.put("DISTRIBUTOR_LIST", i,  "VALUE", distributor.get("CODE"));
				oMap.put("DISTRIBUTOR_LIST", i,  "NAME",distributor.get("NAME"));
			}


			//TODO: Paket taraf�nda fonksiyon yaz�lacak
			String query = "select g.kod, g.kod from gnl_tel_alan_kod_pr g where g.gsm = '?' order by g.kod";

			oMap.put("TEL_ALAN_KOD", DALUtil.fillComboBoxList(query.replace('?', 'H')));
			oMap.put("CEP_TEL_ALAN_KOD", DALUtil.fillComboBoxList(query.replace('?', 'E')));

			return oMap;
		} catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		} finally {

		}

		return oMap;

	}

	/**
	 *  get Customer_Info from email_ID
	 * @param iMap
	 * 				--EMAIL_ID
	 * @return
	 * 				--CUSTOMER_NO
	 * 				--result BNSPR_DLR_BAYI_EDINIM_GET
	 */
	@GraymoundService("BNSPR_WEB_DEALER_GET_CUSTOMER_INFO")
	public static GMMap getCustomerNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BayiEdinimEmail emailRecord = (BayiEdinimEmail) session
					.createCriteria(BayiEdinimEmail.class)
					.add(Restrictions.eq("id", iMap.get("EMAIL_ID")))
					.uniqueResult();
			if (emailRecord == null) {
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("WPK_CUST_INFO_NOT_FOUND", null));
				return oMap;
			}

			iMap.put("CUSTOMER_NUMBER", emailRecord.getMusteriNo());
			oMap.put("CUSTOMER_NUMBER", emailRecord.getMusteriNo());
			oMap.putAll(bayiEdinimGetRecord(iMap));

			if (!StringUtils.isBlank(oMap.getString("BAYI_DURUM_KOD"))) {
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("WPK19", null));
				return oMap;
			}
		} catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}
	
	
	/**
	 *  Servis cagirimlarinda hata alinirsa ilgili kisilere mail atar
	 * @param iMap
	 * 				--ERROR_MESSAGE
	 * @return
	 * 				--RESPONSE
	 */
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_SEND_EMAIL_FOR_SERVICE_ERROR")
	public static GMMap getSendEmailForServiceError(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			List<String> recipientsList = null;
			String rcpListStr = getParameterValue("BAYI_EDINIM_HATA_MAIL_TO");
			if (rcpListStr != null) {
				recipientsList = new ArrayList<String>();
				recipientsList.addAll(Arrays.asList(rcpListStr.split(";")));
			}
			
			GMMap servisMap = new GMMap();
			servisMap.put("IS_BODY_HTML"	,false);
			servisMap.put("FROM"			,getParameterValue("SISTEM_BILGI_MAIL"));
			servisMap.put("RECIPIENTS_TO"	,recipientsList);
			servisMap.put("SUBJECT"			,"Bayi Edinim Servis Hatasi !!! ");

			servisMap.put("MESSAGE_BODY", iMap.getString("ERROR_MESSAGE",""));
			GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);
			
		} catch (Exception e) {
			e.printStackTrace();
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}
	
	
	private static String getParameterValue(String parameter){
		GMMap iMap = new GMMap();
		iMap.put("PARAMETRE", parameter);
		return (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER");
	}
    public static boolean isValidEmail(String email) {
        Pattern pattern = Pattern
                .compile("^[A-Za-z0-9-_]+(\\.[A-Za-z0-9-_]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z0-9-]+)");
        Matcher match = pattern.matcher(email);
        if (!match.matches()) {
            return false;
        }
        return true;
    }
    public static boolean isValidNumericTel(String num, int lenght) {
        Pattern pattern = Pattern.compile("^[0-9]{"+lenght+","+lenght+"}$");
        Pattern onlyZero = Pattern.compile("^[0]{"+lenght+","+lenght+"}$");
        Matcher match1 = pattern.matcher(num);
        Matcher match2 = onlyZero.matcher(num);
        if (num==null || !match1.matches() || match2.matches()) {
            return false;
        }
        return true;
    }
    public static boolean isMatchPattern(String str, String patternStr) {
        if (str==null){
            return false;
        }
        Pattern pattern = Pattern.compile(patternStr);
        Matcher match1 = pattern.matcher(str);
        if (!match1.matches()) {
            return false;
        }
        return true;
    }
    
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_EMAIL_DELIVERY_STATUS_CHECK_JOB")
	public static GMMap checkEmailDeliveryStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		GMMap stateIMap = new GMMap();
		GMMap stateOMap = GMServiceExecuter.call("BNSPR_DLR_BAYI_EDINIM_GET_EMAIL_DELIVERY_STATES", stateIMap);
		Session session = DAOSession.getSession("BNSPRDal");
		
		for(int i=0, n=stateOMap.getSize("DELIVERY_RESULTS") ; i<n; i++) {

			String evamDeliveryStatus = getEvamStatusForDelivery(stateOMap.getString("DELIVERY_RESULTS",i,"DELIVERY_STATUS"));
			
			if(evamDeliveryStatus.trim().length() == 0) {
				logger.warn("Cannot find EVAM Status for "+stateOMap.getString("DELIVERY_RESULTS",i,"DELIVERY_STATUS") + "EmailId is null. Continue with next");
				continue;
			}
			
			String emailId = stateOMap.getString("DELIVERY_RESULTS",i,"REFER_KEY");
			
			if(emailId == null || emailId.trim().length() == 0) {
				logger.warn("EmailId is null. Continue with next");
				continue;
			}
			
			BayiEdinimEmail emailRecord = (BayiEdinimEmail) session.get(BayiEdinimEmail.class, emailId);
			
			if(emailRecord == null) {
				logger.warn("No email record exists for id "+emailId + ". Continue with next");
				continue;
			}
			
			emailRecord.setSonuc(evamDeliveryStatus);
			emailRecord.setSonucTarihi(new Date());
			
			session.save(emailRecord);
			
		}

		session.flush();
		
		return oMap;
	}
	
	private static String getEvamStatusForDelivery(String euroMsgDeliveryStatus) {
		if(euroMsgDeliveryStatus == null) {
			return "";
		}
		euroMsgDeliveryStatus = euroMsgDeliveryStatus.trim();
		
		if("HU".equals(euroMsgDeliveryStatus)) {
			return "HATALI";
		}
		
		if("RD".equals(euroMsgDeliveryStatus)) {
			return "OKUNDU";
		}
		
		return "";
	}
	
	

	@GraymoundService("BNSPR_EVAM_GET_EMAIL_DELIVERY_STATES_START")
	public static GMMap getEmailDeliveryStatesStart(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
		
			oMap.putAll(GMServiceExecuter.call("BNSPR_EUROMSG_GET_EMAIL_DELIVERY_STATES_START", iMap));

			oMap.put("RESPONSE", "1");
			
        } catch (Throwable t){
        	oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", t.getMessage());
        }
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_EVAM_GET_EMAIL_DELIVERY_STATES")
	public static GMMap getEmailDeliveryStates(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
		
			oMap.putAll(GMServiceExecuter.call("BNSPR_EUROMSG_GET_EMAIL_DELIVERY_STATES", iMap));

			oMap.put("RESPONSE", "1");
			
        } catch (Throwable t){
        	oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", t.getMessage());
        }
		
		return oMap;
	} 
	
	@GraymoundService("BNSPR_EVAM_SAVE_UPDATE_MEMBER")
	public static GMMap saveUpdateMember(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
		
			oMap.putAll(GMServiceExecuter.call("BNSPR_EUROMSG_SAVE_UPDATE_MEMBER", iMap));

			oMap.put("RESPONSE", "1");
			
        } catch (Throwable t){
        	oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", t.getMessage());
        }
		
		return oMap;
	} 

	
	@GraymoundService("BNSPR_EVAM_SAVE_MEMBER_LIST")
	public static GMMap saveMemberList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
		
			oMap.putAll(GMServiceExecuter.call("BNSPR_EUROMSG_SAVE_MEMBER_LIST", iMap));

			oMap.put("RESPONSE", "1");
			
        } catch (Throwable t){
        	oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", t.getMessage());
        }
		
		return oMap;
	} 
	
	
	@GraymoundService("BNSPR_EVAM_CREATE_EMAIL_CAMPAIGN")
	public static GMMap createEmailCampaign(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			
			oMap.putAll(GMServiceExecuter.call("BNSPR_EUROMSG_CREATE_EMAIL_CAMPAIGN", iMap));
		
			oMap.put("RESPONSE", "1");
			
        } catch (Throwable t){
        	oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", t.getMessage());
        }
		
		return oMap;
	} 
	
	
	@GraymoundService("BNSPR_EVAM_SEND_EMAIL_CAMPAIGN")
	public static GMMap sendEmailCampaign(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {

			oMap.putAll(GMServiceExecuter.call("BNSPR_EUROMSG_SEND_EMAIL_CAMPAIGN", iMap));
		
			oMap.put("RESPONSE", "1");
			
        } catch (Throwable t){
        	oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", t.getMessage());
        }
		
		return oMap;
	} 
	
	
	@GraymoundService("BNSPR_DLR_BAYI_EDINIM_SEND_SINGLE_MAIL")
	public static GMMap sendSingleMail ( GMMap iMap )
	{
		GMMap oMap = new GMMap();
		
		
		try
		{
			oMap.putAll(GMServiceExecuter.call("BNSPR_EUROMSG_SEND_SINGLE_HTML_EMAIL", iMap));
			oMap.put("RESPONSE", "2");
		}
		catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		
		
		return oMap;
		
		
	}
	
	
	
}


