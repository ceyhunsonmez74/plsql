package tr.com.calikbank.bnspr.adc.services;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.AdkKategori;
import tr.com.aktifbank.bnspr.dao.AdkKategoriTx;
import tr.com.aktifbank.bnspr.dao.AdkKategoriTxId;
import tr.com.aktifbank.bnspr.dao.AdkKategoriislem;
import tr.com.aktifbank.bnspr.dao.AdkKategoriislemTx;
import tr.com.aktifbank.bnspr.dao.AdkKategoriislemTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcTRN4105Services {
	@GraymoundService("BNSPR_TRN4105_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");	
			oMap.putAll(GMServiceExecuter.execute("GET_PROCESS_LIST", iMap));
			List<?> listProcess = (List<?>) oMap.get("PROCESS_LIST");
			oMap.remove("PROCESS_LIST");
			List<AdkKategori> kategoriList = (List<AdkKategori>) session.createCriteria(AdkKategori.class).list();
			List<AdkKategoriislem> kategoriislemList = (List<AdkKategoriislem>) session.createCriteria(AdkKategoriislem.class).list();
			for(int j=0;j<kategoriislemList.size();j++){
				int temp = 0;							
				for(int k=1;k<listProcess.size();k++){
					GMMap row = new GMMap((HashMap<?, ?>)listProcess.get(k));
					if((kategoriislemList.get(j).getId().getIslemOid().equals(row.getString("OID")))){
						temp = 1;
					}
				}if(temp==0){
					session.delete(kategoriislemList.remove(j--));
				}
			}
			for(int i=0;i<kategoriList.size();i++){
				String kategoriOid = kategoriList.get(i).getOid();
				oMap.put("KATEGORI_LIST",i,"OID",kategoriOid);
				oMap.put("KATEGORI_LIST",i,"MAIN",kategoriList.get(i).getMain());
				oMap.put("KATEGORI_LIST",i,"NAME",kategoriList.get(i).getName());
				oMap.put("KATEGORI_LIST",i,"SIL",0);
				for(int k=1;k<listProcess.size();k++){
					GMMap row = new GMMap((HashMap<?, ?>)listProcess.get(k));
					int temp = 0;
					String islemOid = row.getString("OID");
					oMap.put("TEMP",k-1,"OID", islemOid);
					oMap.put("TEMP",k-1,"CODE", row.get("CODE"));
					oMap.put("TEMP",k-1,"NAME", row.get("NAME"));				
					for(int j=0;j<kategoriislemList.size();j++){
						if((kategoriislemList.get(j).getId().getIslemOid().equals(islemOid)) && (kategoriislemList.get(j).getId().getKategoriOid().equals(kategoriOid))){
							temp = 1;
						}
					}
					oMap.put("TEMP",k-1,"SEC", temp);
					oMap.put("TEMP",k-1,"SEC_ILK", temp);
				}
				oMap.put("KATEGORI_LIST",i,"MODEL_DATA",oMap.get("TEMP"));
				oMap.remove("TEMP");
			}
			for(int k=1;k<listProcess.size();k++){  // 0 Se�iniz oldu�undan 1 kullan�ld�.
				GMMap row = new GMMap((HashMap<?, ?>)listProcess.get(k));
				oMap.put("PROCESS_LIST",k-1,"OID",  row.get("OID"));
				oMap.put("PROCESS_LIST",k-1,"CODE", row.get("CODE"));
				oMap.put("PROCESS_LIST",k-1,"NAME", row.get("NAME"));				
				oMap.put("PROCESS_LIST",k-1,"SEC", 0);
				oMap.put("PROCESS_LIST",k-1,"SEC_ILK", 0);
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_TRN4105_ADD_ROW")
	public static GMMap addRow(GMMap iMap) {
		try {
			int size = iMap.getSize("KATEGORI_LIST");
			iMap.put("KATEGORI_LIST",size,"OID","");
			iMap.put("KATEGORI_LIST",size,"NAME","");
			iMap.put("KATEGORI_LIST",size,"SIL",0);
			iMap.put("KATEGORI_LIST",size,"MAIN",0);		
			iMap.put("KATEGORI_LIST",size,"MODEL_DATA",iMap.get("PROCESS_LIST"));
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	

	@GraymoundService("BNSPR_TRN4105_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
		Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "KATEGORY_TABLE";
			String tableName2= "MODEL_DATA";
		
			//Ana Kategori
			if(iMap.get(tableName) != null) {
				List<?> list = (List<?>) iMap.get(tableName);
				if(list.size() > 0) {
					for (int i = 0; i < list.size(); i++) {
						AdkKategoriTx adkKategoriTx = new AdkKategoriTx();
				
						AdkKategoriTxId id = new AdkKategoriTxId();
					   if (!(("S").equals(iMap.getString(tableName, i, "SIL"))&&iMap.getString(tableName, i,"OID")==null))
		                    {
						String kategoriOid = iMap.getString(tableName, i, "OID");
				
						id.setTxNo(iMap.getBigDecimal("TRX_NO"));
						if ("".equals(kategoriOid) || kategoriOid == null)
						{
							id.setOid(UUID.randomUUID().toString().replace("-", ""));
						}
						else
						id.setOid(kategoriOid);
						
						adkKategoriTx.setId(id);
						
						adkKategoriTx.setName(iMap.getString(tableName,i,"NAME"));
						adkKategoriTx.setMain(iMap.getString(tableName,i,"MAIN"));
						
						if(iMap.getBoolean(tableName,i,"SIL")) {
	                    	adkKategoriTx.setSil("S");
						}
						else 
							adkKategoriTx.setSil("");
						
						
						//Alt Kategori
						if (iMap.get(tableName, i, tableName2) != null) {
							List<?> list2 = (List<?>) iMap.get(tableName, i,
									tableName2);
							if (list2.size() > 0) {
								for (int j = 0; j < list2.size(); j++) {
									GMMap altKategoriMap = new GMMap(
											(HashMap<?, ?>) list2.get(j));
									if ("1".equals(altKategoriMap.get("SEC"))) {
										AdkKategoriislemTx adkKategoriislemTx = new AdkKategoriislemTx();

										AdkKategoriislemTxId id2 = new AdkKategoriislemTxId();

										id2.setTxNo(iMap
												.getBigDecimal("TRX_NO"));
										
										id2.setKategoriOid(adkKategoriTx.getId().getOid());

										if ("".equals(altKategoriMap.getString("OID")) || altKategoriMap.getString("OID") == null) {
											id2.setIslemOid(UUID.randomUUID()
													.toString()
													.replace("-", ""));
										} else
											id2.setIslemOid(altKategoriMap
													.getString("OID"));

										adkKategoriislemTx.setId(id2);

										session.save(adkKategoriislemTx);
										session.flush();
									}
								}
							}
					    }
		          }
						session.save(adkKategoriTx);
						session.flush();
					}
				}
			}
	
			iMap.put("TRX_NAME", "4105");		
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

				} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
	
