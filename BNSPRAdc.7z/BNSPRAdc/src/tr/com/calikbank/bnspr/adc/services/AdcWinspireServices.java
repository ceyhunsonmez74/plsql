package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.obss.adc.core.pojo.Process;
import tr.com.obss.adc.core.util.ADCCore;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcWinspireServices {
	
	public static String getProcessName(String processCode){
		Session 	session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		Process process = (Process) session.createCriteria(Process.class)
			.add(Restrictions.eq("code",processCode ))
			.uniqueResult();
		return process.getName(	(String)GMContext.getCurrentContext().getSession().get("language" ));
	}
	@GraymoundService("BNSPR_WINSPIRE_INTEGRATION")
	public static GMMap BnsprWinspreIntegration(GMMap iMap) {
		GMConnection connection = null;
		GMMap oMap = new GMMap();
		try {
			connection = GMConnection.getConnection("INT");
			oMap = new GMMap(connection.serviceCall(iMap.getString("SERVICE_NAME"), iMap));
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} 
		return oMap;
	}
	public static String getUserName(String userCode,String firmCode){
		if (firmCode!=null&&firmCode.length()>0){
			return userCode.toString().concat("@").concat(firmCode.toString());
		}else{
			return userCode==null?null:userCode.toString();
		}
	}
	public static String getUserName(BigDecimal userCode,BigDecimal firmCode){
		if (firmCode!=null&&firmCode.intValue()!=0){
			return userCode.toString().concat("@").concat(firmCode.toString());
		}else{
			return userCode.toString();
		}

	}
}
