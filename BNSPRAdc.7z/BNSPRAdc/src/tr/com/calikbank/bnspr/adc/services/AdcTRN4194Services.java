package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlDkGrupUrunSinifTx;
import tr.com.aktifbank.bnspr.dao.GnlDkGrupUrunSinifTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDkGrupUrunSinifPr;
import tr.com.calikbank.bnspr.dao.GnlDkGrupUrunSinifPrId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4194Services {
	

	  @GraymoundService("BNSPR_TRN4194_GET_GRUP_URUN_SINIF")
	    public static Map<?, ?> getUrunList(GMMap iMap) {
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        GMMap oMap = new GMMap();
	        try{
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_TRN4194.GET_URUN_SINIF_LISTE(?)}");
	        	int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setBigDecimal(i++, iMap.getBigDecimal("DK_GRUP_KODU"));
	            stmt.execute();
	            
	          
				rSet = (ResultSet) stmt.getObject(1);
				String tableName1 = "GRUP_URUN_SINIF";
			   
				for (int row = 0; rSet.next(); row++){
		                
		                oMap.put(tableName1 , row , "MODUL_TUR_KOD" , rSet.getString("MODUL_TUR_KOD"));
		                oMap.put(tableName1 , row , "URUN_TUR_KOD" , rSet.getString("URUN_TUR_KOD"));
		                oMap.put(tableName1 , row , "URUN_SINIF_KOD" , rSet.getString("URUN_SINIF_KOD"));
		                oMap.put(tableName1 , row , "DK_HESABI_1" , rSet.getString("DK_ANA"));
		                oMap.put(tableName1 , row , "INT_BANK_GORUNTU_F" , GuimlUtil.convertToCheckBoxSelected(rSet.getString("INT_BANK_GORUNTU_F")));
		                oMap.put(tableName1 , row , "INT_ISLEM" , GuimlUtil.convertToCheckBoxSelected(rSet.getString("INT_ISLEM")));
		                oMap.put(tableName1 , row , "DK_FAIZ_GELIR" , rSet.getString("DK_FAIZ_GELIR"));
		                oMap.put(tableName1 , row , "DK_FAIZ_GIDER" , rSet.getString("DK_FAIZ_GIDER"));
		                oMap.put(tableName1 , row , "DK_REESKONT" , rSet.getString("DK_REESKONT"));
		                oMap.put(tableName1 , row , "DK_KOM_GELIR" , rSet.getString("DK_KOM_GELIR"));
		                oMap.put(tableName1 , row , "DK_KOM_REESKONT" , rSet.getString("DK_KOM_REESKONT"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_7" , rSet.getString("DK_EKHESAP_7"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_8" , rSet.getString("DK_EKHESAP_8"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_9" , rSet.getString("DK_EKHESAP_9"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_10" , rSet.getString("DK_EKHESAP_10"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_11" , rSet.getString("DK_EKHESAP_11"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_12" , rSet.getString("DK_EKHESAP_12"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_13" , rSet.getString("DK_EKHESAP_13"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_14" , rSet.getString("DK_EKHESAP_14"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_15" , rSet.getString("DK_EKHESAP_15"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_16" , rSet.getString("DK_EKHESAP_16"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_17" , rSet.getString("DK_EKHESAP_17"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_18" , rSet.getString("DK_EKHESAP_18"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_19" , rSet.getString("DK_EKHESAP_19"));
		                oMap.put(tableName1 , row , "DK_EKHESAP_20" , rSet.getString("DK_EKHESAP_20"));
		                
				}
		            
				
				return oMap;
	       
	        } catch (Exception e){
	            
	            throw ExceptionHandler.convertException(e);
	            
	        } finally{
	            
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	            
	        }
	    }
		@GraymoundService("BNSPR_TRN4194_SAVE")
		public static Map<?, ?> save(GMMap iMap){
			try{
				Session session = DAOSession.getSession("BNSPRDal");
				
				List<?> urunGrupList = (List<?>)session.createCriteria(GnlDkGrupUrunSinifTx.class).add(Restrictions.eq("id.grupKod",iMap.getBigDecimal("DK_GRUP_KODU"))).list();
				for (Iterator<?> iterator = urunGrupList.iterator(); iterator.hasNext();) {
					GnlDkGrupUrunSinifTx dkGrupUrunSinifPr = (GnlDkGrupUrunSinifTx) iterator.next();
					session.delete(dkGrupUrunSinifPr);
				}
				
				String tableName = "GRUP_URUN_SINIF";
				for (int row = 0; row < iMap.getSize(tableName); row++) {
					
					GnlDkGrupUrunSinifTx dkGrupUrunSinifPr = new GnlDkGrupUrunSinifTx();
					GnlDkGrupUrunSinifTxId dkGrupUrunSinifPrId = new GnlDkGrupUrunSinifTxId();
					
					dkGrupUrunSinifPrId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					dkGrupUrunSinifPrId.setGrupKod(iMap.getBigDecimal("DK_GRUP_KODU"));
					dkGrupUrunSinifPrId.setModulTurKod(iMap.getString(tableName, row, "MODUL_TUR_KOD"));
					dkGrupUrunSinifPrId.setUrunTurKod(iMap.getString(tableName, row, "URUN_TUR_KOD"));
					dkGrupUrunSinifPrId.setUrunSinifKod(iMap.getString(tableName, row, "URUN_SINIF_KOD"));
					dkGrupUrunSinifPr.setId(dkGrupUrunSinifPrId);
					dkGrupUrunSinifPr.setDkAna(iMap.getString(tableName, row, "DK_HESABI_1"));
					dkGrupUrunSinifPr.setDkFaizGelir(iMap.getString(tableName, row, "DK_FAIZ_GELIR"));
					dkGrupUrunSinifPr.setDkFaizGider(iMap.getString(tableName, row, "DK_FAIZ_GIDER"));
					dkGrupUrunSinifPr.setDkReeskont(iMap.getString(tableName, row, "DK_REESKONT"));
					dkGrupUrunSinifPr.setDkKomGelir(iMap.getString(tableName, row, "DK_KOM_GELIR"));
					dkGrupUrunSinifPr.setDkKomReeskont(iMap.getString(tableName, row, "DK_KOM_REESKONT"));
					dkGrupUrunSinifPr.setDkEkhesap7(iMap.getString(tableName, row, "DK_EKHESAP_7"));
					dkGrupUrunSinifPr.setDkEkhesap8(iMap.getString(tableName, row, "DK_EKHESAP_8"));
					dkGrupUrunSinifPr.setDkEkhesap9(iMap.getString(tableName, row, "DK_EKHESAP_9"));
					dkGrupUrunSinifPr.setDkEkhesap10(iMap.getString(tableName, row, "DK_EKHESAP_10"));
					dkGrupUrunSinifPr.setDkEkhesap11(iMap.getString(tableName, row, "DK_EKHESAP_11"));
					dkGrupUrunSinifPr.setDkEkhesap12(iMap.getString(tableName, row, "DK_EKHESAP_12"));
					dkGrupUrunSinifPr.setDkEkhesap13(iMap.getString(tableName, row, "DK_EKHESAP_13"));
					dkGrupUrunSinifPr.setDkEkhesap14(iMap.getString(tableName, row, "DK_EKHESAP_14"));
					dkGrupUrunSinifPr.setDkEkhesap15(iMap.getString(tableName, row, "DK_EKHESAP_15"));
					dkGrupUrunSinifPr.setDkEkhesap16(iMap.getString(tableName, row, "DK_EKHESAP_16"));
					dkGrupUrunSinifPr.setDkEkhesap17(iMap.getString(tableName, row, "DK_EKHESAP_17"));
					dkGrupUrunSinifPr.setDkEkhesap18(iMap.getString(tableName, row, "DK_EKHESAP_18"));
					dkGrupUrunSinifPr.setDkEkhesap19(iMap.getString(tableName, row, "DK_EKHESAP_19"));
					dkGrupUrunSinifPr.setDkEkhesap20(iMap.getString(tableName, row, "DK_EKHESAP_20"));
					dkGrupUrunSinifPr.setIntBankGoruntuF(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, row, "INT_BANK_GORUNTU_F")));
					dkGrupUrunSinifPr.setIntBankIslemYapilsinF(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, row, "INT_ISLEM")));
					session.saveOrUpdate(dkGrupUrunSinifPr);
				}
				session.flush();

				iMap.put("TRX_NAME", "4194");
				return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
				
			}catch (NonUniqueObjectException e) {
				GMMap myMap = new GMMap();
				myMap.put("MESSAGE_NO", new BigDecimal(710));
				throw new GMRuntimeException(0,(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
	
	
	@GraymoundService("BNSPR_TRN4194_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap(); 
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(
					GnlDkGrupUrunSinifTx.class).add(
					Restrictions.eq("id.txNo", iMap
							.getBigDecimal("TRX_NO"))).list();

			String tableName = "GRUP_URUN_SINIF";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext(); row++) {
				GnlDkGrupUrunSinifTx dkGrupUrunSinifPr = (GnlDkGrupUrunSinifTx)iterator.next();
				oMap.put("DK_GRUP_KODU", dkGrupUrunSinifPr.getId().getGrupKod());
				oMap.put(tableName, row, "MODUL_TUR_KOD", dkGrupUrunSinifPr.getId().getModulTurKod());
                oMap.put(tableName, row, "URUN_TUR_KOD", dkGrupUrunSinifPr.getId().getUrunTurKod());
                oMap.put(tableName, row, "URUN_SINIF_KOD", dkGrupUrunSinifPr.getId().getUrunSinifKod());
                oMap.put(tableName, row, "DK_HESABI_1", dkGrupUrunSinifPr.getDkAna());
                oMap.put(tableName, row, "DK_FAIZ_GELIR", dkGrupUrunSinifPr.getDkFaizGelir());
                oMap.put(tableName, row, "DK_FAIZ_GIDER", dkGrupUrunSinifPr.getDkFaizGider());
                oMap.put(tableName, row, "DK_REESKONT", dkGrupUrunSinifPr.getDkReeskont());
                oMap.put(tableName, row, "DK_KOM_GELIR", dkGrupUrunSinifPr.getDkKomGelir());
                oMap.put(tableName, row, "DK_KOM_REESKONT", dkGrupUrunSinifPr.getDkKomReeskont());
                oMap.put(tableName, row, "DK_EKHESAP_7", dkGrupUrunSinifPr.getDkEkhesap7());
                oMap.put(tableName, row, "DK_EKHESAP_8", dkGrupUrunSinifPr.getDkEkhesap8());
                oMap.put(tableName, row, "DK_EKHESAP_9", dkGrupUrunSinifPr.getDkEkhesap9());
                oMap.put(tableName, row, "DK_EKHESAP_10", dkGrupUrunSinifPr.getDkEkhesap10());
                oMap.put(tableName, row, "DK_EKHESAP_11", dkGrupUrunSinifPr.getDkEkhesap11());
                oMap.put(tableName, row, "DK_EKHESAP_12", dkGrupUrunSinifPr.getDkEkhesap12());
                oMap.put(tableName, row, "DK_EKHESAP_13", dkGrupUrunSinifPr.getDkEkhesap13());
                oMap.put(tableName, row, "DK_EKHESAP_14", dkGrupUrunSinifPr.getDkEkhesap14());
                oMap.put(tableName, row, "DK_EKHESAP_15", dkGrupUrunSinifPr.getDkEkhesap15());
                oMap.put(tableName, row, "DK_EKHESAP_16", dkGrupUrunSinifPr.getDkEkhesap16());
                oMap.put(tableName, row, "DK_EKHESAP_17", dkGrupUrunSinifPr.getDkEkhesap17());
                oMap.put(tableName, row, "DK_EKHESAP_18", dkGrupUrunSinifPr.getDkEkhesap18());
                oMap.put(tableName, row, "DK_EKHESAP_19", dkGrupUrunSinifPr.getDkEkhesap19());
                oMap.put(tableName, row, "DK_EKHESAP_20", dkGrupUrunSinifPr.getDkEkhesap20());
                oMap.put(tableName, row, "INT_BANK_GORUNTU_F", GuimlUtil.convertToCheckBoxSelected(dkGrupUrunSinifPr.getIntBankGoruntuF()));
                oMap.put(tableName, row, "INT_ISLEM", GuimlUtil.convertToCheckBoxSelected(dkGrupUrunSinifPr.getIntBankIslemYapilsinF()));
                oMap.put("ACIKLAMA",LovHelper.diLov(dkGrupUrunSinifPr.getId().getGrupKod(), "4194/LOV_DK_GRUP_KODLARI", "ACIKLAMA"));
                oMap.put("MUSTERI_TIPI",LovHelper.diLov(dkGrupUrunSinifPr.getId().getGrupKod(), "4194/LOV_DK_GRUP_KODLARI", "MUSTERI_TIPI"));
                oMap.put("MUSTERI_TIPI_ADI",LovHelper.diLov(dkGrupUrunSinifPr.getId().getGrupKod(), "4194/LOV_DK_GRUP_KODLARI", "MUSTERI_TIPI_ADI"));
                oMap.put("YERLESIM_TIPI",LovHelper.diLov(dkGrupUrunSinifPr.getId().getGrupKod(), "4194/LOV_DK_GRUP_KODLARI", "YERLESIM_TIPI"));
                oMap.put("YERLESIM_TIPI_ADI",LovHelper.diLov(dkGrupUrunSinifPr.getId().getGrupKod(), "4194/LOV_DK_GRUP_KODLARI", "YERLESIM_TIPI_ADI"));
                
			}

			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
