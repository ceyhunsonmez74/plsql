package tr.com.calikbank.bnspr.adc.services;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.swing.tree.DefaultMutableTreeNode;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AdcTRNMENUServices {

/*private static void createMenuNode(DefaultMutableTreeNode parent,Menu menu,String roleOid,Set<Role> userRoles){
    
		GMMap    item    = new GMMap();
        item.put("OID"                ,menu.getOid());
        item.put("NAME"                ,menu.getName(ADCSession.getLanguage()));
        String pageName = menu.getPage(ADCSession.getLanguage());
        String controlPageName = menu.getControlPage(ADCSession.getLanguage());
        item.put("PAGE_NAME"            ,pageName == null ? "" :pageName);
        item.put("CONTROL_PAGE_NAME"     ,controlPageName == null ? "" :controlPageName);
        item.put("ICON_NAME"            ,menu.getIconName());
        item.put("SHORT_CUT_KEY"        ,menu.getShortCutKey());
        item.put("FONT"                    ,menu.getFont());
        item.put("COLOR_FG"                ,menu.getColorFG());        
        item.put("SORT_ORDER"            ,menu.getSortOrder());
        item.put("CODE"                    ,menu.getCode());
        item.put("NEW_MESSAGE_DATE"        ,menu.getNewMessageDate());
        item.put("POP_UP"                ,String.valueOf(menu.getPopUp()));

        GMMap variables = new GMMap();
        variables.put("PAGE_NAME"            , item.get("PAGE_NAME"));
        variables.put("CONTROL_PAGE_NAME"    , item.get("CONTROL_PAGE_NAME"));
        variables.put("PAGE_OID"            , item.get("OID"));
        
        item.put("VARIABLES"            ,variables);
        
        if (roleOid != null){
            item.put("SELECTED", false);
            Set<Role> roles = menu.getRoles();
            for (Iterator<Role> iterator = roles.iterator(); iterator.hasNext();) {
                Role role = iterator.next();
                if (roleOid.equals(role.getOid())){
                    item.put("SELECTED", true);
                    break;
                }
            }
        }
        
        item.put("NODE_TYPE"        ,"MENU");
        
        DefaultMutableTreeNode node = null;
        
        if (roleOid != null){
            node = new TristateTreeNode(item);
        } else {
            node = new DefaultMutableTreeNode(item);
        }
        

        for (Iterator<?> iter = menu.getChildren().iterator(); iter.hasNext();) {
            Menu child = (Menu) iter.next();
            createMenuNode(node,child,roleOid,userRoles);
        }
        
        if (userRoles != null){
            if (menu.hasRole(userRoles)){
                parent.add(node);
            }
        } else {
            parent.add(node);
        }

	}*/
	
			
		@GraymoundService("BNSPR_TRNMENU")
		public static HashMap<String, Object> getAccountList(GMMap iMap) {
			Connection conn = null;
			PreparedStatement stmt = null;
			ResultSet resultSet = null;
			try {
				conn = DALUtil.getGMConnection();
				StringBuilder query = new StringBuilder();
				
				query.append("select a.level_,a.kodu,a.adi,a.PAR1,( Select max('E') From gnl_rol_program_tx s Where s.program_kod = a.KODU And s.rol_numara = ? and s.tx_no = ? ) Tanim_var ");
				query.append("from V_GNL_PROGRAM_MENU_TREE a");
				
				stmt = conn.prepareStatement(query.toString());
				stmt.setBigDecimal(1,new BigDecimal(1));
				stmt.setBigDecimal(2, new BigDecimal(97110));
				
				ArrayList<DefaultMutableTreeNode> level1List = new ArrayList<DefaultMutableTreeNode>();
				ArrayList<DefaultMutableTreeNode> level2List = new ArrayList<DefaultMutableTreeNode>();
				ArrayList<DefaultMutableTreeNode> level3List = new ArrayList<DefaultMutableTreeNode>();
				
				DefaultMutableTreeNode root = new DefaultMutableTreeNode();
				HashMap<String, Object> rootUo = new HashMap<String, Object>();
				rootUo.put("NAME", "Programlar");
				rootUo.put("ADI", "");
				rootUo.put("TANIM_VAR", "0");
				rootUo.put("LEVEL", new BigDecimal(0));
				root.setUserObject(rootUo);
				
				resultSet = stmt.executeQuery();
				while (resultSet.next()) {
					HashMap<String, Object> rowData = new HashMap<String, Object>();
					BigDecimal level = resultSet.getBigDecimal(1);
					DefaultMutableTreeNode node = new DefaultMutableTreeNode();
					node.setUserObject(rowData);
					rowData.put("NAME", resultSet.getString(2));
					rowData.put("ADI", resultSet.getString(3));
					rowData.put("PAR1", resultSet.getString(4));
					rowData.put("TANIM_VAR", GuimlUtil.convertToCheckBoxValue(resultSet.getString(5)));
					rowData.put("LEVEL", level);
					if(level.compareTo(new BigDecimal(1)) == 0){
						level1List.add(node);
						root.add(node);
					}
					else if(level.compareTo(new BigDecimal(2)) == 0){
						level2List.add(node);
					}
					else if(level.compareTo(new BigDecimal(3)) == 0){
						level3List.add(node);
					}
				}
				for (Iterator<?> iterator = level1List.iterator(); iterator.hasNext();) {
					DefaultMutableTreeNode l1node = (DefaultMutableTreeNode) iterator.next();
					HashMap<?, ?> l1uo = (HashMap<?, ?>)l1node.getUserObject();
					for (Iterator<?> iterator2 = level2List.iterator(); iterator2.hasNext();) {
						DefaultMutableTreeNode l2Node = (DefaultMutableTreeNode) iterator2.next();
						HashMap<?, ?> l2uo = (HashMap<?, ?>)l2Node.getUserObject();
						if(l1uo.get("NAME").equals(l2uo.get("PAR1")))
							l1node.add(l2Node);
						for (Iterator<?> iterator3 = level3List.iterator(); iterator3.hasNext();) {
							DefaultMutableTreeNode l3Node = (DefaultMutableTreeNode) iterator3.next();
							HashMap<?, ?> l3uo = (HashMap<?, ?>)l3Node.getUserObject();
							if(l2uo.get("NAME").equals(l3uo.get("PAR1")))
								l2Node.add(l3Node);
						}
					}
				}
				
				HashMap<String, Object> oMap = new HashMap<String, Object>();
				oMap.put("TREE", root);
				return oMap;

			} catch (SQLException e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(resultSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
	}