package tr.com.calikbank.bnspr.adc.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcValidationServices {
	
	private static Logger logger = Logger.getLogger(AdcValidationServices.class);
	
	private static Configurator conf = Configurator.createConfiguratorFromProperties("configuration/adc-validation.properties");
	
	@GraymoundService("BNSPR_ADC_SEND_VALIDATION_MAIL")
	public static GMMap sendValidationMail(GMMap iMap){
		GMMap oMap=new GMMap();
		try {
			GMMap mailMap = new GMMap();		
			mailMap.put("RECIPIENTS_TO", createRecipientList(iMap.getString("ADDRESS")));
			mailMap.put("FROM", iMap.getString("FROM"));
			mailMap.put("SUBJECT", iMap.getString("SUBJECT"));
			mailMap.put("IS_BODY_HTML", true);
			mailMap.put("MESSAGE_BODY", getHtmlMailData(iMap.getString("MESSAGE"), iMap.getString("TEMPLATE")));
			GMServiceExecuter.call("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailMap);
			oMap.put("RESPONSE", "2");
			
		} catch (Exception exp) {
			logger.error(exp);
			oMap.put("RESPONSE", "0");
		}
		return oMap;
	}
	
	private static ArrayList<String> createRecipientList(String value) {
		ArrayList<String> list = new ArrayList<String>();
		list.add(value);
		return list;
	}
	
	private static String getHtmlMailData(String message, String template){
		GMMap htmlMap=new GMMap();
		htmlMap.put("FOLDER_NAME", conf.getProperty("mail.template.folder"));
		htmlMap.put("TEMPLATE_NAME", getTemplateConf(template));
		htmlMap.put("ENCODING", conf.getProperty("mail.template.encoding"));
		htmlMap.put("INPUTS", getVmTemplateParameters(message));	
		return GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_HTML", htmlMap).getString("HTML_DATA");
	}
	private static String getTemplateConf(String template){
		String vmName=StringUtils.isEmpty(template)?null:conf.getProperty("mail.template.file."+template);
		return vmName!=null?vmName:conf.getProperty("mail.template.file.default");
		
	}
	private static Map<String,Object> getVmTemplateParameters(String message){
		Map<String,Object> inputs=new HashMap<String, Object>();
		inputs.put("MESSAGE", message);
		return inputs;
	}
}
