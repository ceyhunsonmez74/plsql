package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkKanalBlokeRolTx;
import tr.com.calikbank.bnspr.dao.AdkKanalBlokeRolTxId;
import tr.com.calikbank.bnspr.dao.AdkKanalParametreTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcTRN4130Services {

	@GraymoundService("BNSPR_TRN4130_SAVE")
	public static GMMap saveTRN4130(GMMap iMap){
	try {
			Session session = DAOSession.getSession("BNSPRDal");
		
			String kanalKodu;
			String blokeNedenKodu;
			String blokeAltNedenKodu;
			AdkKanalParametreTx adkKanalParametreTx = new AdkKanalParametreTx();

			kanalKodu = iMap.getString("KANAL_KOD");
			blokeNedenKodu =  iMap.getString("BLOKE_NEDEN_KOD");
			blokeAltNedenKodu = iMap.getString("BLOKE_ALT_NEDEN_KOD");
			if(kanalKodu == null || kanalKodu.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kanal Kodu");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}	
			if(blokeNedenKodu == null || blokeNedenKodu.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Bloke Neden Kod");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}	
			adkKanalParametreTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			adkKanalParametreTx.setBlokeNedenKod(blokeNedenKodu);
			adkKanalParametreTx.setKanalKod(kanalKodu);
			adkKanalParametreTx.setBlokeAltNedenKod(blokeAltNedenKodu);
			adkKanalParametreTx.setAciklama(iMap.getString("ACIKLAMA"));
			adkKanalParametreTx.setBlokeKoymaYontemi(iMap.getString("BLOKE_KOYMA_YONTEMI"));
			adkKanalParametreTx.setBlokeKaldirmaYontemi(iMap.getString("BLOKE_KALDIRMA_YONTEMI"));
			adkKanalParametreTx.setBaslangicTarihiEh(iMap.getString("BASLANGIC_TARIHI_EH"));
			adkKanalParametreTx.setBitisTarihiEh(iMap.getString("BITIS_TARIHI_EH"));
			adkKanalParametreTx.setMailGondermeEh(iMap.getString("MAIL_GONDERME_EH"));
			if (("E").equals(iMap.getString("MAIL_GONDERME_EH"))){
				adkKanalParametreTx.setMailAdresleri(iMap.getString("MAIL_ADRESLERI"));
	
			}else if (iMap.getString("MAIL_GONDERME_EH")== null||iMap.getString("MAIL_GONDERME_EH").isEmpty()||("H").equals(iMap.getString("MAIL_GONDERME_EH"))){
				adkKanalParametreTx.setMailAdresleri(null);
			}
			
			adkKanalParametreTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			adkKanalParametreTx.setKanalParametreId(iMap.getBigDecimal("KANAL_PARAMETRE_ID"));
			session.saveOrUpdate(adkKanalParametreTx);
			
			String tableName = "BLOKE_KOYACAK_ROL_TUR_KODLARI";
			List<BigDecimal> blokeRollerList = new ArrayList<BigDecimal>();
			BigDecimal rolNumara;
			List<?> list = (List<?>) iMap.get(tableName);
			for(int i=0; i<list.size();i++) {
				rolNumara = iMap.getBigDecimal(tableName, i, "ROL_NUMARA");
				if(rolNumara == null )
				{
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Rol Numara");
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}	
				AdkKanalBlokeRolTxId id2 = new AdkKanalBlokeRolTxId();
				id2.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id2.setBlokeIslemTuru(iMap.getString(tableName, i, "BLOKE_ISLEM_TURU"));
				id2.setRolNumara(rolNumara);
				if (blokeRollerList.contains(rolNumara)) {
					iMap.put("HATA_NO", new BigDecimal(1223));
					iMap.put("P1", rolNumara);
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				} 
				blokeRollerList.add(rolNumara);
				AdkKanalBlokeRolTx adkKanalBlokeRolTx = (AdkKanalBlokeRolTx) session.get(AdkKanalBlokeRolTx.class, id2);
				if (adkKanalBlokeRolTx == null) {
					adkKanalBlokeRolTx = new AdkKanalBlokeRolTx();
					adkKanalBlokeRolTx.setId(id2);
				} 
				adkKanalBlokeRolTx.setKanalKod(kanalKodu);
				adkKanalBlokeRolTx.setBlokeNedenKod(blokeNedenKodu);
				adkKanalBlokeRolTx.setBlokeAltNedenKod(blokeAltNedenKodu);
				adkKanalBlokeRolTx.setGDS(iMap.getBoolean(tableName, i, "SIL") ? "S" : "D");
		
				session.saveOrUpdate(adkKanalBlokeRolTx);
		     }
			
			String tableName2 = "BLOKE_KALDIRACAK_ROL_TUR_KODLARI";
			List<BigDecimal> blokeRollerList2 = new ArrayList<BigDecimal>();
			BigDecimal rolNumara2;
			List<?> list2 = (List<?>) iMap.get(tableName2);
			for(int i=0; i<list2.size();i++) {
				rolNumara2 = iMap.getBigDecimal(tableName2, i, "ROL_NUMARA");
				if(rolNumara2 == null )
				{
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Rol Numara");
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}	
				AdkKanalBlokeRolTxId id3 = new AdkKanalBlokeRolTxId();
				id3.setTxNo(iMap.getBigDecimal("TRX_NO")); 
				id3.setBlokeIslemTuru(iMap.getString(tableName2, i, "BLOKE_ISLEM_TURU"));
				id3.setRolNumara(rolNumara2);
				
				if (blokeRollerList2.contains(rolNumara2)) {
					iMap.put("HATA_NO", new BigDecimal(1223));
					iMap.put("P1", rolNumara2);
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				} 
				blokeRollerList2.add(rolNumara2);
				AdkKanalBlokeRolTx adkKanalBlokeRolTx = (AdkKanalBlokeRolTx) session.get(AdkKanalBlokeRolTx.class, id3);
				if (adkKanalBlokeRolTx == null) {
					adkKanalBlokeRolTx = new AdkKanalBlokeRolTx();
					adkKanalBlokeRolTx.setId(id3);
				} 
				adkKanalBlokeRolTx.setKanalKod(kanalKodu);
				adkKanalBlokeRolTx.setBlokeNedenKod(blokeNedenKodu);
				adkKanalBlokeRolTx.setBlokeAltNedenKod(blokeAltNedenKodu);
				adkKanalBlokeRolTx.setGDS(iMap.getBoolean(tableName2, i, "SIL") ? "S" : "D");
		
				session.saveOrUpdate(adkKanalBlokeRolTx);
		     }
		
			session.flush();

			iMap.put("TRX_NAME", "4130");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}

		catch (Exception e) {
			System.out.println(e);
			throw ExceptionHandler.convertException(e);
		}

	}	
	
	@GraymoundService("BNSPR_TRN4130_SET_RECORDS")
	public static GMMap setRecords(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_RC_ADC.RC_QRY4130_Kanal_Bloke2(?,?,?,?,?,?) }");
			stmt.setString(1,  iMap.getString("KANAL_KOD"));
			stmt.setString(2,  iMap.getString("BLOKE_NEDEN_KOD"));
			stmt.setString(3,  iMap.getString("BLOKE_ALT_NEDEN_KOD"));
			stmt.setString(4,  iMap.getString("KANAL_PARAMETRE_ID"));
			stmt.registerOutParameter(5, -10);
			stmt.registerOutParameter(6, -10);
			stmt.execute();
			String tableName1 = "BLOKE_KOYACAK_ROL_TUR_KODLARI";
			String tableName2 = "BLOKE_KALDIRACAK_ROL_TUR_KODLARI";
			rSet = (ResultSet)stmt.getObject(5);
			oMap = DALUtil.rSetMap(rSet);
			rSet = (ResultSet)stmt.getObject(6);
			oMap.put("BLOKE_ALT_NEDEN_KOD", iMap.getString("BLOKE_ALT_NEDEN_KOD"));
			oMap.put("DI_BLOKE_ALT_NEDEN",LovHelper.diLov(iMap.getString("BLOKE_ALT_NEDEN_KOD"),iMap.getString("BLOKE_NEDEN_KOD"), "4130/LOV_BLOKE_ALTNEDEN", "ACIKLAMA"));

			int row1 = 0;
			int row2 = 0;
			while (rSet.next()){
			if (rSet.getString("BLOKE_ISLEM_TURU").equals("KO")){
				oMap.put(tableName1, row1,"ROL_NUMARA",rSet.getString("ROL_NUMARA"));
				oMap.put(tableName1, row1, "ROL", LovHelper.diLovF(rSet.getBigDecimal("ROL_NUMARA"), "4130/LOV_ROL_NUMARA", "TANIM","NUMARA"));
				oMap.put(tableName1, row1, "G_D_S","D");
				oMap.put(tableName1, row1, "BLOKE_ISLEM_TURU",rSet.getString("BLOKE_ISLEM_TURU"));
				oMap.put(tableName1, row1, "SIL", false);
				row1 ++;
			}
			else if (rSet.getString("BLOKE_ISLEM_TURU").equals("KA")){
				oMap.put(tableName2, row2,"ROL_NUMARA",rSet.getString("ROL_NUMARA"));
				oMap.put(tableName2, row2, "ROL", LovHelper.diLovF(rSet.getBigDecimal("ROL_NUMARA"), "4130/LOV_ROL_NUMARA", "TANIM","NUMARA"));
				oMap.put(tableName2, row2, "BLOKE_ISLEM_TURU",rSet.getString("BLOKE_ISLEM_TURU"));
				oMap.put(tableName2, row2, "G_D_S","D");
				oMap.put(tableName2, row2, "SIL", false);
				row2 ++;
			}
			
		}
			   
		return oMap;
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
	
		}
		
	}			
	    
	@GraymoundService("BNSPR_TRN4130_GET_KANAL_BLOKE")
	public static GMMap getRecords(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_ADC.RC_QRY4130_Kanal_Bloke(?,?,?) }");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("KANAL_KOD"));
			stmt.setString(i++,  iMap.getString("BLOKE_NEDEN_KOD"));
			stmt.setString(i++,  iMap.getString("DURUM_KODU"));
	
			stmt.execute();
			String tableName = "KANAL_BLOKE_PARAMETRE";
			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, tableName);
			
			
			for (int row = 0; row < oMap.getSize(tableName); row++) {
				String kanalKodu =  oMap.getString(tableName, row, "KANAL_KOD");
				String blokeNedenKodu =  oMap.getString(tableName, row, "BLOKE_NEDEN_KOD");
				String blokeAltNedenKodu = oMap.getString(tableName, row, "BLOKE_ALT_NEDEN_KOD");
				oMap.put(tableName, row, "KANAL_ACIKLAMA", LovHelper.diLov(kanalKodu, "4130/LOV_KANAL", "ACIKLAMA"));
				oMap.put(tableName, row, "BLOKE_NEDEN", LovHelper.diLov(blokeNedenKodu, "4130/LOV_BLOKE_NEDEN", "ACIKLAMA"));
				oMap.put(tableName, row, "BLOKE_ALTNEDEN", LovHelper.diLov(blokeAltNedenKodu,blokeNedenKodu, "4130/LOV_BLOKE_ALTNEDEN", "ACIKLAMA"));
			}
			
			
			
		return oMap;
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}			
	         
	@GraymoundService("BNSPR_TRN4130_W1_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			GuimlUtil.wrapMyCombo(oMap, "DURUM_KODU", 0, "A", "Aktif");
			GuimlUtil.wrapMyCombo(oMap, "DURUM_KODU", 1, "P", "Pasif");
		
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN4130_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
	
				Session session = DAOSession.getSession("BNSPRDal");

				GMMap oMap = new GMMap();
				
				List<?> list = (List<?>) session.createCriteria(AdkKanalParametreTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
				
				AdkKanalParametreTx adkKanalParametreTx = (AdkKanalParametreTx) list.get(0);
				
				oMap.put("TRX_NO", adkKanalParametreTx.getTxNo());
				oMap.put("KANAL_KOD", adkKanalParametreTx.getKanalKod());
				oMap.put("DI_KANAL_KOD", LovHelper.diLov(adkKanalParametreTx.getKanalKod(), "4130/LOV_KANAL", "ACIKLAMA")); 
				oMap.put("BLOKE_NEDEN_KOD", adkKanalParametreTx.getBlokeNedenKod());
				oMap.put("DI_BLOKE_NEDENI", LovHelper.diLov(adkKanalParametreTx.getBlokeNedenKod(), "4130/LOV_BLOKE_NEDEN", "ACIKLAMA")); 
				oMap.put("BLOKE_ALT_NEDEN_KOD", adkKanalParametreTx.getBlokeAltNedenKod());
				oMap.put("DI_BLOKE_ALT_NEDEN", LovHelper.diLov(adkKanalParametreTx.getBlokeAltNedenKod(),adkKanalParametreTx.getBlokeNedenKod(), "4130/LOV_BLOKE_ALTNEDEN", "ACIKLAMA")); 
				oMap.put("ACIKLAMA", adkKanalParametreTx.getAciklama());
				oMap.put("BLOKE_KOYMA_YONTEMI", adkKanalParametreTx.getBlokeKoymaYontemi());
				oMap.put("BLOKE_KALDIRMA_YONTEMI", adkKanalParametreTx.getBlokeKaldirmaYontemi());
				oMap.put("BASLANGIC_TARIHI_EH", adkKanalParametreTx.getBaslangicTarihiEh());
				oMap.put("BITIS_TARIHI_EH", adkKanalParametreTx.getBitisTarihiEh());
				oMap.put("MAIL_GONDERME_EH", adkKanalParametreTx.getMailGondermeEh());
				oMap.put("MAIL_ADRESLERI", adkKanalParametreTx.getMailAdresleri());
				oMap.put("DURUM_KODU", adkKanalParametreTx.getDurumKodu());
				oMap.put("KANAL_PARAMETRE_ID", adkKanalParametreTx.getKanalParametreId());
				String tableName1 = "BLOKE_KOYACAK_ROL_TUR_KODLARI";
    			String tableName2 = "BLOKE_KALDIRACAK_ROL_TUR_KODLARI";
				
			
                List<?> list2 = (List<?>) session.createCriteria(AdkKanalBlokeRolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

            	int row1 = 0;
            	int row2 = 0;
            	for (Iterator<?> iterator = list2.iterator(); iterator.hasNext();) {
            		AdkKanalBlokeRolTx adkKanalBlokeRolTx = (AdkKanalBlokeRolTx) iterator.next();
					if (adkKanalBlokeRolTx.getId().getBlokeIslemTuru().equals("KO")){
						oMap.put(tableName1, row1,"ROL_NUMARA", adkKanalBlokeRolTx.getId().getRolNumara());
						oMap.put(tableName1, row1,"ROL",LovHelper.diLov(adkKanalBlokeRolTx.getId().getRolNumara(), "4130/LOV_ROL_NUMARA", "TANIM"));
						oMap.put(tableName1, row1,"BLOKE_ISLEM_TURU",adkKanalBlokeRolTx.getId().getBlokeIslemTuru());
						oMap.put(tableName1, row1,"KANAL_KOD",adkKanalBlokeRolTx.getKanalKod());
						oMap.put(tableName1, row1,"BLOKE_NEDEN_KOD",adkKanalBlokeRolTx.getBlokeNedenKod());
						oMap.put(tableName1, row1,"BLOKE_ALT_NEDEN_KOD",adkKanalBlokeRolTx.getBlokeAltNedenKod());
						oMap.put(tableName1, row1,"SIL", "S".equals(adkKanalBlokeRolTx.getGDS()));
						oMap.put(tableName1, row1,"G_D_S",adkKanalBlokeRolTx.getGDS());
						row1++;
	            	}
					else if(adkKanalBlokeRolTx.getId().getBlokeIslemTuru().equals("KA")){
						oMap.put(tableName2, row2,"ROL_NUMARA", adkKanalBlokeRolTx.getId().getRolNumara());
	    				oMap.put(tableName2, row2,"ROL",LovHelper.diLov(adkKanalBlokeRolTx.getId().getRolNumara(), "4130/LOV_ROL_NUMARA", "TANIM")); 
	    				oMap.put(tableName2, row2,"BLOKE_ISLEM_TURU",adkKanalBlokeRolTx.getId().getBlokeIslemTuru());
	    				oMap.put(tableName2, row2,"KANAL_KOD",adkKanalBlokeRolTx.getKanalKod());
	    				oMap.put(tableName2, row2,"BLOKE_NEDEN_KOD",adkKanalBlokeRolTx.getBlokeNedenKod());
	    				oMap.put(tableName2, row2,"BLOKE_ALT_NEDEN_KOD",adkKanalBlokeRolTx.getBlokeAltNedenKod());
	    				oMap.put(tableName2, row2,"SIL", "S".equals(adkKanalBlokeRolTx.getGDS()));
	    				oMap.put(tableName2, row2,"G_D_S",adkKanalBlokeRolTx.getGDS());
	    				row2++;
	                	}
				}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	



}

