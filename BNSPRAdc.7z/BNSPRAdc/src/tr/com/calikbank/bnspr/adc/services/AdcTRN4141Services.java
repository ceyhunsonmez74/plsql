package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkBannerTx;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AdcTRN4141Services {
	
	@GraymoundService("BNSPR_TRN4141_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues2(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			iMap.put("KOD", "ADK_BANNER_TYPE");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("BANNER_TYPE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "ADK_DESTINATION_TYPE");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("DESTINATION_TYPE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			DALUtil.fillComboBox(oMap, "KANAL_KOD", true, "SELECT INTEGRATION_ID ,ACIKLAMA FROM V_ML_GNL_KANAL_GRUP_KOD_PR WHERE KOD IN (4,10,2) ORDER BY TO_NUMBER(KOD)"); 
			
			oMap.put("LANGUAGE_LIST", GMServiceExecuter.execute("ADC_CORE_LANGUAGE_LIST", iMap).get("LIST"));			
          
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
    @GraymoundService("BNSPR_TRN4141_BANNER_LIST")
    public static GMMap BannerList(GMMap iMap) {
    	GMMap oMap = new GMMap();
    	try {
   		GMMap myMap = new GMMap(GMServiceExecuter.execute("ADC_MAN_BANNER_LIST", iMap));
		
		for(int i = 0;i < myMap.getSize("LIST");i++) {
			
                oMap.put("T_BANNER",i,"BANNER_KEY",myMap.get("LIST",i,"BANNER_KEY"));
                oMap.put("T_BANNER",i,"BANNER_PAGE",LovHelper.diLov(myMap.get("LIST",i,"BANNER_KEY"), "4141/LOV_BANNER_TYPE", "BANNER_PAGE"));
                oMap.put("T_BANNER",i,"BANNER_TYPE",myMap.get("LIST",i,"BANNER_TYPE"));
                oMap.put("T_BANNER",i,"PRIORITY",myMap.get("LIST",i,"PRIORITY"));
                oMap.put("T_BANNER",i,"DESTINATION_TYPE",myMap.get("LIST",i,"DESTINATION_TYPE"));
                oMap.put("T_BANNER",i,"DESTINATION_URL",myMap.get("LIST",i,"DESTINATION_URL"));
                oMap.put("T_BANNER",i,"TITLE",myMap.get("LIST",i,"TITLE"));
                oMap.put("T_BANNER",i,"END_DATE",myMap.get("LIST",i,"END_DATE"));
                oMap.put("T_BANNER",i,"START_DATE",myMap.get("LIST",i,"START_DATE"));
                oMap.put("T_BANNER",i,"G_D_S",myMap.get("LIST",i,"G_D_S"));
                oMap.put("T_BANNER",i,"INT_ID",myMap.get("LIST",i,"INT_ID"));
                oMap.put("T_BANNER",i,"KANAL_KOD",myMap.get("LIST",i,"CHANNEL_CODE"));
                oMap.put("T_BANNER",i,"SOURCE_URL",myMap.get("LIST",i,"SOURCE_URL"));
                oMap.put("T_BANNER",i,"LANGUAGE",myMap.get("LIST",i,"LANGUAGE"));
            }
        return oMap;
	    }
		 catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}  
    }
	
   @GraymoundService("BNSPR_TRN4141_SAVE")
	public static GMMap saveTRN4141(GMMap iMap){
	try {
			Session session = DAOSession.getSession("BNSPRDal");
		 	AdkBannerTx adkBannerTx = new AdkBannerTx();
		 	String startDate=iMap.getString("START_DATE");
		 	String endDate=iMap.getString("END_DATE");
            String bannerKey = iMap.getString("BANNER_KEY");
            String priority  = iMap.getString("PRIORITY");
            String GDS = iMap.getString("G_D_S");
			String kanalKod= iMap.getString("KANAL_KOD");
			if(("G".compareTo(GDS)==0)||("D".compareTo(GDS)==0))
			{
			if(bannerKey == null || bannerKey.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Banner Key");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(priority == null || priority.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "�ncelik");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(kanalKod==null|| kanalKod.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kanal Kod");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(startDate==null||startDate.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Ba�lang�� Tarihi");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(endDate==null || endDate.isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Biti� Tarihi");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				
			}
			if(startDate.compareTo(endDate)>0)
			{
				iMap.put("HATA_NO", new BigDecimal(1601));
				iMap.put("P1", startDate);
				iMap.put("P2",endDate);
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			}
			adkBannerTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			adkBannerTx.setBannerKey(bannerKey);
			adkBannerTx.setBannerType(iMap.getBigDecimal("BANNER_TYPE"));
			adkBannerTx.setDestinationType(iMap.getBigDecimal("DESTINATION_TYPE"));
			adkBannerTx.setDestinationUrl(iMap.getString("DESTINATION_URL"));
			adkBannerTx.setTitle(iMap.getString("TITLE"));
			adkBannerTx.setEndDate(iMap.getDate("END_DATE"));
			adkBannerTx.setStartDate(iMap.getDate("START_DATE"));
			adkBannerTx.setGDS(iMap.getString("G_D_S").toCharArray()[0]);
			adkBannerTx.setIntId(iMap.getBigDecimal("INT_ID"));
			adkBannerTx.setKanalKod(AdcGeneralServices.getKanalKod(iMap.getString("KANAL_KOD")));
			adkBannerTx.setPriority(iMap.getBigDecimal("PRIORITY"));
			adkBannerTx.setSourceUrl(iMap.getString("SOURCE_URL"));
			adkBannerTx.setLanguageCode(iMap.getString("LANGUAGE"));
			
			session.saveOrUpdate(adkBannerTx);
			session.flush();

			iMap.put("TRX_NAME", "4141");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			System.out.println(e);
			throw ExceptionHandler.convertException(e);
		}
	}	

	private static String getIntegrationId(String kanalKod) {
	    Session session = DAOSession.getSession("BNSPRDal");
		GnlKanalGrupKodPr gnlKanalGrupKodPr = (GnlKanalGrupKodPr) session.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("kod", kanalKod)).uniqueResult();
		return gnlKanalGrupKodPr.getIntegrationId();
	}
   
	@GraymoundService("BNSPR_TRN4141_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
  	   try{
			Session session = DAOSession.getSession("BNSPRDal");
			AdkBannerTx adkBannerTx = (AdkBannerTx) session.createCriteria(AdkBannerTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			GMMap serviceMap = new GMMap();
				serviceMap.put("BANNER_PAGE_KEY", adkBannerTx.getBannerKey());
				serviceMap.put("BANNER_KEY", adkBannerTx.getBannerKey());
				serviceMap.put("BANNER_TYPE", adkBannerTx.getBannerType());
				serviceMap.put("INT_ID",adkBannerTx.getIntId());
			    serviceMap.put("DESTINATION_TYPE",adkBannerTx.getDestinationType());
			    serviceMap.put("DESTINATION_URL",adkBannerTx.getDestinationUrl());
			    serviceMap.put("TITLE",adkBannerTx.getTitle());
			    serviceMap.put("END_DATE",adkBannerTx.getEndDate());
			    serviceMap.put("PRIORITY",adkBannerTx.getPriority());
			    serviceMap.put("SOURCE_URL",adkBannerTx.getSourceUrl());
			    serviceMap.put("START_DATE",adkBannerTx.getStartDate());
			    serviceMap.put("LANGUAGE",adkBannerTx.getLanguageCode()); 
			    serviceMap.put("CHANNEL_CODE",getIntegrationId(adkBannerTx.getKanalKod())); 
			    if ("G".equals(adkBannerTx.getGDS().toString())){
				GMServiceExecuter.execute("ADC_MAN_BANNER_CREATE",serviceMap);
				}else if("D".equals(adkBannerTx.getGDS().toString())){
			    GMServiceExecuter.execute("ADC_MAN_BANNER_UPDATE_WITH_INTID",serviceMap);
				}else if("S".equals(adkBannerTx.getGDS().toString())){
				GMServiceExecuter.execute("ADC_MAN_BANNER_DELETE",serviceMap);
				}
	   
	     return new GMMap();
	     }
		 catch (Exception e) {

			 throw ExceptionHandler.convertException(e);
		}
  	}
	
  	@GraymoundService("BNSPR_TRN4141_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = (List<?>) session.createCriteria(AdkBannerTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				AdkBannerTx adkBannerTx = (AdkBannerTx) iterator.next();
				oMap.put("BANNER_KEY", adkBannerTx.getBannerKey());
				oMap.put("BANNER_TYPE", adkBannerTx.getBannerType());
				oMap.put("G_D_S", adkBannerTx.getGDS());
				oMap.put("TRX_NO", adkBannerTx.getTxNo());
				oMap.put("INT_ID",adkBannerTx.getIntId());
				oMap.put("DESTINATION_TYPE",adkBannerTx.getDestinationType());
				oMap.put("DESTINATION_URL",adkBannerTx.getDestinationUrl());
				oMap.put("TITLE",adkBannerTx.getTitle());
				oMap.put("END_DATE",adkBannerTx.getEndDate());
				oMap.put("PRIORITY",adkBannerTx.getPriority());
				oMap.put("SOURCE_URL",adkBannerTx.getSourceUrl());
				oMap.put("START_DATE",adkBannerTx.getStartDate());
				oMap.put("CHANNEL_CODE",getIntegrationId(adkBannerTx.getKanalKod())); 
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
}
