package tr.com.calikbank.bnspr.adc.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.AdkStandCalisan;
import tr.com.calikbank.bnspr.dao.AdkStandCalisanTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4103Services {
	
	@GraymoundService("BNSPR_TRN4103_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
			try{
				GMMap oMap = new GMMap();
				iMap.put("KOD", "STAND_CAL_POZISYON_KOD");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("POZISYON_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

				iMap.put("KOD", "TUTTUGU_TAKIM_KOD");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("TUTTUGU_TAKIM_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
				iMap.put("KOD", "CAL_STATU_KOD");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("CAL_STATU_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
				iMap.put("KOD", "KAPANMA_NEDEN_KOD");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("KAPANMA_NEDENI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
				iMap.put("KOD", "CAL_KISMI_KAPANMA_NEDEN_KOD");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("CAL_KISMI_KAPANMA_NEDEN_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				
				iMap.put("KOD", "YETKI_SEVIYE_KOD");
				iMap.put("ADD_EMPTY_KEY", "E");
				oMap.put("YETKI_SEVIYE_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
				return oMap;
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
	
	@GraymoundService("BNSPR_TRN4103_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_rc_adc.RC_QRY4103_GET_LIST(?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++,iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++,iMap.getString("KULLANICI_KODU"));
					
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "STAND_CALISAN");
		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN4103_GET_STAND_CALISAN_INFO")
	public static GMMap getStandCalisanInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			AdkStandCalisan adkStandCalisan = (AdkStandCalisan) session.get(AdkStandCalisan.class, iMap.getString("KOD"));

			oMap.put("MUSTERI_NO", adkStandCalisan.getMusteriNo());
			oMap.put("HESAP_NO", adkStandCalisan.getHesapNo());
			oMap.put("KULLANICI_KODU", adkStandCalisan.getKod());
			oMap.put("ISE_BASLAMA_TAR", adkStandCalisan.getIseBaslamaTar());
			oMap.put("POZISYON_KOD", adkStandCalisan.getPozisyonKod());
			oMap.put("TUTTUGU_TAKIM_KOD", adkStandCalisan.getTuttuguTakimKod());
			oMap.put("CAL_STATU_KOD", adkStandCalisan.getCalStatuKod());
			oMap.put("KAPANMA_NEDENI", adkStandCalisan.getCalKapanmaNedenKod());
			oMap.put("CAL_KISMI_KAPANMA_NEDEN_KOD", adkStandCalisan.getCalKismiKapanmaNedenKod());
			iMap.putAll(AdcTRN4102Services.getHobiler(iMap));
			AdcTRN4102Services.parseHobiler(iMap, "SECILEN_HOBILER", adkStandCalisan.getHobiler());
			oMap.putAll(getHobilerforUpdate(iMap));
			oMap.put("YETKI_SEVIYE_KOD", adkStandCalisan.getYetkiSeviyeKod());
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	public static GMMap getHobilerforUpdate(GMMap iMap){
		try{
			List<?> hobilerList = (List<?>)iMap.get("HOBILER");
			List<?> secilenHobilerList = (List<?>)iMap.get("SECILEN_HOBILER");
			if (secilenHobilerList == null) return iMap;
			for (int i = 0; i<hobilerList.size();i++)
				for(int j = 0; j<secilenHobilerList.size();j++ )
					if(iMap.getString("SECILEN_HOBILER",j,"HOBI_KOD").equals(iMap.getString("HOBILER",i,"HOBI_KOD")))
						iMap.put("HOBILER", i,"SEC","1");
			return iMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	@GraymoundService("BNSPR_TRN4103_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			AdkStandCalisanTx adkStandCalisanTx = (AdkStandCalisanTx) session.get(AdkStandCalisanTx.class, iMap
					.getBigDecimal("TRX_NO"));
			if (adkStandCalisanTx == null)
				adkStandCalisanTx = new AdkStandCalisanTx();
			
			adkStandCalisanTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			adkStandCalisanTx.setKod(iMap.getString("KULLANICI_KODU"));
			adkStandCalisanTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			adkStandCalisanTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			adkStandCalisanTx.setIseBaslamaTar(iMap.getDate("ISE_BASLAMA_TAR"));
			adkStandCalisanTx.setPozisyonKod(iMap.getString("POZISYON_KOD"));
			adkStandCalisanTx.setTuttuguTakimKod(iMap.getString("TUTTUGU_TAKIM_KOD"));
			adkStandCalisanTx.setCalStatuKod(iMap.getString("CAL_STATU_KOD"));
			adkStandCalisanTx.setCalKapanmaNedenKod(iMap.getString("KAPANMA_NEDENI"));
			adkStandCalisanTx.setCalKismiKapanmaNedenKod(iMap.getString("CAL_KISMI_KAPANMA_NEDEN_KOD"));
			adkStandCalisanTx.setHobiler(AdcTRN4102Services.prepareHobiKod(iMap));
			adkStandCalisanTx.setYetkiSeviyeKod(iMap.getString("YETKI_SEVIYE_KOD"));
			session.saveOrUpdate(adkStandCalisanTx);
			session.flush();

			iMap.put("TRX_NAME", "4103");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (ConstraintViolationException e) {
			throw new GMRuntimeException(0,e.getCause().getMessage());
		} catch (Exception e) {
			 throw new GMRuntimeException(0,e);	
		}
	}

	@GraymoundService("BNSPR_TRN4103_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			AdkStandCalisanTx adkStandCalisanTx = (AdkStandCalisanTx) session.get(AdkStandCalisanTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("TRX_NO", adkStandCalisanTx.getTxNo());
			oMap.put("KULLANICI_KODU", adkStandCalisanTx.getKod());
			oMap.put("MUSTERI_NO", adkStandCalisanTx.getMusteriNo());
			oMap.put("HESAP_NO", adkStandCalisanTx.getHesapNo());
			oMap.put("ISE_BASLAMA_TAR", adkStandCalisanTx.getIseBaslamaTar());
			oMap.put("POZISYON_KOD", adkStandCalisanTx.getPozisyonKod());
			oMap.put("TUTTUGU_TAKIM_KOD", adkStandCalisanTx.getTuttuguTakimKod());
			iMap.putAll(AdcTRN4102Services.getHobiler(iMap));
			AdcTRN4102Services.parseHobiler(iMap, "SECILEN_HOBILER", adkStandCalisanTx.getHobiler());
			oMap.putAll(getHobilerforUpdate(iMap));
			oMap.put("CAL_STATU_KOD", adkStandCalisanTx.getCalStatuKod());
			oMap.put("KAPANMA_NEDENI", adkStandCalisanTx.getCalKapanmaNedenKod());
			oMap.put("CAL_KISMI_KAPANMA_NEDEN_KOD", adkStandCalisanTx.getCalKismiKapanmaNedenKod());
			oMap.put("YETKI_SEVIYE_KOD", adkStandCalisanTx.getYetkiSeviyeKod());
				
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
