package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Calendar;
import java.util.Map;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KibFirmaYetkiLimit;
import tr.com.calikbank.bnspr.dao.KibKullSifreTanimTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class AdcTRN4207Services {
	
	@GraymoundService("BNSPR_TRN4207_GET_KANAL_KOD")
	public static GMMap getKanalKod(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			
			conn = DALUtil.getGMConnection();
		
			stmt = conn.prepareCall("{? = call PKG_TRN4207.Get_Kanal_Kod(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR); //ref cursor			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("DF_SIFRE_ZARF_NO"));
			stmt.execute();
			
			oMap.put("DF_SIFRE_KANALI",stmt.getString(1));

		return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
	}
	
	@GraymoundService("BNSPR_TRN4207_SAVE")
	public static Map<?, ?> Save (GMMap iMap){
		return GMServiceExecuter.execute("BNSPR_TRN4207_SAVE_1", iMap);
		
	}
	
	@GraymoundService("BNSPR_TRN4207_SAVE_1")
	public static Map<?, ?> Save1 (GMMap iMap){
		try {
			boolean isSendPasswordSms = iMap.getBoolean("SEND_PASSWORD_SMS");
			String phoneNumber = getPhoneNumber(iMap.getBigDecimal("DF_FIRMA_NO"), iMap.getBigDecimal("DF_KULLANICI_KODU"));

			Session session = DAOSession.getSession("BNSPRDal");
			KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, iMap.getBigDecimal("TRX_NO"));
			if(kibKullSifreTanimTx == null) {
				kibKullSifreTanimTx = new KibKullSifreTanimTx();
			}
			
			kibKullSifreTanimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kibKullSifreTanimTx.setFirmaNo(iMap.getBigDecimal("DF_FIRMA_NO"));
			kibKullSifreTanimTx.setKullNo(iMap.getBigDecimal("DF_KULLANICI_KODU"));
			if (("�NTERNET").equals(iMap.getString("DF_SIFRE_KANALI"))) {
				kibKullSifreTanimTx.setKanalKod("1");
			}else if (("�A�RI MERKEZ�").equals(iMap.getString("DF_SIFRE_KANALI"))) {
				kibKullSifreTanimTx.setKanalKod("2");
			}else {
				kibKullSifreTanimTx.setKanalKod("3");
			}
			kibKullSifreTanimTx.setSifreZarfNo(iMap.getBigDecimal("DF_SIFRE_ZARF_NO"));
			kibKullSifreTanimTx.setTeslimTarihi(iMap.getDate("DF_TESLIM_TARIHI"));
			kibKullSifreTanimTx.setGonderimTipi(isSendPasswordSms ? "S" : "Z");
			kibKullSifreTanimTx.setSifre("");
			kibKullSifreTanimTx.setTelefon(phoneNumber);
            
            if (isSendPasswordSms
                    && ((phoneNumber == null)
                            || phoneNumber.isEmpty())) {
                throw new GMRuntimeException(0, "Kullan�c�n�n telefon numaras� tan�ml� de�il");
            }

			if (isSendPasswordSms) {
			    String password = createPassword();
			    
			    kibKullSifreTanimTx.setSifre(password);
	            kibKullSifreTanimTx.setTeslimTarihi(Calendar.getInstance().getTime());
	            kibKullSifreTanimTx.setSifreZarfNo(BigDecimal.ZERO);
			}
			
		    kibKullSifreTanimTx.setOnaysizIslem(iMap.getBoolean("ONAYSIZ_ISLEM") ? "E" : "H");
			
			session.saveOrUpdate(kibKullSifreTanimTx);
			session.flush();
			
			iMap.put("TRX_NAME", "4207");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	public static String createPassword() {
        String password = (new BigDecimal(100000).add(new BigDecimal(new Random().nextInt(900000)))).toString();
        
        return password;
	}
	
	public static String encryptPassword(String password) {
	    JGMPasswordField passwordField = new JGMPasswordField();
	    
	    passwordField.setText(password);
	    String encryptedPassword = new String(passwordField.getPasswordWithAlgorithm("SHA-1"));
	    
	    return encryptedPassword;
	}

	@GraymoundService("BNSPR_TRN4207_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, txNo);
			
			oMap.put("TRX_NO", kibKullSifreTanimTx.getTxNo());
			oMap.put("DF_FIRMA_NO", kibKullSifreTanimTx.getFirmaNo());
			oMap.put("DF_SIFRE_KANALI", kibKullSifreTanimTx.getKanalKod());
			if (("1").equals(kibKullSifreTanimTx.getKanalKod())) {
				oMap.put("DF_SIFRE_KANALI", "�NTERNET");
			}else if (("2").equals(kibKullSifreTanimTx.getKanalKod())) {
				oMap.put("DF_SIFRE_KANALI", "�A�RI MERKEZ�");
			}else {
				oMap.put("DF_SIFRE_KANALI", "�NTERNET-�A�RI MERKEZ�");
			}
			oMap.put("DF_KULLANICI_NO", kibKullSifreTanimTx.getKullNo());
			oMap.put("DF_SIFRE_ZARF_NO", kibKullSifreTanimTx.getSifreZarfNo());
			oMap.put("DF_TESLIM_TARIHI", kibKullSifreTanimTx.getTeslimTarihi());
						
			return oMap;
		} catch (Exception e) {
				throw new GMRuntimeException(0, e);
		} finally {
				
		}
	}
	
	@GraymoundService("BNSPR_TRN4207_SEND_SMS")
	public static GMMap parolaPassword(GMMap iMap){
        BigDecimal txNo = iMap.getBigDecimal("ISLEM_NO");
        Session session = DAOSession.getSession("BNSPRDal");
        KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, txNo);

        boolean isSendPasswordSms = kibKullSifreTanimTx.getGonderimTipi().equals("S");
        boolean isBlocked = iMap.getBoolean("BLOCKED_USER");
        
        int messageCode = 1436;
        String param = kibKullSifreTanimTx.getKullNo().toString();
        
        if (isSendPasswordSms) {
            messageCode = 4968;
            param = kibKullSifreTanimTx.getSifre();
        }

        if (!isSendPasswordSms || !isBlocked) {
    		String message = createMessage(messageCode, param, kibKullSifreTanimTx.getKullNo());
    
    		sendSms(kibKullSifreTanimTx.getTelefon(), message);
        }		
		
        return iMap;
	}

    public static String createMessage(int messageCode, String p1, BigDecimal customerNo) {
        GMMap msgMap = new GMMap();
		msgMap.put("P1", p1);
		msgMap.put("P2", customerNo);
		msgMap.put("MESSAGE_NO", messageCode);
        GnlMusteri customer = getCustomerByCustomerNo(customerNo);
        msgMap.put("DIL_KOD", customer.getIletisimDili());
		return GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE_DILKOD", msgMap).getString("ERROR_MESSAGE");
    }

	private static GnlMusteri getCustomerByCustomerNo(BigDecimal customerNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		return (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", customerNo)).uniqueResult();
	}

	public static String getPhoneNumber(BigDecimal firmCode, BigDecimal userCode){
	    GMMap iMap = new GMMap();
	    iMap.put("FIRMA_KODU", firmCode);
	    iMap.put("KULLANICI_KODU", userCode);

	    String phoneNumber = GMServiceExecuter.call("BNSPR_TRN4202_GET_TRANSFER_DATA", iMap).getString("CEP_TELEFONU");
	    
	    return phoneNumber;
	}
	
	public static void sendSms(String phoneNumber, String message) {
        GMMap smsMap = new GMMap();
        
        smsMap.put("CONTENT", message);
        smsMap.put("MSISDN", phoneNumber);
        
        GMServiceExecuter.call("BNSPR_SMS_SEND_SMS", smsMap);
    }
	
	@GraymoundService("BNSPR_TRN4207_CREATE_USER")
	public static GMMap createAdk(GMMap iMap){
		
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN4207.ADK_user_create_check(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");

			stmt.registerOutParameter	(1, Types.NUMERIC);
			stmt.setBigDecimal			(2, iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter	(3, Types.VARCHAR);
			stmt.registerOutParameter	(4, Types.NUMERIC);
			stmt.registerOutParameter	(5, Types.VARCHAR);
			stmt.registerOutParameter	(6, Types.VARCHAR);
			stmt.registerOutParameter	(7, Types.VARCHAR);
			stmt.registerOutParameter	(8, Types.VARCHAR);
			stmt.registerOutParameter	(9, Types.VARCHAR);
			stmt.registerOutParameter	(10, Types.VARCHAR);
			stmt.registerOutParameter	(11, Types.VARCHAR);
			stmt.registerOutParameter	(12, Types.VARCHAR);
			stmt.registerOutParameter	(13, Types.NUMERIC);
			stmt.registerOutParameter	(14, Types.VARCHAR);
			stmt.registerOutParameter	(15, Types.VARCHAR);
			stmt.registerOutParameter	(16, Types.VARCHAR);
			stmt.registerOutParameter	(17, Types.VARCHAR);
			
			stmt.execute();
			int row = 0;
			JGMPasswordField passwordField = new JGMPasswordField();
			iMap.put("USERNAME"		, stmt.getBigDecimal(13)); //firma_kodu
	        
			iMap.put("MUSTERI_NO", stmt.getBigDecimal(4));
			
//			iMap.put("INTEGRATION"	, 0, "KEY"	, "MUSTERI_NO");
//			iMap.put("INTEGRATION"	, 0, "VALUE", stmt.getBigDecimal(4)); //firma kodu

			iMap.put("INTEGRATION"	, row, "KEY"	, "PHONE_NUMBER");
			iMap.put("INTEGRATION"	, row++, "VALUE", stmt.getString(6));
			
			iMap.put("INTEGRATION"	, row, "KEY"	, "MUSTERI_GRUP");
			iMap.put("INTEGRATION"	, row++, "VALUE", stmt.getString(7));
			
			iMap.put("INTEGRATION"	, row, "KEY"	, "SEGMENT");
			iMap.put("INTEGRATION"	, row++, "VALUE", stmt.getString(8));
			
			iMap.put("INTEGRATION"	, row, "KEY"	, "DOGUM_YILI");
			iMap.put("INTEGRATION"	, row++, "VALUE", stmt.getString(10));
	        
			iMap.put("INTEGRATION"	, row, "KEY"	, "DOGUM_AYI");
			iMap.put("INTEGRATION"	, row++, "VALUE", stmt.getString(11));
			
			iMap.put("INTEGRATION"	, row, "KEY"	, "DOGUM_GUNU");
			iMap.put("INTEGRATION"	, row++, "VALUE", stmt.getString(12));
			
			iMap.put("INTEGRATION"	, row, "KEY"	, "NO_OTP_ACTION");
			iMap.put("INTEGRATION"	, row++, "VALUE", "2");
			
			iMap.put("COMPANY_USER_CODE", stmt.getString(13));
			
//			iMap.put("INTEGRATION"	, 8, "KEY"	, "COMPANY_USER_CODE");
//			iMap.put("INTEGRATION"	, 8, "VALUE", stmt.getString(13));
			
			if ( ("1").equals(stmt.getString(15)) && ("1").equals(stmt.getString(16) == "1")){
				
				    iMap.put("CHANNELS"	, 0, "CODE"		, "CINT");
				    iMap.put("ROLES" , 0, "CODE" , "KK"); 
				  
				    iMap.put("CHANNELS"	, 1, "CODE"		, "CC");
				    iMap.put("ROLES" , 1, "CODE" , "KK"); 
				    
			}else if (("1").equals(stmt.getString(15))){
				
				 iMap.put("CHANNELS"	, 0, "CODE"		, "CINT");
				 iMap.put("ROLES" , 0, "CODE" , "KK"); 
				  
			}else if (("1").equals(stmt.getString(16))){
				
				 iMap.put("CHANNELS"	, 0, "CODE"		, "CC");
				 iMap.put("ROLES" , 0, "CODE" , "KK"); 
			}
			
		    passwordField.setText(stmt.getString(5));
		    iMap.put("CHANNELS"	, 0, "PAROLE"	, new String(passwordField.getPasswordWithAlgorithm("SHA-1")));
		    
		    boolean isSmsPassword = stmt.getString(17).equals("S");
		    String password = stmt.getString(14);
		    
		    if (isSmsPassword) {
		        password = encryptPassword(password);
		    }
		    
	        iMap.put("CHANNELS"	, 0, "PASSWORD"	, password);
	        iMap.put("PASSWORD"	, password);
		       
		   // GMServiceExecuter.call("ADK_CREATE_USER" , iMap);
		    GMServiceExecuter.call("ADC_CORE_USER_CREATE" , iMap);
			
			return iMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	

	@GraymoundService("BNSPR_TRN4207_GET_KULLANICI_BLOKE_DURUMU")
	public static GMMap getKullaniciBlokeDurumu(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{			
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");
			KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, iMap.getBigDecimal("ISLEM_NO"));

			stmt = conn.prepareCall("{? = call PKG_RC4207.kib_kullanici_bloke_durumu(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.INTEGER); //ref cursor			
			stmt.setBigDecimal(i++, kibKullSifreTanimTx.getFirmaNo());
			stmt.setBigDecimal(i++, kibKullSifreTanimTx.getKullNo());

			stmt.execute();
			
			boolean isBlocked = ("2").equals(stmt.getString(1));
			if(isBlocked){
				/*GMMap map = new GMMap();
				map.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
				map.put("BLOKE_NEDENI", "13");
				map.put("MUSTERI_NO", kibKullSifreTanimTx.getFirmaNo());
				map.put("KULLANICI_KOD", kibKullSifreTanimTx.getKullNo());
			/*	String tableName = "KANAL_LIST";
				map.put(tableName, 0, "SEC", true);
				map.put(tableName, 0, "KANAL_KOD", "10");//Kurumsal �nternet Bankac�l���
			    iMap.put("MESSAGE_NO", new BigDecimal(1497));
			    map.put("BLOKE_KOYMA_ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).getString("ERROR_MESSAGE") );
				GMServiceExecuter.call("BNSPR_TRN4131_SAVE_BLOKE_KOYMA",map);*/
				stmt = conn.prepareCall("{call PKG_RC4207.kib_kullanici_bloke_koyma(?,?,?)}");
				int j = 1;
				stmt.setBigDecimal(j++, iMap.getBigDecimal("ISLEM_NO"));
				stmt.setString(j++, kibKullSifreTanimTx.getFirmaNo().toString());
				stmt.setString(j++, kibKullSifreTanimTx.getKullNo().toString());
				stmt.execute();
				session.flush();
				iMap.put("ISLEM_KODU", new java.math.BigDecimal("4131"));
				GMServiceExecuter.execute("BNSPR_TRN4131_AFTER_APPROVAL", iMap);
			}
			
			iMap.put("BLOCKED_USER", isBlocked);

			return iMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN4207_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) { 
		Session session = DAOSession.getSession("BNSPRDal");
		KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, iMap.getBigDecimal("ISLEM_NO"));
		
		if (kibKullSifreTanimTx.getTeslimTarihi() != null )
		{
			//GMServiceExecuter.execute("BNSPR_TRN4207_CREATE_USER", iMap); 4202 'den cagriliyor..
			GMServiceExecuter.call("BNSPR_TRN4208_PAROLA_PASSWORD", iMap);  
			GMServiceExecuter.call("BNSPR_TRN4207_GET_KULLANICI_BLOKE_DURUMU", iMap);			
			GMServiceExecuter.call("BNSPR_TRN4207_SEND_SMS", iMap);
			GMServiceExecuter.call("BNSPR_TRN4207_UPDATE_PASS_IN_TABLE", iMap);
		}
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN4207_GET_KANAL")
	public static GMMap getKanal(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			KibFirmaYetkiLimit kibFirmaYetkiLimit = (KibFirmaYetkiLimit)session.createCriteria(KibFirmaYetkiLimit.class)
			.add(Restrictions.eq("firmaNo", iMap.getBigDecimal("FIRMA_NO")))
			.uniqueResult();	

			oMap.put("INTERNETBANKACILIGI"  , 0);
			oMap.put("CAGRIMERKEZI"			, 0);
			
			if(iMap.getBigDecimal("FIRMA_NO") != null) {
				oMap.put("INTERNETBANKACILIGI"  , kibFirmaYetkiLimit.getInternetBankacigi());
				oMap.put("CAGRIMERKEZI"			, kibFirmaYetkiLimit.getCagriMerkezi());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN4207_UPDATE_PASS_IN_TABLE")
	public static GMMap updatePAsswordFromTable(GMMap iMap){

		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			
			conn = DALUtil.getGMConnection();
        	stmt = conn.prepareCall("{call PKG_TRN4207.Update_kibsifrebasim_Password(?)}");

			stmt.setBigDecimal			(1, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			
			replaceTrxPassword(iMap);
			
			return iMap;
		    
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}	
	}
	
	public static GMMap replaceTrxPassword(GMMap iMap){
        Session session = DAOSession.getSession("BNSPRDal");
        KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, iMap.getBigDecimal("ISLEM_NO"));
        
        if (kibKullSifreTanimTx.getGonderimTipi().equals("S")) {
            kibKullSifreTanimTx.setSifre(iMap.getString("PASSWORD"));
            session.saveOrUpdate(kibKullSifreTanimTx);
            session.flush();
        }
        
        return iMap;
	}
	
	@GraymoundService("BNSPR_TRN4207_GET_SIFRE_ZARF_NO")
	public static GMMap getSifre(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC4207.kib_kullanici_sifre_zarf_no(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC); //ref cursor			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.setString(i++, iMap.getString("KANAL"));
			stmt.execute();
    		oMap.put("SIFRE_ZARF_NO", stmt.getObject(1));
		return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(1, e);
		} finally {
	    	GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
    
    @GraymoundService("BNSPR_TRN4207_GET_PHONE_NUMBER")
    public static GMMap getPhoneNumber(GMMap iMap){
        GMMap oMap = new GMMap();
        
        String phoneNumber = getPhoneNumber(iMap.getBigDecimal("DF_FIRMA_NO"), iMap.getBigDecimal("DF_KULLANICI_KODU"));
        oMap.put("PHONE_NUMBER", phoneNumber);
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN4207_GET_ROLE_ID")
    public static GMMap getRoleId(GMMap iMap){
        GMMap oMap = new GMMap();
        
        String roleId = (String) GMContext.getCurrentContext().getSession().get("ROLE_ID");
        oMap.put("ROLE_ID", roleId);
        
        return oMap;
    }
	
}