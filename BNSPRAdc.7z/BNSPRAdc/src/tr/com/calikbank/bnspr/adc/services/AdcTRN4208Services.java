package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KibFirmaYetkiLimit;
import tr.com.calikbank.bnspr.dao.KibKullSifreTanimTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class AdcTRN4208Services {
		
	@GraymoundService("BNSPR_TRN4208_SAVE")
	public static Map<?, ?> Save (GMMap iMap){
		try {
            boolean isSendPasswordSms = iMap.getBoolean("SEND_PASSWORD_SMS");
            String phoneNumber = AdcTRN4207Services.getPhoneNumber(
                    iMap.getBigDecimal("DF_FIRMA_NO"), iMap.getBigDecimal("DF_KULLANICI_KODU"));

            Session session = DAOSession.getSession("BNSPRDal");
			KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, iMap.getBigDecimal("TRX_NO"));
			if(kibKullSifreTanimTx == null) {
				kibKullSifreTanimTx = new KibKullSifreTanimTx();
			}
			
			kibKullSifreTanimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kibKullSifreTanimTx.setFirmaNo(iMap.getBigDecimal("DF_FIRMA_NO"));
			kibKullSifreTanimTx.setKullNo(iMap.getBigDecimal("DF_KULLANICI_KODU"));
			if (iMap.getString("DF_SIFRE_KANALI").equals("�NTERNET")) {
				kibKullSifreTanimTx.setKanalKod("1");
			}else if (iMap.getString("DF_SIFRE_KANALI").equals("�A�RI MERKEZ�")) {
				kibKullSifreTanimTx.setKanalKod("2");
			}else {
				kibKullSifreTanimTx.setKanalKod("3");
			}
			kibKullSifreTanimTx.setSifreZarfNo(iMap.getBigDecimal("DF_SIFRE_ZARF_NO"));
			kibKullSifreTanimTx.setTeslimTarihi(iMap.getDate("DF_TESLIM_TARIHI"));
            kibKullSifreTanimTx.setGonderimTipi(isSendPasswordSms ? "S" : "Z");
            kibKullSifreTanimTx.setSifre("");
            kibKullSifreTanimTx.setTelefon(phoneNumber);
            
            if (isSendPasswordSms
                    && ((phoneNumber == null)
                            || phoneNumber.isEmpty())) {
                throw new GMRuntimeException(0, "Kullan�c�n�n telefon numaras� tan�ml� de�il");
            }

            if (isSendPasswordSms) {
                String password = AdcTRN4207Services.createPassword();
                
                kibKullSifreTanimTx.setSifre(password);
                kibKullSifreTanimTx.setTeslimTarihi(Calendar.getInstance().getTime());
                kibKullSifreTanimTx.setSifreZarfNo(BigDecimal.ZERO);
            }
            
            kibKullSifreTanimTx.setOnaysizIslem(iMap.getBoolean("ONAYSIZ_ISLEM") ? "E" : "H");

			session.saveOrUpdate(kibKullSifreTanimTx);
			session.flush();
			
			iMap.put("TRX_NAME", "4208");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN4208_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			Session session = DAOSession.getSession("BNSPRDal");
			KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, txNo);
			
			KibFirmaYetkiLimit kibFirmaYetkiLimit = (KibFirmaYetkiLimit)session.createCriteria(KibFirmaYetkiLimit.class).add( Restrictions.eq("firmaNo", kibKullSifreTanimTx.getFirmaNo())).uniqueResult();
			
			oMap.put("TRX_NO", kibKullSifreTanimTx.getTxNo());
			oMap.put("DF_FIRMA_NO", kibKullSifreTanimTx.getFirmaNo());
			oMap.put("DF_SIFRE_KANALI", kibKullSifreTanimTx.getKanalKod());
			if (("1").equals(kibKullSifreTanimTx.getKanalKod())) {
				oMap.put("DF_SIFRE_KANALI", "�NTERNET");
			}else if (("2").equals(kibKullSifreTanimTx.getKanalKod())) {
				oMap.put("DF_SIFRE_KANALI", "�A�RI MERKEZ�");
			}else {
				oMap.put("DF_SIFRE_KANALI", "�NTERNET-�A�RI MERKEZ�");
			}
			oMap.put("DF_KULLANICI_NO", kibKullSifreTanimTx.getKullNo());
			oMap.put("DF_SIFRE_ZARF_NO", kibKullSifreTanimTx.getSifreZarfNo());
			oMap.put("DF_TESLIM_TARIHI", kibKullSifreTanimTx.getTeslimTarihi());
			
			if (("1").equals(kibFirmaYetkiLimit.getInternetBankacigi()))
				oMap.put("INTERNETBANKACILIGI", true );
			else oMap.put("INTERNETBANKACILIGI", false );
			if (("1").equals(kibFirmaYetkiLimit.getCagriMerkezi()))
				oMap.put("CAGRIMERKEZI", true );
			else oMap.put("CAGRIMERKEZI", false );

			return oMap;
		} catch (Exception e) {
				throw new GMRuntimeException(0, e);
		} finally {
				
		}
	}
 
	
	@GraymoundService("BNSPR_TRN4208_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) { 
	    
		try {
		  
            Session session = DAOSession.getSession("BNSPRDal");
            KibKullSifreTanimTx kibKullSifreTanimTx = (KibKullSifreTanimTx)session.get(KibKullSifreTanimTx.class, iMap.getBigDecimal("ISLEM_NO"));
            
            if (kibKullSifreTanimTx.getTeslimTarihi() != null )
            {
    			GMServiceExecuter.call("BNSPR_TRN4208_PAROLA_PASSWORD", iMap);
    			GMServiceExecuter.call("BNSPR_TRN4207_GET_KULLANICI_BLOKE_DURUMU", iMap);
    			GMServiceExecuter.call("BNSPR_TRN4207_SEND_SMS", iMap);
    			
    			AdcTRN4207Services.replaceTrxPassword(iMap);
            }
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN4208_PAROLA_PASSWORD")
	public static GMMap parolaPassword(GMMap iMap){

		Connection conn = null;
		CallableStatement stmt = null;
		
		try {

			conn = DALUtil.getGMConnection();
        	stmt = conn.prepareCall("{call PKG_TRN4208.Get_User_Information(?,?,?,?,?,?,?,?,?,?,?)}");

        	stmt.setBigDecimal			(1, iMap.getBigDecimal("ISLEM_NO"));
        	stmt.registerOutParameter   (2, Types.NUMERIC); //MUSTERI NO
			stmt.registerOutParameter	(3, Types.VARCHAR); //TCKN
			stmt.registerOutParameter	(4, Types.VARCHAR); //TEL NO
			stmt.registerOutParameter	(5, Types.VARCHAR); //AKS
			stmt.registerOutParameter	(6, Types.VARCHAR); //PASS
			stmt.registerOutParameter	(6, Types.VARCHAR);
			stmt.registerOutParameter	(7, Types.VARCHAR);
			stmt.registerOutParameter	(8, Types.VARCHAR);
			stmt.registerOutParameter	(9, Types.VARCHAR);
			stmt.registerOutParameter	(10, Types.NUMERIC); //FIRMA NO
            stmt.registerOutParameter   (11, Types.VARCHAR);
			
			stmt.execute();
			
			GMMap servisMap = new GMMap();
			
			if ( ("1").equals(stmt.getString(7)) && ("1").equals(stmt.getString(8))){
				servisMap.put("CHANNEL_CODE" , "CINT");
			}else if (("1").equals(stmt.getString(7))){
				servisMap.put("CHANNEL_CODE" , "CINT");
		    }else if (("1").equals(stmt.getString(8))){
		    	servisMap.put("CHANNEL_CODE" , "CC");
		    }

			servisMap.put("USER_CODE", AdcWinspireServices.getUserName(stmt.getString(2),stmt.getString(10)));
			if (stmt.getString(6) != null ) 
			{
	            boolean isSmsPassword = stmt.getString(11).equals("S");
	            String password = stmt.getString(6);
	            
	            if (isSmsPassword) {
	                password = AdcTRN4207Services.encryptPassword(password);
	            }

	            iMap.put("PASSWORD", password);
	            servisMap.put("PASSWORD", password);
				servisMap.put("SERVICE_NAME","ADC_REMOTE_USER_UPDATE_PASSWORD");
						
				GMServiceExecuter.call("ADK_CALL_SERVICE", servisMap); 
			};
 
			return iMap;
    
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	}

    
    @GraymoundService("BNSPR_TRN4208_GET_LAST_PASSWORD_CREATION_INFO")
    public static GMMap getLastPasswordCreationInfo(GMMap iMap){
        GMMap oMap = new GMMap();
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        
        try {
            connection = DALUtil.getGMConnection();
            statement = connection.prepareStatement("select * from (" +
                                        "select decode(gonderim_tipi, 'Z', 'ZARF', 'S', 'SMS') gonderim_tipi," +
                                        " to_char(rec_date, 'dd.mm.yyyy hh24:mi:ss') record_date from BNSPR.KIB_KULL_SIFRE_TANIM_TX" +
                                        " where firma_no=? and kull_no=? and teslim_tarihi is not null" +
                                        " order by rec_date desc) where rownum=1");
            
            statement.setBigDecimal(1, iMap.getBigDecimal("FIRMA_KODU"));
            statement.setBigDecimal(2, iMap.getBigDecimal("KULLANICI_KODU"));
            resultSet = statement.executeQuery();
            
            if (resultSet != null && resultSet.next()) {
                oMap.put("SEND_TYPE", resultSet.getString("gonderim_tipi"));
                oMap.put("DATE", resultSet.getString("record_date"));
            }
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(resultSet);
            GMServerDatasource.close(statement);
            GMServerDatasource.close(connection);
        }
    }

}