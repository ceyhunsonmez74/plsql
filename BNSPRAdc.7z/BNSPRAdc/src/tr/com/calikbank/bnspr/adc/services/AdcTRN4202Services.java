package tr.com.calikbank.bnspr.adc.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HardTokenTalep;
import tr.com.aktifbank.bnspr.dao.KibKullaniciTanim;
import tr.com.aktifbank.bnspr.dao.KibKullaniciTanimTx;
import tr.com.aktifbank.bnspr.token.services.TokenServices;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.obss.adc.core.pojo.Channel;
import tr.com.obss.adc.core.pojo.Menu;
import tr.com.obss.adc.core.util.ADCCore;

import com.graymound.annotation.GraymoundService;
import com.graymound.referencedata.GMReferenceDataFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcTRN4202Services {
	
    @GraymoundService("BNSPR_TRN4202_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();

            
            iMap.put("KOD", "ITH_GUVENLIK_YONTEMI");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("GUVENLIK_YONTEMI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            iMap.put("KOD", "ITH_BLOKE_DURUMU");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("BLOKE_DURUMU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            iMap.put("KOD", "ITH_TOKEN_TIPI");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("TOKEN_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            iMap.put("KOD", "FIRMA_KULLANICI_YETKI_TURU");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("YETKI_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            iMap.put("KOD", "ITH_KULLANICI_TIPI");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("KULLANICI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }


    @GraymoundService("BNSPR_TRN4202_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
        Session session = DAOSession.getSession("BNSPRDal");
        KibKullaniciTanimTx kibKullaniciTanimTx = (KibKullaniciTanimTx) session.get(KibKullaniciTanimTx.class, txNo);

        oMap.put("TRX_NO", kibKullaniciTanimTx.getTxNo());
        oMap.put("BLOKE_DURUMU", kibKullaniciTanimTx.getBlokeDurumu());
        oMap.put("GUVENLIK_YONTEMI", kibKullaniciTanimTx.getGuvenlikYonetimi());
        oMap.put("KULLANICI_IP", kibKullaniciTanimTx.getIp());
        oMap.put("TOKEN_TIPI", kibKullaniciTanimTx.getTokenTipi());
        oMap.put("YETKI_TURU", kibKullaniciTanimTx.getYetkiTuru());
        // oMap.put("KULLANICI_KODU", kibKullaniciTanimTx.getKullaniciNo());
        oMap.put("GENEL_KULLANICI_KODU", kibKullaniciTanimTx.getKullaniciNo());
        oMap.put("FIRMA_KODU", kibKullaniciTanimTx.getFirmaNo());
        oMap.put("FIRMA_UNVANI", LovHelper.diLov(kibKullaniciTanimTx.getFirmaNo(), "4202/LOV_FIRMA_UNVANI", "MUSTERI_ADI"));
        // oMap.put("KULLANICI_UNVANI",
        // LovHelper.diLov(kibKullaniciTanimTx.getKullaniciNo(),
        // "4202/LOV_GENEL_KULLANICI" , "MUSTERI_ADI" ));
        oMap.put("CEP_TELEFONU", kibKullaniciTanimTx.getCepTelefonu());
        oMap.put("KULLANICI_TIPI", kibKullaniciTanimTx.getKullaniciTipi());
        oMap.put("SERI_NO", kibKullaniciTanimTx.getSeriNo());

        return oMap;
    }


    @GraymoundService("BNSPR_TRN4202_GET_TRANSFER_DATA")
    public static GMMap getTransferData(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");

        List<?> recordList =
            (List<?>) session.createCriteria(KibKullaniciTanim.class).add(Restrictions.eq("id.kullaniciNo", iMap.getBigDecimal("KULLANICI_KODU")))
                .add(Restrictions.eq("id.firmaNo", iMap.getBigDecimal("FIRMA_KODU"))).list();

        for (int row = 0; row < recordList.size(); row++) {
            KibKullaniciTanim kibKullaniciTanim = (KibKullaniciTanim) recordList.get(row);
            oMap.put("YETKI_TURU", kibKullaniciTanim.getYetkiTuru());
            oMap.put("BLOKE_DURUMU", kibKullaniciTanim.getBlokeDurumu());
            oMap.put("GUVENLIK_YONETIMI", kibKullaniciTanim.getGuvenlikYonetimi());
            oMap.put("KULLANICI_IP", kibKullaniciTanim.getIp());
            oMap.put("TOKEN_TIPI", kibKullaniciTanim.getTokenTipi());
            // oMap.put("KULLANICI_KODU",
            // kibKullaniciTanim.getId().getKullaniciNo());
            oMap.put("GENEL_KULLANICI_KODU", kibKullaniciTanim.getId().getKullaniciNo());
            oMap.put("CEP_TELEFONU", kibKullaniciTanim.getCepTelefonu());
            oMap.put("KULLANICI_TIPI", kibKullaniciTanim.getKullaniciTipi());
            oMap.put("SERI_NO", kibKullaniciTanim.getSeriNo());
        }
        return oMap;
    }

    private static boolean isEmpty(String value) {
        return (value == null || value.trim().equals(""));
    }

    private static void loadMenuChildren(Session session, Menu menu, List<Menu> menuList) {
        for (Iterator<Menu> iterator = menu.getChildren().iterator(); iterator.hasNext();) {
            Menu child = iterator.next();
            menuList.add(child);
            loadMenuChildren(session, child, menuList);
            session.evict(child);
        }
    }

    /**
     * 
     * Kanala ait olan menuleri kanal OID'si ile veri taban�ndan �ekerek liste
     * olarak d�nd�r�r
     * 
     * @param channelOid
     *            Kanal OID'si
     * @return Menu Listesi
     * 
     */
    public static ArrayList<Menu> lookupMenu(String channelOid) {
        Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
        Channel channel = (Channel) session.get(Channel.class, channelOid);
        ArrayList<Menu> result = new ArrayList<Menu>();
        for (Iterator<Menu> iterator = channel.getMenu().iterator(); iterator.hasNext();) {
            Menu menu = iterator.next();
            loadMenuChildren(session, menu, result);
            session.evict(menu);
            result.add(menu);
        }
        return result;
    }

    @GraymoundService("BNSPR_TRN4202_SAVE")
    public static Map<?, ?> Save(GMMap iMap) {
        /*
         * if(!AdcTRN4200Services.validateIP(iMap.getString("KULLANICI_IP")))
         * { iMap.put("HATA_NO", new BigDecimal(1489));
         * GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap); return
         * null; }
         */

        if (isEmpty(iMap.getString("FIRMA_KODU"))) {
            iMap.put("HATA_NO", new BigDecimal(330));
            iMap.put("P1", "Firma Kodu");
            return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
        }

        GMMap oMap = new GMMap();

        if (isEmpty(iMap.getString("CEP_TELEFONU"))) {
            iMap.put("MESSAGE_NO", new BigDecimal(330));
            iMap.put("P1", "CEP TELEFON");
            oMap.put("WARN_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
            return oMap;
        }

        if ((isEmpty(iMap.getString("TCKN")) && iMap.getString("UYRUK_KODU").equals("TR")) || isEmpty(iMap.getString("ISYERI_UNVANI")) || isEmpty(iMap.getString("ANNE_KIZLIK_SOYADI"))
            || isEmpty(iMap.getString("CEP_TELEFONU")) || isEmpty(iMap.getString("ADRES")) || (("TR").equals(iMap.getString("ULKE_KODU")) && isEmpty(iMap.getString("IL_KODU")))
            || (("TR").equals(iMap.getString("ULKE_KODU")) && isEmpty(iMap.getString("ILCE_KODU"))) || isEmpty(iMap.getString("ULKE_KODU"))
            || (!iMap.getString("UYRUK_KODU").equals("TR") && isEmpty(iMap.getString("TCKN")) && isEmpty(iMap.getString("PASAPORT_NO")))) {

            iMap.put("MESSAGE_NO", new BigDecimal(1397));
            oMap.put("WARN_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
            return oMap;
        }

        Session session = DAOSession.getSession("BNSPRDal");
        KibKullaniciTanimTx kibKullaniciTanimTx = (KibKullaniciTanimTx) session.get(KibKullaniciTanimTx.class, iMap.getBigDecimal("TRX_NO"));

        if (kibKullaniciTanimTx == null) {
            kibKullaniciTanimTx = new KibKullaniciTanimTx();
        }
        
        if (isEmpty(iMap.getString("GUVENLIK_YONTEMI"))) {
        	iMap.put("MESSAGE_NO", new BigDecimal(330));
            iMap.put("P1", "GUVELIK YONTEMI");
            oMap.put("WARN_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
            return oMap;
		}
        
        iMap.put("USER_CODE",
				iMap.get("KULLANICI_KODU") + "@" + iMap.get("FIRMA_KODU"));
        
        TokenServices.findOidFromCodes(iMap);
        
		if (iMap.getString("USER_OID") == null) {
			if (iMap.getString("GUVENLIK_YONTEMI").equals("2")) {
				iMap.put("MESSAGE_NO", new BigDecimal(2922));
				oMap.put("WARN_MESSAGE", (String) GMServiceExecuter
						.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap)
						.get("ERROR_MESSAGE"));
				return oMap;
			}
		} else {
			GMMap iMapBloke = new GMMap();
			GMMap oMapBloke = new GMMap();
			// iMapBloke.put("CHANNEL_OID", channel.getOid());
			// iMapBloke.put("USER_OID", iMap.getString("USER_OID"));
			//
			// GMMap oMapBloke = GMServiceExecuter.call(
			// "ADC_CHECK_USER_CHANNEL_BLOCK", iMapBloke);

			iMapBloke.put("KULLANICI_KOD",
					iMap.getBigDecimal("KULLANICI_KODU"));
			iMapBloke.put("MUSTERI_NO", iMap.getBigDecimal("FIRMA_KODU"));

			if (iMap.getBigDecimal("KULLANICI_KODU") != null
					&& iMap.getBigDecimal("FIRMA_KODU") != null) {
				oMapBloke = GMServiceExecuter.call(
						"BNSPR_TRN4131_GET_KANAL_BLOKE", iMapBloke);
			}

			if (oMapBloke.get("BLOKE_BILGI") != null
					&& iMap.getString("GUVENLIK_YONTEMI") != null
					&& iMap.getString("ESKI_GUVENLIK_YONTEMI") != null
					&& !iMap.getString("GUVENLIK_YONTEMI").equals(
							iMap.getString("ESKI_GUVENLIK_YONTEMI"))) {
				iMap.put("MESSAGE_NO", new BigDecimal(2785));
				oMap.put("WARN_MESSAGE", (String) GMServiceExecuter
						.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap)
						.get("ERROR_MESSAGE"));
				return oMap;
			}

			if (iMap.getString("GUVENLIK_YONTEMI").equals("2")) {
				iMap.remove("USER_OID");
				GMMap tokenGMap = TokenServices.getTokenTalep(iMap);

				if (tokenGMap.get("RESPONSE").equals("0")) {
					iMap.put("MESSAGE_NO", new BigDecimal(2903));
					oMap.put(
							"WARN_MESSAGE",
							(String) GMServiceExecuter
									.execute(
											"BNSPR_COMMON_GET_KODSUZ_MESSAGE",
											iMap).get("ERROR_MESSAGE"));
					return oMap;
				}

				if (tokenGMap.getString("RESPONSE").equals("4")) {
					iMap.put("MESSAGE_NO", new BigDecimal(2904));
					oMap.put(
							"WARN_MESSAGE",
							(String) GMServiceExecuter
									.execute(
											"BNSPR_COMMON_GET_KODSUZ_MESSAGE",
											iMap).get("ERROR_MESSAGE"));
					return oMap;
				} else if (tokenGMap.getString("RESPONSE").equals("3")) {
					HardTokenTalep token = (HardTokenTalep) tokenGMap
							.get("TALEP");

					if (token.getOperationStatus().equals("KURYEDE")) {
						iMap.put("MESSAGE_NO", new BigDecimal(2904));
						oMap.put(
								"WARN_MESSAGE",
								(String) GMServiceExecuter.execute(
										"BNSPR_COMMON_GET_KODSUZ_MESSAGE",
										iMap).get("ERROR_MESSAGE"));
						return oMap;
					}

					if (!token.getOperationStatus().equals("KULLANIMDA")) {
						iMap.put("MESSAGE_NO", new BigDecimal(2904));
						oMap.put(
								"WARN_MESSAGE",
								(String) GMServiceExecuter.execute(
										"BNSPR_COMMON_GET_KODSUZ_MESSAGE",
										iMap).get("ERROR_MESSAGE"));
						return oMap;
					}
				}else if(tokenGMap.getString("RESPONSE").equals("5")) {
					iMap.put("MESSAGE_NO", new BigDecimal(2904));
					oMap.put(
							"WARN_MESSAGE",
							(String) GMServiceExecuter
									.execute(
											"BNSPR_COMMON_GET_KODSUZ_MESSAGE",
											iMap).get("ERROR_MESSAGE"));
						return oMap;
					}
				}
			}
            
  
			
            kibKullaniciTanimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
        kibKullaniciTanimTx.setBlokeDurumu(iMap.getString("BLOKE_DURUMU"));
        kibKullaniciTanimTx.setFirmaNo(iMap.getBigDecimal("FIRMA_KODU"));
        kibKullaniciTanimTx.setGuvenlikYonetimi(iMap.getString("GUVENLIK_YONTEMI"));
        kibKullaniciTanimTx.setIp(iMap.getString("KULLANICI_IP"));

        kibKullaniciTanimTx.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU") != null ? iMap.getBigDecimal("KULLANICI_KODU") : iMap.getBigDecimal("YENI_KULLANICI_KODU"));

        kibKullaniciTanimTx.setTokenTipi(iMap.getString("TOKEN_TIPI"));
        kibKullaniciTanimTx.setYetkiTuru(iMap.getString("YETKI_TURU"));
        kibKullaniciTanimTx.setCepTelefonu(iMap.getString("CEP_TELEFONU"));
        kibKullaniciTanimTx.setKullaniciTipi(iMap.getString("KULLANICI_TIPI"));
        kibKullaniciTanimTx.setSeriNo(iMap.getString("SERI_NO"));
        session.saveOrUpdate(kibKullaniciTanimTx);
        session.flush();

        iMap.put("TRX_NAME", "4202");
        return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
    }
    
    
    @GraymoundService("BNSPR_TRN4202_AFTER_APPROVAL")
    public static GMMap afterApproval(GMMap iMap) {
        try {
        	
            GMServiceExecuter.call("BNSPR_TRN4202_CREATE_USER", iMap);
            GMServiceExecuter.call("BNSPR_TRN4202_GET_KULLANICI_BLOKE_DURUMU", iMap);
            
            createSmsPassword(iMap);

            return iMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    private static void createSmsPassword(GMMap iMap) {
        BigDecimal firmCode = iMap.getBigDecimal("MUSTERI_NO");
        BigDecimal userCode = iMap.getBigDecimal("COMPANY_USER_CODE");
        
        Session session = DAOSession.getSession("BNSPRDal");
        @SuppressWarnings("unchecked")
        List<KibKullaniciTanimTx> list = session.createCriteria(KibKullaniciTanimTx.class)
                .add(Restrictions.eq("firmaNo", firmCode))
                .add(Restrictions.eq("kullaniciNo", userCode))
                .list();
        
        // send sms on user creation only
        if (list.size() == 1) {
            String phoneNumber = list.get(0).getCepTelefonu();
            
            if (phoneNumber != null && !phoneNumber.isEmpty()) {
                GMMap serviceMap = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap);
                
                serviceMap.put("DF_FIRMA_NO", firmCode);
                serviceMap.put("DF_KULLANICI_KODU", userCode);
                serviceMap.put("DF_SIFRE_KANALI", "�NTERNET");
                serviceMap.put("SEND_PASSWORD_SMS", true);
                serviceMap.put("ONAYSIZ_ISLEM", true);
        
                GMServiceExecuter.execute("BNSPR_TRN4207_SAVE", serviceMap);
                
                String message = AdcTRN4207Services.createMessage(4997, firmCode.toString(), userCode);
                AdcTRN4207Services.sendSms(phoneNumber, message);
            }
        }
    }


    @GraymoundService("BNSPR_TRN4202_CREATE_USER")
    public static GMMap createAdk(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        try {
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{? = call PKG_TRN4202.ADK_user_create_check(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)}");

            stmt.registerOutParameter(1, Types.NUMERIC);
            stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.registerOutParameter(4, Types.NUMERIC);
            stmt.registerOutParameter(5, Types.VARCHAR);
            stmt.registerOutParameter(6, Types.VARCHAR);
            stmt.registerOutParameter(7, Types.VARCHAR);
            stmt.registerOutParameter(8, Types.VARCHAR);
            stmt.registerOutParameter(9, Types.VARCHAR);
            stmt.registerOutParameter(10, Types.VARCHAR);
            stmt.registerOutParameter(11, Types.VARCHAR);
            stmt.registerOutParameter(12, Types.VARCHAR);
            stmt.registerOutParameter(13, Types.NUMERIC);
            stmt.registerOutParameter(14, Types.VARCHAR);
            stmt.registerOutParameter(15, Types.VARCHAR);
            stmt.registerOutParameter(16, Types.VARCHAR); // yetki turu
            stmt.registerOutParameter(17, Types.VARCHAR);
            stmt.registerOutParameter(18, Types.VARCHAR);

            stmt.execute();

            int row = 0;
            JGMPasswordField passwordField = new JGMPasswordField();
            iMap.put("USERNAME", AdcWinspireServices.getUserName(stmt.getBigDecimal(13), stmt.getBigDecimal(4)));

            iMap.put("MUSTERI_NO", stmt.getBigDecimal(4));

            // iMap.put("INTEGRATION" , 0, "KEY" , "MUSTERI_NO");
            // iMap.put("INTEGRATION" , 0, "VALUE", stmt.getBigDecimal(4));
            // //firma kodu

            iMap.put("INTEGRATION", row, "KEY", "PHONE_NUMBER");
            iMap.put("INTEGRATION", row++, "VALUE", stmt.getString(6));

            iMap.put("INTEGRATION", row, "KEY", "MUSTERI_GRUP");
            iMap.put("INTEGRATION", row++, "VALUE", stmt.getString(7));

            iMap.put("INTEGRATION", row, "KEY", "SEGMENT");
            iMap.put("INTEGRATION", row++, "VALUE", stmt.getString(8));

            iMap.put("INTEGRATION", row, "KEY", "DOGUM_YILI");
            iMap.put("INTEGRATION", row++, "VALUE", stmt.getString(10));

            iMap.put("INTEGRATION", row, "KEY", "DOGUM_AYI");
            iMap.put("INTEGRATION", row++, "VALUE", stmt.getString(11));

            iMap.put("INTEGRATION", row, "KEY", "DOGUM_GUNU");
            iMap.put("INTEGRATION", row++, "VALUE", stmt.getString(12));

            iMap.put("INTEGRATION", row, "KEY", "NO_OTP_ACTION");
            iMap.put("INTEGRATION", row++, "VALUE", "2");

            iMap.put("INTEGRATION", row, "KEY", "TYPE");
            iMap.put("INTEGRATION", row++, "VALUE", stmt.getString(17));
            
            iMap.put("INTEGRATION", row, "KEY", "SECURITY_OPTION");
            iMap.put("INTEGRATION", row++, "VALUE", stmt.getString(18));
            
            iMap.put("COMPANY_USER_CODE", stmt.getBigDecimal(13));

            // iMap.put("INTEGRATION" , 8, "KEY" , "COMPANY_USER_CODE");
            // iMap.put("INTEGRATION" , 8, "VALUE", stmt.getBigDecimal(13));

            if (("1").equals(stmt.getString(14)) && ("1").equals(stmt.getString(15) == "1")) {

                iMap.put("CHANNELS", 0, "CODE", "CINT");
                iMap.put("ROLES", 0, "CODE", "KK");

                iMap.put("CHANNELS", 1, "CODE", "CC");
                iMap.put("ROLES", 1, "CODE", "KK");

            } else if (("1").equals(stmt.getString(14))) {

                iMap.put("CHANNELS", 0, "CODE", "CINT");
                iMap.put("ROLES", 0, "CODE", "KK");

            } else if (("1").equals(stmt.getString(14))) {

                iMap.put("CHANNELS", 0, "CODE", "CC");
                iMap.put("ROLES", 0, "CODE", "KK");
            }

            passwordField.setText(stmt.getString(5));
            iMap.put("CHANNELS", 0, "PAROLE", new String(passwordField.getPassword()));

            iMap.put("CHANNELS", 0, "PASSWORD", GMReferenceDataFactory.getReferenceDataValue("CINT_INIT_PASS", "NAME", "INIT_PASS", "CODE"));

            iMap.put("USER_TRANSACTION_TYPE", stmt.getString(16));

            GMServiceExecuter.executeNT("ADK_CREATE_CINT_USER", iMap);

            return new GMMap();

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN4202_GET_KULLANICI_BLOKE_DURUMU")
    public static GMMap getKullaniciBlokeDurumu(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;

        try {
            conn = DALUtil.getGMConnection();
            Session session = DAOSession.getSession("BNSPRDal");
            KibKullaniciTanimTx kibKullaniciTanimTx = (KibKullaniciTanimTx) session.get(KibKullaniciTanimTx.class, iMap.getBigDecimal("ISLEM_NO"));

            stmt = conn.prepareCall("{? = call PKG_RC4207.kib_kullanici_bloke_durumu(?,?)}");
            int i = 1;
            stmt.registerOutParameter(i++, Types.INTEGER); // ref cursor
            stmt.setBigDecimal(i++, kibKullaniciTanimTx.getFirmaNo());
            stmt.setBigDecimal(i++, kibKullaniciTanimTx.getKullaniciNo());

            stmt.execute();

            boolean isBlocked = "2".equals(stmt.getString(1));
            if (isBlocked) {
                stmt = conn.prepareCall("{call PKG_RC4207.kib_kullanici_bloke_koyma(?,?,?)}");
                int j = 1;

                stmt.setBigDecimal(j++, iMap.getBigDecimal("ISLEM_NO"));
                stmt.setString(j++, kibKullaniciTanimTx.getFirmaNo().toString());
                stmt.setString(j++, kibKullaniciTanimTx.getKullaniciNo().toString());
                stmt.execute();
                session.flush();

                iMap.put("ISLEM_KODU", new java.math.BigDecimal("4131"));
                GMServiceExecuter.execute("BNSPR_TRN4131_AFTER_APPROVAL", iMap);
            }

            return oMap;
        } catch (Exception e) {
            throw new GMRuntimeException(1, e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);

        }
    }

    
}
