package tr.com.aktifbank.bnspr.clks.services.investment;

import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.CommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal.GMCacheCommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;
import tr.com.aktifbank.bnspr.adc.clks.customer.model.Customer.CustomerType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCustomerAcquisitionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CustomerAcquisition;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants.BasvuruDurum;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBasvuru;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBelge;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepBelgeTx;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepTx;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.graymound.util.GMToolkit;

public class BondServices {
	
	private static Logger logger = Logger.getLogger(BondServices.class);
	private static final String DOKUMAN_KOD_UYGUNLUK_TESTI = "566";
	private static final String DOKUMAN_KOD_IKAMETGAH_FATURA = "347";
	private static final String BELGE_KONTROL_GONDERILDI = "5";
	private static final String TELEFON_TIP_GSM = "3";
	private static final String TELEFON_FORMAT_TUM_KOD = "+UAT";
	private static final String MUSTERI_GRUP_KOD = "701";
	private static final String PORTFOY_KOD = "0444.BRY.01.00";
	private static final String KAZANIM_URUNU = "NKOLAYBONO";	
	private static final String PRODUCT_CODE = "BONO";
	private static Integer CREATE_DRAWING_ACCOUNT_MESSAGE_NO = 5699;

	
	private enum Response {
		
		ERROR(0), MISSING_DOCUMENT(1), SUCCESS(2), NEW_CUSTOMER(3);
		
		private int value;
		
		Response(int value) {
			this.value = value;
		}
	    public int getValue() {
	        return value;
	    }
	}
	
	private enum YatirimEkstre {

		SECINIZ("X", "Se�im yap�lmad�"), 
		ISTENMEDI("H", "Ekstre �stemiyorum"), 
		EPOSTA("M", "E-Posta"), 
		POSTA("E", "Posta"),
		ELEKTRONIK_ORTAM("O","Elektronik Ortam");

		private String kod;
		private String aciklama;

		YatirimEkstre(String kod, String aciklama) {
			this.kod = kod;
			this.aciklama = aciklama;
		}

		@Override
		public String toString() {
			return kod;
		}
		
		public String getAciklama() {
			return aciklama;
		}

		public static YatirimEkstre getEnum(String kod) {
			for (YatirimEkstre v : values())
				if (v.toString().equalsIgnoreCase(kod))
					return v;
			throw new IllegalArgumentException();
		}
	}
	
	private enum HesapEkstre {

		SECINIZ("H"), 
		EPOSTA("K"), 
		POSTA("E"),
		ELEKTRONIK_ORTAM("O");

		private String kod;

		HesapEkstre(String kod) {
			this.kod = kod;
		}

		@Override
		public String toString() {
			return kod;
		}
	}
	
	/**
	 * PTT Bono urunune iliskin musteri validasyon servisidir. Girilen {@code TC_KIMLIK_NO} degerinin Akustik'de musteri
	 * karsiligi olmamasi durumunda {@code REPONSE=3}, musteri karsiligi olmasi ancak eksik belge olmasi durumunda
	 * {@code RESPONSE=1}, eksik belge olmamasi durumunda {@code RESPONSE=2} doner.
	 * 
	 * @param iMap {TC_KIMLIK_NO} TC Kimlik Numarasi
	 * @return
	 * 
	 * @throws GMRuntimeException Herhangi bir adimda hata alindiginda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_BONO_MUSTERI_SORGULAMA")
	public static GMMap bnsprClksBonoMusteriSorgulama(GMMap iMap) {
		
		GMMap oMap = new GMMap(), hesapMap = new GMMap();
		String telefon;
		BigDecimal eksikBelgeBasvuru;
		
		try {
			
			// Validation: TC Kimlik
	    	if(GMServiceExecuter.call("BNSPR_COMMON_TCKN_CHECK_DIGIT", new GMMap().put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"))).getInt("SONUC") == 0) {
	    		iMap.put("HATA_NO", "456");
				iMap.put("P1", iMap.getString("TC_KIMLIK_NO"));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	    	}
			
			oMap.put("MUSTERI_NO", (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_musteri.Musteri_Varmi_TCKN(?)}", 
				BnsprType.NUMBER,
				BnsprType.STRING, iMap.getString("TC_KIMLIK_NO")));
						
			if(oMap.get("MUSTERI_NO") == null) {
				return new GMMap().put("RESPONSE", Response.NEW_CUSTOMER.getValue());
			}
			
			if("K".equals((String) DALUtil.callOracleFunction("{? = call pkg_musteri.musteriMi_kontaktMi(?)}", 
					BnsprType.STRING,
					BnsprType.NUMBER, oMap.getBigDecimal("MUSTERI_NO")))) {
				
				return new GMMap().put("RESPONSE", Response.NEW_CUSTOMER.getValue());
			}
			
            BigDecimal txNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>()).get("TRX_NO").toString());
			
			telefon = (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.telefon(?,?,?) }", 
				BnsprType.STRING, 
				BnsprType.NUMBER, oMap.getBigDecimal("MUSTERI_NO"), 
				BnsprType.STRING, TELEFON_TIP_GSM,
				BnsprType.STRING, TELEFON_FORMAT_TUM_KOD);
			
			if(telefon == null || telefon.length() == 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 660)
					.put("P1", "L�tfen Gsm bilgilerinizi g�ncelleyiniz."));
			}
			
			// Belgeleri Kontrol Et	
			eksikBelgeBasvuru = (BigDecimal) DALUtil.callOracleFunction("{ ? = call pkg_trn4801.eksik_belge_basvuru(?) }", 
				BnsprType.NUMBER,
				BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"));
			
			List<String> musteriBelgeList = getMusteriBelgeList(oMap.getBigDecimal("MUSTERI_NO"));
			List<String> bonoBelgeList = getBonoBelgeList(eksikBelgeBasvuru, false);
			Iterator<String> iterator = bonoBelgeList.iterator();
			
			while(iterator.hasNext()) {
				String dokumanKod = iterator.next();
				if(!musteriBelgeList.contains(dokumanKod)) {
					oMap.putAll(eksikBelgeKontrol(eksikBelgeBasvuru, oMap.getBigDecimal("MUSTERI_NO"), iMap.getString("TC_KIMLIK_NO"), dokumanKod));
					if(Response.MISSING_DOCUMENT.equals((Response)oMap.get("RESPONSE"))) {
						oMap.put("RESPONSE", Response.MISSING_DOCUMENT.getValue());
						return oMap;
					}
				}
			}
			
			if(bonoBelgeList.size() == 0) {
				
				Map<String, List<String>> bonoBelgeMap = getBonoBelgeMap();

				belgeMapKeySet:
				for(String dokumanKod : bonoBelgeMap.keySet()) {
					
					if(!musteriBelgeList.contains(dokumanKod)) {
						
						if(bonoBelgeMap.get(dokumanKod) != null) {
							for(String kabulBelgeDokumanKod : bonoBelgeMap.get(dokumanKod)) {
								if(musteriBelgeList.contains(kabulBelgeDokumanKod)) {
									continue belgeMapKeySet; // pass
								}
								
								if("H".equals((String) DALUtil.callOracleFunction("{ ? = call pkg_trn4801.eksik_belge_mi(?,?,?) }", 
									BnsprType.STRING, 
									BnsprType.NUMBER, eksikBelgeBasvuru,
									BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"),
									BnsprType.STRING, kabulBelgeDokumanKod))) {
									continue belgeMapKeySet;
								}
							}
						}
						
						if("H".equals((String) DALUtil.callOracleFunction("{ ? = call pkg_trn4801.eksik_belge_mi(?,?,?) }", 
							BnsprType.STRING, 
							BnsprType.NUMBER, eksikBelgeBasvuru,
							BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"),
							BnsprType.STRING, dokumanKod))) {
							continue;
						}
						
						oMap.put("RESPONSE", Response.MISSING_DOCUMENT.getValue());
						oMap.put("F_YATIRIM_EKSTRE", getYatirimEkstreBilgi(oMap.getBigDecimal("MUSTERI_NO")));
						oMap.put("BASVURU_DURUM", getBasvuruDurum(iMap.getString("TC_KIMLIK_NO")));
						return oMap;
					}
				}
			}
			// Belge Kontrol Tamam
			
			hesapMap = GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_LIST", new GMMap().put("MUSTERI_NO", oMap.getBigDecimal("MUSTERI_NO")));
			
			// M��terinin ilk TL hesab�n� d�n�yor ve bu hesap �zerinden i�lem yap�lacak.
			BigDecimal hesapNo = new BigDecimal(0);
			for(int i = 0; i < hesapMap.getSize("RESULTS"); i++) {
				if("TRY".equals(hesapMap.getString("RESULTS", i, "DOVIZ_KODU")) && "A".equals(hesapMap.getString("RESULTS", i, "DURUM"))) {
					BigDecimal tempHesap = hesapMap.getBigDecimal("RESULTS", i, "HESAP_NO");
					if(hesapNo.compareTo(new BigDecimal(0)) == 0) {
						hesapNo = tempHesap;
						continue;
					}
					else {
						if(hesapNo.compareTo(tempHesap) == 1) {
							hesapNo = tempHesap;
						}
					}
				}
			}
			oMap.put("HESAP_NO", hesapNo);
			
			if(oMap.containsKey("MUSTERI_NO") && !oMap.containsKey("HESAP_NO")) {
				
				// Vadesiz hesap acilisi yapiliyor
				GMMap hMap = GMServiceExecuter.call("BNSPR_CURRENT_ACCOUNTS_CREATE_DRAWING_ACCOUNT", new GMMap()
					.put("MUSTERI_NO", oMap.getBigDecimal("MUSTERI_NO"))
					.put("DOVIZ_KODU", "TRY")
					.put("RUMUZ", (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.kisa_ad(?) }", BnsprType.STRING, BnsprType.NUMBER, oMap.getBigDecimal("MUSTERI_NO")))
					.put("EKSTRE_BASIM_KODU", "X"));
				
				oMap.put("HESAP_NO", hMap.get("HESAP_NUMARASI"));
				
				if (hMap.get("HESAP_NUMARASI") != null && !hMap.getBigDecimal("HESAP_NUMARASI").equals(BigDecimal.ZERO)) {
					
					GMMap msgMap = new GMMap();
					msgMap.put("MESSAGE_NO", BigDecimal.valueOf(CREATE_DRAWING_ACCOUNT_MESSAGE_NO));
					msgMap.put("MSISDN", telefon);
					msgMap.put("TRX_NO",txNo);
					msgMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
					sendSMS(msgMap);
				}
			}
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_BONO_MUSTERI_SORGULAMA err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * PTT Bono urunu musteri kazanim servisi, {@code BNSPR_CLKS_BONO_MUSTERI_SORGULAMA} sonucu eger musteri mevcut 
	 * degil ise cagirilir.
	 * 
	 * 
	 * @param iMap {ISYERI_VE_KULLANICI_BILGILERI[{ISLEMIN_YAPILDIGI_SUBE_ID,ISLEMI_YAPAN_KULLANICI,
	 * ISLEMI_YAPAN_KULLANICI_SICIL,PTT_ISLEM_NO}]}				PTT Sube/Sicil bilgisi
	 * @param iMap {KPS_BILGILERI[{KIMLIK_TIPI,TC_KIMLIK_NO}]}	KPS bilgisi
	 * @param iMap {ADRES_BILGILERI[{...}]}						Ares bilgisi
	 * @param iMap {TC_KIMLIK_NO}								TC Kimlik Numarasi
	 * @param iMap {POSTA_CEKI_HESAP_NUMARASI}					PTT PCH Hesap Numarasi
	 * @param iMap {CEP_TEL_KOD}								GSM Alan Kodu
	 * @param iMap {CEP_TEL_NO}									GSM Numarasi
	 * @param iMap {EV_TEL_KOD}									Ev Telefonu Alan Kodu
	 * @param iMap {EV_TEL_NO}									Ev Telefonu Numarasi
	 * @param iMap {EMAIL}										Email
	 * @param iMap {CALISMA_SEKLI}								Calisma Sekli Kodu
	 * @param iMap {ANNE_KIZLIK_SOYADI}
	 * @param iMap {F_KPS_YAPILDI}								KPS Entegrasyon Bilgisi
	 * @param iMap {F_APS_YAPILDI}								APS Entegrasyon Bilgisi
	 * @param iMap {F_ADRES_BILGILERI_UYUMULU}
	 * @param iMap {YATIRIM_EKSTRE}								Yatirim Ekstre Tercihi
	 * @param iMap {HESAP_EKSTRE}								Hesap Ekstre Tercihi
	 * @return
	 * 
	 * @throws GMRuntimeException Herhangi bir adimda hata alindiginda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_BONO_MUSTERI_BASVURU")
	public static GMMap bnsprClksBonoMusteriBasvuru(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();
		
		try {
			
			map.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			map.put("MUSTERI_TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			map.putAll(kontaktMusteriYaratVeyaGuncelle(new GMMap(mapKeys(map))));
			map.put("CEP_TEL_NO", iMap.getString("CEP_TEL_KOD").concat(iMap.getString("CEP_TEL_NO")));
			map.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN4800_GET_APPLICATION_NO", new GMMap()).getString("BASVURU_NO"));
			
			for(int i = 0; i < map.getSize("ADRES_BILGILERI"); i++) {
				
				map.put("EV_ADRES", iMap.getString("ADRES_BILGILERI", i, "EV_ADRES"));
				map.put("EV_ADR_ILCE_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_ILCE_KOD"));
				map.put("EV_ADR_IL_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_IL_KOD"));
				map.put("EV_POSTA_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_POSTA_KOD"));
				map.put("F_BEYAN_ADRES", "H");
				
				if("H".equals(iMap.getString("ADRES_BILGILERI", i, "F_APS"))) {
					map.put("F_BEYAN_ADRES", "E");
					break;
				}
			}
			
			GMServiceExecuter.call("BNSPR_TRN4800_SAVE", map);
			oMap.put("TRX_NO", map.get("TRX_NO"));
			
			if (map.getBigDecimal("BASVURU_NO") != null && map.getBigDecimal("BASVURU_NO").intValue() > 0) {
				GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", map.getString("CEP_TEL_NO")).put("CONTENT", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5683)).getString("ERROR_MESSAGE")));
			}

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_BONO_MUSTERI_BASVURU err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * TBD
	 * 
	 * <p>* Zorunlu, ** Kosullu Zorunlu</p>
	 * 
	 * @param iMap {TRX_NO**} 							{@code BNSPR_CLKS_BONO_MUSTERI_BASVURU} sonrasi cagiriliyor ise, 
	 * 													zorunludur, {@code BNSPR_CLKS_BONO_MUSTERI_BASVURU} servisinden 
	 * 													d�nen <code>GMMap{TRX_NO}</code> de�eri ge�ilmelidir.
	 * @param iMap {TC_KIMLIK_NO*} 						TC Kimlik Numarasi
	 * @param iMap {YATIRIM_EKSTRE**}					Yatirim Ekstre Tercihi
	 * @param iMap {EMAIL**}							Email
	 * @param iMap {ISYERI_VE_KULLANICI_BILGILERI*[{ISLEMIN_YAPILDIGI_SUBE_ID,ISLEMI_YAPAN_KULLANICI,
	 * ISLEMI_YAPAN_KULLANICI_SICIL,PTT_ISLEM_NO}]}		PTT Sube/Sicil bilgisi
	 * @return
	 * 
	 * @throws GMRuntimeException Herhangi bir adimda hata alindiginda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_BILGILERI")
	public static GMMap bnsprClksBonoMusteriBasvuruBelgeBilgileri(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		List<String> musteriBelgeList =  new ArrayList<String>(), bonoBelgeList;
		BigDecimal eksikBelgeBasvuru;
		
		try {
			
			// Musteri Edinim
			if(iMap.get("TRX_NO") != null) {
				
				Session session = DAOSession.getSession("BNSPRDal");
				ClksBonoTalepTx talepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class, iMap.getBigDecimal("TRX_NO"));
				ClksBonoTalepBasvuru bonoTalepBasvuru = (ClksBonoTalepBasvuru) session.get(ClksBonoTalepBasvuru.class, talepTx.getBasvuruNo());
				oMap.put("BASVURU_NO", talepTx.getBasvuruNo());
				oMap.put("BASVURU_TARIHI", bonoTalepBasvuru != null ? new SimpleDateFormat("yyyyMMdd").format(bonoTalepBasvuru.getRecDate()) : new SimpleDateFormat("yyyyMMdd").format(new Date()));
				oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				iMap.put("EV_ADRES", talepTx.getEvAdres());
				iMap.put("EV_ADR_ILCE_KOD", talepTx.getEvAdrIlceKod());
				iMap.put("EV_ADR_IL_KOD", talepTx.getEvAdrIlceKod());
				iMap.put("EV_POSTA_KOD", talepTx.getEvPostakod());
				iMap.put("F_BEYAN_ADRES", talepTx.getFBeyanAdres());
				iMap.put("MUSTERI_NO", talepTx.getMusteriNo());
			} 
			
			// Mevcut Musteri/Eksik Evrak
			else {
				
				eksikBelgeBasvuru = (BigDecimal) DALUtil.callOracleFunction("{ ? = call pkg_trn4801.eksik_belge_basvuru(?) }", 
						BnsprType.NUMBER,
						BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"));
				
				oMap.put("BASVURU_NO", eksikBelgeBasvuru != null ? eksikBelgeBasvuru : 
					GMServiceExecuter.call("BNSPR_TRN4800_GET_APPLICATION_NO", new GMMap()).getString("BASVURU_NO"));



				oMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				
				iMap.put("MUSTERI_NO", (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_musteri.Musteri_Varmi_TCKN(?)}", 
					BnsprType.NUMBER,
					BnsprType.STRING, iMap.getString("TC_KIMLIK_NO")));
				
				if (eksikBelgeBasvuru == null && oMap.getBigDecimal("BASVURU_NO") != null && oMap.getBigDecimal("BASVURU_NO").intValue() > 0 && iMap.getBigDecimal("MUSTERI_NO") != null && iMap.getBigDecimal("MUSTERI_NO").intValue() > 0) {
					String msisdn = (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.telefon(?,?,?) }", BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.STRING, TELEFON_TIP_GSM, BnsprType.STRING, TELEFON_FORMAT_TUM_KOD);
					GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", msisdn).put("CONTENT", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5683)).getString("ERROR_MESSAGE")));
				}

				iMap.put("F_BEYAN_ADRES", "H");
				for(int i = 0; i < iMap.getSize("ADRES_BILGILERI"); i++) {
					
					iMap.put("EV_ADRES", iMap.getString("ADRES_BILGILERI", i, "EV_ADRES"));
					iMap.put("EV_ADR_ILCE_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_ILCE_KOD"));
					iMap.put("EV_ADR_IL_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_IL_KOD"));
					iMap.put("EV_POSTA_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_POSTA_KOD"));
					
					if("H".equals(iMap.getString("ADRES_BILGILERI", i, "F_APS"))) {
						iMap.put("F_BEYAN_ADRES", "E");
						break;
					}
				}
				
				// Transaction kayit at
				GMServiceExecuter.call("BNSPR_TRN4800_SAVE", iMap
					.put("TRX_NO", oMap.getBigDecimal("TRX_NO"))
					.put("BASVURU_NO", oMap.getBigDecimal("BASVURU_NO")));
				musteriBelgeList = getMusteriBelgeList(iMap.getBigDecimal("MUSTERI_NO"));

				// Beyan adres guncelle
				if(iMap.getSize("ADRES_BILGILERI") > 0 || (iMap.containsKey("YATIRIM_EKSTRE") && iMap.get("YATIRIM_EKSTRE") != null)) {
					musteriAdresEmailGuncelle(iMap);
				}

				Session session = DAOSession.getSession("BNSPRDal");
				ClksBonoTalepBasvuru bonoTalepBasvuru = (ClksBonoTalepBasvuru) session.get(ClksBonoTalepBasvuru.class, oMap.getBigDecimal("BASVURU_NO"));
				oMap.put("BASVURU_TARIHI", bonoTalepBasvuru != null ? new SimpleDateFormat("yyyyMMdd").format(bonoTalepBasvuru.getRecDate()) : new SimpleDateFormat("yyyyMMdd").format(new Date()));
			}
			
			oMap.put("BARKOD", DALUtil.callOracleFunction("{? = call pkg_trn4801.barkod_cek(?)}", BnsprType.STRING, 
				BnsprType.NUMBER, oMap.getBigDecimal("BASVURU_NO")));
			
			iMap.put("TALEP_TRX_NO", oMap.get("TRX_NO"));
			iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			iMap.put("BARKOD", oMap.get("BARKOD"));
			iMap.put("ALINDI", "H");
			iMap.put("BELGE_KONTROL", BELGE_KONTROL_GONDERILDI);
			iMap.put("BASVURU_NO", oMap.get("BASVURU_NO"));
			
			String tempDokumanKod;
			int index;
			
			bonoBelgeList = getBonoBelgeList(oMap.getBigDecimal("BASVURU_NO"), "E".equals(iMap.getString("F_BEYAN_ADRES")) ? true : false);
			Iterator<String> iterator = bonoBelgeList.iterator();
			while(iterator.hasNext()) {
				
				tempDokumanKod = iterator.next();

				if(!musteriBelgeList.contains(tempDokumanKod)) {
					
					// Belge zaman asimi kontrol
					if("H".equals((String) DALUtil.callOracleFunction("{ ? = call pkg_trn4801.eksik_belge_mi(?,?,?) }", 
							BnsprType.STRING, 
							BnsprType.NUMBER, oMap.getBigDecimal("BASVURU_NO"),
							BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"),
							BnsprType.STRING, tempDokumanKod))) {
						
						continue;
					}
						
					index = oMap.getSize("BELGE_DETAY");
					oMap.put("BELGE_DETAY", index, "BELGE_ADI", DALUtil.callOracleFunction("{? = call pkg_genel_pr.dokuman_adi(?)}", 
						BnsprType.STRING, BnsprType.STRING, tempDokumanKod));
					oMap.put("BELGE_DETAY", index, "BELGE_KODU", tempDokumanKod);
					oMap.put("BELGE_DETAY", index, "BELGE_KEY_VALUE", 
						getBelgeData(oMap.getBigDecimal("BASVURU_NO"), new BigDecimal(tempDokumanKod)));
								
					GMServiceExecuter.call("BNSPR_TRN4801_SAVE", iMap.put("DOKUMAN_KOD", new BigDecimal(tempDokumanKod)));
				}
			}
			
			if(bonoBelgeList.size() == 0) {
				
				Map<String, List<String>> bonoBelgeMap = getBonoBelgeMap();
				
				if("E".equals(iMap.getString("F_BEYAN_ADRES"))) {
					bonoBelgeMap.put(DOKUMAN_KOD_IKAMETGAH_FATURA, null);
				}

				belgeMapKeySet:
				for(String dokumanKod : bonoBelgeMap.keySet()) {
					
					if(!musteriBelgeList.contains(dokumanKod)) {
						
						if(bonoBelgeMap.get(dokumanKod) != null) {
							for(String kabulBelgeDokumanKod : bonoBelgeMap.get(dokumanKod)) {
								if(musteriBelgeList.contains(kabulBelgeDokumanKod)) {
									continue belgeMapKeySet; // pass
								}
								
								// Belge zaman asimi kontrol
								if("H".equals((String) DALUtil.callOracleFunction("{ ? = call pkg_trn4801.eksik_belge_mi(?,?,?) }", 
										BnsprType.STRING, 
										BnsprType.NUMBER, oMap.getBigDecimal("BASVURU_NO"),
										BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"),
										BnsprType.STRING, kabulBelgeDokumanKod))) {
									
									continue belgeMapKeySet; // pass
								}
							}
						}
						
						// Belge zaman asimi kontrol
						if("H".equals((String) DALUtil.callOracleFunction("{ ? = call pkg_trn4801.eksik_belge_mi(?,?,?) }", 
								BnsprType.STRING, 
								BnsprType.NUMBER, oMap.getBigDecimal("BASVURU_NO"),
								BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"),
								BnsprType.STRING, dokumanKod))) {
							
							continue;
						}
						
						index = oMap.getSize("BELGE_DETAY");
						oMap.put("BELGE_DETAY", index, "BELGE_ADI", DALUtil.callOracleFunction("{? = call pkg_genel_pr.dokuman_adi(?)}", 
							BnsprType.STRING, BnsprType.STRING, dokumanKod));
						oMap.put("BELGE_DETAY", index, "BELGE_KODU", dokumanKod);
						oMap.put("BELGE_DETAY", index, "BELGE_KEY_VALUE", 
							getBelgeData(oMap.getBigDecimal("BASVURU_NO"), new BigDecimal(dokumanKod)));
									
						GMServiceExecuter.call("BNSPR_TRN4801_SAVE", iMap.put("DOKUMAN_KOD", new BigDecimal(dokumanKod)));
					}
				}
			}
			
			
			oMap.putAll(DALUtil.callOracleRefCursorFunction("{ ? = call pkg_trn4801.basvuru_adres_bilgileri(?) }", "MUSTERI_ADRES_BILGILERI", 
					BnsprType.NUMBER, oMap.getBigDecimal("BASVURU_NO")));
			
			if(oMap.getSize("MUSTERI_ADRES_BILGILERI") == 0) {
				oMap.remove("MUSTERI_ADRES_BILGILERI");
			}
			
			String procStr = "{call pkg_trn4801.get_basvuru_ekstre_info (?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[2];
			Object[] outputValues = new Object[4];

			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = oMap.getBigDecimal("BASVURU_NO");

			i = 0;
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "YATIRIM_EKSTRE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "EMAIL";
			GMMap oMap2 = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

			oMap.put("YATIRIM_EKSTRE", oMap2.getString("YATIRIM_EKSTRE"));
			oMap.put("EMAIL", oMap2.getString("EMAIL"));

			if(oMap.get("YATIRIM_EKSTRE") == null) {
				oMap.put("YATIRIM_EKSTRE", getYatirimEkstreBilgi(iMap.getBigDecimal("MUSTERI_NO")));
			}

			return oMap;
			
		} catch(Exception e) {
			logger.error("CLKS_BONO_BASVURU_BELGE_BILGILERI err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_ONAY")
	public static GMMap bnsprClksBonoMusteriBasvuruBelgeOnay(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		BigDecimal hesapNo = null, belgeTxNo = null, belgeKod = null, musteriNo = null; 
		String dysProjectType = "CLKSDYSBONO", dysStatus = "1", trxName = "4801",
			belgeIdentity = null;;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksBonoTalepTx clksBonoTalepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(clksBonoTalepTx == null) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 660).put("P1", "Kay�t bulunamad�."));
			}
			
			String basvuruDurum = getBasvuruDurum(clksBonoTalepTx.getTcKimlikNo());
			
			musteriNo = clksBonoTalepTx.getMusteriNo();
			YatirimEkstre yatirimEkstre = YatirimEkstre.getEnum(clksBonoTalepTx.getYatirimEkstresiKod() == null ? "X" : 
				clksBonoTalepTx.getYatirimEkstresiKod());
			
			String customerPhone = (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.telefon(?,?,?) }", 
				BnsprType.STRING, 
				BnsprType.NUMBER, musteriNo, 
				BnsprType.STRING, TELEFON_TIP_GSM,
				BnsprType.STRING, TELEFON_FORMAT_TUM_KOD);
			
			@SuppressWarnings("unchecked")
			List<ClksBonoTalepBelgeTx> list =  session.createCriteria(ClksBonoTalepBelgeTx.class)
				.add(Restrictions.eq("talepTx", iMap.getBigDecimal("TRX_NO")))
                .addOrder(Order.asc("id.dokumanKod"))
                .list();
			Iterator<ClksBonoTalepBelgeTx> iterBelgeTx = list.iterator();

			@SuppressWarnings("unchecked")
			List<HashMap<?, ?>> belgeMapList = (ArrayList<HashMap<?,?>>) iMap.get("BELGE_LISTESI");
			
			while(iterBelgeTx.hasNext()) {
				
				ClksBonoTalepBelgeTx belgeTx = iterBelgeTx.next();
				int size = belgeMapList.size();
				
				for(int i = 0; i < size; i++) {
					
					if(belgeTx.getId().getDokumanKod().equals(new BigDecimal((String)belgeMapList.get(i).get("BELGE_KODU")))) {
						
						// Uygunluk test skorunu yatirima gonder
						if(!iMap.getBoolean("F_BARKOD_URET") && new BigDecimal(DOKUMAN_KOD_UYGUNLUK_TESTI).equals(belgeTx.getId().getDokumanKod())) {
							BigDecimal skorLimit = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", new GMMap().put("PARAMETRE", "CLKS_BONO_TALEP_SKOR_LIMIT"))
								.getBigDecimal("DEGER");
							BigDecimal skor = new BigDecimal((String) belgeMapList.get(i).get("DATA"));
							
							if(skor.compareTo(skorLimit) < 0) {
								GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5616));
							}
							
							GMServiceExecuter.call("BNSPR_MENKUL_SKOR_KAYDET", new GMMap()
								.put("MUSTERI_NO", musteriNo)
								.put("TARIH", new java.util.Date())
								.put("SKOR", skor));
						}
						
						GMMap inpMap = new GMMap();
						inpMap.put("BELGE_KEY_VALUE", belgeMapList.get(i).get("BELGE_KEY_VALUE"));
						GMServiceExecuter.call(
							"BNSPR_TRN4801_SAVE",
							inpMap.put("DOKUMAN_KOD", belgeTx.getId().getDokumanKod())
								.put("TRX_NO", belgeTx.getId().getTxNo()).put("TC_KIMLIK_NO", belgeTx.getTcKimlikNo())
								.put("ALINDI", (String) belgeMapList.get(i).get("F_BELGE_TESLIM")));
						
						if(!iterBelgeTx.hasNext()) {
							
							belgeTxNo = belgeTx.getId().getTxNo();
							belgeIdentity = belgeTx.getTcKimlikNo();
							belgeKod = belgeTx.getId().getDokumanKod();
							
							GMServiceExecuter.call("BNSPR_CLKS_BONO_MUSTERI_GRUP_KOD_AT", new GMMap().put("MUSTERI_NO", musteriNo));
							
							GMServiceExecuter.call("DYS_SAVE_NEW_BARCODE_FOR_CLKS", new GMMap()
								.put("BARCODE", belgeTx.getBarkod())
								.put("PROJECT_TYPE", dysProjectType)
								.put("REFERENCE", belgeTx.getBasvuruNo())
								.put("STATUS", dysStatus));
						}
						
						belgeMapList.remove(i);
						break;
					}
				}
			}
			
			if(iMap.getBoolean("F_BARKOD_URET")) {

				session.saveOrUpdate(clksBonoTalepTx);
				session.flush();
				
				// Belge Transaction
				GMServiceExecuter.call("BNSPR_TRN4801_SAVE", new GMMap().put("DOKUMAN_KOD", belgeKod)
					.put("TRX_NO", belgeTxNo).put("TC_KIMLIK_NO", belgeIdentity).put("TRX_NAME", trxName));
				
				return oMap;
			}
			
			GMMap hesapKontrolMap = GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_LIST", new GMMap().put("MUSTERI_NO", musteriNo));

			BigDecimal hesapKontrolNo = new BigDecimal(0);
			for(int i = 0; i < hesapKontrolMap.getSize("RESULTS"); i++) {
				
				if("TRY".equals(hesapKontrolMap.getString("RESULTS", i, "DOVIZ_KODU"))  && "A".equals(hesapKontrolMap.getString("RESULTS", i, "DURUM"))) {
					BigDecimal tempHesap =  hesapKontrolMap.getBigDecimal("RESULTS", i, "HESAP_NO");
					
					if (hesapKontrolNo.compareTo(new BigDecimal(0)) == 0) {
						hesapKontrolNo = tempHesap;
						continue;
					} else {
						if (hesapKontrolNo.compareTo(tempHesap) == 1) {
							hesapKontrolNo = tempHesap;
						}
					}
				}
			}	
			
			TransactionDao<CustomerAcquisition> dao = new DalCustomerAcquisitionDao();
			CustomerAcquisition customerAcquisition = dao.get(iMap.getBigDecimal("TRX_NO"));
			
			CommissionDao commissionDao = new GMCacheCommissionDao();
			List<CommissionRecord> commissionList = commissionDao.getByCommissionCategory(customerAcquisition.commissionCategory());
			if(commissionList != null && commissionList.size() > 0) {
				customerAcquisition.setCommissionAmount(commissionList.get(0).getCommissionAmount());
				customerAcquisition.setCommissionCurrency(commissionList.get(0).getCommissionCurrency());
			}
			
			logger.info("Basvuru Durum:" + basvuruDurum);
			if("B".equals(basvuruDurum) && customerAcquisition.commissionAmount() != null) {
				dao.saveCommission(customerAcquisition);
			}
			
			// Kontakt ise gercege cevirelim aksi takdirde hesap kontrolu yaparak, hesap numarasi donelim.
			if("K".equals((String) DALUtil.callOracleFunction("{? = call pkg_musteri.musteriMi_kontaktMi(?)}", 
					BnsprType.STRING,
					BnsprType.NUMBER, musteriNo))) {
				
				// Kontakt -> Gercek
				kontaktMusteriYarat(new GMMap()
					.put("MUSTERI_NO", musteriNo)
					.put("TC_KIMLIK_NO", clksBonoTalepTx.getTcKimlikNo()));
				
				// Vadesiz hesap acilisi
				if (hesapKontrolNo.compareTo(new BigDecimal(0)) == 0) {
					GMMap hesapMap = GMServiceExecuter.call("BNSPR_CURRENT_ACCOUNTS_CREATE_DRAWING_ACCOUNT", new GMMap()
						.put("MUSTERI_NO", musteriNo)
						.put("DOVIZ_KODU", "TRY")
						.put("RUMUZ", (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.kisa_ad(?) }", BnsprType.STRING, BnsprType.NUMBER, musteriNo))
						.put("EKSTRE_BASIM_KODU", "X"));
					
					hesapNo = hesapMap.getBigDecimal("HESAP_NUMARASI");
					
					GMMap msgMap = new GMMap();
					msgMap.put("MESSAGE_NO", BigDecimal.valueOf(CREATE_DRAWING_ACCOUNT_MESSAGE_NO));
					msgMap.put("MSISDN", customerPhone);
					msgMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
					msgMap.put("MUSTERI_NO", musteriNo);
					sendSMS(msgMap);
					
				}else {
					hesapNo = hesapKontrolNo;
				}
			} 
			
			// Musteri
			else {
				
				if (hesapKontrolNo.compareTo(new BigDecimal(0)) == 0) {
					
					// Vadesiz hesap acilisi
					GMMap hMap = GMServiceExecuter.call("BNSPR_CURRENT_ACCOUNTS_CREATE_DRAWING_ACCOUNT", new GMMap()
						.put("MUSTERI_NO", musteriNo)
						.put("DOVIZ_KODU", "TRY")
						.put("RUMUZ", (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.kisa_ad(?) }", BnsprType.STRING, BnsprType.NUMBER, musteriNo))
						.put("EKSTRE_BASIM_KODU", "X"));
					
					hesapNo = hMap.getBigDecimal("HESAP_NUMARASI");
					
					GMMap msgMap = new GMMap();
					msgMap.put("MESSAGE_NO", BigDecimal.valueOf(CREATE_DRAWING_ACCOUNT_MESSAGE_NO));
					msgMap.put("MSISDN", customerPhone);
					msgMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
					msgMap.put("MUSTERI_NO", musteriNo);
					sendSMS(msgMap);
					
				} else {
					hesapNo = hesapKontrolNo;
				}
				
			}
			
			oMap.put("HESAP_NO", hesapNo);
			oMap.put("MUSTERI_NO", musteriNo);
			
			try {
				oMap.put("IBAN", (String) DALUtil.callOneParameterFunction("{? = call pkg_hesap.iban(?)}", Types.VARCHAR, oMap.getString("HESAP_NO")));
//				GMServiceExecuter.call("BNSPR_IBAN_SMS_GONDER", new GMMap()
//					.put("IBAN", oMap.getString("IBAN"))
//					.put("HESAP_NO", hesapNo)
//					.put("MUSTERI_NO", musteriNo));
			} catch (Exception e) {
				logger.error("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_ONAY > IBAN err: ", e);
			}
			
			clksBonoTalepTx.setHesapNo(hesapNo);
			session.saveOrUpdate(clksBonoTalepTx);
			session.flush();
			
			// Belge Transaction
			GMServiceExecuter.call("BNSPR_TRN4801_SAVE", new GMMap().put("DOKUMAN_KOD", belgeKod)
				.put("TRX_NO", belgeTxNo).put("TC_KIMLIK_NO", belgeIdentity).put("TRX_NAME", trxName));
			
			if(!YatirimEkstre.SECINIZ.equals(yatirimEkstre)) {
				GMServiceExecuter.call("BNSPR_TRN1337_SAVE_ONAYSIZ", new GMMap()
					.put("MUSTERI_NO", musteriNo)
					.put("MUSTERI_TIPI", CustomerType.PERSONAL.toString())
					.put("DMUSTERI_TIPI", "GENEL MUSTERI")
					.put("YATIRIM_EXTRESI_GONDERILSINMI", yatirimEkstre.toString())
					.put("DYATIRIM_EXTRESI_GONDERILSINMI", yatirimEkstre.getAciklama()));
			}
			
			GMServiceExecuter.call("BNSPR_CUSTOMER_SET_GROUP_PERSONAL_DATA_PERMISSION",
				new GMMap().put("CUSTOMER_NO", musteriNo).put("STATUS", "E").put("PRODUCT_CODE", PRODUCT_CODE)
					.put("IS_AUTHORIZED_TRANSACTION", "E"));
			
			return oMap;
		
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_ONAY err: ", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kanal�ndan bono ili�kisi kurulmu� m��teriyi �r�n ve kanal ile ili�kili m��teri grubuna dahil eder.
	 * 
	 * @param iMap {MUSTERI_NO}		M��teri numaras�
	 * @return
	 * 
	 * @throws GMRuntimeException M��teri gurubuna ekleme i�lemi ba�ar�s�z olmas� durumunda f�rlat�rl�r.
	 */
	@GraymoundService("BNSPR_CLKS_BONO_MUSTERI_GRUP_KOD_AT")
	public static GMMap bnsprClksBonoMusteriGrupKodAt(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {
			
			DALUtil.callOracleProcedure("{call pkg_musteri_ek.musteri_grup_eklecikar(?,?,?,?)}",
				new Object[]{
					BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
					BnsprType.STRING, MUSTERI_GRUP_KOD,
					BnsprType.STRING, null,
					BnsprType.STRING, "E"
			}, new Object[]{});
			
			return oMap.put("RESPONSE", Response.SUCCESS.getValue());
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_BONO_MUSTERI_GRUP_KOD_AT err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT Bono belge surecinde belge kontrolu sirasinda cagirilir, belgenin kontrol statulerini gunceller. 
	 * Eger basvurunun durumu EVRAKSIZ olarak kalir ise musteriye SMS gonderimi yapar.
	 * 
	 * @param iMap
	 * @return
	 * 
	 * @throws GMRuntimeException 
	 */
	@GraymoundService("BNSPR_CLKS_BONO_BELGE_GUNCELLE")
	public static GMMap bnsprClksBonoBelgeGuncelle(GMMap iMap) {

		GMMap oMap = new GMMap();
		String belgeListesi = "BELGE_LISTESI", trxName = "4801";

		try {

			GMMap saveMap = new GMMap();
			saveMap.put("TRX_NO",
				GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			for(int i = 0; i < iMap.getSize(belgeListesi); i++) {

				saveMap.put("BASVURU_NO", iMap.get(belgeListesi, i, "BASVURU_NO"));
				saveMap.put("TC_KIMLIK_NO", iMap.get(belgeListesi, i, "TC_KIMLIK_NO"));
				saveMap.put("DOKUMAN_KOD", iMap.get(belgeListesi, i, "DOKUMAN_KOD"));
				saveMap.put("ALINDI", iMap.get(belgeListesi, i, "ALINDI"));
				saveMap.put("BARKOD", iMap.get(belgeListesi, i, "BARKOD"));
				saveMap.put("BELGE_KONTROL", iMap.get(belgeListesi, i, "BELGE_KONTROL"));
				saveMap.put("BELGE_KONTROL_ALT_STATU", iMap.get(belgeListesi, i, "BELGE_KONTROL_ALT_STATU"));
				saveMap.put("BELGE_KONTROL_ACIKLAMA", iMap.get(belgeListesi, i, "BELGE_KONTROL_ACIKLAMA"));
				saveMap.put("GELIS_TARIHI", iMap.get(belgeListesi, i, "GELIS_TARIHI"));
				saveMap.put("TALEP_TRX_NO", iMap.get(belgeListesi, i, "TALEP_TX"));
				saveMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE_ID",
					iMap.get(belgeListesi, i, "ISLEMIN_YAPILDI_SUBE_ID"));
				saveMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI",
					iMap.get(belgeListesi, i, "ISLEMI_YAPAN_KULLANICI"));
				saveMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL",
					iMap.get(belgeListesi, i, "ISLEMI_YAPAN_KULLANICI_SICIL"));

				if(i == iMap.getSize(belgeListesi) - 1) {
					saveMap.put("F_IPAZ", iMap.getBoolean("F_IPAZ"));
					saveMap.put("F_KVKK", iMap.getBoolean("F_KVKK"));
					saveMap.put("TRX_NAME", trxName);
				}

				GMServiceExecuter.call("BNSPR_TRN4801_SAVE", saveMap);
			}

			Session session = DAOSession.getSession("BNSPRDal");

			ClksBonoTalepTx talepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class,
				saveMap.getBigDecimal("TALEP_TRX_NO"));
			ClksBonoTalepBasvuru basvuru = (ClksBonoTalepBasvuru) session.get(ClksBonoTalepBasvuru.class,
				iMap.getBigDecimal("REFERANS"));

			if(iMap.getBoolean("F_IPAZ")) {
				GMServiceExecuter.call("BNSPR_CUSTOMER_UPDATE_MARKETING_PERMISSION",
					iMap.put("TCKN", talepTx.getTcKimlikNo()).put("CUSTOMER_NO", talepTx.getMusteriNo()));
			}

			if(iMap.getBoolean("F_KVKK")) {
				GMServiceExecuter.call("BNSPR_CUSTOMER_SET_GROUP_PERSONAL_DATA_PERMISSION",
					new GMMap().put("CUSTOMER_NO", talepTx.getMusteriNo()).put("STATUS", "E")
						.put("IS_AUTHORIZED_TRANSACTION", "E"));
			}

			if(BasvuruDurum.EVRAKSIZ.toString().equals(basvuru.getDurumKodu())) {

				String msisdn = (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.telefon(?,?,?) }",
					BnsprType.STRING, BnsprType.NUMBER, talepTx.getMusteriNo(), BnsprType.STRING, TELEFON_TIP_GSM,
					BnsprType.STRING, TELEFON_FORMAT_TUM_KOD);

				String content = GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE",
					new GMMap().put("MESSAGE_NO", 5665)).getString("ERROR_MESSAGE");

				try {
					GMServiceExecuter.call(
						"BNSPR_SMS_SEND_SMS_ASYNC",
						new GMMap().put("MSISDN", msisdn).put("CONTENT", content)
							.put("MUSTERI_NO", talepTx.getMusteriNo()).put("TRX_NO", saveMap.getBigDecimal("TRX_NO"))
							.put("MESSAGE_TYPE", 1));

				} catch(Exception e) { // log and skip
					logger.error("BNSPR_CLKS_BONO_BELGE_GUNCELLE > BNSPR_SMS_SEND_SMS_ASYNC err:", e);
				}
			}

			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_BONO_BELGE_GUNCELLE err: ", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Belge surecinde eski barkodlu belgelerin islenebilmesi icin yeni barkod uretir.
	 * 
	 * @param iMap
	 * @return
	 * 
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_CLKS_BONO_BARKOD_URET")
	public static GMMap bnsprClksBonoBarkodUret(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String barkod = null, tcKimlikNo;
		
		try {

			barkod = (String) DALUtil.callOracleFunction("{? = call pkg_trn4801.hobim_barkod_cek(?,?)}", BnsprType.STRING,
				BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"), BnsprType.NUMBER, iMap.getBigDecimal("REFERANS"));
			
			if(barkod != null) {
				oMap.put("BARCODE", barkod);
			} else {
				
				Session session = DAOSession.getSession("BNSPRDal");
			
				if(iMap.get("TC_KIMLIK_NO") == null || iMap.getString("TC_KIMLIK_NO").isEmpty()) {
					ClksBonoTalepTx talepTx = (ClksBonoTalepTx) session.createCriteria(ClksBonoTalepTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("REFERANS"))).addOrder(Order.desc("txNo")).setMaxResults(1).uniqueResult();
					tcKimlikNo = talepTx.getTcKimlikNo();
				} else {
					tcKimlikNo = iMap.getString("TC_KIMLIK_NO");
				}
				
				oMap.putAll(GMServiceExecuter.call("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_BILGILERI", new GMMap().put("TC_KIMLIK_NO", tcKimlikNo)));
				oMap.put("BARCODE", oMap.get("BARKOD"));
				
				if(!oMap.containsKey("BELGE_DETAY") || oMap.getSize("BELGE_DETAY") == 0) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1599));
				}
				
				GMMap belgeMap = new GMMap();
				for(int i = 0; i < oMap.getSize("BELGE_DETAY"); i++) {
					belgeMap.put("BELGE_LISTESI", i, "BELGE_KODU", oMap.getString("BELGE_DETAY", i, "BELGE_KODU"));
					belgeMap.put("BELGE_LISTESI", i, "F_BELGE_TESLIM", "E");
				}
				
				GMServiceExecuter.call("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_ONAY", 
					belgeMap.put("TRX_NO", oMap.getBigDecimal("TRX_NO")).put("F_BARKOD_URET", true));
			}
		
			return oMap;
		
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_BONO_BARKOD_URET err: ", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_BONO_MUSTERI_BELGELERI")
	public static GMMap bnsprClksBonoMusteriBelgeleri(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			BigDecimal musteriNo = (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_musteri.MusteriNoVarMi(?)}",
				BnsprType.NUMBER, BnsprType.STRING, iMap.getString("MUSTERI_NO"));

			if(BigDecimal.ZERO.equals(musteriNo)) {
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ",
					new GMMap().put("HATA_NO", 1456).put("P1", iMap.getString("MUSTERI_NO")));
			}

			oMap.putAll(DALUtil.callOracleRefCursorFunction("{ ? = call pkg_trn4801.musteri_belge_durumlari(?) }",
				"BELGELER", BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO")));

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_BONO_MUSTERI_BELGELERI err: ", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * TBD
	 * 
	 * @return
	 */
	private static Map<String, List<String>> getBonoBelgeMap() {
		
		Map<String, List<String>> belgeMap = new HashMap<String, List<String>>();
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<GnlParamText> list =  session.createCriteria(GnlParamText.class)
            .add(Restrictions.eq("kod", "CLKS_BELGE_BONO_TALEP"))
            .addOrder(Order.asc("siraNo"))
            .list();
		Iterator<GnlParamText> iterator = list.iterator();
		
		while(iterator.hasNext()) {
			
			GnlParamText paramText = iterator.next();
			
			if(!("H".equals(paramText.getKey2()) && paramText.getKey3() == null)) {
				if("H".equals(paramText.getKey2())) {
					
					if(!belgeMap.containsKey(paramText.getKey3())) {
						belgeMap.put(paramText.getKey3(), new ArrayList<String>(Arrays.asList(paramText.getKey1())));
					} else {
						belgeMap.get(paramText.getKey3()).add(paramText.getKey1());
					}
					
				} else if(!belgeMap.containsKey(paramText.getKey1())) {
					belgeMap.put(paramText.getKey1(), null);
				}
			}
		}

		return belgeMap;
	}
	
	/**
	 * TBD
	 * 
	 * @param basvuruNo
	 * @param ikametgahFatura
	 * @return
	 */
	private static List<String> getBonoBelgeList(BigDecimal basvuruNo, boolean ikametgahFatura) {
		
		List<String> belgeList = new ArrayList<String>();
		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<ClksBonoTalepBelge> list = session.createCriteria(ClksBonoTalepBelge.class)
			.add(Restrictions.eq("id.basvuruNo", basvuruNo))
			.list();
		
		Iterator<ClksBonoTalepBelge> iterator = list.iterator();
		
		while(iterator.hasNext()) {
			belgeList.add(iterator.next().getId().getDokumanKod().toString());
		}
		
		/*if(!belgeList.contains(DOKUMAN_KOD_IKAMETGAH_FATURA) && ikametgahFatura) {
			belgeList.add(DOKUMAN_KOD_IKAMETGAH_FATURA);
		}*/

		return belgeList;
	}
	
	/**
	 * TBD
	 * 
	 * @param musteriNo
	 * @return
	 */
	private static List<String> getMusteriBelgeList(BigDecimal musteriNo) {
		
		List<String> belgeList = new ArrayList<String>();
		
		GMMap map = GMServiceExecuter.call("BNSPR_TRN1040_CREATE_TRX_NO", new GMMap().put("MUSTERI_NO", musteriNo).put("DURUM_KODU", "A"));
		map.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", map));
		
		for(int i = 0; i < map.getSize("CBS_MUSTERI_BASVURU_DOKUMAN"); i++) {
			
			if("1".equals(map.getString("CBS_MUSTERI_BASVURU_DOKUMAN", i, "ALINDI_KUTUSU_F"))) {
				belgeList.add(map.getString("CBS_MUSTERI_BASVURU_DOKUMAN", i, "DOKUMAN_KODU"));
			}
		}
		
		return belgeList;
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 * @throws ParseException
	 */
	private static Map<? extends Object, ? extends Object> mapKeys(GMMap iMap) throws ParseException {
		
		/*
		 * + "KPS_BILGILERI[,,,,,ES_TCKN,,,,,,,,,,,KAYIP_KIMLIK_SIRA_NO,KAYIP_KIMLIK_SERI_NO,,,,],"
			+ "ADRES_BILGILERI[EV_ADRES,EV_ADR_IL_KOD,EV_ADR_ILCE_KOD,EV_POSTAKOD],"
			+ "TC_KIMLIK_NO,POSTA_CEKI_HESAP_NUMARASI,CEP_TEL_KOD,CEP_TEL_NO,EV_TEL_KOD,EV_TEL_NO,ANNE_KIZLIK_SOYADI,F_KPS_YAPILDI,F_APS_YAPILDI,F_KIMLIK_BILGILERI_UYUMLU,F_ADRES_BILGILERI_UYUMLU",
		 * 
		 */
		
		GMMap oMap = new GMMap();

		oMap.putAll(iMap);
		oMap.put("KANAL_KODU", 7);
		oMap.put("KANAL_ALT_KODU", iMap.get("KANAL_ALT_KOD"));
		oMap.put("SERI_NO", iMap.get("KPS_BILGILERI", 0, "KIMLIK_SERI_NO"));
		oMap.put("SIRA_NO", iMap.get("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO"));
		iMap.put("SIRA_NO", "0".equals(iMap.getString("SIRA_NO")) ? "" : iMap.getString("SIRA_NO"));
		oMap.put("CINSIYET", iMap.get("KPS_BILGILERI", 0, "CINSIYET"));
		oMap.put("CINSIYET_KOD", iMap.get("KPS_BILGILERI", 0, "CINSIYET"));
		oMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
		oMap.put("ISIM", iMap.get("KPS_BILGILERI", 0, "ADI"));
		oMap.put("SOYADI", iMap.get("KPS_BILGILERI", 0, "SOYADI"));
		oMap.put("IKINCI_ISIM", iMap.get("KPS_BILGILERI", 0, "IKINCI_ADI"));
		oMap.put("UYRUK_KOD", "TR");
		oMap.put("MEDENI_HAL_KOD", iMap.get("KPS_BILGILERI", 0, "MEDENI_HAL"));
		oMap.put("AILE_SIRA_NO",iMap.get("KPS_BILGILERI", 0, "NUFUS_AILE_SIRA_NO"));
		oMap.put("CILT_NO", iMap.get("KPS_BILGILERI", 0, "NUFUS_CILT_NO"));
		oMap.put("SIRA_NO", iMap.get("KPS_BILGILERI", 0, "NUFUS_SIRA_NO"));
		oMap.put("KIZLIK_SOYADI", iMap.get("ONCEKI_SOYADI"));
		oMap.put("MESLEK_KOD", iMap.get("MESLEK"));
		oMap.put("EGITIM_KOD", iMap.get("OGRENIM_DURUMU"));
		oMap.put("VERILDIGI_YER", iMap.get("KPS_BILGILERI", 0, "NUFUS_VERILDIGI_YER"));
		oMap.put("VERILDIGI_TARIH", iMap.get("KPS_BILGILERI", 0, "NUFUS_VERILIS_TARIHI"));
		oMap.put("NUF_VERILIS_NEDENI", iMap.get("KPS_BILGILERI", 0, "NUFUS_VERILIS_NEDENI"));
		oMap.put("KIMLIK_KAYIT_NO", iMap.get("KPS_BILGILERI", 0, "KIMLIK_KAYIT_NO"));
		oMap.put("MAHALLE_KOY", iMap.get("KPS_BILGILERI", 0, "MAHALLE_KOY"));
		oMap.put("IL_KOD", iMap.get("KPS_BILGILERI", 0, "NUFUS_IL_KOD"));
		oMap.put("ILCE_KOD", iMap.get("KPS_BILGILERI", 0, "NUFUS_ILCE_KOD"));
		oMap.put("DOGUM_YERI", iMap.get("KPS_BILGILERI", 0, "DOGUM_YERI"));
		oMap.put("DOGUM_TARIHI", iMap.get("KPS_BILGILERI", 0, "DOGUM_TARIHI"));
		oMap.put("BABA_ADI", iMap.get("KPS_BILGILERI", 0, "BABA_ADI"));
		oMap.put("ANNE_ADI", iMap.get("KPS_BILGILERI", 0, "ANNE_ADI"));
		
		if(iMap.get("KPS_BILGILERI", 0, "KIMLIK_SERI_NO") != null
			&& iMap.get("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO") != null) {
			iMap.put("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO", "0".equals(iMap.getString("KPS_BILGILERI", 0,
				"KIMLIK_SIRA_NO")) ? "" : iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO"));
		} else if(iMap.get("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO") == null) {
			iMap.put("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO", "");
		}
		
		oMap.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SERI_NO").concat(
			iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO").toString()));

		oMap.remove("KPS_BILGILERI");
		oMap.remove("ISYERI_VE_KULLANICI_BILGILERI");
		
		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 */
	private static Map<? extends Object, ? extends Object> kontaktMusteriYaratVeyaGuncelle(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {

			iMap.put("TRX_NO", iMap.getBigDecimal("MUSTERI_TRX_NO"));

			Session session = DAOSession.getSession("BNSPRDal");
			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"));
			restrictions.put("durumKodu", "A");

			@SuppressWarnings("unchecked")
			List<GnlMusteri> records = session.createCriteria(GnlMusteri.class).add(Restrictions.allEq(restrictions)).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).list();
			Iterator<GnlMusteri> iterator = records.iterator();

			if (iterator.hasNext()) {
				
				GnlMusteri gnlMusteri = iterator.next();
				GMMap rMap = new GMMap(kontaktMusteriGuncelle(iMap.put("MUSTERI_NO", gnlMusteri.getMusteriNo())));
				oMap.put("MUSTERI_NO", gnlMusteri.getMusteriNo());
				oMap.put("MUSTERI_TRX_NO", rMap.getBigDecimal("MUSTERI_TRX_NO"));
			}

			else {
				oMap = new GMMap(kontaktMusteriYarat(iMap));
				oMap.put("MUSTERI_NO", (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_musteri.Musteri_Varmi_TCKN(?)}", 
					BnsprType.NUMBER,
					BnsprType.STRING, iMap.getString("TC_KIMLIK_NO")));
			}
		}
		catch (Exception e) {
			logger.error("BondServices.kontaktMusteriYaratVeyaGuncelle err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 */
	private static Map<? extends Object, ? extends Object> musteriAdresEmailGuncelle(GMMap iMap) {
		
		GMMap kontakt = new GMMap();
		try {
			kontakt.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRN1040_CREATE_TRX_NO", new GMMap().put("MUSTERI_NO", iMap.getString("MUSTERI_NO")).put("DURUM_KODU", "A")).getBigDecimal("TRX_NO"));
			kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", new GMMap().put("TRX_NO", kontakt.getBigDecimal("TRX_NO"))));
			
			if (kontakt.getBoolean("F_SAHTE")) { kontakt.put("F_SAHTE", "1"); }
			else { kontakt.put("F_SAHTE", "0"); }
			
			if (kontakt.getBoolean("F_MUSTERIYE_CEVRILEBILIR")) { kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "1"); }
			else { kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "0"); }
			
			int addressListSize = iMap.getSize("ADRES_BILGILERI");
			List<Map<String, Object>> addressList = new ArrayList<Map<String, Object>>();
			for(int i=0; i<iMap.getSize("ADRES_BILGILERI"); i++) {
				if(iMap.getString("ADRES_BILGILERI", i, "EV_ADRES") != null && !iMap.getString("ADRES_BILGILERI", i, "EV_ADRES").isEmpty()) {
					Map<String, Object> rowData = new HashMap<String, Object>();
					rowData.put("ADRES_KOD", addressListSize == 1 ? "E" : "E".equals(iMap.getString("ADRES_BILGILERI", i, "F_APS")) ? "E1" : "E");
					rowData.put("ADRES", iMap.getString("ADRES_BILGILERI", i, "EV_ADRES"));
					rowData.put("ADRES_IL_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_IL_KOD"));
					rowData.put("ADRES_ILCE_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_ILCE_KOD"));
					rowData.put("ULKE_KOD", "TR");
					rowData.put("POSTA_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_POSTAKOD"));
					rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
					rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_EV")));
					addressList.add(rowData);
				}
			}
			
			if(!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")){
				for (int row = 0; row < addressList.size(); row++) {
					Map<String, Object> adrMap = addressList.get(row);
					if ("E".equals(adrMap.get("ADRES_KOD"))) {
						adrMap.put("EXTRE_ADRES_KOD_F", "E");
					}
					addressList.set(row, adrMap);
				}
			}
			
			if(addressList.size() > 0) {
				kontakt.put("ADRES_LIST", addressList);
			}
			
			YatirimEkstre yatirimEkstre;
			try {
				yatirimEkstre = YatirimEkstre.getEnum(iMap.getString("YATIRIM_EKSTRE"));
			} catch(IllegalArgumentException e) {
				yatirimEkstre = YatirimEkstre.SECINIZ;
			}
			
			if(YatirimEkstre.EPOSTA.equals(yatirimEkstre) && !iMap.getString("EMAIL").isEmpty()) {
				kontakt.put("EMAIL_KISISEL", iMap.getString("EMAIL"));
			}
			
			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
	
			return GMServiceExecuter.call("BNSPR_TRN10041_SAVE", kontakt);
			
		} catch (Exception e) {
			logger.error("BondServices.musteriAdresGuncelle err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 */
	private static Map<? extends Object, ? extends Object> kontaktMusteriGuncelle(GMMap iMap) {
		
		try {
			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI").trim());
			}
	
			GMMap kontakt = new GMMap();
			
			kontakt.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRN1040_CREATE_TRX_NO", new GMMap().put("MUSTERI_NO", iMap.getString("MUSTERI_NO")).put("DURUM_KODU", "A")).getBigDecimal("TRX_NO"));
			kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", new GMMap().put("TRX_NO", kontakt.getBigDecimal("TRX_NO"))));
			
			kontakt.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
			kontakt.put("MUSTERI_KONTAKT", "K");
			kontakt.put("MUSTERI_TIPI_KOD", "G");
			kontakt.put("BAGLI_KANAL_GRUBU", iMap.getString("KANAL_KODU"));
			kontakt.put("KANAL_KODU", iMap.getString("KANAL_ALT_KODU"));
			kontakt.put("MUSTERI_SEGMENTI", "N");			
			kontakt.put("YERLESIM_KOD", "I");
			kontakt.put("DK_GRUP_KOD", new BigDecimal("1042"));
			kontakt.put("PROFIL_KOD", "1");
			kontakt.put("BOLUM_KODU", new BigDecimal("444"));
			kontakt.put("KAZANIM_KANALI", iMap.getString("KANAL_KODU"));
			kontakt.put("KAZANIM_URUNU", KAZANIM_URUNU);
			kontakt.put("HESAP_UCRETI_F", "H");
			kontakt.put("YATIRIM_EKSTRESI", "H");
			kontakt.put("PORTFOY_KOD", PORTFOY_KOD);
			kontakt.put("TCKNO_IN", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("TC_KIMLIK_NO", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("ISIM", iMap.getString("ISIM"));
			kontakt.put("IKINCI_ISIM", iMap.getString("IKINCI_ISIM"));
			kontakt.put("SOYADI", iMap.getString("SOYADI"));
			kontakt.put("KISA_AD", iMap.getString("ISIM") + " " + (iMap.getString("IKINCI_ISIM") == null ? "" : iMap.getString("IKINCI_ISIM") + " ") + iMap.getString("SOYADI"));
			kontakt.put("UYRUK_KOD", "TR");
			kontakt.put("DOGUM_TARIHI", !"".equals(iMap.getString("DOGUM_TARIHI")) ? iMap.getDate("DOGUM_TARIHI") : null);
			kontakt.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
			kontakt.put("BABA_ADI", iMap.getString("BABA_ADI"));
			kontakt.put("ANNE_ADI", iMap.getString("ANNE_ADI"));
			kontakt.put("CINSIYET_KOD", iMap.getString("CINSIYET_KOD"));
			kontakt.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			kontakt.put("MEDENI_HAL_KOD", iMap.getString("MEDENI_HAL_KOD"));
			kontakt.put("AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
			kontakt.put("CILT_NO", iMap.getString("CILT_NO"));
			kontakt.put("SIRA_NO", iMap.getString("SIRA_NO"));
			kontakt.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("NUFUS_CUZDANI_SERI_NO"));
			kontakt.put("KIZLIK_SOYADI", iMap.getString("KIZLIK_SOYADI"));
			kontakt.put("MESLEK_KOD", iMap.getString("MESLEK_KOD"));
			kontakt.put("EGITIM_KOD", iMap.getString("EGITIM_KOD"));
			kontakt.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			kontakt.put("F_ISTEGE_BAGLI_SIGORTALI", iMap.getString("SIGORTALI_MI"));
			kontakt.put("UNVAN_KOD", iMap.getString("UNVANI"));
			kontakt.put("IL_KOD", iMap.getString("IL_KOD"));
			kontakt.put("ILCE_KOD", iMap.getString("ILCE_KOD"));
			kontakt.put("MAHALLE_KOY", iMap.getString("MAHALLE_KOY"));
			kontakt.put("ADRES_NO", iMap.getBigDecimal("ADRES_NO"));
			kontakt.put("BUCAK", iMap.getString("BUCAK"));
			kontakt.put("BUCAK_KOD", iMap.getBigDecimal("BUCAK_KOD"));
			kontakt.put("CSBM", iMap.getString("CSBM"));
			kontakt.put("DIS_KAPI_NO", iMap.getString("DIS_KAPI_NO"));
			kontakt.put("IC_KAPI_NO", iMap.getString("IC_KAPI_NO"));
			kontakt.put("IL", iMap.getString("IL"));
			kontakt.put("ILCE", iMap.getString("ILCE"));
			kontakt.put("ILCE_KODU", iMap.getBigDecimal("ILCE_KODU"));
			kontakt.put("IL_KODU", iMap.getBigDecimal("IL_KODU"));
			kontakt.put("KOY", iMap.getString("KOY"));
			kontakt.put("KOY_KAYIT_NO", iMap.getBigDecimal("KOY_KAYIT_NO"));
			kontakt.put("KOY_KOD", iMap.getBigDecimal("KOY_KOD"));
			kontakt.put("MAHALLE", iMap.getString("MAHALLE"));
			kontakt.put("MAHALLE_KOD", iMap.getBigDecimal("MAHALLE_KOD"));
			kontakt.put("YABANCI_ADRES", iMap.getString("YABANCI_ADRES"));
			kontakt.put("YABANCI_SEHIR", iMap.getString("YABANCI_SEHIR"));
			kontakt.put("YABANCI_ULKE", iMap.getString("YABANCI_ULKE"));
			kontakt.put("YABANCI_ULKE_KOD", iMap.getString("YABANCI_ULKE_KOD"));
			kontakt.put("NUF_VERILIS_NEDENI", iMap.getString("NUF_VERILIS_NEDENI"));
			kontakt.put("VERILDIGI_YER", iMap.getString("VERILDIGI_YER"));
			kontakt.put("VERILDIGI_TARIH", !"".equals(iMap.getString("VERILDIGI_TARIH")) ? iMap.getDate("VERILDIGI_TARIH") : null);
			kontakt.put("DURUM_KODU", "A");		
			
			if (iMap.getString("NUFUS_CUZDANI_SERI_NO") != null && !iMap.getString("NUFUS_CUZDANI_SERI_NO").isEmpty()) {
				kontakt.put("F_NUF", "E");
			}
			
			if ("E".equals(iMap.getString("F_KPS_YAPILDI"))) {
				kontakt.put("TCKNO_OUT", iMap.getBigDecimal("TC_KIMLIK_NO"));
			}
	
			int addressListSize = iMap.getSize("ADRES_BILGILERI");
			List<Map<String, Object>> addressList = new ArrayList<Map<String, Object>>();
			for(int i=0; i<iMap.getSize("ADRES_BILGILERI"); i++) {
				if(iMap.getString("ADRES_BILGILERI", i, "EV_ADRES") != null && !iMap.getString("ADRES_BILGILERI", i, "EV_ADRES").isEmpty()) {
					Map<String, Object> rowData = new HashMap<String, Object>();
					rowData.put("ADRES_KOD", addressListSize == 1 ? "E" : "E".equals(iMap.getString("ADRES_BILGILERI", i, "F_APS")) ? "E1" : "E");
					rowData.put("ADRES", iMap.getString("ADRES_BILGILERI", i, "EV_ADRES"));
					rowData.put("ADRES_IL_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_IL_KOD"));
					rowData.put("ADRES_ILCE_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_ILCE_KOD"));
					rowData.put("ULKE_KOD", "TR");
					rowData.put("POSTA_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_POSTAKOD"));
					rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
					rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_EV")));
					addressList.add(rowData);
				}
			}
			
			if(!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")){
				for (int row = 0; row < addressList.size(); row++) {
					Map<String, Object> adrMap = addressList.get(row);
					if ("E".equals(adrMap.get("ADRES_KOD"))) {
						adrMap.put("EXTRE_ADRES_KOD_F", "E");
					}
					addressList.set(row, adrMap);
				}
			}
			
			kontakt.put("ADRES_LIST", addressList);
	
			List<Map<String, Object>> telefonList = new ArrayList<Map<String, Object>>();
			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				Map<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "1");
				rowData.put("ALAN_KOD", iMap.getString("EV_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("EV_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				rowData.put("F_ILETISIM", "0");
				telefonList.add(rowData);
			}
			
			if (iMap.getString("CEP_TEL_NO") != null && !iMap.getString("CEP_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "3");
				rowData.put("ALAN_KOD", iMap.getString("CEP_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("CEP_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				rowData.put("F_ILETISIM", "1");
				rowData.put("OTPMI", true);
				telefonList.add(rowData);
			}
			
			kontakt.put("TELEFON_LIST", telefonList);
			kontakt.put("VELI_VASI", iMap.get("VELI_VASI"));
			kontakt.put("EMAIL_KISISEL", iMap.getString("EMAIL"));
			if(HesapEkstre.EPOSTA.toString().equals(iMap.getString("HESAP_EKSTRE"))) {
				kontakt.put("EKS_EMAIL_TIP", iMap.getString("HESAP_EKSTRE"));
			} else if(kontakt.containsKey("EKS_EMAIL_TIP")) {
				kontakt.put("EKS_EMAIL_TIP", "");
			}
	
			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
			kontakt.put("F_CIFTE_VATANDAS", "R");
			kontakt.put("F_GREEN_CARD", "R");
	
			return GMServiceExecuter.call("BNSPR_TRN10041_SAVE", kontakt).put("MUSTERI_TRX_NO", kontakt.getBigDecimal("TRX_NO"));
			
	
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 */
	private static Map<? extends Object, ? extends Object> kontaktMusteriYarat(GMMap iMap) {

		GMMap kontakt = new GMMap();
		
		try {
			
			// Gercek musteriye donustur
			if(iMap.containsKey("MUSTERI_NO")) {
				
				iMap.put("KONTAKT_NO", iMap.getBigDecimal("MUSTERI_NO"));
				iMap.put("tckno_in", iMap.getString("TC_KIMLIK_NO"));
				iMap.put("ACTION", "NEW");
				
				kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_GET_INFO", iMap));
				
				kontakt.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
				if(StringUtils.isBlank(kontakt.getString("ORIJINAL_EVRAKLIMI"))) {
					kontakt.put("ORIJINAL_EVRAKLIMI", "H");
				}
				kontakt.put("MUSTERI_KONTAKT", "M");
				kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
				kontakt.put("F_CIFTE_VATANDAS", "R");
				kontakt.put("F_GREEN_CARD", "R");		
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "1");
				if(Boolean.valueOf(kontakt.remove("F_SAHTE").toString())) { kontakt.put("F_SAHTE", "1"); } else { kontakt.put("F_SAHTE", "0"); }
				
				try {
					kontakt.putAll(GMServiceExecuter.execute("BNSPR_QRY1098_GET_APS", iMap)); // TODO Review
				}
				catch (Exception e) {
					System.out.println(e.getMessage().toString());
				}
				
				kontakt.put("F_APS_TEYIT", "E");
				kontakt.put("F_APS", "E");
				kontakt.put("ADK_MUSTERISIMI", "H");
				
				return GMServiceExecuter.execute("BNSPR_TRN10011_SAVE", kontakt);
			}
			
			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI").trim());
			}
			
			kontakt.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			kontakt.put("MUSTERI_KONTAKT", "K");
			kontakt.put("MUSTERI_TIPI_KOD", "G");
			kontakt.put("BAGLI_KANAL_GRUBU", iMap.getString("KANAL_KODU"));
			kontakt.put("KANAL_KODU", iMap.getString("KANAL_ALT_KODU"));
			kontakt.put("MUSTERI_SEGMENTI", "N");			
			kontakt.put("YERLESIM_KOD", "I");
			kontakt.put("DK_GRUP_KOD", new BigDecimal("1042"));
			kontakt.put("PROFIL_KOD", "1");
			kontakt.put("BOLUM_KODU", new BigDecimal("444"));
			kontakt.put("KAZANIM_KANALI", iMap.getString("KANAL_KODU"));
			kontakt.put("KAZANIM_URUNU", KAZANIM_URUNU);
			kontakt.put("HESAP_UCRETI_F", "H");
			kontakt.put("PORTFOY_KOD", PORTFOY_KOD);
			kontakt.put("TCKNO_IN", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("TC_KIMLIK_NO", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("ISIM", iMap.getString("ISIM"));
			kontakt.put("IKINCI_ISIM", iMap.getString("IKINCI_ISIM"));
			kontakt.put("SOYADI", iMap.getString("SOYADI"));
			kontakt.put("KISA_AD", iMap.getString("ISIM") + " " + (iMap.getString("IKINCI_ISIM") == null ? "" : iMap.getString("IKINCI_ISIM") + " ") + iMap.getString("SOYADI"));
			kontakt.put("UYRUK_KOD", "TR");
			kontakt.put("DOGUM_TARIHI", !"".equals(iMap.getString("DOGUM_TARIHI")) ? iMap.getDate("DOGUM_TARIHI") : null);
			kontakt.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
			kontakt.put("BABA_ADI", iMap.getString("BABA_ADI"));
			kontakt.put("ANNE_ADI", iMap.getString("ANNE_ADI"));
			kontakt.put("CINSIYET_KOD", iMap.getString("CINSIYET_KOD"));
			kontakt.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			kontakt.put("MEDENI_HAL_KOD", iMap.getString("MEDENI_HAL_KOD"));
			kontakt.put("AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
			kontakt.put("CILT_NO", iMap.getString("CILT_NO"));
			kontakt.put("SIRA_NO", iMap.getString("SIRA_NO"));
			kontakt.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("NUFUS_CUZDANI_SERI_NO"));
			kontakt.put("KIZLIK_SOYADI", iMap.getString("KIZLIK_SOYADI"));
			kontakt.put("MESLEK_KOD", iMap.getString("MESLEK_KOD"));
			kontakt.put("EGITIM_KOD", iMap.getString("EGITIM_KOD"));
			kontakt.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			kontakt.put("F_ISTEGE_BAGLI_SIGORTALI", iMap.getString("SIGORTALI_MI"));
			kontakt.put("UNVAN_KOD", iMap.getString("UNVANI"));
			kontakt.put("IL_KOD", iMap.getString("IL_KOD"));
			kontakt.put("ILCE_KOD", iMap.getString("ILCE_KOD"));
			kontakt.put("MAHALLE_KOY", iMap.getString("MAHALLE_KOY"));
			kontakt.put("ADRES_NO", iMap.getBigDecimal("ADRES_NO"));
			kontakt.put("BUCAK", iMap.getString("BUCAK"));
			kontakt.put("BUCAK_KOD", iMap.getBigDecimal("BUCAK_KOD"));
			kontakt.put("CSBM", iMap.getString("CSBM"));
			kontakt.put("DIS_KAPI_NO", iMap.getString("DIS_KAPI_NO"));
			kontakt.put("IC_KAPI_NO", iMap.getString("IC_KAPI_NO"));
			kontakt.put("IL", iMap.getString("IL"));
			kontakt.put("ILCE", iMap.getString("ILCE"));
			kontakt.put("ILCE_KODU", iMap.getBigDecimal("ILCE_KODU"));
			kontakt.put("IL_KODU", iMap.getBigDecimal("IL_KODU"));
			kontakt.put("KOY", iMap.getString("KOY"));
			kontakt.put("KOY_KAYIT_NO", iMap.getBigDecimal("KOY_KAYIT_NO"));
			kontakt.put("KOY_KOD", iMap.getBigDecimal("KOY_KOD"));
			kontakt.put("MAHALLE", iMap.getString("MAHALLE"));
			kontakt.put("MAHALLE_KOD", iMap.getBigDecimal("MAHALLE_KOD"));
			kontakt.put("YABANCI_ADRES", iMap.getString("YABANCI_ADRES"));
			kontakt.put("YABANCI_SEHIR", iMap.getString("YABANCI_SEHIR"));
			kontakt.put("YABANCI_ULKE", iMap.getString("YABANCI_ULKE"));
			kontakt.put("YABANCI_ULKE_KOD", iMap.getString("YABANCI_ULKE_KOD"));
			kontakt.put("NUF_VERILIS_NEDENI", iMap.getString("NUF_VERILIS_NEDENI"));
			kontakt.put("VERILDIGI_YER", iMap.getString("VERILDIGI_YER"));
			kontakt.put("VERILDIGI_TARIH", !"".equals(iMap.getString("VERILDIGI_TARIH")) ? iMap.getDate("VERILDIGI_TARIH") : null);
			
			if (iMap.getString("NUFUS_CUZDANI_SERI_NO") != null && !iMap.getString("NUFUS_CUZDANI_SERI_NO").isEmpty()) {
				kontakt.put("F_NUF", "E");
			}
			
			if ("E".equals(iMap.getString("F_KPS_YAPILDI"))) {
				kontakt.put("TCKNO_OUT", iMap.getBigDecimal("TC_KIMLIK_NO"));
			}

			int addressListSize = iMap.getSize("ADRES_BILGILERI");
			List<Map<String, Object>> addressList = new ArrayList<Map<String, Object>>();
			for(int i=0; i<iMap.getSize("ADRES_BILGILERI"); i++) {
				if(iMap.getString("ADRES_BILGILERI", i, "EV_ADRES") != null && !iMap.getString("ADRES_BILGILERI", i, "EV_ADRES").isEmpty()) {
					Map<String, Object> rowData = new HashMap<String, Object>();
					rowData.put("ADRES_KOD", addressListSize == 1 ? "E" : "E".equals(iMap.getString("ADRES_BILGILERI", i, "F_APS")) ? "E1" : "E");
					rowData.put("ADRES", iMap.getString("ADRES_BILGILERI", i, "EV_ADRES"));
					rowData.put("ADRES_IL_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_IL_KOD"));
					rowData.put("ADRES_ILCE_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_ADR_ILCE_KOD"));
					rowData.put("ULKE_KOD", "TR");
					rowData.put("POSTA_KOD", iMap.getString("ADRES_BILGILERI", i, "EV_POSTAKOD"));
					rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
					rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_EV")));
					addressList.add(rowData);
				}
			}
			
			if(!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")){
				for (int row = 0; row < addressList.size(); row++) {
					Map<String, Object> adrMap = addressList.get(row);
					if ("E".equals(adrMap.get("ADRES_KOD"))) {
						adrMap.put("EXTRE_ADRES_KOD_F", "E");
					}
					addressList.set(row, adrMap);
				}
			}
				
			kontakt.put("ADRES_LIST", addressList);
			
			List<Map<String, Object>> telefonList = new ArrayList<Map<String, Object>>();
			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				Map<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "1");
				rowData.put("ALAN_KOD", iMap.getString("EV_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("EV_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				rowData.put("F_ILETISIM", "0");
				telefonList.add(rowData);
			}
			
			if (iMap.getString("CEP_TEL_NO") != null && !iMap.getString("CEP_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "3");
				rowData.put("ALAN_KOD", iMap.getString("CEP_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("CEP_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				rowData.put("F_ILETISIM", "1");
				rowData.put("OTPMI", true);
				telefonList.add(rowData);
			}
			kontakt.put("TELEFON_LIST", telefonList);
			kontakt.put("VELI_VASI", iMap.get("VELI_VASI"));
			kontakt.put("EMAIL_KISISEL", iMap.getString("EMAIL"));
			if(HesapEkstre.EPOSTA.toString().equals(iMap.getString("HESAP_EKSTRE"))) {
				kontakt.put("EKS_EMAIL_TIP", iMap.getString("HESAP_EKSTRE"));
			}

			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
			kontakt.put("F_CIFTE_VATANDAS", "R");
			kontakt.put("F_GREEN_CARD", "R");

			return GMServiceExecuter.execute("BNSPR_TRN10011_SAVE", kontakt);


		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * TBD
	 * 
	 * @param musteriNo
	 * @return
	 * @throws Exception
	 */
	private static String getYatirimEkstreBilgi(BigDecimal musteriNo) throws Exception {
		
		GMMap oMap = new GMMap();
		String fYatirimEkstre = "H";
		
		oMap.putAll(GMServiceExecuter.call("BNSPR_TRN1337_MUSTERI_INFO_SEARCH", 
			new GMMap().put("MUSTERI_NO", musteriNo)));
		
		for(YatirimEkstre ekstre : YatirimEkstre.values()) {
			
			try {
				
				if(!ekstre.equals(YatirimEkstre.SECINIZ) && !ekstre.equals(YatirimEkstre.ISTENMEDI) && 
					ekstre.equals(YatirimEkstre.getEnum(oMap.getString("MUSTERI_INFO_LIST", 0, "YATIRIM_EXTRESI_GONDERILSINMI")))) {
					fYatirimEkstre = "E";
				}
				
			} catch(IllegalArgumentException e) {
				fYatirimEkstre = "H";
			}
		}
		
		return fYatirimEkstre;
	}
	
	/**
	 * TBD
	 * 
	 * @param tcKimlikNo
	 * @return
	 * @throws Exception
	 */
	private static String getBasvuruDurum(String tcKimlikNo) throws Exception {
		
		Session session = DAOSession.getSession("BNSPRDal");
		int belgeCount = ((Integer) session.createCriteria(ClksBonoTalepBelge.class)
			.add(Restrictions.eq("tcKimlikNo", tcKimlikNo))
			.setProjection(Projections.rowCount())
			.uniqueResult()).intValue();
		
		return belgeCount > 0 ? BasvuruDurum.EVRAKSIZ.toString() : BasvuruDurum.BASVURU.toString();
	}
	
	/**
	 * TBD
	 * 
	 * @param basvuruNo
	 * @param musteriNo
	 * @param tcKimlikNo
	 * @param dokumanKod
	 * @return
	 */
	private static GMMap eksikBelgeKontrol(BigDecimal basvuruNo, BigDecimal musteriNo, String tcKimlikNo, String dokumanKod) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			if("E".equals((String) DALUtil.callOracleFunction("{ ? = call pkg_trn4801.eksik_belge_mi(?,?,?) }", 
				BnsprType.STRING, 
				BnsprType.NUMBER, basvuruNo,
				BnsprType.STRING, tcKimlikNo,
				BnsprType.STRING, dokumanKod))) {
			
				oMap.put("RESPONSE", Response.MISSING_DOCUMENT);
				oMap.put("F_YATIRIM_EKSTRE", getYatirimEkstreBilgi(musteriNo));
				oMap.put("BASVURU_DURUM", getBasvuruDurum(tcKimlikNo));
				
			} else {
				oMap.put("RESPONSE", Response.SUCCESS);
			}
			
			return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 * @throws ParseException
	 */
	@SuppressWarnings("unused")
	private static Map<String, Object> getAPSAddressObject(GMMap iMap) throws ParseException {
		
		Map<String, Object> rowData = new HashMap<String, Object>();
		String adres = "";
		rowData.put("ADRES_KOD", "A"); // A koduyla ekleniyor.
		
		if (!"0".equals(iMap.getString("ADRES_NO")) && iMap.getString("YABANCI_ULKE_KOD") == null) {
			if (iMap.get("BUCAK") != null && !iMap.getString("BUCAK").isEmpty())
				adres = iMap.getString("BUCAK") + " ";
			if (iMap.get("KOY") != null && !iMap.getString("KOY").isEmpty())
				adres += iMap.getString("KOY") + " ";
			if (iMap.get("MAHALLE") != null && !iMap.getString("MAHALLE").isEmpty())
				adres += iMap.getString("MAHALLE") + " ";
			if (iMap.get("CSBM") != null && !iMap.getString("CSBM").isEmpty())
				adres += iMap.getString("CSBM") + " ";
			if (iMap.get("DIS_KAPI_NO") != null && !iMap.getString("DIS_KAPI_NO").isEmpty())
				adres += "NO:" + iMap.getString("DIS_KAPI_NO") + " ";
			if (iMap.get("IC_KAPI_NO") != null && !iMap.getString("IC_KAPI_NO").isEmpty())
				adres += "DAIRE:" + iMap.getString("IC_KAPI_NO");
			rowData.put("ADRES", adres);
			rowData.put("ULKE_KOD", "TR");
			if (iMap.get("IL_KODU") != null) {
				String ilKodu = "";
				if (iMap.getString("IL_KODU").length() == 1)
					ilKodu = "00" + iMap.getString("IL_KODU");
				else if (iMap.getString("IL_KODU").length() == 2)
					ilKodu = "0" + iMap.getString("IL_KODU");
				else
					ilKodu = iMap.getString("IL_KODU");
				rowData.put("ADRES_IL_KOD", ilKodu);
			}
			rowData.put("ADRES_ILCE_KOD", iMap.getBigDecimal("ILCE_KODU"));
		}
		else {
			rowData.put("ADRES", iMap.getString("YABANCI_ADRES"));
			rowData.put("ULKE_KOD", "");
		}
		rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
		rowData.put("EXTRE_ADRES_KOD_F", "E");
		
		return rowData;
	}
	
	/**
	 * TBD
	 * 
	 * @param basvuruNo
	 * @param dokumanKod
	 * @return
	 */
	private static Object getBelgeData(BigDecimal basvuruNo, BigDecimal dokumanKod) {

		Object object = null;
		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn4801.belge_data(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.BLOB);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.setBigDecimal(3, dokumanKod);
			stmt.execute();
			Blob blob = stmt.getBlob(1);
			if(blob != null) {
				byte[] data = blob.getBytes(1L, (int) blob.length());
				object = GMToolkit.deserialize(data);
			}

		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return object;

	}
	
	private static GMMap sendSMS(GMMap iMap) {
		
		try {
			GMMap msgMap = new GMMap();
            msgMap.put("MESSAGE_NO", iMap.getBigDecimal("MESSAGE_NO"));
			
            GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap()
			.put("MSISDN", iMap.getString("MSISDN"))
			.put("CONTENT", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", msgMap )
				.getString("ERROR_MESSAGE"))
			.put("TRX_NO", iMap.getBigDecimal("TRX_NO"))
			.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO")));
		} catch(Exception e){
			logger.error("BNSPR_COMMON_GET_KODSUZ_MESSAGE err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return new GMMap();
	}
}
