package tr.com.aktifbank.bnspr.clks.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.ClksMusteriKpsApsYkps;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class PttMusteriServices {
	
	@GraymoundService("PTT_MUSTERI_CUSTOMER_CONTINUE")
	public static GMMap pttBonoMusteriCustomerContinue(GMMap iMap)  { 
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		String call = "{call PKG_PTT_MUSTERI.WS_Musteri_Devam_Kontrol(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )}";
		Connection conn = null;
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			stmt.setString(1, iMap.getString("KPS_APS_ID"));
			
			//ps_tckn
			stmt.setString(2, iMap.getString("KIMLIK_BILGILERI", 0, "TC_KIMLIK_NO"));
			//ps_uyruk
			stmt.setString(3, iMap.getString("KIMLIK_BILGILERI", 0, "UYRUK"));
			//ps_kimlik_blg_uyum
			stmt.setString(4, iMap.getString("KIMLIK_BILGILERI", 0, "KIMLIK_BLG_UYUM_EH"));
			//ps_kimlik_tipi
			stmt.setString(5, iMap.getString("KIMLIK_BILGILERI", 0, "KIMLIK_TIPI"));
			//ps_kimlik_seri_no
			stmt.setString(6, iMap.getString("KIMLIK_BILGILERI", 0, "KIMLIK_SERI_NO"));
			//pd_kimlik_ver_tarih
			DateFormat cf = new SimpleDateFormat("yyyyMMdd");
			java.sql.Date kimVerDate = new java.sql.Date(
				cf.parse(iMap.getString("KIMLIK_BILGILERI", 0, "KIMLIK_VER_TARIH")).getTime());
			stmt.setDate(7, kimVerDate);
			//ps_kimlik_ver_yer
			stmt.setString(8, iMap.getString("KIMLIK_BILGILERI", 0, "KIMLIK_VER_YER"));
			//ps_urun_kod
			stmt.setString(9, iMap.getString("URUN"));
			//ps_IYK_sicil
			stmt.setString(10, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_SICIL"));
			//ps_IYK_adsoyad
			stmt.setString(11, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_AD_SOYAD"));
			//ps_IYK_il
			stmt.setString(12, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_IL"));
			//ps_IYK_merkez_sube
			stmt.setString(13, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_MERKEZ_SUBE"));
			//ps_IYK_merkez
			stmt.setString(14, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_MERKEZ"));
			//ps_IYK_sube
			stmt.setString(15, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_SUBE"));
			//ps_IYK_bm
			stmt.setString(16, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_BM"));
			
			//RESPONSE
			stmt.registerOutParameter(17, Types.VARCHAR);
			//RESPONSE_DATA
			stmt.registerOutParameter(18, Types.VARCHAR);
			//pn_tx_no
			stmt.registerOutParameter(19, Types.NUMERIC);
			
			stmt.execute();
			
			oMap.put("RESPONSE", stmt.getString(17));
			oMap.put("RESPONSE_DATA",  stmt.getString(18));
			oMap.put("BANKA_ISLEM_NO", stmt.getLong(19));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("PTT_MUSTERI_CUSTOMER_CONTINUE1")
	public static GMMap pttBonoMusteriCustomerContinue1(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		String call = "{call PKG_PTT_MUSTERI.WS_Musteri_Devam_Kontrol1(?,?,?,?,?,?,?,?,?,? )}";
		Connection conn = null;
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			//pn_tx_no
			stmt.setLong(1, iMap.getLong("BANKA_ISLEM_NO"));
			//ps_annekizliksoyadi
			stmt.setString(2, iMap.getString("ANNE_KIZLIK_SOYADI"));
			//ps_onceki_soyad
			stmt.setString(3, iMap.getString("ONCEKI_SOYADI"));
			//ps_egitimkod
			stmt.setString(4, iMap.getString("EGITIM_KOD"));
			//ps_calismasekli
			stmt.setString(5, iMap.getString("CALISMA_SEKLI"));
			//ps_unvankod
			stmt.setString(6, iMap.getString("UNVAN_KOD"));
			//ps_meslekkod
			stmt.setString(7, iMap.getString("MESLEK_KOD"));
			//ps_ibsigortaeh
			stmt.setString(8, iMap.getString("ISTEGE_BAGLI_SIGORTA_EH"));
			//RESPONSE
			stmt.registerOutParameter(9, Types.VARCHAR);
			//RESPONSE_DATA
			stmt.registerOutParameter(10, Types.VARCHAR);
			
			stmt.execute();
			
			oMap.put("RESPONSE", stmt.getString(9));
			oMap.put("RESPONSE_DATA",  stmt.getString(10));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	@GraymoundService("PTT_MUSTERI_CUSTOMER_CONTINUE2")
	public static GMMap pttBonoMusteriCustomerContinue2(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		String call = "{call PKG_PTT_MUSTERI.WS_Musteri_Devam_Kontrol2(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? )}";
		Connection conn = null;
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			//pn_basvuru_no
			stmt.setLong(1, iMap.getLong("BANKA_ISLEM_NO"));
			//ps_isyeriadi
			stmt.setString(2, iMap.getString("ISYERI_ADI"));
			//ps_isadresi
			stmt.setString(3, iMap.getString("IS_ADRESI"));
			//ps_il_kod 
			String IlKod = iMap.getString("IL_KOD");

			if (!isEmpty(IlKod)) {

				while (IlKod.length() < 3) {
	
				            IlKod = "0" + IlKod;
	
				}
				stmt.setString(4, IlKod);
			}else
				stmt.setString(4, null);
			// ps_ilce_kod  
			stmt.setString(5, iMap.getString("ILCE_KOD"));
			// ps_is_tel 
			stmt.setString(6, iMap.getString("IS_TEL"));
			// ps_dahili
			stmt.setString(7, iMap.getString("DAHILI"));
			//ps_ev_tel
			stmt.setString(8, iMap.getString("EV_TEL"));
			//ps_cep_tel
			stmt.setString(9, iMap.getString("CEP_TEL"));
			//ps_email 
			stmt.setString(10, iMap.getString("EMAIL"));
			// ps_iletisim 
			stmt.setString(11, iMap.getString("ILETISIM_TEL"));
			// ps_yazisma_adres
			stmt.setString(12, iMap.getString("YAZISMA_ADRESI"));
			//ps_yatirim_extre 
			stmt.setString(13, iMap.getString("YATIRIM_EXT_GON_TERCIHI"));
			
			// RESPONSE 
			stmt.registerOutParameter(14, Types.VARCHAR);
			// RESPONSE_DATA
			stmt.registerOutParameter(15, Types.VARCHAR);
			
			//   pn_masraf 
			stmt.registerOutParameter(16, Types.NUMERIC);
			
			stmt.execute();
			
			oMap.put("RESPONSE", stmt.getString(14));
			oMap.put("RESPONSE_DATA",  stmt.getString(15));
			oMap.put("MASRAF_TUTARI", stmt.getBigDecimal(16));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	@GraymoundService("PTT_MUSTERI_PDF_BARKOD")
	public static GMMap pttBonoMusteriPdfBarkod(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		String call = "{call PKG_PTT_MUSTERI.WS_Musteri_PDF_Barkod(?,?,?,?)}";
		Connection conn = null;
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			//Banka_Islem_No
			stmt.setLong(1, iMap.getLong("BANKA_ISLEM_NO"));
			
			// RESPONSE 
			stmt.registerOutParameter(2, Types.VARCHAR);
			// RESPONSE_DATA
			stmt.registerOutParameter(3, Types.VARCHAR);
			
			//  Barkod_No 
			stmt.registerOutParameter(4, Types.VARCHAR);
			
			stmt.execute();
			
			oMap.put("RESPONSE", stmt.getString(2));
			oMap.put("RESPONSE_DATA",  stmt.getString(3));
			oMap.put("BARKOD_NO", stmt.getString(4));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("PTT_MUSTERI_CONTINUE_PDF")
	public static GMMap pttBonoMusteriContinuePdf(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet resSet = null	;
		
		String call = "{call PKG_PTT_MUSTERI.WS_Musteri_Devam_PDF(?,?,?,?)}";
		Connection conn = null;
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			stmt.setLong(1, iMap.getLong("BANKA_ISLEM_NO"));//Banka_Islem_No
			stmt.registerOutParameter(2, Types.VARCHAR);// RESPONSE 
			stmt.registerOutParameter(3, Types.VARCHAR);// RESPONSE_DATA
			
			//  Belge Listesi
			stmt.registerOutParameter(4,-10);
			
			stmt.execute();
			stmt.getMoreResults();
			
			oMap.put("RESPONSE", stmt.getString(2));
			oMap.put("RESPONSE_DATA",  stmt.getString(3));
			if ("2".equals(oMap.getString("RESPONSE"))) {
				
				resSet = (ResultSet)stmt.getObject(4);
				int i = 0;
				while(resSet.next()){
					oMap.put("BELGE_LISTESI", i,"DOKUMAN_KOD"			, resSet.getString("dokuman_kod")			);
					oMap.put("BELGE_LISTESI", i,"BELGE_ADI"				, resSet.getString("belge_adi")				);
					oMap.put("BELGE_LISTESI", i,"TEKRAR_YAZDIRILACAK_MI", resSet.getString("tekrar_yazdirilicakmi")	);
					i++;
				}
			}
			
		
			
			
			
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(resSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/*
	 * INPUT map 
	 *		BANKA_ISLEM_NO
	 *		PTT_ISLEM_NO
	 * OUTPUT map
	 * 		RESPONSE
	 *		RESPONSE_DATA
	 *		MUSTERI_NO
	 *		HESAP_NO
	 *		ISLEM_NO
	 * */
	
	@GraymoundService("PTT_MUSTERI_APPLICATION_CONFIRM")
	public static GMMap pttBonoMusteriApplicationConfirm(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		String call = "{call PKG_PTT_MUSTERI.WS_Musteri_Basvuru_Onay(?,?,?,?,?,?,?)}";
		Connection conn = null;
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			stmt.setLong(1, iMap.getLong("BANKA_ISLEM_NO"));//Banka_Islem_No
			stmt.setString(2, iMap.getString("PTT_ISLEM_NO"));//Ptt_Islem_No
			stmt.registerOutParameter(3, Types.VARCHAR);// RESPONSE 
			stmt.registerOutParameter(4, Types.VARCHAR);// RESPONSE_DATA
			stmt.registerOutParameter(5, Types.NUMERIC);// pn_islem_no
			stmt.registerOutParameter(6, Types.NUMERIC);//  Musteri_No
			stmt.registerOutParameter(7, Types.NUMERIC);//  Hesap_No 
			stmt.execute();
			
			oMap.put("RESPONSE"     , stmt.getString(3));
			oMap.put("RESPONSE_DATA", stmt.getString(4));
			oMap.put("BANKA_ISLEM_NO"		, stmt.getLong(5));
			oMap.put("MUSTERI_NO"	, stmt.getLong(6));
			oMap.put("HESAP_NO"		, stmt.getLong(7));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
		
		return oMap;
	}
	
	@GraymoundService("PTT_MUSTERI_APPLICATION_CANCEL")
	public static GMMap pttBonoMusteriApplicationCancel(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		String call = "{call PKG_PTT_MUSTERI.WS_Musteri_Basvuru_Iptal(?,?,?)}";
		Connection conn = null;
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			stmt.setLong(1, iMap.getLong("BANKA_ISLEM_NO"));//Banka_Islem_No
			stmt.registerOutParameter(2, Types.VARCHAR);// RESPONSE 
			stmt.registerOutParameter(3, Types.VARCHAR);// RESPONSE_DATA
		
			stmt.execute();
			
			oMap.put("RESPONSE", stmt.getString(2));
			oMap.put("RESPONSE_DATA",  stmt.getString(3));
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
		
		return oMap;
	}
	
	/*
	 * INPUT - iMap
	 * 
	 *  KPS_BILGILERI	
			TC_KIMLIK_NO
			KPS_NUFUS_CUZDANI_SERI_NO
			KPS_KIMLIK_SIRA_NO
			KPS_ISIM
			KPS_IKINCI_ISIM
			KPS_SOYAD
			KPS_BABA_ADI
			KPS_ANNE_ADI
			KPS_DOGUM_YERI
			KPS_VERILDIGI_ILCE_KODU
			KPS_VERILDIGI_YER
			KPS_VERILDIGI_TARIH
			KPS_DOGUM_TARIHI
			KPS_OLUM_TARIHI
			KPS_NUFUS_IL_KODU
			KPS_ILCE_KOD
			KPS_MAHALLE_KOY
			KPS_CILT_NO
			KPS_AILE_SIRA_NO
			KPS_SIRA_NO
			KPS_CINSIYET_KOD
			KPS_MEDENI_HAL_KOD
			KPS_NUF_VERILIS_NEDENI
			KPS_KIMLIK_KAYIT_NO
			KPS_KIZLIK_SOYADI
		APS_BILGILERI	
			APS_ADRES_NO
			APS_BUCAK
			APS_BUCAK_KOD
			APS_CSBM
			APS_CSBM_KODU
			APS_DIS_KAPI_NO
			APS_IC_KAPI_NO
			APS_IL
			APS_ILCE
			APS_ILCE_KODU
			APS_IL_KODU
			APS_KOY
			APS_KOY_KAYIT_NO
			APS_KOY_KOD
			APS_MAHALLE
			APS_MAHALLE_KOD
			APS_FAPS_TEYIT
		YKPS_BILGILERI	
			YKPS_UYRUK_KOD
			YKPS_IKAMET_TEZKERE_NO
			YKPS_IKAMET_SURESI_KOD
			YKPS_IKAMET_SURESI_AD
			YKPS_IKAMET_DUZENLEYEN_IL_ADI
			YKPS_IKAMET_TEZKERE_TARIHI
		TX_NO	

	 * 
	 * OUTPUT  - oMap
	 * 
	 * 	RESPONSE
	 *	RESPONSE_DATA
	 *	KPS_APS_ID
	 *
	 * 
	 * */
	
	@GraymoundService("PTT_MUSTERI_PTT_KPS")
	public static GMMap pttBonoMusteriPttKps(GMMap iMap)  {
		GMMap oMap = new GMMap();
		
		GMMap 	xMap 	= new GMMap().put("TABLE_NAME", "CLKS_MUSTERI_KPS_APS_YKPS");
		iMap.put("ID", GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID")) ;
		
		try { 
			ClksMusteriKpsApsYkps kpsTx = clksMusteriKpsApsYkpsOlustur(iMap);
			
			Session session = DAOSession.getSession("BNSPRDal");
			session.save(kpsTx);
			session.flush();
			
			oMap.put("KPS_APS_ID"		, kpsTx.getId() 	);
			oMap.put("RESPONSE"			, "2"				);
			oMap.put("RESPONSE_DATA"	, "Islem Basarili"	);
		}
		catch (Exception e) {
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
			
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
			
	private static ClksMusteriKpsApsYkps clksMusteriKpsApsYkpsOlustur(GMMap iMap) throws Exception {
		ClksMusteriKpsApsYkps kps = new ClksMusteriKpsApsYkps();
		
		kps.setTcKimlikNo(iMap.getString("KPS_BILGILERI", 0, "TC_KIMLIK_NO"));
		kps.setKpsNufusCuzdaniSeriNo(iMap.getString("KPS_BILGILERI", 0, "KPS_NUFUS_CUZDANI_SERI_NO"));
		kps.setKpsKimlikSiraNo(iMap.getString("KPS_BILGILERI", 0, "KPS_KIMLIK_SIRA_NO"));
		kps.setKpsIsim(iMap.getString("KPS_BILGILERI", 0, "KPS_ISIM"));
		kps.setKpsIkinciIsim(iMap.getString("KPS_BILGILERI", 0, "KPS_IKINCI_ISIM"));
		kps.setKpsSoyadi(iMap.getString("KPS_BILGILERI", 0, "KPS_SOYAD"));
		kps.setKpsBabaAdi(iMap.getString("KPS_BILGILERI", 0, "KPS_BABA_ADI"));
		kps.setKpsAnneAdi(iMap.getString("KPS_BILGILERI", 0, "KPS_ANNE_ADI"));
		kps.setKpsDogumYeri(iMap.getString("KPS_BILGILERI", 0, "KPS_DOGUM_YERI"));
		kps.setKpsVerildigiIlceKodu(iMap.getString("KPS_BILGILERI", 0, "KPS_VERILDIGI_ILCE_KODU"));
		kps.setKpsVerildigiYer(iMap.getString("KPS_BILGILERI", 0, "KPS_VERILDIGI_YER"));
		
		if (!isEmpty(iMap.getString("KPS_BILGILERI", 0, "KPS_VERILDIGI_TARIH"))) {
			kps.setKpsVerildigiTarih(iMap.getDate("KPS_BILGILERI", 0, "KPS_VERILDIGI_TARIH"));
		}
		if (!isEmpty(iMap.getString("KPS_BILGILERI", 0, "KPS_DOGUM_TARIHI"))) {
			kps.setKpsDogumTarihi(iMap.getDate("KPS_BILGILERI", 0, "KPS_DOGUM_TARIHI"));
		}
		if (!isEmpty(iMap.getString("KPS_BILGILERI", 0, "KPS_OLUM_TARIHI"))) {
			kps.setKpsOlumTarihi(iMap.getDate("KPS_BILGILERI", 0, "KPS_OLUM_TARIHI"));
		}
		if (!isEmpty(iMap.getString("KPS_BILGILERI", 0, "KPS_NUFUS_IL_KODU"))) {
			kps.setKpsNufusIlKodu(iMap.getString("KPS_BILGILERI", 0, "KPS_NUFUS_IL_KODU"));
		}
		
		kps.setKpsIlceKod(iMap.getString("KPS_BILGILERI", 0, "KPS_ILCE_KOD"));
		kps.setKpsMahalleKoy(iMap.getString("KPS_BILGILERI", 0, "KPS_MAHALLE_KOY"));
		kps.setKpsCiltNo(iMap.getString("KPS_BILGILERI", 0, "KPS_CILT_NO"));
		kps.setKpsAileSiraNo(iMap.getString("KPS_BILGILERI", 0, "KPS_AILE_SIRA_NO"));
		kps.setKpsSiraNo(iMap.getString("KPS_BILGILERI", 0, "KPS_SIRA_NO"));
		kps.setKpsCinsiyetKod(iMap.getString("KPS_BILGILERI", 0, "KPS_CINSIYET_KOD"));
		kps.setKpsMedeniHalKod(iMap.getString("KPS_BILGILERI", 0, "KPS_MEDENI_HAL_KOD"));
		kps.setKpsNufVerilisNedeni(iMap.getString("KPS_BILGILERI", 0, "KPS_NUF_VERILIS_NEDENI"));
		kps.setKpsKimlikKayitNo(iMap.getString("KPS_BILGILERI", 0, "KPS_KIMLIK_KAYIT_NO"));
		kps.setKpsKizlikSoyadi(iMap.getString("KPS_BILGILERI", 0, "KPS_KIZLIK_SOYADI"));
		
		if (!isEmpty(iMap.getString("APS_BILGILERI", 0, "APS_ADRES_NO"))) {
			kps.setApsAdresNo(iMap.getBigDecimal("APS_BILGILERI", 0, "APS_ADRES_NO"));
		}
		
		kps.setApsBucak(iMap.getString("APS_BILGILERI", 0, "APS_BUCAK"));
		
		if (!isEmpty(iMap.getString("APS_BILGILERI", 0, "APS_BUCAK_KOD"))) {
			kps.setApsBucakKod(iMap.getBigDecimal("APS_BILGILERI", 0, "APS_BUCAK_KOD"));
		}
		
		kps.setApsCsbm(iMap.getString("APS_BILGILERI", 0, "APS_CSBM"));
		
		if (!isEmpty(iMap.getString("APS_BILGILERI", 0, "APS_CSBM_KODU"))) {
			kps.setApsCsbmKodu(iMap.getBigDecimal("APS_BILGILERI", 0, "APS_CSBM_KODU"));
		}
		kps.setApsDisKapiNo(iMap.getString("APS_BILGILERI", 0, "APS_DIS_KAPI_NO"));
		kps.setApsIcKapiNo(iMap.getString("APS_BILGILERI", 0, "APS_IC_KAPI_NO"));
		kps.setApsIl(iMap.getString("APS_BILGILERI", 0, "APS_IL"));
		kps.setApsIlce(iMap.getString("APS_BILGILERI", 0, "APS_ILCE"));
		
		if (!isEmpty(iMap.getString("APS_BILGILERI", 0, "APS_ILCE_KODU"))) {
			kps.setApsIlceKodu(iMap.getBigDecimal("APS_BILGILERI", 0, "APS_ILCE_KODU"));
		}
		if (!isEmpty(iMap.getString("APS_BILGILERI", 0, "APS_IL_KODU"))) {
			kps.setApsIlKodu(iMap.getBigDecimal("APS_BILGILERI", 0, "APS_IL_KODU"));			
		}
		kps.setApsKoy(iMap.getString("APS_BILGILERI", 0, "APS_KOY"));
		
		if (!isEmpty(iMap.getString("APS_BILGILERI", 0, "APS_KOY_KAYIT_NO"))) {
			kps.setApsKoyKayitNo(iMap.getBigDecimal("APS_BILGILERI", 0, "APS_KOY_KAYIT_NO"));			
		}
		if (!isEmpty(iMap.getString("APS_BILGILERI", 0, "APS_KOY_KOD"))) {
			kps.setApsKoyKod(iMap.getBigDecimal("APS_BILGILERI", 0, "APS_KOY_KOD"));
		}
		if (!isEmpty(iMap.getString("APS_BILGILERI", 0, "APS_MAHALLE_KOD"))) {
			kps.setApsMahalleKod(iMap.getBigDecimal("APS_BILGILERI", 0, "APS_MAHALLE_KOD"));
		}
		kps.setApsMahalle(iMap.getString("APS_BILGILERI", 0, "APS_MAHALLE"));
		kps.setApsFApsTeyit(iMap.getString("APS_BILGILERI", 0, "APS_FAPS_TEYIT"));
		kps.setYkpsUyrukKod(iMap.getString("YKPS_BILGILERI", 0, "YKPS_UYRUK_KOD"));
		kps.setYkpsIkametTezkereNo(iMap.getString("YKPS_BILGILERI", 0, "YKPS_IKAMET_TEZKERE_NO"));
		kps.setYkpsIkmetSuresiKod(iMap.getString("YKPS_BILGILERI", 0, "YKPS_IKAMET_SURESI_KOD"));
		kps.setYkpsIkmetSuresiAd(iMap.getString("YKPS_BILGILERI", 0, "YKPS_IKAMET_SURESI_AD"));
		kps.setYkpsIkmetDuzenleyenIladi(iMap.getString("YKPS_BILGILERI", 0, "YKPS_IKAMET_DUZENLEYEN_IL_ADI"));
		
		if (!isEmpty(iMap.getString("YKPS_BILGILERI", 0, "YKPS_IKAMET_TEZKERE_TARIHI"))) {
			kps.setYkpsIkmetTezkereTarihi(iMap.getDate("YKPS_BILGILERI", 0, "YKPS_IKAMET_TEZKERE_TARIHI"));
		}
		kps.setTxNo(iMap.getBigDecimal("TX_NO"));
		kps.setId(iMap.getBigDecimal("ID"));
		
		return kps;
	}
	
	private static boolean isEmpty(String arg) {
		return arg == null || arg.trim().isEmpty();
		
	}
}