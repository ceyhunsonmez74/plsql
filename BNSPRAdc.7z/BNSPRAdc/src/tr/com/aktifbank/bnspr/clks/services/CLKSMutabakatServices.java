package tr.com.aktifbank.bnspr.clks.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.EnumSet;
import java.util.Set;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksBasvuruMutabakat;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatSorgu;
import tr.com.calikbank.bnspr.dao.ClksMutabakat;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CLKSMutabakatServices {
	
	private static Logger logger = Logger.getLogger(CLKSMutabakatServices.class);
	
	private enum Transaction {

		NAKIT_YATAN("1"), NAKIT_CEKILEN("5"), TAKSIT_TAHSILATI("4"), KREDI_KULLANDIRIM_ODEMESI("7"), 
		KART_PASSO_YATAN("65"), KART_NKOLAY_YATAN("72"), ATM("60");
		
		private String code;
		
		Transaction(String code) {
			this.code = code;
		}

		@Override
		public String toString() {
			return code;
		}

		public static Transaction fromString(String code) {
			for (Transaction v : values())
				if (v.toString().equalsIgnoreCase(code))
					return v;
			throw new IllegalArgumentException();
		}
	}

	private static Set<Transaction> COLLECTION_TRANSACTIONS = EnumSet.of(Transaction.NAKIT_YATAN,
		Transaction.TAKSIT_TAHSILATI, Transaction.KART_PASSO_YATAN, Transaction.KART_NKOLAY_YATAN, Transaction.ATM);
	private static Set<Transaction> PAYMENT_TRANSACTIONS = EnumSet.of(Transaction.NAKIT_CEKILEN,
		Transaction.KREDI_KULLANDIRIM_ODEMESI);
	
	@GraymoundService("CLKS_AGREEMENT_NEW_SAVE")
	public static GMMap agreementSave(GMMap iMap) {

		GMMap oMap = new GMMap();
		int flushSize = 250, i = 0;

		try {

			Session session = DAOSession.getSession("BNSPRDal");

			iMap.put("sorguNo",
				GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));

			ClksMutabakatSorgu clksMutabakatSorgu = new ClksMutabakatSorgu();
			clksMutabakatSorgu.setSorguNo(iMap.getBigDecimal("sorguNo"));
			clksMutabakatSorgu.setIslemTarihi(iMap.getDate("islemTarihi"));
			clksMutabakatSorgu.setFKomisyonHesaplama("H");
			session.save(clksMutabakatSorgu);

			ClksMutabakat clksMutabakat;

			for(i = 0; i < iMap.getSize("islemListesi"); i++) {

				clksMutabakat = (ClksMutabakat) session.get(ClksMutabakat.class,
					iMap.getBigDecimal("islemListesi", i, "islemNoBanka"));

				if(clksMutabakat == null) {
					clksMutabakat = new ClksMutabakat();
				}
				
				try {
					
					Transaction trx = Transaction.fromString(iMap.getString("islemListesi", i, "islemTuru"));

					if("TRY".contains(iMap.getString("islemListesi", i, "dovizKodu"))) {
						if(COLLECTION_TRANSACTIONS.contains(trx)) {
							
							iMap.put("islemListesi", i, "tutar",
								iMap.getBigDecimal("islemListesi", i, "tutar").subtract(
									iMap.getBigDecimal("islemListesi", i, "masrafTutari")));
							
						} else if(PAYMENT_TRANSACTIONS.contains(trx)) {
							
							iMap.put("islemListesi", i, "tutar",
								iMap.getBigDecimal("islemListesi", i, "tutar").add(
									iMap.getBigDecimal("islemListesi", i, "masrafTutari")));
							
						}
					}

				} catch(IllegalArgumentException e) {}

				clksMutabakat.setSorguNo(iMap.getBigDecimal("sorguNo"));
				clksMutabakat.setIslemNo(iMap.getBigDecimal("islemListesi", i, "islemNo"));
				clksMutabakat.setIslemNoBanka(iMap.getBigDecimal("islemListesi", i, "islemNoBanka"));
				clksMutabakat.setDovizKod(iMap.getString("islemListesi", i, "dovizKodu"));
				clksMutabakat.setHesapNo(NumberUtils.isNumber(iMap.getString("islemListesi", i, "hesapNo")) ? iMap
					.getBigDecimal("islemListesi", i, "hesapNo") : null);
				clksMutabakat.setIslemTipi(iMap.getBigDecimal("islemListesi", i, "islem"));
				clksMutabakat.setIslemTuru(iMap.getString("islemListesi", i, "islemTuru"));
				clksMutabakat.setMasrafTutari(iMap.getBigDecimal("islemListesi", i, "masrafTutari"));
				clksMutabakat.setTutar(iMap.getBigDecimal("islemListesi", i, "tutar"));
				clksMutabakat.setMasrafDovizKod(iMap.getString("islemListesi", i, "masrafDovizKodu"));
				clksMutabakat.setSubeId(iMap.getString("islemListesi", i, "subeId"));
				clksMutabakat.setMerkezId(iMap.getString("islemListesi", i, "merkezId"));
				clksMutabakat.setIslemTarihi(iMap.getDate("islemTarihi"));

				session.saveOrUpdate(clksMutabakat);

				if(i % flushSize == 0) {
					session.flush();
					session.clear();
				}
			}

			if(i % flushSize != 0) {
				session.flush();
			}

			oMap.put("CONTROL_MASK", 2);

		} catch(ConstraintViolationException e) {
			logger.error("CLKS_AGREEMENT_NEW_SAVE ConstraintViolationException err: " + e);
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw ExceptionHandler.convertException(new GMRuntimeException(0, (String) GMServiceExecuter.execute(
				"BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE")));
		} catch(Exception e) {
			logger.error("CLKS_AGREEMENT_NEW_SAVE err: " + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("CLKS_RESPONSE_NEW_PROXY")
	public static GMMap agreementResponse(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Object [] inputValues = new Object [2];
		int i = 0;
		
		try {
			
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("tarih");
			
			oMap = (GMMap)DALUtil.callOracleRefCursorFunction("{ ? = call PKG_PTT_MUTABAKAT.AGREEMENT_RESPONSE(?)}", "islemListesi", inputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("CLKS_PTT_CREDIT_AGREEMENT_NEW")
	public static GMMap pttCreditAgreement(GMMap iMap) throws ParseException{

		GMMap oMap = new GMMap();
		Object [] inputValues = new Object[2];
		Object [] outputValues = new Object[4];
		
		int j = 0;
		
		try{
			
			Session	session	= DAOSession.getSession("BNSPRDal"); 
			ClksBasvuruMutabakat clksBasvuruMutabakat ;

			String tableName = "krediMutabakatList";
			for (int i=0; i<iMap.getSize(tableName); i++) {
				
				clksBasvuruMutabakat= (ClksBasvuruMutabakat)session.get(ClksBasvuruMutabakat.class, iMap.getBigDecimal(tableName, i, "basvuruNo"));
				
				if(clksBasvuruMutabakat == null) {
					clksBasvuruMutabakat = new ClksBasvuruMutabakat();
				}
				
				clksBasvuruMutabakat.setBasvuruNo(iMap.getBigDecimal(tableName, i, "basvuruNo"));
				clksBasvuruMutabakat.setIptalEdildimi(iMap.getString(tableName, i, "iptalEdildimi"));
				clksBasvuruMutabakat.setTutar(iMap.getBigDecimal(tableName, i, "tutar"));
				clksBasvuruMutabakat.setSubeId(iMap.getString(tableName, i, "subeId"));
				clksBasvuruMutabakat.setMerkezId(iMap.getString(tableName, i, "merkezId"));
				
				if ( iMap.get("islemTarihi") != null ){
					clksBasvuruMutabakat.setIslemTarihi(iMap.getDate("islemTarihi"));
				}else{
					clksBasvuruMutabakat.setIslemTarihi(null);	
				}			
				session.saveOrUpdate(clksBasvuruMutabakat);
			}
			session.flush();
		   /*su an bizim gonderdigimiz liste kullanilmiyor ve listeyi bos gonderelim istediler.
			 Birde kayit sayisi PTT den farkliysa mesaj donelim istediler.BT-2133 */
			
			inputValues[j++] = BnsprType.DATE;
			inputValues[j++] = (iMap.get("islemTarihi") != null) ? iMap.getDate("islemTarihi") : null;
			
			j = 0;
			
			outputValues[j++] = BnsprType.REFCURSOR;
			outputValues[j++] = "krediMutabakatListOut";
			outputValues[j++] = BnsprType.NUMBER;
			outputValues[j++] = "CONTROL_MASK";
			
			oMap = (GMMap) DALUtil.callOracleProcedure("{ call PKG_PTT_MUTABAKAT.AGREEMENT_RESPONSE_KREDI(?,?,?)}", inputValues, outputValues);
			
			return oMap;
			
		} catch (ConstraintViolationException e) {
			logger.error("CLKS_PTT_CREDIT_AGREEMENT_NEW ConstraintViolationException err: " + e);
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw ExceptionHandler.convertException(new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE")));
		}catch (Exception e) {
			logger.error("CLKS_PTT_CREDIT_AGREEMENT_NEW err: " + e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
