package tr.com.aktifbank.bnspr.clks.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCardPaymentDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalElectronicFundTransferDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CardPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ElectronicFundTransfer;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.CardPaymentProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.ElectronicFundTransferProcess;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants.Transaction;
import tr.com.aktifbank.bnspr.dao.ClksUptHesapCekilenTx;
import tr.com.aktifbank.bnspr.dao.ClksUptHesapYatanTx;
import tr.com.aktifbank.kurumsalibank.util.ProcessLogUtils;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;
import tr.com.calikbank.bnspr.dao.ClksPftTx;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CLKSServices {

	private static final String Debit_Main_Account = "A";
	private static final String KART_KANAL_ATM = "7";
	private static final String KART_KANAL_GISE = "54";
	private static Logger logger = Logger.getLogger(CLKSServices.class);
	
	/**
	 * 
	 * Description : PTT'den asenkron olarak cagirilan servislerin hata almasi durumunda cagiracagi loglama servisi.
	 *
	 * @param iMap (GMMap)
	 *		{TX_NO, PTT_ISLEM_NO, DURUM_KODU, TUTAR, DOVIZ_KODU}
	 *
	 *	DURUM_KODU:
	 *	A: Onay
	 *	I: Iptal
	 *	L: Limit 
	 *
	 * @return oMap (GMMap)
	 *      {}
	 *
	 */
	@GraymoundService("CLKS_ISLEM_LOG")
	public static GMMap clksIslemLog(GMMap iMap) {

		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		java.io.ByteArrayInputStream stream = null;
		byte[] data = {};

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_ptt.log(?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			if(iMap.containsKey("DATA")) {
				data = (byte[]) iMap.get("DATA");
				stream = new java.io.ByteArrayInputStream(data);
			}

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("PTT_ISLEM_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, iMap.getString("PROCESS_CODE"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("KONUM"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SUBE_ID"));
			stmt.setString(i++, iMap.getString("PERSONEL_SICIL"));
			stmt.setString(i++, iMap.getString("PERSONEL_AD_SOYAD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM"));
			stmt.setString(i++, iMap.getString("ACIKLAMA"));
			stmt.setBinaryStream(i++, stream, data.length);
			stmt.execute();

		} catch(Exception e) {
			logger.error("CLKS_ISLEM_LOG err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			if(stream != null) {
				try {
					stream.close();
				} catch(IOException e) {
					logger.error("CLKS_ISLEM_LOG err:", e);
				}
			}
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("CLKS_GET_HESAP_MUSTERI_DETAY")
	public static GMMap getHesapMusteriDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call Pkg_ptt.hesap_musteri_detay_bilgi(?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(i++, iMap.getString("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DOVIZ_KOD"));
			stmt.setString(i++, iMap.getString("TCKN"));
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			if (rSet.next()) {
				int j = 1;
				oMap.put("MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put("TCNO", rSet.getString(j++));
				oMap.put("UNVAN", rSet.getString(j++));
				oMap.put("DOVIZ_KODU", rSet.getString(j++));
				oMap.put("SUBE_KODU", rSet.getString(j++));
				oMap.put("SUBE_ADI", rSet.getString(j++));
				oMap.put("ADRES", rSet.getString(j++));
				oMap.put("DOGUM_TARIHI", rSet.getDate(j++));
				oMap.put("BABA_ADI", rSet.getString(j++));
				oMap.put("TELEFON", rSet.getString(j++));
				oMap.put("HESAP_NO", rSet.getString(j++));
				oMap.put("IBAN", rSet.getString(j++));
			} else {
				GMMap hMap = new GMMap();
				hMap.put("HATA_NO", 201);
				hMap.put("P1", iMap.getBigDecimal("HESAP_NO"));
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", hMap);
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			//throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("CLKS_PTT_REFERANS_HAVALE_ODEME")
	public static GMMap pttReferansHavaleOdeme(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_PTT_REFERANS_ODEME.referansla_havale_odeme(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.setString(i++, iMap.getString("TCNO"));
			stmt.setString(i++, iMap.getString("VKNO"));
			stmt.execute();

			rSetMSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSetMSet);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}

	@GraymoundService("INTERNET_HAVALE_EFT_MAX_TUTAR_CONTROL")
	public static GMMap pttInternetMaxTutarControl(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_PTT.odemeMaxTutarControl(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("ERKEN_KAPAMA"));
			stmt.execute();

			oMap.put("ODEME_MAX_TUTAR_ONAY", stmt.getBigDecimal(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}

	@GraymoundService("CLKS_PTT_REFERANS_DETAY_BILGI")
	public static GMMap pttReferansDetayBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_PTT_REFERANS_ODEME.referans_detay_bilgi(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.execute();
			rSetMSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSetMSet);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("CLKS_ISLEM_IPTAL_YEDEKLE") // ba�ka class a al�nd�.
	public static GMMap islemIptalYedekle(GMMap iMap) {
		
		String islemKod = null;
		BigDecimal blokeTutari = BigDecimal.ZERO;
		GMMap oMap = new GMMap();
		
		// Reversal'da bloke tutari guncelleme, islem kodlari (0)
		String[] blokeGuncelList = {
			Transaction.ATM_NAKIT_YATAN.toString()
		};
		
		try {

			islemKod = (String) DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_kod(?)}", Types.VARCHAR, iMap.getBigDecimal("islemNo"));
			
			// Case: Kart islemleri haric gise iptal talepleri + "UPT Odeme" reversal talepleri
			if (ClksConstants.IPTAL_GISE.equals(iMap.getString("iptalTip"))) {

				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO", "HesapIslemleri@calikbank.com.tr");
				mailMap.put("TRX_NO", iMap.getString("islemNo"));
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "PTT Islem Iptali ");
				mailMap.put("MAIL_BODY", iMap.getString("islemNo") + " numarali islem iptal edilmistir");
				mailMap.put("IS_BODY_HTML", "H");
				GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);

				// Process altyapisini kullanan islemler
				String[] pList = {
					Transaction.NAKIT_YATAN.toString(),
					Transaction.NAKIT_CEKILEN.toString(),
					Transaction.HAVALE_ODEME.toString(),
					Transaction.HAVALE.toString(),
					Transaction.EFT.toString(),
					Transaction.YP_TRANSFER.toString(),
					Transaction.UPT_ODEME.toString()
				};
				
				// UPT entegrasyonunda kullanilan islemler
				String[] pUptList = {
					Transaction.UPT_ODEME.toString(),
					Transaction.UPT_TALIMAT.toString(),
					Transaction.YP_TRANSFER.toString()
				};
				
				// UPT Nakit Yatirma Cekme Islem Kodlari
                String[] pUPTYatirmaCekmeList = {
                	Transaction.UPT_NAKIT_YATAN.toString(),
                	Transaction.UPT_NAKIT_CEKILEN.toString()
                };
                
				
				// Process bilgisini geri cevirelim
				for(String pKod : pList) {
					if(pKod.equals(islemKod)) {
						ProcessLogUtils.createReverseProcessLog(new GMMap().put("ISLEM_NO", iMap.getString("islemNo")));
						break;
					}
				}
				
				// Case: UPT A.S. islemleri
				for(String pKod : pUptList) {
					if(pKod.equals(islemKod)) {
						
						Object[] inputVals = {
							BnsprType.STRING, islemKod,
							BnsprType.NUMBER, iMap.getBigDecimal("islemNo")
						};
						
						Object[] outputVals = {
							BnsprType.STRING, "UPT_ISLEMI",
							BnsprType.STRING, "REFERANS",
							BnsprType.STRING, "ISLEM",
							BnsprType.STRING, "MUHASEBE_ISLEM_NO"
						};
						
						iMap.putAll((GMMap) DALUtil.callOracleProcedure("{call pkg_ypupt.tu_islemmi(?,?,?,?,?,?)}", inputVals, outputVals));
						
						if ("E".equals(iMap.getString("UPT_ISLEMI"))) {
							
							if (Transaction.UPT_TALIMAT.toString().equals(islemKod)) {
								iMap.put("ISLEMNO", iMap.getBigDecimal("MUHASEBE_ISLEM_NO"));
							}
							
						    oMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("ISLEMNO"));
						    oMap.put("TU_REFERANS", iMap.getString("REFERANS"));
						    oMap.put("ISLEM_TIP", iMap.getString("ISLEM"));
						    oMap.put("BRANCH_ID", iMap.getString("ISLEMYERI"));
						    oMap.put("USER_ID", iMap.getString("KULLANICISICIL"));
						    oMap.put("USER_NAME", iMap.getString("KULLANICISICIL"));
						    

					    	GMServiceExecuter.call("BNSPR_TU_CANCEL_REQUEST", oMap.put("F_ASYNC", true));
							GMServiceExecuter.executeAsync("BNSPR_TU_CANCEL_PROCESS", oMap.put("F_ASYNC", true));
						    
						}
						
						oMap.clear();
						break;						
					}
				}
				
				
                // Case: UPT Para Yatirma/Cekme Islemleri
                for (String pKod : pUPTYatirmaCekmeList) {
                    if (pKod.equals(islemKod)) {
                        Session session = DAOSession.getSession("BNSPRDal");
                        if (Transaction.UPT_NAKIT_YATAN.toString().equals(islemKod)) {

                            ClksUptHesapYatanTx cY = (ClksUptHesapYatanTx) session.get(ClksUptHesapYatanTx.class, iMap.getBigDecimal("islemNo"));

                            // oMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("islemNo"));
                            oMap.put("REFERENCE", cY.getReferansNo());
                        }
                        else if (Transaction.UPT_NAKIT_CEKILEN.toString().equals(islemKod)) {
                            ClksUptHesapCekilenTx cC = (ClksUptHesapCekilenTx) session.get(ClksUptHesapCekilenTx.class, iMap.getBigDecimal("islemNo"));

                            // oMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("islemNo"));
                            oMap.put("REFERENCE", cC.getReferansNo());
                        }

                        // boolean isCancelable = GMServiceExecuter.call("BNSPR_TU_CANCEL_CHECK", oMap).getBoolean("IS_CANCELABLE");
                        oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CANCEL_CUST_ACCOUNT_TRANSACTION", oMap));
                    }
                }
                
				/* �lgili i�lem tiplerinde iptal i�in limit kontrol� yap�lacak */
				String[] controlList = {
					Transaction.KART_PASSO_YATAN.toString()
				};

				for(String pKod : controlList) {
				    if(pKod.equals(islemKod))
					GMServiceExecuter.call("TFF_KART_IPTAL_LIMIT_KONTROL", iMap);
				}
				
				
			}

			// Case: Vazgec talepleri
			else if (ClksConstants.IPTAL_VAZGEC.equals(iMap.getString("iptalTip"))) {
				
				Object[] inputVals = {
					BnsprType.NUMBER, iMap.getBigDecimal("islemNo")
				};
				
				DALUtil.callOracleProcedure("{ call PKG_PTT.islemIptalEdilebilirmiVazgec(?)}", inputVals,  new Object[0]);
			}
			
			// Case: Reversal talepleri - "Kart" reversal talepleri
			// TODO: Reversal akislari icin bu case'i kullanalim.
			else if (ClksConstants.REVERSAL.equals(iMap.getString("iptalTip"))) {
				
				// Process altyapisini kullanan islemler
				String[] pList = {
					Transaction.ATM_KART_PASSO.toString(),
					Transaction.KART_PASSO_YATAN.toString(),
					Transaction.ATM_NAKIT_YATAN.toString()
				};
				
				// Process bilgisini geri cevirelim
				for(String pKod : pList) {
					if(pKod.equals(islemKod)) {
						ProcessLogUtils.createReverseProcessLog(new GMMap().put("ISLEM_NO", iMap.getString("islemNo")));
						break;
					}
				}
				
				Session session = DAOSession.getSession("BNSPRDal");
				ClksHavaleGirisTx clTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("islemNo"));
				clTx.setFReversal("E");
				
				// Bloke tutari guncellemesi (0)
				for(String blokeGuncelKod : blokeGuncelList) {
					if(blokeGuncelKod.equals(islemKod)) {
						blokeTutari = (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_trn2049.Hesap_Bloke_Guncelle(?,?)}", BnsprType.NUMBER, BnsprType.NUMBER, iMap.getBigDecimal("islemNo"), BnsprType.NUMBER, null);
						break;
					}
				}
				
				session.update(clTx);
				session.flush();
			}
			
			Object[] inputVals = {
				BnsprType.NUMBER, iMap.getBigDecimal("islemNo"),
				BnsprType.STRING, iMap.getString("islemYeri"),
				BnsprType.STRING, iMap.getString("kullaniciSicil"),
				BnsprType.STRING, iMap.getString("iptaliYapanKullAdSoyad")
			};
			
			DALUtil.callOracleProcedure("{call PKG_PTT.islem_iptal_bilgi_yedekle(?,?,?,?)}", inputVals, new Object[0]);
			iMap.put("ISLEM_DURUM", DALUtil.callOneParameterFunction("{ ? = call pkg_tx.islem_durum(?)}", Types.VARCHAR, iMap.getBigDecimal("islemNo")));
			
			oMap.put("ISLEM_NO", iMap.getString("islemNo"))
				.put("ISLEM_KODU", islemKod).put("ISLEM_TURU", "I")
				.put("ACIKLAMA", iMap.getString("aciklama"));
			
			oMap.putAll(GMServiceExecuter.call("CLKS_GET_ISLEM_NO", oMap));

			if ("C".equals(iMap.getString("ISLEM_DURUM"))) {
				oMap.put("ISLEM_TURU", "OR");
			}
			
			String tableName = "RC_TX_NO_LIST";
			List<?> list = (List<?>) oMap.get(tableName);

			if (list != null) {
				
				for (int i = list.size() - 1; i >= 0; i--) {
					oMap.put("ISLEM_NO", oMap.getBigDecimal("RC_TX_NO_LIST", i, "ISLEM_NO"));
					
					// Case: Islem yaratilmis ve tamamlanmis ise iptal edelim, aksi durumda Havale islemini engellemesin
					if(((BigDecimal)DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_yaratilmis_mi(?)}", Types.NUMERIC, oMap.getBigDecimal("ISLEM_NO"))).equals(new BigDecimal(1)) &&
							((GMMap) GMServiceExecuter.call("BNSPR_ISLEM_BITMIS_MI", new GMMap().put("TRX_NO", oMap.getBigDecimal("ISLEM_NO")))).getBigDecimal("ISLEM_BITMIS").equals(new BigDecimal(1))) {
						GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", oMap);
					}
				}
			}

			oMap.put("ISLEM_NO", iMap.getString("islemNo")); // orjinal numara geri getiriliyor
			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", oMap);
			
			// Case: Reversal talepleri - "Kart" reversal talepleri
			if (ClksConstants.REVERSAL.equals(iMap.getString("iptalTip"))) {
				
				// Bloke tutari guncellemesi (0)
				for(String blokeGuncelKod : blokeGuncelList) {
					if(blokeGuncelKod.equals(islemKod)) {
						DALUtil.callOracleFunction("{? = call pkg_trn2049.Hesap_Bloke_Guncelle(?,?)}", BnsprType.NUMBER, BnsprType.NUMBER, iMap.getBigDecimal("islemNo"), BnsprType.NUMBER, blokeTutari);
						break;
					}
				}
			}
			
			if (islemKod.equals(Transaction.HAVALE.toString())){
			    BigDecimal islemNo = iMap.getBigDecimal("islemNo");
			    		String basvuruNoAndNewTx = (String) DALUtil.callOracleFunction("{? = call Pkg_TRN2030.KullandirimBasvuruNoGetir(?)}", BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal("islemNo"));
						logger.info("KREDI KULLANDIRIM IPTAL ISLEMI : islem No:" + islemNo + "Basvuru No ve Yeni TxNo :" + basvuruNoAndNewTx  );

						if (basvuruNoAndNewTx !=null){
							String[] parts = basvuruNoAndNewTx.split(",");	
							if (parts.length==2){
								GMMap basvuruNoMap = new GMMap(); 
								basvuruNoMap.put("BASVURU_NO", new BigDecimal(parts[0]));
								basvuruNoMap.put("TX_NO", new BigDecimal(parts[1]));
								basvuruNoMap.put("YENI_DURUM", "IPTAL");
								basvuruNoMap.put("ACIKLAMA", "PTT iptal ekran�ndan kullandirim iptal edildi.");
								basvuruNoMap.putAll(GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_REVERT_PENDING_APPLICATION", basvuruNoMap));
							}
							
						}
				}
			
			
		} catch (Exception e) {
			logger.error("CLKS_ISLEM_IPTAL_YEDEKLE err: "+ e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	
    @GraymoundService("TFF_KART_IPTAL_LIMIT_KONTROL")
    public static GMMap tffKartIptalLimitKontrol(GMMap iMap) {
	try {
	    GMMap oMap = new GMMap();
	    oMap.put("PARAMETRE", "PTT_TFF_KART_ODEME_IPTAL_LIMIT");
	    BigDecimal limit = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N" , oMap).getBigDecimal("DEGER");
		    
	    Session session = DAOSession.getSession("BNSPRDal");
	    ClksHavaleGirisTx clTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("islemNo"));
	       
	    if (clTx.getTutar().compareTo(limit) != -1) {
		iMap.put("HATA_NO", new BigDecimal(5200));
		iMap.put("P1", limit);
		return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	    }
	    session.flush();
	    return iMap;
	} catch (Exception e) {
	    throw ExceptionHandler.convertException(e);
	} finally {

	}
    }
	
	
	@GraymoundService("CLKS_KREDI_TUTARI_ODEME")
	public static GMMap ClksKrediTutariOdeme(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		try {
			
			oMap = DALUtil.callOracleRefCursorFunction("{ ? = call pkg_ptt.basvurunolu_havale_odeme(?)}", "LIST", BnsprType.STRING, iMap.getString("BASVURU_NO"));
			
			@SuppressWarnings("unchecked")
			List<GMMap> list = (ArrayList<GMMap>) oMap.get("LIST");
			oMap = new GMMap(list.get(0));
			
		} catch (ClassCastException e) {
			GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1488).put("P1", iMap.getString("BASVURU_NO")));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("CLKS_2030_PTT_ISLEM_BILGISI_GUNCELLE")
	public static GMMap clks2030PttIslemBilgisiGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN2030_PTT_ISLEM_BILGISI_GUNCELLE", iMap));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CLKS_GET_OTP_TEL_AND_MESAJ_KOSULLU")
	public static GMMap getOTPTel(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_PTT.pttGetOtpTelWithTxNoKosullu(?)}");
			int i = 1;
			//stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));

			stmt.execute();

			oMap.put("MSISDN", stmt.getString(1));

			//oMap.put("MSISDN", "+905055821826");

			oMap.put(
					"CONTENT",
					"PTT subesinden yapmis oldugunuz "
							+ "Nakit Cekme isleminiz Kredili Hesap limitiniz kullanilarak gerceklestirilmistir.");

			oMap.put("CHANNEL", "7");

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CLKS_GET_ISLEM_NO")
	public static GMMap pttilemTamamlanmismi(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_PTT.getislemTxNo(?)}");
			stmt.registerOutParameter(1, -10);
			//stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));
			//stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			oMap = DALUtil.rSetResults(rSet, "RC_TX_NO_LIST");

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CLKS_HESAP_DOVIZ_KOD_KONTROL")
	public static GMMap HesapDovizKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getString("BORCHESAPNO") != null
					&& iMap.getString("BORCHESAPNO").equals("0")) {
				iMap.put("HATA_NO", new BigDecimal(1530));
				//iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO") );
				return (GMMap) GMServiceExecuter.execute(
						"BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

		}
	}

	@GraymoundService("CLKS_ISLEM_IPTAL_EDILEBILIRMI") // ba�ka class a al�nd�.
	public static GMMap iptalEdilebilirmi(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {

			String islemKod = (String) DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_kod(?)}", Types.VARCHAR, iMap.getBigDecimal("ISLEMNO"));	
			DALUtil.callOracleFunction("{ ? = call PKG_PTT.islemIptalEdilebilirmi(?)}", BnsprType.STRING, new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("ISLEMNO")});
			
			oMap.putAll(GMServiceExecuter.call("CLKS_EFT_IPTAL_ONAY", iMap));
				
			GMMap sMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_YPUPT.TU_IslemMi(?,?,?,?,?,?)}",
				new Object[]{
					BnsprType.STRING, islemKod,
					BnsprType.NUMBER, iMap.getBigDecimal("ISLEMNO")
				}, new Object[]{
					BnsprType.STRING, "F_UPT",
					BnsprType.STRING, "TU_REFERANS",
					BnsprType.STRING, "ISLEM_TIP",
					BnsprType.NUMBER, "BANKA_ISLEM_NO"
			});
			sMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("ISLEMNO"));
			
			if ("E".equals(sMap.getString("F_UPT"))) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CANCEL_CHECK", sMap));
				if(!oMap.getBoolean("IS_CANCELABLE")) {
					throw new GMRuntimeException(0, oMap.getString("RESPONSE_DATA"), true);
				}
			} 

			if("2050".equals(islemKod)) {
				Session session = DAOSession.getSession("BNSPRDal");
				Criteria cr = session.createCriteria(ClksHavaleGirisTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("islemNo")));
				ClksHavaleGirisTx tx = (ClksHavaleGirisTx) cr.uniqueResult();  
				iMap.put("MUSTERI_NO", tx.getAliciMusteriNo());
				if("1".equals(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", iMap).getString("F_MUSTERI_BLOKE"))) {
					iMap.put("HATA_NO", new BigDecimal(1676));
					iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
					return (GMMap) GMServiceExecuter.execute(
							"BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_PTT_TUTAR_BILGISI_GUNCELLE")
	public static GMMap pttIslemBilgisiGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ call PKG_TRN2050.PTT_tutar_bilgisi_guncelle(?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEMNO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("tutar"));
			stmt.execute();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CLKS_BILGI_TUTARLILIK_KONTROL")
	public static GMMap ClksTcknMusteriNoBasvuruNoKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_PTT.TcknBasvuruNoMusteriNoKontrol(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setString(i++, iMap.getString("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TCNO"));
			stmt.setString(i++, iMap.getString("MUSTERI_NO"));
			stmt.execute();

			//rSetMSet= (ResultSet)stmt.getObject(1);
			//oMap = DALUtil.rSetMap(rSetMSet);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("CLKS_PFT_GET_TX_TCKN")
	public static Map<?, ?> getTransactionTckn(GMMap iMap) {
		
		try
		{
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria cr = session.createCriteria(ClksPftTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TX_NO")));
			ClksPftTx tx = (ClksPftTx) cr.uniqueResult();
			GMMap oMap = new GMMap();
			oMap.put("TCKN",tx.getTcKimlikNo());
			oMap.put("YKN",tx.getYabanciKimlikNo());
			oMap.put("VKN",tx.getVergiKimlikNo());
			oMap.put("KIMLIK_NO", tx.getKimlikNo());
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
	}
	
	@GraymoundService("CLKS_PFT_SAVE_OR_UPDATE")
	public static GMMap eftSave(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			ClksPftTx clksPftTx = (ClksPftTx) session.get(ClksPftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if (clksPftTx == null) {
				clksPftTx = new ClksPftTx();
			}
			
			clksPftTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			
			if ("1".equals(iMap.getString("SAVE"))) {

				clksPftTx.setUyruk(iMap.getString("uyruk"));
				clksPftTx.setVergiKimlikNo(iMap.getString("vergiKimlikNo"));
				clksPftTx.setYabanciKimlikNo(iMap.getString("yabanciKimlikNo"));
				clksPftTx.setKimlikTuru(iMap.getString("kimlikTuru"));
				clksPftTx.setKimlikNo(iMap.getString("kimlikNo"));
				clksPftTx.setTcKimlikNo(iMap.getString("tcNo"));
				clksPftTx.setGonderenAdi(iMap.getString("gonderenAdSoyad"));
				clksPftTx.setGonderenTelefon(iMap.getString("gonderenTelefon"));
				
				if (iMap.getString("islem").compareTo("P") == 0) {
					clksPftTx.setPostaCekHesapNo(iMap.getBigDecimal("hesapNo"));
					clksPftTx.setIslem(new BigDecimal(ClksConstants.ISLEM_UPT_PCH));
				} else if(iMap.getString("islem").compareTo("I") == 0){
					clksPftTx.setPostaCekHesapNo(iMap.getBigDecimal("hesapNo"));
					clksPftTx.setIslem(new BigDecimal(ClksConstants.ISLEM_UPT_IPC));
				} else {
					clksPftTx.setGonderenHesapNo(iMap.getBigDecimal("hesapNo"));
					clksPftTx.setIslem(new BigDecimal(ClksConstants.ISLEM_UPT));
				}
				
				//imap islem p geldi�inde  posta_cek_hesap_no =hesapNo ekleneicek 
				//islem de�eri "P" gelirse 70 atal�m, ba�ka bir de�er gelirse ise 10 atal�m
				//clksPftTx.setGonderenHesapNo(iMap.getBigDecimal("hesapNo"));
				
				clksPftTx.setMusteriNo(iMap.getBigDecimal("musteriNo"));
				clksPftTx.setGonderenBabaAdi(iMap.getString("gonderenBabaAdi"));
				clksPftTx.setGonderenAnneAdi(iMap.getString("gonderenAnneAdi"));
				clksPftTx.setGonderenAdres(iMap.getString("gonderenAdres"));
				clksPftTx.setOdemeTuru(iMap.getString("odemeTuru"));

				if (iMap.get("gonderenDogumTarihi") != null
						&& !"null".equals(iMap.getString("gonderenDogumTarihi"))
						&& !iMap.getString("gonderenDogumTarihi").isEmpty()) {
					clksPftTx.setGonderenDogumTar(iMap.getDate("gonderenDogumTarihi"));
				}
				else {
					clksPftTx.setGonderenDogumTar(null);
				}
				
				clksPftTx.setGonderenDogumYeri(iMap.getString("gonderenDogumYeri"));
				clksPftTx.setGonderenMeslek(iMap.getString("gonderenMeslek"));
				clksPftTx.setAliciTipi(iMap.getString("aliciTipi"));
				clksPftTx.setTutar(iMap.getBigDecimal("tutar"));
				clksPftTx.setGelenGiden("GIDEN");
				clksPftTx.setMesajKodu(iMap.getString("mesajKodu"));
				clksPftTx.setMasraf(iMap.getBigDecimal("MASRAFTUTARI"));
				clksPftTx.setKpsYapildi(iMap.getString("kpsBasarilimi"));
				clksPftTx.setIsleminYapildigiYer(iMap.getString("islemYeri"));
				clksPftTx.setIslemiYapanKullanici(iMap.getString("kullaniciSicil"));
				clksPftTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
				clksPftTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
				clksPftTx.setMerkezSubeBasmudurluk(iMap.getString("MERKEZ_SUBE_BASMUDURLUK"));
				clksPftTx.setIsleminYapildigiBasmudurluk(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				clksPftTx.setMerkezId(iMap.getString("MERKEZ_ID"));
				clksPftTx.setSubeId(iMap.getString("SUBE_ID"));
				clksPftTx.setIslemiYapanKullAdsoyad(iMap.getString("ISLEMI_YAPAN_KULLANICI_ADSOYAD"));
			}

			else if ("0".equals(iMap.getString("SAVE"))) {

				clksPftTx.setAliciAdi(iMap.getString("aliciAdSoyad"));
				clksPftTx.setAlanBankaKodu(iMap.getString("aliciBankaKodu"));
				clksPftTx.setAlanIlKodu(iMap.getString("aliciIlKodu"));
				clksPftTx.setAlanSubeKodu(iMap.getString("aliciSubeKodu"));
				clksPftTx.setAliciBabaAdi(iMap.getString("aliciBabaAdi"));

				if (iMap.get("aliciDogumTarihi") != null
						&& !"null".equals(iMap.getString("aliciDogumTarihi"))
						&& !iMap.getString("aliciDogumTarihi").isEmpty()) {
					clksPftTx.setAliciDogumTar(iMap.getDate("aliciDogumTarihi"));
				}
				else {
					clksPftTx.setAliciDogumTar(null);
				}
				
				if (iMap.get("aliciKurulusTarihi") != null
						&& !"null".equals(iMap.getString("aliciKurulusTarihi"))
						&& !iMap.getString("aliciKurulusTarihi").isEmpty()) {
					clksPftTx.setKurulusTar(iMap.getDate("aliciKurulusTarihi"));
				}
				else {
					clksPftTx.setKurulusTar(null);
				}
				
				clksPftTx.setAliciTelefon(iMap.getString("aliciTelefonNo"));
				clksPftTx.setAliciAdres(iMap.getString("aliciAdresi"));
				clksPftTx.setAliciHesapNo(iMap.getString("aliciHesapNumarasi"));
				clksPftTx.setAliciIban(iMap.getString("aliciIBAN"));
				clksPftTx.setAliciKartNo(iMap.getString("aliciKartNumarasi"));
				clksPftTx.setAciklama(iMap.getString("aciklama"));
				clksPftTx.setIadeTercihi(iMap.getString("iadeTercihi"));
				
				if (iMap.getString("evrakAlindimi") != null && iMap.getString("evrakAlindimi").compareTo("E") == 0) {
					clksPftTx.setBelgeAlindi(iMap.getString("evrakAlindimi"));
				}
				else {
					clksPftTx.setBelgeAlindi("H");
				}
				clksPftTx.setIbanBiliniyormu(iMap.getString("ibanBiliniyormu"));
				
				if(iMap.get("gonderenTelefon") != null && !iMap.getString("gonderenTelefon").isEmpty()) {
					clksPftTx.setGonderenTelefon(iMap.getString("gonderenTelefon"));
				}
			}

			else if ("2".equals(iMap.getString("SAVE"))) {
				
				clksPftTx.setPttIslemNo(iMap.getBigDecimal("islemNoPTT"));
			}

			session.saveOrUpdate(clksPftTx);
			session.flush();

			return iMap;
		} catch (Exception e) {
			logger.error("CLKS_PFT_SAVE_OR_UPDATE err: " + e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CLKS_INITIAL_KONTROL_AND_GET_DATA")
	public static GMMap ClksInitialKontrolAndGetData(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_PFT.PFT_Kontrol_1(?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, Types.DATE);

			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.execute();
			rSetMSet = (ResultSet) stmt.getObject(2);

			oMap.put("eftTarih", stmt.getDate(3));

			oMap.put("IBAN", stmt.getString(4));

			oMap.putAll(DALUtil.rSetResults(rSetMSet, "evrakListe"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("CLKS_KONTROL_AND_GET_DATA")
	public static GMMap ClksKontrolAndGetData(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ call PKG_PFT.PFT_Kontrol_2(?,?,?,?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("GONDERENHESAPNO"));
			stmt.registerOutParameter(3, Types.DATE);
			stmt.registerOutParameter(4, Types.NUMERIC);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			stmt.registerOutParameter(9, Types.VARCHAR);
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.execute();
			oMap.put("transferTarihi", stmt.getDate(3));
			oMap.put("sorguNumarasi", stmt.getBigDecimal(4));
			oMap.put("bankaKodu", stmt.getString(5));
			oMap.put("bankaAdi", stmt.getString(6));
			oMap.put("tcNo", stmt.getString(7));
			oMap.put("yabanciKimlikNo", stmt.getString(8));
			oMap.put("vergiKimlikNo", stmt.getString(9));
			oMap.put("islem", stmt.getString(10));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_EFT_TX_AKTAR")
	public static GMMap ClksEftTxAktar(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			
			TransactionDao<ElectronicFundTransfer> dao = new DalElectronicFundTransferDao();
			ElectronicFundTransfer transfer = dao.get(iMap.getBigDecimal("TRX_NO"));
	    	
	    	TransactionProcess<ElectronicFundTransfer> process = new ElectronicFundTransferProcess(dao);
	    	process.confirm(transfer);
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_PFT.EFT_Tx_Aktar(?,?)}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("GONDERENHESAPNO"));

			stmt.execute();
						
			oMap.put("SORGUNO", stmt.getBigDecimal(1));
			
			Session session = DAOSession.getSession("BNSPRDal");
			EftEftTx eftEftTx = (EftEftTx) session.get(EftEftTx.class,iMap.getBigDecimal("TRX_NO"));
			ClksPftTx clksPftTx = (ClksPftTx) session.get(ClksPftTx.class,iMap.getBigDecimal("TRX_NO"));
			
			GMMap amlMap = new GMMap(); 
			amlMap.put("ALAN_BANKA", DALUtil.callOneParameterFunction("{? = call pkg_genel_pr.banka_adi_al_eft_hatasiz(?)}", Types.VARCHAR, 
					eftEftTx.getAlanBankaKodu()));
			amlMap.put("GONDEREN", eftEftTx.getGonderen());
			amlMap.put("MUSTERI_NO", clksPftTx.getMusteriNo());
			amlMap.put("ACIKLAMA", eftEftTx.getAciklama());
			amlMap.put("ALICI", eftEftTx.getAliciAdi());
			amlMap.put("TUTAR", eftEftTx.getTutar());
			amlMap.put("EFT_TARIH", eftEftTx.getEftTarih());
			amlMap.put("TRX_NO", eftEftTx.getTxNo());
			amlMap.put("TRX_NAME", "23157");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2315_EFT_PAYGATE_CHECK", amlMap));

			iMap.put("TRX_NAME", "2315");
			
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_PFT_LISTESI")
	public static GMMap clksPFTList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_RC_PFT.GET_EFT_LIST(?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			stmt.setBigDecimal(i++, null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("sorguNo"));
			stmt.setBigDecimal(i++, null);
			stmt.setBigDecimal(i++, null);
			stmt.setString(i++, iMap.getString("durum"));

			if (iMap.getString("tarihBas").compareTo("") != 0)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("tarihBas")
						.getTime()));
			else
				stmt.setDate(i++, null);

			if (iMap.getString("tarihSon").compareTo("") != 0)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("tarihSon")
						.getTime()));
			else
				stmt.setDate(i++, null);

			//stmt.setString(i++, iMap.getString("tarihBas"));
			//stmt.setString(i++, iMap.getString("tarihSon"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("tckn"));
			stmt.setBigDecimal(i++, null);
			stmt.setBigDecimal(i++, null);
			stmt.setBigDecimal(i++, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "islemListesi");
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_BANKA_LIST")
	public static GMMap clksBankaList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_PFT.BANKA_KOD_GUNCELLEMELERI}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "islemListesi");
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_SUBE_LIST")
	public static GMMap clksSubeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_PFT.BANKA_SUBE_GUNCELLEMELERI}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "islemListesi");
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_EFT_IPTAL_ONAY")
	public static GMMap clksEftIptalOnay(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_PTT.EftIptalOnayVarmi(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEMNO"));

			stmt.execute();

			oMap.put("aciklama", stmt.getString(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CLKS_HESAP_NO_PTT")
	public static GMMap clksHesapNoPtt(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_PTT.ptt_hesap(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setString(i++, iMap.getString("dovizKodu"));
			stmt.setString(i++, iMap.getString("tip_islem"));

			stmt.execute();
			oMap.put("GONDERENHESAPNO", stmt.getBigDecimal(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CLKS_GET_PFT_AMOUNT_AND_AMOUND_CODE")
	public static GMMap clksGetAmountAndAmoundCode(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_PFT.Pft_Get_Amount_Amount_Code(?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.VARCHAR);

			stmt.execute();
			oMap.put("TUTAR", stmt.getBigDecimal(2));
			oMap.put("TUTAR_CODE", stmt.getString(3));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CLKS_GET_CUSTOMER_NO_REQUEST")
	public static GMMap clksGetCustomerNoRequest(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_PTT.GetMusteriNoRequest(?,?,?,?,?)}");
			int i = 1;
			stmt.setString(i++, iMap.getString("islemTuru"));
			stmt.setString(i++, iMap.getString("islemTipi"));
			stmt.setString(i++, iMap.getString("ReferansNo"));
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);

			stmt.execute();

			oMap.put("MUSTERI_NO", stmt.getString(4));

			oMap.put("CLKS_USER_TYPE", stmt.getString(5));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CLKS_GET_CUSTOMER_NO_CONFIRM")
	public static GMMap clksGetCustomerNoConfirm(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_PTT.GetMusteriNoConfirm(?,?,?,?)}");
			int i = 1;

			stmt.setString(i++, iMap.getString("islemTuru"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);

			stmt.execute();
			oMap.put("MUSTERI_NO", stmt.getString(3));
			oMap.put("TCKN_MI", stmt.getString(4));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_HESAP_NO_PTT_PFT")
	public static GMMap clksHesapNoPttPft(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			ClksPftTx clksPftTx = (ClksPftTx) session.get(ClksPftTx.class, iMap.getBigDecimal("islemNo"));
			
			if (clksPftTx == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "ISLEM");
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			// Case: Nakit
			if(ClksConstants.ISLEM_UPT == clksPftTx.getIslem().intValue()) {
				oMap.put("GONDERENHESAPNO", DALUtil.callNoParameterFunction("{ ? = call PKG_PFT.PTT_PFT_Hesap}", Types.NUMERIC));
			}
			
			// Case: Posta Ceki Hesabi
			else if(ClksConstants.ISLEM_UPT_PCH == clksPftTx.getIslem().intValue() ||
					ClksConstants.ISLEM_UPT_IPC == clksPftTx.getIslem().intValue()) {
				oMap.put("GONDERENHESAPNO", DALUtil.callNoParameterFunction("{ ? = call PKG_PFT.PTT_PFT_PCH_Hesap}", Types.NUMERIC));
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("TRANSFER_LOG_AT")
	public static GMMap TransferLogAt(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_PTT.Transfer_Log_At(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.setString(i++, iMap.getString("aciklama"));
			stmt.setString(i++, iMap.getString("hesapNo"));
			stmt.setString(i++, iMap.getString("islem"));
			stmt.setString(i++, iMap.getString("islemiYapanAdSoyad"));
			stmt.setString(i++, iMap.getString("islemiYapanTCVKNO"));
			stmt.setString(i++, iMap.getString("islemiYapanTelefonNo"));
			stmt.setString(i++, iMap.getString("islemYeri"));
			stmt.setString(i++, iMap.getString("kullaniciSicil"));
			stmt.setString(i++, iMap.getString("musteriNo"));
			stmt.setString(i++, iMap.getString("tcNo"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("tutar"));
			stmt.setDate(
					i++,
					new Date(GMServiceExecuter
							.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap())
							.getDate("BANKA_TARIH").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNoPTT"));

			stmt.execute();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("PAYMENT_LOG_AT")
	public static GMMap PaymentLogAt(GMMap iMap) {

		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		//GMMap oMap = new GMMap();
		try {

			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH",
					new GMMap()));

			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_PTT.Payment_Log_At(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.setString(i++, iMap.getString("aciklama"));
			stmt.setString(i++, iMap.getString("hesapNo"));
			stmt.setString(i++, iMap.getString("islem"));
			stmt.setString(i++, iMap.getString("islemYeri"));
			stmt.setString(i++, iMap.getString("kullaniciSicil"));
			stmt.setString(i++, iMap.getString("musteriNo"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("tutar"));
			stmt.setString(i++, iMap.getString("aliciAdres"));
			stmt.setString(i++, iMap.getString("aliciAdSoyad"));
			stmt.setString(i++, iMap.getString("aliciAnneAd"));
			stmt.setString(i++, iMap.getString("aliciBabaAd"));
			stmt.setString(i++, iMap.getString("aliciTCVKNo"));
			stmt.setString(i++, iMap.getString("aliciTelefon"));
			stmt.setString(i++, iMap.getString("aliciBabaAd"));
			stmt.setString(i++, iMap.getString("tcNo"));
			stmt.setDate(
					i++,
					new Date(GMServiceExecuter
							.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap())
							.getDate("BANKA_TARIH").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNoPTT"));

			stmt.execute();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("UPT_LOG_AT")
	public static GMMap UptLogAt(GMMap iMap) {

		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		//GMMap oMap = new GMMap();
		try {

			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH",
					new GMMap()));

			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_PTT.UPT_Log_At(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.setString(i++, iMap.getString("TCKNVKN"));
			stmt.setString(i++, iMap.getString("aliciTelefonNumarasi"));
			stmt.setString(i++, iMap.getString("aliciAdres"));
			stmt.setString(i++, iMap.getString("aliciMeslek"));

			if (iMap.get("aliciDogumTarihi") != null
					&& !"null".equals(iMap.getString("aliciDogumTarihi"))
					&& iMap.getString("aliciDogumTarihi").length() != 0)
				stmt.setDate(i++,
						new java.sql.Date(iMap.getDate("aliciDogumTarihi")
								.getTime()));
			//iMap.getDate("gonderenDogumTarihi")
			else
				stmt.setDate(i++, null);

			stmt.setString(i++, iMap.getString("aliciAdSoyad"));
			stmt.setString(i++, iMap.getString("aliciBabaAdi"));
			stmt.setString(i++, iMap.getString("aliciAnneAdi"));

			stmt.setString(i++, iMap.getString("aliciDogumYeri"));

			stmt.setString(i++, iMap.getString("aliciKimlikBelgeNumarasi"));
			stmt.setString(i++, iMap.getString("KPSYapildimi"));
			stmt.setString(i++, iMap.getString("islemNoPTT"));
			stmt.setDate(
					i++,
					new Date(GMServiceExecuter
							.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap())
							.getDate("BANKA_TARIH").getTime()));
			stmt.execute();
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}


	@GraymoundService("PTT_IPTAL_LOG_AT")
	public static GMMap pttFaturaIptalLogAt(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT.Cancel_Log_At(?,?,?,?,?,?,?)}");

			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BANKA_ISLEM_NO"));
			stmt.setString(i++, iMap.getString("ISLEM_YERI"));
			stmt.setString(i++, iMap.getString("KULLANICI_SICIL"));
			stmt.setString(i++, iMap.getString("ACIKLAMA"));
			stmt.setDate(i++, iMap.getDate("ISLEM_TARIHI") != null ? new java.sql.Date(iMap.getDate("ISLEM_TARIHI").getTime()) : null);
			stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SIRA_NO"));

			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("PFT_LOG_AT")
	public static GMMap PftLogAt(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH",
					new GMMap()));
			//.getDate("BANKA_TARIH");
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PFT.Pft_Log_At(?,?,?)}");
			int i = 1;
			//stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNoPTT"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.setDate(i++, new Date(oMap.getDate("BANKA_TARIH").getTime()));
			stmt.execute();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CANCEL_LOG_AT")
	public static GMMap CancelLogAt(GMMap iMap) {

		GMMap oMap = new GMMap();
		boolean asyncCancel = true;

		try {

			String islemKod = (String) DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_kod(?)}", Types.VARCHAR, iMap.getBigDecimal("islemNo"));
			
			// Senkron Islem Tipleri
			String[] pList = {
				Transaction.KART_PASSO_YATAN.toString()
			};
			
			// Senkron iptal mi?
			for(String pKod : pList) {
				if(pKod.equals(islemKod)) {
					asyncCancel = false;
					break;
				}
			}
			
			// Case: Asenkron iptaller icin log atilsin
			if(asyncCancel)  {
				
				Object[] inputVals = {
					BnsprType.NUMBER, iMap.getBigDecimal("islemNo"),
					BnsprType.STRING, iMap.getString("islemYeri"),
					BnsprType.STRING, iMap.getString("kullaniciSicil"),
					BnsprType.STRING, iMap.getString("aciklama"),
					BnsprType.DATE, GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"),
					BnsprType.STRING, iMap.getString("iptalTip"),
					BnsprType.NUMBER, iMap.getBigDecimal("pttSiraNo"),
				};
				
				DALUtil.callOracleProcedure("{call PKG_PTT.Cancel_Log_At(?,?,?,?,?,?,?)}", inputVals, new Object[0]);
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("CLKS_PFT_IADESI_VAR_MI")
	public static GMMap clksPftIadesiVarMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PFT.PFT_iadesi_varmi(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setString(i++, iMap.getString("TCKN"));
			stmt.execute();
			oMap.put("IADESI_VARMI", stmt.getString(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_GET_INPUT_DATA_FOR_COLLECTIVE_CONFIRM")
	public static GMMap clksGetInputDataCollectiveConfirm(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC_PTT.GET_ISLEM_DATA(?,?,?)}"); //PROSEDUR

			int i = 0;

			stmt.setBigDecimal(++i, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(++i, iMap.getString("ISLEM_TIPI"));

			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			//stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(i);
			oMap = DALUtil.rSetMap(rSet);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("CLKS_SORUNLU_ISLEM_MAIL_GONDER")
	public static GMMap ClksSorunluIslemMailGonder(GMMap iMap) {
		try {

			if (iMap.getString("MAIL_GONDER") != null
					&& iMap.getString("MAIL_GONDER").compareTo("1") == 0) {

				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO", iMap.getString("MAIL_LIST"));
				mailMap.put("TRX_NO", iMap.getString("islemNo"));
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put(
						"MAIL_SUBJECT",
						GMServiceExecuter.execute("BNSPR_CORE_GET_SISTEM_ADI",
								iMap).get("SISTEM_ADI")
								+ "PTT Sorunlu Islem");
				mailMap.put("MAIL_BODY",
						iMap.getString("islemNo") + " nolu islem sorunludur. ("
								+ iMap.getString("ERROR_MESSAGE") + ")");
				mailMap.put("IS_BODY_HTML", "H");
				GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
						mailMap);

				// ERROR_MESSAGE

			}

			return iMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("CLKS_GET_KULLANDIRIM_DEKONT_MESSAGE_AND_CONTROL_CITY")
	public static GMMap ClksGetKullandirimDekontMessageAndControlCity(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_PTT.getDekontMessageAndilKontrol(?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("isleminYapildigiIl"));
			stmt.setString(i++, iMap.getString("isleminYapildigiSube"));
			stmt.setString(i++, iMap.getString("isleminYapildigiMerkez"));
			stmt.setString(i++, iMap.getString("isleminYapildigiBasmudurluk"));

			stmt.execute();

			oMap.put("mesaj", stmt.getString(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_PTT_SUPHELI_ISLEM_KONTROL")
	public static GMMap clksGetPttSupheliIslemKontrol(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call pkg_ptt_kredi.PTT_SUPHELI_ISLEM_KONTROL(?,?,?)}");

			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO"));
			stmt.setString(i++, iMap.getString("ISLEM_KOD"));
			stmt.execute();
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GraymoundService("BNSPR_PTT_SGRT_SIGORTA_URUN_LIST")
	public static GMMap bnsprPttSigortaUrunList(GMMap iMap) {
	    Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        ResultSet set = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_PTT_SIGORTA.get_sigorta_urun_list()}");

            stmt.registerOutParameter(1, -10);
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            GMMap oMap =  DALUtil.rSetResults(rSet, "SIGORTA_URUN_LIST");
            List<Map<?,?>>  primList =  new ArrayList<Map<?,?>>();
            List<Map<?,?>> list = (List<Map<?,?>>) oMap.get("SIGORTA_URUN_LIST");
            
            for(Map  map :  list){
                    
                    if( map.get("FIYATLAMA_TIPI") != null && "S".equals(map.get("FIYATLAMA_TIPI").toString() ) ){
                        stmt = conn.prepareCall("{? = call PKG_PTT_SIGORTA.get_urun_detay(?)}");

                        int i = 1;
                        stmt.registerOutParameter(i++, -10);
                        stmt.setString(i++, ( map.get("URUN_KOD")!=null ) ?  map.get("URUN_KOD").toString() : null );
                        stmt.execute();
                        set = (ResultSet) stmt.getObject(1);
                        GMMap pMap =  DALUtil.rSetResults( set, "PRIM_LIST");
                        List<Map<?,?>> pList = pMap.get("PRIM_LIST") != null ?( List<Map<?,?>>) pMap.get("PRIM_LIST") : new ArrayList<Map<?,?>>();
                        for(Map  primMap : pList){
                            primMap.put("URUN_KOD",  ( map.get("URUN_KOD")!=null ) ?  map.get("URUN_KOD").toString() : null );
                            primList.add(primMap);
                        }

                    }
            }
            oMap.put("PRIM_LIST", primList);
            
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
        	GMServerDatasource.close(set);
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	
	@GraymoundService ("CLKS_TFF_CARD_LIST")
	public static GMMap pttAtmGetTffCardList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		try {
			iMap.put("MASK_CC_NO", "N");
			iMap.put("CARD_BANK_STATUS_CC", "All");
			iMap.put("PROCEED", "INCLUDE");
			
			// Case: TC Uyruk
			if(iMap.getString("TCKN") != null && NumberUtils.isNumber(iMap.getString("TCKN"))) {
				
				iMap.put(OceanMapKeys.INPUT_PARAMETER_TYPE, "TCKN");
				
				// Validation: TCKN
		    	if (((Integer) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.TCKN_KONTROL(?)}", Types.INTEGER, iMap.getBigDecimal("TCKN"))) == 0) {
		    		iMap.put("HATA_NO", 2618);
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
		    	}
	    	}
			
			// Case: TCKN/EUPT null geldigi durumda hata donelim
			else {
	            iMap.put("HATA_NO" , 3284);
	            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , iMap);
	        }
	    	
	    	GMMap tMap = new GMMap();
	    	tMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap));
	    	
	    	if(tMap.containsKey("CARD_DETAIL_INFO") && tMap.getSize("CARD_DETAIL_INFO") > 0) {
	    		
	    		oMap.put("MUSTERI_ADI_SOYADI" , tMap.getString("CARD_DETAIL_INFO" , 0 , "NAME"));
	    		
	    		int i = 0;
	    		int index = 0;
	    		for(index = 0; index < tMap.getSize("CARD_DETAIL_INFO"); index++) {
	    			
	    			if(!OceanConstants.Akustik_CreditCard.equals(tMap.getString("CARD_DETAIL_INFO", index, "CARD_DCI_AKUSTIK"))) {
	    				
	    				GMMap hceMap = new GMMap();
	    				hceMap.put("PRODUCT_ID", tMap.getString("CARD_DETAIL_INFO", index, "PRODUCT_ID"));
	    				hceMap.put("PRODUCT_SUB_TYPE", "IN:ONLINE,OFFLINE");

	    				Boolean isHCEKart= "Y".equals(GMServiceExecuter.call("BNSPR_IS_HCE_PRODUCT", hceMap).getString("IS_HCE")) ;

	    				if (!isHCEKart) {
	    					oMap.put("CARD_DETAIL_INFO", i, tMap.getMap("CARD_DETAIL_INFO", index));
	    					oMap.put("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT", oMap.getBigDecimal("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT").setScale(2,BigDecimal.ROUND_HALF_UP));
	    					i++;
	    				}
	    			}
	    		}
	    		
	    		// Case: Secilen Kart
	    		if(iMap.containsKey("CARD_NO") && oMap.containsKey("CARD_DETAIL_INFO") && oMap.getSize("CARD_DETAIL_INFO") > 0) {
	    			
		    		for(index = 0; index < oMap.getSize("CARD_DETAIL_INFO"); index++) {
						if(iMap.getString("CARD_NO").equals(oMap.getString("CARD_DETAIL_INFO", index, "CARD_NO"))) {
							oMap.put("CARD_INDEX", index);
						}
		    		}
	    		}
	    	}
	
			// Case: Donebilecek durumda kart/basvuru yoksa
			if(oMap.getSize("CARD_DETAIL_INFO") == 0) {
				iMap.put("HATA_NO", 3218);
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		} catch (Exception e){
			logger.error("CLKS_TFF_CARD_LIST err: " + e);
            throw ExceptionHandler.convertException(e);
        }
		
    	return oMap;
	}
	
    /**
     * Gelen TCKN veya EUPT hesap no parametresiyle, tff ba�vuru bilgiyi d�nen servisi �a��r�r.
     * 
     * @param iMap
     *            - TCKN - EUPT
     * @return oMap - MUSTERI_ADI_SOYADI - CARD_DETAIL_INFO
     */
    @GraymoundService("PTT_TFF_GET_BASVURU_BILGI")
    public static GMMap pttTffGetBasvuruBilgi(GMMap iMap) {
    	
    	GMMap oMap = new GMMap();
    	int i = 0;
    	String cardGroup;
    	
        try{
        
            GMMap tMap = GMServiceExecuter.call("CLKS_TFF_CARD_LIST", iMap);
            
            for(int index = 0; index < tMap.getSize("CARD_DETAIL_INFO"); index++) {
            	
            	cardGroup = CLKSCommonServices.getCardGroup(tMap.getString("CARD_DETAIL_INFO", index, "CARD_GROUP"));
            	
            	// Case: PassoLig Kart
            	if(ClksConstants.ISLEM_TOPUP_PASSOLIG_KIMLIK == iMap.getInt("ISLEM")) {
            		
            		if(ClksConstants.BRAND_CARD_PASSOLIG.equals(cardGroup)) {
            			oMap.put("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME", tMap.get("CARD_DETAIL_INFO", index, "CARD_PRODUCT_NAME"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "PRODUCT_ID", tMap.get("CARD_DETAIL_INFO", index, "PRODUCT_ID"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "LOGO_CODE", tMap.get("CARD_DETAIL_INFO", index, "LOGO_CODE"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "CARD_NO", tMap.get("CARD_DETAIL_INFO", index, "CARD_NO"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "SYSTEM", tMap.get("CARD_DETAIL_INFO", index, "SYSTEM"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT", tMap.get("CARD_DETAIL_INFO", index, "CARD_AVAIL_LIMIT"));
    		    		i++;
            		}
            	}
            	
            	// Case: N Kolay Kart
            	else if(ClksConstants.ISLEM_TOPUP_NKOLAY_KIMLIK == iMap.getInt("ISLEM")) {
            		
            		// Validation: 
    		    	if(ClksConstants.BRAND_CARD_NKOLAY.equals(cardGroup)) {
    		    		
    		    		oMap.put("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME", tMap.get("CARD_DETAIL_INFO", index, "CARD_PRODUCT_NAME"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "PRODUCT_ID", tMap.get("CARD_DETAIL_INFO", index, "PRODUCT_ID"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "LOGO_CODE", tMap.get("CARD_DETAIL_INFO", index, "LOGO_CODE"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "CARD_NO", tMap.get("CARD_DETAIL_INFO", index, "CARD_NO"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "SYSTEM", tMap.get("CARD_DETAIL_INFO", index, "SYSTEM"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT", tMap.get("CARD_DETAIL_INFO", index, "CARD_AVAIL_LIMIT"));
    		    		i++;
    		    	}
            	}
            }
            
            oMap.put("MUSTERI_ADI_SOYADI", tMap.getString("MUSTERI_ADI_SOYADI"));
            
			// Case: Donebilecek durumda kart/basvuru yoksa
			if(oMap.getSize("CARD_DETAIL_INFO") == 0) {
				iMap.put("HATA_NO", 3218);
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
            
        } catch (Exception e){
        	
			logger.error("PTT_TFF_GET_BASVURU_BILGI err: " + e);
            throw ExceptionHandler.convertException(e);
        }
        
        return oMap;
    }
    
    
    @GraymoundService("CLKS_TFF_CARD_INFO")
    public static GMMap pttTffMusteriAdsoyadTcknTelBilgi(GMMap iMap) {
    	
		GMMap oMap = new GMMap();
    	GMMap cardDetails = new GMMap();   
		
		try {
		  	GMMap pMap = new GMMap();
	  		pMap.put("KOD", "EUTS_KART_NUMARALARI");
		  	pMap.put("KEY", iMap.getString("CARD_NO"));
		  	pMap = GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI",pMap);
		  	if ("E".equals(pMap.getString("IS_EXIST"))){
		  		pMap.clear();
		  		pMap.put("KOD", "EUTS_KART_NUMARALARI");
			  	pMap.put("KEY", iMap.getString("CARD_NO"));
		  		pMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", pMap);
			  	
		  		if(!StringUtil.isEmpty(pMap.getString("TEXT"))){
		  			String hesapNo=pMap.getString("TEXT");
		  			GMMap hMap = new GMMap();
		  			hMap.put("HESAP_NO", hesapNo);
		  			hMap = GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", hMap);
		  			String musteriNo= hMap.getString("MUSTERI_NO");
		  			oMap.put("MUSTERI_NO", musteriNo);
		    		oMap.put("LOGO_CODE", "001");
		    		oMap.put("PRODUCT_ID", "916");
		    		oMap.put("CARD_GROUP", "0");
		    		oMap.put("SYSTEM", "O");
					oMap.put("UNVAN", DALUtil.callOneParameterFunction("{? = call pkg_musteri.unvan(?)}", Types.VARCHAR,musteriNo));
					oMap.put("TCKN", DALUtil.callOneParameterFunction("{? = call pkg_musteri.tc_kimlik_no(?)}", Types.VARCHAR, musteriNo));
					oMap.put("DCI", "D");
					oMap.put("TELNO", DALUtil.callOneParameterFunction("{? = call pkg_musteri.iletisim_telefon(?)}", Types.VARCHAR, musteriNo));
					oMap.put("ALICI_HESAP_NO", hesapNo);
					return oMap;
		  		}
		  	}
	  		
	    	GMMap cardProperties = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", iMap);
	    	iMap.put("CARD_DCI", cardProperties.getString("DCI"));
	    	
	    	if(OceanConstants.Card_Source_Ocean.equals(cardProperties.getString("DESTINATION"))) {	
	    		cardDetails.putAll(GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", iMap));
	    		oMap.put("SYSTEM", "O");
	    	} else if (OceanConstants.Card_Source_Intracard.equals(cardProperties.getString("DESTINATION"))) {
	    		cardDetails.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", iMap));
	    		oMap.put("SYSTEM", "I");
	    	}
	    
	    	// Case: Kredi karti icin G,J ve G,B disinda (Kapal� kartlara da yatirilmasi icin KYS tarafindan bu bilgi alindi) yuklemeye izin verilecek,
	    	//		 diger kart tipleri (debit, prepaid) icin gecerli durum N,N olacaktir.
	    	if ((OceanConstants.Akustik_CreditCard.equals(iMap.getString("CARD_DCI")) &&
	    			cardDetails.getString("CARD_DETAIL_INFO",0,"CUSTOMER_NO") != null && 
	    			!"".equals(cardDetails.getString("CARD_DETAIL_INFO",0,"CUSTOMER_NO")) &&
	    			!"G".equals(cardDetails.getString("CARD_DETAIL_INFO",0,"CARD_STAT_CODE")) &&
	    			!"J".equals(cardDetails.getString("CARD_DETAIL_INFO",0,"CARD_SUB_STAT_CODE")) && 
	    			!"B".equals(cardDetails.getString("CARD_DETAIL_INFO",0,"CARD_SUB_STAT_CODE"))) ||
	    		(!OceanConstants.Akustik_CreditCard.equals(iMap.getString("CARD_DCI")) && 
	    			cardDetails.getString("CARD_DETAIL_INFO",0,"CUSTOMER_NO") != null && 
	    			!"".equals(cardDetails.getString("CARD_DETAIL_INFO",0,"CUSTOMER_NO")) &&
	    			"N".equals(cardDetails.getString("CARD_DETAIL_INFO",0,"CARD_STAT_CODE")) &&
	    			"N".equals(cardDetails.getString("CARD_DETAIL_INFO",0,"CARD_SUB_STAT_CODE")))) {
	    		
	    		oMap.put("MUSTERI_NO", cardDetails.getString("CARD_DETAIL_INFO",0,"CUSTOMER_NO"));
	    		oMap.put("LOGO_CODE", cardDetails.getString("CARD_DETAIL_INFO",0,"LOGO_CODE"));
	    		oMap.put("PRODUCT_ID", cardDetails.getString("CARD_DETAIL_INFO",0,"PRODUCT_ID"));
	    		oMap.put("CARD_GROUP", cardDetails.getString("CARD_DETAIL_INFO",0,"CARD_GROUP"));
				oMap.put("UNVAN", DALUtil.callOneParameterFunction("{? = call pkg_musteri.unvan(?)}", Types.VARCHAR, oMap.getString("MUSTERI_NO")));
				oMap.put("TCKN", DALUtil.callOneParameterFunction("{? = call pkg_musteri.tc_kimlik_no(?)}", Types.VARCHAR, oMap.getString("MUSTERI_NO")));
				oMap.put("DCI", cardProperties.getString("DCI"));
				
				// Case: Debit 
				if(OceanConstants.Akustik_DebitCard.equals(cardProperties.getString("DCI"))) {
					oMap.put("ALICI_HESAP_NO", getDebitAccountNo(cardDetails));
				}
				
				// TCKN bilgisi yok ise, pasaport noyu al
				if (oMap.getString("TCKN") == null || "".equals(oMap.getString("TCKN"))) {
					oMap.put("PASAPORT", DALUtil.callOneParameterFunction("{? = call pkg_musteri.pasaport_no(?)}", Types.VARCHAR, oMap.getString("MUSTERI_NO")));
				}
			
				oMap.put("TELNO", DALUtil.callOneParameterFunction("{? = call pkg_musteri.iletisim_telefon(?)}", Types.VARCHAR, oMap.getString("MUSTERI_NO")));
			}
	    	
	    	else if (cardDetails.getString("CARD_DETAIL_INFO",0,"CUSTOMER_NO") != null && 
				!("".equals(cardDetails.getString("CARD_DETAIL_INFO",0,"CUSTOMER_NO")))) {
	    		iMap.put("HATA_NO", 4139);
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	    	}
	    	
			else {
				iMap.put("HATA_NO", 3218);
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		} catch (Exception e) {
			logger.error("CLKS_TFF_CARD_INFO err: " + e);
            throw ExceptionHandler.convertException(e);
		}
    	
		return oMap;
    }
	
	@GraymoundService("PTT_TFF_TRANSFER_REQUEST")
	public static GMMap pttTffTransferRequest(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();

		try {

			if (iMap.getInt("MASK") == 1) {
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap())); // get TRX_NO
			}
			
			iMap.put("DURUM_KODU", "A");
			iMap.put("CARD_DCI", "A");
			iMap.put("BORC_HESAP_NO", DALUtil.callOneParameterFunction("{? = call pkg_parametre.deger_al_k_n(?)}", Types.NUMERIC, "CLKS_TFF_HESAP"));
			iMap.put("MUSTERI_NO", DALUtil.callOneParameterFunction("{? = call pkg_hesap.musteri_no(?)}", Types.NUMERIC, iMap.getString("BORC_HESAP_NO")));
			iMap.put("DOVIZ_KODU", "TRY");
			
			if (!iMap.containsKey("KASA_KIMLIK_TIPI")) {
				iMap.put("KASA_KIMLIK_TIPI", "1");
			}

			// Islem: Kimlik ile kart odeme
			if (ClksConstants.ISLEM_TOPUP_PASSOLIG_KIMLIK == iMap.getInt("ISLEM") || ClksConstants.ISLEM_TOPUP_NKOLAY_KIMLIK == iMap.getInt("ISLEM")) {
				
				iMap.putAll(GMServiceExecuter.call("CLKS_TFF_CARD_LIST", iMap));
			
				iMap.put("EUPT_HESAP_NO", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "EUPT_ACCOUNT_NO"));
				iMap.put("TC_KIMLIK_NO", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "TCKN"));
				iMap.put("ALICI_TCKN", iMap.get("TC_KIMLIK_NO"));
				iMap.put("ALICI_ADI_SOYADI", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "NAME"));
				iMap.put("LOGO_KODU", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "LOGO_CODE"));
				iMap.put("URUN_KODU", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "PRODUCT_ID"));
				iMap.put("KART_KAYNAGI", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "SYSTEM"));
				iMap.put("KART_NO", iMap.getString("CARD_NO"));
				iMap.put("DCI", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "CARD_DCI_AKUSTIK"));
				iMap.put("CARD_GROUP", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "CARD_GROUP"));
				
				String cardGroup = CLKSCommonServices.getCardGroup(iMap.getString("CARD_GROUP"));
				
		    	// Validation: PassoLig Kart Sorgusu, N Kolay Kart
		    	if(ClksConstants.BRAND_CARD_NKOLAY.equals(cardGroup) && ClksConstants.ISLEM_TOPUP_PASSOLIG_KIMLIK == iMap.getInt("ISLEM")) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
		    	
		    	// Validation: N Kolay Kart Sorgusu, PassoLig Kart
		    	else if(ClksConstants.BRAND_CARD_PASSOLIG.equals(cardGroup) && ClksConstants.ISLEM_TOPUP_NKOLAY_KIMLIK == iMap.getInt("ISLEM")) {
		    		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
				
				// Case: Basvuru (Passolig Kart)
				if ("B".equals(iMap.getString("KART_KAYNAGI"))) {
					iMap.put("EUPT_AB_MUSTERI_NO", iMap.getBigDecimal("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "CUSTOMER_NO"));
					iMap.put("BASVURU_NO", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "CARD_NO"));
					iMap.put("KART_NO", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "CARD_NO"));
					iMap.put("MUSTERI_NO", iMap.getBigDecimal("EUPT_AB_MUSTERI_NO"));
				}
			
				// Case: Acik Kart
				else {
					iMap.put("ALICI_MUSTERI_NO", iMap.getBigDecimal("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "CUSTOMER_NO"));
					iMap.put("KART_NO", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("CARD_INDEX"), "CARD_NO"));
					iMap.put("MUSTERI_NO", iMap.getBigDecimal("ALICI_MUSTERI_NO"));
					
					if(OceanConstants.Akustik_DebitCard.equals(iMap.getString("DCI"))) {
						
						GMMap cardInfoMap = new GMMap();
						cardInfoMap.put("CARD_NO", iMap.get("KART_NO"));
						cardInfoMap.put("CARD_DCI", OceanConstants.Akustik_DebitCard);
						
						if(OceanConstants.Card_Source_Ocean.equals(iMap.getString("KART_KAYNAGI"))) {
							cardInfoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cardInfoMap);
						} else if (OceanConstants.Card_Source_Intracard.equals(iMap.getString("KART_KAYNAGI"))) {
							cardInfoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", cardInfoMap);
						}
						
						iMap.put("ALICI_HESAP_NO", getDebitAccountNo(cardInfoMap));
					}
				}
			} 
			
			// Islem: Kart numaras� ile kart odeme
			else {
				
				tMap.putAll(GMServiceExecuter.call("CLKS_TFF_CARD_INFO", iMap));
				
				iMap.put("URUN_KODU", tMap.getString("PRODUCT_ID"));
				iMap.put("LOGO_KODU", tMap.getString("LOGO_CODE"));
				iMap.put("TC_KIMLIK_NO", tMap.getString("TCKN"));
				iMap.put("ALICI_TCKN", (tMap.getString("TCKN") == null) ? tMap.getString("PASAPORT") : tMap.getString("TCKN"));
				iMap.put("ALICI_ADI_SOYADI", tMap.getString("UNVAN"));
				iMap.put("ALICI_MUSTERI_NO", tMap.getBigDecimal("MUSTERI_NO"));
				iMap.put("KART_KAYNAGI", tMap.getString("SYSTEM"));
				iMap.put("KART_NO", iMap.getString("CARD_NO"));
				iMap.put("DCI", tMap.getString("DCI"));
				iMap.put("ALICI_HESAP_NO", tMap.get("ALICI_HESAP_NO"));
				iMap.put("CARD_GROUP", tMap.get("CARD_GROUP"));
				
				String cardGroup = CLKSCommonServices.getCardGroup(iMap.getString("CARD_GROUP"));
				
				// Validation: PassoLig Kart Sorgusu, N Kolay Kart
		    	if(ClksConstants.BRAND_CARD_NKOLAY.equals(cardGroup) && ClksConstants.ISLEM_TOPUP_PASSOLIG_KART == iMap.getInt("ISLEM")) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
		    	
		    	// Validation: N Kolay Kart Sorgusu, PassoLig Kart
		    	else if(ClksConstants.BRAND_CARD_PASSOLIG.equals(cardGroup) && ClksConstants.ISLEM_TOPUP_NKOLAY_KART == iMap.getInt("ISLEM")) {
		    		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
				
				if ("1".equals(iMap.getString("KASA_KIMLIK_TIPI"))) {				
					oMap.put("ISLEMI_YAPAN_ADSOYAD", tMap.getString("UNVAN"));
					oMap.put("ISLEMI_YAPAN_TCKN", (tMap.getString("TCKN") == null) ? tMap.getString("PASAPORT") : tMap.getString("TCKN"));			
					oMap.put("ISLEMI_YAPAN_TELNO", tMap.getString("TELNO"));
					iMap.put("ISLEMI_YAPAN_TELNO", oMap.getString("ISLEMI_YAPAN_TELNO"));
				}
			}
			
			
			// Case: Basvuru
			if(OceanConstants.Card_Source_Application.equals(iMap.getString("KART_KAYNAGI"))) {
				iMap.put("MASRAF_TUTARI", BigDecimal.ZERO);
			}
			
			// Case: Debit
			else if(OceanConstants.Akustik_DebitCard.equals(iMap.getString("DCI"))) {
				
				// Masraf
				if (ClksConstants.ISLEM_TOPUP_PASSOLIG_KIMLIK == iMap.getInt("ISLEM")) {
					iMap.put("EKRAN_KODU", Transaction.KART_PASSO_YATAN.toString());
				} else if (ClksConstants.ISLEM_TOPUP_NKOLAY_KIMLIK == iMap.getInt("ISLEM")) {
					iMap.put("EKRAN_KODU", Transaction.KART_NKOLAY_YATAN.toString());
				} else if (ClksConstants.ISLEM_TOPUP_PASSOLIG_KART == iMap.getInt("ISLEM")) {
					iMap.put("EKRAN_KODU", Transaction.KART_PASSO_YATAN.toString());
				} else if (ClksConstants.ISLEM_TOPUP_NKOLAY_KART == iMap.getInt("ISLEM")) {
					iMap.put("EKRAN_KODU", Transaction.KART_NKOLAY_YATAN.toString());
				}
				
				iMap.putAll(GMServiceExecuter.call("INTERNET_HAVALE_EFT_MASRAF_HESAPLA", new GMMap()
					.put("EKRAN_KODU", iMap.getString("EKRAN_KODU"))
					.put("TUTAR", iMap.getBigDecimal("TUTAR"))
					.put("MUSTERI_NO", iMap.getBigDecimal("ALICI_MUSTERI_NO"))
					.put("DOVIZ_KOD", "TRY")));
				
				iMap.put("MASRAF_TUTARI", iMap.getBigDecimal("TOPLAM_MASRAF", BigDecimal.ZERO).add(iMap.getBigDecimal("TOPLAM_BSMV", BigDecimal.ZERO)));
			}
			
			// Case: Credit, Prepaid
			else {
				
				GMMap txnFeeMap = GMServiceExecuter.call("BNSPR_GET_TXN_FEE_PROFILE_INFO", new GMMap()
					.put("CARD_NO", iMap.getString("KART_NO"))
					.put("TERMINAL", "GISE"));
				
				iMap.put("MASRAF_TUTARI", BigDecimal.ZERO);
				if(txnFeeMap.getSize("PROFILE_LIST") > 0) {
					iMap.put("MASRAF_TUTARI", iMap.getBigDecimal("TUTAR").multiply(txnFeeMap.getBigDecimal("PROFILE_LIST", 0, "FEE_RATE")).add(txnFeeMap.getBigDecimal("PROFILE_LIST", 0, "FLAT_FEE_AMOUNT")));
				}
			}
			
			// Case: Masraf, Tutardan fazla ise
			if(iMap.getBigDecimal("TUTAR").subtract(iMap.getBigDecimal("MASRAF_TUTARI")).compareTo(BigDecimal.ONE) < 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1458));
			}
			
			iMap.put("MASRAF_TAHSIL_DOVIZ", "TRY");

			// Kayit at
			if (ClksConstants.ISLEM_TOPUP_PASSOLIG_KIMLIK == iMap.getInt("ISLEM") || ClksConstants.ISLEM_TOPUP_NKOLAY_KIMLIK == iMap.getInt("ISLEM")) {
				iMap.put("SAVE", "REQUEST-KIMLIK");
				iMap.put("KASA_KIMLIK_TIPI", "1");
				oMap.putAll(GMServiceExecuter.call("PTT_TFF_TRANSFER_SAVE", iMap));
			} else if (ClksConstants.ISLEM_TOPUP_PASSOLIG_KART == iMap.getInt("ISLEM") || ClksConstants.ISLEM_TOPUP_NKOLAY_KART == iMap.getInt("ISLEM")) {
				iMap.put("SAVE", "REQUEST-KART");
				if (iMap.getString("BANKA_ISLEM_NO") != null && !iMap.getString("BANKA_ISLEM_NO").isEmpty())
					iMap.put("TRX_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
				oMap.putAll(GMServiceExecuter.call("PTT_TFF_TRANSFER_SAVE", iMap));
			}

			// TRX: 2053 (Ortak)
			iMap.put("TRX_NAME", Transaction.KART_PASSO_YATAN.toString());
			
			// Case: Kimlik ile 
			if (ClksConstants.ISLEM_TOPUP_PASSOLIG_KIMLIK == iMap.getInt("ISLEM") || ClksConstants.ISLEM_TOPUP_NKOLAY_KIMLIK == iMap.getInt("ISLEM")) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));
			}
			
			// Case: Kart No ile
			else if ((ClksConstants.ISLEM_TOPUP_PASSOLIG_KART == iMap.getInt("ISLEM") || ClksConstants.ISLEM_TOPUP_NKOLAY_KART == iMap.getInt("ISLEM")) && "2".equals(iMap.getString("MASK"))) {
				if(((BigDecimal)DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_yaratilmis_mi(?)}", Types.NUMERIC, iMap.getBigDecimal("BANKA_ISLEM_NO"))).equals(new BigDecimal(0))) {
					oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));
				}
			}

			oMap.put("BANKA_ISLEM_NO", iMap.getString("TRX_NO"));
			oMap.put("ALICI_ADI_SOYADI", iMap.getString("ALICI_ADI_SOYADI"));
			oMap.put("ALICI_TCKN", iMap.getString("ALICI_TCKN"));
			oMap.put("MASRAF_TUTARI", iMap.getString("MASRAF_TUTARI"));
			oMap.put("MASRAF_DOVIZ_KODU", iMap.getString("MASRAF_TAHSIL_DOVIZ"));
			
		}
		catch (Exception e) {
			
			logger.error("CLKS_PTT_TFF_TRANSFER_REQUEST err: " + e );
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("PTT_TFF_TRANSFER_CONFIRM")
	public static GMMap pttTffTransferConfirm(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		iMap.put("BOUNDARY", true);
		
		try {
			
			TransactionDao<CardPayment> dao = new DalCardPaymentDao();
			CardPayment cardPayment = dao.get(iMap.getBigDecimal("BANKA_ISLEM_NO"));
			TransactionProcess<CardPayment> process = new CardPaymentProcess(dao);
			process.confirm(cardPayment);
			
			// Update
			iMap.put("TRX_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));	
			iMap.put("SAVE", "CONFIRM");
			oMap.putAll(GMServiceExecuter.call("PTT_TFF_TRANSFER_SAVE", iMap));
			
			// Transfer to tff
			iMap.put("OPERATION_TYPE", "");
			iMap.put("TX_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
			
			try {
				GMServiceExecuter.call("BNSPR_DO_TRANSFER_TO_TFF", iMap);
			} catch(Exception e) {
				throw e;
			} finally {
				iMap.put("BOUNDARY", false);
			}

			// Transaction Confirmation
			iMap.put("ISLEM_TURU", "O");
			iMap.put("ISLEM_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
			
			Session session = DAOSession.getSession("BNSPRDal");
			ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("TRX_NO"));

			// Case: 3. Sahis Islemi
			if(clksHavaleGirisTx != null && clksHavaleGirisTx.getKasaKimlikTipi() != null && new BigDecimal(4).equals(clksHavaleGirisTx.getKasaKimlikTipi())) {
				DALUtil.callOneParameterFunction("{? = call  PKG_PTT_ATM.Q2022_KAYIT_AT(?)}", Types.NUMERIC, iMap.getBigDecimal("TRX_NO"));
			}
			
			oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap));
		}
		catch (Exception e) {
			
			logger.error("CLKS_PTT_TFF_TRANSFER_CONFIRM err:" + e);
			
			if(!iMap.getBoolean("BOUNDARY")) {
				try {
					GMMap sMap = new GMMap();
					sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
					sMap.put("ORGINAL_EXTERNAL_TRX_ID", iMap.getBigDecimal("BANKA_ISLEM_NO"));
					sMap.put("EXTERNAL_TRX_ID", sMap.getBigDecimal("TRX_NO"));
					sMap.put("OPERATION_TYPE", "R");
					GMServiceExecuter.call("BNSPR_DO_TRANSFER_TO_TFF", sMap);
				} catch(Exception e1) { logger.error("CLKS_PTT_TFF_TRANSFER_CONFIRM in. err:" + e); }
			}
			
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("PTT_TFF_TRANSFER_SAVE")
	public static GMMap pttTffSave(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("TRX_NO"));

			if (clksHavaleGirisTx == null) {
				clksHavaleGirisTx = new ClksHavaleGirisTx(iMap.getBigDecimal("TRX_NO"));
			}
			
			// Case: Kimlik ile
			if ("REQUEST-KIMLIK".equals(iMap.getString("SAVE"))) {
				
				clksHavaleGirisTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
				clksHavaleGirisTx.setMasrafTutari(iMap.getBigDecimal("MASRAF_TUTARI"));
				clksHavaleGirisTx.setMasrafTahsilDoviz(iMap.getString("MASRAF_TAHSIL_DOVIZ"));
				clksHavaleGirisTx.setIslem(iMap.getBigDecimal("ISLEM"));
				clksHavaleGirisTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
				clksHavaleGirisTx.setKasaKimlikTipi(iMap.getBigDecimal("KASA_KIMLIK_TIPI"));
				clksHavaleGirisTx.setEuptHesapNo(iMap.getBigDecimal("EUPT_HESAP_NO"));
				clksHavaleGirisTx.setAliciMusteriNo(iMap.getBigDecimal("ALICI_MUSTERI_NO"));
				clksHavaleGirisTx.setBorcHesapNo(iMap.getBigDecimal("BORC_HESAP_NO"));
				clksHavaleGirisTx.setKartNo(iMap.getString("KART_NO"));
				clksHavaleGirisTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				clksHavaleGirisTx.setLogoKodu(iMap.getString("LOGO_KODU"));
				clksHavaleGirisTx.setUrunKodu(iMap.getString("URUN_KODU"));
				clksHavaleGirisTx.setKartKaynagi(iMap.getString("KART_KAYNAGI"));
				clksHavaleGirisTx.setIslemSekli(iMap.getString("ISLEM_SEKLI"));
				clksHavaleGirisTx.setDurumKodu(iMap.getString("DURUM_KODU"));
				clksHavaleGirisTx.setTutar(iMap.getBigDecimal("TUTAR"));
				clksHavaleGirisTx.setBorcMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				clksHavaleGirisTx.setEuptAbMusteriNo(iMap.getBigDecimal("EUPT_AB_MUSTERI_NO"));
				clksHavaleGirisTx.setIslemiYapanKullanici(iMap.getString("ISLEMI_YAPAN_SICIL"));
				clksHavaleGirisTx.setIsleminYapildigiYer(iMap.getString("ISLEMIN_YAPILDIGI_YER"));
				clksHavaleGirisTx.setIsleminYapildigiIl(iMap.getString("ISLEMIN_YAPILDIGI_IL"));
				clksHavaleGirisTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
				clksHavaleGirisTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
				clksHavaleGirisTx.setIsleminYapildigiBasmudurluk(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				clksHavaleGirisTx.setMerkezSubeBasmudurluk(iMap.getString("MERKEZ_SUBE_BASMUDURLUK"));
				clksHavaleGirisTx.setIslemiYapanAdsoyad(iMap.getString("ISLEMI_YAPAN_ADSOYAD"));
				clksHavaleGirisTx.setIslemiYapanKullAdsoyad(iMap.getString("ISLEMI_YAPAN_KULLANICI_ADSOYAD"));
				clksHavaleGirisTx.setKartDci(iMap.getString("DCI"));
				clksHavaleGirisTx.setKartGrup(iMap.getString("CARD_GROUP"));
				clksHavaleGirisTx.setAliciHesapNo(iMap.get("ALICI_HESAP_NO") == null ? null : iMap.getBigDecimal("ALICI_HESAP_NO"));
			}
			
			// Case: Kart No ile
			else if ("REQUEST-KART".equals(iMap.getString("SAVE"))) {
				
				clksHavaleGirisTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
				clksHavaleGirisTx.setMasrafTutari(iMap.getBigDecimal("MASRAF_TUTARI"));
				clksHavaleGirisTx.setMasrafTahsilDoviz(iMap.getString("MASRAF_TAHSIL_DOVIZ"));
				clksHavaleGirisTx.setIslem(iMap.getBigDecimal("ISLEM"));
				clksHavaleGirisTx.setKasaKimlikTipi(iMap.getBigDecimal("KASA_KIMLIK_TIPI"));
				clksHavaleGirisTx.setEuptHesapNo(iMap.getBigDecimal("EUPT_HESAP_NO"));
				clksHavaleGirisTx.setAliciMusteriNo(iMap.getBigDecimal("ALICI_MUSTERI_NO"));
				clksHavaleGirisTx.setBorcHesapNo(iMap.getBigDecimal("BORC_HESAP_NO"));
				clksHavaleGirisTx.setKartNo(iMap.getString("KART_NO"));
				clksHavaleGirisTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				clksHavaleGirisTx.setLogoKodu(iMap.getString("LOGO_KODU"));
				clksHavaleGirisTx.setUrunKodu(iMap.getString("URUN_KODU"));
				clksHavaleGirisTx.setKartKaynagi(iMap.getString("KART_KAYNAGI"));
				clksHavaleGirisTx.setIslemSekli(iMap.getString("ISLEM_SEKLI"));
				clksHavaleGirisTx.setDurumKodu(iMap.getString("DURUM_KODU"));
				clksHavaleGirisTx.setTutar(iMap.getBigDecimal("TUTAR"));
				clksHavaleGirisTx.setBorcMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				clksHavaleGirisTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
				clksHavaleGirisTx.setEuptAbMusteriNo(iMap.getBigDecimal("EUPT_AB_MUSTERI_NO"));
				clksHavaleGirisTx.setIslemiYapanKullanici(iMap.getString("ISLEMI_YAPAN_SICIL"));
				clksHavaleGirisTx.setIsleminYapildigiYer(iMap.getString("ISLEMIN_YAPILDIGI_YER"));
				clksHavaleGirisTx.setIsleminYapildigiIl(iMap.getString("ISLEMIN_YAPILDIGI_IL"));
				clksHavaleGirisTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
				clksHavaleGirisTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
				clksHavaleGirisTx.setIsleminYapildigiBasmudurluk(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				clksHavaleGirisTx.setMerkezSubeBasmudurluk(iMap.getString("MERKEZ_SUBE_BASMUDURLUK"));
				clksHavaleGirisTx.setAciklama(iMap.getString("ACIKLAMA")); 
				clksHavaleGirisTx.setIslemiYapanAdsoyad(iMap.getString("ISLEMI_YAPAN_ADSOYAD"));
				clksHavaleGirisTx.setIslemiYapanTckno(iMap.getString("ISLEMI_YAPAN_TCKN"));
				clksHavaleGirisTx.setIslemiYapanTelno(iMap.getString("ISLEMI_YAPAN_TELNO"));
				clksHavaleGirisTx.setIslemiYapanKullAdsoyad(iMap.getString("ISLEMI_YAPAN_KULLANICI_ADSOYAD"));
				clksHavaleGirisTx.setKartDci(iMap.getString("DCI"));
				clksHavaleGirisTx.setKartGrup(iMap.getString("CARD_GROUP"));
				clksHavaleGirisTx.setAliciHesapNo(iMap.get("ALICI_HESAP_NO") == null ? null : iMap.getBigDecimal("ALICI_HESAP_NO"));
				
			}
			else if ("CONFIRM".equals(iMap.getString("SAVE"))) {
				clksHavaleGirisTx.setPttIslemNo((iMap.getBigDecimal("PTT_ISLEM_NO")));
			}
			session.saveOrUpdate(clksHavaleGirisTx);
			session.flush();
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Gelen IBAN(hesapNo) parametresine kar��l�l�k gelen Hesap No'yu bulur.
	 * 
	 * @param iMap
	 *            - hesapNo
	 * @return oMap
	 *         - HESAP_NO
	 */
	@GraymoundService("BNSPR_GET_HESAP_NO_WITH_IBAN")
	public static GMMap getIBAN(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap.put("HESAP_NO", DALUtil.callOneParameterFunction("{? = call pkg_hesap.IBANdan_HesapNoAl(?)}", Types.VARCHAR, iMap.getString("hesapNo")));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
    
	
	/**
	 * Gelen hesapNo parametresine kar��l�l�k gelen Hesap t�r�n� bulur.
	 * @param iMap
	 *            - hesapNo
	 * @return oMap 
	 *  		  - HESAP_TURU
	 */
	@GraymoundService("BNSPR_GET_HESAP_TURU")
	public static GMMap getHesapTuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call  pkg_hesap.hesapturu(?)}");
			stmt.registerOutParameter(1, 12);
			stmt.setString(2, iMap.getString("hesapNo"));

			stmt.execute();
			oMap.put("HESAP_TURU", stmt.getObject(1));

		}
		catch (Exception e) {
			//Gelen inputa g�re (IBAN veya Hesap NO) hata parametresi olarak set edilir
			if ("2".equals(iMap.getString("islem"))) {
				oMap.put("HATA_NO", new BigDecimal(3214));
				oMap.put("P1", iMap.getString("IBAN_NO"));
			}else {
				oMap.put("HATA_NO", new BigDecimal(1527));
				oMap.put("P1", iMap.getString("hesapNo"));
			}
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", oMap);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_DO_TRANSFER_TO_TFF")
	public static GMMap doTransferTff(GMMap iMap) {
	    	
		
		// Case: Reversal
		if (iMap.getString("OPERATION_TYPE").equals("R")){
		    	GMMap rMap = new GMMap();
			rMap.put("REF_TX_NO", iMap.getBigDecimal("ORGINAL_EXTERNAL_TRX_ID"));
			rMap.put("TX_NO", iMap.getBigDecimal("EXTERNAL_TRX_ID"));
			GMServiceExecuter.call("BNSPR_KARTA_PARA_YUKLE_REVERSE", rMap);
		}
		
		// Case: Cancellation
		else if (iMap.getString("OPERATION_TYPE").equals("G")){
		    	GMMap rMap = new GMMap();
			rMap.put("REF_TX_NO", iMap.getBigDecimal("ORGINAL_EXTERNAL_TRX_ID"));
			rMap.put("TX_NO", iMap.getBigDecimal("EXTERNAL_TRX_ID"));
			GMMap outMap = new GMMap();
			outMap.putAll(GMServiceExecuter.call("BNSPR_KARTA_PARA_YUKLE_REVERSE_PTT", rMap));
			
			if(outMap.getString("IPTAL_EDILDI_MI").equals("H")){
                            GMMap exMap = new GMMap();
                            exMap.put("HATA_NO" , "5249");
                            return (GMMap)GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , exMap);
			}
		}
		
		// Case: Transaction
		else {
			
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap inMap = new GMMap();
			
			String dest="";
			String cardNo = "";
			String hesapNo = "";
			String aliciHesap ="";
			
			ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("TX_NO"));
			dest = clksHavaleGirisTx.getKartKaynagi();
			
			// Case: Basvuru
			if (dest.equals("B"))
			{
				hesapNo = clksHavaleGirisTx.getEuptHesapNo() == null ? "" : clksHavaleGirisTx.getEuptHesapNo().toString();
				aliciHesap = getGlobalParam("TFF_PARA_YUKLEME_BASVURU_HVZ");
				inMap.put("ALICI_HESAP_CINSI", "DK");
				inMap.put("ALICI_HESAP_NO", aliciHesap);
				inMap.put("ISLEM_SEKLI", "EUPT");
				
				String desc = getDesc (clksHavaleGirisTx);
                inMap.put("ACIKLAMA", getMessage("3433", desc));
			}
			
			// Case: Diger
			else {
				cardNo = clksHavaleGirisTx.getKartNo();
				
				String dci="";
						
				//
				GMMap pMap = new GMMap();
		  		pMap.put("KOD", "EUTS_KART_NUMARALARI");
			  	pMap.put("KEY", cardNo);
			  	pMap = GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI",pMap);
			  	if ("E".equals(pMap.getString("IS_EXIST"))){
			  		pMap.clear();
			  		pMap.put("KOD", "EUTS_KART_NUMARALARI");
				  	pMap.put("KEY", cardNo);
			  		pMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", pMap);
			  		
			  		aliciHesap = pMap.getString("TEXT");;
					inMap.put("ALICI_HESAP_CINSI", "VS");
					inMap.put("ALICI_HESAP_NO", aliciHesap);
					inMap.put("ISLEM_SEKLI", "DEBIT");
                    inMap.put("ACIKLAMA", getMessage("3434", null));
                    dci ="D";
                    
			  	}
			  	else{
			  		GMMap iMap2 = new GMMap();
					iMap2.put("CARD_NO", cardNo);
					GMMap cardProperty = new GMMap();
					cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES", iMap2);
					dci = cardProperty.getString("DCI");
					Boolean isProceed = cardProperty.getBoolean("IS_PROCEED");
				// Case: Debit
				if (OceanConstants.Akustik_DebitCard.equals(dci)){
					
					GMMap cardInfoMap = new GMMap();
					cardInfoMap.put("CARD_NO", cardNo);
					cardInfoMap.put("CARD_DCI", "D");
					
					if(OceanConstants.Card_Source_Ocean.equals(cardProperty.getString("DESTINATION"))) {
						cardInfoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cardInfoMap);
					} else if (OceanConstants.Card_Source_Intracard.equals(cardProperty.getString("DESTINATION"))) {
						cardInfoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", cardInfoMap);
					}
					
					aliciHesap = getDebitAccountNo(cardInfoMap).toString();
					inMap.put("ALICI_HESAP_CINSI", "VS");
					inMap.put("ALICI_HESAP_NO", aliciHesap);
					inMap.put("ISLEM_SEKLI", "DEBIT");
                    inMap.put("ACIKLAMA", getMessage("3434", null));
					
				}
				
				// Case: Credit
				else if (OceanConstants.Akustik_CreditCard.equals(dci)){			
					
					if (clksHavaleGirisTx.getDovizKodu().equals("TRY")){
						aliciHesap=getGlobalParam("KKART_ODEME_HAVUZ");
						inMap.put("ALICI_HESAP_CINSI", "DK");
						inMap.put("ALICI_HESAP_NO", aliciHesap);
						inMap.put("ISLEM_SEKLI", "CREDIT");
					}
					else{
						aliciHesap=getGlobalParam("KKART_ODEME_HAVUZ_YP");
						inMap.put("ALICI_HESAP_CINSI", "DK");
						inMap.put("ALICI_HESAP_NO", aliciHesap);
						inMap.put("ISLEM_SEKLI", "CREDIT");
					}
				}
				
				// Case: Prepaid
				else if (OceanConstants.Akustik_PrepaidCard.equals(dci)){
					
					if(!isProceed) { 
						try {
							aliciHesap = getGlobalParam(GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap()
								.put("KOD", "CLKS_PREPAID_ALICI_HESAP_MAPPING")
								.put("KEY", clksHavaleGirisTx.getUrunKodu())).getString("TEXT"));
						} catch(Exception e) { logger.error(e.getMessage()); }
						
						if(aliciHesap.length() == 0) {
							aliciHesap = getGlobalParam("O".equals(dest) ? "OCEAN_PREPAID_TOPUP_HAVUZ" : "PREPAID_YUKLEME_HAVUZ");
						}
					} else {
						aliciHesap = getGlobalParam("MCHIP_TOPUP_HESAP");
					}
					
					inMap.put("ALICI_HESAP_CINSI", "DK");
					inMap.put("ALICI_HESAP_NO", aliciHesap);
					inMap.put("ISLEM_SEKLI", "PREPAID");
					
					String desc = getDesc (clksHavaleGirisTx);
					inMap.put("ACIKLAMA", getMessage("3433", desc));
				}
			  	}
			}
			
			clksHavaleGirisTx.setAliciHesapNo(new BigDecimal(aliciHesap));
			session.saveOrUpdate(clksHavaleGirisTx);
			session.flush();
			
			if(clksHavaleGirisTx.getIslem().intValue() == ClksConstants.ISLEM_TOPUP_PASSOLIG_KART || clksHavaleGirisTx.getIslem().intValue() == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KIMLIK) {

				String aciklama = (clksHavaleGirisTx.getAciklama() == null) ? "" : clksHavaleGirisTx.getAciklama();
				
				if(new BigDecimal(1).equals(clksHavaleGirisTx.getKasaKimlikTipi())) {
					inMap.put("ACIKLAMA", getMessage("3434", getDesc(clksHavaleGirisTx)).concat(aciklama));
				} else {
					inMap.put("ACIKLAMA", getMessage("3433", getDesc(clksHavaleGirisTx)).concat(aciklama));
				}
			}
			
			
			inMap.put("KART_NO", cardNo);
			inMap.put("TCKN", clksHavaleGirisTx.getTcKimlikNo());
			inMap.put("URUN_KODU", clksHavaleGirisTx.getUrunKodu());
			inMap.put("LOGO_KODU", clksHavaleGirisTx.getLogoKodu());
			inMap.put("EUPT_HESAP_NO", hesapNo);
			inMap.put("TUTAR", clksHavaleGirisTx.getTutar());
			inMap.put("DOVIZ_KODU", clksHavaleGirisTx.getDovizKodu());
			inMap.put("MASRAF_TUTAR", clksHavaleGirisTx.getMasrafTutari());
			inMap.put("MASRAF_DOVIZ_KODU", clksHavaleGirisTx.getMasrafTahsilDoviz());
			inMap.put("BASVURU_NO", clksHavaleGirisTx.getBasvuruNo());
			inMap.put("ISLEM_CINSI", iMap.getString("OPERATION_TYPE"));
			inMap.put("RRN", iMap.getString("RRN"));
			inMap.put("KART_KAYNAGI", dest);
			inMap.put("REF_TX_NO", iMap.getBigDecimal("TX_NO"));
			inMap.put("TX_NO_VAR","0");
						
			String islemKod = (String) DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_kod(?)}", Types.VARCHAR, iMap.getBigDecimal("TX_NO"));
			inMap.put("KANAL", islemKod.equals(Transaction.KART_PASSO_YATAN.toString()) ? KART_KANAL_GISE : KART_KANAL_ATM);
			
			inMap.put("BORC_HESAP_CINSI", "VS");
			inMap.put("BORC_HESAP_NO", clksHavaleGirisTx.getBorcHesapNo());
			inMap.put("MASRAF_HESAP_NO", clksHavaleGirisTx.getMasrafHesapNo());
			GMServiceExecuter.call("BNSPR_KARTA_PARA_YUKLE_PTT", inMap);
		}
		return new GMMap();
	}

	@SuppressWarnings("unchecked")
	public static BigDecimal getDebitAccountNo(GMMap cardInfoMap) {
		
		List<GMMap> cardAccount = (List<GMMap>) cardInfoMap.get("CARD_DETAIL_INFO", 0, "DEBIT_ACCOUNT_LIST");
		GMMap accMap = new GMMap(cardAccount.get(0));
		
		for (int i = 0; i < accMap.getSize("DEBIT_ACCOUNT_LIST"); i++) {
			
			if (accMap.getString("DEBIT_ACCOUNT_LIST", i, "DEBIT_ACCOUNT_TYPE").equals(Debit_Main_Account)) {
					
					return accMap.getBigDecimal("DEBIT_ACCOUNT_LIST", i, "DEBIT_ACCOUNT_NO");
				}
		}
		return BigDecimal.ZERO;
	}
	
	private static String getGlobalParam(String kod){
		GMMap iMapG = new GMMap();
		iMapG.put("KOD", kod);
		iMapG.put("TRIM_QUOTES", true);
	    String dkNo =GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
	    return dkNo;
	}
	
	private static String getMessage(String kod,String pValue){
	    GMMap iMapG = new GMMap();
	    iMapG.put("MESSAGE_NO", new BigDecimal(kod));      
	   if (pValue !=null) { 
	       iMapG.put("P1",pValue);
	   }
	   return  (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMapG).get("ERROR_MESSAGE");
	}
	
	private static String getDesc(ClksHavaleGirisTx clksHavaleGirisTx) {
	    String desc = "";
	    String nameSurName = clksHavaleGirisTx.getIslemiYapanAdsoyad();
	    String tckn = clksHavaleGirisTx.getTcKimlikNo();
	    if (nameSurName !=null) {
	        desc = nameSurName;
	    }else if (tckn !=null) {
	       desc = tckn; 
	    }
	    return desc;
	}
	
	@GraymoundService("BNSPR_IBAN_KONTROL")
	public static GMMap bnsprIbanKontrol(GMMap iMap) {
	    GMMap oMap = new GMMap();
	    
	    String funcStr = "{? = call pkg_iban.sp_IBAN_Kontrol_Et(?)}";
		String control;
	    int i = 0;
		
		Object [] inputValues = new Object [8];
		
		try {
			
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ALICI_IBAN");
			control = (String)DALUtil.callOracleFunction(funcStr, BnsprType.STRING, inputValues);
		
			// Case: Invalid IBAN
			if ("0".equals(control)) {
				iMap.put("HATA_NO", "694");
	            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		}
		catch(Exception e) {
			
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		
	    return oMap;
	}
	
	@GraymoundService("BNSPR_CLKS_GET_F_GECICI_HESAP")
	public static GMMap bnsprClksGetFGeciciHesap(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		oMap.put("F_GECICI_HESAP", "H");
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("ISLEM_NO"));
			oMap.put("F_GECICI_HESAP", clksHavaleGirisTx.getFGeciciHesap());
		}
		
		catch(Exception e) {
			logger.error("BNSPR_CLKS_GET_F_GECICI_HESAP err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
}
