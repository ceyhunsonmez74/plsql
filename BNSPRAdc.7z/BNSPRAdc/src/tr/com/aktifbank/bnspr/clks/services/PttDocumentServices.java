package tr.com.aktifbank.bnspr.clks.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class PttDocumentServices {
	public static final String KIMLIK_ADRES_TEYIT_FORMU = "110";
	public static final String CERCEVE_SOZLESMESI = "45";
	public static final String BONO_HALKA_ARZ_TALEP_FORMU = "117";
	public static final String BONO_ERKEN_SATIS_TALEP_FORMU = "118";
	public static final String SIGORTA_BEYAN_FORMU_DASK = "150";
	public static final String SIGORTA_BEYAN_FORMU_TRAFIK = "151";
	public static final String SIGORTA_BEYAN_FORMU_KASKO= "159";
	public static final String SIGORTA_BEYAN_FORMU_FERDI_KAZA = "152";
	public static final String SIGORTA_BEYAN_FORMU_GUVENLI_CUZDAN = "596";
	public static final String SIGORTA_BEYAN_FORMU_ESYA = "153";
	public static final String SIGORTA_BEYAN_FORMU_CUZDAN = "154";
	public static final String SIGORTA_BEYAN_FORMU_AILEM_DESTEK = "155";
	public static final String SIGORTA_BEYAN_FORMU_HAYAT = "156";
	public static final String SIGORTA_BEYAN_FORMU_AILE_GUVENCE = "157";
	public static final String SIGORTA_BEYAN_FORMU_HASTALIK = "158";
	public static final String SIGORTA_BEYAN_FORMU_ASISTANS = "159";
    public static final String SIGORTA_BEYAN_FORMU_MINI_KASKO = "471";
    public static final String SIGORTA_BEYAN_FORMU_ACIL_SAGLIK = "484";
	public static final String SIGORTA_BEYAN_FORMU_KONUT_ESYA = "726";

	
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	private static final SimpleDateFormat dateFormat2 = new SimpleDateFormat("dd.MM.yyyy ");
    private static final SimpleDateFormat calendarFormat = new SimpleDateFormat("dd.MM.yyyy kk:mm:ss");
	
	/*
	 * INPUT iMap
	 * 	 	DOKUMAN_LIST
	 *			DOKUMAN_ID
	 * 		ISLEMI_YAPAN_KULLANICI	
	 * 			IYK_SICIL
	 * 			IYK_AD_SOYAD
	 * 			IYK_IL
	 * 			IYK_MERKEZ_SUBE
	 * 			IYK_MERKEZ
	 * 			IYK_SUBE
	 * 			IYK_BM
	 * 		PTT_ISLEM_NO	
	 * OUTPUT oMap
	 * 
	 * 	RESPONSE
	 * 	RESPONSE_DATA
	 * 	BANKA_ISLEM_NO
	 * 	BARKOD
	 * 
	 * */
	@GraymoundService("PTT_DOCUMENT_DOKUMAN_GONDER")
	public static GMMap pttDokumanGonder(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		String call = "{call PKG_PTT_DOKUMAN.WS_Dokuman_Gonder(?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection conn = null;
		
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			Long banka_islem_no=-1L;
			
			 for (int i = 0; i < iMap.getSize("DOKUMAN_LIST"); i++) {
				stmt.setLong	(1, iMap.getLong  ("DOKUMAN_LIST",i,"DOKUMAN_ID"));//pn_dokuman_id
				stmt.setString	(2, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_SICIL"));//ps_IYK_sicil
				stmt.setString	(3, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_AD_SOYAD"));//ps_IYK_adsoyad
				stmt.setString	(4, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_IL"));//ps_IYK_il
				stmt.setString	(5, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_MERKEZ_SUBE"));//ps_IYK_merkez_sube
				stmt.setString	(6, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_MERKEZ"));//ps_IYK_merkez
				stmt.setString	(7, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_SUBE"));//ps_IYK_sube
				stmt.setString	(8, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_BM"));//ps_IYK_bm
				stmt.setLong	(9, iMap.getLong("PTT_ISLEM_NO"));//pn_ptt_islem_no
				stmt.setLong	(10, banka_islem_no);//pn_ptt_islem_no
				stmt.registerOutParameter(10, Types.NUMERIC);//pn_banka_islem_no
				stmt.registerOutParameter(11, Types.VARCHAR);// RESPONSE
				stmt.registerOutParameter(12, Types.VARCHAR);// RESPONSE_DATA
				stmt.registerOutParameter(13, Types.VARCHAR);//ps_barkod
				stmt.execute();
				banka_islem_no=stmt.getLong(10);
				if (!"2".equals(stmt.getString(11))) {
					throw new GMRuntimeException(0,stmt.getString(12), true);
				}
			}
			
			stmt.setLong	(1, -1);//pn_dokuman_id
			stmt.setString	(2, null);//ps_IYK_sicil
			stmt.setString	(3, null);//ps_IYK_adsoyad
			stmt.setString	(4, null);//ps_IYK_il
			stmt.setString	(5, null);//ps_IYK_merkez_sube
			stmt.setString	(6, null);//ps_IYK_merkez
			stmt.setString	(7, null);//ps_IYK_sube
			stmt.setString	(8, null);//ps_IYK_bm
			stmt.setLong	(9, -1);//pn_ptt_islem_no
			stmt.setLong	(10, banka_islem_no);//pn_ptt_islem_no
			stmt.registerOutParameter(10, Types.NUMERIC);//pn_banka_islem_no
			stmt.registerOutParameter(11, Types.VARCHAR);// RESPONSE
			stmt.registerOutParameter(12, Types.VARCHAR);// RESPONSE_DATA
			stmt.registerOutParameter(13, Types.VARCHAR);//ps_barkod
			stmt.execute();
			
			oMap.put("BANKA_ISLEM_NO"	, stmt.getLong(10));
			oMap.put("RESPONSE"			, stmt.getString(11));
			oMap.put("RESPONSE_DATA"	, stmt.getString(12));
			oMap.put("BARKOD"			, stmt.getString(13));

		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e,false);
		
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
		
		return oMap;
	}
	
	/*INPUT iMap
	 * 
	 *	ISLEM_TIPI
	 *	PTT_SICIL
	 *	PTT_MERKEZ
	 *	PTT_SUBE
	 *	TC_KIMLIK_NO
	 *	BASLANGIC_TARIHI
	 *	BITIS_TARIHI
	 *	BELGE_TIPI
	 *
	 * OUTPUT oMap
	 * 
	 *	RESPONSE	
	 *	RESPONSE_DATA	
	 *	BELGE_LISTESI	
	 *		DOKUMAN_ID
	 *		TC_KIMLIK_NO
	 *		AD_SOYAD
	 *		ISLEM_TIP
	 *		BELGE_TIP
	 *		ALINDI_TARIH
	 *		BELGE_DURUM
	 * */
	
	@GraymoundService("PTT_DOCUMENT_DOKUMAN_GONDER_SORGULA")
	public static GMMap pttDokumanGonderSorgula(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet resSet = null	;
		
		String call = "{call PKG_PTT_DOKUMAN.WS_Dokuman_Gonder_Sorgula(?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection conn = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			stmt.setString(1, iMap.getString("ISLEM_TIPI"));//islem_tipi
			stmt.setString(2, iMap.getString("PTT_SICIL"));//ps_PTT_sicil
			stmt.setString(3, iMap.getString("PTT_MERKEZ"));//ps_PTT_merkez
			stmt.setString(4, iMap.getString("PTT_SUBE"));//PTT_Sube
			stmt.setString(5, iMap.getString("TC_KIMLIK_NO"));//TC_Kimlik_No
			stmt.setDate(6,getSqlDate(iMap.getString("BASLANGIC_TARIHI")));//pd_bastar
			stmt.setDate(7, getSqlDate(iMap.getString("BITIS_TARIHI")));//pd_bittar
			stmt.setString(8, iMap.getString("BELGE_TIPI"));//ps_belge_tipi
			stmt.setString(9, iMap.getString("BASMUDURLUK"));
			
			stmt.registerOutParameter(10, java.sql.Types.VARCHAR);//ps_response
			stmt.registerOutParameter(11, java.sql.Types.VARCHAR);//ps_response_data
			stmt.registerOutParameter(12, -10);//rec_belge_liste
			
			stmt.execute();
			stmt.getMoreResults();
			
			oMap.put("RESPONSE", stmt.getString(10));
			oMap.put("RESPONSE_DATA", stmt.getString(11));
			
			
			if ("2".equals(oMap.getString("RESPONSE"))) {
				
				resSet = (ResultSet)stmt.getObject(12);
				int i = 0;
				while(resSet.next()){
					
					oMap.put("BELGE_LISTESI", i,"DOKUMAN_ID"	, resSet.getString("dokuman_id"));
					oMap.put("BELGE_LISTESI", i,"PTT_SUBE", resSet.getString("ptt_sube"));
					oMap.put("BELGE_LISTESI", i,"TC_KIMLIK_NO"	, resSet.getString("tc_kimlik_no"));
					oMap.put("BELGE_LISTESI", i,"AD_SOYAD"		, resSet.getString("ad_soyad"));
					oMap.put("BELGE_LISTESI", i,"ISLEM_TIP"		, resSet.getString("islem_tip"));
					oMap.put("BELGE_LISTESI", i,"BELGE_TIP"		, resSet.getString("belge_tip"));
					oMap.put("BELGE_LISTESI", i,"ALINDI_TARIH"	, resSet.getString("alindi_tarih"));
					oMap.put("BELGE_LISTESI", i,"BELGE_DURUM"	, resSet.getString("belge_durum"));
					oMap.put("BELGE_LISTESI", i,"ISLEM_TARIHI"	, resSet.getString("islem_tarihi"));
					oMap.put("BELGE_LISTESI", i,"PTT_ISLEM_NO"	, resSet.getString("ptt_islem_no"));
					oMap.put("BELGE_LISTESI", i,"TUTAR"	, resSet.getString("tutar"));
					i++;
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e,false);
		}
		finally {
			GMServerDatasource.close(resSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("PTT_DOCUMENT_DOKUMAN_GONDER_IPTAL")
	public static GMMap pttDokumanGonderIptal(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		String call = "{call PKG_PTT_DOKUMAN.WS_Dokuman_Gonder_Iptal(?,?,?)}";
		Connection conn = null;
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			//Banka_Islem_No
			stmt.setLong(1, iMap.getLong("BANKA_ISLEM_NO"));
		
			// RESPONSE 
			stmt.registerOutParameter(2, Types.VARCHAR);
			// RESPONSE_DATA
			stmt.registerOutParameter(3, Types.VARCHAR);
		
			stmt.execute();
			
			oMap.put("RESPONSE", stmt.getString(2));
			oMap.put("RESPONSE_DATA",  stmt.getString(3));
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e,false);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
		
		return oMap;
	}
	
	
	/*
	 * INPUT iMap	
	 * 		ISLEM_TIPI	
	 * 		BELGE_TIPI	
	 * 		PTT_MERKEZ	
	 * 		PTT_SUBE	
	 * 		TC_KIMLIK_NO	
	 * 		AL_BASLANGIC_TARIHI	
	 * 		AL_BITIS_TARIHI	
	 * 		GON_BASLANGIC_TARIHI	
	 * 		GON_BITIS_TARIHI	
	 * 		ALINDI_DURUM	
	 * 		BELGE_DURUM	
	 * 	
	 * OUTPUT  oMap	
	 * 		RESPONSE	
	 * 		RESPONSE_DATA	
	 * 		BELGE_LISTESI	
	 * 			DOKUMAN_ID
	 * 			PTT_SUBE
	 * 			PTT_SICIL
	 * 			TC_KIMLIK_NO
	 * 			AD_SOYAD
	 * 			ISLEM_TIP
	 * 			BELGE_TIP
	 * 			ALINDI_TARIH
	 * 			GONDERILDI_TARIH
	 * 			BASVURU_TARIH
	 * 			ALINDI
	 * 			BELGE_DURUM
	 * 			STATU_KOD
	 * 			ALT_STATU_KOD
	 * 			BARKOD
	 * 			YAZDIR
	 * 			EKSIK_EVRAK_TAMALA
	 * 
	 * */
	@GraymoundService("PTT_DOCUMENT_DOKUMAN_IZLEME_SORGULA")
	public static GMMap pttDokumanIzlemeSorgula(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet resSet = null	;
		
		String call = "{call PKG_PTT_DOKUMAN.WS_Dokuman_Izleme_Sorgula(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		Connection conn = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			 
			int index = 1;
			stmt.setString	(index++, iMap.getString("ISLEM_TIPI"));//ps_islem_tipi
			stmt.setString	(index++, iMap.getString("BELGE_TIPI"));//ps_belge_tipi
			stmt.setString	(index++, iMap.getString("PTT_MERKEZ"));//ps_PTT_merkez
			stmt.setString	(index++, iMap.getString("PTT_SUBE"));//ps_PTT_sube
			stmt.setString	(index++, iMap.getString("TC_KIMLIK_NO"));//ps_tckn
			stmt.setDate	(index++, getSqlDate(iMap.getString("AL_BASLANGIC_TARIHI")));//pd_al_bastar
			stmt.setDate	(index++, getSqlDate(iMap.getString("AL_BITIS_TARIHI")));//pd_al_bittar
			stmt.setDate	(index++, getSqlDate(iMap.getString("GON_BASLANGIC_TARIHI")));//pd_gon_bastar
			stmt.setDate	(index++, getSqlDate(iMap.getString("GON_BITIS_TARIHI")));//pd_al_bittar
			stmt.setString	(index++, iMap.getString("ALINDI_DURUM"));//ps_alindi_durum
			stmt.setString	(index++, iMap.getString("BELGE_DURUM"));//ps_belge_durum
			stmt.setString	(index++, iMap.getString("BASMUDURLUK"));//ps_basmudurluk
			stmt.setString	(index++, iMap.getString("PTT_SICIL"));// ps_PTT_sicil
			stmt.setString	(index++, iMap.getString("BELGE_PTT_DURUM"));// ps_belge_PTT_durum
			stmt.setString	(index++, iMap.getString("MENU"));// ps_menu
			
			stmt.registerOutParameter(index++, java.sql.Types.VARCHAR);//ps_response
			stmt.registerOutParameter(index++, java.sql.Types.VARCHAR);//ps_response_data
			stmt.registerOutParameter(index++, -10);//rec_belge_liste
			
			stmt.execute();
			stmt.getMoreResults();
			
			oMap.put("RESPONSE", stmt.getString(16));
			oMap.put("RESPONSE_DATA", stmt.getString(17));
			
			if ("2".equals(oMap.getString("RESPONSE"))) {
				
				resSet = (ResultSet)stmt.getObject(18);
				int i = 0;
				while(resSet.next()) {
					oMap.put("BELGE_LISTESI", i,"DOKUMAN_ID"	, resSet.getString("dokuman_id"));
					oMap.put("BELGE_LISTESI", i,"PTT_SUBE"		, resSet.getString("ptt_sube"));
					oMap.put("BELGE_LISTESI", i,"PTT_SICIL"		, resSet.getString("Ptt_Sicil"));
					oMap.put("BELGE_LISTESI", i,"PTT_AD_SOYAD"		, resSet.getString("Ptt_Ad_Soyad"));
					oMap.put("BELGE_LISTESI", i,"TC_KIMLIK_NO"	, resSet.getString("tc_kimlik_no"));
					oMap.put("BELGE_LISTESI", i,"AD_SOYAD"		, resSet.getString("ad_soyad"));
					oMap.put("BELGE_LISTESI", i,"ISLEM_TIP"		, resSet.getString("islem_tip"));
					oMap.put("BELGE_LISTESI", i,"BELGE_TIP"		, resSet.getString("belge_tip"));
					oMap.put("BELGE_LISTESI", i,"ALINDI_TARIH"	, resSet.getString("alindi_tarihi"));
					oMap.put("BELGE_LISTESI", i,"GONDERILDI_TARIH", resSet.getString("gonderildi_tarihi"));
					oMap.put("BELGE_LISTESI", i,"BASVURU_TARIH"	, resSet.getString("basvuru_tarihi"));
					oMap.put("BELGE_LISTESI", i,"ALINDI"		, resSet.getString("f_alindi"));
					oMap.put("BELGE_LISTESI", i,"BELGE_DURUM"	, resSet.getString("belge_durum"));
					oMap.put("BELGE_LISTESI", i,"STATU_KOD"		, resSet.getString("statu_kod"));
					oMap.put("BELGE_LISTESI", i,"ALT_STATU_KOD"	, resSet.getString("alt_statu_kod"));
					oMap.put("BELGE_LISTESI", i,"BARKOD"		, resSet.getString("barkod"));
					oMap.put("BELGE_LISTESI", i,"YAZDIR"		, resSet.getString("YAZDIR"));
					oMap.put("BELGE_LISTESI", i,"EKSIK_EVRAK_TAMAMLA", resSet.getString("EKSIK_EVRAK_TAMAMLA"));
					i++;
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e,false);
		}
		finally {
			GMServerDatasource.close(resSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("PTT_DOCUMENT_DOKUMAN_IZLEME_ALINDI")
	public static GMMap pttDokumanIzlemeAlindi(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		String call = "{call PKG_PTT_DOKUMAN.WS_Dokuman_Izleme_Alindi(?,?,?,?,?,?,?,?,?,?,?)}";
		Connection conn = null;
		
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			Long banka_islem_no=-1L;
			for (int i = 0; i < iMap.getSize("DOKUMAN_LIST"); i++) {
				stmt.setLong(1, iMap.getLong  ("DOKUMAN_LIST",i,"DOKUMAN_ID"));//pn_dokuman_id
				stmt.setString(2, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_SICIL"));//ps_IYK_sicil
				stmt.setString(3, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_AD_SOYAD"));//ps_IYK_adsoyad
				stmt.setString(4, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_IL"));//ps_IYK_il
				stmt.setString(5, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_MERKEZ_SUBE"));//ps_IYK_merkez_sube
				stmt.setString(6, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_MERKEZ"));//ps_IYK_merkez
				stmt.setString(7, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_SUBE"));//ps_IYK_sube
				stmt.setString(8, iMap.getString("ISLEMI_YAPAN_KULLANICI", 0, "IYK_BM"));//ps_IYK_bm				
				stmt.setLong(9, banka_islem_no);//pn_banka_islem_no
				
				stmt.registerOutParameter(9, Types.NUMERIC);// BANKA_ISLEM_NO
				stmt.registerOutParameter(10, Types.VARCHAR);// RESPONSE
				stmt.registerOutParameter(11, Types.VARCHAR);// RESPONSE_DATA
				stmt.execute();
				
				banka_islem_no=stmt.getLong(9);
			}
			
			stmt.setLong(1, -1);//pn_dokuman_id
			stmt.setString(2, null);//ps_IYK_sicil
			stmt.setString(3, null);//ps_IYK_adsoyad
			stmt.setString(4, null);//ps_IYK_il
			stmt.setString(5, null);//ps_IYK_merkez_sube
			stmt.setString(6, null);//ps_IYK_merkez
			stmt.setString(7, null);//ps_IYK_sube
			stmt.setString(8, null);//ps_IYK_bm				
			stmt.setLong(9, banka_islem_no);//pn_banka_islem_no
			
			stmt.registerOutParameter(9, Types.NUMERIC);// BANKA_ISLEM_NO
			stmt.registerOutParameter(10, Types.VARCHAR);// RESPONSE
			stmt.registerOutParameter(11, Types.VARCHAR);// RESPONSE_DATA
			stmt.execute();
			
			//oMap.put("BANKA_ISLEM_NO", stmt.getLong(9));
			oMap.put("RESPONSE", stmt.getString(10));
			oMap.put("RESPONSE_DATA", stmt.getString(11));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e,false);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			
		}
		
		return oMap;
	}
	
	
	/*
	 * INPUT iMap
	 * 		DOKUMAN_ID	
     *	
     *  OUTPUT oMap	
     *		RESPONSE	
     *		RESPONSE_DATA	
     *		BELGE_BILGI	
	 *			BARKOD
	 *			TC_KIMLIK_NO
	 *			UYRUK
	 *			AD_SOYAD
	 *			ANNE_AD
	 *			BABA_AD
	 *			DOGUM_YER
	 *			DOGUM_TARIH
	 *			ANNE_KIZLIK_SOYAD
	 *			MESLEK
	 *			CALISMA_SEKLI
	 *			EV_ADRES
	 *			EV_ILCE
	 *			EV_IL
	 *			EV_TEL
	 *			ISYERI_AD
	 *			ISYERI_ADRES
	 *			IS_ILCE
	 *			IS_IL
	 *			IS_TEL
	 *			CEP_TEL
	 *			ILETISIM_ADRES
	 *			ILETISIM_TEL
	 *			YATIRIM_EKSTRE
	 *			KIMLIK_TIP
	 *			SERI_NO
	 *			VERILDIGI_YER
	 *			VERILDIGI_TARIH
	 * */
	@GraymoundService("PTT_DOCUMENT_DOKUMAN_IZLEME_YAZDIR")
	public static GMMap pttDokumanIzlemeYazdir(GMMap iMap)  {
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet resSet = null	;
		
		String call = "{call PKG_PTT_DOKUMAN.WS_Dokuman_Izleme_Yazdir(?,?,?,?)}";
		Connection conn = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			 
			stmt.setLong(1, iMap.getLong("DOKUMAN_ID"));//pn_dokuman_id
			stmt.registerOutParameter(2, java.sql.Types.VARCHAR);//ps_response
			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);//ps_response_data
			stmt.registerOutParameter(4, -10);//rec_belge_bilgi
			stmt.execute();
			stmt.getMoreResults();
			
			oMap.put("RESPONSE"		, stmt.getString(2));
			oMap.put("RESPONSE_DATA", stmt.getString(3));
			
			if ("2".equals(oMap.getString("RESPONSE"))) {
				resSet = (ResultSet)stmt.getObject(4);
				String dokumanAdi = null;
				int i = 0;
				while(resSet.next()) {
					dokumanAdi = resSet.getString("dokuman_adi");
					
					if (KIMLIK_ADRES_TEYIT_FORMU.equals(dokumanAdi) ) {
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i, "DOKUMAN_ADI", dokumanAdi);
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"BARKOD"			, resSet.getString("barkod"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"TC_KIMLIK_NO"		, resSet.getString("tc_kimlik_no"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"UYRUK"				, resSet.getString("Uyruk"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"AD_SOYAD"			, resSet.getString("ad_soyad"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"ANNE_AD"			, resSet.getString("anne_adi"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"BABA_AD"			, resSet.getString("baba_adi"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"DOGUM_YER"			, resSet.getString("dogum_yeri"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"DOGUM_TARIH"		, getDateString(resSet.getDate("dogum_tarihi")));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"ANNE_KIZLIK_SOYAD"	, resSet.getString("anne_kizlik_soyadi"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"MESLEK"			, resSet.getString("meslek"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"CALISMA_SEKLI"		, resSet.getString("calisma_sekli"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"EV_ADRES"			, resSet.getString("ev_adresi"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"EV_ILCE"			, resSet.getString("ev_ilce"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"EV_IL"				, resSet.getString("ev_il"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"EV_TEL"			, resSet.getString("ev_tel"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"ISYERI_AD"			, resSet.getString("isyeri_adi"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"ISYERI_ADRES"		, resSet.getString("is_adresi"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"IS_ILCE"			, resSet.getString("is_ilce"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"IS_IL"				, resSet.getString("is_il"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"IS_TEL"			, resSet.getString("is_tel"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"CEP_TEL"			, resSet.getString("cep_tel"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"ILETISIM_ADRES"	, resSet.getString("iletisim_adresi"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"ILETISIM_TEL"		, resSet.getString("iletisim_tel"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"YATIRIM_EKSTRE"	, resSet.getString("yatirim_ekstre"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"KIMLIK_TIP"		, resSet.getString("kimlik_tipi"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"SERI_NO"			, resSet.getString("seri_no"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"VERILDIGI_YER"		, resSet.getString("verildigi_yer"));
						oMap.put("KIMLIK_ADRES_TEYIT_FORMU", i,"VERILDIGI_TARIH"	, getDateString(resSet.getDate("verildigi_tarih")));
					}
					else if (BONO_HALKA_ARZ_TALEP_FORMU.equals(dokumanAdi) ||
							BONO_ERKEN_SATIS_TALEP_FORMU.equals(dokumanAdi)) {
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"DOKUMAN_ADI", dokumanAdi);
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"BARKOD", resSet.getString("barkod"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"TC_KIMLIK_NO", resSet.getString("tc_kimlik_no"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"AD_SOYAD", resSet.getString("ad_soyad"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"ADRES", resSet.getString("adres"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"HESAP_NO", resSet.getLong("hesap_no"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"SUBE", resSet.getString("sube"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"ISLEM_TARIHI", getDateString(resSet.getDate("islem_tarihi")));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"IHRAC_EDEN", resSet.getString("ihrac_eden"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"ISIN", resSet.getString("isin"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"NOMINAL", resSet.getDouble("nominal"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"ALIS_BEDELI", resSet.getDouble("alis_bedeli"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"BIRIM_FIYAT", resSet.getDouble("birim_fiyat"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"FAIZ_ORAN", resSet.getDouble("Faiz_oran"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"GERI_SATIS_TARIHI", getDateString(resSet.getDate("geri_satis_tarihi")));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"BRUT_GETIRI", resSet.getDouble("BRUT_GETIRI"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"NET_GETIRI", resSet.getDouble("NET_GETIRI"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"STOPAJ", resSet.getDouble("stopaj"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"TAHSIL_YONTEMI", resSet.getString("tahsil_yontemi"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"PCH", resSet.getString("pch"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"BANKA_HESAP_NO", resSet.getLong("banka_hesap_no"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"PTT_SICIL", resSet.getString("ptt_sicil"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"PTT_SICIL_AD_SOYAD", resSet.getString("ptt_sicil_ad_soyad"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"PTT_IL", resSet.getString("ptt_il"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"PTT_SUBE", resSet.getString("ptt_sube"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
							"ISLEM_REF_NO", resSet.getLong("islem_ref_no"));
						oMap.put("BONO_HALKA_ARZ_ERKEN_SATIS_TALEP_FORMU", i,
								"BONO_ALIS_TARIHI", getDateString(resSet.getDate("ba_alis_tarihi")));
					}
					else if(CERCEVE_SOZLESMESI.equals(dokumanAdi) ) {
						oMap.put("CERCEVE_SOZLESMESI", i,"DOKUMAN_ADI", 	dokumanAdi);
						oMap.put("CERCEVE_SOZLESMESI", i,"BARKOD", 			resSet.getString("barkod"));
						oMap.put("CERCEVE_SOZLESMESI", i,"TC_KIMLIK_NO", 	resSet.getString("tc_kimlik_no"));
						oMap.put("CERCEVE_SOZLESMESI", i,"AD_SOYAD",		resSet.getString("ad_soyad"));
						oMap.put("CERCEVE_SOZLESMESI", i,"EV_ADRESI", 		resSet.getString("ev_adresi"));
						oMap.put("CERCEVE_SOZLESMESI", i,"CEP_TEL", 		resSet.getString("cep_tel"));
						oMap.put("CERCEVE_SOZLESMESI", i,"EMAIL", 			resSet.getString("EMAIL"));
					}else if(SIGORTA_BEYAN_FORMU_FERDI_KAZA.equals(dokumanAdi) ) {
						String tableName = "SIGORTA_BEYAN_FORMU_FERDI_KAZA";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);
						oMap.put(tableName, i,"MESLEK_ACIKLAMA", 	resSet.getString("MESLEK_ACIKLAMA"));
						oMap.put(tableName, i,"TEHLIKELI_MESLEK_MI",resSet.getString("TEKLIKELI_MESLEK_MI"));
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
					}else if(SIGORTA_BEYAN_FORMU_GUVENLI_CUZDAN.equals(dokumanAdi) ) {
						String tableName = "SIGORTA_BEYAN_FORMU_GUVENLI_CUZDAN";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);
						oMap.put(tableName, i,"MESLEK_ACIKLAMA", 	resSet.getString("MESLEK_ACIKLAMA"));
						oMap.put(tableName, i,"TEHLIKELI_MESLEK_MI",resSet.getString("TEKLIKELI_MESLEK_MI"));
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
					}
					
					else if(SIGORTA_BEYAN_FORMU_ESYA.equals(dokumanAdi) || SIGORTA_BEYAN_FORMU_KONUT_ESYA.equals(dokumanAdi) ) {
						String tableName = "SIGORTA_BEYAN_FORMU_ESYA";
						if(SIGORTA_BEYAN_FORMU_KONUT_ESYA.equals(dokumanAdi))
							tableName = "SIGORTA_BEYAN_FORMU_KONUT_ESYA";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);
						oMap.put(tableName, i,"RIZIKO_ADRES_IL", 	resSet.getString("RIZIKO_ADRES_IL"));
						oMap.put(tableName, i,"RIZIKO_ADRES_ILCE", 	resSet.getString("RIZIKO_ADRES_ILCE"));
						oMap.put(tableName, i,"RIZIKO_ADRES_BELDE", resSet.getString("RIZIKO_ADRES_BELDE"));
						oMap.put(tableName, i,"RIZIKO_ADRES_MAHALLE",resSet.getString("RIZIKO_ADRES_MAHALLE"));
						oMap.put(tableName, i,"RIZIKO_ADRES_CADDE_SOKAK",resSet.getString("RIZIKO_ADRES_CADDE_SOKAK"));
						oMap.put(tableName, i,"RIZIKO_ADRES_APT",	resSet.getString("RIZIKO_ADRES_APT"));
						oMap.put(tableName, i,"RIZIKO_ADRES_BINA",	resSet.getString("RIZIKO_ADRES_BINA"));
						oMap.put(tableName, i,"RIZIKO_ADRES_KAT",	resSet.getString("RIZIKO_ADRES_KAT"));
						oMap.put(tableName, i,"RIZIKO_ADRES_DAIRE",	resSet.getString("RIZIKO_ADRES_DAIRE"));
						oMap.put(tableName, i,"RIZIKO_ADRES_POSTA_KODU",resSet.getString("RIZIKO_ADRES_POSTA_KODU"));
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
					}else if(SIGORTA_BEYAN_FORMU_DASK.equals(dokumanAdi) ) {
						String tableName = "SIGORTA_BEYAN_FORMU_DASK";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);
						oMap.put(tableName, i,"RIZIKO_ADRES_IL", 	resSet.getString("RIZIKO_ADRES_IL"));
						oMap.put(tableName, i,"RIZIKO_ADRES_ILCE", 	resSet.getString("RIZIKO_ADRES_ILCE"));
						oMap.put(tableName, i,"RIZIKO_ADRES_BELDE", resSet.getString("RIZIKO_ADRES_BELDE"));
						oMap.put(tableName, i,"RIZIKO_ADRES_MAHALLE",resSet.getString("RIZIKO_ADRES_MAHALLE"));
						oMap.put(tableName, i,"RIZIKO_ADRES_CADDE_SOKAK",resSet.getString("RIZIKO_ADRES_CADDE_SOKAK"));
						oMap.put(tableName, i,"RIZIKO_ADRES_APT",	resSet.getString("RIZIKO_ADRES_APT"));
						oMap.put(tableName, i,"RIZIKO_ADRES_BINA",	resSet.getString("RIZIKO_ADRES_BINA"));
						oMap.put(tableName, i,"RIZIKO_ADRES_KAT",	resSet.getString("RIZIKO_ADRES_KAT"));
						oMap.put(tableName, i,"RIZIKO_ADRES_DAIRE",	resSet.getString("RIZIKO_ADRES_DAIRE"));
						oMap.put(tableName, i,"RIZIKO_ADRES_POSTA_KODU",resSet.getString("RIZIKO_ADRES_POSTA_KODU"));
						oMap.put(tableName, i,"RIZIKO_ADA",	resSet.getString("RIZIKO_ADA"));
						oMap.put(tableName, i,"RIZIKO_PARSEL",	resSet.getString("RIZIKO_PARSEL"));
						oMap.put(tableName, i,"RIZIKO_PAFTA",	resSet.getString("RIZIKO_PAFTA"));
						oMap.put(tableName, i,"RIZIKO_SAYFA_NO",resSet.getString("RIZIKO_SAYFA_NO"));
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
						oMap.put(tableName, i,"INSA_YILI",resSet.getString("INSA_YILI"));
						oMap.put(tableName, i,"TOPLAM_KAT_SAYISI",resSet.getString("TOPLAM_KAT_SAYISI"));
						oMap.put(tableName, i,"HASAR_DURUMU",resSet.getString("HASAR_DURUMU"));
						oMap.put(tableName, i,"TAPU_KACKISILIK",resSet.getString("TAPU_KACKISILIK"));
						oMap.put(tableName, i,"DAINI_MURTEHIN_VAR_MI",resSet.getString("DAINI_MURTEHIN_VAR_MI"));
						oMap.put(tableName, i,"DM_BANKA",resSet.getString("DM_BANKA"));
						oMap.put(tableName, i,"DM_BANKA_SUBE",resSet.getString("DM_BANKA_SUBE"));
						oMap.put(tableName, i,"DM_FINANS_KURUMU",resSet.getString("DM_FINANS_KURUMU"));
						oMap.put(tableName, i,"DM_KREDI_TUTARI",resSet.getString("DM_KREDI_TUTARI"));
						oMap.put(tableName, i,"DM_DOVIZ_CINSI",resSet.getString("DM_DOVIZ_CINSI"));
						oMap.put(tableName, i,"DM_BITIS_TARIHI",resSet.getString("DM_BITIS_TARIHI"));
						oMap.put(tableName, i,"DM_SOZLESME_NO",resSet.getString("DM_SOZLESME_NO"));
						oMap.put(tableName, i,"DM_OZEL_NOT",resSet.getString("DM_OZEL_NOT"));
						oMap.put(tableName, i,"YENILEME_MI",resSet.getString("YENILEME_MI"));
						oMap.put(tableName, i,"POLICE_NO",resSet.getString("POLICE_NO"));
						oMap.put(tableName, i,"KONUT_KULLANIM_AMACI",resSet.getString("KONUT_KULLANIM_AMACI"));
						oMap.put(tableName, i,"BINA_ALANI",resSet.getString("BINA_ALANI"));
						oMap.put(tableName, i,"YAPI_TARZI",resSet.getString("YAPI_TARZI"));
						oMap.put(tableName, i,"TAKSIT_SAYISI",resSet.getString("TAKSIT_SAYISI"));
					}else if(SIGORTA_BEYAN_FORMU_TRAFIK.equals(dokumanAdi) ) {
						String tableName = "SIGORTA_BEYAN_FORMU_TRAFIK";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
						oMap.put(tableName, i,"TESCIL_IL", 		resSet.getString("TESCIL_IL"));
						oMap.put(tableName, i,"TESCIL_ILCE", 		resSet.getString("TESCIL_ILCE"));
						oMap.put(tableName, i,"PLAKA", 		resSet.getString("PLAKA"));
						oMap.put(tableName, i,"ABSIS_NO_MU", 		resSet.getString("ABSIS_NO_MU"));
						oMap.put(tableName, i,"SERI_KOD", 		resSet.getString("SERI_KOD"));
						oMap.put(tableName, i,"TESCIL_SERI_ABSIS_NO", 		resSet.getString("TESCIL_SERI_ABSIS_NO"));
						oMap.put(tableName, i,"YENILEME_MI", 		resSet.getString("YENILEME_MI"));
						oMap.put(tableName, i,"POLICE_NO", 		resSet.getString("POLICE_NO"));
						oMap.put(tableName, i,"MARKA", 		resSet.getString("MARKA"));
						oMap.put(tableName, i,"MODEL", 		resSet.getString("MODEL"));
						oMap.put(tableName, i,"TIP", 		resSet.getString("TIP"));
						oMap.put(tableName, i,"TUR", 		resSet.getString("TUR"));
						oMap.put(tableName, i,"YOLCU_ADEDI", 		resSet.getString("YOLCU_ADEDI"));
						oMap.put(tableName, i,"SURUCU_ADEDI", 		resSet.getString("SURUCU_ADEDI"));
						oMap.put(tableName, i,"TRAFIGE_CIKIS_TARIHI", 		resSet.getString("TRAFIGE_CIKIS_TARIHI"));
						oMap.put(tableName, i,"TESCIL_TARIHI", 		resSet.getString("TESCIL_TARIHI"));
						oMap.put(tableName, i,"ZKYTMS_VAR", 		resSet.getString("ZKYTMS_VAR"));
						oMap.put(tableName, i,"ZKYTMS_POLICE_NO", 		resSet.getString("ZKYTMS_POLICE_NO"));
						oMap.put(tableName, i,"TAS_SIRKET_KODU", 		resSet.getString("TAS_SIRKET_KODU"));
						oMap.put(tableName, i,"OGRENCI_SERVISI", 		resSet.getString("OGRENCI_SERVISI"));
						oMap.put(tableName, i,"TRAFIK_YARDIM_VAR", 		resSet.getString("TRAFIK_YARDIM_VAR"));
						oMap.put(tableName, i,"TAKSIT_SAYISI",resSet.getString("TAKSIT_SAYISI"));
					}else if(SIGORTA_BEYAN_FORMU_KASKO.equals(dokumanAdi) ) {
						String tableName = "SIGORTA_BEYAN_FORMU_KASKO";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);	
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
						oMap.put(tableName, i,"PLAKA",resSet.getString("PLAKA"));
						oMap.put(tableName, i,"YENILEME_MI",resSet.getString("YENILEME_MI"));
						oMap.put(tableName, i,"POLICE_NO",resSet.getString("POLICE_NO"));
						oMap.put(tableName, i,"MARKA",resSet.getString("MARKA"));
						oMap.put(tableName, i,"MODEL",resSet.getString("MODEL"));
						oMap.put(tableName, i,"TIP",resSet.getString("TIP"));
						oMap.put(tableName, i,"TUR",resSet.getString("TUR"));
						oMap.put(tableName, i,"KULLANIM_SEKLI",resSet.getString("KULLANIM_SEKLI"));
						oMap.put(tableName, i,"TESCIL_TARIHI",resSet.getString("TESCIL_TARIHI"));
						oMap.put(tableName, i,"LPGLI_MI",resSet.getString("LPGLI_MI"));
						oMap.put(tableName, i,"LPG_ORJINAL_MI",resSet.getString("LPG_ORJINAL_MI"));
						oMap.put(tableName, i,"LPG_MARKA",resSet.getString("LPG_MARKA"));
						oMap.put(tableName, i,"LPG_BEDEL",resSet.getString("LPG_BEDEL"));
						oMap.put(tableName, i,"ILAVE_AKS_VAR_MI",resSet.getString("ILAVE_AKS_VAR_MI"));
						oMap.put(tableName, i,"SES_SIS_VAR_MI",resSet.getString("SES_SIS_VAR_MI"));
						oMap.put(tableName, i,"SES_SIS_ORJINAL_MI",resSet.getString("SES_SIS_ORJINAL_MI"));
						oMap.put(tableName, i,"SES_SIS_MARKA",resSet.getString("SES_SIS_MARKA"));
						oMap.put(tableName, i,"SES_SIS_BEDEL",resSet.getString("SES_SIS_BEDEL"));
						oMap.put(tableName, i,"GORUNTU_SIS_VAR_MI",resSet.getString("GORUNTU_SIS_VAR_MI"));
						oMap.put(tableName, i,"GORUNTU_SIS_ORJINAL_MI",resSet.getString("GORUNTU_SIS_ORJINAL_MI"));
						oMap.put(tableName, i,"GORUNTU_SIS_MARKA",resSet.getString("GORUNTU_SIS_MARKA"));
						oMap.put(tableName, i,"GORUNTU_SIS_BEDEL",resSet.getString("GORUNTU_SIS_BEDEL"));
						oMap.put(tableName, i,"DIGER_AKS_BEDEL",resSet.getString("DIGER_AKS_BEDEL"));
						oMap.put(tableName, i,"YOLCU_ADEDI",resSet.getString("YOLCU_ADEDI"));
						oMap.put(tableName, i,"SURUCU_ADEDI",resSet.getString("SURUCU_ADEDI"));
						oMap.put(tableName, i,"TAKSIT_SAYISI",resSet.getString("TAKSIT_SAYISI"));
						oMap.put(tableName, i,"DAINI_MURTEHIN_VAR_MI",resSet.getString("DAINI_MURTEHIN_VAR_MI"));
						oMap.put(tableName, i,"DM_BANKA",resSet.getString("DM_BANKA"));
						oMap.put(tableName, i,"DM_BANKA_SUBE",resSet.getString("DM_BANKA_SUBE"));
						oMap.put(tableName, i,"DM_FINANS_KURUMU",resSet.getString("DM_FINANS_KURUMU"));
						oMap.put(tableName, i,"DM_KREDI_TUTARI",resSet.getString("DM_KREDI_TUTARI"));
						oMap.put(tableName, i,"DM_DOVIZ_CINSI",resSet.getString("DM_DOVIZ_CINSI"));
						oMap.put(tableName, i,"DM_BITIS_TARIHI",resSet.getString("DM_BITIS_TARIHI"));
						oMap.put(tableName, i,"DM_SOZLESME_NO",resSet.getString("DM_SOZLESME_NO"));
						oMap.put(tableName, i,"DM_OZEL_NOT",resSet.getString("DM_OZEL_NOT"));						
					}else if(SIGORTA_BEYAN_FORMU_HAYAT.equals(dokumanAdi) ) {
						String tableName = "SIGORTA_BEYAN_FORMU_HAYAT";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);
						oMap.put(tableName, i,"SIGORTALI_CINSIYET",	resSet.getString("SIGORTALI_CINSIYET"));
						oMap.put(tableName, i,"SIGORTALI_MEDENI_HAL",resSet.getString("SIGORTALI_MEDENI_HAL"));
						oMap.put(tableName, i,"MESLEK_ACIKLAMA", 	resSet.getString("MESLEK_ACIKLAMA"));
						oMap.put(tableName, i,"SIGORTALI_MUSTERI_NO",resSet.getString("SIGORTALI_MUSTERI_NO"));
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
					}else if(SIGORTA_BEYAN_FORMU_AILE_GUVENCE.equals(dokumanAdi) ) {
						String tableName = "SIGORTA_BEYAN_FORMU_AILE_GUVENCE";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);
						oMap.put(tableName, i,"EK_SIGORTALI_ADET",resSet.getString("EK_SIGORTALI_ADET"));
						oMap.put(tableName, i,"EK_SIGORTALI_1_TCKN",resSet.getString("EK_1_TCKN"));
						oMap.put(tableName, i,"EK_SIGORTALI_2_TCKN",resSet.getString("EK_2_TCKN"));
						oMap.put(tableName, i,"EK_SIGORTALI_3_TCKN",resSet.getString("EK_3_TCKN"));
						oMap.put(tableName, i,"EK_SIGORTALI_4_TCKN",resSet.getString("EK_4_TCKN"));
						oMap.put(tableName, i,"EK_SIGORTALI_5_TCKN",resSet.getString("EK_5_TCKN"));
						oMap.put(tableName, i,"EK_SIGORTALI_1_ADSOYAD",resSet.getString("EK_1_ADSOYAD"));
						oMap.put(tableName, i,"EK_SIGORTALI_2_ADSOYAD",resSet.getString("EK_2_ADSOYAD"));
						oMap.put(tableName, i,"EK_SIGORTALI_3_ADSOYAD",resSet.getString("EK_3_ADSOYAD"));
						oMap.put(tableName, i,"EK_SIGORTALI_4_ADSOYAD",resSet.getString("EK_4_ADSOYAD"));
						oMap.put(tableName, i,"EK_SIGORTALI_5_ADSOYAD",resSet.getString("EK_5_ADSOYAD"));
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
					}else if(SIGORTA_BEYAN_FORMU_MINI_KASKO.equals(dokumanAdi) ) {
                        String tableName = "SIGORTA_BEYAN_FORMU_KASKO";
                        getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);   
                        oMap.put(tableName, i,"DOKUMAN_ADI",        dokumanAdi);
                        oMap.put(tableName, i,"PLAKA",resSet.getString("PLAKA"));
                        oMap.put(tableName, i,"YENILEME_MI",resSet.getString("YENILEME_MI"));
                        oMap.put(tableName, i,"POLICE_NO",resSet.getString("POLICE_NO"));
                        oMap.put(tableName, i,"MARKA",resSet.getString("MARKA"));
                        oMap.put(tableName, i,"MODEL",resSet.getString("MODEL"));
                        oMap.put(tableName, i,"TIP",resSet.getString("TIP"));
                        oMap.put(tableName, i,"TUR",resSet.getString("TUR"));
                        oMap.put(tableName, i,"KULLANIM_SEKLI",resSet.getString("KULLANIM_SEKLI"));
                        oMap.put(tableName, i,"TESCIL_TARIHI",resSet.getString("TESCIL_TARIHI"));
                        oMap.put(tableName, i,"YOLCU_ADEDI",resSet.getString("YOLCU_ADEDI"));
                        oMap.put(tableName, i,"TAKSIT_SAYISI",resSet.getString("TAKSIT_SAYISI"));                         
					}else if(SIGORTA_BEYAN_FORMU_CUZDAN.equals(dokumanAdi) ||
							 SIGORTA_BEYAN_FORMU_AILEM_DESTEK.equals(dokumanAdi) ||
							 SIGORTA_BEYAN_FORMU_HASTALIK.equals(dokumanAdi) ||
							 SIGORTA_BEYAN_FORMU_ASISTANS.equals(dokumanAdi) || 
							 SIGORTA_BEYAN_FORMU_ACIL_SAGLIK.equals(dokumanAdi)) {
						String tableName = "SIGORTA_BEYAN_FORMU_ORTAK";
						getInsuranceInfoFormCommonValues(oMap, tableName, i, resSet);
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
					}else if("160".equals(dokumanAdi) || "161".equals(dokumanAdi) || "162".equals(dokumanAdi) ||
							"163".equals(dokumanAdi) || "164".equals(dokumanAdi) || "165".equals(dokumanAdi) ||
							"166".equals(dokumanAdi) ||"167".equals(dokumanAdi) || "168".equals(dokumanAdi) ||
							"169".equals(dokumanAdi) || "472".equals(dokumanAdi) || "485".equals(dokumanAdi) ||
							"597".equals(dokumanAdi)){
						String tableName = "SIGORTA_BILGI_FORMU";
						oMap.put(tableName, i,"BARKOD", resSet.getString("BARKOD"));
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
						oMap.put(tableName, i,"SIGORTA_SIRKETI_ID", resSet.getString("SIGORTA_SIRKETI_ID"));
					/* Kanun Bilgilendirme Notu */
					}else if("800".equals(dokumanAdi)){
						String tableName = "KANUN_BILGILENDIRME_NOTU";
						oMap.put(tableName, i,"BARKOD", resSet.getString("BARKOD"));
						oMap.put(tableName, i,"DOKUMAN_ADI", 		dokumanAdi);
						oMap.put(tableName, i,"SIGORTA_SIRKETI_ID", resSet.getString("SIGORTA_SIRKETI_ID"));
						oMap.put(tableName, i,"FORM_OKUNDU_MU", resSet.getBoolean("FORM_OKUNDU_MU"));
					}
					
					i++;
				}
			}
			
			GMServerDatasource.close(resSet);
			GMServerDatasource.close(stmt);
			
			call = "{call PKG_PTT_SIGORTA.SORU_LIST(?,?)}";
			stmt = conn.prepareCall(call);
			
			stmt.setBigDecimal(1, iMap.getBigDecimal("DOKUMAN_ID"));//pn_dokuman_id
			stmt.registerOutParameter(2, -10);//rec_belge_bilgi
			stmt.execute();
			
			resSet = (ResultSet)stmt.getObject(2);
			String tableName = "SIGORTA_SAGLIK_SORU_LIST";
			int row = 0;
			while(resSet.next()){
				oMap.put(tableName, row, "SORU_KOD", resSet.getString("SORU_KOD"));
				oMap.put(tableName, row, "SORU_ADI", resSet.getString("SORU_ADI"));
				oMap.put(tableName, row, "GECIRILMIS_MI", resSet.getString("GECIRILMISMI"));
				row++;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e,false);
		}
		finally {
			GMServerDatasource.close(resSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("PTT_DOKUMAN_GET_BARKOD_NUMARASI")
	public static GMMap pttDokumanGetBarkodNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap(); 
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PTT_DOKUMAN.GET_DOKUMAN_BARKOD}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.execute();
			
			oMap.put("BARKOD_NUMARASI", stmt.getString(--i));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static java.sql.Date getSqlDate(String javaDate) throws Exception{
		if (javaDate==null || "".equals(javaDate.trim())) {
			return null;
		}
		Date utilDate;
		SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
		utilDate = fmt.parse(javaDate);
		
		
		return new java.sql.Date(utilDate.getTime());
	}
	
	public static String getDateString(String sqlDate) throws Exception{
		if (sqlDate == null || sqlDate.trim().isEmpty()) {
			return null;
		}
		
		Date tarih = calendarFormat.parse(sqlDate);
		return dateFormat.format(tarih);
		
	}
	
	public static String getDateString(java.sql.Date date) throws Exception{
		if (date == null) {
			return null;
		}
		
		return dateFormat2.format(date);
	}
	
	public static void getInsuranceInfoFormCommonValues(GMMap iMap, String tableName, int row, ResultSet rSet) throws Exception{
		iMap.put(tableName, row, "BARKOD",						rSet.getString("BARKOD"));
		iMap.put(tableName, row, "SIGORTALI_TC_KIMLIK_NO",		rSet.getString("SIGORTALI_TC_KIMLIK_NO"));
		iMap.put(tableName, row, "SIGORTALI_ADI",				rSet.getString("SIGORTALI_ADI"));
		iMap.put(tableName, row, "SIGORTALI_IKINCI_ADI",		rSet.getString("SIGORTALI_IKINCI_ADI"));
		iMap.put(tableName, row, "SIGORTALI_SOYADI",			rSet.getString("SIGORTALI_SOYADI"));
		iMap.put(tableName, row, "SIGORTALI_DOGUM_TARIHI",		getDateString(rSet.getDate("SIGORTALI_DOGUM_TARIHI")));
		iMap.put(tableName, row, "SIGORTALI_CEP_TEL",			rSet.getString("SIGORTALI_CEP_TEL"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_IL",			rSet.getString("SIGORTALI_ADRES_IL"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_ILCE",		rSet.getString("SIGORTALI_ADRES_ILCE"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_BELDE",		rSet.getString("SIGORTALI_ADRES_BELDE"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_MAHALLE",		rSet.getString("SIGORTALI_ADRES_MAHALLE"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_CADDE_SOKAK",	rSet.getString("SIGORTALI_ADRES_CADDE_SOKAK"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_APT",			rSet.getString("SIGORTALI_ADRES_APT"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_BINA",		rSet.getString("SIGORTALI_ADRES_BINA"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_KAT",			rSet.getString("SIGORTALI_ADRES_KAT"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_DAIRE",		rSet.getString("SIGORTALI_ADRES_DAIRE"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_TIP",			rSet.getString("SIGORTALI_ADRES_TIP"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_POSTA_KODU",	rSet.getString("SIGORTALI_ADRES_POSTA_KODU"));
		iMap.put(tableName, row, "SIGORTALI_ADRES_FIRMA_ADI",	rSet.getString("SIGORTALI_ADRES_FIRMA_ADI"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_TC_KIMLIK_NO",rSet.getString("SIGORTA_ETT_TC_KIMLIK_NO"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADI",			rSet.getString("SIGORTA_ETT_ADI"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_IKINCI_ADI",	rSet.getString("SIGORTA_ETT_IKINCI_ADI"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_SOYADI",		rSet.getString("SIGORTA_ETT_SOYADI"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_DOGUM_TARIHI",getDateString(rSet.getDate("SIGORTA_ETT_DOGUM_TARIHI")));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_CEP_TEL",		rSet.getString("SIGORTA_ETT_CEP_TEL"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_IL",	rSet.getString("SIGORTA_ETT_ADRES_IL"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_ILCE",	rSet.getString("SIGORTA_ETT_ADRES_ILCE"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_BELDE",	rSet.getString("SIGORTA_ETT_ADRES_BELDE"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_MAHALLE",rSet.getString("SIGORTA_ETT_ADRES_MAHALLE"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_CADDE_SOKAK",rSet.getString("SIGORTA_ETT_ADRES_CADDE_SOKAK"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_APT",	rSet.getString("SIGORTA_ETT_ADRES_APT"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_BINA",	rSet.getString("SIGORTA_ETT_ADRES_BINA"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_KAT",	rSet.getString("SIGORTA_ETT_ADRES_KAT"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_DAIRE",	rSet.getString("SIGORTA_ETT_ADRES_DAIRE"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_TIP",	rSet.getString("SIGORTA_ETT_ADRES_TIP"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_POSTA_KODU",rSet.getString("SIGORTA_ETT_ADRES_POSTA_KODU"));
		iMap.put(tableName, row, "SIGORTA_ETTIREN_ADRES_FIRMA_ADI",rSet.getString("SIGORTA_ETT_ADRES_FIRMA_ADI"));
		iMap.put(tableName, row, "TAHSILAT_SEKLI",				rSet.getString("TAHSILAT_SEKLI"));
		iMap.put(tableName, row, "PRIM_TUTARI",					rSet.getString("PRIM_TUTARI"));
		iMap.put(tableName, row, "TEMINAT_TUTARI",				rSet.getString("TEMINAT_TUTARI"));
		iMap.put(tableName, row, "INDIRIMLI_PRIM_TUTARI",		rSet.getString("INDIRIMLI_PRIM_TUTARI"));
		iMap.put(tableName, row, "KREDI_KART_NO",				rSet.getString("KREDI_KART_NO"));
		iMap.put(tableName, row, "HESAP_NO",					rSet.getString("HESAP_NO"));
		iMap.put(tableName, row, "TARIH",						getDateString(rSet.getDate("TARIH")));
	}
	
}
