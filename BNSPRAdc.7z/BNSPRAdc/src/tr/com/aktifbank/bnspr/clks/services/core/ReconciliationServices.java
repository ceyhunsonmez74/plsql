package tr.com.aktifbank.bnspr.clks.services.core;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.TransactionDefinition;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.internal.TransactionDefinitionFactory;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants.Response;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatFark;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatFarkMuhasebe;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatFarkSorgu;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ReconciliationServices {

	private static Logger logger = Logger.getLogger(ReconciliationServices.class);
	
	/**
	 * TBD
	 *  
	 * @param iMap {DATE}
	 * @param iMap {RECONCILIATION_CODE}
	 * @param iMap {LIST_NAME**}
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_TRANSACTION_RECONCILIATION")
	public static GMMap transactionReconciliation(GMMap iMap) {

		GMMap oMap = new GMMap();

		String reconciliationCode = iMap.getString("RECONCILIATION_CODE");
		String listName = iMap.getString("LIST_NAME", "RECORDS");

		try {

			// TODO Handle 80, 81, 82
			if(!Arrays.asList("80","81","82").contains(reconciliationCode)) {
				TransactionDefinition td = TransactionDefinitionFactory.of(ReconciliationType.getEnum(reconciliationCode));
				oMap.putAll(td.getReconciliationRecords(iMap.getDate("DATE"), listName));
			}
			
			oMap.put("RESPONSE", Response.SUCCESS.getValue());
			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_TRANSACTION_RECONCILIATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 * 
	 * 
	 * requestParameter = "TARIH,ISLEM[ISLEM_NO,ISLEM_TIPI,DURUM,MUHASEBE[TUTAR,"
			+ "PARA_BIRIMI,MASRAF],KOMISYON[TUTAR,PARA_BIRIMI],MUSTERI_DETAY[SUBE_ID,PERSONEL_SICIL,PERSONEL_ADI],"
			+ "KREDI_BASVURU_DETAY[BASVURU_NO,TUTAR,DURUM,NITELIK,KAMPANYA[KOD,TIP]],KREDI_TAHSILAT_DETAY["
			+ "BASVURU_KANAL,KAMPANYA[KOD,TIP]],FARK_BILDIRIM[DURUM,ACIKLAMA]]", 
		responseParameter = "RESPONSE,RESPONSE_DATA")

	 */
	@GraymoundService("BNSPR_CLKS_TRANSACTION_RECONCILIATION_DIFF")
	public static GMMap transactionReconciliationDiff(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String listName = "ISLEM";
		int size = 0, eksikKayit = 0, fazlaKayit = 0, komisyonFarkliKayit = 0, basvuruDurumFarkliKayit = 0;
		
		try {
			
			size = iMap.getSize(listName);
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("mutabakatTarihi", iMap.getDate("TARIH"));
			restrictions.put("durum", "A");
			restrictions.put("grupKod", iMap.getString("GRUP"));
			
			@SuppressWarnings("unchecked")
			List<ClksMutabakatFarkSorgu> sorguList = session.createCriteria(ClksMutabakatFarkSorgu.class).add(
				Restrictions.allEq(restrictions)).list();
			
			for(ClksMutabakatFarkSorgu prevSorgu : sorguList) {
				prevSorgu.setDurum("K");
				session.update(prevSorgu);
			}
			
			ClksMutabakatFarkSorgu sorgu = new ClksMutabakatFarkSorgu(GMServiceExecuter.call(
				"BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "CLKS_MUTABAKAT_FARK_SORGU")).getBigDecimal(
				"ID"), iMap.getDate("TARIH"), BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, "A",
				iMap.getString("GRUP"));

			// TODO HQL ile silmek yerine farkli bir cozum uygulayalim, status flag ekleyelim
			session.createQuery("delete from ClksMutabakatFark where tarih = :date and grupKod = :grupKod").setDate(
				"date", iMap.getDate("TARIH")).setString("grupKod", iMap.getString("GRUP")).executeUpdate();

			for(int i = 0; i < size; i++) {
				
				BigDecimal islemNo = iMap.getBigDecimal("ISLEM", i, "ISLEM_NO");
				ClksMutabakatFark mutabakat = new ClksMutabakatFark(islemNo);
				ClksMutabakatFarkMuhasebe mutabakatMuh = new ClksMutabakatFarkMuhasebe(islemNo);
				
				mutabakat.setDurum(iMap.getString("ISLEM", i, "DURUM"));
				mutabakat.setIslemTuru(new BigDecimal(iMap.getString("ISLEM", i, "ISLEM_TIPI").replace(",", "")));
				mutabakat.setTarih(iMap.getDate("TARIH"));
				mutabakat.setGrupKod(iMap.getString("GRUP"));
				
				if(iMap.get("ISLEM", i, "KOMISYON") !=null) {
					@SuppressWarnings("unchecked")
					GMMap komisyon = new GMMap(((ArrayList<HashMap<?,?>>) iMap.get("ISLEM", i, "KOMISYON")).get(0));
					mutabakat.setKomisyonTutar(komisyon.getBigDecimal("TUTAR"));
					mutabakat.setKomisyonDovizCinsi(komisyon.getString("PARA_BIRIMI"));
				}
				
				if(iMap.get("ISLEM", i, "MUSTERI_DETAY")!=null) {
					@SuppressWarnings("unchecked")
					GMMap musteriDetay = new GMMap(((ArrayList<HashMap<?,?>>) iMap.get("ISLEM", i, "MUSTERI_DETAY")).get(0));
					mutabakat.setSubeId(musteriDetay.getBigDecimal("SUBE_ID"));
					mutabakat.setPersonelSicil(musteriDetay.getString("PERSONEL_SICIL"));
					mutabakat.setPersonelKimlik(musteriDetay.getString("PERSONEL_ADI"));
				}
				
				if(iMap.get("ISLEM", i, "KREDI_BASVURU_DETAY") !=null) {
					@SuppressWarnings("unchecked")
					GMMap krediDetay = new GMMap(((ArrayList<HashMap<?,?>>) iMap.get("ISLEM", i, "KREDI_BASVURU_DETAY")).get(0));
					mutabakat.setBasvuruNo(krediDetay.getBigDecimal("BASVURU_NO"));
					mutabakat.setBasvuruDurum(krediDetay.getString("DURUM"));
				}
				
				if(iMap.get("ISLEM", i, "FARK_BILDIRIM") != null) {
					@SuppressWarnings("unchecked")
					GMMap details = new GMMap(((ArrayList<HashMap<?, ?>>) iMap.get("ISLEM", i, "FARK_BILDIRIM"))
						.get(0));
					mutabakat.setFarkKod(details.getString("DURUM"));
					mutabakat.setFarkAciklama(details.getString("ACIKLAMA"));
					
	            	if("E".equals(details.getString("DURUM"))) {
	            		eksikKayit++;
	            	} else if("F".equals(details.getString("DURUM"))) {
	            		fazlaKayit++;
	            	} else if("K".equals(details.getString("DURUM"))) {
	            		komisyonFarkliKayit++;
	            	} else if("D".equals(details.getString("DURUM"))) {
	            		basvuruDurumFarkliKayit++;
	            	}
				}
				
				if(iMap.get("ISLEM", i, "MUHASEBE") !=null) {
					@SuppressWarnings("unchecked")
					GMMap muhasebe = new GMMap(((ArrayList<HashMap<?,?>>) iMap.get("ISLEM", i, "MUHASEBE")).get(0));
					String masraf = muhasebe.getString("MASRAF");
					if (masraf.length() == 1 & (masraf.equalsIgnoreCase("E") || masraf.equalsIgnoreCase("H"))){
					   mutabakatMuh.setMasraf(masraf);
					}else {
						mutabakatMuh.setMasraf("X");
					}
					mutabakatMuh.setTutar(muhasebe.getBigDecimal("TUTAR"));
					mutabakatMuh.setDovizCinsi(muhasebe.getString("PARA_BIRIMI"));
					session.saveOrUpdate(mutabakatMuh);
				}
				session.saveOrUpdate(mutabakat);
			}
				
			sorgu.setEksikKayit(BigDecimal.valueOf(eksikKayit));
			sorgu.setFazlaKayit(BigDecimal.valueOf(fazlaKayit));
			sorgu.setKomisyonFarkliKayit(BigDecimal.valueOf(komisyonFarkliKayit));
			sorgu.setKrediDurumFarkliKayit(BigDecimal.valueOf(basvuruDurumFarkliKayit));
			session.save(sorgu);
			session.flush();
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_TRANSACTION_RECONCILIATION_DIFF err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
