package tr.com.aktifbank.bnspr.clks.services.scheduler;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.PensionPayment;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.SgkInstitution;
import tr.com.aktifbank.bnspr.dao.ClksBbBorcTrOnboarding;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditServices {

	private static Logger logger = Logger.getLogger(CreditServices.class);
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("PTT_KBB_SERVISI_ERKEN_UYARI")
	public static GMMap pttkkbServisiErkenUyari(GMMap iMap) {

		ArrayList<String> recipientsList;
		GMMap oMap = new GMMap();

		try {

			oMap = (GMMap) DALUtil.callOracleProcedure("{ call PKG_PTT_KREDI.ptt_kkb_bilgileri_count(?,?,?,?)}",
				new Object[]{BnsprType.NUMBER, BigDecimal.ZERO},
				new Object[]{BnsprType.NUMBER, "basvuru_sayisi",
					BnsprType.NUMBER, "kmh_sayisi",
					BnsprType.NUMBER, "kullandirim_sayisi"});

			int basvuru = oMap.getInt("basvuru_sayisi");
			int kmh = oMap.getInt("kmh_sayisi");
			int kullandirim = oMap.getInt("kullandirim_sayisi");

			// her hangi bir de�er 0 ise e-mail g�nder

			if(basvuru == 0 || kmh == 0 || kullandirim == 0) {
				GMMap mailServisMap = new GMMap();
				GMMap iMapG = new GMMap();
				iMapG.put("KOD", "PTT_KBB_MAIL_FROM");
				String fromMail = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
				mailServisMap.put("FROM", fromMail);

				iMapG.put("KOD", "PTT_KBB_MAIL_TO");
				// TO : Karar Destek ve Analitik Birimi , S�re� ve Proje Y�netimi Birimi, D�� Kaynak Kurum Uygulamalar� Geli�tirme Birimi
				String toMail = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");

				recipientsList = null;
				if(toMail != null) {
					recipientsList = new ArrayList<String>();
					recipientsList.addAll(Arrays.asList(toMail.split(";")));
				}

				mailServisMap.put("RECIPIENTS_TO", recipientsList);
				mailServisMap.put("SUBJECT", "PTT i�i KKB Servisi Erken Uyar� Bilgilendirme Maili");

				String messageBody = "Basvuru say�s� : " + basvuru + "\n" + "KMH say�s� : " + kmh + "\n" + "Kulland�r�m say�s� : " + kullandirim;

				mailServisMap.put("MESSAGE_BODY", messageBody);
				mailServisMap.put("IS_BODY_HTML", "H");

				GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailServisMap);
			}
			
			return oMap;
		}

		catch(Exception e) {
			logger.error("PTT_KBB_SERVISI_ERKEN_UYARI err: " + e);
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("SGK_BLOKE_DURUM")
	public static GMMap sgkBlokeDurum(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			oMap = (GMMap) DALUtil.callOracleProcedure("{ call PKG_PTT_KREDI.sgk_bloke_durum_kaydet(?,?)}", 
				new Object[]{BnsprType.NUMBER, BigDecimal.ZERO},
				new Object[]{BnsprType.NUMBER, "a"});
		}
		catch(Exception e) {
			logger.error("SGK_BLOKE_DURUM err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_SGK_ONLINE_SORGU_HATA_DURUMU_MAIL_GONDERIMI")
    public static GMMap bnsprsgkOnlineSorguHataDurumuMailGonderimi(GMMap iMap) {

        GMMap oMap = new GMMap();

        ArrayList<String> recipientsList;
        String messageBody = "BASVURU NO" + "    " + "HATA KODU"  + "    " + "HATA A�IKLAMASI";

        String procStr = "{ call PKG_PTT_JOB.SGK_Online_Sorgu_Hata_Durumu(?)}";
        int i = 0;
        Object[] inputValues = new Object[0];
        Object[] outputValues = new Object[2];

        try {

            i = 0;

            outputValues[i++] = BnsprType.REFCURSOR;
            outputValues[i++] = "PTT_ISLEM_LIST";

            GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
            oMap.putAll(resultMap);

            String tableName = "PTT_ISLEM_LIST";

            GMMap mailServisMap = new GMMap();
            GMMap iMapG = new GMMap();
            iMapG.put("KOD", "PTT_KBB_MAIL_FROM");
            String fromMail = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
            mailServisMap.put("FROM", fromMail);

            iMapG.put("KOD", "PTT_SGK_ONLINE_HATA_MAIL"); // diskaynakkurumuygulamalarigelistirme.birimi@aktifbank.com.tr
            // TO : Karar Destek ve Analitik Birimi, D�� Kaynak Kurum Uygulamalar� Geli�tirme Birimi
            String toMail = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");

            recipientsList = null;
            if (toMail != null) {
                recipientsList = new ArrayList<String>();
                recipientsList.addAll(Arrays.asList(toMail.split(";")));
            }

            mailServisMap.put("RECIPIENTS_TO", recipientsList);
            mailServisMap.put("SUBJECT", "SAATLIK SGK BLOKE KONTROL");
            
            if (oMap.get(tableName) != null) {
                for (int k = 0; k < oMap.getSize(tableName); k++) {
                	if (!messageBody.contains(oMap.getString(tableName, k, "BASVURU_NO"))) {
                		messageBody = messageBody + "\n" + oMap.getString(tableName, k, "BASVURU_NO") + "           " + oMap.getString(tableName, k, "ERROR_CODE") + "       "  + oMap.getString(tableName, k, "ERROR_DESCRIPTION_2").replace('\n', ' ');
                	}
                }
                
                mailServisMap.put("MESSAGE_BODY", messageBody);
                mailServisMap.put("IS_BODY_HTML", "H");

                GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailServisMap);
            }

        }
        catch (Exception e) {
            logger.error("BNSPR_SGK_ONLINE_SORGU_HATA_DURUMU_MAIL_GONDERIMI err: " + e);
            throw ExceptionHandler.convertException(e);
        }
        return oMap;

    }
}
