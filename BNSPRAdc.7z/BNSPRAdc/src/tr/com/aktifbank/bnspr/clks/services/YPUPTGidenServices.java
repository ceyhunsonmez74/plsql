package tr.com.aktifbank.bnspr.clks.services;

import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.clks.util.BnsprAdcMessageExecuter;
import tr.com.aktifbank.bnspr.clks.util.BnsprAdcUtil;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.YpHavaleGidenTalimatTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.obss.adc.core.util.ADCParameters;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class YPUPTGidenServices {
	private static Logger logger = Logger.getLogger(YPUPTGidenServices.class);
	/*
	 *********************************
	 * INPUT iMap
	 *********************************
		 * ISLEM_NO
		 * ALICI_ULKE_KODU
		 * ODEME_TURU
		 * HAVALE_TIPI
		 * DOVIZ_CINSI
		 * TUTAR
		 * ODEME_DOVIZ_CINSI
		 * ODEME_DOVIZ_TUTAR
		 * ODEME_TL_TUTAR
		 * UPT_TAHSILAT_SEKLI
		 * PTT_EUR_KUR
		 * PTT_USD_KUR
		 * PTT_EUR_USD_PARITE
		 * ISLEMIN_YAPILDIGI_MERKEZ
		 * ISLEMIN_YAPILDIGI_SUBE
		 * MERKEZ_SUBE_BASMUDURLUK
		 * ISLEMIN_YAPILDIGI_BASMUDURLUK
		 * ISLEMIN_YAPILDIGI_IL
		 * ISLEMIN_YAPILDIGI_YER
		 * KULLANICI_SICIL
		 * 
		 * 
	 *********************************
	 * OUTPUT oMap
	 *********************************
		 * 	RESPONSE
		 * 	RESPONSE_DATA
		 * 	ISLEM_NO
		 *  MASRAF_DOVIZ_CINSI
		 *  MASRAF_DOVIZ_TUTAR
		 *  EUR_KUR
		 *  USD_KUR
		 *  EUR_USD_PARITE
		 *  MUHABIR_MASRAF_TUTARI
		 *  OPERASYONEL_MASRAF_TUTARI
		 *  GUVENLIK_SORUSU_CIKSIN_MI
		 *  GUVENLIK_SORUSU_LIST
	 * 
	 * */
	@GraymoundService("CLKS_YPUPT_FCTRANSFER_FIRST_INITIAL_REQUEST")
	public static GMMap ypUptFctransferFirstInitialRequest(GMMap iMap) {
		logger.info("CLKS_YPUPT_FCTRANSFER_FIRST_INITIAL_REQUEST in:" + iMap.toString());
	      
		GMMap oMap = new GMMap();
	    GMMap tMap = new GMMap();
	    
	    try{

	    	/*ISLEM_NO bos ise ilk defa cagiriyor.*/
			if (iMap.getBigDecimal("ISLEM_NO") == null || 
				iMap.getBigDecimal("ISLEM_NO") != null && iMap.getString("ISLEM_NO").compareTo("") == 0) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				iMap.put("ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
			} else {
				iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
			}
			            
	        iMap.put("SAVE", "0"); //CLKS_YPUPT_SAVE_OR_UPDATE servisinde kullaniliyor
            
	        tMap.put("ALICI_ULKE_KODU", iMap.getString("ALICI_ULKE_KODU"));
	        tMap.put("HAVALE_TIPI", iMap.getString("HAVALE_TIPI"));
	        tMap.put("DOVIZ_CINSI", iMap.getString("DOVIZ_CINSI"));
	        
	        //in=>ALICI_ULKE_KODU, HAVALE_TIPI, ALICI_BANKA_KODU, DOVIZ_CINSI, ISLEM_NO
	        String tuIslemMi = GMServiceExecuter.call("CLKS_GET_TU_INFO", tMap).getString("TU_ISLEMMI");
	        //out=>  TU_ISLEMMI
	        iMap.put("TU_ISLEMMI", tuIslemMi);
	        tMap.clear();
	        
			if ("E".equals(tuIslemMi)) {
				
				tMap.put("SEND_AMOUNT", iMap.getBigDecimal("TUTAR"));
				tMap.put("SENDER_COUNTRY_CODE", "TR");
				tMap.put("RECIPIENT_COUNTRY_CODE",iMap.getString  ("ALICI_ULKE_KODU"));
				//input: ALICI_ULKE_KODU,HAVALE_TIPI
				tMap.put("ALICI_ULKE_KODU", iMap.getString("ALICI_ULKE_KODU"));
				tMap.put("HAVALE_TIPI", iMap.getString("HAVALE_TIPI"));
				tMap.putAll(getTransactionTypeCode(tMap));
				//output: TARGET_TRANSACTION_TYPE_CODE
				tMap.put("TARGET_TRANSACTION_TYPE_CODE", tMap.getString("TARGET_TRANSACTION_TYPE_CODE"));
				tMap.put("SEND_AMOUNT_CURRENCY", iMap.getString("DOVIZ_CINSI"));
				tMap.put("DIRECTION", "1"); 
				  
				//in-> SEND_AMOUNT,SENDER_COUNTRY_CODE,RECIPIENT_COUNTRY_CODE,TARGET_TRANSACTION_TYPE_CODE,SEND_AMOUNT_CURRENCY,DIRECTION
				tMap.putAll(GMServiceExecuter.call("BNSPR_TU_GET_EXPENSE_DATA", tMap) ) ;
				//out-> OUT_EXPENSE_AMOUNT, OUT_EXPENSE_CURRENCY, OUT_EXPENSE_PARAMETER_ID    
				  
				iMap.put("masrafTahsilDoviz", tMap.getString("OUT_EXPENSE_CURRENCY"));
				iMap.put("masrafTutari", tMap.getString("OUT_EXPENSE_AMOUNT"));
				iMap.put("masrafId", tMap.getString("OUT_EXPENSE_PARAMETER_ID"));
				tMap.clear();
				
				tMap = GMServiceExecuter.call("CLKS_GET_YPUPT_ANLASMALI_BANKALAR", iMap);
				for(int i=0; i<tMap.getSize("BANKA_LIST"); i++) {
					
					if(iMap.getString("DOVIZ_CINSI").equals(tMap.getString("BANKA_LIST", i, "DOVIZ"))) {
						
						// Case: Limit Kontrol - Limit tanimli degilse limit yok kabul et
						if(iMap.getBigDecimal("TUTAR").compareTo((tMap.getBigDecimal("BANKA_LIST", i, "LIMIT") != null) ? tMap.getBigDecimal("BANKA_LIST", i, "LIMIT") : BigDecimal.valueOf(Integer.MAX_VALUE)) == 1) {
							iMap.put("HATA_NO", new BigDecimal(2685));
							iMap.put("P1", iMap.getString("ALICI_ULKE_KODU"));
							iMap.put("P2", (tMap.getBigDecimal("BANKA_LIST", i, "LIMIT") != null) ? tMap.getBigDecimal("BANKA_LIST", i, "LIMIT") : "");
							return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
						}
						
						// Case: Acenta Maliyet Orani tanimlanmadiysa 0 kabul et
						if(tMap.getBigDecimal("BANKA_LIST", i, "ACENTA_MALIYET_ORAN") == null) {
							tMap.put("BANKA_LIST", i, "ACENTA_MALIYET_ORAN", 0);
						}
						
						// Case: Pazarlama Maliyet Orani tanimlanmadiysa 0 kabul et
						if(tMap.getBigDecimal("BANKA_LIST", i, "PAZARLAMA_MALIYET_ORAN") == null) {
							tMap.put("BANKA_LIST", i, "PAZARLAMA_MALIYET_ORAN", 0);
						}
						
						// Assignment: TU Servisinden donen iki orani topladiktan sonra masrafa gore oranini alip muhabir_masraf_tutari olarak sakla
						iMap.put("MUHABIR_MASRAF_TUTARI", iMap.getBigDecimal("masrafTutari").multiply((tMap.getBigDecimal("BANKA_LIST", i, "ACENTA_MALIYET_ORAN").add(tMap.getBigDecimal("BANKA_LIST", i, "PAZARLAMA_MALIYET_ORAN")))).divide(new BigDecimal(100)));
					}
				}
				tMap.clear();
			}
			
			
	        ClksYPUPTSave(iMap);
	        oMap.putAll(ClksYPUPTFirstInitialRequest(iMap));  
	        
	        if ("E".equals(tuIslemMi)) {
			    oMap.put("MASRAF_DOVIZ_CINSI", iMap.getString("masrafTahsilDoviz"));
			    oMap.put("MASRAF_DOVIZ_TUTAR", iMap.getString("masrafTutari"));
	            tMap.put("RECIPIENT_COUNTRY_CODE", iMap.getString("ALICI_ULKE_KODU"));
	            // input:RECIPIENT_COUNTRY_CODE
	            GMMap tuQuMap = GMServiceExecuter.call("BNSPR_TU_GET_TEST_QUESTIONS", tMap);
	            // output: buradan liste d�n�yor. {TEST_QUESTION_CODE,TEST_QUESTION_DESC}.
	            // GUVENLIK_SORU_LIST, IS_USED_SECURITY_QUESTION, IS_OFFICE_EXISTS
	          
	            if  ("E".equals(tuQuMap.getString("IS_USED_SECURITY_QUESTION"))) {
	            	
	            	oMap.put("GUVENLIK_SORUSU_CIKSIN_MI", "E");
	            	for (int i = 0; i < tuQuMap.getSize("QUESTIONS_LIST"); i++) {
	            		oMap.put("GUVENLIK_SORU_LIST", i,"TEST_QUESTION_CODE",tuQuMap.getString("QUESTIONS_LIST", i, "TEST_QUESTION_CODE"));
	            		oMap.put("GUVENLIK_SORU_LIST", i,"TEST_QUESTION_DESC",tuQuMap.getString("QUESTIONS_LIST", i, "TEST_QUESTION_DESC"));
	            	} 
	            }
	            else {
	            	oMap.put("GUVENLIK_SORUSU_CIKSIN_MI", "H");
		        	oMap.put("GUVENLIK_SORU_LIST", ""); //listeyi bos gonderiyoruz
	            }
	        }
	        else
	        {
	        	oMap.put("GUVENLIK_SORUSU_CIKSIN_MI", "H");
	        	oMap.put("GUVENLIK_SORU_LIST", ""); //listeyi bos gonderiyoruz
	        }
	        
	        oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));
	        oMap.put("ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
	        
	    } catch (Exception e) {
	    	logger.error("CLKS_YPUPT_FCTRANSFER_FIRST_INITIAL_REQUEST err:",e);
	    	throw ExceptionHandler.convertException(e);
	    }    
	    
	    logger.info("CLKS_YPUPT_FCTRANSFER_FIRST_INITIAL_REQUEST out:" + oMap.toString());    
	    return oMap;
	}

	/*
	 *********************************
	 * INPUT iMap
	 *********************************
	 *
		 * ISLEM_NO
		 * GONDEREN_ADI
		 * GONDEREN_TELEFON
		 * GONDEREN_TELEFON_ULKE_KODU
		 * GONDEREN_HESAP_NO
		 * GONDEREN_BABA_ADI
		 * GONDEREN_DOGUM_YERI
		 * GONDEREN_DOGUM_TARIHI
		 * GONDEREN_ADRES
		 * GONDEREN_UYRUK
		 * GONDEREN_KIMLIK_TURU
		 * GONDEREN_KIMLIK_NO
		 * GONDEREN_TCKN
		 * GONDEREN_VERGI_NO_YKN
		 * GONDEREN_KIMLIK_VERILDIGI_ULKE
		 * GONDEREN_KIMLIK_GECERLILIK_TARIHI
		 * GONDEREN_KIMLIK_VERILIS_TARIHI
		 * GONDEREN_SEHIR
		 * SMS_SIFRE
		 * KPS_YAPILDI_MI
		 * ALICI_AD_SOYAD
		 * ALICI_ACIKLAMA
		 * ALICI_TELEFON
		 * ALICI_TELEFON_ULKE_KODU
		 * ALICI_ULKE_KODU
		 * ALICI_HESAP_NO
		 * ALICI_KART_NO
		 * ALICI_IBAN
		 * IBAN_BILINIYOR_MU
		 * ALICI_BANKA_BIC_KODU
		 * ALICI_BANKA_ULKE_KODU
		 * ALICI_BANKA_ADI
		 * ALICI_BANKA_SEHIR_ADI
		 * ALICI_BANKA_SUBE_ADI
		 * ALICI_BANKA_KODU
		 * ALICI_BANKA_SUBE_KODU
		 * ALICI_BANKA_SEHIR_KODU
		 * ALICI_BANKA_BIC_KODU_2
		 * ALICI_BANKA_ADI_2
		 * ALICI_BANKA_SEHIR_ADI_2
		 * ALICI_BANKA_SUBE_ADI_2
		 * 
	 *********************************
	 * OUTPUT oMap
	 *********************************
		 * 	RESPONSE
		 * 	RESPONSE_DATA
	 * 
	 * */
	@GraymoundService("CLKS_YPUPT_FCTRANSFER_INITIAL_REQUEST")
	public static GMMap ypUptFctransferInitialRequest(GMMap iMap) {
		logger.info("CLKS_YPUPT_FCTRANSFER_INITIAL_REQUEST in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();
		iMap.put("SAVE", "1");//CLKS_YPUPT_SAVE_OR_UPDATE servisinde kullaniliyor
		
		try {
			
			if ("TR".equals(iMap.getString("GONDEREN_UYRUK")) ||
				"TC".equals(iMap.getString("GONDEREN_UYRUK"))) {
				iMap.put("USER_OID", iMap.getString("GONDEREN_TCKN"));
			}
			else {
				iMap.put("USER_OID", iMap.getString("GONDEREN_VERGI_NO_YKN"));
			}
			
			if((iMap.get("GONDEREN_DOGUM_TARIHI") != null
					&& !"null".equals(iMap.getString("GONDEREN_DOGUM_TARIHI"))
					&& iMap.getString("GONDEREN_DOGUM_TARIHI").length() != 0) &&
			    !iMap.getString("GONDEREN_DOGUM_TARIHI").equals(new Date(iMap.getDate("GONDEREN_DOGUM_TARIHI").getTime()).toString().replace("-", ""))) {
					iMap.put("HATA_NO", new BigDecimal(1909));
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	        }
			
			GMMap i1Map = new GMMap().put("USER_OID", iMap.getString("USER_OID")).put("OTP_PASS", iMap.getString("SMS_SIFRE"));
			
			//BU iki if blogu kaldirilmali
			int gecici_sayac=0;

			if (iMap.getString("SMS_SIFRE").equals("1234") ==true){
			gecici_sayac=gecici_sayac +1;
			}
			if (iMap.getString("SMS_SIFRE").equals("7110eda4d09e062aa5e4a390b0a572ac0d2c0220") ==true){
			gecici_sayac=gecici_sayac +1;
			}
	
			if (gecici_sayac==0 ){	
			  if ( iMap.getString("GONDEREN_HESAP_NO") != null && iMap.getString("GONDEREN_HESAP_NO").length() != 0  &&
				   ADCParameters.getInt("CLKS_OTP_CONTROL") == 1){
					GMServiceExecuter.call("ADC_MAN_USER_OTP_VALIDATE", i1Map); 
				  }
			}
			
			iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
			//input: ISLEM_NO
			tMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
	        String tuIslemMi = GMServiceExecuter.call("CLKS_GET_TU_INFO", tMap).getString("TU_ISLEMMI");
	        //out=>  TU_ISLEMMI
	        iMap.put("TU_ISLEMMI", tuIslemMi);
	        
			//oMap.putAll(ClksYPUPTSave(iMap));
			ClksYPUPTSave(iMap);
	        //oMap.putAll(ClksYPUPTInitialRequest(iMap));
			ClksYPUPTInitialRequest(iMap);
			
		} catch (Exception e) {
			logger.error("CLKS_YPUPT_FCTRANSFER_INITIAL_REQUEST err:",e);
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));
		logger.info("CLKS_YPUPT_FCTRANSFER_INITIAL_REQUEST out:" + oMap.toString()); 
		return oMap;
	}

	/*
	 *********************************
	 * INPUT iMap
	 *********************************
		 * ISLEM_NO
		 * GUVENLIK_SORU_ID
		 * GUVENLIK_CEVAP
	 *********************************
	 * OUTPUT oMap
	 *********************************
		 * 	RESPONSE
		 * 	RESPONSE_DATA
		 *  REFERANS
		 *  VALOR_TARIHI
		 *  CUT_OFF_SAATI
		 *  OFAC_KONTROL
		 *  GONDEREN_IBAN
		 *  ALINACAK_TUTAR_YP
		 *  ALINACAK_TUTAR_TL
		 *  ALICI_BANKA_ADI
	 * */
	@GraymoundService("CLKS_YPUPT_FCTRANSFER_REQUEST")
	public static GMMap ypUptFctransferRequest(GMMap iMap) {
		logger.info("CLKS_YPUPT_FCTRANSFER_REQUEST in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();
		iMap.put("SAVE", "2");//CLKS_YPUPT_SAVE_OR_UPDATE servisinde kullaniliyor

		/*
		oMap.put("RESPONSE", "2");
		oMap.put("RESPONSE_DATA", "");
		oMap.put("REFERANS", "444.GIH.11.000001");
		oMap.put("VALOR_TARIHI", "20111005");
		oMap.put("CUT_OFF_SAATI", "16:30");
		oMap.put("OFAC_KONTROL", "");
		oMap.put("GONDEREN_IBAN", "1234567890");
		oMap.put("ALINACAK_TUTAR_YP", "1000");
		oMap.put("ALINACAK_TUTAR_TL", "15");
		oMap.put("MASRAF_DOVIZ_CINSI", "TRY");
		oMap.put("MASRAF_DOVIZ_TUTAR", "10");
		oMap.put("MUHABIR_MASRAF_TUTARI", "20");
		*/
		try{
	        //input: ISLEM_NO
	        tMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
	        tMap.putAll(getTuIslemmi(tMap));
		    //output: TU_ISLEMMI
	        
	        if ("E".equals(tMap.getString("TU_ISLEMMI"))) { 
	        	
	        	tMap.clear();
	        	tMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO")); 
	        	tMap.putAll(getTuIslemInfo(tMap));	
	        	tMap.put("TEST_SORU_ID", iMap.getString("GUVENLIK_SORU_ID"));
	        	tMap.put("TEST_SORU_CEVAP", iMap.getString("GUVENLIK_CEVAP"));
		        //in-> iMap4
		        iMap.putAll(GMServiceExecuter.call("BNSPR_TU_SEND_REQUEST", tMap) ) ;
		        //out-> TU_REFERANS
	        }
	        iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
	        ClksYPUPTSave(iMap);
	        oMap.putAll(ClksYPUPTRequest(iMap));
		
		} catch (Exception e) {
		  logger.error("CLKS_YPUPT_FCTRANSFER_REQUEST err:",e);
		  throw ExceptionHandler.convertException(e);
		}    
		oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));
		logger.info("CLKS_YPUPT_FCTRANSFER_REQUEST out:" + oMap.toString());    
		return oMap;	
	}
	
	/*
	 *********************************
	 * INPUT iMap
	 *********************************
		 * ISLEM_NO
		 * ISLEM_NO_PTT
	 *********************************
	 * OUTPUT oMap
	 *********************************
		 * 	RESPONSE
		 * 	RESPONSE_DATA
	
	 * 
	 * */
	@GraymoundService("CLKS_YPUPT_FCTRANSFER_CONFIRM")
	public static GMMap ypUptFctransferConfirm(GMMap iMap) {
		logger.info("CLKS_YPUPT_FCTRANSFER_CONFIRM in:" + iMap.toString());		
		GMMap iMap2 = new GMMap();
		GMMap iMap3 = new GMMap();
		GMMap iMap4 = new GMMap();
		GMMap oMap = new GMMap();
		iMap.put("SAVE", "3");//CLKS_YPUPT_SAVE_OR_UPDATE servisinde kullaniliyor
		try{
			iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
  
		    /***********************************************************/
	        /* TU dan gelen hata bizi etkilemeyecek. biz islemleri tamamlayacagiz.
	         * */
	        try {
				//input: ISLEM_NO
				iMap2.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
				iMap2.putAll(getTuIslemmi(iMap2));
				//output: TU_ISLEMMI
				
				if ("E".equals(iMap2.getString("TU_ISLEMMI"))) { 
				  
					iMap3.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO")); 
					iMap4.putAll(getTuIslemInfo(iMap3));	
					
					iMap4.put("BANKA_ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
				    oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CONFIRM_SEND_REQUEST", iMap4));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
	        	iMap.put("CORRESPONDENT_REF", oMap.getString("CORRESPONDENT_REF"));
		         YPUPTLogAt(iMap);
				 ClksYPUPTSave(iMap);
	            
	          }   
			/***********************************************************/
	        oMap.putAll(ClksYPUptTxAktar(iMap));
		
		} catch (Exception e) {
			  logger.error("CLKS_YPUPT_FCTRANSFER_CONFIRM err:",e);
			  throw ExceptionHandler.convertException(e);
		}    
		
		oMap.put("RESPONSE", "2");
		oMap.put("RESPONSE_DATA", "");
		
		logger.info("CLKS_YPUPT_FCTRANSFER_CONFIRM out:" + oMap.toString());    
	    return oMap;
	}

    @GraymoundService("CLKS_GET_TU_INFO")
    public static GMMap getTuIslemmi(GMMap iMap){
      Connection conn = null;
      CallableStatement stmt = null;
      GMMap oMap = new GMMap();
      try{
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{ ? = call  PKG_YPUPT.TU_Islemimi(?,?,?,?,?)}");
        int i = 1;
        stmt.registerOutParameter(i++, Types.VARCHAR);
        stmt.setString(i++, iMap.getString("ALICI_ULKE_KODU"));
        stmt.setString(i++, iMap.getString("HAVALE_TIPI"));
        stmt.setString(i++, iMap.containsKey("ALICI_BANKA_KODU") ? iMap.getString("ALICI_BANKA_KODU") : null);
        stmt.setString(i++, iMap.getString("DOVIZ_CINSI"));
        stmt.setString(i++, iMap.getString("ISLEM_NO"));
        
        stmt.execute();
        oMap.put("TU_ISLEMMI", stmt.getString(1));
        return oMap;
      } catch (SQLException e) {
        throw ExceptionHandler.convertException(e);
      } finally {
        GMServerDatasource.close(stmt);
        GMServerDatasource.close(conn);
        
      }

    }

    @GraymoundService("CLKS_YPUPT_FIRST_INITIAL_REQUEST")
    public static GMMap ClksYPUPTFirstInitialRequest(GMMap iMap) {
      GMMap oMap = new GMMap();
      Connection conn = null;
      CallableStatement stmt = null;
      ResultSet rSetMSet = null;
      try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{ call PKG_YPUPT.PTT_First_Initial_Request(?,?,?,?,?,?,?,?)}");

        stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
        stmt.registerOutParameter(2, Types.NUMERIC);
        stmt.registerOutParameter(3, Types.NUMERIC);
        stmt.registerOutParameter(4, Types.NUMERIC);
        stmt.registerOutParameter(5, Types.VARCHAR);
        stmt.registerOutParameter(6, Types.NUMERIC);
        stmt.registerOutParameter(7, Types.NUMERIC);
        stmt.registerOutParameter(8, Types.NUMERIC);
        stmt.execute();

        oMap.put("USD_KUR", stmt.getBigDecimal(2));
        oMap.put("EUR_KUR", stmt.getBigDecimal(3));
        oMap.put("EUR_USD_PARITE", stmt.getBigDecimal(4));
        oMap.put("MASRAF_DOVIZ_CINSI", stmt.getString(5));
        oMap.put("MASRAF_DOVIZ_TUTAR", stmt.getBigDecimal(6));
        oMap.put("MUHABIR_MASRAF_TUTARI", stmt.getBigDecimal(7));
        oMap.put("OPERASYONEL_MASRAF_TUTARI", stmt.getBigDecimal(8));
        
        return oMap;

      } catch (SQLException e) {
        throw ExceptionHandler.convertException(e);
      } finally {
        GMServerDatasource.close(rSetMSet);
        GMServerDatasource.close(stmt);
        GMServerDatasource.close(conn);
      }
    }
 
    @GraymoundService("CLKS_YPUPT_INITIAL_REQUEST")
    public static GMMap ClksYPUPTInitialRequest(GMMap iMap) {
      GMMap oMap = new GMMap();
      Connection conn = null;
      CallableStatement stmt = null;
      ResultSet rSetMSet = null;
      try {
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{ call PKG_YPUPT.PTT_Initial_Request(?)}");

        stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
        stmt.execute();

        return oMap;

      } catch (SQLException e) {
        throw ExceptionHandler.convertException(e);
      } finally {
        GMServerDatasource.close(rSetMSet);
        GMServerDatasource.close(stmt);
        GMServerDatasource.close(conn);
      }
    }
 
    @GraymoundService("CLKS_YPUPT_REQUEST")
    public static GMMap ClksYPUPTRequest(GMMap iMap) {
      GMMap oMap = new GMMap();
      Connection conn = null;
      CallableStatement stmt = null;
      ResultSet rSetMSet = null;
      try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_YPUPT.PTT_Request(?,?,?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.DATE);
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.NUMERIC);
			stmt.registerOutParameter(9, Types.NUMERIC);
                    
			stmt.execute();

			oMap.put("REFERANS", stmt.getString(2));
			oMap.put("VALOR_TARIHI", stmt.getDate(3));
			oMap.put("CUT_OFF_SAATI", stmt.getString(4));
			oMap.put("OFAC_KONTROL", stmt.getString(5));
			oMap.put("ALICI_BANKA_ADI", stmt.getString(6));
			oMap.put("GONDEREN_IBAN", stmt.getString(7));
			oMap.put("ALINACAK_TUTAR_YP", stmt.getBigDecimal(8));
			oMap.put("ALINACAK_TUTAR_TL", stmt.getBigDecimal(9));            
			 		  
			iMap.put("TRX_NAME", "2850");
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			return oMap;

      } catch (SQLException e) {
        throw ExceptionHandler.convertException(e);
      } finally {
        GMServerDatasource.close(rSetMSet);
        GMServerDatasource.close(stmt);
        GMServerDatasource.close(conn);
      }
    }
    
    @GraymoundService("CLKS_YPUPT_SAVE_OR_UPDATE")
    public static Map<?, ?> ClksYPUPTSave(GMMap iMap) {
    	try {
    		Session session = DAOSession.getSession("BNSPRDal");

    		YpHavaleGidenTalimatTx ypHavaleGidenTalimatTx = (YpHavaleGidenTalimatTx) session.get(YpHavaleGidenTalimatTx.class, iMap.getBigDecimal("TRX_NO"));

    		if (ypHavaleGidenTalimatTx == null) {
    			ypHavaleGidenTalimatTx = new YpHavaleGidenTalimatTx();
    		}
    		ypHavaleGidenTalimatTx.setTxNo(iMap.getBigDecimal("TRX_NO"));

    		if (iMap.getString("SAVE").compareTo("0") == 0) {

				ypHavaleGidenTalimatTx.setAliciUlkeKodu(iMap.getString("ALICI_ULKE_KODU"));
				ypHavaleGidenTalimatTx.setOdemeTuru(iMap.getString("ODEME_TURU"));
				ypHavaleGidenTalimatTx.setHavaleTipi(iMap.getString("HAVALE_TIPI"));
				ypHavaleGidenTalimatTx.setDovizCinsi(iMap.getString("DOVIZ_CINSI"));
				ypHavaleGidenTalimatTx.setTutar(iMap.getBigDecimal("TUTAR"));
				ypHavaleGidenTalimatTx.setOdemeDovizCinsi(iMap.getString("ODEME_DOVIZ_CINSI"));
				ypHavaleGidenTalimatTx.setMasrafTahsilDoviz(iMap.getString("masrafTahsilDoviz"));
				ypHavaleGidenTalimatTx.setMasrafTutari(iMap.getBigDecimal("masrafTutari"));
				ypHavaleGidenTalimatTx.setTuMasrafId(iMap.getString("masrafId"));
				ypHavaleGidenTalimatTx.setMuhabirBankaMasrafTutari(iMap.getBigDecimal("MUHABIR_MASRAF_TUTARI"));
				ypHavaleGidenTalimatTx.setUptTahsilatSekli(iMap.getString("UPT_TAHSILAT_SEKLI"));
				ypHavaleGidenTalimatTx.setPttUsdkur(iMap.getBigDecimal("PTT_USD_KUR"));
				ypHavaleGidenTalimatTx.setPttEurkur(iMap.getBigDecimal("PTT_EUR_KUR"));
				ypHavaleGidenTalimatTx.setPttParite(iMap.getBigDecimal("PTT_EUR_USD_PARITE"));
				ypHavaleGidenTalimatTx.setOdemeTutari(iMap.getBigDecimal("ODEME_DOVIZ_TUTAR"));
				ypHavaleGidenTalimatTx.setOdemeTutariTl(iMap.getBigDecimal("ODEME_TL_TUTAR"));
				ypHavaleGidenTalimatTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
				ypHavaleGidenTalimatTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
				ypHavaleGidenTalimatTx.setMerkezSubeBasmudurluk(iMap.getString("MERKEZ_SUBE_BASMUDURLUK"));
				ypHavaleGidenTalimatTx.setIsleminYapildigiBasmudurluk(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				ypHavaleGidenTalimatTx.setIsleminYapildigiYer(iMap.getString("ISLEMIN_YAPILDIGI_YER"));
				ypHavaleGidenTalimatTx.setIslemiYapanKullanici(iMap.getString("KULLANICI_SICIL"));
				ypHavaleGidenTalimatTx.setIslemiYapanKullAdsoyad(iMap.getString("ISLEMI_YAPAN_KULLANICI_ADSOYAD"));
				String cityName = iMap.getString("ISLEMIN_YAPILDIGI_IL");
				if (cityName != null && cityName.trim().length() >= 10) {
					cityName = cityName.substring(0, 10); //PTT den il kodu yerine il adi geliyor. Orn: Istanbul/Avrupa
				}
				ypHavaleGidenTalimatTx.setIsleminYapildigiIl(cityName);
				ypHavaleGidenTalimatTx.setFTuOdenecek(iMap.getString("TU_ISLEMMI"));
			}
    		
    		else if (iMap.getString("SAVE").compareTo("1") == 0) {

				ypHavaleGidenTalimatTx.setGonderenUyruk(iMap.getString("GONDEREN_UYRUK"));
				ypHavaleGidenTalimatTx.setGonderenKimlikTuru(iMap.getString("GONDEREN_KIMLIK_TURU"));
				ypHavaleGidenTalimatTx.setGonderenKimlikNo(iMap.getString("GONDEREN_KIMLIK_NO"));
				ypHavaleGidenTalimatTx.setTcKimlikNo(iMap.getString("GONDEREN_TCKN"));
				ypHavaleGidenTalimatTx.setVergiNo(iMap.getString("GONDEREN_VERGI_NO_YKN"));
				ypHavaleGidenTalimatTx.setGonderenAdi(iMap.getString("GONDEREN_ADI"));
				ypHavaleGidenTalimatTx.setGonderenTelefon(iMap.getString("GONDEREN_TELEFON"));
				ypHavaleGidenTalimatTx.setGonderenTelefonUlkeKodu(iMap.getString("GONDEREN_TELEFON_ULKE_KODU"));
				ypHavaleGidenTalimatTx.setGonderenHesapNo(iMap.getBigDecimal("GONDEREN_HESAP_NO"));
				ypHavaleGidenTalimatTx.setGonderenBabaAdi(iMap.getString("GONDEREN_BABA_ADI"));
				ypHavaleGidenTalimatTx.setGonderenDogumYeri(iMap.getString("GONDEREN_DOGUM_YERI"));
				ypHavaleGidenTalimatTx.setGonderenDogumTar((iMap.get("GONDEREN_DOGUM_TARIHI") != null
						&& !"null".equals(iMap.getString("GONDEREN_DOGUM_TARIHI"))
						&& iMap.getString("GONDEREN_DOGUM_TARIHI").length() != 0) ? iMap.getDate("GONDEREN_DOGUM_TARIHI") : null);
				ypHavaleGidenTalimatTx.setGonKimlikVerUlke(iMap.getString("GONDEREN_KIMLIK_VERILDIGI_ULKE"));
				ypHavaleGidenTalimatTx.setGonKimlikGecTarihi((iMap.get("GONDEREN_KIMLIK_GECERLILIK_TARIHI") != null
						&& !"null".equals(iMap.getString("GONDEREN_KIMLIK_GECERLILIK_TARIHI"))
						&& iMap.getString("GONDEREN_KIMLIK_GECERLILIK_TARIHI").length() != 0) ? iMap.getDate("GONDEREN_KIMLIK_GECERLILIK_TARIHI") : null);
				ypHavaleGidenTalimatTx.setGonderenAdres(iMap.getString("GONDEREN_ADRES"));
				ypHavaleGidenTalimatTx.setGonKimlikVerilisTarihi((iMap.get("GONDEREN_KIMLIK_VERILIS_TARIHI") != null
						&& !"null".equals(iMap.getString("GONDEREN_KIMLIK_VERILIS_TARIHI"))
						&& iMap.getString("GONDEREN_KIMLIK_VERILIS_TARIHI").length() != 0) ? iMap.getDate("GONDEREN_KIMLIK_VERILIS_TARIHI") : null);
				ypHavaleGidenTalimatTx.setGonderenSehir(iMap.getString("GONDEREN_SEHIR"));
				ypHavaleGidenTalimatTx.setKpsYapildi(iMap.getString("KPS_YAPILDI_MI"));
				ypHavaleGidenTalimatTx.setAliciAdi(iMap.getString("ALICI_AD_SOYAD"));
				ypHavaleGidenTalimatTx.setAliciHesapNo(iMap.getString("ALICI_HESAP_NO"));
				ypHavaleGidenTalimatTx.setAliciTelefon(iMap.getString("ALICI_TELEFON"));
				ypHavaleGidenTalimatTx.setAliciAdres(iMap.getString("ALICI_ADRESI"));
				ypHavaleGidenTalimatTx.setAliciDogumTar((iMap.get("ALICI_DOGUM_TARIHI") != null
						&& !"null".equals(iMap.getString("ALICI_DOGUM_TARIHI"))
						&& iMap.getString("ALICI_DOGUM_TARIHI").length() != 0) ? iMap.getDate("ALICI_DOGUM_TARIHI") : null);
				ypHavaleGidenTalimatTx.setAliciAciklama(iMap.getString("ALICI_ACIKLAMA"));
				ypHavaleGidenTalimatTx.setAliciKartNo(iMap.getString("ALICI_KART_NO"));
				ypHavaleGidenTalimatTx.setFIbanBiliniyormu(iMap.getString("IBAN_BILINIYOR_MU"));
				ypHavaleGidenTalimatTx.setAliciIbanNo(iMap.getString("ALICI_IBAN"));
				ypHavaleGidenTalimatTx.setAliciBabaAdi(iMap.getString("ALICI_BABA_ADI"));
				ypHavaleGidenTalimatTx.setAliciBankaBicKodu(iMap.getString("ALICI_BANKA_BIC_KODU"));
				ypHavaleGidenTalimatTx.setAliciBankaUlkeKodu(iMap.getString("ALICI_BANKA_ULKE_KODU"));
				ypHavaleGidenTalimatTx.setAliciBankaKodu(iMap.getString("ALICI_BANKA_KODU"));
				ypHavaleGidenTalimatTx.setAliciBankaSubeKodu(iMap.getString("ALICI_BANKA_SUBE_KODU"));
				ypHavaleGidenTalimatTx.setAliciBankaSehirKodu(iMap.getString("ALICI_BANKA_SEHIR_KODU"));
				ypHavaleGidenTalimatTx.setAliciBankaAdi(iMap.getString("ALICI_BANKA_ADI"));
				ypHavaleGidenTalimatTx.setAliciBankaSehirAdi(iMap.getString("ALICI_BANKA_SEHIR_ADI"));
				ypHavaleGidenTalimatTx.setAliciBankaSubeAdi(iMap.getString("ALICI_BANKA_SUBE_ADI"));
				ypHavaleGidenTalimatTx.setAliciBankaBicKodu2(iMap.getString("ALICI_BANKA_BIC_KODU_2"));
				ypHavaleGidenTalimatTx.setAliciBankaAdi2(iMap.getString("ALICI_BANKA_ADI_2"));
				ypHavaleGidenTalimatTx.setAliciBankaSehirAdi2(iMap.getString("ALICI_BANKA_SEHIR_ADI_2"));
				ypHavaleGidenTalimatTx.setAliciBankaSubeAdi2(iMap.getString("ALICI_BANKA_SUBE_ADI_2"));
				ypHavaleGidenTalimatTx.setAliciTelefonUlkeKodu(iMap.getString("ALICI_TELEFON_ULKE_KODU"));
    		}
    		else if (iMap.getString("SAVE").compareTo("2") == 0) {
    			ypHavaleGidenTalimatTx.setReferans(iMap.getString("TU_REFERANS"));
    			ypHavaleGidenTalimatTx.setFKurumReferans(iMap.getBoolean("F_KURUM_REFERANS", true) ? "E" : "H");
    		}

    		else if (iMap.getString("SAVE").compareTo("3") == 0) {
    			ypHavaleGidenTalimatTx.setPttIslemNo(iMap.getBigDecimal("ISLEM_NO_PTT"));
    			ypHavaleGidenTalimatTx.setKurumReferans(iMap.getString("CORRESPONDENT_REF"));
    		}
    		session.saveOrUpdate(ypHavaleGidenTalimatTx);
    		session.flush();

    		return iMap;
    	} catch (Exception e) {
    		throw ExceptionHandler.convertException(e);
    	}
    }
    
    @GraymoundService("CLKS_UPDATE_CUSTOMER_INFO")
    public static GMMap clksUpdateCustomerInfo(GMMap iMap) {
    	
    	try {
	    	Session session = DAOSession.getSession("BNSPRDal");
	
	        YpHavaleGidenTalimatTx ypHavaleGidenTalimatTx = (YpHavaleGidenTalimatTx) session.get(YpHavaleGidenTalimatTx.class, iMap.getBigDecimal("ISLEM_NO"));
	    	
	        if (ypHavaleGidenTalimatTx == null) {
	        	ypHavaleGidenTalimatTx = new YpHavaleGidenTalimatTx();
	        }
	        
	        ypHavaleGidenTalimatTx.setTxNo(iMap.getBigDecimal("ISLEM_NO"));
	        ypHavaleGidenTalimatTx.setTcKimlikNo(iMap.containsKey("GONDEREN_TCKN") ? iMap.getString("GONDEREN_TCKN") : null);
    		ypHavaleGidenTalimatTx.setVergiNo(iMap.containsKey("GONDEREN_VERGI_NO_YKN") ? iMap.getString("GONDEREN_VERGI_NO_YKN") : null);
	        session.saveOrUpdate(ypHavaleGidenTalimatTx);
	        session.flush();
	        
    	} catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    	
        return iMap;
    }
    
	@GraymoundService("CLKS_GET_CUSTOMER_TCKN")
	public static GMMap clksGetCustomerTCKN(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_YPUPT.PTT_Get_Musteri_TCKN(?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.NUMERIC);
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.execute();
			oMap.put("TCKN", stmt.getString(2));
			oMap.put("TUTAR", stmt.getBigDecimal(3));
			oMap.put("TUTAR_CODE", stmt.getString(4));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("CLKS_YPUPT_LOG_AT")
	public static GMMap YPUPTLogAt(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()));
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_YPUPT.YPUPT_Log_At(?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO_PTT"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setDate(i++, new Date(oMap.getDate("BANKA_TARIH").getTime()));
			stmt.execute();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_YPUPT_TX_AKTAR")
	public static GMMap ClksYPUptTxAktar(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			conn = DALUtil.getGMConnection();

			iMap.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
			iMap.put("ISLEM_TURU", "O");
			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA",iMap);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	
	/*
	 *********************************
	 * INPUT iMap
	 *********************************
		 * ALICI_ULKE_KODU
		 * ALICI_BANKA_KODU
		 * ODEME_TURU 
		 * HAVALE_TIPI
		 * DOVIZ_CINSI
		 * TUTAR
		 * GONDEREN_TCKN
	 *********************************
	 * OUTPUT oMap
	 *********************************
		 * 	RESPONSE
		 * 	RESPONSE_DATA
		 *  MASRAF_DOVIZ_TUTAR
		 *  USD_KUR
		 *  EUR_KUR
		 *  EUR_USD_PARITE
	 * */
	@GraymoundService("CLKS_YPUPT_MASRAF_HESAPLA")
	public static GMMap ClksYPUPTMasrafHesapla(GMMap iMap) {
		logger.info("CLKS_YPUPT_MASRAF_HESAPLA in:" + iMap.toString());

		GMMap oMap = new GMMap();
		GMMap i2Map = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		String tuOfisimi = GMServiceExecuter.call("CLKS_GET_TU_INFO", iMap).getString("TU_OFISIMI");

		try {

			if ("E".equals(tuOfisimi)) {

				i2Map.put("SEND_AMOUNT", iMap.getBigDecimal("TUTAR"));
				i2Map.put("SENDER_COUNTRY_CODE", iMap.getString("TR"));
				i2Map.put("RECIPIENT_COUNTRY_CODE", iMap.getString("ALICI_ULKE_KODU"));

				if ("NORM".equals(iMap.getString("HAVALE_TIPI"))) {
					i2Map.put("TARGET_TRANSACTION_TYPE_CODE", iMap.getString("001"));// Isme Gonderim
				} else {
					i2Map.put("TARGET_TRANSACTION_TYPE_CODE", iMap.getString("001"));// SWIFT Gonderim
				}
				i2Map.put("SEND_AMOUNT_CURRENCY", iMap.getString("DOVIZ_CINSI"));
				i2Map.put("DIRECTION", "1");

				// in-> SEND_AMOUNT,
				//SENDER_COUNTRY_CODE,
				//RECIPIENT_COUNTRY_CODE,
				//TARGET_TRANSACTION_TYPE_CODE,
				//SEND_AMOUNT_CURRENCY,DIRECTION
				i2Map.putAll(GMServiceExecuter.call("BNSPR_TU_GET_EXPENSE_DATA", i2Map));
				// out-> OUT_EXPENSE_AMOUNT, 
				// OUT_EXPENSE_CURRENCY, 
				// OUT_EXPENSE_PARAMETER_ID

				if (!i2Map.getString("OUT_EXPENSE_CURRENCY").equals(iMap.getString("DOVIZ_CINSI"))) {
					iMap.put("HATA_NO", new BigDecimal(267));
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				oMap.put("MASRAF_DOVIZ_TUTAR", iMap.getBigDecimal("OUT_EXPENSE_AMOUNT"));

			} else {

				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{ call PKG_YPUPT.PTT_Masraf_Hesapla(?,?,?,?,?,?,?,?,?,?,?)}");

				stmt.setString(1, iMap.getString("ALICI_ULKE_KODU"));
				stmt.setString(2, iMap.getString("ALICI_BANKA_KODU"));
				stmt.setString(3, iMap.getString("ODEME_TURU"));
				stmt.setString(4, iMap.getString("HAVALE_TIPI"));
				stmt.setString(5, iMap.getString("DOVIZ_CINSI"));
				stmt.setBigDecimal(6, iMap.getBigDecimal("TUTAR"));
				stmt.setString(7, iMap.getString("GONDEREN_TCKN"));
				stmt.registerOutParameter(8, Types.NUMERIC);
				stmt.registerOutParameter(9, Types.NUMERIC);
				stmt.registerOutParameter(10, Types.NUMERIC);
				stmt.registerOutParameter(11, Types.NUMERIC);

				stmt.execute();

				oMap.put("USD_KUR", stmt.getBigDecimal(8));
				oMap.put("EUR_KUR", stmt.getBigDecimal(9));
				oMap.put("EUR_USD_PARITE", stmt.getBigDecimal(10));
				oMap.put("MASRAF_DOVIZ_TUTAR", stmt.getBigDecimal(11));

				

			}
			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));

		} catch (SQLException e) {
			logger.error("CLKS_YPUPT_MASRAF_HESAPLA err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		/*
		 * oMap.put("RESPONSE", "2"); oMap.put("RESPONSE_DATA", "");
		 * oMap.put("MASRAF_DOVIZ_TUTAR", "12"); oMap.put("USD_KUR", "1.85");
		 * oMap.put("EUR_KUR", "2.25"); oMap.put("EUR_USD_PARITE", "1.4");
		 */

		logger.info("CLKS_YPUPT_MASRAF_HESAPLA out:" + oMap.toString());
		return oMap;
	}	
 
    @GraymoundService("CLKS_GET_TRANSACTION_TYPE_CODE")
    public static GMMap getTransactionTypeCode(GMMap iMap){
      Connection conn = null;
      CallableStatement stmt = null;
      GMMap oMap = new GMMap();
      try{
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{ ? = call  PKG_YPUPT.Get_Transaction_Type_Code(?,?)}");
        int i = 1;
        stmt.registerOutParameter(i++, Types.VARCHAR);
        stmt.setString(i++, iMap.getString("ALICI_ULKE_KODU"));
        stmt.setString(i++, iMap.getString("HAVALE_TIPI"));
        
        stmt.execute();
        oMap.put("TARGET_TRANSACTION_TYPE_CODE", stmt.getString(1));
        return oMap;
      } catch (SQLException e) {
        throw ExceptionHandler.convertException(e);
      } finally {
        GMServerDatasource.close(stmt);
        GMServerDatasource.close(conn);
        
      }

    }

	@GraymoundService("CLKS_GET_INFOR")
	public static GMMap clksGetInfo(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_YPUPT.Get_Transfer_Info(?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.execute();
			oMap.put("ALICI_ULKE_KODU", stmt.getString(2));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
    @GraymoundService("CLKS_GET_TU_ISLEM_INFO")
    public static GMMap getTuIslemInfo(GMMap iMap){
      Connection conn = null;
      CallableStatement stmt = null;
      GMMap oMap = new GMMap();
	  ResultSet rSet = null;
	  
      try{
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{ ? = call  PKG_YPUPT.Get_TU_Islem(?)}");
        int i = 1;
        stmt.registerOutParameter(i++, -10);
        stmt.setString(i++, iMap.getString("ISLEM_NO"));
        stmt.execute();
	      
	    rSet = (ResultSet)stmt.getObject(1);
	      
	    String tableName = "TU_ISLEM";
	    GMMap o2Map=DALUtil.rSetResults(rSet,tableName);
	    oMap.putAll(o2Map.getMap(tableName, 0));
	      
       /*
	    oMap.put("ALICI_ACIKLAMA",rSet.getString("ALICI_ACIKLAMA"));
        oMap.put("ALICI_ADSOYAD",rSet.getString("ALICI_ADSOYAD"));
        oMap.put("ALICI_BABAADI",rSet.getString("ALICI_BABAADI"));
        oMap.put("ALICI_BANKA_BIC",rSet.getString("ALICI_BANKA_BIC"));
        oMap.put("ALICI_BANKA_KOD",rSet.getString("ALICI_BANKA_KOD"));
        oMap.put("ALICI_DOGTAR",rSet.getString("ALICI_DOGTAR"));
        oMap.put("ALICI_HESAP",rSet.getString("ALICI_HESAP"));
        oMap.put("ALICI_IBAN",rSet.getString("ALICI_IBAN"));
        oMap.put("ALICI_KART_NO",rSet.getString("ALICI_KART_NO"));
        oMap.put("ALICI_SUBE_KOD",rSet.getString("ALICI_SUBE_KOD"));
        oMap.put("ALICI_ULKE_KOD",rSet.getString("ALICI_ULKE_KOD"));
        oMap.put("BANKA_ISLEM_NO",rSet.getString("BANKA_ISLEM_NO"));
        oMap.put("GONDEREN_AD",rSet.getString("GONDEREN_AD"));
        oMap.put("GONDEREN_ADRES",rSet.getString("GONDEREN_ADRES"));
        oMap.put("GONDEREN_ADRES_CADDE",rSet.getString("GONDEREN_ADRES_CADDE"));
        oMap.put("GONDEREN_ADRES_POSTA_KODU",rSet.getString("GONDEREN_ADRES_POSTA_KODU"));
        oMap.put("GONDEREN_ANNEADI",rSet.getString("GONDEREN_ANNEADI"));
        oMap.put("GONDEREN_BABAADI",rSet.getString("GONDEREN_BABAADI"));
        oMap.put("GONDEREN_CEPTEL",rSet.getString("GONDEREN_CEPTEL"));
        oMap.put("GONDEREN_CINSIYET",rSet.getString("GONDEREN_CINSIYET"));
        oMap.put("GONDEREN_DOGTAR",rSet.getString("GONDEREN_DOGTAR"));
        oMap.put("GONDEREN_DOGYER",rSet.getString("GONDEREN_DOGYER"));
        oMap.put("GONDEREN_EV_TEL",rSet.getString("GONDEREN_EV_TEL"));
        oMap.put("GONDEREN_ILCE_KODU",rSet.getString("GONDEREN_ILCE_KODU"));
        oMap.put("GONDEREN_KIMLIK_NO",rSet.getString("GONDEREN_KIMLIK_NO"));
        oMap.put("GONDEREN_KIMLIK_TIP",rSet.getString("GONDEREN_KIMLIK_TIP"));
        oMap.put("GONDEREN_KIMLIK_ULKE_KODU",rSet.getString("GONDEREN_KIMLIK_ULKE_KODU"));
        oMap.put("GONDEREN_KIMLIK_VEREN_ULKE",rSet.getString("GONDEREN_KIMLIK_VEREN_ULKE"));
        oMap.put("GONDEREN_KIMLIK_VERILEN_TARIH",rSet.getString("GONDEREN_KIMLIK_VERILEN_TARIH"));
        oMap.put("GONDEREN_KIMLIK_VERILEN_YER",rSet.getString("GONDEREN_KIMLIK_VERILEN_YER"));
        oMap.put("GONDEREN_SEHIR",rSet.getString("GONDEREN_SEHIR"));
        oMap.put("GONDEREN_SEHIR_KODU",rSet.getString("GONDEREN_SEHIR_KODU"));
        oMap.put("GONDEREN_SOYAD",rSet.getString("GONDEREN_SOYAD"));
        oMap.put("GONDEREN_TU_MUSTERINO",rSet.getString("GONDEREN_TU_MUSTERINO"));
        oMap.put("GONDEREN_ULKE_KOD",rSet.getString("GONDEREN_ULKE_KOD"));
        oMap.put("GONDEREN_UYRUK",rSet.getString("GONDEREN_UYRUK"));
        oMap.put("GONDEREN_VATANDASLIK_NO",rSet.getString("GONDEREN_VATANDASLIK_NO"));
        oMap.put("GONDERIM_NEDENI",rSet.getString("GONDERIM_NEDENI"));
        oMap.put("GONDERIM_PARAKOD",rSet.getString("GONDERIM_PARAKOD"));
        oMap.put("GONDERIM_TUTAR",rSet.getString("GONDERIM_TUTAR"));
        oMap.put("HEDEF_ISLEM_TIP",rSet.getString("HEDEF_ISLEM_TIP"));
        oMap.put("KAYNAK_ISLEM_TIP",rSet.getString("KAYNAK_ISLEM_TIP"));
        oMap.put("MASRAF_INDIRIM_TUTAR",rSet.getString("MASRAF_INDIRIM_TUTAR"));
        oMap.put("KAYNAK_ISLEM_TIP",rSet.getString("KAYNAK_ISLEM_TIP"));
        oMap.put("PARANIN_KAYNAGI",rSet.getString("PARANIN_KAYNAGI"));
        oMap.put("TAHSIL_ISLEM_MASRAF_PARAKOD",rSet.getString("TAHSIL_ISLEM_MASRAF_PARAKOD"));
        oMap.put("TAHSIL_ISLEM_MASRAF_TUTAR",rSet.getString("TAHSIL_ISLEM_MASRAF_TUTAR"));
        oMap.put("TAHSIL_MASRAF_KUR",rSet.getString("TAHSIL_MASRAF_KUR"));
        oMap.put("TAHSIL_MASRAF_PARAKOD",rSet.getString("TAHSIL_MASRAF_PARAKOD"));
        oMap.put("TAHSIL_MASRAF_TUTAR",rSet.getString("TAHSIL_MASRAF_TUTAR"));
        oMap.put("TAHSIL_TUTAR1",rSet.getString("TAHSIL_TUTAR1"));
        oMap.put("TAHSIL_TUTAR1_KUR",rSet.getString("TAHSIL_TUTAR1_KUR"));
        oMap.put("TAHSIL_TUTAR1_PARAKOD",rSet.getString("TAHSIL_TUTAR1_PARAKOD"));
        oMap.put("TAHSIL_TUTAR2",rSet.getString("TAHSIL_TUTAR2"));
        oMap.put("TAHSIL_TUTAR2_KUR",rSet.getString("TAHSIL_TUTAR2_KUR"));
        oMap.put("TAHSIL_TUTAR2_PARAKOD",rSet.getString("TAHSIL_TUTAR2_PARAKOD"));
        oMap.put("TEST_SORU_CEVAP",rSet.getString("TEST_SORU_CEVAP"));
        oMap.put("TEST_SORU_ID",rSet.getString("TEST_SORU_ID"));
        oMap.put("TU_MASRAF_ID",rSet.getString("TU_MASRAF_ID"));
        oMap.put("TU_MASRAF_PARAKOD",rSet.getString("TU_MASRAF_PARAKOD"));
        oMap.put("TU_MASRAF_TUTAR",rSet.getString("TU_MASRAF_TUTAR"));	 
        */
        return oMap;
      } catch (SQLException e) {
        throw ExceptionHandler.convertException(e);
      } finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
        
      }

    }
    
	@GraymoundService("CLKS_GET_YPUPT_ANLASMALI_BANKALAR")
	public static GMMap getClksYpUptAnlasmaliBankalar(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap resultMap = new GMMap();
		GMMap tMap = new GMMap();
		String table = "BANKA_LIST";
		try {

			resultMap.put("COUNTRYLIST", GMServiceExecuter.call("TRUNION_GET_COUNTRY_DATA", iMap).get("COUNTRYLIST"));
			
			int row = 0;
			for(int i = 0; i < resultMap.getSize("COUNTRYLIST"); i++) {
				
				tMap.clear();
				tMap.put("CURRENTPAYMENTLIMITS", resultMap.get("COUNTRYLIST", i, "CURRENTPAYMENTLIMITS"));
				
				if(tMap.getSize("CURRENTPAYMENTLIMITS") > 0) {
					for (int j = 0; j < tMap.getSize("CURRENTPAYMENTLIMITS"); j++) {
						
						if(iMap.containsKey("ALICI_ULKE_KODU") && !"".equals(iMap.getString("ALICI_ULKE_KODU")) && iMap.getString("ALICI_ULKE_KODU") != null) {
							if(resultMap.get("COUNTRYLIST", i, "COUNTRYCODEOUT").equals(iMap.getString("ALICI_ULKE_KODU"))) {
								oMap.put(table, row, "ALICI_ULKE_KODU", resultMap.get("COUNTRYLIST", i, "COUNTRYCODEOUT"));
								oMap.put(table, row, "DOVIZ", tMap.get("CURRENTPAYMENTLIMITS", j, "CURRENCY"));
								oMap.put(table, row, "LIMIT", tMap.get("CURRENTPAYMENTLIMITS", j, "AMOUNT"));
								oMap.put(table, row, "ACENTA_MALIYET_ORAN", resultMap.get("COUNTRYLIST", i, "REPORTEREXPENSE"));
								oMap.put(table, row++, "PAZARLAMA_MALIYET_ORAN", resultMap.get("COUNTRYLIST", i, "MARKETINGEXPENSE"));
							}
						}
						else {
							oMap.put(table, row, "ALICI_ULKE_KODU", resultMap.get("COUNTRYLIST", i, "COUNTRYCODEOUT"));
							oMap.put(table, row, "DOVIZ", tMap.get("CURRENTPAYMENTLIMITS", j, "CURRENCY"));
							oMap.put(table, row, "LIMIT", tMap.get("CURRENTPAYMENTLIMITS", j, "AMOUNT"));
							oMap.put(table, row, "ACENTA_MALIYET_ORAN", resultMap.get("COUNTRYLIST", i, "REPORTEREXPENSE"));
							oMap.put(table, row++, "PAZARLAMA_MALIYET_ORAN", resultMap.get("COUNTRYLIST", i, "MARKETINGEXPENSE"));
						}
					}
				}
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
		return oMap;
	}

	@GraymoundService("CLKS_YPUPT_ALAN_BILGI")
	public static GMMap getClksYpUptAlanBilgi(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		int row = 0;
		int i = 0;
		try {

			String funcStr = "{? = call pkg_parametre.deger_al_k_n(?)}";
			Object [] inputValues = new Object [2];
			
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "PTT_TRANSFER_VKN_YKN_LIMIT";
			BigDecimal PTT_TRANSFER_VKN_YKN_LIMIT = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
			i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "PTT_TRANSFER_ADRES_LIMIT";
			BigDecimal PTT_TRANSFER_ADRES_LIMIT = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
			i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "PTT_TRANSFER_BABA_ADI_LIMIT";
			BigDecimal PTT_TRANSFER_BABA_ADI_LIMIT = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
			i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "PTT_TRANSFER_ANNE_ADI_LIMIT";
			BigDecimal PTT_TRANSFER_ANNE_ADI_LIMIT = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
			
    		Session session = DAOSession.getSession("BNSPRDal");

    		YpHavaleGidenTalimatTx ypHavaleGidenTalimatTx = (YpHavaleGidenTalimatTx) session.get(YpHavaleGidenTalimatTx.class, iMap.getBigDecimal("ISLEM_NO"));

			String tableName = "GONDERICI_BILGI_LIST";
			
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_TCKN")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", ("TR".equals(iMap.getString("GONDEREN_UYRUK"))) ? "1" : "0");
			oMap.put(tableName, row, "ZORUNLULUK", ("TR".equals(iMap.getString("GONDEREN_UYRUK"))) ? "1" : "0");
			
			row++;
		
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_VKN_YKN")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", ("TR".equals(iMap.getString("GONDEREN_UYRUK"))) ? "0" : "1");
			oMap.put(tableName, row, "ZORUNLULUK", "0");
			if(!"TR".equals(iMap.getString("GONDEREN_UYRUK"))) {
				
				if("G".equals(iMap.getString("GONDEREN_KIMLIK_TIPI"))) {
					oMap.put(tableName, row, "ZORUNLULUK", "1");
				}
				else {
					if("TRY".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
		    			if(PTT_TRANSFER_VKN_YKN_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar()) == -1) {
		    				oMap.put(tableName, row, "ZORUNLULUK", "1");
		    			}
		    		} 
		    		else if("EUR".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
		    			if(PTT_TRANSFER_VKN_YKN_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar().multiply(ypHavaleGidenTalimatTx.getPttEurkur())) == -1) {
		    				oMap.put(tableName, row, "ZORUNLULUK", "1");
		    			}
		    		}
		    		else if("USD".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
		    			if(PTT_TRANSFER_VKN_YKN_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar().multiply(ypHavaleGidenTalimatTx.getPttUsdkur())) == -1) {
		    				oMap.put(tableName, row, "ZORUNLULUK", "1");
		    			}
		    		}
	    		}
			}
			
			row++;
		
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_AD_SOYAD")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
		
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_DOGUM_YERI")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
		
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_DOGUM_TARIHI")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
		
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_ANNE_ADI")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "0");
			oMap.put(tableName, row, "ZORUNLULUK", "0");
			if("TR".equals(iMap.getString("GONDEREN_UYRUK"))) {
				
				if("TRY".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
	    			if(PTT_TRANSFER_ANNE_ADI_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar()) == -1) {
	    				oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
	    			}
	    		} 
	    		else if("EUR".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
	    			if(PTT_TRANSFER_ANNE_ADI_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar().multiply(ypHavaleGidenTalimatTx.getPttEurkur())) == -1) {
	    				oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
	    			}
	    		}
	    		else if("USD".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
	    			if(PTT_TRANSFER_ANNE_ADI_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar().multiply(ypHavaleGidenTalimatTx.getPttUsdkur())) == -1) {
	    				oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
	    			}
	    		}
			}
			
			row++;
		
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_BABA_ADI")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_DEKONT", "0");
			if("TR".equals(iMap.getString("GONDEREN_UYRUK"))) {
				
				if("TRY".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
	    			if(PTT_TRANSFER_BABA_ADI_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar()) == -1) {
	    				oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
	    			}
	    		} 
	    		else if("EUR".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
	    			if(PTT_TRANSFER_BABA_ADI_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar().multiply(ypHavaleGidenTalimatTx.getPttEurkur())) == -1) {
	    				oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
	    			}
	    		}
	    		else if("USD".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
	    			if(PTT_TRANSFER_BABA_ADI_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar().multiply(ypHavaleGidenTalimatTx.getPttUsdkur())) == -1) {
	    				oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
	    			}
	    		}
			}
	
			row++;
		
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_KIMLIK_TURU")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
			
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_KIMLIK_NO")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
			
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_ADRES")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "0");
			if(!"NORM".equals(ypHavaleGidenTalimatTx.getHavaleTipi())) {
				oMap.put(tableName, row, "ZORUNLULUK", "1");
			}
			else if("TRY".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
    			if(PTT_TRANSFER_ADRES_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar()) == -1) {
    				oMap.put(tableName, row, "ZORUNLULUK", "1");
    			}
    		} 
    		else if("EUR".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
    			if(PTT_TRANSFER_ADRES_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar().multiply(ypHavaleGidenTalimatTx.getPttEurkur())) == -1) {
    				oMap.put(tableName, row, "ZORUNLULUK", "1");
    			}
    		}
    		else if("USD".equals(ypHavaleGidenTalimatTx.getDovizCinsi())) {
    			if(PTT_TRANSFER_ADRES_LIMIT.compareTo(ypHavaleGidenTalimatTx.getTutar().multiply(ypHavaleGidenTalimatTx.getPttUsdkur())) == -1) {
    				oMap.put(tableName, row, "ZORUNLULUK", "1");
    			}
    		}

			row++;
		
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_CEP_ULKE_KOD")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
			
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "GONDEREN_CEP_TEL_NO")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			tableName = "ALICI_BILGI_LIST";
			row = 0;
			
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "ALICI_AD_SOYAD")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
			
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "ALICI_CEP_ULKE_KOD")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
			
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "ALICI_CEP_TEL_NO")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");
	
			row++;
			
			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_YPUPT_KOD").put("KEY", "ALICI_ACIKLAMA")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "0");
		}
		
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("YP_UPT_KOMISYON_MASRAF_RAPORU_MAIL_JOB")
	public static GMMap komisyonMasrafRaporuMailJob(GMMap iMap) throws java.text.ParseException {
        String FILES_FOLDER = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root" + File.separator + "files"+ File.separator;

		GMMap oMap = new GMMap();
		 
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap tMap = new GMMap();
		
		Date oncekiTarih = null ;
		String oncekiBankaTarihi;

		String extPdf = ".pdf";
		String extXls = ".xls";

		String fileName;
		String tableData = "TABLE_DATA";

		String to;
		String from = "system@aktifbank.com.tr";

		boolean anyError = false;

		// �nceki banka tarihini uygun formatta ald�k:
		{
			try {
				conn = DALUtil.getGMConnection();
			    stmt = conn.prepareCall("{ ? = call  pkg_muhasebe.Onceki_Banka_Tarihi_Bul(?)}");
		        int i = 0;
		        stmt.registerOutParameter(++i, Types.DATE);
		        stmt.execute();
				
		        oncekiTarih = stmt.getDate(1);
		        
		        stmt = conn.prepareCall("{ ? = call  pkg_tarih.geri_is_gunu(?,?,?)}");
		        int j = 0;
		        stmt.registerOutParameter(++j, Types.DATE);
		        stmt.setDate(++j, oncekiTarih);
		        stmt.execute();
			      
			    oncekiTarih =  stmt.getDate(1);

			} catch (Exception e) {
				e.printStackTrace();
			}
			
			oncekiBankaTarihi = oncekiTarih == null ? "" : new SimpleDateFormat("dd.MM.yyyy").format(new java.util.Date( oncekiTarih.getTime() ));
			
			fileName = "komisyon_masraf_raporu-"+oncekiBankaTarihi;
		}

		try {
			// Global parametrelerden mail gonderilecek adresleri �ektik:
			{
	            Session session = DAOSession.getSession("BNSPRDal");
	            GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(
	            		Restrictions.eq("kod", "YP_UPT_RAPOR_MAIL_TO")
	            ).uniqueResult();

	    		to = StringUtils.strip(parametre.getDeger(), "\"");
			}
			
			// Datalar� ald�k:
			{
				try {
					conn = DALUtil.getGMConnection();
			        stmt = conn.prepareCall("{ ? = call  PKG_YPUPT.YP_UPT_Komisyon_Masraf_Raporu}");
			        int i = 1;
			        stmt.registerOutParameter(i++, -10);
			        stmt.execute();
				      
				    rSet = (ResultSet)stmt.getObject(1);

				    oMap = DALUtil.rSetResults(rSet, tableData);
				    if (oMap.getSize(tableData)==0) {
				    	anyError=true;
				    }
				} catch (Exception e) {
					e.printStackTrace();
					anyError=true;
				}
			}
			
			GMMap mailMap = new GMMap();
			mailMap.put("MAIL_TO", to);
			mailMap.put("MAIL_FROM", from);
			mailMap.put("MAIL_SUBJECT",  oncekiBankaTarihi + " Tarihli D�viz UPT Komisyon/Masraf Raporu");
			mailMap.put("IS_BODY_HTML", "H");

			Map<String, String[]> headers = new LinkedHashMap<String, String[]>();

			headers.put("ISLEM_TARIHI", 			new String[] { "��lem Tarihi",	"getDate;DateTime"				});
			headers.put("BANKA_ISLEM_NO", 			new String[] { "Banka ��lem No"									});
			headers.put("PTT_ISLEM_NO", 			new String[] { "PTT ��lem No"									});
			headers.put("ISLEM_TUTARI", 			new String[] { "��lem Tutar�", "getBigDecimal;Number"			});
			headers.put("DOVIZ_CINSI", 				new String[] { "D�viz Cinsi"									});
			headers.put("TAHSILAT_TUTARI", 			new String[] { "Tahsilat Tutar�"								});
			headers.put("MUSTERI_MASRAF", 			new String[] { "M��teri Masraf�", "getBigDecimal;Number"		});
			headers.put("MUSTERI_MASRAF_DOVIZ",		new String[] { "M��teri Masraf� (D�viz Cinsi)"					});
			headers.put("OPS_MASRAF", 				new String[] { "Operasyonel Masraf"	, "getBigDecimal;Number"	});
			headers.put("OPS_MASRAF_DOVIZ", 		new String[] { "Operasyonel Masraf (D�viz Cinsi)"				});
			headers.put("MUHABIR_MASRAF", 			new String[] { "Muhabir Masraf"	, "getBigDecimal;Number"		});
			headers.put("MUHABIR_MASRAF_DOVIZ", 	new String[] { "Muhabir Masraf (D�viz Cinsi)"					});
			headers.put("KOMISYON_TUTAR", 			new String[] { "PTT Komisyon Tutar�", "getBigDecimal;Number"	});
			headers.put("KOMISYON_DOVIZ", 			new String[] { "PTT Komisyon D�viz"								});
			headers.put("ALICI_ULKE_KODU", 			new String[] { "Al�c� �lke Kodu"								});
			headers.put("KUR", 						new String[] { "Kur", "getBigDecimal;Number", "7"				});

			oMap.put("HEADERS", headers);
			oMap.put("FILE_NAME", fileName);
			oMap.put("CHANGE_PAGE_DIRECTION", false);

            int dosyaSayisi = 0;
            if (!anyError) {
				try {
					tMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", oMap));
					
					if (tMap.getInt("DOSYA_SAYISI")>0) {
						for (dosyaSayisi = 1; dosyaSayisi<tMap.getInt("DOSYA_SAYISI") + 1;dosyaSayisi++) {
							mailMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi-1, "FILE_NAME", fileName + (tMap.getInt("DOSYA_SAYISI")==1 ? "" : "-" + dosyaSayisi) + extXls);
							mailMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi-1, "FILE_CONTENT", FileUtil.readFileToByteArray(new File(FILES_FOLDER + fileName + dosyaSayisi + extXls)));
						}
						dosyaSayisi--; // for'daki son kontrolden dolay� 1 fazladan eklenmi�ti
					}

					tMap.putAll(GMServiceExecuter.call("BNSPR_TABLE_TO_PDF", oMap));

					dosyaSayisi++;

					mailMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi - 1, "FILE_NAME", fileName + extPdf);
					mailMap.put("MAIL_ATTACHMENT_LIST", dosyaSayisi - 1, "FILE_CONTENT", FileUtil.readFileToByteArray((File) tMap.get("PDF_FILE")));
				} catch (Exception e) {
					e.printStackTrace();
					anyError=true;
				}
				mailMap.put("MAIL_BODY", anyError ? "Dosyalar eklenirken hata olu�tu." : oncekiBankaTarihi + " tarihine ait D�viz UPT G�nderim Raporu olu�turuldu.");
			} else {
				mailMap.put("MAIL_BODY", "Raporlanacak herhangi bir kay�t bulunamad�.");
			}

			oMap = GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

			if (tMap.containsKey("PDF_FILE") && tMap.get("PDF_FILE")!=null) {
				File pdf = (File) tMap.get("PDF_FILE");
				if (pdf.exists()) {
					pdf.delete();
				}
			}
			GMServiceExecuter.call("BNSPR_DELETE_EXCEL_TMP_FILES", tMap);
		}
	}
}
