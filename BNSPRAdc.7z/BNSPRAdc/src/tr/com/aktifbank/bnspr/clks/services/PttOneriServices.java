package tr.com.aktifbank.bnspr.clks.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;

import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class PttOneriServices {
	private static ArrayList<String> recipientsList;
	private static String mailSubject;
	private static String from;
	private static Configurator conf;
	private static String mailGonderParam;
	private static String  aciklama = null;
	private static String  sube = null;
	private static String  merkez = null;
	private static String  basMudurluk = null;
	private static String  kullaniciSicil = null;
	private static String  adSoyad = null;
	static {
		conf = Configurator.createConfiguratorFromProperties(
			"configuration/pttOneriServices.properties");
		
		String rcpListStr = conf.getProperty("mailRecipientList");
		if (rcpListStr != null) {
			recipientsList = new ArrayList<String>();
			recipientsList.addAll(Arrays.asList(rcpListStr.split(";")));
		}
		
		mailSubject = conf.getProperty("mailSubject");
		from = conf.getProperty("mailFrom");
		mailGonderParam = conf.getProperty("mailGonderParam");
	}
	
	@GraymoundService("PTT_ONERI_KAYDET")
	public static GMMap pttOneriKaydet(GMMap iMap)  {
		
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		String recipientsListStr = null	;
		Connection conn = null;
		
		StringBuilder mailBodySb = new StringBuilder();
		
		String call = "{call PKG_CLKS.oneri_kaydet(?,?,?,?,?,? )}";
		
		try { 
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			
			aciklama = iMap.getString("ONERI", 0, "ACIKLAMA");
			sube = iMap.getString("ONERI", 0, "SUBE");
			merkez = iMap.getString("ONERI", 0, "MERKEZ");
			basMudurluk = iMap.getString("ONERI", 0, "BASMUDURLUK");
			kullaniciSicil = iMap.getString("ONERI", 0, "KULLANICI_SICIL");
			adSoyad = iMap.getString("ONERI", 0, "AD_SOYAD");
			
			//ps_aciklama
			stmt.setString(1,aciklama );
			//ps_islemin_yapildigi_sube
			stmt.setString(2, sube);
			//ps_islemin_yapildigi_merkez
			stmt.setString(3, merkez);
			//ps_islemin_yapildigi_basmudurl
			stmt.setString(4,basMudurluk);
			//ps_islemi_yapan_kullanici_sici
			stmt.setString(5,kullaniciSicil);
			//ps_islemi_yapan_adsoyad
			stmt.setString(6,adSoyad);
			
			mailBodySb.append(aciklama).append("\n PTT G�revlisi/sicil No:");
			mailBodySb.append(adSoyad).append("-").append(kullaniciSicil);
			mailBodySb.append("\n Sube: ").append(sube).append("\n Merkez :");
			mailBodySb.append(merkez).append("\n Basm�d�rl�k :").append(basMudurluk);
			
			stmt.execute();
			GMServerDatasource.close(stmt);
			
			call = "{?=call PKG_PARAMETRE.Deger_Al_K(?)}";
			
			stmt = conn.prepareCall(call);
			stmt.setQueryTimeout(1800);
			stmt.registerOutParameter(1,java.sql.Types.VARCHAR);
			
			stmt.setString(2, mailGonderParam);
			
			stmt.execute();
			stmt.getMoreResults();
			
			recipientsListStr= stmt.getString(1);
			recipientsList = new ArrayList<String>();
			recipientsList.addAll(Arrays.asList(recipientsListStr.split(";")));
			recipientsList.add("serife.uysal@aktifbank.com.tr");
			
			sendMail(mailBodySb.toString());
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new GMRuntimeException(0,e.getMessage(), true);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		
		return oMap;
	}

	private static void sendMail(String mailBody){
	
		
		GMMap servisMap = new GMMap();
		servisMap.put("FROM", from);
		servisMap.put("RECIPIENTS_TO", recipientsList); //recipientsList
		servisMap.put("SUBJECT", mailSubject);
		servisMap.put("IS_BODY_HTML", "H");
	    servisMap.put("MESSAGE_BODY", mailBody);

	    GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);

	}
}