package tr.com.aktifbank.bnspr.clks.util;

import com.graymound.util.GMMap;

public class BnsprAdcMessageExecuter {

	public static String RESPONSE 			= "RESPONSE"		;
	public static String RESPONSE_DATA 		= "RESPONSE_DATA"	;
	
	public static String SORRY 				= "SORRY" 			;
	public static String OPERATION_SUCCESS	= "SUCCESS" 		;
	public static String OPERATION_FAIL		= "FAIL" 			;
	public static String RESPONSE_0			= "0" 				;
	public static String RESPONSE_2			= "2"	 			;

	public static String callMessage (String message , GMMap fields){
// 		daha sonra messageFac.  alinacak simdilik doyle kalacak
//		return GMMessageFactory.getMessage(message, fields);
		return message;
	}
	
	public static String callMessage (String message ){
		return callMessage (message, null);
	}
	
	public static GMMap callError (String message  ){
		return callError(message, new GMMap());
	}
	public static GMMap callError (String message , GMMap iMap ){
		iMap.put(RESPONSE, RESPONSE_0);
		iMap.put(RESPONSE_DATA, callMessage(message,iMap));
		return iMap;
	}
	
	public static GMMap callSuccess (String message  ){
		return callSuccess(message, new GMMap());
	}
	public static GMMap callSuccess (String message , GMMap iMap ){
		iMap.put(RESPONSE, RESPONSE_2);
		iMap.put(RESPONSE_DATA, callMessage(message,iMap));
		return iMap;
	}
	
	public static GMMap fillMap (  String code ,String message,GMMap iMap){
		iMap.put(RESPONSE, code);
		iMap.put(RESPONSE_DATA, callMessage(message,iMap));
		return iMap;
	}
	
}
