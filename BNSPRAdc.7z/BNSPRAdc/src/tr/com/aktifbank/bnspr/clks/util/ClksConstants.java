package tr.com.aktifbank.bnspr.clks.util;

import java.util.EnumSet;
import java.util.Set;

public class ClksConstants {

	public static final int ISLEM_YI_GIDEN_SWIFT = 12;
	public static final int ISLEM_YD_GIDEN_SWIFT = 13;
	public static final int ISLEM_ATM_NY_HESAP = 60;
	public static final int ISLEM_ATM_NY_IBAN = 61;
	public static final int ISLEM_ATM_NY_EUPT = 62;
	public static final int ISLEM_ATM_TOPUP_PASSOLIG_KART = 63;
	public static final int ISLEM_ATM_TOPUP_PASSOLIG_KIMLIK = 64;
	public static final int ISLEM_ATM_TOPUP_NKOLAY_KART = 65;
	public static final int ISLEM_TOPUP_PASSOLIG_KIMLIK = 65;
	public static final int ISLEM_TOPUP_PASSOLIG_KART = 66;
	public static final int ISLEM_TOPUP_NKOLAY_KIMLIK = 57;
	public static final int ISLEM_TOPUP_NKOLAY_KART = 58;
	public static final int ISLEM_UPT_PCH = 70;
	public static final int ISLEM_UPT_IPC = 71;
	public static final int ISLEM_UPT = 10;

	public static final String IPTAL_GISE = "G";
	public static final String IPTAL_VAZGEC = "V";
	public static final String REVERSAL = "R";

	public static final String BRAND_CARD_NKOLAY = "NKOLAY";
	public static final String BRAND_CARD_PASSOLIG = "PASSOLIG";
	public static final int ODEME_ISLEM_NAKIT_CEKME = 1;

	public enum Transaction {

		NAKIT_YATAN("2050"), NAKIT_CEKILEN("2051"), TAKSIT_TAHSILATI("3133"), HAVALE_ODEME("2032"), HAVALE("2030"), EFT(
			"2315"), YP_TRANSFER("2850"), ATM_NAKIT_YATAN("2049"), ATM_KART_PASSO("2048"), ATM_KART_NKOLAY("20481"),
		KART_PASSO_YATAN("2053"), KART_NKOLAY_YATAN("20531"), UPT_ODEME("3552"), UPT_TALIMAT("2316"), UPT_NAKIT_YATAN(
			"3554"), UPT_NAKIT_CEKILEN("3555");

		private String code;
		
		Transaction(String code) {
			this.code = code;
		}

		@Override
		public String toString() {
			return code;
		}
	}
	
	public enum TransactionStatus {

		NEW("N"), CONFIRMED("C"), VERIFIED("V"), APPROVED("A"), PROCESSED("P"), CANCEL_REQUESTED("1"), CANCELED("2"),
		REJECTED("R"), VERIFIED_REJECTED("D"), CANCEL_REJECTED("3");

		private String code;

		TransactionStatus(String code) {
			this.code = code;
		}

		@Override
		public String toString() {
			return code;
		}

		public static TransactionStatus getEnum(String code) {
			for(TransactionStatus v : values())
				if(v.toString().equalsIgnoreCase(code)) return v;
			throw new IllegalArgumentException();
		}
	}
	
	public static Set<TransactionStatus> FINAL_TRANSACTION_STATUS = EnumSet.of(TransactionStatus.PROCESSED,
		TransactionStatus.CANCELED, TransactionStatus.VERIFIED_REJECTED, TransactionStatus.REJECTED,
		TransactionStatus.CANCEL_REJECTED);
	
	public static Set<TransactionStatus> PROCESSED_TRANSACTION_STATUS = EnumSet.of(TransactionStatus.PROCESSED,
		TransactionStatus.CANCEL_REJECTED);

	public enum Response {
		
		SUCCESS(2), ERROR(0);
		
		private int value;
		
		Response(int value) {
			this.value = value;
		}
	    public int getValue() {
	        return value;
	    }
	}

	public enum BasvuruDurum {

		BASVURU("B"), CEPTE("C"), EVRAKSIZ("E");

		private String kod;

		BasvuruDurum(String kod) {
			this.kod = kod;
		}

		@Override
		public String toString() {
			return kod;
		}

		public static BasvuruDurum getEnum(String kod) {
			for (BasvuruDurum v : values())
				if (v.toString().equalsIgnoreCase(kod))
					return v;
			throw new IllegalArgumentException();
		}
	}

	public enum BelgeKontrol {

		UYGUN("1"), EKSIK("2"), UYUMSUZ("3"), SUPHELI("4"), GONDERILDI("5");

		private String kod;

		BelgeKontrol(String kod) {
			this.kod = kod;
		}

		@Override
		public String toString() {
			return kod;
		}
	}
}
