package tr.com.aktifbank.bnspr.clks.services.credit;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.aktifbank.bnspr.dao.ClksPromosyonBasvuruTx;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class PromosyonServices {
	
	private static Logger logger = Logger.getLogger(PromosyonServices.class);
	
	@GraymoundService("BNSPR_CLKS_PROMOSYON_BASVURU_TALEP")
	public static GMMap bnsprClksPromosyonBasvuruTalep(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();
		
		try {
			
			map.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			map.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN2918_GET_APPLICATION_NO", new GMMap()).getString("BASVURU_NO"));
			
			map.put("KANAL_KOD", 7);
			map.put("MUSTERI_NO", kontaktMusteriYaratVeyaGuncelle(new GMMap(mapKeys(map))));
			GMServiceExecuter.call("BNSPR_TRN2918_SAVE", map);
			oMap.put("TRX_NO", map.get("TRX_NO"));
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_PROMOSYON_BASVURU_TALEP err: " + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_CLKS_PROMOSYON_BASVURU_ONAY")
	public static GMMap bnsprClksPromosyonBasvuruOnay(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();
		
		try {
			
			GMServiceExecuter.call("BNSPR_TRN2918_SAVE", map);
			kontaktMusteriYaratVeyaGuncelle(new GMMap(mapKeys(iMap)));
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_PROMOSYON_BASVURU_ONAY err: " + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * @param iMap
	 * @return
	 * @throws ParseException
	 */
	private static Map<? extends Object, ? extends Object> mapKeys(GMMap iMap) throws ParseException {
		
		/*
		 * + "KPS_BILGILERI[,,,,,ES_TCKN,,,,,,,,,,,KAYIP_KIMLIK_SIRA_NO,KAYIP_KIMLIK_SERI_NO,,,,],"
			+ "APS_BILGILERI[EV_ADRES,EV_ADR_IL_KOD,EV_ADR_ILCE_KOD,EV_POSTAKOD],"
			+ "TC_KIMLIK_NO,SGK_PROMOSYON_KADEMESI,SGK_BRUT_MAAS_TUTARI,POSTA_CEKI_HESAP_NUMARASI,CEP_TEL_KOD,CEP_TEL_NO,EV_TEL_KOD,EV_TEL_NO,ANNE_KIZLIK_SOYADI,F_KPS_YAPILDI,F_APS_YAPILDI,F_KIMLIK_BILGILERI_UYUMLU,F_ADRES_BILGILERI_UYUMLU",
		 * 
		 */
		
		GMMap oMap = new GMMap();

		oMap.putAll(iMap);
		oMap.put("KANAL_KODU", iMap.get("KANAL_KOD"));
		oMap.put("KANAL_ALT_KODU", iMap.get("KANAL_ALT_KOD"));
		oMap.put("SERI_NO", iMap.get("KPS_BILGILERI", 0, "KIMLIK_SERI_NO"));
		oMap.put("SIRA_NO", iMap.get("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO"));
		oMap.put("CINSIYET", iMap.get("KPS_BILGILERI", 0, "CINSIYET"));
		oMap.put("CINSIYET_KOD", iMap.get("KPS_BILGILERI", 0, "CINSIYET"));
		oMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
		oMap.put("ISIM", iMap.get("KPS_BILGILERI", 0, "ADI"));
		oMap.put("SOYADI", iMap.get("KPS_BILGILERI", 0, "SOYADI"));
		oMap.put("IKINCI_ISIM", iMap.get("KPS_BILGILERI", 0, "IKINCI_ADI"));
		oMap.put("UYRUK_KOD", iMap.get("UYRUK")); // TODO Review
		oMap.put("MEDENI_HAL_KOD", iMap.get("KPS_BILGILERI", 0, "MEDENI_HAL"));
		oMap.put("AILE_SIRA_NO",iMap.get("KPS_BILGILERI", 0, "NUFUS_AILE_SIRA_NO"));
		oMap.put("CILT_NO", iMap.get("KPS_BILGILERI", 0, "NUFUS_CILT_NO"));
		oMap.put("SIRA_NO", iMap.get("KPS_BILGILERI", 0, "NUFUS_SIRA_NO"));
		oMap.put("KIZLIK_SOYADI", iMap.get("ONCEKI_SOYADI")); // TODO Review
		oMap.put("MESLEK_KOD", iMap.get("MESLEK")); // TODO Review
		oMap.put("EGITIM_KOD", iMap.get("OGRENIM_DURUMU")); // TODO Review
		oMap.put("VERILDIGI_YER", iMap.get("KPS_BILGILERI", 0, "NUFUS_VERILDIGI_YER"));
		oMap.put("VERILDIGI_TARIH", iMap.get("KPS_BILGILERI", 0, "NUFUS_VERILIS_TARIHI"));
		oMap.put("NUF_VERILIS_NEDENI", iMap.get("KPS_BILGILERI", 0, "NUFUS_VERILIS_NEDENI"));
		oMap.put("KIMLIK_KAYIT_NO", iMap.get("KPS_BILGILERI", 0, "KIMLIK_KAYIT_NO"));
		oMap.put("MAHALLE_KOY", iMap.get("KPS_BILGILERI", 0, "MAHALLE_KOY"));
		oMap.put("IL_KOD", iMap.get("KPS_BILGILERI", 0, "NUFUS_IL_KOD"));
		oMap.put("ILCE_KOD", iMap.get("KPS_BILGILERI", 0, "NUFUS_ILCE_KOD"));
		oMap.put("DOGUM_YERI", iMap.get("KPS_BILGILERI", 0, "DOGUM_YERI"));
		oMap.put("DOGUM_TARIHI", iMap.get("KPS_BILGILERI", 0, "DOGUM_TARIHI"));
		oMap.put("BABA_ADI", iMap.get("KPS_BILGILERI", 0, "BABA_ADI"));
		oMap.put("ANNE_ADI", iMap.get("KPS_BILGILERI", 0, "ANNE_ADI"));
		oMap.put("EV_POSTA_KOD", iMap.get("APS_BILGILERI", 0, "EV_POSTAKOD"));
		oMap.put("EV_IL", iMap.get("APS_BILGILERI", 0, "EV_ADR_IL_KOD"));
		oMap.put("EV_ILCE", iMap.get("APS_BILGILERI", 0, "EV_ADR_ILCE_KOD"));
		oMap.put("EV_ADRES", iMap.get("APS_BILGILERI", 0, "EV_ADRES"));

		if (iMap.get("KPS_BILGILERI", 0, "KIMLIK_SERI_NO") != null && iMap.get("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO") != null && iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SERI_NO").length() != 0 && iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO").length() != 0) {
			oMap.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SERI_NO").concat(iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO").toString()));
		}

		oMap.remove("KPS_BILGILERI");
		oMap.remove("APS_BILGILERI");
		oMap.remove("ISYERI_VE_KULLANICI_BILGILERI");
		
		return oMap;
	}

	/**
	 * 
	 * @param iMap
	 * @return
	 */
	private static BigDecimal kontaktMusteriYaratVeyaGuncelle(GMMap iMap) {

		GMMap oMap = new GMMap();
		BigDecimal musteriNo = null;
		try {

			iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));

			Session session = DAOSession.getSession("BNSPRDal");
			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"));
			restrictions.put("durumKodu", "A");

			List<?> records = session.createCriteria(GnlMusteri.class).add(Restrictions.allEq(restrictions)).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).list();
			Iterator<?> iterator = records.iterator();

			if (iterator.hasNext()) {
				GnlMusteri gnlMusteri = (GnlMusteri) iterator.next();
				musteriNo = gnlMusteri.getMusteriNo();
			}

			else {
				oMap.put("MUSTERI_YARATMA_TX_NO", iMap.getBigDecimal("TRX_NO"));
				kontaktMusteriYarat(iMap);
			}

			oMap.put("MUSTERI_NO", musteriNo);

		}
		catch (Exception e) {
			logger.error(" err: " + e);
			throw ExceptionHandler.convertException(e);
		}

		return musteriNo;
	}

	/**
	 * 
	 * @param iMap
	 * @return
	 */
	private static Map<? extends Object, ? extends Object> kontaktMusteriYarat(GMMap iMap) {

		try {
			
			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI").trim());
			}

			GMMap kontakt = new GMMap();
			kontakt.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			kontakt.put("MUSTERI_KONTAKT", "K");
			kontakt.put("MUSTERI_TIPI_KOD", "G");
			kontakt.put("BAGLI_KANAL_GRUBU", iMap.getString("KANAL_KODU"));
			kontakt.put("KANAL_KODU", iMap.getString("KANAL_ALT_KODU"));
			kontakt.put("MUSTERI_SEGMENTI", "N");			
			kontakt.put("YERLESIM_KOD", "I");
			kontakt.put("DK_GRUP_KOD", new BigDecimal("1042"));
			kontakt.put("PROFIL_KOD", "1");
			// kontakt.put("BOLUM_KODU", new BigDecimal("444"));
			kontakt.put("KAZANIM_KANALI", iMap.getString("KANAL_KODU"));
			kontakt.put("KAZANIM_URUNU", "BRY"); // TODO Review
			kontakt.put("HESAP_UCRETI_F", "H");
			kontakt.put("YATIRIM_EKSTRESI", "H");
			kontakt.put("MUSTERI_GRUP_KOD", "6"); // TODO PTT'den Maas Alan Emekliler
			kontakt.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD"));
			kontakt.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", kontakt.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));
			kontakt.put("MUSTERIYI_KAZANDIRAN", "7" /*GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANICI_KOD", iMap).get("KULLANICI_KOD")*/); // TODO Review
			kontakt.put("TCKNO_IN", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("TC_KIMLIK_NO", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("ISIM", iMap.getString("ISIM"));
			kontakt.put("IKINCI_ISIM", iMap.getString("IKINCI_ISIM"));
			kontakt.put("SOYADI", iMap.getString("SOYADI"));
			kontakt.put("KISA_AD", iMap.getString("ISIM") + " " + (iMap.getString("IKINCI_ISIM") == null ? "" : iMap.getString("IKINCI_ISIM") + " ") + iMap.getString("SOYADI"));
			kontakt.put("UYRUK_KOD", "TR");
			kontakt.put("DOGUM_TARIHI", !"".equals(iMap.getString("DOGUM_TARIHI")) ? iMap.getDate("DOGUM_TARIHI") : null);
			kontakt.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
			kontakt.put("BABA_ADI", iMap.getString("BABA_ADI"));
			kontakt.put("ANNE_ADI", iMap.getString("ANNE_ADI"));
			kontakt.put("CINSIYET_KOD", iMap.getString("CINSIYET_KOD"));
			kontakt.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			kontakt.put("MEDENI_HAL_KOD", iMap.getString("MEDENI_HAL_KOD"));
			kontakt.put("AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
			kontakt.put("CILT_NO", iMap.getString("CILT_NO"));
			kontakt.put("SIRA_NO", iMap.getString("SIRA_NO"));
			kontakt.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("NUFUS_CUZDANI_SERI_NO"));
			kontakt.put("KIZLIK_SOYADI", iMap.getString("KIZLIK_SOYADI"));
			kontakt.put("MESLEK_KOD", iMap.getString("MESLEK_KOD"));
			kontakt.put("EGITIM_KOD", iMap.getString("EGITIM_KOD"));
			kontakt.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			kontakt.put("F_ISTEGE_BAGLI_SIGORTALI", iMap.getString("SIGORTALI_MI"));
			kontakt.put("UNVAN_KOD", iMap.getString("UNVANI"));
			kontakt.put("IL_KOD", iMap.getString("IL_KOD"));
			kontakt.put("ILCE_KOD", iMap.getString("ILCE_KOD"));
			kontakt.put("MAHALLE_KOY", iMap.getString("MAHALLE_KOY"));
			kontakt.put("ADRES_NO", iMap.getBigDecimal("ADRES_NO"));
			kontakt.put("BUCAK", iMap.getString("BUCAK"));
			kontakt.put("BUCAK_KOD", iMap.getBigDecimal("BUCAK_KOD"));
			kontakt.put("CSBM", iMap.getString("CSBM"));
			kontakt.put("DIS_KAPI_NO", iMap.getString("DIS_KAPI_NO"));
			kontakt.put("IC_KAPI_NO", iMap.getString("IC_KAPI_NO"));
			kontakt.put("IL", iMap.getString("IL"));
			kontakt.put("ILCE", iMap.getString("ILCE"));
			kontakt.put("ILCE_KODU", iMap.getBigDecimal("ILCE_KODU"));
			kontakt.put("IL_KODU", iMap.getBigDecimal("IL_KODU"));
			kontakt.put("KOY", iMap.getString("KOY"));
			kontakt.put("KOY_KAYIT_NO", iMap.getBigDecimal("KOY_KAYIT_NO"));
			kontakt.put("KOY_KOD", iMap.getBigDecimal("KOY_KOD"));
			kontakt.put("MAHALLE", iMap.getString("MAHALLE"));
			kontakt.put("MAHALLE_KOD", iMap.getBigDecimal("MAHALLE_KOD"));
			kontakt.put("YABANCI_ADRES", iMap.getString("YABANCI_ADRES"));
			kontakt.put("YABANCI_SEHIR", iMap.getString("YABANCI_SEHIR"));
			kontakt.put("YABANCI_ULKE", iMap.getString("YABANCI_ULKE"));
			kontakt.put("YABANCI_ULKE_KOD", iMap.getString("YABANCI_ULKE_KOD"));
			kontakt.put("NUF_VERILIS_NEDENI", iMap.getString("NUF_VERILIS_NEDENI"));
			kontakt.put("VERILDIGI_YER", iMap.getString("VERILDIGI_YER"));
			kontakt.put("VERILDIGI_TARIH", !"".equals(iMap.getString("VERILDIGI_TARIH")) ? iMap.getDate("VERILDIGI_TARIH") : null);

			if (iMap.getString("NUFUS_CUZDANI_SERI_NO") != null && !iMap.getString("NUFUS_CUZDANI_SERI_NO").isEmpty()) {
				kontakt.put("F_NUF", "E");
			}
			
			if ("E".equals(iMap.getString("KPS_YAPILDI"))) {
				kontakt.put("TCKNO_OUT", iMap.getBigDecimal("TC_KIMLIK_NO"));
			}

			List<Map<String, Object>> adresList = new ArrayList<Map<String, Object>>();
			
			if (iMap.getString("EV_ADRES") != null && !iMap.getString("EV_ADRES").isEmpty()) {
				
				Map<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("ADRES_KOD", "E");
				rowData.put("ADRES", iMap.getString("EV_ADRES"));
				rowData.put("ADRES_IL_KOD", iMap.getString("EV_IL"));
				rowData.put("ADRES_ILCE_KOD", iMap.getString("EV_ILCE"));
				rowData.put("ULKE_KOD", "TR");
				rowData.put("POSTA_KOD", iMap.getString("EV_POSTA_KOD"));
				rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
				rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_EV")));
				
				adresList.add(rowData);
			}
			
			// TY-1198 - APS adresi de EV adresi seklinde eklenecek
			boolean ekstreAdresAps = false;
			if (iMap.get("ADRES_NO") == null) { // Eger inputtan yok ise txnoya gore aps bilgilerini getir.
				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_APS_INFO", iMap));
			}
			if (iMap.get("ADRES_NO") != null && !"0".equals(iMap.getString("ADRES_NO")) && iMap.get("YABANCI_ULKE_KOD") == null) { // yine gelmediyse eklenmeyecek.
				adresList.add(getAPSAddressObject(iMap));
				ekstreAdresAps = true;
			}
			if (ekstreAdresAps) {
				for (int row = 0; row < adresList.size(); row++) {
					Map<String, Object> adrMap = adresList.get(row);
					if ("E".equals(adrMap.get("ADRES_KOD")) || "I".equals(adrMap.get("ADRES_KOD"))) {
						adrMap.put("EXTRE_ADRES_KOD_F", "H");
					}
					adresList.set(row, adrMap);
				}
			}else{
				if(!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")){
					for (int row = 0; row < adresList.size(); row++) {
						Map<String, Object> adrMap = adresList.get(row);
						if ("E".equals(adrMap.get("ADRES_KOD"))) {
							adrMap.put("EXTRE_ADRES_KOD_F", "E");
						}
						adresList.set(row, adrMap);
					}
				}
			}
			kontakt.put("ADRES_LIST", adresList);

			List<Map<String, Object>> telefonList = new ArrayList<Map<String, Object>>();
			
			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				Map<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "1");
				rowData.put("ALAN_KOD", iMap.getString("EV_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("EV_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				if ("7".equals(iMap.getString("KANAL_KOD")) && !("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM"))))
					rowData.put("F_ILETISIM", "1");
				else if (iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty())
					rowData.put("F_ILETISIM", "1");
				else
					rowData.put("F_ILETISIM", "0");
				telefonList.add(rowData);
			}
			
			if (iMap.getString("CEP_TEL_NO") != null && !iMap.getString("CEP_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "3");
				rowData.put("ALAN_KOD", iMap.getString("CEP_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("CEP_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				if ("7".equals(iMap.getString("KANAL_KOD"))) {
					if ("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM")))
						rowData.put("F_ILETISIM", "1");
					else if (iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty())
						rowData.put("F_ILETISIM", "1");
					else
						rowData.put("F_ILETISIM", "0");
				}
				else
					rowData.put("F_ILETISIM", "1");
				telefonList.add(rowData);
			}
			kontakt.put("TELEFON_LIST", telefonList);
			kontakt.put("F_APS_TEYIT", "E".equals(iMap.getString("APS_YAPILDIMI")) ? "true" : "false");
			kontakt.put("VELI_VASI", iMap.get("VELI_VASI"));

			if (iMap.getString("EMAIL1") != null && iMap.getString("EMAIL2") != null && !iMap.getString("EMAIL1").isEmpty() && !iMap.getString("EMAIL2").isEmpty())
				kontakt.put("EMAIL_KISISEL", iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));

			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
			kontakt.put("F_CIFTE_VATANDAS", "R");
			kontakt.put("F_GREEN_CARD", "R");

			return GMServiceExecuter.execute("BNSPR_TRN10011_SAVE", kontakt);
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	/**
	 * 
	 * @param iMap
	 * @return
	 * @throws ParseException
	 */
	private static Map<String, Object> getAPSAddressObject(GMMap iMap) throws ParseException {
		
		Map<String, Object> rowData = new HashMap<String, Object>();
		String adres = "";
		rowData.put("ADRES_KOD", "A"); // A koduyla ekleniyor.
		
		if (!"0".equals(iMap.getString("ADRES_NO")) && iMap.getString("YABANCI_ULKE_KOD") == null) {
			if (iMap.get("BUCAK") != null && !iMap.getString("BUCAK").isEmpty())
				adres = iMap.getString("BUCAK") + " ";
			if (iMap.get("KOY") != null && !iMap.getString("KOY").isEmpty())
				adres += iMap.getString("KOY") + " ";
			if (iMap.get("MAHALLE") != null && !iMap.getString("MAHALLE").isEmpty())
				adres += iMap.getString("MAHALLE") + " ";
			if (iMap.get("CSBM") != null && !iMap.getString("CSBM").isEmpty())
				adres += iMap.getString("CSBM") + " ";
			if (iMap.get("DIS_KAPI_NO") != null && !iMap.getString("DIS_KAPI_NO").isEmpty())
				adres += "NO:" + iMap.getString("DIS_KAPI_NO") + " ";
			if (iMap.get("IC_KAPI_NO") != null && !iMap.getString("IC_KAPI_NO").isEmpty())
				adres += "DAIRE:" + iMap.getString("IC_KAPI_NO");
			rowData.put("ADRES", adres);
			rowData.put("ULKE_KOD", "TR");
			if (iMap.get("IL_KODU") != null) {
				String ilKodu = "";
				if (iMap.getString("IL_KODU").length() == 1)
					ilKodu = "00" + iMap.getString("IL_KODU");
				else if (iMap.getString("IL_KODU").length() == 2)
					ilKodu = "0" + iMap.getString("IL_KODU");
				else
					ilKodu = iMap.getString("IL_KODU");
				rowData.put("ADRES_IL_KOD", ilKodu);
			}
			rowData.put("ADRES_ILCE_KOD", iMap.getBigDecimal("ILCE_KODU"));
		}
		else {
			rowData.put("ADRES", iMap.getString("YABANCI_ADRES"));
			rowData.put("ULKE_KOD", "");
		}
		rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
		rowData.put("EXTRE_ADRES_KOD_F", "E");
		
		return rowData;
	}
}
