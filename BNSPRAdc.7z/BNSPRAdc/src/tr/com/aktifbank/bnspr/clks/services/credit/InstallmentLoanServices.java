package tr.com.aktifbank.bnspr.clks.services.credit;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.clks.util.ClksConstants.Response;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class InstallmentLoanServices {

	private static Logger logger = Logger.getLogger(InstallmentLoanServices.class);

	@GraymoundService("CLKS_PTT_KREDI_BASVURU_BILGI")
	public static GMMap pttKrediBasvuruBilgi(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			oMap = (GMMap) DALUtil.callOracleProcedure("{call pkg_ptt.bir_kredi_basvuru_bilgi(?,?,?,?)}", new Object[]{
				BnsprType.STRING, iMap.getString("MUSTERI_NO"), BnsprType.STRING, iMap.getString("TCKN"),
				BnsprType.STRING, iMap.getString("BASVURU_NO")}, new Object[]{BnsprType.REFCURSOR, "BASVURU_LISTESI"});

			if(oMap.size() == 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ",
					new GMMap().put("HATA_NO", "50009").put("P1", iMap.getBigDecimal("MUSTERI_NO")));
			}

		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_BASVURU_BILGI err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_CLKS_INSTALLMENT_LOAN_PAYMENT_CONTROL")
	public static GMMap paymentControl(GMMap iMap) {

		try {

			if(iMap.containsKey("TRX_NO")) {
				
				Session session = DAOSession.getSession("BNSPRDal");
				ClksHavaleGirisTx trx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("TRX_NO"));
			
				if(trx == null) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ",
						new GMMap().put("HATA_NO", 2839).put("P1", iMap.getString("TRX_NO")));
				}
				
				iMap.put("BASVURU_NO", trx.getBasvuruNo());
			}
			
			DALUtil.callOracleProcedure("{call pkg_trn2050.taksit_tahsilat_kontrol(?)}", new Object[]{BnsprType.NUMBER,
				iMap.getBigDecimal("BASVURU_NO")}, new Object[]{});

			return new GMMap().put("RESPONSE", Response.SUCCESS.getValue());

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_INSTALLMENT_LOAN_PAYMENT_CONTROL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_CLKS_INSTALLMENT_LOAN_PAY_OFF_CONTROL")
	public static GMMap erkenKapamaKontrol(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			String musteriBilgi = (String) DALUtil.callOracleFunction("{? = call PKG_PTT.ErkenKapamaKontrol(?,?)}",
				BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.NUMBER,
				iMap.getBigDecimal("TCNO"));
			if(musteriBilgi != null) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ",
					new GMMap().put("HATA_NO", 660)
						.put("P1", "Kredi Kulland�r�m� ile erken kapama ayn� g�n yap�lamaz."));
			}

			return oMap;
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_INSTALLMENT_LOAN_PAY_OFF_CONTROL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_CLKS_INSTALLMENT_LOAN_PAYMENT")
	public static GMMap pttKrediTaksitOdeme(GMMap iMap) {

		GMMap oMap = new GMMap(), taksitMap = new GMMap();

		boolean acik = false;
		boolean kismi = false;

		try {

			taksitMap.putAll(GMServiceExecuter.call("BNSPR_CLKS_INSTALLMENT_LOAN_INFO", iMap));

			int i = 0;

			for(; i < taksitMap.getSize("TAKSIT_BILGILERI")
				&& taksitMap.getDate("TAKSIT_BILGILERI", i, "TAKSIT_TARIH").before(
					DateUtils.truncate(new java.util.Date(), Calendar.DAY_OF_MONTH)); i++) {
				if("ACIK".equals(taksitMap.getString("TAKSIT_BILGILERI", i, "DURUM_KOD"))) {
					acik = true;
				}
				if("KISMI".equals(taksitMap.getString("TAKSIT_BILGILERI", i, "DURUM_KOD"))) {
					kismi = true;
				}
			}

			if(i > 0) { // e�er taksitler g�n�m�z�n �ncesinde ise gerekli kontroleri yap.
				if(!(acik || kismi)) { // ge�mi�te gecikmede ya da kismi i�lem yok ise k�sm� �demeye izin verme
					kismiTahsilatKontrol(iMap);
				}

				if(acik == false) {
					if(DateUtils.isSameDay(taksitMap.getDate("TAKSIT_BILGILERI", i - 1, "TAKSIT_TARIH"),
						new java.util.Date())) {
						kismiTahsilatKontrol(iMap);
					}
				}
			}

			oMap = (GMMap) DALUtil.callOracleProcedure(
				"{call PKG_PTT.bir_kredi_taksit_odeme(?,?,?,?,?,?,?,?,?)}",
				new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"), BnsprType.NUMBER,
					iMap.getBigDecimal("BASVURU_NO"), BnsprType.NUMBER, iMap.getBigDecimal("TUTAR"), BnsprType.STRING,
					iMap.getString("DOVIZKODU")}, new Object[]{BnsprType.REFCURSOR, "TAKSIT_BILGILERI",
					BnsprType.STRING, "DEKONT", BnsprType.STRING, "PTTCALISANMI", BnsprType.NUMBER,
					"ODENEN_TAKSIT_SAYISI", BnsprType.NUMBER, "TOPLAM_TAKSIT_SAYISI"});

			if(iMap.getBigDecimal("TUTAR").compareTo(oMap.getBigDecimal("TAKSIT_BILGILERI", 0, "ODENECEKTAKSITTUTARI")) != 0) {
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5721));
			}
			
			oMap.putAll((GMMap) DALUtil.callOracleProcedure("{call PKG_PTT.bir_kredi_taksit_maxtutar(?,?)}",
				new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")}, new Object[]{BnsprType.NUMBER,
					"ODENEBILECEK_MAX_TUTAR"}));

			return oMap;
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_INSTALLMENT_LOAN_PAYMENT err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_CLKS_INSTALLMENT_LOAN_PAY_OFF")
	public static GMMap pttKrediErkenKapama(GMMap iMap) {

		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT.bir_kredi_erken_kapama(?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.setString(4, iMap.getString("DOVIZKODU"));
			stmt.registerOutParameter(3, Types.NUMERIC);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.execute();
			
			oMap.put("tutar", (BigDecimal) stmt.getObject(3));
			oMap.put("DEKONT", (String) stmt.getObject(5));
			
			return oMap;
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_INSTALLMENT_LOAN_PAY_OFF err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_CLKS_INSTALLMENT_LOAN_INTERIM_PAYMENT")
	public static GMMap pttKrediAraOdemeRequest(GMMap iMap) {

		GMMap taksitMap = new GMMap();

		try {

			iMap.put("ISLEM_TURU", 2);

			GMMap taksiInfo = GMServiceExecuter.call("BNSPR_GET_TAKSIT_BILGILER", iMap);

			// taksitMap.putAll(GMServiceExecuter.call("BNSPR_GET_TAKSIT_BILGILER", iMap));
			taksitMap.put("TAKSIT_NO", taksiInfo.get("TAKSIT_NO"));
			taksitMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			taksitMap.put("REZERVASYON_KURU", 0.00000000);

			if(iMap.getBigDecimal("TUTAR").compareTo(taksiInfo.getBigDecimal("TAKSIT_TUTAR")) < 0) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "�denecek tutar minimum taksit tutar� kadar olmal�d�r");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			taksitMap.putAll(GMServiceExecuter.call("BNSPR_GET_GERI_ODEME_ARA_ODEME", taksitMap));
			taksitMap.put("KAP_GEC_ARA_FAIZI", taksitMap.get("ARA_ODEME_FAIZ"));
			taksitMap.put("KAP_GEC_ARA_FAIZI_KKDF", taksitMap.get("ARA_ODEME_FAIZ_KKDF"));
			taksitMap.put("KAP_GEC_ARA_FAIZI_BSMV", taksitMap.get("ARA_ODEME_FAIZ_BSMV"));

			BigDecimal taksitAnaPara = iMap.getBigDecimal("TUTAR");

			taksitAnaPara = taksitAnaPara.subtract(taksitMap.getBigDecimal("ARA_ODEME_FAIZ"))
				.subtract(taksitMap.getBigDecimal("ARA_ODEME_FAIZ_KKDF"))
				.subtract(taksitMap.getBigDecimal("ARA_ODEME_FAIZ_BSMV"));

			taksitMap.put("TAKSIT_ANAPARA", taksitAnaPara);

			Session session = DAOSession.getSession("BNSPRDal");
			BirKullandirim birKullandirim = (BirKullandirim) session.get(BirKullandirim.class,
				iMap.getBigDecimal("BASVURU_NO"), LockMode.UPGRADE_NOWAIT);

			BigDecimal musteridenAlinacakTutar = iMap.getBigDecimal("TUTAR");

			GMMap geriOdemeDetay = GMServiceExecuter.call("BNSPR_GET_GERI_ODEME_ERKEN_KAPAMA_DETAY", iMap);
			String ilkTaksitDurum = geriOdemeDetay.getString("ILK_TAKSIT_ODENDIMI");
			if(ilkTaksitDurum != null && ilkTaksitDurum.equalsIgnoreCase("H")) {

				musteridenAlinacakTutar = musteridenAlinacakTutar.subtract((geriOdemeDetay.getBigDecimal("FARK_FAIZI"))
					.add(geriOdemeDetay.getBigDecimal("FARK_FAIZI_KKDF")).add(
						geriOdemeDetay.getBigDecimal("FARK_FAIZI_BSMV")));
			}
			taksitMap.put("TAHSILAT_HESAP_NO", birKullandirim.getOtoVirmanHesap());
			taksitMap.put("TAHSILAT_DOVIZ_KODU", "TRY");
			taksitMap.put("DOVIZ_KODU", "TRY");
			taksitMap.put("KREDI_HESAP_NO", birKullandirim.getKrdHesapNo());
			taksitMap.put("TRX_NO",
				GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			taksitMap.put("ISLEM_TURU", 2);
			taksitMap.put("ODENECEK_TAKSIT_NO", taksitMap.get("TAKSIT_NO"));
			taksitMap.put("ODENECEK_TAKSIT_VADE", taksiInfo.get("TAKSIT_VADE"));

			taksitMap.put("TAHSILAT_TUTARI", iMap.get("TUTAR"));
			taksitMap.put("MUSTERIDEN_ALINACAK_TUTAR", musteridenAlinacakTutar);
			taksitMap.put("BAKIYE", DALUtil.callOneParameterFunction("{? = call abs(pkg_hesap.HesapBakiyeAl(?))}",
				Types.NUMERIC, birKullandirim.getKrdHesapNo()));
			taksitMap.put("ACIKLAMA", "Bireysel Ara �deme - "
				+ (String) GMContext.getCurrentContext().getSession().get("CHANNEL"));
			taksitMap.put("PTT_HAVALE_TX_NO", iMap.getBigDecimal("TRX_NO"));
			taksitMap.putAll(GMServiceExecuter.call("BNSPR_GET_ILK_TAKSIT_TARIH", iMap));
			GMServiceExecuter.call("BNSPR_TRN3133_SAVE", taksitMap);

			taksitMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));

			try {

				GMMap yeniPlan = GMServiceExecuter.call("BNSPR_QRY3137_GET_RECORD_FILL_LIST", taksitMap);
				GMMap eMap = new GMMap();

				@SuppressWarnings("unchecked")
				List<GMMap> aList = (ArrayList<GMMap>) yeniPlan.get("RESULTS");

				aList = aList == null ? new ArrayList<GMMap>() : aList;
				int i = 0;
				for(Iterator<GMMap> it = aList.iterator(); it.hasNext();) {
					eMap = new GMMap((Map<?, ?>) it.next());
					taksitMap.put("taksitBilgileri", i, "tarih", eMap.getString("OP_TAKSIT_TARIHI"));
					taksitMap.put("taksitBilgileri", i, "tutar", eMap.getString("OP_KALAN_TUTAR"));
					taksitMap.put("taksitBilgileri", i, "gecikmeTutari", "0");
					taksitMap.put("taksitBilgileri", i, "erkenTahsilatFaizIndirimi", "0");
					taksitMap.put("taksitBilgileri", i, "odenecekTaksitTutari", eMap.getString("OP_TAKSIT_TUTAR"));
					taksitMap.put("taksitBilgileri", i, "taksitSayisi", eMap.getString("OP_TAKSIT_NO"));
					i++;
				}
			} catch(Exception e) {
				logger
					.error("BNSPR_CLKS_INSTALLMENT_LOAN_INTERIM_PAYMENT > BNSPR_QRY3137_GET_RECORD_FILL_LIST err:", e);
			}

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_INSTALLMENT_LOAN_INTERIM_PAYMENT err:", e);
			throw ExceptionHandler.convertException(e);
		}
		return taksitMap;
	}

	@GraymoundService("BNSPR_CLKS_INSTALLMENT_LOAN_INFO")
	public static GMMap info(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			oMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_PTT.bir_kredi_taksit_bilgi(?,?)}", new Object[]{
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")}, new Object[]{BnsprType.REFCURSOR,
				"TAKSIT_BILGILERI"});

			return oMap;
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_INSTALLMENT_LOAN_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	private static GMMap kismiTahsilatKontrol(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			oMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_BASVURU_BILGI", iMap));

			int i = 0;
			for(; i < oMap.getSize("BASVURU_LISTESI"); i++) {
				if(iMap.getString("BASVURU_NO").equals(oMap.getString("BASVURU_LISTESI", i, "BASVURU_NO"))) {
					break;
				}
			}

			if(iMap.getBigDecimal("TUTAR").compareTo(oMap.getBigDecimal("BASVURU_LISTESI", i, "ODENECEK_TUTAR")) < 0) {
				iMap.put("HATA_NO", new BigDecimal(1587));
				iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
