package tr.com.aktifbank.bnspr.clks.util;

import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;


public class BnsprAdcUtil {


	public static Date getCalendarDate() {

		Calendar cal = Calendar.getInstance();
		
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		
		return cal.getTime();
	}

	public static String convertToStandartChars(String str) {
		try {
			str = str.replace('�', 'i'); // (char)305 
			str = str.replace('�', 'o'); // (char)246
			str = str.replace('�', 'u'); // (char)252
			str = str.replace('�', 'g'); // (char)287
			str = str.replace('�', 's'); // (char)251
			str = str.replace('�', 'c'); // (char)231
			str = str.replace('�', 'I');
			str = str.replace('�', 'O');
			str = str.replace('�', 'U');
			str = str.replace('�', 'G');
			str = str.replace('�', 'S');
			str = str.replace('�', 'C');
			return str;
		} catch (Exception e) {
			throw new com.graymound.util.GMRuntimeException(101, e.getMessage());
		}
	}

	public static <T> T nvl(T value, T defaultValue) {
		if (value instanceof String) {
			return StringUtils.isBlank((String) value) ? defaultValue : value;
		}

		return value == null ? defaultValue : value;
	}

	public static String maskName(String str) {

		String result = "";
		if (!(str == null || str.trim().length() == 0)) {
			String strlist[] = str.split(" ");

			if (strlist != null) {
				if (strlist.length > 1) {
					for (int i = 0; i < strlist.length; i++) {
						if (strlist[i] != null && strlist[i].length() > 1) {
							strlist[i] = strlist[i].charAt(0) + strlist[i].substring(1, strlist[i].length()).replaceAll(".", "\\*");
							result = result + " " + strlist[i];
						}
					}
				}
				else {
					result = strlist[0].charAt(0) + strlist[0].substring(1, strlist[0].length()).replaceAll(".", "\\*");
				}

			}
		}
		return result;

	}

	public static boolean matchStrings(String s1, String s2) {

		int ctr = 0;

		String[] parts = s1.split(" ");

		for (int i = 0; i < parts.length; i++) {

			if (StringUtils.containsIgnoreCase(s2, parts[i])) {
				ctr++;
			}
		}

		if (ctr >= 2 && StringUtils.upperCase(s2).endsWith(StringUtils.upperCase(parts[parts.length - 1]))) {
			return true;
		}
		else {
			return false;
		}
	}

	
	
}
