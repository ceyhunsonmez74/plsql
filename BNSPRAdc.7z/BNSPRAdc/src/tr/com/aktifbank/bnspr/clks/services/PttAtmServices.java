package tr.com.aktifbank.bnspr.clks.services;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCardPaymentDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCashDepositDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CardPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CashDeposit;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.CardPaymentProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.CashDepositProcess;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants.Transaction;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/**
 * Class PttAtmServices
 * 
 */
public class PttAtmServices {

	private static Logger logger = Logger.getLogger(PttAtmServices.class);
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_ATM_VALIDATE_ACCOUNT")
	public static GMMap pttAtmValidateAccount(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
		    // Case: Hesap/Iban Nakit Yatirma
		    if (iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_HESAP || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_IBAN) {
		    
				Object[] inputValues = new Object[] {
					BnsprType.STRING, iMap.getString("TCKN"),
					BnsprType.STRING, iMap.getString("CEP_TELEFON_NO"),
					BnsprType.STRING, iMap.getString("HESAP_NO"),
					BnsprType.NUMBER, iMap.getBigDecimal("ISLEM")
				};
				
				Object[] outputValues = new Object[] {
					BnsprType.NUMBER, "KASA_KIMLIK_TIPI",
					BnsprType.STRING, "HESAP_KART_SAHIBI_AD_SOYAD"
				};
			
				// Call procedure
				oMap = (GMMap)DALUtil.callOracleProcedure("{call PKG_PTT_ATM.WS_VALIDATE_ACCOUNT(?,?,?,?,?,?)}", inputValues, outputValues);
		    }
		    
		    // Case: EUPT Nakit Yatirma
		    else if(iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_EUPT) {
		    	
		    	// Validation: TCKN
		    	if (((Integer) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.TCKN_KONTROL(?)}", Types.INTEGER, iMap.getBigDecimal("TCKN"))) == 0) {
		    		iMap.put("HATA_NO", 3037);
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
		    	}
		    	
		    	try {
		    		oMap = GMServiceExecuter.call("BNSPR_EUPT_SEARCH_EUPT_USER", new GMMap().put("EUPT_ACCOUNT_NO", iMap.getString("HESAP_NO")));
		    	} 
		    	catch(Exception e) {
		    		iMap.put("HATA_NO", 3035);
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
		    	}
		    	
		    	// Case: 1. Sahis
		    	if(iMap.getString("TCKN").equals(oMap.getString("USER_LIST",0,"TCKN"))) {
		    		
		    		// Case: Tckn, Cep Telefonu, Eupt Hesap No uyumlu mu? 
			    	if(!"90".concat(iMap.getString("CEP_TELEFON_NO")).equals(oMap.getString("USER_LIST",0,"MOBILE"))) {
			    		iMap.put("HATA_NO", 3037);
						GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			    	}
		    		
		    		oMap.put("KASA_KIMLIK_TIPI", 1);
		    	} 
		    	// Case: 3. Sahis
		    	else {
		    		oMap.put("KASA_KIMLIK_TIPI", 4);
		    	}
		    	
		    	oMap.put("NAME", StringUtils.rightPad(oMap.getString("USER_LIST",0,"NAME").substring(0,2), oMap.getString("USER_LIST",0,"NAME").length(), "*"));
		    	oMap.put("SURNAME", StringUtils.rightPad(oMap.getString("USER_LIST",0,"SURNAME").substring(0,2), oMap.getString("USER_LIST",0,"SURNAME").length(), "*"));
	    		oMap.put("HESAP_KART_SAHIBI_AD_SOYAD", oMap.getString("NAME").concat(" ").concat(oMap.getString("SURNAME")));
	    		
		    }
		    
		    // Case: Kart No ile Passolig Kart, N Kolay Kart Nakit Yatirma
		    else if (iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KART
		    	|| iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_NKOLAY_KART){
		    	
		    	// Validation: TC Kimlik
		    	if(GMServiceExecuter.call("BNSPR_COMMON_TCKN_CHECK_DIGIT", new GMMap().put("TC_KIMLIK_NO", iMap.getString("TCKN"))).getInt("SONUC") == 0) {
		    		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3037));
		    	}
		    	
		    	iMap.put("CARD_NO", iMap.getString("HESAP_NO"));
		    	iMap.put("CARD_DCI", "A");
		    	iMap.remove("TCKN");
		    	oMap.putAll(GMServiceExecuter.call("CLKS_TFF_CARD_INFO", iMap));
				oMap.put("HESAP_KART_SAHIBI_AD_SOYAD", oMap.getString("UNVAN"));
				
				String cardGroup = CLKSCommonServices.getCardGroup(oMap.getString("CARD_GROUP"));
				
				// Validation: PassoLig Kart Sorgusu, N Kolay Kart
		    	if(ClksConstants.BRAND_CARD_NKOLAY.equals(cardGroup) && ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KART == iMap.getInt("ISLEM")) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
		    	
		    	// Validation: N Kolay Kart Sorgusu, PassoLig Kart
		    	else if(ClksConstants.BRAND_CARD_PASSOLIG.equals(cardGroup) && ClksConstants.ISLEM_ATM_TOPUP_NKOLAY_KART == iMap.getInt("ISLEM")) {
		    		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
		    }
		    
		    // Case: Kimlik ile Passolig Kart Nakit Yatirma
		    else if(iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KIMLIK) {

		    	// Validation: TC Kimlik
		    	if(GMServiceExecuter.call("BNSPR_COMMON_TCKN_CHECK_DIGIT", new GMMap().put("TC_KIMLIK_NO", iMap.getString("TCKN"))).getInt("SONUC") == 0) {
		    		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3037));
		    	}
		    	
		    	GMMap tMap = GMServiceExecuter.call("CLKS_PTT_ATM_TFF_CARD_LIST", iMap);
		    	String cardGroup;
		    	int i = 0;
		    	
		    	for(int index = 0; index < tMap.getSize("CARD_DETAIL_INFO"); index++) {
			    	
		    		cardGroup = CLKSCommonServices.getCardGroup(tMap.getString("CARD_DETAIL_INFO", index, "CARD_GROUP"));
		    		
		    		if(ClksConstants.BRAND_CARD_PASSOLIG.equals(cardGroup)) {
            			oMap.put("CARD_DETAIL_INFO", i, "CARD_PRODUCT_NAME", tMap.get("CARD_DETAIL_INFO", index, "CARD_PRODUCT_NAME"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "PRODUCT_ID", tMap.get("CARD_DETAIL_INFO", index, "PRODUCT_ID"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "LOGO_CODE", tMap.get("CARD_DETAIL_INFO", index, "LOGO_CODE"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "CARD_NO", tMap.get("CARD_DETAIL_INFO", index, "CARD_NO"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "SYSTEM", tMap.get("CARD_DETAIL_INFO", index, "SYSTEM"));
    		    		oMap.put("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT", tMap.get("CARD_DETAIL_INFO", index, "CARD_AVAIL_LIMIT"));
    		    		i++;
            		}
		    		

		    	}
		    	
	    		// Case: Donebilecek durumda kart/basvuru yoksa
	    		if(oMap.getSize("CARD_DETAIL_INFO") == 0) {
	    			iMap.put("HATA_NO", 3218);
	    			GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	    		}
		    	
		    	oMap.put("HESAP_KART_SAHIBI_AD_SOYAD", tMap.getString("HESAP_KART_SAHIBI_AD_SOYAD"));
		    }
		}
		catch(Exception e) {
			logger.error("CLKS_PTT_ATM_VALIDATE_ACCOUNT err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_ATM_TRANSFER_REQUEST")
	public static GMMap pttAtmTransferRequest(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String trxName = Transaction.ATM_NAKIT_YATAN.toString();
		
		try {
		    
			// Case: Kart No ile Passolig Kart, N Kolay Kart Nakit Yatirma
		    if (iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KART || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_NKOLAY_KART) {
		    	
		    	if(iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KART) {
		    		trxName = Transaction.ATM_KART_PASSO.toString();
		    	} else {
		    		trxName = Transaction.ATM_KART_NKOLAY.toString();
		    	}
		    	
		    	// Validation: TC Kimlik
		    	if(GMServiceExecuter.call("BNSPR_COMMON_TCKN_CHECK_DIGIT", new GMMap().put("TC_KIMLIK_NO", iMap.getString("TCKN"))).getInt("SONUC") == 0) {
		    		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3037));
		    	}
		    	
		    	GMMap outMap = new GMMap();
		    	outMap.putAll(GMServiceExecuter.call("CLKS_TFF_CARD_INFO", new GMMap()
		    		.put("CARD_NO", iMap.getString("HESAP_NO"))
		    		.put("CARD_DCI", "A")));
		    	
				iMap.put("HESAP_KART_SAHIBI_AD_SOYAD", outMap.getString("UNVAN"));
				iMap.put("PRODUCT_ID", outMap.getString("PRODUCT_ID"));
				iMap.put("LOGO_CODE", outMap.getString("LOGO_CODE"));
				iMap.put("SYSTEM", outMap.getString("SYSTEM"));
				iMap.put("AB_MUSTERI_NO", outMap.getBigDecimal("MUSTERI_NO"));
				iMap.put("CARD_NO", iMap.getString("HESAP_NO"));
				iMap.put("DCI", outMap.getString("DCI"));
				iMap.put("ALICI_HESAP_NO", outMap.get("ALICI_HESAP_NO"));
				iMap.put("CARD_GROUP", outMap.get("CARD_GROUP"));
				
				String cardGroup = CLKSCommonServices.getCardGroup(iMap.getString("CARD_GROUP"));
				
				// Validation: PassoLig Kart Sorgusu, N Kolay Kart
		    	if(ClksConstants.BRAND_CARD_NKOLAY.equals(cardGroup) && ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KART == iMap.getInt("ISLEM")) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
		    	
		    	// Validation: N Kolay Kart Sorgusu, PassoLig Kart
		    	else if(ClksConstants.BRAND_CARD_PASSOLIG.equals(cardGroup) && ClksConstants.ISLEM_ATM_TOPUP_NKOLAY_KART == iMap.getInt("ISLEM")) {
		    		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
				
				if(iMap.getString("TCKN").equals(outMap.getString("TCKN"))) {
					iMap.put("KASA_KIMLIK_TIPI", 1);
				} else {
					iMap.put("KASA_KIMLIK_TIPI", 4);
		    	}
				
		    }
		    
			// Case: Kimlik ile Passolig Kart Nakit Yatirma
		    else if(iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KIMLIK) {
		    	
		    	trxName = Transaction.ATM_KART_PASSO.toString();
		    	
		    	// Validation: TC Kimlik
		    	if(GMServiceExecuter.call("BNSPR_COMMON_TCKN_CHECK_DIGIT", new GMMap().put("TC_KIMLIK_NO", iMap.getString("TCKN"))).getInt("SONUC") == 0) {
		    		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3037));
		    	} 
		    	
		    	GMMap tMap = new GMMap();
		    	tMap.put("SELECTED_CARD_NO", iMap.getString("CARD_NO"));
		    	tMap.put("TCKN", iMap.getString("TCKN"));
		    	tMap.put("HESAP_NO", iMap.getString("HESAP_NO"));
		    	
		    	iMap.putAll(GMServiceExecuter.call("CLKS_PTT_ATM_TFF_CARD_LIST", tMap));

		    	String cardGroup = CLKSCommonServices.getCardGroup(iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "CARD_GROUP"));
		    	
		    	// Validation: PassoLig Kart Sorgusu, N Kolay Kart
		    	if(ClksConstants.BRAND_CARD_NKOLAY.equals(cardGroup)) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3218));
		    	}
		    	
		    	iMap.put("EUPT_HESAP_NO", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "EUPT_ACCOUNT_NO"));
		    	iMap.put("DCI", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "CARD_DCI_AKUSTIK"));
		    	iMap.put("CARD_GROUP", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "CARD_GROUP"));
		    	iMap.put("CARD_NO", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "CARD_NO"));
		    	
		    	// Case: Basvuru
		    	if ("B".equals(iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "SYSTEM"))) {
					iMap.put("AB_MUSTERI_NO", iMap.getBigDecimal("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "CUSTOMER_NO"));
		    	}
		    	
		    	// Case: Diger
		    	else {
		    		iMap.put("ALICI_MUSTERI_NO", iMap.getBigDecimal("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "CUSTOMER_NO"));
		    		
		    		if(OceanConstants.Akustik_DebitCard.equals(iMap.getString("DCI"))) {
						
						GMMap cardInfoMap = new GMMap();
						cardInfoMap.put("CARD_NO", iMap.get("CARD_NO"));
						cardInfoMap.put("CARD_DCI", OceanConstants.Akustik_DebitCard);
						
						if(OceanConstants.Card_Source_Ocean.equals(iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "SYSTEM"))) {
							cardInfoMap = GMServiceExecuter.call("BNSPR_OCEAN_GET_CARD_INFO", cardInfoMap);
						} else if (OceanConstants.Card_Source_Intracard.equals(iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "SYSTEM"))) {
							cardInfoMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_INFO", cardInfoMap);
						}
						
						// TODO: GMService
						iMap.put("ALICI_HESAP_NO", CLKSServices.getDebitAccountNo(cardInfoMap));
					}
		    	}
		    	iMap.put("KASA_KIMLIK_TIPI", 1);
		    	
		    	oMap.put("CARD_PRODUCT_NAME", iMap.getString("CARD_DETAIL_INFO", iMap.getInt("SELECTED_CARD_INDEX"), "CARD_PRODUCT_NAME"));
		    }
			
			Object[] inputValues = new Object[] {
				BnsprType.STRING, iMap.getString("TCKN"),
				BnsprType.STRING, iMap.getString("CEP_TELEFON_NO"),
				BnsprType.STRING, iMap.getString("HESAP_NO"),
				BnsprType.NUMBER, iMap.getBigDecimal("TUTAR"),
				BnsprType.NUMBER, iMap.getBigDecimal("ISLEM"),
				BnsprType.STRING, trxName,
				BnsprType.NUMBER, iMap.containsKey("KASA_KIMLIK_TIPI") ? iMap.getBigDecimal("KASA_KIMLIK_TIPI") : null,
				BnsprType.NUMBER, iMap.containsKey("AB_MUSTERI_NO") ? iMap.getBigDecimal("AB_MUSTERI_NO") : null,
				BnsprType.NUMBER, iMap.containsKey("EUPT_HESAP_NO") ? iMap.getBigDecimal("EUPT_HESAP_NO") : null,
				BnsprType.STRING, iMap.containsKey("CARD_NO") ? iMap.getString("CARD_NO") : null,
				BnsprType.STRING, iMap.containsKey("BASVURU_NO") ? iMap.getString("BASVURU_NO") : null,
				BnsprType.STRING, iMap.containsKey("LOGO_CODE") ? iMap.getString("LOGO_CODE") : null,
				BnsprType.STRING, iMap.containsKey("PRODUCT_ID") ? iMap.getString("PRODUCT_ID") : null,
				BnsprType.STRING, iMap.containsKey("SYSTEM") ? iMap.getString("SYSTEM") : null,
				BnsprType.STRING, iMap.containsKey("DCI") ? iMap.getString("DCI") : null,
				BnsprType.STRING, iMap.containsKey("CARD_GROUP") ? iMap.getString("CARD_GROUP") : null
			};
			
			Object[] outputValues = new Object[] {
				BnsprType.STRING, "HESAP_KART_SAHIBI_AD_SOYAD",
				BnsprType.NUMBER, "BANKA_ISLEM_NO",
				BnsprType.NUMBER, "MASRAF_TUTAR",
				BnsprType.STRING, "MASRAF_DOVIZ_KODU",
				BnsprType.NUMBER, "KASA_KIMLIK_TIPI"
			};
			
			// Call procedure
			oMap.putAll((GMMap)DALUtil.callOracleProcedure("{call PKG_PTT_ATM.WS_TRANSFER_REQUEST(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}", inputValues, outputValues));

			// EUPT, PassoLig Kart Nakit Yatirma
			if(iMap.containsKey("HESAP_KART_SAHIBI_AD_SOYAD")) {
				oMap.put("HESAP_KART_SAHIBI_AD_SOYAD", iMap.getString("HESAP_KART_SAHIBI_AD_SOYAD"));
			}
			
			if(iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_EUPT || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_HESAP || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_IBAN) {
				String musteriNo = (String) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.Musteri_Varmi_TCKN(?)}", Types.VARCHAR, iMap.getString("TCKN"));
				
				// Case: Islemi yapan Musteri/Kontakt mevcut degil
				if(musteriNo == null) {
					
					try {
						
						DateFormat df = new SimpleDateFormat("ddMMyyyy");
						
						// KPS
						iMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));
						GMMap kpsMap = GMServiceExecuter.call("BNSPR_GET_KPS_BILGISI", iMap);                           
						kpsMap.put("KAZANIM_KANALI", "7");
						kpsMap.put("UYRUK_KOD", "TR");
						kpsMap.put("DOGUM_TARIHI", new java.sql.Date(df.parse(kpsMap.getString("DOGUM_TARIHI").replace("/", "")).getTime()));
						if(kpsMap.getString("VERILIS_TARIHI") != null && kpsMap.getString("VERILIS_TARIHI").length() != 0) {
							kpsMap.put("VERILIS_TARIHI", new java.sql.Date(df.parse(kpsMap.getString("VERILIS_TARIHI").replace("/", "")).getTime()));
						} else {
							 kpsMap.remove("VERILIS_TARIHI");
						}
						
						// Islemi yapan kontrolleri
						GMServiceExecuter.call("CLKS_PTT_ATM_ACCOUNT_DEPOSITOR_CONTROL", kpsMap.put("ISLEM", iMap.getInt("ISLEM")));
						
						kpsMap.remove("OLUM_TARIHI");
						iMap.put("ISLEMI_YAPAN_ADSOYAD", kpsMap.getString("ISIM").concat(" ").concat(kpsMap.getString("SOYADI")));
						
	                 	// Kontakt Musteri Olustur
	                    GMServiceExecuter.call("BNSPR_CUST_CREATE_GERCEK_MUSTERI", kpsMap);
					}
					
					// Kontakt Musteri Olusturamazsak Hata Donmeyelim
					catch(Exception e) {
						e.printStackTrace();
						if("3057".equals(e.getMessage().substring(2,6)) ||
						   "3058".equals(e.getMessage().substring(2,6)) ||
						   e.getMessage().startsWith("TCKN") ||
						   e.getMessage().startsWith("18")) {
							
							throw ExceptionHandler.convertException(e);
						}
					}
				} 
				
				// Case: Musteri/Kontakt
				else {
					
					Date dogumTarihi = (Date) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.dogum_tarihi(?)}", Types.DATE, musteriNo);
					Date vefatTarihi = (Date) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.olum_tarihi(?)}", Types.DATE, musteriNo);
					
					// Islemi yapan kontrolleri
					GMServiceExecuter.call("CLKS_PTT_ATM_ACCOUNT_DEPOSITOR_CONTROL", new GMMap().put("DOGUM_TARIHI", dogumTarihi).put("OLUM_TARIHI", vefatTarihi).put("ISLEM", iMap.getInt("ISLEM")));
	
					iMap.put("ISLEMI_YAPAN_ADSOYAD", (String) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.unvan(?)}", Types.VARCHAR, musteriNo));
				}
			}
			
			if(oMap.getInt("KASA_KIMLIK_TIPI") == 1 && iMap.containsKey("ISLEMI_YAPAN_ADSOYAD")) {
				iMap.remove("ISLEMI_YAPAN_ADSOYAD");
			}
			
			// Set misc. parameters
			if (iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_HESAP || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_IBAN) {
				try {
					iMap.put("ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "CLKS_ATM_ACIKLAMA_MAPPING").put("KEY", iMap.getString("ACIKLAMA"))).getString("TEXT"));
				} catch(Exception e) { }
			} else {
				iMap.put("ACIKLAMA", "");
			}
			iMap.put("BANKA_ISLEM_NO", oMap.getBigDecimal("BANKA_ISLEM_NO"));
			iMap.put("ISLEMI_YAPAN_TCKN", iMap.getString("TCKN"));
			iMap.put("ISLEMI_YAPAN_TELNO", iMap.getString("CEP_TELEFON_NO"));
			oMap.put("MASRAF_TUTAR", oMap.getBigDecimal("MASRAF_TUTAR").setScale(2,BigDecimal.ROUND_HALF_UP));
			iMap.put("MASRAF_TUTAR", oMap.get("MASRAF_TUTAR"));
			
			if(iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KIMLIK || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KART || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_NKOLAY_KART) {
				
				// Case: Credit, Prepaid
				if(!OceanConstants.Card_Source_Application.equals(iMap.getString("SYSTEM")) && !OceanConstants.Akustik_DebitCard.equals(iMap.getString("DCI")) && !OceanConstants.Akustik_Basvuru_DebitCard.equals(iMap.getString("DCI"))) {
					
					GMMap txnFeeMap = GMServiceExecuter.call("BNSPR_GET_TXN_FEE_PROFILE_INFO", new GMMap()
						.put("CARD_NO", iMap.getString("CARD_NO"))
						.put("TERMINAL", "ATM"));
					
					iMap.put("MASRAF_TUTAR", BigDecimal.ZERO);
					if(txnFeeMap.getSize("PROFILE_LIST") > 0) {
						iMap.put("MASRAF_TUTAR", iMap.getBigDecimal("TUTAR").multiply(txnFeeMap.getBigDecimal("PROFILE_LIST", 0, "FEE_RATE")).add(txnFeeMap.getBigDecimal("PROFILE_LIST", 0, "FLAT_FEE_AMOUNT")));
					}
					oMap.put("MASRAF_TUTAR", iMap.get("MASRAF_TUTAR"));
				}
				GMMap pMap = new GMMap();
		  		pMap.put("KOD", "EUTS_KART_NUMARALARI");
			  	pMap.put("KEY", iMap.getString("CARD_NO"));
			  	pMap = GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI",pMap);
			  	if ("E".equals(pMap.getString("IS_EXIST"))){
			  		iMap.put("MASRAF_TUTAR",0);
			  	}
			}
			
			// Case: Masraf, Tutardan fazla ise
			if(iMap.getBigDecimal("TUTAR").subtract(iMap.getBigDecimal("MASRAF_TUTAR")).compareTo(BigDecimal.ONE) < 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1458));
			}
			
			// Update
			oMap.putAll(GMServiceExecuter.call("CLKS_PTT_ATM_SAVE", iMap));
			
			// Send Transaction
			iMap.put("TRX_NO", oMap.getBigDecimal("BANKA_ISLEM_NO"));
			iMap.put("TRX_NAME", trxName.equals(Transaction.ATM_KART_NKOLAY.toString()) ? Transaction.ATM_KART_PASSO.toString() : trxName);
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}
		catch(Exception e) {

			logger.error("CLKS_PTT_ATM_TRANSFER_REQUEST err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_ATM_TRANSFER_CONFIRM")
	public static GMMap pttAtmTransferConfirm(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		iMap.put("BOUNDARY", true);
		
		try {
			
			oMap = (GMMap)DALUtil.callOracleRefCursorFunction("{? = call  PKG_PTT_ATM.ISLEM_DETAY(?)}", "ISLEM_DETAY", new Object[] {BnsprType.NUMBER, iMap.getBigDecimal("BANKA_ISLEM_NO")});
			
			// Update
			GMServiceExecuter.call("CLKS_PTT_ATM_SAVE", iMap);
			
			// Case: 3. Sahis Islemi
			if(new BigDecimal(4).equals(oMap.getBigDecimal("ISLEM_DETAY", 0, "KASA_KIMLIK_TIPI"))) {
				DALUtil.callOneParameterFunction("{? = call  PKG_PTT_ATM.Q2022_KAYIT_AT(?)}", Types.NUMERIC, iMap.getBigDecimal("BANKA_ISLEM_NO"));
			}
			
			// Case: TFF Kart (2048 Ortak)
			if(Transaction.ATM_KART_PASSO.toString().equals(oMap.getString("ISLEM_DETAY", 0, "ISLEM_KOD"))) {
				
				TransactionDao<CardPayment> dao = new DalCardPaymentDao();
				CardPayment cardPayment = dao.get(iMap.getBigDecimal("BANKA_ISLEM_NO"));
				TransactionProcess<CardPayment> process = new CardPaymentProcess(dao);
				process.confirm(cardPayment);
				
				iMap.put("OPERATION_TYPE", "");
				iMap.put("TX_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
				
				try {
					GMServiceExecuter.call("BNSPR_DO_TRANSFER_TO_TFF", iMap);
				} catch(Exception e) {
					throw e;
				} finally {
					iMap.put("BOUNDARY", false);
				}
			} else {
				TransactionDao<CashDeposit> dao = new DalCashDepositDao();
				CashDeposit cashDeposit = dao.get(iMap.getBigDecimal("BANKA_ISLEM_NO"));
				TransactionProcess<CashDeposit> process = new CashDepositProcess(dao);
				process.confirm(cashDeposit);
			}
			
			// Transaction Confirmation
			iMap.put("ISLEM_TURU", "O");
			iMap.put("ISLEM_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
			iMap.put("ISLEM_KODU", oMap.getString("ISLEM_DETAY", 0, "ISLEM_KOD"));
			oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap));
		}
		catch(Exception e) {
			
			logger.error("CLKS_PTT_ATM_TRANSFER_CONFIRM err: " + e);
			
			if(!iMap.getBoolean("BOUNDARY")) {
				try {
					GMMap sMap = new GMMap();
					sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
					sMap.put("ORGINAL_EXTERNAL_TRX_ID", iMap.getBigDecimal("BANKA_ISLEM_NO"));
					sMap.put("EXTERNAL_TRX_ID", sMap.getBigDecimal("TRX_NO"));
					sMap.put("OPERATION_TYPE", "R");
					GMServiceExecuter.call("BNSPR_DO_TRANSFER_TO_TFF", sMap);
				} catch(Exception e1) { 
					logger.error("CLKS_PTT_ATM_TRANSFER_CONFIRM - BOUNDARY err: " + e);
				}
			}
			
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_ATM_SAVE")
	public static GMMap pttAtmSave(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx)session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("BANKA_ISLEM_NO"));
			
			if(clksHavaleGirisTx == null) {
				clksHavaleGirisTx = new ClksHavaleGirisTx();
			}
			
			if("REQUEST".equals(iMap.getString("SAVE"))) {
				clksHavaleGirisTx.setAciklama(iMap.getString("ACIKLAMA"));
				clksHavaleGirisTx.setIslem(iMap.getBigDecimal("ISLEM"));
				if(iMap.containsKey("ALICI_MUSTERI_NO")) { clksHavaleGirisTx.setAliciMusteriNo(iMap.getBigDecimal("ALICI_MUSTERI_NO")); }
				clksHavaleGirisTx.setIslemiYapanTckno(iMap.getString("ISLEMI_YAPAN_TCKN"));
				if(iMap.containsKey("KASA_KIMLIK_TIPI") && iMap.getInt("KASA_KIMLIK_TIPI") == 1) { clksHavaleGirisTx.setTcKimlikNo(iMap.getString("ISLEMI_YAPAN_TCKN")); }
				clksHavaleGirisTx.setIslemiYapanAdsoyad(iMap.getString("ISLEMI_YAPAN_ADSOYAD"));
				clksHavaleGirisTx.setIslemiYapanTelno(iMap.getString("ISLEMI_YAPAN_TELNO"));
				clksHavaleGirisTx.setIslemiYapanKullanici(iMap.getString("ISLEMIN_YAPILDIGI_ATM"));
				clksHavaleGirisTx.setIsleminYapildigiYer(iMap.getString("ISLEMIN_YAPILDIGI_YER"));
				clksHavaleGirisTx.setIsleminYapildigiIl(iMap.getString("ISLEMIN_YAPILDIGI_IL"));
				clksHavaleGirisTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
				clksHavaleGirisTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
				clksHavaleGirisTx.setIsleminYapildigiBasmudurluk(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				clksHavaleGirisTx.setMerkezSubeBasmudurluk(iMap.getString("MERKEZ_SUBE_BASMUDURLUK"));
				if(iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KIMLIK || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_PASSOLIG_KART || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_TOPUP_NKOLAY_KART) {
					clksHavaleGirisTx.setAliciHesapNo(iMap.get("ALICI_HESAP_NO") == null ? null : iMap.getBigDecimal("ALICI_HESAP_NO"));
				}
				clksHavaleGirisTx.setMasrafTutari(iMap.getBigDecimal("MASRAF_TUTAR"));
			}
			
			else if("CONFIRM".equals(iMap.getString("SAVE"))) {
				clksHavaleGirisTx.setPttIslemNo((iMap.getBigDecimal("PTT_ISLEM_NO")));
			}
			
			session.saveOrUpdate(clksHavaleGirisTx);
			session.flush();
		}
		
		catch(Exception e) {

			logger.error("CLKS_PTT_ATM_SAVE err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_ATM_ACCOUNT_DEPOSITOR_CONTROL")
	public static GMMap pttAtmAccountDepositorControl(GMMap iMap) {
		
		// Case: Vefat
		if(iMap.containsKey("OLUM_TARIHI") && iMap.getString("OLUM_TARIHI") != null && iMap.getString("OLUM_TARIHI").length() != 0) {
			iMap.put("HATA_NO", 3057);
			GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
		}

		// Case: 18 Yas - Hesaba/IBAN'a gonderimlerde
		Calendar today = Calendar.getInstance();
		Calendar cal = Calendar.getInstance();
		try {
			cal.setTimeInMillis(iMap.getDate("DOGUM_TARIHI").getTime());
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		if((iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_HESAP || iMap.getInt("ISLEM") == ClksConstants.ISLEM_ATM_NY_IBAN) &&
				((today.get(Calendar.YEAR) - cal.get(Calendar.YEAR) < 18) || 
				(today.get(Calendar.YEAR) - cal.get(Calendar.YEAR) == 18 &&
				today.get(Calendar.MONTH) - cal.get(Calendar.MONTH) <= 0 &&
				today.get(Calendar.DATE) - cal.get(Calendar.DATE) < 0))) {
			iMap.put("HATA_NO", 3058);
			GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		
		return new GMMap();
	}
	
	@GraymoundService ("CLKS_PTT_ATM_TFF_CARD_LIST")
	public static GMMap pttAtmGetTffCardList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		iMap.put("MASK_CC_NO", "N");
		iMap.put("CARD_BANK_STATUS_CC", "All");
		
		// Case: TC Uyruk
		if(iMap.getString("TCKN") != null && !("".equals(iMap.getString("TCKN")))) {
			
			iMap.put("INPUT_PARAMETER_TYPE", "TCKN");
			
			// Validation: TCKN
	    	if (((Integer) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.TCKN_KONTROL(?)}", Types.INTEGER, iMap.getBigDecimal("TCKN"))) == 0) {
	    		iMap.put("HATA_NO", 2618);
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	    	}
    	}
		
		// Case: TCKN null geldigi durumda hata donelim
		else{
            iMap.put("HATA_NO" , 3284);
            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ" , iMap);
        }
    	
    	GMMap tMap = new GMMap();
    	tMap.putAll(GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARDS_VIA_TCKN", iMap));
    	
    	if(tMap.containsKey("CARD_DETAIL_INFO") && tMap.getSize("CARD_DETAIL_INFO") > 0) {
    		
    		oMap.put("HESAP_KART_SAHIBI_AD_SOYAD", tMap.getString("CARD_DETAIL_INFO", 0, "NAME"));
    		
    		int i = 0;
    		int index = 0;
    		for(index = 0; index < tMap.getSize("CARD_DETAIL_INFO"); index++) {
    			
    			// Case: Kredi kartlari kimlik ile listelenmeyecek
    			if(!OceanConstants.Akustik_CreditCard.equals(tMap.getString("CARD_DETAIL_INFO", index, "CARD_DCI_AKUSTIK"))) {
    				
    				GMMap hceMap = new GMMap();
    				hceMap.put("PRODUCT_ID", tMap.getString("CARD_DETAIL_INFO", index, "PRODUCT_ID"));
    				hceMap.put("PRODUCT_SUB_TYPE", "IN:ONLINE,OFFLINE");

    				Boolean isHCEKart= "Y".equals(GMServiceExecuter.call("BNSPR_IS_HCE_PRODUCT", hceMap).getString("IS_HCE")) ;

    				if (!isHCEKart) {
    					oMap.put("CARD_DETAIL_INFO", i, tMap.getMap("CARD_DETAIL_INFO", index));
    					oMap.put("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT", oMap.getBigDecimal("CARD_DETAIL_INFO", i, "CARD_AVAIL_LIMIT").setScale(2,BigDecimal.ROUND_HALF_UP));
    					i++;
    				}
    			}
    		}
    		
    		// Case: Secilen Kart
    		if(iMap.containsKey("SELECTED_CARD_NO") && oMap.containsKey("CARD_DETAIL_INFO") && oMap.getSize("CARD_DETAIL_INFO") > 0) {
    			
	    		for(index = 0; index < oMap.getSize("CARD_DETAIL_INFO"); index++) {
					if(iMap.getString("SELECTED_CARD_NO").equals(oMap.getString("CARD_DETAIL_INFO", index, "CARD_NO"))) {
						oMap.put("SELECTED_CARD_INDEX", index);
					}
	    		}
    		}
    	}

		// Case: Donebilecek durumda kart/basvuru yoksa
		if(oMap.getSize("CARD_DETAIL_INFO") == 0) {
			iMap.put("HATA_NO", 3218);
			GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
		}
    	
    	return oMap;
	}
}
