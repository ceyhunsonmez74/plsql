package tr.com.aktifbank.bnspr.clks.services;

import static tr.com.aktifbank.bnspr.clks.services.credit.ApplicationServices.getInstitutionInsuranceCode;
import static tr.com.aktifbank.bnspr.clks.services.credit.ApplicationServices.getInstitutionPlaceCode;
import static tr.com.aktifbank.bnspr.clks.services.credit.ApplicationServices.getInstitutionType;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.CreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.internal.GMCreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal.DalCreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application.STATUS;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Campaign;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Campaign.Relation;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.SgkInstitution;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal.CreditApplicationProcessImpl;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal.CreditApplicationRetireeProcessImpl;
import tr.com.aktifbank.bnspr.adc.clks.customer.model.PersonalCustomer;
import tr.com.aktifbank.bnspr.dao.ClksBbBorcTransferi;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruBirlestirme;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruSmsTalep;
import tr.com.aktifbank.bnspr.dao.ClksPttKrediKkbBasvuru;
import tr.com.aktifbank.bnspr.dao.ClksPttKrediKkbBasvuruId;
import tr.com.aktifbank.bnspr.dao.ClksPttKrediKkbData;
import tr.com.aktifbank.bnspr.dao.ClksPttKrediKkbKullandirim;
import tr.com.aktifbank.bnspr.dao.ClksPttKrediKkbKullandirimId;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.istSgkEmekliSorguDetay;
import tr.com.aktifbank.bnspr.dao.istSgkEmekliSorguLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.ClksBirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.dao.ClksBirBasvuruSgkAylikTx;
import tr.com.calikbank.bnspr.dao.ClksBirBasvuruSgkAylikTxId;
import tr.com.calikbank.bnspr.dao.ClksBirBasvuruTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CLKSCreditServices {

	private static Logger logger = Logger.getLogger(CLKSCreditServices.class);

	private final static int SGK_KONTROL_BASVURU = 1;
	private final static int SGK_KONTROL_KULLANDIRIM = 2;
	private final static String PTT_KKB_ADIM_BASVURU = "B";
	private final static String PTT_KKB_ADIM_SOZLESME = "S";
	private final static int RESPONSE_RED = 3;
	private final static int RESPONSE_IPTAL = 4;
	private static final String TELEFON_TIP_GSM = "3";
	private static final String TELEFON_FORMAT_TUM_KOD = "+UAT";
	private static final String PRODUCT_CODE = "KREDI";
	private static final String DOKUMAN_KOD_EFT_VE_KAPAMA_TALIMAT = "858";
	private final static CreditApplicationApi API = new GMCreditApplicationApi();

	/**
	 * Ba�vuru, Taksit �ptali ve Erken Kapama �ptali talepleri i�in iptal edilebilecek i�lemlerin
	 * listesini d�ner.
	 * 
	 * @param iMap	GMMap {BASVURU_NO, TCKN, ISLEMTIP}
	 * @return		{basvuruNo, TCKN, adiSoyadi, basvuruTarihi, kampanyaUrunAdi, tutar, durum, durumAciklama, 
	 * 				ISLEM_NO_BANKA}
	 */
	@GraymoundService("CLKS_KREDI_IPTAL_LISTESI")
	public static GMMap clksKrediIptalList(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			oMap = DALUtil.callOracleRefCursorFunction("{? = call PKG_TRN2050.GET_KREDI_IPTAL_LISTESI(?,?,?)}",
				"islemListesi", BnsprType.NUMBER, iMap.getBigDecimal("BASVURUNO"), BnsprType.STRING,
				iMap.getString("TCKN"), BnsprType.STRING, iMap.getString("ISLEMTIP"));

		} catch(Exception e) {
			logger.error("CLKS_KREDI_IPTAL_LISTESI err:", e);
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * �zleme, S�zle�me, G�ncelleme, Eksik Evrak, Gi�e ��lem Listesi, Kulland�r�m �demesi i�in Listeleme, �ptal i�in 
	 * Listeleme fonksiyonlar�n�n arkas�nda yer al�r ve girdi kriterlerine uygun ba�vuru kay�tlar�n� d�ner.
	 * 
	 * @param iMap	GMMap {basvuruNo, TCKN, KREDI_TURU, adi, ikinciAdi, soyadi, kampanyaUrunAdi, durum, tarihBas, 
	 * 				tarihSon, islemTip, pttSubeIl, isleminYapildigiMerkez, isleminYapildigiSube, 
	 * 				merkezSubeBasmudurluk, isleminYapildigiBasmudurluk}
	 * @return		{basvuruNo, TCKN, adiSoyadi, basvuruTarihi, krediTuru, kampanyaUrunAdi, tutar, vade, durum, 
	 * 				dosya_masrafi, onayTutar, durumAciklama, ISLEM_NO_BANKA, gorus, BASVURU_ADIM, ISLEM_NO_BELGE, 
	 * 				ISLEMIN_YAPILDIGI_YER, ev_tel, cep_tel, f_emekli, sigorta_kolu, nbsm_tahsis_numarasi}
	 */
	@GraymoundService("CLKS_KREDI_LISTESI")
	public static GMMap clksKrediList(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			if (!"K".equals(iMap.getString("islemTip"))) {
				GMServiceExecuter.call("CLKS_CONVERT_SMS_APPLICATION_TO_RETIREE_APPLICATION", iMap);
			}

			oMap = DALUtil.callOracleRefCursorFunction(
				"{? = call PKG_PTT_KREDI.RC_PTT_BASVURU_IZLEME_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}",
				"islemListesi", BnsprType.NUMBER, iMap.getBigDecimal("basvuruNo"), BnsprType.STRING, iMap
					.getString("TCKN"), BnsprType.NUMBER, iMap.getBigDecimal("KREDI_TURU"), BnsprType.STRING, null,
				BnsprType.STRING, iMap.getString("adi"), BnsprType.STRING, iMap.getString("ikinciAdi"),
				BnsprType.STRING, iMap.getString("soyadi"), BnsprType.STRING, iMap.getString("kampanyaUrunAdi"),
				BnsprType.STRING, iMap.getString("durum"), BnsprType.DATE, (iMap.getString("tarihBas").length() != 0)
					? new java.sql.Date(iMap.getDate("tarihBas").getTime()) : null, BnsprType.DATE,
				(iMap.getString("tarihSon").length() != 0) ? new java.sql.Date(iMap.getDate("tarihSon").getTime())
					: null, BnsprType.STRING, iMap.getString("islemTip"), BnsprType.STRING,
				iMap.getString("pttSubeIl"), BnsprType.STRING, iMap.getString("isleminYapildigiMerkez"),
				BnsprType.STRING, iMap.getString("isleminYapildigiSube"), BnsprType.STRING, iMap
					.getString("merkezSubeBasmudurluk"), BnsprType.STRING, iMap
					.getString("isleminYapildigiBasmudurluk"));

		} catch(Exception e) {
			logger.error("CLKS_KREDI_LISTESI err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * PTT kanal� ile ger�ekle�mi� kredi ba�vurusu iptal talebini valide eder.
	 * 
	 * @param iMap	GMMap {basvuruNo, aciklama, merkez_sube_basmudurluk, islemin_yapildigi_sube, 
	 * 				islemin_yapildigi_merkez, kullaniciSicil}
	 * @return		Girdiyi geri d�ner, olas� bir istisnada validasyon ba�ar�s�z kabul edilir.
	 * @throws GMRuntimeException	Ba�vuru iptal edilemeyecek ise veya farkl� bir istisna ger�ekle�ir ise f�rlat�l�r.
	 */
	@GraymoundService("CLKS_CREDIT_CANCEL_REQUEST")
	public static GMMap PttCreditCancelRequest(GMMap iMap) {

		/**
		 * TODO Validasyon hatas�nda istisna f�rlat�lmamal� ve uygun d�n�� yap�lmal�.	
		 */
		
		try {

			iMap.putAll((GMMap) DALUtil
				.callOracleProcedure("{call PKG_PTT_KREDI.PTT_IPTAL_KONTROL(?,?)}",
					new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("basvuruNo")}, new Object[]{BnsprType.NUMBER,
						"txNo"}));

			Session session = DAOSession.getSession("BNSPRDal");

			ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.createCriteria(ClksBirBasvuruTx.class)
				.add(Restrictions.eq("txNo", iMap.getBigDecimal("txNo"))).uniqueResult();

			clksBirBasvuruTx.setIptalAciklama(iMap.getString("aciklama"));
			String iptalIslemYeri = iMap.getString("merkez_sube_basmudurluk") + "/"
				+ iMap.getString("islemin_yapildigi_merkez") + "/" + iMap.getString("islemin_yapildigi_sube");
			clksBirBasvuruTx.setIptalIslemYeri(iptalIslemYeri);
			clksBirBasvuruTx.setIptalKullaniciSicil(iMap.getString("kullaniciSicil"));

			session.saveOrUpdate(clksBirBasvuruTx);
			session.flush();

		} catch(Exception e) {
			logger.error("CLKS_CREDIT_CANCEL_REQUEST err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return iMap;
	}

	/**
	 * PTT kanal� ile ger�ekle�mi� kredi ba�vurusunu iptal eder.
	 * 
	 * @param iMap	GMMap {basvuruNo, txNo, iptalTip, islemin_yapildigi_il, islemin_yapildigi_merkez, 
	 * 				islemin_yapildigi_sube, merkez_sube_basmudurluk}
	 * @return		Girdiyi geri d�ner, olas� bir istisnada iptal i�lemi ba�ar�s�z kabul edilir.
	 * 
	 * @see			tr.com.calikbank.bnspr.consumerloan.services.ConsumerLoanTRN3172Services#getBasvuruIptal(GMMap) BNSPR_TRN3172_BASVURU_IPTAL
	 */
	@GraymoundService("CLKS_CREDIT_CANCEL_CONFIRM")
	public static GMMap PttCreditCancelConfirm(GMMap iMap) {

		/**
		 * TODO �stisna f�rlat�lmamal� ve uygun d�n�� yap�lmal�.	
		 */
		
		try {

			Session session = DAOSession.getSession("BNSPRDal");

			ClksBirBasvuruTx ClksBirBasvuruTx = (ClksBirBasvuruTx) session.createCriteria(ClksBirBasvuruTx.class)
				.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("basvuruNo")))
				.addOrder(Order.desc("txNo")).setMaxResults(1).uniqueResult();
			
			ClksBirBasvuruTx.setIptalTip(iMap.getString("iptalTip"));
			ClksBirBasvuruTx.setIptalinYapildigiIl(iMap.getString("islemin_yapildigi_il"));
			ClksBirBasvuruTx.setIptalinYapildigiMerkez(iMap.getString("islemin_yapildigi_merkez"));
			ClksBirBasvuruTx.setIptalinYapildigiSube(iMap.getString("islemin_yapildigi_sube"));
			ClksBirBasvuruTx.setIptalinSubeBasmudurluk(iMap.getString("merkez_sube_basmudurluk"));

			session.saveOrUpdate(ClksBirBasvuruTx);
			session.flush();

			iMap.put("BASVURU_NO", iMap.getBigDecimal("basvuruNo"));
			iMap.put("AKSIYON_KARAR_KOD", 2);
			iMap.put("TX_MI", "H");
			iMap.put("PTT_IPTAL", "E");
			iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_BASVURU_IPTAL", iMap));

		} catch (Exception e) {
			logger.error("CLKS_CREDIT_CANCEL_CONFIRM err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return iMap;
	}
	
	/**
	 * PTT kanal�ndan ger�ekle�tirilecek yap�land�rma ba�vurular� �ncesi �n validasyon ger�ekle�tirir. �n validasyon
	 * a�a��daki ad�mlardan olu�maktad�r:
	 * 
	 * <ul>
	 * <li>M��terinin PTT kanal�ndan ger�ekle�mi� ge�erli kulland�r�m i�lemi bulunmas� zorunludur.</li>
	 * <li>M��terinin Yasal Takipde ba�vurusunun olmamas� zorunludur.</li>
	 * <li>M��terinin PTT kanal� haricinde farkl� kanaldan ger�ekle�mi� bir kulland�r�m i�leminin bulunmamas� 
	 * zorunludur.</li>
	 * <li>M��terinin 2. veya takip eden yap�land�rma ba�vurular�nda �nceki yap�land�rma ba�vurusunun sistem taraf�nda 
	 * tutulan adet kadar tahsilat ger�ekle�tirmi� olamas� zorunludur.</li>
	 * <li>M��terinin KKB'de kay�tl� farkl� banka kredisi olmamas� zorunludur.</li>
	 * </ul>
	 * 
	 * @param iMap	GMMap {TCKN}
	 *
	 * @return		{islemSonuc, hataMesaji, VALSTEP} �n validasyon ba�ar�l� olmas� sonucu <code>islemSonuc</code>
	 * 				de�eri 2 aksi takdirde 0 d�ner
	 * 
	 * @see			tr.com.calikbank.bnspr.currentaccounts.services.CurrentAccountsCommonServices#hataYaz 
	 * 				BNSPR_COMMON_HATA_YAZ
	 * @see			tr.com.calikbank.bnspr.intelligence.services#onlineKkbSorgula BNSPR_QRY3911_ONLINE_KKB_SORGULA
	 */
	@GraymoundService("BNSPR_CLKS_CONSOLIDATION_LOAN_PREVALIDATION")
	public static GMMap bnsprClksConsolidationLoanPrevalidation(GMMap iMap) {

		GMMap oMap = new GMMap();
		String kanalKodu = "7", primaryIdType = "6", other = "6", financeType = "90", dot = ".", birthDate = "19000101";
		int valStep = 1;
		BigDecimal musteriNo;

		try {

			Session session = DAOSession.getSession("BNSPRDal");
			musteriNo = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_musteri.Musteri_Varmi_TCKN(?)}", 
					Types.DECIMAL, iMap.getString("TCKN"));
			// Gecerli Kullandirim Kontrol
			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("musteriNo", musteriNo);
			restrictions.put("drm", "G");
			restrictions.put("kanalKodu", "7");

			Criteria criteria = session.createCriteria(BirKullandirim.class).add(Restrictions.allEq(restrictions));

			if(criteria.list().size() == 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5490));
			}
			valStep++;
			
			criteria = session.createCriteria(BirBasvuru.class).add(
				Restrictions.and(Restrictions.ne("pttMaasAlinanKurum", other), Restrictions.and(Restrictions.eq(
					"tcKimlikNo", iMap.getString("TCKN")), Restrictions.not(Restrictions.in("durumKodu", new String[]{
					"KAPANDI", "RED", "IPTAL"})))));

			List<?> list = criteria.list();
			Iterator<?> iterator = list.iterator();

			// Yasal Takip Ek Kontrol
			if(list.size() == 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5490));
			}
			valStep++;
			
			while(iterator.hasNext()) {

				BirBasvuru birBasvuru = (BirBasvuru) iterator.next();

				// Farkli Kanalli Kullandirim Kontrol
				if(!kanalKodu.equals(birBasvuru.getKanalKodu()) && "E".equals(birBasvuru.getPttEmekliPttBildir())) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5490));
				}
			}
			valStep++;
			
			// Tahsilat Kontrol
			if(!((BigDecimal) DALUtil.callOracleFunction("{ ? = call pkg_ptt_basvuru.konsolidasyon_tahsilat_kontrol(?) }", 
					BnsprType.NUMBER, BnsprType.STRING, iMap.getString("TCKN"))).equals(BigDecimal.ZERO)) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5490));
			}
			valStep++;

			// KKB Kontrol
			BigDecimal sorguNo = (BigDecimal) DALUtil.callOracleFunction("{ ? = call pkg_ptt_basvuru.yapilmis_kkb_sorgusu(?) }", 
				BnsprType.NUMBER, BnsprType.STRING, iMap.getString("TCKN"));

			if(sorguNo == null) {
				sorguNo = GMServiceExecuter.call("BNSPR_QRY3911_ONLINE_KKB_SORGULA", new GMMap().put("PRIMARY_ID_TYPE", primaryIdType)
					.put("PRIMARY_ID_NO", iMap.getString("TCKN")).put("FINANCE_TYPE", financeType).put("FORENAME1", dot).put("SURNAME", dot)
					.put("BIRTHDATE", birthDate).put("BIRTHTOWN", dot)).getBigDecimal("SORGU_NO");
			}

			BigDecimal sonuc = (BigDecimal) DALUtil.callOracleFunction("{ ? = call pkg_ptt_basvuru.konsolidasyon_kkb_risk(?) }", 
				BnsprType.NUMBER, BnsprType.NUMBER, sorguNo);

			logger.info("BNSPR_CLKS_CONSOLIDATION_LOAN_PARAMETERS. KKB Sorgu No : " + sorguNo + " KKB Risk : " + sonuc);

			if(sonuc.intValue() > 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5490));
			}

			oMap.put("islemSonuc", 2);

			try {

				//String msisdn = (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.telefon(?,?,?) }", BnsprType.STRING, BnsprType.NUMBER, musteriNo, BnsprType.STRING, TELEFON_TIP_GSM, BnsprType.STRING, TELEFON_FORMAT_TUM_KOD);
				//String content = GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5726)).getString("ERROR_MESSAGE");
				//GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", msisdn).put("CONTENT", content).put("MUSTERI_NO", musteriNo).put("MESSAGE_TYPE", 1));

			}
			catch (Exception e) {
				logger.error("BNSPR_CLKS_CONSOLIDATION_LOAN_PREVALIDATION  > BNSPR_SMS_SEND_SMS_ASYNC err:", e);
			}

		}
		catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSOLIDATION_LOAN_PREVALIDATION err:", e);
			oMap.put("VALSTEP", valStep);
			oMap.put("islemSonuc", 0);
			oMap.put("hataMesaji", e.getMessage());
		}

		return oMap;
	}
	
	/**
	 * PTT kanal� i�in yap�land�rma kredisi i�in sistem taraf�ndan berlirlenen tutar ve vade parametrelerinin
	 * de�erlerini d�ner.
	 * 
	 * @param iMap	GMMap {TC_KIMLIK_NO, BASVURU_NO}
	 * @return		{TUTAR, VADE}
	 * 
	 * @see			tr.com.calikbank.bnspr.currentaccounts.services.CurrentAccountsCommonServices#hataYaz 
	 * 				BNSPR_COMMON_HATA_YAZ
	 * @see			tr.com.calikbank.bnspr.currentaccounts.services.CurrentAccountsCommonServices#getParamText
	 * 				BNSPR_COMMON_GET_PARAM_TEXT
	 */
	@GraymoundService("BNSPR_CLKS_CONSOLIDATION_LOAN_PARAMETERS")
	public static GMMap bnsprClksConsolidationLoanParameters(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			BigDecimal tutar = (BigDecimal) DALUtil.callOracleFunction("{ ? = call pkg_ptt_basvuru.basvuru_konsolidasyon_tutar(?,?) }", BnsprType.NUMBER, 
					BnsprType.STRING, iMap.containsKey("TC_KIMLIK_NO") ? iMap.getString("TC_KIMLIK_NO") : null,
					BnsprType.NUMBER, iMap.containsKey("BASVURU_NO") ? iMap.getBigDecimal("BASVURU_NO") : null);
			
			oMap.put("TUTAR", tutar);
			oMap.put("VADE", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "BAYI_UPSELL_PARAMETRE").put("KEY", "VADE")).getString("TEXT"));
			
			if(oMap.get("TUTAR") == null ) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5491));
			}
			
//			if(oMap.getBigDecimal("TUTAR").compareTo(BigDecimal.ZERO) == 0 ) {
//				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 5491));
//			}
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSOLIDATION_LOAN_PARAMETERS err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/**
	 * PTT i�i KKB risk art��� sonras� ba�vuru ak���n� y�nlendirir.
	 * 
	 * @param iMap	GMMap {BASVURU_NO, ...}
	 * @return		TBD
	 * 
	 * @see			#clksPTTKrediFirstInitial CLKS_PTT_KREDI_FIRST_INITIAL
	 * @see			tr.com.calikbank.bnspr.consumerloan.services.ConsumerLoanInternalQueries#devamSorgular 
	 * 				BNSPR_TRN3171_DEVAM_SORGULAR
	 * @see			#clksPTTKrediInitial CLKS_PTT_KREDI_INITIAL
	 * @see			#clksPTTKrediConfirm CLKS_PTT_KREDI_CONFIRM
	 */
	@GraymoundService("CLKS_REAPPLY_FOR_LOAN")
	public static GMMap clksReapplyForLoan(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = new GMMap();
		
		int response;
		boolean fKonsolidasyonKredisi = false;
		
		try {
			
			// SGK aylik bilgilerini getir.
			iMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_ist_sgk_emekli.rc_guncel_kayit_getir(?)}", "SGK_AYLIK_BILGILERI", BnsprType.STRING, iMap.getString("BASVURU_NO")));
			
			// PTT aylik bilgilerini getir.
			iMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_ist_ptt_emekli.rc_guncel_kayit_getir(?)}", "MAAS_BILGILERI", BnsprType.STRING, iMap.getString("BASVURU_NO")));
			
			GMMap basvuruMap = GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU", new GMMap().put("BASVURU_NO", iMap
				.getBigDecimal("BASVURU_NO")));
			
			GMMap kampanyaMap = GMServiceExecuter.call("BNSPR_TRN3112_GET_FOR_UPDATE", new GMMap().put("KAMPANYA_KOD",
				basvuruMap.getString("URUN_KAMP_KOD")));
			
			@SuppressWarnings("unchecked")
			List<Map<?,?>> productMaps = (ArrayList<Map<?,?>>) kampanyaMap.get("URUN");
			
			int minTerm = 9999, maxTerm = 0;
			BigDecimal minAmount = BigDecimal.valueOf(999999), maxAmount = BigDecimal.ZERO;
			
			for(Map<?,?> productMap : productMaps) {
				minTerm = Math.min(minTerm, Integer.parseInt((String) productMap.get("MIN_VADE")));
				maxTerm = Math.max(maxTerm, Integer.parseInt((String) productMap.get("MAX_VADE")));
				minAmount = minAmount.min(new BigDecimal((String) productMap.get("ALT_LIMIT")));
				maxAmount = maxAmount.max(new BigDecimal((String) productMap.get("UST_LIMIT")));
			}
			
			kampanyaMap.put("CLKS_MIN_VADE", minTerm);
			kampanyaMap.put("CLKS_MAX_VADE", maxTerm);
			kampanyaMap.put("CLKS_MIN_TUTAR", minAmount);
			kampanyaMap.put("CLKS_MAX_TUTAR", maxAmount);
			kampanyaMap.put("KOD", basvuruMap.getString("URUN_KAMP_KOD"));
			
			iMap.put("KAMPANYA", kampanyaMap);
			
			oMap.putAll(GMServiceExecuter.executeNT("CLKS_PTT_KREDI_FIRST_INITIAL", iMap));
			oMap.put("F_REAPPLY", true);
			oMap.put("WEB_SATIS_KANALI", basvuruMap.get("WEB_SATIS_KANALI")); 
			oMap.put("KURYE_SECIMI", "S"); 

			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_DEVAM_SORGULAR", oMap));
	
			fKonsolidasyonKredisi = iMap.getMap("KAMPANYA").getBoolean("BIRLESTIRME_EH");
			
			// Case: NBSM Red/Iptal
			if("H".equals(oMap.getString("DEVAM"))) {
				
				response = RESPONSE_RED;
				if(fKonsolidasyonKredisi) {
					if("IPTAL".equals(oMap.getString("DURUM"))) {
						response = RESPONSE_IPTAL;
					} else {
						response = RESPONSE_RED;
					}
				}
					
				oMap = new GMMap().put("islemSonuc", response).put("hataMesaji", "").put("MESAJ", fKonsolidasyonKredisi ? GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5372)).getString("ERROR_MESSAGE"): oMap.getString("MESSAGE"));
			}
			
			// Case: Devam
			else {
				
				oMap.put("KAMPANYA", kampanyaMap);
				oMap.putAll(GMServiceExecuter.executeNT("CLKS_PTT_KREDI_INITIAL", oMap));
				oMap.put("GUNCELLEMEMI","H").put("APS_YAPILDIMI","E").put("TEMINAT_TABLE", oMap.get("TEMINAT_LIST"));
				map.putAll(GMServiceExecuter.executeNT("CLKS_PTT_KREDI_CONFIRM", oMap));
				oMap.clear();
				
				if("IPTAL".equals(map.getString("DURUM"))) {
					map.put("MESSAGE", fKonsolidasyonKredisi ? GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5372)).getString("ERROR_MESSAGE"): map.getString("MESSAGE"));
				}
				
				// Case: Red
				else if("RED".equals(map.getString("DURUM"))) {
					map.put("MESSAGE", fKonsolidasyonKredisi ? GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5372)).getString("ERROR_MESSAGE"): map.getString("MESSAGE"));
				}
				
				// Case: Dogrulama
//				else if("H".equals(map.getString("DEVAM"))) {
//					map.put("MESSAGE", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5371)).getString("ERROR_MESSAGE"));
//				} 
				else if("H".equals(map.getString("DEVAM"))) {
                     
                    map.put("MESSAGE", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5371)).getString("ERROR_MESSAGE"));
                    try {
                          String msisdn = basvuruMap.getString("CEP_TEL_KOD").concat(basvuruMap.getString("CEP_TEL_NO"));    
                          String musteriNo = basvuruMap.getString("MUSTERI_NO");
                          String content = GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 6141).put("P1", iMap.getBigDecimal("BASVURU_NO"))).getString("ERROR_MESSAGE");
                          GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", msisdn).put("CONTENT", content).put("MUSTERI_NO", musteriNo).put("MESSAGE_TYPE", 1));
                          
                    }
                    catch (Exception e) {
                          logger.error("CLKS_REAPPLY_FOR_LOAN  > BNSPR_SMS_SEND_SMS_ASYNC err: ", e );
                    }
              }

				
				// Case: Sozlesme
				else {
					map.put("MESSAGE", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5373).put("P1", map.getString("ONAYLANAN_KREDI_TUTARI"))).getString("ERROR_MESSAGE"));
				}
				
				for (Iterator<Entry<Object, Object>> rowIterator = map.entrySet().iterator(); rowIterator.hasNext();) {
					
					Entry<Object, Object> rowEntry = rowIterator.next();
					oMap.put("CLKS_CREDIT_CONFIRM", 0, rowEntry.getKey().toString(), rowEntry.getValue());
				}
				
				oMap.put("CLKS_CREDIT_CONFIRM", 0, "islemSonuc", 2);
				oMap.put("islemSonuc", 1);
			}
			
		} catch(Exception e) {
			logger.error("CLKS_REAPPLY_FOR_LOAN err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * PTT kanal�ndan ger�ekle�ecek kredi ba�vurusu, PTT �ny�z� ilk ekran arkas�nda tetiklenen servistir. Bu servis 
	 * sonras�nda kredi entegrasyonunda NBSM I call ger�ekle�ir. 
	 *
	 * @param iMap	GMMap {MAAS_BILGILERI=[{TAHSIS_NUMARASI, MAAS_ALINAN_KURUM, MAAS_TUTARI, UNVANI, EMEKLI_MAAS_DONEM, 
	 * 				ONCEKI_MAAS_ODEME_TARIHI, MAAS_TARIH_SIKLIGI, ILK_MAAS_TARIHI, SON_MAAS_TARIHI, MAAS_PTT_DENMI, 
	 *				EMEKLI_MAAS_EVDENMI, KURUM_DONEM}], SGK_AYLIK_BILGILERI=[{SIGORTA_KOLU, AYLIK_ID, TAHSIS_SEKLI, ADI,
	 *				SOYADI, AYLIK_BANKAMDA,SICIL_NO,SISTEM_ACIK_KAPALI_KODU, AYLIK_SONUC_KODU, AYLIK_SONUC_ACIKLAMA}], 
	 *				SGK_SONUC_KODU, SGK_SONUC_ACIKLAMA, TC_KIMLIK_NO, UYRUK, ADI, IKINCI_ADI, SOYADI, DOGUM_YERI, 
	 *				DOGUM_TARIHI, BABA_ADI, KIMLIK_SERI_NO, KIMLIK_SIRA_NO, ANNE_KIZLIK_SOYADI, CEP_TEL_KOD, CEP_TEL_NO,
	 *				VADE, TUTAR, DOVIZ_KOD, ANNE_ADI, NUFUS_IL_KOD, NUFUS_ILCE_KOD, NUFUS_CILT_NO, NUFUS_AILE_SIRA_NO, 
	 *				NUFUS_SIRA_NO, NUFUS_VERILIS_TARIHI, CINSIYET, MEDENI_HAL, KAYIP_CUZDAN_NO, KAYIP_CUZDAN_SERI, 
	 *				KPS_YAPILDI, NUF_VERILIS_NEDENI, NUF_VERILDIGI_YER, NUFUS_MAHALLE, KIMLIK_KAYIT_NO, KRD_TUR_KOD, 
	 *				KRD_TUR_ALT_KOD, ISLEMI_YAPAN_KULLANICI, ISLEMI_YAPANKULLANICI_ADSOYAD, ISLEMIN_YAPILDIGI_YER, 
	 *				ISLEMIN_YAPILDIGI_IL, ISLEM_NO_BANKA, BASVURU_NO, SESSION_IP, URUN_KAMP_KOD, KIMLIK_SERI_NO_KPS, 
	 *				KIMLIK_SIRA_NO_KPS, CALISMA_SEKLI, SIGORTALIMI, GUNCELLEMEMI, POSTA_CEK_HESABI, 
	 *				ISLEMIN_YAPILDIGI_MERKEZ, ISLEMIN_YAPILDIGI_SUBE, MERKEZ_SUBE_BASMUDURLUK, 
	 *				ISLEMIN_YAPILDIGI_BASMUDURLUK, URUN_NO, URUN_MIKTAR, URUN_NITELIK_DEGER_LIST=[{PAIR_ID, FIELD_NAME, 
	 *				FIELD_VALUE, FIELD_TEXT}], EK_DOKUMAN}
	 *
	 * @return		{RESPONSE, RESPONSE_DATA, ...}
	 *
	 * @see			#ClksPTTCreditSaveorUpdate(GMMap) CLKS_PTT_KREDI_SAVE_OR_UPDATE
	 * @see			#kaydetPTTKKB(GMMap) CLKS_BASVURU_PTT_ICI_KKB_KAYDET
	 * @see			...
	 *
	 */
	@GraymoundService("CLKS_PTT_KREDI_FIRST_INITIAL")
	public static GMMap clksPTTKrediFirstInitial(GMMap iMap) {

		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();
		 
		
		try { 
			GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_CANCEL_INITIAL_SMS_CREDIT_APPLICATION_FOR_RETIREE_APPLICATION", iMap);

			
//			map.put("KAMP_KOD", convertSMSCreditToRetireeApplication(map.getString("KAMP_KOD")));
			// Case: Kullandirim > Basvuru - Sistem Devam (PTT ici KKB riskinin artmasi sebebi ile basvuru sureci basa doner)
			if(map.getBoolean("F_REAPPLY")) {
				
				map.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_LIST_FIRST_INITIAL_INFO", map));
				map.put("URUN_KAMP_KOD", map.get("KAMP_KOD"));
				map.put("KAMP_URUN_ADI", map.get("KAMP_KOD"));
				map.put("KANAL_KOD", map.get("KANAL_KODU"));
				map.put("DOVIZ_KODU", "TRY");
				map.put("EKRAN_NO", 3171);
				map.put("TRX_NAME", 3171);
				map.put("KREDI_TURU", map.get("KRD_TUR_KOD"));
			} 
			
			// Case: Upsell bildirim
			else {
				map.put("F_UPSELL", (GMServiceExecuter.call("CLKS_UPSELL_BILDIRIM", new GMMap().put("TUTAR", map.getBigDecimal("TUTAR")).put("BASVURU_NO", map.getBigDecimal("BASVURU_NO")))).get("F_UPSELL"));
			}
			
			if(map.get("BASVURU_NO") == null || map.getString("BASVURU_NO").isEmpty()) {
				map.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", new GMMap())
					.getBigDecimal("ID"));
			}
			
			Campaign campaign = new Campaign.Builder(map.getMap("KAMPANYA").getBigDecimal("KOD"), 
				map.getBigDecimal("KAMP_KNL_KOD"))
					.accountBlockCode(map.getMap("KAMPANYA").getString("KUL_BLOKE_KODU"))
					.allIncluded(map.getMap("KAMPANYA").getBoolean("HERSEY_DAHIL_EH"))
					.balanceTransfer(map.getMap("KAMPANYA").getBoolean("BORC_TRANSFERI_EH"))
					.publicCredit(map.getMap("KAMPANYA").getBoolean("UCUNCU_SAHIS_EH"))
					.consolidation(map.getMap("KAMPANYA").getBoolean("BIRLESTIRME_EH"))
					.visualImpairment(map.getMap("KAMPANYA").getBoolean("GORME_ENGELLI_EH"))
					.consolidationOnChannel(map.getMap("KAMPANYA").getBoolean("PTT_ICI_BIRLESTIRME_EH"))
					.creditType(Campaign.CreditType.getEnum(map.getMap("KAMPANYA").getInt("KREDI_TURU")))
					.relation("4".equals(map.getString("MAAS_ALINAN_KURUM")) ? Relation.PERSONNEL : Relation.RETIREE)
					.minTerm(map.getMap("KAMPANYA").getInt("CLKS_MIN_VADE"))
					.maxTerm(map.getMap("KAMPANYA").getInt("CLKS_MAX_VADE"))
					.minAmount(map.getMap("KAMPANYA").getBigDecimal("CLKS_MIN_TUTAR"))
					.maxAmount(map.getMap("KAMPANYA").getBigDecimal("CLKS_MAX_TUTAR")).build();
			
			PersonalCustomer customer = new PersonalCustomer(null, map.getString("TC_KIMLIK_NO"));
			customer.setBirthDate(map.getDate("DOGUM_TARIHI"));
			
			Application application = new Application(map.getBigDecimal("BASVURU_NO"), map.getString("TC_KIMLIK_NO"),
				map.getBigDecimal("TUTAR"), map.getInt("VADE"), campaign);
			application.setIpaz(map.getBoolean("F_IPAZ"));
			application.setCrs(map.getBoolean("F_CRS"));
			application.setMobilePhone(map.getString("CEP_TEL_KOD", "").concat(map.getString("CEP_TEL_NO", "")));
			application.setCustomer(customer);
			
			GMMap clksKkbMap = new GMMap().put("SORGU_ADIM", PTT_KKB_ADIM_BASVURU)
				.put("BASVURU_NO", application.getApplicationNo());
			clksKkbMap.put("KKB_SONUC_DATA", map.get("KKB_SONUC_DATA"));
			
			if (!isSMSCreditApplication(map.getBigDecimal("BASVURU_NO"))) {
				GMServiceExecuter.call("CLKS_BASVURU_PTT_ICI_KKB_KAYDET", clksKkbMap);
			}
			
			if(application.getCampaign().isConsolidationOnChannel()) {
				
				boolean isConsolidationOnChannelInfoExists = true;
				if(map.get("KKB_SONUC_DATA") instanceof List<?>) {
					
					@SuppressWarnings("unchecked")
					List<GMMap> kkbSonucData = (List<GMMap>) map.get("KKB_SONUC_DATA");
					
					if(kkbSonucData.get(0).getSize("GECMIS_KULLANDIRIMI_YAPILANLAR") > 0) {
						
						@SuppressWarnings("unchecked")
						List<GMMap> loans = (List<GMMap>) kkbSonucData.get(0).get("GECMIS_KULLANDIRIMI_YAPILANLAR");
						
						saveOrUpdateConsolidationOnChannel(loans, application.getApplicationNo());
					} else {
						isConsolidationOnChannelInfoExists = false;
					}
				} else {
					isConsolidationOnChannelInfoExists = false;
				}
				
				if(!isConsolidationOnChannelInfoExists) {
					if(application.getCampaign().isVisualImpairment()) {
						API.error(5957);
					} else {
						API.error(5956);
					}
				}
			}
			
			CreditApplicationProcess<Application> process = new CreditApplicationRetireeProcessImpl(
				new DalCreditApplicationDao(), API);
			
			Map<?, ?> response = process.applicationRequest(application, "E".equals(map.getString("F_CEP_TEL_VALIDASYON")));

			if(response.get("RESPONSE") != null && !"2".equals(response.get("RESPONSE"))) {
				return new GMMap(response);
			}
			            
			map = GMServiceExecuter.call("BNSPR_CLKS_CREDIT_PENSION_PERIOD", map);
			// PTT Kredi - Kabul Aylik Secimi, SGK Aylik Eslestirme
			// Basvuru Girisi icin SGK Kontrolleri CLKS_BSVURU_EMEKLI_AYLIK_ESLESTIR'de yapiliyor 
			map.putAll(GMServiceExecuter.call("BNSPR_CLKS_CREDIT_SELECT_PENSION", map));

			// 1:Evden, 2:Merkez, -1:Tanimsiz
			map.put("EMEKLI_MAAS_EVDENMI", getInstitutionPlaceCode(map.getInt("MAAS_ALINAN_KURUM")) == "K" ? "E" : "H");
			
			// Maas Alinan Kurum - 1:SSK, 2:Emekli Sandigi, 3:Bagkur, 4:PTT Personel 
			map.put("MAAS_ALINAN_KURUM", getInstitutionType(map.getInt("MAAS_ALINAN_KURUM")));
			
			// Case: PTT, Kamu Personeli
			if (map.getInt("MAAS_ALINAN_KURUM") == 4 || map.getInt("MAAS_ALINAN_KURUM") == 5) {
				map.put("UNVANI", getPersonelUnvanKod(map.getInt("MAAS_ALINAN_KURUM"), map.getString("UNVANI")));
			}
			
			// Case: Emekli Sandigi
			if("2".equals(map.getString("MAAS_ALINAN_KURUM")) && (map.get("MAAS_TARIH_SIKLIGI") == null) || map.getString("MAAS_TARIH_SIKLIGI").isEmpty()) {
				return new GMMap().put("RESPONSE", 1).put("RESPONSE_DATA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 4992)).getString("ERROR_MESSAGE"));
			}
			
			// Son maas tarihi bayrama denk gelirse, yeni degeri ile guncelleniyor
			map.put("SON_MAAS_TARIHI", GMServiceExecuter.call("CLKS_SON_MAAS_TARIHI", map).get("SON_MAAS_TARIHI"));
			
			map.put("ES_TCKN", map.getString("ES_TCKN"));
			map.put("EK_DOKUMAN",map.getString("EK_DOKUMAN"));
			map.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", map.put("KONTROL_SAVE_OR_UPDATE", "1")));
			map.putAll(GMServiceExecuter.call("CLKS_BIR_BASVURU_SGK_AYLIK_TX_SAVE_OR_UPDATE", map));
			
			// TODO Workaround
			if (map.getInt("MAAS_ALINAN_KURUM") != 4) {
				GMServiceExecuter.call("CLKS_BIR_BASVURU_AYLIK_LOG", map);
			}
			
			// Onceki Maas Odeme Tarihini Guncelle
			map.put("ONCEKI_MAAS_ODEME_TARIHI", (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_nbsm_3appl_2.ptt_emekli_onceki_maas_tarihi(?)}", Types.NUMERIC, map.getBigDecimal("BASVURU_NO")));
			map.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", map));
			
			if("99999999".equals(map.getString("ONCEKI_MAAS_ODEME_TARIHI"))) {
				map.remove("ONCEKI_MAAS_ODEME_TARIHI");
			}
			
			// SGK Online Bildirim Loglama
			GMServiceExecuter.executeAsync("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG", map.put("REQUEST_TYPE", "aylikSorgula"));
			
			map.put("AYLIK_GELIR", map.getString("MAAS_TUTARI"));
			map.putAll(GMServiceExecuter.call("BNSPR_TRN3171_CHECK_FAIZ_ORANI", map)); // FAIZ_ORANI, SOZLESME_FAIZ_ORANI

			if(!iMap.getBoolean("F_REAPPLY")) {
				GMServiceExecuter.call("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU", map);
				GMServiceExecuter.call("BNSPR_TRN3171_BASVURU_KAMPANYA_KONTROL", map);
			}
			
			application.setTrxNo(map.getBigDecimal("TRX_NO"));

			map.putAll(GMServiceExecuter.call("BPM_GET_KATKIPAYI", map)); // SERBEST_KATKI_PAYI, MIN_KATKI_PAYI, KATKI_PAYI_KIMDEN, SERBEST_KATKI_ORAN, MAX_KATKI_PAYI 
			map.put("KATILIM_BEDELI", map.getString("MAX_KATKI_PAYI"));
			map.put("PTT_ILK_TAKSIT_YONTEM", GMServiceExecuter.call("CLKS_GET_ILK_TAKSIT_YONTEM", map).getBigDecimal("PTT_ILK_TAKSIT_YONTEM"));

			if(map.getBoolean("F_GIRIS") || (!application.getCampaign().isConsolidation() && !application.getCampaign().isConsolidationOnChannel())) {
				map.putAll(GMServiceExecuter.call("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", map)); // DOSYA_MASRAFI, HERSEY_DAHIL_TUTAR
				map.put("KREDI_TUTARI", map.getBigDecimal("HERSEY_DAHIL_TUTAR"));
			} else {
				map.put("KREDI_TUTARI", map.getBigDecimal("TUTAR"));
			}
			
			
			GMMap odemeGrupMap = GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", new GMMap().put(
					"KAMP_URUN_ADI", campaign.getCode()));
				map.put("ODEME_TIPI", odemeGrupMap.get("DEFAULT_ODEME_TIP"));
				if(odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MIN_VADE") != null) {
					map.put("ODEME_VADESI", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MIN_VADE"));
				}
			
			//BNSPR_TRN3171_CONTROL servisine artan �demeli ile gelen 2 yeni input. 
			map.put("ODEME_ORANI", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MAX_ORAN"));
			map.put("ODEME_PERIYODU", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MAX_PERIYOD")); 	
				
			if(map.getBoolean("F_REAPPLY")) {
				map.put("CLKS_TRX_NO", map.get("TRX_NO"));
				map.put("BNSPR_TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				map.put("TRX_NO", map.get("BNSPR_TRX_NO"));
				map.putAll(GMServiceExecuter.call("BNSPR_TRN3171_SAVE_TEMP", map));
				map.put("TRX_NO", map.get("CLKS_TRX_NO"));
			} else {
				GMServiceExecuter.call("BNSPR_TRN3171_APS_SORGULAMA", map);
				map.putAll(GMServiceExecuter.call("BNSPR_TRN3171_SAVE_TEMP", map));
			}

			BigDecimal maasSikligi = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_nbsm_3appl_2.ptt_emekli_maas_sikligi(?)}", Types.NUMERIC, map.getBigDecimal("BASVURU_NO"));
			
			// Case: Emekli Sandigi - Maas tarih sikligi uyumsuz, ise uyari verilecek.
			if("2".equals(map.getString("MAAS_ALINAN_KURUM")) && !BigDecimal.ZERO.equals(maasSikligi) && !map.getBigDecimal("MAAS_TARIH_SIKLIGI").equals(maasSikligi)) {
				oMap.put("RESPONSE", 3).put("RESPONSE_DATA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5059).put("P1", maasSikligi).put("P2", map.getBigDecimal("MAAS_TARIH_SIKLIGI"))).getString("ERROR_MESSAGE"));
			}
				
			GMServiceExecuter.call("BNSPR_TRN3171_UPDATE_MUSTERI_NO", map);

			for (Iterator<?> iterator = response.entrySet().iterator(); iterator.hasNext();) {
				
				@SuppressWarnings("unchecked")
				Entry<String, Object> entry = (Entry<String, Object>) iterator.next();
				
				oMap.put(entry.getKey(), entry.getValue());
			}
			
			String crsInfo = API.crsInfo(application.getNationalIdentificationNumber());
			
			if(!"E".equals(crsInfo) && application.isCrs()) {
				API.updateCrsInfo(application.getNationalIdentificationNumber(), application.isCrs());
				crsInfo = "E";
				oMap.put("MESSAGE", API.message(5930));
			} else if("E".equals(crsInfo)) {
				oMap.put("MESSAGE", API.message(5927));
			}
			
			if("E".equals(crsInfo)) {
				API.rejectApplication(application.getApplicationNo(), application.getTrxNo(),
					Application.STATUS.BASVURU.toString(), "48");
				application.setStatus(Application.STATUS.RED);
			}
			
			oMap.put("ISLEM_NO_BANKA", map.getBigDecimal("TRX_NO"));
			oMap.put("TRX_NO", map.getBigDecimal("TRX_NO"));
			oMap.put("BASVURU_NO", map.getBigDecimal("BASVURU_NO"));
			oMap.put("FAIZ_ORANI", map.getBigDecimal("SOZLESME_FAIZ_ORANI"));
			oMap.put("DEVAM", map.getString("DEVAM"));
			oMap.put("NBSM_TAHSIS_NUMARASI", map.getString("TAHSIS_NUMARASI"));
			oMap.put("SIGORTA_KOLU", getInstitutionInsuranceCode(map.getInt("MAAS_ALINAN_KURUM")));			
			oMap.put("SERBEST_KATKI_PAYI", map.getString("SERBEST_KATKI_PAYI"));
			oMap.put("SERBEST_KATKI_ORAN", map.getString("FAIZ_ORANI"));
			oMap.put("MAX_KATKI_PAYI", map.get("MAX_KATKI_PAYI") != null ? map.get("MAX_KATKI_PAYI") : 0);
			oMap.put("MIN_KATKI_PAYI", map.get("MIN_KATKI_PAYI") != null ? map.get("MIN_KATKI_PAYI") : 0);
			oMap.put("KATKI_PAYI_KIMDEN", map.getString("KATKI_PAYI_KIMDEN"));
			oMap.put("SGK_RED_NITELIKLI", map.getString("SGK_RED_NITELIKLI"));
            oMap.put("DURUM", application.getStatus().toString());
			
			// Case: SGK'dan Red
			if(application.getStatus() != STATUS.RED && "E".equals(oMap.getString("SGK_RED_NITELIKLI"))) {
	            oMap.putAll(GMServiceExecuter.call("CLKS_PTT_BASVURU_REDDET", new GMMap()
	                .put("ISLEM_NO", map.getBigDecimal("ISLEM_NO_BANKA"))
	                .put("BASVURU_NO", map.getBigDecimal("BASVURU_NO"))
	                .put("ISLEM_KOD", Application.STATUS.BASVURU.toString())
	                .put("AKSIYON_KARAR_KOD", map.getString("SGK_RED_GEREKCE_KODU"))));
	            oMap.put("DURUM", "RED");
	        }
			
			oMap.put("RESPONSE","2");
			
			if(map.getBoolean("F_REAPPLY")) {
				
				oMap.put("TRX_NO", map.getBigDecimal("BNSPR_TRX_NO"))
					.put("CLKS_TRX_NO", map.getBigDecimal("CLKS_TRX_NO"))
					.put("BNSPR_TRX_NO", map.getBigDecimal("BNSPR_TRX_NO"));
				

				GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", new GMMap()
					.put("KONTROL_SAVE_OR_UPDATE", "0")
					.put("CLKS_TRX_NO", map.getBigDecimal("CLKS_TRX_NO"))
					.put("BNSPR_TRX_NO", map.getBigDecimal("BNSPR_TRX_NO")));
			}
		
		} catch (Exception e) {
			logger.error("CLKS_PTT_KREDI_FIRST_INITIAL err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * PTT ici Birlestirme basvurularinda PTT trafindan gonderilen kredi bilgilerini saklar.
	 * 
	 * @param loans					PTT tarafindan gonderilen kredi bilgileri
	 * @param applicationNo			Kredi basvuru numarasi
	 * @throws ParseException
	 * @throws HibernateException
	 * @throws GMRuntimeException
	 */
	private static void saveOrUpdateConsolidationOnChannel(List<GMMap> loans, BigDecimal applicationNo)
		throws ParseException, HibernateException, GMRuntimeException {
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		GMMap dalMap = DALUtil.getResults(String.format(
			"select level, bnspr.seq_clks_bb_birlestirme.nextval seq from dual connect by level <= %s", loans.size()),
			"SEQUENCE_RESULTSET");
		
		@SuppressWarnings("unchecked")
		List<ClksBirBasvuruBirlestirme> birlestirmeList = session.createCriteria(ClksBirBasvuruBirlestirme.class)
			.add(Restrictions.eq("basvuruNo", applicationNo)).list();
		
		for(int i=0; i<birlestirmeList.size(); i++) {
			session.delete(birlestirmeList.get(i));
		}
		
		for(int i = 0; i < loans.size(); i++) {
		
			ClksBirBasvuruBirlestirme birlestirme = new ClksBirBasvuruBirlestirme(dalMap.getBigDecimal(
				"SEQUENCE_RESULTSET", i, "SEQ"), applicationNo);
			birlestirme.setBankaId(loans.get(i).getString("BANKA_ID"));
			birlestirme.setTutar(loans.get(i).getBigDecimal("TUTAR"));
			if (!"0".equals(loans.get(i).getString("BASVURU_TARIHI")))
				birlestirme.setBasvuruTarihi(loans.get(i).getDate("BASVURU_TARIHI"));
			else
				birlestirme.setBasvuruTarihi(loans.get(i).getDate("KULLANDIRIM_TARIHI"));
			birlestirme.setKullandirimTarihi(loans.get(i).getDate("KULLANDIRIM_TARIHI"));
			birlestirme.setKapamaEh("H");
			birlestirme.setKkbAcikEh("E");
			session.save(birlestirme);
		}
		session.flush();
	}

	/**
	 * PTT kanal�ndan ger�ekle�ecek kredi ba�vurusu, PTT �ny�z� ikinci ekran arkas�nda tetiklenen servistir. PTT 
	 * �ny�z�nde "M��teri Bilgilendirme Ekran�" ndan �nce �a��r�l�r.
	 * 
	 * @param iMap	GMMap {...}
	 * @return 		{...}
	 */
	@GraymoundService("CLKS_PTT_KREDI_INITIAL")
	public static GMMap clksPTTKrediInitial(GMMap iMap) {

		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();
		
		try {

			// Case: Kullandirim > Basvuru - Sistem Devam (PTT ici KKB riskinin artmasi sebebi ile basvuru sureci basa doner)
			// TRX_NO > BNSPR_TRX_NO
			// ISLEM_NO_BANKA > CLKS_TRX_NO
			if(map.getBoolean("F_REAPPLY")) {
				map.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_LIST_INITIAL_INFO", map));
				map.put("URUN_KAMP_KOD", map.get("KAMP_KOD"));
			}

			map.put("KANAL_KOD", "7");
			map.put("ODEME_TIPI", "2");
			map.put("ODEME_PERIYODU", "");
			map.put("EKRAN_NO", "3171");
			map.put("ISLEM_KODU", "3171");
			
			oMap.put("TRX_NO", map.getBigDecimal("ISLEM_NO_BANKA"));
			oMap.put("ISLEM_NO_BANKA", map.getBigDecimal("ISLEM_NO_BANKA"));
			oMap.put("BASVURU_NO", map.getBigDecimal("BASVURU_NO"));

			if(map.getBoolean("F_REAPPLY")) { map.put("ISLEM_NO_BANKA", map.get("BNSPR_TRX_NO")); }
			map.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_LIST_FIRST_INITIAL_INFO", map));
			if(map.getBoolean("F_REAPPLY")) { map.put("ISLEM_NO_BANKA", map.get("CLKS_TRX_NO")); }
			map.put("MAAS_TARIH_SIKLIGI", map.get("PERIYOD"));

			// Case: PTT, Kamu Personeli
			if (map.getInt("MAAS_ALINAN_KURUM") == 4 || map.getInt("MAAS_ALINAN_KURUM") == 5) {
				map.put("UNVANI", getPersonelUnvanKod(map.getInt("MAAS_ALINAN_KURUM"), map.getString("UNVANI")));
			}

			if(map.getString("TEMINAT_TABLE") != null && map.getString("TEMINAT_TABLE").compareTo("") == 0) {
				map.remove("TEMINAT_TABLE");
			}

			map.put("KAMP_URUN_ADI", map.getString("KAMP_KOD"));
			map.putAll(GMServiceExecuter.call("BPM_DOSYA_MASRAF_FAIZ_TANIMI", new GMMap()
				.put("KAMP_URUN_ADI", map.getBigDecimal("KAMP_URUN_ADI"))
				.put("TUTAR", map.getBigDecimal("HERSEY_DAHIL_TUTAR"))
				.put("VADE", map.getBigDecimal("VADE"))
				.put("KANAL_KOD", map.getBigDecimal("KANAL_KOD"))
				.put("DOVIZ_KOD", map.getString("DOVIZ_KOD"))
				.put("KRD_TUR_KOD", map.getBigDecimal("KRD_TUR_KOD"))));
			map.put("DOSYA_MASRAFI", map.getString("MAX_DOSYA_MASRAFI"));
			map.put("TRX_NO", map.getBigDecimal("ISLEM_NO_BANKA"));

			// TODO: ?
			if("000".equals(map.getString("EV_IL"))) {
				map.put("EV_IL", "200");
			}

			if(!map.getMap("KAMPANYA").getBoolean("BIRLESTIRME_EH")) {
				map.putAll(GMServiceExecuter.call("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", map));
			}
			
			GMMap odemeGrupMap = GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", new GMMap().put(
					"KAMP_URUN_ADI", map.getString("KAMP_KOD")));			
					
				map.put("ODEME_TIPI", odemeGrupMap.get("DEFAULT_ODEME_TIP"));
				if(odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MIN_VADE") != null) {
					map.put("ODEME_VADESI", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MIN_VADE"));
				}
			
			//BNSPR_TRN3171_CONTROL servisine artan �demeli ile gelen 2 yeni input. 
			map.put("ODEME_ORANI", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MAX_ORAN"));
			map.put("ODEME_PERIYODU", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MAX_PERIYOD")); 	
				
			if(map.getBoolean("F_REAPPLY")) { map.put("TRX_NO", map.get("BNSPR_TRX_NO")); }
			GMServiceExecuter.call("BNSPR_TRN3171_CONTROL", map);
			if(map.getBoolean("F_REAPPLY")) { map.put("TRX_NO", map.get("CLKS_TRX_NO")); }
			
			map.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", map.put("KONTROL_SAVE_OR_UPDATE", "2")));

			// Eklenti
			if(map.getString("SGK_MAAS_TUTARI") != null) {
				map.put("AYLIK_GELIR", map.getString("SGK_MAAS_TUTARI"));
			}
			
			oMap.put("DEVAM", "E");
			oMap.putAll(GMServiceExecuter.call("CLKS_PTT_GET_INITIAL_REQUEST_OUT_DATA", map));
			oMap.put("KAMP_URUN_ADI", map.getString("KAMP_URUN_ADI"));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_TEMINATLAR", oMap));

			for(int i = 0; i < oMap.getSize("TEMINAT_LIST"); i++) {
				oMap.put("TEMINAT_ADI", DALUtil.getResult("select pkg_genel_pr.Teminat_Adi('" + oMap.getString("TEMINAT_LIST", i, "TEMINAT") + "') from dual"));
				oMap.put("TEMINAT_LIST", i, "TEMINAT_ADI", oMap.getString("TEMINAT_ADI"));
			}

			oMap.put("KAMPANYA_KODU", map.getString("KAMP_KOD"));
			oMap.put("MAAS_TARIH_SIKLIGI", oMap.getString("PERIYODU"));

			// BT-1688 nolu issue ile yaptim.
			if(map.getString("MAAS_ALINAN_KURUM").compareTo("2") != 0 && map.getString("MAAS_TARIH_SIKLIGI").compareTo("3") == 0) {
				map.put("HATA_NO", new BigDecimal(1943));
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", map);
			}

			// Case: Emekli/Personel'de aylik periyod kontrolu
			if(map.getString("MAAS_ALINAN_KURUM") != null && map.getString("MAAS_ALINAN_KURUM").compareTo("5") != 0)
				GMServiceExecuter.call("CLKS_MAAS_TARIHI_MAAS_SIKLIGI_UYUMLUMU", map);

			oMap.put("ISLEM_NO_BANKA", map.getBigDecimal("ISLEM_NO_BANKA"));

		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_INITIAL err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * PTT kanal�ndan ger�ekle�ecek kredi ba�vurusu, PTT �ny�z� ikinci ekran arkas�nda tetiklenen 2. servistir. PTT 
	 * �ny�z�nde "M��teri Bilgilendirme Ekran�" ndan �nce �a��r�l�r. {@link #clksPTTKrediInitial(GMMap) 
	 * CLKS_PTT_KREDI_INITIAL} sonras�nda �a��r�l�r.
	 * 
	 * @param iMap	GMMap {...}
	 * @return		...
	 */
	@GraymoundService("CLKS_PTT_KREDI_CONFIRM")
	public static GMMap clksPTTKrediConfirm(GMMap iMap) {

		/**
		 * TODO {@link #clksPTTKrediInitial CLKS_PTT_KREDI_INITIAL} ile ortak degerlendirim tek ad�ma indirilmelidir.
		 */
		
		GMMap i2Map = new GMMap();
		GMMap i4Map = new GMMap();
		GMMap oMap = new GMMap();
		
		BigDecimal teyitEdilenGelir = BigDecimal.ZERO, kapamaTutar = BigDecimal.ZERO;

		try {
			
			if(iMap.getMap("KAMPANYA").getBoolean("BIRLESTIRME_EH")) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_CLKS_CONSOLIDATION_LOAN_PARAMETERS", new GMMap().put(
					"BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))));
				oMap.put("KAPAMA_TUTARI", oMap.remove("TUTAR"));
				oMap.remove("VADE");
			}
			
			// Case: Kullandirim > Basvuru - Sistem Devam (PTT ici KKB riskinin artmasi sebebi ile basvuru sureci basa doner)
			// TRX_NO > CLKS_TRX_NO
			// ISLEM_NO_BANKA > CLKS_TRX_NO
			if(iMap.getBoolean("F_REAPPLY")) {
				if(iMap.getBoolean("F_REAPPLY")) { iMap.put("ISLEM_NO_BANKA", iMap.get("BNSPR_TRX_NO")); }
				iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_CONFIRM_INFO", iMap));
				if(iMap.getBoolean("F_REAPPLY")) { iMap.put("ISLEM_NO_BANKA", iMap.get("CLKS_TRX_NO")); }
			}
			
			// Baris & Sezgi
			BigDecimal islemBankaNoOriginal = iMap.getBigDecimal("ISLEM_NO_BANKA");
			iMap.put("KANAL_KOD", "7");
			iMap.put("EKRAN_NO", "3171");
			iMap.put("ISLEM_KODU", "3171");

			oMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO_BANKA"));
			oMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO_BANKA"));

			// Kayit Guncelleme
			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", iMap.put("KONTROL_SAVE_OR_UPDATE", "3")));

			if(iMap.get("TEYIT_EDILEN_GELIR") != null && iMap.getString("TEYIT_EDILEN_GELIR").length() != 0 && !BigDecimal.ZERO.equals(iMap.getBigDecimal("TEYIT_EDILEN_GELIR"))) {
				teyitEdilenGelir = iMap.getBigDecimal("TEYIT_EDILEN_GELIR");
			}
			
			if(iMap.getBoolean("F_REAPPLY")) { iMap.put("ISLEM_NO_BANKA", iMap.get("BNSPR_TRX_NO")); }
			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_LIST_FIRST_INITIAL_INFO", iMap));
			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_LIST_INITIAL_INFO", iMap));
			if(iMap.getBoolean("F_REAPPLY")) { iMap.put("ISLEM_NO_BANKA", iMap.get("CLKS_TRX_NO")); }
			
			/*
			logger.info("pkg_nbsm_7rsl.get_prev_nbsm_output_value > " + ((String) DALUtil.callOracleFunction("{? = call pkg_nbsm_7rsl.get_prev_nbsm_output_value(?,?,?)}", BnsprType.STRING, 
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"),
				BnsprType.STRING, "I",
				BnsprType.STRING, "InitialStrategyADKIncYNReq")));
			
			logger.info("TEYIT_EDILEN_GELIR > " + iMap.getString("TEYIT_EDILEN_GELIR"));
			*/
			
			if("Y".equals((String) DALUtil.callOracleFunction("{? = call pkg_nbsm_7rsl.get_prev_nbsm_output_value(?,?,?)}", BnsprType.STRING, 
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"),
				BnsprType.STRING, "I",
				BnsprType.STRING, "InitialStrategyADKIncYNReq")) &&
				BigDecimal.ZERO.equals(teyitEdilenGelir) && BigDecimal.ZERO.equals(iMap.getBigDecimal("TEYIT_EDILEN_GELIR"))) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 561).put("P1", "Teyit edilen gelir"));
			}
			
			iMap.put("TEYIT_EDILEN_GELIR", BigDecimal.ZERO.equals(teyitEdilenGelir) ? iMap.get("TEYIT_EDILEN_GELIR") : teyitEdilenGelir);

			if(iMap.getBoolean("F_REAPPLY")) { iMap.put("TRX_NO", iMap.get("BNSPR_TRX_NO")); }
			GMServiceExecuter.executeNT("BNSPR_TRN3171_CONTROL", iMap); //
			GMMap gonderSorgularMap = GMServiceExecuter.call("BNSPR_TRN3171_GONDER_SORGULAR", iMap);
			oMap.putAll(gonderSorgularMap);
			if(iMap.getBoolean("F_REAPPLY")) { iMap.put("TRX_NO", iMap.get("CLKS_TRX_NO")); }

			// Case: Basvuru Onay
			if("E".equals(oMap.getString("DEVAM"))) {

				iMap.put("TRX_NO", oMap.getBigDecimal("TRX_NO"));
				
				if(iMap.getBoolean("F_REAPPLY")) { iMap.put("TRX_NO", iMap.get("BNSPR_TRX_NO")); }
				GMServiceExecuter.call("BNSPR_TRN3171_SAVE", iMap); //
				if(iMap.getBoolean("F_REAPPLY")) { iMap.put("TRX_NO", iMap.get("CLKS_TRX_NO")); }

				iMap.put("TRX_NO", oMap.getBigDecimal("TRX_NO"));
				iMap.put("ISLEM_NO_BANKA", oMap.getBigDecimal("TRX_NO"));

				i2Map.putAll(GMServiceExecuter.call("BNSPR_TCK_NO_GET_BAYI_BILGILERI", new GMMap().put(("TCK_NO"), iMap.getString("TC_KIMLIK_NO"))));

				i4Map.put("MUSTERI_NO", i2Map.getString("MUSTERI_NO"));
				i4Map.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
				i4Map.put("KPS_YAPILDI", iMap.getString("KPS_YAPILDI"));
				i4Map.put("PTT_PERSONEL_MI", iMap.getString("PTT_PERSONEL_MI"));
				i4Map.put("MAAS_ALINAN_KURUM", iMap.getString("MAAS_ALINAN_KURUM"));
				i4Map.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
				if(i2Map.getString("MUSTERI_NO") == null || i2Map.getString("MUSTERI_NO").compareTo("") == 0) {
					i4Map.putAll(GMServiceExecuter.call("CLKS_PTT_KONTAKT_MUSTERI_YARATMA", iMap)); //
				} else if(i2Map.getString("MUSTERI_KONTAKT") != null && i2Map.getString("MUSTERI_KONTAKT").compareTo("K") == 0) {
					i4Map.putAll(GMServiceExecuter.call("CLKS_PTT_KONTAKT_MUSTERI_GUNCELLEME_DATA", iMap)); //
					i4Map.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", i4Map)); //
				}

				i4Map.put("MUSTERI_NO", i2Map.getString("MUSTERI_NO"));

				GMServiceExecuter.call("BNSPR_TRN3171_STATU_GUNCELLE", i4Map); //

				oMap.putAll(GMServiceExecuter.call("CLKS_PTT_GET_CONFIRM_OUT_DATA", iMap));

			} 
			
			// Case: Dogrulama veya Red
			else {
				
				i2Map.putAll(GMServiceExecuter.call("BNSPR_TCK_NO_GET_BAYI_BILGILERI", new GMMap().put(("TCK_NO"), iMap.getString("TC_KIMLIK_NO"))));

				i4Map.put("MUSTERI_NO", i2Map.getString("MUSTERI_NO"));
				i4Map.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
				i4Map.put("KPS_YAPILDI", iMap.getString("KPS_YAPILDI"));
				i4Map.put("PTT_PERSONEL_MI", iMap.getString("PTT_PERSONEL_MI"));
				i4Map.put("MAAS_ALINAN_KURUM", iMap.getString("MAAS_ALINAN_KURUM"));
				i4Map.put("BASVURU_NO", iMap.getString("BASVURU_NO"));

				if(i2Map.getString("MUSTERI_NO") == null || i2Map.getString("MUSTERI_NO").compareTo("") == 0) {
					i4Map.putAll(GMServiceExecuter.call("CLKS_PTT_KONTAKT_MUSTERI_YARATMA", iMap)); //
				} else if(i2Map.getString("MUSTERI_KONTAKT") != null && i2Map.getString("MUSTERI_KONTAKT").compareTo("K") == 0) {
					i4Map.putAll(GMServiceExecuter.call("CLKS_PTT_KONTAKT_MUSTERI_GUNCELLEME_DATA", iMap)); //
					i4Map.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", i4Map)); //
				}

				i4Map.put("MUSTERI_NO", i2Map.getString("MUSTERI_NO"));

				GMServiceExecuter.call("BNSPR_TRN3171_STATU_GUNCELLE", i4Map);
			}
			
			API.sendApplicationText(iMap.getBigDecimal("TRX_NO") == null ? iMap.getBigDecimal("ISLEM_NO") : iMap
				.getBigDecimal("TRX_NO"), iMap.getString("ISLEM_KODU"));

			CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
			Application application = applicationDao.get(iMap.getBigDecimal("BASVURU_NO"));
			
			CreditApplicationProcess<Application> process = new CreditApplicationProcessImpl<Application>(
				applicationDao, API);
			process.applicationConfirm(application);
			process.applicationAfterConfirm(application, gonderSorgularMap);
			
			// Case: Fark Faizi Pesin
			if("0".equals(iMap.getString("PTT_ILK_TAKSIT_YONTEM"))) {
				oMap.put("VADE_FARK_FAIZI", iMap.get("FARK_FAIZ"));
			}
			oMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
			oMap.put("ISLEM_NO_BANKA", islemBankaNoOriginal);
			oMap.put("TRX_NO", islemBankaNoOriginal);
			oMap.put("DEVAM", application.getStatus() == Application.STATUS.SOZLESME ? "E" : "H");
			
			
		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_CONFIRM err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * PTT kanal� kredi ba�vurusuna ait s�zle�me bas�m talebi sonras� �a�r�l�r. Kredi ba�vurusuna ait belge listesini 
	 * d�ner.
	 * 
	 * @param iMap	GMMap {...}
	 * @return		...
	 * 
	 * @see			tr.com.calikbank.bnspr.consumerloan.services.ConsumerLoanTRN3181Services#saveTRN3181
	 * 				BNSPR_TRN3181_SAVE
	 * @see			#bnsprClksCreditGetDocumentVariables(GMMap) BNSPR_CLKS_CREDIT_GET_DOCUMENT_VARIABLES
	 */
	@GraymoundService("CLKS_PTT_KREDI_PAYMENT_PLAN_REQUEST")
	public static GMMap clksPTTKrediPaymentPlanRequest(GMMap iMap) {

		GMMap proxyMap = new GMMap(), oMap = new GMMap();

		try {
			
			CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
			Application application = applicationDao.get(iMap.getBigDecimal("BASVURU_NO"));
			
			CreditApplicationProcess<Application> process = new CreditApplicationProcessImpl<Application>(
				applicationDao, new GMCreditApplicationApi());
			process.paymentPlanRequest(application);
			
			if(application.getCampaign().isConsolidationOnChannel()) {
				
				boolean isMocked = false;
				String isMockedParam ="";
				try {
					isMockedParam = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap()
					.put("KOD", "CLKS_MOCK_CREDIT_KKB_DATA")
					.put("KEY", application.getNationalIdentificationNumber())).getString("TEXT");
				}
				catch (Exception e) {
					isMockedParam="H";
					// TODO: handle exception
				}
				if("E".equals(isMockedParam)) {
					isMocked = true;
				}
				
				if(!isMocked) {
					boolean isConsolidationOnChannelInfoExists = true;
					if(iMap.get("KKB_SONUC_DATA") instanceof List<?>) {
						
						@SuppressWarnings("unchecked")
						List<GMMap> kkbSonucData = (List<GMMap>) iMap.get("KKB_SONUC_DATA");
						
						if(kkbSonucData.get(0).getSize("GECMIS_KULLANDIRIMI_YAPILANLAR") > 0) {
							
							@SuppressWarnings("unchecked")
							List<GMMap> loans = (List<GMMap>) kkbSonucData.get(0).get("GECMIS_KULLANDIRIMI_YAPILANLAR");
							
							Session session = DAOSession.getSession("BNSPRDal");
		
							@SuppressWarnings("unchecked")
							List<ClksBirBasvuruBirlestirme> birlestirmeList = session.createCriteria(ClksBirBasvuruBirlestirme.class)
								.add(Restrictions.eq("basvuruNo", application.getApplicationNo())).list();
							
							if(loans.size() > birlestirmeList.size()) {
								if(!isConsolidationOnChannelInfoExists) {
									if(application.getCampaign().isVisualImpairment()) {
										API.error(5957);
									} else {
										API.error(5956);
									}
								}
							}
							
//							for(int j=0; j<birlestirmeList.size(); j++) {
//								boolean isRecordExists = false;
//								for(int i = 0; i < loans.size(); i++) {
//									if(birlestirmeList.get(j).getBankaId().equals(loans.get(i).getString("BANKA_ID"))
//										&& birlestirmeList.get(j).getBasvuruTarihi().equals(loans.get(i).getString("BASVURU_TARIHI"))
//										&& birlestirmeList.get(j).getKullandirimTarihi().equals(loans.get(i).getString("KULLANDIRIM_TARIHI"))
//										&& birlestirmeList.get(j).getTutar().equals(loans.get(i).getString("TUTAR"))) {
//										isRecordExists = true;
//									}
//								}
//								
//								if(!isRecordExists && "E".equals(birlestirmeList.get(j).getKapamaEh())) {
//									birlestirmeList.get(j).setKapamaEh("S");
//								}
//								
//								session.saveOrUpdate(birlestirmeList.get(j));
//							}
//							session.flush();
							// PTT i�i birle�tirmede s�zle�me ad�m�nda ilk g�nderdi�inden farkl� say�da de�er d�n�lm��se yeniden basvuru girise cevirlecek
							if("E".equals(iMap.getString("SOZLESME_BASIM")) && loans.size()!=birlestirmeList.size()){
								BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"), LockMode.UPGRADE_NOWAIT);
								birBasvuru.setDurumKodu("BASVURU");
								session.saveOrUpdate(birBasvuru);
								session.flush();
								oMap.put("KKB_SONUC_DATA", iMap.get("KKB_SONUC_DATA"));
								oMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
								oMap.put("ISLEM_NO_BANKA", iMap.getString("ISLEM_NO_BANKA"));
								oMap.put("F_REAPPLY", true);
								
								return oMap;
							}
						} else {
							isConsolidationOnChannelInfoExists = false;
						}
					} else {
						isConsolidationOnChannelInfoExists = false;
					}
					
					if(!isConsolidationOnChannelInfoExists) {
						if(application.getCampaign().isVisualImpairment()) {
							API.error(5957);
						} else {
							API.error(5956);
						}
					}
				}
			}
			
			if("E".equals(iMap.getString("SOZLESME_BASIM")) && isSMSCreditApplication(application.getApplicationNo()) && !isSMSCreditConvertedRetireeApplication(application.getApplicationNo()) ) {
				Session session = DAOSession.getSession("BNSPRDal");
				
				BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"), LockMode.UPGRADE_NOWAIT);
				birBasvuru.setDurumKodu("BASVURU");
				session.saveOrUpdate(birBasvuru);
				session.flush();
				
				
				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session
						.createCriteria(ClksBirBasvuruTx.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
	
					if(clksBirBasvuruTx != null) {
				
						clksBirBasvuruTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ_SOZLESME"));
						clksBirBasvuruTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE_SOZLESME"));
						clksBirBasvuruTx.setIsleminYapildigiIl(iMap.getString("ISLEMIN_YAPILDIGI_IL_SOZLESME"));

						session.saveOrUpdate(clksBirBasvuruTx);
						session.flush();
					}
					
				GMServiceExecuter.call("BNSPR_TRN3172_UPDATE_APPLICATION", new GMMap()
				.put("BASVURU_NO", application.getApplicationNo())
				.put("PTT_SUBE_ILI", iMap.getString("ISLEMIN_YAPILDIGI_IL_SOZLESME"))
				.put("PTT_ISLEMIN_YAPILDIGI_MERKEZ", iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ_SOZLESME") )
				.put("PTT_ISLEMIN_YAPILDIGI_SUBE", iMap.getString("ISLEMIN_YAPILDIGI_SUBE_SOZLESME"))
				 );
				
				oMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
				oMap.put("ISLEM_NO_BANKA", iMap.getString("ISLEM_NO_BANKA"));
				oMap.put("F_REAPPLY", true);
				
				return oMap;
			}

			
			iMap.put("KONTROL_SAVE_OR_UPDATE", iMap.getString("KONTROL_SAVE_OR_UPDATE", "7"));
			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", iMap));

			// Kurum Kodu 6 olanlar 3.Ki�i Kredi ba�vurusu yapasnlar. Onlar i�in KKB gerek yok .
			if (iMap.getString("MAAS_ALINAN_KURUM") !=null && !iMap.getString("MAAS_ALINAN_KURUM").equalsIgnoreCase("6") && !isSMSCreditApplication(iMap.getBigDecimal("BASVURU_NO"))) {
				
				// PTT ici KKB Kayit (Basvurunun aksine NT gidelim)
				GMServiceExecuter.executeNT("CLKS_BASVURU_PTT_ICI_KKB_KAYDET", iMap.put("SORGU_ADIM", PTT_KKB_ADIM_SOZLESME));
				
				// KKB riski artmis ise yeniden basvuru girise cevirlecek
				if("E".equals(iMap.getString("SOZLESME_BASIM")) && "BASVURU".equals((String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.ptt_ici_kkb_kontrol(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO")))) {
					
					oMap.put("KKB_SONUC_DATA", iMap.get("KKB_SONUC_DATA"));
					oMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
					oMap.put("ISLEM_NO_BANKA", iMap.getString("ISLEM_NO_BANKA"));
					oMap.put("F_REAPPLY", true);
					
					return oMap;
				}
			}
			
			iMap.put("ISLEMIN_YAPILDIGI_MERKEZ_SOZLESME", iMap.getBigDecimal("ISLEMIN_YAPILDIGI_MERKEZ_SOZLESME"));
			iMap.put("ISLEMIN_YAPILDIGI_SUBE_SOZLESME", iMap.getBigDecimal("ISLEMIN_YAPILDIGI_SUBE_SOZLESME"));
			iMap.put("ISLEMIN_YAPILDIGI_BASMUDURLUK_SOZLESME", iMap.getBigDecimal("ISLEMIN_YAPILDIGI_BASMUDURLUK_SOZLESME"));

			proxyMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO_BANKA"));
			proxyMap.put("ISLEM_NO_BANKA", iMap.getBigDecimal("ISLEM_NO_BANKA"));
			proxyMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));

			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", iMap.put("KONTROL_SAVE_OR_UPDATE", "4")));
			iMap.putAll(GMServiceExecuter.call("CLKS_GET_PAY_PLN_3181_REQUEST_INFO", iMap));

			if (iMap.getBigDecimal("GECIKME_GUN_SAYISI").compareTo(new BigDecimal("0")) == 0) {
				iMap.remove("FAIZ_ODEME_SEKLI");
			}

			// TRN: Sozlesme Basim
			GMServiceExecuter.execute("BNSPR_TRN3181_SAVE", iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO")));
			GMServiceExecuter.execute("BNSPR_TRN3181_SOZLEZME_BASIM_EH", iMap);

			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_PAYMENT_PLAN_PREPARING", iMap));

			// Case: Sozlesme faizi tanimliysa ve faiz oranindan farkli ise
			if (!(iMap.getString("SOZLESME_FAIZI") != null && iMap.getString("FAIZ_ORANI").compareTo("SOZLESME_FAIZI") != 0)) {
				iMap.put("KATKILI_FAIZ_ORANI_AYLIK", "");
				iMap.put("KATKILI_FAIZ_ORANI_YILLIK", "");
			}

			iMap.put("ISLEM_NO_BELGE", iMap.getString("TRX_NO"));
			iMap.put("TRX_NO", proxyMap.getBigDecimal("ISLEM_NO_BANKA"));
			iMap.put("ISLEM_NO_BANKA", proxyMap.getBigDecimal("ISLEM_NO_BANKA"));
			
			// Belge: SOBF, Sigorta Bilgi Formu, vb.
			iMap.putAll(GMServiceExecuter.call("BNSPR_CLKS_CREDIT_GET_DOCUMENT_VARIABLES", new GMMap().put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))));
			iMap.putAll(GMServiceExecuter.call("CLKS_GET_IBAN_FROM_SOZLESME_HESAP",new GMMap().put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))));
			
			for(int i = 0; i < iMap.getSize("BELGE_DETAY"); i++) {

				if(DOKUMAN_KOD_EFT_VE_KAPAMA_TALIMAT.equals(iMap.getString("BELGE_DETAY", i, "BELGE_KODU"))) {

					HashMap<String, Object> reportParameters = new HashMap<String, Object>();

					@SuppressWarnings("unchecked")
					List<Map<?,?>> parameters = (ArrayList<Map<?, ?>>) iMap.get("BELGE_DETAY", i, "BELGE_KEY_VALUE");
					
					for(Map<?, ?> parameter : parameters) {
						reportParameters.put(parameter.get("KEY").toString(), parameter.get("VALUE") != null
							? parameter.get("VALUE").toString() : null);
					}

					JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3181_EFT_KAPAMA_FORMU",
						reportParameters);
					byte[] report = JasperExportManager.exportReportToPdf(jasperPrint);

					GMMap dysMap = new GMMap();
					dysMap.put("DOKUMAN_TIPI", DOKUMAN_KOD_EFT_VE_KAPAMA_TALIMAT);
					dysMap.put("REFERANS_TIPI", "2");
					dysMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
					dysMap.put("REFERANS_NO", iMap.getString("BASVURU_NO"));
					dysMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap())
						.getBigDecimal("TRX_NO"));
					dysMap.put("ONAYSIZ_ISLEM_MI", true);
					dysMap.put("DOSYA_SAYFA", 0, "CONTENT", report);
					dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", "MUST_IMAJ_" + iMap.getString("MUSTERI_NO")
						+ "_" + DOKUMAN_KOD_EFT_VE_KAPAMA_TALIMAT + "_1.pdf");
					dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", 1);

					if(GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap).getBoolean("RESULT")) {
						GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
					} else {
						GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
					}
				}
			}
			

		} catch (Exception e) {
			
			logger.error("CLKS_PTT_KREDI_PAYMENT_PLAN_REQUEST err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return iMap;
	}

	/**
	 * PTT kanal� kredi ba�vurusuna ait s�zle�me bas�m s�recini tamamlamak amac� ile �a��r�l�r.
	 * 
	 * @param iMap	GMMap {...}
	 * @return		...
	 * 
	 * @see			#ClksPTTCreditSaveorUpdate(GMMap) CLKS_PTT_KREDI_SAVE_OR_UPDATE
	 * @see			...
	 */
	@GraymoundService("CLKS_PTT_KREDI_PAYMENT_PLAN_CONFIRM")
	public static GMMap clksPTTKrediPaymentPlanConfirm(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {
			
			oMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO_BANKA"));
			oMap.put("ISLEM_NO_BANKA", iMap.getBigDecimal("ISLEM_NO_BANKA"));
			oMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			oMap.put("ISLEM_NO_BELGE", iMap.getBigDecimal("ISLEM_NO_BELGE"));

			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", iMap.put("KONTROL_SAVE_OR_UPDATE", "5")));
			iMap.put("SOZLESME_EVRAK", "S");

			oMap.putAll(GMServiceExecuter.call("CLKS_GET_PAY_PLN_3181_CONFIRM_INFO", iMap));
			oMap.putAll(GMServiceExecuter.call("CLKS_GET_IBAN_FROM_SOZLESME_HESAP",new GMMap().put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))));
			
		} catch (Exception e) {
			
			logger.error("CLKS_PTT_KREDI_PAYMENT_PLAN_CONFIRM err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * PTT kanal�ndan ger�ekle�tirilen kredi ba�vurusunun kulland�r�m�nda �a��r�l�r. Bu servis sonras�nda s�re� ba�ar� 
	 * ile sonlan�r ise kredi ba�vurusunun durumu <code>EVRAKSIZ</code> olarak g�ncellenir ve kredi tutar� m��terinin
	 * hesab�na ge�er. 
	 * 
	 * @param iMap	GMMap {...}
	 * @return		...
	 * 
	 * @see 		#ClksPTTCreditSaveorUpdate(GMMap) CLKS_PTT_KREDI_SAVE_OR_UPDATE
	 * @see			...
	 */
	@GraymoundService("CLKS_PTT_CONTRACTUAL_REQUEST")
	public static GMMap clksPTTContractualRequest(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {
			
			// Case: Hobim, Eksik Evrak Tamamla akisindan geliyorsa kontrol etmeyelim.
			if(!"-1".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {
				// Durum basvuruya cekilerek ilerlendiyese, diger trx_no degerlerini alalim
				iMap.putAll(getFReapplyTrxDetails(iMap));
			}
			
			// Durum Kontrol
			DALUtil.callOracleProcedure("{call PKG_TRN3181.DURUM_KONTROL(?)}", new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")}, new Object[]{});

			iMap.put("ISLEMIN_YAPILDIGI_MERKEZ_EVRAK", iMap.getBigDecimal("ISLEMIN_YAPILDIGI_MERKEZ_EVRAK"));
			iMap.put("ISLEMIN_YAPILDIGI_SUBE_EVRAK", iMap.getBigDecimal("ISLEMIN_YAPILDIGI_SUBE_EVRAK"));
			iMap.put("ISLEMIN_YAPILDIGI_BASMUDURLUK_EVRAK", iMap.getBigDecimal("ISLEMIN_YAPILDIGI_BASMUDURLUK_EVRAK"));
			//iMap.put("SON_TX_NO", iMap.getBoolean("F_REAPPLY") ? iMap.get("BNSPR_TRX_NO") : iMap.get("SON_TX_NO"));
			iMap.put("KONTROL_SAVE_OR_UPDATE", iMap.getString("KONTROL_SAVE_OR_UPDATE", "6"));
			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", iMap));
		
			// Kurum =6 de�il ise SGK kontrol yap�lacak. 5 i�in gerek yok .Kurum Kodu 5 =  3 Ki�i Kredi Ba�vurusu olarak degerlendirilir.
			if (iMap.getString("MAAS_ALINAN_KURUM") !=null && !iMap.getString("MAAS_ALINAN_KURUM").equalsIgnoreCase("6") ) {
			
				// Case: Kullandirim - SGK Online Kontrolleri
				if(!"E".equals(iMap.getString("EKRAN"))) {
					
					// Dosya masrafi degisikligi var ise, m��teri sozlemeye yonlendirilecek
					GMServiceExecuter.call("BNSPR_TRN3132_CHECK_KATKIPAYI_DOSYAMASRAFI", iMap).getString("CHECK_MESSAGE");
					
					GMMap logMap = new GMMap();
					logMap.putAll(iMap);
					
					// SGK Online Bloke Loglama
					GMServiceExecuter.executeAsync("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG", logMap
						.put("REQUEST_TYPE","aylikBlokeKoy")
						.put("TAHSIS_NUMARASI", iMap.getString("TAHSIS_NUMARASI"))
						.put("SIGORTA_KOLU", iMap.getString("SIGORTA_KOLU"))
						.put("BASVURU_NO", iMap.getString("BASVURU_NO"))
						.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"))
						.put("SGK_SONUC_KODU", iMap.getString("SGK_BLOKE_SONUC_KODU"))
						.put("SGK_SONUC_ACIKLAMA", iMap.getString("SGK_BLOKE_SONUC_ACIKLAMA")));
					
					// SGK Online Bildirim Loglama
					GMServiceExecuter.executeAsync("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG", logMap.put("REQUEST_TYPE", "aylikSorgula"));
				
					iMap.put("SGK_KONTROL_TIP", SGK_KONTROL_KULLANDIRIM); // Kullandirim Kontrolleri
					iMap.putAll(GMServiceExecuter.call("CLKS_BASVURU_EMEKLI_SGK_AYLIK_GETIR", iMap));
					
					// SGK Online Bildirim Kontrol
					GMServiceExecuter.call("BNSPR_CLKS_CREDIT_PENSION_SGK_VALIDATION", iMap);
				}
			}

			// BARCODE (barkod numarasi)
			// CASE_STATUS(borga verecek)
			// CASE_STATUS_DATE (gondermene gerek yok)
			// PROJECT_TYPE(CLKSDYS gondermelisin sabit)
			// REFERENCE(Basvuru numarasi)
			// STATUS (borga verecek)
			// STATUS_DATE(gondermene gerek yok)
			
			iMap.put("BARCODE", iMap.getString("BARKOD_NUMARASI"));
			iMap.put("PROJECT_TYPE", "CLKSDYS");
			iMap.put("REFERENCE", iMap.getBigDecimal("BASVURU_NO"));
			iMap.put("STATUS", "1");

			// Case: Uygun degildir
			if ("E".equals(iMap.getString("SORUN_VARMI"))) {
				oMap.putAll(GMServiceExecuter.call("CLKS_PTT_BASVURU_REDDET", new GMMap()
					.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO_BELGE"))
					.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))
					.put("ISLEM_KOD", "BELGE")
					.put("AKSIYON_KARAR_KOD", "17")));
				
				return oMap;
				
			}
			
			GMServiceExecuter.call("CLKS_PTT_KREDI_UPDATE_BARKOD_LIST", iMap.put("SOZLESME_EVRAK", "E"));

			iMap.put("TEYIT_GEREKLI", false);
			iMap.put("BELGE_KONTROL", true);
			iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO_BELGE"));
			iMap.put("ISLEM_TARIHI", new SimpleDateFormat("yyyyMMdd").format(new java.util.Date()));
			iMap.put("CALISMA_SEKLI_KOD", "2");
			
			int j = 0;
			for (int i = 0; i < iMap.getSize("BELGE_LISTESI"); i++) {

				// TODO 101 ve 102 PTT tarafinda farkli tanimlanmali
				if (!"-1".equals(iMap.getString("BELGE_LISTESI", i, "evrakKodu")) && !"101".equals(iMap.getString("BELGE_LISTESI", i, "evrakKodu")) && !"102".equals(iMap.getString("BELGE_LISTESI", i, "evrakKodu"))) {

					iMap.put("TBL_BELGE", j, "BELGE_KODU", iMap.getBigDecimal("BELGE_LISTESI", i, "evrakKodu"));
					iMap.put("TBL_BELGE", j, "BELGE_ADI", iMap.getString("BELGE_LISTESI", i, "evrakAdi"));
					iMap.put("TBL_BELGE", j, "ALINDI", iMap.getString("BELGE_LISTESI", i, "evrakTeslimEdilmismi"));
					iMap.put("TBL_BELGE", j, "KIMDEN", "M");
					iMap.put("TBL_BELGE", j, "ISLEM_TARIHI", iMap.getString("ISLEM_TARIHI"));
					iMap.put("TBL_BELGE", j, "BARKOD_NUMARASI", iMap.getString("BARKOD_NUMARASI"));
					
					iMap.put("BELGELER", j, "BASVURU_NO", iMap.getString("BASVURU_NO"));
					iMap.put("BELGELER", j, "BELGE_KOD", iMap.getString("BELGE_LISTESI", i, "evrakKodu"));
					iMap.put("BELGELER", j, "BELGE_ADI", iMap.getString("BELGE_LISTESI", i, "evrakAdi"));
					iMap.put("BELGELER", j, "ALINDI", iMap.getString("BELGE_LISTESI", i, "evrakTeslimEdilmismi"));
					iMap.put("BELGELER", j, "KIMDEN_KOD", "M");
					iMap.put("BELGELER", j, "BELGE_KONTROL", "5");
					iMap.put("BELGELER", j, "ISLEM_TARIHI", iMap.getString("ISLEM_TARIHI"));
					iMap.put("BELGELER", j++, "BARKOD_NUMARASI", iMap.getString("BARKOD_NUMARASI"));
				}
			}
			
			// Case: Uygundur
			if ("H".equals(iMap.getString("SORUN_VARMI"))) {
				
				// Tarihce Kayit
				oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", iMap));
				
				/* 3181 EKRANI SIMULE EDILIYOR */
				if (oMap.getString("MESSAGE") == null || (oMap.getString("MESSAGE") != null && oMap.getString("MESSAGE").compareTo("") != 0)) {
					oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_UPDATE_DURUM", iMap));
				}

				iMap.putAll(GMServiceExecuter.call("CLKS_GET_3182_REQUEST_DATA", iMap));
				oMap.put("KAMPANYA_TIP", iMap.getString("KAMPANYA_TIP"));
				oMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
			}

			// Case: Eksik Evrak
			else if (iMap.get("SORUN_VARMI") == null || iMap.getString("SORUN_VARMI").length() == 0 || "null".equals(iMap.getString("SORUN_VARMI")) || "C".equals(iMap.getString("SORUN_VARMI"))) {

				/* 3181 EKRANI SIMULE EDILIYOR */
				iMap.putAll(GMServiceExecuter.call("CLKS_GET_3182_REQUEST_DATA", iMap));
				iMap.put("DURUM_KODU", "EVRAKSIZ");
				oMap.put("KAMPANYA_TIP", iMap.getString("KAMPANYA_TIP"));
			}
			
			GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", iMap);
			GMServiceExecuter.call("DYS_SAVE_NEW_BARCODE_FOR_CLKS", iMap);
			
			GMServiceExecuter.call("BNSPR_CUSTOMER_SET_GROUP_PERSONAL_DATA_PERMISSION", new GMMap().put("CUSTOMER_NO",
				iMap.getBigDecimal("MUSTERI_NO")).put("STATUS", "E").put("PRODUCT_CODE", PRODUCT_CODE).put(
				"IS_AUTHORIZED_TRANSACTION", "E"));

		} catch (Exception e) {
			logger.error("CLKS_PTT_CONTRACTUAL_REQUEST err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/**
	 * PTT kanal�ndan ger�ekle�en kredi ba�vurusuna ili�kin PTT emeklisi ayl�k bilgilerini saklar.
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_BIR_BASVURU_SGK_AYLIK_TX_SAVE_OR_UPDATE")
	public static GMMap ClksBirBasvuruSgkAylikTxSaveOrUpdate(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
		
			Session session = DAOSession.getSession("BNSPRDal");
		
			for (int i = 0; i < iMap.getSize("MAAS_BILGILERI"); i++) {
				
				if("200".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")) || "328".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")) || "212".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"))) {
					iMap.put("MAAS_BILGILERI", i, "EMEKLI_MAAS_EVDENMI", "E");
				} else if("201".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")) || "202".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")) || "211".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"))) {
					iMap.put("MAAS_BILGILERI", i, "EMEKLI_MAAS_EVDENMI", "H");
				}
				
				// Case: Emekli Sandigi
				if ("200".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")) || "201".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"))) {
					iMap.put("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM", "2");
				}
				
				// Case: SSK
				else if ("202".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")) || "328".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"))) {
					iMap.put("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM", "1");
				}
				
				// Case: Bagkur
				else if ("211".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")) || "212".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"))) {
					iMap.put("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM", "3");
				}
				
				for (int j = 0; j < iMap.getSize("SGK_AYLIK_BILGILERI"); j++) {
					
					// Case: Eslesbilecek bir tahsis numarasi/aylik id degeri yoksa sgk aylik bilgilerini dahil etme
					if(iMap.get("MAAS_BILGILERI", i, "TAHSIS_NUMARASI") == null || iMap.getString("MAAS_BILGILERI", i, "TAHSIS_NUMARASI").isEmpty()) {
						break;
					}
					
					if(iMap.getString("MAAS_BILGILERI", i, "TAHSIS_NUMARASI").equals(iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_ID").trim())) {
		
						iMap.put("MAAS_BILGILERI", i, "SGK_AYLIK_ID", iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_ID").trim());
						iMap.put("MAAS_BILGILERI", i, "SGK_SIGORTA_KOLU", iMap.getString("SGK_AYLIK_BILGILERI", j, "SIGORTA_KOLU").trim());
						iMap.put("MAAS_BILGILERI", i, "SGK_TAHSIS_SEKLI", iMap.getString("SGK_AYLIK_BILGILERI", j, "TAHSIS_SEKLI").trim());
						iMap.put("MAAS_BILGILERI", i, "SGK_ADI", iMap.getString("SGK_AYLIK_BILGILERI", j, "ADI").trim());
						iMap.put("MAAS_BILGILERI", i, "SGK_SOYADI", iMap.getString("SGK_AYLIK_BILGILERI", j, "SOYADI").trim());
						iMap.put("MAAS_BILGILERI", i, "SGK_AYLIK_BANKAMDA", "1".equals(iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_BANKAMDA").trim()) ? "E" : "H");
						iMap.put("MAAS_BILGILERI", i, "SGK_AYLIK_SONUC_KODU", iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_SONUC_KODU").trim());
						iMap.put("MAAS_BILGILERI", i, "SGK_AYLIK_SONUC_ACIKLAMA", iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_SONUC_ACIKLAMA").trim());
						
						break;
					}
				}
				
				ClksBirBasvuruSgkAylikTxId clksBirBasvuruSgkAylikTxId = new ClksBirBasvuruSgkAylikTxId(iMap.getBigDecimal("ISLEM_NO_BANKA"), iMap.getString("MAAS_BILGILERI", i, "TAHSIS_NUMARASI"));
				ClksBirBasvuruSgkAylikTx clksBirBasvuruSgkAylikTx = 
						(ClksBirBasvuruSgkAylikTx) session.get(ClksBirBasvuruSgkAylikTx.class, clksBirBasvuruSgkAylikTxId);
				
				if(clksBirBasvuruSgkAylikTx == null) {
					clksBirBasvuruSgkAylikTx = new ClksBirBasvuruSgkAylikTx();
				}
				
				clksBirBasvuruSgkAylikTx.setId(clksBirBasvuruSgkAylikTxId);
				clksBirBasvuruSgkAylikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				clksBirBasvuruSgkAylikTx.setEmekliMaasDonem(iMap.getString("MAAS_BILGILERI", i, "EMEKLI_MAAS_DONEM"));
				clksBirBasvuruSgkAylikTx.setEmekliMaasEvdenmi(iMap.getString("MAAS_BILGILERI", i, "EMEKLI_MAAS_EVDENMI"));
				clksBirBasvuruSgkAylikTx.setIlkMaasTarihi((iMap.get("MAAS_BILGILERI", i, "ILK_MAAS_TARIHI") != null && !iMap.getString("MAAS_BILGILERI", i, "ILK_MAAS_TARIHI").isEmpty()) ? new Date(iMap.getDate("MAAS_BILGILERI", i, "ILK_MAAS_TARIHI").getTime()) : null);
				clksBirBasvuruSgkAylikTx.setMaasAlinanKurum(iMap.getString("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"));
				clksBirBasvuruSgkAylikTx.setMaasPttDenmi(iMap.getString("MAAS_BILGILERI", i, "MAAS_PTT_DENMI"));
				clksBirBasvuruSgkAylikTx.setMaasTarihSikligi((iMap.get("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI") != null && !iMap.getString("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI").isEmpty() && !"0".equals(iMap.getString("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI") != null)) ? iMap.getBigDecimal("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI") : BigDecimal.ONE);
				clksBirBasvuruSgkAylikTx.setMaasTutari(iMap.getBigDecimal("MAAS_BILGILERI", i, "MAAS_TUTARI"));
				clksBirBasvuruSgkAylikTx.setOncekiMaasOdemeTarihi((iMap.get("MAAS_BILGILERI", i, "ONCEKI_MAAS_ODEME_TARIHI") != null && !iMap.getString("MAAS_BILGILERI", i, "ONCEKI_MAAS_ODEME_TARIHI").isEmpty()) ? new Date(iMap.getDate("MAAS_BILGILERI", i, "ONCEKI_MAAS_ODEME_TARIHI").getTime()) : null);
				clksBirBasvuruSgkAylikTx.setSonMaasTarihi((iMap.get("MAAS_BILGILERI", i, "SON_MAAS_TARIHI") != null && !iMap.getString("MAAS_BILGILERI", i, "SON_MAAS_TARIHI").isEmpty()) ? new Date(iMap.getDate("MAAS_BILGILERI", i, "SON_MAAS_TARIHI").getTime()) : null);
				clksBirBasvuruSgkAylikTx.setSgkAdi(iMap.getString("MAAS_BILGILERI", i, "SGK_ADI"));
				clksBirBasvuruSgkAylikTx.setSgkSoyadi(iMap.getString("MAAS_BILGILERI", i, "SGK_SOYADI"));
				clksBirBasvuruSgkAylikTx.setSgkAylikId(iMap.getString("MAAS_BILGILERI", i, "SGK_AYLIK_ID"));
				clksBirBasvuruSgkAylikTx.setSgkAylikBankamda(iMap.getString("MAAS_BILGILERI", i, "SGK_AYLIK_BANKAMDA"));
				clksBirBasvuruSgkAylikTx.setSgkSigortaKolu(iMap.getString("MAAS_BILGILERI", i, "SGK_SIGORTA_KOLU"));
				clksBirBasvuruSgkAylikTx.setSgkSonucKodu(iMap.getString("MAAS_BILGILERI", i, "SGK_AYLIK_SONUC_KODU"));
				clksBirBasvuruSgkAylikTx.setSgkSonucAciklama(iMap.getString("MAAS_BILGILERI", i, "SGK_AYLIK_SONUC_ACIKLAMA"));
				clksBirBasvuruSgkAylikTx.setSgkTahsisSekli(iMap.getString("MAAS_BILGILERI", i, "SGK_TAHSIS_SEKLI"));
				
				session.saveOrUpdate(clksBirBasvuruSgkAylikTx);
			}
			
			session.flush();
			
		} catch (Exception e) {
			logger.error("CLKS_BIR_BASVURU_SGK_AYLIK_TX_SAVE_OR_UPDATE err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("CLKS_GET_IBAN_FROM_SOZLESME_HESAP")
	public static GMMap clksGetIbanFromSozlesmeHesap (GMMap iMap){

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PTT_KREDI.getIbanFromSozlesmeHesapNo(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("IBAN", stmt.getString(1));
			return oMap;

		} catch(Exception e) {
			logger.error("CLKS_GET_IBAN_FROM_SOZLESME_HESAP err:", e);
			oMap.put("IBAN","00"); 
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
    }

	/**
	 * PTT kanal�ndan ger�ekle�en kredi ba�vurusuna ili�kin ba�vuru bilgilerini saklar.
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_KREDI_SAVE_OR_UPDATE")
	public static GMMap ClksPTTCreditSaveorUpdate(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			// Case: Kullandirim > Basvuru Akisi
			if("0".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {
				
				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class,
						iMap.getBigDecimal("CLKS_TRX_NO"),
						LockMode.UPGRADE_NOWAIT);
				
				clksBirBasvuruTx.setBirBasvuruTxNo(iMap.getBigDecimal("BNSPR_TRX_NO"));
				
				session.saveOrUpdate(clksBirBasvuruTx);
				session.flush();
			} 
			
			// Case: FIRST_INITIAL_REQUEST
			else if("1".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {

				// Basvuru Numarasi al
				if(iMap.getString("BASVURU_NO") == null || iMap.getString("BASVURU_NO").isEmpty()) {
					iMap.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", new GMMap()).getBigDecimal("ID"));
				}

				// Tx al
				if(iMap.get("ISLEM_NO_BANKA") == null || iMap.getString("ISLEM_NO_BANKA").isEmpty()) {
					iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
					iMap.put("ISLEM_NO_BANKA", iMap.getBigDecimal("TRX_NO"));
				} else {
					iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO_BANKA"));
				}

				ClksBirBasvuruKimlikTx clksBirBasvuruKimlikTx = (ClksBirBasvuruKimlikTx) session.get(ClksBirBasvuruKimlikTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);

				if(clksBirBasvuruKimlikTx == null) {
					clksBirBasvuruKimlikTx = new ClksBirBasvuruKimlikTx();
				}

				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);

				if(clksBirBasvuruTx == null) {
					clksBirBasvuruTx = new ClksBirBasvuruTx();
				}

				clksBirBasvuruTx.setTxNo(iMap.getBigDecimal("ISLEM_NO_BANKA"));
				clksBirBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				clksBirBasvuruTx.setVade(iMap.getBigDecimal("VADE"));
				clksBirBasvuruTx.setTutar(iMap.getBigDecimal("TUTAR"));
				clksBirBasvuruTx.setDovizKodu(iMap.getString("DOVIZ_KOD"));
				clksBirBasvuruTx.setPostaCekiHesabi(iMap.getString("POSTA_CEK_HESABI"));
				clksBirBasvuruTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
				clksBirBasvuruTx.setKrediTur(iMap.getBigDecimal("KRD_TUR_KOD"));
				clksBirBasvuruTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				clksBirBasvuruTx.setKurum(iMap.getString("MAAS_ALINAN_KURUM"));
				clksBirBasvuruTx.setSgkMaasTutar(iMap.getBigDecimal("MAAS_TUTARI"));
				clksBirBasvuruTx.setIslemiYapanKullanici(iMap.getString("ISLEMI_YAPAN_KULLANICI"));
				clksBirBasvuruTx.setIslemiYapanKullAdsoyad(iMap.getString("ISLEMI_YAPANKULLANICI_ADSOYAD"));
				clksBirBasvuruTx.setIsleminYapildigiYer(iMap.getString("ISLEMIN_YAPILDIGI_YER"));
				clksBirBasvuruTx.setIsleminYapildigiIl(iMap.getString("ISLEMIN_YAPILDIGI_IL"));
				clksBirBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));
				clksBirBasvuruTx.setMaasPttDenmi(iMap.getString("MAAS_PTT_DENMI"));
				clksBirBasvuruTx.setKanalKodu(iMap.getString("KANAL_KOD"));
				clksBirBasvuruTx.setTahsisNumarasi(iMap.getString("TAHSIS_NUMARASI"));
				clksBirBasvuruTx.setMaasTarihSikligi(!"".equals(iMap.get("MAAS_TARIH_SIKLIGI")) ? iMap.getBigDecimal("MAAS_TARIH_SIKLIGI") : new BigDecimal(1));
				clksBirBasvuruTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
				clksBirBasvuruTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
				clksBirBasvuruTx.setBasvuruAdim(new BigDecimal("1"));
				clksBirBasvuruTx.setMerkezSubeBasmudurluk(iMap.getString("MERKEZ_SUBE_BASMUDURLUK"));
				clksBirBasvuruTx.setIsleminYapildigiBasmudurluk(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				clksBirBasvuruTx.setEmekliMaasEvdenmi(iMap.getString("EMEKLI_MAAS_EVDENMI"));
				clksBirBasvuruTx.setEmekliMaasDonem(iMap.getString("EMEKLI_MAAS_DONEM"));
				clksBirBasvuruTx.setSgkSonucKodu(iMap.getString("SGK_SONUC_KODU"));
				clksBirBasvuruTx.setSgkSonucAciklama(iMap.getString("SGK_SONUC_ACIKLAMA"));
				clksBirBasvuruTx.setEkDokuman(iMap.getString("EK_DOKUMAN"));
				clksBirBasvuruTx.setfKonsolidasyonKredisi(iMap.getMap("KAMPANYA").getBoolean("BIRLESTIRME_EH") ? "E"
					: "H");
				clksBirBasvuruTx.setSentetikEmekliMaasOdemesi(iMap.getBoolean("F_SYNTHETIC_PENSION_PAYMENT") ? "1"
					: "0");
				
				if(iMap.getString("SON_MAAS_TARIHI") != null && !"".equals(iMap.getString("SON_MAAS_TARIHI", ""))) {
					clksBirBasvuruTx.setSonMaasTarihi(new Date(iMap.getDate("SON_MAAS_TARIHI").getTime()));
				} else {
					clksBirBasvuruTx.setSonMaasTarihi(null);
				}

				if(iMap.getString("ILK_MAAS_TARIHI") != null && !"".equals(iMap.getString("ILK_MAAS_TARIHI", ""))) {
					clksBirBasvuruTx.setIlkMaasTarihi(new Date(iMap.getDate("ILK_MAAS_TARIHI").getTime()));
				} else {
					clksBirBasvuruTx.setIlkMaasTarihi(null);
				}

				if(iMap.getString("ONCEKI_MAAS_ODEME_TARIHI") != null && !"".equals(iMap.getString("ONCEKI_MAAS_ODEME_TARIHI", ""))
					&& !"00.00.0000".equals(iMap.getString("ONCEKI_MAAS_ODEME_TARIHI", ""))
					&& !"99999999".equals(iMap.getString("ONCEKI_MAAS_ODEME_TARIHI", ""))) {
					clksBirBasvuruTx.setOncekiMaasOdemeTarihi(new Date(iMap.getDate("ONCEKI_MAAS_ODEME_TARIHI").getTime()));
				} else {
					clksBirBasvuruTx.setOncekiMaasOdemeTarihi(null);
				}
				
				clksBirBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("ISLEM_NO_BANKA"));
				clksBirBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				clksBirBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
				clksBirBasvuruKimlikTx.setUyrukKod(iMap.getString("UYRUK"));
				clksBirBasvuruKimlikTx.setAd(iMap.getString("ADI"));
				clksBirBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
				clksBirBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
				clksBirBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
				clksBirBasvuruKimlikTx.setDogumTar(!"".equals(iMap.get("DOGUM_TARIHI")) ? iMap.getDate("DOGUM_TARIHI") : null);
				clksBirBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
				clksBirBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO"));
				clksBirBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS"));
				clksBirBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS"));
				clksBirBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO"));
				clksBirBasvuruKimlikTx.setOncekiSoyad(iMap.getString("ONCEKI_SOYADI"));
				clksBirBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
				clksBirBasvuruKimlikTx.setCepTelAlanKodu(iMap.getString("CEP_TEL_KOD"));
				clksBirBasvuruKimlikTx.setCepTelNo(iMap.getString("CEP_TEL_NO"));
				clksBirBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
				clksBirBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
				clksBirBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
				clksBirBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
				clksBirBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
				clksBirBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
				clksBirBasvuruKimlikTx.setNufusVerTar(!"".equals(iMap.get("NUFUS_VERILIS_TARIHI")) ? iMap.getDate("NUFUS_VERILIS_TARIHI") : null);
				clksBirBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
				clksBirBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
				clksBirBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
				clksBirBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
				clksBirBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
				clksBirBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
				clksBirBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
				clksBirBasvuruKimlikTx.setKimlikKayitNo(iMap.getString("KIMLIK_KAYIT_NO"));
				clksBirBasvuruKimlikTx.setCalismaSekli(iMap.get("CALISMA_SEKLI") == null || "".equals(iMap.getString("CALISMA_SEKLI")) ? "E" : iMap.getString("CALISMA_SEKLI"));
				clksBirBasvuruKimlikTx.setUnvanKod(iMap.getString("UNVANI"));
				clksBirBasvuruKimlikTx.setPttUnvanKod(iMap.getString("PTT_UNVAN_KOD"));
				clksBirBasvuruKimlikTx.setEsTckn(iMap.getString("ES_TCKN"));
				
				if(iMap.getMap("KAMPANYA").getBoolean("BORC_TRANSFERI_EH")) {
					
					ClksBbBorcTransferi clksBbBorcTransferi = (ClksBbBorcTransferi) session.get(
						ClksBbBorcTransferi.class, iMap.getBigDecimal("BASVURU_NO"));
					
					if(clksBbBorcTransferi == null) {
						clksBbBorcTransferi = new ClksBbBorcTransferi(iMap.getBigDecimal("BASVURU_NO"));
						clksBbBorcTransferi.setIban(iMap.get("BORC_TRANSFERI", 0, "IBAN") != null ? iMap.getString(
							"BORC_TRANSFERI", 0, "IBAN") : clksBbBorcTransferi.getIban());
						clksBbBorcTransferi.setBankaKod(iMap.get("BORC_TRANSFERI", 0, "BORC_BANKA_KODU") != null ? iMap.getString(
							"BORC_TRANSFERI", 0, "BORC_BANKA_KODU") : clksBbBorcTransferi.getBankaKod());
						clksBbBorcTransferi.setSubeKod(iMap.get("BORC_TRANSFERI", 0, "BORC_SUBE_KODU") != null ? iMap.getString(
							"BORC_TRANSFERI", 0, "BORC_SUBE_KODU") : clksBbBorcTransferi.getSubeKod());
					}
					session.saveOrUpdate(clksBbBorcTransferi);
				}
				
				session.saveOrUpdate(clksBirBasvuruTx);
				session.saveOrUpdate(clksBirBasvuruKimlikTx);
				session.flush();
			}

			// Case: INITIAL_REQUEST
			else if("2".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {
				
				ClksBirBasvuruKimlikTx clksBirBasvuruKimlikTx = (ClksBirBasvuruKimlikTx) session.get(ClksBirBasvuruKimlikTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);
				
				if((iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty()) && clksBirBasvuruKimlikTx.getCepTelNo() == null) {
					iMap.put("HATA_NO", 2067);
					iMap.put("P1", "Cep Tel No bo� Ge�ildi�i i�in Ev Tel No");
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				clksBirBasvuruKimlikTx.setMeslekKod(iMap.getString("MESLEK"));
				clksBirBasvuruKimlikTx.setUnvanKod(iMap.getString("UNVANI"));
				clksBirBasvuruKimlikTx.setPttUnvanKod(iMap.getString("PTT_UNVAN_KOD"));
				clksBirBasvuruKimlikTx.setIsyeriFaalKonuKod(iMap.getString("ISYERI_FAALIYET_ALANI"));
				clksBirBasvuruKimlikTx.setIsyeriAdi(iMap.getString("ISYERI_ADI") != null ? iMap.getString("ISYERI_ADI").trim() : "");
				clksBirBasvuruKimlikTx.setIsyeriMulkiyetKod(iMap.getString("ISYERI_MULKIYET"));
				clksBirBasvuruKimlikTx.setIsyerindeCalismaSuresi(concatYilAy(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL"),
					iMap.getString("ISYERINDE_CALISMA_SURESI_AY")));
				clksBirBasvuruKimlikTx.setAdresteFaaliyetSuresi(concatYilAy(iMap.getString("FAALIYET_SURESI_YIL"), iMap.getString("FAALIYET_SURESI_AY")));																													// birlestir
				clksBirBasvuruKimlikTx.setIsyeriVergiIlKodu(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
				clksBirBasvuruKimlikTx.setIsyeriVergiDaireKodu(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
				clksBirBasvuruKimlikTx.setIsyeriVergiNo(iMap.getString("ISYERI_VERGI_NO"));
				clksBirBasvuruKimlikTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
				clksBirBasvuruKimlikTx.setMenkulGmenkulGeliri(iMap.getBigDecimal("GMENKUL_GELIR"));
				clksBirBasvuruKimlikTx.setEsGeliri(iMap.getBigDecimal("ES_GELIRI") == null ? BigDecimal.ZERO : iMap.getBigDecimal("ES_GELIRI"));
				clksBirBasvuruKimlikTx.setDigerGelir(iMap.getBigDecimal("DIGER_GELIR"));
				clksBirBasvuruKimlikTx.setEvAdres(iMap.getString("EV_ADRESI") != null ? iMap.getString("EV_ADRESI").trim() : "");
				clksBirBasvuruKimlikTx.setIsAdres(iMap.getString("IS_ADRESI") != null ? iMap.getString("IS_ADRESI").trim() : "");				
				clksBirBasvuruKimlikTx.setEvAdrIlKod(iMap.getString("EV_IL"));
				clksBirBasvuruKimlikTx.setIsAdrIlKod(iMap.getString("IS_IL"));
				clksBirBasvuruKimlikTx.setIsAdrIlceKod(iMap.getString("IS_ILCE"));
				clksBirBasvuruKimlikTx.setEvAdrIlceKod(iMap.getString("EV_ILCE"));
				clksBirBasvuruKimlikTx.setIsAdrUlkeKod("TR");
				clksBirBasvuruKimlikTx.setEvPostakod(iMap.getString("EV_POSTA_KODU"));
				clksBirBasvuruKimlikTx.setIsPostakod(iMap.getString("IS_POSTA_KODU"));

				if(iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
					clksBirBasvuruKimlikTx.setEvTelAlan(iMap.getString("EV_TEL_KOD"));
					clksBirBasvuruKimlikTx.setEvTelNo(iMap.getString("EV_TEL_NO"));
				} else {
					clksBirBasvuruKimlikTx.setEvTelAlan("");
					clksBirBasvuruKimlikTx.setEvTelNo("");
				}

				if(iMap.getString("IS_TEL_NO") != null && !iMap.getString("IS_TEL_NO").isEmpty()) {
					clksBirBasvuruKimlikTx.setIsTelAlan(iMap.getString("IS_TEL_KOD"));
					clksBirBasvuruKimlikTx.setIsTelNo(iMap.getString("IS_TEL_NO"));
					clksBirBasvuruKimlikTx.setIsTelDahili(iMap.getString("IS_TEL_DAHILI"));
				} else {
					clksBirBasvuruKimlikTx.setIsTelAlan(iMap.getString(""));
					clksBirBasvuruKimlikTx.setIsTelNo(iMap.getString(""));
					clksBirBasvuruKimlikTx.setIsTelDahili(iMap.getString(""));
				}

				if((iMap.getString("EMAIL1") != null && !iMap.getString("EMAIL1").isEmpty())
					&& (iMap.getString("EMAIL2") != null && !iMap.getString("EMAIL2").isEmpty())) {
					clksBirBasvuruKimlikTx.setEMail(iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));
				} else {
					clksBirBasvuruKimlikTx.setEMail("");
				}
				
				if(iMap.getBoolean("YAZISMA_ADRESI_EV"))
					clksBirBasvuruKimlikTx.setYazismaAdresKod("E");
				if(iMap.getBoolean("YAZISMA_ADRESI_EV"))
					clksBirBasvuruKimlikTx.setYazismaAdresKod("E");
				else if(iMap.getBoolean("YAZISMA_ADRESI_IS"))
					clksBirBasvuruKimlikTx.setYazismaAdresKod("I");
				
				clksBirBasvuruKimlikTx.setSigortaliMi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("SIGORTALI_MI")));
				clksBirBasvuruKimlikTx.setUlasimKartNo(iMap.getString("ULASIM_KART_NO"));

				if(iMap.getString("TESLIMAT_ADRESI") != null) {
					clksBirBasvuruKimlikTx.setTeslimatAdresi(iMap.getString("TESLIMAT_ADRESI").trim());
				} else {
					clksBirBasvuruKimlikTx.setTeslimatAdresi("");
				}
				clksBirBasvuruKimlikTx.setTeslimatAdrIlKod(iMap.getString("TESLIMAT_ADR_IL"));
				clksBirBasvuruKimlikTx.setTeslimatAdrIlceKod(iMap.getString("TESLIMAT_ADR_ILCE"));
				
				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);
			
				clksBirBasvuruTx.setOdemeTipKod(iMap.getBigDecimal("ODEME_TIPI"));
				clksBirBasvuruTx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAFI"));

				if(iMap.getString("SERBEST_KATKI_PAYI") != null && !"H".equals(iMap.getString("SERBEST_KATKI_PAYI"))) {
					clksBirBasvuruTx.setSerbestKatkiPayi(iMap.getBigDecimal("KATILIM_BEDELI"));
				} else {
					clksBirBasvuruTx.setSerbestKatkiPayi(null);
				}

				clksBirBasvuruTx.setOdemeTipTut(iMap.getBigDecimal("ODEME_TUTARI"));
				clksBirBasvuruTx.setOdemeTipVade(iMap.getBigDecimal("ODEME_VADESI"));
				clksBirBasvuruTx.setOdemeTipPeriyod(iMap.getBigDecimal("ODEME_PERIYODU"));
				clksBirBasvuruTx.setOdemeTipOran(iMap.getBigDecimal("ODEME_ORANI"));
				clksBirBasvuruTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
				if(iMap.getString("DOSYA_MASRAF_TIPI") != null && !"Y".equals(iMap.getString("DOSYA_MASRAF_TIPI"))) {
					clksBirBasvuruTx.setSozlesmeFaizi(iMap.getBigDecimal("SOZLESME_FAIZI"));
				} else {
					clksBirBasvuruTx.setSozlesmeFaizi(null);
				}

				clksBirBasvuruTx.setGorus(iMap.getString("DIGER_GORUS"));
				clksBirBasvuruTx.setGorus(iMap.getString("GORUS"));
				clksBirBasvuruTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
				clksBirBasvuruTx.setBankaKod(iMap.getString("BANKA_KOD"));
				clksBirBasvuruTx.setSubeKod(iMap.getString("SUBE_KOD"));
				clksBirBasvuruTx.setIlKod(iMap.getString("IL_KOD"));
				clksBirBasvuruTx.setHesapNo(iMap.getString("HESAP_NO"));
				clksBirBasvuruTx.setBasvuruAdim(new BigDecimal("2"));

				if(iMap.getString("MAAS_TARIH_SIKLIGI") != null && iMap.getString("MAAS_TARIH_SIKLIGI").compareTo("") != 0) {
					clksBirBasvuruTx.setMaasTarihSikligi(iMap.getBigDecimal("MAAS_TARIH_SIKLIGI"));
				} else {
					iMap.put("MAAS_TARIH_SIKLIGI", "1");
					clksBirBasvuruTx.setMaasTarihSikligi(iMap.getBigDecimal("MAAS_TARIH_SIKLIGI"));
				}

				iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO_BANKA"));

				session.saveOrUpdate(clksBirBasvuruTx); 
				session.saveOrUpdate(clksBirBasvuruKimlikTx);
				session.flush();
			}

			// Case: CONFIRM
			else if("3".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {
				
				ClksBirBasvuruKimlikTx clksBirBasvuruKimlikTx = (ClksBirBasvuruKimlikTx) session.get(ClksBirBasvuruKimlikTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);
				
				clksBirBasvuruKimlikTx.setKimlikBilgileriUyumlumu(iMap.getString("KIMLIK_BILGILERI_UYUMLUMU"));
				clksBirBasvuruKimlikTx.setAdresBilgileriUyumlumu(iMap.getString("ADRES_BILGILERI_UYUMLUMU"));
				clksBirBasvuruKimlikTx.setEvAdresAps(iMap.getString("EV_ADRES_APS"));
				clksBirBasvuruKimlikTx.setEvAdrIlceKodAps(iMap.getString("EV_ADR_IL_KOD_APS"));
				clksBirBasvuruKimlikTx.setEvAdrIlKodAps(iMap.getString("EV_ADR_ILCE_KOD_APS"));
				clksBirBasvuruKimlikTx.setEvPostakodAps(iMap.getString("EV_POSTAKOD_APS"));

				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);
				
				clksBirBasvuruTx.setApsYapildimi(iMap.getString("APS_YAPILDIMI"));
				clksBirBasvuruTx.setBasvuruAdim(new BigDecimal("3"));

				session.saveOrUpdate(clksBirBasvuruTx); 
				session.saveOrUpdate(clksBirBasvuruKimlikTx); 
				session.flush();
			}

			// Case: PAYMENT_PLAN_REQUEST (Sozlesme Basim)
			if("4".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {

				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);

				clksBirBasvuruTx.setOtelemeGunSayisi(iMap.getBigDecimal("TAKSIT_ODEME_GUNU"));
				clksBirBasvuruTx.setBasvuruAdim(new BigDecimal("4"));
				clksBirBasvuruTx.setIslemiYapanKullSozlesme(iMap.getString("ISLEMI_YAPAN_KULLANICI_SOZLESME"));
				clksBirBasvuruTx.setIsleminYapildigiIlSozlesme(iMap.getString("ISLEMIN_YAPILDIGI_IL_SOZLESME"));
				clksBirBasvuruTx.setIsleminYapilMerkezSozlesme(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ_SOZLESME"));
				clksBirBasvuruTx.setIslemYapildigiSubeSozlesme(iMap.getString("ISLEMIN_YAPILDIGI_SUBE_SOZLESME"));
				clksBirBasvuruTx.setMerkezSubeBasmudurlukSozles(iMap.getString("MERKEZ_SUBE_BASMUDURLUK_SOZLESME"));
				clksBirBasvuruTx.setIslemYapilBasmudurlukSoz(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK_SOZLESME"));
				
				session.saveOrUpdate(clksBirBasvuruTx);
				session.flush();
			}

			// Case: PAYMENT_PLAN_CONFIRM
			else if("5".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {

				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);
				
				clksBirBasvuruTx.setBasvuruAdim(new BigDecimal("5"));
				clksBirBasvuruTx.setBarkodNumarasiSozlesme(iMap.getString("BARKOD_NUMARASI"));

				session.saveOrUpdate(clksBirBasvuruTx);
				session.flush();
			}

			// Case: CONTRACTUAL_REQUEST (Kullandirim)
			else if("6".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {

				ClksBirBasvuruKimlikTx clksBirBasvuruKimlikTx = (ClksBirBasvuruKimlikTx) session.get(ClksBirBasvuruKimlikTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);

				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class,
					iMap.getBigDecimal("ISLEM_NO_BANKA"),
					LockMode.UPGRADE_NOWAIT);

				iMap.put("TAHSIS_NUMARASI", clksBirBasvuruTx.getTahsisNumarasi());
				iMap.put("MAAS_ALINAN_KURUM", clksBirBasvuruTx.getKurum());
				iMap.put("SIGORTA_KOLU", "1".equals(iMap.getString("MAAS_ALINAN_KURUM")) ? "4A" 
					: ("3".equals(iMap.getString("MAAS_ALINAN_KURUM")) ? "4B"
					: ("2".equals(iMap.getString("MAAS_ALINAN_KURUM")) ? "4C" : "")));
				iMap.put("TC_KIMLIK_NO", clksBirBasvuruKimlikTx.getTcKimlikNo());

				clksBirBasvuruTx.setBasvuruAdim(new BigDecimal("6"));
				clksBirBasvuruTx.setBasvuruSorunVarmi(iMap.getString("SORUN_VARMI"));
				clksBirBasvuruTx.setIslemiYapanKullaniciEvrak(iMap.getString("ISLEMI_YAPAN_KULLANICI_EVRAK"));
				clksBirBasvuruTx.setIsleminYapildigiIlEvrak(iMap.getString("ISLEMIN_YAPILDIGI_IL_EVRAK"));
				clksBirBasvuruTx.setIsleminYapildigiSubeEvrak(iMap.getString("ISLEMIN_YAPILDIGI_SUBE_EVRAK"));
				clksBirBasvuruTx.setIsleminYapildigiMerkezEvrak(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ_EVRAK"));
				clksBirBasvuruTx.setMerkezSubeBasmudurlukEvrak(iMap.getString("MERKEZ_SUBE_BASMUDURLUK_EVRAK"));
				clksBirBasvuruTx.setIslemYapilBasmudurlukEvrak(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK_EVRAK"));
				clksBirBasvuruTx.setSgkBlokeSonucKodu(iMap.getString("SGK_BLOKE_SONUC_KODU"));
				clksBirBasvuruTx.setSgkBlokeSonucAciklama(iMap.getString("SGK_BLOKE_SONUC_ACIKLAMA"));

				session.saveOrUpdate(clksBirBasvuruTx);
				session.flush();

			} else if("7".equals(iMap.getString("KONTROL_SAVE_OR_UPDATE"))) {
					ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class,
						iMap.getBigDecimal("ISLEM_NO_BANKA"),
						LockMode.UPGRADE_NOWAIT);
					iMap.put("MAAS_ALINAN_KURUM", clksBirBasvuruTx.getKurum());
			} 
			
		} catch(Exception e) {
			
			logger.error("CLKS_PTT_KREDI_SAVE_OR_UPDATE err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return iMap;
	}
	@GraymoundService("CLKS_CONVERT_SMS_APPLICATION_TO_RETIREE_APPLICATION")
	public static GMMap ClksConvertSmsApplicationtoRetireeApplication(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {
				
			GMMap smsMap= GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_INFO", new GMMap().put("TC_KIMLIK_NO",iMap.getString("TCKN")));
			if (!StringUtil.isEmpty(smsMap.getString("BASVURU_NO")) && "E".equals(smsMap.getString("SOZLESME_BASABILIR")) ) {
				
			iMap.put("basvuruNo", smsMap.getBigDecimal("BASVURU_NO"));
			
			Session session = DAOSession.getSession("BNSPRDal");
					
			ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session
					.createCriteria(ClksBirBasvuruSmsTalep.class)
					.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("basvuruNo"))).uniqueResult();
	
			
//			GMServiceExecuter.call("BNSPR_TRN3172_UPDATE_APPLICATION", new GMMap()
//			.put("BASVURU_NO", clksBirBasvuruSmsTalep.getBasvuruNo()));
			if (clksBirBasvuruSmsTalep!=null) {
				
				ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session
						.createCriteria(ClksBirBasvuruTx.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("basvuruNo"))).uniqueResult();
	
					if(clksBirBasvuruTx == null) {
						clksBirBasvuruTx = new ClksBirBasvuruTx();
						clksBirBasvuruTx.setTxNo(clksBirBasvuruSmsTalep.getTxNo());
					}
				
				clksBirBasvuruTx.setBasvuruNo(clksBirBasvuruSmsTalep.getBasvuruNo());
				clksBirBasvuruTx.setVade(clksBirBasvuruSmsTalep.getVade());
				clksBirBasvuruTx.setTutar(clksBirBasvuruSmsTalep.getTutar());
				clksBirBasvuruTx.setDovizKodu("TRY");
	
				clksBirBasvuruTx.setKurum(clksBirBasvuruSmsTalep.getMaasAlinanKurum());
	
				clksBirBasvuruTx.setMaasPttDenmi(clksBirBasvuruSmsTalep.getAylikBankamda());
				clksBirBasvuruTx.setTahsisNumarasi(clksBirBasvuruSmsTalep.getTahsisNumarasi());
	
				clksBirBasvuruTx.setBasvuruAdim(new BigDecimal("1"));
	
				clksBirBasvuruTx.setEmekliMaasEvdenmi(clksBirBasvuruSmsTalep.getPttMaasEvdenMi().toString());
				clksBirBasvuruTx.setSgkSonucKodu(clksBirBasvuruSmsTalep.getSgkSonucKodu());
				clksBirBasvuruTx.setSgkSonucAciklama(clksBirBasvuruSmsTalep.getSgkSonucAciklama());
				clksBirBasvuruTx.setfKonsolidasyonKredisi("H");
				clksBirBasvuruTx.setSentetikEmekliMaasOdemesi("0");
				
				clksBirBasvuruTx.setSonMaasTarihi(clksBirBasvuruSmsTalep.getSonMaasTarihi());
	
				clksBirBasvuruTx.setIlkMaasTarihi(clksBirBasvuruSmsTalep.getIlkMaasTarihi());
	
				clksBirBasvuruTx.setOncekiMaasOdemeTarihi(clksBirBasvuruSmsTalep.getOncekiMaasOdemeTarihi());
				clksBirBasvuruTx.setKampKnlKod(new BigDecimal(DALUtil.getResult("SELECT deger FROM bnspr.gnl_parametre WHERE KOD = 'PTT_SMS_SUBE_EMEKLI_KAMP'")));
	
				   clksBirBasvuruTx.setIsleminYapildigiSube(iMap.getString("isleminYapildigiSube"));
				   clksBirBasvuruTx.setIsleminYapildigiMerkez(iMap.getString("isleminYapildigiMerkez"));
				   clksBirBasvuruTx.setIsleminYapildigiBasmudurluk( iMap.getString("isleminYapildigiBasmudurluk"));
				   clksBirBasvuruTx.setMerkezSubeBasmudurluk(iMap.getString("merkezSubeBasmudurluk"));
				   clksBirBasvuruTx.setIsleminYapildigiIl(iMap.getString("pttSubeIl"));
				   
	//		clksBirBasvuruTx.setPostaCekiHesabi(iMap.getString("POSTA_CEK_HESABI"));
	//		clksBirBasvuruTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
	//		clksBirBasvuruTx.setKrediTur(iMap.getBigDecimal("KRD_TUR_KOD"));
	//		clksBirBasvuruTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
	//		clksBirBasvuruTx.setSgkMaasTutar(iMap.getBigDecimal("MAAS_TUTARI"));
	//		clksBirBasvuruTx.setIslemiYapanKullanici(iMap.getString("ISLEMI_YAPAN_KULLANICI"));
	//		clksBirBasvuruTx.setIslemiYapanKullAdsoyad(iMap.getString("ISLEMI_YAPANKULLANICI_ADSOYAD"));
	//		clksBirBasvuruTx.setIsleminYapildigiYer(iMap.getString("ISLEMIN_YAPILDIGI_YER"));
	//		clksBirBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));
	//		clksBirBasvuruTx.setKanalKodu(iMap.getString("KANAL_KOD"));
	//		clksBirBasvuruTx.setMaasTarihSikligi(!"".equals(iMap.get("MAAS_TARIH_SIKLIGI")) ? iMap.getBigDecimal("MAAS_TARIH_SIKLIGI") : new BigDecimal(1));
	//		clksBirBasvuruTx.setEmekliMaasDonem(iMap.getString("EMEKLI_MAAS_DONEM"));
	//		clksBirBasvuruTx.setEkDokuman(iMap.getString("EK_DOKUMAN"));
				   
					session.saveOrUpdate(clksBirBasvuruTx);
					session.flush();
	
				ClksBirBasvuruKimlikTx clksBirBasvuruKimlikTx = (ClksBirBasvuruKimlikTx) session
						.createCriteria(ClksBirBasvuruKimlikTx.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
	
					if(clksBirBasvuruKimlikTx == null) {
						clksBirBasvuruKimlikTx = new ClksBirBasvuruKimlikTx();
					}
					
					List<BirBasvuruKimlikTx> birBasvuruKimliklist =  session.createCriteria(BirBasvuruKimlikTx.class)
							.add(Restrictions.eq("basvuruNo", clksBirBasvuruSmsTalep.getBasvuruNo()))
			                .addOrder(Order.desc("txNo"))
			                .list();
					
					if (birBasvuruKimliklist.size()>0) {
						BirBasvuruKimlikTx birBasvuruKimlik =birBasvuruKimliklist.get(0);
					
						clksBirBasvuruKimlikTx.setTxNo(clksBirBasvuruTx.getTxNo());
						clksBirBasvuruKimlikTx.setBasvuruNo(birBasvuruKimlik.getBasvuruNo());
						clksBirBasvuruKimlikTx.setTcKimlikNo(birBasvuruKimlik.getTcKimlikNo());
						clksBirBasvuruKimlikTx.setUyrukKod(birBasvuruKimlik.getUyrukKod());
						clksBirBasvuruKimlikTx.setAd(birBasvuruKimlik.getAd());
						clksBirBasvuruKimlikTx.setIkinciAd(birBasvuruKimlik.getIkinciAd());
						clksBirBasvuruKimlikTx.setSoyad(birBasvuruKimlik.getSoyad());
						clksBirBasvuruKimlikTx.setDogumYeri(birBasvuruKimlik.getDogumYeri());
						clksBirBasvuruKimlikTx.setDogumTar(birBasvuruKimlik.getDogumTar());
						clksBirBasvuruKimlikTx.setBabaAd(birBasvuruKimlik.getBabaAd());
						clksBirBasvuruKimlikTx.setKimlikSeriNo(birBasvuruKimlik.getKimlikSeriNo());
						clksBirBasvuruKimlikTx.setKimlikSeriNoKps(birBasvuruKimlik.getKimlikSeriNoKps());
						clksBirBasvuruKimlikTx.setKimlikSiraNo(birBasvuruKimlik.getKimlikSiraNo());
						clksBirBasvuruKimlikTx.setKimlikSiraNoKps(birBasvuruKimlik.getKimlikSiraNoKps());
						clksBirBasvuruKimlikTx.setOncekiSoyad(birBasvuruKimlik.getOncekiSoyad());
						clksBirBasvuruKimlikTx.setAnneKizlik(birBasvuruKimlik.getAnneKizlik());
						clksBirBasvuruKimlikTx.setCepTelAlanKodu(birBasvuruKimlik.getCepTelAlanKodu());
						clksBirBasvuruKimlikTx.setCepTelNo(birBasvuruKimlik.getCepTelNo());
						clksBirBasvuruKimlikTx.setAnneAdi(birBasvuruKimlik.getAnneAdi());
						clksBirBasvuruKimlikTx.setNufusIlKod(birBasvuruKimlik.getNufusIlKod());
						clksBirBasvuruKimlikTx.setNufusIlceKod(birBasvuruKimlik.getNufusIlceKod());
						clksBirBasvuruKimlikTx.setCiltNo(birBasvuruKimlik.getCiltNo());
						clksBirBasvuruKimlikTx.setAileSiraNo(birBasvuruKimlik.getAileSiraNo());
						clksBirBasvuruKimlikTx.setBireySiraNo(birBasvuruKimlik.getBireySiraNo());
						clksBirBasvuruKimlikTx.setNufusVerTar(birBasvuruKimlik.getNufusVerTar());
						clksBirBasvuruKimlikTx.setCinsiyet(birBasvuruKimlik.getCinsiyet());
						clksBirBasvuruKimlikTx.setMedeniHal(birBasvuruKimlik.getMedeniHal());
						clksBirBasvuruKimlikTx.setKayipKimlikSiraNo(birBasvuruKimlik.getKayipKimlikSiraNo());
						clksBirBasvuruKimlikTx.setKayipKimlikSeriNo(birBasvuruKimlik.getKayipKimlikSeriNo());
						clksBirBasvuruKimlikTx.setNufusVerNedeni(birBasvuruKimlik.getNufusVerNedeni());
						clksBirBasvuruKimlikTx.setNufusVerYer(birBasvuruKimlik.getNufusVerYer());
						clksBirBasvuruKimlikTx.setMahalleKoy(birBasvuruKimlik.getMahalleKoy());
						clksBirBasvuruKimlikTx.setKimlikKayitNo(birBasvuruKimlik.getKimlikKayitNo());
						clksBirBasvuruKimlikTx.setCalismaSekli(birBasvuruKimlik.getCalismaSekli());
						clksBirBasvuruKimlikTx.setUnvanKod(birBasvuruKimlik.getUnvanKod());
						clksBirBasvuruKimlikTx.setEsTckn(birBasvuruKimlik.getEsTckn());
						clksBirBasvuruKimlikTx.setEvAdres(birBasvuruKimlik.getEvAdres());
						clksBirBasvuruKimlikTx.setEvAdrIlKod(birBasvuruKimlik.getEvAdrIlKod());
						clksBirBasvuruKimlikTx.setEvAdrIlceKod(birBasvuruKimlik.getEvAdrIlceKod());
						clksBirBasvuruKimlikTx.setEvAdrUlkeKod(birBasvuruKimlik.getEvAdrUlkeKod());
						clksBirBasvuruKimlikTx.setEvPostakod(birBasvuruKimlik.getEvPostakod());
						clksBirBasvuruKimlikTx.setBasvuruTarihi(birBasvuruKimlik.getBasvuruTarihi());
						clksBirBasvuruKimlikTx.setYazismaAdresKod(birBasvuruKimlik.getYazismaAdresKod());
						clksBirBasvuruKimlikTx.setAylikGelir(birBasvuruKimlik.getAylikGelir());
						clksBirBasvuruKimlikTx.setMenkulGmenkulGeliri(birBasvuruKimlik.getMenkulGmenkulGeliri());
						session.saveOrUpdate(clksBirBasvuruKimlikTx);			

				}
					
				session.saveOrUpdate(clksBirBasvuruTx);
 				
				if("E".equals(smsMap.getString("SOZLESME_BASABILIR")))
				{
					BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, smsMap.getBigDecimal("BASVURU_NO"), LockMode.UPGRADE_NOWAIT); 
//					birBasvuru.setDurumKodu("SOZLESME"); // Kanal iadeye neden oldu�u i�in kald�r�ld� sorguya KUL ve kurye se�imi olanlar eklendi.
					clksBirBasvuruTx.setMaasTarihSikligi(birBasvuru.getPttMaasTarihSikligi()); // Asl�nda CLKS_BIRBASVURU_SMS TALEP Tablosunda b�yle bir alan olmal�yd�
					session.saveOrUpdate(birBasvuru);		
				}
				
				}
			session.flush();
			}
		} catch(Exception e) {			
			logger.error("CLKS_CONVERT_SMS_APPLICATION_TO_RETIREE_APPLICATION err : ", e);
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * PTT kanal�ndan ger�ekle�en kredi ba�vurusuna ili�kin kontakt m��teri g�ncelleme kabuk servisi.
	 * 
	 * @param iMap	GMMap
	 * @return
	 * 
	 * @see 		tr.com.calikbank.bnspr.consumerloan.services.ConsumerLoanTRN3171Services#kontaktMusteriOlustur 
	 * 				BNSPR_TRN3171_KONTAKT_MUSTERI
	 */
	@GraymoundService("CLKS_PTT_KONTAKT_MUSTERI_YARATMA")
	public static GMMap ClksPTTKontaktMusteriYaratma(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {
			
			oMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			oMap.put("ISIM", iMap.getString("ADI"));
			oMap.put("IKINCI_ISIM", iMap.getString("IKINCI_ADI"));
			oMap.put("SOYADI", iMap.getString("SOYADI"));
			oMap.put("UYRUK_KOD", "");
			oMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
			oMap.put("KANAL_KODU", "7");
			oMap.put("CINSIYET_KOD", iMap.getString("CINSIYET"));
			oMap.put("BABA_ADI", iMap.getString("BABA_ADI"));
			oMap.put("ANNE_ADI", iMap.getString("ANNE_ADI"));
			oMap.put("DOGUM_TARIHI", iMap.getDate("DOGUM_TARIHI"));
			oMap.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
			oMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			oMap.put("MEDENI_HAL_KOD", iMap.getString("MEDENI_HAL"));
			oMap.put("AILE_SIRA_NO", iMap.getString("NUFUS_AILE_SIRA_NO"));
			oMap.put("CILT_NO", iMap.getString("NUFUS_CILT_NO"));
			oMap.put("SIRA_NO", iMap.getString("NUFUS_SIRA_NO"));
			oMap.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KIMLIK_SERI_NO_KPS").concat(iMap.getString("KIMLIK_SIRA_NO_KPS")));
			oMap.put("VERILDIGI_TARIH", iMap.getString("NUFUS_VERILIS_TARIHI"));
			oMap.put("KIZLIK_SOYADI", iMap.getString("ONCEKI_SOYADI"));
			oMap.put("MESLEK_KOD", iMap.getString("MESLEK"));
			oMap.put("EGITIM_KOD", iMap.getString("OGRENIM_DURUMU"));
			oMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			oMap.put("ISYERI_ADI", iMap.getString("ISYERI_ADI"));
			oMap.put("EMAIL1", iMap.getString("EMAIL1"));
			oMap.put("EMAIL2", iMap.getString("EMAIL2"));
			oMap.put("UNVANI", iMap.getString("UNVANI"));
			oMap.put("EV_ADRES", iMap.getString("EV_ADRESI"));
			oMap.put("EV_IL", iMap.getString("EV_IL"));
			oMap.put("EV_ILCE", iMap.getString("EV_ILCE"));
			oMap.put("EV_POSTA_KOD", iMap.getString("EV_POSTA_KODU"));
			oMap.put("IS_ADRES", iMap.getString("IS_ADRESI"));
			oMap.put("IS_IL", iMap.getString("IS_IL"));
			oMap.put("IS_ILCE", iMap.getString("IS_ILCE"));
			oMap.put("IS_POSTA_KOD", iMap.getString("IS_POSTA_KODU"));
			oMap.put("EV_TEL_KOD", iMap.getString("EV_TEL_KOD"));
			oMap.put("EV_TEL_NO", iMap.getString("EV_TEL_NO"));
			oMap.put("IS_TEL_KOD", iMap.getString("IS_TEL_KOD"));
			oMap.put("IS_TEL_NO", iMap.getString("IS_TEL_NO"));
			oMap.put("IS_TEL_DAHILI", iMap.getString("IS_TEL_DAHILI"));
			oMap.put("IL_KOD", iMap.getString("NUFUS_IL_KOD")); // NUFUS_IL_KOD
			oMap.put("ILCE_KOD", iMap.getString("NUFUS_ILCE_KOD")); // NUFUS_ILCE_KOD
			oMap.put("CEP_TEL_KOD", iMap.getString("CEP_TEL_KOD"));
			oMap.put("CEP_TEL_NO", iMap.getString("CEP_TEL_NO"));
			oMap.put("NUF_VERILIS_NEDENI", iMap.getString("NUF_VERILIS_NEDENI"));
			oMap.put("VERILDIGI_YER", iMap.getString("NUF_VERILDIGI_YER"));
			oMap.put("VERILDIGI_TARIH", iMap.getDate("NUFUS_VERILIS_TARIHI"));
			oMap.put("KANAL_ALT_KODU", "");
			oMap.put("KPS_YAPILDI", iMap.getString("KPS_YAPILDI"));
			oMap.put("YAZISMA_ADRESI_EV", iMap.getString("YAZISMA_ADRESI_EV"));
			oMap.put("YAZISMA_ADRESI_IS", iMap.getString("YAZISMA_ADRESI_IS"));
			oMap.put("URUN_KAMP_KOD", iMap.getString("KONTAKT_KAMP_KOD"));
			oMap.put("KANAL_KOD", "7");
			oMap.put("SIGORTALI_MI", iMap.getString("SIGORTALIMI"));
			oMap.put("MAHALLE_KOY", iMap.getString("NUFUS_MAHALLE"));
			oMap.put("PTT_PERSONEL_MI", iMap.getString("PTT_PERSONEL_MI"));
			oMap.put("MAAS_ALINAN_KURUM", iMap.getString("MAAS_ALINAN_KURUM"));

			if(iMap.getString("CALISMA_SEKLI_KOD") != null && iMap.getString("CALISMA_SEKLI_KOD").compareTo("2") == 0) {
				oMap.put("F_APS_TEYIT", true);
			} else {
				oMap.put("F_APS_TEYIT", false);
			}

			if(iMap.getString("MAAS_ALINAN_KURUM") != null && iMap.getString("MAAS_ALINAN_KURUM").compareTo("4") == 0) {
				oMap.put("ADRES_TEYIT", true);
			} else {
				oMap.put("ADRES_TEYIT", false);
			}

			GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", oMap);

		} catch(Exception e) {
			
			logger.error("CLKS_PTT_KONTAKT_MUSTERI_YARATMA err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_KREDI_LIST_FIRST_INITIAL_INFO")
	public static GMMap clksPTTKrediListFirstInitialInfo(GMMap iMap) {

		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_FIRST_INITIAL_INFO(?,?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO_BANKA"));
			stmt.setBigDecimal(i++, iMap.get("CLKS_TRX_NO") != null ? iMap.getBigDecimal("CLKS_TRX_NO") : null);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(4);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(5);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(6);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_LIST_FIRST_INITIAL_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_KREDI_LIST_INITIAL_INFO")
	public static GMMap clksPTTKrediListInitialInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_INITIAL_INFO(?,?,?,?,?,?)}");
			
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO_BANKA"));
			stmt.setBigDecimal(i++, iMap.get("CLKS_TRX_NO") != null ? iMap.getBigDecimal("CLKS_TRX_NO") : null);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(4);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(5);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(6);
			oMap.putAll(DALUtil.rSetMap(rSet));

		} catch (Exception e) {
			logger.error("CLKS_PTT_KREDI_LIST_INITIAL_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_GET_CONFIRM_OUT_DATA")
	public static GMMap clksPTTGetConfirmOutData(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_CONFIRM_OUT_DATA(?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetMap(rSet));

		} catch(Exception e) {
			logger.error("CLKS_PTT_GET_CONFIRM_OUT_DATA err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_GET_INITIAL_REQUEST_OUT_DATA")
	public static GMMap clksPTTGetInitialRequestOutData(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_INITIAL_REQUEST_OUT_DATA(?,?,?)}");
			
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetMap(rSet));

		} catch (Exception e) {
			logger.error("CLKS_PTT_GET_INITIAL_REQUEST_OUT_DATA err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_KREDI_CONFIRM_INFO")
	public static GMMap clksPTTKrediConfirmInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_CONFIRM_INFO(?,?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO_BANKA"));
			stmt.setBigDecimal(i++, iMap.get("CLKS_TRX_NO") != null ? iMap.getBigDecimal("CLKS_TRX_NO") : null);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(4);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(5);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(6);
			oMap.putAll(DALUtil.rSetResults(rSet, "TEMINAT_TABLE"));

		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_CONFIRM_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_KREDI_PAYMENT_PLAN_PREPARING")
	public static GMMap clksPTTKrediPaymentPlanPreparing(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_PAYMENT_PLAN(?,?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, -10); // ref cursor
			stmt.registerOutParameter(3, -10); // ref cursor

			stmt.registerOutParameter(4, Types.VARCHAR); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetResults(rSet, "ODEME_PLANI"));
			GMServerDatasource.close(rSet);

			oMap.put("BARKOD_NUMARASI", (String) stmt.getObject(4));

			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetMap(rSet));

			return oMap;

		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_PAYMENT_PLAN_PREPARING err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_GET_PAY_PLN_3181_REQUEST_INFO")
	public static GMMap clksPTTGetPayPln3181RequestInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_PAY_PLN_3181_REQUEST_INFO(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, -10); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetMap(rSet));

		} catch (Exception e) {
			logger.error("CLKS_GET_PAY_PLN_3181_REQUEST_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		

		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_GET_PAY_PLN_3181_CONFIRM_INFO")
	public static GMMap clksPTTGetPayPln3181ConfirmInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_PAYMENT_CONFIRM_OUT_DATA(?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, -10); // ref cursor
			stmt.registerOutParameter(3, -10); // ref cursor

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(3);
			String ekDokuman = getEkDokumanBilgi(iMap);
			GMMap resultMap = DALUtil.rSetResults(rSet, "BELGE_LISTESI");
			
			if(StringUtils.isNotBlank(ekDokuman)) {
				@SuppressWarnings("unchecked")
				List<GMMap> belgeListesi = (ArrayList<GMMap>) resultMap.get("BELGE_LISTESI");
				belgeListesi.add(new GMMap().put("evrakKodu", ekDokuman));
				resultMap.put("BELGE_LISTESI", belgeListesi);
			}
			
			oMap.putAll(resultMap);

		} catch(Exception e) {
			logger.error("CLKS_GET_PAY_PLN_3181_CONFIRM_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_PAYMENT_PLAN_REQUEST_INFO")
	public static GMMap clksPTTPaymentPlanRequestInfo(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		
		try {
			
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_PAYMENT_PLAN_REQUEST_INFO(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, -10); // ref cursor
			stmt.registerOutParameter(3, -10); // ref cursor
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetMap(rSet));

			oMap.put("FAIZ_ORANI", oMap.getString("FAIZ_ORANI_SOZLESME"));
			oMap.put("TAKSIT_TUTARI", getTaksitTutari(iMap.getBigDecimal("BASVURU_NO")));
			
			if("0".equals(oMap.getString("FAIZ_ODEME_SEKLI"))) {
				oMap.put("VADE_FARK_FAIZI", oMap.get("FARK_FAIZI"));
			}
			
			if("E".equals(oMap.getString("BIRLESTIRME_EH"))) {
				oMap.put("KAPAMA_TUTARI", GMServiceExecuter.call("BNSPR_CLKS_CONSOLIDATION_LOAN_PARAMETERS", new GMMap().put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))).get("TUTAR"));
			}

			oMap.putAll(GMServiceExecuter.call("CLKS_GET_IBAN_FROM_SOZLESME_HESAP",new GMMap().put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))));
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("CLKS_PTT_PAYMENT_PLAN_REQUEST_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap {BASVURU_NO}		Kredi basvuru numarasi
	 * @return
	 * 
	 * @see			#bnsprClksCreditGetDocumentVariables(GMMap) BNSPR_CLKS_CREDIT_GET_DOCUMENT_VARIABLES
	 * 
	 * @throws GMRuntimeException
	 */
	@GraymoundService("CLKS_PTT_PAYMENT_PLAN_CONFIRM_INFO")
	public static GMMap clksPTTPaymentPlanConfirmInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();

		try {
			
			oMap = (GMMap) DALUtil.callOracleProcedure("{call pkg_ptt_kredi.get_payment_plan_confirm_info(?,?,?)}",
				new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")}, 
				new Object[]{BnsprType.REFCURSOR, "ODEME_PLANI", BnsprType.REFCURSOR, "CLKS_PTT_PAYMENT_PLAN_CONFIRM_INFO"});
			
			@SuppressWarnings("unchecked")
			List<HashMap<?,?>> info = (List<HashMap<?,?>>) oMap.get("CLKS_PTT_PAYMENT_PLAN_CONFIRM_INFO");
			
			for(Map.Entry<?, ?> entry : info.get(0).entrySet()) {
				oMap.put(entry.getKey(), entry.getValue());
			}
			oMap.remove("CLKS_PTT_PAYMENT_PLAN_CONFIRM_INFO");

			GMMap belgeMap = GMServiceExecuter.call("CLKS_PTT_CONTRACTUAL_INFO", iMap);
			List<String> documentCodes = new ArrayList<String>();
			for(int i=0; i<belgeMap.getSize("BELGE_LISTESI"); i++) {
				documentCodes.add(belgeMap.getString("BELGE_LISTESI", i, "evrakKodu"));
			}
			map.put("DOCUMENT_LIST", documentCodes);
			
			oMap.putAll(GMServiceExecuter.call("BNSPR_CLKS_CREDIT_GET_DOCUMENT_VARIABLES", map));

			
			oMap.putAll(GMServiceExecuter.call("CLKS_GET_IBAN_FROM_SOZLESME_HESAP",new GMMap().put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))));
			
		} catch(Exception e) {
			logger.error("CLKS_PTT_PAYMENT_PLAN_CONFIRM_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap {BASVURU_NO}		Kredi basvuru numarasi
	 * @return
	 */
	@GraymoundService("CLKS_PTT_CONTRACTUAL_INFO")
	public static GMMap clksPTTContractualInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_PTT_KREDI.GET_CONTRACTUAL_REQUEST_INFO(?,?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, -10); // ref cursor
			stmt.registerOutParameter(3, -10); // ref cursor

			stmt.registerOutParameter(4, Types.VARCHAR); // ref cursor

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);

			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetResults(rSet, "BELGE_LISTESI"));

			oMap.put("BARKOD_NUMARASI", (String) stmt.getObject(4));

			return oMap;
		} catch (Exception e) {
			logger.error("CLKS_PTT_CONTRACTUAL_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 * 
	 * @see			tr.com.calikbank.bnspr.email.Mailer#sendAsynchronousMail(GMMap) BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL
	 */
	@GraymoundService("CLKS_PTT_KREDI_BASARISIZ_MAIL_GONDER")
	public static GMMap ClksSorunluIslemMailGonder(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_CLKS.GENEL_HATA_MSJ_MAIL_GONDER(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("ERROR_MESSAGE"));
			stmt.execute();
			String NewMailList = stmt.getString(1);

			int length = 0;
			if(iMap.getString("MAIL_GONDER") != null && iMap.getString("MAIL_GONDER").compareTo("1") == 0) {

				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO", NewMailList.equals("-1") ? iMap.getString("MAIL_LIST") : NewMailList);
				mailMap.put("TRX_NO", iMap.getString("islemNo"));
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", GMServiceExecuter.execute("BNSPR_CORE_GET_SISTEM_ADI", iMap).get("SISTEM_ADI") + "PTT Kredi Basarisiz Islem ");
				mailMap.put("MAIL_BODY", iMap.getString("SERVIS_ADI") + iMap.getString("ERROR_MESSAGE"));

				length = iMap.toString().length();
				if(iMap.toString().length() >= 3500) {
					mailMap.put("MAIL_BODY2", iMap.toString().subSequence(1, 3500));
				} else {
					mailMap.put("MAIL_BODY2", iMap.toString().subSequence(1, length));
				}
				if(length <= 7000 && length >= 3500) {
					mailMap.put("MAIL_BODY3", iMap.toString().subSequence(3500, length));
				}
				if(length <= 10500 && length >= 7000) {
					mailMap.put("MAIL_BODY4", iMap.toString().subSequence(7000, length));
				}

				if(length <= 14000 && length >= 10500) {
					mailMap.put("MAIL_BODY4", iMap.toString().subSequence(10500, length));
				}

				mailMap.put("IS_BODY_HTML", "H");
				GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
			}

		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_BASARISIZ_MAIL_GONDER err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return iMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_GET_3182_REQUEST_DATA")
	public static GMMap clksPTTGet3182RequestData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.GET_3182_SAVE_REQUEST_DATA(?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, -10); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);

			oMap.putAll(DALUtil.rSetMap(rSet));

			oMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));

		} catch(Exception e) {
			logger.error("CLKS_GET_3182_REQUEST_DATA err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_KREDI_UPDATE_BARKOD_LIST")
	public static GMMap clksPTTKrediUpdateBarkodList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_KREDI.PTT_UPDATE_BARKOD_LIST(?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("BARKOD_NUMARASI"));
			stmt.setString(i++, iMap.getString("SOZLESME_EVRAK"));
			stmt.execute();

		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_UPDATE_BARKOD_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	/**
	 * PTT kanal�ndan ger�ekle�mi� kredi ba�vurusunun durumunu RED'e �eken kabuk servistir.
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_BASVURU_REDDET")
	public static GMMap PTTBasvuruReddet(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			oMap.put("MESAJ", (String) DALUtil.callOracleFunction("{? = call PKG_PTT_KREDI.PTT_KREDI_BASVURU_REDDET(?,?,?,?)}", BnsprType.STRING, 
				BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_NO"),
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"),
				BnsprType.STRING, iMap.getString("ISLEM_KOD"),
				BnsprType.STRING, iMap.getString("AKSIYON_KARAR_KOD")));
			
			oMap.put("MESSAGE", oMap.getString("MESAJ"));
			
		} catch(Exception e) {
			logger.error("CLKS_PTT_BASVURU_REDDET err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * PTT kanal� i�in kredi ba�vuru simulasyonu �al��t�r�r. �rnek �deme plan� d�ner.
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_CREDIT_SIMULATION")
	public static GMMap PTTCreditSimulation(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			iMap.put("KAMPANYA_KODU", iMap.getString("kampanyaKod"));
			iMap.put("KAMP_KNL_KOD", iMap.getString("kampanyaKod"));
			iMap.put("KAMP_URUN_ADI", iMap.getString("kampanyaKod"));

			// in
			// KAMPANYA_KODU /*KAMPKANALKOD */ KAMP_KOD KAMP_KNL_KOD
			// KAMP_URUN_ADI

			// KREDI_TUTARI
			iMap.put("KREDI_TUTARI", iMap.getString("talepEdilenKrediTutari"));
			iMap.put("TUTAR", iMap.getString("talepEdilenKrediTutari"));
			// KREDI_VADE
			iMap.put("KREDI_VADE", iMap.getString("geriOdemeSuresi"));
			iMap.put("VADE", iMap.getString("geriOdemeSuresi"));
			// PERIYOD
			iMap.put("MAAS_TARIH_SIKLIGI", iMap.getString("maasSikligi"));

			iMap.putAll(GMServiceExecuter.call("CLKS_GET_SIMULATION_REQUEST_DATA", iMap));
			
			API.amountAndTermControl(iMap.getString("kampanyaKod"), iMap.getBigDecimal("talepEdilenKrediTutari"), iMap
				.getInt("geriOdemeSuresi"));

			// in
			// KRD_TUR_KOD, KRD_TUR_ALT_KOD, KRD_TUR_ALT_KOD2, KANAL_KOD
			// DOVIZ_KOD, TUTAR, VADE, KAMP_URUN_ADI kampkanalkod
			// BPM_DOSYA_MASRAF_FAIZ_TANIMI

			iMap.putAll(GMServiceExecuter.call("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));

			// out
			// FAIZ_ORAN, MAX_DOSYA_MASRAFI
			iMap.put("FAIZ_ORANI", iMap.getString("FAIZ_ORAN"));
			iMap.put("DOSYA_MASRAFI", iMap.getString("MAX_DOSYA_MASRAFI"));

			// musteri dogum tarihi
			iMap.put("MUSTERI_DOGUM_TAR", iMap.getString("dogumTar"));

			// PTT-32
			/*
			 * if ((iMap.getString("dogumTar") == null || iMap.getString(
			 * "dogumTar").length() == 0)) { iMap.put("HATA_NO", new
			 * BigDecimal(330)); iMap.put("P1", "Do�um Y�l�"); return
			 * GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap); }
			 * 
			 * if ((iMap.getString("dogumTar").length() != 4)) {
			 * iMap.put("HATA_NO", new BigDecimal(1908)); return
			 * GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap); }
			 */
			// in-> DOGUM_TARIHI, VADE, KAMP_KNL_KOD

			if(iMap.getString("dogumTar") != null && iMap.getString("dogumTar").length() != 0) {
				iMap.put("DOGUM_TARIHI", iMap.getString("dogumTar"));
				iMap.putAll(GMServiceExecuter.call("CLKS_PTT_YAS_KONTROL_2", iMap));

				iMap.put("DOGUM_TARIHI", new SimpleDateFormat("yyyyMMdd").parse(iMap.getString("dogumTar") + "0101"));
				iMap.put("CINSIYET", "E");

				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", iMap));
				iMap.put("KREDI_TUTARI", iMap.getBigDecimal("HERSEY_DAHIL_TUTAR"));

				iMap.put("SIMULASYON_MU", "E");
				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_KAMP_KNL_KOD_RECURSIVE_SIM", iMap));
			}
			
			GMMap odemeGrupMap = GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", 
                    new GMMap().put("KAMP_URUN_ADI", iMap.getString("kampanyaKod")));

			if ("4".equals(odemeGrupMap.get("ODEME_TIP_TABLE", 0, "ODEME_TIP_KOD"))) {
              iMap.put("ODEME_TIP_KOD", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "ODEME_TIP_KOD"));
              iMap.put("ODEME_TIP_PERIYOD", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MAX_PERIYOD"));
              iMap.put("ODEME_TIP_ORAN", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MAX_ORAN"));
			}
        			
			iMap.putAll(GMServiceExecuter.call("BNSPR_QRY3183_GET_ODEME_PLANI", iMap));
			// out
			// SOZLESME_FAIZ_ORANI
			// TOPLAM_TAKSIT_TUTARI

			// ODEME_PLANI
			String tableName = "ornekOdemePlani";
			String tableName2 = "ODEME_PLANI";
			BigDecimal taksitTutari = null;

			for(int i = 0; i < iMap.getSize("ODEME_PLANI"); i++) {
				oMap.put(tableName, i, "taksitNo", i + 1);
				oMap.put(tableName, i, "taksitTarihi", iMap.getString(tableName2, i, "OP_TAKSIT_TARIHI"));
				// Case: 2. taksit tutari
				if(i == 1) {
					taksitTutari = new BigDecimal(iMap.getString(tableName2, i, "OP_TAKSIT_TUTAR"));
				}
				oMap.put(tableName, i, "taksitTutari", iMap.getString(tableName2, i, "OP_TAKSIT_TUTAR"));
				oMap.put(tableName, i, "faiz", iMap.getString(tableName2, i, "OP_FAIZ"));
				oMap.put(tableName, i, "BSMV", iMap.getString(tableName2, i, "OP_BSMV"));
				oMap.put(tableName, i, "KKDF", iMap.getString(tableName2, i, "OP_KKDF"));
				oMap.put(tableName, i, "Anapara", iMap.getString(tableName2, i, "OP_ANAPARA"));
				oMap.put(tableName, i, "KalanAnapara", iMap.getString(tableName2, i, "OP_KALAN_TUTAR"));
			}

			
			iMap.putAll(GMServiceExecuter.call("BNSPR_QRY3183_KREDI_TAKSIT_HESAPLA", iMap));
			/*
			if(taksitTutari == null)
				oMap.put("taksitTutari", iMap.getBigDecimal("KREDI_TAKSIT_TUTARI"));
			else
				oMap.put("taksitTutari", ilkTaksitTutari);
			*/
			oMap.put("taksitTutari", taksitTutari);
			oMap.put("faizOrani", iMap.getBigDecimal("SOZLESME_FAIZ_ORANI")); // FAIZ_ORANI
			oMap.put("toplamGeriOdemeTutari", iMap.getBigDecimal("TOPLAM_TAKSIT_TUTARI"));

			oMap.put("taksitSayisi", iMap.getBigDecimal("geriOdemeSuresi").divide(iMap.getBigDecimal("maasSikligi")));

			// in-> KREDI_TUTARI, KREDI_VADE, MAAS_TARIH_SIKLIGI,
			// MUSTERI_DOGUM_TAR, KAMPANYA_KODU
			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_HAYAT_SIGORTASI_TUTARI_HESAPLA", iMap));
			// out-> HAYAT_SIGORTASI_TUTARI
			oMap.put("hayatSigortasiTutari", iMap.getBigDecimal("HAYAT_SIGORTASI_TUTARI"));
			oMap.put("dosyaMasrafi", iMap.getBigDecimal("DOSYA_MASRAFI"));

			// in->
			// KAMP_URUN_ADI, KAMPANYA_KODU, KANAL_KOD, DOVIZ_KOD, TUTAR, VADE,
			// KAMP_KNL_KOD,
			iMap.putAll(GMServiceExecuter.call("BPM_GET_KATKIPAYI", iMap));
			// out->
			// KATKI_PAYI_KIMDEN, MAX_KATKI_PAYI

			if("M".compareTo(iMap.getString("KATKI_PAYI_KIMDEN")) == 0) {
				oMap.put("katkiPayi", iMap.getBigDecimal("MAX_KATKI_PAYI"));
			} else {
				oMap.put("katkiPayi", new BigDecimal(0));
			}

			oMap.put("toplamMasraf", oMap.getBigDecimal("dosyaMasrafi", BigDecimal.ZERO).add(oMap.getBigDecimal("katkiPayi", BigDecimal.ZERO)));
			
			if("E".equals(iMap.getString("hayatSigortasiDahil"))) {
				oMap.put("toplamMasraf", oMap.getBigDecimal("toplamMasraf", BigDecimal.ZERO).add(oMap.getBigDecimal("hayatSigortasiTutari", BigDecimal.ZERO)));
			}
			
			oMap.put("ODENECEK_TUTAR", iMap.getBigDecimal("KREDI_TUTARI").subtract(oMap.getBigDecimal("toplamMasraf")));

		} catch(Exception e) {
			logger.error("CLKS_PTT_CREDIT_SIMULATION err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_GET_SIMULATION_REQUEST_DATA")
	public static GMMap clksPTTGetSimulationData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PTT_KREDI.GET_SIMULATION_REQUEST_DATA(?,?,?,?)}");

			stmt.registerOutParameter(1, -10); // ref cursor
			stmt.setBigDecimal(2, iMap.getBigDecimal("kampanyaKod"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("maasSikligi"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("geriOdemeSuresi"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("talepEdilenKrediTutari"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetMap(rSet));

			return oMap;

		} catch(Exception e) {
			logger.error("CLKS_GET_SIMULATION_REQUEST_DATA err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_MAAS_TARIHI_MAAS_SIKLIGI_UYUMLUMU")
	public static GMMap clksPTTMaasTarihiSikligiUyumlumu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_PTT_KREDI.MAAS_TARIH_SIKLIK_UYUMLUMU(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			return oMap;
		} catch(Exception e) {
			logger.error("CLKS_MAAS_TARIHI_MAAS_SIKLIGI_UYUMLUMU err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_KREDI_MAIL_ATILSINMI")
	public static GMMap clksPTTKrediMailAtilsinMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_PTT_KREDI.PTT_KREDI_MAIL_ATILSINMI(?,?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.execute();
			oMap.put("MAIL_GONDER", stmt.getString(1));
			oMap.put("MAIL_LIST", stmt.getString(2));
			return oMap;
		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_MAIL_ATILSINMI err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/** 
	 * PTT kanal�ndan ger�ekle�en kredi ba�vurusuna ili�kin kontakt m��teri g�ncelleme i�lemi i�in veri toplar.
	 * 
	 * @param iMap	GMMap
	 * @return
	 * 
	 */
	@GraymoundService("CLKS_PTT_KONTAKT_MUSTERI_GUNCELLEME_DATA")
	public static GMMap ClksPTTKontaktMusteriData(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			oMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			oMap.put("ISIM", iMap.getString("ADI"));
			oMap.put("IKINCI_ISIM", iMap.getString("IKINCI_ADI"));
			oMap.put("SOYADI", iMap.getString("SOYADI"));
			oMap.put("TRX_NO", iMap.getString("TRX_NO"));
			oMap.put("UYRUK_KOD", "");
			oMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
			oMap.put("KANAL_KODU", "7");
			oMap.put("CINSIYET_KOD", iMap.getString("CINSIYET"));
			oMap.put("BABA_ADI", iMap.getString("BABA_ADI"));
			oMap.put("ANNE_ADI", iMap.getString("ANNE_ADI"));
			oMap.put("DOGUM_TARIHI", iMap.getDate("DOGUM_TARIHI"));
			oMap.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
			oMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			oMap.put("MEDENI_HAL_KOD", iMap.getString("MEDENI_HAL"));
			oMap.put("AILE_SIRA_NO", iMap.getString("NUFUS_AILE_SIRA_NO"));
			oMap.put("CILT_NO", iMap.getString("NUFUS_CILT_NO"));
			oMap.put("SIRA_NO", iMap.getString("NUFUS_SIRA_NO"));
			oMap.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KIMLIK_SERI_NO_KPS").concat(iMap.getString("KIMLIK_SIRA_NO_KPS")));
			oMap.put("VERILDIGI_TARIH", iMap.getString("NUFUS_VERILIS_TARIHI"));
			oMap.put("KIZLIK_SOYADI", iMap.getString("ONCEKI_SOYADI"));
			oMap.put("MESLEK_KOD", iMap.getString("MESLEK"));
			oMap.put("EGITIM_KOD", iMap.getString("OGRENIM_DURUMU"));
			oMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			oMap.put("ISYERI_ADI", iMap.getString("ISYERI_ADI"));
			oMap.put("EMAIL1", iMap.getString("EMAIL1"));
			oMap.put("EMAIL2", iMap.getString("EMAIL2"));
			oMap.put("UNVANI", iMap.getString("UNVANI"));
			oMap.put("EV_ADRES", iMap.getString("EV_ADRESI"));
			oMap.put("EV_IL", iMap.getString("EV_IL"));
			oMap.put("EV_ILCE", iMap.getString("EV_ILCE"));
			oMap.put("EV_POSTA_KOD", iMap.getString("EV_POSTA_KODU"));
			oMap.put("IS_ADRES", iMap.getString("IS_ADRESI"));
			oMap.put("IS_IL", iMap.getString("IS_IL"));
			oMap.put("IS_ILCE", iMap.getString("IS_ILCE"));
			oMap.put("IS_POSTA_KOD", iMap.getString("IS_POSTA_KODU"));
			oMap.put("EV_TEL_KOD", iMap.getString("EV_TEL_KOD"));
			oMap.put("EV_TEL_NO", iMap.getString("EV_TEL_NO"));
			oMap.put("IS_TEL_KOD", iMap.getString("IS_TEL_KOD"));
			oMap.put("IS_TEL_NO", iMap.getString("IS_TEL_NO"));
			oMap.put("IS_TEL_DAHILI", iMap.getString("IS_TEL_DAHILI"));
			oMap.put("IL_KOD", iMap.getString("NUFUS_IL_KOD"));
			oMap.put("ILCE_KOD", iMap.getString("NUFUS_ILCE_KOD"));
			oMap.put("CEP_TEL_KOD", iMap.getString("CEP_TEL_KOD"));
			oMap.put("CEP_TEL_NO", iMap.getString("CEP_TEL_NO"));
			oMap.put("NUF_VERILIS_NEDENI", iMap.getString("NUF_VERILIS_NEDENI"));
			oMap.put("VERILDIGI_YER", iMap.getString("NUF_VERILDIGI_YER"));
			oMap.put("VERILDIGI_TARIH", iMap.getDate("NUFUS_VERILIS_TARIHI"));
			oMap.put("KANAL_ALT_KODU", "");
			oMap.put("KPS_YAPILDI", iMap.getString("KPS_YAPILDI"));
			oMap.put("YAZISMA_ADRESI_EV", iMap.getString("YAZISMA_ADRESI_EV"));
			oMap.put("YAZISMA_ADRESI_IS", iMap.getString("YAZISMA_ADRESI_IS"));
			oMap.put("URUN_KAMP_KOD", iMap.getString("KONTAKT_KAMP_KOD"));
			oMap.put("KANAL_KOD", "7");
			oMap.put("SIGORTALI_MI", iMap.getString("SIGORTALIMI"));
			oMap.put("MAHALLE_KOY", iMap.getString("NUFUS_MAHALLE"));
			oMap.put("KISA_AD", iMap.getString("KISA_AD"));

			if(iMap.getString("CALISMA_SEKLI_KOD") != null && iMap.getString("CALISMA_SEKLI_KOD").compareTo("2") == 0) {
				oMap.put("F_APS_TEYIT", true);
			} else {
				oMap.put("F_APS_TEYIT", false);
			}

			if(iMap.getString("MAAS_ALINAN_KURUM") != null && iMap.getString("MAAS_ALINAN_KURUM").compareTo("4") == 0) {
				oMap.put("ADRES_TEYIT", true);
			} else {
				oMap.put("ADRES_TEYIT", false);
			}
			
		} catch(Exception e) {
			logger.error("CLKS_PTT_KONTAKT_MUSTERI_GUNCELLEME_DATA err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_GET_ILK_TAKSIT_YONTEM")
	public static GMMap clksGetIlkTaksitYontem(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PTT_KREDI.GET_FAIZ_ODEME_SEKLI(?)  }");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KOD"));
			stmt.execute();
			oMap.put("PTT_ILK_TAKSIT_YONTEM", stmt.getBigDecimal(1));
			return oMap;

		} catch(Exception e) {
			logger.error("CLKS_GET_ILK_TAKSIT_YONTEM err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_YAS_KONTROL_2")
	public static GMMap clksPTTYasKontrol_2(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_PTT_KREDI.PTTYASKONTROL_2(?,?,?)}");
			int i = 1;

			stmt.setString(i++, iMap.getString("DOGUM_TARIHI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KNL_KOD"));

			stmt.execute();
			return oMap;

		} catch(Exception e) {
			logger.error("CLKS_PTT_YAS_KONTROL_2 err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_HAYAT_SIGORTASI_TUTARI_HESAPLA")
	public static GMMap clksPTTHayatSigortasi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? =  call PKG_PTT_KREDI.PTT_SIGORTA_PRIMI_HESAPLA_2(?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("KREDI_VADE"));
			stmt.setString(i++, iMap.getString("MUSTERI_DOGUM_TAR"));

			/*
			 * dogum tarihi alan� dogum y�l� olarak de�i�tirildi.OO.
			 * if ( iMap.get("MUSTERI_DOGUM_TAR") != null ){ stmt.setDate(4, new
			 * Date(iMap.getDate("MUSTERI_DOGUM_TAR").getTime())); } else {
			 * stmt.setDate(4, null ); }
			 */
			stmt.setString(i++, iMap.getString("MAAS_TARIH_SIKLIGI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMPANYA_KODU"));
			stmt.execute();
			oMap.put("HAYAT_SIGORTASI_TUTARI", stmt.getBigDecimal(1));

			return oMap;
		} catch(Exception e) {
			logger.error("CLKS_PTT_HAYAT_SIGORTASI_TUTARI_HESAPLA err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_MAAS_ALINAN_KURUM")
	public static GMMap clksPTTMaasKurumGetir(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? =  call PKG_PTT_KREDI.MAAS_ALINAN_KURUM(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			oMap.put("MAAS_ALINAN_KURUM", stmt.getString(1));

			return oMap;
		} catch(Exception e) {
			logger.error("CLKS_MAAS_ALINAN_KURUM err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_SON_MAAS_TARIHI")
	public static GMMap clksPTTSonMaasTarihi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? =  call PKG_PTT_KREDI.PTT_SON_MAAS_TARIHI(?,?)}");
			stmt.registerOutParameter(1, Types.DATE);
			if(iMap.get("SON_MAAS_TARIHI") != null && iMap.getString("SON_MAAS_TARIHI").compareTo("") != 0)
				stmt.setDate(2, new Date(iMap.getDate("SON_MAAS_TARIHI").getTime()));
			else
				stmt.setDate(2, null);
			stmt.setString(3, iMap.getString("MAAS_ALINAN_KURUM"));

			stmt.execute();
			oMap.put("SON_MAAS_TARIHI", stmt.getDate(1));

			return oMap;
		} catch(Exception e) {
			logger.error("CLKS_SON_MAAS_TARIHI err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("PTT_KREDI_OTP_KONTROL")
	public static Map<?, ?> getKMVOran(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("PTT_KREDI_OTP_KONTROL", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('PTT_KREDI_OTP_KONTROL')}", Types.NUMERIC));
		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_KREDI_DETAY_BILGI")
	public static GMMap clksPttKrediDetayBilgi(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		try {

			BigDecimal max = BigDecimal.ZERO;
			int indexOfMax = -1;
			for(int j = 0; j < iMap.getSize("MAAS_BILGILERI"); j++) {
				if(iMap.getBigDecimal("MAAS_BILGILERI", j, "MAAS_TUTARI").compareTo(max) == 1) {
					max = iMap.getBigDecimal("MAAS_BILGILERI", j, "MAAS_TUTARI");
					indexOfMax = j;
				}
			}

			iMap.put("MAAS_TARIH_SIKLIGI", iMap.getString("MAAS_BILGILERI", indexOfMax, "MAAS_TARIH_SIKLIGI"));
			iMap.put("SON_MAAS_TARIHI",
				(iMap.getString("MAAS_BILGILERI", indexOfMax, "SON_MAAS_TARIHI") != null && !iMap.getString("MAAS_BILGILERI", indexOfMax, "SON_MAAS_TARIHI")
					.trim()
					.isEmpty()) ? iMap.getString("MAAS_BILGILERI", indexOfMax, "SON_MAAS_TARIHI") : null);
			iMap.put("MAAS_TARIH_SIKLIGI",
				(iMap.getString("MAAS_TARIH_SIKLIGI") == null || "0".equals(iMap.getString("MAAS_TARIH_SIKLIGI")) || iMap.getString("MAAS_TARIH_SIKLIGI")
					.length() == 0) ? "1" : iMap.getString("MAAS_TARIH_SIKLIGI"));

			oMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_PTT_KREDI.TAKSIT_HESAPLA(?,?,?,?,?,?,?,?,?)}", new Object[] {
				BnsprType.NUMBER, iMap.getBigDecimal("KAMP_KOD"),
				BnsprType.STRING, iMap.getString("DOVIZ_KOD"),
				BnsprType.NUMBER, iMap.getBigDecimal("TUTAR"),
				BnsprType.NUMBER, iMap.getBigDecimal("VADE"),
				BnsprType.DATE, iMap.getString("DOGUM_TARIHI") != null && !iMap.getString("DOGUM_TARIHI").trim()
					.isEmpty() ? new java.sql.Date(iMap.getDate("DOGUM_TARIHI").getTime()) : null,
				BnsprType.STRING, iMap.getString("CINSIYET"),
				BnsprType.NUMBER, iMap.getBigDecimal("MAAS_TARIH_SIKLIGI"),
				BnsprType.DATE, iMap.getString("SON_MAAS_TARIHI") != null && !iMap.getString("SON_MAAS_TARIHI").trim()
					.isEmpty() ? new java.sql.Date(iMap.getDate("SON_MAAS_TARIHI").getTime()) : null
			}, new Object[] {
				BnsprType.REFCURSOR, "KREDI_DETAY_LIST"
			});
			
		} catch(Exception e) {
			logger.error("CLKS_PTT_KREDI_DETAY_BILGI err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * TBD
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_PCH_GERI_IADE_LISTESI")
	public static GMMap clksPttPchGeriIadeListesi(GMMap iMap) {
		
		/**
		 * TODO Farkl� bir class'a ta��nacak.
		 */

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT.GET_PCH_GERI_IADE_LIST(?,?,?)}");

			if(iMap.getString("BASLANGIC_TARIHI") != null && !iMap.getString("BASLANGIC_TARIHI").trim().isEmpty()) {
				Date sDate = new java.sql.Date(formatter.parse(iMap.getString("BASLANGIC_TARIHI")).getTime());
				stmt.setDate(1, sDate);
			} else {
				stmt.setDate(1, null);
			}

			if(iMap.getString("BITIS_TARIHI") != null && !iMap.getString("BITIS_TARIHI").trim().isEmpty()) {
				Date eDate = new java.sql.Date(formatter.parse(iMap.getString("BITIS_TARIHI")).getTime());
				stmt.setDate(2, eDate);
			} else {
				stmt.setDate(2, null);
			}

			stmt.registerOutParameter(3, -10); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetResults(rSet, "PCH_IADE_LIST"));

		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/**
	 * PTT - SGK dosya kaynaginden beslenen aylik kurum ve tahsis numarasi kullanilarak SGK online bildirim kaynagindan 
	 * beslenen aylik bilgisi ile eslestirilir.
	 *
	 * @param iMap	GMMap {MAAS_ALINAN_KURUM, TAHSIS_NUMARASI, SGK_AYLIK_BILGILERI[]: [AYLIK_ID, SIGORTA_KOLU, 
	 * 				TAHSIS_SEKLI, ADI, SOYADI, AYLIK_BANKAMDA, AYLIK_SONUC_KODU, SICIL_NO, SISTEM_ACIK_KAPALI_KODU]}
	 *
	 * @return		{SGK_AYLIK_ID, SGK_SIGORTA_KOLU, SGK_TAHSIS_SEKLI, SGK_ADI, SGK_SOYADI, SGK_AYLIK_BANKAMDA, 
	 * 				SGK_AYLIK_SONUC_KODU, SGK_AYLIK_SONUC_ACIKLAMA, SGK_SICIL_NO, SGK_SISTEM_ACIK_KAPALI_KODU}
	 */	
	@GraymoundService ("CLKS_BASVURU_EMEKLI_SGK_AYLIK_GETIR")
	public static GMMap sgkAylikGetir(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		int kurumTip = getInstitutionType(iMap.getInt("MAAS_ALINAN_KURUM"));
		int kurumTipSgk = -1;
		SgkInstitution currentInstitution;
		String sicil = "";
		
		oMap.put("SGK_KAYIT", 0);
		
		for (int j = 0; j < iMap.getSize("SGK_AYLIK_BILGILERI"); j++) {
			
			currentInstitution = SgkInstitution.valueOf(SgkInstitution.InsuranceChannel.getEnum(iMap
				.getString("SGK_AYLIK_BILGILERI", j, "SIGORTA_KOLU").trim()));
			
			kurumTipSgk = Integer.parseInt(currentInstitution.getShortCode().toString());

			// Case: Bagkur
			if (kurumTip == 3 && kurumTip == kurumTipSgk) {
				sicil = iMap.getString("SGK_AYLIK_BILGILERI", j, "SICIL_NO").trim();
				sicil = sicil.substring(0, sicil.length() - 4).concat(sicil.substring(sicil.length() - 3));
			}
			
			// Case: SGK aylik bilgilerini eslestir
			if((kurumTip == 1 && kurumTip == kurumTipSgk && iMap.getString("TAHSIS_NUMARASI").equals(iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_ID").trim())) || 	// SSK
				(kurumTip == 2 && kurumTip == kurumTipSgk && iMap.getString("TAHSIS_NUMARASI").equals(iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_ID").trim())) ||	// Emekli Sandigi
				(kurumTip == 3 && kurumTip == kurumTipSgk && (iMap.getString("TAHSIS_NUMARASI").equals(iMap.getString("SGK_AYLIK_BILGILERI", j, "SICIL_NO").trim()) || iMap.getString("TAHSIS_NUMARASI").equals(sicil)))) {														// Bagkur
				
				oMap.put("SGK_AYLIK_ID", iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_ID").trim());
				oMap.put("SGK_SIGORTA_KOLU", iMap.getString("SGK_AYLIK_BILGILERI", j, "SIGORTA_KOLU").trim());
				oMap.put("SGK_TAHSIS_SEKLI", iMap.getString("SGK_AYLIK_BILGILERI", j, "TAHSIS_SEKLI").trim());
				oMap.put("SGK_ADI", iMap.get("SGK_AYLIK_BILGILERI", j, "ADI") != null ? iMap.getString(
					"SGK_AYLIK_BILGILERI", j, "ADI").trim() : null);
				oMap.put("SGK_SOYADI", iMap.get("SGK_AYLIK_BILGILERI", j, "SOYADI") != null ? iMap.getString(
					"SGK_AYLIK_BILGILERI", j, "SOYADI").trim() : null);
				oMap.put("SGK_AYLIK_BANKAMDA", iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_BANKAMDA").trim());
				oMap.put("SGK_AYLIK_SONUC_KODU", iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_SONUC_KODU").trim());
				oMap.put("SGK_AYLIK_SONUC_ACIKLAMA", iMap.getString("SGK_AYLIK_BILGILERI", j, "AYLIK_SONUC_ACIKLAMA")
					.trim());
				oMap.put("SGK_SICIL_NO", iMap.get("SGK_AYLIK_BILGILERI", j, "SICIL_NO") != null ? iMap.getString(
					"SGK_AYLIK_BILGILERI", j, "SICIL_NO").trim() : null);
				oMap.put("SGK_SISTEM_ACIK_KAPALI_KODU",
					iMap.get("SGK_AYLIK_BILGILERI", j, "SISTEM_ACIK_KAPALI_KODU") != null ? iMap.getString(
						"SGK_AYLIK_BILGILERI", j, "SISTEM_ACIK_KAPALI_KODU").trim() : null);
				oMap.put("SGK_KAYIT", 1);
				
				break;
			}
		}
		
		return oMap;
	}
	
	/**
	 * PTT kanal�ndan ger�ekle�en kredi ba�vurular�nda {@link #clksPTTKrediFirstInitial(GMMap) CLKS_PTT_KREDI_FIRST_INITIAL}
	 * ve {@link #clksPTTContractualRequest(GMMap) CLKS_PTT_CONTRACTUAL_REQUEST} servislerine input olarak
	 * beslenen <code>SGK_AYLIK_BILGILERI</code> ve di�er SGK ili�kili parametreleri kay�t eder.
	 * <p>
	 * <code>REQUEST_TYPE</code> key de�eri <code>aylikSorgula</code> olmas� durumunda {@link #createSgkEmekliMaasSorguLogDetay(GMMap) CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY}
	 * �a��r�larak ayl�k detay bilgileri kay�t edilir.
	 * 
	 * @param iMap	GMMap
	 * @return
	 * 
	 * @see #createSgkEmekliMaasSorguLogDetay(GMMap) CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY
	 */
	@GraymoundService("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG")
	public static GMMap createSgkEmekliSorguLog(GMMap iMap) {
		GMMap oMap = new GMMap();		
		
		try {
				
			oMap.put("LOG_ID", (String) GMServiceExecuter.executeNT("BNSPR_SGK_EMEKLI_SORGU_GET_LOG_ID", iMap).get("LOG_ID"));
			oMap.put("REQUEST_TYPE", iMap.getString("REQUEST_TYPE"));
			oMap.put("PARAM_REF_TUR", "BIR_BASVURU");
			oMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
			oMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
			oMap.put("AYLIK_ID", iMap.getString("TAHSIS_NUMARASI"));
			oMap.put("SIGORTA_KOLU", iMap.getString("SIGORTA_KOLU"));
			
			// Case: 
			if("aylikSorgula".equals(iMap.getString("REQUEST_TYPE"))) {

				if(iMap.get("SGK_SONUC_KODU") != null && !"0".equals(iMap.getString("SGK_SONUC_KODU"))) {
					oMap.put("ERROR_DESCRIPTION", iMap.getString("SGK_SONUC_KODU") + ":" + ((iMap.getString("SGK_SONUC_ACIKLAMA") == null) ? "" : iMap.getString("SGK_SONUC_ACIKLAMA")));
					oMap.put("RESULT_CODE", 0);
					oMap.put("QUERY_RESULT_STATUS", "FAILURE");
				} else {
					oMap.put("RESULT_CODE", 2);
					oMap.put("QUERY_RESULT_STATUS", "SUCCESS");
				}
				
				GMMap requestDataMap = new GMMap()
					.put("PARAM_REF_ID", oMap.getString("PARAM_REF_ID"))
					.put("TCKN", oMap.getString("TC_KIMLIK_NO"))
					.put("BASVURU_NO", oMap.getString("PARAM_REF_ID"))
					.put("PARAM_REF_TUR", oMap.getString("PARAM_REF_TUR"));
				
				oMap.put("REQUEST_DATA", requestDataMap.toString());
			}
			
			// Case: 
			else if("aylikBlokeKoy".equals(iMap.getString("REQUEST_TYPE"))) {
				
				if(iMap.get("SGK_SONUC_KODU") != null && !"0".equals(iMap.getString("SGK_SONUC_KODU")) && !"-10".equals(iMap.getString("SGK_SONUC_KODU"))) {
					oMap.put("ERROR_DESCRIPTION", iMap.getString("SGK_SONUC_KODU") + ":" + ((iMap.getString("SGK_SONUC_ACIKLAMA") == null) ? "" : iMap.getString("SGK_SONUC_ACIKLAMA")));
					oMap.put("RESULT_CODE", 0);
					oMap.put("QUERY_RESULT_STATUS", "FAILURE");
				} else {
					oMap.put("RESULT_CODE", 2);
					oMap.put("QUERY_RESULT_STATUS", "SUCCESS");
				}
				
				GMMap requestDataMap = new GMMap()
					.put("AYLIK_ID", oMap.getString("AYLIK_ID"))
					.put("SIGORTA_KOLU", oMap.getString("SIGORTA_KOLU"))
					.put("PARAM_REF_ID", oMap.getString("PARAM_REF_ID"))
					.put("TCKN", oMap.getString("TC_KIMLIK_NO"))
					.put("EMEKLI_GSM_NO", oMap.getString("EMEKLI_GSM_NO"))
					.put("BASVURU_NO", oMap.getString("PARAM_REF_ID"))
					.put("PARAM_REF_TUR", oMap.getString("PARAM_REF_TUR"));
			
				oMap.put("REQUEST_DATA", requestDataMap.toString());
			}
			
			else {
				
				iMap.put("HATA_NO", 1803);
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			istSgkEmekliSorguLog istSgkEmekliMaasSorguLog = new istSgkEmekliSorguLog();
			istSgkEmekliMaasSorguLog.setLogId(oMap.getBigDecimal("LOG_ID"));
			istSgkEmekliMaasSorguLog.setErrorDescription(oMap.getString("ERROR_DESCRIPTION"));
			istSgkEmekliMaasSorguLog.setQueryResultStatus(oMap.getString("QUERY_RESULT_STATUS"));
			istSgkEmekliMaasSorguLog.setRequestType(oMap.getString("REQUEST_TYPE"));
			istSgkEmekliMaasSorguLog.setRequestData((oMap.getString("REQUEST_DATA") != null) ? new ClobImpl(oMap.getString("REQUEST_DATA")) : new ClobImpl(""));
			istSgkEmekliMaasSorguLog.setResultCode(oMap.getString("RESULT_CODE"));
			istSgkEmekliMaasSorguLog.setParamRefTur(oMap.getString("PARAM_REF_TUR"));
			istSgkEmekliMaasSorguLog.setParamRefId(oMap.getString("PARAM_REF_ID"));
			istSgkEmekliMaasSorguLog.setTcKimlikNo(oMap.getString("TC_KIMLIK_NO"));
			session.save(istSgkEmekliMaasSorguLog);
			session.flush();
			
			// Case: Detay log at
			if("aylikSorgula".equals(oMap.getString("REQUEST_TYPE"))) {
				GMServiceExecuter.executeNT("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY", iMap
						.put("LOG_ID", oMap.getString("LOG_ID"))
						.put("PARAM_REF_TUR", oMap.getString("PARAM_REF_TUR")));
			}
		}
		catch (Exception e) {
			logger.error("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY err:", e);
		}
		
		return oMap;
	}
	

	
	/**
	 * PTT kanal�ndan ger�ekle�en kredi ba�vurular�nda {@link #clksPTTKrediFirstInitial(GMMap) CLKS_PTT_KREDI_FIRST_INITIAL}
	 * ve {@link #clksPTTContractualRequest(GMMap) CLKS_PTT_CONTRACTUAL_REQUEST} servislerine input olarak
	 * beslenen <code>SGK_AYLIK_BILGILERI</code> kay�t eder.
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY")
	public static GMMap createSgkEmekliMaasSorguLogDetay(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			if(iMap.getSize("SGK_AYLIK_BILGILERI") > 0) {

				Session session = DAOSession.getSession("BNSPRDal");
				for(int i = 0; i < iMap.getSize("SGK_AYLIK_BILGILERI"); i++) {

					BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID",
						new GMMap().put("TABLE_NAME", "IST_SGK_EMEKLI_SORGU_DETAY")).getBigDecimal("ID");

					istSgkEmekliSorguDetay istSgkEmekliMaasSorguDetay = new istSgkEmekliSorguDetay();
					istSgkEmekliMaasSorguDetay.setId(id);
					istSgkEmekliMaasSorguDetay.setLogId(iMap.getBigDecimal("LOG_ID"));
					istSgkEmekliMaasSorguDetay.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
					istSgkEmekliMaasSorguDetay.setAdi(iMap.get("SGK_AYLIK_BILGILERI", i, "ADI") != null ? iMap
						.getString("SGK_AYLIK_BILGILERI", i, "ADI").trim() : null);
					istSgkEmekliMaasSorguDetay.setSoyadi(iMap.get("SGK_AYLIK_BILGILERI", i, "SOYADI") != null ? iMap
						.getString("SGK_AYLIK_BILGILERI", i, "SOYADI").trim() : null);
					istSgkEmekliMaasSorguDetay.setAylikId(iMap.get("SGK_AYLIK_BILGILERI", i, "AYLIK_ID") != null ? iMap
						.getString("SGK_AYLIK_BILGILERI", i, "AYLIK_ID").trim() : null);
					istSgkEmekliMaasSorguDetay.setAylikSonucAciklama(iMap.get("SGK_AYLIK_BILGILERI", i,
						"AYLIK_SONUC_ACIKLAMA") != null ? iMap.getString("SGK_AYLIK_BILGILERI", i,
						"AYLIK_SONUC_ACIKLAMA").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setSigortaKolu(iMap.get("SGK_AYLIK_BILGILERI", i, "SIGORTA_KOLU") != null ? iMap.getString(
							"SGK_AYLIK_BILGILERI", i, "SIGORTA_KOLU").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setTahsisSekli(iMap.get("SGK_AYLIK_BILGILERI", i, "TAHSIS_SEKLI") != null ? iMap.getString(
							"SGK_AYLIK_BILGILERI", i, "TAHSIS_SEKLI").trim() : null);
					istSgkEmekliMaasSorguDetay.setSicilNo(iMap.getString("SGK_AYLIK_BILGILERI", i, "SICIL_NO") != null
						? iMap.getString("SGK_AYLIK_BILGILERI", i, "SICIL_NO").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setSistemAcikKapali(iMap.get("SGK_AYLIK_BILGILERI", i, "SICIL_NO") != null ? iMap.getString(
							"SGK_AYLIK_BILGILERI", i, "SISTEM_ACIK_KAPALI_KODU").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setAylikBankamda(iMap.get("SGK_AYLIK_BILGILERI", i, "AYLIK_BANKAMDA") != null ? iMap
							.getString("SGK_AYLIK_BILGILERI", i, "AYLIK_BANKAMDA").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setAylikSonucKodu(iMap.get("SGK_AYLIK_BILGILERI", i, "AYLIK_SONUC_KODU") != null ? iMap
							.getString("SGK_AYLIK_BILGILERI", i, "AYLIK_SONUC_KODU").trim() : null);
					istSgkEmekliMaasSorguDetay.setParamRefTur(iMap.getString("PARAM_REF_TUR"));
					istSgkEmekliMaasSorguDetay.setParamRefId(iMap.getString("BASVURU_NO"));

					session.save(istSgkEmekliMaasSorguDetay);
					session.flush();

					if(iMap.get("SGK_AYLIK_BILGILERI", i, "BLOKE_SONUC_KODU") != null) {
						GMServiceExecuter.executeNT("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG", new GMMap().put(
							"REQUEST_TYPE", "aylikBlokeKoy").put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO")).put(
							"BASVURU_NO", iMap.getString("BASVURU_NO")).put("TAHSIS_NUMARASI",
							iMap.getString("SGK_AYLIK_BILGILERI", i, "AYLIK_ID")).put("SIGORTA_KOLU",
							iMap.getString("SGK_AYLIK_BILGILERI", i, "SIGORTA_KOLU")).put("SGK_SONUC_KODU",
							iMap.getString("SGK_AYLIK_BILGILERI", i, "BLOKE_SONUC_KODU")).put("SGK_SONUC_ACIKLAMA",
							iMap.getString("SGK_AYLIK_BILGILERI", i, "BLOKE_SONUC_ACIKLAMA")));
					}
				}
			}
		} catch(Exception e) {
			logger.error("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY err:", e);
		}

		return oMap;
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_BIR_BASVURU_AYLIK_LOG")
	public static GMMap logMaasBilgileri(GMMap iMap) {
		
		GMMap logMap = new GMMap();
		
		String log_id = (String) GMServiceExecuter.executeNT("BNSPR_PTT_EMEKLI_SORGU_GET_LOG_ID", logMap).get("LOG_ID");
		
		long timeInMillis = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS");
		String time = sdf.format(new Date(timeInMillis));
		
		logMap.put("PARAM_REF_TUR", "BIR_BASVURU");
		logMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
		logMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
		logMap.put("REQUEST_DATA", logMap.toString());
		logMap.put("RESPONSE_DATA", iMap.get("AYLIK_LISTESI").toString());
		logMap.put("LOG_ID", log_id);
		logMap.put("REQUEST_TYPE", "odemeSorgula");
		logMap.put("RESULT_CODE", 2);
		logMap.put("QUERY_RESULT_STATUS", "SUCCESS");
		logMap.put("RESPONSE_TIME", time);
		logMap.put("DURATION", "0");
		
		for (int i = 0; i < iMap.getSize("AYLIK_LISTESI"); i++) {
			
			SgkInstitution.Code sgkInstitutionCode = SgkInstitution.Code.getEnum(String.valueOf(Integer.parseInt(iMap
				.getString("AYLIK_LISTESI", i, "MAAS_ALINAN_KURUM"))));

			logMap.put("MAAS_TABLE", i, "ACIKLAMA", iMap.get("AYLIK_LISTESI", i, "ACIKLAMA"));
			logMap.put("MAAS_TABLE", i, "KIMLIK_NO", logMap.get("TC_KIMLIK_NO"));
			logMap.put("MAAS_TABLE", i, "KURUM_AD", sgkInstitutionCode.getDescription());
			logMap.put("MAAS_TABLE", i, "KURUM_KOD", iMap.getInt("AYLIK_LISTESI", i, "MAAS_ALINAN_KURUM"));
			logMap.put("MAAS_TABLE", i, "MAAS_TUTAR", iMap.get("AYLIK_LISTESI", i, "MAAS_TUTARI"));
			logMap.put("MAAS_TABLE", i, "MAAS_YER", getInstitutionPlaceCode(iMap.getInt("AYLIK_LISTESI", i, "MAAS_ALINAN_KURUM")));
			logMap.put("MAAS_TABLE", i, "TAHSIS_NO", iMap.get("AYLIK_LISTESI", i, "TAHSIS_NUMARASI"));
			logMap.put("MAAS_TABLE", i, "MAAS_HAREKET_TARIHI", iMap.get("AYLIK_LISTESI", i, "ONCEKI_MAAS_ODEME_TARIHI"));
			logMap.put("MAAS_TABLE", i, "ODEME_BASLANGIC_TARIHI", iMap.get("AYLIK_LISTESI", i, "SON_MAAS_TARIHI"));
			logMap.put("MAAS_TABLE", i, "ODEME_DONEM", iMap.get("AYLIK_LISTESI", i, "EMEKLI_MAAS_DONEM"));
			logMap.put("MAAS_TABLE", i, "KURUM_DONEM", iMap.get("AYLIK_LISTESI", i, "KURUM_DONEM"));
		}
		
		GMServiceExecuter.executeNT("BNSPR_PTT_EMEKLI_SORGU_CREATE_LOG", logMap);
		GMServiceExecuter.executeNT("BNSPR_PTT_EMEKLI_SORGU_CREATE_DETAY", logMap);
		
		return logMap;
	}
	
	/**
	 * Kurum de�eri kamu veya 3. �ah�s olmad��� durumda personel unvan kar��l���n� d�ner.
	 * 
	 * @param kurumTip	int
	 * @param unvan		String
	 * @return			PTT personeli i�in ana bankac�l�k'a ge�ilecek �nvan kodu
	 * @throws Exception
	 */
	public static String getPersonelUnvanKod(int kurumTip, String unvan) throws Exception {
		
		if(kurumTip != 4 || kurumTip != 5) {
			return null;
		}
		
		return (String) DALUtil.callOneParameterFunction("{? =  call PKG_PTT_KREDI.get_ptt_personel_unvan_kod(?)}", Types.VARCHAR, unvan);
	}
	
	/**
	 * TBD
	 * 
	 * @param yil	String
	 * @param ay	String
	 * 
	 * @return		Y�l ve ay karakter de�erlerinin birle�tirilmi� <code>String</code> de�eri
	 */
	private static String concatYilAy(String yil, String ay) {
		String yilAy = new String();

		if ((yil != null && yil.isEmpty()) && (ay != null && ay.isEmpty())) {
			return null;
		}

		if (yil == null) {
			if (ay == null) {
				return null;
			} else if (ay.length() == 0) {
				return null;
			} else if (ay.length() == 1) {
				return ("000" + ay);
			} else {
				return ("00" + ay);
			}
		}

		if (ay == null) {
			if (yil.length() == 0) {
				return null;
			} else if (yil.length() == 1) {
				return ("0" + yil + "00");
			} else {
				return (yil + "00");
			}
		}
		if (yil.length() == 0 || yil.equals("0"))
			yilAy = "00";
		else if (yil.length() == 1)
			yilAy = "0" + yil;
		else
			yilAy = yil;
		if (ay.length() == 0 || ay.equals("0"))
			yilAy = yilAy + "00";
		else if (ay.length() == 1)
			yilAy = yilAy + "0" + ay;
		else
			yilAy = yilAy + ay;

		return yilAy;
	}
	
	/**
	 * PTT �ny�z�ndan al�nan ek d�k�man de�erini d�ner.
	 * 
	 * @param iMap	GMMap
	 * @return		PTT ek d�k�man de�eri
	 */
	private static String getEkDokumanBilgi(GMMap iMap) throws Exception {
		
		String dokumanKod = "";
		Session session = DAOSession.getSession("BNSPRDal");
		
		ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session
				.createCriteria(ClksBirBasvuruTx.class)
				.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
		if(clksBirBasvuruTx != null && StringUtils.isNotEmpty(clksBirBasvuruTx.getEkDokuman()))
			dokumanKod = clksBirBasvuruTx.getEkDokuman();

		return dokumanKod;
	}
	
	/**
	 * Basvurunun ikinci taksit tutarini verir.
	 *
	 * @param basvuruNo	Kredi ba�vuru numaras�
	 * @return 			Taksit tutari
	 */
	private static BigDecimal getTaksitTutari(BigDecimal basvuruNo) throws SQLException {
		return (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_ptt_kredi.get_taksit_tutari(?,2)}", BnsprType.NUMBER,
			BnsprType.NUMBER, basvuruNo);
	}
	
	/**
	 * Yeni bir_basvuru trx ile gittigimiz durumda trx numarasini doner.
	 * 
	 * @param iMap 	GMMap
	 * @return
	 */
	private static GMMap getFReapplyTrxDetails(GMMap iMap) throws Exception {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class, iMap.getBigDecimal("ISLEM_NO_BANKA"));
			
			if(clksBirBasvuruTx != null && clksBirBasvuruTx.getBirBasvuruTxNo() != null) {
				oMap.put("F_REAPPLY", true);
				oMap.put("BNSPR_TRX_NO", clksBirBasvuruTx.getBirBasvuruTxNo());
				oMap.put("CLKS_TRX_NO", iMap.getBigDecimal("ISLEM_NO_BANKA"));
			}
			
		} catch(Exception e) {
			logger.error("tr.com.aktifbank.bnspr.clks.services.CLKSCreditServices.getFReapplyTrxDetails err: ", e);
			throw e;
		}
		
		return oMap;
	}
	
	/**
	 * Ba�vuruya ait taksi tutar�n� d�ner.
	 * 
	 * @param iMap	GMMap
	 * @return		<code>BASVURU_NO</code>'ya ait taksit tutar� de�erini <code>GMMap{TAKSIT_TUTARI}<code> alt�nda d�ner.
	 * 
	 * @see #getTaksitTutari(BigDecimal)
	 */
	@GraymoundService("CLKS_BIR_BASVURU_GET_TAKSIT_TUTARI")
	public static GMMap getTaksitTutari(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			oMap.put("TAKSIT_TUTARI", getTaksitTutari(iMap.getBigDecimal("BASVURU_NO")));
		} catch(Exception e) {
			logger.error("CLKS_BIR_BASVURU_GET_TAKSIT_TUTARI", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * TBD
	 * 
	 * @param iMap	GMMap
	 * @return
	 */
	@GraymoundService("CLKS_BASVURU_PTT_ICI_KKB_KAYDET")
	public static GMMap kaydetPTTKKB(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			List<?> list = new ArrayList<GMMap>();
			if(iMap.get("KKB_SONUC_DATA") instanceof List<?>) {
				list = (List<?>) iMap.get("KKB_SONUC_DATA");
			}
			GMMap tmp = (GMMap) list.get(0);
			String kmh_durumu = (String) tmp.get("KMH_DURUMU");
			String sorguAdim = iMap.getString("SORGU_ADIM");

			int kullandirimTableSize = tmp.getSize("GECMIS_KULLANDIRIMI_YAPILANLAR");
			int basvuruTableSize = tmp.getSize("GECMIS_ONAYLANMIS_BASVURULAR");

			Set<ClksPttKrediKkbKullandirim> kullandirimList = new HashSet<ClksPttKrediKkbKullandirim>();
			Set<ClksPttKrediKkbBasvuru> basvuruList = new HashSet<ClksPttKrediKkbBasvuru>();

			for (int i = 0; i < kullandirimTableSize; i++) {
				
				BigDecimal krediTutari = tmp.getBigDecimal("GECMIS_KULLANDIRIMI_YAPILANLAR", i, "TUTAR");
				BigDecimal vade = tmp.getBigDecimal("GECMIS_KULLANDIRIMI_YAPILANLAR", i, "VADE");
				BigDecimal taksitTutari = tmp.getBigDecimal("GECMIS_KULLANDIRIMI_YAPILANLAR", i, "TAKSIT_TUTARI");
				
				if(!BigDecimal.ZERO.equals(krediTutari) && BigDecimal.ZERO.equals(taksitTutari) && !BigDecimal.ZERO.equals(vade)) {
					taksitTutari = krediTutari.divide(vade, 2, RoundingMode.HALF_UP);
				} else if(BigDecimal.ZERO.equals(krediTutari) && !BigDecimal.ZERO.equals(taksitTutari) && !BigDecimal.ZERO.equals(vade)) {
					krediTutari = taksitTutari.multiply(vade);
				} else if(!BigDecimal.ZERO.equals(krediTutari) && !BigDecimal.ZERO.equals(taksitTutari) && BigDecimal.ZERO.equals(vade)) {
					vade = krediTutari.divide(taksitTutari, RoundingMode.HALF_UP);
				}
				
				Date kullandirimTarihi = new Date(tmp.getDate("GECMIS_KULLANDIRIMI_YAPILANLAR", i,"KULLANDIRIM_TARIHI").getTime());
				ClksPttKrediKkbKullandirimId id = new ClksPttKrediKkbKullandirimId(krediTutari, vade, taksitTutari, kullandirimTarihi, txNo);
				ClksPttKrediKkbKullandirim kullandirim = new ClksPttKrediKkbKullandirim();
				kullandirim.setId(id);
				kullandirimList.add(kullandirim);

			}

			for (int i = 0; i < basvuruTableSize; i++) {
				String basvuruSaati = tmp.getString("GECMIS_ONAYLANMIS_BASVURULAR", i, "BASVURU_SAATI");
				Date basvuruTarihi = new Date(tmp.getDate("GECMIS_ONAYLANMIS_BASVURULAR", i, "BASVURU_TARIHI").getTime());

				ClksPttKrediKkbBasvuruId id = new ClksPttKrediKkbBasvuruId(txNo, basvuruTarihi, basvuruSaati);
				ClksPttKrediKkbBasvuru basvuru = new ClksPttKrediKkbBasvuru(id);
				basvuruList.add(basvuru);

			}
			
			ClksPttKrediKkbData kkbSonucData = new ClksPttKrediKkbData(txNo, kmh_durumu, basvuruNo, sorguAdim);
			kkbSonucData.setKrediBasvuru(basvuruList);
			kkbSonucData.setKrediKullandirim(kullandirimList);
			session.saveOrUpdate(kkbSonucData);
			session.flush();

		} catch (Exception e) {
			logger.error("CLKS_BASVURU_PTT_ICI_KKB_KAYDET err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return new GMMap();
	}
	
	/**
	 * Kredi basvuru numarasina ait belge degiskenlerini doner.
	 *
	 * <p>* Zorunlu, ** Kosullu Zorunlu</p>
	 *
	 * @param iMap {BASVURU_NO}			Kredi basvuru numarasi
	 * @param iMap {DOCUMENT_LIST**}	Belge listesi
	 *
	 * @return						<code>{BELGE_DETAY=[{BELGE_KEY_VALUE=[{KEY, VALUE}]BELGE_ADI}]}</code>
	 * 
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_GET_DOCUMENT_VARIABLES")
	public static GMMap bnsprClksCreditGetDocumentVariables(GMMap iMap) {
		
		GMMap oMap = new GMMap(), tMap = new GMMap();
		int row = 0, rowDetails = 0;
		boolean belgeExists = false;

		List<String> documentCodes = null;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			if(!iMap.containsKey("DOCUMENT_LIST")) {
				oMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_basvuru.getbelgelist(?)}", "BELGE_LISTESI", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
			} else {
				@SuppressWarnings("unchecked")
				List<String> tmp = (List<String>) iMap.get("DOCUMENT_LIST");
				documentCodes = tmp;
			}
			
			List<?> list =  session.createCriteria(GnlParamText.class)
                    .add(Restrictions.eq("kod", "CLKS_BASVURU_BELGE_DETAY_SERVIS"))
                    .addOrder(Order.asc("siraNo"))
                    .list();
			
			Iterator<?> iterator = list.iterator();
			
			while(iterator.hasNext()) {
				
				belgeExists = false;
				
				/*
				param.getKey1(); // Belge Kodu
				param.getKey2(); // Belge Adi
				param.getText(); // Function
				*/
				
				GnlParamText param = (GnlParamText) iterator.next();

				if(!iMap.containsKey("DOCUMENT_LIST")) {
					for (int i = 0; i < oMap.getSize("BELGE_LISTESI"); i++) {
						if(param.getKey1().equals(oMap.getString("BELGE_LISTESI", i, "DOKUMAN_KOD"))) {
							belgeExists = true;
						}
					}
				} else {
					if(documentCodes.contains(param.getKey1())) {
						belgeExists = true;
					}
				}
				
				if(belgeExists) {
				
					oMap.put("BELGE_DETAY", row, "BELGE_ADI", param.getKey2());
					oMap.put("BELGE_DETAY", row, "BELGE_KODU", param.getKey1());
					oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call " + param.getText() + "(?)}", "INFO", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")));
					
					Object listObject = oMap.get("INFO");
					
					tMap.clear();
					rowDetails = 0;
					if ((listObject instanceof List)) {
						
						@SuppressWarnings("unchecked")
						List<HashMap<String, Object>> listDetails = (List<HashMap<String, Object>>) listObject;
						
						for (Iterator<Entry<String, Object>> rowIterator = listDetails.get(0).entrySet().iterator(); rowIterator.hasNext();) {
							
							Entry<String, Object> rowEntry = rowIterator.next();
							
							if("PAYMENT_PLAN".equals(rowEntry.getKey())) {
							
								GMMap proxyMap = DALUtil.callOracleRefCursorFunction("{? = call " + param.getText() + "_payment_plan" + "(?)}", "BELGE_PAYMENT_PLAN", BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
								oMap.put("BELGE_DETAY", row, "BELGE_PAYMENT_PLAN", proxyMap.get("BELGE_PAYMENT_PLAN"));
								
							} else {
							
								tMap.put("BELGE_KEY_VALUE", rowDetails, "KEY", rowEntry.getKey());
								tMap.put("BELGE_KEY_VALUE", rowDetails, "VALUE", rowEntry.getValue());
								
								rowDetails++;
							}
						}
						
						oMap.put("BELGE_DETAY", row, "BELGE_KEY_VALUE", tMap.get("BELGE_KEY_VALUE"));
						oMap.remove("INFO");
					}
					
					row++;
				}
			}
			
			oMap.remove("BELGE_LISTESI");
			
			return oMap;
		} 
		
		catch (Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_GET_DOCUMENT_VARIABLES err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * 
	 * PTT Kredi HOBIM eksik evrak tamamlama ak��� arkas�nda �a��r�l�r. 
	 *
	 * @param iMap	GMMap {BASVURU_NO}
	 *
	 * @return 		{BARKOD_NUMARASI, BELGE_LISTESI=[{}]}
	 */
	@GraymoundService("CLKS_KREDI_EKSIK_EVRAK_TAMAMLA")
	public static GMMap krediEksikEvrakTamamla(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String ISLEM_TIP_EKSIK_EVRAK = "E";
		
		try {
			
			// Eksik evrak sorgulama
			iMap.putAll(GMServiceExecuter.call("CLKS_KREDI_LISTESI", new GMMap()
				.put("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))
				.put("islemTip", ISLEM_TIP_EKSIK_EVRAK)
				.put("tarihBas", "")
				.put("tarihSon", "")));
			
			// Case: Eksik evrak yok.
			if(iMap.getSize("islemListesi") == 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1599));
			}
			
			iMap.put("ISLEM_NO_BELGE", iMap.getString("islemListesi", 0, "ISLEM_NO_BELGE"));
			
			// Evrak listesi sorgulama
			iMap.putAll(GMServiceExecuter.call("CLKS_PTT_CONTRACTUAL_INFO", new GMMap()
				.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))));
			
			for (int i = 0; i < iMap.getSize("BELGE_LISTESI"); i++) {
				iMap.put("BELGE_LISTESI", i, "evrakTeslimEdilmismi", "E".equals(iMap.getString("BELGE_LISTESI", i, "evrakTeslimEdilmismi")) ? true : false);
			}
			
			iMap.remove("SORUN_VARMI");
			
			// Eksik evrak tamamlama
			GMServiceExecuter.call("CLKS_PTT_CONTRACTUAL_REQUEST", iMap.put("KONTROL_SAVE_OR_UPDATE", "-1"));
			
			oMap.put("BARCODE", iMap.getString("BARKOD_NUMARASI"));
			oMap.put("BELGE_LISTESI", iMap.get("BELGE_LISTESI"));
		}
		
		catch (Exception e) {
			
			logger.error("CLKS_KREDI_EKSIK_EVRAK_TAMAMLA err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * PTT kanal�ndan ger�ekle�en kredi ba�vurular�nda upsell bilgisini g�nceller.
	 * 
	 * @param iMap	GMMap {BASVURU_NO, TUTAR, UPSELL_LIMIT}
	 * @return		E�er upsell �nerisi, kabul edilmi� ise, map i�inde yer alan <code>F_UPSELL</code>
	 * 				de�eri <code>true</code> olarak d�ner aksi durumda <code>null</code> bir <code>GMMap</code> nesnesi
	 * 				d�ner.
	 */
	@GraymoundService("CLKS_UPSELL_BILDIRIM")
	public static GMMap clksUpsellBildirim(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			if(iMap.get("BASVURU_NO") != null) {
			
				Session session = DAOSession.getSession("BNSPRDal");
				
				BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"), LockMode.UPGRADE_NOWAIT);
			
				if (birBasvuru != null) {
					
					// Case: Upsell oneri, upsell kabul
					if("U".equals(birBasvuru.getBasvuruTeklifTur()) && iMap.containsKey("TUTAR") && iMap.getBigDecimal("TUTAR").compareTo(birBasvuru.getBayiUrunTutari()) > 1) {
						birBasvuru.setBasvuruTeklifOnay("E");
						oMap.put("F_UPSELL", true);
					// Case: Upsell oneri
					} else if(!"U".equals(birBasvuru.getBasvuruTeklifTur()) && iMap.containsKey("UPSELL_LIMIT")) {
						birBasvuru.setBayiUrunTutari(iMap.getBigDecimal("TUTAR"));
						birBasvuru.setBasvuruTeklifTur("U");
						birBasvuru.setBasvuruTeklifTutar(iMap.getBigDecimal("UPSELL_LIMIT"));
					} else {
						; // Do nothing
					}
					session.saveOrUpdate(birBasvuru);
					session.flush();
				}
			}
			
		} catch(Exception e) {
			logger.error("CLKS_UPSELL_BILDIRIM err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap; 
	}
	
	/**
	 * Dijital belge g�nderimi i�in ilgili belgeleri DYS'ye kay�t eder, m��teri �zerinde i�aretler ve 
	 * SMS talebi olu�turur.
	 * 
	 * <p>* Zorunlu, ** Kosullu Zorunlu</p>
	 * 
	 * @param iMap {BASVURU_NO*}		Kredi ba�vuru numaras�
	 * @param iMap {ISLEM_NO_BANKA*}	Transaction numaras�
	 * @return
	 * @throws GMRuntimeException Hatal�/Eksik girdi ge�ilir ise veya SMS G�nderim talebi ger�ekle�mez ise
	 * 
	 * @see <a href="http://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRCurrentAccounts/src/tr/com/calikbank/bnspr/currentaccounts/services/CurrentAccountsCommonServices.java?r=425367">
	 * BNSPR_COMMON_SEND_QS_DOCUMENT</a>
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_SEND_DOCUMENTS")
	public static GMMap bnsprClksCreditSendDocuments(GMMap iMap) {

		/**
		 * TODO Genelle�tirilecektir, 2024 kodu i�in �zelle�tirilmi� olarak implement edildi.
		 */
		
		GMMap oMap = new GMMap();
		HashMap<String, Object> parameters = new HashMap<String, Object>();
		String tableName = "RESULT";
		final String documentCode = "2024", messageNo = "5759", referenceType = "2";
		
		try {
			
			if(!iMap.containsKey("BASVURU_NO")) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 330).put("P1", "BASVURU_NO"));
			} else if(!iMap.containsKey("ISLEM_NO_BANKA")) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 330).put("P1", "ISLEM_NO_BANKA"));
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru basvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			ClksBirBasvuruKimlikTx kimlik = (ClksBirBasvuruKimlikTx) session.get(ClksBirBasvuruKimlikTx.class, iMap.getBigDecimal("ISLEM_NO_BANKA"));
			
			if(basvuru == null || kimlik == null) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 50009));
			}
			
			oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_ptt_kredi.get_sobf_info(?,?)}", tableName,
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, "0"));
			
			String adres = (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.basvuru_sozlesme_adres(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));
			
			parameters.put("KREDI_TURU", oMap.getString(tableName, 0, "KREDI_TURU"));
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("TC_KIMLIK_NO", kimlik.getTcKimlikNo());
			parameters.put("TELEFON", kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo()));
			parameters.put("ADRES", adres);
			parameters.put("VADE", oMap.getBigDecimal(tableName, 0, "VADE"));
			parameters.put("ONAY_TUTAR", oMap.getString(tableName, 0, "ONAY_TUTAR"));
			parameters.put("TAKSIT_TUTARI", oMap.getString(tableName, 0, "TAKSIT_TUTARI"));
			parameters.put("AKDI_FAIZ_AYLIK", oMap.getString(tableName, 0, "AKDI_FAIZ_AYLIK"));
			parameters.put("AKDI_FAIZ_YILLIK", oMap.getString(tableName, 0, "AKDI_FAIZ_YILLIK"));
			parameters.put("GECIKME_FAIZ_ORANI", oMap.getString(tableName, 0, "GECIKME_FAIZ_ORANI"));
			parameters.put("EFEKTIF_FAIZ_ORANI_AYLIK", oMap.getString(tableName, 0, "EFEKTIF_FAIZ_ORANI_AYLIK"));
			parameters.put("EFEKTIF_FAIZ_ORANI_YILLIK", oMap.getString(tableName, 0, "EFEKTIF_FAIZ_ORANI_YILLIK"));
			parameters.put("TOPLAM_GERI_ODEME_TUTARI", oMap.getString(tableName, 0, "TOPLAM_GERI_ODEME_TUTARI"));
			parameters.put("KREDI_TAHSIS_UCRETI", oMap.getString(tableName, 0, "KREDI_TAHSIS_UCRETI"));
			parameters.put("URUN_BILGISI", oMap.getString(tableName, 0, "URUN_BILGISI"));
			parameters.put("SATICI_ADI", oMap.getString(tableName, 0, "SATICI_ADI"));
			parameters.put("ADI_SOYADI", oMap.getString(tableName, 0, "ADI_SOYADI"));
			parameters.put("BASVURU_TARIHI", oMap.getString(tableName, 0, "BASVURU_TARIHI"));
			parameters.put("BAGLI_KREDI_NITELIGI", oMap.getString(tableName, 0, "BAGLI_KREDI_NITELIGI"));
			parameters.put("BANKA_ADI", oMap.getString(tableName, 0, "BANKA_ADI"));
			parameters.put("BANKA_ADRES", oMap.getString(tableName, 0, "BANKA_ADRES"));
			parameters.put("TRX_NO", oMap.getBigDecimal(tableName, 0, "TRX_NO"));
			oMap.remove(tableName);
			
			List<String> reportNames = new ArrayList<String>();
			reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU_PTT_1");
			reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU_PTT_2");
			reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU_PTT_3");
			reportNames.add("BNSPR_RAP3171_SOBF_ODEME_PLANI_PTT");
			
			iMap.put("SAVE_DOCUMENT", true);		
			iMap.put("DOCUMENT_CODE", documentCode);
			iMap.put("CUSTOMER_NO", basvuru.getMusteriNo());
			iMap.put("REFERENCE", iMap.getBigDecimal("BASVURU_NO"));
			iMap.put("REFERENCE_TYPE", referenceType);
			iMap.put("MSISDN", kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo()));
			iMap.put("MESSAGE_NO", messageNo);
			iMap.put("MESSAGE_CONTENT", new GMMap()
				.put("P2", parameters.get("ADI_SOYADI").toString())
				.put("P3", iMap.getString("BASVURU_NO")));
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			parameters.put("KISISEL_BILGILER_GIZLE_EH", "E");				
			iMap.put("DOCUMENT_PARAMETERS", parameters);
			
			oMap = GMServiceExecuter.call("BNSPR_COMMON_SEND_QS_DOCUMENT", iMap);
			
			iMap.put("MUSTERI_NO", basvuru.getMusteriNo());
			iMap.put("DOKUMAN_KOD", "2060");		
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			parameters.put("KISISEL_BILGILER_GIZLE_EH", "H");	
			iMap.put("DOCUMENT_PARAMETERS", parameters);				
			GMServiceExecuter.call("SMS_REPORT_CREDIT_DYS_UPLOAD", iMap);
			
			return oMap;
			
		} catch (Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_SEND_DOCUMENTS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_CLKS_IS_SMS_CREDIT_APPLICATION")
	public static GMMap isSMSCreditApplicationService(GMMap iMap) {
		GMMap outMap = new GMMap();
		BigDecimal applicationNo=iMap.getBigDecimal("BASVURU_NO");
		boolean result = isSMSCreditApplication(applicationNo);
		if (result) {
			outMap.put("IS_SMS_CREDIT", "E");
		}else {
			outMap.put("IS_SMS_CREDIT", "H");
		}
		return outMap;
	}
	
	public static boolean isSMSCreditApplication(BigDecimal applicationNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class,
				applicationNo);
		if (clksBirBasvuruSmsTalep!=null) {
			return true;
		}else {
			return false;
		}
	}
	
	public static boolean isSMSCreditConvertedRetireeApplication(BigDecimal applicationNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class,
				applicationNo);
		if (birBasvuru!=null) {
			String smsCreditCampaignCode = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "CLKS_SMS_KREDI").put("KEY", "KAMPANYA_KODU")).getString("TEXT");

			if (birBasvuru.getKampKod().toString().equals(smsCreditCampaignCode)) {
				return false;
			}
			else {
				return true;
			}
		}else {
			return false;
		}
	}
	
	@GraymoundService("BNSPR_CLKS_CONVERT_SMS_CREDIT_CAMPAIGN_RETIREE_CAMPAIGN")
	public static GMMap convertSMSCreditToRetireeApplication(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
			String kampKod = iMap.getString("URUN_KAMP_KOD");
			String smsCreditCampaignCode = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "CLKS_SMS_KREDI").put("KEY", "KAMPANYA_KODU")).getString("TEXT");
			String retireeCampaignCode = DALUtil.getResult("SELECT deger FROM bnspr.gnl_parametre WHERE KOD = 'PTT_SMS_SUBE_EMEKLI_KAMP'");
			if (smsCreditCampaignCode.equals(kampKod)) {
				
				ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session
						.createCriteria(ClksBirBasvuruSmsTalep.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();	

				if (clksBirBasvuruSmsTalep!=null) {
					iMap.put("ISLEM_NO_BANKA", clksBirBasvuruSmsTalep.getTxNo());;
				}
				kampKod = retireeCampaignCode;
			}
			iMap.put("URUN_KAMP_KOD", kampKod);
			return	iMap;
	}
}