package tr.com.aktifbank.bnspr.clks.services;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.integration.ftp.FtpClient;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.service.loader.GMServiceUtil;
import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.dao.ClksPttDosTrnsfer;

public class CLKSPttFileTransferServices {

	private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMdd");
	private static SimpleDateFormat headerDateFormat = new SimpleDateFormat("yyyyMMdd");
	private static String ROOT = GMServer.getProperty("graymound.home", null)
			+ File.separator + "Server" + File.separator + "Content"
			+ File.separator + "Root";

	private static Logger logger = Logger
			.getLogger(CLKSPttFileTransferServices.class);

	@GraymoundService("CLKS_PTT_BAYI_KREDI_KOMISYON_FILE_TRANSFER")
	public static GMMap clksPttBayiKrediDosyaGonder(GMMap iMap) {

		Calendar beginDate = Calendar.getInstance();
		Calendar endDate = Calendar.getInstance();
		GMMap oMap = new GMMap();
		try {

			beginDate.add(Calendar.DAY_OF_YEAR, -1);
			beginDate.set(Calendar.HOUR, 0);
			beginDate.set(Calendar.MINUTE, 0);
			beginDate.set(Calendar.SECOND, 0);
			endDate.add(Calendar.DAY_OF_YEAR, -1);
			endDate.set(Calendar.HOUR, 23);
			endDate.set(Calendar.MINUTE, 59);
			endDate.set(Calendar.SECOND, 59);

			Object[] inputValues = new Object[10];
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = beginDate.getTime();
			inputValues[2] = BnsprType.DATE;
			inputValues[3] = endDate.getTime();
		  
			
			
			
		   iMap.put("BASLANGIC_TARIHI", beginDate.getTime());
			iMap.put("BITIS_TARIHI", endDate.getTime());
			oMap = GMServiceExecuter
					.call("BNSPR_BAYI_PTT_KREDI_KOMISYON", iMap);

			String krediKomisyon = "KREDI_KOMISYON";
			int tableSize = oMap.getSize(krediKomisyon);
			
			Calendar c1 = Calendar.getInstance();
			c1.add(Calendar.DAY_OF_YEAR, -1);
			String fileName = "AB"
					+ dateFormat.format(c1.getTime());
			if (tableSize > 0) {
				StringBuffer buff = new StringBuffer();
				String header = "H"
						+ headerDateFormat.format(Calendar.getInstance()
								.getTime()) + "00730"
						+fileName		
						+ new String(new char[178]).replace('\0', ' ') + "\r\n";

				BigDecimal totalAmount = new BigDecimal(0.0);
				BigDecimal totalcredit = new BigDecimal(0.0);
				buff.append(header);
              
				for (int row = 0; row < tableSize; row++) {
					String rowData = oMap
							.getString(
									krediKomisyon,
									row,
									"KURUM_KODU||TAHSIS_NO||TC_KIMLIK_NO||BASVURU_NO||KREDI_TUTARI||VADE||KULLANDIRIM_TARIHI||KOMISYON_TUTARI||FILLER");
					rowData = replace(rowData, ",", "", true);
					rowData=rowData+" ";
					datasaveTodb(rowData);
					totalAmount= totalAmount.add(getKomisyon(rowData));
					totalcredit= totalcredit.add(getCredit(rowData));
					buff.append(rowData + "\r\n");
				}
				DecimalFormatSymbols symbols = DecimalFormatSymbols
						.getInstance();
				String sm = String.valueOf(symbols.getDecimalSeparator());
				String totalAmountStr = String.valueOf(totalAmount);
				String totalcreditStr = String.valueOf(totalcredit);
			 
				if ((totalAmountStr.indexOf(".") + 3)<totalAmountStr.length()){
			       totalAmountStr = totalAmountStr.substring(0,
						totalAmountStr.indexOf(".") + 3);}
				
				if ((totalcreditStr.indexOf(".") + 3)<totalcreditStr.length()){
				totalcreditStr = totalcreditStr.substring(0,
						totalcreditStr.indexOf(".") + 3);}
				
				totalAmountStr = totalAmountStr.replace(".", "");
				
				totalcreditStr = totalcreditStr.replace(".", "");
				
				String footer = "F"
						+ String.format("%7s", tableSize).replace(' ', '0')
						+ String.format("%17s", totalAmountStr).replace(' ',
								'0')
						+ String.format("%17s", totalcreditStr).replace(' ',
								'0')
						+ new String(new char[158]).replace('\0', ' ');
				buff.append(footer);
			  logger.info("CLKS_PTT_BAYI_KREDI_KOMISYON_FILE_TRANSFER LIST out:"
						+ buff.toString());

			sendToFtpSite(buff);
			}else {
				sendMail("Bayi Kredi Komisyon",
						"Kayit olmadigi i�in dosya iletilmedi.", null, null);
			}
		} catch (Exception e) {
			logger.error("CLKS_PTT_BAYI_KREDI_KOMISYON_FILE_TRANSFER err:", e);
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		logger.info("CLKS_PTT_BAYI_KREDI_KOMISYON_FILE_TRANSFER out:"
				+ oMap.toString());
		return oMap;
	}

	private static BigDecimal getKomisyon(String rowData) {
		BigDecimal komisyon = new BigDecimal(0.0);
		try {
			if (rowData.trim().length() > 4) {

				DecimalFormatSymbols symbols = DecimalFormatSymbols
						.getInstance();
				String sm = String.valueOf(symbols.getDecimalSeparator());
				int len = rowData.trim().length();
				komisyon = new BigDecimal(rowData.substring(len - 4, len - 2)
						+ "." + rowData.substring(len - 2, len));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return komisyon;
	}
	
	private static BigDecimal getCredit(String rowData) {
		BigDecimal credit = new BigDecimal(0.0);
		try {
			if (rowData.trim().length() > 4) {
  
				DecimalFormatSymbols symbols = DecimalFormatSymbols
						.getInstance();
				String sm = String.valueOf(symbols.getDecimalSeparator());
				int len = rowData.trim().length();
				credit = new BigDecimal((rowData.substring(len - 45, len - 30)
						+ "." + rowData.substring(len - 30, len - 28)).trim());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return credit;
	}

	private static void sendMail(String subject, String mailBody, String fileName, File file) {

		try {
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
			GMMap xMap = new GMMap();

			xMap.put("PARAMETRE", "PTT_BAYI_KOM_MAIL");
			servisMap.put(
					"MAIL_TO",
					GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K",
							xMap).get("DEGER"));
			servisMap.put("MAIL_SUBJECT", subject);
			servisMap.put("MAIL_BODY", mailBody);
			servisMap.put("IS_BODY_HTML", "H");
			if (fileName != null) {
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", fileName);
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT",
						FileUtil.readFileToByteArray((File) file));
			}
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
					servisMap);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static String writeToFile(StringBuffer buff, String fileName) {

		String fullPath = null;
		BufferedWriter bw = null;
		FileOutputStream fout = null;
		try {
			fullPath = ROOT + File.separator + "files" + File.separator
					+ fileName;
			File file = new File(fullPath);
			fout = new FileOutputStream(file);
			bw = new BufferedWriter(new OutputStreamWriter(fout, "ISO-8859-9"));
			bw.write(buff.toString());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				bw.close();
				fout.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

		return fullPath;

	}

	private static String replace(String text, String name, String newName,
			boolean all) {
		if (newName == null || text == null) {
			return text;
		}

		StringBuffer textBuf = new StringBuffer(text);
		StringBuffer newTextBuf = new StringBuffer();
		int pos = -1;
		while ((pos = textBuf.indexOf(name)) >= 0) {
			String left = textBuf.substring(0, pos);
			newTextBuf.append(left);
			newTextBuf.append(newName);
			textBuf.delete(0, pos + name.length());
			if (all == false)
				break;
		}
		newTextBuf.append(textBuf);
		return newTextBuf.toString();
	}

	private static void sendToFtpSite(StringBuffer buff) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_TRN2070.read_gnl_sifre(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, "PTT_BYKK");
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			rSet.next();

			String serverUri = rSet.getString("ip");
			String username = rSet.getString("user_name");
			String password = rSet.getString("passwd");
			String path = rSet.getString("path");
			BigDecimal port = rSet.getBigDecimal("port");
			String ftpType = rSet.getString("FTP_TURU");
			
			Calendar c1 = Calendar.getInstance();
			c1.add(Calendar.DAY_OF_YEAR, -1);
			
			String fileName = "AB"
					+ dateFormat.format(c1.getTime())
					+ ".txt";

			String fullPath = writeToFile(buff, fileName);
			File file = new File(fullPath);
			FtpClient ftpClient = new FtpClient(serverUri, port, ftpType,
					username, password);
			ftpClient.put(path, fileName, file);

			sendMail("Bayi Kredi Komisyon", fileName + " dosyasi iletildi.",
					fileName, file);
			file.delete();

		} catch (Exception e) {
			e.printStackTrace();
			sendMail("Bayi Kredi Komisyon",
					" Dosya iletiminde hata olustu.\r\n"
							+ getExceptionStackTrace(e), null, null);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	private static void datasaveTodb(String str) {
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			
			ClksPttDosTrnsfer clkspttdostrnsfer =new ClksPttDosTrnsfer();
			clkspttdostrnsfer.setGonData(str);
			session.saveOrUpdate(clkspttdostrnsfer);
    		session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	//TY-2115
	  @GraymoundService("BNSPR_CLKS_SGK_SALARY_BLOCK_JOB")
      public static GMMap bnsprSgkSalaryBlockJob(GMMap iMap){
	      
	      GMConnection connection = null;
	      try{
             
              String BANKING_SERVICE = "DEALER"; 
                 connection = GMConnection.getConnection(BANKING_SERVICE);
                   connection.serviceCall("CLKS_SGK_SALARY_BLOCK_SEND_JOB_SERVICE", iMap);
          }catch (Exception e) {
              throw ExceptionHandler.convertException(e);
          }finally {                
              if (connection != null) {  try { connection.close(); } catch (IOException e) { e.printStackTrace(); } }
       }
	      return iMap;
      }
	  

	public static String getExceptionStackTrace(Exception e) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(bos);
		e.printStackTrace(ps);
		ps.flush();
		return new String(bos.toByteArray(), 0, bos.size());
	}
	
	
	@GraymoundService("CLKS_PTT_BAYI_KREDI_KOMISYON_MANUEL")
	public static GMMap clksPttBayiKrediDosyaManuel(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
		   // Startdate yyyyyMMdd  BASLANGIC_TARIHI"
		  //End Date yyyyyMMdd"BITIS_TARIHI"
			oMap = GMServiceExecuter
					.call("CLKS_PTT_BAYI_KREDI_KOMISYON_MANUEL", iMap);

			String krediKomisyon = "KREDI_KOMISYON";
			int tableSize = oMap.getSize(krediKomisyon);
			
			Calendar c1 = Calendar.getInstance();
			c1.add(Calendar.DAY_OF_YEAR, -1);
			String fileName = "AB"
					+ dateFormat.format(c1.getTime());
			if (tableSize > 0) {
				StringBuffer buff = new StringBuffer();
				String header = "H"
						+ headerDateFormat.format(Calendar.getInstance()
								.getTime()) + "00730"
						+fileName		
						+ new String(new char[178]).replace('\0', ' ') + "\r\n";

				BigDecimal totalAmount = new BigDecimal(0.0);
				BigDecimal totalcredit = new BigDecimal(0.0);
				buff.append(header);
              
				for (int row = 0; row < tableSize; row++) {
					String rowData = oMap
							.getString(
									krediKomisyon,
									row,
									"KURUM_KODU||TAHSIS_NO||TC_KIMLIK_NO||BASVURU_NO||KREDI_TUTARI||VADE||KULLANDIRIM_TARIHI||KOMISYON_TUTARI||FILLER");
					rowData = replace(rowData, ",", "", true);
					rowData=rowData+" ";
					datasaveTodb(rowData);
					totalAmount= totalAmount.add(getKomisyon(rowData));
					totalcredit= totalcredit.add(getCredit(rowData));
					buff.append(rowData + "\r\n");
				}
				DecimalFormatSymbols symbols = DecimalFormatSymbols
						.getInstance();
				String sm = String.valueOf(symbols.getDecimalSeparator());
				String totalAmountStr = String.valueOf(totalAmount);
				String totalcreditStr = String.valueOf(totalcredit);
			 
				if ((totalAmountStr.indexOf(".") + 3)<totalAmountStr.length()){
			       totalAmountStr = totalAmountStr.substring(0,
						totalAmountStr.indexOf(".") + 3);}
				
				if ((totalcreditStr.indexOf(".") + 3)<totalcreditStr.length()){
				totalcreditStr = totalcreditStr.substring(0,
						totalcreditStr.indexOf(".") + 3);}
				
				totalAmountStr = totalAmountStr.replace(".", "");
				
				totalcreditStr = totalcreditStr.replace(".", "");
				
				String footer = "F"
						+ String.format("%7s", tableSize).replace(' ', '0')
						+ String.format("%17s", totalAmountStr).replace(' ',
								'0')
						+ String.format("%17s", totalcreditStr).replace(' ',
								'0')
						+ new String(new char[158]).replace('\0', ' ');
				buff.append(footer);
			  logger.info("CLKS_PTT_BAYI_KREDI_KOMISYON_MANUEL LIST out:"
						+ buff.toString());

			sendToFtpSite(buff);
			}else {
				sendMail("Bayi Kredi Komisyon",
						"Kayit olmadigi i�in dosya iletilmedi.", null, null);
			}
		} catch (Exception e) {
			logger.error("CLKS_PTT_BAYI_KREDI_KOMISYON_MANUEL err:", e);
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		logger.info("CLKS_PTT_BAYI_KREDI_KOMISYON_MANUEL out:"
				+ oMap.toString());
		return oMap;
	}

}
