package tr.com.aktifbank.bnspr.clks.services;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import tr.com.aktifbank.intracardservicesintegration.CardServices;
import tr.com.aktifbank.oceanserviceintegration.OceanSendCourierInfo;
import tr.com.aktifbank.proceedserviceintegration.ProceedSendCourierInfo;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.OceanConstants;
import Services.Integration.Ocean.Smartsoft.ServiceResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class PttCourierServices {

	private static Logger logger = Logger.getLogger(PttCourierServices.class);

	@GraymoundService("PTT_SEND_COURIER_INFO")
	public static GMMap pttCourierSendInfo(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			String dest = null;
			GMMap iMap2 = new GMMap();
			String key1 = null;
			if ("8".equals(iMap.getString("BARCODE").substring(0, 1))) {
				key1 = iMap.getString("BARCODE").substring(0, 3);
			}
			else if ("7".equals(iMap.getString("BARCODE").substring(0, 1))) {
				key1 = iMap.getString("BARCODE").substring(0, 4);
			}
			else {
				key1 = iMap.getString("BARCODE").substring(0, 2);
			}

			iMap2.put("KOD", "BARKOD_KURYE_YONLENDIRME");
			iMap2.put("KEY", key1);
			dest = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap2).getString("TEXT");

			String cardNo = getCardNoFromBarcode(iMap.getString("BARCODE"), dest);
			if (BnsprOceanCommonFunctions.isNewCard(null, cardNo, null)) {
				oMap = GMServiceExecuter.call("BNSPR_GENERAL_SEND_COURIER_INFO", iMap);
				oMap.put("RESPONSE", oMap.getString("RETURN_CODE"));
				oMap.put("RESPONSE_DATA", OceanConstants.Ocean_Result_Success);
			}
			else {

				if (dest.equals("O")) {

					ServiceResponse response = OceanSendCourierInfo.sendCourierInfo(iMap.getString("BARCODE"), iMap.getString("PROCESS_DATE"), iMap.getString("PROCESS_TIME"), iMap.getString("DSCR"), iMap.getString("PROCESS_STATUS"), iMap.getString("IDENTITY_NO"), iMap.getString("COURIER_SUB_CODE"), iMap.getString("COURIER_RETRY_COUNT"), iMap.getString("REGION_CODE"), iMap.getString("REGION_NAME"), iMap.getString("AGENT_CODE"), iMap.getString("AGENT_NAME"), iMap.getString("COURIER_CODE"), iMap.getString("COURIER_NAME"), iMap.getString("COMPANY_CODE"), iMap.getString("ADDRESS_TYPE"), iMap.getString("ADRESS"), iMap.getString("TOWN"), iMap.getString("CITY"), iMap.getString("CITY_CODE"), iMap.getString("POST_CODE"), iMap.getString("COURIER_CALLER_NAME"), getUserBranch(), getUser(), iMap.getString("DELIVERY_PERSON_NAME"));
					oMap.put("RESPONSE", response.getReturnCode());
					oMap.put("RESPONSE_DATA", response.getReturnDescription());

				}
				else if (dest.equals("I")) {
					Services.Integration.Intracard.Smartsoft.ServiceResponse response2 = CardServices.sendCourierInfo(iMap.getString("BARCODE"), iMap.getString("PROCESS_DATE"), iMap.getString("PROCESS_TIME"), iMap.getString("DSCR"), iMap.getString("PROCESS_STATUS"), iMap.getString("IDENTITY_NO"), iMap.getString("COURIER_SUB_CODE"), iMap.getString("COURIER_RETRY_COUNT"), iMap.getString("REGION_CODE"), iMap.getString("REGION_NAME"), iMap.getString("AGENT_CODE"), iMap.getString("AGENT_NAME"), iMap.getString("COURIER_CODE"), iMap.getString("COURIER_NAME"), iMap.getString("COMPANY_CODE"), iMap.getString("ADDRESS_TYPE"), iMap.getString("ADRESS"), iMap.getString("TOWN"), iMap.getString("CITY"), iMap.getString("CITY_CODE"), iMap.getString("POST_CODE"), iMap.getString("COURIER_CALLER_NAME"), getUserBranch(), getUser(), iMap.getString("DELIVERY_PERSON_NAME"));
					oMap.put("RESPONSE", response2.getReturnCode());
					oMap.put("RESPONSE_DATA", response2.getReturnDescription());
				}

				else if (dest.equals("P")) {
					Services.Integration.Smartsoft.ServiceResponse response2 = ProceedSendCourierInfo.sendCourierInfo(iMap.getString("BARCODE"), iMap.getString("PROCESS_DATE"), iMap.getString("PROCESS_TIME"), iMap.getString("DSCR"), iMap.getString("PROCESS_STATUS"), iMap.getString("IDENTITY_NO"), iMap.getString("COURIER_SUB_CODE"), iMap.getString("COURIER_RETRY_COUNT"), iMap.getString("REGION_CODE"), iMap.getString("REGION_NAME"), iMap.getString("AGENT_CODE"), iMap.getString("AGENT_NAME"), iMap.getString("COURIER_CODE"), iMap.getString("COURIER_NAME"), iMap.getString("COMPANY_CODE"), iMap.getString("ADDRESS_TYPE"), iMap.getString("ADRESS"), iMap.getString("TOWN"), iMap.getString("CITY"), iMap.getString("CITY_CODE"), iMap.getString("POST_CODE"), iMap.getString("COURIER_CALLER_NAME"), getUserBranch(), getUser(), iMap.getString("DELIVERY_PERSON_NAME"));
					oMap.put("RESPONSE", response2.getReturnCode());
					oMap.put("RESPONSE_DATA", response2.getReturnDescription());
				}

				else {
					oMap.put("RESPONSE", "85");
					oMap.put("RESPONSE_DATA", "TANIMSIZ BARKOD FORMATI. BARKOD NO: " + iMap.getString("BARCODE"));
				}
			}
		}
		catch (Exception e) {
			String mesaj;

			mesaj = ExceptionHandler.convertException(e).toString();
			oMap.put("RESPONSE", "99");
			oMap.put("RESPONSE_DATA", mesaj.trim());
			e.printStackTrace();
		}
		return oMap;
	}

	public static int getUserBranch() throws Exception {
		return GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_SUBE_KOD", new GMMap()).getInt("SUBE_KODU");
	}

	public static String getUser() {
		return (String) GMContext.getCurrentContext().getSession().get("USER_NAME");
	}

	public static String getCardNoFromBarcode(String barcode, String destination) {

		GMMap infoMap = new GMMap();
		GMMap oMap = new GMMap();
		String cardNo = StringUtils.EMPTY;
		infoMap.put("COURIER_BARCODE", barcode);
		if (OceanConstants.Card_Source_Intracard.equals(destination))
			oMap = GMServiceExecuter.call("BNSPR_INTRACARD_GET_CARD_APPLICANT_INFO", infoMap);
		else
			oMap = GMServiceExecuter.call("BNSPR_OCEANCARD_GET_CARD_APPLICANT_INFO", infoMap);

		cardNo = oMap.getString("CARD_NO");

		return cardNo;
	}
}
