package tr.com.aktifbank.bnspr.clks.services.core;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.ClksCrsinfo;
import tr.com.aktifbank.bnspr.dao.ClksislemMutabakat;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.graymound.util.GMToolkit;

public class CoreServices {

	private static Logger logger = Logger.getLogger(CoreServices.class);
	
	private static final String statusProcessed = "P";
	//private static final String statusCanceled = "2";
	
	private static final String responseSuccess = "2";
	private static final String responseFailure = "0";
	
	/**
	 * PTT kanali kredi ve bono urunu icin ozellesmis crs kayit atma servisi.
	 * 
	 * @param iMap {NATIONAL_IDENTITY_NUMBER}	TC kimlik numarasi
	 * @param iMap {CRS_INFO}				    Crs bilgisi
	 * @return									Bilgiler tabloya kayit atilir. 
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_CLKS_INSERT_CRS_INFO")
	public static GMMap bnsprClkCrsInfoInsert(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			if(iMap.containsKey("NATIONAL_IDENTITY_NUMBER") && iMap.containsKey("CRS_INFO")) {
				
				ClksCrsinfo clksCrsinfo = (ClksCrsinfo) session.get(ClksCrsinfo.class, iMap
					.getString("NATIONAL_IDENTITY_NUMBER"));
				
				if(clksCrsinfo == null) {
					clksCrsinfo = new ClksCrsinfo();
				}
				
					clksCrsinfo.setTcKimlikNo(iMap.getString("NATIONAL_IDENTITY_NUMBER"));
					clksCrsinfo.setCrsInfo(iMap.getString("CRS_INFO"));
					
					session.saveOrUpdate(clksCrsinfo);
					session.flush();
			 
				oMap.put("CRS_INSERT_INFO", "S");
				 
			} else {
				oMap.put("CRS_INSERT_INFO", "F");
			}
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_INSERT_CRS_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kanali kredi ve bono urunu icin ozellesmis crs sorgulama servisi.
	 * 
	 * @param iMap {NATIONAL_IDENTITY_NUMBER}	TC kimlik numarasi 
	 * @return									Varsayilan kanalda clks_crs_info tablosunda 
	 * 											crs bilgisi varsa  E (Evet) veya  H (Hayir) 
	 * 											degerini doner. Tablodam kay�t yok ise
	 *											Y (Yok) degerini doner.
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_CLKS_GET_CRS_INFO")
	public static GMMap getCrsInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			if(iMap.containsKey("NATIONAL_IDENTITY_NUMBER")) {
				
				BigDecimal customerNo = (BigDecimal) DALUtil.callOracleFunction(
					"{? = call pkg_musteri.Musteri_Varmi_TCKN(?)}", BnsprType.NUMBER, BnsprType.STRING, iMap
						.getString("NATIONAL_IDENTITY_NUMBER"));
				
				if(customerNo != null) {
					String fCrs = GMServiceExecuter.call("BNSPR_GET_MUSTERI_CRS",
						new GMMap().put("MUSTERI_NO", customerNo)).getString("F_CRS");
					
					if("E".equals(fCrs) || "R".equals(fCrs)){
						if("R".equals(fCrs)){ fCrs="H"; }
					    GMServiceExecuter.call("BNSPR_CLKS_INSERT_CRS_INFO", new GMMap().put("NATIONAL_IDENTITY_NUMBER", iMap
						.getString("NATIONAL_IDENTITY_NUMBER")).put("CRS_INFO", fCrs));
					}
				}

				ClksCrsinfo clksCrsinfo = (ClksCrsinfo) session.get(ClksCrsinfo.class, iMap
					.getString("NATIONAL_IDENTITY_NUMBER"));

				if(clksCrsinfo == null) {
					oMap.put("CRS_INFO", "Y");
				} else {
					oMap.put("CRS_INFO", clksCrsinfo.getCrsInfo());
				}
			} 
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_GET_CRS_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CLKS_SAVE_TRANSACTION_LOG")
	public static GMMap clksSaveTransactionLog(GMMap iMap) {
		
		try {
			logger.info("CLKS_SAVE_TRANSACTION_LOG > F_RECONCILIATION:" + 
				String.valueOf(iMap.getBoolean("F_RECONCILIATION")));
			
			if(!iMap.getBoolean("F_RECONCILIATION")) {
				
				GMMap dataMap = new GMMap(), logMap;
				Set<String> parameters = new HashSet<String>(Arrays.asList(new String[]{"CLIENT_SESSION_ID_RESERVED",
					"CLIENT_TRX_ID_RESERVED", "CORE_TRX_ID_RESERVED", "LOG_SERVICE", "SESSION_ID"}));
				
				for(Object key : iMap.keySet()) {
					if(!parameters.contains(key)) dataMap.put(key, iMap.get(key));
				}
				
				if(iMap.containsKey("LOG_SERVICE")) {
					GMServiceExecuter.call(iMap.getString("LOG_SERVICE"), iMap);
				}
				
				logMap = new GMMap()
					.put("TX_NO", iMap.getBigDecimal("islemNo", iMap.getBigDecimal("ISLEM_NO", iMap.getBigDecimal("TX_NO"))))
					.put("PTT_ISLEM_NO", iMap.getBigDecimal("islemNoPTT", iMap.getBigDecimal("pttSiraNo")))
					.put("TUTAR", iMap.getBigDecimal("tutar"))
					.put("DURUM_KODU", iMap.getString("STATUS_CODE", statusProcessed))
					.put("KONUM", iMap.getString("islemYeri"))
					.put("PERSONEL_SICIL", iMap.getString("kullaniciSicil"))
					.put("PERSONEL_AD_SOYAD", iMap.getString("iptaliYapanKullAdSoyad"))
					.put("ISLEM", iMap.getBigDecimal("islem"))
					.put("ACIKLAMA", iMap.getString("aciklama"));
				logMap.put("DATA", GMToolkit.serialize(dataMap));
				
				GMServiceExecuter.call("CLKS_ISLEM_LOG", logMap);
			}
	
			return new GMMap().put("RESPONSE", responseSuccess);
		
		} catch(Exception e) {

			logger.error("CLKS_SAVE_TRANSACTION_LOG err: " + e.getMessage());
			return new GMMap()
				.put("RESPONSE", responseFailure)
				.put("RESPONSE_DATA", e.getMessage());
		} 
	}
	
	@GraymoundService("CLKS_SAVE_TRANSACTION_STATUS")
	public static GMMap clksSaveTransactionStatus(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session	session	= DAOSession.getSession("BNSPRDal");
			
			ClksislemMutabakat clksIslemMutabakat = new ClksislemMutabakat(
				iMap.getBigDecimal("TRX_NO"),
				responseSuccess.equals(iMap.getString("RESPONSE")) ? "P" : "C",
				new java.util.Date());
			
			session.saveOrUpdate(clksIslemMutabakat);
			session.flush();
			return oMap;
			
		} catch(Exception e) {

			logger.error("CLKS_SAVE_TRANSACTION_STATUS err: " + e.getMessage());
			throw ExceptionHandler.convertException(e);
		}
	}
}
