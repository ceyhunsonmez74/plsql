package tr.com.aktifbank.bnspr.clks.services.scheduler;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.dao.ClksBonoTalepTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TransferServices {

	private static Logger logger = Logger.getLogger(TransferServices.class);

	@GraymoundService("BNSPR_CLKS_BONO_EVENT_NOTIFICATION")
	public static GMMap clksBonoEventNotification(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		PreparedStatement stmt2 = null;
		ResultSet rSet = null;
		ArrayList<ClksBonoTalepTx> readyForEvent = new ArrayList<ClksBonoTalepTx>();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select b.tx_no, b.musteri_tx_no, b.tc_kimlik_no , b.cep_tel_no,b.musteri_no from bnspr.clks_bono_talep_tx b where b.link_status = 'P' and  b.Link_Timestamp is not null and  (b.Link_Timestamp + 1/24/60*B.LINK_TTL) < SYSDATE");
			rSet = stmt.executeQuery();
			while (rSet.next()) {
				ClksBonoTalepTx item = new ClksBonoTalepTx();
				item.setCepTelNo(rSet.getString("CEP_TEL_NO"));
				item.setTcKimlikNo(rSet.getString("TC_KIMLIK_NO"));
				item.setMusteriNo(rSet.getBigDecimal("MUSTERI_NO"));
				item.setTxNo(rSet.getBigDecimal("TX_NO"));
				item.setMusteriTxNo(rSet.getBigDecimal("MUSTERI_TX_NO"));
				readyForEvent.add(item);
			}

			readyForEvent = prepareAndSentEvamEvent(readyForEvent);

			for (Iterator iterator = readyForEvent.iterator(); iterator.hasNext();) {
				ClksBonoTalepTx clksBonoTalepTx = (ClksBonoTalepTx) iterator.next();

				if (clksBonoTalepTx.getLinkStatus().equalsIgnoreCase("U")){
					stmt2 = conn.prepareStatement("UPDATE BNSPR.Clks_Bono_Talep_Tx b set b.link_status = 'U' where b.tx_no = ?");
					stmt2.setBigDecimal(1, clksBonoTalepTx.getTxNo());
					stmt2.execute();
				}
			}

		}
		catch (Exception e) {
			logger.error("BNSPR_CLKS_BONO_EVENT_NOTIFICATION err:", e);

		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}


//	Event Ad�	BONO_PTT_SMS_EXIT	
//	IOM_KEY (Senaryo_key)	MUSTERI_NO	numeric
//	Parametre_1	CEP_TEL	numeric
//	Paremetre_2	AD_SOYAD	String
//	Paremetre_3	TCKN	numeric

	private static ArrayList<ClksBonoTalepTx> prepareAndSentEvamEvent(ArrayList<ClksBonoTalepTx> readyForEvent) {
		
		String telefonTipGsm = "3", telefonFormatTumKod = "+UAT", telefon, email;
		
		for (ClksBonoTalepTx clksBonoTalepTx : readyForEvent) {
			try {		
				GMMap eventMap = new GMMap();
				GMMap map = new GMMap();
				
				map.put("SCENARIO_KEY", clksBonoTalepTx.getMusteriNo());
				telefon = (String) DALUtil.callOracleFunction("{ ? = call pkg_musteri.telefon(?,?,?) }", BnsprType.STRING, BnsprType.NUMBER, clksBonoTalepTx.getMusteriNo(),	BnsprType.STRING, telefonTipGsm, BnsprType.STRING, telefonFormatTumKod);
				map.put("CEP_TEL", telefon);
				GMMap mapMusteri = GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", new GMMap().put("MUSTERI_NO", clksBonoTalepTx.getMusteriNo()));
				map.put("AD_SOYAD", mapMusteri.getString("ADI") + " " + (mapMusteri.getString("IKINCI_ADI")== null ? "" : mapMusteri.getString("IKINCI_ADI")) + mapMusteri.getString("SOYADI"));
				map.put("TCKN",clksBonoTalepTx.getTcKimlikNo() );

				eventMap.put("SCENARIO_KEY", clksBonoTalepTx.getMusteriNo());
				eventMap.put("EVENT_TYPE_NO", "75");
				eventMap.put("EVENT_REF_NO", clksBonoTalepTx.getTcKimlikNo());
				eventMap.put("DATA_MAP", map);
				eventMap.put("INTEGRATION_TYPE", "S");
				GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", eventMap);
				clksBonoTalepTx.setLinkStatus("U");
			}catch (Exception e) {
					logger.error("BNSPR_CLKS_BONO_EVENT_NOTIFICATION err:", e);
			}
		}
		return readyForEvent;
	}

}