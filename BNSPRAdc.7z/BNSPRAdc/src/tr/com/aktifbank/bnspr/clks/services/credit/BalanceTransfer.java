package tr.com.aktifbank.bnspr.clks.services.credit;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Institution;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.PensionPayment;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.SgkInstitution;
import tr.com.aktifbank.bnspr.dao.ClksBbBorcTrOnboarding;
import tr.com.aktifbank.bnspr.dao.ClksBbBorcTransferi;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.istSgkEmekliSorguDetay;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.GnlBankaKodPr;
import tr.com.calikbank.bnspr.dao.GnlBankaSubeKodPr;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class BalanceTransfer {
	
	private static Logger logger = Logger.getLogger(BalanceTransfer.class);
	private static String AKTIF_BANK_BANK_CODE = "143"; 
	
	/**
	 * PTT Borc Transferi icin IBAN validasyonu gerceklestirir, IBAN'a ait banka kodu bilgisini saglar.
	 * 
	 * @param iMap {IBAN}			IBAN
	 * @param iMap {TC_KIMLIK_NO**}	TC Kimlik Numarasi
	 * <p>** opsiyonel</p>
	 * @return						{@code GMMap} i�inde {@code String} {@code BANK_CODE} key/value
	 * @throws GMRuntimeException 	IBAN teyit edilemedigi durumda, gecersiz IBAN girildigi durumda veya farkli diger
	 * 								tum istisnalarda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_IBAN_VALIDATION")
	public static GMMap ibanValidation(GMMap iMap) {

		GMMap oMap = new GMMap();
		String teyitSonucuGecerli = "1", listName = "BRANCHES";

		try {

			oMap.put("BANK_CODE", DALUtil.callOracleFunction("{? = call pkg_iban.iban_banka_kodu_al(?)}",
				BnsprType.STRING, BnsprType.STRING, iMap.getString("IBAN")));
			
			if(AKTIF_BANK_BANK_CODE.equals(oMap.getString("BANK_CODE"))) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(5891)));
			}
			
			if(iMap.containsKey("TC_KIMLIK_NO")) {

				/*if(!teyitSonucuGecerli.equals(GMServiceExecuter.call("BNSPR_KKB_IBAN_TEYIT", iMap).getString(
					"TEYIT_SONUCU"))) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap()
						.put("HATA_NO", BigDecimal.valueOf(5815)));
				}*/
			}

			Session session = DAOSession.getSession("BNSPRDal");
			
			oMap.put("BANK_NAME", ((GnlBankaKodPr) session.get(GnlBankaKodPr.class, oMap.getString("BANK_CODE")))
				.getBankaAdi());

			@SuppressWarnings("unchecked")
			List<GnlBankaSubeKodPr> branches = session.createCriteria(GnlBankaSubeKodPr.class).add(
				Restrictions.and(Restrictions.eq("id.bankaKod", oMap.getString("BANK_CODE")), Restrictions
					.isNull("kapanmaTarihi"))).addOrder(Order.asc("subeAdi")).list();			

			int index = 0;
			for(GnlBankaSubeKodPr branch : branches) {
				oMap.put(listName, index, "CODE", branch.getId().getSubeKod());
				oMap.put(listName, index, "NAME", branch.getSubeAdi());
				oMap.put(listName, index++, "PROVINCE_CODE", branch.getIlKod());
			}
			
			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_IBAN_VALIDATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kredi borc transferi onboarding surecinde emekli maasi tasima bilgisini saglar.
	 * 
	 * @param iMap {CUSTOMER_NO**}		Musteri numarasi
	 * @param iMap {APPLICATIONS**}		Basvuru listesi
	 * @param iMap {DATE**}				Maas Tasima Tarihi
	 * @return 							{@code IS_PENSION_SALARY_TRANSFERRED}, {@code RESPONSE_CODE}, keylerine sahip 
	 * 									{@code GMMap} nesnesi
	 * 
	 * @see BNSPR_CORE_EVENT_CREATE_EVENT
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_GET_PENSION_SALARY_INFO")
	public static GMMap getPensionSalaryInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			if(map.containsKey("APPLICATIONS")) {
				
				for(int i = 0; i < map.getSize("APPLICATIONS"); i++) {
					
					oMap.put("BASVURU", i, "BASVURU_NO", map.getBigDecimal("APPLICATIONS", i, "BASVURU_NO"));
					
					ClksBbBorcTrOnboarding application = (ClksBbBorcTrOnboarding) session.get(
						ClksBbBorcTrOnboarding.class, map.getBigDecimal("APPLICATIONS", i, "BASVURU_NO"));

					oMap.put("BASVURU", i, "MAAS_TASIMA", "H");
					oMap.put("BASVURU", i, "DEVAM", "E");
					
					if(application == null || "0".equals(application.getSorguDurum())) {
						oMap.put("BASVURU", i, "DEVAM", "H");
					} else if("1".equals(application.getMaasTasima())) {
						oMap.put("BASVURU", i, "DEVAM", "H");
						oMap.put("BASVURU", i, "MAAS_TASIMA", "E");
					}
				}
				
			} else if(map.containsKey("DATE")) {
				
				@SuppressWarnings("unchecked")
				List<ClksBbBorcTrOnboarding> list = session.createCriteria(ClksBbBorcTrOnboarding.class).add(
					Restrictions.eq("maasTasimaTarih", map.getDate("DATE"))).list();
				
				for(int i = 0; i < list.size(); i++) {
					
					BirBasvuru application = (BirBasvuru) session.get(BirBasvuru.class, list.get(i).getBasvuruNo());
					
					oMap.put("BASVURU", i, "BASVURU_NO", list.get(i).getBasvuruNo());
					oMap.put("BASVURU", i, "TC_KIMLIK_NO", application.getTcKimlikNo());
					oMap.put("BASVURU", i, "VADE", application.getVade());
					oMap.put("BASVURU", i, "KULLANDIRIM_TARIHI", application.getBasvuruTarihi());
					oMap.put("BASVURU", i, "MAAS_TASIMA", "1".equals(list.get(i).getMaasTasima()) ? "E" : "H");
					oMap.put("BASVURU", i, "DEVAM", "1".equals(list.get(i).getMaasTasima()) ? "H" : "0".equals(list
						.get(i).getSorguDurum()) ? "H" : "E");
				}
				
			} else {
			
				BigDecimal eventTypeNo = BigDecimal.valueOf(84);
				
				ClksBbBorcTrOnboarding application = (ClksBbBorcTrOnboarding) session.createCriteria(
					ClksBbBorcTrOnboarding.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("CUSTOMER_NO")))
					.addOrder(Order.desc("basvuruNo")).setMaxResults(1).uniqueResult();
				
				if(application == null) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(4457)));
				}
				
				GnlMusteri customer = (GnlMusteri) session.get(GnlMusteri.class, iMap.getBigDecimal("CUSTOMER_NO"));
				
				if(customer == null) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(1599)));
				}
				
				GMMap dataMap = new GMMap();
				dataMap.put("SCENARIO_KEY", application.getMusteriNo());
				dataMap.put("IS_PENSION_SALARY_TRANSFERRED", application.getMaasTasima());
				dataMap.put("APPLICATION_NO", application.getBasvuruNo());
				
				GMMap eventMap = GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", new GMMap().put("SCENARIO_KEY",
					application.getMusteriNo()).put("EVENT_TYPE_NO", eventTypeNo).put("EVENT_REF_NO",
					application.getBasvuruNo()).put("INTEGRATION_TYPE", "S").put("DATA_MAP", dataMap));
				
				oMap.put("NATIONAL_IDENTITIY_NUMBER", customer.getTcKimlikNo());
				oMap.put("EVENT_MAP", eventMap);
				oMap.put("RESPONSE", 2);
				oMap.put("IS_PENSION_SALARY_TRANSFERRED", dataMap.getString("IS_PENSION_SALARY_TRANSFERRED"));
				oMap.put("APPLICATION_NO", dataMap.getBigDecimal("APPLICATION_NO"));
			}
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_GET_PENSION_SALARY_INFO err:", e);
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		
		return oMap;
	}
	
	/**
	 * PTT kredi borc transferi onboarding surecinde ilgili bankaya ait kkb borcunun durum bilgisini saglar.
	 * 
	 * @param iMap {CUSTOMER_NO}		Musteri numarasi
	 * @return 							{@code IS_DEBT_PAID_OFF}, {@code RESPONSE_CODE}, keylerine sahip 
	 * 									{@code GMMap} nesnesi
	 * 
	 * @see BNSPR_CORE_EVENT_CREATE_EVENT
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_GET_PAYOFF_INFO")
	public static GMMap getPayoffInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		BigDecimal eventTypeNo = BigDecimal.valueOf(85);
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksBbBorcTrOnboarding application = (ClksBbBorcTrOnboarding) session.createCriteria(
				ClksBbBorcTrOnboarding.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("CUSTOMER_NO")))
				.addOrder(Order.desc("basvuruNo")).setMaxResults(1).uniqueResult();
			
			if(application == null) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(4457)));
			}
			
			GnlMusteri customer = (GnlMusteri) session.get(GnlMusteri.class, iMap.getBigDecimal("CUSTOMER_NO"));
			
			if(customer == null) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(1599)));
			}
			
			GMMap dataMap = new GMMap();
			dataMap.put("SCENARIO_KEY", application.getMusteriNo());
			dataMap.put("IS_DEBT_PAID_OFF", application.getKkbBorcKapatma());
			dataMap.put("APPLICATION_NO", application.getBasvuruNo());
			
			GMMap eventMap = GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", new GMMap().put("SCENARIO_KEY",
				application.getMusteriNo()).put("EVENT_TYPE_NO", eventTypeNo).put("EVENT_REF_NO",
				application.getBasvuruNo()).put("INTEGRATION_TYPE", "S").put("DATA_MAP", dataMap));
			
			oMap.put("NATIONAL_IDENTITIY_NUMBER", customer.getTcKimlikNo());
			oMap.put("EVENT_MAP", eventMap);
			oMap.put("RESPONSE", 2);
			oMap.put("IS_DEBT_PAID_OFF", dataMap.getString("IS_DEBT_PAID_OFF"));
			oMap.put("APPLICATION_NO", dataMap.getBigDecimal("APPLICATION_NO"));
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_GET_PAYOFF_INFO err:", e);
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		
		return oMap;
	}
	
	/**
	 * PTT kanalli borc transferi kredilerine konu olan emekli kurum bilgisini saglar.
	 * 
	 * @param iMap {APPLICATION_NO}		Borc transferi kredisi basvuru numarasi
	 * @return							{@code INSTITUTION} key degerine sahip {@link SgkInstitution}, {@code GMMap} 
	 * 									tipinde kapsanirak doner
	 * @throws GMRuntimeException
	 * 
	 * @see SgkInstitution
	 * @see Institution.ShortCode
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_GET_INSTITUTION")
	public static GMMap getInstitution(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		SgkInstitution institution;
		
		try {
		
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirBasvuru application = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			
			Map<String, String> restrictions = new HashMap<String, String>();
			restrictions.put("paramRefTur", "BIR_BASVURU");
			restrictions.put("paramRefId", iMap.getString("APPLICATION_NO"));
			restrictions.put("aylikId", application.getPttTahsisNumarasi());
			
			@SuppressWarnings("unchecked")
			List<istSgkEmekliSorguDetay> sskSalaries = session.createCriteria(istSgkEmekliSorguDetay.class).add(
				Restrictions.allEq(restrictions)).list();
			
			if(sskSalaries.size() > 0) {
				institution = SgkInstitution.valueOf(Institution.ShortCode.SSK);
			} else {
				institution = SgkInstitution.valueOf(Institution.ShortCode.BAGKUR);
			}
			
			oMap.put("INSTITUTION", institution);
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_GET_INSTITUTION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kanalli borc transferi kredisini emekli kredisine cevirir.
	 * 
	 * @param iMap {APPLICATION_NO}		Borc transferi kredisi basvuru numarasi
	 * @param iMap {PENSION_PAYMENT}	
	 * @return							Bos {@code GMMap}
	 * @throws GMRuntimeException
	 * 
	 * @see PensionPayment
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_UPDATE_APPLICATION")
	public static GMMap updateApplication(GMMap iMap) {
		
		try {
			
			PensionPayment payment = (PensionPayment) iMap.get("PENSION_PAYMENT");
			
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru application = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			application.setPttMaasAlinanKurum(payment.getInstitution().getShortCode().toString());
			application.setPttMaasPttDenmi("E");
			application.setPttMaasEvdenMi("H");
			application.setPttTahsisNumarasi(payment.getAllocationNumber());
			session.saveOrUpdate(application);
			session.flush();
			
			GMServiceExecuter.call("BNSPR_SGK_EMEKLI_UPDATE_KREDI_BILGISI_BLOKE_KOY", new GMMap().put("AYLIK_ID",
				payment.getPaymentId()).put("TCKN", application.getTcKimlikNo()).put("SIGORTA_KOLU",
				payment.getInstitution().getInsuranceChannel().toString()));
			
			return new GMMap();
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_UPDATE_APPLICATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	/**
	 * 
	 * @param iMap {TC_KIMLIK_NO}
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_RETIREE_PENSION_PAYMENTS")
	public static GMMap retireePensionPayments(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		List<BigDecimal> balanceTransferCampaignList = new ArrayList<BigDecimal>();
		String outListName = "MAAS_BILGILERI";
		
		try {
			
			GMMap dateMap = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap());
			String period = dateMap.getString("BANKA_TARIH").substring(0, 6);
			
			if(iMap.containsKey("MAAS_BILGILERI")) {
				String lastSalLoadDate = iMap.getString("MAAS_BILGILERI", 0, "EMEKLI_MAAS_DONEM");
				
				if(!period.substring(0,4).equals(lastSalLoadDate.substring(0,4))) {
					
				} else if(period.substring(0,4).equals(lastSalLoadDate.substring(0,4)) && 
					Integer.valueOf(period.substring(4)) - Integer.valueOf(lastSalLoadDate.substring(4)) > 2) {
					
				} else {
					return oMap;
				}
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			String borcTransferiCampaignCodes = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
					new GMMap().put("KOD", "CLKS_BORC_TRANSFERI").put("KEY", "KAMPANYA_KODU")).getString("TEXT");

			List<String> btCampaignList = Arrays.asList(borcTransferiCampaignCodes.split(","));
			for (String btCampaign : btCampaignList) {
				balanceTransferCampaignList.add(new BigDecimal(btCampaign));
			}
						
			@SuppressWarnings("unchecked")
			List<BirBasvuru> applications = session.createCriteria(BirBasvuru.class).add(
				Restrictions.and(Restrictions.and(Restrictions.and(Restrictions.eq("tcKimlikNo", iMap
					.get("TC_KIMLIK_NO")), Restrictions.in("durumKodu", new String[]{"EVRAKSIZ", "CEPTE"})),
					Restrictions.in("kampKod", balanceTransferCampaignList)), Restrictions
					.ne("pttMaasAlinanKurum", "6"))).list();

			for(BirBasvuru application : applications) {

				ClksBbBorcTransferi balanceTransfer = (ClksBbBorcTransferi) session.get(ClksBbBorcTransferi.class,
					application.getBasvuruNo());

				if(balanceTransfer != null && balanceTransfer.getEftTxNo() != null) {

					String maasAlinanKurum = null;
					String ilkMaasTarihi = null;

					BigDecimal pensionPayment = DALUtil
						.getResults(
							"select s.borc_transferi_tahmini_maas from bnspr.bir_nbsm_sonuc s where s.basvuru_no = "
								+ application.getBasvuruNo()
								+ " and s.nbsm_call_tip_kod = 'F' and s.nbsm_call_id = (select max(s2.nbsm_call_id) from bir_nbsm_sonuc s2 where s2.basvuru_no = s.basvuru_no and s2.nbsm_call_tip_kod = s.nbsm_call_tip_kod)",
							"TABLO").getBigDecimal("TABLO", 0, "BORC_TRANSFERI_TAHMINI_MAAS");

					if("1".equals(application.getPttMaasAlinanKurum())) {
						maasAlinanKurum = "00202";
						GMMap dalMap = (GMMap) DALUtil.callOracleProcedure(
							"{call pkg_trn3171.get_taksitin_odenecegi_gun(?,?,?)}", new Object[]{BnsprType.STRING,
								application.getPttTahsisNumarasi(), BnsprType.DATE, dateMap.getDate("BANKA_TARIH")},
							new Object[]{BnsprType.DATE, "TAKSIT_TARIHI"});
						ilkMaasTarihi = dalMap.getString("TAKSIT_TARIHI");
					} else if("3".equals(application.getPttMaasAlinanKurum())) {
						maasAlinanKurum = "00211";
						int bagkurPensionPaymentDay = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N",
							new GMMap().put("PARAMETRE", "CLKS_BORC_TRANSFERI_BAGKUR_GUN")).getInt("DEGER");
						ilkMaasTarihi = String.format("%s%s", period, bagkurPensionPaymentDay);
					}

					oMap.put(outListName, 0, "ONCEKI_MAAS_ODEME_TARIHI", new String());
					oMap.put(outListName, 0, "UNVANI", new String());
					oMap.put(outListName, 0, "EMEKLI_MAAS_EVDENMI", application.getPttMaasEvdenMi());
					oMap.put(outListName, 0, "MAAS_PTT_DENMI", application.getPttMaasPttDenmi());
					oMap.put(outListName, 0, "EMEKLI_MAAS_DONEM", period);
					oMap.put(outListName, 0, "KURUM_DONEM", period);
					oMap.put(outListName, 0, "SON_MAAS_TARIHI", ilkMaasTarihi);
					oMap.put(outListName, 0, "ILK_MAAS_TARIHI", ilkMaasTarihi);
					oMap.put(outListName, 0, "MAAS_TUTARI", pensionPayment);
					oMap.put(outListName, 0, "TAHSIS_NUMARASI", application.getPttTahsisNumarasi());
					oMap.put(outListName, 0, "MAAS_ALINAN_KURUM", maasAlinanKurum);
					oMap.put(outListName, 0, "MAAS_TARIH_SIKLIGI", application.getPttMaasTarihSikligi());
					oMap.put("F_SYNTHETIC_PENSION_PAYMENT", true);
					break;
				}
			}
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_RETIREE_PENSION_PAYMENTS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}