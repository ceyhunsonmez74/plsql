package tr.com.aktifbank.bnspr.clks.services.transfer;

import java.util.Calendar;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.EftKanalCutoffSaat;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EFTServices {
	
	private static Logger logger = Logger.getLogger(EFTServices.class);
	private static final String CHANNEL_CODE = "7";

	/**
	 * PTT Kanali icin cutoff degerini {@code CUTOFF} key degeri altinda {@code String} tipinde 
	 * HH24:MM formatinda doner. Offset gecildi ise cutoff degirine offset ekleyerek doner.
	 * 
	 * @param iMap {OFFSET}			Dakika {@code int}
	 * @return						{@code CUTOFF} key degeri altinda HH24:MM formatli {@code String} iceren 
	 * 								{@code GMMap}
	 * 
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_CLKS_TRANSFER_GET_EFT_CUTOFF")
	public static GMMap getEftCutoff(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			EftKanalCutoffSaat cutOff = (EftKanalCutoffSaat) session.get(EftKanalCutoffSaat.class, CHANNEL_CODE);
			oMap.put("CUTOFF", cutOff.getCutoffSaat());
			
			String[] time = cutOff.getCutoffSaat().split(":");
			if(iMap.containsKey("OFFSET")) {
				
				Calendar cal = Calendar.getInstance();
				cal.set(Calendar.HOUR_OF_DAY, Integer.valueOf(time[0]));
				cal.set(Calendar.MINUTE, Integer.valueOf(time[1]));
				cal.add(Calendar.MINUTE, iMap.getInt("OFFSET"));
				
				StringBuilder sb = new StringBuilder();
				
				if(String.valueOf(cal.get(Calendar.HOUR_OF_DAY)).length() < 2) {
					sb.append("0");
				}
				
				sb.append(String.valueOf(cal.get(Calendar.HOUR_OF_DAY))).append(":");
				
				if(String.valueOf(cal.get(Calendar.MINUTE)).length() < 2) {
					sb.append("0");
				}
				
				sb.append(String.valueOf(cal.get(Calendar.MINUTE)));
				
				oMap.put("CUTOFF", sb.toString());
			}
			
			return oMap;
			
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_TRANSFER_GET_EFT_CUTOFF err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
