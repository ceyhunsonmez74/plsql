package tr.com.aktifbank.bnspr.clks.services.credit;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksMockKrdSgkAylik;
import tr.com.aktifbank.bnspr.dao.ClksMockKrdSgkAylikDty;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class MockServices {
	
	private static Logger logger = Logger.getLogger(MockServices.class);
	
	@GraymoundService("BNSPR_CLKS_CREDIT_MOCK_SGK_PENSION_DATA")
	public static GMMap mockSgkPensionData(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		ClksMockKrdSgkAylik aylik;
		String listName = "SGK_AYLIK_BILGILERI";
		
		try {
			
			String system = (String) DALUtil.callOracleFunction("{? = call pkg_tablo.sistem_bilgi(?).sistem_adi}",
				BnsprType.STRING, BnsprType.STRING, "CLK");
			
			if(!system.contains("PROD")) {
				
				Session session = DAOSession.getSession("BNSPRDal");
				
				if(iMap.containsKey("APPLICATION_NO")) {
					aylik = (ClksMockKrdSgkAylik) session.createCriteria(ClksMockKrdSgkAylik.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("APPLICATION_NO"))).addOrder(
							Order.desc("kod")).uniqueResult();
				} else {
					aylik = (ClksMockKrdSgkAylik) session.createCriteria(ClksMockKrdSgkAylik.class)
						.add(Restrictions.eq("tcKimlikNo", iMap.getString("NATIONAL_IDENTITY_NUMBER"))).addOrder(
							Order.desc("kod")).uniqueResult();
				}
				
				if(aylik == null) {
					aylik = (ClksMockKrdSgkAylik) session.createCriteria(ClksMockKrdSgkAylik.class)
						.add(Restrictions.eq("basvuruNo", BigDecimal.ZERO)).addOrder(
							Order.desc("kod")).uniqueResult();
				}
				
				oMap.put("SGK_SONUC_KODU", aylik.getSonucKodu());
				oMap.put("SGK_SONUC_ACIKLAMA", aylik.getSonucAciklama());
				
				@SuppressWarnings("unchecked")
				List<ClksMockKrdSgkAylikDty> salaries = session.createCriteria(ClksMockKrdSgkAylikDty.class).add(
					Restrictions.eq("id.mockKod", aylik.getKod())).list();
				
				int i = 0;
				for(ClksMockKrdSgkAylikDty salary : salaries) {
				
					oMap.put(listName, i, "AYLIK_ID", salary.getId().getAylikId());
					oMap.put(listName, i, "ADI", salary.getAdi());
					oMap.put(listName, i, "SOYADI", salary.getSoyadi());
					oMap.put(listName, i, "AYLIK_BANKAMDA", salary.getAylikBankamda());
					oMap.put(listName, i, "AYLIK_SONUC_ACIKLAMA", salary.getAylikSonucAciklama());
					oMap.put(listName, i, "AYLIK_SONUC_KODU", salary.getAylikSonucKodu());
					oMap.put(listName, i, "SICIL_NO", salary.getSicilNo());
					oMap.put(listName, i, "SIGORTA_KOLU", salary.getSigortaKolu());
					oMap.put(listName, i, "SISTEM_ACIK_KAPALI_KODU", salary.getSistemAcikKapali());
					oMap.put(listName, i++, "TAHSIS_SEKLI", salary.getTahsisSekli());
				}
			}
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_MOCK_SGK_PENSION_DATA err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
