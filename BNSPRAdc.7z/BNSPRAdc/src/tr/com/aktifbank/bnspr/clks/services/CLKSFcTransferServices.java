package tr.com.aktifbank.bnspr.clks.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalForeignCurrencyTransferDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ForeignCurrencyTransfer;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transfer;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.ForeignCurrencyTransferProcess;
import tr.com.aktifbank.bnspr.clks.util.BnsprAdcMessageExecuter;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants.Transaction;
import tr.com.aktifbank.bnspr.dao.ClksRefGonderimTx;
import tr.com.aktifbank.bnspr.dao.YpHavaleGidenTalimatTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CLKSFcTransferServices {
	
	private static Logger logger = Logger.getLogger(CLKSFcTransferServices.class);
	private static final String LOCAL_COUNTRY_CODE = "TR";
	
	/**
	 * YP transfer islemlerinde kullanilabilecek transfer tipleri
	 * <li>{@code CASH_PICKUP} - Isme gonderim</li>
	 * <li>{@code CASH_TO_ACCOUNT} - Hesaba gonderim</li>
	 * <li>{@code CASH_TO_CREDIT_CARD} - Kredi Kartina gonderim</li>
	 * <li>{@code CASH_TO_ACCOUNT_IBAN} - Hesaba (IBAN) gonderim </li>
	 */
	private enum Transfer {
		
		CASH_PICKUP("NORM","001"), CASH_TO_ACCOUNT("KRED","011"), CASH_TO_CREDIT_CARD("KRED-KART","NA"), CASH_TO_ACCOUNT_IBAN("IBAN","011");
		
		/**
		 * Transfer kodu - {@code bnspr.yp_havale_giden_talimat_tx.havale_tipi}
		 */
		private final String code;
		
		/**
		 * UPT Transaction Tipi
		 */
		private final String uptType;
		
		private Transfer(String code, String uptType) {
			this.code = code;
			this.uptType = uptType;
		}
		
		@Override
		public String toString() {
			return code;
		}

		public String getUptType() {
			return uptType;
		}

		public static Transfer getEnum(String code) {
			for (Transfer v : values())
				if (v.toString().equalsIgnoreCase(code))
					return v;
			throw new IllegalArgumentException();
		}
	}
	
	@GraymoundService("CLKS_FCTRANSFER_REQUEST_ACTION")
	public static GMMap clksFctransferRequest(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		Object [] inputValues;
		Object [] outputValues;
		
		try {
			
				// islem no al
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				iMap.put("ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
				iMap.put("MASK", "REQUEST");

				boolean isTu = isTransactionThroughUpt(iMap);
				
				GMMap expenseMap = GMServiceExecuter.call("CLKS_FCTRANSFER_GET_EXPENSE_PROCESS", iMap);
				
				iMap.put("BANKA_TARIH", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
				
				for (int i = 0; i < iMap.getSize("TAHSILAT"); i++) {
					if ("TRY".equals(iMap.getString("TAHSILAT", i, "DOVIZ_KODU"))) {
						iMap.put("TAHSIL_TUTAR2", iMap.getBigDecimal("TAHSILAT", i, "TUTAR"));
						iMap.put("TAHSIL_TUTAR2_PARAKOD", iMap.getString("TAHSILAT", i, "DOVIZ_KODU"));
						iMap.put("TAHSIL_TUTAR2_KUR", 1);
					}
					else {
						iMap.put("TAHSIL_TUTAR1", iMap.getBigDecimal("TAHSILAT", i, "TUTAR"));
						iMap.put("TAHSIL_TUTAR1_PARAKOD", iMap.getString("TAHSILAT", i, "DOVIZ_KODU"));
						iMap.put("TAHSIL_TUTAR1_KUR", iMap.getString("ISLEM_".concat(iMap.getString("TAHSIL_TUTAR1_PARAKOD")).concat("_KUR")));
					}
				}
				
				// Case : Turkish Union
				if (isTu) {
					
					iMap.put("ALICI_ADSOYAD", iMap.getString("ALICI_AD_SOYAD"));
					iMap.put("ALICI_BANKA_BIC", iMap.getString("ALICI_BANKA_BIC_KODU"));
					iMap.put("ALICI_BANKA_KOD", iMap.getString("ALICI_BANKA_KODU"));
					iMap.put("ALICI_SUBE_KOD", iMap.getString("ALICI_BANKA_SUBE_KODU"));
					iMap.put("ALICI_ULKE_KOD", iMap.getString("ALICI_ULKE_KODU"));
					iMap.put("ALICI_CEPTEL", iMap.getString("ALICI_TELEFON"));
					iMap.put("ALICI_CEPTEL_ULKEKODU", iMap.getString("ALICI_TELEFON_ULKE_KODU"));
					iMap.put("ALICI_CEPTEL_ULKEKODU",org.apache.commons.lang.StringUtils.leftPad(iMap.getString("ALICI_TELEFON_ULKE_KODU").replace("+", ""), 4, "0"));
					iMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("TRX_NO"));
					iMap.put("GONDEREN_AD", iMap.getString("GONDEREN_ADI"));
					iMap.put("GONDEREN_SOYAD", iMap.getString("GONDEREN_SOYADI"));
					iMap.put("GONDEREN_BABAADI", iMap.getString("GONDEREN_BABA_ADI"));
					iMap.put("GONDEREN_CEPTEL", iMap.getString("GONDEREN_TELEFON"));
					iMap.put("GONDEREN_CEPTEL_ULKEKODU", iMap.getString("GONDEREN_TELEFON_ULKE_KODU"));
					iMap.put("GONDEREN_CEPTEL_ULKEKODU", org.apache.commons.lang.StringUtils.leftPad(iMap.getString("GONDEREN_CEPTEL_ULKEKODU").replace("+", ""), 4, "0"));					
				    iMap.put("GONDEREN_DOGTAR", iMap.getString("GONDEREN_DOGUM_TARIHI"));
				    iMap.put("GONDEREN_DOGYER", iMap.getString("GONDEREN_DOGUM_YERI"));
					iMap.put("GONDEREN_KIMLIK_TIP", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "TU_CLKS_KIMLIK_MAP").put("KEY", iMap.getString("GONDEREN_KIMLIK_TURU", "N"))).getString("TEXT"));
					iMap.put("GONDEREN_KIMLIK_ULKE_KODU", iMap.getString("GONDEREN_UYRUK"));
					iMap.put("GONDEREN_ULKE_KOD", LOCAL_COUNTRY_CODE);
					
					if (!"".equals(iMap.getString("GONDEREN_VERGI_NO_YKN")) && iMap.getString("GONDEREN_VERGI_NO_YKN") != null) {
						iMap.put("GONDEREN_VATANDASLIK_NO", iMap.getString("GONDEREN_VERGI_NO_YKN"));
					} else {
						iMap.put("GONDEREN_VATANDASLIK_NO", iMap.getString("GONDEREN_TCKN")); 
					}
					
					iMap.put("GONDERIM_PARAKOD", iMap.getString("DOVIZ_KODU"));
					iMap.put("GONDERIM_TUTAR", iMap.getBigDecimal("TUTAR"));
					iMap.put("KAYNAK_ISLEM_TIP", "004"); // TODO: Hc
					iMap.put("HEDEF_ISLEM_TIP", iMap.getString("TU_ISLEM_TIPI"));
					iMap.put("TAHSIL_ISLEM_MASRAF_PARAKOD", iMap.getString("MASRAF_TAHSIL_DOVIZ"));
					iMap.put("TAHSIL_ISLEM_MASRAF_TUTAR", iMap.getString("MASRAF_TUTARI"));
					iMap.put("TAHSIL_MASRAF_PARAKOD", iMap.getString("MASRAF_TAHSIL_DOVIZ"));
					iMap.put("TAHSIL_MASRAF_TUTAR", iMap.getString("MASRAF_TUTARI"));
					iMap.put("TAHSIL_MASRAF_KUR", iMap.getString("ISLEM_".concat(iMap.getString("DOVIZ_KODU")).concat("_KUR"))); // PTT_GUNCEL_KUR 
					iMap.put("TU_MASRAF_PARAKOD",iMap.getString("MASRAF_TAHSIL_DOVIZ"));
					iMap.put("TU_MASRAF_TUTAR", iMap.getString("MASRAF_TUTARI"));
					iMap.put("TU_MASRAF_ID", expenseMap.getString("TU_MASRAF_ID"));
					iMap.put("VALOR_TARIHI", iMap.getDate("BANKA_TARIH"));
					iMap.put("ALICI_OFIS_KOD", iMap.getString("OFIS_KODU"));
					
					inputValues = new Object [6];
					outputValues= new Object [6];
					
					inputValues[0] = BnsprType.STRING;
					inputValues[1] = iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_BASMUDURLUK");
					inputValues[2] = BnsprType.STRING;
					inputValues[3] = iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_MERKEZ");
					inputValues[4] = BnsprType.STRING;
					inputValues[5] = iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE");
					
					outputValues[0] = BnsprType.NUMBER;
					outputValues[1] = "HEAD_BRANCH_ID";
					outputValues[2] = BnsprType.NUMBER;
					outputValues[3] = "HEAD_ID";
					outputValues[4] = BnsprType.NUMBER;
					outputValues[5] = "BRANCH_ID";
					
					try {
						iMap.putAll((GMMap)DALUtil.callOracleProcedure("{call pkg_ptt.islem_yeri_al(?,?,?,?,?,?)}", inputValues, outputValues));
					} catch(Exception e) { }
					
			        iMap.putAll(GMServiceExecuter.call("BNSPR_TU_SEND_REQUEST", iMap));
			        iMap.put("REFERANS",iMap.getString("TU_REFERANS"));
			        iMap.put("F_TU_ODENECEK", "E");
		        } 
				
				// Case : Swift
				else {

					iMap.put("F_TU_ODENECEK", "H");
					iMap.put("REFERANS", DALUtil.callOneParameterFunction("{? = call pkg_genel_pr.referans_al(?)}",
						Types.VARCHAR, "GIH"));
					iMap.put("MUHABIR_BANKA_HESAP_NO", expenseMap.getBigDecimal("MUHABIR_BANKA_HESAP_NO"));
					iMap.put("MUHABIR_BANKA_MUSTERI_NO", DALUtil.callOneParameterFunction(
						"{? = call pkg_hesap.musteri_no(?)}", Types.NUMERIC, iMap
							.getBigDecimal("MUHABIR_BANKA_HESAP_NO")));

					oMap.putAll((GMMap) DALUtil.callOracleProcedure("{call PKG_YP_HAVALE.cutOff_Gectimi(?,?,?)}",
						new Object[]{BnsprType.STRING, iMap.getString("DOVIZ_KODU")}, new Object[]{BnsprType.STRING,
							"RED", BnsprType.STRING, "CUT_OFF_SAATI"}));

					if("E".equals(oMap.getString("RED"))) {
						iMap.put("VALOR_TARIHI", DALUtil.callOneParameterFunction(
							"{? = call pkg_tarih.ileri_is_gunu(?)}", Types.DATE, iMap.getDate("BANKA_TARIH")));
					} else if(DateUtils.truncate(new java.util.Date(), Calendar.DATE)
						.after(iMap.getDate("BANKA_TARIH"))) {
						iMap.put("VALOR_TARIHI", DALUtil.callOneParameterFunction(
							"{? = call pkg_tarih.ileri_is_gunu(?)}", Types.DATE, iMap.getDate("BANKA_TARIH")));
					} else {
						iMap.put("VALOR_TARIHI", iMap.getDate("BANKA_TARIH"));
					}

					java.util.Calendar calendar = java.util.Calendar.getInstance();
					while("1".equals((String) DALUtil.callOracleFunction(
						"{? = call pkg_tatil.Doviz_tatil_mi(?,?)}", BnsprType.STRING, BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
							 BnsprType.DATE, iMap.getDate("VALOR_TARIHI")))) {

						calendar.setTime(iMap.getDate("VALOR_TARIHI"));
						calendar.add(Calendar.DAY_OF_MONTH, 1);
						iMap.put("VALOR_TARIHI", calendar.getTime());
					}
		        }
				
				iMap.put("PTT_GUNCEL_KUR", iMap.getString("ISLEM_".concat(iMap.getString("MASRAF_TAHSIL_DOVIZ")).concat("_KUR"))); // Masraf Kuru
				iMap.put("KUR",iMap.getString("ISLEM_".concat(iMap.getString("DOVIZ_KODU")).concat("_KUR")));
				
				try {
					iMap.put("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_IL", ((GMMap)GMServiceExecuter.call("CLKS_GET_ISLEMIN_YAPILDIGI_IL", new GMMap().put("ISLEMIN_YAPILDIGI_BASMUDURLUK", iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_BASMUDURLUK")))).getString("ISLEMIN_YAPILDIGI_IL"));
				} catch(Exception e) { }
				
				try {
					
					inputValues = new Object [6];
					
					inputValues[0] = BnsprType.STRING;
					inputValues[1] = iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_BASMUDURLUK");
					inputValues[2] = BnsprType.STRING;
					inputValues[3] = iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_MERKEZ");
					inputValues[4] = BnsprType.STRING;
					inputValues[5] = iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE");
					
					iMap.put("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_YER", (String) DALUtil.callOracleFunction("{? = call pkg_rc_ptt.islem_yeri_al(?,?,?)}", BnsprType.STRING, inputValues));
					
				} catch(Exception e) { }
				
				if (LOCAL_COUNTRY_CODE.equals(iMap.getString("ALICI_ULKE_KODU"))) {
					if ("IBAN".equals(iMap.getString("UPT_TIPI"))) {
						
						inputValues = new Object[2];
						outputValues = new Object[6];
						
						inputValues[0] = BnsprType.STRING;
						inputValues[1] = iMap.getString("ALICI_IBAN");					
						
						outputValues[0] = BnsprType.STRING;
						outputValues[1] = "BANK_KOD";
						outputValues[2] = BnsprType.STRING;
						outputValues[3] = "BIC_KOD";
						outputValues[4] = BnsprType.STRING;
						outputValues[5] = "ALICI_BANKA_ADI";		
						
						iMap.putAll((GMMap)DALUtil.callOracleProcedure("{call pkg_iban.IBAN_BIC_KODU_ADI_GETIR(?,?,?,?)}", inputValues, outputValues));
						oMap.put("ALICI_BANKA_ADI", iMap.getString("ALICI_BANKA_ADI"));
					}
				}
				
				// OFAC Kontrolleri 	
				oMap.put("OFAC_KONTROL", "");
				
				GMMap ofacMap = new GMMap();
				ofacMap.put("OFAC_GONDEREN", DALUtil.callOneParameterFunction("{? = call pkg_swift.OFAC_Kontrol(?)}", Types.VARCHAR, iMap.getString("GONDEREN_ADI")));
				ofacMap.put("OFAC_ALICI", DALUtil.callOneParameterFunction("{? = call pkg_swift.OFAC_Kontrol(?)}", Types.VARCHAR, iMap.getString("ALICI_AD_SOYAD")));
				
				if ("E".equals(ofacMap.getString("OFAC_GONDEREN")) || "E".equals(ofacMap.getString("OFAC_ALICI"))) {
					
					inputValues = new Object[2];
					
					inputValues[0] = BnsprType.NUMBER;
					inputValues[1] = new BigDecimal(1980);
					
					oMap.put("OFAC_KONTROL",  (String) DALUtil.callOracleFunction("{? = call pkg_hata.kodsuzMesajOlustur(?)}", BnsprType.STRING, inputValues));
				}
				
				if (iMap.getString("GONDEREN_HESAP_NO") != null && !iMap.getString("GONDEREN_HESAP_NO").isEmpty()) {
					iMap.put("GONDEREN_IBAN", (String) DALUtil.callOneParameterFunction("{? = call pkg_hesap.iban(?)}", Types.VARCHAR, iMap.getString("GONDEREN_HESAP_NO")));
				}
				
				if (iMap.getString("GONDEREN_HESAP_NO") != null && !(iMap.getString("GONDEREN_HESAP_NO").isEmpty())) {
					iMap.put("IBAN", iMap.getString("GONDEREN_IBAN"));
					GMServiceExecuter.call("TRUNION_IBAN_KONTROL", iMap);
				}
				
				if (!"1".equals(iMap.getString("UPT_TAHSILAT_SEKLI"))) {
					if (iMap.getBigDecimal("TAHSIL_TUTAR1") != null) {
						iMap.put("ALINACAK_TUTAR_YP", iMap.getBigDecimal("TAHSIL_TUTAR1").setScale(2, BigDecimal.ROUND_HALF_UP)); // virg�lden sonra 2 basamak duyarl�l�k
					}
				} else {
					iMap.put("ALINACAK_TUTAR_YP",0);
				}
				
				iMap.put("ALINACAK_TUTAR_TL", iMap.getBigDecimal("TAHSIL_TUTAR2") != null ? iMap.getBigDecimal("TAHSIL_TUTAR2") : 0);
				iMap.put("MASRAF_TAHSIL_SEKLI", "TRY".equals(iMap.getString("MASRAF_TAHSIL_DOVIZ")) ? "TL" : "YP"); // TODO: Hc
				iMap.put("YURTICI_DISI", LOCAL_COUNTRY_CODE.equals(iMap.getString("ALICI_ULKE_KODU")) ? "I" : "D");
				iMap.put("MUHABIR_BANKA_MASRAF_TUTARI", isTu ? expenseMap.getBigDecimal("MUHABIR_MASRAF_TUTAR") : expenseMap.getBigDecimal("MUHABIR_BANKA_MASRAF_TUTARI_ORJ"));
				iMap.put("OPERASYONEL_MASRAF_TUTAR", expenseMap.getBigDecimal("OPERASYONEL_MASRAF_TUTAR"));
				iMap.put("ISLEM_TARIHI", DALUtil.callNoParameterFunction("{? = call pkg_global.GET_BANKATARIH}", Types.DATE));
				iMap.put("TRANSFER_TARIHI", iMap.getDate("VALOR_TARIHI"));
				
				oMap.put("ALINACAK_TUTAR_TL", iMap.getBigDecimal("ALINACAK_TUTAR_TL"));
				oMap.put("ALINACAK_TUTAR_YP", iMap.getBigDecimal("ALINACAK_TUTAR_YP"));
				//MARJ GELIRI
				oMap.putAll(GMServiceExecuter.call("CLKS_FX_KUR_MARJ_GELIRI",iMap));
				iMap.put("MARJ_GELIRI", oMap.get("MARJ_GELIRI"));
				iMap.put("TRX_NAME", Transaction.YP_TRANSFER.toString());
				GMServiceExecuter.call("BNSPR_TRN2850_SAVE", iMap);
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
				
				oMap.put("ISLEM_NO",iMap.getString("ISLEM_NO"));
				oMap.put("VALOR_TARIHI", iMap.getDate("VALOR_TARIHI"));
				oMap.put("REFERANS", iMap.getString("REFERANS"));
				
				
		}
		catch (Exception e) {
			
			logger.error("CLKS_FCTRANSFER_REQUEST_ACTION err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("CLKS_FX_KUR_MARJ_GELIRI")
	public static GMMap ypUptFxMarjGeliri(GMMap iMap) {
	
		GMMap oMap = new GMMap();
		
		try{
			BigDecimal kurGeliri= new BigDecimal("0.0");
			String dovizKodu =  iMap.getString("DOVIZ_KODU"); //USD
			BigDecimal farkTahsilatDoviz =  new BigDecimal("0.0");
			BigDecimal tahsilatTRY =  new BigDecimal("0.0");
			BigDecimal toplamTutar = iMap.getBigDecimal("TUTAR").add(iMap.getBigDecimal("MASRAF_TUTARI")); //1570.00
			
				for (int i = 0; i < iMap.getSize("TAHSILAT"); i++) {
					if ("TRY".equals(iMap.getString("TAHSILAT", i, "DOVIZ_KODU"))) {
						tahsilatTRY =  iMap.getBigDecimal("TAHSILAT", i, "TUTAR");   //9472.91
					} else {
						farkTahsilatDoviz = iMap.getBigDecimal("TAHSILAT", i, "TUTAR");  //0.00
					}
				}

				BigDecimal marjsizKur = new BigDecimal ("0.0");	
				if (dovizKodu.equals("USD")){
				   marjsizKur = iMap.getBigDecimal("MARJSIZ_USD_KUR");  //5.7906
				}else if (dovizKodu.equals("EUR")){
				   marjsizKur = iMap.getBigDecimal("MARJSIZ_EUR_KUR");
			   }

				if (marjsizKur.compareTo(new BigDecimal ("0.0")) !=0){
					kurGeliri = ((farkTahsilatDoviz.multiply(marjsizKur)).add(tahsilatTRY)).subtract((toplamTutar.multiply(marjsizKur)));
				}
			      // Sistem, hesaplad��� FX bilgisinin �zerine, m��teriden al�nan KGV tutar�n� da FX geliriymi� gibi ekleyip ikisinin toplam�n� FX geliri olarak veriyor.
                // Gelen KMV_TUTAR verisi ��kart�larak bu tutar do�ru hale getiriliyor.
                if (iMap.containsKey("KMV_TUTAR") && !StringUtil.isEmpty(iMap.getString("KMV_TUTAR"))) {
                      kurGeliri = kurGeliri.subtract(iMap.getBigDecimal("KMV_TUTAR"));
                }

				oMap.put("MARJ_GELIRI",kurGeliri);
				
				
//				
//				if ((farkTahsilatDoviz.compareTo(toplamTutar))== 0 ){
//				   oMap.put("MARJ_GELIRI",kurGeliri); 
//			   }else {
//				   BigDecimal farkTL =  (toplamTutar.subtract(farkTahsilatDoviz)).multiply(marjsizKur) ;
//				   kurGeliri = tahsilatTRY.subtract(farkTL);
//				   oMap.put("MARJ_GELIRI",kurGeliri);
//			   }
			
		}catch (Exception e) {
			logger.error("CLKS_FX_KUR_MARJ_GELIRI err:", e);
			throw ExceptionHandler.convertException(e);
		}
	 return oMap;
	}
	

	@GraymoundService("CLKS_FCTRANSFER_CONFIRM_ACTION")
	public static GMMap ypUptFctransferConfirm(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		iMap.put("MASK", "CONFIRM");
		
		try {
			
	    	TransactionDao<ForeignCurrencyTransfer> dao = new DalForeignCurrencyTransferDao();
	    	ForeignCurrencyTransfer transfer = dao.get(iMap.getBigDecimal("ISLEM_NO"));
	    	
	    	TransactionProcess<ForeignCurrencyTransfer> process = new ForeignCurrencyTransferProcess(dao);
	    	process.confirm(transfer);

			if (isTransactionThroughUpt(iMap)) { 
			  
				try {
					GMMap tuMap = getTuIslemInfo(iMap);	
					tuMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"));
				    oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CONFIRM_SEND_REQUEST", tuMap));
				    iMap.put("CORRESPONDENT_REF", oMap.getString("CORRESPONDENT_REF"));
				} catch (Exception e) {
					  logger.error("CLKS_FCTRANSFER_CONFIRM_ACTION err - skipping:",e);
				}
			}
				
        	GMServiceExecuter.call("BNSPR_TRN2850_SAVE", iMap);
			iMap.put("ISLEM_TURU", "O");
			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap);
			 
		    return oMap;
		
		} catch(Exception e) {
			logger.error("CLKS_FCTRANSFER_CONFIRM_ACTION err:", e);
			throw ExceptionHandler.convertException(e);
		}    
	}
	
	@GraymoundService("CLKS_GET_ISLEMIN_YAPILDIGI_IL")
	public static GMMap getIslemiYapanIl(GMMap iMap) {
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareStatement("SELECT KEY2 FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? AND KEY1 = ?");
			stmt.setString(1, "PTT_BASMUDURLUK_UZUN_KOD");
			stmt.setString(2, iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
			
			rSet = stmt.executeQuery();
			rSet.next();
			
			oMap.put("ISLEMIN_YAPILDIGI_IL", rSet.getString(1));
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("CLKS_GET_TU_ISLEM_INFO")
    public static GMMap getTuIslemInfo(GMMap iMap){
      Connection conn = null;
      CallableStatement stmt = null;
      GMMap oMap = new GMMap();
	  ResultSet rSet = null;
	  
      try{
        conn = DALUtil.getGMConnection();
        stmt = conn.prepareCall("{ ? = call  PKG_YPUPT.Get_TU_Islem(?)}");
        int i = 1;
        stmt.registerOutParameter(i++, -10);
        stmt.setString(i++, iMap.getString("ISLEM_NO"));
        stmt.execute();
	      
	    rSet = (ResultSet)stmt.getObject(1);
	      
	    String tableName = "TU_ISLEM";
	    GMMap o2Map=DALUtil.rSetResults(rSet,tableName);
	    oMap.putAll(o2Map.getMap(tableName, 0));
	    
        return oMap;
      } catch (SQLException e) {
        throw ExceptionHandler.convertException(e);
      } finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
        
      }

    }

	/**
	 * Islem tipine, doviz koduna ve tutara gore masraf hesaplar. Eger girdiler sonucu UPT islemi oldugu
	 * anlasilir ise, masraf UPT entegrasyonu uzerinden alinir.
	 * 
	 * @param iMap {ALICI_ULKE_KODU}	Ulke kodu - {@code bnspr.gnl_ulke_kod_pr.kod}
	 * @param iMap {CORPORATION_CODE}	Banka kodu
	 * @param iMap {UPT_TIPI}		 	{@link Transfer#code}
	 * @param iMap {DOVIZ_KODU}			Gonderilmek istenen doviz kodu
	 * @param iMap {TUTAR}				Gonderilmek istenen tutar
	 * @param iMap {ACENTA_MALIYET}		Acenta maliyeti
	 * @param iMap {PAZARLAMA_MALIYET}	Pazarlama maliyeti
	 * @return
	 * 
	 * @see <a href="https://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRExternalServices/src/tr/com/aktifbank/turkishunion/TurkishUnionExtServices.java?r=425487">
	 * BNSPR_TU_GET_EXPENSE_DATA</a>
	 * @see <a href="https://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRExternalServices/src/tr/com/aktifbank/bnspr/external/ptt/services/KurServices.java?r=398334">
	 * BNSPR_EXTERNAL_PTT_KUR_SORGU
	 */
	@GraymoundService("CLKS_FCTRANSFER_GET_EXPENSE_PROCESS")
	public static GMMap ClksYPUPTMasrafHesapla(GMMap iMap) {

		GMMap oMap = new GMMap(), integrationMap = new GMMap();
		boolean isUptTransaction = false;
		Transfer transfer = null;
		
		try {

			isUptTransaction = isTransactionThroughUpt(iMap);
			
			if(isUptTransaction) {

				try {
					transfer = Transfer.getEnum(iMap.getString("UPT_TIPI"));
				} catch(IllegalArgumentException e) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(660))
						.put("P1", "Tan�ms�z UPT Tipi"));
				}

				integrationMap.putAll(GMServiceExecuter.call("BNSPR_TU_GET_EXPENSE_DATA",
					new GMMap().put("SEND_AMOUNT", iMap.getBigDecimal("TUTAR"))
						.put("SENDER_COUNTRY_CODE", LOCAL_COUNTRY_CODE)
						.put("RECIPIENT_COUNTRY_CODE", iMap.getString("ALICI_ULKE_KODU"))
						.put("SEND_AMOUNT_CURRENCY", iMap.getString("DOVIZ_KODU")).put("DIRECTION", "1")
						.put("CORPORATION_CODE", iMap.getString("CORPORATION_CODE"))
						.put("TARGET_TRANSACTION_TYPE_CODE", transfer.getUptType())));

				if(!integrationMap.getString("OUT_EXPENSE_CURRENCY").equals(iMap.getString("DOVIZ_KODU"))) {
					GMServiceExecuter
						.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(267)));
				}

				oMap.put("MASRAF_TUTAR", integrationMap.getBigDecimal("OUT_EXPENSE_AMOUNT"));
				oMap.put("MASRAF_DOVIZ_KOD", integrationMap.getString("OUT_EXPENSE_CURRENCY"));
				oMap.put("TU_MASRAF_ID", integrationMap.getString("OUT_EXPENSE_PARAMETER_ID"));
				oMap.put("MUHABIR_MASRAF_TUTAR",
					oMap.getBigDecimal("MASRAF_TUTAR")
						.multiply((iMap.getBigDecimal("ACENTA_MALIYET").add(iMap.getBigDecimal("PAZARLAMA_MALIYET"))))
						.divide(new BigDecimal(100)));
				oMap.put("OUT_RECEIVED_PAYMENT_AMOUNT", integrationMap.getBigDecimal("OUT_RECEIVED_PAYMENT_AMOUNT"));
				oMap.put("OUT_RECEIVED_PAYMENT_CURREENCY", integrationMap.getString("OUT_RECEIVED_PAYMENT_CURREENCY"));
				oMap.put("OUT_NEW_AMOUNT", integrationMap.getBigDecimal("OUT_NEW_AMOUNT"));

			} else {

				iMap.put("ULKE_KODU",iMap.getString("ALICI_ULKE_KODU"));
				iMap.put("HAVALE_TIPI", iMap.getString("UPT_TIPI"));
				
				oMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_YPUPT.PTT_Masraf_Hesapla(?,?,?,?,?,?,?,?,?,?,?,?)}",
					new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("TUTAR"), BnsprType.STRING,
						iMap.getString("DOVIZ_KODU"), BnsprType.STRING, iMap.getString("HAVALE_TIPI"),
						BnsprType.STRING, iMap.getString("ULKE_KODU")}, new Object[]{BnsprType.NUMBER, "USD_KUR",
						BnsprType.NUMBER, "EUR_KUR", BnsprType.NUMBER, "EUR_USD_PARITE", BnsprType.STRING,
						"MASRAF_DOVIZ_KOD", BnsprType.NUMBER, "MASRAF_TUTAR", BnsprType.NUMBER,
						"MUHABIR_BANKA_HESAP_NO", BnsprType.NUMBER, "MUHABIR_MASRAF_TUTAR", BnsprType.NUMBER,
						"MUHABIRSIZ_MASRAF_TUTAR"});

			}
			
			oMap.putAll(GMServiceExecuter.call("BNSPR_EXTERNAL_PTT_KUR_SORGU",
				new GMMap().put("BAZ_DVZ", iMap.getString("DOVIZ_KODU")).put("GONDERIM_ODEME","G").put("ALIS_SATIS", "S").put("KUR_TIPI", "1")));
		
			oMap.put("USD_KUR", oMap.get("USD"));
			oMap.put("EUR_KUR", oMap.get("EUR"));
			oMap.put("EUR_USD_PARITE", oMap.get("PARITE"));
			
			oMap.putAll((GMMap) DALUtil.callOracleProcedure(
				"{call PKG_YPUPT.Operasyonel_Maliyet_Hesapla(?,?,?,?,?)}",
				new Object[]{BnsprType.STRING, iMap.getString("DOVIZ_KODU"), BnsprType.STRING,
					LOCAL_COUNTRY_CODE.equals(iMap.getString("ALICI_ULKE_KODU")) ? "I" : "D", BnsprType.NUMBER,
					iMap.getBigDecimal("TUTAR"), BnsprType.STRING, isUptTransaction ? "E" : "H"}, new Object[]{
					BnsprType.NUMBER, "OPERASYONEL_MASRAF_TUTAR"}));
        	
			oMap.put("MUHABIR_BANKA_MASRAF_TUTARI_ORJ", ((GMMap) DALUtil.callOracleProcedure(
				"{call pkg_ypupt.muhabir_masraf_hesapla(?,?,?,?,?,?)}",
				new Object[]{BnsprType.STRING, iMap.getString("DOVIZ_KODU"), BnsprType.STRING,
					iMap.getString("UPT_TIPI"), BnsprType.STRING,
					LOCAL_COUNTRY_CODE.equals(iMap.getString("ALICI_ULKE_KODU")) ? "I" : "D", BnsprType.NUMBER,
					iMap.getBigDecimal("TUTAR")}, new Object[]{BnsprType.NUMBER, "MUHABIR_BANKA_MASRAF_TUTARI",
					BnsprType.NUMBER, "MUHABIR_BANKA_HESAP_NO"})).getBigDecimal("MUHABIR_BANKA_MASRAF_TUTARI"));

			return oMap;
		}
		catch (Exception e) {
			logger.error("CLKS_FCTRANSFER_GET_EXPENSE_PROCESS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * Yerel para birimine, doviz koduna ve tutara gore masraf hesaplar. Masraf UPT entegrasyonu uzerinden alinir.
	 * 
	 * @param iMap {ALINAN_ODEME_TUTAR}	Gonderilmek istenen yerel birim tutar�
	 * @param iMap {ALINAN_DOVIZ_KODU}	Gonderilmek istenen yerel birim
	 * @param iMap {ALICI_ULKE_KODU}	Ulke kodu - {@code bnspr.gnl_ulke_kod_pr.kod}
	 * @param iMap {CORPORATION_CODE}	Banka kodu
	 * @param iMap {UPT_TIPI}		 	{@link Transfer#code}
	 * @param iMap {DOVIZ_KODU}			Gonderilmek istenen doviz kodu
	 * @param iMap {TUTAR}				Gonderilmek istenen tutar
	 * @param iMap {ACENTA_MALIYET}		Acenta maliyeti
	 * @param iMap {PAZARLAMA_MALIYET}	Pazarlama maliyeti
	 * @return
	 * 
	 * @see <a href="https://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRExternalServices/src/tr/com/aktifbank/turkishunion/TurkishUnionExtServices.java?r=425487">
	 * BNSPR_TU_GET_LOCAL_PAYMENT_CONVERTER_DATA</a>
	 * @see <a href="https://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRExternalServices/src/tr/com/aktifbank/bnspr/external/ptt/services/KurServices.java?r=398334">
	 * BNSPR_EXTERNAL_PTT_KUR_SORGU
	 */
	@GraymoundService("CLKS_FCTRANSFER_GET_LOCAL_PAYMENT_EXPENSE_PROCESS")
	public static GMMap ClksYPUPTYerelParaMasrafHesapla(GMMap iMap) {

		GMMap oMap = new GMMap(), integrationMap = new GMMap();
		Transfer transfer = null;
		
		try {
			try {
				transfer = Transfer.getEnum(iMap.getString("UPT_TIPI"));
			} catch(IllegalArgumentException e) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(660))
					.put("P1", "Tan�ms�z UPT Tipi"));
			}

			integrationMap.putAll(GMServiceExecuter.call("BNSPR_TU_GET_LOCAL_PAYMENT_CONVERTER_DATA",
				new GMMap().put("RECEIVED_PAYMENT_AMOUNT", iMap.getBigDecimal("ALINAN_ODEME_TUTAR"))
					.put("RECEIVED_PAYMENT_AMOUNT_CURRENCY", iMap.getString("ALINAN_DOVIZ_KODU"))
					.put("SENDER_COUNTRY_CODE", LOCAL_COUNTRY_CODE)
					.put("RECIPIENT_COUNTRY_CODE", iMap.getString("ALICI_ULKE_KODU"))
					.put("SEND_AMOUNT_CURRENCY", iMap.getString("DOVIZ_KODU")).put("DIRECTION", "1")
					.put("CORPORATION_CODE", iMap.getString("CORPORATION_CODE"))
					.put("TARGET_TRANSACTION_TYPE_CODE", transfer.getUptType())));

			if(!integrationMap.getString("OUT_EXPENSE_CURRENCY").equals(iMap.getString("DOVIZ_KODU"))) {
				GMServiceExecuter
					.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(267)));
			}

			oMap.put("MASRAF_TUTAR", integrationMap.getBigDecimal("OUT_EXPENSE_AMOUNT"));
			oMap.put("MASRAF_DOVIZ_KOD", integrationMap.getString("OUT_EXPENSE_CURRENCY"));
			oMap.put("TU_MASRAF_ID", integrationMap.getString("OUT_EXPENSE_PARAMETER_ID"));
			oMap.put("MUHABIR_MASRAF_TUTAR",
				oMap.getBigDecimal("MASRAF_TUTAR")
					.multiply((iMap.getBigDecimal("ACENTA_MALIYET").add(iMap.getBigDecimal("PAZARLAMA_MALIYET"))))
					.divide(new BigDecimal(100)));
			oMap.put("OUT_RECEIVED_PAYMENT_AMOUNT", integrationMap.getBigDecimal("OUT_RECEIVED_PAYMENT_AMOUNT"));
			oMap.put("OUT_RECEIVED_PAYMENT_CURREENCY", integrationMap.getString("OUT_RECEIVED_PAYMENT_CURREENCY"));
			oMap.put("OUT_NEW_AMOUNT", integrationMap.getBigDecimal("OUT_NEW_AMOUNT"));
			
			oMap.putAll(GMServiceExecuter.call("BNSPR_EXTERNAL_PTT_KUR_SORGU",
				new GMMap().put("BAZ_DVZ", iMap.getString("DOVIZ_KODU")).put("GONDERIM_ODEME","G").put("ALIS_SATIS", "S").put("KUR_TIPI", "1")));
		
			oMap.put("USD_KUR", oMap.get("USD"));
			oMap.put("EUR_KUR", oMap.get("EUR"));
			oMap.put("EUR_USD_PARITE", oMap.get("PARITE"));
			
			oMap.putAll((GMMap) DALUtil.callOracleProcedure(
				"{call PKG_YPUPT.Operasyonel_Maliyet_Hesapla(?,?,?,?,?)}",
				new Object[]{BnsprType.STRING, iMap.getString("DOVIZ_KODU"), BnsprType.STRING,
					LOCAL_COUNTRY_CODE.equals(iMap.getString("ALICI_ULKE_KODU")) ? "I" : "D", BnsprType.NUMBER,
					iMap.getBigDecimal("TUTAR"), BnsprType.STRING, "E"}, new Object[]{
					BnsprType.NUMBER, "OPERASYONEL_MASRAF_TUTAR"}));
        	
			oMap.put("MUHABIR_BANKA_MASRAF_TUTARI_ORJ", ((GMMap) DALUtil.callOracleProcedure(
				"{call pkg_ypupt.muhabir_masraf_hesapla(?,?,?,?,?,?)}",
				new Object[]{BnsprType.STRING, iMap.getString("DOVIZ_KODU"), BnsprType.STRING,
					iMap.getString("UPT_TIPI"), BnsprType.STRING,
					LOCAL_COUNTRY_CODE.equals(iMap.getString("ALICI_ULKE_KODU")) ? "I" : "D", BnsprType.NUMBER,
					iMap.getBigDecimal("TUTAR")}, new Object[]{BnsprType.NUMBER, "MUHABIR_BANKA_MASRAF_TUTARI",
					BnsprType.NUMBER, "MUHABIR_BANKA_HESAP_NO"})).getBigDecimal("MUHABIR_BANKA_MASRAF_TUTARI"));

			return oMap;
		}
		catch (Exception e) {
			logger.error("CLKS_FCTRANSFER_GET_LOCAL_PAYMENT_EXPENSE_PROCESS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Islem tipine, doviz koduna ve tutara gore masraf tanimlarini listeler. Eger girdiler sonucu UPT islemi oldugu
	 * anlasilir ise, masraf UPT entegrasyonu uzerinden alinir.
	 * 
	 * @param iMap {ALICI_KURUM_KODU}		UPT'de tanimli alici kurum kodu
	 * @param iMap {TUTAR}					Gonderilmek istenen tutar
	 * @param iMap {GONDEREN_KURUM_KODU}	UPT'de tanimli gonderici kurum kodu
	 * @param iMap {DOVIZ_KODU}				Gonderilmek istenen doviz kodu
	 * @param iMap {UPT_TIPI}				{@link Transfer.code}
	 * @param iMap {ALICI_ULKE_KODU}		Ulke kodu - {@code bnspr.gnl_ulke_kod_pr.kod}
	 * @return
	 * 
	 * @see <a href="https://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRExternalServices/src/tr/com/aktifbank/turkishunion/TurkishUnionExtServices.java?r=425487">
	 * BNSPR_IW_GET_EXPENSE_DATA</a>
	 */
	@GraymoundService("CLKS_FCTRANSFER_GET_INFO_EXPENSE_PROCESS")
	public static GMMap ClksFCTransferInfoMasrafHesapla(GMMap iMap) {

		GMMap oMap = new GMMap();
		boolean isUptTransaction = false;
		Transfer transfer = null;

		iMap.put("KURUM_KODU", iMap.getString("ALICI_KURUM_KODU"));

		try {

			isUptTransaction = isTransactionThroughUpt(iMap);

			if(isUptTransaction) {

				try {
					transfer = Transfer.getEnum(iMap.getString("UPT_TIPI"));
				} catch(IllegalArgumentException e) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(660))
						.put("P1", "Tan�ms�z UPT Tipi"));
				}

				oMap.putAll(GMServiceExecuter.call("BNSPR_IW_GET_EXPENSE_DATA", iMap.put("GONDEREN_ULKE_KODU",
					LOCAL_COUNTRY_CODE).put("TARGET_TRANSACTION_TYPE_CODE", transfer.getUptType())));

				if(!oMap.getString("MASRAF_DOVIZ_KOD").equals(iMap.getString("DOVIZ_KODU"))) {
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal
						.valueOf(267)));
				}
			} else {

				if("TR".equals(iMap.getString("ALICI_ULKE_KODU")) && "TL".equals(iMap.getString("DOVIZ_KODU"))) {
					iMap.put("DOVIZ_KOD", "TRY");
					if ("KRED".equals(iMap.getString("UPT_TIPI")) || "IBAN".equals(iMap.getString("UPT_TIPI"))) {
						iMap.put("EKRAN_KODU", "2315");
					}
					else if ("KRED-KART".equals(iMap.getString("UPT_TIPI"))) {
						iMap.put("EKRAN_KODU", "2386");
					}
					else {
						iMap.put("EKRAN_KODU", "2385");
					}
					oMap.putAll(GMServiceExecuter.call("INTERNET_HAVALE_EFT_MASRAF_HESAPLA", iMap));

					oMap.put("MASRAF_TUTAR", new BigDecimal(oMap.getString("TOPLAM_MASRAF")).add(new BigDecimal(oMap
						.getString("TOPLAM_BSMV"))));
					oMap.put("MASRAF_DOVIZ_KOD", "TL");
					oMap.put("ALICIYA_ODENEN_MIKTAR", new BigDecimal(iMap.getString("TUTAR")).add(new BigDecimal(oMap
						.getString("MASRAF_TUTAR"))));
					oMap.put("USD_KUR", "1.00");
					oMap.put("EUR_KUR", "1.00");
					oMap.put("EUR_USD_PARITE", "1.00");
					oMap.put("MASRAF_DOVIZ_ADI", "TL");

				}
				else {
					oMap = (GMMap) DALUtil.callOracleProcedure("{ call PKG_YPUPT.PTT_Masraf_Hesapla(?,?,?,?,?,?,?,?,?,?,?,?)}",
						new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("TUTAR"), BnsprType.STRING,
							iMap.getString("DOVIZ_KODU"), BnsprType.STRING, iMap.getString("UPT_TIPI"),
							BnsprType.STRING, iMap.getString("ALICI_ULKE_KODU")}, new Object[]{BnsprType.NUMBER,
							"USD_KUR", BnsprType.NUMBER, "EUR_KUR", BnsprType.NUMBER, "EUR_USD_PARITE",
							BnsprType.STRING, "MASRAF_DOVIZ_KOD", BnsprType.NUMBER, "MASRAF_TUTAR", BnsprType.NUMBER,
							"MUHABIR_BANKA_HESAP_NO", BnsprType.NUMBER, "MUHABIR_MASRAF_TUTAR", BnsprType.NUMBER,
							"MUHABIRSIZ_MASRAF_TUTAR"});
				}
			}

			oMap.putAll(GMServiceExecuter.call("BNSPR_EXTERNAL_PTT_KUR_SORGU", new GMMap().put("BAZ_DVZ",
				iMap.getString("DOVIZ_KODU")).put("ALIS_SATIS", "S").put("KUR_TIPI", "1").put("GONDERIM_ODEME","G")));

			oMap.put("USD_KUR", oMap.get("USD"));
			oMap.put("EUR_KUR", oMap.get("EUR"));
			oMap.put("EUR_USD_PARITE", oMap.get("PARITE"));

			return oMap;
		} catch(Exception e) {
			logger.error("CLKS_FCTRANSFER_GET_INFO_EXPENSE_PROCESS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("CLKS_FCTRANSFER_GONDERICI_GETIR_PROCESS")
	public static GMMap clksyuptGondericiyiAra(GMMap iMap) {
		logger.info("CLKS_FCTRANSFER_GONDERICI_GETIR_PROCESS in:" + iMap.toString());
		GMMap tMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

				iMap.put("CitizenshipNumber", iMap.getString("TCKN_YKN_VKN"));
				
				if (iMap.getString("KIMLIK_TURU").isEmpty()) {
					iMap.put("IdentityCardType", "");
					iMap.put("IdentityCardNumber", "");
				} else {
				     iMap.put("IdentityCardType", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "TU_CLKS_KIMLIK_MAP").put("KEY", iMap.getString("KIMLIK_TURU"))).getString("TEXT"));
				     iMap.put("IdentityCardNumber", iMap.getString("KIMLIK_NO"));
				}
				iMap.put("Nationality", iMap.getString("UYRUK"));
				tMap.putAll(GMServiceExecuter.call("TRUNION_GONDERICIYI_ARA", iMap));

				boolean firstName =  tMap.getString("SenderList", 0, "FirstName") == null || (tMap.getString("SenderList", 0, "FirstName").isEmpty()) ? false : true;
				boolean middleName = tMap.getString("SenderList", 0, "MiddleName") == null  || (tMap.getString("SenderList", 0, "MiddleName").isEmpty()) ? false : true;
				boolean lastName = tMap.getString("SenderList", 0, "LastName") == null || (tMap.getString("SenderList", 0, "LastName").isEmpty()) ? false : true;
				
				StringBuilder gondericiAdSoyad = new StringBuilder("");
				
				if (firstName) {
					gondericiAdSoyad.append(tMap.getString("SenderList", 0, "FirstName"));
					gondericiAdSoyad.append(" ");
				}
				
				if (middleName) {
					gondericiAdSoyad.append(tMap.getString("SenderList", 0, "MiddleName"));
					gondericiAdSoyad.append(" ");
				}
				
				if (lastName) {
					gondericiAdSoyad.append(tMap.getString("SenderList", 0, "LastName"));
				}
				oMap.put("GONDERICI_AD_SOYAD", gondericiAdSoyad.toString());
				oMap.put("GONDERICI_DOGUM_YERI", tMap.getString("SenderList", 0, "BirthPlace"));
				oMap.put("GONDERICI_DOGUM_TARIHI", tMap.getString("SenderList", 0, "BirthDate"));
				oMap.put("GONDERICI_ADRES", tMap.getString("SenderList", 0, "Address"));
				String phoneNumber = tMap.getString("SenderList", 0, "PhoneNumber");
				if (phoneNumber != null) {
					String[] phoneParts = phoneNumber.split(" ");   // orn : 0090 505 1231231
					String telUlkeKodu = phoneParts[0].replaceFirst("00", "+");
					oMap.put("GONDERICI_CEP_TEL_ULKE_KOD", telUlkeKodu); // +Ulke Kodu
					oMap.put("GONDERICI_CEP_TEL_KOD", phoneParts[1]); // 5xx li kod
					oMap.put("GONDERICI_CEP_TEL_NO", phoneParts[2]);
					oMap.put("GONDERICI_TELEFON_ULKE_KOD", tMap.getString("SenderList", 0, "PhoneCode"));
				}
			
			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));
		}
		catch (Exception e) {
			logger.error("CLKS_FCTRANSFER_GONDERICI_GETIR_PROCESS err:", e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		logger.info("CLKS_FCTRANSFER_GONDERICI_GETIR_PROCESS out:" + oMap.toString());
		return oMap;
	}
	
	@GraymoundService("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_VIA_KEYWORD_PROCESS")
	public static GMMap getclksypupsOfisListele(GMMap iMap) {
		logger.info("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_VIA_KEYWORD_PROCESS in:" + iMap.toString());
		GMMap tMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			iMap.put("ULKE_KODU", iMap.getString("ULKE_KODU"));
			String formattedString = iMap.getString("KEYWORD").replaceAll("[I�]", "i").toUpperCase();
			iMap.put("KEYWORD", formattedString);
			tMap.putAll(GMServiceExecuter.call("TRUNION_GET_OFFICE_LIST", iMap));
			
			GMMap ofisMap = new GMMap();
			for (int i = 0; i < tMap.getSize("OfficeList"); i++) {
				ofisMap.put("OFIS", i,"OFIS_KODU", tMap.getString("OfficeList", i, "OfficeCode"));
				ofisMap.put("OFIS", i,"OFIS_ADI", tMap.getString("OfficeList", i, "OfficeName"));
				ofisMap.put("OFIS", i,"BOLGE", tMap.getString("OfficeList", i, "StateCode"));
				ofisMap.put("OFIS", i,"SEHIR", tMap.getString("OfficeList", i, "City"));
				ofisMap.put("OFIS", i,"ADRES", tMap.getString("OfficeList", i, "Address"));
			}
			
			if (tMap.getSize("OfficeList") > 0) {
				oMap.put("OFIS_LISTE",0,"OFIS",ofisMap.get("OFIS"));
			}
			
		} catch (Exception e) {
			logger.error("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_VIA_KEYWORD_PROCESS err:", e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		logger.info("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_VIA_KEYWORD_PROCESS out:" + oMap.toString());
		return oMap;
	}

	
	@GraymoundService("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_PROCESS")
	public static GMMap getfcTransferTuGetOfficeListProcess(GMMap iMap) {
		logger.info("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_PROCESS in:" + iMap.toString());
		GMMap tMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			iMap.put("ULKE_KODU", iMap.getString("ULKE_KODU"));
			iMap.put("KURUM", iMap.getString("KURUM"));
			iMap.put("SEHIR", iMap.getString("SEHIR"));
			tMap.putAll(GMServiceExecuter.call("BNSPR_IW_GET_OFFICES", iMap));
			
			long count = 0L;
			for (int i = 0; i < tMap.getSize("OFFICE_LIST"); i++) {
				oMap.put("KURUM_BILGILERI", i, "ID", count++);
				oMap.put("KURUM_BILGILERI", i, "KURUM_ADI", tMap.getString("OFFICE_LIST", i, "OFFICE_CORPORATION_NAME"));
				oMap.put("KURUM_BILGILERI", i, "OFIS", tMap.getString("OFFICE_LIST", i, "OFFICE_NAME"));
				oMap.put("KURUM_BILGILERI", i, "ULKE", tMap.getString("OFFICE_LIST", i, "OFFICE_COUNTRY_NAME"));
				oMap.put("KURUM_BILGILERI", i, "SEHIR", tMap.getString("OFFICE_LIST", i, "OFFICE_CITY_NAME"));
				oMap.put("KURUM_BILGILERI", i, "TELEFON", tMap.getString("OFFICE_LIST", i, "OFFICE_PHONE"));
				oMap.put("KURUM_BILGILERI", i, "ADRES", tMap.getString("OFFICE_LIST", i, "OFFICE_ADDRESS"));	
			}
		}
			catch (Exception e) {
				logger.error("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_PROCESS err:", e);
				throw ExceptionHandler.convertException(e);
			}
			finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			logger.info("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_PROCESS out:" + oMap.toString());
			return oMap;
	}
	
	/**
	 * Transferin UPT uzerinden yapilip yapilmadigi bilgisini doner.
	 * 
	 * @param iMap {MASK*}			Hangi asamada cagirildigi bilgisi
	 * 								<li>"REQUEST" - Transaction yaratilmadan</li>
	 * 								<li>"CONFIRM" - Transaction onaylanmadan</li>
	 * @param iMap {ISLEM_NO**}		Banka islem numarasi, {@code MASK} de�eri {@code CONFIRM} olmasi durumunda 
	 * 								zorunludur.
	 * @param iMap {UPT_TIPI**}		{@link Transfer#code}, {@code MASK} de�eri {@code REQUEST} olmasi durumunda 
	 * 								zorunludur.
	 * @param iMap {KURUM_KODU}		UPT Kurum kodu
	 * @return						{@code true} e�er UPT transferi ise, aksi takdirde {@code false}
	 */
	public static boolean isTransactionThroughUpt(GMMap iMap) {

		if("CONFIRM".equals(iMap.getString("MASK"))) {

			Session session = DAOSession.getSession("BNSPRDal");
			YpHavaleGidenTalimatTx ypHavaleGidenTalimatTx = (YpHavaleGidenTalimatTx) session.get(
				YpHavaleGidenTalimatTx.class, iMap.getBigDecimal("ISLEM_NO"));
			return "E".equals(ypHavaleGidenTalimatTx.getFTuOdenecek());
		}

		else {

			Transfer transfer = null;

			try {
				transfer = Transfer.getEnum(iMap.getString("UPT_TIPI"));
			} catch(IllegalArgumentException e) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("660", "Tan�ms�z UPT Tipi"));
			}

			if(transfer == Transfer.CASH_PICKUP
				|| (Arrays.asList(Transfer.CASH_TO_ACCOUNT, Transfer.CASH_TO_ACCOUNT_IBAN).contains(transfer) && !iMap
					.getString("KURUM_KODU", "").isEmpty())) {
				return true;
			}
		}

		return false;
	}
	
	@GraymoundService("CLKS_FCTRANSTER_VIA_REFERENCE_GET_INFO_PROCESS")
	public static GMMap ClksYpUptReferansNoIleGetir(GMMap iMap) {
		logger.info("CLKS_FCTRANSTER_VIA_REFERENCE_GET_INFO_PROCESS in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
	    GMMap tMap = new GMMap();
	    
	    Connection conn = null;
	    CallableStatement stmt = null;
	    
	    try{
	    	tMap.putAll(GMServiceExecuter.call("BNSPR_TU_GET_PRE_AUTHORIZED_TRANSFER", iMap));
	    	
	    	conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_YPUPT.PTT_get_Kur(?,?,?,?,?,?,?)}"); // banka kurunu al�yoruz
			stmt.setString(1, tMap.getString("GetPreAuthorizedTransferResult", 0, "ODENECEK_TUTAR_DOVIZ_KODU"));
			stmt.registerOutParameter(2, Types.NUMERIC);
			stmt.registerOutParameter(3, Types.NUMERIC);
			stmt.registerOutParameter(4, Types.NUMERIC);
			stmt.registerOutParameter(5, Types.NUMERIC);
			stmt.registerOutParameter(6, Types.NUMERIC);
			stmt.registerOutParameter(7, Types.NUMERIC);
			
			stmt.execute();
			
			oMap.put("REFERANS", tMap.getString("GetPreAuthorizedTransferResult", 0, "TU_REFERANS"));
	    	oMap.put("GONDEREN_ADI", tMap.getString("GetPreAuthorizedTransferResult", 0, "GONDEREN_ADI"));
	    	oMap.put("GONDEREN_KIMLIK_TIPI", tMap.getString("GetPreAuthorizedTransferResult", 0, "GONDEREN_KIMLIK_TIPI"));
	    	oMap.put("GONDEREN_KIMLIK_NUMARASI", tMap.getString("GetPreAuthorizedTransferResult", 0, "GONDEREN_KIMLIK_NUMARASI"));
	    	oMap.put("GONDEREN_TC_KIMLIK_NUMARASI", tMap.getString("GetPreAuthorizedTransferResult", 0, "GONDEREN_TC_KIMLIK_NUMARASI"));
	    	oMap.put("GONDEREN_TELEFON_NUMARASI", tMap.getString("GetPreAuthorizedTransferResult", 0, "GONDEREN_TELEFON_NUMARASI"));
	    	oMap.put("GONDEREN_UYRUK", tMap.getString("GetPreAuthorizedTransferResult", 0, "GONDEREN_UYRUK"));
	    	oMap.put("GONDEREN_TELEFON_ULKE_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "GONDEREN_TELEFON_ULKE_KODU"));
	    	oMap.put("ALICI_ADI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_ADI"));
	    	oMap.put("ALICI_TELEFON_NUMARASI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_TELEFON_NUMARASI"));
	    	oMap.put("ALICI_TELEFON_ULKE_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_TELEFON_ULKE_KODU"));
	    	oMap.put("ALICI_HESAP_NO", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_HESAP_NO"));
	    	oMap.put("ALICI_ULKE_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_ULKE_KODU"));
	    	oMap.put("ALICI_ULKE_ADI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_ULKE_ADI"));
	    	oMap.put("ALICI_KURUM_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_KURUM_KODU"));
	    	oMap.put("ALICI_KURUM_ADI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_KURUM_ADI"));
	    	oMap.put("ALICI_OFIS_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_OFIS_KODU"));
	    	oMap.put("ALICI_OFIS_ADI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_OFIS_ADI"));
	    	oMap.put("TUTAR", tMap.getString("GetPreAuthorizedTransferResult", 0, "TUTAR"));
	    	oMap.put("TUTAR_DOVIZ_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "TUTAR_DOVIZ_KODU"));
	    	oMap.put("MASRAF", tMap.getString("GetPreAuthorizedTransferResult", 0, "MASRAF"));
	    	oMap.put("MASRAF_DOVIZ_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "MASRAF_DOVIZ_KODU"));
	    	oMap.put("TOPLAM_TUTAR", tMap.getString("GetPreAuthorizedTransferResult", 0, "TOPLAM_TUTAR"));
	    	oMap.put("TOPLAM_TUTAR_DOVIZ_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "TOPLAM_TUTAR_DOVIZ_KODU"));
	    	oMap.put("ODENECEK_TUTAR", tMap.getString("GetPreAuthorizedTransferResult", 0, "ODENECEK_TUTAR"));
	    	oMap.put("ODENECEK_TUTAR_DOVIZ_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ODENECEK_TUTAR_DOVIZ_KODU"));
	    	oMap.put("ISLEM_TIPI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ISLEM_TIPI"));
			oMap.put("ACIKLAMA", tMap.getString("GetPreAuthorizedTransferResult", 0, "ACIKLAMA"));
			oMap.put("EFT_GONDERIM_TURU", tMap.getString("GetPreAuthorizedTransferResult", 0, "EFT_GONDERIM_TURU"));
			oMap.put("ALICI_SEHIR_ADI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_SEHIR_ADI"));
			oMap.put("ALICI_SEHIR_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_SEHIR_KODU"));
			oMap.put("ALICI_SUBE_ADI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_SUBE_ADI"));
			oMap.put("ALICI_SUBE_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_SUBE_KODU"));
			oMap.put("ALICI_BANKA_ADI", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_BANKA_ADI"));
			oMap.put("ALICI_BANKA_KODU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_BANKA_KODU"));
			oMap.put("ALICI_KART_NO", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_KART_NO"));
			oMap.put("ALICI_IBAN", tMap.getString("GetPreAuthorizedTransferResult", 0, "ALICI_IBAN"));
			oMap.put("BIC_CODE", tMap.getString("GetPreAuthorizedTransferResult", 0, "BIC_CODE"));
			oMap.put("ODENECEK_TUTAR_KUR_TU", tMap.getString("GetPreAuthorizedTransferResult", 0, "ODENECEK_TUTAR_KUR")); // TU taraf�ndan gelen kur
	    	oMap.put("ODENECEK_TUTAR_KUR_EUR", stmt.getBigDecimal(2)); 
	    	oMap.put("ODENECEK_TUTAR_KUR_USD", stmt.getBigDecimal(3));   // burada marjl� olarak USD, EUR kuru ve EUR/USD paritesi g�nderiliyor
	    	oMap.put("EUR_USD_PARITE", stmt.getBigDecimal(4));
	    	
			oMap.putAll(GMServiceExecuter.call("BNSPR_EXTERNAL_PTT_KUR_SORGU", new GMMap()
				.put("ALIS_SATIS", "S")
				.put("KUR_TIPI", "1"))
				.put("GONDERIM_ODEME","G")
					);
		
			oMap.put("ODENECEK_TUTAR_KUR_USD", oMap.get("USD"));
			oMap.put("ODENECEK_TUTAR_KUR_EUR", oMap.get("EUR"));
	    	
	    	GMMap operasyonMap = new GMMap();
	    	if ("001".equals(oMap.getString("ISLEM_TIPI")) || "003".equals(oMap.getString("ISLEM_TIPI"))) {
	    		int i = 0;
				
				Object [] inputValues = new Object [8];
				Object [] outputValues= new Object [2];
				
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = oMap.getString("TUTAR_DOVIZ_KODU");
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = LOCAL_COUNTRY_CODE.equals(oMap.getString("ALICI_ULKE_KODU")) ? "I" : "D";
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = oMap.getBigDecimal("TUTAR");
				inputValues[i++] = BnsprType.STRING;
				if ("003".equals(oMap.getString("ISLEM_TIPI"))) {
					inputValues[i++] = "H"; 
				} else {
					inputValues[i++] = "E";
				}
				
				i = 0;
				
				outputValues[i++] = BnsprType.NUMBER;
				outputValues[i++] = "OPERASYONEL_MASRAF";
				
				operasyonMap.putAll((GMMap)DALUtil.callOracleProcedure("{call PKG_YPUPT.Operasyonel_Maliyet_Hesapla(?,?,?,?,?)}", inputValues, outputValues));
	    	}
	    	
	    	if ("001".equals(oMap.getString("ISLEM_TIPI"))) {
	    		oMap.put("MUHABIR_MASRAF", tMap.getString("GetPreAuthorizedTransferResult", 0, "MUHABIR_MASRAF"));
	    		oMap.putAll(operasyonMap);    		
	    		
	    	} else if ("003".equals(oMap.getString("ISLEM_TIPI"))) {
	    		
	    		
	    		Object [] inputValues = new Object[8];
	    		Object [] outputValues = new Object[4];
	    		
	    		inputValues[0] = BnsprType.STRING;
	    		inputValues[1] = oMap.getString("TUTAR_DOVIZ_KODU");
	    		inputValues[2] = BnsprType.STRING;
	    		inputValues[3] = Transfer.CASH_TO_ACCOUNT.toString();
	    		inputValues[4] = BnsprType.STRING;
	    		inputValues[5] = LOCAL_COUNTRY_CODE.equals(oMap.getString("ALICI_ULKE_KODU")) ? "I" : "D";
	    		inputValues[6] = BnsprType.NUMBER;
	    		inputValues[7] = oMap.getBigDecimal("TUTAR");
	    		
	    		outputValues[0] = BnsprType.NUMBER;
	    		outputValues[1] = "MUHABIR_MASRAF";
	    		outputValues[2] = BnsprType.NUMBER;
	    		outputValues[3] = "MUHABIR_MASRAF_HESAP_NO";
	    		
	    		oMap.putAll((GMMap)DALUtil.callOracleProcedure("{ call PKG_YPUPT.Muhabir_Masraf_Hesapla(?,?,?,?,?,?)}", inputValues, outputValues));

				String funcStr = "{? = call pkg_parametre.deger_al_k_n(?)}";
				inputValues = new Object [2];
				
				inputValues[0] = BnsprType.STRING;
				inputValues[1] = "YPUPT_SWIFT_PAZARLAMA_MALIYETI";
				
				BigDecimal YPUPT_SWIFT_PAZARLAMA_MALIYETI = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
				
				oMap.put("MUHABIR_MASRAF", oMap.getBigDecimal("MUHABIR_MASRAF").add(tMap.getBigDecimal("GetPreAuthorizedTransferResult", 0, "MASRAF").multiply(YPUPT_SWIFT_PAZARLAMA_MALIYETI)));
				oMap.putAll(operasyonMap);

	    	}

	    	oMap.put("MASK", "INFO");
	    	oMap.put("TX_NO", GMServiceExecuter.call("BNSPR_REF_GONDERIM_SAVE", oMap).getBigDecimal("TX_NO_INFO"));
	    	oMap.put("BANKA_ISLEM_NO", oMap.getBigDecimal("TX_NO"));
	    } catch (Exception e) {
			logger.error("CLKS_FCTRANSTER_VIA_REFERENCE_GET_INFO_PROCESS err:", e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	    
		logger.info("CLKS_FCTRANSTER_VIA_REFERENCE_GET_INFO_PROCESS out:" + oMap.toString());
		return oMap;
	}
	
	@GraymoundService("CLKS_FCTRANSTER_VIA_REFERENCE_REQUEST_ACTION")
	public static GMMap ClksfcTransferViaReferansRequest(GMMap iMap) {
		logger.info("CLKS_FCTRANSTER_VIA_REFERENCE_REQUEST_ACTION in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
	    
	    try{

	    	iMap.putAll(GMServiceExecuter.call("BNSPR_REF_GONDERIM_INFO", iMap));
	    	iMap.put("TU_REFERANS", iMap.getString("REFERANS"));
	    	oMap.putAll(GMServiceExecuter.call("BNSPR_TU_SEND_PRE_AUTHORIZED_TRANSFER_REQUEST", iMap));
	    	oMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
	    	oMap.put("TU_REFERENCE", iMap.getString("TU_REFERENCE"));
	    	iMap.putAll(GMServiceExecuter.call("BNSPR_REF_GONDERIM_INFO", iMap));
	    	iMap.put("MASK", "REQUEST");
	    	iMap.put("MUHASEBE_ISLEM_NO", oMap.getBigDecimal("MUHASEBE_ISLEM_NO"));
	    	GMServiceExecuter.call("BNSPR_REF_GONDERIM_SAVE", iMap);

	    	iMap.put("TRX_NAME", 2316);
	    	iMap.put("TRX_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
	    	oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));
	    	

	    }
	    catch (Exception e) {
			logger.error("CLKS_FCTRANSTER_VIA_REFERENCE_REQUEST_ACTION err:", e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
		logger.info("CLKS_FCTRANSTER_VIA_REFERENCE_REQUEST_ACTION out:" + oMap.toString());
		return oMap;
	}
	
	@GraymoundService("CLKS_FCTRANSTER_VIA_REFERENCE_CONFIRM_ACTION")
	public static GMMap ClksfcTransferViaReferansConfirm(GMMap iMap) {
		logger.info("CLKS_FCTRANSTER_VIA_REFERENCE_CONFIRM_ACTION in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
	    
	    try{
	    	
	    	iMap.putAll(GMServiceExecuter.call("BNSPR_REF_GONDERIM_INFO", iMap));
	    	iMap.put("TU_REFERANS", iMap.getString("REFERANS"));
	    	
	    	GMServiceExecuter.executeAsync("BNSPR_TU_SEND_PRE_AUTHORIZED_TRANSFER_CONFIRM", iMap);
	    	
	    	iMap.put("MASK", "CONFIRM");
	    	GMServiceExecuter.call("BNSPR_REF_GONDERIM_SAVE", iMap);
	    	
	    	iMap.put("ISLEM_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
	    	iMap.put("ISLEM_TURU", "O");
	    	GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap);
	    	
	    	oMap.put("TU_REFERANS", iMap.getString("TU_REFERANS"));
	    	oMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
	    	
	    }
	    catch (Exception e) {
			logger.error("CLKS_FCTRANSTER_VIA_REFERENCE_CONFIRM_ACTION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	    
		logger.info("CLKS_FCTRANSTER_VIA_REFERENCE_REQUEST_ACTION out:" + oMap.toString());
		return oMap;
	}
	
	/**
	 * Girilen ulkeye ait UPT islem parametrelerini doner. 
	 *  
	 * @param iMap {ULKE_KODU}		Ulke kodu - {@code bnspr.gnl_ulke_kod_pr.kod}
	 * @return						Eger ulkeye ait parametre tanimi yok ise, {@code 5799} kodu ile 
	 * 								{@code GMRuntimeException} firlatilir.
	 * 
	 * @see <a href="https://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRExternalServices/src/tr/com/aktifbank/turkishunion/TurkishUnionExtServicesForWs.java?r=422831">
	 * 		BNSPR_TU_GET_COUNTRY_TRANSACTION_TYPES</a>
	 */
	@GraymoundService("CLKS_FCTRANSFER_GET_COUNTRY_DATA_PROCESS")
	public static GMMap ClksYpUptGetCountryData(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			
			oMap.putAll(GMServiceExecuter.call("BNSPR_TU_GET_COUNTRY_TRANSACTION_TYPES", iMap));
			
			if(oMap.containsKey("HATA1")) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(4155))
					.put("P1", oMap.getString("HATA1")));
			}

			else if(oMap.containsKey("HATA2")) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(4154))
					.put("P1", oMap.getString("HATA2")));
			}
			
			return oMap;
		}

		catch(Exception e) {
			logger.error("CLKS_FCTRANSFER_GET_COUNTRY_DATA_PROCESS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CLKS_FCTRANSFER_TU_GET_COUNTRY_LIST_VIA_OFFICE_TYPE_PROCESS")
	public static GMMap ClksfcTransferTuGetCountryListViaOfficeType(GMMap iMap) {
		logger.info("CLKS_FCTRANSFER_TU_GET_COUNTRY_LIST_VIA_OFFICE_TYPE_PROCESS in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
	    
	    try{
	    	oMap.putAll(GMServiceExecuter.call("INFOWEBSERVICE_OFIS_TIPINE_GORE_ULKE_LISTESI_GETIR", iMap));
	    	logger.info("CLKS_FCTRANSFER_TU_GET_COUNTRY_LIST_VIA_OFFICE_TYPE_PROCESS out:" + oMap.toString());
		    return oMap;
	    }    
	    
	    catch(Exception e) {
	    	logger.error("CLKS_FCTRANSFER_TU_GET_COUNTRY_LIST_VIA_OFFICE_TYPE_PROCESS error:" + e);
	    	throw ExceptionHandler.convertException(e);
	    }
	}
	
	@GraymoundService("CLKS_FCTRANSFER_TU_GET_CORPORATION_LIST_VIA_COUNTRY_CODE_PROCESS")
	public static GMMap ClksfcTransferTuGetCorporationListViaCountryCode(GMMap iMap) {
		logger.info("CLKS_FCTRANSFER_TU_GET_CORPORATION_LIST_VIA_COUNTRY_CODE_PROCESS in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
	    
	    try{
	    	oMap.putAll(GMServiceExecuter.call("INFOWEBSERVICE_ULKE_BILGISINE_GORE_KURUM_LISTESI_GETIR", iMap));
	    	logger.info("CLKS_FCTRANSFER_TU_GET_CORPORATION_LIST_VIA_COUNTRY_CODE_PROCESS out:" + oMap.toString());
		    return oMap;
	    }    
	    
	    catch(Exception e) {
	    	logger.error("CLKS_FCTRANSFER_TU_GET_CORPORATION_LIST_VIA_COUNTRY_CODE_PROCESS error:" + e);
	    	throw ExceptionHandler.convertException(e);
	    }
	}
	
	@GraymoundService("CLKS_FCTRANSFER_TU_GET_CITIES_PROCESS")
	public static GMMap ClksfcTransferTuGetCities(GMMap iMap) {
		logger.info("CLKS_FCTRANSFER_TU_GET_CITIES_PROCESS in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
	    
	    try{
	    	oMap.putAll(GMServiceExecuter.call("INFOWEBSERVICE_GET_CITIES", iMap));
	    	logger.info("CLKS_FCTRANSFER_TU_GET_CITIES_PROCESS out:" + oMap.toString());
		    return oMap;
	    }    
	    
	    catch(Exception e) {
	    	logger.error("CLKS_FCTRANSFER_TU_GET_CITIES_PROCESS error:" + e);
	    	throw ExceptionHandler.convertException(e);
	    }
	}
	
	@GraymoundService("CLKS_FCTRANSFER_GET_COUNTRY_INFORMATION_PROCESS")
	public static GMMap ClksfcTransferGetCountryInformation(GMMap iMap) {
		logger.info("CLKS_FCTRANSFER_GET_COUNTRY_INFORMATION_PROCESS in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
	    
	    try{
	    	oMap.putAll(GMServiceExecuter.call("TRUNION_GET_COUNTRY_INFORMATION", iMap)); // TODO: bunu geli�tir
	    	logger.info("CLKS_FCTRANSFER_GET_COUNTRY_INFORMATION_PROCESS out:" + oMap.toString());
		    return oMap;
	    }    
	    
	    catch(Exception e) {
	    	logger.error("CLKS_FCTRANSFER_GET_COUNTRY_INFORMATION_PROCESS error:" + e);
	    	throw ExceptionHandler.convertException(e);
	    }
	}
	
	@GraymoundService("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_VIA_CORPORATION_PROCESS")
	public static GMMap ClksfcTransferGetOfficeListViaCorporationProcess(GMMap iMap) {
		logger.info("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_VIA_CORPORATION_PROCESS in:" + iMap.toString());
		
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();
	    
	    try{
	    	tMap.putAll(GMServiceExecuter.call("INFOSERVICE_GET_OFFICE_LIST_VIA_CORPORATION", iMap));
	    	
	    	for (int i = 0; i < tMap.getSize("OFFICE_LIST"); i++) {
				oMap.put("OFIS_LIST", i, "OFIS_ADI", tMap.getString("OFFICE_LIST", i, "OFFICE_NAME"));
				oMap.put("OFIS_LIST", i, "ULKE", tMap.getString("OFFICE_LIST", i, "OFFICE_COUNTRY_NAME"));
				oMap.put("OFIS_LIST", i, "SEHIR", tMap.getString("OFFICE_LIST", i, "OFFICE_CITY_NAME"));
				oMap.put("OFIS_LIST", i, "ADRES", tMap.getString("OFFICE_LIST", i, "OFFICE_ADDRESS"));	
			}
	    	
	    	logger.info("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_VIA_CORPORATION_PROCESS out:" + oMap.toString());
		    return oMap;
	    }    
	    
	    catch(Exception e) {
	    	logger.error("CLKS_FCTRANSFER_TU_GET_OFFICE_LIST_VIA_CORPORATION_PROCESS error:" + e);
	    	throw ExceptionHandler.convertException(e);
	    }
	}

	@GraymoundService("CLKS_FCTRANSFER_GET_LIMIT_INFO")
	public static GMMap clksFcTransferGetLimitInfo(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN2850.Get_Limit_Info(?,?,?)}");
			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.execute();
			oMap.put("TUTAR", stmt.getBigDecimal(2));
			oMap.put("TUTAR_CODE", stmt.getString(3));

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("FCTRANSFER_LOG_AT")
	public static GMMap FcTransferLogAt(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH",
					new GMMap()));
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_YP_HAVALE.FcTransfer_Log_At(?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNoPTT"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.setDate(i++, new Date(oMap.getDate("BANKA_TARIH").getTime()));
			stmt.execute();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_BIC_CODE_LIST")
	public static GMMap clksBicCodeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_SWIFT_UTIL.BIC_KOD_GUNCELLEMELERI}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "islemListesi");
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_GidenFC_LISTESI")
	public static GMMap clksGidenFCList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_YP_HAVALE.GET_Giden_FC_LIST(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.getString("baslangicTar") != null
					&& iMap.getString("baslangicTar").compareTo("") != 0
					&& iMap.getString("baslangicTar").compareTo("null") != 0)
				stmt.setDate(i++, new java.sql.Date(iMap
						.getDate("baslangicTar").getTime()));
			else
				stmt.setDate(i++, null);

			if (iMap.getString("bitisTar") != null
					&& iMap.getString("bitisTar").compareTo("") != 0
					&& iMap.getString("bitisTar").compareTo("null") != 0)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("bitisTar")
						.getTime()));
			else
				stmt.setDate(i++, null);

			stmt.setString(i++, iMap.getString("referansNo"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("islemNo"));
			stmt.setString(i++, iMap.getString("aliciBankaUlkeKodu"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("pttIslemNo"));
			stmt.setString(i++, iMap.getString("durum"));
			stmt.setString(i++, iMap.getString("gonderenAdi"));
			stmt.setString(i++, iMap.getString("dovizCinsi"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "islemListesi");

			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_GelenFC_LISTESI")
	public static GMMap clksGelenFCList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{ ? = call PKG_YP_HAVALE.GET_GELEN_FC_LIST(?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			stmt.setString(i++, iMap.getString("referansNo"));
			stmt.setString(i++, iMap.getString("aliciAdi"));
			stmt.setString(i++, iMap.getString("gonderenAdi"));
			stmt.registerOutParameter(i++, Types.NUMERIC);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.put("GELEN_HAVALE_OK_SAYISI", stmt.getObject(--i));
			oMap = DALUtil.rSetResults(rSet, "islemListesi");

			if (oMap.getSize("islemListesi") == 0
					&& oMap.getInt("GELEN_HAVALE_OK_SAYISI") == 0) {
				iMap.put("HATA_NO", new BigDecimal(1660));
				return (GMMap) GMServiceExecuter.execute(
						"BNSPR_COMMON_HATA_YAZ", iMap);
			}

			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("CLKS_FCTRANSFER_TR_CEP_TEL_KOD_LOOKUP")
	public static GMMap clksFcTransferTRCepTelKodLookup(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_YPUPT.TR_CEP_TEL_KOD_LOOKUP(?,?,?)}");
			
			stmt.setString(1, iMap.getString("TELEFON"));
			stmt.setString(2, iMap.getString("TELEFON_ULKE_KODU"));
			stmt.registerOutParameter(3, Types.NUMERIC);
			
			stmt.execute();

			oMap.put("COUNT", stmt.getInt(3));
			
			return oMap;
			
			} catch (SQLException e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
	}
	
	@GraymoundService("BAKIYE_KARAKTERI_KONTROL")
	public static GMMap bakiyeKarakteriKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_YPUPT.BAKIYE_KARAKTERI_KONTROL(?,?)}");
			
			stmt.setString(1, iMap.getString("GONDEREN_HESAP_NO"));	
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.execute();
			
			oMap.put("BAKIYE_KARAKTERI", stmt.getString(2));
			return oMap;
			
			} catch (SQLException e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
	}
	
	 @GraymoundService("KUR_DSK_TO_LC") 
	 public static GMMap kurdsktolc(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			String funcStr = "{? = call pkg_kur.DSK_to_LC(?,?)}";
			int i = 0;
			Object[] inputValues = new Object[4];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DOVIZ_KODU");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TUTAR");
			BigDecimal tutar = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
			
			oMap.put("tutar", tutar);
			
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	 }

	 @GraymoundService("MUSTERI_MEVCUTMU") 
	 public static GMMap musteriMevcutmu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
				.prepareCall("{? = call pkg_musteri.Musteri_Mevcutmu(null, 'G', 'I',null,null,null,?,null,null,0,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);	
			stmt.setString(2, iMap.getString("GONDEREN_TCKN"));
			stmt.registerOutParameter(3, Types.NUMERIC);
			stmt.execute();
			
			oMap.put("MUSTERI_MEVCUTMU", stmt.getString(1));
			oMap.put("MUSTERI_NO", stmt.getLong(3));
			
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	 }
	 
	 @GraymoundService("HESAP_DURUM_KODU") 
	 public static GMMap hesapDurumKodu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			String funcStr = "{? = call pkg_hesap.durum_kodu(?)}";
			int i = 0;
			Object [] inputValues = new Object [2];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("HESAP_NO");
			oMap.put("DURUM",(String)DALUtil.callOracleFunction(funcStr, BnsprType.STRING, inputValues));
			
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	 }
	 
	@GraymoundService("HAREKET_KODU_KONTROL") 
	public static GMMap hareketKoduKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			String funcStr = "{call PKG_YPUPT.HAREKET_KODU_KONTROL(?)}";
			int i = 0;
			Object[] inputValues = new Object[2];
			Object[] outputValues = new Object[0];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("GONDEREN_HESAP_NO");
			DALUtil.callOracleProcedure(funcStr, inputValues, outputValues);
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	 
	@GraymoundService("HESAP_HACIZLIMI")
	public static GMMap hesapHacizlimi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			String funcStr = "{? = call PKG_HESAP.Hesap_hacizli_mi(?)}";
			int i = 0;
			Object[] inputValues = new Object[2];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("GONDEREN_HESAP_NO");
			oMap.put("HESAP_HACIZLIMI", (String) DALUtil.callOracleFunction(funcStr, BnsprType.STRING, inputValues));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("TELEFON_KONTROL")
	public static GMMap telefonKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			String funcStr = "{call PKG_YPUPT.TELEFON_KONTROL(?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[6];
			Object[] outputValues = new Object[0];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("GONDEREN_TELEFON");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MUSTERI_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("GONDEREN_TCKN");
			
			DALUtil.callOracleProcedure(funcStr,inputValues, outputValues);
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("ALICI_BANKA_BIC_KODU_KONTROL")
	public static GMMap aliciBankaBicKoduKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			String funcStr = "{call PKG_YPUPT.ALICI_BANKA_BIC_KODU_KONTROL(?,?)}";
			int i = 0;
			Object[] inputValues = new Object[4];
			Object[] outputValues = new Object[0];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ALICI_BANKA_BIC_KODU");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ALICI_BANKA_ULKE_KODU");
			
			DALUtil.callOracleProcedure(funcStr,inputValues, outputValues);
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("ALICI_BANKA_HEAD_OFFICE_KODU")
	public static GMMap aliciBankaHeadOfficeKodu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_YPUPT.ALICI_BANKA_HEAD_OFFICE_KODU(?,?,?)}");
			
			if(iMap.getString("ALICI_BANKA_BIC_KODU").length() == 2) {
				iMap.put("ALICI_BANKA_BIC_KODU", "0" + iMap.getString("ALICI_BANKA_BIC_KODU"));
			}

			stmt.setString(1, iMap.getString("ALICI_BANKA_BIC_KODU"));
			stmt.setString(2, iMap.getString("ALICI_BANKA_ULKE_KODU"));
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.execute();

			oMap.put("ALICI_BANKA_BIC_KODU", stmt.getString(3));
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_REF_GONDERIM_SAVE")
	public static GMMap refGonderimsave(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			ClksRefGonderimTx clksRefGonderimTx = null;

			if ("INFO".equals(iMap.getString("MASK"))) {
				
				clksRefGonderimTx = new ClksRefGonderimTx();
				
				oMap.put("TX_NO_INFO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				clksRefGonderimTx.setTxNo(oMap.getBigDecimal("TX_NO_INFO"));
				clksRefGonderimTx.setAciklama(iMap.getString("ACIKLAMA"));
				clksRefGonderimTx.setAliciyaOdenecekTutar(iMap.getBigDecimal("ALICIYA_ODENECEK_TUTAR"));
				clksRefGonderimTx.setAliciAdi(iMap.getString("ALICI_ADI"));
				clksRefGonderimTx.setAliciBankaAdi(iMap.getString("ALICI_BANKA_ADI"));
				clksRefGonderimTx.setAliciHesapNo(iMap.getString("ALICI_HESAP_NO"));
				clksRefGonderimTx.setAliciIban(iMap.getString("ALICI_IBAN"));
				clksRefGonderimTx.setAliciKartNo(iMap.getString("ALICI_KART_NO"));
				clksRefGonderimTx.setAliciKurumAdi(iMap.getString("ALICI_KURUM_ADI"));
				clksRefGonderimTx.setAliciKurumKodu(iMap.getString("ALICI_KURUM_ADI"));
				clksRefGonderimTx.setAliciOfisAdi(iMap.getString("ALICI_OFIS_ADI"));
				clksRefGonderimTx.setAliciOfisKodu(iMap.getString("ALICI_OFIS_KODU"));
				clksRefGonderimTx.setAliciSehirAdi(iMap.getString("ALICI_SEHIR_ADI"));
				clksRefGonderimTx.setAliciSubeAdi(iMap.getString("ALICI_SUBE_ADI"));
				clksRefGonderimTx.setAliciTelefonNumarasi(iMap.getString("ALICI_TELEFON_NUMARASI"));
				clksRefGonderimTx.setAliciUlkeAdi(iMap.getString("ALICI_ULKE_ADI"));
				clksRefGonderimTx.setAliciUlkeKodu(iMap.getString("ALICI_ULKE_KODU"));
				clksRefGonderimTx.setBicCode(iMap.getString("BIC_CODE"));
				clksRefGonderimTx.setEftGonderimTuru(iMap.getString("EFT_GONDERIM_TURU"));
				clksRefGonderimTx.setEurUsdParite(iMap.getBigDecimal("EUR_USD_PARITE"));
				clksRefGonderimTx.setGonderenAdi(iMap.getString("GONDEREN_ADI"));
				clksRefGonderimTx.setGonderenKimlikNumarasi(iMap.getString("GONDEREN_KIMLIK_NUMARASI"));
				clksRefGonderimTx.setGonderenKimlikTipi(iMap.getString("GONDEREN_KIMLIK_TIPI"));
				clksRefGonderimTx.setGonderenTelefonNumarasi(iMap.getString("GONDEREN_TELEFON_NUMARASI"));
				clksRefGonderimTx.setIslemTipi(iMap.getString("ISLEM_TIPI"));
				clksRefGonderimTx.setMasraf(iMap.getBigDecimal("MASRAF"));
				clksRefGonderimTx.setMasrafDovizKodu(iMap.getString("MASRAF_DOVIZ_KODU"));
				clksRefGonderimTx.setOdenecekTutar(iMap.getBigDecimal("ODENECEK_TUTAR"));
				clksRefGonderimTx.setOdenecekTutarDovizKodu(iMap.getString("ODENECEK_TUTAR_DOVIZ_KODU"));
				clksRefGonderimTx.setOdenecekTutarKurEur(iMap.getBigDecimal("ODENECEK_TUTAR_KUR_EUR"));
				clksRefGonderimTx.setOdenecekTutarKurTu(iMap.getBigDecimal("ODENECEK_TUTAR_KUR_TU"));
				clksRefGonderimTx.setOdenecekTutarKurUsd(iMap.getBigDecimal("ODENECEK_TUTAR_KUR_USD"));
				clksRefGonderimTx.setReferans(iMap.getString("REFERANS"));
				clksRefGonderimTx.setToplamTutar(iMap.getBigDecimal("TOPLAM_TUTAR"));
				clksRefGonderimTx.setToplamTutarDovizKodu(iMap.getString("TOPLAM_TUTAR_DOVIZ_KODU"));
				clksRefGonderimTx.setTutar(iMap.getBigDecimal("TUTAR"));
				clksRefGonderimTx.setTutarDovizKodu(iMap.getString("TUTAR_DOVIZ_KODU"));
				clksRefGonderimTx.setMuhabirMasraf(iMap.getBigDecimal("MUHABIR_MASRAF"));
				clksRefGonderimTx.setOperasyonelMasraf(iMap.getBigDecimal("OPERASYONEL_MASRAF"));
				clksRefGonderimTx.setGonderenUyruk(iMap.getString("GONDEREN_UYRUK"));
				clksRefGonderimTx.setGonderenTelefonUlkeKodu(iMap.getString("GONDEREN_TELEFON_ULKE_KODU"));
				clksRefGonderimTx.setAliciTelefonUlkeKodu(iMap.getString("ALICI_TELEFON_ULKE_KODU"));
				clksRefGonderimTx.setAliciBankaKodu(iMap.getString("ALICI_BANKA_KODU"));
				clksRefGonderimTx.setAliciSehirKodu(iMap.getString("ALICI_SEHIR_KODU"));
				clksRefGonderimTx.setAliciSubeKodu(iMap.getString("ALICI_SUBE_KODU"));
				

			} else if("REQUEST".equals(iMap.getString("MASK"))) {
				clksRefGonderimTx = (ClksRefGonderimTx) session.get(ClksRefGonderimTx.class, iMap.getBigDecimal("BANKA_ISLEM_NO"));
				
				clksRefGonderimTx.setTahsilTutar1(iMap.getBigDecimal("TAHSIL_TUTAR1"));
				clksRefGonderimTx.setTahsilTutar1Parakod(iMap.getString("TAHSIL_TUTAR1_PARAKOD"));
				clksRefGonderimTx.setTahsilTutar1Kur(iMap.getBigDecimal("TAHSIL_TUTAR1_KUR"));
				clksRefGonderimTx.setTahsilTutar2(iMap.getBigDecimal("TAHSIL_TUTAR2"));
				clksRefGonderimTx.setTahsilTutar2Parakod(iMap.getString("TAHSIL_TUTAR2_PARAKOD"));
				clksRefGonderimTx.setTahsilTutar2Kur(iMap.getBigDecimal("TAHSIL_TUTAR2_KUR"));
				clksRefGonderimTx.setIsleminYapildigiSube(iMap.getString("PTT_BILGILERI",0, "ISLEMIN_YAPILDIGI_SUBE"));
				clksRefGonderimTx.setIsleminYapildigiMerkez(iMap.getString("PTT_BILGILERI",0, "ISLEMIN_YAPILDIGI_MERKEZ"));
				clksRefGonderimTx.setIsleminYapildigiSube(iMap.getString("PTT_BILGILERI",0, "ISLEMIN_YAPILDIGI_SUBE"));
				clksRefGonderimTx.setIsleminYapildigiBasmudurluk(iMap.getString("PTT_BILGILERI",0, "ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				clksRefGonderimTx.setMerkezSubeBasmudurluk(iMap.getString("PTT_BILGILERI",0, "MERKEZ_SUBE_BASMUDURLUK"));
				clksRefGonderimTx.setIslemiYapanKullaniciAdsoyad(iMap.getString("PTT_BILGILERI",0, "ISLEMI_YAPAN_KULLANICI_ADSOYAD"));
				clksRefGonderimTx.setIslemiYapanKullaniciSicil(iMap.getString("PTT_BILGILERI",0, "ISLEMI_YAPAN_KULLANICI_SICIL"));
				clksRefGonderimTx.setIsleminYapildigiIl(iMap.getString("PTT_BILGILERI",0, "ISLEMIN_YAPILDIGI_IL"));
				clksRefGonderimTx.setIsleminYapildigiYer(iMap.getString("PTT_BILGILERI",0, "ISLEMIN_YAPILDIGI_YER"));
				clksRefGonderimTx.setMuhasebeIslemNo(iMap.getBigDecimal("MUHASEBE_ISLEM_NO"));
				
				oMap.put("TX_NO_INFO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
				
			} else if("CONFIRM".equals(iMap.getString("MASK"))) {
				clksRefGonderimTx = (ClksRefGonderimTx) session.get(ClksRefGonderimTx.class, iMap.getBigDecimal("BANKA_ISLEM_NO"));
				
				clksRefGonderimTx.setPttIslemNo(iMap.getBigDecimal("PTT_ISLEM_NO"));
			}

			session.saveOrUpdate(clksRefGonderimTx);
			session.flush();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_REF_GONDERIM_INFO")
	public static Map<?, ?> refGonderimInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try { 
			Session session = DAOSession.getSession("BNSPRDal");
			ClksRefGonderimTx clksRefGonderimTx = (ClksRefGonderimTx) session.get(ClksRefGonderimTx.class,iMap.getBigDecimal("BANKA_ISLEM_NO"));

			oMap.put("TX_NO", clksRefGonderimTx.getTxNo());
			oMap.put("ACIKLAMA", clksRefGonderimTx.getAciklama());
			oMap.put("ALICI_ADI", clksRefGonderimTx.getAliciAdi());
			oMap.put("ALICI_BANKA_ADI", clksRefGonderimTx.getAliciBankaAdi());
			oMap.put("ALICI_HESAP_NO", clksRefGonderimTx.getAliciHesapNo());
			oMap.put("ALICI_IBAN", clksRefGonderimTx.getAliciIban());
			oMap.put("ALICI_KART_NO", clksRefGonderimTx.getAliciKartNo());
			oMap.put("ALICI_KURUM_ADI", clksRefGonderimTx.getAliciKurumAdi());
			oMap.put("ALICI_KURUM_KODU", clksRefGonderimTx.getAliciKurumKodu());
			oMap.put("ALICI_OFIS_ADI", clksRefGonderimTx.getAliciOfisAdi());
			oMap.put("ALICI_OFIS_KODU", clksRefGonderimTx.getAliciOfisKodu());
			oMap.put("ALICI_SEHIR_ADI", clksRefGonderimTx.getAliciSehirAdi());
			oMap.put("ALICI_SUBE_ADI", clksRefGonderimTx.getAliciSubeAdi());
			oMap.put("ALICI_TELEFON_NUMARASI", clksRefGonderimTx.getAliciTelefonNumarasi());
			oMap.put("ALICI_ULKE_ADI", clksRefGonderimTx.getAliciUlkeAdi());
			oMap.put("ALICI_ULKE_KODU", clksRefGonderimTx.getAliciUlkeKodu());
			oMap.put("BIC_CODE", clksRefGonderimTx.getBicCode());
			oMap.put("EFT_GONDERIM_TURU", clksRefGonderimTx.getEftGonderimTuru());
			oMap.put("EUR_USD_PARITE", clksRefGonderimTx.getEurUsdParite());
			oMap.put("GONDEREN_ADI", clksRefGonderimTx.getGonderenAdi());
			oMap.put("GONDEREN_KIMLIK_NUMARASI", clksRefGonderimTx.getGonderenKimlikNumarasi());
			oMap.put("GONDEREN_KIMLIK_TIPI", clksRefGonderimTx.getGonderenKimlikTipi());
			oMap.put("GONDEREN_TELEFON_NUMARASI", clksRefGonderimTx.getGonderenTelefonNumarasi());
			oMap.put("ISLEM_TIPI", clksRefGonderimTx.getIslemTipi());
			oMap.put("MASRAF", clksRefGonderimTx.getMasraf());
			oMap.put("MASRAF_DOVIZ_KODU", clksRefGonderimTx.getMasrafDovizKodu());
			oMap.put("ODENECEK_TUTAR", clksRefGonderimTx.getOdenecekTutar());
			oMap.put("ODENECEK_TUTAR_DOVIZ_KODU", clksRefGonderimTx.getOdenecekTutarDovizKodu());
			oMap.put("ODENECEK_TUTAR_KUR_EUR", clksRefGonderimTx.getOdenecekTutarKurEur());
			oMap.put("ODENECEK_TUTAR_KUR_TU", clksRefGonderimTx.getOdenecekTutarKurTu());
			oMap.put("ODENECEK_TUTAR_KUR_USD", clksRefGonderimTx.getOdenecekTutarKurUsd());
			oMap.put("REFERANS", clksRefGonderimTx.getReferans());
			oMap.put("TOPLAM_TUTAR", clksRefGonderimTx.getToplamTutar());
			oMap.put("TOPLAM_TUTAR_DOVIZ_KODU", clksRefGonderimTx.getToplamTutarDovizKodu());
			oMap.put("TUTAR", clksRefGonderimTx.getTutar());
			oMap.put("TUTAR_DOVIZ_KODU", clksRefGonderimTx.getTutarDovizKodu());
			oMap.put("MUHASEBE_ISLEM_NO", clksRefGonderimTx.getMuhasebeIslemNo());
			oMap.put("MUHABIR_MASRAF", clksRefGonderimTx.getMuhabirMasraf());
			oMap.put("OPERASYONEL_MASRAF", clksRefGonderimTx.getOperasyonelMasraf());

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CLKS_UPT_GET_REQUIRED_ATTRIBUTES")
	public static GMMap getclksRequiredAttributes(GMMap iMap) {
		logger.info("CLKS_UPT_GET_REQUIRED_ATTRIBUTES in:" + iMap.toString());
		GMMap tMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			tMap.putAll(GMServiceExecuter.call("TRUNION_UPT_GET_REQUIRED_ATTRIBUTES", iMap));
			
		} catch (Exception e) {
			logger.error("CLKS_UPT_GET_REQUIRED_ATTRIBUTES err:", e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		logger.info("CLKS_UPT_GET_REQUIRED_ATTRIBUTES out:" + tMap.toString());
		return tMap;
	}
	
	  @GraymoundService("BNSPR_BIC_BANK_LIST")
	    public static GMMap getUPTBICbankList(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        try {
	            oMap.putAll(GMServiceExecuter.call("BNSPR_UPT_BIC_BANK_LIST", iMap));
	            return oMap;
	        }
	        catch (Exception e) {
	            logger.error("BNSPR_BIC_BANK_LIST err:", e);
	            throw ExceptionHandler.convertException(e);
	        }
	        finally {

	        }
	    }
}
