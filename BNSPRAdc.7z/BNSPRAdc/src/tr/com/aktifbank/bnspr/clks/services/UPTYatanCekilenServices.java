package tr.com.aktifbank.bnspr.clks.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.clks.util.ClksConstants;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants.Transaction;
import tr.com.aktifbank.bnspr.dao.ClksUptHesapCekilenTx;
import tr.com.aktifbank.bnspr.dao.ClksUptHesapYatanTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class UPTYatanCekilenServices {

    private static Logger logger = Logger.getLogger(UPTYatanCekilenServices.class);

    @GraymoundService("BNSPR_GET_UPT_ACCOUNT_INFO")
    public static GMMap getUptAccountInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            String serviceName = "";

            if ("T".equals(iMap.getString("CUSTOMER_TYPE"))) {
                serviceName = "BNSPR_TU_CUST_ACCOUNT_GET_COMPANY_ACCOUNT";
            }
            else if ("G".equals(iMap.getString("CUSTOMER_TYPE"))) {
                serviceName = "BNSPR_TU_CUST_ACCOUNT_GET_REAL_ACCOUNT";
            }
            oMap.putAll(GMServiceExecuter.call(serviceName, iMap));

            return oMap;
        }
        catch (Exception e) {
            logger.error("BNSPR_GET_UPT_ACCOUNT_INFO err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {

        }
    }

    @GraymoundService("BNSPR_UPT_GET_DEPOSIT_REQUEST")
    public static GMMap getUPTDepositRequest(GMMap iMap) {
        GMMap oMap = new GMMap();
        String trxName = Transaction.UPT_NAKIT_YATAN.toString();
        try {

            oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_DEPOSIT_REQUEST", iMap));

            iMap.put("TRANSACTION_RECORD_ID", oMap.getString("TRANSACTION_RECORD_ID"));
            BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
            iMap.put("TX_NO", txNo);
            oMap.put("TX_NO", txNo);

            iMap.put("SAVE", "REQUEST");
            oMap.putAll(GMServiceExecuter.call("BNSPR_UPT_NAKIT_YATAN_SAVE", iMap));

            // Send Transaction
            iMap.put("TRX_NO", iMap.getBigDecimal("TX_NO"));
            iMap.put("TRX_NAME", trxName);
            oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));

            return oMap;
        }
        catch (Exception e) {
            logger.error("BNSPR_UPT_GET_DEPOSIT_REQUEST err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {

        }
    }

    @GraymoundService("BNSPR_UPT_GET_WITHDRAW_REQUEST")
    public static GMMap getUPTWithdrawRequest(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap otpMap = new GMMap();

        String trxName = Transaction.UPT_NAKIT_CEKILEN.toString();

        try {
            otpMap.put("CODE", iMap.getString("OTP", 0, "CODE"));
            otpMap.put("OPERATION_CODE", iMap.getString("OTP", 0, "OPERATION_CODE"));
            otpMap.put("TO", iMap.getString("OTP", 0, "TELEPHONE_NUMBER"));
            otpMap.putAll(GMServiceExecuter.call("BNSPR_UPT_CHECK_OTP", otpMap));

            if ("2".equals(otpMap.getString("OTP_STATUS"))) {

                oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_WITHDRAW_REQUEST", iMap));

                iMap.put("TRANSACTION_RECORD_ID", oMap.getString("TRANSACTION_RECORD_ID"));
                BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
                iMap.put("TX_NO", txNo);
                oMap.put("TX_NO", txNo);

                iMap.put("SAVE", "REQUEST"); 
                oMap.putAll(GMServiceExecuter.call("BNSPR_UPT_NAKIT_CEKILEN_SAVE", iMap));

                // Send Transaction
                iMap.put("TRX_NO", oMap.getBigDecimal("TX_NO"));
                iMap.put("TRX_NAME", trxName);
                oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));
            }
            else if ("3".equals(otpMap.getString("OTP_STATUS"))) {
                // (Ayn� i�lem kodu ile deneme yap�labilir. Max 3 deneme yapma hakk� bulunmaktad�r.)
                iMap.put("HATA_NO", 5390);
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            else if (("4".equals(otpMap.getString("OTP_STATUS")))) {
                // OTP ge�ersiz hale gelmi�tir, deneme haklar� ya da s�re doldu)
                iMap.put("HATA_NO", 5391);
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
            }

            return oMap;
        }
        catch (Exception e) {
            logger.error("BNSPR_UPT_GET_WITHDRAW_REQUEST err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {

        }
    }

    @GraymoundService("BNSPR_UPT_DEPOSIT_CONFIRM_CUST_ACCOUNT_TRANSACTION")
    public static GMMap getUPTDepositConfirmCustAccountTransaction(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            Session session = DAOSession.getSession("BNSPRDal");

            ClksUptHesapYatanTx clksUptHesapYatanTx = (ClksUptHesapYatanTx) session.get(ClksUptHesapYatanTx.class, iMap.getBigDecimal("TX_NO"));

            iMap.put("TRANSACTION_RECORD_ID", clksUptHesapYatanTx.getTransactionRecordId());

            oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CONFIRM_CUST_ACCOUNT_TRANSACTION", iMap));

            iMap.put("SAVE", "CONFIRM");
            iMap.put("REFERENCE", oMap.getString("REFERENCE"));
            String ref = oMap.getString("REFERENCE");

            oMap.putAll(GMServiceExecuter.call("BNSPR_UPT_NAKIT_YATAN_SAVE", iMap));
            iMap.put("ISLEM_NO", iMap.getBigDecimal("TX_NO"));
            iMap.put("ISLEM_TURU", "O");
            try {
            	GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap);
            }
            catch(Exception e) {
            	iMap.put("REFERENCE", ref);
            	oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CANCEL_CUST_ACCOUNT_TRANSACTION", iMap));
            }

            return oMap;
        }
        catch (Exception e) {
            logger.error("BNSPR_UPT_DEPOSIT_CONFIRM_CUST_ACCOUNT_TRANSACTION err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {

        }
    }

    @GraymoundService("BNSPR_UPT_WITHDRAW_CONFIRM_CUST_ACCOUNT_TRANSACTION")
    public static GMMap getUPTWithdrawConfirmCustAccountTransaction(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            Session session = DAOSession.getSession("BNSPRDal");

            ClksUptHesapCekilenTx clksUptHesapCekilenTx = (ClksUptHesapCekilenTx) session.get(ClksUptHesapCekilenTx.class, iMap.getBigDecimal("TX_NO"));

            iMap.put("TRANSACTION_RECORD_ID", clksUptHesapCekilenTx.getTransactionRecordId());

            oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CONFIRM_CUST_ACCOUNT_TRANSACTION", iMap));

            iMap.put("SAVE", "CONFIRM");
            String ref = oMap.getString("REFERENCE");
            iMap.put("REFERENCE", oMap.getString("REFERENCE"));
            oMap.putAll(GMServiceExecuter.call("BNSPR_UPT_NAKIT_CEKILEN_SAVE", iMap));
            iMap.put("ISLEM_NO", iMap.getBigDecimal("TX_NO"));
            iMap.put("ISLEM_TURU", "O");
            try {
            	GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap);
            }
            catch(Exception e) {
            	iMap.put("REFERENCE", ref);
            	oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CANCEL_CUST_ACCOUNT_TRANSACTION", iMap));
            }
            return oMap;
        }
        catch (Exception e) {
            logger.error("BNSPR_UPT_WITHDRAW_CONFIRM_CUST_ACCOUNT_TRANSACTION err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {

        }
    }

    @GraymoundService("BNSPR_UPT_CANCEL_CUST_ACCOUNT_TRANSACTION")
    public static GMMap getUPTCancelCustAccountTransaction(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CANCEL_CUST_ACCOUNT_TRANSACTION", iMap));
            return oMap;
        }
        catch (Exception e) {
            logger.error("BNSPR_UPT_CANCEL_CUST_ACCOUNT_TRANSACTION err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {

        }
    }

    @GraymoundService("BNSPR_UPT_SEND_OTP")
    public static GMMap getUPTSendOTP(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            oMap.putAll(GMServiceExecuter.call("BNSPR_TU_INFO_SENDOTP", iMap));
            return oMap;
        }
        catch (Exception e) {
            logger.error("BNSPR_UPT_SEND_OTP err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {

        }
    }

    @GraymoundService("BNSPR_UPT_CHECK_OTP")
    public static GMMap getUPTCheckOTP(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            if ("".equals(iMap.getString("CODE"))) {
            }
            oMap.putAll(GMServiceExecuter.call("BNSPR_TU_INFO_CHECKOTP", iMap));
            return oMap;
        }
        catch (Exception e) {
            logger.error("BNSPR_UPT_CHECK_OTP err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {

        }
    }

    @GraymoundService("BNSPR_UPT_NAKIT_CEKILEN_SAVE")
    public static GMMap uptNakitCekilenSave(GMMap iMap) {

        GMMap oMap = new GMMap();

        try {

            Session session = DAOSession.getSession("BNSPRDal");

            ClksUptHesapCekilenTx clksUptHesapCekilenTx = (ClksUptHesapCekilenTx) session.get(ClksUptHesapCekilenTx.class, iMap.getBigDecimal("TX_NO"));

            if (clksUptHesapCekilenTx == null) {
                clksUptHesapCekilenTx = new ClksUptHesapCekilenTx();
            }

            if ("REQUEST".equals(iMap.getString("SAVE"))) {

                clksUptHesapCekilenTx.setTxNo(iMap.getBigDecimal("TX_NO"));
                clksUptHesapCekilenTx.setDovizCinsi(iMap.getString("WITHDRAW_AMOUNT", 0, "CURRENCY_CODE"));
                clksUptHesapCekilenTx.setHesapDovizCinsi(iMap.getString("INFO_DETAILS", 0, "ACCOUNT_CURRENCY_CODE"));
                clksUptHesapCekilenTx.setHesapNo(iMap.getBigDecimal("INFO_DETAILS", 0, "ACCOUNT_NUMBER"));
                clksUptHesapCekilenTx.setKimlikNo(iMap.getString("PERSON", 0, "IDENTITY_NO"));
                clksUptHesapCekilenTx.setKimlikTipi(iMap.getString("PERSON", 0, "IDENTITY_TYPE"));
                clksUptHesapCekilenTx.setMasraf(iMap.getBigDecimal("EXPENSE", 0, "AMOUNT_VALUE"));
                clksUptHesapCekilenTx.setMusteriAdiSoyadi(iMap.getString("INFO_DETAILS", 0, "CUSTOMER_NAME_SURNAME"));
                clksUptHesapCekilenTx.setOdenecekTutar(iMap.getBigDecimal("PAYED_AMOUNTS", 0, "AMOUNT_VALUE"));
                clksUptHesapCekilenTx.setToplamTutar(iMap.getBigDecimal("TOTAL_PAYED_AMOUNT", 0, "AMOUNT_VALUE"));
                clksUptHesapCekilenTx.setTutar(iMap.getBigDecimal("WITHDRAW_AMOUNT", 0, "AMOUNT_VALUE"));
                clksUptHesapCekilenTx.setUyruk(iMap.getString("INFO_DETAILS", 0, "NATION_CODE"));
                clksUptHesapCekilenTx.setIslemiYapanCepTelNo(iMap.getString("INFO_DETAILS", 0, "CUSTOMER_MOBILE_NUMBER"));
                clksUptHesapCekilenTx.setTcKimlikNo(iMap.getString("INFO_DETAILS", 0, "IDENTIFICATION_NUMBER"));

                clksUptHesapCekilenTx.setIsleminYapildigiBasMudurluk(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_BAS_MUDURLUK"));
                clksUptHesapCekilenTx.setIsleminYapildigiIl(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_IL"));
                clksUptHesapCekilenTx.setIsleminYapildigiMerkez(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_MERKEZ"));
                clksUptHesapCekilenTx.setIsleminYapildigiSube(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE"));
                clksUptHesapCekilenTx.setIsleminYapildigiYer(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_YER"));
                clksUptHesapCekilenTx.setIslemiYapanKulAdSoyad(iMap.getString("PTT_BILGILERI", 0, "ISLEMI_YAPAN_KUL_AD_SOYAD"));
                clksUptHesapCekilenTx.setIslemiYapanKullaniciSicil(iMap.getString("PTT_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL"));
                clksUptHesapCekilenTx.setMerkezSubeBasMudurluk(iMap.getString("PTT_BILGILERI", 0, "MERKEZ_SUBE_BAS_MUDURLUK"));
                clksUptHesapCekilenTx.setTransactionRecordId(iMap.getString("TRANSACTION_RECORD_ID"));

            }

            else if ("CONFIRM".equals(iMap.getString("SAVE"))) {
                clksUptHesapCekilenTx.setPttIslemNo(iMap.getBigDecimal("PTT_ISLEM_NO"));
                clksUptHesapCekilenTx.setReferansNo(iMap.getString("REFERENCE"));
            }

            session.saveOrUpdate(clksUptHesapCekilenTx);
            session.flush();
        }

        catch (Exception e) {

            logger.error("BNSPR_UPT_NAKIT_CEKILEN_SAVE err: " + e);
            throw ExceptionHandler.convertException(e);
        }

        return oMap;
    }

    @GraymoundService("BNSPR_UPT_NAKIT_YATAN_SAVE")
    public static GMMap uptNakitYatanSave(GMMap iMap) {

        GMMap oMap = new GMMap();

        try {

            Session session = DAOSession.getSession("BNSPRDal");

            ClksUptHesapYatanTx clksUptHesapYatanTx = (ClksUptHesapYatanTx) session.get(ClksUptHesapYatanTx.class, iMap.getBigDecimal("TX_NO"));

            if (clksUptHesapYatanTx == null) {
                clksUptHesapYatanTx = new ClksUptHesapYatanTx();
            }

            if ("REQUEST".equals(iMap.getString("SAVE"))) {

                clksUptHesapYatanTx.setTxNo(iMap.getBigDecimal("TX_NO"));

                // 3. �ah�s
                if ("2".equals(iMap.getString("DEPOSIT_TYPE"))) {

                    clksUptHesapYatanTx.setAd(iMap.getString("THIRD_PARTY_SENDER", 0, "NAME"));
                    clksUptHesapYatanTx.setSoyad(iMap.getString("THIRD_PARTY_SENDER", 0, "SURNAME"));
                    clksUptHesapYatanTx.setAnneAdi(iMap.getString("THIRD_PARTY_SENDER", 0, "MOTHER_NAME"));
                    clksUptHesapYatanTx.setBabaAdi(iMap.getString("THIRD_PARTY_SENDER", 0, "FATHER_NAME"));
                    clksUptHesapYatanTx.setCepTelNo(iMap.getString("THIRD_PARTY_SENDER", 0, "GSM_NUMBER"));
                    clksUptHesapYatanTx.setDogumTarihi(iMap.getString("THIRD_PARTY_SENDER", 0, "BIRTH_DATE"));
                    clksUptHesapYatanTx.setDogumYeri(iMap.getString("THIRD_PARTY_SENDER", 0, "PLACE"));
                    clksUptHesapYatanTx.setKasaKimlikTipi("4");
                    clksUptHesapYatanTx.setUyruk(iMap.getString("THIRD_PARTY_SENDER", 0, "NATION_CODE"));
                    
                    if ("TR".equals(iMap.getString("THIRD_PARTY_SENDER", 0, "NATION_CODE"))) {
                        // TC Kimlik validasyonu PTT taraf�ndan yap�l�yor.
                        clksUptHesapYatanTx.setTcKimlikNo(iMap.getString("THIRD_PARTY_SENDER", 0, "IDENTIFICATION_NUMBER"));
                    }

                    if (!"TR".equals(iMap.getString("THIRD_PARTY_SENDER", 0, "NATION_CODE"))) {

                        clksUptHesapYatanTx.setKimlikNumarasi(iMap.getString("THIRD_PARTY_SENDER", 0, "IDENTITY_NO"));
                    }
                }
                clksUptHesapYatanTx.setDovizCinsi(iMap.getString("DEPOSIT_AMOUNT", 0, "CURRENCY_CODE"));
                clksUptHesapYatanTx.setHesapDovizCinsi(iMap.getString("ACCOUNT_CURRENCY_CODE"));
                clksUptHesapYatanTx.setHesapNo(iMap.getBigDecimal("ACCOUNT_NUMBER"));
                clksUptHesapYatanTx.setIsleminYapildigiBasMudurluk(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_BAS_MUDURLUK"));
                clksUptHesapYatanTx.setIsleminYapildigiIl(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_IL"));
                clksUptHesapYatanTx.setIsleminYapildigiMerkez(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_MERKEZ"));
                clksUptHesapYatanTx.setIsleminYapildigiSube(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE"));
                clksUptHesapYatanTx.setIsleminYapildigiYer(iMap.getString("PTT_BILGILERI", 0, "ISLEMIN_YAPILDIGI_YER"));
                clksUptHesapYatanTx.setIslemiYapanKullAdsoyad(iMap.getString("PTT_BILGILERI", 0, "ISLEMI_YAPAN_KUL_AD_SOYAD"));
                clksUptHesapYatanTx.setIslemiYapanKullaniciSicil(iMap.getString("PTT_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL"));
                clksUptHesapYatanTx.setMerkezSubeBasMudurluk(iMap.getString("PTT_BILGILERI", 0, "MERKEZ_SUBE_BAS_MUDURLUK"));
                clksUptHesapYatanTx.setMasraf(iMap.getBigDecimal("EXPENSE", 0, "AMOUNT_VALUE"));
                clksUptHesapYatanTx.setMusteriAdiSoyadi(iMap.getString("CUSTOMER_NAME_SURNAME"));
                clksUptHesapYatanTx.setTutar(iMap.getBigDecimal("RECEIVED_AMOUNTS", 0, "AMOUNT_VALUE"));
                clksUptHesapYatanTx.setToplamTutar(iMap.getBigDecimal("TOTAL_RECEIVED_AMOUNT", 0, "AMOUNT_VALUE"));
                clksUptHesapYatanTx.setTransactionRecordId(iMap.getString("TRANSACTION_RECORD_ID"));

                // Ger�ek Hesap (Kendi)
                if ("1".equals(iMap.getString("DEPOSIT_TYPE"))) {
                    clksUptHesapYatanTx.setKasaKimlikTipi("1");
                    clksUptHesapYatanTx.setUyruk(iMap.getString("NATION_CODE"));
                    if ("TR".equals(iMap.getString("NATION_CODE"))) {
                        clksUptHesapYatanTx.setKimlikTipi(iMap.getString("PERSON", 0, "IDENTITY_TYPE"));
                        // Validation: TC Kimlik
                        if (GMServiceExecuter.call("BNSPR_COMMON_TCKN_CHECK_DIGIT", new GMMap().put("TC_KIMLIK_NO", iMap.getString("PERSON", 0, "IDENTITY_NO"))).getInt("SONUC") == 0) {
                            GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3037));
                        }
                        clksUptHesapYatanTx.setTcKimlikNo(iMap.getString("PERSON", 0, "IDENTITY_NO"));
                    }

                    if (!"TR".equals(iMap.getString("NATION_CODE"))) {
                        clksUptHesapYatanTx.setKimlikTipi(iMap.getString("PERSON", 0, "IDENTITY_TYPE"));
                        clksUptHesapYatanTx.setKimlikNumarasi(iMap.getString("PERSON", 0, "IDENTITY_NO"));
                    }
                }

                // T�zel M��teri Temsilcisi
                if ("3".equals(iMap.getString("DEPOSIT_TYPE"))) {
                    clksUptHesapYatanTx.setKasaKimlikTipi("2");
                    clksUptHesapYatanTx.setUyruk(iMap.getString("NATION_CODE"));
                    if ("TR".equals(iMap.getString("NATION_CODE"))) {
                        clksUptHesapYatanTx.setKimlikTipi(iMap.getString("PERSON", 0, "IDENTITY_TYPE"));
                        clksUptHesapYatanTx.setTcKimlikNo(iMap.getString("PERSON", 0, "IDENTITY_NO"));
                    }
                    if (!"TR".equals(iMap.getString("NATION_CODE"))) {
                        clksUptHesapYatanTx.setKimlikTipi(iMap.getString("PERSON", 0, "IDENTITY_TYPE"));
                        clksUptHesapYatanTx.setKimlikNumarasi(iMap.getString("PERSON", 0, "IDENTITY_NO"));
                    }
                }
            }

            else if ("CONFIRM".equals(iMap.getString("SAVE"))) {
                clksUptHesapYatanTx.setPttIslemNo(iMap.getBigDecimal("PTT_ISLEM_NO"));
                clksUptHesapYatanTx.setReferansNo(iMap.getString("REFERENCE"));
            }

            session.saveOrUpdate(clksUptHesapYatanTx);
            session.flush();
        }

        catch (Exception e) {

            logger.error("BNSPR_UPT_NAKIT_YATAN_SAVE err: " + e);
            throw ExceptionHandler.convertException(e);
        }

        return oMap;
    }

    @GraymoundService("BNSPR_TRN3555_AFTER_CANCELLATION")
    public static GMMap afterCancellationTrn3555(GMMap iMap) {
        Connection conn = null;

        ResultSet rSet = null;
        CallableStatement stmt2 = null;

        try {
            Session session = DAOSession.getSession("BNSPRDal");
            ClksUptHesapCekilenTx clksUptHesapCekilenTx = (ClksUptHesapCekilenTx) session.createCriteria(ClksUptHesapCekilenTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TX_NO"))).uniqueResult();
            if (clksUptHesapCekilenTx == null) {
                clksUptHesapCekilenTx = new ClksUptHesapCekilenTx();
            }

            conn = DALUtil.getGMConnection();

            GMServerDatasource.close(stmt2);

            GMMap sMap = new GMMap();
            sMap.put("REFERENCE", clksUptHesapCekilenTx.getReferansNo());
            sMap = GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CANCEL_CUST_ACCOUNT_TRANSACTION", sMap);
            return new GMMap();
        }
        catch (Exception e) {
            logger.error("BNSPR_TRN3555_AFTER_CANCELLATION err: " + e);
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt2);
            GMServerDatasource.close(conn);
        }
    }

    @GraymoundService("BNSPR_TRN3554_AFTER_CANCELLATION")
    public static GMMap afterCancellationTrn3554(GMMap iMap) {
        Connection conn = null;

        ResultSet rSet = null;
        CallableStatement stmt2 = null;

        try {
            Session session = DAOSession.getSession("BNSPRDal");
            ClksUptHesapYatanTx clksUptHesapYatanTx = (ClksUptHesapYatanTx) session.createCriteria(ClksUptHesapYatanTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TX_NO"))).uniqueResult();
            if (clksUptHesapYatanTx == null) {
                clksUptHesapYatanTx = new ClksUptHesapYatanTx();
            }

            conn = DALUtil.getGMConnection();

            GMServerDatasource.close(stmt2);

            GMMap sMap = new GMMap();
            sMap.put("REFERENCE", clksUptHesapYatanTx.getReferansNo());
            sMap = GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CANCEL_CUST_ACCOUNT_TRANSACTION", sMap);
            return new GMMap();
        }
        catch (Exception e) {
            logger.error("BNSPR_TRN3554_AFTER_CANCELLATION err: " + e);
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt2);
            GMServerDatasource.close(conn);
        }
    }
  
}
