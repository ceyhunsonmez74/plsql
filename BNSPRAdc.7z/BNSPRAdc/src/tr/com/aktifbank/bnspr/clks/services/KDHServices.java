package tr.com.aktifbank.bnspr.clks.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class KDHServices {
	/**
	 * CLKS KDH Basvuru Bilgileri
	 * @param 		
	 * 		iMap
	 * 			-TC_KIMLIK_NO
	 * 			-BASVURU_DURUM
	 * 			-BASVURU_NO (Akustik Cagrilarinda)
	 * @return
	 * 		oMap
	 * 			-BASVURU_NO
	 * 			-SOZLESME_TARIHI
	 * 			-MUSTERI_NO
	 * 			-VDSZ_HESAP_NO
	 * 			-KDH_DOVIZ
	 * 			-ONAYLANAN_LIMIT_TUTARI
	 * 			-AD_SOYAD
	 * 			-FAIZ_TAHAKKUK_PERYODU
	 * 			-FAIZ_TAHAKKUK_GUNU
	 * 			-ODEME_TARIHI
	 * 			-KKDF
	 * 			-BSMV
	 * 			-AYLIK_FAIZ_ORANI
	 * 			-GECIKME_FAIZI
	 * 			-TUKETICI_ADRES
	 * 			-BANKA_UNVAN	
	 * 			-BANKA_ADRES
	 * 			-EKSTRE_UCRETI
	 * 			-MESAJ_1
	 * 			-MESAJ_2
	 * 			-BARKOD_NUMARASI
	 * 			-ISLEM_NO_BELGE
	 * 			-ISLEM_NO_BANKA
	 * 			-EMEKLI_MI
	 */
	@GraymoundService("CLKS_PTT_KMH_SOZLESME_BILGILERI_AL")
	public static GMMap clksGetPttKmhSozlesmeBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap(); 
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3071.PTT_KMH_SOZLESME_BILGILERI_AL(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			
			int i = 1;

			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("BASVURU_DURUM"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i++, Types.NUMERIC); // p_basvuru_no out number,
			stmt.registerOutParameter(i++, Types.VARCHAR); //p_sozlesme_tarihi	out varchar2,
			stmt.registerOutParameter(i++, Types.NUMERIC); // p_musteri_no	out number,
			stmt.registerOutParameter(i++, Types.NUMERIC); //p_vdsz_hesap_no	out number,
			stmt.registerOutParameter(i++, Types.VARCHAR); //p_kdh_doviz	out varchar2,
			stmt.registerOutParameter(i++, Types.NUMERIC); //p_limit_tutari	out number, ********
			stmt.registerOutParameter(i++, Types.VARCHAR); //p_ad_soyad	out varchar2,******
			stmt.registerOutParameter(i++, Types.VARCHAR); //p_faiz_tahakkuk_peryodu	out varchar2,
			stmt.registerOutParameter(i++, Types.VARCHAR); //p_faiz_tahakkuk_gunu	out varchar2,
			stmt.registerOutParameter(i++, Types.VARCHAR); //p_odeme_tarihi	out varchar2,
			stmt.registerOutParameter(i++, Types.NUMERIC); //p_kkdf	out number,
			stmt.registerOutParameter(i++, Types.NUMERIC); //p_bsmv	out number,
			stmt.registerOutParameter(i++, Types.NUMERIC); //p_aylik_faiz_orani	out number,
			stmt.registerOutParameter(i++, Types.NUMERIC); //p_gecikme_faizi	out number,
			stmt.registerOutParameter(i++, Types.VARCHAR); //p_tuketici_adres	out varchar2,
			stmt.registerOutParameter(i++, Types.VARCHAR); // p_banka_unvan	out varchar2,
			stmt.registerOutParameter(i++, Types.VARCHAR); // p_banka_adres	out varchar2,
			stmt.registerOutParameter(i++, Types.NUMERIC); //p_ekstre_ucreti out number,
			stmt.registerOutParameter(i++, Types.VARCHAR); // p_mesaj_1 out varchar2,
			stmt.registerOutParameter(i++, Types.VARCHAR); // p_mesaj_2 out varchar2
			stmt.registerOutParameter(i++, Types.NUMERIC); // p_barkod_no out number,
			stmt.registerOutParameter(i++, Types.NUMERIC); // p_islem_no_belge out number
			stmt.registerOutParameter(i++, Types.NUMERIC); // p_son_tx_no out number
			stmt.registerOutParameter(i++, Types.VARCHAR); // p_emekli_mi out varchar2
			stmt.execute();
			
			oMap.put("EMEKLI_MI"				, stmt.getString(--i));
			oMap.put("ISLEM_NO_BANKA"			, stmt.getString(--i));
			oMap.put("ISLEM_NO_BELGE"			, stmt.getString(--i));
			oMap.put("BARKOD_NUMARASI"			, stmt.getString(--i));
			oMap.put("MESAJ_2"					, stmt.getString(--i));
			oMap.put("MESAJ_1"					, stmt.getString(--i));
			oMap.put("EKSTRE_UCRETI"			, stmt.getBigDecimal(--i));
			oMap.put("BANKA_ADRES"				, stmt.getString(--i));
			oMap.put("BANKA_UNVAN"				, stmt.getString(--i));
			oMap.put("TUKETICI_ADRES"			, stmt.getString(--i));
			oMap.put("GECIKME_FAIZI"			, stmt.getBigDecimal(--i));
			oMap.put("AYLIK_FAIZ_ORANI"			, stmt.getBigDecimal(--i));
			oMap.put("BSMV"						, stmt.getBigDecimal(--i));
			oMap.put("KKDF"						, stmt.getBigDecimal(--i));
			oMap.put("ODEME_TARIHI"				, stmt.getString(--i));
			oMap.put("FAIZ_TAHAKKUK_GUNU"		, stmt.getString(--i));
			oMap.put("FAIZ_TAHAKKUK_PERYODU"	, stmt.getString(--i));
			oMap.put("AD_SOYAD"					, stmt.getString(--i));
			oMap.put("ONAYLANAN_LIMIT_TUTARI"	, stmt.getBigDecimal(--i));
			oMap.put("KDH_DOVIZ"				, stmt.getString(--i));
			oMap.put("VDSZ_HESAP_NO"			, stmt.getBigDecimal(--i));
			oMap.put("MUSTERI_NO"				, stmt.getBigDecimal(--i));
			oMap.put("SOZLESME_TARIHI"			, stmt.getString(--i));
			oMap.put("BASVURU_NO"				, stmt.getBigDecimal(--i));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	/**
	 * CLKS KDH Basvuru Bilgileri
	 * @param 		
	 * 		iMap
	 * 			-TRX_NO
	 * @return
	 * 		oMap
	 * 			-TC_KIMLIK_NO
	 */ 			
	@GraymoundService("CLKS_PTT_KDH_TCKN_AL")
	public static GMMap clksGetKDHTCKN(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?= call PKG_TRN3071.Islemden_TCKN_Al(?)}");
			
			stmt.registerOutParameter(1, Types.VARCHAR); //p_sozlesme_tarihi	out varchar2,
			stmt.setString(2, iMap.getString("TRX_NO"));
			
			stmt.execute();
			
			oMap.put("TC_KIMLIK_NO"				, stmt.getString(1));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}


}
