package tr.com.aktifbank.bnspr.clks.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.aktifbank.bnspr.dao.ClksFaturaTahsilatTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksMutabakat;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCParameters;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class PttKurumServices {
	public static final String PAY_CHANNEL_CODE_ = "PAY_CHANNEL_CODE";
	public static final String PAY_CHANNEL_CODE  = "07";
	private static Logger		logger			= Logger.getLogger(PttKurumServices.class);

    @GraymoundService("PTT_KURUM")
    public static GMMap pttKurum(GMMap iMap) {

        GMMap oMap = new GMMap();

        try {
            oMap = GMServiceExecuter.call("BNSPR_COLL_INST_GET_INSTITUTION_LIST", iMap);
        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    @GraymoundService("PTT_ODEME_TIPI_LISTELE")
    public static GMMap pttOdemeListesi(GMMap iMap) {
        GMMap oMap = new GMMap();

        try {
            oMap = GMServiceExecuter.call("BNSPR_COLL_INST_GET_PAYMENT_TYPE_LIST", iMap);
        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    @GraymoundService("PTT_KURUM_MASK_BILGILERI_LISTESI")
    public static GMMap pttKurumListesi(GMMap iMap) {
        GMMap oMap = new GMMap();

        try {
            oMap = GMServiceExecuter.call("BNSPR_COLL_INST_GET_PAYMENT_INPUTS", iMap);
        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    @GraymoundService("PTT_FATURA_LISTESI")
    public static GMMap pttFaturaListesi(GMMap iMap) {
        GMMap oMap = new GMMap();

        try {
            oMap = GMServiceExecuter.call("BNSPR_COLL_INST_GET_BILL_LIST", iMap);
        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    @GraymoundService("PTT_FATURA_DEVAM")
    public static GMMap pttFaturaDevam(GMMap iMap) {
        GMMap oMap = new GMMap();

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {

            /* �lk kontroller yap�l�yor... (OTP �ifre ve hesap kontrol�) */
            {
                if (iMap != null && iMap.getString("HESAP_NO", "").length() > 0) {
                    ADCSession.put("PARENT_USER_OID", ADCSession.get("USER_OID"));

                    String userOid = iMap.getString("USER_OID");
                    ADCSession.put("USER_OID", userOid);

                    if (userOid != null) {
                        GMMap tmp = new GMMap().put("USER_OID", userOid).put("OTP_PASS", iMap.getString("OPT_SIFRE"));
                        if (ADCParameters.getInt("CLKS_OTP_CONTROL") == 1) {
                            GMServiceExecuter.call("ADC_MAN_USER_OTP_VALIDATE", tmp);
                        }
                    } else {
                        throw new GMRuntimeException(0, GMMessageFactory.getMessage("CLKSWRONGTCKN", null), true); // LOGNCHANNL
                    }
                }
            }

            /*
             * ��lem numaras� olu�turulup, session'da sonradan kullan�lmak �zere
             * sakland�:
             */

            BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
            ADCSession.put("CS_REFERENCE_ID", trxNo);

            ClksFaturaTahsilatTx ct = new ClksFaturaTahsilatTx();

            ct.setAdSoyad(iMap.getString("AD_SOYAD"));
            ct.setAnneAdi(iMap.getString("ANNE_ADI"));
            ct.setBabaAdi(iMap.getString("BABA_ADI"));
            ct.setCeptel(iMap.getString("CEPTEL"));
            ct.setOptSifre(iMap.getString("OPT_SIFRE"));
            ct.setDogumTarihi(StringUtils.isBlank(iMap.getString("DOGUM_TARIHI")) ? null : new java.sql.Date(iMap.getDate("DOGUM_TARIHI").getTime()));
            ct.setDogumYeri(iMap.getString("DOGUM_YERI"));
            ct.setDurum("A");
            ct.setFaturaId(iMap.getString("FATURA_ID"));
            ct.setFaturaNo(iMap.getString("FATURA_NO"));
            ct.setFaturaMasrafTutar(iMap.getBigDecimal("FATURA_MASRAF"));
            ct.setFaturaTutar(iMap.getBigDecimal("FATURA_TUTAR"));
            ct.setHesapNo(iMap.getString("HESAP_NO"));
            ct.setIykAdsoyad(iMap.getString("IYK_ADSOYAD"));
            ct.setIykBm(iMap.getString("IYK_BM"));
            ct.setIykIl(iMap.getString("IYK_IL"));
            ct.setIykMerkez(iMap.getString("IYK_MERKEZ"));
            ct.setIykMerkezSube(iMap.getString("IYK_MERKEZ_SUBE"));
            ct.setIykSicil(iMap.getString("IYK_SICIL"));
            ct.setIykSube(iMap.getString("IYK_SUBE"));
            ct.setKismiOdeme(iMap.getString("KISMI_TAHSILAT"));
            ct.setKurumAdi(iMap.getString("KURUM_ADI"));
            ct.setKurumId(iMap.getString("KURUM_OID"));

            /* musteriNo'yu al�yoruz: */
            {
                conn = DALUtil.getGMConnection();

                stmt = conn.prepareCall("{? = call Pkg_Hesap.HesapListe(?,?,?,?,?,?,?)}");
                int i = 1;

                stmt.registerOutParameter(i++, -10);

                stmt.setBigDecimal(i++, null);
                stmt.setString(i++, null);
                stmt.setBigDecimal(i++, StringUtils.isBlank(ct.getHesapNo())?null:new BigDecimal(ct.getHesapNo()));
                stmt.setString(i++, null);
                stmt.setString(i++, null);
                stmt.setString(i++, null);
                stmt.setString(i++, null);

                stmt.execute();

                rSet = (ResultSet) stmt.getObject(1);

                if (rSet.next())
                	ct.setMusteriNo(rSet.getBigDecimal("MUSTERI_NO"));

                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
            }

            /* masrafTutari hesapl�yoruz: */
            {
                GMServerDatasource.close(stmt);
                stmt = conn.prepareCall("{call PKG_MASRAF_YENI.kanal_masraf_hesapla(?, ?, ?, ?, ?, ?, ?, ?, ?)}");
                int i = 1;

                stmt.setString(i++, null);
                stmt.setBigDecimal(i++, null);
                stmt.setString(i++, null);
                stmt.setBigDecimal(i++, ct.getMusteriNo());
                stmt.setBigDecimal(i++, null);
                stmt.setBigDecimal(i++, null);
                stmt.registerOutParameter(i++, Types.NUMERIC); // Buras� kullanaca��m�z tahsil masraf
                stmt.registerOutParameter(i++, Types.NUMERIC);
                stmt.setBigDecimal(i++, ct.getFaturaMasrafTutar());
                stmt.execute();

                ct.setMasrafTutar(stmt.getBigDecimal(7));

                GMServerDatasource.close(stmt);
            }

            ct.setOdemeSekli(iMap.getString("ODEME_SEKLI"));
            ct.setOdemeTipiAdi(iMap.getString("ODEME_TIPI_ADI"));

            /*
             * '�deme Alan De�erleri' ekleniyor (aralar�nda noktal� virg�l
             * ile)...
             */
            {
                String str = "";
                for (int i = 0; i < iMap.getInt("ODEME_ALAN_ADEDI"); i++) {
                    str += iMap.getString("ODEME_ALAN_" + (i + 1),"") + ";";
                }
                str=StringUtils.strip(str, ";");
                ct.setOdemeTipiAlan(iMap.getInt("ODEME_ALAN_ADEDI")==0 ? null : StringUtils.isBlank(str)?null:str); // en sondaki fazla noktal� virg�l� silerek veriyi sakl�yoruz
            }

            ct.setOdemeTipiOid(iMap.getString("ODEME_TIPI_OID"));
            ct.setOdemeTipiKodu(iMap.getString("ODEME_TIPI_KODU"));
            ct.setOptSifre(iMap.getString("OPT_SIFRE"));
            ct.setAdres(iMap.getString("ADRES"));
            ct.setTahsilTutar(iMap.getBigDecimal("ODENECEK_TUTAR"));
            ct.setTarih(BnsprCommonFunctions.getBankaTarih());

            ct.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
            ct.setTxNo(trxNo);

            /*
             * Son kontroller yap�l�yor... (ClksFaturaTahsilatTx pojosundaki
             * do�rulama kriterleri)
             */
            {
                //                ClassValidator<ClksFaturaTahsilatTx> ctValidator = new ClassValidator<ClksFaturaTahsilatTx>(ClksFaturaTahsilatTx.class);
                //                InvalidValue[] invalidValues = ctValidator.getInvalidValues(ct);
                //
                //                for (InvalidValue value : invalidValues) {
                //                    System.out.println("========");
                //                    System.out.println(value);
                //                    System.out.println("message=" + value.getMessage());
                //                    System.out.println("propertyName=" + value.getPropertyName());
                //                    System.out.println("propertyPath=" + value.getPropertyPath());
                //                    System.out.println("value=" + value.getValue());
                //                    System.out.println();
                //                }
                //    
                //                if (invalidValues.length > 0) {
                //                    throw new GMRuntimeException(0, invalidValues[0].toString() + " : " + invalidValues[0].getValue(), false);
                //                }

                /*
                 * Pojodaki kriterler kapat�ld��� i�in a�a��daki do�rulamalar
                 * eklendi:
                 */
                if (ct.getTxNo()==null)
                    throw new GMRuntimeException(0, GMMessageFactory.getMessage("PTT_TX_NO_IS_EMPTY", null), true);
//                if (ct.getMusteriNo()==null)
//                    throw new GMRuntimeException(0, GMMessageFactory.getMessage("PTT_CUSTOMER_NO_NOT_FOUND", null), true);
                if (!StringUtils.isBlank(ct.getHesapNo()) && (StringUtils.isBlank(ct.getCeptel()) || StringUtils.isBlank(ct.getOptSifre())))
                    throw new GMRuntimeException(0, GMMessageFactory.getMessage("PTT_INVALID_PHONE_NUMBER", null), true);
            }

            Session session = DAOSession.getSession("BNSPRDal");
            session.saveOrUpdate(ct);
            session.flush();

            /* Devam edilecek mi? // E�er devam edilmeyecekse hata f�rlat�r */
            {
                GMServerDatasource.close(stmt);
                stmt = conn.prepareCall("{call PKG_PTT_FATURA_TAHSILAT.WS_Fatura_Devam_Kontrol(?)}");

                stmt.setBigDecimal(1, trxNo);
                stmt.execute();
            }

            oMap.put("BANKA_ISLEM_NO", ct.getTxNo());
            oMap.put("TAHSIL_MASRAF", ct.getMasrafTutar());

        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }

    @GraymoundService("PTT_FATURA_REQUEST")
    public static GMMap pttFaturaRequest(GMMap iMap) {
        GMMap oMap = new GMMap();

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_PTT_FATURA_TAHSILAT.WS_Fatura_Request(?)}");

            stmt.setBigDecimal(1, iMap.getBigDecimal("BANKA_ISLEM_NO"));
            stmt.execute();

        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }

    @GraymoundService("PTT_FATURA_CONFIRM")
    public static GMMap pttFaturaConfirm(GMMap iMap) {
        GMMap oMap = new GMMap();

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            Session session = DAOSession.getSession("BNSPRDal");

            ClksFaturaTahsilatTx clksFaturaTahsilatTx =
                (ClksFaturaTahsilatTx) session.createCriteria(ClksFaturaTahsilatTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("BANKA_ISLEM_NO"))).uniqueResult();

            if (clksFaturaTahsilatTx == null) { throw new GMRuntimeException(0, GMMessageFactory.getMessage("PTT_DATA_NOT_FOUND", null), true); }

            oMap.putAll(iMap);
            oMap.put("CHANNEL_REF_ID", iMap.getBigDecimal("BANKA_ISLEM_NO"));
            oMap.put("REFERENCE_ID", iMap.getBigDecimal("BANKA_ISLEM_NO"));

            conn = DALUtil.getGMConnection();

            oMap.put("PAY_CHANNEL_CODE", iMap.getString("PAY_CHANNEL_CODE"));
            oMap.put("PAYMENT_SOURCE", StringUtils.isBlank(clksFaturaTahsilatTx.getHesapNo())?"01":"02"); // nakit ise "01" hesaptan ise "02"

            oMap.put("ACCOUNT_NO", clksFaturaTahsilatTx.getHesapNo());
            oMap.put("MUSTERI_NO", clksFaturaTahsilatTx.getMusteriNo());

            /* Bu k�s�mda hesab�n bulundu�u �ube getiriliyor. */
            try {
                GMServerDatasource.close(stmt);
                stmt = conn.prepareCall("{? = call Pkg_Hesap.HesapListe(?,?,?,?,?,?,?)}");
                int i = 1;

                stmt.registerOutParameter(i++, -10);
                stmt.setBigDecimal(i++, clksFaturaTahsilatTx.getMusteriNo());
                stmt.setString(i++, null);
                stmt.setBigDecimal(i++, clksFaturaTahsilatTx.getHesapNo()==null?null:new BigDecimal(clksFaturaTahsilatTx.getHesapNo()));
                stmt.setString(i++, null);
                stmt.setString(i++, null);
                stmt.setString(i++, null);
                stmt.setString(i++, null);
                stmt.execute();

                rSet = (ResultSet) stmt.getObject(1);

                if (rSet.next()) { // Bize tek bir sonu� gelecek ��nk� hem mu�teriNo hem de hesapNoyu verdik.
                	oMap.put("ACCOUNT_BRANCH", rSet.getString("SUBE")); // �ube No
                }
            } catch (Exception e) {
            	oMap.put("ACCOUNT_BRANCH", (BigDecimal) null);
            }
            
            oMap.put("PAYMENT_TYPE_CODE", clksFaturaTahsilatTx.getOdemeTipiKodu());
            oMap.put("CUSTOM_AMOUNT", clksFaturaTahsilatTx.getTahsilTutar());
            oMap.put("INSTITUTION_OID", clksFaturaTahsilatTx.getKurumId());
            oMap.put("OBJECT", clksFaturaTahsilatTx.getFaturaId());
            oMap.put("TC_ID", clksFaturaTahsilatTx.getTcKimlikNo());
            oMap.put("PHONE_NUMBER", clksFaturaTahsilatTx.getCeptel());

            oMap.put("AB_EXEMPTION", clksFaturaTahsilatTx.getMasrafTutar().compareTo(BigDecimal.ZERO)==0?"1":null);

            oMap.put("CURRENCY_CODE", "TRY");

            {
                String[] subSTR = StringUtils.isBlank(clksFaturaTahsilatTx.getOdemeTipiAlan()) || clksFaturaTahsilatTx.getOdemeTipiAlan().equals("null") ?
                		new String[]{}:clksFaturaTahsilatTx.getOdemeTipiAlan().split(";");

                oMap.put("SUBSCRIBER_SIZE", subSTR.length);
                int j = 1;
                for (String string : subSTR) {
                    oMap.put("SUBSCRIBER_NO" + j++, string);
                }
            }

            oMap = GMServiceExecuter.call("BNSPR_COLL_INST_PAY_BILL", oMap);
        	
            clksFaturaTahsilatTx =
                (ClksFaturaTahsilatTx) session.createCriteria(ClksFaturaTahsilatTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("BANKA_ISLEM_NO"))).uniqueResult();

            if (clksFaturaTahsilatTx == null) { throw new GMRuntimeException(0, GMMessageFactory.getMessage("PTT_DATA_NOT_FOUND", null), true); }

            clksFaturaTahsilatTx.setConfirmed("1");
            clksFaturaTahsilatTx.setDurum("K");
            clksFaturaTahsilatTx.setPttIslemNo(iMap.getBigDecimal("PTT_ISLEM_NO"));
            session.save(clksFaturaTahsilatTx);

        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }

    @GraymoundService("PTT_FATURA_IPTAL")
    public static GMMap pttFaturaIptal(GMMap iMap) {
		logger.info("PTT_FATURA_IPTAL in: " + iMap.toString());

        GMMap oMap = new GMMap();
        try {
        	iMap.put("REFERENCE_NO", iMap.get("BANKA_ISLEM_NO"));
        	GMServiceExecuter.call("BNSPR_COLL_INST_CANCEL_BILL_PAYMENT", iMap);

        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        }

		logger.info("PTT_FATURA_IPTAL out: " + oMap.toString());
        return oMap;
    }

    @GraymoundService("PTT_FATURA_SET_IPTAL_BILGILERI")
    public static GMMap pttFaturaSetIptalBilgileri(GMMap iMap) {
		logger.info("PTT_FATURA_SET_IPTAL_BILGILERI in: " + iMap.toString());

        GMMap oMap = new GMMap();

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_PTT_FATURA_TAHSILAT.PTT_Fatura_Iptal(?, ?,?)}");

            int i = 1;

            stmt.setBigDecimal(i++, iMap.getBigDecimal("BANKA_ISLEM_NO"));
            stmt.setString(i++, iMap.getString("ISLEM_YERI"));
            stmt.setString(i++, iMap.getString("KULLANICI_SICIL"));
            stmt.execute();

        } catch (Exception e) {
            e.printStackTrace();
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

		logger.info("PTT_FATURA_SET_IPTAL_BILGILERI out: " + oMap.toString());
        return oMap;
    }
    
	@GraymoundService("CLKS_AGREEMENT_NEW_SAVE_KURUM")
	public static GMMap agreementSave(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			
			Session	session	= DAOSession.getSession("BNSPRDal");
			
			iMap.put("sorguNo", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO",
				new GMMap()).getBigDecimal("TRX_NO"));
			 
			ClksMutabakat clksMutabakat ;
			 
			for (int i=0; i<iMap.getSize("ISLEM_LISTESI"); i++) {
				clksMutabakat = (ClksMutabakat)session.get(ClksMutabakat.class,
					iMap.getBigDecimal("ISLEM_LISTESI", i, "ISLEM_NO_BANKA"));
					
				if(clksMutabakat == null) {
					clksMutabakat = new ClksMutabakat();
				}
				
				clksMutabakat.setSorguNo(iMap.getBigDecimal("sorguNo"));
				
				clksMutabakat.setIslemNo(iMap.getBigDecimal("ISLEM_LISTESI", i, "ISLEM_NO"));
				clksMutabakat.setIslemNoBanka(iMap.getBigDecimal("ISLEM_LISTESI", i, "ISLEM_NO_BANKA"));
				clksMutabakat.setDovizKod(iMap.getString("ISLEM_LISTESI", i, "DOVIZ_KODU"));
				clksMutabakat.setHesapNo(iMap.getBigDecimal("ISLEM_LISTESI", i, "HESAP_NO"));
				clksMutabakat.setIslemTipi(iMap.getBigDecimal("ISLEM_LISTESI", i, "ISLEM"));
				clksMutabakat.setIslemTuru(iMap.getString("ISLEM_LISTESI", i, "ISLEM_TURU"));
				clksMutabakat.setMasrafTutari(iMap.getBigDecimal("ISLEM_LISTESI", i, "MASRAF_TUTARI"));
				clksMutabakat.setTutar(iMap.getBigDecimal("ISLEM_LISTESI", i, "TUTAR"));
				clksMutabakat.setMasrafDovizKod(iMap.getString("ISLEM_LISTESI", i, "MASRAF_DOVIZ_KODU"));
				clksMutabakat.setSubeId(iMap.getString("ISLEM_LISTESI", i, "SUBE_ID"));
				clksMutabakat.setMerkezId(iMap.getString("ISLEM_LISTESI", i, "MERKEZ_ID"));
				
				clksMutabakat.setIslemTarihi(iMap.getDate("ISLEM_TARIHI"));
				
				session.saveOrUpdate(clksMutabakat);
			}
			
			session.flush();
			
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{ ? = call PKG_PTT_MUTABAKAT.AGREEMENT_RESPONSE_KONT_KURUM(?)}");
			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setDate(2, new Date(iMap.getDate("ISLEM_TARIHI").getTime()));
			stmt.execute();

			oMap.put("CONTROL_MASK", stmt.getBigDecimal(1));	
			
			return oMap;
			
		}
		catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw ExceptionHandler.convertException(new GMRuntimeException(0,
				(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",
					myMap).get("ERROR_MESSAGE")));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		//return new GMMap();
	}
	
	@GraymoundService("CLKS_RESPONSE_NEW_PROXY_KURUM")
	public static GMMap agreementResponse(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap o2Map = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{ ? = call PKG_PTT_MUTABAKAT.AGREEMENT_RESPONSE_KURUM(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setDate(2, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			
			stmt.execute();
			rSetMSet = (ResultSet)stmt.getObject(1);
			
			o2Map = DALUtil.rSetResults(rSetMSet, "ISLEM_LISTESI");
			
			String tableName = "ISLEM_LISTESI";
			for (int i = 0; i< o2Map.getSize("ISLEM_LISTESI"); i++) {
				oMap.put(tableName, i, "ISLEM_NO", o2Map.getString(tableName, i, "ISLEMNO"));
				oMap.put(tableName, i, "ISLEM", o2Map.getString(tableName, i, "ISLEM"));
				oMap.put(tableName, i, "ISLEM_TURU", o2Map.getString(tableName, i, "ISLEMTURU"));
				oMap.put(tableName, i, "HESAP_NO", o2Map.getString(tableName, i, "HESAPNO"));
				oMap.put(tableName, i, "MASRAF_TUTARI", o2Map.getString(tableName, i, "MASRAFTUTARI"));
				oMap.put(tableName, i, "DOVIZ_KODU", o2Map.getString(tableName, i, "DOVIZKODU"));
				oMap.put(tableName, i, "ISLEM_NO_BANKA", o2Map.getString(tableName, i, "ISLEMNOBANKA"));
				oMap.put(tableName, i, "TUTAR", o2Map.getString(tableName, i, "TUTAR"));
				oMap.put(tableName, i, "MASRAF_DOVIZ_KODU", o2Map.getString(tableName, i, "MASRAFDOVIZKODU"));
			}
			return oMap;
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
}
