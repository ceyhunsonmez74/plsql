package tr.com.aktifbank.bnspr.clks.services;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.ClksFonAltinKupurTx;
import tr.com.aktifbank.bnspr.dao.ClksFonAltinKupurTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.annotation.Parameter;
import com.graymound.annotation.ParameterType;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class PTTOnlineAltinServices {

	@GraymoundService("ALTIN_SORGULAMA")
	public static GMMap musteriSorgulama(GMMap iMap) {

		GMMap oMap = new GMMap();
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_musteri_sorgula(?,?,?,?,?,?,?,?,?,?)}";
		int i = 0;
		
		Object [] inputValues = new Object [4];
		Object [] outputValues= new Object [16];
		
		try {
			
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.containsKey("ISLEM_TIPI") ? iMap.getString("ISLEM_TIPI") : 'S'; // Default: Altin Fon Alis
			
			i = 0;
			
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "AD";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "SOYAD";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "TEL_NO";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MUSTERI_NO";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "HESAP_NO";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "SUBE";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "ADRES";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "FON_ADI";
			
			oMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("ALTIN_BILGI")
	public static GMMap altinFiyatBilgi(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		String funcAltinTL;
		if("A".equals(iMap.getString("ISLEM_TIPI"))) {
			funcAltinTL = "{? = call  pkg_kur.eak_to_lc(?,?)}";
		} else {
			funcAltinTL = "{? = call  pkg_kur.esk_to_lc(?,?)}";
		}
		String funcParite = "{? = call  pkg_kur.Parite(?,?,?,?)}";
		
		String funcFonFiyatList = "{? = call  pkg_fon_wrapper.fon_fiyat_list(?,?)}";
		String tableName = "FON_FIYAT_LIST";
		
		int i = 0;
		int row = 0;
		
		try {
			
			iMap.put("PARAMETRE", "ALTIN_FON_KODU");
			String altinDovizKodu = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).getString("DEGER");
			
			Object [] input2Values = new Object [8];
			
			i = 0;
			
			input2Values[i++] = BnsprType.STRING;
			input2Values[i++] = altinDovizKodu;
			input2Values[i++] = BnsprType.NUMBER;
			input2Values[i++] = new BigDecimal(1);
			
			BigDecimal tutar = (BigDecimal)DALUtil.callOracleFunction(funcAltinTL, BnsprType.NUMBER, input2Values);
			BigDecimal roundTutar= tutar.setScale(5, RoundingMode.DOWN);
			
			oMap.put("PAY_FIYAT_LISTESI", row, "DOVIZ_KOD", "TRY");
			oMap.put("PAY_FIYAT_LISTESI", row++, "TUTAR", roundTutar);
			
			i = 0;
			
			input2Values[i++] = BnsprType.STRING;
			input2Values[i++] = altinDovizKodu;
			input2Values[i++] = BnsprType.STRING;
			input2Values[i++] = "USD";
			input2Values[i++] = BnsprType.NUMBER;
			input2Values[i++] = new BigDecimal(1);
			input2Values[i++] = BnsprType.STRING;
			input2Values[i++] = iMap.getString("ISLEM_TIPI");
			
			tutar = (BigDecimal) DALUtil.callOracleFunction(funcParite, BnsprType.NUMBER, input2Values);
			roundTutar= tutar.setScale(5, RoundingMode.DOWN);
			
			oMap.put("PAY_FIYAT_LISTESI", row, "DOVIZ_KOD", "USD");
			oMap.put("PAY_FIYAT_LISTESI", row++, "TUTAR", roundTutar);
			
			i = 0;
			
			input2Values[i++] = BnsprType.STRING;
			input2Values[i++] = "EUR";
			input2Values[i++] = BnsprType.STRING;
			input2Values[i++] = "USD";
			input2Values[i++] = BnsprType.NUMBER;
			input2Values[i++] = new BigDecimal(1);
			input2Values[i++] = BnsprType.STRING;
			input2Values[i++] = iMap.getString("ISLEM_TIPI");
			
			// XAU-Parite / EUR-Parite
			BigDecimal tutar_eur_parite = (BigDecimal) DALUtil.callOracleFunction(funcParite, BnsprType.NUMBER, input2Values);
			tutar = tutar.divide(tutar_eur_parite, RoundingMode.HALF_UP);
			roundTutar= tutar.setScale(5, RoundingMode.DOWN);
			
			oMap.put("PAY_FIYAT_LISTESI", row, "DOVIZ_KOD", "EUR");
			oMap.put("PAY_FIYAT_LISTESI", row++, "TUTAR", roundTutar);
			
			Object [] input3Values = new Object [4];
			
			i = 0;
			
			input3Values[i++] = BnsprType.DATE; 
			input3Values[i++] = null;
			input3Values[i++] = BnsprType.STRING;
			input3Values[i++] = altinDovizKodu;
			
			GMMap resultMap = (GMMap)DALUtil.callOracleRefCursorFunction(funcFonFiyatList, tableName, input3Values);
			oMap.put("FON_PAY_FIYATI", resultMap.getBigDecimal("FON_FIYAT_LIST", 0, "FON_FIYATI"));
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("ALTIN_HESAP")
	public static GMMap altinSatisFiyatHesapla(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			
			String tableName = "FON_FIYAT_TABLO";
			int i = 0;
			
			String func = "{? = call  pkg_ptt_altin_fonu.Hesapla(?,?,?,?,?,?,?)}";
			Object [] inputValues = new Object [14];

			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.containsKey("ISLEM_NO_BANKA") ? iMap.getBigDecimal("ISLEM_NO_BANKA") : null;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MUSTERI_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TUTAR_GRAM");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.containsKey("DOVIZ_KODU") ? iMap.getString("DOVIZ_KODU") : "TRY";
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TALEP_GRAM");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TALEP_TUTAR");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEM_TIPI");
			
			GMMap resultMap = (GMMap)DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			
			oMap.put("ISLEM_NO_BANKA", resultMap.getBigDecimal("FON_FIYAT_TABLO", 0, "ISLEM_NO"));
			oMap.put("TUTAR", resultMap.getBigDecimal("FON_FIYAT_TABLO", 0, "ISLEM_TUTARI"));
			oMap.put("FON_PAY_FIYATI", resultMap.getBigDecimal("FON_FIYAT_TABLO", 0, "FON_FIYATI"));
			oMap.put("FON_PAY_ADEDI", resultMap.getBigDecimal("FON_FIYAT_TABLO", 0, "PAY_ADEDI"));
			oMap.put("FON_GRAMI", resultMap.getBigDecimal("FON_FIYAT_TABLO", 0, "FON_TUTARI"));
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("ALTIN_ALIS_TALEP")
	public static GMMap altinAlisTalep(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_alis_talep(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [34];
		Object [] outputValues= new Object [10];
		
		try {
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MUSTERI_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("AD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOYAD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TAHSILAT_SEKLI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("HESAP_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_IL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_SUBE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_YER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("MERKEZ_SUBE_BASMUDURLUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMI_YAPAN_SICIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMI_YAPAN_KULLANICI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEMIN_YAPILDIGI_MERKEZ_ID");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEMIN_YAPILDIGI_SUBE_ID");
			
			i = 0;         
			
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "ISLEM_TARIHI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "VALOR_TARIHI";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MASRAF_TUTARI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "MASRAF_DOVIZ_KODU";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "SUBE_KODU";
			
			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_ALIS_KONTROL")
	public static GMMap altinAlisKontrol(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			
			String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_alis_kontrol(?,?)}";  
			int i = 0;
			
			Object [] inputValues = new Object [2];
			Object [] outputValues= new Object [2];
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			
			i = 0;
			
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "DOKUMAN_LIST";
			
			GMMap resultMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.putAll(resultMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_ALIS_ONAY")
	public static GMMap altinAlisOnay(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			
			String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_alis_onay(?,?)}";  
			int i = 0;
			
			Object [] inputValues = new Object [4];
			Object [] outputValues= new Object [0];
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("PTT_ISLEM_NO");
			
			GMMap resultMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.putAll(resultMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_SATIS_STOK_DURUM")
	public static GMMap alinSatisStokDurum(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		int row = 0;
		
		try {
			iMap.put("MERKEZ_ID", iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ_ID"));
			iMap.put("SUBE_ID", iMap.getString("ISLEMIN_YAPILDIGI_SUBE_ID"));
			//GMMap tmpMap = GMServiceExecuter.call("BNSPR_EXTERNAL_PTT_IAR_BRING_STOCK", iMap);
			GMMap tmpMap = new GMMap();

			tmpMap.put("STOCK", row, "ADET", 59);
			tmpMap.put("STOCK", row, "ACIKLAMA", "0.50 GRAM PTT ALTIN");
			tmpMap.put("STOCK", row, "URUN_KODU", "0.50 GRM PTT");
			tmpMap.put("STOCK", row++, "URUN_ID", 9);
			
			tmpMap.put("STOCK", row, "ADET", 46);
			tmpMap.put("STOCK", row, "ACIKLAMA", "1 GRAM PTT ALTIN");
			tmpMap.put("STOCK", row, "URUN_KODU", "1.00 GRM PTT");
			tmpMap.put("STOCK", row++, "URUN_ID", 10);
			
			tmpMap.put("STOCK", row, "ADET", 38);
			tmpMap.put("STOCK", row, "ACIKLAMA", "1.50 GRAM PTT ALTIN");
			tmpMap.put("STOCK", row, "URUN_KODU", "1.50 GRM PTT");
			tmpMap.put("STOCK", row++, "URUN_ID", 11);
			
			for(int i=0; i<tmpMap.getSize("STOCK"); i++) {	
				oMap.put("STOK_LIST", i, "ID", tmpMap.getBigDecimal("STOCK", i, "URUN_ID"));
				oMap.put("STOK_LIST", i, "URUN_KODU", tmpMap.getString("STOCK", i, "URUN_KODU"));
				oMap.put("STOK_LIST", i, "ACIKLAMA", tmpMap.getString("STOCK", i, "ACIKLAMA"));
				oMap.put("STOK_LIST", i, "MIKTAR", tmpMap.getBigDecimal("STOCK", i, "ADET"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_SATIS_TALEP")
	public static GMMap altinSatisTalep(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_satis_talep(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [34];
		Object [] outputValues= new Object [10];
		
		try {
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MUSTERI_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("AD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOYAD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TAHSILAT_SEKLI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("HESAP_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_IL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_SUBE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_YER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("MERKEZ_SUBE_BASMUDURLUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMI_YAPAN_SICIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMI_YAPAN_KULLANICI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEMIN_YAPILDIGI_MERKEZ_ID");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEMIN_YAPILDIGI_SUBE_ID");
			
			i = 0;         
			
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "ISLEM_TARIHI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "VALOR_TARIHI";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MASRAF_TUTARI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "MASRAF_DOVIZ_KODU";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "SUBE_KODU";
			
			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			int row = 0;
			while (row < iMap.getSize("ALTIN_KUPURU")) {
				ClksFonAltinKupurTxId clksFonAltinKupurTxId = new ClksFonAltinKupurTxId();
				clksFonAltinKupurTxId.setTxNo(iMap.getBigDecimal("ISLEM_NO_BANKA"));
				clksFonAltinKupurTxId.setKupurKod(iMap.getString("ALTIN_KUPURU", row, "KULCE"));
				ClksFonAltinKupurTx clksFonAltinKupurTx = new ClksFonAltinKupurTx();
				clksFonAltinKupurTx.setId(clksFonAltinKupurTxId);
				clksFonAltinKupurTx.setMiktar(iMap.getBigDecimal("ALTIN_KUPURU", row, "ADET"));
				session.saveOrUpdate(clksFonAltinKupurTx);
				session.flush();
				row++;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("ALTIN_SATIS_KONTROL")
	public static GMMap altinSatisKontrol(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			
			String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_satis_kontrol(?,?)}";  
			int i = 0;
			
			Object [] inputValues = new Object [2];
			Object [] outputValues= new Object [2];
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			
			i = 0;
			
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "DOKUMAN_LIST";
			
			GMMap resultMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.putAll(resultMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_SATIS_ONAY")
	public static GMMap altinSatisOnay(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			
			String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_satis_onay(?,?)}";  
			int i = 0;
			
			Object [] inputValues = new Object [4];
			Object [] outputValues= new Object [0];
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("PTT_ISLEM_NO");
			
			GMMap resultMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.putAll(resultMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	
	
	@GraymoundService("ALTIN_DUZENLI_ALIS_TALEP")
	public static GMMap altinDuzenliAlis(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String procStr = "{ call PKG_PTT_ALTIN_FONU.WS_altin_duzenli_alis_talep(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [46];
		Object [] outputValues= new Object [12];
		
		try {
			
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("AD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SOYAD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ALIS_TIPI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ALIS_TUTARI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DOVIZ_KODU");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("HESAP_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("GUN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ALIS_SURE_TIPI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ADET");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = (iMap.get("SURE") == null || "".equals(iMap.get("SURE").toString())) ? null : new java.sql.Date(iMap.getDate("SURE").getTime());
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("EMAIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SMS");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_IL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_SUBE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_YER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("MERKEZ_SUBE_BASMUDURLUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMI_YAPAN_SICIL");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMI_YAPAN_KULLANICI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEMIN_YAPILDIGI_MERKEZ_ID");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEMIN_YAPILDIGI_SUBE_ID");
			
			i = 0;
			
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MUSTERI_NO";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "ISLEM_TARIHI";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MASRAF_TUTARI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "MASRAF_DOVIZ_KODU";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "ISLEM_NO_BANKA";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "SUBE_KODU";
			
			GMMap resultMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.putAll(resultMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_DUZENLI_ALIS_KONTROL")
	public static GMMap altinDuzenliAlisKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_duzenli_alis_kontrol(?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [2];
		Object [] outputValues= new Object [2];
		
		try {
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			
			i = 0;
			
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "DOKUMAN_LIST";
			
			GMMap resultMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.putAll(resultMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_DUZENLI_ALIS_ONAY")
	public static GMMap altinDuzenliAlisOnay(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_duzenli_alis_onay(?,?)}";  
			int i = 0;
			
			Object [] inputValues = new Object [4];
			Object [] outputValues= new Object [0];
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("PTT_ISLEM_NO");
			
			oMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_DUZENLI_ALIS_TALIMAT_LIST")
	public static GMMap altinDuzenliAlisTalimatList(GMMap iMap) {
		GMMap oMap = new GMMap();
		String procStr = "{ call PKG_PTT_ALTIN_FONU.WS_altin_talimat_liste_sorgula(?,?,?,?,?,?)}";
		int i = 0;
		
		Object [] inputValues = new Object [2];
		Object [] outputValues= new Object [10];
		
		try {
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TCKN");
			
			i = 0;
			
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MUSTERI_NO";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "TALIMAT_SAYISI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "AD";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "SOYAD";
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "TALIMAT_LIST";
			
			GMMap resultMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.putAll(resultMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_DUZENLI_ALIS_TALIMAT_IPTAL_KONTROL")
	public static GMMap altinDuzenliAlisTalimatIptalKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_talimat_iptal_kontrol(?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [2];
		Object [] outputValues= new Object [2];
		
		try {
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			
			i = 0;
			
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "DOKUMAN_LIST";
			
			GMMap resultMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			
			oMap.putAll(resultMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_DUZENLI_ALIS_TALIMAT_IPTAL_ONAY")
	public static GMMap altinDuzenliAlisTalimatIptalOnay(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_talimat_iptal_onay(?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [4];
		Object [] outputValues= new Object [0];
		
		try {
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("PTT_ISLEM_NO");
			
			oMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_LOKASYONDA_MUTABAKAT")
	public static GMMap altinLokasyondaMutabakat(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_lokasyonda_mutabakat(?,?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [4];
		Object [] outputValues= new Object [2];
		
		try {
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEMIN_YAPILDIGI_MERKEZ_ID");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEMIN_YAPILDIGI_SUBE_ID");
			
			i = 0;
			
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "ISLEM_LIST";
			
			oMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_IPTAL_DURUM")
	public static GMMap altinIptalDurum(GMMap iMap) {

		GMMap oMap = new GMMap();
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_iptal_durum(?,?,?,?,?,?,?,?,?,?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [2];
		Object [] outputValues= new Object [20];
		
		try {
			
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("PTT_ISLEM_NO");
			
			i = 0;
			
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "ISLEM_NO_BANKA";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "ISLEM_TIPI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "TAHSILAT_TIPI";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "TUTAR";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "TUTAR_DOVIZ_KODU";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "MASRAF_TUTARI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "MASRAF_DOVIZ_KODU";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "BANKA_DURUM";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "ACIKLAMA";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "IPTAL_BUTON_TIP";
			
			oMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("ALTIN_IPTAL")
	public static GMMap altinIptal(GMMap iMap) {
	
		GMMap oMap = new GMMap();
		String procStr = "{call PKG_PTT_ALTIN_FONU.WS_altin_iptal(?,?,?,?,?,?)}";  
		int i = 0;
		
		Object [] inputValues = new Object [10];
		Object [] outputValues= new Object [2];
		
		try {

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("IPTAL_YAPILDIGI_YER");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("IPTAL_YAPAN_KULLANICI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("IPTAL_ACIKLAMA");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ISLEM_NO_BANKA");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("IPTAL_PTT_ISLEM_NO");
			
			i = 0;
			
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "DURUM";
			
			oMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
}