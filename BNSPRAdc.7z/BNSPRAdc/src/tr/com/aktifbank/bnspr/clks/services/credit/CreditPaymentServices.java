package tr.com.aktifbank.bnspr.clks.services.credit;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionContext;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.CommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal.GMCacheCommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCreditPaymentDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalInstallmentLoanDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CreditPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.InstallmentLoan;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKonsolidasyon;
import tr.com.aktifbank.bnspr.dao.ClksBbBorcTrOnboarding;
import tr.com.aktifbank.bnspr.dao.ClksBbBorcTransferi;
import tr.com.aktifbank.bnspr.dao.ClksHavaleOdeme;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.dao.GnlMasraf;
import tr.com.calikbank.bnspr.dao.GnlMasrafId;
import tr.com.calikbank.bnspr.dao.MuhBloke;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditPaymentServices {

	private static Logger logger = Logger.getLogger(CreditPaymentServices.class);
	
	@GraymoundService("CLKS_CRED_CONS_INSTALLMENT_LOAN_PAYMENT_WRAPPER")
	public static GMMap clksCredConsInstallemntLoanPaymentWrapper(GMMap iMap) {
		
		try {
			GMServiceExecuter.executeAsync("CLKS_CRED_CONS_INSTALLMENT_LOAN_PAYMENT", iMap);
		} catch(Exception e) {
			logger.error("CLKS_CRED_CONS_INSTALLMENT_LOAN_PAYMENT_WRAPPER err:", e);
		}
		
		return new GMMap();
	}
	
	@GraymoundService("CLKS_CRED_CONS_INSTALLMENT_LOAN_PAYMENT")
	public static GMMap clksCredConsInstallemntLoanPayment(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = new GMMap();
		StringBuilder body = new StringBuilder();
		BigDecimal kapamaTutari = BigDecimal.ZERO, toplamKapamaTutari = BigDecimal.ZERO;
		List<BigDecimal> acikBasvuruNoListesi = new ArrayList<BigDecimal>();
		BigDecimal blokeBasarili = null;
		Connection conn = null;
		CallableStatement stmt = null;
		StringBuilder query = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_PTT_BASVURU.konsolidasyon_kapama_liste(?)");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			
			while (rSet.next()) {	
				try {
					map.put("BASVURU_NO", rSet.getBigDecimal(1));
					GMServiceExecuter.executeNT("BNSPR_CLKS_CREDIT_PAYMENT_CONSOLIDATION_PAY_OFF", map);
				} catch(Exception e) {
					logger.error(
						"CLKS_CRED_CONS_INSTALLMENT_LOAN_PAYMENT > pkg_ptt_basvuru.konsolidasyon_kredi_kapama err:", e);
					acikBasvuruNoListesi.add(rSet.getBigDecimal(1));
				}
			}
			
			if(acikBasvuruNoListesi.size() > 0) {
				
				body.append("<!DOCTYPE html><html lang=\"en\"><head></head><body>");
				body.append("<div style\"margin:20px 0\">").append("Ba�vuru No: ").append(iMap.getString("BASVURU_NO"))
					.append("</div>");
				body.append("<ul>");
				for(BigDecimal acikBasvuruNo : acikBasvuruNoListesi) {
					kapamaTutari = (BigDecimal) DALUtil.callOracleFunction(
						"{? = call pkg_trn3243.kredi_kapama_tutar(?)}", BnsprType.NUMBER, BnsprType.NUMBER,
						acikBasvuruNo);
					body.append("<li>").append(acikBasvuruNo.toString()).append(": ").append(kapamaTutari.toString())
						.append("</li>");
					toplamKapamaTutari = toplamKapamaTutari.add(kapamaTutari);
				}
				body.append("</ul>");
				
				blokeBasarili = (BigDecimal) DALUtil.callOracleFunction(
					"{? = call pkg_trn2030.kredi_konsolidasyon_bloke_koy(?,?,?,?)}", BnsprType.NUMBER,
					BnsprType.NUMBER, iMap.getBigDecimal("BLOKE_MUSTERI_NO"), BnsprType.NUMBER, iMap
						.getBigDecimal("BLOKE_HESAP_NO"), BnsprType.STRING, iMap.getString("BLOKE_DOVIZ_KODU"),
					BnsprType.NUMBER, toplamKapamaTutari);

				body.append("<div style\"margin:20px 0\">").append("Bloke Durumu: ").append(
					blokeBasarili.equals(BigDecimal.ONE) ? "Ba�ar�l�" : "Ba�ar�s�z").append("</div>");
				body.append("</body></html>");

				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K",
					new GMMap().put("PARAMETRE", "PTT_KOM_MUTABAKAT_MAIL_TO")).getString("DEGER"));
				mailMap.put("TRX_NO", iMap.getString("ISLEM_NO"));
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "PTT Konsolidasyon Kredisi - Kapatilamayan Ba�vurular");
				mailMap.put("MAIL_BODY", body.toString());
				mailMap.put("IS_BODY_HTML", "E");
				GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
			}
			
		} catch(Exception e) {

			logger.error("CLKS_CRED_CONS_INSTALLMENT_LOAN_PAYMENT err:", e);
			
			if(blokeBasarili == null) {
				body.append("<div style\"margin:20px 0\">Bloke Durumu: Ba�ar�s�z</div>");
			}
			body.append("</body></html>");
			GMMap mailMap = new GMMap();
			mailMap.put("MAIL_TO", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K",
				new GMMap().put("PARAMETRE", "PTT_KOM_MUTABAKAT_MAIL_TO")).getString("DEGER"));
			mailMap.put("TRX_NO", iMap.getString("ISLEM_NO"));
			mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
			mailMap.put("MAIL_SUBJECT", "PTT Konsolidasyon Kredisi - Kapatilamayan Ba�vurular");
			mailMap.put("MAIL_BODY", body.toString());
			mailMap.put("IS_BODY_HTML", "E");
			GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CLKS_CREDIT_PAYMENT_CONSOLIDATION_PAY_OFF")
	public static GMMap clksCreditPaymentConsolidationPayOff(GMMap iMap) {
		
		try {
			
			DALUtil.callOracleProcedure("{call pkg_ptt_basvuru.konsolidasyon_kredi_kapama(?)}", new Object[]{
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")
			}, new Object[]{});
			
			return new GMMap().put("RESPONSE", 2);
		} catch(Exception e) {

			logger.error("BNSPR_CLKS_CREDIT_PAYMENT_CONSOLIDATION_PAY_OFF err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CLKS_CREDIT_PAYMENT_CONSOLIDATION_INFO")
	public static GMMap clksCreditPaymentConsolidationInfo(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			oMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_ptt.konsolidasyon_geri_odeme_bilgi(?)}",
				"yapilandirilanBasvuruListesi", BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_NO"));
			return oMap;

		} catch(Exception e) {

			logger.error("CLKS_CREDIT_PAYMENT_CONSOLIDATION_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kredi kullandirim odemesi onayinda cagirilir.
	 * 
	 * @param iMap {ISLEM_NO}
	 * @param iMap {ISLEM_TURU}
	 * @param iMap {ACIKLAMA}
	 * @return 
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_PAYMENT_APPROVAL")
	public static GMMap paymentApproval(GMMap iMap) {

		GMMap oMap = new GMMap();
		int count = 0;
		StringBuilder sb = new StringBuilder();

		try {

			TransactionDao<CreditPayment> trxDao = new DalCreditPaymentDao();
			CommissionDao commissionDao = new GMCacheCommissionDao();
			CreditPayment trxCreditPayment = trxDao.get(iMap.getBigDecimal("ISLEM_NO"));
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksHavaleOdemeTx clksHavaleOdemeTx = (ClksHavaleOdemeTx) session.get(ClksHavaleOdemeTx.class,
				trxCreditPayment.trxNo());
			BirBasvuru basvuru = (BirBasvuru) session.get(BirBasvuru.class, trxCreditPayment.getReferenceNo());
			
			trxCreditPayment.setCommissionCategory(Arrays.asList("1", "2", "3").contains(
				basvuru.getPttMaasAlinanKurum()) ? CommissionCategory.KREDI_KULLANDIRIM_EMEKLI : "4".equals(basvuru
				.getPttMaasAlinanKurum()) ? CommissionCategory.KREDI_KULLANDIRIM_PERSONEL
				: CommissionCategory.KREDI_KULLANDIRIM_DIGER);

			CommissionContext commissionContext = new CommissionContext(trxCreditPayment.commissionCategory()
				.getStrategyClass().getDeclaredConstructor(List.class).newInstance(
					commissionDao.getByCommissionCategory(trxCreditPayment.commissionCategory())));

			Record commissionRecord = commissionContext.calculate(new Record(trxCreditPayment.amount(),
				trxCreditPayment.currency()));
			trxCreditPayment.setCommissionAmount(commissionRecord.getAmount());
			trxCreditPayment.setCommissionCurrency(commissionRecord.getCurrency());

			trxDao.saveCommission(trxCreditPayment);
			
			oMap.put("KAMPANYA", GMServiceExecuter.call("BNSPR_TRN3112_GET_FOR_UPDATE", new GMMap().put("KAMPANYA_KOD",
				basvuru.getKampKod())));
			
			if(oMap.getMap("KAMPANYA").getBoolean("BORC_TRANSFERI_EH")) {
				
				ClksBbBorcTransferi borcTransferi = (ClksBbBorcTransferi) session.get(ClksBbBorcTransferi.class,
					basvuru.getBasvuruNo());
				
				GMMap eftMap = new GMMap().put("T_IBAN", borcTransferi.getIban());
				eftMap.put("PAYMENT_TRX", clksHavaleOdemeTx);
				
				GMServiceExecuter.call("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_EXECUTE_EFT", eftMap);
				
			} else {
			
				if(oMap.getMap("KAMPANYA").getBoolean("BIRLESTIRME_EH")) {
	
					List<?> list = session.createCriteria(BirBasvuruKonsolidasyon.class).add(
						Restrictions.eq("id.basvuruNo", new BigDecimal(clksHavaleOdemeTx.getReferansNo()))).add(
						Restrictions.eq("kapamaEh", "E")).list();
					Iterator<?> iterator = list.iterator();
					while(iterator.hasNext()) {
	
						BirBasvuruKonsolidasyon birBasvuruKonsolidasyon = (BirBasvuruKonsolidasyon) iterator.next();
						oMap.put("yapilandirilanBasvuruListesi", count, "basvuruNo", birBasvuruKonsolidasyon.getId()
							.getYapilandirilanBasvuruNo());
						oMap.put("yapilandirilanBasvuruListesi", count++, "islemNo", birBasvuruKonsolidasyon.getTxNo());
						sb.append(birBasvuruKonsolidasyon.getId().getYapilandirilanBasvuruNo()).append(",");

						InstallmentLoan trxInstallmentLoan = new InstallmentLoan(birBasvuruKonsolidasyon.getTxNo());
						trxInstallmentLoan.setReconciliationType(ReconciliationType.INSTALLMENT_LOAN);
						trxInstallmentLoan.setCommissionCategory(Arrays.asList("1", "2", "3").contains(
							basvuru.getPttMaasAlinanKurum()) ? CommissionCategory.KREDI_TAHSILAT_EMEKLI : "4"
							.equals(basvuru.getPttMaasAlinanKurum()) ? CommissionCategory.KREDI_TAHSILAT_PERSONEL
							: CommissionCategory.KREDI_TAHSILAT_DIGER);

						CommissionContext commissionContextLoan = new CommissionContext(trxInstallmentLoan
							.commissionCategory().getStrategyClass().getDeclaredConstructor(List.class).newInstance(
								commissionDao.getByCommissionCategory(trxInstallmentLoan.commissionCategory())));

						Record commissionRecordLoan = commissionContextLoan.calculate(new Record(BigDecimal.ONE,
							CurrencyType.TRY));
						trxInstallmentLoan.setCommissionAmount(commissionRecordLoan.getAmount());
						trxInstallmentLoan.setCommissionCurrency(commissionRecordLoan.getCurrency());

						new DalInstallmentLoanDao().saveCommission(trxInstallmentLoan);
					}
	
					oMap.put("BASVURU_NO", new BigDecimal(clksHavaleOdemeTx.getReferansNo()));
					oMap.put("CONTENT", sb.toString());
					oMap.put("BLOKE_HESAP_NO", clksHavaleOdemeTx.getHesapNo());
					oMap.put("BLOKE_MUSTERI_NO", clksHavaleOdemeTx.getMusteriNo());
					oMap.put("BLOKE_DOVIZ_KODU", clksHavaleOdemeTx.getDovizKodu());
				} else if(oMap.getMap("KAMPANYA").getBoolean("PTT_ICI_BIRLESTIRME_EH")) {
				
					if(GMServiceExecuter.call("BNSPR_CLKS_CREDIT_GET_MARKETING_PERMISSION",
						new GMMap().put("NATIONAL_IDENTITY_NUMBER", clksHavaleOdemeTx.getTckno())).getBoolean(
						"F_MARKETING_PERMISSION_SMS")) {

						GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap()
						.put("MSISDN", clksHavaleOdemeTx.getGonderenTelefon())
						.put("CONTENT", 
							 GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap()
								.put("MESSAGE_NO", BigDecimal.valueOf(5968))
								.put("P1", clksHavaleOdemeTx.getGonderenAdSoyad().replaceFirst(".* ", ""))
								.put("P2", clksHavaleOdemeTx.getReferansNo())).getString("ERROR_MESSAGE"))
						.put("TRX_NO", clksHavaleOdemeTx.getTxNo())
						.put("MUSTERI_NO", clksHavaleOdemeTx.getMusteriNo()));
					}
				}
	
				oMap.putAll(GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap));
			}
			
			return oMap;

		} catch(Exception e) {

			logger.error("BNSPR_CLKS_CREDIT_PAYMENT_APPROVAL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kredi kullandirim odemesinda kullandirim blokesi cozmek amaci ile cagirilir.
	 * 
	 * @param iMap {APPLICATION_NO}		Kredi basvuru numarasi
	 * @return							Bloke bulunamamis ancak hata alinmamis ise {@code RESPONSE=1}, bloke bulunmus ve
	 * 									kaldirilmis ise {@code RESPONSE=2} key,value iceren {@code GMMap}
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_UNBLOCK_ACCOUNT")
	public static GMMap unblockAccount(GMMap iMap) {

		GMMap oMap = new GMMap().put("RESPONSE", "1");
		String blockedTypeCode = "17", blockedOpenStatusCode = "A", blockedClosedStatusCode = "K";

		try {
			
			Session session = DAOSession.getSession("BNSPRDal");

			BirKullandirim kullandirim = (BirKullandirim) session.get(BirKullandirim.class, iMap
				.getBigDecimal("APPLICATION_NO"));

			BigDecimal netAmount = kullandirim.getKrdTutarTl().subtract(
				kullandirim.getDosyaMasraf() == null ? BigDecimal.ZERO : kullandirim.getDosyaMasraf()).subtract(
				kullandirim.getBayiKom() == null ? BigDecimal.ZERO : kullandirim.getBayiKom()).subtract(
				kullandirim.getMusKom() == null ? BigDecimal.ZERO : kullandirim.getMusKom()).subtract(
				kullandirim.getFarkFaiz() == null ? BigDecimal.ZERO : kullandirim.getFarkFaiz()).subtract(
				kullandirim.getKrediSigPrim() == null ? BigDecimal.ZERO : kullandirim.getKrediSigPrim());

			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("hesapNo", kullandirim.getAlacHesapNo());
			restrictions.put("durumKodu", blockedOpenStatusCode);
			restrictions.put("blokeNedenKodu", blockedTypeCode);
			restrictions.put("blokeTutari", netAmount);

			MuhBloke bloke = (MuhBloke) session.createCriteria(MuhBloke.class).add(Restrictions.allEq(restrictions))
				.uniqueResult();

			if(bloke != null) {
				DALUtil.callOracleProcedure("{call pkg_hesap.bloketutariguncelle(?,?,?)}", new Object[]{
					BnsprType.NUMBER, kullandirim.getAlacHesapNo(), BnsprType.NUMBER, netAmount.negate(),
					BnsprType.STRING, blockedTypeCode}, new Object[]{});

				bloke.setDurumKodu(blockedClosedStatusCode);
				bloke.setCozKayitTarih(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate(
					"BANKA_TARIH"));
				bloke.setCozKayitSistemTarih(new Date());
				bloke.setCozKayitKullaniciKodu((String) DALUtil.callOracleFunction(
					"{? = call pkg_global.get_kullanicikod}", BnsprType.STRING, new Object[]{}));
				bloke.setCozKayitKullaniciBolumKodu((String) DALUtil.callOracleFunction(
					"{? = call pkg_global.get_subekod}", BnsprType.STRING, new Object[]{}));

				session.saveOrUpdate(bloke);
				session.flush();
				oMap.put("RESPONSE", "2");
			}

			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_UNBLOCK_ACCOUNT err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT borc transferi kredisi kullandirim odemesi amaci ile cagirilir. Kullandirim blokesi cozulerek, 
	 * EFT tetiklenir.
	 * 
	 * @param iMap {T_IBAN}							Alici IBAN
	 * @param iMap {PAYMENT_TRX}					{@link ClksHavaleOdemeTx}
	 * @return										EFT basari ile gonderildigi durumda {@code RESPONSE=2} key, value
	 * 												iceren {@code GMMap}
	 * @throws GMRuntimeException
	 * 
	 * @see #unblockAccount(GMMap) BNSPR_CLKS_CREDIT_UNBLOCK_ACCOUNT
	 * @see BNSPR_COMMON_GET_BANKA_TARIH
	 * @see BNSPR_TRN2315_EFT_PAYGATE_CHECK
	 * @see BNSPR_TRX_SEND_TRANSACTION
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_EXECUTE_EFT")
	public static GMMap balanceTransferExecuteEft(GMMap iMap) {
		
		GMMap oMap = new GMMap().put("RESPONSE", "2");
		BigDecimal eftAmount;
		
		try {

			ClksHavaleOdemeTx odemeTx = (ClksHavaleOdemeTx) iMap.get("PAYMENT_TRX");
			eftAmount = odemeTx.getTutar().subtract(
				odemeTx.getMasrafTutari() != null ? odemeTx.getMasrafTutari() : BigDecimal.ZERO);
			
			GMServiceExecuter
				.call("BNSPR_CLKS_CREDIT_UNBLOCK_ACCOUNT", new GMMap().put("APPLICATION_NO", odemeTx.getReferansNo()));
	
			String gonderenBankaKodu = (String) DALUtil.callNoParameterFunction(
				"{? = call pkg_genel_pr.bankamiz_kodu}", Types.VARCHAR);
			String gonderenSubeKodu = "90001";
			String gonderenSehirKodu = "999";
			
			GMMap ibanMap = (GMMap) DALUtil.callOracleProcedure(
				"{call pkg_eft.EFT_IBAN_Banka_Sube_Sehir_Al(?,?,?,?,?,?,?)}",
				new Object[] {
					BnsprType.STRING, iMap.getString("T_IBAN")
				}, 
				new Object[] {
					BnsprType.STRING, "T_BANK_CODE",
					BnsprType.STRING, "T_BRANCH_CODE",
					BnsprType.STRING, "T_CITY_CODE",
					BnsprType.STRING, "T_BANK_NAME",
					BnsprType.STRING, "T_BRANCH_NAME",
					BnsprType.STRING, "T_CITY_NAME"
				}
			);
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eft = new EftEftTx();
			eft.setTxNo(odemeTx.getTxNo());
			eft.setAciklama(String.format("%s NOLU BA�VURU, %s BANKA BOR� TRANSFER� R�SK KAPAMA", odemeTx
				.getReferansNo(), ibanMap.getString("T_BANK_NAME")));
			eft.setGelenGiden("GIDEN");
			eft.setMesajKodu("KRED");
			eft.setEftTarih(odemeTx.getIslemTarihi());
			eft.setTutar(eftAmount);
			eft.setTutarScr(eftAmount);
			eft.setMasraf(BigDecimal.ZERO);
			eft.setMasrafIcDis("D");
			eft.setMasrafTahsilSekli("H");
			eft.setMasrafHesapNo(odemeTx.getHesapNo());
			eft.setGonderen(odemeTx.getGonderenAdSoyad());
			eft.setGonderenVergiKimlikNumarasi(odemeTx.getTckno());
			eft.setGonderenHesapNumarasi(odemeTx.getHesapNo().toString());
			eft.setGonderenTelefon(odemeTx.getGonderenTelefon().replaceFirst("((\\+|0{2})9){0,1}0", ""));
			eft.setGonderenAdres(odemeTx.getGonderenAdres());
			eft.setGonderenBanka(gonderenBankaKodu);
			eft.setGonderenSube(gonderenSubeKodu);
			eft.setGonderenSehir(gonderenSehirKodu);
			eft.setBolumKodu(odemeTx.getSubeKodu());
			eft.setAliciAdi(odemeTx.getGonderenAdSoyad());
			eft.setAlanBankaKodu(ibanMap.getString("T_BANK_CODE", iMap.getString("T_BANK_CODE")));
			eft.setAlanSehirKodu(ibanMap.getString("T_CITY_CODE", iMap.getString("T_CITY_CODE")));
			eft.setAlanSubeKodu(ibanMap.getString("T_BRANCH_CODE", iMap.getString("T_BRANCH_CODE")));
			eft.setAliciIban(iMap.getString("T_IBAN"));
			eft.setSorguNo((BigDecimal) DALUtil.callOracleFunction("{? = call pkg_genel_pr.genel_kod_al(?)}",
				BnsprType.NUMBER, BnsprType.STRING, "EFT-SORGU"));
			eft.setOtomatikBildirimOlustur("E");
			eft.setOncelik(BigDecimal.ONE);
			eft.setIslemTipi("M");
			eft.setKasaKimlikTipi(BigDecimal.ONE);
			eft.setOdemeTuru("99");
			eft.setMusteriNo(odemeTx.getMusteriNo());
			eft.setMusteriHesapNo(odemeTx.getHesapNo());
			session.save(eft);
			
			ClksHavaleOdeme odeme = (ClksHavaleOdeme) session.get(ClksHavaleOdeme.class, odemeTx.getReferansNo());

			if(odeme == null) {
				odeme = new ClksHavaleOdeme(odemeTx.getReferansNo());
			}
			
			odeme.setYaratanTxno(odemeTx.getTxNo());
			odeme.setDurumKodu(odemeTx.getDurumKodu());
			odeme.setIslemSekli(odemeTx.getIslemSekli());
			odeme.setIslem(odemeTx.getIslem());
			odeme.setMusteriNo(odemeTx.getMusteriNo());
			odeme.setHesapNo(odemeTx.getHesapNo());
			odeme.setDovizKodu(odemeTx.getDovizKodu());
			odeme.setTutar(odemeTx.getTutar());
			odeme.setTckno(odemeTx.getTckno());
			odeme.setValorTarihi(odemeTx.getValorTarihi());
			odeme.setAciklama(odemeTx.getAciklama());
			odeme.setSubeKodu(odemeTx.getSubeKodu());
			odeme.setMasrafTahsilDoviz(odemeTx.getMasrafTahsilDoviz());
			odeme.setMasrafTutari(odemeTx.getMasrafTutari());
			odeme.setMasrafHesapNo(odemeTx.getMasrafHesapNo());
			odeme.setIslemTarihi(odemeTx.getIslemTarihi());
			odeme.setAlacakMusteriNo(odemeTx.getAlacakMusteriNo());
			odeme.setAlacakHesapNo(odemeTx.getAlacakHesapNo());
			odeme.setGonderenAdSoyad(odemeTx.getGonderenAdSoyad());
			odeme.setGonderenAdres(odemeTx.getGonderenAdres());
			odeme.setGonderenTelefon(odemeTx.getGonderenTelefon());
			odeme.setIslemiYapanKullanici(odemeTx.getIslemiYapanKullanici());
			odeme.setIslemiYapanKullAdsoyad(odemeTx.getIslemiYapanKullAdsoyad());
			odeme.setIsleminYapildigiBasmudurluk(odemeTx.getIsleminYapildigiBasMudurluk());
			odeme.setIsleminYapildigiIl(odemeTx.getIsleminYapildigiIl());
			odeme.setIsleminYapildigiMerkez(odemeTx.getIsleminYapildigiMerkez());
			odeme.setIsleminYapildigiSube(odemeTx.getIsleminYapildigiSube());
			odeme.setIsleminYapildigiYer(odemeTx.getIsleminYapildigiYer());
			odeme.setIptalinYapildigiYer(null);
			odeme.setIptaliYapanKullAdsoyad(null);
			odeme.setIptaliYapanKullanici(null);
			odeme.setOdemeninDovizTuru(odemeTx.getOdemeninDovizTuru());
			odeme.setOdemeTutari(odemeTx.getOdemeTutari());
			session.save(odeme);
			
			ClksBbBorcTransferi borcTransferi = (ClksBbBorcTransferi) session.get(ClksBbBorcTransferi.class,
				new BigDecimal(odemeTx.getReferansNo()));

			borcTransferi.setEftTxNo(odemeTx.getTxNo());
			session.saveOrUpdate(borcTransferi);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(odemeTx.getIslemTarihi());
			cal.add(Calendar.DATE, GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N",
				new GMMap().put("PARAMETRE", "CLKS_KRD_BT_SORGU_ERTELEME_GUN")).getInt(("DEGER")));
			
			GMMap bMap = GMServiceExecuter.call("BNSPR_TRN3174_BORC_TRANSFERI_BILGI", new GMMap().put("BASVURU_NO", odemeTx.getReferansNo()));

			ClksBbBorcTrOnboarding onboarding = new ClksBbBorcTrOnboarding();
			onboarding.setBasvuruNo(new BigDecimal(odemeTx.getReferansNo()));
			onboarding.setMusteriNo(odemeTx.getMusteriNo());
			onboarding.setTarih(odemeTx.getIslemTarihi());
			onboarding.setSorguTarih(cal.getTime());
			onboarding.setSorguKontrolGun(GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N",
				new GMMap().put("PARAMETRE", "CLKS_KRD_BT_SORGU_KONTROL_GUN")).getBigDecimal(("DEGER")));
			onboarding.setKrediRisk(bMap.getBigDecimal("KREDI_RISKI"));
			onboarding.setKmhRisk(bMap.getBigDecimal("KMH_RISKI"));
			onboarding.setKkRisk(bMap.getBigDecimal("KREDI_KART_RISKI"));
			onboarding.setMaasSorguKontrolGun(GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N",
				new GMMap().put("PARAMETRE", "CLKS_KRD_BT_MAAS_SORGU_KNTRL")).getBigDecimal(("DEGER")));
			
			session.save(onboarding);
			
			GMMap textMap = new GMMap().put("MESSAGE_NO", BigDecimal.valueOf(5824))
				.put("P1", odemeTx.getGonderenAdSoyad().replaceFirst(".* ", ""))
				.put("P2", iMap.getString("T_IBAN").replaceFirst("[0-9]{20}", 
					new String(new char[20]).replace("\0", "*")));
					
			if(GMServiceExecuter.call("BNSPR_CLKS_CREDIT_GET_MARKETING_PERMISSION",
				new GMMap().put("NATIONAL_IDENTITY_NUMBER", odemeTx.getTckno())).getBoolean("F_MARKETING_PERMISSION_SMS")) {
				textMap.put("MESSAGE_NO", BigDecimal.valueOf(5875));
				textMap.put("P3", DALUtil.getResults(
					"select s.borc_transferi_upsell_limit from bnspr.bir_nbsm_sonuc s where s.basvuru_no = "
						+ odemeTx.getReferansNo()
						+ " and s.nbsm_call_tip_kod = 'F' and s.nbsm_call_id = (select max(s2.nbsm_call_id) from bir_nbsm_sonuc s2 where s2.basvuru_no = s.basvuru_no and s2.nbsm_call_tip_kod = s.nbsm_call_tip_kod)",
				"TABLO").getBigDecimal("TABLO", 0, "BORC_TRANSFERI_UPSELL_LIMIT")).toString();
			}
				
			GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap()
				.put("MSISDN", odemeTx.getGonderenTelefon())
				.put("CONTENT", 
					GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", textMap).getString("ERROR_MESSAGE"))
				.put("TRX_NO", odemeTx.getTxNo())
				.put("MUSTERI_NO", odemeTx.getMusteriNo()));
			
			GMMap amlMap = new GMMap();
			amlMap.put("ALAN_BANKA", DALUtil.callOneParameterFunction(
				"{? = call pkg_genel_pr.banka_adi_al_eft_hatasiz(?)}", Types.VARCHAR, eft.getAlanBankaKodu()));
			amlMap.put("GONDEREN", eft.getGonderen());
			amlMap.put("MUSTERI_NO", eft.getMusteriNo());
			amlMap.put("ACIKLAMA", eft.getAciklama());
			amlMap.put("ALICI", eft.getAliciAdi());
			amlMap.put("TUTAR", eft.getTutar());
			amlMap.put("EFT_TARIH", eft.getEftTarih());
			amlMap.put("TRX_NO", eft.getTxNo());
			amlMap.put("TRX_NAME", "23157");
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN2315_EFT_PAYGATE_CHECK", amlMap));

			DALUtil.callOracleProcedure("{call pkg_masraf_yeni.masraf_yarat(?,?,?,?,?,?)}", new Object[]{
				BnsprType.NUMBER, eft.getTxNo(), BnsprType.NUMBER, BigDecimal.valueOf(2315), BnsprType.NUMBER,
				eft.getTutar(), BnsprType.STRING, "TRY", BnsprType.NUMBER, eft.getMusteriNo(), BnsprType.NUMBER,
				eft.getMusteriHesapNo()}, new Object[]{});
			
			GnlMasraf masraf = (GnlMasraf) session.get(GnlMasraf.class, new GnlMasrafId(eft.getTxNo(), "EFTKOMISYN",
				BigDecimal.ONE));
			
			if (masraf != null) {
				masraf.setAlinan(BigDecimal.ZERO);
				masraf.setBsmv(BigDecimal.ZERO);
				session.saveOrUpdate(masraf);
			}
			
			session.flush();
			
			GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", new GMMap()
				.put("TRX_NO", eft.getTxNo())
				.put("TRX_NAME", "2315")			
				.put("TRX_ONAYSIZ_ISLEM", "E"));
			
			return oMap;
			
		} catch (Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_EXECUTE_EFT err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
