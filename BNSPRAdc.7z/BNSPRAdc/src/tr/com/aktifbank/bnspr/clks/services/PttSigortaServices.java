package tr.com.aktifbank.bnspr.clks.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.aktifbank.bnspr.dao.ClksSigortaMutabakat;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class PttSigortaServices {
	
	@GraymoundService("BNSPR_CLKS_PTT_KOMISYON_IZLEME_REQUEST")
    public static GMMap bnsprClksPttKomisyonIzlemeRequest(GMMap iMap)  {
	    GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet1 = null;
        ResultSet rSet2 = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call pkg_rc_sigorta.PTT_Komisyon_Izleme(?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            int i = 1;
            
            stmt.setString(i++, iMap.getString("PC_SIGORTA_SIRKETI"));
            stmt.setString(i++, iMap.getString("PC_POLICE_NO"));
            stmt.setString(i++, iMap.getString("PC_DURUMKODU"));
            stmt.setString(i++, iMap.getString("PC_TCKN"));
            stmt.setDate(i++, StringUtils.isBlank(iMap.getString("PD_SATIS_BAS_TAR")) ? null : new java.sql.Date(iMap.getDate("PD_SATIS_BAS_TAR").getTime()));
            stmt.setDate(i++, StringUtils.isBlank(iMap.getString("PD_SATIS_BIT_TAR")) ? null : new java.sql.Date(iMap.getDate("PD_SATIS_BIT_TAR").getTime()));
            stmt.setString(i++, iMap.getString("PC_SIGORTA_URUN"));
            stmt.setString(i++, iMap.getString("PC_PLAKA_IL"));
            stmt.setString(i++, iMap.getString("PC_PLAKA_HARF"));
            stmt.setString(i++, iMap.getString("PC_PLAKA_SAYI"));
            stmt.setString(i++, iMap.getString("PC_IPTAL_IADE"));
            stmt.registerOutParameter(i++, -10);
            stmt.registerOutParameter(i++, -10);
            stmt.execute();
            rSet1 = (ResultSet) stmt.getObject(12);
            rSet2 = (ResultSet) stmt.getObject(13);

            String listName1 = "RC_TAHAKKUK_LIST";
            String listName2 = "RC_TAHSILAT_LIST";
            int row = 0;
            while (rSet1.next()) {
                oMap.put(listName1, row, "SIGORTA_SIRKETI", rSet1.getObject("SIGORTA_SIRKETI"));
                oMap.put(listName1, row, "ODEME_SEKLI", rSet1.getObject("ODEME_SEKLI"));
                oMap.put(listName1, row, "SATIS_TARIHI", rSet1.getObject("SATIS_TARIHI") == null ? null : sdf.format(rSet1.getDate("SATIS_TARIHI")));
                oMap.put(listName1, row, "TC_KIMLIK_NO", rSet1.getObject("TC_KIMLIK_NO"));
                oMap.put(listName1, row, "POLICE_NO", rSet1.getObject("POLICE_NO"));
                oMap.put(listName1, row, "TAKSIT_SAYISI", rSet1.getObject("TAKSIT_SAYISI"));
                oMap.put(listName1, row, "PRIM_TUTARI", rSet1.getObject("PRIM_TUTARI"));
                oMap.put(listName1, row, "NET_PRIM_TUTARI", rSet1.getObject("NET_PRIM_TUTARI"));
                oMap.put(listName1, row, "KOMISYON_TUTARI", rSet1.getObject("KOMISYON_TUTARI"));
                oMap.put(listName1, row, "TOPLAM_KOMISYON_TUTARI", rSet1.getObject("TOPLAM_KOMISYON_TUTARI"));
                oMap.put(listName1, row, "POLICE_BAS_TARIH", rSet1.getObject("POLICE_BAS_TARIH") == null ? null : sdf.format(rSet1.getDate("POLICE_BAS_TARIH")));
                oMap.put(listName1, row, "POLICE_BIT_TARIH", rSet1.getObject("POLICE_BIT_TARIH") == null ? null : sdf.format(rSet1.getDate("POLICE_BIT_TARIH")));
                oMap.put(listName1, row, "URUN", rSet1.getObject("URUN"));
                oMap.put(listName1, row, "TAHSILAT_TARIHI", rSet1.getObject("TAHSILAT_TARIHI") == null ? null : sdf.format(rSet1.getDate("TAHSILAT_TARIHI")));
                oMap.put(listName1, row, "KOMISYON_DURUMU", rSet1.getObject("KOMISYON_DURUMU"));
                oMap.put(listName1, row, "IPTAL_IADE_DURUMU", rSet1.getObject("IPTAL_IADE_DURUMU"));

                row++;
            }
            while (rSet2.next()) {
                oMap.put(listName2, row, "SIGORTA_SIRKETI", rSet2.getObject("SIGORTA_SIRKETI"));
                oMap.put(listName2, row, "ODEME_SEKLI", rSet2.getObject("ODEME_SEKLI"));
                oMap.put(listName2, row, "SATIS_TARIHI", rSet2.getObject("SATIS_TARIHI") == null ? null : sdf.format(rSet2.getDate("SATIS_TARIHI")));
                oMap.put(listName2, row, "TC_KIMLIK_NO", rSet2.getObject("TC_KIMLIK_NO"));
                oMap.put(listName2, row, "POLICE_NO", rSet2.getObject("POLICE_NO"));
                oMap.put(listName2, row, "TAKSIT_SAYISI", rSet2.getObject("TAKSIT_SAYISI"));
                oMap.put(listName2, row, "PRIM_TUTARI", rSet2.getObject("PRIM_TUTARI"));
                oMap.put(listName2, row, "NET_PRIM_TUTARI", rSet2.getObject("NET_PRIM_TUTARI"));
                oMap.put(listName2, row, "KOMISYON_TUTARI", rSet2.getObject("KOMISYON_TUTARI"));
                oMap.put(listName1, row, "TOPLAM_KOMISYON_TUTARI", rSet1.getObject("TOPLAM_KOMISYON_TUTARI"));
                oMap.put(listName2, row, "POLICE_BAS_TARIH", rSet2.getObject("POLICE_BAS_TARIH") == null ? null : sdf.format(rSet2.getDate("POLICE_BAS_TARIH")));
                oMap.put(listName2, row, "POLICE_BIT_TARIH", rSet2.getObject("POLICE_BIT_TARIH") == null ? null : sdf.format(rSet2.getDate("POLICE_BIT_TARIH")));
                oMap.put(listName2, row, "URUN", rSet2.getObject("URUN"));
                oMap.put(listName2, row, "TAHSILAT_TARIHI", rSet2.getObject("TAHSILAT_TARIHI") == null ? null : sdf.format(rSet2.getDate("TAHSILAT_TARIHI")));
                oMap.put(listName2, row, "KOMISYON_DURUMU", rSet2.getObject("KOMISYON_DURUMU"));
                oMap.put(listName1, row, "IPTAL_IADE_DURUMU", rSet1.getObject("IPTAL_IADE_DURUMU"));
                row++;
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet1);
            GMServerDatasource.close(rSet2);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
	
	@GraymoundService("BNSPR_CLKS_PTT_ISLEM_IZLEME_REQUEST")
    public static GMMap bnsprClksGetPttIslemIzleme(GMMap iMap)  {
	    GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call pkg_rc_sigorta.PTT_Islem_Izleme(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            int i = 1;
            
            stmt.setString(i++, iMap.getString("PC_SIGORTA_SIRKETI"));
            stmt.setString(i++, iMap.getString("PC_POLICE_NO"));
            stmt.setString(i++, iMap.getString("PC_YENILEME_NO"));
            stmt.setString(i++, iMap.getString("PC_DURUMKODU"));
            stmt.setString(i++, iMap.getString("PC_TCKN"));
            stmt.setDate(i++, StringUtils.isBlank(iMap.getString("PD_TANZIM_BAS_TAR")) ? null : new java.sql.Date(iMap.getDate("PD_TANZIM_BAS_TAR").getTime()));
            stmt.setDate(i++, StringUtils.isBlank(iMap.getString("PD_TANZIM_BIT_TAR")) ? null : new java.sql.Date(iMap.getDate("PD_TANZIM_BIT_TAR").getTime()));
            stmt.setString(i++, iMap.getString("PC_SIGORTA_URUN"));
            stmt.setString(i++, iMap.getString("PC_PLAKA_IL"));
            stmt.setString(i++, iMap.getString("PC_PLAKA_HARF"));
            stmt.setString(i++, iMap.getString("PC_PLAKA_SAYI"));
            stmt.setString(i++, iMap.getString("PC_PTT_BASMUDURLUK"));
            stmt.setString(i++, iMap.getString("PC_PTT_MERKEZ"));
            stmt.setString(i++, iMap.getString("PC_PTT_SUBE"));
            stmt.setString(i++, iMap.getString("PC_PTT_KULLANICI"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("PC_PTT_ISLEM_NO"));
            stmt.setString(i++, iMap.getString("PC_TAHSILAT_SEKLI"));
            stmt.registerOutParameter(i, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(i);

            String listName = "RC_ISLEM_LIST";
            int row = 0;
            while (rSet.next()) {
                oMap.put(listName, row, "SIGORTA_SIRKETI", rSet.getObject("SIGORTA_SIRKETI"));
                oMap.put(listName, row, "URUN", rSet.getObject("URUN"));
                oMap.put(listName, row, "TANZIM_TARIHI", rSet.getObject("TANZIM_TARIHI") == null ? null : sdf.format(rSet.getDate("TANZIM_TARIHI")));
                oMap.put(listName, row, "POLICE_DURUMU", rSet.getObject("POLICE_DURUMU"));
                oMap.put(listName, row, "SIGORTALI_UNVAN", rSet.getObject("SIGORTALI_UNVAN"));
                oMap.put(listName, row, "SIGORTALI_TCKN_VKN", rSet.getObject("SIGORTALI_TCKN_VKN"));
                oMap.put(listName, row, "SIGORTA_ETTIREN_TCKN_VKN", rSet.getObject("SIGORTA_ETTIREN_TCKN_VKN"));
                oMap.put(listName, row, "POLICE_NO", rSet.getObject("POLICE_NO"));
                oMap.put(listName, row, "YENILEME_NO", rSet.getObject("YENILEME_NO"));
                oMap.put(listName, row, "ZEYIL_NO", rSet.getObject("ZEYIL_NO"));
                oMap.put(listName, row, "ZEYIL_ACIKLAMA", rSet.getObject("ZEYIL_ACIKLAMA"));
                oMap.put(listName, row, "TAKSIT_SAYISI", rSet.getObject("TAKSIT_SAYISI"));
                oMap.put(listName, row, "PRIM_TUTARI", rSet.getObject("PRIM_TUTARI"));
                oMap.put(listName, row, "NET_PRIM_TUTARI", rSet.getObject("NET_PRIM_TUTARI"));
                oMap.put(listName, row, "KOMISYON_TUTARI", rSet.getObject("KOMISYON_TUTARI"));
                oMap.put(listName, row, "POLICE_BAS_TARIH", rSet.getObject("POLICE_BAS_TARIH") == null ? null : sdf.format(rSet.getDate("POLICE_BAS_TARIH")));
                oMap.put(listName, row, "POLICE_BIT_TARIH", rSet.getObject("POLICE_BIT_TARIH") == null ? null : sdf.format(rSet.getDate("POLICE_BIT_TARIH")));
                oMap.put(listName, row, "PTT_ISLEM_NO", rSet.getObject("PTT_ISLEM_NO"));
                oMap.put(listName, row, "TAHSILAT_SEKLI", rSet.getObject("TAHSILAT_SEKLI"));
                row++;
            }

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

	@GraymoundService("CLKS_MUTABAKAT_CLKS_SIGORTA_AGREEMENT")
	public static GMMap agreementSigorta(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			iMap.put("SORGU_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));

			ClksSigortaMutabakat clksMutabakat;

			String tableName = "ISLEM_LISTESI";
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				clksMutabakat = (ClksSigortaMutabakat) session.get(ClksSigortaMutabakat.class, iMap.getBigDecimal(tableName, i, "ISLEM_NO_BANKA"));

				if (clksMutabakat == null) {
					clksMutabakat = new ClksSigortaMutabakat();
				}

				clksMutabakat.setSorguNo(iMap.getBigDecimal("SORGU_NO"));

				clksMutabakat.setIslemNo(iMap.getBigDecimal(tableName, i, "ISLEM_NO"));
				clksMutabakat.setIslemNoBanka(iMap.getBigDecimal(tableName, i, "ISLEM_NO_BANKA"));
				clksMutabakat.setDovizKod(iMap.getString(tableName, i, "DOVIZ_KODU"));
				clksMutabakat.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
				clksMutabakat.setIslemTipi(iMap.getBigDecimal(tableName, i, "ISLEM"));
				clksMutabakat.setIslemTuru(iMap.getString(tableName, i, "ISLEM_TURU"));
				clksMutabakat.setMasrafTutari(iMap.getBigDecimal(tableName, i, "MASRAF_TUTARI"));
				clksMutabakat.setTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
				clksMutabakat.setMasrafDovizKod(iMap.getString(tableName, i, "MASRAF_DOVIZ_KODU"));
				clksMutabakat.setSubeId(iMap.getString(tableName, i, "SUBE_ID"));
				clksMutabakat.setMerkezId(iMap.getString(tableName, i, "MERKEZ_ID"));
				clksMutabakat.setDurum(iMap.getString(tableName, i, "DURUM"));
				clksMutabakat.setIslemTarihi(iMap.getDate("ISLEM_TARIHI"));
				clksMutabakat.setKomisyonTutar(iMap.getBigDecimal(tableName, i, "KOMISYON_TUTARI"));

				session.saveOrUpdate(clksMutabakat);
			}

			session.flush();
			oMap.put("RESPONSE", "2");

			return oMap;
		}
		catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw ExceptionHandler.convertException(new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE")));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_PTT_SIGORTA_POLICE_PDF_INFO")
	public static GMMap methodName(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT_SIGORTA.get_police_pdf_info(?,?,?)}");

			int i = 1;

			stmt.setBigDecimal(++i, iMap.getBigDecimal("TALEP_NO"));
			stmt.registerOutParameter(++i, Types.NUMERIC);
			stmt.registerOutParameter(++i, Types.NUMERIC);
			stmt.execute();			
			
			BigDecimal islemNo = stmt.getBigDecimal(2);
			BigDecimal policeNo = stmt.getBigDecimal(3);

			oMap.put("ISLEM_NO", islemNo);
			oMap.put("POLICE_NO", policeNo);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("AKUSTIK_SIGORTA_URETIM_MUTABAKATI")
	public static GMMap getUretimMutabakat(GMMap iMap) {
		 
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        DateFormat DOB = new SimpleDateFormat("yyyyMMdd");

	        try {

	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_RC_SIGORTA.PTT_Uretim_Bilgileri(?)}");

	            int i = 0;
	            stmt.registerOutParameter(++i, -10); // ref cursor
	            stmt.setDate(++i, iMap.getString("TANZIM_TARIHI")==null ? null :  new java.sql.Date(DOB.parse(iMap.getString("TANZIM_TARIHI")).getTime()) );
	            stmt.execute();
	            
	            rSet = (ResultSet) stmt.getObject(1);
	            String tableName = "MUTABAKAT_SIGORTA_LIST";
 
	            return DALUtil.rSetResults(rSet, tableName);
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }

	}
}