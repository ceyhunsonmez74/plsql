package tr.com.aktifbank.bnspr.clks.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalElectronicFundTransferPaymentDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalForeignCurrencyTransferPaymentDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalReferencePaymentDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ElectronicFundTransferPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ForeignCurrencyTransferPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ReferencePayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.ElectronicFundTransferPaymentProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.ForeignCurrencyTransferPaymentProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.ReferencePaymentProcess;
import tr.com.aktifbank.bnspr.dao.ClksUptOdemeTx;
import tr.com.aktifbank.bnspr.dao.TuTransferTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CLKSReferencePayment {
	
	private static Logger logger = Logger.getLogger(CLKSReferencePayment.class);

	@GraymoundService("CLKS_REFERANSLI_ODEME_LISTESI")
	public static GMMap clksUPTList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		BigDecimal id = null;
		GMMap i2Map = new GMMap();
		
		String azerpostKurumKodu = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
				new GMMap().put("KOD", "CLKS_UPT_AZERPOST_BILGILERI").put("KEY", "KURUM_KODU"))
				.getString("TEXT");
				
		String azerpostUlkeKodu = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
				new GMMap().put("KOD", "CLKS_UPT_AZERPOST_BILGILERI").put("KEY", "ULKE_KODU"))
				.getString("TEXT");
		
		try {
			i2Map.put("TU_REFERANS", iMap.getString("referansSorguNo", ""));
			i2Map.put("GONDEREN_AD_SOYAD", iMap.getString("gonderenAdSoyadUnvan", ""));
			i2Map.put("ALICI_AD_SOYAD", iMap.getString("aliciAdSoyad", ""));

			if ("E".equals(DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K('G_TU_SORGU')}", Types.VARCHAR))) {
			    i2Map.putAll(GMServiceExecuter.call("CLKS_REFERENCE_PAYMENT_ISLEM_YERI_AL", iMap));
				i2Map.putAll(GMServiceExecuter.call("BNSPR_TU_GET_TRANSFER_INFO", i2Map));
				id = i2Map.getBigDecimal("ID");

				if (i2Map.get("TU_REFERANS") != null && !i2Map.getString("TU_REFERANS").isEmpty() && iMap.getString("referansSorguNo") != null && !iMap.getString("referansSorguNo").isEmpty()) {
					iMap.put("referansSorguNo", i2Map.getString("TU_REFERANS"));
				}
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_PTT_REFERANS_ODEME.GET_REFERENCE_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);

			stmt.setString(i++, iMap.getString("paraninGeldigiYer"));
			stmt.setString(i++, iMap.getString("dovizTuru"));
			stmt.setString(i++, iMap.getString("ps_arama_yontemi"));
			stmt.setString(i++, iMap.getString("referansSorguNo"));
			stmt.setString(i++, iMap.getString("aliciAdSoyad"));
			stmt.setString(i++, iMap.getString("gonderenAdSoyadUnvan"));
			stmt.setString(i++, iMap.getString("gonderenUlke"));
			stmt.setBigDecimal(i++, id);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setString(i++, iMap.getString("iadeOdeme"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap.put("EURUSDParite", stmt.getObject(13));
			oMap.put("USDKur", stmt.getObject(12));
			oMap.put("EURKur", stmt.getObject(11));
			oMap.put("EFT_OK_SAYISI", stmt.getObject(10));

			oMap = DALUtil.rSetResults(rSet, "islemListesi");

			if (oMap.getSize("islemListesi") == 0) {
				
				if (oMap.getInt("EFT_OK_SAYISI") == 1) {
					iMap.put("HATA_NO", 1660);
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				if (StringUtils.isNotBlank(iMap.getString("referansSorguNo"))) {
					iMap.put("HATA_NO", 2532);
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				if ((iMap.getString("iadeOdeme") == null || !iMap.getString("iadeOdeme").equalsIgnoreCase("e")) && StringUtils.isBlank(iMap.getString("referansSorguNo"))) {
					
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);

					stmt = conn.prepareCall("{? = call PKG_PTT_REFERANS_ODEME.iade_islemi_varmi(?,?,?,?,?,?,?,?)}");
					i = 1;

					stmt.registerOutParameter(i++, Types.VARCHAR);

					stmt.setString(i++, iMap.getString("paraninGeldigiYer"));
					stmt.setString(i++, iMap.getString("dovizTuru"));
					stmt.setString(i++, iMap.getString("ps_arama_yontemi"));
					stmt.setString(i++, iMap.getString("referansSorguNo"));
					stmt.setString(i++, iMap.getString("aliciAdSoyad"));
					stmt.setString(i++, iMap.getString("gonderenAdSoyadUnvan"));
					stmt.setString(i++, iMap.getString("gonderenUlke"));
					stmt.setBigDecimal(i++, id);

					stmt.execute();
					String sonuc = stmt.getString(1);

					if (sonuc != null && sonuc.equalsIgnoreCase("e")) {
						iMap.put("HATA_NO", 2541);
						GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
			}
			for(int r = 0; r < i2Map.getSize("TRANSFER_INFO_LIST"); r++){
				if (i2Map.getString("TRANSFER_INFO_LIST", r,"GONDEREN_KURUM_AB_MUS_NO").equals(azerpostKurumKodu)) {
					oMap.put("islemListesi", r, "gonderenBanka", azerpostUlkeKodu);	
				}
			}
//			if (!StringUtil.isEmpty(i2Map.getString("MASRAF"))) {
//				oMap.put("MASRAFDOVIZTUTAR", i2Map.getBigDecimal("MASRAF"));
//				oMap.put("MASRAFDOVIZCINSI", i2Map.getString("MASRAF_DOVIZ_CINSI"));	
//				for (int j = 0; j < i2Map.getSize("MASRAF_LIST"); j++) {
//					oMap.put("islemListesi",j,"MASRAFDOVIZTUTAR", i2Map.getBigDecimal("MASRAF_LIST",j,"MASRAF"));
//					oMap.put("islemListesi",j,"MASRAFDOVIZCINSI", i2Map.getString("MASRAF_LIST",j,"MASRAF_DOVIZ_CINSI"));	
//				}
//				
//			}
			return oMap;

		}
		catch (SQLException e) {
			logger.error("CLKS_REFERANSLI_ODEME_LISTESI err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_REFERENCE_REQUEST_SERVICES")
	public static GMMap clksReferenceRequestServices(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap o2Map = new GMMap();
		
		try {

			iMap.put("EKRAN_KODU", GMServiceExecuter.call("GET_EKRAN_KODU", iMap).get("EKRAN_KODU"));

			// Case: UPT Odeme
			if ("3552".equals(iMap.getString("EKRAN_KODU"))) {
				
				iMap.put("REFERANS", iMap.getString("referansNo"));
				iMap.put("VKNO", iMap.getString("aliciVKN"));
				iMap.putAll(GMServiceExecuter.call("CLKS_PTT_REFERANS_HAVALE_ODEME_TU", iMap)); // TRX_NO, REFERANS, ISLEM_SEKLI, GONDEREN_HESAP_NO, ODEME_SEKLI, ODENECEK_MUSTERI_NO, ODENECEK_HESAP_NO, ACIKLAMA, ISLEM_TARIHI, TUTAR, IBAN, MASRAF_TUTAR, MASRAF_TUTAR_PARAKOD
				oMap.put("TRX_NO", iMap.getString("TRX_NO"));

				iMap.put("TUTAR", iMap.getBigDecimal("tutar"));
				iMap.put("DOVIZ_KOD", iMap.getString("dovizKod"));

				if (iMap.getString("uptOdemeSekli").compareTo("2") == 0) {
					iMap.put("odemeninDovizTuru", "TRY");
				}

				iMap.put("SAVE", "1");
				if ("E".equals(iMap.getString("IADE"))) {
					// input:
					iMap.put("FX_MARJ_GELIRI", BigDecimal.ZERO);
					iMap.put("TU_ISLEM", "I");
				}
				else {
					// input:
					iMap.putAll(GMServiceExecuter.call("CLKS_REFERANS_ODEME_MARJ_GELIRI", iMap));
					iMap.put("TU_ISLEM", "O");
				}
				
				iMap.putAll(GMServiceExecuter.call("CLKS_REFERENNCE_PAYMENT_SAVE_OR_UPDATE", iMap));
				// output: N/A
				
				if (!iMap.getString("oncekiTxNo").isEmpty()) {
					/**
					 * TU odemesi ise onun requestini cagirilir.
					 * PTT �deme ekran�nda sorgula ile request servisi cagriliyor ve tx aliniyor.
					 * Onay asamasinda ise oncekiTxno dolu olarak hem Request hem confirm servisi cagriliyor
					 */
					GMMap tuInMap = new GMMap();
					tuInMap.put("TU_REFERANS", iMap.getString("referansNo"));
					tuInMap.put("BANKA_ISLEM_NO", iMap.getString("TRX_NO"));
							
					String[] alici_ad_soyad = iMap.getString("aliciAdSoyadUnvan").split(" ");	
					
					int size = alici_ad_soyad.length;
					
					final String re = Pattern.quote(iMap.getString("aliciTelefonUlkeKodu"));
					iMap.put("aliciTelefonNumarasi", iMap.getString("aliciTelefonNumarasi").replaceFirst(re, ""));
					iMap.put("aliciTelefonUlkeKodu", iMap.getString("aliciTelefonUlkeKodu").replaceAll("\\+", "00"));
					
					if (iMap.getString("aliciTelefonUlkeKodu").length() == 5) {
						iMap.put("aliciTelefonUlkeKodu", iMap.getString("aliciTelefonUlkeKodu").substring(1, 5));
					}
					
					tuInMap.put("ALICI_AD", iMap.getString("aliciAdSoyadUnvan").substring(0, iMap.getString("aliciAdSoyadUnvan").length() - alici_ad_soyad[size - 1].length()));
					tuInMap.put("ALICI_SOYAD", alici_ad_soyad[size - 1]);
					//tuInMap.put("ALICI_KIMLIK_TIP", iMap.getString("aliciKimlikTuru"));
					
					try {
						tuInMap.put("ALICI_KIMLIK_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "TU_CLKS_KIMLIK_MAP").put("KEY", iMap.getString("aliciKimlikTuru"))).get("TEXT"));
					}
					catch (Exception e) {
						tuInMap.put("ALICI_KIMLIK_TIP", "NCZ");
					}
					
					tuInMap.put("ALICI_KIMLIK_NO", iMap.getString("aliciKimlikNumarasi"));
					tuInMap.put("ALICI_DOGUM_YERI", iMap.getString("aliciDogumYeri"));
					tuInMap.put("ALICI_DOGUM_TARIHI", iMap.getString("aliciDogumTarihi"));					
					tuInMap.put("ALICI_CEPTEL", iMap.getString("aliciTelefonNumarasi"));
					tuInMap.put("ALICI_CEPTEL_ULKEKODU", iMap.getString("aliciTelefonUlkeKodu"));
					tuInMap.put("ALICI_ADRES", iMap.getString("aliciAdres"));
					tuInMap.put("ALICI_UYRUK", iMap.getString("aliciUyruk"));
					tuInMap.put("ALICI_VATANDASLIK_NO", iMap.getString("aliciVatandaslikNo"));
					tuInMap.put("ALICI_MESLEK", iMap.getString("aliciMeslek"));
					
					tuInMap.putAll(GMServiceExecuter.call("CLKS_REFERENCE_PAYMENT_ISLEM_YERI_AL", iMap));
					tuInMap.put("USER_ID", iMap.getString("kullaniciSicil"));
					tuInMap.put("USER_NAME", iMap.getString("kullaniciSicil"));

					if ("E".equals(iMap.getString("IADE"))) {
						GMServiceExecuter.call("BNSPR_TU_REFUND_PAYMENT_REQUEST", tuInMap);
					}
					else {
						GMServiceExecuter.call("BNSPR_TU_PAYMENT_REQUEST", tuInMap);
					}
				}
				
				try {
					oMap.putAll(GMServiceExecuter.call("TRUNION_TRANSACTION_IS_CORPORATION_POOL", iMap));
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				if (oMap.getBoolean("IsCorporationPool")) {
					iMap.put("fKurumIslem", "E");
				}
				else {
					iMap.put("fKurumIslem", "H");
				}

				GMServiceExecuter.execute("BNSPR_TRN3552_SAVE", iMap);

				iMap.put("ODEME_TUTAR_TL", iMap.getBigDecimal("odemeTutariTL"));/*TL tutarin YP karsiligi tabloda tutuluyor*/
				iMap.put("ODEME_KUR", iMap.getString("odemeKur"));

				// TODO: Masraf CLKS_REFERANSLI_ODEME_LISTESI servisi ile donuluyor, PTT Uygulamasinda kullanilmiyorsa bu parametrelerin
				// gonderilmesine gerek yok.
				oMap.put("masrafTutari", iMap.getBigDecimal("MASRAF_TUTAR"));
				oMap.put("masrafTL", iMap.getBigDecimal("MASRAF_TUTAR"));
				oMap.put("masrafYP", iMap.getBigDecimal("MASRAF_TUTAR"));
				oMap.put("musteriyeOdenecekTutarYP", iMap.getBigDecimal("odemeTutariYP"));
				oMap.put("musteriyeOdenecekTutarTL", iMap.getBigDecimal("ODEME_TUTAR_TL").multiply(iMap.getBigDecimal("ODEME_KUR")).subtract(oMap.getBigDecimal("masrafTL")).setScale(2, BigDecimal.ROUND_HALF_UP));
				oMap.put("havaleTutari", iMap.getBigDecimal("tutar"));
				oMap.put("IBAN", iMap.getString("IBAN"));
				oMap.put("kur", iMap.getBigDecimal("ODEME_KUR"));
				oMap.put("kur_geliri", iMap.getBigDecimal("FX_MARJ_GELIRI"));
				
				oMap.put("referansSorguNo", iMap.getString("referansNo"));
				
			}

			// Case: Havale/Swift Odeme
			else {

				iMap.put("REFERANS", iMap.getString("referansNo"));
				iMap.put("VKNO", iMap.getString("aliciVKN"));

				// input: REFERANS, VKNO
				iMap.putAll(GMServiceExecuter.call("CLKS_PTT_REFERANS_HAVALE_ODEME", iMap));
				// output: TRX_NO, REFERANS, ISLEM_SEKLI, GONDEREN_HESAP_NO, ODEME_SEKLI, ODENECEK_MUSTERI_NO, ODENECEK_HESAP_NO, ACIKLAMA,
				// ISLEM_TARIHI, DURUM_KODU, TUTAR, IBAN
				// clks_havale_odeme_tx tablosuna cari_subelerarasi_hav_giris tablosundaki bilgiler yaziliyor

				GMMap s2Map = new GMMap();
				s2Map.put("REFERANS", iMap.getString("referansNo"));

				// input: REFERANS
				GMMap o1Map = new GMMap();
				o1Map.putAll(GMServiceExecuter.call("CLKS_PTT_REFERANS_DETAY_BILGI", s2Map));
				iMap.put("MUSTERI_NO", o1Map.getString("MUSTERI_NO"));
				iMap.put("MASRAF_ALINACAKMI", o1Map.getString("MASRAF_ALINACAKMI"));
				// output: TUTAR, MUSTERI_NO, MASRAF_ALINACAKMI

				// 3 = SWIFT
				// 2 = Aktifbank'tan Referansli Odeme
				if (iMap.getString("islem").compareTo("3") == 0 || iMap.getString("islem").compareTo("2") == 0) {
					if ("USD".compareTo(iMap.getString("dovizKod")) == 0) {
						iMap.put("EKRAN_KODU", "20321");
					}
					else if ("EUR".compareTo(iMap.getString("dovizKod")) == 0) {
						iMap.put("EKRAN_KODU", "20323");
					}
				}

				iMap.put("TUTAR", iMap.getBigDecimal("tutar"));
				iMap.put("DOVIZ_KOD", iMap.getString("dovizKod"));
				iMap.put("ODEME_DOVIZ_KODU", iMap.get("odemeninDovizTuru"));
				
				if (iMap.getString("MASRAF_ALINACAKMI").compareTo("E") == 0 || iMap.getString("islem").compareTo("1") == 0) {
					o2Map.putAll(GMServiceExecuter.call("INTERNET_HAVALE_EFT_MASRAF_HESAPLA", iMap));
				}

				iMap.put("masrafTutari", o2Map.getBigDecimal("TOPLAM_MASRAF", BigDecimal.ZERO).add(o2Map.getBigDecimal("TOPLAM_BSMV", BigDecimal.ZERO)));
				oMap.put("TRX_NO", iMap.getString("TRX_NO"));
				oMap.put("masrafTutari", iMap.get("masrafTutari"));

				if (iMap.getString("uptOdemeSekli").compareTo("2") == 0) {
					iMap.put("odemeninDovizTuru", "TRY");
				}

				if (iMap.getString("odemeTutariYP") == null || iMap.getString("odemeTutariYP").length() == 0) {
					iMap.put("odemeTutariYP", new BigDecimal(0));
				}
				iMap.put("ODEME_TUTAR", iMap.getString("odemeTutariYP"));

				if (iMap.getString("odemeTutariTL") == null || iMap.getString("odemeTutariTL").length() == 0) {
					iMap.put("odemeTutariTL", new BigDecimal(0));
				}

				iMap.put("ODEME_TUTAR_TL", iMap.getBigDecimal("odemeTutariTL"));/*TL tutar�n YP karsili�i tabloda tutuluyor*/
				iMap.put("ODEME_KUR", iMap.getString("odemeKur"));
				iMap.put("MASRAF_ODEME_DOVIZ_KODU", iMap.getString("masrafinOdemeSekli"));
				iMap.put("REFERANS", iMap.getString("referansNo"));
				iMap.put("SAVE", "1");

				oMap.put("referansSorguNo", iMap.getString("referansNo"));
				
				iMap.putAll(GMServiceExecuter.call("CLKS_REFERANS_ODEME_MARJ_GELIRI", iMap));
				
				oMap.putAll(GMServiceExecuter.call("CLKS_REFERENNCE_PAYMENT_SAVE_OR_UPDATE", iMap));

				// TODO: Masraf CLKS_REFERANSLI_ODEME_LISTESI servisi ile donuluyor, PTT Uygulamasinda kullanilmiyorsa bu parametrelerin
				// gonderilmesine gerek yok.
				oMap.put("masrafTL", iMap.getBigDecimal("masrafTutari").multiply(iMap.getBigDecimal("ODEME_KUR")).setScale(2, BigDecimal.ROUND_HALF_UP));
				oMap.put("masrafYP", iMap.getBigDecimal("masrafTutari"));
				oMap.put("musteriyeOdenecekTutarYP", iMap.getBigDecimal("odemeTutariYP"));
				oMap.put("musteriyeOdenecekTutarTL", iMap.getBigDecimal("ODEME_TUTAR_TL").multiply(iMap.getBigDecimal("ODEME_KUR")).subtract(oMap.getBigDecimal("masrafTL")).setScale(2, BigDecimal.ROUND_HALF_UP));

				/*cari_subelerarasi_hav_odeme_tx icin duzenleme*/
				if ("TRY".equals(iMap.getString("ODEME_DOVIZ_KODU"))) {
					iMap.put("ODEME_TUTAR", iMap.getBigDecimal("TUTAR"));
					iMap.put("ODEME_TUTAR_TL", new BigDecimal(0));
				}
				GMServiceExecuter.execute("BNSPR_TRN2032_SAVE_SUBELERARASI_HAVALE_IPTAL_IADE_ODEME", iMap);

				oMap.put("havaleTutari", iMap.getBigDecimal("tutar"));
				oMap.put("IBAN", iMap.getString("IBAN"));
				oMap.put("kur", iMap.getBigDecimal("ODEME_KUR"));
				oMap.put("kur_geliri", iMap.getBigDecimal("FX_MARJ_GELIRI"));
			}
			
			oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_ptt_referans_odeme.transfer_komisyon_bilgileri(?,?)}", "TRANSFER_KOMISYON", BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"), BnsprType.NUMBER, iMap.getBigDecimal("EKRAN_KODU")));
			oMap.put("TRANSFER_TX_NO", oMap.get("TRANSFER_KOMISYON", 0, "TRANSFER_TX_NO"));
			oMap.put("KOMISYON_TUTAR", oMap.get("TRANSFER_KOMISYON", 0, "KOMISYON_TUTAR"));
			oMap.put("KOMISYON_DOVIZ", oMap.get("TRANSFER_KOMISYON", 0, "KOMISYON_DOVIZ"));

			return oMap;
		}
		catch (Exception e) {
			
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("CLKS_REFERANS_ODEME_MARJ_GELIRI")
	public static GMMap clksReferencePaymentMarj(GMMap iMap) {

		GMMap oMap = new GMMap();
		BigDecimal fxMarjGeliri = new BigDecimal("0.0");
		BigDecimal marjsizKur = new BigDecimal("0.0");
		try {
			if("USD".equals(iMap.getString("dovizKod"))) {
				marjsizKur = iMap.getBigDecimal("MARJSIZ_USD_KUR");  //5.7906
			}else 	if("EUR".equals(iMap.getString("dovizKod"))) {
				marjsizKur = iMap.getBigDecimal("MARJSIZ_EUR_KUR");
			}
			if (marjsizKur.compareTo(new BigDecimal ("0.0")) !=0){
				BigDecimal toplamTutar = iMap.getBigDecimal("tutar");
				BigDecimal dovizOdeme = iMap.getBigDecimal("odemeTutariYP");
				BigDecimal tlOdeme = iMap.getBigDecimal("odemeTutariTL");
				fxMarjGeliri = ((toplamTutar.multiply(marjsizKur))).subtract((dovizOdeme.multiply(marjsizKur)).add(tlOdeme));
			}

			oMap.put("FX_MARJ_GELIRI", fxMarjGeliri);
		}catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("CLKS_REFERENCE_CONFIRM_SERVICES")
	public static GMMap clksReferenceConfirmServices(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

			iMap.put("SAVE", "2");
			oMap.putAll(GMServiceExecuter.call("CLKS_REFERENNCE_PAYMENT_SAVE_OR_UPDATE", iMap));
			iMap.put("ISLEM_TURU", "O");
			iMap.put("ISLEM_NO", iMap.getString("TRX_NO"));
			
			if ("4".equals(iMap.getString("islem")) || "3".equals(iMap.getString("islem"))) {
				TransactionDao<ForeignCurrencyTransferPayment> dao = new DalForeignCurrencyTransferPaymentDao();
				ForeignCurrencyTransferPayment payment = dao.get(iMap.getBigDecimal("TRX_NO"));

				TransactionProcess<ForeignCurrencyTransferPayment> process = new ForeignCurrencyTransferPaymentProcess(
					dao);
		    	process.confirm(payment);
			} else {
				TransactionDao<ReferencePayment> dao = new DalReferencePaymentDao();
				ReferencePayment payment = dao.get(iMap.getBigDecimal("TRX_NO"));
		    	
		    	TransactionProcess<ReferencePayment> process = new ReferencePaymentProcess(dao);
		    	process.confirm(payment);
			}
			
			// TU odemesi ise onun confirmi cagirilir. hata alsa bile isleme devam etsin
			if ("4".equals(iMap.getString("islem"))) {
				GMMap tuInMap = new GMMap();

				String tuRef = GMServiceExecuter.call("GET_TU_REFERENCE", iMap).getString("TU_REF");

				tuInMap.put("TU_REFERANS", tuRef);
				tuInMap.put("BANKA_ISLEM_NO", iMap.getString("TRX_NO"));
				tuInMap.putAll(GMServiceExecuter.call("CLKS_REFERENCE_PAYMENT_ISLEM_YERI_AL", oMap));
				tuInMap.put("USER_ID", oMap.getString("USER_ID"));
				tuInMap.put("USER_NAME", oMap.getString("USER_NAME"));
				try {
					tuInMap.put("ALICI_KIMLIK_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "TU_CLKS_KIMLIK_MAP").put("KEY", oMap.getString("ALICI_KIMLIK_TIPI"))).get("TEXT"));
				}
				catch (Exception e) {
					tuInMap.put("ALICI_KIMLIK_TIP", "NCZ");
				}

				tuInMap.put("ALICI_KIMLIK_NO", oMap.getString("ALICI_KIMLIK_NO"));
				tuInMap.put("ALICI_DOGUM_TARIHI", oMap.getString("ALICI_DOGUM_TARIHI"));
				tuInMap.put("ALICI_DOGUM_YERI", oMap.getString("ALICI_DOGUM_YERI"));
				tuInMap.put("ALICI_CEPTEL", oMap.getString("ALICI_CEPTEL"));
				tuInMap.put("ALICI_CEPTEL_ULKEKODU", oMap.getString("ALICI_CEPTEL_ULKEKODU"));
				tuInMap.putAll(GMServiceExecuter.call("GET_TU_IADE_MI", tuInMap));
				if ("E".equals(tuInMap.getString("IADE")))
					GMServiceExecuter.call("BNSPR_TU_REFUND_PAYMENT_CONFIRM", tuInMap);
				else
					GMServiceExecuter.call("BNSPR_TU_PAYMENT_REQUEST_CONFIRM", tuInMap);
			}

			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap);

			return oMap;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_REFERENNCE_PAYMENT_SAVE_OR_UPDATE")
	public static GMMap ReferencePaymentSaveorUpdate(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			ClksHavaleOdemeTx clksHavaleOdemeTx = (ClksHavaleOdemeTx) session.get(ClksHavaleOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (clksHavaleOdemeTx == null)
				clksHavaleOdemeTx = new ClksHavaleOdemeTx();

			clksHavaleOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));

			if (iMap.getString("SAVE").compareTo("1") == 0) {

				clksHavaleOdemeTx.setIslem(iMap.getBigDecimal("islem"));
				clksHavaleOdemeTx.setAliciUyruk(iMap.getString("uyruk"));
				clksHavaleOdemeTx.setAliciTckno(iMap.getString("aliciTCKimlikNo"));
				clksHavaleOdemeTx.setAliciVkn(iMap.getString("aliciVKN"));
				clksHavaleOdemeTx.setAliciBabaadi(iMap.getString("aliciBabaAdi"));
				if (iMap.get("aliciDogumTarihi") != null && iMap.getString("aliciDogumTarihi").compareTo("") != 0) {
					clksHavaleOdemeTx.setAliciDogumTarihi(iMap.getDate("aliciDogumTarihi"));
				}
				else {
					clksHavaleOdemeTx.setAliciDogumTarihi(null);
				}
				clksHavaleOdemeTx.setAliciTelefon(iMap.getString("aliciTelefonNumarasi"));
				clksHavaleOdemeTx.setAliciTelefonUlkeKodu(iMap.getString("aliciTelefonUlkeKodu"));
				clksHavaleOdemeTx.setAliciAdres(iMap.getString("aliciAdres"));
				clksHavaleOdemeTx.setAliciKimlikTuru(iMap.getString("aliciKimlikTuru"));
				clksHavaleOdemeTx.setAliciAnneadi(iMap.getString("aliciAnneAdi"));
				clksHavaleOdemeTx.setAliciDogumYeri(iMap.getString("aliciDogumYeri"));
				clksHavaleOdemeTx.setOdemeninDovizTuru(iMap.getString("odemeninDovizTuru"));
				clksHavaleOdemeTx.setMasrafTahsilDoviz(iMap.getString("masrafinOdemeSekli"));
				clksHavaleOdemeTx.setIsleminYapildigiYer(iMap.getString("isleminYeri"));
				clksHavaleOdemeTx.setIsleminYapildigiIl(iMap.getString("isleminYapildigiIl"));
				clksHavaleOdemeTx.setIslemiYapanKullanici(iMap.getString("kullaniciSicil"));
				clksHavaleOdemeTx.setReferansNo(iMap.getString("referansNo"));
				clksHavaleOdemeTx.setTutar(iMap.getBigDecimal("tutar"));
				clksHavaleOdemeTx.setDovizKodu(iMap.getString("dovizKod"));
				// clksHavaleOdemeTx.setIslemSekli("CLKSRODE");
				clksHavaleOdemeTx.setIslemTarihi(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
				clksHavaleOdemeTx.setMasrafTutari(iMap.getBigDecimal("masrafTutari"));
				clksHavaleOdemeTx.setDurumKodu("A");
				clksHavaleOdemeTx.setAliciAdSoyad(iMap.getString("aliciAdSoyadUnvan"));
				clksHavaleOdemeTx.setKpsYapildimi(iMap.getString("KPSYapildimi"));
				clksHavaleOdemeTx.setAliciKimlikNumarasi(iMap.getString("aliciKimlikNumarasi"));
				clksHavaleOdemeTx.setAliciMeslek(iMap.getString("aliciMeslek"));

				clksHavaleOdemeTx.setOdemeTutari(iMap.getBigDecimal("odemeTutariYP"));
				clksHavaleOdemeTx.setOdemeTutariTl(iMap.getBigDecimal("odemeTutariTL"));
				clksHavaleOdemeTx.setOdemeKur(iMap.getBigDecimal("odemeKur"));
				if("USD".equals(iMap.getString("dovizKod"))) {
					clksHavaleOdemeTx.setUsdKur(iMap.getBigDecimal("odemeKur"));
					clksHavaleOdemeTx.setUsdMarjsizKur(iMap.getBigDecimal("MARJSIZ_USD_KUR"));
					
				} else if("EUR".equals(iMap.getString("dovizKod"))) {
					clksHavaleOdemeTx.setEurKur(iMap.getBigDecimal("odemeKur"));
					clksHavaleOdemeTx.setEurMarjsizKur(iMap.getBigDecimal("MARJSIZ_EUR_KUR"));
				}
				clksHavaleOdemeTx.setOncekiTxno(iMap.getBigDecimal("oncekiTxNo"));
				clksHavaleOdemeTx.setOdemeSekli(iMap.getString("uptOdemeSekli"));
				clksHavaleOdemeTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
				clksHavaleOdemeTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
				clksHavaleOdemeTx.setMerkezSubebasMudurluk(iMap.getString("MERKEZ_SUBE_BASMUDURLUK"));
				clksHavaleOdemeTx.setIsleminYapildigiBasMudurluk(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				clksHavaleOdemeTx.setIslemiYapanKullAdsoyad(iMap.getString("ISLEMI_YAPAN_KULLANICI_ADSOYAD"));
				clksHavaleOdemeTx.setFxMarjGeliri(iMap.getBigDecimal("FX_MARJ_GELIRI"));
				
				oMap.put("gonderenAdSoyadUnvan", clksHavaleOdemeTx.getGonderenAdSoyad());

			}

			if (iMap.getString("SAVE").compareTo("2") == 0) {
				clksHavaleOdemeTx.setPttIslemNo(iMap.getBigDecimal("islemNoPTT"));

				oMap.put("ALICI_KIMLIK_TIPI", clksHavaleOdemeTx.getAliciKimlikTuru());
				oMap.put("ALICI_KIMLIK_NO", clksHavaleOdemeTx.getAliciKimlikNumarasi());
				oMap.put("ALICI_DOGUM_TARIHI", clksHavaleOdemeTx.getAliciDogumTarihi());
				oMap.put("ALICI_DOGUM_YERI", clksHavaleOdemeTx.getAliciDogumYeri());
				oMap.put("ALICI_CEPTEL", clksHavaleOdemeTx.getAliciTelefon().substring(clksHavaleOdemeTx.getAliciTelefonUlkeKodu().length()));
				oMap.put("ALICI_CEPTEL_ULKEKODU", clksHavaleOdemeTx.getAliciTelefonUlkeKodu().replace("+", "00"));
				oMap.put("ISLEMIN_YAPILDIGI_BASMUDURLUK", clksHavaleOdemeTx.getIsleminYapildigiBasMudurluk());
				oMap.put("ISLEMIN_YAPILDIGI_MERKEZ", clksHavaleOdemeTx.getIsleminYapildigiMerkez());
				oMap.put("ISLEMIN_YAPILDIGI_SUBE", clksHavaleOdemeTx.getIsleminYapildigiSube());
				oMap.put("USER_ID", clksHavaleOdemeTx.getIslemiYapanKullanici());
				oMap.put("USER_NAME", clksHavaleOdemeTx.getIslemiYapanKullanici());
			}
			session.saveOrUpdate(clksHavaleOdemeTx);
			session.flush();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("GET_TU_REFERENCE")
	public static GMMap getTuReference(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal tx = iMap.getBigDecimal("TRX_NO");
		Connection conn = null;
		CallableStatement stmt = null;
		String tuRef = "";
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_tu.f_islem_tu_referans_bul(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, tx);
			stmt.execute();
			tuRef = stmt.getString(1);
			oMap.put("TU_REF", tuRef);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
		return oMap;

	}

	@GraymoundService("CLKS_UPT_SAVE_OR_UPDATE_NEW")
	public static GMMap uptSaveorUpdate(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap i2Map = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			ClksUptOdemeTx clksUptOdemeTx = (ClksUptOdemeTx) session.get(ClksUptOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (clksUptOdemeTx == null)
				clksUptOdemeTx = new ClksUptOdemeTx();

			clksUptOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));

			if (iMap.getString("SAVE").compareTo("1") == 0) {

				clksUptOdemeTx.setEftEftTxNo(iMap.getBigDecimal("EFTTxNo"));
				clksUptOdemeTx.setTutar(iMap.getBigDecimal("tutar"));
				clksUptOdemeTx.setDovizKod(iMap.getString("tutarDovizKodu"));
				clksUptOdemeTx.setIslemYeri(iMap.getString("islemYeri"));
				clksUptOdemeTx.setKullaniciSicil(iMap.getString("kullaniciSicil"));
				clksUptOdemeTx.setIslemDurum("C");
				clksUptOdemeTx.setIslemTarihi(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
				clksUptOdemeTx.setMasrafTutari(iMap.getBigDecimal("masrafTutari"));
				clksUptOdemeTx.setAliciTelefonNumarasi(iMap.getBigDecimal("aliciTelefonNumarasi"));
				clksUptOdemeTx.setAliciAdres(iMap.getString("aliciAdres"));

				if (iMap.get("aliciDogumTarihi") != null && !"null".equals(iMap.getString("aliciDogumTarihi")) && iMap.getString("aliciDogumTarihi").length() != 0)
					clksUptOdemeTx.setAliciDogumTarihi(iMap.getDate("aliciDogumTarihi"));
				else
					clksUptOdemeTx.setAliciDogumTarihi(null);

				clksUptOdemeTx.setAliciBabaAdi(iMap.getString("aliciBabaAdi"));
				clksUptOdemeTx.setAliciAnneAdi(iMap.getString("aliciAnneAdi"));
				clksUptOdemeTx.setAliciDogumYeri(iMap.getString("aliciDogumYeri"));
				// clksUptOdemeTx.setAliciAdsoyad(iMap.getString("aliciAdSoyad"));

				if (iMap.get("aliciTCKimlikNo") != null && !"null".equals(iMap.getString("aliciTCKimlikNo")) && iMap.getString("aliciTCKimlikNo").length() != 0) {
					clksUptOdemeTx.setTcknVkn(iMap.getString("aliciTCKimlikNo"));
				}
				else {
					if ("1".equals(iMap.getString("uyruk"))) {
						clksUptOdemeTx.setTcknVkn(iMap.getString("aliciVKN"));
					}
					else {
						iMap.put("HATA_NO", "330");
						iMap.put("P1", "Al�c� TC Kimlik No");
						return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}

				clksUptOdemeTx.setKpsYapildimi(iMap.getString("KPSYapildimi"));
				clksUptOdemeTx.setAliciUyruk(iMap.getString("uyruk"));
				clksUptOdemeTx.setAlicininKimlikTuru(iMap.getString("aliciKimlikTuru"));
				clksUptOdemeTx.setAliciKimlikbelgeNumarasi(iMap.getString("aliciKimlikNumarasi"));
				clksUptOdemeTx.setAliciAdsoyad(iMap.getString("aliciAdSoyadUnvan"));

				clksUptOdemeTx.setIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
				clksUptOdemeTx.setIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
				clksUptOdemeTx.setMerkezSubeBasmudurluk(iMap.getString("MERKEZ_SUBE_BASMUDURLUK"));
				clksUptOdemeTx.setIsleminYapildigiBasmudurluk(iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK"));
				clksUptOdemeTx.setIslemiYapanKullAdsoyad(iMap.getString("ISLEMI_YAPAN_KULLANICI_ADSOYAD"));

				session.saveOrUpdate(clksUptOdemeTx);
				session.flush();

				i2Map.put("TRX_NAME", "2317");
				i2Map.put("TRX_NO", iMap.getBigDecimal("EFTTxNo"));
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", i2Map);
			}

			if (iMap.getString("SAVE").compareTo("2") == 0) {

				clksUptOdemeTx.setIslemDurum("P");
				clksUptOdemeTx.setIslemNoPtt(iMap.getBigDecimal("islemNoPTT"));

				session.saveOrUpdate(clksUptOdemeTx);
				session.flush();

				oMap.put("EFT_EFT_TX_NO", clksUptOdemeTx.getEftEftTxNo());
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("CLKS_UPT_REQUEST_SERVICES_NEW")
	public static GMMap clksUptRequestServices(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();

		GMMap o2Map = new GMMap();
		GMMap o3Map = new GMMap();
		GMMap oMasraf = new GMMap();
		try {

			iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO")); // TRX_NO alindi

			iMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_LC_KOD", new GMMap()));

			iMap.put("tutarDovizKodu", iMap.getString("LC_KOD"));
			oMap.put("TRX_NO", iMap.getString("TRX_NO"));
			iMap.put("EKRAN_KODU", "2317");
			iMap.put("TUTAR", iMap.getBigDecimal("tutar"));
			iMap.put("DOVIZ_KOD", iMap.getString("dovizKod"));

			oMasraf.putAll(GMServiceExecuter.call("UPT_MASRAFSIZMI", iMap));
			if ("E".equals(oMasraf.getString("MASRAF_EH"))) {
				o3Map.put("masrafTutari", BigDecimal.ZERO);
			}
			else {
				o2Map.putAll(GMServiceExecuter.call("INTERNET_HAVALE_EFT_MASRAF_HESAPLA", iMap));
				o3Map.put("masrafTutari", o2Map.getBigDecimal("TOPLAM_MASRAF", BigDecimal.ZERO).add(o2Map.getBigDecimal("TOPLAM_BSMV", BigDecimal.ZERO)));
			}

			iMap.putAll(o3Map);
			oMap.putAll(o3Map);
			oMap.put("referansSorguNo", iMap.getString("referansNo"));
			oMap.put("kur", "1");
			oMap.put("musteriyeOdenecekTutarTL"/*"musteriyeOdenecekTutar"*/, iMap.getBigDecimal("tutar").subtract(iMap.getBigDecimal("masrafTutari")));
			oMap.put("havaleTutari", iMap.getBigDecimal("tutar"));
			oMap.put("masrafTL"/*"masraf"*/, iMap.getBigDecimal("masrafTutari"));

			oMap.putAll(GMServiceExecuter.call("CLKS_UPT_SAVE_OR_UPDATE_NEW", iMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("CLKS_UPT_CONFIRM_SERVICES_NEW")
	public static GMMap clksUptConfirmServices(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			
			TransactionDao<ElectronicFundTransferPayment> dao = new DalElectronicFundTransferPaymentDao();
			ElectronicFundTransferPayment payment = dao.get(iMap.getBigDecimal("islemNo"));
	    	
	    	TransactionProcess<ElectronicFundTransferPayment> process = new ElectronicFundTransferPaymentProcess(dao);
	    	process.confirm(payment);
			
			iMap.put("TRX_NO", iMap.getBigDecimal("islemNo"));
			oMap.putAll(GMServiceExecuter.call("CLKS_UPT_SAVE_OR_UPDATE_NEW", iMap));
			// iMap.put("ISLEM_NO", oMap.getBigDecimal("EFT_EFT_TX_NO"));
			iMap.put("ISLEM_NO", iMap.getBigDecimal("islemNo"));
			iMap.put("ISLEM_TURU", "O");
			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * CLKS_PTT_REFERANS_HAVALE_ODEME_TU:
	 * bnspr.clks_havale_odeme_tx tablosuna bnspr.tu_odeme_list tablosundaki bilgiler yaziliyor.
	 * 
	 * @param iMap
	 *            GMMap
	 * @return
	 */
	@GraymoundService("CLKS_PTT_REFERANS_HAVALE_ODEME_TU")
	public static GMMap pttReferansHavaleOdemeTU(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetMSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_PTT_REFERANS_ODEME.referansla_havale_odeme_tu(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.setString(i++, iMap.getString("TCNO"));
			stmt.setString(i++, iMap.getString("VKNO"));
			stmt.execute();

			rSetMSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSetMSet);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_TRN3552_SAVE")
	public static Map<?, ?> saveTUHavaleOdeme(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			TuTransferTx tuTransferTx = new TuTransferTx();
			tuTransferTx.setTxNo(GuimlUtil.getTableCellBigDecimal(iMap.get("TRX_NO")));
			tuTransferTx.setTuReferans(iMap.getString("REFERANS"));
			tuTransferTx.setIslem(iMap.getString("TU_ISLEM"));
			tuTransferTx.setGonParakod(iMap.getString("DOVIZ_KOD"));
			tuTransferTx.setGonTutar(iMap.getBigDecimal("TUTAR"));
			tuTransferTx.setAliciAdsoyad(iMap.getString("aliciAdSoyadUnvan"));
			tuTransferTx.setGonderenAdsoyad(iMap.getString("gonderenAdSoyadUnvan"));
			// tuTransferTx.setKurumKod("");
			// tuTransferTx.setKurumHesap("");
			// tuTransferTx.setKurumMasHesap("");
			tuTransferTx.setMasraf(iMap.getBigDecimal("masraf_tutar"));
			tuTransferTx.setMasrafParakod(iMap.getString("masraf_tutar_parakod"));
			tuTransferTx.setfKurumIslem(iMap.getString("fKurumIslem"));

			session.saveOrUpdate(tuTransferTx);
			session.flush();
			iMap.put("TRX_NAME", "3552");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("UPT_MASRAFSIZMI")
	public static GMMap getMasrafEH(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call  PKG_PFT.UPT_Masraf_Alinacakmi(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setString(i++, iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
			stmt.execute();
			oMap.put("MASRAF_EH", stmt.getString(1));
			return oMap;
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}

	@GraymoundService("GET_EKRAN_KODU")
	public static GMMap getEkranKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String ekranKodu = "";
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_PTT_REFERANS_ODEME.Get_Islem_Kodu(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setString(i++, iMap.getString("referansNo"));
			stmt.execute();
			ekranKodu = stmt.getString(1);
			oMap.put("EKRAN_KODU", ekranKodu);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
		return oMap;
	}

	@GraymoundService("GET_TU_IADE_MI")
	public static GMMap iadeMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_PTT_REFERANS_ODEME.Get_TU_Iade_Mi(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setString(i++, iMap.getString("TU_REFERANS"));
			stmt.execute();

			oMap.put("IADE", stmt.getString(1));
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
		return oMap;

	}

	@GraymoundService("CLKS_REFERENCE_PAYMENT_ALAN_BILGI")
	public static GMMap getClksReferencePaymentAlanBilgi(GMMap iMap) {

		GMMap oMap = new GMMap();
		int row = 0;
		int i = 0;
		try {

			String funcStr = "{? = call pkg_kur.DSK_to_LC(?,?)}";
			Object[] input0Values = new Object[4];
			input0Values[i++] = BnsprType.STRING;
			input0Values[i++] = "USD";
			input0Values[i++] = BnsprType.NUMBER;
			input0Values[i++] = new BigDecimal(1);
			BigDecimal usdKur = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, input0Values);
			i = 0;
			input0Values[i++] = BnsprType.STRING;
			input0Values[i++] = "EUR";
			input0Values[i++] = BnsprType.NUMBER;
			input0Values[i++] = new BigDecimal(1);
			BigDecimal eurKur = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, input0Values);
			i = 0;

			funcStr = "{? = call pkg_parametre.deger_al_k_n(?)}";
			Object[] inputValues = new Object[2];

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "PTT_TRANSFER_VKN_YKN_LIMIT";
			BigDecimal PTT_TRANSFER_VKN_YKN_LIMIT = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
			i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "PTT_TRANSFER_ADRES_LIMIT";
			BigDecimal PTT_TRANSFER_ADRES_LIMIT = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
			i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "PTT_TRANSFER_BABA_ADI_LIMIT";
			BigDecimal PTT_TRANSFER_BABA_ADI_LIMIT = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);
			i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "PTT_TRANSFER_ANNE_ADI_LIMIT";
			BigDecimal PTT_TRANSFER_ANNE_ADI_LIMIT = (BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, inputValues);

			String tableName = "ALICI_BILGI_LIST";

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_TCKN")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", ("0".equals(iMap.getString("ALICI_UYRUK"))) ? "1" : "0");
			oMap.put(tableName, row, "ZORUNLULUK", ("0".equals(iMap.getString("ALICI_UYRUK"))) ? "1" : "0");

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_VKN_YKN")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", ("0".equals(iMap.getString("ALICI_UYRUK"))) ? "0" : "1");
			oMap.put(tableName, row, "ZORUNLULUK", "0");
			if (!"0".equals(iMap.getString("ALICI_UYRUK"))) {

				if ("G".equals(iMap.getString("ALICI_KIMLIK_TIPI"))) {
					oMap.put(tableName, row, "ZORUNLULUK", "1");
				}
				else {

					if ("TRY".equals(iMap.getString("DOVIZ_KODU"))) {
						if (PTT_TRANSFER_VKN_YKN_LIMIT.compareTo(iMap.getBigDecimal("TUTAR")) == -1) {
							oMap.put(tableName, row, "ZORUNLULUK", "1");
						}
					}
					else if ("EUR".equals(iMap.getString("DOVIZ_KODU"))) {
						if (PTT_TRANSFER_VKN_YKN_LIMIT.compareTo(iMap.getBigDecimal("TUTAR").multiply(eurKur)) == -1) {
							oMap.put(tableName, row, "ZORUNLULUK", "1");
						}
					}
					else if ("USD".equals(iMap.getString("DOVIZ_KODU"))) {
						if (PTT_TRANSFER_VKN_YKN_LIMIT.compareTo(iMap.getBigDecimal("TUTAR").multiply(usdKur)) == -1) {
							oMap.put(tableName, row, "ZORUNLULUK", "1");
						}
					}
				}
			}

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_AD_SOYAD")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_DOGUM_YERI")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_DOGUM_TARIHI")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_KIMLIK_TURU")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_KIMLIK_NO")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_ADRES")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "0");
			if ("TRY".equals(iMap.getString("DOVIZ_KODU"))) {
				if (PTT_TRANSFER_ADRES_LIMIT.compareTo(iMap.getBigDecimal("TUTAR")) == -1) {
					oMap.put(tableName, row, "ZORUNLULUK", "1");
				}
			}
			else if ("EUR".equals(iMap.getString("DOVIZ_KODU"))) {
				if (PTT_TRANSFER_ADRES_LIMIT.compareTo(iMap.getBigDecimal("TUTAR").multiply(eurKur)) == -1) {
					oMap.put(tableName, row, "ZORUNLULUK", "1");
				}
			}
			else if ("USD".equals(iMap.getString("DOVIZ_KODU"))) {
				if (PTT_TRANSFER_ADRES_LIMIT.compareTo(iMap.getBigDecimal("TUTAR").multiply(usdKur)) == -1) {
					oMap.put(tableName, row, "ZORUNLULUK", "1");
				}
			}

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_ANNE_ADI")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "0");
			oMap.put(tableName, row, "ZORUNLULUK", "0");
			if ("0".equals(iMap.getString("ALICI_UYRUK"))) {

				if ("TRY".equals(iMap.getString("DOVIZ_KODU"))) {
					if (PTT_TRANSFER_ANNE_ADI_LIMIT.compareTo(iMap.getBigDecimal("TUTAR")) == -1) {
						oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
					}
				}
				else if ("EUR".equals(iMap.getString("DOVIZ_KODU"))) {
					if (PTT_TRANSFER_ANNE_ADI_LIMIT.compareTo(iMap.getBigDecimal("TUTAR").multiply(eurKur)) == -1) {
						oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
					}
				}
				else if ("USD".equals(iMap.getString("DOVIZ_KODU"))) {
					if (PTT_TRANSFER_ANNE_ADI_LIMIT.compareTo(iMap.getBigDecimal("TUTAR").multiply(usdKur)) == -1) {
						oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
					}
				}
			}

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_BABA_ADI")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_DEKONT", "0");
			if ("0".equals(iMap.getString("ALICI_UYRUK"))) {

				if ("TRY".equals(iMap.getString("DOVIZ_KODU"))) {
					if (PTT_TRANSFER_BABA_ADI_LIMIT.compareTo(iMap.getBigDecimal("TUTAR")) == -1) {
						oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
					}
				}
				else if ("EUR".equals(iMap.getString("DOVIZ_KODU"))) {
					if (PTT_TRANSFER_BABA_ADI_LIMIT.compareTo(iMap.getBigDecimal("TUTAR").multiply(eurKur)) == -1) {
						oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
					}
				}
				else if ("USD".equals(iMap.getString("DOVIZ_KODU"))) {
					if (PTT_TRANSFER_BABA_ADI_LIMIT.compareTo(iMap.getBigDecimal("TUTAR").multiply(usdKur)) == -1) {
						oMap.put(tableName, row, "GOSTERIM_DEKONT", "1");
					}
				}
			}

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_CEP_ULKE_KOD")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");

			row++;

			oMap.put(tableName, row, "KOD", row);
			oMap.put(tableName, row, "ALAN_ADI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "PTT_ALAN_REFERANS_ODEME_KOD").put("KEY", "ALICI_CEP_TEL_NO")).getString("TEXT"));
			oMap.put(tableName, row, "GOSTERIM_EKRAN", "1");
			oMap.put(tableName, row, "ZORUNLULUK", "1");

		}

		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("CLKS_REFERENCE_PAYMENT_KUR_BILGI")
	public static GMMap getClksReferencePaymentKurBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = GMServiceExecuter.call("BNSPR_EXTERNAL_PTT_KUR_SORGU", new GMMap().put("BAZ_DVZ", iMap.getString("DOVIZ_KOD")).put("GONDERIM_ODEME","O")); // ALIS_KUR, SATIS_KUR
			oMap.put("UPT_KUR", DALUtil.callOneParameterFunction("{? = call pkg_ptt_referans_odeme.upt_kur(?)}", Types.DECIMAL, iMap.getString("DOVIZ_KOD")));

		}
		catch (Exception e) {
			logger.error("CLKS_REFERENCE_PAYMENT_KUR_BILGI err: " + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("CLKS_REFERENCE_PAYMENT_ISLEM_YERI_AL")
	public static GMMap islemYeriAl(GMMap iMap) {
		GMMap oMap = new GMMap();

		String procStr = "{call PKG_PTT.ISLEM_YERI_AL(?,?,?,?,?,?)}";
		int i = 0;

		Object[] inputValues = new Object[6];
		Object[] outputValues = new Object[6];

		try {

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEMIN_YAPILDIGI_SUBE");

			i = 0;

			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "HEAD_BRANCH_ID";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "HEAD_ID";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "BRANCH_ID";

			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("CLKS_EFEKTIF_KUR_BILGI")
	public static GMMap getClksEfektifKurBilgi(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			
			oMap = GMServiceExecuter.call("BNSPR_EXTERNAL_PTT_KUR_SORGU", new GMMap()
				.put("BAZ_DVZ", "EUR")
				.put("ALIS_SATIS", "A")
				.put("KUR_TIPI", "1")
				.put("GONDERIM_ODEME", "O"));
			oMap.put("USD_ALIS_KUR", oMap.get("USD"));
			oMap.put("EUR_ALIS_KUR", oMap.get("EUR"));
			oMap.put("PARITE", oMap.get("PARITE"));
			
			oMap.put("MARJLI_USD_ALIS_KUR", oMap.get("USD_MARJLI_KUR"));
			oMap.put("MARJLI_EUR_ALIS_KUR", oMap.get("EUR_MARJLI_KUR"));

			
			oMap.putAll(GMServiceExecuter.call("BNSPR_EXTERNAL_PTT_KUR_SORGU", new GMMap()
			.put("BAZ_DVZ", "EUR")
			.put("ALIS_SATIS", "S")
			.put("KUR_TIPI", "1")
			.put("GONDERIM_ODEME", "G")));

			oMap.put("USD_SATIS_KUR", oMap.get("USD"));
			oMap.put("EUR_SATIS_KUR", oMap.get("EUR"));
			
			oMap.put("MARJLI_USD_SATIS_KUR", oMap.get("USD_MARJLI_KUR"));
			oMap.put("MARJLI_EUR_SATIS_KUR", oMap.get("EUR_MARJLI_KUR"));
			
			oMap.put("LABEL_3", "Parite");
			
			// UPT g�nderme ya da �deme ekran�nda tablo olu�turulmas� istenmesine g�re y�ld�z ile i�aretlenecek column bilgisi parametrik olarak al�n�yor
			if("G".equals(iMap.getString("ISLEM_TURU"))) {
				oMap.put("LABEL_1",GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", 
						new GMMap().put("PARAMETRE",  "UPT_GONDERME_SATIS_LABEL")).getString("DEGER"));
				oMap.put("LABEL_2",GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", 
						new GMMap().put("PARAMETRE",  "UPT_GONDERME_ALIS_LABEL")).getString("DEGER"));
			} else if("O".equals(iMap.getString("ISLEM_TURU"))) {
				oMap.put("LABEL_1",GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", 
						new GMMap().put("PARAMETRE",  "UPT_ODEME_SATIS_LABEL")).getString("DEGER"));
				oMap.put("LABEL_2",GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", 
						new GMMap().put("PARAMETRE",  "UPT_ODEME_ALIS_LABEL")).getString("DEGER"));
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
}
