package tr.com.aktifbank.bnspr.clks.services;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.clks.util.ClksConstants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.sun.xml.internal.ws.wsdl.writer.document.Types;

public class CLKSCommonServices {
	
	private static Logger logger = Logger.getLogger(CLKSCommonServices.class);
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_COMMON_MASRAF_HESAPLA")
	public static GMMap setKanalKodu(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String kanalKodu = "";
		
		try {
			
			if(iMap.containsKey("KANAL_KODU")) {
				
				kanalKodu = (String) DALUtil.callNoParameterFunction("{? = call pkg_global.Get_KanalKod}", java.sql.Types.VARCHAR);
				DALUtil.callOracleProcedure("{call pkg_global.Set_KanalKod(?)}", new Object[]{ BnsprType.STRING, iMap.getString("KANAL_KODU") }, new Object[]{});
			}
			
			oMap = GMServiceExecuter.call("INTERNET_HAVALE_EFT_MASRAF_HESAPLA", iMap);
			
			if(iMap.containsKey("KANAL_KODU")) {
				
				DALUtil.callOracleProcedure("{call pkg_global.Set_KanalKod(?)}", new Object[]{ BnsprType.STRING, kanalKodu }, new Object[]{});
			}
			
		} catch(Exception e) {
			logger.error("CLKS_COMMON_SET_KANAL_KODU err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("CLKS_COMMON_GET_KANAL_KODU")
	public static GMMap getKanalKodu(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			oMap.put("KANAL_KODU", DALUtil.callNoParameterFunction("{? = call pkg_global.Get_KanalKod}", java.sql.Types.VARCHAR));
			
		} catch(Exception e) {
			logger.error("CLKS_COMMON_GET_KANAL_KODU err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * @param dci
	 * @param system
	 * @return
	 */
	public static String getCardGroup(String cardGroup) {
		
		// Case: Passo Ozellikli
		if("1".equals(cardGroup)) {
			return ClksConstants.BRAND_CARD_PASSOLIG;
		}
		
		// Case: N Kolay (YIM, UPT Kart, vb.)
		else {
			return ClksConstants.BRAND_CARD_NKOLAY;
		}
	}
}