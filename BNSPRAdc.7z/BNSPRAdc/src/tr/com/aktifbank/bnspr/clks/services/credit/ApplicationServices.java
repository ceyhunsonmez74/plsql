package tr.com.aktifbank.bnspr.clks.services.credit;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Institution;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.PensionPayment;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.SgkInstitution;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKonsolidasyon;
import tr.com.aktifbank.bnspr.dao.istSgkEmekliSorguDetay;
import tr.com.aktifbank.bnspr.dao.istSgkEmekliSorguLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ApplicationServices {
	
	private static Logger logger = Logger.getLogger(ApplicationServices.class);
	
	private final static int SGK_KONTROL_BASVURU = 1;
	private final static int SGK_KONTROL_KULLANDIRIM = 2;
	
	/**
	 * Description : PTT - SGK dosya kaynakli kurum koduna gore aylik odemesinin kurum tipi bilgisini doner.
	 *		   -1: Tanimsiz
	 *			1: SSK
	 *			2: Emekli Sandigi
	 *			3: Bagur
	 *			4: PTT Personel
	 *			5: Kamu
	 *			6: 3.Ki�i Kredi
	 *
	 * @param kurumKod int
	 *
	 * @return int
	 */
	public static int getInstitutionType(int kurumKod) {
		
		int kurumTip = -1;
		
		switch (kurumKod) {
		
			// Case: SSK
			case 202: case 328: kurumTip = 1;
				break;
			// Case: Emekli Sandigi
			case 200: case 201: kurumTip = 2;
				break;
			// Case: Bagkur
			case 211: case 212: kurumTip = 3;
				break;
			case 9999: 			kurumTip = 6;
			break;	
			default: kurumTip = kurumKod;
				break;
				
				
		}

		return kurumTip;
	}
	
	/**
	 * Description : PTT - SGK dosya kaynakli kurum koduna gore aylik odemesinin kurum sigorta kolu bilgisini doner
	 *
	 * @param kurumKod int
	 *
	 * @return String Sigorta Kolu
	 */
	public static String getInstitutionInsuranceCode(int kurumKod) {
		
		String sigortaKolu = "";
		
		switch (kurumKod) {
		
			// Case: SSK
			case 1: case 202: case 328: sigortaKolu = "4A";
				break;
			// Case: Emekli Sandigi
			case 2: case 200: case 201: sigortaKolu = "4C";
				break;
			// Case: Bagkur
			case 3: case 211: case 212: sigortaKolu = "4B";
				break;
			default: sigortaKolu = Integer.toString(kurumKod);
				break;
				
		}

		return sigortaKolu;
	}
	
	/**
	 * Description : PTT - SGK dosya kaynakli kurum koduna gore aylik odemesinin ev/merkez tipi bilgisini doner.
	 *
	 * @param kurumKod int
	 *
	 * @return String kurumun odeme tipine gore Merkez ise "M" Konut ise "K" degerinde String doner.
	 */
	public static String getInstitutionPlaceCode(int kurumKod) {
		
		String kurumYer = "";
		
		switch (kurumKod) {
		
			// Case: Ev
			case 200: case 328: case 212: kurumYer = "K";
				break;
			// Case: Merkez
			case 201: case 202: case 211: kurumYer = "M";
				break;
			default:
				break;
		}

		return kurumYer;
	}
	
	/**
	 * Kampanya uyumsuzluk kontrolleri ve SMS mesajlari {@code GMMap} icinde {@code DURUM} key mevcut degil ise 
	 * basvuru girisinde kampanya ozelinde validasyon saglar, aksi durumda senaryoya uygun SMS eslestirmesi saglar.
	 * 
	 * @param iMap {KAMPANYA}					{@code GMMap} tipinde kampanya ozellikleri
	 * @param iMap {SGK_AYLIK_BILGILERI**}		SGK aylik bilgileri
	 * @param iMap {PENSION_PAYMENT**}			{@link PensionPayment}
	 * @param iMap {DURUM**}					Basvurunun durumu
	 * @param iMap {SOYADI}						Musterinin soyadi
	 * @param iMap {TRX_NO}						Bavuru transcation numarasi
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_CHECK_CAMPAIGN_RULES")
	public static GMMap checkCampaignRules(GMMap iMap) {
		
		GMMap oMap = new GMMap().put("RESPONSE", "2");
		
		try {
			
			GMMap campaignMap = iMap.getMap("KAMPANYA");

			if(iMap.containsKey("DURUM")) {
				
				oMap.put("SCENARIO", "1");
				
				GMMap marketingMap = GMServiceExecuter.call("BNSPR_CLKS_CREDIT_GET_MARKETING_PERMISSION", 
					new GMMap().put("NATIONAL_IDENTITY_NUMBER", iMap.getBigDecimal("TC_KIMLIK_NO")));
				
				if(Arrays.asList(iMap.getString("BORC_TRANSFERI_RED_2"), iMap.getString("BORC_TRANSFERI_RED_3"),
					iMap.getString("BORC_TRANSFERI_RED_4"), iMap.getString("BORC_TRANSFERI_DURUM_5")).contains("Y")) {
					
					GMMap msgMap = new GMMap();
					
					if("Y".equals(iMap.getString("BORC_TRANSFERI_RED_2"))) {
						msgMap.put("MESSAGE_NO", BigDecimal.valueOf(5828)).put("P1", iMap.getString("SOYADI"))
							.put("P2", iMap.getString("BORC_TRANSFERI_UPSELL_LIMIT"));
					} else if("Y".equals(iMap.getString("BORC_TRANSFERI_RED_3"))) {
						msgMap.put("MESSAGE_NO", BigDecimal.valueOf(5829)).put("P1", iMap.getString("SOYADI"))
						.put("P2", iMap.getString("BORC_TRANSFERI_UPSELL_LIMIT"));
					} else if("Y".equals(iMap.getString("BORC_TRANSFERI_RED_4"))) {
						msgMap.put("MESSAGE_NO", BigDecimal.valueOf(5830)).put("P1", iMap.getString("SOYADI"));
					} else if("Y".equals(iMap.getString("BORC_TRANSFERI_DURUM_5"))) {
						msgMap.put("MESSAGE_NO", BigDecimal.valueOf(5831)).put("P1", iMap.getString("SOYADI"))
						.put("P2", iMap.getString("BORC_TRANSFERI_UPSELL_LIMIT"));
					}
					
					if(marketingMap.getBoolean("F_MARKETING_PERMISSION_SMS")) {
					
						GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap()
							.put("MSISDN", iMap.getString("MSISDN"))
							.put("CONTENT", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", msgMap)
								.getString("ERROR_MESSAGE"))
							.put("TRX_NO", iMap.getBigDecimal("TRX_NO"))
							.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO")));
					}
				} else if(iMap.get("PTT_EMEKLI_LIMIT") != null
					&& BigDecimal.ZERO.compareTo(iMap.getBigDecimal("PTT_EMEKLI_LIMIT")) == -1) {
					
					if(marketingMap.getBoolean("F_MARKETING_PERMISSION_SMS")) {
						GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap()
							.put("MSISDN", iMap.getString("MSISDN"))
							.put("CONTENT", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap()
								.put("MESSAGE_NO", BigDecimal.valueOf(5966)).put("P1", iMap.getString("SOYADI"))
								.put("P2", iMap.getString("PTT_EMEKLI_LIMIT"))).getString("ERROR_MESSAGE"))
							.put("TRX_NO", iMap.getBigDecimal("TRX_NO"))
							.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO")));
					}
				} else if("Y".equals(iMap.getString("PTT_ICI_BT_YONLENDIR"))) {
					if(marketingMap.getBoolean("F_MARKETING_PERMISSION_SMS")) {
						GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap()
							.put("MSISDN", iMap.getString("MSISDN"))
							.put("CONTENT", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap()
								.put("MESSAGE_NO", BigDecimal.valueOf(5967)).put("P1", iMap.getString("SOYADI"))
								.put("P2", iMap.getString("PTT_ICI_BT_LIMIT"))).getString("ERROR_MESSAGE"))
							.put("TRX_NO", iMap.getBigDecimal("TRX_NO"))
							.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO")));
					}
					
					GMMap redirectionMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD",
						"CLKS_KRD_PTT_ICI_BT_KAMP_MAP").put("KEY", campaignMap.getString("KOD")));

					if(redirectionMap.get("TEXT") != null) {
						oMap.put("YENI_URUN_KAMP_KOD", redirectionMap.getString("TEXT"));
					}
				}
				 
			} else {
				
				oMap.put("SCENARIO", "0");
				String listName = "SGK_AYLIK_BILGILERI";
			
				if(campaignMap.getBoolean("BORC_TRANSFERI_EH")) {
	
					for(int i = 0; i<iMap.getSize(listName); i++) {
						if("1".equals(iMap.getString(listName, i, "AYLIK_BANKAMDA"))) {
							GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal
								.valueOf(5819)));
						}
					}
					
					if(iMap.get("PENSION_PAYMENT") == null
						|| ((PensionPayment) iMap.get("PENSION_PAYMENT")).getInstitution().getShortCode() == 
						Institution.ShortCode.EMEKLI_SANDIGI) {
						GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal
							.valueOf(5818)));
					}
					
				} else if(campaignMap.getBoolean("UCUNCU_SAHIS_EH")) {
					
					for(int i = 0; i<iMap.getSize(listName); i++) {
						if("1".equals(iMap.getString(listName, i, "AYLIK_BANKAMDA"))) {
							GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal
								.valueOf(5819)));
						}
					}
				}
			}
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_CHECK_CAMPAIGN_RULES err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * Description : Emekli Sandigi disindaki tum kurumlar�n maas_tarih_sikligi default 1 olarak set edilecek.  
	 * 
	 * @param iMap (GMMap)
	 * @return iMap (GMMap)
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_PENSION_PERIOD")
	public static GMMap bnsprClksCreditPensionPeriod(GMMap iMap) {
		
		int kurumTip;
		
		for (int i = 0; i < iMap.getSize("MAAS_BILGILERI"); i++) {
			
			kurumTip = getInstitutionType(iMap.getInt("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"));
			iMap.put("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI",  kurumTip != 2 ? 1 : iMap.get("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI"));
			
			// Tum aylik bilgileri NBSM icin loglanacak
			iMap.put("AYLIK_LISTESI", i,  "TAHSIS_NUMARASI", iMap.get("MAAS_BILGILERI", i, "TAHSIS_NUMARASI"));
			iMap.put("AYLIK_LISTESI", i,  "MAAS_ALINAN_KURUM", iMap.get("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"));
			iMap.put("AYLIK_LISTESI", i,  "MAAS_TUTARI", iMap.get("MAAS_BILGILERI", i, "MAAS_TUTARI"));
			iMap.put("AYLIK_LISTESI", i,  "EMEKLI_MAAS_DONEM", iMap.get("MAAS_BILGILERI", i, "EMEKLI_MAAS_DONEM"));
			iMap.put("AYLIK_LISTESI", i,  "ONCEKI_MAAS_ODEME_TARIHI", iMap.get("MAAS_BILGILERI", i, "ONCEKI_MAAS_ODEME_TARIHI"));
			iMap.put("AYLIK_LISTESI", i,  "MAAS_TARIH_SIKLIGI", iMap.get("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI"));
			iMap.put("AYLIK_LISTESI", i,  "ILK_MAAS_TARIHI", iMap.get("MAAS_BILGILERI", i, "ILK_MAAS_TARIHI"));
			iMap.put("AYLIK_LISTESI", i,  "SON_MAAS_TARIHI", iMap.get("MAAS_BILGILERI", i, "SON_MAAS_TARIHI"));
			iMap.put("AYLIK_LISTESI", i,  "MAAS_PTT_DENMI", iMap.get("MAAS_BILGILERI", i, "MAAS_PTT_DENMI"));
			iMap.put("AYLIK_LISTESI", i,  "EMEKLI_MAAS_EVDENMI", iMap.get("MAAS_BILGILERI", i, "EMEKLI_MAAS_EVDENMI"));
			iMap.put("AYLIK_LISTESI", i,  "KURUM_DONEM", iMap.get("MAAS_BILGILERI", i, "KURUM_DONEM"));
		}
		
		return iMap;
	}
	
	@GraymoundService("BNSPR_CLKS_CREDIT_PENSION_SGK_VALIDATION")
	public static GMMap bnsprClksCreditPensionSgkValidation(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			oMap.put("SONUC", 1);

			String flagSgkBagkurKontrol = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "CLKS_SGK_BAGKUR_SERVIS_KONTROL")).getString("DEGER");
			String flagSgkSskKontrol = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "CLKS_SGK_SSK_SERVIS_KONTROL")).getString("DEGER");
			String flagSgkEmekliSandigiKontrol = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "CLKS_SGK_ESAN_SERVIS_KONTROL")).getString("DEGER");

			// Case: SSK, Bagkur, Emekli Sandigi
			if(("1".equals(iMap.getString("MAAS_ALINAN_KURUM")) && "E".equals(flagSgkSskKontrol)) || ("2".equals(iMap.getString("MAAS_ALINAN_KURUM")) && "E".equals(flagSgkEmekliSandigiKontrol)) || ("3".equals(iMap.getString("MAAS_ALINAN_KURUM")) && "E".equals(flagSgkBagkurKontrol))) {

				// Case: SGK Sonuc Kodu
				if(iMap.get("SGK_SONUC_KODU") != null && iMap.getString("SGK_SONUC_KODU").length() != 0 && !"-1".equals(iMap.getString("SGK_SONUC_KODU")) && (!iMap.containsKey("SGK_BLOKE_SONUC_KODU") || (iMap.containsKey("SGK_BLOKE_SONUC_KODU") && !"-1".equals(iMap.getString("SGK_BLOKE_SONUC_KODU"))))) {

					// Case: Basvuru adimindaki SGK kontrolleri
					if(iMap.getInt("SGK_KONTROL_TIP") == SGK_KONTROL_BASVURU) {

						// Case: SGK - PTT Aylik Listeleri eslemiyor
						if(!iMap.containsKey("SGK_AYLIK_ID")) {

							GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 4425));
						}

						/**
						 * -4 : AYLIK DURDURULMUS
						 * -13 : ODEME BILGISI YOK
						 */
						if("-4".equals(iMap.getString("SGK_AYLIK_SONUC_KODU")) || "-13".equals(iMap.getString("SGK_AYLIK_SONUC_KODU"))) {

							GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1827));
						}

						else if("-4".equals(iMap.getString("SGK_SONUC_KODU")) || "-13".equals(iMap.getString("SGK_SONUC_KODU"))) {

							GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1827));
						}

						// Case: Aylik bankada degil
						if(!"1".equals(iMap.getString("SGK_AYLIK_BANKAMDA"))) {

							GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1827));
						}
					}

					// Case: Kullandirim adimindaki SGK kontrolleri
					else if(iMap.getInt("SGK_KONTROL_TIP") == SGK_KONTROL_KULLANDIRIM) {

						/**
						 * -4 : AYLIK DURDURULMUS
						 * -6 : SADECE KENDI BANKANIZDAN AYLIK ALANLARA BLOKE KOYMA VE KALDIRMA ISLEMI YAPABILIRSINIZ
						 * -13 : ODEME BILGISI YOK
						 */
						if(iMap.getString("SGK_BLOKE_SONUC_KODU") == null || iMap.getString("SGK_BLOKE_SONUC_KODU").isEmpty() || "-1".equals(iMap.getString("SGK_BLOKE_SONUC_KODU")) || "-3".equals(iMap.getString("SGK_BLOKE_SONUC_KODU"))) {

							if("-4".equals(iMap.getString("SGK_AYLIK_SONUC_KODU")) || "-6".equals(iMap.getString("SGK_AYLIK_SONUC_KODU")) || "-13".equals(iMap.getString("SGK_AYLIK_SONUC_KODU"))) {

								GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 4425));
							}

							else if("-4".equals(iMap.getString("SGK_SONUC_KODU")) || "-6".equals(iMap.getString("SGK_SONUC_KODU")) || "-13".equals(iMap.getString("SGK_SONUC_KODU"))) {

								GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 4425));
							}

							// Case: Aylik bankada degil
							if(!"1".equals(iMap.getString("SGK_AYLIK_BANKAMDA"))) {

								GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 4425));
							}
						}

						else if(!"0".equals(iMap.getString("SGK_BLOKE_SONUC_KODU")) && !"-10".equals(iMap.getString("SGK_BLOKE_SONUC_KODU"))) {

							iMap.put("HATA_NO", 4425);
							GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
						}
					}
				}

				// Case: Entegrasyonda bir hata ise ayiralim
				else {
					oMap.put("SONUC", -1);
				}
			}
		} catch(Exception e) {
			
			logger.error("BNSPR_CLKS_CREDIT_PENSION_SGK_VALIDATION err:" + e);
			oMap.put("SONUC", 0);
			
			// Case: Basvuru'da nitelikli kredi olarak sayilmasi icin hata vermeyelim
			if(!"1".equals(iMap.getString("RETURN"))) {
				throw ExceptionHandler.convertException(e);
			}
		}
		
		return oMap;
	}
	
	/**
	 * Kampanya politikasina uygun sgk aylik secimi yapar.
	 * 
	 * @param iMap {SGK_AYLIK_BILGILERI**}
	 * @param iMap {PARAM_REF_TUR**}
	 * @param iMap {PARAM_REF_ID**}
	 * @param iMap {KAMPANYA}
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_SELECT_SGK_PENSION")
	public static GMMap selectSgkPension(GMMap iMap) {
	
		GMMap oMap = new GMMap();
		String listName = "SGK_AYLIK_BILGILERI";
		PensionPayment payment = null;
		
		try {
			
			if(iMap.getMap("KAMPANYA").getBoolean("BORC_TRANSFERI_EH")) {
				
				if(iMap.containsKey(listName)) {
					
					for(int i=0; i<iMap.getSize(listName); i++) {
						
						if(iMap.get(listName, i, "SIGORTA_KOLU") == null
							|| iMap.getString(listName, i, "SIGORTA_KOLU").isEmpty()) {
							continue;
						}

						String sicilNo = iMap.get(listName, i, "SICIL_NO") != null ? iMap.getString(listName, i,
							"SICIL_NO").trim() : "";
						String aylikId = iMap.get(listName, i, "AYLIK_ID") != null ? iMap.getString(listName, i,
							"AYLIK_ID").trim() : "";

						PensionPayment tmp = new PensionPayment(SgkInstitution.valueOf(SgkInstitution.InsuranceChannel
							.getEnum(iMap.getString(listName, i, "SIGORTA_KOLU").trim())), aylikId, sicilNo, iMap
							.getString(listName, i, "AYLIK_SONUC_KODU"), iMap.getString(listName, i,
							"AYLIK_SONUC_ACIKLAMA"), iMap.getInt(listName, i, "AYLIK_BANKAMDA"));
						
						if(payment == null || !payment.hasHigherPriority(tmp)) {
							payment = (PensionPayment) tmp.clone();
						}
					}
				}
			}
			
			if(payment != null) {
				oMap.put("PENSION_PAYMENT", payment);
			}
			
			// TODO Diger kampanya tiplerine ozel politika(lar) uyarlanmali
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_SELECT_SGK_PENSION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * Description : PTT Basvuruda kullanilacak aylik bilgisini ve eslestirilebildigi takdirde SGK online aylik bilgisini doner.
	 *
	 * @param iMap (GMMap)
	 * 		{MAAS_BILGILERI=[{TAHSIS_NUMARASI, MAAS_TUTARI, MAAS_ALINAN_KURUM, UNVANI, EMEKLI_MAAS_DONEM, ONCEKI_MAAS_ODEME_TARIHI, 
	 *			MAAS_TARIH_SIKLIGI, ILK_MAAS_TARIHI, SON_MAAS_TARIHI, MAAS_PTT_DENMI, EMEKLI_MAAS_EVDENMI}],
	 *		SGK_AYLIK_BILGILERI=[{TAYLIK_ID, SIGORTA_KOLU, TAHSIS_SEKLI, ADI, SOYADI, AYLIK_BANKAMDA, AYLIK_SONUC_KODU, SICIL_NO, SISTEM_ACIK_KAPALI_KODU}]}
	 *
	 * @return oMap (GMMap)
	 *      {SGK_AYLIK_ID, SGK_SIGORTA_KOLU, SGK_TAHSIS_SEKLI, SGK_ADI, SGK_SOYADI, SGK_AYLIK_BANKAMDA, SGK_AYLIK_SONUC_KODU, SGK_AYLIK_SONUC_ACIKLAMA
	 *      SGK_SICIL_NO, SGK_SISTEM_ACIK_KAPALI_KODU}
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_SELECT_PENSION")
	public static GMMap bnsprClksCreditSelectPension(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			BigDecimal gecerliAylikTutari = BigDecimal.ZERO;
			boolean gecerliAylikExists = false, aylikExists = false, hataliSorguExists = false;
			int index = -1, row = 0, sgkIndex = -1, pttIndex = -1;;
			
			// Son donem maas bilgileri
			for (int i = 0; i < iMap.getSize("MAAS_BILGILERI"); i++) {
				
				aylikExists = false;
				
				for(int j = 0; j < oMap.getSize("MAAS_BILGILERI"); j++) {
					
					// Case: Siradaki aylik, son donem aylik listesinde var ise;
					if(iMap.getString("MAAS_BILGILERI", i, "TAHSIS_NUMARASI").equals(oMap.getString("MAAS_BILGILERI", j, "TAHSIS_NUMARASI"))) {
						
						// Case: Siradaki aylik donemi daha guncel ise, son donem aylik bilgilerini guncelle
						if(iMap.getBigDecimal("MAAS_BILGILERI", i, "EMEKLI_MAAS_DONEM").compareTo(oMap.getBigDecimal("MAAS_BILGILERI", j, "EMEKLI_MAAS_DONEM")) == 1) {
							
							oMap.put("MAAS_BILGILERI", j, "TAHSIS_NUMARASI", iMap.get("MAAS_BILGILERI", i, "TAHSIS_NUMARASI"));
							oMap.put("MAAS_BILGILERI", j, "MAAS_TUTARI", iMap.get("MAAS_BILGILERI", i, "MAAS_TUTARI"));
							oMap.put("MAAS_BILGILERI", j, "MAAS_ALINAN_KURUM", iMap.get("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"));
							oMap.put("MAAS_BILGILERI", j, "UNVANI",iMap.get("MAAS_BILGILERI", i, "UNVANI"));
							oMap.put("MAAS_BILGILERI", j, "PTT_UNVAN_KOD",iMap.get("MAAS_BILGILERI", i, "UNVANI"));
							oMap.put("MAAS_BILGILERI", j, "EMEKLI_MAAS_DONEM", iMap.get("MAAS_BILGILERI", i, "EMEKLI_MAAS_DONEM"));
							oMap.put("MAAS_BILGILERI", j, "ONCEKI_MAAS_ODEME_TARIHI", iMap.get("MAAS_BILGILERI", i, "ONCEKI_MAAS_ODEME_TARIHI"));
							oMap.put("MAAS_BILGILERI", j, "MAAS_TARIH_SIKLIGI", iMap.get("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI"));
							oMap.put("MAAS_BILGILERI", j, "ILK_MAAS_TARIHI", iMap.get("MAAS_BILGILERI", i, "ILK_MAAS_TARIHI"));
							oMap.put("MAAS_BILGILERI", j, "SON_MAAS_TARIHI", iMap.get("MAAS_BILGILERI", i,"SON_MAAS_TARIHI"));
							oMap.put("MAAS_BILGILERI", j, "MAAS_PTT_DENMI", iMap.get("MAAS_BILGILERI", i, "MAAS_PTT_DENMI"));
							oMap.put("MAAS_BILGILERI", j, "EMEKLI_MAAS_EVDENMI", iMap.get("MAAS_BILGILERI", i, "EMEKLI_MAAS_EVDENMI"));
							oMap.put("MAAS_BILGILERI", j, "KURUM_DONEM", iMap.get("MAAS_BILGILERI", i, "KURUM_DONEM"));
							oMap.put("MAAS_BILGILERI", j, "KURUM_TIP", getInstitutionType(iMap.getInt("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")));
						}
						
						aylikExists = true;
						break;
					}
				}
				
				// Case: Siradaki aylik, son donem aylik listesinde var ise, devam et
				if(aylikExists) {
					continue;
				}
				
				// Siradaki ayligi, son donem aylik listesine ekle
				oMap.put("MAAS_BILGILERI", row, "TAHSIS_NUMARASI", iMap.get("MAAS_BILGILERI", i, "TAHSIS_NUMARASI"));
				oMap.put("MAAS_BILGILERI", row, "MAAS_TUTARI", iMap.get("MAAS_BILGILERI", i, "MAAS_TUTARI"));
				oMap.put("MAAS_BILGILERI", row, "MAAS_ALINAN_KURUM", iMap.get("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"));
				oMap.put("MAAS_BILGILERI", row, "UNVANI",iMap.get("MAAS_BILGILERI", i, "UNVANI"));
				oMap.put("MAAS_BILGILERI", row, "PTT_UNVAN_KOD",iMap.get("MAAS_BILGILERI", i, "UNVANI"));
				oMap.put("MAAS_BILGILERI", row, "EMEKLI_MAAS_DONEM", iMap.get("MAAS_BILGILERI", i, "EMEKLI_MAAS_DONEM"));
				oMap.put("MAAS_BILGILERI", row, "ONCEKI_MAAS_ODEME_TARIHI", iMap.get("MAAS_BILGILERI", i, "ONCEKI_MAAS_ODEME_TARIHI"));
				oMap.put("MAAS_BILGILERI", row, "MAAS_TARIH_SIKLIGI", iMap.get("MAAS_BILGILERI", i, "MAAS_TARIH_SIKLIGI"));
				oMap.put("MAAS_BILGILERI", row, "ILK_MAAS_TARIHI", iMap.get("MAAS_BILGILERI", i, "ILK_MAAS_TARIHI"));
				oMap.put("MAAS_BILGILERI", row, "SON_MAAS_TARIHI", iMap.get("MAAS_BILGILERI", i,"SON_MAAS_TARIHI"));
				oMap.put("MAAS_BILGILERI", row, "MAAS_PTT_DENMI", iMap.get("MAAS_BILGILERI", i, "MAAS_PTT_DENMI"));
				oMap.put("MAAS_BILGILERI", row, "EMEKLI_MAAS_EVDENMI", iMap.get("MAAS_BILGILERI", i, "EMEKLI_MAAS_EVDENMI"));
				oMap.put("MAAS_BILGILERI", row, "KURUM_DONEM", iMap.get("MAAS_BILGILERI", i, "KURUM_DONEM"));
				oMap.put("MAAS_BILGILERI", row, "KURUM_TIP", getInstitutionType(iMap.getInt("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM")));
				
				row++;
			}
			
			oMap.put("SGK_AYLIK_BILGILERI", iMap.get("SGK_AYLIK_BILGILERI"));
			oMap.put("SGK_SONUC_KODU", iMap.get("SGK_SONUC_KODU"));
			oMap.put("SGK_SONUC_ACIKLAMA", iMap.get("SGK_SONUC_ACIKLAMA"));
			oMap.put("SGK_KONTROL_TIP", SGK_KONTROL_BASVURU); // Basvuru Kontrolleri
			
			GMMap sgkMap = new GMMap();
			int kontrol;
			
			// Son donem ayliklar
			for (int i = 0; i < oMap.getSize("MAAS_BILGILERI"); i++) {
				
				sgkMap.putAll(GMServiceExecuter.call("CLKS_BASVURU_EMEKLI_SGK_AYLIK_GETIR", iMap
						.put("MAAS_ALINAN_KURUM", oMap.getBigDecimal("MAAS_BILGILERI", i, "MAAS_ALINAN_KURUM"))
						.put("TAHSIS_NUMARASI", oMap.getString("MAAS_BILGILERI", i, "TAHSIS_NUMARASI"))));
				
				// Case: SGK Kayit donusu varsa sgk parametrelerini aylik bilgilerine dahil edelim
				if(sgkMap.getInt("SGK_KAYIT") == 1) {
					
					oMap.put("MAAS_BILGILERI", i, "SGK_AYLIK_ID", sgkMap.get("SGK_AYLIK_ID"));
					oMap.put("MAAS_BILGILERI", i, "SGK_SIGORTA_KOLU", sgkMap.get("SGK_SIGORTA_KOLU"));
					oMap.put("MAAS_BILGILERI", i, "SGK_TAHSIS_SEKLI", sgkMap.get("SGK_TAHSIS_SEKLI"));
					oMap.put("MAAS_BILGILERI", i, "SGK_ADI", sgkMap.get("SGK_ADI"));
					oMap.put("MAAS_BILGILERI", i, "SGK_SOYADI", sgkMap.get("SGK_SOYADI"));
					oMap.put("MAAS_BILGILERI", i, "SGK_AYLIK_BANKAMDA", sgkMap.get("SGK_AYLIK_BANKAMDA"));
					oMap.put("MAAS_BILGILERI", i, "SGK_AYLIK_SONUC_KODU", sgkMap.get("SGK_AYLIK_SONUC_KODU"));
					oMap.put("MAAS_BILGILERI", i, "SGK_AYLIK_SONUC_ACIKLAMA", sgkMap.get("SGK_AYLIK_SONUC_ACIKLAMA"));
					oMap.put("MAAS_BILGILERI", i, "SGK_SICIL_NO", sgkMap.get("SGK_SICIL_NO"));
					oMap.put("MAAS_BILGILERI", i, "SGK_SISTEM_ACIK_KAPALI_KODU", sgkMap.get("SGK_SISTEM_ACIK_KAPALI_KODU"));
					oMap.put("MAAS_BILGILERI", i, "SGK_KAYIT", sgkMap.get("SGK_KAYIT"));
				} 
				
				else {
					oMap.put("MAAS_BILGILERI", i, "SGK_KAYIT", sgkMap.get("SGK_KAYIT"));
				}
				
				// Case: En yuksek tutara sahip aylik bilgileri kullanilacak
				if(oMap.getBigDecimal("MAAS_BILGILERI", i, "MAAS_TUTARI").compareTo(gecerliAylikTutari) == 1) {
					
					kontrol = GMServiceExecuter.call("BNSPR_CLKS_CREDIT_PENSION_SGK_VALIDATION", oMap
							.put("SGK_AYLIK_ID", oMap.getString("MAAS_BILGILERI", i, "SGK_AYLIK_ID"))
							.put("SGK_AYLIK_BANKAMDA", oMap.getString("MAAS_BILGILERI", i, "SGK_AYLIK_BANKAMDA"))
							.put("SGK_AYLIK_SONUC_KODU", oMap.getString("MAAS_BILGILERI", i, "SGK_AYLIK_SONUC_KODU"))
							.put("RETURN", 1)
							.put("MAAS_ALINAN_KURUM", oMap.getBigDecimal("MAAS_BILGILERI", i, "KURUM_TIP"))).getInt("SONUC");
					
					// Case: SGK Kontrollerine takiliyorsa, aylik bilgisini dikkate alma
					if(kontrol == -1) {
                          hataliSorguExists = true;
                          pttIndex = i;
                          continue;
					} else if (kontrol == 0) {
                          pttIndex = i;
                          continue;
					}
					
					sgkIndex = i;
					
					gecerliAylikTutari = oMap.getBigDecimal("MAAS_BILGILERI", i, "MAAS_TUTARI");
					gecerliAylikExists = true;
				}
			}
			
			 // Case: SGK'dan gecersiz ancak SGK servisine erisilememis
			if(!gecerliAylikExists && hataliSorguExists) {
				oMap.put("SGK_RED_NITELIKLI", "E").put("SGK_RED_GEREKCE_KODU", "38");
				index = pttIndex;
			}
			
			// Case: SGK'dan gecersiz
            else if(!gecerliAylikExists) {
            	oMap.put("SGK_RED_NITELIKLI", "E").put("SGK_RED_GEREKCE_KODU", "39");
                index = pttIndex;
            }
			
            else {
                  index = sgkIndex;
            }
			
			oMap.put("TAHSIS_NUMARASI", oMap.getString("MAAS_BILGILERI", index, "TAHSIS_NUMARASI"));
			oMap.put("MAAS_TUTARI", oMap.getBigDecimal("MAAS_BILGILERI", index, "MAAS_TUTARI"));
			oMap.put("MAAS_ALINAN_KURUM", oMap.getString("MAAS_BILGILERI", index, "MAAS_ALINAN_KURUM"));
			oMap.put("UNVANI", oMap.getString("MAAS_BILGILERI", index, "UNVANI"));
			oMap.put("PTT_UNVAN_KOD", oMap.getString("MAAS_BILGILERI", index, "UNVANI"));
			oMap.put("EMEKLI_MAAS_DONEM", oMap.getString("MAAS_BILGILERI", index, "EMEKLI_MAAS_DONEM"));
			oMap.put("ONCEKI_MAAS_ODEME_TARIHI", (oMap.getString("MAAS_BILGILERI", index, "ONCEKI_MAAS_ODEME_TARIHI") != null && !oMap.getString("MAAS_BILGILERI", index, "ONCEKI_MAAS_ODEME_TARIHI").trim().isEmpty()) ? oMap.getString("MAAS_BILGILERI", index, "ONCEKI_MAAS_ODEME_TARIHI") : null);
			oMap.put("MAAS_TARIH_SIKLIGI", oMap.getString("MAAS_BILGILERI", index, "MAAS_TARIH_SIKLIGI"));
			oMap.put("ILK_MAAS_TARIHI", (oMap.getString("MAAS_BILGILERI", index, "ILK_MAAS_TARIHI") != null && !oMap.getString("MAAS_BILGILERI", index, "ILK_MAAS_TARIHI").trim().isEmpty()) ? oMap.getString("MAAS_BILGILERI", index, "ILK_MAAS_TARIHI") : null);
			oMap.put("SON_MAAS_TARIHI", (oMap.getString("MAAS_BILGILERI", index, "SON_MAAS_TARIHI") != null && !oMap.getString("MAAS_BILGILERI", index, "SON_MAAS_TARIHI").trim().isEmpty()) ? oMap.getString("MAAS_BILGILERI", index, "SON_MAAS_TARIHI") : null);
			oMap.put("MAAS_PTT_DENMI", oMap.getString("MAAS_BILGILERI", index, "MAAS_PTT_DENMI"));
			oMap.put("EMEKLI_MAAS_EVDENMI", oMap.getString("MAAS_BILGILERI", index, "EMEKLI_MAAS_EVDENMI"));
			oMap.put("KURUM_DONEM", oMap.getString("MAAS_BILGILERI", index, "KURUM_DONEM"));
			
			if(oMap.getInt("MAAS_BILGILERI", index, "SGK_KAYIT") == 1) {
				
				oMap.put("SGK_AYLIK_ID", oMap.getString("MAAS_BILGILERI", index, "AYLIK_ID"));
				oMap.put("SGK_SIGORTA_KOLU", oMap.getString("MAAS_BILGILERI", index, "SIGORTA_KOLU"));
				oMap.put("SGK_TAHSIS_SEKLI", oMap.getString("MAAS_BILGILERI", index, "TAHSIS_SEKLI"));
				oMap.put("SGK_ADI", oMap.getString("MAAS_BILGILERI", index, "ADI"));
				oMap.put("SGK_SOYADI", oMap.getString("MAAS_BILGILERI", index, "SOYADI"));
				oMap.put("SGK_AYLIK_BANKAMDA", oMap.getString("MAAS_BILGILERI", index, "AYLIK_BANKAMDA"));
				oMap.put("SGK_AYLIK_SONUC_KODU", oMap.getString("MAAS_BILGILERI", index, "AYLIK_SONUC_KODU"));
				oMap.put("SGK_AYLIK_SONUC_ACIKLAMA", oMap.getString("MAAS_BILGILERI", index, "AYLIK_SONUC_ACIKLAMA"));
				oMap.put("SGK_SICIL_NO", oMap.getString("MAAS_BILGILERI", index, "SICIL_NO"));
				oMap.put("SGK_SISTEM_ACIK_KAPALI_KODU", oMap.getString("MAAS_BILGILERI", index, "SISTEM_ACIK_KAPALI_KODU"));
			}
		}
		
		catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_SELECT_PENSION err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * Yap�landirma kredi ba�vurusu i�in yap�landirilan kredilere dair bilgi d�ner.
	 * 
	 * @param iMap {BASVURU_NO}	Yapilandirma kredisi basvuru numarasi
	 * @return					<code>GMMap{IS_CONSOLIDATED,CONSOLIDATED_APPLICATIONS}</code> tipinde de�er d�ner.
	 * 							{@code IS_CONSOLIDATED} - Ba�vuru numaras� e�er bir konsolidasyon kredisine ait ise {@code true}, aksi durumda 
	 * 							{@code false} d�ner. E�er {@code IS_CONSOLIDATED}, {@code true} ise {@code List<GMMap>} 
	 * 							tipinde <code>CONSOLIDATED_APPLICATIONS{APPLICATION_NO, IS_CONSOLIDATED}</code> d�ner.
	 * 							{@code APPLICATION_NO} - Yap�land�rma aday� ba�vuru numaras�. {@code IS_CONSOLIDATED} - 
	 * 							Yap�land�rma aday� yap�land�r�ld�ysa {@code true}, yap�land�r�lmad�ysa {@code false}.
	 * 
	 * @throws GMRuntimeException - T�m istisnalarda f�rlat�l�r.
	 * 							
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_GET_CONSOLIDATION_INFO")
	public static GMMap bnsprClksCreditGetConsolidationInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		int i = 0;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			@SuppressWarnings("unchecked")
			List<BirBasvuruKonsolidasyon> list = session.createCriteria(BirBasvuruKonsolidasyon.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			Iterator<BirBasvuruKonsolidasyon> iterator = list.iterator();
			oMap.put("IS_CONSOLIDATED", iterator.hasNext());
			
			while(iterator.hasNext()) {
				BirBasvuruKonsolidasyon basvuru = iterator.next();
				oMap.put("CONSOLIDATED_APPLICATIONS", i, "APPLICATION_NO", basvuru.getId().getYapilandirilanBasvuruNo());
				oMap.put("CONSOLIDATED_APPLICATIONS", i++, "IS_CONSOLIDATED", "E".equals(basvuru.getKapamaEh()) ? true : false);
			}
			
			return oMap;
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_GET_CONSOLIDATION_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kanalindan gerceklesen kredi basvurularinda {@link #applicationRequest(GMMap) BNSPR_CLKS_CREDIT_APPLICATION_REQUEST}
	 * servisine input olarak beslenen <code>SGK_AYLIK_BILGILERI</code> ve diger SGK iliskili parametreleri kayit eder.
	 * <p>
	 * <code>REQUEST_TYPE</code> key degeri <code>aylikSorgula</code> olmasi durumunda {@link #sgkEmekliMaasSorguCreateLogDetay(GMMap) BNSPR_CLKS_CREDIT_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY}
	 * cagirilarak aylik detay bilgileri kayit edilir.
	 * 
	 * @param iMap {REQUEST_TYPE}
	 * @param iMap {BASVURU_NO}
	 * @param iMap {TC_KIMLIK_NO}
	 * @param iMap {REQUEST_TYPE}
	 * @param iMap {SGK_SONUC_KODU}
	 * @param iMap {SGK_SONUC_ACIKLAMA}
	 * @param iMap {SGK_AYLIK_BILGILERI**}
	 * <p>** opsiyonel</p>
	 * @return
	 * 
	 * @see #sgkEmekliMaasSorguCreateLogDetay(GMMap) BNSPR_CLKS_CREDIT_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG")
	public static GMMap sgkEmekliMaasSorguCreateLog(GMMap iMap) {
		
		GMMap oMap = new GMMap();		
		
		try {
				
			iMap.put("LOG_ID", GMServiceExecuter.executeNT("BNSPR_SGK_EMEKLI_SORGU_GET_LOG_ID", new GMMap()).get(
				"LOG_ID"));
			iMap.put("PARAM_REF_TUR", "BIR_BASVURU");
			iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
			
			if("aylikSorgula".equals(iMap.getString("REQUEST_TYPE"))) {

				iMap.put("ERROR_DESCRIPTION",
					iMap.getString("SGK_SONUC_KODU") + ":" + iMap.get("SGK_SONUC_ACIKLAMA") == null ? "" : iMap
						.getString("SGK_SONUC_ACIKLAMA"));
				
				if(iMap.get("SGK_SONUC_KODU") != null && !"0".equals(iMap.getString("SGK_SONUC_KODU"))) {
					iMap.put("QUERY_RESULT_STATUS", "FAILURE");
				} else {
					iMap.put("QUERY_RESULT_STATUS", "SUCCESS");
				}
				
				iMap.put("REQUEST_DATA", new GMMap()
					.put("PARAM_REF_ID", iMap.getString("PARAM_REF_ID"))
					.put("TCKN", iMap.getString("TC_KIMLIK_NO"))
					.put("BASVURU_NO", iMap.getString("PARAM_REF_ID"))
					.put("PARAM_REF_TUR", iMap.getString("PARAM_REF_TUR")).toString());
				
			} else {
				iMap.put("HATA_NO", 1803);
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			istSgkEmekliSorguLog istSgkEmekliMaasSorguLog = new istSgkEmekliSorguLog();
			istSgkEmekliMaasSorguLog.setLogId(iMap.getBigDecimal("LOG_ID"));
			istSgkEmekliMaasSorguLog.setErrorDescription(iMap.getString("ERROR_DESCRIPTION"));
			istSgkEmekliMaasSorguLog.setQueryResultStatus(iMap.getString("QUERY_RESULT_STATUS"));
			istSgkEmekliMaasSorguLog.setRequestType(iMap.getString("REQUEST_TYPE"));
			istSgkEmekliMaasSorguLog.setRequestData(iMap.get("REQUEST_DATA") != null ? new ClobImpl(iMap
				.getString("REQUEST_DATA")) : null);
			istSgkEmekliMaasSorguLog.setResponseData(iMap.get("RESPONSE_DATA") != null ? new ClobImpl(iMap
				.getString("RESPONSE_DATA")) : null);
			istSgkEmekliMaasSorguLog.setResultCode(iMap.getString("RESULT_CODE"));
			istSgkEmekliMaasSorguLog.setParamRefTur(iMap.getString("PARAM_REF_TUR"));
			istSgkEmekliMaasSorguLog.setParamRefId(iMap.getString("PARAM_REF_ID"));
			istSgkEmekliMaasSorguLog.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			session.save(istSgkEmekliMaasSorguLog);
			session.flush();
			
			// Detay log at
			if("aylikSorgula".equals(iMap.getString("REQUEST_TYPE"))) {
				GMServiceExecuter.executeNT("BNSPR_CLKS_CREDIT_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY", iMap);
			}

			oMap.put("RESPONSE", "2");
			
		} catch (Exception e) {
			logger.error("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY err:", e);
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		
		return oMap;
	}
	
	/**
	 * PTT kanalindan gerceklesen kredi basvurularinda {@link #applicationRequest(GMMap) BNSPR_CLKS_CREDIT_APPLICATION_REQUEST}
	 * servisine input olarak beslenen <code>SGK_AYLIK_BILGILERI</code> kayit eder.
	 * 
	 * @param iMap {LOG_ID}
	 * @param iMap {PARAM_REF_TUR}
	 * @param iMap {PARAM_REF_ID}
	 * @param iMap {TC_KIMLIK_NO}
	 * @param iMap {SGK_AYLIK_BILGILERI}
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY")
	public static GMMap sgkEmekliMaasSorguCreateLogDetay(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			if(iMap.getSize("SGK_AYLIK_BILGILERI") > 0) {

				Session session = DAOSession.getSession("BNSPRDal");
				for(int i = 0; i < iMap.getSize("SGK_AYLIK_BILGILERI"); i++) {

					BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID",
						new GMMap().put("TABLE_NAME", "IST_SGK_EMEKLI_SORGU_DETAY")).getBigDecimal("ID");

					istSgkEmekliSorguDetay istSgkEmekliMaasSorguDetay = new istSgkEmekliSorguDetay();
					istSgkEmekliMaasSorguDetay.setId(id);
					istSgkEmekliMaasSorguDetay.setLogId(iMap.getBigDecimal("LOG_ID"));
					istSgkEmekliMaasSorguDetay.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
					istSgkEmekliMaasSorguDetay.setAdi(iMap.get("SGK_AYLIK_BILGILERI", i, "ADI") != null ? iMap
						.getString("SGK_AYLIK_BILGILERI", i, "ADI").trim() : null);
					istSgkEmekliMaasSorguDetay.setSoyadi(iMap.get("SGK_AYLIK_BILGILERI", i, "SOYADI") != null ? iMap
						.getString("SGK_AYLIK_BILGILERI", i, "SOYADI").trim() : null);
					istSgkEmekliMaasSorguDetay.setAylikId(iMap.get("SGK_AYLIK_BILGILERI", i, "AYLIK_ID") != null ? iMap
						.getString("SGK_AYLIK_BILGILERI", i, "AYLIK_ID").trim() : null);
					istSgkEmekliMaasSorguDetay.setAylikSonucAciklama(iMap.get("SGK_AYLIK_BILGILERI", i,
						"AYLIK_SONUC_ACIKLAMA") != null ? iMap.getString("SGK_AYLIK_BILGILERI", i,
						"AYLIK_SONUC_ACIKLAMA").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setSigortaKolu(iMap.get("SGK_AYLIK_BILGILERI", i, "SIGORTA_KOLU") != null ? iMap.getString(
							"SGK_AYLIK_BILGILERI", i, "SIGORTA_KOLU").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setTahsisSekli(iMap.get("SGK_AYLIK_BILGILERI", i, "TAHSIS_SEKLI") != null ? iMap.getString(
							"SGK_AYLIK_BILGILERI", i, "TAHSIS_SEKLI").trim() : null);
					istSgkEmekliMaasSorguDetay.setSicilNo(iMap.getString("SGK_AYLIK_BILGILERI", i, "SICIL_NO") != null
						? iMap.getString("SGK_AYLIK_BILGILERI", i, "SICIL_NO").trim() : null);
					istSgkEmekliMaasSorguDetay.setSistemAcikKapali(iMap.get("SGK_AYLIK_BILGILERI", i,
						"SISTEM_ACIK_KAPALI_KODU") != null ? iMap.getString("SGK_AYLIK_BILGILERI", i,
						"SISTEM_ACIK_KAPALI_KODU").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setAylikBankamda(iMap.get("SGK_AYLIK_BILGILERI", i, "AYLIK_BANKAMDA") != null ? iMap
							.getString("SGK_AYLIK_BILGILERI", i, "AYLIK_BANKAMDA").trim() : null);
					istSgkEmekliMaasSorguDetay
						.setAylikSonucKodu(iMap.get("SGK_AYLIK_BILGILERI", i, "AYLIK_SONUC_KODU") != null ? iMap
							.getString("SGK_AYLIK_BILGILERI", i, "AYLIK_SONUC_KODU").trim() : null);
					istSgkEmekliMaasSorguDetay.setParamRefTur(iMap.getString("PARAM_REF_TUR"));
					istSgkEmekliMaasSorguDetay.setParamRefId(iMap.getString("PARAM_REF_ID"));

					session.save(istSgkEmekliMaasSorguDetay);
					session.flush();
				}
			}

			oMap.put("RESPONSE", "2");
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG_DETAY err:", e);
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}
	
	/**
	 * PTT kanali kredi urunu icin ozellesmis ipaz sorgulama servisi.
	 * 
	 * @param iMap {NATIONAL_IDENTITY_NUMBER}	TC kimlik numarasi
	 * @param iMap {CUSTOMER_NO}				Musteri numarasi
	 * @return									Varsayilan kanalda SMS ve TELEFON izinleri olmamasi durumunda 
	 * 											<tt>GMMap{F_MAKETING_PERMISSION=false, F_MARKETING_PERMISSION_SMS=true/false, 
	 * 											F_MARKETING_PERMISSION_PHONE=true/false}</tt>, izin olmasi durumunda ise, 
	 * 											<tt>GMMap{F_MAKETING_PERMISSION=true, F_MARKETING_PERMISSION_SMS=true, 
	 * 											F_MARKETING_PERMISSION_PHONE=true}</tt> degeri doner. 
	 * @throws GMRuntimeException
	 * @see BNSPR_CUSTOMER_GET_MARKETING_PERMISSION_LIST
	 */
	@GraymoundService("BNSPR_CLKS_CREDIT_GET_MARKETING_PERMISSION")
	public static GMMap getMarketingPermission(GMMap iMap) {
		
		GMMap oMap = new GMMap(), marketingMap = new GMMap();
		
		try {
			
			if(iMap.containsKey("NATIONAL_IDENTITY_NUMBER")) {
				marketingMap = GMServiceExecuter.call("BNSPR_CUSTOMER_GET_MARKETING_PERMISSION_LIST", new GMMap()
					.put("TCKN", iMap.getString("NATIONAL_IDENTITY_NUMBER")).put("CHANNEL", "BANKA"));
			} else if(iMap.containsKey("CUSTOMER_NO")) {
				marketingMap = GMServiceExecuter.call("BNSPR_CUSTOMER_GET_MARKETING_PERMISSION_LIST", new GMMap()
					.put("CUSTOMER_NO", iMap.getBigDecimal("CUSTOMER_NO")).put("CHANNEL", "BANKA"));
			} else {
				// TODO Throw exception
			}
			
			oMap.put("F_MARKETING_PERMISSION_SMS", "E".equals(marketingMap.getString("LIST", 0, "F_SMS")));
			oMap.put("F_MARKETING_PERMISSION_PHONE", "E".equals(marketingMap.getString("LIST", 0, "F_TELEFON")));
			if(oMap.getBoolean("F_MARKETING_PERMISSION_SMS") && oMap.getBoolean("F_MARKETING_PERMISSION_PHONE")) {
				oMap.put("F_MARKETING_PERMISSION", true);
			} else {
				oMap.put("F_MARKETING_PERMISSION", false);
			}
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CREDIT_GET_MARKETING_PERMISSION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}