package tr.com.aktifbank.bnspr.clks.services.credit;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.internal.GMCreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal.DalCreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal.CreditApplicationProcessImpl;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class QueryServices {
	
	private static Logger logger = Logger.getLogger(QueryServices.class);
	
	@GraymoundService("BNSPR_CLKS_KREDI_BASVURU_DURUM_SORGU")
	public static GMMap bnsprClksKrediBasvuruDurumSorgu(GMMap iMap) {
		
		GMMap oMap = (GMMap) iMap.clone();
		
		try {
			
			for(int i = 0; i < iMap.getSize("BASVURU"); i++) {
				
				CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
				Application application = applicationDao.get(iMap.getBigDecimal("BASVURU", i, "BASVURU_NO"));
				application.setStatus(applicationDao.saveOrUpdateApplicationStatusOnQuery(application
					.getApplicationNo()));

				CreditApplicationProcess<Application> process = new CreditApplicationProcessImpl<Application>(
					applicationDao, new GMCreditApplicationApi());

				if(application.getCommissionCategory() == null) {
					process.applicationAfterIntermediateStatus(application);
				}
				
				oMap.put("BASVURU", i, "DURUM", application.getStatus().toString());
				oMap.put("BASVURU", i, "F_NITELIKLI_RED", application.isQualifiedCommission() ? "E" : "H");
			}
		
		} catch(Exception e) {

			logger.error("BNSPR_CLKS_KREDI_BASVURU_DURUM_SORGU err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
}
