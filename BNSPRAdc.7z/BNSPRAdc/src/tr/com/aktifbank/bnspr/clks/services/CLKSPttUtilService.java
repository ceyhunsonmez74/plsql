package tr.com.aktifbank.bnspr.clks.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.clks.util.BnsprAdcMessageExecuter;
import tr.com.aktifbank.bnspr.dao.ClksPttDailyAgreement;
import tr.com.aktifbank.bnspr.dao.ClksPttDailyAgreementId;
import tr.com.aktifbank.bnspr.dao.ClksPttHourlyAgreement;
import tr.com.aktifbank.bnspr.dao.ClksPttHourlyAgrntLookup;
import tr.com.aktifbank.bnspr.dao.ClksPttHourlyAgrntLookupId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CLKSPttUtilService {
	private static Logger logger = Logger.getLogger(CLKSPttUtilService.class);

	@GraymoundService("BNSPR_PTT_HOURLY_AGREEMENT")
	public static GMMap clksPttHourlyAgreement(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMServiceExecuter.executeAsync(
				"BNSPR_PTT_HOURLY_AGREEMENT_ASYNCHRONOUS", iMap);
		
		GMServiceExecuter.executeAsync(
				"BNSPR_PTT_HOURLY_CHANGE_STATUS", iMap);
		return oMap;
	}

	@GraymoundService("BNSPR_PTT_ERROR_LOGING")
	public static GMMap clksPttErrorLoging(GMMap iMap) {
		Connection conn = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();

		} catch (Exception e) {
			logger.error("BNSPR_PTT_ERROR_LOGING err: " + e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_PTT_REQUEST_RESPONSE_LOGING")
	public static GMMap clksPttRequestResponseLoging(GMMap iMap) {
		Connection conn = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();

		} catch (Exception e) {
			logger.error("BNSPR_PTT_REQUEST_RESPONSE_LOGING err: " + e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_PTT_DAILY_AGREEMENT")
	public static GMMap clksPttDailyAgreement(GMMap iMap) {

		logger.info("BNSPR_PTT_DAILY_AGREEMENT in:" + iMap.toString());
		Connection conn = null;
		GMMap oMap = new GMMap();
		CallableStatement stmt = null;
		Session session = DAOSession.getSession("BNSPRDal");
		String islemListesi = "ISLEM_LISTESI";
		int tableSize = iMap.getSize(islemListesi);
		try {
			conn = DALUtil.getGMConnection();
			for (int row = 0; row < tableSize; row++) {

				ClksPttDailyAgreementId clksPttDailyAgreementId = new ClksPttDailyAgreementId(
						iMap.getDate("TARIH"), iMap.getBigDecimal(islemListesi,
								row, "ISLEMTIPI"), "PTT");

				ClksPttDailyAgreement clksPttDailyAgreement = (ClksPttDailyAgreement) session
						.get(ClksPttDailyAgreement.class,
								clksPttDailyAgreementId);
				if (clksPttDailyAgreement == null)
					clksPttDailyAgreement = new ClksPttDailyAgreement();

				clksPttDailyAgreement.setId(clksPttDailyAgreementId);
				clksPttDailyAgreement.setOdemeTahsilat(iMap.getString(
						islemListesi, row, "ODEME_TAHSILAT"));
				clksPttDailyAgreement.setAdet(iMap.getBigDecimal(islemListesi,
						row, "ADET"));
				clksPttDailyAgreement.setIslemTutariTl(iMap.getBigDecimal(
						islemListesi, row, "ISLEM_TUTARI_TL"));
				clksPttDailyAgreement.setIslemTutariEur(iMap.getBigDecimal(
						islemListesi, row, "ISLEM_TUTARI_EUR"));
				clksPttDailyAgreement.setIslemTutariUsd(iMap.getBigDecimal(
						islemListesi, row, "ISLEM_TUTARI_USD"));
				clksPttDailyAgreement.setMasrafTutariTl(iMap.getBigDecimal(
						islemListesi, row, "MASRAF_TUTARI_TL"));
				clksPttDailyAgreement.setMasrafTutariEur(iMap.getBigDecimal(
						islemListesi, row, "MASRAF_TUTARI_EUR"));
				clksPttDailyAgreement.setMasrafTutariUsd(iMap.getBigDecimal(
						islemListesi, row, "MASRAF_TUTARI_USD"));
				clksPttDailyAgreement.setKomisyonTutariTl(iMap.getBigDecimal(
						islemListesi, row, "KOMISYON_TUTARI_TL"));
				clksPttDailyAgreement.setKomisyonTutariEur(iMap.getBigDecimal(
						islemListesi, row, "KOMISYON_TUTARI_EUR"));
				clksPttDailyAgreement.setKomisyonTutariUsd(iMap.getBigDecimal(
						islemListesi, row, "KOMISYON_TUTARI_USD"));
				session.saveOrUpdate(clksPttDailyAgreement);
			}
			session.flush();
			int i = 0;
			Object[] inputValues = new Object[2];
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = new java.sql.Date(iMap.getDate("TARIH")
					.getTime());
			Object[] outputValues = new Object[0];
			String procStr = "{call PKG_PTT_JOB.PTTKomisyonhesapla(?)}";
			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues,
					outputValues);

		} catch (Exception e) {
			logger.error("BNSPR_PTT_DAILY_AGREEMENT err: " + e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		logger.info("BNSPR_PTT_DAILY_AGREEMENT out:" + oMap.toString());
		return oMap;
	}

	@GraymoundService("BNSPR_PTT_PERSONEL_SICIL_ADSOYAD")
	public static GMMap bnsprPttPersonelSicilAdSoyad(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			oMap.put("SICIL_NO", iMap.getBigDecimal("SICIL_NO"));
			oMap.put(
					"PERSONEL_AD_SOYAD",
					DALUtil.getResult("select t.personel_ad_soyad from clks_ptt_personel t where t.sicil =  '"
							+ iMap.getBigDecimal("SICIL_NO") + "'"));
			return oMap;

		} catch (Exception e) {
			logger.error("BNSPR_PTT_PERSONEL_SICIL_ADSOYAD err: " + e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_DAILY_AND_HOURLY_CONTROL")
	public static GMMap pttDailyAndHourlyControl(GMMap iMap) {

		logger.info("BNSPR_DAILY_AND_HOURLY_CONTROL in:" + iMap.toString());
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Connection conn2 = null;
		CallableStatement stmt2 = null;
		ResultSet rSet2 = null;
		String izlemetablosu = "IZLEMETABLOSU";
		String izlemetablosu2 = "SAATLIKMUTABAKATTABLOSU";
		int i = 0;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call  PKG_PTT_JOB.Clks_Daily_List(?)}");
			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(i);
			oMap = DALUtil.rSetResults(rSet, izlemetablosu);
			String body = "<!DOCTYPE html><html><head>"
                          +"<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>"
                          +"</head><style>"
                          + "table, th, td {border: 1px solid black;}</style>"
                          + "<body><strong>Gunluk Mutabakat Calisma Durumu</strong><br>";

			String rowData = " ";
			int tableSize = oMap.getSize(izlemetablosu);
			if (tableSize > 0) {
				rowData = "<table><tr><td>Mutabakat Gunu</td><td>Calisma Tarihi</td><td>Calisma Saati</td><td>Calisma Sayisi</td></tr>";
				for (int row = 0; row < tableSize; row++) {
					rowData = rowData
							+ "<tr><td>"
							+ oMap.getString(izlemetablosu, row,
									"MUTABAKAT_TARIHI") + "</td>";
					rowData = rowData + "<td>"
							+ oMap.getString(izlemetablosu, row, "JOB_TARIHI")
							+ "</td>";
					rowData = rowData + "<td>"
							+ oMap.getString(izlemetablosu, row, "JOB_SAATI")
							+ "</td>";
					rowData = rowData + "<td>"
							+ oMap.getString(izlemetablosu, row, "RUN_COUNT")
							+ "</td></tr>";
				}
				body = body + rowData + "</table>";
			} else {
				rowData = "<strong>" + dateFormat.format(date)
						+ " Tarihli Gunluk Mutabakat Calismamistir </strong>";
				body = body + rowData;
			}
			body = body
					+ "<br><br><strong>Saatlik Mutabakat Calisma Durumu</strong><br>";

			i = 0;
			conn2 = DALUtil.getGMConnection();
			stmt2 = conn2
					.prepareCall("{call  PKG_PTT_JOB.Clks_Hourly_List(?)}");
			stmt2.registerOutParameter(++i, -10);
			stmt2.execute();
			rSet2 = (ResultSet) stmt2.getObject(i);
			oMap = DALUtil.rSetResults(rSet2, izlemetablosu2);

			int tableSize2 = oMap.getSize(izlemetablosu2);
			if (tableSize2 > 0) {
				rowData = "<table><tr><td>Mutabakat Tarihi</td><td>Job Calisma Saati</td><td>Job Calisma Adedi</td><td>Gelen Data Adedi</td></tr>";
				for (int row = 0; row < tableSize2; row++) {
					rowData = rowData + "<tr><td>"
							+ oMap.getString(izlemetablosu2, row, "RUN_TIME")
							+ "</td>";
					rowData = rowData + "<td>"
							+ oMap.getString(izlemetablosu2, row, "REC_TIME")
							+ "</td>";
					rowData = rowData + "<td>"
							+ oMap.getString(izlemetablosu2, row, "RUN_COUNT")
							+ "</td>";
					rowData = rowData + "<td>"
							+ oMap.getString(izlemetablosu2, row, "ISLEM_ADET")
							+ "</td></tr>";
				}
				body = body + rowData + "</table></body></html>";
			} else {
				rowData = "<strong>"
						+ dateFormat.format(date)
						+ " Tarihinde Saatlik Mutabakat Calismamistir </strong>";
				body = body + rowData + "</body></html>";
			}
			oMap.put("MAIL_FROM", "system@aktifbank.com.tr");
			oMap.put("PARAMETRE", "GUNLUK_SAATLIK_MUTABAKAT");
			oMap.put("MAIL_TO",GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K",oMap).get("DEGER"));
		
			if ((tableSize2 > 0) && (tableSize > 0)) {
				oMap.put("MAIL_SUBJECT",
						"Gunluk Ve Saatlik Mutabakat Calisma Zamanlari");
			} else {
				oMap.put("MAIL_SUBJECT",
						"Gunluk Ve Saatlik Mutabakata Gelmeyen Datalar Var");
			}
			oMap.put("MAIL_BODY", body);
			sendMail(oMap);
			return oMap;

		} catch (Exception e) {
			logger.error("BNSPR_DAILY_AND_HOURLY_CONTROL err: " + e);
			throw ExceptionHandler.convertException(e);
		} finally {
			logger.info("CLKS_PTT_DAILY_AGREEMENT out:" + oMap.toString());
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn2);
		}
	}

	private static void sendMail(GMMap iMap) {
		try {
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_TO",iMap.getString("MAIL_TO"));
			servisMap.put("MAIL_FROM", iMap.getString("MAIL_FROM"));
			servisMap.put("MAIL_SUBJECT", iMap.getString("MAIL_SUBJECT"));
			servisMap.put("MAIL_BODY", iMap.getString("MAIL_BODY"));
			servisMap.put("IS_BODY_HTML", "E");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
					servisMap);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@GraymoundService("BNSPR_PTT_HOURLY_AGREEMENT_ASYNCHRONOUS")
	public static GMMap clksPttHourlyAgreementAsyncronous(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String islemListesi = "ISLEM_LISTESI";
			String mutabakat = "MUTABAKAT";
			int tableSize = iMap.getSize(islemListesi);

			for (int row = 0; row < tableSize; row++) {

				ClksPttHourlyAgreement clksPttHourlyAgreement = new ClksPttHourlyAgreement();
				clksPttHourlyAgreement.setBankaIslemNo(iMap.getString(
						islemListesi, row, "BANKA_ISLEM_NO"));
				clksPttHourlyAgreement.setTarihSaat(iMap.getDate("TARIH_SAAT"));
				clksPttHourlyAgreement.setKayitSaati(iMap
						.getString("KAYIT_SAATI"));
				clksPttHourlyAgreement.setPttIslemNo(iMap.getString(
						islemListesi, row, "PTT_ISLEM_NO"));
				clksPttHourlyAgreement.setIslemSaati(iMap.getString(
						islemListesi, row, "ISLEM_SAATI"));
				clksPttHourlyAgreement.setIslemTarihi(iMap.getDate(
						islemListesi, row, "ISLEM_TARIHI"));
				clksPttHourlyAgreement.setPttSubeId(iMap.getString(
						islemListesi, row, "PTT_SUBE_ID"));
				clksPttHourlyAgreement.setPttMerkezId(iMap.getString(
						islemListesi, row, "PTT_MERKEZ_ID"));
				clksPttHourlyAgreement.setIslemTipi(iMap.getString(
						islemListesi, row, "ISLEM_TIPI"));
				clksPttHourlyAgreement.setAltIslemTipi(iMap.getString(
						islemListesi, row, "ALT_ISLEM_TIPI"));
				clksPttHourlyAgreement.setDurum(iMap.getString(islemListesi,
						row, "DURUM"));
				clksPttHourlyAgreement.setHesapNo(iMap.getString(islemListesi,
						row, "HESAP_NO"));
				clksPttHourlyAgreement.setIslemMasrafDovizKodu(iMap.getString(
						islemListesi, row, "ISLEM_MASRAF_DOVIZ_KODU"));
				clksPttHourlyAgreement.setIslemMasrafTutar(iMap.getBigDecimal(
						islemListesi, row, "ISLEM_MASRAF_TUTAR"));
				clksPttHourlyAgreement.setIslemDovizKodu(iMap.getString(
						islemListesi, row, "ISLEM_DOVIZ_KODU"));
				clksPttHourlyAgreement.setIslemTutar(iMap.getBigDecimal(
						islemListesi, row, "ISLEM_TUTAR"));
				session.saveOrUpdate(clksPttHourlyAgreement);
				GMMap mutabakatMap = new GMMap();
				mutabakatMap.put(mutabakat,
						iMap.get(islemListesi, row, mutabakat));
				int table2Size = mutabakatMap.getSize(mutabakat);

				for (int row2 = 0; row2 < table2Size; row2++) {
					ClksPttHourlyAgrntLookupId clksPttHourlyAgrntLookupId = new ClksPttHourlyAgrntLookupId();
					clksPttHourlyAgrntLookupId.setBankaIslemNo(iMap.getString(
							islemListesi, row, "BANKA_ISLEM_NO"));
					clksPttHourlyAgrntLookupId.setDovizKodu(mutabakatMap
							.getString(mutabakat, row2, "DOVIZ_KODU"));
					clksPttHourlyAgrntLookupId.setTutar(mutabakatMap
							.getBigDecimal(mutabakat, row2, "TUTAR"));
					ClksPttHourlyAgrntLookup clksPttHourlyAgrntLookup = new ClksPttHourlyAgrntLookup();
					clksPttHourlyAgrntLookup.setId(clksPttHourlyAgrntLookupId);
					session.saveOrUpdate(clksPttHourlyAgrntLookup);
				}

			}
			session.flush();

		} catch (Exception e) {
			oMap.putAll(BnsprAdcMessageExecuter.callError(e.getMessage()));

		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_PTT_HOURLY_CHANGE_STATUS")
	public static GMMap clksPttHourlyChangeStatus(GMMap iMap) {
		logger.info("BNSPR_PTT_HOURLY_CHANGE_STATUS in:" + iMap.toString());
		GMMap oMap = new GMMap();
		GMMap mailMap=new GMMap();
		mailMap.put("MAIL_SUBJECT","Saatlik Mutabakat Sorunlu Islemlerin Onaylanmas�");
		mailMap.put("MAIL_FROM", "system@aktifbank.com.tr");
		mailMap.put("PARAMETRE", "SAATLIK_MUTABAKAT_SORUNLU");
		mailMap.put("MAIL_TO",GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K",mailMap).get("DEGER"));
		int sorunluSayisi=0;
		int onaylananSayisi=0;
		String body = "<!DOCTYPE html><html><head>"
                +"<meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/>"
                +"</head><style>"
                + "table, th, td {border: 1px solid black;}</style>"
                + "<body><strong>Saatlik Mutabakat Gelen Islemlerden Sorunlu Sayisi Ve Onaylanmislarin Sayisi </strong><br>";
		String bodyTable="<table><tr><td>Onaylanm�� ��lem No</td><td>IsLem Yapildigi Tarih</td><td>IsLem Yapildigi Saat</td><td>Islem Mutabakat Adi</td></tr>";
		String proc="{call PKG_PTT_JOB.Hourly_Change_Status(?,?)}";	
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String sorunlutablosu="SORUNLU_ISLEM_LISTESI";
		int Durum;
		try {
			int i = 0;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(proc);
			stmt.setDate(++i, new java.sql.Date(iMap.getDate("TARIH_SAAT")
					.getTime()));
			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(i);
			oMap = DALUtil.rSetResults(rSet, sorunlutablosu);
			
			sorunluSayisi=oMap.getSize(sorunlutablosu);	
			if (sorunluSayisi!=0){ 
			for (int row = 0; row < oMap.getSize(sorunlutablosu); row++) {
				GMMap o2Map = new GMMap();
				
				o2Map.put("ISLEM_NO",oMap.getString(sorunlutablosu,row,"ISLEM_NO"));
				o2Map.put("ISLEM_TIPI",oMap.getString(sorunlutablosu,row,"ISLEM_TIPI"));
				o2Map.put("DURUM_KODU",oMap.getString(sorunlutablosu,row,"AB_DURUMU"));
				try {
					GMServiceExecuter.execute("QRY2056_ISLEM_ONAYLAMA", o2Map);
					bodyTable=bodyTable+"<tr><td>"+oMap.getString(sorunlutablosu,row,"ISLEM_NO")+"</td>"+
					                         "<td>"+oMap.getString(sorunlutablosu,row,"ISLEM_TARIHI")+"</td>"+
					                         "<td>"+oMap.getString(sorunlutablosu,row,"ISLEM_SAATI")+"</td>"+
					                         "<td>"+islemTipi(oMap.getString(sorunlutablosu,row,"ISLEM_TIPI2"))+"</td>";
					onaylananSayisi++;
					if (oMap.getString(sorunlutablosu, row, "AB_DURUMU")
							.equals("Sorunlu")) {
						Durum = 1;
					} else {
						Durum = 3;
					}
				} catch (GMRuntimeException e) {
					if (oMap.getString(sorunlutablosu, row, "AB_DURUMU")
							.equals("Sorunlu")) {
						Durum = 2;
					} else {
						Durum = 4;
					}
				}
				Connection conn2 = null;
				CallableStatement stmt2 = null;
				String proc2="{call PKG_PTT_JOB.Hourly_Change(?,?,?)}";	
				int j = 0;
				try{
				conn2 = DALUtil.getGMConnection();
				stmt2 = conn2.prepareCall(proc2);
				stmt2.setInt(++j,oMap.getInt(sorunlutablosu,row,"ISLEM_NO"));
				stmt2.setInt(++j,Durum);
				stmt2.setInt(++j,1);
				stmt2.execute();
				} catch(Exception e) {
					logger.error("BNSPR_PTT_HOURLY_CHANGE_STATUS err: " + e);
					throw ExceptionHandler.convertException(e);
		          }
				finally {
					logger.info("BNSPR_PTT_HOURLY_CHANGE_STATUS out:" + o2Map.toString());
					GMServerDatasource.close(stmt2);
					GMServerDatasource.close(conn2);

				}
				o2Map.clear();
				
			}
			}
          
		} catch(Exception e) {
			logger.error("BNSPR_PTT_HOURLY_CHANGE_STATUS err: " + e);
			throw ExceptionHandler.convertException(e);
          }
		finally {
			logger.info("BNSPR_PTT_HOURLY_CHANGE_STATUS out:" + oMap.toString());
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
		bodyTable=bodyTable+"</table>";
		body=body+"<table><tr><td>Islemlerin Tarihi</td><td>Gelen Sorunlu Islem Say�s�</td><td>Onaylanm�s Islem Say�s�</td></tr>"+
				"<tr><td>"+iMap.getString("TARIH_SAAT")+"</td><td>"+sorunluSayisi+"</td><td>"+ onaylananSayisi+"</td></tr></table>";
		if (onaylananSayisi!=0) {
		body=body+"<br><br><strong>Saatlik Mutabakat Onaylanan ��lemler</strong><br>"+bodyTable;	
		}
		body=body+"</body></html>";
		mailMap.put("MAIL_BODY", body);
		if (sorunluSayisi!=0) {
	sendMail(mailMap);
		}
	return oMap;	
	}
	
	private static String islemTipi(String islem) {
		String islemAd="";
		if (islem.equals("1")){
			islemAd="NAKIT YATIRMA";
		}else if (islem.equals("4")){
			islemAd="KREDI YATIRMA";
		}else if (islem.equals("5")){
			islemAd="NAKIT CEKME";
		}else if (islem.equals("6")||(islem.equals("8"))||(islem.equals("11"))||(islem.equals("14"))){
			islemAd="UPT ODEME";
		}else if (islem.equals("7")){
			islemAd="KREDI KULLANDIRIM";			
		}else if (islem.equals("9")){
			islemAd="KREDI BASVURUSU";			
		} else  if (islem.equals("10")){
			islemAd="TL UPT";			
		}else if (islem.equals("12")){
			islemAd="YP YURTICI GONDERIM";			
		}else if (islem.equals("13")){
			islemAd="YP YURTDISI GONDERIM";			
		}else if (islem.equals("25")){
			islemAd="INTERNET UPT HESABINA PARA YATIRMA";			
		}else if (islem.equals("26")){
			islemAd="INTERNET UPT HESABINADAN NAKIT CEKME";			
		}else if (islem.equals("27")){
			islemAd="UPT IADE";			
		}else if (islem.equals("28")){
			islemAd="INTERNET UPT HESABI ACMA";			
		}else if (islem.equals("60")){
			islemAd="ATM HESABA NAKIT YATIRMA";			
		}else if (islem.equals("61")){
			islemAd="ATM IBAN''A NAKIT YATIRMA";			
		}else if (islem.equals("62")){
			islemAd="'ATM EUPT HESABINA NAKIT";			
		}else if ((islem.equals("63"))||(islem.equals("64"))){
			islemAd="ATM NAKIT YATIRMA PASSOLIG";			
		}else if (islem.equals("65")||islem.equals("66")){
			islemAd="PASSOLIG YATIRMA";			
		}else if (islem.equals("70")){
			islemAd="PCH TL UPT GONDERIM";			
		}else if (islem.equals("80")||islem.equals("81")||(islem.equals("82"))){
			islemAd="UPT TALIMAT";
		}    
		
		

		return islemAd;
	}
	
	@GraymoundService("BNSPR_PTT_INSURANCE_DAILY_CONTROL")
	public static GMMap clksInsuranceDailycontrol(GMMap iMap) {
		logger.info("BNSPR_PTT_INSURANCE_DAILY_CONTROL start");
		Connection conn = null;
		PreparedStatement stmt = null;
		PreparedStatement stmt1 = null;
		ResultSet rSet = null;
		SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
		
		GMMap mailMap=new GMMap();
		mailMap.put("MAIL_SUBJECT","G�nl�k Mutabakat Kontrol�");
		mailMap.put("MAIL_FROM", "system@aktifbank.com.tr");
		mailMap.put("PARAMETRE", "GUNLUK_MUTABAKAT_SORUNLU");
		mailMap.put("MAIL_TO",GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", mailMap).get("DEGER"));
		
		try{

			conn = DALUtil.getServiceLogConnection();
			String sql ="select * from ADC_SERVICE_LOG  where SERVICE_NAME = 'AKUSTIK_SIGORTA_EBS_URETIM_JOB'  and trunc (BEGIN_DATE) = '" + format.format(Calendar.getInstance().getTime()) + "' order by BEGIN_DATE desc";
			stmt = conn.prepareStatement(sql);
			rSet = stmt.executeQuery();

			String template = "<!DOCTYPE html><head><meta http-equiv=\"Content-Type\" content=\"text/html;charset=UTF-8\"/></head><body>"
					+ "<table style=\"height: 252px; width: 100%;\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">"
					+ "<tbody><tr><td style=\"height: 30px; text-align: center;\" colspan=\"2\"><h1><strong>G�nl�k Mutabakat Kontrol�</strong></h1></td></tr>"
					+ "<tr><td style=\"height: 30px; width: 70%; text-align: center;\"><strong>AktifBank i�lem say�s�</strong></td><td style=\"height: 30px; width=30%; text-align: center;\">{0}</td></tr>"
					+ "<tr><td style=\"height: 30px; text-align: center;\"><strong>EBS i�lem say�s�</strong></td><td style=\"height: 30px; text-align: center;\">{1}</td></tr>"
					+ "<tr><td style=\"height: 30px; text-align: center;\" colspan=\"2\"><h2><span style=\"color: {2};\"><strong>{3}</strong></span></h2></td></tr></tbody></table>"
					+ "</body></html>";
			
			String body ="";
			
			GMMap eMap =  DALUtil.rSetResults(rSet, "EBS_RESULT");
			
			if (eMap.getSize("EBS_RESULT")>0) {
//				String bDate =  oMap.getString("EBS_RESULT", 0, "BEGIN_DATE");
//				String duration =  oMap.getString("EBS_RESULT", 0, "DURATION");
//				String response =  oMap.getString("EBS_RESULT", 0, "RESPONSE");
				
				String sql1 = "select * from ADC_SERVICE_LOG  where (SERVICE_NAME = 'CLKS_SIGORTA_EBS_URETIM') or SERVICE_NAME = 'CLKS_SIGORTA_URETIM_ISLEM_RESPONSE') and trunc(BEGIN_DATE) = '" + format.format(Calendar.getInstance().getTime()) + "' order by BEGIN_DATE desc";
				stmt1 = conn.prepareStatement(sql1);
				rSet = stmt1.executeQuery();
				GMMap pttMap =  DALUtil.rSetResults(rSet, "CLKS_RESULT");

				if (pttMap.getSize("CLKS_RESULT") > 0) {
					String response = pttMap.getString("CLKS_RESULT", 0, "RESPONSE");
					
					/* Ptt taraf�ndaki i�lem say�s� response i�erisinden ay�klan�yor */
					String startTag = "ISLEM=[";
					String endTag = "][";
					
					int startIndex = response.indexOf(startTag) + startTag.length();
					int endIndex = response.indexOf(endTag);
					int ebsIslemSayisi = Integer.parseInt(response.substring(startIndex, endIndex));
					
					/* Banka taraf�ndaki kay�tlar map i�erisine dolduruluyor. */
					Calendar cal = Calendar.getInstance();
					cal.add(Calendar.DAY_OF_YEAR, -1);
					
					
					iMap.put("TARIH_BAS",cal.getTime());
					iMap.put("TARIH_BIT",cal.getTime());
					
					GMMap oMap3 = new GMMap();
					oMap3.putAll(GMServiceExecuter.execute("BNSPR_QRY4111_SORGULA", iMap)); 
					
					int bankaIslemSayisi = oMap3.getSize("SONUC");
					
					String[] values = new String[4];
					values[0] = String.valueOf(bankaIslemSayisi);
					values[1] = String.valueOf(ebsIslemSayisi);
					
					if(bankaIslemSayisi == ebsIslemSayisi){
						values[2] = "green";
						values[3] = "AktifBank ve PTT kay�t say�lar� e�it.";
					}else{
						values[2] = "red";
						values[3] = "AktifBank ve PTT kay�t say�lar� e�it de�il!!";
					}
					
					 body = MessageFormat.format(template, values);
					 
				 }else{
					 String[] values = {"-", "-", "red", "�retim mutabat� �al��mam��!!"};
					 body = MessageFormat.format(template, values);
				 }			
				
			}else{
				 String[] values = {"-", "-", "red", "EBS job �al��mam��!!"};
				 body = MessageFormat.format(template, values);
			}			
			
			mailMap.put("MAIL_BODY", body);
			sendMail(mailMap);
		
			
		}catch (Exception e){
			logger.error("BNSPR_PTT_INSURANCE_DAILY_CONTROL err: " + e);
			throw ExceptionHandler.convertException(e);
		}finally {
			logger.info("BNSPR_PTT_INSURANCE_DAILY_CONTROL end");
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(conn);
		}
		
		return new GMMap();	
	}
	
	
	
	
}
