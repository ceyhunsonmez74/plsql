package tr.com.aktifbank.bnspr.clks.services.scheduler;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.ClksislemLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCCoreUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMToolkit;

public class ReconciliationServices {

	private static Logger logger = Logger.getLogger(ReconciliationServices.class);

	@GraymoundService("CLKS_RECONCILIATION_AUTOMATION")
	public static GMMap clksReconciliationAutomation(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = new GMMap(), inMap = new GMMap(), dataMap = new GMMap();
		
		String statusProcessed = "P", statusCanceled = "2", statusOnApproval = "C",
				statusBnspr, statusVendor, serviceName, location, description, personnelId, personnelName;
		BigDecimal txNo, pttIslemNo, processType, retryCount;
		
		try {
			
			if(!iMap.containsKey("TARIH")) {
				iMap.put("TARIH", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).get("BANKA_TARIH"));
			}
			
			map = DALUtil.callOracleRefCursorFunction("{ ? = call pkg_trn2052.get_mismatched_records(?) }", "RECORDS", BnsprType.DATE, iMap.getDate("TARIH"));
			
			for (int i = 0; i < map.getSize("RECORDS"); i++) {
				
				serviceName = map.getString("RECORDS", i, "ONAY_SERVISI");
				txNo = map.getBigDecimal("RECORDS", i, "TX_NO");
				pttIslemNo = map.getBigDecimal("RECORDS", i, "PTT_ISLEM_NO");
				statusBnspr = map.getString("RECORDS", i, "DURUM_KODU");
				statusVendor = map.getString("RECORDS", i, "PTT_DURUM_KODU");
				location = map.getString("RECORDS", i, "KONUM");
				personnelId = map.getString("RECORDS", i, "PERSONEL_SICIL");
				personnelName = map.getString("RECORDS", i, "PERSONEL_AD_SOYAD");
				description = map.getString("RECORDS", i, "ACIKLAMA");
				processType = map.getBigDecimal("RECORDS", i, "ISLEM");
				retryCount = map.getBigDecimal("RECORDS", i, "RETRY_COUNT").add(BigDecimal.ONE);
				java.sql.Blob blob = map.get("RECORDS", i, "DATA") == null ? null : (java.sql.Blob) map.get("RECORDS", i, "DATA");
				
				if(blob != null) {
					byte[] data = blob.getBytes(1L, (int)blob.length());
					dataMap = (GMMap) GMToolkit.deserialize(data);
				}
				
				if(statusVendor.equals(statusCanceled) && statusBnspr.equals(statusProcessed)) {

		            inMap.put("F_RECONCILIATION", true)
						.put("islemNo", txNo)
		            	.put("pttSiraNo", pttIslemNo)
		            	.put("islemYeri", location)
		            	.put("kullaniciSicil", personnelId)
		            	.put("iptaliYapanKullAdSoyad", personnelName)
		            	.put("aciklama", description)
		            	.put("iptalTip", "G");
					
					oMap = remoteCall("CLKS_TRANSACTION_CANCEL_CONFIRM", inMap);
					
				} else if(statusVendor.equals(statusCanceled) && statusBnspr.equals(statusOnApproval)) {
					
					// TODO Update transaction status code to "R"
					
				} else if(statusVendor.equals(statusProcessed) && statusBnspr.equals(statusOnApproval)) {
				
					inMap.put("F_RECONCILIATION", true)
						.put("islemNo", txNo)
						.put("islemNoPTT", pttIslemNo)
						.put("islem", processType)
		            	.put("islemYeri", location)
		            	.put("aciklama",description)
		            	.put("kullaniciSicil", personnelId)
		            	.put("islemiyapankullaniciadsoyad", personnelName)
						.put("ISLEM_NO", txNo)
						.put("ISLEM_NO_PTT", pttIslemNo);
					inMap.putAll(dataMap);
					
					oMap = remoteCall(serviceName, inMap);
				}
				
				// TODO Batch update
				GMServiceExecuter.executeNT("CLKS_RECONCILIATION_AUTOMATION_AFTER_REMOTE_CALL", new GMMap().put("TX_NO", txNo)
					.put("RETRY_COUNT", retryCount)
					.put("STATUS_VENDOR", statusVendor)
					.put("RESPONSE_DATA", oMap.getString("RESPONSE_DATA", oMap.getString("hataMesaji", "N/A"))));
			}
			
		} catch(Exception e) {
			logger.error("CLKS_RECONCILIATION_AUTOMATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return new GMMap();
	}
	
	@GraymoundService("CLKS_RECONCILIATION_AUTOMATION_AFTER_REMOTE_CALL")
	public static GMMap clksReconciliationAutomationAfterRemoteCall(GMMap iMap) {
		
		String statusAfterRemoteCall, statusVendor, responseData;
		BigDecimal txNo, retryCount;
		StringBuilder body = new StringBuilder();
		
		try {
			
			txNo = iMap.getBigDecimal("TX_NO");
			retryCount = iMap.getBigDecimal("RETRY_COUNT");
			statusVendor = iMap.getString("STATUS_VENDOR");
			responseData = iMap.getString("RESPONSE_DATA");
			
			statusAfterRemoteCall = (String) DALUtil.callOracleFunction("{ ? = call pkg_tx.islem_durum(?) }", BnsprType.STRING, BnsprType.NUMBER, txNo);
			
			Session session = DAOSession.getSession("BNSPRDal");
			ClksislemLog islem = (ClksislemLog) session.get(ClksislemLog.class, txNo);
			
			islem.setRetryCount(retryCount);
			if(statusAfterRemoteCall.equals(statusVendor)) {
				islem.setReconciliationAutomationCode("S");
			} else if (retryCount.compareTo(new BigDecimal(4)) == 1) {
				islem.setReconciliationAutomationCode("U");
				body.append("��lem Numaras�: ").append(txNo.toString()).append("\nSon Al�nan Hata: ").append(responseData);
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "CLKS_SCHEDULER_RA_MAIL_TO")).getString("DEGER"));
				mailMap.put("TRX_NO", txNo);
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "PTT Sorunlu ��lem Otomasyonu - ��z�mlenemeyen ��lem");
				mailMap.put("MAIL_BODY", body.toString());
				mailMap.put("IS_BODY_HTML", "H");
				GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
			} else {
				islem.setReconciliationAutomationCode("P"); // Release
			}
			
			session.saveOrUpdate(islem);
			session.flush();
			
		} catch(Exception e) {
			logger.error("CLKS_RECONCILIATION_AUTOMATION_AFTER_REMOTE_CALL err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return new GMMap();
	}
	
	private static GMMap remoteCall(String serviceName, GMMap iMap) {
		
		GMConnection connection = null;
		GMMap oMap = new GMMap();
		
		try {
			
			connection = GMConnection.getConnection("DEALER");
			oMap.putAll(ADCCoreUtil.remoteCall(connection, serviceName, iMap));

		} catch(IOException e) {
			logger.error(e);
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("CONNFAIL", new GMMap()));
		} catch(Exception e) {
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", e.getMessage());
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (IOException e) {
					logger.error(e);
				}
			}
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY2062_RC_PTT_KOM_MUTABAKAT_KONTROL")
    public static GMMap getKomMutabakatKontrolList(GMMap iMap) {

        GMMap oMap = new GMMap();

        ArrayList<String> recipientsList;
        String messageBody = "ISLEM_TARIHI" + "  " + "ISLEM_TIP" + "  " + "ISLEM_SAYISI";

        String procStr = "{ call PKG_RC2062.Kom_Mutabakat_Kontrol_Job(?)}";
        int i = 0;
        Object[] inputValues = new Object[0];
        Object[] outputValues = new Object[2];

        try {

            i = 0;

            outputValues[i++] = BnsprType.REFCURSOR;
            outputValues[i++] = "PTT_ISLEM_LIST";

            GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
            oMap.putAll(resultMap);

            String tableName = "PTT_ISLEM_LIST";

            GMMap mailServisMap = new GMMap();
            GMMap iMapG = new GMMap();
            iMapG.put("KOD", "PTT_KBB_MAIL_FROM");
            String fromMail = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
            mailServisMap.put("FROM", fromMail);

            iMapG.put("KOD", "PTT_KOM_MUTABAKAT_MAIL_TO");
            // TO : Karar Destek ve Analitik Birimi, D�� Kaynak Kurum Uygulamalar� Geli�tirme Birimi
            String toMail = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");

            recipientsList = null;
            if (toMail != null) {
                recipientsList = new ArrayList<String>();
                recipientsList.addAll(Arrays.asList(toMail.split(";")));
            }

            mailServisMap.put("RECIPIENTS_TO", recipientsList);
            mailServisMap.put("SUBJECT", getIslemTarihi(iMap).getString("TARIH") + " " + "Komisyon Hesaplamas� Yap�lamam�� ��lemler");
            
            if (oMap.get(tableName) != null) {
                for (int k = 0; k < oMap.getSize(tableName); k++) {

                    messageBody = messageBody + "\n" + oMap.getString(tableName, k, "ISLEM_TARIHI") + "  " + oMap.getString(tableName, k, "ISLEM_TIP") + "  " + oMap.getString(tableName, k, "ISLEM_SAYISI");
                }
            }
            else {
                messageBody = "Komisyonu s�f�r hesaplanm�� i�lem bulunmamaktad�r.";
            }

            mailServisMap.put("MESSAGE_BODY", messageBody);
            mailServisMap.put("IS_BODY_HTML", "H");

            GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailServisMap);

        }
        catch (Exception e) {
            logger.error("BNSPR_QRY2062_RC_PTT_KOM_MUTABAKAT_KONTROL err:", e);
            throw ExceptionHandler.convertException(e);
        }
        return oMap;

    }

    // Bir onceki ay icinde komisyon tutari sifir hesaplanm�s kayit yok ise komisyon hesap ayini doner
    private static GMMap getIslemTarihi(GMMap iMap) {

        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();

            String q = "select to_char(last_day(add_months(pkg_muhasebe.Banka_Tarihi_Bul, -1)),'Month')" + " " +
                       "|| to_char(last_day(add_months(pkg_muhasebe.Banka_Tarihi_Bul, -1)),'yyyy') TARIH from dual";

            stmt = conn.prepareCall(q);
            rSet = stmt.executeQuery();
            while (rSet.next()) {
                oMap.put("TARIH", rSet.getString("TARIH"));
            }
            return oMap;

        }
        catch (Exception e) {
            logger.error("getIslemTarihi err:", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
}
