package tr.com.aktifbank.bnspr.token.services;

import java.awt.Color;
import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import jxl.Workbook;
import jxl.write.DateFormat;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.HardTokenTalep;
import tr.com.aktifbank.bnspr.dao.HardTokenTalepTx;
import tr.com.aktifbank.bnspr.dao.KibKullaniciTanim;
import tr.com.aktifbank.bnspr.dao.KibKullaniciTanimId;
import tr.com.aktifbank.bnspr.dao.KibKullaniciTanimTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.obss.adc.core.otp.pojo.Token;
import tr.com.obss.adc.core.pojo.Channel;
import tr.com.obss.adc.core.pojo.User;
import tr.com.obss.adc.core.util.ADCCore;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TokenServices {
	private static long oneDay=(long) (24*60*60*1000);
	// private static String ARIZALI_CIHAZ = "ARIZALI_CIHAZ";
    private static String BASVURU_ALINDI = "BASVURU_ALINDI";
	private static String BASVURU_ONAYLANDI = "BASVURU_ONAYLANDI";
	// private static String BASVURU_REDDEDILDI = "BASVURU_REDDEDILDI";
	private static String ESLESTIRILDI = "ESLESTIRILDI";
	// private static String KAYIP_CALINTI = "KAYIP_CALINTI";
	private static String KULLANIMDA = "KULLANIMDA";
	private static String KURYEDE = "KURYEDE";
	// private static String KURYEDEN_IADE = "KURYEDEN_IADE";
	// private static String MUSTERI_ARIZA_BILDIRIM = "MUSTERI_ARIZA_BILDIRIM";
	// private static String MUSTERI_IADE = "MUSTERI_IADE";
	//	private static String TANIMLANMAMIS = "TANIMLANMAMIS";
	// private static String TEDARIKCIYE_GONDERILDI = "TEDARIKCIYE_GONDERILDI";

	private static String OPERATION_CHANNEL_CINT = "CINT";
	private static String AKTIF_SIFRE_TALEP_YOK = "0";
	private static String AKTIF_SIFRE_TALEP_VAR_VE_AKTIF = "3";
	private static String AKTIF_SIFRE_TALEPTX_VAR_AMA_TALEP_YOK = "4";
	private static String AKTIF_SIFRE_TALEP_VAR_AMA_AKTIF_DEGIL = "5";

	private static String CHANNEL_KURUMSAL_INTERNET_BANKACILIGI = "CINT";
	private static String CHANNEL_CAGRI_MERKEZI = "CC";

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat(
			"dd.MM.yyyy");
	public static final String projeKodu = "GMS200513";
	private static String ROOT = GMServer.getProperty("graymound.home", null)
			+ File.separator + "Server" + File.separator + "Content"
			+ File.separator + "Root";
	public static WritableCellFormat cellDateFormat = new WritableCellFormat(
			new DateFormat("dd.MM.yyyy"));

	@GraymoundService(value = "ADC_MAN_USER_TOKEN_BASVURU")
	public static GMMap createHardTokenTalep(GMMap iMap) {
		GMMap oMap = new GMMap();

		String kullaniciId = iMap.getString("KULLANICI_ID");
		String firmaId = iMap.getString("FIRMA_ID");
		String hesapNo = iMap.getString("HESAP_NO");
		iMap.put("USER_CODE", kullaniciId + "@" + firmaId);

		if (iMap.getBigDecimal("HESAP_NO") == null) {
			iMap.put("MESSAGE_NO", new BigDecimal(2792));
			oMap.put(
					"MESSAGE",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "0");
			return oMap;
		}

		if (iMap.getString("ADRES") == null) {
			iMap.put("MESSAGE_NO", new BigDecimal(2762));
			oMap.put(
					"MESSAGE",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "0");
			return oMap;
		}

		GMMap oidGMap=new GMMap().put("USER_CODE", kullaniciId + "@" + firmaId);
		findOidFromCodes(oidGMap);
		String userOid = oidGMap.getString("USER_OID");

		Session session = null;
		GMMap i2Map = new GMMap();
		try {
			session = DAOSession.getSession("BNSPRDal");

			iMap.put("KULLANICI_KODU", iMap.get("KULLANICI_ID"));
			iMap.put("FIRMA_KODU", iMap.get("FIRMA_ID"));
			GMMap tokenTalepGmap = getTokenTalep(iMap);

			if (!(tokenTalepGmap.get("RESPONSE").equals(AKTIF_SIFRE_TALEP_YOK) || tokenTalepGmap
					.get("RESPONSE").equals(
							AKTIF_SIFRE_TALEP_VAR_AMA_AKTIF_DEGIL))) {
				GMMap myMap = new GMMap();
				myMap.put("MESSAGE_NO", new BigDecimal(2746));
				String message = (String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_KODSUZ_MESSAGE", myMap).get(
						"ERROR_MESSAGE");
				oMap.put("RESPONSE", "1");
				oMap.put("RESPONSE_DATA", message);
				oMap.put("MESSAGE", message);
				return oMap;
			}

			Integer talepId = GMServiceExecuter.call(
					"BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getInt("SIRA_NO");

			HardTokenTalepTx hardTokenTalepTx = new HardTokenTalepTx();
			hardTokenTalepTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			hardTokenTalepTx.setTalepId(talepId);
			hardTokenTalepTx.setOperationChannel(iMap.getString("CHANNEL_ID"));
			// hardTokenTalepTx.setOperationDate(new Date());
			hardTokenTalepTx.setOperationStatus(BASVURU_ALINDI);
			// hardTokenTalepTx.setOperationUser("Unknown");
			hardTokenTalepTx.setUserOId(userOid);
			hardTokenTalepTx.setAccountNo(hesapNo);
			session.saveOrUpdate(hardTokenTalepTx);
			session.flush();

			i2Map.put("TRX_NAME", "4300");
			i2Map.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", i2Map);

			GMMap talepGmap = getTokenTalep(iMap);
			if (talepGmap.get("RESPONSE")
					.equals(AKTIF_SIFRE_TALEP_VAR_VE_AKTIF)) {
				oMap.put("APPROVED", "YES");
				
				GMMap myMap = new GMMap();
				myMap.put("MESSAGE_NO", new BigDecimal(2900));
				oMap.put(
						"RETURN_VALUE",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_KODSUZ_MESSAGE", myMap).get(
								"ERROR_MESSAGE"));
				oMap.put("RESPONSE", "2");
			} else {
				oMap.put("APPROVED", "NO");
				
				GMMap myMap = new GMMap();
				myMap.put("MESSAGE_NO", new BigDecimal(302));
				iMap.put("P1", hardTokenTalepTx.getTxNo().toString());
				oMap.put(
						"RETURN_VALUE",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_KODSUZ_MESSAGE", myMap).get(
								"ERROR_MESSAGE"));
				oMap.put("RESPONSE", "2");
			}

			return oMap;
		} catch (Exception e) {
			session.close();
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService(value = "ADC_MAN_USER_TOKEN_BASVURU_VIEW_INIT")
	public static GMMap viewHardTokenTalep(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		HardTokenTalepTx talep = (HardTokenTalepTx)session
				.createCriteria(HardTokenTalepTx.class)
				.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
		
		Session adcSession = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		
		User user = (User)adcSession
				.createCriteria(User.class)
				.add(Restrictions.eq("oid", talep.getUserOId())).uniqueResult();
		
		GMMap accountIMap=new GMMap();
		accountIMap.put("TABLE_NAME", "ACCOUNT_LIST");
		accountIMap.put("MUSTERI_NO", user.getCustomerId().toString());
		accountIMap.put("KULLANICI_NO", user.getUserCustomerId().toString());
		accountIMap.put("HESAP_KISIT_FLAG", "110");
		
		GMMap accountOMap = GMServiceExecuter.call(
				"INTERNET_GET_KIB_HESAP_LIST", accountIMap);
		
		int rowSelected=-1;
		BigDecimal accountNo=null;
		int size=((ArrayList)accountOMap.get("ACCOUNT_LIST")).size();
		
		String colorTableName = "TBL_COLOR";
		
		for (int row = 0; row < size; row++) {
			accountNo= accountOMap.getBigDecimal("ACCOUNT_LIST", row, "HESAP_NO");
			if (accountNo!=null && accountNo.toString().equals(talep.getAccountNo())) {
				rowSelected=row;
				oMap.put(colorTableName, row, "HESAP_NO",getTableCellColorData(Color.GREEN));
		        oMap.put(colorTableName, row, "RUMUZ", getTableCellColorData(Color.GREEN));
		        oMap.put(colorTableName, row, "HESAP_TIPI", getTableCellColorData(Color.GREEN));
		        oMap.put(colorTableName, row, "SUBE", getTableCellColorData(Color.GREEN));
		        oMap.put(colorTableName, row, "BAKIYE", getTableCellColorData(Color.GREEN));
		        oMap.put(colorTableName, row, "KULLANILABILIR_BAKIYE", getTableCellColorData(Color.GREEN));
		        oMap.put(colorTableName, row, "KMH_LIMIT", getTableCellColorData(Color.GREEN));
			}else {
				oMap.put(colorTableName, row, "HESAP_NO",getTableCellColorData(Color.WHITE));
		        oMap.put(colorTableName, row, "RUMUZ", getTableCellColorData(Color.WHITE));
		        oMap.put(colorTableName, row, "HESAP_TIPI", getTableCellColorData(Color.WHITE));
		        oMap.put(colorTableName, row, "SUBE", getTableCellColorData(Color.WHITE));
		        oMap.put(colorTableName, row, "BAKIYE", getTableCellColorData(Color.WHITE));
		        oMap.put(colorTableName, row, "KULLANILABILIR_BAKIYE", getTableCellColorData(Color.WHITE));
		        oMap.put(colorTableName, row, "KMH_LIMIT", getTableCellColorData(Color.WHITE));
			}
		}
		
		oMap.put("ACCOUNT_NO_SEQ", rowSelected);
		
		oMap.put("FIRMA_ID", user.getCustomerId());
		oMap.put("KULLANICI_ID", user.getUserCustomerId());
		
		oMap.put("FIRMA_AD", LovHelper.diLov(user.getCustomerId(), "4155/LOV_MUSTERI_NO", "MUSTERI_ADI")); 
		oMap.put("KULLANICI_AD", LovHelper.diLov(user.getUserCustomerId(), "4155/LOV_MUSTERI_NO", "MUSTERI_ADI")); 
		
		return oMap;
	}
		     
	private static GMMap getTableCellColorData(Color backgroundColor) {
		GMMap oMap = new GMMap();
		oMap.put("setBackground", backgroundColor);
		return oMap;
	}

	@GraymoundService(value = "ADC_MAN_USER_TOKEN_AKTIVASYON")
	public static GMMap activateHardTokenTalep(GMMap iMap) {
		GMMap oMap = new GMMap();

		String seriNo = iMap.getString("SERI_NO");
		iMap.put("SERIAL", seriNo);
		// String password = iMap.getString("PASSWORD");

		Session session = null;
		GMMap i2Map = new GMMap();
		try {
			session = DAOSession.getSession("BNSPRDal");

			GMMap activateOMap = GMServiceExecuter.call(
					"BNSPR_EXTERNAL_HARD_TOKEN_VERIFY_PASSWORD", iMap);

			if (activateOMap.getString("RESPONSE") != null
					&& activateOMap.get("RESPONSE").equals("0")) {
				iMap.put("MESSAGE_NO", new BigDecimal(2783));
				oMap.put(
						"RESPONSE_DATA",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
								"ERROR_MESSAGE"));
				oMap.put("RESPONSE", "0");
				return oMap;
			}

			HardTokenTalep talep = null;
			GMMap validOMap = validateTokenActivation(iMap);

			if (!validOMap.getString("RESPONSE").equals("3")) {
				return validOMap;
			} else {
				@SuppressWarnings("unchecked")
				List<HardTokenTalep> talepList = session
						.createCriteria(HardTokenTalep.class)
						.add(Restrictions.eq("tokenId", seriNo))
						.addOrder(Order.desc("operationDate")).list();
				talep = (HardTokenTalep) talepList.get(0);
			}

			if (activateOMap.getString("RESPONSE") != null
					&& !activateOMap.getString("RESPONSE").equals("0")) {
				BigDecimal txNo = GMServiceExecuter.call(
						"BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal(
						"TRX_NO");

				HardTokenTalepTx hardTokenTalepTx = new HardTokenTalepTx();
				hardTokenTalepTx.setTxNo(txNo);
				hardTokenTalepTx.setOperationChannel(OPERATION_CHANNEL_CINT);
				hardTokenTalepTx.setOperationStatus(KULLANIMDA);
				hardTokenTalepTx.setUserOId(talep.getUserOId());
				hardTokenTalepTx.setTokenId(seriNo);
				hardTokenTalepTx.setTalepId(talep.getId());

				session.saveOrUpdate(hardTokenTalepTx);
				session.flush();

				i2Map.put("TRX_NAME", "4331");
				i2Map.put("TRX_NO", txNo);
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", i2Map);
				
				iMap.remove("USER_OID");
			    iMap.put("SECURITY_OPTION", "TOKEN");
				GMServiceExecuter.execute("ADC_MAN_USER_KIB_GUVENLIK_YONTEMI_DEGISTIR",
						iMap);

				iMap.put("MESSAGE_NO", new BigDecimal(2782));
				oMap.put(
						"RESPONSE_DATA",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
								"ERROR_MESSAGE"));
				oMap.put("RESPONSE", "2");
			} else {
				iMap.put("MESSAGE_NO", new BigDecimal(2783));
				oMap.put(
						"RESPONSE_DATA",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
								"ERROR_MESSAGE"));
				oMap.put("RESPONSE", "0");
			}
			return oMap;
		} catch (Exception e) {
			session.close();
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("ADC_MAN_USER_TOKEN_AKTIVASYON_VALIDATION")
	public static GMMap validateTokenActivation(GMMap iMap) {
		GMMap oMap = new GMMap();

		String seriNo = iMap.getString("SERI_NO");
		// String password = iMap.getString("PASSWORD");

		Session session = DAOSession.getSession("BNSPRDal");

		GMMap talepOutMap = getTokenTalep(iMap);

		if (talepOutMap.getString("RESPONSE").equals(AKTIF_SIFRE_TALEP_YOK)
				|| talepOutMap.getString("RESPONSE").equals(
						AKTIF_SIFRE_TALEP_VAR_AMA_AKTIF_DEGIL)) {
			iMap.put("MESSAGE_NO", new BigDecimal(2745));
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "1");
			return oMap;
		}

		@SuppressWarnings("unchecked")
		List<HardTokenTalep> talepList = session
				.createCriteria(HardTokenTalep.class)
				.add(Restrictions.eq("tokenId", seriNo))
				.addOrder(Order.desc("operationDate")).list();

		if (talepList == null || talepList.size() == 0) {
			iMap.put("MESSAGE_NO", new BigDecimal(2781));
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "1");
			return oMap;
		}

		@SuppressWarnings("unchecked")
		List<HardTokenTalepTx> txList = session
				.createCriteria(HardTokenTalepTx.class)
				.add(Restrictions.eq("talepId", talepList.get(0).getId()))
				.addOrder(Order.desc("operationDate")).list();

		if (!talepList.get(0).getOperationStatus().equals("KURYEDE")) {
			for (HardTokenTalepTx hardTokenTalepTx : txList) {
				if (hardTokenTalepTx.getOperationStatus().equals("KULLANIMDA")) {
					iMap.put("MESSAGE_NO", new BigDecimal(2784));
					oMap.put("RESPONSE_DATA", (String) GMServiceExecuter
							.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap)
							.get("ERROR_MESSAGE"));
					oMap.put("RESPONSE", "1");
					return oMap;
				}
			}
			iMap.put("MESSAGE_NO", new BigDecimal(2781));
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "1");
			return oMap;
		}

		oMap.put("RESPONSE", "3");
		return oMap;
	}

	@GraymoundService(value = "ADC_MAN_USER_TOKEN_VERIFY_PASSWORD")
	public static GMMap verifyPassword(GMMap iMap) {
		GMMap oMap = new GMMap();

		String serial = iMap.getString("SERIAL");
		String password = iMap.getString("PASSWORD");

		if (serial == null) {
			iMap.put("MESSAGE_NO", new BigDecimal(330));
			iMap.put("P1", "CIHAZ SERI NO");
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "0");
			return oMap;
		}

		if (password == null) {
			iMap.put("MESSAGE_NO", new BigDecimal(330));
			iMap.put("P1", "PASSWORD");
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "0");
			return oMap;
		}

		try {

			GMMap activateOMap = GMServiceExecuter.call(
					"BNSPR_EXTERNAL_HARD_TOKEN_VERIFY_PASSWORD", iMap);

			if (activateOMap.getString("RESPONSE").equals("0")) {
				activateOMap.put("RESPONSE_DATA", "fail");
			} else if (activateOMap.getString("RESPONSE").equals("2")) {
				activateOMap.put("RESPONSE_DATA", "success");
			}

			return activateOMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService(value = "ADC_MAN_USER_TOKEN_BASVURU_INITIALIZE")
	public static GMMap findTokenTalep(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tokenTalepGmap = getTokenTalep(iMap);

		Session session = DAOSession.getSession("BNSPRDal");

		KibKullaniciTanimId id = new KibKullaniciTanimId();
		id.setFirmaNo(new BigDecimal(iMap.getString("FIRMA_KODU")));
		id.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU"));
		KibKullaniciTanim kibKullaniciTanim = (KibKullaniciTanim) session.get(
				KibKullaniciTanim.class, id);

		if (!(tokenTalepGmap.get("RESPONSE").equals(AKTIF_SIFRE_TALEP_YOK) || tokenTalepGmap
				.get("RESPONSE").equals(AKTIF_SIFRE_TALEP_VAR_AMA_AKTIF_DEGIL))) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(2746));
			oMap.put("RESPONSE", "1");
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", myMap).get(
							"ERROR_MESSAGE"));
			return oMap;
		} else if (kibKullaniciTanim.getYetkiTuru().equals("1")) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(2817));
			oMap.put("RESPONSE", "1");
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", myMap).get(
							"ERROR_MESSAGE"));
			return oMap;
		} else {
			oMap.put("RESPONSE", "3");
			return oMap;
		}
	}

	@GraymoundService(value = "ADC_MAN_USER_TOKEN_BASVURU_BUL")
	public static GMMap getTokenTalep(GMMap iMap) {

		GMMap oMap = new GMMap();
		boolean onlySeriNo = false;
		if (iMap.get("USER_OID") == null) {
			iMap.put("USER_CODE",
					iMap.get("KULLANICI_KODU") + "@" + iMap.get("FIRMA_KODU"));
			findOidFromCodes(iMap);
		} else {
			onlySeriNo = true;
		}
		
		findCodesFromOid(iMap);
		
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		Session sessionAdc = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		@SuppressWarnings("unchecked")
		List<User> userList = sessionAdc.createCriteria(User.class)
				.add(Restrictions.eq("userCustomerId", iMap.getBigDecimal("KULLANICI_KODU"))).list();
		
		String[] oids=new String[userList.size()];
		
		int row=0;
		for (User user : userList) {
			oids[row++]=user.getOid();
		}

		@SuppressWarnings("unchecked")
		List<HardTokenTalepTx> talepLer = session
				.createCriteria(HardTokenTalepTx.class)
				.add(Restrictions.in("userOId", oids))
				.addOrder(Order.desc("operationDate")).list();
		if (talepLer == null || talepLer.size() == 0) {
			oMap.put("RESPONSE", AKTIF_SIFRE_TALEP_YOK);
		} else {

			@SuppressWarnings("unchecked")
			List<HardTokenTalep> talepList = session
					.createCriteria(HardTokenTalep.class)
					.add(Restrictions.eq("id", talepLer.get(0).getTalepId()))
					.addOrder(Order.desc("operationDate")).list();

			if (talepList == null || talepList.size() == 0) {
				oMap.put("RESPONSE", AKTIF_SIFRE_TALEPTX_VAR_AMA_TALEP_YOK);
				if(!onlySeriNo){
					oMap.put("TALEP_TX", talepLer.get(0));
				}
			} else {
				if (talepList.get(0).getOperationStatus().equals(KULLANIMDA)
						|| talepList.get(0).getOperationStatus()
								.equals(BASVURU_ONAYLANDI)
						|| talepList.get(0).getOperationStatus()
								.equals(ESLESTIRILDI)
						|| talepList.get(0).getOperationStatus()
								.equals(KURYEDE)
						|| talepList.get(0).getOperationStatus()
								.equals(BASVURU_ALINDI)) {
					oMap.put("RESPONSE", AKTIF_SIFRE_TALEP_VAR_VE_AKTIF);
					if (onlySeriNo) {
						oMap.put("SERI_NO", talepList.get(0).getTokenId());
					} else {
						oMap.put("TALEP", talepList.get(0));
					}
				} else {
					oMap.put("RESPONSE", AKTIF_SIFRE_TALEP_VAR_AMA_AKTIF_DEGIL);
					if (onlySeriNo) {
						oMap.put("SERI_NO", talepList.get(0).getTokenId());
					} else {
						oMap.put("TALEP", talepList.get(0));
					}
				}
			}
		}
		return oMap;
	}

	@GraymoundService(value = "ADC_MAN_USER_KIB_GUVENLIK_YONTEMI_INITIALIZE")
	public static GMMap initSecurityManagementType(GMMap iMap) {
		GMMap oMap = new GMMap();

		BigDecimal kullanici_kod = iMap.getBigDecimal("KULLANICI_KODU");
		BigDecimal firma_kod = iMap.getBigDecimal("FIRMA_KODU");

		GMMap tokenGMap = getTokenTalep(iMap);

		if (tokenGMap.get("RESPONSE").equals(AKTIF_SIFRE_TALEP_YOK)
				|| tokenGMap.get("RESPONSE").equals(
						AKTIF_SIFRE_TALEP_VAR_AMA_AKTIF_DEGIL)) {
			iMap.put("MESSAGE_NO", new BigDecimal(2777));
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "1");
			return oMap;
		}

		if (tokenGMap.getString("RESPONSE").equals(
				AKTIF_SIFRE_TALEPTX_VAR_AMA_TALEP_YOK)) {
			iMap.put("MESSAGE_NO", new BigDecimal(2780));
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
							"ERROR_MESSAGE"));
			oMap.put("RESPONSE", "1");
			return oMap;
		} else if (tokenGMap.getString("RESPONSE").equals(
				AKTIF_SIFRE_TALEP_VAR_VE_AKTIF)) {
			HardTokenTalep token = (HardTokenTalep) tokenGMap.get("TALEP");

			if (token.getOperationStatus().equals("KURYEDE")) {
				iMap.put("MESSAGE_NO", new BigDecimal(2779));
				oMap.put(
						"RESPONSE_DATA",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
								"ERROR_MESSAGE"));
				oMap.put("RESPONSE", "1");
				return oMap;
			}

			if (!token.getOperationStatus().equals("KULLANIMDA")) {
				iMap.put("MESSAGE_NO", new BigDecimal(2780));
				oMap.put(
						"RESPONSE_DATA",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
								"ERROR_MESSAGE"));
				oMap.put("RESPONSE", "1");
				return oMap;
			}
		}

		Session session = DAOSession.getSession("BNSPRDal");

		KibKullaniciTanimId id = new KibKullaniciTanimId();
		id.setFirmaNo(firma_kod);
		id.setKullaniciNo(kullanici_kod);
		KibKullaniciTanim kibKullaniciTanim = (KibKullaniciTanim) session.get(
				KibKullaniciTanim.class, id);

		if (kibKullaniciTanim.getGuvenlikYonetimi() == null
				|| kibKullaniciTanim.getGuvenlikYonetimi().equals("")) {
			oMap.put("SECURITY_OPTION", "");
		} else if (kibKullaniciTanim.getGuvenlikYonetimi().equals("1")) {
			oMap.put("SECURITY_OPTION", "OTP");
		} else if (kibKullaniciTanim.getGuvenlikYonetimi().equals("2")) {
			oMap.put("SECURITY_OPTION", "TOKEN");
		} else {
			oMap.put("SECURITY_OPTION", "");
		}

		oMap.put("RESPONSE", "4");
		return oMap;

	}

	@GraymoundService(value = "ADC_MAN_USER_KIB_GUVENLIK_YONTEMI_SORGULA")
	public static GMMap querySecurityManagementType(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		KibKullaniciTanimId id = new KibKullaniciTanimId();
		id.setFirmaNo(iMap.getBigDecimal("FIRMA_KODU"));
		id.setKullaniciNo(iMap.getBigDecimal("KULLANICI_KODU"));
		KibKullaniciTanim kibKullaniciTanim = (KibKullaniciTanim) session.get(
				KibKullaniciTanim.class, id);

		if (kibKullaniciTanim.getGuvenlikYonetimi() == null
				|| kibKullaniciTanim.getGuvenlikYonetimi().equals("")) {
			oMap.put("SECURITY_OPTION", "");
		} else if (kibKullaniciTanim.getGuvenlikYonetimi().equals("1")) {
			oMap.put("SECURITY_OPTION", "OTP");
		} else if (kibKullaniciTanim.getGuvenlikYonetimi().equals("2")) {
			oMap.put("SECURITY_OPTION", "TOKEN");
		} else {
			oMap.put("SECURITY_OPTION", "");
		}
		return oMap;

	}

	@GraymoundService(value = "ADC_MAN_USER_KIB_GUVENLIK_YONTEMI_DEGISTIR")
	public static GMMap changeSecurityManagementType(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap tx_map = new GMMap();
		tx_map = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap);

		BigDecimal txNo = tx_map.getBigDecimal("TRX_NO");
		BigDecimal kullanici_kod = iMap.getBigDecimal("KULLANICI_KODU");
		BigDecimal firma_kod = iMap.getBigDecimal("FIRMA_KODU");

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			if (iMap.getString("FIRMA_KODU") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Firma Kodu");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("SECURITY_OPTION") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Güvenlik Yöntemi");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("KULLANICI_KODU") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kullanıcı Kodu");
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("SECURITY_OPTION").equals("TOKEN")) {
				GMMap tokenGMap = getTokenTalep(iMap);

				if (tokenGMap.get("RESPONSE").equals(AKTIF_SIFRE_TALEP_YOK)
						|| tokenGMap.get("RESPONSE").equals(
								AKTIF_SIFRE_TALEP_VAR_AMA_AKTIF_DEGIL)) {
					iMap.put("MESSAGE_NO", new BigDecimal(2777));
					oMap.put("RESPONSE_DATA", (String) GMServiceExecuter
							.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap)
							.get("ERROR_MESSAGE"));
					oMap.put("RESPONSE", "1");
				}

				if (tokenGMap.getString("RESPONSE").equals(AKTIF_SIFRE_TALEPTX_VAR_AMA_TALEP_YOK)) {
					iMap.put("MESSAGE_NO", new BigDecimal(2780));
					oMap.put("RESPONSE_DATA", (String) GMServiceExecuter
							.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap)
							.get("ERROR_MESSAGE"));
					oMap.put("RESPONSE", "1");
				} else if (tokenGMap.getString("RESPONSE").equals(AKTIF_SIFRE_TALEP_VAR_VE_AKTIF)) {
					HardTokenTalep token = (HardTokenTalep) tokenGMap
							.get("TALEP");

					if (token.getOperationStatus().equals("KURYEDE")) {
						iMap.put("MESSAGE_NO", new BigDecimal(2779));
						oMap.put(
								"RESPONSE_DATA",
								(String) GMServiceExecuter
										.execute(
												"BNSPR_COMMON_GET_KODSUZ_MESSAGE",
												iMap).get("ERROR_MESSAGE"));
						oMap.put("RESPONSE", "1");
					}

					if (!token.getOperationStatus().equals("KULLANIMDA")) {
						iMap.put("MESSAGE_NO", new BigDecimal(2780));
						oMap.put(
								"RESPONSE_DATA",
								(String) GMServiceExecuter
										.execute(
												"BNSPR_COMMON_GET_KODSUZ_MESSAGE",
												iMap).get("ERROR_MESSAGE"));
						oMap.put("RESPONSE", "1");
					}
				}
			}

			conn = DALUtil.getGMConnection();

			Session session = DAOSession.getSession("BNSPRDal");

			KibKullaniciTanimTx kibKullaniciTanimTx = new KibKullaniciTanimTx();

			kibKullaniciTanimTx.setTxNo(txNo);
			kibKullaniciTanimTx.setFirmaNo(firma_kod);
			kibKullaniciTanimTx.setKullaniciNo(kullanici_kod);

			if (iMap.getString("SECURITY_OPTION").equals("OTP")) {
				kibKullaniciTanimTx.setGuvenlikYonetimi("1");
			} else if (iMap.getString("SECURITY_OPTION").equals("TOKEN")) {
				kibKullaniciTanimTx.setGuvenlikYonetimi("2");
			} else {
				kibKullaniciTanimTx.setGuvenlikYonetimi(null);
			}
			

			KibKullaniciTanimId id = new KibKullaniciTanimId();
			id.setFirmaNo(firma_kod);
			id.setKullaniciNo(kullanici_kod);
			KibKullaniciTanim kibKullaniciTanim = (KibKullaniciTanim) session
					.get(KibKullaniciTanim.class, id);

			kibKullaniciTanimTx.setBlokeDurumu(kibKullaniciTanim
					.getBlokeDurumu());

			kibKullaniciTanimTx.setIp(kibKullaniciTanim.getIp());

			kibKullaniciTanimTx.setYetkiTuru(kibKullaniciTanim.getYetkiTuru());
			kibKullaniciTanimTx.setCepTelefonu(kibKullaniciTanim
					.getCepTelefonu());
			kibKullaniciTanimTx.setKullaniciTipi(kibKullaniciTanim
					.getKullaniciTipi());
			kibKullaniciTanimTx.setSeriNo(kibKullaniciTanim.getSeriNo());
			session.saveOrUpdate(kibKullaniciTanimTx);
			session.flush();

			iMap.put("TRX_NAME", "4330");
			iMap.put("TRX_NO", txNo);
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			iMap.put("ISLEM_NO", txNo);
			GMServiceExecuter.execute("BNSPR_TRN4202_CREATE_USER", iMap);

		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService(value = "ADC_MAN_USER_TOKEN_INITIALIZE")
	public static GMMap initializeToken(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("KOD", "HARD_TOKEN_GUNCELLEME");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put(
				"SIFRE_GUNCELLEME_LIST",
				GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
						iMap).get("RESULTS"));

		iMap.put("KOD", "HARD_TOKEN_TANIMLAMA");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put(
				"SIFRE_TANIMLAMA_LIST",
				GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
						iMap).get("RESULTS"));

		iMap.put("KOD", "HARD_TOKEN_DURUM");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put(
				"TOKEN_DURUMU_LIST",
				GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
						iMap).get("RESULTS"));

		iMap.put("KOD", "HARD_TOKEN_BASVURU_DURUM");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put(
				"TALEP_DURUMU_LIST",
				GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
						iMap).get("RESULTS"));

		iMap.put("KOD", "HARD_TOKEN_UCRET_DURUM");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put(
				"UCRET_DURUMU_LIST",
				GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
						iMap).get("RESULTS"));
		
		iMap.put("KOD", "HARD_TOKEN_STOK_STATUS");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put(
				"STOK_DURUMU_LIST",
				GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
						iMap).get("RESULTS"));
		
		GMMap oMap1 = new GMMap();
		GMMap oMap2 = new GMMap();
		oMap1 = getChannelList(iMap);
		int row = 0;
		for (int i = 0; i < oMap1.getSize("CHANNEL_LIST"); i++) {
			oMap2.put("TALEP_KANALI_LIST", row, "VALUE",
					oMap1.get("CHANNEL_LIST", row, "CODE"));
			oMap2.put("TALEP_KANALI_LIST", row, "NAME",
					oMap1.get("CHANNEL_LIST", row, "NAME"));
			row++;
		}
		oMap.put("TALEP_KANALI_LIST", oMap2.get("TALEP_KANALI_LIST"));

		GMMap validateSorgu = new GMMap();
		validateSorgu.put("MESSAGE_NO", new BigDecimal(2748));
		oMap.put(
				"V_VALIDATE_SORGU",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", validateSorgu).get(
						"ERROR_MESSAGE"));

		GMMap messageSelection = new GMMap();
		messageSelection.put("MESSAGE_NO", new BigDecimal(2749));
		oMap.put(
				"V_MESSAGE_SELECTION",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", messageSelection)
						.get("ERROR_MESSAGE"));

		GMMap message1 = new GMMap();
		message1.put("MESSAGE_NO", new BigDecimal(2750));
		oMap.put(
				"V_MESSAGE_1",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message1).get(
						"ERROR_MESSAGE"));

		GMMap message2 = new GMMap();
		message2.put("MESSAGE_NO", new BigDecimal(2751));
		oMap.put(
				"V_MESSAGE_2",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message2).get(
						"ERROR_MESSAGE"));

		GMMap message3 = new GMMap();
		message3.put("MESSAGE_NO", new BigDecimal(2752));
		oMap.put(
				"V_MESSAGE_3",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message3).get(
						"ERROR_MESSAGE"));

		GMMap message4 = new GMMap();
		message4.put("MESSAGE_NO", new BigDecimal(2753));
		oMap.put(
				"V_MESSAGE_4",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message4).get(
						"ERROR_MESSAGE"));

		GMMap message5 = new GMMap();
		message5.put("MESSAGE_NO", new BigDecimal(2754));
		oMap.put(
				"V_MESSAGE_5",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message5).get(
						"ERROR_MESSAGE"));

		GMMap message6 = new GMMap();
		message6.put("MESSAGE_NO", new BigDecimal(2755));
		oMap.put(
				"V_MESSAGE_6",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message6).get(
						"ERROR_MESSAGE"));

		GMMap message7 = new GMMap();
		message7.put("MESSAGE_NO", new BigDecimal(2756));
		oMap.put(
				"V_MESSAGE_7",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message7).get(
						"ERROR_MESSAGE"));

		GMMap message8 = new GMMap();
		message8.put("MESSAGE_NO", new BigDecimal(2757));
		oMap.put(
				"V_MESSAGE_8",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message8).get(
						"ERROR_MESSAGE"));

		GMMap message9 = new GMMap();
		message9.put("MESSAGE_NO", new BigDecimal(2758));
		oMap.put(
				"V_MESSAGE_9",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message9).get(
						"ERROR_MESSAGE"));

		GMMap message10 = new GMMap();
		message10.put("MESSAGE_NO", new BigDecimal(2764));
		oMap.put(
				"V_MESSAGE_10",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message10).get(
						"ERROR_MESSAGE"));

		GMMap message11 = new GMMap();
		message11.put("MESSAGE_NO", new BigDecimal(2765));
		oMap.put(
				"V_MESSAGE_11",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message11).get(
						"ERROR_MESSAGE"));

		GMMap message12 = new GMMap();
		message12.put("MESSAGE_NO", new BigDecimal(2766));
		oMap.put(
				"V_MESSAGE_12",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", message12).get(
						"ERROR_MESSAGE"));

		GMMap messageSenk = new GMMap();
		messageSenk.put("MESSAGE_NO", new BigDecimal(2802));
		oMap.put(
				"V_SENKRONIZASYON",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", messageSenk).get(
						"ERROR_MESSAGE"));

		GMMap messageGuncelleme = new GMMap();
		messageGuncelleme.put("MESSAGE_NO", new BigDecimal(2803));
		oMap.put(
				"V_GUNCELLEME",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", messageGuncelleme)
						.get("ERROR_MESSAGE"));

		GMMap messageTanimlama = new GMMap();
		messageTanimlama.put("MESSAGE_NO", new BigDecimal(2804));
		oMap.put(
				"V_TANIMLAMA",
				(String) GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_ERROR_MESSAGE", messageTanimlama)
						.get("ERROR_MESSAGE"));
		
		Session 	session				= DAOSession.getSession(ADCCore.SESSION_FACTORY);
		Channel		channel				= (Channel) session.createCriteria(Channel.class).add(Restrictions.eq("code", "CINT")).uniqueResult();

		if(iMap.getBigDecimal("FIRMA_KODU") != null) {
			
			findOidFromCodes(iMap);
			Token token = (Token) session.createCriteria(Token.class).add(Restrictions.eq("userOid", iMap.getString("USER_OID"))).add(Restrictions.eq("channelOid", channel.getOid())).uniqueResult();
			int failCount = token.getFailCount();
			
//			String failCount = channel.getParameters().get("ADC_OTP_FAIL_COUNT");
			
			oMap.put("BLOKE_SAYISI", failCount);
			oMap.put("BLOKE_LIMIT", channel.getParameters().get("ADC_OTP_FAIL_COUNT"));
			System.out.println(failCount + " FAAAILLLLLL");			
		}
		

		return oMap;
	}

	public static GMMap getChannelList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		int row = 0;

		oMap.put("CHANNEL_LIST", new ArrayList<Object>());
		String[] values = { CHANNEL_CAGRI_MERKEZI,
				CHANNEL_KURUMSAL_INTERNET_BANKACILIGI };

		Iterator<?> iterator = session.createCriteria(Channel.class)
				.addOrder(Order.asc("code"))
				.add(Restrictions.in("code", values)).list().iterator();

		oMap.put("CHANNEL_LIST", row, "OID", 0);
		oMap.put("CHANNEL_LIST", row, "CODE", "NONE");
		oMap.put("CHANNEL_LIST", row++, "NAME",
				GMMessageFactory.getMessage("PLSSELECT", null));

		while (iterator.hasNext()) {
			Channel channel = (Channel) iterator.next();
			oMap.put("CHANNEL_LIST", row, "OID", channel.getOid());
			oMap.put("CHANNEL_LIST", row, "CODE", channel.getCode());
			oMap.put("CHANNEL_LIST", row, "NAME",
					channel.getName(ADCSession.getLanguage()));
			row++;
		}

		oMap.put("ROW_COUNT", row);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN4300_GET_MUSTERI_ADRES")
	public static GMMap getMusteriAdres(GMMap iMap) {
		GMMap oMap = new GMMap();;

		// oMap.put(tableName , row , "DI_IL_KOD" ,
		// LovHelper.diLov(record.getIlKod() , "10011/LOV_ADRES_IL" ,
		// "IL_ADI"));
		// oMap.put(tableName , row , "DI_ILCE_KOD" ,
		// LovHelper.diLov(record.getIlceKod() , record.getIlKod() ,
		// "10011/LOV_ADRES_ILCE" , "ILCE_ADI"));
		// oMap.put(tableName , row , "DI_ULKE_KODU" ,
		// LovHelper.diLov(record.getUlkeKod() , "10011/LOV_ULKE" ,
		// "ULKE_ADI"));

		// ps_adres OUT GNL_MUSTERI_ADRES.adres%TYPE,
		// ps_semt OUT GNL_MUSTERI_ADRES.semt%TYPE,
		// ps_il_kod OUT GNL_MUSTERI_ADRES.il_kod%TYPE,
		// ps_ilce_kod OUT gnl_musteri_adres.ilce_kod%TYPE,
		// pn_posta_kod OUT GNL_MUSTERI_ADRES.posta_kod%TYPE,
		// ps_ulke_kod OUT GNL_MUSTERI_ADRES.ulke_kod%TYPE)

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call pkg_musteri.Musteri_Adres(?,?,?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.execute();

			StringBuilder tamAdresBuilder = new StringBuilder();
			tamAdresBuilder.append(stmt.getString(2));
			tamAdresBuilder.append(" ");
			tamAdresBuilder.append(stmt.getString(3));
			tamAdresBuilder.append(" ");
			tamAdresBuilder.append(LovHelper.diLov(stmt.getString(5),
					stmt.getString(4), "10011/LOV_ADRES_ILCE", "ILCE_ADI"));
			tamAdresBuilder.append(" ");
			tamAdresBuilder.append(LovHelper.diLov(stmt.getString(4),
					"10011/LOV_ADRES_IL", "IL_ADI"));
			// tamAdresBuilder.append(" ");
			// tamAdresBuilder.append(stmt.getString(6));
			tamAdresBuilder.append(" ");
			tamAdresBuilder.append(LovHelper.diLov(stmt.getString(7),
					"10011/LOV_ULKE", "ULKE_ADI"));

			oMap.put("TAM_ADRES", tamAdresBuilder.toString());
		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService(value = "ADC_MAN_USER_TOKEN_KIB_BASVURU_IZLEME")
	public static GMMap kibHardTokenTalepIzleme(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("KULLANICI_KODU", iMap.get("KULLANICI_ID"));
		iMap.put("FIRMA_KODU", iMap.get("FIRMA_ID"));
		GMMap tokenTalepGmap = getTokenTalep(iMap);

		if (tokenTalepGmap.get("RESPONSE").equals(AKTIF_SIFRE_TALEP_YOK)
				|| tokenTalepGmap.get("RESPONSE").equals(
						AKTIF_SIFRE_TALEP_VAR_AMA_AKTIF_DEGIL)) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(2745));
			oMap.put("RESPONSE", "1");
			oMap.put(
					"RESPONSE_DATA",
					(String) GMServiceExecuter.execute(
							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", myMap).get(
							"ERROR_MESSAGE"));
			return oMap;
		} else if (tokenTalepGmap.get("RESPONSE").equals(
				AKTIF_SIFRE_TALEPTX_VAR_AMA_TALEP_YOK)) {

			HardTokenTalepTx talepTx = (HardTokenTalepTx) tokenTalepGmap
					.get("TALEP_TX");

			oMap.put("TALEP_TARIHI",
					dateFormat.format(talepTx.getOperationDate()));

			iMap.put("KOD", "HARD_TOKEN_BASVURU_DURUM");
			iMap.put("KEY", talepTx.getOperationStatus());
			oMap.put("DURUM",
					GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap)
							.get("TEXT"));
			
//			iMap.put("MESSAGE_NO", new BigDecimal(2902));
//			oMap.put(
//					"DURUM",
//					(String) GMServiceExecuter.execute(
//							"BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get(
//							"ERROR_MESSAGE"));
			
		} else if (tokenTalepGmap.get("RESPONSE").equals(
				AKTIF_SIFRE_TALEP_VAR_VE_AKTIF)) {
			HardTokenTalep talepLast = (HardTokenTalep) tokenTalepGmap
					.get("TALEP");
			Session session = null;
			try {
				session = DAOSession.getSession("BNSPRDal");
				@SuppressWarnings("unchecked")
				List<HardTokenTalepTx> talepTxList = session
						.createCriteria(HardTokenTalepTx.class)
						.add(Restrictions.eq("talepId", talepLast.getId()))
						.addOrder(Order.asc("operationDate")).list();

				oMap.put("SERI_NO", talepLast.getTokenId()); 
				oMap.put("SERI_NO_VISUAL", formatSeriNo(talepLast.getTokenId()==null?null:talepLast.getTokenId().substring(0, 10))); 
				oMap.put("TALEP_TARIHI", dateFormat.format(talepTxList.get(0).getOperationDate()));

				HardTokenTalepTx hardTokenTalepKullanimda = null;
				for (@SuppressWarnings("rawtypes")
				Iterator iterator = talepTxList.iterator(); iterator.hasNext();) {
					HardTokenTalepTx hardTokenTalepTx = (HardTokenTalepTx) iterator
							.next();

					if (hardTokenTalepTx.getOperationStatus().equals(
							"KULLANIMDA")) {
						hardTokenTalepKullanimda = hardTokenTalepTx;
						break;
					}

				}

				if (hardTokenTalepKullanimda != null) {
					oMap.put("AKTIFLENME_TARIHI",
							dateFormat.format(hardTokenTalepKullanimda
									.getOperationDate()));
				}

				iMap.put("KOD", "HARD_TOKEN_BASVURU_DURUM_KIB");
				iMap.put("KEY", talepLast.getOperationStatus());
				oMap.put(
						"DURUM",
						GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
								iMap).get("TEXT"));
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
		return oMap;
	}

	@GraymoundService("GET_TOKEN_BASVURU")
	public static GMMap getTokenBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			// String userOID = null;
			// if(iMap.getString("KULLANICI_KODU") != null) {
			// userOID = iMap.getString("KULLANICI_KODU");
			// }
			// if(iMap.getString("FIRMA_KODU") != null) {
			// userOID += "@" + iMap.getString("FIRMA_KODU");
			// }

			int i = 1;
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_TRN4301.RC_QRY4301_Sorgula(?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10);

			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.setString(i++, iMap.getString("TALEP_DURUMU_LIST"));
			String talepKanali = iMap.getString("TALEP_KANALI_LIST");
			if (talepKanali==null||talepKanali.equals("NONE")) {
				stmt.setString(i++, null);
			} else {
				stmt.setString(i++, talepKanali);
			}
			stmt.setString(i++, iMap.getString("TOKEN_DURUMU_LIST"));
			Date start = iMap.getDate("TALEP_TAR_BASLANGIC");
			if (start == null) {
				stmt.setDate(i++, null);
			} else {
				stmt.setDate(i++,
						new java.sql.Date(iMap.getDate("TALEP_TAR_BASLANGIC")
								.getTime()));
				// stmt.setTimestamp(i++, new
				// Timestamp(iMap.getDate("TALEP_TAR_BASLANGIC").getTime()));
				// stmt.setString(i++, "to_Date('" + new
				// SimpleDateFormat("dd/MM/yyyy HH:MM:SS").format(iMap.getDate("TALEP_TAR_BASLANGIC"))
				// + "', 'dd/MM/yyyy HH24:MI:SS')");
			}
			Date end = iMap.getDate("TALEP_TAR_BITIS");
			if (end == null) {
				stmt.setDate(i++, null);
			} else {
				stmt.setDate(i++,
						new java.sql.Date(iMap.getDate("TALEP_TAR_BITIS")
								.getTime()));
			}

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = BnsprCommonFunctions.getTableName(iMap);
			int row = 0;

			while (rSet.next()) {
				// int j = 1;
				// if(iMap.getString("FIRMA_KODU") != null) {
				// String sqlFirma =
				// "select pkg_musteri.unvan(t.firma_no) from kib_firma_yetki_limit t WHERE t.firma_no = (SELECT CUSTOMER_ID FROM adc_man_user WHERE OID = '"
				// + rSet.getString("USER_OID") + "')";
				// PreparedStatement stmt1 = conn.prepareStatement(sqlFirma);
				// ResultSet rsFirma = (ResultSet) stmt1.getResultSet();
				// while(rsFirma.next()) {
				// oMap.put(tableName, row, "FIRMA", rsFirma.getString(1));
				// }
				// rsFirma.close();
				// GMServerDatasource.close(stmt1);
				// }
				String blokeDurumu = null;

				Session sessionADC = DAOSession
						.getSession(ADCCore.SESSION_FACTORY);
				Channel channel = (Channel) sessionADC
						.createCriteria(Channel.class)
						.add(Restrictions.eq("code", "CINT")).uniqueResult();

				// iMap.put("USER_CODE", iMap.get("KULLANICI_KODU") + "@" +
				// iMap.get("FIRMA_KODU"));
				// TokenServices.findOidFromCodes(iMap);

//				GMMap iMapBloke = new GMMap();
////				iMapBloke.put("CHANNEL_OID", channel.getOid());
////				iMapBloke.put("USER_OID", rSet.getString("user_oid"));
//				
//				iMapBloke.put("KULLANICI_KOD", iMap.getBigDecimal("KULLANICI_KODU"));
//				iMapBloke.put("MUSTERI_NO", iMap.getBigDecimal("FIRMA_KODU"));
//				
//				GMMap oMapBloke = GMServiceExecuter.call("BNSPR_TRN4131_GET_KANAL_BLOKE", iMapBloke);
//				if(oMapBloke.get("BLOKE_BILGI") != null) {
//					blokeDurumu = getBlokeliDegil().substring(0, 7);
//					System.out.println(blokeDurumu + " BLOKELI DEGIL");
//				}
				

//				GMMap oMapBloke = GMServiceExecuter.call(
//						"ADC_CHECK_USER_CHANNEL_BLOCK", iMapBloke);
//				if (oMapBloke.getString("RESPONSE").equals("0")) {
//					blokeDurumu = oMapBloke.getString("BLOKE_NOTE");
//				}
//
//				channel = (Channel) sessionADC.createCriteria(Channel.class)
//						.add(Restrictions.eq("code", "CC")).uniqueResult();
//
//				iMapBloke = new GMMap();
//				iMapBloke.put("CHANNEL_OID", channel.getOid());
//				iMapBloke.put("USER_OID", rSet.getString("user_oid"));
//
//				oMapBloke = GMServiceExecuter.call(
//						"ADC_CHECK_USER_CHANNEL_BLOCK", iMapBloke);
//				if (oMapBloke.getString("RESPONSE").equals("0")) {
//					if (blokeDurumu != null) {
//						blokeDurumu += ", " + oMapBloke.getString("BLOKE_NOTE");
//					} else {
//						blokeDurumu = oMapBloke.getString("BLOKE_NOTE");
//					}
//				}

				oMap.put(tableName, row, "ID", rSet.getString("talep_id"));
				oMap.put(tableName, row, "FIRMA", rSet.getString("firma"));
				oMap.put(tableName, row, "FIRMA_NO", rSet.getString("firma_no"));
				oMap.put(tableName, row, "KULLANICI_NO",
						rSet.getString("kullanici_no"));
				oMap.put(tableName, row, "KULLANICI",
						rSet.getString("kullanici"));
				oMap.put(tableName, row, "TALEP_TARIHI", rSet.getTimestamp("talep_tarihi") != null?new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(rSet.getTimestamp("talep_tarihi")): null);					
				oMap.put(tableName, row, "TALEP_KANALI",
						rSet.getString("talep_kanali"));
				oMap.put(tableName, row, "TANIMLANMA_TARIHI",rSet
						.getTimestamp("tanimlanma_tarihi")!=null?
						new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(rSet
								.getTimestamp("tanimlanma_tarihi")):null);
				;
				oMap.put(tableName, row, "TANIMLAYAN_TEMSILCI",
						rSet.getString("tanimlayan_temsilci"));
				oMap.put(tableName, row, "TALEP_DURUMU",
						rSet.getString("talep_durumu"));
				oMap.put(tableName, row, "TOKEN_DURUMU",
						rSet.getString("token_durumu"));
				oMap.put(tableName, row, "BLOKE_DURUMU", blokeDurumu);
				oMap.put(tableName, row, "SERI_NO", rSet.getString("seri_no"));
				oMap.put(tableName, row, "USER_OID", rSet.getString("user_oid"));
				oMap.put(tableName, row, "TALEP_KANALI_KOD",
						rSet.getString("talep_kanali_kod"));
				oMap.put(tableName, row, "TOKEN_ID", rSet.getString("token_id"));
				row++;
			}

			System.out.print(row + " rows");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}

		return oMap;
	}
	@GraymoundService("GET_TOKEN_BASVURU_ALINDI")
	public static GMMap getTokenBasvuruAlindi(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			// String userOID = null;
			// if(iMap.getString("KULLANICI_KODU") != null) {
			// userOID = iMap.getString("KULLANICI_KODU");
			// }
			// if(iMap.getString("FIRMA_KODU") != null) {
			// userOID += "@" + iMap.getString("FIRMA_KODU");
			// }

			int i = 1;
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_TRN4301.RC_QRY4301_Sorgula_Alindi(?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10);

			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.setString(i++, iMap.getString("TALEP_DURUMU_LIST"));
			String talepKanali = iMap.getString("TALEP_KANALI_LIST");
			if (talepKanali==null||talepKanali.equals("NONE")) {
				stmt.setString(i++, null);
			} else {
				stmt.setString(i++, talepKanali);
			}
			stmt.setString(i++, iMap.getString("TOKEN_DURUMU_LIST"));
			Date start = iMap.getDate("TALEP_TAR_BASLANGIC");
			if (start == null) {
				stmt.setDate(i++, null);
			} else {
				stmt.setDate(i++,
						new java.sql.Date(iMap.getDate("TALEP_TAR_BASLANGIC")
								.getTime()));
				// stmt.setTimestamp(i++, new
				// Timestamp(iMap.getDate("TALEP_TAR_BASLANGIC").getTime()));
				// stmt.setString(i++, "to_Date('" + new
				// SimpleDateFormat("dd/MM/yyyy HH:MM:SS").format(iMap.getDate("TALEP_TAR_BASLANGIC"))
				// + "', 'dd/MM/yyyy HH24:MI:SS')");
			}
			Date end = iMap.getDate("TALEP_TAR_BITIS");
			if (end == null) {
				stmt.setDate(i++, null);
			} else {
				stmt.setDate(i++,
						new java.sql.Date(iMap.getDate("TALEP_TAR_BITIS")
								.getTime()));
			}

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = BnsprCommonFunctions.getTableName(iMap);
			int row = 0;

			while (rSet.next()) {
				// int j = 1;
				// if(iMap.getString("FIRMA_KODU") != null) {
				// String sqlFirma =
				// "select pkg_musteri.unvan(t.firma_no) from kib_firma_yetki_limit t WHERE t.firma_no = (SELECT CUSTOMER_ID FROM adc_man_user WHERE OID = '"
				// + rSet.getString("USER_OID") + "')";
				// PreparedStatement stmt1 = conn.prepareStatement(sqlFirma);
				// ResultSet rsFirma = (ResultSet) stmt1.getResultSet();
				// while(rsFirma.next()) {
				// oMap.put(tableName, row, "FIRMA", rsFirma.getString(1));
				// }
				// rsFirma.close();
				// GMServerDatasource.close(stmt1);
				// }
				String blokeDurumu = null;

				Session sessionADC = DAOSession
						.getSession(ADCCore.SESSION_FACTORY);
				Channel channel = (Channel) sessionADC
						.createCriteria(Channel.class)
						.add(Restrictions.eq("code", "CINT")).uniqueResult();

				// iMap.put("USER_CODE", iMap.get("KULLANICI_KODU") + "@" +
				// iMap.get("FIRMA_KODU"));
				// TokenServices.findOidFromCodes(iMap);

				GMMap iMapBloke = new GMMap();
				iMapBloke.put("CHANNEL_OID", channel.getOid());
				iMapBloke.put("USER_OID", rSet.getString("user_oid"));

				GMMap oMapBloke = GMServiceExecuter.call(
						"ADC_CHECK_USER_CHANNEL_BLOCK", iMapBloke);
				if (oMapBloke.getString("RESPONSE").equals("0")) {
					blokeDurumu = oMapBloke.getString("BLOKE_NOTE");
				}

				channel = (Channel) sessionADC.createCriteria(Channel.class)
						.add(Restrictions.eq("code", "CC")).uniqueResult();

				iMapBloke = new GMMap();
				iMapBloke.put("CHANNEL_OID", channel.getOid());
				iMapBloke.put("USER_OID", rSet.getString("user_oid"));

				oMapBloke = GMServiceExecuter.call(
						"ADC_CHECK_USER_CHANNEL_BLOCK", iMapBloke);
				if (oMapBloke.getString("RESPONSE").equals("0")) {
					if (blokeDurumu != null) {
						blokeDurumu += ", " + oMapBloke.getString("BLOKE_NOTE");
					} else {
						blokeDurumu = oMapBloke.getString("BLOKE_NOTE");
					}
				}

				oMap.put(tableName, row, "ID", rSet.getString("talep_id"));
				oMap.put(tableName, row, "FIRMA", rSet.getString("firma"));
				oMap.put(tableName, row, "FIRMA_NO", rSet.getString("firma_no"));
				oMap.put(tableName, row, "KULLANICI_NO",
						rSet.getString("kullanici_no"));
				oMap.put(tableName, row, "KULLANICI",
						rSet.getString("kullanici"));
				oMap.put(tableName, row, "TALEP_TARIHI", new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(rSet.getTimestamp("talep_tarihi")));
				oMap.put(tableName, row, "TALEP_KANALI",
						rSet.getString("talep_kanali"));
				oMap.put(tableName, row, "TANIMLANMA_TARIHI",rSet
						.getTimestamp("tanimlanma_tarihi")!=null?
						new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(rSet
								.getTimestamp("tanimlanma_tarihi")):null);
				;
				oMap.put(tableName, row, "TANIMLAYAN_TEMSILCI",
						rSet.getString("tanimlayan_temsilci"));
				oMap.put(tableName, row, "TALEP_DURUMU",
						rSet.getString("talep_durumu"));
				oMap.put(tableName, row, "TOKEN_DURUMU",
						rSet.getString("token_durumu"));
				oMap.put(tableName, row, "BLOKE_DURUMU", blokeDurumu);
				oMap.put(tableName, row, "SERI_NO", rSet.getString("seri_no"));
				oMap.put(tableName, row, "USER_OID", rSet.getString("user_oid"));
				oMap.put(tableName, row, "TALEP_KANALI_KOD",
						rSet.getString("talep_kanali_kod"));
				oMap.put(tableName, row, "TOKEN_ID", rSet.getString("token_id"));
				row++;
			}

			System.out.print(row + " rows");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}

		return oMap;
	}

	@GraymoundService("KEEP_TOKEN_TALEP_ID_IN_SESSION")
	public static GMMap keepTalepIdInSession(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("TALEP_ID", iMap.getString("TALEP_ID"));
		oMap.put("FIRMA_KODU", iMap.getString("FIRMA_KODU"));
		oMap.put("KULLANICI_KODU", iMap.getString("KULLANICI_KODU"));
		oMap.put("FIRMA_ADI", iMap.getString("FIRMA_ADI"));
		oMap.put("KULLANICI_ADI", iMap.getString("KULLANICI_ADI"));
		oMap.put("TALEP_KANALI", iMap.getString("TALEP_KANALI"));
		oMap.put("TALEP_TARIHI", iMap.getString("TALEP_TARIHI"));
		String blokeDurum = null;
		
		GMMap iMapBloke = new GMMap();
//		iMapBloke.put("CHANNEL_OID", channel.getOid());
//		iMapBloke.put("USER_OID", rSet.getString("user_oid"));
		
		iMapBloke.put("KULLANICI_KOD", iMap.getBigDecimal("KULLANICI_KODU"));
		iMapBloke.put("MUSTERI_NO", iMap.getBigDecimal("FIRMA_KODU"));
		
		
		GMMap oMapBloke = GMServiceExecuter.call("BNSPR_TRN4131_GET_KANAL_BLOKE", iMapBloke);
		if(oMapBloke.get("BLOKE_BILGI") != null) {
			blokeDurum = getBlokeliDegil().substring(0, 7);
			System.out.println(blokeDurum + " BLOKELI");
		}
		else {
			blokeDurum = getBlokeliDegil();
			System.out.print("BLOKELI DEGIL");
		}
		
		
//		if(iMap.getString("BLOKE_DURUMU")!=null) {
//			blokeDurum = iMap.getString("BLOKE_DURUMU");
//			System.out.print("BLOKELI");
//		}
//		else {
//			blokeDurum = getBlokeliDegil();
//			System.out.print("BLOKELI DEGIL");
//		}
		oMap.put("BLOKE_DURUMU", blokeDurum);
		oMap.put("SERI_NO", iMap.getString("SERI_NO"));
		oMap.put("SERI_NO_MASK",
				formatSeriNo(iMap.getString("SERI_NO") != null ? iMap
						.getString("SERI_NO").substring(0, 10) : null));
		oMap.put("TALEP_DURUMU", iMap.getString("TALEP_DURUMU"));
		oMap.put("TANIMLAYAN_TEMSILCI", iMap.getString("TANIMLAYAN_TEMSILCI"));
		oMap.put("TOKEN_DURUMU", iMap.getString("TOKEN_DURUMU"));
		oMap.put("USER_OID", iMap.getString("USER_OID"));
		oMap.put("TALEP_KANALI_KOD", iMap.getString("TALEP_KANALI_KOD"));
		oMap.put("TOKEN_ID", iMap.getString("TOKEN_ID"));
		oMap.put("TANIM_TARIHI", iMap.getString("TANIM_TARIHI"));
		ADCSession.put("HARD_TOKEN_TALEP_ID_IN_SESSION", oMap);
		return oMap;
	}
	
	public static String getBlokeliDegil() {
		GMMap messageTanimlama = new GMMap();
		messageTanimlama.put("MESSAGE_NO", new BigDecimal(2897));
		String result = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", messageTanimlama).get("ERROR_MESSAGE");	
//		result = result.substring(8);
		System.out.println(result + " BOOOOOOOOOOOOOOOOOOOOOO");
		return result;
	}

	@GraymoundService("GET_TOKEN_TALEP_ID_FROM_SESSION")
	public static GMMap getTalepIdFromSession(GMMap iMap) {
		GMMap oMap = new GMMap();

		oMap = (GMMap) ADCSession.get("HARD_TOKEN_TALEP_ID_IN_SESSION");

		return oMap;
	}

	public static String formatSeriNo(String seriNo) {
		String result = seriNo;

		if (result == null) {
			return null;
		} else {
			result = result.substring(0, 2) + "-" + result.substring(2, 9)
					+ "-" + result.substring(9);
			return result;
		}
	}

	@GraymoundService("GET_AKTIF_SIFRE_TARIHCE")
	public static GMMap getAktifSifreTarihce(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_TRN4302.RC_QRY4302_Sorgula(?,?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIRMA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KULLANICI_KODU"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = BnsprCommonFunctions.getTableName(iMap);
			int row = 0;

			while (rSet.next()) {
				oMap.put(tableName, row, "CIHAZ_SERI_NO", formatSeriNo(rSet.getString("seri_no") != null ? rSet.getString("seri_no").substring(0, 10) : null));
//				oMap.put(tableName, row, "CIHAZ_SERI_NO", iMap.getString("seri_no"));
				oMap.put(tableName, row, "ISLEM_TARIHI", new SimpleDateFormat(
						"dd/MM/yyyy HH:mm:ss").format(rSet
						.getTimestamp("islem_tarihi")));
				oMap.put(tableName, row, "ISLEM", rSet.getString("islem"));
				oMap.put(tableName, row, "ISLEM_YAPAN_KULLANICI",
						rSet.getString("kullanici"));
				oMap.put(tableName, row, "ONAYLAYAN_KULLANICI",
						rSet.getString("onaylayan_kullanici"));
				oMap.put(tableName, row, "UCRET_DURUMU",
						rSet.getString("ucret_durumu"));
				// oMap.put(tableName, row, "UCRET_ACIKLAMASI",
				// rSet.getString("ucret_aciklamasi"));
				row++;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}

		return oMap;
	}

	@GraymoundService("AKTIF_SIFRE_TANIMLAMA")
	public static GMMap aktifSifreTanimlama(GMMap iMap) {
		GMMap oMap = new GMMap();

		// GMMap session = (GMMap)
		// ADCSession.get("HARD_TOKEN_TALEP_ID_IN_SESSION");

		Integer talepID = iMap.getInt("TALEP_ID");
		// String tanimlayanTemsilci = iMap.getString("TANIMLAYAN_TEMSILCI");
		String talepKanali = iMap.getString("TALEP_KANALI_KOD");
		String talepDurumu = iMap.getString("TALEP_DURUMU");

		// if(talepDurumu.equals("AKTIVASYON")) {
		// talepDurumu = "KULLANIMDA";
		// }
		// else if(talepDurumu.equals("ARIZA_BILDIRIM")) {
		// talepDurumu = "MUSTERI_ARIZA_BILDIRIM";
		// }
		//
		HardTokenTalepTx hardTokenTalepTx = new HardTokenTalepTx();
		hardTokenTalepTx.setTalepId(talepID);
		hardTokenTalepTx.setOperationChannel(talepKanali);
		hardTokenTalepTx.setOperationStatus(talepDurumu);

		GMMap sessionMap = (GMMap) ADCSession
				.get("HARD_TOKEN_TALEP_ID_IN_SESSION");

		GMMap tx_map = new GMMap();
		tx_map = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap);

		String tokenId = sessionMap.getString("TOKEN_ID");
		String userOId = sessionMap.getString("USER_OID");
		System.out.println(tokenId + " " + userOId + " DSADSADASDS"
				+ talepDurumu);
		BigDecimal txNo = tx_map.getBigDecimal("TRX_NO");

		hardTokenTalepTx.setTokenId(tokenId);
		hardTokenTalepTx.setUserOId(userOId);
		hardTokenTalepTx.setTxNo(txNo);

		Session session = DAOSession.getSession("BNSPRDal");
		session.saveOrUpdate(hardTokenTalepTx);
		session.flush();

		GMMap i2Map = new GMMap();

		i2Map.put("TRX_NAME", "4305");
		i2Map.put("TRX_NO", txNo);
		GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", i2Map);

		String firmaKodu = sessionMap.get("FIRMA_KODU").toString();
		String kullaniciKodu = sessionMap.get("KULLANICI_KODU").toString();
		
		GMMap changeGuvenlikYontemi = new GMMap();
		changeGuvenlikYontemi.put("FIRMA_KODU", firmaKodu);
		changeGuvenlikYontemi.put("KULLANICI_KODU",	kullaniciKodu);
		if (talepDurumu.equals("KULLANIMDA")) {
			System.out.println(firmaKodu + " " + kullaniciKodu + " KULLANIMDAAAAAAAAAAAA");
			changeGuvenlikYontemi.put("SECURITY_OPTION", "TOKEN");
		} else {
			changeGuvenlikYontemi.put("SECURITY_OPTION", "OTP");
		}
		GMServiceExecuter.execute("ADC_MAN_USER_KIB_GUVENLIK_YONTEMI_DEGISTIR",
				changeGuvenlikYontemi);

		return oMap;
	}

	@GraymoundService("GET_STOK_OZET")
	public static GMMap getStokOzet(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRAdc");
		// session.createQuery("SELECT * FROM ")

		return oMap;
	}

	public static void findOidFromCodes(GMMap iMap) {
		
		if (iMap.getString("USER_CODE")==null) {
			iMap.put("USER_CODE",
					iMap.get("KULLANICI_KODU") + "@" + iMap.get("FIRMA_KODU"));
		}
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		String userCode = iMap.getString("USER_CODE");
		User user = (User) session.createCriteria(User.class)
				.add(Restrictions.eq("username", userCode)).uniqueResult();
		
		if (user==null) {
			iMap.remove("USER_OID");
		}else {
			iMap.put("USER_OID", user.getOid());
		}
	}
	
	public static void findCodesFromOid(GMMap iMap) {
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		String userOid = iMap.getString("USER_OID");
		User user = (User) session.createCriteria(User.class)
				.add(Restrictions.eq("oid", userOid)).uniqueResult();
		iMap.put("KULLANICI_KODU", user.getUserCustomerId());
		iMap.put("FIRMA_KODU", user.getCustomerId());
	}

	@GraymoundService("BNSPR_TRN4308_GET_STOCK_DETAIL")
	public static GMMap getStockDetail(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			int i = 1;
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? =call PKG_TRN4308.RC_QRY4308_Sorgula(?,?,?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("TALEP_DURUMU"));
			stmt.setString(i++, iMap.getString("UCRET_DURUMU"));
			stmt.setString(i++, iMap.getString("TOKEN_DURUMU"));
			
			System.out.println(iMap.getString("TALEP_DURUMU") + " - " + iMap.getString("UCRET_DURUMU") + " - " + iMap.getString("TOKEN_DURUMU") + " BOOOOOOOOOOOOOOOOOO");
			
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int row = 0;
			String tableName = BnsprCommonFunctions.getTableName(iMap);

			while (rSet.next()) {
				oMap.put(tableName, row, "SERI_NO",      rSet.getString("seri_no"));
				oMap.put(tableName, row, "KULLANICI",    rSet.getString("kullanici"));
				oMap.put(tableName, row, "FIRMA_UNVANI", rSet.getString("firma"));
				oMap.put(tableName, row, "TALEP_KANALI", rSet.getString("talep_kanali"));
				oMap.put(tableName, row, "UCRET_DURUMU", rSet.getString("ucret_durumu"));
				oMap.put(tableName, row, "TALEP_DURUMU", rSet.getString("talep_durumu"));
				oMap.put(tableName, row, "TOKEN_DURUMU", rSet.getString("token_durumu"));
				row++;
			}
		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN4308_GET_STOCK_INFO")
	public static GMMap getStockInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Date tempDate = null;
			if (iMap.getDate("START_DATE") != null) {
				tempDate = iMap.getDate("START_DATE");
			}
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_TRN4309.RC_QRY4309_Sorgula(?,?,?,?,?,?,?,?,?)}");
			stmt.setDate(1,
					tempDate != null ? new java.sql.Date(tempDate.getTime())
							: null);
			stmt.registerOutParameter(2, Types.INTEGER);
			stmt.registerOutParameter(3, Types.INTEGER);
			stmt.registerOutParameter(4, Types.INTEGER);
			stmt.registerOutParameter(5, Types.INTEGER);
			stmt.registerOutParameter(6, Types.INTEGER);
			stmt.registerOutParameter(7, Types.INTEGER);
			stmt.registerOutParameter(8, Types.INTEGER);
			stmt.registerOutParameter(9, Types.INTEGER);
			stmt.execute();

			oMap.put("SATIN_ALINAN", stmt.getInt(2));
			oMap.put("STOKTA_BEKLEYEN", stmt.getInt(3));
			oMap.put("KULLANIMDA", stmt.getInt(4));
			oMap.put("ARIZALI", stmt.getInt(5));
			oMap.put("KAYIP_CALINTI", stmt.getInt(6));
			oMap.put("UCRET_ALINAN", stmt.getInt(7));
			oMap.put("UCRET_ALINMADI", stmt.getInt(8));
			oMap.put("TEDARIKCIDE", stmt.getInt(9));

		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} catch (ParseException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN4308_STOK_ARIZA_BILDRIIM")
	public static GMMap stokArizaBildirim(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		String seriNo = iMap.getString("SERI_NO");
		String tokenStatus = iMap.getString("TOKEN_STATUS");
		
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN4309.Stok_Ariza_Bildirim(?,?,?,?)}");	
			
			stmt.setString(1, seriNo);
			stmt.setString(2, tokenStatus);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.execute();
			
			GMMap message = new GMMap();
			message.put("MESSAGE_NO", new BigDecimal(stmt.getInt(4)));		
			String stokAriza = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", message).get("ERROR_MESSAGE");
			
			oMap.put("RESULT", stmt.getString(3));
			oMap.put("STOK_ARIZA", stokAriza);
			
		}  catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		}  finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("AKTIF_SIFRE_GUNCELLEME")
	public static GMMap aktifSifreGuncelleme(GMMap iMap) {
		GMMap oMap = new GMMap();

		Integer talepID = iMap.getInt("TALEP_ID");
		String talepKanali = iMap.getString("TALEP_KANALI");
		String talepDurumu = iMap.getString("TALEP_DURUMU");

		HardTokenTalepTx hardTokenTalepTx = new HardTokenTalepTx();
		hardTokenTalepTx.setTalepId(talepID);
		hardTokenTalepTx.setOperationChannel(talepKanali);
		hardTokenTalepTx.setOperationStatus(talepDurumu);

		GMMap sessionMap = (GMMap) ADCSession
				.get("HARD_TOKEN_TALEP_ID_IN_SESSION");

		GMMap tx_map = new GMMap();
		tx_map = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap);

		String tokenId = sessionMap.getString("TOKEN_ID");
		String userOId = sessionMap.getString("USER_OID");
		BigDecimal txNo = tx_map.getBigDecimal("TRX_NO");

		hardTokenTalepTx.setTokenId(tokenId);
		hardTokenTalepTx.setUserOId(userOId);
		hardTokenTalepTx.setTxNo(txNo);

		Session session = DAOSession.getSession("BNSPRDal");
		session.saveOrUpdate(hardTokenTalepTx);
		session.flush();

		GMMap i2Map = new GMMap();

		i2Map.put("TRX_NAME", "4307");
		i2Map.put("TRX_NO", txNo);
		GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", i2Map);

		GMMap changeGuvenlikYontemi = new GMMap();
		changeGuvenlikYontemi.put("FIRMA_KODU", sessionMap.get("FIRMA_KODU"));
		changeGuvenlikYontemi.put("KULLANICI_KODU",
				sessionMap.get("KULLANICI_KODU"));
		changeGuvenlikYontemi.put("SECURITY_OPTION", "OTP");
		GMServiceExecuter.execute("ADC_MAN_USER_KIB_GUVENLIK_YONTEMI_DEGISTIR",
				changeGuvenlikYontemi);

		return oMap;
	}

	@GraymoundService("AKTIF_SIFRE_ESLESTIR")
	public static GMMap aktifSifreEslestir(GMMap iMap) {
		GMMap oMap = new GMMap();

		Integer talepID = iMap.getInt("TALEP_ID");
		String talepKanali = iMap.getString("TALEP_KANALI_KOD");
		// String talepDurumu = iMap.getString("TALEP_DURUMU");
		String talepDurumu = "ESLESTIRILDI";
		String ilkSifre = iMap.getString("ILK_SIFRE");
		String ikinciSifre = iMap.getString("IKINCI_SIFRE");

		HardTokenTalepTx hardTokenTalepTx = new HardTokenTalepTx();
		hardTokenTalepTx.setTalepId(talepID);
		hardTokenTalepTx.setOperationChannel(talepKanali);
		hardTokenTalepTx.setOperationStatus(talepDurumu);
		hardTokenTalepTx.setSynchPassFirst(ilkSifre);
		hardTokenTalepTx.setSynchPassSecond(ikinciSifre);

		GMMap sessionMap = (GMMap) ADCSession
				.get("HARD_TOKEN_TALEP_ID_IN_SESSION");

		GMMap tx_map = new GMMap();
		tx_map = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap);

		// String tokenId = sessionMap.getString("TOKEN_ID");
		String tokenId = iMap.getString("SERI_NO") + "GO3DEFAULT  ";
		String userOId = sessionMap.getString("USER_OID");
		BigDecimal txNo = tx_map.getBigDecimal("TRX_NO");

		hardTokenTalepTx.setTokenId(tokenId);
		hardTokenTalepTx.setUserOId(userOId);
		hardTokenTalepTx.setTxNo(txNo);

		GMMap syncMap = new GMMap();
		syncMap.put("SERIAL", hardTokenTalepTx.getTokenId());
		syncMap.put("PASSWORD1", iMap.getString("PASSWORD1"));
		syncMap.put("PASSWORD2", iMap.getString("PASSWORD2"));

		System.out.println("SERIAL = " + hardTokenTalepTx.getTokenId()
				+ "\nPASSWORD1 = " + iMap.getString("PASSWORD1")
				+ "\nPASSWORD2 = " + iMap.getString("PASSWORD2"));

		Connection conn = null;
		CallableStatement stmt = null;
		int cihazSorgula = 0;
		ResultSet rSet = null;
		int i = 1;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? =call PKG_TRN4304.cihaz_sorgula(?)}");

			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, tokenId);

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			stmt.execute();
			while (rSet.next()) {
				cihazSorgula = rSet.getInt("sonuc");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}

		if (cihazSorgula == 0) {
			GMMap syncResult = GMServiceExecuter.call(
					"BNSPR_EXTERNAL_HARD_TOKEN_SYNC", syncMap);
			if (syncResult.getString("RESPONSE").equals("2")) {
				Session session = DAOSession.getSession("BNSPRDal");
				session.saveOrUpdate(hardTokenTalepTx);
				session.flush();

				GMMap i2Map = new GMMap();

				i2Map.put("TRX_NAME", "4304");
				i2Map.put("TRX_NO", txNo);
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", i2Map);

				GMMap messageBasarili = new GMMap();
				messageBasarili.put("MESSAGE_NO", new BigDecimal(2815));
				oMap.put(
						"RESPONSE",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_ERROR_MESSAGE",
								messageBasarili).get("ERROR_MESSAGE"));
				
				oMap.put("RESULT", "true");

				// oMap.put("RESPONSE", "İşlem başarılı.");
			} else {
				GMMap messageBasarisiz = new GMMap();
				messageBasarisiz.put("MESSAGE_NO", new BigDecimal(2816));
				oMap.put(
						"RESPONSE",
						(String) GMServiceExecuter.execute(
								"BNSPR_COMMON_GET_ERROR_MESSAGE",
								messageBasarisiz).get("ERROR_MESSAGE"));
				
				oMap.put("RESULT", "false");
				// oMap.put("RESPONSE", "İşlem başarısız.");
			}
		} else {
			GMMap message = new GMMap();
			message.put("MESSAGE_NO", new BigDecimal(cihazSorgula));
								
			String cihazSorgulaMsj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", message).get("ERROR_MESSAGE");
			
			oMap.put("RESPONSE", cihazSorgulaMsj);
			oMap.put("RESULT", "false");
		}

		return oMap;
	}

	@GraymoundService("AKTIF_SIFRE_REDDET")
	public static GMMap aktifSifreReddet(GMMap iMap) {
		GMMap oMap = new GMMap();

		Integer talepID = iMap.getInt("TALEP_ID");
		String talepKanali = iMap.getString("TALEP_KANALI_KOD");
		String talepDurumu = "BASVURU_REDDEDILDI";

		HardTokenTalepTx hardTokenTalepTx = new HardTokenTalepTx();
		hardTokenTalepTx.setTalepId(talepID);
		hardTokenTalepTx.setOperationChannel(talepKanali);
		hardTokenTalepTx.setOperationStatus(talepDurumu);

		GMMap sessionMap = (GMMap) ADCSession
				.get("HARD_TOKEN_TALEP_ID_IN_SESSION");

		GMMap tx_map = new GMMap();
		tx_map = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap);

		String tokenId = sessionMap.getString("TOKEN_ID");
		String userOId = sessionMap.getString("USER_OID");
		BigDecimal txNo = tx_map.getBigDecimal("TRX_NO");

		hardTokenTalepTx.setTokenId(tokenId);
		hardTokenTalepTx.setUserOId(userOId);
		hardTokenTalepTx.setTxNo(txNo);

		Session session = DAOSession.getSession("BNSPRDal");
		session.saveOrUpdate(hardTokenTalepTx);
		session.flush();

		GMMap i2Map = new GMMap();

		i2Map.put("TRX_NAME", "4304");
		i2Map.put("TRX_NO", txNo);
		GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", i2Map);
		return oMap;
	}

	

	

	@GraymoundService("HARD_TOKEN_ESLESTIRME_RAPOR")
	public static GMMap hardTokenEslestirmeRaporuHazirla(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_TRN4304.RC_QRY4304_EslestirmeRapor}");
			stmt.registerOutParameter(1, -10); // ref cursor

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			int fileNum = 1;
			File f = new File(ROOT + File.separator + "files" + File.separator
					+ "Eslestirme Listesi_" + fileNum + ".xls");
			WritableWorkbook workbook = Workbook.createWorkbook(f);
			int sheetNum = 0;
			WritableSheet sheet = workbook.createSheet("Eslestirme Listesi_"
					+ fileNum + "_" + (sheetNum + 1), sheetNum);
			// Baslik satiri.
			int row = 0;
			int col = 0;
			sheet.addCell(new Label(col++, row, DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_EXCEL_COLUMNS', 'ADK', 'MUSTERI_NO') from dual")));
			sheet.addCell(new Label(col++, row, DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_EXCEL_COLUMNS', 'ADK', 'FIRMA_UNVANI') from dual")));
			sheet.addCell(new Label(col++, row, DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_EXCEL_COLUMNS', 'ADK', 'SUBE_KODU') from dual")));
			sheet.addCell(new Label(col++, row, DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_EXCEL_COLUMNS', 'ADK', 'KULLANICI_ADI') from dual")));
			sheet.addCell(new Label(col++, row, DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_EXCEL_COLUMNS', 'ADK', 'HESAP_NO') from dual")));
			sheet.addCell(new Label(col++, row, DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_EXCEL_COLUMNS', 'ADK', 'STATUS') from dual")));
			sheet.addCell(new Label(col++, row, DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_EXCEL_COLUMNS', 'ADK', 'TOKEN_ID') from dual")));
			row++;
			while (rSet.next()) {
				col = 0;
				sheet.addCell(new Label(col++, row, rSet
						.getString("MUSTERI_NO")));
				sheet.addCell(new Label(col++, row, rSet
						.getString("FIRMA_UNVANI")));
				sheet.addCell(new Label(col++, row, rSet.getString("SUBE_KODU")));
				sheet.addCell(new Label(col++, row, rSet
						.getString("KULLANICI_ADI")));
				sheet.addCell(new Label(col++, row, rSet.getString("HESAP_NO")));
				sheet.addCell(new Label(col++, row, rSet.getString("STATUS")==null?"Yeni Talep":rSet.getString("STATUS")));
				sheet.addCell(new Label(col++, row, rSet.getString("TOKEN_ID").replace("GO3DEFAULT  ", "")));
				row++;

			}
			workbook.write();
			workbook.close();
			GMMap mailMap = new GMMap();
			mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME",
					"Eslestirme Listesi_" + fileNum + ".xls");
			mailMap.put(
					"MAIL_ATTACHMENT_LIST",
					0,
					"FILE_CONTENT",
					FileUtil.readFileToByteArray(ROOT + File.separator
							+ "files" + File.separator + "Eslestirme Listesi_"
							+ fileNum + ".xls"));
			Date d=new Date(System.currentTimeMillis()-oneDay);
			SimpleDateFormat sdf =new SimpleDateFormat("dd/MM/yyyy");
			
			mailMap.put("MAIL_SUBJECT", DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_MAIL_SUBJECT', 'ADK', 'SUBJECT') from dual")+sdf.format(d));
			mailMap.put("MAIL_FROM", "KIB.TOKEN.ESLESTIRME@aktifbank.com.tr");
			mailMap.put(
					"MAIL_TO",
					DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_EMAIL', 'ADK', 'TO') from dual"));
			mailMap.put("IS_BODY_HTML", "H");
			mailMap.put("MAIL_BODY", sdf.format(d)+" "+DALUtil.getResult("select PKG_PARAMETRE.ParamTextAl('ESLESTIRME_MAIL_BODY', 'ADK', 'MAIL_BODY') from dual"));
			GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL",
					mailMap);
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("HARD_TOKEN_ISLEM_GORUNTULE")
	public static GMMap hardTokenIslemGoruntule (GMMap iMap) {
		GMMap oMap = new GMMap();
		
		BigDecimal tx_no = iMap.getBigDecimal("TRX_NO");
		
		Session session = DAOSession.getSession("BNSPRDal");

		HardTokenTalepTx talep = (HardTokenTalepTx) session.createCriteria(HardTokenTalepTx.class).add(Restrictions.eq("txNo", tx_no)).uniqueResult();
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			int i = 1;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN4301.get_hard_token_islem(?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, talep.getTxNo());
			
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			
			while(rSet.next()) {
				String firma_no = rSet.getString("firma_no");
				String kullanici_no = rSet.getString("kullanici_no");
				String firma = rSet.getString("firma");
				String kullanici = rSet.getString("kullanici");
				String talep_tarihi = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(rSet.getTimestamp("talep_tarihi"));
				String talep_kanali = rSet.getString("talep_kanali");
				String tanimlanma_tarihi = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(rSet.getTimestamp("tanimlanma_tarihi"));
				String tanimlayan_temsilci = rSet.getString("tanimlayan_temsilci");
				String talep_durumu = rSet.getString("talep_durumu");
				String token_durumu = rSet.getString("token_durumu");
				String seri_no = rSet.getString("seri_no") != null ? rSet.getString("seri_no").substring(0, 10) : null;
				String user_oid = rSet.getString("user_oid");
				String talep_kanali_kod = rSet.getString("talep_kanali_kod");
				String token_id = rSet.getString("token_id") != null ? rSet.getString("token_id").substring(0, 10) : null;
				String ilk_sifre = rSet.getString("ilk_sifre");
				String ikinci_sifre = rSet.getString("ikinci_sifre");
				String islem_oncesi_talep = rSet.getString("islem_oncesi_talep");
				String islem_oncesi_token = rSet.getString("islem_oncesi_token");
				String talep_durumu_kod = rSet.getString("talep_durumu_kod");
				
				oMap.put("FIRMA_NO", firma_no);
				oMap.put("KULLANICI_NO", kullanici_no);
				oMap.put("FIRMA", firma);
				oMap.put("KULLANICI", kullanici);
				oMap.put("TALEP_TARIHI", talep_tarihi);
				oMap.put("TALEP_KANALI", talep_kanali);
				oMap.put("TANIMLANMA_TARIHI", tanimlanma_tarihi);
				oMap.put("TANIMLAYAN_TEMSILCI", tanimlayan_temsilci);
				oMap.put("TALEP_DURUMU", talep_durumu);
				oMap.put("TOKEN_DURUMU", token_durumu);
				oMap.put("SERI_NO", seri_no);
				oMap.put("USER_OID", user_oid);
				oMap.put("TALEP_KANALI_KOD", talep_kanali_kod);
				oMap.put("TOKEN_ID", token_id);
				oMap.put("ILK_SIFRE", ilk_sifre);
				oMap.put("IKINCI_SIFRE", ikinci_sifre);
				oMap.put("ISLEM_ONCESI_TALEP", islem_oncesi_talep);
				oMap.put("ISLEM_ONCESI_TOKEN", islem_oncesi_token);
				oMap.put("TALEP_DURUMU_KOD", talep_durumu_kod);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
		
		
		return oMap;
	}
	@GraymoundService("AKTIF_SIFRE_LISTESI")
	public static GMMap getHardTokenList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call PKG_TRN4308.RC_QRY4308_AktifSifreListe}");
			stmt.registerOutParameter(1, -10); // ref cursor

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String tableName="AKTIF_SIFRE_LISTE";
			int row=0;
			while (rSet.next()) {
				oMap.put(tableName, row, "TOKEN_ID",	rSet.getString("token_id").replace("GO3DEFAULT  ", ""));
				row++;
			}
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("AKTIF_SIFRE_UCRET_UPDATE")
	public static GMMap getAktifSifreUcretUpdateService(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		String tokenId = iMap.getString("TOKEN_ID")+"GO3DEFAULT  ";
		String ucretDurum = iMap.getString("UCRET_DURUM");
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{call PKG_TRN4308.RC_QRY4308_AktifSifreUcretUpt(?,?)}");
			stmt.setString(1,tokenId+"");
			stmt.setString(2,ucretDurum+"");
			stmt.execute();
			oMap.put("RESULT", "OK");
						
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
