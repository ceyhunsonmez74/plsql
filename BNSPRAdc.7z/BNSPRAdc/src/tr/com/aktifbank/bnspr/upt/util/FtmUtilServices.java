package tr.com.aktifbank.bnspr.upt.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.math.BigDecimal;

import org.hibernate.Session;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FtmUtilServices  {
    
    
    public static GMMap getLineFromFTM(long start, long end, BigDecimal ftmTransferId) {
        
        String fetchQuery = String.format("SELECT ffc.line_number,ffc.line FROM ftm.ftm_file_content ffc " +
                                       "WHERE ffc.ftm_process_oid=%s AND ffc.line_number >= %s and ffc.line_number <= %s " +
                                       "order by ffc.line_number",
                ftmTransferId, start, end);
           final String tableName = "FILE_LINE";
       
       return  DALUtil.getResults(fetchQuery, tableName);
   }

    
    
    public static GMMap getFileNameFromFTM (BigDecimal oid) {
        String fetchQuery = String.format("SELECT OID, FTM_FILE_DEFINITION_OID, FILE_NAME ,"
                + " FILE_DATE, BEGIN_DATE,END_DATE, FTM_PROCESS_STATE_OID from FTM.FTM_PROCESS where OID = %s", oid);
        
        return  DALUtil.getResults(fetchQuery, "FILE_NAME");  
    }
    
    
    public static void ftmTransferFile(String ftmId,
                                       BigDecimal ftmProcessIdForEmeksan,
                                       String emeklifileName,
                                       BigDecimal ftmProcessIdForSSK,
                                       String sSKfileName,
                                       BigDecimal ftmProcessIdForBagKur,
                                       String bAGKURfileName) throws Exception{
       try {
        GMMap ftmFileRequest = new GMMap();
        GMConnection connection = GMConnection.getConnection("FTM");
        int index = 0;
        ftmFileRequest.put("FILE_DEF_ID", ftmId);
        
        if (ftmProcessIdForEmeksan.intValue()>0 && emeklifileName.length()>0) {
            GMMap firstFileRequest = new GMMap();
            firstFileRequest.put("PROCESS_ID", ftmProcessIdForEmeksan);
            firstFileRequest.put("FILE_NAME", emeklifileName);
            ftmFileRequest.put("FILE_PARAMS",index, firstFileRequest);
            index++;
        }
        
        if (ftmProcessIdForSSK.intValue()>0 && sSKfileName.length()>0 ) {
            GMMap secondFileRequest = new GMMap();
            secondFileRequest.put("PROCESS_ID", ftmProcessIdForSSK);
            secondFileRequest.put("FILE_NAME", sSKfileName);
            ftmFileRequest.put("FILE_PARAMS", index, secondFileRequest); 
            index++;
        }
      
        if (ftmProcessIdForBagKur.intValue()>0 && bAGKURfileName.length()>0 ) {
            GMMap thirdFileRequest = new GMMap();
            thirdFileRequest.put("PROCESS_ID", ftmProcessIdForBagKur);
            thirdFileRequest.put("FILE_NAME", bAGKURfileName);
            ftmFileRequest.put("FILE_PARAMS", index, thirdFileRequest); 
            
        }
         
        connection.serviceCall("BNSPR_FTM_CREATE_AND_TRANSFER_FILE",ftmFileRequest);
            
       }catch (Exception e) {
           throw e;
       }

    }
    
    
    public static void ftmTransferSingleFile(String ftmId, BigDecimal ftmProcessId, String fileName) throws IOException {
        GMMap input = new GMMap();
        input.put("FILE_DEF_ID", ftmId);
        input.put("PROCESS_ID", ftmProcessId);
        input.put("FILE_NAME", fileName);
        GMConnection connection = GMConnection.getConnection("FTM");
        connection.serviceCall("BNSPR_FTM_CREATE_AND_TRANSFER_FILE", input);
    }
    
    
    

    public static BigDecimal getNextValueOfFTMProcessId() {
        
        Session session = DAOSession.getSession("BNSPRDal");
        return new BigDecimal(((Number) session
                .createSQLQuery("SELECT ftm.seq_ftm_process.nextval FROM dual")
                .uniqueResult()).longValue());
    }
    
    public static String getGlobalParam(String batchParamCode) {
        GMMap iMapG = new GMMap();
        iMapG.put("KOD", batchParamCode);
        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
        return batchNo;
    }
    
    
    
    public static GMMap sendMail(String subject,String message) {
        GMMap oMap = new GMMap();
        try {
            
            if (message.length()>3500) {
                message = message.substring(0,3500);
            }
            
            String mailTo = getGlobalParam("KREDI_FTM_MAIL_LISTESI");
            GMMap mailServisMap = new GMMap();
            mailServisMap.put("MAIL_FROM", "FTM@aktifbank.com.tr");
            mailServisMap.put("MAIL_TO", mailTo);
            mailServisMap.put("MAIL_SUBJECT", subject);
            mailServisMap.put("MAIL_BODY", message);
            mailServisMap.put("IS_BODY_HTML", "H");
            GMServiceExecuter.executeNT("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailServisMap);
        }
        
        catch (Exception e) {
            e.printStackTrace();
        }

        return oMap;
    }
    
    public static String getExceptionStackTrace(Exception e) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(bos);
        e.printStackTrace(ps);
        ps.flush();
        return new String(bos.toByteArray(), 0, bos.size());
    }
    



   
    
}
