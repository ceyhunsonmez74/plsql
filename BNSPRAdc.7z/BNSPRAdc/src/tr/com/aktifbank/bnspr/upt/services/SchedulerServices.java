package tr.com.aktifbank.bnspr.upt.services;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TuGonderTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SchedulerServices {
    private final static String RESPONSE_FAIL = "0";

    @GraymoundService("BNSPR_UPT_EFT_GET_RETURN_CONTROL")
    public static GMMap getNKolayEftReurnControl(GMMap iMap) {

        GMMap oMap = new GMMap();

        String procStr = "{ call PKG_TU.getNKolayEftIadeKontrol(?)}";

        int i = 0;
        Object[] inputValues = new Object[0];
        Object[] outputValues = new Object[2];

        try {
            Session session = DAOSession.getSession("BNSPRDal");
            i = 0;

            outputValues[i++] = BnsprType.REFCURSOR;
            outputValues[i++] = "RC_RETURN_LIST";

            GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
            oMap.putAll(resultMap);

            String tableName = "RC_RETURN_LIST";
            String NKolayDurumGuncelleList = "NKOLAY_DURUM_GUNCELLE_LIST";

            for (int k = 0; k < oMap.getSize(tableName); k++) {
                try {
                    GMMap Nkolay = GMServiceExecuter.call("BNSPR_NKOLAY_EFT_IADE_BILDIR", new GMMap()

                    .put("KRD_BASVURU_NO", resultMap.getBigDecimal(tableName, k, "KRD_BASVURU_NO"))
                    .put("DURUM_KODU", resultMap.getString(tableName, k, "DURUM_KODU"))
                    .put("ACIKLAMA_ID", resultMap.getBigDecimal(tableName, k, "ACIKLAMA_ID"))
                    .put("ACIKLAMA", resultMap.getString(tableName, k, "ACIKLAMA")));

                    oMap.put(NKolayDurumGuncelleList, k, "RESPONSE", Nkolay.getBigDecimal("RESPONSE"));
                    oMap.put(NKolayDurumGuncelleList, k, "RESPONSE_DATA", Nkolay.getString("RESPONSE_DATA"));
                    oMap.put(NKolayDurumGuncelleList, k, "TX_NO", resultMap.getBigDecimal(tableName, k, "TX_NO"));

                }
                catch (Exception e) {
                    e.getMessage();
                    e.printStackTrace();
                    oMap.put(NKolayDurumGuncelleList, k, "RESPONSE", RESPONSE_FAIL);
                    oMap.put(NKolayDurumGuncelleList, k, "RESPONSE_DATA", e.getMessage());
                    oMap.put(NKolayDurumGuncelleList, k, "TX_NO", resultMap.getBigDecimal(tableName, k, "TX_NO"));
                }
            }

            for (int k = 0; k < oMap.getSize(tableName); k++) {

                if ("0".equals(oMap.getString(NKolayDurumGuncelleList, k, "RESPONSE"))) {

                    TuGonderTx tuGonderTx = (TuGonderTx) session.get(TuGonderTx.class, oMap.getBigDecimal(NKolayDurumGuncelleList, k, "TX_NO"));
                    if (tuGonderTx != null) {
                        tuGonderTx.setIadeBildirimDurum("F");
                        tuGonderTx.setIadeBildirimAciklama(oMap.getString(NKolayDurumGuncelleList, k, "RESPONSE_DATA"));
                        session.saveOrUpdate(tuGonderTx);
                    }
                }
                session.flush();
            }
        }
        catch (Exception e) {}

     return oMap;

    }
}
