package tr.com.aktifbank.bnspr.upt.services.scheduler;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TransferServices {

	private static Logger logger = Logger.getLogger(TransferServices.class);

	private static void sendMail(BigDecimal trxNo, String subject, String body) {
		
		GMMap iMap = new GMMap();
		iMap.put("MAIL_TO", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "UPT_SCHEDULER_RNA_MAIL_TO")).getString("DEGER"));
		iMap.put("TRX_NO", trxNo);
		iMap.put("MAIL_FROM", "System@aktifbank.com.tr");
		iMap.put("MAIL_SUBJECT", subject);
		iMap.put("MAIL_BODY", body);
		iMap.put("IS_BODY_HTML", "H");
		GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", iMap);
	}
	
	@GraymoundService("BNSPR_UPT_REFUND_NOTIFICATION_AUTOMATION")
	public static GMMap bnsprUptRefundNotificationAutomation(GMMap iMap) {
		
		BigDecimal ekranKod = new BigDecimal(2312);
		int limit;
		StringBuilder aciklama2 = new StringBuilder();
		String referans = "";
		GMMap oMap = new GMMap(), eftMap = new GMMap();
		
		try {
			
			if(!iMap.containsKey("TARIH")) {
				iMap.put("TARIH", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).get("BANKA_TARIH"));
			}
			
			limit = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", new GMMap().put("PARAMETRE", "UPT_SCHEDULER_RNA_LIMIT")).getInt("DEGER");
			oMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_rc_tu.rc_tu_giden_eft_iade_gelen(?)}", "RECORDS", BnsprType.DATE, iMap.getDate("TARIH"));

			if(oMap.getSize("RECORDS") > limit * 2) {
				sendMail(null, "UPT Iade Bildirim Otomasyonu - Bekleyen Kay�t Say�s� Bildirimi", "Bekleyen kay�t say�s�: " + String.valueOf(oMap.getSize("RECORDS")));
			}
			
			for(int i = 0; i < Math.min(oMap.getSize("RECORDS"), limit); i++) {
				
				referans = oMap.getString("RECORDS", i, "TU_REFERANS");
				
				eftMap = GMServiceExecuter.call("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", new GMMap().put("TRX_NO", oMap.getBigDecimal("RECORDS", i, "IADE_EFT_TXNO")));

				aciklama2.setLength(0);
				aciklama2.append(referans)
					.append("-")
					.append(new SimpleDateFormat("dd/MM/yyyy").format(eftMap.getDate("ILGILI_ISLEM_TARIH")))
					.append("-")
					.append(oMap.getString("RECORDS", i, "GONDEREN_ADSOYAD"));
				
				eftMap.put("ODEME_TX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				eftMap.put("ISLEM_TIPI", eftMap.getString("ISLEM_TIPI", "M"));
				eftMap.put("GELEN_GIDEN", "GELEN");
				if ("2315".equals(oMap.getString("RECORDS", i, "ISLEM_KOD"))) 
   				     eftMap.put("EKRAN_NO", ekranKod);
				else
					eftMap.put("EKRAN_NO", new BigDecimal(2371));

				eftMap.put("ACIKLAMA_2", aciklama2.toString());
				
				GMServiceExecuter.executeNT("BNSPR_EFT_SAVE", eftMap);
			}
		}
		
		catch(Exception e) {
			
			logger.error("BNSPR_UPT_REFUND_NOTIFICATION_AUTOMATION err:", e);
			sendMail(eftMap.getBigDecimal("TRX_NO"), "UPT Iade Bildirim Otomasyonu - Sorunlu ��lem", referans + " - " + e.getMessage());
		}
		
		return new GMMap();
	}
}