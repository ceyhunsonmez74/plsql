package tr.com.aktifbank.bnspr.upt.services.core;

import java.sql.CallableStatement;
import java.sql.Connection;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CoreServices {

	private static Logger logger = Logger.getLogger(CoreServices.class);
	
	private static final String statusProcessed = "P";
	//private static final String statusCanceled = "2";
	
	private static final String responseSuccess = "2";
	private static final String responseFailure = "0";
	
	@GraymoundService("UPT_SAVE_TRANSACTION_LOG")
	public static GMMap uptSaveTransactionLog(GMMap iMap) {
		
		try {

			if(!iMap.getBoolean("F_RECONCILIATION_AUTOMATION")) {
				
				logger.info("UPT_SAVE_TRANSACTION_LOG > F_RECONCILIATION_AUTOMATION: false");
				
				if(iMap.containsKey("LOG_SERVICE")) {
					GMServiceExecuter.call(iMap.getString("LOG_SERVICE"), iMap);
				}
				
				GMServiceExecuter.call("UPT_CONFIRM_LOG", iMap);
			} else {
				logger.info("UPT_SAVE_TRANSACTION_LOG > F_RECONCILIATION_AUTOMATION: true");
			}
	
			return new GMMap().put("RESPONSE", responseSuccess);
		
		} catch(Exception e) {

			logger.error("UPT_SAVE_TRANSACTION_LOG err: " + e.getMessage());
			return new GMMap()
				.put("RESPONSE", responseFailure)
				.put("RESPONSE_DATA", e.getMessage());
		} 
	}
	
	@GraymoundService("UPT_SAVE_TRANSACTION_STATUS")
	public static GMMap uptSaveTransactionStatus(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			/* incele muabakat nassil olmali ?
			 Session	session	= DAOSession.getSession("BNSPRDal");
			 
			
			ClksislemMutabakat clksIslemMutabakat = new ClksislemMutabakat(
				iMap.getBigDecimal("TRX_NO"),
				responseSuccess.equals(iMap.getString("RESPONSE")) ? "P" : "C",
				new java.util.Date());
			
			session.saveOrUpdate(clksIslemMutabakat);
			session.flush();
			return oMap;
			*/
			GMServiceExecuter.call("UPT_MUTABAKAT_TAMAMLA", iMap);
			return oMap;
			
		} catch(Exception e) {

			logger.error("UPT_SAVE_TRANSACTION_STATUS err: " + e.getMessage());
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("UPT_CONFIRM_LOG")
	public static GMMap confirmLog(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String call = "{call PKG_TU.Confirm_tx_log(?,?)}";
		String tuRef = iMap.getString("TU_REFERANS");
		if (StringUtils.isEmpty(tuRef)) {
			tuRef = GMServiceExecuter.call("GET_TU_REFERENCE", new GMMap().put("TRX_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"))).getString("TU_REF");
		}

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(call);

			stmt.setBigDecimal(1, iMap.getBigDecimal("BANKA_ISLEM_NO"));
			stmt.setString(2, tuRef);
			stmt.execute();

		}
		catch (Exception e) {

			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("UPT_CANCEL_LOG")
	public static GMMap cancelLog(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String call = "{call PKG_TU.cancel_confirm_tx_log(?,?,?)}";

		String tuRef = GMServiceExecuter.call("GET_TU_REFERENCE", new GMMap().put("TRX_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"))).getString("TU_REF");
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(call);

			stmt.setBigDecimal(1, iMap.getBigDecimal("BANKA_ISLEM_NO"));
			stmt.setString(2, tuRef);
			stmt.setString(3, iMap.getString("ISLEM_TIP"));
			stmt.execute();

		}
		catch (Exception e) {

			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("UPT_MUTABAKAT_TAMAMLA")
	public static GMMap uptMutabakatTamamla(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		String callMutabakat = "{call PKG_TU.Mutabakat_Tamamla(?)}";

		try {
			conn = DALUtil.getGMConnection();


			stmt = conn.prepareCall(callMutabakat);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BANKA_ISLEM_NO"));
			stmt.execute();



		}
		catch (Exception e) {

			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}


}
