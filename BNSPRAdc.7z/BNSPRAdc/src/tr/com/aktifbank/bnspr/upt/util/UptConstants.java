package tr.com.aktifbank.bnspr.upt.util;


public class UptConstants {

	public static final int ISLEM_YI_GIDEN_SWIFT = 12;
	public static final int ISLEM_YD_GIDEN_SWIFT = 13;
	public static final int ISLEM_ATM_NY_HESAP = 60;
	public static final int ISLEM_ATM_NY_IBAN = 61;
	public static final int ISLEM_ATM_NY_EUPT = 62;
	public static final int ISLEM_ATM_TOPUP_PASSOLIG_KART = 63;
	public static final int ISLEM_ATM_TOPUP_PASSOLIG_KIMLIK = 64;
	public static final int ISLEM_ATM_TOPUP_NKOLAY_KART = 65;
	public static final int ISLEM_TOPUP_PASSOLIG_KIMLIK = 65;
	public static final int ISLEM_TOPUP_PASSOLIG_KART = 66;
	public static final int ISLEM_TOPUP_NKOLAY_KIMLIK = 57;
	public static final int ISLEM_TOPUP_NKOLAY_KART = 58;
	public static final int ISLEM_UPT_PCH = 70;
	public static final int ISLEM_UPT_IPC = 71;
	public static final int ISLEM_UPT = 10;

	public static final String ISLEM_KOD_NAKIT_YATAN = "2050";
	public static final String ISLEM_KOD_NAKIT_CEKILEN = "2051";
	public static final String ISLEM_KOD_REFERANSLI_ODEME = "2032";
	public static final String ISLEM_KOD_HAVALE_ODEME = "2030";
	public static final String ISLEM_KOD_UPT = "2315";
	public static final String ISLEM_KOD_GIDEN_SWIFT = "2850";
	public static final String ISLEM_KOD_ATM_NY_HESAP = "2049";
	public static final String ISLEM_KOD_ATM_NY_IBAN = "2049";
	public static final String ISLEM_KOD_ATM_NY_EUPT = "2061";
	public static final String ISLEM_KOD_ATM_TOPUP_PASSOLIG_KART = "2048";
	public static final String ISLEM_KOD_ATM_TOPUP_PASSOLIG_KIMLIK = "2048";
	public static final String ISLEM_KOD_ATM_TOPUP_NKOLAY_KART = "20481";
	public static final String ISLEM_KOD_ATM_TOPUP_NKOLAY_KIMLIK = "20481";
	public static final String ISLEM_KOD_TOPUP_PASSOLIG_KART = "2053";
	public static final String ISLEM_KOD_TOPUP_PASSOLIG_KIMLIK = "2053";
	public static final String ISLEM_KOD_TOPUP_NKOLAY_KART = "20531";
	public static final String ISLEM_KOD_TOPUP_NKOLAY_KIMLIK = "20531";
	public static final String ISLEM_KOD_UPTAS_ODEME = "3552";
	public static final String ISLEM_KOD_UPTAS_TALIMAT = "2316";
	public static final String ISLEM_KOD_UPT_HAVALE_NAKIT_YATIRMA = "2117";

	public static final String ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME = "2118";

	public static final String ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME_USD = "21181";
	public static final String ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME_EUR = "21182";

	public static final int EKRAN_KOD_UPT_HAVALE_NAKIT_YATIRMA = 2117;
	public static final int EKRAN_KOD_UPT_HAVALE_NAKIT_CEKME = 2118;



	public static final String IPTAL_GISE = "G";
	public static final String IPTAL_VAZGEC = "V";
	public static final String REVERSAL = "R";

	public static final String BRAND_CARD_NKOLAY = "NKOLAY";
	public static final String BRAND_CARD_PASSOLIG = "PASSOLIG";
	public static final int ODEME_ISLEM_NAKIT_CEKME = 1;
	public static final String IBAN_KONTROL = "1";
	public static final String RESPONSE_DATA = "RESPONSE_DATA";
	public static final String RESPONSE = "RESPONSE";
	public static final String ISLEM_SEKLI_UPT_YATAN = "UPTYTN";
	public static final String ISLEM_SEKLI_UPT_CEKIM = "UPTNC";

	
	public enum NakitYatirmaIslemTip
	{
		KREDI("4"), IBAN_NAKIT_YATIRMA("2"), HESAP_NAKIT_YATIRMA("1");
		private String kod;

		NakitYatirmaIslemTip(String kod) {
			this.kod = kod;
		}

		@Override
		public String toString() {
			return kod;
		}

		public String getKod() {
			return kod;
		}
		public static NakitYatirmaIslemTip getEnum(String kod) {
			for (NakitYatirmaIslemTip v : values())
				if (v.toString().equalsIgnoreCase(kod))
					return v;
			throw new IllegalArgumentException();
		}
		
	}

	public enum DovizKodu {
		TRY("TRY"), EUR("EUR"), USD("USD");
		private String kod;

		DovizKodu(String kod) {
			this.kod = kod;
		}

		@Override
		public String toString() {
			return kod;
		}

		public String getKod() {
			return kod;
		}

		public static DovizKodu getEnum(String kod) {
			for (DovizKodu v : values())
				if (v.toString().equalsIgnoreCase(kod))
					return v;
			throw new IllegalArgumentException();
		}

	}

	public enum KasaKimlikTipi {
		UCUNCU_SAHIS_NAKIT_YATIRMA("4");
		private String kod;

		KasaKimlikTipi(String kod) {
			this.kod = kod;
		}

		@Override
		public String toString() {
			return kod;
		}

		public String getKod() {
			return kod;
		}

		public static KasaKimlikTipi getEnum(String kod) {
			for (KasaKimlikTipi v : values())
				if (v.toString().equalsIgnoreCase(kod))
					return v;
			throw new IllegalArgumentException();
		}

	}

	public enum HesapHareketKodu {
		UCUNCU_SAHIS_NAKIT_YATIRMA("4");
		private String kod;

		HesapHareketKodu(String kod) {
			this.kod = kod;
		}

		@Override
		public String toString() {
			return kod;
		}

		public String getKod() {
			return kod;
		}

		public static HesapHareketKodu getEnum(String kod) {
			for (HesapHareketKodu v : values())
				if (v.toString().equalsIgnoreCase(kod))
					return v;
			throw new IllegalArgumentException();
		}

	}


	public enum BelgeKontrol {

		UYGUN("1"), EKSIK("2"), UYUMSUZ("3"), SUPHELI("4"), GONDERILDI("5");

		private String kod;

		BelgeKontrol(String kod) {
			this.kod = kod;
		}

		@Override
		public String toString() {
			return kod;
		}
	}
}
