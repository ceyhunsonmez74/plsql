package tr.com.aktifbank.bnspr.upt.services.credit;

import java.math.BigDecimal;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class InstallmentLoanServices {

	private static Logger logger = Logger.getLogger(InstallmentLoanServices.class);
	private static int HAVALE_TIPI_HESABA = 1;
	
	/**
	 * Description : TBA
	 * 
	 * @param iMap GMMap
	 * 		{...}
	 * @return GMMap
	 *      {...}
	 */
	@GraymoundService("UPT_INSTALLMENT_LOAN_PAYMENT")
	public static GMMap installmentLoanPayment(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		GMMap proxyMap = new GMMap();
		
		try {
			
            proxyMap.put("GONDEREN_MUSTERI_NO", iMap.get("GONDEREN_MUSTERI_NO"));
            proxyMap.put("GONDEREN_HESAP_NO", iMap.get("GONDEREN_HESAP_NO"));
            proxyMap.put("ALICI_HESAP_NO", GMServiceExecuter.call("BNSPR_COMMON_GET_ACCOUNT_WITH_IBAN", new GMMap().put("IBAN", iMap.getString("ALICI_HESAP_NO"))).get("ACCOUNT_NO"));
            proxyMap.put("ALICI_SUBE", GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", new GMMap().put("HESAP_NO", proxyMap.getString("ALICI_HESAP_NO"))).get("SUBE_KODU"));
            proxyMap.put("TUTAR", iMap.get("TAKSIT_TUTARI"));
            proxyMap.put("HAVALE_TIPI", HAVALE_TIPI_HESABA); 
			
			proxyMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			proxyMap.put("REZERVASYON_KURU", 1);
			proxyMap.putAll(GMServiceExecuter.call("BNSPR_GET_GERI_ODEME_TAKSIT_TAHSILAT", proxyMap));

			// Case: Kismi taksit tahsilati
			if("KISMI".equals(proxyMap.getString("TAKSIT_DURUM"))) {
				proxyMap.putAll(GMServiceExecuter.call("BNSPR_GET_GERI_ODEME_TAKSIT_TAHSILAT_KISMI", proxyMap));
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			BirKullandirim birKullandirim = (BirKullandirim) session.get(BirKullandirim.class, proxyMap.getBigDecimal("BASVURU_NO"), LockMode.UPGRADE_NOWAIT);
			
			proxyMap.put("TAHSILAT_HESAP_NO", birKullandirim.getOtoVirmanHesap());
			proxyMap.put("TAHSILAT_DOVIZ_KODU", "TRY");
			proxyMap.put("KREDI_HESAP_NO", birKullandirim.getKrdHesapNo());
			proxyMap.put("DOVIZ_KODU", "TRY");
			proxyMap.put("BAKIYE", DALUtil.callOneParameterFunction("{? = call abs(pkg_hesap.HesapBakiyeAl(?))}", Types.NUMERIC, proxyMap.getString("KREDI_HESAP_NO")));
			proxyMap.put("DOVIZ_BAKIYE", DALUtil.callOneParameterFunction("{? = call pkg_bireysel2.KalanAnapara(?)}", Types.NUMERIC, proxyMap.getBigDecimal("BASVURU_NO")));
			proxyMap.put("ISLEM_TURU", 1);
			proxyMap.put("TAHSILAT_TUTARI_TAM", proxyMap.get("TAHSILAT_TUTARI"));
			proxyMap.put("TAHSILAT_TUTARI", (iMap.getBigDecimal("TAKSIT_TUTARI").compareTo(proxyMap.getBigDecimal("TAHSILAT_TUTARI")) < 0) ? iMap.get("TAKSIT_TUTARI") : proxyMap.get("TAHSILAT_TUTARI"));
			proxyMap.put("TAHSILAT_TUTARI_TL", proxyMap.get("TAHSILAT_TUTARI"));
			proxyMap.put("ERKEN_OR_GECIKME", BigDecimal.ZERO.equals(proxyMap.getBigDecimal("GECIKME_FAIZ")) ? BigDecimal.ZERO.equals(proxyMap.getBigDecimal("ERKEN_ODEME_FAIZ_INDIRIM")) ? "X" : "E" : "G");
			proxyMap.put("ERK_TAH_FAIZ_IND_GEC_FAIZI", "G".equals(proxyMap.getString("ERKEN_OR_GECIKME")) ? proxyMap.getBigDecimal("GECIKME_FAIZ") : proxyMap.getBigDecimal("ERKEN_ODEME_FAIZ_INDIRIM"));
			proxyMap.put("ODENECEK_TAKSIT_NO", iMap.get("TAKSIT_NO"));
			proxyMap.put("ODENECEK_TAKSIT_VADE", proxyMap.remove("TAKSIT_VADE"));
			proxyMap.put("ODENECEK_TAKSIT_TUTARI", proxyMap.remove("TAKSIT_TUTARI"));
			proxyMap.put("ACIKLAMA", "Bireysel Kredi Geri �deme - " + (String) GMContext.getCurrentContext().getSession().get("CHANNEL"));
			proxyMap.put("TAKSIT_FAIZI", proxyMap.remove("FAIZ"));
			proxyMap.put("TAKSIT_FAIZI_KKDF", proxyMap.remove("FAIZ_KKDF"));
			proxyMap.put("TAKSIT_FAIZI_BSMV", proxyMap.remove("FAIZ_BSMV"));
			proxyMap.put("ALINACAK_GECIKME_FAIZI", proxyMap.remove("GECIKME_FAIZ"));
			proxyMap.put("TAKSITTE_KALAN_BORC", proxyMap.getBigDecimal("TAHSILAT_TUTARI_TAM").subtract(proxyMap.getBigDecimal("TAHSILAT_TUTARI")));
			proxyMap.put("TAKSITTE_KALAN_BORC_YP", BigDecimal.ZERO);
			proxyMap.put("TAKSIT_ANAPARA", proxyMap.remove("ANAPARA"));
			proxyMap.put("TAKSIT_ANAPARA", "G".equals(proxyMap.getString("ERKEN_OR_GECIKME")) ? proxyMap.getBigDecimal("TAKSIT_ANAPARA").subtract(proxyMap.getBigDecimal("TAKSITTE_KALAN_BORC")) : proxyMap.getBigDecimal("TAKSIT_ANAPARA"));
			proxyMap.put("TAKSIT_ANAPARA_TL", BigDecimal.ZERO);
			proxyMap.put("KAP_GEC_ARA_FAIZI", "G".equals(proxyMap.getString("ERKEN_OR_GECIKME")) ? proxyMap.getBigDecimal("ALINACAK_GECIKME_FAIZI") : BigDecimal.ZERO);
			proxyMap.put("KAP_GEC_ARA_FAIZI_TL", BigDecimal.ZERO);
			proxyMap.put("KAP_GEC_ARA_FAIZI_KKDF", "G".equals(proxyMap.getString("ERKEN_OR_GECIKME")) ? proxyMap.remove("GECIKME_FAIZ_KKDF") : BigDecimal.ZERO);
			proxyMap.put("KAP_GEC_ARA_FAIZI_KKDF_TL", BigDecimal.ZERO);
			proxyMap.put("KAP_GEC_ARA_FAIZI_BSMV", "G".equals(proxyMap.getString("ERKEN_OR_GECIKME")) ? proxyMap.remove("GECIKME_FAIZ_BSMV") : BigDecimal.ZERO);
			proxyMap.put("KAP_GEC_ARA_FAIZI_BSMV_TL", BigDecimal.ZERO);
			proxyMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			proxyMap.remove("ERKEN_ODEME_FAIZ_INDIRIM");
			
			// Taksit Tahsilati
			proxyMap.putAll(GMServiceExecuter.call("BNSPR_TRN3133_SAVE", proxyMap));
			oMap.put("ISLEM_NO", proxyMap.get("TRX_NO"));
			
		} catch (Exception e) {
			
			logger.error("UPT_INSTALLMENT_LOAN_PAYMENT err:" + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
}
