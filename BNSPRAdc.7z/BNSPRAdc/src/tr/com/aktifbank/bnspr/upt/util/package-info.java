/**
 * 
 */
/**
 * @author nigar.karamahmutoglu
 *
 */
package tr.com.aktifbank.bnspr.upt.util;