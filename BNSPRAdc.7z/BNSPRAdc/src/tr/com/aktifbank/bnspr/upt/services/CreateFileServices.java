package tr.com.aktifbank.bnspr.upt.services;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.upt.util.FtmUtilServices;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CreateFileServices {
    private static Logger logger = Logger.getLogger(CreateFileServices.class);

    @GraymoundService("BNSPR_FTM_GET_ACCOUNT_ACT_LIST")
    public static GMMap tuHesapHareketListesi(GMMap iMap) {
        Session session = DAOSession.getSession("BNSPRDal");
        GMMap oMap = new GMMap();

        try {

            if (((GMMap) GMServiceExecuter.call("BNSPR_COMMON_CHECK_ACCOUNT_WHITELIST_FOR_WS", iMap)).getInt("SONUC") == 0) {
                GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 2086));
            }

            oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_HAREKET_LIST", iMap));

            String tableName = "RESULTS";
            BigDecimal ftmProcessId = iMap.getBigDecimal("FTM_PROCESS_ID");

            int k = 0;

            if (oMap.getSize(tableName) > 0) {
                BigDecimal lineNumber = BigDecimal.ZERO;
                for (k = 0; k < ((oMap.getSize(tableName))); k++) {
                    lineNumber = lineNumber.add(BigDecimal.ONE);
                    String line = oMap.getString(tableName, k, "ISLEM_TARIHI") + "|" + oMap.getString(tableName, k, "VALOR_TARIHI") + "|" + oMap.getString(tableName, k, "ISLEM_ACIKLAMA") + "|" + oMap.getString(tableName, k, "HAREKET_TUTARI") + "|" + oMap.getString(tableName, k, "ISLEM_TIPI") + "|" + oMap.getString(tableName, k, "ISLEM_SONRASI_BAKIYE") + "|" + oMap.getString(tableName, k, "GONDEREN") + "|" + oMap.getString(tableName, k, "ISLEM_NO") + "|" + oMap.getString(tableName, k, "ISLEM_KOD") + "|" + oMap.getString(tableName, k, "FIS_NO") + "|" + oMap.getString(tableName, k, "KARAKTER") + "|" + oMap.getString(tableName, k, "YARAT_TAR") + "|" + oMap.getString(tableName, k, "MUHASEBE_TARIHI");
                    line = line.replace("null", "");
                    FtmFileContent ftmFileContentDetail = new FtmFileContent();
                    ftmFileContentDetail.setFtmProcessOid(ftmProcessId);
                    ftmFileContentDetail.setLineNumber(lineNumber);
                    ftmFileContentDetail.setLine(line);
                    ftmFileContentDetail.setOid(lineNumber.toString());
                    session.save(ftmFileContentDetail);
                    session.flush();

                }
            }

            else {
                FtmFileContent ftmFileContentDetail = new FtmFileContent();
                ftmFileContentDetail.setFtmProcessOid(ftmProcessId);
                ftmFileContentDetail.setLineNumber(BigDecimal.ONE);
                ftmFileContentDetail.setLine("");
                ftmFileContentDetail.setOid(BigDecimal.ONE.toString());
                session.save(ftmFileContentDetail);
                session.flush();
            }
        }

        catch (Exception e) {
            logger.error("BNSPR_FTM_GET_ACCOUNT_ACT_LIST err: " + e);
            throw ExceptionHandler.convertException(e);
        }

        return iMap;
    }

    @GraymoundService("BNSPR_FTM_GET_ACCOUNT_ACT_LIST_EXECUTE")
    public static GMMap getTUHareketListFTM(GMMap iMap) {

        GMMap oMap = new GMMap();
        String fileName = "";
        BigDecimal ftmProcessId = null;
        String ftmId = "";

        try {
            ftmProcessId = FtmUtilServices.getNextValueOfFTMProcessId();
            ftmId = FtmUtilServices.getGlobalParam("HESAP_HAREKETLERI_FTM_ID");

            fileName = iMap.getString("TRANSACTION_ID") + ".txt";
            iMap.put("FTM_PROCESS_ID", ftmProcessId);

            GMServiceExecuter.executeNT("BNSPR_FTM_GET_ACCOUNT_ACT_LIST", iMap);

            FtmUtilServices.ftmTransferSingleFile(ftmId, ftmProcessId, fileName);
        }
        catch (Exception e) {
            logger.error("BNSPR_FTM_GET_HESAP_HAREKET_LIST_EXECUTE err: " + e);
         //   throw ExceptionHandler.convertException(e);
        }

        return oMap;
    }
}
