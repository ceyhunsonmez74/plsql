package tr.com.aktifbank.bnspr.upt.services.cashpayment;

import static tr.com.aktifbank.bnspr.upt.util.UptConstants.ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME;
import static tr.com.aktifbank.bnspr.upt.util.UptConstants.ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME_EUR;
import static tr.com.aktifbank.bnspr.upt.util.UptConstants.ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME_USD;
import static tr.com.aktifbank.bnspr.upt.util.UptConstants.ISLEM_SEKLI_UPT_CEKIM;
import static tr.com.aktifbank.bnspr.upt.util.UptConstants.ODEME_ISLEM_NAKIT_CEKME;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.clks.util.BnsprAdcMessageExecuter;
import tr.com.aktifbank.bnspr.clks.util.BnsprAdcUtil;
import tr.com.aktifbank.bnspr.dao.UptHavaleOdemeTx;
import tr.com.aktifbank.bnspr.upt.util.UPTUtil;
import tr.com.aktifbank.bnspr.upt.util.UptConstants.DovizKodu;
import tr.com.obss.adc.core.pojo.User;
import tr.com.obss.adc.core.pojo.UserIntegration;
import tr.com.obss.adc.core.util.ADCCore;
import tr.com.obss.adc.core.util.ADCParameters;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
public class CashPaymentServices {

	private static Logger logger = Logger.getLogger(CashPaymentServices.class);



	@GraymoundService("UPT_CASH_PAYMENT_REQUEST")
	public static GMMap cashPaymentRequest(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap processMap = new GMMap();
		try {

			iMap.put("ISLEM_TURU", "P").put("ISLEM_TIPI", ODEME_ISLEM_NAKIT_CEKME);
			

			String ekranKodu = ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME;
			

			iMap.putAll(validateHesap(new GMMap().put("HESAP_NO", iMap.getString("HESAP_NO")).put("IBAN", iMap.getString("IBAN"))));



			if (iMap.getString("TUTAR") == null || iMap.getString("TUTAR").length() == 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 330).put("P1", "tutar"));
			}
			
			String hesapMusteriNo = GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", iMap).getString("MUSTERI_NO");

			/* AdcSession incele**/
			String orgUserOid = (String) ADCSession.get("USER_OID");
			String userOid = UPTUtil.getUserOidUsingCustomerNo(hesapMusteriNo);
			ADCSession.put("PARENT_USER_OID", orgUserOid);
			ADCSession.put("USER_OID", userOid);


			BigDecimal customerNo = (BigDecimal) GMContext.getCurrentContext().getSession().get("INTEGRATION_ID");


			String hesapTckn = GMServiceExecuter.call("BNSPR_COMMON_GET_TCKN", new GMMap().put("MUSTERI_NO", hesapMusteriNo)).getString("TCKN");
			String hesapVkn = GMServiceExecuter.call("BNSPR_COMMON_GET_VKN", new GMMap().put("MUSTERI_NO", hesapMusteriNo)).getString("VKN");
			String hesapUnvan = GMServiceExecuter.call("BNSPR_COMMON_GET_UNVAN", new GMMap().put("MUSTERI_NO", hesapMusteriNo)).getString("UNVAN");


				if (!(iMap.getString("ISLEM_YAPAN_TCKN_VKN").equals(hesapTckn) || iMap.getString("ISLEM_YAPAN_TCKN_VKN").equals(hesapVkn))) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1920));
				}
				if (

				!BnsprAdcUtil.matchStrings(iMap.getString("ISLEM_YAPAN_BILGI", 0, "UNVAN"), hesapUnvan)) {

					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 2290));
				}

			GMMap hesapMusteriDetayMap = new GMMap();
			hesapMusteriDetayMap = GMServiceExecuter.call("UPT_GET_HESAP_MUSTERI_DETAY", new GMMap().put("HESAP_NO", iMap.getString("HESAP_NO")).put("DOVIZ_KOD", iMap.getString("DOVIZ_KODU")));





			if (DovizKodu.TRY.getKod().equals(hesapMusteriDetayMap.getString("DOVIZ_KODU"))) {
				ekranKodu = ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME;
			}
			else if (DovizKodu.USD.getKod().equals(hesapMusteriDetayMap.getString("DOVIZ_KODU"))) {
				ekranKodu = ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME_USD;
			}
			else if (DovizKodu.EUR.getKod().equals(hesapMusteriDetayMap.getString("DOVIZ_KODU"))) {
				ekranKodu = ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME_EUR;
			}

			else {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 3).put("P1", "DOVIZ_KODU").put("P2", iMap.getString("DOVIZ_KODU")));
			}

			GMMap masrafMap = new GMMap();
			masrafMap.putAll(GMServiceExecuter.call("INTERNET_HAVALE_EFT_MASRAF_HESAPLA", new GMMap().put("EKRAN_KODU", ekranKodu).put("TUTAR", iMap.getBigDecimal("TUTAR")).put("DOVIZ_KOD", hesapMusteriDetayMap.getString("DOVIZ_KODU")).put("MUSTERI_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO")).put("KARSI_HESAP_NO", iMap.getBigDecimal("HESAP_NO"))));

			processMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getString("TRX_NO"));
			processMap.put("DOVIZ_KODU", hesapMusteriDetayMap.get("DOVIZ_KODU"));

			processMap.put("KARSI_HESAP_NO", hesapMusteriDetayMap.getString("HESAP_NO"));

			processMap.put("MASRAF_TUTARI", masrafMap.getBigDecimal("TOPLAM_MASRAF", BigDecimal.ZERO).add(masrafMap.getBigDecimal("TOPLAM_BSMV", BigDecimal.ZERO)));
			processMap.put("MASRAF_TAHSIL_DOVIZ", masrafMap.getString("DOVIZ_KODU"));
			processMap.put("MUSTERI_NO", hesapMusteriDetayMap.getString("MUSTERI_NO"));
			processMap.put("CUSTOMER_ID", hesapMusteriDetayMap.getString("MUSTERI_NO"));
			processMap.put("SUBE_KODU", hesapMusteriDetayMap.getString("SUBE_KODU"));
			processMap.put("SUBE_ADI", hesapMusteriDetayMap.getString("SUBE_ADI"));
			processMap.put("TUTAR", iMap.getString("TUTAR"));
			processMap.put("TUTAR_CODE", hesapMusteriDetayMap.getString("DOVIZ_KODU"));

			/*
						map.put("PROCESS_CODE", "CLKS-PAY");/*CLKS_PAYMENT_PROCESS
						*/
			
			GMMap paramMap = new GMMap();
			paramMap.put("PARAMETRE", "UPT_HESABA_" + iMap.getString("DOVIZ_KODU") + "_HAVUZ");

			processMap.put("ALACAK_HESAP_NO", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", paramMap).getString("DEGER"));

			processMap.put("ALACAK_MUSTERI_NO", customerNo);

			processMap.put("BORC_HESAP_NO", iMap.getString("HESAP_NO"));
			processMap.put("BORC_MUSTERI_NO", hesapMusteriDetayMap.getString("MUSTERI_NO"));
			processMap.put("ISLEM_SEKLI", ISLEM_SEKLI_UPT_CEKIM);

			processMap.put("TUTAR_CODE", processMap.getString("DOVIZ_KODU"));
			processMap.put("ISLEM_YAPAN_AD_SOYAD", iMap.getString("ISLEM_YAPAN_BILGI", 0, "UNVAN"));
			processMap.put("IBAN", iMap.get("IBAN"));
			processMap.put("HESAP_NO", iMap.get("HESAP_NO"));
			processMap.put("CONTROL_MASK", "0");
			processMap.putAll(UPTUtil.FeedMapCaseTwo());

			if ("0".equals(processMap.getString("BORC_HESAP_NO"))) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1530));
			}
			/*
			map.put("PROCESS_CODE", "CLKS-PAY");/*UPT_PAYMENT_PROCESS
			oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", map);
			*/

			processMap.put("ISLEM_TARIHI", new Date(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH").getTime()));
			processMap.put("VALOR_TARIHI", new Date(GMServiceExecuter.call("BNSPR_TRN1101_GET_TARIH_AND_KULLANICI", new GMMap()).getDate("BANKA_TARIH").getTime()));
			processMap.putAll(GMServiceExecuter.call("BNSPR_TRN2003_GET_TYPE", new GMMap().put("CUSTOMER_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO"))));
			processMap.putAll(GMServiceExecuter.call("BNSPR_TRN4300_GET_MUSTERI_ADRES", new GMMap().put("MUSTERI_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO"))));
			processMap.putAll(GMServiceExecuter.call("UPT_GET_MUSTERI_BILGI", new GMMap().put("MUSTERI_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO"))));
			processMap.put("HESAP_MUSTERI_BILGILERI", 0, "ADRES", processMap.getString("TAM_ADRES"));
			processMap.put("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO"));
			processMap.put("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_TIPI", processMap.getString("CUSTOMER_TYPE"));

			oMap.put("HESAP_MUSTERI_BILGILERI", processMap.get("HESAP_MUSTERI_BILGILERI"));
			processMap.putAll(iMap);
			oMap.putAll(GMServiceExecuter.execute("UPT_CASH_PAYMENT_PROCESS", processMap));
			oMap.put("SUBE_KODU", hesapMusteriDetayMap.get("SUBE_KODU"));
			oMap.put("SUBE_ADI", hesapMusteriDetayMap.get("SUBE_ADI"));
			oMap.put("DOVIZ_KODU", hesapMusteriDetayMap.get("DOVIZ_KODU"));

			oMap.put("BANKA_ISLEM_NO", processMap.getString("TRX_NO"));
			oMap.put("ISLEM", iMap.getString("ISLEM"));
			oMap.put("ODENEBILECEK_MAX_TUTAR", processMap.getString("TUTAR"));
			oMap.put("MASRAF_TUTARI", processMap.get("MASRAF_TUTARI"));
			oMap.put("IBAN", processMap.get("IBAN"));
			oMap.put("HESAP_NO", processMap.get("HESAP_NO"));
			oMap.put("BORC_TUTARI", processMap.getString("TUTAR"));

			DateFormat df = new SimpleDateFormat("ddMMyyyy");
			oMap.put("VALOR", df.format(processMap.getDate("VALOR_TARIHI")));
			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));

			try {
				GMServiceExecuter.call("UPT_CASH_PAYMENT_SEND_OTP", processMap);
			}
			catch (Exception e) {
				logger.error("UPT_CASH_PAYMENT_REQUEST  send otp err:", e);
			}

			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));
			return oMap;


		}
		catch (Exception e) {

			logger.error("UPT_CASH_PAYMENT_REQUEST err:", e);
			oMap = BnsprAdcMessageExecuter.callError(e.getMessage());
		}

		return oMap;

	}

	@GraymoundService("UPT_CASH_PAYMENT_SEND_OTP")
	public static GMMap cashPaymentSendOtp(GMMap iMap) {
		/*GMMap telMap = new GMMap();
		GMMap oMap = new GMMap();
		telMap.put("CUSTOMER_NO", iMap.getBigDecimal("MUSTERI_NO"));
		telMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", telMap));

		if (!"1".equals(telMap.getString("RESPONSE")) || StringUtils.isEmpty(telMap.getString("PHONE_NUMBER"))) {
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2933)));
		}
		// Send OTP
		sendOtp(iMap);
*/
		
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		User user = (User) session.createCriteria(User.class).add(Restrictions.eq("customerId", iMap.getBigDecimal("MUSTERI_NO"))).uniqueResult();
		if (user != null) {
			logger.info("CashPaymentServices > sendOtp: user exists!");
			String userOid = user.getOid();

			UserIntegration userInteraction = (UserIntegration) session.createCriteria(UserIntegration.class).add(Restrictions.eq("userOid", userOid)).add(Restrictions.eq("key", "PHONE_NUMBER")).uniqueResult();

			if (userInteraction != null && (userInteraction.getValue() != null)) {

				logger.info("CashPaymentServices > sendOtp: user integration exists!");
				GMMap otpMap = new GMMap().put("USER_OID", userInteraction.getUserOid()).put("PHONE_NUMBER", userInteraction.getValue());
				// .put("HEADER", "AKTIFBANK");

				otpMap.putAll(GMServiceExecuter.call("ADC_MAN_USER_OTP_CREATE", otpMap));
				if (!"2".equals(otpMap.getString("RESPONSE"))) {
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(3012)).put("P1", userInteraction.getValue()));
				}
				return BnsprAdcMessageExecuter.callSuccess("");
			}
			else {

				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2933)));
			}
		}
		else {
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2933)));
		}
	}
	




	@GraymoundService("UPT_CASH_PAYMENT_PROCESS")
	public static GMMap cashPaymentProcess(GMMap iMap) {
		

			if(iMap.getString("CONTROL_MASK", "1").charAt(0) == '0') {
				return GMServiceExecuter.call("BNSPR_TRN2118_SAVE", iMap);
			} else {
				
				return GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap);
			}

	}

	@GraymoundService("UPT_CASH_PAYMENT_CONFIRM")
	public static GMMap cashPaymentConfirm(GMMap iMap) {

		GMMap oMap = new GMMap();
		String orgUserOid = null;
		long sTime = System.currentTimeMillis();

		try {

			iMap.put("ISLEM_TURU", "P").put("ISLEM_TIPI", ODEME_ISLEM_NAKIT_CEKME);
			orgUserOid = (String) ADCSession.get("USER_OID");
			/* seniz upt islem logu icin log atma incele**/
			GMServiceExecuter.call("UPT_SAVE_TRANSACTION_LOG", iMap.put("LOG_SERVICE", "BNSPR_TRN2118_PAYMENT_LOG"));

			iMap.putAll(GMServiceExecuter.call("BNSPR_TRN2118_GET_MUSTERI_NO_CONFIRM", iMap));
			iMap.putAll(GMServiceExecuter.call("BNSPR_TRN2118_GET_ISLEM_BILGI", new GMMap().put("ISLEM_NO", iMap.getString("BANKA_ISLEM_NO")).put("ISLEM_TIPI", "NAKIT_CEKME")));

			UPTUtil.putUserOidInSessionForCustomerLimit(iMap);
			ADCSession.put("PARENT_USER_OID", orgUserOid);
			if (iMap.get("HESAP_MUSTERI_BILGILERI") != null) {
				ADCSession.put("USER_OID", UPTUtil.getUserOidUsingCustomerNo(iMap.getString("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_NO")));
			}


			if (ADCSession.get("USER_OID") == null) {
				throw new GMRuntimeException(0, GMMessageFactory.getMessage("UPTWRONGTCKN", null), true); // LOGNCHANNL
			}

			
			
			GMServiceExecuter.call("BNSPR_TRN2118_ISLEM_BILGISI_GUNCELLE", iMap);
			
			oMap.put("ISLEM_NO", iMap.getString("BANKA_ISLEM_NO"));
			oMap.put("BANKA_ISLEM_NO", iMap.getString("BANKA_ISLEM_NO"));
			oMap.put("ISLEM_KODU", iMap.getString("BANKA_ISLEM_NO"));
			oMap.put("ISLEM_TURU", "O");
			oMap.put("ACIKLAMA", " ");
			
			oMap.put("TUTAR_CODE", GMServiceExecuter.call("BNSPR_COMMON_GET_ISLEM_DETAY", new GMMap().put("TRX_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"))).getString("DOVIZ_KOD"));
			oMap.put("TUTAR", iMap.getString("TUTAR"));
			oMap.put("CONTROL_MASK", "1");
			oMap.putAll(UPTUtil.FeedMapCaseOne());
			
			/* process altyapisina geciste kullan
			oMap.put("PROCESS_CODE", "UPT-PAY"); // GraymoundService: CLKS_PAYMENT_PROCESS
			oMap = GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", oMap);
			**/
			oMap.putAll(GMServiceExecuter.execute("UPT_CASH_PAYMENT_PROCESS", oMap));
			oMap.put("BAKIYE", GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", new GMMap().put("HESAP_NO", iMap.getString("HESAP_NO"))));
			

			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));

		}

		catch (Exception e) {


			logger.error("UPT_CASH_PAYMENT_CONFIRM err:", e);
			oMap = BnsprAdcMessageExecuter.callError(e.getMessage());
			iMap.put("ERROR_MESSAGE", e.getMessage());
			iMap.put("MAIL_GONDER", ADCParameters.getString("TU_SORUNLU_MAIL_ATILSINMI"));
			iMap.put("MAIL_LIST", ADCParameters.getString("TU_SORUNLU_MAIL_ADRES_LIST"));

			GMServiceExecuter.call("TU_SORUNLU_ISLEM_MAIL_GONDER", iMap);
		}

		finally {
			ADCSession.remove("PARENT_USER_OID");
			ADCSession.put("USER_OID", orgUserOid);
		}

		return oMap;
	}

	@GraymoundService("UPT_VALIDATE_CASH_PAYMENT")
	public static GMMap validateCashPayment(GMMap iMap) {

		GMMap oMap = new GMMap();


		try {
			oMap.putAll(validateHesap(iMap));
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", oMap));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN2003_GET_TYPE", new GMMap().put("CUSTOMER_NO", oMap.getBigDecimal("MUSTERI_NO"))));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN4300_GET_MUSTERI_ADRES", new GMMap().put("MUSTERI_NO", oMap.getBigDecimal("MUSTERI_NO"))));
			oMap.putAll(GMServiceExecuter.call("UPT_GET_MUSTERI_BILGI", new GMMap().put("MUSTERI_NO", oMap.getBigDecimal("MUSTERI_NO"))));
			oMap.put("HESAP_MUSTERI_BILGILERI", 0, "ADRES", oMap.getString("TAM_ADRES"));
			oMap.put("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_NO", oMap.getBigDecimal("MUSTERI_NO"));
			oMap.put("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_TIPI", oMap.getString("CUSTOMER_TYPE"));
			oMap.put("DOVIZ_KODU", GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_DOVIZ_KODU", iMap).getString("BLOKE_DOVIZ_KODU"));


			GMMap telMap = new GMMap();

			telMap.put("CUSTOMER_NO", oMap.getBigDecimal("MUSTERI_NO"));
			telMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", telMap));

			if (!"1".equals(telMap.getString("RESPONSE")) || StringUtils.isEmpty(telMap.getString("PHONE_NUMBER"))) {
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2933)));
			}

			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));

			return oMap;

		}
		catch (Exception e) {
			logger.error("UPT_VALIDATE_CASH_PAYMENT err:", e);
			oMap = BnsprAdcMessageExecuter.callError(e.getMessage());

		}

		return oMap;
	}

	@GraymoundService("UPT_CASH_PAYMENT_VALIDATE_OTP")
	public static GMMap uptCashPaymentValidateOtp(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			logger.info("UPT_CASH_PAYMENT_VALIDATE_OTP: Validate OTP");
			Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
			UptHavaleOdemeTx UptHavaleOdemeTx = (UptHavaleOdemeTx) session.createCriteria(UptHavaleOdemeTx.class)
					.add(Restrictions.eq("txNo", iMap.getBigDecimal("BANKA_ISLEM_NO")))
.add(Restrictions.eq("tuReferans", iMap.getBigDecimal("TU_REFERANS")))
					.setFetchSize(1).list().get(0);
			if (UptHavaleOdemeTx == null) {
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(5006)).put("P1", iMap.getString("hesapNo")));
			}
			
				String userOid = UPTUtil.getUserOidUsingCustomerNo(UptHavaleOdemeTx.getMusteriNo().toString());

				JGMPasswordField pass = new JGMPasswordField();
				pass.setText(iMap.getString("OTP_PASS"));
				GMServiceExecuter.call("ADC_MAN_USER_OTP_VALIDATE", new GMMap().put("USER_OID", userOid).put("OTP_PASS", new String(pass.getPassword())));
			
			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));

		}
		catch (Exception e) {
			logger.error("UPT_CASH_PAYMENT_VALIDATE_OTP err:" + e);
			oMap = BnsprAdcMessageExecuter.callError(e.getMessage());
		}

		return oMap;
	}

	private static GMMap validateHesap(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("HESAP_NO", StringUtils.trim(iMap.getString("HESAP_NO")));
		iMap.put("IBAN", StringUtils.trim(iMap.getString("IBAN")));
		String hesapIban = null;
		String ibanHesap = null;

		// Case: hesapNo iban parametresi bos gonderilmemelidir.
		if (StringUtils.isEmpty(iMap.getString("HESAP_NO")) && StringUtils.isEmpty(iMap.getString("IBAN"))) {
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(330)).put("P1", "hesapNo"));
		}

		// IBAN kontrol servisi i�in parametre beslemesi yapiyoruz.
		if (!StringUtils.isEmpty(iMap.getString("IBAN"))) {
			oMap.putAll(GMServiceExecuter.call("BNSPR_IBAN_KONTROL_WITH_NO_ERROR", iMap));
			if (!"1".equals(oMap.getString("ibanControl"))) {
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(694)));
			}
			ibanHesap = GMServiceExecuter.call("BNSPR_COMMON_GET_ACCOUNT_WITH_IBAN", iMap).getString("ACCOUNT_NO");
			if (!StringUtils.isEmpty(iMap.getString("HESAP_NO"))) {
				if (!iMap.getString("HESAP_NO").equals(ibanHesap)) {
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2242)));
				}
			}
			else {
				iMap.put("HESAP_NO", ibanHesap);
			}
		}

		if (!StringUtils.isEmpty(iMap.getString("HESAP_NO"))) {
			try {
				hesapIban = GMServiceExecuter.call("BNSPR_COMMON_GET_IBAN", iMap).getString("IBAN");
			}
			catch (Exception e) {
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2133)));
			}
			if (!StringUtils.isEmpty(iMap.getString("IBAN"))) {
				if (!iMap.getString("IBAN").equals(hesapIban)) {
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2242)));
				}
			}
			else {
				iMap.put("IBAN", hesapIban);
			}
		}
		oMap.putAll(iMap);

		// hesap var mi yok mu kontrol et, hesabin olmama durumunda �agirilan servis exception firlatacak.
		GMServiceExecuter.call("BNSPR_COMMON_GET_DEFTER_BAKIYE", iMap);

		// hesap_hareket_kodu

		oMap.putAll(GMServiceExecuter.call("BNSPR_CURRENT_ACCOUNTS_GET_HESAP_HAREKET_KODU", new GMMap().put("hesapNo", iMap.getBigDecimal("HESAP_NO"))));

		if ("3".equals(oMap.getString("HESAP_HAREKET_KODU"))) {
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(5005)).put("P1", iMap.getString("HESAP_NO")));
		}
		else if ("4".equals(oMap.getString("HESAP_HAREKET_KODU"))) {
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(5006)).put("P1", iMap.getString("HESAP_NO")));
		}

		// Hesap Numarasi, Hesap Turu Validasyonu
		oMap.putAll(GMServiceExecuter.call("BNSPR_GET_HESAP_TURU", new GMMap().put("hesapNo", iMap.getBigDecimal("HESAP_NO"))));
		oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));

		return oMap;

	}

	@GraymoundService("UPT_CASH_PAYMENT_CANCEL")
	public static GMMap cashPaymentCancel(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("ISLEM_TURU", "I");
		iMap.put("ISLEM_KODU", ISLEM_KOD_UPT_HAVALE_NAKIT_CEKME);

		// islem onayla iptal dogruladan mi cagirsak buradan mi emin olamadim
		oMap = GMServiceExecuter.call("BNSPR_TRN2118_CANCEL", iMap);

		return oMap;
	}



}
