package tr.com.aktifbank.bnspr.upt.util;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.obss.adc.core.pojo.User;
import tr.com.obss.adc.core.util.ADCCore;
import tr.com.obss.adc.core.util.ADCCoreUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.connection.GMConnection;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.ejb.GMEJBRemoteClient;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class UPTUtil {

	public static final String TRN_TYPE_REQUEST = "REQUEST";
	public static final String TRN_TYPE_CONFIRM = "CONFIRM";
	public static final int CHANNEL_CODE = 7; 
	
	private static String BANKING_SERVICE = "TRUNION";
	private static Logger logger = Logger.getLogger(UPTUtil.class);

	public static GMMap FeedMapCaseOne() { /* 1000001 */

		GMMap xMap = new GMMap();
		xMap.put("PASS_EXECUTION", false);
		xMap.put("PASS_TIME_LIMIT", true);
		xMap.put("PASS_QUANTITY_LIMIT", true);
		xMap.put("PASS_AMOUNT_LIMIT", true);
		xMap.put("PASS_FRAUD_LIMIT", true);
		xMap.put("PASS_CUSTOMER_AMOUNT_LIMIT", true);
		xMap.put("PASS_SERVICE_EXECUTION", false);
		return xMap;
	}

	public static GMMap FeedMapCaseTwo() { /* 0111111 */

		GMMap xMap = new GMMap();
		xMap.put("PASS_EXECUTION", true);
		xMap.put("PASS_TIME_LIMIT", false);
		xMap.put("PASS_QUANTITY_LIMIT", false);
		xMap.put("PASS_AMOUNT_LIMIT", false);
		xMap.put("PASS_FRAUD_LIMIT", false);
		xMap.put("PASS_CUSTOMER_AMOUNT_LIMIT", false);
		xMap.put("PASS_SERVICE_EXECUTION", false);
		return xMap;
	}

	public static GMMap FeedMapCaseThree() { /* 0000001 */

		GMMap xMap = new GMMap();
		xMap.put("PASS_EXECUTION", true);
		xMap.put("PASS_TIME_LIMIT", true);
		xMap.put("PASS_QUANTITY_LIMIT", true);
		xMap.put("PASS_AMOUNT_LIMIT", true);
		xMap.put("PASS_FRAUD_LIMIT", true);
		xMap.put("PASS_CUSTOMER_AMOUNT_LIMIT", true);
		xMap.put("PASS_SERVICE_EXECUTION", false);
		return xMap;
	}

	public static GMMap FeedMapCaseZero() { /* 00000000 */

		GMMap xMap = new GMMap();
		xMap.put("PASS_EXECUTION", true);
		xMap.put("PASS_TIME_LIMIT", true);
		xMap.put("PASS_QUANTITY_LIMIT", true);
		xMap.put("PASS_AMOUNT_LIMIT", true);
		xMap.put("PASS_FRAUD_LIMIT", true);
		xMap.put("PASS_CUSTOMER_AMOUNT_LIMIT", true);
		xMap.put("PASS_SERVICE_EXECUTION", true);
		return xMap;
	}

	public static GMMap FeedMapCase62() { /* 0111110 */

		GMMap xMap = new GMMap();
		xMap.put("PASS_EXECUTION", true);
		xMap.put("PASS_TIME_LIMIT", false);
		xMap.put("PASS_QUANTITY_LIMIT", false);
		xMap.put("PASS_AMOUNT_LIMIT", false);
		xMap.put("PASS_FRAUD_LIMIT", false);
		xMap.put("PASS_CUSTOMER_AMOUNT_LIMIT", false);
		xMap.put("PASS_SERVICE_EXECUTION", true);
		return xMap;
	}

	public static GMMap remoteCall(String serviceName, GMMap iMap) {
		GMConnection connection = null;
		GMMap oMap = new GMMap();
		try {

			connection = GMConnection.getConnection(BANKING_SERVICE);
			oMap.putAll(ADCCoreUtil.remoteCall(connection, serviceName, iMap));

			return oMap;

		} catch (IOException e) {
			logger.error(e);
			throw new com.graymound.util.GMRuntimeException(101,
					GMMessageFactory.getMessage("CONNFAIL", new GMMap()));
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static GMMap remoteCallTx(String serviceName, GMMap iMap) {
		GMMap oMap = new GMMap();

		oMap = GMEJBRemoteClient.getInstance().executeService(BANKING_SERVICE, serviceName, iMap);
		return oMap;

	}

	public static String getUserOid(String customerIDNo) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		try {
			oMap = UPTUtil.remoteCall(
					"BNSPR_KASA_KIMLIK_GET_MUSTERI_NO_WITH_TCKN",
					new GMMap().put("TCKN", customerIDNo));

			User user = (User) session
					.createCriteria(User.class)
					.add(Restrictions.eq("customerId",
							oMap.getBigDecimal(("MUSTERI_NO"))))
					.setFetchSize(1).list().get(0);
			//oMap.putAll( CLKSUtil.call("CLKS_GET_USER_OID", oMap)  )  ;
			return user.getOid();
		} catch (Exception ex) {
			return null;
		}

	}

	public static GMMap getUserOid(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		String customerIDNo = null;
		if (iMap.getString("TCKN") != null && "".equals(iMap.getString("TCKN")) == false) {
			oMap = UPTUtil.remoteCall(
					"BNSPR_KASA_KIMLIK_GET_MUSTERI_NO_WITH_TCKN",
					new GMMap().put("TCKN", iMap.getString("TCKN")));
					customerIDNo = iMap.getString("TCKN");
		} else if (iMap.getString("YKN") != null && "".equals(iMap.getString("YKN")) == false) {
			oMap = UPTUtil.remoteCall(
					"BNSPR_KASA_KIMLIK_GET_MUSTERI_NO_WITH_YKN",
					new GMMap().put("YKN", iMap.getString("YKN")));
					customerIDNo = iMap.getString("YKN");
		} else if (iMap.getString("VKN") != null && "".equals(iMap.getString("VKN")) == false) {
			oMap = UPTUtil.remoteCall(
					"BNSPR_KASA_KIMLIK_GET_MUSTERI_NO_WITH_VKN",
					new GMMap().put("VKN", iMap.getString("VKN")));
					customerIDNo = iMap.getString("VKN");
		}
		
		if ("0".equals(oMap.getString("MUSTERI_NO", "0"))) {
			return new GMMap().put("CUSTOMEROID", customerIDNo).put(
					"CLKS_USER_TYPE", "0");
		}

		GMMap typeMap = UPTUtil.remoteCall(
				"BNSPR_TRN1040_GET_MUSTERI_TUR_KONTAKT", oMap);
		if ("M".equals(typeMap.getString("M_OR_K"))) {
			typeMap.put("CLKS_USER_TYPE", "2");
		} else {
			typeMap.put("CLKS_USER_TYPE", "1");
		}
		List<?> userList = session
				.createCriteria(User.class)
				.add(Restrictions.eq("customerId",
						oMap.getBigDecimal(("MUSTERI_NO")))).setFetchSize(1)
				.list();
		if (userList.isEmpty()) {
			return new GMMap().put("CUSTOMEROID", customerIDNo).put(
					"CLKS_USER_TYPE", typeMap.getString("CLKS_USER_TYPE"));
		} else {
			return new GMMap().put("CUSTOMEROID",
					((User) userList.get(0)).getOid()).put("CLKS_USER_TYPE",
					typeMap.getString("CLKS_USER_TYPE"));
		}

	}

	public static void putUserOidInSessionForCustomerLimit(GMMap iMap) {
		ADCSession.put(
				"USER_OID",
				getUserOidUsingCustomerNo(iMap.getString("MUSTERI_NO"),
						iMap.getString("TCKN_MI")));
	}

	private static String getUserOidUsingCustomerNo(String customerNo,
			String tckn_mi) { //MUSTER� �SE CUSTOMER_NO DEGILSE TCKN ile gelicek

		if (customerNo == null || customerNo.length() == 0)
			return "*";
		try {

			GMMap oMap = new GMMap();

			oMap.put("MUSTERI_NO", customerNo);
			Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

			if ("H".equals(tckn_mi)) {
				//if ("H".compareTo(tckn_mi) == 0) {
				User user = (User) session
						.createCriteria(User.class)
						.add(Restrictions.eq("customerId",
								oMap.getBigDecimal(("MUSTERI_NO"))))
						.setFetchSize(1).list().get(0);
				return user.getOid();
			} else {
				return customerNo;
			}

		} catch (Exception e) {
			// Log error but return default user
			logger.error("GET_USER_OID err:", e);
			return "*";
		}
	}

	public static String getUserOidUsingCustomerNo(String customerNo) {
		return getUserOidUsingCustomerNo(customerNo, "H");
	}
	public static GMMap multiServiceCall(GMMap iMap, GMMap oMap) {
		GMConnection connection = null;
		try {
			connection = GMConnection.getConnection(BANKING_SERVICE);
			oMap.putAll(GMServiceExecuter.call("INTERNET_MULTI_SERVICE_EXECUTER", iMap));
			return oMap;

		} catch (IOException e) {
			throw new com.graymound.util.GMRuntimeException(101,
					GMMessageFactory.getMessage("CONNFAIL", new GMMap()), true);
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (IOException e) {
					logger.warn(e.getStackTrace());
				}
			}
		}
	}

}
