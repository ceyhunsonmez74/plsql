
package tr.com.aktifbank.bnspr.upt.services.cashtransfer;

import static tr.com.aktifbank.bnspr.upt.util.UptConstants.ISLEM_KOD_UPT_HAVALE_NAKIT_YATIRMA;
import static tr.com.aktifbank.bnspr.upt.util.UptConstants.ISLEM_SEKLI_UPT_YATAN;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.clks.util.BnsprAdcMessageExecuter;
import tr.com.aktifbank.bnspr.clks.util.BnsprAdcUtil;
import tr.com.aktifbank.bnspr.upt.util.UPTUtil;
import tr.com.aktifbank.bnspr.upt.util.UptConstants;
import tr.com.aktifbank.bnspr.upt.util.UptConstants.KasaKimlikTipi;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCParameters;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CashTransferServices {

	private static Logger logger = Logger.getLogger(CashTransferServices.class);

	

	@GraymoundService("UPT_VALIDATE_CASH_TRANSFER")
	public static GMMap validateCashTransfer(GMMap iMap) {

		GMMap oMap = new GMMap();


		try {
			oMap.putAll(validateHesap(iMap));
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", oMap));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN2003_GET_TYPE", new GMMap().put("CUSTOMER_NO", oMap.getBigDecimal("MUSTERI_NO"))));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN4300_GET_MUSTERI_ADRES", new GMMap().put("MUSTERI_NO", oMap.getBigDecimal("MUSTERI_NO"))));
			oMap.putAll(GMServiceExecuter.call("UPT_GET_MUSTERI_BILGI", new GMMap().put("MUSTERI_NO", oMap.getBigDecimal("MUSTERI_NO"))));
			oMap.put("HESAP_MUSTERI_BILGILERI", 0, "ADRES", oMap.getString("TAM_ADRES"));
			oMap.put("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_NO", oMap.getBigDecimal("MUSTERI_NO"));
			oMap.put("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_TIPI", oMap.getString("CUSTOMER_TYPE"));
			oMap.put("DOVIZ_KODU", GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_DOVIZ_KODU", iMap).getString("BLOKE_DOVIZ_KODU"));
			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));




		}
		catch (Exception e) {
			logger.error("UPT_VALIDATE_CASH_TRANSFER err:", e);
			oMap = BnsprAdcMessageExecuter.callError(e.getMessage());

		}

		return oMap;
	}

	private static GMMap validateHesap(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("HESAP_NO", StringUtils.trim(iMap.getString("HESAP_NO")));
		iMap.put("IBAN", StringUtils.trim(iMap.getString("IBAN")));
		String hesapIban = null ;
		String ibanHesap = null;

		// Case: hesapNo iban parametresi bos gonderilmemelidir.
		if (StringUtils.isEmpty(iMap.getString("HESAP_NO")) && StringUtils.isEmpty(iMap.getString("IBAN"))) {
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(330)).put("P1", "hesapNo"));
			}
			
			// IBAN kontrol servisi i�in parametre beslemesi yapiyoruz.
		if (!StringUtils.isEmpty(iMap.getString("IBAN"))) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_IBAN_KONTROL_WITH_NO_ERROR", iMap));
				if (!"1".equals(oMap.getString("ibanControl"))) {
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(694)));
				}
				ibanHesap = GMServiceExecuter.call("BNSPR_COMMON_GET_ACCOUNT_WITH_IBAN", iMap).getString("ACCOUNT_NO");
				if (!StringUtils.isEmpty(iMap.getString("HESAP_NO"))) {
					if (!iMap.getString("HESAP_NO").equals(ibanHesap)) {
						return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2242)));
					}
				}
			else {
				iMap.put("HESAP_NO", ibanHesap);
			}
		   }


		if (!StringUtils.isEmpty(iMap.getString("HESAP_NO"))) {
			try {
			hesapIban = GMServiceExecuter.call("BNSPR_COMMON_GET_IBAN", iMap).getString("IBAN");
			}
			catch (Exception e) {
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2133)));
			}
			if (!StringUtils.isEmpty(iMap.getString("IBAN"))) {
				if (!iMap.getString("IBAN").equals(hesapIban)) {
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(2242)));
				}
			}
			else {
				iMap.put("IBAN", hesapIban);
			}
		}
		oMap.putAll(iMap);

			// hesap var mi yok mu kontrol et, hesabin olmama durumunda �agirilan servis exception firlatacak.
			GMServiceExecuter.call("BNSPR_COMMON_GET_DEFTER_BAKIYE", iMap);

			// hesap_hareket_kodu

		oMap.putAll(GMServiceExecuter.call("BNSPR_CURRENT_ACCOUNTS_GET_HESAP_HAREKET_KODU", new GMMap().put("hesapNo", iMap.getBigDecimal("HESAP_NO"))));

			if ("3".equals(oMap.getString("HESAP_HAREKET_KODU"))) {
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(5005)).put("P1", iMap.getString("HESAP_NO")));
			}
			else if ("4".equals(oMap.getString("HESAP_HAREKET_KODU"))) {
			return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(5006)).put("P1", iMap.getString("HESAP_NO")));
			}

		// Hesap Numarasi, Hesap Turu Validasyonu
		oMap.putAll(GMServiceExecuter.call("BNSPR_GET_HESAP_TURU", new GMMap().put("hesapNo", iMap.getBigDecimal("HESAP_NO"))));
		oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));

		return oMap;

	}

	@GraymoundService("UPT_CASH_TRANSFER_REQUEST")
	public static GMMap cashTransferRequest(GMMap iMap) {

		GMMap oMap = new GMMap();
		String orgUserOid = null;
		GMMap hesapValidateMap = new GMMap();

		try {
			orgUserOid = (String) ADCSession.get("USER_OID");


			iMap.put("ISLEM_TURU", "T");
			iMap.put("ISLEM_TIPI", iMap.getString("ISLEM"));
			hesapValidateMap.put("HESAP_NO", iMap.get("HESAP_NO"));
			hesapValidateMap.put("IBAN", iMap.get("IBAN"));

			iMap.putAll(validateHesap(hesapValidateMap));
			iMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", iMap));




			// Case: tutar parametresi bos gonderilmemelidir.
			if (iMap.getString("TUTAR") == null || iMap.getString("TUTAR").length() == 0) {
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(330)).put("P1", "tutar"));
			}




			String hesapTckn = GMServiceExecuter.call("BNSPR_COMMON_GET_TCKN", new GMMap().put("MUSTERI_NO", iMap.getString("MUSTERI_NO"))).getString("TCKN");
			String hesapVkn = GMServiceExecuter.call("BNSPR_COMMON_GET_VKN", new GMMap().put("MUSTERI_NO", iMap.getString("MUSTERI_NO"))).getString("VKN");
			String hesapUnvan = GMServiceExecuter.call("BNSPR_COMMON_GET_UNVAN", new GMMap().put("MUSTERI_NO", iMap.getString("MUSTERI_NO"))).getString("UNVAN");
			


			// Case: 3. Sahis NY
			if (KasaKimlikTipi.UCUNCU_SAHIS_NAKIT_YATIRMA.getKod().equals(iMap.getString("KASA_KIMLIK_TIPI"))) {

				// Case: odemeTuru zorunlu alan
				if (iMap.getString("ODEME_TURU") == null || iMap.getString("ODEME_TURU").length() == 0) {
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", new BigDecimal(5004)));
				}

			}

			// Case: Kendi Hesabina NY
			else {

				if (!(iMap.getString("ISLEM_YAPAN_TCKN_VKN").equals(hesapTckn)
						||
 iMap.getString("ISLEM_YAPAN_TCKN_VKN").equals(hesapVkn))){
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1920));
				}
				if (
						
				!BnsprAdcUtil.matchStrings(iMap.getString("ISLEM_YAPAN_BILGI", 0, "UNVAN"), hesapUnvan)) {

					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 2290));
				}
			}



			UPTUtil.putUserOidInSessionForCustomerLimit(new GMMap().put("MUSTERI_NO", iMap.getString("MUSTERI_NO")).put("TCKN_MI", "H"));
			GMMap processMap = new GMMap();
			processMap.putAll(iMap);
			processMap.putAll(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap())); // onceki tx_no al

			GMMap hesapMusteriDetayMap = new GMMap();
			hesapMusteriDetayMap = GMServiceExecuter.call("UPT_GET_HESAP_MUSTERI_DETAY", iMap);

			GMMap o2Map = new GMMap();

			processMap.put("DOVIZ_KOD", hesapMusteriDetayMap.get("DOVIZ_KODU"));

			processMap.put("KARSI_HESAP_NO", hesapMusteriDetayMap.getString("HESAP_NO"));

			o2Map = GMServiceExecuter.call("INTERNET_HAVALE_EFT_MASRAF_HESAPLA", new GMMap().put("TUTAR", iMap.getString("TUTAR")).put("DOVIZ_KOD", hesapMusteriDetayMap.getString("DOVIZ_KODU")).put("MUSTERI_NO", hesapMusteriDetayMap.getString("MUSTERI_NO")).put("KARSI_HESAP_NO", hesapMusteriDetayMap.getString("HESAP_NO")).put("EKRAN_KODU", UptConstants.EKRAN_KOD_UPT_HAVALE_NAKIT_YATIRMA));

			processMap.put("ISLEM_NO", processMap.getString("TRX_NO"));
			processMap.put("ALICI_HESAP_NO", hesapMusteriDetayMap.getString("HESAP_NO"));
			processMap.put("ALICI_MUSTERI_NO", hesapMusteriDetayMap.getString("MUSTERI_NO"));
			// processMap.put("CUSTOMER_ID", hesapMusteriDetayMap.getString("MUSTERI_NO"));
			processMap.put("ALICI_SUBE_KODU", hesapMusteriDetayMap.getString("SUBE_KODU"));
			processMap.put("ALICI_SUBE_ADI", hesapMusteriDetayMap.getString("SUBE_ADI"));

			processMap.put("DOVIZ_KODU", hesapMusteriDetayMap.getString("DOVIZ_KODU"));

			hesapMusteriDetayMap.put("TIP_ISLEM", "NAKIT_YATIRMA");
			hesapMusteriDetayMap.put("PARAMETRE", "UPT_HESABA_" + hesapMusteriDetayMap.getString("DOVIZ_KODU") + "_HAVUZ");

			processMap.put("BORC_HESAP_NO", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", hesapMusteriDetayMap).getString("DEGER"));

			if ("0".equals(processMap.getString("BORC_HESAP_NO"))) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 1530));
			}

			processMap.put("BORC_MUSTERI_NO", (BigDecimal) GMContext.getCurrentContext().getSession().get("INTEGRATION_ID"));
			processMap.put("DOVIZ_KODU", hesapMusteriDetayMap.get("DOVIZ_KODU"));
			processMap.put("MASRAF_TUTARI", o2Map.getBigDecimal("TOPLAM_MASRAF", BigDecimal.ZERO).add(o2Map.getBigDecimal("TOPLAM_BSMV", BigDecimal.ZERO)));
			processMap.put("TUTAR", iMap.getString("TUTAR"));
			processMap.put("AMOUNT", iMap.getString("TUTAR"));
			processMap.put("ISLEM_SEKLI", ISLEM_SEKLI_UPT_YATAN);

			processMap.put("AMOUNT_CODE", processMap.getString("DOVIZ_KODU"));
			processMap.put("TUTAR_CODE", processMap.getString("DOVIZ_KODU"));
			processMap.put("CONTROL_MASK", "0");


			/**
			 * todo :process yapisina gecersek cagirilacak/
			 * sMap.put("PROCESS_CODE", "CLKS-TRN");/*CLKS_TRANSFER_PROCESS
			 * sMap.putAll(UPTUtil.FeedMapCaseTwo());
			 * 
			 * oMap.putAll(GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", sMap));
			 **/

			processMap.put("ISLEM_TARIHI", new Date(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH").getTime()));
			processMap.put("VALOR_TARIHI", new Date(GMServiceExecuter.call("BNSPR_TRN1101_GET_TARIH_AND_KULLANICI", new GMMap()).getDate("BANKA_TARIH").getTime()));
			processMap.putAll(GMServiceExecuter.call("BNSPR_TRN2003_GET_TYPE", new GMMap().put("CUSTOMER_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO"))));
			processMap.putAll(GMServiceExecuter.call("BNSPR_TRN4300_GET_MUSTERI_ADRES", new GMMap().put("MUSTERI_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO"))));
			processMap.putAll(GMServiceExecuter.call("UPT_GET_MUSTERI_BILGI", new GMMap().put("MUSTERI_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO"))));
			processMap.put("HESAP_MUSTERI_BILGILERI", 0, "ADRES", processMap.getString("TAM_ADRES"));
			processMap.put("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_NO", hesapMusteriDetayMap.getBigDecimal("MUSTERI_NO"));
			processMap.put("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_TIPI", processMap.getString("CUSTOMER_TYPE"));

			oMap.put("HESAP_MUSTERI_BILGILERI", processMap.get("HESAP_MUSTERI_BILGILERI"));
			oMap.putAll(GMServiceExecuter.execute("UPT_CASH_TRANSFER_PROCESS", processMap));
			oMap.put("SUBE_KODU", hesapMusteriDetayMap.get("SUBE_KODU"));
			oMap.put("SUBE_ADI", hesapMusteriDetayMap.get("SUBE_ADI"));
			oMap.put("DOVIZ_KODU", hesapMusteriDetayMap.get("DOVIZ_KODU"));

			oMap.put("BANKA_ISLEM_NO", processMap.getString("TRX_NO"));
			oMap.put("ISLEM", iMap.getString("ISLEM"));
			oMap.put("ODENEBILECEK_MAX_TUTAR", processMap.getString("TUTAR"));
			oMap.put("MASRAF_TUTARI", processMap.get("MASRAF_TUTARI"));
			oMap.put("IBAN", iMap.get("IBAN"));
			oMap.put("HESAP_NO", iMap.get("HESAP_NO"));
			oMap.put("BORC_TUTARI", processMap.getString("TUTAR"));


			DateFormat df = new SimpleDateFormat("ddMMyyyy");
			oMap.put("VALOR", df.format(processMap.getDate("VALOR_TARIHI")));
			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));


		}
		catch (Exception e) {
			logger.error("UPT_CASH_TRANSFER_REQUEST err:", e);
			oMap = BnsprAdcMessageExecuter.callError(e.getMessage());
		}
		finally {
			ADCSession.put("USER_OID", orgUserOid);
		}

		return oMap;
	}

	@GraymoundService("UPT_CASH_TRANSFER_CONFIRM")
	public static GMMap cashTransferConfirm(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			String orgUserOid = (String) ADCSession.get("USER_OID");

			
			/* seniz upt islem logu icin log atma incele**/
			iMap.put("ISLEM_NO", iMap.getString("BANKA_ISLEM_NO"));
			GMServiceExecuter.call("UPT_SAVE_TRANSACTION_LOG", iMap.put("LOG_SERVICE", "UPT_CASH_TRANSFER_LOG"));

			iMap.put("ISLEM_TURU", "T");

			iMap.put("MUSTERI_NO", iMap.get("HESAP_MUSTERI_BILGILERI", 0, "MUSTERI_NO"));
			iMap.put("TCKN_MI", "H");
			GMMap i2Map = new GMMap();
			i2Map.put("ISLEM_NO", iMap.getString("BANKA_ISLEM_NO"));
			i2Map.put("ISLEM_TIPI", "NAKIT_YATIRMA");
			iMap.putAll(GMServiceExecuter.call("UPT_GET_INPUT_DATA_FOR_TRANSFER_CONFIRM", i2Map));

			UPTUtil.putUserOidInSessionForCustomerLimit(iMap);
			/* seniz devam
			oMap = TahsilatProxy.transferConfirmproxy(iMap);
			*/

			/*** proxy impl **/

			GMMap sMap = new GMMap();

			GMMap s1Map = new GMMap();
			s1Map.put("ISLEM_NO", iMap.getBigDecimal("BANKA_ISLEM_NO"));
			s1Map.put("TUTAR", iMap.getBigDecimal("TUTAR"));
			s1Map.put("TUTAR_CODE", "");
			s1Map.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
			s1Map.put("ISLEM_YAPAN_AD_SOYAD", iMap.getString("ISLEM_YAPAN_BILGI", 0, "UNVAN"));

			s1Map.put("GONDEREN_VKN_TCKN", iMap.getString("ISLEM_YAPAN_TCKN_VKN"));

			s1Map.put("GONDEREN_TEL_NO", iMap.getString("ISLEM_YAPAN_BILGI", 0, "TEL_NO"));
			s1Map.put("TU_REFERANS", iMap.getString("TU_REFERANS"));
			/* tutar & tutar_code control*/
			GMServiceExecuter.call("BNSPR_TRN2117_ISLEM_BILGISI_GUNCELLE", s1Map);

			s1Map.putAll(new GMMap().put("TRX_NO", iMap.getBigDecimal("ISLEM_NO")));
			s1Map.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_ISLEM_DETAY", s1Map));

			sMap.put("TUTAR", s1Map.getBigDecimal("ESKI_TUTAR")); // ozan�n g�nderdi�i tutar ilk girilen tutara denk olmadi�i i�in bu i�i kendim yapiyorum
			sMap.put("TUTAR_CODE", s1Map.getString("DOVIZ_KOD"));
			sMap.put("ISLEM_NO", iMap.getString("ISLEM_NO"));
			sMap.put("ISLEM_KODU", ISLEM_KOD_UPT_HAVALE_NAKIT_YATIRMA);
			sMap.put("ISLEM", iMap.getString("ISLEM"));
			sMap.put("ISLEM_TURU", "O");
			sMap.put("ACIKLAMA", "Turkish Union");
			sMap.put("KAYNAK_TAHSILAT", ISLEM_KOD_UPT_HAVALE_NAKIT_YATIRMA.equals(s1Map.getString("ISLEM_KOD")) ? "A" : "K");
			
			sMap.put("ISLEM_YAPAN_AD_SOYAD", iMap.get("ISLEM_YAPAN_AD_SOYAD"));

			/* GraymoundService:  process yapisina gecilirse o sekilde cagir hen transfer hem confirm. CLKS_TRANSFER_PROCESS
			sMap.putAll(UPTUtil.FeedMapCaseOne());
			sMap.put("PROCESS_CODE", "CLKS-TRN");
			**/
			sMap.put("CONTROL_MASK", "1");

			oMap.putAll(GMServiceExecuter.execute("UPT_CASH_TRANSFER_PROCESS", sMap));
			oMap.put("BAKIYE", GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", new GMMap().put("HESAP_NO", iMap.getString("HESAP_NO"))));

			oMap.putAll(BnsprAdcMessageExecuter.callSuccess(""));

		}
		catch (Exception e) {
			logger.error("UPT_CASH_TRANSFER_CONFIRM err:", e);
			oMap = BnsprAdcMessageExecuter.callError(e.getMessage());
			iMap.put("ERROR_MESSAGE", e.getMessage());
			iMap.put("MAIL_GONDER", ADCParameters.getString("TU_SORUNLU_MAIL_ATILSINMI"));
			iMap.put("MAIL_LIST", ADCParameters.getString("TU_SORUNLU_MAIL_ADRES_LIST"));

			GMServiceExecuter.call("TU_SORUNLU_ISLEM_MAIL_GONDER", iMap);
		}

		return oMap;
	}

	@GraymoundService("UPT_CASH_TRANSFER_PROCESS")
	public static GMMap cahtransferProcess(GMMap iMap) {

		GMMap oMap = new GMMap();


		// Case: Request
		if ("0".equals(iMap.getString("CONTROL_MASK", "1"))) {

			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN2117_SAVE", iMap));
		}

		// Case: Confirm
		else {
			oMap = GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", iMap);

		}

		return oMap;
	}

	@GraymoundService("UPT_CASH_TRANSFER_CANCEL")
	public static GMMap cashTransferCancel(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("ISLEM_TURU", "I");
		iMap.put("ISLEM_KODU", ISLEM_KOD_UPT_HAVALE_NAKIT_YATIRMA);

		// islem onayla iptal dogruladan mi cagirsak buradan mi emin olamadim
		oMap = GMServiceExecuter.call("BNSPR_TRN2117_CANCEL", iMap);

		return oMap;
	}

	@GraymoundService("UPT_GET_INPUT_DATA_FOR_TRANSFER_CONFIRM")
	public static GMMap getInputDataTransferConfirm(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN2117.GET_ISLEM_BILGI(?,?,?)}"); // PROSEDUR

			int i = 0;

			stmt.setBigDecimal(++i, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(++i, iMap.getString("ISLEM_TIPI"));

			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			// stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(i);
			oMap = DALUtil.rSetMap(rSet);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("UPT_CASH_TRANSFER_LOG")
	public static GMMap cashTransferLog(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN2117.Transfer_Log_At(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			

			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("ACIKLAMA"));
			stmt.setString(i++, iMap.getString("HESAP_NO"));
			stmt.setString(i++, iMap.getString("IBAN"));
			stmt.setString(i++, iMap.getString("ISLEM"));
			stmt.setString(i++, iMap.getString("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setDate(i++, new Date(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TU_REFERANS"));
			
			
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("UPT_GET_MUSTERI_BILGI")
	public static GMMap getMusteriBilgi(GMMap iMap) {

		Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			GMMap oMap = new GMMap();
			try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN2117.get_hesap_musteri_bilgi(?)}");

				stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "HESAP_MUSTERI_BILGILERI"));
			

			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}

			return oMap;
		}

	@GraymoundService("UPT_GET_HESAP_MUSTERI_DETAY")
	public static GMMap getHesapMusteriDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tu.hesap_musteri_detay_bilgi(?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(i++, iMap.getString("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DOVIZ_KOD"));
			stmt.setString(i++, iMap.getString("TCKN"));
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			if (rSet.next()) {
				int j = 1;
				oMap.put("MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put("TC_KIMLIK_NO", rSet.getString(j++));
				oMap.put("UNVAN", rSet.getString(j++));
				oMap.put("DOVIZ_KODU", rSet.getString(j++));
				oMap.put("SUBE_KODU", rSet.getString(j++));
				oMap.put("SUBE_ADI", rSet.getString(j++));
				oMap.put("ADRES", rSet.getString(j++));
				oMap.put("DOGUM_TARIHI", rSet.getDate(j++));
				oMap.put("BABA_ADI", rSet.getString(j++));
				oMap.put("TELEFON", rSet.getString(j++));
				oMap.put("HESAP_NO", rSet.getString(j++));
				oMap.put("IBAN", rSet.getString(j++));
			}
			else {
				GMMap hMap = new GMMap();
				hMap.put("HATA_NO", 201);
				hMap.put("P1", iMap.getBigDecimal("HESAP_NO"));
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", hMap);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
			// throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

}
