package tr.com.aktifbank.bnspr.fom.services.common;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.graymound.util.GMMap;

public class CommonServices {
	private static final Log logger = LogFactory.getLog(CommonServices.class);

	public static String getValueOfParameter(String code, String criteria1, String criteria2) throws Exception {

		GMMap map = new GMMap();
		map.put("KOD", code);
		map.put("KEY1", criteria1);

		if (criteria2 != null)
			map.put("KEY2", criteria2);

		GMMap output = ServiceHelper.callService(map, "BNSPR_COMMON_GET_COMBO_PARAMETERS");
		String result = null;

		for (int i = 0; i < output.getSize("RESULTS"); i++) {
			if (output.getString("RESULTS", i, "VALUE").equals(criteria1)) {
				result = output.getString("RESULTS", i, "NAME");
				break;
			}
		}

		return result;
	}
}
