package tr.com.aktifbank.bnspr.fom.services;

import java.math.BigDecimal;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksislemHesapDetayPr;
import tr.com.aktifbank.bnspr.dao.ClksislemTanimPr;
import tr.com.aktifbank.bnspr.dao.FomEftTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlBankaSubeKodPr;
import tr.com.calikbank.bnspr.dao.GnlBankaSubeKodPrId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import org.apache.commons.lang.StringUtils;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class TransferServices {

	private static final Logger logger = Logger.getLogger(TransferServices.class);
	private static final String KRED = "KRED";
	private static final String KRED_KART = "KRED-KART";
	private static final String HESAP = "H";
	private static final String IBAN = "I";
	
	/**
	 * Description : TBA
	 * 
	 * @param iMap
	 *            GMMap
	 *            {...}
	 * @return GMMap
	 *         {...}
	 */
	@GraymoundService("FOM_VALIDATE_EFT")
	public static GMMap validateEft(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
		} catch (Exception e) {

			logger.error("FOM_VALIDATE_EFT err:" + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * Description : TBA
	 * 
	 * @param iMap
	 *            GMMap
	 *            {...}
	 * @return GMMap
	 *         {...}
	 */
	@GraymoundService("FOM_EXECUTE_EFT")
	public static GMMap executeEft(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			BigDecimal fomHesapNo = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", new GMMap().put("PARAMETRE", "FOM_EFT_HAVALE_GECICI_HESAP")).getBigDecimal("DEGER");
			String gonderenBankaKodu = (String) DALUtil.callNoParameterFunction("{? = call pkg_genel_pr.bankamiz_kodu}", Types.VARCHAR);
			String gonderenSubeKodu = String.format("%05d", GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", new GMMap().put("HESAP_NO", fomHesapNo)).getInt("SUBE_KODU"));
			String gonderenSehirKodu;
			
			// Case: IBAN ile hesaba EFT
			if(KRED.equals(iMap.getString("EFT_TYPE")) && IBAN.equals(iMap.getString("EFT_ACCOUNT_TYPE"))) {
				
				oMap = (GMMap) DALUtil.callOracleProcedure("{call pkg_eft.EFT_IBAN_Banka_Sube_Sehir_Al(?,?,?,?,?,?,?)}", 
					new Object[] {
						BnsprType.STRING, iMap.getString("T_IBAN")
					}, 
					new Object[] {
						BnsprType.STRING, "T_BANK_CODE",
						BnsprType.STRING, "T_BRANCH_CODE",
						BnsprType.STRING, "T_CITY_CODE",
						BnsprType.STRING, "T_BANK_NAME",
						BnsprType.STRING, "T_BRANCH_NAME",
						BnsprType.STRING, "T_CITY_NAME"
					}
				);
			}

			Session session = DAOSession.getSession("BNSPRDal");
			
			// Case: Havale
			if(gonderenBankaKodu.equals(oMap.getString("T_BANK_CODE", iMap.getString("T_BANK_CODE")))) {
	
				GnlBankaSubeKodPrId gnlBankaSubeKodPrId = new GnlBankaSubeKodPrId(gonderenBankaKodu, gonderenSubeKodu);
				GnlBankaSubeKodPr gnlBankaSubeKodPr = (GnlBankaSubeKodPr) session.get(GnlBankaSubeKodPr.class, gnlBankaSubeKodPrId);
				
				gonderenSubeKodu = StringUtils.stripStart(gonderenSubeKodu, "0");
				gonderenSehirKodu = gnlBankaSubeKodPr.getIlKod();
			} 
			
			// Case: EFT
			else {

				gonderenSubeKodu = "90001";
				gonderenSehirKodu = "999";
			}
			
			FomEftTx fomEftTx = new FomEftTx();
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
			
			fomEftTx.setTxNo(trxNo);
			fomEftTx.setMesajKodu(iMap.getString("EFT_TYPE"));
			fomEftTx.setOdemeTuru((iMap.get("PAYMENT_TYPE") == null || iMap.getString("PAYMENT_TYPE").isEmpty()) ? "99" : iMap.getString("PAYMENT_TYPE"));
			fomEftTx.setAlanBankaKodu(oMap.getString("T_BANK_CODE", iMap.getString("T_BANK_CODE")));
			fomEftTx.setAlanSehirKodu(oMap.getString("T_CITY_CODE", iMap.getString("T_CITY_CODE")));
			fomEftTx.setAlanSubeKodu(oMap.getString("T_BRANCH_CODE", iMap.getString("T_BRANCH_CODE")));
			fomEftTx.setAliciAdi(iMap.getString("T_NAME"));
			fomEftTx.setAliciHesapNo(iMap.getString("T_ACCOUNT_NO"));
			fomEftTx.setAliciIban(iMap.getString("T_IBAN"));
			fomEftTx.setAliciKartNo(iMap.getString("T_CARD_NO"));
			fomEftTx.setAliciTelefonNo(iMap.getString("T_PHONE_NO"));
			fomEftTx.setBayiKod(iMap.getString("AGENT_CODE"));
			fomEftTx.setEftTarih(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
			fomEftTx.setFomAciklama(iMap.getString("DESCRIPTION"));
			fomEftTx.setFomHesapNo(fomHesapNo);
			fomEftTx.setFomMusteriNo(GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", new GMMap().put("HESAP_NO", fomEftTx.getFomHesapNo())).getBigDecimal("MUSTERI_NO"));
			fomEftTx.setGonderenBankaKodu(gonderenBankaKodu);
			fomEftTx.setGonderenSehirKodu(gonderenSehirKodu);
			fomEftTx.setGonderenSubeKodu(gonderenSubeKodu);
			fomEftTx.setGonderenAdres(iMap.getString("F_ADDRESS"));
			fomEftTx.setGonderenAnneAdi(iMap.getString("F_MOTHER_NAME"));
			fomEftTx.setGonderenBabaAdi(iMap.getString("F_FATHER_NAME"));
			fomEftTx.setGonderenDogumTarihi(iMap.getDate("F_BIRTH_DATE"));
			fomEftTx.setGonderenDogumYeri(iMap.getString("F_BIRTH_PLACE"));
			fomEftTx.setGonderenTcKimlikNo(iMap.getString("F_NATIONAL_IDENTITY_NUMBER"));
			fomEftTx.setGonderenAdi(iMap.getString("F_NAME"));
			fomEftTx.setGonderenTelefonNo(iMap.getString("F_PHONE_NO"));
			fomEftTx.setGonderenUyruk("TR");
			fomEftTx.setAciklama(iMap.getString("DESCRIPTION")); 
			fomEftTx.setMasraf(BigDecimal.ZERO);
			fomEftTx.setTutar(iMap.getBigDecimal("AMOUNT"));
			fomEftTx.setSanalIban(iMap.getString("VIRTUAL_IBAN"));
			
			session.save(fomEftTx);
			session.flush();
			
			// TRN: EFT/Havale/Virman
			oMap = ((GMMap) DALUtil.callOracleProcedure("{call pkg_fom_eft.ws_fom_gon_eft_onay(?,?,?)}", 
				new Object[] {
					BnsprType.NUMBER, trxNo
				},
				new Object[] {
					BnsprType.NUMBER, "EFT_NO",
					BnsprType.DATE,	"EFT_DATE"
			})).put("TRX_NO", trxNo);
			
		} catch (Exception e) {

			logger.error("FOM_EXECUTE_EFT err:" + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
}
