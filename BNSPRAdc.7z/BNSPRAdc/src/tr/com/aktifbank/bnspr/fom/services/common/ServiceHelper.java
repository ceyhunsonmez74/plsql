package tr.com.aktifbank.bnspr.fom.services.common;

import java.util.Map;

import com.graymound.connection.GMConnection;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ServiceHelper {
	public static GMMap callService(GMMap input, String serviceName) throws Exception {
		return GMServiceExecuter.call(serviceName, input);
	}

	public static GMMap callOldSchoolService(GMMap input, String serviceName) throws Exception {
		Map<?, ?> response = GMServiceExecuter.execute(serviceName, input);
		return convertMapToGMMap(response);
	}

	public static GMMap callServiceWithNewTransaction(GMMap input, String serviceName) throws Exception {
		return convertMapToGMMap(GMServiceExecuter.executeNT(serviceName, input));
	}

	public static void callServiceAsync(GMMap input, String serviceName) throws Exception {
		GMServiceExecuter.executeAsync(serviceName, input);
	}

	public static GMMap callGraymoundServiceWithExternalConnection(String connectionName, String serviceName, GMMap input) throws Exception {
		GMConnection connection = GMConnection.getConnection(connectionName);
		return convertMapToGMMap(connection.serviceCall(serviceName, input));
	}

	public static GMMap convertMapToGMMap(Map<?, ?> map) {
		GMMap output = new GMMap();
		for (Object key : map.keySet()) {
			output.put(key, map.get(key));
		}
		return output;
	}
}
