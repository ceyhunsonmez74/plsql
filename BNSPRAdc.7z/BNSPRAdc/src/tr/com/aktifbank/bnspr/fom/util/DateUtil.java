package tr.com.aktifbank.bnspr.fom.util;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;

public class DateUtil {

	public static String getTodayDate(String pattern) {
		return LocalDate.now().toString(DateTimeFormat.forPattern(pattern));
	}
}
