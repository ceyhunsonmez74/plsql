package tr.com.aktifbank.bnspr.fom.services;

import java.math.BigDecimal;
import java.sql.Types;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.clks.util.ClksConstants;
import tr.com.aktifbank.bnspr.dao.FomMutabakat;
import tr.com.aktifbank.kurumsalibank.util.ProcessLogUtils;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class CoreServices {
	
	private static Logger logger = Logger.getLogger(CoreServices.class);

	/**
	 * Description : TBA
	 * 
	 * @param iMap
	 *            GMMap
	 *            {...}
	 * @return GMMap
	 *         {...}
	 */

	@GraymoundService("FOM_RECONCILIATION")
	public static GMMap insertFomReconciliation(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
				
				FomMutabakat fomMutabakat ;
				String tableName = "TRX_LIST";
				for (int i=0; i<iMap.getSize(tableName); i++) {
					fomMutabakat = (FomMutabakat)session.get(FomMutabakat.class, iMap.getBigDecimal(tableName,i,"TRX_NO"));
					if(fomMutabakat == null) {
						fomMutabakat = new FomMutabakat();
					}
					fomMutabakat.setTxNo(iMap.getBigDecimal(tableName,i,"TRX_NO"));
					fomMutabakat.setIslemTipi(iMap.getString(tableName,i,"TRX_TYPE"));
					fomMutabakat.setTutar(iMap.getBigDecimal(tableName,i,"AMOUNT"));
					fomMutabakat.setDovizKod(iMap.getString(tableName,i,"CURRENCY_CODE"));
					fomMutabakat.setIslemTarihi(iMap.getDate(tableName,i,"TRX_DATE"));
					fomMutabakat.setBayiKod(iMap.getString(tableName,i,"AGENT_CODE"));
					fomMutabakat.setDurumKod(iMap.getString(tableName,i,"STATUS"));
                    
					session.saveOrUpdate(fomMutabakat);
				}
				session.flush();
		}
		catch (Exception e) {
			logger.error("FOM_RECONCILIATION err:" + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * Description : TBA
	 * 
	 * @param iMap
	 *            GMMap
	 *            {...}
	 * @return GMMap
	 *         {...}
	 */
	@GraymoundService("FOM_VALIDATE_CANCEL_TRX")
	public static GMMap validateCancelTrx(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			DALUtil.callOracleProcedure("{call pkg_fom_eft.ws_fom_iptal_sor(?)}", 
				new Object[] {
					BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO")
				}, 
				new Object[] {}
			);
			
		} catch (Exception e) {

			logger.error("FOM_VALIDATE_CANCEL_TRX err:" + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * Description : TBA
	 * 
	 * @param iMap
	 *            GMMap
	 *            {...}
	 * @return GMMap
	 *         {...}
	 */
	@GraymoundService("FOM_CANCEL_TRX")
	public static GMMap cancelTrx(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String[] pList = {"2315", "2030", "2010"};
		
		try {
			
			String trxName = ((BigDecimal) DALUtil.callOracleFunction("{? = call pkg_tx.islem_kod(?)}", BnsprType.NUMBER, BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"))).toString();
			
			// Process'i geri cevirelim
			for (String pKod : pList) {
				if (pKod.equals(trxName)) {
					ProcessLogUtils.createReverseProcessLog(new GMMap().put("ISLEM_NO", iMap.getBigDecimal("TRX_NO")));
					break;
				}
			}
			
			// Iptal
			DALUtil.callOracleProcedure("{call pkg_fom_eft.ws_fom_iptal(?,?)}", 
				new Object[] {
					BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"),
					BnsprType.STRING, iMap.getString("AGENT_CODE")
				}, 
				new Object[] {}
			);
			
		} catch (Exception e) {

			logger.error("FOM_CANCEL_TRX err:" + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * Description : TBA
	 * 
	 * @param iMap
	 *            GMMap
	 *            {...}
	 * @return GMMap
	 *         {...}
	 */
	@GraymoundService("FOM_TRX_STATUS")
	public static GMMap trxStatus(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			oMap.put("STATUS", DALUtil.callOracleFunction("{? = call pkg_fom_eft.ws_fom_isl_drm_sor(?)}", BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO")));
			
		} catch (Exception e) {

			logger.error("FOM_TRX_STATUS err:" + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * Description : TBA
	 * 
	 * @param iMap
	 *            GMMap
	 *            {...}
	 * @return GMMap
	 *         {...}
	 */
	@GraymoundService("FOM_TRX_LIST_STATUS")
	public static GMMap trxListStatus(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			for(int i = 0; i < iMap.getSize("TRX_LIST"); i++) {
			
				oMap.put("STATUS_LIST", i, "TRX_NO", iMap.getBigDecimal("TRX_LIST", i, "TRX_NO"));
				oMap.put("STATUS_LIST", i, "STATUS", DALUtil.callOracleFunction("{? = call pkg_fom_eft.ws_fom_isl_drm_sor(?)}", BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal("TRX_LIST", i, "TRX_NO")));
			}
			
		} catch (Exception e) {

			logger.error("FOM_TRX_LIST_STATUS err:" + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
}
