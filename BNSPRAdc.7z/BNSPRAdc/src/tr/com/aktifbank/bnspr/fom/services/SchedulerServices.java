package tr.com.aktifbank.bnspr.fom.services;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FomEftTx;
import tr.com.aktifbank.bnspr.fom.services.common.CommonServices;
import tr.com.aktifbank.bnspr.fom.util.DateUtil;
import tr.com.aktifbank.integration.iksir.IksirClient;
import tr.com.aktifbank.integration.iksir.ServiceMessage;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.iksir.LoginResponse;
import tr.com.iksir.TransferRefundNotificationResponse;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class SchedulerServices {
	private static final Log logger = LogFactory.getLog(SchedulerServices.class);

	private final static String RESPONSE_FAIL = "0";
	private final static String FOM_REFUND_NOTIFICATION_AUTO_PARAM = "FOM_REFUND_NOTIFICATION_AUTO_PARAM";

	@GraymoundService("BNSPR_FOM_EFT_GET_RETURN_CONTROL")
	public static GMMap getFomEftReurnControl(GMMap iMap) {

		GMMap oMap = new GMMap();

		String procStr = "{ call PKG_FOM_EFT.getFomEftIadeKontrol(?)}";

		int i = 0;
		Object[] inputValues = new Object[0];
		Object[] outputValues = new Object[2];

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			i = 0;

			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "RC_RETURN_LIST";

			GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			oMap.putAll(resultMap);

			String tableName = "RC_RETURN_LIST";
			String yimDurumGuncelleList = "YIM_DURUM_GUNCELLE_LIST";

			for (int k = 0; k < oMap.getSize(tableName); k++) {
				try {
					GMMap yimMap = GMServiceExecuter.call("BNSPR_YIM_DURUM_GUNCELLE", new GMMap()

					.put("F_ASYNC", resultMap.getString(tableName, k, "F_ASYNC")).put("KRD_BASVURU_NO", resultMap.getBigDecimal(tableName, k, "KRD_BASVURU_NO")).put("DURUM_KODU", resultMap.getString(tableName, k, "DURUM_KODU")).put("ACIKLAMA_ID", resultMap.getBigDecimal(tableName, k, "ACIKLAMA_ID")).put("ACIKLAMA", resultMap.getString(tableName, k, "ACIKLAMA")));

					oMap.put(yimDurumGuncelleList, k, "RESPONSE", yimMap.getBigDecimal("RESPONSE"));
					oMap.put(yimDurumGuncelleList, k, "RESPONSE_DATA", yimMap.getString("RESPONSE_DATA"));
					oMap.put(yimDurumGuncelleList, k, "TX_NO", resultMap.getBigDecimal(tableName, k, "KRD_BASVURU_NO"));

				}
				catch (Exception e) {
					e.getMessage();
					e.printStackTrace();
					oMap.put(yimDurumGuncelleList, k, "RESPONSE", RESPONSE_FAIL);
					oMap.put(yimDurumGuncelleList, k, "RESPONSE_DATA", e.getMessage());
					oMap.put(yimDurumGuncelleList, k, "TX_NO", resultMap.getBigDecimal(tableName, k, "KRD_BASVURU_NO"));
				}
			}

			for (int k = 0; k < oMap.getSize(tableName); k++) {

				if ("0".equals(oMap.getString(yimDurumGuncelleList, k, "RESPONSE"))) {

					FomEftTx fomEftTx = (FomEftTx) session.get(FomEftTx.class, oMap.getBigDecimal(yimDurumGuncelleList, k, "TX_NO"));
					if (fomEftTx != null) {
						fomEftTx.setFomBildirimDurum("F");
						fomEftTx.setFomBildirimAciklama(oMap.getString(yimDurumGuncelleList, k, "RESPONSE_DATA"));
						session.saveOrUpdate(fomEftTx);
					}
				}
				session.flush();
			}
		}
		catch (Exception e) {
		}

		return oMap;

	}

	@GraymoundService("BNSPR_FOM_REFUND_NOTIFICATION_AUTOMATION")
	public static GMMap bnsprFomRefundNotificationAutomation(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			String serviceUrl = CommonServices.getValueOfParameter(FOM_REFUND_NOTIFICATION_AUTO_PARAM, "URL", null);
			String iksirChannel = CommonServices.getValueOfParameter(FOM_REFUND_NOTIFICATION_AUTO_PARAM, "CHANNEL", null);
			String dealerCode = CommonServices.getValueOfParameter(FOM_REFUND_NOTIFICATION_AUTO_PARAM, "DEALER_CODE", null);
			String password = CommonServices.getValueOfParameter(FOM_REFUND_NOTIFICATION_AUTO_PARAM, "PASSWORD", null);
			String userName = CommonServices.getValueOfParameter(FOM_REFUND_NOTIFICATION_AUTO_PARAM, "USERNAME", null);

			ServiceMessage serviceMessageLogin = new ServiceMessage();
			LoginResponse loginResponse = IksirClient.login(serviceUrl, serviceMessageLogin, iksirChannel, dealerCode, userName, password);

			String responseCode = loginResponse.getResult().getRESPONSE_CODE();

			if ("2".equals(responseCode)) {
				String sessionId = loginResponse.getResult().getSessionId();
				String clientTrxIdReserved = loginResponse.getResult().getCORE_TRX_ID_RESERVED();

				String date = DateUtil.getTodayDate("dd/MM/YYYY");
				StringBuilder queryBuilder = new StringBuilder();

				String tableName = "BNSPR.FOM_EFT_TX";
				queryBuilder.append(" select e.tx_no AS REF_NO ");
				queryBuilder.append(" from BNSPR.FOM_EFT_TX tu ");
				queryBuilder.append(" inner join bnspr.eft_eft_tx e on e.tx_no = tu.tx_no ");
				queryBuilder.append(" inner join bnspr.muh_islem i on i.numara = tu.tx_no ");
				queryBuilder.append(" inner join bnspr.eft_iade_gelen g on g.tx_no = e.tx_no ");
				queryBuilder.append(" where i.islem_kod IN (2315,2336) ");
				queryBuilder.append(" and e.durum in ('RELEASE', 'TCMB') ");
				queryBuilder.append(String.format(" and g.iade_eft_tarih ='%s'  ", date));

				GMMap resultMap = DALUtil.getResults(queryBuilder.toString(), tableName);

				for (int i = 0; i < resultMap.getSize(tableName); i++) {
					String referenceNo = resultMap.getString(tableName, i, "REF_NO");
					int statusCode = 7; // 7:IADE 8:IPTAL
					boolean refundExpense = false; //true: masraf iade edilir. false:masraf iade edllmez.
					String trx_source = "AKTIFBANK";

					ServiceMessage serviceMessage = new ServiceMessage();
					TransferRefundNotificationResponse transferRefundNotificationResponse = IksirClient.transferRefundNotificationResponse(serviceUrl, serviceMessage, sessionId, iksirChannel, dealerCode, sessionId, clientTrxIdReserved, referenceNo, statusCode, refundExpense, trx_source);
					if (transferRefundNotificationResponse == null || transferRefundNotificationResponse.getResult() == null)
						logger.error("An exception occured while BNSPR_FOM_REFUND_NOTIFICATION_AUTOMATION transferCancelResponse null ");
					else if (!"2".equals(transferRefundNotificationResponse.getResult().getRESPONSE_CODE())) {
						logger.error("An exception occured while BNSPR_FOM_REFUND_NOTIFICATION_AUTOMATION transferCancelResponse  : " + transferRefundNotificationResponse.getResult().getRESPONSE_CODE() + " - " + transferRefundNotificationResponse.getResult().getRESPONSE_DATA());
						logger.error("referenceNo  : " + referenceNo);
					}
					else {
						logger.error("succesfull referenceNo  : " + referenceNo);
					}
				}
			}
			else {
				logger.error("An exception occured while BNSPR_FOM_REFUND_NOTIFICATION_AUTOMATION login responseCode : " + responseCode);
			}
		}
		catch (Exception e) {
			logger.error("An exception occured while BNSPR_FOM_REFUND_NOTIFICATION_AUTOMATION ");
			logger.error(System.currentTimeMillis(), e);
		}
		return oMap;
	}
}
