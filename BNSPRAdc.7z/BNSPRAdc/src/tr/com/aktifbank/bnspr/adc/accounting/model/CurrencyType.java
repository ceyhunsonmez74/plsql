package tr.com.aktifbank.bnspr.adc.accounting.model;

public enum CurrencyType {
	TRY, USD, EUR;

	public static CurrencyType getEnum(String code) {
		for(CurrencyType v : values())
			if(v.toString().equalsIgnoreCase(code)) return v;
		throw new IllegalArgumentException();
	}
}
