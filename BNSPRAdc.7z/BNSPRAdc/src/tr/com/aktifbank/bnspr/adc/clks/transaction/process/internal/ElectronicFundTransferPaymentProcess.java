package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ElectronicFundTransferPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class ElectronicFundTransferPaymentProcess extends TransactionBaseProcess<ElectronicFundTransferPayment> implements
	TransactionProcess<ElectronicFundTransferPayment> {
	
	private static Logger logger = Logger.getLogger(ElectronicFundTransferPaymentProcess.class);

	public ElectronicFundTransferPaymentProcess(TransactionDao<ElectronicFundTransferPayment> dao) {
		super(dao);
	}

	@Override
	public void request(ElectronicFundTransferPayment transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(ElectronicFundTransferPayment transaction) {
		super.confirm(transaction);
	}
}
