package tr.com.aktifbank.bnspr.adc.clks.transaction.process;

import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transaction;

public interface TransactionProcess<T extends Transaction> {
	
	/**
	 * 
	 * @param transaction
	 */
	public void request(T transaction);
	
	/**
	 * 
	 * @param transaction
	 */
	public void confirm(T transaction);
	
}
