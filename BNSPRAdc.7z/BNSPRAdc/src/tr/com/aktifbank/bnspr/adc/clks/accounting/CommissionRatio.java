package tr.com.aktifbank.bnspr.adc.clks.accounting;

import java.math.BigDecimal;
import java.math.RoundingMode;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.accounting.model.Record;

public class CommissionRatio implements CommissionStrategy {

	/**
	 * Komisyon orani
	 */
	private float commissionRatio;
	
	/**
	 * Komisyon para birimi
	 */
	private CurrencyType commissionCurrency;
	
	/**
	 * Kur
	 */
	private float rate;
	
	
	public CommissionRatio(float commissionRatio, CurrencyType commissionCurrency, float rate) {
		this.commissionCurrency = commissionCurrency;
		this.commissionRatio = commissionRatio;
		this.rate = rate;
	}

	@Override
	public Record calculate(Record transactionRecord) {
		
		BigDecimal commissionAmount = transactionRecord.getAmount().multiply(BigDecimal.valueOf(commissionRatio));
		
		if(commissionCurrency != transactionRecord.getCurrency()) {
			commissionAmount = commissionAmount.multiply(BigDecimal.valueOf(rate));
		}
		
		commissionAmount = commissionAmount.setScale(2, RoundingMode.HALF_UP);
		
		return new Record(commissionAmount, commissionCurrency);
	}
}
