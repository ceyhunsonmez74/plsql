package tr.com.aktifbank.bnspr.adc.clks.core.api;

import java.math.BigDecimal;
import java.util.Map;

public interface CoreApplicationApi {
	
	/**
	 * {@code BANKA} kanalina izinli pazarlama kaydi atar.
	 *
	 * @param customerNo
	 * @param nationalIdentityNumber
	 */
	public void updateCustomerMarketingPermission(BigDecimal customerNo, String nationalIdentityNumber);
	
	/**
	 * {@code nationalIdentityNumber} icin CRS raporlama bilgisini doner.
	 * 
	 * @param nationalIdentityNumber	TC Kimlik numarasi
	 * @return							Eger CRS kaydi alinmamais ise {@code "Y"}, CRS kaydi farkli ulke vergi 
	 * 									m�kellefiyeti var ise {@code "E"}, CRS kaydi farkli ulke veri mukellefiyeti yok 
	 * 									ise {@code "H"} doner.
	 *  
	 */
	public String crsInfo(String nationalIdentityNumber);
	
	/**
	 * {@code nationalIdentityNumber} icin CRS raporlama kaydini saklar.
	 * 
	 * @param nationalIdentityNumber	TC Kimlik numarasi
	 * @param isCrsReportable			{@code true} ise CRS kapsaminda raporlanir, {@code false} ise raporlanmaz.
	 */
	public void updateCrsInfo(String nationalIdentityNumber, boolean isCrsReportable);
	
	/**
	 * Text parametre degeri doner
	 * 
	 * @param code	Parametre kodu
	 * @return
	 */
	public String getParameter(String code);
	
	/**
	 * 
	 * @param messageNumber
	 * @param parameters
	 */
	public String message(int messageNumber, Map<String, String> parameters);
	
	/**
	 * 
	 * @param messageNumber
	 * @param parameters
	 */
	public String message(int messageNumber, String ... parameters);
	
	/**
	 * 
	 * @param messageNumber
	 * @param parameters
	 */
	public void error(int messageNumber, Map<String, String> parameters);
	
	/**
	 * 
	 * @param messageNumber
	 * @param parameters
	 */
	public void error(int messageNumber, String ... parameters);
	
	/**
	 * {@code msisdn} degerine {@code content} {@code null} degil ise {@code content} degeri ile aksi durumda 
	 * {@code messageNumber} karsilik gelen icerik ile sms talebi gecer.
	 * 
	 * @param trxNo
	 * @param customerNo
	 * @param msisdn
	 * @param content
	 * @param messageNumber
	 */
	public void sendText(BigDecimal trxNo, BigDecimal customerNo, String msisdn, String content,
		int messageNumber);
	
	/**
	 * {@code areaCode} ve {@code phoneNumber} degerleri {@code nationalIdentityNumber} degeri farkli olan bir musteri 
	 * uzerinde bulunuyor ise {@code true} aksi durumda {@code false} doner. 
	 * 
	 * @param nationalIdentityNumber
	 * @param areaCode
	 * @param phoneNumber
	 */
	public boolean isMobilePhoneExistsOnAnotherCustomer(String nationalIdentityNumber, String areaCode,
		String phoneNumber);
	
	/**
	 * Mail gonderimi gerceklestirir.
	 * 
	 * @param from		Mail gonderen adres
	 * @param to		Mail alan adres
	 * @param subject	Mail konusu
	 * @param body		Mail icerigi
	 * @param isHtml	HTML icerik mi?
	 * @param trxNo		Iliskili islem numarasi
	 */
	public void sendMail(String from, String to, String subject, String body, boolean isHtml, BigDecimal trxNo);
	
	/**
	 * Event tetikleme islemi yapar.
	 * 
	 * @param serviceName	Event tetikleme yapacak servis adi
	 * @param paremeters	Event icin gerekli parametreler
	 * @param async			Asenkron cagri
	 */
	public void eventCall(String serviceName, Map<?,?> paremeters, boolean async);

	/**
	 * 
	 * @param customerNo
	 * @param productCode
	 */
	public void setGroupPersonalDatePermission(BigDecimal customerNo, String productCode);
}
