package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ElectronicFundTransfer;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class ElectronicFundTransferProcess extends TransactionBaseProcess<ElectronicFundTransfer> implements
	TransactionProcess<ElectronicFundTransfer> {
	
	private static Logger logger = Logger.getLogger(ElectronicFundTransferProcess.class);

	public ElectronicFundTransferProcess(TransactionDao<ElectronicFundTransfer> dao) {
		super(dao);
	}

	@Override
	public void request(ElectronicFundTransfer transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(ElectronicFundTransfer transaction) {
		super.confirm(transaction);
	}
}
