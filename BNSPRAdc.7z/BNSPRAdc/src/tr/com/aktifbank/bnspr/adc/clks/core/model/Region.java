package tr.com.aktifbank.bnspr.adc.clks.core.model;

import java.io.Serializable;

public class Region implements Serializable {

	private static final long serialVersionUID = 2068746010640652852L;

	/**
	 * Basmudurluk kodu
	 */
	private String code;
	
	/**
	 * Basmudurluk uzun kodu
	 */
	private String longCode;
	
	/**
	 * Basmudurluk aciklama
	 */
	private String description;
	
	
	public Region(String code, String longCode) {
		this.code = code;
		this.longCode = longCode;
	}

	/**
	 * @return {@link #code}
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code {@link #code}
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return {@link #longCode}
	 */
	public String getLongCode() {
		return longCode;
	}

	/**
	 * @param longCode {@link #longCode}
	 */
	public void setLongCode(String longCode) {
		this.longCode = longCode;
	}

	/**
	 * @return {@link #description}
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description {@link #description}
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
}
