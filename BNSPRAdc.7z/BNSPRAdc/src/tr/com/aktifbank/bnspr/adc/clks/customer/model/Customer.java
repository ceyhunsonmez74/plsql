package tr.com.aktifbank.bnspr.adc.clks.customer.model;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * Musteri sinifi
 */
public abstract class Customer implements Serializable {

	private static final long serialVersionUID = -1773604909529740903L;
	
	/**
	 * Musteri Turu
	 * <li>{@link #CORPORATE}</li>
	 * <li>{@link #PERSONAL}</li>
	 */
	public enum CustomerType {
		
		/**
		 * Kurumsal (Tuzel)
		 */
		CORPORATE("T"),
		
		/**
		 * Bireysel (Gercek)
		 */
		PERSONAL("G");
		
		private String code;
		
		private CustomerType(String code) {
			this.code = code;
		}
		
		@Override
		public String toString() {
			return code;
		}
	}
	
	/**
	 * Musteri numarasi
	 */
	private BigDecimal customerNo;
	
	/**
	 * Museri Turu
	 */
	private CustomerType type;
	
	public Customer(BigDecimal customerNo) {
		this.customerNo = customerNo;
	}

	/**
	 * @return {@link #customerNo}
	 */
	public BigDecimal getCustomerNo() {
		return customerNo;
	}

	/**
	 * @param customerNo - {@link #customerNo}
	 */
	public void setCustomerNo(BigDecimal customerNo) {
		this.customerNo = customerNo;
	}

	/**
	 * @return {@link #type}
	 */
	public CustomerType getType() {
		return type;
	}

	/**
	 * @param type - {@link #type}
	 */
	public void setType(CustomerType type) {
		this.type = type;
	}
}
