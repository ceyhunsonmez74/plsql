package tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CampaignDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Campaign;
import tr.com.calikbank.bnspr.dao.BirKampanya;

import com.graymound.server.dao.DAOSession;

public class DalCampaignDao implements CampaignDao<Campaign> {

	@Override
	public List<Campaign> all() {
		
		List<Campaign> campaignList = new ArrayList<Campaign>();

		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<BirKampanya> list = session.createCriteria(BirKampanya.class).list();

		for(BirKampanya birKampanya : list) {
			
			Campaign campaign = new Campaign.Builder(birKampanya.getKod(), null)
				.accountBlockCode(birKampanya.getKulBlokeKodu())
				.allIncluded("E".equals(birKampanya.getHerseyDahilEh()) ? true : false)
				.balanceTransfer("E".equals(birKampanya.getBorcTransferiEh()) ? true : false)
				.publicCredit("E".equals(birKampanya.getUcuncuSahisEh()) ? true : false)
				.consolidation("E".equals(birKampanya.getBirlestirmeEh()) ? true : false)
				.visualImpairment("E".equals(birKampanya.getGormeEngelliEh()) ? true : false)
				.consolidationOnChannel("E".equals(birKampanya.getPttIciBirlestirmeEh()) ? true : false)
				.creditType(Campaign.CreditType.getEnum(birKampanya.getKrdTurKod().intValue()))
				.build();
			
			campaignList.add(campaign);
		}
		return campaignList;
	}

	@Override
	public Campaign get(Serializable id) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		BirKampanya birKampanya = (BirKampanya) session.get(BirKampanya.class, id);
		
		Campaign campaign = new Campaign.Builder(birKampanya.getKod(), null)
			.accountBlockCode(birKampanya.getKulBlokeKodu())
			.allIncluded("E".equals(birKampanya.getHerseyDahilEh()) ? true : false)
			.balanceTransfer("E".equals(birKampanya.getBorcTransferiEh()) ? true : false)
			.publicCredit("E".equals(birKampanya.getUcuncuSahisEh()) ? true : false)
			.consolidation("E".equals(birKampanya.getBirlestirmeEh()) ? true : false)
			.visualImpairment("E".equals(birKampanya.getGormeEngelliEh()) ? true : false)
			.consolidationOnChannel("E".equals(birKampanya.getPttIciBirlestirmeEh()) ? true : false)
			.creditType(Campaign.CreditType.getEnum(birKampanya.getKrdTurKod().intValue()))
			.build();
		
		return campaign;
	}

	@Override
	public List<Campaign> filter(Map<String, Object> criteria) {
		
		List<Campaign> campaignList = new ArrayList<Campaign>();

		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<BirKampanya> list = session.createCriteria(BirKampanya.class).add(Restrictions.allEq(criteria)).list();

		for(BirKampanya birKampanya : list) {
			
			Campaign campaign = new Campaign.Builder(birKampanya.getKod(), null)
				.accountBlockCode(birKampanya.getKulBlokeKodu())
				.allIncluded("E".equals(birKampanya.getHerseyDahilEh()) ? true : false)
				.balanceTransfer("E".equals(birKampanya.getBorcTransferiEh()) ? true : false)
				.publicCredit("E".equals(birKampanya.getUcuncuSahisEh()) ? true : false)
				.consolidation("E".equals(birKampanya.getBirlestirmeEh()) ? true : false)
				.visualImpairment("E".equals(birKampanya.getGormeEngelliEh()) ? true : false)
				.consolidationOnChannel("E".equals(birKampanya.getPttIciBirlestirmeEh()) ? true : false)
				.creditType(Campaign.CreditType.getEnum(birKampanya.getKrdTurKod().intValue()))
				.build();
			
			campaignList.add(campaign);
		}
		return campaignList;
	}

	@Override
	public void save(Campaign type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(Campaign type) {
		// TODO Auto-generated method stub
		
	}
}
