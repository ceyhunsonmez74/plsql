package tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.CreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;

public class CreditApplicationBalanceTransferProcess extends CreditApplicationBaseProcessImpl<Application> implements
	CreditApplicationProcess<Application> {

	private static final long serialVersionUID = -5219537664447794655L;

	private static Logger logger = Logger.getLogger(CreditApplicationBalanceTransferProcess.class);

	public CreditApplicationBalanceTransferProcess(CreditApplicationDao<Application> dao, CreditApplicationApi api) {
		super(dao, api);
	}

	@Override
	public Map<?, ?> contractualRequest(Application application, List<Map<?, ?>> documents) {
		
		logger.info(String.format("[ConsumerLoan][BalanceTransfer][ContractualRequest] - %s", application.toString()));
		
		Map<?,?> processMap = super.contractualRequest(application, documents);
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("APPLICATION_NO", application.getApplicationNo());
		parameters.put("NAME", application.getCustomer().toString());
		parameters.put("PHONE", application.getMobilePhone());
		parameters.put("BANK_CODE", application.getBankCode());
		parameters.put("BANK_BRANCH_CODE", application.getBankBranchCode());
		
		this.getApi().eventCall("BNSPR_CLKS_CM_ON_BALANCE_TRANSFER_LOAN_AGREEMENT", parameters, true);
		
		return processMap;
	}
}
