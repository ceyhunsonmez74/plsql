package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CardPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class CardPaymentProcess extends TransactionBaseProcess<CardPayment> implements TransactionProcess<CardPayment> {

	public CardPaymentProcess(TransactionDao<CardPayment> dao) {
		super(dao);
	}

	@Override
	public void request(CardPayment transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(CardPayment transaction) {
		super.confirm(transaction);
	}
}
