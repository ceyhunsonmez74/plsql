package tr.com.aktifbank.bnspr.adc.clks.accounting;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;

/**
 * Komisyon strateji arayuz sinifi
 */
public interface CommissionStrategy {
	
	/**
	 * Komisyon stratejisine uygun komisyon kaydini hesaplar.
	 * 
	 * @param transactionRecord		Muhasebe kaydi
	 * @return	Muhasebe kaydi
	 */
	Record calculate(Record transactionRecord);
}