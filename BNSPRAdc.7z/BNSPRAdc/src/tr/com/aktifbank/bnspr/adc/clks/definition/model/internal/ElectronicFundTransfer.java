package tr.com.aktifbank.bnspr.adc.clks.definition.model.internal;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.TransactionDefinition;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.util.GMMap;

class ElectronicFundTransfer extends BaseTransactionDefinition implements TransactionDefinition {


	public ElectronicFundTransfer(String[] code, String reconciliationType) {
		super(code,reconciliationType);
	}

	@Override
	public Map<?, ?> getReconciliationRecords(Date date, String listName) throws SQLException {

		GMMap oMap = new GMMap(), records = DALUtil.callOracleRefCursorFunction(
			"{? = call pkg_trn2052.get_eft_transfer_records(?,?)}", listName, BnsprType.DATE, date, BnsprType.NUMBER,
			new BigDecimal(this.getReconcilitionCode()));

		for(int i = 0; i < records.getSize(listName); i++) {
			
			GMMap accountingMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "TUTAR")).put(
				"PARA_BIRIMI", records.getString(listName, i, "PARA_BIRIMI")).put("MASRAF", "H");
			
			GMMap commisionMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "KOMISYON_TUTAR")).put(
				"KOMISYON_PARA_BIRIMI", records.getString(listName, i, "KOMISYON_PARA_BIRIMI"));
			
			GMMap clientMap = new GMMap().put("SUBE_ID", records.getString(listName, i, "SUBE_ID")).put(
				"PERSONEL_SICIL", records.getString(listName, i, "PERSONEL_SICIL")).put("PERSONEL_ADI",
				records.getString(listName, i, "PERSONEL_SICIL"));
			
			GMMap detailsMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "ISLEM_TUTARI")).put(
				"PARA_BIRIMI", records.getString(listName, i, "ISLEM_PARA_BIRIMI")).put("MASRAF",
				records.getBigDecimal(listName, i, "ISLEM_MASRAF_TUTARI")).put("UPT_SEKLI",
				records.getString(listName, i, "UPT_SEKLI"));

			oMap.put(listName, i, "ISLEM_TIPI", reconciliationCode);
			oMap.put(listName, i, "ISLEM_NO", records.getBigDecimal(listName, i, "ISLEM_NO"));
			oMap.put(listName, i, "DURUM", records.getString(listName, i, "DURUM"));
			oMap.put(listName, i, "MUHASEBE", new ArrayList<GMMap>(Arrays.asList(accountingMap)));
			oMap.put(listName, i, "KOMISYON", new ArrayList<GMMap>(Arrays.asList(commisionMap)));
			oMap.put(listName, i, "MUSTERI_DETAY", new ArrayList<GMMap>(Arrays.asList(clientMap)));
			oMap.put(listName, i, "UPT_DETAY", new ArrayList<GMMap>(Arrays.asList(detailsMap)));
		}
		
		return oMap;

	}

	@Override
	public Map<?, ?> getRecords(Date date, String listName) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<?, ?> getConfirmData(BigDecimal trxNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String reconciliationCode() {
		// TODO Auto-generated method stub
		return null;
	}

}
