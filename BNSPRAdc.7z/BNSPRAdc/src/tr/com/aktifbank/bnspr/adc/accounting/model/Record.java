package tr.com.aktifbank.bnspr.adc.accounting.model;

import java.math.BigDecimal;

public class Record {

	private final BigDecimal amount;
	private final CurrencyType currency;
	
	public Record(BigDecimal amount, CurrencyType currency) {
		this.amount = amount;
		this.currency = currency;
	}

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * @return the currency
	 */
	public CurrencyType getCurrency() {
		return currency;
	}
}
