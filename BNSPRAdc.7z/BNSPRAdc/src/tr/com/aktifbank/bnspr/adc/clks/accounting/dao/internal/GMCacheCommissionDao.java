package tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal;

import java.util.List;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.CommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;

import com.graymound.cache.GMCache;
import com.graymound.cache.GMCacheFactory;

public class GMCacheCommissionDao implements CommissionDao {
	private static Logger logger = Logger.getLogger(GMCacheCommissionDao.class);

	@SuppressWarnings("unused")
	@Override
	public List<CommissionRecord> getByCommissionCategory(CommissionCategory commissionCategory) {
		
		GMCache cache = GMCacheFactory.getInstance().getCache("CLKS_COMMISSION_TABLE_CACHE");
		
		@SuppressWarnings("unchecked")
		List<CommissionRecord> list = (List<CommissionRecord>) cache.get(commissionCategory.toString());
		
		logger.error("GMCacheCommissionDao - commissionCategory :  " 			+ commissionCategory.toString());						
		logger.error("GMCacheCommissionDao - CommissionRecord list size :  " 	+ list.size());	
		
		int counter = 0;
		for(CommissionRecord comRecord : list)
		{
			logger.error("CommissionRecord list counter :  " 				+ counter);	
			logger.error("CommissionRecord list CommissionAmount :  " 		+ comRecord.getCommissionAmount());	
			logger.error("CommissionRecord list CommissionCurrency :  " 	+ comRecord.getCommissionCurrency());	
			logger.error("CommissionRecord list CommissionType :  " 		+ comRecord.getCommissionType());	
			logger.error("CommissionRecord list Currency :  " 				+ comRecord.getCurrency());	
			logger.error("CommissionRecord list EndingAmount :  " 			+ comRecord.getEndingAmount());	
			logger.error("CommissionRecord list MaxCommissionAmount :  " 	+ comRecord.getMaxCommissionAmount());	
			logger.error("CommissionRecord list MinCommissionAmount :  " 	+ comRecord.getMinCommissionAmount());	
			logger.error("CommissionRecord list StartingAmount :  " 		+ comRecord.getStartingAmount());	
			counter++;
		}

		return list;
	}
}
