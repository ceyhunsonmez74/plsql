package tr.com.aktifbank.bnspr.adc.clks.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.hibernate.Session;






import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.GnlBankaKodPr;
import tr.com.calikbank.bnspr.dao.GnlBankaSubeKodPr;
import tr.com.calikbank.bnspr.dao.GnlBankaSubeKodPrId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CampaignManagementServices {
	
	private static Logger logger = Logger.getLogger(CampaignManagementServices.class);
	
	/**
	 * PTT borc transferi kredisi kullandirim odemesi tamamlandiktan sonra EVAM kampanyasi tetiklenmesi amaci ile
	 * cagirilir.
	 * 
	 * @param iMap {APPLICATION_NO}			Kredi basvuru numarasi
	 * @param iMap {NAME}					Musterinin adi ve soyadi
	 * @param iMap {PHONE}					Musterinin telefon numarasi
	 * @param iMap {BANK_CODE}				Musterinin borcunun bulundugu banka kodu
	 * @param iMap {BANK_BRANCH_CODE}		Musterinin borcunun bulundugu banka subesinin kodu
	 * @return								Event basari ile tetiklendigi durumda {@code RESPONSE=2} key, value ve 
	 * 										{@link BNSPR_CORE_EVENT_CREATE_EVENT} servisinden donen {@code GMMap}'e ait 
	 * 										key, value iceren {@code GMMap}, aksi durumda {@code RESPONSE=0} key, value 
	 * 										iceren {@code GMMap}
	 * @throws GMRuntimeException
	 * 
	 * @see BNSPR_TRN3112_GET_FOR_UPDATE
	 * @see BNSPR_CORE_EVENT_CREATE_EVENT
	 */
	@GraymoundService("BNSPR_CLKS_CM_ON_BALANCE_TRANSFER_LOAN_AGREEMENT")
	public static GMMap onBalanceTransferLoanAgreement(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		BigDecimal eventTypeNo = BigDecimal.valueOf(86);
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirBasvuru application = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("APPLICATION_NO"));
			BirKullandirim lending = (BirKullandirim) session.get(BirKullandirim.class, iMap
				.getBigDecimal("APPLICATION_NO"));
			
			GMMap campaignMap = GMServiceExecuter.call("BNSPR_TRN3112_GET_FOR_UPDATE", new GMMap().put("KAMPANYA_KOD",
				application.getKampKod()));
			
			GnlBankaKodPr bank = (GnlBankaKodPr) session.get(GnlBankaKodPr.class, iMap.getString("BANK_CODE"));

			GnlBankaSubeKodPr bankBranch = (GnlBankaSubeKodPr) session.get(GnlBankaSubeKodPr.class,
				new GnlBankaSubeKodPrId(iMap.getString("BANK_CODE"), iMap.getString("BANK_BRANCH_CODE")));

			GMMap dataMap = new GMMap();
			dataMap.put("SCENARIO_KEY", application.getMusteriNo());
			dataMap.put("TCKN", application.getTcKimlikNo());
			dataMap.put("BASVURU_NO", application.getBasvuruNo());
			dataMap.put("KREDI_TURU", application.getKrediTur());
			dataMap.put("KANAL_KODU", application.getKanalKodu());
			dataMap.put("DURUM_KODU", application.getDurumKodu());
			dataMap.put("KAMPANYA_ADI", campaignMap.getString("ACIKLAMA"));
			dataMap.put("BASVURU_TARIHI", application.getBasvuruTarihi());
			dataMap.put("KULLANDIRIM_GUN_SAYISI", TimeUnit.DAYS.convert(Math.abs(new Date().getTime()
				- lending.getIslemTar().getTime()), TimeUnit.MILLISECONDS));
			dataMap.put("TUTAR", application.getOnayTutar());
			dataMap.put("VADE", application.getVade());
			dataMap.put("AD_SOYAD", iMap.getString("NAME"));
			dataMap.put("CEP_TEL", iMap.getString("PHONE"));
			dataMap.put("MAAS_ALDIGI_BANKA_ADI", bank != null ? bank.getBankaAdi() : iMap.getString("BANK_CODE"));
			dataMap.put("MAAS_ALDIGI_BANKA_SUBE_ADI", bankBranch != null ? bankBranch.getSubeAdi() : iMap
				.getString("BANK_BRANCH_CODE"));
			dataMap.put("ONONAY_TUTAR",
						DALUtil.getResults(
							"select s.borc_transferi_upsell_limit from bnspr.bir_nbsm_sonuc s where s.basvuru_no = "
									+ iMap.getBigDecimal("APPLICATION_NO")
									+ " and s.nbsm_call_tip_kod = 'F' and s.nbsm_call_id = (select max(s2.nbsm_call_id) from bir_nbsm_sonuc s2 where s2.basvuru_no = s.basvuru_no and s2.nbsm_call_tip_kod = s.nbsm_call_tip_kod)",
							"TABLO").getBigDecimal("TABLO", 0,
							"BORC_TRANSFERI_UPSELL_LIMIT"));

			GMMap eventMap = GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", new GMMap().put("SCENARIO_KEY",
				application.getMusteriNo()).put("EVENT_TYPE_NO", eventTypeNo).put("EVENT_REF_NO",
				iMap.getString("APPLICATION_NO")).put("INTEGRATION_TYPE", "S").put("DATA_MAP",
				dataMap));
			oMap.putAll(eventMap);
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CM_ON_BALANCE_TRANSFER_LOAN_AGREEMENT err:", e);
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}
}
