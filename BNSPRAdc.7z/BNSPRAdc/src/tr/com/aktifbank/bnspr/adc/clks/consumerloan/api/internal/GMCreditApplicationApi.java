package tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.internal;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.CreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application.STATUS;
import tr.com.aktifbank.bnspr.adc.clks.core.api.internal.GMCoreApplicationApi;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class GMCreditApplicationApi extends GMCoreApplicationApi implements CreditApplicationApi {
	
	private static final String DYS_PROJECT_TYPE = "CLKSDYS";
	private static final String DYS_PROJECT_STATUS = "1";

	@Override
	public void amountAndTermControl(String campaignCode, BigDecimal amount, int term) {
		GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_AMOUNT_AND_TERM_CONTROL", 
			new GMMap().put("URUN_KAMP_KOD", campaignCode).put("TUTAR", amount).put("VADE", term));
	}

	@Override
	public void ageControl(Date birthDate, BigDecimal campaignChannelCode, int term) {
		GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_AGE_CONTROL", new GMMap().put("DOGUM_TARIHI",
			birthDate).put("KAMP_KNL_KOD", campaignChannelCode).put("VADE", term));
	}

	@Override
	public String rejectApplication(BigDecimal applicationNo, BigDecimal trxNo, String status, String decisionCode) {
		return GMServiceExecuter.call("CLKS_PTT_BASVURU_REDDET", new GMMap().put("ISLEM_NO", trxNo)
			.put("BASVURU_NO", applicationNo).put("ISLEM_KOD", status).put("AKSIYON_KARAR_KOD", decisionCode))
			.getString("MESSAGE");
	}

	@Override
	public void saveBarcode(BigDecimal applicationNo, String barcode) {
		GMServiceExecuter.call("DYS_SAVE_NEW_BARCODE_FOR_CLKS", new GMMap().put("BARCODE", barcode).put("PROJECT_TYPE",
			DYS_PROJECT_TYPE).put("REFERENCE", applicationNo).put("STATUS", DYS_PROJECT_STATUS));
	}

	@Override
	public Map<?, ?> fetchParameters(BigDecimal applicationNo, STATUS status) {
		
		if(status == STATUS.BELGE) {
			return new GMMap(GMServiceExecuter.execute("CLKS_GET_3182_REQUEST_DATA", new GMMap().put("BASVURU_NO",
				applicationNo)));
		}
		
		return null;
	}

	@Override
	public void documentControl(List<Map<?, ?>> documents, Map<?, ?> parameters) {
		
		GMMap requestMap = new GMMap(parameters);
		requestMap.put("BELGELER", documents);
		
		GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", requestMap);
	}

	@Override
	public Map<?, ?> updateDocuments(BigDecimal applicationNo, BigDecimal documentTrxNo, List<Map<?, ?>> documents) {
		
		GMMap responseMap = null;
		
		GMMap requestMap = new GMMap();
		requestMap.put("BASVURU_NO", applicationNo);
		requestMap.put("TBL_BELGE", documents);
		requestMap.put("CALISMA_SEKLI_KOD", "2");
		requestMap.put("TEYIT_GEREKLI", false);
		requestMap.put("BELGE_KONTROL", true);
		requestMap.put("TRX_NO", documentTrxNo);
		
		responseMap = GMServiceExecuter.call("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", requestMap);
		
		if(!responseMap.containsKey("MESSAGE")) {
			responseMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_UPDATE_DURUM", new GMMap().put("BASVURU_NO",
				applicationNo).put("CALISMA_SEKLI_KOD", requestMap.getString("CALISMA_SEKLI_KOD"))));
		}
		
		return responseMap;
	}

	@Override
	public void sendApplicationText(BigDecimal trxNo, String trxCode) {
		GMServiceExecuter.call("BNSPR_BASVURU_SEND_SMS", new GMMap().put("TRX_NO", trxNo).put("ISLEM_KODU", trxCode));
	}

	@Override
	public boolean consolidationValidation(String nationalIdentityNumber, BigDecimal applicationNo) {
		return GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_CONSOLIDATION_VALIDATION", new GMMap().put("TCKN",
			nationalIdentityNumber).put("BASVURU_NO", applicationNo)).getBoolean("IS_VALID");
	}
}