package tr.com.aktifbank.bnspr.adc.clks.transaction.dao;

import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transaction;
import tr.com.aktifbank.bnspr.adc.dao.BaseDao;

public interface TransactionDao<T extends Transaction> extends BaseDao<T> {
	
	/**
	 * Islem durumlari
	 * <li>{@link #NOT_FOUND}</li>
	 * <li>{@link #CREATED}</li>
	 * <li>{@link #PROCESSED}</li>
	 * <li>{@link #CANCELLED}</li>
	 * <li>{@link #OTHER}</li>
	 */
	public enum StateType {
		
		/**
		 * Islem yaratilmadi 
		 */
		NOT_FOUND,
		
		/**
		 * Yaratildi
		 */
		CREATED, 
		
		/**
		 * Islendi, tamamlandi
		 */
		PROCESSED, 
		
		/**
		 * Iptal edildi
		 */
		CANCELLED,
		
		/**
		 * Diger
		 */
		OTHER;
	}
	
	public StateType getState(T transaction);
	public void saveCommission(T transaction);
}
