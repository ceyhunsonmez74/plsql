package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

/**
 * PTT kanali hesap acma sinifi
 */
public class CustomerAcquisition extends Transaction {
	
	private static final long serialVersionUID = -5396005792905322616L;
	
	public CustomerAcquisition(BigDecimal trxNo) {
		super(trxNo, (short) 4800);
		this.setReconciliationType(ReconciliationType.CUSTOMER_ACQUISITION);
		this.setCommissionCategory(CommissionCategory.CUSTOMER_ACQUISITION);
	}
}
