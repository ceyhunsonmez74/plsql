package tr.com.aktifbank.bnspr.adc.clks.accounting.dao;

import java.util.List;

import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;

public interface CommissionDao {
	
	public List<CommissionRecord> getByCommissionCategory(CommissionCategory commissionCategory);
}
