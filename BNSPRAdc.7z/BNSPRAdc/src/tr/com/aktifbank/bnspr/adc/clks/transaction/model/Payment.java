package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

abstract class Payment extends Transaction {

	private static final long serialVersionUID = 2327304230492296076L;
	
	/**
	 * Iade odemesi?
	 */
	private boolean refund = false;

	
	/**
	 * Masraf iade edildi mi?
	 */
	private boolean expenseRefunded = false;
	
	protected Payment(BigDecimal trxNo, short code) {
		super(trxNo, code);
	}

	/**
	 * @return {@link #refund}
	 */
	public boolean isRefund() {
		return refund;
	}

	/**
	 * @param refund {@link #refund}
	 */
	public void setRefund(boolean refund) {
		this.refund = refund;
	}
	
	/**
	 * @return {@link #expenseRefunded}
	 */
	public boolean isExpenseRefunded() {
		return expenseRefunded;
	}

	/**
	 * @param expenseRefunded {@link #expenseRefunded}
	 */
	public void setExpenseRefunded(boolean expenseRefunded) {
		this.expenseRefunded = expenseRefunded;
	}

	@Override
	public void setCurrency(CurrencyType currency) {
		super.setCurrency(currency);
		if(this.reconciliationType() != ReconciliationType.REFUND_PAYMENT_WITH_EXPENSE) {
			this.setCommissionCategory(this.currency() == CurrencyType.TRY ? CommissionCategory.PAYMENT
				: CommissionCategory.FC_PAYMENT);
		}
	}
}
