package tr.com.aktifbank.bnspr.adc.clks.accounting.model;

import java.io.Serializable;
import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;

/**
 * Komisyon Barem Sinifi
 *
 */
public class CommissionRecord implements Serializable {
	
	private static final long serialVersionUID = 5524563741674813404L;
	private final BigDecimal startingAmount;
	private final BigDecimal endingAmount;
	private final CurrencyType currency;
	private final BigDecimal minCommissionAmount;
	private final BigDecimal maxCommissionAmount;
	private final BigDecimal commissionAmount;
	private final CurrencyType commissionCurrency;
	private final CommissionType commissionType;
	
	public static class Builder {
		
		private final BigDecimal startingAmount;
		private final BigDecimal endingAmount;
		private final CurrencyType currency;
		
		private BigDecimal minCommissionAmount = null;
		private BigDecimal maxCommissionAmount = null;
		private BigDecimal commissionAmount = null;
		private CurrencyType commissionCurrency = null;
		private CommissionType commissionType = null;
		
		public Builder(BigDecimal startingAmount, BigDecimal endingAmount, CurrencyType currency) {
		
			this.startingAmount = startingAmount;
			this.endingAmount = endingAmount;
			this.currency = currency;
		}
		
		public Builder minCommissionAmount(BigDecimal minCommissionAmount) {
			this.minCommissionAmount = minCommissionAmount;
			return this;
		}
		
		public Builder maxCommissionAmount(BigDecimal maxCommissionAmount) {
			this.maxCommissionAmount = maxCommissionAmount;
			return this;
		}
		
		public Builder commissionAmount(BigDecimal commissionAmount) {
			this.commissionAmount = commissionAmount;
			return this;
		}
		
		public Builder commissionCurrency(CurrencyType commissionCurrency) {
			this.commissionCurrency = commissionCurrency;
			return this;
		}
		
		public Builder commissionType(CommissionType commissionType) {
			this.commissionType = commissionType;
			return this;
		}
		
		public CommissionRecord build() {
			return new CommissionRecord(this);
		}
	}
	
	private CommissionRecord(Builder builder) {

		this.startingAmount = builder.startingAmount;
		this.endingAmount = builder.endingAmount;
		this.currency = builder.currency;
		this.minCommissionAmount = builder.minCommissionAmount;
		this.maxCommissionAmount = builder.maxCommissionAmount;
		this.commissionAmount = builder.commissionAmount;
		this.commissionCurrency = builder.commissionCurrency;
		this.commissionType = builder.commissionType;
	}

	/**
	 * @return Taban islem tutari
	 */
	public BigDecimal getStartingAmount() {
		return startingAmount;
	}

	/**
	 * @return Tavan islem tutari
	 */
	public BigDecimal getEndingAmount() {
		return endingAmount;
	}
	
	/**
	 * @return Islem para birimi
	 */
	public CurrencyType getCurrency() {
		return currency;
	}
	
	/**
	 * @return Komisyon tutari alt limit
	 */
	public BigDecimal getMinCommissionAmount() {
		return minCommissionAmount;
	}

	/**
	 * @return Komisyon tutari ust limit
	 */
	public BigDecimal getMaxCommissionAmount() {
		return maxCommissionAmount;
	}

	/**
	 * @return Komisyon tutari
	 */
	public BigDecimal getCommissionAmount() {
		return commissionAmount;
	}

	/**
	 * @return Komisyon para birimi
	 */
	public CurrencyType getCommissionCurrency() {
		return commissionCurrency;
	}

	/**
	 * @return Komisyon tipi
	 */
	public CommissionType getCommissionType() {
		return commissionType;
	}
	
	@Override
	public String toString() {
		return String
			.format(
				"%s(commissionType=%s, startingAmount=%s, endingAmount=%s, currency=%s, commissionAmount=%s, commissionCurrency=%s, minCommissionAmount=%s, maxCommissionAmount=%s)",
				CommissionRecord.class.getSimpleName(), this.commissionType == null ? "null" : this.commissionType
					.toString(), this.startingAmount.toString(), this.endingAmount.toString(),
				this.currency.toString(), this.commissionAmount == null ? "null" : this.commissionAmount.toString(),
				this.commissionCurrency == null ? "null" : this.commissionCurrency.toString(),
				this.minCommissionAmount == null ? "null" : this.minCommissionAmount.toString(),
				this.maxCommissionAmount == null ? "null" : this.maxCommissionAmount.toString());
	}
}