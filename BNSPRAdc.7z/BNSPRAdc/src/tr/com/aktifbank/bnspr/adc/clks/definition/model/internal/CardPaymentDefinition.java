package tr.com.aktifbank.bnspr.adc.clks.definition.model.internal;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.Map;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.TransactionDefinition;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

class CardPaymentDefinition extends BaseTransactionDefinition implements TransactionDefinition {

	public CardPaymentDefinition(String reconciliationType) {
		super(new String[]{"2053"}, reconciliationType);
	}
	
	@Override
	public Map<?, ?> getReconciliationRecords(Date date, String listName) throws SQLException {
		
		GMMap records = new GMMap();
		
		if("65".equals(this.getReconcilitionCode())) {
			records = DALUtil.callOracleRefCursorFunction("{? = call pkg_trn2052.get_payment_passocard_records(?)}",
				listName, BnsprType.DATE, date);
		} else if("72".equals(this.getReconcilitionCode())) {
			records = DALUtil.callOracleRefCursorFunction("{? = call pkg_trn2052.get_payment_nkolaycard_records(?)}",
				listName, BnsprType.DATE, date);
		}
		
		return this.formatReconciliationMap(records, listName);
	}

	@Override
	public Map<?, ?> getRecords(Date date, String listName) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<?, ?> getConfirmData(BigDecimal trxNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String reconciliationCode() {
		// TODO Auto-generated method stub
		return null;
	}

}
