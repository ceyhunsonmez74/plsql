package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ForeignCurrencyTransfer;
import tr.com.aktifbank.bnspr.dao.YpHavaleGidenTalimatTx;

import com.graymound.server.dao.DAOSession;

public class DalForeignCurrencyTransferDao extends DalTransactionDao<ForeignCurrencyTransfer> implements
	TransactionDao<ForeignCurrencyTransfer> {

	public DalForeignCurrencyTransferDao() {
		super(ForeignCurrencyTransfer.class);
	}

	@Override
	public ForeignCurrencyTransfer get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		YpHavaleGidenTalimatTx ypHavaleGidenTalimatTx = (YpHavaleGidenTalimatTx) session.get(
			YpHavaleGidenTalimatTx.class, trxNo);
		ForeignCurrencyTransfer transfer = new ForeignCurrencyTransfer(ypHavaleGidenTalimatTx.getTxNo());
		transfer.setToCountryCode(ypHavaleGidenTalimatTx.getAliciUlkeKodu());
		transfer.setAmount(ypHavaleGidenTalimatTx.getTutar());
		transfer.setCurrency(CurrencyType.getEnum(ypHavaleGidenTalimatTx.getDovizCinsi()));
		transfer.setExpenseAmount(ypHavaleGidenTalimatTx.getMasrafTutari());
		transfer.setExpenseCurrency(CurrencyType.getEnum(ypHavaleGidenTalimatTx.getMasrafTahsilDoviz()));
		transfer.setClientTrxNo(ypHavaleGidenTalimatTx.getPttIslemNo());
		transfer.setTransactionExchangeRate(ypHavaleGidenTalimatTx.getPttGuncelKur().floatValue());
		return transfer;
	}

	@Override
	public List<ForeignCurrencyTransfer> filter(Map<String, Object> criteria) {

		List<ForeignCurrencyTransfer> transferList = new ArrayList<ForeignCurrencyTransfer>();

		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<YpHavaleGidenTalimatTx> list = session.createCriteria(YpHavaleGidenTalimatTx.class).add(
			Restrictions.allEq(criteria)).list();

		for(YpHavaleGidenTalimatTx ypHavaleGidenTalimatTx : list) {
			ForeignCurrencyTransfer transfer = new ForeignCurrencyTransfer(ypHavaleGidenTalimatTx.getTxNo());
			transfer.setToCountryCode(ypHavaleGidenTalimatTx.getAliciUlkeKodu());
			transfer.setAmount(ypHavaleGidenTalimatTx.getTutar());
			transfer.setCurrency(CurrencyType.getEnum(ypHavaleGidenTalimatTx.getDovizCinsi()));
			transfer.setExpenseAmount(ypHavaleGidenTalimatTx.getMasrafTutari());
			transfer.setExpenseCurrency(CurrencyType.getEnum(ypHavaleGidenTalimatTx.getMasrafTahsilDoviz()));
			transfer.setClientTrxNo(ypHavaleGidenTalimatTx.getPttIslemNo());
			transfer.setTransactionExchangeRate(ypHavaleGidenTalimatTx.getPttGuncelKur().floatValue());
			transferList.add(transfer);
		}
		return transferList;
	}

	@Override
	public List<ForeignCurrencyTransfer> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(ForeignCurrencyTransfer type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(ForeignCurrencyTransfer type) {
		// TODO Auto-generated method stub
		
	}
}
