package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CardPayment;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;

import com.graymound.server.dao.DAOSession;

public class DalCardPaymentDao extends DalTransactionDao<CardPayment> implements TransactionDao<CardPayment> {

	public DalCardPaymentDao() {
		super(CardPayment.class);
	}

	@Override
	public CardPayment get(Serializable trxNo) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, trxNo);

		String transactionType = clksHavaleGirisTx.getIslem().toString();
		ReconciliationType reconciliationType = null;
		
		if(clksHavaleGirisTx.getIslemSekli().startsWith("PATM") && "63".equals(transactionType)) {
			reconciliationType = ReconciliationType.ATM_CARD_PAYMENT_PASSO;
		} else if(clksHavaleGirisTx.getIslemSekli().startsWith("PATM") && "64".equals(transactionType)) {
			reconciliationType = ReconciliationType.ATM_CARD_PAYMENT_PASSO_WITH_ID;
		} else if(clksHavaleGirisTx.getIslemSekli().startsWith("PATM") && "65".equals(transactionType)) {
			reconciliationType = ReconciliationType.ATM_CARD_PAYMENT_NKOLAY;
		} else if(Arrays.asList("65","66").contains(transactionType)) {
			reconciliationType = ReconciliationType.CARD_PAYMENT_PASSO;
		} else if(Arrays.asList("57","58").contains(transactionType)) {
			reconciliationType = ReconciliationType.CARD_PAYMENT_NKOLAY;
		}
		
		CardPayment cardPayment = new CardPayment(clksHavaleGirisTx.getTxNo(), reconciliationType);
		
		cardPayment.setAmount(clksHavaleGirisTx.getTutar());
		cardPayment.setCurrency(CurrencyType.getEnum(clksHavaleGirisTx.getDovizKodu()));
		cardPayment.setClientTrxNo(clksHavaleGirisTx.getPttIslemNo());
		return cardPayment;
	}

	@Override
	public List<CardPayment> filter(Map<String, Object> criteria) {
		
		List<CardPayment> cardPaymentList = new ArrayList<CardPayment>();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<ClksHavaleGirisTx> list = session.createCriteria(ClksHavaleGirisTx.class).add(Restrictions.allEq(criteria))
			.list();

		for(ClksHavaleGirisTx clksHavaleGirisTx : list) {

			String transactionType = clksHavaleGirisTx.getIslem().toString();
			ReconciliationType reconciliationType = null;
			
			if(clksHavaleGirisTx.getIslemSekli().startsWith("PATM") && "63".equals(transactionType)) {
				reconciliationType = ReconciliationType.ATM_CARD_PAYMENT_PASSO;
			} else if(clksHavaleGirisTx.getIslemSekli().startsWith("PATM") && "64".equals(transactionType)) {
				reconciliationType = ReconciliationType.ATM_CARD_PAYMENT_PASSO_WITH_ID;
			} else if(clksHavaleGirisTx.getIslemSekli().startsWith("PATM") && "65".equals(transactionType)) {
				reconciliationType = ReconciliationType.ATM_CARD_PAYMENT_NKOLAY;
			} else if(Arrays.asList("65","66").contains(transactionType)) {
				reconciliationType = ReconciliationType.CARD_PAYMENT_PASSO;
			} else if(Arrays.asList("57","58").contains(transactionType)) {
				reconciliationType = ReconciliationType.CARD_PAYMENT_NKOLAY;
			}
			
			CardPayment cardPayment = new CardPayment(clksHavaleGirisTx.getTxNo(), reconciliationType);
			cardPayment.setAmount(clksHavaleGirisTx.getTutar());
			cardPayment.setCurrency(CurrencyType.getEnum(clksHavaleGirisTx.getDovizKodu()));
			cardPayment.setClientTrxNo(clksHavaleGirisTx.getPttIslemNo());
			cardPaymentList.add(cardPayment);
		}
		return cardPaymentList;
	}

	@Override
	public List<CardPayment> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(CardPayment type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(CardPayment type) {
		// TODO Auto-generated method stub
		
	}
}
