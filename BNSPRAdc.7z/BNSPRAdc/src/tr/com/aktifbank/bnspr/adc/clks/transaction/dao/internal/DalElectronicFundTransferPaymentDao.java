package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ElectronicFundTransfer;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ElectronicFundTransferPayment;
import tr.com.aktifbank.bnspr.dao.ClksUptOdemeTx;
import tr.com.calikbank.bnspr.dao.ClksPftTx;

import com.graymound.server.dao.DAOSession;

public class DalElectronicFundTransferPaymentDao extends DalTransactionDao<ElectronicFundTransferPayment> implements
	TransactionDao<ElectronicFundTransferPayment> {

	public DalElectronicFundTransferPaymentDao() {
		super(ElectronicFundTransferPayment.class);
	}

	@Override
	public ElectronicFundTransferPayment get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		ClksUptOdemeTx clksUptOdemeTx = (ClksUptOdemeTx) session.get(ClksUptOdemeTx.class, trxNo);
		ElectronicFundTransferPayment payment = new ElectronicFundTransferPayment(clksUptOdemeTx.getTxNo());
		payment.setAmount(clksUptOdemeTx.getTutar());
		payment.setCurrency(CurrencyType.TRY);
		payment.setExpenseAmount(clksUptOdemeTx.getMasrafTutari());
		payment.setExpenseCurrency(CurrencyType.TRY);
		return payment;
	}

	@Override
	public List<ElectronicFundTransferPayment> filter(Map<String, Object> criteria) {

		List<ElectronicFundTransferPayment> paymentList = new ArrayList<ElectronicFundTransferPayment>();

		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<ClksUptOdemeTx> list = session.createCriteria(ClksUptOdemeTx.class).add(
			Restrictions.allEq(criteria)).list();

		for(ClksUptOdemeTx clksUptOdemeTx : list) {
			ElectronicFundTransferPayment payment = new ElectronicFundTransferPayment(clksUptOdemeTx.getTxNo());
			payment.setAmount(clksUptOdemeTx.getTutar());
			payment.setCurrency(CurrencyType.TRY);
			payment.setExpenseAmount(clksUptOdemeTx.getMasrafTutari());
			payment.setExpenseCurrency(CurrencyType.TRY);
			paymentList.add(payment);
		}
		return paymentList;
	}

	@Override
	public List<ElectronicFundTransferPayment> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(ElectronicFundTransferPayment type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(ElectronicFundTransferPayment type) {
		// TODO Auto-generated method stub
		
	}
}
