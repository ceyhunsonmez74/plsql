package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;
import java.util.List;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

public class ForeignCurrencyTransfer extends Transaction {

	private static final long serialVersionUID = 3226592875161563469L;
	private static final String LOCAL_COUNTRY_CODE = "TR";
	private float transactionExchangeRate;
	
	/**
	 * Tahsilat kayitlari
	 */
	private List<Record> accountingRecord;
	
	/**
	 * Alici ulke kodu
	 */
	private String toCountryCode;
	
	/**
	 * Yurt ici/disi
	 */
	private boolean localPayment;

	public ForeignCurrencyTransfer(BigDecimal trxNo) {
		super(trxNo, (short) 2850);
		this.setCommissionCategory(CommissionCategory.FOREIGN_CURRENCY_TRANSFER);
	}

	/**
	 * @return {@link #accountingRecord}
	 */
	public List<Record> getAccountingRecord() {
		return accountingRecord;
	}

	/**
	 * @param accountingRecord {@link #accountingRecord}
	 */
	public void setAccountingRecord(List<Record> accountingRecord) {
		this.accountingRecord = accountingRecord;
	}

	/**
	 * @return {@link #toCountryCode}
	 */
	public String getToCountryCode() {
		return toCountryCode;
	}

	/**
	 * @param toCountryCode {@link #toCountryCode}
	 */
	public void setToCountryCode(String toCountryCode) {
		this.toCountryCode = toCountryCode;
		if(LOCAL_COUNTRY_CODE.equals(toCountryCode)) {
			this.setReconciliationType(ReconciliationType.FOREIGN_CURRENCY_TRANSFER_LOCAL);
			this.localPayment = true;
		} else {
			this.setReconciliationType(ReconciliationType.FOREIGN_CURRENCY_TRANSFER_GLOBAL);
			this.localPayment = false;
		}
	}

	/**
	 * @return localPayment {@link #localPayment}
	 */
	public boolean isLocalPayment() {
		return localPayment;
	}

	/**
	 * @param localPayment {@link #localPayment}
	 */
	public void setLocalPayment(boolean localPayment) {
		this.localPayment = localPayment;
	}

	/**
	 * @return transactionExchangeRate {@link #transactionExchangeRate}
	 */
	public float getTransactionExchangeRate() {
		return transactionExchangeRate;
	}

	/**
	 * @param transactionExchangeRate {@link #transactionExchangeRate}
	 */
	public void setTransactionExchangeRate(float transactionExchangeRate) {
		this.transactionExchangeRate = transactionExchangeRate;
	}
}
