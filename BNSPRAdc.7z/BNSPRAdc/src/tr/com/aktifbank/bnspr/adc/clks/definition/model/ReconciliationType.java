package tr.com.aktifbank.bnspr.adc.clks.definition.model;

/**
 * PTT kanali islemlerine ait mutabakat tipleri
 * 
 * <li>{@link #CASH_DEPOSIT}</li>
 * <li>{@link #CASH_WITHRDRAWAL}</li>
 * <li>{@link #CREDIT_APPLICATION}</li>
 * <li>{@link #CREDIT_PAYMENT}</li>
 * <li>{@link #INSTALLMENT_LOAN}</li>
 * <li>{@link #REFERENCE_PAYMENT}</li>
 * <li>{@link #FOREIGN_CURRENCY_TRANSFER_PAYMENT}</li>
 * <li>{@link #FOREIGN_CURRENCY_TRANSFER_LOCAL}</li>
 * <li>{@link #FOREIGN_CURRENCY_TRANSFER_GLOBAL}</li>
 * <li>{@link #ELECTRONIC_FUND_TRANSFER}</li>
 * <li>{@link #ELECTRONIC_FUND_TRANSFER_FROM_PCH}</li>
 * <li>{@link #ELECTRONIC_FUND_TRANSFER_PAYMENT}</li> 
 * <li>{@link #REFUND_PAYMENT}</li> 
 * <li>{@link #REFUND_PAYMENT_WITH_EXPENSE}</li> 
 * <li>{@link #CARD_PAYMENT_PASSO}</li> 
 * <li>{@link #CARD_PAYMENT_NKOLAY}</li> 
 * <li>{@link #ATM_CASH_DEPOSIT_TO_ACCOUNT}</li> 
 * <li>{@link #ATM_CASH_DEPOSIT_TO_IBAN}</li> 
 * <li>{@link #ATM_CARD_PAYMENT_PASSO}</li> 
 * <li>{@link #ATM_CARD_PAYMENT_NKOLAY}</li> 
 * <li>{@link #ATM_CARD_PAYMENT_PASSO_WITH_ID}</li> 
 * <li>{@link #CUSTOMER_ACQUISITION}</li>
 */
public enum ReconciliationType {
	
	/**
	 * Nakit yatirma
	 */
	CASH_DEPOSIT("1"),
	
	/**
	 * Nakit cekme
	 */
	CASH_WITHDRAWAL("5"),
	
	/**
	 * Kredi basvuru
	 */
	CREDIT_APPLICATION("9"),
	
	/**
	 * Kredi odemesi
	 */
	CREDIT_PAYMENT("7"),

	/**
	 * Kredi taksit tahsilati
	 */
	INSTALLMENT_LOAN("4"),

	/**
	 * Referansli odeme
	 */
	REFERENCE_PAYMENT("6"),
	
	/**
	 * YP UPT (UPT/SWIFT) odeme 
	 */
	FOREIGN_CURRENCY_TRANSFER_PAYMENT("14"),
	
	/**
	 * UPT/SWIFT yurt ici gonderim
	 */
	FOREIGN_CURRENCY_TRANSFER_LOCAL("12"),
	
	/**
	 * UPT/SWIFT yurt disi Gonderim
	 */
	FOREIGN_CURRENCY_TRANSFER_GLOBAL("13"),
	
	/**
	 * EFT (TL UPT)
	 */
	ELECTRONIC_FUND_TRANSFER("10"),
	
	/**
	 * EFT (TL UPT) PCH ile
	 */
	ELECTRONIC_FUND_TRANSFER_FROM_PCH("70"),
	
	/**
	 * EFT odeme
	 */
	ELECTRONIC_FUND_TRANSFER_PAYMENT("11"),
	
	/**
	 * Iade odeme
	 */
	REFUND_PAYMENT("27"),
	
	/**
	 * Masraf dahil iade odeme
	 */
	REFUND_PAYMENT_WITH_EXPENSE("85"),

	/**
	 * Gise passolig kart odemesi
	 */
	CARD_PAYMENT_PASSO("65"),
	
	/**
	 * Gise nkolay kart odemesi
	 */
	CARD_PAYMENT_NKOLAY("72"),
	
	/**
	 * ATM'den hesaba nakit yatirma
	 */
	ATM_CASH_DEPOSIT_TO_ACCOUNT("60,60"),
	
	/**
	 * ATM'den hesaba nakit yatirma
	 */
	ATM_CASH_DEPOSIT_TO_IBAN("60,61"),
	
	/**
	 * ATM'den passolig kart odemesi
	 */
	ATM_CARD_PAYMENT_PASSO("60,63"),
	
	/**
	 * ATM'den nkolay kart odemesi
	 */
	ATM_CARD_PAYMENT_NKOLAY("60,65"),
	
	/**
	 * ATM'den passolig kart odemesi
	 */
	ATM_CARD_PAYMENT_PASSO_WITH_ID("60,64"),
	
	/**
	 * Musteri edinim
	 */
	CUSTOMER_ACQUISITION("137");
	
	
	private String code;

	private ReconciliationType(String code) {
		this.code = code;
	}

	public static ReconciliationType getEnum(String code) {
		for(ReconciliationType v : values())
			if(v.toString().equalsIgnoreCase(code)) return v;
		throw new IllegalArgumentException();
	}

	@Override
	public String toString() {
		return code;
	}
}
