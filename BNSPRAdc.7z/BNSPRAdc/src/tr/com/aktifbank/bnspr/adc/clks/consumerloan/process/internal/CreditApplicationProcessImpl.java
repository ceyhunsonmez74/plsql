package tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.CreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;

/**
 * 
 */
public class CreditApplicationProcessImpl<T extends Application> extends
	CreditApplicationBaseProcessImpl<T> implements CreditApplicationProcess<T> {

	private static final long serialVersionUID = 8877657328828400398L;

	public CreditApplicationProcessImpl(CreditApplicationDao<T> dao,
		CreditApplicationApi api) {
		super(dao, api);
	}
}
