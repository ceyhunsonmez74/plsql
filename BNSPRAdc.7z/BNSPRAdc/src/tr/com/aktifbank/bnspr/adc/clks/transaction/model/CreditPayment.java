package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transaction;

/**
 * PTT kanali kredi odemesi islem sinifi
 */
public class CreditPayment extends Transaction {
	
	private static final long serialVersionUID = -8482391248689690288L;
	private BigDecimal referenceNo;
	
	public CreditPayment(BigDecimal trxNo) {
		super(trxNo, (short) 2030);
		this.setReconciliationType(ReconciliationType.CREDIT_PAYMENT);
	}
	
	protected CreditPayment(BigDecimal trxNo, short trxCode) {
		super(trxNo, trxCode);
	}

	/**
	 * @return Kredi basvuru numarasi
	 */
	public BigDecimal getReferenceNo() {
		return referenceNo;
	}

	/**
	 * @param referenceNo the referenceNo to set
	 */
	public void setReferenceNo(BigDecimal referenceNo) {
		this.referenceNo = referenceNo;
	}
}
