package tr.com.aktifbank.bnspr.adc.clks.consumerloan.api;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.core.api.CoreApplicationApi;

/**
 * Kredi basvuru API sinifi
 */
public interface CreditApplicationApi extends CoreApplicationApi {
	
	/**
	 * Kredi kampanyasi ozelinde tutar ve vade kontrolu saglar.
	 *  
	 * @param campaignCode		Kampanya kodu
	 * @param amount			Kredi tutari
	 * @param term				Kredi vadesi
	 */
	public void amountAndTermControl(String campaignCode, BigDecimal amount, int term);
	
	/**
	 * Kredi basvuru yas kontrolu saglar.
	 * 
	 * @param birthDate				Dogum tarihi
	 * @param campaignChannelCode	Kampanya kanal kodu
	 * @param term					Kredi vadesi
	 */
	public void ageControl(Date birthDate, BigDecimal campaignChannelCode, int term);
	
	
	/**
	 * Kredi basvurusunu {@code RED} olarak gunceller, tarihceye kayit atar.
	 * 
	 * @param applicationNo			Kredi basvuru numarasi
	 * @param trxNo					Islem numarasi
	 * @param status				Basvuru durumu
	 * @param decisionCode			Karar kod
	 * @return						RED aciklama
	 */
	public String rejectApplication(BigDecimal applicationNo, BigDecimal trxNo, String status, String decisionCode);
	
	/**
	 * Kredi belgesetine ait barkod icin DYS kaydi atar.
	 * 
	 * @param applicationNo
	 * @param barcode
	 */
	public void saveBarcode(BigDecimal applicationNo, String barcode);
	
	/**
	 * Kredi sureci icin parametre toparlar.
	 * 
	 * @param applicationNo		Kredi basvuru numarasi
	 * @param status			Basvuru durumu
	 * @return
	 * 
	 * @see Application.STATUS
	 */
	public Map<?,?> fetchParameters(BigDecimal applicationNo, Application.STATUS status);
	
	/**
	 * Belge kontrol ve kredi kullandirimi.
	 * 
	 * @param documents		Kredi belgeleri
	 * @param parameters	Belge kontrol icin gerekli parametre seti
	 */
	public void documentControl(List<Map<?,?>> documents, Map<?,?> parameters);
	
	/**
	 * 
	 * @param applicationNo		Kredi basvuru numarasi
	 * @param documentTrxNo		Kredi belge islem numarasi
	 * @param documents			Kredi basvuru belgeleri
	 * @return
	 */
	public Map<?,?> updateDocuments(BigDecimal applicationNo, BigDecimal documentTrxNo, List<Map<?,?>> documents);
	
	/**
	 * 
	 * @param trxNo		Kredi basvuru islem numarasi 
	 * @param trxCode	Kredi basvuru islem kodu
	 */
	public void sendApplicationText(BigDecimal trxNo, String trxCode);
	
	
	/**
	 * Yapilandirma kredilerinde on validasyon saglar.
	 * 
	 * @param nationalIdentityNumber	TC Kimlik numarasi
	 * @param applicationNo 				Kredi basvuru numarasi
	 * @return 
	 */
	public boolean consolidationValidation(String nationalIdentityNumber, BigDecimal applicationNo);
}
