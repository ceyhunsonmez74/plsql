package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionContext;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ForeignCurrencyTransfer;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class ForeignCurrencyTransferProcess extends TransactionBaseProcess<ForeignCurrencyTransfer> implements
	TransactionProcess<ForeignCurrencyTransfer> {
	
	private static Logger logger = Logger.getLogger(ForeignCurrencyTransferProcess.class);
	private static final float COMMISSION_RATIO = 0.35f;

	public ForeignCurrencyTransferProcess(TransactionDao<ForeignCurrencyTransfer> dao) {
		super(dao);
	}

	@Override
	public void request(ForeignCurrencyTransfer transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(ForeignCurrencyTransfer transaction) {
		super.confirm(transaction);
	}

	/**
	 * 
	 */
	@Override
	protected Record calculateCommission(ForeignCurrencyTransfer transaction) {
		
		CommissionContext commissionContext = null;
		Record record = null;
		
		try {
			
			// float commissionRatio, CurrencyType commissionCurrency, float rate
			
			commissionContext = new CommissionContext(transaction.commissionCategory()
				.getStrategyClass().getDeclaredConstructor(new Class[]{float.class, CurrencyType.class, float.class})
				.newInstance(new Object[]{Float.valueOf(COMMISSION_RATIO), CurrencyType.TRY, 
					Float.valueOf(transaction.getTransactionExchangeRate())}));

			record = commissionContext.calculate(new Record(transaction.expenseAmount(), transaction.expenseCurrency()));
			
		} catch(Exception e) {
			logger.error("ForeignCurrencyTransferProcess.calculateCommission err:", e);
		}
		
		return record;
	}
}
