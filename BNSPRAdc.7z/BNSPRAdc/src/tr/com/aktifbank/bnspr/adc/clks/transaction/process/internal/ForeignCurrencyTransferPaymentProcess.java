package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ForeignCurrencyTransferPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class ForeignCurrencyTransferPaymentProcess extends TransactionBaseProcess<ForeignCurrencyTransferPayment> implements
	TransactionProcess<ForeignCurrencyTransferPayment> {
	
	private static Logger logger = Logger.getLogger(ForeignCurrencyTransferPaymentProcess.class);

	public ForeignCurrencyTransferPaymentProcess(TransactionDao<ForeignCurrencyTransferPayment> dao) {
		super(dao);
	}

	@Override
	public void request(ForeignCurrencyTransferPayment transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(ForeignCurrencyTransferPayment transaction) {
		super.confirm(transaction);
	}
}
