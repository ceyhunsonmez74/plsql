package tr.com.aktifbank.bnspr.adc.clks.accounting;

import java.util.List;

import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;

public abstract class CommissionOnAmount {

	private final List<CommissionRecord> records;

	/**
	 * 
	 * @param records	Komisyon barem listesi
	 */
	public CommissionOnAmount(List<CommissionRecord> records) {
		this.records = records;
	}

	/**
	 * 
	 * @return	Komisyon baremlerini doner
	 * @see CommissionRecord
	 */
	public List<CommissionRecord> getRecords() {
		return records;
	}
}
