package tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.CreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;

public class CreditApplicationRetireeProcessImpl extends
	CreditApplicationBaseProcessImpl<Application> implements CreditApplicationProcess<Application> {

	private static final long serialVersionUID = -49201426166430795L;

	private static Logger logger = Logger.getLogger(CreditApplicationRetireeProcessImpl.class);

	public CreditApplicationRetireeProcessImpl(CreditApplicationDao<Application> dao,
		CreditApplicationApi api) {
		super(dao, api);
	}
	
	@Override
	public Map<?,?> applicationRequest(Application application, boolean checkExistingMobilePhone) {
		
		logger.info(String.format("[ConsumerLoan][Retiree][ApplicationRequest] - %s", application.toString()));
		
		if(application.getCampaign().isConsolidationOnChannel()) {
			
			if(!this.getApi().consolidationValidation(application.getNationalIdentificationNumber(), application.getApplicationNo())) {
				if(application.getCampaign().isVisualImpairment()) {
					this.getApi().error(5957);
				} else {
					this.getApi().error(5956);
				}
			}
		}
		
		Map<?,?> processMap = super.applicationRequest(application, checkExistingMobilePhone);
		return processMap;
	}
	
	@Override
	public Map<?, ?> contractualRequest(Application application, List<Map<?, ?>> documents) {
		
		logger.info(String.format("[ConsumerLoan][Retiree][ContractualRequest] - %s", application.toString()));
		return super.contractualRequest(application, documents);
	}
}
