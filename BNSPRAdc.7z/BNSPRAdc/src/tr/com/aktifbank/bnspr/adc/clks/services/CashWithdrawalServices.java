package tr.com.aktifbank.bnspr.adc.clks.services;

import java.math.BigDecimal;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCashWithdrawalDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CashWithdrawal;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.CashWithdrawalProcess;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CashWithdrawalServices {
	
	private static Logger logger = Logger.getLogger(CashWithdrawalServices.class);
	
	@GraymoundService("BNSPR_CLKS_CASH_WITHDRAWAL_CONFIRM")
	public static GMMap confirm(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {
			
			TransactionDao<CashWithdrawal> dao = new DalCashWithdrawalDao();
			CashWithdrawal cashWithdrawal = dao.get(iMap.getBigDecimal("ISLEM_NO"));
			
			TransactionProcess<CashWithdrawal> process = new CashWithdrawalProcess(dao);
			process.confirm(cashWithdrawal);
			
			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", new GMMap().put("ISLEM_TURU", "O").put(
				"ISLEM_NO", cashWithdrawal.trxNo()).put("ISLEM_KODU", BigDecimal.valueOf(cashWithdrawal.trxCode())));
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CASH_WITHDRAWAL_CONFIRM err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

}
