package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ReferencePayment;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class DalReferencePaymentDao extends DalTransactionDao<ReferencePayment> implements
	TransactionDao<ReferencePayment> {
	
	private static Logger logger = Logger.getLogger(DalReferencePaymentDao.class);

	public DalReferencePaymentDao() {
		super(ReferencePayment.class);
	}

	@Override
	public ReferencePayment get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		ClksHavaleOdemeTx clksHavaleOdemeTx = (ClksHavaleOdemeTx) session.get(ClksHavaleOdemeTx.class, trxNo);
		ReferencePayment payment = new ReferencePayment(clksHavaleOdemeTx.getTxNo(), "CLKSIADE"
			.equals(clksHavaleOdemeTx.getIslemSekli()) ? true : false);
		payment.setAmount(clksHavaleOdemeTx.getTutar());
		payment.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
		payment.setExpenseAmount(clksHavaleOdemeTx.getMasrafTutari());
		payment.setExpenseCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getMasrafTahsilDoviz()));
		payment.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
		
		// TODO Framework bagimliligi cozulecek
		if(payment.isRefund()) {
			try {
				GMMap transferMap = DALUtil.callOracleRefCursorFunction(
					"{? = call pkg_ptt_referans_odeme.transfer_komisyon_bilgileri(?,?)}", "TRANSFER_KOMISYON",
					BnsprType.NUMBER, payment.trxNo(), BnsprType.NUMBER, BigDecimal.valueOf(payment.trxCode()));
				
				if(transferMap.get("TRANSFER_KOMISYON", 0, "KOMISYON_TUTAR") != null) {
					payment.setExpenseRefunded(true);
					payment.setCommissionAmount(transferMap.getBigDecimal("TRANSFER_KOMISYON", 0, "KOMISYON_TUTAR").negate());
					payment.setCommissionCurrency(CurrencyType.getEnum(transferMap.getString("TRANSFER_KOMISYON", 0, "KOMISYON_DOVIZ")));
				}
				
			} catch(Exception e) {
				logger.error(String.format("ReferencePayment -> %s", payment), e);
			}
		}
		
		return payment;
	}

	@Override
	public List<ReferencePayment> filter(Map<String, Object> criteria) {

		List<ReferencePayment> paymentList = new ArrayList<ReferencePayment>();

		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<ClksHavaleOdemeTx> list = session.createCriteria(ClksHavaleOdemeTx.class).add(
			Restrictions.allEq(criteria)).list();

		for(ClksHavaleOdemeTx clksHavaleOdemeTx : list) {
			ReferencePayment payment = new ReferencePayment(clksHavaleOdemeTx.getTxNo(), "CLKSIADE"
				.equals(clksHavaleOdemeTx.getIslemSekli()) ? true : false);
			payment.setAmount(clksHavaleOdemeTx.getTutar());
			payment.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
			payment.setExpenseAmount(clksHavaleOdemeTx.getMasrafTutari());
			payment.setExpenseCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getMasrafTahsilDoviz()));
			payment.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
			paymentList.add(payment);
		}
		return paymentList;
	}

	@Override
	public List<ReferencePayment> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(ReferencePayment type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(ReferencePayment type) {
		// TODO Auto-generated method stub
		
	}
}
