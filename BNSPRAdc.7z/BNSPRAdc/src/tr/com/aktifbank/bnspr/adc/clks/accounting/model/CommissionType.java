package tr.com.aktifbank.bnspr.adc.clks.accounting.model;

/**
 * Komisyon Tipi
 * 
 * <li>{@link #FIX_AMOUNT}</li>
 * <li>{@link #RATIO}</li>
 */
public enum CommissionType {
	
	/**
	 * Sabit tutar
	 */
	FIX_AMOUNT, 
	
	/**
	 * Oran
	 */
	RATIO
}
