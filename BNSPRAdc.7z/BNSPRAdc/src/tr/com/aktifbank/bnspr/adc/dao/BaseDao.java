package tr.com.aktifbank.bnspr.adc.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface BaseDao<T> {
	public List<T> all();
	public T get(Serializable id);
	public List<T> filter(Map<String, Object> criteria);
	public void save(T type);
	public void saveOrUpdate(T type);
}
