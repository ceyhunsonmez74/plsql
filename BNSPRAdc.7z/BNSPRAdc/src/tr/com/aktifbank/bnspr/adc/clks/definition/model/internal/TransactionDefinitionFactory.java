package tr.com.aktifbank.bnspr.adc.clks.definition.model.internal;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.TransactionDefinition;

public class TransactionDefinitionFactory {

	/**
	 * 
	 * @param code
	 * @return
	 */
	public static TransactionDefinition of(ReconciliationType code) {

		switch(code) {
			case INSTALLMENT_LOAN:
				return new InstallmentLoanDefinition();
			case CREDIT_PAYMENT:
				return new CreditPaymentDefinition();
			case CREDIT_APPLICATION:
				return new CreditApplicationDefinition();
			case ELECTRONIC_FUND_TRANSFER:
				return new ElectronicFundTransfer(new String[] { "2315" }, ReconciliationType.ELECTRONIC_FUND_TRANSFER.toString());
			case ELECTRONIC_FUND_TRANSFER_FROM_PCH:
				return new ElectronicFundTransfer(new String[] { "2315" }, ReconciliationType.ELECTRONIC_FUND_TRANSFER_FROM_PCH.toString());
			case FOREIGN_CURRENCY_TRANSFER_GLOBAL:
				return new ForeignCurrencyTransferDefinition(ReconciliationType.FOREIGN_CURRENCY_TRANSFER_GLOBAL.toString());
			case FOREIGN_CURRENCY_TRANSFER_LOCAL:
				return new ForeignCurrencyTransferDefinition(ReconciliationType.FOREIGN_CURRENCY_TRANSFER_LOCAL.toString());
			case REFERENCE_PAYMENT:
				return new ReferencePaymentDefinition();
			case ELECTRONIC_FUND_TRANSFER_PAYMENT:
				return new ElectronicFundTransferPayment(new String[] { "2317" }, "11");
			case FOREIGN_CURRENCY_TRANSFER_PAYMENT:
				return new ForeignCurrencyTransferPaymentDefinition();
			case REFUND_PAYMENT:
				return new RefundPaymentDefinition();
			case REFUND_PAYMENT_WITH_EXPENSE:
				return new RefundPaymentWithExpense();
			case CASH_DEPOSIT:
				return new CashDepositDefinition();
			case CASH_WITHDRAWAL:	
				return new CashWithDrawalDefinition();
			case ATM_CASH_DEPOSIT_TO_ACCOUNT:
				return new ATMCashDepositDefinition(new String[] {"2048","2049"}, "60,60");
			case ATM_CASH_DEPOSIT_TO_IBAN:
				return new ATMCashDepositDefinition(new String[] {"2048","2049"}, "60,61");
			case ATM_CARD_PAYMENT_PASSO:
				return new ATMCashDepositDefinition(new String[] {"2048","2049"}, "60,63");
			case ATM_CARD_PAYMENT_PASSO_WITH_ID:
				return new ATMCashDepositDefinition(new String[] {"2048","2049"}, "60,64");
			case ATM_CARD_PAYMENT_NKOLAY:
				return new ATMCashDepositDefinition(new String[] {"2048","2049"}, "60,65");
			case CARD_PAYMENT_PASSO:
				return new CardPaymentDefinition(ReconciliationType.CARD_PAYMENT_PASSO.toString());
			case CARD_PAYMENT_NKOLAY:
				return new CardPaymentDefinition(ReconciliationType.CARD_PAYMENT_NKOLAY.toString());
			case CUSTOMER_ACQUISITION:
				return new CustomerAcquisitionDefinition();
			default:
				return null;
		}
	}
	

}
