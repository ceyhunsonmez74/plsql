package tr.com.aktifbank.bnspr.adc.clks.consumerloan.model;

import java.math.BigDecimal;
import java.util.Arrays;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.SgkInstitution.InsuranceChannel;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.SgkInstitution.RelatedField;

/**
 * Emekli aylik odemesi sinifi
 * 
 * @author kaan.yanc
 * @see SgkInstitution
 */
public final class PensionPayment implements Cloneable, java.io.Serializable {
	
	private static final long serialVersionUID = -7869449608468142549L;
	private SgkInstitution institution;
	private String paymentId;
	private String registrationNumber;
	private BigDecimal amount;
	private int paymentPeriod;
	private String paymentResultCode;
	private String paymentResultDescription;
	private int paymentSource;

	/**
	 * Emekli aylik odemesi
	 * 
	 * @param institution				SGK kurumu
	 * @param paymentId					SGK aylik id
	 * @param registrationNumber		SGK sicil numarasi
	 * @param paymentResultCode			SGK sonuc kodu
	 * @param paymentResultDescription	SGK sonuc aciklamasi
	 * @param paymentSource				SGK aylik bankamda mi degeri
	 */
	public PensionPayment(SgkInstitution institution, String paymentId, String registrationNumber,
		String paymentResultCode, String paymentResultDescription, int paymentSource) {
		this.institution = institution;
		this.paymentId = paymentId;
		this.registrationNumber = registrationNumber;
		this.paymentResultCode = paymentResultCode;
		this.paymentResultDescription = paymentResultDescription;
		this.paymentSource = paymentSource;
		this.paymentPeriod = Arrays.asList(SgkInstitution.InsuranceChannel._4A, SgkInstitution.InsuranceChannel._4B)
			.contains(institution.getInsuranceChannel()) ? 1 : 0;
	}

	/**
	 * Emekli aylik odemesi
	 * 
	 * @param institution 				SGK kurumu
	 * @param paymentId 				SGK aylik id
	 * @param registrationNumber		SGK sicil numarasi
	 * @param amount					Aylik Tutari
	 * @param paymentPeriod				Aylik periyodu
	 * @param paymentResultCode			SGK sonuc kodu
	 * @param paymentResultDescription	SGK sonuc aciklamasi
	 * @param paymentSource				SGK aylik bankamda mi degeri
	 */
	public PensionPayment(SgkInstitution institution, String paymentId, String registrationNumber, BigDecimal amount,
		int paymentPeriod, String paymentResultCode, String paymentResultDescription, int paymentSource) {
		this.institution = institution;
		this.paymentId = paymentId;
		this.registrationNumber = registrationNumber;
		this.amount = amount;
		this.paymentPeriod = paymentPeriod;
		this.paymentResultCode = paymentResultCode;
		this.paymentResultDescription = paymentResultDescription;
		this.paymentSource = paymentSource;
	}
	
	@Override
	public Object clone() {
		PensionPayment cloned;
		
		try {
			cloned = (PensionPayment) super.clone();
		} catch(CloneNotSupportedException e) {
			cloned = new PensionPayment(this.institution, this.paymentId, this.registrationNumber, this.amount,
				this.paymentPeriod, this.paymentResultCode, this.paymentResultDescription, this.paymentSource);
		}		
	    
		return cloned;
	}

	/**
	 * Emekli maasi uzerinde tasima blokesi olup olmadigini doner. Degisken initialize edilmediyse {@code false} doner.
	 * 
	 * @return bloke var ise {@code true}, aksi durumda {@code false}
	 */
	public boolean isPaymentLocked() {
		
		if("-10".equals(paymentResultCode))
			return true;
		
		return false;
	}
	
	/**
	 * Emekli maasinin kaynaginin PTT olup olmadigini doner. Degisken initialize edilmediyse {@code false} doner.
	 * 
	 * @return kaynak PTT ise {@code true}, aksi durumda {@code false}
	 */
	public boolean isPaymentSourceValid() {
		
		if(paymentSource == 1)
			return true;
		
		return false;
	}	
	
	/**
	 * Iki PensionPayment nesnesini karsilastirir ve karsilastirilan nesnenin onceligi daha yuksek ise {@code false}
	 * degerini doner.
	 * <p>Oncelik asagidaki kuralsetine gore berlirlenir.</p>
	 * <ul>
	 * <li>Bu nesnenin ve kasrsilastirilan nesnenin {@link #isPaymentLocked()} degerleri esit ise, oncelik 
	 * {@link PensionPayment#getInstitution()} degiskeninin {@link InsuranceChannel} sinif degisken degerine gore, 
	 * asagidaki sirada belirlenir:</li>
	 * <p><ul>
	 * <li>{@link InsuranceChannel#_4A}</li>
	 * <li>{@link InsuranceChannel#_4B}</li>
	 * <li>{@link InsuranceChannel#_4C}</li>
	 * </ul></p>
	 * <li>Karsilastirilan nesnenin {@link #isPaymentLocked()} degeri {@code true}, bu nesneninki {@code false}</li> ise
	 * , oncelik karsilastirilan nesneye verilir.</li>
	 * <li>Karsilastirilan nesnenin {@link #isPaymentLocked()} degeri {@code false}, bu nesneninki {@code true}</li> ise
	 * , oncelik bu nesneye verilir.</li>
	 * <ul>
	 * 
	 * @param payment		Karsilastirilacak {@code PensionPayment}
	 * @return				Karsilastirilan {@code PensionPayment} daha yuksek bir oncelige sahip ise {@code false},
	 * 						aksi durumda {@code true}
	 */
	public boolean hasHigherPriority(PensionPayment payment) {

		if(this.equals(payment)) return true;

		if(this.isPaymentLocked() == payment.isPaymentLocked()) {

			if(this.institution.getInsuranceChannel() == InsuranceChannel._4C
				&& payment.getInstitution().getInsuranceChannel() != InsuranceChannel._4C) return false;
			else if(this.institution.getInsuranceChannel() == InsuranceChannel._4B
				&& payment.getInstitution().getInsuranceChannel() == InsuranceChannel._4A) return false;
			else return true;

		} else {

			if(!this.isPaymentLocked() && payment.isPaymentLocked()) return false;
			else return true;
		}
	}
	
	@Override
	public String toString() {
		return String.format(
			"%s(institution=%s, paymentId=%s, paymentResultCode=%s, paymentSource=%s, amount=%s, period=%s)",
			PensionPayment.class.getSimpleName(), institution.toString(), paymentId, paymentResultCode, paymentSource,
			amount, paymentPeriod);
	}
	
	/**
	 * @return SGK kurumu
	 */
	public SgkInstitution getInstitution() {
		return institution;
	}

	public void setInstitution(SgkInstitution institution) {
		this.institution = institution;
	}
	
	/**
	 * @return SGK aylik id
	 */
	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	/**
	 * @return SGK sicil numarasi
	 */
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	/**
	 * @return TL biriminden aylik tutari
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return Aylik periyodu (1,3 vb.)
	 */
	public int getPaymentPeriod() {
		return paymentPeriod;
	}

	public void setPaymentPeriod(int paymentPeriod) {
		this.paymentPeriod = paymentPeriod;
	}

	/**
	 * @return SGK aylik sonuc kodu
	 */
	public String getPaymentResultCode() {
		return paymentResultCode;
	}

	public void setPaymentResultCode(String paymentResultCode) {
		this.paymentResultCode = paymentResultCode;
	}

	/**
	 * @return SGK aylik sonuc aciklamasi
	 */
	public String getPaymentResultDescription() {
		return paymentResultDescription;
	}

	public void setPaymentResultDescription(String paymentResultDescription) {
		this.paymentResultDescription = paymentResultDescription;
	}

	/**
	 * @return SGK aylik bankamda bilgisi
	 * <ul><li>1: Aylik bankamda</li><li>0: Aylik bankamda degil</li></ul>
	 */
	public int getPaymentSource() {
		return paymentSource;
	}

	public void setPaymentSource(int paymentSource) {
		this.paymentSource = paymentSource;
	}
	
	/**
	 * @return Tahsis numarasi 
	 */
	public String getAllocationNumber() {
		if(institution.getRelatedField() == RelatedField.AYLIK_ID)
			return paymentId;
		else if(institution.getRelatedField() == RelatedField.SICIL_NO)
			return registrationNumber;
		else
			throw new IllegalStateException("relatedField is not set.");
	}
}
