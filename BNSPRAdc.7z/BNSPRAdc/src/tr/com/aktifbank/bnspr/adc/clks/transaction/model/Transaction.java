package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.io.Serializable;
import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

/**
 * 
 */
abstract public class Transaction implements Serializable {

	private static final long serialVersionUID = -7548437234737306641L;
	
	/**
	 * Islem Numarasi
	 */
	private final BigDecimal trxNo;
	
	/**
	 * Islem Kodu
	 */
	private final Short code;
	
	/**
	 * Islem Tutari
	 */
	private BigDecimal amount;
	
	/**
	 * Islem Para birimi
	 */
	private CurrencyType currency;
	
	/**
	 * Masraf Tutari
	 */
	private BigDecimal expenseAmount;
	
	/**
	 * Masraf Para birimi
	 */
	private CurrencyType expenseCurrency;
	
	
	/**
	 * Vendor Islem Numarasi
	 */
	private BigDecimal clientTransactionNo;
	
	/**
	 * Komisyon Kategorisi
	 */
	private CommissionCategory commissionCategory;
	
	/**
	 * Mutabakat Tipi
	 */
	private ReconciliationType reconciliationType;
	
	/**
	 * Komisyon Tutari
	 */
	private BigDecimal commissionAmount;
	
	/**
	 * Komisyon Para birimi
	 */
	private CurrencyType commissionCurrency;

	/**
	 * 
	 * @param trxNo {@link #trxNo}
	 * @param code {@link #code}
	 */
	public Transaction(BigDecimal trxNo, Short code) {
		this.trxNo = trxNo;
		this.code = code;
	}

	/**
	 * @return {@link #trxNo}
	 */
	public BigDecimal trxNo() {
		return trxNo;
	}
	
	/**
	 * @return {@link #trxCode()}
	 */
	public Short trxCode() {
		return code;
	}

	/**
	 * @return {@link #amount}
	 */
	public BigDecimal amount() {
		return amount;
	}
	
	/**
	 * @param ampount {@link #amount}
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return {@link #currency}
	 */
	public CurrencyType currency() {
		return currency;
	}

	/**
	 * @param currency {@link #currency}
	 */
	public void setCurrency(CurrencyType currency) {
		this.currency = currency;
	}

	/**
	 * @return {@link #expenseAmount}
	 */
	public BigDecimal expenseAmount() {
		return expenseAmount;
	}
	
	/**
	 * @param expenseAmount {@link #expenseAmount}
	 */
	public void setExpenseAmount(BigDecimal expenseAmount) {
		this.expenseAmount = expenseAmount;
	}

	/**
	 * @return {@link #expenseCurrency}
	 */
	public CurrencyType expenseCurrency() {
		return expenseCurrency;
	}

	/**
	 * @param expenseCurrency {@link #expenseCurrency}
	 */
	public void setExpenseCurrency(CurrencyType expenseCurrency) {
		this.expenseCurrency = expenseCurrency;
	}
	
	/**
	 * @return {@link #clientTrxNo()}
	 */
	public BigDecimal clientTrxNo() {
		return clientTransactionNo;
	}

	/**
	 * @param clientTransactionNo {@link #clientTrxNo}
	 */
	public void setClientTrxNo(BigDecimal clientTrxNo) {
		this.clientTransactionNo = clientTrxNo;
	}

	/**
	 * @return {@link #commissionCategory}
	 */
	public CommissionCategory commissionCategory() {
		return commissionCategory;
	}

	/**
	 * @param commissionCategory {@link #commissionCategory}
	 */
	public void setCommissionCategory(CommissionCategory commissionCategory) {
		this.commissionCategory = commissionCategory;
	}

	/**
	 * @return {@link #reconciliationType}
	 */
	public ReconciliationType reconciliationType() {
		return reconciliationType;
	}

	/**
	 * @param reconciliationType {@link #reconciliationType}
	 */
	public void setReconciliationType(ReconciliationType reconciliationType) {
		this.reconciliationType = reconciliationType;
	}

	/**
	 * @return {@link #commissionAmount}
	 */
	public BigDecimal commissionAmount() {
		return commissionAmount;
	}

	/**
	 * @param commissionAmount {@link #commissionAmount}
	 */
	public void setCommissionAmount(BigDecimal commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	/**
	 * @return {@link #commissionCurrency}
	 */
	public CurrencyType commissionCurrency() {
		return commissionCurrency;
	}

	/**
	 * @param commissionCurrency {@link #commissionCurrency}
	 */
	public void setCommissionCurrency(CurrencyType commissionCurrency) {
		this.commissionCurrency = commissionCurrency;
	}

	@Override
	public String toString() {
		return String.format("%s(trxNo=%s, code=%s)", Transaction.class.getSimpleName(), this
			.trxNo().toString(), this.trxCode().toString());
	}
}
