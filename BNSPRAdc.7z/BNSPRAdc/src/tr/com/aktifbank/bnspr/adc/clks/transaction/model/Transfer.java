package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transaction;

/**
 * PTT kanali havale islem sinifi
 * 
 * @author kaan.yanc
 * @see Transaction
 */
public class Transfer extends Transaction {

	private static final long serialVersionUID = 2494190227913284591L;

	public Transfer(BigDecimal trxNo) {
		super(trxNo, (short) 2030);
	}

}
