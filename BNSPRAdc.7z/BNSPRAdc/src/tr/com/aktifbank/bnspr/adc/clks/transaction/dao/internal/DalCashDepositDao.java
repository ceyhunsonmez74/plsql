package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CashDeposit;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CashDeposit.CHANNEL;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;

import com.graymound.server.dao.DAOSession;

public class DalCashDepositDao extends DalTransactionDao<CashDeposit> implements TransactionDao<CashDeposit> {

	public DalCashDepositDao() {
		super(CashDeposit.class);
	}

	@Override
	public CashDeposit get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, trxNo);

		String transactionType = clksHavaleGirisTx.getIslem().toString();
		ReconciliationType reconciliationType = null;
		
		if(Arrays.asList("1","2").contains(transactionType)) {
			reconciliationType = ReconciliationType.CASH_DEPOSIT;
		} else if("4".equals(transactionType)) {
			reconciliationType = ReconciliationType.INSTALLMENT_LOAN;
		} else if("60".equals(transactionType)) {
			reconciliationType = ReconciliationType.ATM_CASH_DEPOSIT_TO_ACCOUNT;
		} else if("61".equals(transactionType)) {
			reconciliationType = ReconciliationType.ATM_CASH_DEPOSIT_TO_IBAN;
		}
		
		CashDeposit cashDeposit = new CashDeposit(clksHavaleGirisTx.getTxNo(), clksHavaleGirisTx.getIslemSekli()
			.startsWith("PATM") ? CHANNEL.ATM : CHANNEL.BRANCH, reconciliationType);
		
		cashDeposit.setAmount(clksHavaleGirisTx.getTutar());
		cashDeposit.setCurrency(CurrencyType.getEnum(clksHavaleGirisTx.getDovizKodu()));
		cashDeposit.setClientTrxNo(clksHavaleGirisTx.getPttIslemNo());
		cashDeposit.setExpenseAmount(clksHavaleGirisTx.getMasrafTutari());
		cashDeposit.setExpenseCurrency(CurrencyType.getEnum(clksHavaleGirisTx.getMasrafTahsilDoviz()));
		return cashDeposit;
	}

	@Override
	public List<CashDeposit> filter(Map<String, Object> criteria) {
		
		List<CashDeposit> cashDepositList = new ArrayList<CashDeposit>();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<ClksHavaleGirisTx> list = session.createCriteria(ClksHavaleGirisTx.class).add(Restrictions.allEq(criteria))
			.list();

		for(ClksHavaleGirisTx clksHavaleGirisTx : list) {

			String transactionType = clksHavaleGirisTx.getIslem().toString();
			ReconciliationType reconciliationType = null;
			
			if(Arrays.asList("1","2").contains(transactionType)) {
				reconciliationType = ReconciliationType.CASH_DEPOSIT;
			} else if("4".equals(transactionType)) {
				reconciliationType = ReconciliationType.INSTALLMENT_LOAN;
			} else if("60".equals(transactionType)) {
				reconciliationType = ReconciliationType.ATM_CASH_DEPOSIT_TO_ACCOUNT;
			} else if("61".equals(transactionType)) {
				reconciliationType = ReconciliationType.ATM_CASH_DEPOSIT_TO_IBAN;
			}
			
			CashDeposit cashDeposit = new CashDeposit(clksHavaleGirisTx.getTxNo(), clksHavaleGirisTx.getIslemSekli()
				.startsWith("PATM") ? CHANNEL.ATM : CHANNEL.BRANCH, reconciliationType);
			cashDeposit.setAmount(clksHavaleGirisTx.getTutar());
			cashDeposit.setCurrency(CurrencyType.getEnum(clksHavaleGirisTx.getDovizKodu()));
			cashDeposit.setClientTrxNo(clksHavaleGirisTx.getPttIslemNo());
			cashDepositList.add(cashDeposit);
		}
		return cashDepositList;
	}

	@Override
	public List<CashDeposit> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(CashDeposit type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(CashDeposit type) {
		// TODO Auto-generated method stub
		
	}
}
