package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;
import java.util.EnumSet;

import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

/**
 * PTT kanali kart odemeleri sinifi
 *
 * @see Transaciton
 */
public class CardPayment extends Transaction {

	private static final long serialVersionUID = 1890830607648532791L;
	
	/**
	 * Islem kanali
	 */
	private CHANNEL channel;
	
	/**
	 * Kart ozelligi
	 */
	private PROPERTY property;
	
	public enum PROPERTY {
		PASSO, NKOLAY
	}
	
	public enum CHANNEL {
		BRANCH, ATM
	}

	public CardPayment(BigDecimal trxNo, ReconciliationType reconciliationType) {
		super(trxNo, EnumSet.of(ReconciliationType.CARD_PAYMENT_NKOLAY, ReconciliationType.CARD_PAYMENT_PASSO)
			.contains(reconciliationType) ? (short) 2053 : (short) 2048);
		this.setReconciliationType(reconciliationType);
		if(EnumSet.of(ReconciliationType.ATM_CARD_PAYMENT_NKOLAY, ReconciliationType.ATM_CARD_PAYMENT_PASSO,
			ReconciliationType.ATM_CARD_PAYMENT_PASSO_WITH_ID).contains(reconciliationType)) {
			this.channel = CHANNEL.ATM;
			this.setCommissionCategory(CommissionCategory.ATM_CARD_PAYMENT);
		} else if(EnumSet.of(ReconciliationType.CARD_PAYMENT_NKOLAY, ReconciliationType.CARD_PAYMENT_PASSO).contains(
			reconciliationType)) {
			this.channel = CHANNEL.BRANCH;
			this.setCommissionCategory(CommissionCategory.CARD_PAYMENT);
		}
	}

	/**
	 * @return the channel
	 */
	public CHANNEL getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(CHANNEL channel) {
		this.channel = channel;
	}

	/**
	 * @return the property
	 */
	public PROPERTY getProperty() {
		return property;
	}

	/**
	 * @param property the property to set
	 */
	public void setProperty(PROPERTY property) {
		this.property = property;
	}
}
