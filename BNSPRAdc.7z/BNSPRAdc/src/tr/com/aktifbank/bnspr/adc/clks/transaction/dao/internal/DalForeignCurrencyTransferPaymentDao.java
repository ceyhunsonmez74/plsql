package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ForeignCurrencyTransferPayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ForeignCurrencyTransferPayment.PROVIDER;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class DalForeignCurrencyTransferPaymentDao extends DalTransactionDao<ForeignCurrencyTransferPayment> implements
	TransactionDao<ForeignCurrencyTransferPayment> {
	
	private static Logger logger = Logger.getLogger(DalForeignCurrencyTransferPaymentDao.class);

	public DalForeignCurrencyTransferPaymentDao() {
		super(ForeignCurrencyTransferPayment.class);
	}

	@Override
	public ForeignCurrencyTransferPayment get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		ClksHavaleOdemeTx clksHavaleOdemeTx = (ClksHavaleOdemeTx) session.get(
			ClksHavaleOdemeTx.class, trxNo);
		ForeignCurrencyTransferPayment payment = new ForeignCurrencyTransferPayment(clksHavaleOdemeTx.getTxNo(),
			BigDecimal.valueOf(4).compareTo(clksHavaleOdemeTx.getIslem()) == 0 ? PROVIDER.UPT : PROVIDER.SWIFT,
				"CLKSIADE".equals(clksHavaleOdemeTx.getIslemSekli()) ? true : false);
		payment.setAmount(clksHavaleOdemeTx.getTutar());
		payment.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
		payment.setExpenseAmount(clksHavaleOdemeTx.getMasrafTutari());
		payment.setExpenseCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getMasrafTahsilDoviz()));
		payment.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
		
		// TODO Framework bagimliligi cozulecek
		if(payment.isRefund()) {
			try {
				GMMap transferMap = DALUtil.callOracleRefCursorFunction(
					"{? = call pkg_ptt_referans_odeme.transfer_komisyon_bilgileri(?,?)}", "TRANSFER_KOMISYON",
					BnsprType.NUMBER, payment.trxNo(), BnsprType.NUMBER, BigDecimal.valueOf(payment.trxCode()));
				
				if(transferMap.get("TRANSFER_KOMISYON", 0, "KOMISYON_TUTAR") != null) {
					payment.setExpenseRefunded(true);
					payment.setCommissionAmount(transferMap.getBigDecimal("TRANSFER_KOMISYON", 0, "KOMISYON_TUTAR").negate());
					payment.setCommissionCurrency(CurrencyType.getEnum(transferMap.getString("TRANSFER_KOMISYON", 0, "KOMISYON_DOVIZ")));
				}
				
			} catch(Exception e) {
				logger.error(String.format("ForeignCurrencyTransferPayment -> %s", payment), e);
			}
		}
		
		return payment;
	}

	@Override
	public List<ForeignCurrencyTransferPayment> filter(Map<String, Object> criteria) {

		List<ForeignCurrencyTransferPayment> paymentList = new ArrayList<ForeignCurrencyTransferPayment>();

		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<ClksHavaleOdemeTx> list = session.createCriteria(ClksHavaleOdemeTx.class).add(
			Restrictions.allEq(criteria)).list();

		for(ClksHavaleOdemeTx clksHavaleOdemeTx : list) {
			ForeignCurrencyTransferPayment payment = new ForeignCurrencyTransferPayment(clksHavaleOdemeTx.getTxNo(),
				BigDecimal.valueOf(4).compareTo(clksHavaleOdemeTx.getIslem()) == 0 ? PROVIDER.UPT : PROVIDER.SWIFT,
					"CLKSIADE".equals(clksHavaleOdemeTx.getIslemSekli()) ? true : false);
			payment.setAmount(clksHavaleOdemeTx.getTutar());
			payment.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
			payment.setExpenseAmount(clksHavaleOdemeTx.getMasrafTutari());
			payment.setExpenseCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getMasrafTahsilDoviz()));
			payment.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
			
			// TODO Framework bagimliligi cozulecek
			if(payment.isRefund()) {
				try {
					GMMap transferMap = DALUtil.callOracleRefCursorFunction(
						"{? = call pkg_ptt_referans_odeme.transfer_komisyon_bilgileri(?,?)}", "TRANSFER_KOMISYON",
						BnsprType.NUMBER, payment.trxNo(), BnsprType.NUMBER, BigDecimal.valueOf(payment.trxCode()));
					
					if(transferMap.get("TRANSFER_KOMISYON", 0, "KOMISYON_TUTAR") != null) {
						payment.setExpenseRefunded(true);
						payment.setCommissionAmount(transferMap.getBigDecimal("TRANSFER_KOMISYON", 0, "KOMISYON_TUTAR").negate());
						payment.setCommissionCurrency(CurrencyType.getEnum(transferMap.getString("TRANSFER_KOMISYON", 0, "KOMISYON_DOVIZ")));
					}
					
				} catch(Exception e) {
					logger.error(String.format("ForeignCurrencyTransferPayment -> %s", payment), e);
				}
			}
			
			paymentList.add(payment);
		}
		return paymentList;
	}

	@Override
	public List<ForeignCurrencyTransferPayment> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(ForeignCurrencyTransferPayment type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(ForeignCurrencyTransferPayment type) {
		// TODO Auto-generated method stub
		
	}
}
