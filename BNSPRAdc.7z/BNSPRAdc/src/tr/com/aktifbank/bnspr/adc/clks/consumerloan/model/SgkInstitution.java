package tr.com.aktifbank.bnspr.adc.clks.consumerloan.model;

import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * {@code SgkInstitution} sinifi SGK kurumundan emekliler icin kurum yapisini
 * temsil eder.
 * 
 * <p><blockquote><pre>
 *   SgkInstitution institution = SgkInstitution.valueOf(SgkInstitution.InsuranceChannel._4A);
 *   SgkInstitution institution = SgkInstitution.valueOf(SgkInstitution.ShortCode.SSK);
 * </pre></blockquote>
 * </p>
 * 
 * @see Institution
 * @see #valueOf(tr.com.aktifbank.bnspr.adc.credit.Institution.ShortCode)
 * @see #valueOf(InsuranceChannel)
 * 
 * @author kaan.yanc
 */
public class SgkInstitution implements Institution, java.io.Serializable {
	
	private static final long serialVersionUID = 438833542499292012L;
	private final ShortCode shortCode;
	private final CampaignType campaignType;
	private final InsuranceChannel insuranceChannel;
	private final RelatedField relatedField;
	private Code code;
	
	private static final Map<InsuranceChannel, ShortCode> insuranceChannelShortCodeMap = initInsuranceChannelShortCodeMap();
	private static final Map<InsuranceChannel, Code> insuranceChannelDefaultCodeMap = initInsuranceChannelDefaultCodeMap();

	private static Map<InsuranceChannel, ShortCode> initInsuranceChannelShortCodeMap() {
		Map<InsuranceChannel, ShortCode> map = new HashMap<InsuranceChannel, ShortCode>();
		map.put(InsuranceChannel._4A, ShortCode.SSK);
		map.put(InsuranceChannel._4B, ShortCode.BAGKUR);
		map.put(InsuranceChannel._4C, ShortCode.EMEKLI_SANDIGI);
		return Collections.unmodifiableMap(map);
	}

	private static Map<InsuranceChannel, Code> initInsuranceChannelDefaultCodeMap() {
		Map<InsuranceChannel, Code> map = new HashMap<InsuranceChannel, Code>();
		map.put(InsuranceChannel._4A, Code.SSK_MERKEZ);
		map.put(InsuranceChannel._4B, Code.BAGKUR_MERKEZ);
		map.put(InsuranceChannel._4C, Code.EMEKLI_SANDIGI_MERKEZ);
		return Collections.unmodifiableMap(map);
	}
	
	private static final Set<Code> codesSSK = EnumSet.of(Code.SSK_KONUT, Code.SSK_MERKEZ);
	private static final Set<Code> codesBagkur = EnumSet.of(Code.BAGKUR_KONUT, Code.BAGKUR_MERKEZ);
	private static final Set<Code> codesEmekliSandigi = EnumSet.of(Code.EMEKLI_SANDIGI_KONUT,
		Code.EMEKLI_SANDIGI_MERKEZ);

	/**
	 *
	 */
	public enum Code {
		SSK_KONUT(328, "S.S.K. KONUTTA �DEME"), SSK_MERKEZ(202, "S.S.K MERKEZ"), BAGKUR_KONUT(212, "BA�KUR KONUTTA"), BAGKUR_MERKEZ(211, "BA�KUR MERKEZDE"), EMEKLI_SANDIGI_KONUT(200, "EMEKL� SANDI�I KONUTTA TESL�M"),
		EMEKLI_SANDIGI_MERKEZ(201, "EMEKL� SANDI�I MERKEZDE �DEME");		
		
		private int code;
		private String description;
		
		Code(int code, String description) {
			this.code = code;
			this.description = description;
		}
		
		public static Code getEnum(String code) {
			for(Code v : values())
				if(v.toString().equalsIgnoreCase(code))
					return v;
			throw new IllegalArgumentException();
		}
		
		@Override
		public String toString() {
			return String.valueOf(code);
		}
		
		public String getDescription() {
			return description;
		}
	}
	
	/**
	 * Tahsis numarasi icin kullanilabilir baglanti alanalari
	 */
	public enum RelatedField {
		AYLIK_ID, SICIL_NO;
	}
	
	/**
	 * SGK sigorta kolu
	 */
	public enum InsuranceChannel {
		
		/**
		 * Sosyal Sigortalar Kurumu
		 */
		_4A, 
		
		/**
		 * Bagkur
		 */
		_4B, 
		
		/**
		 * Emekli Sandigi 
		 */
		_4C;
		
		public static InsuranceChannel getEnum(String code) {
			for(InsuranceChannel v : values())
				if(v.toString().equalsIgnoreCase(code))
					return v;
			throw new IllegalArgumentException();
		}
		
		@Override
		public String toString() {
			return this == _4A ? "4A" : this == _4B ? "4B" : this == _4C ? "4C" : null;
		}
	}
	
	/**
	 * 
	 * @param shortCode
	 * @param campaignType
	 * @param insuranceChannel
	 * @param relatedField
	 * @param code
	 * @param paymentId
	 * @param registrationNumber
	 * @param amount
	 * @param paymentPeriod
	 * @param paymentResultCode
	 * @param paymentResultDescription
	 * @param paymentSource
	 */
	public SgkInstitution(ShortCode shortCode, CampaignType campaignType, InsuranceChannel insuranceChannel,
		RelatedField relatedField, Code code) {
		this.shortCode = shortCode;
		this.campaignType = campaignType;
		this.insuranceChannel = insuranceChannel;
		this.relatedField = relatedField;
		this.code = code;
	}

	/**
	 * 
	 * @param insuranceChannel
	 */
	private SgkInstitution(InsuranceChannel insuranceChannel) {
		
		this.shortCode = insuranceChannelShortCodeMap.get(insuranceChannel);
		this.campaignType = CampaignType.EMEKLI;
		this.insuranceChannel = insuranceChannel;
		this.code = insuranceChannelDefaultCodeMap.get(insuranceChannel);
		
		if(insuranceChannel == InsuranceChannel._4B)
			this.relatedField = RelatedField.SICIL_NO;
		else
			this.relatedField = RelatedField.AYLIK_ID;
		
	}
	
	@Override
	public ShortCode getShortCode() {
		return shortCode;
	}
	
	@Override
	public CampaignType getCampaignType() {
		return campaignType;
	}
	
	@Override
	public String toString() {
		return String.format("%s(insuranceChannel=%s)", SgkInstitution.class.getSimpleName(), insuranceChannel
			.toString());
	}
	
	/**
	 * 
	 * @param insuranceChannel
	 * @return
	 */
	public static SgkInstitution valueOf(InsuranceChannel insuranceChannel) {
		return new SgkInstitution(insuranceChannel);
	}
	
	/**
	 * 
	 * @param shortCode
	 * @return
	 */
	public static SgkInstitution valueOf(ShortCode shortCode) {
		for(Entry<InsuranceChannel, ShortCode> entry : insuranceChannelShortCodeMap.entrySet())
			if(entry.getValue() == shortCode)
				return new SgkInstitution(entry.getKey());
		
		throw new IllegalArgumentException("Map entry not found");
	}

	public InsuranceChannel getInsuranceChannel() {
		return insuranceChannel;
	}

	public RelatedField getRelatedField() {
		return relatedField;
	}

	public Code getCode() {
		return code;
	}

	public void setCode(Code code) {
		
		if(this.shortCode == ShortCode.SSK && !codesSSK.contains(code))
			throw new IllegalArgumentException("Invalid argument");
		else if(this.shortCode == ShortCode.BAGKUR && !codesBagkur.contains(code))
			throw new IllegalArgumentException("Invalid argument");
		else if(this.shortCode == ShortCode.EMEKLI_SANDIGI && !codesEmekliSandigi.contains(code))
			throw new IllegalArgumentException("Invalid argument");
		
		this.code = code;
	}
}
