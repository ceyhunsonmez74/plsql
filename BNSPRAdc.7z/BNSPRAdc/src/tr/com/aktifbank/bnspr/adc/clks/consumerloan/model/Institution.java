package tr.com.aktifbank.bnspr.adc.clks.consumerloan.model;

/**
 * PTT kredileri icin kurum arayuz sinifi
 * 
 * @author kaan.yanc
 */
public interface Institution {
	
	public enum ShortCode {
		SSK(1), BAGKUR(3), EMEKLI_SANDIGI(2), PTT_PERSONEL(4), DIGER(6);
		
		private int code;
		
		ShortCode(int code) {
			this.code = code;
		}
		
		public static ShortCode getEnum(String code) {
			for(ShortCode v : values())
				if(v.toString().equalsIgnoreCase(code))
					return v;
			throw new IllegalArgumentException();
		}
		
		@Override
		public String toString() {
			return String.valueOf(code);
		}
	}
	
	public enum CampaignType {
		EMEKLI("E"), PTT("PTTPER"), DIGER("D");
		
		private String code;
		
		private CampaignType(String code) {
			this.code = code;
		}
		
		@Override
		public String toString() {
			return code;
		}
	}
	
	/**
	 * @return kurum kisa kodu - {@link ShortCode}
	 */
	public ShortCode getShortCode();
	
	/**
	 * 
	 * @return kurum kampanya tipi - {@link CampaignType}
	 */
	public CampaignType getCampaignType();
}

