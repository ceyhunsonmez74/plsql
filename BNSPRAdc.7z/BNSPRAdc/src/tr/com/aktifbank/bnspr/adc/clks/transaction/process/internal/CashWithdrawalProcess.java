package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CashWithdrawal;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class CashWithdrawalProcess extends TransactionBaseProcess<CashWithdrawal> implements
	TransactionProcess<CashWithdrawal> {

	public CashWithdrawalProcess(TransactionDao<CashWithdrawal> dao) {
		super(dao);
	}

	@Override
	public void request(CashWithdrawal transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(CashWithdrawal transaction) {
		super.confirm(transaction);
	}
}
