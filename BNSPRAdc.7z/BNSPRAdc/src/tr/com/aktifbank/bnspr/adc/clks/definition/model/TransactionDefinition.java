package tr.com.aktifbank.bnspr.adc.clks.definition.model;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.Map;


/**
 * 
 * @author kaan.yanc
 */
public interface TransactionDefinition {
		
	public Map<?,?> getReconciliationRecords(Date date, String listName) throws SQLException;
	public Map<?,?> getRecords(Date date, String listName) throws SQLException;
	public Map<?,?> getConfirmData(BigDecimal trxNo);
	public String reconciliationCode();
}
