package tr.com.aktifbank.bnspr.adc.clks.services;

import static tr.com.aktifbank.bnspr.clks.services.credit.ApplicationServices.getInstitutionPlaceCode;
import static tr.com.aktifbank.bnspr.clks.services.credit.ApplicationServices.getInstitutionType;

import java.math.BigDecimal;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.EnumSet;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionContext;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.CommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal.GMCacheCommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.CreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.internal.GMCreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal.DalCampaignDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal.DalCreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Campaign;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Campaign.CreditType;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Campaign.Relation;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Institution;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.InstitutionFactory;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.PensionPayment;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal.CreditApplicationBalanceTransferProcess;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal.CreditApplicationProcessImpl;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal.CreditApplicationRetireeProcessImpl;
import tr.com.aktifbank.bnspr.adc.clks.core.model.Branch;
import tr.com.aktifbank.bnspr.adc.clks.core.model.Region;
import tr.com.aktifbank.bnspr.adc.clks.core.model.Teller;
import tr.com.aktifbank.bnspr.adc.clks.customer.model.PersonalCustomer;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCreditPaymentDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CreditPayment;
import tr.com.aktifbank.bnspr.adc.dao.BaseDao;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruBarkod;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruBirlestirme;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruSmsTalep;
import tr.com.aktifbank.bnspr.dao.ClksPttMerkSubeKampiliski;
import tr.com.aktifbank.bnspr.dao.ClksSgkMaasBlokeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruTx;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.MuhBloke;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanApplicationServices {

	private static Logger logger = Logger.getLogger(ConsumerLoanApplicationServices.class);
	private final static String KANAL_KOD = "7";
	private final static CreditApplicationApi API = new GMCreditApplicationApi();
	private final static String SMS_APPLICATION_STATU_INITIAL = "I";
	private final static String SMS_APPLICATION_STATU_PENDING = "P";
	private final static String SMS_APPLICATION_STATU_APPROVED = "A";
	private final static String SMS_APPLICATION_STATU_TIMEOUT = "T";
	private final static String SMS_APPLICATION_STATU_DUPLICATED = "D";
	private final static String SMS_APPLICATION_STATU_SEND_READY = "SR";
	private final static String SMS_APPLICATION_STATU_SEND = "S";
	private final static String SMS_APPLICATION_STATU_USAGE_READY = "UR";
	private final static String SMS_APPLICATION_STATU_USAGE = "U";
	private final static String SMS_APPLICATION_STATU_USAGE_SEND = "US";
	private final static String SMS_APPLICATION_STATU_USAGE_COMPLETED = "UC";
	private final static String SMS_APPLICATION_STATU_FAIL = "F";
	private final static String PCH_STATU_YES = "E";
	private final static String PCH_STATU_NO = "H";
	private final static String SMS_CREDIT_STATU_REFUSED = "1";
	static long milisecondCountInADay = 86400000;

	



	/**
	 * PTT kanalindan baslatilan kredi basvurularinda kampanya kodu ile kurum bilgisini ve sube tanimini kontrol eder.
	 * Uyumsuzluk tespitinde {@link GMRuntimeException} firlatir, aksi durumda null {@code GMMap} nesnesi doner.
	 * TODO Sube kontrolu eklenmeli.
	 * 
	 * @param iMap {CAMPAIGN}
	 * @param iMap {KAMP_KNL_KOD}
	 * @param iMap {INSTITUTION_CODE}
	 * @param iMap {BRANCH_CODE}
	 * @param iMap {HEAD_BRANCH_CODE}
	 * 
	 * @throws GMRuntimeException		Uyumsuzluk tespitinde firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_CAMPAIGN_VALIDATION")
	public static GMMap campaignValidation(GMMap iMap) {
					
		try {
			
			Campaign campaign = new Campaign.Builder(iMap.getMap("CAMPAIGN").getBigDecimal("KOD"), 
				iMap.getBigDecimal("KAMP_KNL_KOD"))
					.accountBlockCode(iMap.getMap("CAMPAIGN").getString("KUL_BLOKE_KODU"))
					.allIncluded(iMap.getMap("CAMPAIGN").getBoolean("HERSEY_DAHIL_EH"))
					.balanceTransfer(iMap.getMap("CAMPAIGN").getBoolean("BORC_TRANSFERI_EH"))
					.publicCredit(iMap.getMap("CAMPAIGN").getBoolean("UCUNCU_SAHIS_EH"))
					.consolidation(iMap.getMap("CAMPAIGN").getBoolean("BIRLESTIRME_EH"))
					.visualImpairment(iMap.getMap("CAMPAIGN").getBoolean("GORME_ENGELLI_EH"))
					.consolidationOnChannel(iMap.getMap("CAMPAIGN").getBoolean("PTT_ICI_BIRLESTIRME_EH"))
					.creditType(Campaign.CreditType.getEnum(iMap.getMap("CAMPAIGN").getInt("KREDI_TURU")))
					.minTerm(iMap.getMap("CAMPAIGN").getInt("CLKS_MIN_VADE"))
					.maxTerm(iMap.getMap("CAMPAIGN").getInt("CLKS_MAX_VADE"))
					.minAmount(iMap.getMap("CAMPAIGN").getBigDecimal("CLKS_MIN_TUTAR"))
					.maxAmount(iMap.getMap("CAMPAIGN").getBigDecimal("CLKS_MAX_TUTAR")).build();
			
			if(campaign.getRelation() == null) {
				if("4".equals(iMap.getString("INSTITUTION_CODE"))) {
					campaign.setRelation(Campaign.Relation.PERSONNEL);
				} else {
					campaign.setRelation(Campaign.Relation.RETIREE);
				}
			}
			
			if(EnumSet.of(Campaign.Relation.PERSONNEL, Campaign.Relation.OTHER).contains(campaign.getRelation())
				&& !Arrays.asList("4", "6").contains(iMap.getString("INSTITUTION_CODE"))) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal.valueOf(660)).put("P1",
					"Se�ti�iniz kampanya, kredi ba�vurunuz ile uyumlu de�ildir. L�tfen uyumlu bir kampanya se�erek tekrar deneyin."));
			} else if(Campaign.Relation.RETIREE == campaign.getRelation()
				&& Arrays.asList("4", "6").contains(iMap.getString("INSTITUTION_CODE"))) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 561).put("P1",
					"Se�ti�iniz kampanya, kredi ba�vurunuz ile uyumlu de�ildir. L�tfen uyumlu bir kampanya se�erek tekrar deneyin."));
			}
			
			return new GMMap();
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_CAMPAIGN_VALIDATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kanalindan baslatilan kredi basvurularinda girdi olarak kullanimak uzere kampanya listesini doner.
	 * 
	 * @param iMap {BRANCH_ID*}					PTT Sube id
	 * @param iMap {INSTITUTION_SHORT_CODE}		Kurum K�sa Kodu
	 * @param iMap {CAMPAIGN_TYPE}				Kampanya Tipi
	 * 											<li>{@code "K"}: Diger Kredi</li>
	 * 											<li>{@code "B"}: Yapilandirma</li>
	 * @return 									Girdileri uygun <code>KAMPANYA_LISTESI=[{KAMPANYA_KODU,KAMPANYA_ADI}]</code> 
	 * 											formatinda {@code GMMap} nesnesi.
	 * 
	 * @see <a href="https://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRConsumerLoan/src/tr/com/calikbank/bnspr/consumerloan/services/ConsumerLoanTRN3171Services.java?r=425962">
	 * 		BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI</a>
	 * @see Institution
	 * @see InstitutionFactory
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_CAMPAIGN_LIST")
	public static GMMap campaignList(GMMap iMap) {

		GMMap oMap = new GMMap();
		ArrayList<GMMap> outCampaignList = new ArrayList<GMMap>();
		boolean relationExists = false;
		
		try {
			
			BaseDao<Campaign> dao = new DalCampaignDao();
			
			Session session = DAOSession.getSession("BNSPRDal");
			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("id.subeId", iMap.getString("BRANCH_ID"));
			
			if(iMap.get("INSTITUTION_SHORT_CODE") != null && !iMap.getString("INSTITUTION_SHORT_CODE").isEmpty()) {
				
				try {

					Institution institution = InstitutionFactory.getInstitution(Institution.ShortCode.getEnum(iMap
						.getString("INSTITUTION_SHORT_CODE")));
					restrictions.put("id.calismaSekliKod", institution.getCampaignType().toString());

				} catch(IllegalArgumentException e) {

					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 990).put("P1",
						String.format("(INSTITUTION_SHORT_CODE=%s)", iMap.getString("INSTITUTION_SHORT_CODE"))));
				}
				
			}
			
			@SuppressWarnings("unchecked")
			List<ClksPttMerkSubeKampiliski> campaignRelations = session.createCriteria(ClksPttMerkSubeKampiliski.class)
				.add(Restrictions.allEq(restrictions)).list();
			
			if(campaignRelations.size() == 0) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 990)
					.put("P1", String.format("(BRANCH_ID=%s)", iMap.getString("BRANCH_ID"))));
			}

			oMap = GMServiceExecuter.call("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", 
				new GMMap().put("KANAL_KODU", KANAL_KOD).put("DOVIZ_KODU", "TRY").put("KRD_TUR_KOD", 
					Campaign.CreditType.IHTIYAC_KREDISI.getCode()));
			
			// Populate credit campaign list
			if(oMap.containsKey(oMap.getString("LIST_NAME")) && oMap.get(oMap.getString("LIST_NAME")) instanceof List) {
				
				@SuppressWarnings("unchecked")
				List<HashMap<String,String>> campaigns = (ArrayList<HashMap<String,String>>) oMap.get(oMap.getString("LIST_NAME"));
				
				for(HashMap<String, String> map : campaigns) {
					
					if(map.get("VALUE") == null)
						continue;
					
					Campaign campaignModel = dao.get(new BigDecimal(map.get("VALUE")));
					
					// Yapilandirma
					if("B".equals(iMap.getString("CAMPAIGN_TYPE")) && !campaignModel.isConsolidation()) continue;
					
					// Diger Kredi
					else if("K".equals(iMap.getString("CAMPAIGN_TYPE")) && campaignModel.isConsolidation()) continue;

					relationExists = false;
					for(ClksPttMerkSubeKampiliski campaignRelation : campaignRelations) {
						if(campaignRelation.getId().getKampanyaKod().toString().equals(map.get("VALUE"))) {
							relationExists = true;
						}
					}
					
					if(relationExists) {
						outCampaignList.add(new GMMap().put("KAMPANYA_KODU",map.get("VALUE"))
							.put("KAMPANYA_ADI", map.get("NAME"))
							.put("BIRLESTIRME_EH", campaignModel.isConsolidation() ? "E":"H")
							.put("BORC_TRANSFERI_EH", campaignModel.isBalanceTransfer() ? "E":"H")
							.put("UCUNCU_SAHIS_EH", campaignModel.isPublicCredit() ? "E":"H")
							.put("PTT_ICI_BIRLESTIRME_EH", campaignModel.isConsolidationOnChannel() ? "E":"H")
							.put("GORME_ENGELLI_EH", campaignModel.isVisualImpairment() ? "E":"H"));
					}
				}
				
			} else {
				
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 990)
					.put("P1", String.format("(KANAL_KODU=%s,KRD_TUR_KOD=%s)", KANAL_KOD, 
						CreditType.IHTIYAC_KREDISI.toString())));
			}
			
			oMap.remove(oMap.getString("LIST_NAME"));
			oMap.remove("LIST_NAME");
			oMap.remove("ADD_EMPTY_KEY");
			oMap.put("KAMPANYA_LISTESI", outCampaignList);
			return oMap;
			
		} catch(Exception e) {
			
			logger.error("BNSPR_CLKS_CONSUMERLOAN_CAMPAIGN_LIST err: " + e);
			throw ExceptionHandler.convertException(e);
			
		}
	}
	
	/**
	 * Kredi kampanyasi ozelinde tutar ve vade kontrolu saglar.
	 * TODO Implement in Java
	 * 
	 * @param iMap {URUN_KAMP_KOD}	Kampanya kodu
	 * @param iMap {TUTAR}			Kredi tutari
	 * @param iMap {VADE}			Kredi vadesi
	 * @return  					Bos {@code GMMap} nesnesi.
	 * @throws GMRuntimeException	<li>Kampanya ozelinde tutar ve vade tanimi yok ise firlatilir.</li>
	 * 								<li>Sistem istinasinda firlatilir.</li>
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_AMOUNT_AND_TERM_CONTROL")
	public static GMMap amountAndTermControl(GMMap iMap) {
		
		try {
			
			DALUtil.callOracleProcedure("{call pkg_ptt_kredi.kampanya_tutar_vade_kontrol(?,?,?)}", new Object[]{
					BnsprType.NUMBER, iMap.getBigDecimal("URUN_KAMP_KOD"),
					BnsprType.NUMBER, iMap.getBigDecimal("TUTAR"),
					BnsprType.NUMBER, iMap.getBigDecimal("VADE")
				}, new Object[]{});
			
			return new GMMap();

		} catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_AMOUNT_AND_TERM_CONTROL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * Kredi basvurusuna iliskin yas kontrolu saglar.
	 * TODO Implement in Java
	 * 
	 * @param iMap {DOGUM_TARIHI}	Dogum tarihi
	 * @param iMap {VADE}			Kredi vadesi
	 * @param iMap {KAMP_KNL_KOD}	Kampanya kanal kodu
	 * @return  					Bos {@code GMMap} nesnesi.
	 * @throws GMRuntimeException	<li>Yas sebebi ile kontrole takilir ise firlatilir.</li>
	 * 								<li>Sistem istinasinda firlatilir.</li>
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_AGE_CONTROL")
	public static GMMap ageControl(GMMap iMap) {
		
		try {
			DALUtil.callOracleProcedure("{ call pkg_ptt_kredi.pttyaskontrol(?,?,?)}", new Object[]{
				BnsprType.DATE, iMap.getDate("DOGUM_TARIHI"),
				BnsprType.NUMBER, iMap.getBigDecimal("VADE"),
				BnsprType.NUMBER, iMap.getBigDecimal("KAMP_KNL_KOD")
			}, new Object[]{});
			
			return new GMMap();

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_AGE_CONTROL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * NBSM Initial ve/veya Final call'dan RED dondugu durumda red surecini isletir. RED basvuru icin nitelikli
	 * komisyon hesaplanip hesaplanmadigi bilgisini saglar.
	 * 
	 * @param iMap {BASVURU_NO}		Kredi basvuru numarasi
	 * @return 						Nitelikli {@code RED} kredi ise {@code F_NITELKIKLI_RED=E}, niteliksiz ise 
	 * 								{@code F_NITELKIKLI_RED=H} key/value iceren {@code GMMap} nesnesi.
	 * @throws GMRuntimeException	Sistem istisnasinda firlatilir.						
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_REJECT")
	public static GMMap applicationReject(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
			Application application = applicationDao.get(iMap.getBigDecimal("BASVURU_NO"));

			CreditApplicationProcess<Application> process = new CreditApplicationProcessImpl<Application>(
				applicationDao, API);
			process.applicationReject(application);
			
			oMap.put("F_NITELIKLI_RED", application.isQualifiedCommission() ? "E" : "H");
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_REJECT err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * PTT kredi basvuru surecine ait PTT onyuzu ilk ekran arkasinda tetiklenen servistir. Bu servis 
	 * sonrasinda NBSM I call cagirilir. 
	 * 
	 * @param iMap {KKB_SONUC_DATA}						PTT ici KKB verileri
	 * @param iMap {MAAS_BILGILERI}						Postaweb maas verileri
	 * @param iMap {SGK_AYLIK_BILGILERI}				SGK maas verileri
	 * @param iMap {SGK_SONUC_ACIKLAMA}					SGK entegrasyonu sonuc aciklama
	 * @param iMap {SGK_SONUC_KODU}						SGK entegrasyonu sonuc kodu
	 * @param iMap {TC_KIMLIK_NO}						TC kimlik numarasi
	 * @param iMap {UYRUK}								Ulke Kodu
	 * @param iMap {ADI}
	 * @param iMap {IKINCI_ADI}
	 * @param iMap {SOYADI}
	 * @param iMap {DOGUM_YERI}
	 * @param iMap {DOGUM_TARIHI}
	 * @param iMap {BABA_ADI}
	 * @param iMap {KIMLIK_SERI_NO}
	 * @param iMap {KIMLIK_SIRA_NO}
	 * @param iMap {ANNE_KIZLIK_SOYADI}
	 * @param iMap {CEP_TEL_KOD}
	 * @param iMap {CEP_TEL_NO}
	 * @param iMap {VADE}								Kredi vadesi
	 * @param iMap {TUTAR}								Kredi basvuru tutari
	 * @param iMap {DOVIZ_KOD}							
	 * @param iMap {ANNE_ADI}
	 * @param iMap {NUFUS_IL_KOD}
	 * @param iMap {NUFUS_ILCE_KOD}
	 * @param iMap {NUFUS_CILT_NO}
	 * @param iMap {NUFUS_AILE_SIRA_NO}
	 * @param iMap {NUFUS_SIRA_NO}
	 * @param iMap {NUFUS_VERILIS_TARIHI}
	 * @param iMap {CINSIYET}
	 * @param iMap {MEDENI_HAL}
	 * @param iMap {KAYIP_CUZDAN_NO}
	 * @param iMap {KAYIP_CUZDAN_SERI}
	 * @param iMap {KPS_YAPILDI}
	 * @param iMap {NUF_VERILIS_NEDENI}
	 * @param iMap {NUF_VERILDIGI_YER}
	 * @param iMap {NUFUS_MAHALLE}
	 * @param iMap {KIMLIK_KAYIT_NO}
	 * @param iMap {KRD_TUR_KOD}
	 * @param iMap {KRD_TUR_ALT_KOD}
	 * @param iMap {ISLEMI_YAPAN_KULLANICI}
	 * @param iMap {ISLEMI_YAPANKULLANICI_ADSOYAD}
	 * @param iMap {ISLEMIN_YAPILDIGI_YER}
	 * @param iMap {ISLEMIN_YAPILDIGI_IL}
	 * @param iMap {ISLEM_NO_BANKA}
	 * @param iMap {BASVURU_NO}
	 * @param iMap {SESSION_IP}
	 * @param iMap {URUN_KAMP_KOD}
	 * @param iMap {KIMLIK_SERI_NO_KPS}
	 * @param iMap {KIMLIK_SIRA_NO_KPS}
	 * @param iMap {CALISMA_SEKLI}
	 * @param iMap {SIGORTALIMI}
	 * @param iMap {GUNCELLEMEMI}
	 * @param iMap {POSTA_CEK_HESABI}
	 * @param iMap {ISLEMIN_YAPILDIGI_MERKEZ}
	 * @param iMap {ISLEMIN_YAPILDIGI_SUBE}
	 * @param iMap {MERKEZ_SUBE_BASMUDURLUK}
	 * @param iMap {ISLEMIN_YAPILDIGI_BASMUDURLUK}
	 * @param iMap {EK_DOKUMAN}
	 * @param iMap {IBAN}
	 * @param iMap {BORC_BANKA_KODU}
	 * @param iMap {BORC_SUBE_KODU}
	 * @param iMap {F_HESAP_KAPAMA}
	 * @param iMap {F_CEP_TEL_VALIDASYON}				{@code String} Cep telefonu validasyonu yapilacak ise {@code "E"}, 
	 * 													aksi durumda {@code "H"}
	 * @param iMap {F_IPAZ}								{@code boolean} IPAZ
	 * @param iMap {F_CRS}								{@code boolean} CRS
	 * @param iMap {KAMPANYA}							{@code GMMap} nesnesi icinde kampanya bilgileri
	 * 
	 * @return
	 * @throws GMRuntimeException
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_REQUEST")
	public static GMMap applicationRequest(GMMap iMap) {
		
		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();
		
		try {
			
			if(map.get("BASVURU_NO") == null || map.getString("BASVURU_NO").isEmpty()) {
				map.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", new GMMap())
					.getBigDecimal("ID"));
			}
			
			Campaign campaign = new Campaign.Builder(map.getMap("KAMPANYA").getBigDecimal("KOD"), 
				map.getBigDecimal("KAMP_KNL_KOD"))
					.accountBlockCode(map.getMap("KAMPANYA").getString("KUL_BLOKE_KODU"))
					.allIncluded(map.getMap("KAMPANYA").getBoolean("HERSEY_DAHIL_EH"))
					.balanceTransfer(map.getMap("KAMPANYA").getBoolean("BORC_TRANSFERI_EH"))
					.publicCredit(map.getMap("KAMPANYA").getBoolean("UCUNCU_SAHIS_EH"))
					.consolidation(map.getMap("KAMPANYA").getBoolean("BIRLESTIRME_EH"))
					.visualImpairment(map.getMap("KAMPANYA").getBoolean("GORME_ENGELLI_EH"))
					.consolidationOnChannel(map.getMap("KAMPANYA").getBoolean("PTT_ICI_BIRLESTIRME_EH"))
					.creditType(Campaign.CreditType.getEnum(map.getMap("KAMPANYA").getInt("KREDI_TURU")))
					.relation(Relation.OTHER)
					.minTerm(map.getMap("KAMPANYA").getInt("CLKS_MIN_VADE"))
					.maxTerm(map.getMap("KAMPANYA").getInt("CLKS_MAX_VADE"))
					.minAmount(map.getMap("KAMPANYA").getBigDecimal("CLKS_MIN_TUTAR"))
					.maxAmount(map.getMap("KAMPANYA").getBigDecimal("CLKS_MAX_TUTAR")).build();
			
			PersonalCustomer customer = new PersonalCustomer(null, map.getString("TC_KIMLIK_NO"));
			customer.setBirthDate(map.getDate("DOGUM_TARIHI"));
			
			Application application = new Application(map.getBigDecimal("BASVURU_NO"), map.getString("TC_KIMLIK_NO"),
				map.getBigDecimal("TUTAR"), map.getInt("VADE"), campaign);
			application.setIpaz(map.getBoolean("F_IPAZ"));
			application.setCrs(map.getBoolean("F_CRS"));
			application.setMobilePhone(map.getString("CEP_TEL_KOD", "").concat(map.getString("CEP_TEL_NO", "")));
			application.setCustomer(customer);
			
			CreditApplicationProcess<Application> process = new CreditApplicationProcessImpl<Application>(
				new DalCreditApplicationDao(), API);
			Map<?, ?> response = process.applicationRequest(application, "E".equals(map.getString("F_CEP_TEL_VALIDASYON")));

			if(response.get("RESPONSE") != null && !"2".equals(response.get("RESPONSE"))) {
				return new GMMap(response);
			}
			
			if(map.containsKey("SGK_SONUC_KODU") && map.get("SGK_SONUC_KODU") != null) {
				GMServiceExecuter.executeNT("BNSPR_CLKS_CREDIT_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG", map.put("REQUEST_TYPE",
					"aylikSorgula"));
			}
			
			// TODO Bu logic ApplicationProcess'e tasinacak
			if(campaign.isBalanceTransfer()) {
				map.putAll(GMServiceExecuter.call("BNSPR_CLKS_CREDIT_SELECT_SGK_PENSION", map));
				map.put("TAHSIS_NUMARASI", ((PensionPayment) map.get("PENSION_PAYMENT")).getAllocationNumber());
			}
			
			GMServiceExecuter.call("BNSPR_CLKS_CREDIT_CHECK_CAMPAIGN_RULES", map);
			GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", map.put("KONTROL_SAVE_OR_UPDATE", "1"));
			GMServiceExecuter.call("BNSPR_TRN3171_CHECK_FAIZ_ORANI", map);
			GMServiceExecuter.call("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU", map);
			GMServiceExecuter.call("BNSPR_TRN3171_BASVURU_KAMPANYA_KONTROL", map);
			
			application.setTrxNo(map.getBigDecimal("TRX_NO"));
			
			GMMap katkiPayiMap = GMServiceExecuter.call("BPM_GET_KATKIPAYI", map);
			map.put("SERBEST_KATKI_PAYI", katkiPayiMap.get("SERBEST_KATKI_PAYI"));
			map.put("SERBEST_KATKI_ORAN", katkiPayiMap.get("SERBEST_KATKI_ORAN"));
			map.put("MIN_KATKI_PAYI", katkiPayiMap.get("MIN_KATKI_PAYI"));
			map.put("MAX_KATKI_PAYI", katkiPayiMap.get("MAX_KATKI_PAYI"));
			map.put("KATKI_PAYI_KIMDEN", katkiPayiMap.get("KATKI_PAYI_KIMDEN"));
			map.put("KATILIM_BEDELI", katkiPayiMap.get("MAX_KATKI_PAYI"));
			
			GMMap faizTanimiMap = GMServiceExecuter.call("BPM_DOSYA_MASRAF_FAIZ_TANIMI", map);
			map.put("FAIZ_ORANI", faizTanimiMap.get("FAIZ_ORAN"));
			map.put("SOZLESME_FAIZI", faizTanimiMap.get("SOZLESME_ORANI"));
			map.put("KATILIM_BEDELI", faizTanimiMap.get("MAX_KATKI_PAYI"));
			map.put("DOSYA_MASRAFI", faizTanimiMap.get("MAX_DOSYA_MASRAFI")); 

			GMMap herseyDahilMap = GMServiceExecuter.call("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", map);
			map.put("KREDI_TUTARI", herseyDahilMap.getBigDecimal("HERSEY_DAHIL_TUTAR"));	
			
			GMMap odemeGrupMap = GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", new GMMap().put(
				"KAMP_URUN_ADI", campaign.getCode()));
			map.put("ODEME_TIPI", odemeGrupMap.get("DEFAULT_ODEME_TIP"));
			if(odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MIN_VADE") != null) {
				map.put("ODEME_VADESI", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MIN_VADE"));
			}
			
			// Varsayilan: Taksitlere dagit
			map.put("PTT_ILK_TAKSIT_YONTEM", map.getMap("KAMPANYA").getBoolean("F_PESIN") ? "0" : map.getMap(
				"KAMPANYA").getBoolean("F_ILK_TAKSITTE_AL") ? "1" : map.getMap("KAMPANYA").getBoolean(
				"F_TAKSITLERE_DAGIT") ? "2" : map.getMap("KAMPANYA").getBoolean("F_HIC_ALMA") ? "3" : "2");		
			
			GMServiceExecuter.call("BNSPR_TRN3171_APS_SORGULAMA", new GMMap().put("TC_KIMLIK_NO",
				map.getString("TC_KIMLIK_NO")).put("TRX_NO", map.getBigDecimal("TRX_NO")));
			GMMap trxMap = GMServiceExecuter.call("BNSPR_TRN3171_SAVE_TEMP", map.put("EKRAN_NO", "3171"));
			map.put("MUSTERI_NO", trxMap.get("MUSTERI_NO"));
			
			GMServiceExecuter.call("BNSPR_TRN3171_UPDATE_MUSTERI_NO", map);
						
			// TODO Bu logic ApplicationProcess'e tasinacak
			if(campaign.isBalanceTransfer()) {
				oMap.put("NBSM_TAHSIS_NUMARASI", map.get("TAHSIS_NUMARASI"));
				oMap.put("SIGORTA_KOLU", ((PensionPayment) map.get("PENSION_PAYMENT")).getInstitution()
					.getInsuranceChannel().toString());
			}
			
			for (Iterator<?> iterator = response.entrySet().iterator(); iterator.hasNext();) {
				
				@SuppressWarnings("unchecked")
				Entry<String, Object> entry = (Entry<String, Object>) iterator.next();
				
				oMap.put(entry.getKey(), entry.getValue());
			}
			

			String crsInfo = API.crsInfo(application.getNationalIdentificationNumber());
			
			if(!"E".equals(crsInfo) && application.isCrs()) {
				API.updateCrsInfo(application.getNationalIdentificationNumber(), application.isCrs());
				crsInfo = "E";
				oMap.put("MESSAGE", API.message(5930));
			} else if("E".equals(crsInfo)) {
				oMap.put("MESSAGE", API.message(5927));
			}
			
			if("E".equals(crsInfo)) {
				API.rejectApplication(application.getApplicationNo(), application.getTrxNo(),
					Application.STATUS.BASVURU.toString(), "48");
				application.setStatus(Application.STATUS.RED);
			}
			
			oMap.put("DURUM", application.getStatus().toString());
			oMap.put("MUSTERI_NO", map.get("MUSTERI_NO"));
			oMap.put("ISLEM_NO_BANKA", map.get("TRX_NO"));
			oMap.put("TRX_NO", map.get("TRX_NO"));
			oMap.put("BASVURU_NO", map.get("BASVURU_NO"));
			oMap.put("FAIZ_ORANI", map.get("SOZLESME_FAIZ_ORANI"));
			oMap.put("SERBEST_KATKI_PAYI", map.get("SERBEST_KATKI_PAYI"));
			oMap.put("SERBEST_KATKI_ORAN", map.get("FAIZ_ORANI"));
			oMap.put("MAX_KATKI_PAYI", map.get("MAX_KATKI_PAYI") != null ? map.get("MAX_KATKI_PAYI") : 0);
			oMap.put("MIN_KATKI_PAYI", map.get("MIN_KATKI_PAYI") != null ? map.get("MIN_KATKI_PAYI") : 0);
			oMap.put("KATKI_PAYI_KIMDEN", map.get("KATKI_PAYI_KIMDEN"));
			oMap.put("RESPONSE","2");
			
			return oMap;
			
		} catch(Exception e) {

			logger.error("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_REQUEST err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * PTT kredi basvuru surecine ait PTT onyuzu ikinci ekran arkasinda tetiklenen ilk servistir.
	 * 
	 * @param iMap {ISLEM_NO_BANKA}
	 * @param iMap {BASVURU_NO}
	 * @param iMap {...}								...
	 * @param iMap {KAMPANYA}							{@code GMMap} tipinde kampanya bilgileri
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_REQUEST_UPDATE")
	public static GMMap applicationRequestUpdate(GMMap iMap) {

		GMMap oMap = new GMMap(), map = (GMMap) iMap.clone();
		
		try {
			
			map.put("TRX_NO", map.getBigDecimal("ISLEM_NO_BANKA"));
			
			GMMap requestMap = GMServiceExecuter.call("CLKS_PTT_KREDI_LIST_FIRST_INITIAL_INFO", map);
			map.putAll(requestMap);
			map.put("KANAL_KOD", requestMap.get("KANAL_KODU"));
			
			GMMap odemeGrupMap = GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", new GMMap().put(
				"KAMP_URUN_ADI", requestMap.getString("KAMP_KOD")));
			map.put("ODEME_TIPI", odemeGrupMap.get("DEFAULT_ODEME_TIP"));
			if(odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MIN_VADE") != null) {
				map.put("ODEME_VADESI", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MIN_VADE"));
			}
			
			//BNSPR_TRN3171_CONTROL servisine artan �demeli ile gelen 2 yeni input. 
			map.put("ODEME_ORANI", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MAX_ORAN"));
			map.put("ODEME_PERIYODU", odemeGrupMap.get("ODEME_TIP_TABLE", 0, "MAX_PERIYOD")); 
			
			GMMap faizTanimiMap = GMServiceExecuter.call("BPM_DOSYA_MASRAF_FAIZ_TANIMI", new GMMap()
				.put("KAMP_URUN_ADI", requestMap.getBigDecimal("KAMP_KOD"))
				.put("TUTAR", requestMap.getBigDecimal("HERSEY_DAHIL_TUTAR"))
				.put("VADE", requestMap.getBigDecimal("VADE"))
				.put("KANAL_KOD", requestMap.getBigDecimal("KANAL_KODU"))
				.put("DOVIZ_KOD", requestMap.getString("DOVIZ_KOD"))
				.put("KRD_TUR_KOD", requestMap.getBigDecimal("KRD_TUR_KOD")));
			map.put("DOSYA_MASRAFI", faizTanimiMap.get("MAX_DOSYA_MASRAFI")); 
			
			try {
				if(map.get("AYLIK_GELIR") != null && Integer.valueOf(map.get("AYLIK_GELIR").toString()) >= 0) {
					return new GMMap().put("RESPONSE", 4).put(
						"RESPONSE_DATA",
						GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE",
							new GMMap().put("MESSAGE_NO", BigDecimal.valueOf(2035))).getString("ERROR_MESSAGE"));
				}
			} catch(Exception e) {
				logger.error("BNSPR_CLKS_CREDIT_APPLICATION_REQUEST_UPDATE err:", e);
				return new GMMap().put("RESPONSE", 4).put(
					"RESPONSE_DATA",
					GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE",
						new GMMap().put("MESSAGE_NO", BigDecimal.valueOf(2035))).getString("ERROR_MESSAGE"));
			}
			
			GMServiceExecuter.call("BNSPR_TRN3171_CONTROL", map);
			GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", map.put("KONTROL_SAVE_OR_UPDATE", "2"));
			
			oMap.put("BASVURU_NO", map.get("BASVURU_NO"));
			oMap.put("ISLEM_NO_BANKA", map.get("ISLEM_NO_BANKA"));
			oMap.put("DEVAM", "E");
			oMap.putAll(GMServiceExecuter.call("CLKS_PTT_GET_INITIAL_REQUEST_OUT_DATA", new GMMap().put("BASVURU_NO",
				map.getBigDecimal("BASVURU_NO"))));
			
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_TEMINATLAR", oMap));
			for(int i = 0; i < oMap.getSize("TEMINAT_LIST"); i++) {
				oMap.put("TEMINAT_ADI", DALUtil.getResult("select pkg_genel_pr.Teminat_Adi('" + oMap.getString("TEMINAT_LIST", i, "TEMINAT") + "') from dual"));
				oMap.put("TEMINAT_LIST", i, "TEMINAT_ADI", oMap.getString("TEMINAT_ADI"));
			}
			
			return oMap;
			
		} catch(Exception e) {
	
			logger.error("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_REQUEST_UPDATE err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}	

	/**
	 * PTT kredi basvuru surecine ait PTT onyuzu ikinci ekran arkasinda tetiklenen ikinci/son servistir. NBSM F call 
	 * cagrisi yapilir.
	 * 
	 * @param iMap {ISLEM_NO_BANKA}
	 * @param iMap {BASVURU_NO}
	 * @param iMap {KIMLIK_BILGILERI_UYUMLUMU}
	 * @param iMap {ADRES_BILGILERI_UYUMLUMU}
	 * @param iMap {GUNCELLEMEMI}
	 * @param iMap {EV_ADRES_APS}
	 * @param iMap {EV_ADR_IL_KOD_APS}
	 * @param iMap {EV_ADR_ILCE_KOD_APS}
	 * @param iMap {TEMINAT_TABLE}
	 * @param iMap {APS_YAPILDIMI}
	 * @param iMap {TEYIT_EDILEN_GELIR}
	 * @param iMap {KAMPANYA}							{@code GMMap} tipinde kampanya bilgileri
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_CONFIRM")
	public static GMMap applicationConfirm(GMMap iMap) {

		GMMap oMap = new GMMap(), statusUpdateMap = new GMMap(), map = (GMMap) iMap.clone();
		BigDecimal teyitEdilenGelir = BigDecimal.ZERO;
		
		try {
			
			map.put("TRX_NO", map.getBigDecimal("ISLEM_NO_BANKA"));
			map.put("ISLEM_KODU", "3171");
			
			GMServiceExecuter.call("CLKS_PTT_KREDI_SAVE_OR_UPDATE", map.put("KONTROL_SAVE_OR_UPDATE", "3"));

			if(map.get("TEYIT_EDILEN_GELIR") != null && !map.getString("TEYIT_EDILEN_GELIR").isEmpty()
				&& !BigDecimal.ZERO.equals(map.getBigDecimal("TEYIT_EDILEN_GELIR"))) {
				teyitEdilenGelir = map.getBigDecimal("TEYIT_EDILEN_GELIR");
			}

			GMMap requestMap = GMServiceExecuter.call("CLKS_PTT_KREDI_LIST_FIRST_INITIAL_INFO", map);
			requestMap.putAll(GMServiceExecuter.call("CLKS_PTT_KREDI_LIST_INITIAL_INFO", map));
			map.putAll(requestMap);
			map.put("KANAL_KOD", requestMap.get("KANAL_KODU"));

			if("Y".equals((String) DALUtil
				.callOracleFunction("{? = call pkg_nbsm_7rsl.get_prev_nbsm_output_value(?,?,?)}", BnsprType.STRING,
					BnsprType.NUMBER, map.getBigDecimal("BASVURU_NO"), BnsprType.STRING, "I", BnsprType.STRING,
					"InitialStrategyADKIncYNReq"))
				&& BigDecimal.ZERO.equals(teyitEdilenGelir)
				&& BigDecimal.ZERO.equals(map.getBigDecimal("TEYIT_EDILEN_GELIR"))) {
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 561).put("P1",
					"Teyit edilen gelir"));
			}

			map.put("TEYIT_EDILEN_GELIR", BigDecimal.ZERO.equals(teyitEdilenGelir) ? map.get("TEYIT_EDILEN_GELIR")
				: teyitEdilenGelir);

			GMServiceExecuter.executeNT("BNSPR_TRN3171_CONTROL", map);
			GMMap gonderSorgularMap = GMServiceExecuter.call("BNSPR_TRN3171_GONDER_SORGULAR", map);
			oMap.putAll(gonderSorgularMap);
			//oMap.putAll(GMConnection.getConnection("UAT").serviceCall("BNSPR_TRN3171_GONDER_SORGULAR", map));

			// Case: Basvuru Onay
			if("E".equals(oMap.getString("DEVAM"))) {
				GMServiceExecuter.call("BNSPR_TRN3171_SAVE", map); 
			}
			
			GMMap bayiBilgileriMap = GMServiceExecuter.call("BNSPR_TCK_NO_GET_BAYI_BILGILERI", new GMMap().put(
				"TCK_NO", map.getString("TC_KIMLIK_NO")));

			statusUpdateMap.put("MUSTERI_NO", bayiBilgileriMap.getString("MUSTERI_NO"));
			statusUpdateMap.put("TC_KIMLIK_NO", map.getString("TC_KIMLIK_NO"));
			statusUpdateMap.put("KPS_YAPILDI", map.getString("KPS_YAPILDI"));
			statusUpdateMap.put("PTT_PERSONEL_MI", map.getString("PTT_PERSONEL_MI"));
			statusUpdateMap.put("MAAS_ALINAN_KURUM", map.getString("MAAS_ALINAN_KURUM"));
			statusUpdateMap.put("BASVURU_NO", map.getString("BASVURU_NO"));
			if(bayiBilgileriMap.getString("MUSTERI_NO") == null || bayiBilgileriMap.getString("MUSTERI_NO").compareTo("") == 0) {
				statusUpdateMap.putAll(GMServiceExecuter.call("CLKS_PTT_KONTAKT_MUSTERI_YARATMA", map));
			} else if(bayiBilgileriMap.getString("MUSTERI_KONTAKT") != null && bayiBilgileriMap.getString("MUSTERI_KONTAKT").compareTo("K") == 0) {
				statusUpdateMap.putAll(GMServiceExecuter.call("CLKS_PTT_KONTAKT_MUSTERI_GUNCELLEME_DATA", map));
				statusUpdateMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", statusUpdateMap));
			}

			GMServiceExecuter.call("BNSPR_TRN3171_STATU_GUNCELLE", statusUpdateMap);
			
			API.sendApplicationText(map.getBigDecimal("TRX_NO") == null ? map.getBigDecimal("ISLEM_NO") : map
				.getBigDecimal("TRX_NO"), map.getString("ISLEM_KODU"));

			CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
			Application application = applicationDao.get(iMap.getBigDecimal("BASVURU_NO"));
			
			CreditApplicationProcess<Application> process = new CreditApplicationProcessImpl<Application>(
				applicationDao, API);
			process.applicationConfirm(application);
			process.applicationAfterConfirm(application, gonderSorgularMap);
			
			oMap.put("VADE_FARK_FAIZI", "0".equals(map.getString("PTT_ILK_TAKSIT_YONTEM")) ? map.get("FARK_FAIZ")
				: BigDecimal.ZERO);
			oMap.put("TC_KIMLIK_NO", map.get("TC_KIMLIK_NO"));
			oMap.put("ISLEM_NO_BANKA", map.get("ISLEM_NO_BANKA"));
			oMap.putAll(GMServiceExecuter.call("CLKS_PTT_GET_CONFIRM_OUT_DATA", map));
			
			return oMap;
			
		} catch(Exception e) {
	
			logger.error("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_CONFIRM err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kanal�ndan ger�ekle�tirilen kredi ba�vurusunun kulland�r�m�nda �a��r�l�r. Bu servis sonras�nda s�re� ba�ar� 
	 * ile sonlan�r ise kredi ba�vurusunun durumu <code>EVRAKSIZ</code> olarak g�ncellenir ve kredi tutar� m��terinin
	 * hesab�na ge�er. 
	 * 
	 * @param iMap	GMMap {...}
	 * @return		...
	 * 
	 * @see 		#ClksPTTCreditSaveorUpdate(GMMap) CLKS_PTT_KREDI_SAVE_OR_UPDATE
	 * @see			...
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_CONTRACTUAL_REQUEST")
	public static GMMap contractualRequest(GMMap iMap) {

		try {
			
			// Durum Kontrol
			DALUtil.callOracleProcedure("{call PKG_TRN3181.DURUM_KONTROL(?)}", new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")}, new Object[]{});
			
			CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
			Application application = applicationDao.get(iMap.getBigDecimal("BASVURU_NO"));
			
			Branch branch = new Branch(iMap.getString("ISLEMIN_YAPILDIGI_SUBE_EVRAK"), new Branch(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ_EVRAK"), null));
			branch.setProvinceCode(iMap.getString("ISLEMIN_YAPILDIGI_IL_EVRAK"));
			branch.setRegion(new Region(null, iMap.getString("ISLEMIN_YAPILDIGI_BASMUDURLUK_EVRAK")));
			
			application.setTrxNoDocumentProcessing(iMap.getBigDecimal("ISLEM_NO_BELGE"));
			application.setTeller(new Teller(iMap.getString("ISLEMI_YAPAN_KULLANICI_EVRAK"), null));
			application.setBranch(branch);
			application.setBarcode(iMap.getString("BARKOD_NUMARASI"));
			application.setContractualRequestapprovedApproved("H".equals(iMap.getString("SORUN_VARMI")) ? true : false);
			application.setStatus(Application.STATUS.BELGE);
			applicationDao.save(application);

			List<Map<?,?>> documents = new ArrayList<Map<?,?>>();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			for (int i = 0; i < iMap.getSize("BELGE_LISTESI"); i++) {
				
				if(!Arrays.asList("-1", "101", "102").contains(iMap.getString("BELGE_LISTESI", i, "evrakKodu"))) {

					Map<String, Object> documentMap = new HashMap<String, Object>();
					documentMap.put("BASVURU_NO", application.getApplicationNo());
					documentMap.put("BELGE_KOD", iMap.getBigDecimal("BELGE_LISTESI", i, "evrakKodu"));
					documentMap.put("BELGE_KODU", iMap.getBigDecimal("BELGE_LISTESI", i, "evrakKodu"));
					documentMap.put("BELGE_ADI", iMap.getString("BELGE_LISTESI", i, "evrakAdi"));
					documentMap.put("ALINDI",iMap.getString("BELGE_LISTESI", i, "evrakTeslimEdilmismi"));
					documentMap.put("ISLEM_TARIHI", formatter.parse(formatter.format(new Date())));
					documentMap.put("KIMDEN_KOD", "M");
					documentMap.put("KIMDEN", "M");
					documentMap.put("BELGE_KONTROL", "5");
					documentMap.put("BARKOD_NUMARASI", application.getBarcode());
					documents.add(documentMap);
				}
			}
			
			CreditApplicationProcess<Application> process = null;
			
			if(application.getCampaign().getRelation() == Relation.RETIREE) {
				
				// Case: Kullandirim - SGK Online Kontrolleri
				if(!"E".equals(iMap.getString("EKRAN"))) {
					
					// Dosya masrafi degisikligi var ise, m��teri sozlemeye yonlendirilecek
					GMServiceExecuter.call("BNSPR_TRN3132_CHECK_KATKIPAYI_DOSYAMASRAFI", iMap);
					
					GMMap logMap = new GMMap();
					logMap.put("SGK_AYLIK_BILGILERI", iMap.get("SGK_AYLIK_BILGILERI"));
					
					// SGK Online Bloke Loglama
					// TODO Async
					GMServiceExecuter.executeAsync("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG", logMap
						.put("REQUEST_TYPE","aylikBlokeKoy")
						.put("TAHSIS_NUMARASI", iMap.getString("TAHSIS_NUMARASI"))
						.put("SIGORTA_KOLU", iMap.getString("SIGORTA_KOLU"))
						.put("BASVURU_NO", iMap.getString("BASVURU_NO"))
						.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"))
						.put("SGK_SONUC_KODU", iMap.getString("SGK_BLOKE_SONUC_KODU"))
						.put("SGK_SONUC_ACIKLAMA", iMap.getString("SGK_BLOKE_SONUC_ACIKLAMA")));
					
					// SGK Online Bildirim Loglama
					// TODO Async
					GMServiceExecuter.executeAsync("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG", logMap.put("REQUEST_TYPE",
						"aylikSorgula"));

					iMap.putAll(GMServiceExecuter.call("CLKS_BASVURU_EMEKLI_SGK_AYLIK_GETIR", iMap.put(
						"SGK_KONTROL_TIP", 2)));
					
					// SGK Online Bildirim Kontrol
					GMServiceExecuter.call("BNSPR_CLKS_CREDIT_PENSION_SGK_VALIDATION", iMap);
				}
				
				process = new CreditApplicationRetireeProcessImpl(applicationDao, API);
				
			} else if(application.getCampaign().isBalanceTransfer()) {
				process = new CreditApplicationBalanceTransferProcess(applicationDao, API);
			} else {
				process = new CreditApplicationProcessImpl<Application>(applicationDao, API);
			}
			
			Map<?, ?> processMap = null;
			if(Arrays.asList("B","S").contains(iMap.getString("EKRAN"))) {
				processMap = process.contractualRequest(application, documents);
				
				if(application.getStatus() == Application.STATUS.RED) {
					return new GMMap(processMap);
				}
				
			} else if("E".equals(iMap.getString("EKRAN"))) {
				processMap = process.resendDocuments(application, documents);
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			ClksBirBasvuruBarkod clksBirBasvuruBarkod = (ClksBirBasvuruBarkod) session.get(ClksBirBasvuruBarkod.class, application.getBarcode());
			
			if(clksBirBasvuruBarkod != null) {
				clksBirBasvuruBarkod.setBarkodKullanildimi("E");
				clksBirBasvuruBarkod.setIslemTarihi(new Date());
				clksBirBasvuruBarkod.setIslemYapanSicilNo(application.getTeller().getRecord());
				clksBirBasvuruBarkod.setIslemYapilanSube(application.getBranch().getBranchCode());
				clksBirBasvuruBarkod.setIslemYapilanMerkez(application.getBranch().getHeadBranchCode());
				clksBirBasvuruBarkod.setIsleminYapildigiIl(application.getBranch().getProvinceCode());
				session.saveOrUpdate(clksBirBasvuruBarkod);
				session.flush();
			}
			
			return new GMMap(processMap);

		} catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_CONTRACTUAL_REQUEST err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT kanalinda kullandirim odemesi tamamlanmamis kredilerin, kullandirimlarini iptal eder, basvurunun durumunu 
	 * {@code SOZLESME} olarak gunceller. 
	 * 
	 * @param iMap {BASVURU_NO}		Kredi basvuru numarasi
	 * @param iMap {TX_NO}			Islem numarasi
	 * @param iMap {YENI_DURUM}		Iptal sonras� yeni basvuru durumu
	 * @param iMap {ACIKLAMA}		Basvuru durum guncelleme aciklamasi
	 * @return						Bos {@code GMMap} nesnesi
	 * @throws	GMRuntimeException	<li>Bagimli servislerdeki istisnalar firlatilir.</li>
	 * 								<li>Sistem istisnasinda firlatilir.</li>
	 * @see BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA
	 * @see BNSPR_TRN3198_SAVE
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_REVERT_PENDING_APPLICATION")
	public static GMMap revertPendingApplication(GMMap iMap) {
		
		String islemIptal = "I", aciklama = "PTT - �demesi Tamamlanmam�� Kulland�r�m", gerekceKod = "5";
		BigDecimal ekranKod = new BigDecimal(3132); //3182
		
		try {
			
			CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
			Application application = applicationDao.get(iMap.getBigDecimal("BASVURU_NO"));
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirKullandirim kullandirim = (BirKullandirim) session.get(BirKullandirim.class, application.getApplicationNo());
			
			Map<String,Object> restrictions = new HashMap<String, Object>();
			restrictions.put("hesapNo", kullandirim.getAlacHesapNo());
			restrictions.put("durumKodu", "A");
			restrictions.put("blokeNedenKodu", application.getCampaign().getAccountBlockCode());
			
			MuhBloke bloke = (MuhBloke) session.createCriteria(MuhBloke.class).add(Restrictions.allEq(restrictions))
				.setFirstResult(0).setMaxResults(1).uniqueResult();
			
			if(bloke != null) {
				
				BigDecimal netAmount = kullandirim.getKrdTutarTl().subtract(
					kullandirim.getDosyaMasraf() == null ? BigDecimal.ZERO : kullandirim.getDosyaMasraf()).subtract(
					kullandirim.getBayiKom() == null ? BigDecimal.ZERO : kullandirim.getBayiKom()).subtract(
					kullandirim.getMusKom() == null ? BigDecimal.ZERO : kullandirim.getMusKom()).subtract(
					kullandirim.getFarkFaiz() == null ? BigDecimal.ZERO : kullandirim.getFarkFaiz()).subtract(
					kullandirim.getKrediSigPrim() == null ? BigDecimal.ZERO : kullandirim.getKrediSigPrim());
				
				DALUtil.callOracleProcedure("{ call pkg_hesap.bloketutariguncelle(?,?,?)}", new Object[]{BnsprType.NUMBER,
					kullandirim.getAlacHesapNo(), BnsprType.NUMBER, netAmount.negate(), BnsprType.STRING,
					application.getCampaign().getAccountBlockCode()}, new Object[]{});
				
				bloke.setDurumKodu("K");
				bloke.setCozKayitTarih(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate(
					"BANKA_TARIH"));
				bloke.setCozKayitSistemTarih(new Date());
				bloke.setCozKayitKullaniciKodu((String) DALUtil.callNoParameterFunction(
					"{? = call pkg_global.GET_KULLANICIKOD}", Types.VARCHAR));
				bloke.setCozOnayKullaniciBolumKodu((String) DALUtil.callNoParameterFunction(
					"{? = call pkg_global.GET_SUBEKOD}", Types.VARCHAR));
				session.saveOrUpdate(bloke);
				session.flush();
			}
			
			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", new GMMap()
				.put("ISLEM_TURU", islemIptal)
				.put("ISLEM_NO", iMap.getBigDecimal("TX_NO"))
				.put("ISLEM_KODU", ekranKod)
				.put("ACIKLAMA", aciklama));
			
			application = applicationDao.get(application.getApplicationNo());
			
			logger.info(String.format("BNSPR_CLKS_CONSUMERLOAN_REVERT_PENDING_APPLICATION > %s", application.toString()));
			
			GMServiceExecuter.call("BNSPR_TRN3198_SAVE", new GMMap()
				.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"))
				.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"))
				.put("ESKI_DURUM_KODU", Application.STATUS.KUL.toString())
				.put("YENI_DURUM_KODU", iMap.getString("YENI_DURUM", Application.STATUS.SOZLESME.toString())) 
				.put("GEREKCE", gerekceKod)
				.put("ACIKLAMA", iMap.getString("ACIKLAMA", aciklama)));
			
			return new GMMap();

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_REVERT_PENDING_APPLICATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT ici Birlestirme Kredisi manuel surecte KKB entegrasyonu ile baska bankada kredi riski olup olmadigi validasyonunu
	 * saglar. Banka banka kredi riski mevcut degil ise GMRuntimeException firlatilir.
	 * 
	 * @param iMap {TCKN} 			TC Kimlik Numarasi
	 * @param iMap {BASVURU_NO}		Kredi basvuru numarasi
	 * @see BNSPR_QRY3911_ONLINE_KKB_SORGULA
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_CONSOLIDATION_VALIDATION")
	public static GMMap consolidationValidation(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		oMap.put("IS_VALID", true);
		String primaryIdType = "6", financeType = "90", dot = ".", birthDate = "19000101";
		boolean isMocked = false;
		
		try {
		
			// KKB Kontrol
			BigDecimal sorguNo = (BigDecimal) DALUtil.callOracleFunction(
				"{ ? = call pkg_ptt_basvuru.yapilmis_kkb_sorgusu(?) }", BnsprType.NUMBER, BnsprType.STRING, iMap
					.getString("TCKN"));
	
			if(sorguNo == null) {
				sorguNo = GMServiceExecuter.call(
					"BNSPR_QRY3911_ONLINE_KKB_SORGULA",
					new GMMap().put("PRIMARY_ID_TYPE", primaryIdType).put("PRIMARY_ID_NO", iMap.getString("TCKN")).put(
						"FINANCE_TYPE", financeType).put("FORENAME1", dot).put("SURNAME", dot).put("BIRTHDATE",
						birthDate).put("BIRTHTOWN", dot)).getBigDecimal("SORGU_NO");
			}
	
			BigDecimal sonuc = (BigDecimal) DALUtil.callOracleFunction("{ ? = call pkg_ptt_basvuru.ptt_ici_bt_kkb_risk(?,?) }", 
				BnsprType.NUMBER, BnsprType.NUMBER, sorguNo, BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
	
			logger.info("BNSPR_CLKS_CONSUMERLOAN_CONSOLIDATION_VALIDATION. KKB Sorgu No : " + sorguNo + " KKB Risk : " + sonuc);
			String isMockedParam ="";
			try {
				isMockedParam = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap()
				.put("KOD", "CLKS_MOCK_CREDIT_KKB_DATA")
				.put("KEY", iMap.getString("TCKN"))).getString("TEXT");
			}
			catch (Exception e) {
				isMockedParam="H";
				// TODO: handle exception
			}
			if("E".equals(isMockedParam)) {
				isMocked = true;
			}
			
			if(sonuc.intValue() == 0 && !isMocked) {
				oMap.put("IS_VALID", false);
			} else if(sonuc.intValue() > 0 && !isMocked) {
				Session session = DAOSession.getSession("BNSPRDal");
				
				Map<String, Object> restrictions = new HashMap<String, Object>();
				restrictions.put("basvuruNo", iMap.getBigDecimal("BASVURU_NO"));
				restrictions.put("kkbAcikEh", "E");
				
				@SuppressWarnings("unchecked")
				List<ClksBirBasvuruBirlestirme> birlestirmeList = session.createCriteria(
					ClksBirBasvuruBirlestirme.class).add(Restrictions.allEq(restrictions)).list();
				
				if(birlestirmeList != null && birlestirmeList.size() > 0) {
					;
				} else {
					oMap.put("IS_VALID", false);
				}
			}
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_CONSOLIDATION_VALIDATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT ici birlestirme kredisi icin kaptilacak PTT kredilerine dair bilgi doner.
	 * 
	 * @param iMap {BASVURU_NO}		Kredi basvuru numaras�
	 * @return 						{@code GMMap}
	 * @throws GMRuntimeException	Diger istisnai durumlarda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_FOR_CHANNEL_INFO")
	public static GMMap consumerLoanForChannelInfo(GMMap iMap) {

		GMMap oMap = new GMMap();
		boolean isMocked = false;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");

			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("basvuruNo", iMap.getBigDecimal("BASVURU_NO"));
			
			@SuppressWarnings("unchecked")
			List<ClksBirBasvuruBirlestirme> birlestirmeList = session.createCriteria(ClksBirBasvuruBirlestirme.class)
				.add(Restrictions.allEq(restrictions)).list();
			int index=0;
			for(int i=0; i<birlestirmeList.size(); i++) {
				
				if(i == 0) {
					BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, birlestirmeList.get(i).getBasvuruNo());
					String isMockedParam ="";
					try {
						isMockedParam = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap()
						.put("KOD", "CLKS_MOCK_CREDIT_KKB_DATA")
						.put("KEY", birBasvuru.getTcKimlikNo())).getString("TEXT");
					}
					catch (Exception e) {
						isMockedParam="H";
						// TODO: handle exception
					}
					if("E".equals(isMockedParam)) {
						isMocked = true;
					}
				
				}
				
				if(isMocked) {
					oMap.put("PTT_ICI_BIRLESTIRME", i, "BANKA_ID", birlestirmeList.get(i).getBankaId());
					oMap.put("PTT_ICI_BIRLESTIRME", i, "TUTAR", birlestirmeList.get(i).getTutar());
					oMap.put("PTT_ICI_BIRLESTIRME", i, "BASVURU_TARIHI", birlestirmeList.get(i).getBasvuruTarihi());
					oMap.put("PTT_ICI_BIRLESTIRME", i, "KULLANDIRIM_TARIHI", birlestirmeList.get(i)
						.getKullandirimTarihi());
				} else if("E".equals(birlestirmeList.get(i).getKapamaEh())) {
					oMap.put("PTT_ICI_BIRLESTIRME",index, "BANKA_ID", birlestirmeList.get(i).getBankaId());
					oMap.put("PTT_ICI_BIRLESTIRME", index, "TUTAR", birlestirmeList.get(i).getTutar());
					oMap.put("PTT_ICI_BIRLESTIRME", index, "BASVURU_TARIHI", birlestirmeList.get(i).getBasvuruTarihi());
					oMap.put("PTT_ICI_BIRLESTIRME", index, "KULLANDIRIM_TARIHI", birlestirmeList.get(i).getKullandirimTarihi());
					index++;
				} else {
					oMap.put("F_PARTIAL_CONSOLIDATION_FOR_CHANNEL", true);
				}
			}
			
			return oMap;
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_FOR_CHANNEL_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT SMS kredisi icin CODEC taraf�ndan gelen istekleri kaydeden servis
	 * 
	 *  * @param iMap {NATIONAL_IDENTIFICATION_NUMBER} 			TC Kimlik Numarasi
	 * @param iMap {MSISDN}		Telefon numaras�
	 * @return 						{@code GMMap}
	 * @throws GMRuntimeException	Diger istisnai durumlarda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION")
	public static GMMap consumerLoanSaveSmsApplication(GMMap iMap) {
		boolean halt = false;
		String msisdn = iMap.getString("MSISDN"), message = "";
		String nationalIdentificationNumber = iMap.getString("NATIONAL_IDENTIFICATION_NUMBER");
		String info ="";
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			String channel = iMap.getString("CHANNEL");
			// GMContext.getCurrentContext().getSession().get("CHANNEL_CODE")

			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO")==null ? BigDecimal.ZERO: iMap.getBigDecimal("BASVURU_NO");
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
			String truncatedMsisdn = msisdn.replaceFirst("((\\+|0{2})9){0,1}0", "");
			String areaCode = truncatedMsisdn.substring(0, 3), phoneNumber = truncatedMsisdn.substring(3);

			ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = new ClksBirBasvuruSmsTalep();
			clksBirBasvuruSmsTalep.setBasvuruNo(basvuruNo);
			clksBirBasvuruSmsTalep.setMsisdn(msisdn);
			clksBirBasvuruSmsTalep.setKanal(channel);
			clksBirBasvuruSmsTalep.setTxNo(trxNo);
			
			String smsCreditCampaignCode = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
					new GMMap().put("KOD", "CLKS_SMS_KREDI").put("KEY", "KAMPANYA_KODU"))
					.getString("TEXT");
			BigDecimal kampKod= new BigDecimal(smsCreditCampaignCode);
			
			clksBirBasvuruSmsTalep.setKampanyaKodu(kampKod);


			if ("BULK".equals(channel)) {
				clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_INITIAL);
				message = API.message(5970);
				clksBirBasvuruSmsTalep.setTxNo(trxNo);
				clksBirBasvuruSmsTalep.setTcKimlikNo(iMap.getString("NATIONAL_IDENTIFICATION_NUMBER"));
				
				session.saveOrUpdate(clksBirBasvuruSmsTalep);
				session.flush();

				if (isSMSSendableChannel(clksBirBasvuruSmsTalep.getKanal())) {
					GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", iMap.getString("MSISDN")).put("CONTENT", message));
				}
			}
			else {
				basvuruNo = GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", new GMMap()).getBigDecimal("ID");
				clksBirBasvuruSmsTalep.setBasvuruNo(basvuruNo);

				GMMap mobileMap = GMServiceExecuter.call("BNSPR_CLKS_CUSTOMER_EXISTING_MOBILE_PHONE_CONTROL_FOR_SMS_CREDIT", new GMMap().put("TC_KIMLIK_NO", iMap.getString("NATIONAL_IDENTIFICATION_NUMBER")).put("CEP_TEL_KOD", areaCode).put("CEP_TEL_NO", phoneNumber));

				if (!StringUtil.isEmpty(mobileMap.getString("MESSAGE_NO"))) {
					message = API.message(mobileMap.getInt("MESSAGE_NO"));
					halt = true;
					info = message;
				}
				else {
					if (!StringUtil.isEmpty(mobileMap.getString("TC_KIMLIK_NO"))) {
						nationalIdentificationNumber = mobileMap.getString("TC_KIMLIK_NO");
					}
				}

				Map<String, Object> restrictions = new HashMap<String, Object>();

				if (!StringUtil.isEmpty(nationalIdentificationNumber)) {
					clksBirBasvuruSmsTalep.setTcKimlikNo(nationalIdentificationNumber);

					if (GMServiceExecuter.call("BNSPR_COMMON_TCKN_CHECK_DIGIT", new GMMap().put("TC_KIMLIK_NO", nationalIdentificationNumber)).getInt("SONUC") == 0) {
						message = API.message(5975);
						info = message;
						halt = true;
					}
					else {
						GMMap validationMap = GMServiceExecuter.call("BNSPR_CL_PTT_SMS_VALIDATION", new GMMap().put("TC_KIMLIK_NO", nationalIdentificationNumber));
						if (!"00".equals(validationMap.getString("RESPONSE_CODE"))) {
							if ("90".equals(validationMap.getString("RESPONSE_CODE"))) {
								message = API.message(5977);
								halt = true;
								info = validationMap.getString("RESPONSE_MESSAGE");
							}
							else {
								message = API.message(5973);
								halt = true;
								info = validationMap.getString("RESPONSE_MESSAGE");
							}

						}

						// else if(API.isMobilePhoneExistsOnAnotherCustomer(iMap.getString("NATIONAL_IDENTIFICATION_NUMBER"), areaCode, phoneNumber)) {
						// message = API.message(5971);
						// halt = true;
						// }
						if (!halt) {
							
							restrictions.put("tcKimlikNo", nationalIdentificationNumber);
							restrictions.put("kanalKodu", "7");

							@SuppressWarnings("unchecked")
							List<BirBasvuru> birBasvuruList = session.createCriteria(BirBasvuru.class).add(Restrictions.and(Restrictions.and(Restrictions.allEq(restrictions), Restrictions.not(Restrictions.in("durumKodu", new String[] { Application.STATUS.CEPTE.toString(), Application.STATUS.EVRAKSIZ.toString(), Application.STATUS.RED.toString(), Application.STATUS.IPTAL.toString(),
									Application.STATUS.KAPANDI.toString() }))), Restrictions.eq("kampKod", new BigDecimal(smsCreditCampaignCode)))).list();

							if (birBasvuruList != null && birBasvuruList.size() > 0) {
								message = API.message(5977);
								info = message;
								halt = true;
							}

							@SuppressWarnings("unchecked")
							List<BirBasvuru> birBasvuruListBranch = session.createCriteria(BirBasvuru.class)
							.add(Restrictions.and(Restrictions.and(Restrictions.allEq(restrictions), 
									Restrictions.not(Restrictions.in("durumKodu", new String[] { Application.STATUS.CEPTE.toString(), Application.STATUS.EVRAKSIZ.toString(), Application.STATUS.RED.toString(), Application.STATUS.IPTAL.toString(),
									Application.STATUS.KAPANDI.toString() }))), Restrictions.ne("kampKod", new BigDecimal(smsCreditCampaignCode)))).list();

							if (birBasvuruListBranch != null && birBasvuruListBranch.size() > 0) {
								message = API.message(6004);
								info = message;
								halt = true;
							}
						}
					}

				}

				if (halt) {
					clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_FAIL);
					if (info.length() > 199) {
						info = info.substring(0, 199);
					}
					clksBirBasvuruSmsTalep.setAciklama(info);

					session.saveOrUpdate(clksBirBasvuruSmsTalep);
					session.flush();
					if (isSMSSendableChannel(clksBirBasvuruSmsTalep.getKanal())) {
						GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", iMap.getString("MSISDN")).put("CONTENT", message));
					}
					return new GMMap().put("RESPONSE", 2);
				}

				restrictions.clear();
				restrictions.put("tcKimlikNo", nationalIdentificationNumber);

				@SuppressWarnings("unchecked")
				// List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
				// .add(Restrictions.allEq(restrictions)).list();
				List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
				.add(Restrictions.and(Restrictions.allEq(restrictions), Restrictions.in("durumKodu", new String[] { SMS_APPLICATION_STATU_INITIAL, SMS_APPLICATION_STATU_PENDING }))).list();

				if (clksBirBasvuruSmsTalepList.size() > 0) {

					clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_DUPLICATED);
					message = API.message(5977);
					session.saveOrUpdate(clksBirBasvuruSmsTalep);
					session.flush();
					if (isSMSSendableChannel(clksBirBasvuruSmsTalep.getKanal())) {
						GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", iMap.getString("MSISDN")).put("CONTENT", message));
					}
				}
				else {
					if (StringUtil.isEmpty(info)) {
						clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_INITIAL);
						message = API.message(5970);

						session.saveOrUpdate(clksBirBasvuruSmsTalep);
						session.flush();

						if (isSMSSendableChannel(clksBirBasvuruSmsTalep.getKanal())) {
							GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", iMap.getString("MSISDN")).put("CONTENT", message));
						}
					}
				}
			}
	
			return new GMMap().put("RESPONSE", 2);
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT SMS Kredisi i�in taleplerin PTT ye iletilmesi i�in servis
	 * 
	 * @param iMap {BASVURU_NO}		Kredi basvuru numaras�
	 * @return 						{@code GMMap}
	 * @param oMap {"SMS_TALEP_LIST", i, "TC_KIMLIK_NO"}		Tc Kimlik No

	 * @throws GMRuntimeException	Diger istisnai durumlarda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_LIST")
	public static GMMap consumerLoanGetSmsApplicationList(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");

			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("durumKodu", SMS_APPLICATION_STATU_INITIAL);

			@SuppressWarnings("unchecked")
			List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
				.add(Restrictions.allEq(restrictions)).list();
			
			for(int i=0; i<clksBirBasvuruSmsTalepList.size(); i++) {
				ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = new ClksBirBasvuruSmsTalep();
				clksBirBasvuruSmsTalep = clksBirBasvuruSmsTalepList.get(i);
				oMap.put("SMS_TALEP_LIST", i, "TC_KIMLIK_NO", clksBirBasvuruSmsTalep.getTcKimlikNo());
				oMap.put("SMS_TALEP_LIST", i, "KANAL", clksBirBasvuruSmsTalep.getKanal());
				oMap.put("SMS_TALEP_LIST", i, "BASVURU_NO", clksBirBasvuruSmsTalep.getBasvuruNo());	
				oMap.put("SMS_TALEP_LIST", i, "BANKA_ISLEM_NO", clksBirBasvuruSmsTalep.getTxNo());	
				
				clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_PENDING); 
				clksBirBasvuruSmsTalep.setProcessDate(new Date());
				session.saveOrUpdate(clksBirBasvuruSmsTalep);
			}
			session.flush();			
			return oMap;
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	/**
	 * PTT SMS Kredisi i�in Maa� bilgilerini kaydeden servis
	 *  MAAS_BILGILERI[TAHSIS_NUMARASI,MAAS_ALINAN_KURUM,MAAS_TUTARI,UNVANI,EMEKLI_MAAS_DONEM,ONCEKI_MAAS_ODEME_TARIHI,MAAS_TARIH_SIKLIGI,ILK_MAAS_TARIHI,SON_MAAS_TARIHI,MAAS_PTT_DENMI,EMEKLI_MAAS_EVDENMI,KURUM_DONEM],
     *  SGK_AYLIK_BILGILERI[SIGORTA_KOLU,AYLIK_ID,TAHSIS_SEKLI,ADI,SOYADI,AYLIK_BANKAMDA,SICIL_NO,SISTEM_ACIK_KAPALI_KODU,AYLIK_SONUC_KODU,AYLIK_SONUC_ACIKLAMA]
     *  TC_KIMLIK_NO,SGK_SONUC_KOD, SGK_SONUC_ACIKLAMA,PCH_DURUM
	 * 
	 */
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION_PENSION_INFO")
	public static GMMap consumerLoanSaveSmsApplicationPensionInfo(GMMap iMap) {
		
		GMMap map = new GMMap(), oMap = new GMMap();
		map.putAll(iMap);
		
		try {
			
			for (int i = 0; i < map.getSize("MAAS_BILGILERI"); i++) {
				if("00000000".equals(map.getString("MAAS_BILGILERI", i, "ONCEKI_MAAS_ODEME_TARIHI"))) {
					map.put("MAAS_BILGILERI", i, "ONCEKI_MAAS_ODEME_TARIHI", new String());
				}
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			String message = null;
			
			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"));
			restrictions.put("durumKodu", SMS_APPLICATION_STATU_PENDING);
			
			@SuppressWarnings("unchecked")
			List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
				.add(Restrictions.allEq(restrictions)).list();
			
			for(int i=0; i<clksBirBasvuruSmsTalepList.size(); i++) {
				
				ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = clksBirBasvuruSmsTalepList.get(i);
				String msisdn = clksBirBasvuruSmsTalep.getMsisdn();
				String truncatedMsisdn = msisdn.replaceFirst("((\\+|0{2})9){0,1}0", "");
				String areaCode = truncatedMsisdn.substring(0,3), phoneNumber = truncatedMsisdn.substring(3);
				
				map.put("BASVURU_NO", clksBirBasvuruSmsTalep.getBasvuruNo());

				map.put("ISLEM_NO_BANKA",clksBirBasvuruSmsTalep.getTxNo() );
				
				Application application = null;
				
				String smsCreditCampaignCode = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
						new GMMap().put("KOD", "CLKS_SMS_KREDI").put("KEY", "KAMPANYA_KODU"))
						.getString("TEXT");
				BigDecimal kampKod= new BigDecimal(smsCreditCampaignCode);
				BigDecimal kampKnlKod = new BigDecimal(7);
				

				application = new Application(clksBirBasvuruSmsTalep.getBasvuruNo(), clksBirBasvuruSmsTalep.getTcKimlikNo(), BigDecimal.ZERO
						, 60, new Campaign.Builder(kampKod,kampKnlKod).build());
				
				application.setTrxNo(clksBirBasvuruSmsTalep.getTxNo());
				application.setCurrency(CurrencyType.TRY);
				
				application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_SMS_KREDI);
				application.setQualifiedCommission(true);
				CreditApplicationDao<Application> dao = new DalCreditApplicationDao();
				
				Record record = null;
				
				try {
					CommissionContext commissionContext = new CommissionContext(application.getCommissionCategory()
						.getStrategyClass().getDeclaredConstructor(List.class).newInstance(
							new GMCacheCommissionDao().getByCommissionCategory(application.getCommissionCategory())));

					record = commissionContext.calculate(new Record(application.getAmount(), application.getCurrency()));
					application.setCommission(record);
					dao.saveCommission(application);
					
				} catch(Exception e) {
					logger.error(String.format(
						"(commissionCategory, amount, currency) => (%s,%s,%s)",
						application.getCommissionCategory().toString(), application.getAmount().toString(), application.getCurrency().toString()), e);
				}
				
				if (PCH_STATU_YES.equals(iMap.getString("PCH"))) {
				try {
					map = GMServiceExecuter.call("BNSPR_CLKS_CREDIT_PENSION_PERIOD", map);
					
					// PTT Kredi - Kabul Aylik Secimi, SGK Aylik Eslestirme
					map.putAll(GMServiceExecuter.call("BNSPR_CLKS_CREDIT_SELECT_PENSION", map));
					// -> SGK_AYLIK_BILGILERI, SGK_SONUC_KODU, SGK_SONUC_ACIKLAMA, SGK_KONTROL_TIP
					//    TAHSIS_NUMARASI, MAAS_TUTARI, MAAS_ALINAN_KURUM, UNVANI, PTT_UNVAN_KOD, EMEKLI_MAAS_DONEM, ONCEKI_MAAS_ODEME_TARIHI
					//    MAAS_TARIH_SIKLIGI, ILK_MAAS_TARIHI, SON_MAAS_TARIHI, MAAS_PTT_DENMI, EMEKLI_MAAS_EVDENMI, KURUM_DONEM
					
					// Son maas tarihi bayrama denk gelirse, yeni degeri ile guncelleniyor
					map.put("SON_MAAS_TARIHI", GMServiceExecuter.call("CLKS_SON_MAAS_TARIHI", map).get("SON_MAAS_TARIHI"));
		
					// 1:Evden, 2:Merkez, -1:Tanimsiz
					map.put("EMEKLI_MAAS_EVDENMI", getInstitutionPlaceCode(map.getInt("MAAS_ALINAN_KURUM")) == "K" ? "E" : "H");
					
					// Maas Alinan Kurum - 1:SSK, 2:Emekli Sandigi, 3:Bagkur, 4:PTT Personel 
					map.put("MAAS_ALINAN_KURUM", getInstitutionType(map.getInt("MAAS_ALINAN_KURUM")));
					
					// Case: Emekli Sandigi
					if("2".equals(map.getString("MAAS_ALINAN_KURUM")) && (map.get("MAAS_TARIH_SIKLIGI") == null)
						|| map.getString("MAAS_TARIH_SIKLIGI").isEmpty()) {
						// TODO Maas periyodu belirsiz ?
						// return new GMMap().put("RESPONSE", 1).put("RESPONSE_DATA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 4992)).getString("ERROR_MESSAGE"));
					}
					
					// PTT - SGK Maas Kayit
					map.putAll(GMServiceExecuter.call("CLKS_BIR_BASVURU_SGK_AYLIK_TX_SAVE_OR_UPDATE", map));
					
					// PTT Maas Loglama
					GMServiceExecuter.call("CLKS_BIR_BASVURU_AYLIK_LOG", map);
					
					// SGK Online Bildirim Loglama
					GMServiceExecuter.call("CLKS_SGK_EMEKLI_MAAS_SORGU_CREATE_LOG", map.put("REQUEST_TYPE", "aylikSorgula"));
					
					map.put("AYLIK_GELIR", map.getBigDecimal("MAAS_TUTARI"));
				}
				catch (Exception e) {
					// TODO: handle exception
//					message = API.message(5974);
//				
//					GMServiceExecuter.executeAsync("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", msisdn).put("CONTENT", message));
				
					logger.error("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION_PENSION_INFO err:", e);
					throw ExceptionHandler.convertException(e);
				}

				
				clksBirBasvuruSmsTalep.setTxNo(map.getBigDecimal("ISLEM_NO_BANKA"));
				clksBirBasvuruSmsTalep.setAylikGelir(map.getBigDecimal("AYLIK_GELIR"));
				clksBirBasvuruSmsTalep.setTahsisNumarasi(map.getString("TAHSIS_NUMARASI"));
				clksBirBasvuruSmsTalep.setMaasAlinanKurum(map.getString("MAAS_ALINAN_KURUM"));
				clksBirBasvuruSmsTalep.setIlkMaasTarihi(map.get("ILK_MAAS_TARIHI") != null ? map.getDate("ILK_MAAS_TARIHI") : null);
				clksBirBasvuruSmsTalep.setSonMaasTarihi(map.get("SON_MAAS_TARIHI") != null ? map.getDate("SON_MAAS_TARIHI") : null);
				clksBirBasvuruSmsTalep.setOncekiMaasOdemeTarihi(map.get("ONCEKI_MAAS_ODEME_TARIHI") != null ? map.getDate("ONCEKI_MAAS_ODEME_TARIHI") : null);
				clksBirBasvuruSmsTalep.setPttMaasEvdenMi(map.getString("EMEKLI_MAAS_EVDENMI").charAt(0));
				clksBirBasvuruSmsTalep.setPch(map.getString("PCH"));
				clksBirBasvuruSmsTalep.setSgkSonucKodu(map.getString("SGK_SONUC_KOD"));
				clksBirBasvuruSmsTalep.setSgkSonucAciklama(map.getString("SGK_SONUC_ACIKLAMA"));
				clksBirBasvuruSmsTalep.setAylikBankamda(iMap.getString("SGK_AYLIK_BILGILERI",0,"AYLIK_BANKAMDA"));
				clksBirBasvuruSmsTalep.setMaasBilgiTarih(new Date());
				session.saveOrUpdate(clksBirBasvuruSmsTalep);
				session.flush();
				
				map.put("ONCEKI_MAAS_ODEME_TARIHI", (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_nbsm_3appl_2.ptt_emekli_onceki_maas_tarihi(?)}", Types.NUMERIC, map.getBigDecimal("BASVURU_NO")));
				if("99999999".equals(map.getString("ONCEKI_MAAS_ODEME_TARIHI"))) {
					map.remove("ONCEKI_MAAS_ODEME_TARIHI");
				}
				
				clksBirBasvuruSmsTalep.setOncekiMaasOdemeTarihi(map.get("ONCEKI_MAAS_ODEME_TARIHI") != null ? map.getDate("ONCEKI_MAAS_ODEME_TARIHI") : null);
				session.saveOrUpdate(clksBirBasvuruSmsTalep);
				session.flush();
				
				if("-4".equals(iMap.getString("SGK_SONUC_KOD")) || "-6".equals(iMap.getString("SGK_SONUC_KOD")) || "-13".equals(iMap.getString("SGK_SONUC_KOD"))) {
					message = API.message(5976);
				}
				if(!"1".equals(iMap.getString("SGK_AYLIK_BILGILERI",0,"AYLIK_BANKAMDA"))) {
					message = API.message(5976);				
				}
					if(message == null){
						clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_APPROVED); // TODO Asenkron yap�da stat�ler ele al�ncak 
						session.saveOrUpdate(clksBirBasvuruSmsTalep);
						session.flush();
						
						GMMap applicationMap = new GMMap();
						applicationMap.put("TRX_NO", map.getBigDecimal("ISLEM_NO_BANKA"));
						applicationMap.put("TC_KIMLIK_NO", map.getString("TC_KIMLIK_NO"));
						applicationMap.put("BASVURU_NO", map.getBigDecimal("BASVURU_NO"));
						applicationMap.put("CEP_TEL_ALAN_KODU", areaCode);
						applicationMap.put("CEP_TEL_NO", phoneNumber);
						applicationMap.put("MSISDN", msisdn);
						applicationMap.put("KAYNAK", clksBirBasvuruSmsTalep.getKanal());
						oMap.put("APPLICATION_MAP", applicationMap);
					}
			}else{
				String pchStatu= iMap.getString("PCH");
				if (pchStatu.length()>30) {
					pchStatu = PCH_STATU_NO;
				}
				clksBirBasvuruSmsTalep.setPch(pchStatu);
				clksBirBasvuruSmsTalep.setMaasBilgiTarih(new Date());
				clksBirBasvuruSmsTalep.setSgkSonucKodu(iMap.getString("SGK_SONUC_KOD"));
				clksBirBasvuruSmsTalep.setSgkSonucAciklama(iMap.getString("SGK_SONUC_ACIKLAMA"));
				session.saveOrUpdate(clksBirBasvuruSmsTalep);
				session.flush();
				message = API.message(6040);// pch yok i�in ayr� mesaj istenirse o tan�mlanacak
				
				if(!"1".equals(iMap.getString("SGK_AYLIK_BILGILERI",0,"AYLIK_BANKAMDA"))) {
					message = API.message(5976);				
				}
				
				if("-4".equals(iMap.getString("SGK_SONUC_KOD")) || "-6".equals(iMap.getString("SGK_SONUC_KOD")) || "-13".equals(iMap.getString("SGK_SONUC_KOD"))) {
					message = API.message(5976);
				}
			}
				if(message != null) {
					if (isSMSSendableChannel(clksBirBasvuruSmsTalep.getKanal())) {
					GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", msisdn).put("CONTENT",
						message));
					}
				}
			}
		
			return oMap;
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION_PENSION_INFO err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_STATUS_LIST")
	public static GMMap consumerLoanGetSmsApplicationStatusList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			
			Date processDate = iMap.getDate("DATE", new Date());
//			GMMap recordsMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_trn2052.get_sms_credit_app_records(?)}", "RECORD_LIST", BnsprType.DATE, processDate);
			
//			CreditApplicationDao<Application> dao = new DalCreditApplicationDao();
			
			String refusedSendStartTimeParam = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
				new GMMap().put("KOD", "CLKS_SMS_KREDI_RED_BILDIRME_SAATI").put("KEY", "RED_BASLAMA_SAATI_HHMM"))
				.getString("TEXT");
			

			
			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("durumKodu", SMS_APPLICATION_STATU_SEND_READY);
			
			@SuppressWarnings("unchecked")
			List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
				.add(Restrictions.allEq(restrictions)).list();
			
			for(int i=0; i<clksBirBasvuruSmsTalepList.size(); i++) {
				ClksBirBasvuruSmsTalep talep =clksBirBasvuruSmsTalepList.get(i);
				
				Date refusedSendStartTime = getDateRefusedSendStartTime(refusedSendStartTimeParam);
				
				if (SMS_CREDIT_STATU_REFUSED.equals(talep.getDurum())) {
					if (processDate.before(refusedSendStartTime)) {
						continue;
					}
				}

				oMap.put("SMS_BASVURU_LIST", i, "TC_KIMLIK_NO", talep.getTcKimlikNo());
				oMap.put("SMS_BASVURU_LIST", i, "AD", talep.getAd());
				oMap.put("SMS_BASVURU_LIST", i, "SOYAD", talep.getSoyad());
				oMap.put("SMS_BASVURU_LIST", i, "TUTAR", talep.getTutar());
				oMap.put("SMS_BASVURU_LIST", i, "VADE", talep.getVade());
				oMap.put("SMS_BASVURU_LIST", i, "MASRAF_TUTARI", talep.getMasrafTutari());
				oMap.put("SMS_BASVURU_LIST", i, "DURUM", talep.getDurum());
				oMap.put("SMS_BASVURU_LIST", i, "BASVURU_NO", talep.getBasvuruNo());
				oMap.put("SMS_BASVURU_LIST", i, "MAAS_ALINAN_KURUM_KOD", talep.getMaasAlinanKurum());
				oMap.put("SMS_BASVURU_LIST", i, "CALISMA_DURUM_KOD", talep.getCalismaDurumKod());
				oMap.put("SMS_BASVURU_LIST", i, "BANKA_ISLEM_NO", talep.getTxNo());
				oMap.put("SMS_BASVURU_LIST", i, "NITELIKLI", talep.getNitelikli());
				oMap.put("SMS_BASVURU_LIST", i, "KAMPANYA_ADI", talep.getKampanyaAdi());
				oMap.put("SMS_BASVURU_LIST", i, "KAMPANYA_KODU", talep.getKampanyaKodu());
				oMap.put("SMS_BASVURU_LIST", i, "KONSOLIDASYON_EH", talep.getKonsolidasyonEh());
				oMap.put("SMS_BASVURU_LIST", i, "TAKSITI_TUTAR", talep.getTaksitTutari());

				talep.setDurumKodu(SMS_APPLICATION_STATU_SEND);
				talep.setBasvuruDurumTarih(new Date());
				session.saveOrUpdate(talep);
				
			}
			session.flush();
			return oMap;
		}
		catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_STATUS_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_UPDATE_SMS_APPLICATION_STATUS_LIST")
	public static GMMap consumerLoanUpdateSmsApplicationStatusList(GMMap iMap) {
		GMMap recordsMap= new GMMap();
		Date processDate;
		try {
			processDate = iMap.getDate("DATE", new Date());
			recordsMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_trn2052.get_sms_credit_app_records(?)}", "RECORD_LIST", BnsprType.DATE, processDate);

			String refusedSendStartTimeParam = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
					new GMMap().put("KOD", "CLKS_SMS_KREDI_RED_BILDIRME_SAATI").put("KEY", "RED_BASLAMA_SAATI_HHMM"))
					.getString("TEXT");

			Session session = DAOSession.getSession("BNSPRDal");
						
			CreditApplicationDao<Application> dao = new DalCreditApplicationDao();
			
			for (int i = 0; i < recordsMap.getSize("RECORD_LIST"); i++) {
				
				Date refusedSendStartTime = getDateRefusedSendStartTime(refusedSendStartTimeParam);
				
				if (SMS_CREDIT_STATU_REFUSED.equals(recordsMap.getString("RECORD_LIST", i, "DURUM"))) {
					if (processDate.before(refusedSendStartTime)) {
						continue;
					}
				}

				ClksBirBasvuruSmsTalep talep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class,
						recordsMap.getBigDecimal("RECORD_LIST", i, "BASVURU_NO"));
				talep.setAd(recordsMap.getString("RECORD_LIST", i, "AD"));
				talep.setSoyad(recordsMap.getString("RECORD_LIST", i, "SOYAD"));
				talep.setTutar(recordsMap.getBigDecimal("RECORD_LIST", i, "TUTAR"));
				talep.setVade(recordsMap.getBigDecimal("RECORD_LIST", i, "VADE"));
				talep.setMasrafTutari(recordsMap.getBigDecimal("RECORD_LIST", i, "MASRAF_TUTARI"));
				talep.setDurum(recordsMap.getString("RECORD_LIST", i, "DURUM"));
				talep.setCalismaDurumKod(recordsMap.getString("RECORD_LIST", i, "CALISMA_DURUM_KOD"));
				talep.setNitelikli(recordsMap.getString("RECORD_LIST", i, "NITELIKLI"));
				talep.setKampanyaAdi(recordsMap.getString("RECORD_LIST", i, "KAMPANYA_ADI"));
				talep.setKampanyaKodu(recordsMap.getBigDecimal("RECORD_LIST", i, "KAMPANYA_KODU"));
				talep.setKonsolidasyonEh(recordsMap.getString("RECORD_LIST", i, "KONSOLIDASYON_EH"));
				
				talep.setTaksitTutari(recordsMap.getBigDecimal("RECORD_LIST", i, "TAKSIT_TUTARI"));

		
				
				BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, recordsMap.getBigDecimal("RECORD_LIST", i, "BASVURU_NO"));
				BirBasvuruTx birBasvuruTx = null;
				Application application = null;
				
				if(birBasvuru == null) {
					birBasvuruTx = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("basvuruNo", recordsMap.getBigDecimal("RECORD_LIST", i, "BASVURU_NO"))).setFirstResult(0).setMaxResults(1).uniqueResult();

					application = new Application(birBasvuruTx.getBasvuruNo(), birBasvuruTx.getTcKimlikNo(), birBasvuruTx
						.getTutar(), birBasvuruTx.getVade().intValue(), new Campaign.Builder(birBasvuruTx.getKampKod(), birBasvuruTx
						.getKampKnlKod()).build());
				} else {
					application = new Application(birBasvuru.getBasvuruNo(), birBasvuru.getTcKimlikNo(), birBasvuru
						.getTutar(), birBasvuru.getVade().intValue(), new Campaign.Builder(birBasvuru.getKampKod(), birBasvuru
						.getKampKnlKod()).build());
				}
					
				application.setTrxNo(recordsMap.getBigDecimal("RECORD_LIST", i, "BANKA_ISLEM_NO"));
				application.setCurrency(CurrencyType.TRY);
				
				// RED
				if (SMS_CREDIT_STATU_REFUSED.equals(recordsMap.getString("RECORD_LIST", i, "DURUM"))) {
					
//					application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_RED_EMEKLI);
//					
//					try {
//						application.setQualifiedCommission("E".equals(dao.updateQualifiedCommissionOnReject(application
//							.getApplicationNo(), application.getNationalIdentificationNumber())) ? true : false);
//					} catch(SQLException e) {
//						logger.error(application.toString(), e);
//					}
				} 
				
				// ONAY
				else {
//					application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_KABUL_EMEKLI);
//					application.setQualifiedCommission(true);
					
					ClksSgkMaasBlokeTx clksSgkMaasBlokeTx = new ClksSgkMaasBlokeTx();
				    String id = DALUtil.getResult("select pkg_genel_pr.genel_kod_al('CLKS_SGK_MAAS_BLOKE_TX') from dual");
					clksSgkMaasBlokeTx.setSgkBlockId(new BigDecimal(id));
					clksSgkMaasBlokeTx.setTckn(recordsMap.getString("RECORD_LIST", i, "TC_KIMLIK_NO"));
					clksSgkMaasBlokeTx.setBasvuruNo(recordsMap.getBigDecimal("RECORD_LIST", i, "BASVURU_NO"));
					clksSgkMaasBlokeTx.setAsama("H");
					clksSgkMaasBlokeTx.setBasvuruTarihi(recordsMap.getDate("RECORD_LIST", i, "BASVURU_TARIHI"));
//				    clksSgkMaasBlokeTx.setKrediSonTaksitTarihi(recordsMap.getDate("RECORD_LIST", i, "KREDI_SON_TAKSIT_TARIHI"));
//				    clksSgkMaasBlokeTx.setKullandirimTarihi(recordsMap.getDate("RECORD_LIST", i, "KULLANDIRIM_TARIHI"));
				    clksSgkMaasBlokeTx.setKrediSonTaksitTarihi(DateUtils.addMonths(new Date(), 60));
				    clksSgkMaasBlokeTx.setKullandirimTarihi(DateUtils.addDays(new Date(), 15));
				    clksSgkMaasBlokeTx.setDurumu("A");
					clksSgkMaasBlokeTx.setEmekliSicilNo(recordsMap.getString("RECORD_LIST", i, "PTT_TAHSIS_NUMARASI"));
					clksSgkMaasBlokeTx.setGsmNo(recordsMap.getString("RECORD_LIST", i, "MSISDN"));
					clksSgkMaasBlokeTx.setKaynak("SORGU");
					session.save(clksSgkMaasBlokeTx);
				}
				
//				if(application.isQualifiedCommission()) {
//					Record record = null;
//					
//					try {
//						CommissionContext commissionContext = new CommissionContext(application.getCommissionCategory()
//							.getStrategyClass().getDeclaredConstructor(List.class).newInstance(
//								new GMCacheCommissionDao().getByCommissionCategory(application.getCommissionCategory())));
//	
//						record = commissionContext.calculate(new Record(application.getAmount(), application.getCurrency()));
//						application.setCommission(record);
//						dao.saveCommission(application);
//						
//					} catch(Exception e) {
//						logger.error(String.format(
//							"(commissionCategory, amount, currency) => (%s,%s,%s)",
//							application.getCommissionCategory().toString(), application.getAmount().toString(), application.getCurrency().toString()), e);
//					}
//				} else {
//					recordsMap.put("RECORD_LIST", i, "NITELIKLI", "0");
//					talep.setNitelikli("0");
//				}
				
				talep.setDurumKodu(SMS_APPLICATION_STATU_SEND_READY);
				session.saveOrUpdate(talep);
				
			}
			session.flush();

			
		}
		catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_UPDATE_SMS_APPLICATION_STATUS_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}
		return recordsMap;
		
	}
	
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_CREDIT_USAGE_STATUS_LIST")
	public static GMMap consumerLoanGetSmsApplicationCreditUsageStatusList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			Date processDate = iMap.getDate("DATE", new Date());
			GMMap recordsMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_trn2052.get_sms_credit_payment_records (?)}", "RECORD_LIST", BnsprType.DATE, processDate);
			
			TransactionDao<CreditPayment> dao = new DalCreditPaymentDao();
			CommissionDao commissionDao = new GMCacheCommissionDao();
			
			for (int i = 0; i < recordsMap.getSize("RECORD_LIST"); i++) {
				
				
				oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i, "BASVURU_NO", recordsMap.getBigDecimal("RECORD_LIST", i, "BASVURU_NO"));
				oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i, "YAPILDI_EH", "E");
				oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i, "BANKA_ISLEM_NO", recordsMap.getBigDecimal("RECORD_LIST", i, "BANKA_ISLEM_NO"));
				oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i, "TUTAR", recordsMap.getBigDecimal("RECORD_LIST", i, "TUTAR"));
				oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i, "MASRAF", recordsMap.getBigDecimal("RECORD_LIST", i, "MASRAF"));
				
				oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i, "KAMPANYA_ADI", recordsMap.getString("RECORD_LIST", i, "KAMPANYA_ADI"));
				oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i, "KAMPANYA_KODU", recordsMap.getString("RECORD_LIST", i, "KAMPANYA_KODU"));
				oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i, "KONSOLIDASYON_EH", recordsMap.getString("RECORD_LIST", i, "KONSOLIDASYON_EH"));
				
				if(recordsMap.get("RECORD_LIST", i, "YAPILANDIRILAN_BASVURU_NO") != null) {
					
					String[] listeBasvuruNo = {recordsMap.getString("RECORD_LIST", i, "YAPILANDIRILAN_BASVURU_NO")};
					if(recordsMap.getString("RECORD_LIST", i, "YAPILANDIRILAN_BASVURU_NO").contains(",")){
						listeBasvuruNo = recordsMap.getString("RECORD_LIST", i, "YAPILANDIRILAN_BASVURU_NO").split(",");
					}
					
					String[] listeTxNo = {recordsMap.getString("RECORD_LIST", i,"YAPILANDIRILAN_TX_NO")};
					if(recordsMap.getString("RECORD_LIST", i,"YAPILANDIRILAN_TX_NO").contains(",")){
						listeTxNo = recordsMap.getString("RECORD_LIST", i,"YAPILANDIRILAN_TX_NO").split(",");
					}
							
					GMMap yapilandirilanBasvuruListesiMap= new GMMap();
					
					for(int j = 0; j < listeBasvuruNo.length; j++) {
						yapilandirilanBasvuruListesiMap.put("yapilandirilanBasvuruListesi", j, "basvuruNo", listeBasvuruNo[j].trim());
						yapilandirilanBasvuruListesiMap.put("yapilandirilanBasvuruListesi", j, "islemNo", listeTxNo[j].trim());
					}
				
					oMap.put("SMS_KULLANDIRIM_DURUM_LIST", i,"yapilandirilanBasvuruListesi", yapilandirilanBasvuruListesiMap.get("yapilandirilanBasvuruListesi"));
					
				}

				
//				oMap.put("SMS_KULLANDIRIM_LIST", i, "TC_KIMLIK_NO", recordsMap.getString("RECORD_LIST", i, "TC_KIMLIK_NO"));
//				oMap.put("SMS_KULLANDIRIM_LIST", i, "BASVURU_NO", recordsMap.getBigDecimal("RECORD_LIST", i, "BASVURU_NO"));
//				oMap.put("SMS_KULLANDIRIM_LIST", i, "AD", recordsMap.getString("RECORD_LIST", i, "AD"));
//				oMap.put("SMS_KULLANDIRIM_LIST", i, "SOYAD", recordsMap.getString("RECORD_LIST", i, "SOYAD"));
//				oMap.put("SMS_KULLANDIRIM_LIST", i, "TUTAR", recordsMap.getBigDecimal("RECORD_LIST", i, "TUTAR"));
//				oMap.put("SMS_KULLANDIRIM_LIST", i, "MASRAF", recordsMap.getBigDecimal("RECORD_LIST", i, "MASRAF"));
//				oMap.put("SMS_KULLANDIRIM_LIST", i, "BANKA_ISLEM_NO", recordsMap.getBigDecimal("RECORD_LIST", i, "BANKA_ISLEM_NO"));

				ClksBirBasvuruSmsTalep talep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class,
					recordsMap.getBigDecimal("RECORD_LIST", i, "BASVURU_NO"));
				talep.setDurumKodu(SMS_APPLICATION_STATU_USAGE_SEND);
				talep.setKullandirimDurumTarih(new Date());
				BigDecimal creditAmount = talep.getTutar();
				session.saveOrUpdate(talep);
				
				CreditPayment payment = new CreditPayment(recordsMap.getBigDecimal("RECORD_LIST", i, "BANKA_ISLEM_NO"));
				payment.setAmount(creditAmount);
				payment.setCurrency(CurrencyType.TRY);
				
				BirBasvuru basvuru = (BirBasvuru) session.get(BirBasvuru.class, recordsMap.getBigDecimal("RECORD_LIST", i, "BASVURU_NO"));
				
				payment.setCommissionCategory(Arrays.asList("1", "2", "3").contains(
					basvuru.getPttMaasAlinanKurum()) ? CommissionCategory.KREDI_KULLANDIRIM_EMEKLI : "4".equals(basvuru
					.getPttMaasAlinanKurum()) ? CommissionCategory.KREDI_KULLANDIRIM_PERSONEL
					: CommissionCategory.KREDI_KULLANDIRIM_DIGER);

				CommissionContext commissionContext = new CommissionContext(payment.commissionCategory()
					.getStrategyClass().
					getDeclaredConstructor(List.class).
					newInstance(
						commissionDao.getByCommissionCategory(
								payment.commissionCategory())));

//				Record commissionRecord = commissionContext.calculate(new Record(payment.amount(),
//					payment.currency()));
//				payment.setCommissionAmount(commissionRecord.getAmount());
//				payment.setCommissionCurrency(commissionRecord.getCurrency());
//				dao.saveCommission(payment);
			}
			session.flush();
			
			return oMap;

		}
		catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_CREDIT_USAGE_STATUS_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_CREDIT_USAGE_READY_LIST")
	public static GMMap consumerLoanGetSmsApplicationCreditUsageReadyList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			Date processDate = iMap.getDate("DATE", new Date());
			
			
			GMMap recordsMap = GMServiceExecuter.call("BNSPR_OTOMATIK_PTT_SMS_KULLANDIRIM_LIST",
					new GMMap());
			int counter=0;
			for (int i = 0; i < recordsMap.getSize("RESULTS"); i++) {
				
				ClksBirBasvuruSmsTalep talep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class,
						recordsMap.getBigDecimal("RESULTS", i, "BASVURU_NO"));
				
				if (SMS_APPLICATION_STATU_SEND.equals(talep.getDurumKodu())) {
					
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "TC_KIMLIK_NO", recordsMap.getString("RESULTS", i, "TC_KIMLIK_NO"));
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "BASVURU_NO", recordsMap.getBigDecimal("RESULTS", i, "BASVURU_NO"));
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "AD", recordsMap.getString("RESULTS", i, "AD"));
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "SOYAD", recordsMap.getString("RESULTS", i, "SOYAD"));
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "TUTAR", recordsMap.getBigDecimal("RESULTS", i, "TUTAR"));
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "MASRAF", recordsMap.getBigDecimal("RESULTS", i, "MASRAF"));
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "BANKA_ISLEM_NO", recordsMap.getBigDecimal("RESULTS", i, "BANKA_ISLEM_NO"));
//		ahmetlerin servisten alaca��z ya da biz �ekip alaca��z			
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "KAMPANYA_ADI", recordsMap.getString("RESULTS", i, "KAMPANYA_ADI"));
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "KAMPANYA_KODU", recordsMap.getString("RESULTS", i, "KAMPANYA_KODU"));
					oMap.put("SMS_KULLANDIRIM_LIST", counter, "KONSOLIDASYON_EH", recordsMap.getString("RESULTS", i, "BIRLESTIRME_EH"));
					
					
					talep.setDurumKodu(SMS_APPLICATION_STATU_USAGE_READY);
					talep.setKullandirimHazirTarih(new Date());
					session.saveOrUpdate(talep);
					counter++;
				}
				
			}
			session.flush();
			
			return oMap;

		}
		catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_CREDIT_USAGE_READY_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_CREATE_SMS_APPLICATION_PREAPPROVE_WRAPPER")
	public static GMMap consumerLoanCreateSmsApplicationPreApproveWrapper(GMMap iMap) {

		try {
			GMServiceExecuter.executeAsync("BNSPR_CLKS_CONSUMERLOAN_CREATE_SMS_APPLICATION_PREAPPROVE", iMap
				.getMap("APPLICATION_MAP"));
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_CREATE_SMS_APPLICATION_PREAPPROVE_WRAPPER err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_CREATE_SMS_APPLICATION_PREAPPROVE")
	public static GMMap consumerLoanCreateSmsApplicationPreApprove(GMMap iMap) {
		
		GMMap applicationMap = new GMMap();
		
		try {
			
			if ("BULK".equals(iMap.getString("KAYNAK"))) {
				applicationMap = GMServiceExecuter.call("BNSPR_TRN3172_EVALUATE_PTT_BULK_APPLICATION", 
						new GMMap().put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")));
			}
			else {
				applicationMap = GMServiceExecuter.call("BNSPR_CL_PTT_CREATE_SMS_PREAPPROVE", 
						new GMMap().put("TRX_NO", iMap.getBigDecimal("TRX_NO")).put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"))
						.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("CEP_TEL_ALAN_KODU", iMap.getString("CEP_TEL_ALAN_KODU"))
						.put("CEP_TEL_NO", iMap.getString("CEP_TEL_NO")).put("KAYNAK", iMap.getString("KAYNAK")));

				String message = null;

				if ("ONAY".equals(applicationMap.getString("DURUM"))) {
					message = API.message(5972, applicationMap.getString("ADI_SOYADI"), applicationMap.getString("ONAY_TUTAR"), applicationMap.getString("ONAY_VADE"));
				}
				else if ("RED".equals(applicationMap.getString("DURUM"))) {
					message = API.message(5973, applicationMap.getString("ADI_SOYADI"));
				}
				else if ("HATA".equals(applicationMap.getString("DURUM"))) {
					message = API.message(5974);
				}
				Session session = DAOSession.getSession("BNSPRDal");

				ClksBirBasvuruSmsTalep talep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class, iMap.getBigDecimal("BASVURU_NO"));

				if (isSMSSendableChannel(talep.getKanal())) {
					if (message != null) {
						GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", iMap.getString("MSISDN")).put("CONTENT", message));
					}
				}
			}
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_CREATE_SMS_APPLICATION_PREAPPROVE err:", e);
		}
		
		return applicationMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_INFO_FOR_FEEDBACK")
	public static GMMap consumerLoanApplicationInfoForFeedback(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String feedbackStatus = null;
			BigDecimal applicationNo = null;
			String info = null;
			
			for (int i = 0; i < iMap.getSize("GERI_BILDIRIM_LIST"); i++) {
				applicationNo = iMap.getBigDecimal("GERI_BILDIRIM_LIST", i, "BASVURU_NO");
				feedbackStatus = iMap.getString("GERI_BILDIRIM_LIST", i, "DURUM");
				info = iMap.getString("GERI_BILDIRIM_LIST", i, "ACIKLAMA");
				
				if (i == 0 && applicationNo != null && applicationNo.compareTo(BigDecimal.ZERO) == 0) {
					
					String updateLastXMinutes = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "CLKS_SMS_KREDI_FEEDBACK").put("KEY", "UPDATE_LAST_X_MINUTES")).getString("TEXT");
					int lastXMinutes = Integer.valueOf("-".concat(updateLastXMinutes));
					
					if ("B".equals(feedbackStatus)) {
						List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
																				 .add(Restrictions.eq("durumKodu", SMS_APPLICATION_STATU_SEND))
						 														 .add(Restrictions.ge("basvuruDurumTarih", addMinute(new Date(), lastXMinutes))).list();
						for(ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep:clksBirBasvuruSmsTalepList) {
							clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_SEND_READY);
							session.update(clksBirBasvuruSmsTalep);
						}
						
					} else if ("K".equals(feedbackStatus)) {
						List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
																				 .add(Restrictions.eq("durumKodu", SMS_APPLICATION_STATU_USAGE))
																				 .add(Restrictions.ge("kullandirimDurumTarih", addMinute(new Date(), lastXMinutes))).list();
						for(ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep:clksBirBasvuruSmsTalepList) {
							clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_SEND);
							session.update(clksBirBasvuruSmsTalep);
						}						
						
					} else if ("T".equals(feedbackStatus)) {
						List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
																				 .add(Restrictions.eq("durumKodu", SMS_APPLICATION_STATU_PENDING))
																				 .add(Restrictions.ge("processDate", addMinute(new Date(), lastXMinutes))).list();
						for(ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep:clksBirBasvuruSmsTalepList) {
							clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_INITIAL);
							session.update(clksBirBasvuruSmsTalep);
						}
						
					}
					break;
				}
					
				if ("B".equals(feedbackStatus)) {
					Map<String, Object> restrictions = new HashMap<String, Object>();
					restrictions.put("durumKodu", SMS_APPLICATION_STATU_SEND);
					restrictions.put("basvuruNo", applicationNo);
					
					ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session.createCriteria(ClksBirBasvuruSmsTalep.class)
																				.add(Restrictions.allEq(restrictions)).uniqueResult();
					clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_APPROVED);
					clksBirBasvuruSmsTalep.setAciklama(info);
					
					session.update(clksBirBasvuruSmsTalep);
					
				} else if ("K".equals(feedbackStatus)) {
					Map<String, Object> restrictions = new HashMap<String, Object>();
					restrictions.put("durumKodu", SMS_APPLICATION_STATU_USAGE_READY);
					restrictions.put("basvuruNo", applicationNo);
					
					ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session.createCriteria(ClksBirBasvuruSmsTalep.class)
																				.add(Restrictions.allEq(restrictions)).uniqueResult();
					if (StringUtil.isEmpty(info)) {
						clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_USAGE);
						clksBirBasvuruSmsTalep.setAciklama(info);
					}
					else {
						clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_SEND);
						clksBirBasvuruSmsTalep.setAciklama(info);
					}
					
					session.update(clksBirBasvuruSmsTalep);
					
				}else if ("P".equals(feedbackStatus)) {
					Map<String, Object> restrictions = new HashMap<String, Object>();
					restrictions.put("durumKodu", SMS_APPLICATION_STATU_USAGE_SEND);
					restrictions.put("basvuruNo", applicationNo);
					
					ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session.createCriteria(ClksBirBasvuruSmsTalep.class)
																				.add(Restrictions.allEq(restrictions)).uniqueResult();
					if (StringUtil.isEmpty(info)) {
						clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_USAGE_COMPLETED);
						clksBirBasvuruSmsTalep.setAciklama(info);
					}
					else {
						clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_USAGE);
						clksBirBasvuruSmsTalep.setAciklama(info);
					}
					
					session.update(clksBirBasvuruSmsTalep);
					
				}
			}
		
			session.flush();
			return oMap;
		}
		catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_APPLICATION_INFO_FOR_FEEDBACK err:", e);
			throw ExceptionHandler.convertException(e);
		}

	}	
	
	@GraymoundService("BNSPR_PTT_SMS_KULLANDIRIM_KONTROL")
	public static GMMap controlSMSCreditUsageStaus(GMMap iMap) {
		GMMap outmap= new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			ClksBirBasvuruSmsTalep talep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class,
					iMap.getBigDecimal("BASVURU_NO"));
			
			iMap.put("TC_KIMLIK_NO", talep.getTcKimlikNo());
			
			if (SMS_APPLICATION_STATU_USAGE.equals(talep.getDurumKodu())) {
				outmap.put("KULLANDIRILABILIR_EH", "E");			                 
			}
			else {
				outmap.put("KULLANDIRILABILIR_EH", "H");			                 
				outmap.put("ACIKLAMA", talep.getAciklama());
			}
			GMMap pchMap = 	GMServiceExecuter.call("BNSPR_PTT_EMEKLI_PCH_SORGULA", iMap);
			
			if (!"E".equals(pchMap.getString("PCH_DURUMU"))) {
				outmap.put("KULLANDIRILABILIR_EH", "H");			                 
				outmap.put("ACIKLAMA", "P�H durumu uygun de�il");
				talep.setAciklama("P�H durumu uygun de�il");
				session.saveOrUpdate(talep);
				session.flush();
			}
		
		} catch(Exception e) {
			logger.error("BNSPR_PTT_SMS_KULLANDIRIM_KONTROL err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return outmap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_SEND_SMS_FOR_PENDING_SMS_CREDIT_APPLICATION")
	public static GMMap consumerLoanSendSmsForPendingSmsCreditApplication(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String message = null;
			
			DateFormat shortDateTimeFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date beginDate = addDay(new Date(),-1);
			Date endDate = new Date();	
//					String updateLastXMinutes = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "CLKS_SMS_KREDI_FEEDBACK").put("KEY", "PENDING_X_MINUTES")).getString("TEXT");
//					int lastXMinutes = Integer.valueOf("-".concat(updateLastXMinutes));
					
						List<ClksBirBasvuruSmsTalep> clksBirBasvuruSmsTalepList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
																					.add(Restrictions.eq("durumKodu", SMS_APPLICATION_STATU_PENDING))
																					.add(Restrictions.ge("processDate", shortDateTimeFormat.parse(shortDateTimeFormat.format(beginDate))))
																					.add(Restrictions.lt("processDate", shortDateTimeFormat.parse(shortDateTimeFormat.format(endDate))))
																					.list();
					
					for(ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep:clksBirBasvuruSmsTalepList) {
						List<ClksBirBasvuruSmsTalep> basvuruSmsTalepApprovedList = session.createCriteria(ClksBirBasvuruSmsTalep.class)
								.add(Restrictions.eq("durumKodu", SMS_APPLICATION_STATU_APPROVED))
								.add(Restrictions.ge("processDate", shortDateTimeFormat.parse(shortDateTimeFormat.format(beginDate))))
								.add(Restrictions.lt("processDate", shortDateTimeFormat.parse(shortDateTimeFormat.format(endDate))))
								.add(Restrictions.eq("tcKimlikNo", clksBirBasvuruSmsTalep.getTcKimlikNo()))
								.list();
						
						clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_FAIL);
						
						if(basvuruSmsTalepApprovedList.isEmpty()){
							message = API.message(5976);
							if(message != null) {
								if (isSMSSendableChannel(clksBirBasvuruSmsTalep.getKanal())) {
								GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", clksBirBasvuruSmsTalep.getMsisdn())
									.put("CONTENT", message));
								}
							}
							clksBirBasvuruSmsTalep.setAciklama(message);
							session.update(clksBirBasvuruSmsTalep);
						}else{
							message = API.message(6170);
							clksBirBasvuruSmsTalep.setAciklama(message);
							session.update(clksBirBasvuruSmsTalep);
						}
					}	
			session.flush();
		}
		catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_SEND_SMS_FOR_PENDING_SMS_CREDIT_APPLICATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
    @GraymoundService("BNSPR_CLKS_CONSUMERLOAN_CANCEL_INITIAL_SMS_CREDIT_APPLICATION_FOR_RETIREE_APPLICATION")
    public static GMMap consumerLoanCancelInitialSmsCreditApplicationForRetireeApplication(GMMap iMap){

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String message = null;
			 
			String tckn = iMap.getString("TC_KIMLIK_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO"); 
			
			ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep =(ClksBirBasvuruSmsTalep) session.createCriteria(ClksBirBasvuruSmsTalep.class)
																					.add(Restrictions.eq("durumKodu", SMS_APPLICATION_STATU_INITIAL))
																					.add(Restrictions.eq("tcKimlikNo", tckn))
  																					.uniqueResult();
					
				if(clksBirBasvuruSmsTalep != null && !clksBirBasvuruSmsTalep.getBasvuruNo().equals(basvuruNo)){
						message = API.message(6138); //PTT �ubesinden giri� yap�lmas�
						//if(message != null) {
						//		if (isSMSSendableChannel(clksBirBasvuruSmsTalep.getKanal())) {
						//				GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", clksBirBasvuruSmsTalep.getMsisdn()).put("CONTENT", message)); }
						//}
						clksBirBasvuruSmsTalep.setDurumKodu(SMS_APPLICATION_STATU_FAIL);
						clksBirBasvuruSmsTalep.setAciklama(message);
						session.update(clksBirBasvuruSmsTalep);
					}	
				session.flush();
		}
		catch (Exception e) {
			logger.error("BNSPR_CLKS_CONSUMERLOAN_CANCEL_INITIAL_SMS_CREDIT_APPLICATION_FOR_RETIREE_APPLICATION err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CLKS_CONSUMERLOAN_GET_SMS_APPLICATION_INFO")
	public static GMMap consumerLoanGetSmsApplicationInfo(GMMap iMap) {
		GMMap outMap  = new GMMap();
		GMMap resultMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String smsCreditCampaignCode = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "CLKS_SMS_KREDI").put("KEY", "KAMPANYA_KODU")).getString("TEXT");
		String smsCreditCampaignName = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "CLKS_SMS_KREDI").put("KEY", "KAMPANYA_ADI")).getString("TEXT");
		String smsCreditValidationDay = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "CLKS_SMS_KREDI").put("KEY", "GECERLILIK_GUN_SAYISI")).getString("TEXT");


		resultMap = GMServiceExecuter.call("BNSPR_CL_PTT_SMS_YARIM_BASVURU", new GMMap().put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO")));
		if (StringUtil.isEmpty(resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"BASVURU_NO"))) {
			outMap.put("SMSKREDI","H");

		}else if("H".equals(resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"BASVURU_GIREBILIR"))&&
				"H".equals(resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"SOZLESME_BASABILIR"))){
			outMap.put("SMSKREDI","H");

		}else{
			BigDecimal basvuruNo = resultMap.getBigDecimal("PTT_SMS_YARIM_BASVURU",0,"BASVURU_NO");
			
			ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class,
					basvuruNo);
			Date controlDate = clksBirBasvuruSmsTalep.getProcessDate();
			for (int i = 0; i < Integer.parseInt(smsCreditValidationDay); i++) {
				controlDate = getNextWorkingDay(controlDate);
			}
			if (subtractDatesToDays(new Date(),controlDate)>0) {
				outMap.put("SMSKREDI","H");
			}else{
				 outMap.put("SMSKREDI","E");
				 outMap.put("BASVURU_NO", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"BASVURU_NO"));
				 outMap.put("DURUM_KODU", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"DURUM_KODU"));
				 outMap.put("BASVURU_GIREBILIR", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"BASVURU_GIREBILIR"));
				 outMap.put("SOZLESME_BASABILIR", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"SOZLESME_BASABILIR"));
				 outMap.put("KURYE_CIKTI", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"KURYE_CIKTI"));
				 outMap.put("ACIKLAMA", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"DURUM_MESAJI"));
				 outMap.put("KAMPANYA_KODU", smsCreditCampaignCode);
				 outMap.put("KAMPANYA_ADI", smsCreditCampaignName);

				 
			}
		
		}	
		if (!StringUtil.isEmpty(resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"DURUM_MESAJI"))) {
			 outMap.put("SMSKREDI","E");
			 outMap.put("BASVURU_NO", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"BASVURU_NO"));
			 outMap.put("ACIKLAMA", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"DURUM_MESAJI"));
			 outMap.put("KAMPANYA_KODU", smsCreditCampaignCode);
			 outMap.put("KAMPANYA_ADI", smsCreditCampaignName);
			 outMap.put("SOZLESME_BASABILIR", resultMap.getString("PTT_SMS_YARIM_BASVURU",0,"SOZLESME_BASABILIR"));
		}
		
		 return outMap;
		
	}
	
	public static Date getDateRefusedSendStartTime(String refusedSendStartTime) throws ParseException {
		DateFormat shortDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
		String shortDateString = shortDateTimeFormat.format(new Date());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
		return dateFormat.parse(shortDateString+refusedSendStartTime);
		
	}
	
	public static Date addMinute(Date date, int dayCount) {
		Calendar defaultCalendar = Calendar.getInstance();
		defaultCalendar.setTime(date);
		defaultCalendar.add(Calendar.MINUTE, dayCount);
		return defaultCalendar.getTime();
	}
	
	public static Date addDay(Date date, int dayCount) {
		Calendar defaultCalendar = Calendar.getInstance();
		defaultCalendar.setTime(date);
		defaultCalendar.add(Calendar.DATE, dayCount);
		return defaultCalendar.getTime();
	}
	
	public static long subtractDatesToDays(Date first, Date second) {
		GregorianCalendar c1 = new GregorianCalendar();
		GregorianCalendar c2 = new GregorianCalendar();
		c1.setTime(second);
		c2.setTime(first);
		long span = c2.getTimeInMillis() - c1.getTimeInMillis();
		GregorianCalendar c3 = new GregorianCalendar();
		c3.setTimeInMillis(span);
		return c3.getTimeInMillis() / milisecondCountInADay;
	}
	
	
	public static boolean isSMSSendableChannel(String channel) {
		String isSMSSendableChannel = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
				new GMMap().put("KOD", "CLKS_SMS_KREDI_SMS_ATILABILIR_KANAL").put("KEY", channel))
				.getString("TEXT");
		if ("E".equals(isSMSSendableChannel)) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public static Date getNextWorkingDay(Date dateTime) {
		GMMap map = new GMMap();
		map.put("TARIH", dateTime);
		Date nextWorkingDay = new Date();
		try {
			nextWorkingDay = GMServiceExecuter.call("INTERNET_ILERI_IS_GUNU", map).getDate("RESULT");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nextWorkingDay;
	}
}
