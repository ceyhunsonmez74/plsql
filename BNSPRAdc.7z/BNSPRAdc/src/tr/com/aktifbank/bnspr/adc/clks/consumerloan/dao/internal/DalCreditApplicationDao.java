package tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;

import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application.STATUS;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Campaign;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Institution;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.InstitutionFactory;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.PensionPayment;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.SgkInstitution;
import tr.com.aktifbank.bnspr.adc.clks.customer.model.PersonalCustomer;
import tr.com.aktifbank.bnspr.dao.ClksBbBorcTransferi;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruDogrulama;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruKomSmsSube;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruKomisyon;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.dao.ClksBirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.dao.ClksBirBasvuruTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.dao.DAOSession;

public class DalCreditApplicationDao implements CreditApplicationDao<Application> {

	@Override
	public List<Application> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Application get(Serializable id) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.createCriteria(ClksBirBasvuruTx.class).add(
			Restrictions.eq("basvuruNo", id)).uniqueResult();
		ClksBirBasvuruKimlikTx clksBirBasvuruKimlikTx = (ClksBirBasvuruKimlikTx) session.get(ClksBirBasvuruKimlikTx.class,
			clksBirBasvuruTx.getTxNo());
		ClksBirBasvuruKomisyon clksBirBasvuruKomisyon = (ClksBirBasvuruKomisyon) session.get(
			ClksBirBasvuruKomisyon.class, id);
		BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, id);
		
		if(birBasvuru != null) {
			session.refresh(birBasvuru);
		}
		
		Application application = new Application(birBasvuru.getBasvuruNo(), birBasvuru.getTcKimlikNo(), birBasvuru
			.getTutar(), birBasvuru.getVade().intValue(), new Campaign.Builder(birBasvuru.getKampKod(), birBasvuru
			.getKampKnlKod()).build());
		application.setTrxNo(clksBirBasvuruTx.getTxNo());
		application.setCurrency(CurrencyType.getEnum(birBasvuru.getDovizKodu()));
		application.setCustomer(new PersonalCustomer(birBasvuru.getMusteriNo(), birBasvuru.getTcKimlikNo()));
		application.getCustomer().setFirstName(clksBirBasvuruKimlikTx.getAd());
		application.getCustomer().setSecondaryName(clksBirBasvuruKimlikTx.getIkinciAd());
		application.getCustomer().setLastName(clksBirBasvuruKimlikTx.getSoyad());
		application.setStatus(Application.STATUS.getEnum(birBasvuru.getDurumKodu()));
		application.setInstitution(InstitutionFactory.getInstitution(Institution.ShortCode.getEnum(birBasvuru
			.getPttMaasAlinanKurum())));
		application.setMobilePhone(String.format("%s%s", clksBirBasvuruKimlikTx.getCepTelAlanKodu(),
			clksBirBasvuruKimlikTx.getCepTelNo()));
		
		if(clksBirBasvuruKomisyon != null) {
			application.setCommission(new Record(clksBirBasvuruKomisyon.getTutar(), CurrencyType
				.getEnum(clksBirBasvuruKomisyon.getDovizKodu())));
			application.setCommissionCategory(CommissionCategory.getEnum(clksBirBasvuruKomisyon.getKomisyonTuru()));
		}
		application.setQualifiedCommission("E".equals(clksBirBasvuruTx.getfNitelikliRed()) ? true : false);

		Campaign campaign = application.getCampaign();
		BirKampanya birKampanya = (BirKampanya) session.get(BirKampanya.class, campaign.getCode());
		
		campaign.setAccountBlockCode(birKampanya.getKulBlokeKodu());
		campaign.setAllIncluded("E".equals(birKampanya.getHerseyDahilEh()) ? true : false);
		campaign.setBalanceTransfer("E".equals(birKampanya.getBorcTransferiEh()) ? true : false);
		campaign.setPublicCredit("E".equals(birKampanya.getUcuncuSahisEh()) ? true : false);
		campaign.setConsolidation("E".equals(birKampanya.getBirlestirmeEh()) ? true : false);
		campaign.setCreditType(Campaign.CreditType.getEnum(birKampanya.getKrdTurKod().intValue()));
		campaign.setVisualImpairment("E".equals(birKampanya.getGormeEngelliEh()) ? true : false);
		campaign.setConsolidationOnChannel("E".equals(birKampanya.getPttIciBirlestirmeEh()) ? true: false);
		campaign.setRelation(campaign.getRelation() == null ? "4".equals(birBasvuru.getPttMaasAlinanKurum())
			? Campaign.Relation.PERSONNEL : Campaign.Relation.RETIREE : campaign.getRelation());
		
		if(campaign.isBalanceTransfer()) {
			ClksBbBorcTransferi clksBbBorcTransferi = (ClksBbBorcTransferi) session.get(ClksBbBorcTransferi.class,
				application.getApplicationNo());
			application.setBankCode(clksBbBorcTransferi.getBankaKod());
			application.setBankBranchCode(clksBbBorcTransferi.getSubeKod());
		}
		
		// TODO Assign amount and term limits of campaign

		Institution institution = InstitutionFactory.getInstitution(Institution.ShortCode.getEnum(birBasvuru
			.getPttMaasAlinanKurum()));
				
		if(EnumSet.of(Institution.ShortCode.SSK, Institution.ShortCode.EMEKLI_SANDIGI).contains(
			institution.getShortCode())) {
			application.setSelectedSalary(new PensionPayment((SgkInstitution) institution, birBasvuru
				.getPttTahsisNumarasi(), null, null, null, 1));

		} else if(Institution.ShortCode.BAGKUR == institution.getShortCode()) {
			application.setSelectedSalary(new PensionPayment((SgkInstitution) institution, null, birBasvuru
				.getPttTahsisNumarasi(), null, null, 1));
		}
			
		return application;
	}

	@Override
	public List<Application> filter(Map<String, Object> criteria) {

		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<BirBasvuru> birBasvuruList = session.createCriteria(BirBasvuru.class).add(Restrictions.allEq(criteria)).list();
		List<Application> applicationList = new ArrayList<Application>();
		
		for(BirBasvuru birBasvuru : birBasvuruList) {
			BigDecimal applicationNumber = birBasvuru.getBasvuruNo();
			Application application = get(applicationNumber);
			applicationList.add(application);
		}
		
		return applicationList;
	}

	@Override
	public void save(Application application) {
		
		Session session = DAOSession.getSession("BNSPRDal");

		ClksBirBasvuruTx clksBirBasvuruTx = (ClksBirBasvuruTx) session.get(ClksBirBasvuruTx.class, application
			.getTrxNo(), LockMode.UPGRADE_NOWAIT);

		clksBirBasvuruTx.setBasvuruAdim(application.getStatus() == Application.STATUS.BELGE ? BigDecimal.valueOf(6)
			: clksBirBasvuruTx.getBasvuruAdim());
		clksBirBasvuruTx.setBasvuruSorunVarmi(application.isContractualRequestapprovedApproved() ? "H" : "E");
		clksBirBasvuruTx.setIslemiYapanKullaniciEvrak(application.getTeller().getRecord());
		clksBirBasvuruTx.setIsleminYapildigiIlEvrak(application.getBranch().getProvinceCode());
		clksBirBasvuruTx.setIsleminYapildigiSubeEvrak(application.getBranch().getBranchCode());
		clksBirBasvuruTx.setIsleminYapildigiMerkezEvrak(application.getBranch().getHeadBranchCode() != null
			? application.getBranch().getHeadBranchCode() : "1");
		clksBirBasvuruTx.setMerkezSubeBasmudurlukEvrak(application.getBranch().isHeadBranch() ? "M" : "S");
		clksBirBasvuruTx.setIslemYapilBasmudurlukEvrak(application.getBranch().getRegion().getLongCode());

		session.saveOrUpdate(clksBirBasvuruTx);
		session.flush();
	}

	@Override
	public void saveOrUpdate(Application application) {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void saveCommission(Application application) {
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		ClksBirBasvuruKomisyon record = (ClksBirBasvuruKomisyon) session.get(ClksBirBasvuruKomisyon.class, application
			.getApplicationNo());
		
		if(record != null) {
			if(application.getCommissionCategory().equals(CommissionCategory.KREDI_BASVURU_KABUL_EMEKLI_SMS)) {
				ClksBirBasvuruKomSmsSube subeSmsRecord = (ClksBirBasvuruKomSmsSube) session.get(ClksBirBasvuruKomSmsSube.class, application.getApplicationNo());
				if(subeSmsRecord == null) {
					subeSmsRecord = new ClksBirBasvuruKomSmsSube(application.getApplicationNo());
					subeSmsRecord.setDovizKodu(application.getCommissionCurrency().toString());
					subeSmsRecord.setTutar(application.getCommissionAmount());
					subeSmsRecord.setKomisyonTuru(application.getCommissionCategory().toString());
					subeSmsRecord.setKayitTarih(new java.util.Date());
					
					session.save(subeSmsRecord);
					session.flush();
				}
			}
			
			return;
		}
		
		record = new ClksBirBasvuruKomisyon(application.getApplicationNo());
		record.setDovizKodu(application.getCommissionCurrency().toString());
		record.setTutar(application.getCommissionAmount());
		record.setKomisyonTuru(application.getCommissionCategory().toString());
		record.setKayitTarih(new java.util.Date());
		
		session.save(record);
		session.flush();
	}

	@Override
	public String updateQualifiedCommissionOnReject(BigDecimal applicationNo, String nationalIdentificationNumber)
		throws SQLException {

		return (String) DALUtil.callOracleFunction("{? = call pkg_rc2062.kredi_basvuru_red_nitelik(?,?)}",
			BnsprType.STRING, BnsprType.NUMBER, applicationNo, BnsprType.STRING, nationalIdentificationNumber);
	}

	@Override
	public STATUS saveOrUpdateApplicationStatusOnQuery(BigDecimal applicationNo) throws SQLException {
		return STATUS.getEnum((String) DALUtil.callOracleFunction("{? = call pkg_rc2062.kredi_basvuru_durum_sorgu(?)}", 
			BnsprType.STRING, new Object[]{BnsprType.NUMBER, applicationNo}));
	}

	@Override
	public void saveAsPendingApplication(BigDecimal applicationNo, Application.STATUS status) throws SQLException {
		
		Session session = DAOSession.getSession("BNSPRDal");

		ClksBirBasvuruDogrulama record = (ClksBirBasvuruDogrulama) session.get(
			ClksBirBasvuruDogrulama.class, applicationNo);
		
		if(record != null) return;
		
		record = new ClksBirBasvuruDogrulama(applicationNo);
		record.setDurumKodu(status.toString());
		record.setBasvuruTarihi(new java.util.Date());
		
		session.save(record);
		session.flush();
	}
}
