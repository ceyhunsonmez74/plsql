package tr.com.aktifbank.bnspr.adc.clks.consumerloan.model;

public class PttInstitution implements Institution {
	
	private final ShortCode shortCode;
	private final CampaignType campaignType;

	public PttInstitution() {
		this.shortCode = ShortCode.PTT_PERSONEL;
		this.campaignType = CampaignType.PTT;
	}

	@Override
	public ShortCode getShortCode() {
		return shortCode;
	}

	@Override
	public CampaignType getCampaignType() {
		return campaignType;
	}
}
