package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

/**
 * PTT kanali kredi taksit tahsilati islem sinifi
 * 
 * @see Transaction
 */
public class InstallmentLoan extends Transaction {

	private static final long serialVersionUID = 7283662376664160211L;
	
	/**
	 * Kredi basvuru numarasi
	 */
	private BigDecimal applicationNo;
	private boolean earlyPayOff;
	private BigDecimal installmentNo;
	

	public InstallmentLoan(BigDecimal trxNo) {
		super(trxNo, (short) 3133);
	}

	/**
	 * @return {@link #applicationNo}
	 */
	public BigDecimal getApplicationNo() {
		return applicationNo;
	}

	/**
	 * @param applicationNo {@link #applicationNo}
	 */
	public void setApplicationNo(BigDecimal applicationNo) {
		this.applicationNo = applicationNo;
	}
	
	/**
	 * @return the earlyPayOff
	 */
	public boolean isEarlyPayOff() {
		return earlyPayOff;
	}

	/**
	 * @param earlyPayOff the earlyPayOff to set
	 */
	public void setEarlyPayOff(boolean earlyPayOff) {
		this.earlyPayOff = earlyPayOff;
	}
	
	/**
	 * @return the installmentNumber
	 */
	public BigDecimal getInstallmentNo() {
		return installmentNo;
	}

	/**
	 * @param installmentNumber the installmentNumber to set
	 */
	public void setInstallmentNumber(BigDecimal installmentNo) {
		this.installmentNo = installmentNo;
	}
	
}
