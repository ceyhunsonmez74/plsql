package tr.com.aktifbank.bnspr.adc.clks.core.model;

import java.io.Serializable;

public class Teller implements Serializable {
	
	private static final long serialVersionUID = -6408359015004117846L;

	/**
	 * Personel sicili
	 */
	private String record;
	
	/**
	 * Personel tam adi
	 */
	private String fullName;
	
	
	public Teller(String record, String fullName) {
		this.record = record;
		this.fullName = fullName;
	}

	/**
	 * @return the record
	 */
	public String getRecord() {
		return record;
	}

	/**
	 * @param record the record to set
	 */
	public void setRecord(String record) {
		this.record = record;
	}

	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
}
