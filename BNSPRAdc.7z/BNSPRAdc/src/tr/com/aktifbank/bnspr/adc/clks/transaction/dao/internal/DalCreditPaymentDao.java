package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CreditPayment;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;

import com.graymound.server.dao.DAOSession;

public class DalCreditPaymentDao extends DalTransactionDao<CreditPayment> implements TransactionDao<CreditPayment> {

	public DalCreditPaymentDao() {
		super(CreditPayment.class);
	}

	@Override
	public CreditPayment get(Serializable id) {
		Session session = DAOSession.getSession("BNSPRDal");
		ClksHavaleOdemeTx clksHavaleOdemeTx = (ClksHavaleOdemeTx) session.get(ClksHavaleOdemeTx.class, id);
		CreditPayment creditPayment = new CreditPayment(clksHavaleOdemeTx.getTxNo());
		creditPayment.setReferenceNo(new BigDecimal(clksHavaleOdemeTx.getReferansNo()));
		creditPayment.setAmount(clksHavaleOdemeTx.getTutar());
		creditPayment.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
		creditPayment.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
		return creditPayment;
	}

	@Override
	public List<CreditPayment> filter(Map<String, Object> criteria) {
		List<CreditPayment> creditPaymentList = new ArrayList<CreditPayment>();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<ClksHavaleOdemeTx> list = session.createCriteria(ClksHavaleOdemeTx.class).add(Restrictions.allEq(criteria))
			.list();

		for(ClksHavaleOdemeTx clksHavaleOdemeTx : list) {
			CreditPayment creditPayment = new CreditPayment(clksHavaleOdemeTx.getTxNo());
			creditPayment.setReferenceNo(new BigDecimal(clksHavaleOdemeTx.getReferansNo()));
			creditPayment.setAmount(clksHavaleOdemeTx.getTutar());
			creditPayment.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
			creditPayment.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
			creditPaymentList.add(creditPayment);
		}
		return creditPaymentList;
	}

	@Override
	public List<CreditPayment> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(CreditPayment type) {
		// TODO Auto-generated method stub		
	}

	@Override
	public void saveOrUpdate(CreditPayment type) {
		// TODO Auto-generated method stub
	}
}
