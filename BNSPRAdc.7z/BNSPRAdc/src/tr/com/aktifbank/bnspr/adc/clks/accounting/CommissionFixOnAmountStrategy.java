package tr.com.aktifbank.bnspr.adc.clks.accounting;

import java.util.List;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;

public class CommissionFixOnAmountStrategy extends CommissionOnAmount implements CommissionStrategy {
	private static Logger logger = Logger.getLogger(CommissionFixOnAmountStrategy.class);

	/**
	 * @param records
	 *            Komisyon barem listesi
	 */
	public CommissionFixOnAmountStrategy(List<CommissionRecord> records) {
		super(records);
	}

	@Override
	public Record calculate(Record transactionRecord) {

		logger.error("CommissionFixOnAmountStrategy - "
				+ "transactionRecord currency : " + transactionRecord.getCurrency() 
				+ " transactionRecord Amount : " + transactionRecord.getAmount());

		int counter = 0;
		for (CommissionRecord record : this.getRecords()) {

			logger.error("counter: " + counter 
					+ "record currency: " + record.getCurrency() 
					+ "record StartingAmount: " + record.getStartingAmount() 
					+ "record EndingAmount: " + record.getEndingAmount() 
					+ "record CommissionAmount: " + record.getCommissionAmount() 
					+ "record CommissionCurrency: " + record.getCommissionCurrency());

			if (transactionRecord.getCurrency() == record.getCurrency() 
					&& transactionRecord.getAmount().compareTo(record.getStartingAmount()) >= 0 
					&& transactionRecord.getAmount().compareTo(record.getEndingAmount()) <= 0) 
			{
				logger.error("CommissionFixOnAmountStrategy -  finish return ");						
				return new Record(record.getCommissionAmount(), record.getCommissionCurrency());
			}
			counter++;
		}

		return null;
	}
}
