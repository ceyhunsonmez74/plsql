package tr.com.aktifbank.bnspr.adc.clks.services;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.core.api.CoreApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.core.api.internal.GMCoreApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalInstallmentLoanDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.InstallmentLoan;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class IntallmentLoanServices {

	private static Logger logger = Logger.getLogger(IntallmentLoanServices.class);
	private static CoreApplicationApi api = new GMCoreApplicationApi();
	private static final String MAIL_FROM = "System@aktifbank.com.tr";
	private static final String MAIL_SUBJECT_EARLY_PAYOFF = "PTT Kredi - Erken Kapama Uyar�s�";
	private static final String MAIL_SUBJECT_INSTALLMENT_RECEIVING = "PTT Kredi - Taksit Tahsilat� Uyar�s�";

	@GraymoundService("BNSPR_CLKS_INSTALLMENT_LOAN_CONFIRM")
	public static GMMap confirm(GMMap iMap) {

		GMMap oMap = new GMMap();
		InstallmentLoan installmentLoan = null;

		try {

			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("pttHavaleTxno", iMap.getBigDecimal("ISLEM_NO"));

			installmentLoan = new DalInstallmentLoanDao().filter(restrictions).get(0);

			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", new GMMap().put("ISLEM_NO",
				installmentLoan.trxNo()).put("ISLEM_TURU", "O").put("ISLEM_KODU",
				BigDecimal.valueOf(installmentLoan.trxCode())));

			return oMap;

		} catch(Exception e) {
			String mailAddressTo = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K",
				new GMMap().put("PARAMETRE", "CLKS_KRD_SORUNLU_THSLT_MAIL_TO")).getString(("DEGER"));
			GMMap mailInMap = new GMMap();
			mailInMap.put("TO", mailAddressTo);
			mailInMap.put("ISLEM_NO", installmentLoan.trxNo());
			if(installmentLoan.isEarlyPayOff()) {
				mailInMap.put("SUBJECT", MAIL_SUBJECT_EARLY_PAYOFF);
				mailInMap.put("BODY", installmentLoan.getApplicationNo().toString()
					+ " ba�vuru numaral� kredinin erken kapama i�lemi s�ras�nda hata al�nm��t�r.");
			} else {
				mailInMap.put("SUBJECT", MAIL_SUBJECT_INSTALLMENT_RECEIVING);
				mailInMap.put("BODY", installmentLoan.getApplicationNo().toString() + " ba�vuru numaral� kredinin "
					+ installmentLoan.getInstallmentNo() + " no'lu taksit tahsilat� i�lemi s�ras�nda hata al�nm��t�r.");
			}
			GMServiceExecuter.executeNT("BNSPR_CLKS_INSTALLMENT_LOAN_ERROR_SENDMAIL", mailInMap);

			logger.error("BNSPR_CLKS_INSTALLMENT_LOAN_CONFIRM err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_CLKS_INSTALLMENT_LOAN_ERROR_SENDMAIL")
	public static GMMap sendMailForInstallmentLoan(GMMap iMap) {
		try {
			api.sendMail(MAIL_FROM, iMap.getString("TO"), iMap.getString("SUBJECT"), iMap.getString("BODY"), false,
				iMap.getBigDecimal("ISLEM_NO"));
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_INSTALLMENT_LOAN_ERROR_SENDMAIL err:", e);
			throw ExceptionHandler.convertException(e);
		}
		return new GMMap();
	}
}
