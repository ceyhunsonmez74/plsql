package tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.CommissionDao;
import tr.com.aktifbank.bnspr.dao.ClksKomisyonPr;

import com.graymound.server.dao.DAOSession;

public class DalCommissionDao implements CommissionDao {

	@Override
	public List<CommissionRecord> getByCommissionCategory(CommissionCategory commissionCategory) {
		
		List<CommissionRecord> recordList = new ArrayList<CommissionRecord>();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		Map<String, String> restrictions = new HashMap<String, String>();
		restrictions.put("islemTuru", commissionCategory.toString());
		restrictions.put("masrafTuru", "T");
		
		@SuppressWarnings("unchecked")
		List<ClksKomisyonPr> records = session.createCriteria(ClksKomisyonPr.class).add(
			Restrictions.allEq(restrictions)).list();

		for(ClksKomisyonPr record : records) {
			
			recordList.add(new CommissionRecord.Builder(record.getMasrafBaslangicTutar(), record.getMasrafBitisTutar(), CurrencyType
				.getEnum(record.getIslemDovizKodu()))
					.commissionType("S".equals(record.getMasrafTipi()) ? CommissionType.FIX_AMOUNT : CommissionType.RATIO)
					.commissionAmount(record.getMasrafTutarOran())
					.commissionCurrency(CurrencyType.getEnum(record.getMasrafDovizKodu()))
					.minCommissionAmount(record.getMinTutar())
					.maxCommissionAmount(record.getMaxTutar()).build());
		}
		
		return recordList;
	}
}
