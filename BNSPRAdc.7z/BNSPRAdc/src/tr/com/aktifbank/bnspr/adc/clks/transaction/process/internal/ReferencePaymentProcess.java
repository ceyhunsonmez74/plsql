package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ReferencePayment;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class ReferencePaymentProcess extends TransactionBaseProcess<ReferencePayment> implements
	TransactionProcess<ReferencePayment> {
	
	private static Logger logger = Logger.getLogger(ReferencePaymentProcess.class);

	public ReferencePaymentProcess(TransactionDao<ReferencePayment> dao) {
		super(dao);
	}

	@Override
	public void request(ReferencePayment transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(ReferencePayment transaction) {
		super.confirm(transaction);
	}
}
