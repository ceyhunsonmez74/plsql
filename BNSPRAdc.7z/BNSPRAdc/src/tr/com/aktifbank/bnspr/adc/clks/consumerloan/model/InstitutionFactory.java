package tr.com.aktifbank.bnspr.adc.clks.consumerloan.model;

import java.util.EnumSet;
import java.util.Set;

/**
 * TBD
 * 
 * @author kaan.yanc
 */
public class InstitutionFactory {

	private static Set<Institution.ShortCode> sgkInstitutions = EnumSet.of(Institution.ShortCode.SSK,
		Institution.ShortCode.BAGKUR, Institution.ShortCode.EMEKLI_SANDIGI);
	private static Set<Institution.ShortCode> pttInstitutions = EnumSet.of(Institution.ShortCode.PTT_PERSONEL);
	private static Set<Institution.ShortCode> otherIntitutions = EnumSet.of(Institution.ShortCode.DIGER);

	public static Institution getInstitution(Institution.ShortCode code) {
		
		if(sgkInstitutions.contains(code))
			return SgkInstitution.valueOf(code);
		else if(pttInstitutions.contains(code))
			return new PttInstitution();
		else if(otherIntitutions.contains(code))
			return new OtherInstitution();
		else
			return null;
	}
}
