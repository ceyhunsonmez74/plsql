package tr.com.aktifbank.bnspr.adc.clks.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.internal.GMCreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal.DalCreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.PensionPayment;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.SgkInstitution;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal.CreditApplicationProcessImpl;
import tr.com.aktifbank.bnspr.adc.clks.core.api.CoreApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.core.api.internal.GMCoreApplicationApi;
import tr.com.aktifbank.bnspr.dao.ClksBbBorcTrOnboarding;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruDogrulama;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class SchedulerServices {

	private static Logger logger = Logger.getLogger(SchedulerServices.class);
	private static CoreApplicationApi api = new GMCoreApplicationApi();
	private static final String SYSTEM_MAIL_FROM = "System@aktifbank.com.tr";

	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CLKS_SCHEDULER_EFT_APPROVAL_AUTOMATION")
	public static GMMap eftApprovalAutomation(GMMap iMap) {

		String subeKod, subeKodBireysel = "444", kanalKod = "7", islemOnay = "O";
		BigDecimal ekranKod = new BigDecimal(2315);
		int limit;

		GMMap oMap = new GMMap();

		try {

			limit = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N",
				new GMMap().put("PARAMETRE", "CLKS_SCHEDULER_EAA_LIMIT")).getInt("DEGER");
			subeKod = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD", iMap).getString("SUBE_KOD");
			GMServiceExecuter.call("BNSPR_CORE_SET_USER_BRANCH", new GMMap().put("BRANCH_ID", subeKodBireysel));

			oMap = GMServiceExecuter.call("BNSPR_PFT_GELEN_KUTUSU_GET_RECORD", new GMMap().put("EKRAN_KOD", ekranKod)
				.put("KANAL_KOD", kanalKod).put("KRITER", islemOnay));

			limit = Math.max(oMap.getInt("ROW_COUNT") - limit, 0);

			if(!BigDecimal.ZERO.equals(oMap.getBigDecimal("ROW_COUNT"))) {

				// BNSPR_PFT_GELEN_KUTUSU_GET_RECORD servisi guncel kayitlari sirali olarak getiriyor.
				for(int i = oMap.getSize("RESULTS") - 1; i >= limit; i--) {

					GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", new GMMap().put("ISLEM_TURU",
						islemOnay).put("ISLEM_NO", oMap.getBigDecimal("RESULTS", i, "NO")).put("ISLEM_KODU", ekranKod)
						.put("ACIKLAMA", ""));
				}
			}

			GMServiceExecuter.call("BNSPR_CORE_SET_USER_BRANCH", new GMMap().put("BRANCH_ID", subeKod));
		}

		catch(Exception e) {
			logger.error("BNSPR_CLKS_SCHEDULER_EFT_APPROVAL_AUTOMATION err:", e);
		}

		return new GMMap();
	}
	
	/**
	 * 
	 * @param iMap {TARIH} 
	 * @return {@code GMMap}
	 * 
	 * @throws GMRuntimeException
	 * @see BNSPR_COMMON_GET_BANKA_TARIH
	 * @see BNSPR_CLKS_UNPAID_CREDIT_STATUS_UPDATE
	 */
	@GraymoundService("BNSPR_CLKS_SCHEDULER_CONSUMERLOAN_REVERSAL_OF_PENDING_APPLICATIONS")
	public static GMMap consumerLoanReversalOfPendingApplications(GMMap iMap) {

		GMMap oMap = new GMMap(), map = new GMMap();

		try {

			if(!iMap.containsKey("TARIH")) {
				iMap.put("TARIH", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap())
					.get("BANKA_TARIH"));
			}

			map = DALUtil.callOracleRefCursorFunction(
				"{ ? = call pkg_ptt_kredi.get_unpaid_credit_app_records(?,?,?) }", "RECORDS", BnsprType.DATE, iMap
					.getDate("TARIH"), BnsprType.NUMBER, null, BnsprType.STRING, null);

			for(int i = 0; i < map.getSize("RECORDS"); i++) {

				try {
					GMServiceExecuter.executeNT("BNSPR_CLKS_CONSUMERLOAN_REVERT_PENDING_APPLICATION", new GMMap().put(
						"TX_NO", map.getBigDecimal("RECORDS", i, "TX_NO")).put("BASVURU_NO",
						map.getBigDecimal("RECORDS", i, "BASVURU_NO")));
				}

				catch(Exception e) {
					api.sendMail(SYSTEM_MAIL_FROM, GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K",
						new GMMap().put("PARAMETRE", "CLKS_SCHEDULER_UCSU_MAIL_TO")).getString("DEGER"),
						"PTT - �demesi Tamamlanmam�� Kulland�r�m - Stat� G�ncelleme Hatas�", map.getBigDecimal(
							"RECORDS", i, "TX_NO")
							+ " - " + map.getBigDecimal("RECORDS", i, "BASVURU_NO") + " - " + e.getMessage(), false,
						map.getBigDecimal("RECORDS", i, "TX_NO"));
				}
			}
		}

		catch(Exception e) {
			logger.error("BNSPR_CLKS_SCHEDULER_CONSUMERLOAN_REVERSAL_OF_PENDING_APPLICATIONS err:", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * PTT kanalli borc transferi kredilerinde basvuru sureci sonrasi onboarding sureci kapsaminda basvuru sahiplerinin
	 * SGK maas tasima bilgisi ve KKB borc kapatma bilgisi sorgulanir. SGK maas tasima bilgisinde maasin tasindigi
	 * tespit edilir ise KKB borc kapatma sorgusu yapilmaz.
	 * 
	 * @return 			{@code AFFECTED_ROWS} key degerine es sorgulanan kayit sayisi, {@code SALARY_MOVED_ROWS} key
	 * 					degerine es maas tasima tespit edilen kayit sayisi, {@code DEBT_PAID_OFF_ROWS} altinda isi KKB 
	 * 					borcu kapatilmis kayit sayisi {@code GMMap} tipinde kapsanarak doner
	 * 
	 * @throws GMRuntimeException
	 * 
	 * @see BNSPR_SGK_EMEKLI_GET_EMEKLI_AYLIK_BILGILERI
	 * @see BNSPR_QRY3911_ONLINE_KKB_SORGULA
	 */
	@GraymoundService("BNSPR_CLKS_SCHEDULER_CONSUMERLOAN_BALANCE_TRANSFER_PROCESS_ONBOARDING")
	public static GMMap consumerLoanBalanceTransferProcessOnboarding(GMMap iMap) {

		GMMap oMap = new GMMap();
		String primaryIdType = "6", financeType = "90", dot = ".", birthDate = "19000101";
		int affectedRows = 0, salaryMovedRows = 0, debtPaidOffRows = 0;

		try {

			/* maas tas�ma = 1 ise sorgu �al��maz.
			 * maas tas�ma = 0 ve maas tas�ma s�resi a��lmam�� ise listeye al.
			 * kkb kapama 0 ve kkb s�resi a��lmam�� ise listeye al. 
			 * */

			iMap.put("TARIH", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap())
				.getDate("BANKA_TARIH"));

			Session session = DAOSession.getSession("BNSPRDal");
			// Criteria criteria = session.createCriteria(ClksBbBorcTrOnboarding.class);

			@SuppressWarnings("unchecked")
			List<ClksBbBorcTrOnboarding> applications = session
				.createQuery(
					"from ClksBbBorcTrOnboarding where ( ( kkbBorcKapatma = 0 and kkbBorcKapatmaTarih > SYSDATE - sorguKontrolGun) or sorguTarih > SYSDATE - maasSorguKontrolGun ) and maasTasima = 0")
				.list();

			for(ClksBbBorcTrOnboarding application : applications) {

				BirBasvuru applicationDetails = (BirBasvuru) session.get(BirBasvuru.class, application.getBasvuruNo());

				GMMap sgkMap = GMServiceExecuter.call("BNSPR_SGK_EMEKLI_GET_EMEKLI_AYLIK_BILGILERI", new GMMap().put(
					"TCKN", applicationDetails.getTcKimlikNo()).put("PARAM_REF_TUR", "ONBOARDING").put("PARAM_REF_ID",
					application.getBasvuruNo()));

				PensionPayment movedPayment = null;
				for(int i = 0; i < sgkMap.getSize("AYLIKLAR"); i++) {

					if(sgkMap.get("AYLIKLAR", i, "SIGORTA_KOLU") == null
						|| sgkMap.getString("AYLIKLAR", i, "SIGORTA_KOLU").isEmpty()) {
						continue;
					}

					String sicilNo = sgkMap.get("AYLIKLAR", i, "SICIL_NO") != null ? sgkMap.getString("AYLIKLAR", i,
						"SICIL_NO").trim() : "";
					String aylikId = sgkMap.get("AYLIKLAR", i, "AYLIK_ID") != null ? sgkMap.getString("AYLIKLAR", i,
						"AYLIK_ID").trim() : "";

					PensionPayment payment = new PensionPayment(SgkInstitution.valueOf(SgkInstitution.InsuranceChannel
						.getEnum(sgkMap.getString("AYLIKLAR", i, "SIGORTA_KOLU"))), aylikId, sicilNo, sgkMap.getString(
						"AYLIKLAR", i, "AYLIK_SONUC_KODU"), sgkMap.getString("AYLIKLAR", i, "AYLIK_SONUC_ACIKLAMA"),
						sgkMap.getInt("AYLIKLAR", i, "AYLIK_BANKAMDA"));

					if(SgkInstitution.InsuranceChannel._4C == payment.getInstitution().getInsuranceChannel()) continue;

					// Basvuru uzerindeki aylik ise devam etmeyelim aksi durumda son tasinan ayligi kabul edelim.
					if(payment.getAllocationNumber().equals(applicationDetails.getPttTahsisNumarasi())
						&& payment.isPaymentSourceValid()) {
						movedPayment = payment;
						break;
					} else if(payment.isPaymentSourceValid()) {
						movedPayment = payment;
					}
				}

				if(movedPayment != null) {

					application.setMaasTasimaTarih(iMap.getDate("TARIH"));
					application.setMaasTasima("1");
					// application.setSorguDurum("0");
					session.saveOrUpdate(application);

					GMMap updateApplicationInputMap = new GMMap();
					updateApplicationInputMap.put("APPLICATION_NO", application.getBasvuruNo());
					updateApplicationInputMap.put("PENSION_PAYMENT", movedPayment);

					GMServiceExecuter.call("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_UPDATE_APPLICATION",
						updateApplicationInputMap);
					salaryMovedRows++;
					continue;
				}

				long diffMillisecs = iMap.getDate("TARIH").getTime() - application.getSorguTarih().getTime();
				long diff = TimeUnit.DAYS.convert(diffMillisecs, TimeUnit.MILLISECONDS);

				if(application.getKkbBorcKapatma().equalsIgnoreCase("0")
					&& diff <= application.getSorguKontrolGun().longValue()) {

					BigDecimal sorguNo = GMServiceExecuter.call(
						"BNSPR_QRY3911_ONLINE_KKB_SORGULA",
						new GMMap().put("PRIMARY_ID_TYPE", primaryIdType).put("PRIMARY_ID_NO",
							applicationDetails.getTcKimlikNo()).put("FINANCE_TYPE", financeType).put("FORENAME1", dot)
							.put("SURNAME", dot).put("BIRTHDATE", birthDate).put("BIRTHTOWN", dot)).getBigDecimal(
						"SORGU_NO");

					/*BigDecimal sorguNo = new BigDecimal((String) GMConnection.getConnection("UAT").serviceCall(
						"BNSPR_QRY3911_ONLINE_KKB_SORGULA",
						new GMMap().put("PRIMARY_ID_TYPE", primaryIdType).put("PRIMARY_ID_NO",
							applicationDetails.getTcKimlikNo()).put("FINANCE_TYPE", financeType).put("FORENAME1", dot).put(
							"SURNAME", dot).put("BIRTHDATE", birthDate).put("BIRTHTOWN", dot)).get("SORGU_NO"));*/

					GMMap kkbMap = (GMMap) DALUtil.callOracleProcedure(
						"{ call pkg_ptt_basvuru.borc_transferi_kkb_risk(?,?,?,?,?)}", new Object[]{BnsprType.NUMBER,
							sorguNo, BnsprType.NUMBER, application.getBasvuruNo()}, new Object[]{BnsprType.NUMBER,
							"KREDI_RISK", BnsprType.NUMBER, "KMH_RISK", BnsprType.NUMBER, "KK_RISK"});

					application.setKrediRisk(kkbMap.getBigDecimal("KREDI_RISK"));
					application.setKmhRisk(kkbMap.getBigDecimal("KMH_RISK"));
					application.setKkRisk(kkbMap.getBigDecimal("KK_RISK"));

					if(kkbMap.get("KREDI_RISK") != null && kkbMap.get("KMH_RISK") != null
						&& kkbMap.getInt("KREDI_RISK") <= 0 && kkbMap.getInt("KMH_RISH") <= 0) {

						application.setKkbBorcKapatmaTarih(iMap.getDate("TARIH"));
						application.setKkbBorcKapatma("1");
						debtPaidOffRows++;
					}
				}

				session.saveOrUpdate(application);
				affectedRows++;
			}
			session.flush();

			oMap.put("AFFECTED_ROWS", affectedRows);
			oMap.put("SALARY_MOVED_ROWS", salaryMovedRows);
			oMap.put("DEBT_PAID_OFF_ROWS", debtPaidOffRows);

			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_SCHEDULER_CONSUMERLOAN_BALANCE_TRANSFER_PROCESS_ONBOARDING err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_CLKS_SCHEDULER_CONSUMERLOAN_ASSIGN_COMMISSION_RECORD_JOB")
	public static GMMap consumerLoanAssignCommissionRecordJob(GMMap iMap) {
		
		try {
			
			Calendar cal = Calendar.getInstance();
	    	 
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
	    	cal.set(Calendar.MINUTE, 0);
	    	cal.set(Calendar.SECOND, 0);
	    	cal.set(Calendar.MILLISECOND, 0);
			
	    	CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
	    	CreditApplicationProcess<Application> process = new CreditApplicationProcessImpl<Application>(
				applicationDao, new GMCreditApplicationApi());
	    	
			Session session = DAOSession.getSession("BNSPRDal");
			
			@SuppressWarnings("unchecked")
			List<ClksBirBasvuruDogrulama> pendingApplications = session.createCriteria(ClksBirBasvuruDogrulama.class)
				.add(Restrictions.eq("basvuruTarihi", cal.getTime())).list();
			
			for(ClksBirBasvuruDogrulama pendingApplication : pendingApplications) {
				
				Application application = applicationDao.get(pendingApplication.getBasvuruNo());
				
				if(application.getCommissionCategory() == null) {
					process.applicationAfterIntermediateStatus(application);
				}
			}
			
			return new GMMap();
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_SCHEDULER_CONSUMERLOAN_ASSIGN_COMMISSION_RECORD_JOB err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
