package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import java.math.BigDecimal;
import java.util.EnumSet;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CashDeposit;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class CashDepositProcess extends TransactionBaseProcess<CashDeposit> implements TransactionProcess<CashDeposit> {

	public CashDepositProcess(TransactionDao<CashDeposit> dao) {
		super(dao);
	}

	@Override
	public void request(CashDeposit transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(CashDeposit transaction) {

		if(ReconciliationType.CASH_DEPOSIT == transaction.reconciliationType()
			&& transaction.getChannel() == CashDeposit.CHANNEL.BRANCH) {

			Record commissionRecord = this.calculateCommission(transaction);
			transaction.setCommissionCurrency(commissionRecord.getCurrency());
			
			if(commissionRecord.getCurrency() == transaction.expenseCurrency()) {
				transaction.setCommissionAmount(commissionRecord.getAmount().compareTo(transaction.expenseAmount()) >= 0
						? commissionRecord.getAmount().subtract(transaction.expenseAmount()) : BigDecimal.ZERO);
			} else {
				transaction.setCommissionAmount(commissionRecord.getAmount());
			}
		}
		
		super.confirm(transaction);
	}
}
