package tr.com.aktifbank.bnspr.adc.clks.services;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriTelefon;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CustomerServices {

	private static Logger logger = Logger.getLogger(CustomerServices.class);

	/**
	 * Girdi telefon bilgilerinin farkli bir kimlik bilgisine sahip musteri uzerinde kayitli telefon numarasi olup 
	 * olmadiginin kontrolunu saglar.
	 * 
	 * @param iMap {CEP_TEL_KOD}	Telefona ait alan kodu
	 * @param iMap {CEP_TEL_NO}		Telefon numarasi
	 * @param iMap {TC_KIMLIK_NO}	TC kimlik numarasi
	 * @return						Girilen telefon farkli bir kimlik numarasina ait m�steride kayitli ise 
	 * 								{@code RESPONSE=4} key,value degerine sahip, aksi durumda {@code RESPONSE=2} key,
	 * 								value degerine sahip {@code GMMap}
	 * @throws GMRuntimeException	Sistem ististanasinda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_CUSTOMER_EXISTING_MOBILE_PHONE_CONTROL")
	public static GMMap existingMobilePhoneControl(GMMap iMap) {
		
		GMMap oMap = new GMMap().put("RESPONSE", "2");

		try {
			
			Session session = DAOSession.getSession("BNSPRDal");

			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("alanKod", iMap.getString("CEP_TEL_KOD"));
			restrictions.put("telNo", iMap.getString("CEP_TEL_NO"));

			@SuppressWarnings("unchecked")
			List<GnlMusteriTelefon> mobilePhones = session.createCriteria(GnlMusteriTelefon.class).add(
				Restrictions.allEq(restrictions)).list();
			Iterator<GnlMusteriTelefon> iterMobilePhones = mobilePhones.iterator();

			while(iterMobilePhones.hasNext()) {

				GnlMusteri customer = (GnlMusteri) session.get(GnlMusteri.class, iterMobilePhones.next().getId()
					.getMusteriNo());

				if("K".equals(customer.getMusteriKontakt())) continue;
				
				if(!iMap.getString("TC_KIMLIK_NO").equals(customer.getTcKimlikNo())) {
					oMap.put("RESPONSE", "4");
					oMap.put("RESPONSE_DATA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE",
						new GMMap().put("MESSAGE_NO", 5061)).getString("ERROR_MESSAGE"));
					break;
				}
			}

			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CUSTOMER_EXISTING_MOBILE_PHONE_CONTROL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	/**
	 * Girdi telefon bilgilerinin farkli bir kimlik bilgisine sahip musteri uzerinde kayitli telefon numarasi olup 
	 * olmadiginin kontrolunu saglar SMS Kredi i�in.
	 * 
	 * @param iMap {CEP_TEL_KOD}	Telefona ait alan kodu
	 * @param iMap {CEP_TEL_NO}		Telefon numarasi
	 * @param iMap {TC_KIMLIK_NO}	TC kimlik numarasi
	 * @return						Girilen telefon farkli bir kimlik numarasina ait m�steride kayitli ise 
	 * 								{@code RESPONSE=4} key,value degerine sahip, aksi durumda {@code RESPONSE=2} key,
	 * 								value degerine sahip {@code GMMap}
	 * @throws GMRuntimeException	Sistem ististanasinda firlatilir.
	 */
	@GraymoundService("BNSPR_CLKS_CUSTOMER_EXISTING_MOBILE_PHONE_CONTROL_FOR_SMS_CREDIT")
	public static GMMap existingMobilePhoneControlForSMSCredit(GMMap iMap) {
				
		GMMap oMap = new GMMap().put("RESPONSE", "2");

		try {
			
			Session session = DAOSession.getSession("BNSPRDal");

			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("alanKod", iMap.getString("CEP_TEL_KOD"));
			restrictions.put("telNo", iMap.getString("CEP_TEL_NO"));

			@SuppressWarnings("unchecked")
			List<GnlMusteriTelefon> mobilePhones = session.createCriteria(GnlMusteriTelefon.class).add(
				Restrictions.allEq(restrictions)).list();
			Iterator<GnlMusteriTelefon> iterMobilePhones = mobilePhones.iterator();
			
			if (StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))&&mobilePhones.size()>1) {
				oMap.put("MESSAGE_NO","5971");
			}
			if (StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))&&mobilePhones.size()==0) {
				oMap.put("MESSAGE_NO","6006");
			}
			while(iterMobilePhones.hasNext()) {

				GnlMusteri customer = (GnlMusteri) session.get(GnlMusteri.class, iterMobilePhones.next().getId()
					.getMusteriNo());
				
//				if ("M".equals(customer.getMusteriKontakt())) {
					oMap.put("TC_KIMLIK_NO", customer.getTcKimlikNo());
//				}
					
				if("K".equals(customer.getMusteriKontakt())) continue;
				
				if(!StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))&&!iMap.getString("TC_KIMLIK_NO").equals(customer.getTcKimlikNo())) {
					oMap.put("RESPONSE", "4");
					oMap.put("RESPONSE_DATA", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE",
						new GMMap().put("MESSAGE_NO", 5061)).getString("ERROR_MESSAGE"));
					oMap.put("MESSAGE_NO","5971");
					break;
				}
			}
			
			GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).uniqueResult();
            List<GnlMusteriTelefon> telefon = null;
            if (musteri != null) {
                  telefon = (List<GnlMusteriTelefon>) session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("alanKod", iMap.getString("CEP_TEL_KOD"))).add(Restrictions.eq("telNo", iMap.getString("CEP_TEL_NO"))).add(Restrictions.eq("id.musteriNo", musteri.getMusteriNo())).list();
            
                  if (telefon == null || telefon.size() == 0) {
                        oMap.put("MESSAGE_NO","5971");
                  }
            }


			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CUSTOMER_EXISTING_MOBILE_PHONE_CONTROL_FOR_SMS_CREDIT err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
