package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transfer;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;

import com.graymound.server.dao.DAOSession;

public class DalTransferDao extends DalTransactionDao<Transfer> implements TransactionDao<Transfer> {

	public DalTransferDao() {
		super(Transfer.class);
	}

	@Override
	public Transfer get(Serializable id) {
		Session session = DAOSession.getSession("BNSPRDal");
		ClksHavaleOdemeTx clksHavaleOdemeTx = (ClksHavaleOdemeTx) session.get(ClksHavaleOdemeTx.class, id);
		Transfer transfer = new Transfer(clksHavaleOdemeTx.getTxNo());
		transfer.setAmount(clksHavaleOdemeTx.getTutar());
		transfer.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
		transfer.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
		return transfer;
	}

	@Override
	public List<Transfer> filter(Map<String, Object> criteria) {
		
		List<Transfer> transferList = new ArrayList<Transfer>();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		criteria.put("islemSekli", "CLKSKODE");
		@SuppressWarnings("unchecked")
		List<ClksHavaleOdemeTx> list = session.createCriteria(ClksHavaleOdemeTx.class).add(Restrictions.allEq(criteria))
			.list();

		for(ClksHavaleOdemeTx clksHavaleOdemeTx : list) {
			Transfer transfer = new Transfer(clksHavaleOdemeTx.getTxNo());
			transfer.setAmount(clksHavaleOdemeTx.getTutar());
			transfer.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
			transfer.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
			transferList.add(transfer);
		}
		return transferList;
	}

	@Override
	public List<Transfer> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Transfer type) {
		// TODO Auto-generated method stub
	}

	@Override
	public void saveOrUpdate(Transfer type) {
		// TODO Auto-generated method stub
	}
}
