package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionContext;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal.GMCacheCommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transaction;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

abstract class TransactionBaseProcess<T extends Transaction> implements TransactionProcess<T> {
	
	private static Logger logger = Logger.getLogger(TransactionBaseProcess.class);

	private final TransactionDao<T> dao;
	
	public TransactionBaseProcess(TransactionDao<T> dao) {
		this.dao = dao;
	}

	@Override
	public void request(T transaction) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void confirm(T transaction) {
		
		if(transaction.commissionAmount() == null) {
			if(transaction.commissionCategory() != null && transaction.commissionCategory().getStrategyClass() == null) { // Batch hesaplanacak
				transaction.setCommissionAmount(BigDecimal.ZERO);
				transaction.setCommissionCurrency(null);
			} else if(transaction.commissionCategory() != null) {
				Record commissionRecord = calculateCommission(transaction);
				transaction.setCommissionAmount(commissionRecord.getAmount());
				transaction.setCommissionCurrency(commissionRecord.getCurrency());
			}
		}
		
		if(transaction.commissionAmount() != null) {
			dao.saveCommission(transaction);
		}
	}
	
	/**
	 * 
	 * @param transaction
	 * @return
	 */
	protected Record calculateCommission(T transaction) {
		
		CommissionContext commissionContext = null;
		Record record = null;
		
		try {
			commissionContext = new CommissionContext(transaction.commissionCategory()
				.getStrategyClass().getDeclaredConstructor(List.class).newInstance(
					new GMCacheCommissionDao().getByCommissionCategory(transaction.commissionCategory())));

			record = commissionContext.calculate(new Record(transaction.amount(), transaction.currency()));
			
		} catch(Exception e) {
			logger.error(e.getMessage(), e);
		}
		
		return record;
	}

	public TransactionDao<T> getDao() {
		return dao;
	}
}
