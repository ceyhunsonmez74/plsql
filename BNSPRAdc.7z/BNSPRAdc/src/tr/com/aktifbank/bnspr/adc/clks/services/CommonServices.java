package tr.com.aktifbank.bnspr.adc.clks.services;

import java.math.BigDecimal;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal.DalCreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application.STATUS;
import tr.com.aktifbank.bnspr.clks.services.CLKSServices;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants;
import tr.com.aktifbank.bnspr.clks.util.ClksConstants.Transaction;
import tr.com.aktifbank.bnspr.dao.ClksUptHesapCekilenTx;
import tr.com.aktifbank.bnspr.dao.ClksUptHesapYatanTx;
import tr.com.aktifbank.kurumsalibank.util.ProcessLogUtils;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CommonServices {

	private static Logger logger = Logger.getLogger(CLKSServices.class);

	@GraymoundService("BNSPR_CLKS_CANCEL_TRANSACTION_REQUEST")
	public static GMMap iptalEdilebilirmi(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			String islemKod = (String) DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_kod(?)}",
				Types.VARCHAR, iMap.getBigDecimal("ISLEMNO"));
			
			DALUtil.callOracleFunction("{ ? = call PKG_PTT.islemIptalEdilebilirmi(?)}", BnsprType.STRING, new Object[]{
				BnsprType.NUMBER, iMap.getBigDecimal("ISLEMNO")});

			if("2315".equals(islemKod)) {
				oMap.putAll(GMServiceExecuter.call("CLKS_EFT_IPTAL_ONAY", iMap));
			}

			GMMap sMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_YPUPT.TU_IslemMi(?,?,?,?,?,?)}", new Object[]{
				BnsprType.STRING, islemKod, BnsprType.NUMBER, iMap.getBigDecimal("ISLEMNO")}, new Object[]{
				BnsprType.STRING, "F_UPT", BnsprType.STRING, "TU_REFERANS", BnsprType.STRING, "ISLEM_TIP",
				BnsprType.NUMBER, "BANKA_ISLEM_NO"});
			sMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("ISLEMNO"));

			if("E".equals(sMap.getString("F_UPT"))) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CANCEL_CHECK", sMap));
				if(!oMap.getBoolean("IS_CANCELABLE")) {
					throw new GMRuntimeException(0, oMap.getString("RESPONSE_DATA"), true);
				}
			}

			if("2050".equals(islemKod)) {
				Session session = DAOSession.getSession("BNSPRDal");
				Criteria cr = session.createCriteria(ClksHavaleGirisTx.class).add(
					Restrictions.eq("txNo", iMap.getBigDecimal("islemNo")));
				ClksHavaleGirisTx tx = (ClksHavaleGirisTx) cr.uniqueResult();
				iMap.put("MUSTERI_NO", tx.getAliciMusteriNo());
				
				if("E".equals(tx.getFErkenkapama()) && BigDecimal.valueOf(4).equals(tx.getIslem())) { // erken kapama iptali ve taksit tahsilat� varsa
					// BirBasvuru basvuru bug�n olan tc kimlik no durum evraks�z
					CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
					Map<String, Object> criteria = new HashMap<String, Object>();
					SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
					criteria.put("tcKimlikNo", tx.getTcKimlikNo());
					criteria.put("basvuruTarihi", formatter.parse(formatter.format(new Date())));
					criteria.put("kanalKodu", "7");
					
					List<Application> appList = applicationDao.filter(criteria);
					boolean isCancellable = true;
					
					if(appList.size() > 0) {
						
						for(Application app : appList) {
							if(EnumSet.of(STATUS.SOZLESME, STATUS.EVRAKSIZ, STATUS.CEPTE).contains(app.getStatus())) {
								isCancellable = false;
								break;
							}
						}
						
						if(!isCancellable) {
							GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", BigDecimal
								.valueOf(5936)));
						}
					}

				}
				
				if("1".equals(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", iMap).getString("F_MUSTERI_BLOKE"))) {
					iMap.put("HATA_NO", new BigDecimal(1676));
					iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

			}

			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CANCEL_TRANSACTION_REQUEST", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_CLKS_CANCEL_TRANSACTION")
	public static GMMap islemIptalYedekle(GMMap iMap) {
		
		String islemKod = null;
		BigDecimal blokeTutari = BigDecimal.ZERO;
		GMMap oMap = new GMMap();
		
		// Reversal'da bloke tutari guncelleme, islem kodlari (0)
		String[] blokeGuncelList = {
			Transaction.ATM_NAKIT_YATAN.toString()
		};
		
		try {

			islemKod = (String) DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_kod(?)}", Types.VARCHAR, iMap.getBigDecimal("islemNo"));
			
			// Case: Kart islemleri haric gise iptal talepleri + "UPT Odeme" reversal talepleri
			if (ClksConstants.IPTAL_GISE.equals(iMap.getString("iptalTip"))) {

				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO", "HesapIslemleri@calikbank.com.tr");
				mailMap.put("TRX_NO", iMap.getString("islemNo"));
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "PTT Islem Iptali ");
				mailMap.put("MAIL_BODY", iMap.getString("islemNo") + " numarali islem iptal edilmistir");
				mailMap.put("IS_BODY_HTML", "H");
				GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);

				// Process altyapisini kullanan islemler
				String[] pList = {
					Transaction.NAKIT_YATAN.toString(),
					Transaction.NAKIT_CEKILEN.toString(),
					Transaction.HAVALE_ODEME.toString(),
					Transaction.HAVALE.toString(),
					Transaction.EFT.toString(),
					Transaction.YP_TRANSFER.toString(),
					Transaction.UPT_ODEME.toString()
				};
				
				// UPT entegrasyonunda kullanilan islemler
				String[] pUptList = {
					Transaction.UPT_ODEME.toString(),
					Transaction.UPT_TALIMAT.toString(),
					Transaction.YP_TRANSFER.toString()
				};
				
				// UPT Nakit Yatirma Cekme Islem Kodlari
                String[] pUPTYatirmaCekmeList = {
                	Transaction.UPT_NAKIT_YATAN.toString(),
                	Transaction.UPT_NAKIT_CEKILEN.toString()
                };
                
				
				// Process bilgisini geri cevirelim
				for(String pKod : pList) {
					if(pKod.equals(islemKod)) {
						ProcessLogUtils.createReverseProcessLog(new GMMap().put("ISLEM_NO", iMap.getString("islemNo")));
						break;
					}
				}
				
				// Case: UPT A.S. islemleri
				for(String pKod : pUptList) {
					if(pKod.equals(islemKod)) {
						
						Object[] inputVals = {
							BnsprType.STRING, islemKod,
							BnsprType.NUMBER, iMap.getBigDecimal("islemNo")
						};
						
						Object[] outputVals = {
							BnsprType.STRING, "UPT_ISLEMI",
							BnsprType.STRING, "REFERANS",
							BnsprType.STRING, "ISLEM",
							BnsprType.STRING, "MUHASEBE_ISLEM_NO"
						};
						
						iMap.putAll((GMMap) DALUtil.callOracleProcedure("{call pkg_ypupt.tu_islemmi(?,?,?,?,?,?)}", inputVals, outputVals));
						
						if ("E".equals(iMap.getString("UPT_ISLEMI"))) {
							
							if (Transaction.UPT_TALIMAT.toString().equals(islemKod)) {
								iMap.put("ISLEMNO", iMap.getBigDecimal("MUHASEBE_ISLEM_NO"));
							}
							
						    oMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("ISLEMNO"));
						    oMap.put("TU_REFERANS", iMap.getString("REFERANS"));
						    oMap.put("ISLEM_TIP", iMap.getString("ISLEM"));
						    oMap.put("BRANCH_ID", iMap.getString("ISLEMYERI"));
						    oMap.put("USER_ID", iMap.getString("KULLANICISICIL"));
						    oMap.put("USER_NAME", iMap.getString("KULLANICISICIL"));
						    

					    	GMServiceExecuter.call("BNSPR_TU_CANCEL_REQUEST", oMap.put("F_ASYNC", true));
							GMServiceExecuter.executeAsync("BNSPR_TU_CANCEL_PROCESS", oMap.put("F_ASYNC", true));
						    
						}
						
						oMap.clear();
						break;						
					}
				}
				
				
                // Case: UPT Para Yatirma/Cekme Islemleri
                for (String pKod : pUPTYatirmaCekmeList) {
                    if (pKod.equals(islemKod)) {
                        Session session = DAOSession.getSession("BNSPRDal");
                        if (Transaction.UPT_NAKIT_YATAN.toString().equals(islemKod)) {

                            ClksUptHesapYatanTx cY = (ClksUptHesapYatanTx) session.get(ClksUptHesapYatanTx.class, iMap.getBigDecimal("islemNo"));

                            // oMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("islemNo"));
                            oMap.put("REFERENCE", cY.getReferansNo());
                        }
                        else if (Transaction.UPT_NAKIT_CEKILEN.toString().equals(islemKod)) {
                            ClksUptHesapCekilenTx cC = (ClksUptHesapCekilenTx) session.get(ClksUptHesapCekilenTx.class, iMap.getBigDecimal("islemNo"));

                            // oMap.put("BANKA_ISLEM_NO", iMap.getBigDecimal("islemNo"));
                            oMap.put("REFERENCE", cC.getReferansNo());
                        }

                        // boolean isCancelable = GMServiceExecuter.call("BNSPR_TU_CANCEL_CHECK", oMap).getBoolean("IS_CANCELABLE");
                        oMap.putAll(GMServiceExecuter.call("BNSPR_TU_CUST_ACCOUNT_CANCEL_CUST_ACCOUNT_TRANSACTION", oMap));
                    }
                }
                
				/* �lgili i�lem tiplerinde iptal i�in limit kontrol� yap�lacak */
				String[] controlList = {
					Transaction.KART_PASSO_YATAN.toString()
				};

				for(String pKod : controlList) {
				    if(pKod.equals(islemKod))
					GMServiceExecuter.call("TFF_KART_IPTAL_LIMIT_KONTROL", iMap);
				}
				
				
			}

			// Case: Vazgec talepleri
			else if (ClksConstants.IPTAL_VAZGEC.equals(iMap.getString("iptalTip"))) {
				
				Object[] inputVals = {
					BnsprType.NUMBER, iMap.getBigDecimal("islemNo")
				};
				
				DALUtil.callOracleProcedure("{ call PKG_PTT.islemIptalEdilebilirmiVazgec(?)}", inputVals,  new Object[0]);
			}
			
			// Case: Reversal talepleri - "Kart" reversal talepleri
			// TODO: Reversal akislari icin bu case'i kullanalim.
			else if (ClksConstants.REVERSAL.equals(iMap.getString("iptalTip"))) {
				
				// Process altyapisini kullanan islemler
				String[] pList = {
					Transaction.ATM_KART_PASSO.toString(),
					Transaction.KART_PASSO_YATAN.toString(),
					Transaction.ATM_NAKIT_YATAN.toString()
				};
				
				// Process bilgisini geri cevirelim
				for(String pKod : pList) {
					if(pKod.equals(islemKod)) {
						ProcessLogUtils.createReverseProcessLog(new GMMap().put("ISLEM_NO", iMap.getString("islemNo")));
						break;
					}
				}
				
				Session session = DAOSession.getSession("BNSPRDal");
				ClksHavaleGirisTx clTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("islemNo"));
				clTx.setFReversal("E");
				
				// Bloke tutari guncellemesi (0)
				for(String blokeGuncelKod : blokeGuncelList) {
					if(blokeGuncelKod.equals(islemKod)) {
						blokeTutari = (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_trn2049.Hesap_Bloke_Guncelle(?,?)}", BnsprType.NUMBER, BnsprType.NUMBER, iMap.getBigDecimal("islemNo"), BnsprType.NUMBER, null);
						break;
					}
				}
				
				session.update(clTx);
				session.flush();
			}
			
			Object[] inputVals = {
				BnsprType.NUMBER, iMap.getBigDecimal("islemNo"),
				BnsprType.STRING, iMap.getString("islemYeri"),
				BnsprType.STRING, iMap.getString("kullaniciSicil"),
				BnsprType.STRING, iMap.getString("iptaliYapanKullAdSoyad")
			};
			
			DALUtil.callOracleProcedure("{call PKG_PTT.islem_iptal_bilgi_yedekle(?,?,?,?)}", inputVals, new Object[0]);
			iMap.put("ISLEM_DURUM", DALUtil.callOneParameterFunction("{ ? = call pkg_tx.islem_durum(?)}", Types.VARCHAR, iMap.getBigDecimal("islemNo")));
			
			oMap.put("ISLEM_NO", iMap.getString("islemNo"))
				.put("ISLEM_KODU", islemKod).put("ISLEM_TURU", "I")
				.put("ACIKLAMA", iMap.getString("aciklama"));
			
			oMap.putAll(GMServiceExecuter.call("CLKS_GET_ISLEM_NO", oMap));

			if ("C".equals(iMap.getString("ISLEM_DURUM"))) {
				oMap.put("ISLEM_TURU", "OR");
			}
			
			String tableName = "RC_TX_NO_LIST";
			List<?> list = (List<?>) oMap.get(tableName);

			if (list != null) {
				
				for (int i = list.size() - 1; i >= 0; i--) {
					oMap.put("ISLEM_NO", oMap.getBigDecimal("RC_TX_NO_LIST", i, "ISLEM_NO"));
					
					// Case: Islem yaratilmis ve tamamlanmis ise iptal edelim, aksi durumda Havale islemini engellemesin
					if(((BigDecimal)DALUtil.callOneParameterFunction("{? = call pkg_tx.islem_yaratilmis_mi(?)}", Types.NUMERIC, oMap.getBigDecimal("ISLEM_NO"))).equals(new BigDecimal(1)) &&
							((GMMap) GMServiceExecuter.call("BNSPR_ISLEM_BITMIS_MI", new GMMap().put("TRX_NO", oMap.getBigDecimal("ISLEM_NO")))).getBigDecimal("ISLEM_BITMIS").equals(new BigDecimal(1))) {
						GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", oMap);
					}
				}
			}

			oMap.put("ISLEM_NO", iMap.getString("islemNo")); // orjinal numara geri getiriliyor
			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", oMap);
			
			// Case: Reversal talepleri - "Kart" reversal talepleri
			if (ClksConstants.REVERSAL.equals(iMap.getString("iptalTip"))) {
				
				// Bloke tutari guncellemesi (0)
				for(String blokeGuncelKod : blokeGuncelList) {
					if(blokeGuncelKod.equals(islemKod)) {
						DALUtil.callOracleFunction("{? = call pkg_trn2049.Hesap_Bloke_Guncelle(?,?)}", BnsprType.NUMBER, BnsprType.NUMBER, iMap.getBigDecimal("islemNo"), BnsprType.NUMBER, blokeTutari);
						break;
					}
				}
			}
			
			if (islemKod.equals(Transaction.HAVALE.toString())){
			    BigDecimal islemNo = iMap.getBigDecimal("islemNo");
			    		String basvuruNoAndNewTx = (String) DALUtil.callOracleFunction("{? = call Pkg_TRN2030.KullandirimBasvuruNoGetir(?)}", BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal("islemNo"));
						logger.info("KREDI KULLANDIRIM IPTAL ISLEMI : islem No:" + islemNo + "Basvuru No ve Yeni TxNo :" + basvuruNoAndNewTx  );

						if (basvuruNoAndNewTx !=null){
							String[] parts = basvuruNoAndNewTx.split(",");	
							if (parts.length==2){
								GMMap basvuruNoMap = new GMMap(); 
								basvuruNoMap.put("BASVURU_NO", new BigDecimal(parts[0]));
								basvuruNoMap.put("TX_NO", new BigDecimal(parts[1]));
								basvuruNoMap.put("YENI_DURUM", "IPTAL");
								basvuruNoMap.put("ACIKLAMA", "PTT iptal ekran�ndan kullandirim iptal edildi.");
								basvuruNoMap.putAll(GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_REVERT_PENDING_APPLICATION", basvuruNoMap));
							}
							
						}
				}
			
			
		} catch (Exception e) {
			logger.error("BNSPR_CLKS_CANCEL_TRANSACTION err: ", e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
}
