package tr.com.aktifbank.bnspr.adc.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Types;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Currency;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.CommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal.GMCacheCommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.DiffType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCustomerAcquisitionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CustomerAcquisition;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatFark;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatFarkSorgu;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatTanimPr;
import tr.com.aktifbank.bnspr.dao.ClksislemKomisyon;
import tr.com.aktifbank.bnspr.dao.ClksislemTanimPr;
import tr.com.aktifbank.bnspr.dao.ClksislemiliskiPr;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class AdcQRY4052Services {

	private static Logger logger = Logger.getLogger(AdcQRY4052Services.class);
	
	private static GMMap remoteCall(String serviceName, GMMap iMap) {

		String BANKING_SERVICE = "DEALER";
		
		GMConnection connection = null;
		GMMap oMap = new GMMap();

		try {
			connection = GMConnection.getConnection(BANKING_SERVICE);
			oMap.putAll(connection.serviceCall(serviceName, iMap));
			return oMap;
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			if(connection != null) {
				try {
					connection.close();
				} catch(IOException e) {
					logger.error("AdcQRY4052Services.remoteCall err:", e);
				}
			}
		}
	}
	
	private enum ReconciliationGroup {
		KREDI("K"),
		UPT("U"),
		DIGER("D");

		private String code;
		
		private ReconciliationGroup(String code) {
			this.code = code;
		}
		
		@Override
		public String toString() {
			return code;
		}

		public String getCode() {
			return code;
		}

		public static ReconciliationGroup getEnum(String code) {
			for(ReconciliationGroup v : values()) {
				if(v.toString().equalsIgnoreCase(code)) return v;
			}
			throw new IllegalArgumentException();
		}
	}
	
	/**
	 *
	 */
	private enum TransactionStatus {
		PROCESSED("P", "Tamam"), CANCELLED("2", "�ptal"), REFUSED("R", "Red"), CONFIRMED("C", "Onay Bekliyor");
		
		private String code;
		private String label;
		
		private TransactionStatus(String code, String label) {
			this.code = code;
			this.label = label;
		}
		
		@Override
		public String toString() {
			return label;
		}

		public String getCode() {
			return code;
		}
		
		public static TransactionStatus getEnum(String code) {
			for(TransactionStatus v : values()) {
				if(v.getCode().equalsIgnoreCase(code)) return v;
			}
			throw new IllegalArgumentException();
		}
	}
	
	/**
	 *
	 */
	private enum ReconciliationItemGroupByAccounting {
		COLLECTION("Yatan", 1), 
		PAYMENT("�ekilen", 2), 
		CANCELLED_COLLECTION("Yatan �ptal", 2), 
		CANCELLED_PAYMENT("�ekilen �ptal", 1);
		
		private String label;
		private int accountingDirection;
		
		private ReconciliationItemGroupByAccounting(String label, int accountingDirection) {
			this.label = label;
			this.accountingDirection = accountingDirection;
		}
		
		/**
		 * @return the accountingDirection
		 */
		public int getAccountingDirection() {
			return accountingDirection;
		}

		@Override
		public String toString() {
			return label;
		}
	}
	
	/**
	 *
	 */
	private enum ReconciliationItemGroupByCategory {
		
		KREDI_KULLANDIRIM("Kredi Kullandirim"),
		KREDI_YATIRMA("Kredi Yat�rma"),
		KREDI_BASVURU("Kredi Ba�vuru"),
		UPT_ODEME("UPT �deme"),
		YP_UPT_YD("YP Yurtd��� G�nderim"),
		YP_UPT_YI("YP Yurti�i G�nderim"),
		TL_UPT("TL UPT"),
		UPT_IADE("UPT �ade"), 
		NAKIT_YATIRMA("Nakit Yat�rma"),
		NAKIT_CEKME("Nakit �ekme"),
		ATM_NAKIT_YATIRMA("ATM Nakit Yat�rma"),
		PASSOLIG_YATIRMA("Passolig Yat�rma"),
		ATM_NAKIT_YATIRMA_PASSOLIG("ATM Nakit Yat�rma Passolig"),
		NKOLAY_GISE("N Kolay Gi�e"),
		NKOLAY_ATM("N Kolay ATM"),
		HESAP_ACMA("Hesap A�ma");
		
		private String label;
		
		private ReconciliationItemGroupByCategory(String label) {
			this.label = label;
		}
		
		@Override
		public String toString() {
			return label;
		}
	}
	
	private static final Map<ReconciliationItemGroupByAccounting, ReconciliationItemGroupByAccounting> 
		FIRST_LEVEL_RECONCILIATION_ITEM_CANCELLED_MAP = initFirstLevelReconciliationItemCancelledMap();
	
	private enum TransactionType {

		KREDI_KULLANDIRIM_ODEMESI(7, "Kredi Kulland�r�m �demesi", ReconciliationItemGroupByAccounting.PAYMENT,
			ReconciliationItemGroupByCategory.KREDI_KULLANDIRIM), 
		
		KREDI_TAKSIT_TAHSILATI(4, "Kredi Taksit Tahsilat�", ReconciliationItemGroupByAccounting.COLLECTION, 
			ReconciliationItemGroupByCategory.KREDI_YATIRMA), 
		
		KREDI_BASVURU(9, "Kredi Ba�vuru", null, ReconciliationItemGroupByCategory.KREDI_BASVURU),
		
		YP_UPT_YURTICI(12, "YP UPT Yurti�i G�nderim", ReconciliationItemGroupByAccounting.COLLECTION,
			ReconciliationItemGroupByCategory.YP_UPT_YI),
		
		YP_UPT_YURTDISI(13, "YP UPT Yurtd��� G�nderim", ReconciliationItemGroupByAccounting.COLLECTION, 
			ReconciliationItemGroupByCategory.YP_UPT_YD),
		
		TL_UPT(10, "TL UPT", ReconciliationItemGroupByAccounting.COLLECTION, ReconciliationItemGroupByCategory.TL_UPT),
		
		REFERANS_ODEME(6, "Referansl� �deme", ReconciliationItemGroupByAccounting.PAYMENT, 
			ReconciliationItemGroupByCategory.UPT_ODEME),
		
		UPT_ODEME(14, "UPT �demesi (Swift/UPT)", ReconciliationItemGroupByAccounting.PAYMENT, 
			ReconciliationItemGroupByCategory.UPT_ODEME),
			
		TL_UPT_ODEME(11, "TL UPT �demesi", ReconciliationItemGroupByAccounting.PAYMENT, 
			ReconciliationItemGroupByCategory.UPT_ODEME),
			
		UPT_IADE(27, "UPT �ade �demesi", ReconciliationItemGroupByAccounting.PAYMENT, 
			ReconciliationItemGroupByCategory.UPT_IADE),
		
		NAKIT_YATIRMA(1, "Nakit Yat�rma", ReconciliationItemGroupByAccounting.COLLECTION, 
			ReconciliationItemGroupByCategory.NAKIT_YATIRMA),
		
		NAKIT_CEKME(5, "Nakit �ekme", ReconciliationItemGroupByAccounting.PAYMENT, 
			ReconciliationItemGroupByCategory.NAKIT_CEKME),
		
		KART_PASSOLIG(65, "Kart Passolig - Gi�e", ReconciliationItemGroupByAccounting.COLLECTION, 
			ReconciliationItemGroupByCategory.PASSOLIG_YATIRMA),
		
		KART_NKOLAY(72, "Kart N Kolay - Gi�e", ReconciliationItemGroupByAccounting.COLLECTION, 
			ReconciliationItemGroupByCategory.NKOLAY_GISE),
			
		ATM_NAKIT_YATIRMA_HESAP(6060, "Nakit Yat�rma - ATM (Hesap)", ReconciliationItemGroupByAccounting.COLLECTION,
			ReconciliationItemGroupByCategory.ATM_NAKIT_YATIRMA),
			
		ATM_NAKIT_YATIRMA_IBAN(6061, "Nakit Yat�rma - ATM (IBAN)", ReconciliationItemGroupByAccounting.COLLECTION,
			ReconciliationItemGroupByCategory.ATM_NAKIT_YATIRMA),
			
		ATM_KART_PASSOLIG(6063, "Kart Passolig - ATM", ReconciliationItemGroupByAccounting.COLLECTION,
			ReconciliationItemGroupByCategory.ATM_NAKIT_YATIRMA_PASSOLIG),
			
		ATM_KART_PASSOLIG_KIMLIK(6064, "Kart Passolig - ATM", ReconciliationItemGroupByAccounting.COLLECTION,
			ReconciliationItemGroupByCategory.ATM_NAKIT_YATIRMA_PASSOLIG),
			
		ATM_KART_NKOLAY(6065, "Kart N Kolay - ATM", ReconciliationItemGroupByAccounting.COLLECTION,
			ReconciliationItemGroupByCategory.NKOLAY_ATM),
			
		HESAP_ACMA(137, "Hesap A�ma", null,  ReconciliationItemGroupByCategory.HESAP_ACMA);
		
		private int code;
		private String label;
		private ReconciliationItemGroupByAccounting accountingGroup;
		private ReconciliationItemGroupByCategory categoryGroup;

		private TransactionType(int code, String text, ReconciliationItemGroupByAccounting accountingGroup, 
			ReconciliationItemGroupByCategory categoryGroup) {
			this.code = code;
			this.label = text;
			this.accountingGroup = accountingGroup;
			this.categoryGroup = categoryGroup;
		}

		@Override
		public String toString() {
			return this.label;
		}

		public int getCode() {
			return code;
		}

		public ReconciliationItemGroupByAccounting getAccountingGroup() {
			return accountingGroup;
		}
		
		public ReconciliationItemGroupByCategory getCategoryGroup() {
			return categoryGroup;
		}

		public static TransactionType getEnum(int code) {
			for(TransactionType v : values()) {
				if(v.getCode() == code) return v;
			}
			throw new IllegalArgumentException();
		}
	}

	private static Map<ReconciliationItemGroupByAccounting, ReconciliationItemGroupByAccounting>
		initFirstLevelReconciliationItemCancelledMap() {
		Map<ReconciliationItemGroupByAccounting, ReconciliationItemGroupByAccounting> map = 
			new HashMap<ReconciliationItemGroupByAccounting, ReconciliationItemGroupByAccounting>();
		map.put(ReconciliationItemGroupByAccounting.COLLECTION, ReconciliationItemGroupByAccounting.CANCELLED_COLLECTION);
		map.put(ReconciliationItemGroupByAccounting.PAYMENT, ReconciliationItemGroupByAccounting.CANCELLED_PAYMENT);
		return Collections.unmodifiableMap(map);
	}
	
	/**
	 * 
	 * @param enumClass
	 * @param map
	 */
	private static <E extends Enum<E>> void
		resetMap(Class<E> enumClass, Map<E, Map<CurrencyType, List<BigDecimal>>> map) {

		for(E item : enumClass.getEnumConstants()) {

			Map<CurrencyType, List<BigDecimal>> amountMap = new HashMap<CurrencyType, List<BigDecimal>>();

			for(CurrencyType currency : CurrencyType.values()) {
				amountMap.put(currency, Arrays.asList(BigDecimal.ZERO, BigDecimal.ZERO));
			}

			map.put(item, amountMap);
		}
	}

	@GraymoundService("BNSPR_QRY4052_INITIALIZE")
	public static GMMap init(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			oMap.put("TRN2052_YETKI", DALUtil.callNoParameterFunction("{? = call pkg_trn2052.islem_yetki_kontrol}",
				Types.VARCHAR));
			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_TRN4052_INITIALIZE err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY4052_GET_RECORDS")
	public static GMMap getRecords(GMMap iMap) {

		GMMap oMap = new GMMap();
		String listName = "RESULTS", listNameAccountingGroup = "ACCOUNTING_GROUP_SUMMARY", 
			listNameCategoryGroup = "CATEGORY_GROUP_SUMMARY", listNameDiffRecords = "DIFF_RECORDS", 
			listNameDiffConsumerLoanApplications = "DIFF_CONSUMERLOAN_APPLICATIONS";
		DecimalFormat df = new DecimalFormat("#,##0.00");

		/**
		 * Map<Mutabakat Kalemi, Para Birimi<Tutar, Adet>>
		 */
		HashMap<ReconciliationItemGroupByAccounting, Map<CurrencyType, List<BigDecimal>>> accountingGroupSummary = 
			new HashMap<ReconciliationItemGroupByAccounting, Map<CurrencyType, List<BigDecimal>>>();

		resetMap(ReconciliationItemGroupByAccounting.class, accountingGroupSummary);
		
		Map<ReconciliationItemGroupByCategory, Map<CurrencyType, List<BigDecimal>>> categoryGroupSummary =
			new HashMap<ReconciliationItemGroupByCategory, Map<CurrencyType, List<BigDecimal>>>();
		
		resetMap(ReconciliationItemGroupByCategory.class, categoryGroupSummary);
		
		Map<CurrencyType, BigDecimal> liability = new HashMap<CurrencyType, BigDecimal>();
		
		for(CurrencyType currency : CurrencyType.values()) {
			liability.put(currency, BigDecimal.ZERO);
		}
		
		try {

			oMap.put("CHECK_MUTABAKAT_FARK_SORGU", false);
			oMap.put("CHECK_MUTABAKAT_FARK_EKSIK_KAYIT", false);
			
			Session session = DAOSession.getSession("BNSPRDal");

			Map<String, Object> restrictions = new HashMap<String, Object>();
			restrictions.put("mutabakatTarihi", iMap.getDate("TARIH"));
			restrictions.put("durum", "A");
			
			Map<ReconciliationGroup, Boolean> reconciliationGroupDiff = new HashMap<ReconciliationGroup, Boolean>();
			
			for(ReconciliationGroup group : ReconciliationGroup.values()) {
				restrictions.put("grupKod", group.toString());
				
				ClksMutabakatFarkSorgu clksMutabakatFarkSorgu = (ClksMutabakatFarkSorgu) session.createCriteria(
					ClksMutabakatFarkSorgu.class).add(Restrictions.allEq(restrictions)).uniqueResult();
				
				if(clksMutabakatFarkSorgu != null) {
					reconciliationGroupDiff.put(group, Boolean.valueOf(true));
					if(clksMutabakatFarkSorgu.getEksikKayit().compareTo(BigDecimal.ZERO) > 0) {
						oMap.put("CHECK_MUTABAKAT_FARK_EKSIK_KAYIT", true);
					}
				} else {
					reconciliationGroupDiff.put(group, Boolean.valueOf(false));
				}
			}
			
			if(reconciliationGroupDiff.entrySet().iterator().hasNext()) {
				oMap.put("CHECK_MUTABAKAT_FARK_SORGU", true);
			} else {
				oMap.put("CHECK_MUTABAKAT_FARK_SORGU", false);
			}
			
			for(Iterator<Entry<ReconciliationGroup, Boolean>> iterator = reconciliationGroupDiff.entrySet()
				.iterator(); iterator.hasNext();) {
				Entry<ReconciliationGroup, Boolean> entry = iterator.next();
				if(!entry.getValue().booleanValue()) {
					oMap.put("CHECK_MUTABAKAT_FARK_SORGU", false);
				}
			}
			
			// Source System
			GMMap dalMap = DALUtil.callOracleRefCursorFunction("{ ? = call pkg_rc4052.rc_qry4052_ozet_tablo(?,?)}",
				listName, BnsprType.DATE, iMap.getDate("TARIH"), BnsprType.STRING, iMap.getString("ROL"));
			
			for(int i = 0; i < dalMap.getSize(listName); i++) {
				
				TransactionType transactionType = TransactionType.getEnum(dalMap.getInt(listName, i, "ISLEM_TURU"));
				TransactionStatus transactionStatus = TransactionStatus.getEnum(dalMap.getString(listName, i, "DURUM"));
				CurrencyType currency = CurrencyType.getEnum(dalMap.getString(listName, i, "PARA_BIRIMI"));
				
				// TODO Kredi Basvuru ?
				if(transactionType.getCategoryGroup() == null || transactionStatus == TransactionStatus.CANCELLED) continue;
				
				Map<CurrencyType, List<BigDecimal>> item = categoryGroupSummary.get(transactionType.getCategoryGroup());

				item.get(currency).set(0, item.get(currency).get(0).add(dalMap.getBigDecimal(listName, i, "TUTAR")));
				item.get(currency).set(1, item.get(currency).get(1).add(dalMap.getBigDecimal(listName, i, "ADET")));
				item.get(CurrencyType.TRY).set(0, item.get(CurrencyType.TRY).get(0)
					.add(dalMap.getBigDecimal(listName, i, "TUTAR_2")));
			}
			
			for(int i = 0; i < dalMap.getSize(listName); i++) {

				TransactionType transactionType = TransactionType.getEnum(dalMap.getInt(listName, i, "ISLEM_TURU"));
				TransactionStatus transactionStatus = TransactionStatus.getEnum(dalMap.getString(listName, i, "DURUM"));
				CurrencyType currency = CurrencyType.getEnum(dalMap.getString(listName, i, "PARA_BIRIMI"));

				if(transactionType.getAccountingGroup() == null) continue;

				Map<CurrencyType, List<BigDecimal>> item = accountingGroupSummary.get(transactionType
					.getAccountingGroup());

				item.get(currency).set(0, item.get(currency).get(0).add(dalMap.getBigDecimal(listName, i, "TUTAR")));
				item.get(currency).set(1, item.get(currency).get(1).add(dalMap.getBigDecimal(listName, i, "ADET")));
				item.get(CurrencyType.TRY).set(0, item.get(CurrencyType.TRY).get(0).add(dalMap.getBigDecimal(listName, i, "TUTAR_2")));

				if(transactionStatus == TransactionStatus.CANCELLED) {

					Map<CurrencyType, List<BigDecimal>> itemCancelled = accountingGroupSummary
						.get(FIRST_LEVEL_RECONCILIATION_ITEM_CANCELLED_MAP.get(transactionType.getAccountingGroup()));

					itemCancelled.get(currency).set(0,
						itemCancelled.get(currency).get(0).add(dalMap.getBigDecimal(listName, i, "TUTAR")));

					itemCancelled.get(currency).set(1,
						itemCancelled.get(currency).get(1).add(dalMap.getBigDecimal(listName, i, "ADET")));

					itemCancelled.get(CurrencyType.TRY).set(0,
						itemCancelled.get(CurrencyType.TRY).get(0).add(dalMap.getBigDecimal(listName, i, "TUTAR_2")));
				}
			}
			
			// Target System
			Map<ReconciliationItemGroupByAccounting, Map<CurrencyType, List<BigDecimal>>> firstLevelTargetSummary = SerializationUtils
					.clone(accountingGroupSummary);

			GMMap dalClksMap = DALUtil
				.callOracleRefCursorFunction("{ ? = call pkg_rc4052.rc_qry4052_clks_ozet_tablo(?,?)}", listName,
					BnsprType.DATE, iMap.getDate("TARIH"), BnsprType.STRING, iMap.getString("ROL"));
			
			for(int i = 0; i < dalClksMap.getSize(listName); i++) {

				TransactionType transactionType = TransactionType.getEnum(dalClksMap.getInt(listName, i, "ISLEM_TURU"));
				TransactionStatus transactionStatus = TransactionStatus.getEnum(dalClksMap.getString(listName, i,
					"DURUM"));
				CurrencyType currency = CurrencyType.getEnum(dalClksMap.getString(listName, i, "PARA_BIRIMI"));
				String diffCode = dalClksMap.getString(listName, i, "FARK_KOD");

				Map<CurrencyType, List<BigDecimal>> item = firstLevelTargetSummary
					.get(transactionType.getAccountingGroup());
				
				if(item != null) {
					item.get(currency).set(0, "E".equals(diffCode) ? item.get(currency).get(0).add(
						dalClksMap.getBigDecimal(listName, i, "TUTAR")) : item.get(currency).get(0).subtract(
						dalClksMap.getBigDecimal(listName, i, "TUTAR")));
	
					item.get(currency).set(1, "E".equals(diffCode) ? item.get(currency).get(1).add(
						dalClksMap.getBigDecimal(listName, i, "ADET")) : item.get(currency).get(1).subtract(
						dalClksMap.getBigDecimal(listName, i, "ADET")));
				}
				
				if(transactionStatus == TransactionStatus.CANCELLED) {
					
					Map<CurrencyType, List<BigDecimal>> itemCancelled = firstLevelTargetSummary
						.get(FIRST_LEVEL_RECONCILIATION_ITEM_CANCELLED_MAP
							.get(transactionType.getAccountingGroup()));

					itemCancelled.get(currency).set(0, "E".equals(diffCode) ? itemCancelled.get(currency).get(0).add(
						dalClksMap.getBigDecimal(listName, i, "TUTAR")) : itemCancelled.get(currency).get(0)
							.subtract(dalClksMap.getBigDecimal(listName, i, "TUTAR")));

					itemCancelled.get(currency).set(1, "E".equals(diffCode) ? itemCancelled.get(currency).get(1).add(
						dalClksMap.getBigDecimal(listName, i, "ADET")) : itemCancelled.get(currency).get(1)
							.subtract(dalClksMap.getBigDecimal(listName, i, "ADET")));
				}
			}
			
			// Output - listNameAccountingGroup
			int idx = 0;
			for(ReconciliationItemGroupByAccounting item : ReconciliationItemGroupByAccounting.values()) {
				
				oMap.put(listNameAccountingGroup, idx, "ISLEM_TIPI", item.toString() + " Toplam Tutar");
				
				for(CurrencyType currency : CurrencyType.values()) {
					
					df.setCurrency(Currency.getInstance(currency.toString()));
					
					oMap.put(listNameAccountingGroup, idx, currency.toString() + "AKTIFBANK", df.format(
						accountingGroupSummary.get(item).get(currency).get(0)));

					if(oMap.getBoolean("CHECK_MUTABAKAT_FARK_SORGU")) {

						liability.put(currency, item.getAccountingDirection() == 1 ? liability.get(currency).add(
							firstLevelTargetSummary.get(item).get(currency).get(0)) : liability.get(currency).subtract(
							firstLevelTargetSummary.get(item).get(currency).get(0)));
						
						oMap.put(listNameAccountingGroup, idx, currency.toString() + "PTT", df.format(
							firstLevelTargetSummary.get(item).get(currency).get(0)));
					} else {
						oMap.put(listNameAccountingGroup, idx, currency.toString() + "PTT", df.format(
							BigDecimal.ZERO));
					}
				}
				
				oMap.put(listNameAccountingGroup, ++idx, "ISLEM_TIPI", item.toString() + " Adet");
				
				for(CurrencyType currency : CurrencyType.values()) {
					oMap.put(listNameAccountingGroup, idx, currency.toString() + "AKTIFBANK", accountingGroupSummary.get(item)
						.get(currency).get(1));
					
					if(oMap.getBoolean("CHECK_MUTABAKAT_FARK_SORGU")) {
						oMap.put(listNameAccountingGroup, idx, currency.toString() + "PTT", firstLevelTargetSummary.get(item)
							.get(currency).get(1));
					} else {
						oMap.put(listNameAccountingGroup, idx, currency.toString() + "PTT", BigDecimal.ZERO);
					}
				}
				idx++;
			}
			
			oMap.put(listNameAccountingGroup, idx, "ISLEM_TIPI", "Bor�");
			for(CurrencyType currency : CurrencyType.values()) {
				if(liability.get(currency).compareTo(BigDecimal.ZERO) == -1) {
					oMap.put(listNameAccountingGroup, idx, currency.toString() + "AKTIFBANK", df.format(liability.get(
						currency).abs()));
					oMap.put(listNameAccountingGroup, idx, currency.toString() + "PTT", df.format(BigDecimal.ZERO));
				} else {
					oMap.put(listNameAccountingGroup, idx, currency.toString() + "PTT", df.format(liability
						.get(currency)));
					oMap.put(listNameAccountingGroup, idx, currency.toString() + "AKTIFBANK", df.format(BigDecimal.ZERO));
				}
			}
			
			// Output - listNameCategoryGroup
			idx = 0;
			for(ReconciliationItemGroupByCategory item : ReconciliationItemGroupByCategory.values()) {
				
				oMap.put(listNameCategoryGroup, idx, "ISLEM_TIPI", item.toString());
				BigDecimal count = BigDecimal.ZERO;
				
				for(CurrencyType currency : CurrencyType.values()) {

					df.setCurrency(Currency.getInstance(currency.toString()));
					
					oMap.put(listNameCategoryGroup, idx, currency.toString(), df.format(categoryGroupSummary.get(item)
						.get(currency).get(0)));
					count = count.add(categoryGroupSummary.get(item).get(currency).get(1));
				}
				
				oMap.put(listNameCategoryGroup, idx, "ADET", count);
				idx++;
			}
			
			// Second Level - Diff (Mutabakatsiz Kayitlar)
			GMMap dalDiffMap = DALUtil.callOracleRefCursorFunction(
				"{ ? = call pkg_rc4052.rc_qry4052_clks_detay_tablo(?,?)}", listNameDiffRecords, BnsprType.DATE, iMap
					.getDate("TARIH"), BnsprType.STRING, iMap.getString("ROL"));
			
			for(int i = 0; i < dalDiffMap.getSize(listNameDiffRecords); i++) {

				TransactionType transactionType = TransactionType.getEnum(dalDiffMap.getInt(listNameDiffRecords, i,
					"ISLEM_TURU"));
				TransactionStatus transactionStatus = TransactionStatus.getEnum(dalDiffMap.getString(
					listNameDiffRecords, i, "DURUM"));
				ReconciliationGroup group = ReconciliationGroup.getEnum(dalDiffMap.getString(listNameDiffRecords, i,
					"GRUP_KOD"));
				DiffType diffType = DiffType.getEnum(dalDiffMap.getString(listNameDiffRecords, i, "FARK_KOD"));
				
				oMap.put(listNameDiffRecords, i, "ISLEM_NO", dalDiffMap.getString(listNameDiffRecords, i,
					"TX_NO"));
				oMap.put(listNameDiffRecords, i, "ISLEM_TIPI", transactionType.toString());
				oMap.put(listNameDiffRecords, i, "ISLEM_TURU", transactionType.getCode());
				oMap.put(listNameDiffRecords, i, "DURUM", transactionStatus.toString());
				oMap.put(listNameDiffRecords, i, "DURUM_ENUM_CODE", transactionStatus.getCode());
				oMap.put(listNameDiffRecords, i, "FARK_KOD_ENUM_CODE", diffType.getCode());
				oMap.put(listNameDiffRecords, i, "FARK_KOD", diffType.toString());
				oMap.put(listNameDiffRecords, i, "FARK_ACIKLAMA", dalDiffMap.getString(listNameDiffRecords,
					i, "FARK_ACIKLAMA"));
				oMap.put(listNameDiffRecords, i, "ISLEM_TUTAR",
					dalDiffMap.get(listNameDiffRecords, i, "TUTAR") != null ? df.format(dalDiffMap.getBigDecimal(
						listNameDiffRecords, i, "TUTAR")) : null);
				oMap.put(listNameDiffRecords, i, "ISLEM_PARA_BIRIMI", dalDiffMap.getString(listNameDiffRecords,
					i, "PARA_BIRIMI"));
				oMap.put(listNameDiffRecords, i, "KOMISYON_TUTAR", dalDiffMap.get(listNameDiffRecords, i,
					"KOMISYON_TUTAR") != null ? df.format(dalDiffMap.getBigDecimal(listNameDiffRecords, i,
					"KOMISYON_TUTAR")) : null);
				oMap.put(listNameDiffRecords, i, "KOMISYON_PARA_BIRIMI", dalDiffMap.getString(
					listNameDiffRecords, i, "KOMISYON_PARA_BIRIMI"));
				oMap.put(listNameDiffRecords, i, "BASVURU_NO", dalDiffMap.getString(listNameDiffRecords, i,
					"BASVURU_NO"));
				oMap.put(listNameDiffRecords, i, "GRUP_KOD_ENUM_CODE", group.getCode());
			}
			
			
			// Second Level - Diff (Mutabakatsiz Basvurular)
			GMMap dalDiffAppMap = DALUtil.callOracleRefCursorFunction(
				"{ ? = call pkg_rc4052.rc_qry4052_clks_bsv_dty_tablo(?)}", listNameDiffConsumerLoanApplications,
				BnsprType.DATE, iMap.getDate("TARIH"));
			
			for(int i = 0; i < dalDiffAppMap.getSize(listNameDiffConsumerLoanApplications); i++) {

				TransactionType transactionType = TransactionType.getEnum(dalDiffAppMap.getInt(
					listNameDiffConsumerLoanApplications, i, "ISLEM_TURU"));
				TransactionStatus transactionStatus = TransactionStatus.getEnum(dalDiffAppMap.getString(
					listNameDiffConsumerLoanApplications, i, "DURUM"));
				ReconciliationGroup group = ReconciliationGroup.getEnum(dalDiffAppMap.getString(listNameDiffConsumerLoanApplications, i,
					"GRUP_KOD"));
				DiffType diffType = DiffType.getEnum(dalDiffAppMap.getString(listNameDiffConsumerLoanApplications, i,
					"FARK_KOD"));

				oMap.put(listNameDiffConsumerLoanApplications, i, "ISLEM_NO", dalDiffAppMap.getString(
					listNameDiffConsumerLoanApplications, i, "TX_NO"));
				oMap.put(listNameDiffConsumerLoanApplications, i, "ISLEM_TIPI", transactionType.toString());
				oMap.put(listNameDiffConsumerLoanApplications, i, "ISLEM_TURU", transactionType.getCode());
				oMap.put(listNameDiffConsumerLoanApplications, i, "DURUM", transactionStatus.toString());
				oMap.put(listNameDiffConsumerLoanApplications, i, "DURUM_ENUM_CODE", transactionStatus.getCode());
				oMap.put(listNameDiffConsumerLoanApplications, i, "FARK_KOD_ENUM_CODE", diffType.getCode());
				oMap.put(listNameDiffConsumerLoanApplications, i, "FARK_KOD", diffType.toString());
				oMap.put(listNameDiffConsumerLoanApplications, i, "FARK_ACIKLAMA", dalDiffAppMap.getString(
					listNameDiffConsumerLoanApplications, i, "FARK_ACIKLAMA"));
				oMap.put(listNameDiffConsumerLoanApplications, i, "KOMISYON_TUTAR", dalDiffAppMap.get(
					listNameDiffConsumerLoanApplications, i, "KOMISYON_TUTAR") != null ? df.format(dalDiffAppMap
					.getBigDecimal(listNameDiffConsumerLoanApplications, i, "KOMISYON_TUTAR")) : null);
				oMap.put(listNameDiffConsumerLoanApplications, i, "KOMISYON_PARA_BIRIMI", dalDiffAppMap.getString(
					listNameDiffConsumerLoanApplications, i, "KOMISYON_PARA_BIRIMI"));
				oMap.put(listNameDiffConsumerLoanApplications, i, "BASVURU_NO", dalDiffAppMap.getString(
					listNameDiffConsumerLoanApplications, i, "BASVURU_NO"));
				oMap.put(listNameDiffConsumerLoanApplications, i, "GRUP_KOD_ENUM_CODE", group.getCode());
			}
			
			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_QRY4052_GET_RECORDS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY4052_RECONCILE_TRANSACTIONS")
	public static GMMap reconcileTransactions(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String listName = "INPUT";
		int recordCount = 0;
		int successfulResponseCount = 0;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			@SuppressWarnings("unchecked")
			List<HashMap<String, String>> transactions = (ArrayList<HashMap<String, String>>) iMap.get(listName);
			
			Map<ReconciliationGroup, Integer> successfulResponseByGroup = new HashMap<ReconciliationGroup, Integer>();
			for(ReconciliationGroup group : ReconciliationGroup.values()) {
				successfulResponseByGroup.put(group, Integer.valueOf(0));
			}
			
			for(HashMap<String, String> transaction : transactions) {
				
				TransactionType transactionType = TransactionType.getEnum(Integer.parseInt((String) transaction
					.get("ISLEM_TURU")));
				TransactionStatus transactionStatus = TransactionStatus.getEnum(transaction.get("DURUM_ENUM_CODE"));
				ReconciliationGroup group = ReconciliationGroup.getEnum(transaction.get("GRUP_KOD_ENUM_CODE"));
				DiffType diffType = DiffType.getEnum(transaction.get("FARK_KOD_ENUM_CODE"));
					
				if(DiffType.EKSIK_KAYIT != diffType) continue;

				if(transactionStatus == TransactionStatus.CANCELLED) continue;
				
				
				if(!EnumSet.of(TransactionType.KREDI_KULLANDIRIM_ODEMESI, TransactionType.KREDI_TAKSIT_TAHSILATI,
					TransactionType.NAKIT_YATIRMA, TransactionType.NAKIT_CEKME, TransactionType.ATM_NAKIT_YATIRMA_IBAN,
					TransactionType.ATM_NAKIT_YATIRMA_HESAP, TransactionType.ATM_KART_PASSOLIG,
					TransactionType.ATM_KART_PASSOLIG_KIMLIK, TransactionType.ATM_KART_NKOLAY,
					TransactionType.KART_NKOLAY, TransactionType.KART_PASSOLIG, TransactionType.YP_UPT_YURTICI,
					TransactionType.YP_UPT_YURTDISI, TransactionType.HESAP_ACMA).contains(transactionType)) continue;
				
				recordCount++;
				
				BigDecimal trxNo = new BigDecimal(transaction.get("ISLEM_NO"));
				if(transactionType == TransactionType.HESAP_ACMA) {
					
					ClksMutabakatFark fark = (ClksMutabakatFark) session.get(ClksMutabakatFark.class, trxNo);
					ClksislemKomisyon komisyon = (ClksislemKomisyon) session.get(ClksislemKomisyon.class, trxNo);
					if(komisyon == null) {
						
						TransactionDao<CustomerAcquisition> dao = new DalCustomerAcquisitionDao();
						CustomerAcquisition customerAcquisition = dao.get(trxNo);
						
						CommissionDao commissionDao = new GMCacheCommissionDao();
						List<CommissionRecord> commissionList = commissionDao.getByCommissionCategory(customerAcquisition.commissionCategory());
						if(commissionList != null && commissionList.size() > 0) {
							customerAcquisition.setCommissionAmount(commissionList.get(0).getCommissionAmount());
							customerAcquisition.setCommissionCurrency(commissionList.get(0).getCommissionCurrency());
						}
						dao.saveCommission(customerAcquisition);
						komisyon = (ClksislemKomisyon) session.get(ClksislemKomisyon.class, trxNo);
					}
					
					komisyon.setKayitTarih(iMap.getDate("TARIH"));
					
					session.saveOrUpdate(komisyon);
					session.delete(fark);

					successfulResponseByGroup.put(group, successfulResponseByGroup.get(group) + 1);
					successfulResponseCount++;
					
				} else {
				
					ClksMutabakatTanimPr mutabakatTanimPr = (ClksMutabakatTanimPr) session.createCriteria(
						ClksMutabakatTanimPr.class).add(
						Restrictions.eq("islemTuru", new BigDecimal(transaction.get("ISLEM_TURU")))).uniqueResult();
					
					ClksislemiliskiPr iliski = (ClksislemiliskiPr) session.createCriteria(ClksislemiliskiPr.class).add(
						Restrictions.eq("id.clksMutabakatKod", mutabakatTanimPr.getKod())).setFirstResult(0).setMaxResults(
						1).uniqueResult();
	
					ClksislemTanimPr islemTanimPr = (ClksislemTanimPr) session.get(ClksislemTanimPr.class, iliski.getId()
						.getClksIslemKod());
					
					GMMap request = new GMMap();
					
					if(transactionType == TransactionType.NAKIT_YATIRMA) {
						request.put("islemNo", transaction.get("ISLEM_NO"));
						request.put("islem", 1);
					} else if(transactionType == TransactionType.NAKIT_CEKME) {
						request.put("islemNo", transaction.get("ISLEM_NO"));
						request.put("islem", 1);
					} else if(transactionType == TransactionType.KREDI_TAKSIT_TAHSILATI) {
						request.put("islemNo", transaction.get("ISLEM_NO"));
						request.put("islem", 4);
					} else if(transactionType == TransactionType.KREDI_KULLANDIRIM_ODEMESI) {
						request.put("islemNo", transaction.get("ISLEM_NO"));
						request.put("islem", 3);
					} else if(EnumSet.of(TransactionType.ATM_NAKIT_YATIRMA_HESAP, TransactionType.ATM_NAKIT_YATIRMA_IBAN,
						TransactionType.ATM_KART_PASSOLIG_KIMLIK, TransactionType.ATM_KART_PASSOLIG,
						TransactionType.ATM_KART_NKOLAY, TransactionType.KART_NKOLAY, TransactionType.KART_PASSOLIG)
						.contains(transactionType)) {
						request.put("BANKA_ISLEM_NO", transaction.get("ISLEM_NO"));
					} else if(EnumSet.of(TransactionType.YP_UPT_YURTICI, TransactionType.YP_UPT_YURTDISI).contains(
						transactionType)) {
						request.put("ISLEM_NO", transaction.get("ISLEM_NO"));
					} else {
						request.put("TRX_NO", transaction.get("ISLEM_NO"));
					}
					
					logger.info(String.format("service:%s, tx_no:%s", islemTanimPr.getOnayServisi(), trxNo));
	
					TransactionStatus currentTransactionStatus = null;
					String currentTransactionStatusCode = (String) DALUtil.callOracleFunction(
						"{ ? = call pkg_tx.islem_durum(?)}", BnsprType.STRING, BnsprType.NUMBER, trxNo);
					try {
						currentTransactionStatus = TransactionStatus.getEnum(currentTransactionStatusCode);
					} catch(IllegalArgumentException e) {
						logger.info(String.format("service:%s, tx_no:%s, status:%s - %s", islemTanimPr.getOnayServisi(),
							trxNo, currentTransactionStatusCode, "Skipping.."));
					}
					
					boolean isCallFailed = false;
					if(currentTransactionStatus == transactionStatus 
						&& currentTransactionStatus == TransactionStatus.PROCESSED) {
						logger.info(String.format("service:%s, tx_no:%s, status:%s - %s", islemTanimPr.getOnayServisi(),
							trxNo, TransactionStatus.PROCESSED.toString(), "Skipping.."));
					}
					
					else {
					
						DALUtil.callOracleFunction("{ ? = call pkg_rc4052.update_trx_to_reconcile(?)}", BnsprType.NUMBER,
							BnsprType.NUMBER, trxNo);
						
						try {
							
							GMMap response = remoteCall(islemTanimPr.getOnayServisi(), request);
							
							String serviceResponse = response.getString("RESPONSE", response.getString("islemSonuc"));
							String serviceMessage = response.getString("RESPONSE_DATA", response.getString("hataMesaji"));
							
							logger.info(String.format("service:%s, tx_no:%s, response:%s, responseData:%s", islemTanimPr
								.getOnayServisi(), transaction.get("ISLEM_NO"), serviceResponse, serviceMessage));
							
							if(!"2".equals(serviceResponse)) {
								isCallFailed = true;
								logger.error(String.format("%s:%s(%s) -> %s", "BNSPR_QRY4052_RECONCILE_TRANSACTIONS err", islemTanimPr
									.getOnayServisi(), request.toString(), response.toString()));
							}
							
						} catch(Exception e) {
							isCallFailed = true;
							logger.error(String.format("%s:%s(%s)", "BNSPR_QRY4052_RECONCILE_TRANSACTIONS err", islemTanimPr
								.getOnayServisi(), request.toString()), e);
						}
						
						if(EnumSet.of(TransactionType.YP_UPT_YURTICI, TransactionType.YP_UPT_YURTDISI).contains(
							transactionType)) {
							try {
	
								currentTransactionStatusCode = (String) DALUtil.callOracleFunction(
									"{ ? = call pkg_tx.islem_durum(?)}", BnsprType.STRING, BnsprType.NUMBER, trxNo);
	
								currentTransactionStatus = TransactionStatus.getEnum(currentTransactionStatusCode);
	
							} catch(Exception ie) {}
	
							if(currentTransactionStatus == transactionStatus
								&& currentTransactionStatus == TransactionStatus.PROCESSED) {
								isCallFailed = false;
								logger.info(String.format("service:%s, tx_no:%s, status:%s - %s", islemTanimPr
									.getOnayServisi(), trxNo, TransactionStatus.PROCESSED.toString(),
									"Cross-Check - Skipping.."));
							}
						}
					}
				
					if(!isCallFailed) {
						
						ClksMutabakatFark fark = (ClksMutabakatFark) session.get(ClksMutabakatFark.class, trxNo);
						ClksislemKomisyon komisyon = (ClksislemKomisyon) session.get(ClksislemKomisyon.class, trxNo);
						komisyon.setKayitTarih(iMap.getDate("TARIH"));
						
						session.saveOrUpdate(komisyon);
						session.delete(fark);
	
						successfulResponseByGroup.put(group, successfulResponseByGroup.get(group) + 1);
						successfulResponseCount++;
					}
				}
			}
			
			if(successfulResponseCount > 0) {
				
				Map<String, Object> restrictions = new HashMap<String, Object>();
				restrictions.put("mutabakatTarihi", iMap.getDate("TARIH"));
				restrictions.put("durum", "A");
				
				for(ReconciliationGroup group : ReconciliationGroup.values()) {
					restrictions.put("grupKod", group.getCode());
					
					ClksMutabakatFarkSorgu sorgu = (ClksMutabakatFarkSorgu) session.createCriteria(
						ClksMutabakatFarkSorgu.class).add(Restrictions.allEq(restrictions)).uniqueResult();
					
					if(sorgu != null) {
						sorgu.setEksikKayit(sorgu.getEksikKayit().subtract(
							BigDecimal.valueOf(successfulResponseByGroup.get(group))));
						session.saveOrUpdate(sorgu);
					}
				}
				
				session.flush();
			}
			
			oMap.put("KAYIT_ADET", recordCount);
			oMap.put("BASARILI_KAYIT_ADET", BigDecimal.valueOf(successfulResponseCount));
			oMap.put("MESSAGE", String.format("%s i�lemden %s adedi sonu�land�.", recordCount, successfulResponseCount));
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_QRY4052_RECONCILE_TRANSACTIONS err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
