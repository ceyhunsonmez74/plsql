package tr.com.aktifbank.bnspr.adc.clks.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionType;
import tr.com.aktifbank.bnspr.dao.ClksKomisyonPr;

import com.graymound.cache.GMCacheLoader;
import com.graymound.server.dao.DAOSession;

public class CommissionTableLoader implements GMCacheLoader {
	
	private static Logger logger = Logger.getLogger(CommissionTableLoader.class);

	@Override
	public Map<String, Object> load() {
		Map<String, Object> map = new HashMap<String, Object>();

		try {
			for(CommissionCategory category : CommissionCategory.values()) {
				map.put(category.toString(), new ArrayList<CommissionRecord>());
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			Map<String, String> restrictions = new HashMap<String, String>();
			restrictions.put("masrafTuru", "T");
			
			@SuppressWarnings("unchecked")
			List<ClksKomisyonPr> records = session.createCriteria(ClksKomisyonPr.class).add(
				Restrictions.allEq(restrictions)).list();
			
			for(Iterator<ClksKomisyonPr> iter = records.iterator(); iter.hasNext();) {
				
				ClksKomisyonPr next = iter.next();
				
				if(next != null && map.get(next.getIslemTuru()) != null) {
					
					@SuppressWarnings("unchecked")
					List<CommissionRecord> currentList = (ArrayList<CommissionRecord>) map.get(next.getIslemTuru());
					
					currentList.add(new CommissionRecord.Builder(next.getMasrafBaslangicTutar(), 
							next.getMasrafBitisTutar(), CurrencyType.getEnum(next.getIslemDovizKodu()))
						.commissionType("S".equals(next.getMasrafTipi()) ? CommissionType.FIX_AMOUNT : CommissionType.RATIO)
						.commissionAmount(next.getMasrafTutarOran())
						.commissionCurrency(CurrencyType.getEnum(next.getMasrafDovizKodu()))
						.minCommissionAmount(next.getMinTutar())
						.maxCommissionAmount(next.getMaxTutar())
						.build());
				}
			}
		} catch(Exception e) {
			logger.error("Cache Error: ", e);
		}
		
		return map;
	}

	@Override
	public Object lookup(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
