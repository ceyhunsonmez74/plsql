package tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CustomerAcquisition;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;

public class CustomerAcquisitionProcess extends TransactionBaseProcess<CustomerAcquisition> implements
	TransactionProcess<CustomerAcquisition> {

	public CustomerAcquisitionProcess(TransactionDao<CustomerAcquisition> dao) {
		super(dao);
	}

	@Override
	public void request(CustomerAcquisition transaction) {
		super.request(transaction);
	}

	@Override
	public void confirm(CustomerAcquisition transaction) {
		super.confirm(transaction);
	}
}
