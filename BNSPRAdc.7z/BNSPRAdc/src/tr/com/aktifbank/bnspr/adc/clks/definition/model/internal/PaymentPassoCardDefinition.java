package tr.com.aktifbank.bnspr.adc.clks.definition.model.internal;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.TransactionDefinition;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.internal.ForeignCurrencyTransferDefinition.AccountingType;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

public class PaymentPassoCardDefinition extends BaseTransactionDefinition implements TransactionDefinition {

	public PaymentPassoCardDefinition() {
		super(new String[]{"2053"}, "65");
	}
	
	@Override
	public Map<?, ?> getReconciliationRecords(Date date, String listName) throws SQLException {
		
		GMMap oMap = new GMMap(), records = DALUtil.callOracleRefCursorFunction(
				"{? = call pkg_trn2052.get_payment_passocard_records(?)}", listName, BnsprType.DATE, date);
			
	for(int i = 0; i < records.getSize(listName); i++) {
			GMMap accountingMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "TUTAR")).put(
				"PARA_BIRIMI", records.getString(listName, i, "PARA_BIRIMI")).put("MASRAF", "H");
			GMMap commisionMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "KOMISYON_TUTAR")).put(
				"PARA_BIRIMI", records.getString(listName, i, "KOMISYON_PARA_BIRIMI"));
			GMMap clientMap = new GMMap().put("SUBE_ID", records.getString(listName, i, "SUBE_ID")).put(
				"PERSONEL_SICIL", records.getString(listName, i, "PERSONEL_SICIL")).put("PERSONEL_ADI",
				records.getString(listName, i, "PERSONEL_ADI"));

			oMap.put(listName, i, "ISLEM_TIPI", reconciliationCode);
			oMap.put(listName, i, "ISLEM_NO", records.getBigDecimal(listName, i, "ISLEM_NO"));
			oMap.put(listName, i, "DURUM", records.getString(listName, i, "DURUM"));
			oMap.put(listName, i, "MUHASEBE", new ArrayList<GMMap>(Arrays.asList(accountingMap)));
			oMap.put(listName, i, "KOMISYON", new ArrayList<GMMap>(Arrays.asList(commisionMap)));
			oMap.put(listName, i, "MUSTERI_DETAY", new ArrayList<GMMap>(Arrays.asList(clientMap)));
		}	
		return oMap;
	}

	@Override
	public Map<?, ?> getRecords(Date date, String listName) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<?, ?> getConfirmData(BigDecimal trxNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String reconciliationCode() {
		// TODO Auto-generated method stub
		return null;
	}

}
