package tr.com.aktifbank.bnspr.adc.clks.core.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class Branch implements Serializable {

	private static final long serialVersionUID = 3524314081180324904L;
	
	/**
	 * Merkez Kod
	 */
	private Branch headBranch;
	
	/**
	 * Sube Kod
	 */
	private String branchCode;
	
	/**
	 * Sube Id 
	 */
	private BigDecimal branchId;
	
	/**
	 * Basmudurluk
	 */
	private Region region;
	
	/**
	 * Il kodu
	 */
	private String provinceCode;
	
	
	/**
	 * Sube aciklama
	 */
	private String description;
	
	public Branch(String branchCode, Branch headBranch) {
		this.branchCode = branchCode;
		this.headBranch = headBranch;
	}
	
	/**
	 * @return Merkez sube ise {@code true}, aksi durumda {@code false}
	 */
	public boolean isHeadBranch() {
		return "1".equals(branchCode) ? true : false;
	}

	/**
	 * @return Merkez sube kodu, eger merkez sube ise {@code null}
	 */
	public String getHeadBranchCode() {
		return headBranch != null ? headBranch.getBranchCode() : null;
	}
	
	/**
	 * @return {@link #headBranch}
	 */
	public Branch getHeadBranch() {
		return headBranch;
	}

	/**
	 * @param headBranch {@link #headBranch}
	 */
	public void setHeadBranch(Branch headBranch) {
		this.headBranch = headBranch;
	}

	/**
	 * @return {@link #branchCode}
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * @param branchCode {@link #branchCode}
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * @return {@link #branchId}
	 */
	public BigDecimal getBranchId() {
		return branchId;
	}

	/**
	 * @param branchId {@link #branchId}
	 */
	public void setBranchId(BigDecimal branchId) {
		this.branchId = branchId;
	}

	/**
	 * @return {@link #description}
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description {@link #description}
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return {@link #region}
	 */
	public Region getRegion() {
		return region;
	}

	/**
	 * @param region {@link #region}
	 */
	public void setRegion(Region region) {
		this.region = region;
	}

	/**
	 * @return {@link #provinceCode}
	 */
	public String getProvinceCode() {
		return provinceCode;
	}

	/**
	 * @param provinceCode {@link #provinceCode}
	 */
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}
}
