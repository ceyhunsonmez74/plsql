package tr.com.aktifbank.bnspr.adc.clks.core.api.internal;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.adc.clks.core.api.CoreApplicationApi;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class GMCoreApplicationApi implements CoreApplicationApi {
	
	private static Logger logger = Logger.getLogger(GMCoreApplicationApi.class);

	@Override
	public String crsInfo(String nationalIdentityNumber) {
		GMMap oMap = GMServiceExecuter.call("BNSPR_CLKS_GET_CRS_INFO", new GMMap().put("NATIONAL_IDENTITY_NUMBER",
			nationalIdentityNumber));
		
		return oMap.getString("CRS_INFO");
	}

	@Override
	public void updateCrsInfo(String nationalIdentityNumber, boolean isCrsReportable) {
		GMServiceExecuter.call("BNSPR_CLKS_INSERT_CRS_INFO",  new GMMap().put("NATIONAL_IDENTITY_NUMBER",
			nationalIdentityNumber).put("CRS_INFO", isCrsReportable ? "E" : "H"));
	}
	
	@Override
	public void setGroupPersonalDatePermission(BigDecimal customerNo, String productCode) {
		GMServiceExecuter.call("BNSPR_CUSTOMER_SET_GROUP_PERSONAL_DATA_PERMISSION", new GMMap().put("CUSTOMER_NO",
			customerNo).put("STATUS", "E").put("PRODUCT_CODE", productCode).put("IS_AUTHORIZED_TRANSACTION", "E"));
	}
	
	@Override
	public void updateCustomerMarketingPermission(BigDecimal customerNo, String nationalIdentityNumber) {
		GMServiceExecuter.call("BNSPR_CUSTOMER_UPDATE_MARKETING_PERMISSION", new GMMap().put("TCKN",
			nationalIdentityNumber).put("CHANNEL", "BANKA").put("CUSTOMER_NO", customerNo));
	}

	@Override
	public String getParameter(String code) {
		return GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", code)).getString(
			"DEGER");
	}

	@Override
	public String message(int messageNumber, Map<String, String> parameters) {
		
		GMMap iMap = new GMMap();
		iMap.put("MESSAGE_NO", BigDecimal.valueOf(messageNumber));
		iMap.putAll(parameters);
		
		return GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE");
	}

	@Override
	public String message(int messageNumber, String... parameters) {
		
		GMMap iMap = new GMMap();
		iMap.put("MESSAGE_NO", BigDecimal.valueOf(messageNumber));

		for(int i = 0; i < parameters.length; i++) {	
			iMap.put(String.format("%s%s", "P", i + 1), parameters[i]);
		}
		
		return GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE");
	}
	
	@Override
	public void error(int messageNumber, Map<String, String> parameters) {
		
		GMMap iMap = new GMMap();
		iMap.put("HATA_NO", BigDecimal.valueOf(messageNumber));
		iMap.putAll(parameters);
		
		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	}

	@Override
	public void error(int messageNumber, String... parameters) {
		
		GMMap iMap = new GMMap();
		iMap.put("HATA_NO", BigDecimal.valueOf(messageNumber));

		for(int i = 0; i < parameters.length; i++) {	
			iMap.put(String.format("%s%s", "P", i + 1), parameters[i]);
		}
		
		GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
	}
	
	@Override
	public void sendText(BigDecimal trxNo, BigDecimal customerNo, String msisdn, String content,
		int messageNumber) {

		if(content == null) {
			content = message(messageNumber, new HashMap<String,String>());
		}

		GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", new GMMap().put("MSISDN", msisdn).put("CONTENT", content)
			.put("TRX_NO", trxNo).put("MUSTERI_NO", customerNo));
	}

	@Override
	public boolean isMobilePhoneExistsOnAnotherCustomer(String nationalIdentityNumber, String areaCode, String phoneNumber) {

		GMMap responseMap = GMServiceExecuter.call("BNSPR_CLKS_CUSTOMER_EXISTING_MOBILE_PHONE_CONTROL", new GMMap().put(
			"TC_KIMLIK_NO", nationalIdentityNumber).put("CEP_TEL_KOD", areaCode).put("CEP_TEL_NO", phoneNumber));
		
		// TODO implement enumaration for response
		if("2".equals(responseMap.getString("RESPONSE"))) return false;
		
		return true;
	}

	@Override
	public void sendMail(String from, String to, String subject, String body, boolean isHtml, BigDecimal trxNo) {
		
		logger.info(String.format("Sending mail from %s to %s", from, to));
		
		if(trxNo == null) {
			trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
		}

		GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", new GMMap().put("MAIL_FROM", from).put("MAIL_TO",
			to).put("MAIL_SUBJECT", subject).put("MAIL_BODY", body).put("IS_BODY_HTML", isHtml ? "E" : "H").put(
			"TRX_NO", trxNo));
		
		logger.info(String.format("Mail sent from %s to %s", from, to));
	}

	@Override
	public void eventCall(String serviceName, Map<?, ?> paremeters, boolean async) {
		
		if(async) {
			GMServiceExecuter.executeAsync(serviceName, paremeters);
		} else {
			GMServiceExecuter.execute(serviceName, paremeters);
		}
		
	}
}
