package tr.com.aktifbank.bnspr.adc.clks.consumerloan.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class Campaign implements Serializable {

	private static final long serialVersionUID = -5159376375493437399L;
	
	/**
	 * Kampanya Kodu
	 */
	private final BigDecimal code;
	
	/**
	 * Kampanya Kanal Kodu
	 */
	private final BigDecimal channelCode;
	
	/* Credit Property Flags */
	
	/**
	 * Kampanya Aciklamasi
	 */
	private String description;
	
	/**
	 * Borc Transferi Kredisi
	 */
	private boolean balanceTransfer;
	
	/**
	 * Yapilandirma (Birlestirme) Kredisi
	 */
	private boolean consolidation;
	
	/**
	 * Gorme Engelliler icin Kredi
	 */
	private boolean visualImpairment;
	
	/**
	 * Genel (3. Sahis) Kredi
	 */
	private boolean publicCredit;
	
	/**
	 * PTT i�i Birlestirme Kredisi
	 */
	private boolean consolidationOnChannel;
	
	/* Campaign Properties */
	
	/**
	 * Kredi Turu
	 */
	private CreditType creditType;
	
	/**
	 * Hersey Dahil
	 */
	private boolean allIncluded;
	
	/**
	 * Kullandirim Bloke Kodu
	 */
	private String accountBlockCode;
	
	/**
	 * Kampanya icin izin verilen en dusuk tutar
	 */
	private BigDecimal minAmount;
	
	/**
	 * Kampanya icin izin verilen en yuksek tutar
	 */
	private BigDecimal maxAmount;
	
	/**
	 * Kampanya icin izin verilen en dusuk vade
	 */
	private int minTerm;
	
	/**
	 * Kampanya icin izin verilen en yuksek vade
	 */
	private int maxTerm;
	
	/**
	 * Kampanya - Maas Alinan Kurum iliskisi
	 */
	private Relation relation;
	
	/**
	 * Kredi Tur
	 *
	 */
	public enum CreditType {
		IHTIYAC_KREDISI(1),
		KONUT_KREDISI(2),
		TASIT_KREDISI(3),
		KDH(5);
		
		private int code;
		
		CreditType(int code) {
			this.code = code;
		}

		/**
		 * @return Kredi Tur Kod
		 */
		public int getCode() {
			return code;
		}
		
		public static CreditType getEnum(int code) {
			for(CreditType v : values())
				if(v.getCode() == code)
					return v;
			throw new IllegalArgumentException("Eslesmeyen Kredi Turu (" + String.valueOf(code) + ")");
		}
	}
	
	/**
	 * Kampanya Iliskisi
	 */
	public enum Relation {
		RETIREE("E"), PERSONNEL("PTTPER"), OTHER("D");
		
		private String code;
		
		Relation(String code) {
			this.code = code;
		}
		
		@Override
		public String toString() {
			return code;
		}
	}
	
	public static class Builder {
		
		private final BigDecimal code;
		private final BigDecimal channelCode;
		
		private String description = null;
		private CreditType creditType = null;
		private boolean allIncluded = false;
		private boolean balanceTransfer = false;
		private boolean publicCredit = false;
		private boolean consolidation = false;
		private boolean visualImpairment = false;
		private boolean consolidationOnChannel = false;
		private String accountBlockCode = null ;
		private BigDecimal minAmount = null;
		private BigDecimal maxAmount = null;
		private int minTerm = 0;
		private int maxTerm = 0;
		private Relation relation;
		
		public Builder(BigDecimal code, BigDecimal channelCode) {
			this.code = code;
			this.channelCode = channelCode;
		}
		
		public Builder description(String description) {
			this.description = description;
			return this;
		}
		
		public Builder creditType(CreditType creditType) {
			this.creditType = creditType;
			return this;
		}

		public Builder allIncluded(boolean allIncluded) {
			this.allIncluded = allIncluded;
			return this;
		}

		public Builder balanceTransfer(boolean balanceTransfer) {
			this.balanceTransfer = balanceTransfer;
			return this;
		}

		public Builder publicCredit(boolean publicCredit) {
			this.publicCredit = publicCredit;
			return this;
		}

		public Builder consolidation(boolean consolidation) {
			this.consolidation = consolidation;
			return this;
		}
		
		public Builder visualImpairment(boolean visualImpairment) {
			this.visualImpairment = visualImpairment;
			return this;
		}

		public Builder consolidationOnChannel(boolean consolidationOnChannel) {
			this.consolidationOnChannel = consolidationOnChannel;
			return this;
		}
		
		public Builder accountBlockCode(String accountBlockCode) {
			this.accountBlockCode = accountBlockCode;
			return this;
		}
		
		public Builder minAmount(BigDecimal minAmount) {
			this.minAmount = minAmount;
			return this;
		}
		
		public Builder maxAmount(BigDecimal maxAmount) {
			this.maxAmount = maxAmount;
			return this;
		}
		
		public Builder minTerm(int minTerm) {
			this.minTerm = minTerm;
			return this;
		}
		
		public Builder maxTerm(int maxTerm) {
			this.maxTerm = maxTerm;
			return this;
		}
		
		public Builder relation(Relation relation) {
			this.relation = relation;
			return this;
		}
		
		public Campaign build() {
			return new Campaign(this);
		}
	}
	
	private Campaign(Builder builder) {
	
		this.code = builder.code;
		this.channelCode = builder.channelCode;
		this.description = builder.description;
		this.accountBlockCode = builder.accountBlockCode;
		this.allIncluded = builder.allIncluded;
		this.balanceTransfer = builder.balanceTransfer;
		this.publicCredit = builder.publicCredit;
		this.consolidation = builder.consolidation;
		this.visualImpairment = builder.visualImpairment;
		this.consolidationOnChannel = builder.consolidationOnChannel;
		this.creditType = builder.creditType;
		this.maxAmount = builder.maxAmount;
		this.minAmount = builder.minAmount;
		this.maxTerm = builder.maxTerm;
		this.minTerm = builder.minTerm;
		this.relation = builder.relation;
		
		if(this.relation == null) {
			this.relation = this.balanceTransfer || this.publicCredit ? Relation.OTHER : null;
		}
		
	}
	
	/**
	 * @return {@link #code}
	 */
	public BigDecimal getCode() {
		return code;
	}
	
	/**
	 * @return {@link #channelCode}
	 */
	public BigDecimal getChannelCode() {
		return channelCode;
	}

	/**
	 * @return {@link #description}
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @return {@link #creditType}
	 */
	public CreditType getCreditType() {
		return creditType;
	}

	/**
	 * {@link #creditType}
	 */
	public void setCreditType(CreditType creditType) {
		this.creditType = creditType;
	}

	/**
	 * @return {@link #allIncluded}
	 */
	public boolean isAllIncluded() {
		return allIncluded;
	}

	/**
	 * {@link #allIncluded}
	 */
	public void setAllIncluded(boolean allIncluded) {
		this.allIncluded = allIncluded;
	}

	/**
	 * @return {@link #balanceTransfer}
	 */
	public boolean isBalanceTransfer() {
		return balanceTransfer;
	}

	/**
	 * @param balanceTransfer - {@link #balanceTransfer}
	 */
	public void setBalanceTransfer(boolean balanceTransfer) {
		this.balanceTransfer = balanceTransfer;
		
		if(this.relation == null) {
			this.relation = this.balanceTransfer ? Relation.OTHER : null;
		}
	}

	/**
	 * @return {@link #publicCredit}
	 */
	public boolean isPublicCredit() {
		return publicCredit;
	}

	/**
	 * @param publicCredit - {@link #publicCredit}
	 */
	public void setPublicCredit(boolean publicCredit) {
		this.publicCredit = publicCredit;
		
		if(this.relation == null) {
			this.relation = this.publicCredit ? Relation.OTHER : null;
		}
	}

	/**
	 * @return {@link #consolidation}
	 */
	public boolean isConsolidation() {
		return consolidation;
	}

	public void setConsolidation(boolean consolidation) {
		this.consolidation = consolidation;
	}

	/**
	 * @return {@link #visualImpairment}
	 */
	public boolean isVisualImpairment() {
		return visualImpairment;
	}

	public void setVisualImpairment(boolean visualImpairment) {
		this.visualImpairment = visualImpairment;
	}

	/**
	 * @return {@link #consolidationOnChannel
	 */
	public boolean isConsolidationOnChannel() {
		return consolidationOnChannel;
	}

	/**
	 * @param consolidationOnChannel the consolidationOnChannel to set
	 */
	public void setConsolidationOnChannel(boolean consolidationOnChannel) {
		this.consolidationOnChannel = consolidationOnChannel;
	}

	/**
	 * @return {@link #accountBlockCode}
	 */
	public String getAccountBlockCode() {
		return accountBlockCode;
	}

	public void setAccountBlockCode(String accountBlockCode) {
		this.accountBlockCode = accountBlockCode;
	}

	/**
	 * @return {@link #minAmount}
	 */
	public BigDecimal getMinAmount() {
		return minAmount;
	}

	public void setMinAmount(BigDecimal minAmount) {
		this.minAmount = minAmount;
	}

	/**
	 * @return {@link #maxAmount}
	 */
	public BigDecimal getMaxAmount() {
		return maxAmount;
	}

	public void setMaxAmount(BigDecimal maxAmount) {
		this.maxAmount = maxAmount;
	}

	/**
	 * @return {@link #minTerm}
	 */
	public int getMinTerm() {
		return minTerm;
	}

	public void setMinTerm(int minTerm) {
		this.minTerm = minTerm;
	}

	/**
	 * @return {@link #maxTerm}
	 */
	public int getMaxTerm() {
		return maxTerm;
	}

	public void setMaxTerm(int maxTerm) {
		this.maxTerm = maxTerm;
	}
	
	/**
	 * @return {@link #relation}
	 */
	public Relation getRelation() {
		return relation;
	}
	
	public void setRelation(Relation relation) {
		this.relation = relation;
	}

	@Override
	public String toString() {
		return String.format("%s(kod=%s, relation=%s)", Campaign.class.getSimpleName(), this.getCode()
			.toString(), this.getRelation() != null ? this.getRelation().toString() : "null");
	}
}
