package tr.com.aktifbank.bnspr.adc.clks.services;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionContext;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal.GMCacheCommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalCashDepositDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal.DalInstallmentLoanDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CashDeposit;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.InstallmentLoan;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.TransactionProcess;
import tr.com.aktifbank.bnspr.adc.clks.transaction.process.internal.CashDepositProcess;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;

import com.graymound.server.dao.DAOSession;
import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CashDepositServices {
	
	private static Logger logger = Logger.getLogger(CashDepositServices.class);
	
	@GraymoundService("BNSPR_CLKS_CASH_DEPOSIT_CONFIRM")
	public static GMMap confirm(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			TransactionDao<CashDeposit> dao = new DalCashDepositDao();
			CashDeposit cashDeposit = dao.get(iMap.getBigDecimal("ISLEM_NO"));

			// TODO Refactor into process class
			if(cashDeposit.reconciliationType() == ReconciliationType.INSTALLMENT_LOAN) {
				
				Map<String, Object> restrictions = new HashMap<String, Object>();
				restrictions.put("pttHavaleTxno", cashDeposit.trxNo());
				
				InstallmentLoan installmentLoan = new DalInstallmentLoanDao().filter(restrictions).get(0);

				Session session = DAOSession.getSession("BNSPRDal");
				BirBasvuru basvuru = (BirBasvuru) session.get(BirBasvuru.class, installmentLoan.getApplicationNo());
				
				cashDeposit.setCommissionCategory(!"7".equals(basvuru.getKanalKodu())
					? CommissionCategory.KREDI_TAHSILAT_EMEKLI_DIGER_KANAL : Arrays.asList("1", "2", "3").contains(
						basvuru.getPttMaasAlinanKurum()) ? CommissionCategory.KREDI_TAHSILAT_EMEKLI : "4".equals(basvuru
						.getPttMaasAlinanKurum()) ? CommissionCategory.KREDI_TAHSILAT_PERSONEL
						: CommissionCategory.KREDI_TAHSILAT_DIGER);
				
			}
			
			TransactionProcess<CashDeposit> process = new CashDepositProcess(dao);
			process.confirm(cashDeposit);
			
			GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", new GMMap().put("ISLEM_TURU", "O").put(
				"ISLEM_NO", cashDeposit.trxNo()).put("ISLEM_KODU", BigDecimal.valueOf(cashDeposit.trxCode())));
			
			return oMap;
			
		} catch(Exception e) {
			logger.error("BNSPR_CLKS_CASH_DEPOSIT_CONFIRM err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
}
