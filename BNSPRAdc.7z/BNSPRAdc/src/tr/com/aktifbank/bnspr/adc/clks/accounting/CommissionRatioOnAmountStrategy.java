package tr.com.aktifbank.bnspr.adc.clks.accounting;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.model.CommissionRecord;

public class CommissionRatioOnAmountStrategy extends CommissionOnAmount implements CommissionStrategy {

	/**
	 * @param records	Komisyon barem listesi
	 */
	public CommissionRatioOnAmountStrategy(List<CommissionRecord> records) {
		super(records);
	}

	@Override
	public Record calculate(Record transactionRecord) {
		
		for(CommissionRecord record : this.getRecords()) {
			
			if(transactionRecord.getCurrency() == record.getCurrency()
				&& transactionRecord.getAmount().compareTo(record.getStartingAmount()) >= 0
					&& transactionRecord.getAmount().compareTo(record.getEndingAmount()) <= 0) {
				
				BigDecimal calculated = record.getCommissionAmount().multiply(transactionRecord.getAmount());
				calculated = calculated.setScale(2, RoundingMode.HALF_UP);
				
				if(record.getMinCommissionAmount() != null
					&& calculated.compareTo(record.getMinCommissionAmount()) == -1) {
					calculated = record.getMinCommissionAmount();
				} else if(record.getMaxCommissionAmount() != null
					&& calculated.compareTo(record.getMaxCommissionAmount()) == 1) {
					calculated = record.getMaxCommissionAmount();	
				}
				
				
				return new Record(calculated, record.getCommissionCurrency());
			}
		}
		
		return null;
	}
}
