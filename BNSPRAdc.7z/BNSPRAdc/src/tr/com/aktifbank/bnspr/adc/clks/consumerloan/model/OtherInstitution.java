package tr.com.aktifbank.bnspr.adc.clks.consumerloan.model;

public class OtherInstitution implements Institution {
	
	private final ShortCode shortCode;
	private final CampaignType campaignType;

	public OtherInstitution() {
		this.shortCode = ShortCode.DIGER;
		this.campaignType = CampaignType.DIGER;
	}

	@Override
	public ShortCode getShortCode() {
		return shortCode;
	}

	@Override
	public CampaignType getCampaignType() {
		return campaignType;
	}

}
