package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CashWithdrawal;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;

import com.graymound.server.dao.DAOSession;

public class DalCashWithdrawalDao extends DalTransactionDao<CashWithdrawal> implements TransactionDao<CashWithdrawal> {

	public DalCashWithdrawalDao() {
		super(CashWithdrawal.class);
	}

	@Override
	public CashWithdrawal get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		ClksHavaleOdemeTx clksHavaleOdemeTx = (ClksHavaleOdemeTx) session.get(ClksHavaleOdemeTx.class, trxNo);
		
		CashWithdrawal cashWithdrawal = new CashWithdrawal(clksHavaleOdemeTx.getTxNo());
		cashWithdrawal.setAmount(clksHavaleOdemeTx.getTutar());
		cashWithdrawal.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
		cashWithdrawal.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
		return cashWithdrawal;
	}

	@Override
	public List<CashWithdrawal> filter(Map<String, Object> criteria) {
		
		List<CashWithdrawal> cashWithdrawalList = new ArrayList<CashWithdrawal>();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<ClksHavaleOdemeTx> list = session.createCriteria(ClksHavaleOdemeTx.class).add(Restrictions.allEq(criteria))
			.list();

		for(ClksHavaleOdemeTx clksHavaleOdemeTx : list) {
			
			CashWithdrawal cashWithdrawal = new CashWithdrawal(clksHavaleOdemeTx.getTxNo());
			cashWithdrawal.setAmount(clksHavaleOdemeTx.getTutar());
			cashWithdrawal.setCurrency(CurrencyType.getEnum(clksHavaleOdemeTx.getDovizKodu()));
			cashWithdrawal.setClientTrxNo(clksHavaleOdemeTx.getPttIslemNo());
			cashWithdrawalList.add(cashWithdrawal);
		}
		return cashWithdrawalList;
	}

	@Override
	public List<CashWithdrawal> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(CashWithdrawal type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(CashWithdrawal type) {
		// TODO Auto-generated method stub
		
	}
}
