package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transaction;
import tr.com.aktifbank.bnspr.dao.ClksislemKomisyon;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.dao.DAOSession;

abstract class DalTransactionDao<T extends Transaction> implements TransactionDao<T> {

	private Class<T> entityType;
	
	public DalTransactionDao(Class<T> entityType) {
		this.entityType = entityType;
	}

	@Override
	public void saveCommission(T transaction) {
		
		Session session = DAOSession.getSession("BNSPRDal");

		ClksislemKomisyon record = (ClksislemKomisyon) session.get(ClksislemKomisyon.class, transaction.trxNo());

		if(record != null) return;

		record = new ClksislemKomisyon(transaction.trxNo(), new BigDecimal(transaction.reconciliationType().toString().replace(",", "")));
		record.setKomisyonTuru(transaction.commissionCategory() != null ? transaction.commissionCategory().toString() : null);
		record.setKayitTarih(new java.util.Date());
		record.setTutar(transaction.commissionAmount());
		record.setDovizKodu(transaction.commissionCurrency() != null ? transaction.commissionCurrency().toString() : null);

		session.save(record);
		session.flush();
	}
	
	@Override
	public StateType getState(T transaction) {
		
		try {
			String state = (String) DALUtil.callOracleFunction("{ pkg_tx.islem_durum(?) }", BnsprType.STRING,
				BnsprType.NUMBER, transaction.trxNo());
			
			if("P".equals(state)) return StateType.PROCESSED;
			else if("2".equals(state)) return StateType.CANCELLED;
			else if("C".equals(state)) return StateType.CREATED;
			else return StateType.OTHER;
			
		} catch(SQLException e) {
			return StateType.NOT_FOUND;
		}
	}
	
	protected Class<T> getEntityType() {
		return entityType;
	}
}
