package tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao;

import java.math.BigDecimal;
import java.sql.SQLException;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.dao.BaseDao;

public interface CreditApplicationDao<T extends Application> extends BaseDao<T>  {
	
	/**
	 * Komisyon kaydini saklar.
	 * 
	 * @param application {@link Application}
	 */
	public void saveCommission(T application);
	
	/**
	 * Red basvuru durumunda komisyon niteligini hesaplar, saklar ve bilgi saglar.
	 * 
	 * @param applicationNo {@link Application#getApplicationNo()}
	 * @param nationalIdentificationNumber {@link Application#getNationalIdentificationNumber()}
	 * @return Red komisyonu nitelikli olmasi durumunda "E", aksi durumda "H".
	 * @throws SQLException 
	 */
	public String updateQualifiedCommissionOnReject(BigDecimal applicationNo, String nationalIdentificationNumber)
		throws SQLException;
	
	/**
	 * Ara statuye dusmus basvurularin ilerletilmesi durumunda yeni durumlarini saglar. 
	 * 
	 * @param applicationNo {@link Application#getApplicationNo()}
	 * @return {@link Application#getStatus()}
	 * @throws SQLException
	 */
	public Application.STATUS saveOrUpdateApplicationStatusOnQuery(BigDecimal applicationNo) throws SQLException;
	
	/**
	 * Ara statuye dusmus basvuruyu kaydeder.
	 * 
	 * @param applicationNo {@link Application#getApplicationNo()}
	 * @throws SQLException
	 */
	public void saveAsPendingApplication(BigDecimal applicationNo, Application.STATUS status) throws SQLException;
}
