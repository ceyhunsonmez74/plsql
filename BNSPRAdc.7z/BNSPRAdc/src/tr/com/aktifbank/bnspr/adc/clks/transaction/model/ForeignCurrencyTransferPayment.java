package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

/**
 * YP UPT/Swift Odemeleri
 *
 */
public class ForeignCurrencyTransferPayment extends Payment {

	private static final long serialVersionUID = 3382340647707613789L;

	/**
	 * Finansal sistem saglayici
	 */
	private PROVIDER provider;
	
	public enum PROVIDER {
		UPT, SWIFT
	}
	
	public ForeignCurrencyTransferPayment(BigDecimal trxNo, PROVIDER provider) {
		super(trxNo, provider == PROVIDER.UPT ? (short) 3552 : (short) 2032);
		this.provider = provider;
		this.setReconciliationType(ReconciliationType.FOREIGN_CURRENCY_TRANSFER_PAYMENT);
	}
	
	public ForeignCurrencyTransferPayment(BigDecimal trxNo, PROVIDER provider, boolean isRefund) {
		this(trxNo, provider);
		this.setRefund(isRefund);
		if(isRefund) {
			this.setReconciliationType(ReconciliationType.REFUND_PAYMENT);
		}
	}

	/**
	 * @return {@link #provider}
	 */
	public PROVIDER getProvider() {
		return provider;
	}

	/**
	 * @param provider {@link #provider}
	 */
	public void setProvider(PROVIDER provider) {
		this.provider = provider;
	}

	/**
	 * @return {@link #expenseRefunded}
	 */
	@Override
	public boolean isExpenseRefunded() {
		return super.isExpenseRefunded();
	}

	/**
	 * @param expenseRefunded {@link #expenseRefunded}
	 */
	@Override
	public void setExpenseRefunded(boolean expenseRefunded) {
		super.setExpenseRefunded(expenseRefunded);
		if(expenseRefunded) {
			this.setReconciliationType(ReconciliationType.REFUND_PAYMENT_WITH_EXPENSE);
			this.setCommissionCategory(null);
		} else {
			this.setReconciliationType(ReconciliationType.REFUND_PAYMENT);
		}
	}
	
	@Override
	public String toString() {
		return String.format("%s(trxNo=%s, code=%s, provider=%s, refund=%s, expenseRefunded=%s)",
			ForeignCurrencyTransferPayment.class.getSimpleName(), this.trxNo().toString(), this.trxCode().toString(),
			this.provider.toString(), this.isRefund(), this.isExpenseRefunded());
	}
}
