package tr.com.aktifbank.bnspr.adc.clks.definition.model.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import com.graymound.util.GMMap;

abstract class BaseTransactionDefinition {
	
	protected final String[] code;
	protected final String reconciliationCode;
	
	public BaseTransactionDefinition(String[] code, String reconciliationType) {
		this.code = code;
		this.reconciliationCode = reconciliationType;
	}
	
	public Map<?,?> formatReconciliationMap(GMMap records, String listName) {
		
		GMMap oMap = new GMMap();
		
		for(int i = 0; i < records.getSize(listName); i++) {
			
			GMMap accountingMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "TUTAR")).put(
				"PARA_BIRIMI", records.getString(listName, i, "PARA_BIRIMI")).put("MASRAF", "H");
			
			GMMap commisionMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "KOMISYON_TUTAR")).put(
				"KOMISYON_PARA_BIRIMI", records.getString(listName, i, "KOMISYON_PARA_BIRIMI"));
			
			GMMap clientMap = new GMMap().put("SUBE_ID", records.getString(listName, i, "SUBE_ID")).put(
				"PERSONEL_SICIL", records.getString(listName, i, "PERSONEL_SICIL")).put("PERSONEL_ADI",
				records.getString(listName, i, "PERSONEL_SICIL"));

			oMap.put(listName, i, "ISLEM_TIPI", reconciliationCode);
			oMap.put(listName, i, "ISLEM_NO", records.getBigDecimal(listName, i, "ISLEM_NO"));
			oMap.put(listName, i, "DURUM", records.getString(listName, i, "DURUM"));
			oMap.put(listName, i, "MUHASEBE", new ArrayList<GMMap>(Arrays.asList(accountingMap)));
			oMap.put(listName, i, "KOMISYON", new ArrayList<GMMap>(Arrays.asList(commisionMap)));
			oMap.put(listName, i, "MUSTERI_DETAY", new ArrayList<GMMap>(Arrays.asList(clientMap)));
		}
		
		return oMap;
	}

	public String[] getCode() {
		return code;
	}

	public String getReconcilitionCode() {
		return reconciliationCode;
	}
}
