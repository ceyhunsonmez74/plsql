package tr.com.aktifbank.bnspr.adc.dal;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.AdcBlackWhiteList;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AdcBlackWhiteListDAL {

	
	
	@SuppressWarnings("unchecked")
	public static List<AdcBlackWhiteList> getList(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(AdcBlackWhiteList.class);
			if(!StringUtils.isEmpty(iMap.getString("BLACK_OR_WHITE")))
				criteria.add(Restrictions.eq("blackOrWhite", 	iMap.getString("BLACK_OR_WHITE")));
			
			if(!StringUtils.isEmpty(iMap.getString("LIST_TYPE")))
				criteria.add(Restrictions.eq("listType", 		iMap.getString("LIST_TYPE")));
			
			if(!StringUtils.isEmpty(iMap.getString("START_DATE")) && !StringUtils.isEmpty(iMap.getString("END_DATE")))
				criteria.add(Restrictions.between("recDate", 	iMap.getDate("START_DATE"), iMap.getDate("END_DATE")));
			
			if(!StringUtils.isEmpty(iMap.getString("REC_OWNER")))
				criteria.add(Restrictions.eq("recOwner", 	iMap.getString("REC_OWNER")));
			
			List<AdcBlackWhiteList> adcBlackWhiteList = criteria.list();
			return adcBlackWhiteList;
		}catch (Exception e){
			throw new GMRuntimeException(0,e);
		}
	}

	@SuppressWarnings("unchecked")
	public static AdcBlackWhiteList get(String oid , String blackOrWhite, String listType, String value) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(AdcBlackWhiteList.class);
			
			if(!StringUtils.isEmpty(oid)){
				return (AdcBlackWhiteList) session.get(AdcBlackWhiteList.class, oid);
			}
			criteria.add(Restrictions.eq("blackOrWhite", 	blackOrWhite));
			criteria.add(Restrictions.eq("listType", 		listType));
			criteria.add(Restrictions.eq("value", 			value));
			
			AdcBlackWhiteList adcBlackWhiteList = (AdcBlackWhiteList)criteria.uniqueResult();
			return adcBlackWhiteList;
		}catch (Exception e){
			throw new GMRuntimeException(0,e);
		}
	}

	@SuppressWarnings("unchecked")
	public static void save(AdcBlackWhiteList adcBlackWhiteList) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			session.saveOrUpdate(adcBlackWhiteList);
			session.flush();
		}catch (Exception e){
			throw new GMRuntimeException(0,e);
		}
	}
	
	
	public static void delete(AdcBlackWhiteList adcBlackWhiteList){
		Session session = DAOSession.getSession("BNSPRDal");
		session.delete(adcBlackWhiteList);
		session.flush();
	}
	


}
