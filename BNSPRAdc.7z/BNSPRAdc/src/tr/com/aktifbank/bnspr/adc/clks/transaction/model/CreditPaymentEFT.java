package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

/**
 * PTT kanali kredi odemesi islem sinifi
 */
public class CreditPaymentEFT extends CreditPayment {
	
	private static final long serialVersionUID = -4223447449263379422L;

	public CreditPaymentEFT(BigDecimal trxNo) {
		super(trxNo, (short) 2315);
		this.setReconciliationType(ReconciliationType.CREDIT_PAYMENT);
	}
}
