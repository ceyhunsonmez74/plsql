package tr.com.aktifbank.bnspr.adc.clks.consumerloan.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.core.model.Branch;
import tr.com.aktifbank.bnspr.adc.clks.core.model.Teller;
import tr.com.aktifbank.bnspr.adc.clks.customer.model.PersonalCustomer;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

public class Application implements Serializable {

	private static final long serialVersionUID = -5369312718105647832L;
	private static final String channelCode = "7";

	/**
	 * Basvuru Durumu
	 * 
	 * <li>{@link #BASVURU}</li>
	 * <li>{@link #IPTAL}</li>
	 * <li>{@link #RED}</li>
	 * <li>{@link #DOGRULAMA}</li>
	 * <li>{@link #FRAUD}</li>
	 * <li>{@link #ISTIHBARAT}</li>
	 * <li>{@link #NBSM}</li>
	 * <li>{@link #ONAY1}</li>
	 * <li>{@link #ONAY2}</li>
	 * <li>{@link #ONAY3}</li>
	 * <li>{@link #ONAY4}</li>
	 * <li>{@link #SOZLESME}</li>
	 * <li>{@link #KUL}</li>
	 * <li>{@link #KULONAY}</li>
	 * <li>{@link #KANALIADE}</li>
	 * <li>{@link #BELGE}</li>
	 * <li>{@link #EVRAKSIZ}</li>
	 * <li>{@link #CEPTE}</li>
	 * <li>{@link #KAPANDI}</li>
	 * 
	 */
	public enum STATUS {
		BASVURU, IPTAL, RED, DOGRULAMA, FRAUD, ISTIHBARAT, NBSM, ONAY1, ONAY2, ONAY3, ONAY4, SOZLESME, KUL, KULONAY,
		KANALIADE, BELGE, EVRAKSIZ, CEPTE, KAPANDI;
		
		public static STATUS getEnum(String status) {
			for(STATUS v : values())
				if(v.toString().equalsIgnoreCase(status))
					return v;
			return null;
		}
	}
	
	private BigDecimal trxNo;
	
	/**
	 * Basvuru Numarasi
	 */
	private BigDecimal applicationNo;
	
	/**
	 * TC Kimlik Numarasi
	 */
	private String nationalIdentificationNumber;
	
	/**
	 * Musteri
	 */
	private PersonalCustomer customer;
	
	/**
	 * Kredi Tutari
	 */
	private BigDecimal amount;
	
	/**
	 * Kredi Vadesi
	 */
	private int term;
	
	/**
	 * Para Birimi
	 */
	private CurrencyType currency;
	
	/**
	 * Kredi Kampanyasi
	 */
	private Campaign campaign;
	
	/**
	 * Kredi Durumu
	 */
	private STATUS status;
	
	/**
	 * Kurumu
	 */
	private Institution institution;
	
	/**
	 * Izinli Pazarlama Kabul
	 */
	private boolean ipaz = false;
	
	/**
	 * KVKK Kabul
	 */
	private boolean kvkk = false;
	
	/**
	 * CRS'e Tabi Musteri
	 */
	private boolean crs = false;
	
	/**
	 * Cep Telefonu
	 */
	private String mobilePhone;
	
	/**
	 * Komisyon Kategorisi
	 */
	private CommissionCategory commissionCategory;
	
	/**
	 * Mutabakat Tipi
	 */
	private ReconciliationType reconciliationType;
	
	/**
	 * Komisyon Tutari
	 */
	private BigDecimal commissionAmount;
	
	/**
	 * Komisyon Parabirimi
	 */
	private CurrencyType commissionCurrency;
	
	/**
	 * Upsell Limit
	 */
	private BigDecimal upsellLimit;
	
	/**
	 * Maas odemeleri
	 */
	private List<PensionPayment> salaries;
	
	/**
	 * Basvuru maas odemesi
	 */
	private PensionPayment selectedSalary;
	
	/**
	 * Basvuru surecinin RED ile sonuclanmasi durumunda komisyon nitelik bilgisi, diger sureclerde 
	 * deger anlam ifade etmez.
	 */
	private boolean qualifiedCommission;
	
	/**
	 * Borc Transferi basvurusu ise ilgili banka kodu
	 */
	private String bankCode;
	
	/**
	 * Borc Transferi basvurusu ise ilgili banka sube kodu
	 */
	private String bankBranchCode;
	
	/**
	 * Basvurunun yapildigi sube
	 */
	private Branch branch;
	
	/**
	 * Basvuruyu yapan gise personeli
	 */
	private Teller teller;
	
	/**
	 * Belge islem numarasi
	 */
	private BigDecimal trxNoDocumentProcessing;
	
	/**
	 * Son barkod numarasi
	 */
	private String barcode;
	
	/**
	 * Kullandirimda sorun var mi?
	 */
	private boolean contractualRequestapproved;
	
	public Application(BigDecimal applicationNo, String nationalIdentificationNumber, BigDecimal amount, int term,
		Campaign campaign) {
		
		this.applicationNo = applicationNo;
		this.nationalIdentificationNumber = nationalIdentificationNumber;
		this.amount = amount;
		this.term = term;
		this.campaign = campaign;
		this.currency = CurrencyType.TRY;
		this.status = STATUS.BASVURU;
	}
	
	/**
	 * @return {@link #applicationNo}
	 */
	public BigDecimal getApplicationNo() {
		return applicationNo;
	}
	
	/**
	 * @param applicationNo - {@link #applicationNo}
	 */
	public void setApplicationNo(BigDecimal applicationNo) {
		this.applicationNo = applicationNo;
	}
	
	/**
	 * @return {@link #nationalIdentificationNumber}
	 */
	public String getNationalIdentificationNumber() {
		return nationalIdentificationNumber;
	}
	
	/**
	 * @param nationalIdentificationNumber - {@link #nationalIdentificationNumber}
	 */
	public void setNationalIdentificationNumber(String nationalIdentificationNumber) {
		this.nationalIdentificationNumber = nationalIdentificationNumber;
	}
	
	/**
	 * @return {@link #customer}
	 */
	public PersonalCustomer getCustomer() {
		return customer;
	}
	
	/**
	 * @param customer - {@link #customer}
	 */
	public void setCustomer(PersonalCustomer customer) {
		this.customer = customer;
	}
	
	/**
	 * @return {@link #amount}
	 */
	public BigDecimal getAmount() {
		return amount;
	}
	
	/**
	 * @param amount - {@link #amount}
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return {@link #term}
	 */
	public int getTerm() {
		return term;
	}
	
	/**
	 * @param term - {@link #term}
	 */
	public void setTerm(int term) {
		this.term = term;
	}

	public CurrencyType getCurrency() {
		return currency;
	}

	public void setCurrency(CurrencyType currency) {
		this.currency = currency;
	}

	public static String getChannelcode() {
		return channelCode;
	}

	public Campaign getCampaign() {
		return campaign;
	}

	public void setCampaign(Campaign campaign) {
		this.campaign = campaign;
	}
	
	public STATUS getStatus() {
		return status;
	}
	
	public void setStatus(STATUS status) {
		this.status = status;
	}

	public Institution getInstitution() {
		return institution;
	}

	public void setInstitution(Institution institution) {
		this.institution = institution;
	}

	public boolean isIpaz() {
		return ipaz;
	}

	public void setIpaz(boolean ipaz) {
		this.ipaz = ipaz;
	}

	public boolean isKvkk() {
		return kvkk;
	}

	public void setKvkk(boolean kvkk) {
		this.kvkk = kvkk;
	}

	public boolean isCrs() {
		return crs;
	}

	public void setCrs(boolean crs) {
		this.crs = crs;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public BigDecimal getTrxNo() {
		return trxNo;
	}

	public void setTrxNo(BigDecimal trxNo) {
		this.trxNo = trxNo;
	}
	
	public BigDecimal getUpsellLimit() {
		return upsellLimit;
	}

	public void setUpsellLimit(BigDecimal upsellLimit) {
		this.upsellLimit = upsellLimit;
	}

	/**
	 * @return {@link #commissionCategory}
	 */
	public CommissionCategory getCommissionCategory() {
		return commissionCategory;
	}

	/**
	 * @param commissionCategory - {@link #commissionCategory}
	 */
	public void setCommissionCategory(CommissionCategory commissionCategory) {
		this.commissionCategory = commissionCategory;
	}

	/**
	 * @return {@link #reconciliationType}
	 */
	public ReconciliationType getReconciliationType() {
		return reconciliationType;
	}

	/**
	 * @param reconciliationType - {@link #reconciliationType}
	 */
	public void setReconciliationType(ReconciliationType reconciliationType) {
		this.reconciliationType = reconciliationType;
	}

	/**
	 * @return {@link #commissionAmount}
	 */
	public BigDecimal getCommissionAmount() {
		return commissionAmount;
	}

	/**
	 * @param commissionAmount - {@link #commissionAmount}
	 */
	public void setCommissionAmount(BigDecimal commissionAmount) {
		this.commissionAmount = commissionAmount;
	}

	/**
	 * @return {@link #commissionCurrency}
	 */
	public CurrencyType getCommissionCurrency() {
		return commissionCurrency;
	}

	/**
	 * @param commissionCurrency - {@link #commissionCurrency}
	 */
	public void setCommissionCurrency(CurrencyType commissionCurrency) {
		this.commissionCurrency = commissionCurrency;
	}

	/**
	 * @param commissionAmount - {@link #commissionAmount}
	 * @param commissionCurrency - {@link #commissionCurrency}
	 */
	public void setCommission(BigDecimal commissionAmount, CurrencyType commissionCurrency) {
		this.commissionAmount = commissionAmount;
		this.commissionCurrency = commissionCurrency;
	}
	
	/**
	 * @param commissionRecord
	 */
	public void setCommission(Record commissionRecord) {
		this.commissionAmount = commissionRecord.getAmount();
		this.commissionCurrency = commissionRecord.getCurrency();
	}

	/**
	 * @return {@link #qualifiedCommission}
	 */
	public boolean isQualifiedCommission() {
		return qualifiedCommission;
	}

	/**
	 * @param qualifiedCommission {@link #qualifiedCommission}
	 */
	public void setQualifiedCommission(boolean qualifiedCommission) {
		this.qualifiedCommission = qualifiedCommission;
	}

	/**
	 * @return {@link #salaries}
	 */
	public List<PensionPayment> getSalaries() {
		return salaries;
	}

	/**
	 * @param salaries {@link #salaries}
	 */
	public void setSalaries(List<PensionPayment> salaries) {
		this.salaries = salaries;
	}
	
	/**
	 * @return {@link #selectedSalary}
	 */
	public PensionPayment getSelectedSalary() {
		return selectedSalary;
	}

	/**
	 * @param selectedSalary {@link #selectedSalary}
	 */
	public void setSelectedSalary(PensionPayment selectedSalary) {
		this.selectedSalary = selectedSalary;
	}

	/**
	 * @return {@link #bankCode}
	 */
	public String getBankCode() {
		return bankCode;
	}

	/**
	 * @param bankCode {@link #bankCode}
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	/**
	 * @return {@link #bankBranchCode}
	 */
	public String getBankBranchCode() {
		return bankBranchCode;
	}

	/**
	 * @param bankBranchCode {@link #bankBranchCode}
	 */
	public void setBankBranchCode(String bankBranchCode) {
		this.bankBranchCode = bankBranchCode;
	}

	/**
	 * @return the branch
	 */
	public Branch getBranch() {
		return branch;
	}

	/**
	 * @param branch the branch to set
	 */
	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	/**
	 * @return the teller
	 */
	public Teller getTeller() {
		return teller;
	}

	/**
	 * @param teller the teller to set
	 */
	public void setTeller(Teller teller) {
		this.teller = teller;
	}

	/**
	 * @return {@link #trxNoDocumentProcessing}
	 */
	public BigDecimal getTrxNoDocumentProcessing() {
		return trxNoDocumentProcessing;
	}

	/**
	 * @param trxNoDocumentProcessing {@link #trxNoDocumentProcessing}
	 */
	public void setTrxNoDocumentProcessing(BigDecimal trxNoDocumentProcessing) {
		this.trxNoDocumentProcessing = trxNoDocumentProcessing;
	}

	/**
	 * @return {@link #barcode}
	 */
	public String getBarcode() {
		return barcode;
	}

	/**
	 * @param barcode {@link #barcode}
	 */
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}

	/**
	 * @return the approved
	 */
	public boolean isContractualRequestapprovedApproved() {
		return contractualRequestapproved;
	}

	/**
	 * @param approved the approved to set
	 */
	public void setContractualRequestapprovedApproved(boolean contractualRequestapproved) {
		this.contractualRequestapproved = contractualRequestapproved;
	}

	@Override
	public String toString() {
		return String
			.format("%s(basvuruNo=%s, durumKodu=%s, tcKimlikNo=%s, campaign=%s)", Application.class.getSimpleName(),
				this.getApplicationNo().toString(), this.getStatus() != null ? this.getStatus().toString() : "null",
				this.getNationalIdentificationNumber(), campaign != null ? campaign.toString() : null);
	}
}
