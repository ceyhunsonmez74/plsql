package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transaction;

/**
 * PTT kanali nakit cekme islem sinifi
 * 
 * @see Transaction
 */
public class CashWithdrawal extends Transaction {

	private static final long serialVersionUID = 6142539681115645426L;

	public CashWithdrawal(BigDecimal trxNo) {
		super(trxNo, (short) 2051);
		this.setReconciliationType(ReconciliationType.CASH_WITHDRAWAL);
	}
	
	@Override
	public void setCurrency(CurrencyType currency) {
		super.setCurrency(currency);
		if(currency == CurrencyType.TRY) {
			this.setCommissionCategory(CommissionCategory.CASH_WITHDRAWAL_LC);
		} else {
			this.setCommissionCategory(CommissionCategory.CASH_WITHDRAWAL_FC);
		}
	}
}
