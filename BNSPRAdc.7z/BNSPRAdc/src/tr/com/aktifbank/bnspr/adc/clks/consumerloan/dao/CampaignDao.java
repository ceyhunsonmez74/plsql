package tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Campaign;
import tr.com.aktifbank.bnspr.adc.dao.BaseDao;

public interface CampaignDao<T extends Campaign> extends BaseDao<T> {

}
