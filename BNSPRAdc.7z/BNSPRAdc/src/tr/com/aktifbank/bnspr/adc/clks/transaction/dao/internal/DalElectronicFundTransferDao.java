package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.ElectronicFundTransfer;
import tr.com.calikbank.bnspr.dao.ClksPftTx;

import com.graymound.server.dao.DAOSession;

public class DalElectronicFundTransferDao extends DalTransactionDao<ElectronicFundTransfer> implements
	TransactionDao<ElectronicFundTransfer> {

	public DalElectronicFundTransferDao() {
		super(ElectronicFundTransfer.class);
	}

	@Override
	public ElectronicFundTransfer get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		ClksPftTx clksPftTx = (ClksPftTx) session.get(ClksPftTx.class, trxNo);
		ElectronicFundTransfer transfer = new ElectronicFundTransfer(clksPftTx.getTxNo());
		transfer.setAmount(clksPftTx.getTutar());
		transfer.setCurrency(CurrencyType.TRY);
		transfer.setExpenseAmount(clksPftTx.getMasraf());
		transfer.setExpenseCurrency(CurrencyType.TRY);
		transfer.setClientTrxNo(clksPftTx.getPttIslemNo());
		transfer.setMessage(ElectronicFundTransfer.MESSAGE.getEnum(clksPftTx.getMesajKodu()));
		transfer.setFromPCH(BigDecimal.valueOf(10).equals(clksPftTx.getIslem()) ? false : true);
		transfer.setFromAccount(transfer.isFromPCH() ? clksPftTx.getPostaCekHesapNo() : clksPftTx.getGonderenHesapNo());
		transfer.setToAccount(clksPftTx.getAliciHesapNo() != null ? new BigDecimal(clksPftTx.getAliciHesapNo()) : null);
		transfer.setToBankCode(clksPftTx.getAlanBankaKodu());
		transfer.setToBranchCode(clksPftTx.getAlanSubeKodu());
		transfer.setToIBAN(clksPftTx.getAliciIban());
		transfer.setReconciliationType(transfer.isFromPCH() ? ReconciliationType.ELECTRONIC_FUND_TRANSFER_FROM_PCH
			: ReconciliationType.ELECTRONIC_FUND_TRANSFER);
		return transfer;
	}

	@Override
	public List<ElectronicFundTransfer> filter(Map<String, Object> criteria) {

		List<ElectronicFundTransfer> transferList = new ArrayList<ElectronicFundTransfer>();

		Session session = DAOSession.getSession("BNSPRDal");

		@SuppressWarnings("unchecked")
		List<ClksPftTx> list = session.createCriteria(ClksPftTx.class).add(
			Restrictions.allEq(criteria)).list();

		for(ClksPftTx clksPftTx : list) {
			ElectronicFundTransfer transfer = new ElectronicFundTransfer(clksPftTx.getTxNo());
			transfer.setAmount(clksPftTx.getTutar());
			transfer.setCurrency(CurrencyType.TRY);
			transfer.setExpenseAmount(clksPftTx.getMasraf());
			transfer.setExpenseCurrency(CurrencyType.TRY);
			transfer.setClientTrxNo(clksPftTx.getPttIslemNo());
			transfer.setMessage(ElectronicFundTransfer.MESSAGE.getEnum(clksPftTx.getMesajKodu()));
			transfer.setFromPCH(BigDecimal.valueOf(10).equals(clksPftTx.getIslem()) ? false : true);
			transfer.setFromAccount(transfer.isFromPCH() ? clksPftTx.getPostaCekHesapNo() : clksPftTx
				.getGonderenHesapNo());
			transfer.setToAccount(new BigDecimal(clksPftTx.getAliciHesapNo()));
			transfer.setToBankCode(clksPftTx.getAlanBankaKodu());
			transfer.setToBranchCode(clksPftTx.getAlanSubeKodu());
			transfer.setToIBAN(clksPftTx.getAliciIban());
			transfer.setReconciliationType(transfer.isFromPCH() ? ReconciliationType.ELECTRONIC_FUND_TRANSFER_FROM_PCH
				: ReconciliationType.ELECTRONIC_FUND_TRANSFER);
			transferList.add(transfer);
		}
		return transferList;
	}

	@Override
	public List<ElectronicFundTransfer> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(ElectronicFundTransfer type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(ElectronicFundTransfer type) {
		// TODO Auto-generated method stub
		
	}
}
