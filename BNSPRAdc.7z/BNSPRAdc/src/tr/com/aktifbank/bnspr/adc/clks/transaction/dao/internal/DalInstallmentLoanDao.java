package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.InstallmentLoan;
import tr.com.calikbank.bnspr.dao.BirGeriOdemeTx;

import com.graymound.server.dao.DAOSession;

public class DalInstallmentLoanDao extends DalTransactionDao<InstallmentLoan> implements TransactionDao<InstallmentLoan> {

	public DalInstallmentLoanDao() {
		super(InstallmentLoan.class);
	}

	@Override
	public InstallmentLoan get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		BirGeriOdemeTx birGeriOdemeTx = (BirGeriOdemeTx) session.get(BirGeriOdemeTx.class, trxNo);
		InstallmentLoan installmentLoan = new InstallmentLoan(birGeriOdemeTx.getTxNo());
		installmentLoan.setApplicationNo(birGeriOdemeTx.getBasvuruNo());
		installmentLoan.setAmount(birGeriOdemeTx.getTahsilatTutar());
		installmentLoan.setCurrency(CurrencyType.TRY);
		installmentLoan.setEarlyPayOff("3".equals(birGeriOdemeTx.getBirGeriOdmTip()) ? true : false); 
		installmentLoan.setInstallmentNumber(birGeriOdemeTx.getTaksitNo());
		return installmentLoan;
	}

	@Override
	public List<InstallmentLoan> filter(Map<String, Object> criteria) {
		
		List<InstallmentLoan> installmentLoanList = new ArrayList<InstallmentLoan>();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<BirGeriOdemeTx> list = session.createCriteria(BirGeriOdemeTx.class).add(Restrictions.allEq(criteria))
			.list();

		for(BirGeriOdemeTx birGeriOdemeTx : list) {
			InstallmentLoan installmentLoan = get(birGeriOdemeTx.getTxNo());
			installmentLoanList.add(installmentLoan);
		}
		return installmentLoanList;
	}

	@Override
	public List<InstallmentLoan> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(InstallmentLoan type) {
		// TODO Auto-generated method stub
	}

	@Override
	public void saveOrUpdate(InstallmentLoan type) {
		// TODO Auto-generated method stub
	}
}
