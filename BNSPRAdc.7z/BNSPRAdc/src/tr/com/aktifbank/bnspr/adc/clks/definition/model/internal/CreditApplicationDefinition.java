package tr.com.aktifbank.bnspr.adc.clks.definition.model.internal;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionContext;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal.GMCacheCommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.internal.GMCreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.internal.DalCreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application.STATUS;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal.CreditApplicationProcessImpl;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.TransactionDefinition;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruDurumSorgu;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

/**
 * TODO Relocate GM andData Access dependencies to outer levels
 */
class CreditApplicationDefinition extends BaseTransactionDefinition implements TransactionDefinition {
	
	private static Logger logger = Logger.getLogger(CreditApplicationDefinition.class);
	
	private static final String AKSIYON_KARAR_KOD_KOMISYON_MUTABAKAT_NEDENIYLE_RED = "47";
	
	public CreditApplicationDefinition() {
		super(new String[]{"3171"}, "9");
	}
	
	/**
	 * Dogrulamaya dusmus ve sorgulanmamasi/sorgulanmis ancak ilerlememis basvurular icin red komisyonu atilir. 
	 * EVRAKSIZ ve CEPTE olmadigi surece basvurunun durumu RED degil ise RED'e cekilir.
	 * 
	 * @param date		Mutabakat tarihi
	 */
	private void additionalCommissionAllocation(Date date) {

		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<ClksBirBasvuruDurumSorgu> sorguList = session.createCriteria(ClksBirBasvuruDurumSorgu.class).add(
			Restrictions.eq("tarih", date)).list();
		
		for(ClksBirBasvuruDurumSorgu sorgu : sorguList) {

			logger.info(String.format(
				"additionalCommissionAllocation(%s) => ClksBirBasvuruDurumSorgu(basvuruNo=%s)", date.toString(),
				sorgu.getBasvuruNo()));
			
			if(sorgu.getDurumKodu().equals(STATUS.DOGRULAMA.toString())) {

				CreditApplicationDao<Application> applicationDao = new DalCreditApplicationDao();
				Application application = applicationDao.get(sorgu.getBasvuruNo());
				
				logger.info(String.format("additionalCommissionAllocation(%s) => %s, Application.trxNo=%s", date
					.toString(), application.toString(), application.getTrxNo() != null ? application.getTrxNo()
					.toString() : "null"));
				
				if(application.getCommissionCategory() != null) {
					logger.info(String.format(
						"additionalCommissionAllocation(%s) => %s - Commission record allocated, skipping ...", date
							.toString(), application.toString()));
					continue;
				}
				
				if(application.getCampaign().isPublicCredit()) {
					
					logger.info(String.format(
						"additionalCommissionAllocation(%s) => %s - 3. Sahis Kredi, skipping ...", date.toString(),
						application.toString()));
					
					if(application.getStatus() != STATUS.RED) {
						
						switch(application.getCampaign().getRelation()) {
							case RETIREE:
								application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_KABUL_EMEKLI);
								break;
							case PERSONNEL:
								application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_KABUL_PERSONEL);
								break;
							case OTHER:
								application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_KABUL_DIGER);
								break;
							default:
								break;
						}
						
						CommissionContext commissionContext = null;
						Record record = null;
						
						try {
							commissionContext = new CommissionContext(application.getCommissionCategory()
								.getStrategyClass().getDeclaredConstructor(List.class).newInstance(
									new GMCacheCommissionDao().getByCommissionCategory(application.getCommissionCategory())));
	
							record = commissionContext.calculate(new Record(application.getAmount(), application
								.getCurrency()));
							
						} catch(Exception e) {
							logger.error(String.format(
								"additionalCommissionAllocation(commissionCategory, amount, currency) => (%s,%s,%s)",
								application.getCommissionCategory().toString(), application.getAmount().toString(), 
								application.getCurrency().toString()), e);
						}
					
						if(record != null) {
							application.setCommission(record);
							applicationDao.saveCommission(application);
						}
					}
					
					continue;
				}
				
				
				if(EnumSet.of(STATUS.EVRAKSIZ, STATUS.CEPTE, STATUS.IPTAL).contains(application.getStatus())) {
					// Do nothing
				} else if(application.getStatus() != STATUS.RED) {
					try {
						DALUtil.callOracleFunction("{? = call pkg_ptt_kredi.ptt_kredi_basvuru_reddet(?,?,?,?)}",
							BnsprType.STRING, BnsprType.NUMBER, application.getTrxNo(), BnsprType.NUMBER, application
								.getApplicationNo(), BnsprType.STRING, application.getStatus().toString(),
							BnsprType.STRING, AKSIYON_KARAR_KOD_KOMISYON_MUTABAKAT_NEDENIYLE_RED);
						application.setStatus(Application.STATUS.RED);
					} catch(SQLException e) {
						logger.error(String.format("CreditApplicationDefinition.commissionAllocation (%s) err:",
							application.getApplicationNo()), e);
					}
				}

				CreditApplicationProcess<Application> process = new CreditApplicationProcessImpl<Application>(
					applicationDao, new GMCreditApplicationApi());
				process.applicationAfterIntermediateStatus(application);
			}
		}
	}

	@Override
	public Map<?, ?> getReconciliationRecords(Date date, String listName) throws SQLException {
		
		additionalCommissionAllocation(date);
		
		GMMap oMap = new GMMap(), records = DALUtil.callOracleRefCursorFunction(
			"{? = call pkg_trn2052.get_credit_application_records(?)}", listName, BnsprType.DATE, date);
		
		for(int i = 0; i < records.getSize(listName); i++) {
			
			GMMap commisionMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "KOMISYON_TUTAR")).put(
				"PARA_BIRIMI", records.getString(listName, i, "KOMISYON_PARA_BIRIMI"));
			
			GMMap clientMap = new GMMap().put("SUBE_ID", records.getString(listName, i, "SUBE_ID")).put(
				"PERSONEL_SICIL", records.getString(listName, i, "PERSONEL_SICIL")).put("PERSONEL_ADI",
				records.getString(listName, i, "PERSONEL_SICIL"));
			
			GMMap detailsMap = new GMMap().put("BASVURU_NO", records.getString(listName, i, "BASVURU_NO")).put("DURUM",
				records.getString(listName, i, "KREDI_DURUM")).put("TUTAR",
				records.getString(listName, i, "KREDI_TUTAR")).put("NITELIK",
				records.getString(listName, i, "KREDI_NITELIK"));
			detailsMap.put("KAMPANYA", new ArrayList<GMMap>(Arrays.asList(new GMMap().put("KOD",
				records.getString(listName, i, "KAMP_KOD")).put("TIP", records.getString(listName, i, "KAMP_TIP")))));

			oMap.put(listName, i, "ISLEM_TIPI", reconciliationCode);
			oMap.put(listName, i, "ISLEM_NO", records.getBigDecimal(listName, i, "ISLEM_NO"));
			oMap.put(listName, i, "DURUM", records.getString(listName, i, "DURUM"));
			oMap.put(listName, i, "KOMISYON", new ArrayList<GMMap>(Arrays.asList(commisionMap)));
			oMap.put(listName, i, "MUSTERI_DETAY", new ArrayList<GMMap>(Arrays.asList(clientMap)));
			oMap.put(listName, i, "KREDI_BASVURU_DETAY", new ArrayList<GMMap>(Arrays.asList(detailsMap)));
		}
		
		return oMap;
		
	}

	@Override
	public Map<?, ?> getRecords(Date date, String listName) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<?, ?> getConfirmData(BigDecimal trxNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String reconciliationCode() {
		return reconciliationCode;
	}
}
