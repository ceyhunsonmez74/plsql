package tr.com.aktifbank.bnspr.adc.clks.customer.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Gercek musteri sinifi
 */
public class PersonalCustomer extends Customer {
	
	private static final long serialVersionUID = 1304799817659412616L;

	/**
	 * TC Kimlik Numarasi
	 */
	private String nationalIdentificationNumber;
	
	/**
	 * Dogum Tarihi
	 */
	private Date birthDate;
	
	/**
	 * Adi
	 */
	private String firstName;
	
	/**
	 * Ikinci Adi
	 */
	private String secondaryName;
	
	/**
	 * Soyadi
	 */
	private String lastName;
	
	public PersonalCustomer(BigDecimal customerNo, String nationalIdentificationNumber) {
		super(customerNo);
		this.nationalIdentificationNumber = nationalIdentificationNumber;
		this.setType(CustomerType.PERSONAL);
	}

	/**
	 * @return {@link #nationalIdentificationNumber}
	 */
	public String getNationalIdentificationNumber() {
		return nationalIdentificationNumber;
	}

	/**
	 * @param nationalIdentificationNumber {@link #nationalIdentificationNumber}
	 */
	public void setNationalIdentificationNumber(String nationalIdentificationNumber) {
		this.nationalIdentificationNumber = nationalIdentificationNumber;
	}

	/**
	 * @return {@link #birthDate}
	 */
	public Date getBirthDate() {
		return birthDate;
	}

	/**
	 * @param birthDate {@link #birthDate}
	 */
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * @return {@link #firstName}
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName {@link #firstName}
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return {@link #secondaryName}
	 */
	public String getSecondaryName() {
		return secondaryName;
	}

	/**
	 * @param secondaryName {@link #secondaryName}
	 */
	public void setSecondaryName(String secondaryName) {
		this.secondaryName = secondaryName;
	}

	/**
	 * @return {@link #lastName}
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName {@link #lastName}
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return String.format("%s %s %s", firstName, secondaryName == null ? "" : secondaryName, lastName).replace("  ",
			" ");
	}
}
