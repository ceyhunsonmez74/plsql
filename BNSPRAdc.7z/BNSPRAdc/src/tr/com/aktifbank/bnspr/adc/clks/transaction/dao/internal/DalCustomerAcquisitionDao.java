package tr.com.aktifbank.bnspr.adc.clks.transaction.dao.internal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.adc.clks.transaction.dao.TransactionDao;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.CustomerAcquisition;
import tr.com.aktifbank.bnspr.dao.ClksBonoTalepTx;

import com.graymound.server.dao.DAOSession;

public class DalCustomerAcquisitionDao extends DalTransactionDao<CustomerAcquisition> implements TransactionDao<CustomerAcquisition> {

	public DalCustomerAcquisitionDao() {
		super(CustomerAcquisition.class);
	}

	@Override
	public CustomerAcquisition get(Serializable trxNo) {
		Session session = DAOSession.getSession("BNSPRDal");
		ClksBonoTalepTx clksBonoTalepTx = (ClksBonoTalepTx) session.get(ClksBonoTalepTx.class, trxNo);
		CustomerAcquisition customerAcquisition = new CustomerAcquisition(clksBonoTalepTx.getTxNo());
		return customerAcquisition;
	}

	@Override
	public List<CustomerAcquisition> filter(Map<String, Object> criteria) {
		
		List<CustomerAcquisition> customerAcquisitionList = new ArrayList<CustomerAcquisition>();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		@SuppressWarnings("unchecked")
		List<ClksBonoTalepTx> list = session.createCriteria(ClksBonoTalepTx.class).add(Restrictions.allEq(criteria))
			.list();

		for(ClksBonoTalepTx clksBonoTalepTx : list) {
			CustomerAcquisition customerAcquisition = new CustomerAcquisition(clksBonoTalepTx.getTxNo());
			customerAcquisitionList.add(customerAcquisition);
		}
		return customerAcquisitionList;
	}

	@Override
	public List<CustomerAcquisition> all() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(CustomerAcquisition type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveOrUpdate(CustomerAcquisition type) {
		// TODO Auto-generated method stub
		
	}
}
