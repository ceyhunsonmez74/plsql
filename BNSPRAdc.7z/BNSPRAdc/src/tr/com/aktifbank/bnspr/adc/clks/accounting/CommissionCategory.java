package tr.com.aktifbank.bnspr.adc.clks.accounting;


/**
 * Komisyon kategorisi
 * <li>{@link #KREDI_TAHSILAT_EMEKLI}</li>
 * <li>{@link #KREDI_TAHSILAT_PERSONEL}</li>
 * <li>{@link #KREDI_TAHSILAT_DIGER}</li>
 * <li>{@link #KREDI_TAHSILAT_EMEKLI_DIGER_KANAL}</li>
 * <li>{@link #KREDI_KULLANDIRIM_EMEKLI}</li>
 * <li>{@link #KREDI_KULLANDIRIM_PERSONEL}</li>
 * <li>{@link #KREDI_KULLANDIRIM_DIGER}</li>
 * <li>{@link #KREDI_BASVURU_KABUL_EMEKLI}</li>
 * <li>{@link #KREDI_BASVURU_RED_EMEKLI}</li>
 * <li>{@link #KREDI_BASVURU_KABUL_PERSONEL}</li>
 * <li>{@link #KREDI_BASVURU_RED_PERSONEL}</li>
 * <li>{@link #KREDI_BASVURU_KABUL_DIGER}</li>
 * <li>{@link #KREDI_BASVURU_RED_DIGER}</li>
 * <li>{@link #KREDI_BASVURU_SMS_KREDI}</li>
 * <li>{@link #FOREIGN_CURRENCY_TRANSFER}</li>
 * <li>{@link #ELECTRONIC_FUND_TRANSFER}</li>
 * <li>{@link #PAYMENT}</li>
 * <li>{@link #FC_PAYMENT}</li>
 * <li>{@link #CASH_DEPOSIT}</li>
 * <li>{@link #ATM_CASH_DEPOSIT}</li>
 * <li>{@link #CASH_WITHDRAWAL}</li>
 * <li>{@link #CARD_PAYMENT}</li>
 * <li>{@link #ATM_CARD_PAYMENT}</li>
 * <li>{@link #CUSTOMER_ACQUISITION}</li>
 */
public enum CommissionCategory {
	
	/**
	 * Emekli kredisi tahsilat komisyonu
	 */
	KREDI_TAHSILAT_EMEKLI("TT", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Personel kredisi tahsilat komisyonu
	 */
	KREDI_TAHSILAT_PERSONEL("TTPER", CommissionFixOnAmountStrategy.class),

	/**
	 * Genel kredi tahsilat komisyonu
	 */
	KREDI_TAHSILAT_DIGER("TTG", CommissionFixOnAmountStrategy.class),
	
	/**
	 * PTT harici kanalli emekli kredisi tahsilat komisyonu
	 */
	KREDI_TAHSILAT_EMEKLI_DIGER_KANAL("TTPTTD", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Emekli kredisi kullandirim komisyonu
	 */
	KREDI_KULLANDIRIM_EMEKLI("KK", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Personel kredisi kullandirim komisyonu
	 */
	KREDI_KULLANDIRIM_PERSONEL("KKPER", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Genel kredi kullandirim komisyonu
	 */
	KREDI_KULLANDIRIM_DIGER("KKG", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Emekli kredisi nitelikli basvuru komisyonu
	 */
	KREDI_BASVURU_KABUL_EMEKLI("PKKAB", CommissionFixOnAmountStrategy.class),
	
	
	/**
	 * SMS Kredi �ubeden Emekli kredisi nitelikli basvuru komisyonu
	 */
	KREDI_BASVURU_KABUL_EMEKLI_SMS("PKKABSMS", CommissionFixOnAmountStrategy.class),
	
	
	/**
	 * Emekli kredisi nitelikli red komisyonu
	 */
	KREDI_BASVURU_RED_EMEKLI("PKRED", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Personel kredisi nitelikli basvuru komisyonu
	 */
	KREDI_BASVURU_KABUL_PERSONEL("PKKABPER", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Personel kredisi nitelikli red komisyonu
	 */
	KREDI_BASVURU_RED_PERSONEL("PKREDPER", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Genel kredi nitelikli basvuru komisyonu
	 */
	KREDI_BASVURU_KABUL_DIGER("PKKABG", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Genel kredi nitelikli red komisyonu
	 */
	KREDI_BASVURU_RED_DIGER("PKREDG", CommissionFixOnAmountStrategy.class),
	
	
	/**
	 * SMS Kredi komisyonu
	 */
	KREDI_BASVURU_SMS_KREDI("PKREDSMS", CommissionFixOnAmountStrategy.class),
	
	/**
	 * YP UPT/SWIFT gonderim komisyonu
	 */
	FOREIGN_CURRENCY_TRANSFER("FCT", CommissionRatio.class),
	
	/**
	 * EFT (TL UPT) diger gonderim
	 */
	ELECTRONIC_FUND_TRANSFER("EFT", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Ref. odeme, EFT odeme, UPT odeme, Iade odeme - TRY
	 */
	PAYMENT("GLNUPT", CommissionRatioOnAmountStrategy.class),
	
	/**
	 * Ref. odeme, EFT odeme, UPT odeme, Iade odeme - YP
	 */
	FC_PAYMENT("GLNUPT", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Nakit yatan
	 */
	CASH_DEPOSIT("NY", CommissionFixOnAmountStrategy.class),
	
	/**
	 * ATM'den Nakit yatan
	 */
	ATM_CASH_DEPOSIT("NY-ATM", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Nakit cekme - TL
	 */
	CASH_WITHDRAWAL_LC("NC", CommissionRatioOnAmountStrategy.class),
	
	/**
	 * Nakit cekme - YP
	 */
	CASH_WITHDRAWAL_FC("NC", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Giseden kart odemeleri
	 */
	CARD_PAYMENT("PASSO-GISE", CommissionFixOnAmountStrategy.class),

	/**
	 * ATM'den kart odemeleri
	 */
	ATM_CARD_PAYMENT("PASSO-ATM", CommissionFixOnAmountStrategy.class),
	
	/**
	 * Hesap acma
	 */
	CUSTOMER_ACQUISITION("HA", CommissionFixOnAmountStrategy.class);
	
	private String code;
	private Class<? extends CommissionStrategy> strategyClass;
	
	private CommissionCategory(String code, Class<? extends CommissionStrategy> strategyClass) {
		this.code = code;
		this.strategyClass = strategyClass;
	}
	
	@Override
	public String toString() {
		return code;
	}

	/**
	 * @return the strategyClass
	 */
	public Class<? extends CommissionStrategy> getStrategyClass() {
		return strategyClass;
	}

	/**
	 * @param strategyClass the strategyClass to set
	 */
	public void setStrategyClass(Class<? extends CommissionStrategy> strategyClass) {
		this.strategyClass = strategyClass;
	}

	public static CommissionCategory getEnum(String code) {
		for(CommissionCategory v : values())
			if(v.toString().equalsIgnoreCase(code))
				return v;
		throw new IllegalArgumentException();
	}
}
