package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

/**
 * YP UPT/Swift Odemeleri
 *
 */
public class ReferencePayment extends Payment {
	
	private static final long serialVersionUID = -7046662750125693614L;

	public ReferencePayment(BigDecimal trxNo) {
		super(trxNo, (short) 2032);
		this.setReconciliationType(ReconciliationType.REFERENCE_PAYMENT);
	}

	public ReferencePayment(BigDecimal trxNo, boolean isRefund) {
		this(trxNo);
		this.setRefund(isRefund);
		if(isRefund) {
			this.setReconciliationType(ReconciliationType.REFUND_PAYMENT);
		}
	}
	
	/**
	 * @param expenseRefunded {@link #expenseRefunded}
	 */
	@Override
	public void setExpenseRefunded(boolean expenseRefunded) {
		super.setExpenseRefunded(expenseRefunded);
		if(expenseRefunded) {
			this.setReconciliationType(ReconciliationType.REFUND_PAYMENT_WITH_EXPENSE);
			this.setCommissionCategory(null);
		} else {
			this.setReconciliationType(ReconciliationType.REFUND_PAYMENT);
		}
	}
	
	@Override
	public String toString() {
		return String.format("%s(trxNo=%s, code=%s, refund=%s, expenseRefunded=%s)",
			ReferencePayment.class.getSimpleName(), this.trxNo().toString(), this.trxCode().toString(),
			this.isRefund(), this.isExpenseRefunded());
	}
}
