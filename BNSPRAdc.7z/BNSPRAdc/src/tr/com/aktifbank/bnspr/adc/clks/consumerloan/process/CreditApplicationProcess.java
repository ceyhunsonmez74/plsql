package tr.com.aktifbank.bnspr.adc.clks.consumerloan.process;

import java.util.List;
import java.util.Map;

import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;

/**
 * Kredi basvuru sureci icin arayuz sinifi
 *
 * @param <T>
 */
public interface CreditApplicationProcess<T extends Application> {
	
	/**
	 * Kredi basvuru talebi
	 * 
	 * @param application
	 * @param checkExistingMobilePhone
	 */
	public Map<?,?> applicationRequest(T application, boolean checkExistingMobilePhone);
	
	/**
	 * Kredi basvuru reddi
	 * 
	 * @param application
	 */
	public Map<?,?> applicationReject(T application);
	
	/**
	 * Kredi basvuru ara statu sonrasinda cagirilir.
	 * 
	 * @param application
	 */
	public Map<?,?> applicationAfterIntermediateStatus(T application);
	
	/**
	 * Kredi bavuru onayi, kredi basvurusu sozlesme adimina gecerek sozlesme basima hazir olur veya ara duruma duser.
	 * 
	 * @param application
	 */
	public Map<?,?> applicationConfirm(T application);
	
	/**
	 * Kredi bavuru onay sonrasi cagirilir.
	 * 
	 * @param application	Basvuru
	 * @param parameters	Karar parametreleri
	 */
	public Map<?,?> applicationAfterConfirm(T application, Map<?,?> parameters);
	
	/**
	 * Sozlesme basim
	 * 
	 * @param application
	 */
	public Map<?,?> paymentPlanRequest(T application);
	
	/**
	 * Sozlesme basim onayi
	 * 
	 * @param application
	 */
	public Map<?,?> paymentPlanConfirm(T application);
	
	/**
	 * Kullandirim
	 * 
	 * @param application	Basvuru
	 * @param documents		Basvuru Belgeleri
	 * @param isApproved	Belgelerin uygunluk durumu
	 */
	public Map<?,?> contractualRequest(T application, List<Map<?,?>> documents);
	
	/**
	 * Eksik Evrak
	 * 
	 * @param application	Basvuru
	 * @param documents		Basvuru Belgeleri
	 * @return
	 */
	public Map<?,?> resendDocuments(T applications, List<Map<?,?>> documents);
}
