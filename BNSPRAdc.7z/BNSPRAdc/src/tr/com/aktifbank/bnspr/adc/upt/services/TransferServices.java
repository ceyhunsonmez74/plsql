package tr.com.aktifbank.bnspr.adc.upt.services;

import java.sql.Types;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class TransferServices {

	private static Logger logger = Logger.getLogger(TransferServices.class);
	private static String AKTIF_BANK_BANK_CODE = "143"; 

	@GraymoundService("BNSPR_UPT_KOPRU_IBAN_HAREKETLERI")
	public static GMMap kopruIbanHareketleri(GMMap iMap) {

		try {
			return DALUtil.callOracleRefCursorFunction("{ ? = call pkg_kopru_iban.rc_kopru_bakiye_aktarim(?,?,?) }",
				"HAREKET", BnsprType.DATE, iMap.getDate("TARIH"), BnsprType.STRING, iMap.getString("BASZAMAN"),
				BnsprType.STRING, iMap.getString("BITZAMAN"));
		} catch(Exception e) {
			logger.error("BNSPR_UPT_KOPRU_IBAN_HAREKETLERI err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_UPT_IBAN_FIRST_CONTROL")
	public static GMMap uptBnsprIbanFirstControl(GMMap iMap) {

		GMMap oMap = new GMMap();
		
		try {
			oMap.put("BANK_CODE", DALUtil.callOracleFunction("{? = call pkg_iban.iban_banka_kodu_al(?)}", BnsprType.STRING, BnsprType.STRING, iMap.getString("IBAN")));

			if(AKTIF_BANK_BANK_CODE.equals(oMap.getString("BANK_CODE"))) {
				oMap.put("HESAP_NO", DALUtil.callOneParameterFunction("{? = call pkg_hesap.IBANdan_HesapNoAl(?)}", Types.VARCHAR, iMap.getString("IBAN")));
				oMap.put("MUSTERI_NO", DALUtil.callOneParameterFunction("{? = call pkg_hesap.musteri_no(?)}", Types.NUMERIC, oMap.getString("HESAP_NO")));

				Session session = DAOSession.getSession("BNSPRDal");
				
				GnlMusteri gnlMusteri = (GnlMusteri) session.get(GnlMusteri.class, oMap.getBigDecimal("MUSTERI_NO"));
				
				if(gnlMusteri.getIkinciAdi() != null && gnlMusteri.getAdi()!= null) 
					oMap.put("ADI", (gnlMusteri.getAdi().length() > 1 ? gnlMusteri.getAdi().substring(0,2) + "*****" : gnlMusteri.getAdi())  + " " + 
									(gnlMusteri.getIkinciAdi().length() > 1 ? gnlMusteri.getIkinciAdi().substring(0,2) + "*****" : gnlMusteri.getIkinciAdi()));
				else{
					oMap.put("ADI", gnlMusteri.getAdi() != null && gnlMusteri.getAdi().length() > 1 ? gnlMusteri.getAdi().substring(0,2) + "*****" : gnlMusteri.getAdi());
					} 
				oMap.put("SOYADI", gnlMusteri.getSoyadi() != null && gnlMusteri.getSoyadi().length() > 1 ? gnlMusteri.getSoyadi().substring(0,2) + "*****" : gnlMusteri.getSoyadi());
				oMap.put("MUSTERI_TUR_KOD", "G".equals(gnlMusteri.getMusteriTurKod()) ? gnlMusteri.getMusteriTurKod() : "T");
				oMap.put("TICARI_UNVAN", "O".equals(gnlMusteri.getMusteriTurKod()) ? 
										 (gnlMusteri.getKisaAd() != null && gnlMusteri.getKisaAd().length() > 1 ? gnlMusteri.getKisaAd().substring(0,2) + "*****" : gnlMusteri.getKisaAd()) :
										 (gnlMusteri.getTicariUnvan() != null && gnlMusteri.getTicariUnvan().length() > 1 ? gnlMusteri.getTicariUnvan().substring(0,2) + "*****" : gnlMusteri.getTicariUnvan()));
				}	

			return oMap;

		} catch(Exception e) {
			logger.error("BNSPR_UPT_IBAN_FIRST_CONTROL err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}

}
