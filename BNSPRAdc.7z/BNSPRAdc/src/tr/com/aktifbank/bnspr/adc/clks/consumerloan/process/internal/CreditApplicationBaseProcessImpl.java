package tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.internal;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.graymound.server.dao.DAOSession;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.accounting.model.Record;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionContext;
import tr.com.aktifbank.bnspr.adc.clks.accounting.dao.internal.GMCacheCommissionDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.api.CreditApplicationApi;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.dao.CreditApplicationDao;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.model.Application.STATUS;
import tr.com.aktifbank.bnspr.adc.clks.consumerloan.process.CreditApplicationProcess;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruSmsTalep;

public abstract class CreditApplicationBaseProcessImpl<T extends Application> implements CreditApplicationProcess<T>,
	Serializable {

	private static final long serialVersionUID = -3785527535788583389L;

	private static Logger logger = Logger.getLogger(CreditApplicationBaseProcessImpl.class);
	
	/**
	 * Kredi basvuru servis nesnesi
	 */
	private final CreditApplicationApi api;
	
	/**
	 * Kredi basvu DAO nesnesi
	 */
	private final CreditApplicationDao<T> dao;
	
	public CreditApplicationBaseProcessImpl(CreditApplicationDao<T> dao, CreditApplicationApi api) {
		this.dao = dao;
		this.api = api;
	}

	@Override
	public Map<?,?> applicationRequest(T application, boolean checkExistingMobilePhone) {
		
		logger.info(String.format("[ConsumerLoan][BaseLogic][ApplicationRequest] - %s", application.toString()));
		
		Map<String, Object> response = new HashMap<String, Object>();
		
		if(checkExistingMobilePhone) {
			if(api.isMobilePhoneExistsOnAnotherCustomer(application.getNationalIdentificationNumber(), application
				.getMobilePhone().substring(0, 3), application.getMobilePhone().substring(3))) {
				response.put("RESPONSE", "4");
				response.put("RESPONSE_DATA", api.message(5061));
				return response;
			}
		}

		api.amountAndTermControl(application.getCampaign().getCode().toString(), application.getAmount(), application
			.getTerm());
		
		api.ageControl(application.getCustomer().getBirthDate(), application.getCampaign().getChannelCode(),
			application.getTerm());

		if(application.isIpaz()) {
			api.updateCustomerMarketingPermission(null, application.getNationalIdentificationNumber());
			api.sendText(application.getTrxNo(), null, application.getMobilePhone(), null, 5856);
		}
		
		/*
		String crsInfo = api.crsInfo(application.getNationalIdentificationNumber());
		
		if(!"E".equals(crsInfo) && application.isCrs()) {
			api.updateCrsInfo(application.getNationalIdentificationNumber(), application.isCrs());
			crsInfo = "E";
			response.put("MESSAGE", api.message(5930));
		} else if("E".equals(crsInfo)) {
			response.put("MESSAGE", api.message(5927));
		}
		
		if("E".equals(crsInfo)) {
			api.rejectApplication(application.getApplicationNo(), application.getTrxNo(), STATUS.BASVURU.toString(),
				"48");
			application.setStatus(STATUS.RED);
		}
		*/
		
		return response;
	}
	
	@Override
	public Map<?,?> applicationReject(T application) {
		
		logger.info(String.format("[ConsumerLoan][BaseLogic][ApplicationReject] - %s", application.toString()));
		saveRejectionCommission(application);
		return new HashMap<String, Object>();
	}
	
	@Override
	public Map<?,?> applicationAfterIntermediateStatus(T application) {
		
		logger.info(String.format("[ConsumerLoan][BaseLogic][ApplicationAfterIntermediateStatus] - %s", application.toString()));
		
		if(EnumSet.of(STATUS.SOZLESME, STATUS.EVRAKSIZ, STATUS.CEPTE, STATUS.IPTAL).contains(application.getStatus())) {
			saveAdmissionCommission(application);
		} else if(application.getStatus() == STATUS.RED) {
			saveRejectionCommission(application);
		}

		return new HashMap<String, Object>();
	}

	@Override
	public Map<?,?> applicationConfirm(T application) {
		
		logger.info(String.format("[ConsumerLoan][BaseLogic][ApplicationConfirm] - %s", application.toString()));
		
		if(application.getStatus() == STATUS.SOZLESME) {
			saveAdmissionCommission(application);
		} else if(application.getStatus() == STATUS.RED) {
			saveRejectionCommission(application);
		} else {
			try {
				dao.saveAsPendingApplication(application.getApplicationNo(), application.getStatus());
			} catch(SQLException e) {
				logger.error("Error while saving application as to be verified application - "
					+ application.getApplicationNo(), e);
				api.error(1803);
			}
		}

		return new HashMap<String, Object>();
	}
	
	@Override
	public Map<?,?> applicationAfterConfirm(T application, Map<?,?> parameters) {
		
		logger.info(String.format("[ConsumerLoan][BaseLogic][ApplicationAfterConfirm] - %s", application.toString()));
		
		if("Y".equalsIgnoreCase((String) parameters.get("SGK_BELGE_GEREKLI"))) {
			api.sendText(application.getTrxNo(), application.getCustomer().getCustomerNo(), application
				.getMobilePhone(), api.message(5942, application.getCustomer().toString(), application
				.getApplicationNo().toString()), -1);
		}
		
		return new HashMap<String, Object>();
	}

	@Override
	public Map<?,?> paymentPlanRequest(T application) {

		logger.info(String.format("[ConsumerLoan][BaseLogic][PaymentPlanRequest] - %s", application.toString()));
		saveAdmissionCommission(application);
		return new HashMap<String, Object>();
	}

	@Override
	public Map<?,?> paymentPlanConfirm(T application) {

		logger.info(String.format("[ConsumerLoan][BaseLogic][PaymentPlanConfirm] - %s", application.toString()));
		return new HashMap<String, Object>();
	}

	@Override
	public Map<?,?> contractualRequest(T application, List<Map<?,?>> documents) {

		logger.info(String.format("[ConsumerLoan][BaseLogic][ContractualRequest] - %s", application.toString()));
		
		Map<String, Object> response = new HashMap<String, Object>();

		if(!application.isContractualRequestapprovedApproved()) {
			String message = api.rejectApplication(application.getApplicationNo(), application.getTrxNoDocumentProcessing(),
				Application.STATUS.BELGE.toString(), "17");
			application.setStatus(STATUS.RED);
			response.put("MESSAGE", message);
			
			return response;
		}
		
		@SuppressWarnings("unchecked")
		Map<String, Object> updateDocumentsMap = (Map<String, Object>) api.updateDocuments(application
			.getApplicationNo(), application.getTrxNoDocumentProcessing(), documents);
		
		response.putAll(updateDocumentsMap);

		Map<?,?> parameters = api.fetchParameters(application.getApplicationNo(), Application.STATUS.BELGE);
		api.documentControl(documents, parameters);
		api.setGroupPersonalDatePermission(application.getCustomer().getCustomerNo(), "KREDI");
		api.saveBarcode(application.getApplicationNo(), application.getBarcode());
		
		response.put("KAMPANYA_TIP", parameters.get("KAMPANYA_TIP"));
		response.put("TC_KIMLIK_NO", application.getNationalIdentificationNumber());
		
		return response;
	}

	@Override
	public Map<?,?> resendDocuments(T application, List<Map<?,?>> documents) {

		logger.info(String.format("[ConsumerLoan][BaseLogic][ResendDocuments] - %s", application.toString()));
		
		Map<String, Object> response = new HashMap<String, Object>();
		
		@SuppressWarnings("unchecked")
		Map<String, Object> parameters = (Map<String, Object>) api.fetchParameters(application.getApplicationNo(), Application.STATUS.BELGE);
		parameters.put("DURUM_KODU", "EVRAKSIZ");
		
		api.documentControl(documents, parameters);
		api.setGroupPersonalDatePermission(application.getCustomer().getCustomerNo(), "KREDI");
		api.saveBarcode(application.getApplicationNo(), application.getBarcode());

		response.put("KAMPANYA_TIP", parameters.get("KAMPANYA_TIP"));
		
		return response;
	}
	
	/**
	 * 
	 * @param application
	 */
	protected void saveAdmissionCommission(T application) {
		
		switch(application.getCampaign().getRelation()) {
			case RETIREE:
				application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_KABUL_EMEKLI);
				if (isSMSCreditApplication(application.getApplicationNo())) {
					application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_KABUL_EMEKLI_SMS);
				}
				break;
			case PERSONNEL:
				application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_KABUL_PERSONEL);
				break;
			case OTHER:
				application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_KABUL_DIGER);
				break;
			default:
				break;
		}
	
		application.setCommission(calculateCommission(application.getCommissionCategory(), application.getAmount(),
			application.getCurrency()));
		dao.saveCommission(application);
		
	}
	
	/**
	 * 
	 * @param application
	 */
	protected void saveRejectionCommission(T application) {

		switch(application.getCampaign().getRelation()) {
			case RETIREE:
				application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_RED_EMEKLI);
				break;
			case PERSONNEL:
				application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_RED_PERSONEL);
				break;
			case OTHER:
				application.setCommissionCategory(CommissionCategory.KREDI_BASVURU_RED_DIGER);
				break;
			default:
				break;
		}
		
		try {
			application.setQualifiedCommission("E".equals(dao.updateQualifiedCommissionOnReject(application
				.getApplicationNo(), application.getNationalIdentificationNumber())) ? true : false);
		} catch(SQLException e) {
			logger.error("CreditApplicationBaseProcessImpl.saveRejectionCommission(" + application.toString() +")", e);
		}
		
		if(application.isQualifiedCommission()) {
			application.setCommission(calculateCommission(application.getCommissionCategory(), application.getAmount(),
				application.getCurrency()));
			dao.saveCommission(application);
		}
	}
	
	/**
	 * 
	 * @param commissionCategory
	 * @param amount
	 * @param currency
	 * @return
	 */
	protected Record calculateCommission(CommissionCategory commissionCategory, BigDecimal amount, CurrencyType currency) {
		
		CommissionContext commissionContext = null;
		Record record = null;
		
		try {
			commissionContext = new CommissionContext(commissionCategory
				.getStrategyClass().getDeclaredConstructor(List.class).newInstance(
					new GMCacheCommissionDao().getByCommissionCategory(commissionCategory)));

			record = commissionContext.calculate(new Record(amount, currency));
			
		} catch(Exception e) {
			logger.error(String.format(
				"CreditApplicationBaseProcessImpl.calculateCommission(commissionCategory, amount, currency) => (%s,%s,%s)",
				commissionCategory.toString(), amount.toString(), currency.toString()), e);
		}
		
		return record;
	}

	/**
	 * @return {@link #dao}
	 */
	public CreditApplicationDao<T> getDao() {
		return dao;
	}

	/**
	 * @return  {@link #api}
	 */
	public CreditApplicationApi getApi() {
		return api;
	}
	
	public static boolean isSMSCreditApplication(BigDecimal applicationNo) {
		Session session = DAOSession.getSession("BNSPRDal");

		ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class,
				applicationNo);
		if (clksBirBasvuruSmsTalep!=null) {
			return true;
		}else {
			return false;
		}
	}
}