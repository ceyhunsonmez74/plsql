package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;

public class ElectronicFundTransferPayment extends Transaction {

	private static final long serialVersionUID = 2327304230492296076L;
	
	public ElectronicFundTransferPayment(BigDecimal trxNo) {
		super(trxNo, (short) 2317);
		this.setReconciliationType(ReconciliationType.ELECTRONIC_FUND_TRANSFER_PAYMENT);
		this.setCommissionCategory(CommissionCategory.PAYMENT);
	}
}
