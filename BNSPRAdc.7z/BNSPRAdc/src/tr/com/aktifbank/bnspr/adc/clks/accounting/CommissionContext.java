package tr.com.aktifbank.bnspr.adc.clks.accounting;

import tr.com.aktifbank.bnspr.adc.accounting.model.Record;

public class CommissionContext {
	
	private CommissionStrategy strategy;
	
	public CommissionContext(CommissionStrategy strategy) {
		this.strategy = strategy;
	}
	
	public Record calculate(Record transactionRecord) {
		return strategy.calculate(transactionRecord);
	}
}
