package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.EnumSet;

import tr.com.aktifbank.bnspr.adc.accounting.model.CurrencyType;
import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;
import tr.com.aktifbank.bnspr.adc.clks.definition.model.ReconciliationType;
import tr.com.aktifbank.bnspr.adc.clks.transaction.model.Transaction;

/**
 * PTT kanali nakit yatirma islem sinifi
 * 
 * @see Transaction
 */
public class CashDeposit extends Transaction {

	private static final long serialVersionUID = 2153284579758930811L;
	
	/**
	 * Islem kanali
	 */
	private CHANNEL channel;
	
	public enum CHANNEL {
		BRANCH, ATM
	}

	public CashDeposit(BigDecimal trxNo, CHANNEL channel, ReconciliationType reconciliationType) {
		super(trxNo, channel == CHANNEL.BRANCH ? (short) 2050 : (short) 2049);
		this.setChannel(channel);
		this.setReconciliationType(reconciliationType);
		if(EnumSet.of(ReconciliationType.CASH_DEPOSIT, ReconciliationType.ATM_CASH_DEPOSIT_TO_ACCOUNT,
			ReconciliationType.ATM_CASH_DEPOSIT_TO_IBAN).contains(reconciliationType)) {
			this.setCommissionCategory(channel == CHANNEL.BRANCH ? CommissionCategory.CASH_DEPOSIT
				: CommissionCategory.ATM_CASH_DEPOSIT);
		}
	}

	/**
	 * @return {@link #channel}
	 */
	public CHANNEL getChannel() {
		return channel;
	}

	/**
	 * @param channel {@link #channel}
	 */
	public void setChannel(CHANNEL channel) {
		this.channel = channel;
	}
}
