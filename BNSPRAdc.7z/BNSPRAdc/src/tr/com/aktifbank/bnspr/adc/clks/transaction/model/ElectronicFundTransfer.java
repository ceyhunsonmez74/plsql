package tr.com.aktifbank.bnspr.adc.clks.transaction.model;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.adc.clks.accounting.CommissionCategory;

public class ElectronicFundTransfer extends Transaction {

	private static final long serialVersionUID = 2327304230492296076L;

	/**
	 * EFT Mesaj Kodu
	 */
	private MESSAGE message;
	
	/**
	 * Alici Hesap Numarasi
	 */
	private BigDecimal toAccount;
	
	/**
	 * Karsi Banka Kodu
	 */
	private String toBankCode;
	
	/**
	 * Karsi Banka Sube Kodu
	 */
	private String toBranchCode;
	
	/**
	 * Karsi IBAN Numarasi
	 */
	private String toIBAN;
	
	/**
	 * {@link #fromPCH} {@code true} ise, posta ceki hesap numarasi, aksi takdirde Aktif Bank hesap numarasi.
	 */
	private BigDecimal fromAccount;
	
	/**
	 * Gonderimin PCH'den yapildip/yapilmadiginin bilgisi
	 */
	private boolean fromPCH;
	
	public enum MESSAGE {
		TO_NAME("NORM"),
		TO_ACCOUNT("KRED"),
		TO_CREDIT_CARD("KRED-KART"),
		TO_IBAN("IBAN");
		
		private String code;

		private MESSAGE(String code) {
			this.code = code;
		}
		
		@Override
		public String toString() {
			return code;
		}
		
		public static MESSAGE getEnum(String code) {
			for(MESSAGE v : values())
				if(v.toString().equalsIgnoreCase(code))
					return v;
			
			return null;
		}
	}
	
	public ElectronicFundTransfer(BigDecimal trxNo) {
		super(trxNo, (short) 2315);
		this.setCommissionCategory(CommissionCategory.ELECTRONIC_FUND_TRANSFER);
	}

	/**
	 * @return {@link #message}
	 */
	public MESSAGE getMessage() {
		return message;
	}

	/**
	 * @param message {@link #message}
	 */
	public void setMessage(MESSAGE message) {
		this.message = message;
	}

	/**
	 * @return {@link #toAccount}
	 */
	public BigDecimal getToAccount() {
		return toAccount;
	}

	/**
	 * @param toAccount {@link #toAccount}
	 */
	public void setToAccount(BigDecimal toAccount) {
		this.toAccount = toAccount;
	}

	/**
	 * @return {@link #toIBAN}
	 */
	public String getToIBAN() {
		return toIBAN;
	}

	/**
	 * @param toIBAN {@link #toIBAN}
	 */
	public void setToIBAN(String toIBAN) {
		this.toIBAN = toIBAN;
	}

	/**
	 * @return {@link #fromAccount}
	 */
	public BigDecimal getFromAccount() {
		return fromAccount;
	}

	/**
	 * @param fromAccount {@link #fromAccount}
	 */
	public void setFromAccount(BigDecimal fromAccount) {
		this.fromAccount = fromAccount;
	}

	/**
	 * @return {@link #toBankCode}
	 */
	public String getToBankCode() {
		return toBankCode;
	}

	/**
	 * @param toBankCode {@link #toBankCode}
	 */
	public void setToBankCode(String toBankCode) {
		this.toBankCode = toBankCode;
	}

	/**
	 * @return {@link #toBranchCode}
	 */
	public String getToBranchCode() {
		return toBranchCode;
	}

	/**
	 * @param toBranchCode {@link #toBranchCode}
	 */
	public void setToBranchCode(String toBranchCode) {
		this.toBranchCode = toBranchCode;
	}

	/**
	 * @return {@link #fromPCH}
	 */
	public boolean isFromPCH() {
		return fromPCH;
	}

	/**
	 * @param fromPCH {@link #fromPCH}
	 */
	public void setFromPCH(boolean fromPCH) {
		this.fromPCH = fromPCH;
	}
}
