package tr.com.aktifbank.bnspr.adc.clks.definition.model;


public enum DiffType {

	FAZLA_KAYIT("F", "Fazla Kay�t"),
	EKSIK_KAYIT("E", "Eksik Kay�t"),
	DURUM_FARKLI_KAYIT("D", "Ba�vuru Durumu Farkl� Kay�t"),
	KOMISYON_FARKLI_KAYIT("K", "Komisyonu Farkl� Kay�t");
	
	private String code;
	private String label;
	
	private DiffType(String code, String label) {
		this.code = code;
		this.label = label;
	}
	
	public String getCode() {
		return code;
	}
	
	@Override
	public String toString() {
		return label;
	}

	public static DiffType getEnum(String code) {
		for(DiffType v : values()) {
			if(v.getCode().equals(code)) return v;
		}
		throw new IllegalArgumentException();
	}
}
