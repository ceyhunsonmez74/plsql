package tr.com.aktifbank.bnspr.adc.clks.definition.model.internal;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.adc.clks.definition.model.TransactionDefinition;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

class CreditPaymentDefinition extends BaseTransactionDefinition implements TransactionDefinition {
	
	public CreditPaymentDefinition() {
		super(new String[]{"2030", "2315"}, "7");
	}

	@Override
	public Map<?, ?> getReconciliationRecords(Date date, String listName) throws SQLException {
		
		GMMap oMap = new GMMap(), records = DALUtil.callOracleRefCursorFunction(
			"{? = call pkg_trn2052.get_credit_payment_records(?)}", listName, BnsprType.DATE, date);
		
		for(int i = 0; i < records.getSize(listName); i++) {
			
			GMMap accountingMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "TUTAR")).put(
				"PARA_BIRIMI", records.getString(listName, i, "PARA_BIRIMI")).put("MASRAF", "H");
			
			GMMap commisionMap = new GMMap().put("TUTAR", records.getBigDecimal(listName, i, "KOMISYON_TUTAR")).put(
				"PARA_BIRIMI", records.getString(listName, i, "KOMISYON_PARA_BIRIMI"));
			
			GMMap clientMap = new GMMap().put("SUBE_ID", records.getString(listName, i, "SUBE_ID")).put(
				"PERSONEL_SICIL", records.getString(listName, i, "PERSONEL_SICIL")).put("PERSONEL_ADI",
				records.getString(listName, i, "PERSONEL_ADI"));
			
			GMMap detailsMap = new GMMap().put("BASVURU_NO", records.getString(listName, i, "BASVURU_NO")).put("TUTAR",
				records.getString(listName, i, "KREDI_TUTAR"));
			detailsMap.put("KAMPANYA", new ArrayList<GMMap>(Arrays.asList(new GMMap().put("KOD",
				records.getString(listName, i, "KAMP_KOD")).put("TIP", records.getString(listName, i, "KAMP_TIP")))));

			oMap.put(listName, i, "ISLEM_TIPI", reconciliationCode);
			oMap.put(listName, i, "ISLEM_NO", records.getBigDecimal(listName, i, "ISLEM_NO"));
			oMap.put(listName, i, "DURUM", records.getString(listName, i, "DURUM"));
			oMap.put(listName, i, "MUHASEBE", new ArrayList<GMMap>(Arrays.asList(accountingMap)));
			oMap.put(listName, i, "KOMISYON", new ArrayList<GMMap>(Arrays.asList(commisionMap)));
			oMap.put(listName, i, "MUSTERI_DETAY", new ArrayList<GMMap>(Arrays.asList(clientMap)));
			oMap.put(listName, i, "KREDI_BASVURU_DETAY", new ArrayList<GMMap>(Arrays.asList(detailsMap)));
		}
		
		return oMap;
	}

	@Override
	public Map<?, ?> getRecords(Date date, String listName) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<?, ?> getConfirmData(BigDecimal trxNo) {
		
		GMMap oMap = new GMMap();
		
		Session	session	= DAOSession.getSession("BNSPRDal");
		
		ClksHavaleOdemeTx trx = (ClksHavaleOdemeTx) session.get(ClksHavaleOdemeTx.class, trxNo);
		
		if(trxNo == null) {
			// TODO throw exception
		}
		
		oMap.put("ACIKLAMA", trx.getAciklama());
		oMap.put("ISLEM", trx.getIslem());
		
		return oMap;
	}

	@Override
	public String reconciliationCode() {
		return reconciliationCode;
	}
}
