package tr.com.aktifbank.bnspr.clks.services.test;

import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.fail;

import com.graymound.util.GMMap;


public class InstallmentLoanServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}
	
	@Test
	public void testBnsprClksInstallmentLoanPaymentControl() {
		
		GMMap iMap = new GMMap();
		iMap.put("BASVURU_NO", 9776765);
		
		try {
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_INSTALLMENT_LOAN_PAYMENT_CONTROL", iMap);
			assertValidResponse(map);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testPttKrediBasvuruBilgi() {

		
		GMMap iMap = new GMMap();
		//iMap.put("TCKN", "14273575936");
		iMap.put("BASVURU_NO", 9806134);
		
		try {
			
			Map<?,?> map = this.getConn().serviceCall("CLKS_PTT_KREDI_BASVURU_BILGI", iMap);
			assertValidResponse(map);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
}
