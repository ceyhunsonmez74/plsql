package tr.com.aktifbank.bnspr.clks.services.test;


import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;

import com.graymound.connection.GMConnection;

public abstract class BaseTest {
	
	private static GMConnection conn;
	
    public static void establishConnection() {
		
		boolean localConnectionEstablished = false;
		
		try {
			URLConnection urlConn = new URL("http://localhost:8080/GMServer/Server/JAVA").openConnection();
			urlConn.connect();
			localConnectionEstablished = true;
			System.out.println("Local connection established.");
		}
		catch(IOException e) {
			System.out.println("Local connection cannot be established.");
		}
		
		try {
			conn = GMConnection.getConnection(localConnectionEstablished ? "LOCAL" : "UAT");
		} catch(IOException e) {
			fail(e.getMessage());
		}
    }
	
	public static void assertValidResponse(Map<?,?> map) {
		
		assertNotNull(map);
		
		if(map.containsKey("RESPONSE")) {
			if(map.get("RESPONSE").toString() == "0") {
				assertTrue("RESPONSE_DATA length is 0.", ((String) map.get("RESPONSE_DATA")).length() > 0);
			}
		}
	}
	
	public GMConnection getConn() throws IOException {
		return conn;
	}

	public GMConnection getConn(String connName) throws IOException {
		return GMConnection.getConnection(connName);
	}
}
