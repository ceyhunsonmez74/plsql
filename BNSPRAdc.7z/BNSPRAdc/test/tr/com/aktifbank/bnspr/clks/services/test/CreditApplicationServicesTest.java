package tr.com.aktifbank.bnspr.clks.services.test;

import static org.hamcrest.core.AnyOf.anyOf;
import static org.hamcrest.core.StringContains.containsString;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditApplicationServicesTest extends BaseTest {
	
	@Rule
	public final ExpectedException thrown = ExpectedException.none();
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}
	
	@Test
	public void Should_ReturnPensionerCampaignListForRelatedBranch_When_ValidInputGiven() {
		
		GMMap iMap = new GMMap();
		iMap.put("BRANCH_ID", "3346");
		iMap.put("INSTITUTION_SHORT_CODE", "1");
		iMap.put("CAMPAIGN_TYPE", "K");
		
		try {
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_CAMPAIGN_LIST", iMap);
			assertTrue(map.containsKey("KAMPANYA_LISTESI"));
			
			@SuppressWarnings("unchecked")
			List<GMMap> campaigns = (ArrayList<GMMap>) map.get("KAMPANYA_LISTESI");
			
			for(GMMap campaign : campaigns) {
				assertThat(campaign.getString("KAMPANYA_ADI"), containsString("Emekli"));
			}
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void Should_ReturnPersonelCampaignListForRelatedBranch_When_ValidInputGiven() throws IOException {
		
		GMMap iMap = new GMMap();
		iMap.put("BRANCH_ID", "3346");
		iMap.put("INSTITUTION_SHORT_CODE", "4");
		iMap.put("CAMPAIGN_TYPE", "K");
		
		try {
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_CAMPAIGN_LIST", iMap);
			assertTrue(map.containsKey("KAMPANYA_LISTESI"));
			
			@SuppressWarnings("unchecked")
			List<GMMap> campaigns = (ArrayList<GMMap>) map.get("KAMPANYA_LISTESI");
			
			for(GMMap campaign : campaigns) {
				assertThat(campaign.getString("KAMPANYA_ADI"), containsString("Personel"));
			}
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void Should_ReturnThirdPersonCampaignListForRelatedBranch_When_ValidInputGiven() throws IOException {
		
		GMMap iMap = new GMMap();
		iMap.put("BRANCH_ID", "3346");
		iMap.put("INSTITUTION_SHORT_CODE", "6");
		iMap.put("CAMPAIGN_TYPE", "K");
		
		try {
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_CAMPAIGN_LIST", iMap);
			assertTrue(map.containsKey("KAMPANYA_LISTESI"));
			
			@SuppressWarnings("unchecked")
			List<GMMap> campaigns = (ArrayList<GMMap>) map.get("KAMPANYA_LISTESI");
			
			for(GMMap campaign : campaigns) {
				assertThat(campaign.getString("KAMPANYA_ADI"), containsString("3. �ah�s"));
			}
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void Should_ReturnPensionerConsolidationCampaignListForRelatedBranch_When_ValidInputGiven() {
		
		GMMap iMap = new GMMap();
		iMap.put("BRANCH_ID", "3346");
		iMap.put("INSTITUTION_SHORT_CODE", "1");
		iMap.put("CAMPAIGN_TYPE", "B");
		
		try {
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_CAMPAIGN_LIST", iMap);
			assertTrue(map.containsKey("KAMPANYA_LISTESI"));
			
			@SuppressWarnings("unchecked")
			List<GMMap> campaigns = (ArrayList<GMMap>) map.get("KAMPANYA_LISTESI");
			
			for(GMMap campaign : campaigns) {
				assertThat(campaign.getString("KAMPANYA_ADI"),
					anyOf(containsString("Emekli"), containsString("Birle�tirme")));
			}
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void Should_ReturnPersonelConsolidationCampaignListForRelatedBranch_When_ValidInputGiven() {
		
		GMMap iMap = new GMMap();
		iMap.put("BRANCH_ID", "3346");
		iMap.put("INSTITUTION_SHORT_CODE", "4");
		iMap.put("CAMPAIGN_TYPE", "B");
		
		try {
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_CAMPAIGN_LIST", iMap);
			assertTrue(map.containsKey("KAMPANYA_LISTESI"));
			
			@SuppressWarnings("unchecked")
			List<GMMap> campaigns = (ArrayList<GMMap>) map.get("KAMPANYA_LISTESI");
			
			for(GMMap campaign : campaigns) {
				assertThat(campaign.getString("KAMPANYA_ADI"),
					anyOf(containsString("Personel"), containsString("Birle�tirme")));
			}
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void Should_ThrowGMRuntimeException_When_UnrelatedOrInvalidBranchGiven() throws IOException {

		GMMap iMap = new GMMap();
		iMap.put("BRANCH_ID", "-1");
		iMap.put("CAMPAIGN_TYPE", "K");
		iMap.put("INSTITUTION_SHORT_CODE", "1");
	
		thrown.expect(GMRuntimeException.class);
		thrown.expectMessage("Bu ko�ullar i�in kampanya tan�m� yap�lmam��");
		this.getConn().serviceCall("BNSPR_CLKS_CREDIT_CAMPAIGN_LIST", iMap);
	}

}
