package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class AdcPAR4025ServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}

	@Test
	public void testIslemSave() {
			
		try {
			this.getConn().serviceCall("BNSPR_PAR4025_ISLEM_SAVE", new GMMap());
			assertTrue(true);
		}
		catch(Exception e) {
			fail(e.getMessage());
		}
	}
}
