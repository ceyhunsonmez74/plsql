package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class OverdraftAccountApplication extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}

	@Test
	public void testTalep() {

		GMMap iMap = new GMMap();
		String nullVal = null;

		iMap.put("CEP_TEL_KOD","555");
		iMap.put("CEP_TEL_NO","4322235");
		iMap.put("POSTA_CEKI_HESAP_NUMARASI", 553);
		iMap.put("ANNE_KIZLIK_SOYADI", "DERE");
		iMap.put("F_KPS_YAPILDI", "E");
		iMap.put("F_APS_YAPILDI", "E");
		iMap.put("F_KIMLIK_BILGILERI_UYUMLU", "E");
		iMap.put("F_ADRES_BILGILERI_UYUMLU", "E");
		iMap.put("F_FATURA_TAHSILAT", "E");
		iMap.put("HESAP_EKSTRE", "E");
		iMap.put("EMAIL", nullVal);
		iMap.put("TALEP_EDILEN_TUTAR", 400);
		iMap.put("SGK_SONUC_KODU", nullVal);
		iMap.put("SGK_SONUC_ACIKLAMA", nullVal);
		iMap.put("MAAS_PERIOD", 1);
		iMap.put("SON_MEZUN_OLDUGU_OKUL", "U");
		iMap.put("OTURDUGU_EV_DURUMU",1);
		iMap.put("ADRESTE_OTURMA_SURESI_YIL",1);
		iMap.put("ADRESTE_OTURMA_SURESI_AY",5);
		iMap.put("CALISMA_SEKLI",1);
		iMap.put("TC_KIMLIK_NO", "43042932984");
		iMap.put("UYRUK", nullVal);
		iMap.put("ADI", "DEN�Z");
		iMap.put("IKINCI_ADI", nullVal);
		iMap.put("SOYADI", "KUM");
		iMap.put("ONCEKI_SOYADI", nullVal);
		iMap.put("DOGUM_YERI", "BE��KTA�");
		iMap.put("DOGUM_TARIHI", "19670501");
		iMap.put("BABA_ADI", "G�ND�Z");
		iMap.put("KIMLIK_SERI_NO", nullVal);
		iMap.put("KIMLIK_SIRA_NO", nullVal);
		iMap.put("ANNE_ADI", "YAZ");
		iMap.put("NUFUS_IL_KOD", "034");
		iMap.put("NUFUS_ILCE_KOD", 1183);
		iMap.put("NUFUS_CILT_NO", 34);
		iMap.put("NUFUS_AILE_SIRA_NO", 99);
		iMap.put("NUFUS_SIRA_NO", 999);
		iMap.put("NUFUS_VERILIS_TARIHI", "20000101");
		iMap.put("CINSIYET", "K");
		iMap.put("MEDENI_HAL", 2);
		iMap.put("NUF_VERILIS_NEDENI", "De�i�tirme");
		iMap.put("NUF_VERILDIGI_YER", "1183");
		iMap.put("KIMLIK_KAYIT_NO", nullVal);
		iMap.put("KIMLIK_SERI_NO_KPS", "K02");
		iMap.put("KIMLIK_SIRA_NO_KPS", "123456");
		
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE_ID", "1773");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI", "34284");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL", "123450");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_MERKEZ", "VAN");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "PTT_ISLEM_NO", "");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "MERKEZ_SUBE_BASMUDURLUK", "M");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_BASMUDURLUK", "65102");
		
		GMMap kkbSonucData = new GMMap();
    	/*kkbSonucData.put("GECMIS_KULLANDIRIMI_YAPILANLAR", 0, "TAKSIT_TUTARI", taksit);
    	kkbSonucData.put("GECMIS_KULLANDIRIMI_YAPILANLAR", 0, "KULLANDIRIM_TARIHI", "20160609");
    	kkbSonucData.put("GECMIS_KULLANDIRIMI_YAPILANLAR", 0, "VADE", 36);
    	kkbSonucData.put("GECMIS_KULLANDIRIMI_YAPILANLAR", 0, "TUTAR", tutar);
    	kkbSonucData.put("GECMIS_ONAYLANMIS_BASVURULAR", 0, "BASVURU_TARIHI", "20160609");
    	kkbSonucData.put("GECMIS_ONAYLANMIS_BASVURULAR", 0, "BASVURU_SAATI", "13:53");*/
    	kkbSonucData.put("KMH_DURUMU", "H");
    	
    	List<GMMap> kkbSonucDataList = new ArrayList<GMMap>();
    	kkbSonucDataList.add(kkbSonucData);
        iMap.put("KKB_SONUC_DATA", kkbSonucDataList);
		
		iMap.put("APS_BILGILERI", 0, "EV_ADRES", "[TEST ORTAMI][GECERSIZ ADRES]");
		iMap.put("APS_BILGILERI", 0, "EV_POSTAKOD", "");
		
		iMap.put("MAAS_BILGILERI", 0, "ONCEKI_MAAS_ODEME_TARIHI", "20181024");
		iMap.put("MAAS_BILGILERI", 0, "MAAS_PTT_DENMI", "E");
		iMap.put("MAAS_BILGILERI", 0, "EMEKLI_MAAS_EVDENMI", "H");
		iMap.put("MAAS_BILGILERI", 0, "EMEKLI_MAAS_DONEM", "201810");
		iMap.put("MAAS_BILGILERI", 0, "KURUM_DONEM", "201811");
		iMap.put("MAAS_BILGILERI", 0, "MAAS_TUTARI", 1663.33);
		iMap.put("MAAS_BILGILERI", 0, "ILK_MAAS_TARIHI", "20170328");
		iMap.put("MAAS_BILGILERI", 0, "SON_MAAS_TARIHI", "20181024");
		iMap.put("MAAS_BILGILERI", 0, "TAHSIS_NUMARASI", "3411439984");
		iMap.put("MAAS_BILGILERI", 0, "MAAS_ALINAN_KURUM", "202");
		iMap.put("MAAS_BILGILERI", 1, "ONCEKI_MAAS_ODEME_TARIHI", "20180924");
		iMap.put("MAAS_BILGILERI", 1, "MAAS_PTT_DENMI", "E");
		iMap.put("MAAS_BILGILERI", 1, "EMEKLI_MAAS_EVDENMI", "H");
		iMap.put("MAAS_BILGILERI", 1, "EMEKLI_MAAS_DONEM", "201809");
		iMap.put("MAAS_BILGILERI", 1, "KURUM_DONEM", "201811");
		iMap.put("MAAS_BILGILERI", 1, "MAAS_TUTARI", 1663.33);
		iMap.put("MAAS_BILGILERI", 1, "ILK_MAAS_TARIHI", "20170328");
		iMap.put("MAAS_BILGILERI", 1, "SON_MAAS_TARIHI", "20180924");
		iMap.put("MAAS_BILGILERI", 1, "TAHSIS_NUMARASI", "3411439984");
		iMap.put("MAAS_BILGILERI", 1, "MAAS_ALINAN_KURUM", "202");
		iMap.put("MAAS_BILGILERI", 2, "ONCEKI_MAAS_ODEME_TARIHI", "20180820");
		iMap.put("MAAS_BILGILERI", 2, "MAAS_PTT_DENMI", "E");
		iMap.put("MAAS_BILGILERI", 2, "EMEKLI_MAAS_EVDENMI", "H");
		iMap.put("MAAS_BILGILERI", 2, "EMEKLI_MAAS_DONEM", "201808");
		iMap.put("MAAS_BILGILERI", 2, "KURUM_DONEM", "201811");
		iMap.put("MAAS_BILGILERI", 2, "MAAS_TUTARI", 1639.33);
		iMap.put("MAAS_BILGILERI", 2, "ILK_MAAS_TARIHI", "20170328");
		iMap.put("MAAS_BILGILERI", 2, "SON_MAAS_TARIHI", "20180818");
		iMap.put("MAAS_BILGILERI", 2, "TAHSIS_NUMARASI", "3411439984");
		iMap.put("MAAS_BILGILERI", 2, "MAAS_ALINAN_KURUM", "202");
		iMap.put("MAAS_BILGILERI", 2, "MAAS_TARIH_SIKLIGI", nullVal);
		iMap.put("MAAS_BILGILERI", 3, "ONCEKI_MAAS_ODEME_TARIHI", "20180724");
		iMap.put("MAAS_BILGILERI", 3, "MAAS_PTT_DENMI", "E");
		iMap.put("MAAS_BILGILERI", 3, "EMEKLI_MAAS_EVDENMI", "H");
		iMap.put("MAAS_BILGILERI", 3, "EMEKLI_MAAS_DONEM", "201807");
		iMap.put("MAAS_BILGILERI", 3, "KURUM_DONEM", "201811");
		iMap.put("MAAS_BILGILERI", 3, "MAAS_TUTARI", 1560.79);
		iMap.put("MAAS_BILGILERI", 3, "ILK_MAAS_TARIHI", "20170328");
		iMap.put("MAAS_BILGILERI", 3, "SON_MAAS_TARIHI", "20180724");
		iMap.put("MAAS_BILGILERI", 3, "TAHSIS_NUMARASI", "3411439984");
		iMap.put("MAAS_BILGILERI", 3, "MAAS_ALINAN_KURUM", "202");

		try {

			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_KMH_BASVURU_TALEP", iMap);
			map = this.getConn("UAT").serviceCall("BNSPR_TRN3171_DEVAM_SORGULAR", map);
			assertValidResponse(map);

		}
		catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testOnay() {

		GMMap iMap = new GMMap();

		try {

			// BASVURU_NO=9830947, TRX_NO=40558444,
			
			iMap.put("BASVURU_NO", "9830947");
			iMap.put("TRX_NO", "40558444");
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_KMH_BASVURU_ONAY", iMap);
			assertValidResponse(map);
		}
		catch (Exception e) {
			fail(e.getMessage());
		}
		
	}
	
	@Test
	public void testSozlesmeBasim() {


		GMMap iMap = new GMMap();

		try {

			iMap.put("BASVURU_NO", "9830947");
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_KMH_BASVURU_BELGE_BILGILERI", iMap);
			assertValidResponse(map);
		}
		catch (Exception e) {
			fail(e.getMessage());
		}
	}
}
