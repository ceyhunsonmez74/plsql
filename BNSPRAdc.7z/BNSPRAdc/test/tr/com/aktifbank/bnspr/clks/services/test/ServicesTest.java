package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class ServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}

	@Test
	public void testClksIslemIptalEdilebilirmi() {
		
		try {
			Map<?,?> map = this.getConn().serviceCall("CLKS_ISLEM_IPTAL_EDILEBILIRMI", new GMMap().put("ISLEMNO", 12862890));
			assertNotNull(map);
			
			/*if(((Integer) map.get("RESPONSE")).intValue() == 2) {
				assertNotNull(map.get("BASVURU"));
			} else {
				assertTrue(((String) map.get("RESPONSE_CODE")).length() > 0);
			}*/
		}
		catch(Exception e) {
			fail(e.getMessage());
		}
	}
}
