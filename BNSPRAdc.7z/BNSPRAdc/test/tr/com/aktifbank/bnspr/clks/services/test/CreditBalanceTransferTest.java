package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.graymound.util.GMMap;

public class CreditBalanceTransferTest extends BaseTest {
	
	@Rule
	public final ExpectedException thrown = ExpectedException.none();
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}
	
	@Test
	public void Should_ReturnBankCode_When_ValidIBANGiven() {
		
		GMMap iMap = new GMMap();
		iMap.put("IBAN", "TR140006400000110740456920");
		
		try {
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_IBAN_VALIDATION", iMap);
			assertTrue(map.containsKey("BANK_CODE"));
			assertTrue(map.containsKey("BANK_NAME"));
			assertEquals((String) map.get("BANK_CODE"),"64");
			assertTrue(map.containsKey("BRANCHES"));
			
			@SuppressWarnings("unchecked")
			List<HashMap<String,String>> branches = (ArrayList<HashMap<String,String>>) map.get("BRANCHES");
			
			for(HashMap<String,String> branch : branches) {
				assertNotNull("CODE is null", branch.get("CODE"));
				assertNotNull("NAME is null", branch.get("NAME"));
				assertNotNull("PROVINCE_CODE is null", branch.get("PROVINCE_CODE"));
			}
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void Should_TriggerPayOffEvent_When_GetPayOffInfoCalled() {
		
		GMMap iMap = new GMMap();
		iMap.put("CUSTOMER_NO", 1362570);
		
		try {
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_GET_PAYOFF_INFO", iMap);
			assertNotNull("RESPONSE is null", map.get("RESPONSE"));
			System.out.println(map);
		} catch(IOException e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void Should_TriggerPayOffEvent_When_GetPensionSalarayInfoCalled() {
		
		GMMap iMap = new GMMap();
		iMap.put("CUSTOMER_NO", 1362570);
		
		try {
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_BALANCE_TRANSFER_GET_PENSION_SALARY_INFO",
				iMap);
			assertNotNull("RESPONSE is null", map.get("RESPONSE"));
			System.out.println(map);
		} catch(IOException e) {
			fail(e.getMessage());
		}
	}

}
