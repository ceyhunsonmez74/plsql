package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class BondServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}
	
	@Test
	public void testMevcutMusteriHesapAcmaVeEvrakTamamlama() {
		
		GMMap iMap = new GMMap();
		iMap.put("TC_KIMLIK_NO", "13507858388");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMIN_YAPILDIGI_SUBE_ID", "1773");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMI_YAPAN_KULLANICI", "1000000020");
		iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMI_YAPAN_KULLANICI_SICIL", "777669");
		
		try {
			GMMap map = new GMMap(this.getConn().serviceCall("BNSPR_CLKS_BONO_MUSTERI_SORGULAMA", iMap));
			System.out.println("BNSPR_CLKS_BONO_MUSTERI_SORGULAMA:" + map.toString());
			assertEquals("1", map.getString("RESPONSE"));
			map.clear();
			map = new GMMap(this.getConn().serviceCall("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_BILGILERI", iMap));
			System.out.println("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_BILGILERI:" + map.toString());
			assertNotNull(map.get("BELGE_DETAY"));
			assertNotNull(map.get("TRX_NO"));
			assertNotNull(map.get("BARKOD"));
			assertNotNull(map.get("BASVURU_NO"));
			for(int i=0; i<map.getSize("BELGE_DETAY"); i++) {
				map.put("BELGE_LISTESI", i, "BELGE_KODU", map.getString("BELGE_DETAY", i, "BELGE_KODU"));
				map.put("BELGE_LISTESI", i, "F_BELGE_TESLIM", "E");
				map.put("BELGE_LISTESI", i, "DATA", "50");
			}
			map.remove("BELGE_DETAY");
			map.remove("BASVURU_NO");
			map.remove("BARKOD");
			map = new GMMap(this.getConn().serviceCall("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_ONAY", map));
			System.out.println("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_ONAY:" + map.toString());
			assertNotNull(map.get("HESAP_NO"));
			assertNotNull(map.get("MUSTERI_NO"));
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprClksBonoMusteriBasvuru() {
		
		try {
			
			/*
			"ISYERI_VE_KULLANICI_BILGILERI[ISLEMIN_YAPILDIGI_SUBE_ID,ISLEMI_YAPAN_KULLANICI,
				ISLEMI_YAPAN_KULLANICI_SICIL,PTT_ISLEM_NO],"
			
			+ "KPS_BILGILERI[KIMLIK_TIPI,TC_KIMLIK_NO,ADI,SOYADI,DOGUM_YERI,DOGUM_TARIHI,BABA_ADI,ANNE_ADI,
				ES_TCKN,KIMLIK_SERI_NO,KIMLIK_SIRA_NO,NUFUS_IL_KOD,NUFUS_ILCE_KOD,MAHALLE_KOY,NUFUS_CILT_NO,
				NUFUS_AILE_SIRA_NO,NUFUS_SIRA_NO,CINSIYET,MEDENI_HAL,KAYIP_KIMLIK_SIRA_NO,KAYIP_KIMLIK_SERI_NO,
				NUFUS_VERILIS_TARIHI,NUFUS_VERILIS_NEDENI,NUFUS_VERILDIGI_YER,KIMLIK_KAYIT_NO],"
			
			+ "APS_BILGILERI[EV_ADRES,EV_ADR_IL_KOD,EV_ADR_ILCE_KOD,EV_POSTAKOD],"
			
			+ "TC_KIMLIK_NO,POSTA_CEKI_HESAP_NUMARASI,CEP_TEL_KOD,CEP_TEL_NO,EV_TEL_KOD,EV_TEL_NO,EMAIL,ANNE_KIZLIK_SOYADI,
				,F_KPS_YAPILDI,F_APS_YAPILDI,F_KIMLIK_BILGILERI_UYUMLU,F_ADRES_BILGILERI_UYUMLU",
			*/
			
			GMMap iMap = new GMMap();
			iMap.put("TC_KIMLIK_NO", "26960226250");
			iMap.put("CEP_TEL_KOD", "589"); iMap.put("CEP_TEL_NO", "9997845");
			iMap.put("EV_TEL_KOD", "212"); iMap.put("EV_TEL_NO", "2342843");
			iMap.put("EMAIL", "asd@aliveli.com");
			iMap.put("ANNE_KIZLIK_SOYADI", "TEST");
			iMap.put("F_KPS_YAPILDI", "E"); iMap.put("F_APS_YAPILDI", "E");
			iMap.put("F_KIMLIK_BILGILERI_UYUMLU", "E"); iMap.put("F_ADRES_BILGILERI_UYUMLU", "E");
			iMap.put("CALISMA_SEKLI", "O");
			iMap.put("HESAP_EKSTRE", "E");
			iMap.put("YATIRIM_EKSTRE", "E");
			
			iMap.put("KPS_BILGILERI", 0, "KIMLIK_TIPI", ""); iMap.put("KPS_BILGILERI", 0, "TC_KIMLIK_NO", "");
			iMap.put("KPS_BILGILERI", 0, "ADI", "DEN�Z"); 
			iMap.put("KPS_BILGILERI", 0, "IKINCI_ADI", ""); iMap.put("KPS_BILGILERI", 0, "SOYADI", "KUM");
			iMap.put("KPS_BILGILERI", 0, "DOGUM_YERI", "AK�A�AR"); iMap.put("KPS_BILGILERI", 0, "DOGUM_TARIHI", "19690317");
			iMap.put("KPS_BILGILERI", 0, "BABA_ADI", "VEL�"); iMap.put("KPS_BILGILERI", 0, "ANNE_ADI", "AY�E");
			iMap.put("KPS_BILGILERI", 0, "ES_TCKN", ""); 
			iMap.put("KPS_BILGILERI", 0, "KIMLIK_SERI_NO", "T10");
			iMap.put("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO", "113191"); 
			iMap.put("KPS_BILGILERI", 0, "NUFUS_ILCE_KOD", "1760"); iMap.put("KPS_BILGILERI", 0, "NUFUS_IL_KOD", "042"); 
			iMap.put("KPS_BILGILERI", 0, "MAHALLE_KOY", "AK�A�AR"); iMap.put("KPS_BILGILERI", 0, "NUFUS_CILT_NO", "");
			iMap.put("KPS_BILGILERI", 0, "NUFUS_AILE_SIRA_NO", "22"); iMap.put("KPS_BILGILERI", 0, "NUFUS_SIRA_NO", "53");
			iMap.put("KPS_BILGILERI", 0, "CINSIYET", "E");  iMap.put("KPS_BILGILERI", 0, "MEDENI_HAL", "1"); /* 1,2 */
			iMap.put("KPS_BILGILERI", 0, "KAYIP_KIMLIK_SIRA_NO", ""); iMap.put("KPS_BILGILERI", 0, "KAYIP_KIMLIK_SERI_NO", "");
			iMap.put("KPS_BILGILERI", 0, "NUFUS_VERILIS_TARIHI", "20100902"); iMap.put("KPS_BILGILERI", 0, "NUFUS_VERILIS_NEDENI", "Yenileme");
			iMap.put("KPS_BILGILERI", 0, "NUFUS_VERILDIGI_YER", "Sel�uklu"); iMap.put("KPS_BILGILERI", 0, "KIMLIK_KAYIT_NO", "");
			
			iMap.put("ADRES_BILGILERI", 0, "EV_ADRES", "�VG� SK. No : 7D/1 ERENK�Y MAH. SEL�UKLU KONYA"); 
			iMap.put("ADRES_BILGILERI", 0, "EV_ADR_IL_KOD", "042");
			iMap.put("ADRES_BILGILERI", 0, "EV_ADR_ILCE_KOD", "1839"); 
			iMap.put("ADRES_BILGILERI", 0, "EV_POSTAKOD", ""); 
			iMap.put("ADRES_BILGILERI", 0, "F_APS", "E");
			
			iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMI_YAPAN_KULLANICI", "452617");
			iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMI_YAPAN_KULLANICI_SICIL", "254860");
			iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMIN_YAPILDIGI_SUBE_ID", "1048");
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_BONO_MUSTERI_BASVURU", iMap);
			assertValidResponse(map);
			
			System.out.println(map.toString());
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprClksBonoMusteriSorgulama() {
		
		try {
			
			GMMap iMap = new GMMap();
			iMap.put("TC_KIMLIK_NO", "26960226250"); // 12616721590
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_BONO_MUSTERI_SORGULAMA", iMap);
			assertValidResponse(map);
			
			System.out.println(map.toString());
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprClksBonoMusteriBasvuruBelgeBilgileri() {
		
		try {
			
			String nullVal = null;
			
			
			GMMap iMap = new GMMap();
			//iMap.put("TRX_NO", "35819323");
			iMap.put("TC_KIMLIK_NO", "37318330390");
			iMap.put("YATIRIM_EKSTRE", nullVal);
			iMap.put("EMAIL", nullVal);
			
			iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMI_YAPAN_KULLANICI", "452617");
			iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMI_YAPAN_KULLANICI_SICIL", "254860");
			iMap.put("ISYERI_VE_KULLANICI_BILGILERI", 0,  "ISLEMIN_YAPILDIGI_SUBE_ID", "1048");
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_BILGILERI", iMap);
			assertValidResponse(map);
			
			System.out.println(map.toString());
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprClksBonoMusteriBasvuruBelgeOnay() {
		
		try {
			
			GMMap iMap = new GMMap();
			iMap.put("TRX_NO", "35819323");
			iMap.put("BELGE_LISTESI", 0, "BELGE_KODU", "2");
			iMap.put("BELGE_LISTESI", 0, "F_BELGE_TESLIM", "E");
			iMap.put("BELGE_LISTESI", 1, "BELGE_KODU", "545");
			iMap.put("BELGE_LISTESI", 1, "F_BELGE_TESLIM", "E");
			iMap.put("BELGE_LISTESI", 1, "DATA", "44");
			iMap.put("BELGE_LISTESI", 2, "BELGE_KODU", "565");
			iMap.put("BELGE_LISTESI", 2, "F_BELGE_TESLIM", "E");
			iMap.put("BELGE_LISTESI", 2, "DATA", "44");
			iMap.put("BELGE_LISTESI", 3, "BELGE_KODU", "569");
			iMap.put("BELGE_LISTESI", 3, "F_BELGE_TESLIM", "E");
			iMap.put("BELGE_LISTESI", 3, "DATA", "44");
			iMap.put("BELGE_LISTESI", 4, "BELGE_KODU", "566");
			iMap.put("BELGE_LISTESI", 4, "F_BELGE_TESLIM", "E");
			iMap.put("BELGE_LISTESI", 4, "DATA", "44");
			iMap.put("BELGE_LISTESI", 5, "BELGE_KODU", "1105");
			iMap.put("BELGE_LISTESI", 5, "F_BELGE_TESLIM", "E");
			iMap.put("BELGE_LISTESI", 5, "DATA", "44");
			iMap.put("BELGE_LISTESI", 6, "BELGE_KODU", "1108");
			iMap.put("BELGE_LISTESI", 6, "F_BELGE_TESLIM", "E");
			iMap.put("BELGE_LISTESI", 6, "DATA", "44");
			iMap.put("BELGE_LISTESI", 7, "BELGE_KODU", "-1");
			iMap.put("BELGE_LISTESI", 7, "F_BELGE_TESLIM", "E");
			iMap.put("BELGE_LISTESI", 7, "DATA", "44");
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_BONO_MUSTERI_BASVURU_BELGE_ONAY", iMap);
			assertValidResponse(map);
			
			System.out.println(map.toString());
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprTrn2050Save() {
		
		try {
			
			GMMap iMap = new GMMap();
			iMap.put("F_BONO_TALEP", true);
			iMap.put("BORCMUSTERINO", 1003289);
			iMap.put("CUSTOMER_ID", 1315347);
			iMap.put("TCNO", "72232131258");
			iMap.put("isleminYapildigiBasmudurluk", "034034");
			iMap.put("merkezSubeBasmudurluk", "S");
			iMap.put("BORCHESAPNO", 8856);
			iMap.put("ALICISUBE", 444);
			iMap.put("islemiyapankullaniciadsoyad", "Asd asd");
			iMap.put("DOVIZKODU", "TRY");
			iMap.put("AMOUNT_CODE", "TRY");
			iMap.put("kasaKimlikTipi", "1");
			iMap.put("DOVIZ_KOD", "TRY");
			iMap.put("ALICIHESAPNO", 203317);
			iMap.put("isleminYapildigiSube", "98");
			iMap.put("KARSI_HESAP_NO", 203317);
			iMap.put("TUTAR", 100);
			iMap.put("isleminYapildigiMerkez", "24999");
			iMap.put("ALICIMUSTERINO", 1315347);
			iMap.put("ISLEMSEKLI", "CLKSYTN");
			iMap.put("AMOUNT", 100);
			iMap.put("TUTAR_CODE", "TRY");
			iMap.put("isleminYapildigiIl", "003");
			iMap.put("MUSTERI_NO", 1315347);
			iMap.put("islem", 1);
			iMap.put("TRX_NO", 30727770);
			iMap.put("MASRAFTUTARI", 0);
			iMap.put("BONO_TALEP_TX", 30714037);
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_TRN2050_SAVE", iMap);
			assertValidResponse(map);
			
			System.out.println(map.toString());
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprClksBonoBarkodUret() {
		
		try {
			
			GMMap iMap = new GMMap();
			//iMap.put("REFERANS", 9200);
			iMap.put("TC_KIMLIK_NO", "46057805724");
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_BONO_BARKOD_URET", iMap);
			assertValidResponse(map);
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprTrn4801GetInfo() {
		
		try {
			
			GMMap iMap = new GMMap();
			iMap.put("BARCODE_NO", "2680088003469");
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_TRN4801_GET_INFO", iMap);
			assertValidResponse(map);
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testMusteriGrupAt() {
		
		try {
			
			GMMap iMap = new GMMap();
			iMap.put("MUSTERI_NO", 1321334);
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_BONO_MUSTERI_GRUP_KOD_AT", iMap);
			assertValidResponse(map);
		} catch(Exception e) {
			fail(e.getMessage());
		}
		
	}
}
