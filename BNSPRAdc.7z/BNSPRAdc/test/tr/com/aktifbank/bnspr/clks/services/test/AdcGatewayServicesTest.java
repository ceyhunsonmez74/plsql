package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class AdcGatewayServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}

	@Test
	public void emptyInput() {
		
		String message = "Service not found";
		
		try {
			this.getConn().serviceCall("ADC_SERVICE_GATEWAY", new GMMap());
		}
		catch(Exception e) {
			assertEquals(message, e.getMessage().substring(0, message.length()));
		}
	}
	
	@Test
	public void invalidServiceCall() {
		
		GMMap iMap = new GMMap();
		String message = "Service not found", serviceName = "INSTALLMENT_LOAN", channel = "UPT";
		
		try {
			
			iMap.put("GP_CHANNEL", channel);
			iMap.put("GP_SERVICE_NAME", serviceName);
			this.getConn().serviceCall("ADC_SERVICE_GATEWAY", iMap);
		}
		catch(Exception e) {
			assertEquals(message.concat(" : ").concat(channel).concat("_").concat(serviceName), e.getMessage());
		}
	}
}
