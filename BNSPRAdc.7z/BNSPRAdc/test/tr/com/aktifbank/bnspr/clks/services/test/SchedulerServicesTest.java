package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class SchedulerServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}

	private GMMap testClksReconciliationAutomationAfterRemoteCallMap;
	private GMMap testClksReconciliationAutomationMap;
	
	@Test
	public void testClksEftApprovalAutomation() {
		
		try {
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_EFT_APPROVAL_AUTOMATION", new GMMap());
			assertValidResponse(map);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testClksReconciliationAutomation() {
		
		testClksReconciliationAutomationMap = new GMMap();
		// testClksReconciliationAutomationMap.put("TARIH", "20140924");
		testClksReconciliationAutomationMap.put("TARIH", "20170908");
		
		try {
			
			Map<?,?> map = this.getConn().serviceCall("CLKS_RECONCILIATION_AUTOMATION", testClksReconciliationAutomationMap);
			assertValidResponse(map);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testClksReconciliationAutomationAfterRemoteCall() {
		
		try {
			testClksReconciliationAutomationAfterRemoteCallMap = new GMMap();
			testClksReconciliationAutomationAfterRemoteCallMap.put("TX_NO", new BigDecimal(153403064));
			testClksReconciliationAutomationAfterRemoteCallMap.put("RETRY_COUNT", new BigDecimal(5));
			testClksReconciliationAutomationAfterRemoteCallMap.put("STATUS_VENDOR", "2");
			
			Map<?,?> map = this.getConn().serviceCall("CLKS_RECONCILIATION_AUTOMATION_AFTER_REMOTE_CALL", testClksReconciliationAutomationAfterRemoteCallMap);
			assertValidResponse(map);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
}
