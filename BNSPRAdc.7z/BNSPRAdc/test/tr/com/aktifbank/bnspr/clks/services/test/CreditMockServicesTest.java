package tr.com.aktifbank.bnspr.clks.services.test;

import static org.hamcrest.core.StringContains.containsString;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.graymound.util.GMMap;

public class CreditMockServicesTest extends BaseTest {
	
	@Rule
	public final ExpectedException thrown = ExpectedException.none();
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}
	
	@Test
	public void Should_ReturnDefaultData_When_NewIdentityGiven() {
		
		GMMap iMap = new GMMap();
		iMap.put("NATIONAL_IDENTITY_NUMBER", "21277633562");
		
		try {
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_MOCK_SGK_PENSION_DATA", iMap);
			assertTrue(map.containsKey("SGK_AYLIK_BILGILERI"));
			assertTrue(map.containsKey("SGK_SONUC_KODU"));
			assertTrue(map.containsKey("SGK_SONUC_ACIKLAMA"));
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}

}
