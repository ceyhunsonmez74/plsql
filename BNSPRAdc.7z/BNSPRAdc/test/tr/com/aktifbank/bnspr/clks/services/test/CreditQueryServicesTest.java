package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class CreditQueryServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}

	@Test
	public void testBnsprClksKrediBasvuruDurumSorgu() {

		try {

			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_KREDI_BASVURU_DURUM_SORGU", new GMMap().put("BASVURU", 0, "BASVURU_NO", 16053));
			assertValidResponse(map);
			assertNotNull("map.get(\"BASVURU\") is <null> but expected a list.", map.get("BASVURU"));
		}
		catch(Exception e) {
			fail(e.getMessage());
		}
	}
}
