package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class CreditPaymentServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}

	@Test
	public void testClksCreditPaymentConsolidationInfo() {

		try {

			Map<?, ?> map = this.getConn().serviceCall("CLKS_CREDIT_PAYMENT_CONSOLIDATION_INFO", new GMMap().put("ISLEM_NO", 27834239));
			assertValidResponse(map);
			System.out.println(map.toString());
		}
		catch(Exception e) {
			fail(e.getMessage());
		}
	}	
	
	@Test
	public void testInstallmentLoanPayment() {

		try {

			Map<?, ?> map = this.getConn().serviceCall("CLKS_CREDIT_PAYMENT_APPROVAL", new GMMap().put("ISLEM_NO", 27834239));
			assertValidResponse(map);
			System.out.println(map.toString());
		}
		catch(Exception e) {
			fail(e.getMessage());
		}
	}
}
