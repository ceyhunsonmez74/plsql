package tr.com.aktifbank.bnspr.clks.services.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.graymound.util.GMMap;

public class CreditServicesTest extends BaseTest {
	
	@BeforeClass
	public static void establishConnection() {
		BaseTest.establishConnection();
	}
	
	@Test
	public void testClksPttPaymentPlanRequestInfo() {
		
		GMMap iMap = new GMMap();
		iMap.put("BASVURU_NO", 9754336);
		
		try {
			
			Map<?,?> map = this.getConn().serviceCall("CLKS_PTT_PAYMENT_PLAN_REQUEST_INFO", iMap);
			assertValidResponse(map);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprClksConsolidationLoanPrevalidation() {
		
		final int valStepPaymentCountCheck = 4;
		final int valStepYTCheck = 2;
		
		try {
			
			/*GMMap input = new GMMap();
			input.put("INPUT", 0, "TCKN", "30361375806");
			input.put("INPUT", 1, "TCKN", "19541254988");
			
			for(int i = 0; i < input.getSize("INPUT"); i++) {
				Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_CONSOLIDATION_LOAN_PREVALIDATION", new GMMap().put("TCKN", input.getString("INPUT", i, "TCKN")));
				commonAssertion(map);
			}*/
			
			// Tahsilat Kontrol
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_CONSOLIDATION_LOAN_PREVALIDATION", new GMMap().put("TCKN", "19541254988"));
			assertValidResponse(map);
			if(valStepPaymentCountCheck == Integer.valueOf(((String) map.get("VALSTEP"))).intValue()) {
				assertEquals("'Yasal Takip' check assertion failed.", 0, Integer.valueOf(((String) map.get("islemSonuc"))).intValue());
			}
			
			// Yasal Takip Kontrol
			map = this.getConn().serviceCall("BNSPR_CLKS_CONSOLIDATION_LOAN_PREVALIDATION", new GMMap().put("TCKN", "30361375806"));
			assertValidResponse(map);
			if(valStepYTCheck == Integer.valueOf(((String) map.get("VALSTEP"))).intValue()) {
				assertEquals("'Yasal Takip' check assertion failed.", 0, Integer.valueOf(((String) map.get("islemSonuc"))).intValue());
			}
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testClksPTTKampTutarVadeUyumlumu() {
		
		try {
			
			GMMap testMap = new GMMap();
			int index = 0;
			String list = "LIST";
			
			testMap.put(list, index, "URUN_KAMP_KOD", 561);
			testMap.put(list, index, "TUTAR", 500);
			testMap.put(list, index, "TUTAR", 500);
			
			this.getConn().serviceCall("CLKS_PTT_KAMP_VADE_TUTAR_UYUMLUMU", null);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprClksUnpaidCreditStatusUpdate() {
		
		GMMap iMap = new GMMap();
		iMap.put("TX_NO", 30493176);
		iMap.put("BASVURU_NO", 9778608);
		
		try {
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_UNPAID_CREDIT_STATUS_UPDATE", iMap);
			assertValidResponse(map);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void testBnsprClksUnpaidCreditControl() {
		
		GMMap iMap = new GMMap();
		iMap.put("TC_KIMLIK_NO", "16376671928");
		
		try {
			
			Map<?,?> map = this.getConn().serviceCall("BNSPR_CLKS_UNPAID_CREDIT_CONTROL", iMap);
			assertValidResponse(map);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	public void testClksPttKrediFirstInitial() {

		GMMap iMap = new GMMap();
		String nullVal = null;

		iMap.put("URUN_KAMP_KOD", "366");
		iMap.put("NUF_VERILDIGI_YER", "Be�ikta�");
		iMap.put("POSTA_CEK_HESABI", nullVal);
		iMap.put("PTT_UNVAN_KOD", nullVal);
		iMap.put("PASS_TIME_LIMIT", true);
		iMap.put("PASS_EXECUTION", false);
		iMap.put("MEDENI_HAL", 2);
		iMap.put("NUFUS_IL_KOD", 034);
		iMap.put("ISLEMIN_YAPILDIGI_BASMUDURLUK", 65102);
		iMap.put("KAMP_KNL_KOD", "117355978");
		iMap.put("NUF_VERILIS_NEDENI", "De�i�tirme");
		iMap.put("EK_DOKUMAN", 101);
		iMap.put("PASS_QUANTITY_LIMIT", true);
		iMap.put("KRD_TUR_KOD", 1);
		iMap.put("CONTROL_MASK", 1);
		iMap.put("BASVURU_NO", nullVal);
		iMap.put("CINSIYET", "K");
		iMap.put("F_GIRIS", true);
		iMap.put("URUN_NO", nullVal);
		iMap.put("KAMP_URUN_ADI", 366);
		iMap.put("TC_KIMLIK_NO", "31825044412");
		iMap.put("KIMLIK_SERI_NO", "K02");
		iMap.put("SESSION_IP", nullVal);
		iMap.put("BABA_ADI", "G�NE�");
		iMap.put("NUFUS_VERILIS_TARIHI", "20000101");
		iMap.put("NUFUS_SIRA_NO", "999");
		iMap.put("SGK_SONUC_KODU", nullVal);
		iMap.put("PASS_AMOUNT_LIMIT", true);
		iMap.put("CEP_TEL_VALIDASYON", true);
		iMap.put("DOVIZ_KODU", "TRY");
		iMap.put("VADE", 48);
		iMap.put("PASS_SERVICE_EXECUTION", false);
		iMap.put("UYRUK", nullVal);
		iMap.put("HESAP_KAPANSIN_MI", nullVal);
		iMap.put("KIMLIK_SIRA_NO_KPS", "123456");
		iMap.put("KAMP_KOD", "366");
		iMap.put("ISLEMIN_YAPILDIGI_IL", "065");
		iMap.put("KPS_YAPILDI", "E");
		iMap.put("NUFUS_AILE_SIRA_NO", "99");
		iMap.put("ADI", "DEN�Z");
		iMap.put("EKRAN_NO", "3171");
		iMap.put("KAYIP_CUZDAN_NO", nullVal);
		iMap.put("CALISMA_SEKLI", "E");
		iMap.put("MERKEZ_SUBE_BASMUDURLUK", "M");
		iMap.put("NUFUS_CILT_NO", "34");
		iMap.put("DOGUM_TARIHI", "19871021");
		iMap.put("ISLEM_NO_BANKA", nullVal);
		iMap.put("KIMLIK_KAYIT_NO", nullVal);
		iMap.put("F_KONSOLIDASYON_KREDISI", false);
		iMap.put("KIMLIK_SERI_NO_KPS", "K02");
		iMap.put("KREDI_TURU", 1);
		iMap.put("ISLEMIN_YAPILDIGI_MERKEZ", 11221);
		iMap.put("KIMLIK_SIRA_NO", "123456");
		iMap.put("KAYIP_CUZDAN_SERI", nullVal);
		iMap.put("URUN_MIKTAR", nullVal);
		iMap.put("SGK_SONUC_ACIKLAMA", nullVal);
		iMap.put("NUFUS_ILCE_KOD", 1183);
		iMap.put("PASS_CUSTOMER_AMOUNT_LIMIT", true);
		iMap.put("DOGUM_YERI", "BE��KTA�");
		iMap.put("ANNE_KIZLIK_SOYADI", "TEST");
		iMap.put("DOVIZ_KOD", "TRY");
		iMap.put("SOYADI", "KUM");
		iMap.put("PROCESS_CODE", "CLKS-KRKUL");
		iMap.put("NUFUS_MAHALLE", "BE��KTA�");
		iMap.put("GUNCELLEMEMI", "H");
		iMap.put("KRD_TUR_ALT_KOD", nullVal);
		iMap.put("MASK", 1);
		iMap.put("TUTAR", 5000.00);
		iMap.put("ISLEMIN_YAPILDIGI_YER", "VAN/VAN /VAN");
		iMap.put("CEP_TEL_NO", "8778878");
		iMap.put("KANAL_KOD", 7);
		iMap.put("ISLEMI_YAPANKULLANICI_ADSOYAD", "AKTIF BANK");
		iMap.put("ISLEMI_YAPAN_KULLANICI", "777669");
		iMap.put("CEP_TEL_KOD", "505");
		iMap.put("IKINCI_ADI", nullVal);
		iMap.put("ANNE_ADI", "YAZ");
		iMap.put("KANAL_KODU", 7);
		iMap.put("PASS_FRAUD_LIMIT", true);
		iMap.put("SIGORTALIMI", "E");
		iMap.put("ISLEMIN_YAPILDIGI_SUBE", 1);

		iMap.put("MAAS_BILGILERI", 0, "ONCEKI_MAAS_ODEME_TARIHI", "20180329");
		iMap.put("MAAS_BILGILERI", 0, "UNVANI", nullVal);
		iMap.put("MAAS_BILGILERI", 0, "MAAS_PTT_DENMI", "E");
		iMap.put("MAAS_BILGILERI", 0, "EMEKLI_MAAS_EVDENMI", "H");
		iMap.put("MAAS_BILGILERI", 0, "EMEKLI_MAAS_DONEM", "201803");
		iMap.put("MAAS_BILGILERI", 0, "KURUM_DONEM", "201803");
		iMap.put("MAAS_BILGILERI", 0, "MAAS_TUTARI", 1663.33);
		iMap.put("MAAS_BILGILERI", 0, "ILK_MAAS_TARIHI", "20170328");
		iMap.put("MAAS_BILGILERI", 0, "SON_MAAS_TARIHI", "20180328");
		iMap.put("MAAS_BILGILERI", 0, "TAHSIS_NUMARASI", "04371724022000");
		iMap.put("MAAS_BILGILERI", 0, "MAAS_ALINAN_KURUM", "211");
		iMap.put("MAAS_BILGILERI", 0, "MAAS_TARIH_SIKLIGI", nullVal);
		iMap.put("MAAS_BILGILERI", 1, "ONCEKI_MAAS_ODEME_TARIHI", "20180228");
		iMap.put("MAAS_BILGILERI", 1, "UNVANI", nullVal);
		iMap.put("MAAS_BILGILERI", 1, "MAAS_PTT_DENMI", "E");
		iMap.put("MAAS_BILGILERI", 1, "EMEKLI_MAAS_EVDENMI", "H");
		iMap.put("MAAS_BILGILERI", 1, "EMEKLI_MAAS_DONEM", "201802");
		iMap.put("MAAS_BILGILERI", 1, "KURUM_DONEM", "201803");
		iMap.put("MAAS_BILGILERI", 1, "MAAS_TUTARI", 1663.33);
		iMap.put("MAAS_BILGILERI", 1, "ILK_MAAS_TARIHI", "20170328");
		iMap.put("MAAS_BILGILERI", 1, "SON_MAAS_TARIHI", "20180228");
		iMap.put("MAAS_BILGILERI", 1, "TAHSIS_NUMARASI", "04371724022000");
		iMap.put("MAAS_BILGILERI", 1, "MAAS_ALINAN_KURUM", "211");
		iMap.put("MAAS_BILGILERI", 1, "MAAS_TARIH_SIKLIGI", nullVal);
		iMap.put("MAAS_BILGILERI", 2, "ONCEKI_MAAS_ODEME_TARIHI", "20180129");
		iMap.put("MAAS_BILGILERI", 2, "UNVANI", nullVal);
		iMap.put("MAAS_BILGILERI", 2, "MAAS_PTT_DENMI", "E");
		iMap.put("MAAS_BILGILERI", 2, "EMEKLI_MAAS_EVDENMI", "H");
		iMap.put("MAAS_BILGILERI", 2, "EMEKLI_MAAS_DONEM", "201801");
		iMap.put("MAAS_BILGILERI", 2, "KURUM_DONEM", "201803");
		iMap.put("MAAS_BILGILERI", 2, "MAAS_TUTARI", 1639.33);
		iMap.put("MAAS_BILGILERI", 2, "ILK_MAAS_TARIHI", "20170328");
		iMap.put("MAAS_BILGILERI", 2, "SON_MAAS_TARIHI", "20180129");
		iMap.put("MAAS_BILGILERI", 2, "TAHSIS_NUMARASI", "04371724022000");
		iMap.put("MAAS_BILGILERI", 2, "MAAS_ALINAN_KURUM", "211");
		iMap.put("MAAS_BILGILERI", 2, "MAAS_TARIH_SIKLIGI", nullVal);
		iMap.put("MAAS_BILGILERI", 3, "ONCEKI_MAAS_ODEME_TARIHI", "20171228");
		iMap.put("MAAS_BILGILERI", 3, "UNVANI", nullVal);
		iMap.put("MAAS_BILGILERI", 3, "MAAS_PTT_DENMI", "E");
		iMap.put("MAAS_BILGILERI", 3, "EMEKLI_MAAS_EVDENMI", "H");
		iMap.put("MAAS_BILGILERI", 3, "EMEKLI_MAAS_DONEM", "201712");
		iMap.put("MAAS_BILGILERI", 3, "KURUM_DONEM", "201803");
		iMap.put("MAAS_BILGILERI", 3, "MAAS_TUTARI", 1560.79);
		iMap.put("MAAS_BILGILERI", 3, "ILK_MAAS_TARIHI", "20170328");
		iMap.put("MAAS_BILGILERI", 3, "SON_MAAS_TARIHI", "20171228");
		iMap.put("MAAS_BILGILERI", 3, "TAHSIS_NUMARASI", "04371724022000");
		iMap.put("MAAS_BILGILERI", 3, "MAAS_ALINAN_KURUM", "211");
		iMap.put("MAAS_BILGILERI", 3, "MAAS_TARIH_SIKLIGI", nullVal);

		try {

			Map<?, ?> map = this.getConn().serviceCall("CLKS_PTT_KREDI_FIRST_INITIAL", iMap);
			assertValidResponse(map);

		}
		catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void sendDigitalDocumentWithoutProvidingApplicationNumber() {

		String message = "Alana giri� zorunludur";
		
		try {
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_SEND_DOCUMENTS", new GMMap());
			assertValidResponse(map);
		} catch (Exception e) {
			assertEquals(message, e.getMessage().substring(0, message.length()));
		}
	}
	
	@Test
	public void sendDigitalDocumentInvalidInput() {
		
		GMMap iMap = new GMMap();
		String message = "Arad���n�z kriterlere uygun kay�t bulunamad�";
		
		try {
			iMap.put("BASVURU_NO", "123456");
			iMap.put("ISLEM_NO_BANKA", 111111);
			iMap.put("MASK", "1");
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_SEND_DOCUMENTS", iMap);
			assertValidResponse(map);

		} catch (Exception e) {
			assertEquals(message, e.getMessage().substring(0, message.length()));
		}
	}
	
	@Test
	public void sendDigitalDocumentForApprovedCreditApplication() {

		GMMap iMap = new GMMap();
		
		try {
			
			iMap.put("BASVURU_NO", "9832813");
			iMap.put("ISLEM_NO_BANKA", 41282449);
			iMap.put("MASK", "1");
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_SEND_DOCUMENTS", iMap);
			System.out.println(map);
			assertValidResponse(map);

		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void sendDigitalDocumentForDeniedCreditApplication() {
		
		GMMap iMap = new GMMap();
		
		try {
			iMap.put("BASVURU_NO", "9832467");
			iMap.put("ISLEM_NO_BANKA", 41141425);
			iMap.put("MASK", "1");
			
			Map<?, ?> map = this.getConn().serviceCall("BNSPR_CLKS_CREDIT_SEND_DOCUMENTS", iMap);
			assertValidResponse(map);

		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	@Test
	public void getMissingDocumentContent() {
		GMMap iMap = new GMMap();
		
		try {
			iMap.put("BASVURU_NO", "9829945");
			
			Map<?, ?> map = this.getConn().serviceCall("CLKS_PTT_PAYMENT_PLAN_CONFIRM_INFO", iMap);
			assertValidResponse(map);
			
			System.out.println(map.toString());
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
}
