package tr.com.aktifbank.bnspr.upt.services.test;

import static junit.framework.Assert.fail;

import java.util.Map;

import tr.com.aktifbank.bnspr.clks.services.test.BaseTest;

import com.graymound.util.GMMap;

public class SchedulerServicesTest extends BaseTest {

	private GMMap map;
	
	public void testBnsprUptXAutomation() {
		
		map = new GMMap();
		map.put("TARIH", "20171012");
		
		try {
			
			Map<?,?> oMap = this.getConn().serviceCall("BNSPR_UPT_REFUND_NOTIFICATION_AUTOMATION", map);
			assertValidResponse(oMap);
			
		} catch(Exception e) {
			fail(e.getMessage());
		}
	}
}
