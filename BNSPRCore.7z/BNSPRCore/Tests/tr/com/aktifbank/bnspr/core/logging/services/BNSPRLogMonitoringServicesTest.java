package tr.com.aktifbank.bnspr.core.logging.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.graymound.connection.GMConnection;
import com.graymound.connection.GMConnectionPool;
import com.graymound.message.GMMessageFactory;


public class BNSPRLogMonitoringServicesTest {
	private String logOid = "8ada8bba2037174b012037503d440024";
	private String urlAddress = "http://localhost:8180/GMServer/Server/JAVA";
	
	@Test
	public final void testGetChannelList() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		GMConnection conn = null;
		try {
			conn = new GMConnection(new GMConnectionPool(new URL(urlAddress)),false);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		Map<?, ?> oMap = null;
		try {
			
			iMap.put("USERNAME", "BNSPR");
			iMap.put("PASSWORD", "ATA1234");
			iMap.put("LANGUAGE", "tr");
			iMap.put("CHANNEL", "");
			oMap = conn.serviceCall("BNSPR_USER_AUTHENTICATE", iMap);
			iMap.clear();
			iMap.put("PHONE_NUMBER", "4654646546");
			oMap = conn.serviceCall("ADC_MAN_USER_OTP_CREATE", iMap);
		} catch (IOException e) {
			fail("Eror when calling service");
		}
		List<?> list = (List<?>) oMap.get("CHANNEL_LIST");
		Iterator<?> iter = list.iterator();
		int rowCnt = 0;
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("0", rowData.get("OID"));
			assertEquals("Se�iniz", rowData.get("NAME"));
			assertEquals("NONE", rowData.get("CODE"));
		}
		while (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			rowCnt++;
		}
		if (rowCnt<2){
			fail("Not yet implemented");
		}
	}

	@Test
	public final void testGetProcessList() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		GMConnection conn = null;
		try {
			conn = new GMConnection(new GMConnectionPool(new URL("http://localhost:8180/GMServer/Server/JAVA")),false);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		Map<?, ?> oMap = null;
		try {
			
			iMap.put("USERNAME", "BNSPR");
			iMap.put("PASSWORD", "ATA1234");
			iMap.put("LANGUAGE", "tr");
			iMap.put("CHANNEL", "IVR");
			oMap = conn.serviceCall("BNSPR_USER_AUTHENTICATE", iMap);
			iMap.clear();
			iMap.put("PROCESS_TYPE", "1");
			oMap = conn.serviceCall("GET_ADC_PROCESS_LIST", iMap);
		} catch (IOException e) {
			fail("Eror when calling service");
		}
		List<?> list = (List<?>) oMap.get("PROCESS_LIST");
		Iterator<?> iter = list.iterator();
		int rowCnt = 0;
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("0", rowData.get("OID"));
			assertEquals(true, rowData.get("NAME").toString().length()>0);
			assertEquals("NONE", rowData.get("CODE"));
		}
		while (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			rowCnt++;
		}
		if (rowCnt<2){
			fail("Not all processes listed.");
		}
	}

	@Test
	public final void testGetProcessTypeList() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		GMConnection conn = null;
		try {
			conn = new GMConnection(new GMConnectionPool(new URL("http://localhost:8180/GMServer/Server/JAVA")),false);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		Map<?, ?> oMap = null;
		try {
			
			iMap.put("USERNAME", "BNSPR");
			iMap.put("PASSWORD", "ATA1234");
			iMap.put("LANGUAGE", "tr");
			iMap.put("CHANNEL", "");
			oMap = conn.serviceCall("BNSPR_USER_AUTHENTICATE", iMap);
			iMap.clear();
			oMap = conn.serviceCall("GET_ADC_PROCESS_TYPE_LIST", iMap);
		} catch (IOException e) {
			fail("Eror when calling service");
		}
		List<?> list = (List<?>) oMap.get("PROCESS_TYPE_LIST");
		Iterator<?> iter = list.iterator();
		int rowCnt = 0;
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("NONE", rowData.get("OID"));
			assertEquals("Se�iniz", rowData.get("NAME"));
			assertEquals("NONE", rowData.get("CODE"));
		}
		while (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			rowCnt++;
		}
		if (rowCnt<2){
			fail("Not yet implemented");
		}
	}

	@Test 
	public final void testGetLogStatusList() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		GMConnection conn = null;
		try {
			conn = new GMConnection(new GMConnectionPool(new URL("http://localhost:8180/GMServer/Server/JAVA")),false);
		} catch (MalformedURLException e) {
			fail("Can not get connection.");
		}
		Map<?, ?> oMap = null;
		try {
			
			iMap.put("USERNAME", "BNSPR");
			iMap.put("PASSWORD", "ATA1234");
			iMap.put("LANGUAGE", "tr");
			iMap.put("CHANNEL", "");
			oMap = conn.serviceCall("BNSPR_USER_AUTHENTICATE", iMap);
			iMap.clear();
			oMap = conn.serviceCall("GET_ADC_LOG_STATUS_LIST", iMap);
		} catch (IOException e) {
			fail("Eror when calling service");
		}
		List<?> list = (List<?>) oMap.get("STATUS_LIST");
		Iterator<?> iter = list.iterator();
		int rowCnt = 0;
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("1", rowData.get("OID"));
			assertEquals("T�m�", rowData.get("NAME"));
			assertEquals("1", rowData.get("CODE"));
		}
		while (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			rowCnt++;
		}
		if (rowCnt<2){
			fail("Not yet implemented");
		}
	}

	@Test
	public final void testFillLogDetail() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		GMConnection conn = null;
		try {
			conn = new GMConnection(new GMConnectionPool(new URL("http://localhost:8180/GMServer/Server/JAVA")),false);
		} catch (MalformedURLException e) {
			fail("Can not get connection.");
		}
		Map<?, ?> oMap = null;
		try {
			
			iMap.put("USERNAME", "BNSPR");
			iMap.put("PASSWORD", "ATA1234");
			iMap.put("LANGUAGE", "tr");
			iMap.put("CHANNEL", "");
			oMap = conn.serviceCall("BNSPR_USER_AUTHENTICATE", iMap);
			iMap.clear();
			iMap.put("LOG_OID", logOid);
			oMap = conn.serviceCall("FILL_LOG_DETAIL", iMap);
		} catch (IOException e) {
			fail("Eror when calling service");
		}
		List<?> list = (List<?>) oMap.get("LIST");
		Iterator<?> iter = list.iterator();
		int rowCnt = 0;
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals(true, rowData.get("colAttributeName")!=null);
			assertEquals(true, rowData.get("colAttributeValue")!=null);
		}
		if (oMap.size()<2){
			fail("Not yet implemented");
		}
	}

	@Test
	public final void testGetLog() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		GMConnection conn = null;
		try {
			conn = new GMConnection(new GMConnectionPool(new URL("http://localhost:8180/GMServer/Server/JAVA")),false);
		} catch (MalformedURLException e) {
			fail("Can not get connection.");
		}
		Map<?, ?> oMap = null;
		try {
			
			iMap.put("USERNAME", "BNSPR");
			iMap.put("PASSWORD", "ATA1234");
			iMap.put("LANGUAGE", "tr");
			iMap.put("CHANNEL", "");
			oMap = conn.serviceCall("BNSPR_USER_AUTHENTICATE", iMap);
			iMap.clear();
			iMap.put("START_DATE", new GregorianCalendar(2009,1,1).getTime());
			iMap.put("END_DATE", new GregorianCalendar(2009,3,1).getTime());
			oMap = conn.serviceCall("GET_ADC_PROCESS_LOG", iMap);
		} catch (IOException e) {
			fail("Eror when calling service");
		}
		List<?> list = (List<?>) oMap.get("LOG_LIST");
		Iterator<?> iter = list.iterator();
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals(true, rowData.get("colStartDate")!=null);
			assertEquals(true, rowData.get("colSurname")!=null);
			assertEquals(true, rowData.get("colChannel")!=null);
			assertEquals(true, rowData.get("colStatus")!=null);
			assertEquals(true, rowData.get("colProcess")!=null);
			assertEquals(true, rowData.get("colLogOid")!=null);
			assertEquals(true, rowData.get("colName")!=null);
			assertEquals(true, rowData.get("colUsername")!=null);
			assertEquals(true, rowData.get("colLogOid")!=null);
			//this.logOid = (String) rowData.get("colLogOid");
		}
		
		if (oMap.size()<2){
			fail("Not enough rows returned!");
		}
	}

	@Test
	public final void testGetReferenceDataValue() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testInitialize() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGuimlLogService() {
		fail("Not yet implemented"); // TODO
	}

}
