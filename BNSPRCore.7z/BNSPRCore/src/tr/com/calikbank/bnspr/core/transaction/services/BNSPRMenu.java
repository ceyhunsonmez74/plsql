package tr.com.calikbank.bnspr.core.transaction.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.GnlKullNot;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.core.util.CoreUtil;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class BNSPRMenu {
    @GraymoundService("BNSPR_GET_USER_NOTE")
    public static GMMap getNote(GMMap iMap){
        try {
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");

            GnlKullNot kn = (GnlKullNot) session.get(GnlKullNot.class, iMap.getString("KULLANICI_KOD"));

            return oMap.put("NOTE", kn==null?null:kn.getNote());
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    @GraymoundService("BNSPR_SAVE_USER_NOTE")
    public static GMMap saveNote(GMMap iMap){
        try {
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");

            GnlKullNot kn = (GnlKullNot) session.get(GnlKullNot.class, iMap.getString("KULLANICI_KOD"));
            if (kn==null) {
                kn = new GnlKullNot();
                kn.setKullKod(iMap.getString("KULLANICI_KOD"));
            }

            kn.setNote(iMap.getString("NOTE"));
            session.saveOrUpdate(kn);

            return oMap.put("MESSAGE", GMMessageFactory.getMessage("OPSUCC", (GMMap) null));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    @GraymoundService("BNSPR_GET_SUBE_LIST")
    public static GMMap getSubeList(GMMap iMap){
        Connection          conn = null;
        CallableStatement   stmt = null;
        ResultSet rset = null;
        try { 
            
            GMMap oMap = new GMMap();
            conn    = DALUtil.getGMConnection();
            StringBuffer query = new StringBuffer();
            query.append("select a.sube_kodu, b.sube_adi ");
            query.append("from gnl_erisim a, gnl_sube_kod_pr b ");
            query.append("where a.kullanici_kodu = PKG_GLOBAL.GET_KULLANICIKOD ");
            query.append("and  a.sube_kodu = b.kod ");
            query.append("and ( pkg_muhasebe.Banka_Tarihi_Bul >= a.baslangic_tarihi OR a.baslangic_tarihi is null) ");
            query.append("and  a.sube_kodu = b.kod ");
            query.append("and ( pkg_muhasebe.Banka_Tarihi_Bul < a.bitis_tarihi OR a.bitis_tarihi is null)");
            
            stmt    = conn.prepareCall(query.toString());

            rset = stmt.executeQuery();
            
            DALUtil.fillComboBox(oMap, "SUBE_LIST", false, rset);
            return oMap;
        } catch (SQLException e) {
            throw new GMRuntimeException(0,e);
        } finally {
            GMServerDatasource.close(rset);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	
	@GraymoundService("BNSPR_GET_ROL_LIST")
	public static GMMap getRolList(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		ResultSet 			rset = null;
		try {
			GMMap oMap = new GMMap();
			conn	= DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer();
			query.append("Select c.rol_numara, d.tanim ");
			query.append("from gnl_erisim_rol c,gnl_rol d ");
			query.append("where c.rol_numara = d.numara ");
			query.append("and c.erisim_kullanici_kodu = PKG_GLOBAL.GET_KULLANICIKOD ");
			query.append("and pkg_muhasebe.Banka_Tarihi_Bul between NVL(c.BASLANGIC_TARIHI,pkg_muhasebe.Banka_Tarihi_Bul) AND NVL(c.BITIS_TARIHI,pkg_muhasebe.Banka_Tarihi_Bul)  ");
			query.append("and c.sube_kodu = ? and pkg_muhasebe.Banka_Tarihi_Bul between NVL(d.BASLANGIC_TARIHI,pkg_muhasebe.Banka_Tarihi_Bul) AND NVL(d.BITIS_TARIHI,pkg_muhasebe.Banka_Tarihi_Bul) ");
			if ("E".equals(iMap.getString("F_AKUSTIK"))) 
     			query.append("and d.s_k='1' ");
			else
				query.append("and d.s_k!='2' ");
			query.append("order by c.rol_numara");
			stmt = conn.prepareCall(query.toString());
			stmt.setString(1, iMap.getString("SUBE_KODU"));		
			rset = stmt.executeQuery();
			DALUtil.fillComboBox(oMap, "ROL_LIST", false, rset);
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0,e);
		} finally {
			GMServerDatasource.close(rset);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_SET_BRANCH_ROLE")
	public static GMMap setBranchRole(GMMap iMap){
		
		Connection			conn = null;
		CallableStatement	stmt = null;
		try {
			
			GMContext.getCurrentContext().getSession().put("ROLE_ID", iMap.getString("ROLE_ID"));
			GMContext.getCurrentContext().getSession().put("BRANCH_ID", iMap.getString("BRANCH_ID"));

			BnsprCommonFunctions.setUserGlobals2();
			
			GMMap oMap = new GMMap();
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0,e);
		} finally {
			
			GMMap logMap = new GMMap();
			logMap.put("ROLE_CODE", iMap.getString("ROLE_ID", ""));
			logMap.put("BRANCH_ID", iMap.getString("BRANCH_ID", ""));
			logMap.put("GUIML_NAME", iMap.getString("GUIML_NAME", ""));
			GMServiceExecuter.execute("BNSPR_CORE_APP_USER_BRANCH_LOG", logMap);
			
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService(value="BNSPR_CORE_GET_SISTEM_ADI",authenticationRequired=false)
	public static GMMap getSistemAdi(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn	= DALUtil.getGMConnection();
			stmt	= conn.prepareCall("{? = call pkg_genel_pr.sistem_adi_getir}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			oMap.put("SISTEM_ADI", stmt.getString(1));
			oMap.put("SISTEM", CoreUtil.getEnvironment());		
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(0,e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_CORE_GET_DATABASE_ADI")
	public static GMMap getDatabaseAdi(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn	= DALUtil.getGMConnection();
			stmt	= conn.prepareCall("{? = call pkg_genel_pr.database_adi}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			oMap.put("DATABASE_ADI", stmt.getString(1));
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(0,e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	 
}
