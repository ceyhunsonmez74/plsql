package tr.com.calikbank.bnspr.core.transaction.services;

import com.graymound.util.GMMap;

public interface MappingStrategy{
	void doMapping(GMMap oMap, Object pojo, String tableName, int row);
}
