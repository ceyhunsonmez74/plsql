package tr.com.calikbank.bnspr.core.transaction;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import tr.com.obss.adc.core.services.transaction.ServiceExecuter;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.connection.GMConnection;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMToolkit;

public class BNSPRServiceExecuterForRemoteCall extends
		ServiceExecuter {

    private static String CONNECTION;

    private static Logger   log = Logger.getLogger("servicelog");
    
    static {
        try {
            InputStream inputStream = GMServiceExecuter.class.getResourceAsStream("/configuration/GMServiceConfiguration.xml");
            if(inputStream != null) {
                GMToolkit.parseSAX(inputStream, new Handler());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class Handler extends DefaultHandler{
        
        /* (non-Javadoc)
         * @see org.xml.sax.helpers.DefaultHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
         */
        @Override
        public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
            if ("service-executer".equals(name)) {
                CONNECTION = attributes.getValue("connection");
                
                if (CONNECTION == null) {
                    log.error("Unable to find 'connection' in GMServiceConfiguration.xml");
                }
            }
        }
    }
    
	protected GMMap remoteCall(String serviceName, GMMap map) {
        Date start = new Date();
        GMMap oMap = new GMMap();
        GMConnection connection = null;

        try {
            if (log.isDebugEnabled()) {
                log.debug("StartService sessionID="
                        + GMContext.getCurrentContext().getSession().getId()
                        + " serviceName=" + serviceName + " MAP="
                        + (map == null ? "NULL" : map.toString()));
            } else if (log.isInfoEnabled()) {
                log.info("StartService sessionID="
                        + GMContext.getCurrentContext().getSession().getId()
                        + " serviceName=" + serviceName);
            }
            
            String channel = ADCSession.getString("CHANNEL", "");
            connection = GMConnection.getConnection(CONNECTION + channel);

            oMap.putAll(connection.serviceCall(serviceName, map));

            return oMap;

        } catch (IOException e) {
            e.printStackTrace ();
            throw new com.graymound.util.GMRuntimeException(101,
                    GMMessageFactory.getMessage("CONNFAIL", new GMMap()), true);
        } finally {
            Date finish = new Date();
            long execTime = finish.getTime() - start.getTime();
            if (log.isDebugEnabled()) {
                log.debug("FinishService sessionID="
                        + GMContext.getCurrentContext().getSession().getId()
                        + " serviceName=" + serviceName + " duration="
                        + execTime + " MAP="
                        + (oMap == null ? "NULL" : oMap.toString()));
            } else if (log.isInfoEnabled()) {
                log.info("FinishService sessionID="
                        + GMContext.getCurrentContext().getSession().getId()
                        + " serviceName=" + serviceName + " duration="
                        + execTime);
            }
            
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception ex) {

            }
        }
    }

	@Override
	protected GMMap callService(String serviceName, GMMap map) {
		GMMap oMap = null;
        GMService service = getService(serviceName);
        if (service == null) {
            oMap = remoteCall(serviceName, map);
        } else {
            oMap = super.callService(serviceName, map);
        }
		return oMap;
	}

	@Override
	protected Map<?, ?> executeService(String serviceName, Map<?, ?> map) {
	    Map<?, ?> oMap = null;
		GMService service = getService(serviceName);
		if (service == null) {
		    oMap = remoteExecute(serviceName, map);
		} else {
		    oMap = super.executeService(serviceName, map);
		}
		return oMap;
	}
    
    protected Map<?, ?> remoteExecute(String serviceName, Map<?, ?> map) {
        Map<?, ?> oMap = null;
        Date start = new Date();
        GMConnection connection = null;
        try {
            if (log.isDebugEnabled()) {
                log.debug("StartService sessionID="
                        + GMContext.getCurrentContext().getSession().getId()
                        + " serviceName=" + serviceName + " MAP="
                        + (map == null ? "NULL" : map.toString()));
            } else if (log.isInfoEnabled()) {
                log.info("StartService sessionID="
                        + GMContext.getCurrentContext().getSession().getId()
                        + " serviceName=" + serviceName);
            }
            String channel = ADCSession.getString("CHANNEL", "");
            connection = GMConnection.getConnection(CONNECTION + channel);

            oMap = connection.serviceCall(serviceName, map);
            
            return oMap;
        } catch (IOException e) {
            e.printStackTrace ();
            throw new com.graymound.util.GMRuntimeException(101,
                    GMMessageFactory.getMessage("CONNFAIL", new GMMap()), true);
        } finally {
            Date finish = new Date();
            long execTime = finish.getTime() - start.getTime();
            if (log.isDebugEnabled()) {
                log.debug("FinishService sessionID="
                        + GMContext.getCurrentContext().getSession().getId()
                        + " serviceName=" + serviceName + " duration="
                        + execTime + " MAP="
                        + (oMap == null ? "NULL" : oMap.toString()));
            } else if (log.isInfoEnabled()) {
                log.info("FinishService sessionID="
                        + GMContext.getCurrentContext().getSession().getId()
                        + " serviceName=" + serviceName + " duration="
                        + execTime);
            }

            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception ex) {

            }
        }
    }

}
