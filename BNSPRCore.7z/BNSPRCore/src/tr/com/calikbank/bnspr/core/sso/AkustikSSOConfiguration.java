package tr.com.calikbank.bnspr.core.sso;

import java.util.ResourceBundle;

import tr.com.aktifbank.integration.sso.Credential;
import tr.com.aktifbank.integration.sso.SSOClient;
import tr.com.aktifbank.integration.sso.SSOClient.SSOImplementation;
import tr.com.aktifbank.integration.sso.SSOClientFactory;

import com.graymound.server.servlet.context.GMContextSession;
import com.graymound.util.GMMap;


/**
 *
 *	@author		Olcay Yuce
 *	@version 	1.0
 *
 */

public class AkustikSSOConfiguration {

	private static GMMap configuration = new GMMap();
	
	static {
		ResourceBundle properties = ResourceBundle.getBundle("akustik-sso");

		configuration.put("AKUSTIK_LOGIN_SERVICE", properties.getString("akustik.login.service"));
	
	}
	

	public static String getAkustikLoginService() {
		return configuration.getString("AKUSTIK_LOGIN_SERVICE");
	}
	
	
	
}


