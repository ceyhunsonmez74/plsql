package tr.com.calikbank.bnspr.core.sso;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.integration.sso.ChannelSSOClientManager;
import tr.com.aktifbank.integration.sso.Credential;
import tr.com.aktifbank.integration.sso.SSOClient;
import tr.com.calikbank.bnspr.dao.GnlKullanici;

import com.graymound.server.servlet.context.GMContextSession;
import com.graymound.util.GMMap;


/**
 *
 *	@author		Olcay Yuce
 *	@version 	1.0
 *
 */

public class SSOUtil {

	private static Logger logger = Logger.getLogger(SSOUtil.class);
	
	private SSOUtil() {
		
	}
	
	
	public static boolean login(String username, String password, String channelCode, GMContextSession session) {
		Credential credential = new Credential(username,password);
		
		SSOClient ssoClient = ChannelSSOClientManager.getSSOClient(channelCode);
		
		return ssoClient.login(credential, channelCode, session);
	}
	
	
	public static String validate(String ssoToken, String serviceName, String channelCode, GMContextSession session) {
		
		SSOClient ssoClient = ChannelSSOClientManager.getSSOClient(channelCode);
		
		return ssoClient.validate(ssoToken, serviceName, channelCode, session);
		
	}
	
	
	public static String generateToken(String serviceName, String channelCode, GMContextSession session) {

		SSOClient ssoClient = ChannelSSOClientManager.getSSOClient(channelCode);
		
		return ssoClient.generateToken(serviceName, channelCode, session);
		
	}
	
	public static GMMap validateSSOLoginToken(String ssoToken, String loginService, String channelCode, 
			Session hibernateSession, GMContextSession contextSession) {
		
		// init as failure
		boolean success = false;
		
		GMMap oMap = new GMMap();
		
		try {
			SSOClient ssoClient = ChannelSSOClientManager.getSSOClient(channelCode);

			String ssoUserName = ssoClient.validate(ssoToken, loginService, channelCode, contextSession);
			
			if(ssoUserName != null && ssoUserName.trim().length() > 0) {
				
				GnlKullanici gnlKullanici = (GnlKullanici)hibernateSession.createCriteria(GnlKullanici.class).add(
						Restrictions.eq("kod",ssoUserName)).uniqueResult();			
				
				if(gnlKullanici == null){ // CAS case insensitive logine izin veriyor, o yuzden bir de buyuk harfe cevirerek arayalim
					gnlKullanici = (GnlKullanici)hibernateSession.createCriteria(GnlKullanici.class).add(
							Restrictions.eq("kod",ssoUserName.toUpperCase())).uniqueResult();			
				}
				
				if(gnlKullanici != null) {
					
					success = true;
					
					oMap.put("USERNAME", ssoUserName);
					oMap.put("PASSWORD", gnlKullanici.getSifre());

				}
			}
			
		} catch (Exception e) {
			logger.warn("Cannot login SSO ", e);
		}
				
		
		oMap.put("SUCCESS", success);
		
		return oMap;
	}

	
	
}


