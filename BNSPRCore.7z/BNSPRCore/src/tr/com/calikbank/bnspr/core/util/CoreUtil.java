package tr.com.calikbank.bnspr.core.util;

import java.util.ArrayList;
import java.util.ResourceBundle;

import org.apache.commons.lang.ArrayUtils;

public class CoreUtil {

	private static int MESSAGE_LENGTH=4000;
	
	public static Integer EVENT_MAX_THREAD_SIZE = 8;

	private static String ENVIRONMENT ;

	static {
		try{
			ResourceBundle coreProperties = ResourceBundle.getBundle("bnspr-core");
		
			MESSAGE_LENGTH=Integer.valueOf(coreProperties.getString("exception.message.max.lenght"));
		
			EVENT_MAX_THREAD_SIZE = Integer.valueOf(coreProperties.getString("event.maxThreadSize"));
			
			ENVIRONMENT = coreProperties.getString("environment");
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		
	public static String getEnvironment() {
		return ENVIRONMENT;
	}

	public static boolean isEnvironmentProd(){
		return CoreEnums.ENVIRONMENT.PROD.getValue().equals(ENVIRONMENT);
	}
	
	public static String controlMessageSize(String mainExc, String subExc){
		StringBuffer message=new StringBuffer(mainExc==null?"":mainExc);
		if(message.toString().length()==MESSAGE_LENGTH){
			return message.toString();
		}
		if(message.toString().length()>0){
			message.append("\n");
		}
		message.append(subExc==null?"":subExc);
		if(message.toString().length()>MESSAGE_LENGTH){
			return message.toString().substring(0, MESSAGE_LENGTH);
		}
		return message.toString();
	}
	
	public static String[] split(String str,String separator){
		
		if (str == null) {
			return null;
		}
		
		int len = str.length();
		if (len == 0) {
			return ArrayUtils.EMPTY_STRING_ARRAY;
		}

		int separatorLength = separator.length();
		ArrayList<String> substrings = new ArrayList<String>();
		int beg = 0;
		int end = 0;
		while (end < len) {
			end = str.indexOf(separator, beg);

			if (end > -1) {
				substrings.add(str.substring(beg, end));
				beg = end + separatorLength;	
			} else {
				substrings.add(str.substring(beg));
				end = len;
			}
		}

		return ((String[]) substrings.toArray(new String[substrings.size()]));
	}
	
}
