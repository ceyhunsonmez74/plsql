package tr.com.calikbank.bnspr.core.transaction.services;

import java.util.Map;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;



public class BNSPRServiceExecuter {

	@GraymoundService("BNSPR_CORE_SERVICE_EXECUTE")
	public static Map<?, ?> processExecuteWrapper(GMMap iMap) throws Exception {
		try {
			GMMap xMap = GMServiceExecuter.call(
					"BNSPR_CORE_GET_APPLICATION_TYPE", iMap);
			if ("CC".equals(xMap.getString("APP_TYPE"))) {
				return GMServiceExecuter.call("ADC_CORE_PROCESS_EXECUTE", iMap);
			} else
				return GMServiceExecuter.call(
						iMap.getString("SERVICE_NAME_RESERVED"), iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
