package tr.com.calikbank.bnspr.core.transaction.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class BNSPRParallelServiceExecuter {
	@GraymoundService("INTERNET_PARALLEL_SERVICE_EXECUTER")
	public static GMMap parallelServiceExecuter(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String keyList = "KEY_LIST";
			List<?> servicesList = (ArrayList<?>) iMap.get(keyList);
			if (servicesList != null) {
				List<Thread> tList = new ArrayList<Thread>();
				List<BNSPRThreadExecuter> eList = new ArrayList<BNSPRThreadExecuter>();
				for (int row = 0; row < servicesList.size(); row++) {
					String serviceData = iMap.getString(keyList, row, "SERVICE_DATA");
					if (serviceData != null) {
						String serviceName = iMap.getString(serviceData, 0, "SERVICE_NAME");
						if (serviceName != null) {
							GMMap xMap = new GMMap();
							if (iMap.containsKey(serviceData))
								xMap.putAll((HashMap<?, ?>) ((ArrayList<?>) iMap.get(serviceData)).get(0));
									
							BNSPRThreadExecuter executer = new BNSPRThreadExecuter(xMap);
							eList.add(executer);
							Thread thread = new Thread(executer);
							tList.add(thread);
							
						} else {
							throw new GMRuntimeException(1, "\"SERVICE_NAME\" bulunamad�. (\"" + serviceData + "\")");
						}
					} else {
						throw new GMRuntimeException(1, "\"SERVICE_DATA\" bulunamad�.");
					}
				}
				for(Thread t : tList){
					t.start();
				}
				for(Thread t : tList){
					t.join();
				}
				for(BNSPRThreadExecuter e : eList){
					oMap.putAll(e.getOMap());
				}
			} else {
				throw new GMRuntimeException(1, "\"KEY_LIST\" bulunamad�.");
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

}
