package tr.com.calikbank.bnspr.core.transaction;

import java.util.Map;

import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuterDefault;
import com.graymound.util.GMMap;

public class BNSPRServiceExecuterDefault extends GMServiceExecuterDefault {

	@Override
	protected GMMap callService(String serviceName, GMMap map) {
		try {
			if(log.isInfoEnabled())
				log.info( GMContext.getCurrentContext().getSession().getId()+" Start: " +serviceName);
			return super.callService(serviceName, map);
		} finally {
			if(log.isInfoEnabled())
				log.info( GMContext.getCurrentContext().getSession().getId()+" Finish :"+ serviceName);
		}
	}
	
	@Override
	protected Map<?, ?> executeService(String serviceName, Map<?, ?> map) {
		try {
			if(log.isInfoEnabled())
				log.info(GMContext.getCurrentContext().getSession().getId()+" Start: " +serviceName);
			return super.executeService(serviceName, map);
		} finally {
			if(log.isInfoEnabled())
				log.info(GMContext.getCurrentContext().getSession().getId()+" Finish :"+ serviceName);
		}
	}

}
