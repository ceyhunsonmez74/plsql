package tr.com.calikbank.bnspr.core.exception;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import tr.com.calikbank.bnspr.core.LanguageCode;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.server.GMServerDatasource;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMRuntimeException;

/**
 * @author alik
 */
public class ErrorMessageRepository {

    private static ErrorMessageRepository instance;

    private static final String[] JAVA_ERROR_CODES = {
        "50001", /* Undefined exception */
        "50002", /* org.hibernate.JDBCException */
        "50003" /* java.io.IOException */
    };

    private Map<String, String> data = new HashMap<String, String>();

    private ErrorMessageRepository() {
        loadData();
    }

    public static ErrorMessageRepository getInstance() {
        if (null == instance) {
            synchronized (ErrorMessageRepository.class) {
                if (null == instance) { // double check
                    instance = new ErrorMessageRepository();
                }
            }
        }
        return instance;
    }

    public String getMessage(String errorCode) {
        return getMessage(errorCode, getLanguageCodeFromSession());
    }

    public String getMessage(String errorCode, LanguageCode languageCode) {
        String messageData = data.get(errorCode);
        if (null == messageData) {
            return errorCode + "- No error message defined for this errorCode.";
        }
        else
        	return messageData;
    }

    // Loads language specific data from database
    protected void loadData() {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
        	String dilKod = GMContext.getCurrentContext().getSession().get("language").toString().toUpperCase();
//            String kanalKod = GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", new GMMap()).get("KANAL_KOD").toString().toUpperCase();
            
            conn = DALUtil.getGMConnection();
            StringBuffer query = new StringBuffer();
            for (String errorCode : JAVA_ERROR_CODES) {
            	query.append("select mesaj_no, mesaj from GNL_MESAJ_PR msg where ")
                .append("((DIL_KOD = '")
                .append(dilKod)
                .append("' and  KANAL_KOD = pkg_global.Get_kanalkod and  MESAJ_NO = '")
                .append(errorCode)
                .append("') or ((select count(*) from GNL_MESAJ_PR msg where DIL_KOD = '")
                .append(dilKod)
                .append("' and  KANAL_KOD = pkg_global.Get_kanalkod and  MESAJ_NO = '")
                .append(errorCode)
                .append("') = 0 and (DIL_KOD = '")
                .append(dilKod)
                .append("' and  KANAL_KOD = '")
                .append("1")	//default olarak kanal kodu 1 olanlar gelecek
                .append("' and  MESAJ_NO = '")
                .append(errorCode)
                .append("')))");

            	if(!errorCode.equals(JAVA_ERROR_CODES[JAVA_ERROR_CODES.length - 1]))
            		query.append(" union ");
            }
            stmt = conn.prepareCall(query.toString());

            ResultSet rset = stmt.executeQuery();
            while (rset.next()) {
                String errorCode = "BSP-" + rset.getString("MESAJ_NO");
                String message = rset.getString("MESAJ");

                data.put(errorCode, message);
            }

        } catch (Exception e) {
            throw createInitializationError();
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

    }

    protected static LanguageCode getLanguageCodeFromSession() {
        return LanguageCode.valueOf(GMContext.getCurrentContext().getSession()
                .getLanguage());
    }

    protected static GMRuntimeException createInitializationError () {
        String errorMessage = "An error occured while message list is being read from the database.";
        if (LanguageCode.tr == getLanguageCodeFromSession()) {
            errorMessage = "Mesaj listesi veritabanindan okunurken hata olustu.";
        }
        return new GMRuntimeException (0, "BSP-50000" + ": " + errorMessage);
    }

}
