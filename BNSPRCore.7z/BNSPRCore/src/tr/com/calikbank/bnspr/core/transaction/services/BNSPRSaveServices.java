package tr.com.calikbank.bnspr.core.transaction.services;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class BNSPRSaveServices {
	@GraymoundService("BNSPR_SAVE")
	public static GMMap save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			iMap.put("TRX_NO", iMap.getBigDecimal("txNo"));
			iMap.put("TRX_NAME", iMap.getBigDecimal("trxName"));
			session.save(getObject(iMap));
			session.flush();
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	public static Object getObject(GMMap iMap){
		try{
			Class<?> pojo = Class.forName("tr.com.calikbank.bnspr.dao."+iMap.getString("className"));
			Object obj = pojo.newInstance();
			Field[] fields = pojo.getDeclaredFields(); 
			StringBuffer fieldName = null;
			for(int i=0;i<fields.length;i++){
				Field field = fields[i];
				fieldName = new StringBuffer(field.getName());
				if(!fieldName.toString().equals("serialVersionUID")){ 
                    fieldName.setCharAt(0, Character.toUpperCase(fieldName.charAt(0))); 
                    StringBuffer setMethodName =  new StringBuffer("set"); 
                    setMethodName.append(fieldName);
                    Class<?>[] parameters = new Class[1]; 
                    parameters[0] = field.getType();
                    System.out.println(field.getType());
                    System.out.println(field.getType().getClass());
                    Method setMethod = pojo.getMethod(setMethodName.toString(),parameters);
                    Object args = new Object();
                    if(field.getType().equals(BigDecimal.class)){
                    	args = iMap.getBigDecimal(field.getName());
                    	setMethod.invoke(obj,args);
                    }else if(field.getType().equals(String.class)){
                    	args =iMap.getString(field.getName());
                    	setMethod.invoke(obj, args);
                    }else if(field.getType().equals(java.util.Date.class)){
                    	args = iMap.getDate(field.getName());
                    	setMethod.invoke(obj, args);
                    }else if(fieldName.toString().endsWith("Id")){
                    	iMap.put("className", field.getType().getName().substring(field.getType().getName().lastIndexOf(".")+1));
                    	setMethod.invoke(obj, getObject(iMap));
                    }
				}
			}
			return obj;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			Class<?> pojo = Class.forName("tr.com.calikbank.bnspr.dao."+iMap.getString("className"));
			Field[] fields = pojo.getDeclaredFields();
			
			Object obj = session.get(pojo, iMap.getBigDecimal("txNo"));
			StringBuffer fieldName = null;
			GMMap oMap = new GMMap();
			for(int i=0;i<fields.length;i++){
				Field field = fields[i];
				fieldName = new StringBuffer(field.getName());
				if(!fieldName.toString().equals("serialVersionUID")){
					fieldName.setCharAt(0, Character.toUpperCase(fieldName.charAt(0)));
					StringBuffer getMethodName = new StringBuffer("get");
					getMethodName.append(fieldName);
                    Method getMethod = pojo.getMethod(getMethodName.toString());
					oMap.put(field.getName(), getMethod.invoke(obj));
				}
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
