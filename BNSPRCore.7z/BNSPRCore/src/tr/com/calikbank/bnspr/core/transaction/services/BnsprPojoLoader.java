package tr.com.calikbank.bnspr.core.transaction.services;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.util.GMMap;


class LoaderDetailContainer{
	private String tableName;
	private MappingStrategy strategy;
	private List<?> pojoList;
	public String getTableName() {
		return tableName;
	}
	public MappingStrategy getStrategy() {
		return strategy;
	}
	public List<?> getPojoList() {
		return pojoList;
	}
	public LoaderDetailContainer(String tableName, List<?> pojoList, MappingStrategy strategy){
		this.tableName = tableName;
		this.pojoList = pojoList;
		this.strategy = strategy;
	}
	
	
}

public class BnsprPojoLoader {
	private GMMap oMap;
	private Object masterPojo;
	private MappingStrategy masterStrategy; 
	private List<LoaderDetailContainer> container = new ArrayList<LoaderDetailContainer>();
	
	public BnsprPojoLoader(GMMap oMap, Object pojo, MappingStrategy masterStrategy){
		this.oMap = oMap;
		this.masterPojo = pojo;
		this.masterStrategy = masterStrategy;
	}
	
	public BnsprPojoLoader addDetailPojoList(List<?> detailPojoList, String tableName, MappingStrategy strategy){
		container.add(new LoaderDetailContainer(tableName, detailPojoList, strategy));
		return this;
	}

	public GMMap load(){
		try{
			System.out.println(masterPojo.getClass());
			Field [] fieldArray = masterPojo.getClass().getDeclaredFields(); 
			for (int i = 0; i < fieldArray.length; i++) {
				Field field = fieldArray[i];
				field.setAccessible(true);
				String keyName = field.getName();
				if (keyName.toString().equals("serialVersionUID"))
					continue;
				oMap.put(keyName, field.get(masterPojo));
			}
			
			if (masterStrategy != null)
				masterStrategy.doMapping(oMap, masterPojo, null, 0);
			
			for (int i = 0; i < container.size(); i++) {
				List<?> detailPojoList = container.get(i).getPojoList();
				for (Iterator<?> iterator = detailPojoList.iterator(); iterator.hasNext();) {
					Object detailObject = (Object) iterator.next();
					Field [] detailFieldArray = detailObject.getClass().getDeclaredFields();
					int row = 0;
					for (int j = 0; j < detailFieldArray.length; j++) {
						Field field = detailFieldArray[j];
						field.setAccessible(true);
						String keyName = field.getName();
						if (keyName.toString().equals("serialVersionUID"))
							continue;
						String tableName = container.get(i).getTableName(); 
						oMap.put(tableName, row, keyName, field.get(detailObject));
						if(container.get(i).getStrategy() != null)
							container.get(i).getStrategy().doMapping(oMap, detailObject, tableName, row);
					}
					row++;
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
