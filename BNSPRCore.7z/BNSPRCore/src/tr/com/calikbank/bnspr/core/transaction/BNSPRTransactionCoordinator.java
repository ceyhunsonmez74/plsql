package tr.com.calikbank.bnspr.core.transaction;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.HashMap;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;

import com.graymound.server.GMServerDatasource;
import com.graymound.server.coordinator.GMTransactionCoordinator;
import com.graymound.server.servlet.context.GMContext;

public class BNSPRTransactionCoordinator implements GMTransactionCoordinator {

	public BNSPRTransactionCoordinator() {
		super();
	} 
 
	@Override
	public void beginTransaction(HashMap<?, ?> iMap) {
		Connection			conn = null;
		CallableStatement	stmt = null;
		try {
			String clientUserInfo = (String)iMap.get("CLIENT_INFO_RESERVED"); //online kanallardan beslenen client info bilgisi(ip, port vs bilgileri json formatinda iceriyor)
			if(clientUserInfo != null)
				GMContext.getCurrentContext().getSession().put("CLIENT_INFO_RESERVED", clientUserInfo);
			
			BnsprCommonFunctions.setUserGlobals2();
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@Override
	public void endTransaction() {
		// TODO Auto-generated method stub

	}

}
