package tr.com.calikbank.bnspr.core.exception;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import tr.com.calikbank.bnspr.core.util.CoreEnums;
import tr.com.calikbank.bnspr.core.util.CoreUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.server.GMServer;
import com.graymound.util.GMRuntimeException;

/**
 *
 * @author alik
 */
public class ExceptionHandler {

    private static final Log log = LogFactory.getLog(ExceptionHandler.class);

    /*
    private static SQLExceptionConverter sqlExceptionConverter = null;

    // Dogrudan JDBC kullanilan durumlarda alinan SQLException'larinin
    // Hibernate tarafindan yorumlanarak JDBCException hiyerarsisine
    // donusturulmesinin, gercekten gerekli olup olmadigi irdelenmeli.
    static {
        try {
            sqlExceptionConverter = SQLExceptionConverterFactory
                    .buildSQLExceptionConverter(new Oracle9Dialect(),
                            new Properties());
        } catch (Throwable e) {
            log.error(e);
            throw new ExceptionInInitializerError(e);
        }
    }
    */

    public static GMRuntimeException convertException(Throwable e) {

        Long errorId = System.currentTimeMillis();

        log.error(errorId, e);
        
        if(Boolean.valueOf(GMServer.getProperty("exception.putToSession", "false"))){
            StringWriter sw = new StringWriter();
            e.printStackTrace(new PrintWriter(sw));
            
            String requestIdKey = "REQUEST_ID_" + Thread.currentThread().getId();
            String requestId = ADCSession.getString(requestIdKey);
            String exceptionKey = "EXCEPTION_" + requestId;
            String exception = ADCSession.getString(exceptionKey);
            
            ADCSession.put(exceptionKey, CoreUtil.controlMessageSize(exception,sw.toString()));
            
            ADCSession.put("LAST_EXCEPTION", ADCSession.getString(exceptionKey));
            ADCSession.put("LAST_EXCEPTION_DATE", new Date());        	
        }

        if (e instanceof GMRuntimeException) {
        	throw (GMRuntimeException) e;        
        } else if (e instanceof java.sql.SQLException) {
            String errMsg = e.getMessage();

            boolean businessException = errMsg.startsWith("ORA-") && errMsg.compareTo("ORA-20000") >= 0;
            // Java sp hatalar� istisna
            if (businessException && errMsg.startsWith("ORA-29532"))
            		businessException = false;
            if (businessException) {
                String[] subErrMsgs = CoreUtil.split(errMsg, "||");
                if (subErrMsgs==null || subErrMsgs.length < 3) {
                	throw new Error(e);
                }
                String businessExceptionMsg = subErrMsgs[subErrMsgs.length/2];
                
                String businessExceptionMsgCode = null;
                String akustikBEPrefix= CoreEnums.EXCEPTION_PREFIX.AKUSTIK_BUSINESS_EXCEPTION.getValue();
                if(businessExceptionMsg.startsWith( akustikBEPrefix) ){ // Akustik business exception mesaj ornegi : "B-184: Kriterler uyumsuz"
                	int msgCodeBeginIndex = businessExceptionMsg.indexOf(akustikBEPrefix) ;
                	int msgCodeColonIndex = businessExceptionMsg.indexOf(":");
                	businessExceptionMsgCode = businessExceptionMsg.substring( msgCodeBeginIndex, msgCodeColonIndex);
                	if(!Boolean.valueOf( GMServer.getProperty("exception.displayMsgCode", "false") )){ // mesaj kodu hata mesajinda gosterilmeyecekse cikariyoruz
                		businessExceptionMsg = businessExceptionMsg.substring(msgCodeColonIndex + 1).trim();
                	}
                }
                               
                if(businessExceptionMsgCode != null)
                	return new GMRuntimeException(0, businessExceptionMsg, businessExceptionMsgCode);
                else 
                	return new GMRuntimeException(0, businessExceptionMsg);
                
            } else{
            	throw new Error(e) ;
            }
        }else if(e instanceof java.io.IOException){
        	return new GMRuntimeException(101, "Connection Error");
        }else{
        	throw new Error(e);
        }
    }

    
    public static GMRuntimeException convertException(Throwable e, boolean sendToClient) {
    
    	try {
    		throw convertException(e);
		} catch (GMRuntimeException gmEx) {
			if (!sendToClient) {
				return new GMRuntimeException(gmEx.getCode(), gmEx.getMessage(),false);
			}else
				return gmEx;

		}
    	
    
    }
    
    /**
     * Converts given exception to GMRuntimeException by associating error code
     * and language specific error message.
  
    
    
    public static GMRuntimeException convertException(Throwable e) {

        Long errorId = System.currentTimeMillis();

        log.error(errorId, e);

        if (e instanceof GMRuntimeException) {
        	throw (GMRuntimeException) e;        
        } else if (e instanceof java.sql.SQLException) {


//             * Typical java.sql.SQLException that carries business exception
//             * thrown by core banking stored procedures is:
//             *
//             * ORA-20001: ||BSP-00330: Alana giris zorunludur. (ad)|| ORA-06512:
//             * konum "BNSPR.PKG_HATA", sat�r 51 ORA-06512: konum
//             * "BNSPR.PKG_TRN9917", sat�r 67 ORA-06512: konum
//             * "BNSPR.PKG_TRN9917", sat�r 24 ORA-06512: konum sat�r 1
//             *
//             * or:
//             *
//             * ORA-20100: ORA-20001: ||BSP-00675:  HATA.. Fİ�İN USD Dövizinde
//             * 450 Tuda BALANSSIZLIK var...|| ORA-06512: konum "BNSPR.PKG_TX",
//             * satır 1118 ORA-06512: konum "BNSPR.PKG_TX",  satır 447
//             * ORA-06512: konum  satır 1


            String errMsg = e.getMessage();

            boolean businessException = errMsg.startsWith("ORA-") && errMsg.compareTo("ORA-20000") >= 0;
            if (businessException) {
                String[] subErrMsgs = errMsg.split("\\|\\|");
                String businessExceptionMsg = subErrMsgs[1];// + " - LOGID: " + errorId;  	 BNSPRPRO-592 ile kaldirildi
                return new GMRuntimeException(0, businessExceptionMsg);
            } else {
                // Handles the message by using Hibernate's exception handling
                // mechanism. Hibernate converts SQLException to one of the
                // subclass of JDBCException.
                return convertException(sqlExceptionConverter.convert(
                        (SQLException) e, e.getMessage(), "NO_SQL"));
            }
        } else if (e instanceof org.hibernate.JDBCException) {
            return createGMRuntimeException("BSP-50002", errorId);
        } else if (e instanceof java.io.IOException) {
            return createGMRuntimeException("BSP-50003", errorId);
        } else if (e instanceof Error) { // do not do anything!
            throw new Error(e);
        } else {
            return createGMRuntimeException("BSP-50001", errorId);
        }
    }
    
    */ 

    protected static GMRuntimeException createGMRuntimeException(
            String errorCode, Long errorId) {

        String errorMessage = ErrorMessageRepository.getInstance().getMessage(errorCode);

        return new GMRuntimeException(0, errorCode
                + ": " + errorMessage + " - LOGID: " + errorId);
    }


    // Since the code is dependent to GM, following unit test does not work
    // anymore!

    private static void test01BusinessException() {
        System.out.println("-------------------- test01BusinessException ()");
        try {
            try {
                String reason = "ORA-20001: ||BSP-00330:  Alana giris zorunludur. (ad)||"
                        + "\n"
                        + "ORA-06512: konum \"BNSPR.PKG_HATA\",  satir 51"
                        + "\n"
                        + "ORA-06512: konum \"BNSPR.PKG_TRN9917\",  satir 67"
                        + "\n"
                        + "ORA-06512: konum \"BNSPR.PKG_TRN9917\",  satir 24"
                        + "\n" + "ORA-06512: konum  satir 1";

                throw new SQLException(reason);
            } catch (Exception e) {
                throw ExceptionHandler.convertException(e);
            }
        } catch (GMRuntimeException e) {
            System.err.println(e.getMessage());
        }

    }

/*    private static void test02IOException() {
        System.out.println("-------------------- test02IOException ()");
        try {
            try {
                throw new IOException("This is an I/O exception.");
            } catch (Exception e) {
                throw ExceptionHandler.convertException(e);
            }
        } catch (GMRuntimeException e) {
            System.err.println(e.getMessage());
        }

    }

    private static void sleep() {
        try {
            Thread.sleep(500);
        } catch (Exception e) {
        }
    }
*/
    public static void main(String[] args) {
//        String errMessage = "ORA-20100: ORA-20001: ||BSP-00675:  HATA.. XYZ";
//        System.out.println(errMessage.compareTo("ORA-20000"));
//        System.out.println(System.currentTimeMillis());
//
//        Long errorId = System.currentTimeMillis();
//
//        log.error(errorId, new Exception("my exception"));

        test01BusinessException();
        //sleep();
        //test02IOException();
    }

}
