package tr.com.calikbank.bnspr.core.sso.services;

import org.apache.log4j.Logger;

import tr.com.aktifbank.integration.sso.cas.AktifBankProxyGrantingTicketStorage;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;


/**
 *
 *	@author		Olcay Yuce
 *	@version 	1.0
 *
 */

public class BNSPRSSOServices {

	private static Logger logger = Logger.getLogger(BNSPRSSOServices.class);

	
	@GraymoundService("BNSPR_SSO_CAS_PGT_CALLBACK_SERVICE")
	public static GMMap casPGTCallback(GMMap iMap){
		GMMap oMap = new GMMap();
		
		String proxyGrantingTicketIou = iMap.getString("PGTIOU");
		String proxyGrantingTicket = iMap.getString("PGT");
		
		AktifBankProxyGrantingTicketStorage.getInstance().save(proxyGrantingTicketIou, proxyGrantingTicket);
		
        return oMap;
	}
	

}


