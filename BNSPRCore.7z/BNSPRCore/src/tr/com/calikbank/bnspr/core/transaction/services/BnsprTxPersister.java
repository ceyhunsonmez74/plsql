package tr.com.calikbank.bnspr.core.transaction.services;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.TestPojo;
import tr.com.calikbank.bnspr.dao.TestDetailPojoId;

import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

class BnsprDetailContainer{
	private Class<?> detailPojoClass;
	private Class<?> detailIdClass;
	private List<Mapping> mappingList;
	private String tableName;
	
	BnsprDetailContainer(Class<?> detailPojoClass, Class<?> detailIdClass, String tableName, List<Mapping> mappingList){
		this.detailIdClass = detailIdClass;
		this.detailPojoClass = detailPojoClass;
		this.tableName = tableName;
		this.mappingList = mappingList;
	}
	
	public Class<?> getDetailPojoClass() {
		return detailPojoClass;
	}
	public Class<?> getDetailIdClass() {
		return detailIdClass;
	}
	public List<Mapping> getMappingList() {
		return mappingList;
	}
	public String getTableName() {
		return tableName;
	}
}

public class BnsprTxPersister{
	private GMMap iMap;
	private Class<?> pojoMasterClass;
	private Class<?> pojoMasterIdClass;
	private List<BnsprDetailContainer> detailContainerList;
	
	private List<Mapping> masterMappings;
	private String currentMappedFieldName;
	private Object currentMappedValue;
	
	private String trxName;
	
	public BnsprTxPersister(GMMap iMap, Class<?> pojoMasterClass, Class<?> pojoMasterIdClass, List<Mapping> mappings, String trxName){
		this.iMap = iMap;
		this.pojoMasterClass = pojoMasterClass;
		this.pojoMasterIdClass = pojoMasterIdClass;
		this.masterMappings = mappings;
		this.trxName = trxName;
	}
	public BnsprTxPersister addDetailPojoClass(Class<?> detailPojoClass, Class<?> detailIdClass, String tableName, List<Mapping> mappingList){
		if(detailContainerList == null)
			detailContainerList = new ArrayList<BnsprDetailContainer>();
		detailContainerList.add(new BnsprDetailContainer(detailPojoClass, detailIdClass, tableName, mappingList));
		return this;
	}
	
	public Map<?, ?> persist(){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			Object obj = createObject(pojoMasterClass, pojoMasterIdClass, masterMappings, null, 0);	
			session.save(obj);
			if(detailContainerList!=null){
				for (int i = 0; i < detailContainerList.size(); i++) {
					BnsprDetailContainer detailContainer = detailContainerList.get(i);
					Object detailObject = null;
					if (detailContainer.getTableName() != null) {
						for (int j = 0; j < iMap.getSize(detailContainer.getTableName()); j++) {
							detailObject = createObject(detailContainer.getDetailPojoClass(), detailContainer.getDetailIdClass(), detailContainer.getMappingList(), detailContainer.getTableName(), j);
							session.save(detailObject);
						} 
					}else {
						detailObject = createObject(detailContainer.getDetailPojoClass(), detailContainer.getDetailIdClass(), detailContainer.getMappingList(), detailContainer.getTableName(), 0);
						session.save(detailObject);
					}
				}
			}
			session.flush();
			iMap.put("TRX_NO", iMap.get("txNo"));
			iMap.put("TRX_NAME", trxName);
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private Object createObject(Class<?> pojoClass, Class<?> idClass, List<Mapping> mappings, String tableName, int row) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, SecurityException, NoSuchMethodException, ParseException{
		Object obj = pojoClass.newInstance();
		Field[] fields = pojoClass.getDeclaredFields(); 

		for(int i=0;i<fields.length;i++){
			Field field = fields[i];
			field.setAccessible(true);
			
			String keyName = field.getName();
			Object args = null;
			if (keyName.toString().equals("serialVersionUID"))
				continue;
			
			if(mappings != null){
				processMap(keyName, mappings);
				if(currentMappedFieldName != null)
					keyName = this.currentMappedFieldName;
				else if(currentMappedValue != null){
					field.set(obj, currentMappedValue);
					continue;
				}
			}
			
			if (tableName == null) {
				if (field.getType().equals(BigDecimal.class)) {
					args = iMap.getBigDecimal(keyName);
				} else if (field.getType().equals(String.class)) {
					args = iMap.getString(keyName);
				} else if (field.getType().equals(java.util.Date.class)) {
					args = iMap.getDate(keyName);
				} else if (field.getType().equals(idClass)) {
					args = createObject(idClass, null, mappings, tableName, row);
				}
			} else {
				if (field.getType().equals(BigDecimal.class)) {
					args = iMap.getBigDecimal(tableName, row, keyName);
				} else if (field.getType().equals(String.class)) {
					args = iMap.getString(tableName, row, keyName);
				} else if (field.getType().equals(java.util.Date.class)) {
					args = iMap.getDate(tableName, row, keyName);
				} else if (field.getType().equals(idClass)) {
					args = createObject(idClass, null, mappings, tableName, row);
				}
			}
			field.set(obj, args);
		}
		return obj;
	}
	
	

	private void processMap(String fieldName, List<Mapping> mappingList){
		this.currentMappedFieldName = null;
		this.currentMappedValue = null;
		for (Iterator<?> iterator = mappingList.iterator(); iterator.hasNext();) {
			Mapping mapping = (Mapping) iterator.next();
			if(fieldName.equals(mapping.getPojoFieldName())){
				currentMappedFieldName = mapping.getKeyName();
				currentMappedValue = mapping.getValue();
			}
		}
	}

	public static void main(String [] args) throws IllegalArgumentException, SecurityException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException, ParseException {
		GMMap oMap = new GMMap();
		oMap.put("string", "STRING");
		oMap.put("bd", new BigDecimal(13));
		oMap.put("date", new Date());
		String tableName = "LIST";
		oMap.put(tableName, 0, "str", "DETAIL STRING");
		oMap.put(tableName, 0, "bd", new BigDecimal(new Random().nextInt(100000)));
		oMap.put(tableName, 0, "date", new Date());
		
		Mapping mapping = new Mapping("str", "string", null);
		Mapping mapping2 = new Mapping("bd", null, new BigDecimal(31));
		
		ArrayList<Mapping> mappingList = new ArrayList<Mapping>();
		mappingList.add(mapping);
		mappingList.add(mapping2);
		
		new BnsprTxPersister(oMap, TestPojo.class, TestDetailPojoId.class, mappingList, "TRX_TEMPLATE")
		.addDetailPojoClass(tr.com.calikbank.bnspr.dao.TestDetailPojo.class, null, tableName, null)
		.persist();
	}
}
