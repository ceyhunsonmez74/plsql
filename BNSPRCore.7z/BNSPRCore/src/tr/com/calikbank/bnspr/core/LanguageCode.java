package tr.com.calikbank.bnspr.core;

/**
 * @author alik
 */
public enum LanguageCode {
    tr, // Turkish
    en // English
}
