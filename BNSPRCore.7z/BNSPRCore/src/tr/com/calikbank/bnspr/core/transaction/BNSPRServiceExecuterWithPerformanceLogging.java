package tr.com.calikbank.bnspr.core.transaction;

import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;

import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuterDefault;
import com.graymound.util.GMMap;

public class BNSPRServiceExecuterWithPerformanceLogging extends
		GMServiceExecuterDefault {

	private static Logger	log	= Logger.getLogger("servicelog");

	@Override
	protected GMMap callService(String serviceName, GMMap map) {
		Date start = new Date();
		Date finish = null;
		GMMap oMap = null;
		try {
			if (log.isDebugEnabled()) {
				log.debug("StartService sessionID="
						+ GMContext.getCurrentContext().getSession().getId()
						+ " serviceName=" + serviceName + " MAP="
						+ (map == null ? "NULL" : map.toString()));
			} else if (log.isInfoEnabled()) {
				log.info("StartService sessionID="
						+ GMContext.getCurrentContext().getSession().getId()
						+ " serviceName=" + serviceName);
			}
			oMap = super.callService(serviceName, map);
			return oMap;
		} finally {
			finish = new Date();
			long execTime = finish.getTime() - start.getTime();
			if (log.isDebugEnabled()) {
				log.debug("FinishService sessionID="
						+ GMContext.getCurrentContext().getSession().getId()
						+ " serviceName=" + serviceName + " duration="
						+ execTime + " MAP="
						+ (oMap == null ? "NULL" : oMap.toString()));
			} else if (log.isInfoEnabled()) {
				log.info("FinishService sessionID="
						+ GMContext.getCurrentContext().getSession().getId()
						+ " serviceName=" + serviceName + " duration="
						+ execTime);
			}
		}
	}

	@Override
	protected Map<?, ?> executeService(String serviceName, Map<?, ?> map) {
		Map<?, ?> oMap = null;
		Date start = new Date();
		Date finish = null;
		try {
			if (log.isDebugEnabled()) {
				log.debug("StartService sessionID="
						+ GMContext.getCurrentContext().getSession().getId()
						+ " serviceName=" + serviceName + " MAP="
						+ (map == null ? "NULL" : map.toString()));
			} else if (log.isInfoEnabled()) {
				log.info("StartService sessionID="
						+ GMContext.getCurrentContext().getSession().getId()
						+ " serviceName=" + serviceName);
			}
			oMap = super.executeService(serviceName, map);
			return oMap;
		} finally {
			finish = new Date();
			long execTime = finish.getTime() - start.getTime();
			if (log.isDebugEnabled()) {
				log.debug("FinishService sessionID="
						+ GMContext.getCurrentContext().getSession().getId()
						+ " serviceName=" + serviceName + " duration="
						+ execTime + " MAP="
						+ (oMap == null ? "NULL" : oMap.toString()));
			} else if (log.isInfoEnabled()) {
				log.info("FinishService sessionID="
						+ GMContext.getCurrentContext().getSession().getId()
						+ " serviceName=" + serviceName + " duration="
						+ execTime);
			}
		}
	}
}
