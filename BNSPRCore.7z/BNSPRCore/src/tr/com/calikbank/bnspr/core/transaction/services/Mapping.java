package tr.com.calikbank.bnspr.core.transaction.services;

class Mapping{
	public Mapping(String pojoFieldName, String keyName, Object value){
		this.pojoFieldName = pojoFieldName;
		this.keyName = keyName;
		this.value = value;
	}
	private String pojoFieldName;
	private String keyName;
	private Object value;
	public String getPojoFieldName() {
		return pojoFieldName;
	}
	public String getKeyName() {
		return keyName;
	}

	public Object getValue() {
		return value;
	}
}