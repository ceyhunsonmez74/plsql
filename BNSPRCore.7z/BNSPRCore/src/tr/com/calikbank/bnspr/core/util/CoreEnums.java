package tr.com.calikbank.bnspr.core.util;

public class CoreEnums {

	public enum ENVIRONMENT{
		
		DEV("DEV"),
		TEST("TEST"),
		UAT("UAT"),
		PREPROD("PREPROD"),
		PROD("PROD");
		
		
		private String value;
		
		private ENVIRONMENT(String value){
			this.value = value;
		}
		
		public String getValue() {
			return value;
		}
		
	}
	
	public enum EXCEPTION_PREFIX{

		AKUSTIK_BUSINESS_EXCEPTION("B-");
		
		private String value;

		private EXCEPTION_PREFIX(String value){
			this.value = value;
		}
		
		public String getValue() {
			return value;
		}
		
	}
	
}
