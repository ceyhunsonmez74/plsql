package tr.com.calikbank.bnspr.core.transaction.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlKullSifreUnutma;
import tr.com.aktifbank.bnspr.dao.GnlKullaniciEsZamanizin;
import tr.com.aktifbank.bnspr.dao.GnlKullaniciOturum;
import tr.com.calikbank.bnspr.core.LanguageCode;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.core.sso.AkustikSSOConfiguration;
import tr.com.calikbank.bnspr.core.sso.SSOUtil;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.dao.GnlKullanici;
import tr.com.calikbank.bnspr.dao.VGnlRolProgramMenu;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.pojo.Channel;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.annotation.GraymoundServiceParameters;
import com.graymound.annotation.Parameter;
import com.graymound.cache.GMCache;
import com.graymound.cache.GMCacheFactory;
import com.graymound.connection.GMConnection;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
 
public class BNSPRAuthServices { 
	
	private static final String		DAO_SESSION_FACTORY_NAME	= "BNSPRDal";
	
	private static Logger logger = Logger.getLogger(BNSPRAuthServices.class);
	 
	private static void createModuleMenuNode(DefaultMutableTreeNode parent,VGnlRolProgramMenu menu){
		GMMap	item	= new GMMap();
/*		item.put("OID"				,menu.getOid());
		item.put("VERSION"			,menu.getVersion());*/

		item.put("NAME"				,menu.getId().getAdi());
		item.put("PAGE_NAME"		,menu.getId().getKodu());
		item.put("SHORT_CUT_KEY"	,menu.getShortCutKey());
		item.put("SORT_ORDER"		,menu.getSira());
		item.put("SHORT_NAME"		,menu.getKisaKod());
		item.put("NODE_TYPE"		,"MENU");
		
		GMMap variables = new GMMap();
		variables.put("PAGE_TO_OPEN",menu.getSira());
		item.put("VARIABLES"		,variables);
		
		
		DefaultMutableTreeNode node = new DefaultMutableTreeNode(item);

		for (Iterator<?> iter = menu.getVGnlRolProgramMenus().iterator(); iter.hasNext();) {
			VGnlRolProgramMenu child = (VGnlRolProgramMenu) iter.next();
			createModuleMenuNode(node,child);
		}
		parent.add(node);
	} 

	private static TreeNode createModuleNode(VGnlRolProgramMenu module){
		HashMap<String,Object>	item	= new HashMap<String,Object>();
		item.put("NAME"			,module.getId().getAdi());
		item.put("SORT_ORDER"		,module.getSira());
		item.put("NODE_TYPE"	,"MODULE");
	
		DefaultMutableTreeNode root = new DefaultMutableTreeNode(item);
	
		for (Iterator<?> iter = module.getVGnlRolProgramMenus().iterator(); iter.hasNext();) {
			VGnlRolProgramMenu moduleMenu = (VGnlRolProgramMenu) iter.next();
				createModuleMenuNode(root,moduleMenu);
			
		}
		return root;
	}

	@GraymoundService(value="BNSPR_USER_AUTHENTICATE",authenticationRequired=false)
	@GraymoundServiceParameters(iParameters = { @Parameter(name="USERNAME"), 
            @Parameter(name="PASSWORD"), 
            @Parameter(name="LANGUAGE"), 
            @Parameter(name="CHANNEL" )})
	public static GMMap userAuthenticate(GMMap iMap){
			GMMap oMap = new GMMap();
			String username =  iMap.getString("USERNAME");
			String password = iMap.getString("PASSWORD");
			String language = iMap.getString("LANGUAGE");
			Session session = DAOSession.getSession(DAO_SESSION_FACTORY_NAME);
			
			
			// SSO BEGIN
			String ssoToken = iMap.getString("SSO_TOKEN");
			if(ssoToken != null && ssoToken.trim().length() > 0) {
				
				Channel channel = (Channel) iMap.get("CHANNEL");
				String channelCode = channel == null ? "BNSPR" : channel.getCode();
				String ssoLoginService =  iMap.getString("SSO_LOGIN_SERVICE", AkustikSSOConfiguration.getAkustikLoginService());
				
				GMMap ssoLoginResult = SSOUtil.validateSSOLoginToken(ssoToken, ssoLoginService, 
						channelCode, session, GMContext.getCurrentContext().getSession());
				
				if(!ssoLoginResult.getBoolean("SUCCESS")) {
					// set wrong password and let fail count to be incremented if username is supplied  
					password = "0";
				} else {
					// set username/password as valid username and password
					username = ssoLoginResult.getString("USERNAME");
					password = ssoLoginResult.getString("PASSWORD");
				}
				
				if(language == null) {
					language = String.valueOf(LanguageCode.tr);
				}
				
			}
			//SSO END
			
			
			List<?>	list	= session.createCriteria(GnlKullanici.class).add(Restrictions.eq("kod",username)).list();
			if (!list.isEmpty()){
				GnlKullanici user = (GnlKullanici)list.get(0);
				GMMap myMap = new GMMap();
				myMap.put("KULLANICI_KOD", username);
				myMap.put("SIFRE_HASHED", password);
				myMap.put("DURUM", iMap.getString("DURUM"));
				Object logSonuc = GMServiceExecuter.executeNT("BNSPR_CORE_SIFRE_LOGLA", myMap).get("SONUC");
				oMap.put("SONUC", logSonuc);
				//logsonuc == 0 => OK
				//logsonuc == 1 => Hatali
				//if (iMap.containsKey("CHANNEL") || logSonuc.equals("0")){
				if (logSonuc.equals("0")){

					checkParallelLogin(user, session);
					
					ADCSession.put("APP_TYPE_RESERVED"	, AkustikConstants.APP_TYPE_AKUSTIK);
					ADCSession.put("language"			, language		);
					ADCSession.put("USER_NAME"			, username		);
					ADCSession.put("USER_OID"			, user.getKod()	);					
					ADCSession.put("authenticated"		, username		);
					ADCSession.put("CHANNEL_CODE"		, user.getKanalKod()		);
					if(!StringUtil.isEmpty(user.getKanalKod())){
						GnlKanalGrupKodPr kanal = (GnlKanalGrupKodPr)session.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("kod", user.getKanalKod())).uniqueResult();
						if(!StringUtil.isEmpty(kanal.getIntegrationId())){
							ADCSession.put("CHANNEL", kanal.getIntegrationId());
						}		
					}
					
					ADCSession.setAuthenticated(true);
					
				} 
				else if (logSonuc.equals("44")){
				  
				    iMap.put("UID", username);
					boolean isLdapUser = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_BNSPR", iMap).getBoolean("LDAP_USER");//LDAP_BNSPR
				  
					if(isLdapUser){
						iMap.put("INET_USER_STATUS","Passive");
						GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_BNSPR", iMap);// LDAP_BNSPR
					}
				  
					throwErrorMessage(887); //Sifre Kilitli MHA 061108
			   } 
			   else{
				   throwErrorMessage(1711); 
				   throw new GMRuntimeException(0, "Invalid username/password !");
			   }
			} 
			else {
				oMap.put("SONUC", "11");
				throwErrorMessage(1711); 
			}
			return oMap;
	}
	
	
	private static void checkParallelLogin(GnlKullanici user, Session session){
		 //sistem kullanicisi degilse ve es oturum izini yoksa kullanicinin acik oturumu varsa kapatacagiz
		if(!"$$SYS$$".equals( user.getRolKod() )){
			String userCode = user.getKod();
			
			GnlKullaniciEsZamanizin esZamanIzin	= (GnlKullaniciEsZamanizin)session.createCriteria(GnlKullaniciEsZamanizin.class)
																					.add(Restrictions.eq("kullanicikod", userCode))
																					.uniqueResult();
			if(esZamanIzin == null){
				GnlKullaniciOturum kullaniciOturum	= (GnlKullaniciOturum)session.createCriteria(GnlKullaniciOturum.class)
																			.add(Restrictions.eq("kod", userCode)).uniqueResult();
				if(kullaniciOturum != null){
					String lastSessionId = kullaniciOturum.getLastSessionId();
					if( lastSessionId != null ){
						logger.info("Old session of user " + userCode + " is being removed:" + lastSessionId );
						GMCache sessionCache	= GMCacheFactory.getInstance().getCache("GM_SESSION_CACHE");
						sessionCache.remove(lastSessionId);
					}	
				}
				else{
					kullaniciOturum = new GnlKullaniciOturum();
				}
				kullaniciOturum.setKod(userCode);
				kullaniciOturum.setLastSessionId(ADCSession.getSessionID());
				kullaniciOturum.setLastModified(new Date());
				session.saveOrUpdate(kullaniciOturum);
			}
		}
	}
	
	
	@GraymoundService(value="BNSPR_CINT_AUTHENTICATE",authenticationRequired=false)
	public static GMMap cintAuthenticate(GMMap iMap){
		GMMap oMap=userAuthenticate(iMap);
		/*String customerNo=iMap.getString("MUSTERI_NO");
		CallableStatement stmt=null;
		Connection conn=null;
		try {
			if (customerNo!=null){
				conn = GMServerDatasource.getConnection("java:/GraymoundDS");
				stmt = conn.prepareCall("{? = call pkg_musteri.musteri_sube(?)}");
				stmt.registerOutParameter(1,java.sql.Types.CHAR);
				stmt.setString(2, customerNo);
				stmt.execute();
				GMContext.getCurrentContext().getSession().put("BRANCH_ID",stmt.getString(1));
				System.out.println("Branch set to :"+stmt.getString(1));				
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}*/
			
		return oMap;
	}
	
	@GraymoundService(value="BNSPR_DEALER_AUTHENTICATE",authenticationRequired=false)
	public static GMMap dealerAuthenticate(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
			
			String username 	= iMap.containsKey("USERNAME") ? iMap.remove("USERNAME").toString() : null;			
			String password 	= iMap.containsKey("PASSWORD") ? iMap.remove("PASSWORD").toString() : null;
			String language 	= iMap.containsKey("LANGUAGE") ? iMap.remove("LANGUAGE").toString() : null;
			Session session 	= DAOSession.getSession(DAO_SESSION_FACTORY_NAME);
			List<?>	list		= session.createCriteria(GnlKullanici.class).add(Restrictions.eq("kod",username)).list();
			if (!list.isEmpty()){
				GnlKullanici user 	= (GnlKullanici)list.get(0);
				GMMap myMap 		= new GMMap();
				myMap.put("KULLANICI_KOD"	, username);
				myMap.put("SIFRE_HASHED"	, password);
				Object logSonuc 	= GMServiceExecuter.executeNT("BNSPR_CORE_SIFRE_LOGLA", myMap).get("SONUC");
				oMap.put("SONUC"			, logSonuc);
				//logsonuc == 0 => OK
				//logsonuc == 1 => Hatal�
				if (logSonuc.equals("0")){
					GMContext.getCurrentContext().getSession().put("USER_NAME"			, username		);
					GMContext.getCurrentContext().getSession().put("USER_OID"			, user.getKod()	);					
					GMContext.getCurrentContext().getSession().put("authenticated"		, username		);
					GMContext.getCurrentContext().getSession().put("language"			, language		);
					GMContext.getCurrentContext().getSession().setAuthenticated(true);
					ADCSession.put("CHANNEL_CODE", user.getKanalKod());
					if(!StringUtil.isEmpty(user.getKanalKod())){
						GnlKanalGrupKodPr kanal = (GnlKanalGrupKodPr)session.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("kod", user.getKanalKod())).uniqueResult();
						if(!StringUtil.isEmpty(kanal.getIntegrationId())){
							ADCSession.put("CHANNEL", kanal.getIntegrationId());
						}
					}
					
					for (Object key : iMap.keySet()) {
						GMContext.getCurrentContext().getSession().put(key.toString()	, iMap.get(key));
					}
				} 
			  	  else if (logSonuc.equals("44")){
				 	throwErrorMessage(887); //Sifre Kilitli MHA 061108
				} else {
					throw new RuntimeException("Invalid username/password !");
				}
			} else {
				oMap.put("SONUC", "11");
				throw new RuntimeException("Invalid username/password !");
			}
			return oMap;
		} catch (HibernateException e) {
			throw new GMRuntimeException(12,e);
		}

	}
	
	@GraymoundService("BNSPR_USER_AUTHORIZE")
	public static GMMap userAuthorize(GMMap iMap){
		DefaultMutableTreeNode	root 			= new DefaultMutableTreeNode(new GMMap());
		Session session = null;
		
		try {
			session = DAOSession.getSession(DAO_SESSION_FACTORY_NAME);
//			GnlKullanici			user 	= (GnlKullanici) session.load(GnlKullanici.class, (String)GMContext.getCurrentContext().getSession().get("USER_NAME"));
			List<?>			list 	= session.createCriteria(VGnlRolProgramMenu.class).add(Restrictions.eq("id.par1","X"))
												 .addOrder(Order.asc("sira"))
												 .list();
			for (Iterator<?> iter = list.iterator(); iter.hasNext();) {
				VGnlRolProgramMenu		module	= (VGnlRolProgramMenu) iter.next();
//				if (module.hasRole(user.getRoles())){
					root.add((MutableTreeNode)createModuleNode(module));
				//}
			}

			GMMap oMap = new GMMap();
			oMap.put("userMenu",root);	
			oMap.put("favoriteMenu",getUserFavoritePrograms());
			return oMap;
			
		} catch (Exception e) {
			throw new RuntimeException(e);
		} 
	}
	
	@SuppressWarnings("unchecked")
	private static DefaultMutableTreeNode getUserFavoritePrograms(){
		List<Object[]> favoriteList = DAOSession.getSession(DAO_SESSION_FACTORY_NAME)
				.createQuery("SELECT F.id.kod,M.id.adi FROM GnlProgramFavorite F, VGnlRolProgramMenu M WHERE F.id.kod=M.id.kodu AND F.id.kullKod=:kullKod ORDER BY M.id.adi")
				.setParameter("kullKod", ADCSession.getString("USER_NAME")).list();
		
		DefaultMutableTreeNode	favoriteRoot = new DefaultMutableTreeNode(new GMMap());
		for (Object[] pageData : favoriteList) {
			GMMap favoriteItem = new GMMap();
			favoriteItem.put("NAME",pageData[1]);
			favoriteItem.put("PAGE_NAME",pageData[0]);
			favoriteRoot.add(new DefaultMutableTreeNode(favoriteItem));
		}
		return favoriteRoot;
	}
	
	@GraymoundService("BNSPR_CORE_SIFRE_DEGISTIR")
	public static GMMap sifreDogrula(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		GMMap oMap = new GMMap();
		
		try {
			
			String currentUserCode = GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD",new GMMap()).getString("KULLANICI_KOD");
			
			boolean ownPassword = currentUserCode.equals(iMap.getString("KULLANICI_KOD"));
			iMap.put("PWD_RESET", !ownPassword);
			
			conn	= DALUtil.getGMConnection();
			iMap.put("UID", iMap.getString("KULLANICI_KOD"));
			boolean isLdapUser = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_BNSPR", iMap).getBoolean("LDAP_USER");//LDAP_BNSPR
			
			if(iMap.getString("DURUM").equals("D")){ //kullanici sifre degistirme ekrani
				try
				{
					stmt = conn.prepareCall("{? = call PKG_SIFRE.GIRIS_KONTROL(?,?)}");
					stmt.setString(2, iMap.getString("KULLANICI_KOD"));
					stmt.setString(3, iMap.getString("SIFRE"));
					stmt.registerOutParameter(1, java.sql.Types.VARCHAR);
					stmt.execute();
					String sifreDogrulamaStatus = stmt.getString(1);
					if(sifreDogrulamaStatus.equals("Y")){
						throwErrorMessage(875);//yanlis sifre
					}
					else if(sifreDogrulamaStatus.equals("K")){
						if(isLdapUser){
							iMap.put("INET_USER_STATUS","Passive");
							GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_BNSPR", iMap);// LDAP_BNSPR
						}
						throwErrorMessage(876);//kilitli sifre
					}
				}finally{
					GMServerDatasource.close(stmt);
				}
	            if (iMap.getString("SIFRE").equals(iMap.getString("YENI_SIFRE_HASHED"))){
	            	throwErrorMessage(5291); //ilk sifre ile yeni sifre ayni olamaz
	            }
			}
			
			if (iMap.getString("YENI_SIFRE").contains(iMap.getString("KULLANICI_KOD"))) {
            	throwErrorMessage(5296); //yeni sifre kullanici kodunu i�eremez
			}
			
			if(!iMap.getString("YENI_SIFRE").equals(iMap.getString("YENI_SIFRE_TEKRAR"))){
				throwErrorMessage(882); //yeni sifreler farkli
			}

			Object yeniSifreStatus = DALUtil.callOneParameterFunction("{? = call PKG_SIFRE.Sifre_Gecerlimi(?)}", Types.VARCHAR, iMap.getString("YENI_SIFRE"));
			if(yeniSifreStatus.equals("1")){
				//throwErrorMessage(877); //sifre en az sekiz karakter olmali
				GMMap sfMap = new GMMap();
				sfMap.put("MESSAGE_NO",new BigDecimal(877));
				sfMap.put("P1", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('SIFRE_MIN_UZUNLUK')}", Types.NUMERIC));
				//hrowErrorMessage(880); //sifrede en az iki rakam olmalidir
				//oMap.put("MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", sfMap).get("ERROR_MESSAGE"));
				throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", sfMap).get("ERROR_MESSAGE"));
				
			}
			else if (yeniSifreStatus.equals("6")){
				GMMap sfMap = new GMMap();
				sfMap.put("MESSAGE_NO",new BigDecimal(1079));
				sfMap.put("P1", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('SIFRE_MAX_UZUNLUK')}", Types.NUMERIC));
				//hrowErrorMessage(880); //sifrede en az iki rakam olmalidir
				//oMap.put("MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", sfMap).get("ERROR_MESSAGE"));
				throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", sfMap).get("ERROR_MESSAGE"));				
			}
			else if(yeniSifreStatus.equals("2")){
				throwErrorMessage(878); //Turkce karakter olamaz
			}
			else if(yeniSifreStatus.equals("3")){
				throwErrorMessage(879); //Sifrede ozel karakter olamaz
			}
			else if(yeniSifreStatus.equals("4")){
				GMMap sfMap = new GMMap();
				sfMap.put("MESSAGE_NO",new BigDecimal(880));
				sfMap.put("P1", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('SIFRE_MIN_RAKKAM_ADETI')}", Types.NUMERIC));
				//hrowErrorMessage(880); //sifrede en az iki rakam olmalidir
				//oMap.put("MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", sfMap).get("ERROR_MESSAGE"));
				throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", sfMap).get("ERROR_MESSAGE"));
			}
			else if(yeniSifreStatus.equals("5")){
				throwErrorMessage(881); //�ifrede sadece rakam olmamalidir
			}
			else if(yeniSifreStatus.equals("7")){
				throwErrorMessage(5292); //�ifrede sadece rakam olmamalidir
			}
			else if(yeniSifreStatus.equals("8")){
				throwErrorMessage(5293); //�ifrede sadece rakam olmamalidir
			}
			
			Session session = DAOSession.getSession("BNSPRDal");
			GnlKullanici kull = (GnlKullanici)session.get(GnlKullanici.class, iMap.getString("KULLANICI_KOD"));
			kull.setSifre(iMap.getString("YENI_SIFRE_HASHED"));
			kull.setSifreDegisiklikTar( GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap ()).getDate("BANKA_TARIH"));
			session.update(kull);
			session.flush();

			GMMap myMap = new GMMap();
			myMap.put("KULLANICI_KOD", iMap.getString("KULLANICI_KOD"));
			myMap.put("SIFRE_HASHED", iMap.getString("YENI_SIFRE_HASHED"));
			myMap.put("DURUM", iMap.getString("DURUM"));
			Object logSonuc = GMServiceExecuter.execute("BNSPR_CORE_SIFRE_LOGLA", myMap).get("SONUC");
			if(logSonuc.equals("33")){
				throwErrorMessage(884); //son �� sifre ile ayni
			}
			
			myMap.put("MESSAGE_NO", new BigDecimal(883));
			oMap.put("MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
			
			if(isLdapUser){
				iMap.put("PASSWORD", iMap.getString("YENI_SIFRE"));
				GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_BNSPR", iMap);// LDAP_BNSPR
			}
			
			stmt = conn.prepareCall("{call PKG_TRN9909.infomail(?,?,?,?) }");
			int i = 1;	
			stmt.setString(i++,iMap.getString("KULLANICI_KOD"));
			stmt.setString(i++, iMap.getString("YENI_SIFRE"));
			stmt.setString(i++, iMap.getString("DURUM"));
			stmt.setString(i++, iMap.getString("SIFRE_UNUTMA"));
			stmt.execute();
	
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0,e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService(value="BNSPR_CORE_SIFRE_LOGLA",authenticationRequired=false)
	public static HashMap<?, ?> sifreLogla(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		try {
			
			GMMap oMap = new GMMap();
			conn	= DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{call PKG_SIFRE.SIFRE_LOGLA(?,?,?,?,?)}");
			stmt.setString(1, iMap.getString("KULLANICI_KOD"));
			stmt.setString(2, iMap.getString("SIFRE_HASHED"));
			stmt.setString(3, iMap.getString("DURUM"));
			
			stmt.registerOutParameter(4, java.sql.Types.VARCHAR);
			stmt.setString(5, (String)GMContext.getCurrentContext().getSession().get("CLIENT_IP"));
			stmt.execute();
			oMap.put("SONUC", stmt.getString(4));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CORE_GET_SIFRE_DURUMU")
	public static HashMap<?, ?> getSifreDurumu(GMMap iMap){
		iMap.put("SIFRE_DURUMU", DALUtil.callOneParameterFunction("{? = call PKG_SIFRE.Sifre_Durumu(?)}", Types.VARCHAR, iMap.getString("KULLANICI_KOD")));
		return iMap;
	}
	
	
	@GraymoundService("BNSPR_CORE_GET_ROL_GECERLILIK")
	public static HashMap<?, ?> getRolGecerlilik(GMMap iMap){
		iMap.put("SURE_DOLMUS", DALUtil.callNoParameterFunction("{? = call Pkg_Personel.Rol_Gecerlilik_Kontrol()}", Types.VARCHAR)) ;
		return iMap; 
	}	
	
	@GraymoundService("BNSPR_CORE_AKUSTIK_MENU_ROL")
	public static HashMap<?, ?> getAkustikMenuRol(GMMap iMap){
		iMap.put("AKUSTIK_ROL", DALUtil.callNoParameterFunction("{? = call Pkg_Personel.Akustik_Menu_Rol_Kontrol()}", Types.VARCHAR)) ;
		return iMap; 
	}	

	@GraymoundService(value="BNSPR_CORE_GET_KULLANICI_ADI",authenticationRequired=false)
	public static HashMap<?, ?> getKullaniciAdi(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		try {
			
			GMMap oMap = new GMMap();
			conn	= DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_GENEL_PR.kullanici_adi(?)}");
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.registerOutParameter(1, java.sql.Types.VARCHAR);			
			stmt.execute();
			oMap.put("KULLANICI_ADI", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	
	}
	
	@GraymoundService(value="BNSPR_CORE_FORGOT_PASS_OTP_VALIDATE",authenticationRequired=false)
	public static GMMap validateForgotPassOtp(GMMap iMap){
		GMMap oMap = new GMMap();
		iMap.put("ACTION_GROUP", "LOGIN");
		try{
			GMConnection connection = GMConnection.getConnection("SCHEDULER");
			
			GMMap map = new GMMap();
			map.put("CHANNEL_CODE", "MAN");
			map.putAll(connection.serviceCall("ADC_CORE_GET_CHANNEL_BY_CODE", map));
			String bnsprChannelOid = map.getString("CHANNEL_OID");
			iMap.put("CHANNEL_OID", bnsprChannelOid);
			oMap.putAll(connection.serviceCall("ADC_MAN_USER_OTP_VALIDATE", iMap));
			if("0".equals(oMap.getString("RESPONSE"))){
				throw new GMRuntimeException(0, oMap.getString("RESPONSE_DATA")); 
			}	
			
			Session session = DAOSession.getSession(DAO_SESSION_FACTORY_NAME);
			GnlKullSifreUnutma record = (GnlKullSifreUnutma)session.createCriteria(GnlKullSifreUnutma.class)
																.add(Restrictions.eq("kullKod", iMap.getString("KULLANICI_KOD")))
																.add(Restrictions.eq("sifreGonderildi", "C"))
																.uniqueResult();
			
			record.setSifreGonderildi("V");
			session.save(record);
			session.flush();
			
			return oMap;
		}catch(GMRuntimeException ex){
			String message = ex.getMessage();
			if(GMMessageFactory.getMessage("OTPBLOCK" , null).equals(ex.getMessage()))
				message = GMMessageFactory.getMessage("BLOCK_MESSAGE", new GMMap().put("FIELD", "OTP"));
			throw new GMRuntimeException(ex.getCode(), message);
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService(value="BNSPR_CORE_SAVE_FORGOT_PASSWORD",authenticationRequired=false)
	public static GMMap saveForgotPassword(GMMap iMap){
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession(DAO_SESSION_FACTORY_NAME);
		List<GnlKullSifreUnutma> forgotPassList = session.createCriteria(GnlKullSifreUnutma.class)
														 .add(Restrictions.eq("sifreGonderildi", "C"))
														 .add(Restrictions.eq("kullKod", iMap.getString("KULLANICI_KOD")))
														 .list();

		//onceki ara durumda kalmis kayitlari iptal statusune cevir
		for(GnlKullSifreUnutma record : forgotPassList){
			record.setSifreGonderildi("I");
			session.save(record);
			session.flush();
		}
		
		GnlKullSifreUnutma record = new GnlKullSifreUnutma();
		record.setKullKod(iMap.getString("KULLANICI_KOD"));
		
		record.setOtpTel(iMap.getString("KULLANICI_OTP_TEL"));
		String clientIp = (String) GMContext.getCurrentContext().getSession().get("CLIENT_IP");
		record.setIpAdres(clientIp);
		record.setUserOid(iMap.getString("USER_OID"));
		
		session.save(record);
		
		return oMap;
	}
	
	
	@SuppressWarnings("unchecked")
	@GraymoundService(value="BNSPR_CORE_FORGOT_PASSWORD_JOB")
	public static GMMap forgotPasswordJob(GMMap iMap){
		GMMap oMap = new GMMap();
		
		ADCSession.put("CHANNEL", "BNSPR");
		
		Session session = DAOSession.getSession(DAO_SESSION_FACTORY_NAME);
		List<GnlKullSifreUnutma> forgotPassList = session.createCriteria(GnlKullSifreUnutma.class)
														 .add(Restrictions.or(Restrictions.isNull("sifreGonderildi"), 
																			  Restrictions.in("sifreGonderildi", new String[]{"V"})))
														 .addOrder(Order.desc("lastupdated"))
														 .list();
		
		List<String> processedUsers = new ArrayList<String>();
		
		GMMap map = new GMMap();
		map.put("CHANNEL_CODE", "MAN");
		String bnsprChannelOid = GMServiceExecuter.call("ADC_CORE_GET_CHANNEL_BY_CODE", map).getString("CHANNEL_OID");
		
		for(GnlKullSifreUnutma record : forgotPassList){
			
			try{
				if(record.getSifreGonderildi() == null){ //otp gonderimi yapilacak, basarili olursa statu C'ye cevrilecek
					if(processedUsers.contains(record.getKullKod())){
						record.setSifreGonderildi("I"); // Iptal
					}
					else{
						processedUsers.add(record.getKullKod());
						
						GMMap sMap = new GMMap();
						
						sMap.put("USER_OID", 	 record.getUserOid());
						sMap.put("CHANNEL_OID",  bnsprChannelOid );
						sMap.put("PHONE_NUMBER", record.getOtpTel() );
						
						
						try{
							GMServiceExecuter.call("ADC_MAN_USER_OTP_CREATE", sMap);
							record.setSifreGonderildi("C"); // C:otp created => kaydi otp gonderilmis olarak guncelle
						}
						catch(Exception e){
							logger.error(e);
							record.setSifreGonderildi("I"); // Iptal -- Hata alan kaydi iptal et tekrar tekrar gonderim denemesi olmasin
						}
					}
					
				} 
				else if("V".equals(record.getSifreGonderildi())){ //V:otp dogrulanmis => sifre gonderilecek

					iMap.put("KULLANICI_KOD", record.getKullKod());
					GMServiceExecuter.call("BNSPR_CORE_ADMIN_SIFRE_DEGISTIR", iMap);

					record.setSifreGonderildi("E");
					record.setSifreGonderimTarih(new Date());
					
				}
				
				session.saveOrUpdate(record);
				session.flush();

			}catch(Exception ex){
				logger.warn(ex.getMessage());
			}
			
		}
		
		return oMap;
	}

	@GraymoundService(value="BNSPR_CORE_GET_KULLANICI_OTP_TEL",authenticationRequired=false)
	public static HashMap<?, ?> getKullaniciOtpTel(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		try {
			
			GMMap oMap = new GMMap();
			conn	= DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_TRN9909.kullanici_otp_tel(?)}");
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.registerOutParameter(1, java.sql.Types.VARCHAR);			
			stmt.execute();
			oMap.put("KULLANICI_OTP_TEL", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	
	}	

	@GraymoundService(value="BNSPR_CORE_GET_KULLANICI_ROL_KOD",authenticationRequired=false)
	public static HashMap<?, ?> getKullaniciRolKod(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		try {
			
			GMMap oMap = new GMMap();
			conn	= DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_TRN9909.sf_kullanici_rolkod_al(?)}");
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.registerOutParameter(1, java.sql.Types.VARCHAR);			
			stmt.execute();
			oMap.put("KULLANICI_ROL_KOD", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	
	}	

	@GraymoundService(value="BNSPR_CORE_GET_KULLANICI_CUSTOMER_NO",authenticationRequired=false)
	public static HashMap<?, ?> getKullaniciMusteriNo(GMMap iMap){
		Connection			conn = null;
		CallableStatement	stmt = null;
		try {
			
			GMMap oMap = new GMMap();
			conn	= DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_PERSONEL.GET_PERSONEL_MUSTERI_NO(?)}");
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.registerOutParameter(1, java.sql.Types.NUMERIC);			
			stmt.execute();
			oMap.put("MUSTERI_NO", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	
	}	
	
	@GraymoundService(value="BNSPR_CORE_GET_APPLICATION_TYPE")
	public static GMMap getApplicationType(GMMap iMap){	
		GMMap oMap = new GMMap();
		try{
			oMap.put("APP_TYPE", ADCSession.getString("APP_TYPE_RESERVED"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	@GraymoundService("BNSPR_CORE_CREATE_USER_OTP")
	public static GMMap createUserOtp(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			GMMap map = new GMMap();
			map.put("CHANNEL_CODE", "MAN");
			String bnsprChannelOid = GMServiceExecuter.call("ADC_CORE_GET_CHANNEL_BY_CODE", map).getString("CHANNEL_OID");
			iMap.put("CHANNEL_OID",  bnsprChannelOid );
			
			oMap = GMServiceExecuter.call("ADC_MAN_USER_OTP_CREATE", iMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_CORE_VALIDATE_USER_OTP")
	public static GMMap validateOtp (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			GMMap map = new GMMap();
			map.put("CHANNEL_CODE", "MAN");
			String bnsprChannelOid = GMServiceExecuter.call("ADC_CORE_GET_CHANNEL_BY_CODE", map).getString("CHANNEL_OID");
			iMap.put("CHANNEL_OID", bnsprChannelOid);
			oMap = GMServiceExecuter.call("ADC_MAN_USER_OTP_VALIDATE", iMap);
			if("0".equals(oMap.getString("RESPONSE"))){
				throw new GMRuntimeException(0, oMap.getString("RESPONSE_DATA")); 
			}
		}catch(GMRuntimeException ex){
			String message = ex.getMessage();
			if(GMMessageFactory.getMessage("OTPBLOCK" , null).equals(ex.getMessage()))
				// message = GMMessageFactory.getMessage("BLOCK_MESSAGE", new GMMap().put("FIELD", "OTP"));
				throwErrorMessage(5644);
			
			 throw new GMRuntimeException(ex.getCode(), message);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	private static void throwErrorMessage(int errorKod){
		GMMap myMap = new GMMap();
		myMap.put("MESSAGE_NO", new BigDecimal(errorKod));
		throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
	}
}
