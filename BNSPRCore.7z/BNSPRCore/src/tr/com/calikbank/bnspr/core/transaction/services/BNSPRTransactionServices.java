package tr.com.calikbank.bnspr.core.transaction.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.AppuserbranchLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class BNSPRTransactionServices {

	private static ArrayList<String> onaysizIslemList = null;

	private static ArrayList<String> cagiranIslemList = null;

	private static Logger l = Logger.getLogger(BNSPRTransactionServices.class);

	private static void logDebug(String msg) {
		if (l.isDebugEnabled())
			l.debug(msg);
	}

	@GraymoundService("BNSPR_CORE_SET_USER_BRANCH")
	public static GMMap setBranchList(GMMap iMap) {

		GMContext.getCurrentContext().getSession().put("BRANCH_ID", iMap.getString("BRANCH_ID"));
		try {
			GMServiceExecuter.execute("BNSPR_CORE_APP_USER_BRANCH_LOG", iMap);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return new GMMap();

	}

	@GraymoundService("BNSPR_CORE_APP_USER_BRANCH_LOG")
	public static GMMap appUserBranchLog(GMMap iMap) {

		String usercode = iMap.getString("USER_CODE", "");
		String rolecode = iMap.getString("ROLE_CODE", "");
		String branchcode = iMap.getString("BRANCH_ID", "");
		String guimlname = iMap.getString("GUIML_NAME", "");

		logDebug("USER_CODE:" + usercode + ", ROLE_CODE:" + rolecode + ", BRANCH_ID:" + branchcode + ", GUIML_NAME:" + guimlname);

		if (usercode.trim().length() == 0) {
			usercode = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANICI_KOD", iMap).get("KULLANICI_KOD");
			logDebug("USER_CODE:" + usercode);
		}

		if (rolecode.trim().length() == 0) {
			rolecode = GMContext.getCurrentContext().getSession().get("ROLE_ID") == null ? "" : GMContext.getCurrentContext().getSession().get("ROLE_ID").toString();

			if (rolecode.trim().length() == 0) {
				Connection conn = null;
				CallableStatement stmt = null;

				try {
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{? = call pkg_global.GET_ROLKOD()}");
					stmt.registerOutParameter(1, Types.VARCHAR);
					stmt.execute();
					rolecode = stmt.getString(1);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					GMServerDatasource.close(stmt);
					GMServerDatasource.close(conn);
				}
			}

			logDebug("ROLE_CODE:" + rolecode);

		}

		if (branchcode.trim().length() == 0) {
			branchcode = GMContext.getCurrentContext().getSession().get("BRANCH_ID") == null ? "" : GMContext.getCurrentContext().getSession().get("BRANCH_ID").toString();
		}

		logDebug("BRANCH_ID:" + branchcode);

		BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getBigDecimal("SIRA_NO");
		BigDecimal rc = null;

		try {
			rc = new BigDecimal(rolecode);
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		AppuserbranchLog log = new AppuserbranchLog();
		log.setId(id);
		log.setBranchcode(branchcode);
		log.setGuiml(guimlname);
		log.setRolecode(rc);
		log.setUsercode(usercode);

		Session session = DAOSession.getSession("BNSPRDal");
		session.save(log);
		session.flush();

		return new GMMap();

	}

	@GraymoundService("BNSPR_CORE_GET_BRANCH_LIST")
	public static GMMap getBranchList(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("LIST", 0, "CODE", "300");
		oMap.put("LIST", 0, "NAME", "200 - Merkez");

		oMap.put("LIST", 1, "CODE", "201");
		oMap.put("LIST", 1, "NAME", "201 - Merkez+1");

		return oMap;
	}

	@GraymoundService("BNSPR_TRX_GET_TRANSACTION_NO")
	public static GMMap getTransactionNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TX.islem_no_al()}");

			stmt.registerOutParameter(1, Types.INTEGER);
			stmt.execute();

			Object obj = stmt.getObject(1);

			oMap.put("TRX_NO", obj.toString());

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRX_SEND_TRANSACTION")
	public static GMMap sendTransaction(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		CallableStatement stmt3 = null;

		try {
			getOnaysizIslemList();
			String transactionName = iMap.getString("TRX_NAME");
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			String script = null;
			String onaysizIslem = iMap.get("TRX_ONAYSIZ_ISLEM") == null? "" : iMap.getString("TRX_ONAYSIZ_ISLEM");
			String cagiranIslem = iMap.get("CAGIRAN_TRX_NO") == null? "" : "E";
			
			
			// Ic ice calisan islemlerde alt islemlerin onaysiz gerceklesebilmesi
			// Orn: Kredi basvurusunda musteri bilgi guncelleme
			if (("E".equals(onaysizIslem)|| "B".equals(onaysizIslem)) && getOnaysizIslemList().contains("PKG_TRN" + transactionName)){
			
				if (("E".equals(cagiranIslem)) && getCagiranIslemList().contains("PKG_TRN" + transactionName)){
						script = " begin " //
								+ "  ? := PKG_TRN" + transactionName + ".transaction_start(? , '"+onaysizIslem+"', ?); " //
								+ " end; ";
				}
				else {
					script = " begin " //
							+ "  ? := PKG_TRN" + transactionName + ".transaction_start(? , '"+onaysizIslem+"'); " //
							+ " end; ";
				}
			}
			else {
				if (("E".equals(cagiranIslem)) && getCagiranIslemList().contains("PKG_TRN" + transactionName)){
					if (getOnaysizIslemList().contains("PKG_TRN" + transactionName)){
						script = "{? = call PKG_TRN" + transactionName + ".transaction_start(?,'H',?)}";
					}
					else
     				    script = "{? = call PKG_TRN" + transactionName + ".transaction_start(?,?)}";
     			}
			    else {
     				script = "{? = call PKG_TRN" + transactionName + ".transaction_start(?)}";
			    }
			}		
			stmt = conn.prepareCall(script);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			if (("E".equals(cagiranIslem)) && getCagiranIslemList().contains("PKG_TRN" + transactionName)){
     			stmt.setBigDecimal(3, iMap.getBigDecimal("CAGIRAN_TRX_NO"));
			}	
			stmt.execute();

			// gonderilmek istenen ek bir mesaj var ise onu gosterecek, yoksa defaultu "" olacak.
			oMap.put("MESSAGE", stmt.getString(1) + " " + iMap.getString("EK_MESAJ", ""));
			
			if(!onaysizIslem.equals("B")){
			
			//��lem do�rulamas� gerekmiyorsa do�rulama servisi �a�r�ls�n
			stmt3 = conn.prepareCall("{? = call pkg_tx.kalan_dogrulama_sayisi(?)}");
			stmt3.registerOutParameter(1, Types.NUMERIC);
			stmt3.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt3.execute();
			
			if (stmt3.getInt(1)==0){
				GMServiceExecuter.execute("BNSPR_ISLEM_EXECUTE_POST_SERVICE", new GMMap().put("ISLEM_KODU", new BigDecimal(transactionName)).put("ISLEM_TURU", "D").put("ISLEM_NO", iMap.getBigDecimal("TRX_NO")));
			}


			// eger islem onay gerektirmeyen bir islemse otomatikman onaylanmis olacaktir, bu durumda islemin onay sonrasi servisi varsa calistir
			stmt2 = conn.prepareCall("{? = call PKG_TX.Islem_tamamlanmis_mi(?)}");
			stmt2.registerOutParameter(1, Types.NUMERIC);
			stmt2.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt2.execute();
			int tamamlanmismi = stmt2.getInt(1); // 0 tamamlandi, 1 tamamlanmadi anlamina geliyor
			if (tamamlanmismi == 0)
				GMServiceExecuter.execute("BNSPR_ISLEM_EXECUTE_POST_SERVICE", new GMMap().put("ISLEM_KODU", new BigDecimal(transactionName)).put("ISLEM_TURU", "O").put("ISLEM_NO", iMap.getBigDecimal("TRX_NO")));
			oMap.put("TX_STATUS", String.valueOf(tamamlanmismi));
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

			//
			//
			// String result ="";
			// String message = e.getMessage().replace("ORA-20001:","");
			// int pipeIndex = message.indexOf("||");
			// while (pipeIndex != -1){
			// message = message.substring(pipeIndex+2,message.length()-2);
			//
			// pipeIndex = message.indexOf("||");
			// if (pipeIndex != -1){
			// result += message.substring(0,pipeIndex)+"\n";
			// }
			// }
			// if("".equals(result))
			// throw new GMRuntimeException(0,e);
			// else
			// throw new GMRuntimeException(0,result);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRX_SEND_TRANSACTION_TEMP")
	public static GMMap sendTransactionTemp(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			String transactionName = iMap.getString("TRX_NAME");
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN" + transactionName + ".transaction_start_temp(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			oMap.put("MESSAGE", stmt.getString(1));
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_CORE_GET_USER_INFO")
	public static GMMap getUserInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			String username = (String) GMContext.getCurrentContext().getSession().get("USER_NAME");

			if (username == null) {
				username = "BNSPR";
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_GLOBAL.GET_USER_GLOBALS2(?,?,?,?)}");
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.DATE);
			stmt.registerOutParameter(4, Types.VARCHAR);

			stmt.setString(1, username);

			stmt.execute();

			String branchId = stmt.getString(2);
			String workingDate = new SimpleDateFormat("dd.MM.yyyy").format(stmt.getDate(3));
			String roleID = stmt.getString(4);

			GMContext.getCurrentContext().getSession().put("BRANCH_ID", branchId);
			GMContext.getCurrentContext().getSession().put("WORKING_DATE", workingDate);
			GMContext.getCurrentContext().getSession().put("ROLE_ID", roleID);

			GMMap oMap = new GMMap();

			oMap.put("BRANCH_ID", branchId);
			oMap.put("WORKING_DATE", workingDate);
			oMap.put("ROLE_ID", roleID);

			String[] data = new String[4];
			data[0] = username;
			data[1] = stmt.getString(2);
			data[2] = workingDate;
			data[3] = stmt.getString(4);

			oMap.put("STATUS_BAR_DATA", data);
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService(value = "BNSPR_CORE_AUTHENTICATE", authenticationRequired = false)
	public static Map<?, ?> coreAuthenticate(Map<String, Object> iMap) {
		GMServiceExecuter.execute("BNSPR_USER_AUTHENTICATE", iMap);
		GMServiceExecuter.execute("BNSPR_CORE_GET_USER_INFO", iMap);
		// GMServiceExecuter.execute("GM_ADM_USER_AUTHENTICATE", iMap);
		return GMServiceExecuter.execute("BNSPR_CORE_GET_USER_INFO", iMap);
	}

	@GraymoundService(value = "BNSPR_CORE_AUTHENTICATE_TEST", authenticationRequired = false)
	public static Map<?, ?> coreAuthenticateTest(Map<String, Object> iMap) {
		GMServiceExecuter.execute("GM_ADM_USER_AUTHENTICATE_TEST", iMap);
		return GMServiceExecuter.execute("BNSPR_CORE_GET_USER_INFO", iMap);
	}

	private static ArrayList<String> getOnaysizIslemList() {
		if (onaysizIslemList == null) {
			onaysizIslemList = new ArrayList<String>();
			String func = "{ ? = call PKG_UTIL.onaysiz_islem_list}";
			try {
				GMMap islemMap = new GMMap(DALUtil.callOracleRefCursorFunction(func, "RESULTS", new Object[0]));
				for (int i = 0; i < islemMap.getSize("RESULTS"); i++) {
					onaysizIslemList.add(islemMap.getString("RESULTS", i, "PACKAGE_NAME"));
				}
			}
			catch (SQLException e) {
				throw ExceptionHandler.convertException(e);
			}

		}
		return onaysizIslemList;
	}
	private static ArrayList<String> getCagiranIslemList() {
		if (cagiranIslemList == null) {
			cagiranIslemList = new ArrayList<String>();
			String func = "{ ? = call PKG_UTIL.onaysiz_islem_list}";
			try {
				GMMap islemMap = new GMMap(DALUtil.callOracleRefCursorFunction(func, "RESULTS", new Object[0]));
				for (int i = 0; i < islemMap.getSize("RESULTS"); i++) {
					cagiranIslemList.add(islemMap.getString("RESULTS", i, "PACKAGE_NAME"));
				}
			}
			catch (SQLException e) {
				throw ExceptionHandler.convertException(e);
			}

		}
		return cagiranIslemList;
	}
}
