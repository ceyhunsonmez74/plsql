package tr.com.calikbank.bnspr.core.transaction.services;

import com.graymound.connection.GMConnection;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class BNSPRThreadExecuter implements Runnable{
	private GMMap oMap;
	private GMMap iMap;
	private GMConnection conn;
	public BNSPRThreadExecuter(GMMap iMap) {
		this.iMap = iMap;
	}
	
	@Override
	public void run() {
		try {
			conn =  GMConnection.getConnection("BANKING");
			oMap = new GMMap(conn.serviceCall(iMap.getString("SERVICE_NAME"), iMap));
		} catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}

	public GMMap getOMap() {
		return oMap;
	}

	public void setOMap(GMMap map) {
		oMap = map;
	}
}
