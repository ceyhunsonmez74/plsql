package tr.com.aktifbank.bnspr.core.esb.services;

import com.graymound.connection.GMConnection;
import com.graymound.util.GMMap;

public class AppServerConnection {

	public static String notifyEvent(String eventNo){
		try {
			GMConnection conn= GMConnection.getConnection("BNSPR");
			GMMap parameters = new GMMap();
			parameters.put("EVENT_NO", eventNo);
			conn.serviceCall("BNSPR_CORE_EVENT_DISPATCHER_ASYNC", parameters);
		} catch (Exception e){
			e.printStackTrace();
			return e.getMessage();
		}
		return "OK";
	}
	public static void main (String[] argv){
		AppServerConnection.notifyEvent("1");
	}
}