package tr.com.aktifbank.bnspr.core.logging.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import tr.com.aktifbank.bnspr.dao.AdkKategori;
import tr.com.aktifbank.bnspr.dao.AdkKategoriislem;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.dao.GnlKullanici;
import tr.com.obss.adc.core.pojo.Channel;
import tr.com.obss.adc.core.pojo.LanguageData;
import tr.com.obss.adc.core.pojo.Process;
import tr.com.obss.adc.core.pojo.ProcessLog;
import tr.com.obss.adc.core.pojo.ProcessLogDetail;
import tr.com.obss.adc.core.pojo.Role;
import tr.com.obss.adc.core.pojo.User;
import tr.com.obss.adc.core.pojo.UserActionLog;
import tr.com.obss.adc.core.util.ADCCore;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.referencedata.GMReferenceDataFactory;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ADCTransactionLogMonitoringServices {
	// Status codes for process logs
	private static final String ALL = "2";
	private static final String SUCCESS = "1";
	private static final String FAIL = "0";
	
	private static List<String> getLogChannels() {
		ArrayList<String> channelOidList = new ArrayList<String>();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

		Iterator<?> iterator = session.createCriteria(Channel.class).addOrder(
				Order.asc("code")).list().iterator();

		List<?> channels = GMReferenceDataFactory
				.getReferenceData("LOGCHANNELS");
		GMMap channelMap = new GMMap();
		Iterator<?> iter = channels.iterator();
		while (iter.hasNext()) {
			HashMap<?, ?> item = (HashMap<?, ?>) iter.next();
			channelMap.put(item.get("CODE"), item.get("NAME"));
//			System.out.println(item.getClass().getName());
		}
		while (iterator.hasNext()) {
			Channel channel = (Channel) iterator.next();
			if (channelMap.containsKey(channel.getCode())) {
				channelOidList.add(channel.getOid());
			}
		}

		return channelOidList;		
	}
	
	private static List<String> getCustomerUserOids(String customerNo) {
		
		BigDecimal customerNoAsNumber = new BigDecimal(customerNo);
		ArrayList<String> customerUserOids = new ArrayList<String>();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		
		List<User> userList = session.createCriteria(User.class).add(Restrictions.or(Restrictions.eq("customerId", customerNoAsNumber), Restrictions.eq("userCustomerId", customerNoAsNumber))).list();
		
//		List<UserIntegration> userIntegrationList = (List<UserIntegration>) session.createCriteria(UserIntegration.class)
//		.add(Restrictions.eq("key", "MUSTERI_NO"))
//		.add(Restrictions.eq("value", customerNo)).list();

		if (userList == null || userList.size()==0) {
			throw new GMRuntimeException(0, GMMessageFactory
				.getMessage("LOGMONERR01", null), true);
		}
		for(int i=0;i<userList.size();i++){
			customerUserOids.add(userList.get(i).getOid());
		}
		
		return customerUserOids;
	}
	
	private static List<String> getRoleSessions(String roleOid) {
		ArrayList<String> sessionIdList = new ArrayList<String>();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		Iterator<?> iterator = session.createCriteria(UserActionLog.class)
			.add(Restrictions.eq("actionGroup", "LOGIN"))
			.add(Restrictions.eq("action", "ROLE"))
			.add(Restrictions.eq("resultData", roleOid))
			.add(Restrictions.eq("channelOid", ADCSession.get("CC_CHANNEL_OID_FOR_LOG"))).list().iterator();
		while (iterator.hasNext()) {
			UserActionLog userActionLog = (UserActionLog) iterator.next();
			sessionIdList.add(userActionLog.getSessionId());
		}
		return sessionIdList;		
	}	
	
	private static List<String> getProcessOidListOfType(String processType) {
		ArrayList<String> processOidList = new ArrayList<String>();
		Session session = DAOSession.getSession("BNSPRDal");
		Iterator<?> iterator = ((List<AdkKategoriislem>) session.createCriteria(AdkKategoriislem.class).add(Restrictions.eq("id.kategoriOid", processType)).list()).iterator();
		while (iterator.hasNext()) {
			AdkKategoriislem kategoriislem = (AdkKategoriislem) iterator.next();
			processOidList.add(kategoriislem.getId().getIslemOid());
		}
		return processOidList;		
	}
	
	
	@GraymoundService("GET_ADC_CHANNEL_LIST")
	public static GMMap getChannelList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		int row = 0;

		oMap.put("CHANNEL_LIST", new ArrayList<Object>());

		Iterator<?> iterator = session.createCriteria(Channel.class).addOrder(
				Order.asc("code")).list().iterator();

		oMap.put("CHANNEL_LIST", row, "OID", 0);
		oMap.put("CHANNEL_LIST", row, "CODE", "NONE");
		oMap.put("CHANNEL_LIST", row++, "NAME", GMMessageFactory.getMessage("PLSSELECT", null));

		List<?> channels = GMReferenceDataFactory
				.getReferenceData("LOGCHANNELS");
		GMMap channelMap = new GMMap();
		Iterator<?> iter = channels.iterator();
		while (iter.hasNext()) {
			HashMap<?, ?> item = (HashMap<?, ?>) iter.next();
			channelMap.put(item.get("CODE"), item.get("NAME"));
//			System.out.println(item.getClass().getName());
		}
		while (iterator.hasNext()) {
			Channel channel = (Channel) iterator.next();
			if (channelMap.containsKey(channel.getCode())) {
				if("CC".equals(channel.getCode())){
					ADCSession.put("CC_CHANNEL_OID_FOR_LOG", channel.getOid());
				}
				oMap.put("CHANNEL_LIST", row, "OID", channel.getOid());
				oMap.put("CHANNEL_LIST", row, "CODE", channel.getCode());
				oMap.put("CHANNEL_LIST", row, "NAME", channel.getName(ADCSession.getLanguage()));
				row++;
			}

		}

		oMap.put("ROW_COUNT", row);

		return oMap;
	}
	
	@GraymoundService("GET_ADC_ROLE_LIST")
	public static GMMap getRoleList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		int row = 0;

		oMap.put("ROLE_LIST", new ArrayList<Object>());

		Iterator<?> iterator = session.createCriteria(Role.class).add(Restrictions.eq("channelOid", ADCSession.get("CC_CHANNEL_OID_FOR_LOG"))).addOrder(
				Order.asc("code")).list().iterator();

		oMap.put("ROLE_LIST", row, "OID", 0);
		oMap.put("ROLE_LIST", row, "CODE", "NONE");
		oMap.put("ROLE_LIST", row++, "NAME", GMMessageFactory.getMessage("PLSSELECT", null));

		while (iterator.hasNext()) {
			Role role = (Role) iterator.next();
			oMap.put("ROLE_LIST", row, "OID", role.getOid());
			oMap.put("ROLE_LIST", row, "CODE", role.getCode());
			oMap.put("ROLE_LIST", row, "NAME", role.getName(ADCSession.getLanguage()));
			row++;
		}

		oMap.put("ROW_COUNT", row);

		return oMap;
	}

	public static String getProcessOidByProcessCode(String processCode){
		String processOid = "";
		try {
			Iterator<?> iterator = null;
			Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
			iterator = session.createCriteria(Process.class)
					.add(Restrictions.eq("code", processCode))
					.list().iterator();
			if (iterator.hasNext()) {
				Process process = (Process) iterator.next();
				processOid = process.getOid();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return processOid;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("GET_ADC_PROCESS_LIST")
	public static GMMap getProcessList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		int row = 0;
		String processType = iMap.getString("PROCESS_TYPE");
		Iterator<?> iterator = null;

		if (processType == null || processType.equals("NONE")) {
			iterator = session.createCriteria(Process.class).addOrder(
					Order.asc("code")).list().iterator();
		} else {

			iterator = session.createCriteria(Process.class).add(
					Restrictions.eq("type", iMap.getString("PROCESS_TYPE")))
					.addOrder(Order.asc("code")).list().iterator();
		}
		String language = ADCSession.getLanguage();
		ArrayList<String> processOids = new ArrayList<String>();
		
		Map<String,Integer> processOidIndexMap = new HashMap<String, Integer>();
		
		while (iterator.hasNext()) {
			Process process = (Process) iterator.next();

			oMap.put("PROCESS_LIST", row, "OID", process.getOid());
			processOids.add(process.getOid());
			oMap.put("PROCESS_LIST", row, "CODE", process.getCode());
			
			processOidIndexMap.put(process.getOid(), row);
			
			row++;
		}
		if(processOids.size() == 0){
			return oMap;
		}
		
		List<LanguageData> languageDataList = (List<LanguageData>)session.createCriteria(LanguageData.class).
			add(Restrictions.eq("ownerKey", "NAME")).
			add(Restrictions.in("ownerOid", processOids.toArray())).list();
		
		for(Iterator<LanguageData> langIterator = languageDataList.iterator(); langIterator.hasNext(); ) {
			LanguageData languageData = langIterator.next();
			Integer index = processOidIndexMap.get(languageData.getOwnerOid());

			if(index != null) {
				oMap.put("PROCESS_LIST", index, "NAME", languageData.getData());
			}
			
		}
		
		return oMap;
	}

	@GraymoundService("GET_ADC_PROCESS_TYPE_LIST")
	public static GMMap getProcessTypeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<AdkKategori> kategoriList = (List<AdkKategori>) session.createCriteria(AdkKategori.class).list();
		int size = 0;
		if(kategoriList != null){
			size =	kategoriList.size();
		}
		oMap.put("PROCESS_TYPE_LIST", 0, "OID", "NONE");
		oMap.put("PROCESS_TYPE_LIST", 0, "CODE", "NONE");
		oMap.put("PROCESS_TYPE_LIST", 0, "NAME", GMMessageFactory.getMessage("PLSSELECT", null));		
		
		for(int i=1;i<=size;i++){
			oMap.put("PROCESS_TYPE_LIST", i, "OID", kategoriList.get(i-1).getOid());
			oMap.put("PROCESS_TYPE_LIST", i, "CODE", kategoriList.get(i-1).getOid());
			oMap.put("PROCESS_TYPE_LIST", i, "NAME",kategoriList.get(i-1).getName());			
		}
		oMap.put("ROW_COUNT",size+1);

		return oMap;
	}

	@GraymoundService("FILL_LOG_DETAIL")
	public static GMMap fillLogDetail(GMMap iMap) throws GMRuntimeException {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		int row = 0;
		String processLogOid = iMap.getString("LOG_OID");

		oMap.put("LIST", new ArrayList<Object>());

		List<?> processLogs = (List<?>) session.createCriteria(
				ProcessLogDetail.class).add(
				Restrictions.eq("processLogOid", processLogOid)).addOrder(
				Order.asc("sortOrder")).list();

		Iterator<?> iterator = processLogs.iterator();
		while (iterator.hasNext()) {
			ProcessLogDetail logDetail = (ProcessLogDetail) iterator.next();

			if (logDetail.getDescription() != null)
				oMap.put("LIST", row, "colAttributeName", logDetail
						.getDescription());
			else
				oMap.put("LIST", row, "colAttributeName", logDetail.getKey());

			oMap.put("LIST", row, "colAttributeValue", logDetail.getValue());
			row++;
		}
		oMap.put("ROW_COUNT", row);
		return oMap;
	}

	@GraymoundService("GET_ADC_PROCESS_LOG")
	public static GMMap getLog(GMMap iMap) throws GMRuntimeException {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		
		String processOid = iMap.getString("PROCESS_OID");
		String status = iMap.getString("STATUS");
		String channelOid = iMap.getString("CHANNEL_OID");
		String userCode = iMap.getString("USER_CODE");
		String processType = iMap.getString("PROCESS_TYPE");
		String customerNo = iMap.getString("CUSTOMER_NO");
		String role = iMap.getString("ROLE");
		String parentUserOid = iMap.getString("PARENT_USER_OID");

		Date startDate = null;
		Date endDate = null;
		long period = 0;
		int row = 0;

		SimpleExpression userExp = null;
		SimpleExpression parentUserExp = null;
		Criterion customerExp = null;
		SimpleExpression processExp = null;
		Criterion channelExp = null;
		SimpleExpression statusExp = null;
		Criterion roleExp = null;
		Criterion processTypeExp = null;

		long MAX_ALLOWED_PERIOD = Long.parseLong(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_PERIOD",
						"CODE"));
		int MAX_ROWS = Integer.parseInt(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_ROWS",
						"CODE"));
		int count = iMap.getInt("COUNT");
		if(count > 0) {
			MAX_ROWS = Math.min(count, MAX_ROWS);
		}
		
		GMMap messageParam = new GMMap();

		try {
			startDate = iMap.getDate("START_DATE");
			endDate = iMap.getDate("END_DATE");
		} catch (Throwable e) {
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHDATEERROR", null));
			}
		}
		
		if (startDate == null || endDate == null) {
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHDATEERROR", null));
			}else{
				if (startDate == null){
					startDate = new Date(0);
					if(iMap.getBoolean("LAST_YEAR")){
						Calendar cal = Calendar.getInstance();
						cal.add(Calendar.YEAR, -1);
						startDate = cal.getTime();
					}
				}
				if (endDate == null){
					Calendar cal = Calendar.getInstance();
					if(!iMap.getBoolean("LAST_YEAR")){
						cal.add(Calendar.YEAR, 1);
					}
					endDate = cal.getTime();
				}
			}			
		}

		period = (endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24);
		if (period > MAX_ALLOWED_PERIOD) {
			messageParam.put("MAX_ALLOWED_PERIOD", MAX_ALLOWED_PERIOD);
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHMAXPERIODERR", messageParam));
			}
		}

		List<?> processLogs = null;
		{
			if (userCode != null && !userCode.equals("")) {
				User user = (User) session.createCriteria(User.class).add(
						Restrictions.eq("username", userCode)).uniqueResult();

				if (user == null) {
					throw new GMRuntimeException(0, GMMessageFactory
							.getMessage("LOGMONERR01", null), true);
				}
				userExp = Restrictions.eq("userOid", user.getOid());
			}
			
			if (customerNo != null && !customerNo.equals("")) {
				List<String> customerUserOids = getCustomerUserOids(customerNo);
				if(customerUserOids.size() == 0){
					return oMap;
				}
				customerExp = Restrictions.in("parentUserOid", customerUserOids.toArray());
			}
			
			if (parentUserOid != null && !parentUserOid.equals("")) {
				parentUserExp = Restrictions.eq("parentUserOid", parentUserOid);
			}

			if (processOid != null && !processOid.equals("0")) {
				processExp = Restrictions.eq("processOid", processOid);
			}

			if (channelOid != null && !channelOid.equals("0")) {
				channelExp = Restrictions.or(
						Restrictions.eq("channelOid", channelOid), 
						Restrictions.eq("boundChannelOid", channelOid) 
						); 
			} else {
				List<String> logChannels = getLogChannels();
				if(logChannels.size() == 0){
					return oMap;
				}
				channelExp = Restrictions.in("channelOid", logChannels.toArray());
			}
			if (status != null && !status.equals(ALL)) {
				statusExp = Restrictions.eq("status", status);
			}
			if (role != null && !role.equals("0")) {
				List<String> sessionlist = getRoleSessions(role);
				if(sessionlist.size() == 0){
					return oMap;
				}
				roleExp = Restrictions.in("sessionId", sessionlist.toArray());
			}
			iMap.putAll(GMServiceExecuter.execute("GET_PROCESS_LIST_TYPE", iMap));
			if (processType != null && !processType.equalsIgnoreCase("NONE")) {
				List<String> processOidList = getProcessOidListOfType(processType);
				if(processOidList.size() == 0){
					return oMap;
				}
				processTypeExp = Restrictions.in("processOid", processOidList.toArray());
			}


			SimpleExpression startDateExp = Restrictions.ge("lastupdated",
					startDate);
			SimpleExpression endDateExp = Restrictions.le("lastupdated",
					endDate);
			Criteria query = session.createCriteria(ProcessLog.class);
			if (userExp != null)
				query.add(userExp);				
			if (parentUserExp != null){
				query.add(parentUserExp);
			}else if (customerExp != null){
				query.add(customerExp);
			}				
			if (processExp != null)
				query.add(processExp);
			if (channelExp != null)
				query.add(channelExp);
			if (statusExp != null)
				query.add(statusExp);
			if (roleExp != null)
				query.add(roleExp);
			if (processTypeExp != null)
				query.add(processTypeExp);
			

			query.add(startDateExp).add(endDateExp);
			query.addOrder(Order.desc("lastupdated"));
						
			query.setMaxResults(MAX_ROWS);
			
//			System.out.println("ProcessLog Query : "+ query);
			
			processLogs = (List<?>) query.list();
		}

		oMap.put("LOG_LIST", new ArrayList<Object>());

		Iterator<?> iterator = processLogs.iterator();
		HashMap<String, Object> cache = new HashMap<String, Object>();
		SimpleDateFormat outputFormat = new SimpleDateFormat(
				"dd/MM/yy HH:mm:ss");
		SimpleDateFormat outputFormatTime = new SimpleDateFormat("HHmmss");
		
		iMap.putAll(GMServiceExecuter.execute("GET_PROCESS_LIST_TYPE", iMap));
		
		int maxRows = MAX_ROWS + 2;
		if(iMap.containsKey("COUNT")){
			maxRows = iMap.getInt("COUNT");
		}
		
		while (iterator.hasNext() && row < maxRows) {
			ProcessLog log = (ProcessLog) iterator.next();
			
			if("2".equals(log.getProcessKey()) || (log.getAmount() != null && log.getAmount().compareTo(new BigDecimal(0))<0)){
				continue;
			}	
			
			String processMainType = "";
			String processOidTemp = log.getProcessOid();
			if(processOidTemp != null){
				for(int k=0;k<iMap.getSize("PROCESS_LIST_TYPE");k++){
					if(processOidTemp.equals(iMap.getString("PROCESS_LIST_TYPE",k,"ISLEM_OID"))){
						processMainType = iMap.getString("PROCESS_LIST_TYPE",k,"KATEGORI_NAME");
					}
				}
			}			
			
			if(log.getAmount() != null){
				oMap.put("LOG_LIST", row, "colAmount", log.getAmount().toPlainString() + " " + getDovizBasimKodu(log.getAmountCode(),cache));
			}else{
				oMap.put("LOG_LIST", row, "colAmount", "");
			}			
			oMap.put("LOG_LIST", row, "colUserIp", log.getUserIP());
			oMap.put("LOG_LIST", row, "colSource", "A");
			oMap.put("LOG_LIST", row, "colLogOid", log.getOid());
			oMap.put("LOG_LIST", row, "colStatus", getReferenceDataValue("LOG_STATUS", "CODE", log.getStatus(), "NAME"));
			oMap.put("LOG_LIST", row, "colStatusMessage", log.getStatusMessage());			
			oMap.put("LOG_LIST", row, "colChannel", getChannelName(log.getChannelOid(), cache));
			oMap.put("LOG_LIST", row, "colStartDate", log.getLastupdated());
			oMap.put("LOG_LIST", row, "colStartDateTime", outputFormatTime.format(log.getLastupdated()));
			oMap.put("LOG_LIST", row, "colEndDate", log.getProcessDate());
			oMap.put("LOG_LIST", row, "colEndDateTime", outputFormatTime.format(log.getProcessDate()));
			if (getProcess(log.getProcessOid(), cache) != null) {
				oMap.put("LOG_LIST", row, "colProcessType",processMainType);
				oMap.put("LOG_LIST", row, "colProcess", getProcess(
						log.getProcessOid(), cache).getName(
						ADCSession.getLanguage()));
				if (getProcess(log.getProcessOid(), cache).getType().equals("3")) {
					oMap.put("LOG_LIST", row, "colProcess", log.getStatusMessage());
				} 
			} else {
				oMap.put("LOG_LIST", row, "colProcessType", "��lem Bulunamad�");
				oMap.put("LOG_LIST", row, "colProcess", "��lem Bulunamad�");
			}
			User user = getUser(log.getUserOid(), cache);
			if (user != null) {
				customerNo = null;
				if ( user.getUserCustomerId() != null) {
					customerNo = ""+user.getUserCustomerId();
				} else if(user.getCustomerId() != null) {
					customerNo = ""+user.getCustomerId();
				}
				if(customerNo == null || customerNo.equals("")){
					GnlKullanici kullanici = getKullanici(user.getUsername(), cache);
					try {
						oMap.put("LOG_LIST", row, "colUsername", user.getUsername());//Agent
						oMap.put("LOG_LIST", row, "colName", kullanici.getAd());//Agent Ad�
						oMap.put("LOG_LIST", row, "colSurname", kullanici.getSoyad());//Agent Soyad�
					} catch (Exception e) {
						oMap.put("LOG_LIST", row, "colName",
								"Kullan�c� Ad� Bulunamad�");
					}					
				}else{
					GnlMusteri customer = getCustomer(customerNo, cache);
					try {
						oMap.put("LOG_LIST", row, "colCustomerNo", customerNo);//Agent
						oMap.put("LOG_LIST", row, "colCustomerId", user.getUsername());//Agent
						oMap.put("LOG_LIST", row, "colCustomerName", customer.getAdi()+ (customer.getIkinciAdi() != null && customer.getIkinciAdi().length() > 0 ? " " + customer.getIkinciAdi() : ""));//Agent Ad�
						oMap.put("LOG_LIST", row, "colCustomerSurname", customer.getSoyadi());//Agent Soyad�
					} catch (Exception e) {
						oMap.put("LOG_LIST", row, "colCustomerName", "M��teri Ad� Bulunamad�");
					}
				}				
			}
			oMap.put("LOG_LIST", row, "MESSAGE", log.getStatusMessage());
			
			user = getUser(log.getParentUserOid(), cache);
			if (user != null) {
				customerNo = null;
				if (user.getUserCustomerId() != null) {
					customerNo = ""+user.getUserCustomerId();
				} else if(user.getCustomerId() != null) {
					customerNo = ""+user.getCustomerId();
				}
				oMap.put("LOG_LIST", row, "colCustomerNo", customerNo);//M��teri No
				
				GnlMusteri customer = getCustomer(customerNo, cache);

				try {
					oMap.put("LOG_LIST", row, "colCustomerId", user.getUsername());//M��teri TCKN
					oMap.put("LOG_LIST", row, "colCustomerName", customer.getAdi()+ (customer.getIkinciAdi() != null && customer.getIkinciAdi().length() > 0 ? " " + customer.getIkinciAdi() : ""));//M��teri Ad�
					oMap.put("LOG_LIST", row, "colCustomerSurname", getCustomer(customerNo, cache).getSoyadi());//M��teri Soyad�
				} catch (Exception e) {
					oMap.put("LOG_LIST", row, "colCustomerName", "M��teri Ad� Bulunamad�");
				}
			}
			
			row++;
		}
		oMap.put("ROW_COUNT", row);
		return oMap;
	}

	public static String getChannelCode(String oid,
			HashMap<String, Object> cache) {
		String key = "ChannelCode-" + oid;
		if (cache.containsKey(key)) {
			return (String) cache.get(key);
		}

		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		Channel channel = (Channel) session.createCriteria(Channel.class).add(
				Restrictions.eq("oid", oid)).uniqueResult();
		if (channel != null) {
			cache.put(key, channel.getCode());
			return channel.getCode();
		}
		cache.put(key, "Kanal Bulunamad�");
		return "Kanal Bulunamad�";

	}
	
	public static String getChannelName(String oid,
			HashMap<String, Object> cache) {
		String key = "ChannelCode-" + oid;
		if (cache.containsKey(key)) {
			return (String) cache.get(key);
		}

		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		Channel channel = (Channel) session.createCriteria(Channel.class).add(
				Restrictions.eq("oid", oid)).uniqueResult();
		if (channel != null) {
			cache.put(key, channel.getName(ADCSession.getLanguage()));
			return channel.getName(ADCSession.getLanguage());
		}
		cache.put(key, "Kanal Bulunamad�");
		return "Kanal Bulunamad�";

	}

	private static Process getProcess(String oid, HashMap<String, Object> cache) {
		if (oid == null) {
			return null;
		}

		String key = "Process-" + oid;
		if (cache.containsKey(key)) {
			return (Process) cache.get(key);
		}

		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		Process process = (Process) session.createCriteria(Process.class).add(
				Restrictions.eq("oid", oid)).uniqueResult();
		if (oid == null || process == null) {
			return null;
		}
		cache.put(key, process);
		return process;
	}

	private static List<?> getMatchingUsers(String name) {
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		SQLQuery usersQuery = session
				.createSQLQuery("select user_oid as userOid "
						+ "from adc_man_user_integration ui where int_key='MUSTERI_NO' "
						+ "and ui.int_value in (select musteri_no from bnspr.gnl_musteri where arama_isim like :shortName)");
		return usersQuery.addScalar("userOid", Hibernate.STRING).setString(
				"shortName", name).setMaxResults(100).list();
	}

	private static User getUser(String oid, HashMap<String, Object> cache) {
		String key = "User-" + oid;
		if (cache.containsKey(key)) {
			return (User) cache.get(key);
		}
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		User user = (User) session.createCriteria(User.class).add(
				Restrictions.eq("oid", oid)).uniqueResult();
		cache.put(key, user);
		return user;
	}
	
	private static String getDovizBasimKodu(String dovizKod, HashMap<String, Object> cache) {
		String key = "Doviz-" + dovizKod;
		if (cache.containsKey(key)) {
			return (String) cache.get(key);
		}
		String dovizBasimKodu = "";
		try{
			dovizBasimKodu =  GMServiceExecuter.call("BNSPR_COMMON_GET_DOVIZ_BASIM_KODU", new GMMap().put("DOVIZ_KODU", dovizKod)).getString("DOVIZ_BASIM_KODU");
			cache.put(key, dovizBasimKodu);
		}catch(Exception e){	
		}
		return dovizBasimKodu;
	}

	private static GnlMusteri getCustomer(String customerNo,
			HashMap<String, Object> cache) {
		String key = "Customer-" + customerNo;
		if (cache.containsKey(key)) {
			return (GnlMusteri) cache.get(key);
		}
		// This does not work no idea why !....
		GnlMusteri customer;
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			customer = (GnlMusteri) session.createCriteria(GnlMusteri.class)
					.add(
							Restrictions.eq("musteriNo", new BigDecimal(
									customerNo))).uniqueResult();
			cache.put(key, customer);
		} catch (NullPointerException npe) {
			customer = null;
		}
		return customer;
	}
	
	private static GnlKullanici getKullanici(String userName,
			HashMap<String, Object> cache) {
		String key = "Kullanici-" + userName;
		if (cache.containsKey(key)) {
			return (GnlKullanici) cache.get(key);
		}
		// This does not work no idea why !....
		GnlKullanici kullanici;
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			kullanici = (GnlKullanici) session.createCriteria(GnlKullanici.class)
					.add(
							Restrictions.eq("kod", userName)).uniqueResult();
			cache.put(key, kullanici);
		} catch (NullPointerException npe) {
			kullanici = null;
		}
		return kullanici;
	}

	public static String getReferenceDataValue(String referenceDataName,
			String keyName, String keyValue, String valueName) {
		List<?> list = GMReferenceDataFactory
				.getReferenceData(referenceDataName);

		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?, ?> map = (HashMap<?, ?>) iterator.next();
			if (map.containsKey(keyName) && keyValue != null
					&& keyValue.equals(map.get(keyName))) {
				return (String) map.get(valueName);
			}
		}
		return null;
	}
	
	@GraymoundService("GET_ADC_USER_ACTION_LOG")
	public static GMMap getUserActionLog(GMMap iMap) throws GMRuntimeException {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		Session session2 = DAOSession.getSession("BNSPRDal");
		
		String processOid = iMap.getString("PROCESS_OID");
		String status = iMap.getString("STATUS");
		String channelOid = iMap.getString("CHANNEL_OID");
		String userCode = iMap.getString("USER_CODE");
		String processType = iMap.getString("PROCESS_TYPE");
		String customerNo = iMap.getString("CUSTOMER_NO");
		String role = iMap.getString("ROLE");
		String parentUserOid = iMap.getString("PARENT_USER_OID");

		Date startDate = null;
		Date endDate = null;
		long period = 0;
		int row = 0;

		SimpleExpression userExp = null;
		SimpleExpression actionExp = null;
		SimpleExpression actionGroupExp = null;
		Criterion channelExp = null;
		SimpleExpression statusExp = null;
		Criterion roleExp = null;
		Criterion customerExp = null;
		

		long MAX_ALLOWED_PERIOD = Long.parseLong(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_PERIOD",
						"CODE"));
		int MAX_ROWS = Integer.parseInt(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_ROWS",
						"CODE"));
		int count = iMap.getInt("COUNT");
		if(count > 0) {
			MAX_ROWS = Math.min(count, MAX_ROWS);
		}
		
		GMMap messageParam = new GMMap();

		try {
			startDate = iMap.getDate("START_DATE");
			endDate = iMap.getDate("END_DATE");
		} catch (Throwable e) {
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHDATEERROR", null));
			}
		}
		
		if (startDate == null || endDate == null) {
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHDATEERROR", null));
			}else{
				if (startDate == null){
					startDate = new Date(0);
				}
				if (endDate == null){
					Calendar cal = Calendar.getInstance();
					cal.add(Calendar.YEAR, 1);
					endDate = cal.getTime();
				}
			}	
		}

		period = (endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24);
		if (period > MAX_ALLOWED_PERIOD) {
			messageParam.put("MAX_ALLOWED_PERIOD", MAX_ALLOWED_PERIOD);
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHMAXPERIODERR", messageParam));
			}
		}

		List<?> userActionLogs = null;
		{
			if (userCode != null && !userCode.equals("")) {
				User user = (User) session.createCriteria(User.class).add(
						Restrictions.eq("username", userCode)).uniqueResult();

				if (user == null) {
					throw new GMRuntimeException(0, GMMessageFactory
							.getMessage("LOGMONERR01", null), true);
				}
				userExp = Restrictions.eq("userOid", user.getOid());
			}			
			
			if (parentUserOid != null && !parentUserOid.equals("")) {
				userExp = Restrictions.eq("userOid", parentUserOid);
			}else if (customerNo != null && !customerNo.equals("")) {
				List<String> customerUserOids =  getCustomerUserOids(customerNo);
				if(customerUserOids.size() == 0){
					return oMap;
				}
				customerExp = Restrictions.in("userOid", customerUserOids.toArray());
			}
			
			if (role != null && !role.equals("0")) {
				List<String> sessionlist = getRoleSessions(role);
				if(sessionlist.size() == 0){
					return oMap;
				}
				roleExp = Restrictions.in("sessionId", sessionlist.toArray());
			}			
			if(((userExp != null) || (roleExp != null)) && (customerExp != null)){
				return oMap;
			}
			
			if (processOid != null && !processOid.equals("0")) {
				String group_action = GMReferenceDataFactory.getReferenceDataValue("USER_ACTION", "OID", processOid,"CODE");
				if(group_action != null){
					int index = group_action.indexOf("-");				
					actionExp = Restrictions.eq("action", group_action.substring(index+1));
					actionGroupExp = Restrictions.eq("actionGroup", group_action.substring(0,index));
				}else{
					return oMap;
				}
			}

			if (channelOid != null && !channelOid.equals("0")) {
				channelExp = Restrictions.eq("channelOid", channelOid);
			}else {
				List<String> logChannels = getLogChannels();
				if(logChannels.size() == 0){
					return oMap;
				}
				channelExp = Restrictions.in("channelOid", logChannels.toArray());
			}
			if (status != null && !status.equals(ALL)) {
				statusExp = Restrictions.eq("result", status);
			}

			SimpleExpression startDateExp = Restrictions.ge("lastupdated",
					startDate);
			SimpleExpression endDateExp = Restrictions.le("lastupdated",
					endDate);
			Criteria query = session.createCriteria(UserActionLog.class);
			if (userExp != null)
				query.add(userExp);
			if (customerExp != null)
				query.add(customerExp);
			if (actionExp != null)
				query.add(actionExp);
			if (actionGroupExp != null)
				query.add(actionGroupExp);
			if (channelExp != null)
				query.add(channelExp);
			if (statusExp != null)
				query.add(statusExp);
			if (roleExp != null)
				query.add(roleExp);
			
			query.add(startDateExp).add(endDateExp);
			
			query.setMaxResults(MAX_ROWS);
			
			userActionLogs = (List<?>) query.list();
		}

		Iterator<?> iterator = userActionLogs.iterator();
		HashMap<String, Object> cache = new HashMap<String, Object>();
		SimpleDateFormat outputFormat = new SimpleDateFormat(
				"dd/MM/yy HH:mm:ss");
		SimpleDateFormat outputFormatTime = new SimpleDateFormat("HHmmss");
		Boolean kategoriControl = false;
		List<AdkKategoriislem> kategoriislemList = null;
		if(!processType.equalsIgnoreCase("NONE")){
			kategoriislemList = (List<AdkKategoriislem>) session2.createCriteria(AdkKategoriislem.class).add(Restrictions.eq("id.kategoriOid", processType)).list();
			kategoriControl = true;
		}
		iMap.putAll(GMServiceExecuter.execute("GET_PROCESS_LIST_TYPE", iMap));
		iMap.put("USER_ACTIONS",GMReferenceDataFactory.getReferenceData("USER_ACTION"));
		GMMap userActions = new GMMap();
		for(int i=0;i<iMap.getSize("USER_ACTIONS");i++){
			userActions.put(iMap.getString("USER_ACTIONS",i,"CODE"), true);
		}
		while (iterator.hasNext() && row < MAX_ROWS + 2) {
			UserActionLog log = (UserActionLog) iterator.next();
			String processMainType = "";
			String processOidTemp = GMReferenceDataFactory.getReferenceDataValue("USER_ACTION", "CODE", log.getActionGroup() + "-" + log.getAction(), "OID");
			String actionGroup = log.getActionGroup()+"-"+log.getAction();
			if(!userActions.getBoolean(actionGroup)){
				continue;
			}                                              
			if(kategoriControl){
				Boolean cont = true;
				for(int k=0;k<kategoriislemList.size();k++){
					if(kategoriislemList.get(k).getId().getIslemOid().equals(processOidTemp)){
						cont = false;
						break;
					}
				}
				if(cont){
					continue;
				}
			}	
			if(processOidTemp != null){
				for(int k=0;k<iMap.getSize("PROCESS_LIST_TYPE");k++){
					if(processOidTemp.equals(iMap.getString("PROCESS_LIST_TYPE",k,"ISLEM_OID"))){
						processMainType = iMap.getString("PROCESS_LIST_TYPE",k,"KATEGORI_NAME");
					}
				}
			}			
			
			User user = getUser(log.getUserOid(), cache);
			if("OTP".equals(log.getAction()) && "LOGIN".equals(log.getActionGroup())){
				oMap.put("LOG_LIST", row, "colSource", "C");
				oMap.put("LOG_LIST", row, "colLogOid", log.getOid());
			} 
			oMap.put("LOG_LIST", row, "colAmount", "");
			oMap.put("LOG_LIST", row, "colSource", "C");
			oMap.put("LOG_LIST", row, "colLogOid", log.getOid());
			oMap.put("LOG_LIST", row, "colStatus", getReferenceDataValue(
					"LOG_STATUS", "CODE", log.getResult() != null ? log
							.getResult() : "1", "NAME"));
			oMap.put("LOG_LIST", row, "colChannel", getChannelName(log
					.getChannelOid(), cache));

			oMap.put("LOG_LIST", row, "colStartDate", log
					.getLastupdated());
			oMap.put("LOG_LIST", row, "colStartDateTime", outputFormatTime.format(log
					.getLastupdated()));
			oMap.put("LOG_LIST", row, "colEndDate", log
					.getLastupdated());
			oMap.put("LOG_LIST", row, "colEndDateTime", outputFormatTime.format(log
					.getLastupdated()));
			oMap.put("LOG_LIST", row, "colProcess", GMReferenceDataFactory.getReferenceDataValue("USER_ACTION", "CODE", log.getActionGroup() + "-" + log.getAction(), "NAME"));
			oMap.put("LOG_LIST", row, "colProcessType",processMainType);
			oMap.put("LOG_LIST", row, "colUserIp", log.getUserIP());
			if (user != null) {
				customerNo = null;
				if (user.getUserCustomerId() != null) {
					customerNo = ""+user.getUserCustomerId();
				} else if(user.getCustomerId() != null) {
					customerNo = ""+user.getCustomerId();
				}
				oMap.put("LOG_LIST", row, "colCustomerNo", customerNo);
				GnlMusteri customer = getCustomer(customerNo, cache);
				try {
					oMap.put("LOG_LIST", row, "colUsername", user.getUsername());
					oMap.put("LOG_LIST", row, "colCustomerId", user.getUsername());
					oMap.put("LOG_LIST", row, "colName",customer.getAdi()+ (customer.getIkinciAdi() != null&& customer.getIkinciAdi().length() > 0 ? " "+ customer.getIkinciAdi(): ""));
					oMap.put("LOG_LIST", row, "colCustomerName", customer.getAdi()+ (customer.getIkinciAdi() != null && customer.getIkinciAdi().length() > 0 ? " " + customer.getIkinciAdi() : ""));
					oMap.put("LOG_LIST", row, "colSurname", getCustomer(customerNo, cache).getSoyadi());
					oMap.put("LOG_LIST", row, "colCustomerSurname", getCustomer(customerNo, cache).getSoyadi());
				} catch (Exception e) {
					// TODO: Create message
					oMap.put("LOG_LIST", row, "colName","Kullan�c� Ad� Bulunamad�");
					oMap.put("LOG_LIST", row, "colCustomerName","Kullan�c� Ad� Bulunamad�");
				}
			}
			row++;
		}
		oMap.put("ROW_COUNT", row);

		return oMap;
	}

	@GraymoundService("GET_ADC_USER_LOGIN_LOG")
	public static GMMap getUserLoginLog(GMMap iMap) throws GMRuntimeException {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

		String status = iMap.getString("STATUS");
		String channelOid = iMap.getString("CHANNEL_OID");
		String userCode = iMap.getString("USER_CODE");
		String title = iMap.getString("TITLE");
		String actionGroup = "LOGIN";

		Date startDate = null;
		Date endDate = null;
		long period = 0;
		int row = 0;

		SimpleExpression userExp = null;
		SimpleExpression channelExp = null;
		SimpleExpression actionGroupExp = null;
		// SimpleExpression statusExp = null;
		Criterion titleExp = null;

		long MAX_ALLOWED_PERIOD = Long.parseLong(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_PERIOD",
						"CODE"));
		int MAX_ROWS = Integer.parseInt(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_ROWS",
						"CODE"));
		GMMap messageParam = new GMMap();

		try {
			startDate = iMap.getDate("START_DATE");
			endDate = iMap.getDate("END_DATE");
		} catch (Throwable e) {
			throw new GMRuntimeException(0, GMMessageFactory.getMessage(
					"LOGWATCHDATEERROR", null));
		}

		if (startDate == null || endDate == null) {
			throw new GMRuntimeException(0, GMMessageFactory.getMessage(
					"LOGWATCHDATEERROR", null));
		}

		period = (endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24);
		if (period > MAX_ALLOWED_PERIOD) {
			messageParam.put("MAX_ALLOWED_PERIOD", MAX_ALLOWED_PERIOD);
			throw new GMRuntimeException(0, GMMessageFactory.getMessage(
					"LOGWATCHMAXPERIODERR", messageParam));
		}

		List<?> userActionLogs = null;
		{
			if (userCode != null && !userCode.equals("")) {
				User user = (User) session.createCriteria(User.class).add(
						Restrictions.eq("username", userCode)).uniqueResult();

				if (user == null) {
					throw new GMRuntimeException(0, GMMessageFactory
							.getMessage("LOGMONERR01", null), true);
				}
				userExp = Restrictions.eq("userOid", user.getOid());
			}

			if (channelOid != null && !channelOid.equals("0")) {
				channelExp = Restrictions.eq("channelOid", channelOid);
			}
			if (actionGroup != null && !actionGroup.equals("0")) {
				actionGroupExp = Restrictions.eq("actionGroup", actionGroup);
			}
			// if (status != null && !status.equals(ALL)) {
			// statusExp = Restrictions.eq("status", status);
			// }

			if (title != null && !(title.length() == 0)) {
				List<?> matchingUsers = getMatchingUsers("%" + title + "%");
				if(matchingUsers.size() == 0){
					return oMap;
				}
				titleExp = Restrictions.in("userOid", matchingUsers.toArray());
			}

			SimpleExpression startDateExp = Restrictions.ge("lastupdated",
					startDate);
			SimpleExpression endDateExp = Restrictions.le("lastupdated",
					endDate);
			Criteria query = session.createCriteria(UserActionLog.class);
			if (userExp != null)
				query.add(userExp);
			if (channelExp != null)
				query.add(channelExp);
			if (actionGroupExp != null)
				query.add(actionGroupExp);
			// if (statusExp != null)
			// query.add(statusExp);
			if (titleExp != null) {
				query.add(titleExp);
			}
			query.add(startDateExp).add(endDateExp).addOrder(
					Order.asc("lastupdated"));
			userActionLogs = (List<?>) query.list();
		}

		List<UserActionLog> userLoginLogs = new ArrayList<UserActionLog>();
		Iterator<?> iterator = userActionLogs.iterator();
		HashMap<String, Integer> sessions = new HashMap<String, Integer>();
		while (iterator.hasNext()) {
			UserActionLog log = (UserActionLog) iterator.next();
			if (sessions.get(log.getSessionId()) == null
					|| ((UserActionLog) userActionLogs.get(sessions.get(log
							.getSessionId()))).getLastupdated().before(
							log.getLastupdated())) {
				sessions.put(log.getSessionId(), row);
			}
			row++;
		}
		row = 0;

		Iterator<?> iterator2 = userActionLogs.iterator();
		while (iterator2.hasNext()) {
			UserActionLog log = (UserActionLog) iterator2.next();
			if (sessions.get(log.getSessionId()) != -1) {
				if (status == null
						|| status.equals(ALL)
						|| status.equals(((UserActionLog) userActionLogs
								.get(sessions.get(log.getSessionId())))
								.getResult())) {
					userLoginLogs.add((UserActionLog) userActionLogs
							.get(sessions.get(log.getSessionId())));
				}
				sessions.put(log.getSessionId(), -1);
			}
		}

		oMap.put("LOG_LIST", new ArrayList<Object>());

		Iterator<?> iterator3 = userLoginLogs.iterator();
		HashMap<String, Object> cache = new HashMap<String, Object>();
		SimpleDateFormat outputFormat = new SimpleDateFormat(
				"dd/MM/yy kk:mm:ss");
		while (iterator3.hasNext() && row < MAX_ROWS) {
			UserActionLog log = (UserActionLog) iterator3.next();
			User user = getUser(log.getUserOid(), cache);
			oMap.put("LOG_LIST", row, "colLogOid", log.getOid());
			oMap.put("LOG_LIST", row, "colStatus", getReferenceDataValue(
					"LOG_STATUS", "CODE", log.getResult() != null ? log
							.getResult() : "1", "NAME"));
			oMap.put("LOG_LIST", row, "colChannel", getChannelCode(log
					.getChannelOid(), cache));

			oMap.put("LOG_LIST", row, "colStartDate", outputFormat.format(log
					.getLastupdated()));
			oMap.put("LOG_LIST", row, "colAction", log.getAction());
			oMap.put("LOG_LIST", row, "colUserIP", log.getUserIP());

			if (user != null) {
				String customerNo = null;
				if (user.getUserCustomerId() != null) {
					customerNo = ""+user.getUserCustomerId();
				} else if(user.getCustomerId() != null){
					customerNo = ""+user.getCustomerId();
				}
				GnlMusteri customer = getCustomer(customerNo, cache);

				try {
					oMap
							.put("LOG_LIST", row, "colUsername", user
									.getUsername());

					oMap
							.put("LOG_LIST", row, "colName",
									customer.getAdi()
											+ (customer.getIkinciAdi() != null
													&& customer.getIkinciAdi()
															.length() > 0 ? " "
													+ customer.getIkinciAdi()
													: ""));
					oMap.put("LOG_LIST", row, "colSurname", getCustomer(
							customerNo, cache).getSoyadi());
				} catch (Exception e) {
					// TODO: Create message
					oMap.put("LOG_LIST", row, "colName",
							"Kullan�c� Ad� Bulunamad�");
				}
			}

			row++;
		}
		oMap.put("ROW_COUNT", row);

		return oMap;
	}

	@GraymoundService("GET_ADC_OTP_LOG")
	public static GMMap getOtpLog(GMMap iMap) throws GMRuntimeException {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

		String status = iMap.getString("STATUS");
		String channelOid = iMap.getString("CHANNEL_OID");
		String customerNo = iMap.getString("CUSTOMER_NO");
		String actionGroup = "OTP";

		Date startDate = null;
		Date endDate = null;
		long period = 0;
		int row = 0;

		Criterion customerExp = null;
		SimpleExpression channelExp = null;
		SimpleExpression actionGroupExp = null;
		SimpleExpression statusExp = null;

		long MAX_ALLOWED_PERIOD = Long.parseLong(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_PERIOD",
						"CODE"));
		int MAX_ROWS = Integer.parseInt(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_ROWS",
						"CODE"));
		GMMap messageParam = new GMMap();

		try {
			String startTime = iMap.getString("START_TIME");
			String endTime = iMap.getString("END_TIME");
			SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
			startDate = iMap.getDate("START_DATE");
			startDate.setTime(startDate.getTime()
					+ sdf.parse(startTime).getTime() + 7200000);
			endDate = iMap.getDate("END_DATE");
			endDate.setTime(endDate.getTime() + sdf.parse(endTime).getTime()
					+ 7200000);
		} catch (Throwable e) {
			throw new GMRuntimeException(0, GMMessageFactory.getMessage(
					"LOGWATCHDATEERROR", null));
		}
		if (startDate == null || endDate == null) {
			throw new GMRuntimeException(0, GMMessageFactory.getMessage(
					"LOGWATCHDATEERROR", null));
		}

		period = (endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24);
		if (period > MAX_ALLOWED_PERIOD) {
			messageParam.put("MAX_ALLOWED_PERIOD", MAX_ALLOWED_PERIOD);
			throw new GMRuntimeException(0, GMMessageFactory.getMessage(
					"LOGWATCHMAXPERIODERR", messageParam));
		}

		List<?> userActionLogs = null;
		{
			if (customerNo != null && !customerNo.equals("")) {
				List <String> customerUserOids = getCustomerUserOids(customerNo);
				if(customerUserOids.size() == 0){
					return oMap;
				}
				customerExp = Restrictions.in("userOid", customerUserOids.toArray());
			}

			if (channelOid != null && !channelOid.equals("0")) {
				channelExp = Restrictions.eq("channelOid", channelOid);
			}
			if (actionGroup != null && !actionGroup.equals("0")) {
				actionGroupExp = Restrictions.eq("actionGroup", actionGroup);
			}
			if (status != null && !status.equals(ALL)) {
				statusExp = Restrictions.eq("result", status);
			}

			SimpleExpression startDateExp = Restrictions.ge("lastupdated",
					startDate);
			SimpleExpression endDateExp = Restrictions.le("lastupdated",
					endDate);
			Criteria query = session.createCriteria(UserActionLog.class);
			if (customerExp != null)
				query.add(customerExp);
			if (channelExp != null)
				query.add(channelExp);
			if (actionGroupExp != null)
				query.add(actionGroupExp);
			if (statusExp != null)
				query.add(statusExp);
			query.add(startDateExp).add(endDateExp).addOrder(
					Order.asc("lastupdated"));
			userActionLogs = (List<?>) query.list();
		}

		oMap.put("LOG_LIST", new ArrayList<Object>());

		Iterator<?> iterator = userActionLogs.iterator();
		HashMap<String, Object> cache = new HashMap<String, Object>();
		SimpleDateFormat outputFormat = new SimpleDateFormat(
				"dd/MM/yy kk:mm:ss");
		while (iterator.hasNext() && row < MAX_ROWS) {	
			UserActionLog log = (UserActionLog) iterator.next();
			User user = getUser(log.getUserOid(), cache);
			oMap.put("LOG_LIST", row, "colLogOid", log.getOid());
			oMap.put("LOG_LIST", row, "colStatus", getReferenceDataValue(
					"LOG_STATUS", "CODE", log.getResult() != null ? log
							.getResult() : "1", "NAME"));
			oMap.put("LOG_LIST", row, "colChannel", getChannelCode(log
					.getChannelOid(), cache));	

			if ("0".equals(log.getResult())) {
				oMap.put("LOG_LIST", row, "colDescription", getReferenceDataValue(
						"OTP_LOG_DESC", "CODE", log.getAction(), "NAME"));
			}
			oMap.put("LOG_LIST", row, "colPhoneNumber", log.getResultData());
			oMap.put("LOG_LIST", row, "colStartDate", outputFormat.format(log
					.getLastupdated()));
			oMap.put("LOG_LIST", row, "colAction", getReferenceDataValue(
					"OTP_LOG_ACTION", "CODE", log.getAction(), "NAME"));
			oMap.put("LOG_LIST", row, "colUserIP", log.getUserIP());

			if (user != null) {
				customerNo = null;
				if (user.getUserCustomerId() != null) {
					customerNo = ""+user.getUserCustomerId();
				} else if(user.getCustomerId() != null) {
					customerNo = ""+user.getCustomerId();
				}
				GnlMusteri customer = getCustomer(customerNo, cache);

				try {
					oMap
							.put("LOG_LIST", row, "colUsername", user
									.getUsername());

					oMap
							.put("LOG_LIST", row, "colName",
									customer.getAdi()
											+ (customer.getIkinciAdi() != null
													&& customer.getIkinciAdi()
															.length() > 0 ? " "
													+ customer.getIkinciAdi()
													: ""));
					oMap.put("LOG_LIST", row, "colSurname", getCustomer(
							customerNo, cache).getSoyadi());
					oMap.put("LOG_LIST", row, "colCustomerNo",customerNo);
				} catch (Exception e) {
				// TODO: use message
					oMap.put("LOG_LIST", row, "colName",
							"Kullan�c� Ad� Bulunamad�");
				}
			}

			row++;
		}
		oMap.put("ROW_COUNT", row);

		return oMap;
	}
	
}
