package tr.com.aktifbank.bnspr.core.esb.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EmEvent;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class DataCollectionServices {
	
	//TODO Sigorta data collection servisleri, BNSPRExternalServices projesi altina tasinsa daha iyi olur

	@GraymoundService("INSURANCE_DATA_COLLECTOR")
	public static GMMap insuranceDataCollector(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		Statement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		Calendar calendar = new GregorianCalendar();

		try {
			conn = DALUtil.getSigortaConnection();

			String hourMask = null; // �r: "09:00:00" -> saat olarak 9:00 al
			int minute = 1;

			hourMask = hourMask == null ? "HH:mm:ss" : hourMask;

			SimpleDateFormat simpleDate = new SimpleDateFormat("yyyy-MM-dd "
					+ hourMask + " ");

			TimeZone timeZone = TimeZone.getDefault();

			simpleDate.setTimeZone(timeZone);

			String lastDate = simpleDate.format(calendar.getTime());
			calendar.add(Calendar.MINUTE, minute == -1 ? -60 : -minute);
			String firstDate = simpleDate.format(calendar.getTime());

			/*
			 * �rnek zaman:
			 */
			//            lastDate  = "12/02/2011 15:42:14 ";
			//            firstDate = "10/02/2011 15:42:14 ";
			/* 
			 */

			/*
			 * 
			 *      �u an  i�in verileri  �ekecek bir  paket  olmad��� i�in  �nceki  veriler  kontrol
			 * edilemiyor, yaln�zca �u anki kaydedilmesi gereken verilerin �n kay�tlar� tutuluyor. 
			 * 
			 */

			String sql = "exec [dbo].[spGetContactList] '" + firstDate + "', '"
					+ lastDate + "', '', '', -1, -1;";

			stmt = conn.createStatement();
			rSet = stmt.executeQuery(sql);

			oMap = DALUtil.rSetResults(rSet, "SIGORTA_VERILERI");
			int size = oMap.getSize("SIGORTA_VERILERI");

			GMServerDatasource.close(conn);

			conn = DALUtil.getGMConnection();

			//            conn.setAutoCommit(false);

			stmt2 = conn
					.prepareCall("{call PKG_EVENT.P_CREATE_EVENT(? , ? , ? , ? , ? , ?)}");

			String id;
			for (int i = 0; i < size; i++) {
				id = oMap.getString("SIGORTA_VERILERI", i, "ID");

				// -Input-

				/* Event Type No     */stmt2.setBigDecimal(1,
						new BigDecimal(1)); // Sigorta -> 1
				/* Kaynak Refno      */stmt2.setString(2, id); // veri id'si
				/* Kaynak Kanal      */stmt2.setString(3, ""); // kanal ad�
				/* Integration Type  */stmt2.setString(4, "B"); // asenkron, senkron, batch
				/* Durum             */stmt2.setString(5, "S"); // S�rada

				// -Output-

				/* Event No          */stmt2.registerOutParameter(6,
						Types.NUMERIC);

				stmt2.execute();
				int eventNo = stmt2.getInt(6);
				conn.commit();
				stmt2.clearParameters();
				try {
					GMServiceExecuter.execute("EVENT_DISPATCHER_ASNC",
							new GMMap().put("EVENT_NO", eventNo));
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}

			//            conn.commit();
			//            conn.setAutoCommit(true);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("INSURANCE_DATA_NOTIFIER")
	public static GMMap insuranceDataNotifier(GMMap iMap) {
		Connection conn=null;
		PreparedStatement stmt = null;
		ResultSet rSet= null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EmEvent event = (EmEvent) session
					.createCriteria(EmEvent.class)
					.add(Restrictions.eq("eventno", iMap.getBigDecimal("EVENT_NO")))
					.uniqueResult();
			conn = DALUtil.getSigortaConnection();
			String sql = "select * from TKF_TEKLIF where teklif_id=?";
			stmt= conn.prepareCall(sql);
			stmt.setString(1, event.getKaynakRefno());
			rSet=stmt.executeQuery();
			GMMap resultMap = DALUtil.rSetResults(rSet, "SIGORTA_VERILERI");
			GMMap messages = new GMMap();
			messages.put("MESSAGES", 0,"SCENARIO_KEY","");
			messages.put("MESSAGES", 0,"EVENT","");
			messages.put("MESSAGES", 0,"SCENARIO","");
			messages.put("MESSAGES", 0,"PARAMETERS",resultMap);
			
			GMServiceExecuter.execute("BNSPR_EXT_CAMPAIGN_SAVE_KAMPANYA_BILDIRIM",messages);
			GMServiceExecuter.execute("BNSPR_EXT_CAMPAIGN_KAMPANYA_BILDIRIM_JOB",new GMMap());
		} 
		catch (Exception ex){
			
		}
		return new GMMap();
	}
	
}
