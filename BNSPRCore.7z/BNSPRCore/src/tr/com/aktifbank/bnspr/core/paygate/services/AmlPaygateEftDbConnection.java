package tr.com.aktifbank.bnspr.core.paygate.services;

import com.graymound.connection.GMConnection;
import com.graymound.util.GMMap;

public class AmlPaygateEftDbConnection {
	
	public static String callBulkSearch(String senderName, String receiverName, String description, String trxNo, String customerNum, String trxName, String senderBank, String receiverBank, String amount, String eftDate){
		String isFoundViolation = null;
		try {
			GMConnection conn= GMConnection.getConnection("BNSPR");
			GMMap parameters = new GMMap();
			parameters.put("GONDEREN", senderName);
			parameters.put("ALICI", receiverName);
			parameters.put("ACIKLAMA", description);
			parameters.put("TRX_NO", trxNo);
			parameters.put("MUSTERI_NO", customerNum);
			parameters.put("TRX_NAME", trxName);
			parameters.put("GONDEREN_BANKA", senderBank);
			parameters.put("ALAN_BANKA", receiverBank);
			parameters.put("TUTAR", amount.replace(",", "."));
			parameters.put("EFT_TARIH", eftDate);
			if ("2315".equals(trxName))
   			 	isFoundViolation = (String) conn.serviceCall("BNSPR_TRN2315_EFT_PAYGATE_CHECK", parameters).get("IS_FOUND_VIOLATION");
			else
				isFoundViolation = (String) conn.serviceCall("BNSPR_TRN2317_EFT_PAYGATE_CHECK", parameters).get("IS_FOUND_VIOLATION");
		} catch (Exception e){
			e.printStackTrace();
			isFoundViolation = "Exception: " + e.toString();
		}		
		return isFoundViolation;
	}
}