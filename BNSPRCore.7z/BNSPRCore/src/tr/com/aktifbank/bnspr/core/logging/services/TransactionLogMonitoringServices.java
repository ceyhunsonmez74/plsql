package tr.com.aktifbank.bnspr.core.logging.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.Collator;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.referencedata.GMReferenceDataFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TransactionLogMonitoringServices { 

	@GraymoundService("GET_PROCESS_TYPE_LIST")
	public static GMMap getProcessTypeList(GMMap iMap) { 
		return ADCTransactionLogMonitoringServices
				.getProcessTypeList(new GMMap());
	}

	@GraymoundService("GET_CHANNEL_LIST")
	public static GMMap getChannelList(GMMap iMap) {
		return ADCTransactionLogMonitoringServices.getChannelList(new GMMap());
	}
	
	@GraymoundService("GET_ROLE_LIST")
	public static GMMap getRoleList(GMMap iMap) {
		return ADCTransactionLogMonitoringServices.getRoleList(new GMMap());
	}

	@GraymoundService("GET_PROCESS_LIST")
	public static GMMap getProcessList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		oMap.put("PROCESS_LIST_0", ADCTransactionLogMonitoringServices
				.getProcessList(new GMMap()).get("PROCESS_LIST"));
		oMap.put("SECOND_PROCESS_LIST", BNSPRTransactionLogMonitoringServices
				.getBnsprProcessList(new GMMap()).get("PROCESS_LIST"));
		oMap.put("USER_ACTION_LIST", GMReferenceDataFactory.getReferenceData("USER_ACTION"));
		concatTables(oMap, "PROCESS_LIST_0", "SECOND_PROCESS_LIST");
		concatTables(oMap, "PROCESS_LIST_0", "USER_ACTION_LIST");
		sortTable(oMap, "PROCESS_LIST_0");

		oMap.put("PROCESS_LIST", new ArrayList<Object>());
		oMap.put("PROCESS_LIST", 0, "OID", 0);
		oMap.put("PROCESS_LIST", 0, "CODE", "NONE");
		oMap.put("PROCESS_LIST", 0, "NAME", GMMessageFactory.getMessage(
				"PLSSELECT", null));
		concatTables(oMap, "PROCESS_LIST", "PROCESS_LIST_0");
		oMap.remove("PROCESS_LIST_0");
		oMap.remove("SECOND_PROCESS_LIST");
		oMap.remove("USER_ACTION_LIST");
		return oMap;
	}
	@GraymoundService("GET_PROCESS_LIST_TYPE")
	public static GMMap getProcessListTypes(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			String query = "select k.name, i.islem_oid from adk_kategori k, adk_kategori_islem i where k.oid=i.kategori_oid and k.main = 1";
			stmt = conn.prepareStatement(query);
			rSet = stmt.executeQuery();
			int row = 0;
			while (rSet.next()) {				
				oMap.put("PROCESS_LIST_TYPE",row,"KATEGORI_NAME",rSet.getString(1));
				oMap.put("PROCESS_LIST_TYPE",row++,"ISLEM_OID",rSet.getString(2));
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("GET_ADC_LOG_STATUS_LIST")
	public static GMMap getLogStatusList(GMMap iMap) {
		GMMap oMap = new GMMap();
		int row = 0;

		oMap.put("STATUS_LIST", new ArrayList<Object>());
		Iterator<?> iterator = GMReferenceDataFactory.getReferenceData(
				"LOG_STATUS").iterator();

		while (iterator.hasNext()) {
			HashMap<?, ?> process = (HashMap<?, ?>) iterator.next();

			oMap.put("STATUS_LIST", row, "OID", process.get("CODE"));
			oMap.put("STATUS_LIST", row, "CODE", process.get("CODE"));
			oMap.put("STATUS_LIST", row, "NAME", process.get("NAME"));

			row++;
		}

		oMap.put("ROW_COUNT", row);

		return oMap;
	}

	@GraymoundService("GET_PROCESS_LOG")
	public static GMMap getProcessLog(GMMap iMap) throws ParseException{
		GMMap oMap = new GMMap();

		if(!iMap.containsKey("TIME_CONTROL")){
			iMap.put("TIME_CONTROL", true);
		}
		int MAX_ROWS = Integer.parseInt(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_ROWS",
						"CODE"));

		int count = iMap.getInt("COUNT");
		if(count > 0) {
			MAX_ROWS = Math.min(count, MAX_ROWS);
		}
		
		String ccChannelOid = ADCSession.getString("CC_CHANNEL_OID_FOR_LOG");
		
		try {
			String startTime = iMap.getString("START_TIME");
			String endTime = iMap.getString("END_TIME");
			SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
			iMap.getDate("START_DATE").setTime(iMap.getDate("START_DATE").getTime()
					+ sdf.parse(startTime).getTime() + 10800000);
			iMap.getDate("END_DATE").setTime(iMap.getDate("END_DATE").getTime() + 
					sdf.parse(endTime).getTime()
					+ 10800000);
		} catch (Throwable e) {
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHDATEERROR", null));
			}
		}
		
//		Performans iyileştirmesi için yorum içine alınmıştır.
//		if(("0".equals(iMap.getString("CHANNEL_OID")))||(ccChannelOid != null && ccChannelOid.equals(iMap.getString("CHANNEL_OID")))){
//			oMap.putAll(BNSPRTransactionLogMonitoringServices.getLog(iMap));
//			BNSPRTransactionLogMonitoringServices.checkLogSize(oMap.getSize("LOG_LIST"), MAX_ROWS, iMap.getBoolean("SKIP_MAX_CONTROL"));
//		}	
		
		oMap.put("SECOND_LOG_LIST", ADCTransactionLogMonitoringServices.getLog(iMap).get("LOG_LIST"));
		BNSPRTransactionLogMonitoringServices.checkLogSize(oMap.getSize("SECOND_LOG_LIST"), MAX_ROWS, iMap.getBoolean("SKIP_MAX_CONTROL"));
		
//		Performans iyileştirmesi için yorum içine alınmıştır.
//		oMap.put("THIRD_LOG_LIST", ADCTransactionLogMonitoringServices.getUserActionLog(iMap).get("LOG_LIST"));
//		BNSPRTransactionLogMonitoringServices.checkLogSize(oMap.getSize("THIRD_LOG_LIST"), MAX_ROWS, iMap.getBoolean("SKIP_MAX_CONTROL"));

		concatTables(oMap, "LOG_LIST", "SECOND_LOG_LIST");
		concatTables(oMap, "LOG_LIST", "THIRD_LOG_LIST");
		
		BNSPRTransactionLogMonitoringServices.checkLogSize(oMap.getSize("LOG_LIST"), MAX_ROWS, iMap.getBoolean("SKIP_MAX_CONTROL"));

		sortTableByColumn(oMap, "LOG_LIST", "colStartDateTime");
		sortTablebyDate(oMap, "LOG_LIST", "colStartDate");
		
		//for process logging
		SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
		if(iMap.getDate("START_DATE") != null){
			iMap.put("START_DATE_TXT"	, sdfDate.format(iMap.getDate("START_DATE")));
		}
		if(iMap.getDate("END_DATE") != null){
			iMap.put("END_DATE_TXT"		, sdfDate.format(iMap.getDate("END_DATE")));
		}
		if(iMap.getString("START_TIME") != null){
			iMap.put("START_TIME_TXT"	, formatTime(iMap.getString("START_TIME")));
		}
		if(iMap.getString("END_TIME") != null){
			iMap.put("END_TIME_TXT"		, formatTime(iMap.getString("END_TIME")));
		}
					
		return oMap;
	}

	private static String formatTime(String HHmmss) {
		StringBuffer time = new StringBuffer(HHmmss);
		time.insert(2, ":");
		time.insert(5, ":");
		return time.toString();
	}
	
	@GraymoundService("LOG_MONITOR_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(getProcessTypeList(new GMMap()));
		oMap.putAll(getChannelList(new GMMap()));
		oMap.putAll(getRoleList(new GMMap()));
		oMap.putAll(getProcessList(new GMMap()));
		oMap.putAll(getLogStatusList(new GMMap()));
		oMap.put("CC_CHANNEL_OID", ADCSession.get("CC_CHANNEL_OID_FOR_LOG"));
		return oMap;
	}
	
	@GraymoundService("GET_LAST_X_PROCESS_TYPE_LOG")
	public static GMMap getLastXProcessTypeLog(GMMap iMap) throws ParseException {
		GMMap oMap = new GMMap();
		GMMap i2Map = new GMMap();
		GMMap i4Map = new GMMap();
		i4Map.put("CHANNEL_LIST",getChannelList(new GMMap()).get("CHANNEL_LIST"));
		i4Map.put("PROCESS_TYPE_LIST",getProcessTypeList(new GMMap()).get("PROCESS_TYPE_LIST"));
//		i4Map.put("PROCESS_LIST",getProcessList(new GMMap()).get("PROCESS_LIST"));
		
		i2Map.put("CUSTOMER_NO", iMap.get("CUSTOMER_NO"));
		for(int k=0;k<i4Map.getSize("PROCESS_TYPE_LIST");k++){
			if(i4Map.getString("PROCESS_TYPE_LIST",k,"NAME") != null && i4Map.getString("PROCESS_TYPE_LIST",k,"NAME").equals(iMap.getString("PROCESS_TYPE"))){
				i2Map.put("PROCESS_TYPE", i4Map.getString("PROCESS_TYPE_LIST",k,"OID"));
			}
		}
		
		if(i2Map.get("PROCESS_TYPE")==null){
			i2Map.put("PROCESS_TYPE", "NONE");
		}
		
		String processOid = ADCTransactionLogMonitoringServices.getProcessOidByProcessCode(iMap.getString("PROCESS_CODE"));
		if(!StringUtils.isEmpty(processOid)){
			i2Map.put("PROCESS_OID", processOid);
		}
		
//		for(int k=0;k<i4Map.getSize("PROCESS_LIST");k++){
//			if(i4Map.getString("PROCESS_LIST",k,"CODE") != null && i4Map.getString("PROCESS_LIST",k,"CODE").equals(iMap.getString("PROCESS_CODE"))){
//				i2Map.put("PROCESS_OID", i4Map.getString("PROCESS_LIST",k,"OID"));
//			}
//		}
		
		i2Map.put("SKIP_MAX_CONTROL", true);
		i2Map.put("PARENT_USER_OID", iMap.get("PARENT_USER_OID"));
		i2Map.put("STATUS", iMap.get("STATUS"));
		i2Map.put("TIME_CONTROL", iMap.get("TIME_CONTROL"));
		i2Map.put("USER_CODE", iMap.get("USER_CODE"));
		i2Map.put("CHANNEL_OID", "0");
		i2Map.put("COUNT", iMap.getInt("COUNT"));
		
		i2Map.put("LAST_YEAR", true);
				
		GMMap i3Map = getProcessLog(i2Map);
		int count = iMap.getInt("COUNT");
		int row = 0;
		for(int i=i3Map.getSize("LOG_LIST")-1;i>-1&&row<count;i--){

			oMap.put("LOG_LIST", row, "colSource", i3Map.get("LOG_LIST", i, "colSource"));
			oMap.put("LOG_LIST", row, "colLogOid", i3Map.get("LOG_LIST", i, "colLogOid"));
			oMap.put("LOG_LIST", row, "colStatus", i3Map.get("LOG_LIST", i, "colStatus"));
			oMap.put("LOG_LIST", row, "colChannel", i3Map.get("LOG_LIST", i, "colChannel"));
			for(int k=0;k<i4Map.getSize("CHANNEL_LIST");k++){
				if(i4Map.getString("CHANNEL_LIST",k,"CODE") != null && i4Map.getString("CHANNEL_LIST",k,"CODE").equals(i3Map.get("LOG_LIST", i, "colChannel"))){
					oMap.put("LOG_LIST", row, "colChannel", i4Map.getString("CHANNEL_LIST",k,"NAME"));
				}
			}
			oMap.put("LOG_LIST", row, "colStartDate", i3Map.get("LOG_LIST", i, "colStartDate"));
			oMap.put("LOG_LIST", row, "colStartDateTime", i3Map.get("LOG_LIST", i, "colStartDateTime"));
			oMap.put("LOG_LIST", row, "colEndDate", i3Map.get("LOG_LIST", i, "colEndDate"));
			oMap.put("LOG_LIST", row, "colEndDateTime", i3Map.get("LOG_LIST", i, "colEndDateTime"));
			oMap.put("LOG_LIST", row, "colProcess", i3Map.get("LOG_LIST", i, "colProcess"));
			oMap.put("LOG_LIST", row, "colProcessType", i3Map.get("LOG_LIST", i, "colProcessType"));
			oMap.put("LOG_LIST", row, "colUserIp", i3Map.get("LOG_LIST", i, "colUserIp"));
			oMap.put("LOG_LIST", row, "colStartDate", i3Map.get("LOG_LIST", i, "colStartDate"));			
			oMap.put("LOG_LIST", row, "colCustomerNo", i3Map.get("LOG_LIST", i, "colCustomerNo"));
			oMap.put("LOG_LIST", row, "colUsername", i3Map.get("LOG_LIST", i, "colUsername"));
			oMap.put("LOG_LIST", row, "colCustomerId", i3Map.get("LOG_LIST", i, "colCustomerId"));
			oMap.put("LOG_LIST", row, "colName", i3Map.get("LOG_LIST", i, "colName"));
			oMap.put("LOG_LIST", row, "colCustomerName", i3Map.get("LOG_LIST", i, "colCustomerName"));
			oMap.put("LOG_LIST", row, "colSurname", i3Map.get("LOG_LIST", i, "colSurname"));
			oMap.put("LOG_LIST", row, "colCustomerSurname", i3Map.get("LOG_LIST", i, "colCustomerSurname"));
			oMap.put("LOG_LIST", row, "colAmount", i3Map.get("LOG_LIST", i, "colAmount"));

			row++;
		}		
		return oMap;
	}

	@SuppressWarnings("unchecked")
	public static GMMap concatTables(GMMap iMap, String tableTo,
			String tableFrom) {
		try {
			GMMap oMap = new GMMap();
			List<?> listFrom = (List<?>) iMap.get(tableFrom);
			List<?> listTo = (List<?>) iMap.get(tableTo);
			int sizeTo;
			if (listTo == null) {
				sizeTo = 0;
			} else {
				sizeTo = listTo.size();
			}
			if (listFrom != null) {
				for (int i = 0; i < listFrom.size(); i++) {
					HashMap<String, Object> temp = (HashMap<String, Object>) (listFrom
							.get(i));
					for (Iterator<? extends Map.Entry<String, Object>> j = temp
							.entrySet().iterator(); j.hasNext();) {
						Map.Entry<String, Object> e = j.next();
						iMap.put(tableTo, sizeTo + i, e.getKey(), e.getValue());
					}
				}
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@SuppressWarnings("unchecked")
	public static GMMap sortTable(GMMap iMap, String tableName) {
		try {
			GMMap oMap = new GMMap();
			List<?> listFrom = (List<?>) iMap.get(tableName);
			Collections.sort(listFrom, new Comparator() {
				public int compare(Object o1, Object o2) {
					try {
						Collator collator = Collator.getInstance(new Locale("tr","TR"));
						if (o1 == null)
							return 1;
						else if (o2 == null)
							return -1;
						else if (((HashMap) o1).get("NAME") == null)
							return 1;
						else if (((HashMap) o2).get("NAME") == null)
							return -1;
						
						return collator.compare(((String) ((HashMap) o1).get("NAME")),((String) ((HashMap) o2).get("NAME")));
					} catch (Throwable t) {
						System.out.println(((HashMap) o1).get("NAME"));
						System.out.println(((HashMap) o2).get("NAME"));
						t.printStackTrace();
						return 0;
					}
				}

				public boolean equals(Object o1, Object o2) {
					if (o1 == null && o2 != null)
						return false;
					else if (o1 == null && o2 == null)
						return true;

					return ((String) ((HashMap) o1).get("NAME"))
							.equals((String) ((HashMap) o2).get("NAME"));
				}
			});
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public static GMMap sortTablebyDate(GMMap iMap, String tableName, final String dateFieldName) {
		GMMap oMap = new GMMap();
		try {			
			List<?> listFrom = (List<?>) iMap.get(tableName);
			Collections.sort(listFrom, new Comparator() {
				public int compare(Object ob1, Object ob2) {
					try {
						GMMap o1 = new GMMap((HashMap<?, ?>)ob1);
						GMMap o2 = new GMMap((HashMap<?, ?>)ob2);
						if (o1 == null)
							return 1;
						else if (o2 == null)
							return -1;
						else if (o1.get(dateFieldName) == null)
							return 1;
						else if (o2.get(dateFieldName) == null)
							return -1;
						else if (o2.getDate(dateFieldName).after(o1.getDate(dateFieldName)))
							return -1;
						else if (o2.getDate(dateFieldName).before(o1.getDate(dateFieldName)))
							return 1;
						else return 0;
					} catch (Throwable t) {
						return 0;
					}
				}

				public boolean equals(Object ob1, Object ob2) {
					try {
						GMMap o1 = new GMMap((HashMap<?, ?>)ob1);
						GMMap o2 = new GMMap((HashMap<?, ?>)ob2);
						if (o1 == null && o2 != null)
							return false;
						else if (o1 == null && o2 == null)
							return true;	
						return (o1.getDate(dateFieldName).equals(o2.getDate(dateFieldName)));
					} catch (Throwable t) {
						return true;
					}
				}
			});
			return oMap;
		} catch (Exception e) {
			return oMap;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static GMMap sortTableByColumn(GMMap iMap, String tableName,final String columnName) {
		GMMap oMap = new GMMap();
		try {			
			List<?> listFrom = (List<?>) iMap.get(tableName);
			Collections.sort(listFrom, new Comparator() {
				public int compare(Object ob1, Object ob2) {
					try {
						GMMap o1 = new GMMap((HashMap<?, ?>)ob1);
						GMMap o2 = new GMMap((HashMap<?, ?>)ob2);
						if (o1 == null)
							return 1;
						else if (o2 == null)
							return -1;
						else if (o1.get(columnName) == null)
							return 1;
						else if (o2.get(columnName) == null)
							return -1;
						else if (o2.getString(columnName).compareTo(o1.getString(columnName))>0)
							return -1;
						else if (o2.getString(columnName).compareTo(o1.getString(columnName))<0)
							return 1;
						else return 0;
					} catch (Throwable t) {
						return 0;
					}
				}

				public boolean equals(Object ob1, Object ob2) {
					try {
						GMMap o1 = new GMMap((HashMap<?, ?>)ob1);
						GMMap o2 = new GMMap((HashMap<?, ?>)ob2);
						if (o1 == null && o2 != null)
							return false;
						else if (o1 == null && o2 == null)
							return true;	
						return (o1.getString(columnName).compareTo(o2.getString(columnName))==0);
					} catch (Throwable t) {
						return true;
					}
				}
			});
			return oMap;
		} catch (Exception e) {
			return oMap;
		}
	}

}
