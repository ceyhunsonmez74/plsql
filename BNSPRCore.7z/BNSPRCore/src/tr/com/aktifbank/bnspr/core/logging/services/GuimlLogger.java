package tr.com.aktifbank.bnspr.core.logging.services;

import tr.com.aktifbank.bnspr.dao.AppguimlEntrylog;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.util.GMMap;

/**
 * Log ".guiml" pages
 * 
 * @author samis
 * 
 */
public class GuimlLogger {
	
	@GraymoundService(value = "GUIML_LOG_SERVICE", authenticationRequired = false)
	public static GMMap guimlLog(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getString("GUIML") != null) {

				AppguimlEntrylog guimlLog = new AppguimlEntrylog();
				guimlLog.setGuiml(iMap.getString("GUIML"));
				guimlLog.setIpno(GMContext.getCurrentContext().getSession()
						.get("CLIENT_IP").toString());
				guimlLog.setSessionid(GMContext.getCurrentContext()
						.getSession().getId());
				guimlLog.setUsercode((String) GMContext.getCurrentContext()
						.getSession().get("USER_NAME"));
				DAOSession.getSession("BNSPRDal").save(guimlLog);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}
}
