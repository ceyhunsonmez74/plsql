package tr.com.aktifbank.bnspr.core.event.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EmEvent;
import tr.com.aktifbank.bnspr.dao.EmEventCatalogue;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.core.util.CoreUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EventServices {
	
	private static Logger log = Logger.getLogger(EventServices.class);
	
	private final static String EVENT_DRM_SIRADA = "C";
	private final static String EVENT_DRM_HATA = "E";
	private final static String EVENT_DRM_IPTAL = "I";
	private final static String EVENT_DRM_BASARILI = null;
	
	private final static String EVENT_INTEGRATION_TYPE_SYNC = 	"S";
	private final static String EVENT_INTEGRATION_TYPE_ASYNC = 	"A";
	
	public final static String WAIT_FOR_RESULT_TRUE = "1";
	
	private static Boolean CURRENT_EVENT_DISPATCHER_JOB_EXISTS = false;
	
	private synchronized static void setCurrentEventDispatcherJobExists(boolean value){
		CURRENT_EVENT_DISPATCHER_JOB_EXISTS = value;
	}
	
	/**
	 * 
	 * @param iMap
	 * 			-EVENT_NO
	 * @return
	 */
	@GraymoundService("BNSPR_CORE_EVENT_DISPATCHER_ASYNC")
	public static GMMap asyncEventDispatcher(GMMap iMap) {
		GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_DISPATCHER", iMap);
		return new GMMap().put("RESULT", 2)
						  .put("RESULT_DATA", "");
	}

	/**
	 * 
	 * @param iMap
	 * 			-EVENT_NO
	 * 			-DATA_MAP  :optional
	 * @return
	 */
	@GraymoundService("BNSPR_CORE_EVENT_DISPATCHER")
	public static GMMap eventDispatcher(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESPONSE", "2");
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			EmEvent event = new EmEvent();
			/*
			 * LockMode.UPGRADE_NOWAIT ilk gelen icin row lock koyar, ikinci gelen lock'in kalkmasini beklemeden exception alir
			 * Bu lock exception teoride olusabilecek bir durum degil, BNSPR_CORE_EVENT_DISPATCHER_JOB servisi event listeleme ve dispatch etme kismina ayni anda ikinci bir job servisinin ulasmamasini sagliyor, 
			 * finally bloguna eristiginde ise event kaydinin durumunu guncelleyerek new tx ile isini coktan gormus oluyor, o esnada baska bir job servisi listeleme kismina girse bile basarili statusune gelmi� ayni event kaydini listeleyemez
			 * 
			 */
			event = (EmEvent) session.load(EmEvent.class, iMap.getBigDecimal("EVENT_NO"), LockMode.UPGRADE_NOWAIT ); 
			
			EmEventCatalogue eventCatalogue = new EmEventCatalogue();
			eventCatalogue = (EmEventCatalogue) session.load(EmEventCatalogue.class, event.getEventtypeno());
			
			
			iMap.put("EVENT_REF_NO", event.getKaynakRefno());
			
			log.info("Event No = " + iMap.getString("EVENT_NO"));
			
			try{
				GMMap dataMap = new GMMap();
				
				if(iMap.containsKey("DATA_MAP")){
					dataMap = iMap.getMap("DATA_MAP");
				}
				else{
					if(eventCatalogue.getDataCollectService()!=null)
						dataMap = GMServiceExecuter.call(eventCatalogue.getDataCollectService(), iMap);
				}
				
				GMMap consumeMap = new GMMap();
				consumeMap.put("EVENT_NO", 		  iMap.getString("EVENT_NO"));
				consumeMap.put("EVENT", 		  eventCatalogue.getEvent());
				consumeMap.put("SCENARIO", 		  eventCatalogue.getScenario());
				consumeMap.put("WAIT_FOR_RESULT", eventCatalogue.getWaitForResult());
				consumeMap.put("DATA_MAP", 		  dataMap);
				
				if(eventCatalogue.getDataConsumerService()!=null)
					oMap.putAll( GMServiceExecuter.call(eventCatalogue.getDataConsumerService(), consumeMap) );
				
				event.setDrm(EVENT_DRM_BASARILI);
			}
			catch(Exception e){
				e.printStackTrace(); 
				oMap.put("RESPONSE", "0");
				if( WAIT_FOR_RESULT_TRUE.equals(eventCatalogue.getWaitForResult()) ){
					event.setDrm(EVENT_DRM_IPTAL); //senkron bildirim yapip aninda sonuc almak isteyen event bildirimini hata durumunda iptale cek, jobun daha sonra tekrar denemesinin bir anlami yok 
				}
				else{
					event.setDrm(EVENT_DRM_HATA);
				}	
				event.setIslemAdet( ( event.getIslemAdet() == null ? new BigDecimal(0) : event.getIslemAdet() ).add(new BigDecimal(1)));
			}
			event.setSonDrmTar(new Date());
			session.save(event);
			session.flush();
			
		}
		catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CORE_EVENT_DISPATCHER_JOB")
	public static GMMap eventDispatcherJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean isCurrentlyExecutingJob = false;
		try {
			
			synchronized (CURRENT_EVENT_DISPATCHER_JOB_EXISTS) {
				if(CURRENT_EVENT_DISPATCHER_JOB_EXISTS) //Ayni anda birden fazla job calismasin
					return oMap;
				else{
					setCurrentEventDispatcherJobExists(true);
					isCurrentlyExecutingJob = true;
				}					
			}
			
			String eventJobId = UUID.randomUUID().toString();
			log.info(eventJobId + " nolu Event Job basladi");
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> eventList = session.createCriteria(EmEvent.class)
										.add( Restrictions.or(Restrictions.eq("drm", EVENT_DRM_SIRADA), Restrictions.eq("drm", EVENT_DRM_HATA) ) )
										.add( Restrictions.lt("islemAdet", new BigDecimal(10))) // 10'dan fazla hata almis kayitlarla ilgilenme
										.addOrder(Order.asc("eventno"))
										//.setLockMode(LockMode.UPGRADE_NOWAIT ) // lock koymaya gerek yok, bir job CURRENT_EVENT_DISPATCHER_JOB_EXISTS kontrolunden dolayi eventleri listeleyip durumlarini new tx ile guncellemeden once ikinci bir job gelemez buraya
										.list();
			
			log.info("Islenecek event sayisi: " +eventList.size());
			
			ArrayList<GMMap> taskList = new ArrayList<GMMap>();
			
			for (int i=0; i<eventList.size(); i++) {
				try{
					EmEvent event = (EmEvent)eventList.get(i);
					
					GMMap taskMap = new GMMap(); 
	                taskMap.put("T_SERVICE_NAME", "BNSPR_CORE_EVENT_DISPATCHER"); 
	                taskMap.put("EVENT_NO" , event.getEventno());	                    
	                taskList.add(taskMap);
					
					if(taskList.size() == CoreUtil.EVENT_MAX_THREAD_SIZE || ( i == eventList.size()-1 )  ){
						GMMap sMap = new GMMap();
						sMap.put("T_TASKS", taskList); 
						// waits until all tasks to finish 
                        GMServiceExecuter.callParallel(sMap);
                        taskList.clear();
					}

				}
				catch(Exception e){
					taskList.clear();
					log.error(e.getMessage());//hatayi firlatma bir sonraki kumeyle devam et donguye
				}
			}
			
			log.info(eventJobId + " nolu Event Job bitti");
			
		}
		catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		finally{
			if(isCurrentlyExecutingJob){
				setCurrentEventDispatcherJobExists(false);
			}	
		}
		return oMap;
	}
	
	/**
	 * 
	 * @param iMap
	 * 			-EVENT_TYPE_NO
	 * 			-EVENT_REF_NO
	 * 			-INTEGRATION_TYPE   : optional(if not sent, defaults to "A": Asynchronous)
	 * 			-DATA_MAP(GMMap)	: optional(if DATA_MAP is sent, data collect servis will not be called and this data will be consumed)
	 * @return
	 * 		  oMap	
	 */
	@GraymoundService("BNSPR_CORE_EVENT_CREATE_EVENT")
	public static GMMap createEvent(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			if(iMap.containsKey("EVENT_TYPE_NO") && iMap.getBigDecimal("EVENT_TYPE_NO")!=null){
				EmEventCatalogue eventCatalogue = (EmEventCatalogue) session.load(EmEventCatalogue.class, iMap.getBigDecimal("EVENT_TYPE_NO"));
				if(eventCatalogue.getDrm().equals(EVENT_DRM_IPTAL)){
					oMap.put("RESPONSE", "0");
					return oMap;
				}
			}

            GMMap sMap = new GMMap().put("TABLE_NAME" , "EM_EVENT");
            BigDecimal eventId = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID" , sMap).getBigDecimal("ID");
            
            String integrationType = iMap.getString("INTEGRATION_TYPE");
			
			EmEvent event = new EmEvent();
			event.setEventno(eventId);
			event.setEventtypeno(iMap.getBigDecimal("EVENT_TYPE_NO"));
			event.setKaynakRefno(iMap.getString("EVENT_REF_NO"));
			event.setDrm(EVENT_DRM_SIRADA);
			event.setKaynakKanal(ADCSession.getString("CHANNEL_CODE"));
			event.setIntegrationType(StringUtil.isEmpty(integrationType) ? EVENT_INTEGRATION_TYPE_ASYNC : integrationType);
			event.setSonDrmTar(new Date());
			event.setIslemAdet(new BigDecimal(0));
			session.save(event);
			session.flush();
			
			if(EVENT_INTEGRATION_TYPE_SYNC.equals(integrationType)){
				sMap.clear();
				sMap.put("EVENT_NO", eventId);
				if(iMap.containsKey("DATA_MAP")){
					sMap.put("DATA_MAP", iMap.getMap("DATA_MAP"));
				}
				oMap.putAll(GMServiceExecuter.call("BNSPR_CORE_EVENT_DISPATCHER", sMap));
			}
			
		} 
		catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		}
		oMap.put("RESPONSE", "2");
		return oMap;
	}

	
}
