package tr.com.aktifbank.bnspr.core.logging.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.AdkKategoriislem;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.referencedata.GMReferenceDataFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class BNSPRTransactionLogMonitoringServices {
	
	@GraymoundService("GET_BNSPR_CHANNEL_NAME")
	public static String getChannelName(String integrationId) { // CC -->
		// value for
		// call
		// center
		Session session = DAOSession.getSession("BNSPRDal");
		GnlKanalGrupKodPr gnlKanalGrupKodPr = (GnlKanalGrupKodPr) session
				.createCriteria(GnlKanalGrupKodPr.class).add(
						Restrictions.eq("integrationId", integrationId))
				.uniqueResult();
		return gnlKanalGrupKodPr.getKod();
	}

	public static GnlMusteri getCustomer(String customerNo,
			HashMap<String, Object> cache) {
		String key = "Customer-" + customerNo;
		if (cache.containsKey(key)) {
			return (GnlMusteri) cache.get(key);
		}

		GnlMusteri customer;
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			customer = (GnlMusteri) session.createCriteria(GnlMusteri.class)
					.add(
							Restrictions.eq("musteriNo", new BigDecimal(
									customerNo))).uniqueResult();
			cache.put(key, customer);
		} catch (NullPointerException npe) {
			customer = null;
		}
		return customer;
	}
	
	private static String getDovizBasimKodu(String dovizKod, HashMap<String, Object> cache) {
		String key = "Doviz-" + dovizKod;
		if (cache.containsKey(key)) {
			return (String) cache.get(key);
		}
		String dovizBasimKodu = "";
		try{
			dovizBasimKodu =  GMServiceExecuter.call("BNSPR_COMMON_GET_DOVIZ_BASIM_KODU", new GMMap().put("DOVIZ_KODU", dovizKod)).getString("DOVIZ_BASIM_KODU");
			cache.put(key, dovizBasimKodu);
		}catch(Exception e){	
		}
		return dovizBasimKodu;
	}


	@GraymoundService("GET_BNSPR_PROCESS_LIST")
	public static GMMap getBnsprProcessList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		int row = 0;
		String processQuery ="";
		try {
			conn = DALUtil.getAdcConnection();

			processQuery = "select i.kod islem_kod, i.aciklama from bnspr.muh_islem_tanim_pr i";					

			stmt = conn.prepareStatement(processQuery);
			rSet = stmt.executeQuery();

			while (rSet.next()) {
				oMap.put("PROCESS_LIST", row, "OID", rSet.getString(1));
				oMap.put("PROCESS_LIST", row, "CODE", rSet.getString(1));
				oMap.put("PROCESS_LIST", row, "NAME", rSet.getString(1)+ " - "+rSet.getString(2));
				
				row++;
			}

			oMap.put("ROW_COUNT", row);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rSet.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return oMap;
	}

	@GraymoundService("GET_BNSPR_PROCESS_LOG")
	public static GMMap getLog(GMMap iMap) throws GMRuntimeException {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		List<AdkKategoriislem> kategoriislemList = null;
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		
		String processOid = iMap.getString("PROCESS_OID");
		String status = iMap.getString("STATUS");
		String userCode = iMap.getString("USER_CODE");
		String processType = iMap.getString("PROCESS_TYPE");
		String customerNo = iMap.getString("CUSTOMER_NO");
		String role = iMap.getString("ROLE");
		String channelOid = iMap.getString("CHANNEL_OID");

		java.util.Date startDate = null;
		java.util.Date endDate = null;
		long period = 0;
		int row = 0;

		long MAX_ALLOWED_PERIOD = Long.parseLong(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_PERIOD",
						"CODE"));
		int MAX_ROWS = Integer.parseInt(GMReferenceDataFactory
				.getReferenceDataValue("LOGWATCH_PARAMS", "NAME", "MAX_ROWS",
						"CODE"));
		
		int count = iMap.getInt("COUNT");
		if(count > 0) {
			MAX_ROWS = Math.min(count, MAX_ROWS);
		}
		
		GMMap messageParam = new GMMap();
		
		try {
			startDate = iMap.getDate("START_DATE");
			endDate = iMap.getDate("END_DATE");
		} catch (Throwable e) {
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHDATEERROR", null));
			}
		}
		
		if (startDate == null || endDate == null) {
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHDATEERROR", null));
			}else{
				if (startDate == null){
					startDate = new Date(0);
				}
				if (endDate == null){
					Calendar cal = Calendar.getInstance();
					cal.add(Calendar.YEAR, 1);
					endDate = cal.getTime();					
				}
			}
		}

		period = (endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24);
		if (period > MAX_ALLOWED_PERIOD) {
			messageParam.put("MAX_ALLOWED_PERIOD", MAX_ALLOWED_PERIOD);
			if(iMap.getBoolean("TIME_CONTROL")){
				throw new GMRuntimeException(0, GMMessageFactory.getMessage(
						"LOGWATCHMAXPERIODERR", messageParam));
			}
		}		
		HashMap<String, Object> cache = new HashMap<String, Object>();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call  PKG_RC_CALL_CENTER.RC_GET_CC_ISLEM_LOG (?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			
			if(userCode != null && !userCode.equals("")){
				stmt.setString(i++, userCode);
			}else{
				stmt.setString(i++, null);
			}
			if (!(startDate == null)) {
				stmt.setDate(i++, new java.sql.Date( startDate.getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			if (!(endDate == null)) {
				stmt.setDate(i++, new java.sql.Date( endDate.getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			if (processOid != null && !processOid.equals("0")) {
				stmt.setString(i++, processOid);
			} else {
				stmt.setString(i++, null);
			}
			if (status != null && !status.equals("2")) {
				stmt.setString(i++, status);
			}else {
				stmt.setString(i++, null);
			}
			if(customerNo != null && !customerNo.equals("")){
				stmt.setString(i++, customerNo);
			}else{
				stmt.setString(i++, null);
			}
			Boolean roleControl = false;
			if (role != null && !role.equals("0")) {
				stmt.setString(i++, role);
				roleControl = true;
			}else {
				stmt.setString(i++, null);
			}
			if (channelOid != null && !channelOid.equals("0")) {
				stmt.setString(i++, ADCTransactionLogMonitoringServices.getChannelCode(channelOid, cache));
			}else {
				stmt.setString(i++, null);
			}
			if (processType != null && !processType.equalsIgnoreCase("NONE")) {
				stmt.setString(i++, processType);
			}else {
				stmt.setString(i++, null);
			}
			SimpleDateFormat outputFormatTime = new SimpleDateFormat("HHmmss");
			iMap.putAll(GMServiceExecuter.execute("GET_PROCESS_LIST_TYPE", iMap));
			
			stmt.execute();
			
			stmt.setMaxRows(MAX_ROWS + 2);
			
			rSet = (ResultSet) stmt.getObject(1);
			int maxRows = MAX_ROWS + 2;
			if(iMap.containsKey("COUNT")){
				maxRows = iMap.getInt("COUNT");
			}
			while (rSet.next() && row < maxRows) {
				if(rSet.getString(18) == null || !(rSet.getString(18).equals("CC") || rSet.getString(18).equals("MAN"))){
					continue;
				}
				if(roleControl){
					if(!role.equals(rSet.getString(1))){
						continue;
					}
				}
				String processMainType = "";
				String processOidTemp = rSet.getString(2);
				if(processOidTemp != null){
					for(int k=0;k<iMap.getSize("PROCESS_LIST_TYPE");k++){
						if(processOidTemp.equals(iMap.getString("PROCESS_LIST_TYPE",k,"ISLEM_OID"))){
							processMainType = iMap.getString("PROCESS_LIST_TYPE",k,"KATEGORI_NAME");
						}
					}
				}				
				oMap.put("LOG_LIST", row, "colUserIp", "CallCenter veya �ube");
				oMap.put("LOG_LIST", row, "colSource", "B");
				oMap.put("LOG_LIST", row, "colLogOid", rSet.getBigDecimal(3));
				oMap.put("LOG_LIST", row, "colProcess", rSet.getString(4));
				oMap.put("LOG_LIST", row, "colProcessType",processMainType);
				oMap.put("LOG_LIST", row, "colStatus", getReferenceDataValue("LOG_STATUS", "CODE", rSet.getString(6), "NAME"));
				oMap.put("LOG_LIST", row, "colChannel", rSet.getString(17));
				oMap.put("LOG_LIST", row, "colStartDate", rSet.getDate(5));
				oMap.put("LOG_LIST", row, "colStartDateTime", outputFormatTime.format(rSet.getTime(5)));
				oMap.put("LOG_LIST", row, "colEndDate", rSet.getDate(5));
				oMap.put("LOG_LIST", row, "colEndDateTime", outputFormatTime.format(rSet.getTime(5)));
				oMap.put("LOG_LIST", row, "colCustomerId", rSet.getString(7));
				oMap.put("LOG_LIST", row, "colCustomerName", rSet.getString(8));
				oMap.put("LOG_LIST", row, "colCustomerSurname", rSet.getString(9));
				oMap.put("LOG_LIST", row, "colCustomerNo", rSet.getString(10));
				oMap.put("LOG_LIST", row, "colUsername", rSet.getString(11));
				oMap.put("LOG_LIST", row, "colName", rSet.getString(12));
				oMap.put("LOG_LIST", row, "colSurname", rSet.getString(13));
				oMap.put("LOG_LIST", row, "colScreenName", rSet.getString(14));
				if( rSet.getBigDecimal(15) != null){
					oMap.put("LOG_LIST", row, "colAmount", rSet.getBigDecimal(15).toPlainString() + " " + getDovizBasimKodu(rSet.getString(16),cache));
				}else{
					oMap.put("LOG_LIST", row, "colAmount", "");
				}
				row++;
			}
			oMap.put("ROW_COUNT", row);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}


	/*private static String getChannelCode(String oid,
			HashMap<String, Object> cache) {
		String key = "ChannelCode-" + oid;
		if (cache.containsKey(key)) {
			return (String) cache.get(key);
		}

		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
		Channel channel = (Channel) session.createCriteria(Channel.class).add(
				Restrictions.eq("oid", oid)).uniqueResult(); 
		if (channel != null) {
			cache.put(key, channel.getCode());
			return channel.getCode();
		}
		cache.put(key, "Kanal Bulunamad�");
		return "Kanal Bulunamad�";

	}*/

	public static String getReferenceDataValue(String referenceDataName,
			String keyName, String keyValue, String valueName) {
		List<?> list = GMReferenceDataFactory
				.getReferenceData(referenceDataName);

		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?, ?> map = (HashMap<?, ?>) iterator.next();
			if (map.containsKey(keyName) && keyValue != null
					&& keyValue.equals(map.get(keyName))) {
				return (String) map.get(valueName);
			}
		}
		return null;
	}
	
	public static void checkLogSize(int logSize, int maxsize, boolean skipMaxControl) {
		
		if(skipMaxControl) {
			return;
		}
		
		GMMap iMap = new GMMap();
		
		if( logSize > maxsize ){
			iMap.put("P1", maxsize);
			iMap.put("HATA_NO", new BigDecimal(1728));
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		
		
	}
	
}
