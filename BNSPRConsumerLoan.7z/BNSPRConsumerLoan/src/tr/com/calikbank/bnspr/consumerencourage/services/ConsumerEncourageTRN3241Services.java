package tr.com.calikbank.bnspr.consumerencourage.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirTesvikPuanGuncelleTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerEncourageTRN3241Services {

	@GraymoundService("BNSPR_TRN3241_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			if (iMap.getString("ACIKLAMA") == null || iMap.getString("ACIKLAMA").length() == 0) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "ACIKLAMA");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			BirTesvikPuanGuncelleTx birTesvikPuanGuncelleTx = new BirTesvikPuanGuncelleTx();

			birTesvikPuanGuncelleTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birTesvikPuanGuncelleTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			if (iMap.getBoolean("PUAN_EKLE")) {
				birTesvikPuanGuncelleTx.setPuanEkleSil("E");
				birTesvikPuanGuncelleTx.setPuan(iMap.getBigDecimal("PUAN_EKLE_TUTAR"));
				birTesvikPuanGuncelleTx.setAciklama(iMap.getString("KULLANICI_KOD").concat("-").concat(iMap.getString("ACIKLAMA")));

			}
			else {
				birTesvikPuanGuncelleTx.setPuanEkleSil("S");
				birTesvikPuanGuncelleTx.setPuan(iMap.getBigDecimal("PUAN_SIL_TUTAR"));
				birTesvikPuanGuncelleTx.setAciklama(iMap.getString("KULLANICI_KOD").concat("-").concat(iMap.getString("ACIKLAMA")));
			}
			session.saveOrUpdate(birTesvikPuanGuncelleTx);

			session.flush();
			iMap.put("TRX_NAME", "3241");
			return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}
		finally {

		}
	}

	@GraymoundService("BNSPR_TRN3241_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;
		String tableName;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3241.GET_INFO(?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(2, -10); // ref cursor
			stmt.registerOutParameter(3, -10); // ref cursor
			stmt.registerOutParameter(4, -10); // ref cursor
			stmt.execute();

			rSet1 = (ResultSet) stmt.getObject(2);
			tableName = "CALISAN_BILGILERI";
			int i = 0;
			while (rSet1.next()) {
				oMap.put(tableName, i, "CALISTIGI_BAYI_KOD", rSet1.getBigDecimal("SATICI_KOD"));
				oMap.put(tableName, i, "CALISTIGI_BAYI_ADI", rSet1.getString("SATICI_ADI"));
				oMap.put(tableName, i, "CALISAN_NO", rSet1.getBigDecimal("CALISAN_NO"));
				i++;
			}
			GMServerDatasource.close(rSet1);

			rSet2 = (ResultSet) stmt.getObject(3);
			if (rSet2.next()) {
				oMap.put("TOPLAM_PUAN", rSet2.getBigDecimal("TOPLAM_PUAN"));
				oMap.put("HARCADIGI_PUAN", rSet2.getBigDecimal("HARCADIGI_PUAN"));
				oMap.put("KULLANILABILIR_PUAN", rSet2.getBigDecimal("KULLANILABILIR_PUAN"));
			}
			GMServerDatasource.close(rSet2);

			rSet3 = (ResultSet) stmt.getObject(4);

			while (rSet3.next()) {
				if (rSet3.getString("PUAN_EKLE_SIL").equals("E")) {
					oMap.put("PUAN_EKLE", true);
					oMap.put("PUAN_EKLE_TUTAR", rSet3.getBigDecimal("PUAN"));
					oMap.put("PUAN_SIL", false);

				}
				else {
					oMap.put("PUAN_SIL", true);
					oMap.put("PUAN_EKLE", false);
					oMap.put("PUAN_SIL_TUTAR", rSet3.getBigDecimal("PUAN"));
				}
				oMap.put("MUSTERI_NO", rSet3.getBigDecimal("MUSTERI_NO"));
				oMap.put("AD_SOYAD", rSet3.getString("AD_SOYAD"));
				oMap.put("ACIKLAMA", rSet3.getString("ACIKLAMA"));

			}
			GMServerDatasource.close(rSet3);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
