package tr.com.calikbank.bnspr.consumerencourage.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeGuncelleTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeTalepTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeTalepTxId;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerEncourageTRN3230Services {
	@GraymoundService("BNSPR_TRN3230_SORGULA")
	public static GMMap hediyeTalepTakipSorgula(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			int i = 1;

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3230.sorgula(?,?,?,?)}");

			stmt.registerOutParameter(i++, -10); // ref cursor

			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));

			if (iMap.getDate("ALINMA_BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("ALINMA_BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);

			if (iMap.getDate("ALINMA_SON_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("ALINMA_SON_TARIH").getTime()));
			else
				stmt.setDate(i++, null);

			stmt.setString(i++, iMap.getString("HEDIYE_DURUM"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "HEDIYE_TALEP_LIST");
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_TRN3230_SAVE")
	public static GMMap hediyeTalepTakipSave(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirTesvikHediyeGuncelleTx birTesvikHediyeGuncelleTx = new BirTesvikHediyeGuncelleTx();
			birTesvikHediyeGuncelleTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birTesvikHediyeGuncelleTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birTesvikHediyeGuncelleTx.setBasTarih(iMap.getDate("BAS_TARIH"));
			birTesvikHediyeGuncelleTx.setBitTarih(iMap.getDate("BIT_TARIH"));
			birTesvikHediyeGuncelleTx.setHediyeDurum(iMap.getString("HEDIYE_DURUM"));
			session.saveOrUpdate(birTesvikHediyeGuncelleTx);
			session.flush();

			BirTesvikHediyeTalepTx birTesvikHediyeTalepTx = new BirTesvikHediyeTalepTx();
			BirTesvikHediyeTalepTxId id = new BirTesvikHediyeTalepTxId();

			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setId(iMap.getBigDecimal("ID"));
			birTesvikHediyeTalepTx.setId(id);
			birTesvikHediyeTalepTx.setAciklama(iMap.getString("ACIKLAMA"));
			birTesvikHediyeTalepTx.setAdres(iMap.getString("ADRES"));
			birTesvikHediyeTalepTx.setGuncellenenHediyeStatu(iMap.getString("GUNCEL_STATU"));
			birTesvikHediyeTalepTx.setHediyeStatu(iMap.getString("MEVCUT_STATU"));
			birTesvikHediyeTalepTx.setIlceKod(iMap.getString("ILCE_KOD"));
			birTesvikHediyeTalepTx.setIlKod(iMap.getString("IL_KOD"));
			birTesvikHediyeTalepTx.setIsyeriUnvani(iMap.getString("ISYERI_UNVAN"));
			birTesvikHediyeTalepTx.setReferansNo(iMap.getString("REFERANS_NO"));
			birTesvikHediyeTalepTx.setSemt(iMap.getString("SEMT"));
			birTesvikHediyeTalepTx.setTelAlan(iMap.getString("TEL_ALAN"));
			birTesvikHediyeTalepTx.setTelNo(iMap.getString("TEL_NO"));
			birTesvikHediyeTalepTx.setHediyeKod(iMap.getString("HEDIYE_KOD"));
			birTesvikHediyeTalepTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));

			session.saveOrUpdate(birTesvikHediyeTalepTx);
			session.flush();

			iMap.put("TRX_NAME", "3230");
			return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}
		finally {

		}

	}

	@GraymoundService("BNSPR_TRN3230_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBox(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "TESVIK_HEDIYE_STATU");

			oMap.put("HEDIYE_STATU", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			oMap.put("HEDIYE_DURUM", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			oMap.put("GUNCEL_STATU", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3230_GUNCEL_STATU_COMBO")
	public static GMMap fillGuncelStatuCombo(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3230.statu_combo(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("HEDIYE_STATU"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "GUNCEL_STATU", rSet.getString(1), rSet.getString(2));
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN3230_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;
		int i;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3230.GET_INFO(?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(2, -10); // ref cursor
			stmt.registerOutParameter(3, -10); // ref cursor
			stmt.registerOutParameter(4, -10); // ref cursor

			stmt.execute();
			rSet1 = (ResultSet) stmt.getObject(2);
			i = 0;
			while (rSet1.next()) {

				oMap.put("MUSTERI_NO", rSet1.getBigDecimal("MUSTERI_NO"));
				oMap.put("MUSTERI_AD", rSet1.getString("AD_SOYAD"));
				oMap.put("BAS_TARIH", rSet1.getDate("BAS_TARIH"));
				oMap.put("BIT_TARIH", rSet1.getDate("BIT_TARIH"));
				oMap.put("HEDIYE_DURUM", rSet1.getString("HEDIYE_DURUM"));
				i++;
			}
			GMServerDatasource.close(rSet1);

			rSet2 = (ResultSet) stmt.getObject(3);
			String tableName = "HEDIYE_TALEP_LIST";
			i = 0;
			while (rSet2.next()) {

				oMap.put(tableName, i, "ISLEM_TARIHI", rSet2.getDate("ISLEM_TARIHI"));
				oMap.put(tableName, i, "MUSTERI_NO", rSet2.getBigDecimal("MUSTERI_NO"));
				oMap.put(tableName, i, "MUSTERI_UNVAN", rSet2.getString("MUSTERI_UNVAN"));
				oMap.put(tableName, i, "HARCANAN_PUAN", rSet2.getBigDecimal("HARCANAN_PUAN"));
				oMap.put(tableName, i, "HEDIYE_KOD", rSet2.getString("HEDIYE_KOD"));
				oMap.put(tableName, i, "HEDIYE_ADI", rSet2.getString("HEDIYE_ADI"));
				oMap.put(tableName, i, "HEDIYE_STATU", rSet2.getString("HEDIYE_STATU"));
				i++;
			}
			GMServerDatasource.close(rSet2);

			rSet3 = (ResultSet) stmt.getObject(4);
			i = 0;
			while (rSet3.next()) {

				oMap.put("GUNCEL_STATU", rSet3.getString("GUNCELLENEN_HEDIYE_STATU"));
				oMap.put("REF_NO", rSet3.getString("REFERANS_NO"));
				oMap.put("ACIKLAMA", rSet3.getString("ACIKLAMA"));
				oMap.put("ISYERI_UNVANI", rSet3.getBigDecimal("ISYERI_UNVANI"));
				oMap.put("ADRES", rSet3.getString("ADRES"));
				oMap.put("SEMT", rSet3.getString("SEMT"));
				oMap.put("IL_KOD", rSet3.getString("IL_KOD"));
				oMap.put("IL_ADI", rSet3.getString("IL_ADI"));
				oMap.put("ILCE_KOD", rSet3.getString("ILCE_KOD"));
				oMap.put("ILCE_ADI", rSet3.getString("ILCE_ADI"));
				oMap.put("TEL_ALAN", rSet3.getString("IL_ADI"));
				oMap.put("TEL_NO", rSet3.getString("IL_ADI"));

				i++;
			}
			GMServerDatasource.close(rSet3);

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
