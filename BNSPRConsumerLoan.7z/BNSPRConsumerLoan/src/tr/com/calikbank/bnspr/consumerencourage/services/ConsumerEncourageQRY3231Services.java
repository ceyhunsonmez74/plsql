package tr.com.calikbank.bnspr.consumerencourage.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerEncourageQRY3231Services {
	@GraymoundService("BNSPR_QRY3231_SORGULA")
	public static GMMap puanHareketleriIzleSorgula(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		ResultSet rSet2 = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3231.sorgula(?,?,?)}");
			
			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.registerOutParameter(2, -10); // rc_calisan_list
			stmt.registerOutParameter(3, -10); // rc_puan_list
			stmt.execute();
			
            String tableName="CALISAN_BILGILERI";
            int i=0;
			rSet1 = (ResultSet) stmt.getObject(2);
			while (rSet1.next()) {
				oMap.put(tableName, i, "CALISTIGI_BAYI_KOD", rSet1.getBigDecimal("SATICI_KOD"));
				oMap.put(tableName, i, "CALISTIGI_BAYI_ADI", rSet1.getString("SATICI_ADI"));
				oMap.put(tableName, i, "CALISAN_NO", rSet1.getBigDecimal("CALISAN_NO"));
				i++;
			}
			GMServerDatasource.close(rSet1);

			rSet2 = (ResultSet) stmt.getObject(3);
			while (rSet2.next()) {
				oMap.put("TOPLAM_PUAN", rSet2.getBigDecimal("TOPLAM_PUAN"));
				oMap.put("HARCADIGI_PUAN", rSet2.getBigDecimal("HARCADIGI_PUAN"));
				oMap.put("KULLANILABILIR_PUAN", rSet2.getBigDecimal("KULLANILABILIR_PUAN"));
			}
			GMServerDatasource.close(rSet2);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3231_HAREKET_GORUNTULE")
	public static GMMap puanHareketleriGoruntule(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3231.hareket_goruntule(?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, -10); // rc_hareket_list
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

			if (iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(3, new java.sql.Date(iMap.getDate("BAS_TARIH")
						.getTime()));
			else
				stmt.setDate(3, null);

			if (iMap.getDate("BIT_TARIH") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("BIT_TARIH")
						.getTime()));
			else
				stmt.setDate(4, null);

			stmt.setBigDecimal(5,iMap.getBigDecimal("MIN_PUAN"));
			stmt.setBigDecimal(6,iMap.getBigDecimal("MAX_PUAN"));
			stmt.setString(7, iMap.getString("SECIM"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			String tableName="PUAN_HAREKETLERI";
			int i=0;
			while(rSet.next()){
				oMap.put(tableName, i, "ISLEM_TARIHI", rSet.getString("ISLEM_TARIHI"));
				oMap.put(tableName, i, "PUAN_TURU", rSet.getString("PUAN_TURU"));
				oMap.put(tableName, i, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
				oMap.put(tableName, i, "PUAN", rSet.getBigDecimal("PUAN"));
				oMap.put(tableName, i, "HEDIYE_ADI", rSet.getString("HEDIYE_ADI"));
				oMap.put(tableName, i, "KREDI_TUTARI", rSet.getBigDecimal("KREDI_TUTARI"));
				oMap.put(tableName, i, "MEVCUT_STATU", rSet.getString("MEVCUT_STATU"));
				oMap.put(tableName, i, "TALEBI_ALAN", rSet.getString("TALEBI_ALAN"));
				oMap.put(tableName, i, "SON_GUNCELLEYEN", rSet.getString("SON_GUNCELLEYEN"));
				oMap.put(tableName, i, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, i, "ILISKILI_TALEP_ID", rSet.getString("ILISKILI_TALEP_ID"));

				i++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}
	@GraymoundService("BNSPR_QRY3231_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBox(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "TESVIK_HEDIYE_STATU");
			oMap.put(
					"HEDIYE_STATU",
					GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
							iMap).get("RESULTS"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_QRY3231_DETAY_HAREKET")
	public static GMMap detayHareket(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3231.detay_hareket(?)}");

			stmt.registerOutParameter(1, -10); // rc_hareket_list
			stmt.setBigDecimal(2, iMap.getBigDecimal("ILISKILI_TALEP_ID"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			String tableName="DETAY_HAREKET";
			int i=0;
			while(rSet.next()){
				oMap.put(tableName, i, "ISLEM_TARIHI", rSet.getString("ISLEM_TARIHI"));
				oMap.put(tableName, i, "HEDIYE_STATU", rSet.getString("HEDIYE_STATU"));
				oMap.put(tableName, i, "GUNCELLENEN_STATU", rSet.getString("GUNCELLENEN_STATU"));
				oMap.put(tableName, i, "ISLEMI_YAPAN", rSet.getString("ISLEMI_YAPAN"));
				oMap.put(tableName, i, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, i, "ISYERI_UNVANI", rSet.getString("ISYERI_UNVANI"));
				oMap.put(tableName, i, "ADRES", rSet.getString("ADRES"));
				oMap.put(tableName, i, "SEMT", rSet.getString("SEMT"));
				oMap.put(tableName, i, "IL_KOD", rSet.getString("IL_KOD"));
				oMap.put(tableName, i, "IL_ADI", rSet.getString("IL_ADI"));
				oMap.put(tableName, i, "ILCE_KOD", rSet.getString("ILCE_KOD"));
				oMap.put(tableName, i, "ILCE_ADI", rSet.getString("ILCE_ADI"));
				oMap.put(tableName, i, "TEL_ALAN", rSet.getString("TEL_ALAN"));
				oMap.put(tableName, i, "TEL_NO", rSet.getString("TEL_NO"));

				i++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}
}
