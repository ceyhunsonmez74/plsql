package tr.com.calikbank.bnspr.consumerencourage.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeKodlariTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeKodlariTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerEncourageTRN3227Services {

	@GraymoundService("BNSPR_TRN3227_GET_HEDIYE_LIST")
	public static GMMap getHediyeList(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3227.get_hediye_list(?)}");

			stmt.registerOutParameter(1, -10); // ref cursor

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "HEDIYE_LIST");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_TRN3227_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBox(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "TESVIK_HEDIYE_KIMLER_ALABILIR");
			oMap.put(
					"KIMLER_ALABILIR",
					GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
							iMap).get("RESULTS"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3227_SAVE")
	public static Map<?, ?> hediyeSave(GMMap iMap) {

		String tableName = "HEDIYE_LIST";
		int i = 0;
		int o = 0;
		BigDecimal hataKod = new BigDecimal(2184);

		List<?> list = (List<?>) iMap.get(tableName);

		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
  
				for (i = 0; i < list.size(); i++) {
					
                  if(iMap.getString(tableName,i,"KOD")==null || iMap.getString(tableName, i, "KOD").length() ==0){
                	   iMap.put("P1", "Hediye Kod");
                	   iMap.put("HATA_NO", new BigDecimal(330));
					   GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ",
								iMap);
                  }
                   
					for (int j = i + 1; j < list.size(); j++) {
						
						if(iMap.getString(tableName,j,"KOD")==null || iMap.getString(tableName, j, "KOD").length()==0){
		                	   iMap.put("P1", "Hediye Kod");
		                	   iMap.put("HATA_NO", new BigDecimal(330));
							   GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ",
										iMap);
		                   }
						
						o = iMap.getString(tableName, j, "KOD").compareTo(
								iMap.getString(tableName, i, "KOD"));

						if (o == 0) {
							iMap.put("HATA_NO", hataKod);
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ",
									iMap);

						}
					}

					
					BirTesvikHediyeKodlariTx birTesvikHediyeKodlariTx = new BirTesvikHediyeKodlariTx();
			        BirTesvikHediyeKodlariTxId id = new BirTesvikHediyeKodlariTxId();

					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setKod(iMap.getString(tableName, i, "KOD"));
                    birTesvikHediyeKodlariTx.setId(id);
					birTesvikHediyeKodlariTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
					birTesvikHediyeKodlariTx.setAd(iMap.getString(tableName, i,"AD"));
					
					if (iMap.getBoolean(tableName, i, "DURUM"))
						birTesvikHediyeKodlariTx.setDurum("A");
					else
						birTesvikHediyeKodlariTx.setDurum("K");
					
                    birTesvikHediyeKodlariTx.setKimlerAlabilir(iMap.getString( tableName, i, "KIMLER_ALABILIR"));
					birTesvikHediyeKodlariTx.setPuan(iMap.getBigDecimal(tableName, i, "PUAN"));
					session.saveOrUpdate(birTesvikHediyeKodlariTx);
	
				}

			session.flush();

			iMap.put("TRX_NAME", "3227");
			return new GMMap(GMServiceExecuter.execute(
					"BNSPR_TRX_SEND_TRANSACTION", iMap));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN3227_VIEW_INIT")
	public static GMMap hediyeView(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session
					.createCriteria(BirTesvikHediyeKodlariTx.class)
					.add(Restrictions.eq("id.txNo",
							iMap.getBigDecimal("TRX_NO"))).list();

			String tableName = "HEDIYE_LIST";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirTesvikHediyeKodlariTx birTesvikHediyeKodlariTx = (BirTesvikHediyeKodlariTx) iterator
						.next();
				oMap.put(tableName, row, "KOD", birTesvikHediyeKodlariTx
						.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA",
						birTesvikHediyeKodlariTx.getAciklama());
				oMap.put(tableName, row, "AD", birTesvikHediyeKodlariTx.getAd());
				
				if(birTesvikHediyeKodlariTx.getDurum().compareTo("A")==0){
				  oMap.put(tableName, row, "DURUM", new BigDecimal(1));}
				else{
				  oMap.put(tableName, row, "DURUM",new BigDecimal(0));
				}
					
				oMap.put(tableName, row, "KIMLER_ALABILIR",
						birTesvikHediyeKodlariTx.getKimlerAlabilir());
				oMap.put(tableName, row, "PUAN",
						birTesvikHediyeKodlariTx.getPuan());
				row++;
			}

		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
}
