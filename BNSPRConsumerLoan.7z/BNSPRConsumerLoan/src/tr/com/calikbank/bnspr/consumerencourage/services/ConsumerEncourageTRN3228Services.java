package tr.com.calikbank.bnspr.consumerencourage.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeTalepTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeTalepTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerEncourageTRN3228Services {

	@GraymoundService("BNSPR_TRN3228_SORGULA")
	public static GMMap hediyeTalepSorgula(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;
		ResultSet rSet4 = null;
		String tableName;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3228.sorgula(?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));

			if (iMap.getBoolean("CHECK_BOX"))
				stmt.setString(2, "E");
			else
				stmt.setString(2, "H");

			stmt.registerOutParameter(3, -10); // rc_calisan_bilgi
			stmt.registerOutParameter(4, -10); // rc_puan_bilgi
			stmt.registerOutParameter(5, -10); // rc_hediye_bilgi
			stmt.registerOutParameter(6, -10); // rc_adres_bilgi

			stmt.execute();
			rSet1 = (ResultSet) stmt.getObject(3);
			tableName="CALISAN_BILGILERI";
			int i=0;
			while (rSet1.next()) {
				oMap.put(tableName, i, "CALISTIGI_BAYI_KOD", rSet1.getBigDecimal("SATICI_KOD"));
				oMap.put(tableName, i, "CALISTIGI_BAYI_ADI", rSet1.getString("SATICI_ADI"));
				oMap.put(tableName, i, "CALISAN_NO", rSet1.getBigDecimal("CALISAN_NO"));
				i++;
			}
			GMServerDatasource.close(rSet1);

			rSet2 = (ResultSet) stmt.getObject(4);
			while (rSet2.next()) {
				oMap.put("TOPLAM_PUAN", rSet2.getBigDecimal("TOPLAM_PUAN"));
				oMap.put("HARCADIGI_PUAN", rSet2.getBigDecimal("HARCADIGI_PUAN"));
				oMap.put("KULLANILABILIR_PUAN", rSet2.getBigDecimal("KULLANILABILIR_PUAN"));
			}
			GMServerDatasource.close(rSet2);
	
			rSet3 = (ResultSet) stmt.getObject(5);
			tableName = "HEDIYE_BILGI";
		    i = 0;
			while (rSet3.next()) {
				oMap.put(tableName, i, "KOD", rSet3.getString("KOD"));
				oMap.put(tableName, i, "AD", rSet3.getString("AD"));
				oMap.put(tableName, i, "ACIKLAMA", rSet3.getString("ACIKLAMA"));
				oMap.put(tableName, i, "PUAN", rSet3.getString("PUAN"));
				i++;
			}
			GMServerDatasource.close(rSet3);

			rSet4 = (ResultSet) stmt.getObject(6);
			while (rSet4.next()) {
				oMap.put("ADRES", rSet4.getString("ADRES"));
				oMap.put("SEMT", rSet4.getString("SEMT"));
				oMap.put("IL_KOD", rSet4.getString("IL_KOD"));
				oMap.put("ILCE_KOD", rSet4.getString("ILCE_KOD"));
				oMap.put("TEL_ALAN", rSet4.getString("TEL_ALAN"));
				oMap.put("TEL_NO", rSet4.getString("TEL_NO"));
				oMap.put("IL_ADI", rSet4.getString("IL_ADI"));
				oMap.put("ILCE_ADI", rSet4.getString("ILCE_ADI"));
				oMap.put("UNVAN", rSet4.getString("ISYERI_UNVANI"));
			}
			GMServerDatasource.close(rSet4);

			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(rSet4);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3228_SAVE")
	public static GMMap hediyeTalepSave(GMMap iMap) {

		String tableName = "HEDIYE_BILGI";

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) iMap.get(tableName);

				for (int i = 0; i < list.size(); i++) {

					if (iMap.getBoolean(tableName, i, "SECIM")){

						BirTesvikHediyeTalepTx birTesvikHediyeTalepTx = new BirTesvikHediyeTalepTx();
						BirTesvikHediyeTalepTxId id = new BirTesvikHediyeTalepTxId();
                        
						id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                        id.setId(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO",iMap).getBigDecimal("SIRA_NO"));
                    	birTesvikHediyeTalepTx.setId(id);
						birTesvikHediyeTalepTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
						birTesvikHediyeTalepTx.setHediyeKod(iMap.getString(tableName, i, "KOD"));
                        birTesvikHediyeTalepTx.setHediyeStatu("TA");
                        birTesvikHediyeTalepTx.setGuncellenenHediyeStatu("TA");

						if (iMap.getBoolean("CHECK_BOX"))
							birTesvikHediyeTalepTx.setSadecePuaniYetenEh("E");
						else
							birTesvikHediyeTalepTx.setSadecePuaniYetenEh("H");

						birTesvikHediyeTalepTx.setAciklama(iMap.getString("ACIKLAMA"));
						birTesvikHediyeTalepTx.setAdres(iMap.getString("ADRES"));
						birTesvikHediyeTalepTx.setSemt(iMap.getString("SEMT"));
						birTesvikHediyeTalepTx.setTelAlan(iMap.getString("TEL_ALAN"));
						birTesvikHediyeTalepTx.setTelNo(iMap.getString("TEL_NO"));
						birTesvikHediyeTalepTx.setIlceKod(iMap.getString("ILCE_KOD"));
						birTesvikHediyeTalepTx.setIlKod(iMap.getString("IL_KOD"));
						birTesvikHediyeTalepTx.setIsyeriUnvani(iMap.getString("UNVAN"));
						session.saveOrUpdate(birTesvikHediyeTalepTx);
						
					}
				}
			
			session.flush();
			iMap.put("TRX_NAME", "3228");
			return new GMMap(GMServiceExecuter.execute(
					"BNSPR_TRX_SEND_TRANSACTION", iMap));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		} finally {

		}
	}
	@GraymoundService("BNSPR_TRN3228_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;
		ResultSet rSet4 = null;
        String tableName;
	  try{
		
		GMMap oMap = new GMMap();
		conn = DALUtil.getGMConnection();
		stmt = conn.prepareCall("{call PKG_TRN3228.GET_INFO(?,?,?,?,?)}");
		stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
		stmt.registerOutParameter(2, -10); //ref cursor
		stmt.registerOutParameter(3, -10); //ref cursor
		stmt.registerOutParameter(4, -10); //ref cursor
		stmt.registerOutParameter(5, -10); //ref cursor
		stmt.execute();
		
		rSet1 = (ResultSet)stmt.getObject(2);
		tableName="CALISAN_BILGILERI";
		int i=0;
		while(rSet1.next()){
		  oMap.put(tableName, i, "CALISTIGI_BAYI_KOD",rSet1.getBigDecimal("SATICI_KOD"));
		  oMap.put(tableName, i,"CALISTIGI_BAYI_ADI", rSet1.getString("SATICI_ADI"));
		  oMap.put(tableName, i,"CALISAN_NO",rSet1.getBigDecimal("CALISAN_NO"));
		  i++;
		}
		GMServerDatasource.close(rSet1);
		
		rSet2 = (ResultSet)stmt.getObject(3);
		if (rSet2.next()) {
			oMap.put("TOPLAM_PUAN", rSet2.getBigDecimal("TOPLAM_PUAN"));
			oMap.put("HARCADIGI_PUAN", rSet2.getBigDecimal("HARCADIGI_PUAN"));
			oMap.put("KULLANILABILIR_PUAN", rSet2.getBigDecimal("KULLANILABILIR_PUAN"));
		}
		GMServerDatasource.close(rSet2);
		
		rSet3 = (ResultSet)stmt.getObject(4);
		tableName = "HEDIYE_BILGI";
	    i = 0;
		while (rSet3.next()) {
			oMap.put(tableName, i, "KOD", rSet3.getString("KOD"));
			oMap.put(tableName, i, "AD", rSet3.getString("AD"));
			oMap.put(tableName, i, "ACIKLAMA", rSet3.getString("ACIKLAMA"));
			oMap.put(tableName, i, "PUAN", rSet3.getString("PUAN"));
			if(new BigDecimal(1).compareTo(rSet3.getBigDecimal("SECIM"))==0)
			{
		      oMap.put(tableName, i,  "SECIM", true);
		    }
			else{
			  oMap.put(tableName, i,  "SECIM", false);
			}
			i++;
		}
		GMServerDatasource.close(rSet3);
		
		rSet4 = (ResultSet)stmt.getObject(5);
		while (rSet4.next()) {
			oMap.put("MUSTERI_NO", rSet4.getBigDecimal("MUSTERI_NO"));
			oMap.put("AD_SOYAD", rSet4.getString("AD_SOYAD"));
			if("E".compareTo(rSet4.getString("SADECE_PUANI_YETEN_EH"))==0)
			{
			   oMap.put("PUANI_YETECEK_HEDIYELER", true);
			}
			else{
			   oMap.put("PUANI_YETECEK_HEDIYELER", false);
			}
			oMap.put("ADRES", rSet4.getString("ADRES"));
			oMap.put("SEMT", rSet4.getString("SEMT"));
			oMap.put("IL_KOD", rSet4.getString("IL_KOD"));
			oMap.put("ILCE_KOD", rSet4.getString("ILCE_KOD"));
			oMap.put("TEL_ALAN", rSet4.getString("TEL_ALAN"));
			oMap.put("TEL_NO", rSet4.getString("TEL_NO"));
			oMap.put("IL_ADI", rSet4.getString("IL_ADI"));
			oMap.put("ILCE_ADI", rSet4.getString("ILCE_ADI"));
			oMap.put("UNVAN", rSet4.getString("ISYERI_UNVANI"));
			oMap.put("ACIKLAMA", rSet4.getString("ACIKLAMA"));

		}
		GMServerDatasource.close(rSet4);
		return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(rSet4);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
