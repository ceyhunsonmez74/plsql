package tr.com.calikbank.bnspr.consumerencourage.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeiptalTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeTalepTxId;
import tr.com.aktifbank.bnspr.dao.BirTesvikHediyeTalepTx;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerEncourageTRN3229Services {
	@GraymoundService("BNSPR_TRN3229_SORGULA")
	public static GMMap hediyeTalepIptalSorgula(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
		
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3229.sorgula(?,?,?,?)}");
    	
			stmt.registerOutParameter(1, -10); //ref cursor
            stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
            if (iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(3,
						new java.sql.Date(iMap.getDate("BAS_TARIH")
								.getTime()));
			else
				stmt.setDate(3, null);

			if (iMap.getDate("BIT_TARIH") != null)
				stmt.setDate(4,
						new java.sql.Date(iMap.getDate("BIT_TARIH")
								.getTime()));
			else
				stmt.setDate(4, null);
			stmt.setString(5, iMap.getString("HEDIYE_DURUM"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName="HEDIYE_TALEP_LIST";
			int i=0;
		    while(rSet.next()){
		    	oMap.put(tableName, i, "ID",rSet.getBigDecimal("ID"));
				oMap.put(tableName, i, "ISLEM_TARIHI",rSet.getDate("ISLEM_TARIHI"));
				oMap.put(tableName, i, "MUSTERI_NO",rSet.getBigDecimal("MUSTERI_NO"));
				oMap.put(tableName, i, "MUSTERI_UNVAN",rSet.getString("MUSTERI_UNVAN"));
				oMap.put(tableName, i, "HARCANAN_PUAN",rSet.getBigDecimal("HARCANAN_PUAN"));
				oMap.put(tableName, i, "HEDIYE_KOD",rSet.getString("HEDIYE_KOD"));
				oMap.put(tableName, i, "HEDIYE_ADI",rSet.getString("HEDIYE_ADI"));
				oMap.put(tableName, i, "MEVCUT_STATU",rSet.getString("HEDIYE_STATU"));
				oMap.put(tableName, i, "REFERANS_NO",rSet.getString("REFERANS_NO"));
				oMap.put(tableName, i, "ACIKLAMA",rSet.getString("ACIKLAMA"));
				oMap.put(tableName, i, "ISYERI_UNVANI",rSet.getString("ISYERI_UNVANI"));
				oMap.put(tableName, i, "ADRES",rSet.getString("ADRES"));
				oMap.put(tableName, i, "SEMT",rSet.getString("SEMT"));
				oMap.put(tableName, i, "IL_KOD",rSet.getString("IL_KOD"));
				oMap.put(tableName, i, "ILCE_KOD",rSet.getString("ILCE_KOD"));
				oMap.put(tableName, i, "TEL_ALAN",rSet.getString("TEL_ALAN"));
				oMap.put(tableName, i, "TEL_NO",rSet.getString("TEL_NO"));

		    	i++;
		    }
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
	
		}
	}
	@GraymoundService("BNSPR_TRN3229_SAVE")
	public static Map<?, ?> save(GMMap iMap){

		try{
			Session session = DAOSession.getSession("BNSPRDal"); 
            String tableName = "HEDIYE_TALEP_LIST";
			List<?> guiList = (List<?>)iMap.get(tableName);
			if(guiList.size()==0){
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			BirTesvikHediyeiptalTx birTesvikHediyeIptalTx = new BirTesvikHediyeiptalTx();
			birTesvikHediyeIptalTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birTesvikHediyeIptalTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birTesvikHediyeIptalTx.setBasTarih(iMap.getDate("BAS_TARIH"));
			birTesvikHediyeIptalTx.setBitTarih(iMap.getDate("BIT_TARIH"));
			birTesvikHediyeIptalTx.setHediyeDurum(iMap.getString("HEDIYE_DURUM"));
		    session.save(birTesvikHediyeIptalTx);
		    session.flush();

			for (int i = 0; i < guiList.size(); i++) {
			 if(iMap.getBoolean(tableName, i, "IPTAL")){
				BirTesvikHediyeTalepTx birTesvikHediyeTalepTx = new BirTesvikHediyeTalepTx();
				BirTesvikHediyeTalepTxId id=new BirTesvikHediyeTalepTxId();
				
			    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			    id.setId(iMap.getBigDecimal(tableName, i, "ID"));
			    birTesvikHediyeTalepTx.setId(id);
			    birTesvikHediyeTalepTx.setHediyeStatu(iMap.getString(tableName, i, "MEVCUT_STATU"));
			    birTesvikHediyeTalepTx.setGuncellenenHediyeStatu("IP");
			    birTesvikHediyeTalepTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
			    birTesvikHediyeTalepTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
			    birTesvikHediyeTalepTx.setHediyeKod(iMap.getString(tableName, i, "HEDIYE_KOD"));
			    birTesvikHediyeTalepTx.setIsyeriUnvani(iMap.getString(tableName, i, "ISYERI_UNVANI"));
			    birTesvikHediyeTalepTx.setAdres(iMap.getString(tableName, i, "ADRES"));
			    birTesvikHediyeTalepTx.setSemt(iMap.getString(tableName, i, "SEMT"));
			    birTesvikHediyeTalepTx.setIlKod(iMap.getString(tableName, i, "IL_KOD"));
			    birTesvikHediyeTalepTx.setIlceKod(iMap.getString(tableName, i, "ILCE_KOD"));
			    birTesvikHediyeTalepTx.setTelAlan(iMap.getString(tableName, i, "TEL_ALAN"));
			    birTesvikHediyeTalepTx.setTelNo(iMap.getString(tableName, i, "TEL_NO"));

			    session.save(birTesvikHediyeTalepTx);
			 }				
			}
			session.flush();  
			iMap.put("TRX_NAME", "3229");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3229_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBox(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "TESVIK_HEDIYE_STATU");
			oMap.put(
					"HEDIYE_DURUM",
					GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
							iMap).get("RESULTS"));
			oMap.put(
					"MEVCUT_STATU",
					GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
							iMap).get("RESULTS"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3229_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = (List<?>)session.createCriteria(BirTesvikHediyeiptalTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();

		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			BirTesvikHediyeiptalTx birTesvikHediyeiptalTx = (BirTesvikHediyeiptalTx) iterator.next();
			oMap.put("MUSTERI_NO", birTesvikHediyeiptalTx.getMusteriNo());
			oMap.put("BAS_TARIH", birTesvikHediyeiptalTx.getBasTarih());
			oMap.put("BIT_TARIH", birTesvikHediyeiptalTx.getBitTarih());
			oMap.put("HEDIYE_DURUM", birTesvikHediyeiptalTx.getHediyeDurum());	
		}
		conn = DALUtil.getGMConnection();
		stmt = conn.prepareCall("{? = call PKG_TRN3229.GET_INFO(?,?,?,?,?)}");
			
		stmt.registerOutParameter(1, -10); //ref cursor
		stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
		stmt.setBigDecimal(3, oMap.getBigDecimal("MUSTERI_NO"));
		if (oMap.getDate("BAS_TARIH") != null)
			stmt.setDate(4,
					new java.sql.Date(oMap.getDate("BAS_TARIH")
							.getTime()));
		else
			stmt.setDate(4, null);

		if (oMap.getDate("BIT_TARIH") != null)
			stmt.setDate(5,
					new java.sql.Date(oMap.getDate("BIT_TARIH")
							.getTime()));
		else
			stmt.setDate(5, null);
		stmt.setString(6, oMap.getString("HEDIYE_DURUM"));

		stmt.execute();
		rSet = (ResultSet)stmt.getObject(1);
		String tableName="HEDIYE_TALEP_LIST";
		int i=0;
		while(rSet.next()){
			
		oMap.put(tableName, i, "ID",rSet.getBigDecimal("ID"));
		oMap.put(tableName, i, "ISLEM_TARIHI",rSet.getDate("ISLEM_TARIHI"));
		oMap.put(tableName, i, "MUSTERI_NO",rSet.getBigDecimal("MUSTERI_NO"));
		oMap.put(tableName, i, "MUSTERI_UNVAN",rSet.getString("MUSTERI_UNVAN"));
		oMap.put(tableName, i, "HARCANAN_PUAN",rSet.getBigDecimal("HARCANAN_PUAN"));
		oMap.put(tableName, i, "HEDIYE_KOD",rSet.getString("HEDIYE_KOD"));
		oMap.put(tableName, i, "HEDIYE_ADI",rSet.getString("HEDIYE_ADI"));
		oMap.put(tableName, i, "MEVCUT_STATU",rSet.getString("HEDIYE_STATU"));
		oMap.put(tableName, i, "REFERANS_NO",rSet.getString("REFERANS_NO"));
		oMap.put(tableName, i, "ACIKLAMA",rSet.getString("ACIKLAMA"));
		oMap.put(tableName, i, "IPTAL",rSet.getBigDecimal("IPTAL"));
		oMap.put("MUSTERI_AD", rSet.getString("MUSTERI_AD"));

        i++;
		}
        	return oMap;
        	
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}

