package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirTemPoliceKayitTx;
import tr.com.aktifbank.bnspr.dao.BirTemPoliceKayitTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3252Services {

	@GraymoundService("BNSPR_TRN3252_IMPORT_EXCEL")
	public static GMMap excelToTable(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			byte[] inputFile = (byte[]) iMap.get("FILE");
			if (inputFile == null) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Dosya se�mediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Workbook workbook;
			WorkbookSettings ws = new WorkbookSettings();

			// ws.setCharacterSet(cs);
			ws.setEncoding("ISO-8859-9");
			ws.setExcelDisplayLanguage("TR");
			ws.setExcelRegionalSettings("TR");
			ws.setLocale(new Locale("tr", "TR"));
			try {
				workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
				if (workbook.getSheet(0).getColumns() != 3) {
					throw new GMRuntimeException(0, "Yanl�� Kolon Say�s�.");
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Sheet sheet = workbook.getSheet(0);
			for (int j = 0; j + 1 < sheet.getRows(); j++) {
				for (int i = 0; i < sheet.getColumns(); i++) {
					oMap.put("TABLE", j, "COLUMN_" + (i), sheet.getCell(i, j + 1).getContents());
				}

			}
			oMap.put("SATIR_SAYISI", oMap.getSize("TABLE"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}

	}

	@GraymoundService("BNSPR_TRN3252_SAVE")
	public static Map<?, ?> saveTRN3252(GMMap iMap) {
		try {
			if ("".equals(iMap.getString("SIGORTA_SIRKET"))) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Sigorta �irketi se�iniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("FILE_NAME") == null) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Dosya se�iniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Session session = DAOSession.getSession("BNSPRDal");
			@SuppressWarnings("unchecked")
			List<BirTemPoliceKayitTx> policeList = (List<BirTemPoliceKayitTx>) session.createCriteria(BirTemPoliceKayitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (BirTemPoliceKayitTx kayit : policeList) {
				session.delete(kayit);
				session.flush();
			}
			for (int i = 0; i < iMap.getSize("TABLE"); i++) {
				BirTemPoliceKayitTx birTemPoliceKayitTx = new BirTemPoliceKayitTx();
				BirTemPoliceKayitTxId Id = new BirTemPoliceKayitTxId();
				Id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				Id.setPoliceNo(iMap.getString("TABLE", i, "COLUMN_0"));
				birTemPoliceKayitTx.setId(Id);
				birTemPoliceKayitTx.setDosyaAdi(iMap.getString("FILE_NAME"));
				birTemPoliceKayitTx.setBasvuruNo(iMap.getBigDecimal("TABLE", i, "COLUMN_1"));
				birTemPoliceKayitTx.setTcKimlikNo(iMap.getString("TABLE", i, "COLUMN_2"));
				birTemPoliceKayitTx.setSigortaSirket(iMap.getString("SIGORTA_SIRKET"));
				session.save(birTemPoliceKayitTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3252");

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}

	}
}
