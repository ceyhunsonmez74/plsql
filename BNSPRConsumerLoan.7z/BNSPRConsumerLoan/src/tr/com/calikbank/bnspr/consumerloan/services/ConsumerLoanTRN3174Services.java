package tr.com.calikbank.bnspr.consumerloan.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTarim;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTasit;
import tr.com.aktifbank.bnspr.dao.BirTahsisDegerGorusTx;
import tr.com.aktifbank.bnspr.dao.BirTahsisDegerGorusTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminatTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminatTxId;
import tr.com.calikbank.bnspr.dao.BirTahsisDegerTx;
import tr.com.calikbank.bnspr.dao.BirTahsisDogrulamaTx;
import tr.com.calikbank.bnspr.dao.BirTahsisDogrulamaTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3174Services {

	private enum enmScreenCode {
		ONAY1("ONAY1", 3174), ONAY2("ONAY2", 3175), ONAY3("ONAY3", 3176), ONAY4("ONAY4", 3177);

		private String durumKod;
		private int screenCode;

		private enmScreenCode(String durumKod, int screenCode) {
			this.durumKod = durumKod;
			this.screenCode = screenCode;
		}

		public String getDurumKod() {
			return durumKod;
		}

		public int getScreenCode() {
			return screenCode;
		}
	}

	private static final String calendarFormat = "yyyyMMdd kkmmss";

	@GraymoundService("BNSPR_TRN3174_GET_DETAY")
	public static GMMap getDetay(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		try {
			GMMap oMap = new GMMap();
			String ekranNo = iMap.getString("EKRAN_NO");
			String durumKodu = null;
			if ("3174".equals(ekranNo))
				durumKodu = "ONAY1";
			else if ("3175".equals(ekranNo))
				durumKodu = "ONAY2";
			else if ("3176".equals(ekranNo))
				durumKodu = "ONAY3";
			else if ("3177".equals(ekranNo))
				durumKodu = "ONAY4";

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3174.RC_QRY3174_GET_DETAY_LIST(?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, durumKodu);

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetMap(rSet));

			if (oMap.getString("ANNE_KIZLIK_SOYADI") != null) {

				StringBuffer anneOncekiSoyad = new StringBuffer(oMap.getString("ANNE_KIZLIK_SOYADI"));

				for (int i = 0; i < anneOncekiSoyad.length(); i++) {
					if (i % 2 == 1) {
						anneOncekiSoyad.setCharAt(i, '*');
					}
				}

				oMap.put("ANNE_KIZLIK_SOYADI", anneOncekiSoyad);
			}

			BigDecimal onOnayTut = oMap.getBigDecimal("ON_ONAY_TUTAR");
			oMap.put("ON_ONAYLI_MI", onOnayTut.signum() > 0);

			if (oMap.getString("BAYI_GORUS") != null)
				oMap.put("BAYI_GORUS", oMap.getString("BAYI_GORUS").replace(", ", "\n").trim());

			oMap.put("TEMINAT", GMServiceExecuter.execute("BNSPR_TRN3174_GET_TEMINAT_LIST", iMap).get("TEMINAT"));
			oMap.put("BELGE", GMServiceExecuter.execute("BNSPR_TRN3174_GET_BELGE_LIST", iMap).get("BELGE"));
			oMap.put("TAHSIS_GORUS_LIST", GMServiceExecuter.execute("BNSPR_TRN3174_GET_TAHSIS_GORUS_LIST", iMap).get("TAHSIS_GORUS_LIST"));
			oMap.put("MUSTERI_KONTROL_LIST", GMServiceExecuter.execute("BNSPR_TRN3174_GET_MUSTERI_KONTROL_TAKIP", iMap).get("MUSTERI_KONTROL_LIST"));
			if (oMap.getString("SATICI_KOD") == null && oMap.getString("MERKEZ_BAYI_KOD") != null)
				iMap.put("SATICI_KOD", oMap.getString("MERKEZ_BAYI_KOD"));
			else
				iMap.put("SATICI_KOD", oMap.getString("SATICI_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3174_GET_SATICI_TAHSIS_DATA", iMap));
			oMap.put("KONTAKT_MUSTERI", "K".equals(oMap.getString("KONTAKT_MUSTERI")) ? true : false);
			oMap.put("ISTEGE_BAGLI_SIGORTALI", "E".equals(oMap.getString("KONTAKT_MUSTERI")) ? true : false);
			if (oMap.get("KREDI_TUR") != null) {
				oMap.put("KREDI_TUR", oMap.remove("KREDI_TUR").toString());
			}
			if (oMap.get("ODEME_TIP_KOD") != null) {
				oMap.put("ODEME_TIP_KOD", oMap.remove("ODEME_TIP_KOD").toString());
			}

			// Distributor Tablosu
			stmt.clearParameters();
			stmt.close();

			stmt = conn.prepareCall("{? = call pkg_trn3174.RC_QRY3174_GET_DISTRIBUTOR(?)}");
			stmt.registerOutParameter(1, -10);
			if (oMap.getString("SATICI_KOD") == null && oMap.getString("MERKEZ_BAYI_KOD") != null)
				stmt.setBigDecimal(2, oMap.getBigDecimal("MERKEZ_BAYI_KOD"));
			else
				stmt.setBigDecimal(2, oMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();

			rSet2 = (ResultSet) stmt.getObject(1);

			String tableName = "DISTRIBUTOR";
			int row = 0;

			while (rSet2.next()) {
				oMap.put(tableName, row, "KOD", rSet2.getBigDecimal(1));
				oMap.put(tableName, row, "SATICI_ADI", rSet2.getString(2));
				row++;
			}
			// Distributor Tablosu Sonu

			String kanal = oMap.getString("DST_KAZANIM_KANAL");
			if (kanal != null && !kanal.isEmpty()) {
				// bayi kazan�m kanal� degeri parametreden al�n�r
				GMMap paramMap = new GMMap();
				paramMap.put("KOD", "BAYI_KAZANIM_KANAL");
				paramMap.put("KEY", oMap.getString("DST_KAZANIM_KANAL"));
				oMap.put("DST_KAZANIM_KANAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).get("TEXT"));
			}
			
			try {
				BirBasvuruTasit tasit = (BirBasvuruTasit) session.createCriteria(BirBasvuruTasit.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				if ("3".equals(tasit.getAracTipi())) {
					oMap.put("KONSINYE_EH", "1");
				} else {
					oMap.put("KONSINYE_EH", "0");
				}
			}
			catch (Exception e) {
				oMap.put("KONSINYE_EH", "0");
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_TAHSIS_DETAY")
	public static GMMap getTahsisDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3174.RC_QRY3174_GET_TAHSIS_DETAY(?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("EKRAN_ADI"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetMap(rSet));

			if (oMap.getString("KARAR") != null && oMap.getString("KARAR").equals("I") && oMap.getString("IADE_KOD") != null && oMap.getString("IADE_KOD").equals("DOGRULAMA")) {

				oMap.put("MUSTERI_DOG_IADE", "N");
				oMap.put("MUSTERI_ISYERI_DOG_IADE", "Not Required");
				oMap.put("1KEFIL_IADE", "Not Required");
				oMap.put("2KEFIL_IADE", "Not Required");
				// PY-2273
				oMap.put("MUSTERI_FRAUD_DOG_IADE", "N");
				oMap.put("MUSTERI_WEB_DOG_IADE", "N");
				oMap.put("1KEFIL_FRAUD_IADE", "N");
				oMap.put("2KEFIL_FRAUD_IADE", "N");

				String nbsmDogSonucStr = (oMap.getString("NBSM_DOG_SONUC_STR_M") == null ? "" : oMap.getString("NBSM_DOG_SONUC_STR_M")) + "-" + (oMap.getString("NBSM_DOG_SONUC_STR_K1") == null ? "" : oMap.getString("NBSM_DOG_SONUC_STR_K1")) + "-" + (oMap.getString("NBSM_DOG_SONUC_STR_K2") == null ? "" : oMap.getString("NBSM_DOG_SONUC_STR_K2"));
				if (nbsmDogSonucStr != null && !nbsmDogSonucStr.equals("")) {
					int size = nbsmDogSonucStr.split("-").length;
					for (int i = 0; i < size; i++) {
						if (nbsmDogSonucStr.split("-")[i].contains("MAppVer")) {
							oMap.put("MUSTERI_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("MEmptVer")) {
							oMap.put("MUSTERI_ISYERI_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("K1EmptVer")) {
							oMap.put("1KEFIL_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("K2EmptVer")) {
							oMap.put("2KEFIL_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						// PY-2273
						else if (nbsmDogSonucStr.split("-")[i].contains("MFraudVer")) {
							oMap.put("MUSTERI_FRAUD_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("MWebVer")) {
							oMap.put("MUSTERI_WEB_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("K1FraudVer")) {
							oMap.put("1KEFIL_FRAUD_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("K2FraudVer")) {
							oMap.put("2KEFIL_FRAUD_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
					}
				}
			}

			StringBuffer query = new StringBuffer();
			query.append("select key2,text from gnl_param_text where kod = 'BASVURU_AKSIYON_KARAR_KOD'");
			DALUtil.fillComboBox(oMap, "MODEL_AKSIYON_KARAR_KOD", true, query.toString());

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_BELGE_LIST")
	public static GMMap getBelgeList(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();

			GMMap oMap = new GMMap();
			String tableName = "BELGE";
			int row = 0;
			for (Object name : list) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) name;

				oMap.put(tableName, row, "KIMDEN", LovHelper.diLov(birBasvuruBelge.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
				oMap.put(tableName, row, "KIMDEN_KOD", birBasvuruBelge.getId().getKimden());
				oMap.put(tableName, row, "ALINDI", birBasvuruBelge.getAlindi());
				oMap.put(tableName, row, "BELGE_KONTROL", birBasvuruBelge.getBelgeKontrol());
				oMap.put(tableName, row, "ORJINAL_EVRAK_MI", birBasvuruBelge.getOrjinalEvrakMi());
				if (birBasvuruBelge.getBelgeGelisTarihi() != null)
					oMap.put(tableName, row, "BELGE_GELIS_TARIHI", new SimpleDateFormat(calendarFormat).format(birBasvuruBelge.getBelgeGelisTarihi()));
				if (birBasvuruBelge.getIslemTarihi() != null)
					oMap.put(tableName, row, "ISLEM_TARIHI", new SimpleDateFormat(calendarFormat).format(birBasvuruBelge.getIslemTarihi()));
				oMap.put(tableName, row, "BELGE_HATA", birBasvuruBelge.getBelgeHata());
				oMap.put(tableName, row, "BARKOD_NUMARASI", birBasvuruBelge.getBarkodNumarasi());
				oMap.put(tableName, row, "ONAYLI_MI", birBasvuruBelge.getOnayliMi());
				oMap.put(tableName, row, "UYUMSUZ_ACIKLAMA", birBasvuruBelge.getUyumsuzAciklama());
				oMap.put(tableName, row, "BELGE_YERI", birBasvuruBelge.getBelgeYeri());
				oMap.put(tableName, row, "KONTROL_NEDENI", birBasvuruBelge.getKontrolNedeni());
				oMap.put(tableName, row, "ISLEM_YAPAN_KULLANICI", birBasvuruBelge.getIslemYapanKullanici());
				oMap.put(tableName, row, "BELGE_KOD", birBasvuruBelge.getId().getDokumanKod());
				oMap.put(tableName, row, "BELGE_ADI", LovHelper.diLov(birBasvuruBelge.getId().getDokumanKod(), "3174/LOV_BELGE_KOD", "ACIKLAMA"));
				oMap.put(tableName, row, "BELGE_ALINMA_ADIMI", birBasvuruBelge.getBelgeAlinmaAdim());
				oMap.put(tableName, row, "EKLENDI", true);

				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_SIGORTA_BILGILERI")
	public static GMMap sigortaBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3174.RC_QRY3174_SIGORTA_BILGILERI(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "SIGORTA";
			int row = 0;

			// s.basvuru_no, s.sigorta_urun_no, s.sigorta_talep_no,
			// s.sigorta_primi, t.Kanaldaki_Adi
			while (rSet.next()) {
				oMap.put(tableName, row, "SIGORTA_URUN_NO", rSet.getBigDecimal("SIGORTA_URUN_NO"));
				oMap.put(tableName, row, "KANALDAKI_ADI", rSet.getString("KANALDAKI_ADI"));
				oMap.put(tableName, row, "SIGORTA_PRIMI", rSet.getBigDecimal("SIGORTA_PRIMI"));
				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_TEMINAT_LIST")
	public static GMMap getTeminatList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select teminat_kod,teminat_adedi from bir_basvuru_teminat where basvuru_no = ?");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			rSet = stmt.executeQuery();

			GMMap oMap = new GMMap();
			String tableName = "TEMINAT";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "TEMINAT_ADI", rSet.getString("teminat_kod"));
				oMap.put(tableName, row, "TEMINAT_ADEDI", rSet.getBigDecimal("teminat_adedi"));

				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(1, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_TAHSIS_GORUS_LIST")
	public static GMMap getTahsisGorusList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.RC_TRN3174_TAHSIS_GORUS_LIST(?,?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "TAHSIS_GORUS_LIST", false, rSet);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_MUSTERI_KONTROL_TAKIP")
	public static GMMap getMusteriKontrolTakip(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.get_musteri_kontrol_takip(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			oMap = DALUtil.rSetResults(rSet, "MUSTERI_KONTROL_LIST");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static String getKampanyaUrunAdi(String dovizKodu, BigDecimal krediTuru, BigDecimal krediAltTur, BigDecimal krediAltTur2, String kanalKod, BigDecimal kampKod) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call Pkg_bireysel.KanaldakiAd_KampUrun(?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, krediTuru);
			stmt.setBigDecimal(3, krediAltTur);
			stmt.setBigDecimal(4, krediAltTur2);
			stmt.setString(5, kanalKod);
			stmt.setString(6, dovizKodu);
			stmt.setBigDecimal(7, kampKod);

			stmt.execute();
			String kampanyaAdi = "";
			kampanyaAdi = stmt.getString(1);
			return kampanyaAdi;
		}
		catch (Exception e) {
			throw new GMRuntimeException(1, e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static String getResult(String query) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement(query);
			rSet = stmt.executeQuery();
			String result = "";
			if (rSet.next()) {
				result = rSet.getString(1);
			}
			return result;
		}
		catch (Exception e) {
			throw new GMRuntimeException(1, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "KREDI_TUR", false, "select kod, aciklama from bir_krd_tur where drm = 'G' order by 1");
			DALUtil.fillComboBox(oMap, "DOVIZ_KODU", false, "select kod,aciklama from gnl_doviz_kod_pr");
			DALUtil.fillComboBox(oMap, "MEDENI_HAL", false, "select kod,aciklama from gnl_medeni_hal_kod_pr");
			DALUtil.fillComboBox(oMap, "EGITIM_DURUM_KOD", false, "select kod,aciklama from gnl_egitim_kod_pr");
			DALUtil.fillComboBox(oMap, "MESLEK_KOD", false, "select kod,aciklama from gnl_meslek_kod_pr");
			DALUtil.fillComboBox(oMap, "UNVAN_KOD", false, "select kod,aciklama from gnl_unvan_kod_pr");
			DALUtil.fillComboBox(oMap, "ODEME_TIP_LIST", false, "select kod,aciklama from bir_odm_tip_pr");
			DALUtil.fillComboBox(oMap, "PTT_UNVAN_KOD", false, "select ptt_unvan_kod, ptt_unvan from clks_ptt_banka_unvan_karsilik");

			iMap.put("KOD", "IKAMET_DURUM_KOD");
			oMap.put("IKAMET_DURUM_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			iMap.put("KOD", "ISYERI_MULKIYET_KOD");
			oMap.put("ISYERI_MULKIYET_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			iMap.put("KOD", "CALISMA_SEKLI");
			oMap.put("CALISMA_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			iMap.put("KOD", "ISYERI_FAAL_KONU_KOD");
			oMap.put("ISYERI_FAAL_KONU_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			iMap.put("KOD", "MUST_YAZISMA_ADRES_KOD");
			oMap.put("YAZISMA_ADRES_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			DALUtil.fillComboBox(oMap, "TEMINAT", false, "select kod, aciklama from v_ml_tem_teminat_kodlari_pr order by 1");

			DALUtil.fillComboBox(oMap, "MUS_BAS_DOG_AKSIYON_KOD", false, "select key1,text from v_ml_gnl_param_text where kod='BAS_DOG_AKSIYON_KOD' and key2='M'");
			DALUtil.fillComboBox(oMap, "ISY_BAS_DOG_AKSIYON_KOD", false, "select key1,key3 from v_ml_gnl_param_text where kod='BAS_DOG_AKSIYON_KOD' and key2='I' and key1 IN ('Not Required', 'Work') ");

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3174_GET_BASVURU_KARAR_KOD", iMap));

			DALUtil.fillComboBox(oMap, "IADE_KOD", true, "select t.key1,t.text from gnl_param_text t where t.kod='ONAY_STATU_KOD' and t.sira_no between 2 and (select sira_no from gnl_param_text where kod='ONAY_STATU_KOD' and key1 = '" + iMap.getString("DURUM_KODU") + "') ");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static String determineDurumKod(String ekranNo, String aksiyonKod, String iadeKod) {
		String durumKodu = null;
		if (aksiyonKod.equals("S")) {
			if (ekranNo.equals("3174"))
				durumKodu = "ONAY1";
			else if (ekranNo.equals("3175"))
				durumKodu = "ONAY2";
			else if (ekranNo.equals("3176"))
				durumKodu = "ONAY3";
			else if (ekranNo.equals("3177"))
				durumKodu = "ONAY4";
		}
		if (aksiyonKod.equals("U")) {
			if (ekranNo.equals("3174"))
				durumKodu = "ONAY2";
			else if (ekranNo.equals("3175"))
				durumKodu = "ONAY3";
			else if (ekranNo.equals("3176"))
				durumKodu = "ONAY4";
			else if (ekranNo.equals("3177"))
				durumKodu = "SOZLESME";
		}
		else if (aksiyonKod.equals("I"))
			durumKodu = iadeKod;
		else if (aksiyonKod.equals("R"))
			durumKodu = "RED";
		else if (aksiyonKod.equals("O"))
			durumKodu = "SOZLESME";
		else if (aksiyonKod.equals("C"))
			durumKodu = "IPTAL";

		return durumKodu;
	}

	@GraymoundService("BNSPR_TRN3174_SEND_SMS")
	public static GMMap sendSMS(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3174.TahsisSms(?,?,?)}");
			int pc = 1;
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter(pc++, Types.VARCHAR);
			stmt.registerOutParameter(pc++, Types.VARCHAR);

			stmt.execute();
			String mesaj = stmt.getString(--pc);
			String cepTel = stmt.getString(--pc);

			if (mesaj != null) {
				iMap.put("MSISDN", cepTel);
				iMap.put("CONTENT", mesaj);
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap).get("RESULT");
				// if(!mesg.substring(0, 1).equals("-"))
				// System.out.println(cepTel+" numarali telefona -"+
				// iMap.getString("CONTENT")+
				// "- mesaji gonderilmistir.");
			}

			/** Web kanalinda Onay Ciktiysa direk KUL a alinacak **/
			Session session = DAOSession.getSession("BNSPRDal");
			BirTahsisDegerTx birTahsisDegerTx = (BirTahsisDegerTx) session.createCriteria(BirTahsisDegerTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			iMap.put("BASVURU_NO", birTahsisDegerTx.getBasvuruNo());
			if ("SOZLESME".equals(birTahsisDegerTx.getIslemSonrasiDurumKodu())) {
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				if ("8".equals(birBasvuru.getKanalKodu()) || "5".equals(birBasvuru.getKanalKodu())) {
					GMServiceExecuter.execute("BNSPR_CL_WEB_AUTOMATIC_AGREEMENT_PROCESS", iMap);
				}else if("7".equals(birBasvuru.getKanalKodu()) && "PTT_SMS".equals(birBasvuru.getWebSatisKanali())){
					GMMap sMap = new GMMap();
					sMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
					sMap.putAll(GMServiceExecuter.call("CLKS_GET_PAY_PLN_3181_REQUEST_INFO", iMap));
					sMap.put("TAKSIT_GUNU", birBasvuru.getTaksitGunu());
					sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_CREATE_AGREEMENT", sMap));
					sMap.put("AGREEMENT_TRX_NO", sMap.get("TRX_NO"));
					GMServiceExecuter.execute("BNSPR_TRN3172_SAVE_AGREEMENT", sMap);
				}
			}
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirTahsisDegerTx birTahsisDegerTx = (BirTahsisDegerTx) session.get(BirTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));

			if (birTahsisDegerTx == null)
				birTahsisDegerTx = new BirTahsisDegerTx();

			if (iMap.getBigDecimal("ONAY_TUTAR").compareTo(iMap.getBigDecimal("TALEP_TUTAR")) == 1) {
				iMap.put("HATA_NO", new BigDecimal(1054));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			birTahsisDegerTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birTahsisDegerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birTahsisDegerTx.setAciklama(iMap.getString("GORUS"));
			birTahsisDegerTx.setTahsisGorus(iMap.getString("IT_GORUS"));
			birTahsisDegerTx.setDurumKod(iMap.getString("DURUM"));
			birTahsisDegerTx.setOnayTutar(iMap.getBigDecimal("ONAY_TUTAR"));
			birTahsisDegerTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
			birTahsisDegerTx.setIadeKod(iMap.getString("IADE_KOD"));
			birTahsisDegerTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
			birTahsisDegerTx.setAksiyonAltKararKod(iMap.getString("AKSIYON_ALT_KARAR_KOD"));
			birTahsisDegerTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			birTahsisDegerTx.setLtvUygunMu(iMap.getString("LTV_UYGUN_MU"));
			birTahsisDegerTx.setHasarAdedi(iMap.getBigDecimal("HASAR_ADEDI"));
			birTahsisDegerTx.setHasarTutari(iMap.getBigDecimal("HASAR_TUTARI"));
			birTahsisDegerTx.setAracKmBilgisi(iMap.getBigDecimal("ARAC_KM_BILGISI"));
    	    birTahsisDegerTx.setKmMuayeneTarihi(iMap.getDate("KM_MUAYENE_TARIHI"));
			/** TY-6763 TY-Tahsis ekranlar� (3178-3174-3175-3176-3177-3190) - Onay takibi */

			if (iMap.getString("AKSIYON_KOD") != null && !(iMap.getString("AKSIYON_KOD").equals("I") && iMap.getString("IADE_KOD") == null)) {
				birTahsisDegerTx.setIslemSonrasiDurumKodu(determineDurumKod(iMap.getString("EKRAN_NO"), iMap.getString("AKSIYON_KOD"), iMap.getString("IADE_KOD")));
				if ("5".equals(iMap.getString("KREDI_TUR"))) {
					if (("SOZLESME".equals(birTahsisDegerTx.getIslemSonrasiDurumKodu()) || "BELGE".equals(birTahsisDegerTx.getIslemSonrasiDurumKodu()))) {
						iMap.put("DURUM", birTahsisDegerTx.getIslemSonrasiDurumKodu());
						birTahsisDegerTx.setIslemSonrasiDurumKodu(GMServiceExecuter.call("BNSPR_KMH_ADIM_BELIRLE", iMap).getString("DURUM"));
					}
					else if ("RED".equals(birTahsisDegerTx.getIslemSonrasiDurumKodu())) {
						GMServiceExecuter.execute("BNSPR_KMH_EVENT_YARAT", iMap);
					}
				}
			}
			birTahsisDegerTx.setMusteriNoDegistir(iMap.getString("MUSTERI_NO_GUNCELLE"));
			if ("E".equals(iMap.getString("MUSTERI_NO_GUNCELLE"))) {
				birTahsisDegerTx.setEskiMusteriNo(iMap.getBigDecimal("ESKI_MUSTERI_NO"));
				birTahsisDegerTx.setYeniMusteriNo(iMap.getBigDecimal("YENI_MUSTERI_NO"));
			}
			else {
				birTahsisDegerTx.setEskiMusteriNo(null);
				birTahsisDegerTx.setYeniMusteriNo(null);
			}

			if (iMap.getString("AKSIYON_KOD") != null && iMap.getString("AKSIYON_KOD").equals("I") && iMap.getString("IADE_KOD") != null && iMap.getString("IADE_KOD").equals("DOGRULAMA")) {

				BirTahsisDogrulamaTx birTahsisDogrulamaTxM = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "M")).uniqueResult();

				if (birTahsisDogrulamaTxM == null) {
					birTahsisDogrulamaTxM = new BirTahsisDogrulamaTx();
					BirTahsisDogrulamaTxId birTahsisDogrulamaTxId = new BirTahsisDogrulamaTxId();
					birTahsisDogrulamaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birTahsisDogrulamaTxId.setKimIcin("M");

					birTahsisDogrulamaTxM.setId(birTahsisDogrulamaTxId);
				}

				birTahsisDogrulamaTxM.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				String nbsmDogSonucStr = "";
				nbsmDogSonucStr = nbsmDogSonucStr + "MAppVer:" + (iMap.getString("MUSTERI_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_DOG_IADE")) + "-";
				nbsmDogSonucStr = nbsmDogSonucStr + "MEmptVer:" + (iMap.getString("MUSTERI_ISYERI_DOG_IADE") == null ? "Not Required" : iMap.getString("MUSTERI_ISYERI_DOG_IADE")) + "-";
				// PY-2273
				nbsmDogSonucStr = nbsmDogSonucStr + "MFraudVer:" + (iMap.getString("MUSTERI_FRAUD_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_FRAUD_DOG_IADE")) + "-";
				nbsmDogSonucStr = nbsmDogSonucStr + "MWebVer:" + (iMap.getString("MUSTERI_WEB_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_WEB_DOG_IADE"));

				birTahsisDogrulamaTxM.setNbsmDogSonucStr(nbsmDogSonucStr);
				birTahsisDegerTx.setNbsmDogSonucStrM(nbsmDogSonucStr);

				session.saveOrUpdate(birTahsisDogrulamaTxM);

				BirTahsisDogrulamaTx birTahsisDogrulamaTxK1 = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "K1")).uniqueResult();

				if (birTahsisDogrulamaTxK1 == null) {
					birTahsisDogrulamaTxK1 = new BirTahsisDogrulamaTx();
					BirTahsisDogrulamaTxId birTahsisDogrulamaTxId = new BirTahsisDogrulamaTxId();
					birTahsisDogrulamaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birTahsisDogrulamaTxId.setKimIcin("K1");
					birTahsisDogrulamaTxK1.setId(birTahsisDogrulamaTxId);
				}

				// PY-2273
				String nbsmK1DogSonucStr = "";
				nbsmK1DogSonucStr = nbsmK1DogSonucStr + "K1EmptVer:" + (iMap.getString("1KEFIL_IADE") == null ? "Not Required" : iMap.getString("1KEFIL_IADE")) + "-";
				nbsmK1DogSonucStr = nbsmK1DogSonucStr + "K1FraudVer:" + (iMap.getString("1KEFIL_FRAUD_IADE") == null ? "N" : iMap.getString("1KEFIL_FRAUD_IADE"));

				birTahsisDogrulamaTxK1.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				birTahsisDogrulamaTxK1.setNbsmDogSonucStr(nbsmK1DogSonucStr);
				birTahsisDegerTx.setNbsmDogSonucStrK1(birTahsisDogrulamaTxK1.getNbsmDogSonucStr());

				session.saveOrUpdate(birTahsisDogrulamaTxK1);

				BirTahsisDogrulamaTx birTahsisDogrulamaTxK2 = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "K2")).uniqueResult();

				if (birTahsisDogrulamaTxK2 == null) {
					birTahsisDogrulamaTxK2 = new BirTahsisDogrulamaTx();
					BirTahsisDogrulamaTxId birTahsisDogrulamaTxId = new BirTahsisDogrulamaTxId();
					birTahsisDogrulamaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birTahsisDogrulamaTxId.setKimIcin("K2");
					birTahsisDogrulamaTxK2.setId(birTahsisDogrulamaTxId);
				}

				// PY-2273
				String nbsmK2DogSonucStr = "";
				nbsmK2DogSonucStr = nbsmK2DogSonucStr + "K2EmptVer:" + (iMap.getString("2KEFIL_IADE") == null ? "Not Required" : iMap.getString("2KEFIL_IADE")) + "-";
				nbsmK2DogSonucStr = nbsmK2DogSonucStr + "K2FraudVer:" + (iMap.getString("2KEFIL_FRAUD_IADE") == null ? "N" : iMap.getString("2KEFIL_FRAUD_IADE"));

				birTahsisDogrulamaTxK2.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				birTahsisDogrulamaTxK2.setNbsmDogSonucStr(nbsmK2DogSonucStr);
				birTahsisDegerTx.setNbsmDogSonucStrK2(birTahsisDogrulamaTxK2.getNbsmDogSonucStr());

				session.saveOrUpdate(birTahsisDogrulamaTxK2);
			}

			session.saveOrUpdate(birTahsisDegerTx);
			session.flush();
			
			if (iMap.getString("AKSIYON_KOD") != null && !(iMap.getString("AKSIYON_KOD").equals("I") && "KANALIADE".equals(iMap.getString("IADE_KOD")))) {
				
				List<?> lastTeminatList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				for (Object name : lastTeminatList) {
					BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) name;
					session.delete(birBasvuruTeminatTx);
				}
				session.flush();
	
				List<?> teminatList = (List<?>) iMap.get("TEMINAT");
				String tableName = "TEMINAT";
	
				for (int i = 0; i < teminatList.size(); i++) {
					BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.teminatKod", iMap.getString(tableName, i, "TEMINAT_ADI"))).uniqueResult();
					if (birBasvuruTeminatTx == null) {
						birBasvuruTeminatTx = new BirBasvuruTeminatTx();
						BirBasvuruTeminatTxId birBasvuruTeminatTxId = new BirBasvuruTeminatTxId();
	
						birBasvuruTeminatTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birBasvuruTeminatTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birBasvuruTeminatTxId.setTeminatKod(iMap.getString(tableName, i, "TEMINAT_ADI"));
						birBasvuruTeminatTx.setId(birBasvuruTeminatTxId);
					}
					birBasvuruTeminatTx.setTeminatAdedi(iMap.getBigDecimal(tableName, i, "TEMINAT_ADEDI"));
	
					session.save(birBasvuruTeminatTx);
				}
				session.flush();
	
				List<?> lastBelgeList = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				for (Object name : lastBelgeList) {
					BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) name;
					session.delete(birBasvuruBelgeTx);
				}
				session.flush();
	
				List<?> belgeList = (List<?>) iMap.get("BELGE");
				tableName = "BELGE";
				for (int i = 0; i < belgeList.size(); i++) {
					BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.kimden", iMap.getString(tableName, i, "KIMDEN_KOD"))).add(Restrictions.eq("id.dokumanKod", iMap.getString(tableName, i, "BELGE_KOD"))).uniqueResult();
					if (birBasvuruBelgeTx == null) {
						birBasvuruBelgeTx = new BirBasvuruBelgeTx();
						BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();
	
						birBasvuruBelgeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birBasvuruBelgeTxId.setDokumanKod(iMap.getString(tableName, i, "BELGE_KOD"));
						birBasvuruBelgeTxId.setKimden(iMap.getString(tableName, i, "KIMDEN_KOD"));
						birBasvuruBelgeTx.setAlindi(iMap.getString(tableName, i, "ALINDI"));
						birBasvuruBelgeTx.setBelgeKontrol(iMap.getString(tableName, i, "BELGE_KONTROL"));
						birBasvuruBelgeTx.setOrjinalEvrakMi(iMap.getString(tableName, i, "ORJINAL_EVRAK_MI"));
						if (iMap.getString(tableName, i, "BELGE_GELIS_TARIHI") != null)
							birBasvuruBelgeTx.setBelgeGelisTarihi(new SimpleDateFormat(calendarFormat).parse(iMap.getString(tableName, i, "BELGE_GELIS_TARIHI")));
						if (iMap.getString(tableName, i, "ISLEM_TARIHI") != null)
							birBasvuruBelgeTx.setIslemTarihi(new SimpleDateFormat(calendarFormat).parse(iMap.getString(tableName, i, "ISLEM_TARIHI")));
						birBasvuruBelgeTx.setBelgeHata(iMap.getString(tableName, i, "BELGE_HATA"));
						birBasvuruBelgeTx.setBarkodNumarasi(iMap.getString(tableName, i, "BARKOD_NUMARASI"));
						birBasvuruBelgeTx.setOnayliMi(iMap.getString(tableName, i, "ONAYLI_MI"));
						birBasvuruBelgeTx.setUyumsuzAciklama(iMap.getString(tableName, i, "UYUMSUZ_ACIKLAMA"));
						birBasvuruBelgeTx.setBelgeYeri(iMap.getString(tableName, i, "BELGE_YERI"));
						birBasvuruBelgeTx.setKontrolNedeni(iMap.getString(tableName, i, "KONTROL_NEDENI"));
						birBasvuruBelgeTx.setIslemYapanKullanici(iMap.getString(tableName, i, "ISLEM_YAPAN_KULLANICI"));
						birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
						String belgeAlinmaAdim = iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI") != null && !iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI").trim().isEmpty() ? iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI") : "S";
						birBasvuruBelgeTx.setBelgeAlinmaAdim(belgeAlinmaAdim);
					}
					session.save(birBasvuruBelgeTx);
				}
				session.flush();
	
				List<?> musteriKontrolList = (List<?>) iMap.get("MUSTERI_KONTROL_LIST");
				tableName = "MUSTERI_KONTROL_LIST";
				for (int i = 0; i < musteriKontrolList.size(); i++) {
					BirTahsisDegerGorusTx birTahsisDegerGorusTx = (BirTahsisDegerGorusTx) session.createCriteria(BirTahsisDegerGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.gorusKod", iMap.getString(tableName, i, "GORUS_KOD"))).uniqueResult();
					if (birTahsisDegerGorusTx == null) {
						birTahsisDegerGorusTx = new BirTahsisDegerGorusTx();
						BirTahsisDegerGorusTxId id = new BirTahsisDegerGorusTxId();
						id.setTxNo(iMap.getBigDecimal("TRX_NO"));
						id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						id.setGorusKod(iMap.getString(tableName, i, "GORUS_KOD"));
						birTahsisDegerGorusTx.setId(id);
						if (iMap.getBoolean(tableName, i, "SEC")) {
							birTahsisDegerGorusTx.setEH("E");
						}
						else {
							birTahsisDegerGorusTx.setEH("H");
						}
					}
					session.saveOrUpdate(birTahsisDegerGorusTx);
				}
				session.flush();
				
			}
			iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (NonUniqueObjectException e) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_TEMP")
	public static Map<?, ?> saveTemp(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirTahsisDegerTx birTahsisDegerTx = (BirTahsisDegerTx) session.get(BirTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));

			if (birTahsisDegerTx == null)
				birTahsisDegerTx = new BirTahsisDegerTx();

			if (iMap.getBigDecimal("ONAY_TUTAR").compareTo(iMap.getBigDecimal("TALEP_TUTAR")) == 1) {
				iMap.put("HATA_NO", new BigDecimal(1054));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			birTahsisDegerTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birTahsisDegerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birTahsisDegerTx.setAciklama(iMap.getString("GORUS"));
			birTahsisDegerTx.setTahsisGorus(iMap.getString("IT_GORUS"));
			birTahsisDegerTx.setDurumKod(iMap.getString("DURUM"));
			birTahsisDegerTx.setOnayTutar(iMap.getBigDecimal("ONAY_TUTAR"));
			birTahsisDegerTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
			birTahsisDegerTx.setIadeKod(iMap.getString("IADE_KOD"));
			birTahsisDegerTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
			birTahsisDegerTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			if (iMap.getString("AKSIYON_KOD") != null && !(iMap.getString("AKSIYON_KOD").equals("I") && iMap.getString("IADE_KOD") == null)) {
				birTahsisDegerTx.setIslemSonrasiDurumKodu(determineDurumKod(iMap.getString("EKRAN_NO"), iMap.getString("AKSIYON_KOD"), iMap.getString("IADE_KOD")));
				if ("5".equals(iMap.getString("KREDI_TUR")) && ("SOZLESME".equals(birTahsisDegerTx.getIslemSonrasiDurumKodu()) || "BELGE".equals(birTahsisDegerTx.getIslemSonrasiDurumKodu()))) {
					iMap.put("DURUM", birTahsisDegerTx.getIslemSonrasiDurumKodu());
					birTahsisDegerTx.setIslemSonrasiDurumKodu(GMServiceExecuter.call("BNSPR_KMH_ADIM_BELIRLE", iMap).getString("DURUM"));
				}
			}

			if (iMap.getString("AKSIYON_KOD") != null && iMap.getString("AKSIYON_KOD").equals("I") && iMap.getString("IADE_KOD") != null && iMap.getString("IADE_KOD").equals("DOGRULAMA")) {

				BirTahsisDogrulamaTx birTahsisDogrulamaTxM = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "M")).uniqueResult();

				if (birTahsisDogrulamaTxM == null) {
					birTahsisDogrulamaTxM = new BirTahsisDogrulamaTx();
					BirTahsisDogrulamaTxId birTahsisDogrulamaTxId = new BirTahsisDogrulamaTxId();
					birTahsisDogrulamaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birTahsisDogrulamaTxId.setKimIcin("M");

					birTahsisDogrulamaTxM.setId(birTahsisDogrulamaTxId);
				}

				birTahsisDogrulamaTxM.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				String nbsmDogSonucStr = "";
				nbsmDogSonucStr = nbsmDogSonucStr + "MAppVer:" + (iMap.getString("MUSTERI_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_DOG_IADE")) + "-";
				nbsmDogSonucStr = nbsmDogSonucStr + "MEmptVer:" + (iMap.getString("MUSTERI_ISYERI_DOG_IADE") == null ? "Not Required" : iMap.getString("MUSTERI_ISYERI_DOG_IADE")) + "-";
				// PY-2273
				nbsmDogSonucStr = nbsmDogSonucStr + "MFraudVer:" + (iMap.getString("MUSTERI_FRAUD_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_FRAUD_DOG_IADE")) + "-";
				nbsmDogSonucStr = nbsmDogSonucStr + "MWebVer:" + (iMap.getString("MUSTERI_WEB_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_WEB_DOG_IADE"));

				birTahsisDogrulamaTxM.setNbsmDogSonucStr(nbsmDogSonucStr);
				birTahsisDegerTx.setNbsmDogSonucStrM(nbsmDogSonucStr);

				session.saveOrUpdate(birTahsisDogrulamaTxM);

				BirTahsisDogrulamaTx birTahsisDogrulamaTxK1 = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "K1")).uniqueResult();

				if (birTahsisDogrulamaTxK1 == null) {
					birTahsisDogrulamaTxK1 = new BirTahsisDogrulamaTx();
					BirTahsisDogrulamaTxId birTahsisDogrulamaTxId = new BirTahsisDogrulamaTxId();
					birTahsisDogrulamaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birTahsisDogrulamaTxId.setKimIcin("K1");
					birTahsisDogrulamaTxK1.setId(birTahsisDogrulamaTxId);
				}

				// PY-2273
				String nbsmK1DogSonucStr = "";
				nbsmK1DogSonucStr = nbsmK1DogSonucStr + "K1EmptVer:" + (iMap.getString("1KEFIL_IADE") == null ? "Not Required" : iMap.getString("1KEFIL_IADE")) + "-";
				nbsmK1DogSonucStr = nbsmK1DogSonucStr + "K1FraudVer:" + (iMap.getString("1KEFIL_FRAUD_IADE") == null ? "N" : iMap.getString("1KEFIL_FRAUD_IADE"));

				birTahsisDogrulamaTxK1.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				birTahsisDogrulamaTxK1.setNbsmDogSonucStr(nbsmK1DogSonucStr);
				birTahsisDegerTx.setNbsmDogSonucStrK1(birTahsisDogrulamaTxK1.getNbsmDogSonucStr());

				session.saveOrUpdate(birTahsisDogrulamaTxK1);

				BirTahsisDogrulamaTx birTahsisDogrulamaTxK2 = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "K2")).uniqueResult();

				if (birTahsisDogrulamaTxK2 == null) {
					birTahsisDogrulamaTxK2 = new BirTahsisDogrulamaTx();
					BirTahsisDogrulamaTxId birTahsisDogrulamaTxId = new BirTahsisDogrulamaTxId();
					birTahsisDogrulamaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birTahsisDogrulamaTxId.setKimIcin("K2");
					birTahsisDogrulamaTxK2.setId(birTahsisDogrulamaTxId);
				}

				// PY-2273
				String nbsmK2DogSonucStr = "";
				nbsmK2DogSonucStr = nbsmK2DogSonucStr + "K2EmptVer:" + (iMap.getString("2KEFIL_IADE") == null ? "Not Required" : iMap.getString("2KEFIL_IADE")) + "-";
				nbsmK2DogSonucStr = nbsmK2DogSonucStr + "K2FraudVer:" + (iMap.getString("2KEFIL_FRAUD_IADE") == null ? "N" : iMap.getString("2KEFIL_FRAUD_IADE"));

				birTahsisDogrulamaTxK2.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				birTahsisDogrulamaTxK2.setNbsmDogSonucStr(nbsmK2DogSonucStr);
				birTahsisDegerTx.setNbsmDogSonucStrK2(birTahsisDogrulamaTxK2.getNbsmDogSonucStr());

				session.saveOrUpdate(birTahsisDogrulamaTxK2);
			}

			session.saveOrUpdate(birTahsisDegerTx);
			session.flush();

			List<?> lastTeminatList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			for (Object name : lastTeminatList) {
				BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) name;
				session.delete(birBasvuruTeminatTx);
			}
			session.flush();

			List<?> teminatList = (List<?>) iMap.get("TEMINAT");
			String tableName = "TEMINAT";

			for (int i = 0; i < teminatList.size(); i++) {
				BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.teminatKod", iMap.getString(tableName, i, "TEMINAT_ADI"))).uniqueResult();
				if (birBasvuruTeminatTx == null) {
					birBasvuruTeminatTx = new BirBasvuruTeminatTx();
					BirBasvuruTeminatTxId birBasvuruTeminatTxId = new BirBasvuruTeminatTxId();

					birBasvuruTeminatTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruTeminatTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birBasvuruTeminatTxId.setTeminatKod(iMap.getString(tableName, i, "TEMINAT_ADI"));
					birBasvuruTeminatTx.setId(birBasvuruTeminatTxId);
				}
				birBasvuruTeminatTx.setTeminatAdedi(iMap.getBigDecimal(tableName, i, "TEMINAT_ADEDI"));

				session.save(birBasvuruTeminatTx);
			}
			session.flush();

			List<?> lastBelgeList = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			for (Object name : lastBelgeList) {
				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) name;
				session.delete(birBasvuruBelgeTx);
			}
			session.flush();

			List<?> belgeList = (List<?>) iMap.get("BELGE");
			tableName = "BELGE";
			for (int i = 0; i < belgeList.size(); i++) {
				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.kimden", iMap.getString(tableName, i, "KIMDEN_KOD"))).add(Restrictions.eq("id.dokumanKod", iMap.getString(tableName, i, "BELGE_KOD"))).uniqueResult();
				if (birBasvuruBelgeTx == null) {
					birBasvuruBelgeTx = new BirBasvuruBelgeTx();
					BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();

					birBasvuruBelgeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birBasvuruBelgeTxId.setDokumanKod(iMap.getString(tableName, i, "BELGE_KOD"));
					birBasvuruBelgeTxId.setKimden(iMap.getString(tableName, i, "KIMDEN_KOD"));
					birBasvuruBelgeTx.setAlindi(iMap.getString(tableName, i, "ALINDI"));
					birBasvuruBelgeTx.setBelgeKontrol(iMap.getString(tableName, i, "BELGE_KONTROL"));
					birBasvuruBelgeTx.setOrjinalEvrakMi(iMap.getString(tableName, i, "ORJINAL_EVRAK_MI"));
					if (iMap.getString(tableName, i, "BELGE_GELIS_TARIHI") != null)
						birBasvuruBelgeTx.setBelgeGelisTarihi(new SimpleDateFormat(calendarFormat).parse(iMap.getString(tableName, i, "BELGE_GELIS_TARIHI")));
					if (iMap.getString(tableName, i, "ISLEM_TARIHI") != null)
						birBasvuruBelgeTx.setIslemTarihi(new SimpleDateFormat(calendarFormat).parse(iMap.getString(tableName, i, "ISLEM_TARIHI")));
					birBasvuruBelgeTx.setBelgeHata(iMap.getString(tableName, i, "BELGE_HATA"));
					birBasvuruBelgeTx.setBarkodNumarasi(iMap.getString(tableName, i, "BARKOD_NUMARASI"));
					birBasvuruBelgeTx.setOnayliMi(iMap.getString(tableName, i, "ONAYLI_MI"));
					birBasvuruBelgeTx.setUyumsuzAciklama(iMap.getString(tableName, i, "UYUMSUZ_ACIKLAMA"));
					birBasvuruBelgeTx.setBelgeYeri(iMap.getString(tableName, i, "BELGE_YERI"));
					birBasvuruBelgeTx.setKontrolNedeni(iMap.getString(tableName, i, "KONTROL_NEDENI"));
					birBasvuruBelgeTx.setIslemYapanKullanici(iMap.getString(tableName, i, "ISLEM_YAPAN_KULLANICI"));
					birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
					String belgeAlinmaAdim = iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI") != null && !iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI").trim().isEmpty() ? iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI") : "S";
					birBasvuruBelgeTx.setBelgeAlinmaAdim(belgeAlinmaAdim);
				}
				session.save(birBasvuruBelgeTx);
			}
			session.flush();

			List<?> musteriKontrolList = (List<?>) iMap.get("MUSTERI_KONTROL_LIST");
			tableName = "MUSTERI_KONTROL_LIST";
			for (int i = 0; i < musteriKontrolList.size(); i++) {
				BirTahsisDegerGorusTx birTahsisDegerGorusTx = new BirTahsisDegerGorusTx();
				BirTahsisDegerGorusTxId id = new BirTahsisDegerGorusTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				id.setGorusKod(iMap.getString(tableName, i, "GORUS_KOD"));
				birTahsisDegerGorusTx.setId(id);
				if (iMap.getBoolean(tableName, i, "SEC")) {
					birTahsisDegerGorusTx.setEH("E");
				}
				else {
					birTahsisDegerGorusTx.setEH("H");
				}
				session.saveOrUpdate(birTahsisDegerGorusTx);
			}
			session.flush();
			iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION_TEMP", iMap);
		}
		catch (NonUniqueObjectException e) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirTahsisDegerTx birTahsisDegerTx = (BirTahsisDegerTx) session.get(BirTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));

			iMap.put("BASVURU_NO", birTahsisDegerTx.getBasvuruNo());
			iMap.put("EKRAN_NO", "0");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3174_GET_DETAY", iMap));
			oMap.put("BASVURU_NO", birTahsisDegerTx.getBasvuruNo());
			oMap.put("GORUS", birTahsisDegerTx.getAciklama());
			oMap.put("IT_GORUS", birTahsisDegerTx.getTahsisGorus());
			oMap.put("ONAY_TUTAR", birTahsisDegerTx.getOnayTutar());
			oMap.put("AKSIYON_KOD", birTahsisDegerTx.getAksiyonKod());
			oMap.put("AKSIYON_KARAR_KOD", birTahsisDegerTx.getAksiyonKararKod());
			oMap.put("AKSIYON_ALT_KARAR_KOD", birTahsisDegerTx.getAksiyonAltKararKod());
			oMap.put("IADE_KOD", birTahsisDegerTx.getIadeKod());

			if (birTahsisDegerTx.getAksiyonKod() != null && birTahsisDegerTx.getAksiyonKod().equals("I") && birTahsisDegerTx.getIadeKod() != null && birTahsisDegerTx.getIadeKod().equals("DOGRULAMA")) {

				oMap.put("MUSTERI_DOG_IADE", "N");
				oMap.put("MUSTERI_ISYERI_DOG_IADE", "Not Required");
				oMap.put("1KEFIL_IADE", "Not Required");
				oMap.put("2KEFIL_IADE", "Not Required");
				// PY-2273
				oMap.put("MUSTERI_FRAUD_DOG_IADE", "N");
				oMap.put("MUSTERI_WEB_DOG_IADE", "N");
				oMap.put("1KEFIL_FRAUD_IADE", "N");
				oMap.put("2KEFIL_FRAUD_IADE", "N");

				BirTahsisDogrulamaTx birTahsisDogrulamaTx = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "M")).uniqueResult();

				String nbsmDogSonucStr = birTahsisDogrulamaTx.getNbsmDogSonucStr();
				if (nbsmDogSonucStr != null && !nbsmDogSonucStr.equals("")) {
					int size = nbsmDogSonucStr.split("-").length;
					for (int i = 0; i < size; i++) {
						if (nbsmDogSonucStr.split("-")[i].contains("MAppVer")) {
							oMap.put("MUSTERI_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("MEmptVer")) {
							oMap.put("MUSTERI_ISYERI_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						// PY-2273
						else if (nbsmDogSonucStr.split("-")[i].contains("MFraudVer")) {
							oMap.put("MUSTERI_FRAUD_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("MWebVer")) {
							oMap.put("MUSTERI_WEB_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
					}
				}

				birTahsisDogrulamaTx = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "K1")).uniqueResult();

				nbsmDogSonucStr = birTahsisDogrulamaTx.getNbsmDogSonucStr();
				if (nbsmDogSonucStr != null && !nbsmDogSonucStr.equals("")) {
					int size = nbsmDogSonucStr.split("-").length;
					for (int i = 0; i < size; i++) {
						if (nbsmDogSonucStr.split("-")[i].contains("K1EmptVer")) {
							oMap.put("1KEFIL_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("K1FraudVer")) {
							oMap.put("1KEFIL_FRAUD_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
					}
				}

				birTahsisDogrulamaTx = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "K2")).uniqueResult();

				nbsmDogSonucStr = birTahsisDogrulamaTx.getNbsmDogSonucStr();
				if (nbsmDogSonucStr != null && !nbsmDogSonucStr.equals("")) {
					int size = nbsmDogSonucStr.split("-").length;
					for (int i = 0; i < size; i++) {
						if (nbsmDogSonucStr.split("-")[i].contains("K2EmptVer")) {
							oMap.put("2KEFIL_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
						else if (nbsmDogSonucStr.split("-")[i].contains("K2FraudVer")) {
							oMap.put("2KEFIL_FRAUD_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
						}
					}
				}
			}

			String tableName = "TEMINAT";
			int row = 0;
			List<?> teminatList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : teminatList) {
				BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) name;

				oMap.put(tableName, row, "TEMINAT_ADI", birBasvuruTeminatTx.getId().getTeminatKod());
				oMap.put(tableName, row, "TEMINAT_ADEDI", birBasvuruTeminatTx.getTeminatAdedi());

				row++;
			}

			tableName = "BELGE";
			row = 0;
			List<?> belgeList = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : belgeList) {
				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) name;
				oMap.put(tableName, row, "KIMDEN", LovHelper.diLov(birBasvuruBelgeTx.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
				oMap.put(tableName, row, "KIMDEN_KOD", birBasvuruBelgeTx.getId().getKimden());
				oMap.put(tableName, row, "BELGE_KOD", birBasvuruBelgeTx.getId().getDokumanKod());
				oMap.put(tableName, row, "BELGE_ADI", LovHelper.diLov(birBasvuruBelgeTx.getId().getDokumanKod(), "3174/LOV_BELGE_KOD", "ACIKLAMA"));
				oMap.put(tableName, row, "BELGE_ALINMA_ADIMI", birBasvuruBelgeTx.getBelgeAlinmaAdim());

				row++;
			}

			// Distributor Tablosu
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3174.RC_QRY3174_GET_DISTRIBUTOR(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, oMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();

			rSet2 = (ResultSet) stmt.getObject(1);

			String tableNameDist = "DISTRIBUTOR";
			int rowDist = 0;

			while (rSet2.next()) {
				oMap.put(tableNameDist, rowDist, "KOD", rSet2.getBigDecimal(1));
				oMap.put(tableNameDist, rowDist, "SATICI_ADI", rSet2.getString(2));
				row++;
			}

			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

			// musteri kontrol takip
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3174.get_musteri_kontrol_takip_info(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			rSet3 = (ResultSet) stmt.getObject(1);
			String tableNameKont = "MUSTERI_KONTROL_LIST";
			int rowKont = 0;
			while (rSet3.next()) {
				oMap.put(tableNameKont, rowKont, "SEC", rSet3.getString("SEC"));
				oMap.put(tableNameKont, rowKont, "GORUS_KOD", rSet3.getString("GORUS_KOD"));
				oMap.put(tableNameKont, rowKont, "GORUS", rSet3.getString("GORUS"));

				rowKont++;
			}
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_BASVURU_IADE_KOD")
	public static GMMap getBasvuruIadeKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "IADE_KOD", true, "select t.key1,t.key1 from gnl_param_text t where t.kod='ONAY_STATU_KOD' and t.sira_no > 1 and t.sira_no <= (select sira_no from gnl_param_text where kod='ONAY_STATU_KOD' and key1 = '" + iMap.getString("DURUM_KODU") + "') and t.key1 <> '" + iMap.getString("DURUM_KODU") + "' ");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_BASVURU_IADE_KOD_ALL")
	public static GMMap getBasvuruIadeKodAll(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "IADE_KOD", true, "select t.key1,t.key1 from gnl_param_text t where t.kod='ONAY_STATU_KOD'");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_BASVURU_AKSIYON_KARAR_KOD")
	public static GMMap getBasvuruAksiyonKararKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			StringBuffer query = new StringBuffer();
			query.append("select key2,text from gnl_param_text where kod = 'BASVURU_AKSIYON_KARAR_KOD' and ((key2 not in ('3','4','5') and key1 = 'C') or key1 <> 'C') and ((key1='R' and NVL(key3,'A')='A') or key1<>'R') and key1='" + iMap.getString("KARAR") + "' "); // OTOMATIK
			// IPTAL
			// c�kart�ld�
			if (iMap.getString("IADE_KOD") != null)
				query.append(" and key3='" + iMap.getString("IADE_KOD") + "' ");
			query.append(" order by 1");
			DALUtil.fillComboBox(oMap, "AKSIYON_KARAR_KOD", true, query.toString());
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_BASVURU_KARAR_KOD")
	public static GMMap getBasvuruKararKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			if ("3177".equals(iMap.getString("EKRAN_NO")))
				DALUtil.fillComboBox(oMap, "KARAR", true, "select t.key1,t.text from gnl_param_text t where t.kod='BASVURU_AKSIYON_KOD' and t.key1 not in ('U') order by sira_no");
			else if ("3190".equals(iMap.getString("EKRAN_NO"))) {
				if ("Accept".equals(iMap.getString("NBSM_KARAR_KOD")))
					DALUtil.fillComboBox(oMap, "KARAR", true, "select t.key1,t.text from gnl_param_text t where t.kod='BASVURU_IST_AKSIYON_KOD' order by sira_no");
				else
					DALUtil.fillComboBox(oMap, "KARAR", true, "select t.key1,t.text from gnl_param_text t where t.kod='BASVURU_IST_AKSIYON_KOD' and t.key1 not in ('D') order by sira_no");
			}
			else
				DALUtil.fillComboBox(oMap, "KARAR", true, "select t.key1,t.text from gnl_param_text t where t.kod='BASVURU_AKSIYON_KOD' order by sira_no");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_TARIHCE")
	public static GMMap getTarihce(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			StringBuilder query = new StringBuilder();
			query.append("select * ");
			query.append("from V_BIR_BASVURU_TARIHCE t ");
			query.append("where t.basvuru_no= ? ");

			stmt = conn.prepareStatement(query.toString());
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			rSet = stmt.executeQuery();
			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_BIR_ONCEKI_BASVURULAR")
	public static GMMap getOncekiBasvurular(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.RC_QRY3174_ONCEKI_BASVURULAR(?,?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap getIkinciMusteriNo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			StringBuilder query = new StringBuilder();
			query.append("select m.musteri_no from gnl_musteri m ");
			query.append("where m.tc_kimlik_no= ? and m.musteri_no <> ? ");

			stmt = conn.prepareStatement(query.toString());
			int i = 1;
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));

			rSet = stmt.executeQuery();
			GMMap oMap = new GMMap();
			if (rSet.next()) {
				oMap.put("DIGER_MUSTERI_NO", rSet.getBigDecimal(1));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_SATICI_TAHSIS_DATA")
	public static GMMap getSaticiTahsisData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3174.RC_QRY3174_GET_SATICI_TAHSIS(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_SAKLA_TX_NO")
	public static GMMap getoncekiSaklaTxNo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			oMap.put("TRX_NO", DALUtil.getResult("select max(tx_no) tx_no from bir_tahsis_deger_tx where basvuru_no = " + iMap.getBigDecimal("BASVURU_NO") + ""));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_GET_ONCEKI_BASVURU_DETAY")
	public static GMMap getOncekiBasvuruDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.RC_QRY3174_GET_DETAY_LIST(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);

			stmt = conn.prepareCall("{? = call PKG_RC3122.RC_QRY3122_MUSTERI_ESLESTIRME(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3174_GET_KEFIL_LIST")
	public static GMMap getKefilList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3171.RC_QRY3171_KEFIL_LIST(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_ILETISIM_BILGILERI")
	public static GMMap getIletisimBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.RC_QRY3174_ILETISIM_BILGILERI(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);

			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.RC_QRY3174_APS_BILGILERI(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));

			/** TY-6327 begin TY-Tahsis ekranlari - iletisim Bilgileri (APS) */
			if (iMap.get("TC_KIMLIK_NO") != null && !"".equals(iMap.getString("TC_KIMLIK_NO"))) {
				try{
					GMMap tMap = new GMMap();
					tMap.putAll(GMServiceExecuter.call("BNSPR_QRY1098_GET_APS", iMap));
					oMap.put("TASINMA_TARIHI", tMap.get("TASINMA_TARIHI"));
					oMap.put("YABANCI_ADRES", tMap.get("YABANCI_ADRES"));
					oMap.put("YABANCI_IL", tMap.get("YABANCI_IL"));
					oMap.put("YABANCI_ULKE", tMap.get("YABANCI_ULKE_ACIKLAMA"));
				}catch(Exception e){
					oMap.put("APS_MESSAGE", e.getMessage());
				}
			}
			/** TY-6327 end */

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_KIMLIK_BILGILERI")
	public static GMMap getKimlikBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.RC_QRY3174_KIMLIK_BILGILERI(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));

			GMMap sMap = new GMMap();
			sMap.put("tckno_in", oMap.getString("TC_KIMLIK_NO"));
			GMMap kpsMap = GMServiceExecuter.call("BNSPR_TRN10011_KPS_KIMLIK_SORGULAMA" , sMap);
			
			oMap.put("ANNE_TCKN", kpsMap.getString("anneTckn"));
			oMap.put("BABA_TCKN", kpsMap.getString("babaTckn"));
			
			kpsMap = GMServiceExecuter.call("BNSPR_TRN10011_KPS_NUFUS_KAYIT_SORGULAMA" , sMap);
			
			oMap.put("EVLENME_TARIHI", kpsMap.getDate("evlenmeTarihi"));
			oMap.put("BOSANMA_TARIHI", kpsMap.getDate("bosanmaTarihi"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3174_TARIM_BILGILERI")
	public static GMMap getTarimBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		BirBasvuruTarim tarim = (BirBasvuruTarim) session.createCriteria(BirBasvuruTarim.class).add(Restrictions.eq("basvuruNo", iMap.getSize("BASVURU_NO"))).uniqueResult();
		oMap.put("BUYUKBAS_SAYISI", tarim.getBuyukbasSayisi());
		oMap.put("DONUM", tarim.getDonum());
		oMap.put("GUNCEL_RISK", tarim.getGuncelRisk());
		oMap.put("KUCUKBAS_SAYISI", tarim.getKucukbasSayisi());
		oMap.put("SATIS_KANALI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "TARIM_SATIS_KANAL_KOD").put("KEY", tarim.getTarimSatisKanalKod())).getString("TEXT"));
		oMap.put("TARIS_EH", tarim.getTarisEh());
		
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3174_TASIT_BILGILERI")
	public static GMMap getTasitBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.RC_QRY3174_TASIT_BILGILERI(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_TASIT_BILGILERI_TX")
	public static GMMap getTasitBilgileriTx(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.RC_QRY3174_TASIT_BILGILERI_TX(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_WEB_LINK")
	public static GMMap getWebLink(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			iMap.put("PARAMETRE", "SSK_REHBERLIK_LINK");
			oMap.put("SSK_REHBERLIK_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "SSK_TCKN_LINK");
			oMap.put("SSK_TCKN_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "SSK_AD_SOYAD_LINK");
			oMap.put("SSK_AD_SOYAD_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "SSK_EMEKLI_LINK");
			oMap.put("SSK_EMEKLI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "SSK_EMEKLI_AYLIGI_LINK");
			oMap.put("SSK_EMEKLI_AYLIGI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "BAGKUR_AD_SOYAD_TCKN_LINK");
			oMap.put("BAGKUR_AD_SOYAD_TCKN_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "BAGKUR_BORC_BILGISI_LINK");
			oMap.put("BAGKUR_BORC_BILGISI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "BAGKUR_EMEKLI_LINK");
			oMap.put("BAGKUR_EMEKLI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "EMEK_SAN_TCKN_LINK");
			oMap.put("EMEK_SAN_TCKN_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "AVUKAT_SORGULAMA_LINK");
			oMap.put("AVUKAT_SORGULAMA_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "TC_SANAYI_ODASI_LINK");
			oMap.put("TC_SANAYI_ODASI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "ITO_UNVAN_LINK");
			oMap.put("ITO_UNVAN_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "ITO_AD_SOYAD_LINK");
			oMap.put("ITO_AD_SOYAD_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "ITO_TICARET_SICIL_NO_LINK");
			oMap.put("ITO_TICARET_SICIL_NO_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "BTSO_LINK");
			oMap.put("BTSO_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "KTSO_LINK");
			oMap.put("KTSO_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "TICARET_SICIL_GAZETESI_LINK");
			oMap.put("TICARET_SICIL_GAZETESI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "TT_REHBER_LINK");
			oMap.put("TT_REHBER_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "E_VERGI_LINK");
			oMap.put("E_VERGI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "ARAC_SORGULAMA_LINK");
			oMap.put("ARAC_SORGULAMA_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "KASKO_DEGER_LISTESI");
			oMap.put("KASKO_DEGER_LISTESI", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "TRAMER_LINK");
			oMap.put("TRAMER_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "SABAS_LINK");
			oMap.put("SABAS_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.put("PARAMETRE", "GOOGLE_LINK");
			oMap.put("GOOGLE_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));

			iMap.putAll(getKimlikBilgileri(iMap));
			Date date = iMap.getDate("YIL");

			String link = "https://esgm.sgk.gov.tr/Esgm/KimlikSorgulama?mernisNo=" + iMap.getString("TCKN")
			// + "&babaAdi="
			// + iMap.getString("BABA_AD")
			+ "&ilKodu=" + iMap.getString("NUFUS_IL_KOD").substring(1)
			// + "&ilceKodu="
			// + iMap.getString("NUFUS_ILCE_KOD")
			+ "&ciltNo=" + iMap.getString("CILT_NO")
			// + "&aileSiraNo="
			// + iMap.getString("AILE_SIRA_NO")
			+ "&dYil=" + 19 + date.getYear() + "&guvenlikKodu=";

			oMap.put("SSK_TCKN_LINK", link);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_HESAP_BILGILERI")
	public static GMMap getHesapBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		BigDecimal toplamKullandirilan = new BigDecimal(0);
		BigDecimal toplamAnapara = new BigDecimal(0);
		BigDecimal toplamTaksit = new BigDecimal(0);
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3174.RC_TRN3174_HESAP_BILGILERI(?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			String tableName = "KREDI_BILGI";
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetResults(rSet, tableName));
			GMServerDatasource.close(rSet);

			for (int j = 0; j < oMap.getSize(tableName); j++) {
				if ("Y".equals(oMap.getString(tableName, j, "TAKIP_DURUM_KODU")) || ("A".equals(oMap.getString(tableName, j, "DURUM_KOD")) && ("A".equals(oMap.getString(tableName, j, "TAKIP_DURUM_KODU")) || "I".equals(oMap.getString(tableName, j, "TAKIP_DURUM_KODU")) || "G".equals(oMap.getString(tableName, j, "TAKIP_DURUM_KODU")) || StringUtils.isEmpty(oMap.getString(tableName, j, "TAKIP_DURUM_KODU"))))) {

					toplamKullandirilan = oMap.get(tableName, j, "KULLANDIRILAN_TUTAR") != null ? toplamKullandirilan.add(oMap.getBigDecimal(tableName, j, "KULLANDIRILAN_TUTAR")) : toplamKullandirilan;
					toplamAnapara = oMap.get(tableName, j, "ANAPARA_BAKIYESI") != null ? toplamAnapara.add(oMap.getBigDecimal(tableName, j, "ANAPARA_BAKIYESI")) : toplamAnapara;
					toplamTaksit = oMap.get(tableName, j, "TAKSIT_TUTARI") != null ? toplamTaksit.add(oMap.getBigDecimal(tableName, j, "TAKSIT_TUTARI")) : toplamTaksit;
				}
			}

			oMap.put("TOPLAM_KULLANDIRILAN_TUTAR", toplamKullandirilan);
			oMap.put("TOPLAM_ANAPARA_BAKIYESI", toplamAnapara);
			oMap.put("TOPLAM_TAKSIT_TUTARI", toplamTaksit);

			tableName = "KMH_BILGI";
			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetResults(rSet, tableName));

			rSet = (ResultSet) stmt.getObject(4);
			oMap.putAll(DALUtil.rSetMap(rSet));

			iMap.put("TAHSIS_IZLEME", "E");
			iMap.put("MUSTERI_NO", oMap.getString("MUSTERI_NO"));
			oMap.put("KREDI_KART_BILGI", GMServiceExecuter.execute("BNSPR_GET_KK_OCEAN_CARD_INFO", iMap).get("KREDI_KART_BILGI"));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3174_GET_BRM_SORGU_SONUC")
	public static GMMap getBRMSorguSonuc(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_NBSM.get_sonuc_map(?,?)}");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			// Musteri Sonuc
			stmt.setString(3, "M");
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(rSetBRMSonucMap(rSet, "M"));
			GMServerDatasource.close(rSet);

			// Kefil1 Sonuc
			stmt.setString(3, "K1");
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(rSetBRMSonucMap(rSet, "K1"));
			GMServerDatasource.close(rSet);

			// Kefil Sonuc
			stmt.setString(3, "K2");
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(rSetBRMSonucMap(rSet, "K2"));

			stmt.close();
			if (!("E".equals(iMap.getString("KK_BASVURU_MU")))) {
				stmt = conn.prepareCall("{? = call pkg_basvuru.Nbsm_Taksit_Tutari(?,?)}");
				stmt.registerOutParameter(1, Types.DECIMAL);
				stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setBigDecimal(3, oMap.getBigDecimal("M_SISTEMIN_ONERDIGI_TUTAR"));
				stmt.execute();
				oMap.put("NBSM_TAKSIT_TUTAR", stmt.getBigDecimal(1));
				oMap.put("M_SAFE_URUN_MU", "FATURALI SAFE".equals(oMap.getString("M_SAFE_URUN_MU")) ? "Evet" : "Hay�r");

				GMServerDatasource.close(stmt);

				String es_kkb_sonuc = "Ba�ar�s�z";

				String func = "{? = call PKG_KKB_SORGULA.es_kkb_sorgu_basarili(?,?)}";

				Object inputValues[] = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, "I" };

				String s1 = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);

				if ("E".equals(s1)) {
					inputValues[3] = "F";
					String s2 = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
					if ("E".equals(s2)) {
						es_kkb_sonuc = "Ba�ar�l�";
					}
				}

				oMap.put("ES_KKB_SONUC", es_kkb_sonuc);

			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	public static GMMap rSetBRMSonucMap(ResultSet rSet, String sorguTipi) {
		try {
			GMMap oMap = new GMMap();
			if (rSet.next()) {
				ResultSetMetaData rs = rSet.getMetaData();
				for (int c = 1; c <= rs.getColumnCount(); c++) {
					oMap.put(sorguTipi + "_" + rs.getColumnName(c), rSet.getObject(c));
				}

				putAciklama(oMap, "ISYERI_DOGRULAMA", sorguTipi, "BAS_DOG_AKSIYON_KOD");
				putAciklama(oMap, "MUSTERI_DOGRULAMA", sorguTipi, "BAS_DOG_AKSIYON_KOD");
				putAciklama(oMap, "WEB_DOGRULAMA", sorguTipi, "BAS_DOG_AKSIYON_KOD");
				putAciklama(oMap, "ADRES_BELGESI_ISTISNASI", sorguTipi, "NBSM_EVET_HAYIR");
				putAciklama(oMap, "GELIR_BELGESI_ISTISNASI", sorguTipi, "NBSM_EVET_HAYIR");
				putAciklama(oMap, "ES_GELIR_BELGESI_ISTISNASI", sorguTipi, "NBSM_EVET_HAYIR");
				putAciklama(oMap, "GMENKUL_BELGESI_ISTISNASI", sorguTipi, "NBSM_EVET_HAYIR");
				putAciklama(oMap, "KEFIL_GEREKIYOR_MU", sorguTipi, "NBSM_EVET_HAYIR");
				putAciklama(oMap, "GARANTORLU", sorguTipi, "NBSM_EVET_HAYIR");
				putAciklama(oMap, "GEREKCE_KODU_01", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_02", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_03", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_04", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_05", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_06", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_07", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_08", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_09", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_10", sorguTipi, "NBSM_REASON_CODE");
				putAciklama(oMap, "GEREKCE_KODU_KEFILDEN", sorguTipi, "NBSM_REASON_CODE");

				if (oMap.getString(sorguTipi + "_HANGI_KISI_KEFIL_ALINACAK") != null) {
					String key = null;
					if (oMap.getString(sorguTipi + "_HANGI_KISI_KEFIL_ALINACAK").equals("Y")) {
						key = "1";
					}
					else if (oMap.getString(sorguTipi + "_HANGI_KISI_KEFIL_ALINACAK").equals("N")) {
						key = "2";
					}
					if (key != null) {
						oMap.put(sorguTipi + "_HANGI_KISI_KEFIL_ALINACAK_ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "KEFIL_YAKINLIK_KOD").put("KEY", key)).getString("TEXT"));
					}
				}

				if (oMap.getString(sorguTipi + "_SISTEM_BASVURU_KARARI") != null) {
					oMap.put(sorguTipi + "_SISTEM_BASVURU_KARARI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "NBSM_KARAR_KOD").put("KEY", oMap.getString(sorguTipi + "_SISTEM_BASVURU_KARARI"))).getString("TEXT"));

				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_QRY3174_GET_ONCEKI_BASVURU_COLOR")
	public static GMMap getOncekiBasvurularColor(GMMap iMap) {
		try {
			Color differentBackground = new Color(255, 0, 64);
			Color defaultBackground = new Color(255, 255, 255);
			GMMap oMap = new GMMap();

			Set<Object> keySet = iMap.keySet();
			for (Object keyObject : keySet) {
				String key = (String) keyObject;
				if (iMap.containsKey(key + "_M")) {
					if (iMap.getString(key).equals(iMap.getString(key + "_M"))) {
						oMap.put("C_" + key, defaultBackground);
						oMap.put("C_" + key + "_M", defaultBackground);
					}
					else if (!iMap.getString(key).equals(iMap.getString(key + "_M"))) {
						oMap.put("C_" + key, differentBackground);
						oMap.put("C_" + key + "_M", differentBackground);
					}
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/*
	 * Gelen degerlerin(columnName'e gore) paramtext karsiliklarini oMap'e atar
	 */
	private static void putAciklama(GMMap oMap, String columnName, String sorguTipi, String paramText) {
		if (paramText.equals("NBSM_REASON_CODE")) {
			if (oMap.getString(sorguTipi + "_" + columnName) != null)
				oMap.put(sorguTipi + "_" + columnName + "_ACIKLAMA", getReasonCodeAciklama(oMap.getString(sorguTipi + "_" + columnName)));
		}
		else {
			if (oMap.getString(sorguTipi + "_" + columnName) != null)
				oMap.put(sorguTipi + "_" + columnName + "_ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", paramText).put("KEY", oMap.getString(sorguTipi + "_" + columnName))).getString("TEXT"));
		}
	}

	private static String getReasonCodeAciklama(String kod) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3174.reason_code_aciklama(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, kod);
			stmt.execute();

			return stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_PTT_SMS_GONDER")
	public static GMMap PTTSMSGonderilmelimi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3174.PTTSMSGonderilmelimi(?)}");
			int pc = 1;
			stmt.registerOutParameter(pc++, Types.VARCHAR);
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			if (iMap.getString("KARAR") != null && iMap.getString("KARAR").compareTo("R") == 0 && stmt.getString(1) == "E") {
				GMServiceExecuter.call("BNSPR_TRN3174_SEND_SMS", iMap);
			}
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_BASVURU_KILIT_KONTROL")
	public static GMMap getBasvuruKilitKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3174.basvuru_kilit_kontrol(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			return oMap;
		}
		catch (Exception e) {
			if(iMap.containsKey("FROM_IWD")){
				oMap.put("MESSAGE",e.getMessage());
				return oMap;
			}else{
				throw ExceptionHandler.convertException(e);
			}
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_BASVURU_KILITLE")
	public static GMMap getBasvuruKilitle(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3174.basvuru_kilitle(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3174_BASVURU_KILIT_COZ")
	public static GMMap getBasvuruKilitCoz(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3174.basvuru_kilit_coz(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3174_BASVURU_KEFIL_VARMI")
	public static GMMap getKefilKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3171.Get_Kefil_Count (?, ?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.registerOutParameter(i, Types.NUMERIC);
			stmt.execute();

			oMap.put("KEFIL_DURUM", stmt.getBigDecimal(i));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3174_ALT_AKSIYON_KARAR_KOD")
	public static GMMap altAksiyonKararKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String aksiyonKararKod = iMap.getString("AKSIYON_KARAR_KOD");
			if (aksiyonKararKod != null) {
				StringBuffer query = new StringBuffer();
				query.append("select key2,text from gnl_param_text");
				query.append(" where kod = 'BASVURU_RED_GEREKCE_KARAR_KOD'");
				query.append(" and key1='" + aksiyonKararKod + "'");
				query.append(" and nvl(key3,'A')='A'");
				query.append(" order by 1");
				DALUtil.fillComboBox(oMap, "ALT_AKSIYON_KARAR_KOD", true, query.toString());
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_BASVURU_LIST_BY_APS_NO")
	public static GMMap basvuruListByApsNo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String func = "{? = call pkg_trn3174.rc_qry3174_aps_basvuru(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("APS_NO") };
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BASVURU_LIST", inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3174_FIND_EKRAN_NO")
	public static GMMap findEkranNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		String durumKodu = iMap.getString("DURUM_KODU");
		int ekranKodu = 0;
		if (enmScreenCode.ONAY1.getDurumKod().equalsIgnoreCase(durumKodu))
			ekranKodu = enmScreenCode.ONAY1.getScreenCode();
		else if (enmScreenCode.ONAY2.getDurumKod().equalsIgnoreCase(durumKodu))
			ekranKodu = enmScreenCode.ONAY2.getScreenCode();
		else if (enmScreenCode.ONAY3.getDurumKod().equalsIgnoreCase(durumKodu))
			ekranKodu = enmScreenCode.ONAY3.getScreenCode();
		else if (enmScreenCode.ONAY4.getDurumKod().equalsIgnoreCase(durumKodu))
			ekranKodu = enmScreenCode.ONAY4.getScreenCode();

		oMap.put("EKRAN_KODU", ekranKodu);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3174_FIND_BASVURU_NO_BY_TX_NO")
	public static GMMap findBasvuruNoByTxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3174.find_basvuru_no(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("TX_NO"));
			stmt.execute();

			oMap.put("BASVURU_NO", stmt.getBigDecimal(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN3174_IS_USER_AND_CLIENT_RELATIVE")
	public static GMMap isUserAndClientRelative(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3174.is_user_and_client_relative(?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3174_BIRLESTIRME_BASVURU_LIST")
	public static GMMap birlestirmeBasvuruList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String func = "{? = call pkg_trn3174.rc_qry3174_birlestirme_bilgi(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BASVURU_LIST", inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3174_BORC_TRANSFERI_BILGI")
	public static GMMap borcTransferiBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3174.rc_qry3174_borc_transferi(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
