package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirihtarnameMusteriLog;
import tr.com.aktifbank.bnspr.dao.BirihtarnameSorguLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3296Services {
    @GraymoundService("BNSPR_QRY3296_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_rc3295.ihtarname_min_gun}");
            stmt.registerOutParameter(1, Types.NUMERIC); //ref cursor
            stmt.execute();
            oMap.put("MIN_GUN", stmt.getBigDecimal(1));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    @GraymoundService("BNSPR_QRY3296_QUERY_IHTAR")
    public static GMMap queryIhtar(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC3295.sorgu_no_al()}");
            stmt.registerOutParameter(1, Types.NUMERIC);
            stmt.execute();

            oMap.put("SORGU_NO", stmt.getBigDecimal(1));
            stmt.close();
            stmt = conn.prepareCall("{call pkg_rc3295.sorgu_sonucu_hazirla_kmh(?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            stmt.setBigDecimal(1, oMap.getBigDecimal("SORGU_NO"));
            stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setString(3, iMap.getString("TCKN"));
            stmt.setBigDecimal(4, iMap.getBigDecimal("HESAP_NO"));
            stmt.setBigDecimal(5, iMap.getBigDecimal("BAKIYE_ALT"));
            stmt.setBigDecimal(6, iMap.getBigDecimal("BAKIYE_UST"));
            stmt.setBigDecimal(7, iMap.getBigDecimal("GECIKME_TUTAR_ALT"));
            stmt.setBigDecimal(8, iMap.getBigDecimal("GECIKME_TUTAR_UST"));
            stmt.setBigDecimal(9, iMap.getBigDecimal("GECIKME_GUN_SAYISI_ALT"));
            stmt.setBigDecimal(10, iMap.getBigDecimal("GECIKME_GUN_SAYISI_UST"));
            stmt.setString(11, iMap.getBoolean("APS_IHTAR") ? "E" : "H");
            stmt.setString(12, iMap.getBoolean("NOTER_IHTAR") ? "E" : "H");
            stmt.registerOutParameter(13, -10); //ref cursor

            stmt.execute();
            rSet = (ResultSet) stmt.getObject(13);
            String tableName = "TABLE_DATA";
            int row = 0;
            while (rSet.next()) {
                oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
                oMap.put(tableName, row, "MUSTERI_NO", rSet.getObject("MUSTERI_NO"));
                oMap.put(tableName, row, "AD_SOYAD", rSet.getObject("AD_SOYAD"));
                oMap.put(tableName, row, "IHTARNAME_TIP", rSet.getObject("IHTARNAME_TIP"));
                oMap.put(tableName, row, "KREDI_BAKIYE", rSet.getObject("KREDI_BAKIYE"));
                oMap.put(tableName, row, "GECIKME_TUTAR", rSet.getObject("GECIKME_TUTAR"));
                oMap.put(tableName, row, "GECIKME_TARIH", rSet.getObject("GECIKME_TARIH"));
                oMap.put(tableName, row, "GECIKME_GUN", rSet.getObject("GECIKME_GUN"));
                oMap.put(tableName, row, "TOPLAM_BORC", rSet.getObject("TOPLAM_BORC"));
                row++;
            }

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

    @GraymoundService("BNSPR_QRY3296_IHTARNAME")
    public static GMMap setIhtarname(GMMap iMap) {
        Connection conn = null;
;        CallableStatement stmt = null;
        ResultSet rSet = null;
        ResultSet rSet2 = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        GMMap oMap = new GMMap();
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "TABLE_DATA";
            String serviceName = "BNSPR_KPS_GET_ADDRESS_INFO";
            for (int i = 0; i < iMap.getSize(tableName); i++) {
                iMap.put("TCKN", iMap.getString(tableName, i, "TC_KIMLIK_NO"));
                BirihtarnameMusteriLog birihtarnameMusteriLog =
                    (BirihtarnameMusteriLog) session.createCriteria(BirihtarnameMusteriLog.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal(tableName, i, "MUSTERI_NO")))
                        .add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
                if (iMap.getBoolean(tableName, i, "YAZDIR")) {
                	if(!StringUtils.isEmpty(iMap.getString("TCKN"))){
                		iMap.put("ADDRESS_LOG_ID", GMServiceExecuter.call(serviceName, iMap).getString("LOG_ID"));
                		birihtarnameMusteriLog.setApsSorguId(iMap.getBigDecimal("ADDRESS_LOG_ID"));
                	}
                    birihtarnameMusteriLog.setIhtarnameEh("E");
                } else {
                    birihtarnameMusteriLog.setIhtarnameEh("H");
                }
        
                session.saveOrUpdate(birihtarnameMusteriLog);
                session.flush();
            }
            BirihtarnameSorguLog birihtarnameSorguLog = (BirihtarnameSorguLog)session.createCriteria(BirihtarnameSorguLog.class)
                    .add(Restrictions.eq("sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
            birihtarnameSorguLog.setOlusturTarih(new java.util.Date());
            session.saveOrUpdate(birihtarnameSorguLog);
            session.flush();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_RC3295.ihtarname_olustur(?,?,?)}");
            stmt.setBigDecimal(1, iMap.getBigDecimal("SORGU_NO"));
            stmt.registerOutParameter(2, -10);
            stmt.registerOutParameter(3, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(2);
            rSet2 = (ResultSet) stmt.getObject(3);

            tableName = "MUSTERI_LIST";
            int row = 0;
            while (rSet.next()) {
                if(iMap.getString("TIP").equals(rSet.getString("IHTARNAME_TIP"))){
                oMap.put(tableName, row, "SORGU_NO", rSet.getObject("SORGU_NO"));
                oMap.put(tableName, row, "REC_OWNER", rSet.getObject("REC_OWNER"));
                oMap.put(tableName, row, "REC_DATE", rSet.getObject("REC_DATE"));
                oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
                oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
                oMap.put(tableName, row, "AD_SOYAD", rSet.getObject("AD_SOYAD"));
                oMap.put(tableName, row, "IHTARNAME_EH", rSet.getObject("IHTARNAME_EH"));
                oMap.put(tableName, row, "ADRES", rSet.getString("ADRES"));
                oMap.put(tableName, row, "APS_SORGU_ID", rSet.getObject("APS_SORGU_ID"));
                oMap.put(tableName, row, "KREDI_BAKIYE", rSet.getObject("KREDI_BAKIYE"));
                oMap.put(tableName, row, "GECIKME_TUTAR", rSet.getObject("GECIKME_TUTAR"));
                oMap.put(tableName, row, "GECIKME_TARIH", rSet.getObject("GECIKME_TARIH"));
                oMap.put(tableName, row, "GECIKME_GUN", rSet.getObject("GECIKME_GUN"));
                oMap.put(tableName, row, "TOPLAM_BORC",  formatCurrency(rSet.getBigDecimal("TOPLAM_BORC")));
                oMap.put(tableName, row, "IHTAR_MASRAF",  formatCurrency(rSet.getBigDecimal("IHTAR_MASRAF")));
                row++;
                }
            }

            tableName = "KREDI_LIST";
            row = 0;
            while (rSet2.next()) {
                oMap.put(tableName, row, "SORGU_NO", rSet2.getObject("SORGU_NO"));
                oMap.put(tableName, row, "REC_OWNER", rSet2.getObject("REC_OWNER"));
                oMap.put(tableName, row, "REC_DATE", rSet2.getObject("REC_DATE"));
                oMap.put(tableName, row, "MUSTERI_NO", rSet2.getString("MUSTERI_NO"));
                oMap.put(tableName, row, "BASVURU_NO", rSet2.getString("BASVURU_NO")); 
                oMap.put(tableName, row, "BAGLI_HESAP_NO", rSet2.getString("HESAP_NO"));
                oMap.put(tableName, row, "IBAN", rSet2.getString("IBAN"));
                oMap.put(tableName, row, "KULLANDIRIM_TARIH", StringUtils.isBlank(rSet2.getString("KULLANDIRIM_TARIH")) ? "" : sdf.format(rSet2.getDate("KULLANDIRIM_TARIH")));
                oMap.put(tableName, row, "KULLANDIRIM_TUTAR",  formatCurrency(rSet2.getBigDecimal("KULLANDIRIM_TUTAR")));
                oMap.put(tableName, row, "FAIZ_ORAN",  formatCurrency(rSet2.getBigDecimal("FAIZ_ORAN")));
                oMap.put(tableName, row, "YILLIK_FAIZ_ORAN", formatCurrency(rSet2.getBigDecimal("YILLIK_FAIZ_ORAN")));
                oMap.put(tableName, row, "TOPLAM_BORC", formatCurrency(rSet2.getBigDecimal("TOPLAM_BORC")));
                oMap.put(tableName, row, "GECIKME_TARIH", rSet2.getObject("GECIKME_TARIH"));
                oMap.put(tableName, row, "GECIKME_GUN", rSet2.getObject("GECIKME_GUN"));
                oMap.put(tableName, row, "TC_KIMLIK_NO", rSet2.getObject("TC_KIMLIK_NO"));
                oMap.put(tableName, row, "DIGER_BORC", rSet2.getBigDecimal("DIGER_BORC"));
                oMap.put(tableName, row, "ANAPARA_TUTARI",formatCurrency( rSet2.getBigDecimal("ANAPARA_TUTARI")));
                oMap.put(tableName, row, "GECIKME_FAIZ_TUTAR", formatCurrency(rSet2.getBigDecimal("GECIKME_FAIZ_TUTAR")));
                oMap.put(tableName, row, "KKDF_TUTARI", formatCurrency(rSet2.getBigDecimal("KKDF_TUTARI")));
                oMap.put(tableName, row, "BSMV_TUTARI", formatCurrency(rSet2.getBigDecimal("BSMV_TUTARI")));
                oMap.put(tableName, row, "TOPLAM_BORC_TUTARI",
                    formatCurrency(rSet2.getBigDecimal("DIGER_BORC") == null ? rSet2.getBigDecimal("TOPLAM_BORC") : rSet2.getBigDecimal("TOPLAM_BORC").add(rSet2.getBigDecimal("DIGER_BORC"))));
                oMap.put(tableName, row, "GECIKMIS_TAKSIT_TUTAR", formatCurrency(rSet2.getBigDecimal("GECIKMIS_TAKSIT_TUTAR")));
                row++;
            }

            stmt.close();
            oMap.put("TIP", iMap.getString("TIP"));
            oMap.putAll(GMServiceExecuter.call("BNSPR_NOTER_KMH_IHTAR_RAPOR", oMap));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(rSet2);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    public static String formatCurrency(BigDecimal value) {
        if (value == null || value.compareTo(BigDecimal.ZERO) == 0)
        	return "0,00";
        DecimalFormat formatter = new DecimalFormat("###,##0.00");
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
        symbols.setDecimalSeparator(',');
        symbols.setGroupingSeparator('.');
        formatter.setDecimalFormatSymbols(symbols);
        return formatter.format(value);
    }

    @GraymoundService("BNSPR_QRY3296_SELECT_ALL")
    public static GMMap selectAll(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            if (iMap.getBoolean("CHECKED")) {
                for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
                    iMap.put("TABLE_DATA", i, "YAZDIR", true);
                }
            } else {
                for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
                    iMap.put("TABLE_DATA", i, "YAZDIR", false);
                }
            }
            oMap.put("TABLE_DATA", iMap.get("TABLE_DATA"));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }
    
    

}
