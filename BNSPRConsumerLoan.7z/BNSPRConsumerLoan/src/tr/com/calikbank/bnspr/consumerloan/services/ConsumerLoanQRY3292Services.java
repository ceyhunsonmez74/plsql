package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3292Services {
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>BASLANGIC_TARIHI - Arama araligi default baslangic tarihi(banka tarihi - 1 ay)
	 *         <li>BITIS_TARIHI - Arama araligi default bitis tarihi(banka tarihi)
	 *         <li>URUN_TIPI_LIST - Dcs gecikmeye dusebilecek urun tipleri
	 */
	@GraymoundService("BNSPR_QRY3292_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Baslangic ve bitis tarihi araligi 1 ay olsun
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3173_GET_DATES", iMap));
			//Urun tipi al
			GMMap sorguMap = new GMMap();
			sorguMap.put("TABLE_NAME", "URUN_TIPI_LIST");
			sorguMap.put("ADD_EMPTY_KEY", "E");
			sorguMap.put("KOD", "DCS_GECIKME_URUN_TIPI");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen kriterlere gore istenilen sonuclari listeler<br>
	 * @author murat.el
	 * @since
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>TC_KIMLIK_NO - TC kimlik numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>CEP_TEL_ALAN - Cep telefonu alan kodu
	 *        <li>CEP_TEL_NUMARA - Cep telefonu numarasi
	 *        <li>BASLANGIC_TAR - Arama baslangic tarihi
	 *        <li>BITIS_TAR - Arama bitis tarihi
	 *        <li>URUN_TIPI - Urun tipi
	 *        <li>REFERANS_NO - Referans numarasi(KK:Kart numarasi|BK:Basvuru numarasi|KMH:Hesap numarasi)
	 * @return Sorgu sonuclari<br>
	 *        <li>YASAL_TAKIP_BILGILERI - Dcs Gecikme sonrasi sms gonderilecek/gonderilen data ve sms bilgileri
	 */
	@GraymoundService("BNSPR_QRY3292_LIST")
	public static GMMap list(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Connection al
			conn = DALUtil.getGMConnection();
			//Listele
			query = "{? = call PKG_DCS_DELAY_SMS.Rc_Qry3292_List(?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("CEP_TEL_ALAN"));
			stmt.setString(i++, iMap.getString("CEP_TEL_NUMARA"));
			//tarihleri sql data olarak gonder
			//Baslangic
			if (iMap.getDate("BASLANGIC_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			//Bitis
			if (iMap.getDate("BITIS_TAR") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getString("URUN_TIPI"));
			stmt.setString(i++, iMap.getString("REFERANS_NO"));
			stmt.execute();
			//Ekran formatina cevir
			rSet = (ResultSet) stmt.getObject(1);
			DALUtil.rSetResults(rSet, "YASAL_TAKIP_BILGILERI", oMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

}
