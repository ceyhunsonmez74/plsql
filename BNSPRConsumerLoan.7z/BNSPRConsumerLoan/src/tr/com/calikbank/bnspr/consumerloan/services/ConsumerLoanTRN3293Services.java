package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruSgkYaziTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSgkYaziTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3293Services {

	@GraymoundService("BNSPR_TRN3293_GET_IADE_LIST")
	public static GMMap getIadeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "TABLE";
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3293.GET_IADE_LIST(?,?,?)}");
			
			int paramIndex = 1;
			stmt.setDate(paramIndex++, iMap.getDate("ISLEM_TARIHI") != null ?
					 new Date(iMap.getDate("ISLEM_TARIHI").getTime()) : null);
			stmt.setString(paramIndex++, iMap.getString("YAZI_NO"));
			stmt.registerOutParameter(paramIndex++, -10);
			stmt.execute();
			stmt.getMoreResults();
			
			rSet = (ResultSet) stmt.getObject(--paramIndex);
			oMap.putAll(DALUtil.rSetResults(rSet, tableName));

		}catch (Exception e) {
			ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3293_CREATE_REPORT")
	public static GMMap createReport(GMMap iMap){
		
		deleteReport(iMap);
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String yaziTarihi = null;
		
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			for (int i = 0; i < iMap.getSize("TABLE"); i++) {
				if(iMap.getBoolean("TABLE", i, "SEC")){
					BirBasvuruSgkYaziTx tx = new BirBasvuruSgkYaziTx();
					BirBasvuruSgkYaziTxId id = new BirBasvuruSgkYaziTxId();
					
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setIadeYaziNo(iMap.getString("YAZI_NO"));
					id.setAciklama(iMap.getString("ACIKLAMA"));
					id.setMusteriNo(iMap.getBigDecimal("TABLE", i, "MUSTERI_NO"));
					id.setTckn(iMap.getString("TABLE", i, "TCKN"));
					id.setAdSoyad(iMap.getString("TABLE", i, "AD_SOYAD"));
					id.setIadeTutar(iMap.getBigDecimal("TABLE", i, "IADE_TUTAR"));
					tx.setId(id);
					
					if(yaziTarihi == null){
						if(iMap.getDate("TABLE", i, "YAZI_TARIHI") != null)
							yaziTarihi = sdf.format(new Date(iMap.getDate("TABLE", i,"YAZI_TARIHI").getTime()));
					}
					
					session.save(tx);
					session.flush();
				}
			}
			
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			
			parameters.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			parameters.put("YAZI_NO", iMap.getString("YAZI_NO"));
			parameters.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
			parameters.put("TARIH", sdf.format(new java.util.Date()));
			parameters.put("YAZI_TARIHI", yaziTarihi);
			
			oMap.put("REPORT_DATA", ReportUtil.generateReport("BNSPR_RAP3293_SGK_IADE_YAZI", parameters));
			
		}catch (Exception e) {
			ExceptionHandler.convertException(e);
		}finally{
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3293_DELETE_REPORT_DATA")
	public static GMMap deleteReport(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		PreparedStatement pstmt = null;
		try{
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			pstmt = conn.prepareStatement("delete from bir_basvuru_sgk_yazi_tx where tx_no = ?");
			pstmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			pstmt.execute();
			pstmt.close();
			
			session.flush();
		}catch (Exception e) {
			ExceptionHandler.convertException(e);
		}finally{
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3293_SAVE")
	public static GMMap save(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			iMap.put("TRX_NAME", "3293");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			return oMap;
		}catch (Exception e) {
			ExceptionHandler.convertException(e);
		}finally{
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3293_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "TABLE";
		
		try{
			Session session = DAOSession.getSession("BNSPRDal");
            String sgkYaziStr = "select musteri_no, tckn, iade_tutar, iade_yazi_no, aciklama from bir_basvuru_sgk_yazi_tx where tx_no = " + iMap.getBigDecimal("TRX_NO");
            
            GMMap sgkMap = DALUtil.getResults(sgkYaziStr, tableName);
            
			for (int i = 0; i < sgkMap.getSize(tableName);i++) {
				oMap.put(tableName, i,"SEC", true);
				oMap.put(tableName, i,"MUSTERI_NO", sgkMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
				oMap.put(tableName, i,"TCKN", sgkMap.getBigDecimal(tableName, i, "TCKN"));
				oMap.put(tableName, i,"IADE_TUTAR", sgkMap.getBigDecimal(tableName, i, "IADE_TUTAR"));
				oMap.put("YAZI_NO", sgkMap.getBigDecimal(tableName, i, "IADE_YAZI_NO"));
				oMap.put("ACIKLAMA", sgkMap.getBigDecimal(tableName, i, "ACIKLAMA"));
			}
			
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
		}catch (Exception e) {
			ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
}
