package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruYim;
import tr.com.aktifbank.bnspr.dao.BirBasvuruYimTx;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanYimServices implements Constants {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanYimServices.class);
	
	/**
	 * Basvurunun durum bilgisini doner.
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_YIM_GET_BASVURU_DURUM")
	public static GMMap getBasvuruDuru(GMMap iMap){
		GMMap oMap = new GMMap();
		String status = StringUtils.EMPTY;
		BigDecimal appNo = BigDecimal.ZERO;
		
		try {
			appNo = iMap.getBigDecimal(BASVURU_NO);
			status = (String) DALUtil.callOneParameterFunction("{? = call pkg_yim.getBasvuruDurum(?)}", Types.VARCHAR, appNo);
			oMap.put(DURUM, status);
			
			if(STR_MINUS_ONE.equals(status)){
				oMap.put(RETURN_CODE, STR_ZERO);
				oMap.put(RETURN_DATA, "Sorgulama ba�ar�s�z. Ba�vuru No : " + appNo);
			}else if(STR_ZERO.equals(status)){
				oMap.put(RETURN_CODE, STR_ONE);
				oMap.put(RETURN_DATA, appNo + " no'lu ba�vuru bulunamad�.");
			}else {
				oMap.put(RETURN_CODE, STR_ONE);
				oMap.put(RETURN_DATA, "Sorgulama ba�ar�l�. Ba�vuru No : " + appNo);
			}
		}
		catch (Exception e) {
			logger.error("BNSPR_YIM_GET_BASVURU_DURUM servisinde hata!");
			oMap.put(RETURN_CODE, STR_ZERO);
			oMap.put(RETURN_DATA, "Sorgulama servisinde hata olu�tu.");
		}
		
		return oMap;
	}
	
	/**
	 * Basvurunun durumunu gunceller.
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_YIM_ODEME_GUNCELLEME")
	public static GMMap yimOdemeGuncelleme(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = null;
		Date updateDate = new Date();
		String appState = StringUtils.EMPTY;
		String returnCode = StringUtils.EMPTY;
		BigDecimal appNo = BigDecimal.ZERO;
		BigDecimal txNo = BigDecimal.ZERO;
		
		try {
			session = DAOSession.getSession("BNSPRDal");
			appNo = iMap.getBigDecimal(BASVURU_NO);
			updateDate = iMap.getDate(GUNCELLEME_TARIHI);
			appState = iMap.getString(DURUM);
			
			BirBasvuruYim yim = (BirBasvuruYim) session.createCriteria(BirBasvuruYim.class).add(Restrictions.eq("basvuruNo", appNo)).uniqueResult();
			BirBasvuruYimTx yimTx = new BirBasvuruYimTx();
			
			if(yim != null){
				txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal(TRX_NO);
				yimTx.setTxNo(txNo);
				yimTx.setBasvuruNo(appNo);
				yimTx.setDurumKodu(appState);
				yimTx.setGuncellemeTarihi(updateDate);
				yimTx.setBasvuruTarihi(yim.getBasvuruTarihi());
				yimTx.setDovizKodu(yim.getDovizKodu());
				yimTx.setKrediTutari(yim.getKrediTutari());
				yimTx.setKullandirilanNetTutar(yim.getKullandirilanNetTutar());
				yimTx.setKullandirimTarihi(yim.getKullandirimTarihi());
				yimTx.setMusteriNo(yim.getMusteriNo());
				yimTx.setMusteriHesapNo(yim.getMusteriHesapNo());
				yimTx.setYimHesapNo(yim.getYimHesapNo());
				session.save(yimTx);
				session.flush();
				
				returnCode = (String) DALUtil.callOneParameterFunction("{? = call pkg_yim.basvuruDurumGuncelle(?)}", Types.VARCHAR, appNo);
				oMap.put(RETURN_CODE, returnCode);
				
				if(STR_ONE.equals(returnCode)){
					oMap.put(RETURN_DATA, "G�ncelleme ba�ar�l�.");
				}else if (STR_ZERO.equals(returnCode)) {
					oMap.put(RETURN_DATA, "G�ncelleme ba�ar�s�z.");
				}
			}else {
				oMap.put(RETURN_CODE, STR_ONE);
				oMap.put(RETURN_DATA, appNo + " no'lu ba�vuru bulunamad�.");
			}
		}
		catch (Exception e) {
			logger.error("BNSPR_YIM_ODEME_GUNCELLEME servisinde hata!");
			oMap.put(RETURN_CODE, STR_ZERO);
			oMap.put(RETURN_DATA, "G�ncelleme servisinde hata al�nd�.");
		}
		
		return oMap;
	}
	
	/**Mutabakat icin basvuru raporu doner.
	 * @param iMap
	 *  GUNCELLEME_TARIHI - Basvuru guncelleme tarihi
	 * @return oMap
	 * 	RESPONSE - Sonuc kodu (0:Basarisiz, 1:Basarili)
	 */
	@GraymoundService("BNSPR_YIM_BASVURU_RAPOR")
	public static GMMap getYimBasvuruBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		Connection conn = null;
		CallableStatement stmt = null;
		String tableName = "REPORT";
		String returnCode = StringUtils.EMPTY;
		String returnData = StringUtils.EMPTY;
		
		try {
			conn = DALUtil.getGMConnection();
			int paramIndex = 1;
			Date updateDate = iMap.getDate(GUNCELLEME_TARIHI);
			stmt = conn.prepareCall("{ call pkg_yim.getBasvuruRapor(?,?,?,?)}");
			stmt.setDate(paramIndex++, updateDate != null ? new java.sql.Date(updateDate.getTime()) : null);
			stmt.registerOutParameter(paramIndex++, -10);
			stmt.registerOutParameter(paramIndex++, Types.VARCHAR);
			stmt.registerOutParameter(paramIndex, Types.VARCHAR);
			stmt.execute();
			stmt.getMoreResults();
			
			returnData = (String) stmt.getObject(paramIndex--);
			returnCode =   (String) stmt.getObject(paramIndex--);
			rSet = (ResultSet) stmt.getObject(paramIndex);	
			oMap = DALUtil.rSetResults(rSet, tableName);
			oMap.put(RETURN_CODE, returnCode);
			oMap.put(RETURN_DATA, returnData);
		}
		catch (Exception e) {
			logger.error("BNSPR_YIM_BASVURU_RAPOR servisinde hata!");
			oMap.put(RETURN_CODE, STR_ZERO);
			oMap.put(RETURN_DATA, "Sorgulama Ba�ar�s�z.");
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	/**YIM sistemindeki mutabakat bilgisini tarih bilgisine gore alir.
	 * @param iMap
	 *  TARIH - Mutabakat bilgisi istenen tarih
	 * @return oMap
	 * 	RESPONSE - Sonuc kodu (0:Basarisiz, 1:Basarili)
	 * 	RESPONSE_DATA - Sonuc aciklamasi.
	 */
	@GraymoundService("BNSPR_GET_MUTABAKAT_FROM_YIM")
	public static GMMap getMutabakatFromYim(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try {
			oMap = GMServiceExecuter.call("BNSPR_YIM_MUTABAKAT_SORGULA", iMap);
			if(!AkustikConstants.RESPONSE_SUCCESS.equals(oMap.getString("RESPONSE"))){
				throw new GMRuntimeException(0, "YIM Mutabakat Servisinde Hata! : " + oMap.getString("RESPONSE_DATA"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**YIM && Aktifbank sistemindeki mutabakat bilgilerini doner.
	 * @param iMap
	 *  TARIH - Mutabakat bilgisi istenen tarih
	 * @return oMap
	 * 	RESPONSE - Sonuc kodu (0:Basarisiz, 1:Basarili)
	 * 	RESPONSE_DATA - Sonuc aciklamasi.
	 */
	@GraymoundService("BNSPR_GET_YIM_MUTABAKAT_INFO")
	public static GMMap getMutabakat(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap sMap= new GMMap();
		try {
			sMap=ConsumerLoanCommonServices.getParamTextLists("YIM_BASVURU_PARAMETRE", "PARAM_TABLE");
		}
		catch (SQLException e1) {
			logger.error(e1.getMessage());
			oMap.put("MESSAGE", "Parametre Servisinden Veri Al�namad�");
		}

		String tableName = "RESULT";
		HashMap<String, HashMap<String, Object>> reportMap = new HashMap<String, HashMap<String, Object>>();
	
		try {
			try {
				GMMap aktifMap = GMServiceExecuter.call("BNSPR_YIM_BASVURU_RAPOR", iMap);
				for(int i = 0; i < aktifMap.getSize("REPORT") ; i++){
					String status = aktifMap.getString("REPORT", i, "DURUM_KODU");
					String count = aktifMap.getString("REPORT", i, "ADET");
					BigDecimal amount = aktifMap.getBigDecimal("REPORT", i, "KUL_TUTAR");
					
					reportMap.put(status, new HashMap<String, Object>());
					reportMap.get(status).put("TOPLAM_ODEME_AKTIF", amount);
					reportMap.get(status).put("TOPLAM_ADET_AKTIF", count);
				}
			}
			catch (Exception e) {
				logger.error(e.getMessage());
				oMap.put("MESSAGE", "Aktifbank Mutabakat Servisinden Veri Al�namad�");
			}
			
			try {
				GMMap yimMap = GMServiceExecuter.call("BNSPR_GET_MUTABAKAT_FROM_YIM", iMap);
				for(int i = 0; i < yimMap.getSize("MUTABAKAT") ; i++){
					String status = yimMap.getString("MUTABAKAT", i, "ODEME_DURUM");
					BigDecimal amount = yimMap.getBigDecimal("MUTABAKAT", i, "TUTAR");
					BigDecimal count = yimMap.getBigDecimal("MUTABAKAT", i, "ADET");
					
					if(!reportMap.containsKey(status)){
						reportMap.put(status, new HashMap<String, Object>());
					}
					reportMap.get(status).put("TOPLAM_ODEME_YIM", amount);
					reportMap.get(status).put("TOPLAM_ADET_YIM", count);
				}
			}
			catch (Exception e) {
				logger.error(e.getMessage());
				oMap.put("MESSAGE", "Yim Mutabakat Servisinden Veri Al�namad�");
			}
			
			int oMapSize = 0;
			for(String s : reportMap.keySet()){
				//gnl_param_text tablosundaki key2 alan�ndan de�er al�n�r.
				 for (int i = 0; i < sMap.getSize("PARAM_TABLE"); i++) {
					 if(s.equals(sMap.getString("PARAM_TABLE", i, "DESCRIPTION"))){
						 oMap.put(tableName, oMapSize, "DURUM_KODU", sMap.getString("PARAM_TABLE", i, "KEY2"));
						 break;
					 }
				}
				
				oMap.put(tableName, oMapSize, "TOPLAM_ODEME_AKTIF", reportMap.get(s).get("TOPLAM_ODEME_AKTIF"));
				oMap.put(tableName, oMapSize, "TOPLAM_ADET_AKTIF", reportMap.get(s).get("TOPLAM_ADET_AKTIF"));
				oMap.put(tableName, oMapSize, "TOPLAM_ODEME_YIM", reportMap.get(s).get("TOPLAM_ODEME_YIM"));
				oMap.put(tableName, oMapSize++, "TOPLAM_ADET_YIM", reportMap.get(s).get("TOPLAM_ADET_YIM"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
}
