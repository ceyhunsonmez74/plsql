package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirTakiptenCanliyaTx;
import tr.com.aktifbank.bnspr.dao.BirTakiptenCanliyaTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN8080Services {

	@GraymoundService("BNSPR_TRN8080_IMPORT_EXCELL")
	public static GMMap load8080(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			byte[] inputFile = (byte[]) iMap.get("FILE");
			if (inputFile == null) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Dosya se�mediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Workbook workbook;
			WorkbookSettings ws = new WorkbookSettings();
			ws.setEncoding("ISO-8859-9");
			ws.setExcelDisplayLanguage("TR");
			ws.setExcelRegionalSettings("TR");
			ws.setLocale(new Locale("tr", "TR"));
			int colCount = 0;
			String colNames[] = null;
			try {
				workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
				colCount = workbook.getSheet(0).getColumns();
				if (colCount < 1) {
					throw new GMRuntimeException(0, "Yanl�� Kolon Say�s�.");
				}
				colNames = new String[colCount];
				for (int i = 0; i < colCount; i++) {
					String colName = workbook.getSheet(0).getCell(i, 0).getContents().trim();
					colNames[i] = colName;
				}
			}
			catch (Exception e) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Sheet sheet = workbook.getSheet(0);
			String tableName = "TAKIPTEN_TABLO";
			for (int j = 0; j + 1 < sheet.getRows(); j++) {
				
				BigDecimal basvuruNo = null;
				BigDecimal ytsBakiye = null;
				
				for (int i = 0; i < colCount; i++) {
					String val = sheet.getCell(i, (j + 1)).getContents().trim();
					String key = colNames[i];
					oMap.put(tableName, j, key, val);
					
					if (key.equals("BASVURU_NO")) {
						basvuruNo = new BigDecimal(val);
					}
					
					if (key.equals("YTS_BAKIYE")) {
						ytsBakiye = new BigDecimal(val);
					}
				}
				
				try {
					BigDecimal krediBakiye = getKalanAnapara(basvuruNo);
					
					if (krediBakiye.compareTo(ytsBakiye) == -1) {//ytsbakiye kredibakiyeden kucuk veya esit olmal�
						oMap.put(tableName, j, "DURUM", "H");
					} else {
						oMap.put(tableName, j, "DURUM", "E");
					}
					oMap.put(tableName, j, "KREDI_BAKIYE", krediBakiye);
				}
				catch (Exception e) {
					oMap.put(tableName, j, "KREDI_BAKIYE", 0);
					oMap.put(tableName, j, "DURUM", "H");
				}
				
				
			}
			if (oMap.getSize("TAKIPTEN_TABLO") == 0) {
				iMap.put("MESSAGE_NO", new java.math.BigDecimal(1614));
				String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
				throw new GMRuntimeException(0, message);
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8080_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "TAKIPTEN_TABLO";

			List<?> basvuruListe = (List<?>) iMap.get(tableName);
			if (basvuruListe.size() == 0) {
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			for (int i = 0; i < basvuruListe.size(); i++) {

				BigDecimal basvuruNo = iMap.getBigDecimal(tableName, i, "BASVURU_NO");
				String durum = iMap.getString(tableName, i, "DURUM");

				if (basvuruNo != null && durum.equals("E")) {
					BirTakiptenCanliyaTxId id = new BirTakiptenCanliyaTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setBasvuruNo(basvuruNo);

					BirTakiptenCanliyaTx tx = new BirTakiptenCanliyaTx();
					tx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					tx.setKrediHesabi(iMap.getBigDecimal(tableName, i, "KREDI_HESABI"));
					tx.setAlacHesap(iMap.getBigDecimal(tableName, i, "ALACAK_HESABI"));
					tx.setIslemSonucu("W");
					tx.setId(id);

					session.saveOrUpdate(tx);
				}
			}
			session.flush();

			iMap.put("TRX_NAME", "8080");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8080_TAKIPI_KAPA")
	public static GMMap takipiKapa(GMMap iMap) {

		Connection conn = null;
		GMMap oMap = new GMMap();
		CallableStatement stmtDt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			String tableName = "KAPATILACAK_TABLO";
	
			List<?> basvuruListe = (List<?>) iMap.get(tableName);
			if (basvuruListe.size() == 0) {
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
	
			for (int i = 0; i < basvuruListe.size(); i++) {
				BigDecimal basvuruNo = iMap.getBigDecimal(tableName, i, "BASVURU_NO");
				BigDecimal txNo = iMap.getBigDecimal(tableName, i, "TX_NO");
				BigDecimal vadesizBakiye = iMap.getBigDecimal(tableName, i, "VADESIZ_BAKIYE");
	
				if (basvuruNo != null && txNo != null ) {
					try {
						stmtDt = conn.prepareCall("{call BNSPR.PKG_TRN8080.Takip_Hesabi_Kapama(?, ?)}");
						stmtDt.setBigDecimal(1, basvuruNo);
						stmtDt.setBigDecimal(2, txNo);
						stmtDt.execute();
					}
					catch (Exception e) {
						oMap.put("RESPONSE", -1);
						oMap.put("RESPONSE_DATA", e.getMessage());
					}
				}
			}
			
			oMap.put("MESSAGE", "��leminiz tamamland�.");
		} catch (Exception e) {
			oMap.put("RESPONSE", -1);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		finally {
			GMServerDatasource.close(stmtDt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	private static BigDecimal getKalanAnapara(BigDecimal basvuruNo) {
		Connection conn = null;
		BigDecimal tutar = null;
		CallableStatement stmtDt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmtDt = conn.prepareCall("{? = call BNSPR.PKG_TRN8080.F_KALAN_ANAPARA(?) }");
			stmtDt.registerOutParameter(1, Types.DECIMAL);
			stmtDt.setBigDecimal(2, basvuruNo);
			stmtDt.execute();
			tutar = stmtDt.getBigDecimal(1);
		} catch (Exception e) {
			oMap.put("RESPONSE", -1);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		finally {
			GMServerDatasource.close(stmtDt);
			GMServerDatasource.close(conn);
		}
		return tutar;
	}
	
	@GraymoundService("BNSPR_TRN8080_KREDI_LISTE")
	public static GMMap gettakiptenKapaliListe(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Object[] objArray = new Object[0];
			return DALUtil.callOracleRefCursorFunction("{? = call BNSPR.PKG_TRN8080.F_TAKIPTEN_KAPANACAK_LISTE}", "KAPATILACAK_TABLO", objArray);
		} catch (Exception e) {
			oMap.put("RESPONSE", -1);
			oMap.put("RESPONSE_DATA", e.getMessage());
		}
		return iMap;
	}

}
