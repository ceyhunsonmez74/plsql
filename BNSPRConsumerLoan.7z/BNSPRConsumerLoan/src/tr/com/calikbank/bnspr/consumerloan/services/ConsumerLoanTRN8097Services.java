package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirNbsmMusteriFlag;
import tr.com.aktifbank.bnspr.dao.BirNbsmMusteriFlagTx;
import tr.com.aktifbank.bnspr.dao.BirNbsmMusteriFlagTxId;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN8097Services {

	public enum IslemTipi {
		YENI("Y", "Yeni Kay�t"), GUNCELLEME("G", "G�ncelleme"), SILME("S", "Silme"), DEGISIKLIK_YOK("D", "De�i�iklik Yok");

		private String kod;
		private String aciklama;

		public String getKod() {
			return kod;
		}

		public String getAciklama() {
			return aciklama;
		}

		public static IslemTipi tipBul(String kod) {
			if ("Y".equalsIgnoreCase(kod)) {
				return YENI;
			}
			else if ("G".equalsIgnoreCase(kod)) {
				return GUNCELLEME;
			}
			else if ("S".equalsIgnoreCase(kod)) {
				return SILME;
			}

			return null;
		}

		private IslemTipi(String kod, String aciklama) {
			this.kod = kod;
			this.aciklama = aciklama;
		}

	}

	@GraymoundService("BNSPR_TRN8097_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		List<BirNbsmMusteriFlag> liste = session.createCriteria(BirNbsmMusteriFlag.class).add(Restrictions.ge("bitisTarihi", DateUtils.truncate(new Date(), Calendar.DATE))).add(Restrictions.isNull("basvuruNo")).list();

		String tableName = "FLAG_TABLO";

		for (int row = 0; row < liste.size(); row++) {
			oMap.put(tableName, row, "BITIS_TARIHI", liste.get(row).getBitisTarihi());
			oMap.put(tableName, row, "KANAL_KOD", liste.get(row).getKanalKod());
			oMap.put(tableName, row, "KAYIT_TARIHI", liste.get(row).getKayitTarihi());
			oMap.put(tableName, row, "ONAY_TUTAR", liste.get(row).getOnayTutar());
			oMap.put(tableName, row, "TC_KIMLIK_NO", liste.get(row).getTcKimlikNo());
			oMap.put(tableName, row, "FLAG_NO", liste.get(row).getFlagNo());
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8097_TARIHCE")
	public static GMMap tarihce(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		List<BirNbsmMusteriFlagTx> liste = session.createCriteria(BirNbsmMusteriFlagTx.class).addOrder(Order.desc("bitisTarihi")).list();

		String tableName = "FLAG_TABLO";

		for (int row = 0; row < liste.size(); row++) {
			oMap.put(tableName, row, "BITIS_TARIHI", liste.get(row).getBitisTarihi());
			oMap.put(tableName, row, "KANAL_KOD", liste.get(row).getId().getKanalKod());
			oMap.put(tableName, row, "KAYIT_TARIHI", liste.get(row).getKayitTarihi());
			oMap.put(tableName, row, "ONAY_TUTAR", liste.get(row).getOnayTutar());
			oMap.put(tableName, row, "REC_OWNER", liste.get(row).getRecOwner());
			oMap.put(tableName, row, "TC_KIMLIK_NO", liste.get(row).getId().getTcKimlikNo());
			oMap.put(tableName, row, "ISLEM_TIPI", IslemTipi.tipBul(liste.get(row).getIslemTipi()).getAciklama());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN8097_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		List<BirNbsmMusteriFlagTx> liste = session.createCriteria(BirNbsmMusteriFlagTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

		String tableName = "FLAG_TABLO";

		for (int row = 0; row < liste.size(); row++) {
			oMap.put(tableName, row, "BITIS_TARIHI", liste.get(row).getBitisTarihi());
			oMap.put(tableName, row, "KANAL_KOD", liste.get(row).getId().getKanalKod());
			oMap.put(tableName, row, "KAYIT_TARIHI", liste.get(row).getKayitTarihi());
			oMap.put(tableName, row, "ONAY_TUTAR", liste.get(row).getOnayTutar());
			oMap.put(tableName, row, "TC_KIMLIK_NO", liste.get(row).getId().getTcKimlikNo());
			oMap.put(tableName, row, "ISLEM_TIPI", IslemTipi.tipBul(liste.get(row).getIslemTipi()).getAciklama());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN8097_DELETE_RECORD")
	public static GMMap deleteRecord(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap rowMap = iMap.getMap("ROW");

		Session session = DAOSession.getSession("BNSPRDal");

		// Yeni kay�tsa i�lem yap�lmamal�
		if (!"Y".equalsIgnoreCase(rowMap.getString("ISLEM_TIPI"))) {

			BirNbsmMusteriFlagTx tx = new BirNbsmMusteriFlagTx();
			BirNbsmMusteriFlagTxId id = new BirNbsmMusteriFlagTxId();

			id.setTcKimlikNo(rowMap.getString("TC_KIMLIK_NO"));
			id.setKanalKod(rowMap.getBigDecimal("KANAL_KOD"));
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			try {
				tx.setBitisTarihi(rowMap.getDate("BITIS_TARIHI"));
				tx.setKayitTarihi(rowMap.getDate("KAYIT_TARIHI"));
			}
			catch (ParseException e) {
				e.printStackTrace();
			}
			
			tx.setOnayTutar(rowMap.getBigDecimal("ONAY_TUTAR"));
			tx.setFlagNo(rowMap.getBigDecimal("FLAG_NO"));
			tx.setIslemTipi(IslemTipi.SILME.getKod());
			tx.setRecOwner(ADCSession.getString("USER_NAME"));

			tx.setId(id);
			session.save(tx);
			session.flush();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN8097_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		String tableName = "FLAG_TABLO";

		for (int row = 0; row < iMap.getSize(tableName); row++) {
			if (iMap.getString(tableName, row, "ISLEM_TIPI") != null) {
				BirNbsmMusteriFlagTx tx = new BirNbsmMusteriFlagTx();

				BirNbsmMusteriFlagTxId id = new BirNbsmMusteriFlagTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				
				id.setTcKimlikNo(iMap.getString(tableName, row, "TC_KIMLIK_NO"));
				id.setKanalKod(iMap.getBigDecimal(tableName, row, "KANAL_KOD"));

				tx.setId(id);

				try {
					tx.setBitisTarihi(iMap.getDate(tableName, row, "BITIS_TARIHI"));
					tx.setKayitTarihi(iMap.getDate(tableName, row, "KAYIT_TARIHI"));
				}
				catch (ParseException e) {
					iMap.put("HATA_NO", new BigDecimal(1393));
					throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap).get("ERROR_MESSAGE"));
				}

				tx.setIslemTipi(iMap.getString(tableName, row, "ISLEM_TIPI"));
				tx.setOnayTutar(iMap.getBigDecimal(tableName, row, "ONAY_TUTAR"));
				tx.setFlagNo(iMap.getBigDecimal(tableName, row, "FLAG_NO"));
				tx.setRecOwner(ADCSession.getString("USER_NAME"));

				session.save(tx);
				session.flush();
			}
		}

		iMap.put("TRX_NAME", "8097");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		return oMap;

	}

}
