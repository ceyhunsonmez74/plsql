package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiBasvuru;
import tr.com.aktifbank.bnspr.dao.BirSaticiBasvuruDetayTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiBasvuruTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiTanim;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8061Services {

	private static final String KAZANIM_KANALI = "1";

	@GraymoundService("BNSPR_TRN8061_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			iMap.put("ADD_EMPTY_KEY", "");
			iMap.put("KOD", "SATICI_TIP_KOD");
			oMap.put("SATICI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAGLI_OLD_BOLGE_KOD");
			oMap.put("BAGLI_OLDUGU_BOLGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			// Bayi sorumlu kisi combobox i service ile doldurulacak

			// Portfoy kodu lov ile doluyor

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "ISYERI_FAAL_KONU_KOD");
			oMap.put("FAALIYET_KONUSU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "FIRMA_TIPI");
			oMap.put("SIRKET_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_ILISKI_TIPI");
			iMap.put("ADD_EMPTY_KEY", "");
			iMap.put("TABLE_NAME", "BAYI_ILISKI_TIPI");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN8061_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			BirSaticiBasvuruTx birSaticiBasvuruTx;

			if (basvuruNo != null) {
				List<BirSaticiBasvuruTx> list = (List<BirSaticiBasvuruTx>) session.createCriteria(BirSaticiBasvuruTx.class).add(Restrictions.eq("basvuruNo", basvuruNo)).addOrder(Order.desc("txNo")).list();

				if (list != null && list.size() > 0) {
					trxNo = list.get(0).getTxNo();
				}
			}

			birSaticiBasvuruTx = (BirSaticiBasvuruTx) session.createCriteria(BirSaticiBasvuruTx.class).add(Restrictions.eq("txNo", trxNo)).uniqueResult();

			oMap.put("BASVURU_NO", birSaticiBasvuruTx.getBasvuruNo());
			oMap.put("AGENT_ADI", birSaticiBasvuruTx.getAgentAdi());
			oMap.put("SATICI_TIPI", birSaticiBasvuruTx.getSaticiTipi());
			oMap.put("BAGLI_OLDUGU_BOLGE", birSaticiBasvuruTx.getBagliOlduguBolge());
			oMap.put("BAYI_SORUMLU_KISI", birSaticiBasvuruTx.getBayiSorumluKisi());
			oMap.put("PORTFOY_KOD", birSaticiBasvuruTx.getPortfoyKod());
			oMap.put("FAALIYET_KONUSU", birSaticiBasvuruTx.getFaaliyetKonusu());
			oMap.put("SIRKET_TIPI", birSaticiBasvuruTx.getSirketTipi());

			String sirketTipi = birSaticiBasvuruTx.getSirketTipi();
			if (sirketTipi != null)
				sirketTipi = sirketTipi.equals("7") ? "1" : "4";

			// Burda duzenleme yapicaz
			if (sirketTipi == "1") // tckn
			{
				oMap.put("TCKN_VERGINO", birSaticiBasvuruTx.getTckn());
				oMap.put("lblVERGINO_TCKN", "TCKN");
			}
			else {
				oMap.put("TCKN_VERGINO", birSaticiBasvuruTx.getVergiNo());
				oMap.put("lblVERGINO_TCKN", "VKN");
			}

			oMap.put("VERGI_DAIRESI_IL", birSaticiBasvuruTx.getVergiDairesiIl());
			oMap.put("VERGI_DAIRESI_ADI", birSaticiBasvuruTx.getVergiDairesiAdi());
			oMap.put("KURULUS_TARIHI", birSaticiBasvuruTx.getKurulusTarihi());
			oMap.put("ADRES", birSaticiBasvuruTx.getAdres());
			oMap.put("ADRES_IL_KOD", birSaticiBasvuruTx.getAdresIlKod());
			oMap.put("ADRES_ILCE_KOD", birSaticiBasvuruTx.getAdresIlceKod());
			oMap.put("TEL_KOD", birSaticiBasvuruTx.getTelefonKod());
			oMap.put("TEL_NO", birSaticiBasvuruTx.getTelefonNo());
			oMap.put("FAKS_KOD", birSaticiBasvuruTx.getFaksKod());
			oMap.put("FAKS_NO", birSaticiBasvuruTx.getFaksNo());
			String email = birSaticiBasvuruTx.getEmail();

			if (email != null) {
				String[] arr = email.split("@");
				if (arr.length == 2) {
					oMap.put("E_POSTA_NAME", arr[0]);
					oMap.put("E_POSTA_NET", arr[1]);
				}
			}

			oMap.put("WEB_ADRESI", birSaticiBasvuruTx.getWebAdresi());
			oMap.put("CREDIT", GuimlUtil.convertToCheckBoxSelected(birSaticiBasvuruTx.getCredit()));
			oMap.put("UPT", GuimlUtil.convertToCheckBoxSelected(birSaticiBasvuruTx.getUpt()));
			oMap.put("SIGORTA", GuimlUtil.convertToCheckBoxSelected(birSaticiBasvuruTx.getSigorta()));
			oMap.put("MUSTERI_NO", birSaticiBasvuruTx.getMusteriNo());

			List<BirSaticiBasvuruDetayTx> birSaticiBasvuruDetayTxList = session.createCriteria(BirSaticiBasvuruDetayTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();

			birSaticiBasvuruDetayTxList = session.createCriteria(BirSaticiBasvuruDetayTx.class).add(Restrictions.eq("txNo", trxNo)).list();

			String tn = "ILISKILI_KISILER";
			int i = 0;

			for (BirSaticiBasvuruDetayTx birSaticiBasvuruDetayTx : birSaticiBasvuruDetayTxList) {
				oMap.put(tn, i, "TCKN", birSaticiBasvuruDetayTx.getTckn());
				oMap.put(tn, i, "ADI", birSaticiBasvuruDetayTx.getAd());
				oMap.put(tn, i, "IKINCI_ADI", birSaticiBasvuruDetayTx.getIkinciAd());
				oMap.put(tn, i, "SOYADI", birSaticiBasvuruDetayTx.getSoyad());
				oMap.put(tn, i, "CEP_KOD", birSaticiBasvuruDetayTx.getCepTelefonKod());
				oMap.put(tn, i, "CEP_NO", birSaticiBasvuruDetayTx.getCepTelefonNo());
				oMap.put(tn, i, "ILISKI_TIPI", birSaticiBasvuruDetayTx.getIliskiTipi());
				oMap.put(tn, i, "ORTAKLIK_PAYI", birSaticiBasvuruDetayTx.getOrtaklikPayi());
				i++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN8061_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirSaticiBasvuruTx birSaticiBasvuruTx = (BirSaticiBasvuruTx) session.get(BirSaticiBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birSaticiBasvuruTx != null)
				session.delete(birSaticiBasvuruTx);
			session.flush();

			String kanalKod = iMap.containsKey("KANAL_KOD") ? iMap.getString("KANAL_KOD") : GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", (GMMap) null).getString("KANAL_KOD");

			birSaticiBasvuruTx = new BirSaticiBasvuruTx(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("BASVURU_NO"));
			birSaticiBasvuruTx.setKanalKodu(kanalKod);

			// her durumda TCKN atilmali 3271 de VKN de burdan okunuyor
			iMap.put("TCKN", iMap.getString("TCKN"));
			// TCKNO 10 haneli bile olsa KPS tarafinda kullaniliyor ,VKN_STATE i belirlemek icin ???? YA DA YEN� B�R DEG�SKEN �LE O TARAF� BURDAN KONTROL EDEBILIRIZ
			if (iMap.getString("TCKN").length() == 11) {
				iMap.put("TCKN", iMap.getString("TCKN"));
			}
			else if (iMap.getString("TCKN").length() < 11) {
				iMap.put("VKN", iMap.getString("TCKN"));
				iMap.put("IS_VIA_TCKN", false);
				iMap.put("customer_out", true);
			}

			iMap.put("TCKNO", iMap.getString("TCKN"));

			String sirketTipi = "1";
			if (iMap.getString("SIRKET_TIPI") != null)
				sirketTipi = iMap.getString("SIRKET_TIPI").equals("7") ? "4" : "1";

			// Bunlar create contact icersinde kullanilan degiskenler
			iMap.put("PROFIL_KODU", sirketTipi);
			iMap.put("ADRES_TIP", "I");
			iMap.put("ADRES_IL", iMap.getString("ADRES_IL_KOD"));
			iMap.put("IL", iMap.getString("ADRES_IL_KOD"));
			iMap.put("ADRES_ILCE", iMap.getString("ADRES_ILCE_KOD"));
			iMap.put("ILCE", iMap.getString("ADRES_ILCE_KOD"));

			iMap.put("TEL_TIP", iMap.getString("TEL_KOD") == null ? null : "2");
			iMap.put("KANAL_KOD", KAZANIM_KANALI);
			iMap.put("BAYI_ADI", iMap.getString("AGENT_ADI"));

			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3271_CREATE_CONTACT", iMap));

			birSaticiBasvuruTx.setAgentAdi(iMap.getString("AGENT_ADI"));
			birSaticiBasvuruTx.setSaticiTipi(iMap.getString("SATICI_TIPI"));
			birSaticiBasvuruTx.setBagliOlduguBolge(iMap.getString("BAGLI_OLDUGU_BOLGE"));
			birSaticiBasvuruTx.setBayiSorumluKisi(iMap.getString("BAYI_SORUMLU_KISI"));
			birSaticiBasvuruTx.setPortfoyKod(iMap.getString("PORTFOY_KOD"));
			birSaticiBasvuruTx.setFaaliyetKonusu(iMap.getString("FAALIYET_KONUSU"));
			birSaticiBasvuruTx.setSirketTipi(iMap.getString("SIRKET_TIPI"));
			birSaticiBasvuruTx.setVergiNo(iMap.getString("TCKN").length() < 11 ? iMap.getString("TCKN") : null);
			birSaticiBasvuruTx.setTckn(iMap.getString("TCKN").length() == 11 ? iMap.getString("TCKN") : null);
			birSaticiBasvuruTx.setVergiDairesiIl(iMap.getString("VERGI_DAIRESI_IL"));
			birSaticiBasvuruTx.setVergiDairesiAdi(iMap.getString("VERGI_DAIRESI_ADI"));
			birSaticiBasvuruTx.setKurulusTarihi(iMap.getDate("KURULUS_TARIHI"));
			birSaticiBasvuruTx.setAdres(iMap.getString("ADRES"));
			birSaticiBasvuruTx.setAdresIlKod(iMap.getString("ADRES_IL_KOD"));
			birSaticiBasvuruTx.setAdresIlceKod(iMap.getString("ADRES_ILCE_KOD"));
			birSaticiBasvuruTx.setTelefonKod(iMap.getString("TEL_KOD"));
			birSaticiBasvuruTx.setTelefonNo(iMap.getString("TEL_NO"));
			birSaticiBasvuruTx.setFaksKod(iMap.getString("FAKS_KOD"));
			birSaticiBasvuruTx.setFaksNo(iMap.getString("FAKS_NO"));
			birSaticiBasvuruTx.setEmail(iMap.getString("E_POSTA_NAME") + "@" + iMap.getString("E_POSTA_NET"));
			birSaticiBasvuruTx.setCredit(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("CREDIT")));
			birSaticiBasvuruTx.setUpt(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("UPT")));
			birSaticiBasvuruTx.setSigorta(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("SIGORTA")));
			birSaticiBasvuruTx.setMusteriNo(oMap.getBigDecimal("MUSTERI_NO"));
			birSaticiBasvuruTx.setDurum("ISTIHBARAT");
			// birSaticiBasvuruTx.setMusteriYaratTxNo(oMap.getBigDecimal("MUSTERI_YARAT_TX_NO"));
			// bayiBasvuruTx.setHesapNo(null);

			session.save(birSaticiBasvuruTx);
			session.flush();

			String tn = "ILISKILI_KISILER";
			int size = iMap.getSize(tn);

			//
			GMMap sMap;
			BirSaticiBasvuruDetayTx birSaticiBasvuruDetayTx;

			// Iliskili kisiler
			for (int i = 0; i < size; i++) {
				sMap = new GMMap();
				sMap.put("TRX_NO", iMap.getString("TRX_NO"));
				sMap.put("TCKN", iMap.getString(tn, i, "TCKN"));
				sMap.put("TCKNO", iMap.getString(tn, i, "TCKN"));
				sMap.put("PROFIL_KODU", "1");
				sMap.put("KANAL_KOD", KAZANIM_KANALI);
				sMap.put("ADRES_TIP", (String) null);
				sMap.put("TEL_TIP", iMap.getString(tn, i, "CEP_KOD") == null ? null : "3");

				sMap.put("TEL_KOD", iMap.getString(tn, i, "CEP_KOD"));
				sMap.put("TEL_NO", iMap.getString(tn, i, "CEP_NO"));

				// tckn = iMap.getString("TCKN");
				// ykn = iMap.getString("YKN");
				// vkn = iMap.getString("VKN");

				sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3271_CREATE_CONTACT", sMap));

				BigDecimal iliskiNo = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "BIR_SATICI_BASVURU_DETAY")).getBigDecimal("ID");

				birSaticiBasvuruDetayTx = new BirSaticiBasvuruDetayTx(iMap.getBigDecimal("TRX_NO"), iliskiNo, iMap.getBigDecimal("BASVURU_NO"));
				birSaticiBasvuruDetayTx.setTckn(iMap.getString(tn, i, "TCKN"));
				birSaticiBasvuruDetayTx.setAd(iMap.getString(tn, i, "ADI"));
				birSaticiBasvuruDetayTx.setIkinciAd(iMap.getString(tn, i, "IKINCI_ADI"));
				birSaticiBasvuruDetayTx.setSoyad(iMap.getString(tn, i, "SOYADI"));
				birSaticiBasvuruDetayTx.setIliskiTipi(iMap.getString(tn, i, "ILISKI_TIPI"));
				birSaticiBasvuruDetayTx.setCepTelefonKod(iMap.getString(tn, i, "CEP_KOD"));
				birSaticiBasvuruDetayTx.setCepTelefonNo(iMap.getString(tn, i, "CEP_NO"));
				birSaticiBasvuruDetayTx.setMusteriNo(sMap.getBigDecimal("MUSTERI_NO"));
				// bayiBasvuruOrtakTx.setMusteriYaratTxNo(sMap.getBigDecimal("MUSTERI_YARAT_TX_NO"));
				birSaticiBasvuruDetayTx.setOrtaklikPayi(iMap.getBigDecimal(tn, i, "ORTAKLIK_PAYI"));

				session.save(birSaticiBasvuruDetayTx);
				session.flush();
			}

			session.flush();

			iMap.put("TRX_NAME", "8061");

			/*
			if ( !KARALISTE_KKB_CAPRAZ_CEK_SENET_SORGULA( iMap.getBigDecimal("BASVURU_NO")))
			{
				iMap.put("MESSAGE_NO", new BigDecimal(5659));
				return null;
			}*/

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN8061_REPLACE_UPPER_CHARS")
	public static GMMap replaceUpperChars(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			String agent_adi = iMap.getString("AGENT_ADI");
			agent_adi = agent_adi.toUpperCase();
			/*marka_kod = marka_kod.replace('�', 'I');
			marka_kod = marka_kod.replace('�', 'C');
			marka_kod = marka_kod.replace('�', 'S');
			marka_kod = marka_kod.replace('�', 'O');
			marka_kod = marka_kod.replace('�', 'G');
			marka_kod = marka_kod.replace('�', 'U');*/
			// marka_kod = marka_kod.replace('.', '');
			// marka_kod = marka_kod.replace('-', null);
			// marka_kod = marka_kod.replace('/', null);
			// marka_kod = marka_kod.replace(' ', null);

			oMap.put("AGENT_ADI", agent_adi);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_GET_BAYI_BASVURU_SONUC")
	public static GMMap getBayiBasvuruSonuc(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		ResultSet rSet = null;
		ResultSet rSetKKB = null;

		try {

			// BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			BigDecimal saticiKod = iMap.getBigDecimal("SATICI_KODU");
			String agentType = iMap.getString("AGENT_TYPE");

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_BAYI_BASVURU.satici_durum(? ,?)}");

			int parameterIndex = 1;
			stmt.registerOutParameter(parameterIndex++, Types.VARCHAR);
			stmt.setBigDecimal(parameterIndex++, saticiKod);
			stmt.setString(parameterIndex++, agentType);

			stmt.execute();

			String durum_kodu = stmt.getString(1);

			GMMap bMap = new GMMap();

			bMap.put("DURUM", durum_kodu);

			// oMap.put("MESSAGE", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", bMap).getString("ERROR_MESSAGE"));

			return bMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSetKKB);

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}

	@GraymoundService("BNSPR_GET_SATICI_NAME")
	public static GMMap getSaticiName(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		ResultSet rSet = null;
		ResultSet rSetSatici = null;

		try {

			BigDecimal saticiKod = iMap.getBigDecimal("SATICI_KODU");

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_BAYI_BASVURU.get_satici_name(?)}");

			int parameterIndex = 1;
			stmt.registerOutParameter(parameterIndex++, Types.VARCHAR);
			stmt.setBigDecimal(parameterIndex++, saticiKod);

			stmt.execute();

			String saticiName = stmt.getString(1);

			GMMap bMap = new GMMap();

			bMap.put("NAME", saticiName);

			return bMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSetSatici);

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}

	@GraymoundService("BNSPR_EXECUTE_BIR_SATICI_SORGULAR")
	public static GMMap executeBirSaticiSorgular(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt3 = null;
		CallableStatement stmt4 = null;

		ResultSet rSet = null;
		ResultSet rSetKKB = null;

		try {

			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			conn = DALUtil.getGMConnection();
			// stmt = conn.prepareCall("{? = call PKG_BAYI_BASVURU.bir_satici_istihbarat_sorgu(?)}");

			// burda KKB sorgusunu unutmusuz 1.sorgudan sonra KKB ye insert lazim
			stmt = conn.prepareCall("{? = call PKG_BAYI_BASVURU.bayi_istihbarat_sorgu_1_bs(?)}");

			int parameterIndex = 1;
			stmt.registerOutParameter(parameterIndex++, Types.VARCHAR);
			stmt.setBigDecimal(parameterIndex++, basvuruNo);
			stmt.execute();

			String sorgu_sonuc = stmt.getString(1);

			GMMap bMap = new GMMap();

			if (sorgu_sonuc.equals("RED")) {
				bMap.put("MESSAGE_NO", new BigDecimal(5659));
			}
			else if (sorgu_sonuc.equals("KABUL"))
				bMap.put("MESSAGE_NO", new BigDecimal(5661));
			else
				bMap.put("MESSAGE_NO", new BigDecimal(5662));

			// KKB eklemesi yapiyoruz ,basvuru no yu verip ,sorgu_no yu alicaz ve insert etmis olucaz KKB tablosuna
			parameterIndex = 1;
			stmt3 = conn.prepareCall("{? = call PKG_BAYI_BASVURU.sorgusu_yapilmamis_kkbler_bs(?)}");

			stmt3.registerOutParameter(parameterIndex++, -10);
			stmt3.setBigDecimal(parameterIndex++, basvuruNo);
			stmt3.execute();
			rSetKKB = (ResultSet) stmt3.getObject(1);

			int mapIndex = 0;
			String tableName = "KKB_SORGU_LIST";
			GMMap kkbSorguMap = new GMMap();
			while (rSetKKB.next()) {
				kkbSorguMap.put(tableName, mapIndex, "SORGU_ID", rSetKKB.getBigDecimal("KKB_SORGU_NO"));
				mapIndex++;
			}
			if (kkbSorguMap.getSize(tableName) > 0) {
				GMServiceExecuter.executeNT("ADD_KKB_TEST", kkbSorguMap);
			}

			// tekrar sorgu
			stmt4 = conn.prepareCall("{? = call PKG_BAYI_BASVURU.bayi_istihbarat_sorgu_2_bs(?)}");

			parameterIndex = 1;
			stmt4.registerOutParameter(parameterIndex++, Types.VARCHAR);
			stmt4.setBigDecimal(parameterIndex++, basvuruNo);
			stmt4.execute();

			sorgu_sonuc = stmt4.getString(1);

			if (sorgu_sonuc.equals("RED")) {
				bMap.put("MESSAGE_NO", new BigDecimal(5659));
			}
			else if (sorgu_sonuc.equals("KABUL"))
				bMap.put("MESSAGE_NO", new BigDecimal(5661));
			else
				bMap.put("MESSAGE_NO", new BigDecimal(5662));

			oMap.put("MESSAGE", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", bMap).getString("ERROR_MESSAGE"));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSetKKB);
			GMServerDatasource.close(stmt4);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}

	@GraymoundService("BNSPR_BIR_SATICI_KULLANIDIRIM_JOB")
	public static GMMap bireyselBasvurudanSaticiyaConversion(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetSaticilar = null;
		Session session = DAOSession.getSession("BNSPRDal");

		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_BAYI_BASVURU.get_satici_records(?)}");

			int parameterIndex = 1;
			stmt.registerOutParameter(parameterIndex++, -10);
			stmt.setString(parameterIndex++, "ONAYLI");
			stmt.execute();

			rSetSaticilar = (ResultSet) stmt.getObject(1);

			BigDecimal saticiKod = null;

			while (rSetSaticilar.next()) {
				try {

					BirSaticiTanim tanim = (BirSaticiTanim) session.createCriteria(BirSaticiTanim.class).add(Restrictions.eq("musteriNo", rSetSaticilar.getBigDecimal("MUSTERI_NO"))).uniqueResult();

					if (tanim == null) {
						tanim = new BirSaticiTanim();
						GMMap tMap = new GMMap();

						tMap.put("TABLE_NAME", "BIR_SATICI_TANIM");
						saticiKod = (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", tMap).get("ID");
						tanim.setKod(saticiKod);
					}

					if (!"E".equalsIgnoreCase(tanim.getCredit())) {
						tanim.setCredit(rSetSaticilar.getString("CREDIT"));
					}
					tanim.setDurum("G");
					tanim.setSaticiAdi(rSetSaticilar.getString("AGENT_ADI"));
					if (!"E".equalsIgnoreCase(tanim.getSigorta())) {
						tanim.setSigorta(rSetSaticilar.getString("SIGORTA"));
					}
					tanim.setTckn(rSetSaticilar.getString("TCKN"));
					if (!"E".equalsIgnoreCase(tanim.getUpt())) {
						tanim.setUpt(rSetSaticilar.getString("UPT"));
					}
					tanim.setVergiNo(rSetSaticilar.getString("VERGI_NO"));
					tanim.setMusteriNo(rSetSaticilar.getBigDecimal("MUSTERI_NO"));

					session.saveOrUpdate(tanim);

					BirSaticiBasvuru basvuru = (BirSaticiBasvuru) session.createCriteria(BirSaticiBasvuru.class).add(Restrictions.eq("basvuruNo", rSetSaticilar.getBigDecimal("BASVURU_NO"))).uniqueResult();
					basvuru.setDurum("TANIMLANDI");
					session.saveOrUpdate(basvuru);
					session.flush();

				}
				catch (Exception e) {
					throw ExceptionHandler.convertException(e);
				}
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(rSetSaticilar);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}
}
