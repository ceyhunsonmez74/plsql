package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKampanyaSegment;
import tr.com.aktifbank.bnspr.dao.BirKampanyaSegmentTx;
import tr.com.aktifbank.bnspr.dao.BirKampanyaSegmentTxId;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3113Services {

	public enum IslemTipi {
		YENI("Y", "Yeni Kay�t"), GUNCELLEME("G", "G�ncelleme"), SILME("S", "Silme"), DEGISIKLIK_YOK("D", "De�i�iklik Yok");

		private String kod;
		private String aciklama;

		public String getKod() {
			return kod;
		}

		public String getAciklama() {
			return aciklama;
		}

		public static IslemTipi tipBul(String kod) {
			if ("Y".equalsIgnoreCase(kod)) {
				return YENI;
			}
			else if ("G".equalsIgnoreCase(kod)) {
				return GUNCELLEME;
			}
			else if ("S".equalsIgnoreCase(kod)) {
				return SILME;
			}

			return null;
		}

		private IslemTipi(String kod, String aciklama) {
			this.kod = kod;
			this.aciklama = aciklama;
		}

	}

	@GraymoundService("BNSPR_3113_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("KOD", "SEGMENT_KREDI_TURU");
		oMap.put("SEGMENT_KREDI_TURLERI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

		String tableName = "TUTAR_TIP";
		GuimlUtil.wrapMyCombo(oMap, tableName, null, " ");
		GuimlUtil.wrapMyCombo(oMap, tableName, "S", "Standart");
		GuimlUtil.wrapMyCombo(oMap, tableName, "O", "Onaylanan Tutar");

		tableName = "VADE_TIP";
		GuimlUtil.wrapMyCombo(oMap, tableName, null, " ");
		GuimlUtil.wrapMyCombo(oMap, tableName, "S", "Standart");
		GuimlUtil.wrapMyCombo(oMap, tableName, "O", "Talep edilen vade");

		tableName = "VADE_TUR";
		GuimlUtil.wrapMyCombo(oMap, tableName, null, " ");
		GuimlUtil.wrapMyCombo(oMap, tableName, "A", "AY");
		GuimlUtil.wrapMyCombo(oMap, tableName, "G", "G�N");

		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3178_GET_KANAL_LIST", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3113_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		List<BirKampanyaSegment> liste = session.createCriteria(BirKampanyaSegment.class).list();

		String tableName = "SEGMENT_TABLO";

		for (int row = 0; row < liste.size(); row++) {
			oMap.put(tableName, row, "SEGMENT", liste.get(row).getId().getSegment());
			oMap.put(tableName, row, "SEGMENT_ALT_KOD", liste.get(row).getId().getSegmentAltKod());
			oMap.put(tableName, row, "KAMPANYA_KOD", liste.get(row).getId().getKampanyaKod());
			oMap.put(tableName, row, "SIGORTALI_KAMP_KOD", liste.get(row).getSigortaliKampKod());
			oMap.put(tableName, row, "KREDI_TURU", liste.get(row).getId().getKrediTuru());
			oMap.put(tableName, row, "TUTAR_TIP", liste.get(row).getTutarTip());
			oMap.put(tableName, row, "TUTAR", liste.get(row).getTutar());
			oMap.put(tableName, row, "VADE_TIP", liste.get(row).getVadeTip());
			oMap.put(tableName, row, "VADE", liste.get(row).getVade());
			oMap.put(tableName, row, "VADE_TUR", liste.get(row).getVadeTur());
			oMap.put(tableName, row, "ISLEM_TIPI", IslemTipi.DEGISIKLIK_YOK.getKod());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3113_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		List<BirKampanyaSegmentTx> liste = session.createCriteria(BirKampanyaSegmentTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

		String tableName = "SEGMENT_TABLO";

		for (int row = 0; row < liste.size(); row++) {
			oMap.put(tableName, row, "SEGMENT", liste.get(row).getId().getSegment());
			oMap.put(tableName, row, "SEGMENT_ALT_KOD", liste.get(row).getId().getSegmentAltKod());
			oMap.put(tableName, row, "KAMPANYA_KOD", liste.get(row).getId().getKampanyaKod());
			oMap.put(tableName, row, "SIGORTALI_KAMP_KOD", liste.get(row).getSigortaliKampKod());
			oMap.put(tableName, row, "KREDI_TURU", liste.get(row).getId().getKrediTuru());
			oMap.put(tableName, row, "TUTAR_TIP", liste.get(row).getTutarTip());
			oMap.put(tableName, row, "TUTAR", liste.get(row).getTutar());
			oMap.put(tableName, row, "VADE_TIP", liste.get(row).getVadeTip());
			oMap.put(tableName, row, "VADE", liste.get(row).getVade());
			oMap.put(tableName, row, "VADE_TUR", liste.get(row).getVadeTur());
			oMap.put(tableName, row, "ISLEM_TIP", IslemTipi.tipBul(liste.get(row).getId().getIslemTip()).getAciklama());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3113_DELETE_RECORD")
	public static GMMap deleteRecord(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap rowMap = iMap.getMap("ROW");

		Session session = DAOSession.getSession("BNSPRDal");

		// Yeni kay�tsa i�lem yap�lmamal�
		if (rowMap.getString("ISLEM_TIPI") != null) {

			BirKampanyaSegmentTx tx = new BirKampanyaSegmentTx();

			BirKampanyaSegmentTxId id = new BirKampanyaSegmentTxId();
			id.setTxNo(iMap.getBigDecimal("TX_NO"));
			id.setSegment(rowMap.getString("SEGMENT"));
			id.setSegmentAltKod(rowMap.getString("SEGMENT_ALT_KOD"));
			id.setIslemTip(IslemTipi.SILME.getKod());
			id.setKrediTuru(rowMap.getString("KREDI_TURU"));
			id.setKampanyaKod(rowMap.getBigDecimal("KAMPANYA_KOD"));
			tx.setId(id);

			tx.setTutar(rowMap.getBigDecimal("TUTAR"));
			tx.setTutarTip(rowMap.getString("TUTAR_TIP"));
			tx.setVade(rowMap.getBigDecimal("VADE"));
			tx.setVadeTip(rowMap.getString("VADE_TIP"));
			tx.setVadeTur(rowMap.getString("VADE_TUR"));
			tx.setSigortaliKampKod(rowMap.getBigDecimal("SIGORTALI_KAMP_KOD"));

			session.save(tx);
			session.flush();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3113_UPDATE_RECORD")
	public static GMMap updateRecord(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap rowMap = iMap.getMap("ROW");

		Session session = DAOSession.getSession("BNSPRDal");

		// Yeni kay�tsa i�lem yap�lmamal�
		if (rowMap.getString("ISLEM_TIPI") != null) {

			BirKampanyaSegmentTx tx = (BirKampanyaSegmentTx) session.createCriteria(BirKampanyaSegmentTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TX_NO"))).add(Restrictions.eq("id.segment", iMap.getString("SEGMENT"))).add(Restrictions.eq("id.segmentAltKod", iMap.getString("SEGMENT_ALT_KOD"))).uniqueResult();

			if (tx == null) {
				tx = new BirKampanyaSegmentTx();
			}

			BirKampanyaSegmentTxId id = new BirKampanyaSegmentTxId();
			id.setTxNo(iMap.getBigDecimal("TX_NO"));
			id.setSegment(rowMap.getString("SEGMENT"));
			id.setSegmentAltKod(rowMap.getString("SEGMENT_ALT_KOD"));
			id.setIslemTip(IslemTipi.GUNCELLEME.getKod());
			id.setKrediTuru(rowMap.getString("KREDI_TURU"));
			id.setKampanyaKod(rowMap.getBigDecimal("KAMPANYA_KOD"));
			tx.setId(id);

			tx.setTutar(rowMap.getBigDecimal("TUTAR"));
			tx.setTutarTip(rowMap.getString("TUTAR_TIP"));
			tx.setVade(rowMap.getBigDecimal("VADE"));
			tx.setVadeTip(rowMap.getString("VADE_TIP"));
			tx.setVadeTur(rowMap.getString("VADE_TUR"));
			tx.setSigortaliKampKod(rowMap.getBigDecimal("SIGORTALI_KAMP_KOD"));

			session.saveOrUpdate(tx);
			session.flush();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3113_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		String tableName = "SEGMENT_TABLO";

		for (int row = 0; row < iMap.getSize(tableName); row++) {
			if (iMap.getString(tableName, row, "ISLEM_TIPI") == null) {
				BirKampanyaSegmentTx tx = new BirKampanyaSegmentTx();

				BirKampanyaSegmentTxId id = new BirKampanyaSegmentTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setSegment(iMap.getString(tableName, row, "SEGMENT"));
				id.setSegmentAltKod(iMap.getString(tableName, row, "SEGMENT_ALT_KOD"));
				id.setIslemTip(IslemTipi.YENI.getKod());
				id.setKrediTuru(iMap.getString(tableName, row, "KREDI_TURU"));
				id.setKampanyaKod(iMap.getBigDecimal(tableName, row, "KAMPANYA_KOD"));
				tx.setId(id);

				tx.setTutar(iMap.getBigDecimal(tableName, row, "TUTAR"));
				tx.setTutarTip(iMap.getString(tableName, row, "TUTAR_TIP"));
				tx.setVade(iMap.getBigDecimal(tableName, row, "VADE"));
				tx.setVadeTip(iMap.getString(tableName, row, "VADE_TIP"));
				tx.setVadeTur(iMap.getString(tableName, row, "VADE_TUR"));
				tx.setSigortaliKampKod(iMap.getBigDecimal(tableName, row, "SIGORTALI_KAMP_KOD"));

				session.save(tx);
				session.flush();
			}
		}

		iMap.put("TRX_NAME", "3113");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		return oMap;

	}

	/**
	 * @author mehmet.uluturk
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN3113_KAMPANYA_BUL")
	public static GMMap kampanyaBul(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap odMap = new GMMap();
		GMMap odrMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String segment = ConsumerLoanCommonServices.nvl(iMap.getString("MUSTERI_SEGMENT"), "X");
			String segmentAltKod = ConsumerLoanCommonServices.nvl(iMap.getString("MUSTERI_SEGMENT_ALT_KOD"), "X");
			List<BirKampanyaSegment> kampanyaList = session.createCriteria(BirKampanyaSegment.class).add(Restrictions.eq("id.segment", segment)).add(Restrictions.eq("id.segmentAltKod", segmentAltKod)).list();
			List<GnlParamText> paramTextList = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "SEGMENT_KREDI_TURU")).addOrder(Order.desc("siraNo")).list();

			String tableName = "KAMPANYA_LISTE";
			int row = 0;

			odMap.put("KREDI_TURU", iMap.get("KREDI_TURU"));
			odMap.put("KANAL_KOD", iMap.get("KANAL_KODU"));
			odMap.put("DOVIZ_KOD", iMap.get("DOVIZ_KODU"));

			for (BirKampanyaSegment kampanya : kampanyaList) {
				for (GnlParamText gnlParamText : paramTextList) {
					if (iMap.getBigDecimal(gnlParamText.getKey2()) != null && BigDecimal.ZERO.compareTo(iMap.getBigDecimal(gnlParamText.getKey2())) < 0 && gnlParamText.getKey1().equals(kampanya.getId().getKrediTuru())) {
						odrMap.clear();
						oMap.put(tableName, row, "KREDI_TIP", gnlParamText.getKey1());
						oMap.put(tableName, row, "ONAY_TUTAR", iMap.getBigDecimal(gnlParamText.getKey2()));
						if ("O".equals(kampanya.getVadeTip())) {
							oMap.put(tableName, row, "VADE", iMap.get("VADE"));
						}
						else {
							oMap.put(tableName, row, "VADE", kampanya.getVade());
						}
						oMap.put(tableName, row, "VADE_TUR", kampanya.getVadeTur());
						oMap.put(tableName, row, "KAMP_KOD", kampanya.getId().getKampanyaKod());

						BirKampanya birKampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", kampanya.getId().getKampanyaKod())).uniqueResult();
						oMap.put(tableName, row, "FAIZSIZ_SURE", birKampanya.getFaizsizSure());

						oMap.put(tableName, row, "SIGORTA_EH", "H");

						if (iMap.getBigDecimal("TUTAR").compareTo(iMap.getBigDecimal(gnlParamText.getKey2())) > 0) {
							oMap.put(tableName, row, "DUSUK_TUTAR_EH", "E");
						}
						else {
							oMap.put(tableName, row, "DUSUK_TUTAR_EH", "H");
						}

						oMap.put(tableName, row, "SEGMENT_KOD", segment);
						oMap.put(tableName, row, "SEGMENT_ALT_KOD", segmentAltKod);

						iMap.put("KAMP_URUN_ADI", oMap.get(tableName, row, "KAMP_KOD"));
						iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", iMap));
						for (int index = 0; index < iMap.getSize("ODEME_TIP_TABLE"); index++) {
							if ("7".equals(iMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
								oMap.put(tableName, row, "ODEMESIZ_SURE_MIN", iMap.get("ODEME_TIP_TABLE", index, "MIN_VADE"));
								oMap.put(tableName, row, "ODEMESIZ_SURE_MAX", iMap.get("ODEME_TIP_TABLE", index, "MAX_VADE"));
							}
							else if ("8".equals(iMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
								oMap.put(tableName, row, "ODEMESIZ_SURE", iMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
								odMap.put("ODEME_TIP_VADE", iMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
								odMap.put("ODEME_TIP_KOD", iMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
							}else{
								odMap.put("ODEME_TIP_KOD", iMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
							}
						}
						oMap.put(tableName, row, "ODEME_TIP_KOD", odMap.get("ODEME_TIP_KOD"));

						odMap.put("KREDI_TUTARI", oMap.get(tableName, row, "ONAY_TUTAR"));
						odMap.put("TUTAR", oMap.get(tableName, row, "ONAY_TUTAR"));
						odMap.put("KAMPANYA_KODU", oMap.get(tableName, row, "KAMP_KOD"));
						odMap.put("KAMP_URUN_ADI", oMap.get(tableName, row, "KAMP_KOD"));
						odMap.put("KREDI_VADE", oMap.get(tableName, row, "VADE"));
						odMap.put("VADE", oMap.get(tableName, row, "VADE"));
						odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
						if (odMap.getInt("VADE") > 2) {
							oMap.put(tableName, row, "AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 2, "OP_TAKSIT_TUTAR"));
						}
						else {
							oMap.put(tableName, row, "AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 1, "OP_TAKSIT_TUTAR"));
						}
						oMap.put(tableName, row, "FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
						
						GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "WEBKREDI_SIGORTA_TEKLIF")).uniqueResult();

						if (kampanya.getSigortaliKampKod() != null && "A".equals(parametre.getDeger())){
							odrMap.clear();
							oMap.put(tableName, row, "SIGORTALI_KAMP_KOD", kampanya.getSigortaliKampKod());
							iMap.put("KAMP_URUN_ADI", oMap.get(tableName, row, "SIGORTALI_KAMP_KOD"));
							iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", iMap));
							for (int index = 0; index < iMap.getSize("ODEME_TIP_TABLE"); index++) {
								if ("7".equals(iMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
									oMap.put(tableName, row, "SIGORTALI_ODEMESIZ_SURE_MIN", iMap.get("ODEME_TIP_TABLE", index, "MIN_VADE"));
									oMap.put(tableName, row, "SIGORTALI_ODEMESIZ_SURE_MAX", iMap.get("ODEME_TIP_TABLE", index, "MAX_VADE"));
								}
								else if ("8".equals(iMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
									oMap.put(tableName, row, "SIGORTALI_ODEMESIZ_SURE", iMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
									odMap.put("ODEME_TIP_VADE", iMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
									odMap.put("ODEME_TIP_KOD", iMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
								}else{
									odMap.put("ODEME_TIP_KOD", iMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
								}
							}
							oMap.put(tableName, row, "SIGORTALI_ODEME_TIP_KOD", odMap.get("ODEME_TIP_KOD"));
							
							odMap.put("KREDI_TUTARI", oMap.get(tableName, row, "ONAY_TUTAR"));
							odMap.put("TUTAR", oMap.get(tableName, row, "ONAY_TUTAR"));
							odMap.put("KAMPANYA_KODU", oMap.get(tableName, row, "SIGORTALI_KAMP_KOD"));
							odMap.put("KAMP_URUN_ADI", oMap.get(tableName, row, "SIGORTALI_KAMP_KOD"));
							odMap.put("KREDI_VADE", oMap.get(tableName, row, "VADE"));
							odMap.put("VADE", oMap.get(tableName, row, "VADE"));
							odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
							if (odMap.getInt("VADE") > 2) {
								oMap.put(tableName, row, "SIGORTALI_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 2, "OP_TAKSIT_TUTAR"));
							}
							else {
								oMap.put(tableName, row, "SIGORTALI_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 1, "OP_TAKSIT_TUTAR"));
							}
							oMap.put(tableName, row, "SIGORTALI_FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
						}
						row++;
					}
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}
