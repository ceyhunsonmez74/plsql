package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3259Services {

	@GraymoundService("BNSPR_TRN3259_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3259.IADE_ODEME(?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			BigDecimal txNo = iMap.getBigDecimal("TX_NO");

			int paramIndex = 1;
			stmt.clearParameters();
			stmt.setBigDecimal(paramIndex++, txNo);
			stmt.setBigDecimal(paramIndex++, iMap.get("BASVURU_NO") != null ? iMap.getBigDecimal("BASVURU_NO") : null);
			stmt.setBigDecimal(paramIndex++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setDate(paramIndex++, null);
			stmt.setString(paramIndex++, iMap.get("KANAL_KODU") != null ? iMap.getString("KANAL_KODU") : null);
			stmt.setString(paramIndex++, iMap.get("DURUM") != null ? iMap.getString("DURUM") : null);
			stmt.setBigDecimal(paramIndex++, iMap.get("HESAP_NO") != null ? iMap.getBigDecimal("HESAP_NO") : null);
			stmt.setBigDecimal(paramIndex++, iMap.get("BAKIYE") != null ? iMap.getBigDecimal("BAKIYE") : null);
			stmt.setDate(paramIndex++, iMap.getDate("VEFAT_TARIH") != null ? new Date(iMap.getDate("VEFAT_TARIH").getTime()) : null);
			stmt.setString(paramIndex++, iMap.getString("YAZI_NO"));
			stmt.setDate(paramIndex++, iMap.getDate("ISLEM_TARIH") != null ? new Date(iMap.getDate("ISLEM_TARIH").getTime()) : null);
			stmt.setBigDecimal(paramIndex++, iMap.getBigDecimal("IADE_TUTAR"));
			stmt.setBigDecimal(paramIndex++, iMap.get("KRD_HESAP_NO") != null ? iMap.getBigDecimal("KRD_HESAP_NO") : null);
			stmt.execute();

		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		try {
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3259_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "TABLE";
		BigDecimal toplamTutar = BigDecimal.ZERO;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3259.GET_IADE_BILGILERI(?,?,?,?,?)}");

			int paramIndex = 1;
			stmt.setString(paramIndex++, iMap.getString("MUSTERI_NO"));
			stmt.registerOutParameter(paramIndex++, -10);
			stmt.registerOutParameter(paramIndex++, Types.VARCHAR);
			stmt.registerOutParameter(paramIndex++, Types.DECIMAL);
			stmt.registerOutParameter(paramIndex++, Types.DATE);
			stmt.execute();
			stmt.getMoreResults();
			oMap.put("IADE_ONCEKI_TARIH", stmt.getDate(--paramIndex));
			oMap.put("IADE_ONCEKI_FIS_NO", stmt.getInt(--paramIndex));
			oMap.put("SGK_IADE_YAPILDIMI", stmt.getString(--paramIndex));
			rSet = (ResultSet) stmt.getObject(--paramIndex);
			oMap.putAll(DALUtil.rSetResults(rSet, tableName));

			for (int i = 0; i < oMap.getSize("TABLE"); i++) {
				if (oMap.getBigDecimal("TABLE", i, "IADE_TUTAR") != null) {
					toplamTutar = toplamTutar.add(oMap.getBigDecimal("TABLE", i, "IADE_TUTAR"));
				}
			}
			oMap.put("TOPLAM_TUTAR", toplamTutar);

		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3259_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "TABLE";

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3259.getTxInfo(?,?)}");

			int paramIndex = 1;
			stmt.setBigDecimal(paramIndex++, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(paramIndex++, -10);
			stmt.execute();
			stmt.getMoreResults();

			rSet = (ResultSet) stmt.getObject(--paramIndex);
			oMap = DALUtil.rSetResults(rSet, tableName);

			if (oMap.getSize(tableName) > 0) {
				oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				oMap.put("MUSTERI_NO", oMap.getBigDecimal(tableName, 0, "MUSTERI_NO"));
				oMap.put("YAZI_NO", oMap.getString(tableName, 0, "YAZI_NO"));
				oMap.put("ISLEM_TARIH", oMap.get(tableName, 0, "ISLEM_TARIH"));
			}

		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

}
