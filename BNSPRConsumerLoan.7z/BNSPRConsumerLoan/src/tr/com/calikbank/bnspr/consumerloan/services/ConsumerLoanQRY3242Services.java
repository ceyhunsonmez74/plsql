package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3242Services {
	
	@GraymoundService("BNSPR_QRY3242_SORGULA")
	public static GMMap sorgula(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt 	= null;
		ResultSet rSet 			= null;
		GMMap oMap = new GMMap();  
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_RC3242.bakiye_tutarsiz_rapor(?)}");
			stmt.registerOutParameter(1,-10);
			
			if(iMap.getDate("TARIH") != null)
				stmt.setDate(2, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(2, null);
			
			stmt.execute();
			String tableName="BASVURULAR";
			rSet = (ResultSet)stmt.getObject(1);
			int i=0;
			while (rSet.next()) {
                  oMap.put(tableName, i, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
                  oMap.put(tableName, i, "MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
                  oMap.put(tableName, i, "UNVAN", rSet.getString("UNVAN"));
                  oMap.put(tableName, i, "VADESIZ_HESAP_NO", rSet.getBigDecimal("VADESIZ_HESAP_NO"));
                  oMap.put(tableName, i, "TAKSIT_TUTARI", rSet.getBigDecimal("TAKSIT_TUTARI"));
                  
                  i++;
				}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
	 finally {
		GMServerDatasource.close(rSet);
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(conn);
	}
	}
}
