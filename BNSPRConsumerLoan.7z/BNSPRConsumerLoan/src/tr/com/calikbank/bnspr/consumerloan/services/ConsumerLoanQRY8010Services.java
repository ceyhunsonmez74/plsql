package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY8010Services {
	
	@GraymoundService("BNSPR_GET_YIM_BASVURU_LIST")
	public static GMMap getBasvuruRapor(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "RESULT";

		try {
			java.util.Date startDate = iMap.getDate("ILK_TARIH");
			java.util.Date endDate = iMap.getDate("SON_TARIH");
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call pkg_yim.getBasvuruList(?, ?, ?, ?, ?, ?)}");
			int paramIndex = 1;
			stmt.setBigDecimal(paramIndex++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(paramIndex++, iMap.getString("TCKN"));
			stmt.setString(paramIndex++, iMap.getString("DURUM"));
			stmt.setDate(paramIndex++, startDate != null ? new Date(startDate.getTime()) : null);
			stmt.setDate(paramIndex++, endDate != null ? new Date(endDate.getTime()) : null);
			stmt.registerOutParameter(paramIndex, -10);
			stmt.execute();
			stmt.getMoreResults();
			
			rSet = (ResultSet) stmt.getObject(paramIndex);
			oMap = DALUtil.rSetResults(rSet, tableName);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_YIM_BASVURU_DURUM_PARAM_KOD")
	public final static GMMap getYimAppStaus(GMMap iMap) throws SQLException {
		GMMap oMap = new GMMap();
		
		try {
			String code = iMap.getString("KOD");
			String key1 = iMap.getString("KEY1");
			
			oMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("LIST_NAME", "STATUS_LIST");
			oMap.put("LIST_QUERY", "SELECT TEXT KEY, KEY2 VALUE FROM BNSPR.GNL_PARAM_TEXT WHERE KOD = '" + code + "' AND KEY1 = '" + key1 + "' ORDER BY TEXT");
			oMap = DALUtil.fillComboBox(oMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

}
