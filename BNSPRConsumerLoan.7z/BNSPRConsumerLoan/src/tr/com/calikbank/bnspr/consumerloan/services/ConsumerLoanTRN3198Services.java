package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruKararCozmeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3198Services {

	@GraymoundService("BNSPR_TRN3198_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruGuncelleList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try
		{	
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3198.Rc_Trn3198_Basvuru_Izleme_List(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setString(i++, iMap.getString("KAMP_URUN_ADI"));
			stmt.setString(i++, iMap.getString("DURUM"));
			if(iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else 
				stmt.setDate(i++, null);
			if(iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(i++,  new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else 
				stmt.setDate(i++, null);
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("SATICI_KODU"));
			stmt.setString(i++, iMap.getString("SATICI_CALISMA_SEKLI"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("SUBE_KODU"));
			if (iMap.getBoolean("IPTAL") == true)
				stmt.setString (i++, "TRUE");
			else
				stmt.setString (i++, "FALSE");

			stmt.execute(); 
			
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap.putAll(DALUtil.rSetResults(rSet, "BASVURU_BILGILERI"));
			
			if (oMap.getSize("BASVURU_BILGILERI") == 0){
				iMap.put("HATA_NO", new BigDecimal(1614));
				return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN3198_SAVE")
	public static GMMap save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirBasvuruKararCozmeTx birBasvuruKararCozmeTx = new BirBasvuruKararCozmeTx();
			birBasvuruKararCozmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruKararCozmeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruKararCozmeTx.setEskiDurumKodu(iMap.getString("ESKI_DURUM_KODU"));
			birBasvuruKararCozmeTx.setYeniDurumKodu(iMap.getString("YENI_DURUM_KODU"));
			birBasvuruKararCozmeTx.setAciklama(iMap.getString("ACIKLAMA"));
			birBasvuruKararCozmeTx.setKararGerekce(iMap.getString("GEREKCE"));
			
			session.save(birBasvuruKararCozmeTx);
		
			session.flush();
			
			iMap.put("TRX_NAME", "3198");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			if(e.getCause()!=null)throw new GMRuntimeException(0,e.getCause().getMessage());
			else throw new GMRuntimeException(0,e);
		}
	}
	@GraymoundService("BNSPR_TRN3198_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");   
			
			BirBasvuruKararCozmeTx birBasvuruKararCozmeTx = (BirBasvuruKararCozmeTx)session.createCriteria(BirBasvuruKararCozmeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("TX_NO", birBasvuruKararCozmeTx.getTxNo());
			oMap.put("BASVURU_NO", birBasvuruKararCozmeTx.getBasvuruNo());
			oMap.put("ESKI_DURUM_KOD", birBasvuruKararCozmeTx.getEskiDurumKodu());
			oMap.put("YENI_DURUM_KOD", birBasvuruKararCozmeTx.getYeniDurumKodu());
			oMap.put("ACIKLAMA", birBasvuruKararCozmeTx.getAciklama());
			oMap.put("GEREKCE", birBasvuruKararCozmeTx.getKararGerekce());
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}	
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3198_YENI_STATU_LIST")
	public static GMMap getOnayStatuListYeni(GMMap iMap){  //BNSPR_QRY3129_ONAY_STATU_LIST
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1 from v_ml_gnl_param_text where kod = 'ONAY_STATU_KOD' and key1 not in ('BASVURU' , 'SOZLESME' , 'KAPANDI', 'KUL', 'KULONAY', 'CEPTE', 'JOB', 'NBSM', 'RED') order by sira_no");

			rSet = stmt.executeQuery();
			String listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
			while (rSet.next()) {
				if(rSet.getString(1).equals("KUL"))
					GuimlUtil.wrapMyCombo(oMap, listName,"KUL", "KULLANDIRIM");
				else 
					GuimlUtil.wrapMyCombo(oMap, listName,rSet.getString(1), rSet.getString(1));
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3198_YENI_BASVURU_LIST")
	public static GMMap yeniBasvuruList(GMMap iMap){
		GMMap oMap = new GMMap();
		String func = "{? = call PKG_TRN3198.Rc_Trn3198_Basvuru_Izleme_List(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		try {
			System.out.println("Yeni Basvuru List iMap="+iMap);
			Object[] inputValues = new Object[]{
			    BnsprType.NUMBER,null,
			    BnsprType.STRING,iMap.getString("TC_KIMLIK_NO"),
			    BnsprType.NUMBER,null,
			    BnsprType.STRING,null,
			    BnsprType.STRING,null,
			    BnsprType.STRING,null,
			    BnsprType.STRING,null,
			    BnsprType.STRING,null,
			    BnsprType.STRING,null,
			    BnsprType.DATE,iMap.getDate("BASLANGIC_TAR"),
			    BnsprType.DATE,null,
			    BnsprType.STRING,null,
			    BnsprType.STRING,null,
			    BnsprType.STRING,null,
			    BnsprType.NUMBER,null,
			    BnsprType.STRING,"FALSE"			    
			};
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BASVURU_BILGILERI", inputValues));
			String message="OK";
			if(oMap.getSize("BASVURU_BILGILERI")>0) {
			   iMap.put("MESSAGE_NO", new BigDecimal(2957));
		       iMap.put("P1", oMap.getBigDecimal("BASVURU_BILGILERI",0,"BASVURU_NO"));
		       message = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE");
			}
			oMap.put("MESSAGE",message);	
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);		
		}
		return oMap;
	}
}
