package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAdkBasvuru;
import tr.com.aktifbank.bnspr.dao.BirNbsmMusteriSegment;
import tr.com.aktifbank.bnspr.dao.BirNbsmMusteriSegmentId;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanInternalQueries {

	@GraymoundService("BNSPR_NBSM_TCMB_SORGU")
	public static GMMap basvuruTCMBTxSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_basvuru_sorgu.BasvuruTCMBTxSorgu (?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("SORGU_KIM_ICIN"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KEFIL_NO"));

			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_NBSM_FRAUD_SORGU")
	public static GMMap basvuruFraudTxSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_basvuru_sorgu.BasvuruFraudTxSorgu (?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("SORGU_KIM_ICIN"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KEFIL_NO"));

			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_NBSM_KKB_SORGU")
	public static GMMap basvuruKKBTxSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i;
		BigDecimal minSorguNo = null;
		BigDecimal maxSorguNo = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru_sorgu.BasvuruKKBTxSorgu (?,?,?,?,?,?,?,?,?)}");
			i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(i++, iMap.getString("SORGU_KIM_ICIN"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KEFIL_NO"));
			stmt.setString(i++, iMap.getString("BBE_GEREKLI") != null ? iMap.getString("BBE_GEREKLI") : "0");
			stmt.setString(i++, iMap.getString("VYS_DONDUR") != null ? iMap.getString("VYS_DONDUR") : "0");

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			GMMap sMap = new GMMap();
			sMap.putAll(DALUtil.rSetResults(rSet, "KKB_SORGU_LIST"));
			if (stmt.getString(6).equals("E")) {
				GMServiceExecuter.execute("ADD_KKB_TEST", sMap);
			}
			for (int z = 0; z < sMap.getSize("KKB_SORGU_LIST"); z++) {
				BigDecimal sorguNo = sMap.getBigDecimal("KKB_SORGU_LIST", z, "SORGU_ID");

				if (minSorguNo == null)
					minSorguNo = sorguNo;
				if (maxSorguNo == null)
					maxSorguNo = sorguNo;
				if (sorguNo.compareTo(minSorguNo) < 0)
					minSorguNo = sorguNo;
				if (sorguNo.compareTo(maxSorguNo) > 0)
					maxSorguNo = sorguNo;
			}
			stmt2 = conn.prepareCall("{? = call pkg_basvuru_sorgu.BasvuruKKBTxSorguDevam (?,?,?,?,?,?,?,?)}");
			i = 1;
			stmt2.registerOutParameter(i++, Types.VARCHAR);
			stmt2.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt2.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt2.setString(i++, iMap.getString("SORGU_KIM_ICIN"));
			stmt2.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt2.setBigDecimal(i++, minSorguNo);
			stmt2.setBigDecimal(i++, maxSorguNo);
			stmt2.setString(i++, iMap.getString("BBE_GEREKLI") != null ? iMap.getString("BBE_GEREKLI") : "0");
			stmt2.setString(i++, iMap.getString("VYS_DONDUR") != null ? iMap.getString("VYS_DONDUR") : "0");

			stmt2.execute();

			oMap.put("KKB_BASARILI", stmt2.getString(1));

		}
		catch (Exception e) {
			oMap.put("KKB_BASARILI", "H");

			try {
				stmt2 = conn.prepareCall("{? = call pkg_basvuru_sorgu.BasvuruKKBTxSorguDevam (?,?,?,?,?,?,?,?)}");
				i = 1;
				stmt2.registerOutParameter(i++, Types.VARCHAR);
				stmt2.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt2.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
				stmt2.setString(i++, iMap.getString("SORGU_KIM_ICIN"));
				stmt2.setString(i++, iMap.getString("SORGU_SEVIYESI"));
				stmt2.setBigDecimal(i++, minSorguNo);
				stmt2.setBigDecimal(i++, maxSorguNo);
				stmt2.setString(i++, iMap.getString("BBE_GEREKLI") != null ? iMap.getString("BBE_GEREKLI") : "0");
				stmt2.setString(i++, iMap.getString("VYS_DONDUR") != null ? iMap.getString("VYS_DONDUR") : "0");

				stmt2.execute();
			}
			catch (Exception e2) {
				oMap.put("KKB_BASARILI", "H");
			}
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	public static Map<?, ?> getExternalData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("1")); // External 1
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_NBSM_GET_APPLICATION_DATA")
	public static GMMap getApplicationData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("3")); // Application 3
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			if (iMap.getString("SORGU_SEVIYESI").equals("R"))
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static Map<?, ?> getCustomerData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("4")); // Customer 4
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			if (iMap.getString("SORGU_SEVIYESI").equals("R"))
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_NBSM_GET_KKB_DATA")
	public static GMMap getKKBData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("5")); // KKB 5
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_NBSM_GET_FRAUD_DATA")
	public static GMMap getVerificationFraudData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("2")); // Vertification&Fraud 2
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_NBSM_GET_TCMB_DATA")
	public static GMMap getTCMBData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM.Get_Ref_Cursor (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, new BigDecimal("6")); // TCMB 6
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static void nbsmBilinmeyenNumaraSorgulama(GMMap iMap) {
		if ("Y".equals(iMap.getString("EVTEL_SORGU_GEREKLI")) || "Y".equals(iMap.getString("ISTEL_SORGU_GEREKLI")) || "Y".equals(iMap.getString("CEPTEL_SORGU_GEREKLI"))) {
			iMap.put("KIM_ICIN", "M");
			GMServiceExecuter.executeNT("BNSPR_NBSM_UNKNOWN_NUMBER_QUERY", iMap);
		}
		if ("Y".equals(iMap.getString("KEFIL_1_EVTEL_SORGU_GEREKLI")) || "Y".equals(iMap.getString("KEFIL_1_ISTEL_SORGU_GEREKLI")) || "Y".equals(iMap.getString("KEFIL_1_CEPTEL_SORGU_GEREKLI"))) {
			iMap.put("KIM_ICIN", "K1");
			GMServiceExecuter.executeNT("BNSPR_NBSM_UNKNOWN_NUMBER_QUERY", iMap);
		}
		if ("Y".equals(iMap.getString("KEFIL_2_EVTEL_SORGU_GEREKLI")) || "Y".equals(iMap.getString("KEFIL_2_ISTEL_SORGU_GEREKLI")) || "Y".equals(iMap.getString("KEFIL_2_CEPTEL_SORGU_GEREKLI"))) {
			iMap.put("KIM_ICIN", "K2");
			GMServiceExecuter.executeNT("BNSPR_NBSM_UNKNOWN_NUMBER_QUERY", iMap);
		}
	}

	@GraymoundService("BNSPR_NBSM_UNKNOWN_NUMBER_QUERY")
	public static GMMap nbsmUnknownNumberQuery(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "118_WEB_SORGULAMA")).uniqueResult();

		try {
			if ("A".equals(parametre.getDeger())) {
				conn = DALUtil.getGMConnection();

				String kim_icin = null;
				if ("M".equals(iMap.getString("KIM_ICIN")))
					kim_icin = "";
				else if ("K1".equals(iMap.getString("KIM_ICIN")))
					kim_icin = "KEFIL_1_";
				else if ("K2".equals(iMap.getString("KIM_ICIN")))
					kim_icin = "KEFIL_2_";

				stmt = conn.prepareCall("{? = call PKG_IST_BILINMEYEN_NUMARA.rc_basvuru_bilgi (?,?,?)}");

				stmt.registerOutParameter(1, -10);
				stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setString(3, kim_icin + "TELEFON");
				stmt.setString(4, "H");
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(1);

				String ev_tel = null;
				String is_tel = null;
				String cep_tel = null;

				while (rSet.next()) {
					ev_tel = rSet.getString("EV_TEL");
					is_tel = rSet.getString("IS_TEL");
					cep_tel = rSet.getString("CEP_TEL");
				}

				iMap.put("PARAM_REF_TUR", "BIR_BASVURU");
				iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
				iMap.put("CLIENT_QUERY_NO", "1");

				sMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
				sMap.put("SORGU_TIP_KOD", "4");
				sMap.put("KIM_ICIN", iMap.getString("KIM_ICIN"));
				sMap.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));

				if ("Y".equals(iMap.getString(kim_icin + "EVTEL_SORGU_GEREKLI")) && !StringUtils.isBlank(ev_tel) && ev_tel.length() == 10) {
					oMap = new GMMap();
					iMap.put("PHONE_NUMBER", ev_tel);
					oMap = GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NUMBER", iMap);

					if (oMap.getString("LOG_ID") != null) {
						sMap.put("SORGU_NO", new BigDecimal(oMap.getString("LOG_ID")));
						insertBasvuruSorguTakip(sMap);
					}

				}
				if ("Y".equals(iMap.getString(kim_icin + "ISTEL_SORGU_GEREKLI")) && !StringUtils.isBlank(is_tel) && is_tel.length() == 10) {
					oMap = new GMMap();
					iMap.put("PHONE_NUMBER", is_tel);
					oMap = GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NUMBER", iMap);

					if (oMap.getString("LOG_ID") != null) {
						sMap.put("SORGU_NO", new BigDecimal(oMap.getString("LOG_ID")));
						insertBasvuruSorguTakip(sMap);
					}
				}
				if ("Y".equals(iMap.getString(kim_icin + "CEPTEL_SORGU_GEREKLI")) && !StringUtils.isBlank(cep_tel) && cep_tel.length() == 10) {
					oMap = new GMMap();
					iMap.put("PHONE_NUMBER", cep_tel);
					oMap = GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NUMBER", iMap);

					if (oMap.getString("LOG_ID") != null) {
						sMap.put("SORGU_NO", new BigDecimal(oMap.getString("LOG_ID")));
						insertBasvuruSorguTakip(sMap);
					}
				}
			}
			oMap.put("MESSAGE", "SUCCESS");
		}
		catch (Exception e) {
			System.out.println(ExceptionHandler.convertException(e));
			oMap.put("MESSAGE", ExceptionHandler.convertException(e));
			return oMap;
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	public static void insertBasvuruSorguTakip(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_BASVURU_SORGU.insert_bir_basvuru_sorgu_takip (?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SORGU_NO"));
			stmt.setString(i++, iMap.getString("SORGU_TIP_KOD"));
			stmt.setString(i++, iMap.getString("KIM_ICIN"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(i++, null);
			stmt.setString(i++, null);
			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static Map<?, ?> getPrevNbsmData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM_7RSL.get_prev_nbsm_outputs (?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SMCallType"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			oMap.put("RESULT", DALUtil.rSetMap(rSet));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static Map<?, ?> brmDecisionCall(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			GMMap bMap = new GMMap();
			bMap.put("CallId", (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "BIR_NBSM_SORGU")).get("ID"));
			oMap.put("CallId", bMap.getBigDecimal("CallId"));
			bMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			bMap.put("ONONAY_BASVURU", iMap.get("ONONAY_BASVURU"));
			if (iMap.containsKey("LOG_LEVEL")) {
				bMap.put("LOG_LEVEL", iMap.get("LOG_LEVEL"));
			}

			GMMap nbsmDataMap = new GMMap();
			nbsmDataMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			nbsmDataMap.put("TRX_NO", iMap.get("TRX_NO"));
			nbsmDataMap.put("SORGU_SEVIYESI", iMap.get("SORGU_SEVIYESI"));
			if ("E".equals(iMap.getString("KKB_YAPILDI")) || "R".equals(iMap.getString("SMCallType")) || "G".equals(iMap.getString("SMCallType")) || "L".equals(iMap.getString("SMCallType"))) {
				nbsmDataMap.put("KKB_DATA_ALINSIN_MI", Constants.EVET);
			}
			bMap.putAll(GMServiceExecuter.execute("BNSPR_NBSM_COLLECT_DATA", nbsmDataMap));

			oMap.put("MUSTERI_BLOKESI_VAR", bMap.getMap("MVT").getString("AppBlockedCustCode"));
			bMap.put("SMCallType", iMap.getString("SMCallType"));
			if (iMap.getMap("RESULT") != null)
				bMap.put("RESULT", iMap.getMap("RESULT"));

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru_sorgu.BasvuruInsertNBSMSorguID (?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SMCallType"));
			stmt.setBigDecimal(i++, bMap.getBigDecimal("CallId"));
			stmt.execute();
			oMap.putAll(GMServiceExecuter.execute("BNSPR_BRM_DECISION_CALL", bMap));

			fillNbsmDeger(bMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static String brmDecisionGetString(String brmKey, GMMap iMap1, GMMap iMap2) {
		if (iMap1.getString(brmKey) != null)
			return iMap1.getString(brmKey);
		else
			return iMap2.getString(brmKey);
	}

	public static GMMap basvuruSonlandir(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			if ((iMap.getBigDecimal("KANAL_KOD") == null) || (iMap.getString("KANAL_KOD").compareTo("7") != 0)) {
				iMap.put("TRX_NAME", "3171");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			}
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3171.basvuruNbsmRed(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("DURUM"));
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static Map<?, ?> updateNbsmSorguSonuc(GMMap iMap, GMMap i2Map) {
		Connection conn = null;
		CallableStatement stmt = null;
		Session session = null;
		try {
			if (i2Map.containsKey("CallId") && i2Map.getBigDecimal("CallId") != null) {
				conn = DALUtil.getGMConnection();

				stmt = conn.prepareCall("{call PKG_BASVURU_SORGU.UpdateNbsmSorguSonuc (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
				int i = 1;
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("CallId"));
				stmt.setString(i++, i2Map.getString("DURUM"));
				stmt.setString(i++, i2Map.getString("NBSM_KARAR_KOD"));
				stmt.setString(i++, i2Map.getString("NBSM_KOD"));
				stmt.setString(i++, i2Map.getString("GELIR_GOSTER"));
				stmt.setString(i++, i2Map.getString("GELIR_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("ADRES_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("GMENKUL_GELIR_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("ES_GELIR_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_1_GELIR_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_1_ADRES_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_2_GELIR_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_2_ADRES_BELGE_GEREKLI"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("ONAY_TUTAR"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("NBSM_UW_ONCELIK"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("NBSM_FRAUD_ONCELIK"));
				stmt.setString(i++, i2Map.getString("NBSM_FRAUD_KARAR_KOD"));
				stmt.setString(i++, i2Map.getString("GARANTORLU_MU"));
				stmt.setString(i++, i2Map.getString("MUSTERI_BLOKESI_VAR"));
				stmt.setString(i++, i2Map.getString("NBSM_KARAR_GEREKCE"));
				stmt.setString(i++, i2Map.getString("EVTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("ISTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("CEPTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_1_EVTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_1_ISTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_1_CEPTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_2_EVTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_2_ISTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("KEFIL_2_CEPTEL_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("ES_KKB_SORGU_GEREKLI"));
				stmt.setString(i++, i2Map.getString("TESLIMAT_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("IKINCI_KIMLIK_BELGE_GEREKLI"));
				stmt.setString(i++, i2Map.getString("EK_BILGI_GOSTER"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("UPSELL_LIMIT"));
				stmt.setString(i++, i2Map.getString("MINI_KREDI_SONUC"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("KDH_LIMIT"));
				stmt.setString(i++, i2Map.getString("MUSTERI_SEGMENT"));
				stmt.setString(i++, i2Map.getString("MUSTERI_SEGMENT_ALT_KOD"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("NORMAL_KREDI_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("MINI_KREDI_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("UPSELL_KREDI_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("DUSUK_FAIZ_KREDI_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("KONSOLIDASYON_KREDI_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("SPOT_KREDI_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("ONONAY_KREDI_LIMIT"));
				stmt.setString(i++, i2Map.getString("PSYC_SCORE_YN"));
				stmt.setString(i++, i2Map.getString("SOZLESME_BEKLEME_EH"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("PTT_KISMI_KONSOLIDASYON_ADET"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("BORC_TRANSFERI_UPSELL_LIMIT"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("BORC_TRANSFERI_TAHMINI_MAAS"));
				stmt.setBigDecimal(i++, i2Map.getBigDecimal("PTT_SMS_UPSELL_LIMIT"));
				stmt.execute();
			}

			if (!"1".equals(iMap.getString("ONONAY_BASVURU"))) {
				iMap.put("DURUM", i2Map.getString("DURUM"));
				if (!"E".equals(i2Map.getString("DEVAM")) && ("RED".equals(i2Map.getString("DURUM")) || "FRAUD".equals(i2Map.getString("DURUM"))))
					basvuruSonlandir(iMap);
				else {
					i2Map.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					i2Map.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));

					nbsmBilinmeyenNumaraSorgulama(i2Map);
				}

				/** netmera �n onay profile call **/
				session = DAOSession.getSession("BNSPRDal");
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				iMap.put("TC_KIMLIK_NO", birBasvuru.getTcKimlikNo());
				List<?> list = session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.eq("guncellenenCallId", i2Map.getBigDecimal("CallId"))).list();
				if (list.size() > 0) {
					GMServiceExecuter.executeAsync("BNSPR_TRN8000_NETMERA_EVENT", iMap);
				}
			}

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static void durumuBasvuruYap(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_BASVURU_SORGU.Durumu_Basvuru_Yap (?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static void durumKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_nbsm.Durum_Kontrol (?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));

			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_DEVAM_SORGULAR")
	public static Map<?, ?> devamSorgular(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			iMap.put("SORGU_KIM_ICIN", "M");
			iMap.put("SORGU_SEVIYESI", "H");

			oMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			oMap.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));

			if (!"1".equals(iMap.getString("ONONAY_BASVURU"))) {
				durumKontrol(iMap);
			}

			GMServiceExecuter.executeNT("BNSPR_NBSM_TCMB_SORGU", iMap);
			// GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);

			if (!"1".equals(iMap.getString("ONONAY_BASVURU"))) {
				iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3171_GET_MUSTERINO", iMap).get("MUSTERI_NO"));
			}			 
			GMServiceExecuter.executeNT("BNSPR_GET_KK_OCEAN_CARD_INFO", iMap);

			iMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));
			oMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));
			iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));

			GMMap bMap = new GMMap();
			bMap.putAll(brmDecisionCall(iMap)); // KKB icin NBSM sorgusu yapiliyor

			oMap.put("NBSM_KARAR_KOD", bMap.getString("KKBPolicyRulesDecisionCategory"));
			oMap.put("NBSM_FRAUD_KARAR_KOD", bMap.getString("SMFraudStrategyFraudLevel"));
			oMap.put("CallId", bMap.getBigDecimal("CallId"));

			if ("Policy Decline".equals(bMap.getString("KKBPolicyRulesDecisionCategory")) || "Decline".equals(bMap.getString("KKBPolicyRulesDecisionCategory"))) // red
			{
				if ("N".equals(bMap.getString("SMFraudStrategyFraudQueueYN")))
					oMap.put("DURUM", "RED");
				// PY-2273
				else if ("Y".equals(bMap.getString("FinalStrategyReturnReq"))) // Iade gerekli
				{
					oMap.put("DURUM", "KANALIADE");
					oMap.put("NBSM_KARAR_GEREKCE", bMap.getString("FinalStrategyReturnReasonCode"));
				}
				else if ("Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")))
					oMap.put("DURUM", "FRAUD");
				oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
				oMap.put("SPOT_MESSAGE", "".equals(bMap.getString("SpotLMUtilAmntComm")) ? null : bMap.getString("SpotLMUtilAmntComm"));
				oMap.put("SPOT_MESSAGE_RISK", "".equals(bMap.getString("SpotRiskAmountComm")) ? null : bMap.getString("SpotRiskAmountComm"));
				oMap.put("DEVAM", "H");
				oMap.put("NBSM_FRAUD_ONCELIK", bMap.getString("SMPriorityStrategyFraudQueuePriority"));
				oMap.put("NBSM_UW_ONCELIK", bMap.getString("SMPriorityStrategyUWQueuePriority"));
			}
			else {

				GMServiceExecuter.call("BNSPR_KKB_CKS_SORGU", iMap);

					if ("Y".equals(bMap.getString("StrategyInvoiceScoreYN"))) {
						GMServiceExecuter.executeNT("BNSPR_NKOLAY_FATURA_SKOR", iMap);
					}
					if ("Y".equals(bMap.getString("KKBStrategyKKBYNTelcoYNReq"))) {
						GMServiceExecuter.executeAsync("BNSPR_QRY8008_TELCO_SORGULA", iMap);
					}

					oMap.put("PSYC_SCORE_YN", bMap.getString("KKBStrategyKKBYNPsycScoreReq"));

					// PY-2273
					if ("Y".equals(bMap.getString("FinalStrategyReturnReq"))) // Iade gerekli
					{
						oMap.put("DURUM", "KANALIADE");
						oMap.put("NBSM_KARAR_GEREKCE", bMap.getString("FinalStrategyReturnReasonCode"));
					}
					else {
						oMap.put("EVTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppHomChReq"));
						oMap.put("ISTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppWorkChReq"));
						oMap.put("CEPTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppGSMChReq"));
						updateNbsmSorguSonuc(iMap, oMap);

						iMap.put("SORGU_SEVIYESI", "I");
						oMap.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));
						// TY-1252
						if ("Y".equals(bMap.getString("KKBStrategyKKBYNRequiredYN"))) // KKB gerekli
						{
							if ("Y".equals(bMap.getString("KKBStrategyBBEYNRequiredYN"))) {
								iMap.put("BBE_GEREKLI", "1");
							}
							if ("Y".equals(bMap.getString("KKBStrategyVYSYNRequiredYN"))) {
								iMap.put("VYS_DONDUR", "1");
							}
							GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap);
							iMap.put("KKB_YAPILDI", "E");
							GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
						}
						if ("Y".equals(bMap.getString("KKBStrategySpoKKBYNRequiredYN"))) {
							if ("Y".equals(bMap.getString("KKBStrategyBBEYNRequiredYN"))) {
								iMap.put("BBE_GEREKLI", "1");
							}
							if ("Y".equals(bMap.getString("KKBStrategyVYSYNRequiredYN"))) {
								iMap.put("VYS_DONDUR", "1");
							}
							iMap.put("SORGU_KIM_ICIN", "E");
							GMServiceExecuter.executeNT("BNSPR_NBSM_TCMB_SORGU", iMap);
							GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap);
							//GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
							iMap.put("SORGU_KIM_ICIN", "M");
						}
						
						if ("Y".equals(bMap.getString("StrategySpoFraudRequiredYN"))) {
							iMap.put("SORGU_KIM_ICIN", "E");
							GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
							iMap.put("SORGU_KIM_ICIN", "M");
						}

						iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
						// onceki nbsm datalari
						iMap.putAll(getPrevNbsmData(iMap));

						GMMap b2Map = new GMMap();
						b2Map.putAll(brmDecisionCall(iMap));
						oMap.put("ONAY_TUTAR", b2Map.getBigDecimal("StrategyLimitMergeLimit"));
						oMap.put("NBSM_KARAR_KOD", b2Map.getString("InitialDecisionMergeDecCatgry"));
						oMap.put("NBSM_FRAUD_KARAR_KOD", b2Map.getString("SMFraudStrategyFraudLevel"));
						oMap.put("CallId", b2Map.getBigDecimal("CallId"));
						oMap.put("NBSM_FRAUD_ONCELIK", b2Map.getString("SMPriorityStrategyFraudQueuePriority"));
						oMap.put("NBSM_UW_ONCELIK", b2Map.getString("SMPriorityStrategyUWQueuePriority"));
						oMap.put("GARANTORLU_MU", b2Map.getString("StrategyLimitMergeCmpGuarantorF"));
						oMap.put("MUSTERI_BLOKESI_VAR", b2Map.getString("MUSTERI_BLOKESI_VAR"));
						oMap.put("EVTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppHomChReq", b2Map, bMap));
						oMap.put("ISTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppWorkChReq", b2Map, bMap));
						oMap.put("CEPTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppGSMChReq", b2Map, bMap));
						oMap.put("ES_KKB_SORGU_GEREKLI", brmDecisionGetString("KKBStrategySpoKKBYNRequiredYN", b2Map, bMap));
						oMap.put("PTT_KISMI_KONSOLIDASYON_ADET", b2Map.getString("StrategyPTTPartialConsolidation"));
						oMap.put("PTT_SMS_LIMIT_UYARI_EH", b2Map.getString("StrategyLimit0Inst60"));

						if ("Policy Decline".equals(b2Map.getString("InitialDecisionMergeDecCatgry")) || "Decline".equals(b2Map.getString("InitialDecisionMergeDecCatgry"))) {
							if ("Y".equals(b2Map.getString("DecisionKonsolidasyonLoan")))
								oMap.put("DURUM", "IPTAL");
							else if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")))
								oMap.put("DURUM", "RED");
							else if ("Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")))
								oMap.put("DURUM", "FRAUD");
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							oMap.put("SPOT_MESSAGE", "".equals(b2Map.getString("SpotLMUtilAmntComm")) ? null : b2Map.getString("SpotLMUtilAmntComm"));
							oMap.put("SPOT_MESSAGE_RISK", "".equals(b2Map.getString("SpotRiskAmountComm")) ? null : b2Map.getString("SpotRiskAmountComm"));
							oMap.put("BORC_TRANSFERI_RED_2", b2Map.getString("StrategyPTTDebtTransferDec2"));
							oMap.put("BORC_TRANSFERI_RED_3", b2Map.getString("StrategyPTTDebtTransferDec3"));
							oMap.put("BORC_TRANSFERI_RED_4", b2Map.getString("StrategyPTTDebtTransferDec4"));
							oMap.put("BORC_TRANSFERI_RED_5", b2Map.getString("StrategyPTTDebtTransferDec5"));
							oMap.put("PTT_EMEKLI_LIMIT", b2Map.getBigDecimal("PttEmekliLimit"));
							oMap.put("DEVAM", "H");
						}
						else {
							// ikinci ekranda gelir alanlari gosterilecek mi
							oMap.put("GELIR_GOSTER", b2Map.getString("InitialStrategyIncYNReq"));
							oMap.put("PTT_GELIR_GOSTER", b2Map.getString("InitialStrategyADKIncYNReq"));
							oMap.put("EK_BILGI_GOSTER", b2Map.getString("InitialStrategyAddInfYNReq"));
							oMap.put("UPSELL_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeUpsellLimit"));
							oMap.put("MINI_KREDI_SONUC", b2Map.getString("StrategyLimitMergeMiniLoanF"));
							oMap.put("NBSM_FRAUD_SONUC", b2Map.getString("SMFraudStrategyFraudChReq"));

							oMap.put("MUSTERI_SEGMENT", b2Map.getString("StrategyAppnSegCustSegment"));
							oMap.put("MUSTERI_SEGMENT_ALT_KOD", b2Map.getString("StrategyAppnSegCustSubSegment"));
							oMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
							oMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));

							oMap.put("NORMAL_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg0Lim"));
							oMap.put("MINI_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg2Lim"));
							oMap.put("UPSELL_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeUpsellLimit"));
							oMap.put("DUSUK_FAIZ_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg4Lim"));
							oMap.put("KONSOLIDASYON_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg5Lim"));
							oMap.put("SPOT_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg6Lim"));
							oMap.put("ONONAY_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg7Lim"));
							oMap.put("ONONAY_KONSOLIDASYON_LIMIT", b2Map.getString("StrategyLimitMergeConsLimit"));

							oMap.put("BORC_TRANSFERI_DURUM_5", b2Map.getString("StrategyPTTDebtTransferDec5"));
							oMap.put("BORC_TRANSFERI_UPSELL_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeBTUpsellLmt"));
							oMap.put("BORC_TRANSFERI_TAHMINI_MAAS", b2Map.getBigDecimal("AppMonthlySalIncBT"));
							oMap.put("PTT_SMS_UPSELL_LIMIT", b2Map.getBigDecimal("StrategyLmtMrgRmngUpsellLmt"));
							
							oMap.put("PTT_ICI_BT_YONLENDIR", b2Map.getString("ReferralMessageToPttIciBt"));
							oMap.put("PTT_ICI_BT_LIMIT", b2Map.getBigDecimal("PttIciBtLimit"));
							oMap.put("DOGRULAMA", b2Map.getString("StrategyFraudCustInstSelectF"));

							GMServiceExecuter.execute("BNSPR_TRN3171_NBSM_SEGMENT_LOG", oMap);

							oMap.put("DURUM", "BASVURU");
							oMap.put("DEVAM", "E");
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							oMap.put("SPOT_MESSAGE", "".equals(b2Map.getString("SpotLMUtilAmntComm")) ? null : b2Map.getString("SpotLMUtilAmntComm"));

							if ("Y".equals(b2Map.getString("TeydebAltScoreYN"))) {
								GMServiceExecuter.executeAsync("BNSPR_EXT_SOSYALSKOR_SORGULA", iMap);
							}
						}
					}
				
			}
			updateNbsmSorguSonuc(iMap, oMap);
			return oMap;
		}
		catch (Exception e) {
			durumuBasvuruYap(iMap);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_NBSM_SEGMENT_LOG")
	public static GMMap nbsmMusteriSegmentLog(GMMap iMap) {

		if (iMap.getString("MUSTERI_SEGMENT") != null && !iMap.getString("MUSTERI_SEGMENT").isEmpty()) {
			Session session = DAOSession.getSession("BNSPRDal");

			BirNbsmMusteriSegment segment = new BirNbsmMusteriSegment();
			BirNbsmMusteriSegmentId id = new BirNbsmMusteriSegmentId(iMap.getBigDecimal("BASVURU_NO"), iMap.getString("SORGU_SEVIYESI"), iMap.getBigDecimal("SORGU_ID"));
			segment.setId(id);
			segment.setSegment(iMap.getString("MUSTERI_SEGMENT", "X"));
			segment.setSegmentAltKod(iMap.getString("MUSTERI_SEGMENT_ALT_KOD", "X"));
			segment.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO", BigDecimal.ZERO));

			session.saveOrUpdate(segment);
			session.flush();
		}
		return iMap;
	}

	public static BigDecimal kefilSayisi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_basvuru.KefilSayisi (?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.INTEGER);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();

			return stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static BigDecimal kefilNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_basvuru.KefilNo (?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.INTEGER);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SIRA_NO"));

			stmt.execute();

			return stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GONDER_SORGULAR")
	public static Map<?, ?> gonderSorgular(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			boolean kkbBasarili = true;
			GMMap oMap = new GMMap();
			iMap.put("SORGU_KIM_ICIN", "M");
			iMap.put("SORGU_SEVIYESI", "K");
			durumKontrol(iMap);

			GMServiceExecuter.executeNT("BNSPR_NBSM_TCMB_SORGU", iMap);
			// GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);

			iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3171_GET_MUSTERINO", iMap).get("MUSTERI_NO"));
			GMServiceExecuter.executeNT("BNSPR_GET_KK_OCEAN_CARD_INFO", iMap);

			iMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));
			oMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));
			// KKB icin NBSM sorgusu
			iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
			GMMap bMap = new GMMap();
			bMap.putAll(brmDecisionCall(iMap));
			oMap.put("NBSM_KARAR_KOD", bMap.getString("KKBPolicyRulesDecisionCategory"));
			oMap.put("NBSM_FRAUD_KARAR_KOD", bMap.getString("SMFraudStrategyFraudLevel"));
			oMap.put("CallId", bMap.getBigDecimal("CallId"));
			oMap.put("DEVAM", "E");
			//
			if ("Policy Decline".equals(bMap.getString("KKBPolicyRulesDecisionCategory")) || "Decline".equals(bMap.getString("KKBPolicyRulesDecisionCategory"))) {
				if ("N".equals(bMap.getString("SMFraudStrategyFraudQueueYN")))
					oMap.put("DURUM", "RED");
				// PY-2273
				else if ("Y".equals(bMap.getString("FinalStrategyReturnReq"))) // Iade gerekli
				{
					oMap.put("DURUM", "KANALIADE");
					oMap.put("NBSM_KARAR_GEREKCE", bMap.getString("FinalStrategyReturnReasonCode"));
				}
				else if ("Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")))
					oMap.put("DURUM", "FRAUD");
				oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
				oMap.put("DEVAM", "H");
				oMap.put("NBSM_FRAUD_ONCELIK", bMap.getString("SMPriorityStrategyFraudQueuePriority"));
				oMap.put("NBSM_UW_ONCELIK", bMap.getString("SMPriorityStrategyUWQueuePriority"));
			}
			else {
				iMap.put("SORGU_SEVIYESI", "F");
				oMap.put("SORGU_SEVIYESI", "F");

				// PY-2273
				if ("Y".equals(bMap.getString("FinalStrategyReturnReq"))) // Iade gerekli
				{
					oMap.put("DURUM", "KANALIADE");
					oMap.put("NBSM_KARAR_GEREKCE", bMap.getString("FinalStrategyReturnReasonCode"));
				}
				else {
					// TY-1252
					if ("Y".equals(bMap.getString("KKBStrategyKKBYNRequiredYN"))) // KKB gerekli
					{
						if ("Y".equals(bMap.getString("KKBStrategyBBEYNRequiredYN"))) { // TEST COMMIT
							iMap.put("BBE_GEREKLI", "1");
						}
						if ("Y".equals(bMap.getString("KKBStrategyVYSYNRequiredYN"))) {
							iMap.put("VYS_DONDUR", "1");
						}
						kkbBasarili = "E".equals(GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap).get("KKB_BASARILI"));
						if (kkbBasarili) {
							iMap.put("KKB_YAPILDI", "E");
							GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
						}
						else {
							oMap.put("DURUM", "JOB");
							iMap.put("MESSAGE_NO", new BigDecimal(1506));
							oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
							oMap.put("DEVAM", "H");
						}
					}
					String KKBStrategySpoKKBYNRequiredYNICall = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "KKBStrategySpoKKBYNRequiredYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "I"));
					if ("Y".equals(bMap.getString("KKBStrategySpoKKBYNRequiredYN")) || "Y".equals(KKBStrategySpoKKBYNRequiredYNICall)) {
						if ("Y".equals(bMap.getString("KKBStrategyBBEYNRequiredYN"))) {
							iMap.put("BBE_GEREKLI", "1");
						}
						if ("Y".equals(bMap.getString("KKBStrategyVYSYNRequiredYN"))) {
							iMap.put("VYS_DONDUR", "1");
						}
						iMap.put("SORGU_KIM_ICIN", "E");
						GMServiceExecuter.executeNT("BNSPR_NBSM_TCMB_SORGU", iMap);
						GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap);
						GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
						iMap.put("SORGU_KIM_ICIN", "M");
					}
					if (kkbBasarili) {
						iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));

						// onceki nbsm datalari
						iMap.putAll(getPrevNbsmData(iMap));

						GMMap b2Map = new GMMap();
						b2Map.putAll(brmDecisionCall(iMap));
						oMap.put("NBSM_KARAR_KOD", b2Map.getString("FinalDecisionMergeDecCategory"));
						oMap.put("NBSM_FRAUD_KARAR_KOD", b2Map.getString("SMFraudStrategyFraudLevel"));
						oMap.put("CallId", b2Map.getBigDecimal("CallId"));
						oMap.put("NBSM_FRAUD_ONCELIK", b2Map.getString("SMPriorityStrategyFraudQueuePriority"));
						oMap.put("NBSM_UW_ONCELIK", b2Map.getString("SMPriorityStrategyUWQueuePriority"));
						oMap.put("ADRES_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionAddressDocumentsRequired"));
						oMap.put("GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionIncomeDocumentsRequired"));
						oMap.put("GMENKUL_GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionREMADocumentsRequired"));
						oMap.put("ES_GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionSpouseDocumentRequired"));
						oMap.put("GARANTORLU_MU", b2Map.getString("StrategyLimitMergeCmpGuarantorF"));
						oMap.put("MUSTERI_BLOKESI_VAR", b2Map.getString("MUSTERI_BLOKESI_VAR"));
						oMap.put("EVTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppHomChReq", b2Map, bMap));
						oMap.put("ISTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppWorkChReq", b2Map, bMap));
						oMap.put("CEPTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppGSMChReq", b2Map, bMap));
						oMap.put("ES_KKB_SORGU_GEREKLI", brmDecisionGetString("KKBStrategySpoKKBYNRequiredYN", b2Map, bMap));
						oMap.put("TESLIMAT_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionDeliveryDocumentsRequired"));
						oMap.put("IKINCI_KIMLIK_BELGE_GEREKLI", b2Map.getString("SMOtherIDChReq"));
						oMap.put("SGK_BELGE_GEREKLI", b2Map.getString("VerAppWebSGKDocChqRq"));

						oMap.put("MUSTERI_SEGMENT", b2Map.getString("StrategyAppnSegCustSegment"));
						oMap.put("MUSTERI_SEGMENT_ALT_KOD", b2Map.getString("StrategyAppnSegCustSubSegment"));
						oMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
						oMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));

						oMap.put("NORMAL_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg0Lim"));
						oMap.put("MINI_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg2Lim"));
						oMap.put("UPSELL_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeUpsellLimit"));
						oMap.put("DUSUK_FAIZ_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg4Lim"));
						oMap.put("KONSOLIDASYON_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg5Lim"));
						oMap.put("SPOT_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg6Lim"));
						oMap.put("ONONAY_KREDI_LIMIT", b2Map.getString("StrategyLimitMergeSeg7Lim"));
						oMap.put("PSYC_SCORE_YN", b2Map.getString("KKBStrategyKKBYNPsycScoreReq"));
						oMap.put("SOZLESME_BEKLEME_EH", nvlString(iMap.getString("SOZLESME_BEKLEME_EH"), b2Map.getString("StrategyAppnPendingStatF")));
						oMap.put("PTT_KISMI_KONSOLIDASYON_ADET", b2Map.getString("StrategyPTTPartialConsolidation"));

						oMap.put("BORC_TRANSFERI_DURUM_5", b2Map.getString("StrategyPTTDebtTransferDec5"));
						oMap.put("BORC_TRANSFERI_UPSELL_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeBTUpsellLmt"));
						oMap.put("PTT_SMS_UPSELL_LIMIT", b2Map.getBigDecimal("StrategyLmtMrgRmngUpsellLmt"));
						oMap.put("BORC_TRANSFERI_TAHMINI_MAAS", b2Map.getBigDecimal("AppMonthlySalIncBT"));
						oMap.put("DOGRULAMA", b2Map.getString("StrategyFraudCustInstSelectF"));

						GMServiceExecuter.executeNT("BNSPR_TRN3171_NBSM_SEGMENT_LOG", oMap);

						if ("Policy Decline".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Decline".equals(b2Map.getString("FinalDecisionMergeDecCategory"))) {
							if ("Y".equals(b2Map.getString("DecisionKonsolidasyonLoan")))
								oMap.put("DURUM", "IPTAL");
							else if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")))
								oMap.put("DURUM", "RED");
							// PY-2273
							else if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
							{
								oMap.put("DURUM", "KANALIADE");
								oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
							}
							else if ("Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")))
								oMap.put("DURUM", "FRAUD");
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							oMap.put("DEVAM", "H");
						}
						else {
							oMap.put("UPSELL_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeUpsellLimit"));
							oMap.put("MINI_KREDI_SONUC", b2Map.getString("StrategyLimitMergeMiniLoanF"));
							oMap.put("KDH_LIMIT", b2Map.getBigDecimal("StrategyLimitMergeKDHLimit"));

							if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
							{
								oMap.put("DURUM", "KANALIADE");
								oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
								oMap.put("ONAY_TUTAR", b2Map.getBigDecimal("StrategyLimitMergeLimit"));
								oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							}
							else {
								oMap.put("ONAY_TUTAR", b2Map.getBigDecimal("StrategyLimitMergeLimit"));
								oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
								oMap.put("NBSM_KOD", "MAppVer:" + b2Map.getString("FinalStrategyAppVerAppChReq") //
										+ "-MEmptVer:" + b2Map.getString("FinalStrategyEmptVerReqCode") //
										+ "-MFraudVer:" + b2Map.getString("SMFraudStrategyFraudChReq") // PY-2273
										+ "-MWebVer:" + b2Map.getString("FinalStrategyWebChReq") // PY-2273
								);

								if (!"E".equals(iMap.getString("NBSMSIZ_KEFIL")) //
										&& "N".equals(b2Map.getString("FinalStrategyGuaYNRequired")) //
										&& "N".equals(b2Map.getString("FinalStrategyAppVerAppChReq")) //
										&& "Not Required".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
										&& "N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
										&& "N".equals(b2Map.getString("SMFraudStrategyFraudChReq")) // PY-2273
										&& "N".equals(b2Map.getString("FinalStrategyWebChReq")) // PY-2273
								) {
									if (("Policy Accept".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Accept".equals(b2Map.getString("FinalDecisionMergeDecCategory"))) && ("No Fraud".equals(b2Map.getString("SMFraudStrategyFraudLevel")) || "High Fraud".equals(b2Map.getString("SMFraudStrategyFraudLevel"))))
										oMap.put("DURUM", "SOZLESME");
									else if (("Policy Accept".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Accept".equals(b2Map.getString("FinalDecisionMergeDecCategory"))) && "Low Fraud".equals(b2Map.getString("SMFraudStrategyFraudLevel")))
										if ("Y".equalsIgnoreCase(oMap.getString("PSYC_SCORE_YN"))) {
											oMap.put("DURUM", "BASVURU");
										}
										else {
											oMap.put("DURUM", "ISTIHBARAT");
										}
									else if ("Decline Refer".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Refer".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Accept Refer".equals(b2Map.getString("FinalDecisionMergeDecCategory")))
										if ("Y".equalsIgnoreCase(oMap.getString("PSYC_SCORE_YN"))) {
											oMap.put("DURUM", "BASVURU");
										}
										else {
											oMap.put("DURUM", "ISTIHBARAT");
										}
								}
								else if (!"E".equals(iMap.getString("NBSMSIZ_KEFIL")) //
										&& "N".equals(b2Map.getString("FinalStrategyGuaYNRequired")) //
										&& "N".equals(b2Map.getString("FinalStrategyAppVerAppChReq")) //
										&& "Not Required".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
										&& "Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
										&& "N".equals(b2Map.getString("SMFraudStrategyFraudChReq")) // PY-2273
										&& "N".equals(b2Map.getString("FinalStrategyWebChReq")) // PY-2273
								) {
									oMap.put("DURUM", "FRAUD");
								}
								else if ("E".equals(iMap.getString("NBSMSIZ_KEFIL")) || "Y".equals(b2Map.getString("FinalStrategyGuaYNRequired"))) {
									// kefil alinacak, sm kefil call yapilacak
									oMap.put("KEFIL_GEREKLI", b2Map.getString("FinalStrategyGuaYNRequired"));
									oMap.put("DURUM", "BASVURU");
									if ("Y".equals(b2Map.getString("FinalStrategyAppVerAppChReq")) //
											|| "Home".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
											|| "Work".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
											|| "Web".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
											|| "Y".equals(b2Map.getString("SMFraudStrategyFraudChReq")) // PY-2273
											|| "Y".equals(b2Map.getString("FinalStrategyWebChReq")) // PY-2273
									) {
										// dogrulama ekranina gonderilir, sm final 2 call yapilacak
										oMap.put("NBSM_KOD", "MAppVer:" + b2Map.getString("FinalStrategyAppVerAppChReq") //
												+ "-MEmptVer:" + b2Map.getString("FinalStrategyEmptVerReqCode") //
												+ "-MFraudVer:" + b2Map.getString("SMFraudStrategyFraudChReq") // PY-2273
												+ "-MWebVer:" + b2Map.getString("FinalStrategyWebChReq") // PY-2273
										);
									}
								}
								else if (!"E".equals(iMap.getString("NBSMSIZ_KEFIL")) //
										&& "N".equals(b2Map.getString("FinalStrategyGuaYNRequired")) //
										&& ("Y".equals(b2Map.getString("FinalStrategyAppVerAppChReq")) //
												|| "Home".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
												|| "Work".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
												|| "Web".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
												|| "Y".equals(b2Map.getString("SMFraudStrategyFraudChReq")) // PY-2273
										|| "Y".equals(b2Map.getString("FinalStrategyWebChReq")) // PY-2273
										) //
								) {
									// dogrulama ekranina gonderilir, sm final 2 call yapilacak
									oMap.put("DURUM", "DOGRULAMA");
									oMap.put("NBSM_KOD", "MAppVer:" + b2Map.getString("FinalStrategyAppVerAppChReq") //
											+ "-MEmptVer:" + b2Map.getString("FinalStrategyEmptVerReqCode") //
											+ "-MFraudVer:" + b2Map.getString("SMFraudStrategyFraudChReq") // PY-2273
											+ "-MWebVer:" + b2Map.getString("FinalStrategyWebChReq") // PY-2273
									);
								}
								else {
									iMap.put("HATA_NO", new BigDecimal(1499));
									return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
								}
							}
						}
					}
				}
			}
			if ("KANALIADE".equals(oMap.getString("DURUM")) && "Emekli ilk maa�".equals(oMap.getString("NBSM_KARAR_GEREKCE"))) {
				GMMap eMap = new GMMap();
				eMap.put("EVENT_TYPE_NO", "66");
				eMap.put("EVENT_REF_NO", iMap.getString("BASVURU_NO"));
				GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", eMap);
			}
			updateNbsmSorguSonuc(iMap, oMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static String getPrevNbsmOutputValue(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_NBSM_7RSL.get_prev_nbsm_output_value (?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setString(i++, iMap.getString("NBSM_KEY"));

			stmt.execute();

			return stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KEFIL_SORGULAR")
	public static Map<?, ?> kefilSorgular(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			boolean kkbBasarili = true;
			GMMap oMap = new GMMap();
			GMMap bMap = new GMMap();
			GMMap b2Map = new GMMap();
			iMap.put("SORGU_KIM_ICIN", "K1");
			iMap.put("SORGU_SEVIYESI", "G");
			iMap.put("SIRA_NO", 1);
			iMap.put("KEFIL_NO", kefilNo(iMap));
			GMServiceExecuter.executeNT("BNSPR_NBSM_TCMB_SORGU", iMap);
			// basvuruFraudTxSorgu(iMap);
			kkbBasarili = "E".equals(GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap).get("KKB_BASARILI"));
			if (kkbBasarili || kefilSayisi(iMap).compareTo(BigDecimal.ZERO) == 0) {
				GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
				iMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));
				// Kefil 1 icin NBSM sorgusu
				iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
				// onceki nbsm datalari
				iMap.putAll(getPrevNbsmData(iMap));
				bMap.putAll(brmDecisionCall(iMap));
				String dogrulamaStr = null;
				dogrulamaStr = "K1EmptVer:" + bMap.getString("KefilStrategyGuaEmptVerReqCode") //
						+ "-K1FraudVer:" + bMap.getString("SMFraudStrategyGua1FraudChReq") // PY-2273
				;
				oMap.put("NBSM_FRAUD_ONCELIK", bMap.getString("SMPriorityStrategyFraudQueuePriority"));
				oMap.put("NBSM_UW_ONCELIK", bMap.getString("SMPriorityStrategyUWQueuePriority"));

				if (kefilSayisi(iMap).compareTo(BigDecimal.ONE) >= 1) {
					iMap.put("SORGU_KIM_ICIN", "K2");
					iMap.put("SORGU_SEVIYESI", "L");
					iMap.put("SIRA_NO", 2);
					iMap.put("KEFIL_NO", kefilNo(iMap));
					GMServiceExecuter.executeNT("BNSPR_NBSM_TCMB_SORGU", iMap);
					// basvuruFraudTxSorgu(iMap);
					kkbBasarili = "E".equals(GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap).get("KKB_BASARILI"));
					if (kkbBasarili) {
						GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
						// Kefil 2 icin NBSM sorgusu
						iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
						iMap.putAll(getPrevNbsmData(iMap));
						b2Map.putAll(brmDecisionCall(iMap));
						dogrulamaStr = dogrulamaStr + "-K2EmptVer:" + b2Map.getString("KefilStrategyGuaEmptVerReqCode") //
								+ "-K2FraudVer:" + b2Map.getString("SMFraudStrategyGua2FraudChReq") // PY-2273
						;
						oMap.put("NBSM_FRAUD_ONCELIK", b2Map.getString("SMPriorityStrategyFraudQueuePriority"));
						oMap.put("NBSM_UW_ONCELIK", b2Map.getString("SMPriorityStrategyUWQueuePriority"));
					}
					else {
						oMap.put("DURUM", "JOB");
						iMap.put("MESSAGE_NO", new BigDecimal(1506));
						oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
						oMap.put("DEVAM", "H");

						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{call pkg_trn3171.updateDurum(?,?)}");
						stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
						stmt.setString(2, "JOB");
						stmt.execute();

						return oMap;
					}
				}
				else
					b2Map = bMap;

				if (kkbBasarili || kefilSayisi(iMap).compareTo(BigDecimal.ZERO) == 0) {
					oMap.put("CallId", b2Map.getBigDecimal("CallId"));
					oMap.put("DEVAM", "E");
					String smFraudStrategyFraudQueueYN = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudQueueYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
					oMap.put("KEFIL_1_ADRES_BELGE_GEREKLI", bMap.getString("KefilStrategyGuarantorDocumentExceptionGuarantorAddressDocumentsRequired"));
					oMap.put("KEFIL_1_GELIR_BELGE_GEREKLI", bMap.getString("KefilStrategyGuarantorDocumentExceptionGuarantorIncomeDocumentsRequired"));
					oMap.put("KEFIL_2_ADRES_BELGE_GEREKLI", b2Map.getString("KefilStrategyGuarantorDocumentExceptionGuarantorAddressDocumentsRequired"));
					oMap.put("KEFIL_2_GELIR_BELGE_GEREKLI", b2Map.getString("KefilStrategyGuarantorDocumentExceptionGuarantorIncomeDocumentsRequired"));
					oMap.put("KEFIL_1_EVTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1HomChReq"));
					oMap.put("KEFIL_1_ISTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1WorkChReq"));
					oMap.put("KEFIL_1_CEPTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1GSMChReq"));
					oMap.put("KEFIL_2_EVTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2HomChReq"));
					oMap.put("KEFIL_2_ISTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2WorkChReq"));
					oMap.put("KEFIL_2_CEPTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2GSMChReq"));

					if ("Policy Decline".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Decline".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) {
						if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")))
							oMap.put("DURUM", "RED");
						// PY-2273
						else if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
						{
							oMap.put("DURUM", "KANALIADE");
							oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
						}
						else if ("Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(smFraudStrategyFraudQueueYN))
							oMap.put("DURUM", "FRAUD");
						oMap.put("DEVAM", "H");
						oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));

					}
					else {
						// PY-2273
						if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
						{
							oMap.put("DURUM", "KANALIADE");
							oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
						}
						else {
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));

							String FinalStrategyAppVerAppChReq = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "FinalStrategyAppVerAppChReq").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
							String FinalStrategyEmptVerReqCode = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "FinalStrategyEmptVerReqCode").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
							String SMFraudStrategyFraudChReq = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudChReq").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F")); // PY-2273

							String smFraudStrategyFraudLevel = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudLevel").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));

							if ("Y".equals(FinalStrategyAppVerAppChReq) //
									|| !("Not Required".equals(FinalStrategyEmptVerReqCode)) //
									|| "Home".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Work".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Web".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Home".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Work".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Web".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Y".equals(SMFraudStrategyFraudChReq) // PY-2273
									|| "Y".equals(bMap.getString("SMFraudStrategyGua1FraudChReq")) // PY-2273
									|| "Y".equals(b2Map.getString("SMFraudStrategyGua2FraudChReq")) // PY-2273
							) {
								// dogrulama ekranina gonderilir, sm final 2 call yapilacak
								oMap.put("DURUM", "DOGRULAMA");
								oMap.put("NBSM_KOD", dogrulamaStr);
							}
							else if ("N".equals(FinalStrategyAppVerAppChReq) //
									&& "Not Required".equals(FinalStrategyEmptVerReqCode) //
									&& "Not Required".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
									&& "Not Required".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
									&& "N".equals(SMFraudStrategyFraudChReq) // PY-2273
									&& "N".equals(nvlString(bMap.getString("SMFraudStrategyGua1FraudChReq"), "N")) // PY-2273
									&& "N".equals(nvlString(b2Map.getString("SMFraudStrategyGua2FraudChReq"), "N")) // PY-2273
									&& ("Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
											|| "Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) //
									|| "Y".equals(smFraudStrategyFraudQueueYN) //
									)) {
								oMap.put("DURUM", "FRAUD");
							}
							else if ("N".equals(smFraudStrategyFraudQueueYN) && "N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) && "N".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) && (("Low Fraud").equals(smFraudStrategyFraudLevel) || ("Low Fraud").equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || ("Low Fraud").equals(b2Map.getString("SMFraudStrategyGua2FraudLevel"))))
								oMap.put("DURUM", "ISTIHBARAT");
							else if ("N".equals(FinalStrategyAppVerAppChReq) //
									&& "Not Required".equals(FinalStrategyEmptVerReqCode) //
									&& "Not Required".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) // 1.kefilin
									&& "Not Required".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) // 2.kefilin
									&& "N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
									&& "N".equals(SMFraudStrategyFraudChReq) // PY-2273
									&& "N".equals(nvlString(bMap.getString("SMFraudStrategyGua1FraudChReq"), "N")) // PY-2273
									&& "N".equals(nvlString(b2Map.getString("SMFraudStrategyGua2FraudChReq"), "N")) // PY-2273
							) {
								if (("Policy Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) && ("No Fraud".equals(b2Map.getString("SMFraudStrategyGua2FraudLevel")) || "No Fraud".equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || "No Fraud".equals(smFraudStrategyFraudLevel)) || "High Fraud".equals(smFraudStrategyFraudLevel))
									oMap.put("DURUM", "SOZLESME");
								else if (("Policy Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) && ("Low Fraud".equals(b2Map.getString("SMFraudStrategyGua2FraudLevel")) || "Low Fraud".equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || "Low Fraud".equals(smFraudStrategyFraudLevel)))
									oMap.put("DURUM", "ISTIHBARAT");
								else if ("Decline Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")))
									oMap.put("DURUM", "ISTIHBARAT");
							}
							else {
								iMap.put("HATA_NO", new BigDecimal(1499));
								return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
							}
						}
					}
				}
				oMap.put("NBSM_KARAR_KOD", b2Map.getString("KefilKefil1Kefil2DecCategory"));
				updateNbsmSorguSonuc(iMap, oMap);
			}
			else {
				oMap.put("DURUM", "JOB");
				iMap.put("MESSAGE_NO", new BigDecimal(1506));
				oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				oMap.put("DEVAM", "H");

				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_trn3171.updateDurum(?,?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setString(2, "JOB");
				stmt.execute();
				return oMap;
			}

			return oMap;
		}
		catch (Exception e) {
			durumuBasvuruYap(iMap);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_FINAL_SORGULAR")
	public static Map<?, ?> finalSorgular(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			iMap.put("SORGU_SEVIYESI", "R");
			iMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));
			iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
			durumKontrol(iMap);

			iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3171_GET_MUSTERINO", iMap).get("MUSTERI_NO"));
			GMServiceExecuter.executeNT("BNSPR_GET_KK_OCEAN_CARD_INFO", iMap);

			// onceki nbsm datalari
			GMMap bMap = new GMMap();
			iMap.putAll(getPrevNbsmData(iMap));
			bMap.putAll(brmDecisionCall(iMap));
			// sonuca gore red, fraud var, fraud yok, onay
			oMap.put("CallId", bMap.getBigDecimal("CallId"));
			oMap.put("DEVAM", "E");

			String smFraudStrategyFraudQueueYNK1 = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudQueueYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "G"));
			String smFraudStrategyFraudQueueYNK2 = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudQueueYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "L"));

			oMap.put("NBSM_KARAR_KOD", bMap.getString("FinalDecisionMergeDecCategory"));
			oMap.put("ONAY_TUTAR", bMap.getBigDecimal("StrategyLimitMergeLimit"));
			oMap.put("NBSM_FRAUD_ONCELIK", bMap.getString("SMPriorityStrategyFraudQueuePriority"));
			oMap.put("NBSM_UW_ONCELIK", bMap.getString("SMPriorityStrategyUWQueuePriority"));
			oMap.put("ADRES_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionAddressDocumentsRequired"));
			oMap.put("GELIR_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionIncomeDocumentsRequired"));
			oMap.put("GMENKUL_GELIR_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionREMADocumentsRequired"));
			oMap.put("ES_GELIR_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionSpouseDocumentRequired"));
			oMap.put("GARANTORLU_MU", bMap.getString("StrategyLimitMergeCmpGuarantorF"));
			oMap.put("MUSTERI_BLOKESI_VAR", bMap.getString("MUSTERI_BLOKESI_VAR"));
			oMap.put("EVTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppHomChReq"));
			oMap.put("ISTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppWorkChReq"));
			oMap.put("CEPTEL_SORGU_GEREKLI", bMap.getString("SMTelVerAppGSMChReq"));
			oMap.put("ES_KKB_SORGU_GEREKLI", bMap.getString("KKBStrategySpoKKBYNRequiredYN"));
			oMap.put("TESLIMAT_BELGE_GEREKLI", bMap.getString("StrategyDocumentExceptionDeliveryDocumentsRequired"));
			oMap.put("IKINCI_KIMLIK_BELGE_GEREKLI", bMap.getString("SMOtherIDChReq"));
			oMap.put("SOZLESME_BEKLEME_EH", bMap.getString("StrategyAppnPendingStatF"));
			oMap.put("PTT_KISMI_KONSOLIDASYON_ADET", bMap.getString("StrategyPTTPartialConsolidation"));

			if ("Policy Decline".equals(bMap.getString("FinalDecisionMergeDecCategory")) || "Decline".equals(bMap.getString("FinalDecisionMergeDecCategory"))) {
				if ("N".equals(bMap.getString("SMFraudStrategyFraudQueueYN")))
					oMap.put("DURUM", "RED");
				// PY-2273
				else if ("Y".equals(bMap.getString("FinalStrategyReturnReq"))) // Iade gerekli
				{
					oMap.put("DURUM", "KANALIADE");
					oMap.put("NBSM_KARAR_GEREKCE", bMap.getString("FinalStrategyReturnReasonCode"));
				}
				else if ("Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(smFraudStrategyFraudQueueYNK1) || "Y".equals(smFraudStrategyFraudQueueYNK2))
					oMap.put("DURUM", "FRAUD");
				oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
			}
			else {
				oMap.put("UPSELL_LIMIT", bMap.getBigDecimal("StrategyLimitMergeUpsellLimit"));
				oMap.put("MINI_KREDI_SONUC", bMap.getString("StrategyLimitMergeMiniLoanF"));
				oMap.put("MESSAGE", "".equals(bMap.getString("SMCommunicationStrategyMessage")) ? null : bMap.getString("SMCommunicationStrategyMessage"));
				String smFraudStrategyFraudLevelK1 = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudLevel").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "G"));
				String smFraudStrategyFraudLevelK2 = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudLevel").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "L"));

				// PY-2273
				if ("Y".equals(bMap.getString("FinalStrategyReturnReq"))) // Iade gerekli
				{
					oMap.put("DURUM", "KANALIADE");
					oMap.put("NBSM_KARAR_GEREKCE", bMap.getString("FinalStrategyReturnReasonCode"));
				}
				else if ("Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(smFraudStrategyFraudQueueYNK1) || "Y".equals(smFraudStrategyFraudQueueYNK2))
					oMap.put("DURUM", "FRAUD");
				else {
					if ("N".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) && (smFraudStrategyFraudQueueYNK1 == null || "N".equals(smFraudStrategyFraudQueueYNK1)) && (smFraudStrategyFraudQueueYNK2 == null || "N".equals(smFraudStrategyFraudQueueYNK2)) && (("Low Fraud").equals(bMap.getString("SMFraudStrategyFraudLevel")) || ("Low Fraud").equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || ("Low Fraud").equals(bMap.getString("SMFraudStrategyGua2FraudLevel"))))
						oMap.put("DURUM", "ISTIHBARAT");
					else if (("Policy Accept".equals(bMap.getString("FinalDecisionMergeDecCategory")) || "Accept".equals(bMap.getString("FinalDecisionMergeDecCategory"))) && ("No Fraud".equals(bMap.getString("SMFraudStrategyFraudLevel")) || "High Fraud".equals(bMap.getString("SMFraudStrategyFraudLevel")) || "No Fraud".equals(smFraudStrategyFraudLevelK1) || "No Fraud".equals(smFraudStrategyFraudLevelK2)))
						oMap.put("DURUM", "SOZLESME");
					else if (("Policy Accept".equals(bMap.getString("FinalDecisionMergeDecCategory")) || "Accept".equals(bMap.getString("FinalDecisionMergeDecCategory"))) && ("Low Fraud".equals(bMap.getString("SMFraudStrategyFraudLevel")) || "Low Fraud".equals(smFraudStrategyFraudLevelK1) || "Low Fraud".equals(smFraudStrategyFraudLevelK2)))
						oMap.put("DURUM", "ISTIHBARAT");
					else if (("Decline Refer".equals(bMap.getString("FinalDecisionMergeDecCategory")) || "Refer".equals(bMap.getString("FinalDecisionMergeDecCategory"))) || "Accept Refer".equals(bMap.getString("FinalDecisionMergeDecCategory")))
						oMap.put("DURUM", "ISTIHBARAT");
				}
			}

			updateNbsmSorguSonuc(iMap, oMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KKB_JOB")
	public static Map<?, ?> kkbJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			List<?> list = (List<?>) GMServiceExecuter.executeNT("BNSPR_TRN3171_KKB_JOB_LIST", iMap).get("KKB_LIST");
			if (list == null)
				return oMap;
			for (int i = 0; i < list.size(); i++) {
				HashMap tempMap = (HashMap) list.get(i);
				try {
					GMServiceExecuter.executeNT("KKB_JOB_NT", tempMap);
				}
				catch (Exception e) {
					System.out.println("KKB JOB HATA : " + tempMap.get("BASVURU_NO") + " - " + e.toString());
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KKB_JOB_LIST")
	public static Map<?, ?> kkbJobList(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt1 = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt1 = conn.prepareCall("{? = call PKG_BASVURU_SORGU.getKKBJobBasvuru}");
			stmt1.registerOutParameter(1, -10);
			stmt1.execute();

			rSet = (ResultSet) stmt1.getObject(1);
			int row = 0;
			while (rSet.next()) {
				oMap.put("KKB_LIST", row, "NBSM_CALL_TIP_KOD", rSet.getString("NBSM_CALL_TIP_KOD"));
				oMap.put("KKB_LIST", row, "BASVURU_NO", rSet.getString("BASVURU_NO"));
				oMap.put("KKB_LIST", row, "TRX_NO", rSet.getBigDecimal("TX_NO"));
				oMap.put("KKB_LIST", row, "BBE_GEREKLI", rSet.getString("BBE_GEREKLI"));
				oMap.put("KKB_LIST", row, "VYS_DONDUR", rSet.getString("VYS_DONDUR"));
				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("KKB_JOB_NT")
	public static GMMap kkbSorgu(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt2 = null;

		GMMap bMap = new GMMap();
		GMMap b2Map = new GMMap();
		GMMap oMap = new GMMap();

		boolean kkbBasarili = true;

		try {

			String sorguSeviyesi = null;
			sorguSeviyesi = iMap.getString("NBSM_CALL_TIP_KOD");
			iMap.put("SORGU_SEVIYESI", sorguSeviyesi);

			conn = DALUtil.getGMConnection();
			switch (sorguSeviyesi.charAt(0)) {
			case 'F': {
				iMap.put("SORGU_KIM_ICIN", "M");
				kkbBasarili = "E".equals(GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap).get("KKB_BASARILI"));
				if (!kkbBasarili) {
					oMap.put("DURUM", "JOB");
					iMap.put("MESSAGE_NO", new BigDecimal(1506));
					oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
					oMap.put("DEVAM", "H");

					stmt2 = conn.prepareCall("{call pkg_trn3171.updateDurum(?,?)}");
					stmt2.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
					stmt2.setString(2, "JOB");
					stmt2.execute();
					GMServerDatasource.close(stmt2);

					break;
				}
				else {
					iMap.put("KKB_YAPILDI", "E");
					GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
					iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));

					// onceki nbsm datalari
					iMap.putAll(getPrevNbsmData(iMap));

					b2Map.putAll(brmDecisionCall(iMap));
					oMap.put("NBSM_KARAR_KOD", b2Map.getString("FinalDecisionMergeDecCategory"));
					oMap.put("NBSM_FRAUD_KARAR_KOD", b2Map.getString("SMFraudStrategyFraudLevel"));
					oMap.put("CallId", b2Map.getBigDecimal("CallId"));
					oMap.put("NBSM_FRAUD_ONCELIK", b2Map.getString("SMPriorityStrategyFraudQueuePriority"));
					oMap.put("NBSM_UW_ONCELIK", b2Map.getString("SMPriorityStrategyUWQueuePriority"));
					oMap.put("DEVAM", "E");

					String smFraudStrategyFraudQueueYNK1 = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudQueueYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "G"));
					String smFraudStrategyFraudQueueYNK2 = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudQueueYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "L"));

					oMap.put("ADRES_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionAddressDocumentsRequired"));
					oMap.put("GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionIncomeDocumentsRequired"));
					oMap.put("GMENKUL_GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionREMADocumentsRequired"));
					oMap.put("ES_GELIR_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionSpouseDocumentRequired"));
					oMap.put("GARANTORLU_MU", b2Map.getString("StrategyLimitMergeCmpGuarantorF"));
					oMap.put("MUSTERI_BLOKESI_VAR", b2Map.getString("MUSTERI_BLOKESI_VAR"));
					oMap.put("EVTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppHomChReq", b2Map, bMap));
					oMap.put("ISTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppWorkChReq", b2Map, bMap));
					oMap.put("CEPTEL_SORGU_GEREKLI", brmDecisionGetString("SMTelVerAppGSMChReq", b2Map, bMap));
					oMap.put("ES_KKB_SORGU_GEREKLI", brmDecisionGetString("KKBStrategySpoKKBYNRequiredYN", b2Map, bMap));
					oMap.put("TESLIMAT_BELGE_GEREKLI", b2Map.getString("StrategyDocumentExceptionDeliveryDocumentsRequired"));
					oMap.put("IKINCI_KIMLIK_BELGE_GEREKLI", b2Map.getString("SMOtherIDChReq"));

					if ("Policy Decline".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Decline".equals(b2Map.getString("FinalDecisionMergeDecCategory"))) {
						if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")))
							oMap.put("DURUM", "RED");
						// PY-2273
						else if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
						{
							oMap.put("DURUM", "KANALIADE");
							oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
						}
						else if ("Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(smFraudStrategyFraudQueueYNK1) || "Y".equals(smFraudStrategyFraudQueueYNK2))
							oMap.put("DURUM", "FRAUD");

						oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
						oMap.put("DEVAM", "H");
					}
					else {
						// PY-2273
						if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
						{
							oMap.put("DURUM", "KANALIADE");
							oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
							oMap.put("ONAY_TUTAR", b2Map.getBigDecimal("StrategyLimitMergeLimit"));
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
						}
						else {
							oMap.put("ONAY_TUTAR", b2Map.getBigDecimal("StrategyLimitMergeLimit"));
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							String smFraudStrategyFraudLevelK1 = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudLevel").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "G"));
							String smFraudStrategyFraudLevelK2 = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudLevel").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "L"));
							oMap.put("NBSM_KOD", "MAppVer:" + b2Map.getString("FinalStrategyAppVerAppChReq") //
									+ "-MEmptVer:" + b2Map.getString("FinalStrategyEmptVerReqCode") //
									+ "-MFraudVer:" + b2Map.getString("SMFraudStrategyFraudChReq") // PY-2273
									+ "-MWebVer:" + b2Map.getString("FinalStrategyWebChReq") // PY-2273
							);

							if ("Y".equals(b2Map.getString("FinalStrategyGuaYNRequired"))) {
								// kefil alinacak, sm kefil call yapilacak
								oMap.put("KEFIL_GEREKLI", b2Map.getString("FinalStrategyGuaYNRequired"));
								oMap.put("DURUM", "BASVURU");
								if ("Y".equals(b2Map.getString("FinalStrategyAppVerAppChReq")) //
										|| "Home".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
										|| "Work".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
										|| "Web".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
										|| "Y".equals(b2Map.getString("SMFraudStrategyFraudChReq")) // PY-2273
										|| "Y".equals(b2Map.getString("FinalStrategyWebChReq")) // PY-2273
								) {
									// dogrulama ekranina gonderilir, sm final 2 call yapilacak
									oMap.put("NBSM_KOD", "MAppVer:" + b2Map.getString("FinalStrategyAppVerAppChReq") //
											+ "-MEmptVer:" + b2Map.getString("FinalStrategyEmptVerReqCode") //
											+ "-MFraudVer:" + b2Map.getString("SMFraudStrategyFraudChReq") // PY-2273
											+ "-MWebVer:" + b2Map.getString("FinalStrategyWebChReq") // PY-2273
									);
								}
							}
							else if ("N".equals(b2Map.getString("FinalStrategyGuaYNRequired")) //
									&& ("Y".equals(b2Map.getString("FinalStrategyAppVerAppChReq")) //
											|| "Home".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
											|| "Work".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
											|| "Web".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
											|| "Y".equals(b2Map.getString("SMFraudStrategyFraudChReq")) // PY-2273
									|| "Y".equals(b2Map.getString("FinalStrategyWebChReq")) // PY-2273
									) //
							) {
								// dogrulama ekranina gonderilir, sm final 2 call yapilacak
								oMap.put("DURUM", "DOGRULAMA");
								oMap.put("NBSM_KOD", "MAppVer:" + b2Map.getString("FinalStrategyAppVerAppChReq") //
										+ "-MEmptVer:" + b2Map.getString("FinalStrategyEmptVerReqCode") //
										+ "-MFraudVer:" + b2Map.getString("SMFraudStrategyFraudChReq") // PY-2273
										+ "-MWebVer:" + b2Map.getString("FinalStrategyWebChReq") // PY-2273
								);
							}
							else if ("N".equals(b2Map.getString("FinalStrategyGuaYNRequired")) //
									&& "N".equals(b2Map.getString("FinalStrategyAppVerAppChReq")) //
									&& "Not Required".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
									&& "N".equals(b2Map.getString("SMFraudStrategyFraudChReq")) // PY-2273
									&& "N".equals(b2Map.getString("FinalStrategyWebChReq")) // PY-2273
									&& ("Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
											|| "Y".equals(smFraudStrategyFraudQueueYNK1) //
									|| "Y".equals(smFraudStrategyFraudQueueYNK2) //
									) //
							) {
								oMap.put("DURUM", "FRAUD");
							}
							else if ("N".equals(b2Map.getString("FinalStrategyGuaYNRequired")) //
									&& "N".equals(b2Map.getString("FinalStrategyAppVerAppChReq")) //
									&& "Not Required".equals(b2Map.getString("FinalStrategyEmptVerReqCode")) //
									&& "N".equals(b2Map.getString("SMFraudStrategyFraudChReq")) //
									&& "N".equals(b2Map.getString("FinalStrategyWebChReq")) // PY-2273
									&& "N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) // PY-2273
							) {
								if (("Policy Accept".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Accept".equals(b2Map.getString("FinalDecisionMergeDecCategory"))) && ("No Fraud".equals(b2Map.getString("SMFraudStrategyFraudLevel")) || "High Fraud".equals(b2Map.getString("SMFraudStrategyFraudLevel")) || "No Fraud".equals(smFraudStrategyFraudLevelK1) || "No Fraud".equals(smFraudStrategyFraudLevelK2)))
									oMap.put("DURUM", "SOZLESME");
								else if (("Policy Accept".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Accept".equals(b2Map.getString("FinalDecisionMergeDecCategory"))) && ("Low Fraud".equals(b2Map.getString("SMFraudStrategyFraudLevel")) || "Low Fraud".equals(smFraudStrategyFraudLevelK1) || "Low Fraud".equals(smFraudStrategyFraudLevelK2)))
									oMap.put("DURUM", "ISTIHBARAT");
								else if ("Decline Refer".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Refer".equals(b2Map.getString("FinalDecisionMergeDecCategory")) || "Accept Refer".equals(b2Map.getString("FinalDecisionMergeDecCategory")))
									oMap.put("DURUM", "ISTIHBARAT");
							}
						}
					}
				}
				// updateNbsmSorguSonuc(iMap, oMap);
				break;
			}
			case 'G':
				iMap.put("SORGU_KIM_ICIN", "K1");
				kkbBasarili = "E".equals(GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap).get("KKB_BASARILI"));
				if (kkbBasarili) {
					GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
					iMap.put("SORGU_ID", iMap.getBigDecimal("TRX_NO"));
					// Kefil 1 icin NBSM sorgusu
					iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
					// onceki nbsm datalari
					iMap.putAll(getPrevNbsmData(iMap));
					bMap.putAll(brmDecisionCall(iMap));
					String dogrulamaStr = null;
					dogrulamaStr = "K1EmptVer:" + bMap.getString("KefilStrategyGuaEmptVerReqCode") //
							+ "-K1FraudVer:" + bMap.getString("SMFraudStrategyGua1FraudChReq") // PY-2273
					;
					oMap.put("NBSM_FRAUD_ONCELIK", bMap.getString("SMPriorityStrategyFraudQueuePriority"));
					oMap.put("NBSM_UW_ONCELIK", bMap.getString("SMPriorityStrategyUWQueuePriority"));

					if (kefilSayisi(iMap).compareTo(BigDecimal.ONE) >= 1) {
						iMap.put("SORGU_KIM_ICIN", "K2");
						iMap.put("SORGU_SEVIYESI", "L");
						GMServiceExecuter.executeNT("BNSPR_NBSM_TCMB_SORGU", iMap);
						// basvuruFraudTxSorgu(iMap);
						kkbBasarili = "E".equals(GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap).get("KKB_BASARILI"));
						if (kkbBasarili) {
							GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
							// Kefil 2 icin NBSM sorgusu
							iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
							b2Map.putAll(brmDecisionCall(iMap));
							dogrulamaStr = dogrulamaStr + "-K2EmptVer:" + b2Map.getString("KefilStrategyGuaEmptVerReqCode") //
									+ "-K2FraudVer:" + b2Map.getString("SMFraudStrategyGua2FraudChReq") // PY-2273
							;
							oMap.put("NBSM_FRAUD_ONCELIK", b2Map.getString("SMPriorityStrategyFraudQueuePriority"));
							oMap.put("NBSM_UW_ONCELIK", b2Map.getString("SMPriorityStrategyUWQueuePriority"));
						}
						else {
							oMap.put("DURUM", "JOB");
							iMap.put("MESSAGE_NO", new BigDecimal(1506));
							oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
							oMap.put("DEVAM", "H");

							stmt2 = conn.prepareCall("{call pkg_trn3171.updateDurum(?,?)}");
							stmt2.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
							stmt2.setString(2, "JOB");
							stmt2.execute();
							GMServerDatasource.close(stmt2);

							break;
						}
					}
					else
						b2Map = bMap;

					if (kkbBasarili) {
						oMap.put("CallId", b2Map.getBigDecimal("CallId"));
						oMap.put("DEVAM", "E");
						String smFraudStrategyFraudQueueYN = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudQueueYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));

						oMap.put("KEFIL_1_ADRES_BELGE_GEREKLI", bMap.getString("KefilStrategyGuarantorDocumentExceptionGuarantorAddressDocumentsRequired"));
						oMap.put("KEFIL_1_GELIR_BELGE_GEREKLI", bMap.getString("KefilStrategyGuarantorDocumentExceptionGuarantorIncomeDocumentsRequired"));
						oMap.put("KEFIL_2_ADRES_BELGE_GEREKLI", b2Map.getString("KefilStrategyGuarantorDocumentExceptionGuarantorAddressDocumentsRequired"));
						oMap.put("KEFIL_2_GELIR_BELGE_GEREKLI", b2Map.getString("KefilStrategyGuarantorDocumentExceptionGuarantorIncomeDocumentsRequired"));
						oMap.put("KEFIL_1_EVTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1HomChReq"));
						oMap.put("KEFIL_1_ISTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1WorkChReq"));
						oMap.put("KEFIL_1_CEPTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1GSMChReq"));
						oMap.put("KEFIL_2_EVTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2HomChReq"));
						oMap.put("KEFIL_2_ISTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2WorkChReq"));
						oMap.put("KEFIL_2_CEPTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2GSMChReq"));

						if ("Policy Decline".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Decline".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) {
							if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")))
								oMap.put("DURUM", "RED");
							// PY-2273
							else if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
							{
								oMap.put("DURUM", "KANALIADE");
								oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
							}
							else if ("Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(smFraudStrategyFraudQueueYN))
								oMap.put("DURUM", "FRAUD");
							oMap.put("DEVAM", "H");
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
						}
						else {
							// PY-2273
							if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
							{
								oMap.put("DURUM", "KANALIADE");
								oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
								oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
							}
							else {
								oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));

								String finalStrategyAppVerAppChReq = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "FinalStrategyAppVerAppChReq").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
								String finalStrategyEmptVerReqCode = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "FinalStrategyEmptVerReqCode ").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
								String smFraudStrategyFraudChReq = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudChReq ").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
								String finalStrategyWebChReq = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "FinalStrategyWebChReq ").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F")); // PY-2273
								String smFraudStrategyFraudLevel = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudLevel").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F")); // PY-2273

								if ("Y".equals(finalStrategyAppVerAppChReq) //
										|| !("Not Required".equals(finalStrategyEmptVerReqCode)) //
										|| "Home".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
										|| "Work".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
										|| "Web".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
										|| "Home".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
										|| "Work".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
										|| "Web".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
										|| "Y".equals(smFraudStrategyFraudChReq) // PY-2273
										|| "Y".equals(finalStrategyWebChReq) // PY-2273
										|| "Y".equals(bMap.getString("SMFraudStrategyGua1FraudChReq")) // PY-2273
										|| "Y".equals(b2Map.getString("SMFraudStrategyGua2FraudChReq")) // PY-2273
								) {
									// dogrulama ekranina gonderilir, sm final 2 call yapilacak
									oMap.put("DURUM", "DOGRULAMA");
									oMap.put("NBSM_KOD", dogrulamaStr);
								}
								else if ("N".equals(finalStrategyAppVerAppChReq) //
										&& "Not Required".equals(finalStrategyEmptVerReqCode) //
										&& "Not Required".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
										&& "Not Required".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
										&& "N".equals(smFraudStrategyFraudChReq) // PY-2273
										&& "N".equals(finalStrategyWebChReq) // PY-2273
										&& "N".equals(nvlString(bMap.getString("SMFraudStrategyGua1FraudChReq"), "N")) // PY-2273
										&& "N".equals(nvlString(b2Map.getString("SMFraudStrategyGua2FraudChReq"), "N")) // PY-2273
										&& ("Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
												|| "Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) //
										|| "Y".equals(smFraudStrategyFraudQueueYN) //
										) //
								) {
									oMap.put("DURUM", "FRAUD");
								}
								else if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) && (("Low Fraud").equals(smFraudStrategyFraudLevel) || ("Low Fraud").equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || ("Low Fraud").equals(b2Map.getString("SMFraudStrategyGua2FraudLevel"))))
									oMap.put("DURUM", "ISTIHBARAT");
								else if ("N".equals(finalStrategyAppVerAppChReq) //
										&& "Not Required".equals(finalStrategyEmptVerReqCode) //
										&& "Not Required".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) // 1.kefilin
										&& "Not Required".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) // 2.kefilin
										&& "N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
										&& "N".equals(smFraudStrategyFraudChReq) // PY-2273
										&& "N".equals(finalStrategyWebChReq) // PY-2273
										&& "N".equals(nvlString(bMap.getString("SMFraudStrategyGua1FraudChReq"), "N")) // PY-2273
										&& "N".equals(nvlString(b2Map.getString("SMFraudStrategyGua2FraudChReq"), "N")) // PY-2273
								) {
									if (("Policy Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) && ("No Fraud".equals(b2Map.getString("SMFraudStrategyGua2FraudLevel")) || "No Fraud".equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || "No Fraud".equals(smFraudStrategyFraudLevel) || "High Fraud".equals(smFraudStrategyFraudLevel)))
										oMap.put("DURUM", "SOZLESME");
									else if (("Policy Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) && ("Low Fraud".equals(b2Map.getString("SMFraudStrategyGua2FraudLevel")) || "Low Fraud".equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || "Low Fraud".equals(smFraudStrategyFraudLevel)))
										oMap.put("DURUM", "ISTIHBARAT");
									else if ("Decline Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")))
										oMap.put("DURUM", "ISTIHBARAT");
								}
							}
						}
					}
					oMap.put("NBSM_KARAR_KOD", b2Map.getString("KefilKefil1Kefil2DecCategory"));
					// updateNbsmSorguSonuc(iMap, oMap);
				}
				else {
					oMap.put("DURUM", "JOB");
					iMap.put("MESSAGE_NO", new BigDecimal(1506));
					oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
					oMap.put("DEVAM", "H");

					stmt2 = conn.prepareCall("{call pkg_trn3171.updateDurum(?,?)}");
					stmt2.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
					stmt2.setString(2, "JOB");
					stmt2.execute();
					GMServerDatasource.close(stmt2);

				}
				break;
			case 'L':
				String dogrulamaStr = null;
				iMap.put("SORGU_KIM_ICIN", "K2");
				kkbBasarili = "E".equals(GMServiceExecuter.executeNT("BNSPR_NBSM_KKB_SORGU", iMap).get("KKB_BASARILI"));

				if (kkbBasarili) {
					GMServiceExecuter.executeNT("BNSPR_NBSM_FRAUD_SORGU", iMap);
					// Kefil 2 icin NBSM sorgusu
					iMap.put("SMCallType", iMap.getString("SORGU_SEVIYESI"));
					b2Map.putAll(brmDecisionCall(iMap));

					dogrulamaStr = dogrulamaStr + "-K2EmptVer:" + b2Map.getString("KefilStrategyGuaEmptVerReqCode") //
							+ "-K2FraudVer:" + b2Map.getString("SMFraudStrategyGua2FraudChReq") // PY-2273
					;
					oMap.put("NBSM_FRAUD_ONCELIK", b2Map.getString("SMPriorityStrategyFraudQueuePriority"));
					oMap.put("NBSM_UW_ONCELIK", b2Map.getString("SMPriorityStrategyUWQueuePriority"));
				}
				else {
					oMap.put("DURUM", "JOB");
					iMap.put("MESSAGE_NO", new BigDecimal(1506));
					oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
					oMap.put("DEVAM", "H");

					stmt2 = conn.prepareCall("{call pkg_trn3171.updateDurum(?,?)}");
					stmt2.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
					stmt2.setString(2, "JOB");
					stmt2.execute();
					GMServerDatasource.close(stmt2);

					break;
				}
				if (kkbBasarili) {
					oMap.put("CallId", b2Map.getBigDecimal("CallId"));
					oMap.put("DEVAM", "E");
					String smFraudStrategyFraudQueueYN = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudQueueYN").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));

					oMap.put("KEFIL_1_ADRES_BELGE_GEREKLI", bMap.getString("KefilStrategyGuarantorDocumentExceptionGuarantorAddressDocumentsRequired"));
					oMap.put("KEFIL_1_GELIR_BELGE_GEREKLI", bMap.getString("KefilStrategyGuarantorDocumentExceptionGuarantorIncomeDocumentsRequired"));
					oMap.put("KEFIL_2_ADRES_BELGE_GEREKLI", b2Map.getString("KefilStrategyGuarantorDocumentExceptionGuarantorAddressDocumentsRequired"));
					oMap.put("KEFIL_2_GELIR_BELGE_GEREKLI", b2Map.getString("KefilStrategyGuarantorDocumentExceptionGuarantorIncomeDocumentsRequired"));
					oMap.put("KEFIL_1_EVTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1HomChReq"));
					oMap.put("KEFIL_1_ISTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1WorkChReq"));
					oMap.put("KEFIL_1_CEPTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua1GSMChReq"));
					oMap.put("KEFIL_2_EVTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2HomChReq"));
					oMap.put("KEFIL_2_ISTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2WorkChReq"));
					oMap.put("KEFIL_2_CEPTEL_SORGU_GEREKLI", b2Map.getString("SMTelVerGua2GSMChReq"));

					if ("Policy Decline".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Decline".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) {
						if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")))
							oMap.put("DURUM", "RED");
						// PY-2273
						else if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
						{
							oMap.put("DURUM", "KANALIADE");
							oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
						}
						else if ("Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) || "Y".equals(smFraudStrategyFraudQueueYN))
							oMap.put("DURUM", "FRAUD");
						oMap.put("DEVAM", "H");
						oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
					}
					else {
						// PY-2273
						if ("Y".equals(b2Map.getString("FinalStrategyReturnReq"))) // Iade gerekli
						{
							oMap.put("DURUM", "KANALIADE");
							oMap.put("NBSM_KARAR_GEREKCE", b2Map.getString("FinalStrategyReturnReasonCode"));
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));
						}
						else {
							oMap.put("MESSAGE", "".equals(b2Map.getString("SMCommunicationStrategyMessage")) ? null : b2Map.getString("SMCommunicationStrategyMessage"));

							String finalStrategyAppVerAppChReq = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "FinalStrategyAppVerAppChReq").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
							String finalStrategyEmptVerReqCode = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "FinalStrategyEmptVerReqCode").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
							String smFraudStrategyFraudChReq = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudChReq ").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F"));
							String finalStrategyWebChReq = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "FinalStrategyWebChReq ").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F")); // PY-2273
							String smFraudStrategyFraudLevel = getPrevNbsmOutputValue(new GMMap().put("NBSM_KEY", "SMFraudStrategyFraudLevel").put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO")).put("SORGU_SEVIYESI", "F")); // PY-2273

							if ("Y".equals(finalStrategyAppVerAppChReq) //
									|| !("Not Required".equals(finalStrategyEmptVerReqCode)) //
									|| "Home".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Work".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Web".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Home".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Work".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Web".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
									|| "Y".equals(smFraudStrategyFraudChReq) // PY-2273
									|| "Y".equals(finalStrategyWebChReq) // PY-2273
									|| "Y".equals(bMap.getString("SMFraudStrategyGua1FraudChReq")) // PY-2273
									|| "Y".equals(b2Map.getString("SMFraudStrategyGua2FraudChReq")) // PY-2273
							) {
								// dogrulama ekranina gonderilir, sm final 2 call yapilacak
								oMap.put("DURUM", "DOGRULAMA");
								oMap.put("NBSM_KOD", dogrulamaStr);
							}
							else if ("N".equals(finalStrategyAppVerAppChReq) //
									&& "Not Required".equals(finalStrategyEmptVerReqCode) //
									&& "Not Required".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) //
									&& "Not Required".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) //
									&& "N".equals(smFraudStrategyFraudChReq) // PY-2273
									&& "N".equals(finalStrategyWebChReq) // PY-2273
									&& "N".equals(nvlString(bMap.getString("SMFraudStrategyGua1FraudChReq"), "N")) // PY-2273
									&& "N".equals(nvlString(b2Map.getString("SMFraudStrategyGua2FraudChReq"), "N")) // PY-2273
									&& ("Y".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
											|| "Y".equals(bMap.getString("SMFraudStrategyFraudQueueYN")) //
									|| "Y".equals(smFraudStrategyFraudQueueYN) //
									) //
							) {
								oMap.put("DURUM", "FRAUD");
							}
							else if ("N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) && (("Low Fraud").equals(smFraudStrategyFraudLevel) || ("Low Fraud").equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || ("Low Fraud").equals(b2Map.getString("SMFraudStrategyGua2FraudLevel"))))
								oMap.put("DURUM", "ISTIHBARAT");
							else if ("N".equals(finalStrategyAppVerAppChReq) //
									&& "Not Required".equals(finalStrategyEmptVerReqCode) //
									&& "Not Required".equals(bMap.getString("KefilStrategyGuaEmptVerReqCode")) // 1.kefilin
									&& "Not Required".equals(b2Map.getString("KefilStrategyGuaEmptVerReqCode")) // 2.kefilin
									&& "N".equals(b2Map.getString("SMFraudStrategyFraudQueueYN")) //
									&& "N".equals(smFraudStrategyFraudChReq) // PY-2273
									&& "N".equals(finalStrategyWebChReq) // PY-2273
									&& "N".equals(nvlString(bMap.getString("SMFraudStrategyGua1FraudChReq"), "N")) // PY-2273
									&& "N".equals(nvlString(b2Map.getString("SMFraudStrategyGua2FraudChReq"), "N")) // PY-2273
							) {
								if (("Policy Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) && ("No Fraud".equals(b2Map.getString("SMFraudStrategyGua2FraudLevel")) || "No Fraud".equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || "No Fraud".equals(smFraudStrategyFraudLevel)) || "High Fraud".equals(smFraudStrategyFraudLevel))
									oMap.put("DURUM", "SOZLESME");
								else if (("Policy Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept".equals(b2Map.getString("KefilKefil1Kefil2DecCategory"))) && ("Low Fraud".equals(b2Map.getString("SMFraudStrategyGua2FraudLevel")) || "Low Fraud".equals(bMap.getString("SMFraudStrategyGua1FraudLevel")) || "Low Fraud".equals(smFraudStrategyFraudLevel)))
									oMap.put("DURUM", "ISTIHBARAT");
								else if ("Decline Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")) || "Accept Refer".equals(b2Map.getString("KefilKefil1Kefil2DecCategory")))
									oMap.put("DURUM", "ISTIHBARAT");
							}
						}
					}
				}
				oMap.put("NBSM_KARAR_KOD", b2Map.getString("KefilKefil1Kefil2DecCategory"));
				// updateNbsmSorguSonuc(iMap, oMap);

				break;

			default:
				break;
			}
			if ("E".equals(oMap.getString("DEVAM"))) {
				iMap.put("TRX_NAME", "3171");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			}
			updateNbsmSorguSonuc(iMap, oMap);

			stmt2 = conn.prepareCall("{call PKG_BASVURU_SORGU.finishKKBJob(?,?,?)}");
			stmt2.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt2.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt2.setString(3, oMap.getString("DURUM"));
			stmt2.execute();
			GMServerDatasource.close(stmt2);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}

		return new GMMap();
	}

	public static void fillNbsmDeger(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_RC_NBSM.fill_nbsm_deger(?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("SMCallType"));

			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static String nvlString(String str1, String str2) {
		if (str1 != null)
			return str1;
		else
			return str2;
	}
}
