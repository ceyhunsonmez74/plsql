package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.biff.EmptyCell;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.VdmkKrediDevirDemoTx;
import tr.com.aktifbank.bnspr.dao.VdmkKrediDevirDemoTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3260Services {
	
	@GraymoundService("BNSPR_TRN3260_UPLOAD_EXCEL")
	public static GMMap uploadExcel(GMMap iMap){
		GMMap oMap = new GMMap();
		try{			
			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("ISO-8859-9");
			
			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet dataSheet = workbook.getSheet(0);
			
			String tableName = "TABLO";
			int row = 0;
			for(int i=0; i<dataSheet.getRows(); i++){
				
				if(dataSheet.getCell(0, i) instanceof EmptyCell){
					continue;
				}else{
					String referans = dataSheet.getCell(0, i).getContents();
					String basvuru_no = dataSheet.getCell(1, i).getContents();
					
					if(referans != null && !referans.trim().isEmpty()){
						BigDecimal basvuruNo = new BigDecimal(basvuru_no);
						
						oMap.put(tableName, row, "BASVURU_NO", basvuruNo);
						oMap.put(tableName, row, "REFERANS", referans);
						row++;
					}
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3260_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		List<VdmkKrediDevirDemoTx> infoList = session.createCriteria(VdmkKrediDevirDemoTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		
		int row = 0;
		String tableName = "TABLO";
		for(VdmkKrediDevirDemoTx infoRecord : infoList){
            oMap.put(tableName, row, "BASVURU_NO", infoRecord.getId().getBasvuruNo());
            oMap.put(tableName, row, "REFERANS", infoRecord.getId().getReferans());
			row++;
		}
		
		return oMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3260_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<VdmkKrediDevirDemoTx> removalList = session.createCriteria(VdmkKrediDevirDemoTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for(VdmkKrediDevirDemoTx record : removalList){
				session.delete(record);
			}
			session.flush();
			
			String tn = "TABLO";
			VdmkKrediDevirDemoTx tx;
			for(int i=0; i<iMap.getSize(tn);i++){
			    tx = new VdmkKrediDevirDemoTx(new VdmkKrediDevirDemoTxId());
			    tx.getId().setTxNo(iMap.getBigDecimal("TRX_NO"));
                tx.getId().setBasvuruNo(iMap.getBigDecimal(tn, i,"BASVURU_NO"));
                tx.getId().setReferans(iMap.getString(tn, i,"REFERANS"));
				session.save(tx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3260");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (org.hibernate.NonUniqueObjectException e) {
            iMap.put("HATA_NO", new BigDecimal(660));
            iMap.put("P1", "Birbirinin ayn� iki veri olamaz!!");
            return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
	}
}
