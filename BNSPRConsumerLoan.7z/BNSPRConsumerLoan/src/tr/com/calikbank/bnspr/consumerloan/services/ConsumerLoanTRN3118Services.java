package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirProjeLimitPrTx;
import tr.com.calikbank.bnspr.dao.BirProjeLimitPrTxId;
import tr.com.calikbank.bnspr.dao.BirProjePrTx;
import tr.com.calikbank.bnspr.dao.BirProjePrTxId;
import tr.com.calikbank.bnspr.dao.BirProjeSinirPrTx;
import tr.com.calikbank.bnspr.dao.BirProjeSinirPrTxId;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3118Services {
	
	@GraymoundService("BNSPR_TRN3118_GET_PROJECT_INFO")
	public static GMMap trn3118GetProjectInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirProjePrTx.class).add(Restrictions.eq("id.kod", iMap.getBigDecimal("PROJE_KOD"))).addOrder(Order.desc("id.txNo")).list();
			BirProjePrTx birProjePrTx  = (BirProjePrTx)list.iterator().next();
			
			oMap.put("BASLANGIC_TAR", birProjePrTx.getBaslangicTar());
			oMap.put("BITIS_TAR", birProjePrTx.getBitisTar());
			oMap.put("STATU", birProjePrTx.getStatu());
			oMap.put("KREDI_TURU", LovHelper.diLov(birProjePrTx.getKrediTuru(), "3118/LOV_KREDI_TURU", "KREDI_TURU"));
			oMap.put("KREDI_KOD", LovHelper.diLov(birProjePrTx.getKrediTuru(), "3118/LOV_KREDI_TURU", "KREDI_KOD"));
			oMap.put("DAGITICI_FIRMA_KOD", LovHelper.diLov(birProjePrTx.getDagiticiFirmaKod(), "3118/LOV_DAGITICI_FIRMA", "DAGITICI_FIRMA_KOD"));
			oMap.put("DAGITICI_FIRMA_ADI", LovHelper.diLov(birProjePrTx.getDagiticiFirmaKod(), "3118/LOV_DAGITICI_FIRMA", "DAGITICI_FIRMA_AD"));
			oMap.put("YUKLENICI_FIRMA_KOD", LovHelper.diLov(birProjePrTx.getYukleniciFirmaMusteriNo(), "3118/LOV_YUKLENICI_FIRMA", "MUSTERI_NO"));
			oMap.put("YUKLENICI_FIRMA_ADI", LovHelper.diLov(birProjePrTx.getYukleniciFirmaMusteriNo(), "3118/LOV_YUKLENICI_FIRMA", "UNVAN"));
			oMap.put("GARANTOR_FIRMA", birProjePrTx.getGarantorFirma());
			oMap.put("GARANTI_TAAH_VEREN", birProjePrTx.getGarantiTaahVerenFirma());
			oMap.put("PROJE_HACMI", birProjePrTx.getProjeHacmi());
			oMap.put("IPOTEK_TAR", birProjePrTx.getIpotekKonulacakTar());
			oMap.put("KRD_KONU_GMENKUL_ADEDI", birProjePrTx.getKrediyeKonuGmenkulAdedi());
			oMap.put("HAYAT_SIG_ISTISNASI", birProjePrTx.getHayatSigIstisnasiTalepMi());
			oMap.put("HAYAT_MAX_VADE", birProjePrTx.getHayatSigMaxVade());
			oMap.put("HAYAT_MAX_LTV", birProjePrTx.getHayatSigMaxKrdOrani());
			oMap.put("KASKO_SIG_ISTISNASI", birProjePrTx.getKaskoSigIstisnasiTalepMi());
			oMap.put("KASKO_MAX_VADE", birProjePrTx.getKaskoSigMaxVade());
			oMap.put("KASKO_MAX_LTV", birProjePrTx.getKaskoSigMaxKrdOrani());
			oMap.put("INSAAT_BASLANGIC_TAR", birProjePrTx.getInsaatBasTar());
			String tamamlanmaSuresi = birProjePrTx.getTamamlamaSuresi();
			if(tamamlanmaSuresi != null && tamamlanmaSuresi.length() == 4)
			{
				String tamamlanmaSuresiYil = tamamlanmaSuresi.substring(0, 2);
				if(tamamlanmaSuresiYil.length() == 2 && tamamlanmaSuresiYil.charAt(0) == '0')
					tamamlanmaSuresiYil = tamamlanmaSuresiYil.substring(1);
				oMap.put("TAMAMLANMA_SURE_YIL", tamamlanmaSuresiYil);
				String tamamlanmaSuresiAy = tamamlanmaSuresi.substring(2, 4);
				if(tamamlanmaSuresiAy.length() == 2 && tamamlanmaSuresiAy.charAt(0) == '0')
					tamamlanmaSuresiAy = tamamlanmaSuresiAy.substring(1);
				oMap.put("TAMAMLANMA_SURE_AY", tamamlanmaSuresiAy);
				
			}
			oMap.put("INSAAT_SEVIYESI_TEXT", LovHelper.diLov(birProjePrTx.getInsaatSeviyesi(), "3118/LOV_INSAAT_SEVIYESI", "INSAAT_SEVIYESI"));
			oMap.put("INSAAT_SEVIYESI", LovHelper.diLov(birProjePrTx.getInsaatSeviyesi(), "3118/LOV_INSAAT_SEVIYESI", "KOD"));
			oMap.put("EKSPERTIZE", birProjePrTx.getEkspertizYapilacakMi());
			oMap.put("IMAR_DURUM_BELGESI", birProjePrTx.getImarDurumBelgesi());
			oMap.put("KONUT_SIG_TAAH", birProjePrTx.getKonutSigortasiTaahVarmi());
			oMap.put("KONUT_TESLIM_TAR", birProjePrTx.getKonutTeslimTar());
			oMap.put("GMENKUL_ADEDI", birProjePrTx.getGmenkulAdedi());
			oMap.put("INSAAT_RUHSAT", birProjePrTx.getInsaatRuhsati());
			oMap.put("INSAAT_RUHSAT_TAR", birProjePrTx.getInsaatRuhsatTar());
			oMap.put("KOOPERATIF", birProjePrTx.getKooperatifMi());
			oMap.put("PROJEYI_YAPAN_KOOPERATIF", birProjePrTx.getProjeyiYapanKoop());
			oMap.put("INSAATI_YAPAN_MUT_FIRMA", birProjePrTx.getInsaatiYapanMutFirma());
			oMap.put("ARSA_SAHIBI", birProjePrTx.getArsaSahibi());
			oMap.put("ARSA_HARIC_M2_INS_MALIYETI", birProjePrTx.getArsaHaricM2InsaatMaliyeti());
			oMap.put("KONUT_DEGERI", birProjePrTx.getKonutDegeri());
			oMap.put("ARSA_SAHIBINE_VER_KONUT_ADEDI", birProjePrTx.getArsaSahibineVerKonutAdedi());
			oMap.put("YUKLENICIYE_VER_KONUT_ADEDI", birProjePrTx.getYukleniciyeVerKonutAdedi());
			oMap.put("MAX_KREDI_TUTARI", birProjePrTx.getMaxKrediTutari());
			oMap.put("KOOP_ODENEN_TOPLAM_AIDATI", birProjePrTx.getUyelerinKoopOdedigiToplam());
			oMap.put("BLOK_ADEDI", birProjePrTx.getBlokAdedi());
			oMap.put("TOPLAM_DAIRE_ADEDI", birProjePrTx.getToplamDaireAdedi());
			oMap.put("UYE_ADEDI", birProjePrTx.getUyeAdedi());
			oMap.put("KREDI_KUL_UYE_ADEDI", birProjePrTx.getKrediKullanacakUyeAdedi());
			oMap.put("SATILMIS_KONUT_ADEDI", birProjePrTx.getSatilmisKonutAdedi());
			oMap.put("SATILMAMIS_KONUT_ADEDI", birProjePrTx.getSatilmamisKonutAdedi());
			oMap.put("UYE_PROFILI", birProjePrTx.getUyeProfili());
			oMap.put("AYLIK_KOOP_AIDATI", birProjePrTx.getAylikKoopAidati());
			oMap.put("GORUS", birProjePrTx.getGorus());
			oMap.put("KURUMSAL_TAHSIS_KOSULLARI", birProjePrTx.getKurumsalTahsisKosullari());
			oMap.put("BIREYSEL_TAHSIS_KOSULLARI", birProjePrTx.getBireyselTahsisKosullari());
			oMap.put("KONUT_TASIT_MAX_YAS", birProjePrTx.getKonutTasitMaxYasi());
			
			getSinirTable("UST_DUZEY_TABLE", "1", iMap, oMap, session);
			getSinirTable("ESIT_ODEMELI_TABLE", "2", iMap, oMap, session);
			getSinirTable("ODEMESIZ_DONEMLI_TABLE", "3", iMap, oMap, session);
			
			List<?> limitList = (List<?>) session.createCriteria(BirProjeLimitPrTx.class).add(Restrictions.eq("id.projeKod", iMap.getBigDecimal("PROJE_KOD"))).list();
			String tableName = "LIMIT_PARAM_TABLE";
			int row = 0;
			for (Iterator<?> iterator = limitList.iterator(); iterator.hasNext();row++) {
				BirProjeLimitPrTx birProjeLimitPr = (BirProjeLimitPrTx) iterator.next();
				oMap.put(tableName, row, "DOVIZ_KODU", LovHelper.diLov(birProjeLimitPr.getId().getDovizKodu(), "3118/LOV_DOVIZ", "KOD"));
				oMap.put(tableName, row, "GARANTI_TAAH_ORANI", birProjeLimitPr.getGarantiTaahOrani());
				oMap.put(tableName, row, "GARANTOR_ORANI", birProjeLimitPr.getGarantorOrani());
				oMap.put(tableName, row, "ORJ_LIMIT_TUTARI", birProjeLimitPr.getOrjLimitTutari());
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3118_SAVE_PROJECT_INFO")
	public static Map<?, ?> saveMarkaModel(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirProjePrTx birProjePrTx =  (BirProjePrTx) session.createCriteria(BirProjePrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birProjePrTx == null)
				birProjePrTx = new BirProjePrTx();
			
			BirProjePrTxId id = new BirProjePrTxId();
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setKod(iMap.getBigDecimal("PROJE_KOD"));
			birProjePrTx.setId(id);
			birProjePrTx.setAdi(iMap.getString("PROJE_ADI"));
			birProjePrTx.setBaslangicTar(iMap.getDate("BASLANGIC_TAR"));
			birProjePrTx.setBitisTar(iMap.getDate("BITIS_TAR"));
			birProjePrTx.setStatu(iMap.getString("STATU"));
			birProjePrTx.setKrediTuru(iMap.getBigDecimal("KREDI_KOD"));
			birProjePrTx.setDagiticiFirmaKod(iMap.getBigDecimal("DAGITICI_FIRMA_KOD"));
			birProjePrTx.setYukleniciFirmaMusteriNo(iMap.getBigDecimal("YUKLENICI_FIRMA_KOD"));
			birProjePrTx.setGarantorFirma(iMap.getString("GARANTOR_FIRMA"));
			birProjePrTx.setGarantiTaahVerenFirma(iMap.getString("GARANTI_TAAH_VEREN"));
			birProjePrTx.setProjeHacmi(iMap.getBigDecimal("PROJE_HACMI"));
			birProjePrTx.setIpotekKonulacakTar(iMap.getDate("IPOTEK_TAR"));
			birProjePrTx.setKrediyeKonuGmenkulAdedi(iMap.getBigDecimal("KRD_KONU_GMENKUL_ADEDI"));
			birProjePrTx.setHayatSigIstisnasiTalepMi(iMap.getString("HAYAT_SIG_ISTISNASI"));
			birProjePrTx.setHayatSigMaxVade(iMap.getBigDecimal("HAYAT_MAX_VADE"));
			birProjePrTx.setHayatSigMaxKrdOrani(iMap.getBigDecimal("HAYAT_MAX_LTV"));
			birProjePrTx.setKaskoSigIstisnasiTalepMi(iMap.getString("KASKO_SIG_ISTISNASI"));
			birProjePrTx.setKaskoSigMaxVade(iMap.getBigDecimal("KASKO_MAX_VADE"));
			birProjePrTx.setKaskoSigMaxKrdOrani(iMap.getBigDecimal("KASKO_MAX_LTV"));
			birProjePrTx.setInsaatBasTar(iMap.getDate("INSAAT_BASLANGIC_TAR"));
			String tamamlanmaSuresiYil = iMap.getString("TAMAMLANMA_SURE_YIL");
			if(tamamlanmaSuresiYil == null || tamamlanmaSuresiYil.length() == 0 )
				tamamlanmaSuresiYil = "00";
			else if(tamamlanmaSuresiYil.length() == 1)
				tamamlanmaSuresiYil = "0" + tamamlanmaSuresiYil;
			String tamamlanmaSuresiAy = iMap.getString("TAMAMLANMA_SURE_AY");
			if(tamamlanmaSuresiAy == null || tamamlanmaSuresiAy.length() == 0)
				tamamlanmaSuresiAy = "00";
			else if(tamamlanmaSuresiAy.length() == 1)
				tamamlanmaSuresiAy = "0" + tamamlanmaSuresiAy;
			birProjePrTx.setTamamlamaSuresi(tamamlanmaSuresiYil + tamamlanmaSuresiAy);
			birProjePrTx.setInsaatSeviyesi(iMap.getString("INSAAT_SEVIYESI"));
			birProjePrTx.setEkspertizYapilacakMi(iMap.getString("EKSPERTIZE"));
			birProjePrTx.setImarDurumBelgesi(iMap.getString("IMAR_DURUM_BELGESI"));
			birProjePrTx.setKonutSigortasiTaahVarmi(iMap.getString("KONUT_SIG_TAAH"));
			birProjePrTx.setKonutTeslimTar(iMap.getDate("KONUT_TESLIM_TAR"));
			birProjePrTx.setGmenkulAdedi(iMap.getBigDecimal("GMENKUL_ADEDI"));
			birProjePrTx.setInsaatRuhsati(iMap.getString("INSAAT_RUHSAT"));
			birProjePrTx.setInsaatRuhsatTar(iMap.getDate("INSAAT_RUHSAT_TAR"));
			birProjePrTx.setKooperatifMi(iMap.getString("KOOPERATIF"));
			birProjePrTx.setProjeyiYapanKoop(iMap.getString("PROJEYI_YAPAN_KOOPERATIF"));
			birProjePrTx.setInsaatiYapanMutFirma(iMap.getString("INSAATI_YAPAN_MUT_FIRMA"));
			birProjePrTx.setArsaSahibi(iMap.getString("ARSA_SAHIBI"));
			birProjePrTx.setArsaHaricM2InsaatMaliyeti(iMap.getBigDecimal("ARSA_HARIC_M2_INS_MALIYETI"));
			birProjePrTx.setArsaSahibineVerKonutAdedi(iMap.getBigDecimal("ARSA_SAHIBINE_VER_KONUT_ADEDI"));
			birProjePrTx.setKonutDegeri(iMap.getBigDecimal("KONUT_DEGERI"));
			birProjePrTx.setYukleniciyeVerKonutAdedi(iMap.getBigDecimal("YUKLENICIYE_VER_KONUT_ADEDI"));
			birProjePrTx.setMaxKrediTutari(iMap.getBigDecimal("MAX_KREDI_TUTARI"));
			birProjePrTx.setUyelerinKoopOdedigiToplam(iMap.getBigDecimal("KOOP_ODENEN_TOPLAM_AIDATI"));
			birProjePrTx.setBlokAdedi(iMap.getBigDecimal("BLOK_ADEDI"));
			birProjePrTx.setToplamDaireAdedi(iMap.getBigDecimal("TOPLAM_DAIRE_ADEDI"));
			birProjePrTx.setUyeAdedi(iMap.getBigDecimal("UYE_ADEDI"));
			birProjePrTx.setKrediKullanacakUyeAdedi(iMap.getBigDecimal("KREDI_KUL_UYE_ADEDI"));
			birProjePrTx.setSatilmisKonutAdedi(iMap.getBigDecimal("SATILMIS_KONUT_ADEDI"));
			birProjePrTx.setSatilmamisKonutAdedi(iMap.getBigDecimal("SATILMAMIS_KONUT_ADEDI"));
			birProjePrTx.setUyeProfili(iMap.getString("UYE_PROFILI"));
			birProjePrTx.setAylikKoopAidati(iMap.getBigDecimal("AYLIK_KOOP_AIDATI"));
			birProjePrTx.setGorus(iMap.getString("GORUS"));
			birProjePrTx.setKurumsalTahsisKosullari(iMap.getString("KURUMSAL_TAHSIS_KOSULLARI"));
			birProjePrTx.setBireyselTahsisKosullari(iMap.getString("BIREYSEL_TAHSIS_KOSULLARI"));
			birProjePrTx.setKonutTasitMaxYasi(iMap.getBigDecimal("KONUT_TASIT_MAX_YAS"));
			
			session.saveOrUpdate(birProjePrTx);
			session.flush();
			
			saveSinirTable("UST_DUZEY_TABLE", "1", iMap, session);
			saveSinirTable("ESIT_ODEMELI_TABLE", "2", iMap, session);
			saveSinirTable("ODEMESIZ_DONEMLI_TABLE", "3", iMap, session);

			String tableName = "LIMIT_PARAM_TABLE";
			List<?> list = (List<?>) iMap.get(tableName);

			for (int j = 0; j < list.size(); j++) {
				if(iMap.getString(tableName, j, "DOVIZ_KODU") == null)
				{
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Limit Tan�mlama Tablosu");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					return null;
				}
				BirProjeLimitPrTx birProjeLimitPrTx = (BirProjeLimitPrTx) session.get(BirProjeLimitPrTx.class, new BirProjeLimitPrTxId(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("PROJE_KOD"), iMap.getString(tableName, j, "DOVIZ_KODU")));
				if (birProjeLimitPrTx == null){
					birProjeLimitPrTx = new BirProjeLimitPrTx();
					BirProjeLimitPrTxId id3 = new BirProjeLimitPrTxId();
					id3.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id3.setProjeKod(iMap.getBigDecimal("PROJE_KOD"));
					id3.setDovizKodu(iMap.getString(tableName, j, "DOVIZ_KODU"));
				
					birProjeLimitPrTx.setId(id3);
				}
				else{
					iMap.put("HATA_NO", new BigDecimal(723));
					iMap.put("P1", "Limit Tan�mlama Tablosu");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				birProjeLimitPrTx.setOrjLimitTutari(iMap.getBigDecimal(tableName, j, "ORJ_LIMIT_TUTARI"));
				birProjeLimitPrTx.setGarantorOrani((iMap.getBigDecimal(tableName, j, "GARANTOR_ORANI") == null) ? new BigDecimal(0) : iMap.getBigDecimal(tableName, j, "GARANTOR_ORANI"));
				birProjeLimitPrTx.setGarantiTaahOrani((iMap.getBigDecimal(tableName, j, "GARANTI_TAAH_ORANI") == null) ? new BigDecimal(0) : iMap.getBigDecimal(tableName, j, "GARANTI_TAAH_ORANI"));
				
				session.saveOrUpdate(birProjeLimitPrTx);
				session.flush();
			}
			
			iMap.put("TRX_NAME", "3118");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static void saveSinirTable(String tableName, String tip, GMMap iMap, Session session)
		throws Exception {
		List<?> list = (List<?>) iMap.get(tableName);
		
		for (int j = 0; j < list.size(); j++) {
			String hataTable = "";
			switch (tip.charAt(0) - '0') {
			case 1:
				hataTable = "�st D�zey S�n�rlama Tablosu";
				break;
			case 2:
				hataTable = "E�it �demeli S�n�rlama Tablosu";
				break;
			case 3:
				hataTable = "�demesiz D�nemli S�n�rlama Tablosu";
				break;
			default:
				break;
			}
			if(iMap.getString(tableName, j, "DOVIZ_KODU") == null)
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", hataTable);
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				return;
			}
			BirProjeSinirPrTx birProjeSinirPrTx = (BirProjeSinirPrTx) session.get(BirProjeSinirPrTx.class, new BirProjeSinirPrTxId(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("PROJE_KOD"), iMap.getString(tableName, j, "DOVIZ_KODU"), tip));
			if (birProjeSinirPrTx == null){
				birProjeSinirPrTx = new BirProjeSinirPrTx();
				BirProjeSinirPrTxId id2 = new BirProjeSinirPrTxId();
				id2.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id2.setProjeKod(iMap.getBigDecimal("PROJE_KOD"));
				id2.setDovizKodu(iMap.getString(tableName, j, "DOVIZ_KODU"));
				id2.setTip(tip); 
			
				birProjeSinirPrTx.setId(id2);
			}
			else{
				iMap.put("HATA_NO", new BigDecimal(723));
				iMap.put("P1", hataTable);
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			birProjeSinirPrTx.setMaxLtv(iMap.getBigDecimal(tableName, j, "MAX_LTV") == null ? new BigDecimal(0) : iMap.getBigDecimal(tableName, j, "MAX_LTV"));
			birProjeSinirPrTx.setMinVade(iMap.getBigDecimal(tableName, j, "MIN_VADE") == null ? new BigDecimal(0) : iMap.getBigDecimal(tableName, j, "MIN_VADE"));
			birProjeSinirPrTx.setMaxVade(iMap.getBigDecimal(tableName, j, "MAX_VADE") == null ? new BigDecimal(0) : iMap.getBigDecimal(tableName, j, "MAX_VADE"));
			
			session.saveOrUpdate(birProjeSinirPrTx);
			session.flush();
		}
	}

	public static void getSinirTable(String tableName, String tip, GMMap iMap, GMMap oMap, Session session)
	throws Exception {
		List<?> sinirList = (List<?>) session.createCriteria(BirProjeSinirPrTx.class).add(Restrictions.eq("id.projeKod", iMap.getBigDecimal("PROJE_KOD"))).add(Restrictions.eq("id.tip", tip)).list();
		int row = 0;
		for (Iterator<?> iterator = sinirList.iterator(); iterator.hasNext();row++) {
			BirProjeSinirPrTx birProjeSinirPr = (BirProjeSinirPrTx) iterator.next();
			oMap.put(tableName, row, "DOVIZ_KODU", LovHelper.diLov(birProjeSinirPr.getId().getDovizKodu(), "3118/LOV_DOVIZ", "KOD"));
			oMap.put(tableName, row, "MAX_LTV", birProjeSinirPr.getMaxLtv());
			oMap.put(tableName, row, "MAX_VADE", birProjeSinirPr.getMinVade());
			oMap.put(tableName, row, "MAX_VADE", birProjeSinirPr.getMaxVade());
		}
	}
}
