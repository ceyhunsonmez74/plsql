	package tr.com.calikbank.bnspr.consumerloan.services;

	import java.io.ByteArrayInputStream;
	import java.io.ByteArrayOutputStream;
	import java.io.IOException;
	import java.io.ObjectInput;
	import java.io.ObjectInputStream;
	import java.io.ObjectOutput;
	import java.io.ObjectOutputStream;
	import java.math.BigDecimal;
	import java.text.SimpleDateFormat;
	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.Calendar;
	import java.util.Collection;
	import java.util.HashMap;
	import java.util.Iterator;
	import java.util.List;
	import java.util.Map;

	import jxl.Sheet;
	import jxl.Workbook;
	import jxl.WorkbookSettings;
	import jxl.read.biff.BiffException;

	import org.hibernate.Session;
	import org.hibernate.criterion.Restrictions;

	import tr.com.aktifbank.bnspr.dao.BirKrediHesapExcelTelTx;
	import tr.com.aktifbank.bnspr.dao.BirKrediHesapExcelTelTxId;
	import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipExcelTx;
	import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipExcelTxId;
	import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

	import com.graymound.annotation.GraymoundService;
	import com.graymound.server.dao.DAOSession;
	import com.graymound.service.GMServiceExecuter;
	import com.graymound.util.GMMap;
	import com.graymound.util.GMRuntimeException;

	public class ConsumerLoanTRN3239Services{

		@GraymoundService("BNSPR_TRN3239_GET_COMBOBOX_INITIAL_VALUE")
		public static GMMap getComboBoxInitialValues(GMMap iMap) {
			try {
				GMMap oMap = new GMMap();

				iMap.put("KOD", "TAKIP_FIRMA_KOD");
				iMap.put("ADD_EMPTY_KEY", "H");
				oMap.put("FIRMA_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));			

				return oMap;

			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

		@GraymoundService("BNSPR_TRN3239_LOAD_EXCEL")
		public static GMMap sigortaKayitlariList(GMMap iMap) {
			GMMap oMap = new GMMap();
			try {
				WorkbookSettings ws = new WorkbookSettings();
				ws.setEncoding("iso-8859-9");

				Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")), ws);
				Sheet sheet = workbook.getSheet(0);
				String tableName = "ARAMA_DATALARI";
				int tableRow = 0;

				for (int excelRow = 1; excelRow < sheet.getRows(); excelRow++, tableRow++) {

					oMap.put(tableName, tableRow, "BASVURU_NO", sheet.getCell(0, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "ARAMA_SONUCU", sheet.getCell(1, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "ARAMA_SONUCU_DETAY", sheet.getCell(2, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "AKSIYON", sheet.getCell(3, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "ODEME_SOZU_TARIHI", sheet.getCell(4, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "ARAMA_TARIHI", sheet.getCell(5, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "KENDINEMI_AIT", sheet.getCell(7, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "KIME_AIT", sheet.getCell(8, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "TELEFON_TIPI", sheet.getCell(9, excelRow).getContents().trim());
					oMap.put(tableName, tableRow, "TEL_NO", sheet.getCell(10, excelRow).getContents().trim());

				}
				workbook.close();
			}
			catch (IndexOutOfBoundsException e) {
				throw new GMRuntimeException(0, "Excel s�tunu eksik");
			}
			catch (Exception e) {
				throw new GMRuntimeException(0, e);
			}
			return oMap;
		}

		@GraymoundService("BNSPR_TRN3239_SAVE")
		public static Map<?, ?> save(GMMap iMap) {

			try {
				String tableName = "ARAMA_DATALARI";
				List<?> guiList = (List<?>) iMap.get(tableName);
				
				if (guiList.size() == 0) {
					iMap.put("HATA_NO", new BigDecimal(1064));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getString("FIRMA_KOD") == null || iMap.getString("FIRMA_KOD").length() == 0) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "OUTSOURCE_FIRMA_KOD");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getString("DOSYA_ADI") == null || iMap.getString("DOSYA_ADI").length() == 0) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "DOSYA_ADI");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				iMap.put("DOSYA_NO", GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).get("SIRA_NO"));
				//oMap.put("DOSYA_NO", GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).get("SIRA_NO"));
				
				int fullDataSize = guiList.size();
				int beginIndex = 0 ;
				int endIndex = fullDataSize/2;
				
				List<GMMap> parallelJobList = new ArrayList<GMMap>();
				GMMap sorguMap = null;	
				
				sorguMap = new GMMap();			
				sorguMap.put("T_SERVICE_NAME", "BNSPR_TRN3239_SAVE_PARALLEL");
				sorguMap.put(tableName,iMap.get(tableName));
				sorguMap.put("BEGIN_INDEX",beginIndex);
				sorguMap.put("END_INDEX",endIndex);
				sorguMap.put("TRX_NO",iMap.getBigDecimal("TRX_NO"));
				sorguMap.put("FIRMA_KOD",iMap.getString("FIRMA_KOD"));
				sorguMap.put("DOSYA_ADI",iMap.getString("DOSYA_ADI"));
				sorguMap.put("DOSYA_NO",iMap.get("DOSYA_NO"));
				
				parallelJobList.add(sorguMap);
				
				sorguMap = new GMMap();
				sorguMap.put("T_SERVICE_NAME", "BNSPR_TRN3239_SAVE_PARALLEL");
				sorguMap.put(tableName,iMap.get(tableName));
				sorguMap.put("BEGIN_INDEX",endIndex);
				sorguMap.put("END_INDEX",fullDataSize);
				BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
				sorguMap.put("TRX_NO",trxNo);
				sorguMap.put("FIRMA_KOD",iMap.getString("FIRMA_KOD"));
				sorguMap.put("DOSYA_ADI",iMap.getString("DOSYA_ADI"));
				sorguMap.put("DOSYA_NO",iMap.get("DOSYA_NO"));
				
				parallelJobList.add(sorguMap);

				GMMap jobMap = new GMMap();
				jobMap.put("T_TASKS", parallelJobList);
				jobMap.putAll(GMServiceExecuter.callParallel(jobMap));
				
				GMMap keyMap = null;
				if(!jobMap.getBoolean("T_SUCCESSFUL")) {
					throw new GMRuntimeException(0, "Arama detaylar� paralel kaydetme hatasi !!!");
				} else {					
					for (int i = 0; i < jobMap.getSize("T_RESULTS"); i++) {
						keyMap = jobMap.getMap("T_RESULTS", i);
						keyMap.remove("T_SUCCESSFUL");
						keyMap.remove("CORE_TRX_ID_RESERVED");
					}
				}
				return keyMap;
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
		
		@GraymoundService("BNSPR_TRN3239_SAVE_PARALLEL")
		public static Map<?, ?> saveParellel(GMMap iMap) {

			try {
				Session session = DAOSession.getSession("BNSPRDal");
				String tableName = "ARAMA_DATALARI";
				int beginIndex = iMap.getInt("BEGIN_INDEX");
				int endIndex = iMap.getInt("END_INDEX");
				
				int telSiraNo = 1;
				BigDecimal basvuruNo = null;
				SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

				for (int i = beginIndex; i < endIndex; i++) {

					if (iMap.getBigDecimal(tableName, i, "BASVURU_NO") != null) {
						BirKrediHesapTakipExcelTx birKrediHesapTakipExcelTx = new BirKrediHesapTakipExcelTx();
						BirKrediHesapTakipExcelTxId id = new BirKrediHesapTakipExcelTxId();
						id.setTxNo(iMap.getBigDecimal("TRX_NO"));
						id.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
						basvuruNo = iMap.getBigDecimal(tableName, i, "BASVURU_NO");
						birKrediHesapTakipExcelTx.setFirmaGorus(iMap.getString(tableName, i, "AKSIYON"));
						birKrediHesapTakipExcelTx.setId(id);
						birKrediHesapTakipExcelTx.setDosyaAd(iMap.getString("DOSYA_ADI"));
						//birKrediHesapTakipExcelTx.setDosyaNo(oMap.getBigDecimal("DOSYA_NO"));
						birKrediHesapTakipExcelTx.setDosyaNo(iMap.getBigDecimal("DOSYA_NO"));
						birKrediHesapTakipExcelTx.setFirmaKod(iMap.getString("FIRMA_KOD"));
						if(!"".equals(iMap.getString(tableName, i, "ARAMA_TARIHI"))){
							birKrediHesapTakipExcelTx.setFirmaGorusTarihi(formatter.parse(iMap.getString(tableName, i, "ARAMA_TARIHI")));
							birKrediHesapTakipExcelTx.setAramaTarihi(formatter.parse(iMap.getString(tableName, i, "ARAMA_TARIHI")));
						}
						birKrediHesapTakipExcelTx.setAksiyon(iMap.getString(tableName, i, "AKSIYON"));
						birKrediHesapTakipExcelTx.setAramaSonucu(iMap.getString(tableName, i, "ARAMA_SONUCU"));
						birKrediHesapTakipExcelTx.setAramaSonucuDetay(iMap.getString(tableName, i, "ARAMA_SONUCU_DETAY"));
						if(!"".equals(iMap.getString(tableName, i, "ODEME_SOZU_TARIHI"))){
							birKrediHesapTakipExcelTx.setOdemeSozuTarihi(formatter.parse(iMap.getString(tableName, i, "ODEME_SOZU_TARIHI")));
						}
						session.save(birKrediHesapTakipExcelTx);

						telSiraNo = 1;
					}

					if(!"".equals(iMap.getString(tableName, i, "TEL_NO"))){
						BirKrediHesapExcelTelTx birKrediHesapExcelTelTx = new BirKrediHesapExcelTelTx();
						BirKrediHesapExcelTelTxId idTel = new BirKrediHesapExcelTelTxId();
						idTel.setTxNo(iMap.getBigDecimal("TRX_NO"));
						idTel.setBasvuruNo(basvuruNo);
						idTel.setSiraNo(new BigDecimal(telSiraNo));
						telSiraNo++;
						birKrediHesapExcelTelTx.setId(idTel);
						birKrediHesapExcelTelTx.setKendineMiAit(iMap.getString(tableName, i, "KENDINEMI_AIT"));
						birKrediHesapExcelTelTx.setKimeAit(iMap.getString(tableName, i, "KIME_AIT"));
						birKrediHesapExcelTelTx.setTelTip(telTipDonustur(iMap.getString(tableName, i, "TELEFON_TIPI")));
						birKrediHesapExcelTelTx.setTelAlan(iMap.getString(tableName, i, "TEL_NO").substring(0, 3));
						birKrediHesapExcelTelTx.setTelNo(iMap.getString(tableName, i, "TEL_NO").substring(3, 10));
						
						session.save(birKrediHesapExcelTelTx);
					}
				}
				session.flush();
				iMap.put("TRX_NAME", "3239");
				return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

		private static String telTipDonustur(String telTipi) {
			if("Cep".equals(telTipi)){
				return "C";
			}else if("Ev".equals(telTipi)){
				return "E";
			}else if("��".equals(telTipi)){
				return "I";
			}else{
				return telTipi;
			}
		}

		@GraymoundService("BNSPR_TRN3239_GET_INFO")
		public static GMMap hediyeView(GMMap iMap) {
			GMMap oMap = new GMMap();

			try {

				Session session = DAOSession.getSession("BNSPRDal");
				List<?> list = (List<?>) session.createCriteria(BirKrediHesapTakipExcelTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

				String tableName = "ARAMA_DATALARI";
				int row = 0;
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					BirKrediHesapTakipExcelTx birKrediHesapTakipExcelTx = (BirKrediHesapTakipExcelTx) iterator.next();
					oMap.put(tableName, row, "BASVURU_NO", birKrediHesapTakipExcelTx.getId().getBasvuruNo());
					oMap.put(tableName, row, "ARAMA_SONUCU", birKrediHesapTakipExcelTx.getAramaSonucu());
					oMap.put(tableName, row, "ARAMA_SONUCU_DETAY", birKrediHesapTakipExcelTx.getAramaSonucuDetay());
					oMap.put(tableName, row, "AKSIYON", birKrediHesapTakipExcelTx.getAksiyon());
					oMap.put(tableName, row, "ODEME_SOZU_TARIHI", birKrediHesapTakipExcelTx.getOdemeSozuTarihi());
					oMap.put(tableName, row, "ARAMA_TARIHI", birKrediHesapTakipExcelTx.getAramaTarihi());
					oMap.put("FIRMA_KOD", birKrediHesapTakipExcelTx.getFirmaKod());
					oMap.put("DOSYA_AD", birKrediHesapTakipExcelTx.getDosyaAd());

					List<?> list2 = (List<?>) session.createCriteria(BirKrediHesapExcelTelTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", birKrediHesapTakipExcelTx.getId().getBasvuruNo())).list();
					for (Iterator<?> iterator2 = list2.iterator(); iterator2.hasNext();) {
						BirKrediHesapExcelTelTx birKrediHesapExcelTelTx = (BirKrediHesapExcelTelTx) iterator2.next();
						oMap.put(tableName, row, "KENDINEMI_AIT", birKrediHesapExcelTelTx.getKendineMiAit());
						oMap.put(tableName, row, "KIME_AIT", birKrediHesapExcelTelTx.getKimeAit());
						oMap.put(tableName, row, "TELEFON_TIPI", birKrediHesapExcelTelTx.getTelTip());
						oMap.put(tableName, row, "TEL_NO", birKrediHesapExcelTelTx.getTelAlan().concat(birKrediHesapExcelTelTx.getTelNo()));
						row++;
					}

				}

			}
			catch (Exception e) {
				throw new GMRuntimeException(0, e);
			}
			return oMap;
		}

	}
