package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKampKnl;
import tr.com.calikbank.bnspr.dao.BirKampMeslekIliski;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3185Services {
	@GraymoundService("BNSPR_QRY3185_QUERY_KAMPANYA")
	public static GMMap queryKampanya(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3185.RC_QRY3185_QUERY_KAMPANYA(?,?,?,?,?,?,?,?,?,?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMPANYA_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ALT_KREDI_TIPI"));
			stmt.setString(i++, iMap.getString("KAMPANYA_TIPI"));
			stmt.setString(i++, iMap.getString("DURUM"));
			if(iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			
			if(iMap.getDate("BIT_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			
			stmt.setString(i++, iMap.getString("KANAL_KOD"));
			stmt.setString(i++, iMap.getString("ALT_KANAL_KOD"));
			stmt.setString(i++, iMap.getString("DISTRIBUTOR"));

			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap omap =  DALUtil.rSetResults(rSet, "KAMPANYA_LIST");
			
			for (int j = 0; j < omap.getSize("KAMPANYA_LIST"); j++) {
				omap.put("KAMPANYA_LIST", j ,"HERSEY_DAHIL_EH", GuimlUtil.convertToCheckBoxValue(omap.getString("KAMPANYA_LIST",j,"HERSEY_DAHIL_EH")));
			}
			
			return omap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3185_GET_KAMPANYA_DETAY")
	public static GMMap getKampanyaDetay(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			Criteria criteria = session.createCriteria(BirKampKnl.class)
								.add(Restrictions.eq("kampKod", iMap.getBigDecimal("KAMPANYA_KOD")));
			
			if(iMap.getString("KANAL_KOD") != null && !(iMap.getString("KANAL_KOD").isEmpty())) {
				criteria.add(Restrictions.eq("kanalKod", iMap.getString("KANAL_KOD")));
			}

			List<?> kampanyaDetayList = criteria.list();
			String tableName = "KAMPANYA_DETAY";
			int i = 0;
			for (Iterator<?> iterator = kampanyaDetayList.iterator(); iterator.hasNext();i++) {
				BirKampKnl birKampKnl = (BirKampKnl) iterator.next();
				if(birKampKnl.getDrm().compareTo("I")==0){
					i--;
				}else{
				oMap.put(tableName, i, "KD_ALT_LIMIT", birKampKnl.getAltLimit());
				oMap.put(tableName, i, "KD_BAZ_FAIZ", birKampKnl.getBazOran());
				oMap.put(tableName, i, "KD_DOSYA_MASRAF_ORAN", birKampKnl.getDosMasrafOran());
				oMap.put(tableName, i, "KD_DOVIZ_CINSI", birKampKnl.getDovizKod());
				oMap.put(tableName, i, "KD_INTERNET_EH", birKampKnl.getInternetEh());
				oMap.put(tableName, i, "KD_KANAL_KODU", birKampKnl.getKanalKod());
				oMap.put(tableName, i, "KD_KANALDAKI_ADI", birKampKnl.getKanaldakiAd());
				oMap.put(tableName, i, "KD_KATKI_PAYI_KIMDEN", birKampKnl.getKatkiPayiKimden());
				oMap.put(tableName, i, "KD_KATKI_PAYI_ORAN", birKampKnl.getKatkiPayiOran());
				oMap.put(tableName, i, "KD_KATKI_PAYI_TIPI", birKampKnl.getKatkiPayiTipi());
				oMap.put(tableName, i, "KD_KOD", birKampKnl.getKod());
				oMap.put(tableName, i, "KD_MARKA", birKampKnl.getMarkaKod());
				oMap.put(tableName, i, "KD_MAX_DOSYA_MASRAFI", birKampKnl.getMaxDosMasraf());
				oMap.put(tableName, i, "KD_MAX_KATKI_PAYI", birKampKnl.getMaxKatkiPayi());
				oMap.put(tableName, i, "KD_MAX_VADE", birKampKnl.getMaxVade());
				oMap.put(tableName, i, "KD_MIN_DOSYA_MASRAFI", birKampKnl.getMinDosMasraf());
				oMap.put(tableName, i, "KD_MIN_KATKI_PAYI", birKampKnl.getMinKatkiPayi());
				oMap.put(tableName, i, "KD_MIN_VADE", birKampKnl.getMinVade());
				oMap.put(tableName, i, "KD_DI_MODEL", LovHelper.diLov(birKampKnl.getModelKod(), iMap.getBigDecimal("KREDI_TURU"), birKampKnl.getMarkaKod(), "3112/LOV_MARKA_MODEL", "ACIKLAMA"));
				oMap.put(tableName, i, "KD_MODEL", birKampKnl.getModelKod());
				oMap.put(tableName, i, "KD_MODEL_YIL", birKampKnl.getModelYil());
				//oMap.put(tableName, i, "KD_ODEME_GRUBU", birKampKnl.getOdmGrpNo());
				//oMap.put(tableName, i, "KD_DI_ODEME_GRUBU", LovHelper.diLov(birKampKnl.getOdmGrpNo(), "3112/LOV_ODEME_GRUBU", "ACIKLAMA"));
				oMap.put(tableName, i, "KD_SOZLESME_FAIZI", birKampKnl.getSozlesmeOran());
				oMap.put(tableName, i, "KD_UST_LIMIT", birKampKnl.getUstLimit());
				oMap.put(tableName, i, "KD_DOSYA_MASRAF_TIP", birKampKnl.getDosMasrafTipi());
				String sabitSozlesmeFaizi = iMap.getString(tableName, i, "KD_SABIT_SOZLESME_FAIZI_EH");
				if("X".equals(sabitSozlesmeFaizi)){
					sabitSozlesmeFaizi = null;
				}
				oMap.put(tableName, i, "KD_SABIT_SOZLESME_FAIZI_EH", birKampKnl.getSabitSozlesmeFaiziEh());
				oMap.put(tableName, i, "KD_DURUM", birKampKnl.getDrm());
				oMap.put(tableName, i, "KD_KATKI_PAY_DAGITIM_TIP", birKampKnl.getKatkiPayDagitimTip());
				oMap.put(tableName, i, "KD_KATKI_PAY_DAGITIM_SEKLI", birKampKnl.getKatkiPayDagitimSekli());
				oMap.put(tableName, i, "KD_KATKI_PAY_DAGITIM_ORAN", birKampKnl.getKatkiPayDagitimOran());
				oMap.put(tableName, i, "KD_KATKI_PAY_DAGITIM_TUTAR", birKampKnl.getKatkiPayDagitimTutar());			
			}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3185_GET_KAMPANYA_TEMINAT")
	public static GMMap getKampanyaTeminat(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3185.KampTeminatIliski(?)}");
			stmt.registerOutParameter(1, -10); //ref cursor
			stmt.setBigDecimal(2, iMap.getBigDecimal("KAMP_KNL_KOD"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "KAMPANYA_TEMINAT");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3185_GET_KAMPANYA_MESLEK")
	public static GMMap getKampanyaMeslek(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> kampanyaTeminatList = session.createCriteria(BirKampMeslekIliski.class).add(Restrictions.eq("id.kampKod", iMap.getBigDecimal("KAMP_KNL_KOD"))).list();
			String tableName = "KAMPANYA_MESLEK";
			int i = 0;
			for (Iterator<?> iterator = kampanyaTeminatList.iterator(); iterator.hasNext();i++) {
				BirKampMeslekIliski kampMeslekIliski = (BirKampMeslekIliski) iterator.next();
				oMap.put(tableName, i, "KOD", kampMeslekIliski.getId().getMeslekKod());
				oMap.put(tableName, i, "ACIKLAMA", LovHelper.diLov(kampMeslekIliski.getId().getMeslekKod(), "3185Q/LOV_MESLEK", "ACIKLAMA"));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3185_GET_DAGITICI_AND_BAYI")
	public static GMMap getDagiticiAndBayi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3185.RC_QRY3185_GET_DAGITICI(?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KNL_KOD"));
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
	
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap.putAll(DALUtil.rSetResults(rSet, "DAGITICI_LIST"));
			
			GMServerDatasource.close(rSet);
			
			stmt = conn.prepareCall("{? = call PKG_RC3185.RC_QRY3185_GET_BAYI(?,?)}");
			i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KNL_KOD"));
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
	
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
		
			oMap.putAll(DALUtil.rSetResults(rSet, "BAYI_LIST"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3185_GET_SIGORTA_SATIS_URUN")
	public static GMMap getSigortaSatisUrun(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String func2 = "{? = call pkg_rc3185.SIGORTA_SATIS_URUNLERI(?)}";
			int i = 0;

			Object[] inputValues = new Object[2];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KAMP_KNL_KOD");

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func2, "SIGORTA_SATIS_URUN", inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3185_GET_ILISKILI_SIGORTA_URUN")
	public static GMMap getIliskiliSigortaUrun(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String func2 = "{? = call pkg_rc3185.ILISKILI_SIGORTA_URUN(?)}";
			int i = 0;

			Object[] inputValues = new Object[2];
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KANAL_KODU");

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func2, "ILISKILI_SIGORTA_URUN", inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
}
