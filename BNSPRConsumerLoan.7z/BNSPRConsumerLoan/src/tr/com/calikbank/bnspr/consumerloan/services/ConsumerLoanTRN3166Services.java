package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisan;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisanKodTx;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisanKodTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.obss.adc.core.pojo.User;
import tr.com.obss.adc.core.util.ADCCore;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.JGMPasswordField;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3166Services {
	private final static String	DEALER_CHANNEL_CODE	= "DLR";
	private final static String	IVR_CHANNEL_CODE	= "IVR";

	@GraymoundService("BNSPR_TRN3166_CREATE_DEALER_USER")
	public static GMMap createDealerUser(GMMap iMap) {
		
		try {
			GMMap oMap;
			GMMap sMap = new GMMap();
			GMMap xMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			String saticiKod = iMap.getString("SATICI_KOD");
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			String userName = iMap.getString("USERNAME");
			JGMPasswordField passwordField = new JGMPasswordField();
			BirSatici birSatici = (BirSatici) session.createCriteria(
					BirSatici.class).add(
					Restrictions.eq("kod", new BigDecimal(saticiKod)))
					.uniqueResult();
			String password;
			
			sMap.put("USERNAME", userName);
			sMap.put("INTEGRATION", 0, "KEY", "KANAL_ALT_KODU");
			sMap.put("INTEGRATION", 0, "VALUE", saticiKod);
			sMap.put("COMPANY_USER_CODE", musteriNo);

			if (birSatici != null) {
				sMap.put("MUSTERI_NO", birSatici.getMusteriNo());
			}

			ADCSession.put("3166_USER_PASSWORD", (new BigDecimal(1000)
					.add(new BigDecimal(new Random().nextInt(9000))))
					.toString());
			passwordField.setText(ADCSession.getString("3166_USER_PASSWORD"));
			password = new String(passwordField.getPassword());

			//Create Dealer User
			sMap.put("CHANNELS", 0, "CODE", DEALER_CHANNEL_CODE);
			sMap.put("CHANNELS", 0, "PAROLE", password);
			sMap.put("CHANNELS", 0, "PASSWORD", password);

			sMap.put("ROLES", 0, "CODE", iMap.getString("ROLE"));

			// Create IVR User
			sMap.put("CHANNELS", 1, "CODE", IVR_CHANNEL_CODE);
			sMap.put("CHANNELS", 1, "PAROLE", password);
			sMap.put("CHANNELS", 1, "PASSWORD", password);
			sMap.put("ROLES", 1, "CODE", iMap.getString("ROLE"));

			oMap = GMServiceExecuter.call("ADK_CREATE_USER", sMap);
			xMap = new GMMap();
			xMap.put("CHANNEL_CODE", IVR_CHANNEL_CODE);
			xMap.put("USER_CODE", userName);
			xMap.put("PASSWORD", password);
			GMServiceExecuter.call("ADC_REMOTE_USER_UPDATE_PASSWORD", xMap);
			xMap.put("CHANNEL_CODE", DEALER_CHANNEL_CODE);
			GMServiceExecuter.call("ADC_REMOTE_USER_UPDATE_PASSWORD", xMap);

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3166_UNBLOCK_DEALER_USER")
	public static GMMap unBlockDealer(GMMap iMap) {
		try {
			Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);
			GMMap xMap = new GMMap();
			User user = (User) session.createCriteria(User.class).add(
					Restrictions.eq("username", iMap.getString("USERNAME")))
					.uniqueResult();
			xMap.put("USER_OID", user.getOid());
			xMap.put("ALL_CHANNELS", true);
			GMServiceExecuter.call("ADC_UNBLOCK_USER_CHANNEL", xMap);

			return new GMMap();
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3166_DEALER_USER_ADD_LDAP_USER")
	public static GMMap dealerUserAddLdapUser(GMMap iMap) {
		try {
			GMMap servisMap = new GMMap();
			servisMap.put("UID", iMap.getString("USERNAME"));
			servisMap.put("CN", iMap.getString("ADI"));
			servisMap.put("SN", iMap.getString("SOYADI"));
			servisMap.put("GIVEN_NAME", iMap.getString("GIVEN_NAME"));
			servisMap.put("MAIL", iMap.getString("EPOSTA"));
			servisMap.put("PASSWORD", ADCSession
					.getString("3166_USER_PASSWORD"));
			servisMap.put("INET_USER_STATUS", "Active");

			return GMServiceExecuter.call("BNSPR_SYSTEM_LDAP_ADD_USER_DLR",
					servisMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {

		}
	}

	private static void dealerLogLdapAction(String username) {
		GMMap logMap = new GMMap();

		Session session = DAOSession.getSession(ADCCore.SESSION_FACTORY);

		User user = (User) session.createCriteria(User.class).add(
				Restrictions.eq("username", username)).uniqueResult();

		if (user != null) {
			logMap.put("USER_OID", user.getOid());
			logMap.put("PARENT_USER_OID", user.getOid());
		}
		logMap.put("CHANNEL_OID", ADCSession.getString("CHANNEL_OID"));
		logMap.put("SESSION_ID", ADCSession.getSessionID());

		logMap.put("LAST_UPDATE", Calendar.getInstance().getTime());
		logMap.put("ACTION_GROUP", "LDAP");
		logMap.put("ACTION", "3166");
		logMap.put("RESULT", "1");

		GMServiceExecuter.executeNT("ADC_CORE_USER_ACTION_LOG_CREATE", logMap);
	}

	@GraymoundService("BNSPR_TRN3166_GET_CALISAN_LIST")
	public static GMMap getCalisanList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn
					.prepareCall("{call PKG_TRN3166.get_calisan_list(?,?) }");

			stmt.setBigDecimal(1, iMap.getBigDecimal("SATICI_KOD"));
			stmt.registerOutParameter(2, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetResults(rSet, "CALISAN_LIST"));

			if (iMap.getString("BAYI_CALISAN_KODU_CC") != null
					&& !iMap.getString("BAYI_CALISAN_KODU_CC").equals("")) {
				for (int i = 0; i < oMap.getSize("CALISAN_LIST"); i++) {
					if (iMap.getString("BAYI_CALISAN_KODU_CC").equals(
							oMap.getString("CALISAN_LIST", i, "KOD"))) {
						oMap.put("CALISAN_LIST", i, "SEC", "1");
					}
				}
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_TRN3166_SAVE")
	public static GMMap save(GMMap iMap) {
		boolean flag = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "CALISAN_LIST";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {
				if (iMap.getString(tableName, i, "SEC").equals("1")) {
					flag = true;
					BirSaticiCalisanKodTx birSaticiCalisanKodTx = new BirSaticiCalisanKodTx();
					BirSaticiCalisanKodTxId id = new BirSaticiCalisanKodTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setCalisanKod(iMap.getBigDecimal(tableName, i, "KOD"));

					birSaticiCalisanKodTx.setId(id);
					birSaticiCalisanKodTx.setSaticiKod(iMap
							.getBigDecimal("SATICI_KOD"));

					String userName = iMap.getString(tableName, i, "KOD");
					birSaticiCalisanKodTx.setKullaniciKod(userName);
					session.save(birSaticiCalisanKodTx);
				}
			}
			session.flush();
			if (!flag) {
				iMap.put("HATA_NO", new BigDecimal(1073));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			iMap.put("TRX_NAME", "3166");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3166_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> recordList = (List<?>) session.createCriteria(
					BirSaticiCalisanKodTx.class).add(
					Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.list();

			if (recordList.size() > 0) {
				BirSaticiCalisanKodTx birSaticiCalisanKodTx = (BirSaticiCalisanKodTx) recordList
						.get(0);
				oMap.put("SATICI_KOD", birSaticiCalisanKodTx.getSaticiKod());
				oMap = getCalisanList(oMap);
				oMap.put("SATICI_KOD", birSaticiCalisanKodTx.getSaticiKod());
			}
			String tableName = "CALISAN_LIST";
			List<?> list = (List<?>) oMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {
				oMap.put(tableName, i, "SEC", false);
			}
			for (int j = 0; j < recordList.size(); j++) {
				BirSaticiCalisanKodTx birSaticiCalisanKodTx = (BirSaticiCalisanKodTx) recordList
						.get(j);
				for (int i = 0; i < list.size(); i++) {
					if (birSaticiCalisanKodTx.getKullaniciKod().toString()
							.equals(
									oMap.getBigDecimal(tableName, i, "KOD")
											.toString())) {
						oMap.put(tableName, i, "SEC", true);
						break;
					}
				}
			}
			BirSatici birSatici = (BirSatici) session.createCriteria(
					BirSatici.class).add(
					Restrictions.eq("kod", oMap.getBigDecimal("SATICI_KOD")))
					.uniqueResult();
			oMap.put("SATICI_ADI", birSatici.getSaticiAdi());
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3166_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirSaticiCalisanKodTx.class)
											.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO")))
											.list();
			for (Iterator<?> iter = list.iterator(); iter.hasNext();) {
				BirSaticiCalisanKodTx birSaticiCalisanKodTx = (BirSaticiCalisanKodTx) iter.next();

				BirSaticiCalisan birSaticiCalisan = (BirSaticiCalisan) session.get(BirSaticiCalisan.class, birSaticiCalisanKodTx.getId().getCalisanKod());

				GMMap serviceMap = new GMMap();
				serviceMap.put("USERNAME", birSaticiCalisanKodTx.getId().getCalisanKod());
				serviceMap.put("ROLE", birSaticiCalisan.getYetkiGirisKod());
				serviceMap.put("SATICI_KOD", birSaticiCalisanKodTx.getSaticiKod());
				serviceMap.put("MUSTERI_NO", birSaticiCalisan.getMusteriNo());
				GMServiceExecuter.execute("BNSPR_TRN3166_CREATE_DEALER_USER", serviceMap);
				serviceMap.put("USERNAME", birSaticiCalisanKodTx.getId().getCalisanKod());
				GMServiceExecuter.execute("BNSPR_TRN3166_UNBLOCK_DEALER_USER", serviceMap);

				ArrayList<Object> listPar = new ArrayList<Object>();
				listPar.add(birSaticiCalisan.getMusteriNo());
				@SuppressWarnings("deprecation")
				HashMap<?, ?> gercekMusteri = LovHelper.diLovAll(birSaticiCalisan.getMusteriNo(), "3161/LOV_GERCEK_MUSTERI_GET_INFO", listPar);

				String eposta = (String) gercekMusteri.get("EMAIL_KISISEL");

				if (gercekMusteri != null) {			
					String func = "{? = call PKG_TRN3166.get_sms_mesaj(?,?,?)}";
					Object inputValues[] = {
						BnsprType.NUMBER, birSaticiCalisanKodTx.getSaticiKod(),
						BnsprType.STRING, birSaticiCalisanKodTx.getId().getCalisanKod().toPlainString(),
						BnsprType.STRING, ADCSession.getString("3166_USER_PASSWORD")
					};									
					String smsContent = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
					if(smsContent != null && !smsContent.isEmpty())
					{
						GMMap smsMap = new GMMap();
						smsMap.put("CONTENT", smsContent);
						String msisdn = "";
						String gsm_alan = null;
						String gsm_tel  = null;
						if(smsContent.contains("Passo")) {						
							gsm_alan = birSaticiCalisan.getCepAlanKod();
							gsm_tel  = birSaticiCalisan.getCepTelNo();
							iMap.put("PARAMETRE", "UBE_SMS_HEADER");
							smsMap.put("HEADER", (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
						} else {
							gsm_alan = (String) gercekMusteri.get("GSM_ALAN");
							gsm_tel  = (String) gercekMusteri.get("GSM");							
						}
						gsm_alan = (gsm_alan==null) ? "" : gsm_alan;
						gsm_tel  = (gsm_tel==null)? "" : gsm_tel;
						msisdn = msisdn.concat(gsm_alan)
								       .concat(gsm_tel);
						if(msisdn.length()>0) {
							smsMap.put("MSISDN", msisdn);
							GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap);
						} else {
							GMMap mailMap = new GMMap();
							if (eposta != null && !eposta.isEmpty()) {
								mailMap.put("MAIL_TO", eposta);
								//mailMap.put("MAIL_CC", "mustafa.gunler@aktifbank.com.tr");
							} else {
								mailMap.put("MAIL_TO", DALUtil.callNoParameterFunction("{? = call pkg_parametre.Deger_Al_K('DEALER_USER_INFO')}", Types.VARCHAR));
							}
							mailMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
							mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
							mailMap.put("MAIL_SUBJECT", "Bayi Kullanicisi Olusturma");
							mailMap.put("MAIL_BODY", "Kullanici kodu,Sifre :" + birSaticiCalisanKodTx.getId().getCalisanKod() + "," + ADCSession.getString("3166_USER_PASSWORD") + "");
							mailMap.put("IS_BODY_HTML", "H");
							GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
						}
					}
				} 

				serviceMap.put("EPOSTA", eposta);
				serviceMap.put("ADI", birSaticiCalisan.getAdi());
				serviceMap.put("SOYADI", birSaticiCalisan.getSoyadi());
				serviceMap.put("GIVEN_NAME", birSaticiCalisan.getBirSatici().getSaticiAdi());
				GMServiceExecuter.execute("BNSPR_TRN3166_DEALER_USER_ADD_LDAP_USER", serviceMap);
				dealerLogLdapAction((birSaticiCalisanKodTx.getId().getCalisanKod()).toPlainString());

			}
			ADCSession.remove("3166_USER_PASSWORD");
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
}
