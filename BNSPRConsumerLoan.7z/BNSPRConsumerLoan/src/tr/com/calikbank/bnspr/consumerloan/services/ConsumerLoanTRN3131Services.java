package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKrediBasvuruTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3131Services {

	@GraymoundService("BNSPR_TRN3131_SAVE")
	public static Map<?, ?> saveTRN3131(GMMap iMap) {

		HashMap<String, Object> oMap = new HashMap<String, Object>();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirKrediBasvuruTx birKrediBasvuruTx = (BirKrediBasvuruTx) session.get(BirKrediBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birKrediBasvuruTx == null) {
				birKrediBasvuruTx = new BirKrediBasvuruTx();
			}

			/*
			 * Asagida BigDecimal ler GuimlUtil.getTableCellBigDecimal
			 * fonksiyonunu kullandi. Bos String Hatasi giderilince
			 * duzeltilecektir.
			 */

			birKrediBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birKrediBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birKrediBasvuruTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birKrediBasvuruTx.setAdiSoyadi(iMap.getString("ADI_SOYADI"));
			birKrediBasvuruTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			birKrediBasvuruTx.setCepTelNo(iMap.getString("CEP_TELEFON_NO"));
			birKrediBasvuruTx.setDovizKodu(iMap.getString("DOVIZ_CINSI"));
			birKrediBasvuruTx.setSozlesmeTarihi(new Date());
			birKrediBasvuruTx.setGecikmeGunSayisi(iMap.getBigDecimal("GECIKME_GUN_SAYISI"));
			birKrediBasvuruTx.setIlkTaksitTarihi(iMap.getDate("ILK_TAKSIT_TARIHI"));
			birKrediBasvuruTx.setIlkTaksitYontem(iMap.getBigDecimal("FAIZ_ALMA"));
			birKrediBasvuruTx.setKur(iMap.getBigDecimal("KUR"));
			birKrediBasvuruTx.setVade(iMap.getBigDecimal("VADE"));
			birKrediBasvuruTx.setKullandirimTarihi(iMap.getDate("KULLANDIRIM_TARIHI"));
			birKrediBasvuruTx.setTutar(iMap.getBigDecimal("TUTAR"));
			birKrediBasvuruTx.setBazFaiz(iMap.getBigDecimal("BAZ_FAIZ"));
			birKrediBasvuruTx.setDurumKodu(iMap.getString("KREDI_BASVURU_DURUMU"));
			birKrediBasvuruTx.setOdemeTuru(iMap.getString("ODEME_TURU"));
			birKrediBasvuruTx.setOdemePeryodu(iMap.getBigDecimal("ODEME_PERIYODU"));
			birKrediBasvuruTx.setArtisPeryodu(iMap.getBigDecimal("ARTIS_PERIYODU"));
			birKrediBasvuruTx.setArtisOrani(iMap.getBigDecimal("ARTIS_ORANI"));
			birKrediBasvuruTx.setAraOdemePeryodu(iMap.getBigDecimal("ARA_ODEME_PERIYODU"));
			birKrediBasvuruTx.setAraOdemeOrani(iMap.getBigDecimal("ARA_ODEME_ORANI"));
			birKrediBasvuruTx.setAraOdemeTutari(iMap.getBigDecimal("ARA_ODEME_TUTARI"));
			birKrediBasvuruTx.setOdemesizSure(iMap.getBigDecimal("ODEMESIZ_SURE"));
			birKrediBasvuruTx.setBayiDfKomisyonTutari(iMap.getBigDecimal("BAYI_DF_KOMISYON_TUTARI"));
			birKrediBasvuruTx.setMusteriKomisyonTutari(iMap.getBigDecimal("MUSTERI_KOMISYON_TUTARI"));
			birKrediBasvuruTx.setSozlesmeFaizi(iMap.getBigDecimal("SOZLESME_FAIZI"));
			birKrediBasvuruTx.setIstihbaratDosyaMasrafi(iMap.getBigDecimal("ISTIHBARAT_DOSYA_MASRAFI"));
			birKrediBasvuruTx.setTeminatSigortaPrimi(iMap.getBigDecimal("TEMINAT_SIGORTA_PRIMI"));
			birKrediBasvuruTx.setEkspertizUcreti(iMap.getBigDecimal("EKSPERTIZ_UCRETI"));
			birKrediBasvuruTx.setAvukatlikUcreti(iMap.getBigDecimal("AVUKATLIK_UCRETI"));
			birKrediBasvuruTx.setKrediYonetimMasrafi(iMap.getBigDecimal("KREDI_YONETIM_MASRAFI"));
			birKrediBasvuruTx.setKrediSigPrimiPesinat(iMap.getBigDecimal("PESINAT"));
			birKrediBasvuruTx.setKrediSigPrimiYillikOdeme(iMap.getBigDecimal("YILLIK_ODEME"));
			birKrediBasvuruTx.setKrediSigPrimiYontem(iMap.getBigDecimal("YONTEM"));
			birKrediBasvuruTx.setKrediTur(iMap.getBigDecimal("KREDI_TUR"));
			birKrediBasvuruTx.setKrediAltTur(iMap.getBigDecimal("KREDI_ALT_TUR"));
			birKrediBasvuruTx.setKrediAltTur2(iMap.getBigDecimal("KREDI_ALT_TUR2"));
			birKrediBasvuruTx.setKanalKodu(iMap.getString("KANAL_KODU"));

			birKrediBasvuruTx.setKkdfVarMi(iMap.getString("F_KKDF"));
			if (iMap.getString("F_KKDF").equals("E"))
				birKrediBasvuruTx.setKkdfOran(getKKDFOran(iMap));
			else
				birKrediBasvuruTx.setKkdfOran(new BigDecimal(0));

			birKrediBasvuruTx.setBsmvVarMi(iMap.getString("F_BSMV"));
			if (iMap.getString("F_BSMV").equals("E"))
				birKrediBasvuruTx.setBsmvOran(getBSMVOran(iMap));
			else
				birKrediBasvuruTx.setBsmvOran(new BigDecimal(0));

			birKrediBasvuruTx.setFarkFaizi(iMap.getBigDecimal("FARK_FAIZI"));
			session.saveOrUpdate(birKrediBasvuruTx);
			session.flush();

			if (iMap.getString("SAVE_METHOD").equals("SAVE")) {
				fillPaymentPlan(iMap);
				iMap.put("TRX_NAME", "3131");
				return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			} else if (iMap.getString("SAVE_METHOD").equals("ODEME_PLANI")) {
				fillPaymentPlan(iMap);
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}

	public static void fillPaymentPlan(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3131.fillpaymentplan(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3131_GET_FILL_PAYMENT_PLAN_EK3")
	public static GMMap getFillPaymentPlanEk3(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3131.fillpaymentplan_ek3(?,?,?)}");
			stmt.registerOutParameter(1, Types.BIGINT);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("VADE"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("KEY", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static BigDecimal getKKDFOran(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3131.getkkdfrate(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KREDI_TUR"));

			stmt.execute();

			return stmt.getBigDecimal(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static BigDecimal getBSMVOran(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3131.getbsmvrate(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KREDI_TUR"));

			stmt.execute();

			return stmt.getBigDecimal(1);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3131_GET_INFO")
	public static GMMap getTRN3131Info(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirKrediBasvuruTx birKrediBasvuruTx = (BirKrediBasvuruTx) session.get(BirKrediBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("BASVURU_NO", birKrediBasvuruTx.getBasvuruNo());
			oMap.put("MUSTERI_NO", birKrediBasvuruTx.getMusteriNo());
			oMap.put("ADI_SOYADI", birKrediBasvuruTx.getAdiSoyadi());
			oMap.put("TC_KIMLIK_NO", birKrediBasvuruTx.getTcKimlikNo());
			oMap.put("CEP_TELEFON_NO", birKrediBasvuruTx.getCepTelNo());
			oMap.put("DOVIZ_CINSI", birKrediBasvuruTx.getDovizKodu());
			oMap.put("SOZLESME_TARIHI", birKrediBasvuruTx.getSozlesmeTarihi());
			oMap.put("GECIKME_GUN_SAYISI", birKrediBasvuruTx.getGecikmeGunSayisi());
			oMap.put("ILK_TAKSIT_TARIHI", birKrediBasvuruTx.getIlkTaksitTarihi());
			oMap.put("FAIZ_ALMA", birKrediBasvuruTx.getIlkTaksitYontem());
			oMap.put("KUR", birKrediBasvuruTx.getKur());
			oMap.put("VADE", birKrediBasvuruTx.getVade());
			oMap.put("KULLANDIRIM_TARIHI", birKrediBasvuruTx.getKullandirimTarihi());
			oMap.put("TUTAR", birKrediBasvuruTx.getTutar());
			oMap.put("BAZ_FAIZ", birKrediBasvuruTx.getBazFaiz());

			iMap.put("BASVURU_NO", birKrediBasvuruTx.getBasvuruNo());
			oMap.put("KREDI_BASVURU_DURUMU", GMServiceExecuter.execute("BNSPR_TRN3131_GET_DURUM_KODU", iMap).get("DURUM_KODU"));

			oMap.put("ODEME_TURU", birKrediBasvuruTx.getOdemeTuru());
			oMap.put("ODEME_PERIYODU", birKrediBasvuruTx.getOdemePeryodu());
			oMap.put("ARTIS_PERIYODU", birKrediBasvuruTx.getArtisPeryodu());
			oMap.put("ARTIS_ORANI", birKrediBasvuruTx.getArtisOrani());
			oMap.put("ARA_ODEME_PERIYODU", birKrediBasvuruTx.getAraOdemePeryodu());
			oMap.put("ARA_ODEME_ORANI", birKrediBasvuruTx.getAraOdemeOrani());
			oMap.put("ARA_ODEME_TUTARI", birKrediBasvuruTx.getAraOdemeTutari());
			oMap.put("ODEMESIZ_SURE", birKrediBasvuruTx.getOdemesizSure());
			oMap.put("BAYI_DF_KOMISYON_TUTARI", birKrediBasvuruTx.getBayiDfKomisyonTutari());
			oMap.put("MUSTERI_KOMISYON_TUTARI", birKrediBasvuruTx.getMusteriKomisyonTutari());
			oMap.put("SOZLESME_FAIZI", birKrediBasvuruTx.getSozlesmeFaizi());
			oMap.put("ISTIHBARAT_DOSYA_MASRAFI", birKrediBasvuruTx.getIstihbaratDosyaMasrafi());
			oMap.put("TEMINAT_SIGORTA_PRIMI", birKrediBasvuruTx.getTeminatSigortaPrimi());
			oMap.put("EKSPERTIZ_UCRETI", birKrediBasvuruTx.getEkspertizUcreti());
			oMap.put("AVUKATLIK_UCRETI", birKrediBasvuruTx.getAvukatlikUcreti());
			oMap.put("KREDI_YONETIM_MASRAFI", birKrediBasvuruTx.getKrediYonetimMasrafi());
			oMap.put("PESINAT", birKrediBasvuruTx.getKrediSigPrimiPesinat());
			oMap.put("YILLIK_ODEME", birKrediBasvuruTx.getKrediSigPrimiYillikOdeme());
			oMap.put("YONTEM", birKrediBasvuruTx.getKrediSigPrimiYontem());

			oMap.put("KREDI_TUR", birKrediBasvuruTx.getKrediTur());
			oMap.put("KREDI_ALT_TUR", birKrediBasvuruTx.getKrediAltTur());
			oMap.put("KREDI_ALT_TUR2", birKrediBasvuruTx.getKrediAltTur2());
			oMap.put("KANAL_KODU", birKrediBasvuruTx.getKanalKodu());

			oMap.put("DI_KREDI_TUR", LovHelper.diLov(birKrediBasvuruTx.getKrediTur(), "3131/LOV_KREDI_TUR", "ACIKLAMA"));
			oMap.put("DI_KREDI_ALT_TUR", LovHelper.diLov(birKrediBasvuruTx.getKrediAltTur(), birKrediBasvuruTx.getKrediTur(), "3131/LOV_KREDI_ALT_TUR", "ACIKLAMA"));
			oMap.put("DI_KREDI_ALT_TUR2", LovHelper.diLov(birKrediBasvuruTx.getKrediAltTur2(), birKrediBasvuruTx.getKrediTur(), birKrediBasvuruTx.getKrediAltTur(), "3131/LOV_KREDI_ALT_TUR2", "ACIKLAMA"));
			oMap.put("DI_KANAL_KODU", LovHelper.diLov(birKrediBasvuruTx.getKanalKodu(), birKrediBasvuruTx.getKrediTur(), birKrediBasvuruTx.getKrediAltTur(), birKrediBasvuruTx.getKrediAltTur2(), "3131/LOV_KANAL_KODU", "ACIKLAMA"));

			oMap.put("F_KKDF", GuimlUtil.convertToCheckBoxSelected(birKrediBasvuruTx.getKkdfVarMi()));
			oMap.put("F_BSMV", GuimlUtil.convertToCheckBoxSelected(birKrediBasvuruTx.getBsmvVarMi()));
			oMap.put("FARK_FAIZI", birKrediBasvuruTx.getFarkFaizi());
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3131_GET_FAIZ_ORAN")
	public static GMMap getFaizOran(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_bireysel.FaizOraniDosyaMasrafi(?,?,?,?,?,?,?,?,?,?,?,?,'E')}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TUR_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_ALT_TUR_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_ALT_TUR2_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("DOVIZ"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.registerOutParameter(i++, Types.DECIMAL);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.DECIMAL);
			stmt.registerOutParameter(i++, Types.DECIMAL);
			stmt.registerOutParameter(i++, Types.DECIMAL);

			stmt.execute();

			BigDecimal faizOran = stmt.getBigDecimal(8);

			String dosMasrafTip = stmt.getString(9);
			BigDecimal minDosMasraf = stmt.getBigDecimal(10);
			// BigDecimal maxDosMasraf = stmt.getBigDecimal(11);
			BigDecimal dosMasrafOran = stmt.getBigDecimal(12);

			BigDecimal istDosMasraf = new BigDecimal(0);
			Boolean istDosEnabled = false;

			if (dosMasrafTip != null)
				if (dosMasrafTip.equals("Y")) {
					istDosMasraf = new BigDecimal(0);
					istDosEnabled = false;
				} else if (dosMasrafTip.equals("O")) {
					BigDecimal dosMasraf = iMap.getBigDecimal("TUTAR").multiply(dosMasrafOran).divide(new BigDecimal(100)).round(new MathContext(2, RoundingMode.HALF_UP));
					if (minDosMasraf.compareTo(dosMasraf) > 0)
						istDosMasraf = minDosMasraf;
					else
						istDosMasraf = dosMasraf;
					istDosEnabled = false;
				} else if (dosMasrafTip.equals("T")) {
					istDosMasraf = minDosMasraf;
					istDosEnabled = true;
				}

			GMMap oMap = new GMMap();
			oMap.put("FAIZ_ORAN", faizOran);
			oMap.put("IST_DOS_MASRAF", istDosMasraf);
			oMap.put("IST_DOS_ENABLED", istDosEnabled);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3131_MIN_MAX_DEGER_KONTROL")
	public static GMMap minMaxDegerKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_bireysel.KrdTipMinMaxDegerKontrol(?,?,?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TUR_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_ALT_TUR_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_ALT_TUR2_KODU"));
			stmt.setString(i++, iMap.getString("DOVIZ"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));

			stmt.execute();

			GMMap oMap = new GMMap();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3131_GET_VERGI_KOMISYON")
	public static GMMap getVergiKomisyon(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirKrediBasvuruTx birKrediBasvuruTx = (BirKrediBasvuruTx) session.get(BirKrediBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("BAYI_DF_KOMISYON_TUTARI", birKrediBasvuruTx.getBayiDfKomisyonTutari());
			oMap.put("MUSTERI_KOMISYON_TUTARI", birKrediBasvuruTx.getMusteriKomisyonTutari());
			oMap.put("SOZLESME_FAIZI", birKrediBasvuruTx.getSozlesmeFaizi());

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CHECK_TAKSIT_TARIHI")
	public static GMMap checkTaksitTarihi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tarih.is_gunu_bul(?,2)}");
			stmt.registerOutParameter(1, Types.DATE);
			java.util.Date date = (java.util.Date) iMap.get("ILK_TAKSIT_TARIHI");
			stmt.setDate(2, new java.sql.Date(date.getTime()));
			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("ILK_TAKSIT_TARIHI", stmt.getDate(1));
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3131_GET_DILOV")
	public static GMMap getDilov(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DI_KREDI_TUR", LovHelper.diLov(iMap.getString("KREDI_TUR"), "3131/LOV_KREDI_TUR", "ACIKLAMA"));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3131_GET_BASVURU_NO")
	public static GMMap getBasvuruNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call Pkg_Genel_pr.genel_kod_al('BIR_KREDI_BASVURU')}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.execute();

			oMap.put("BASVURU_NO", stmt.getBigDecimal(1));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3131_ISLEMDEN_BASVURU_NO_AL")
	public static GMMap getTXBasvuruNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call Pkg_TRN3131.islemden_basvuru_no_al(?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TX_NO"));

			stmt.execute();

			oMap.put("TX_BASVURU_NO", stmt.getBigDecimal(1));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3131_GET_COMBOBOX_INITIAL_VALUES")
	public static GMMap getComboboxInitialValues(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			BigDecimal krediTur = iMap.getBigDecimal("KREDI_TUR");
			BigDecimal krediTip = iMap.getBigDecimal("KREDI_TIP");
			BigDecimal altKrediTip = iMap.getBigDecimal("ALT_KREDI_TIP");
			BigDecimal kanalKodu = iMap.getBigDecimal("KANAL_KODU");

			StringBuffer query = new StringBuffer();
			query.append("SELECT DISTINCT K.DOVIZ_KOD,K.DOVIZ_KOD ");
			query.append("FROM ");
			query.append(" BIR_KRD_TUR_KNL K ");
			query.append("WHERE ");
			query.append("K.DRM = 'G' ");
			query.append("AND KRD_TUR_KOD =  ? ");
			query.append("AND KRD_TUR_ALT_KOD = ?");
			query.append("AND KRD_TUR_ALT_KOD2 = ? ");
			query.append("AND K.KANAL_KOD = ? ");
			query.append("ORDER BY 1 ");

			stmt = conn.prepareCall(query.toString());

			stmt.setBigDecimal(1, krediTur);
			stmt.setBigDecimal(2, krediTip);
			stmt.setBigDecimal(3, altKrediTip);
			stmt.setBigDecimal(4, kanalKodu);
			
			rSet = stmt.executeQuery();

			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("LIST_NAME", "DOVIZ_CINSI");
			DALUtil.fillComboBox(iMap, rSet);
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3131_GET_DURUM_KODU")
	public static GMMap getDurumKodu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn3131.basvurudurumkodu(?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			oMap.put("DURUM_KODU", stmt.getString(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3131_GET_ODEME_GRUPLAR_URUN")
	public static GMMap getOdemeGruplarUrun(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_Bireysel.OdemeGruplar_Urun(?,?,?,?,?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TUR_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_ALT_TUR_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_ALT_TUR2_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("DOVIZ"));

			stmt.execute();
			
			stmt.getMoreResults();
			rSet = (ResultSet)stmt.getObject(1);
			
			Boolean flag = false;
			oMap.put("F_ESIT",flag);		    
		    oMap.put("F_ODEMESIZ_SURELI",flag);
			
			while (rSet.next()) {
				flag = true;
				
				oMap.put("ODEME_GRUP_KOD", rSet.getBigDecimal(1));	
				
			    if (rSet.getBigDecimal(2).compareTo(new BigDecimal(2)) == 0)
			    	oMap.put("F_ESIT",flag);
			    if (rSet.getBigDecimal(2).compareTo(new BigDecimal(7)) == 0)
			    	oMap.put("F_ODEMESIZ_SURELI",flag);
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
