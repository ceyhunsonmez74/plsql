package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.biff.EmptyCell;

import org.apache.axis.encoding.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.VysKrediDevirTx;
import tr.com.aktifbank.bnspr.dao.VysKrediDevirTxId;
import tr.com.calikbank.bnspr.consumerloan.document.type.WebCreditDocument;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.ftp.AktifSFTPClient;
import tr.com.calikbank.integration.ftp.FtpClient;
import tr.com.calikbank.integration.ftp.FtpClientException;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3279Services {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanTRN3279Services.class);
	private static int CANLI_SATIS = 1;
	private static int TAKIP_SATIS = 2;

	@GraymoundService("BNSPR_TRN3279_UPLOAD_EXCEL")
	public static GMMap uploadExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			if (iMap.getString("FIRMA_KOD") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Firma");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("ISO-8859-9");

			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet dataSheet = workbook.getSheet(0);

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call bnspr.PKG_TRN3279.kredi_bilgi(?,?,?,?,?,?,?,?,?,?)}");

			String tableName = "DEVIR_TABLO";
			int row = 0;
			for (int i = 0; i < dataSheet.getRows(); i++) {

				if (dataSheet.getCell(0, i) instanceof EmptyCell) {
					continue;
				}
				else {
					String basvuru = dataSheet.getCell(0, i).getContents();

					if (basvuru != null && !basvuru.trim().isEmpty()) {
						BigDecimal basvuruNo = new BigDecimal(basvuru);

						int index = 1;
						stmt.setBigDecimal(index++, basvuruNo);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.execute();

						oMap.put(tableName, row, "BASVURU_NO", basvuruNo);
						index = 2;
						oMap.put(tableName, row, "MUSTERI_NO", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "AD_SOYAD", stmt.getString(index++));
						oMap.put(tableName, row, "KANAL_ADI", stmt.getString(index++));
						oMap.put(tableName, row, "KAMPANYA_ADI", stmt.getString(index++));
						oMap.put(tableName, row, "KREDI_TUR", stmt.getString(index++));
						oMap.put(tableName, row, "GGS", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "KALAN_ANAPARA", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "GECIKME_TUTARI", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "MASRAF_BAKIYE", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "SEC", true);
						
						row++;

						stmt.clearParameters();
					}
				}
			}

			return oMap;
		}
		catch (Exception e) {			
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3279_UPLOAD_EXCEL_TAKIP")
	public static GMMap uploadExcelTakip(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			if (iMap.getString("FIRMA_KOD") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Firma");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("ISO-8859-9");

			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet dataSheet = workbook.getSheet(0);

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3279.kredi_bilgi_takip(?,?,?,?,?,?,?,?,?,?)}");

			String tableName = "DEVIR_TABLO";
			int row = 0;
			for (int i = 0; i < dataSheet.getRows(); i++) {

				if (dataSheet.getCell(0, i) instanceof EmptyCell) {
					continue;
				}
				else {
					String basvuru = dataSheet.getCell(0, i).getContents();

					if (basvuru != null && !basvuru.trim().isEmpty()) {
						BigDecimal basvuruNo = new BigDecimal(basvuru);

						int index = 1;
						stmt.setBigDecimal(index++, basvuruNo);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.execute();

						oMap.put(tableName, row, "BASVURU_NO", basvuruNo);
						index = 2;
						oMap.put(tableName, row, "MUSTERI_NO", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "AD_SOYAD", stmt.getString(index++));
						oMap.put(tableName, row, "KANAL_ADI", stmt.getString(index++));
						oMap.put(tableName, row, "KAMPANYA_ADI", stmt.getString(index++));
						oMap.put(tableName, row, "KREDI_TUR", stmt.getString(index++));
						oMap.put(tableName, row, "GGS", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "KALAN_ANAPARA", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "GECIKME_TUTARI", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "MASRAF_BAKIYE", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "SEC", true);
						
						row++;

						stmt.clearParameters();
					}
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3279_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			Session session = DAOSession.getSession("BNSPRDal");

			List<VysKrediDevirTx> infoList = session.createCriteria(VysKrediDevirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3279.kredi_bilgi(?,?,?,?,?,?,?,?,?,?)}");

			int row = 0;
			String tableName = "DEVIR_TABLO";
			for (VysKrediDevirTx infoRecord : infoList) {
				oMap.put("DEVIR_NO", infoRecord.getId().getDevirNo());
				oMap.put("FIRMA_KODU", infoRecord.getId().getFirmaKodu());
				oMap.put(tableName, row, "BASVURU_NO", infoRecord.getId().getBasvuruNo());
				oMap.put(tableName, row, "GGS", infoRecord.getGgs());

				int i = 1;
				stmt.setBigDecimal(i++, infoRecord.getId().getBasvuruNo());
				stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.execute();

				i = 2;
				oMap.put(tableName, row, "MUSTERI_NO", stmt.getBigDecimal(i++));
				oMap.put(tableName, row, "AD_SOYAD", stmt.getString(i++));
				oMap.put(tableName, row, "KANAL_ADI", stmt.getString(i++));
				oMap.put(tableName, row, "KAMPANYA_ADI", stmt.getString(i++));
				oMap.put(tableName, row, "KREDI_TUR", stmt.getString(i++));
				oMap.put(tableName, row, "KALAN_ANAPARA", stmt.getBigDecimal(i++));
				oMap.put(tableName, row, "GECIKME_TUTARI", stmt.getBigDecimal(i++));
				oMap.put(tableName, row, "MASRAF_BAKIYE", stmt.getBigDecimal(i++));
				oMap.put(tableName, row, "SEC", true);
				row++;
				stmt.clearParameters();
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3279_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			String devirTipi = iMap.getString("DEVIR_TIPI");
			
			if(StringUtils.isNotEmpty(devirTipi)){
				if(devirTipi.equalsIgnoreCase("2")){
					GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "VYS_FIRMA_TAKIP_DEVIR_ORAN")).uniqueResult();
					if(parametre != null){
						BigDecimal kapamaOran = iMap.getBigDecimal("KAPAMA_ORAN");
						if(kapamaOran != null && kapamaOran.compareTo(BigDecimal.ZERO) == 1){
							parametre.setDeger(kapamaOran.toString());
							session.update(parametre);
							session.flush();
						}
						else{
							throw new GMRuntimeException(0, "Kapama Oran� s�f�rdan b�y�k olmal�d�r.");
						}
					}
				}
				GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "VYS_DEVIR_TIPI")).uniqueResult();
				if(parametre != null){
					parametre.setDeger(devirTipi);
					session.update(parametre);
					session.flush();
				}
			}

			List<VysKrediDevirTx> removalList = session.createCriteria(VysKrediDevirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (VysKrediDevirTx record : removalList) {
				session.delete(record);
			}

			session.flush();

			String tableName = "DEVIR_TABLO";

			for (int i = 0; i < iMap.getSize(tableName); i++) {

				if(iMap.getBoolean(tableName, i, "SEC"))
				{
					VysKrediDevirTxId id = new VysKrediDevirTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setDevirNo(iMap.getBigDecimal("DEVIR_NO"));
					id.setFirmaKodu(iMap.getString("FIRMA_KODU"));
					id.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
	
					VysKrediDevirTx newRecord = new VysKrediDevirTx();
					newRecord.setId(id);
					newRecord.setGgs(iMap.getBigDecimal(tableName, i, "GGS"));
					session.save(newRecord);
				}
			}

			session.flush();

			iMap.put("TRX_NAME", "3279");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3279_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		try {
			iMap.put("DEVIR_TIP_LIST", 0 , "VALUE", CANLI_SATIS);
			iMap.put("DEVIR_TIP_LIST", 0 , "NAME", "Canl�dan Sat��");
			iMap.put("DEVIR_TIP_LIST", 1 , "VALUE", TAKIP_SATIS);
			iMap.put("DEVIR_TIP_LIST", 1 , "NAME", "Takipten Sat��");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN3279_GET_VYS_FIRMA")
	public static GMMap getVysFirma(GMMap iMap) {
		try {
			String devirTipi = iMap.getString("DEVIR_TIPI");
			DALUtil.fillComboBox(iMap, "FIRMA_LIST", false, "select t.key2,t.text from bnspr.v_ml_gnl_param_text t where t.kod = 'VYS_FIRMA_PARAMETRE' "
					+ "and t.key1='ADI' and t.key3=" + devirTipi + " order by t.text");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN3279_FTP_VYS_DOCUMENT")
	public static GMMap ftpVysDocument(GMMap iMap) {
		GMMap oMap = new GMMap();
		String basvuruNo = StringUtils.EMPTY;
		String dokumanAdi = StringUtils.EMPTY;
		
		try {
			String func = "{? = call BNSPR.PKG_RC3279.BASVURU_DOKUMAN_LIST() }";
			oMap = DALUtil.callOracleRefCursorFunction(func, "DOKUMAN_LIST");
			
			for (int j = 0; j < oMap.getSize("DOKUMAN_LIST"); j++) {
				dokumanAdi = oMap.getString("DOKUMAN_LIST", j, "BELGE_YERI");
				basvuruNo = oMap.getString("DOKUMAN_LIST", j, "BASVURU_NO");
				
				byte[] dokumanByteArray = (byte[]) GMServiceExecuter.call("DYS_CMIS_GET_DOKUMAN_LINK_BY_FILENAME", new GMMap().
						put("DOKUMAN_CLASS","Musteri").put("DOKUMAN_ADI", dokumanAdi).put("DOKUMAN_BYTE_ARRAY_NEEDED", true)).get("DOKUMAN_BYTE_ARRAY");
            	GMMap ftpFileMap = new GMMap();
            	ftpFileMap.put("FILE", dokumanByteArray);
            	ftpFileMap.put("FILE_NAME", dokumanAdi);
            	ftpFileMap.put("BASVURU_NO", basvuruNo);
            	
            	GMServiceExecuter.call("BNSPR_TRN3279_FTP_FILE", ftpFileMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3279_FTP_FILE")
    public static GMMap ftpVysFile(GMMap iMap) {
	CallableStatement stmt = null;
	ResultSet rSet = null;
	Connection conn = null;
	
    String fileName = iMap.getString("FILE_NAME");
    String basvuruNo = iMap.getString("BASVURU_NO");
    byte [] fileSend = (byte[]) iMap.get("FILE");
	
    try {
		    conn = DALUtil.getGMConnection();
		    stmt = conn.prepareCall("{? = call PKG_TRN2070.read_gnl_sifre(?)}");
		    stmt.registerOutParameter(1, -10);
		    stmt.setString(2, "VYS_SFTP"); 
		    stmt.execute();
		    rSet = (ResultSet) stmt.getObject(1);
		    rSet.next();
	
		    String serverUri = rSet.getString("ip");
		    String username = rSet.getString("user_name");
		    String password = rSet.getString("passwd");
		    String path = rSet.getString("path");
		    BigDecimal port = rSet.getBigDecimal("port");
		    String ftpType = rSet.getString("FTP_TURU");
		    
		    String currentDateStr = new SimpleDateFormat("dd.MM.yyyy").format(Calendar.getInstance().getTime());
		    //path = path.concat("/").concat(currentDateStr);
		    
		    String newDirectory = currentDateStr.concat("/").concat(basvuruNo);
		    
		    FtpClient ftpClient=new FtpClient(serverUri, port, ftpType, username, password);
			if(!ftpClient.isFileExist(path, newDirectory)) {
				ftpClient.createDirectory(path, newDirectory);
				logger.info(newDirectory + " isimli dizin yaratildi..");
			}
			
			String filePath = path + "/" + newDirectory;				
			ftpClient.put(filePath, fileName, fileSend);
			logger.info(fileName + " isimli dosya " + filePath + " isimli dizinde yaratildi..");
		} 
		catch (FtpClientException e) {
			String message = StringUtils.EMPTY;
			
			if (e.getMessage().contains("Connection timed out")) {
				message = "Baglanti zaman asimi !!";
			} else {
				message = fileName + " dosyasinin ftp ye aktarilmasi sirasinda hata olustu!";
			}
			
			logger.error(message);
			throw new FtpClientException(message);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		    GMServerDatasource.close(rSet);
		    GMServerDatasource.close(stmt);
		    GMServerDatasource.close(conn);
		}
			
		return iMap;
    }
}
