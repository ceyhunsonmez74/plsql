package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ifrsBrmSonuc;
import tr.com.calikbank.bnspr.dao.ifrsBrmSonucId;
import tr.com.calikbank.bnspr.dao.ifrsOutput;
import tr.com.calikbank.bnspr.dao.ifrsOutputId;
import tr.com.calikbank.bnspr.dao.ifrsinput;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanIFRSServices implements Constants{
	
	private final static Logger LOGGER = Logger.getLogger(ConsumerLoanIFRSServices.class);
	private final static int MAX_RESULT = 50000;
	private final static String SUCCESS = "1";
	private final static String BRM_ERROR = "2";
	private final static String EXCEPTION = "3";
	
	/**
	 * Project : <br>
	 * DESC    : 
	 *
	 * @param iMap (GMMap)
	 *          PARAM_I
	 *
	 * @return oMap (GMMap)
	 *
	 * @author huseyin.ceteci
	 * @since  TY-9826
	 *
	 */
	@GraymoundService("BNSPR_CL_IFRS_CALL")
	public static GMMap ifrsCall(GMMap iMap) {
		GMMap bMap = new GMMap();
		Session session = null;
		ifrsBrmSonuc brmSonuc = null;
		ifrsBrmSonucId brmSonucId = null;
		ifrsinput i = null;
		ifrsOutput o = null;
		
		try {
			session = DAOSession.getSession("BNSPRDal");
			i =  (ifrsinput) session.createCriteria(ifrsinput.class).add(Restrictions.eq("id.referenceDate", iMap.getDate("Referencedate")))
					.add(Restrictions.eq("id.accountId", iMap.getString("Accountid")))
					.add(Restrictions.eq("id.customerId", iMap.getString("Customerid"))).uniqueResult();
			
			GMMap xMap = new GMMap();
			xMap.put("INPUT", iMap);

			GMMap aMap = new GMMap();
			xMap.put("OUTPUT", aMap);
			xMap.put("RESULT", new GMMap());
			xMap.put("CallId", (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "IFRS_NBSM_SORGU")).get("ID"));
			if (iMap.containsKey("LOG_LEVEL")) {
				xMap.put("LOG_LEVEL", iMap.get("LOG_LEVEL"));
			}
			
			brmSonuc = new ifrsBrmSonuc();
			brmSonucId = new ifrsBrmSonucId();
			brmSonucId.setAccountId(iMap.getString("Accountid"));
			brmSonucId.setReferenceDate(iMap.getDate("Referencedate"));
			brmSonucId.setInput(iMap.toString().length() > 2000 ? iMap.toString().substring(0, 1980) : iMap.toString());
			
			try{
				i.setProcessDate(new Date());
				bMap.putAll(GMServiceExecuter.execute("BNSPR_BRM_DECISION_IFRS_CALL", xMap));
				brmSonucId.setResultCode("S");
				i.setIsProcessed(SUCCESS);
				
			}catch(Exception e){
				e.printStackTrace();
				brmSonucId.setResultCode("E");
				i.setIsProcessed(BRM_ERROR);
				if(e != null && e.getMessage() != null){
					brmSonucId.setError("NBSM HATA :" + (e.getMessage().length() > 1980 ? e.getMessage().substring(0, 1980) : e.getMessage()));
				}
			}
			
			brmSonuc.setId(brmSonucId);
			session.saveOrUpdate(brmSonuc);
			
			o = (ifrsOutput) session.createCriteria(ifrsOutput.class).add(Restrictions.eq("id.referenceDate", iMap.getDate("Referencedate"))).add(Restrictions.eq("id.accountId", iMap.getString("Accountid"))).uniqueResult();
			if(o == null){
				o = new ifrsOutput();
				ifrsOutputId oId = new ifrsOutputId();
				oId.setAccountId(iMap.getString("Accountid"));
				oId.setReferenceDate(iMap.getDate("Referencedate"));
				o.setId(oId);
			}
			
			o.setAge(bMap.getBigDecimal("Age"));
			o.setCcf(bMap.getBigDecimal("Ccf"));
			o.setCp(bMap.getBigDecimal("Cp"));
			o.setCustomerId(bMap.getString("Customerid"));
			o.setDecisionCategory(bMap.getString("Decisioncategory"));
			o.setDerInterestRate(bMap.getBigDecimal("Derinterestrate"));
			o.setDiscountVector1(bMap.getBigDecimal("Discountvector1"));
			o.setDiscountVector2(bMap.getBigDecimal("Discountvector2"));
			o.setDiscountVector3(bMap.getBigDecimal("Discountvector3"));
			o.setDiscountVector4(bMap.getBigDecimal("Discountvector4"));
			o.setDiscountVector5(bMap.getBigDecimal("Discountvector5"));
			o.setDiscountVector6(bMap.getBigDecimal("Discountvector6"));
			o.setDiscountVector7(bMap.getBigDecimal("Discountvector7"));
			o.setDiscountVector8(bMap.getBigDecimal("Discountvector8"));
			o.setDiscountVector9(bMap.getBigDecimal("Discountvector9"));
			o.setDiscountVector10(bMap.getBigDecimal("Discountvector10"));
			o.setEadYear1(bMap.getBigDecimal("Eadyear1"));
			o.setEadYear2(bMap.getBigDecimal("Eadyear2"));
			o.setEadYear3(bMap.getBigDecimal("Eadyear3"));
			o.setEadYear4(bMap.getBigDecimal("Eadyear4"));
			o.setEadYear5(bMap.getBigDecimal("Eadyear5"));
			o.setEadYear6(bMap.getBigDecimal("Eadyear6"));
			o.setEadYear7(bMap.getBigDecimal("Eadyear7"));
			o.setEadYear8(bMap.getBigDecimal("Eadyear8"));
			o.setEadYear9(bMap.getBigDecimal("Eadyear9"));
			o.setEadYear10(bMap.getBigDecimal("Eadyear10"));
			o.setEcl12month(bMap.getBigDecimal("Ecl12month"));
			o.setEclBaseFinal(bMap.getBigDecimal("Eclbasefinal"));
			o.setEclBase12month(bMap.getBigDecimal("Eclbase12month"));
			o.setEclBaseLifetime(bMap.getBigDecimal("Eclbaselifetime"));
			o.setEclBaseYear1(bMap.getBigDecimal("Eclbaseyear1"));
			o.setEclBaseYear2(bMap.getBigDecimal("Eclbaseyear2"));
			o.setEclBaseYear3(bMap.getBigDecimal("Eclbaseyear3"));
			o.setEclBaseYear4(bMap.getBigDecimal("Eclbaseyear4"));
			o.setEclBaseYear5(bMap.getBigDecimal("Eclbaseyear5"));
			o.setEclBaseYear6(bMap.getBigDecimal("Eclbaseyear6"));
			o.setEclBaseYear7(bMap.getBigDecimal("Eclbaseyear7"));
			o.setEclBaseYear8(bMap.getBigDecimal("Eclbaseyear8"));
			o.setEclBaseYear9(bMap.getBigDecimal("Eclbaseyear9"));
			o.setEclBaseYear10(bMap.getBigDecimal("Eclbaseyear10"));
			o.setEclFinal(bMap.getBigDecimal("Eclfinal"));
			o.setEclHigh12month(bMap.getBigDecimal("Eclhigh12month"));
			o.setEclHighFinal(bMap.getBigDecimal("Eclhighfinal"));
			o.setEclHighLifetime(bMap.getBigDecimal("Eclhighlifetime"));
			o.setEclHighYear1(bMap.getBigDecimal("Eclhighyear1"));
			o.setEclHighYear2(bMap.getBigDecimal("Eclhighyear2"));
			o.setEclHighYear3(bMap.getBigDecimal("Eclhighyear3"));
			o.setEclHighYear4(bMap.getBigDecimal("Eclhighyear4"));
			o.setEclHighYear5(bMap.getBigDecimal("Eclhighyear5"));
			o.setEclHighYear6(bMap.getBigDecimal("Eclhighyear6"));
			o.setEclHighYear7(bMap.getBigDecimal("Eclhighyear7"));
			o.setEclHighYear8(bMap.getBigDecimal("Eclhighyear8"));
			o.setEclHighYear9(bMap.getBigDecimal("Eclhighyear9"));
			o.setEclHighYear10(bMap.getBigDecimal("Eclhighyear10"));
			o.setEclLifetime(bMap.getBigDecimal("Ecllifetime"));
			o.setEclLow12month(bMap.getBigDecimal("Ecllow12month"));
			o.setEclLowFinal(bMap.getBigDecimal("Ecllowfinal"));
			o.setEclLowLifetime(bMap.getBigDecimal("Ecllowlifetime"));
			o.setEclLowYear1(bMap.getBigDecimal("Ecllowyear1"));
			o.setEclLowYear2(bMap.getBigDecimal("Ecllowyear2"));
			o.setEclLowYear3(bMap.getBigDecimal("Ecllowyear3"));
			o.setEclLowYear4(bMap.getBigDecimal("Ecllowyear4"));
			o.setEclLowYear5(bMap.getBigDecimal("Ecllowyear5"));
			o.setEclLowYear6(bMap.getBigDecimal("Ecllowyear6"));
			o.setEclLowYear7(bMap.getBigDecimal("Ecllowyear7"));
			o.setEclLowYear8(bMap.getBigDecimal("Ecllowyear8"));
			o.setEclLowYear9(bMap.getBigDecimal("Ecllowyear9"));
			o.setEclLowYear10(bMap.getBigDecimal("Ecllowyear10"));
			o.setLgdNewSegment(bMap.getString("Lgdnewsegment"));
			o.setLgdYear1(bMap.getBigDecimal("Lgdyear1"));
			o.setLgdYear2(bMap.getBigDecimal("Lgdyear2"));
			o.setLgdYear3(bMap.getBigDecimal("Lgdyear3"));
			o.setLgdYear4(bMap.getBigDecimal("Lgdyear4"));
			o.setLgdYear5(bMap.getBigDecimal("Lgdyear5"));
			o.setLgdYear6(bMap.getBigDecimal("Lgdyear6"));
			o.setLgdYear7(bMap.getBigDecimal("Lgdyear7"));
			o.setLgdYear8(bMap.getBigDecimal("Lgdyear8"));
			o.setLgdYear9(bMap.getBigDecimal("Lgdyear9"));
			o.setLgdYear10(bMap.getBigDecimal("Lgdyear10"));
			o.setLoanChannel(bMap.getString("Loanchannel"));
			o.setMaturityVector1(bMap.getBigDecimal("Maturityvector1"));
			o.setMaturityVector2(bMap.getBigDecimal("Maturityvector2"));
			o.setMaturityVector3(bMap.getBigDecimal("Maturityvector3"));
			o.setMaturityVector4(bMap.getBigDecimal("Maturityvector4"));
			o.setMaturityVector5(bMap.getBigDecimal("Maturityvector5"));
			o.setMaturityVector6(bMap.getBigDecimal("Maturityvector6"));
			o.setMaturityVector7(bMap.getBigDecimal("Maturityvector7"));
			o.setMaturityVector8(bMap.getBigDecimal("Maturityvector8"));
			o.setMaturityVector9(bMap.getBigDecimal("Maturityvector9"));
			o.setMaturityVector10(bMap.getBigDecimal("Maturityvector10"));
			o.setNcr(bMap.getBigDecimal("Ncr"));
			o.setNplRatio(bMap.getBigDecimal("Nplratio"));
			o.setPdBaseYear1(bMap.getBigDecimal("Pdbaseyear1"));
			o.setPdBaseYear2(bMap.getBigDecimal("Pdbaseyear2"));
			o.setPdBaseYear3(bMap.getBigDecimal("Pdbaseyear3"));
			o.setPdBaseYear4(bMap.getBigDecimal("Pdbaseyear4"));
			o.setPdBaseYear5(bMap.getBigDecimal("Pdbaseyear5"));
			o.setPdBaseYear6(bMap.getBigDecimal("Pdbaseyear6"));
			o.setPdBaseYear7(bMap.getBigDecimal("Pdbaseyear7"));
			o.setPdBaseYear8(bMap.getBigDecimal("Pdbaseyear8"));
			o.setPdBaseYear9(bMap.getBigDecimal("Pdbaseyear9"));
			o.setPdBaseYear10(bMap.getBigDecimal("Pdbaseyear10"));
			o.setPdHighYear1(bMap.getBigDecimal("Pdhighyear1"));
			o.setPdHighYear2(bMap.getBigDecimal("Pdhighyear2"));
			o.setPdHighYear3(bMap.getBigDecimal("Pdhighyear3"));
			o.setPdHighYear4(bMap.getBigDecimal("Pdhighyear4"));
			o.setPdHighYear5(bMap.getBigDecimal("Pdhighyear5"));
			o.setPdHighYear6(bMap.getBigDecimal("Pdhighyear6"));
			o.setPdHighYear7(bMap.getBigDecimal("Pdhighyear7"));
			o.setPdHighYear8(bMap.getBigDecimal("Pdhighyear8"));
			o.setPdHighYear9(bMap.getBigDecimal("Pdhighyear9"));
			o.setPdHighYear10(bMap.getBigDecimal("Pdhighyear10"));
			o.setPdLowYear1(bMap.getBigDecimal("Pdlowyear1"));
			o.setPdLowYear2(bMap.getBigDecimal("Pdlowyear2"));
			o.setPdLowYear3(bMap.getBigDecimal("Pdlowyear3"));
			o.setPdLowYear4(bMap.getBigDecimal("Pdlowyear4"));
			o.setPdLowYear5(bMap.getBigDecimal("Pdlowyear5"));
			o.setPdLowYear6(bMap.getBigDecimal("Pdlowyear6"));
			o.setPdLowYear7(bMap.getBigDecimal("Pdlowyear7"));
			o.setPdLowYear8(bMap.getBigDecimal("Pdlowyear8"));
			o.setPdLowYear9(bMap.getBigDecimal("Pdlowyear9"));
			o.setPdLowYear10(bMap.getBigDecimal("Pdlowyear10"));
			o.setPdScore(bMap.getBigDecimal("Pdscore"));
			o.setPdYear1(bMap.getBigDecimal("Pdyear1"));
			o.setPdYear2(bMap.getBigDecimal("Pdyear2"));
			o.setPdYear3(bMap.getBigDecimal("Pdyear3"));
			o.setPdYear4(bMap.getBigDecimal("Pdyear4"));
			o.setPdYear5(bMap.getBigDecimal("Pdyear5"));
			o.setPdYear6(bMap.getBigDecimal("Pdyear6"));
			o.setPdYear7(bMap.getBigDecimal("Pdyear7"));
			o.setPdYear8(bMap.getBigDecimal("Pdyear8"));
			o.setPdYear9(bMap.getBigDecimal("Pdyear9"));
			o.setPdYear10(bMap.getBigDecimal("Pdyear10"));
			o.setRefPdPool(bMap.getBigDecimal("Refpdpool"));
			o.setRemainingMaturity(bMap.getBigDecimal("Remainingmaturity"));
			o.setRemMaturity(bMap.getBigDecimal("RemMaturity"));
			o.setScenario(bMap.getBigDecimal("Scenario"));
			o.setSortedDecisionTable1(bMap.getString("SortedDecisionTable"));
			o.setSortedDecisionTable2(bMap.getString("SortedDecisionTable2"));
			o.setSortedDecisionTable3(bMap.getString("SortedDecisionTable3"));
			o.setSortedDecisionTable4(bMap.getString("SortedDecisionTable4"));
			o.setSortedDecisionTable5(bMap.getString("SortedDecisionTable5"));
			o.setSortedDecisionTable6(bMap.getString("SortedDecisionTable6"));
			o.setSortedDecisionTable7(bMap.getString("SortedDecisionTable7"));
			o.setSortedDecisionTable8(bMap.getString("SortedDecisionTable8"));
			o.setSortedDecisionTable9(bMap.getString("SortedDecisionTable9"));
			o.setSortedDecisionTable10(bMap.getString("SortedDecisionTable10"));
			o.setSortedReasonCodeTable1(bMap.getString("SortedReasonCodeTable"));
			o.setSortedReasonCodeTable2(bMap.getString("SortedReasonCodeTable2"));
			o.setSortedReasonCodeTable3(bMap.getString("SortedReasonCodeTable3"));
			o.setSortedReasonCodeTable4(bMap.getString("SortedReasonCodeTable4"));
			o.setSortedReasonCodeTable5(bMap.getString("SortedReasonCodeTable5"));
			o.setSortedReasonCodeTable6(bMap.getString("SortedReasonCodeTable6"));
			o.setSortedReasonCodeTable7(bMap.getString("SortedReasonCodeTable7"));
			o.setSortedReasonCodeTable8(bMap.getString("SortedReasonCodeTable8"));
			o.setSortedReasonCodeTable9(bMap.getString("SortedReasonCodeTable9"));
			o.setSortedReasonCodeTable10(bMap.getString("SortedReasonCodeTable10"));
			o.setStage(bMap.getBigDecimal("Stage"));
			o.setTimeInDefaultDays(bMap.getBigDecimal("Timeindefaultdays"));
			o.setTimeSinceCustomer(bMap.getBigDecimal("Timesincecustomer"));
			o.setUrunSinifKod(bMap.getString("Urunsinifkod"));
			
			session.saveOrUpdate(o);
			session.flush();
		}
		catch (Exception e) {
			LOGGER.error("BNPSR_CL_IFRS_CALL Hata. Account Id :" + iMap.getString("Accountid") + " Hata :");
			e.printStackTrace();
			i.setIsProcessed(EXCEPTION);
			session.saveOrUpdate(i);
			session.flush();
		}

		return bMap;
	}
	
	@GraymoundService("BNSPR_LIST_IFRS_CALL")
	public static GMMap listIfrsCall(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = null;

		try {
			session = DAOSession.getSession("BNSPRDal");
			
			if(iMap.get("REFERENCE_DATE") == null) {
				iMap.put("REFERENCE_DATE", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).get("BANKA_TARIH"));
			}
			iMap.put("PARAMETRE", "BIR_IFRS_NBSM_LOG_LEVEL");
			iMap.put("LOG_LEVEL", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N" , iMap).getInt("DEGER"));
			
			@SuppressWarnings("unchecked")
			List<ifrsinput> inputList = session.createCriteria(ifrsinput.class).add(Restrictions.or(Restrictions.isNull("isProcessed"), Restrictions.eq("isProcessed", "0"))).setMaxResults(MAX_RESULT).list();
			int i = 0;
			for (ifrsinput input : inputList) {
				oMap.put("RESULTS", i, "Producttype", input.getProductType());
				oMap.put("RESULTS", i, "Urunturkod", input.getUrunTurKod());
				oMap.put("RESULTS", i, "Urunsinifkod", input.getUrunSinifKod());
				oMap.put("RESULTS", i, "Kreditip", input.getKrediTip());
				oMap.put("RESULTS", i, "Subproducttype", input.getSubProductType());
				oMap.put("RESULTS", i, "Lastdefaultdate", ConsumerLoanCommonServices.nvl(input.getLastDefaultDate(), "19000101"));
				oMap.put("RESULTS", i, "Referencedate", input.getId().getReferenceDate());
				oMap.put("RESULTS", i, "Customerdefaultflag", (Integer) ConsumerLoanCommonServices.nvl(input.getCustomerDefaultFlag(), BigDecimal.ZERO).intValue());
				oMap.put("RESULTS", i, "Dayspastdueatcustomerlvl", (Integer) ConsumerLoanCommonServices.nvl(input.getDaysPastDueAtCustomerLvl(), BigDecimal.ZERO).intValue());
				oMap.put("RESULTS", i, "Minislemtarihi", ConsumerLoanCommonServices.nvl(input.getMinIslemTarihi(), "19000101"));
				oMap.put("RESULTS", i, "Totalcashexposure", ConsumerLoanCommonServices.nvl(input.getTotalCashExposure(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Nplexposure", ConsumerLoanCommonServices.nvl(input.getNplExposure(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Disbursementdate", ConsumerLoanCommonServices.nvl(input.getDisbursementDate(), "19000101"));
				oMap.put("RESULTS", i, "Customerid", ConsumerLoanCommonServices.nvl(input.getId().getCustomerId(), 2));
				oMap.put("RESULTS", i, "Accountid", input.getId().getAccountId());
				oMap.put("RESULTS", i, "Outstandingbalance", ConsumerLoanCommonServices.nvl(input.getOutstandingBalance(), 0));
				oMap.put("RESULTS", i, "Dvzalis", ConsumerLoanCommonServices.nvl(input.getDvzalis(), 1));
				oMap.put("RESULTS", i, "Maturitydate", ConsumerLoanCommonServices.nvl(input.getMaturityDate(), "19000101"));
				oMap.put("RESULTS", i, "Accountopendate", ConsumerLoanCommonServices.nvl(input.getAccountOpenDate(), "19000101"));
				oMap.put("RESULTS", i, "Numberoftotalinstallments", ConsumerLoanCommonServices.nvl(input.getNumberOfTotalInstallments(), -1));
				oMap.put("RESULTS", i, "Numberofremaininginst", ConsumerLoanCommonServices.nvl(input.getNumberOfRemainingInst(), -1));
				oMap.put("RESULTS", i, "Year1sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear1SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year2sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear2SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year3sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear3SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year4sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear4SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year5sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear5SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year6sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear6SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year7sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear7SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year8sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear8SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year9sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear9SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Year10sumofinstallments", ConsumerLoanCommonServices.nvl(input.getYear10SumOfInstallments(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Lao", ConsumerLoanCommonServices.nvl(input.getLao(), 0));
				oMap.put("RESULTS", i, "Last6mnthmaxdaypassdue", ConsumerLoanCommonServices.nvl(input.getLast6MnthMaxDayPassDue(), -1));
				oMap.put("RESULTS", i, "Last12mnnumdelinquency2", ConsumerLoanCommonServices.nvl(input.getLast12MnNumDelinquency2(), -1));
				oMap.put("RESULTS", i, "Avglast3mtpayoutsbal", ConsumerLoanCommonServices.nvl(input.getAvgLast3MTPayOutsBal(), -1));
				oMap.put("RESULTS", i, "Loanchannelid", ConsumerLoanCommonServices.nvl(input.getLoanChannelId(), 4));
				oMap.put("RESULTS", i, "Last6mnthtotalnumloans", ConsumerLoanCommonServices.nvl(input.getLast6MnthTotalNumLoans(), -1));
				oMap.put("RESULTS", i, "Timesincefirstaccountcr", ConsumerLoanCommonServices.nvl(input.getTimeSinceFirstAccountCr(), "19000101"));
				oMap.put("RESULTS", i, "Customerbirthdate", ConsumerLoanCommonServices.nvl(input.getCustomerBirthDate(), "19000101"));
				oMap.put("RESULTS", i, "Interestrate", ConsumerLoanCommonServices.nvl(input.getInterestRate(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Country", input.getCountryCode());
				oMap.put("RESULTS", i, "CurrencyCode", input.getCurrencyCode());
				oMap.put("RESULTS", i, "CountrepartyDefaultFlag", ConsumerLoanCommonServices.nvl(input.getCountrepartyDefaultFlag(), "-1"));
				oMap.put("RESULTS", i, "Personelflag", ConsumerLoanCommonServices.nvl(input.getPersonelFlag(), "H"));
				oMap.put("RESULTS", i, "Defaultid", input.getDefaultId());
				oMap.put("RESULTS", i, "Bakiye", ConsumerLoanCommonServices.nvl(input.getBakiye(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Birikmisfaiz", ConsumerLoanCommonServices.nvl(input.getBirikmisFaiz(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Bakiyetl", ConsumerLoanCommonServices.nvl(input.getBakiyeTl(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Risk", ConsumerLoanCommonServices.nvl(input.getRisk(), BigDecimal.ZERO));
				oMap.put("RESULTS", i, "Musteridkno", input.getMusteriDkNo());
				oMap.put("RESULTS", i, "Dkreeskont", input.getDkReeskont());
				oMap.put("RESULTS", i, "Dkpasifhesapno", input.getDkPasifhesapNo());
				oMap.put("RESULTS", i, "Kdo", ConsumerLoanCommonServices.nvl(input.getKdo(), BigDecimal.ONE));
				oMap.put("RESULTS", i, "Riskgrubu", ConsumerLoanCommonServices.nvl(input.getRiskGrubu(), BigDecimal.ZERO));
				
				oMap.put("RESULTS", i, "LOG_LEVEL", iMap.get("LOG_LEVEL"));
				i++;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_IFRS_PROCESS_JOB")
	public static GMMap IfrsProcessJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("IS_PARALLEL", true);
			iMap.put("LIST_SERVICE_NAME", "BNSPR_LIST_IFRS_CALL");
			iMap.put("PROCESS_SERVICE_NAME", "BNSPR_CL_IFRS_CALL");
			iMap.put("THREAD_SIZE", 16);
			GMServiceExecuter.execute("BNSPR_PROCESS_CREDIT_CARD_JOB", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

}
