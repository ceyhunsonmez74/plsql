package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.BirKrediTaksitGecSilTx;
import tr.com.aktifbank.bnspr.dao.BirKrediTaksitGecSilTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3222Services {
	@GraymoundService("BNSPR_TRN3222_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3222.GET_TAKSIT_LIST(?)}");
			
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			
			GMMap sMap = new GMMap();
			sMap = (GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", sMap ) );
		
			String tableName = "TAKSIT_LISTESI";
			int row = 0;
			while (rSet.next()) {
			  oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal("SIRA_NO"));
			  oMap.put(tableName, row, "TAKSIT_TARIH", rSet.getDate("TAKSIT_TARIH"));
			  oMap.put(tableName, row, "TAKSIT_TUT", rSet.getBigDecimal("TAKSIT_TUT"));
			  oMap.put(tableName, row, "DURUM_KOD", rSet.getString("DURUM_KOD"));
			  String durum = rSet.getString("DURUM_KOD");
			  oMap.put(tableName, row, "ODEME_TARIH", rSet.getDate("ODEME_TARIH"));
			  String odemeTarihi = rSet.getString("ODEME_TARIH");
			  
			  if ( (durum.compareTo("ACIK") ==0) &&  odemeTarihi == null && sMap.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH") ) > 0
						&& rSet.getBigDecimal("TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1 ){
					oMap.put(tableName, row, "DURUM_KOD","GECIKMEDE") ;
				}
			  
			  if ( (durum.compareTo("ACIK") ==0) &&  sMap.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH") ) > -1
						&& rSet.getBigDecimal("TAKSIT_TUT").compareTo(new BigDecimal(0)) == 0 ){
					oMap.put(tableName, row, "DURUM_KOD","ODENDI") ;
				}
			  
			  oMap.put(tableName, row, "GECIKME_FAIZI", rSet.getBigDecimal("GECIKME_FAIZ_TUTARI"));
			  oMap.put(tableName, row, "GECIKME_FAIZ_ALINAN", rSet.getBigDecimal("GECIKME_FAIZ_ALINAN"));
			 
			  row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		

	@GraymoundService("BNSPR_TRN3222_SAVE")
	public static Map<?, ?> save(GMMap iMap){

		try{
			Session session = DAOSession.getSession("BNSPRDal"); 
            String tableName = "TAKSIT_LISTESI";
			List<?> guiList = (List<?>)iMap.get(tableName);
			if(guiList.size()==0){
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		
			for (int i = 0; i < guiList.size(); i++) {
			 if(iMap.getString(tableName,i,"DURUM_KOD").equals("GECIKMEDE") || iMap.getString(tableName,i,"DURUM_KOD").equals("KISMI")){
				BirKrediTaksitGecSilTx birKrediTaksitGecSilTx = new BirKrediTaksitGecSilTx();
				BirKrediTaksitGecSilTxId id=new BirKrediTaksitGecSilTxId();
				
			    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			    id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			    id.setSiraNo(iMap.getBigDecimal(tableName, i,"SIRA_NO"));
			    birKrediTaksitGecSilTx.setId(id);
			    birKrediTaksitGecSilTx.setDurumKod(iMap.getString(tableName, i,"DURUM_KOD"));
			    birKrediTaksitGecSilTx.setGecikmeFaizAlinan(iMap.getBigDecimal(tableName, i,"GECIKME_FAIZ_ALINAN"));
			    birKrediTaksitGecSilTx.setGecikmeFaizTutari(iMap.getBigDecimal(tableName, i,"GECIKME_FAIZI"));
			    birKrediTaksitGecSilTx.setOdemeTarih(iMap.getDate(tableName, i,"ODEME_TARIH"));
			    birKrediTaksitGecSilTx.setTaksitTarih(iMap.getDate(tableName, i,"TAKSIT_TARIH"));
			    birKrediTaksitGecSilTx.setTaksitTut(iMap.getBigDecimal(tableName, i,"TAKSIT_TUT"));
			    session.save(birKrediTaksitGecSilTx);
			 }
				
			}
			session.flush();  
			iMap.put("TRX_NAME", "3222");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3222_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = (List<?>)session.createCriteria(BirKrediTaksitGecSilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		
		
		String tableName = "TAKSIT_LISTESI";
		int row = 0;
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			BirKrediTaksitGecSilTx birKrediTaksitGecSilTx = (BirKrediTaksitGecSilTx) iterator.next();
			oMap.put(tableName, row, "SIRA_NO", birKrediTaksitGecSilTx.getId().getSiraNo());
			oMap.put("BASVURU_NO", birKrediTaksitGecSilTx.getId().getBasvuruNo());
			oMap.put(tableName, row, "TAKSIT_TARIH", birKrediTaksitGecSilTx.getTaksitTarih());
			oMap.put(tableName, row, "TAKSIT_TUT", birKrediTaksitGecSilTx.getTaksitTut());
			oMap.put(tableName, row, "DURUM_KOD", birKrediTaksitGecSilTx.getDurumKod());
			oMap.put(tableName, row, "ODEME_TARIH", birKrediTaksitGecSilTx.getOdemeTarih());
			oMap.put(tableName, row, "GECIKME_FAIZI", birKrediTaksitGecSilTx.getGecikmeFaizTutari());
			oMap.put(tableName, row, "GECIKME_FAIZ_ALINAN", birKrediTaksitGecSilTx.getGecikmeFaizAlinan());
			oMap.put(tableName, row, "GECIKME_FAIZ_ALINAN", birKrediTaksitGecSilTx.getGecikmeFaizAlinan());
			row++;
		}
		conn = DALUtil.getGMConnection();
		stmt = conn.prepareCall("{? = call PKG_TRN3222.GET_MUSTERI(?)}");
			
		stmt.registerOutParameter(1, -10); //ref cursor
		stmt.setBigDecimal(2, oMap.getBigDecimal("BASVURU_NO"));
		stmt.execute();
		rSet = (ResultSet)stmt.getObject(1);
		while(rSet.next()){
		oMap.put("MUSTERI_NO",rSet.getBigDecimal("MUSTERI_NO"));
		oMap.put("UNVAN", rSet.getString("ADI_SOYADI"));
		}
        	return oMap;
        	
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	
}
