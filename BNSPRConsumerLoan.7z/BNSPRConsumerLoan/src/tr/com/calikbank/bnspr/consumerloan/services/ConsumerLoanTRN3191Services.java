package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrdAltTur2Tx;
import tr.com.aktifbank.bnspr.dao.BirKrdAltTur2TxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKrdAltTurTx;
import tr.com.calikbank.bnspr.dao.BirKrdAltTurTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3191Services {
	@GraymoundService("BNSPR_TRN3191_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "KRD_TUR_KOD", true, "SELECT KOD,ACIKLAMA FROM v_ml_bir_krd_tur ORDER BY to_number(KOD)");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3191_GET_LIST")
	public static GMMap GetList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		ResultSet rSet2 = null;		
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3191.NBSM_URUN_PARAMETRESI(?,?,?)}");
    		stmt.setBigDecimal(1,iMap.getBigDecimal("KRD_TUR_KOD"));
			stmt.registerOutParameter(2, -10); //ref cursor
			stmt.registerOutParameter(3, -10); //ref cursor
			stmt.execute();
			rSet1 = (ResultSet)stmt.getObject(2);
		    oMap = DALUtil.rSetResults(rSet1, "TABLE1");
		    rSet2 = (ResultSet)stmt.getObject(3);
		    oMap.putAll(DALUtil.rSetResults(rSet2, "TABLE2"));	
		return oMap;
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
	
		}
		
	}			
	
	@GraymoundService("BNSPR_TRN3191_SAVE")
	public static Map<?, ?> saveTRN3191save(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "TABLE1";
			
			List<?> list = (List<?>) iMap.get(tableName);
			for(int i=0; i<list.size();i++) {
			    BirKrdAltTurTxId id = new BirKrdAltTurTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKrdTurKod(iMap.getBigDecimal("KRD_TUR_KOD"));
				id.setKod(iMap.getBigDecimal(tableName, i,"KOD"));
				
				BirKrdAltTurTx birKrdAltTurTx = new BirKrdAltTurTx();
				birKrdAltTurTx.setId(id);
				birKrdAltTurTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				birKrdAltTurTx.setNbsmKod(iMap.getString(tableName, i,"NBSM_KOD"));
			    if (iMap.getString(tableName, i,"DURUM") != null && !"".equals(iMap.getString(tableName, i,"DURUM"))&& iMap.getString(tableName, i,"DURUM").equals("Ge�erli")){
    			birKrdAltTurTx.setDrm("G");
                }else if(iMap.getString(tableName, i,"DURUM") != null && !"".equals(iMap.getString(tableName, i,"DURUM"))&& iMap.getString(tableName, i,"DURUM").equals("Ge�ersiz")){
                birKrdAltTurTx.setDrm("I");}
				session.saveOrUpdate(birKrdAltTurTx);
		     }
			session.flush();
						
		   String tableName2 = "TABLE2";
		    	
				List<?> list2 = (List<?>) iMap.get(tableName2);
				for(int j=0; j<list2.size();j++) 
				{
					BirKrdAltTur2Tx birKrdAltTur2Tx = new BirKrdAltTur2Tx();
					BirKrdAltTur2TxId id2 = new BirKrdAltTur2TxId();
					id2.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id2.setKrdTurKod(iMap.getBigDecimal("KRD_TUR_KOD"));
					id2.setKod(iMap.getBigDecimal(tableName2, j,"KOD"));
					id2.setKrdTurAltKod(iMap.getBigDecimal(tableName2, j,"KRD_TUR_ALT_KOD"));
					
				birKrdAltTur2Tx.setId(id2);
				birKrdAltTur2Tx.setAciklama(iMap.getString(tableName2, j, "ACIKLAMA"));
				birKrdAltTur2Tx.setNbsmKod(iMap.getString(tableName2, j,"NBSM_KOD"));
				if (iMap.getString(tableName2, j,"DURUM2") != null && !"".equals(iMap.getString(tableName2, j,"DURUM2")) && iMap.getString(tableName2, j,"DURUM2").equals("Ge�erli")){
				birKrdAltTur2Tx.setDrm("G");
                }else if(iMap.getString(tableName2, j,"DURUM2") != null && !"".equals(iMap.getString(tableName2, j,"DURUM2")) && iMap.getString(tableName2, j,"DURUM2").equals("Ge�ersiz")){
                birKrdAltTur2Tx.setDrm("I");}
				session.saveOrUpdate(birKrdAltTur2Tx);
		     }
				session.flush();
			
			iMap.put("TRX_NAME", "3191");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}catch (Exception e) {
			
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3191_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirKrdAltTurTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "TABLE1";
			int row = 0;
			GMMap oMap = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				BirKrdAltTurTx birKrdAltTurTx = (BirKrdAltTurTx) iterator.next();
				oMap.put(tableName, row, "KOD", birKrdAltTurTx.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA", birKrdAltTurTx.getAciklama());
				oMap.put(tableName, row, "NBSM_KOD", birKrdAltTurTx.getNbsmKod());
				oMap.put(tableName, row, "DURUM",   birKrdAltTurTx.getDrm()); 
				
			}
			List<?> list2 = (List<?>) session.createCriteria(BirKrdAltTur2Tx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName2 = "TABLE2";
			int row2 = 0;
			GMMap xMap = new GMMap();
			for (Iterator<?> iterator = list2.iterator(); iterator.hasNext();row2++) {
				BirKrdAltTur2Tx birKrdAltTur2Tx = (BirKrdAltTur2Tx) iterator.next();
				xMap.put(tableName2, row2, "KRD_TUR_ALT_KOD", birKrdAltTur2Tx.getId().getKrdTurAltKod());
				xMap.put(tableName2, row2, "KRD_TUR_KOD", birKrdAltTur2Tx.getId().getKrdTurKod());
				xMap.put(tableName2, row2, "KOD", birKrdAltTur2Tx.getId().getKod());
				xMap.put(tableName2, row2, "ACIKLAMA", birKrdAltTur2Tx.getAciklama());
				xMap.put(tableName2, row2, "NBSM_KOD", birKrdAltTur2Tx.getNbsmKod());
				xMap.put(tableName2, row2, "DURUM2",   birKrdAltTur2Tx.getDrm()); 
				xMap.put("KRD_TUR_KOD", birKrdAltTur2Tx.getId().getKrdTurKod());
			}
			
			oMap.putAll(xMap);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
	
	
	
	
