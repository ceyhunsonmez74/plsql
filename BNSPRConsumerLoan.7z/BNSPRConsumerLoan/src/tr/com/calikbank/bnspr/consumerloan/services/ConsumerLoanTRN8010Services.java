package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.Map;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8010Services {
	
	@GraymoundService("BNSPR_TRN8010_SAVE")
	public static Map<?, ?> saveTRN8010(GMMap iMap) {
		try {
			GMServiceExecuter.call("BNSPR_YIM_ODEME_GUNCELLEME", iMap);
			iMap.put("KRD_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			iMap.put("DURUM_KODU", iMap.getBigDecimal("DURUM"));
			GMServiceExecuter.call("BNSPR_YIM_DURUM_GUNCELLE", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		iMap.put("MESSAGE", "��leminiz ba�ar�yla ger�ekle�tirilmi�tir.");
		return iMap;
	}
	
	@GraymoundService("BNSPR_GET_YIM_CREDIT_LIST")
	public static GMMap getBasvuruRapor(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "RESULT";

		try {
			java.util.Date startDate = iMap.getDate("ILK_TARIH");
			java.util.Date endDate = iMap.getDate("SON_TARIH");
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call pkg_yim.getYimKrediList(?, ?, ?, ?, ?, ?)}");
			int paramIndex = 1;
			stmt.setBigDecimal(paramIndex++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(paramIndex++, iMap.getString("TCKN"));
			stmt.setString(paramIndex++, iMap.getString("DURUM"));
			stmt.setDate(paramIndex++, startDate != null ? new Date(startDate.getTime()) : null);
			stmt.setDate(paramIndex++, endDate != null ? new Date(endDate.getTime()) : null);
			stmt.registerOutParameter(paramIndex, -10);
			stmt.execute();
			stmt.getMoreResults();
			
			rSet = (ResultSet) stmt.getObject(paramIndex);
			oMap = DALUtil.rSetResults(rSet, tableName);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8010_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "RESULT";
		Object[] inputs = {BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO")};
		
		try {
			oMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_yim.getYimTx(?)}", tableName, inputs);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

}
