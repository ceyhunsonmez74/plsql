package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import tr.com.aktifbank.integration.ebs.EBSClient;
import tr.com.calikbank.bnspr.consumerloan.services.ConsumerLoanVehicleServices.HasarInfo.Attribute;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class ConsumerLoanVehicleServices implements Constants {

	public class HasarInfo {
		public class Attribute {
			public String type;
			public String name;
			public String value;
		}

		public class Value {
			public String typeName;
			public List<Attribute> attribute;
		}

		public class Root {
			public int executionTime;
			public List<Value> values;
		}
	}

	private final static String confFile = "aktifbank-consumerloan-ext.properties";

	/**
	 * Arac markalarini doner.
	 * 
	 * @author huseyin.ceteci
	 * @return oMap - Sonuc bilgisi <li>RESPONSE - Islem sonuc kodu (0:Basarisiz | 2:Basarili) <li>RESPONSE_DATA - Islem sonuc aciklamasi. <li>MAKES - Arac markalarini MAKE kolonunda donen tablo.
	 */
	@GraymoundService("BNSPR_GET_VEHICLE_MAKES")
	public static GMMap getVehicleMakes(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap = EBSClient.getVehicleMakes();
			oMap.put(RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
			if (!oMap.containsKey(MAKES)) {
				oMap.put(RESPONSE_DATA, "Kay�t bulunamad�!");
			}
		}
		catch (Exception e) {
			if (YES.equals(RAISE_ERROR)) {
				throw ExceptionHandler.convertException(e);
			}
			else {
				oMap.put(RESPONSE_DATA, e.getMessage());
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			}
		}

		return oMap;
	}

	/**
	 * Arac markasina ait model yillarini doner.
	 * 
	 * @author huseyin.ceteci
	 * @param iMap
	 *            <li>MAKE_CODE - Arac markasi.
	 * @return oMap - Sonuc bilgisi <li>RESPONSE - Islem sonuc kodu (0:Basarisiz | 2:Basarili) <li>RESPONSE_DATA - Islem sonuc aciklamasi. <li>MODEL_YEARS - Model yillarini YEAR kolonunda donen tablo.
	 */
	@GraymoundService("BNSPR_GET_VEHICLE_MODEL_YEARS")
	public static GMMap getVehicleModelYears(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String makeCode = iMap.getString(MAKE_CODE);

			if (StringUtils.isEmpty(makeCode)) {
				oMap.put(RESPONSE_DATA, "Marka kodu bo� olamaz!");
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			}
			else {
				oMap = EBSClient.getVehicleModelYears(makeCode);
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
				if (!oMap.containsKey(MODEL_YEARS)) {
					oMap.put(RESPONSE_DATA, "Kay�t bulunamad�!");
				}
			}
		}
		catch (Exception e) {
			if (YES.equals(RAISE_ERROR)) {
				throw ExceptionHandler.convertException(e);
			}
			else {
				oMap.put(RESPONSE_DATA, e.getMessage());
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			}
		}

		return oMap;
	}

	/**
	 * Arac markasina ait modelleri doner.
	 * 
	 * @author huseyin.ceteci
	 * @param iMap
	 *            <li>MAKE_CODE - Arac markasi. <li>MODEL_YEAR - Model yili.
	 * @return oMap - Sonuc bilgisi <li>RESPONSE - Islem sonuc kodu (0:Basarisiz | 2:Basarili) <li>RESPONSE_DATA - Islem sonuc aciklamasi. <li>MODELS - Model bilgileri TIP, ID, BEDEL kolonlar�nda tutan tablo.
	 */
	@GraymoundService("BNSPR_GET_VEHICLE_MODELS")
	public static GMMap getVehicleModels(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String makeCode = iMap.getString(MAKE_CODE);
			String modelYear = iMap.getString(MODEL_YEAR);

			if (StringUtils.isEmpty(makeCode)) {
				oMap.put(RESPONSE_DATA, "Marka kodu bo� olamaz!");
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			}
			else if (StringUtils.isEmpty(modelYear)) {
				oMap.put(RESPONSE_DATA, "Model y�l� bo� olamaz!");
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			}
			else {
				oMap = EBSClient.getVehicleModels(makeCode, modelYear);
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
				if (!oMap.containsKey(MODELS)) {
					oMap.put(RESPONSE_DATA, "Kay�t bulunamad�!");
				}
				else {
					for (int i = 0; i < oMap.getSize(MODELS); i++) {
						BigDecimal vehicleId = oMap.getBigDecimal(MODELS, i, ID);
						oMap.put(MODELS, i, ID, vehicleId);
					}
				}
			}

		}
		catch (Exception e) {
			if (YES.equals(RAISE_ERROR)) {
				throw ExceptionHandler.convertException(e);
			}
			else {
				oMap.put(RESPONSE_DATA, e.getMessage());
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			}
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_VEHICLE_DAMAGES_INFO")
	public static GMMap getVehicleDamagesInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Configurator configurator = Configurator.createConfiguratorFromProperties(confFile);

		String endpoint = configurator.getProperty("cl.tasit.hasar.robot.url");
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost(endpoint);

		StringEntity params = null;
		try {
			params = new StringEntity("{" + "\"parameters\": [{" + "\"variableName\": \"BKTInput\"," + "\"attribute\": [" + "{" + "\"type\": \"text\"," + "\"name\": \"SasiNo\"," + "\"value\": \"" + iMap.getString("SASI_NO") + "\"" + "}" + "]}]}");
		}
		catch (UnsupportedEncodingException e1) {
			throw ExceptionHandler.convertException(e1);
		}
		post.addHeader("content-type", "application/json");
		post.addHeader("accept", "application/json");
		post.setEntity(params);

		try {
			CloseableHttpResponse response = httpClient.execute(post);
			String json = EntityUtils.toString(response.getEntity());
			oMap.put("RESPONSE", json);
			//"{\"executionTime\":239558,\"values\":[{\"typeName\":\"HasarBilgileri\",\"attribute\":[{\"type\":\"text\",\"name\":\"HasarTarihi\",\"value\":\"14.11.2020;26.07.2018;09.03.2017;10.08.2014;07.07.2014;\"},{\"type\":\"text\",\"name\":\"HasarNedeni\",\"value\":\"ERP-Carpma;ERP-Carpma;Carpma;ERP-Park Halinde �arpilma;ERP-�arpma;\"},{\"type\":\"text\",\"name\":\"HasarTutari\",\"value\":\"18.887,91 TL;78.125,41 TL;-;1.634,41 TL;403,96 TL;\"}]}]}";
			Gson gson = new GsonBuilder().disableHtmlEscaping().create();
			HasarInfo.Root output = gson.fromJson(json, HasarInfo.Root.class);
						
			List<Attribute> attributes = output.values.get(0).attribute;
			
			for (Attribute attribute : attributes) {
				String tableName = attribute.name.toUpperCase(Locale.ENGLISH);
				String[] values = attribute.value.split(";");
				int row = 0;
				for (String value : values) {
					oMap.put(tableName, row, "DEGER", value);
					row++;
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_VEHICLE_MODELS_BY_CODE")
	public static GMMap getVehicleModelsByVehicleCode(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String makeCode = iMap.getString(MAKE_CODE);
			String modelYear = iMap.getString(MODEL_YEAR);
			String vehicleCode = iMap.getString("VEHICLE_CODE");

			if (StringUtils.isEmpty(vehicleCode)) {
				oMap.put(RESPONSE_DATA, "Ara� kodu bo� olamaz!");
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			}
			else {
				oMap = EBSClient.getVehicleModels(makeCode, modelYear, vehicleCode);
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
				if (!oMap.containsKey(MODELS)) {
					oMap.put(RESPONSE_DATA, "Kay�t bulunamad�!");
				}
				else {
					for (int i = 0; i < oMap.getSize(MODELS); i++) {
						BigDecimal vehicleId = oMap.getBigDecimal(MODELS, i, ID);
						oMap.put(MODELS, i, ID, vehicleId);
					}
				}
			}

		}
		catch (Exception e) {
			if (YES.equals(RAISE_ERROR)) {
				throw ExceptionHandler.convertException(e);
			}
			else {
				oMap.put(RESPONSE_DATA, e.getMessage());
				oMap.put(RESPONSE, AkustikConstants.RESPONSE_FAIL);
			}
		}

		return oMap;
	}

}
