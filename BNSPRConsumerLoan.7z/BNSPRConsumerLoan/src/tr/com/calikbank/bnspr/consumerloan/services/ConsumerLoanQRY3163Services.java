package tr.com.calikbank.bnspr.consumerloan.services;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Types;

import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3163Services {
	
	
	@GraymoundService("BNSPR_QRY3163_GET_LIMIT_DATA")
	public static GMMap getBayiLimitData(GMMap iMap) {  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();		
			
			stmt = conn.prepareCall("{? = call PKG_RC3163.QRY3163_GET_LIMIT_DATA(?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			

				stmt.setBigDecimal(i++, iMap.getBigDecimal("BAYI_KOD")); //EK
				stmt.setString(i++, iMap.getString("BAYI_STATU")); //EK
				stmt.setBigDecimal(i++, iMap.getBigDecimal("LIMIT_TIPI")); //EK
				stmt.setString(i++, iMap.getString("DOVIZ_KODU")); //EK
				
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "RESULTS");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3163_GET_LAST_TRX_NO")
	public static GMMap getLastTRXNo(GMMap iMap){
		
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC3163.Get_MAX_Bayi_Detay_TRX_NO(?,?)}");
			int i = 1;
			//stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAYI_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			oMap.put("TRX_NO", stmt.getString(1));
			
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	

	@GraymoundService("BNSPR_QRY3163_GET_LIMIT_HAREKET_LIST")
	public static GMMap getLimitHareketList(GMMap iMap) {  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();		
			
			stmt = conn.prepareCall("{? = call PKG_RC3163.QRY3163_GET_LIMIT_HAREKET_DATA(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			
			
			
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			

				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO")); //EK
				stmt.setString(i++, iMap.getString("LIMIT_TIPI")); //EK
				stmt.setString(i++, iMap.getString("BASVURU_STATU")); //EK
				stmt.setString(i++, iMap.getString("DOVIZ_KODU")); //EK
				
				
				stmt.setString(i++, iMap.getString("BORC_ALACAK")); //EK
				
				
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_HESAP_NO")); //EK
				
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KODU")); //EK
				
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BAYI_KODU")); //EK
				
				stmt.setString(i++, iMap.getString("BAYI_STATU")); //EK
				
				
				if(iMap.get("TARIH_BAS")!=null)
					stmt.setDate(i++, new Date(iMap.getDate("TARIH_BAS").getTime()));
				else 
					stmt.setDate(i++, null);
				if(iMap.get("TARIH_SON")!=null)
					stmt.setDate(i++, new Date(iMap.getDate("TARIH_SON").getTime()));
				else 
					stmt.setDate(i++, null);
				
				
				
				stmt.registerOutParameter(i++, Types.NUMERIC); //
				stmt.registerOutParameter(i++, Types.NUMERIC); //
				stmt.registerOutParameter(i++, Types.NUMERIC); //
				
				stmt.execute();
				rSet = (ResultSet)stmt.getObject(1);
				oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));
				
				oMap.put("SUMBELGE", stmt.getBigDecimal(13));
				
				oMap.put("SUMGARANTI", stmt.getBigDecimal(14));
				
				oMap.put("SUMKEFALET", stmt.getBigDecimal(15));
			
			
			
			return oMap;
			
			
			//return DALUtil.rSetResults(rSet, "RESULTS");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	
	
	
}
