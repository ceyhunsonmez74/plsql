package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirTemTanim;
import tr.com.calikbank.bnspr.dao.BirTemTanimTx;
import tr.com.calikbank.bnspr.dao.BirTemTanimTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
 
public class ConsumerLoanTRN3104Services {

	@GraymoundService("BNSPR_TRN3104_GET_KREDI_TEMINAT_TANIM")
	public static GMMap getKrediTeminatTanim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> teminatTanimPersistenceList = (List<?>) session.createCriteria(BirTemTanim.class).add(Restrictions.eq("id.krdTurKod", iMap.getBigDecimal("KRD_TUR_KOD"))).add(Restrictions.eq("id.krdTurAltKod", iMap.getBigDecimal("KRD_TUR_ALT_KOD"))).add(Restrictions.eq("id.krdTurAltKod2", iMap.getBigDecimal("KRD_TUR_ALT_KOD2"))).add(Restrictions.eq("id.kanalKod", iMap.getString("KANAL"))).add(Restrictions.eq("dovizKod", iMap.getString("DOVIZ_KODU"))).list();
			GMMap oMap = new GMMap();
			String tableName = "TEMINAT_TANIM";
			int row = 0;
			for (Iterator<?> iterator = teminatTanimPersistenceList.iterator(); iterator.hasNext();) {
				BirTemTanim birTemTanim = (BirTemTanim) iterator.next();
				
				oMap.put(tableName, row, "TEMINAT_KODU", birTemTanim.getId().getTeminatKod());
				oMap.put(tableName, row, "TEMINAT_ADI", LovHelper.diLov(birTemTanim.getId().getTeminatKod(), "3104/LOV_TEMINAT", "ACIKLAMA"));
				oMap.put(tableName, row, "ZORUNLU", birTemTanim.getZorunlu());

				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3104_GET_RECORD")
	public static GMMap getRecord(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			
			List<?> kriterList = (List<?>)session.createCriteria(BirTemTanimTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Iterator<?> iter = kriterList.iterator();
			if(iter.hasNext()){
				BirTemTanimTx temTanimTx = (BirTemTanimTx) iter.next();
				oMap.put("KRD_TUR_KOD", temTanimTx.getId().getKrdTurKod());
				oMap.put("KRD_TUR_KOD_DI", LovHelper.diLov(temTanimTx.getId().getKrdTurKod(), "3104/LOV_KREDI_TUR", "ACIKLAMA"));
				oMap.put("KRD_TUR_ALT_KOD", temTanimTx.getId().getKrdTurAltKod());
				ArrayList<Object> lovInputList = new ArrayList<Object>();
				lovInputList.add(temTanimTx.getId().getKrdTurKod().toString());
				oMap.put("KRD_TUR_ALT_KOD_ID", LovHelper.diLov(temTanimTx.getId().getKrdTurAltKod(), "3104/LOV_KREDI_TIPI", "ACIKLAMA", lovInputList));
				oMap.put("KRD_TUR_ALT_KOD2", temTanimTx.getId().getKrdTurAltKod2());
				lovInputList.clear();
				lovInputList.add(temTanimTx.getId().getKrdTurKod().toString());
				lovInputList.add(temTanimTx.getId().getKrdTurAltKod().toString());
				oMap.put("KRD_TUR_ALT_KOD2_DI", LovHelper.diLov(temTanimTx.getId().getKrdTurAltKod2(), "3104/LOV_ALT_KREDI_TIPI", "ACIKLAMA", lovInputList));
				oMap.put("KANAL", temTanimTx.getId().getKanalKod());
				lovInputList.clear();
				lovInputList.add(temTanimTx.getId().getKrdTurKod().toString());
				lovInputList.add(temTanimTx.getId().getKrdTurAltKod().toString());
				lovInputList.add(temTanimTx.getId().getKrdTurAltKod2().toString());
				oMap.put("KANAL_DI", LovHelper.diLov(temTanimTx.getId().getKanalKod(), "3104/LOV_KANAL", "ACIKLAMA", lovInputList));
				oMap.put("DOVIZ_KODU", temTanimTx.getDovizKod());
				lovInputList.clear();
				lovInputList.add(temTanimTx.getId().getKrdTurKod().toString());
				lovInputList.add(temTanimTx.getId().getKrdTurAltKod().toString());
				lovInputList.add(temTanimTx.getId().getKrdTurAltKod2().toString());
				lovInputList.add(temTanimTx.getId().getKanalKod());
				oMap.put("DOVIZ_ADI", LovHelper.diLov(temTanimTx.getDovizKod(), "3104/LOV_DOVIZ_KODU", "ADI", lovInputList));
			}
			
			
			List<?> teminatTanimPersistenceList = (List<?>) session.createCriteria(BirTemTanimTx.class).add(Restrictions.and(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")),Restrictions.isNull("sil"))).list();
			
			String tableName = "TEMINAT_TANIM";
			int row = 0;
			for (Iterator<?> iterator = teminatTanimPersistenceList.iterator(); iterator.hasNext();) {
				BirTemTanimTx birTemTanimTx = (BirTemTanimTx) iterator.next();
				oMap.put(tableName, row, "TEMINAT_KODU", birTemTanimTx.getId().getTeminatKod());
				oMap.put(tableName, row, "TEMINAT_ADI", LovHelper.diLov(birTemTanimTx.getId().getTeminatKod(), "3104/LOV_TEMINAT", "ACIKLAMA"));
				oMap.put(tableName, row, "ZORUNLU", birTemTanimTx.getZorunlu());

				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static ArrayList<HashMap<String, Object>> readTeminatTanim(List<?> teminatTanimPersistenceList) {
		ArrayList<HashMap<String, Object>> teminatTanimOutList = new ArrayList<HashMap<String, Object>>();
		for (Iterator<?> iterator = teminatTanimPersistenceList.iterator(); iterator.hasNext();) {
			BirTemTanim birTemTanim = (BirTemTanim) iterator.next();
			HashMap<String, Object> rowData = new HashMap<String, Object>();
			rowData.put("TEMINAT_KODU", birTemTanim.getId().getTeminatKod());
			rowData.put("TEMINAT_ADI", LovHelper.diLov(birTemTanim.getId().getTeminatKod(), "3104/LOV_TEMINAT", "ACIKLAMA"));
			rowData.put("ZORUNLU", birTemTanim.getZorunlu());
			teminatTanimOutList.add(rowData);
		}
		return teminatTanimOutList;
	}

	@GraymoundService("BNSPR_TRN3104_SAVE_KREDI_TEMINAT_TANIM")
	public static Map<?, ?> saveKrediTeminatTanim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "TEMINAT_TANIM";
			List<?> list = (List<?>) iMap.get(tableName);
			if (list.size() == 0) {
				Connection conn = null;
				CallableStatement stmt = null;
				try {
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{call PKG_TRN3104.TumKayitSil(?, ?, ?, ?, ?, ?)}");
					stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
					stmt.setBigDecimal(2, iMap.getBigDecimal("KRD_TUR_KOD"));
					stmt.setBigDecimal(3, iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
					stmt.setBigDecimal(4, iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
					stmt.setString(5, iMap.getString("KANAL_KOD"));
					stmt.setString(6, iMap.getString("DOVIZ_KOD"));

					stmt.execute();

				} catch (Exception e) {
					throw ExceptionHandler.convertException(e);
				} finally {
					GMServerDatasource.close(stmt);
					GMServerDatasource.close(conn);
				}
//				iMap.put("HATA_NO", new BigDecimal(442));
//				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			} else {
				for (int i = 0; i < list.size(); i++) {
					if (iMap.getString(tableName, i, "TEMINAT_KODU") == null) {
						iMap.put("HATA_NO", new BigDecimal(813));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}

					BirTemTanimTx birTemTanimTx = (BirTemTanimTx) session.get(BirTemTanimTx.class, new BirTemTanimTxId(iMap.getBigDecimal("KRD_TUR_KOD"), iMap.getBigDecimal("KRD_TUR_ALT_KOD"), iMap.getBigDecimal("KRD_TUR_ALT_KOD2"), iMap.getString("KANAL_KOD"), iMap.getString(tableName, i, "TEMINAT_KODU"), iMap.getBigDecimal("TRX_NO")));
					if (birTemTanimTx == null) {
						birTemTanimTx = new BirTemTanimTx();
					} else {
						{
							iMap.put("HATA_NO", new BigDecimal(716));
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
					}
					BirTemTanimTxId id = new BirTemTanimTxId();
					id.setKrdTurKod(iMap.getBigDecimal("KRD_TUR_KOD"));
					id.setKrdTurAltKod(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
					id.setKrdTurAltKod2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setTeminatKod(iMap.getString(tableName, i, "TEMINAT_KODU"));
					id.setKanalKod(iMap.getString("KANAL_KOD"));
					birTemTanimTx.setId(id);

					birTemTanimTx.setZorunlu(iMap.getString(tableName, i, "ZORUNLU"));
					birTemTanimTx.setDovizKod(iMap.getString("DOVIZ_KOD"));
					session.saveOrUpdate(birTemTanimTx);
				}
			}
			session.flush();
			iMap.put("MESSAGE", "��leminiz Tamamlanm��t�r.");
			iMap.put("TRX_NAME", "3104");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3104_GET_COMBO_MODEL_DATA")
	public static GMMap getComboModelDatas(GMMap iMap) {
		String listName = "ZORUNLU_COMBO";
		GuimlUtil.wrapMyCombo(iMap, listName, "E", "Evet");
		GuimlUtil.wrapMyCombo(iMap, listName, "H", "Hay�r");
		return iMap;
	}
}
