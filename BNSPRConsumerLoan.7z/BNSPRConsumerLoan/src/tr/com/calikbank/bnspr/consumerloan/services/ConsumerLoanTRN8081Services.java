package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.DcsDagilimiptali;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8081Services {

	@GraymoundService("BNSPR_TRN8081_SORGULA")
	public static GMMap musteriDagilimiBul(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call bnspr.pkg_trn8081.f_dagilim_liste(?)}");
			stmt.registerOutParameter(1, -10); // ref cursor
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "DAGILIM_TABLO";

			int i = 0;
			while (rSet.next()) {

				oMap.put(tableName, i, "TAKIP_HESAP_NO", rSet.getString("TAKIP_HESAP_NO"));
				oMap.put(tableName, i, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
				oMap.put(tableName, i, "TAHSILAT_TIPI", rSet.getString("TAHSILAT_TIPI"));
				oMap.put(tableName, i, "TAHSILAT_ID", rSet.getString("TAHSILAT_ID"));
				oMap.put(tableName, i, "TX_ID", rSet.getString("TX_ID"));
				oMap.put(tableName, i, "TUTAR", rSet.getString("TUTAR"));
				oMap.put(tableName, i, "VERGI_TUTAR1", rSet.getString("VERGI_TUTAR1"));
				oMap.put(tableName, i, "VERGI_TUTAR2", rSet.getString("VERGI_TUTAR2"));
				oMap.put(tableName, i, "ISLEM_ACIKLAMA", rSet.getString("ISLEM_ACIKLAMA"));

				i++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
		}
	}

	@GraymoundService("BNSPR_TRN8081_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "DAGILIM_TABLO";

			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");

			List<?> dagilimListe = (List<?>) iMap.get(tableName);
			if (dagilimListe.size() == 0) {
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			for (int i = 0; i < dagilimListe.size(); i++) {

				if (iMap.getBoolean(tableName, i, "IPTAL")) {

					BigDecimal txId = iMap.getBigDecimal(tableName, i, "TX_ID");
					BigDecimal tahsilatId = iMap.getBigDecimal(tableName, i, "TAHSILAT_ID");
					BigDecimal musteriNo = iMap.getBigDecimal(tableName, i, "MUSTERI_NO");

					session.saveOrUpdate(new DcsDagilimiptali(txId, txNo, tahsilatId, musteriNo));
				}
			}
			session.flush();

			iMap.put("TRX_NAME", "8081");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8081_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		try {
			if (iMap.getBoolean("CHECKED")) {
				for (int i = 0; i < iMap.getSize("DAGILIM_TABLO"); i++) {
					iMap.put("DAGILIM_TABLO", i, "IPTAL", 1);
				}
			}
			else {
				for (int i = 0; i < iMap.getSize("DAGILIM_TABLO"); i++) {
					iMap.put("DAGILIM_TABLO", i, "IPTAL", 0);
				}
			}
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}
}
