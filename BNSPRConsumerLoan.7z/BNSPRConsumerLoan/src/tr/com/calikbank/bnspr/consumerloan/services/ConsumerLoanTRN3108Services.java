package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirFaizBazOranPr;
import tr.com.calikbank.bnspr.dao.BirFaizBazOranPrTx;
import tr.com.calikbank.bnspr.dao.BirFaizBazOranPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;


import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3108Services {
	@GraymoundService("BNSPR_TRN3108_GET_FAIZ_BAZ_ORAN_PR")
	public static GMMap getKrdAltTur(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(
					BirFaizBazOranPr.class).add(
					Restrictions.and(Restrictions.eq("krdTurKod", iMap
							.getBigDecimal("KRD_TUR_KOD")), Restrictions.eq(
							"krdTurAltKod", iMap
									.getBigDecimal("KRD_ALT_TUR_KOD")))).addOrder(Order.asc("dovizKod")).addOrder(Order.asc("minVade")).addOrder(Order.asc("minTutar")).list();

			GMMap oMap = new GMMap();
			String tableName = "FAIZ_BAZ_ORAN";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				BirFaizBazOranPr birFaizBazOranPr = (BirFaizBazOranPr) iterator
						.next();

				oMap.put(tableName, row, "KOD", birFaizBazOranPr.getId());
				oMap.put(tableName, row, "DOVIZ_CINSI", birFaizBazOranPr.getDovizKod());
				oMap.put(tableName, row, "MIN_VADE", birFaizBazOranPr.getMinVade());
				oMap.put(tableName, row, "MAX_VADE", birFaizBazOranPr.getMaxVade());
				oMap.put(tableName, row, "MIN_TUTAR", birFaizBazOranPr.getMinTutar());
				oMap.put(tableName, row, "MAX_TUTAR", birFaizBazOranPr.getMaxTutar());
				oMap.put(tableName, row, "FAIZ_ORANI", birFaizBazOranPr.getBazOran());
				oMap.put(tableName, row, "DOSYA_MASRAF_TIP", birFaizBazOranPr.getDosMasrafTip());
				oMap.put(tableName, row, "DOSYA_MASRAFI", birFaizBazOranPr.getDosMasrafOran());
				oMap.put(tableName, row, "MIN_DOSYA_MASRAFI", birFaizBazOranPr.getMinDosMasraf());
				oMap.put(tableName, row, "MAX_DOSYA_MASRAFI", birFaizBazOranPr.getMaxDosMasraf());
				oMap.put(tableName, row, "OZEL_ORAN_1", birFaizBazOranPr.getOzelOran1());
				oMap.put(tableName, row, "OZEL_ORAN_2", birFaizBazOranPr.getOzelOran2());
				oMap.put(tableName, row, "ESKI_BAZ_ORAN", birFaizBazOranPr.getBazOran());
				
			}

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	@GraymoundService("BNSPR_TRN3108_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Boolean flag = true;
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "KRD_BAZ_ORAN";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i=0; i<list.size(); i++) {
				BirFaizBazOranPrTx birFaizBazOranPrTx = new BirFaizBazOranPrTx();
				BirFaizBazOranPrTxId birFaizBazOranPrTxId = new BirFaizBazOranPrTxId();
				
				birFaizBazOranPrTxId.setId(iMap.getBigDecimal(tableName, i, "KOD"));
				birFaizBazOranPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				
				birFaizBazOranPrTx.setId(birFaizBazOranPrTxId);
				birFaizBazOranPrTx.setDovizKod(iMap.getString(tableName, i,"DOVIZ_CINSI"));
				
			    birFaizBazOranPrTx.setMinVade(iMap.getBigDecimal(tableName, i, "MIN_VADE"));
			    birFaizBazOranPrTx.setMaxVade(iMap.getBigDecimal(tableName, i, "MAX_VADE"));
				birFaizBazOranPrTx.setMinTutar(iMap.getBigDecimal(tableName, i, "MIN_TUTAR"));
				birFaizBazOranPrTx.setMaxTutar(iMap.getBigDecimal(tableName, i, "MAX_TUTAR"));
				birFaizBazOranPrTx.setBazOran(iMap.getBigDecimal(tableName, i, "FAIZ_ORANI"));
				birFaizBazOranPrTx.setDosMasrafOran(iMap.getBigDecimal(tableName, i, "DOSYA_MASRAFI"));
				birFaizBazOranPrTx.setMinDosMasraf(iMap.getBigDecimal(tableName, i, "MIN_DOSYA_MASRAFI"));
				birFaizBazOranPrTx.setMaxDosMasraf(iMap.getBigDecimal(tableName, i, "MAX_DOSYA_MASRAFI"));
				birFaizBazOranPrTx.setOzelOran1(iMap.getBigDecimal(tableName, i, "OZEL_ORAN_1"));
				birFaizBazOranPrTx.setOzelOran2(iMap.getBigDecimal(tableName, i, "OZEL_ORAN_2"));
				birFaizBazOranPrTx.setEskiBazOran(iMap.getBigDecimal(tableName, i, "ESKI_BAZ_ORAN"));
				
				birFaizBazOranPrTx.setDosMasrafTip(iMap.getString(tableName, i, "DOSYA_MASRAF_TIP"));
                birFaizBazOranPrTx.setKrdTurKod(iMap.getBigDecimal("KRD_TUR_KOD"));
                birFaizBazOranPrTx.setKrdTurAltKod(iMap.getBigDecimal("KRD_ALT_TUR_KOD"));
				
                session.save(birFaizBazOranPrTx);
                flag = false;
                session.flush();
			}
			
			if (flag)
				kayitSil(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("KRD_TUR_KOD"), iMap.getBigDecimal("KRD_ALT_TUR_KOD"));
			iMap.put("TRX_NAME", "3108");

			/*Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			Map<?, ?> myMap = GMServiceExecuter.execute("BNSPR_KREDI_FAIZ_ORAN_TO_TURKLINE", iMap);

			if(myMap.get("RESULT").equals("HATA")){
				throw new GMRuntimeException(0, "TurkLine Aktar�mda hata al�nd�");
			}
			return oMap;*/
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	public static void kayitSil(BigDecimal trxNo, BigDecimal kod, BigDecimal kod1) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3108.TumKayitSil(?,?,?)}");
			stmt.setBigDecimal(1, trxNo);
			stmt.setBigDecimal(2, kod);
			stmt.setBigDecimal(3, kod1);
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3108_GET_DOSYA_MASRAF_TIP_VALUE")
	public static GMMap getDosyaMasrafTipValue(GMMap iMap) {
		return getDosyaMasrafTip(iMap, "DOSYA_MASRAF_TIP");
	}
	
	public static GMMap getDosyaMasrafTip(GMMap iMap, String listName) {
		GuimlUtil.wrapMyCombo(iMap, listName, "T","Tutar");
		GuimlUtil.wrapMyCombo(iMap, listName, "O","Oran");
		GuimlUtil.wrapMyCombo(iMap, listName, "Y","Yok");
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN3108_GET_KRD_TIP_DEFAULT_MIN_MAX_VALUES")
	public static GMMap getKrdTipDefaultMinMaxValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call Pkg_Bireysel.KrdTipMinMaxDeger_Kanaldan(?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("KRD_TUR_KOD"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("KRD_ALT_TUR_KOD"));
			stmt.setString(3, iMap.getString("DOVIZ_KODU"));
			stmt.registerOutParameter(4, Types.DECIMAL);
			stmt.registerOutParameter(5, Types.DECIMAL);
			stmt.registerOutParameter(6, Types.DECIMAL);
			stmt.registerOutParameter(7, Types.DECIMAL);
			stmt.execute();
			
			oMap.put("MIN_VADE", stmt.getBigDecimal(4));
			oMap.put("MAX_VADE", stmt.getBigDecimal(5));
			oMap.put("MIN_TUTAR", stmt.getBigDecimal(6));
			oMap.put("MAX_TUTAR", stmt.getBigDecimal(7));
			

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN3108_GET_FAIZ_BAZ_ORAN_PR_WITH_TX_NO")
	public static GMMap getKrdAltTurWithTxNo(GMMap iMap) {
		String krdTurKod = null;
		String krdAltTurKod = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(
					BirFaizBazOranPrTx.class).add(
					Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			GMMap oMap = new GMMap();
			String tableName = "FAIZ_BAZ_ORAN";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				BirFaizBazOranPrTx birFaizBazOranPrTx = (BirFaizBazOranPrTx) iterator
						.next();

				oMap.put("KRD_TUR_KOD", birFaizBazOranPrTx.getKrdTurKod());
				oMap.put("KRD_ALT_TUR_KOD", birFaizBazOranPrTx.getKrdTurAltKod());
				oMap.put(tableName, row, "KOD", birFaizBazOranPrTx.getId().getId());
				oMap.put(tableName, row, "DOVIZ_CINSI", birFaizBazOranPrTx.getDovizKod());
				oMap.put(tableName, row, "MIN_VADE", birFaizBazOranPrTx.getMinVade());
				oMap.put(tableName, row, "MAX_VADE", birFaizBazOranPrTx.getMaxVade());
				oMap.put(tableName, row, "MIN_TUTAR", birFaizBazOranPrTx.getMinTutar());
				oMap.put(tableName, row, "MAX_TUTAR", birFaizBazOranPrTx.getMaxTutar());
				oMap.put(tableName, row, "FAIZ_ORANI", birFaizBazOranPrTx.getBazOran());
				oMap.put(tableName, row, "DOSYA_MASRAF_TIP", birFaizBazOranPrTx.getDosMasrafTip());
				oMap.put(tableName, row, "DOSYA_MASRAFI", birFaizBazOranPrTx.getDosMasrafOran());
				oMap.put(tableName, row, "MIN_DOSYA_MASRAFI", birFaizBazOranPrTx.getMinDosMasraf());
				oMap.put(tableName, row, "MAX_DOSYA_MASRAFI", birFaizBazOranPrTx.getMaxDosMasraf());
				oMap.put(tableName, row, "OZEL_ORAN_1", birFaizBazOranPrTx.getOzelOran1());
				oMap.put(tableName, row, "OZEL_ORAN_2", birFaizBazOranPrTx.getOzelOran2());
			}
			oMap.put("KREDI_TURU_ADI", LovHelper.diLov(oMap.getString("KRD_TUR_KOD"), "3108/LOV_KREDI_TURU", "ACIKLAMA"));
			oMap.put("KREDI_ALT_TURU_ADI", LovHelper.diLov(oMap.getString("KRD_ALT_TUR_KOD"),oMap.getString("KRD_TUR_KOD"), "3108/LOV_KREDI_TIPI", "ACIKLAMA"));
			
			iMap.put("KRD_TUR_KOD", krdTurKod);
			iMap.put("KRD_ALT_TUR_KOD", krdAltTurKod);
			oMap.putAll(ConsumerLoanTRN3109Services.getDovizKodlari(iMap));
			
			getDosyaMasrafTip(oMap, "DOSYA_MASRAF_TIP");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3108_AFTER_APROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		try {
			GMServiceExecuter.execute("BNSPR_KREDI_FAIZ_ORAN_TO_TURKLINE", new GMMap());
			GMServiceExecuter.execute("BNSPR_DELETE_TURKLINE_KREDI_DATA", new GMMap());
			GMServiceExecuter.execute("BNSPR_SET_TURKLINE_KREDITUR_DATA", new GMMap());
			GMServiceExecuter.execute("BNSPR_SET_TURKLINE_KREDI_DATA", new GMMap());
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
