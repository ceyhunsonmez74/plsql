package tr.com.calikbank.bnspr.consumerloan.services;

import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirKrediKontrolBakiyeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3232Services {

	@GraymoundService("BNSPR_TRN3232_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal"); 	
			
			BirKrediKontrolBakiyeTx tx = new BirKrediKontrolBakiyeTx();
			
			tx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			tx.setIslemNo(iMap.getBigDecimal("ISLEM_NO"));
			tx.setIslemKodu(iMap.getString("ISLEM_KODU"));
			tx.setIslemTarihi(iMap.getDate("ISLEM_TARIHI"));
			tx.setIslemTutari(iMap.getBigDecimal("ISLEM_TUTARI"));
			tx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			tx.setHesapBakiye(iMap.getBigDecimal("HESAP_BAKIYE"));
			tx.setToplamKapamaTutari(iMap.getBigDecimal("TOPLAM_KAPAMA_TUTARI"));
			tx.setToplamTaksitTutari(iMap.getBigDecimal("TOPLAM_TAKSIT_TUTARI"));
			tx.setKayitTarihi(iMap.getDate("KAYIT_TARIHI"));
			tx.setDurumKodu(iMap.getString("DURUM_KODU"));
			
			session.save(tx);
			session.flush();
			
			iMap.put("TRX_NAME", "3232");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
