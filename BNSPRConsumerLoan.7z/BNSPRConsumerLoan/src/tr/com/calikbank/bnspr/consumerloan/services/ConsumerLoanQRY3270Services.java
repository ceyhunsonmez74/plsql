package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3270Services {
	
	private static final Logger LOGGER = Logger.getLogger(ConsumerLoanQRY3270Services.class);

	@GraymoundService("BNSPR_QRY3270_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("TABLE_NAME", "KIM_ICIN_LIST");
			sorguMap.put("KOD", "BASVURU_KISI_KOD");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", sorguMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	

	@GraymoundService("BNSPR_QRY3270_LIST_DOKUMAN")
	public static GMMap listDokumanKod(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			StringBuilder query = new StringBuilder();
			query.append(" SELECT kod,aciklama");
			query.append(" FROM bnspr.bir_basvuru_belge b, bnspr.v_ml_gnl_belge_kod_pr p");
			query.append(" WHERE b.dokuman_kod = p.kod");
			query.append(" AND b.basvuru_no = ");
			query.append(iMap.getString(Constants.BASVURU_NO));
			query.append(" ORDER BY 1");
			  
			DALUtil.fillComboBox(oMap, "DOKUMAN_KOD_LIST", false, query.toString());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3270_DOSYA_VAR_MI")
	public static GMMap isFileExits(GMMap iMap) {
		GMMap oMap = new GMMap();
		String dosyaVarMi = Constants.HAYIR;

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put(Constants.BASVURU_NO, iMap.get(Constants.BASVURU_NO));
			sorguMap.put(Constants.DOKUMAN_KOD, iMap.get(Constants.DOKUMAN_KOD));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_GET_DOKUMAN_PATH", sorguMap));
			String filePath = sorguMap.getString("FILE_PATH");
			//filePath = "C:\\mnt2\\1.pdf";
			
			File file = new File(filePath);
			if (file != null && file.exists()) {
				dosyaVarMi = Constants.EVET;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("DOSYA_VAR_MI", dosyaVarMi);
		return oMap;
	}
	
	/** Bayi dokumanlari ekranda gecici dizine kaydedildikten sonra alindi olarak isaretlenir.<br>
	 * @author murat.el
	 * @since PY-10975, PY-11141
	 * @param iMap - Basvuru bilgisi<br>
	 *        <li>BASVURU_NO - Kredi basvuru numarasi
	 *        <li>KIM_ICIN - Kim icin dokuman yukleniyor? (M:Musteri, K1-K2:Kefil, E:Es)
	 *        <li>DOKUMAN_KOD - Dokuman kodu
	 *        <li>DOSYA_ICERIK - ByetArray formatinda dosya icerigi
	 * @return oMap - Sonuc bilgisi<br>
	 */
	@GraymoundService("BNSPR_QRY3270_BELGE_YUKLE")
	public static GMMap belgeYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		//
		BigDecimal basvuruNo = iMap.getBigDecimal(Constants.BASVURU_NO);
		String dokumanKod = iMap.getString(Constants.DOKUMAN_KOD);
		String kimIcin = ConsumerLoanCommonServices.nvl(iMap.getString("KIM_ICIN"), "M");
		
		try {
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			
			//Belge yuklenebilir mi?
			GMMap sorguMap = new GMMap();
			sorguMap.put(Constants.BASVURU_NO, basvuruNo);
			sorguMap.put(Constants.DOKUMAN_KOD, dokumanKod);
			sorguMap.put("DOSYA_ICERIK", iMap.get("DOSYA_ICERIK"));
			sorguMap.put("KANAL", "3270");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_GECICI_BELGE_YUKLE", sorguMap));//ARSIV_FILE_PATH
			String versiyonPath = sorguMap.getString("ARSIV_FILE_PATH");
			
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			//Belgenin onceki statusunu al, yeni statusunu ona gore guncelle
			BirBasvuruBelgeId belgeId = new BirBasvuruBelgeId();
			belgeId.setBasvuruNo(basvuruNo);
			belgeId.setDokumanKod(dokumanKod);
			belgeId.setKimden(kimIcin);
			
			BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) session.get(BirBasvuruBelge.class, belgeId);
			String belgeYeniDurum = "6";//Belge Yuklendi
			//Belge durumu eksikse yeni belge yuklendigi zaman statuyu farklilastir
			if (birBasvuruBelge != null && "2".equals(birBasvuruBelge.getBelgeKontrol())) {
				belgeYeniDurum = "7";//Eksik Belge Yuklendi
			}
			//Basvuru uzerinde belgeyi alindi olarak guncelle.
			//Tx
			
			/** PY-11214 PY-3270 akustik belg y�kleme */
			if (birBasvuruBelge != null && "1".equals(birBasvuruBelge.getBelgeKontrol())) {
				ConsumerLoanCommonServices.raiseGMError("5382", null);
			}
			
			BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setBasvuruNo(basvuruNo);
			id.setDokumanKod(dokumanKod);
			id.setKimden(kimIcin);
			
			BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, id);
			if (birBasvuruBelgeTx == null) {
				birBasvuruBelgeTx = new BirBasvuruBelgeTx();
				birBasvuruBelgeTx.setId(id);
			}
			birBasvuruBelgeTx.setAlindi(Constants.EVET);
			birBasvuruBelgeTx.setBelgeKontrol(belgeYeniDurum);
			birBasvuruBelgeTx.setVersiyonPath(versiyonPath);
			
			session.save(birBasvuruBelgeTx);
			//Belge
			birBasvuruBelge.setAlindi(Constants.EVET);
			birBasvuruBelge.setBelgeKontrol(belgeYeniDurum);
			session.save(birBasvuruBelge);
			
			session.flush();
			
			// create IWD task for documents
			try {
				GMMap iwdMap = new GMMap();
				iwdMap.put(Constants.BASVURU_NO, basvuruNo);
				iwdMap.put(Constants.DOKUMAN_KOD, dokumanKod);
				iwdMap.put(Constants.KIMDEN, kimIcin);
				iwdMap.put(Constants.BELGE_KONTROL, belgeYeniDurum);
				GMServiceExecuter.executeAsync("BNSPR_CL_IWD_CREATE_TASK", iwdMap);
			}
			catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * Manual olarak dizine birakilan dosyalari arsiv klasorune kopyalar, 
	 * BIR_BASVURU_BELGE kayd�n� g�nceller,
	 * BIR_BASVURU_BELGE_TX e kay�t olusturur. 
	 */
	@GraymoundService("BNSPR_CHECK_MANUAL_DOCUMENT_UPLOAD")
	public static GMMap checkManualDocumentUpload(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "TABLE";
		String rootPath = StringUtils.EMPTY;
		BigDecimal txNo = BigDecimal.ZERO;
		
		try {
			iMap.put("PARAMETRE", "KRE_DOKUMAN_PATH");
			rootPath = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).getString("DEGER");
			txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3182.getEksikBelgeKontrolList(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);			
			iMap = DALUtil.rSetResults(rSet, tableName);
			
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				BigDecimal basvuruNo = iMap.getBigDecimal(tableName, i, "BASVURU_NO");
				String dokumanKod = iMap.getString(tableName, i, "DOKUMAN_KOD");
				BigDecimal txRecDate = iMap.getBigDecimal(tableName, i, "REC_DATE");
				String belgeKontrol = iMap.getString(tableName, i, "BELGE_KONTROL");
				
				File basvuruDir = new File(rootPath + File.separator + basvuruNo);
				File archiveDir = new File(basvuruDir + File.separator + "ARSIV");
				
				if(!basvuruDir.exists() || !basvuruDir.isDirectory()){
					LOGGER.info(basvuruDir.getPath() + " dizini bulunamad�!");
				}else {
					boolean fileIsExist = false;
					for(File f : basvuruDir.listFiles()){
						String filePattern = dokumanKod + ".pdf";
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
						BigDecimal lastModifiedDate = new BigDecimal(dateFormat.format(f.lastModified()));
						
						if(f.getName().matches(filePattern) && lastModifiedDate.compareTo(txRecDate) == 1){
							fileIsExist = true;
							
							/*create archive directory and file*/
							if(!archiveDir.exists()){
								archiveDir.mkdir();
							}
							
							File arcFile = new File(archiveDir.getPath() + File.separator + dokumanKod + "_" + System.currentTimeMillis() + ".pdf");
							FileUtils.copyFile(f, arcFile);
							
							/*update related table*/
							Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
							
							if(Constants.BELGE_KONTROL_EKSIK.equals(belgeKontrol) || Constants.BELGE_KONTROL_HATALI.equals(belgeKontrol)){
								belgeKontrol = Constants.BELGE_KONTROL_EKSIK_BELGE_YUKLENDI;
							}else {
								belgeKontrol = Constants.BELGE_KONTROL_YUKLENDI;
							}
							
							BirBasvuruBelgeId belgeId = new BirBasvuruBelgeId();
							belgeId.setBasvuruNo(basvuruNo);
							belgeId.setDokumanKod(dokumanKod);
							belgeId.setKimden("M");
							
							BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) session.get(BirBasvuruBelge.class, belgeId);
							birBasvuruBelge.setAlindi(Constants.EVET);
							birBasvuruBelge.setBelgeKontrol(belgeKontrol);
							session.update(birBasvuruBelge);
							
							BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();
							id.setTxNo(txNo);
							id.setBasvuruNo(basvuruNo);
							id.setDokumanKod(dokumanKod);
							id.setKimden("M");
							
							BirBasvuruBelgeTx birBasvuruBelgeTx = new BirBasvuruBelgeTx();
							birBasvuruBelgeTx.setId(id);
							birBasvuruBelgeTx.setAlindi(Constants.EVET);
							birBasvuruBelgeTx.setBelgeKontrol(belgeKontrol);
							birBasvuruBelgeTx.setVersiyonPath(archiveDir.getPath() + File.separator + arcFile.getName());
							session.save(birBasvuruBelgeTx);
							session.flush();
							
							try {
								oMap.put(Constants.BASVURU_NO, basvuruNo);
								oMap.put(Constants.DOKUMAN_KOD, dokumanKod);
								oMap.put(Constants.KIMDEN, "M");
								oMap.put(Constants.BELGE_KONTROL, belgeKontrol);
								oMap.put("TRX_NO", txNo);
								GMServiceExecuter.executeAsync("BNSPR_CL_IWD_CREATE_TASK", oMap);
							}
							catch (Exception e) {
								LOGGER.error(e.getMessage() + "BasvuruNo : " + basvuruNo + "belgeNo: " + dokumanKod);
							}
						}
					}
					if(!fileIsExist){
						LOGGER.info(basvuruDir.getPath() + " dizini alt�nda " + dokumanKod + " adl� dosya bulunamad�!");
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

}
