package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTasit;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTasitTx;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.MuhHesapRezerv;
import tr.com.aktifbank.bnspr.dao.MuhHesapRezervId;
import tr.com.calikbank.bnspr.consumerloan.utils.CreditTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorusTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorusTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirBasvuruSozlesmeTx;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.ReportUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3181Services {

	@GraymoundService("BNSPR_TRN3181_BASVURU_GUNCELLE_LIST")
	public static GMMap getBasvuruGuncelleList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			if (iMap.getDate("BASLANGIC_TAR") != null && iMap.getDate("BITIS_TAR") != null) {
				if (iMap.getDate("BASLANGIC_TAR").after(iMap.getDate("BITIS_TAR"))) {
					iMap.put("HATA_NO", new BigDecimal(915));
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}
			BigDecimal kampKod = null;
			BigDecimal krdAltTurKod = null;
			if (iMap.getString("KAMP_URUN_ADI") != null && iMap.getString("KAMP_URUN_ADI").isEmpty())
				iMap.put("KAMP_URUN_ADI", (String) null);
			if (iMap.getString("KAMP_URUN_ADI") != null) {
				if (iMap.getString("KAMP_URUN_ADI").indexOf('-') < 0)
					kampKod = iMap.getBigDecimal("KAMP_URUN_ADI");
				else
					krdAltTurKod = new BigDecimal(iMap.getString("KAMP_URUN_ADI").substring(iMap.getString("KAMP_URUN_ADI").indexOf('-') + 1));
			}

			int i = 1;

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_3181.getBasvuruGuncelleList(?,?,?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(i++, kampKod);
			stmt.setBigDecimal(i++, krdAltTurKod);

			if (iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else
				stmt.setDate(i++, null);

			stmt.setString(i++, iMap.getString("ALINACAK_AKSIYON"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "BASVURU_BILGILERI";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO").toString());
				oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getString("TC_KIMLIK_NO"));
				oMap.put(tableName, row, "AD_SOYAD", rSet.getString("ADI_SOYADI"));
				oMap.put(tableName, row, "BASVURU_TAR", rSet.getString("BASVURU_TARIHI"));
				oMap.put(tableName, row, "KREDI_TURU", rSet.getString("KREDI_TURU"));
				oMap.put(tableName, row, "KAMP_URUN_ADI", rSet.getString("KAMP_URUN_ADI"));
				oMap.put(tableName, row, "KREDI_TUTARI", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, row, "ALINACAK_AKSIYON", rSet.getString("ALINACAK_AKSIYON"));
				oMap.put(tableName, row, "KART_BASVURUSU", rSet.getString("KART_BASVURUSU"));
				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_DIST_AKTARIM_BILGI")
	public static GMMap getDistAktarimBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3181.dist_aktarim_bilgi(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			String mesaj = stmt.getString(1);

			if (mesaj != null)
				oMap.put("DIST_AKTARIM", mesaj);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO")
	public static GMMap trn3181GetInfoByBasvuruNo(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			BigDecimal saticiKod = birBasvuru.getSaticiKod();
			String kanalKod = birBasvuru.getKanalKodu();
			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));
			oMap.put("BAYI_KOM", birBasvuru.getBayiKom());
			oMap.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
			String adSoyad = birBasvuruKimlik.getAd();
			if (birBasvuruKimlik.getIkinciAd() != null && !birBasvuruKimlik.getIkinciAd().isEmpty())
				adSoyad = adSoyad.concat(' ' + birBasvuruKimlik.getIkinciAd());
			adSoyad = adSoyad.concat(' ' + birBasvuruKimlik.getSoyad());
			oMap.put("ADI_SOYADI", adSoyad);
			oMap.put("KREDI_TUR", birBasvuru.getKrediTur());
			oMap.put("DI_KREDI_TUR", LovHelper.diLov(birBasvuru.getKrediTur(), "3181/LOV_KREDI_TUR", "ACIKLAMA"));
			oMap.put("DOVIZ_KOD", birBasvuru.getDovizKodu());
			oMap.put("TALEP_EDILEN_KRD_TUTAR", birBasvuru.getTutar());
			oMap.put("ONAYLANAN_KRD_TUTAR", GMServiceExecuter.execute("BNSPR_TRN3181_HERSEY_DAHIL_TUTAR", iMap).get("HERSEY_DAHIL_TUTAR"));
			oMap.put("ODEME_TIPI", birBasvuru.getOdemeTipKod());
			oMap.put("DI_ODEME_TIPI", LovHelper.diLov(birBasvuru.getOdemeTipKod(), "3181/LOV_ODEME_TIP", "ACIKLAMA"));
			oMap.put("FAIZ_ORANI", birBasvuru.getSozlesmeFaizi());
			oMap.put("BAZ_FAIZ", birBasvuru.getFaizOrani());
			oMap.put("KREDI_VADE", birBasvuru.getVade());
			oMap.put("DOSYA_MASRAFI", birBasvuru.getDosyaMasrafi());
			oMap.put("KATILIM_BEDELI", birBasvuru.getSerbestKatkiPayi());
			oMap.put("GECIKME_GUN_SAYISI", birBasvuru.getGecikmeGunSayisi());
			oMap.put("TAKSIT_GUNU", birBasvuru.getTaksitGunu());
			oMap.put("AY_SONU", "E".equals(birBasvuru.getTaksitGunuAysonuMu()));
			oMap.put("ILK_TAKSIT_TARIHI", birBasvuru.getIlkTaksitTarihi());
			oMap.put("FAIZ_ODEME_SEKLI", birBasvuru.getIlkTaksitYontem());
			oMap.put("FARK_FAIZI", birBasvuru.getFarkFaizi());
			oMap.put("KKDF_ORANI", birBasvuru.getKkdfOrani().divide(new BigDecimal(100)));
			oMap.put("BSMV_ORANI", birBasvuru.getBsmvOrani().divide(new BigDecimal(100)));
			oMap.put("SOZLESME_BASILDI", GMServiceExecuter.execute("BNSPR_TRN3181_SOZLESME_BASILDI_MI", iMap).get("SOZLESME_BASILDI_EH"));
			oMap.put("SATICI_KOD", birBasvuru.getSaticiKod());
			oMap.put("KREDI_ODEME_TIPI", birBasvuru.getKrediOdemeTipi());

			if (!(iMap.getString("ACTION", "").equals("MESAJ_KUTUSU_CAGIRDI")) && !(iMap.getString("ACTION", "").equals("CALL"))) {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_TRN3181.FarkFaiziOdemeSekli2(?)}");
				stmt.registerOutParameter(1, -10);
				stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(1);
				String listName = "FAIZ_ODEME_SEKLI_LIST";
				while (rSet.next()) {
					GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString("KEY1"), rSet.getString("TEXT"));
				}
				conn.close();
				stmt.close();
			}
			else {
				iMap.put("KOD", "BIR_FARK_FAIZ_SEKLI_KOD");
				oMap.put("FAIZ_ODEME_SEKLI_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			}

			if ("7".equals(birBasvuru.getKanalKodu())) {
				oMap.putAll(GMServiceExecuter.call("GET_PTT_INFO", iMap));
			}

			if (birBasvuru.getSigortaPrimi() != null) {
				oMap.put("SIGORTA_PRIMI", birBasvuru.getSigortaPrimi());
			}

			GMMap iMap2 = new GMMap();
			if (birBasvuru.getPttSigortaFirmaKodu() != null) {
				iMap2.put("KOD", "SIGORTASIRKET");
				iMap2.put("KEY", birBasvuru.getPttSigortaFirmaKodu());
				oMap.put("SIGORTA_SIRKETI", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap2).getString("TEXT"));
			}

			oMap.put("FAIZ_ODEME_SEKLI", birBasvuru.getIlkTaksitYontem());
			oMap.put("SIGORTA_PRIMI_CALL", birBasvuru.getSigortaPrimi());
			oMap.put("FARK_FAIZI_CALL", birBasvuru.getFarkFaizi());
			oMap.put("FAIZ_ODEME_SEKLI_CALL", birBasvuru.getIlkTaksitYontem());

			oMap.put("SOZLESME_TARIHI", birBasvuru.getSozlesmeTarihi());

			if (birBasvuru.getSozlesmeTarihi() == null) {
				oMap.put("SOZLESME_TARIHI", Calendar.getInstance().getTime());
			}

			oMap.put("ODEME_TUTARI", birBasvuru.getOdemeTipTut());
			oMap.put("ODEME_ORANI", birBasvuru.getOdemeTipOran());
			oMap.put("ODEME_VADESI", birBasvuru.getOdemeTipVade());
			oMap.put("ODEME_PERIYODU", birBasvuru.getOdemeTipPeriyod());
			oMap.put("SUBE", birBasvuru.getSubeKod());
			oMap.put("HESAP_NO", birBasvuru.getHesapNo());
			oMap.put("SON_TX_NO", birBasvuru.getSonTxNo());

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3187.son_tx_no(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("SON_TX_NO_2", stmt.getString(1));
			conn.close();
			stmt.close();

			oMap.put("CALISMA_SEKLI_KOD", birBasvuru.getCalismaSekliKod());
			oMap.put("WEEKEND_CARE", birBasvuru.getWeekendCare());
			oMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());

			oMap.put("KANAL_KOD_PTT", birBasvuru.getKanalKodu());

			oMap.put("KANAL_KOD_BASVURU", birBasvuru.getKanalKodu());
			oMap.put("FAIZSIZ_FINANSMAN", birBasvuru.getFaizsizFinansman());

			ArrayList<Object> list = new ArrayList<Object>();
			list.add(birBasvuru.getKampKod());
			list.add(birBasvuru.getKrediTur());
			list.add(birBasvuru.getKrediAltTur());
			list.add(birBasvuru.getKrediAltTur2());
			list.add(birBasvuru.getKanalKodu());
			list.add(birBasvuru.getDovizKodu());
			list.add(birBasvuru.getKampKod());
			oMap.put("KAMP_URUN_AD", LovHelper.diLov("1", "3181/LOV_KAMP_URUN_AD", "KANALDAKI_AD", list));

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3173.rc_qry3173_bayi_gorsun_eh(?)}");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			GMMap bMap = new GMMap();
			while (rSet.next()) {
				bMap.put(rSet.getString("DOKUMAN_KOD"), rSet.getString("BAYI_GORSUN_EH"));
			}

			List<?> belge = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();
			String asilBelgeGerekliEh = "";

			String tableName = "TBL_BELGE";
			int row_x = 0;
			for (int row = 0; row < belge.size(); row++) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge.get(row);
				String dokumanKod = birBasvuruBelge.getId().getDokumanKod();

				String bayiGorsunMu = "" + bMap.get(dokumanKod);

				if ("E".equals(bayiGorsunMu)) {
					oMap.put(tableName, row_x, "BELGE_KODU", dokumanKod);
					oMap.put(tableName, row_x, "BELGE_KIMDEN", LovHelper.diLov(birBasvuruBelge.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
					oMap.put(tableName, row_x, "KIMDEN", birBasvuruBelge.getId().getKimden());
					oMap.put(tableName, row_x, "BELGE_ADI", LovHelper.diLov(dokumanKod, "3181/LOV_BELGE", "ACIKLAMA"));
					oMap.put(tableName, row_x, "ALINDI", GuimlUtil.convertToCheckBoxSelected(birBasvuruBelge.getAlindi()));
					asilBelgeGerekliEh = LovHelper.diLov(dokumanKod, "3182/LOV_BELGE_EKLE_KOD", "ASIL_BELGE_GEREKLI_EH");
					if (birBasvuruBelge.getBelgeKontrol() != null) {
						if (birBasvuruBelge.getBelgeKontrol().equalsIgnoreCase("6") || birBasvuruBelge.getBelgeKontrol().equalsIgnoreCase("7")) {
							oMap.put(tableName, row_x, "YUKLENDI", true);
						}
						else {
							oMap.put(tableName, row_x, "YUKLENDI", false);
						}
					}
					else {
						oMap.put(tableName, row_x, "YUKLENDI", false);
					}
					oMap.put(tableName, row_x, "ELEKTRONIK_BELGE_ALINABILIR", "H".equals(asilBelgeGerekliEh) ? "E" : "H");
					oMap.put(tableName, row_x, "BELGE_ALIM_SEKLI", birBasvuruBelge.getBelgeAlimSekli());
					row_x++;
				}
			}

			List<?> belge_to = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("belgeAlinmaAdim", "TO")).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();
			tableName = "TBL_BELGE_TO";
			row_x = 0;
			for (int row = 0; row < belge_to.size(); row++) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge_to.get(row);
				String dokumanKod = birBasvuruBelge.getId().getDokumanKod();

				String bayiGorsunMu = "" + bMap.get(dokumanKod);

				if ("E".equals(bayiGorsunMu)) {
					oMap.put(tableName, row_x, "BELGE_KODU", dokumanKod);
					oMap.put(tableName, row_x, "BELGE_KIMDEN", LovHelper.diLov(birBasvuruBelge.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
					oMap.put(tableName, row_x, "KIMDEN", birBasvuruBelge.getId().getKimden());
					oMap.put(tableName, row_x, "BELGE_ADI", LovHelper.diLov(dokumanKod, "3181/LOV_BELGE", "ACIKLAMA"));
					oMap.put(tableName, row_x, "ALINDI", GuimlUtil.convertToCheckBoxSelected(birBasvuruBelge.getAlindi()));
					asilBelgeGerekliEh = LovHelper.diLov(dokumanKod, "3182/LOV_BELGE_EKLE_KOD", "ASIL_BELGE_GEREKLI_EH");
					oMap.put(tableName, row_x, "ELEKTRONIK_BELGE_ALINABILIR", "H".equals(asilBelgeGerekliEh) ? "E" : "H");
					oMap.put(tableName, row_x, "BELGE_ALIM_SEKLI", birBasvuruBelge.getBelgeAlimSekli());
					row_x++;
				}
			}

			List<?> belge_ts = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("belgeAlinmaAdim", "TS")).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();

			tableName = "TBL_BELGE_TS";
			row_x = 0;
			for (int row = 0; row < belge_ts.size(); row++) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge_ts.get(row);
				String dokumanKod = birBasvuruBelge.getId().getDokumanKod();

				String bayiGorsunMu = "" + bMap.get(dokumanKod);

				if ("E".equals(bayiGorsunMu)) {
					oMap.put(tableName, row_x, "BELGE_KODU", dokumanKod);
					oMap.put(tableName, row_x, "BELGE_KIMDEN", LovHelper.diLov(birBasvuruBelge.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
					oMap.put(tableName, row_x, "KIMDEN", birBasvuruBelge.getId().getKimden());
					oMap.put(tableName, row_x, "BELGE_ADI", LovHelper.diLov(dokumanKod, "3181/LOV_BELGE", "ACIKLAMA"));
					oMap.put(tableName, row_x, "ALINDI", GuimlUtil.convertToCheckBoxSelected(birBasvuruBelge.getAlindi()));
					asilBelgeGerekliEh = LovHelper.diLov(dokumanKod, "3182/LOV_BELGE_EKLE_KOD", "ASIL_BELGE_GEREKLI_EH");
					oMap.put(tableName, row_x, "ELEKTRONIK_BELGE_ALINABILIR", "H".equals(asilBelgeGerekliEh) ? "E" : "H");
					oMap.put(tableName, row_x, "BELGE_ALIM_SEKLI", birBasvuruBelge.getBelgeAlimSekli());
					row_x++;
				}
			}

			List<?> belge_ks = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("belgeAlinmaAdim", "KS")).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();

			tableName = "TBL_BELGE_KS";
			row_x = 0;
			for (int row = 0; row < belge_ks.size(); row++) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge_ks.get(row);
				String dokumanKod = birBasvuruBelge.getId().getDokumanKod();

				String bayiGorsunMu = "" + bMap.get(dokumanKod);

				if ("E".equals(bayiGorsunMu)) {
					oMap.put(tableName, row_x, "BELGE_KODU", dokumanKod);
					oMap.put(tableName, row_x, "BELGE_KIMDEN", LovHelper.diLov(birBasvuruBelge.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
					oMap.put(tableName, row_x, "KIMDEN", birBasvuruBelge.getId().getKimden());
					oMap.put(tableName, row_x, "BELGE_ADI", LovHelper.diLov(dokumanKod, "3181/LOV_BELGE", "ACIKLAMA"));
					oMap.put(tableName, row_x, "ALINDI", GuimlUtil.convertToCheckBoxSelected(birBasvuruBelge.getAlindi()));
					asilBelgeGerekliEh = LovHelper.diLov(dokumanKod, "3182/LOV_BELGE_EKLE_KOD", "ASIL_BELGE_GEREKLI_EH");
					oMap.put(tableName, row_x, "ELEKTRONIK_BELGE_ALINABILIR", "H".equals(asilBelgeGerekliEh) ? "E" : "H");
					oMap.put(tableName, row_x, "BELGE_ALIM_SEKLI", birBasvuruBelge.getBelgeAlimSekli());
					row_x++;
				}
			}

			oMap.put("TEMINAT_LIST", GMServiceExecuter.execute("BNSPR_TRN3181_GET_TEMINAT_LIST_BY_BASVURU_NO", iMap).get("RESULTS"));
			oMap.put("SIGORTA_LIST", GMServiceExecuter.execute("BNSPR_TRN3181_GET_SIGORTA_LIST_BY_BASVURU_NO", iMap).get("RESULTS"));
			conn.close();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3195.Garantorlu_mu(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("GARANTORLU_MU", stmt.getString(1));
			stmt.close();
			conn.close();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.KefilVarMi(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.DECIMAL);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("KEFIL_SAYISI", stmt.getBigDecimal(1));
			conn.close();

			if (StringUtils.isNotBlank(iMap.getString("KANAL_KODU")) && iMap.getString("KANAL_KODU").equals("2")) {
				BirSaticiTahsis birSaticiTahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", oMap.getBigDecimal("SATICI_KOD"))).uniqueResult();
				oMap.put("GARANTOR_GORUNSUN_EH", birSaticiTahsis.getGarantorGorunsunEh());
			}

			if ("2".equals(kanalKod) && saticiKod != null && oMap.getSize("TBL_BELGE") > 0) {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_RC_3181.sozlesme_belge_mesaj(?,?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, saticiKod);
				stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
				stmt.execute();
				String mesaj = stmt.getString(1);
				oMap.put("MESAJ", mesaj);
				stmt.close();
				conn.close();
			}

			if (birBasvuru.getKrediTur().compareTo(CreditTypes.TASIT.getCreditCode()) == 0) {
				BirBasvuruTasit arac = (BirBasvuruTasit) session.createCriteria(BirBasvuruTasit.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				String aracTip = (String) DALUtil.callOneParameterFunction("{? = call pkg_basvuru.getTasitBasvuruTip(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));

				oMap.put("ARAC_KOD", arac.getAracKod());
				oMap.put("ARAC_MARKA", arac.getMarka());
				oMap.put("ARAC_MODEL_YIL", arac.getModelYil());
				oMap.put("ARAC_MODEL", arac.getModel());
				oMap.put("ARAC_KULLANIM_AMAC", arac.getKullanimAmac());
				oMap.put("ARAC_KASKO_DEGER", arac.getKaskoDeger());
				oMap.put("ARAC_NOTER_DEGER", arac.getNoterDeger());
				oMap.put("ARAC_PLAKA", arac.getPlaka());
				oMap.put("ARAC_RUHSAT_TARIH", arac.getRuhsatTarih());
				oMap.put("ARAC_SICIL_NO", arac.getSicilNo());
				oMap.put("ARAC_MOTOR_NO", arac.getMotorNo());
				oMap.put("ARAC_SASI_NO", arac.getSasiNo());
				oMap.put("ARAC_TIP", aracTip);
				oMap.put("ARAC_TRAFIK_SUBE", arac.getTrafikSubesi());
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_SAVE")
	public static Map<?, ?> saveTRN3181(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuruSozlesmeTx birBasvuruSozlesmeTx = (BirBasvuruSozlesmeTx) session.get(BirBasvuruSozlesmeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birBasvuruSozlesmeTx == null)
				birBasvuruSozlesmeTx = new BirBasvuruSozlesmeTx();

			birBasvuruSozlesmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruSozlesmeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruSozlesmeTx.setSigortaPrimi(iMap.getBigDecimal("SIGORTA_PRIMI"));
			birBasvuruSozlesmeTx.setSozlesmeTarihi(new Date());
			birBasvuruSozlesmeTx.setGecikmeGunSayisi(iMap.getBigDecimal("GECIKME_GUN_SAYISI"));
			birBasvuruSozlesmeTx.setTaksitGunu(iMap.getBigDecimal("TAKSIT_GUNU"));
			birBasvuruSozlesmeTx.setTaksitGunuAysonuMu(iMap.getBoolean("AY_SONU") ? "E" : "H");
			birBasvuruSozlesmeTx.setIlkTaksitTarihi(iMap.getDate("ILK_TAKSIT_TARIHI"));
			birBasvuruSozlesmeTx.setFaizOdemeSekli(iMap.getString("FAIZ_ODEME_SEKLI"));
			birBasvuruSozlesmeTx.setFarkFaizi(iMap.getBigDecimal("FARK_FAIZ"));
			birBasvuruSozlesmeTx.setBankaKod(iMap.getString("BANKA"));
			birBasvuruSozlesmeTx.setIlKod(iMap.getString("IL"));
			birBasvuruSozlesmeTx.setSubeKod(iMap.getString("SUBE"));
			birBasvuruSozlesmeTx.setHesapNo(iMap.getString("HESAP_NO"));
			birBasvuruSozlesmeTx.setIban(iMap.getString("IBAN_NO"));
			birBasvuruSozlesmeTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			birBasvuruSozlesmeTx.setDurumKodu("SOZLESME");
			birBasvuruSozlesmeTx.setIslemSonrasiDurumKodu("SOZLESME");
			birBasvuruSozlesmeTx.setWeekendCare(iMap.getBigDecimal("WEEKEND_CARE"));
			birBasvuruSozlesmeTx.setKrediOdemeTipi(iMap.getBigDecimal("KREDI_ODEME_TIPI"));

			iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_GARANTORLU_MU", iMap));

			if ((iMap.getString("GARANTOR_ONAYLANDI_MI") == null && "1".equals(iMap.getString("GARANTORLU_MU"))) || "E".equals(iMap.getString("GARANTOR_ONAYLANDI_MI"))) {
				BirBasvuruGorusTx birBasvuruGorusTx = (BirBasvuruGorusTx) session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.gorusKod", "10")).uniqueResult();
				if (birBasvuruGorusTx == null) {
					birBasvuruGorusTx = new BirBasvuruGorusTx();
				}
				BirBasvuruGorusTxId Id = new BirBasvuruGorusTxId();
				Id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				Id.setGorusKod("10");
				Id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birBasvuruGorusTx.setEH("E");
				birBasvuruGorusTx.setId(Id);
				session.saveOrUpdate(birBasvuruGorusTx);
				session.flush();
			}
			else if (iMap.getString("GARANTOR_ONAYLANDI_MI") != null && "H".equals(iMap.getString("GARANTOR_ONAYLANDI_MI"))) {
				birBasvuruSozlesmeTx.setIslemSonrasiDurumKodu("RED");
				birBasvuruSozlesmeTx.setAksiyonKod("R");
				birBasvuruSozlesmeTx.setAksiyonKararKod("19");
				oMap.put("BASVURU_RED", true);
			}

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			BigDecimal musteriNo = (birBasvuru.getMusteriNo() == null ? null : birBasvuru.getMusteriNo());
			String tc_kimlik_no = (birBasvuru.getTcKimlikNo() == null ? null : birBasvuru.getTcKimlikNo());
			MuhHesapRezerv muhHesapRezerv = null;// (MuhHesapRezerv) session.createCriteria(MuhHesapRezerv.class).add(Restrictions.eq("id.musteriNo",
													// musteriNo)).add(Restrictions.eq("basvuruNo",
													// iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("durumKodu", "A")).uniqueResult();

			String portfoyKod = GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD");
			iMap.put("MUSTERI_NO", musteriNo);
			iMap.put("SUBE_KODU", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", portfoyKod)).getString("PORTFOY_SUBE_KOD"));

			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_GET_ONCEKI_BASVURU_HESAPNO", iMap));

			if (musteriNo != null && oMap.getBigDecimal("HESAP_NO") == null && oMap.getBigDecimal("REZERV_HESAP_NO") == null) {
				muhHesapRezerv = new MuhHesapRezerv();
				MuhHesapRezervId muhHesapRezervId = new MuhHesapRezervId();

				muhHesapRezervId.setHesapNo(getAccountNo());
				muhHesapRezervId.setMusteriNo(musteriNo);
				muhHesapRezerv.setId(muhHesapRezervId);
				muhHesapRezerv.setDurumKodu("A");

				oMap.put("REZERV_HESAP_NO", muhHesapRezervId.getHesapNo());

				muhHesapRezerv.setIban(getIbanNo(muhHesapRezervId.getHesapNo()));
				muhHesapRezerv.setDovizKodu(GMServiceExecuter.call("BNSPR_COMMON_GET_LOCAL_CUR", iMap).getString("DOVIZ_KODU"));
				muhHesapRezerv.setAciklama("3181 s�zle�me �ncesi rezerve");
				muhHesapRezerv.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				session.save(muhHesapRezerv);
				session.flush();

			}
			birBasvuruSozlesmeTx.setSozlesmeHesapNo((oMap.getBigDecimal("HESAP_NO") == null) ? oMap.getBigDecimal("REZERV_HESAP_NO") : oMap.getBigDecimal("HESAP_NO"));
			birBasvuruSozlesmeTx.setBayiDigitalBasvuru("H");
			
			/** PY-16299 PTT SMS Kredi */
			oMap.put("SOZLESME_HESAP_NO", birBasvuruSozlesmeTx.getSozlesmeHesapNo());

			oMap.put("PDF_VAR_EH", "E");
			/** Bayi yeni akis kontrol **/
			if ("2".equals(birBasvuru.getKanalKodu()) && birBasvuru.getSaticiKod() != null && !"1".equals(birBasvuru.getCalismaSekliKod())) {
				BirSatici satici = (BirSatici) session.get(BirSatici.class, birBasvuru.getSaticiKod());
				if ("1".equals(satici.getBayiKrediTipi()) || "2".equals(satici.getBayiKrediTipi())) {
					iMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
					GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).uniqueResult();
					if ("M".equals(musteri.getMusteriKontakt()) || "E".equals(GMServiceExecuter.call("BNSPR_CL_CERCEVE_SOZLESME_KONTROL", iMap).getString("SONUC"))) {
						// onceden eski akistan sozlesme basildiysa yine eski akistan olmasi gerekli..
						List<?> sozlesmeTxList = session.createCriteria(BirBasvuruSozlesmeTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.or(Restrictions.eq("bayiDigitalBasvuru", "H"), Restrictions.isNull("bayiDigitalBasvuru"))).list();
						if(sozlesmeTxList.size() == 0) {
							oMap.put("ELEKTRONIK_AKIS", "E");
							birBasvuruSozlesmeTx.setBayiDigitalBasvuru("E");
	
							// kart sorgulamasi yap
							iMap.put("TCKN", birBasvuru.getTcKimlikNo());
							GMServiceExecuter.execute("BNSPR_CL_GET_DEBIT_CARD_INFO", iMap);
	
							// sms gonder TY-11638 talep kapsam�nda a�a��ya al�nd�
//							if (birBasvuruKimlik.getCepTelAlanKodu() != null) {
//								iMap.put("MSISDN", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));
//								iMap.put("MESSAGE_NO", new BigDecimal(5407));
//								iMap.put("P1", iMap.getString("BASVURU_NO"));
//								iMap.put("CONTENT", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
//								GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap).get("RESULT");
//							}
	
							// pdf belirle
							if ("E".equals(birBasvuru.getPttEmekliPttBildir()) || "7".equals(birBasvuru.getKanalKodu()) || CreditTypes.TASIT.getCreditCode().compareTo(birBasvuru.getKrediTur()) == 0) {
								oMap.put("PDF_VAR_EH", "E");
							}
							else {
								oMap.put("PDF_VAR_EH", "H");
							}
						}
					}else{
						if(CreditTypes.TASIT.getCreditCode().compareTo(birBasvuru.getKrediTur()) != 0){
							iMap.put("HATA_NO", "5814");
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
					}
				}
			}

			session.saveOrUpdate(birBasvuruSozlesmeTx);
			session.flush();

			List<?> listBelge = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			Object[] arrayBelge = listBelge.toArray();
			for (int i = 0; i < arrayBelge.length; i++) {
				listBelge.remove(arrayBelge[i]);
				session.delete(arrayBelge[i]);
			}

			// rehin sozlesmesi icin alinan arac bilgileri kaydediliyor
			if (CreditTypes.TASIT.getCreditCode().compareTo(birBasvuru.getKrediTur()) == 0) {
				BirBasvuruTasit birBasvuruTasit = (BirBasvuruTasit) session.get(BirBasvuruTasit.class, birBasvuru.getBasvuruNo());

				if (birBasvuruTasit != null) {
					BirBasvuruTasitTx birBasvuruTasitTx = new BirBasvuruTasitTx();
					birBasvuruTasitTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruTasitTx.setBasvuruNo(birBasvuruTasit.getBasvuruNo());
					birBasvuruTasitTx.setAracKod(birBasvuruTasit.getAracKod());
					birBasvuruTasitTx.setMarka(birBasvuruTasit.getMarka());
					birBasvuruTasitTx.setModelYil(birBasvuruTasit.getModelYil());
					birBasvuruTasitTx.setModel(birBasvuruTasit.getModel());
					birBasvuruTasitTx.setKullanimAmac(birBasvuruTasit.getKullanimAmac());
					birBasvuruTasitTx.setKaskoDeger(birBasvuruTasit.getKaskoDeger());
					birBasvuruTasitTx.setNoterDeger(birBasvuruTasit.getNoterDeger());
					birBasvuruTasitTx.setPlaka(iMap.getString("ARAC_PLAKA"));
					birBasvuruTasitTx.setRuhsatTarih(iMap.getDate("ARAC_RUHSAT_TARIH"));
					birBasvuruTasitTx.setSicilNo(iMap.getString("ARAC_SICIL_NO"));
					birBasvuruTasitTx.setMotorNo(iMap.getString("ARAC_MOTOR_NO"));
					birBasvuruTasitTx.setSasiNo(ConsumerLoanCommonServices.nvl(iMap.getString("ARAC_SASI_NO"), "").trim());
					birBasvuruTasitTx.setTrafikSubesi(iMap.getString("ARAC_TRAFIK_SUBE"));
					session.saveOrUpdate(birBasvuruTasitTx);
				}
			}
			session.flush();

			iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
						
			iMap.put("TC_KIMLIK_NO", tc_kimlik_no);
			GMServiceExecuter.execute("BNSPR_TRN3171_PTT_EMEKLI_BLOKE_KOYMA", iMap);

			/** Paygate Check servisi asenkron call **/
			GMServiceExecuter.executeAsync("BNSPR_TRN3171_BASVURU_PAYGATE_CHECK", iMap);
			
			/* KAPS Sorgulama */
			GMMap paramMap = new GMMap();
			paramMap.put("KOD", "KAPS_SORGU");
			paramMap.put("KEY", "SORGU_KONTROL");
			String sorguKontrol = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).getString("TEXT");
			
			if("1".equals(sorguKontrol)){
				BirSatici satici = (BirSatici) session.createCriteria(BirSatici.class).add(Restrictions.eq("kod", birBasvuru.getSaticiKod())).uniqueResult();
				try {
					if ("8".equals(birBasvuru.getKanalKodu()) || ("2".equals(birBasvuru.getKanalKodu()) && "1".equals(satici.getBayiKrediTipi()))) {
						GMMap kapsMap = new GMMap();
						kapsMap.put("TCKN", tc_kimlik_no);
						kapsMap.put("KULLANICI", ADCSession.get("USER_NAME"));
						kapsMap.put("REZERVASYON", "0");
						kapsMap.put("REZERVASYON_TUTARI", birBasvuru.getOnayTutar());
						kapsMap.put("DOVIZ_KODU", "949");// GNL_PARAM_TEXT WHERE KOD = 'KAPS_SORGU'
						kapsMap.put("URUN_KODU", "02");
						GMServiceExecuter.executeAsync("BNSPR_KAPS_BILDIRIM_SORGULAMA", kapsMap);
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3181_COPY")
	public static Map<?, ?> copyTRN3181(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<BirBasvuruSozlesmeTx> sozlesmeList = session.createCriteria(BirBasvuruSozlesmeTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();

			BigDecimal maxTxNo = new BigDecimal(-1);
			int index = -1;

			for (int i = 0; i < sozlesmeList.size(); i++) {
				if (sozlesmeList.get(i).getTxNo().compareTo(maxTxNo) == 1) {
					index = i;
					maxTxNo = sozlesmeList.get(i).getTxNo();
				}
			}
			BirBasvuruSozlesmeTx birBasvuruSozlesmeTx = (BirBasvuruSozlesmeTx) DALUtil.clonePojo(sozlesmeList.get(index));
			birBasvuruSozlesmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruSozlesmeTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			session.saveOrUpdate(birBasvuruSozlesmeTx);
			session.flush();

			List<?> listBelge = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			Object[] arrayBelge = listBelge.toArray();
			for (int i = 0; i < arrayBelge.length; i++) {
				listBelge.remove(arrayBelge[i]);
				session.delete(arrayBelge[i]);
			}
			session.flush();
			if (iMap.getBoolean("CONFIRM")) {
				iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
				return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			else{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_trn3181.elektronik_belge_sil(?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));

				stmt.execute();
				return iMap;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL")
	public static Map<?, ?> sozlesmeBelgeleriniAl(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		boolean otoKul = true;
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			if (iMap.getBoolean("TEYIT_GEREKLI")) {
				if (!(iMap.getBoolean("SORUN_VAR") || iMap.getBoolean("SORUN_YOK"))) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "kimlik teyit");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}

			iMap.put("BAYI_ERKEN_BELGE_ALIMI", (String) GMServiceExecuter.execute("BNSPR_TRN3181_BAYI_ERKEN_BELGE_ALIMI", iMap).get("BAYI_ERKEN_BELGE_ALIMI"));
			oMap.put("BAYI_ERKEN_BELGE_ALIMI", iMap.getString("BAYI_ERKEN_BELGE_ALIMI"));

			String tableName = "TBL_BELGE";
			if (iMap.containsKey(tableName)) {
				List<?> belgeler = (ArrayList<?>) iMap.get(tableName);
				for (int row = 0; row < belgeler.size(); row++) {
					if (iMap.getBoolean("BELGE_KONTROL") && !iMap.getBoolean(tableName, row, "ALINDI") //
							&& !"E".equals(iMap.getString("BAYI_ERKEN_BELGE_ALIMI"))) {
						iMap.put("MESSAGE_NO", new BigDecimal(1026));
						iMap.put("P1", iMap.getBigDecimal("BASVURU_NO").toString());
						oMap.put("MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
						oMap.put("DURUM_KODU", "SOZLESME");
						return oMap;
					}
					BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setDokumanKod(iMap.getString(tableName, row, "BELGE_KODU"));
					id.setKimden(iMap.getString(tableName, row, "KIMDEN"));
					id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, id);
					if (birBasvuruBelgeTx == null) {
						birBasvuruBelgeTx = new BirBasvuruBelgeTx();
					}
					birBasvuruBelgeTx.setId(id);
					birBasvuruBelgeTx.setAlindi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, row, "ALINDI")));
					birBasvuruBelgeTx.setBelgeAlinmaAdim("S");
					session.save(birBasvuruBelgeTx);
				}
			}
			tableName = "TBL_BELGE_TO";
			if (iMap.containsKey(tableName)) {
				List<?> belgeler_to = (ArrayList<?>) iMap.get(tableName);
				for (int row = 0; row < belgeler_to.size(); row++) {
					BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setDokumanKod(iMap.getString(tableName, row, "BELGE_KODU"));
					id.setKimden(iMap.getString(tableName, row, "KIMDEN"));
					id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, id);
					if (birBasvuruBelgeTx == null) {
						birBasvuruBelgeTx = new BirBasvuruBelgeTx();
					}
					birBasvuruBelgeTx.setId(id);
					birBasvuruBelgeTx.setAlindi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, row, "ALINDI")));
					birBasvuruBelgeTx.setBelgeAlinmaAdim("TO");
					session.save(birBasvuruBelgeTx);
				}
			}
			tableName = "TBL_BELGE_TS";
			if (iMap.containsKey(tableName)) {
				List<?> belgeler_ts = (ArrayList<?>) iMap.get(tableName);
				for (int row = 0; row < belgeler_ts.size(); row++) {
					BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setDokumanKod(iMap.getString(tableName, row, "BELGE_KODU"));
					id.setKimden(iMap.getString(tableName, row, "KIMDEN"));
					id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, id);
					if (birBasvuruBelgeTx == null) {
						birBasvuruBelgeTx = new BirBasvuruBelgeTx();
					}
					birBasvuruBelgeTx.setId(id);
					birBasvuruBelgeTx.setAlindi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, row, "ALINDI")));
					birBasvuruBelgeTx.setBelgeAlinmaAdim("TS");
					session.save(birBasvuruBelgeTx);
				}
			}
			tableName = "TBL_BELGE_KS";
			if (iMap.containsKey(tableName)) {
				List<?> belgeler_ts = (ArrayList<?>) iMap.get(tableName);
				for (int row = 0; row < belgeler_ts.size(); row++) {
					BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setDokumanKod(iMap.getString(tableName, row, "BELGE_KODU"));
					id.setKimden(iMap.getString(tableName, row, "KIMDEN"));
					id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, id);
					if (birBasvuruBelgeTx == null) {
						birBasvuruBelgeTx = new BirBasvuruBelgeTx();
					}
					birBasvuruBelgeTx.setId(id);
					birBasvuruBelgeTx.setAlindi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, row, "ALINDI")));
					birBasvuruBelgeTx.setBelgeAlinmaAdim("KS");
					session.save(birBasvuruBelgeTx);
				}
			}
			session.flush();
			if (iMap.getBoolean("BELGE_KONTROL")) {
				BirBasvuruSozlesmeTx birBasvuruSozlesmeTx = (BirBasvuruSozlesmeTx) session.createCriteria(BirBasvuruSozlesmeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
				if (birBasvuruSozlesmeTx != null) {
					if (iMap.getBoolean("TEYIT_GEREKLI")) {
						birBasvuruSozlesmeTx.setKimlikTeyidiYapildiEh((iMap.getBoolean("SORUN_YOK")) ? "E" : "H");
					}
					if (iMap.getBoolean("TEYIT_GEREKLI") && iMap.getBoolean("SORUN_VAR")) {
						birBasvuruSozlesmeTx.setIslemSonrasiDurumKodu("RED");
						birBasvuruSozlesmeTx.setAksiyonKod("R");
						birBasvuruSozlesmeTx.setAksiyonKararKod("16");
					}
					else if ((iMap.getString("CALISMA_SEKLI_KOD") != null && iMap.getString("CALISMA_SEKLI_KOD").equals("2")) || "8".equals(iMap.getString("KANAL_KODU")) || "5".equals(iMap.getString("KANAL_KODU"))) {
						birBasvuruSozlesmeTx.setIslemSonrasiDurumKodu("KUL");
						birBasvuruSozlesmeTx.setAksiyonKod(null);
						birBasvuruSozlesmeTx.setAksiyonKararKod(null);
					}
					else {
						birBasvuruSozlesmeTx.setIslemSonrasiDurumKodu("BELGE");
						birBasvuruSozlesmeTx.setAksiyonKod(null);
						birBasvuruSozlesmeTx.setAksiyonKararKod(null);
					}
					birBasvuruSozlesmeTx.setDistAktarimOnay(iMap.getString("DIST_AKTARIM_EH"));
					session.saveOrUpdate(birBasvuruSozlesmeTx);
					session.flush();
					oMap.put("DURUM_KODU", birBasvuruSozlesmeTx.getIslemSonrasiDurumKodu());
					oMap.put("BAYI_DIGITAL_BASVURU", birBasvuruSozlesmeTx.getBayiDigitalBasvuru());
					if ((!StringUtil.isEmpty(iMap.getString("CONFIRM"))) && (!iMap.getBoolean("CONFIRM"))) {
						iMap.put("TRX_NAME", "3181");
						GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
					}
				}
			}
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3181.SozlesmeBelgeleriniAl(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();

			if (iMap.getBoolean("TEYIT_GEREKLI")) {
				if (iMap.getBoolean("SORUN_VAR")) {
					oMap.put("IPTAL", "E");
					oMap.put("DURUM_KODU", "RED");
					iMap.put("MESSAGE_NO", new BigDecimal(5202));
					oMap.put("MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				}
			}
			
			/** Eger digital bayi basvurusu ve butun belgeler elektronik ve alindi ise belge sureci otomatik tamamlaniyor 
			 * 
			 * 	TY-10560 kullandirim akis ile revizyon. Tasit haric bayi kredileri belgeler ok ise kullandirilacak.
			 * **/
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if("2".equals(birBasvuru.getKanalKodu()) && CreditTypes.TASIT.getCreditCode().compareTo(birBasvuru.getKrediTur()) != 0 && ("BELGE".equals(oMap.getString("DURUM_KODU")) || "KUL".equals(oMap.getString("DURUM_KODU")))){
				List<?> belgeList = session.createCriteria(BirBasvuruBelge.class)
						.add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
						.add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).list();
				
				GMMap bMap = new GMMap();
				
				BirBasvuruBelge birBasvuruBelge = null;	
				int j = 0;
				for (int i = 0; i < belgeList.size(); i++) {
					birBasvuruBelge = (BirBasvuruBelge) belgeList.get(i);
					if("E".equals(birBasvuruBelge.getAlindi())){
						bMap.put("BELGELER", j, "BELGE_KOD", birBasvuruBelge.getId().getDokumanKod());
						bMap.put("BELGELER", j, "BASVURU_NO", iMap.getString("BASVURU_NO"));
						bMap.put("BELGELER", j, "BELGE_ADI", birBasvuruBelge.getBelgeAdi());
						bMap.put("BELGELER", j, "ALINDI", birBasvuruBelge.getAlindi());
						bMap.put("BELGELER", j, "KIMDEN_KOD", birBasvuruBelge.getId().getKimden());
						bMap.put("BELGELER", j, "BELGE_KONTROL", birBasvuruBelge.getBelgeKontrol());
						bMap.put("BELGELER", j, "GELIS_TARIHI", birBasvuruBelge.getBelgeGelisTarihi());
						bMap.put("BELGELER", j, "ORJINAL_EVRAK_MI", GuimlUtil.convertToCheckBoxValue(birBasvuruBelge.getOrjinalEvrakMi()));
						bMap.put("BELGELER", j, "ISLEM_TARIHI", new Date());
						j++;
					}else{
						otoKul = false;
					}
				}
				
				if(otoKul){
					bMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					bMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
					bMap.put("CALISMA_TIPI", birBasvuru.getCalismaSekliKod());
					bMap.put("DURUM_KODU", birBasvuru.getDurumKodu());
					bMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
					bMap.put("MUSTERI_ESLESTIRME", "false");
					bMap.put("OTOMATIK_KULLANDIRIM", "true");
					bMap.put("OTOMATIK_AKIS", "E");
					GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", bMap);
					oMap.put("OTOMATIK_KULLANDIRIM", "true");
				}
			}
			
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3187_SOZLESME_BELGELERINI_AL")
	public static Map<?, ?> sozlesmeBegleriniAl1(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			List<?> belgeler = (ArrayList<?>) iMap.get("TBL_BELGE");
			String tableName = "TBL_BELGE";
			for (int row = 0; row < belgeler.size(); row++) {
				BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();

				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setDokumanKod(iMap.getString(tableName, row, "BELGE_KODU"));
				id.setKimden(iMap.getString(tableName, row, "KIMDEN"));
				id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, id);

				if (birBasvuruBelgeTx == null) {
					birBasvuruBelgeTx = new BirBasvuruBelgeTx();
				}
				birBasvuruBelgeTx.setId(id);

				birBasvuruBelgeTx.setAlindi("E");
				session.save(birBasvuruBelgeTx);
			}
			session.flush();
			BirBasvuruSozlesmeTx birBasvuruSozlesmeTx = (BirBasvuruSozlesmeTx) session.createCriteria(BirBasvuruSozlesmeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birBasvuruSozlesmeTx != null) {
				if ((iMap.getString("CALISMA_SEKLI_KOD") != null && iMap.getString("CALISMA_SEKLI_KOD").equals("2")) || "8".equals(iMap.getString("KANAL_KODU")) || "5".equals(iMap.getString("KANAL_KODU")))
					birBasvuruSozlesmeTx.setIslemSonrasiDurumKodu("KUL");
				else
					birBasvuruSozlesmeTx.setIslemSonrasiDurumKodu("BELGE");
				session.save(birBasvuruSozlesmeTx);
				session.flush();
			}
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3181.SozlesmeBelgeleriniAl(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_INFO_BY_TRX_NO")
	public static GMMap getInfoByTrxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuruSozlesmeTx birBasvuruSozlesmeTx = (BirBasvuruSozlesmeTx) session.get(BirBasvuruSozlesmeTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("BASVURU_NO", birBasvuruSozlesmeTx.getBasvuruNo());
			BigDecimal sigortaPrimi = birBasvuruSozlesmeTx.getSigortaPrimi();
			if (sigortaPrimi != null)
				oMap.put("SIGORTA_PRIMI", birBasvuruSozlesmeTx.getSigortaPrimi());
			else
				oMap.put("SIGORTA_PRIMI", new BigDecimal(0));
			oMap.put("SOZLESME_TARIHI", birBasvuruSozlesmeTx.getSozlesmeTarihi());
			oMap.put("GECIKME_GUN_SAYISI", birBasvuruSozlesmeTx.getGecikmeGunSayisi());
			oMap.put("ILK_TAKSIT_TARIHI", birBasvuruSozlesmeTx.getIlkTaksitTarihi());
			oMap.put("FAIZ_ODEME_SEKLI", birBasvuruSozlesmeTx.getFaizOdemeSekli());
			oMap.put("BANKA", birBasvuruSozlesmeTx.getBankaKod());
			oMap.put("IL", birBasvuruSozlesmeTx.getIlKod());
			oMap.put("SUBE", birBasvuruSozlesmeTx.getSubeKod());
			oMap.put("HESAP_NO", birBasvuruSozlesmeTx.getHesapNo());
			oMap.put("IBAN_NO", birBasvuruSozlesmeTx.getIban());
			oMap.put("AY_SONU", birBasvuruSozlesmeTx.getTaksitGunuAysonuMu().equals("E") ? true : false);
			oMap.put("TAKSIT_GUNU", birBasvuruSozlesmeTx.getTaksitGunu());

			if (iMap.getString("ACTION") != "MESAJ_KUTUSU_CAGIRDI" && iMap.getString("ACTION") != "CALL") {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_TRN3181.FarkFaiziOdemeSekli2(?)}");
				stmt.registerOutParameter(1, -10);
				stmt.setBigDecimal(2, birBasvuruSozlesmeTx.getBasvuruNo());
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(1);
				String listName = "FAIZ_ODEME_SEKLI_LIST";
				while (rSet.next()) {
					GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString("KEY1"), rSet.getString("TEXT"));
				}
			}
			else {
				iMap.put("KOD", "BIR_FARK_FAIZ_SEKLI_KOD");
				oMap.put("FAIZ_ODEME_SEKLI_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			}

			List<?> listBelge = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "TBL_BELGE";
			for (int row = 0; row < listBelge.size(); row++) {
				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) listBelge.get(row);
				String belgeKod = birBasvuruBelgeTx.getId().getDokumanKod();
				oMap.put(tableName, row, "BELGE_KODU", belgeKod);
				oMap.put(tableName, row, "BELGE_ADI", LovHelper.diLov(belgeKod, "3181/LOV_BELGE", "ACIKLAMA"));
				oMap.put(tableName, row, "ALINDI", GuimlUtil.convertToCheckBoxSelected(birBasvuruBelgeTx.getAlindi()));
			}

			oMap.put("TEMINAT_LIST", GMServiceExecuter.execute("BNSPR_TRN3181_GET_TEMINAT_LIST_BY_TX_NO", iMap).get("RESULTS"));
			oMap.put("SIGORTA_LIST", GMServiceExecuter.execute("BNSPR_TRN3181_GET_SIGORTA_LIST_BY_TX_NO", iMap).get("RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO_AFTER_TX")
	public static Map<?, ?> trn3181GetInfoByBasvuruNoAfterTx(GMMap iMap) {
		try {
			return GMServiceExecuter.execute("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO", iMap);
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_TEMINAT_LIST_BY_BASVURU_NO")
	public static GMMap trn3181GetTeminatListByBasvuruNo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer();
			query.append("select t.teminat_kod,pkg_genel_pr.Teminat_Adi(t.teminat_kod) as teminat_adi,");
			query.append("t.teminat_adedi from bir_basvuru_teminat t ");
			query.append("where t.basvuru_no = ? ");
			stmt = conn.prepareStatement(query.toString());
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			rSet = stmt.executeQuery();
			return DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_SIGORTA_LIST_BY_BASVURU_NO")
	public static GMMap trn3181GetSigortaListByBasvuruNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3181.Get_Sigorta_Satis_List_Basvuru(?)}");

			stmt.registerOutParameter(1, -10);

			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_TEMINAT_LIST_BY_TX_NO")
	public static GMMap trn3181GetTeminatListByTxNo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer();
			query.append("select t.teminat_kod,pkg_genel_pr.Teminat_Adi(t.teminat_kod) as teminat_adi,");
			query.append("t.teminat_adedi from bir_basvuru_teminat_tx t ");
			query.append("where t.tx_no = ? ");
			stmt = conn.prepareStatement(query.toString());
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			rSet = stmt.executeQuery();
			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_SIGORTA_LIST_BY_TX_NO")
	public static GMMap trn3181GetSigortaListByTxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3181.Get_Sigorta_Satis_List_Tx(?)}");

			stmt.registerOutParameter(1, -10);

			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_UPDATE_DURUM")
	public static GMMap updateDurum(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3171.updateDurum(?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			if (iMap.getString("CALISMA_SEKLI_KOD") != null && iMap.getString("CALISMA_SEKLI_KOD").equals("2")) {
				stmt.setString(2, "KUL");
				// kmh ise event yarat
				iMap.put("KREDI_TUR", DALUtil.callOneParameterFunction("{? = call pkg_trn3071.basvuru_kredi_turu(?)}", Types.NUMERIC, iMap.getBigDecimal("BASVURU_NO")));
				if ("5".equals(iMap.getString("KREDI_TUR"))) {
					GMServiceExecuter.execute("BNSPR_KMH_EVENT_YARAT", iMap);
				}
			}
			else
				stmt.setString(2, "BELGE");

			stmt.execute();

			iMap.put("MESSAGE_NO", new BigDecimal(711));
			// iMap.put("P1", iMap.getBigDecimal("BASVURU_NO").toString());

			oMap.put("MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_ILK_TAKSIT_TARIHI")
	public static GMMap getIlkTaksitTarihi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3181.Ilk_Taksit_Tarihi(?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(2, new java.sql.Date(iMap.getDate("SOZLESME_TARIHI").getTime()));
			stmt.registerOutParameter(3, Types.DATE);
			stmt.registerOutParameter(4, Types.INTEGER);

			stmt.execute();

			oMap.put("ILK_TAKSIT_TARIHI", stmt.getDate(3));
			oMap.put("TATIL_FARKI", stmt.getInt(4));

			GMServerDatasource.close(stmt);
			// PTT_GECIKME_GUN_SAYISI
			stmt = conn.prepareCall("{? = call PKG_PTT_KREDI.PTT_GECIKME_GUN_SAYISI(?,?)}");
			stmt.registerOutParameter(1, Types.INTEGER);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(3, new java.sql.Date(iMap.getDate("SOZLESME_TARIHI").getTime()));
			stmt.execute();
			oMap.put("GECIKME_GUN_SAYISI", stmt.getInt(1));

			Calendar calendar = Calendar.getInstance();
			calendar.setTime(oMap.getDate("ILK_TAKSIT_TARIHI"));
			calendar.add(Calendar.DATE, -oMap.getInt("GECIKME_GUN_SAYISI"));
			oMap.put("ILK_TAKSIT_TARIHI_ASIL", calendar.getTime());
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_KIMLIK_TEYIT_GEREKLI_MI")
	public static GMMap kimklikTeyitGerekliMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			oMap = getTaksitGunuList(iMap);
			oMap.put("TEYIT_GEREKLI_MI", "E");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_COMBO_TAKSIT_GUNU")
	public static GMMap getTaksitGunuList(GMMap iMap) {
		GMMap oMap = new GMMap();
		int i = 0;
		oMap.put("TAKSIT_GUNU", i, "VALUE", i);
		oMap.put("TAKSIT_GUNU", i, "NAME", "");
		i++;
		while (i < 30) {
			oMap.put("TAKSIT_GUNU", i, "VALUE", i);
			oMap.put("TAKSIT_GUNU", i, "NAME", i);
			i++;
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_GET_OTELEME_GUN_SAYISI")
	public static GMMap trn3181GetOtelemeGunSayisi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? =  call PKG_TRN3181.Oteleme_Gun_Sayisi(?,?,?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(3, new java.sql.Date(iMap.getDate("SOZLESME_TARIHI").getTime()));
			stmt.setBigDecimal(4, iMap.getBigDecimal("TAKSIT_GUNU"));
			stmt.setString(5, iMap.getBoolean("AY_SONU") ? "E" : "H");
			stmt.execute();
			BigDecimal otelemeGunSayisi = stmt.getBigDecimal(1);
			if (otelemeGunSayisi != null) {
				oMap.put("OTELEME_GUN", stmt.getString(1));
			}
			else
				oMap.put("OTELEME_GUN", BigDecimal.ZERO);
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3187_GET_KANAL_KODLARI")
	public static GMMap getKanalKodlari(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "KANAL_KODLARI");
		iMap.put("LIST_QUERY", "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by 1");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3187_GET_SATICI_KODLARI")
	public static GMMap getSaticiKodlari(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "SATICI_KODLARI");
		iMap.put("LIST_QUERY", "select distinct kod,pkg_genel_pr.kanal_Alt_adi(b.kanal_kodu,b.satici_kod) satici_adi from gnl_kanal_kod_pr s,bir_basvuru b where s.kod = b.satici_kod order by 1");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3187_BASVURU_GUNCELLE_LIST")
	public static GMMap getBasvuruGuncelleList1(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			if (iMap.getDate("BASLANGIC_TAR") != null && iMap.getDate("BITIS_TAR") != null) {
				if (iMap.getDate("BASLANGIC_TAR").after(iMap.getDate("BITIS_TAR"))) {
					iMap.put("HATA_NO", new BigDecimal(915));
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}
			conn = DALUtil.getGMConnection();
			BigDecimal kampKod = null;
			BigDecimal krdAltTurKod = null;
			if (iMap.getString("KAMP_URUN_ADI") != null) {
				if (iMap.getString("KAMP_URUN_ADI").indexOf('-') < 0)
					kampKod = iMap.getBigDecimal("KAMP_URUN_ADI");
				else {
					krdAltTurKod = new BigDecimal(iMap.getString("KAMP_URUN_ADI").substring(iMap.getString("KAMP_URUN_ADI").indexOf('-') + 1).substring(0, iMap.getString("KAMP_URUN_ADI").substring(iMap.getString("KAMP_URUN_ADI").indexOf('-') + 1).indexOf('-')));
				}
			}

			int i = 1;

			// 2 defa conn alinmis dolayisiyla ilk alinan conn close olmuyor
			// conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC_3187.getBasvuruGuncelleList(?,?,?,?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(i++, -10);
			// String kanalKod = null;
			// if(iMap.getString("KANAL_KODU") != null)
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			/*else
			{
				if(iMap.getString("KAMP_URUN_ADI") != null){
					kanalKod = iMap.getString("KAMP_URUN_ADI").substring(iMap.getString("KAMP_URUN_ADI").indexOf('-') + 1);
					kanalKod = kanalKod.substring(kanalKod.indexOf('-')+1, kanalKod.length());
				}
					stmt.setString(i++, kanalKod);
				
			}*/
			stmt.setString(i++, iMap.getString("SATICI_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(i++, kampKod);
			stmt.setBigDecimal(i++, krdAltTurKod);

			if (iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else
				stmt.setDate(i++, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "BASVURU_BILGILERI";
			int row = 0;

			while (rSet.next()) {
				oMap.put(tableName, row, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO").toString());
				oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getString("TC_KIMLIK_NO"));
				oMap.put(tableName, row, "AD_SOYAD", rSet.getString("ADI_SOYADI"));
				oMap.put(tableName, row, "BASVURU_TAR", rSet.getString("BASVURU_TARIHI"));
				oMap.put(tableName, row, "KREDI_TURU", rSet.getString("KREDI_TURU"));
				oMap.put(tableName, row, "KAMP_URUN_ADI", rSet.getString("KAMP_URUN_ADI"));
				oMap.put(tableName, row, "KREDI_TUTARI", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, row, "KANAL", rSet.getString("KANAL"));
				oMap.put(tableName, row, "SATICI", rSet.getString("SATICI"));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString("KANAL_KODU"));
				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3187_GET_EFT_BANKA")
	public static GMMap getEFTBanka(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "BANKA_TCMB_KODU");
		iMap.put("LIST_QUERY", "select banka_tcmb_kod BANKA_TCMB_KODU, banka_adi BANKA_ADI from gnl_banka_kod_pr where kapanma_tarihi is null and banka_tcmb_kod<>pkg_genel_pr.bankamiz_kodu order by banka_adi");
		DALUtil.fillComboBox(iMap);
		iMap.put("DATE", new Date());
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3187_GET_EFT_IL")
	public static GMMap getEFTBankaIl(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "IL_KODU");
		iMap.put("LIST_QUERY", "select distinct i.kod IL_KODU, i.il_adi IL_ADI from  gnl_il_kod_pr i, gnl_banka_sube_kod_pr s, gnl_banka_kod_pr b where i.kod = s.il_kod and s.banka_kod = b.kod and b.banka_tcmb_kod = " + iMap.getString("BANKA_TCMB_KODU") + " order by i.il_adi");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3187_GET_EFT_SUBE")
	public static GMMap getEFTBankaSube(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "SUBE_KODU");
		iMap.put("LIST_QUERY", "select s.sube_kod SUBE_KODU, s.sube_adi SUBE_ADI, i.kod IL_KODU, i.il_adi IL_ADI from gnl_banka_sube_kod_pr s, gnl_il_kod_pr i, gnl_banka_kod_pr b where b.banka_tcmb_kod = " + iMap.getString("BANKA_TCMB_KODU") + " and s.banka_kod = b.kod and s.il_kod = nvl(" + iMap.getString("IL_KODU") + ", s.il_kod) and s.il_kod = i.kod and s.kapanma_tarihi is null order by s.sube_adi ");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3181_MUSTERI_PERSONEL_MI")
	public static GMMap musteriPersonelMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_musteri.Personel_mi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

			stmt.execute();

			oMap.put("PERSONEL_MI", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_DEFAULT_FAIZ_ODEME_SEKLI")
	public static GMMap getDefaultFaizOdemeSekli(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3181.FarkFaiziOdemeSekli(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			oMap.put("DEFAULT_FAIZ_ODEME_SEKLI", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_KKDF_ORANI")
	public static GMMap kkdfOrani(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			if (new BigDecimal(5) == iMap.getBigDecimal("KRD_TUR_KOD")) {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_kmh.kkdf_oran(?)}");
				stmt.registerOutParameter(1, Types.INTEGER);
				stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

				stmt.execute();

				oMap.put("KKDF_ORANI", stmt.getBigDecimal(1).divide(new BigDecimal(100)));

				return oMap;
			}
			else {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_bireysel.kkdfOran(?)}");
				stmt.registerOutParameter(1, Types.INTEGER);
				stmt.setBigDecimal(2, iMap.getBigDecimal("KRD_TUR_KOD"));

				stmt.execute();

				oMap.put("KKDF_ORANI", stmt.getBigDecimal(1).divide(new BigDecimal(100)));

				return oMap;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_BSMV_ORANI")
	public static GMMap bsmvOrani(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			if (new BigDecimal(5) == iMap.getBigDecimal("KRD_TUR_KOD")) {
				oMap.put("BSMV_ORANI", new BigDecimal(0));
				return oMap;
			}
			else {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_bireysel.BSMVOran(?)}");
				stmt.registerOutParameter(1, Types.INTEGER);
				stmt.setBigDecimal(2, iMap.getBigDecimal("KRD_TUR_KOD"));

				stmt.execute();

				oMap.put("BSMV_ORANI", stmt.getBigDecimal(1).divide(new BigDecimal(100)));

				return oMap;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_TAKSIT_OTELEME_KOD")
	public static GMMap getTaksitOtelemeKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			iMap.put("KOD", "TAKSIT_OTELEME_KOD");
			oMap.put("TAKSIT_OTELEME_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			oMap.put("DATE", new Date());
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("GET_PTT_INFO")
	public static GMMap GetPTTInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3181.GetPttInfo(?,?,?,?)  }");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, Types.DATE);
			stmt.registerOutParameter(3, Types.NUMERIC);
			stmt.registerOutParameter(4, Types.NUMERIC);

			stmt.execute();

			// oMap.put("SIGORTA_PRIMI",stmt.getString(1));
			oMap.put("ILK_TAKSIT_TARIH_PTT", stmt.getDate(2));
			oMap.put("OTELEME_GUN_PTT", stmt.getBigDecimal(3));
			oMap.put("FARK_FAIZI", stmt.getBigDecimal(4));
			oMap.put("FAIZ_ODEME_SEKLI", "2");

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/*@GraymoundService("GET_SIGORTA_PRIM")
	public static GMMap GetSigortaPrim(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();
		try {
						
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3181.GetSigortaPrim2(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			
			oMap.put("SIGORTA_PRIMI",stmt.getBigDecimal(1)); 

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
	    }
	}*/
	@GraymoundService("BNSPR_TRN3181_SOZLEZME_BASIM_EH")
	public static GMMap sozlemeBasimEH(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3181.SozlesmeBasildiUpd(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, "E");
			stmt.execute();
			oMap.put("RESULT", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_HAFTASONU_OTELEME_SEKLI")
	public static GMMap haftasonuOtelemeSekli(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3181.HaftasonuOtelemeSekli(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("RESULT", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_PTT_KMH_SOZLESME_GENERATE_REPORT")
	public static GMMap generateReportPttKmhSozlesme(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			iMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));

			GMMap resultMap = GMServiceExecuter.call("CLKS_PTT_KMH_SOZLESME_BILGILERI_AL", iMap);

			HashMap<String, Object> rowData = new HashMap<String, Object>();

			rowData.put("SON_TX_NO", resultMap.getBigDecimal("ISLEM_NO_BANKA"));
			rowData.put("ISLEM_NO_BELGE", resultMap.getBigDecimal("ISLEM_NO_BELGE"));
			rowData.put("BARKOD_NO", resultMap.getBigDecimal("BARKOD_NUMARASI"));
			rowData.put("MESAJ_2", resultMap.getString("MESAJ_2"));
			rowData.put("MESAJ_1", resultMap.getString("MESAJ_1"));
			rowData.put("EKSTRE_UCRETI", resultMap.getBigDecimal("EKSTRE_UCRETI"));
			rowData.put("BANKA_ADRES", resultMap.getString("BANKA_ADRES"));
			rowData.put("BANKA_UNVAN", resultMap.getString("BANKA_UNVAN"));
			rowData.put("TUKETICI_ADRES", resultMap.getString("TUKETICI_ADRES"));
			rowData.put("GECIKME_FAIZI", resultMap.getBigDecimal("GECIKME_FAIZI"));
			rowData.put("AYLIK_FAIZ_ORANI", resultMap.getBigDecimal("AYLIK_FAIZ_ORANI"));
			rowData.put("BSMV", resultMap.getBigDecimal("BSMV"));
			rowData.put("KKDF", resultMap.getBigDecimal("KKDF"));
			rowData.put("ODEME_TARIHI", resultMap.getString("ODEME_TARIHI"));
			rowData.put("FAIZ_TAHAKKUK_GUNU", resultMap.getString("FAIZ_TAHAKKUK_GUNU"));
			rowData.put("FAIZ_TAHAKKUK_PERYODU", resultMap.getString("FAIZ_TAHAKKUK_PERYODU"));
			rowData.put("AD_SOYAD", resultMap.getString("AD_SOYAD"));
			rowData.put("LIMIT_TUTARI", resultMap.getBigDecimal("ONAYLANAN_LIMIT_TUTARI"));
			rowData.put("KDH_DOVIZ", resultMap.getString("KDH_DOVIZ"));
			rowData.put("VDSZ_HESAP_NO", resultMap.getBigDecimal("VDSZ_HESAP_NO"));
			rowData.put("MUSTERI_NO", resultMap.getBigDecimal("MUSTERI_NO"));
			rowData.put("SOZLESME_TARIHI", resultMap.getString("SOZLESME_TARIHI"));
			rowData.put("BASVURU_NO", resultMap.getBigDecimal("BASVURU_NO"));
			rowData.put("TCKN", iMap.getString("TCKN"));

			ArrayList<HashMap<String, Object>> reportModelData = new ArrayList<HashMap<String, Object>>();
			reportModelData.add(rowData);

			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("REPORT_DATA", reportModelData);

			JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3181_PTT_KMH_SOZLESME", parameters);
			oMap.put("REPORT", jasperPrint);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static BigDecimal getAccountNo() {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_GENEL_PR.genel_kod_al('HESAP.VDSZ')}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.execute();
			return stmt.getBigDecimal(1);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static String getIbanNo(BigDecimal hesapNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call Pkg_Iban.sp_IBAN_al(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, hesapNo);
			stmt.execute();
			return stmt.getString(1);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_ERKEN_BELGE_BASIM_DURUM")
	public static Map<?, ?> getErkenBelgeBasimDurum(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{ ? = call PKG_TRN3181.erken_belge_basvuru_durum_list(?,?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("SATICI_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEM_TUR");
			oMap = DALUtil.callOracleRefCursorFunction(func, "ALINACAK_AKSIYON", inputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_ALINACAK_AKSIYON_LIST")
	public static GMMap getAlinacakAksiyonList(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("ISLEM_TUR", "CONTRACT");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_ERKEN_BELGE_BASIM_DURUM", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_BAYI_ERKEN_BELGE_ALIMI")
	public static Map<?, ?> getBayiErkenBelgeAlabilir(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{ ? = call PKG_TRN3181.erken_belge_alinabilir_mi(?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			String durum = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
			oMap.put("BAYI_ERKEN_BELGE_ALIMI", durum);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_HERSEY_DAHIL_TUTAR")
	public static Map<?, ?> getHerseyDahilTutar(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{ ? = call PKG_TRN3181.hersey_dahil_kredi_tutar(?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			BigDecimal tutar = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			oMap.put("HERSEY_DAHIL_TUTAR", tutar);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_SOZLESME_BASILDI_MI")
	public static Map<?, ?> getSozlesmeBasildiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{ ? = call PKG_TRN3181.sozlesme_basildi_mi(?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			String durum = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
			oMap.put("SOZLESME_BASILDI_EH", durum);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_ERKEN_BELGE_TX_NO")
	public static Map<?, ?> getErkenBelgeTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{ ? = call PKG_TRN3181.erken_belge_tx_no(?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			BigDecimal tx_no = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			oMap.put("ERKEN_BELGE_TX_NO", tx_no);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_PTT_EMEKLISI_MI")
	public static GMMap getPttEmeklisiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_PTT_EMEKLISI_MI", iMap));

		if ("E".equals(oMap.getString("PTT_EMEKLISI_MI")))
			oMap.put("PTT_EMEKLISI_MI", "1");
		else
			oMap.put("PTT_EMEKLISI_MI", "0");
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_GET_ONCEKI_BASVURU_HESAPNO")
	public static GMMap getOncekiBasvuruHesapno(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (iMap.get("ALAC_HESAP_NO") == null) {
			Session session = DAOSession.getSession("BNSPRDal");

			String func = "{ ? = call PKG_TRN3181.onceki_basvuru_hesap_no(?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			BigDecimal hesapNo = null;
			try {
				hesapNo = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			if (hesapNo != null) {
				oMap.put("HESAP_NO", hesapNo);
				MuhHesapRezerv hr = (MuhHesapRezerv) session.createCriteria(MuhHesapRezerv.class).add(Restrictions.eq("id.hesapNo", hesapNo)).add(Restrictions.eq("durumKodu", "A")).uniqueResult();
				if (hr != null) {
					if (hr.getBasvuruNo() == null) {
						hr.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						session.flush();
					}
					oMap.put("REZERV_HESAP_NO", hesapNo);
				}
			}
			else {
				/** ayni basvuruda rezerv hesap kapatilip geri donus olabiliyor **/
				List<MuhHesapRezerv> lst = session.createCriteria(MuhHesapRezerv.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				if (lst != null && lst.size() > 0) {
					if ("A".equals(lst.get(0).getDurumKodu())) {
						oMap.put("REZERV_HESAP_NO", lst.get(0).getId().getHesapNo());
					}
					else {
						oMap.put("HESAP_NO", lst.get(0).getId().getHesapNo());
					}
				}
			}
		}
		else {
			oMap.put("HESAP_NO", iMap.get("ALAC_HESAP_NO"));
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3187_AFTER_BELGE_YUKLE")
	public static GMMap afterBelgeYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap bMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		conn = DALUtil.getGMConnection();

		try {
			stmt = conn.prepareCall("{? = call PKG_RC3173.rc_qry3173_bayi_gorsun_eh(?)}");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			while (rSet.next()) {
				bMap.put(rSet.getString("DOKUMAN_KOD"), rSet.getString("BAYI_GORSUN_EH"));
			}

			List<?> belge = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();
			String asilBelgeGerekliEh = "";

			String tableName = "TBL_BELGE";
			int row_x = 0;
			for (int row = 0; row < belge.size(); row++) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge.get(row);
				String dokumanKod = birBasvuruBelge.getId().getDokumanKod();

				String bayiGorsunMu = "" + bMap.get(dokumanKod);

				if ("E".equals(bayiGorsunMu)) {
					oMap.put(tableName, row_x, "BELGE_KODU", dokumanKod);
					oMap.put(tableName, row_x, "BELGE_KIMDEN", LovHelper.diLov(birBasvuruBelge.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
					oMap.put(tableName, row_x, "KIMDEN", birBasvuruBelge.getId().getKimden());
					oMap.put(tableName, row_x, "BELGE_ADI", LovHelper.diLov(dokumanKod, "3181/LOV_BELGE", "ACIKLAMA"));
					oMap.put(tableName, row_x, "ALINDI", GuimlUtil.convertToCheckBoxSelected(birBasvuruBelge.getAlindi()));
					asilBelgeGerekliEh = LovHelper.diLov(dokumanKod, "3182/LOV_BELGE_EKLE_KOD", "ASIL_BELGE_GEREKLI_EH");
					if (birBasvuruBelge.getBelgeKontrol() != null) {
						if (birBasvuruBelge.getBelgeKontrol().equalsIgnoreCase("6") || birBasvuruBelge.getBelgeKontrol().equalsIgnoreCase("7")) {
							oMap.put(tableName, row_x, "YUKLENDI", true);
						}
						else {
							oMap.put(tableName, row_x, "YUKLENDI", false);
						}
					}
					else {
						oMap.put(tableName, row_x, "YUKLENDI", false);
					}
					oMap.put(tableName, row_x, "ELEKTRONIK_BELGE_ALINABILIR", "H".equals(asilBelgeGerekliEh) ? "E" : "H");
					row_x++;
				}
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return oMap;
	}
}
