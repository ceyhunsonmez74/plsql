package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3196Services {
	
	@GraymoundService("BNSPR_QRY3196_GET_COMBOBOX_INITIAL_VALUE")
	public static GMMap getComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "KANAL"	, true, "select b.kanal_kodu, " +
			"pkg_genel_pr.kanal_adi(b.kanal_kodu) kanal_adi from bir_basvuru b group by b.kanal_kodu order by 1");
			
			DALUtil.fillComboBox(oMap, "TELEFON_TIPLERI"	, true, "select key1, " +
			"text from v_ml_gnl_param_text v where v.KOD='TELEFON_TIPLERI'  order by key1");
			
			DALUtil.fillComboBox(oMap, "ADRES_TIPLERI"	, true, "SELECT a.adres_kod ADRES_TIPI, a.aciklama ACIKLAMA "+
			"FROM v_ml_gnl_adres_grup_pr a "+
			"where a.musteri_tur_kod='G' "+
			"and a.adres_kod in('E','I','Y') "+
			"ORDER BY a.adres_kod");
			
			DALUtil.fillComboBox(oMap, "MUSTERI_GRUBU", true, "select kod, aciklama from V_ML_GNL_MUSTERI_GRUP_KOD_PR v order by kod");
						
			oMap.putAll(GMServiceExecuter.call("BNSPR_QRY3196_GET_SATICI_KOD", iMap));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_KREDI_TURLERI", iMap));
			
			iMap.put("KOD"				, "KREDI_HESAP_DURUM");
			
			/** TY-6901 TY-Bireysel krediler Servis �al��malar�_Kredi ve ba�vuruya ait bilgiler i�in servis */
			if("8034".equals(iMap.getString("EKRAN_NO")))
				iMap.put("ADD_EMPTY_KEY", "HEPSI");		
			else 
				iMap.put("ADD_EMPTY_KEY", "E");	
			oMap.put("HESAP_DURUM_LIST"	, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", 
											iMap).get("RESULTS"));
			iMap.put("KOD"				, "KRD_HESAP_TAKIP_SON_GORUSME");
			iMap.put("ADD_EMPTY_KEY"	, "E");
			oMap.put("SON_GORUSME_LIST"	, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", 
											iMap).get("RESULTS"));	
			
			iMap.put("KOD", "3195_FRAUD_PAR");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("FRAUD_PAR_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			return oMap;
			
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY3196_GET_SATICI_KOD")
    public static GMMap getSaticiKod(GMMap iMap){
           try{
                  GMMap oMap = new GMMap();
                  DALUtil.fillComboBox(oMap, "SATICI", true, "select kod, aciklama from v_kanal_alt_kod_pr where kanal_kod = nvl(" + iMap.getString("KANAL_KOD") + ",kanal_kod) and ((kanal_kod = '2' and kod in (select s.kod from bir_satici_tahsis s)) or kanal_kod <> '2') and ROWNUM < 9999 order by 1");
                  return oMap;
           }catch (Exception e) {
                  throw ExceptionHandler.convertException(e);
           }
    }
	
	@GraymoundService("BNSPR_QRY3196_GET_KREDI_LIST")
	public static GMMap getKrediList(GMMap iMap){
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3196.get_kredi_list(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCKN"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAKIYE_ALT").doubleValue() > 0 ? 
										iMap.getBigDecimal("BAKIYE_ALT") : null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAKIYE_UST").doubleValue() > 0 ? 
					iMap.getBigDecimal("BAKIYE_UST") : null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VADESIZ_HESAP_NO"));
			stmt.setString(i++,iMap.getString("HESAP_DURUMU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("GECIKME_TUTARI_ALT").doubleValue() > 0 ? 
					iMap.getBigDecimal("GECIKME_TUTARI_ALT") : null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("GECIKME_TUTARI_UST").doubleValue() > 0 ? 
					iMap.getBigDecimal("GECIKME_TUTARI_UST") : null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("GECIKME_GUN_SAYISI"));
			if(iMap.getDate("GECIKME_TARIHI_ALT")!=null) {
				stmt.setDate(i++, new Date(iMap.getDate("GECIKME_TARIHI_ALT").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			if(iMap.getDate("GECIKME_TARIHI_UST")!=null) {
				stmt.setDate(i++, new Date(iMap.getDate("GECIKME_TARIHI_UST").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SATICI_KODU"));
			stmt.setString(i++, iMap.getBoolean("VEFAT_DURUMU") ? "E" : "H");
			stmt.setString(i++, iMap.getString("FAIZSIZ_FINANSMAN"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "KREDI_LIST");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3196_GET_KREDI_BILGILERI")
	public static GMMap getKrediBilgileri(GMMap iMap){
		Connection 			conn 		= null;
		CallableStatement 	stmt 		= null;
		CallableStatement 	stmt2 		= null;
		ResultSet 			rSetKredi 	= null;
		ResultSet 			rSetGorus 	= null;
		ResultSet 			rSetTel 	= null;
		ResultSet 			rSetAdr 	= null;
		ResultSet 			rSetArama 	= null;
		GMMap				oMap		= new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3196.get_kredi_bilgileri(?,?,?,?,?,?)}");
			int i =1;	
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_HESAP_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSetKredi = (ResultSet)stmt.getObject(2);
			rSetGorus = (ResultSet)stmt.getObject(3);
			rSetTel= (ResultSet)stmt.getObject(4);
			rSetAdr = (ResultSet)stmt.getObject(5);
			rSetArama = (ResultSet)stmt.getObject(6);

			while (rSetGorus.next()) {
				GuimlUtil.wrapMyCombo(oMap, "TAHSIS_GORUS_LIST", null, rSetGorus.getString(1));
			}			
			
			oMap.putAll(DALUtil.rSetMap(rSetKredi));
            oMap.put("TAHSILAT_YAPILAMAZ", oMap.getString("TAHSILAT_YAPILAMAZ")==null?false:(oMap.getString("TAHSILAT_YAPILAMAZ").equalsIgnoreCase("E")?true:false));
            oMap.put("BAYIDEN_KAPATILACAK", oMap.getString("BAYIDEN_KAPATILACAK")==null?false:(oMap.getString("BAYIDEN_KAPATILACAK").equalsIgnoreCase("E")?true:false));
            oMap.put("YENIDEN_YAP_EH", oMap.getString("YENIDEN_YAP_EH")==null?false:(oMap.getString("YENIDEN_YAP_EH").equalsIgnoreCase("E")?true:false));
			oMap.put("FPD", oMap.getString("FPD") == null ? false : (oMap.getString("FPD").equalsIgnoreCase("E") ? true : false));
			oMap.put("ILK_KEZ_GECIKME_MI", oMap.getString("ILK_KEZ_GECIKME_MI") == null ? false : (oMap.getString("ILK_KEZ_GECIKME_MI").equalsIgnoreCase("E") ? true : false));
			if("Y".equals(oMap.getString("FRAUD_NEDEN_KOD")) || "".equals(oMap.getString("FRAUD_NEDEN_KOD")))
				oMap.put("FRAUD_VAR_MI", false);
			else
				oMap.put("FRAUD_VAR_MI", true);
			
			String aramaNedeni = oMap.getString("ARAMA_NEDENI");
			if(aramaNedeni != null && aramaNedeni.length()==13){
				if(aramaNedeni.charAt(0) == '1'){
					oMap.put("GECIKMEDE", true);
				}else{
					oMap.put("GECIKMEDE", false);
				}
				if(aramaNedeni.charAt(1) == '1'){
					oMap.put("EMEKLI_MAASINI_AKTARMIS", true);
				}else{
					oMap.put("EMEKLI_MAASINI_AKTARMIS", false);
				}
				if(aramaNedeni.charAt(2) == '1'){
					oMap.put("TEMINAT", true);
				}else{
					oMap.put("TEMINAT", false);
				}
				if(aramaNedeni.charAt(3) == '1'){
					oMap.put("E_HACIZ", true);
				}else{
					oMap.put("E_HACIZ", false);
				}
				if(aramaNedeni.charAt(4) == '1'){
					oMap.put("VEFAT", true);
				}else{
					oMap.put("VEFAT", false);
				}
				if(aramaNedeni.charAt(5) == '1'){
					oMap.put("TAKSIT_TARIHI_ERTELEME", true);
				}else{
					oMap.put("TAKSIT_TARIHI_ERTELEME", false);
				}	
				if(aramaNedeni.charAt(6) == '1'){
					oMap.put("MAASI_KESILMIS", true);
				}else{
					oMap.put("MAASI_KESILMIS", false);
				}
				if(aramaNedeni.charAt(7) == '1'){
					oMap.put("KAYIP_MUSTERI", true);
				}else{
					oMap.put("KAYIP_MUSTERI", false);
				}
				if(aramaNedeni.charAt(8) == '1'){
					oMap.put("IADE_ISTENDI", true);
				}else{
					oMap.put("IADE_ISTENDI", false);
				}
				if(aramaNedeni.charAt(9) == '1'){
					oMap.put("HAREKETSIZ_HESAP", true);
				}else{
					oMap.put("HAREKETSIZ_HESAP", false);
				}if(aramaNedeni.charAt(10) == '1'){
					oMap.put("YENIDEN_YAPILANDIRMA", true);
				}else{
					oMap.put("YENIDEN_YAPILANDIRMA", false);
				}if(aramaNedeni.charAt(11) == '1'){
					oMap.put("HIC_ULASILAMADI", true);
				}else{
					oMap.put("HIC_ULASILAMADI", false);
				}if(aramaNedeni.charAt(12) == '1'){
					oMap.put("BASKA_BANKA_KREDISI_VAR", true);
				}else{
					oMap.put("BASKA_BANKA_KREDISI_VAR", false);
				}
			}else{
				oMap.put("GECIKMEDE", false);
				oMap.put("EMEKLI_MAASINI_AKTARMIS", false);
				oMap.put("TEMINAT", false);
				oMap.put("E_HACIZ", false);
				oMap.put("VEFAT", false);
				oMap.put("TAKSIT_TARIHI_ERTELEME", false);
				oMap.put("MAASI_KESILMIS", false);
				oMap.put("KAYIP_MUSTERI", false);
				oMap.put("IADE_ISTENDI", false);
				oMap.put("HAREKETSIZ_HESAP", false);
				oMap.put("YENIDEN_YAPILANDIRMA", false);
				oMap.put("HIC_ULASILAMADI", false);
				oMap.put("BASKA_BANKA_KREDISI_VAR", false);
			}
			oMap.putAll(DALUtil.rSetResults(rSetTel,"TEL_LIST"));
			for(int k=0;k<oMap.getSize("TEL_LIST");k++){
				oMap.put("TEL_LIST",k,"T_SIRA_NO","T"+oMap.getString("TEL_LIST",k,"SIRA_NO"));
				oMap.put("TEL_LIST",k,"KENDINE_MI_AIT", "E".equals(oMap.getString("TEL_LIST", k, "KENDINE_MI_AIT")));
			}
			oMap.putAll(DALUtil.rSetResults(rSetAdr,"ADR_LIST"));
			for(int k=0;k<oMap.getSize("ADR_LIST");k++){
				oMap.put("ADR_LIST",k,"A_SIRA_NO","A"+oMap.getString("ADR_LIST",k,"SIRA_NO"));
			}
			oMap.putAll(DALUtil.rSetResults(rSetArama,"ARAMA_LIST"));
						
			/* Son G�ncelleme Gerek�esi */
            stmt2 = conn.prepareCall("{? = call PKG_TRN3199.Son_Guncelleme_Gerekcesi(?)}");
            stmt2.registerOutParameter(1 , Types.VARCHAR);
            stmt2.setBigDecimal(2 , iMap.getBigDecimal("BASVURU_NO"));
            stmt2.execute();
            
            oMap.put("SON_ISLEM_GEREKCE", stmt2.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSetKredi);
			GMServerDatasource.close(rSetGorus);
			GMServerDatasource.close(rSetTel);
			GMServerDatasource.close(rSetAdr);
			GMServerDatasource.close(rSetArama);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3196_GET_DETAY_IZLE")
	public static GMMap getDetayIzle(GMMap iMap){
		Connection 			conn 		= null;
		CallableStatement 	stmt 		= null;
		ResultSet 			rSetKredi 	= null;
		ResultSet 			rSetGorus 	= null;
		ResultSet 			rSetTel 	= null;
		ResultSet 			rSetAdr 	= null;
		ResultSet 			rSetArama 	= null;
		GMMap				oMap		= new GMMap();
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3196.get_kredi_bilgileri(?,?,?,?,?,?)}");
			int i =1;	
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_HESAP_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSetKredi = (ResultSet)stmt.getObject(2);
			rSetGorus = (ResultSet)stmt.getObject(3);
			rSetTel= (ResultSet)stmt.getObject(4);
			rSetAdr = (ResultSet)stmt.getObject(5);
			rSetArama = (ResultSet)stmt.getObject(6);

			while (rSetGorus.next()) {
				GuimlUtil.wrapMyCombo(oMap, "TAHSIS_GORUS_LIST", null, rSetGorus.getString(1));
			}

			oMap.putAll(DALUtil.rSetMap(rSetKredi));
            oMap.put("TAHSILAT_YAPILAMAZ", oMap.getString("TAHSILAT_YAPILAMAZ")==null?false:(oMap.getString("TAHSILAT_YAPILAMAZ").equalsIgnoreCase("E")?true:false));
            oMap.put("BAYIDEN_KAPATILACAK", oMap.getString("BAYIDEN_KAPATILACAK")==null?false:(oMap.getString("BAYIDEN_KAPATILACAK").equalsIgnoreCase("E")?true:false));

			String aramaNedeni = oMap.getString("ARAMA_NEDENI");
			if(aramaNedeni != null && aramaNedeni.length()==13){
				if(aramaNedeni.charAt(0) == '1'){
					oMap.put("GECIKMEDE", true);
				}else{
					oMap.put("GECIKMEDE", false);
				}
				if(aramaNedeni.charAt(1) == '1'){
					oMap.put("EMEKLI_MAASINI_AKTARMIS", true);
				}else{
					oMap.put("EMEKLI_MAASINI_AKTARMIS", false);
				}
				if(aramaNedeni.charAt(2) == '1'){
					oMap.put("TEMINAT", true);
				}else{
					oMap.put("TEMINAT", false);
				}
				if(aramaNedeni.charAt(3) == '1'){
					oMap.put("E_HACIZ", true);
				}else{
					oMap.put("E_HACIZ", false);
				}
				if(aramaNedeni.charAt(4) == '1'){
					oMap.put("VEFAT", true);
				}else{
					oMap.put("VEFAT", false);
				}
				if(aramaNedeni.charAt(5) == '1'){
					oMap.put("TAKSIT_TARIHI_ERTELEME", true);
				}else{
					oMap.put("TAKSIT_TARIHI_ERTELEME", false);
				}	
				if(aramaNedeni.charAt(6) == '1'){
					oMap.put("MAASI_KESILMIS", true);
				}else{
					oMap.put("MAASI_KESILMIS", false);
				}
				if(aramaNedeni.charAt(7) == '1'){
					oMap.put("KAYIP_MUSTERI", true);
				}else{
					oMap.put("KAYIP_MUSTERI", false);
				}
				if(aramaNedeni.charAt(8) == '1'){
					oMap.put("IADE_ISTENDI", true);
				}else{
					oMap.put("IADE_ISTENDI", false);
				}
				if(aramaNedeni.charAt(9) == '1'){
					oMap.put("HAREKETSIZ_HESAP", true);
				}else{
					oMap.put("HAREKETSIZ_HESAP", false);
				}if(aramaNedeni.charAt(10) == '1'){
					oMap.put("YENIDEN_YAPILANDIRMA", true);
				}else{
					oMap.put("YENIDEN_YAPILANDIRMA", false);
				}if(aramaNedeni.charAt(11) == '1'){
					oMap.put("HIC_ULASILAMADI", true);
				}else{
					oMap.put("HIC_ULASILAMADI", false);
				}if(aramaNedeni.charAt(12) == '1'){
					oMap.put("BASKA_BANKA_KREDISI_VAR", true);
				}else{
					oMap.put("BASKA_BANKA_KREDISI_VAR", false);
				}
			}else{
				oMap.put("GECIKMEDE", false);
				oMap.put("EMEKLI_MAASINI_AKTARMIS", false);
				oMap.put("TEMINAT", false);
				oMap.put("E_HACIZ", false);
				oMap.put("VEFAT", false);
				oMap.put("TAKSIT_TARIHI_ERTELEME", false);
				oMap.put("MAASI_KESILMIS", false);
				oMap.put("KAYIP_MUSTERI", false);
				oMap.put("IADE_ISTENDI", false);
				oMap.put("HAREKETSIZ_HESAP", false);
				oMap.put("YENIDEN_YAPILANDIRMA", false);
				oMap.put("HIC_ULASILAMADI", false);
				oMap.put("BASKA_BANKA_KREDISI_VAR", false);


			}
			oMap.putAll(DALUtil.rSetResults(rSetTel,"TEL_LIST"));
			for(int k=0;k<oMap.getSize("TEL_LIST");k++){
				oMap.put("TEL_LIST",k,"T_SIRA_NO","T"+oMap.getString("TEL_LIST",k,"SIRA_NO"));
				oMap.put("TEL_LIST",k,"KENDINE_MI_AIT", "E".equals(oMap.getString("TEL_LIST", k, "KENDINE_MI_AIT")));
			}
			oMap.putAll(DALUtil.rSetResults(rSetAdr,"ADR_LIST"));
			for(int k=0;k<oMap.getSize("ADR_LIST");k++){
				oMap.put("ADR_LIST",k,"A_SIRA_NO","A"+oMap.getString("ADR_LIST",k,"SIRA_NO"));
			}
			
			oMap.putAll(DALUtil.rSetResults(rSetArama,"ARAMA_LIST"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSetKredi);
			GMServerDatasource.close(rSetGorus);
			GMServerDatasource.close(rSetTel);
			GMServerDatasource.close(rSetAdr);
			GMServerDatasource.close(rSetArama);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
