package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrediYetkiLimitPrTx;
import tr.com.aktifbank.bnspr.dao.KkbOrtamYetkiTalepTx;
import tr.com.aktifbank.bnspr.dao.VdmkKrediDevirTx;
import tr.com.aktifbank.bnspr.dao.VdmkKrediDevirTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3254Services {

	@GraymoundService("BNSPR_TRN3254_TEST_DEVIR_LIST")
	public static GMMap getTersDevirList(GMMap iMap) {
		GMMap oMap = new GMMap();
		String func = "{? = call pkg_trn3254.tersdevir_sorgula(?)}";
		try{
			Object inputValues[]={
				BnsprType.NUMBER,iMap.getBigDecimal("DEVIR_NO")  
			};
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TERSDEVIR_TABLO", inputValues));
			if(oMap.getSize("TERSDEVIR_TABLO")==0) {
				 iMap.put("MESSAGE_NO", new java.math.BigDecimal(1614));
		         String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
		         throw new GMRuntimeException(0, message);
			}
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3254_GET_INFO")
	public static GMMap getInfoTRN3254(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<VdmkKrediDevirTx> liste = session.createCriteria(VdmkKrediDevirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

//		oMap.put("BASVURU_NO", liste.get(0).getId().getBasvuruNo());
		oMap.put("DEVIR_NO", liste.get(0).getId().getDevirNo());
		oMap.put("TRX_NO", liste.get(0).getId().getTxNo());
		
    	String tableName = "TERSDEVIR_TABLO";
		int row = 0;
		
		
		for (Iterator<?> iterator = liste.iterator(); iterator.hasNext(); row++){
			
			VdmkKrediDevirTx tx = (VdmkKrediDevirTx) iterator.next();
			
			oMap.put(tableName, row, "BASVURU_NO",  tx.getId().getBasvuruNo() );
			
				 String func = "{? = call pkg_trn3254.kredi_bilgi(?)}"; 
            	 Object inputValues[] = {
            		BnsprType.NUMBER,tx.getId().getBasvuruNo()	 
            	 };
            	 GMMap tMap = null;
            	 
				try {
					tMap = DALUtil.callOracleRefCursorFunction(func,tableName, inputValues);
				}
				catch (SQLException e) {
					e.printStackTrace();
				}
            	 int ind = oMap.getSize(tableName);  
            	 int len = tMap.getSize(tableName);            	 
            	 if(len>0) {            		
            		 Set<?> keySet = (Set<?>) tMap.getMap(tableName,0).keySet();
            		 String keys[] = keySet.toArray(new String[keySet.size()]);
            		 Arrays.sort(keys);            		          		
            		 for(int i=0;i<len;i++) {            			          			            		 
            			 for(String key:keys) {
	            			 Object val= tMap.get(tableName,i, key);	            				            			
	            			 //oMap.put(tableName,ind,key,val);
	            			 if(key.equals("URUN_SINIF_KOD") || key.equals("BAKIYE") || key.equals("TAKIP_DURUM") || key.equals("HESAP_NO")  || key.equals("DEVIR_TARIHI")  ) 
	            				 oMap.put(tableName, row, key, val );
	            		 }
	            		 ind++;
            		 }
            	 } 
            
			//oMap.put(tableName, row, "URUN_SINIF_KOD", tx.getYeniUrunSinifKod());			
			//oMap.put(tableName, row, "YENI_MODUL_TUR_KOD", tx.getYeniModulTurKod());
			//oMap.put(tableName, row, "YENI_URUN_SINIF_KOD", tx.getYeniUrunSinifKod() );
			//oMap.put(tableName, row, "YENI_URUN_TUR_KOD", tx.getYeniUrunTurKod() );
			//oMap.put(tableName, row, "ISLEM_ACIKLAMA", tx.getIslemAciklama() );
			
		}
		return oMap;
		
	}
	
	@GraymoundService("BNSPR_TRN3254_ISLEM_YETKI")
	public static GMMap getIslemYetki(GMMap iMap) {
		GMMap oMap = new GMMap();
		String func = "{? = call pkg_trn3254.islem_yetki(?)}";
		try{
			Object inputValues[]={
				BnsprType.STRING,(String) DALUtil.callOracleFunction("{? = call pkg_global.get_kullanicikod}", BnsprType.STRING)  
			};		
			String yetki = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);			
			oMap.put("ISLEM_YETKI", "E".equals(yetki));			
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3254_SAVE")
	public static GMMap save3254(GMMap iMap) {			
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName="TERSDEVIR_TABLO";
			int len = iMap.getSize(tableName);
	        for(int i=0;i<len;i++) {
	        	VdmkKrediDevirTx vdmkKrediDevirTx = new VdmkKrediDevirTx();
	        	VdmkKrediDevirTxId vdmkKrediDevirTxId = new VdmkKrediDevirTxId();
	        	vdmkKrediDevirTxId.setBasvuruNo(iMap.getBigDecimal(tableName,i,"BASVURU_NO"));
	        	vdmkKrediDevirTxId.setDevirNo(iMap.getBigDecimal("DEVIR_NO"));
	        	vdmkKrediDevirTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
	        	vdmkKrediDevirTx.setId(vdmkKrediDevirTxId);
	        	vdmkKrediDevirTx.setIslemTip(iMap.getString("ISLEM_TIPI"));
	        	vdmkKrediDevirTx.setDevirTarihi(iMap.getDate(tableName,i,"DEVIR_TARIHI"));
	        	vdmkKrediDevirTx.setHesapNo(iMap.getBigDecimal(tableName,i,"HESAP_NO"));
	        	vdmkKrediDevirTx.setHesapTakipDurum(iMap.getString(tableName,i,"HESAP_TAKIP_DURUM"));
	        	vdmkKrediDevirTx.setTaksitNo(BigDecimal.valueOf(0));
	        	vdmkKrediDevirTx.setYeniModulTurKod(iMap.getString(tableName,i,"YENI_MODUL_TUR_KOD"));
	        	vdmkKrediDevirTx.setYeniUrunSinifKod(iMap.getString(tableName,i,"YENI_URUN_SINIF_KOD"));
	        	vdmkKrediDevirTx.setYeniUrunTurKod(iMap.getString(tableName,i,"YENI_URUN_TUR_KOD"));
	        	vdmkKrediDevirTx.setIslemAciklama(iMap.getString(tableName,i,"ISLEM_ACIKLAMA"));
	        	session.saveOrUpdate(vdmkKrediDevirTx);	        	
	        }
	        session.flush();
	        iMap.put("TRX_NAME", "3254");
			return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}
	@GraymoundService("BNSPR_TRN3254_IMPORT_EXCELL")
	public static GMMap load3254(GMMap iMap) {	
		GMMap oMap = new GMMap();
		try{			
			byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
                if(workbook.getSheet(0).getColumns() < 1){
                    throw new GMRuntimeException(0, "Yanl�� Kolon Say�s�.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            String tableName="TERSDEVIR_TABLO";
            for (int j = 0; j + 1 < sheet.getRows(); j++) {
            	 String basvuruNo = sheet.getCell(0, (j+1)).getContents().trim();
            	 if(basvuruNo.length()==0) {
            		 break;
            	 }       
            	 String func = "{? = call pkg_trn3254.kredi_bilgi(?)}"; 
            	 Object inputValues[] = {
            		BnsprType.NUMBER,BigDecimal.valueOf(Long.parseLong(basvuruNo))	 
            	 };
            	 GMMap tMap = DALUtil.callOracleRefCursorFunction(func,tableName, inputValues);
            	 int ind = oMap.getSize(tableName);  
            	 int len = tMap.getSize(tableName);            	 
            	 if(len>0) {            		
            		 Set<?> keySet = (Set<?>) tMap.getMap(tableName,0).keySet();
            		 String keys[] = keySet.toArray(new String[keySet.size()]);
            		 Arrays.sort(keys);            		          		
            		 for(int i=0;i<len;i++) {            			          			            		 
            			 for(String key:keys) {
	            			 Object val= tMap.get(tableName,i, key);	            				            			
	            			 oMap.put(tableName,ind,key,val);	            			             			            			 
	            		 }
	            		 ind++;
            		 }
            	 } else {
            		 oMap.put(tableName,ind,"BASVURU_NO",basvuruNo);
            	 } 
            }
            if(oMap.getSize("TERSDEVIR_TABLO")==0) {
				 iMap.put("MESSAGE_NO", new java.math.BigDecimal(1614));
		         String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
		         throw new GMRuntimeException(0, message);
			}            
            return oMap;
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}
	@GraymoundService("BNSPR_TRN3254_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {	
		GMMap oMap = new GMMap();
		try {
		   String func = "{call pkg_trn3254.vdmk_tersdevir_yasaltakip(?)}";	
		   Object inputValues[] = {
		      BnsprType.NUMBER,iMap.getBigDecimal("ISLEM_NO")		   
		   };
		   Object outputValues[] = {};
		   DALUtil.callOracleProcedure(func, inputValues, outputValues);
		   oMap.put("MESSAGE", "3254 After Approval ��lemi Tamamland�");			
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}	
}
