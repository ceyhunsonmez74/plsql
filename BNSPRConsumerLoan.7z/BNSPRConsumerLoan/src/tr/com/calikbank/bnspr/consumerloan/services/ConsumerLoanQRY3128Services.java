package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3128Services {

	@GraymoundService("BNSPR_QRY3128_FILL_BAYI_ADI_COMBO")
	public static GMMap fillBayiAdiCombo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3128.fill_bayi_adi_combo(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "BAYI_ADI", rSet.getString(1), rSet.getString(2));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3128_FILL_CALISAN_ADI_COMBO")
	public static GMMap fillCalisanAdiCombo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3128.fill_calisan_adi_combo(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "CALISAN_ADI", rSet.getString(1), rSet.getString(2));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3128_GET_CALISAN_ADI")
	public static GMMap fillGetCalisanAdi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_RC3128.get_calisan_adi(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("BAYI_ADI"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "CALISAN_ADI", rSet.getString(1), rSet.getString(2));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3128_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_RC3128.sorgula(?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("BAYI_ADI"));
			stmt.setString(3, iMap.getString("TESVIK_YONTEMI"));

			if (iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else
				stmt.setDate(4, null);
			if (iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(5, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else
				stmt.setDate(5, null);

			stmt.execute();
			String tableName = "TESVIK_IZLEME";
			rSet = (ResultSet) stmt.getObject(1);
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "BAYI_KODU", rSet.getBigDecimal("BAYI_KODU"));
				oMap.put(tableName, i, "BAYI_ADI", rSet.getString("BAYI_ADI"));
				oMap.put(tableName, i, "KREDI_TUTAR", rSet.getBigDecimal("TESVIK_KRD_TUTAR"));
				oMap.put(tableName, i, "BAYI_TESVIK_TUTAR", rSet.getBigDecimal("BAYI_TESVIK_TUTAR") != null ? rSet.getBigDecimal("BAYI_TESVIK_TUTAR") : BigDecimal.ZERO);
				oMap.put(tableName, i, "KURUM_TESVIK_TUTAR", rSet.getBigDecimal("BAYI_TESVIK_TUTAR") != null ? rSet.getBigDecimal("BAYI_TESVIK_TUTAR") : BigDecimal.ZERO);
				oMap.put(tableName, i, "BAYI_STATUSU", rSet.getString("BAYI_STATUSU"));
				oMap.put(tableName, i, "BAGLI_BOLGE", rSet.getString("BAGLI_BOLGE"));
				i++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3128_DETAY_SORGULA")
	public static GMMap detaySorgula(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_RC3128.detay_sorgula(?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("BAYI_ADI"));
			stmt.setString(3, iMap.getString("TESVIK_YONTEMI"));

			if (iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else
				stmt.setDate(4, null);
			if (iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(5, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else
				stmt.setDate(5, null);

			stmt.execute();
			String tableName = "SORGU_DETAY";
			rSet = (ResultSet) stmt.getObject(1);
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "BAYI_KODU", rSet.getBigDecimal("BAYI_KODU"));
				oMap.put(tableName, i, "KREDI_TUTARI", rSet.getBigDecimal("KREDI_TUTARI"));
				oMap.put(tableName, i, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
				oMap.put(tableName, i, "TESVIK_TUTAR", rSet.getBigDecimal("TESVIK_TUTAR"));
				oMap.put(tableName, i, "ISLEM_TAR", rSet.getDate("ISLEM_TAR"));
				oMap.put(tableName, i, "ODEME_TARIHI", rSet.getDate("ODEME_TARIHI"));
				oMap.put(tableName, i, "TAKSIT_NO", rSet.getBigDecimal("TAKSIT_NO"));
				oMap.put(tableName, i, "TESVIK_TAKSITI", rSet.getBigDecimal("TESVIK_TAKSITI"));
				i++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3128_CALISANA_GORE_BAYI_BUL")
	public static GMMap calisanaGoreBayiBul(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (iMap.getString("BAYI_ADI").compareTo("-1") == 0 && iMap.getString("CALISAN_ADI").compareTo("-1") != 0 && iMap.getString("CALISAN_ADI").compareTo("-2") != 0) {
			oMap.put("BUL_BULMA", "BUL");
		}
		if (iMap.getString("BAYI_ADI").compareTo("-2") == 0 && iMap.getString("CALISAN_ADI").compareTo("-1") != 0 && iMap.getString("CALISAN_ADI").compareTo("-2") != 0) {
			oMap.put("BUL_BULMA", "BUL");
		}
		return oMap;
	}
}
