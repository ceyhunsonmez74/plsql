package tr.com.calikbank.bnspr.consumerloan.models.socialscore;

public class DeviceInformation {
	private Platform Platform;

    private String Device;

    private ISPAddress ISPAddress;

    private Browser Browser;

    public Platform getPlatform ()
    {
        return Platform;
    }

    public void setPlatform (Platform Platform)
    {
        this.Platform = Platform;
    }

    public String getDevice ()
    {
        return Device;
    }

    public void setDevice (String Device)
    {
        this.Device = Device;
    }

    public ISPAddress getISPAddress ()
    {
        return ISPAddress;
    }

    public void setISPAddress (ISPAddress ISPAddress)
    {
        this.ISPAddress = ISPAddress;
    }

    public Browser getBrowser ()
    {
        return Browser;
    }

    public void setBrowser (Browser Browser)
    {
        this.Browser = Browser;
    }
}
