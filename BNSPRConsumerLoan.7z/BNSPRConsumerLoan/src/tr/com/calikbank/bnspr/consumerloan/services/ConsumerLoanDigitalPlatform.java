package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrediOtoYapilandirma;
import tr.com.aktifbank.bnspr.dao.GnlKaraListeGercek;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.KmhTanim;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanDigitalPlatform {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanDigitalPlatform.class);
	
	@GraymoundService("BNSPR_DIGITAL_PLATFORM_GET_KREDI_BASVURU_LIST")
	public static GMMap getKrediBasvuruList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BK_INT.bir_kredi_basvuru_list(?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TUR"));
			stmt.setDate(i++, iMap.get("ILK_TARIH") != null ? new Date(iMap.getDate("ILK_TARIH").getTime()) : null);
			stmt.setDate(i++, iMap.get("SON_TARIH") != null ? new Date(iMap.getDate("SON_TARIH").getTime() + 86399999) : null); // 86400000
																																// =
																																// miliseconds
																																// in
																																// a
																																// day
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("DURUM") != null ? (iMap.getString("DURUM").isEmpty() ? null : iMap.getString("DURUM")) : null);
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("KANAL"));
			stmt.setString(i++, iMap.getBoolean("ILK_GIRIS") ? "H" : "E");
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(8);
			oMap.put("NO_CREDIT", "H".equals(stmt.getString(11)));
			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_DIGITAL_PLATFORM_GET_KREDI_BASVURU_DETAY")
	public static GMMap getKrediBasvuruDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BK_INT.bir_kredi_basvuru_detay_list(?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("KANAL"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			GMServerDatasource.close(rSet);
			rSet = (ResultSet) stmt.getObject(3);
			oMap.putAll(DALUtil.rSetMap(rSet));

			String statusCode = oMap.getString("DURUM_KODU");
			if ("EVRAKSIZ".equals(statusCode) || "KUL".equals(statusCode) || "BELGE".equals(statusCode) || "CEPTE".equals(statusCode) || "KULONAY".equals(statusCode)) {
				i = 1;
				GMServerDatasource.close(stmt);
				stmt = conn.prepareCall("{ ? = call PKG_BK_INT.bir_kredi_odeme_plan(?)}");
				stmt.registerOutParameter(i++, -10);
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt.execute();
				GMServerDatasource.close(rSet);
				rSet = (ResultSet) stmt.getObject(1);
				oMap.putAll(DALUtil.rSetResults(rSet, "PAYMENT_PLAN"));
				oMap.put("SON_ODEME_PLANI", true);
			}
			else if (!("RED".equals(statusCode) || "IPTAL".equals(statusCode))) {
				iMap.put("FAIZ_ORANI", oMap.get("FAIZ_ORANI"));
				iMap.put("KREDI_TURU", oMap.get("KREDI_TUR"));
				iMap.put("KAMPANYA_KODU", oMap.get("KAMP_KOD"));
				iMap.put("KANAL_KOD", oMap.get("KANAL_KODU"));
				iMap.put("DOVIZ_KOD", "TRY");
				iMap.put("KREDI_TUTARI", oMap.get("BASVURU_TUTARI"));
				iMap.put("KREDI_VADE", oMap.get("VADE"));
				iMap.put("ODEME_TIP_KOD", oMap.get("ODEME_TIP_KOD"));
				iMap.put("ODEME_TIP_PERIYOD", oMap.get("ODEME_TIP_PERIYOD"));
				iMap.put("ODEME_TIP_TUTAR", oMap.get("ODEME_TIP_TUT"));
				iMap.put("ODEME_TIP_ORAN", oMap.get("ODEME_TIP_ORAN"));
				iMap.put("ODEME_TIP_VADE", oMap.get("ODEME_TIP_VADE"));
				iMap.put("KATKI_PAYI", oMap.get("KATKI_PAYI"));
				iMap.put("KRD_TUR_ALT_KOD", oMap.get("KREDI_ALT_TUR"));
				iMap.put("KRD_TUR_ALT_KOD2", oMap.get("KREDI_ALT_TUR2"));
				iMap.put("KRD_TUR_ALT_KOD2", oMap.get("KREDI_ALT_TUR2"));
				oMap.put("PAYMENT_PLAN", GMServiceExecuter.execute("BNSPR_QRY3135_GET_RECORD_FILL_LIST", iMap).get("RESULTS"));
				oMap.put("SON_ODEME_PLANI", false);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_DIGITAL_PLATFORM_GET_KREDI_ODEME_LIST")
	public static GMMap getKrediOdemeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BK_INT.bir_kredi_odeme_list( ?, ?, ?)}");

			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("KANAL"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
	}

	@GraymoundService("BNSPR_DIGITAL_PLATFORM_GET_KREDI_BASVURU_ODEME_DETAY")
	public static GMMap getKrediBasvuruOdemeDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BK_INT.bir_kredi_odenecek_tutar_bilgi(?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_NO"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.execute();

			oMap.put("MIN_TUTAR", stmt.getBigDecimal(3));
			oMap.put("TUTAR", stmt.getBigDecimal(4));
			oMap.put("INDIRIM_TUTARI", stmt.getBigDecimal(5));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			//
		}
	}

	@GraymoundService("BNSPR_DIGITAL_PLATFORM_KREDI_TAKSIT_ODEME")
	public static GMMap krediTaksitOde(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_BK_INT.bir_kredi_taksit_odeme(?, ?, ?, ?)}");

			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIKTAR"));
			stmt.execute();

			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_DIGITAL_PLATFORM_KARALISTE_KONTROL")
	public static GMMap karalisteKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		List<GnlKaraListeGercek> list=null;
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			if(iMap.get("TC_KIMLIK_NO") != null){
				list = session.createQuery("from GnlKaraListeGercek where tcknNo= '"+iMap.get("TC_KIMLIK_NO") +"' " +
						"and ((kayitKategorisi=1 AND tarafBilgisi in (2,3)) or (kayitKategorisi=2 AND tarafBilgisi =10) or (kayitKategorisi=15 AND tarafBilgisi=30)) " +
						"and kayitDurum='A'").list();
			} else if(iMap.get("PASAPORT_NO") != null){
				list = session.createQuery("from GnlKaraListeGercek where pasaportNo= '"+iMap.get("PASAPORT_NO") +"' " +
						"and ((kayitKategorisi=1 AND tarafBilgisi in (2,3)) or (kayitKategorisi=2 AND tarafBilgisi =10) or (kayitKategorisi=15 AND tarafBilgisi=30)) " +
						"and kayitDurum='A'").list();
			}
			
			if(list != null && list.size()>0){
				oMap.put("RESULT", "E");
			}else{
				oMap.put("RESULT", "H");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * DESC    : Risk Sorgulama Servisi
	 *
	 * @param iMap (GMMap)
	 *          MUSTERI_NO  TC_KIMLIK_NO
	 *
	 * @return oMap (GMMap)
	 *      RESPONSE
	 *      RESPONSE_DATA
	 *      	MUSTERI RISK BILGILERI (BIREYSEL, VDMK, TASFIYE)
	 */
	@GraymoundService("BNSPR_DIGITAL_PLATFORM_RISK_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			
			if (StringUtil.isEmpty(iMap.getString("MUSTERI_NO"))) {
				if (StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))) {
					throw new GMRuntimeException(0, "M��teri No / Tc kimlik no dan birisi dolu olmal�d�r.");
				}
				else {
					String musteriNo = (String) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.Musteri_Varmi_TCKN(?)}", Types.VARCHAR, iMap.getString("TC_KIMLIK_NO"));
					if (musteriNo == null) {
						throw new GMRuntimeException(0, "Tc Kimlik Noya ait m��teri bulunamad�.");
					}
					else {
						iMap.put("MUSTERI_NO", musteriNo);
					}
				}
			}
			
			//iMap.put("MUSTERI_NO", 1312225);
			
			GMMap rMap = new GMMap();
			
			/** Bireysel Risk **/
			BigDecimal toplamBireyselRisk = BigDecimal.ZERO;
			BigDecimal toplamFaizsizRisk = BigDecimal.ZERO;
			
			List<BirBasvuru> list = null;
			Session session = DAOSession.getSession("BNSPRDal");
			if(!StringUtil.isEmpty(iMap.getString("MUSTERI_NO"))){
				list = session.createCriteria(BirBasvuru.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).list();
			}else{
				list = session.createCriteria(BirBasvuru.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).list();
			}
			
			

			BigDecimal sumTaksitTutari = new BigDecimal(0);
			BigDecimal taksitTutari = new BigDecimal(0);
			
			
			for (BirBasvuru birBasvuru : list) {
				
				iMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
				taksitTutari = GMServiceExecuter.call("BNSPR_QRY3135_GET_RECORD_FILL_LIST", iMap).getBigDecimal("SUM_TAKSIT_TUTAR");
				
				if( "E".equals(birBasvuru.getFaizsizFinansman()) )
					toplamFaizsizRisk = toplamFaizsizRisk.add(taksitTutari);
				else
					toplamBireyselRisk = toplamBireyselRisk.add(taksitTutari);

			}
			oMap.put("TOPLAM_BIREYSEL_RISK", toplamBireyselRisk);
			oMap.put("TOPLAM_FAIZSIZ_RISK", toplamFaizsizRisk);
			
			
			/** KDH Kapama Bakiyesi **/
			List<?> kdhList = null;
			kdhList = session.createCriteria(KmhTanim.class)
					.add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO")))
					.add(Restrictions.not(Restrictions.in("durum", new String[] {"KAPALI","T","Y","YT"})))
					.list();
			//Degerleri al
			BigDecimal kdhKapamaBakiye = BigDecimal.ZERO;
			KmhTanim kmhTanim = null;
			for (Object o : kdhList) {
				kmhTanim = (KmhTanim) o;
				rMap.clear();
				rMap.put("HESAP_NO", kmhTanim.getHesapNo());
				rMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3290_KMH_KAPAMA_BAKIYESI_HESAPLA", rMap));
				kdhKapamaBakiye = kdhKapamaBakiye.add(rMap.getBigDecimal("KAPAMA_BAKIYESI"));
			}
			oMap.put("TOPLAM_KDH_RISK", kdhKapamaBakiye);
			
					
					
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_DIGITAL_PLATFORM_KREDI_ERKEN_KAPAMA")
	public static GMMap krediErkenKapama(GMMap iMap) {
		try {
			Object inputs [] = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.NUMBER, iMap.getBigDecimal("HESAP_NO") };
			Object outputs [] = { BnsprType.NUMBER, "ISLEM_NO" };
			
			GMMap resultMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_BK_INT.bir_kredi_erken_kapama(?, ?, ?)}", inputs, outputs);
			
			GMServiceExecuter.call("BNSPR_TRN3133_AFTER_APPROVAL", resultMap);
			
			return new GMMap().put("RESPONSE", 2);
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_DIGITAL_PLATFORM_TAKSIT_OTELEME")
	public static GMMap basvuruTaksitOteleme(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap basvuruList = new GMMap();
		String queryResult,kanalKodu,borcTransferi = StringUtils.EMPTY;
		BigDecimal maxId = BigDecimal.ZERO;
		BigDecimal basvuruNo = BigDecimal.ZERO;
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {			
			queryResult = DALUtil.getResult("select max(id) from bnspr.bir_kredi_oto_yapilandirma");
			maxId = new BigDecimal(queryResult).add(BigDecimal.ONE);
			
			iMap.put("KANAL","CC");
	        basvuruList = GMServiceExecuter.call("BNSPR_DIGITAL_PLATFORM_GET_KREDI_BASVURU_LIST", iMap);	        
	        for(int i = 0; i < basvuruList.getSize("RESULTS"); i++){
                try {
                	basvuruNo = basvuruList.getBigDecimal("RESULTS", i, "BASVURU_NO");
                	kanalKodu = basvuruList.getString("RESULTS", i, "KANAL_KODU");                	
                	borcTransferi = basvuruList.getString("RESULTS", i, "BORC_TRANSFERI_EH");
                	
                    BirKrediOtoYapilandirma birKrediOtoYapilandirma = new BirKrediOtoYapilandirma();
                    birKrediOtoYapilandirma.setBasvuruNo(basvuruNo);
                    birKrediOtoYapilandirma.setDurumAciklama(StringUtils.EMPTY);
                    birKrediOtoYapilandirma.setDurumKod("0");
                    birKrediOtoYapilandirma.setGerekceKod("15");
                    birKrediOtoYapilandirma.setId(maxId);
                    birKrediOtoYapilandirma.setOtelemeAySayisi(new BigDecimal(3));


                    if((StringUtils.isNotEmpty(kanalKodu) && kanalKodu.equalsIgnoreCase("7")) || (
                    		StringUtils.isNotEmpty(borcTransferi) && borcTransferi.equalsIgnoreCase("E"))){
                    	birKrediOtoYapilandirma.setEkVade(new BigDecimal(3));
                    }
                    else{
                    	birKrediOtoYapilandirma.setEkVade(new BigDecimal(0));
                    }
                    
                    session.saveOrUpdate(birKrediOtoYapilandirma);
                    
                } catch (Exception e) {
                    logger.error("BirKrediOtoYapilandirma oteleme hatasi: " + e.getMessage() + " Basvuru No: " +  basvuruNo);
                }
                maxId = maxId.add(BigDecimal.ONE);
            }
	        session.flush();
	        
	        oMap.put("RETURN_DESC" , basvuruList.getSize("RESULTS") + " adet basvuru icin BirKrediOtoYapilandirma oteleme islemi tamamlandi.");
		}
		catch (GMRuntimeException e){
	           oMap.put("RETURN_DESC" , e.getMessage());
	    }
		finally {
			session.close();
		}
	    return oMap;
	}
	
	@GraymoundService("BNSPR_DIGITAL_PLATFORM_KAPALI_BASVURU_LIST")
	public static GMMap kapaliBasvuruList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			sMap = GMServiceExecuter.call("BNSPR_QRY3225_BASVURU_LIST", iMap);
			if(sMap.get("BASVURU_LIST") != null && sMap.getSize("BASVURU_LIST") > 0){
				oMap.put("BASVURU_LIST", sMap.get("BASVURU_LIST"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_DIGITAL_PLATFORM_GET_KAPAMA_YAZISI")
	public static GMMap getKapamaYazisi(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			GMMap reportMap = GMServiceExecuter.call("BNSPR_QRY3225_GET_REPORTS", iMap);
			JasperPrint jasperPrint = (JasperPrint) reportMap.get("REPORT");

			String fileName = iMap.getBigDecimal("BASVURU_NO") + reportMap.getString("BASVURU_PATH") + "_" + System.currentTimeMillis() + ".pdf";
			String fileNamePath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;

			JRPdfExporter pdfexporter = new JRPdfExporter();
			pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileNamePath);
			pdfexporter.exportReport();

			oMap.put("FILE_NAME", fileName);
			oMap.put("FILE_BYTE_ARRAY", FileUtil.readFileToByteArray(new File(fileNamePath)));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_DIGITAL_PLATFORM_GET_CL_DASHBOARD_INFO")
	public static GMMap getClDashboardInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;		
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			if (StringUtil.isEmpty(iMap.getString("MUSTERI_NO"))) {
				if (StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))) {
					throw new GMRuntimeException(0, "M��teri No / Tc kimlik no dan birisi dolu olmal�d�r.");
				}
				else {
					String musteriNo = (String) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.Musteri_Varmi_TCKN(?)}", Types.VARCHAR, iMap.getString("TC_KIMLIK_NO"));
					if (musteriNo != null) {
						iMap.put("MUSTERI_NO", musteriNo);
					}
				}
			}
		
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BK_INT.bir_kredi_dashboard_info(?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.registerOutParameter(i++, -10);
			
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(2);
			oMap.putAll(DALUtil.rSetMap(rSet));
			
			GMServerDatasource.close(rSet);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			//
		}
	}
}
