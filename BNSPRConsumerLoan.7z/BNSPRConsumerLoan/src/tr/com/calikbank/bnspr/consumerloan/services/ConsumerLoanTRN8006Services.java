package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBelgeHavuzPr;
import tr.com.aktifbank.bnspr.dao.BirBelgeHavuzPrTx;
import tr.com.aktifbank.bnspr.dao.BirBelgeHavuzPrTxId;
import tr.com.aktifbank.bnspr.dao.BirKrediYetkiLimitPr;
import tr.com.aktifbank.bnspr.dao.BirKrediYetkiLimitPrTx;
import tr.com.aktifbank.bnspr.dao.BirKrediYetkiLimitPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBelgeMatrisPrTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8006Services {

	public static final String TABLE_NAME = "TBL_KULLANICI_SEC";

	@GraymoundService("BNSPR_TRN8006_GET_INFO")
	public static GMMap getInfoTRN8006(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> listBirBelgeHavuz = null;
		BigDecimal rol = iMap.getBigDecimal("ROL");
		String rolAciklama = null;
		String kod = null;
		BigDecimal atamaDurumu = new BigDecimal(0);
		int row = 0;

		try {
			if ((iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI")) || (iMap.getString("ACTION").equals("EDIT"))) {
				listBirBelgeHavuz = (List<?>) session.createCriteria(BirBelgeHavuzPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
				rol = ((BirBelgeHavuzPrTx) listBirBelgeHavuz.get(0)).getRol();
				for (Iterator<?> iterator = listBirBelgeHavuz.iterator(); iterator.hasNext(); row++) {
					if ((iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI")) || (iMap.getString("ACTION").equals("EDIT"))) {
						BirBelgeHavuzPrTx birBelgeHavuzTx = (BirBelgeHavuzPrTx) iterator.next();

						oMap.put(TABLE_NAME, row, "KOD", birBelgeHavuzTx.getId().getKod());
						oMap.put(TABLE_NAME, row, "AD_SOYAD", birBelgeHavuzTx.getAdSoyad());
						oMap.put(TABLE_NAME, row, "ATAMA_YAPILABILIR_MI", birBelgeHavuzTx.getAtamaYapilabilir());
					}
				}
			}
			else {
				oMap.putAll(getUsers(rol));
				for (int i = 0; i < oMap.getSize(TABLE_NAME); i++) {
					kod = oMap.getString(TABLE_NAME, i, "KOD");
					listBirBelgeHavuz = (List<?>) session.createCriteria(BirBelgeHavuzPr.class).add(Restrictions.eq("kod", kod)).add(Restrictions.eq("rol", rol)).list();
					if (listBirBelgeHavuz.size() > 0) {
						atamaDurumu = ((BirBelgeHavuzPr) listBirBelgeHavuz.get(0)).getAtamaYapilabilir();
						if (atamaDurumu != new BigDecimal(0)) {
							oMap.put(TABLE_NAME, i, "ATAMA_YAPILABILIR_MI", atamaDurumu);
						}
					}
				}

			}
			rolAciklama = LovHelper.diLov(rol, "8005/LOV_ROL", "TANIM");

			oMap.put("ROL", rol);
			oMap.put("ROL_ACIKLAMA", rolAciklama);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	private static GMMap getUsers(BigDecimal rol) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN8006.all_user_from_rol(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, rol);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, TABLE_NAME);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN8006_SAVE")
	public static Map<?, ?> saveTRN8006(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> listBirBelgeHavuz = (List<?>) session.createCriteria(BirBelgeHavuzPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = listBirBelgeHavuz.iterator(); iterator.hasNext();) {
				BirBelgeHavuzPrTx birBelgeHavuz = (BirBelgeHavuzPrTx) iterator.next();
				session.delete(birBelgeHavuz);
			}
			session.flush();

			String tableName = "TBL_KULLANICI_SEC";
			ArrayList<?> list = (ArrayList<?>) iMap.get(tableName);
			if (list.size() > 0) {
				for (int i = 0; i < list.size(); i++) {
					BirBelgeHavuzPrTx birBelgeHavuzTx = new BirBelgeHavuzPrTx();
					BirBelgeHavuzPrTxId id = new BirBelgeHavuzPrTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setKod(iMap.getString(tableName, i, "KOD"));
					birBelgeHavuzTx.setId(id);
					birBelgeHavuzTx.setRol(iMap.getBigDecimal("ROL"));
					birBelgeHavuzTx.setAdSoyad(iMap.getString(tableName, i, "AD_SOYAD"));
					birBelgeHavuzTx.setAtamaYapilabilir(iMap.getBigDecimal(tableName, i, "ATAMA_YAPILABILIR_MI"));
					session.save(birBelgeHavuzTx);
				}
			}
			session.flush();

			iMap.put("TRX_NAME", "8006");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
