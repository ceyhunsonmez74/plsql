package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAdkBasvuru;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKartBilgi;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKartBilgiTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKonsolidasyon;
import tr.com.aktifbank.bnspr.dao.BirKrediOdemeplaniGunTx;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruSozlesmeTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTx;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.dao.GnlPersonel;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


/** Bireysel krediler birden fazla yerde kullanilan servislerin ortak bir yerde tutulmasini saglar
 * @author murat.el
 * @since TY-3806
 */
public class ConsumerLoanCommonServices {
	
	private final static Logger LOGGER = Logger.getLogger(ConsumerLoanCommonServices.class);
	protected static Configurator conf = Configurator.createConfiguratorFromProperties ("configuration/aktifbank-int-dys.properties");
	private final static int CARD_HOLDER_NAME_LENGTH = 26;
//	GMMap sorguMap = new GMMap();
//	sorguMap.put(Constants.BASVURU_NO, null);
//	sorguMap.put("HATA_VERILSIN_MI", Constants.HAYIR);
//	sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CONSUMERLOAN_COMMON_RED_SMS_GONDER", sorguMap));
		
	/**Basvuru red edildiginde musteriye bilgilendirme smsi gonderilir. 
	 * Sms icerigi basvuru kanalinin PTT olup olmamasina gore farklilik gosterir.<br>
	 * @author murat.el
	 * @since TY-3806
	 * @param iMap - Basvuru bilgisi<br>
	 *        <li>BASVURU_NO - Kredi basvuru numarasi
	 *        <li>HATA_VERILSIN_MI - Hata verilsin mi? (E:Evet|H:Hayir)
	 * @return oMap - Sonuc bilgisi<br>
	 * 		  <li>RESPONSE - Islem sonuc kodu (0:Basarisiz|2:Basarili)
	 * 		  <li>RESPONSE_DATA - Islem sonuc aciklamasi
	 * 		  <li>SMS_LOG_ID - Sms bilgisine ait log idsi
	 * 		  <li>SMS_RESULT - Sms sonucu
	 */
	@GraymoundService("BNSPR_CONSUMERLOAN_COMMON_RED_SMS_GONDER")
	public static GMMap redSmsGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
		BigDecimal basvuruNo = iMap.getBigDecimal(Constants.BASVURU_NO);

		try {
			//Sms icerigi ve vep telefonunu al
			GMMap sorguMap = new GMMap();
			sorguMap.put(Constants.BASVURU_NO, basvuruNo);
			sorguMap.put("ISLEM_TIPI", "RED");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CONSUMERLOAN_COMMON_SMS_BILGI_AL_BY_BASVURU_NO", sorguMap));
            String mesaj = sorguMap.getString("MESAJ");
            String cepNo = sorguMap.getString("CEP_NO");
            //Kontrol
            if (StringUtils.isBlank(mesaj) || StringUtils.isBlank(cepNo)) {
            	oMap.put(Constants.RESPONSE_DATA, basvuruNo.toString() + " nolu basvuruya ait sms bilgileri alinamadi.");
            	return oMap;
            }
            //Sms gonder
            sorguMap.clear();
			sorguMap.put("MSISDN", cepNo);
			sorguMap.put("CONTENT", mesaj);
			sorguMap.put("HEADER", "AKTIFBANK");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", sorguMap));
			//Kontrol
			if (AkustikConstants.RESPONSE_SUCCESS.equals(Constants.RESPONSE)) {
				oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
				oMap.put(Constants.RESPONSE_DATA, "Islem Basarili");
				oMap.put("SMS_LOG_ID", sorguMap.get("BNSPR_LOG_ID"));
				oMap.put("SMS_RESULT", sorguMap.get("RESULT"));
			} 
			else {
				oMap.put(Constants.RESPONSE_DATA, basvuruNo.toString() + " nolu basvuruya sms gonderimi yapilirken hata aldi.");
			}
		}
		catch (Exception e) {
			if (Constants.EVET.equals(iMap.getString("HATA_VERILSIN_MI"))) {
				throw ExceptionHandler.convertException(e);
			} else {
				oMap.put(Constants.RESPONSE_DATA, e.getMessage());
			}
		}

		return oMap;
	}
	
	//Yeni bir islem tipi geldiginde javadoca ekleyin.
	/**Basvuruya ait gonderilecek smsin icerik ve numara bilgisini bulur.<br>
	 * @author murat.el
	 * @since TY-3806
	 * @param iMap - Basvuru bilgisi<br>
	 *        <li>BASVURU_NO - Kredi basvuru numarasi
	 *        <li>ISLEM_TIPI - Hangi islem icin sms bilgisi alinacak? (RED:Basvuru red)
	 * @return oMap - Sonuc bilgisi<br>
	 * 		  <li>MESAJ - Sms icerigi
	 * 		  <li>MESAJ - Smsin gonderilecegi numara
	 */
	@GraymoundService("BNSPR_CONSUMERLOAN_COMMON_SMS_BILGI_AL_BY_BASVURU_NO")
	public static GMMap smsBilgiAlByBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Sms icerigi ve vep telefonunu al
			conn = DALUtil.getGMConnection();

			query = "{ call PKG_BIREYSEL_UTILS.SMS_BILGI_AL(?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("ISLEM_TIPI"));
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.registerOutParameter(4, Types.VARCHAR);
            stmt.execute();
            //Bilgileri al
            oMap.put("MESAJ", stmt.getString(3));
            oMap.put("CEP_NO", stmt.getString(4));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	/** Verilen hata kodu ve parametrelerle ekrana hata mesaji verir.
	 * @author murat.el
	 * @since TY-3806
	 * @param errorCode - GNL_Mesaj_Pr tablosunda tanimli olan Hata Kodu
	 * @param parameters - Hata aciklamasinda yer alacak parametreler. Max.:4
	 */
	public static void raiseGMError(String errorCode, Object...parameters) {
		HashMap<String, Object> myMap = new HashMap<String, Object>();
        myMap.put("HATA_NO", errorCode);
        
        if (parameters != null && parameters.length > 0) {
        	int index = 0;
        	while (index < parameters.length) {
        		 myMap.put("P" + (index+1), parameters[index]);
        		 index++;
			}
        }
        
        try {
        	String errorMessage =
        			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap).get("ERROR_MESSAGE").toString();
        	throw new GMRuntimeException(0, errorMessage);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
	}
	/**
	 * Basvru icin param text icinde kayitlari almaya yarar
	 * 
	 * @param kod 
	 * paramText kodu
	 * 
	 * @param listName 
	 * geri donen listenin adi
	 * */
	public final static GMMap getParamTextLists(String kod, String listName) throws SQLException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("SELECT KEY1 CODE,TEXT DESCRIPTION, KEY2 FROM v_ml_gnl_param_text WHERE kod = ?");
			stmt.setString(1, kod);
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, listName);
		} catch (SQLException e) {
			e.printStackTrace();
			ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_CL_DEALER_GET_APPLICATION_STATUS_LIST")
	public static GMMap getStatusList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("Select key1 code, text From V_ML_GNL_PARAM_TEXT t Where t.kod  = upper('ONAY_STATU_KOD') and exists (select 1 from bir_basvuru where durum_kodu=t.KEY1 and  ((durum_kodu!='BASVURU' ) or (t.Key2=aksiyon_kod or aksiyon_kod is null)))");
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "APPLICATION_STATUS_LIST");
		} catch (SQLException e) {
			ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CL_DEALER_GET_CANCEL_REASON_LIST")
	public static GMMap getIptalGerekceListesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = ConsumerLoanCommonServices.getParamTextLists("BIR_BASVURU_IPTAL_GEREKCE", "CANEL_REASON_LIST");
		} catch (SQLException e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_DEALER_GET_AGR_SALES_CHANNEL_LIST")
	public static GMMap getAgricultureSalesChannelList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap = ConsumerLoanCommonServices.getParamTextLists("TARIM_SATIS_KANAL_KOD", "AGR_SALES_CHANNEL_LIST");
		} catch (SQLException e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_DEALER_PRODUCT_BOUGHT_FOR_LIST")
	public static GMMap getProductBoughtForList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("SELECT KEY1 CODE,TEXT DESCRIPTION FROM v_ml_gnl_param_text WHERE kod = ? and nvl(key3,'A') != 'P'");
			stmt.setString(1, "TESLIMAT_KISI_KOD");
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "PRODUCT_BOUGHT_FOR_CODE_LIST");
		} catch (SQLException e) {
			ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_DEALER_SECOND_IDENTITY_LIST")
	public static GMMap getSecondIdentityList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			//second_identity_code_list
			oMap = ConsumerLoanCommonServices.getParamTextLists("KIMLIK2_TIP_KOD", "SECOND_IDENTITY_CODE_LIST");
		} catch (SQLException e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_GET_CAMPAIGN_LIST")
	public static GMMap getCampaignList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			int i=0;
			Object[] outputValues = new Object[6];
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "KAMPANYA_LIST";
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "SIGORTA_LIST";
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "RISKLI_URUN_LIST";
			
			String func = "{call pkg_kampanya.get_tam_kampanya_listesi(?,?,?)}";
			
			oMap = (GMMap) DALUtil.callOracleProcedure(func, new Object [0], outputValues);
		}
		
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_GET_RESIDENCE_STATUS_LIST")
	public static GMMap getResidenceStatusList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			//second_identity_code_list
			oMap = ConsumerLoanCommonServices.getParamTextLists("IKAMET_DURUM_KOD", "RESIDENCE_STATUS_CODE_LIST");
		}
		
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_CL_PRODUCT_LIST")
	public static GMMap getProductList(GMMap iMap) throws SQLException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select MALNO ID,UST_MALNO PARENT_ID, AD NAME from bnspr.bir_bayi_mal_tanim");
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "PRODUCT_LIST");
		} catch (SQLException e) {
			e.printStackTrace();
			ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	/*@GraymoundService("BNSPR_CL_CAMPAIGN_INSURANCE_LIST")
	public static GMMap getCampaignInsuranceList(GMMap iMap) throws SQLException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("SELECT KEY1 CODE,TEXT DESCRIPTION, CASE KEY2 WHEN '1' THEN 'OLUMLU' WHEN '2' THEN 'OLUMSUZ' END TYPE, KEY3 STATUS FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and (KEY2 = '1' OR KEY2 = '2' ) ORDER BY KEY1");
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "OPINION_CODE_LIST");
		} catch (SQLException e) {
			e.printStackTrace();
			ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}

		return oMap;
	}*/
	
	@GraymoundService("BNSPR_CL_GET_OPINION_LIST")
	public static GMMap getOpinionList(GMMap iMap) throws SQLException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("SELECT KEY1 CODE,TEXT DESCRIPTION, CASE KEY2 WHEN '1' THEN 'OLUMLU' WHEN '2' THEN 'OLUMSUZ' END TYPE, KEY3 STATUS FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and (KEY2 = '1' OR KEY2 = '2' ) ORDER BY KEY1");
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "OPINION_CODE_LIST");
		} catch (SQLException e) {
			e.printStackTrace();
			ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_GET_PAYMENT_TYPES")
	public static GMMap getPaymentTypes(GMMap iMap) throws SQLException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select KOD CODE,ACIKLAMA DESCRIPTION from bir_odm_grp_pr");
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "INTEREST_PAYMENT_TYPE_LIST");
		} catch (SQLException e) {
			e.printStackTrace();
			ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
/*	
	@GraymoundService("BNSPR_CL_DEALER_INITIALIZE")
	public static GMMap dealerInitialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
		oMap.put("KANAL_ALT_KOD", iMap.get("KANAL_ALT_KOD"));
		iMap.put("KANAL_KODU", oMap.getString("KANAL_KOD"));
		iMap.put("KANAL_ALT_KODU", oMap.getString("KANAL_ALT_KOD"));
		iMap.put("SATICI_KOD", oMap.getString("KANAL_ALT_KOD"));
		iMap.put("SATICI_KODU", oMap.getString("KANAL_ALT_KOD"));
		iMap.put("DOVIZ_KODU", "TRY");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CINSIYET_TURLERI", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MEDENI_HAL_TURLERI", iMap));
	//	oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DOVIZ_CINSLERI", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CALISMA_SEKILLERI", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MESLEKLER", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ADLARI", iMap));

		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILLER", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OGRENIM_DURUMLARI", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_FAALIYET_ALANLARI", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ISYERI_MULKIYET_TURLERI", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ILLERI", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_IKAMET_TURLERI", iMap));
		//oMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BAYI_IL_ILCE_KOD", iMap));
		iMap.put("IL_KODU", oMap.getString("BAYI_IL_KOD"));
		iMap.put("IL_KOD", oMap.getString("BAYI_IL_KOD"));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILCELER", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TELEFON_KOD", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OLUMLU_GORUS", iMap));
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OLUMSUZ_GORUS", iMap));
		
		
		return oMap;
		
	}*/
	/** Verilen deger nullsa default degeri atar degilse kendisini dondurur.
	 * @since TY-3875
	 * @author murat.el
	 * @param value - Kontrol edilecek deger
	 * @param defaultValue - Kontrol edilen deger nullsa donecek sonuc
	 */
	public static <T> T nvl(T value, T defaultValue) {
		if (value instanceof String) {
			return StringUtils.isBlank((String) value) ? defaultValue : value;
		}

		return value == null ? defaultValue : value;
	}
	
	@GraymoundService("BNSPR_CL_TOPLU_KPS_GET_LIST")
	public static GMMap topluKPSGetList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Object[] inputValues = new Object[2];
			String func = "{? = call pkg_bireysel.topluKpsYapilacaklar}";

			oMap= DALUtil.callOracleRefCursorFunction(func, "KPS_LIST");
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_CL_GET_DELAER_INFO")
	public static GMMap getDealerInfo(GMMap iMap) throws Exception {
		
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {

			BirSatici satici = (BirSatici) session.get(BirSatici.class, iMap.getBigDecimal("SATICI_KOD"));
			BirSaticiTahsis saticiTahsis = (BirSaticiTahsis) session.get(BirSaticiTahsis.class, iMap.getBigDecimal("SATICI_KOD"));

			if (satici != null) {
				oMap.put("BAYI_KOD", satici.getKod());
				oMap.put("BAYI_ADI", satici.getSaticiAdi());
				oMap.put("BAYI_TEL_ALANKOD", satici.getAlanKodTel());
				oMap.put("BAYI_TEL", satici.getTelNo());
				oMap.put("BAYI_ADRES", satici.getAdres());
				oMap.put("SATICI_TIPI", satici.getSaticiTipKod());
				oMap.put("MUSTERI_NO", satici.getMusteriNo());
				oMap.put("SUBE_MUSTERI_NO", satici.getSubeMusteriNo());
				oMap.put("MERKEZ_BAYI", satici.getBagliMerkezBayi());
				oMap.put("DURUM", satici.getDrm());
				oMap.put("BAYI_CALISMA_SEKLI", saticiTahsis.getCalismaSekliKod());
				oMap.put("AYNI_SIFRE_BASVURU", saticiTahsis.getAyniSifreBasvuruEh());
				oMap.put("OTP_GEREKLIMI", saticiTahsis.getOtpKontrolEh());
				oMap.put("ERKEN_SOZLESME_BASIM", saticiTahsis.getErkenBelgeAlimiEh());
				oMap.put("KREDI_ODEMESI", satici.getKrediOdemesi());
				oMap.put("DEBIT_KART", satici.getDebitKart());
				oMap.put("BAYI_KREDI_TIPI", satici.getBayiKrediTipi());
				oMap.put("KORUMA_KREDISI", satici.getKorumaKredisi());
				oMap.put("FAIZSIZ_FINANSMAN", satici.getFaizsizFinansman());
				
				HashMap<Integer,String> creditTypes = null;
				String krediTurKod = satici.getKrdTurKodlari();				
				if(StringUtils.isNotBlank(krediTurKod)){
					creditTypes = new HashMap<Integer,String>();
					for(int i = 0; i < krediTurKod.length() ; i++){
						if(krediTurKod.charAt(i) == Constants.CREDIT_TYPE_ENABLED){
							creditTypes.put(i+1, Constants.CREDIT_TYPES[i]);
						}
					}
					oMap.put(Constants.CREDIT_TYPE_LIST,creditTypes);
				}
				
				if(!"".equals(satici.getBayiSorumluKisi())){
					GnlPersonel personel = (GnlPersonel) session.get(GnlPersonel.class, satici.getBayiSorumluKisi());
					
					if(personel != null)
					{
						oMap.put("BAYI_SORUMLU_MUSTERI_NO", personel.getMusteriNo());
					}
				}

			}
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_START_APPLICATION")
	public static GMMap startApplication(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		try {
			List<Object> list = session.createQuery("from BirBasvuruTx b, BirBasvuruKimlikTx k where b.txNo = k.txNo and b.tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO")
					+ "' and b.durumKodu = 'ON_ONAY"
					+ "' and b.basvuruNo=" + iMap.getString("BASVURU_NO")).list();
			if(list.size() > 0){
				Object[] obj =  (Object[])list.get(0);
				BirBasvuruTx basvuruTx = (BirBasvuruTx)obj[0];
				BirBasvuruKimlikTx kimlik = (BirBasvuruKimlikTx)obj[1];

				if(basvuruTx.getSaticiKod() == null || basvuruTx.getSaticiKod().equals(iMap.getBigDecimal("SATICI_KOD"))){
					BirBasvuru b = (BirBasvuru)session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruTx.getBasvuruNo())).uniqueResult();
					//eger isleme alinmamissa
					if(b == null){
						oMap.put("NAME",nvl(kimlik.getAd(),""));
						oMap.put("SURNAME",nvl(kimlik.getSoyad(),""));
						oMap.put("BIRTH_PLACE",nvl(kimlik.getDogumYeri(),""));
						oMap.put("BIRTHDATE",nvl(kimlik.getDogumTar(),""));
						oMap.put("FARTHER_NAME",nvl(kimlik.getBabaAd(),""));
						oMap.put("MOTHER_NAME",nvl(kimlik.getAnneAdi(),""));
						oMap.put("GENDER",nvl(kimlik.getCinsiyet(),""));
						oMap.put("MARITAL_STATUS",nvl(kimlik.getMedeniHal(),""));
						oMap.put("MOBILE_NUMBER",nvl(kimlik.getCepTelNo(),""));
		
						if(StringUtils.isBlank(kimlik.getKimlikSeriNoKps())){
							oMap.put("IS_KPS_DONE",false);
						}
						basvuruTx.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
						session.save(basvuruTx);
						session.flush();
						
						oMap.put("ELEKTRONIK_AKIS", "H");
						oMap.put("CERCEVE_SOZLESME_UYARI", "H");
						BirSatici satici = (BirSatici) session.get(BirSatici.class, iMap.getBigDecimal("SATICI_KOD"));
						if("1".equals(satici.getBayiKrediTipi()) || "2".equals(satici.getBayiKrediTipi())){
							BirSaticiTahsis saticiTahsis = (BirSaticiTahsis) session.get(BirSaticiTahsis.class, iMap.getBigDecimal("SATICI_KOD"));
							if(!"1".equals(saticiTahsis.getCalismaSekliKod())){
								iMap.put("MUSTERI_NO", basvuruTx.getMusteriNo());
								
								GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).uniqueResult();
								if("M".equals(musteri.getMusteriKontakt()) || "E".equals(cerceveSozlesmeKontrol(iMap).getString("SONUC"))){
									oMap.put("ELEKTRONIK_AKIS", "E");
								}
							}
						}
						
						// ptt emekli servisini cagir..
						GMServiceExecuter.executeAsync("BNSPR_TRN3171_PTT_EMEKLI_SORGULA", iMap);
					}else{
						oMap.put("IS_PROCESSED", "1");
						oMap.put("DEALER_CODE", basvuruTx.getSaticiKod());
					}
					
					if(basvuruTx.getMusteriNo() != null){
						iMap.put("MUSTERI_NO", basvuruTx.getMusteriNo());
						oMap.put("MUSTERI_KONTAKT", GMServiceExecuter.execute("BNSPR_CUST_GET_MUSTERIMI_KONTAKMI", iMap).get("KONTAK_MUSTERI"));
						oMap.put("KIMLIK_SERI_NO", kimlik.getKimlikSeriNoKps());
						oMap.put("KIMLIK_SIRA_NO", kimlik.getKimlikSiraNoKps());
						oMap.put("CUSTOMER_NO", basvuruTx.getMusteriNo());
					}
				}else{
					iMap.put("HATA_NO", "5082");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}else{
				iMap.put("HATA_NO", "5081");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_SEARCH_DELAER")
	public static GMMap searchDealer(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			List<BirSatici> satici = (List<BirSatici>) session.createCriteria(BirSatici.class)
					.add(Restrictions.or(
							Restrictions.eq("kod", iMap.getBigDecimal("SATICI_KOD")),
							Restrictions.ilike("saticiAdi", "%"+nvl(iMap.getString("SATICI_ADI")+"%","")))).list();

			if (satici != null && satici.size() > 0) {
				int i = 0;
				for(BirSatici s : satici){
					oMap.put("SATICI_LIST",i,"BAYI_KOD", s.getKod());
					oMap.put("SATICI_LIST",i,"BAYI_ADI", s.getSaticiAdi());
					oMap.put("SATICI_LIST",i,"BAYI_TEL_ALANKOD", s.getAlanKodTel());
					oMap.put("SATICI_LIST",i,"BAYI_TEL", s.getTelNo());
					oMap.put("SATICI_LIST",i,"BAYI_ADRES", s.getAdres());

					oMap.put("SATICI_LIST",i,"SATICI_TIPI", s.getSaticiTipKod());

					oMap.put("SATICI_LIST",i,"MUSTERI_NO", s.getMusteriNo());
					oMap.put("SATICI_LIST",i,"SUBE_MUSTERI_NO", s.getSubeMusteriNo());
					i++;
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_CL_GET_BAYI_PERSONEL_LIST")
	public static GMMap getBayiPersonelList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			String sql ="select c.kod, c.adi,c.ikinci_ad, c.soyadi, "
					+ "c.yetki_giris_kod yetki_seviyesi,c.tc_kimlik_no,c.cal_statu_kod, "
					+ "(select text from gnl_param_text where kod = 'POZISYON_KOD' and key1 = c.pozisyon_kod) gorev, "
					+ "c.durum, c.cal_kismi_kapanma_neden_kod kapama_nedeni,pkg_musteri.otp_telefon(c.musteri_no, 'A') cep_alan,pkg_musteri.otp_telefon(c.musteri_no, 'T') cep_no"
					+ " from bir_satici_calisan c, bir_satici_tahsis b where c.durum = 'ONAY'   "
					+ "and (c.satici_kod in (select satici_kod from bir_satici_calisan c where c.durum = 'ONAY'"
					+ " and c.kod = ?) or c.satici_kod = ?) and b.kod = c.satici_kod and b.bayi_statu_kod != 'K'";
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement(sql);
			// stmt =
			// conn.prepareStatement("select c.kod,c.adi ||' ' ||c.soyadi from bir_satici_calisan c where c.durum='ONAY' and c.cal_statu_kod<>'K'  and c.satici_kod=? ");
			stmt.setBigDecimal(1, iMap.getBigDecimal("SATICI_KOD"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "PERSONEL_LIST");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_CL_TOPLU_KPS_SEND_RESULTS")
	public static GMMap topluKPSSendResults(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal txNo = iMap.getBigDecimal("ISLEM_NO");
		
		try {
			
			oMap = DALUtil.getResults("select * from bnspr.gnl_musteri_toplu_kps where tx_no="+txNo, "TOPLU_KPS");
			
			StringBuilder mailBody = new StringBuilder();
			mailBody.append("<html><body>");
			mailBody.append("<table>");
			mailBody.append("<tr>");
			mailBody.append("<th>TX_NO</th>");
			mailBody.append("<th>KPS_SORGU_ID</th>");
			mailBody.append("<th>TCKN</th>");
			mailBody.append("<th>DURUM</th>");
			mailBody.append("<th>HATA_KOD</th>");
			mailBody.append("<th>HATA_ACIKLAMA</th>");
			mailBody.append("<th>SORGU_NEDENI</th>");
			mailBody.append("<th>DURUM</th>");
			mailBody.append("</tr>");
			for(int i = 0; i < oMap.getSize("TOPLU_KPS");i++){
				mailBody.append("<tr>");
				mailBody.append("<td>"+oMap.getString("TOPLU_KPS",i,"TX_NO")+"</td>");
				mailBody.append("<td>"+oMap.getString("TOPLU_KPS",i,"KPS_SORGU_ID")+"</td>");
				mailBody.append("<td>"+oMap.getString("TOPLU_KPS",i,"TCKN")+"</td>");
				mailBody.append("<td>"+oMap.getString("TOPLU_KPS",i,"DURUM")+"</td>");
				mailBody.append("<td>"+oMap.getString("TOPLU_KPS",i,"HATA_KOD")+"</td>");
				mailBody.append("<td>"+oMap.getString("TOPLU_KPS",i,"HATA_ACIKLAMA")+"</td>");
				mailBody.append("<td>"+oMap.getString("TOPLU_KPS",i,"SORGU_NEDENI")+"</td>");
				mailBody.append("<td>"+oMap.getString("TOPLU_KPS",i,"DURUM")+"</td>");
				mailBody.append("</tr>");
				
				
			}
			mailBody.append("</table>");
			mailBody.append("</body></html>");
			
			
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
			GMMap xMap = new GMMap();
			xMap.put("PARAMETRE", "KRE_TOPLU_KPS_MAIL_TO");
			servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
			servisMap.put("MAIL_SUBJECT", "Toplu Kps Sonuc : "  + GMServiceExecuter.call("BNSPR_CORE_GET_DATABASE_ADI", iMap).getString("DATABASE_ADI"));
			if(mailBody.length() > 3000){
				servisMap.put("MAIL_BODY_CLOB", mailBody);
			}else{
				servisMap.put("MAIL_BODY", mailBody);
			}
			servisMap.put("IS_BODY_HTML", "E");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	public static String formatCurrency(BigDecimal value) {
		DecimalFormat formatter = new DecimalFormat("###,##0.00");
		DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
		symbols.setDecimalSeparator(',');
		symbols.setGroupingSeparator('.');
		formatter.setDecimalFormatSymbols(symbols);
		return formatter.format(value);
	}
	
	//---------------------------------------------- BELGE YUKLEME
	/** Bayi dokumanlari ekranda gecici dizine kaydedildikten sonra alindi olarak isaretlenir.<br>
	 * @author murat.el
	 * @since PY-10975
	 * @param iMap - Basvuru bilgisi<br>
	 *        <li>BASVURU_NO - Kredi basvuru numarasi
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>KIM_ICIN - Kim icin dokuman yukleniyor? (M:Musteri, K1-K2:Kefil, E:Es)
	 *        <li>DOKUMAN_KOD - Dokuman kodu
	 *        <li>DOSYA_UZANTISI - Dosya uzantisi
	 *        <li>DOSYA_ICERIK - ByetArray formatinda dosya icerigi
	 * @return oMap - Sonuc bilgisi<br>
	 */
	@GraymoundService("BNSPR_CL_BELGE_YUKLE")
	public static GMMap belgeYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		//
		BigDecimal basvuruNo = iMap.getBigDecimal(Constants.BASVURU_NO);
		BigDecimal trxNo = iMap.getBigDecimal(Constants.TRX_NO);
		String dokumanKod = iMap.getString(Constants.DOKUMAN_KOD);
		String kimIcin = ConsumerLoanCommonServices.nvl(iMap.getString("KIM_ICIN"), "M");
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		
		try {
			//Belge yuklenebilir mi?
			BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();
			id.setTxNo(trxNo);
			id.setBasvuruNo(basvuruNo);
			id.setDokumanKod(dokumanKod);
			id.setKimden(kimIcin);
			
			BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, id);
			if (birBasvuruBelgeTx == null) {
				birBasvuruBelgeTx = new BirBasvuruBelgeTx();
				birBasvuruBelgeTx.setId(id);
			}/*else{
				raiseGMError("5237", dokumanKod);
			}*/ 
			
			GMMap sorguMap = new GMMap();
			sorguMap.put(Constants.BASVURU_NO, basvuruNo);
			sorguMap.put(Constants.DOKUMAN_KOD, dokumanKod);
			sorguMap.put("DOSYA_ICERIK", iMap.get("DOSYA_ICERIK"));
			sorguMap.put("KANAL", "BAYI");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_GECICI_BELGE_YUKLE", sorguMap));//ARSIV_FILE_PATH
			String versiyonPath = sorguMap.getString("ARSIV_FILE_PATH");
			
			//Belgenin onceki statusunu al, yeni statusunu ona gore guncelle
			BirBasvuruBelgeId belgeId = new BirBasvuruBelgeId();
			belgeId.setBasvuruNo(basvuruNo);
			belgeId.setDokumanKod(dokumanKod);
			belgeId.setKimden(kimIcin);
			
			BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) session.get(BirBasvuruBelge.class, belgeId);
			String belgeYeniDurum = "6";//Belge Yuklendi
			//Belge durumu eksikse yeni belge yuklendigi zaman statuyu farklilastir
			if (birBasvuruBelge != null && "2".equals(birBasvuruBelge.getBelgeKontrol())) {
				belgeYeniDurum = "7";//Eksik Belge Yuklendi
			}
			//Basvuru uzerinde belgeyi alindi olarak guncelle.
			birBasvuruBelgeTx.setAlindi(Constants.EVET);
			birBasvuruBelgeTx.setBelgeKontrol(belgeYeniDurum);
			birBasvuruBelgeTx.setVersiyonPath(versiyonPath);
			session.save(birBasvuruBelgeTx);
			session.flush();
			
			// create IWD task for documents
			try {
				GMMap iwdMap = new GMMap();
				iwdMap.put(Constants.BASVURU_NO, basvuruNo);
				iwdMap.put(Constants.DOKUMAN_KOD, dokumanKod);
				iwdMap.put(Constants.KIMDEN, kimIcin);
				iwdMap.put(Constants.BELGE_KONTROL, belgeYeniDurum);
				iwdMap.put("TRX_NO", trxNo);
				GMServiceExecuter.executeAsync("BNSPR_CL_IWD_CREATE_TASK", iwdMap);
			}
			catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_KULLANDIRIM_KONTROL")
	public static GMMap kullandirimKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kontrolEh = "H";
		
		try{
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
	
			GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).uniqueResult();
	
			if (musteri != null) {
				iMap.put("MUSTERI_NO", musteri.getMusteriNo());
				if ("M".equalsIgnoreCase(musteri.getMusteriKontakt())) {
					iMap.putAll(GMServiceExecuter.call("BNSPR_MUSTERI_BHS_KONTROL", iMap));
	
					if ("H".equalsIgnoreCase(iMap.getString("F_BHS"))) {
						iMap.putAll(GMServiceExecuter.call("BNSPR_KART_KURYE_TESLIM_BHS_KONTROL", iMap));
						if ("E".equalsIgnoreCase(iMap.getString("F_BHS"))) {
							kontrolEh = "E";
						}
					}else{
						kontrolEh = "E";
					}
				} else {
					iMap.put("PARAMETRE", "BIR_KULLANDIRIM_KONTROL_BHS");
					String[] bhsKodlari = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).getString("DEGER").split("-");
					for (String bhsKod : bhsKodlari) {
						if (!"".equals(bhsKod)) {
							String funcDokumanKontrol = "{? = call BNSPR.PKG_MUSTERI_EK.musteri_dokuman_kontrol(?,?)}";
							Object[] inputDokumanKontrol = new Object[] { BnsprType.NUMBER,
									iMap.getBigDecimal("MUSTERI_NO"), BnsprType.STRING,
									bhsKod };
							kontrolEh = (String) DALUtil.callOracleFunction(funcDokumanKontrol, BnsprType.STRING, inputDokumanKontrol);
							if("E".equals(kontrolEh))
								break;
						}
					}
				}
			}
			
			if("E".equals(kontrolEh)){
				// sonuclanmamis basvuru kontrolu
				List<BirBasvuru> list =  session.createCriteria(BirBasvuru.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))
						).add(Restrictions.eq("kanalKodu", "8")).add(Restrictions.eq("krediTur", new BigDecimal(1)))
						.add(Restrictions.or(Restrictions.eq("durumKodu", "KUL"), Restrictions.and(Restrictions.eq("durumKodu", "DOGRULAMA"), Restrictions.eq("sozlesmeBasildiEh", "E")))).list();
				
				if(list.size() > 0){
					kontrolEh = "H";
					oMap.put("SONUCLANMAMIS_BASVURU", "E");
				}
			}
	
			oMap.put("SONUC", kontrolEh);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_CERCEVE_SOZLESME_KONTROL")
	public static GMMap cerceveSozlesmeKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kontrolEh = "H";
		
		try {
			// kart taraf� kontrol edilecek..
			iMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			iMap.putAll(GMServiceExecuter.call("BNSPR_BAYI_IS_EXISTS_PREPAID_APPLICATION", iMap));
			if("Y".equals(iMap.getString("IS_EXISTS"))){
				kontrolEh = "E";
			}
			
			oMap.put("SONUC", kontrolEh);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**** update belge statu (sadece eksik belgeler icin cagrilmalidir.) ****/
	@GraymoundService("BNSPR_CL_UPDATE_DOCUMENT_STATUS")
	public static GMMap updateDocumentStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			for (int i = 0; i < iMap.getSize("BELGE_LIST"); i++) {
				BirBasvuruBelge b = (BirBasvuruBelge)session.createCriteria(BirBasvuruBelge.class)
								.add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
								.add(Restrictions.eq("id.dokumanKod", iMap.getString("BELGE_LIST",i, "DOKUMAN_KOD")))
								.add(Restrictions.eq("id.kimden", iMap.getString("BELGE_LIST",i, "KIMDEN"))).uniqueResult();
				
				if(b != null){
					if("E".equals(iMap.getString("BELGE_LIST",i, "ALINDI"))){
						b.setAlindi("E");
						if("2".equals(b.getBelgeKontrol()) || "3".equals(b.getBelgeKontrol()))
							b.setBelgeKontrol("7");
						else
							b.setBelgeKontrol("6");
					}
					BirBasvuruBelgeTx tx = new BirBasvuruBelgeTx();
					BirBasvuruBelgeTxId txId = new BirBasvuruBelgeTxId();
					txId.setBasvuruNo(b.getId().getBasvuruNo());
					txId.setDokumanKod(b.getId().getDokumanKod());
					txId.setKimden(b.getId().getKimden());
					txId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					tx.setId(txId);
					tx.setAlindi(b.getAlindi());
					tx.setBelgeKontrol(b.getBelgeKontrol());
					session.save(b);
					session.save(tx);
					session.flush();
				}
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * TCKN, KANAL_KOD, KAMP_KOD, KRD_TUR_KOD, DOVIZ_KODU, TUTAR, VADE, CALL_NBSM
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_ONONAY_BASVURU")
	public static GMMap onOnayBasvuru(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			if(StringUtil.isEmpty(iMap.getString("TCKN"))){
				throw new GMRuntimeException(0, "TCKN dolu olmal�d�r.");
			}

			iMap.put("KAMP_URUN_ADI", iMap.get("KAMP_KOD"));
			iMap.put("KOD", iMap.get("KAMP_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", iMap));
			iMap.put("KAMP_KNL_KOD", oMap.get("KAMP_KNL_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", iMap));
			iMap.put("FAIZ_ORANI", oMap.get("FAIZ_ORANI"));
			
			iMap.put("ONONAY_BASVURU", "1");
			iMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_SAVE_ONONAY_BASVURU", iMap));
			oMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			
			if(iMap.get("HATA_NO") != null){
				oMap.put("RESPONSE_CODE", "E");
				oMap.put("RESPONSE_MESSAGE", iMap.get("HATA"));
			}else{
				oMap.put("RESPONSE_CODE", "S");
				
				if("E".equals(iMap.getString("CALL_NBSM"))){
					iMap.put("PARAMETRE", "BIR_ONONAY_NBSM_LOG_LEVEL");
					iMap.put("LOG_LEVEL", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N" , iMap).getInt("DEGER"));
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_DEVAM_SORGULAR", iMap));
				}
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/**
	 * ON_ONAY_ID , TC_KIMLIK_NO  optional
	 * @param iMap
	 * @return TUTAR, VADE
	 */
	@GraymoundService("BNSPR_CL_GET_ON_ONAY_BILGI")
	public static GMMap getOnOnayBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap kMap = new GMMap();
		GMMap hMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			if(iMap.get("MUSTERI_NO") != null) {
				GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).uniqueResult();
				if(musteri != null){
					iMap.put("TC_KIMLIK_NO", musteri.getTcKimlikNo());
				}
			}
			if(iMap.get("TC_KIMLIK_NO") != null){
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall ( "{? = call PKG_RC8000.Get_Evam_Info_By_Tckn(?, ?, ?)}" );
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
				stmt.setString(i++, iMap.getString("LIMIT_TURU"));
				stmt.execute();
				rSet = (ResultSet) stmt.getObject (1);
				oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
				
				if(oMap.getSize("RESULTS") > 0){
					GMMap odrMap = new GMMap();
					oMap.put("BASVURU_NO", oMap.get("RESULTS", 0, "BASVURU_NO"));
					oMap.put("GECERLILIK_TARIHI", oMap.get("RESULTS", 0, "GECERLILIK_TARIHI"));
					oMap.put("KAMPANYA_KODU", oMap.get("RESULTS", 0, "KAMPANYA_KOD"));
					oMap.put("KREDI_TUTARI", oMap.get("RESULTS", 0, "ONAY_TUTAR"));
					oMap.put("TUTAR", oMap.get("RESULTS", 0, "ONAY_TUTAR"));
					oMap.put("KREDI_TURU", oMap.get("RESULTS", 0, "KREDI_TUR_KOD"));
					oMap.put("ODEME_TIP_KOD", oMap.get("RESULTS", 0, "ODEME_TIP_KOD"));
					oMap.put("KANAL_KOD", oMap.get("RESULTS", 0, "KANAL_KOD"));
					oMap.put("DOVIZ_KOD", oMap.get("RESULTS", 0, "DOVIZ_KODU"));
					oMap.put("KREDI_VADE", oMap.get("RESULTS", 0, "ONAY_VADE"));
					oMap.put("VADE", oMap.get("RESULTS", 0, "ONAY_VADE"));
					oMap.put("KAMP_URUN_ADI", oMap.get("RESULTS", 0, "KAMPANYA_KOD"));
					oMap.put("KONSOLIDASYON_LIMIT", oMap.get("RESULTS", 0, "KONSOLIDASYON_LIMIT"));
					oMap.put("KAYNAK", oMap.get("RESULTS", 0, "KAYNAK"));
					oMap.put("SEGMENT", oMap.get("RESULTS", 0, "SEGMENT"));
					
					if(iMap.get("KANAL_KODU") != null){
						oMap.put("KANAL_KOD", iMap.get("KANAL_KODU"));
					}
					
					if("P".equals(iMap.getString("LIMIT_TURU")) || "T".equals(iMap.getString("LIMIT_TURU"))){
						oMap.put("RISK_BAZLI_FIYATLAMA", "E");
					}
					
					if(oMap.get("TUTAR") != null && oMap.getBigDecimal("TUTAR").compareTo(BigDecimal.ZERO) > 0) {
					
						odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", oMap));
						oMap.put("AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_TUTAR"));
						oMap.put("FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
						oMap.put("DOSYA_MASRAFI", odrMap.get("DOSYA_MASRAFI"));
						oMap.put("HESABA_YATACAK_TUTAR", odrMap.get("HESABA_YATACAK_TUTAR"));
						oMap.put("TOPLAM_TAKSIT_TUTARI", odrMap.get("TOPLAM_TAKSIT_TUTARI"));
						oMap.put("COST_RATIO", odrMap.get("COST_RATIO"));
						oMap.put("GECIKME_FAIZ_ORAN", odrMap.get("GECIKME_FAIZ_ORAN"));
						oMap.put("GECIKME_FAIZ_ORAN_YILLIK", odrMap.get("GECIKME_FAIZ_ORAN")!=null?odrMap.getBigDecimal("GECIKME_FAIZ_ORAN").multiply(new BigDecimal(12)):null);
						oMap.put("ODEME_PLANI", odrMap.get("ODEME_PLANI"));
					}
					
					if(oMap.get("KONSOLIDASYON_LIMIT") != null && oMap.getBigDecimal("KONSOLIDASYON_LIMIT").compareTo(BigDecimal.ZERO) > 0) {

						kMap.put("KOD", "ONONAY_LIMIT_KAMP_KOD");
						kMap.put("KEY", "P");
						kMap.put("KEY2", "K");
						oMap.put("KONSOLIDASYON_KAMP_KOD", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", kMap).getString("TEXT"));
						oMap.put("KONSOLIDASYON_KREDI_TUTAR", oMap.get("KONSOLIDASYON_LIMIT"));
						
						@SuppressWarnings("unchecked")
						List<BirBasvuruKonsolidasyon> list = session.createCriteria(BirBasvuruKonsolidasyon.class).add(Restrictions.eq("id.basvuruNo", oMap.getBigDecimal("BASVURU_NO"))).list();
						Iterator<BirBasvuruKonsolidasyon> iterator = list.iterator();
						
						int toplamAdet = 0;
						int kapatilacakAdet = 0;
						BigDecimal kapamaTutari = BigDecimal.ZERO;
						while(iterator.hasNext()) {
							BirBasvuruKonsolidasyon basvuru = iterator.next();
							if("E".equals(basvuru.getKapamaEh())) {
								kapatilacakAdet++;
								kapamaTutari = kapamaTutari.add( (BigDecimal) DALUtil.callOracleFunction(
											"{? = call pkg_trn3243.kredi_kapama_tutar(?)}", BnsprType.NUMBER, BnsprType.NUMBER,
											basvuru.getId().getYapilandirilanBasvuruNo()) );
							}
							toplamAdet++;
						}
						
						oMap.put("ACIK_KREDI_ADET", toplamAdet);
						oMap.put("KAPATILACAK_KREDI_ADET", kapatilacakAdet);
						oMap.put("KAPAMA_TUTARI", kapamaTutari);
						
						if(kapatilacakAdet > 0) {
							/** konsolidasyon talep tutari guncel hesaplanmasi **/
							hMap.put("KREDI_TUTARI", kapamaTutari);
							hMap.put("TUTAR", kapamaTutari);
							
							hMap.put("DOVIZ_KOD", oMap.get("DOVIZ_KOD"));
							hMap.put("DOVIZ_KODU", oMap.get("DOVIZ_KOD"));
	 						hMap.put("KANAL_KOD", "7");
	 						hMap.put("KRD_TUR_KOD", oMap.get("KREDI_TURU"));
	 						hMap.put("KAMP_URUN_ADI", oMap.get("KONSOLIDASYON_KAMP_KOD"));
	 						hMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_KREDI_MIN_MAX_DEGER", hMap));
	 						
							hMap.put("KREDI_VADE", hMap.get("MAX_VADE"));
							hMap.put("VADE", hMap.get("MAX_VADE"));
							hMap.put("KAMP_KOD", oMap.get("KONSOLIDASYON_KAMP_KOD"));
							hMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", hMap));
							
							hMap.put("DOGUM_TARIHI", oMap.get("RESULTS", 0, "DOGUM_TAR"));
							hMap.put("CINSIYET", oMap.get("RESULTS", 0, "CINSIYET"));
							
							hMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", hMap));
							oMap.put("KONSOLIDASYON_MIN_TUTAR", hMap.getBigDecimal("HERSEY_DAHIL_TUTAR"));
							oMap.put("KONSOLIDASYON_MUSTERIYE_KALAN_TUTAR", oMap.getBigDecimal("KONSOLIDASYON_LIMIT").subtract(hMap.getBigDecimal("HERSEY_DAHIL_TUTAR")));
							oMap.put("KONSOLIDASYON_VADE", hMap.get("VADE"));
							
							odrMap.clear();
							hMap.put("TUTAR", oMap.getBigDecimal("KONSOLIDASYON_LIMIT"));
							hMap.put("KAMPANYA_KODU", oMap.get("KONSOLIDASYON_KAMP_KOD"));
							hMap.put("KREDI_TUTARI", oMap.getBigDecimal("KONSOLIDASYON_LIMIT"));
							hMap.put("KREDI_TURU", oMap.get("RESULTS", 0, "KREDI_TUR_KOD"));
							hMap.put("ODEME_TIP_KOD", oMap.get("RESULTS", 0, "ODEME_TIP_KOD"));
							hMap.put("RISK_BAZLI_FIYATLAMA", oMap.get("RISK_BAZLI_FIYATLAMA"));
							hMap.put("SEGMENT", oMap.get("SEGMENT"));
							
							odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", hMap));
							oMap.put("K_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_TUTAR"));
							oMap.put("K_FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
							oMap.put("K_DOSYA_MASRAFI", odrMap.get("DOSYA_MASRAFI"));
							oMap.put("K_HESABA_YATACAK_TUTAR", odrMap.get("HESABA_YATACAK_TUTAR"));
							oMap.put("K_TOPLAM_TAKSIT_TUTARI", odrMap.get("TOPLAM_TAKSIT_TUTARI"));
							oMap.put("K_COST_RATIO", odrMap.get("COST_RATIO"));
							oMap.put("K_GECIKME_FAIZ_ORAN", odrMap.get("GECIKME_FAIZ_ORAN"));
							oMap.put("K_GECIKME_FAIZ_ORAN_YILLIK", odrMap.get("GECIKME_FAIZ_ORAN")!=null?odrMap.getBigDecimal("GECIKME_FAIZ_ORAN").multiply(new BigDecimal(12)):null);
							oMap.put("K_ODEME_PLANI", odrMap.get("ODEME_PLANI"));
						}
					}
					
					oMap.remove("RESULTS");
				}
				
			}else{
				BirAdkBasvuru adk = (BirAdkBasvuru) session.get(BirAdkBasvuru.class, iMap.getBigDecimal("ON_ONAY_ID"));
				if(adk != null){
					oMap.put("TUTAR", adk.getTutar());
					oMap.put("VADE", adk.getVade());
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close ( rSet );
			GMServerDatasource.close ( stmt );
			GMServerDatasource.close ( conn );
		}
		return oMap;
	}
	
	/**NoNameDebitCard icin musteri atamasi yapar.<br>
	 * @author huseyin.ceteci
	 * @since 
	 * @param iMap <br>
	 *        <li>BASVURU_NO - Kredi basvuru numarasi
	 *        <li>KART_NO - Kart numarasi
	 * @return oMap - Sonuc bilgisi<br>
	 * 		  <li>RETURN_CODE - Islem sonuc kodu (0:Basarisiz|1:Basarili)
	 * 		  <li>RETURN_DATA - Islem sonuc aciklamasi
	 */
	@GraymoundService("BNSPR_CL_MATCH_CARD_AND_CUSTOMER")
	public static GMMap matchCardAndCustomer(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = null;
		BigDecimal customerNo = BigDecimal.ZERO;
		BigDecimal appNo = BigDecimal.ZERO;
		BigDecimal dbtAppNo = BigDecimal.ZERO;
		BigDecimal boxOfficeId = BigDecimal.ZERO;
		BigDecimal bankAccountNo = BigDecimal.ZERO;
		String cardNo = StringUtils.EMPTY;
		String customerName = StringUtils.EMPTY;
		boolean isMatchCustomer = false;
		
		try {
			session = DAOSession.getSession("BNSPRDal");
			appNo = iMap.getBigDecimal("BASVURU_NO");
			cardNo = iMap.getString("KART_NO");
			
			BirBasvuru application = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", appNo)).uniqueResult();
			if(application == null){
				oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(Constants.RESPONSE_DATA, "Ba�vuru kayd� bulunamad�.");
				return oMap;
			}
			
			GnlMusteri customer = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", application.getMusteriNo())).uniqueResult();
			if(customer == null){
				oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(Constants.RESPONSE_DATA, "M��teri kayd� bulunamad�.");
				return oMap;
			}
			
			BigDecimal maxSozlesmeNo = (BigDecimal) session.createCriteria(BirBasvuruSozlesmeTx.class).add(Restrictions.eq("basvuruNo", appNo)).setProjection(Projections.max("txNo")).uniqueResult();
			BirBasvuruSozlesmeTx sozlesme = (BirBasvuruSozlesmeTx) session.createCriteria(BirBasvuruSozlesmeTx.class).add(Restrictions.eq("txNo", maxSozlesmeNo)).uniqueResult();
			if(sozlesme == null){
				oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(Constants.RESPONSE_DATA, "S�zle�me kayd� bulunamad�.");
				return oMap;
			}
			
			customerName = checkCardHolderName(customer.getAdi(), customer.getIkinciAdi(), customer.getSoyadi());
			customerNo = customer.getMusteriNo();
			bankAccountNo = sozlesme.getSozlesmeHesapNo();
			boxOfficeId = application.getSaticiKod();
			dbtAppNo = GMServiceExecuter.call("BNSPR_TRN3871_GET_BASVURU_NO", iMap).getBigDecimal("ID");
			
			//match card && customer
			GMMap queryMap = new GMMap();
			queryMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			queryMap.put("CARD_NO", cardNo);
			queryMap.putAll(GMServiceExecuter.execute("BNSPR_CL_CREATE_CARD_CUSTOMER", queryMap));
            String custResult = queryMap.getString("ORESULT");
            String custResultDesc = queryMap.getString("RETURN_DESCRIPTION");
            
            if (!AkustikConstants.RESPONSE_SUCCESS.equals(queryMap.getString("RETURN_CODE"))) {
            	oMap.put("RESPONSE", AkustikConstants.RESPONSE_FAIL);
            	oMap.put("RESPONSE_DATA", custResult + "-" + custResultDesc);
                return oMap;
            }

            queryMap.clear();
			queryMap.put("CUSTOMER_NO", customerNo);
			queryMap.put("BANK_ACCOUNT_NO", bankAccountNo);
			queryMap.put("CARD_NO", cardNo);
			queryMap.put("NAME", customerName);
			queryMap.put("APPLICATION_NO", dbtAppNo);
			queryMap.put("BOX_OFFICE_ID", boxOfficeId);
			queryMap.put("TXN_TYPE", "N");
			queryMap.put("CARD_POST_IDX", "OTHER");
			GMServiceExecuter.call("BNSPR_OCEAN_MATCH_CARD_AND_CUSTOMER", queryMap);
			isMatchCustomer = true;
			
			//get application info for card request
			GMMap applicationMap = new GMMap();
			queryMap.clear();
			queryMap.put("APPLICATION_NO", appNo);
			applicationMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_APPLICATION_INFO_FOR_DEBIT_CARD", queryMap));
			
			//card request
			queryMap.clear();
			queryMap.put("KANAL", "BAYI");
			queryMap.put("REFERANS_NO", appNo);
			queryMap.put("DBT_BASVURU_NO", dbtAppNo);
			queryMap.put("ISLEM_TIPI", iMap.getString("ISLEM_TIPI", "NND"));
			queryMap.put("KART_NO", cardNo);
			queryMap.putAll(applicationMap);
			GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", queryMap);
			
			//insert cl card info
			BirBasvuruKartBilgi cardInfo = (BirBasvuruKartBilgi) session.createCriteria(BirBasvuruKartBilgi.class).add(Restrictions.eq("basvuruNo", appNo)).uniqueResult();
			if(cardInfo == null){
				cardInfo = new BirBasvuruKartBilgi();
				cardInfo.setBasvuruNo(appNo);
			}
			cardInfo.setKartNo(cardNo);
			cardInfo.setKartTalepId(dbtAppNo);
			cardInfo.setKartTipi("NN");
			session.save(cardInfo);
			
			BirBasvuruKartBilgiTx cardTx = new BirBasvuruKartBilgiTx();
			cardTx.setTxNo(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			cardTx.setBasvuruNo(appNo);
			cardTx.setKartNo(cardNo);
			cardTx.setKartTalepId(dbtAppNo);
			cardTx.setKartTipi("NN");
			
			session.save(cardTx);
			
			//add document
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
			queryMap.clear();
			queryMap.put("KOD", "BAYI_BASVURU_EK_DOKUMANLAR");
			queryMap.put("KEY", "KART_TESLIM_TUTANAGI");
			String documentCode = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", queryMap).getString("TEXT");
			
			BirBasvuruBelgeTxId documentTxId = new BirBasvuruBelgeTxId();
			documentTxId.setTxNo(trxNo);
			documentTxId.setBasvuruNo(appNo);
			documentTxId.setDokumanKod(documentCode);
			documentTxId.setKimden("M");

			BirBasvuruBelgeTx documentTx = new BirBasvuruBelgeTx();
			documentTx.setId(documentTxId);
			documentTx.setAlindi("E");
			documentTx.setBelgeKontrol("6");
			session.save(documentTx);
			
			BirBasvuruBelgeId documentId = new BirBasvuruBelgeId();
			documentId.setBasvuruNo(appNo);
			documentId.setDokumanKod(documentCode);
			documentId.setKimden("M");
			
			BirBasvuruBelge document = (BirBasvuruBelge) session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id", documentId)).uniqueResult();
			if (document == null){
				document = new BirBasvuruBelge();
			}
			document.setId(documentId);
			document.setAlindi("E");
			document.setBelgeKontrol("6");
			session.saveOrUpdate(document);
			session.flush();
			
			oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
			oMap.put(Constants.RESPONSE_DATA, "M��teri kart e�le�tirme i�lemi ba�ar�yla ger�ekle�tirilmi�tir.");
		}
		catch (Exception e) {
			if(isMatchCustomer){
				GMMap queryMap = new GMMap();
				queryMap.put("CUSTOMER_NO", customerNo);
				queryMap.put("BANK_ACCOUNT_NO", bankAccountNo);
				queryMap.put("CARD_NO", cardNo);
				queryMap.put("NAME", customerName);
				queryMap.put("APPLICATION_NO", dbtAppNo);
				queryMap.put("BOX_OFFICE_ID", boxOfficeId);
				queryMap.put("TXN_TYPE", "C");
				queryMap.put("CARD_POST_IDX", "OTHER");
				GMServiceExecuter.call("BNSPR_OCEAN_MATCH_CARD_AND_CUSTOMER", queryMap);
			}
			
			String message = e.getMessage();
			LOGGER.error(message);
			oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
			oMap.put(Constants.RESPONSE_DATA, message);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_CREATE_CARD_CUSTOMER")
	public static GMMap createCreditCardCustomer(GMMap iMap)
	{
    	Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
 		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_WEBKREDI.Get_Customer_Info_For_Ocean(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			iMap.putAll(DALUtil.rSetMap(rSet));
			
			LOGGER.debug("BNSPR_OCEAN_CREATE_CUSTOMER INPUT : " + iMap.toString());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_CREATE_CUSTOMER", iMap));
			LOGGER.debug("BNSPR_OCEAN_CREATE_CUSTOMER OUTPUT : " + oMap.toString());
			
			if ("BASIM".equals(iMap.getString("DURUM_KOD")) && !"2".equals(oMap.getString("RETURN_CODE"))) {
				StringBuilder mailHata = new StringBuilder();
				mailHata.append("ORESULT");
				mailHata.append("\n");
				mailHata.append(oMap.getString("ORESULT"));
				mailHata.append("\n");
				mailHata.append("RETURN_DESCRIPTION");
				mailHata.append("\n");
				mailHata.append(oMap.getString("RETURN_DESCRIPTION"));
				
				GMMap mailMap = new GMMap();
				mailMap.put("MAIL_TO_PARAM", "TFF_OCEAN_INTRA_MAIL_TO");
				mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
				mailMap.put("MAIL_SUBJECT", "Web Kredi Ocean Customer Hata - " + iMap.getString("BASVURU_NO"));
				mailMap.put("MAIL_BODY", mailHata.toString());
				GMServiceExecuter.execute("BNSPR_KK_BASVURU_SEND_MAIL", mailMap);
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
	
	public static String checkCardHolderName(String name, String secondName, String lastName){
		String cardHolderName = name + (StringUtils.isEmpty(secondName) ? " " : (" " + secondName + " ")) + lastName;
		
		if(cardHolderName.length() > CARD_HOLDER_NAME_LENGTH){
			if((name + " " + lastName).length() <= CARD_HOLDER_NAME_LENGTH){
				cardHolderName = name + " " + lastName;
			}else if((name.substring(0, 1) + ". " + lastName).length() <= CARD_HOLDER_NAME_LENGTH) {
				cardHolderName = (name.substring(0, 1) + ". " + lastName);
			}else{
				cardHolderName = (name + " " + lastName).substring(0, CARD_HOLDER_NAME_LENGTH);
			}
		}
		
		return cardHolderName;
	}
	
	@GraymoundService("BNSPR_CL_KONSOLIDASYON_TUTAR")
	public static GMMap konsolidasyonTutar(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			BigDecimal tutar = (BigDecimal) DALUtil.callOracleFunction("{ ? = call pkg_basvuru.basvuru_konsolidasyon_tutar(?,?,?) }", BnsprType.NUMBER, 
					BnsprType.STRING, iMap.containsKey("TC_KIMLIK_NO") ? iMap.getString("TC_KIMLIK_NO") : null,
					BnsprType.NUMBER, iMap.containsKey("BASVURU_NO") ? iMap.getBigDecimal("BASVURU_NO") : null,
					BnsprType.NUMBER, iMap.containsKey("KANAL_KODU") ? iMap.getBigDecimal("KANAL_KODU") : null);
			
			oMap.put("TUTAR", tutar);
			oMap.put("VADE", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "BAYI_UPSELL_PARAMETRE").put("KEY", "VADE")).getString("TEXT"));
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CONSUMERLOAN_COMMON_ILERLET_SMS_GONDER")
	public static GMMap basvuruIlerletSmsGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal basvuruNo = iMap.getBigDecimal(Constants.BASVURU_NO);
		try {
			String mesaj = "";
			String cepTel = "";

			GMMap sorguMap = new GMMap();
			sorguMap.put(Constants.BASVURU_NO, basvuruNo);
			sorguMap.put("ISLEM_TIPI", "ILERLET");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_CONSUMERLOAN_COMMON_SMS_BILGI_AL_BY_BASVURU_NO", sorguMap));
            mesaj = sorguMap.getString("MESAJ");
            cepTel = sorguMap.getString("CEP_NO");
            if (StringUtils.isBlank(mesaj) || StringUtils.isBlank(cepTel)) {
            	oMap.put(Constants.RESPONSE_DATA, basvuruNo.toString() + " nolu basvuruya ait sms bilgileri alinamadi.");
            	oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
            	return oMap;
            }
            GMMap mesajMap = new GMMap();
            mesajMap.put("MSISDN", cepTel);
            mesajMap.put("CONTENT", mesaj);
            mesajMap.put("HEADER", "AKTIFBANK");
            mesajMap.putAll(GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", mesajMap));
			oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
		}
		catch (Exception e) {
			oMap.put(Constants.RESPONSE_DATA, e.getMessage());
			oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
			return oMap;
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_YENIDEN_YAPILANDIRMA_RAPOR")
	public static GMMap yenidenYapilandirmaRapor(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session;
		try {
			session = DAOSession.getSession("BNSPRDal");
			if (iMap.getBigDecimal("TRX_NO") == null) {
				oMap.put("PDF_SMS_RESPONSE", "ERROR");
	            oMap.put("PDF_SMS_RESPONSE_MESSAGE", "��lem numaras� zorunludur.");
				return oMap;
			}

			BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.get(BirKrediOdemeplaniGunTx.class, iMap.getBigDecimal("TRX_NO"));
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", birKrediOdemeplaniGunTx.getBasvuruNo());
			
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", birKrediOdemeplaniGunTx.getBasvuruNo())).uniqueResult();
			String queryGuncelBorc = "select sum(t.taksit_tut) from bir_kredi_taksit t where t.basvuru_no = " + birKrediOdemeplaniGunTx.getBasvuruNo().toString();
			if(StringUtils.isNotEmpty(queryGuncelBorc)){
				parameters.put("GUNCEL_BORC", new BigDecimal(DALUtil.getResult(queryGuncelBorc)));
			}else{
				parameters.put("GUNCEL_BORC", BigDecimal.ZERO);
			}
			parameters.put("VADESIZ_HESAP_NO", (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.onceki_basvuru_hesap_no(?)}", Types.VARCHAR, birKrediOdemeplaniGunTx.getBasvuruNo()));

			ArrayDeque<String> reportNames = new ArrayDeque<String>();
			if("E".equals(birBasvuru.getFaizsizFinansman())){
				reportNames.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME_FZ");
			}else{
				reportNames.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME");
			}

			JasperPrint reportOdemePlani = ReportUtil.generateAndConcatReports(reportNames, parameters);
			oMap.put("REPORT", reportOdemePlani);
			oMap.put("PDF_SMS_RESPONSE", "SUCCESS");
            oMap.put("PDF_SMS_RESPONSE_MESSAGE", "");
            
			return oMap;
		}
		catch (Exception e) {
			 e.printStackTrace();
             oMap.put("PDF_SMS_RESPONSE", "ERROR");
             oMap.put("PDF_SMS_RESPONSE_MESSAGE", ExceptionHandler.convertException(e).getMessage());
             return oMap;
		}
		finally {
		}
	}
	
	@GraymoundService("BNSPR_CL_PTT_SMS_YARIM_BASVURU")
	public static GMMap getPttSmsYarimBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap soMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);			
			if(iMap.get("TC_KIMLIK_NO") != null){
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall ( "{? = call pkg_basvuru.get_ptt_sms_yarim_basvuru(?)}" );
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));				
				stmt.execute();
				rSet = (ResultSet) stmt.getObject (1);
				soMap = DALUtil.rSetResultsPutStr(rSet, "PTT_SMS_YARIM_BASVURU");					
			}
			return soMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
}
