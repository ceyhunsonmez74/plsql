package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;


public class ConsumerLoanQRY8064Services {
	
	@GraymoundService("BNSPR_QRY8064_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;		
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc8064.qry8064_sorgula(?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(i++, iMap.getDate("BASVURU_BAS_TAR") != null ? new Date(iMap.getDate("BASVURU_BAS_TAR").getTime()) : null);
			stmt.setDate(i++, iMap.getDate("BASVURU_BIT_TAR") != null ? new Date(iMap.getDate("BASVURU_BIT_TAR").getTime()) : null);
			stmt.setString(i++, iMap.getString("VKN"));
			stmt.setString(i++, iMap.getString("TCKN"));
			stmt.setString(i++, iMap.getString("DURUM"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();
			oMap.putAll(DALUtil.rSetResults((ResultSet) stmt.getObject(1), "BASVURU_LIST"));
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}

	@GraymoundService("BNSPR_QRY8064_ISTIHBARAT_SORGULA")
	public static GMMap istihbaratSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC8064.Basvuru_sorgu_list(?)}");
			stmt.registerOutParameter(1, -10); // ref cursor
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "ISTIHBARAT_LIST";
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "SORGU_NO", rSet.getBigDecimal("SORGU_NO"));
				oMap.put(tableName, i, "SORGU_TIPI", rSet.getString("SORGU_TIPI"));
				oMap.put(tableName, i, "SORGU_TIPI_ACK", rSet.getString("SORGU_TIPI_ACK"));
				oMap.put(tableName, i, "SORGU_SONUC", rSet.getString("SORGU_SONUC"));
				oMap.put(tableName, i, "RED_ACIKLAMA", rSet.getString("RED_ACIKLAMA"));
				oMap.put(tableName, i, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));

				i++;
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
		
}
