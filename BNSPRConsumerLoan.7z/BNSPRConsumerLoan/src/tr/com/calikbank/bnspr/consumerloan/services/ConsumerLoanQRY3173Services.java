package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3173Services {

	@GraymoundService("BNSPR_QRY3173_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruGuncelleList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try
		{	
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3173.RC_QRY3173_BASVURU_IZLEME_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, iMap.getString("ADI"));
			stmt.setString(i++, iMap.getString("IKINCI_ADI"));
			stmt.setString(i++, iMap.getString("SOYADI"));
			stmt.setString(i++, iMap.getString("KAMP_URUN_ADI"));
			stmt.setString(i++, iMap.getString("DURUM"));
			if(iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else 
				stmt.setDate(i++, null);
			if(iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(i++,  new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else 
				stmt.setDate(i++, null);
			
			if (iMap.getBoolean("IPTAL") == true)
				stmt.setString (i++, "TRUE");
			else
				stmt.setString (i++, "FALSE");
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_ALT_KODU"));
			stmt.setString(i++, iMap.getString("ALINACAK_AKSIYON"));
			if (iMap.getBoolean("TESLIMAT_YAPILABILIR_MI") == true)
				stmt.setString (i++, "TRUE");
			else
				stmt.setString (i++, "FALSE");
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
		    return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3173_ONAY_STATU_LIST")
	public static GMMap getOnayStatuList(GMMap iMap){
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "DURUM");
		iMap.put("LIST_QUERY", "Select distinct text, text From V_ML_GNL_PARAM_TEXT t Where t.kod  = upper('ONAY_STATU_KOD') and exists (select 1 from bir_basvuru where durum_kodu=t.KEY1 and  ((durum_kodu!='BASVURU' ) or (t.Key2=aksiyon_kod or aksiyon_kod is null)))");
		return DALUtil.fillComboBox(iMap);
	}
	
	@GraymoundService("BNSPR_QRY3173_ALINACAK_AKSIYON_LIST")
	public static GMMap getAlinacakAksiyonList(GMMap iMap){
		GMMap oMap = new GMMap();
		iMap.put("ISLEM_TUR", "VIEW");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_ERKEN_BELGE_BASIM_DURUM", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3173_CHECK_BASVURU")
	public static GMMap checkBasvuru(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.KanaldaBasvuruVarMi(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3173_GET_DATES")
	public static GMMap getDates(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Date toDay;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_muhasebe.Banka_Tarihi_Bul()}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.execute();
			toDay = stmt.getDate(1);
			
			BigDecimal ayOnce = new BigDecimal(-1);
			stmt = conn.prepareCall("{? = call pkg_tarih.ay_sonra(?,?)}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.setDate(2, toDay) ;
			stmt.setBigDecimal(3, ayOnce);
			stmt.execute();
			oMap.put("BASLANGIC_TARIHI", stmt.getDate(1));
			oMap.put("BITIS_TARIHI", toDay);
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3173_GET_TESLIMAT")
    public static GMMap getTeslimatBilgi(GMMap iMap){
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call Pkg_rc3173.get_teslimat_bilgileri(?,?,?)}");
            stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
            stmt.registerOutParameter(2, -10);
            stmt.registerOutParameter(3, -10);
            stmt.execute();

            rSet = (ResultSet) stmt.getObject(2);

           
            GMMap oMap = new GMMap();
            int row = 0; 
            while(rSet.next()){ 
                oMap.put("BASVURU_NO", rSet.getObject("BASVURU_NO"));
                oMap.put("BASVURAN_AD", rSet.getObject("BASVURAN_AD"));
                oMap.put("BASVURAN_TCKN", rSet.getObject("BASVURAN_TCKN"));
                oMap.put("BASVURU_TARIHI", rSet.getObject("BASVURU_TARIHI"));
                oMap.put("MUHTARLIK_ADRES_EHB", rSet.getObject("MUHTARLIK_ADRES_EHB"));
                oMap.put("TESLIMAT_ADRES_AYNI_EH", rSet.getObject("TESLIMAT_ADRES_AYNI_EH"));
                oMap.put("GEC_TESLIMAT_NEDEN", rSet.getObject("GEC_TESLIMAT_NEDEN"));
                oMap.put("TESLIMAT_KISI", rSet.getObject("TESLIMAT_KISI"));
                oMap.put("TESLIMAT_KISI_TCKN", rSet.getObject("TESLIMAT_KISI_TCKN"));
                oMap.put("TESLIMAT_ADRESI", rSet.getObject("TESLIMAT_ADRESI"));
                oMap.put("TESLIMAT_ADR_IL_KOD", rSet.getObject("TESLIMAT_ADR_IL_KOD"));
                oMap.put("TESLIMAT_ADR_ILCE_KOD", rSet.getObject("TESLIMAT_ADR_ILCE_KOD"));
                oMap.put("TESLIMAT_POSTAKOD", rSet.getObject("TESLIMAT_POSTAKOD"));
                oMap.put("KIMLIK2_TIP", rSet.getObject("KIMLIK2_TIP"));
                if(StringUtils.isNotBlank(rSet.getString("KIMLIK2_KART_ILK6"))){
                    oMap.put("KART1", rSet.getString("KIMLIK2_KART_ILK6").substring(0,4));
                    oMap.put("KART2", rSet.getString("KIMLIK2_KART_ILK6").substring(4));
                }
                oMap.put("KART3", rSet.getString("KIMLIK2_KART_SON4"));
                
                /** TY-6310 TY-tahsis izleme ekranlar�na teslimat adresi farkl� olma nedeni eklenmesi hk. */                
                GMMap tMap = new GMMap();
                tMap.put("TESLIMAT_FARKLI_OLMA_NEDENI", rSet.getObject("TESLIMAT_FARKLI_OLMA_NEDENI"));
                tMap.put("TESLIMAT_URUN_KIME", rSet.getObject("TESLIMAT_KISI"));
				oMap.put("TESLIMAT_FARKLI_OLMA_NEDENI_DESC", GMServiceExecuter.execute("BNSPR_TRN3172_GET_TESLIMAT_FARKLI_OLMA_NEDENI_DESCRIPTION", tMap).get("TESLIMAT_FARKLI_OLMA_NEDENI_DESC"));
            }
            rSet.close();
            
            rSet = (ResultSet) stmt.getObject(3);
            
            String tableName = "URUN_TABLE";
            
            while (rSet.next()) {
                oMap.put(tableName, row, "AD", rSet.getObject("AD"));
                oMap.put(tableName, row, "TUTAR", rSet.getObject("TUTAR"));
                oMap.put(tableName, row, "MALNO", rSet.getObject("MALNO"));
                oMap.put(tableName, row, "ADET", rSet.getObject("ADET"));
                oMap.put(tableName, row, "MODEL", rSet.getObject("MODEL"));
                row++;
            }
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
            GMServerDatasource.close(rSet);
        }
    }
	
}
