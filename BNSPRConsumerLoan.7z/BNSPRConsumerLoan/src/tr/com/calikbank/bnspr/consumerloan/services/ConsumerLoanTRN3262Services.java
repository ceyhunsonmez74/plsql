package tr.com.calikbank.bnspr.consumerloan.services;

import java.text.SimpleDateFormat;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirGarantordenKapamaTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3262Services {

	@GraymoundService("BNSPR_TRN3262_SAVE")
	public static Map<?, ?> saveTRN3262(GMMap iMap) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirGarantordenKapamaTx birGarantordenKapamaTx = (BirGarantordenKapamaTx) session.get(BirGarantordenKapamaTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if (birGarantordenKapamaTx == null)
				birGarantordenKapamaTx = new BirGarantordenKapamaTx();
			
			birGarantordenKapamaTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birGarantordenKapamaTx.setBazFaizOrani(iMap.getBigDecimal("BAZ_FAIZ_ORANI"));
			birGarantordenKapamaTx.setBsmvOrani(iMap.getBigDecimal("BSMV_ORANI"));
			birGarantordenKapamaTx.setDistBakiyesindenIsleyenFaiz(iMap.getBigDecimal("DIST_BAKIYESI_ISLEYEN_FAIZ"));
			birGarantordenKapamaTx.setDistributordenAlinacakTutar(iMap.getBigDecimal("DIST_ALINACAK_TUTAR"));
			birGarantordenKapamaTx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAFI_TUTARI"));
			birGarantordenKapamaTx.setDosyaMasrafiBsmv(iMap.getBigDecimal("DOSYA_MASRAFI_BSMV_TUTARI"));
			birGarantordenKapamaTx.setDosyaMasrafiNet(iMap.getBigDecimal("NET_DOSYA_MASRAFI_TUTARI"));
			birGarantordenKapamaTx.setFaizGelirindenIadeTutari(iMap.getBigDecimal("FAIZ_GELIRINDEN_IADE_TUTARI"));
			birGarantordenKapamaTx.setFaizHesaplamadaBazTutar(iMap.getBigDecimal("FAIZ_HESAPLAMADA_BAZ_TUTAR"));
			birGarantordenKapamaTx.setFarkFaiziBsmvTutari(iMap.getBigDecimal("FARK_FAIZI_BSMV_TUTARI"));
			birGarantordenKapamaTx.setFarkFaiziKkdfTutari(iMap.getBigDecimal("FARK_FAIZI_KKDF_TUTARI"));
			birGarantordenKapamaTx.setFarkFaiziNet(iMap.getBigDecimal("NET_FARK_FAIZI_TUTARI"));
			birGarantordenKapamaTx.setFarkFaiziTutari(iMap.getBigDecimal("FARK_FAIZI_TUTARI"));
			birGarantordenKapamaTx.setFeragatEdilecekGecikmeFaizi(iMap.getBigDecimal("FERAGAT_EDILECEK_GECIKME_FAIZI"));
			birGarantordenKapamaTx.setGarantorBlokajHesapNo(iMap.getBigDecimal("GRNTR_FIRMA_BLOKAJ_HESAP_NO"));
			birGarantordenKapamaTx.setGecenGunSayisi(iMap.getBigDecimal("GECEN_GUN_SAYISI"));
			birGarantordenKapamaTx.setIndirimliFaizOrani(iMap.getBigDecimal("INDIRIMLI_FAIZ_ORANI"));
			birGarantordenKapamaTx.setKalanAnapara(iMap.getBigDecimal("KALAN_ANAPARA"));
			birGarantordenKapamaTx.setKapamaTarihi(iMap.getDate("KAPAMA_TARIHI"));
			birGarantordenKapamaTx.setKapamaTutari(iMap.getBigDecimal("KAPAMA_TUTARI"));
			birGarantordenKapamaTx.setKatkiPayiTutari(iMap.getBigDecimal("KATKI_PAYI_TUTARI"));
			birGarantordenKapamaTx.setKatkiPayiTutariBsmv(iMap.getBigDecimal("KATKI_PAYI_BSMV_TUTARI"));
			birGarantordenKapamaTx.setKatkiPayiTutariKkdf(iMap.getBigDecimal("KATKI_PAYI_KKDF_TUTARI"));
			birGarantordenKapamaTx.setKatkiPayiTutariNet(iMap.getBigDecimal("NET_KATKI_PAYI_TUTARI"));
			birGarantordenKapamaTx.setKkdfOrani(iMap.getBigDecimal("KKDF_ORANI"));
			birGarantordenKapamaTx.setKrediTutari(iMap.getBigDecimal("KREDI_TUTARI"));
			birGarantordenKapamaTx.setKullandirimTarihi(StringUtils.isNotBlank(iMap.getString("KULLANDIRIM_TARIHI")) ? sdf.parse(iMap.getString("KULLANDIRIM_TARIHI")) : null);
			birGarantordenKapamaTx.setMusteriAdi(iMap.getString("MUSTERI_ADI"));
			birGarantordenKapamaTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birGarantordenKapamaTx.setMusteriVadesizHesapNo(iMap.getBigDecimal("MUSTERI_VADESIZ_HESAP_NO"));
			birGarantordenKapamaTx.setSonOdenenTaksitTarihi(StringUtils.isNotBlank(iMap.getString("SON_ODENEN_TAKSIT_TARIHI")) ? sdf.parse(iMap.getString("SON_ODENEN_TAKSIT_TARIHI")) : null);
			birGarantordenKapamaTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birGarantordenKapamaTx.setBazfaizUzerindenIsleyenFaiz(iMap.getBigDecimal("BAZFAIZ_UZERINDEN_ISLEYEN_FAIZ"));
			
			if (iMap.getBoolean("GARANTORDEN_KAPAMA_YAPILACAK_MI")){
				birGarantordenKapamaTx.setGarantordenKapamaYapilacakmi("E");
			}	
			else{
				birGarantordenKapamaTx.setGarantordenKapamaYapilacakmi("H");
			}
			
			session.saveOrUpdate(birGarantordenKapamaTx);
			session.flush();

			iMap.put("TRX_NAME", "3262");

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

		
	@GraymoundService("BNSPR_TRN3262_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
	try{
		Session session = DAOSession.getSession("BNSPRDal");
		BirGarantordenKapamaTx birGarantordenKapamaTx = (BirGarantordenKapamaTx) session.get(BirGarantordenKapamaTx.class, iMap.getBigDecimal("TRX_NO"));
		
		oMap.put("BASVURU_NO", birGarantordenKapamaTx.getBasvuruNo());
		oMap.put("BAZ_FAIZ_ORANI", birGarantordenKapamaTx.getBazFaizOrani());
		oMap.put("BSMV_ORANI", birGarantordenKapamaTx.getBsmvOrani());
		oMap.put("DIST_BAKIYESI_ISLEYEN_FAIZ", birGarantordenKapamaTx.getDistBakiyesindenIsleyenFaiz());
		oMap.put("DIST_ALINACAK_TUTAR", birGarantordenKapamaTx.getDistributordenAlinacakTutar());
		oMap.put("DOSYA_MASRAFI_TUTARI", birGarantordenKapamaTx.getDosyaMasrafi());
		oMap.put("DOSYA_MASRAFI_BSMV_TUTARI", birGarantordenKapamaTx.getDosyaMasrafiBsmv());
		oMap.put("NET_DOSYA_MASRAFI_TUTARI", birGarantordenKapamaTx.getDosyaMasrafiNet());
		oMap.put("FAIZ_GELIRINDEN_IADE_TUTARI", birGarantordenKapamaTx.getFaizGelirindenIadeTutari());
		oMap.put("FAIZ_HESAPLAMADA_BAZ_TUTAR", birGarantordenKapamaTx.getFaizHesaplamadaBazTutar());
		oMap.put("FARK_FAIZI_BSMV_TUTARI", birGarantordenKapamaTx.getFarkFaiziBsmvTutari());	
		oMap.put("FARK_FAIZI_KKDF_TUTARI", birGarantordenKapamaTx.getFarkFaiziKkdfTutari());
		oMap.put("NET_FARK_FAIZI_TUTARI", birGarantordenKapamaTx.getFarkFaiziNet());
		oMap.put("FARK_FAIZI_TUTARI", birGarantordenKapamaTx.getFarkFaiziTutari());
		oMap.put("FERAGAT_EDILECEK_GECIKME_FAIZI", birGarantordenKapamaTx.getFeragatEdilecekGecikmeFaizi());
		oMap.put("GRNTR_FIRMA_BLOKAJ_HESAP_NO", birGarantordenKapamaTx.getGarantorBlokajHesapNo());
		oMap.put("GECEN_GUN_SAYISI", birGarantordenKapamaTx.getGecenGunSayisi());
		oMap.put("INDIRIMLI_FAIZ_ORANI", birGarantordenKapamaTx.getIndirimliFaizOrani());
		oMap.put("KALAN_ANAPARA", birGarantordenKapamaTx.getKalanAnapara());
		oMap.put("KAPAMA_TARIHI", birGarantordenKapamaTx.getKapamaTarihi());
		oMap.put("KAPAMA_TUTARI", birGarantordenKapamaTx.getKapamaTutari());
		oMap.put("KATKI_PAYI_TUTARI", birGarantordenKapamaTx.getKatkiPayiTutari());
		oMap.put("KATKI_PAYI_BSMV_TUTARI", birGarantordenKapamaTx.getKatkiPayiTutariBsmv());
		oMap.put("KATKI_PAYI_KKDF_TUTARI", birGarantordenKapamaTx.getKatkiPayiTutariKkdf());
		oMap.put("NET_KATKI_PAYI_TUTARI", birGarantordenKapamaTx.getKatkiPayiTutariNet());
		oMap.put("KKDF_ORANI", birGarantordenKapamaTx.getKkdfOrani());
		oMap.put("KREDI_TUTARI", birGarantordenKapamaTx.getKrediTutari());
		oMap.put("KULLANDIRIM_TARIHI", birGarantordenKapamaTx.getKullandirimTarihi()!=null ? sdf.format(birGarantordenKapamaTx.getKullandirimTarihi()) : null);
		oMap.put("MUSTERI_ADI", birGarantordenKapamaTx.getMusteriAdi());
		oMap.put("MUSTERI_NO", birGarantordenKapamaTx.getMusteriNo());
		oMap.put("MUSTERI_VADESIZ_HESAP_NO", birGarantordenKapamaTx.getMusteriVadesizHesapNo());
		oMap.put("SON_ODENEN_TAKSIT_TARIHI", birGarantordenKapamaTx.getSonOdenenTaksitTarihi()!=null ? sdf.format(birGarantordenKapamaTx.getKullandirimTarihi()) : null);
		oMap.put("TRX_NO", birGarantordenKapamaTx.getTxNo());
		oMap.put("GARANTORDEN_KAPAMA_YAPILACAK_MI", birGarantordenKapamaTx.getGarantordenKapamaYapilacakmi());
		oMap.put("BAZFAIZ_UZERINDEN_ISLEYEN_FAIZ", birGarantordenKapamaTx.getBazfaizUzerindenIsleyenFaiz());
	    return oMap;
	    
	    } 
		catch (Exception e) {
	    throw ExceptionHandler.convertException(e);
	    }

	}
	@GraymoundService("BNSPR_TRN3262_GARANTOR_KAPAMA_HESAPLA")
	public static GMMap calculate(GMMap iMap){
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");		
		GMMap oMap = new GMMap();
        try {

            String procStr = "{ call PKG_TRN3262.Garantor_Kapama_Hesapla(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
            Object[] inputValues = new Object[24];
            Object[] outputValues = new Object[16];
            int i = 0;
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("KREDI_TUTARI");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("NET_DOSYA_MASRAFI_TUTARI");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("NET_KATKI_PAYI_TUTARI");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("NET_FARK_FAIZI_TUTARI");
            inputValues[i++] = BnsprType.DATE;
            inputValues[i++] = iMap.getDate("KAPAMA_TARIHI");
            inputValues[i++] = BnsprType.DATE;
            inputValues[i++] = StringUtils.isNotBlank(iMap.getString("SON_ODENEN_TAKSIT_TARIHI")) ? sdf.parse(iMap.getString("SON_ODENEN_TAKSIT_TARIHI")) : null;
            inputValues[i++] = BnsprType.DATE;
            inputValues[i++] = StringUtils.isNotBlank(iMap.getString("KULLANDIRIM_TARIHI")) ? sdf.parse(iMap.getString("KULLANDIRIM_TARIHI")) : null;
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("BAZ_FAIZ_ORANI");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("KALAN_ANAPARA");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("KKDF_ORANI");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("BSMV_ORANI");
            
            
            i = 0;
            outputValues[i++] = BnsprType.NUMBER;
            outputValues[i++] = "FAIZ_HESAPLAMADA_BAZ_TUTAR";
            outputValues[i++] = BnsprType.NUMBER;
            outputValues[i++] = "DIST_BAKIYESI_ISLEYEN_FAIZ";
            outputValues[i++] = BnsprType.NUMBER;
            outputValues[i++] = "GECEN_GUN_SAYISI";
            outputValues[i++] = BnsprType.NUMBER;
            outputValues[i++] = "KAPAMA_TUTARI";
            outputValues[i++] = BnsprType.NUMBER;
            outputValues[i++] = "FAIZ_GELIRINDEN_IADE_TUTARI";
            outputValues[i++] = BnsprType.NUMBER;
            outputValues[i++] = "DIST_ALINACAK_TUTAR";
            outputValues[i++] = BnsprType.NUMBER;
            outputValues[i++] = "FERAGAT_EDILECEK_GECIKME_FAIZI";
            outputValues[i++] = BnsprType.NUMBER;
            outputValues[i++] = "BAZFAIZ_UZERINDEN_ISLEYEN_FAIZ";
            
            oMap.putAll((GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues));


        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
	
	}
}
