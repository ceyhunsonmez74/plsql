package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruistTcmbTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruistTcmbTxId;
import tr.com.aktifbank.bnspr.dao.GnlEkranAlanRolTanim;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuruFraudTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruistTcmbKayitTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruistTcmbKayitTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3189Services {
	@GraymoundService("BNSPR_TRN3189_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();

			String listName = "DURUM"; 
			GuimlUtil.wrapMyCombo(oMap, listName, "X", " ");
			GuimlUtil.wrapMyCombo(oMap, listName, "B", "Benzer");
			GuimlUtil.wrapMyCombo(oMap, listName, "K", "Kesin");
			GuimlUtil.wrapMyCombo(oMap, listName, "Y", "Yok");
			GuimlUtil.wrapMyCombo(oMap, listName, "Z", "Kesin-Fraud Yok");

			iMap.put("KOD", "FRAUD_SONUC_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("FRAUD_KARAR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			iMap.put("KOD", "FRAUD_NEDEN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("FRAUD_GEREKCE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			iMap.put("KOD", "KARA_LISTE_KAYNAK_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KARA_LISTE_KAYNAK_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			listName = "FRAUD_KARAR_2SIZ";

			DALUtil.fillComboBox(oMap, listName, true, "SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'FRAUD_SONUC_KOD' and key1 <>'2' ORDER BY SIRA_NO");

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3189_GET_FRAUD_NEDEN_KOD")
	public static GMMap getFraudNedenKod(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "FRAUD_GEREKCE", true, "select key1,text from v_ml_gnl_param_text where kod = 'FRAUD_NEDEN_KOD' and key2 = '"+iMap.getString("FRAUD_KARAR")+"'  order by sira_no");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3189_GET_KARA_LISTE_KAYIT_KOD")
	public static GMMap getKaraListeKayitKategori(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			//Sahtecilik,��pheli Durum 
			if("1".equals(iMap.getString("FRAUD_KARAR")))
				DALUtil.fillComboBox(oMap, "KARA_LISTE_DURUM_KOD", true, "select key1,text from v_ml_gnl_param_text where kod = 'KARA_LISTE_DURUM_KOD' and key1 in ('1')  order by sira_no");
			else if("3".equals(iMap.getString("FRAUD_KARAR")))
				DALUtil.fillComboBox(oMap, "KARA_LISTE_DURUM_KOD", true, "select key1,text from v_ml_gnl_param_text where kod = 'KARA_LISTE_DURUM_KOD' and key1 in ('2')  order by sira_no");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3189_GET_KARA_LISTE_TARAF_KOD")
	public static GMMap getKaraListeTarafKod(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			//Ma�dur, Sahtekar,��pheli secilebiliyor
			DALUtil.fillComboBox(oMap, "KARA_LISTE_TARAF_KOD", true, "select key1,text from v_ml_gnl_param_text where kod = 'KARA_LISTE_TARAF_KOD' and key2 = '"+iMap.getString("KARA_LISTE_DURUM_KOD")+"'  order by sira_no");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3189_GET_KARA_LISTE_KAYIT_SEBEP_KOD")
	public static GMMap getKaraListeKayitSebepKod(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "KARA_LISTE_KAYIT_SEBEP_KOD", true, "select key1,text from v_ml_gnl_param_text where kod = 'KARA_LISTE_KAYIT_SEBEP_KOD' and key2 = '"+iMap.getString("KARA_LISTE_DURUM_KOD")+"' order by sira_no");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3189_GET_SORGU_LIST")
	public static GMMap getSorguList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3189.RC_QRY3189_GET_SORGU_LIST(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet)stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet,"RESULTS"));
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);

			List<?> ozetList=(List<?>) oMap.get("RESULTS");
			if(ozetList!=null){
				for(int i=0;i<ozetList.size();i++){
					stmt = conn.prepareCall("{? = call PKG_TRN3189.RC_QRY3189_GET_CAPRAZ_KAYIT(?,?)}");
					stmt.registerOutParameter(1, -10);
					
					stmt.setBigDecimal(2, oMap.getBigDecimal("RESULTS", i, "ID"));
					stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
					
					stmt.execute();
					stmt.getMoreResults();
					rSet = (ResultSet)stmt.getObject(1);

					oMap.put("RESULTS", i, "CAPRAZ_MODEL", DALUtil.rSetResults(rSet,"RESULTS").get("RESULTS"));
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);
					
					stmt = conn.prepareCall("{? = call PKG_RC3927.RC_QRY3927_GET_KARA_LISTE(?)}");
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, oMap.getBigDecimal("RESULTS", i, "ID"));

					stmt.execute();
					stmt.getMoreResults();
					rSet = (ResultSet)stmt.getObject(1);

					oMap.put("RESULTS", i, "KARA_MODEL", DALUtil.rSetResults(rSet,"RESULTS").get("RESULTS"));
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3189_CHECK_KESIN_DURUM")
	public static GMMap checkKesinDurum(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			List<?> ozetList=(List<?>) iMap.get("OZET_TABLE");
			if(ozetList!=null){
				for(int i=0;i<ozetList.size();i++){

					List<?> caprazList=(List<?>) iMap.get("OZET_TABLE", i, "CAPRAZ_MODEL");
					if(caprazList!=null){
						for(int j=0;j<caprazList.size();j++){
							GMMap caprazListMap = new GMMap((HashMap<?, ?>)caprazList.get(j));
							//	if(caprazListMap.getString("IST_DURUM").equals("K")||(caprazListMap.getString("IST_DURUM").equals("X") && "K".equals(caprazListMap.getString("SONUC")))){
							if(caprazListMap.getString("IST_DURUM").equals("K")){
								oMap.put("KESIN_DURUM",		"K");
								return oMap;
							}							
						}
					}

					List<?> karaList=(List<?>) iMap.get("OZET_TABLE", i, "KARA_MODEL");
					if(karaList!=null){
						for(int j=0;j<karaList.size();j++){
							GMMap karaListMap = new GMMap((HashMap<?, ?>)karaList.get(j));
							//	if(karaListMap.getString("IST_DURUM").equals("K")||(karaListMap.getString("IST_DURUM").equals("X") && "K".equals(karaListMap.getString("DURUM")))){
							if(karaListMap.getString("IST_DURUM").equals("K")){
								oMap.put("KESIN_DURUM",		"K");
								return oMap;
							}

						}
					}
				}
			}

			// comment outs for BK-3216

			oMap.put("KESIN_DURUM",		"Y");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}



	@GraymoundService("BNSPR_QRY3189_GET_CAPRAZ_KAYIT")
	public static GMMap getCaprazKayitList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3189.RC_QRY3189_GET_CAPRAZ_KAYIT(? ,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ID"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet,"RESULTS");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN3189_GET_DETAY_LIST")
	public static GMMap getDetayList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3189.RC_QRY3189_GET_DETAY_LIST(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ID"));
			stmt.setString(3, iMap.getString("SORGU_KOD"));
			stmt.setString(4, iMap.getString("KIM_ICIN"));

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet,"RESULTS");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN3189_DECODE_BASVURU_FRAUD_DATA")
	public static GMMap decodeBasvuruFraudData(GMMap iMap){
		try{
			GMMap oMap = new GMMap();

			oMap.put("EV_ADR_IL_KOD", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod ='"+iMap.getString("EV_ADR_IL_KOD")+"' "));
			oMap.put("EV_ADR_ILCE_KOD", DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("EV_ADR_IL_KOD")+"' and ilce_kod ='"+iMap.getString("EV_ADR_ILCE_KOD")+"'"));
			oMap.put("IS_ADR_IL_KOD", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod ='"+iMap.getString("IS_ADR_IL_KOD")+"' "));
			oMap.put("IS_ADR_ILCE_KOD", DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("IS_ADR_IL_KOD")+"' and ilce_kod ='"+iMap.getString("IS_ADR_ILCE_KOD")+"'"));

			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	@GraymoundService("BNSPR_TRN3189_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirBasvuruFraudTx birBasvuruFraudTx = (BirBasvuruFraudTx) session.createCriteria(BirBasvuruFraudTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if(birBasvuruFraudTx == null)
				birBasvuruFraudTx = new BirBasvuruFraudTx();

			birBasvuruFraudTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruFraudTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruFraudTx.setKaralisteyeEklensinEh(iMap.getString("KARA_LISTEYE_EKLENSIN"));
			birBasvuruFraudTx.setKayitKategorisi(iMap.getString("KARA_LISTE_DURUM_KOD"));
			birBasvuruFraudTx.setTarafBilgisi(iMap.getString("KARA_LISTE_TARAF_KOD"));
			birBasvuruFraudTx.setKaynak(iMap.getString("KARA_LISTE_KAYNAK_KOD"));
			birBasvuruFraudTx.setKayitSebebi(iMap.getString("KARA_LISTE_KAYIT_SEBEP_KOD"));
			birBasvuruFraudTx.setFraudSonucKod(iMap.getString("FRAUD_KARAR"));
			birBasvuruFraudTx.setFraudKaynakKod(iMap.getString("FRAUD_KAYNAK_KOD"));
			birBasvuruFraudTx.setFraudNedenKod(iMap.getString("FRAUD_GEREKCE"));
			birBasvuruFraudTx.setGorus(iMap.getString("GORUS"));
			birBasvuruFraudTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			birBasvuruFraudTx.setDogrulamaTahsisGorus(iMap.getString("DT_GORUS"));
			session.saveOrUpdate(birBasvuruFraudTx);

			String fraudTableName = "OZET_TABLE";
			String caprazTableName = "CAPRAZ_MODEL";
			String karaTableName = "KARA_MODEL";

			String temp;

			List<?> fraudList = (List<?>) iMap.get(fraudTableName);
			if(fraudList != null){				
				for (int i = 0; i < fraudList.size(); i++) {

					String karaSonuc = 		"Y";
					String caprazSonuc = 	"Y";

					List<?> caprazList = (List<?>) iMap.get(fraudTableName	,i	,caprazTableName);
					if(caprazList != null){
						for (int j = 0; j < caprazList.size(); j++) {
							GMMap caprazListMap = new GMMap((HashMap<?, ?>)caprazList.get(j));
							if(caprazListMap.getString("IST_DURUM").equals("X")){
								temp = caprazListMap.getString("SONUC");
							}else{
								temp = caprazListMap.getString("IST_DURUM");

								BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx = (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kayitId", caprazListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
								if(birBasvuruistTcmbKayitTx == null)
								{
									birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO"),caprazListMap.getBigDecimal("KAYIT_ID")));
								}

								birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
								birBasvuruistTcmbKayitTx.setTahsisSonuc(caprazListMap.getString("IST_DURUM"));
								birBasvuruistTcmbKayitTx.setSorguTip("E");
								birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(fraudTableName	,i	,"ID"));

								session.saveOrUpdate(birBasvuruistTcmbKayitTx);
							}
							if(temp.equals("Y") && !( caprazSonuc.equals("B")||caprazSonuc.equals("K"))){
								caprazSonuc = "Y";
							}
							if(temp.equals("B") && !caprazSonuc.equals("K")){
								caprazSonuc = "B";
							}
							if(temp.equals("K") || temp.equals("Z")){
								caprazSonuc = "K";
							}

						}
					}
					List<?> karaList = (List<?>) iMap.get(fraudTableName	,i	,karaTableName);
					if(karaList != null){

						for (int j = 0; j < karaList.size(); j++) {
							GMMap karaListMap = new GMMap((HashMap<?, ?>)karaList.get(j));
							if(karaListMap.getString("IST_DURUM").equals("X")){
								temp = karaListMap.getString("DURUM");
							}else{
								temp = karaListMap.getString("IST_DURUM");

								BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx = (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kayitId", karaListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
								if(birBasvuruistTcmbKayitTx == null)
								{
									birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO"),karaListMap.getBigDecimal("KAYIT_ID")));
								}

								birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
								birBasvuruistTcmbKayitTx.setTahsisSonuc(karaListMap.getString("IST_DURUM"));
								birBasvuruistTcmbKayitTx.setSorguTip("B");
								birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(fraudTableName	,i	,"ID"));

								session.saveOrUpdate(birBasvuruistTcmbKayitTx);
							}

							if(temp.equals("Y") && !( karaSonuc.equals("B")||karaSonuc.equals("K"))){
								karaSonuc = "Y";
							}
							if(temp.equals("B") && !karaSonuc.equals("K")){
								karaSonuc = "B";
							}
							if(temp.equals("K") || temp.equals("Z")){
								karaSonuc = "K";
							}

						}
					}

					if(!(karaSonuc.equals(iMap.getString(fraudTableName	,i	,"KARA_LISTE_SONUC")) && caprazSonuc.equals(iMap.getString(fraudTableName	,i	,"ESKI_BASVURU_SONUC")))){


						BirBasvuruistTcmbTx birBasvuruistTcmbTx = (BirBasvuruistTcmbTx) session.createCriteria(BirBasvuruistTcmbTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
						.add(Restrictions.eq("id.sorguId", iMap.getBigDecimal(fraudTableName	,i	,"ID"))).uniqueResult();
						if(birBasvuruistTcmbTx == null)
						{
							birBasvuruistTcmbTx = new BirBasvuruistTcmbTx();
							BirBasvuruistTcmbTxId birBasvuruistTcmbTxId = new BirBasvuruistTcmbTxId();
							birBasvuruistTcmbTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
							birBasvuruistTcmbTxId.setSorguId(iMap.getBigDecimal(fraudTableName	,i	,"ID"));
							birBasvuruistTcmbTx.setId(birBasvuruistTcmbTxId);

						}

						birBasvuruistTcmbTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birBasvuruistTcmbTx.setIslemKod("3189");
						birBasvuruistTcmbTx.setCaprazSorguSonuc(caprazSonuc);
						birBasvuruistTcmbTx.setKaraListeSonuc(karaSonuc);

						session.saveOrUpdate(birBasvuruistTcmbTx);

					}
				}
			}

			session.flush();

			if (!iMap.getBoolean("DONT_SEND_TRANSACTION")) {
				iMap.put("TRX_NAME", "3189");
				return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3189_KARA_LISTE_GONDER")
	public static GMMap karaListeGonder(GMMap iMap){
		try{
			GMServiceExecuter.call("BNSPR_BASVURU_SEND_SMS", iMap);

			iMap.put("TRX_NO",DALUtil.callOneParameterFunction("{? = call pkg_trn3189.KaraListeGonder(?)}", Types.DECIMAL, iMap.getBigDecimal("ISLEM_NO")));
			if(iMap.getBigDecimal("TRX_NO") != null)
			{
				iMap.put("TRX_NAME","3921");
				GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			return new GMMap();
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3189_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuruFraudTx birBasvuruFraudTx = (BirBasvuruFraudTx) session.get(BirBasvuruFraudTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("TRX_NO", birBasvuruFraudTx.getTxNo());
			oMap.put("BASVURU_NO", birBasvuruFraudTx.getBasvuruNo());
			oMap.put("KARA_LISTEYE_EKLENSIN", birBasvuruFraudTx.getKaralisteyeEklensinEh());
			oMap.put("KARA_LISTEYE_EKLENSIN_MI", birBasvuruFraudTx.getKaralisteyeEklensinEh()==null?false:birBasvuruFraudTx.getKaralisteyeEklensinEh().equals("E"));
			oMap.put("KARA_LISTE_DURUM_KOD", birBasvuruFraudTx.getKayitKategorisi());
			oMap.put("KARA_LISTE_TARAF_KOD", birBasvuruFraudTx.getTarafBilgisi());
			oMap.put("KARA_LISTE_KAYNAK_KOD", birBasvuruFraudTx.getKaynak());
			oMap.put("KARA_LISTE_KAYIT_SEBEP_KOD", birBasvuruFraudTx.getKayitSebebi());
			oMap.put("FRAUD_KARAR", birBasvuruFraudTx.getFraudSonucKod());
			oMap.put("FRAUD_KAYNAK_KOD", birBasvuruFraudTx.getFraudKaynakKod());
			oMap.put("FRAUD_GEREKCE", birBasvuruFraudTx.getFraudNedenKod());
			oMap.put("GORUS", birBasvuruFraudTx.getGorus());
			oMap.put("DT_GORUS", birBasvuruFraudTx.getDogrulamaTahsisGorus());
			iMap.put("BASVURU_NO", birBasvuruFraudTx.getBasvuruNo());
			oMap.put("TAHSIS_GORUS_LIST", GMServiceExecuter.execute("BNSPR_TRN3174_GET_TAHSIS_GORUS_LIST", iMap).get("TAHSIS_GORUS_LIST"));
			//GMMap oMap = new BnsprPojoLoader(new GMMap(),session.get(BirBasvuruFraudTx.class, iMap.getBigDecimal("TRX_NO")),null).load();
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3189_GET_FRAUD_DETAY")
	public static GMMap getInfoByBasvuru(GMMap iMap) {		
		try {			
			String func = "{? = call PKG_TRN3174.rc_qry3174_get_fraud_detay(?)}";
			Object[] inputValues = {
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") 	
			};		
			GMMap oMap = new GMMap();
			String tableName = "RESULTS";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
			int len = oMap.getSize(tableName);
			if(len>0) {
				Set<?> keySet = oMap.getMap(tableName,0).keySet();
				for(Object key:keySet) {
					String keyName = (String) key;
					Object keyValue = oMap.get(tableName,0,keyName);
					oMap.put(keyName, keyValue);
				}
			}		
			oMap.put("KARALISTEYE_EKLENSIN_MI", oMap.get("KARALISTEYE_EKLENSIN_EH")==null?false:oMap.getString("KARALISTEYE_EKLENSIN_EH").equals("E"));
			oMap.put("TAHSIS_GORUS_LIST", GMServiceExecuter.execute("BNSPR_TRN3174_GET_TAHSIS_GORUS_LIST", iMap).get("TAHSIS_GORUS_LIST"));			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_BASVURU_GECMIS_BILGI")
	public static GMMap getBasvuruGecmisBilgi(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3189.BasvuruGecmisDetay(?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DEGER"));

			stmt.execute();

			rSet1 = (ResultSet)stmt.getObject(1);
			
			SimpleDateFormat outputFormatTime = new SimpleDateFormat("HHmmss");

			String tableName = "GECMIS_TABLE";

			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet1.next()) {
				oMap.put(tableName, j, "DEGER", rSet1.getString("DEGER"));
				oMap.put(tableName, j, "ISLEM_NO", rSet1.getString("ISLEM_NO"));
				oMap.put(tableName, j, "ISLEM_TARIHI", rSet1.getDate("ISLEM_TARIHI"));
				//oMap.put(tableName, j, "ISLEM_SAATI", rSet1.getString("ISLEM_SAATI"));
				oMap.put(tableName, j, "ISLEM_SAATI", outputFormatTime.format(rSet1.getTime("ISLEM_SAATI")));
				
				j++;
			}
			
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_BASVURU_GECMIS_ADRES")
	public static GMMap getBasvuruGecmisAdres(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3189.BasvuruGecmisAdres(?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("DEGER"));
			stmt.setString(i++, iMap.getString("TUR"));

			stmt.execute();

			rSet1 = (ResultSet)stmt.getObject(1);
			
			SimpleDateFormat outputFormatTime = new SimpleDateFormat("HHmmss");

			String tableName = "ADRES_TABLE";

			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet1.next()) {
				oMap.put(tableName, j, "DEGER", rSet1.getString("DEGER"));
			//	oMap.put(tableName, j, "ISLEM_NO", rSet1.getString("ISLEM_NO"));
				oMap.put(tableName, j, "ISLEM_TARIHI", rSet1.getDate("ISLEM_TARIHI"));
				oMap.put(tableName, j, "ISLEM_SAATI", outputFormatTime.format(rSet1.getTime("ISLEM_SAATI")));
				oMap.put(tableName, j, "TUR", rSet1.getString("TUR"));
				
				j++;
			}
			
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_QRY3189_GET_COMPONENT_ROLE")
	public static GMMap getComponentRoles(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<GnlEkranAlanRolTanim> roleList = null;
		String currentRole = StringUtils.EMPTY;
		String alanAdi = iMap.getString("ALAN_ADI");
		BigDecimal islemKod = iMap.getBigDecimal("ISLEM_KOD");
		
		try {
			roleList = (List<GnlEkranAlanRolTanim>) session.createCriteria(GnlEkranAlanRolTanim.class).
						add(Restrictions.eq("id.islemKod", islemKod)).
						add(Restrictions.eq("id.alanAdi", alanAdi)).list();
			
			currentRole = (String) DALUtil.callNoParameterFunction("{? = call pkg_global.get_rolkod}", Types.VARCHAR);
			oMap.put("ANNE_KIZLIK_SOYADI_GORUNUR", false);
			for (GnlEkranAlanRolTanim gnlEkranAlanRolTanim : roleList) {
				if(gnlEkranAlanRolTanim.getErisimliRol() != null && Arrays.asList(gnlEkranAlanRolTanim.getErisimliRol().split(";")).contains(currentRole)){
					oMap.put("ANNE_KIZLIK_SOYADI_GORUNUR", true);
				}
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
}
