package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3140Services {
	
	@GraymoundService("BNSPR_3140_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_KREDI_TIPI");
			oMap.put("BAYI_KREDI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "TASIT_ARAC_TIPI");
			oMap.put("TASIT_ARAC_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		} catch(Exception e) {
			
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3140_GET_HAVUZDAKI_BASVURULAR")
	public static GMMap getHavuzdakiBasvurular(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "IS_HAVUZU";
		try {
			Object[] inputValues = new Object[40];
			int n = 0;
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("MUSTERI_NO");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("DOKUMAN_KOD");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("BELGE_KONTROL");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("ORJ_EVRAK");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("CALISMA_TIPI");
			inputValues[n++] = BnsprType.DATE;
			if (iMap.getDate("BELGE_GELIS_TAR") != null)
				inputValues[n++] = new java.sql.Date(iMap.getDate("BELGE_GELIS_TAR").getTime());
			else
				inputValues[n++] = null;
		
			inputValues[n++] = BnsprType.DATE;
			if (iMap.getDate("BASVURU_BAS_TARIHI") != null)
				inputValues[n++] = new java.sql.Date(iMap.getDate("BASVURU_BAS_TAR").getTime());
			else
				inputValues[n++] = null;
			
			inputValues[n++] = BnsprType.DATE;
			if (iMap.getDate("BASVURU_BIT_TARIHI") != null)
				inputValues[n++] = new java.sql.Date(iMap.getDate("BASVURU_BIT_TAR").getTime());
			else
				inputValues[n++] = null;

			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("LISTELEME_TIP");
			
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("KREDI_TUR");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("KANAL_KOD");
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("GARANTOR");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("BAYI_KREDI_TIPI");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("VERI_GIRISE_BELGE_GELDI");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("KULLANICI_KOD");
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("KAMPANYA_KOD");
			
			inputValues[n++] = BnsprType.DATE;
			if (iMap.getDate("VERI_GIRIS_BASTARIHI") != null)
				inputValues[n++] = new java.sql.Date(iMap.getDate("VERI_GIRIS_BASTARIHI").getTime());
			else
				inputValues[n++] = null;

			inputValues[n++] = BnsprType.DATE;
			if (iMap.getDate("VERI_GIRIS_BITISTARIHI") != null)
				inputValues[n++] = new java.sql.Date(iMap.getDate("VERI_GIRIS_BITISTARIHI").getTime());
			else
				inputValues[n++] = null;

			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("ARAC_TIPI");
			
			String func = "{ ? = call pkg_qry3140.gethavuzdakibasvurular(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? ,? ,?, ?) }";
			oMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		for (int i = 0; i < oMap.getSize(tableName); i++) {
			oMap.put(tableName, i, "TEMINAT", !"-1".equals(oMap.getString(tableName, i, "TEMINAT")));
			oMap.put(tableName, i, "ONCEKI_ADIMA_IADE", "E".equals(oMap.getString(tableName, i, "ONCEKI_ADIMA_IADE")));
			oMap.put(tableName, i, "IPTAL_EDILEBILIR_MI", "E".equals(oMap.getString(tableName, i, "IPTAL_EDILEBILIR_MI")));
			oMap.put(tableName, i, "KONTAKT_MUSTERI", "K".equals(oMap.getString(tableName, i, "KONTAKT_MUSTERI")));
		}

		oMap.put("ROW_COUNT", oMap.getSize(tableName));

		return oMap;
	}

	@GraymoundService("BNSPR_QRY3140_SON_ISLEM_BILGI")
	public static GMMap sonIslemBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_basvuru.SonIslemYapanKullanici(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			GMMap oMap = new GMMap();
			oMap.put("SON_ISLEM_YAPAN_KULLANICI", stmt.getString(1));
			GMServerDatasource.close(stmt);

			stmt = conn.prepareCall("{? = call pkg_basvuru.SonIslemTarihi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			oMap.put("SON_ISLEM_TARIHI", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_QRY3140_ADIMA_IADE")
	public static GMMap oncekiAdimaIade(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.AdimaIade(?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("IADE_DURUM"));
			stmt.setString(3, iMap.getString("IADE_NEDENI"));
			stmt.setString(4, iMap.getString("ESKI_DURUM"));
			stmt.setString(5, iMap.getString("ADI_SOYADI"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_QRY3140_IPTAL")
	public static GMMap iptal(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.HavuzdanIptal(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("AKSIYON_KARAR_KOD"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_TRN3140_GET_TEMINAT_GIRILMIS_MI")
	public static GMMap getTeminatGirilmisMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3132.TeminatGirilmisMi(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3140_GET_TEMINAT_DEGISMIS_MI")
	public static GMMap getTeminatDegismisMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3132.sonradan_eklenen_teminat_mesaj(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3140_ONCEKI_ADIM_LIST")
	public static GMMap getOncekiAdimList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "ONCEKI_ADIM_LIST", true, "select t.key1, t.key1 from v_ml_gnl_param_text t where t.KOD = 'ONAY_STATU_KOD' and t.sira_no < (select sira_no from v_ml_gnl_param_text t where t.KOD = 'ONAY_STATU_KOD' and t.KEY1 = '" + iMap.getString("DURUM_KODU") + "') and sira_no > 1 order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3140_BELGE_DURUM_LIST")
	public static GMMap getBelgeDurumList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "BELGE_DURUM_LIST", true, "select t.key1 key,  T.TEXT value  from v_ml_gnl_param_text t where t.KOD = 'BELGE_KONTROL_KOD' order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3140_BELGE_HATA_LIST")
	public static GMMap getBelgeHataList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "BELGE_HATA_LIST", true, "select t.key1 KEY, t.TEXT VALUE from v_ml_gnl_param_text t where t.KOD = 'BIR_BELGE_HATA' order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3140_CALISMA_SEKLI_LIST")
	public static GMMap getCalismaSekliList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "CALISMA_SEKLI_KOD", true, "select t.key1 key,  T.TEXT value  from v_ml_gnl_param_text t where t.KOD = 'CALISMA_SEKLI_KOD' order by sira_no");
			
			 iMap.put("KOD", "EVET_HAYIR");
	         iMap.put("ADD_EMPTY_KEY", "H");
	        oMap.put("ORJ_EVRAKMI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3140_BASVURU_DURUM_LIST")
	public static GMMap getBasvuruDurumList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "BASVURU_DURUM_LIST", true, "select t.key1 key,  T.TEXT value  from v_ml_gnl_param_text t where t.KOD = 'ONAY_STATU_KOD' order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_QRY3140_ONAY_STATU_LIST")
	public static GMMap getOnayStatuList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1 from v_ml_gnl_param_text where kod = 'ONAY_STATU_KOD' and key1 not in ('KULONAY', 'NBSM', 'JOB', 'KAPANDI') order by sira_no");

			rSet = stmt.executeQuery();
			String listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
			while (rSet.next()) {
				if (rSet.getString(1).equals("KUL"))
					GuimlUtil.wrapMyCombo(oMap, listName, "KUL", "KULLANDIRIM");
				else
					GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(1));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BAYI_LIMIT_IPTAL")
	public static GMMap BNSPR_Bayi_Limit_Iptal(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BAYI_LIMIT.Manuel_Limit_Iade(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, "IPTAL");
			stmt.setString(3, iMap.getString("ISLEM_KOD"));
			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BAYI_LIMIT_IADE_SON_DURUM")
	public static GMMap BNSPR_Bayi_Limit_Iade(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BAYI_LIMIT.Manuel_Limit_Iade(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));

			stmt.setString(2, iMap.getString("AKSIYON_KARAR_KOD"));

			stmt.setString(3, iMap.getString("ISLEM_KOD"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BAYI_LIST_4_MI4BIZ")
	public static GMMap bnsprBayiList4Mi4Biz(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {

			String query = "SELECT s.KOD, s.SATICI_ADI, s.MUSTERI_NO, s.TANIMLAMA_TAR, s.SATICI_TIP_KOD, s.BAGLI_MERKEZ_BAYI, " + "s.KURULUS_TAR,s.KRD_TUR_KODLARI, s.YETKI_SEVIYE_KOD, s.ONEM_DERECE_KOD, s.TESVIK_UYGULAMA_EH, s.TESVIK_FARKLI_EH, " + "s.TESVIK_UYGULAMA_EH, s.TESVIK_FARKLI_EH, s.BELGE_GON_FAKS_EH, s.BELGE_GON_EMAIL_EH, s.ADRES, s.ALAN_KOD_TEL, s.TEL_NO, " + "s.ALAN_KOD_FAKS, s.FAKS_NO, s.EMAIL, s.WEB_ADRES, s.BANKA_KOD, s.BANKA_SUBE, s.BANKA_HESAP, s.PARA_CIKIS_OTO_EH, s.SATIS_GORUS_KOD, " + "s.DRM, s.BAGLI_OLD_BOLGE_KOD, s.DOK_YOLLAMA_KOD, s.ACIKLAMA, s.HESAP_NO, s.ADRES_IL, s.ADRES_ILCE, s.TESVIK_PUAN, s.BAYI_SORUMLU_KISI, s.PORTFOY_KOD, " + "s.SUBE_MUSTERI_NO, s.DISTRIBUTOR_HESAP_NO, s.SIGORTA_SATISI_EH, si.BAGLI_OLD_SAT_KOD " + "FROM bir_satici s " + "left outer join bir_satici_iliski si " + "on s.kod = si.satici_kod " + "where s.drm = 'G' and s.satici_tip_kod in ('M', 'S', 'D')";

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(query);
			stmt.execute();
			rSet = stmt.getResultSet();
			while (rSet.next()) {
				String kod = rSet.getString("KOD");

				if (oMap.get(kod) == null) {
					oMap.put(kod, new GMMap());
					GMMap bayiMap = oMap.getMap(kod);

					bayiMap.put("HESAP_NO", rSet.getString("HESAP_NO"));
					bayiMap.put("ADRES_IL", rSet.getString("ADRES_IL"));
					bayiMap.put("ADRES_ILCE", rSet.getString("ADRES_ILCE"));
					bayiMap.put("TESVIK_PUAN", rSet.getString("TESVIK_PUAN"));
					bayiMap.put("BAYI_SORUMLU_KISI", rSet.getString("BAYI_SORUMLU_KISI"));
					bayiMap.put("PORTFOY_KOD", rSet.getString("PORTFOY_KOD"));
					bayiMap.put("SUBE_MUSTERI_NO", rSet.getString("SUBE_MUSTERI_NO"));
					bayiMap.put("DISTRIBUTOR_HESAP_NO", rSet.getString("DISTRIBUTOR_HESAP_NO"));
					bayiMap.put("SIGORTA_SATISI_EH", rSet.getString("SIGORTA_SATISI_EH"));
					bayiMap.put("SATICI_ADI", rSet.getString("SATICI_ADI"));
					bayiMap.put("MUSTERI_NO", rSet.getString("MUSTERI_NO"));
					bayiMap.put("TANIMLAMA_TAR", rSet.getString("TANIMLAMA_TAR"));
					bayiMap.put("SATICI_TIP_KOD", rSet.getString("SATICI_TIP_KOD"));
					bayiMap.put("BAGLI_MERKEZ_BAYI", rSet.getString("BAGLI_MERKEZ_BAYI"));
					bayiMap.put("KURULUS_TAR", rSet.getString("KURULUS_TAR"));
					bayiMap.put("KRD_TUR_KODLARI", rSet.getString("KRD_TUR_KODLARI"));
					bayiMap.put("YETKI_SEVIYE_KOD", rSet.getString("YETKI_SEVIYE_KOD"));
					bayiMap.put("ONEM_DERECE_KOD", rSet.getString("ONEM_DERECE_KOD"));
					bayiMap.put("TESVIK_UYGULAMA_EH", rSet.getString("TESVIK_UYGULAMA_EH"));
					bayiMap.put("TESVIK_FARKLI_EH", rSet.getString("TESVIK_FARKLI_EH"));
					bayiMap.put("ALAN_KOD_FAKS", rSet.getString("ALAN_KOD_FAKS"));
					bayiMap.put("FAKS_NO", rSet.getString("FAKS_NO"));
					bayiMap.put("EMAIL", rSet.getString("EMAIL"));
					bayiMap.put("WEB_ADRES", rSet.getString("WEB_ADRES"));
					bayiMap.put("BANKA_KOD", rSet.getString("BANKA_KOD"));
					bayiMap.put("BANKA_SUBE", rSet.getString("BANKA_SUBE"));
					bayiMap.put("BANKA_HESAP", rSet.getString("BANKA_HESAP"));
					bayiMap.put("PARA_CIKIS_OTO_EH", rSet.getString("PARA_CIKIS_OTO_EH"));
					bayiMap.put("SATIS_GORUS_KOD", rSet.getString("SATIS_GORUS_KOD"));
					bayiMap.put("DRM", rSet.getString("DRM"));
					bayiMap.put("BAGLI_OLD_BOLGE_KOD", rSet.getString("BAGLI_OLD_BOLGE_KOD"));
					bayiMap.put("DOK_YOLLAMA_KOD", rSet.getString("DOK_YOLLAMA_KOD"));
					bayiMap.put("ACIKLAMA", rSet.getString("ACIKLAMA"));
					oMap.put(kod, bayiMap);

				}

				GMMap bayiMap = oMap.getMap(kod);
				if (bayiMap.get("BAGLI_OLD_SAT_KOD") == null || bayiMap.getString("BAGLI_OLD_SAT_KOD").trim().length() == 0) {
					bayiMap.put("BAGLI_OLD_SAT_KOD", rSet.getString("BAGLI_OLD_SAT_KOD"));
				}
				else {
					String str = bayiMap.getString("BAGLI_OLD_SAT_KOD").trim();
					str = str + "," + rSet.getString("BAGLI_OLD_SAT_KOD");
					bayiMap.put("BAGLI_OLD_SAT_KOD", str);
				}

				oMap.put(kod, bayiMap);
			}

			GMMap mp = new GMMap();

			Iterator<?> it = oMap.keySet().iterator();

			int i = 0;
			String tableName = "BAYI_LIST";

			while (it.hasNext()) {
				String kod = (String) it.next();
				GMMap bayiMap = oMap.getMap(kod);

				mp.put(tableName, i, "KOD", kod);
				mp.put(tableName, i, "HESAP_NO", bayiMap.getString("HESAP_NO"));
				mp.put(tableName, i, "ADRES_IL", bayiMap.getString("ADRES_IL"));
				mp.put(tableName, i, "ADRES_ILCE", bayiMap.getString("ADRES_ILCE"));
				mp.put(tableName, i, "TESVIK_PUAN", bayiMap.getString("TESVIK_PUAN"));
				mp.put(tableName, i, "BAYI_SORUMLU_KISI", bayiMap.getString("BAYI_SORUMLU_KISI"));
				mp.put(tableName, i, "PORTFOY_KOD", bayiMap.getString("PORTFOY_KOD"));
				mp.put(tableName, i, "SUBE_MUSTERI_NO", bayiMap.getString("SUBE_MUSTERI_NO"));
				mp.put(tableName, i, "DISTRIBUTOR_HESAP_NO", bayiMap.getString("DISTRIBUTOR_HESAP_NO"));
				mp.put(tableName, i, "SIGORTA_SATISI_EH", bayiMap.getString("SIGORTA_SATISI_EH"));
				mp.put(tableName, i, "SATICI_ADI", bayiMap.getString("SATICI_ADI"));
				mp.put(tableName, i, "MUSTERI_NO", bayiMap.getString("MUSTERI_NO"));
				mp.put(tableName, i, "TANIMLAMA_TAR", bayiMap.getString("TANIMLAMA_TAR"));
				mp.put(tableName, i, "SATICI_TIP_KOD", bayiMap.getString("SATICI_TIP_KOD"));
				mp.put(tableName, i, "BAGLI_MERKEZ_BAYI", bayiMap.getString("BAGLI_MERKEZ_BAYI"));
				mp.put(tableName, i, "KURULUS_TAR", bayiMap.getString("KURULUS_TAR"));
				mp.put(tableName, i, "KRD_TUR_KODLARI", bayiMap.getString("KRD_TUR_KODLARI"));
				mp.put(tableName, i, "YETKI_SEVIYE_KOD", bayiMap.getString("YETKI_SEVIYE_KOD"));
				mp.put(tableName, i, "ONEM_DERECE_KOD", bayiMap.getString("ONEM_DERECE_KOD"));
				mp.put(tableName, i, "TESVIK_UYGULAMA_EH", bayiMap.getString("TESVIK_UYGULAMA_EH"));
				mp.put(tableName, i, "TESVIK_FARKLI_EH", bayiMap.getString("TESVIK_FARKLI_EH"));
				mp.put(tableName, i, "ALAN_KOD_FAKS", bayiMap.getString("ALAN_KOD_FAKS"));
				mp.put(tableName, i, "FAKS_NO", bayiMap.getString("FAKS_NO"));
				mp.put(tableName, i, "EMAIL", bayiMap.getString("EMAIL"));
				mp.put(tableName, i, "WEB_ADRES", bayiMap.getString("WEB_ADRES"));
				mp.put(tableName, i, "BANKA_KOD", bayiMap.getString("BANKA_KOD"));
				mp.put(tableName, i, "BANKA_SUBE", bayiMap.getString("BANKA_SUBE"));
				mp.put(tableName, i, "BANKA_HESAP", bayiMap.getString("BANKA_HESAP"));
				mp.put(tableName, i, "PARA_CIKIS_OTO_EH", bayiMap.getString("PARA_CIKIS_OTO_EH"));
				mp.put(tableName, i, "SATIS_GORUS_KOD", bayiMap.getString("SATIS_GORUS_KOD"));
				mp.put(tableName, i, "DRM", bayiMap.getString("DRM"));
				mp.put(tableName, i, "BAGLI_OLD_BOLGE_KOD", bayiMap.getString("BAGLI_OLD_BOLGE_KOD"));
				mp.put(tableName, i, "DOK_YOLLAMA_KOD", bayiMap.getString("DOK_YOLLAMA_KOD"));
				mp.put(tableName, i, "ACIKLAMA", bayiMap.getString("ACIKLAMA"));
				mp.put(tableName, i, "BAGLI_OLD_SAT_KOD", bayiMap.getString("BAGLI_OLD_SAT_KOD"));

				i++;
			}

			return mp;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_TRN3140_BASVURU_BELGE_DETAY")
	public static GMMap getBasvuruBelgeDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_QRY3140.getSonYukleyenKullanici(?,?,?)}");

			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<BirBasvuruBelge> belgeler = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			if(belgeler.size() > 0){
				for(int i = 0;i<belgeler.size();i++){
					BirBasvuruBelge belge = belgeler.get(i);
					oMap.put("BELGE_DETAY",i,"KIMDEN",LovHelper.diLov(belge.getId().getKimden(),"3181/LOV_BASVURU_KISI","ACIKLAMA"));
					oMap.put("BELGE_DETAY",i,"BELGE",LovHelper.diLov(belge.getId().getDokumanKod(), "3140/LOV_BELGE_KOD", "ACIKLAMA"));
					oMap.put("BELGE_DETAY",i,"BELGE_KONTROLU",belge.getBelgeKontrol());
					oMap.put("BELGE_DETAY",i,"BELGE_HATASI",belge.getBelgeHata());
					
					int paramIndex = 1;
					stmt.registerOutParameter(paramIndex++, Types.VARCHAR);
					stmt.setBigDecimal(paramIndex++, belge.getId().getBasvuruNo());
					stmt.setString(paramIndex++, belge.getId().getDokumanKod());
					stmt.setString(paramIndex++, belge.getId().getKimden());
					stmt.execute();
					
					oMap.put("BELGE_DETAY", i, "SON_YUKLEYEN", stmt.getObject(1));
					Object inputs[] = {BnsprType.NUMBER, belge.getId().getBasvuruNo(), BnsprType.NUMBER, new BigDecimal(belge.getId().getDokumanKod())};
					Object outputs[] = {BnsprType.STRING, "BELGE_GELDI", BnsprType.STRING, "BELGE_ORJINAL"};
					GMMap resultMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_TRN3182.getBelgeKuryeArsivBilgileri(?,?,?,?)}", inputs, outputs);
					oMap.put("BELGE_DETAY", i, "BELGE_GELDI", resultMap.getString("BELGE_GELDI"));
					oMap.put("BELGE_DETAY", i, "BELGE_ORJINAL", resultMap.getString("BELGE_ORJINAL"));
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3140_KREDI_TUR_LIST")
	public static GMMap getKrediTurList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "KREDI_TUR_LIST", true, "select t.kod key,  t.aciklama value  from bnspr.bir_krd_tur t where t.drm = 'G' order by kod");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3140_KULLANICI_LIST")
	public static GMMap getKullaniciList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "KULLANICI_LIST", true, "select h.kod key, h.ad_soyad value from bir_belge_havuz_pr h where h.atama_yapilabilir=1");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY3140_BASKA_KULLANICIYA_ATA")
	public static GMMap baskaKullaniciyaAta(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		String tableName = "BASVURULAR";
		
		for (int i = 0; i < iMap.getSize(tableName); i++) {
			boolean secim = iMap.getBoolean(tableName, i, "SEC");
			
			if (secim) {
				try {
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{? = call pkg_qry3140.updateKullanici(?,?)}");
					stmt.registerOutParameter(1, Types.VARCHAR);
					stmt.setBigDecimal(2, iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					stmt.setString(3, iMap.getString("KULLANICI_KOD"));

					stmt.execute();
					oMap.put("MESAJ", stmt.getString(1));
				}
				catch (Exception e) {
					throw ExceptionHandler.convertException(e);
				}
				finally {
					GMServerDatasource.close(conn);
					GMServerDatasource.close(stmt);
				}
			}
			
		}
		
		return oMap;
		
	}
	
	@GraymoundService("BNSPR_QRY3140_KULLANICI_ADMIN_MI")
	public static GMMap isAdmin(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_qry3140.kullaniciAdminMi}");
			stmt.registerOutParameter(1, Types.VARCHAR);

			stmt.execute();
			oMap.put("RESULT", stmt.getString(1));

			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
}
