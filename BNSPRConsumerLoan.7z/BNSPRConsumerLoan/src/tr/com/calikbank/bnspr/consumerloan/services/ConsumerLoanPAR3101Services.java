package tr.com.calikbank.bnspr.consumerloan.services;

import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class ConsumerLoanPAR3101Services {
	@GraymoundService("BNSPR_PARAMATERS_GET_DRM_IPTAL_BILGI")
	public static GMMap getDrmIptalBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		String listName = "DRM";
		GuimlUtil.wrapMyCombo(oMap, listName, "G","Ge�erli");
		GuimlUtil.wrapMyCombo(oMap, listName, "I","Ge�ersiz");
		return oMap;
	}
}
