package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.XMLGregorianCalendar;

import org.hibernate.Session;
import org.hibernate.criterion.Order;

import tr.com.aktifbank.bnspr.dao.BddkMasrafKomisyonPr;
import tr.com.aktifbank.integration.bddk.BddkClient;
import tr.com.aktifbank.integration.bddk.descriptor.Banka;
import tr.com.aktifbank.integration.bddk.descriptor.Banka.IslemGrubu;
import tr.com.aktifbank.integration.bddk.descriptor.Banka.IslemGrubu.Islem;
import tr.com.aktifbank.integration.bddk.descriptor.Banka.IslemGrubu.Islem.Kalem;
import tr.com.aktifbank.integration.bddk.descriptor.Banka.IslemGrubu.Islem.Kalem.Masraf;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;

public class ConsumerLoanPAR3226Services {
	
	@GraymoundService("BNSPR_PAR3226_XML_OLUSTUR")
	public static GMMap xmlOlustur(GMMap iMap){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		PreparedStatement stmt2 = null;
		ResultSet rSet2 = null;
		PreparedStatement stmt3 = null;
		ResultSet rSet3 = null;
		PreparedStatement stmt4 = null;
		ResultSet rSet4 = null;
		try {
			GMMap oMap = new GMMap();
			Banka banka = new Banka();
			String guncTarihi = iMap.getString("GUNCELLEME_TARIHI") + " " + iMap.getString("GUNCELLEME_SAATI"); 
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select to_number(p.kod) KOD, p.bankamiz_adi adi, to_date('"+guncTarihi+"', 'yyyymmdd hh24:mi:ss') guncelleme_tarihi from gnl_bankamiz_bilgi_pr p");
			rSet = stmt.executeQuery();
			int bankaKod = 0;
			String bankaAdi = null;
			Timestamp guncellemeTarihi = null;
			if(rSet.next())
			{
				bankaKod = rSet.getInt("KOD");
				bankaAdi = rSet.getString("ADI");
				guncellemeTarihi = rSet.getTimestamp("GUNCELLEME_TARIHI");
			}
			banka.setAdi(bankaAdi);
			banka.setEFTKodu(bankaKod);
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(guncellemeTarihi);
			XMLGregorianCalendar xgc = new XMLGregorianCalendarImpl(gc);
			xgc.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
			xgc.setFractionalSecond(null);
			banka.setGuncellemeTarihi(xgc);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			
			stmt = conn.prepareStatement("select p.islem_grup_tur islem_grup_tur, min(id) from bddk_masraf_komisyon_pr p group by p.islem_grup_tur order by 2");
			rSet = stmt.executeQuery();
			while(rSet.next())
			{
				String islemGrupTur = rSet.getString("ISLEM_GRUP_TUR");
				IslemGrubu islemGrubu = new IslemGrubu();
				islemGrubu.setIslemGrubuAdi(islemGrupTur);

				stmt2 = conn.prepareStatement("select distinct p.islem_tur islem_tur from bddk_masraf_komisyon_pr p where p.islem_grup_tur='"+islemGrupTur+"'");
				rSet2 = stmt2.executeQuery();
				while(rSet2.next())
				{
					String islemTur = rSet2.getString("ISLEM_TUR");
					Islem islem = new Islem();
					islem.setIslemAdi(islemTur);

					stmt3 = conn.prepareStatement("select distinct p.kalem_adi kalem_adi from bddk_masraf_komisyon_pr p where p.islem_grup_tur='"+islemGrupTur+"' and p.islem_tur='"+islemTur+"'");
					rSet3 = stmt3.executeQuery();
					while(rSet3.next())
					{
						String kalemAdi = rSet3.getString("KALEM_ADI");
						Kalem kalem = new Kalem();
						kalem.setKalemAdi(kalemAdi);
						
						kalemAdi = kalemAdi.replaceAll("'", "''");
						stmt4 = conn.prepareStatement("select distinct p.masraf_adi, p.birim_tutar, p.birim_oran, p.asgari_tutar, p.asgari_oran, p.azami_tutar, p.azami_oran, p.aciklama, to_date(to_char(p.guncelleme_tarihi,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') guncelleme_tarihi from bddk_masraf_komisyon_pr p where p.islem_grup_tur='"+islemGrupTur+"' and p.islem_tur='"+islemTur+"' and p.kalem_adi='"+kalemAdi+"'");
						rSet4 = stmt4.executeQuery();
						while(rSet4.next())
						{
							Masraf masraf = new Masraf();
							masraf.setMasrafAdi(rSet4.getString("MASRAF_ADI"));
							masraf.setBirimTutar(rSet4.getString("BIRIM_TUTAR") == null ? "" : rSet4.getString("BIRIM_TUTAR"));
							masraf.setBirimOran(rSet4.getString("BIRIM_ORAN") == null ? "" : rSet4.getString("BIRIM_ORAN"));
							masraf.setAsgariTutar(rSet4.getBigDecimal("ASGARI_TUTAR") == null ? "" : (rSet4.getBigDecimal("ASGARI_TUTAR")).toString());
							masraf.setAsgariOran(rSet4.getBigDecimal("ASGARI_ORAN") == null ? "" : (rSet4.getBigDecimal("ASGARI_ORAN")).toString());
							masraf.setAzamiTutar(rSet4.getBigDecimal("AZAMI_TUTAR") == null ? "" : (rSet4.getBigDecimal("AZAMI_TUTAR")).toString());
							masraf.setAzamiOran(rSet4.getBigDecimal("AZAMI_ORAN") == null ? "" : (rSet4.getBigDecimal("AZAMI_ORAN")).toString());
							masraf.setAciklama(rSet4.getString("ACIKLAMA") == null ? "" : rSet4.getString("ACIKLAMA"));
							gc.setTime(rSet4.getTimestamp("GUNCELLEME_TARIHI"));
							xgc = new XMLGregorianCalendarImpl(gc);
							xgc.setFractionalSecond(null);
							xgc.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
							masraf.setGuncellemeTarihi(xgc);
							
							kalem.getMasraf().add(masraf);
						}
						islem.getKalem().add(kalem);
						GMServerDatasource.close(rSet4);
						GMServerDatasource.close(stmt4);
					}
					
					islemGrubu.getIslem().add(islem);
					GMServerDatasource.close(rSet3);
					GMServerDatasource.close(stmt3);
				}
				banka.getIslemGrubu().add(islemGrubu);
				GMServerDatasource.close(rSet2);
				GMServerDatasource.close(stmt2);
			}
			
			BddkClient bddkClient = new BddkClient();
			String xml = bddkClient.putBanka(banka);
			oMap.put("XML", xml);
			System.out.println(xml);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(rSet4);
			GMServerDatasource.close(stmt4);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_PAR3226_MAIL_GONDER")
	public static GMMap sendMail(GMMap iMap){
		try{
			
			GMMap oMap = new GMMap();
			
			File tempFile = File.createTempFile("TuketiciVerileri", ".xml");
			OutputStreamWriter oow = new OutputStreamWriter(new FileOutputStream(tempFile),"ISO-8859-9");
			oow.write(iMap.getString("XML"));
			oow.close();
			
			iMap.put("PARAMETRE", iMap.getString("MAIL_TO_PARAM"));
			String mailTo = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).getString("DEGER");
			
			iMap.put("MAIL_FROM", iMap.getString("MAIL_FROM"));
			iMap.put("MAIL_SUBJECT", iMap.getString("MAIL_SUBJECT"));
			iMap.put("MAIL_BODY", iMap.getString("MAIL_BODY"));
			iMap.put("IS_BODY_HTML", "H");
			iMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", iMap.getString("FILE_NAME"));
			iMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", FileUtil.readFileToByteArray(tempFile));
			iMap.put("MAIL_TO", mailTo);
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", iMap);
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_PAR3226_SEARCH")
	public static GMMap search(GMMap iMap){
		try{
			Calendar updateTime = Calendar.getInstance();
			String hour = null;
			String minutes = null;
			String seconds = null;
			GMMap oMap = new GMMap();
			String tableName = "BDDK_MASRAF_KOMISYON";
			Session session = DAOSession.getSession("BNSPRDal");
			List<BddkMasrafKomisyonPr> searchList = (List<BddkMasrafKomisyonPr>) session.createCriteria(BddkMasrafKomisyonPr.class).addOrder(Order.asc("islemGrupTur"))
																																	.addOrder(Order.asc("islemTur"))
																																	.addOrder(Order.asc("kalemAdi"))
																																	.addOrder(Order.asc("id")).list();
			int row = 0;
			for(BddkMasrafKomisyonPr pr : searchList){
				oMap.put(tableName,row,"ID"					,pr.getId());
				oMap.put(tableName,row,"ISLEM_GRUP_TUR"		,pr.getIslemGrupTur());
				oMap.put(tableName,row,"ISLEM_TUR"			,pr.getIslemTur());
				oMap.put(tableName,row,"KALEM_ADI"			,pr.getKalemAdi());
				oMap.put(tableName,row,"MASRAF_ADI"			,pr.getMasrafAdi());
				oMap.put(tableName,row,"BIRIM_TUTAR"		,pr.getBirimTutar());
				oMap.put(tableName,row,"BIRIM_ORAN"			,pr.getBirimOran());
				oMap.put(tableName,row,"ASGARI_TUTAR"		,pr.getAsgariTutar());
				oMap.put(tableName,row,"ASGARI_ORAN"		,pr.getAsgariOran());
				oMap.put(tableName,row,"AZAMI_TUTAR"		,pr.getAzamiTutar());
				oMap.put(tableName,row,"AZAMI_ORAN"			,pr.getAzamiOran());
				oMap.put(tableName,row,"ACIKLAMA"			,pr.getAciklama());
				oMap.put(tableName,row,"GUNCELLEME_TARIHI"	,pr.getGuncellemeTarihi());
				updateTime.setTime(pr.getGuncellemeTarihi());
				hour = String.valueOf(updateTime.get(Calendar.HOUR_OF_DAY));
				minutes = String.valueOf(updateTime.get(Calendar.MINUTE));
				seconds = String.valueOf(updateTime.get(Calendar.SECOND));
				hour = hour.length() > 1 ? hour : "0"+hour;
				minutes = minutes.length() > 1 ? minutes : "0"+minutes;
				seconds = seconds.length() > 1 ? seconds : "0"+seconds;
				oMap.put(tableName,row,"GUNCELLEME_SAATI"	, hour+":"+minutes+":"+seconds);
				row++;
			}
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR3226_GET_TIME")
	public static GMMap getDate(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			String hour = null;
			String minutes = null;
			String seconds = null;
			
			Calendar time = Calendar.getInstance();
			time.setTime(new Date());
			
			hour = String.valueOf(time.get(Calendar.HOUR_OF_DAY));
			minutes = String.valueOf(time.get(Calendar.MINUTE));
			seconds = String.valueOf(time.get(Calendar.SECOND));
			hour = hour.length() > 1 ? hour : "0"+hour;
			minutes = minutes.length() > 1 ? minutes : "0"+minutes;
			seconds = seconds.length() > 1 ? seconds : "0"+seconds;
			
			oMap.put("GUNCELLEME_TARIHI", time.getTime());
			oMap.put("GUNCELLEME_SAATI", hour+":"+minutes+":"+seconds);
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_PAR3226_SAVE")
	public static GMMap save(GMMap iMap){
		try{
			
			GMMap oMap = new GMMap();
			Calendar time = Calendar.getInstance();
			String tableName = "BDDK_MASRAF_KOMISYON";
			
			if(iMap.get(tableName) != null && iMap.getSize(tableName) > 0){
				
				Session session = DAOSession.getSession("BNSPRDal");
				
				List<BddkMasrafKomisyonPr> currentList = (List<BddkMasrafKomisyonPr>) session.createCriteria(BddkMasrafKomisyonPr.class).list();
				for(BddkMasrafKomisyonPr delPr : currentList){
					session.delete(delPr);
					session.flush();
				}
				
				for(int i =0;  i<iMap.getSize(tableName); i++){
					
					BddkMasrafKomisyonPr pr = new BddkMasrafKomisyonPr();
					pr.setId(iMap.getBigDecimal(tableName, i, "ID"));
					pr.setIslemGrupTur(iMap.getString(tableName, i, "ISLEM_GRUP_TUR"));
					pr.setIslemTur(iMap.getString(tableName, i, "ISLEM_TUR"));
					pr.setKalemAdi(iMap.getString(tableName, i, "KALEM_ADI"));
					pr.setMasrafAdi(iMap.getString(tableName, i, "MASRAF_ADI"));
					pr.setBirimTutar(iMap.getString(tableName, i, "BIRIM_TUTAR"));
					pr.setBirimOran(iMap.getString(tableName, i, "BIRIM_ORAN"));
					pr.setAsgariTutar(iMap.getBigDecimal(tableName, i, "ASGARI_TUTAR"));
					pr.setAsgariOran(iMap.getBigDecimal(tableName, i, "ASGARI_ORAN"));
					pr.setAzamiTutar(iMap.getBigDecimal(tableName, i, "AZAMI_TUTAR"));
					pr.setAzamiOran(iMap.getBigDecimal(tableName, i, "AZAMI_ORAN"));
					pr.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
					time.setTime(iMap.getDate(tableName, i, "GUNCELLEME_TARIHI"));
					String[] clock = iMap.getString(tableName, i, "GUNCELLEME_SAATI").split(":");
					time.set(Calendar.HOUR_OF_DAY, Integer.valueOf(clock[0]));
					time.set(Calendar.MINUTE, Integer.valueOf(clock[1]));
					time.set(Calendar.SECOND, Integer.valueOf(clock[2]));
					pr.setGuncellemeTarihi(time.getTime());
					session.save(pr);
					session.flush();
					
				}
				
			}
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
