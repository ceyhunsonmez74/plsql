package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiYetkiTanimTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiYetkiTanimTxId;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisan;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisanTx;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisanTxId;
import tr.com.calikbank.bnspr.dao.BirSaticiIliski;
import tr.com.calikbank.bnspr.dao.BirSaticiIliskiTx;
import tr.com.calikbank.bnspr.dao.BirSaticiIliskiTxId;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.dao.BirSaticiTx;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.tree.checkbox.TristateTreeNode;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3161Services {

	private static String DLR_CHANNEL_OID = null;
	public static final String GM_DATASOURCE = "java:/GraymoundDS";
	public static final String BNSPR_SESSION_NAME = "BNSPRDal";

	@GraymoundService("BNSPR_3161_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "SATICI_TIP_KOD");
			oMap.put("SATICI_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "FIRMA_TIPI");
			oMap.put("SIRKET_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_KREDI_TIPI");
			oMap.put("BAYI_KREDI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "SATIS_GORUS_KOD");
			oMap.put("SATICI_GORUSU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAGLI_OLD_BOLGE_KOD");
			oMap.put("BAGLI_OLDUGU_BOLGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "DOK_YOLLAMA_KOD");
			oMap.put("DOKUMAN_YOLLAMA_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "YETKI_SEVIYE_KOD");
			oMap.put("YETKI_SEVIYESI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "CAL_STATU_KOD");
			oMap.put("CALISAN_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "YETKI_SEVIYE_KOD");
			oMap.put("YETKI_SEVIYESI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "TUTTUGU_TAKIM_KOD");
			oMap.put("TUTTUGU_TAKIM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "POZISYON_KOD");
			oMap.put("POZISYONU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("LOV", "3161/LOV_UYRUK");
			iMap.put("VALUE", "KOD");
			iMap.put("NAME", "ACIKLAMA");
			oMap.put("UYRUK_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_KAZANIM_KANAL");
			oMap.put("DST_KAZANIM_KANAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "DEBIT_KART_VERILEBILIR_MI_KOD");
			oMap.put("DEBIT_VERILEBILIR_MI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	// BPM i�in
	@GraymoundService("BNSPR_TRN3161_SAVE")
	public static Map<?, ?> saveTRN3161(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiTx birSaticiTx = new BirSaticiTx();
			birSaticiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birSaticiTx.setKod(iMap.getBigDecimal("KOD"));
			birSaticiTx.setSaticiAdi(iMap.getString("SATICI_ADI"));
			birSaticiTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			// birSaticiTx.setTanimlamaTar(iMap.getDate("TANIMLAMA_TAR"));
			birSaticiTx.setSaticiTipKod(iMap.getString("SATICI_TIP_KOD"));
			birSaticiTx.setBagliMerkezBayi(iMap.getBigDecimal("BAGLI_MERKEZ_BAYI"));
			birSaticiTx.setKurulusTar(iMap.getDate("KURULUS_TAR"));
			String krdTur = GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("F_IHTIYAC"));
			krdTur = krdTur + GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("F_KONUT"));
			krdTur = krdTur + GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("F_TASIT"));
			krdTur = krdTur + "000" + GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("F_TARIM"));
			birSaticiTx.setKrdTurKodlari(krdTur);
			birSaticiTx.setAdres(iMap.getString("SATICI_ADRES"));
			birSaticiTx.setAdresIl(iMap.getString("SATICI_IL"));
			birSaticiTx.setAdresIlce(iMap.getString("SATICI_ILCE"));
			birSaticiTx.setAlanKodTel(iMap.getString("SATICI_ALAN_KOD_TEL"));
			birSaticiTx.setTelNo(iMap.getString("SATICI_TEL_NO"));
			birSaticiTx.setAlanKodFaks(iMap.getString("SATICI_ALAN_KOD_FAKS"));
			birSaticiTx.setFaksNo(iMap.getString("SATICI_FAKS_NO"));
			birSaticiTx.setEmail(iMap.getString("EMAIL"));
			birSaticiTx.setWebAdres(iMap.getString("WEB_ADRES"));
			birSaticiTx.setBankaKod(iMap.getString("BANKA_KOD"));
			birSaticiTx.setBankaSube(iMap.getString("BANKA_SUBE"));
			birSaticiTx.setBankaHesap(iMap.getString("BANKA_HESAP"));
			birSaticiTx.setParaCikisOtoEh(iMap.getString("PARA_CIKIS_OTO_EH"));
			birSaticiTx.setSatisGorusKod(iMap.getString("SATIS_GORUS_KOD"));
			birSaticiTx.setDrm(iMap.getString("DRM"));
			birSaticiTx.setBagliOldBolgeKod(iMap.getString("BAGLI_OLD_BOLGE_KOD"));
			birSaticiTx.setDokYollamaKod(iMap.getString("DOK_YOLLAMA_KOD"));
			birSaticiTx.setBayiSorumluKisi(iMap.getBigDecimal("BAYI_SORUMLU_KISI"));
			birSaticiTx.setPortfoyKod("PORTFOY_KOD");
			session.save(birSaticiTx);
			session.flush();

			List<?> saticiCalisanGuiList = (List<?>) iMap.get("SATICI_CALISAN");
			String tableName = "SATICI_CALISAN";
			for (int i = 0; i < saticiCalisanGuiList.size(); i++) {
				BirSaticiCalisanTx saticiCalisanTx = new BirSaticiCalisanTx();
				BirSaticiCalisanTxId id = new BirSaticiCalisanTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
				saticiCalisanTx.setId(id);
				saticiCalisanTx.setSaticiKod(iMap.getBigDecimal(tableName, i, "SATICI_KOD"));
				saticiCalisanTx.setTcKimlikNo(iMap.getString(tableName, i, "TC_KIMLIK_NO"));
				saticiCalisanTx.setAdi(iMap.getString(tableName, i, "ADI"));
				saticiCalisanTx.setSoyadi(iMap.getString(tableName, i, "SOYADI"));
				saticiCalisanTx.setUyrukKod(iMap.getString(tableName, i, "UYRUK_KOD"));
				saticiCalisanTx.setDogumTarihi(iMap.getDate(tableName, i, "DOGUM_TARIHI"));
				saticiCalisanTx.setDogumYeri(iMap.getString(tableName, i, "DOGUM_YERI"));
				saticiCalisanTx.setBabaAdi(iMap.getString(tableName, i, "BABA_ADI"));
				/*
				 * saticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_GIRIS_KOD"));
				 */

				if (iMap.getString(tableName, i, "YETKI_SEVIYESI") != null && iMap.getString(tableName, i, "YETKI_SEVIYESI").compareTo(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI")) != 0) {
					saticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
					saticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
					saticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"));
					saticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));

				}
				else if (iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI") != null && iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI").compareTo(iMap.getString(tableName, i, "YETKI_SEVIYESI")) != 0) {
					saticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
					saticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
					saticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"));
					saticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));

				}
				else if ((iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI") == null && iMap.getString(tableName, i, "YETKI_SEVIYESI") == null) || (iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI").compareTo(iMap.getString(tableName, i, "YETKI_SEVIYESI")) == 0)) {
					saticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
					saticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));
					saticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "ONCEKI_YETKI_SEVIYESI"));
					saticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR"));
				}

				saticiCalisanTx.setCepAlanKod(iMap.getString(tableName, i, "CEP_ALAN_KOD"));
				saticiCalisanTx.setCepTelNo(iMap.getString(tableName, i, "CEP_TEL_NO"));
				saticiCalisanTx.setEposta(iMap.getString(tableName, i, "EPOSTA"));
				saticiCalisanTx.setIseBaslamaTar(iMap.getDate(tableName, i, "ISE_BASLAMA_TAR"));
				saticiCalisanTx.setPozisyonKod(iMap.getString(tableName, i, "POZISYON_KOD"));
				saticiCalisanTx.setTuttuguTakimKod(iMap.getString(tableName, i, "TUTTUGU_TAKIM_KOD"));
				saticiCalisanTx.setHobiKod(iMap.getString(tableName, i, "HOBI_KOD"));
				saticiCalisanTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
				saticiCalisanTx.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
				saticiCalisanTx.setDigerBankaKod(iMap.getString(tableName, i, "DIGER_BANKA_KOD"));
				saticiCalisanTx.setDigerSubeKod(iMap.getString(tableName, i, "DIGER_SUBE_KOD"));
				saticiCalisanTx.setDigerHesapNo(iMap.getString(tableName, i, "DIGER_HESAP_NO"));
				saticiCalisanTx.setArmaganKartNo(iMap.getString(tableName, i, "ARMAGAN_KART_NO"));
				// saticiCalisanTx.setCalStatuKod(iMap.getString(tableName, i, "CAL_STATU_KOD"));
				// saticiCalisanTx.setCalKismiKapanmaNedenKod(iMap.getString(tableName, i,
				// "CAL_KISMI_KAPANMA_NEDEN_KOD"));
				session.save(saticiCalisanTx);
			}
			session.flush();

			List<?> teminatlarGuiList = (List<?>) iMap.get("SATICI_ILISKI");
			tableName = "SATICI_ILISKI";
			for (int i = 0; i < teminatlarGuiList.size(); i++) {
				BirSaticiIliskiTx birSaticiIliskiTx = new BirSaticiIliskiTx();
				BirSaticiIliskiTxId id = new BirSaticiIliskiTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				// id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
				birSaticiIliskiTx.setId(id);
				// birSaticiIliskiTx.setSaticiKod(iMap.getBigDecimal(tableName,
				// i, "SATICI_KOD"));
				// birSaticiIliskiTx.setBagliOldSatKod(iMap.getBigDecimal(tableName,
				// i, "BAGLI_OLD_SAT_KOD"));
				session.save(birSaticiIliskiTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3161");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3161_SAVE_AND_CREATE_CONTAKT")
	public static Map<?, ?> saveAndCreateContakt(GMMap iMap) {
		try {

			if (iMap.getBigDecimal("MUSTERI_NO") == null || iMap.getString("MUSTERI_NO").isEmpty()) {
				iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3161_KONTAKT_SATICI", iMap).get("MUSTERI_NO"));
				iMap.put("MUSTERI_HESAP_NO", iMap.getBigDecimal("DI_HESAP_NO"));
				if (iMap.getString("SATICI_TIP").equals("S")) {
					iMap.put("SUBE_MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
				}
			}
			else {
				if (iMap.getString("SATICI_TIP").equals("S") && iMap.getBigDecimal("SUBE_MUSTERI_NO") == null) {
					iMap.remove("VERGI_TCK_NO");
					iMap.put("SUBE_MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3161_KONTAKT_SATICI", iMap).get("MUSTERI_NO"));
				}
				else if (iMap.getString("SATICI_TIP") == "S" && iMap.getBigDecimal("SUBE_MUSTERI_NO") != null) {
					iMap.put("SUBE_MUSTERI_NO", iMap.getBigDecimal("SUBE_MUSTERI_NO"));
				}

			}
			
			iMap.put("CREDIT", GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("CREDIT")));
			iMap.put("UPT", GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("UPT")));
			iMap.put("SIGORTA", GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("SIGORTA")));

			return GMServiceExecuter.execute("BNSPR_TRN3161_SCREEN_SAVE", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * @param iMap
	 *            (GMMap)
	 *            TCKN
	 *            BAYI_KOD
	 *            CEP_TEL_ALAN
	 *            CEP_TEL
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 * 
	 * 
	 * */
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3161_SATICI_CALISAN_EKLE_UBE")
	public static GMMap saticiEkleUBE(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			BigDecimal trxNo = null;
			BigDecimal saticiKod = null;
			BigDecimal bagliSaticiKod = null;
			String bayiRefKod = iMap.getString("BAYI_KOD");
			String distKod = iMap.getString("DIST_KOD");
			String tckn = iMap.getString("TCKN");
			String cepalan = iMap.getString("CEP_TEL_ALAN");
			String ceptel = iMap.getString("CEP_TEL");
			Session session = DAOSession.getSession(BNSPR_SESSION_NAME);
			String func = "{call bnspr.pkg_trn3461.ube_web_kullanici_kontroller(?,?,?,?,?)}";
			Object[] inputValues = { BnsprType.STRING, distKod, BnsprType.STRING, bayiRefKod, BnsprType.STRING, tckn, BnsprType.STRING, cepalan,
					BnsprType.STRING, ceptel };
			Object[] outputValues = {};
			DALUtil.callOracleProcedure(func, inputValues, outputValues);
			try {
				func = "{? = call bnspr.pkg_trn3461.ube_birsatici_txno(?,?)}";
				inputValues = new Object[] { BnsprType.STRING, bayiRefKod, BnsprType.STRING, distKod };
				trxNo = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
				BirSaticiTx birSaticiTx = (BirSaticiTx) session.get(BirSaticiTx.class, trxNo);
				saticiKod = birSaticiTx.getKod();
				List<BirSaticiIliskiTx> list = (List<BirSaticiIliskiTx>) session.createCriteria(BirSaticiIliskiTx.class).add(Restrictions.eq("id.txNo", trxNo)).add(Restrictions.eq("distBayiRef", bayiRefKod)).list();
				if (list.size() > 0) {
					bagliSaticiKod = list.get(0).getId().getBagliOldSatKod();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}

			if (saticiKod == null) {
				GMMap errorMap = new GMMap();
				errorMap.put("HATA_NO", "3661");
				errorMap.put("P1", iMap.getString("BAYI_KOD"));
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", errorMap);
			}

			BirSaticiCalisanTx birSaticiCalisanTx = new BirSaticiCalisanTx();

			BirSaticiCalisanTxId id = new BirSaticiCalisanTxId();
			id.setTxNo(trxNo);

			HashMap<String, Object> xMap = new HashMap<String, Object>();
			xMap.put("TABLE_NAME", "BIR_SATICI_CALISAN");

			id.setKod((BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", xMap).get("ID"));

			GMMap searchMap = new GMMap();
			searchMap.put("COUNTRY_CODE", "TR");
			searchMap.put("TCKN", iMap.getString("TCKN"));

			BigDecimal musteriNo = GMServiceExecuter.call("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", searchMap).getBigDecimal("CUSTOMER_NO");

			GMMap calisanKontrol = new GMMap();
			List<?> calisanlarList = session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("birSatici.kod", saticiKod)).add(Restrictions.eq("durum", "ONAY")).list(); // .add(Restrictions.eq("durum","ONAY"))
			String tableName = "TABLE_DATA";
			int row = 0;
			for (int i = 0; i < calisanlarList.size(); i++) {

				BirSaticiCalisan birSaticiCalisan = (BirSaticiCalisan) calisanlarList.get(i);
				calisanKontrol.put(tableName, row, "KOD", birSaticiCalisan.getKod());
				calisanKontrol.put(tableName, row, "MUSTERI_NO", birSaticiCalisan.getMusteriNo());
				calisanKontrol.put(tableName, row, "TCK_NO", birSaticiCalisan.getMusteriNo());
				row++;
			}
			if (musteriNo == null || musteriNo.compareTo(BigDecimal.ZERO) <= 0) {

				calisanKontrol.put("TCKN", iMap.getString("TCKN"));
				calisanKontrol = GMServiceExecuter.call("BNSPR_3161_CHECK_CURRENT_LIST", calisanKontrol);

				GMMap tMap = new GMMap();
				tableName = "CALISANLAR";
				tMap.put("CALISAN_ROW", 0);
				tMap.put(tableName, 0, "TCK_NO", iMap.getString("TCKN"));
				tMap.put(tableName, 0, "CEP_TEL_ALAN", iMap.getString("CEP_TEL_ALAN"));
				tMap.put(tableName, 0, "CEP_TEL", iMap.getString("CEP_TEL"));
				musteriNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRN3161_KONTAKT_CALISAN", tMap).get("MUSTERI_NO").toString());
			}
			else {
				calisanKontrol.put("MUSTERI_NO", musteriNo);
				calisanKontrol.put("TCKN", iMap.getString("TCKN"));
				calisanKontrol = GMServiceExecuter.call("BNSPR_3161_CHECK_CURRENT_LIST", calisanKontrol);

				calisanKontrol = new GMMap();
				calisanKontrol.put("MUSTERI_NO", musteriNo);
				calisanKontrol.put("SATICI_KOD", saticiKod);
				calisanKontrol = GMServiceExecuter.call("BNSPR_TRN3161_GET_CALISAN_TANIMLI_MI", calisanKontrol);
				if ("C".equals(calisanKontrol.getString("STATU"))) {
					GMMap errorMap = new GMMap();
					errorMap.put("HATA_NO", "2492");
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", errorMap);
				}

			}
			birSaticiCalisanTx.setId(id);
			birSaticiCalisanTx.setCepAlanKod(iMap.getString("CEP_TEL_ALAN"));
			birSaticiCalisanTx.setCepTelNo(iMap.getString("CEP_TEL"));
			birSaticiCalisanTx.setSaticiKod(saticiKod);

			func = "{? = call pkg_trn3461.calisan_default(?)}";
			inputValues = new Object[] { BnsprType.NUMBER, bagliSaticiKod };
			GMMap dMap = new GMMap();
			tableName = "RESULTS";
			dMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
			int len = dMap.getSize(tableName);
			if (len == 1) {
				birSaticiCalisanTx.setOrtakEh(dMap.getString(tableName, 0, "ORTAK_EH"));
				birSaticiCalisanTx.setOrtaklikPayi(dMap.getBigDecimal(tableName, 0, "ORTAKLIK_PAYI"));
				birSaticiCalisanTx.setPozisyonKod(dMap.getString(tableName, 0, "POZISYON_KOD"));
				birSaticiCalisanTx.setYetkiGirisKod(dMap.getString(tableName, 0, "YETKI_GIRIS_KOD"));
				birSaticiCalisanTx.setCalStatuKod(dMap.getString(tableName, 0, "CAL_STATU_KOD"));
			}

			iMap.putAll(LovHelper.diLovAll(musteriNo, "3161/LOV_GERCEK_MUSTERI"));
			birSaticiCalisanTx.setMusteriNo(musteriNo);
			birSaticiCalisanTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			birSaticiCalisanTx.setAdi(iMap.getString("ADI"));
			birSaticiCalisanTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
			birSaticiCalisanTx.setSoyadi(iMap.getString("SOYADI"));
			birSaticiCalisanTx.setUyrukKod(iMap.getString("UYRUK_KOD"));
			birSaticiCalisanTx.setDogumTarihi(iMap.getDate("DOGUM_TARIHI"));
			birSaticiCalisanTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
			birSaticiCalisanTx.setBabaAdi(iMap.getString("BABA_ADI"));
			birSaticiCalisanTx.setCihazKullanicisi(iMap.getString("CIHAZ_KULLANICISI"));
			birSaticiCalisanTx.setBayiCihazKodu(iMap.getString("BAYI_CIHAZ_KODU"));

			session.save(birSaticiCalisanTx);
			session.flush();
			func = "{? = call pkg_trn3161.transaction_start(?,?)}";
			inputValues = new Object[] { BnsprType.NUMBER, trxNo, BnsprType.STRING, "E" };
			oMap.put("MESSAGE", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));

			GMMap tMap = new GMMap();
			tMap.put("SATICI_KOD", saticiKod);
			tMap.put("CALISAN_KOD", id.getKod());
			tMap.put("TRX_NO", trxNo);
			tMap.put("TCKN", tckn);
			tMap.put("CEP_TEL_ALAN", cepalan);
			tMap.put("CEP_TEL", ceptel);
			tMap.put("DIST_KOD", distKod);
			tMap.put("BAYI_KOD", bayiRefKod);
			GMServiceExecuter.call("BNSPR_TRN3161_KULLANICI_YARAT_WRAPPER_UBE", tMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		oMap.put("RESPONSE", 2);
		return oMap;
	}

	/**
	 * 
	 * DESC : WRAPPER FUNCTION FOR 3166 SAVE
	 * 
	 * @param iMap
	 *            (GMMap)
	 *            SATICI_KOD
	 *            CALISAN_KOD
	 * 
	 * @return oMap (GMMap)
	 *         RESPONSE
	 *         RESPONSE_DATA
	 * 
	 *         Company : Aktifbank
	 * 
	 */
	@GraymoundService("BNSPR_TRN3161_KULLANICI_YARAT_WRAPPER_UBE")
	public static GMMap kullaniciYaratWrapper(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap trxMap = new GMMap();
			trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
			GMMap userCreateMap = new GMMap();

			iMap.put("BAYI_CALISAN_KODU_CC", iMap.getString("CALISAN_KOD"));
			GMMap t = GMServiceExecuter.call("BNSPR_TRN3166_GET_CALISAN_LIST", iMap);
			userCreateMap.putAll(t);
			userCreateMap.put("TRX_NO", trxMap.getString("TRX_NO"));
			userCreateMap.put("SATICI_KOD", iMap.getString("SATICI_KOD"));
			GMServiceExecuter.call("BNSPR_TRN3166_SAVE", userCreateMap);
			String func = "{? = call pkg_trn3462.ube_basvuru_tx(?,?,?,?,?,?,?)}";
			Object[] inputValues = { BnsprType.STRING, iMap.getString("DIST_KOD"), BnsprType.STRING, iMap.getString("BAYI_KOD"), BnsprType.STRING,
					iMap.getString("TCKN"), BnsprType.NUMBER, iMap.getBigDecimal("CEP_TEL_ALAN"), BnsprType.NUMBER, iMap.getBigDecimal("CEP_TEL"),
					BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"), BnsprType.NUMBER, trxMap.getBigDecimal("TRX_NO"), };
			BigDecimal trxNo = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			func = "{? = call pkg_trn3462.transaction_start(?,?)}";
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(func);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, trxNo);
			stmt.setString(3, "E");
			stmt.execute();

			func = "{ call pkg_trn3462.ube_basvuru_mail(?) }";
			Object[] outputValues = {};
			inputValues = new Object[] { BnsprType.NUMBER, trxNo };
			DALUtil.callOracleProcedure(func, inputValues, outputValues);
		}
		catch (Exception e) {
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE_NO", "3662");
			messageMap.put("P1", iMap.getString("CALISAN_KOD"));
			messageMap.put("P2", iMap.getString("SATICI_KOD"));
			messageMap.put("P3", e.getMessage());
			messageMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", messageMap));
			String mailFrom = "system@aktifbank.com.tr";
			String mailToParametre = "3161_KULLANICI_YARAT_HATA_MAIL";
			String mailSubject = "SATICI KULLANICI YARATMA HATASI";
			String mailBody = messageMap.getString("ERROR_MESSAGE");
			sendMail(mailFrom, mailToParametre, mailSubject, mailBody);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	protected static String getOrtamAdi() {
		GMMap xMap = new GMMap();
		return GMServiceExecuter.call("BNSPR_CORE_GET_DATABASE_ADI", xMap).getString("DATABASE_ADI");
	}

	protected static void sendMail(String mailFrom, String mailToParametre, String subject, String mailBody) {
		try {
			GMMap servisMap = new GMMap();
			servisMap.put("MAIL_FROM", mailFrom);
			GMMap xMap = new GMMap();
			xMap.put("PARAMETRE", mailToParametre);
			servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
			servisMap.put("MAIL_SUBJECT", subject + " --- " + getOrtamAdi());
			servisMap.put("MAIL_BODY", mailBody);
			servisMap.put("IS_BODY_HTML", "H");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 3161 Ekran�na ili�kin
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3161_SCREEN_SAVE")
	public static Map<?, ?> saveScreenTRN3161(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirSaticiTx birSaticiTx = (BirSaticiTx) session.get(BirSaticiTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birSaticiTx == null)
				birSaticiTx = new BirSaticiTx();

			birSaticiTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birSaticiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birSaticiTx.setKod(iMap.getBigDecimal("SATICI_KOD"));
			birSaticiTx.setSaticiAdi(iMap.getString("DI_SATICI_KOD"));
			birSaticiTx.setSaticiTipKod(iMap.getString("SATICI_TIP"));
			birSaticiTx.setBagliOldBolgeKod(iMap.getString("BAGLI_OLDUGU_BOLGE"));
			birSaticiTx.setBagliMerkezBayi(iMap.getBigDecimal("BAGLI_OLDUGU_MERKEZ_BAYI_KOD"));
			birSaticiTx.setDokYollamaKod(iMap.getString("DOKUMAN_YOLLAMA_TIPI"));
			birSaticiTx.setDrm(iMap.getString("DURUM"));

			birSaticiTx.setKurulusTar(iMap.getDate("KURULUS_TARIHI"));
			birSaticiTx.setAlanKodTel(iMap.getString("SATICI_TELEFON_ALAN"));
			birSaticiTx.setTelNo(iMap.getString("SATICI_TELEFON"));
			birSaticiTx.setAlanKodFaks(iMap.getString("SATICI_FAX_ALAN"));
			birSaticiTx.setFaksNo(iMap.getString("SATICI_FAKS"));
			String emailName = iMap.getString("E_POSTA_NAME");
			String emailNet = iMap.getString("E_POSTA_NET");
			if (emailName != null && !"".equals(emailName))
				emailName = emailName + "@";
			if (emailNet != null && !"".equals(emailNet))
				emailName = emailName + emailNet;
			birSaticiTx.setEmail(emailName);

			birSaticiTx.setWebAdres(iMap.getString("WEB_ADRESI"));
			birSaticiTx.setAdres(iMap.getString("SATICI_ADRES"));
			birSaticiTx.setAdresIl(iMap.getString("SATICI_IL"));
			birSaticiTx.setAdresIlce(iMap.getString("SATICI_ILCE"));
			birSaticiTx.setHesapNo(iMap.getBigDecimal("MUSTERI_HESAP_NO"));
			birSaticiTx.setParaCikisOtoEh(iMap.getString("PARA_CIKISI"));
			birSaticiTx.setBankaKod(iMap.getString("BANKA_KOD"));
			birSaticiTx.setBankaSube(iMap.getString("SUBE_KOD"));
			birSaticiTx.setBankaHesap(iMap.getString("HESAP_A"));
			birSaticiTx.setSatisGorusKod(iMap.getString("SATICI_GORUSU"));
			birSaticiTx.setKrdTurKodlari(iMap.getString("KREDI_TURU"));
			birSaticiTx.setAciklama(iMap.getString("ACIKLAMA"));
			Date bankaTarih = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH");
			birSaticiTx.setTanimlamaTar(bankaTarih);
			birSaticiTx.setBayiSorumluKisi(iMap.getBigDecimal("BAYI_SORUMLU_KISI"));
			birSaticiTx.setBayiUbeSorumlu(iMap.getBigDecimal("BAYI_UBE_SORUMLU"));
			birSaticiTx.setPortfoyKod(iMap.getString("PORTFOY_KOD"));
			birSaticiTx.setSubeMusteriNo(iMap.getBigDecimal("SUBE_MUSTERI_NO"));
			birSaticiTx.setDistributorHesapNo(iMap.getBigDecimal("DISTRIBUTOR_HESAP_NO"));
			birSaticiTx.setKrediOdemesi(iMap.getBoolean("KREDI_ODEMESI") ? "1" : "0");
			birSaticiTx.setDebitKart(iMap.getString("DEBIT_KART"));
			birSaticiTx.setBayiKrediTipi(iMap.getString("BAYI_KREDI_TIPI"));
			birSaticiTx.setBayiKrediKodu(iMap.getBigDecimal("BAYI_KREDI_KODU"));
			birSaticiTx.setUpsellYapilabilir(iMap.getBoolean("UPSELL_YAPILABILIR") ? "1" : "0");
			birSaticiTx.setKorumaKredisi(iMap.getBoolean("KORUMA_KREDISI") ? "1" : "0");
			birSaticiTx.setFaizsizFinansman(iMap.getBoolean("FAIZSIZ_FINANSMAN") ? "E" : "H");
			
			if (iMap.getBoolean("SIGORTA_SATISI")) {
				birSaticiTx.setSigortaSatisiEh("E");
			}
			else {
				birSaticiTx.setSigortaSatisiEh("H");
			}
			//
			if( iMap.getString("CREDIT") != null)
				birSaticiTx.setAgentCredit(iMap.getString("CREDIT"));
			
			if( iMap.getString("UPT") != null)
				birSaticiTx.setAgentUpt(iMap.getString("UPT"));
			
			if( iMap.getString("SIGORTA") != null)
				birSaticiTx.setAgentSigorta(iMap.getString("SIGORTA"));
			

			session.saveOrUpdate(birSaticiTx);

			List<?> listDagiticilar = session.createCriteria(BirSaticiIliskiTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayDagiticilar = listDagiticilar.toArray();
			for (int i = 0; i < arrayDagiticilar.length; i++) {
				listDagiticilar.remove(arrayDagiticilar[i]);
				session.delete(arrayDagiticilar[i]);
			}
			session.flush();

			List<?> dagitiFirmalar = (List<?>) iMap.get("BAGLI_OLDUGU_DAGITICI_FIRMALAR");
			String tableName = "BAGLI_OLDUGU_DAGITICI_FIRMALAR";
			if(dagitiFirmalar != null)
			{
			for (int i = 0; i < dagitiFirmalar.size(); i++) {
				BirSaticiIliskiTx birSaticiIliskiTx = new BirSaticiIliskiTx();
				BirSaticiIliskiTxId id = new BirSaticiIliskiTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
				id.setBagliOldSatKod(iMap.getBigDecimal(tableName, i, "VALUE"));
				birSaticiIliskiTx.setId(id);
				birSaticiIliskiTx.setDistBayiRef(iMap.getString(tableName, i, "DIST_BAYI_REF"));
				birSaticiIliskiTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, i, "SEC")));
				session.save(birSaticiIliskiTx);
			}
			}
			session.flush();

			tableName = "YETKI_SEVIYE_TREE";
			DefaultMutableTreeNode root = (DefaultMutableTreeNode) iMap.get(tableName);
			if (root != null) {
				Enumeration<DefaultMutableTreeNode> enumeration = root.breadthFirstEnumeration();
				while (enumeration.hasMoreElements()) {
					DefaultMutableTreeNode node = enumeration.nextElement();
					if (!root.equals(node)) {
						GMMap roleMap = (GMMap) node.getUserObject();

						BirSaticiYetkiTanimTxId yetkiTxId = new BirSaticiYetkiTanimTxId();
						yetkiTxId.setTrxNo(iMap.getBigDecimal("TRX_NO"));
						yetkiTxId.setRoleOid(roleMap.getString("OID"));

						BirSaticiYetkiTanimTx yetkiTx = (BirSaticiYetkiTanimTx) session.get(BirSaticiYetkiTanimTx.class, yetkiTxId);
						if (yetkiTx == null) {
							yetkiTx = new BirSaticiYetkiTanimTx(yetkiTxId);
						}

						yetkiTx.setRoleName(roleMap.getString("NAME"));
						yetkiTx.setSelected(GuimlUtil.convertFromCheckBoxValue(roleMap.getBoolean("SELECTED")));

						session.saveOrUpdate(yetkiTx);
					}
				}
				session.flush();
			}

			tableName = "CALISANLAR";
			if (iMap.get(tableName) != null) {
				List<?> listCalisanlar = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
				Object[] arrayCalisanlar = listCalisanlar.toArray();
				for (int i = 0; i < arrayCalisanlar.length; i++) {
					listCalisanlar.remove(arrayCalisanlar[i]);
					session.delete(arrayCalisanlar[i]);

				}
				session.flush();
				List<?> calisanlarList = (List<?>) iMap.get(tableName);

				for (int i = 0; i < calisanlarList.size(); i++) {

					BirSaticiCalisanTx birSaticiCalisanTx = new BirSaticiCalisanTx();

					BirSaticiCalisanTxId id = new BirSaticiCalisanTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					HashMap<String, Object> xMap = new HashMap<String, Object>();
					xMap.put("TABLE_NAME", "BIR_SATICI_CALISAN");

					if (iMap.get(tableName, i, "KOD") == null || iMap.get(tableName, i, "KOD").equals(""))
						id.setKod((BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", xMap).get("ID"));
					else
						id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
					BigDecimal musteriNo = iMap.getBigDecimal(tableName, i, "MUSTERI_NO");

					if (iMap.getBoolean(tableName, i, "YENI_MUSTERI_MI") && !"E".equals(iMap.getString(tableName, i, "CIHAZ_KULLANICISI"))) {
						iMap.put("CALISAN_ROW", i);
						musteriNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRN3161_KONTAKT_CALISAN", iMap).get("MUSTERI_NO").toString());
					}

					birSaticiCalisanTx.setId(id);
					birSaticiCalisanTx.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
					birSaticiCalisanTx.setMusteriNo(musteriNo);
					birSaticiCalisanTx.setTcKimlikNo(iMap.getString(tableName, i, "TCK_NO"));
					birSaticiCalisanTx.setAdi(iMap.getString(tableName, i, "ADI"));
					birSaticiCalisanTx.setIkinciAd(iMap.getString(tableName, i, "IKINCI_ADI"));
					birSaticiCalisanTx.setSoyadi(iMap.getString(tableName, i, "SOYADI"));
					birSaticiCalisanTx.setUyrukKod(iMap.getString(tableName, i, "UYRUK"));
					birSaticiCalisanTx.setDogumTarihi(iMap.getDate(tableName, i, "DOGUM_TARIHI"));
					birSaticiCalisanTx.setDogumYeri(iMap.getString(tableName, i, "DOGUM_YERI"));
					birSaticiCalisanTx.setBabaAdi(iMap.getString(tableName, i, "BABA_ADI"));
					birSaticiCalisanTx.setCepAlanKod(iMap.getString(tableName, i, "CEP_TEL_ALAN"));
					birSaticiCalisanTx.setCepTelNo(iMap.getString(tableName, i, "CEP_TEL"));
					String calisanEmailName = iMap.getString(tableName, i, "EPOSTA_NAME");
					String calisanEmailNet = iMap.getString(tableName, i, "EPOSTA_NET");
					if (calisanEmailName != null && !"".equals(calisanEmailName))
						calisanEmailName = calisanEmailName + "@";
					if (calisanEmailNet != null && !"".equals(calisanEmailNet))
						calisanEmailName = calisanEmailName + calisanEmailNet;
					birSaticiCalisanTx.setEposta(calisanEmailName);
					birSaticiCalisanTx.setOrtakEh(iMap.getString(tableName, i, "ORTAK_MI"));
					birSaticiCalisanTx.setOrtaklikPayi(iMap.getBigDecimal(tableName, i, "ORTAKLIK_PAYI"));
					birSaticiCalisanTx.setIseBaslamaTar(iMap.getDate(tableName, i, "ISE_BASLAMA_TARIHI"));
					birSaticiCalisanTx.setPozisyonKod(iMap.getString(tableName, i, "POZISYONU"));
					birSaticiCalisanTx.setTuttuguTakimKod(iMap.getString(tableName, i, "TUTTUGU_TAKIM"));
					birSaticiCalisanTx.setHobiKod(iMap.getString(tableName, i, "HOBILERI"));
					birSaticiCalisanTx.setCihazKullanicisi(iMap.getString(tableName, i, "CIHAZ_KULLANICISI"));
					birSaticiCalisanTx.setBayiCihazKodu(iMap.getString(tableName, i, "BAYI_CIHAZ_KODU"));
					// birSaticiCalisanTx.setCalStatuKod(iMap.getString(tableName, i, "CALISAN_STATUSU"));
					// birSaticiCalisanTx.setCalKismiKapanmaNedenKod(iMap.getString(tableName, i, "KAPANMA_NEDENI"));
					/*
					 * birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
					 */
					if (iMap.getString(tableName, i, "YETKI_SEVIYESI") != null && !iMap.getString(tableName, i, "YETKI_SEVIYESI").equals(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"))) {
						birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
						birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
						birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"));
						birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));

					}
					else if (iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI") != null && !iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI").equals(iMap.getString(tableName, i, "YETKI_SEVIYESI"))) {
						birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
						birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
						birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"));
						birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));

					}
					else if ((iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI") == null && iMap.getString(tableName, i, "YETKI_SEVIYESI") == null) || (iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI").equals(iMap.getString(tableName, i, "YETKI_SEVIYESI")))) {
						birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
						birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));
						birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "ONCEKI_YETKI_SEVIYESI"));
						birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR"));
					}

					birSaticiCalisanTx.setDigerBankaKod(iMap.getString(tableName, i, "BANKA_KOD"));
					birSaticiCalisanTx.setDigerSubeKod(iMap.getString(tableName, i, "SUBE_KOD"));
					birSaticiCalisanTx.setDigerHesapNo(iMap.getString(tableName, i, "HESAP_A"));
					birSaticiCalisanTx.setIban(iMap.getString(tableName, i, "IBAN"));
					birSaticiCalisanTx.setHesapNo(iMap.getBigDecimal(tableName, i, "MUSTERI_HESAP_NO"));

					session.save(birSaticiCalisanTx);
					session.flush();
				}
			}
			/**
			 * Kay�t �ncesi -mesaj- g�sterilmesi istendi�i (BNSPRPRO-8197) i�in mesaj g�sterildikten sonra ekrandan transaction
			 * ba�lat�lacak.
			 */
			if (iMap.getBoolean("IS_FROM_SCREEN")) {
				iMap.put("TRX_NAME", "3161");
				return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			else {
				String onaysizIslem = iMap.getString("TRX_ONAYSIZ_ISLEM");
				if (onaysizIslem.equals("E")) {
					String func = "{? = call pkg_trn3161.transaction_start(?,?)}";
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall(func);
					stmt.registerOutParameter(1, Types.VARCHAR);
					stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
					stmt.setString(3, onaysizIslem);
					stmt.execute();
					oMap.put("MESSAGE", stmt.getString(1));
					oMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
					return oMap;
				}
				else {
					iMap.put("TRX_NAME", "3161");
					return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN3161_KONTAKT_SATICI")
	public static GMMap trn3161KontaktSatici(GMMap iMap) {
		try {

			GMMap kontakt = new GMMap();

			if ("D".equals(iMap.getString("SATICI_TIP")) && (iMap.getString("DI_MUSTERI_NO") == null || iMap.getString("DI_MUSTERI_NO").isEmpty()))
				return kontakt;

			Date bankaTarih = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH");
			String firmaTipi = iMap.getString("SIRKET_TIPI");

			String trxNo = GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO").toString();
			kontakt.put("TRX_NO", trxNo);

			if ("M".equals(iMap.getString("SATICI_TIP"))) {
				if (iMap.getString("ADRES") == null || iMap.getString("ADRES").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Adres");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getString("IL") == null || iMap.getString("IL").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Adres �l");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getString("ILCE") == null || iMap.getString("ILCE").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Adres �l�e");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getString("ADRES") == null || iMap.getString("ADRES").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Adres");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getString("TELEFON_ALAN") == null || iMap.getString("TELEFON_ALAN").isEmpty() || iMap.getString("TELEFON") == null || iMap.getString("TELEFON").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Telefon");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}
			// ADRES
			List<HashMap<String, Object>> adresList = new ArrayList<HashMap<String, Object>>();

			HashMap<String, Object> adresData = new HashMap<String, Object>();
			adresData.put("ADRES_KOD", "I");
			adresData.put("ISYERI_UNVANI", iMap.getString("DI_MUSTERI_NO"));
			adresData.put("ADRES", iMap.getString("ADRES"));
			adresData.put("ADRES_IL_KOD", iMap.getString("IL"));
			adresData.put("ADRES_ILCE_KOD", iMap.getString("ILCE"));
			adresData.put("ULKE_KOD", "TR");
			adresData.put("EXTRE_ADRES_KOD_F", "E");
			adresData.put("UPD_DATE", bankaTarih);
			adresList.add(adresData);

			kontakt.put("ADRES_LIST", adresList);

			// TELEFON
			List<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();

			if (iMap.getString("TELEFON_ALAN") != null && !iMap.getString("TELEFON_ALAN").isEmpty() && iMap.getString("TELEFON") != null && !iMap.getString("TELEFON").isEmpty()) {
				HashMap<String, Object> telefonData = new HashMap<String, Object>();
				telefonData.put("TEL_TIP", "2");
				telefonData.put("ALAN_KOD", iMap.getString("TELEFON_ALAN"));
				telefonData.put("TEL_NO", iMap.getString("TELEFON"));
				telefonData.put("F_ILETISIM", "E");
				telefonData.put("ULKE_KODU", "90");
				telefonData.put("UPD_DATE", bankaTarih);
				telefonList.add(telefonData);
			}

			if (iMap.getString("FAX_ALAN") != null && !iMap.getString("FAX_ALAN").isEmpty() && iMap.getString("FAKS") != null && !iMap.getString("FAKS").isEmpty()) {
				HashMap<String, Object> faxData = new HashMap<String, Object>();
				faxData.put("TEL_TIP", "5");
				faxData.put("ALAN_KOD", iMap.getString("FAX_ALAN"));
				faxData.put("TEL_NO", iMap.getString("FAKS"));
				faxData.put("F_ILETISIM", "H");
				faxData.put("ULKE_KODU", "90");
				faxData.put("UPD_DATE", bankaTarih);
				telefonList.add(faxData);
			}

			kontakt.put("TELEFON_LIST", telefonList);

			if (firmaTipi == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "�irket Tipi");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (!"7".equals(firmaTipi)) {
				kontakt.put("MUSTERI_TIPI_KOD", "T");
				kontakt.put("DK_GRUP_KOD", "1044");
				kontakt.put("PROFIL_KODU", "1");
				kontakt.put("PROFIL_ALT1_KODU", "1");
				kontakt.put("TICARI_UNVAN", iMap.getString("DI_MUSTERI_NO"));
				kontakt.put("BOLUM_KODU", GMServiceExecuter.execute("BNSPR_TRN2201_GET_SUBE_KODU", new GMMap()).get("SUBE_KODU"));
				kontakt.put("UYRUK_KOD", "TR");
				kontakt.put("VERGI_DAIRE_KODU", iMap.getString("VERGI_DAIRESI"));
				kontakt.put("VERGI_DAIRE_IL_KODU", iMap.getString("VERGI_DAIRESI_IL"));
				kontakt.put("VERGI_NO", iMap.getString("VERGI_TCK_NO"));
				kontakt.put("YERLESIM_KOD", "I");
				if (iMap.getString("DI_MUSTERI_NO").length() <= 50)
					kontakt.put("KISA_AD", iMap.getString("DI_MUSTERI_NO"));
				else
					kontakt.put("KISA_AD", iMap.getString("DI_MUSTERI_NO").substring(0, 50));
				kontakt.put("MUSTERI_KONTAKT", "K");
				kontakt.put("ILK_ILISKI_TARIHI", bankaTarih);
				kontakt.put("BAGLI_KANAL_GRUBU", GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", new GMMap()).get("KANAL_KOD"));
				kontakt.put("KANAL_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_ALT_KOD", new GMMap()).get("KANAL_ALT_KOD"));
				kontakt.put("HESAP_UCRETI_F", "H");
				kontakt.put("MUSTERI_SEGMENTI", "B");
				String emailName = iMap.getString("E_POSTA_NAME");
				String emailNet = iMap.getString("E_POSTA_NET");
				if ((!emailName.equals("")) || (!emailNet.equals("")))
					kontakt.put("EMAIL_IS", emailName + "@" + emailNet);
				else
					kontakt.put("EMAIL_IS", "");
				kontakt.put("WEB_ADRESI", iMap.getString("WEB_ADRESI"));
				kontakt.put("ORIJINAL_EVRAKLIMI", "H");

				kontakt.put("FIRMA_TIPI", firmaTipi);
				kontakt.put("KURULUS_TARIHI", iMap.getDate("KURULUS_TARIHI"));

				// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
				kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
				kontakt.put("TRX_NAME", "10012");
				GMServiceExecuter.execute("BNSPR_TRN10012_SAVE", kontakt);

			}
			else if ("7".equals(firmaTipi)) {
				kontakt.put("MUSTERI_TIPI_KOD", "G");
				kontakt.put("TICARI_UNVAN", iMap.getString("DI_MUSTERI_NO"));

				if (iMap.containsKey("VERGI_TCK_NO") && iMap.getBigDecimal("VERGI_TCK_NO") != null && !"".equals(iMap.getBigDecimal("VERGI_TCK_NO"))) {
					GMMap kps = new GMMap();
					kps.put("tckno_in", iMap.getBigDecimal("VERGI_TCK_NO"));
					kps.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_KPS_KIMLIK_SORGULAMA", kps));

					kontakt.put("TC_KIMLIK_NO", kps.get("tckno_out"));
					kontakt.put("TCKNO_IN", kps.get("tckno_out"));
					String ad1 = kps.get("ad1").toString();
					String ad2 = "";
					String soyad = kps.get("soyad").toString();
					String kisaAd = ad1 + " " + soyad;
					if (kps.get("ad2") != null) {
						ad2 = kps.get("ad2").toString();
						kisaAd = ad1 + " " + ad2 + " " + soyad;
					}
					kontakt.put("ISIM", ad1);
					kontakt.put("IKINCI_ISIM", ad2);
					kontakt.put("SOYADI", soyad);
					kontakt.put("UYRUK_KOD", "TR");
					kontakt.put("DOGUM_TARIHI", kps.get("dogumTarihi"));
					kontakt.put("DOGUM_YERI", kps.get("dogumyeri"));
					kontakt.put("BABA_ADI", kps.get("babaad"));
					kontakt.put("ANNE_ADI", kps.get("anaad"));
					// kontakt.put("ANNE_KIZLIK_SOYADI",);
					kontakt.put("CINSIYET", kps.get("cinsiyet"));
					kontakt.put("CINSIYET_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_CINSIYET_KOD", kontakt).get("KOD"));

					kontakt.put("MEDENI_HAL", kps.get("medenihali"));
					kontakt.put("MEDENI_HAL_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_MEDENI_HAL_KOD", kontakt).get("KOD"));

					kontakt.put("AILE_SIRA_NO", kps.get("ailesirano"));
					kontakt.put("CILT_NO", kps.get("ciltkodu"));
					kontakt.put("SIRA_NO", kps.get("bireysirano"));
					kontakt.put("KIZLIK_SOYADI", kps.get("kizliksoyad"));
					kontakt.put("KISA_AD", kisaAd);
				}
				else {
					kontakt.put("ISIM", iMap.getString("ISIM"));
					kontakt.put("SOYADI", iMap.getString("SOYADI"));
					kontakt.put("TICARI_UNVAN", iMap.getString("TICARI_UNVAN"));
					kontakt.put("UYRUK_KOD", "TR");
				}
				kontakt.put("MUSTERI_KONTAKT", "K");
				String emailName = iMap.getString("E_POSTA_NAME");
				String emailNet = iMap.getString("E_POSTA_NET");
				if ((!emailName.equals("")) || (!emailNet.equals("")))
					kontakt.put("EMAIL_KISISEL", emailName + "@" + emailNet);
				else
					kontakt.put("EMAIL_KISISEL", "");
				kontakt.put("BAGLI_KANAL_GRUBU", GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", new GMMap()).get("KANAL_KOD"));
				kontakt.put("KANAL_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_ALT_KOD", new GMMap()).get("KANAL_ALT_KOD"));
				kontakt.put("DK_GRUP_KOD", "1043");
				kontakt.put("PROFIL_KOD", "4");
				kontakt.put("BOLUM_KODU", GMServiceExecuter.execute("BNSPR_TRN2201_GET_SUBE_KODU", new GMMap()).get("SUBE_KODU"));
				kontakt.put("YERLESIM_KOD", "I");

				kontakt.put("ILK_ILISKI_TARIHI", bankaTarih);
				kontakt.put("HESAP_UCRETI_F", "H");
				kontakt.put("MUSTERI_SEGMENTI", "B");
				kontakt.put("ORIJINAL_EVRAKLIMI", "H");
				kontakt.put("TICARI_SICIL_KAYIT_TARIHI", iMap.getDate("KURULUS_TARIHI"));

				// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
				kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
				kontakt.put("TRX_NAME", "10011");
				
				// ekranda bunlar i�in alan bulunmuyor, default olarak
				// �ifte vatanda�l�k : R ("Hay�r")
				// Green Card : R("De�ilim")
				kontakt.put("F_CIFTE_VATANDAS", "R");
				kontakt.put("F_GREEN_CARD", "R");
				
				GMServiceExecuter.execute("BNSPR_TRN10011_SAVE", kontakt);

			}
			GMMap oMap = new GMMap();

			oMap.put("TRX_NO", trxNo);
			oMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_COMMON_GET_MUSTERI_NO_BY_TRX_NO", oMap).get("MUSTERI_NO"));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN3161_KONTAKT_CALISAN")
	public static GMMap trn3161KontaktCalisan(GMMap iMap) {

		try {
			GMMap kontakt = new GMMap();
			GMMap oMap = new GMMap();

			Date bankaTarih = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH");

			String tableName = "CALISANLAR";
			int row = iMap.getInt("CALISAN_ROW");

			String trxNo = GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO").toString();
			kontakt.put("TRX_NO", trxNo);
			kontakt.put("MUSTERI_TIPI_KOD", "G");

			if (iMap.getBigDecimal(tableName, row, "TCK_NO") == null && !"E".equals(iMap.getString(tableName, row, "CIHAZ_KULLANICISI"))) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "�al��an TC Kimlik No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			GMMap kps = new GMMap();
			kps.put("tckno_in", iMap.getBigDecimal(tableName, row, "TCK_NO"));
			kps.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_KPS_KIMLIK_SORGULAMA", kps));

			kontakt.put("TC_KIMLIK_NO", kps.get("tckno_out"));
			kontakt.put("TCKNO_IN", kps.get("tckno_out"));
			String ad1 = kps.get("ad1").toString();
			String ad2 = "";
			String soyad = kps.get("soyad").toString();
			String kisaAd = ad1 + " " + soyad;
			if (kps.get("ad2") != null) {
				ad2 = kps.get("ad2").toString();
				kisaAd = ad1 + " " + ad2 + " " + soyad;
			}
			kontakt.put("ISIM", ad1);
			kontakt.put("IKINCI_ISIM", ad2);
			kontakt.put("SOYADI", soyad);
			kontakt.put("UYRUK_KOD", "TR");
			kontakt.put("DOGUM_TARIHI", kps.get("dogumTarihi"));
			kontakt.put("DOGUM_YERI", kps.get("dogumyeri"));
			kontakt.put("BABA_ADI", kps.get("babaad"));
			kontakt.put("ANNE_ADI", kps.get("anaad"));
			// kontakt.put("ANNE_KIZLIK_SOYADI",);
			kontakt.put("CINSIYET", kps.get("cinsiyet"));
			kontakt.put("CINSIYET_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_CINSIYET_KOD", kontakt).get("KOD"));

			kontakt.put("MEDENI_HAL", kps.get("medenihali"));
			kontakt.put("MEDENI_HAL_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_MEDENI_HAL_KOD", kontakt).get("KOD"));

			kontakt.put("AILE_SIRA_NO", kps.get("ailesirano"));
			kontakt.put("CILT_NO", kps.get("ciltkodu"));
			kontakt.put("SIRA_NO", kps.get("bireysirano"));
			kontakt.put("KIZLIK_SOYADI", kps.get("kizliksoyad"));
			kontakt.put("MUSTERI_KONTAKT", "K");
			String emailName = iMap.getString(tableName, row, "EPOSTA_NAME");
			String emailNet = iMap.getString(tableName, row, "EPOSTA_NET");
			if (StringUtils.isNotEmpty(emailNet) && StringUtils.isNotEmpty(emailName))
				kontakt.put("EMAIL_KISISEL", emailName + "@" + emailNet);
			else
				kontakt.put("EMAIL_KISISEL", "");
			kontakt.put("BAGLI_KANAL_GRUBU", GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", new GMMap()).get("KANAL_KOD"));
			kontakt.put("KANAL_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_ALT_KOD", new GMMap()).get("KANAL_ALT_KOD"));
			kontakt.put("DK_GRUP_KOD", "1042");
			kontakt.put("PROFIL_KOD", "1");
			kontakt.put("BOLUM_KODU", GMServiceExecuter.execute("BNSPR_TRN2201_GET_SUBE_KODU", new GMMap()).get("SUBE_KODU"));
			kontakt.put("YERLESIM_KOD", "I");
			kontakt.put("KISA_AD", kisaAd);
			kontakt.put("ILK_ILISKI_TARIHI", bankaTarih);
			kontakt.put("HESAP_UCRETI_F", "H");
			kontakt.put("MUSTERI_SEGMENTI", "N");
			kontakt.put("ORIJINAL_EVRAKLIMI", "H");

			// ADRES
			List<HashMap<String, Object>> adresList = new ArrayList<HashMap<String, Object>>();

			HashMap<String, Object> adresData = new HashMap<String, Object>();
			adresData.put("ADRES_KOD", "I");
			adresData.put("ISYERI_UNVANI", StringUtils.isEmpty(iMap.getString("DI_MUSTERI_NO")) ? kisaAd : iMap.getString("DI_MUSTERI_NO"));
			adresData.put("ADRES", iMap.getString("ADRES"));
			adresData.put("ADRES_IL_KOD", iMap.getString("IL"));
			adresData.put("ADRES_ILCE_KOD", iMap.getString("ILCE"));
			adresData.put("ULKE_KOD", "TR");
			adresData.put("EXTRE_ADRES_KOD_F", "E");
			adresData.put("UPD_DATE", bankaTarih);
			adresList.add(adresData);

			kontakt.put("ADRES_LIST", adresList);

			// TELEFON
			List<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();

			if (iMap.getBigDecimal(tableName, row, "CEP_TEL") != null && !iMap.getString(tableName, row, "CEP_TEL").isEmpty()) {
				HashMap<String, Object> telefonData = new HashMap<String, Object>();
				telefonData.put("TEL_TIP", "3");
				telefonData.put("ALAN_KOD", iMap.getBigDecimal(tableName, row, "CEP_TEL_ALAN"));
				telefonData.put("TEL_NO", iMap.getString(tableName, row, "CEP_TEL"));
				telefonData.put("F_ILETISIM", "E");
				telefonData.put("ULKE_KODU", "90");
				telefonData.put("UPD_DATE", bankaTarih);
				telefonList.add(telefonData);
			}

			if (iMap.getString("TELEFON_ALAN") != null && !iMap.getString("TELEFON_ALAN").isEmpty() && iMap.getString("TELEFON") != null && !iMap.getString("TELEFON").isEmpty()) {
				HashMap<String, Object> isTelefonData = new HashMap<String, Object>();
				isTelefonData.put("TEL_TIP", "2");
				isTelefonData.put("ALAN_KOD", iMap.getString("TELEFON_ALAN"));
				isTelefonData.put("TEL_NO", iMap.getString("TELEFON"));
				isTelefonData.put("F_ILETISIM", "H");
				isTelefonData.put("ULKE_KODU", "90");
				isTelefonData.put("UPD_DATE", bankaTarih);
				telefonList.add(isTelefonData);
			}
			kontakt.put("TELEFON_LIST", telefonList);

			List<HashMap<String, Object>> nullList = new ArrayList<HashMap<String, Object>>();
			kontakt.put("VELI_VASI", nullList);
			kontakt.put("CBS_MUSTERI_BASVURU_NOTLAR", nullList);
			kontakt.put("CBS_MUSTERI_BASVURU_DOKUMAN", nullList);
			kontakt.put("CBS_MUSTERI_BASVURU_GORUSME", nullList);

			// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
			kontakt.put("TRX_NAME", "10011");
			
			// ekranda bunlar i�in alan bulunmuyor, default olarak
			// �ifte vatanda�l�k : R ("Hay�r")
			// Green Card : R("De�ilim")
			kontakt.put("F_CIFTE_VATANDAS", "R");
			kontakt.put("F_GREEN_CARD", "R");
			
			GMServiceExecuter.execute("BNSPR_TRN10011_SAVE", kontakt);

			oMap.put("TRX_NO", trxNo);
			oMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_COMMON_GET_MUSTERI_NO_BY_TRX_NO", oMap).get("MUSTERI_NO"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN3161_GET_DAGITICI_FOR_BAYI")
	public static GMMap trn3161GetDagiticiForBayi(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			iMap.put("COMBO", "DAGITICI_ALL");

			List<?> dagiciFirmalar = (List<?>) (GMServiceExecuter.execute("BPM_PRC3299_FILL_COMBOBOX", iMap)).get("RESULTS");

			String tableName = "BAGLI_OLDUGU_DAGITICI_FIRMALAR";
			int row = 0;
			System.out.println("dagitici firmalar..");
			if (dagiciFirmalar == null)
				return oMap;

			for (Iterator<?> iterator = dagiciFirmalar.iterator(); iterator.hasNext();) {
				HashMap<?, ?> data = (HashMap<?, ?>) iterator.next();
				BirSaticiIliski birSaticiIliski = (BirSaticiIliski) session.createCriteria(BirSaticiIliski.class).add(Restrictions.eq("id.saticiKod", iMap.getBigDecimal("SATICI_KOD"))).add(Restrictions.eq("id.bagliOldSatKod", new BigDecimal((String) data.get("VALUE")))).uniqueResult();
				if (birSaticiIliski != null) {
					String bayiRef = (birSaticiIliski.getDistBayiRef() == null) ? "" : birSaticiIliski.getDistBayiRef();
					oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxSelected(birSaticiIliski.getSec()));
					oMap.put(tableName, row, "DIST_BAYI_REF", bayiRef);
				}
				oMap.put(tableName, row, "VALUE", data.get("VALUE"));
				oMap.put(tableName, row, "NAME", data.get("NAME"));
				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3161_GET_INFO_FOR_UPDATE")
	public static GMMap trn3161GetInfoForUpdate(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			BirSatici birSatici = (BirSatici) session.get(BirSatici.class, iMap.getBigDecimal("SATICI_KOD"));

			BigDecimal musteriNo = birSatici.getMusteriNo();
			oMap.put("MUSTERI_NO", musteriNo);

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(LovHelper.getLOVQuery("3161/LOV_TUZEL_MUSTERI_GET_INFO"));
			stmt.setBigDecimal(1, musteriNo);
			stmt.setBigDecimal(2, musteriNo);
			rSet = stmt.executeQuery();

			if (rSet.next()) {
				oMap.put("DI_MUSTERI_NO", rSet.getString("UNVAN"));
				oMap.put("VERGI_NUMARASI", rSet.getString("VERGI_NO"));
				oMap.put("VERGI_DAIRESI_IL", rSet.getString("VERGI_IL_KODU"));
				oMap.put("VERGI_DAIRESI", rSet.getString("VERGI_DAIRE_KODU"));
				oMap.put("SIRKET_TIPI", rSet.getString("FIRMA_TIPI"));
				oMap.put("ADI", rSet.getString("ADI"));
				oMap.put("SOYADI", rSet.getString("SOYADI"));
				oMap.put("TICARI_UNVAN", rSet.getString("TICARI_UNVAN"));

				GMMap xMap = new GMMap();
				xMap.put("EMAIL_1", rSet.getString("EMAIL_IS"));
				GMMap eMap = new GMMap();
				eMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS", xMap));
				oMap.put("E_POSTA_NAME", eMap.getString("EMAIL_11"));
				oMap.put("E_POSTA_NET", eMap.getString("EMAIL_12"));

				oMap.put("TELEFON_ALAN", rSet.getString("TEL_ALAN"));
				oMap.put("TELEFON", rSet.getString("TELEFON"));
				oMap.put("FAX_ALAN", rSet.getString("FAX_ALAN"));
				oMap.put("FAKS", rSet.getString("FAX"));
				oMap.put("ADRES", rSet.getString("ADRES"));
				oMap.put("IL_KOD", rSet.getString("ADRES_IL"));
				oMap.put("ILCE_KOD", rSet.getString("ADRES_ILCE"));

				oMap.put("WEB_ADRESI", rSet.getString("WEB_ADRES"));
				oMap.put("KURULUS_TARIHI", rSet.getDate("KURULUS_TARIHI"));
			}

			oMap.put("SATICI_TELEFON_ALAN", birSatici.getAlanKodTel());
			oMap.put("SATICI_TELEFON", birSatici.getTelNo());
			oMap.put("SATICI_FAX_ALAN", birSatici.getAlanKodFaks());
			oMap.put("SATICI_FAX", birSatici.getFaksNo());
			oMap.put("SATICI_ADRES", birSatici.getAdres());
			oMap.put("SATICI_IL_KOD", birSatici.getAdresIl());
			oMap.put("SATICI_ILCE_KOD", birSatici.getAdresIlce());

			oMap.put("SATICI_TIP", birSatici.getSaticiTipKod());
			oMap.put("YETKI_SEVIYESI", birSatici.getYetkiSeviyeKod());
			oMap.put("BAGLI_OLDUGU_BOLGE", birSatici.getBagliOldBolgeKod());
			oMap.put("BAGLI_OLDUGU_MERKEZ_BAYI_KOD", birSatici.getBagliMerkezBayi());
			oMap.put("DI_BAGLI_OLDUGU_MERKEZ_BAYI_KOD", LovHelper.diLov(birSatici.getBagliMerkezBayi(), "3161/LOV_MERKEZ_BAYI", "SATICI_ADI"));
			oMap.put("DOKUMAN_YOLLAMA_TIPI", birSatici.getDokYollamaKod());
			oMap.put("DURUM", birSatici.getDrm());
			oMap.put("PARA_CIKISI", birSatici.getParaCikisOtoEh());
			oMap.put("MUSTERI_HESAP_NO", birSatici.getHesapNo());
			oMap.put("DI_MUSTERI_HESAP_NO", LovHelper.diLov(birSatici.getHesapNo(), musteriNo, "3161/LOV_VDSZ_HESAP", "KISA_ISIM"));
			oMap.put("BANKA_KOD", birSatici.getBankaKod());
			oMap.put("DI_BANKA_KOD", LovHelper.diLov(birSatici.getBankaKod(), "3161/LOV_BANKA", "BANKA_ADI"));
			oMap.put("SUBE_KOD", birSatici.getBankaSube());
			oMap.put("DI_SUBE_KOD", LovHelper.diLov(birSatici.getBankaSube(), birSatici.getBankaKod(), oMap.getString("IL_KOD"), "3161/LOV_BANKA_SUBE", "SUBE_ADI"));
			oMap.put("HESAP_A", birSatici.getBankaHesap());
			oMap.put("SATICI_GORUSU", birSatici.getSatisGorusKod());
			oMap.put("BAYI_SORUMLU_KISI", birSatici.getBayiSorumluKisi());
			oMap.put("BAYI_UBE_SORUMLU", birSatici.getBayiUbeSorumlu());
			String krediTurKodlari = birSatici.getKrdTurKodlari();
			oMap.put("PORTFOY_KOD", birSatici.getPortfoyKod());
			oMap.put("KREDI_ODEMESI", birSatici.getKrediOdemesi() != null ? birSatici.getKrediOdemesi() : "0");
			oMap.put("DEBIT_KART", birSatici.getDebitKart() != null ? birSatici.getDebitKart() : "0");
			oMap.put("UPSELL_YAPILABILIR", birSatici.getUpsellYapilabilir() != null ? birSatici.getUpsellYapilabilir() : "0");
			oMap.put("KORUMA_KREDISI", birSatici.getKorumaKredisi() != null ? birSatici.getKorumaKredisi() : "0");
			oMap.put("FAIZSIZ_FINANSMAN",  GuimlUtil.convertToCheckBoxSelected(birSatici.getFaizsizFinansman()));
			oMap.put("BAYI_KREDI_TIPI", birSatici.getBayiKrediTipi() != null ? birSatici.getBayiKrediTipi() : "0");
			oMap.put("BAYI_KREDI_KODU", birSatici.getBayiKrediKodu());
			oMap.put("F_IHTIYAC", false);
			oMap.put("F_TASIT", false);
			oMap.put("F_KONUT", false);
			oMap.put("F_TARIM", false);
			if (krediTurKodlari.charAt(0) == '1')
				oMap.put("F_IHTIYAC", true);
			if (krediTurKodlari.charAt(1) == '1')
				oMap.put("F_KONUT", true);
			if (krediTurKodlari.charAt(2) == '1')
				oMap.put("F_TASIT", true);
			if (krediTurKodlari.charAt(6) == '1')
				oMap.put("F_TARIM", true);

			oMap.put("ACIKLAMA", birSatici.getAciklama());
			oMap.put("SUBE_MUSTERI_NO", birSatici.getSubeMusteriNo());
			oMap.put("DISTRIBUTOR_HESAP_NO", birSatici.getDistributorHesapNo());
			oMap.put("DI_FIRMA_HESAP_NO", LovHelper.diLov(birSatici.getDistributorHesapNo(), musteriNo, "3161/LOV_FIRMA_HESAP_NO", "KISA_ISIM"));

			if (("E").equals(birSatici.getSigortaSatisiEh())) {
				oMap.put("SIGORTA_SATISI", true);
			}
			else {
				oMap.put("SIGORTA_SATISI", false);
			}

			if ("D".equals(birSatici.getSaticiTipKod()))
				iMap.put("COMBO", "DAGITICI");
			else
				iMap.put("COMBO", "DAGITICI_ALL");
			
			List<?> dagiciFirmalar = (List<?>) (GMServiceExecuter.execute("BPM_PRC3299_FILL_COMBOBOX", iMap)).get("RESULTS");

			String tableName = "BAGLI_OLDUGU_DAGITICI_FIRMALAR";
			int row = 0;
			if (dagiciFirmalar != null && dagiciFirmalar.size() > 0) {
				for (Iterator<?> iterator = dagiciFirmalar.iterator(); iterator.hasNext();) {
					HashMap<?, ?> data = (HashMap<?, ?>) iterator.next();
					BirSaticiIliski birSaticiIliski = (BirSaticiIliski) session.createCriteria(BirSaticiIliski.class).add(Restrictions.eq("id.saticiKod", birSatici.getKod())).add(Restrictions.eq("id.bagliOldSatKod", new BigDecimal((String) data.get("VALUE")))).uniqueResult();
					if (birSaticiIliski != null) {
						String bayiRef = (birSaticiIliski.getDistBayiRef() == null) ? "" : birSaticiIliski.getDistBayiRef();
						oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxSelected(birSaticiIliski.getSec()));
						oMap.put(tableName, row, "DIST_BAYI_REF", bayiRef);
					}
					oMap.put(tableName, row, "VALUE", data.get("VALUE"));
					oMap.put(tableName, row, "NAME", data.get("NAME"));
					row++;
				}
			}

			List<?> calisanlarList = session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("birSatici.kod", iMap.getBigDecimal("SATICI_KOD"))).add(Restrictions.eq("durum", "ONAY")).list(); // .add(Restrictions.eq("durum","ONAY"))
			tableName = "CALISANLAR";
			row = 0;
			for (int i = 0; i < calisanlarList.size(); i++) {

				BirSaticiCalisan birSaticiCalisan = (BirSaticiCalisan) calisanlarList.get(i);
				oMap.put(tableName, row, "KOD", birSaticiCalisan.getKod());
				oMap.put(tableName, row, "MUSTERI_NO", birSaticiCalisan.getMusteriNo());

				ArrayList<Object> listPar = new ArrayList<Object>();
				listPar.add(birSaticiCalisan.getMusteriNo());
				HashMap<?, ?> gercekMusteri = LovHelper.diLovAll(birSaticiCalisan.getMusteriNo(), "3161/LOV_GERCEK_MUSTERI_GET_INFO", listPar);
				if (gercekMusteri != null) {
					oMap.put(tableName, row, "DI_MUSTERI_NO", (String) gercekMusteri.get("UNVAN"));
					oMap.put(tableName, row, "TCK_NO", (String) gercekMusteri.get("TC_KIMLIK_NO"));
					oMap.put(tableName, row, "ADI", (String) gercekMusteri.get("ADI"));
					oMap.put(tableName, row, "IKINCI_ADI", (String) gercekMusteri.get("IKINCI_ADI"));
					oMap.put(tableName, row, "SOYADI", (String) gercekMusteri.get("SOYADI"));
					oMap.put(tableName, row, "UYRUK", (String) gercekMusteri.get("UYRUK_KOD"));
					oMap.put(tableName, row, "DOGUM_TARIHI", (String) gercekMusteri.get("DOGUM_TARIHI"));
					oMap.put(tableName, row, "DOGUM_YERI", (String) gercekMusteri.get("DOGUM_YERI"));
					oMap.put(tableName, row, "BABA_ADI", (String) gercekMusteri.get("BABA_ADI"));
					oMap.put(tableName, row, "ANNE_ADI", (String) gercekMusteri.get("ANNE_ADI"));

					oMap.put(tableName, row, "CEP_TEL_ALAN", (String) gercekMusteri.get("GSM_ALAN"));
					oMap.put(tableName, row, "CEP_TEL", (String) gercekMusteri.get("GSM"));

					GMMap xMap = new GMMap();
					xMap.put("EMAIL_1", (String) gercekMusteri.get("EMAIL_KISISEL"));
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS", xMap));
					oMap.put(tableName, row, "EPOSTA_NAME", oMap.get("EMAIL_11"));
					oMap.put(tableName, row, "EPOSTA_NET", oMap.get("EMAIL_12"));
				}

				oMap.put(tableName, row, "ORTAK_MI", birSaticiCalisan.getOrtakEh());
				oMap.put(tableName, row, "ORTAKLIK_PAYI", birSaticiCalisan.getOrtaklikPayi());
				oMap.put(tableName, row, "ISE_BASLAMA_TARIHI", birSaticiCalisan.getIseBaslamaTar());
				oMap.put(tableName, row, "POZISYONU", birSaticiCalisan.getPozisyonKod());
				oMap.put(tableName, row, "TUTTUGU_TAKIM", birSaticiCalisan.getTuttuguTakimKod());
				oMap.put(tableName, row, "HOBILERI", birSaticiCalisan.getHobiKod());
				oMap.put(tableName, row, "CALISAN_STATUSU", birSaticiCalisan.getCalStatuKod());
				oMap.put(tableName, row, "KAPANMA_NEDENI", birSaticiCalisan.getCalKismiKapanmaNedenKod());
				oMap.put(tableName, row, "YETKI_SEVIYESI", birSaticiCalisan.getYetkiGirisKod());
				oMap.put(tableName, row, "YETKI_SEVIYESI_GUNCELLEME_TAR", birSaticiCalisan.getYetkiGirisKodGuncellemeTar());
				oMap.put(tableName, row, "ONCEKI_YETKI_SEVIYESI", birSaticiCalisan.getOncekiYetkiGirisKod());
				oMap.put(tableName, row, "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR", birSaticiCalisan.getOncekiYetkiGuncellemeTar());
				oMap.put(tableName, row, "GIZLI_YETKI_SEVIYESI", birSaticiCalisan.getYetkiGirisKod());
				oMap.put(tableName, row, "BANKA_KOD", birSaticiCalisan.getDigerBankaKod());
				oMap.put(tableName, row, "DI_BANKA_KOD", LovHelper.diLov(birSaticiCalisan.getDigerBankaKod(), "3161/LOV_BANKA", "BANKA_ADI"));
				oMap.put(tableName, row, "SUBE_KOD", birSaticiCalisan.getDigerSubeKod());
				oMap.put(tableName, row, "DI_SUBE_KOD", LovHelper.diLov(birSaticiCalisan.getDigerSubeKod(), birSaticiCalisan.getDigerBankaKod(), oMap.getString("IL_KOD"), "3161/LOV_BANKA_SUBE", "SUBE_ADI"));
				oMap.put(tableName, row, "HESAP_A", birSaticiCalisan.getDigerHesapNo());
				oMap.put(tableName, row, "IBAN", birSaticiCalisan.getIban());
				oMap.put(tableName, row, "MUSTERI_HESAP_NO", birSaticiCalisan.getHesapNo());
				oMap.put(tableName, row, "DI_MUSTERI_HESAP_NO", LovHelper.diLov(birSaticiCalisan.getHesapNo(), birSaticiCalisan.getMusteriNo(), "3161/LOV_VDSZ_HESAP", "KISA_ISIM"));
				oMap.put(tableName, row, "YENI_MUSTERI_MI", false);
				oMap.put(tableName, row, "CIHAZ_KULLANICISI", birSaticiCalisan.getCihazKullanicisi());
				oMap.put(tableName, row, "BAYI_CIHAZ_KODU", birSaticiCalisan.getBayiCihazKodu());

				row++;
			}
			BirSaticiTahsis birSaticiTahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", birSatici.getKod())).uniqueResult();
			if (birSaticiTahsis != null) {
				oMap.put("DST_KAZANIM_KANAL", birSaticiTahsis.getDstKazanimKanal());
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3161_GET_INFO_BY_TRX_NO")
	public static GMMap trn3161GetInfoByTrxNo(GMMap iMap) {

		try {

			GMMap oMap = new GMMap();

			setBirSaticiMap(iMap.getBigDecimal("TRX_NO"), oMap);

			String dagiticiFirmaTableName = "BAGLI_OLDUGU_DAGITICI_FIRMALAR";
			setDagiticiFirmalarTable(iMap.getBigDecimal("TRX_NO"), dagiticiFirmaTableName, oMap);
			String calisanlarTableName = "CALISANLAR";
			setCalisanlarTable(iMap.getBigDecimal("TRX_NO"), calisanlarTableName, oMap);

			GMMap roleTreeMap = getDlrRoleTreeByTrxNo(iMap);
			oMap.put("YETKI_SEVIYE_TREE", roleTreeMap.get("LIST"));

			// Renklendirme

			if ("ISLEM_GORUNTULE".equals(iMap.getString("ACTION"))) {
				GMMap i2Map = new GMMap();
				i2Map.put("TRX_NO", iMap.get("TRX_NO"));
				i2Map.put("SATICI_KOD", oMap.get("SATICI_KOD"));
				BigDecimal oldTxNo = GMServiceExecuter.call("BNSPR_TRN3161_GET_ONCEKI_TX_NO", i2Map).getBigDecimal("OLD_TRX_NO");

				GMMap oldMap = new GMMap();
				if (oldTxNo != null) {
					setBirSaticiMap(oldTxNo, oldMap);
				}
				else {
					oldMap = null;
				}

				oMap.putAll(BeanSetProperties.mapDifference(oldMap, oMap));

				// Tablolar i�in renklendirme
				String oldDagiticiFirmaTableName = "OLD_BAGLI_OLDUGU_DAGITICI_FIRMALAR";
				setDagiticiFirmalarTable(oldTxNo, oldDagiticiFirmaTableName, oMap);
				oMap.put("DAGITICI_FIRMALAR_COLOR_DATA", (BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldDagiticiFirmaTableName), (ArrayList<?>) oMap.get(dagiticiFirmaTableName), "VALUE")).get("COLOR_DATA"));

				// Tablolar i�in renklendirme
				String oldCalisanlarTableName = "OLD_CALISANLAR";
				setCalisanlarTable(oldTxNo, oldCalisanlarTableName, oMap);
				oMap.put("CALISANLAR_COLOR_DATA", (BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldCalisanlarTableName), (ArrayList<?>) oMap.get(calisanlarTableName), "KOD")).get("COLOR_DATA"));

			}
			// Renklendirme biti�

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static void setBirSaticiMap(BigDecimal txNo, GMMap oMap) throws SQLException, FileNotFoundException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiTx birSaticiTx = (BirSaticiTx) session.get(BirSaticiTx.class, txNo);

			oMap.put("SATICI_KOD", birSaticiTx.getKod());
			oMap.put("DI_SATICI_KOD", birSaticiTx.getSaticiAdi());

			BigDecimal musteriNo = birSaticiTx.getMusteriNo();
			oMap.put("MUSTERI_NO", musteriNo);

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(LovHelper.getLOVQuery("3161/LOV_TUZEL_MUSTERI_GET_INFO"));
			stmt.setBigDecimal(1, musteriNo);
			stmt.setBigDecimal(2, musteriNo);
			rSet = stmt.executeQuery();

			if (rSet.next()) {
				oMap.put("DI_MUSTERI_NO", rSet.getString("UNVAN"));
				oMap.put("VERGI_NUMARASI", rSet.getString("VERGI_NO"));
				oMap.put("VERGI_DAIRESI_IL", rSet.getString("VERGI_IL_KODU"));
				oMap.put("VERGI_DAIRESI", rSet.getString("VERGI_DAIRE_KODU"));
				oMap.put("SIRKET_TIPI", rSet.getString("FIRMA_TIPI"));

				GMMap xMap = new GMMap();
				xMap.put("EMAIL_1", rSet.getString("EMAIL_IS"));
				GMMap eMap = new GMMap();
				eMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS", xMap));
				oMap.put("E_POSTA_NAME", eMap.getString("EMAIL_11"));
				oMap.put("E_POSTA_NET", eMap.getString("EMAIL_12"));

				oMap.put("TELEFON_ALAN", rSet.getString("TEL_ALAN"));
				oMap.put("TELEFON", rSet.getString("TELEFON"));
				oMap.put("FAX_ALAN", rSet.getString("FAX_ALAN"));
				oMap.put("FAKS", rSet.getString("FAX"));
				oMap.put("ADRES", rSet.getString("ADRES"));
				oMap.put("IL_KOD", rSet.getString("ADRES_IL"));
				oMap.put("ILCE_KOD", rSet.getString("ADRES_ILCE"));

				oMap.put("WEB_ADRESI", rSet.getString("WEB_ADRES"));
				oMap.put("KURULUS_TARIHI", rSet.getDate("KURULUS_TARIHI"));
			}

			GMMap aMap = new GMMap();
			aMap.put("MUSTERI_NO", musteriNo);
			/* oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2033_GET_MUSTERI_ADRES", aMap)); */

			oMap.put("SATICI_TIP", birSaticiTx.getSaticiTipKod());
			oMap.put("YETKI_SEVIYESI", birSaticiTx.getYetkiSeviyeKod());
			oMap.put("BAGLI_OLDUGU_BOLGE", birSaticiTx.getBagliOldBolgeKod());
			oMap.put("BAGLI_OLDUGU_MERKEZ_BAYI_KOD", birSaticiTx.getBagliMerkezBayi());
			oMap.put("DI_BAGLI_OLDUGU_MERKEZ_BAYI_KOD", LovHelper.diLov(birSaticiTx.getBagliMerkezBayi(), "3161/LOV_MERKEZ_BAYI", "SATICI_ADI"));
			oMap.put("DOKUMAN_YOLLAMA_TIPI", birSaticiTx.getDokYollamaKod());
			oMap.put("DURUM", birSaticiTx.getDrm());
			oMap.put("PARA_CIKISI", birSaticiTx.getParaCikisOtoEh());
			oMap.put("MUSTERI_HESAP_NO", birSaticiTx.getHesapNo());
			oMap.put("DI_MUSTERI_HESAP_NO", LovHelper.diLov(birSaticiTx.getHesapNo(), musteriNo, "3161/LOV_VDSZ_HESAP", "KISA_ISIM"));
			oMap.put("BANKA_KOD", birSaticiTx.getBankaKod());
			oMap.put("DI_BANKA_KOD", LovHelper.diLov(birSaticiTx.getBankaKod(), "3161/LOV_BANKA", "BANKA_ADI"));
			oMap.put("SUBE_KOD", birSaticiTx.getBankaSube());
			oMap.put("DI_SUBE_KOD", LovHelper.diLov(birSaticiTx.getBankaSube(), birSaticiTx.getBankaKod(), oMap.getString("IL_KOD"), "3161/LOV_BANKA_SUBE", "SUBE_ADI"));
			oMap.put("HESAP_A", birSaticiTx.getBankaHesap());
			oMap.put("SATICI_GORUSU", birSaticiTx.getSatisGorusKod());

			oMap.put("SATICI_ADRES", birSaticiTx.getAdres());
			oMap.put("SATICI_IL_KOD", birSaticiTx.getAdresIl());
			oMap.put("SATICI_ILCE_KOD", birSaticiTx.getAdresIlce());
			oMap.put("SATICI_TELEFON_ALAN", birSaticiTx.getAlanKodTel());
			oMap.put("SATICI_TELEFON", birSaticiTx.getTelNo());
			oMap.put("SATICI_FAX_ALAN", birSaticiTx.getAlanKodFaks());
			oMap.put("SATICI_FAX", birSaticiTx.getFaksNo());
			oMap.put("BAYI_SORUMLU_KISI", birSaticiTx.getBayiSorumluKisi());
			oMap.put("BAYI_UBE_SORUMLU", birSaticiTx.getBayiUbeSorumlu());
			oMap.put("PORTFOY_KOD", birSaticiTx.getPortfoyKod());
			oMap.put("SUBE_MUSTERI_NO", birSaticiTx.getSubeMusteriNo());
			oMap.put("DISTRIBUTOR_HESAP_NO", birSaticiTx.getDistributorHesapNo());
			oMap.put("DI_FIRMA_HESAP_NO", LovHelper.diLov(birSaticiTx.getDistributorHesapNo(), musteriNo, "3161/LOV_FIRMA_HESAP_NO", "KISA_ISIM"));
			oMap.put("KREDI_ODEMESI", birSaticiTx.getKrediOdemesi() != null ? birSaticiTx.getKrediOdemesi() : "0");
			oMap.put("DEBIT_KART", birSaticiTx.getDebitKart() != null ? birSaticiTx.getDebitKart() : "0");
			oMap.put("UPSELL_YAPILABILIR", birSaticiTx.getUpsellYapilabilir() != null ? birSaticiTx.getUpsellYapilabilir() : "0");
			oMap.put("KORUMA_KREDISI", birSaticiTx.getKorumaKredisi() != null ? birSaticiTx.getKorumaKredisi() : "0");
			oMap.put("FAIZSIZ_FINANSMAN",  GuimlUtil.convertToCheckBoxSelected(birSaticiTx.getFaizsizFinansman()));
			oMap.put("BAYI_KREDI_TIPI", birSaticiTx.getBayiKrediTipi() != null ? birSaticiTx.getBayiKrediTipi() : "0");
			oMap.put("BAYI_KREDI_KODU", birSaticiTx.getBayiKrediKodu());

			if (("E").equals(birSaticiTx.getSigortaSatisiEh())) {
				oMap.put("SIGORTA_SATISI", true);
			}
			else {
				oMap.put("SIGORTA_SATISI", false);
			}

			String krediTurKodlari = birSaticiTx.getKrdTurKodlari();
			oMap.put("F_IHTIYAC", false);
			oMap.put("F_TASIT", false);
			oMap.put("F_KONUT", false);
			oMap.put("F_TARIM", false);
			if (krediTurKodlari.charAt(0) == '1')
				oMap.put("F_IHTIYAC", true);
			if (krediTurKodlari.charAt(1) == '1')
				oMap.put("F_KONUT", true);
			if (krediTurKodlari.charAt(2) == '1')
				oMap.put("F_TASIT", true);
			if (krediTurKodlari.charAt(6) == '1')
				oMap.put("F_TARIM", true);

			oMap.put("ACIKLAMA", birSaticiTx.getAciklama());
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	private static void setDagiticiFirmalarTable(BigDecimal txNo, String tableName, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> dagitiFirmalar = session.createCriteria(BirSaticiIliskiTx.class).add(Restrictions.eq("id.txNo", txNo)).list();
		int row = 0;
		for (int i = 0; i < dagitiFirmalar.size(); i++) {
			BirSaticiIliskiTx birSaticiIliskiTx = (BirSaticiIliskiTx) dagitiFirmalar.get(i);
			oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxSelected(birSaticiIliskiTx.getSec()));
			oMap.put(tableName, row, "DIST_BAYI_REF", birSaticiIliskiTx.getDistBayiRef());
			oMap.put(tableName, row, "VALUE", birSaticiIliskiTx.getId().getBagliOldSatKod());
			oMap.put(tableName, row, "NAME", LovHelper.diLov(birSaticiIliskiTx.getId().getBagliOldSatKod(), "3161/LOV_DAG_FIRMA_ALL", "SATICI_ADI"));
			row++;
		}
	}

	private static void setCalisanlarTable(BigDecimal txNo, String tableName, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");

		List<?> calisanlarList = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo", txNo)).list();

		int row = 0;
		for (int i = 0; i < calisanlarList.size(); i++) {

			BirSaticiCalisanTx birSaticiCalisanTx = (BirSaticiCalisanTx) calisanlarList.get(i);
			oMap.put(tableName, row, "MUSTERI_NO", birSaticiCalisanTx.getMusteriNo());

			ArrayList<Object> listPar = new ArrayList<Object>();
			listPar.add(birSaticiCalisanTx.getMusteriNo());
			HashMap<?, ?> musteriLovMap = LovHelper.diLovAll(birSaticiCalisanTx.getMusteriNo(), "3161/LOV_GERCEK_MUSTERI_GET_INFO", listPar);
			if (musteriLovMap != null) {
				oMap.put(tableName, row, "DI_MUSTERI_NO", (String) musteriLovMap.get("UNVAN"));
				oMap.put(tableName, row, "TCK_NO", (String) musteriLovMap.get("TC_KIMLIK_NO"));
				oMap.put(tableName, row, "ADI", (String) musteriLovMap.get("ADI"));
				oMap.put(tableName, row, "IKINCI_ADI", (String) musteriLovMap.get("IKINCI_ADI"));
				oMap.put(tableName, row, "SOYADI", (String) musteriLovMap.get("SOYADI"));
				oMap.put(tableName, row, "UYRUK", (String) musteriLovMap.get("UYRUK_KOD"));
				oMap.put(tableName, row, "DOGUM_TARIHI", musteriLovMap.get("DOGUM_TARIHI"));
				oMap.put(tableName, row, "DOGUM_YERI", (String) musteriLovMap.get("DOGUM_YERI"));
				oMap.put(tableName, row, "BABA_ADI", (String) musteriLovMap.get("BABA_ADI"));
				oMap.put(tableName, row, "ANNE_ADI", (String) musteriLovMap.get("ANNE_ADI"));

				GMMap xMap = new GMMap();
				xMap.put("EMAIL_1", (String) musteriLovMap.get("EMAIL_KISISEL"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS", xMap));
				oMap.put(tableName, row, "EPOSTA_NAME", oMap.get("EMAIL_11"));
				oMap.put(tableName, row, "EPOSTA_NET", oMap.get("EMAIL_12"));

				oMap.put(tableName, row, "CEP_TEL_ALAN", (String) musteriLovMap.get("GSM_ALAN"));
				oMap.put(tableName, row, "CEP_TEL", (String) musteriLovMap.get("GSM"));
			}
			oMap.put(tableName, row, "KOD", birSaticiCalisanTx.getId().getKod());
			oMap.put(tableName, row, "ORTAK_MI", birSaticiCalisanTx.getOrtakEh());
			oMap.put(tableName, row, "ORTAKLIK_PAYI", birSaticiCalisanTx.getOrtaklikPayi());
			oMap.put(tableName, row, "ISE_BASLAMA_TARIHI", birSaticiCalisanTx.getIseBaslamaTar());
			oMap.put(tableName, row, "POZISYONU", birSaticiCalisanTx.getPozisyonKod());
			oMap.put(tableName, row, "TUTTUGU_TAKIM", birSaticiCalisanTx.getTuttuguTakimKod());
			oMap.put(tableName, row, "HOBILERI", birSaticiCalisanTx.getHobiKod());
			oMap.put(tableName, row, "CALISAN_STATUSU", birSaticiCalisanTx.getCalStatuKod());
			oMap.put(tableName, row, "KAPANMA_NEDENI", birSaticiCalisanTx.getCalKismiKapanmaNedenKod());
			oMap.put(tableName, row, "YETKI_SEVIYESI", birSaticiCalisanTx.getYetkiGirisKod());
			oMap.put(tableName, row, "YETKI_SEVIYESI_GUNCELLEME_TAR", birSaticiCalisanTx.getYetkiGirisKodGuncellemeTar());
			oMap.put(tableName, row, "ONCEKI_YETKI_SEVIYESI", birSaticiCalisanTx.getOncekiYetkiGirisKod());
			oMap.put(tableName, row, "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR", birSaticiCalisanTx.getOncekiYetkiGuncellemeTar());
			oMap.put(tableName, row, "GIZLI_YETKI_SEVIYESI", birSaticiCalisanTx.getYetkiGirisKod());
			oMap.put(tableName, row, "BANKA_KOD", birSaticiCalisanTx.getDigerBankaKod());
			oMap.put(tableName, row, "DI_BANKA_KOD", LovHelper.diLov(birSaticiCalisanTx.getDigerBankaKod(), "3161/LOV_BANKA", "BANKA_ADI"));
			oMap.put(tableName, row, "SUBE_KOD", birSaticiCalisanTx.getDigerSubeKod());
			oMap.put(tableName, row, "DI_SUBE_KOD", LovHelper.diLov(birSaticiCalisanTx.getDigerSubeKod(), birSaticiCalisanTx.getDigerBankaKod(), oMap.getString("IL_KOD"), "3161/LOV_BANKA_SUBE", "SUBE_ADI"));
			oMap.put(tableName, row, "HESAP_A", birSaticiCalisanTx.getDigerHesapNo());
			oMap.put(tableName, row, "IBAN", birSaticiCalisanTx.getIban());
			oMap.put(tableName, row, "MUSTERI_HESAP_NO", birSaticiCalisanTx.getHesapNo());
			oMap.put(tableName, row, "DI_MUSTERI_HESAP_NO", LovHelper.diLov(birSaticiCalisanTx.getHesapNo(), birSaticiCalisanTx.getMusteriNo(), "3161/LOV_VDSZ_HESAP", "KISA_ISIM"));
			oMap.put(tableName, row, "YENI_MUSTERI_MI", false);
			oMap.put(tableName, row, "CIHAZ_KULLANICISI", birSaticiCalisanTx.getCihazKullanicisi());
			oMap.put(tableName, row, "BAYI_CIHAZ_KODU", birSaticiCalisanTx.getBayiCihazKodu());

			row++;
		}
	}

	@GraymoundService("BNSPR_TRN3161_GET_ONCEKI_TX_NO")
	public static GMMap getOncekiTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3161.onceki_txno_3161(?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("SATICI_KOD"));
			stmt.execute();

			oMap.put("OLD_TRX_NO", stmt.getBigDecimal(1));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3161_GET_MUSTERI_BAYI_BILGILERI")
	// [1]MUSTERI_NO IN NUMBER,
	// [2]VERGI_IL_KODU OUT VARCHAR2,
	// [3]VERGI_DAIRE_KODU OUT VARCHAR2,
	// [4]VERGI_NO OUT NUMBER,
	// [5]EMAIL OUT VARCHAR2,
	// [6]WEB_ADRES OUT VARCHAR2,
	// [7]TICARI_UNVAN OUT VARCHAR2,
	// [8]FIRMA_TIPI OUT VARCHAR2,
	// [9]KURULUS_TARIHI OUT DATE,
	// [10]ADRES_KOD OUT VARCHAR2,
	// [11]ISYERI_UNVANI OUT VARCHAR2,
	// [12]ADRES OUT VARCHAR2,
	// [13]SEMT OUT VARCHAR2,
	// [14]IL_KOD OUT VARCHAR2,
	// [15]ILCE_KOD OUT VARCHAR2,
	// [16]POSTA_KOD OUT VARCHAR2,
	// [17]ULKE_KOD OUT VARCHAR2,
	// [18]TEL_TIP OUT VARCHAR2,
	// [19]ALAN_KOD OUT VARCHAR2,
	// [20]TELEFON_NO OUT VARCHAR2,
	public static GMMap getMusteriBayiBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_musteri_bpm.musteri_bayi_bilgileri(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, GuimlUtil.getTableCellBigDecimal(iMap.get("MUSTERI_NO")));

			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.NUMERIC);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			stmt.registerOutParameter(9, Types.DATE);
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.registerOutParameter(11, Types.VARCHAR);
			stmt.registerOutParameter(12, Types.VARCHAR);
			stmt.registerOutParameter(13, Types.VARCHAR);
			stmt.registerOutParameter(14, Types.VARCHAR);
			stmt.registerOutParameter(15, Types.VARCHAR);
			stmt.registerOutParameter(16, Types.VARCHAR);
			stmt.registerOutParameter(17, Types.VARCHAR);
			stmt.registerOutParameter(18, Types.VARCHAR);
			stmt.registerOutParameter(19, Types.VARCHAR);
			stmt.registerOutParameter(20, Types.VARCHAR);
			stmt.registerOutParameter(21, Types.VARCHAR);

			stmt.execute();

			int i = 2;

			oMap.put("VERGI_IL_KODU", stmt.getString(i++));
			oMap.put("VERGI_DAIRE_KODU", stmt.getString(i++));
			oMap.put("VERGI_NO", stmt.getBigDecimal(i++));
			/*
			 * if(stmt.getBigDecimal(i) != null) oMap.put("VERGI_NO", stmt.getBigDecimal(i++).toString()); else{
			 * oMap.put("VERGI_NO", null); i++; }
			 */
			oMap.put("EMAIL", stmt.getString(i++));
			oMap.put("WEB_ADRES", stmt.getString(i++));
			oMap.put("TICARI_UNVAN", stmt.getString(i++));
			oMap.put("FIRMA_TIPI", stmt.getString(i++));
			oMap.put("KURULUS_TARIHI", stmt.getDate(i++));
			/*
			 * if(stmt.getDate(i) != null) oMap.put("KURULUS_TARIHI", stmt.getDate(i++).toString()); else{
			 * oMap.put("KURULUS_TARIHI", null); i++; }
			 */
			oMap.put("ADRES_KOD", stmt.getString(i++));
			oMap.put("ISYERI_UNVANI", stmt.getString(i++));
			oMap.put("ADRES", stmt.getString(i++));
			oMap.put("SEMT", stmt.getString(i++));
			oMap.put("IL_KOD", stmt.getString(i++));
			oMap.put("ILCE_KOD", stmt.getString(i++));
			oMap.put("POSTA_KOD", stmt.getString(i++));
			oMap.put("ULKE_KOD", stmt.getString(i++));
			oMap.put("TEL_TIP", stmt.getString(i++));
			oMap.put("ALAN_KOD", stmt.getString(i++));
			oMap.put("TELEFON_NO", stmt.getString(i++));
			oMap.put("MUSTERI_KONTAKT", stmt.getString(i++));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/*
	 * TCK_NO IN NUMBER
	 * 
	 * MUSTERI_NO OUT NUMBER VERGI_IL_KODU OUT VARCHAR2 VERGI_DAIRE_KODU OUT VARCHAR2 VERGI_NO OUT NUMBER EMAIL OUT
	 * VARCHAR2 WEB_ADRES OUT VARCHAR2 TICARI_UNVAN OUT VARCHAR2 FIRMA_TIPI OUT VARCHAR2 KURULUS_TARIHI OUT DATE,
	 * ADRES_KOD OUT VARCHAR2 ISYERI_UNVANI OUT VARCHAR2 ADRES OUT VARCHAR2 SEMT OUT VARCHAR2 IL_KOD OUT VARCHAR2
	 * ILCE_KOD OUT VARCHAR2 POSTA_KOD OUT VARCHAR2 ULKE_KOD OUT VARCHAR2 TEL_TIP OUT VARCHAR2 ALAN_KOD OUT VARCHAR2
	 * TELEFON_NO OUT VARCHAR2
	 */
	@GraymoundService("BNSPR_TCK_NO_GET_BAYI_BILGILERI")
	public static GMMap getTCKNoGetBayiBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_MUSTERI_BPM.musteri_bayi_bilgileri_tckno(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCK_NO"));

			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);

			stmt.execute();

			i = 2;
			oMap.put("MUSTERI_NO", stmt.getObject(i++));
			oMap.put("VERGI_IL_KODU", stmt.getObject(i++));
			oMap.put("VERGI_DAIRE_KODU", stmt.getObject(i++));
			oMap.put("VERGI_NO", stmt.getObject(i++));
			oMap.put("EMAIL", stmt.getObject(i++));
			oMap.put("WEB_ADRES", stmt.getObject(i++));
			oMap.put("TICARI_UNVAN", stmt.getObject(i++));
			oMap.put("FIRMA_TIPI", stmt.getObject(i++));
			oMap.put("KURULUS_TARIHI", stmt.getObject(i++));
			oMap.put("ADRES_KOD", stmt.getObject(i++));
			oMap.put("ISYERI_UNVANI", stmt.getObject(i++));
			oMap.put("ADRES", stmt.getObject(i++));
			oMap.put("SEMT", stmt.getObject(i++));
			oMap.put("IL_KOD", stmt.getObject(i++));
			oMap.put("ILCE_KOD", stmt.getObject(i++));
			oMap.put("POSTA_KOD", stmt.getObject(i++));
			oMap.put("ULKE_KOD", stmt.getObject(i++));
			oMap.put("TEL_TIP", stmt.getObject(i++));
			oMap.put("ALAN_KOD", stmt.getObject(i++));
			oMap.put("TELEFON_NO", stmt.getObject(i++));
			oMap.put("MUSTERI_KONTAKT", stmt.getObject(i++));
			
			/** Bayi kanal�ndan e�er ticari kampanya girildiyse ticari m��terinin bulunmas� i�in **/
			if(iMap.get("KAMP_URUN_ADI") != null){
				Session session = DAOSession.getSession("BNSPRDal");
				BirKampanya birKampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", iMap.getBigDecimal("KAMP_URUN_ADI"))).uniqueResult();
				String ticariKrediEh = "H";
				if (birKampanya != null) {
					ticariKrediEh = birKampanya.getTicariKrediEh();
				}
				// Kampanya Ticari Kredi Evet ise ticari musteri(4) yoksa olusturur
				// Kampanya Ticari Kredi Hayir ise bireysel musteri(1) yoksa olusturur
				List<GnlMusteri> list;
				if ("E".equals(ticariKrediEh)) {
					list = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TCK_NO")))
							.add(Restrictions.eq("musteriStat1", "4")).add(Restrictions.eq("durumKodu", "A")).list();
				}
				else {
					list = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TCK_NO")))
							.add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).list();
				}
				
				if (list != null && list.size() > 0) {
					oMap.put("MUSTERI_NO", list.get(0).getMusteriNo());
				}
			}
			
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	/*
	 * VERGI_NO IN NUMBER
	 * 
	 * MUSTERI_NO OUT NUMBER VERGI_IL_KODU OUT VARCHAR2 VERGI_DAIRE_KODU OUT VARCHAR2 EMAIL OUT VARCHAR2 WEB_ADRES OUT
	 * VARCHAR2 TICARI_UNVAN OUT VARCHAR2 FIRMA_TIPI OUT VARCHAR2 KURULUS_TARIHI OUT DATE, ADRES_KOD OUT VARCHAR2
	 * ISYERI_UNVANI OUT VARCHAR2 ADRES OUT VARCHAR2 SEMT OUT VARCHAR2 IL_KOD OUT VARCHAR2 ILCE_KOD OUT VARCHAR2
	 * POSTA_KOD OUT VARCHAR2 ULKE_KOD OUT VARCHAR2 TEL_TIP OUT VARCHAR2 ALAN_KOD OUT VARCHAR2 TELEFON_NO OUT VARCHAR2
	 */
	@GraymoundService("BNSPR_VERGI_NO_GET_BAYI_BILGILERI")
	public static GMMap getVergiNoGetBayiBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_MUSTERI_BPM.musteri_bayi_bilgileri_vergino(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VERGI_NO"));

			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);

			stmt.execute();

			i = 2;
			oMap.put("MUSTERI_NO", stmt.getObject(i++));
			oMap.put("VERGI_IL_KODU", stmt.getObject(i++));
			oMap.put("VERGI_DAIRE_KODU", stmt.getObject(i++));
			oMap.put("EMAIL", stmt.getObject(i++));
			oMap.put("WEB_ADRES", stmt.getObject(i++));
			oMap.put("TICARI_UNVAN", stmt.getObject(i++));
			oMap.put("FIRMA_TIPI", stmt.getObject(i++));
			oMap.put("KURULUS_TARIHI", stmt.getObject(i++));
			oMap.put("ADRES_KOD", stmt.getObject(i++));
			oMap.put("ISYERI_UNVANI", stmt.getObject(i++));
			oMap.put("ADRES", stmt.getObject(i++));
			oMap.put("SEMT", stmt.getObject(i++));
			oMap.put("IL_KOD", stmt.getObject(i++));
			oMap.put("ILCE_KOD", stmt.getObject(i++));
			oMap.put("POSTA_KOD", stmt.getObject(i++));
			oMap.put("ULKE_KOD", stmt.getObject(i++));
			oMap.put("TEL_TIP", stmt.getObject(i++));
			oMap.put("ALAN_KOD", stmt.getObject(i++));
			oMap.put("TELEFON_NO", stmt.getObject(i++));
			oMap.put("MUSTERI_KONTAKT", stmt.getObject(i++));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3161_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiTx birSaticiTx = (BirSaticiTx) session.createCriteria(BirSaticiTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();

			GMMap adcMap = new GMMap();
			if ("S".equals(birSaticiTx.getSaticiTipKod())) {
				adcMap.put("MUSTERI_NO", birSaticiTx.getSubeMusteriNo());
			}
			else {
				adcMap.put("MUSTERI_NO", birSaticiTx.getMusteriNo());
			}

			if (adcMap.get("MUSTERI_NO") != null) {
				GMMap roleMap = new GMMap();
				iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
				roleMap = getDlrRoleTreeByTrxNo(iMap);
				if (roleMap.getSize("ROLES") > 0) {
					Set<?> keySet = roleMap.getMap("ROLES", 0).keySet();
					for (int j = 0; j < roleMap.getSize("ROLES"); j++) {
						for (Object key : keySet) {
							String keyName = (String) key;
							Object keyValue = roleMap.get("ROLES", j, keyName);
							adcMap.put("ROLES", j, keyName, keyValue);
						}
					}
				}
				adcMap.putAll(GMServiceExecuter.call("BNSPR_TRN3161_CREATE_DLR_ADC_USER", adcMap));
				iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
				adcMap.put("TREE", roleMap.get("LIST"));
				GMServiceExecuter.execute("ADC_CORE_USER_ROLE_UPDATE", adcMap);

				List<?> list = session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("birSatici.kod", birSaticiTx.getKod())).list();
				GMMap oMap = new GMMap();
				String calisanKod = null;
				String calStatuKod = null;
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					BirSaticiCalisan birSaticiCalisan = (BirSaticiCalisan) iterator.next();
					calisanKod = birSaticiCalisan.getKod().toString();
					calStatuKod = birSaticiCalisan.getCalStatuKod();
					iMap.put("UID", calisanKod);
					oMap = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_DLR", iMap);
					if ("IPTAL".equals(birSaticiCalisan.getDurum())) {
						iMap.put("USER_STATUS", "Inactive");
					}
					else {
						if ("K".equals(calStatuKod)) {
							iMap.put("USER_STATUS", "Inactive");
						}
						else {
							iMap.put("USER_STATUS", "Active");
						}
					}
					if (oMap.getBoolean("LDAP_USER")) {
						GMServiceExecuter.execute("BNSPR_SYSTEM_LDAP_SET_USER_STATUS_DLR", iMap);
					}
				}

				@SuppressWarnings("unchecked")
				List<BirSaticiCalisanTx> calisanTxList = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
				if (calisanTxList != null) {
					for (BirSaticiCalisanTx birSaticiCalisanTx : calisanTxList) {
						GMMap serviceMap = new GMMap();
						try {
							serviceMap.put("USERNAME", birSaticiCalisanTx.getId().getKod());
							serviceMap.put("ROLE_CODE", birSaticiCalisanTx.getYetkiGirisKod());
							GMServiceExecuter.call("ADC_CORE_REMOTE_USER_ROLE_UPDATE", serviceMap);
						}
						catch (Exception e) {
							// Ilgili kullanicinin ADC_USER yok. Sonraki ile devam et
							System.out.println("Cannot update dealer employee user role " + serviceMap);
						}
					}
				}
			}

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_3161_GET_MERKEZ_BAYI_INFO")
	public static GMMap getMerkezBayiInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			BirSatici birSatici = (BirSatici) session.get(BirSatici.class, iMap.getBigDecimal("MERKEZ_BAYI_KOD"));

			oMap.put("MUSTERI_NO", birSatici.getMusteriNo());
			oMap.put("HESAP_NO", birSatici.getHesapNo());

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_3161_GET_ADC_DEALER_ROLE_LIST")
	public synchronized static GMMap getAdcUserRoleList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			if (DLR_CHANNEL_OID == null) {
				iMap.put("CHANNEL_CODE", "DLR");
				DLR_CHANNEL_OID = GMServiceExecuter.call("ADC_CORE_GET_CHANNEL_BY_CODE", iMap).getString("CHANNEL_OID");
			}

			GMMap adcMap = new GMMap();
			adcMap.put("CHANNEL_OID", DLR_CHANNEL_OID);

			if ("S".equals(iMap.getString("SATICI_TIP_KOD"))) {
				iMap.put("CUSTOMER_ID", iMap.getString("SUBE_MUSTERI_NO"));
			}
			else {
				iMap.put("CUSTOMER_ID", iMap.getString("MUSTERI_NO"));
			}

			iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3161_GET_DLR_ADC_USER", iMap));

			if (iMap.getString("USER_OID") != null) {
				adcMap.put("USER_OID", iMap.getString("USER_OID"));
			}
			else {
				adcMap.put("USER_OID", "");
			}

			iMap.put("KOD", "YETKI_SEVIYE_KOD");
			oMap.put("YETKI_SEVIYESI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			oMap.putAll(GMServiceExecuter.execute("ADC_CORE_USER_ROLE_LIST", adcMap));
			TristateTreeNode root = (TristateTreeNode) oMap.get("LIST");
			ArrayList<DefaultMutableTreeNode> deleteList = new ArrayList<DefaultMutableTreeNode>();

			for (@SuppressWarnings("unchecked")
			Enumeration<DefaultMutableTreeNode> traverse = root.breadthFirstEnumeration(); traverse.hasMoreElements();) {

				DefaultMutableTreeNode node = traverse.nextElement();

				String roleCode = ((GMMap) node.getUserObject()).getString("CODE");
				for (int j = 0; j < oMap.getSize("YETKI_SEVIYESI"); j++) {
					if ((oMap.getString("YETKI_SEVIYESI", j, "VALUE")).equals(roleCode)) {
						deleteList.add(node);
						break;
					}
				}
			}
			for (DefaultMutableTreeNode node : deleteList) {
				((DefaultMutableTreeNode) node.getParent()).remove(node);
			}

			oMap.put("LIST", root);
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3161_GET_BAYI_SORUMLU_KISI")
	public static GMMap getBayiSorumluKisi(GMMap iMap) {
		/*Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3161.bayi_sorumlu_personeller(?)}");

			stmt.registerOutParameter(1, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "BAYI_SORUMLU_KISI", rSet.getString(1), rSet.getString(2));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}*/
		GMMap oMap = new GMMap();
		try {
			String[] funcs = { "{call PKG_TRN3161.bayi_sorumlu_personeller(?)}", "{call PKG_TRN3161.bayi_ube_sorumlu_personeller(?)}" };
			String[] tables = { "BAYI_SORUMLU_KISI", "BAYI_UBE_SORUMLU" };
			Object[] inputValues = {};
			Object[] outputValues = { BnsprType.REFCURSOR, "RESULT" };
			for (int i = 0; i < funcs.length; i++) {
				GMMap tMap = (GMMap) DALUtil.callOracleProcedure(funcs[i], inputValues, outputValues);
				int size = tMap.getSize("RESULT");
				if (size > 0) {
					for (int j = 0; j < size; j++) {
						GuimlUtil.wrapMyCombo(oMap, tables[i], tMap.getString("RESULT", j, "PERSONEL_NUMARA"), tMap.getString("RESULT", j, "AD_SOYAD"));
					}
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3161_GET_DLR_ADC_USER")
	public static GMMap getDlrAdcUser(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			String customerId = iMap.getString("CUSTOMER_ID");
			if (customerId != null) {

				iMap.put("USERNAME", createDlrUsername(customerId));
				oMap.putAll(GMServiceExecuter.execute("ADC_CORE_USER_LIST", iMap));

				if (oMap.getSize("LIST") == 1) {
					oMap.put("USER_OID", oMap.getString("LIST", 0, "OID"));
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3161_CREATE_DLR_ADC_USER")
	public static GMMap createAdk(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			GMMap controlMap = new GMMap();
			String customerId = iMap.getString("MUSTERI_NO");
			controlMap.put("CUSTOMER_ID", customerId);
			controlMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3161_GET_DLR_ADC_USER", controlMap));

			if (controlMap.getString("USER_OID") == null) {
				iMap.put("USERNAME", createDlrUsername(customerId));
				iMap.put("MUSTERI_NO", customerId);
				iMap.put("CHANNELS", 0, "CODE", "DLR");
				iMap.put("CHANNEL_CODE", "DLR");
				GMMap createMap = GMServiceExecuter.call("ADK_CREATE_USER", iMap);
				oMap.put("USER_OID", createMap.getString("USER_OID"));
			}
			else {
				oMap.put("USER_OID", controlMap.getString("USER_OID"));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3161_GET_DLR_ROLE_TREE_BY_TRX_NO")
	public static GMMap getDlrRoleTreeByTrxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			List<BirSaticiYetkiTanimTx> yetkiList = session.createCriteria(BirSaticiYetkiTanimTx.class).add(Restrictions.eq("id.trxNo", iMap.getBigDecimal("TRX_NO"))).list();

			TristateTreeNode root = new TristateTreeNode(new GMMap());
			int i = 0;
			for (BirSaticiYetkiTanimTx yetki : yetkiList) {
				GMMap roleMap = new GMMap();
				roleMap.put("OID", yetki.getId().getRoleOid());
				roleMap.put("NAME", yetki.getRoleName());
				roleMap.put("SELECTED", GuimlUtil.convertToCheckBoxSelected(yetki.getSelected()));
				TristateTreeNode node = new TristateTreeNode(roleMap);
				oMap.put("ROLES", i++, roleMap);
				root.add(node);
			}

			oMap.put("LIST", root);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	// Same as CINT usernames
	private static String createDlrUsername(String customerId) {
		String username = null;
		if (customerId != null && !customerId.trim().isEmpty()) {
			StringBuilder sb = new StringBuilder();
			sb.append(customerId).append("@").append(customerId);
			username = sb.toString();
		}
		return username;
	}

	/*
	 * @GraymoundService("BNSPR_TRN3161_GET_CALISAN_STATU") public static GMMap getYetkiSeviyesi(GMMap iMap){ Connection
	 * conn = null; CallableStatement stmt = null; ResultSet rSet = null; GMMap oMap = new GMMap(); try{ conn =
	 * DALUtil.getGMConnection(); stmt =
	 * conn.prepareCall("{? = call Pkg_Trn3161.Get_Calisan_Statu(?) }"); int i = 0; stmt.registerOutParameter(++i, -10);
	 * stmt.setBigDecimal (++i, iMap.getBigDecimal("KOD")); stmt.execute();
	 * 
	 * rSet = (ResultSet)stmt.getObject(1); oMap = DALUtil.rSetMap(rSet);
	 * 
	 * return oMap;
	 * 
	 * }catch (Exception e){ throw ExceptionHandler.convertException(e); }finally{ GMServerDatasource.close(rSet);
	 * GMServerDatasource.close(stmt); GMServerDatasource.close(conn); } }
	 */

	@GraymoundService("BNSPR_TRN3161_GET_CALISAN_TANIMLI_MI")
	public static GMMap getCalisanTanimliMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3161.calisanStatu(?,?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("STATUS", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_3161_CHECK_CURRENT_LIST")
	public static GMMap checkCurrent(GMMap iMap) {
		for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
			if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO")) && iMap.getString("MUSTERI_NO").equals(iMap.getString("TABLE_DATA", i, "MUSTERI_NO"))) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Calisan tabloda mevcut");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			else if (StringUtils.isNotBlank(iMap.getString("TCKN")) && iMap.getString("TCKN").equals(iMap.getString("TABLE_DATA", i, "TCK_NO"))) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Calisan tabloda mevcut");
				// TODO : mesaj olarak eklenecek
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		}
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3161_GET_KISA_ISIM")
	public static GMMap getKisaIsim(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_HESAP.kisa_isim(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("HESAP_NO"));
			stmt.execute();
			String kisaIsim = (String) stmt.getObject(1);
			oMap.put("KISA_ISIM", kisaIsim);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/** TY-6208 TY-3161-Bayi Tan�mlama Ekran �yile�tirmeleri */
	@GraymoundService("BNSPR_TRN3161_PORTFOY_KOD_KONTROLU")
	public static GMMap portfoyKodKontrolu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call pkg_trn3161.portfoy_kod_kontrolu(?,?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));
			stmt.setString(3, iMap.getString("PORTFOY_KOD"));
			stmt.execute();

			oMap.put("MESSAGE", stmt.getString(1) == null ? "" : stmt.getString(1).trim());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return iMap;
	}
}
