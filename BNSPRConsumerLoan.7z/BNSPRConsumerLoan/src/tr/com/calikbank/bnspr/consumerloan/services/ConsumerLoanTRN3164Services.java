package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSaticiTesvikTanimTx;
import tr.com.calikbank.bnspr.dao.BirSaticiTesvikTanimTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3164Services {
	@GraymoundService("BNSPR_TRN3164_GET_BIR_SATICI_TESVIK_TANIM")
	public static GMMap getBirSaticiLimitList(GMMap iMap) {
		BigDecimal trxNo;
		try {
			Connection conn = null;
			CallableStatement stmt = null;
			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_trn3164.islem_kaydi_yarat(?)}");
				stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));
				stmt.registerOutParameter(1, Types.NUMERIC);
				
				stmt.execute();
				
				trxNo = stmt.getBigDecimal(1);
				
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}	
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirSaticiTesvikTanimTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();

			GMMap oMap = new GMMap();
			String tableName = "BIR_SATICI_TESVIK_TANIM";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirSaticiTesvikTanimTx birSaticiTesvikTanimTx= (BirSaticiTesvikTanimTx)iterator.next();
				
				oMap.put(tableName, row, "TRX_NO", birSaticiTesvikTanimTx.getId().getTxNo());
				oMap.put(tableName, row, "ID", birSaticiTesvikTanimTx.getId().getId());
				oMap.put(tableName, row, "SATICI_KOD", birSaticiTesvikTanimTx.getSaticiKod());
				oMap.put(tableName, row, "KRD_TUR_KOD", birSaticiTesvikTanimTx.getKrdTurKod());
				oMap.put(tableName, row, "KRD_TUR_ALT_KOD", birSaticiTesvikTanimTx.getKrdTurAltKod());
				oMap.put(tableName, row, "KRD_TUR_ALT_KOD2", birSaticiTesvikTanimTx.getKrdTurAltKod2());
				oMap.put(tableName, row, "TESVIK_KOD", birSaticiTesvikTanimTx.getTesvikKod());
				oMap.put(tableName, row, "BAYI_ORAN", birSaticiTesvikTanimTx.getBayiOran());
				oMap.put(tableName, row, "BAYI_TUT", birSaticiTesvikTanimTx.getBayiTut());
				oMap.put(tableName, row, "CAL_ORAN", birSaticiTesvikTanimTx.getCalOran());
				oMap.put(tableName, row, "CAL_TUT", birSaticiTesvikTanimTx.getCalTut());
				
				oMap.putAll(getAciklamalar(birSaticiTesvikTanimTx.getKrdTurKod(), birSaticiTesvikTanimTx.getKrdTurAltKod(), birSaticiTesvikTanimTx.getKrdTurAltKod2(), birSaticiTesvikTanimTx.getTesvikKod()));
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	public static GMMap getAciklamalar(BigDecimal krdTurKod,BigDecimal krdTurAltKod,BigDecimal krdTurAltKod2,BigDecimal tesvikKod){
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn
					.prepareCall("{call PKG_TRN3164.get_aciklamalar(?,?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			
			stmt.setBigDecimal(1, krdTurKod);
			stmt.setBigDecimal(2, krdTurAltKod);
			stmt.setBigDecimal(3, krdTurAltKod2);
			stmt.setBigDecimal(4, tesvikKod);
						
			stmt.execute();

			oMap.put("KRD_TUR_KOD_ACIKLAMA", stmt.getString(5));
			oMap.put("KRD_TUR_ALT_KOD_ACIKLAMA", stmt.getString(6));
			oMap.put("KRD_TUR_ALT_KOD2_ACIKLAMA", stmt.getString(7));
			oMap.put("TESVIK_KOD_ACIKLAMA", stmt.getString(8));
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3164_SAVE")
	public static Map<?, ?> saveTRN3151(GMMap iMap) {
		BigDecimal trxNo = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> saticiTahsisTesvikTanimList = (List<?>) iMap.get("BIR_SATICI_TESVIK_TANIM");
			String tableName = "BIR_SATICI_TESVIK_TANIM";
			
			Connection conn = null;
			CallableStatement stmt = null;
			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_trn3164.islem_kayit_temizle(?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal(tableName, 0, "TRX_NO"));
				
				stmt.execute();
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			
			for (int i = 0; i < saticiTahsisTesvikTanimList.size(); i++) {
				BirSaticiTesvikTanimTx birSaticiTesvikTanimTx = new BirSaticiTesvikTanimTx();
				BirSaticiTesvikTanimTxId birSaticiTesvikTanimTxId = new BirSaticiTesvikTanimTxId();
				
				birSaticiTesvikTanimTxId.setId(iMap.getBigDecimal(tableName, i, "ID"));
				birSaticiTesvikTanimTxId.setTxNo(iMap.getBigDecimal(tableName, i, "TRX_NO"));
				trxNo = iMap.getBigDecimal(tableName, i, "TRX_NO");
				birSaticiTesvikTanimTx.setId(birSaticiTesvikTanimTxId);
				birSaticiTesvikTanimTx.setSaticiKod(iMap.getBigDecimal(tableName,i,"SATICI_KOD"));
				birSaticiTesvikTanimTx.setKrdTurKod(iMap.getBigDecimal(tableName,i,"KRD_TUR_KOD"));
				birSaticiTesvikTanimTx.setKrdTurAltKod(iMap.getBigDecimal(tableName,i,"KRD_TUR_ALT_KOD"));
				birSaticiTesvikTanimTx.setKrdTurAltKod2(iMap.getBigDecimal(tableName,i,"KRD_TUR_ALT_KOD2"));
				birSaticiTesvikTanimTx.setTesvikKod(iMap.getBigDecimal(tableName,i,"TESVIK_KOD"));
				birSaticiTesvikTanimTx.setBayiOran(iMap.getBigDecimal(tableName,i,"BAYI_ORAN"));
				birSaticiTesvikTanimTx.setBayiTut(iMap.getBigDecimal(tableName,i,"BAYI_TUT"));
				birSaticiTesvikTanimTx.setCalOran(iMap.getBigDecimal(tableName,i,"CAL_ORAN"));
				birSaticiTesvikTanimTx.setCalTut(iMap.getBigDecimal(tableName,i,"CAL_TUT"));
				
				session.save(birSaticiTesvikTanimTx);
			}
			
			session.flush();
			
			iMap.put("TRX_NO",trxNo);
			iMap.put("TRX_NAME", "3164");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
