package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiZiyaretTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3265Services {

    @GraymoundService("BNSPR_TRN3265_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap bilgiFillComboBoxInitialValues(GMMap iMap) {
        try {
            return DALUtil.fillComboBox(iMap, "IL_LIST", true, "select kod, il_adi from gnl_il_kod_pr order by il_adi");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    @GraymoundService("BNSPR_TRN3265_GET_GUNCELLEME_YETKI")
    public static GMMap getGuncellemeYetki(GMMap iMap) {
        GMMap oMap = new GMMap();
        Object[] inputValues;
        String func;
        try {

            func = "{? = call pkg_global.get_kullanicikod}";
            iMap.put("KULLANICI_KOD", DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[0]));

            inputValues = new Object[2];
            int i = 0;
            inputValues[i++] = BnsprType.STRING;
            inputValues[i++] = iMap.getString("KULLANICI_KOD");

            func = "{? = call pkg_trn3265.ziyaret_guncelleme_yetki(?)}";

            oMap.put("GUNCELLEME_YETKI", "E".equals(DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues)));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3265_GET_ZIYARET_DEGISTIRILEBILIR_MI")
    public static GMMap getZiyaretDegistirilebilirMi(GMMap iMap) {
        GMMap oMap = new GMMap();
        Object[] inputValues;
        String func;
        try {
            if (StringUtils.isNotBlank(iMap.getString("ISLEM_NO"))) {
                inputValues = new Object[2];
                int i = 0;
                inputValues[i++] = BnsprType.STRING;
                inputValues[i++] = iMap.getString("ISLEM_NO");

                func = "{? = call pkg_trn3265.ziyaret_guncellenebilir_eh (?)}";

                oMap.put("GUNCELLENEBILIR_MI", "E".equals(DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues)));

                func = "{? = call pkg_trn3265.ziyaret_silinebilir_eh (?)}";

                oMap.put("SILINEBILIR_MI", "E".equals(DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues)));
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3265_BAYI_ZIYARET_SORGULA")
    public static GMMap getZiyaretBilgileri(GMMap iMap) {
        GMMap oMap;
        Object[] inputValues;
        String func;
        int i = 0;
        try {
            func = "{? = call pkg_trn3265.bayi_ziyaret_sorgula(?,?,?)}";
            inputValues = new Object[12];

            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("SATICI_KOD");
            inputValues[i++] = BnsprType.DATE;
            inputValues[i++] = iMap.getDate("ZIYARET_BASTAR");
            inputValues[i++] = BnsprType.DATE;
            inputValues[i++] = iMap.getDate("ZIYARET_BITTAR");

            oMap = DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues);

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3265_BAYI_ZIYARET_DETAY")
    public static GMMap getZiyaretDetay(GMMap iMap) {
        GMMap oMap = new GMMap();
        Object[] inputValues;
        String func;
        int i = 0;
        try {
            func = "{? = call pkg_trn3265.ziyaret_bilgileri(?,?)}";
            inputValues = new Object[4];

            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("ISLEM_NO");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("TRX_NO");

            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
            oMap.put("MUSTERI_NO", oMap.getString("RESULTS", 0, "MUSTERI_NO"));
            oMap.put("DURUM", oMap.getString("RESULTS", 0, "DURUM"));
            oMap.put("KOD", oMap.getString("RESULTS", 0, "SATICI_KOD"));
            oMap.put("IL", oMap.getString("RESULTS", 0, "IL_KOD"));
            oMap.put("ZIYARET_SEBEP", oMap.getString("RESULTS", 0, "ZIYARET_SEBEP"));
            oMap.put("ZIYARETI_YAPAN", oMap.getString("RESULTS", 0, "ZIYARETI_YAPAN"));
            oMap.put("ZIYARET_TARIH_PLAN", oMap.getDate("RESULTS", 0, "ZIYARET_TARIH_PLAN"));
            oMap.put("ZIYARET_TARIH_GERCEK", oMap.getDate("RESULTS", 0, "ZIYARET_TARIH_GERCEK"));
            oMap.put("KIMLIK_KONTROL_E", "E".equals(oMap.getString("RESULTS", 0, "KIMLIK_KONTROL_EH")));
            oMap.put("KIMLIK_KONTROL_H", "H".equals(oMap.getString("RESULTS", 0, "KIMLIK_KONTROL_EH")));
            oMap.put("FARKLI_TUTAR_E", "E".equals(oMap.getString("RESULTS", 0, "FARKLI_TUTAR_EH")));
            oMap.put("FARKLI_TUTAR_H", "H".equals(oMap.getString("RESULTS", 0, "FARKLI_TUTAR_EH")));
            oMap.put("ILK_TERCIH_E", "E".equals(oMap.getString("RESULTS", 0, "ILK_TERCIH_EH")));
            oMap.put("ILK_TERCIH_H", "H".equals(oMap.getString("RESULTS", 0, "ILK_TERCIH_EH")));
            oMap.put("BILGI_SAHIBI_E", "E".equals(oMap.getString("RESULTS", 0, "BILGI_SAHIBI_EH")));
            oMap.put("BILGI_SAHIBI_H", "H".equals(oMap.getString("RESULTS", 0, "BILGI_SAHIBI_EH")));
            oMap.put("MUSTERI_BILGILENDIRME_E", "E".equals(oMap.getString("RESULTS", 0, "MUSTERI_BILGILENDIRME_EH")));
            oMap.put("MUSTERI_BILGILENDIRME_H", "H".equals(oMap.getString("RESULTS", 0, "MUSTERI_BILGILENDIRME_EH")));
            oMap.put("GORUS", oMap.getString("RESULTS", 0, "GORUS"));
            oMap.put("ISLEM_NO", oMap.getBigDecimal("RESULTS", 0, "ISLEM_NO"));
            oMap.put("REC_DATE", oMap.getDate("RESULTS", 0, "REC_DATE"));
            oMap.put("REC_OWNER", oMap.getString("RESULTS", 0, "REC_OWNER"));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3265_SAVE")
    public static GMMap save3265(GMMap iMap) {
        try {
            Session session = DAOSession.getSession("BNSPRDal");

            BirSaticiZiyaretTx birSaticiZiyaretTx = (BirSaticiZiyaretTx) session.createCriteria(BirSaticiZiyaretTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

            if (birSaticiZiyaretTx == null) {
                birSaticiZiyaretTx = new BirSaticiZiyaretTx();
            }
            
            if("false".equals(iMap.getString("BILGI_SAHIBI_E")) && "false".equals(iMap.getString("BILGI_SAHIBI_H")))
                birSaticiZiyaretTx.setBilgiSahibiEh(null);
            else
            birSaticiZiyaretTx.setBilgiSahibiEh(iMap.getBoolean("BILGI_SAHIBI_E") ? "E" : "H");
            
            if("false".equals(iMap.getString("FARKLI_TUTAR_E")) && "false".equals(iMap.getString("FARKLI_TUTAR_H")))
                birSaticiZiyaretTx.setFarkliTutarEh(null);
            else
            birSaticiZiyaretTx.setFarkliTutarEh(iMap.getBoolean("FARKLI_TUTAR_E") ? "E" : "H");
            
            if("false".equals(iMap.getString("ILK_TERCIH_E")) && "false".equals(iMap.getString("ILK_TERCIH_H")))
                birSaticiZiyaretTx.setIlkTercihEh(null);
            else
            birSaticiZiyaretTx.setIlkTercihEh(iMap.getBoolean("ILK_TERCIH_E") ? "E" : "H");
            
            if("false".equals(iMap.getString("KIMLIK_KONTROL_E")) && "false".equals(iMap.getString("KIMLIK_KONTROL_H")))
                birSaticiZiyaretTx.setKimlikKontrolEh(null);
            else
            birSaticiZiyaretTx.setKimlikKontrolEh(iMap.getBoolean("KIMLIK_KONTROL_E") ? "E" : "H");
            
            if("false".equals(iMap.getString("MUSTERI_BILGILENDIRME_E")) && "false".equals(iMap.getString("MUSTERI_BILGILENDIRME_H")))
                birSaticiZiyaretTx.setMusteriBilgilendirmeEh(null);
            else
            birSaticiZiyaretTx.setMusteriBilgilendirmeEh(iMap.getBoolean("MUSTERI_BILGILENDIRME_E") ? "E" : "H");
            
            if(StringUtils.isBlank(iMap.getString("DURUM"))){
                iMap.put("MESSAGE_NO", new java.math.BigDecimal(985));
                String message = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
                throw new GMRuntimeException(0, message);
            }else{
                birSaticiZiyaretTx.setDurum(iMap.getString("DURUM"));
            }
            
            birSaticiZiyaretTx.setGorus(iMap.getString("GORUS"));
            birSaticiZiyaretTx.setIlKod(iMap.getString("IL_KOD"));
            birSaticiZiyaretTx.setIslemNo(iMap.getBigDecimal("ISLEM_NO"));
            birSaticiZiyaretTx.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
            birSaticiZiyaretTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            birSaticiZiyaretTx.setZiyaretiYapan(iMap.getString("ZIYARETI_YAPAN"));
            birSaticiZiyaretTx.setZiyaretSebep(iMap.getString("ZIYARET_SEBEP"));
            birSaticiZiyaretTx.setZiyaretTarihGercek(iMap.getDate("ZIYARET_TARIH_GERCEK"));
            birSaticiZiyaretTx.setZiyaretTarihPlan(iMap.getDate("ZIYARET_TARIH_PLAN"));

            session.save(birSaticiZiyaretTx);
            session.flush();

            iMap.put("TRX_NAME", "3265");
            return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3265_GET_INFO")
    public static GMMap trn3265GetInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap i2Map = new GMMap();
        GMMap oldMap = new GMMap();
        Object[] inputValues;
        BigDecimal islemNo;
        int i;
        try {
            Session session = DAOSession.getSession("BNSPRDal");

            BirSaticiZiyaretTx birSaticiSicilTx = (BirSaticiZiyaretTx) session.createCriteria(BirSaticiZiyaretTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

            islemNo = birSaticiSicilTx.getIslemNo();

            i2Map.put("TRX_NO", iMap.get("TRX_NO"));
            i2Map.put("ISLEM_NO", islemNo);
            oldMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRN3265_GET_ONCEKI_TX_NO", i2Map).getBigDecimal("OLD_TRX_NO"));

            i = 0;
            inputValues = new Object[4];
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = null;
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("TRX_NO");

            setSicilDetayMap(oMap, inputValues);

            inputValues[--i] = oldMap.getBigDecimal("TRX_NO");

            setSicilDetayMap(oldMap, inputValues);
            oMap.putAll(BeanSetProperties.mapDifference(oldMap, oMap));

            oMap.putAll(iMap);

            return oMap;

        } catch (Exception e) {
            throw new GMRuntimeException(0, e);
        }
    }

    public static void setSicilDetayMap(GMMap oMap, Object[] inputValues) throws SQLException, ParseException {

        String func = "{? = call pkg_trn3265.ziyaret_bilgileri(?,?)}";
        oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
        oMap.put("DURUM", oMap.getString("RESULTS", 0, "DURUM"));
        oMap.put("MUSTERI_BILGILENDIRME_E", "E".equals(oMap.getString("RESULTS", 0, "MUSTERI_BILGILENDIRME_EH")));
        oMap.put("MUSTERI_BILGILENDIRME_H", "H".equals(oMap.getString("RESULTS", 0, "MUSTERI_BILGILENDIRME_EH")));
        oMap.put("ISLEM_NO", oMap.getString("RESULTS", 0, "ISLEM_NO"));
        oMap.put("ZIYARETI_YAPAN", oMap.getString("RESULTS", 0, "ZIYARETI_YAPAN"));
        oMap.put("BILGI_SAHIBI_E", "E".equals(oMap.getString("RESULTS", 0, "BILGI_SAHIBI_EH")));
        oMap.put("BILGI_SAHIBI_H", "H".equals(oMap.getString("RESULTS", 0, "BILGI_SAHIBI_EH")));
        oMap.put("ZIYARET_TARIH_GERCEK", oMap.getDate("RESULTS", 0, "ZIYARET_TARIH_GERCEK"));
        oMap.put("TX_NO", oMap.getString("RESULTS", 0, "TX_NO"));
        oMap.put("REC_DATE", oMap.getDate("RESULTS", 0, "REC_DATE"));
        oMap.put("GORUS", oMap.getString("RESULTS", 0, "GORUS"));
        oMap.put("ZIYARET_TARIH_PLAN", oMap.getDate("RESULTS", 0, "ZIYARET_TARIH_PLAN"));
        oMap.put("SATICI_KOD", oMap.getString("RESULTS", 0, "SATICI_KOD"));
        oMap.put("MUSTERI_NO", oMap.getString("RESULTS", 0, "MUSTERI_NO"));
        oMap.put("KIMLIK_KONTROL_E", "E".equals(oMap.getString("RESULTS", 0, "KIMLIK_KONTROL_EH")));
        oMap.put("KIMLIK_KONTROL_H", "H".equals(oMap.getString("RESULTS", 0, "KIMLIK_KONTROL_EH")));
        oMap.put("FARKLI_TUTAR_E", "E".equals(oMap.getString("RESULTS", 0, "FARKLI_TUTAR_EH")));
        oMap.put("FARKLI_TUTAR_H", "H".equals(oMap.getString("RESULTS", 0, "FARKLI_TUTAR_EH")));
        oMap.put("REC_OWNER", oMap.getString("RESULTS", 0, "REC_OWNER"));
        oMap.put("ILK_TERCIH_E", "E".equals(oMap.getString("RESULTS", 0, "ILK_TERCIH_EH")));
        oMap.put("ILK_TERCIH_H", "H".equals(oMap.getString("RESULTS", 0, "ILK_TERCIH_EH")));
        oMap.put("ZIYARET_SEBEP", oMap.getString("RESULTS", 0, "ZIYARET_SEBEP"));
        oMap.put("IL_KOD", oMap.getString("RESULTS", 0, "IL_KOD"));
        oMap.put("DURUM", oMap.getString("RESULTS", 0, "DURUM"));
    }

    @GraymoundService("BNSPR_TRN3265_GET_ONCEKI_TX_NO")
    public static GMMap getOldTxNo(GMMap iMap) {
        GMMap oMap = new GMMap();
        Object[] inputValues;
        String func;
        int i = 0;
        try {
            func = "{?=call pkg_trn3265.onceki_txno(?,?)}";
            inputValues = new Object[4];

            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("TRX_NO");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("ISLEM_NO");

            oMap.put("OLD_TRX_NO", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }
    @GraymoundService("BNSPR_TRN3265_GET_MUSTERI_NO")
    public static GMMap getMusteriNo(GMMap iMap) {
        GMMap oMap = new GMMap();
        Object[] inputValues;
        String func;
        int i = 0;
        try {
            func = "{?=call pkg_trn3265.satici_musteri_no(?)}";
            inputValues = new Object[4];

            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("SATICI_NO");

            oMap.put("MUSTERI_NO", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3265_GET_ZIYARET_ISLEM_NO")
    public static GMMap getSicilIslemNo(GMMap iMap) {
        GMMap oMap = new GMMap();
        String func;
        try {
            func = "{?=call pkg_trn3265.ziyaret_islem_no_al}";
            oMap.put("ISLEM_NO", DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[0]));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }
}
