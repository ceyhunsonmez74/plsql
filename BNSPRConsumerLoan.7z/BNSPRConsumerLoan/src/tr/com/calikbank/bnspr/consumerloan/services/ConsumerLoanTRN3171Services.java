package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAdkBasvuru;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKimlikDigerTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKimlikDigerTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruMalTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruMalTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruPaket;
import tr.com.aktifbank.bnspr.dao.BirBasvuruPaketTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSigortaSatisTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSigortaSatisTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTarimTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTasitTx;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlMusteriApsTx;
import tr.com.aktifbank.bnspr.dao.KmhBireyselBasvuruTx;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.consumerloan.utils.CreditTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.core.transaction.services.BnsprTxPersister;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorusTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorusTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruKefilTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruKefilTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminatTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminatTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTxLog;
import tr.com.calikbank.bnspr.dao.BirBasvuruTxLogId;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.dao.GnlMusteriTelefon;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.PaygateConstants;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.webservices.kps.KPSUtil;
import tr.com.obss.adc.core.util.ADCSession;
import tr.com.paygate.ArrayOfInstanceGroup;
import tr.com.paygate.ArrayOfSearchFilter;
import tr.com.paygate.ArrayOfSearchRequest;
import tr.com.paygate.DetailLevel;
import tr.com.paygate.FilterName;
import tr.com.paygate.InstanceGroup;
import tr.com.paygate.SearchFilter;
import tr.com.paygate.SearchRequest;
import tr.com.paygate.SearchType;
import tr.gov.nvi.kpsv2.model.KisiAdresBilgileriModel;
import tr.gov.nvi.kpsv2.model.TarihModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.BilesikKutukModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCCuzdanBilgisiModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCKKModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCKisiBilgisiModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.YabanciKisiBilgisiModel;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3171Services {

	public static final String veliVasiTurEs = "31";
	public static final String veliUyruk = "TR";

	@GraymoundService("BNSPR_TRN3171_GET_CINSIYET_TURLERI")
	public static GMMap getCinsiyetTurleri(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "CINSIYET_LIST", false, "select kod, aciklama from v_ml_gnl_cinsiyet_kod_pr order by 1");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_PTT_MAAS_ALINAN_KURUMLAR")
	public static GMMap pttInitialize(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "PTT_MAAS_ALINAN_KURUM_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'PTT_KREDI_MAAS_ALINAN_KURUM' order by text");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3171_GET_PTT_KURYE_SECIMI")
	public static GMMap pttKuryeSecimi(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "PTT_KURYE_SECIM_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'PTT_KURYE_SECIMI' order by text");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_MEDENI_HAL_TURLERI")
	public static GMMap getMedeniHalTurleri(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "MEDENI_HAL_LIST", false, "select kod, aciklama from v_ml_gnl_medeni_hal_kod_pr order by 1");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KREDI_TURLERI")
	public static GMMap getKrediTurleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3171.get_kredi_turleri(?,?,?) }");
			stmt.setString(1, iMap.getString("KANAL_KODU"));
			stmt.setString(2, iMap.getString("KANAL_ALT_KODU"));
			stmt.registerOutParameter(3, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(3);

			return DALUtil.fillComboBox(iMap, "KREDI_TUR_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KAMPANYA_LISTESI")
	public static GMMap getKampanyalar(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		BirAdkBasvuru adk = (BirAdkBasvuru) session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
		BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
		String tableName = "SEGMENT_TABLE";
		GMMap sMap = DALUtil.getResults("select s.normal_kredi_limit,s.mini_kredi_limit,s.upsell_kredi_limit, s.dusuk_faiz_kredi_limit, s.konsolidasyon_kredi_limit,s.spot_kredi_limit,s.ononay_kredi_limit,nvl(s.musteri_segment,'X') segment,nvl(s.musteri_segment_alt_kod,'X') segment_alt_kod from bnspr.bir_nbsm_sonuc s where s.basvuru_no = " + iMap.getBigDecimal("BASVURU_NO") + " and s.nbsm_call_id = (select max(s2.nbsm_call_id) from bir_nbsm_sonuc s2 where s2.basvuru_no = s.basvuru_no)", tableName);

		String segment = null;
		String segmentAltKod = null;

		BigDecimal normalKrediLimit = null;
		BigDecimal miniKrediLimit = null;
		BigDecimal upsellKrediLimit = null;
		BigDecimal dusukFaizKrediLimit = null;
		BigDecimal konsolidasyonKrediLimit = null;
		BigDecimal spotKrediLimit = null;
		BigDecimal ononayKrediLimit = null;

		if (sMap != null && sMap.getSize(tableName) > 0) {

			segment = sMap.getString(tableName, 0, "SEGMENT");
			segmentAltKod = sMap.getString(tableName, 0, "SEGMENT_ALT_KOD");
			dusukFaizKrediLimit = sMap.getBigDecimal(tableName, 0, "DUSUK_FAIZ_KREDI_LIMIT");
			konsolidasyonKrediLimit = sMap.getBigDecimal(tableName, 0, "KONSOLIDASYON_KREDI_LIMIT");
			miniKrediLimit = sMap.getBigDecimal(tableName, 0, "MINI_KREDI_LIMIT");
			normalKrediLimit = sMap.getBigDecimal(tableName, 0, "NORMAL_KREDI_LIMIT");
			ononayKrediLimit = sMap.getBigDecimal(tableName, 0, "ONONAY_KREDI_LIMIT");
			spotKrediLimit = sMap.getBigDecimal(tableName, 0, "SPOT_KREDI_LIMIT");
			upsellKrediLimit = sMap.getBigDecimal(tableName, 0, "UPSELL_KREDI_LIMIT");

		}

		sMap.put("KANAL_KODU", iMap.getString("KANAL_KODU"));
		sMap.put("VADE", birBasvuru != null ? birBasvuru.getVade() : adk.getVade());
		sMap.put("TUTAR", birBasvuru != null ? birBasvuru.getTutar() : adk.getTutar());
		sMap.put("KANAL_KOD", iMap.getString("KANAL_KODU"));
		sMap.put("DOVIZ_KODU", "TRY");
		sMap.put("KREDI_TURU", birBasvuru != null ? birBasvuru.getKrediTur() : adk.getKrediTurKod());
		sMap.put("MUSTERI_SEGMENT", segment);
		sMap.put("SEGMENT_ALT_KOD", segmentAltKod);
		sMap.put("DUSUK_FAIZ_KREDI_LIMIT", dusukFaizKrediLimit);
		sMap.put("KONSOLIDASYON_KREDI_LIMIT", konsolidasyonKrediLimit);
		sMap.put("MINI_KREDI_LIMIT", miniKrediLimit);
		sMap.put("NORMAL_KREDI_LIMIT", normalKrediLimit);
		sMap.put("ONONAY_KREDI_LIMIT", ononayKrediLimit);
		sMap.put("SPOT_KREDI_LIMIT", spotKrediLimit);
		sMap.put("UPSELL_KREDI_LIMIT", upsellKrediLimit);

		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3113_KAMPANYA_BUL", sMap));

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_GET_ODEME_TIP")
	public static GMMap getOdemeTip(GMMap iMap) {
		GMMap oMap = new GMMap();

		BigDecimal kampKod = iMap.getBigDecimal("KAMP_KOD");

		if (kampKod != null) {

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMPANYA_LISTESI", iMap));
			int size = oMap.getSize("KAMPANYA_LISTE");

			for (int row = 0; row < size; row++) {

				if (kampKod.compareTo(oMap.getBigDecimal("KAMPANYA_LISTE", row, "KAMP_KOD")) == 0) {
					oMap.put("ODEME_TIP_KOD", oMap.getBigDecimal("KAMPANYA_LISTE", row, "ODEME_TIP_KOD"));
					oMap.put("ODEME_TIP_VADE", oMap.getBigDecimal("KAMPANYA_LISTE", row, "ODEMESIZ_SURE"));
					break;
				}

			}
		}
		return oMap;
	}

	@SuppressWarnings("rawtypes")
	@GraymoundService("BNSPR_TRN3171_GET_SEGMENT_KAMPANYA_LISTESI")
	public static GMMap getSegmentKampanyaListesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMPANYA_LISTESI", iMap));

		int size = oMap.getSize("KAMPANYA_LISTE");

		List<BigDecimal> kampKodlari = new ArrayList<BigDecimal>();

		for (int row = 0; row < size; row++) {

			BirKampanya kampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", oMap.getBigDecimal("KAMPANYA_LISTE", row, "KAMP_KOD"))).uniqueResult();

			if (kampKodlari.contains(kampanya.getKod())) {
				continue;
			}
			else {
				kampKodlari.add(kampanya.getKod());
			}

			GuimlUtil.wrapMyCombo(oMap, "URUN_KAMP_TUR_LIST", kampanya.getKod().toString(), kampanya.getAciklama());
		}

		return oMap;
	}

	@SuppressWarnings("rawtypes")
	@GraymoundService("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI")
	public static GMMap getUrunKampanyaTurleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3171.get_urun_kampanya_turleri(?,?,?,?,?,?,?,?) }");

			stmt.setString(1, iMap.getString("KRD_TUR_KOD"));
			stmt.setString(2, iMap.getString("KANAL_KODU"));
			stmt.setString(3, iMap.getString("DOVIZ_KODU"));
			if (iMap.containsKey("IZLE"))
				stmt.setBigDecimal(4, new BigDecimal(1));
			else
				stmt.setBigDecimal(4, new BigDecimal(0));

			if (iMap.getBoolean("IZLE"))
				stmt.setBigDecimal(5, new BigDecimal(1));
			else
				stmt.setBigDecimal(5, new BigDecimal(0));

			if (!(iMap.containsKey("IZLE") && iMap.getBoolean("IZLE")))
				stmt.setString(6, iMap.getString("KANAL_ALT_KODU"));
			else
				stmt.setString(6, null);

			stmt.registerOutParameter(7, -10);

			/** TY-6229 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			stmt.setString(8, iMap.getString("ARAC_TIPI"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(7);

			DALUtil.fillComboBox(oMap, "URUN_KAMP_TUR_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
			if (oMap.containsKey("URUN_KAMP_TUR_LIST") && ((ArrayList) oMap.get("URUN_KAMP_TUR_LIST")).size() == 2)
				oMap.put("DEFAULT_URUN_KAMP", oMap.getString("URUN_KAMP_TUR_LIST", 1, "VALUE"));
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * BNSPR_TRN3171_GET_KREDI_TURLERI key-value seklinde iki alani map ledigi icin,
	 * sorgu sonucu gelen alanlarin tamamini kullanmak icin eklendi.
	 * 
	 */
	@GraymoundService("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI_DETAY")
	public static GMMap getUrunKampanyaTurleriDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3171.get_urun_kampanya_turleri(?,?,?,?,?,?,?) }");
			stmt.setString(1, iMap.getString("KRD_TUR_KOD"));
			stmt.setString(2, iMap.getString("KANAL_KODU"));
			stmt.setString(3, iMap.getString("DOVIZ_KODU"));
			if (iMap.containsKey("IZLE"))
				stmt.setBigDecimal(4, new BigDecimal(1));
			else
				stmt.setBigDecimal(4, new BigDecimal(0));

			if (iMap.getBoolean("IZLE"))
				stmt.setBigDecimal(5, new BigDecimal(1));
			else
				stmt.setBigDecimal(5, new BigDecimal(0));

			if (!(iMap.containsKey("IZLE") && iMap.getBoolean("IZLE")))
				stmt.setString(6, iMap.getString("KANAL_ALT_KODU"));
			else
				stmt.setString(6, null);

			stmt.registerOutParameter(7, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(7);

			oMap = DALUtil.rSetResults(rSet, "URUN_KAMP_TUR_LIST");
			if (oMap.containsKey("URUN_KAMP_TUR_LIST")) {
				if (((ArrayList<?>) oMap.get("URUN_KAMP_TUR_LIST")).size() == 2) {
					oMap.put("DEFAULT_URUN_KAMP", oMap.getString("URUN_KAMP_TUR_LIST", 1, "VALUE"));
				}

				GMMap paramMap = new GMMap();
				paramMap.put("PARAMETRE", "NAKIT_KREDI_TUR_LIST");
				List<String> cashCreditList = Arrays.asList(GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", paramMap).getString("DEGER", "-1").split(","));

				String tip2 = StringUtils.EMPTY;
				String tasitSifirAltTurCodes = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap.put("KOD", "TASIT_KREDI_ALT_TUR_KOD2").put("KEY", Constants.TASIT_TURU_SIFIR)).getString("TEXT");
				String tasitIkinciElAltTurCodes = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap.put("KOD", "TASIT_KREDI_ALT_TUR_KOD2").put("KEY", Constants.TASIT_TURU_IKINCI_EL)).getString("TEXT");

				for (int i = 0; i < oMap.getSize("URUN_KAMP_TUR_LIST"); i++) {
					if (cashCreditList != null && cashCreditList.contains(oMap.getString("URUN_KAMP_TUR_LIST", i, "TUR"))) {
						paramMap.clear();
						paramMap.put("KOD", "NAKIT_KREDI_TUR_TIP");
						paramMap.put("KEY", oMap.getString("URUN_KAMP_TUR_LIST", i, "TUR"));
						List<String> cashCreditSubList = Arrays.asList(GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).getString("TEXT", "-1").split(","));

						if (cashCreditSubList != null && cashCreditList.contains(oMap.getString("URUN_KAMP_TUR_LIST", i, "TIP"))) {
							oMap.put("URUN_KAMP_TUR_LIST", i, "NAKIT_KREDI", "1");
						}
						else {
							oMap.put("URUN_KAMP_TUR_LIST", i, "NAKIT_KREDI", "0");
						}
					}
					else {
						oMap.put("URUN_KAMP_TUR_LIST", i, "NAKIT_KREDI", "0");
					}

					tip2 = oMap.getString("URUN_KAMP_TUR_LIST", i, "TIP2");
					oMap.put("URUN_KAMP_TUR_LIST", i, Constants.TASIT_TURU, StringUtils.EMPTY);
					if (StringUtils.isNotBlank(tip2)) {
						if (StringUtils.isNotBlank(tasitSifirAltTurCodes)) {
							if (tasitSifirAltTurCodes.contains(tip2)) {
								oMap.put("URUN_KAMP_TUR_LIST", i, Constants.TASIT_TURU, Constants.TASIT_TURU_SIFIR);
							}
						}
						if (StringUtils.isNotBlank(tasitIkinciElAltTurCodes)) {
							if (tasitIkinciElAltTurCodes.contains(tip2)) {
								oMap.put("URUN_KAMP_TUR_LIST", i, Constants.TASIT_TURU, Constants.TASIT_TURU_IKINCI_EL);
							}
						}
					}
					
					if(oMap.get("URUN_KAMP_TUR_LIST", i, "KOD") != null && !oMap.getString("URUN_KAMP_TUR_LIST", i, "KOD").contains("-")) {
						BirKampanya birKampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", oMap.getBigDecimal("URUN_KAMP_TUR_LIST", i, "KOD"))).uniqueResult();
						if (birKampanya.getEkPaketKod() != null) {
							GMMap pMap = ConsumerLoanCommonServices.getParamTextLists("BIR_BASVURU_PAKET_TANIM", "PARAM_TABLE");
							for (int j = 0; j < pMap.getSize("PARAM_TABLE"); j++) {
								if (birKampanya.getEkPaketKod().toString().equals(pMap.getString("PARAM_TABLE", j, "CODE"))) {
									oMap.put("URUN_KAMP_TUR_LIST", i, "KORUMA_KREDISI_TUTAR", pMap.getBigDecimal("PARAM_TABLE", j, "KEY2"));
									oMap.put("URUN_KAMP_TUR_LIST", i, "KORUMA_KREDISI_KOD", birKampanya.getEkPaketKod().toString());
								}
							}
						}
					}
					
				}
			}

			/** Bayi upsell kampanya kodu **/
			GMMap pMap = ConsumerLoanCommonServices.getParamTextLists("BAYI_UPSELL_PARAMETRE", "PARAM_TABLE");
			for (int i = 0; i < pMap.getSize("PARAM_TABLE"); i++) {
				if ("MAX_TUTAR".equals(pMap.getString("PARAM_TABLE", i, "CODE"))) {
					oMap.put("UPSELL_MAX_TUTAR", pMap.getString("PARAM_TABLE", i, "DESCRIPTION"));
				}
				else if ("KAMPANYA_KODU".equals(pMap.getString("PARAM_TABLE", i, "CODE"))) {
					oMap.put("UPSELL_KAMP_KOD", pMap.getString("PARAM_TABLE", i, "DESCRIPTION"));
				}
				else if ("MIN_TUTAR".equals(pMap.getString("PARAM_TABLE", i, "CODE"))) {
					oMap.put("UPSELL_MIN_TUTAR", pMap.getString("PARAM_TABLE", i, "DESCRIPTION"));
				}
			}
			
			/** Koruma kredisi max vade **/
			pMap.clear();
			pMap.put("PARAMETRE", "IR_EK_PAKET_MAX_VADE");
			oMap.put("KORUMA_KREDISI_MAX_VADE", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", pMap).getString("DEGER"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3187_GET_URUN_KAMPANYA_TURLERI")
	public static GMMap getUrunKampanyaTurleriKanalKodu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3187.get_urun_kampanya_turleri(?,?,?,?,?,?,?) }");

			stmt.setString(1, iMap.getString("KRD_TUR_KOD"));
			stmt.setString(2, iMap.getString("KANAL_KODU"));
			stmt.setString(3, iMap.getString("DOVIZ_KODU"));
			if (iMap.containsKey("IZLE"))
				stmt.setBigDecimal(4, new BigDecimal(1));
			else
				stmt.setBigDecimal(4, new BigDecimal(0));

			if (iMap.getBoolean("IZLE"))
				stmt.setBigDecimal(5, new BigDecimal(1));
			else
				stmt.setBigDecimal(5, new BigDecimal(0));

			if (!(iMap.containsKey("IZLE") && iMap.getBoolean("IZLE")))
				stmt.setString(6, iMap.getString("KANAL_ALT_KODU"));
			else
				stmt.setString(6, null);

			stmt.registerOutParameter(7, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(7);

			DALUtil.fillComboBox(oMap, "URUN_KAMP_TUR_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
			if (oMap.containsKey("URUN_KAMP_TUR_LIST") && ((ArrayList<?>) oMap.get("URUN_KAMP_TUR_LIST")).size() == 2) {
				oMap.put("DEFAULT_URUN_KAMP", oMap.getString("URUN_KAMP_TUR_LIST", 1, "VALUE"));
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_DOVIZ_CINSLERI")
	public static GMMap getDovizCinsleri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3171.get_doviz_cinsleri(?,?,?) }");

			stmt.setString(1, iMap.getString("KRD_TUR_KOD"));
			stmt.setString(2, iMap.getString("KANAL_KODU"));
			stmt.registerOutParameter(3, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(3);

			DALUtil.fillComboBox(oMap, "DOVIZ_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_GARANTOR_MU")
	public static GMMap getGarantorMu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_basvuru.checkGarantor(?, ?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KODU"));
			stmt.setString(3, iMap.getString("DOVIZ_KODU"));
			stmt.execute();
			oMap.put("GARANTOR_MU", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_GECERLI_TEMINATLAR")
	public static GMMap getGecerliTeminatlar(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			if (iMap.getString("KAMP_URUN_ADI") == null) {
				oMap.put("TEMINAT_VAR_MI", false);
				return oMap;
			}

			String urunKampKod = iMap.getString("KAMP_URUN_ADI");
			BigDecimal urun_kamp_kod = new BigDecimal(urunKampKod.indexOf('-')); // <0 ilk blok degilse diger blok

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3171.Get_Gecerli_Teminat_List(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 0;

			stmt.registerOutParameter(++i, -10);

			stmt.setString(++i, iMap.getString("KAMP_URUN_ADI"));
			stmt.setString(++i, iMap.getString("DOVIZ_KOD"));
			stmt.setString(++i, iMap.getString("KANAL_KODU"));
			stmt.setBigDecimal(++i, iMap.getBigDecimal("VADE"));
			stmt.setBigDecimal(++i, iMap.getBigDecimal("TUTAR"));
			stmt.setString(++i, iMap.getString("BASVURU_NO"));
			stmt.setString(++i, iMap.getString("KRD_TUR_KOD"));
			stmt.setString(++i, iMap.getString("KRD_TUR_ALT_KOD"));
			stmt.setString(++i, iMap.getString("KRD_TUR_ALT_KOD2"));
			stmt.setString(++i, iMap.getString("DOVIZ_KOD"));
			stmt.setString(++i, iMap.getString("KANAL_KODU"));
			stmt.setString(++i, iMap.getString("BASVURU_NO"));
			stmt.setBigDecimal(++i, urun_kamp_kod);

			if (iMap.getBigDecimal("SATICI_KOD") != null) {
				stmt.setBigDecimal(++i, iMap.getBigDecimal("SATICI_KOD"));
			}
			else {
				stmt.setBigDecimal(++i, null);
			}
			stmt.execute();
			// stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			String listName = "TEMINATLAR";

			DALUtil.fillComboBox(oMap, listName, iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
			oMap.put("TEMINAT_VAR_MI", oMap.getSize(listName) > (iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E") ? 1 : 0));

			return oMap; // combobox dolacak

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_GECERLI_SIGORTA_URUNLERI")
	public static GMMap getGecerliSigortaUrunleri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3171.Get_Gecerli_Sigorta_Urunleri(?)}");

			stmt.registerOutParameter(1, -10);

			stmt.setBigDecimal(2, iMap.getBigDecimal("KAMP_KNL_KOD"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			String listName = "SIGORTALAR";

			GMMap sMap = new GMMap();
			GMMap tMap = new GMMap();
			tMap.putAll(DALUtil.rSetResults(rSet, listName + "_LIST"));
			oMap.putAll(tMap);

			int i = 0;
			while (i < tMap.getSize(listName + "_LIST")) {
				if (i == 0) {
					oMap.put("INIT_VALUE", oMap.getString(listName + "_LIST", i, "SIGORTA_URUN_NO"));
				}
				oMap.put(listName, i, "VALUE", oMap.getString(listName + "_LIST", i, "SIGORTA_URUN_NO"));
				oMap.put(listName, i, "NAME", oMap.getString(listName + "_LIST", i, "KANALDAKI_ADI"));

				sMap.put("URUN_ID", oMap.getString(listName + "_LIST", i, "SIGORTA_URUN_NO"));
				oMap.put(listName, i, "PRIM", GMServiceExecuter.call("BNSPR_INSURANCE_GET_PRODUCT_INFO", sMap).get("PIRIM_TUTARI"));

				i++;
			}
			return oMap; // combobox dolacak

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_SIGORTA_URUNLERI")
	public static GMMap getSigortaUrunleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3171.Get_Sigorta_Urunleri(?,?)}");

			stmt.registerOutParameter(1, -10);

			stmt.setBigDecimal(2, iMap.getBigDecimal("KAMP_KNL_KOD"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "SIGORTA_LIST"));
			oMap.put("BAYI_KAZANCI_FLAG", false);
			oMap.put("BAYI_KAZANCI", BigDecimal.ZERO);
			if (oMap.containsKey("SIGORTA_LIST")) {
				if (oMap.getSize("SIGORTA_LIST") > 0) {
					oMap.put("BAYI_KAZANCI", oMap.getBigDecimal("SIGORTA_LIST", 0, "BAYI_KAZANCI"));
					if (oMap.getBigDecimal("BAYI_KAZANCI").compareTo(BigDecimal.ZERO) > 0)
						oMap.put("BAYI_KAZANCI_FLAG", true);
				}
			}
			return oMap; // tabloyu doldurur -- digeri combobox i dolduracak sanirim

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_TEMINATLAR")
	public static GMMap getTeminatlar(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			String urunKampKod = iMap.getString("KAMP_URUN_ADI");

			BigDecimal urun_kamp_kod = new BigDecimal(urunKampKod.indexOf('-')); // <0 ilk blok degilse diger blok

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3171.Get_Teminat_List(?,?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 0;

			stmt.registerOutParameter(++i, -10);

			stmt.setString(++i, iMap.getString("KAMP_URUN_ADI"));
			stmt.setString(++i, iMap.getString("DOVIZ_KOD"));
			stmt.setString(++i, iMap.getString("KANAL_KODU"));
			stmt.setBigDecimal(++i, iMap.getBigDecimal("VADE"));
			stmt.setBigDecimal(++i, iMap.getBigDecimal("TUTAR"));
			stmt.setString(++i, iMap.getString("KRD_TUR_KOD"));
			stmt.setString(++i, iMap.getString("KRD_TUR_ALT_KOD"));
			stmt.setString(++i, iMap.getString("KRD_TUR_ALT_KOD2"));
			stmt.setString(++i, iMap.getString("DOVIZ_KOD"));
			stmt.setString(++i, iMap.getString("KANAL_KODU"));
			stmt.setBigDecimal(++i, urun_kamp_kod);

			if (iMap.getBigDecimal("SATICI_KOD") != null) {
				stmt.setBigDecimal(++i, iMap.getBigDecimal("SATICI_KOD"));
			}
			else {
				stmt.setBigDecimal(++i, null);
			}

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "TEMINAT_LIST"); // tabloyu doldurur -- digeri combobox i dolduracak sanirim
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KEFIL_YAKINLIK")
	public static GMMap getKefilYakinlik(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			ArrayList<Object> queryParameters = new ArrayList<Object>();
			queryParameters.add(iMap.get("KRD_TUR_KOD"));
			queryParameters.add(iMap.get("KRD_TUR_KOD"));
			oMap.put("QUERY_PARAMETERS", queryParameters);
			return DALUtil.fillComboBox(oMap, "KEFIL_YAKINLIK_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'KEFIL_YAKINLIK_KOD' and nvl(key2, ?) = ? order by sira_no");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KEFIL_YAKINLIK_ALL")
	public static GMMap getKefilYakinlikAll(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			return DALUtil.fillComboBox(oMap, "KEFIL_YAKINLIK_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'KEFIL_YAKINLIK_KOD'");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_OGRENIM_DURUMLARI")
	public static GMMap getOgrenimDurumlari(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "OGRENIM_LIST", true, "select kod, aciklama from v_ml_gnl_egitim_kod_pr order by sira_no");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_CALISMA_SEKILLERI")
	public static GMMap getCalismaSekilleri(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "CALISMA_SEKLI_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' and (('" + iMap.getString("KANAL_KOD") + "' = '8' and key1 not in ('C', 'A', 'T')) or '" + iMap.getString("KANAL_KOD") + "' <> '8') order by sira_no");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_YAZISMA_TURLERI")
	public static GMMap getYazismaTurleri(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "YAZISMA_TURLERI_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'MUST_YAZISMA_ADRES_KOD' order by text");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_FAALIYET_ALANLARI")
	public static GMMap getFaaliyetAlanlari(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "FAALIYET_ALAN_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'ISYERI_FAAL_KONU_KOD' order by sira_no, text");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ISYERI_MULKIYET_TURLERI")
	public static GMMap getIsyeriMulkiyetTurleri(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "ISYERI_MULKIYET_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'ISYERI_MULKIYET_KOD' order by text");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ILLER")
	public static GMMap getIller(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "IL_LIST", true, "select kod, il_adi from gnl_il_kod_pr order by il_adi");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_DHF_ILLER")
	public static GMMap getDhfIller(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "DHF_IL_LIST", true, "select distinct t.il_kod, pkg_genel_pr.il_adi_hatasiz(t.il_kod) il_adi from gnl_ilce_kod_pr t where t.dhf_kod is not null order by il_adi");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ILCELER")
	public static GMMap getIlceler(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select ilce_kod, ilce_adi from gnl_ilce_kod_pr where il_kod = ? order by ilce_adi");
			stmt.setString(1, iMap.getString("IL_KODU"));
			rSet = stmt.executeQuery();

			DALUtil.fillComboBox(oMap, "ILCELER_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_DHF_ILCELER")
	public static GMMap getDhfIlceler(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select t.ilce_kod, t.ilce_adi from gnl_ilce_kod_pr t where t.dhf_kod is not null and t.il_kod = ? order by t.ilce_adi");
			stmt.setString(1, iMap.getString("IL_KODU"));
			rSet = stmt.executeQuery();

			DALUtil.fillComboBox(oMap, "DHF_ILCELER_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_VERGI_DAIRESI_ILLERI")
	public static GMMap getVergiDairesiIlleri(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "VERGI_DAIRESI_IL_LIST", true, "select distinct(il_kod) kod, pkg_genel_pr.il_adi(il_kod) il_adi from gnl_vergi_daire_kod_pr order by 2");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_VERGI_DAIRESI_ADLARI")
	public static GMMap getVergiDairesiAdlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select vergi_d_kod, vergi_d_adi from gnl_vergi_daire_kod_pr where il_kod = ? order by vergi_d_adi");
			stmt.setString(1, iMap.getString("VERGI_DAIRESI_IL"));
			rSet = stmt.executeQuery();

			DALUtil.fillComboBox(oMap, "VERGI_DAIRESI_AD_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_UNVAN_TURLERI")
	public static GMMap getUnvanTurleri(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select u.kod,u.ACIKLAMA from v_ml_gnl_unvan_kod_pr u,v_ml_gnl_meslek_kod_pr m where m.KOD= ? and substr(m.unvan_dizi,pkg_trn10011.unvan_indis_belirle(u.KOD),1)='1' ");
			stmt.setString(1, iMap.getString("MESLEK_KOD"));
			rSet = stmt.executeQuery();

			return DALUtil.fillComboBox(iMap, "UNVAN_TURLERI_LIST", true, rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_IKAMET_TURLERI")
	public static GMMap getIkametTurleri(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "IKAMET_TURLERI_LIST", true, "select key1, text from v_ml_gnl_param_text where kod = 'IKAMET_DURUM_KOD' order by sira_no");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_MESLEKLER")
	public static GMMap getMeslekler(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		CallableStatement stmt3 = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();

			String egitimKod = iMap.getString("EGITIM_KOD");
			String calismaSekliKod = iMap.getString("CALISMA_SEKLI");

			Calendar farkTar = GregorianCalendar.getInstance();
			farkTar.setTimeInMillis(iMap.getDate("BANKA_TARIHI").getTime() - iMap.getDate("DOGUM_TARIHI").getTime());
			int yas = farkTar.get(GregorianCalendar.YEAR) - 1970;

			stmt3 = conn.prepareCall("{? = call pkg_genel_pr.Yas_Araligi_Kodu_Bul(?)}");
			stmt3.registerOutParameter(1, Types.VARCHAR);
			stmt3.setBigDecimal(2, new BigDecimal(yas));
			stmt3.execute();
			StringBuffer yasDizi = new StringBuffer("_____");
			Integer index = new Integer(stmt3.getString(1));
			yasDizi = yasDizi.replace(index - 1, index, "1");

			StringBuffer egitimDizi = new StringBuffer();
			stmt = conn.prepareStatement("select sira_no from v_ml_gnl_egitim_kod_pr where kod = ? order by sira_no");
			stmt.setString(1, egitimKod);
			rSet = stmt.executeQuery();

			while (rSet.next()) {
				Integer firstIndex = new Integer(rSet.getString("SIRA_NO"));
				egitimDizi.append("%1");
				for (int i = firstIndex; i < 6; i++)
					egitimDizi.append('1');
			}
			GMServerDatasource.close(rSet);
			StringBuffer calismaSekliDizi = new StringBuffer("___________");
			if (calismaSekliKod != null) {
				GMServerDatasource.close(stmt);
				stmt = conn.prepareStatement("select count(*) sira_no from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' and sira_no <= (select sira_no from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' and key1 = ?)");
				stmt.setString(1, calismaSekliKod);
				rSet = stmt.executeQuery();

				while (rSet.next()) {
					index = new Integer(rSet.getString("SIRA_NO"));
					calismaSekliDizi = calismaSekliDizi.replace(index - 1, index, "1");
				}
			}
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			stmt = conn.prepareStatement("select kod, aciklama from v_ml_gnl_meslek_kod_pr where egitim_dizi like ? and yas_dizi like ? and calisma_sekli_dizi like ? order by Decode(aciklama,'Di�er','ZZZZZZZ',aciklama)");
			stmt.setString(1, egitimDizi.toString());
			stmt.setString(2, yasDizi.toString());
			stmt.setString(3, calismaSekliDizi.toString());

			rSet = stmt.executeQuery();

			oMap.put("ADD_EMPTY_KEY", iMap.getString("BOS_ALAN"));
			oMap.put("LIST_NAME", "MESLEK_LIST");
			DALUtil.fillComboBox(oMap, rSet);
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_CALISMA_SEKLI")
	public static Map<?, ?> checkCalismaSekli(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			String calismaSekli = iMap.getString("CALISMA_SEKLI");
			BigDecimal krdTurKod = iMap.getBigDecimal("KRD_TUR_KOD");

			if (calismaSekli == null || calismaSekli.isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(1159));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "CALISMA_SEKLI")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			} else if(!calismaSekli.equalsIgnoreCase("TR") && new BigDecimal(7).equals(krdTurKod)) {
				iMap.put("HATA_NO", new BigDecimal(5896));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1 from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' and key1 = '" + calismaSekli + "' and (('" + iMap.getString("KANAL_KOD") + "' = '8' and key1 not in ('C', 'A', 'T')) or '" + iMap.getString("KANAL_KOD") + "' <> '8')");
			rSet = stmt.executeQuery();

			if (!rSet.next()) {
				iMap.put("HATA_NO", new BigDecimal(1000));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "CALISMA_SEKLI_1")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_EVE_TESLIM_URUN")
	public static Map<?, ?> checkEveTeslimUrun(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String eveTeslimUrun = null;
			if (iMap.getString("TESLIM_GEREKLI") != null && iMap.getString("TESLIM_GEREKLI").equals("E")) {
				if (!(iMap.getBoolean("TESLIM_E") || iMap.getBoolean("TESLIM_H"))) {
					iMap.put("HATA_NO", "993");
					iMap.put("P1", "eve teslimatl� �r�n bilgisini");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				else {
					if (iMap.getBoolean("TESLIM_E")) {
						if (iMap.getDate("TESLIMAT_TARIHI") != null && iMap.getDate("TESLIMAT_TARIHI").before(iMap.getDate("BANKA_TARIHI"))) {
							iMap.put("HATA_NO", "1867");
							SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
							iMap.put("P1", outputFormat.format(iMap.getDate("BANKA_TARIHI")));
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
						else if (iMap.getDate("TESLIMAT_TARIHI") == null && iMap.getBoolean("TESLIMAT_TARIHI_BOS")) {
							iMap.put("HATA_NO", "993");
							iMap.put("P1", "teslimat tarihi");
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);

						}
						else if (iMap.getDate("TESLIMAT_TARIHI") == null && !iMap.getBoolean("TESLIMAT_TARIHI_BOS")) {
							iMap.put("HATA_NO", "1866");
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
					}
					eveTeslimUrun = iMap.getBoolean("TESLIM_E") ? "E" : "H";
				}
			}

			oMap.put("EVE_TESLIM_URUN", eveTeslimUrun);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_KIMLIK_SERI_NO")
	public static Map<?, ?> checkKimlikSeriNo(GMMap iMap) {
		GMMap oMap = new GMMap();

		// TY-9248 Kontrol kredic icin yapilmasi istendi
		if (iMap.getString("KAMP_KOD") != null) {
			String personelKredic = DALUtil.getResult("select pkg_parametre.Deger_Al_K_N('PERSONEL_KREDIC') from dual");
			if (personelKredic.equals(iMap.getString("KAMP_KOD"))) {
				return oMap;
			}
		}

		String kpsKimlikSeriNo = iMap.getString("KIMLIK_SERI_NO_KPS");
		String kpsKimlikSiraNo = iMap.getString("KIMLIK_SIRA_NO_KPS");

		if (kpsKimlikSeriNo == null) {
			kpsKimlikSeriNo = iMap.getMap("KPS_DATA").getString("KIMLIK_SERI_NO");
			kpsKimlikSiraNo = iMap.getMap("KPS_DATA").getString("KIMLIK_SIRA_NO");
		}

		if (!kpsKimlikSeriNo.equals(iMap.getString("KIMLIK_SERI_NO")) || !kpsKimlikSiraNo.equals(iMap.getString("KIMLIK_SIRA_NO"))) {
			iMap.put("HATA_NO", new BigDecimal(5198));
			return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_TELEFON")
	public static Map<?, ?> checkTelefonKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			String kod = iMap.getString("KOD");
			String no = iMap.getString("TEL_NO");
			String gsm = iMap.getString("GSM");

			if (kod == null || kod.isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "CEP_TELEFONU")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (no == null || no.isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "CEP_TELEFONU_NO")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (kod == null || no == null || kod.length() < 3 || no.length() < 7) {
				iMap.put("HATA_NO", new BigDecimal(861));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "CEP_TELEFONU_1")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareStatement("select * from gnl_tel_alan_kod_pr where kod = ? and gsm = ?");
			stmt.setString(1, kod);
			stmt.setString(2, gsm);

			rSet = stmt.executeQuery();

			if (!rSet.next()) {
				iMap.put("HATA_NO", new BigDecimal(1000));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "CEP_TELEFONU_KOD_1")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_TELEFON_KOD")
	public static Map<?, ?> getTelefonKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			String kod = iMap.getString("IL_KOD");

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareStatement("select kod from gnl_tel_alan_kod_pr where il_kod = ?");
			stmt.setString(1, kod);

			rSet = stmt.executeQuery();

			if (rSet.next())
				oMap.put("KOD", rSet.getString("KOD"));
			if (rSet.next())
				oMap.put("KOD", "");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BAYI_IL_ILCE_KOD")
	public static Map<?, ?> getBayiIlIlceKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			if (iMap.getBigDecimal("SATICI_KOD") == null) {
				oMap.put("BAYI_IL_KOD", "X");
				oMap.put("BAYI_ILCE_KOD", "X");
			}
			else {
				stmt = conn.prepareStatement("select a.il_kod, a.ilce_kod from bir_satici s, gnl_musteri_adres a where a.musteri_no = s.musteri_no and a.extre_adresi_mi = 'E' and s.kod = ?");
				stmt.setBigDecimal(1, iMap.getBigDecimal("SATICI_KOD"));

				rSet = stmt.executeQuery();

				if (rSet.next()) {
					oMap.put("BAYI_IL_KOD", rSet.getString("IL_KOD"));
					oMap.put("BAYI_ILCE_KOD", rSet.getString("ILCE_KOD"));
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA")
	public static GMMap getKimlikBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap sMap = new GMMap();
			sMap.put("TCKN", iMap.getString("TCKNO"));
			String tcKimlikNo = iMap.getString("TCKNO");
			// sMap = new
			// GMMap(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_KPS_GET_KISI_BILGILERI",
			// sMap));
			try {
				sMap = GMServiceExecuter.call("BNSPR_KPS_GET_KISI_BILGILERI", sMap);
			}
			catch (Exception e) {

			}

			if (sMap.getInt("HATA_KOD") == 0) {
				BilesikKutukModel bilesikKutukModel = (BilesikKutukModel) sMap.get("KISI_BILGISI");

				if (bilesikKutukModel != null) {
					Calendar dogumTarihi = Calendar.getInstance();
					if (tcKimlikNo.startsWith("9")) {
						YabanciKisiBilgisiModel yabanciKisiBilgisiModel = bilesikKutukModel.getYabanciKisiBilgisiModel();
						TarihModel dogumTarih = yabanciKisiBilgisiModel.getDogumTarih();
						if (dogumTarih != null) {
							dogumTarihi.set(dogumTarih.getYil(), dogumTarih.getAy() - 1, dogumTarih.getGun());
							oMap.put("DOGUM_TARIHI", dogumTarihi.getTime());
						}

						oMap.put("TCKNO_OUT", yabanciKisiBilgisiModel.getKimlikNo());
						oMap.put("AD", yabanciKisiBilgisiModel.getAd());
						oMap.put("SOYAD", yabanciKisiBilgisiModel.getSoyad());
						oMap.put("CINSIYET", KPSUtil.getParametreAciklama(yabanciKisiBilgisiModel.getCinsiyet()));
						oMap.put("CINSIYET_KOD", KPSUtil.getParametreKod(yabanciKisiBilgisiModel.getCinsiyet()));
						oMap.put("BABA_AD", yabanciKisiBilgisiModel.getBabaAd());
						oMap.put("ANNE_AD", yabanciKisiBilgisiModel.getAnneAd());

						oMap.put("KIZLIK_SOYAD", "");
						oMap.put("DOGUM_YERI", yabanciKisiBilgisiModel.getDogumYer());
						oMap.put("DURUMU", KPSUtil.getParametreKod(yabanciKisiBilgisiModel.getDurum())); // DURUMU_KOD
						oMap.put("DURUMU_ACIKLAMA", KPSUtil.getParametreAciklama(yabanciKisiBilgisiModel.getDurum()));
						oMap.put("MEDENI_HALI", KPSUtil.getParametreAciklama(yabanciKisiBilgisiModel.getMedeniHal()));
						oMap.put("MEDENI_HALI_KOD", KPSUtil.getParametreKod(yabanciKisiBilgisiModel.getMedeniHal()));
						oMap.put("ES_TCKN", yabanciKisiBilgisiModel.getEsKimlikNo());

						String ad = StringUtils.EMPTY;
						ad = yabanciKisiBilgisiModel.getAd();

						String ad1;
						String ad2;
						if (ad.indexOf(" ") >= 0) {
							ad1 = ad.substring(0, ad.indexOf(" "));
							ad2 = ad.substring(ad.indexOf(" ")).trim();
						}
						else {
							ad1 = ad;
							ad2 = null;
						}
						oMap.put("AD1", ad1);
						oMap.put("AD2", ad2);

						String olumTarihStr = StringUtils.EMPTY;
						TarihModel olumTarihModel = yabanciKisiBilgisiModel.getOlumTarih();
						if (yabanciKisiBilgisiModel.getOlumTarih() != null) {
							olumTarihStr = yabanciKisiBilgisiModel.getOlumTarih().toString();
						}
						if (!StringUtil.isEmpty(olumTarihStr)) {
							Calendar olumTarihi = Calendar.getInstance();
							olumTarihi.set(olumTarihModel.getYil(), olumTarihModel.getAy() - 1, olumTarihModel.getGun());
							oMap.put("OLUM_TARIHI", olumTarihi.getTime());
						}
					}
					else {
						TCKisiBilgisiModel tcKisiBilgisiModel = bilesikKutukModel.getTcKisiBilgisiModel();
						TCCuzdanBilgisiModel tcCuzdanBilgisiModel = bilesikKutukModel.getTcCuzdanBilgisiModel();
						TCKKModel tckkModel = bilesikKutukModel.getTckkModel();

						TarihModel dogumTarih = tcKisiBilgisiModel.getDogumTarih();
						if (dogumTarih != null) {
							dogumTarihi.set(dogumTarih.getYil(), dogumTarih.getAy() - 1, dogumTarih.getGun());
							oMap.put("DOGUM_TARIHI", dogumTarihi.getTime());
						}

						oMap.put("TCKNO_OUT", tcKisiBilgisiModel.getTcKimlikNo());
						oMap.put("AD", tcKisiBilgisiModel.getAd());
						oMap.put("SOYAD", tcKisiBilgisiModel.getSoyad());
						oMap.put("CINSIYET", KPSUtil.getParametreAciklama(tcKisiBilgisiModel.getCinsiyet()));
						oMap.put("CINSIYET_KOD", KPSUtil.getParametreKod(tcKisiBilgisiModel.getCinsiyet()));
						oMap.put("BABA_AD", tcKisiBilgisiModel.getBabaAd());
						oMap.put("ANNE_AD", tcKisiBilgisiModel.getAnneAd());

						oMap.put("KIZLIK_SOYAD", "");
						oMap.put("DOGUM_YERI", tcKisiBilgisiModel.getDogumYer());
						oMap.put("DURUMU", KPSUtil.getParametreKod(tcKisiBilgisiModel.getDurum())); // DURUMU_KOD
						oMap.put("DURUMU_ACIKLAMA", KPSUtil.getParametreAciklama(tcKisiBilgisiModel.getDurum()));
						oMap.put("MEDENI_HALI", KPSUtil.getParametreAciklama(tcKisiBilgisiModel.getMedeniHal()));
						oMap.put("MEDENI_HALI_KOD", KPSUtil.getParametreKod(tcKisiBilgisiModel.getMedeniHal()));
						oMap.put("ES_TCKN", tcKisiBilgisiModel.getEsTCKimlikNo());
						oMap.put("DIN", tcKisiBilgisiModel.getDin());

						String ad = StringUtils.EMPTY;
						ad = tcKisiBilgisiModel.getAd();

						String ad1;
						String ad2;
						if (ad.indexOf(" ") >= 0) {
							ad1 = ad.substring(0, ad.indexOf(" "));
							ad2 = ad.substring(ad.indexOf(" ")).trim();
						}
						else {
							ad1 = ad;
							ad2 = null;
						}
						oMap.put("AD1", ad1);
						oMap.put("AD2", ad2);

						String ilKodu = String.valueOf(tcKisiBilgisiModel.getIl().getKod());

						if (ilKodu.length() == 2)
							ilKodu = "0" + ilKodu;
						if (ilKodu.length() == 1)
							ilKodu = "00" + ilKodu;
						oMap.put("IL_KODU", ilKodu);
						oMap.put("IL", String.valueOf(tcKisiBilgisiModel.getIl().getAciklama()));
						oMap.put("ILCE_KODU", String.valueOf(tcKisiBilgisiModel.getIlce().getKod()));
						oMap.put("ILCE", String.valueOf(tcKisiBilgisiModel.getIlce().getAciklama()));
						oMap.put("MAHALLE_KOY", tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel.getCilt().getAciklama() : "");
						oMap.put("CILT_KODU", tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel.getCilt().getKod() : "");
						oMap.put("CILT", tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel.getCilt().getAciklama() : "");
						oMap.put("AILE_SIRA_NO", tcKisiBilgisiModel.getAileSiraNo());
						oMap.put("BIREY_SIRA_NO", tcKisiBilgisiModel.getBireySiraNo());

						String olumTarihStr = StringUtils.EMPTY;
						TarihModel olumTarihModel = tcKisiBilgisiModel.getOlumTarih();
						if (tcKisiBilgisiModel.getOlumTarih() != null) {
							olumTarihStr = tcKisiBilgisiModel.getOlumTarih().toString();
						}
						if (!StringUtil.isEmpty(olumTarihStr)) {
							Calendar olumTarihi = Calendar.getInstance();
							olumTarihi.set(olumTarihModel.getYil(), olumTarihModel.getAy() - 1, olumTarihModel.getGun());
							oMap.put("OLUM_TARIHI", olumTarihi.getTime());
						}

						if (tcCuzdanBilgisiModel != null && !StringUtils.isEmpty(tcCuzdanBilgisiModel.getSeri())) {
							oMap.put("KIMLIK_SERI_NO", tcCuzdanBilgisiModel.getSeri());

							String ncNo = tcCuzdanBilgisiModel.getNo();
							if (ncNo.length() == 5)
								ncNo = "0" + ncNo;
							if (ncNo.length() == 4)
								ncNo = "00" + ncNo;
							if (ncNo.length() == 3)
								ncNo = "000" + ncNo;
							if (ncNo.length() == 2)
								ncNo = "0000" + ncNo;
							oMap.put("KIMLIK_SIRA_NO", ncNo);
							oMap.put("VERILDIGI_ILCE_KODU", KPSUtil.getParametreKod(tcCuzdanBilgisiModel.getVerildigiIlce()));
							oMap.put("VERILDIGI_ILCE_ADI", KPSUtil.getParametreAciklama(tcCuzdanBilgisiModel.getVerildigiIlce()));

							TarihModel verilmeTarihModel = tcCuzdanBilgisiModel.getVerilmeTarih();
							if (verilmeTarihModel != null) {
								Calendar verilisTarihi = Calendar.getInstance();
								verilisTarihi.set(verilmeTarihModel.getYil(), verilmeTarihModel.getAy() - 1, verilmeTarihModel.getGun());
								oMap.put("VERILIS_TARIHI", verilisTarihi.getTime());
							}
							oMap.put("VERILIS_NEDENI", KPSUtil.getParametreAciklama(tcCuzdanBilgisiModel.getCuzdanVerilmeNeden()));
							oMap.put("VERILIS_NEDENI_KOD", KPSUtil.getParametreKod(tcCuzdanBilgisiModel.getCuzdanVerilmeNeden()));
							oMap.put("KIMLIK_KAYIT_NO", tcCuzdanBilgisiModel.getCuzdanKayitNo());
						}
						else if (tckkModel != null && !StringUtils.isEmpty(tckkModel.getSeriNo())) {
							oMap.put("KIMLIK_SERI_NO", tckkModel.getSeriNo().substring(0, 3));
							oMap.put("KIMLIK_SIRA_NO", tckkModel.getSeriNo().substring(3));
							oMap.put("VERILDIGI_ILCE_KODU", KPSUtil.getParametreKod(tckkModel.getTeslimEdenBirim()));
							oMap.put("VERILDIGI_ILCE_ADI", KPSUtil.getParametreAciklama(tckkModel.getTeslimEdenBirim()));

							TarihModel verilmeTarihModel = tckkModel.getTeslimTarih();
							if (verilmeTarihModel != null) {
								Calendar verilisTarihi = Calendar.getInstance();
								verilisTarihi.set(verilmeTarihModel.getYil(), verilmeTarihModel.getAy() - 1, verilmeTarihModel.getGun());
								oMap.put("VERILIS_TARIHI", verilisTarihi.getTime());
							}
							oMap.put("VERILIS_NEDENI", KPSUtil.getParametreAciklama(tckkModel.getBasvuruNeden()));
							oMap.put("VERILIS_NEDENI_KOD", KPSUtil.getParametreKod(tckkModel.getBasvuruNeden()));
							oMap.put("KIMLIK_KAYIT_NO", tckkModel.getKayitNo());
						}
					}

					ADCSession.put("KPS_MAP", oMap);
				}
				else {
					ADCSession.remove("KPS_MAP");
				}
			}
			else if (oMap.getInt("HATA_KOD") == 1 || oMap.getInt("HATA_KOD") == 2) {

				iMap.put("HATA_NO", "456");
				iMap.put("P1", tcKimlikNo);
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);

			}
			else {
				oMap.put("TCKNO", tcKimlikNo);
				oMap.put("KPS_LOG", "KAPALI");
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_KPS_KIMLIK_DOGRULAMA")
	public static GMMap kimlikDogrulama(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			/** burasi yeni KPS ile KPS_SORGULAMA servisine tasindi **/
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_KPS_KAYIP_KIMLIK_SORGULAMA")
	public static GMMap kayipKimlikSorgulama(GMMap iMap) {
		GMMap oMap = new GMMap();
		/*
		 * try{ KayipCuzdanC kayipCuzdanBilgisi =
		 * KpsServices.getKayipCuzdanBilgisi(iMap.getString("TCKNO"));
		 * if(kayipCuzdanBilgisi != null) { oMap.put("KAYIP_CUZDAN_SERI",
		 * kayipCuzdanBilgisi.getKayipCuzdanSeri()); oMap.put("KAYIP_CUZDAN_NO",
		 * kayipCuzdanBilgisi.getKayipCuzdanNo()); } return oMap; } catch
		 * (KpsBusinessException e) { KPSSorguSonucu sorguSonucu =
		 * e.getSorguSonucu(); e.printStackTrace();
		 * System.err.println(sorguSonucu.getHataKod());
		 * System.err.println(sorguSonucu.getHata()); } catch (Exception e) { //
		 * throw ExceptionHandler.convertException(e); }
		 */
		return oMap;
	}

	@SuppressWarnings("unused")
	public static String concatYilAy(String yil, String ay) {
		String yilAy = new String();

		if (yil != null && yil.equals("") && ay != null && ay.equals("")) {
			return null;
		}

		if (yil == null) {
			if (ay == null) {
				return null;
			}
			else if (ay.length() == 0) {
				return null;
			}
			else if (ay.length() == 1) {
				return "000" + ay;
			}
			else {
				return "00" + ay;
			}
		}

		if (ay == null) {
			if (yil == null) {
				return null;
			}
			else if (yil.length() == 0) {
				return null;
			}
			else if (yil.length() == 1) {
				return "0" + yil + "00";
			}
			else {
				return yil + "00";
			}
		}
		if (yil.length() == 0 || yil.equals("0"))
			yilAy = "00";
		else if (yil.length() == 1)
			yilAy = "0" + yil;
		else
			yilAy = yil;
		if (ay.length() == 0 || ay.equals("0"))
			yilAy = yilAy + "00";
		else if (ay.length() == 1)
			yilAy = yilAy + "0" + ay;
		else
			yilAy = yilAy + ay;

		return yilAy;
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_DOGUM_TARIHI")
	public static Map<?, ?> checkDogumTarihi(GMMap iMap) {
		try {
			Calendar dogumTar = GregorianCalendar.getInstance();
			if (iMap.getDate("DOGUM_TARIHI") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Dogum Tarihi");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			dogumTar.setTime(iMap.getDate("DOGUM_TARIHI"));

			Calendar onsekizYilOncesi = new GregorianCalendar();
			onsekizYilOncesi.setTime(iMap.getDate("BANKA_TARIHI"));
			onsekizYilOncesi.add(GregorianCalendar.YEAR, -18);
			if (dogumTar.after(onsekizYilOncesi)) {
				iMap.put("HATA_NO", new BigDecimal(951));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KAMPANYA_KULLANILABILIR_MI")
	public static Map<?, ?> kampanyaKullanilabilirMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			if (iMap.getBigDecimal("KAMP_KOD") != null) {
				stmt = conn.prepareCall("{call pkg_kampanya.Kamp_MusteriIcinGecerliMi(?,?)}");
				int i = 1;
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KOD"));
				stmt.setString(i++, iMap.getString("TCKN"));

				stmt.execute();
			}
			// String urunKampKod = iMap.getString("KAMP_URUN_ADI");
			// if(urunKampKod.indexOf('-') < 0)
			// {
			// BigDecimal kampKod = new BigDecimal(urunKampKod);
			// stmt = conn.prepareCall("{call pkg_kampanya.Kamp_MusteriIcinGecerliMi(?,?)}");
			// int i = 1;
			// stmt.setBigDecimal(i++, kampKod);
			// stmt.setString(i++, iMap.getString("TCKN"));
			//
			// stmt.execute();
			// }

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_TURKCE_CHAR")
	public static Map<?, ?> checkTurkceChar(GMMap iMap) {
		try {
			String alan = iMap.getString("ALAN");
			String charSet = "���i��";
			for (int i = 0; i < charSet.length(); i++) {
				if (alan.indexOf(charSet.charAt(i)) > -1) {
					iMap.put("HATA_NO", new BigDecimal(593));
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KRD_TUR_KOD_BOL")
	public static Map<?, ?> krdTurKodBol(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			if (iMap.getString("KOD") != null) {
				String kod = iMap.getString("KOD");
				if (kod.indexOf('-') > 0) {
					String altTurKod = kod.substring(0, kod.indexOf('-'));
					String altTurKod2 = kod.substring(kod.indexOf('-') + 1);

					oMap.put("KRD_TUR_ALT_KOD", altTurKod);
					oMap.put("KRD_TUR_ALT_KOD2", altTurKod2);
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_AD")
	public static Map<?, ?> checkAd(GMMap iMap) {
		try {
			String ad = iMap.getString("AD");
			String alanAdi = iMap.getString("ALAN_ADI");

			if (ad == null || ad.length() == 0) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", alanAdi)).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (ad.length() <= 1) {
				iMap.put("HATA_NO", new BigDecimal(973));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", alanAdi + "_1")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			String regexp = "^(?:\\p{L}\\p{M}*|[\\.]|[\\ ])*$";
			// Anne Kizlik Soyad icerisinde Bosluk kabul edilmesin. TY-1189 adem
			if (alanAdi.equals("AKS")) {
				regexp = "^(?:\\p{L}\\p{M}*|[\\.])*$";
			}
			if (alanAdi.contains("ADRES")) {
				regexp = "^(?:.*[\\p{L}]+.*)*$";
			}
			String newWord = new String(ad);
			newWord = newWord.toUpperCase();

			int i = 0;
			int len = newWord.length();

			if (!newWord.matches(regexp)) {
				iMap.put("HATA_NO", new BigDecimal(974));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", alanAdi + "_1")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			len = ad.length();
			for (i = 0; i < len - 2; i++) {
				if (ad.charAt(i) == ad.charAt(i + 1) && ad.charAt(i + 1) == ad.charAt(i + 2)) {
					if (!ad.substring(i, i + 1).matches("[0-9]")) {
						iMap.put("HATA_NO", new BigDecimal(975));
						iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", alanAdi + "_1")).get("TEXT"));
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
				}
			}
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_KIMLIK_NO")
	public static Map<?, ?> checkKimlikNo(GMMap iMap) {
		try {
			String seriNo = iMap.getString("SERI_NO");
			String siraNo = iMap.getString("SIRA_NO");
			if (iMap.getString("CINSIYET") == null) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "CINSIYET")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			String cinsiyet = iMap.getString("CINSIYET").substring(0, 1);
			if (seriNo == null || seriNo.isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "KIMLIK_SERI_NO")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (siraNo == null || siraNo.isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "KIMLIK_SIRA_NO")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			return new GMMap();
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER")
	public static Map<?, ?> checkUrunBazindaMinMaxDeger(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			String urunKampKod = iMap.getString("KAMP_URUN_ADI");
			if (urunKampKod == null || urunKampKod.isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(1159));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "KAMPANYA_URUN_ADI")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (iMap.getBigDecimal("KREDI_TUTARI").toString().compareTo("0.00") == 0 || iMap.getBigDecimal("KREDI_TUTARI").toString().compareTo("0") == 0) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "TUTAR")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (iMap.getBigDecimal("KREDI_VADESI") == null || iMap.getBigDecimal("KREDI_VADESI").equals(new BigDecimal(0))) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "VADE")).get("TEXT"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			BigDecimal tutar = iMap.getBigDecimal("KREDI_TUTARI");
			BigDecimal vade = iMap.getBigDecimal("KREDI_VADESI");
			BigDecimal krdAltTur;
			BigDecimal krdAltTur2;
			BigDecimal kampKod;
			int i = 1;
			if (urunKampKod.indexOf('-') < 0) {
				kampKod = new BigDecimal(urunKampKod);
				stmt = conn.prepareCall("{call pkg_bireysel.KrdTipMinMaxDeger_Kampanya(?,?,?,?,?,?,?)}");
				stmt.setBigDecimal(i++, kampKod);
				stmt.setString(i++, iMap.getBigDecimal("KANAL_KOD").toString());
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			}
			else {
				krdAltTur = new BigDecimal(urunKampKod.substring(0, urunKampKod.indexOf('-')));
				krdAltTur2 = new BigDecimal(urunKampKod.substring(urunKampKod.indexOf('-') + 1));
				stmt = conn.prepareCall("{call pkg_bireysel.KrdTipMinMaxDeger_UrunBazinda(?,?,?,?,?,?,?,?,?)}");
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_TUR_KOD"));
				stmt.setBigDecimal(i++, krdAltTur);
				stmt.setBigDecimal(i++, krdAltTur2);
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KOD"));
			}

			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);

			stmt.execute();
			BigDecimal maxTutar = stmt.getBigDecimal(--i);
			BigDecimal minTutar = stmt.getBigDecimal(--i);
			BigDecimal maxVade = stmt.getBigDecimal(--i);
			BigDecimal minVade = stmt.getBigDecimal(--i);

			if (tutar.compareTo(minTutar) < 0 || tutar.compareTo(maxTutar) > 0) {
				iMap.put("HATA_NO", new BigDecimal(1042));
				iMap.put("P1", minTutar);
				iMap.put("P2", maxTutar);
				iMap.put("P3", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_DOVIZ_BASIM_KODU", iMap).get("DOVIZ_BASIM_KODU"));
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (vade.compareTo(minVade) < 0 || vade.compareTo(maxVade) > 0) {
				iMap.put("HATA_NO", new BigDecimal(1041));
				iMap.put("P1", minVade);
				iMap.put("P2", maxVade);
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return new GMMap();

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KREDI_MIN_MAX_DEGER")
	public static Map<?, ?> getUrunBazindaMinMaxDeger(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			GMMap oMap = new GMMap();
			String urunKampKod = iMap.getString("KAMP_URUN_ADI");
			if (urunKampKod == null || urunKampKod.isEmpty()) {
				oMap.put("VADE_LABEL", "Kredi Vadesi");
				return oMap;
			}
			BigDecimal krdAltTur;
			BigDecimal krdAltTur2;
			BigDecimal kampKod;
			int i = 1;
			if (urunKampKod.indexOf('-') < 0) {
				kampKod = new BigDecimal(urunKampKod);
				stmt = conn.prepareCall("{call pkg_bireysel.KrdTipMinMaxDeger_Kampanya(?,?,?,?,?,?,?)}");
				stmt.setBigDecimal(i++, kampKod);
				stmt.setString(i++, iMap.getBigDecimal("KANAL_KOD").toString());
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			}
			else {
				krdAltTur = new BigDecimal(urunKampKod.substring(0, urunKampKod.indexOf('-')));
				krdAltTur2 = new BigDecimal(urunKampKod.substring(urunKampKod.indexOf('-') + 1));
				stmt = conn.prepareCall("{call pkg_bireysel.KrdTipMinMaxDeger_UrunBazinda(?,?,?,?,?,?,?,?,?)}");
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_TUR_KOD"));
				stmt.setBigDecimal(i++, krdAltTur);
				stmt.setBigDecimal(i++, krdAltTur2);
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KOD"));
			}

			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);

			stmt.execute();

			BigDecimal maxTutar = stmt.getBigDecimal(--i);
			BigDecimal minTutar = stmt.getBigDecimal(--i);
			BigDecimal maxVade = stmt.getBigDecimal(--i);
			BigDecimal minVade = stmt.getBigDecimal(--i);

			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_GRUBU_TUR", iMap));

			oMap.put("MIN_MAX_TUTAR", "(" + (minTutar == null ? "" : minTutar) + "-" + (maxTutar == null ? "" : maxTutar) + ")" + iMap.getString("DOVIZ_KODU"));
			oMap.put("MIN_MAX_VADE", "(" + (minVade == null ? "" : minVade) + "-" + (maxVade == null ? "" : maxVade) + ")" + (iMap.getString("ODEME_GRUBU_SIKMI") != null && "E".equals(iMap.getString("ODEME_GRUBU_SIKMI")) ? "taksit" : "ay"));
			oMap.put("MIN_TUTAR", minTutar);
			oMap.put("MAX_TUTAR", maxTutar);
			oMap.put("MIN_VADE", minVade);
			oMap.put("MAX_VADE", maxVade);

			if (iMap.getString("ODEME_GRUBU_SIKMI") != null && "E".equals(iMap.getString("ODEME_GRUBU_SIKMI")))
				oMap.put("VADE_LABEL", "Taksit Say�s�");
			else
				oMap.put("VADE_LABEL", "Kredi Vadesi");
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ODEME_GRUBU_TUR")
	public static Map<?, ?> getOdemeGrubuTur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			GMMap oMap = new GMMap();
			String urunKampKod = iMap.getString("KAMP_URUN_ADI");
			if (urunKampKod == null || urunKampKod.isEmpty())
				return oMap;

			BigDecimal kampKod;
			int i = 1;
			if (urunKampKod.indexOf('-') < 0) {
				kampKod = new BigDecimal(urunKampKod);
				stmt = conn.prepareCall("{? = call PKG_KAMPANYA.ODEME_GRUBU_SIK_MI(?)}");
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.setBigDecimal(i++, kampKod);

				stmt.execute();
				String odemeGrubuSikMi = stmt.getString(1);
				oMap.put("ODEME_GRUBU_SIKMI", odemeGrubuSikMi);
			}
			else
				oMap.put("ODEME_GRUBU_SIKMI", "H");

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_FAIZ_ORANI")
	public static Map<?, ?> checkFaizOrani(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			String urunKampKod = iMap.getString("KAMP_URUN_ADI");
			if (urunKampKod == null || urunKampKod.isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", "Kampanya/Urun Adini");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getBigDecimal("TUTAR").equals(new BigDecimal(0))) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", "kredi tutari");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (iMap.getBigDecimal("VADE").equals(new BigDecimal(0))) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", "kredi vadesini");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			BigDecimal krdAltTur;
			BigDecimal krdAltTur2;
			BigDecimal kampKod;
			BigDecimal faizOrani;
			BigDecimal SozlesmeFaizOrani = new BigDecimal("0");
			int i = 1;
			if (urunKampKod.indexOf('-') < 0) {
				kampKod = new BigDecimal(urunKampKod);
				stmt = conn.prepareCall("{call pkg_bireysel.FaizOrani_kamp( ?, ?, ?, ?, ?, ?, ?) }");

				stmt.setBigDecimal(i++, kampKod);
				stmt.setString(i++, iMap.getBigDecimal("KANAL_KOD").toString());
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));

				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.execute();
				faizOrani = stmt.getBigDecimal(6);
				SozlesmeFaizOrani = stmt.getBigDecimal(7);
			}
			else {
				krdAltTur = new BigDecimal(urunKampKod.substring(0, urunKampKod.indexOf('-')));
				krdAltTur2 = new BigDecimal(urunKampKod.substring(urunKampKod.indexOf('-') + 1));
				stmt = conn.prepareCall("{? = call pkg_bireysel.FaizOrani(?, ?, ?, ?, ?, ?, ?)}");
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_TUR_KOD"));
				stmt.setBigDecimal(i++, krdAltTur);
				stmt.setBigDecimal(i++, krdAltTur2);
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KOD"));
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
				stmt.execute();
				faizOrani = stmt.getBigDecimal(1);
			}
			GMMap oMap = new GMMap();
			oMap.put("FAIZ_ORANI", faizOrani);
			oMap.put("SOZLESME_FAIZ_ORANI", SozlesmeFaizOrani);

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_FAIZ_ORANI_LIST")
	public static GMMap checkFaizOraniList(GMMap iMap) {
		GMMap oMap = new GMMap();
		String procStr = "{ call pkg_bireysel.FaizOrani_kamp_list(?,?,?,?,?,?)}";
		int i = 0;
		Object[] inputValues = new Object[10];
		Object[] outputValues = new Object[2];

		try {
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("KAMP_URUN_ADI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KANAL_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DOVIZ_KODU");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("VADE");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			
			i = 0;

			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "RC_LIST";

			GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

			oMap.putAll(resultMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;

	}

	@GraymoundService("BNSPR_TRN3171_GET_KAMP_KNL_KOD")
	public static Map<?, ?> getKampKnlKod(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			String urunKampKod = iMap.getString("KAMP_URUN_ADI");

			GMMap oMap = new GMMap();
			BigDecimal kampKod;
			BigDecimal kampKnlKod = null;
			int i = 1;
			if (urunKampKod.indexOf('-') < 0) {
				kampKod = iMap.getBigDecimal("KAMP_URUN_ADI");
				stmt = conn.prepareCall("{call pkg_bireysel.Kamp_Knl_Kod( ?, ?, ?, ?, ?, ?) }");

				stmt.setBigDecimal(i++, kampKod);
				stmt.setString(i++, iMap.getBigDecimal("KANAL_KOD").toString());
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));

				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.execute();
				kampKnlKod = stmt.getBigDecimal(6);

				oMap.put("KAMP_KOD", kampKod);
			}

			oMap.put("KAMP_KNL_KOD", kampKnlKod);
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN")
	public static GMMap getOdemeGruplarUrun(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			if (iMap.getString("KAMP_URUN_ADI") == null)
				return oMap;

			String urunKampKod = iMap.getString("KAMP_URUN_ADI");
			int i = 1;
			if (urunKampKod.indexOf('-') < 0) {
				stmt = conn.prepareCall("{? = call pkg_bireysel.OdemeGruplar_Kamp(?)}");
				stmt.registerOutParameter(i++, -10);
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_URUN_ADI"));
			}
			else {
				stmt = conn.prepareCall("{? = call Pkg_Bireysel.OdemeGruplar_Urun(?,?,?,?,?)}");
				stmt.registerOutParameter(i++, -10);
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_TUR_KOD"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KOD"));
				stmt.setString(i++, iMap.getString("DOVIZ_KOD"));
			}
			stmt.execute();

			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			int count = 0;
			String defaultOdemeTipKod = null;
			GMMap oGMap = new GMMap();
			while (rSet.next()) {
				defaultOdemeTipKod = rSet.getString(2);
				GuimlUtil.wrapMyCombo(oMap, "ODEME_TIP_LIST", rSet.getString(2), rSet.getString(3));
				oMap.put("ODEME_TIP_TABLE", count, "ODEME_GRUP_KOD", rSet.getString(1));
				oMap.put("ODEME_TIP_TABLE", count, "ODEME_TIP_KOD", rSet.getString(2));
				oMap.put("ODEME_TIP_TABLE", count, "ODEME_TIP_ADI", rSet.getString(3));
				oGMap.clear();
				oGMap.putAll(GMServiceExecuter.call("BPM_GET_ODEME_GRUP_BILGILERI", oMap.getMap("ODEME_TIP_TABLE", count)));

				oMap.put("ODEME_TIP_TABLE", count, "MIN_VADE", oGMap.get("MIN_VADE"));
				oMap.put("ODEME_TIP_TABLE", count, "MAX_VADE", oGMap.get("MAX_VADE"));
				oMap.put("ODEME_TIP_TABLE", count, "MIN_ORAN", oGMap.get("MIN_ORAN"));
				oMap.put("ODEME_TIP_TABLE", count, "MAX_ORAN", oGMap.get("MAX_ORAN"));
				oMap.put("ODEME_TIP_TABLE", count, "MIN_TUTAR", oGMap.get("MIN_TUTAR"));
				oMap.put("ODEME_TIP_TABLE", count, "MAX_TUTAR", oGMap.get("MAX_TUTAR"));
				oMap.put("ODEME_TIP_TABLE", count, "MIN_PERIYOD", oGMap.get("MIN_PERIYOD"));
				oMap.put("ODEME_TIP_TABLE", count, "MAX_PERIYOD", oGMap.get("MAX_PERIYOD"));

				count++;
			}
			if (count == 1)
				oMap.put("DEFAULT_ODEME_TIP", defaultOdemeTipKod);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_SAVE")
	public static Map<?, ?> saveTRN3171(GMMap iMap) {
		// Boolean isMarried = false;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI").trim());
			}

			BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.get(BirBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birBasvuruTx == null)
				birBasvuruTx = new BirBasvuruTx();
			birBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));

			birBasvuruTx.setAdcOwner(iMap.getString("ADC_OWNER"));
			birBasvuruTx.setSatisPersoneli(iMap.getBigDecimal("PERSONEL"));
			birBasvuruTx.setEveTeslimatliUrun(iMap.getString("EVE_TESLIM_URUN"));
			birBasvuruTx.setUrunTeslimTarihi(iMap.getDate("TESLIMAT_TARIHI"));
			birBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			if (!(birBasvuruTx.getRecursiveFlag() != null && birBasvuruTx.getRecursiveFlag().compareTo(BigDecimal.ONE) == 0)) {
				birBasvuruTx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAFI"));
				birBasvuruTx.setTutar(iMap.getBigDecimal("HERSEY_DAHIL_TUTAR", iMap.getBigDecimal("TUTAR")));
				birBasvuruTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
				if (iMap.getString("SERBEST_KATKI_PAYI") != null && iMap.getString("SERBEST_KATKI_PAYI") != "H") {
					birBasvuruTx.setSerbestKatkiPayi(iMap.getBigDecimal("KATILIM_BEDELI"));
				}
				else {
					birBasvuruTx.setSerbestKatkiPayi(null);
				}
			}
			birBasvuruTx.setDovizKodu(iMap.getString("DOVIZ_KOD"));
			birBasvuruTx.setDurumKodu("BASVURU"); // TODO degisecek
			if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
				birBasvuruTx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));
				birBasvuruTx.setKrediAltTur(null);
				birBasvuruTx.setKrediAltTur2(null);
				if (!(birBasvuruTx.getRecursiveFlag() != null && birBasvuruTx.getRecursiveFlag().compareTo(BigDecimal.ONE) == 0)) {
					birBasvuruTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
				}
			}
			else {
				birBasvuruTx.setKampKod(null);
				birBasvuruTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birBasvuruTx.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				birBasvuruTx.setKampKnlKod(null);
			}

			birBasvuruTx.setKanalKodu(iMap.getString("KANAL_KOD"));
			if (iMap.containsKey("BAGLI_SUBE_KOD")) {
				birBasvuruTx.setBagliSubeKodu(iMap.getString("BAGLI_SUBE_KOD"));
			}
			birBasvuruTx.setKrediTur(iMap.getBigDecimal("KRD_TUR_KOD"));
			birBasvuruTx.setOdemeTipKod(iMap.getBigDecimal("ODEME_TIPI"));
			birBasvuruTx.setOdemeTipOran(iMap.getBigDecimal("ODEME_ORANI"));
			birBasvuruTx.setOdemeTipPeriyod(iMap.getBigDecimal("ODEME_PERIYODU"));
			birBasvuruTx.setOdemeTipTut(iMap.getBigDecimal("ODEME_TUTARI"));
			birBasvuruTx.setOdemeTipVade(iMap.getBigDecimal("ODEME_VADESI"));
			birBasvuruTx.setAksiyonKod("");
			birBasvuruTx.setSaticiKod(iMap.getBigDecimal("KANAL_ALT_KOD"));

			birBasvuruTx.setVade(iMap.getBigDecimal("VADE"));
			if (iMap.getString("DOSYA_MASRAF_TIPI") != null && iMap.getString("DOSYA_MASRAF_TIPI") != "Y") {
				birBasvuruTx.setSozlesmeFaizi(iMap.getBigDecimal("SOZLESME_FAIZI"));
			}
			else {
				birBasvuruTx.setSozlesmeFaizi(null);
			}
			birBasvuruTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
			birBasvuruTx.setGorus(iMap.getString("DIGER_GORUS"));
			birBasvuruTx.setIslemSonrasiDurumKodu("NBSM");
			birBasvuruTx.setSubeKod(iMap.getString("SUBE_KOD"));
			birBasvuruTx.setHesapNo(iMap.getString("HESAP_NO"));
			birBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));
			birBasvuruTx.setBasvuruTutari(iMap.getBigDecimal("TUTAR"));
			// birBasvuruTx.setDurumKodu("BASVURU");

			birBasvuruTx.setPttMaasAlinanKurum(iMap.getString("MAAS_ALINAN_KURUM"));

			if (iMap.get("ONCEKI_MAAS_ODEME_TARIHI") != null && iMap.getString("ONCEKI_MAAS_ODEME_TARIHI").compareTo("") != 0 && iMap.getString("ONCEKI_MAAS_ODEME_TARIHI").compareTo("00.00.0000") != 0) {
				birBasvuruTx.setPttOncekiMaasOdemeTarihi(iMap.getDate("ONCEKI_MAAS_ODEME_TARIHI"));
			}

			birBasvuruTx.setPttSgkMaasTutar(iMap.getBigDecimal("MAAS_TUTARI"));

			if (iMap.get("SON_MAAS_TARIHI") != null && iMap.getString("SON_MAAS_TARIHI").compareTo("") != 0) {
				birBasvuruTx.setPttSonMaasTarihi(iMap.getDate("SON_MAAS_TARIHI"));
			}

			birBasvuruTx.setPttMaasTarihSikligi(iMap.getBigDecimal("MAAS_TARIH_SIKLIGI"));
			birBasvuruTx.setApsYapildimi(iMap.getString("APS_YAPILDIMI"));
			birBasvuruTx.setApsBilgileriUyumlumu(iMap.getString("ADRES_BILGILERI_UYUMLUMU"));
			birBasvuruTx.setPttKpsBilgileriUyumlumu(iMap.getString("KIMLIK_BILGILERI_UYUMLUMU"));

			if (iMap.containsKey("POSTA_CEK_HESABI")) {
				birBasvuruTx.setPttPostaCekiHesabi(iMap.getBigDecimal("POSTA_CEK_HESABI"));
			}
			if (iMap.containsKey("MAAS_PTT_DENMI")) {
				birBasvuruTx.setPttMaasPttDenmi(iMap.getString("MAAS_PTT_DENMI"));
			}
			if (iMap.containsKey("EMEKLI_MAAS_EVDENMI")) {
				birBasvuruTx.setPttMaasEvdenMi(iMap.getString("EMEKLI_MAAS_EVDENMI"));
			}
			if (iMap.containsKey("TAHSIS_NUMARASI")) {
				birBasvuruTx.setPttTahsisNumarasi(iMap.getString("TAHSIS_NUMARASI"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_IL")) {
				birBasvuruTx.setPttSubeIli(iMap.getString("ISLEMIN_YAPILDIGI_IL"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_MERKEZ")) {
				birBasvuruTx.setPttIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_SUBE")) {
				birBasvuruTx.setPttIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
			}

			if (iMap.get("ILK_TAKSIT_TARIH") != null) {
				birBasvuruTx.setIlkTaksitTarihi(iMap.getDate("ILK_TAKSIT_TARIH"));
			}

			if (iMap.getString("KANAL_KOD") != null && iMap.getString("KANAL_KOD").compareTo("7") == 0) {
				birBasvuruTx.setIlkTaksitYontem(iMap.getString("PTT_ILK_TAKSIT_YONTEM"));
				birBasvuruTx.setGecikmeGunSayisi(iMap.getBigDecimal("GECIKME_GUN_SAYISI"));
			}
			birBasvuruTx.setHesapKapansinMi(iMap.getString("HESAP_KAPANSIN_MI"));
			birBasvuruTx.setTaksitGunu(iMap.getBigDecimal("TAKSIT_GUNU"));

			session.saveOrUpdate(birBasvuruTx);

			BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birBasvuruKimlikTx == null) {
				birBasvuruKimlikTx = new BirBasvuruKimlikTx();
				birBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			birBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruKimlikTx.setAd(iMap.getString("ADI"));
			birBasvuruKimlikTx.setAdresteFaaliyetSuresi(concatYilAy(iMap.getString("FAALIYET_SURESI_YIL"), iMap.getString("FAALIYET_SURESI_AY"))); // ay yil birlestir
			birBasvuruKimlikTx.setAdresteOturmaSuresi(concatYilAy(iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL"), iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY"))); //
			birBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
			birBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
			birBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
			birBasvuruKimlikTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
			birBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
			birBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
			birBasvuruKimlikTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			birBasvuruKimlikTx.setCepTelAlanKodu(iMap.getString("CEP_TEL_KOD"));
			birBasvuruKimlikTx.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			birBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
			birBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
			birBasvuruKimlikTx.setDigerGelir(iMap.getBigDecimal("DIGER_GELIR"));
			birBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
			birBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
			birBasvuruKimlikTx.setEgitimDurumKod(iMap.getString("OGRENIM_DURUMU"));
			if (iMap.getString("EMAIL1") != null && !iMap.getString("EMAIL1").isEmpty() && iMap.getString("EMAIL2") != null && !iMap.getString("EMAIL2").isEmpty()) {
				birBasvuruKimlikTx.setEMail(iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));
			}
			else {
				birBasvuruKimlikTx.setEMail("");
			}
			birBasvuruKimlikTx.setEsGeliri(iMap.getBigDecimal("ES_GELIRI") == null ? BigDecimal.ZERO : iMap.getBigDecimal("ES_GELIRI"));
			if (iMap.getString("EV_ADRESI") != null) {
				birBasvuruKimlikTx.setEvAdres(iMap.getString("EV_ADRESI").trim());
			}
			else {
				birBasvuruKimlikTx.setEvAdres("");
			}
			birBasvuruKimlikTx.setEvAdrIlceKod(iMap.getString("EV_ILCE"));
			birBasvuruKimlikTx.setEvAdrIlKod(iMap.getString("EV_IL"));
			birBasvuruKimlikTx.setEvAdrUlkeKod("TR");
			birBasvuruKimlikTx.setEvPostakod(iMap.getString("EV_POSTA_KODU"));
			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				birBasvuruKimlikTx.setEvTelAlan(iMap.getString("EV_TEL_KOD"));
				birBasvuruKimlikTx.setEvTelNo(iMap.getString("EV_TEL_NO"));
			}
			else {
				birBasvuruKimlikTx.setEvTelAlan("");
				birBasvuruKimlikTx.setEvTelNo("");
			}
			birBasvuruKimlikTx.setIkametDurumKod(iMap.getString("IKAMET_DURUMU"));
			birBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
			if (iMap.getString("IS_ADRESI") != null) {
				birBasvuruKimlikTx.setIsAdres(iMap.getString("IS_ADRESI").trim());
			}
			else {
				birBasvuruKimlikTx.setIsAdres("");
			}
			birBasvuruKimlikTx.setIsAdrIlceKod(iMap.getString("IS_ILCE"));
			birBasvuruKimlikTx.setIsAdrIlKod(iMap.getString("IS_IL"));
			birBasvuruKimlikTx.setIsAdrUlkeKod("TR");
			birBasvuruKimlikTx.setIsPostakod(iMap.getString("IS_POSTA_KODU"));
			if (iMap.getString("IS_TEL_NO") != null && !iMap.getString("IS_TEL_NO").isEmpty()) {
				birBasvuruKimlikTx.setIsTelAlan(iMap.getString("IS_TEL_KOD"));
				birBasvuruKimlikTx.setIsTelNo(iMap.getString("IS_TEL_NO"));
				birBasvuruKimlikTx.setIsTelDahili(iMap.getString("IS_TEL_DAHILI"));
			}
			else {
				birBasvuruKimlikTx.setIsTelAlan(iMap.getString(""));
				birBasvuruKimlikTx.setIsTelNo(iMap.getString(""));
				birBasvuruKimlikTx.setIsTelDahili(iMap.getString(""));
			}
			if (iMap.getString("ISYERI_ADI") != null) {
				birBasvuruKimlikTx.setIsyeriAdi(iMap.getString("ISYERI_ADI").trim());
			}
			else {
				birBasvuruKimlikTx.setIsyeriAdi("");
			}
			birBasvuruKimlikTx.setIsyeriFaalKonuKod(iMap.getString("ISYERI_FAALIYET_ALANI"));
			birBasvuruKimlikTx.setIsyeriMulkiyetKod(iMap.getString("ISYERI_MULKIYET"));
			birBasvuruKimlikTx.setIsyerindeCalismaSuresi(concatYilAy(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), iMap.getString("ISYERINDE_CALISMA_SURESI_AY")));
			birBasvuruKimlikTx.setIsyeriVergiDaireKodu(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
			birBasvuruKimlikTx.setIsyeriVergiIlKodu(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			birBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
			birBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
			birBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO") != null ? iMap.getString("KIMLIK_SERI_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS") != null ? iMap.getString("KIMLIK_SERI_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO") != null ? iMap.getString("KIMLIK_SIRA_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS") != null ? iMap.getString("KIMLIK_SIRA_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));

			birBasvuruKimlikTx.setMenkulGmenkulGeliri(iMap.getBigDecimal("GMENKUL_GELIR"));
			birBasvuruKimlikTx.setMeslekKod(iMap.getString("MESLEK"));
			// birBasvuruKimlikTx.setMusteriNo(new BigDecimal(0)); //TODO sonradan yapilacak
			birBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
			birBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
			birBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));

			// birBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
			if (iMap.get("NUFUS_VERILIS_TARIHI") != null && iMap.getString("NUFUS_VERILIS_TARIHI").compareTo("") != 0) {
				birBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
			}
			else {
				birBasvuruKimlikTx.setNufusVerTar(null);
			}

			birBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
			birBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
			birBasvuruKimlikTx.setOncekiSoyad(iMap.getString("ONCEKI_SOYADI"));
			birBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
			birBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			birBasvuruKimlikTx.setEsTckn(iMap.getString("ES_TCKN"));
			birBasvuruKimlikTx.setUnvanKod(iMap.getString("UNVANI"));
			birBasvuruKimlikTx.setPttUnvanKod(iMap.getString("PTT_UNVAN_KOD"));
			birBasvuruKimlikTx.setUyrukKod("TR");
			birBasvuruKimlikTx.setIsyeriVergiNo(iMap.getString("ISYERI_VERGI_NO"));
			if (iMap.getBoolean("YAZISMA_ADRESI_EV")) {
				birBasvuruKimlikTx.setYazismaAdresKod("E");
			}
			else if (iMap.getBoolean("YAZISMA_ADRESI_IS")) {
				birBasvuruKimlikTx.setYazismaAdresKod("I");
			}

			birBasvuruKimlikTx.setSigortaliMi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("SIGORTALI_MI")));
			birBasvuruKimlikTx.setUlasimKartNo(iMap.getString("ULASIM_KART_NO"));
			birBasvuruKimlikTx.setKimlikKayitNo(iMap.getString("KIMLIK_KAYIT_NO"));

			if (StringUtils.isNotBlank(iMap.getString("KART1")) && StringUtils.isNotBlank(iMap.getString("KART2"))) {
				birBasvuruKimlikTx.setKimlik2KartIlk6(iMap.getString("KART1").concat(iMap.getString("KART2")));
			}
			birBasvuruKimlikTx.setKimlik2KartSon4(iMap.getString("KART3"));
			birBasvuruKimlikTx.setKimlik2Tip(iMap.getString("IKINCI_KIMLIK_TURU"));
			birBasvuruKimlikTx.setKampanyaBilgi(iMap.getString("KAMPANYA_BILGI"));

			session.saveOrUpdate(birBasvuruKimlikTx);

			boolean evliMi = iMap.getString("MEDENI_HAL").equals("1") && StringUtils.isNotBlank(iMap.getString("ES_TCKN"));
			if (evliMi) {
				GMServiceExecuter.execute("BNSPR_TRN3171_SAVE_ES_BILGILERI", iMap);
			}

			List<?> silTeminatList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayTeminatlar = silTeminatList.toArray();
			for (Object element : arrayTeminatlar) {
				silTeminatList.remove(element);
				session.delete(element);
			}
			session.flush();

			String tableName = "TEMINAT_TABLE";
			List<?> teminatList = (List<?>) iMap.get(tableName);

			if (teminatList != null) {
				for (int i = 0; i < teminatList.size(); i++) {
					if (iMap.getString(tableName, i, "TEMINAT") == null || iMap.getString(tableName, i, "TEMINAT").isEmpty()) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "Teminat Adini");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.teminatKod", iMap.getString(tableName, i, "TEMINAT"))).uniqueResult();

					birBasvuruTeminatTx = new BirBasvuruTeminatTx();
					BirBasvuruTeminatTxId teminatId = new BirBasvuruTeminatTxId();
					teminatId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					teminatId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					teminatId.setTeminatKod(iMap.getString(tableName, i, "TEMINAT"));
					birBasvuruTeminatTx.setId(teminatId);

					birBasvuruTeminatTx.setTeminatAdedi(iMap.getBigDecimal(tableName, i, "ADET"));
					// birBasvuruTeminatTx.setTeminatTipi(iMap.getString(tableName, i, "TEMINAT_ADI"));

					session.saveOrUpdate(birBasvuruTeminatTx);
				}
			}
			session.flush();

			String tableName2 = "SIGORTA_TABLE";
			List<?> sigortaList = (List<?>) iMap.get(tableName2);

			if (sigortaList != null) {
				for (int i = 0; i < sigortaList.size(); i++) {
					if (iMap.getString(tableName2, i, "SIGORTA_SATIS_URUN") == null || iMap.getString(tableName2, i, "SIGORTA_SATIS_URUN").isEmpty()) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "Sigorta Satis Urun");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirBasvuruSigortaSatisTx birBasvuruSigortaSatisTx = (BirBasvuruSigortaSatisTx) session.createCriteria(BirBasvuruSigortaSatisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.sigortaUrunNo", iMap.getBigDecimal(tableName2, i, "SIGORTA_SATIS_URUN"))).uniqueResult();

					if (birBasvuruSigortaSatisTx == null)
						birBasvuruSigortaSatisTx = new BirBasvuruSigortaSatisTx();
					BirBasvuruSigortaSatisTxId id = new BirBasvuruSigortaSatisTxId();

					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					id.setSigortaUrunNo(iMap.getBigDecimal(tableName2, i, "SIGORTA_SATIS_URUN"));
					birBasvuruSigortaSatisTx.setId(id);
					birBasvuruSigortaSatisTx.setSigortaPrimi(iMap.getBigDecimal(tableName2, i, "PRIM"));

					session.saveOrUpdate(birBasvuruSigortaSatisTx);
				}
			}
			session.flush();

			List<?> silGorusList = session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayGorusler = silGorusList.toArray();
			for (Object element : arrayGorusler) {
				silGorusList.remove(element);
				session.delete(element);
			}
			session.flush();

			String gorusTable = "GORUS";
			List<?> gorusList = (List<?>) iMap.get(gorusTable);
			if (gorusList != null) {
				for (int i = 0; i < gorusList.size(); i++) {
					BirBasvuruGorusTx birBasvuruGorusTx = new BirBasvuruGorusTx();
					BirBasvuruGorusTxId birBasvuruGorusTxId = new BirBasvuruGorusTxId();

					birBasvuruGorusTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruGorusTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birBasvuruGorusTxId.setGorusKod(iMap.getString(gorusTable, i, "BASVURU_GORUS"));
					birBasvuruGorusTx.setId(birBasvuruGorusTxId);
					if (iMap.getString(gorusTable, i, "SEC").equals("1") || iMap.getBoolean(gorusTable, i, "SEC"))
						birBasvuruGorusTx.setEH("E");
					else
						birBasvuruGorusTx.setEH("H");
					session.save(birBasvuruGorusTx);
				}
			}
			session.flush();

			iMap.put("TRX_NAME", "3171");
			GMMap oMap = new GMMap();
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

			iMap.put("MESSAGE_NO", new BigDecimal(1156));
			oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_SAVE_TEMP")
	public static Map<?, ?> saveTempTRN3171(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI").trim());
			}

			BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.get(BirBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birBasvuruTx == null)
				birBasvuruTx = new BirBasvuruTx();

			birBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruTx.setAdcOwner(iMap.getString("ADC_OWNER"));
			birBasvuruTx.setSatisPersoneli(iMap.getBigDecimal("PERSONEL"));
			birBasvuruTx.setEveTeslimatliUrun(iMap.getString("EVE_TESLIM_URUN"));
			birBasvuruTx.setUrunTeslimTarihi(iMap.getDate("TESLIMAT_TARIHI"));
			birBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			if (!(birBasvuruTx.getRecursiveFlag() != null && birBasvuruTx.getRecursiveFlag().compareTo(BigDecimal.ONE) == 0)) {
				birBasvuruTx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAFI"));
				if (iMap.getString("SERBEST_KATKI_PAYI") != null && iMap.getString("SERBEST_KATKI_PAYI") != "H") {
					birBasvuruTx.setSerbestKatkiPayi(iMap.getBigDecimal("KATILIM_BEDELI"));
				}
				else {
					birBasvuruTx.setSerbestKatkiPayi(null);
				}
			}
			birBasvuruTx.setDovizKodu(iMap.getString("DOVIZ_KOD"));
			if (iMap.getString("DURUM_KODU") == null || iMap.getString("DURUM_KODU").isEmpty())
				birBasvuruTx.setDurumKodu("BASVURU");
			else
				birBasvuruTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
				birBasvuruTx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));
				birBasvuruTx.setKrediAltTur(null);
				birBasvuruTx.setKrediAltTur2(null);
				if (!(birBasvuruTx.getRecursiveFlag() != null && birBasvuruTx.getRecursiveFlag().compareTo(BigDecimal.ONE) == 0)) {
					birBasvuruTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
				}
			}
			else {
				birBasvuruTx.setKampKod(null);
				birBasvuruTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birBasvuruTx.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				birBasvuruTx.setKampKnlKod(null);
			}

			birBasvuruTx.setKanalKodu(iMap.getString("KANAL_KOD"));
			birBasvuruTx.setKrediTur(iMap.getBigDecimal("KRD_TUR_KOD"));
			birBasvuruTx.setOdemeTipKod(iMap.getBigDecimal("ODEME_TIPI"));
			birBasvuruTx.setOdemeTipOran(iMap.getBigDecimal("ODEME_ORANI"));
			birBasvuruTx.setOdemeTipPeriyod(iMap.getBigDecimal("ODEME_PERIYODU"));
			birBasvuruTx.setOdemeTipTut(iMap.getBigDecimal("ODEME_TUTARI"));
			birBasvuruTx.setOdemeTipVade(iMap.getBigDecimal("ODEME_VADESI"));
			birBasvuruTx.setAksiyonKod("");
			birBasvuruTx.setSaticiKod(iMap.getBigDecimal("KANAL_ALT_KOD"));
			birBasvuruTx.setQrKaynakKod(iMap.getBigDecimal("QR_KAYNAK_KOD"));

			birBasvuruTx.setTutar(iMap.getBigDecimal("HERSEY_DAHIL_TUTAR", iMap.getBigDecimal("TUTAR")));
			birBasvuruTx.setVade(iMap.getBigDecimal("VADE"));
			birBasvuruTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			if (iMap.getString("DOSYA_MASRAF_TIPI") != null && iMap.getString("DOSYA_MASRAF_TIPI") != "Y") {
				birBasvuruTx.setSozlesmeFaizi(iMap.getBigDecimal("SOZLESME_FAIZI"));
			}
			else {
				birBasvuruTx.setSozlesmeFaizi(null);
			}
			birBasvuruTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
			birBasvuruTx.setGorus(iMap.getString("DIGER_GORUS"));
			birBasvuruTx.setIslemSonrasiDurumKodu("NBSM");
			birBasvuruTx.setSubeKod(iMap.getString("SUBE_KOD"));
			birBasvuruTx.setHesapNo(iMap.getString("HESAP_NO"));
			birBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));
			birBasvuruTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			if (iMap.containsKey("BAGLI_SUBE_KOD")) {
				birBasvuruTx.setBagliSubeKodu(iMap.getString("BAGLI_SUBE_KOD"));
			}
			birBasvuruTx.setPttMaasAlinanKurum(iMap.getString("MAAS_ALINAN_KURUM"));

			if (iMap.get("ONCEKI_MAAS_ODEME_TARIHI") != null && iMap.getString("ONCEKI_MAAS_ODEME_TARIHI").compareTo("") != 0 && iMap.getString("ONCEKI_MAAS_ODEME_TARIHI").compareTo("00.00.0000") != 0) {
				birBasvuruTx.setPttOncekiMaasOdemeTarihi(iMap.getDate("ONCEKI_MAAS_ODEME_TARIHI"));
			}
			birBasvuruTx.setPttSgkMaasTutar(iMap.getBigDecimal("MAAS_TUTARI"));

			if (iMap.get("SON_MAAS_TARIHI") != null && iMap.getString("SON_MAAS_TARIHI").compareTo("") != 0) {
				birBasvuruTx.setPttSonMaasTarihi(iMap.getDate("SON_MAAS_TARIHI"));
			}

			birBasvuruTx.setPttMaasTarihSikligi(iMap.getBigDecimal("MAAS_TARIH_SIKLIGI"));
			birBasvuruTx.setApsYapildimi(iMap.getString("APS_YAPILDIMI"));
			birBasvuruTx.setApsBilgileriUyumlumu(iMap.getString("ADRES_BILGILERI_UYUMLUMU"));
			birBasvuruTx.setPttKpsBilgileriUyumlumu(iMap.getString("KIMLIK_BILGILERI_UYUMLUMU"));

			if (iMap.containsKey("POSTA_CEK_HESABI")) {
				birBasvuruTx.setPttPostaCekiHesabi(iMap.getBigDecimal("POSTA_CEK_HESABI"));
			}
			if (iMap.containsKey("MAAS_PTT_DENMI")) {
				birBasvuruTx.setPttMaasPttDenmi(iMap.getString("MAAS_PTT_DENMI"));
			}
			if (iMap.containsKey("EMEKLI_MAAS_EVDENMI")) {
				birBasvuruTx.setPttMaasEvdenMi(iMap.getString("EMEKLI_MAAS_EVDENMI"));
			}
			if (iMap.containsKey("TAHSIS_NUMARASI")) {
				birBasvuruTx.setPttTahsisNumarasi(iMap.getString("TAHSIS_NUMARASI"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_IL")) {
				birBasvuruTx.setPttSubeIli(iMap.getString("ISLEMIN_YAPILDIGI_IL"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_MERKEZ")) {
				birBasvuruTx.setPttIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_SUBE")) {
				birBasvuruTx.setPttIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
			}
			if (iMap.getString("KANAL_KOD") != null && iMap.getString("KANAL_KOD").compareTo("7") == 0) {
				birBasvuruTx.setIlkTaksitYontem(iMap.getString("PTT_ILK_TAKSIT_YONTEM"));
				birBasvuruTx.setGecikmeGunSayisi(iMap.getBigDecimal("GECIKME_GUN_SAYISI"));
			}
			birBasvuruTx.setBasvuruTutari(iMap.getBigDecimal("TUTAR"));
			birBasvuruTx.setGecTeslimatNeden(iMap.getString("GEC_TESLIMAT_NEDEN"));
			birBasvuruTx.setHesapKapansinMi(iMap.getString("HESAP_KAPANSIN_MI"));
			birBasvuruTx.setKazanimTur(iMap.getString("KAZANIM_TUR"));
			birBasvuruTx.setWebSatisKanali(iMap.getString("WEB_SATIS_KANALI"));
			birBasvuruTx.setFaizsizFinansman(iMap.getString("FAIZSIZ_FINANSMAN"));
			birBasvuruTx.setDebitKartTalep(iMap.getString("DEBIT_KART_TALEP"));
			
			/** PY-16299 PTT SMS */
			if (iMap.containsKey("BASVURU_TARIHI")) {
				birBasvuruTx.setBasvuruTarihi(iMap.getDate("BASVURU_TARIHI"));
			}
			if (iMap.containsKey("PTT_TAHSIS_NUMARASI")) {
				birBasvuruTx.setPttTahsisNumarasi(iMap.getString("PTT_TAHSIS_NUMARASI"));
			}
			if (iMap.containsKey("KURYE_SECIMI")) {
				birBasvuruTx.setKuryeSecimi(iMap.getString("KURYE_SECIMI"));
			}
			if (iMap.containsKey("ONAY_TUTAR")) {
				birBasvuruTx.setOnayTutar(iMap.getBigDecimal("ONAY_TUTAR"));
			}

			// birBasvuruTx.setDurumKodu("BASVURU");
			session.saveOrUpdate(birBasvuruTx);

			BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birBasvuruKimlikTx == null) {
				birBasvuruKimlikTx = new BirBasvuruKimlikTx();
				birBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			birBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruKimlikTx.setAd(iMap.getString("ADI"));
			birBasvuruKimlikTx.setAdresteFaaliyetSuresi(concatYilAy(iMap.getString("FAALIYET_SURESI_YIL"), iMap.getString("FAALIYET_SURESI_AY"))); // ay yil birlestir
			birBasvuruKimlikTx.setAdresteOturmaSuresi(concatYilAy(iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL"), iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY"))); //
			birBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
			birBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
			birBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
			birBasvuruKimlikTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
			birBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
			birBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
			birBasvuruKimlikTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			birBasvuruKimlikTx.setCepTelAlanKodu(iMap.getString("CEP_TEL_KOD"));
			birBasvuruKimlikTx.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			birBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
			birBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
			birBasvuruKimlikTx.setDigerGelir(iMap.getBigDecimal("DIGER_GELIR"));
			birBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
			birBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
			birBasvuruKimlikTx.setEgitimDurumKod(iMap.getString("OGRENIM_DURUMU"));
			if (iMap.getString("EMAIL1") != null && !iMap.getString("EMAIL1").isEmpty() && iMap.getString("EMAIL2") != null && !iMap.getString("EMAIL2").isEmpty()) {
				birBasvuruKimlikTx.setEMail(iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));
			}
			else {
				birBasvuruKimlikTx.setEMail("");
			}
			birBasvuruKimlikTx.setEsGeliri(iMap.getBigDecimal("ES_GELIRI") == null ? BigDecimal.ZERO : iMap.getBigDecimal("ES_GELIRI"));
			if (iMap.getString("EV_ADRESI") != null) {
				birBasvuruKimlikTx.setEvAdres(iMap.getString("EV_ADRESI").trim());
			}
			else {
				birBasvuruKimlikTx.setEvAdres("");
			}
			birBasvuruKimlikTx.setEvAdrIlceKod(iMap.getString("EV_ILCE"));
			birBasvuruKimlikTx.setEvAdrIlKod(iMap.getString("EV_IL"));
			birBasvuruKimlikTx.setEvAdrUlkeKod("TR");
			birBasvuruKimlikTx.setEvPostakod(iMap.getString("EV_POSTA_KODU"));
			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				birBasvuruKimlikTx.setEvTelAlan(iMap.getString("EV_TEL_KOD"));
				birBasvuruKimlikTx.setEvTelNo(iMap.getString("EV_TEL_NO"));
			}
			else {
				birBasvuruKimlikTx.setEvTelAlan("");
				birBasvuruKimlikTx.setEvTelNo("");
			}
			birBasvuruKimlikTx.setIkametDurumKod(iMap.getString("IKAMET_DURUMU"));
			birBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
			if (iMap.getString("IS_ADRESI") != null) {
				birBasvuruKimlikTx.setIsAdres(iMap.getString("IS_ADRESI").trim());
			}
			else {
				birBasvuruKimlikTx.setIsAdres("");
			}
			birBasvuruKimlikTx.setIsAdrIlceKod(iMap.getString("IS_ILCE"));
			birBasvuruKimlikTx.setIsAdrIlKod(iMap.getString("IS_IL"));
			birBasvuruKimlikTx.setIsAdrUlkeKod("TR");
			birBasvuruKimlikTx.setIsPostakod(iMap.getString("IS_POSTA_KODU"));
			if (iMap.getString("IS_TEL_NO") != null && !iMap.getString("IS_TEL_NO").isEmpty()) {
				birBasvuruKimlikTx.setIsTelAlan(iMap.getString("IS_TEL_KOD"));
				birBasvuruKimlikTx.setIsTelNo(iMap.getString("IS_TEL_NO"));
				birBasvuruKimlikTx.setIsTelDahili(iMap.getString("IS_TEL_DAHILI"));
			}
			else {
				birBasvuruKimlikTx.setIsTelAlan(iMap.getString(""));
				birBasvuruKimlikTx.setIsTelNo(iMap.getString(""));
				birBasvuruKimlikTx.setIsTelDahili(iMap.getString(""));
			}
			if (iMap.getString("ISYERI_ADI") != null) {
				birBasvuruKimlikTx.setIsyeriAdi(iMap.getString("ISYERI_ADI").trim());
			}
			else {
				birBasvuruKimlikTx.setIsyeriAdi("");
			}
			birBasvuruKimlikTx.setIsyeriFaalKonuKod(iMap.getString("ISYERI_FAALIYET_ALANI"));
			birBasvuruKimlikTx.setIsyeriMulkiyetKod(iMap.getString("ISYERI_MULKIYET"));
			birBasvuruKimlikTx.setIsyerindeCalismaSuresi(concatYilAy(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), iMap.getString("ISYERINDE_CALISMA_SURESI_AY")));
			birBasvuruKimlikTx.setIsyeriVergiDaireKodu(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
			birBasvuruKimlikTx.setIsyeriVergiIlKodu(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			birBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
			birBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
			birBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO") != null ? iMap.getString("KIMLIK_SERI_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS") != null ? iMap.getString("KIMLIK_SERI_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO") != null ? iMap.getString("KIMLIK_SIRA_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS") != null ? iMap.getString("KIMLIK_SIRA_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
			birBasvuruKimlikTx.setMenkulGmenkulGeliri(iMap.getBigDecimal("GMENKUL_GELIR"));
			birBasvuruKimlikTx.setMeslekKod(iMap.getString("MESLEK"));
			// birBasvuruKimlikTx.setMusteriNo(new BigDecimal(0)); //TODO sonradan yapilacak
			birBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
			birBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
			birBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));

			// birBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
			if (iMap.get("NUFUS_VERILIS_TARIHI") != null && iMap.getString("NUFUS_VERILIS_TARIHI").compareTo("") != 0) {
				birBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
			}
			else {
				birBasvuruKimlikTx.setNufusVerTar(null);
			}

			birBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
			birBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
			birBasvuruKimlikTx.setOncekiSoyad(iMap.getString("ONCEKI_SOYADI"));
			birBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
			birBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			birBasvuruKimlikTx.setEsTckn(iMap.getString("ES_TCKN"));
			birBasvuruKimlikTx.setUnvanKod(iMap.getString("UNVANI"));
			birBasvuruKimlikTx.setPttUnvanKod(iMap.getString("PTT_UNVAN_KOD"));
			birBasvuruKimlikTx.setUyrukKod("TR");
			birBasvuruKimlikTx.setIsyeriVergiNo(iMap.getString("ISYERI_VERGI_NO"));
			boolean isYazismaAdresEv = iMap.getBoolean("YAZISMA_ADRESI_EV");
			boolean isYazismaAdresIs = iMap.getBoolean("YAZISMA_ADRESI_IS");
			String yazismaAdresKod = (isYazismaAdresEv) ? "E" : ((isYazismaAdresIs) ? "I" : "");
			birBasvuruKimlikTx.setYazismaAdresKod(yazismaAdresKod);
			birBasvuruKimlikTx.setSigortaliMi(iMap.getBoolean("SIGORTALI_MI") ? "E" : "H");
			birBasvuruKimlikTx.setUlasimKartNo(iMap.getString("ULASIM_KART_NO"));
			birBasvuruKimlikTx.setKimlikKayitNo(iMap.getString("KIMLIK_KAYIT_NO"));

			if (iMap.getBoolean("MUH_ADR_E"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("E");
			else if (iMap.getBoolean("MUH_ADR_H"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("H");
			else if (iMap.getBoolean("MUH_ADR_B"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("B");

			if (iMap.getBoolean("ADR_AYNI_E")) {
				birBasvuruKimlikTx.setTeslimatAdresAyniEh("E");
			}
			else if (iMap.getBoolean("ADR_AYNI_H")) {
				birBasvuruKimlikTx.setTeslimatAdresAyniEh("H");
				birBasvuruKimlikTx.setTeslimatAdresi(iMap.getString("TESLIMAT_ADRES"));
				birBasvuruKimlikTx.setTeslimatAdrIlKod(iMap.getString("TESLIMAT_IL"));
				birBasvuruKimlikTx.setTeslimatAdrIlceKod(iMap.getString("TESLIMAT_ILCE"));
				birBasvuruKimlikTx.setTeslimatPostakod(iMap.getString("TESLIMAT_POSTA_KODU"));
				birBasvuruKimlikTx.setTeslimatKisiTckn(iMap.getString("TESLIMAT_TCKN"));
				birBasvuruKimlikTx.setTeslimatFarkliOlmaNedeni(iMap.getString("TESLIMAT_FARKLI_OLMA_NEDENI"));
			}
			birBasvuruKimlikTx.setTeslimatKisi(iMap.getString("TESLIMAT_URUN_KIME"));
			if (StringUtils.isNotBlank(iMap.getString("KART1")) && StringUtils.isNotBlank(iMap.getString("KART2"))) {
				birBasvuruKimlikTx.setKimlik2KartIlk6(iMap.getString("KART1").concat(iMap.getString("KART2")));
			}
			birBasvuruKimlikTx.setKimlik2KartSon4(iMap.getString("KART3"));
			birBasvuruKimlikTx.setKimlik2Tip(iMap.getString("IKINCI_KIMLIK_TURU"));
			birBasvuruKimlikTx.setTeyitEdilenGelir(iMap.get("TEYIT_EDILEN_GELIR") != null ? iMap.getBigDecimal("TEYIT_EDILEN_GELIR") : new BigDecimal(0));
			birBasvuruKimlikTx.setKampanyaBilgi(iMap.getString("KAMPANYA_BILGI"));
			session.saveOrUpdate(birBasvuruKimlikTx);

			GMMap sMap = new GMMap();

			sMap.put("KANAL_KODU", iMap.getString("KANAL_KOD"));
			sMap.put("KANAL_ALT_KODU", iMap.getString("KANAL_ALT_KOD"));
			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", iMap.getString("CINSIYET"));
			sMap.putAll(iMap);
			sMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sMap.put("ISIM", sMap.get("ADI"));
			sMap.put("IKINCI_ISIM", sMap.get("IKINCI_ADI"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", sMap.get("CINSIYET"));
			sMap.put("MEDENI_HAL_KOD", sMap.get("MEDENI_HAL"));
			sMap.put("AILE_SIRA_NO", sMap.get("NUFUS_AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("NUFUS_CILT_NO"));
			sMap.put("SIRA_NO", sMap.get("NUFUS_SIRA_NO"));
			sMap.put("KIZLIK_SOYADI", sMap.get("ONCEKI_SOYADI"));
			sMap.put("MESLEK_KOD", sMap.get("MESLEK"));
			sMap.put("EGITIM_KOD", sMap.get("OGRENIM_DURUMU"));
			sMap.put("VERILDIGI_YER", sMap.get("NUF_VERILDIGI_YER"));
			sMap.put("VERILDIGI_TARIH", sMap.get("NUFUS_VERILIS_TARIHI"));
			sMap.put("EV_POSTA_KOD", sMap.get("EV_POSTA_KODU"));
			sMap.put("EV_ADRES", sMap.get("EV_ADRESI"));
			sMap.put("IS_POSTA_KOD", sMap.get("IS_POSTA_KODU"));
			sMap.put("IS_ADRES", sMap.get("IS_ADRESI"));
			sMap.put("MAHALLE_KOY", sMap.get("NUFUS_MAHALLE"));
			sMap.put("IL_KOD", sMap.get("NUFUS_IL_KOD"));
			sMap.put("ILCE_KOD", sMap.get("NUFUS_ILCE_KOD"));

			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}
			// Musteri degilse yaratilir.
			GMMap outMap = new GMMap();
			outMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_CREATE_KONTAKT_MUSTERI", sMap));

			if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
				iMap.put("KAMP_KOD", iMap.getBigDecimal("URUN_KAMP_KOD"));
				iMap.put("MUSTERI_NO", outMap.getBigDecimal("MUSTERI_NO"));
				GMServiceExecuter.execute("BNSPR_TRN3171_YENIDEN_YAPILANDIRMA", iMap);
			}

			// Es ile ilgili islemler
			boolean evliMi = iMap.getString("MEDENI_HAL").equals("1") && StringUtils.isNotBlank(iMap.getString("ES_TCKN"));
			if (evliMi) {
				iMap.put("MUSTERI_YARATMA_TX_NO", outMap.getBigDecimal("MUSTERI_YARATMA_TX_NO"));
				iMap.put("MUSTERI_NO", outMap.getBigDecimal("MUSTERI_NO"));
				GMServiceExecuter.execute("BNSPR_TRN3171_SAVE_ES_BILGILERI", iMap);
			}

			List<?> silTeminatList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayTeminatlar = silTeminatList.toArray();
			for (Object element : arrayTeminatlar) {
				silTeminatList.remove(element);
				session.delete(element);
			}
			session.flush();

			String tableName = "TEMINAT_TABLE";
			List<?> teminatList = (List<?>) iMap.get(tableName);

			if (teminatList != null) {
				for (int i = 0; i < teminatList.size(); i++) {
					if (iMap.getString(tableName, i, "TEMINAT") == null || iMap.getString(tableName, i, "TEMINAT").isEmpty()) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "Teminat Adi");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.teminatKod", iMap.getString(tableName, i, "TEMINAT"))).uniqueResult();

					birBasvuruTeminatTx = new BirBasvuruTeminatTx();
					BirBasvuruTeminatTxId teminatId = new BirBasvuruTeminatTxId();
					teminatId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					teminatId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					teminatId.setTeminatKod(iMap.getString(tableName, i, "TEMINAT"));
					birBasvuruTeminatTx.setId(teminatId);

					birBasvuruTeminatTx.setTeminatAdedi(iMap.getBigDecimal(tableName, i, "ADET"));

					session.saveOrUpdate(birBasvuruTeminatTx);

					session.flush();
				}
			}
			String tableName2 = "SIGORTA_TABLE";
			List<?> sigortaList = (List<?>) iMap.get(tableName2);

			if (sigortaList != null) {
				for (int i = 0; i < sigortaList.size(); i++) {
					if (iMap.getString(tableName2, i, "SIGORTA_SATIS_URUN") == null || iMap.getString(tableName2, i, "SIGORTA_SATIS_URUN").isEmpty()) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "Sigorta Satis Urun");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirBasvuruSigortaSatisTx birBasvuruSigortaSatisTx = (BirBasvuruSigortaSatisTx) session.createCriteria(BirBasvuruSigortaSatisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.sigortaUrunNo", iMap.getBigDecimal(tableName2, i, "SIGORTA_SATIS_URUN"))).uniqueResult();

					if (birBasvuruSigortaSatisTx == null)
						birBasvuruSigortaSatisTx = new BirBasvuruSigortaSatisTx();
					BirBasvuruSigortaSatisTxId id = new BirBasvuruSigortaSatisTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					id.setSigortaUrunNo(iMap.getBigDecimal(tableName2, i, "SIGORTA_SATIS_URUN"));
					birBasvuruSigortaSatisTx.setId(id);
					birBasvuruSigortaSatisTx.setSigortaPrimi(iMap.getBigDecimal(tableName2, i, "PRIM"));

					session.saveOrUpdate(birBasvuruSigortaSatisTx);
				}
				session.flush();
			}

			List<?> silGorusList = session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayGorusler = silGorusList.toArray();
			for (Object element : arrayGorusler) {
				silGorusList.remove(element);
				session.delete(element);
			}
			session.flush();

			String gorusTable = "GORUS";
			List<?> gorusList = (List<?>) iMap.get(gorusTable);
			if (gorusList != null) {
				for (int i = 0; i < gorusList.size(); i++) {
					BirBasvuruGorusTx birBasvuruGorusTx = new BirBasvuruGorusTx();
					BirBasvuruGorusTxId birBasvuruGorusTxId = new BirBasvuruGorusTxId();

					birBasvuruGorusTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruGorusTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birBasvuruGorusTxId.setGorusKod(iMap.getString(gorusTable, i, "BASVURU_GORUS"));
					birBasvuruGorusTx.setId(birBasvuruGorusTxId);
					if (iMap.getString(gorusTable, i, "SEC").equals("1") || iMap.getBoolean(gorusTable, i, "SEC"))
						birBasvuruGorusTx.setEH("E");
					else
						birBasvuruGorusTx.setEH("H");
					session.save(birBasvuruGorusTx);
				}
				session.flush();
			}

			// Tasit Kredisinde Arac bilgilerini kaydediyoruz.
			if (birBasvuruTx.getKrediTur().compareTo(CreditTypes.TASIT.getCreditCode()) == 0) {
				BirBasvuruTasitTx birBasvuruTasit = new BirBasvuruTasitTx();
				birBasvuruTasit.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birBasvuruTasit.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				birBasvuruTasit.setAracKod(iMap.getBigDecimal("ARAC_KOD"));
				birBasvuruTasit.setMarka(iMap.getString("MARKA"));
				birBasvuruTasit.setModelYil(iMap.getString("MODEL_YIL"));
				birBasvuruTasit.setModel(iMap.getString("MODEL"));
				birBasvuruTasit.setKullanimAmac(iMap.getString("KULLANIM_AMAC"));
				birBasvuruTasit.setKaskoDeger(iMap.getBigDecimal("KASKO_DEGER"));
				birBasvuruTasit.setNoterDeger(iMap.getBigDecimal("NOTER_DEGER"));
				birBasvuruTasit.setPlaka(iMap.getString("PLAKA"));
				birBasvuruTasit.setRuhsatTarih(iMap.getDate("RUHSAT_TARIH"));
				birBasvuruTasit.setSicilNo(iMap.getString("SICIL_NO"));
				birBasvuruTasit.setMotorNo(iMap.getString("MOTOR_NO"));
				birBasvuruTasit.setSasiNo(ConsumerLoanCommonServices.nvl(iMap.getString("SASI_NO"), "").trim());
				birBasvuruTasit.setTrafikSubesi(iMap.getString("ARAC_TRAFIK_SUBE"));
				birBasvuruTasit.setAracTipi(iMap.getString("ARAC_TIPI"));
				birBasvuruTasit.setRuhsatTcknVkn(iMap.getString("RUHSAT_TCKN_VKN"));
				birBasvuruTasit.setKm(iMap.getBigDecimal("KM"));
				
				try {
					iMap.put("PARAMETRE", "TASIT_REHIN_MASRAFI");
					birBasvuruTasit.setRehinMasrafi(new BigDecimal((String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER")));
				}
				catch (Exception e) {
					birBasvuruTasit.setRehinMasrafi(BigDecimal.ZERO);
				}
				
				session.saveOrUpdate(birBasvuruTasit);
				session.flush();
			}

			/** Ek paket varsa tabloyu doldur **/
			if ("E".equals(iMap.getString("EK_IHTIYAC")) && iMap.get("KAMP_KOD") != null) {
				BirBasvuruPaketTx birBasvuruPaketTx = (BirBasvuruPaketTx) session.createCriteria(BirBasvuruPaketTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

				if (birBasvuruPaketTx == null)
					birBasvuruPaketTx = new BirBasvuruPaketTx();
				birBasvuruPaketTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birBasvuruPaketTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				BirKampanya birKampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", iMap.getBigDecimal("KAMP_KOD"))).uniqueResult();
				if (birKampanya.getEkPaketKod() != null) {
					GMMap pMap = ConsumerLoanCommonServices.getParamTextLists("BIR_BASVURU_PAKET_TANIM", "PARAM_TABLE");
					for (int i = 0; i < pMap.getSize("PARAM_TABLE"); i++) {
						if (birKampanya.getEkPaketKod().toString().equals(pMap.getString("PARAM_TABLE", i, "CODE"))) {
							birBasvuruPaketTx.setTutar(pMap.getBigDecimal("PARAM_TABLE", i, "KEY2"));
							birBasvuruPaketTx.setPaketTuru(birKampanya.getEkPaketKod().toString());
						}
					}
					session.saveOrUpdate(birBasvuruPaketTx);
					session.flush();
				}
			}
			else {
				List<?> silPaketList = session.createCriteria(BirBasvuruPaket.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				Object[] arrayPaketler = silPaketList.toArray();
				for (Object element : arrayPaketler) {
					silPaketList.remove(element);
					session.delete(element);
				}
				session.flush();
			}

			/** Kdh basvuru bilgileri **/
			if (new BigDecimal(5).equals(iMap.getBigDecimal("KRD_TUR_KOD"))) {
				KmhBireyselBasvuruTx kmhBireyselBasvuruTx = (KmhBireyselBasvuruTx) session.createCriteria(KmhBireyselBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
				if (kmhBireyselBasvuruTx == null) {
					kmhBireyselBasvuruTx = new KmhBireyselBasvuruTx();
					kmhBireyselBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				}
				kmhBireyselBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				kmhBireyselBasvuruTx.setKmhTurKod(iMap.getBigDecimal("KMH_TUR_KOD"));
				kmhBireyselBasvuruTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				kmhBireyselBasvuruTx.setEkstreBasimKodu(iMap.getString("KMH_EKSTRE_BASIM_KODU"));
				kmhBireyselBasvuruTx.setIliskiliBasvuruNo(iMap.getBigDecimal("ILISKILI_BASVURU_NO"));
				kmhBireyselBasvuruTx.setOtomatikLimitArtis(iMap.getString("OTOMATIK_LIMIT_ARTIS"));
				kmhBireyselBasvuruTx.setKrediKartTalimat(iMap.getString("KREDI_KART_TALIMAT"));
				kmhBireyselBasvuruTx.setKrediOdemeTalimat(iMap.getString("KREDI_ODEME_TALIMAT"));
				kmhBireyselBasvuruTx.setSigortaOdemeTalimat(iMap.getString("SIGORTA_ODEME_TALIMAT"));
				kmhBireyselBasvuruTx.setSubeKod(iMap.getBigDecimal("SUBE_KOD"));

				session.saveOrUpdate(kmhBireyselBasvuruTx);
				session.flush();
			}

			GMMap oMap = new GMMap();

			iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION_TEMP", iMap));

			oMap.put("MUSTERI_YARATMA_TX_NO", outMap.getBigDecimal("MUSTERI_YARATMA_TX_NO"));
			oMap.put("MUSTERI_NO", outMap.getBigDecimal("MUSTERI_NO"));
			oMap.put("EVLI_MI", evliMi);

			iMap.put("TABLE_NAME", "BIR_BASVURU_TX_LOG");
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap));

			BirBasvuruTxLog birBasvuruTxLog = (BirBasvuruTxLog) session.createCriteria(BirBasvuruTxLog.class).add(Restrictions.eq("id.logId", iMap.getBigDecimal("ID"))).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			if (birBasvuruTxLog == null) {
				birBasvuruTxLog = new BirBasvuruTxLog();
				BirBasvuruTxLogId logId = new BirBasvuruTxLogId();
				logId.setLogId(iMap.getBigDecimal("ID"));
				logId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				logId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				birBasvuruTxLog.setId(logId);
			}
			birBasvuruTxLog.setAd(iMap.getString("ADI"));
			birBasvuruTxLog.setAnneAdi(iMap.getString("ANNE_ADI"));
			birBasvuruTxLog.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
			birBasvuruTxLog.setBabaAd(iMap.getString("BABA_ADI"));
			birBasvuruTxLog.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			birBasvuruTxLog.setCinsiyet(iMap.getString("CINSIYET"));
			birBasvuruTxLog.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
			birBasvuruTxLog.setDogumYeri(iMap.getString("DOGUM_YERI"));
			birBasvuruTxLog.setSoyad(iMap.getString("SOYADI"));
			birBasvuruTxLog.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
			birBasvuruTxLog.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
			birBasvuruTxLog.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
			birBasvuruTxLog.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
			birBasvuruTxLog.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
			birBasvuruTxLog.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));

			// birBasvuruTxLog.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
			if (iMap.get("NUFUS_VERILIS_TARIHI") != null && iMap.getString("NUFUS_VERILIS_TARIHI").compareTo("") != 0) {
				birBasvuruTxLog.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
			}
			else {
				birBasvuruTxLog.setNufusVerTar(null);
			}

			birBasvuruTxLog.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
			birBasvuruTxLog.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
			birBasvuruTxLog.setKanalKodu(iMap.getString("KANAL_KOD"));
			birBasvuruTxLog.setKrediTur(iMap.getBigDecimal("KRD_TUR_KOD"));
			if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0)
				birBasvuruTxLog.setKampKod(iMap.getBigDecimal("URUN_KAMP_KOD"));
			else {
				birBasvuruTxLog.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birBasvuruTxLog.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
			}
			birBasvuruTxLog.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
			birBasvuruTxLog.setDovizKodu(iMap.getString("DOVIZ_KOD"));
			birBasvuruTxLog.setTutar(iMap.getBigDecimal("TUTAR"));
			birBasvuruTxLog.setVade(iMap.getBigDecimal("VADE"));
			birBasvuruTxLog.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
			birBasvuruTxLog.setSaticiKod(iMap.getBigDecimal("KANAL_ALT_KOD"));
			birBasvuruTxLog.setCepTelAlanKodu(iMap.getString("CEP_TEL_KOD"));
			birBasvuruTxLog.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			birBasvuruTxLog.setIkinciAd(iMap.getString("IKINCI_ADI"));
			birBasvuruTxLog.setOncekiSoyad(iMap.getString("ONCEKI_SOYADI"));
			birBasvuruTxLog.setMedeniHal(iMap.getString("MEDENI_HAL"));
			birBasvuruTxLog.setTcKimlikNo(iMap.getBigDecimal("TC_KIMLIK_NO"));
			birBasvuruTxLog.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
			birBasvuruTxLog.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
			birBasvuruTxLog.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO") != null ? iMap.getString("KIMLIK_SERI_NO").toUpperCase() : null);
			birBasvuruTxLog.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS") != null ? iMap.getString("KIMLIK_SERI_NO_KPS").toUpperCase() : null);
			birBasvuruTxLog.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO") != null ? iMap.getString("KIMLIK_SIRA_NO").toUpperCase() : null);
			birBasvuruTxLog.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS") != null ? iMap.getString("KIMLIK_SIRA_NO_KPS").toUpperCase() : null);
			birBasvuruTxLog.setKimlikKayitNo(iMap.getString("KIMLIK_KAYIT_NO"));
			birBasvuruTxLog.setBagliSubeKodu(birBasvuruTx.getBagliSubeKodu());
			session.saveOrUpdate(birBasvuruTxLog);
			session.flush();
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CONTROL")
	public static Map<?, ?> controlTRN3171(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		PreparedStatement pstmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI").trim());
			}

			BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.get(BirBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birBasvuruTx == null)
				birBasvuruTx = new BirBasvuruTx();

			birBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruTx.setAdcOwner(iMap.getString("ADC_OWNER"));
			birBasvuruTx.setSatisPersoneli(iMap.getBigDecimal("PERSONEL"));
			birBasvuruTx.setEveTeslimatliUrun(iMap.getString("EVE_TESLIM_URUN"));
			birBasvuruTx.setUrunTeslimTarihi(iMap.getDate("TESLIMAT_TARIHI"));
			birBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			if (!(birBasvuruTx.getRecursiveFlag() != null && birBasvuruTx.getRecursiveFlag().compareTo(BigDecimal.ONE) == 0)) {
				birBasvuruTx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAFI"));
				BigDecimal hdTutar = iMap.getBigDecimal("HERSEY_DAHIL_TUTAR");
				birBasvuruTx.setTutar((hdTutar != null) ? hdTutar : iMap.getBigDecimal("TUTAR"));
				birBasvuruTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
				if (iMap.getString("SERBEST_KATKI_PAYI") != null && iMap.getString("SERBEST_KATKI_PAYI") != "H") {
					birBasvuruTx.setSerbestKatkiPayi(iMap.getBigDecimal("KATILIM_BEDELI"));
				}
				else {
					birBasvuruTx.setSerbestKatkiPayi(null);
				}
			}
			birBasvuruTx.setDovizKodu(iMap.getString("DOVIZ_KOD"));
			birBasvuruTx.setDurumKodu(ConsumerLoanCommonServices.nvl(iMap.getString("DURUM_KODU"), "BASVURU"));
			if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
				birBasvuruTx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));
				birBasvuruTx.setKrediAltTur(null);
				birBasvuruTx.setKrediAltTur2(null);
				if (!(birBasvuruTx.getRecursiveFlag() != null && birBasvuruTx.getRecursiveFlag().compareTo(BigDecimal.ONE) == 0)) {
					birBasvuruTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
				}
			}
			else {
				birBasvuruTx.setKampKod(null);
				birBasvuruTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birBasvuruTx.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				birBasvuruTx.setKampKnlKod(null);
			}

			birBasvuruTx.setKanalKodu(iMap.getString("KANAL_KOD"));
			if (iMap.containsKey("BAGLI_SUBE_KOD")) {
				birBasvuruTx.setBagliSubeKodu(iMap.getString("BAGLI_SUBE_KOD"));
			}
			birBasvuruTx.setKrediTur(iMap.getBigDecimal("KRD_TUR_KOD"));
			birBasvuruTx.setOdemeTipKod(iMap.getBigDecimal("ODEME_TIPI"));
			birBasvuruTx.setOdemeTipOran(iMap.getBigDecimal("ODEME_ORANI"));
			birBasvuruTx.setOdemeTipPeriyod(iMap.getBigDecimal("ODEME_PERIYODU"));
			birBasvuruTx.setOdemeTipTut(iMap.getBigDecimal("ODEME_TUTARI"));
			birBasvuruTx.setOdemeTipVade(iMap.getBigDecimal("ODEME_VADESI"));
			birBasvuruTx.setAksiyonKod("");
			birBasvuruTx.setSaticiKod(iMap.getBigDecimal("KANAL_ALT_KOD"));

			birBasvuruTx.setVade(iMap.getBigDecimal("VADE"));
			if (iMap.getString("DOSYA_MASRAF_TIPI") != null && iMap.getString("DOSYA_MASRAF_TIPI") != "Y") {
				birBasvuruTx.setSozlesmeFaizi(iMap.getBigDecimal("SOZLESME_FAIZI"));
			}
			else {
				birBasvuruTx.setSozlesmeFaizi(null);
			}
			birBasvuruTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
			birBasvuruTx.setGorus(iMap.getString("DIGER_GORUS"));
			birBasvuruTx.setIslemSonrasiDurumKodu("NBSM");
			birBasvuruTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			birBasvuruTx.setBasvuruTutari(iMap.getBigDecimal("TUTAR"));
			// birBasvuruTx.setDurumKodu("BASVURU");

			birBasvuruTx.setPttMaasAlinanKurum(iMap.getString("MAAS_ALINAN_KURUM"));

			if (iMap.get("ONCEKI_MAAS_ODEME_TARIHI") != null && iMap.getString("ONCEKI_MAAS_ODEME_TARIHI").compareTo("") != 0 && iMap.getString("ONCEKI_MAAS_ODEME_TARIHI").compareTo("00.00.0000") != 0) {
				birBasvuruTx.setPttOncekiMaasOdemeTarihi(iMap.getDate("ONCEKI_MAAS_ODEME_TARIHI"));
			}

			birBasvuruTx.setPttSgkMaasTutar(iMap.getBigDecimal("MAAS_TUTARI"));

			if (iMap.get("SON_MAAS_TARIHI") != null && iMap.getString("SON_MAAS_TARIHI").compareTo("") != 0) {
				birBasvuruTx.setPttSonMaasTarihi(iMap.getDate("SON_MAAS_TARIHI"));
			}

			birBasvuruTx.setPttMaasTarihSikligi(iMap.getBigDecimal("MAAS_TARIH_SIKLIGI"));
			birBasvuruTx.setApsYapildimi(iMap.getString("APS_YAPILDIMI"));
			birBasvuruTx.setApsBilgileriUyumlumu(iMap.getString("ADRES_BILGILERI_UYUMLUMU"));
			birBasvuruTx.setPttKpsBilgileriUyumlumu(iMap.getString("KIMLIK_BILGILERI_UYUMLUMU"));

			if (iMap.containsKey("POSTA_CEK_HESABI")) {
				birBasvuruTx.setPttPostaCekiHesabi(iMap.getBigDecimal("POSTA_CEK_HESABI"));
			}
			if (iMap.containsKey("MAAS_PTT_DENMI")) {
				birBasvuruTx.setPttMaasPttDenmi(iMap.getString("MAAS_PTT_DENMI"));
			}
			if (iMap.containsKey("EMEKLI_MAAS_EVDENMI")) {
				birBasvuruTx.setPttMaasEvdenMi(iMap.getString("EMEKLI_MAAS_EVDENMI"));
			}
			if (iMap.containsKey("TAHSIS_NUMARASI")) {
				birBasvuruTx.setPttTahsisNumarasi(iMap.getString("TAHSIS_NUMARASI"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_IL")) {
				birBasvuruTx.setPttSubeIli(iMap.getString("ISLEMIN_YAPILDIGI_IL"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_MERKEZ")) {
				birBasvuruTx.setPttIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
			}
			if (iMap.containsKey("ISLEMIN_YAPILDIGI_SUBE")) {
				birBasvuruTx.setPttIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
			}

			if (iMap.get("ILK_TAKSIT_TARIH") != null) {
				birBasvuruTx.setIlkTaksitTarihi(iMap.getDate("ILK_TAKSIT_TARIH"));
			}

			if (iMap.getString("KANAL_KOD") != null && iMap.getString("KANAL_KOD").compareTo("7") == 0) {
				birBasvuruTx.setIlkTaksitYontem(iMap.getString("PTT_ILK_TAKSIT_YONTEM"));
			}

			birBasvuruTx.setGecTeslimatNeden(iMap.getString("GEC_TESLIM_NEDEN"));
			birBasvuruTx.setHesapKapansinMi(iMap.getString("HESAP_KAPANSIN_MI"));
			birBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));
			birBasvuruTx.setTaksitGunu(iMap.getBigDecimal("TAKSIT_GUNU"));
			birBasvuruTx.setSozlesmeBeklemeEh(iMap.getString("SOZLESME_BEKLEME_EH"));
			birBasvuruTx.setDebitKartTalep(iMap.getString("DEBIT_KART_TALEP"));
			if (iMap.get("WEB_SATIS_KANALI") != null) {
				birBasvuruTx.setWebSatisKanali(iMap.getString("WEB_SATIS_KANALI"));
			}
			if (iMap.containsKey("KURYE_SECIMI")) {
				birBasvuruTx.setKuryeSecimi(iMap.getString("KURYE_SECIMI"));
			}
			
			session.saveOrUpdate(birBasvuruTx);
			session.flush();

			BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birBasvuruKimlikTx == null) {
				birBasvuruKimlikTx = new BirBasvuruKimlikTx();
				birBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			birBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruKimlikTx.setAd(iMap.getString("ADI"));
			birBasvuruKimlikTx.setAdresteFaaliyetSuresi(concatYilAy(iMap.getString("FAALIYET_SURESI_YIL"), iMap.getString("FAALIYET_SURESI_AY"))); // ay yil birlestir
			birBasvuruKimlikTx.setAdresteOturmaSuresi(concatYilAy(iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL"), iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY"))); //
			birBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
			birBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
			birBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
			birBasvuruKimlikTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
			birBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
			birBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
			birBasvuruKimlikTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			birBasvuruKimlikTx.setCepTelAlanKodu(iMap.getString("CEP_TEL_KOD"));
			birBasvuruKimlikTx.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			birBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
			birBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
			birBasvuruKimlikTx.setDigerGelir(iMap.getBigDecimal("DIGER_GELIR"));
			birBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
			birBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
			birBasvuruKimlikTx.setEgitimDurumKod(iMap.getString("OGRENIM_DURUMU"));
			if (iMap.getString("EMAIL1") != null && !iMap.getString("EMAIL1").isEmpty() && iMap.getString("EMAIL2") != null && !iMap.getString("EMAIL2").isEmpty()) {
				birBasvuruKimlikTx.setEMail(iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));
			}
			else {
				birBasvuruKimlikTx.setEMail("");
			}
			birBasvuruKimlikTx.setEsGeliri(iMap.getBigDecimal("ES_GELIRI"));
			if (iMap.getString("EV_ADRESI") != null) {
				birBasvuruKimlikTx.setEvAdres(iMap.getString("EV_ADRESI").trim());
			}
			else {
				birBasvuruKimlikTx.setEvAdres("");
			}
			birBasvuruKimlikTx.setEvAdrIlceKod(iMap.getString("EV_ILCE"));
			birBasvuruKimlikTx.setEvAdrIlKod(iMap.getString("EV_IL"));
			birBasvuruKimlikTx.setEvAdrUlkeKod("TR");
			birBasvuruKimlikTx.setEvPostakod(iMap.getString("EV_POSTA_KODU"));
			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				birBasvuruKimlikTx.setEvTelAlan(iMap.getString("EV_TEL_KOD"));
				birBasvuruKimlikTx.setEvTelNo(iMap.getString("EV_TEL_NO"));
			}
			else {
				birBasvuruKimlikTx.setEvTelAlan("");
				birBasvuruKimlikTx.setEvTelNo("");
			}
			birBasvuruKimlikTx.setIkametDurumKod(iMap.getString("IKAMET_DURUMU"));
			birBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
			if (iMap.getString("IS_ADRESI") != null) {
				birBasvuruKimlikTx.setIsAdres(iMap.getString("IS_ADRESI").trim());
			}
			else {
				birBasvuruKimlikTx.setIsAdres("");
			}
			birBasvuruKimlikTx.setIsAdrIlceKod(iMap.getString("IS_ILCE"));
			birBasvuruKimlikTx.setIsAdrIlKod(iMap.getString("IS_IL"));
			birBasvuruKimlikTx.setIsAdrUlkeKod("TR");
			birBasvuruKimlikTx.setIsPostakod(iMap.getString("IS_POSTA_KODU"));
			if (iMap.getString("IS_TEL_NO") != null && !iMap.getString("IS_TEL_NO").isEmpty()) {
				birBasvuruKimlikTx.setIsTelAlan(iMap.getString("IS_TEL_KOD"));
				birBasvuruKimlikTx.setIsTelNo(iMap.getString("IS_TEL_NO"));
				birBasvuruKimlikTx.setIsTelDahili(iMap.getString("IS_TEL_DAHILI"));
			}
			else {
				birBasvuruKimlikTx.setIsTelAlan(iMap.getString(""));
				birBasvuruKimlikTx.setIsTelNo(iMap.getString(""));
				birBasvuruKimlikTx.setIsTelDahili(iMap.getString(""));
			}
			if (iMap.getString("ISYERI_ADI") != null) {
				birBasvuruKimlikTx.setIsyeriAdi(iMap.getString("ISYERI_ADI").trim());
			}
			else {
				birBasvuruKimlikTx.setIsyeriAdi("");
			}
			birBasvuruKimlikTx.setIsyeriFaalKonuKod(iMap.getString("ISYERI_FAALIYET_ALANI"));
			birBasvuruKimlikTx.setIsyeriMulkiyetKod(iMap.getString("ISYERI_MULKIYET"));
			birBasvuruKimlikTx.setIsyerindeCalismaSuresi(concatYilAy(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), iMap.getString("ISYERINDE_CALISMA_SURESI_AY")));
			birBasvuruKimlikTx.setIsyeriVergiDaireKodu(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
			birBasvuruKimlikTx.setIsyeriVergiIlKodu(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			birBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
			birBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
			birBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO") != null ? iMap.getString("KIMLIK_SERI_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS") != null ? iMap.getString("KIMLIK_SERI_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO") != null ? iMap.getString("KIMLIK_SIRA_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS") != null ? iMap.getString("KIMLIK_SIRA_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
			birBasvuruKimlikTx.setIsyeriFaalKonuKod(iMap.getString("ISYERI_FAALIYET_ALANI"));
			birBasvuruKimlikTx.setIsyeriMulkiyetKod(iMap.getString("ISYERI_MULKIYET"));
			birBasvuruKimlikTx.setIsyerindeCalismaSuresi(concatYilAy(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), iMap.getString("ISYERINDE_CALISMA_SURESI_AY")));
			birBasvuruKimlikTx.setIsyeriVergiDaireKodu(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
			birBasvuruKimlikTx.setIsyeriVergiIlKodu(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			birBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
			birBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
			birBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO") != null ? iMap.getString("KIMLIK_SERI_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS") != null ? iMap.getString("KIMLIK_SERI_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO") != null ? iMap.getString("KIMLIK_SIRA_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS") != null ? iMap.getString("KIMLIK_SIRA_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
			birBasvuruKimlikTx.setMenkulGmenkulGeliri(iMap.getBigDecimal("GMENKUL_GELIR"));
			if (new BigDecimal(5).equals(iMap.getBigDecimal("KRD_TUR_KOD")) && "4".equals(iMap.getString("MAAS_ALINAN_KURUM"))) {
				birBasvuruKimlikTx.setMeslekKod("30"); // KDH ve PTT Personel ise Meslek Memur olacak
			}
			else {
				birBasvuruKimlikTx.setMeslekKod(iMap.getString("MESLEK"));
			}
			// birBasvuruKimlikTx.setMusteriNo(new BigDecimal(0)); //TODO sonradan yapilacak
			birBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
			birBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
			birBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));

			// birBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));

			if (iMap.get("NUFUS_VERILIS_TARIHI") != null && iMap.getString("NUFUS_VERILIS_TARIHI").compareTo("") != 0) {
				birBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
			}
			else {
				birBasvuruKimlikTx.setNufusVerTar(null);
			}

			birBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
			birBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
			birBasvuruKimlikTx.setOncekiSoyad(iMap.getString("ONCEKI_SOYADI"));
			birBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
			birBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			birBasvuruKimlikTx.setUnvanKod(iMap.getString("UNVANI"));
			birBasvuruKimlikTx.setPttUnvanKod(iMap.getString("PTT_UNVAN_KOD"));
			birBasvuruKimlikTx.setUyrukKod("TR");
			birBasvuruKimlikTx.setIsyeriVergiNo(iMap.getString("ISYERI_VERGI_NO"));
			if (iMap.getBoolean("YAZISMA_ADRESI_EV"))
				birBasvuruKimlikTx.setYazismaAdresKod("E");
			else if (iMap.getBoolean("YAZISMA_ADRESI_IS"))
				birBasvuruKimlikTx.setYazismaAdresKod("I");

			birBasvuruKimlikTx.setSigortaliMi(iMap.getBoolean("SIGORTALI_MI") ? "E" : "H");
			birBasvuruKimlikTx.setUlasimKartNo(iMap.getString("ULASIM_KART_NO"));
			birBasvuruKimlikTx.setKimlikKayitNo(iMap.getString("KIMLIK_KAYIT_NO"));

			if (iMap.getBoolean("MUH_ADR_E"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("E");
			else if (iMap.getBoolean("MUH_ADR_H"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("H");
			else if (iMap.getBoolean("MUH_ADR_B"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("B");

			if (iMap.getBoolean("ADR_AYNI_E")) {
				birBasvuruKimlikTx.setTeslimatAdresAyniEh("E");
			}
			else if (iMap.getBoolean("ADR_AYNI_H")) {
				birBasvuruKimlikTx.setTeslimatAdresAyniEh("H");
				birBasvuruKimlikTx.setTeslimatAdresi(iMap.getString("TESLIMAT_ADRES"));
				birBasvuruKimlikTx.setTeslimatAdrIlKod(iMap.getString("TESLIMAT_IL"));
				birBasvuruKimlikTx.setTeslimatAdrIlceKod(iMap.getString("TESLIMAT_ILCE"));
				birBasvuruKimlikTx.setTeslimatPostakod(iMap.getString("TESLIMAT_POSTA_KODU"));
				birBasvuruKimlikTx.setTeslimatKisiTckn(iMap.getString("TESLIMAT_TCKN"));
				birBasvuruKimlikTx.setTeslimatFarkliOlmaNedeni(iMap.getString("TESLIMAT_FARKLI_OLMA_NEDENI"));
			}
			birBasvuruKimlikTx.setTeslimatKisi(iMap.getString("TESLIMAT_URUN_KIME"));
			if (StringUtils.isNotBlank(iMap.getString("KART1")) && StringUtils.isNotBlank(iMap.getString("KART2"))) {
				birBasvuruKimlikTx.setKimlik2KartIlk6(iMap.getString("KART1").concat(iMap.getString("KART2")));
			}
			birBasvuruKimlikTx.setKimlik2KartSon4(iMap.getString("KART3"));
			birBasvuruKimlikTx.setKimlik2Tip(iMap.getString("IKINCI_KIMLIK_TURU"));
			birBasvuruKimlikTx.setTeyitEdilenGelir(iMap.get("TEYIT_EDILEN_GELIR") != null ? iMap.getBigDecimal("TEYIT_EDILEN_GELIR") : BigDecimal.ZERO);
			birBasvuruKimlikTx.setKampanyaBilgi(iMap.getString("KAMPANYA_BILGI"));
			birBasvuruKimlikTx.setEsTckn(iMap.getString("ES_TCKN"));

			session.saveOrUpdate(birBasvuruKimlikTx);
			boolean evliMi = iMap.getString("MEDENI_HAL").equals("1") && StringUtils.isNotBlank(iMap.getString("ES_TCKN"));
			if (evliMi) {
				GMServiceExecuter.execute("BNSPR_TRN3171_SAVE_ES_BILGILERI", iMap);
			}

			conn = DALUtil.getGMConnection();
			pstmt = conn.prepareStatement("DELETE FROM bir_basvuru_mal_tx WHERE TX_NO = ?");
			pstmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			pstmt.execute();
			pstmt.close();
			conn.close();
			
			if (CreditTypes.TARIM.getCreditCode().equals(iMap.getBigDecimal("KRD_TUR_KOD"))) { // �ift�i
				BirBasvuruTarimTx tarim = new BirBasvuruTarimTx(iMap.getBigDecimal("TRX_NO"));
				tarim.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				tarim.setBuyukbasSayisi(iMap.getBigDecimal("BUYUKBAS_SAYISI"));
				tarim.setDonum(iMap.getBigDecimal("DONUM"));
				tarim.setGuncelRisk(iMap.getBigDecimal("GUNCEL_RISK"));
				tarim.setKucukbasSayisi(iMap.getBigDecimal("KUCUKBAS_SAYISI"));
				tarim.setTarimSatisKanalKod(iMap.getString("TARIM_SATIS_KANAL_KOD"));
				tarim.setTarisEh(iMap.getString("TARIS_EH"));
				
				session.save(tarim);
				session.flush();
			}

			String tableName = "URUN_TABLE";
			List<?> malList = (List<?>) iMap.get(tableName);
			if (malList != null) {
				for (int i = 0; i < malList.size(); i++) {
					BirBasvuruMalTx birBasvuruMalTx = new BirBasvuruMalTx();
					BirBasvuruMalTxId birBasvuruMalTxId = new BirBasvuruMalTxId();
					birBasvuruMalTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruMalTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birBasvuruMalTxId.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
					birBasvuruMalTxId.setAd(iMap.getString(tableName, i, "AD"));
					birBasvuruMalTxId.setTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
					birBasvuruMalTxId.setMalno(iMap.getBigDecimal(tableName, i, "MALNO"));
					birBasvuruMalTxId.setAdet(iMap.getBigDecimal(tableName, i, "ADET"));
					birBasvuruMalTxId.setModel(iMap.getString(tableName, i, "MODEL"));
					birBasvuruMalTxId.setSiraNo(new BigDecimal(i + 1));
					birBasvuruMalTx.setId(birBasvuruMalTxId);
					session.save(birBasvuruMalTx);
				}
			}
			session.flush();

			List<?> silTeminatList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayTeminatlar = silTeminatList.toArray();
			for (Object element : arrayTeminatlar) {
				silTeminatList.remove(element);
				session.delete(element);
			}
			session.flush();

			tableName = "TEMINAT_TABLE";
			List<?> teminatList = (List<?>) iMap.get(tableName);

			if (teminatList != null) {
				for (int i = 0; i < teminatList.size(); i++) {
					if (iMap.getString(tableName, i, "TEMINAT") == null || iMap.getString(tableName, i, "TEMINAT").isEmpty()) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "Teminat Adini");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirBasvuruTeminatTx birBasvuruTeminatTx = new BirBasvuruTeminatTx();
					BirBasvuruTeminatTxId teminatId = new BirBasvuruTeminatTxId();
					teminatId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					teminatId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					teminatId.setTeminatKod(iMap.getString(tableName, i, "TEMINAT"));
					birBasvuruTeminatTx.setId(teminatId);

					birBasvuruTeminatTx.setTeminatAdedi(iMap.getBigDecimal(tableName, i, "ADET"));

					session.saveOrUpdate(birBasvuruTeminatTx);
				}
			}
			session.flush();

			List<?> silSigortaList = session.createCriteria(BirBasvuruSigortaSatisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arraySigortalar = silSigortaList.toArray();
			for (Object element : arraySigortalar) {
				silSigortaList.remove(element);
				session.delete(element);
			}
			session.flush();

			String tableName2 = "SIGORTA_TABLE";
			List<?> sigortaList = (List<?>) iMap.get(tableName2);

			if (sigortaList != null) {
				for (int i = 0; i < sigortaList.size(); i++) {
					if (iMap.getString(tableName2, i, "SIGORTA_SATIS_URUN") == null || iMap.getString(tableName2, i, "SIGORTA_SATIS_URUN").isEmpty()) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "Sigorta Satis Urun");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirBasvuruSigortaSatisTx birBasvuruSigortaSatisTx = (BirBasvuruSigortaSatisTx) session.createCriteria(BirBasvuruSigortaSatisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.sigortaUrunNo", iMap.getBigDecimal(tableName2, i, "SIGORTA_SATIS_URUN"))).uniqueResult();

					if (birBasvuruSigortaSatisTx == null)
						birBasvuruSigortaSatisTx = new BirBasvuruSigortaSatisTx();
					BirBasvuruSigortaSatisTxId id = new BirBasvuruSigortaSatisTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					id.setSigortaUrunNo(iMap.getBigDecimal(tableName2, i, "SIGORTA_SATIS_URUN"));
					birBasvuruSigortaSatisTx.setId(id);
					birBasvuruSigortaSatisTx.setSigortaPrimi(iMap.getBigDecimal(tableName2, i, "PRIM"));
					session.saveOrUpdate(birBasvuruSigortaSatisTx);
				}
			}
			session.flush();

			List<?> silGorusList = session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayGorusler = silGorusList.toArray();
			for (Object element : arrayGorusler) {
				silGorusList.remove(element);
				session.delete(element);
			}
			session.flush();

			String gorusTable = "GORUS";
			List<?> gorusList = (List<?>) iMap.get(gorusTable);
			if (gorusList != null) {
				for (int i = 0; i < gorusList.size(); i++) {
					BirBasvuruGorusTx birBasvuruGorusTx = new BirBasvuruGorusTx();
					BirBasvuruGorusTxId birBasvuruGorusTxId = new BirBasvuruGorusTxId();

					birBasvuruGorusTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruGorusTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birBasvuruGorusTxId.setGorusKod(iMap.getString(gorusTable, i, "BASVURU_GORUS"));
					birBasvuruGorusTx.setId(birBasvuruGorusTxId);
					if (iMap.getString(gorusTable, i, "SEC").equals("1") || iMap.getBoolean(gorusTable, i, "SEC"))
						birBasvuruGorusTx.setEH("E");
					else
						birBasvuruGorusTx.setEH("H");
					session.save(birBasvuruGorusTx);
				}
			}
			session.flush();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3171.After_Control(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			stmt.close();

			stmt = conn.prepareCall("{call pkg_trn3171.Basvuru_Kaydet(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(pstmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BASVURU")
	public static GMMap getBasvuruBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("BASVURU_NO", birBasvuruTx.getBasvuruNo());
			oMap.put("DOVIZ_KOD", birBasvuruTx.getDovizKodu());
			if (birBasvuruTx.getKampKnlKod() != null)
				oMap.put("URUN_KAMP_KOD", birBasvuruTx.getKampKod());
			else {
				oMap.put("KRD_TUR_ALT_KOD", birBasvuruTx.getKrediAltTur());
				oMap.put("KRD_TUR_ALT_KOD2", birBasvuruTx.getKrediAltTur2());
				oMap.put("URUN_KAMP_KOD", birBasvuruTx.getKrediAltTur() + "-" + birBasvuruTx.getKrediAltTur2());
			}
			oMap.put("KAMP_KNL_KOD", birBasvuruTx.getKampKnlKod());
			oMap.put("KAMP_KOD", birBasvuruTx.getKampKod());
			oMap.put("EVE_TESLIM_URUN", birBasvuruTx.getEveTeslimatliUrun());
			oMap.put("TESLIMAT_TARIHI", birBasvuruTx.getUrunTeslimTarihi());
			oMap.put("KRD_TUR_KOD", birBasvuruTx.getKrediTur());
			oMap.put("TUTAR", birBasvuruTx.getTutar());
			oMap.put("VADE", birBasvuruTx.getVade());
			oMap.put("KANAL_KOD", birBasvuruTx.getKanalKodu());
			oMap.put("PERSONEL", birBasvuruTx.getSatisPersoneli());

			oMap.put("MAAS_ALINAN_KURUM", birBasvuruTx.getPttMaasAlinanKurum());
			oMap.put("ONCEKI_MAAS_ODEME_TARIHI", birBasvuruTx.getPttOncekiMaasOdemeTarihi());
			oMap.put("MAAS_TUTARI", birBasvuruTx.getPttSgkMaasTutar());
			oMap.put("SON_MAAS_TARIHI", birBasvuruTx.getPttSonMaasTarihi());
			oMap.put("MAAS_TARIH_SIKLIGI", birBasvuruTx.getPttMaasTarihSikligi());
			oMap.put("POSTA_CEK_HESABI", birBasvuruTx.getPttPostaCekiHesabi());
			oMap.put("MAAS_PTT_DENMI", birBasvuruTx.getPttMaasPttDenmi());
			oMap.put("EMEKLI_MAAS_EVDENMI", birBasvuruTx.getPttMaasEvdenMi());
			oMap.put("TAHSIS_NUMARASI", birBasvuruTx.getPttTahsisNumarasi());
			oMap.put("APS_YAPILDIMI", birBasvuruTx.getApsYapildimi());
			oMap.put("GECIKME_GUN_SAYISI", birBasvuruTx.getGecikmeGunSayisi());
			oMap.put("PTT_ILK_TAKSIT_YONTEM", birBasvuruTx.getIlkTaksitYontem());
			oMap.put("ILK_TAKSIT_TARIH", birBasvuruTx.getIlkTaksitTarihi());

			oMap.put("ISLEMIN_YAPILDIGI_IL", birBasvuruTx.getPttSubeIli());
			oMap.put("ISLEMIN_YAPILDIGI_MERKEZ", birBasvuruTx.getPttIsleminYapildigiMerkez());
			oMap.put("ISLEMIN_YAPILDIGI_SUBE", birBasvuruTx.getPttIsleminYapildigiSube());
			oMap.put("HESAP_KAPANSIN_MI", birBasvuruTx.getHesapKapansinMi());
			oMap.put("KAZANIM_TUR", birBasvuruTx.getKazanimTur());
			oMap.put("WEB_SATIS_KANALI", birBasvuruTx.getWebSatisKanali());
			oMap.put("FAIZSIZ_FINANSMAN", birBasvuruTx.getFaizsizFinansman());

			if (birBasvuruTx.getKanalKodu() != null && birBasvuruTx.getKanalKodu().compareTo("7") == 0) {

				int i = 1;
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call PKG_TRN3172.PTT_GET_IL_SUBE_MERKEZ(?,?,?,?,?,?)}"); // PROSEDUR
				stmt.setString(i++, birBasvuruTx.getPttSubeIli());
				stmt.setString(i++, birBasvuruTx.getPttIsleminYapildigiSube());
				stmt.setString(i++, birBasvuruTx.getPttIsleminYapildigiMerkez());

				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.execute();

				oMap.put("D_ISLEMIN_YAPILDIGI_IL", stmt.getString(4));
				oMap.put("D_ISLEMIN_YAPILDIGI_SUBE", stmt.getString(5));
				oMap.put("D_ISLEMIN_YAPILDIGI_MERKEZ", stmt.getString(6));

			}

			BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("CALISMA_SEKLI", birBasvuruKimlikTx.getCalismaSekli());
			oMap.put("ADI", birBasvuruKimlikTx.getAd());
			oMap.put("ANNE_KIZLIK_SOYADI", birBasvuruKimlikTx.getAnneKizlik());
			// oMap.put("BABA_ADI", birBasvuruKimlikTx.getBabaAd());
			oMap.put("CEP_TEL_KOD", birBasvuruKimlikTx.getCepTelAlanKodu());
			oMap.put("CEP_TEL_NO", birBasvuruKimlikTx.getCepTelNo());
			// oMap.put("CINSIYET", birBasvuruKimlikTx.getCinsiyet());
			// oMap.put("DOGUM_TARIHI", birBasvuruKimlikTx.getDogumTar());
			// oMap.put("DOGUM_YERI", birBasvuruKimlikTx.getDogumYeri());
			oMap.put("IKINCI_ADI", birBasvuruKimlikTx.getIkinciAd());
			oMap.put("KIMLIK_SERI_NO", birBasvuruKimlikTx.getKimlikSeriNo());
			oMap.put("KIMLIK_SIRA_NO", birBasvuruKimlikTx.getKimlikSiraNo());
			// oMap.put("MEDENI_HAL", birBasvuruKimlikTx.getMedeniHal());
			oMap.put("SOYADI", birBasvuruKimlikTx.getSoyad());
			oMap.put("ONCEKI_SOYADI", birBasvuruKimlikTx.getOncekiSoyad());
			oMap.put("TC_KIMLIK_NO", birBasvuruKimlikTx.getTcKimlikNo());
			oMap.put("ES_TCKN", birBasvuruKimlikTx.getEsTckn());
			// oMap.put("UYRUK", birBasvuruKimlikTx.getUyrukKod());

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BASVURU_DETAY")
	public static GMMap getBasvuruDetayBilgileri(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("BASVURU_NO", birBasvuruTx.getBasvuruNo());
			oMap.put("DOSYA_MASRAFI", birBasvuruTx.getDosyaMasrafi());
			oMap.put("ODEME_TIPI", birBasvuruTx.getOdemeTipKod());
			oMap.put("ODEME_ORANI", birBasvuruTx.getOdemeTipOran());
			oMap.put("ODEME_PERIYODU", birBasvuruTx.getOdemeTipPeriyod());
			oMap.put("ODEME_TUTARI", birBasvuruTx.getOdemeTipTut());
			oMap.put("ODEME_VADESI", birBasvuruTx.getOdemeTipVade());
			oMap.put("KATILIM_BEDELI", birBasvuruTx.getSerbestKatkiPayi());
			oMap.put("SOZLESME_FAIZI", birBasvuruTx.getSozlesmeFaizi());

			oMap.put("ADRES_BILGILERI_UYUMLUMU", birBasvuruTx.getApsBilgileriUyumlumu());
			oMap.put("KIMLIK_BILGILERI_UYUMLUMU", birBasvuruTx.getPttKpsBilgileriUyumlumu());

			BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

			if (birBasvuruKimlikTx.getAdresteFaaliyetSuresi() != null) {
				String adresteFaaliyetSuresiYil = birBasvuruKimlikTx.getAdresteFaaliyetSuresi().substring(0, 2);
				if (adresteFaaliyetSuresiYil.charAt(0) == '0')
					adresteFaaliyetSuresiYil = adresteFaaliyetSuresiYil.substring(1);
				String adresteFaaliyetSuresiAy = birBasvuruKimlikTx.getAdresteFaaliyetSuresi().substring(2, 4);
				if (adresteFaaliyetSuresiAy.charAt(0) == '0')
					adresteFaaliyetSuresiAy = adresteFaaliyetSuresiAy.substring(1);
				oMap.put("FAALIYET_SURESI_YIL", adresteFaaliyetSuresiYil);
				oMap.put("FAALIYET_SURESI_AY", adresteFaaliyetSuresiAy);
			}
			else {
				oMap.put("FAALIYET_SURESI_YIL", "00");
				oMap.put("FAALIYET_SURESI_AY", "00");
			}
			if (birBasvuruKimlikTx.getAdresteOturmaSuresi() != null) {
				String adresteOturmaSuresiYil = birBasvuruKimlikTx.getAdresteOturmaSuresi().substring(0, 2);
				if (adresteOturmaSuresiYil.charAt(0) == '0')
					adresteOturmaSuresiYil = adresteOturmaSuresiYil.substring(1);
				String adresteOturmaSuresiAy = birBasvuruKimlikTx.getAdresteOturmaSuresi().substring(2, 4);
				if (adresteOturmaSuresiAy.charAt(0) == '0')
					adresteOturmaSuresiAy = adresteOturmaSuresiAy.substring(1);
				oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL", adresteOturmaSuresiYil);
				oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY", adresteOturmaSuresiAy);
			}
			else {
				oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL", "00");
				oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY", "00");
			}
			oMap.put("AYLIK_GELIR", birBasvuruKimlikTx.getAylikGelir());
			oMap.put("CALISMA_SEKLI", birBasvuruKimlikTx.getCalismaSekli());
			oMap.put("DIGER_GELIR", birBasvuruKimlikTx.getDigerGelir());
			oMap.put("OGRENIM_DURUMU", birBasvuruKimlikTx.getEgitimDurumKod());
			if (birBasvuruKimlikTx.getEMail() != null && birBasvuruKimlikTx.getEMail().length() > 1) {
				oMap.put("EMAIL1", birBasvuruKimlikTx.getEMail().substring(0, birBasvuruKimlikTx.getEMail().indexOf('@')));
				oMap.put("EMAIL2", birBasvuruKimlikTx.getEMail().substring(birBasvuruKimlikTx.getEMail().indexOf('@') + 1));
			}
			oMap.put("ES_GELIRI", birBasvuruKimlikTx.getEsGeliri());
			oMap.put("EV_ADRESI", birBasvuruKimlikTx.getEvAdres());
			oMap.put("EV_ILCE", birBasvuruKimlikTx.getEvAdrIlceKod());
			oMap.put("EV_IL", birBasvuruKimlikTx.getEvAdrIlKod());
			oMap.put("EV_POSTA_KODU", birBasvuruKimlikTx.getEvPostakod());
			oMap.put("EV_TEL_KOD", birBasvuruKimlikTx.getEvTelAlan());
			oMap.put("EV_TEL_NO", birBasvuruKimlikTx.getEvTelNo());
			oMap.put("IKAMET_DURUMU", birBasvuruKimlikTx.getIkametDurumKod());
			oMap.put("IS_ADRESI", birBasvuruKimlikTx.getIsAdres());
			oMap.put("IS_ILCE", birBasvuruKimlikTx.getIsAdrIlceKod());
			oMap.put("IS_IL", birBasvuruKimlikTx.getIsAdrIlKod());
			oMap.put("IS_POSTA_KODU", birBasvuruKimlikTx.getIsPostakod());
			oMap.put("IS_TEL_KOD", birBasvuruKimlikTx.getIsTelAlan());
			oMap.put("IS_TEL_DAHILI", birBasvuruKimlikTx.getIsTelDahili());
			oMap.put("IS_TEL_NO", birBasvuruKimlikTx.getIsTelNo());
			oMap.put("ISYERI_ADI", birBasvuruKimlikTx.getIsyeriAdi());
			oMap.put("ISYERI_FAALIYET_ALANI", birBasvuruKimlikTx.getIsyeriFaalKonuKod());
			oMap.put("ISYERI_MULKIYET", birBasvuruKimlikTx.getIsyeriMulkiyetKod());

			if (birBasvuruKimlikTx.getIsyerindeCalismaSuresi() != null) {
				String isyerindeCalismaSuresiYil = birBasvuruKimlikTx.getIsyerindeCalismaSuresi().substring(0, 2);
				if (isyerindeCalismaSuresiYil.charAt(0) == '0')
					isyerindeCalismaSuresiYil = isyerindeCalismaSuresiYil.substring(1);
				String isyerindeCalismaSuresiAy = birBasvuruKimlikTx.getIsyerindeCalismaSuresi().substring(2, 4);
				if (isyerindeCalismaSuresiAy.charAt(0) == '0')
					isyerindeCalismaSuresiAy = isyerindeCalismaSuresiAy.substring(1);
				oMap.put("ISYERINDE_CALISMA_SURESI_YIL", isyerindeCalismaSuresiYil);
				oMap.put("ISYERINDE_CALISMA_SURESI_AY", isyerindeCalismaSuresiAy);
			}
			else {
				oMap.put("ISYERINDE_CALISMA_SURESI_YIL", "00");
				oMap.put("ISYERINDE_CALISMA_SURESI_AY", "00");
			}
			oMap.put("ISYERI_VERGI_DAIRESI_ADI", birBasvuruKimlikTx.getIsyeriVergiDaireKodu());
			oMap.put("ISYERI_VERGI_DAIRESI_IL", birBasvuruKimlikTx.getIsyeriVergiIlKodu());
			oMap.put("ISYERI_VERGI_NO", birBasvuruKimlikTx.getIsyeriVergiNo());
			oMap.put("GMENKUL_GELIR", birBasvuruKimlikTx.getMenkulGmenkulGeliri());
			oMap.put("MESLEK", birBasvuruKimlikTx.getMeslekKod());
			oMap.put("UNVANI", birBasvuruKimlikTx.getUnvanKod());
			oMap.put("YAZISMA_ADRESI_EV", birBasvuruKimlikTx.getYazismaAdresKod() != null ? birBasvuruKimlikTx.getYazismaAdresKod().equals("E") : false);
			oMap.put("YAZISMA_ADRESI_IS", birBasvuruKimlikTx.getYazismaAdresKod() != null ? birBasvuruKimlikTx.getYazismaAdresKod().equals("I") : false);
			oMap.put("SIGORTALI_MI", GuimlUtil.convertToCheckBoxSelected(birBasvuruKimlikTx.getSigortaliMi()));
			oMap.put("ULASIM_KART_NO", birBasvuruKimlikTx.getUlasimKartNo());

			List<?> limitList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "TEMINAT_TABLE";
			int row = 0;
			for (Object name : limitList) {
				BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) name;
				oMap.put(tableName, row, "TEMINAT", birBasvuruTeminatTx.getId().getTeminatKod());
				// oMap.put(tableName, row, "TEMINAT_ADI", birBasvuruTeminatTx.getTeminatTipi());
				oMap.put(tableName, row, "ADET", birBasvuruTeminatTx.getTeminatAdedi());
				row++;
			}

			List<?> sigortaList = session.createCriteria(BirBasvuruSigortaSatisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName2 = "SIGORTA_TABLE";
			row = 0;
			for (Object name : sigortaList) {
				BirBasvuruSigortaSatisTx birBasvuruSigortaSatisTx = (BirBasvuruSigortaSatisTx) name;
				oMap.put(tableName2, row, "SIGORTA_SATIS_URUN", birBasvuruSigortaSatisTx.getId().getSigortaUrunNo());
				oMap.put(tableName2, row, "ADET", "1");
				oMap.put(tableName2, row, "PRIM", birBasvuruSigortaSatisTx.getSigortaPrimi());

				row++;
			}
			GMMap xMap = new GMMap();
			xMap.put("KAMP_KNL_KOD", oMap.get("KANAL_KOD"));
			xMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			xMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_SIGORTA_URUNLERI", xMap));
			oMap.put("BAYI_KAZANCI", xMap.getBigDecimal("BAYI_KAZANCI"));
			oMap.put("BAYI_KAZANCI_FLAG", xMap.getBoolean("BAYI_KAZANCI_FLAG"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KONTAKT_MUSTERI")
	public static Map<?, ?> kontaktMusteriOlustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			Session session = DAOSession.getSession("BNSPRDal");
			BirKampanya birKampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", iMap.getBigDecimal("KAMP_KOD"))).uniqueResult();
			String ticariKrediEh = "H";
			if (birKampanya != null) {
				ticariKrediEh = birKampanya.getTicariKrediEh();
			}

			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI").trim());
			}

			GMMap kontakt = new GMMap();
			kontakt.put("MUSTERI_KONTAKT", "K");
			kontakt.put("MUSTERI_TIPI_KOD", "G");
			kontakt.put("BAGLI_KANAL_GRUBU", iMap.getString("KANAL_KODU"));
			kontakt.put("KANAL_KODU", iMap.getString("KANAL_ALT_KODU"));
			kontakt.put("MUSTERI_SEGMENTI", "N");
			kontakt.put("YERLESIM_KOD", "I");
			/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			if ("E".equals(ticariKrediEh)) {
				kontakt.put("DK_GRUP_KOD", new BigDecimal("1043"));
				kontakt.put("PROFIL_KOD", "4");
			}
			else {
				kontakt.put("DK_GRUP_KOD", new BigDecimal("1042"));
				kontakt.put("PROFIL_KOD", "1");
			}
			// kontakt.put("BOLUM_KODU", new BigDecimal("444"));
			kontakt.put("KAZANIM_KANALI", iMap.getString("KANAL_KODU"));
			kontakt.put("KAZANIM_URUNU", "BRY");
			kontakt.put("HESAP_UCRETI_F", "H");
			kontakt.put("YATIRIM_EKSTRESI", "H");

			if (StringUtils.isNotBlank(iMap.getString("URUN_KAMP_KOD")) && iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_kampanya.Kamp_MusteriGrupKod(?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, iMap.getBigDecimal("URUN_KAMP_KOD"));
				stmt.execute();
				if (stmt.getString(1) != null && stmt.getString(1).isEmpty() == false)
					kontakt.put("MUSTERI_GRUP_KOD", stmt.getString(1));
				else
					kontakt.put("MUSTERI_GRUP_KOD", "1"); // normal musteri
			}
			else
				kontakt.put("MUSTERI_GRUP_KOD", "1"); // normal musteri

			kontakt.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD"));
			kontakt.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", kontakt.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));

			if (iMap.getString("KANAL_KOD") != null && iMap.getString("KANAL_KOD").equals("3") && iMap.getString("KANAL_KOD").equals(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD")))
				kontakt.put("MUSTERIYI_KAZANDIRAN", GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANICI_KOD", iMap).get("KULLANICI_KOD"));

			kontakt.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			kontakt.put("TCKNO_IN", iMap.getBigDecimal("TC_KIMLIK_NO"));
			if ("E".equals(iMap.getString("KPS_YAPILDI")))
				kontakt.put("TCKNO_OUT", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("TC_KIMLIK_NO", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("ISIM", iMap.getString("ISIM"));
			kontakt.put("IKINCI_ISIM", iMap.getString("IKINCI_ISIM"));
			kontakt.put("SOYADI", iMap.getString("SOYADI"));
			kontakt.put("KISA_AD", iMap.getString("ISIM") + " " + (iMap.getString("IKINCI_ISIM") == null ? "" : iMap.getString("IKINCI_ISIM") + " ") + iMap.getString("SOYADI"));
			if (iMap.getString("UYRUK_KOD") != null && !iMap.getString("UYRUK_KOD").isEmpty())
				kontakt.put("UYRUK_KOD", iMap.getString("UYRUK_KOD"));
			else
				kontakt.put("UYRUK_KOD", "TR");
			kontakt.put("DOGUM_TARIHI", !"".equals(iMap.getString("DOGUM_TARIHI")) ? iMap.getDate("DOGUM_TARIHI") : null);
			kontakt.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
			kontakt.put("BABA_ADI", iMap.getString("BABA_ADI"));
			kontakt.put("ANNE_ADI", iMap.getString("ANNE_ADI"));
			kontakt.put("CINSIYET_KOD", iMap.getString("CINSIYET_KOD"));
			kontakt.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			kontakt.put("MEDENI_HAL_KOD", iMap.getString("MEDENI_HAL_KOD"));
			kontakt.put("AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
			kontakt.put("CILT_NO", iMap.getString("CILT_NO"));
			kontakt.put("SIRA_NO", iMap.getString("SIRA_NO"));

			kontakt.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("NUFUS_CUZDANI_SERI_NO"));
			kontakt.put("KIZLIK_SOYADI", iMap.getString("KIZLIK_SOYADI"));
			kontakt.put("MESLEK_KOD", iMap.getString("MESLEK_KOD"));
			kontakt.put("EGITIM_KOD", iMap.getString("EGITIM_KOD"));
			kontakt.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			kontakt.put("F_ISTEGE_BAGLI_SIGORTALI", iMap.getString("SIGORTALI_MI"));
			kontakt.put("ISYERI_ADI", iMap.getString("ISYERI_ADI"));
			/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			if ("E".equals(ticariKrediEh)) {
				if (CreditTypes.TARIM.getCreditCode().equals(iMap.getBigDecimal("KRD_TUR_KOD"))) { // �ift�i
					kontakt.put("TICARI_UNVAN", kontakt.getString("KISA_AD"));
					kontakt.put("SEKTOR_KOD", "A");
				}
				else {
					kontakt.put("TICARI_UNVAN", iMap.getString("ISYERI_ADI"));
					kontakt.put("SEKTOR_KOD", iMap.getString("SEKTOR_KOD","FD"));
				}
				kontakt.put("VERGI_DAIRE_IL_KODU", iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
				kontakt.put("VERGI_DAIRE_KODU", iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
				kontakt.put("VERGI_NO", iMap.getString("ISYERI_VERGI_NO"));

				kontakt.put("SEKTOR_ALT1_KODU", iMap.getString("SEKTOR_ALT1_KODU"));
				kontakt.put("SEKTOR_ALT2_KODU", iMap.getString("SEKTOR_ALT2_KODU"));
			}
			kontakt.put("UNVAN_KOD", iMap.getString("UNVANI"));
			kontakt.put("IL_KOD", iMap.getString("IL_KOD"));
			kontakt.put("ILCE_KOD", iMap.getString("ILCE_KOD"));
			kontakt.put("MAHALLE_KOY", iMap.getString("MAHALLE_KOY"));

			kontakt.put("ADRES_NO", iMap.getBigDecimal("ADRES_NO"));
			kontakt.put("BUCAK", iMap.getString("BUCAK"));
			kontakt.put("BUCAK_KOD", iMap.getBigDecimal("BUCAK_KOD"));
			kontakt.put("CSBM", iMap.getString("CSBM"));
			kontakt.put("DIS_KAPI_NO", iMap.getString("DIS_KAPI_NO"));
			kontakt.put("IC_KAPI_NO", iMap.getString("IC_KAPI_NO"));
			kontakt.put("IL", iMap.getString("IL"));
			kontakt.put("ILCE", iMap.getString("ILCE"));
			kontakt.put("ILCE_KODU", iMap.getBigDecimal("ILCE_KODU"));
			kontakt.put("IL_KODU", iMap.getBigDecimal("IL_KODU"));
			kontakt.put("KOY", iMap.getString("KOY"));
			kontakt.put("KOY_KAYIT_NO", iMap.getBigDecimal("KOY_KAYIT_NO"));
			kontakt.put("KOY_KOD", iMap.getBigDecimal("KOY_KOD"));
			kontakt.put("MAHALLE", iMap.getString("MAHALLE"));
			kontakt.put("MAHALLE_KOD", iMap.getBigDecimal("MAHALLE_KOD"));
			kontakt.put("YABANCI_ADRES", iMap.getString("YABANCI_ADRES"));
			kontakt.put("YABANCI_SEHIR", iMap.getString("YABANCI_SEHIR"));
			kontakt.put("YABANCI_ULKE", iMap.getString("YABANCI_ULKE"));
			kontakt.put("YABANCI_ULKE_KOD", iMap.getString("YABANCI_ULKE_KOD"));

			if (iMap.getString("NUFUS_CUZDANI_SERI_NO") != null && !iMap.getString("NUFUS_CUZDANI_SERI_NO").isEmpty())
				kontakt.put("F_NUF", "E");

			kontakt.put("NUF_VERILIS_NEDENI", iMap.getString("NUF_VERILIS_NEDENI"));
			kontakt.put("VERILDIGI_YER", iMap.getString("VERILDIGI_YER"));
			kontakt.put("VERILDIGI_TARIH", !"".equals(iMap.getString("VERILDIGI_TARIH")) ? iMap.getDate("VERILDIGI_TARIH") : null);

			ArrayList<HashMap<String, Object>> adresList = new ArrayList<HashMap<String, Object>>();
			if (iMap.getString("EV_ADRES") != null && !iMap.getString("EV_ADRES").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("ADRES_KOD", "E");
				rowData.put("ADRES", iMap.getString("EV_ADRES"));
				rowData.put("ADRES_IL_KOD", iMap.getString("EV_IL"));
				rowData.put("ADRES_ILCE_KOD", iMap.getString("EV_ILCE"));
				rowData.put("ULKE_KOD", "TR");
				rowData.put("POSTA_KOD", iMap.getString("EV_POSTA_KOD"));
				rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
				rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_EV")));
				adresList.add(rowData);
			}
			if (iMap.getString("IS_ADRES") != null && !iMap.getString("IS_ADRES").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("ADRES_KOD", "I");
				rowData.put("ISYERI_UNVANI", iMap.getString("ISYERI_ADI"));
				rowData.put("ADRES", iMap.getString("IS_ADRES"));
				rowData.put("ADRES_IL_KOD", iMap.getString("IS_IL"));
				rowData.put("ADRES_ILCE_KOD", iMap.getString("IS_ILCE"));
				rowData.put("ULKE_KOD", "TR");
				rowData.put("POSTA_KOD", iMap.getString("IS_POSTA_KOD"));
				rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
				rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_IS")));

				adresList.add(rowData);
			}
			// TY-1198 - APS adresi de EV adresi seklinde eklenecek
			boolean ekstreAdresAps = false;
			if (iMap.get("ADRES_NO") == null) { // Eger inputtan yok ise txnoya gore aps bilgilerini getir.
				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_APS_INFO", iMap));
			}
			if (iMap.get("ADRES_NO") != null && !"0".equals(iMap.getString("ADRES_NO")) && iMap.get("YABANCI_ULKE_KOD") == null) { // yine gelmediyse eklenmeyecek.
				adresList.add(getAPSAddressObject(iMap));
				ekstreAdresAps = true;
			}
			if (ekstreAdresAps) {
				for (int row = 0; row < adresList.size(); row++) {
					HashMap<String, Object> adrMap = adresList.get(row);
					if ("E".equals(adrMap.get("ADRES_KOD")) || "I".equals(adrMap.get("ADRES_KOD"))) {
						adrMap.put("EXTRE_ADRES_KOD_F", "H");
					}
					adresList.set(row, adrMap);
				}
			}
			else {
				if (!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")) {
					for (int row = 0; row < adresList.size(); row++) {
						HashMap<String, Object> adrMap = adresList.get(row);
						if ("E".equals(adrMap.get("ADRES_KOD"))) {
							adrMap.put("EXTRE_ADRES_KOD_F", "E");
						}
						adresList.set(row, adrMap);
					}
				}
			}
			kontakt.put("ADRES_LIST", adresList);

			ArrayList<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();
			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "1");
				rowData.put("ALAN_KOD", iMap.getString("EV_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("EV_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				if ("7".equals(iMap.getString("KANAL_KOD")) && !("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "6".equals(iMap.getString("MAAS_ALINAN_KURUM"))))
					rowData.put("F_ILETISIM", "1");
				else if (iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty())
					rowData.put("F_ILETISIM", "1");
				else
					rowData.put("F_ILETISIM", "0");
				telefonList.add(rowData);
			}
			if (iMap.getString("IS_TEL_NO") != null && !iMap.getString("IS_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "2");
				rowData.put("ALAN_KOD", iMap.getString("IS_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("IS_TEL_NO"));
				rowData.put("DAH_NO", iMap.getString("IS_TEL_DAHILI"));
				rowData.put("ULKE_KODU", "90");
				if ((iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty()) && (iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty()))
					rowData.put("F_ILETISIM", "1");
				else
					rowData.put("F_ILETISIM", "0");
				telefonList.add(rowData);
			}
			if (iMap.getString("CEP_TEL_NO") != null && !iMap.getString("CEP_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "3");
				rowData.put("ALAN_KOD", iMap.getString("CEP_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("CEP_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				if ("7".equals(iMap.getString("KANAL_KOD"))) {
					if ("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "6".equals(iMap.getString("MAAS_ALINAN_KURUM")))
						rowData.put("F_ILETISIM", "1");
					else if (iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty())
						rowData.put("F_ILETISIM", "1");
					else
						rowData.put("F_ILETISIM", "0");
				}
				else
					rowData.put("F_ILETISIM", "1");
				telefonList.add(rowData);
			}
			kontakt.put("TELEFON_LIST", telefonList);
			kontakt.put("F_APS_TEYIT", iMap.getString("F_APS_TEYIT"));

			if ("E".equals(iMap.getString("APS_YAPILDIMI"))) {
				kontakt.put("F_APS_TEYIT", "true");
			}

			kontakt.put("VELI_VASI", iMap.get("VELI_VASI"));

			if (iMap.getString("EMAIL1") != null && iMap.getString("EMAIL2") != null && !iMap.getString("EMAIL1").isEmpty() && !iMap.getString("EMAIL2").isEmpty())
				kontakt.put("EMAIL_KISISEL", iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));

			// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");

			// ekranda bunlar i�in alan bulunmuyor, default olarak
			// �ifte vatanda�l�k : R ("Hay�r")
			// Green Card : R("De�ilim")
			kontakt.put("F_CIFTE_VATANDAS", "R");
			kontakt.put("F_GREEN_CARD", "R");

			return GMServiceExecuter.execute("BNSPR_TRN10011_SAVE", kontakt);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static HashMap<String, Object> getAPSAddressObject(GMMap iMap) throws ParseException {
		HashMap<String, Object> rowData = new HashMap<String, Object>();
		String adres = "";
		rowData.put("ADRES_KOD", "A"); // A koduyla ekleniyor.
		if (!"0".equals(iMap.getString("ADRES_NO")) && iMap.getString("YABANCI_ULKE_KOD") == null) {
			if (iMap.get("BUCAK") != null && !iMap.getString("BUCAK").isEmpty())
				adres = iMap.getString("BUCAK") + " ";
			if (iMap.get("KOY") != null && !iMap.getString("KOY").isEmpty())
				adres += iMap.getString("KOY") + " ";
			if (iMap.get("MAHALLE") != null && !iMap.getString("MAHALLE").isEmpty())
				adres += iMap.getString("MAHALLE") + " ";
			if (iMap.get("CSBM") != null && !iMap.getString("CSBM").isEmpty())
				adres += iMap.getString("CSBM") + " ";
			if (iMap.get("DIS_KAPI_NO") != null && !iMap.getString("DIS_KAPI_NO").isEmpty())
				adres += "NO:" + iMap.getString("DIS_KAPI_NO") + " ";
			if (iMap.get("IC_KAPI_NO") != null && !iMap.getString("IC_KAPI_NO").isEmpty())
				adres += "DAIRE:" + iMap.getString("IC_KAPI_NO");
			rowData.put("ADRES", adres);
			rowData.put("ULKE_KOD", "TR");
			if (iMap.get("IL_KODU") != null) {
				String ilKodu = "";
				if (iMap.getString("IL_KODU").length() == 1)
					ilKodu = "00" + iMap.getString("IL_KODU");
				else if (iMap.getString("IL_KODU").length() == 2)
					ilKodu = "0" + iMap.getString("IL_KODU");
				else
					ilKodu = iMap.getString("IL_KODU");
				rowData.put("ADRES_IL_KOD", ilKodu);
			}
			rowData.put("ADRES_ILCE_KOD", iMap.getBigDecimal("ILCE_KODU"));
		}
		else {
			rowData.put("ADRES", iMap.getString("YABANCI_ADRES"));
			rowData.put("ULKE_KOD", "");
		}
		rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
		rowData.put("EXTRE_ADRES_KOD_F", "E");
		return rowData;
	}

	@GraymoundService("BNSPR_TRN3171_ODEME_PLANI_OLUSTUR")
	public static GMMap odemePlaniOlustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3171.fillPaymentPlan(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_STATU_GUNCELLE")
	public static GMMap statuGuncelle(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3171.updateDurumAndMusteriNo(?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, "JOB"); // yalan oldu
			stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_STATU_GUNCELLE_KEFIL")
	public static GMMap statuGuncelleKefil(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BASVURU.updateKefilMusteriNo (?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("KEFIL_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KKB_SORGU")
	public static GMMap kkbSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_kkb_sorgula.BIR_BASVURU_KKB_SORGU(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_TCMB_SORGU")
	public static GMMap tcmbSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_ist_tcmb.BasvuruTCMBSorgu(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_GORUS")
	public static GMMap getGorus(GMMap iMap) {
		try {
			StringBuilder query = new StringBuilder();
			query.append("SELECT KEY1 BASVURU_GORUS,TEXT GORUS, 0 SEC FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and KEY1 <> 8 and nvl(KEY3,'A') = 'A' ORDER BY KEY1");
			return DALUtil.getResults(query.toString(), "GORUS_TABLE");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_OLUMLU_GORUS")
	public static GMMap getOlumluGorus(GMMap iMap) {
		try {
			String sql = "SELECT KEY1 BASVURU_GORUS,TEXT GORUS, 0 SEC FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and KEY2 = '1' AND nvl(KEY3,'A')='A' ORDER BY KEY1";
			return DALUtil.getResults(sql, "OLUMLU_GORUS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_OLUMSUZ_GORUS")
	public static GMMap getOlumsuzGorus(GMMap iMap) {
		try {
			String query = "SELECT KEY1 BASVURU_GORUS,TEXT GORUS, 0 SEC FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and KEY2 = '2' and NVL(KEY3,'A') = 'A' ORDER BY KEY1";
			return DALUtil.getResults(query, "OLUMSUZ_GORUS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_YENI_GORUS")
	public static GMMap getYeniGorus(GMMap iMap) {
		try {
			StringBuilder query = new StringBuilder();
			query.append("SELECT KEY1 BASVURU_GORUS,TEXT GORUS, 0 SEC FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and KEY2 = '3' and NVL(KEY3,'A') = 'A' ORDER BY KEY1");
			return DALUtil.getResults(query.toString(), "YENI_GORUS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KEFIL_GORUS")
	public static GMMap getKefilGorus(GMMap iMap) {
		try {
			StringBuilder query = new StringBuilder();
			query.append("SELECT KEY1 BASVURU_GORUS,TEXT GORUS, 0 SEC FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and KEY2 = '5' and nvl(KEY3,'A') = 'A' ORDER BY KEY1");
			return DALUtil.getResults(query.toString(), "KEFIL_GORUS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_BASVURU_GONDER")
	public static GMMap basvuruGonder(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3171.basvuruGonder(?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BASVURU_GORUS")
	public static GMMap getBasvuruGorus(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "RESULTS", false, "select kod,text from gnl_param_text where kod= 'BAYI_BASVURU_GORUS_KOD'and key1<>8");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BASVURU_GORUS_LIST")
	public static GMMap getBasvuruGorusList(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "RESULTS", false, "select key1,text from gnl_param_text where kod= 'BAYI_BASVURU_GORUS_KOD'and key1<>8");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_IADE_BASV_LIST")
	public static GMMap getIadeBasvList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3171.RC_GET_BAYIIADE_BASVURULAR(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("SATICI_KOD"));

			stmt.execute();

			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "IADE_BASV_LIST";
			return DALUtil.rSetResultsPutStr(rSet, tableName);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_EKSIK_BELG_BASV_LIST")
	public static GMMap getEksikBelgBasvList(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3171.RC_GET_EKSIK_BELGELI_BASV(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("SATICI_KOD"));

			stmt.execute();

			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "EKSIK_BELG_BASV_LIST";
			return DALUtil.rSetResultsPutStr(rSet, tableName);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_EKSIK_BELGE_LIST")
	public static GMMap getEksikBelgeList(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3171.RC_GET_EKSIK_BELGELER(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "EKSIK_BELGE_LIST";
			oMap = DALUtil.rSetResultsPutStr(rSet, tableName);

			for (int i = 0; i < oMap.getSize(tableName); i++) {
				java.util.Date belgeTamamlamaTarihi = null;
				if (oMap.get(tableName, i, "SOZLESME_TARIHI") != null) {
					GMMap tempMap = new GMMap();
					tempMap.put("TARIH", oMap.getDate(tableName, i, "SOZLESME_TARIHI"));
					tempMap.put("GUN", oMap.getBigDecimal(tableName, i, "ORJ_EVRAK_GONDERIM_SURESI"));
					belgeTamamlamaTarihi = GMServiceExecuter.call("BNSPR_COMMON_SONRAKI_GUN", tempMap).getDate("TARIH");
				}
				oMap.put(tableName, i, "BELGE_TAMAMLAMA_TARIHI", belgeTamamlamaTarihi);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BU_AY_KREDI_ADET")
	public static GMMap getBuAyKrediAdet(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.BUAYKIKREDIADEDI(?) }");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();

			oMap.put("KREDI_ADET", stmt.getBigDecimal(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BU_AY_KREDI_MIKTAR")
	public static GMMap getBuAyKrediMiktar(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.BUAYKULLANDIRILANKREDITUTARI(?) }");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();

			oMap.put("KREDI_MIKTAR", stmt.getBigDecimal(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_SATICI_KREDI_SIRA")
	public static GMMap getSaticiKrediSira(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.SATICIKREDISIRASI(?) }");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();

			oMap.put("KREDI_SIRA", stmt.getBigDecimal(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ONAYLI_KULLANILMAMIS_BASVURU")
	public static GMMap getOnayliKullanilmamisBasvuru(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.ONAYLANMISKULLANDIRILMAMISBAS(?) }");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();
			oMap.put("KULLANILMAMIS_BASVURU", stmt.getBigDecimal(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("WEB_CREDIT_SAVE")
	public static Map<?, ?> webCreditSave(GMMap iMap) {
		try {
			// iMap.put("txNo", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			return new BnsprTxPersister(iMap, BirBasvuruTx.class, null, null, "3171").addDetailPojoClass(BirBasvuruKimlikTx.class, Long.class, null, null).persist();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU")
	public static Map<?, ?> basvuruGirisCaprazSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_basvuru.BasvuruGirisCaprazKontrol(?,?,?,?,?,?,?,?,?,?,?,?) }");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("CEP_TEL_ALAN") + iMap.getString("CEP_TEL_NO"));
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("KANAL_ALT_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setString(i++, iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
			stmt.setString(i++, iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAAS_TUTARI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAAS_ALINAN_KURUM"));
			stmt.execute();

			GMMap oMap = new GMMap();
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_DHF_ILCE")
	public static GMMap checkDHFIlce(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BASVURU.WebKrediDHFKontrol(?,?)}");

			stmt.setString(1, iMap.getString("IL_KOD"));
			stmt.setString(2, iMap.getString("ILCE_KOD"));

			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KANAL_ALT_KODLARI")
	public static GMMap getKanalAltKodlari(GMMap iMap) {
		if (iMap.getString("ADD_EMPTY_KEY") == null)
			iMap.put("ADD_EMPTY_KEY", "H");
		iMap.put("LIST_NAME", "KANAL_ALT_KODLARI");
		iMap.put("LIST_QUERY", "select kod, aciklama from v_kanal_alt_kod_pr where kanal_kod = " + iMap.getString("KANAL_KOD") + " and ((kanal_kod = '2' and kod in (select s.kod from bir_satici_tahsis s)) or kanal_kod <> '2') order by 1");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}

	public static void fillKefilTxTable(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirBasvuruKefilTx birBasvuruKefilTx = (BirBasvuruKefilTx) session.createCriteria(BirBasvuruKefilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kefilNo", iMap.getBigDecimal("KEFIL_NO"))).uniqueResult();
			if (birBasvuruKefilTx == null) {
				birBasvuruKefilTx = new BirBasvuruKefilTx();
				BirBasvuruKefilTxId kefilId = new BirBasvuruKefilTxId();
				kefilId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				kefilId.setKefilNo(iMap.getBigDecimal("KEFIL_NO"));

				birBasvuruKefilTx.setId(kefilId);
			}
			birBasvuruKefilTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruKefilTx.setSiraNo(iMap.getBigDecimal("K_SIRA_NO"));
			birBasvuruKefilTx.setAd(iMap.getString("K_ADI"));
			birBasvuruKefilTx.setAnneAdi(iMap.getString("K_ANNE_ADI"));
			birBasvuruKefilTx.setAnneKizlik(iMap.getString("K_ANNE_KIZLIK_SOYADI"));
			birBasvuruKefilTx.setAylikGelir(iMap.getBigDecimal("K_AYLIK_GELIR"));
			birBasvuruKefilTx.setAyniAdresFaaliyetSure(concatYilAy(iMap.getString("K_FAALIYET_SURESI_YIL"), iMap.getString("K_FAALIYET_SURESI_AY")));
			birBasvuruKefilTx.setBabaAd(iMap.getString("K_BABA_ADI"));
			birBasvuruKefilTx.setCalismaSekliKod(iMap.getString("K_CALISMA_SEKLI"));
			birBasvuruKefilTx.setCepTelAlanKod(iMap.getString("K_CEP_TEL_KOD"));
			birBasvuruKefilTx.setCepTelNo(iMap.getString("K_CEP_TEL_NO"));
			birBasvuruKefilTx.setCinsiyet(iMap.getString("K_CINSIYET"));
			birBasvuruKefilTx.setDogumTar(iMap.getDate("K_DOGUM_TARIHI"));
			birBasvuruKefilTx.setDogumYeri(iMap.getString("K_DOGUM_YERI"));
			birBasvuruKefilTx.setEgitimDurumKod(iMap.getString("K_OGRENIM_DURUMU"));
			if (iMap.getString("K_EMAIL1") != null && !iMap.getString("K_EMAIL1").isEmpty() && iMap.getString("K_EMAIL2") != null && !iMap.getString("K_EMAIL2").isEmpty()) {
				birBasvuruKefilTx.setEMail(iMap.getString("K_EMAIL1") + "@" + iMap.getString("K_EMAIL2"));
			}
			else {
				birBasvuruKefilTx.setEMail("");
			}
			if (iMap.getString("K_EV_ADRESI") != null) {
				birBasvuruKefilTx.setEvAdres(iMap.getString("K_EV_ADRESI").trim());
			}
			else {
				birBasvuruKefilTx.setEvAdres("");
			}
			birBasvuruKefilTx.setEvAdresIlceKod(iMap.getString("K_EV_ILCE"));
			birBasvuruKefilTx.setEvAdresIlKod(iMap.getString("K_EV_IL"));
			birBasvuruKefilTx.setEvPostaKod(iMap.getString("K_EV_POSTA_KODU"));
			birBasvuruKefilTx.setEvTelAlanKod(iMap.getString("K_EV_TEL_KOD"));
			birBasvuruKefilTx.setEvTelNo(iMap.getString("K_EV_TEL_NO"));
			birBasvuruKefilTx.setEvAdresUlkeKod("TR");
			birBasvuruKefilTx.setGmenkulGelir(iMap.getBigDecimal("K_GMENKUL_GELIR"));
			birBasvuruKefilTx.setIkametDurumKod(iMap.getString("K_IKAMET_DURUMU"));
			birBasvuruKefilTx.setIkinciAd(iMap.getString("K_IKINCI_ADI"));
			if (iMap.getString("K_IS_ADRESI") != null) {
				birBasvuruKefilTx.setIsAdres(iMap.getString("K_IS_ADRESI").trim());
			}
			else {
				birBasvuruKefilTx.setIsAdres("");
			}
			birBasvuruKefilTx.setIsAdresIlceKod(iMap.getString("K_IS_ILCE"));
			birBasvuruKefilTx.setIsAdresIlKod(iMap.getString("K_IS_IL"));
			birBasvuruKefilTx.setIsPostaKod(iMap.getString("K_IS_POSTA_KODU"));
			birBasvuruKefilTx.setIsTelAlanKod(iMap.getString("K_IS_TEL_KOD"));
			birBasvuruKefilTx.setIsTelDahili(iMap.getString("K_IS_TEL_DAHILI"));
			birBasvuruKefilTx.setIsTelNo(iMap.getString("K_IS_TEL_NO"));
			birBasvuruKefilTx.setIsAdresUlkeKod("TR");
			if (iMap.getString("K_ISYERI_ADI") != null) {
				birBasvuruKefilTx.setIsyeriAdi(iMap.getString("K_ISYERI_ADI").trim());
			}
			else {
				birBasvuruKefilTx.setIsyeriAdi("");
			}
			birBasvuruKefilTx.setIsyeriFaalKonuKod(iMap.getString("K_ISYERI_FAALIYET_ALANI"));
			birBasvuruKefilTx.setIsyeriMulkiyetKod(iMap.getString("K_ISYERI_MULKIYET"));
			birBasvuruKefilTx.setIsyeriVergiDaireIlKodu(iMap.getString("K_ISYERI_VERGI_DAIRESI_IL"));
			birBasvuruKefilTx.setIsyeriVergiDaireKodu(iMap.getString("K_ISYERI_VERGI_DAIRESI_ADI"));
			birBasvuruKefilTx.setIsyeriVergiNo(iMap.getString("K_ISYERI_VERGI_NO"));
			birBasvuruKefilTx.setKefilTipKod(iMap.getString("K_KEFIL_TIP_KOD"));
			birBasvuruKefilTx.setKefilYakinligi(iMap.getString("K_KEFIL_YAKINLIGI"));
			birBasvuruKefilTx.setKimlikSeriSiraNo(iMap.getString("K_KIMLIK_SERI_NO") + iMap.getString("K_KIMLIK_SIRA_NO"));
			birBasvuruKefilTx.setMedeniHal(iMap.getString("K_MEDENI_HAL"));
			birBasvuruKefilTx.setMeslekKod(iMap.getString("K_MESLEK"));
			birBasvuruKefilTx.setMevcutAdresOturmaSure(concatYilAy(iMap.getString("K_MEVCUT_ADRESTE_OTURMA_SURESI_YIL"), iMap.getString("K_MEVCUT_ADRESTE_OTURMA_SURESI_AY")));
			birBasvuruKefilTx.setMevcutIsyeriCalismaSure(concatYilAy(iMap.getString("K_ISYERINDE_CALISMA_SURESI_YIL"), iMap.getString("K_ISYERINDE_CALISMA_SURESI_AY")));
			// birBasvuruKefilTx.setMusteriNo(musteriNo);
			birBasvuruKefilTx.setOncekiSoyad(iMap.getString("K_ONCEKI_SOYADI"));
			birBasvuruKefilTx.setSigortaliMi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("K_SIGORTALI_MI")));
			birBasvuruKefilTx.setSoyad(iMap.getString("K_SOYADI"));
			birBasvuruKefilTx.setTcKimlikNo(iMap.getString("K_TC_KIMLIK_NO"));
			birBasvuruKefilTx.setUnvanKod(iMap.getString("K_UNVANI"));
			birBasvuruKefilTx.setUyruk("TR");
			if (iMap.getBoolean("K_YAZISMA_ADRESI_EV"))
				birBasvuruKefilTx.setYazismaAdresKod("E");
			else if (iMap.getBoolean("K_YAZISMA_ADRESI_IS"))
				birBasvuruKefilTx.setYazismaAdresKod("I");
			if (iMap.getString("K_KIMLIK_SERI_NO_KPS") != null && iMap.getString("K_KIMLIK_SIRA_NO_KPS") != null) {
				birBasvuruKefilTx.setKimlikSeriSiraNoKps(iMap.getString("K_KIMLIK_SERI_NO_KPS") + iMap.getString("K_KIMLIK_SIRA_NO_KPS"));
			}
			else {
				birBasvuruKefilTx.setKimlikSeriSiraNoKps(null);
			}
			birBasvuruKefilTx.setKimlikSeriSiraNoKps(iMap.getString("K_KIMLIK_SERI_NO_KPS") + iMap.getString("K_KIMLIK_SIRA_NO_KPS"));
			birBasvuruKefilTx.setNufusIlKod(iMap.getString("K_NUFUS_IL_KOD"));
			birBasvuruKefilTx.setNufusIlceKod(iMap.getString("K_NUFUS_ILCE_KOD"));
			birBasvuruKefilTx.setMahalleKoy(iMap.getString("K_NUFUS_MAHALLE")); // "K_MAHALLE_KOY"
			birBasvuruKefilTx.setCiltNo(iMap.getString("K_NUFUS_CILT_NO")); // "K_CILT_NO"
			birBasvuruKefilTx.setAileSiraNo(iMap.getString("K_NUFUS_AILE_SIRA_NO")); // "K_AILE_SIRA_NO"
			birBasvuruKefilTx.setBireySiraNo(iMap.getString("K_NUFUS_SIRA_NO")); // "K_BIREY_SIRA_NO"
			birBasvuruKefilTx.setNufusVerTar(iMap.getDate("K_NUFUS_VERILIS_TARIHI")); // "K_NUFUS_VER_TAR"
			birBasvuruKefilTx.setNufusVerYer(iMap.getString("K_NUF_VERILDIGI_YER")); // "K_NUFUS_VER_YER"
			birBasvuruKefilTx.setNufusVerNedeni(iMap.getString("K_NUF_VERILIS_NEDENI")); // "K_NUFUS_VER_NEDENI"
			if (iMap.getString("K_KAYIP_CUZDAN_SERI") != null && iMap.getString("K_KAYIP_CUZDAN_NO") != null) {
				birBasvuruKefilTx.setKayipKimlikSeriSiraNo(iMap.getString("K_KAYIP_CUZDAN_SERI") + iMap.getString("K_KAYIP_CUZDAN_NO")); // "K_KAYIP_KIMLIK_SERI_NO" "K_KAYIP_KIMLIK_SIRA_NO"
			}
			else {
				birBasvuruKefilTx.setKayipKimlikSeriSiraNo(null);
			}
			birBasvuruKefilTx.setSil("H");
			session.saveOrUpdate(birBasvuruKefilTx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static void putKPSDetails(GMMap iMap) {
		GMMap kpsMap = (GMMap) ADCSession.get("KPS_MAP");

		if (kpsMap != null && iMap.getString("K_TC_KIMLIK_NO").equals(kpsMap.getString("TCKNO_OUT"))) {
			iMap.put("K_ADI", kpsMap.getString("AD1", iMap.getString("K_ADI")));
			iMap.put("K_IKINCI_ADI", kpsMap.getString("AD2", iMap.getString("K_IKINCI_ADI")));
			iMap.put("K_SOYADI", kpsMap.getString("SOYAD", iMap.getString("K_SOYADI")));
			iMap.put("K_ANNE_ADI", kpsMap.getString("ANNE_AD", iMap.getString("K_ANNE_ADI")));
			// iMap.put("K_ANNE_KIZLIK_SOYADI", kefilMap.get("KIZLIK_SOYAD", iMap.getString("K_ANNE_KIZLIK_SOYADI")));
			iMap.put("K_BABA_ADI", kpsMap.getString("BABA_AD", iMap.getString("K_BABA_ADI")));
			iMap.put("K_CINSIYET", kpsMap.getString("CINSIYET", iMap.getString("K_CINSIYET")).charAt(0) + "");
			iMap.put("K_DOGUM_TARIHI", kpsMap.getString("DOGUM_TARIHI", iMap.getString("K_DOGUM_TARIHI")));
			iMap.put("K_DOGUM_YERI", kpsMap.getString("DOGUM_YERI", iMap.getString("K_DOGUM_YERI")));
			iMap.put("K_MEDENI_HAL", kpsMap.getString("MEDENI_HALI", iMap.getString("K_MEDENI_HAL")).charAt(0) == 'E' ? 1 : 2);
			iMap.put("K_NUFUS_IL_KOD", kpsMap.getString("IL_KODU", iMap.getString("K_NUFUS_IL_KOD")));
			iMap.put("K_NUFUS_ILCE_KOD", kpsMap.getString("ILCE_KODU", iMap.getString("K_NUFUS_ILCE_KOD")));
			iMap.put("K_NUFUS_MAHALLE", kpsMap.getString("MAHALLE_KOY", iMap.getString("K_NUFUS_MAHALLE")));
			iMap.put("K_NUFUS_CILT_NO", kpsMap.getString("CILT_KODU", iMap.getString("K_NUFUS_CILT_NO")));
			iMap.put("K_NUFUS_AILE_SIRA_NO", kpsMap.getString("AILE_SIRA_NO", iMap.getString("K_NUFUS_AILE_SIRA_NO")));
			iMap.put("K_NUFUS_SIRA_NO", kpsMap.getString("BIREY_SIRA_NO", iMap.getString("K_NUFUS_SIRA_NO")));
			iMap.put("K_KIMLIK_SERI_NO_KPS", kpsMap.getString("KIMLIK_SERI_NO", iMap.getString("K_KIMLIK_SERI_NO_KPS")));
			iMap.put("K_KIMLIK_SIRA_NO_KPS", kpsMap.getString("KIMLIK_SIRA_NO", iMap.getString("K_KIMLIK_SIRA_NO_KPS")));
			iMap.put("K_NUFUS_VERILIS_TARIHI", kpsMap.getString("VERILIS_TARIHI", iMap.getString("K_NUFUS_VERILIS_TARIHI")));
			iMap.put("K_NUF_VERILDIGI_YER", kpsMap.getString("VERILDIGI_ILCE_KODU", iMap.getString("K_NUF_VERILDIGI_YER")));
			iMap.put("K_NUF_VERILIS_NEDENI", kpsMap.getString("VERILIS_NEDENI", iMap.getString("K_NUF_VERILIS_NEDENI")));
		}
	}

	@GraymoundService("BNSPR_TRN3171_CONTROL_KEFIL")
	public static Map<?, ?> controlKefil(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			putKPSDetails(iMap);
			fillKefilTxTable(iMap);

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.KefilKontrol(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GECICI_NBSM")
	public static Map<?, ?> geciciNBSM(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("PARAMETRE", "KEFIL_ALINSIN");
			oMap.put("KEFIL_GEREKLI", (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
			oMap.put("KEFIL_SAYISI", "2");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3171_GET_KEFIL_LIST")
	public static GMMap getCaprazKayitList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			stmt = conn.prepareCall("{? = call PKG_TRN3171.RC_QRY3171_KEFIL_LIST(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));

			if (!(iMap.getString("ACTION") != null && iMap.getString("ACTION").equals("VIEW"))) {
				String tableName = "RESULTS";
				List<?> kefilList = (List<?>) oMap.get(tableName);
				if (kefilList != null) {
					for (int i = 0; i < kefilList.size(); i++) {
						GMMap kefilMap = new GMMap((HashMap<?, ?>) kefilList.get(i));
						BirBasvuruKefilTx eskiKefilTx = (BirBasvuruKefilTx) session.createCriteria(BirBasvuruKefilTx.class).add(Restrictions.eq("id.txNo", kefilMap.getBigDecimal("KEFIL_TX_NO"))).add(Restrictions.eq("id.kefilNo", kefilMap.getBigDecimal("KEFIL_NO"))).uniqueResult();
						BirBasvuruKefilTx yeniKefilTx = (BirBasvuruKefilTx) DALUtil.clonePojo(eskiKefilTx);
						if (!eskiKefilTx.getId().getTxNo().equals(iMap.getBigDecimal("TRX_NO"))) {
							BirBasvuruKefilTxId kefilId = new BirBasvuruKefilTxId();
							kefilId.setTxNo(iMap.getBigDecimal("TRX_NO"));
							kefilId.setKefilNo(kefilMap.getBigDecimal("KEFIL_NO"));
							yeniKefilTx.setId(kefilId);
							session.saveOrUpdate(yeniKefilTx);
							session.flush();

							stmt = conn.prepareCall("{call pkg_basvuru.KefilKontrol(?)}");

							stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
							stmt.execute();

							oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
							iMap.put("TCK_NO", yeniKefilTx.getTcKimlikNo());
							oMap.putAll(GMServiceExecuter.execute("BNSPR_TCK_NO_GET_BAYI_BILGILERI", iMap));
							oMap.put("KEFIL_NO", kefilId.getKefilNo());
							GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE_KEFIL", oMap);
						}
					}
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KEFIL_ONAY")
	public static GMMap kefilOnay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.KefilOnay(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KEFIL_BILGILERI")
	public static GMMap getKefilBilgileri(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuruKefilTx birBasvuruKefilTx = (BirBasvuruKefilTx) session.createCriteria(BirBasvuruKefilTx.class).add(Restrictions.eq("id.kefilNo", iMap.getBigDecimal("KEFIL_NO"))).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birBasvuruKefilTx != null) {
				oMap.put("TRX_NO", birBasvuruKefilTx.getId().getTxNo());
				oMap.put("BASVURU_NO", birBasvuruKefilTx.getBasvuruNo());
				oMap.put("K_SIRA_NO", birBasvuruKefilTx.getSiraNo());
				oMap.put("K_ADI", birBasvuruKefilTx.getAd());
				oMap.put("K_ANNE_ADI", birBasvuruKefilTx.getAnneAdi());
				oMap.put("K_ANNE_KIZLIK_SOYADI", birBasvuruKefilTx.getAnneKizlik());
				oMap.put("K_AYLIK_GELIR", birBasvuruKefilTx.getAylikGelir());

				if (birBasvuruKefilTx.getAyniAdresFaaliyetSure() != null && birBasvuruKefilTx.getAyniAdresFaaliyetSure().length() > 3) {
					String adresteFaaliyetSuresiYil = birBasvuruKefilTx.getAyniAdresFaaliyetSure().substring(0, 2);
					// if(!adresteFaaliyetSuresiYil.equals("00"))
					{
						if (adresteFaaliyetSuresiYil.charAt(0) == '0')
							adresteFaaliyetSuresiYil = adresteFaaliyetSuresiYil.substring(1);
					}
					String adresteFaaliyetSuresiAy = birBasvuruKefilTx.getAyniAdresFaaliyetSure().substring(2, 4);
					// if(!adresteFaaliyetSuresiAy.equals("00"))
					{
						if (adresteFaaliyetSuresiAy.charAt(0) == '0')
							adresteFaaliyetSuresiAy = adresteFaaliyetSuresiAy.substring(1);
					}
					oMap.put("K_FAALIYET_SURESI_YIL", adresteFaaliyetSuresiYil);
					oMap.put("K_FAALIYET_SURESI_AY", adresteFaaliyetSuresiAy);
				}

				oMap.put("K_BABA_ADI", birBasvuruKefilTx.getBabaAd());
				oMap.put("K_CALISMA_SEKLI", birBasvuruKefilTx.getCalismaSekliKod());
				oMap.put("K_CEP_TEL_KOD", birBasvuruKefilTx.getCepTelAlanKod());
				oMap.put("K_CEP_TEL_NO", birBasvuruKefilTx.getCepTelNo());
				oMap.put("K_CINSIYET", birBasvuruKefilTx.getCinsiyet());
				oMap.put("K_DOGUM_TARIHI", birBasvuruKefilTx.getDogumTar());
				oMap.put("K_DOGUM_YERI", birBasvuruKefilTx.getDogumYeri());
				oMap.put("K_OGRENIM_DURUMU", birBasvuruKefilTx.getEgitimDurumKod());

				if (birBasvuruKefilTx.getEMail() != null && birBasvuruKefilTx.getEMail().length() > 1) {
					oMap.put("K_EMAIL1", birBasvuruKefilTx.getEMail().substring(0, birBasvuruKefilTx.getEMail().indexOf('@')));
					oMap.put("K_EMAIL2", birBasvuruKefilTx.getEMail().substring(birBasvuruKefilTx.getEMail().indexOf('@') + 1));
				}

				oMap.put("K_EV_ADRESI", birBasvuruKefilTx.getEvAdres());
				oMap.put("K_EV_ILCE", birBasvuruKefilTx.getEvAdresIlceKod());
				oMap.put("K_EV_IL", birBasvuruKefilTx.getEvAdresIlKod());
				oMap.put("K_EV_POSTA_KODU", birBasvuruKefilTx.getEvPostaKod());
				oMap.put("K_EV_TEL_KOD", birBasvuruKefilTx.getEvTelAlanKod());
				oMap.put("K_EV_TEL_NO", birBasvuruKefilTx.getEvTelNo());
				oMap.put("K_GMENKUL_GELIR", birBasvuruKefilTx.getGmenkulGelir());
				oMap.put("K_IKAMET_DURUMU", birBasvuruKefilTx.getIkametDurumKod());
				oMap.put("K_IKINCI_ADI", birBasvuruKefilTx.getIkinciAd());
				oMap.put("K_IS_ADRESI", birBasvuruKefilTx.getIsAdres());
				oMap.put("K_IS_ILCE", birBasvuruKefilTx.getIsAdresIlceKod());
				oMap.put("K_IS_IL", birBasvuruKefilTx.getIsAdresIlKod());
				oMap.put("K_IS_POSTA_KODU", birBasvuruKefilTx.getIsPostaKod());
				oMap.put("K_IS_TEL_KOD", birBasvuruKefilTx.getIsTelAlanKod());
				oMap.put("K_IS_TEL_DAHILI", birBasvuruKefilTx.getIsTelDahili());
				oMap.put("K_IS_TEL_NO", birBasvuruKefilTx.getIsTelNo());
				oMap.put("K_ISYERI_ADI", birBasvuruKefilTx.getIsyeriAdi());
				oMap.put("K_ISYERI_FAALIYET_ALANI", birBasvuruKefilTx.getIsyeriFaalKonuKod());
				oMap.put("K_ISYERI_MULKIYET", birBasvuruKefilTx.getIsyeriMulkiyetKod());
				oMap.put("K_ISYERI_VERGI_DAIRESI_IL", birBasvuruKefilTx.getIsyeriVergiDaireIlKodu());
				oMap.put("K_ISYERI_VERGI_DAIRESI_ADI", birBasvuruKefilTx.getIsyeriVergiDaireKodu());
				oMap.put("K_ISYERI_VERGI_NO", birBasvuruKefilTx.getIsyeriVergiNo());
				oMap.put("K_KEFIL_TIP_KOD", birBasvuruKefilTx.getKefilTipKod());
				oMap.put("K_KEFIL_YAKINLIGI", birBasvuruKefilTx.getKefilYakinligi());

				if (birBasvuruKefilTx.getKimlikSeriSiraNo() != null && birBasvuruKefilTx.getKimlikSeriSiraNo().length() > 3) {
					oMap.put("K_KIMLIK_SERI_NO", birBasvuruKefilTx.getKimlikSeriSiraNo().substring(0, 3));
					oMap.put("K_KIMLIK_SIRA_NO", birBasvuruKefilTx.getKimlikSeriSiraNo().substring(3));
				}

				oMap.put("K_MEDENI_HAL", birBasvuruKefilTx.getMedeniHal());
				oMap.put("K_MESLEK", birBasvuruKefilTx.getMeslekKod());

				if (birBasvuruKefilTx.getMevcutAdresOturmaSure() != null && birBasvuruKefilTx.getMevcutAdresOturmaSure().length() > 3) {
					String adresteOturmaSuresiYil = birBasvuruKefilTx.getMevcutAdresOturmaSure().substring(0, 2);
					// if(!adresteOturmaSuresiYil.equals("00"))
					{
						if (adresteOturmaSuresiYil.charAt(0) == '0')
							adresteOturmaSuresiYil = adresteOturmaSuresiYil.substring(1);
					}
					String adresteOturmaSuresiAy = birBasvuruKefilTx.getMevcutAdresOturmaSure().substring(2, 4);
					// if(!adresteFaaliyetSuresiAy.equals("00"))
					{
						if (adresteOturmaSuresiAy.charAt(0) == '0')
							adresteOturmaSuresiAy = adresteOturmaSuresiAy.substring(1);
					}
					oMap.put("K_MEVCUT_ADRESTE_OTURMA_SURESI_YIL", adresteOturmaSuresiYil);
					oMap.put("K_MEVCUT_ADRESTE_OTURMA_SURESI_AY", adresteOturmaSuresiAy);
				}

				if (birBasvuruKefilTx.getMevcutIsyeriCalismaSure() != null && birBasvuruKefilTx.getMevcutIsyeriCalismaSure().length() > 3) {
					String isyerindeCalismaSuresiYil = birBasvuruKefilTx.getMevcutIsyeriCalismaSure().substring(0, 2);
					// if(!adresteOturmaSuresiYil.equals("00"))
					{
						if (isyerindeCalismaSuresiYil.charAt(0) == '0')
							isyerindeCalismaSuresiYil = isyerindeCalismaSuresiYil.substring(1);
					}
					String isyerindeCalismaSuresiAy = birBasvuruKefilTx.getMevcutIsyeriCalismaSure().substring(2, 4);
					// if(!adresteFaaliyetSuresiAy.equals("00"))
					{
						if (isyerindeCalismaSuresiAy.charAt(0) == '0')
							isyerindeCalismaSuresiAy = isyerindeCalismaSuresiAy.substring(1);
					}
					oMap.put("K_ISYERINDE_CALISMA_SURESI_YIL", isyerindeCalismaSuresiYil);
					oMap.put("K_ISYERINDE_CALISMA_SURESI_AY", isyerindeCalismaSuresiAy);
				}

				oMap.put("K_ONCEKI_SOYADI", birBasvuruKefilTx.getOncekiSoyad());
				oMap.put("K_SIGORTALI_MI", GuimlUtil.convertToCheckBoxSelected(birBasvuruKefilTx.getSigortaliMi()));
				oMap.put("K_SOYADI", birBasvuruKefilTx.getSoyad());
				oMap.put("K_TC_KIMLIK_NO", birBasvuruKefilTx.getTcKimlikNo());
				oMap.put("K_UNVANI", birBasvuruKefilTx.getUnvanKod());
				oMap.put("K_YAZISMA_ADRESI_EV", birBasvuruKefilTx.getYazismaAdresKod().equals("E"));
				oMap.put("K_YAZISMA_ADRESI_IS", birBasvuruKefilTx.getYazismaAdresKod().equals("I"));

				if (birBasvuruKefilTx.getKimlikSeriSiraNoKps() != null && birBasvuruKefilTx.getKimlikSeriSiraNoKps().length() > 3) {
					oMap.put("K_KIMLIK_SERI_NO_KPS", birBasvuruKefilTx.getKimlikSeriSiraNoKps().substring(0, 3));
					oMap.put("K_KIMLIK_SIRA_NO_KPS", birBasvuruKefilTx.getKimlikSeriSiraNoKps().substring(3));
				}

				oMap.put("K_NUFUS_IL_KOD", birBasvuruKefilTx.getNufusIlKod());
				oMap.put("K_NUFUS_ILCE_KOD", birBasvuruKefilTx.getNufusIlceKod());
				oMap.put("K_MAHALLE_KOY", birBasvuruKefilTx.getMahalleKoy());
				oMap.put("K_NUFUS_CILT_NO", birBasvuruKefilTx.getCiltNo());
				oMap.put("K_NUFUS_AILE_SIRA_NO", birBasvuruKefilTx.getAileSiraNo());
				oMap.put("K_NUFUS_SIRA_NO", birBasvuruKefilTx.getBireySiraNo());
				oMap.put("K_NUFUS_VERILIS_TARIHI", birBasvuruKefilTx.getNufusVerTar());
				oMap.put("K_NUF_VERILDIGI_YER", birBasvuruKefilTx.getNufusVerYer());
				oMap.put("K_NUF_VERILIS_NEDENI", birBasvuruKefilTx.getNufusVerNedeni());

				if (birBasvuruKefilTx.getKayipKimlikSeriSiraNo() != null && birBasvuruKefilTx.getKayipKimlikSeriSiraNo().length() > 3) {
					oMap.put("K_KAYIP_CUZDAN_SERI", birBasvuruKefilTx.getKayipKimlikSeriSiraNo().substring(0, 3));
					oMap.put("K_KAYIP_CUZDAN_NO", birBasvuruKefilTx.getKayipKimlikSeriSiraNo().substring(3));
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_KEFIL_SIL")
	public static Map<?, ?> deleteKefil(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> silKefilList = session.createCriteria(BirBasvuruKefilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayKefiller = silKefilList.toArray();
			for (int i = 0; i < arrayKefiller.length; i++) {
				if (((BirBasvuruKefilTx) arrayKefiller[i]).getId().getKefilNo().compareTo(iMap.getBigDecimal("KEFIL_NO")) == 0) {
					((BirBasvuruKefilTx) arrayKefiller[i]).setSiraNo(new BigDecimal(0));
					((BirBasvuruKefilTx) arrayKefiller[i]).setSil("E");
					session.saveOrUpdate(arrayKefiller[i]);
				}
				else if (!(((BirBasvuruKefilTx) arrayKefiller[i]).getSil() != null && ((BirBasvuruKefilTx) arrayKefiller[i]).getSil().equals("E")) && ((BirBasvuruKefilTx) arrayKefiller[i]).getSiraNo().compareTo(new BigDecimal(2)) == 0) {
					((BirBasvuruKefilTx) arrayKefiller[i]).setSiraNo(new BigDecimal(1));
					session.saveOrUpdate(arrayKefiller[i]);
				}
			}
			session.flush();
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CHECK_KEFIL_TCKN")
	public static Map<?, ?> checkKefilTCKN(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_BASVURU.CheckKefil(?, ? , ?,? )}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KEFIL_NO"));
			stmt.setString(i++, iMap.getString("TCKN"));

			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BASVURU_SEND_SMS")
	public static GMMap sendSMS(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BASVURU.SendSms(?,?,?,?)}");
			int pc = 1;
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("TRX_NO") == null ? iMap.getBigDecimal("ISLEM_NO") : iMap.getBigDecimal("TRX_NO"));
			stmt.setString(pc++, iMap.getString("ISLEM_KODU"));
			stmt.registerOutParameter(pc++, Types.VARCHAR);
			stmt.registerOutParameter(pc++, Types.VARCHAR);

			stmt.execute();
			String mesaj = stmt.getString(--pc);
			String cepTel = stmt.getString(--pc);

			if (mesaj != null) {
				iMap.put("MSISDN", cepTel);
				iMap.put("CONTENT", mesaj);
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap).get("RESULT");
				// if(!mesg.substring(0, 1).equals("-"))
				// System.out.println(cepTel+" numarali telefona -"+ iMap.getString("CONTENT")+ "- mesaji gonderilmistir.");
			}
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_APS_SORGULAMA")
	public static GMMap getAdresBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap sMap = new GMMap();
			GMMap i2Map = new GMMap();
			sMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
			//sMap = new GMMap(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_KPS_GET_KISI_BILGILERI", sMap));
			sMap = GMServiceExecuter.call("BNSPR_KPS_GET_KISI_ADRES_BILGISI", sMap);			

			if (sMap.getInt("HATA_KOD") == 0) {
				KisiAdresBilgileriModel kisiAdresBilgisi = (KisiAdresBilgileriModel) sMap.get("KISI_ADRES_BILGISI");

				oMap.put("ADRES_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getAdresNo());
				oMap.put("BUCAK", kisiAdresBilgisi.getYerlesimYeriAdresi().getBucak());
				oMap.put("BUCAK_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getBucakKodu());
				oMap.put("CSBM", kisiAdresBilgisi.getYerlesimYeriAdresi().getCsbm());
				oMap.put("CSBM_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getCsbmKodu());
				oMap.put("DIS_KAPI_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getDisKapiNo());
				oMap.put("IC_KAPI_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getIcKapiNo());
				oMap.put("IL", kisiAdresBilgisi.getYerlesimYeriAdresi().getIl());
				oMap.put("ILCE", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlce());
				oMap.put("ILCE_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlceKodu());
				oMap.put("IL_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlKodu());
				oMap.put("KOY", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoy());
				oMap.put("KOY_KAYIT_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoyKayitNo());
				oMap.put("KOY_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoyKodu());
				oMap.put("MAHALLE", kisiAdresBilgisi.getYerlesimYeriAdresi().getMahalle());
				oMap.put("MAHALLE_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getMahalleKodu());

				if (oMap.getString("MUSTERI_NO") == null) {
					oMap.put("MUSTERI_NO", GMServiceExecuter.call("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", sMap).getBigDecimal("CUSTOMER_NO"));
				}

				i2Map.putAll(oMap);
				i2Map.put("TRX_NO", iMap.get("TRX_NO"));

				GMServiceExecuter.execute("BNSPR_SAVE_APS", i2Map);

				oMap.put("APS_YAPILDIMI", "E");

			}
			else if (sMap.getInt("HATA_KOD") == 2) {
				oMap.put("APS_YAPILDIMI", "E");
			}
			else {
				oMap.put("APS_YAPILDIMI", "H");
			}

		}
		catch (Exception e) {
			oMap.put("APS_YAPILDIMI", "H");
		}
		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3171_GET_APS_INFO")
	public static GMMap getAdresBilgileriInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<BirBasvuruTx> basvuruList = session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("txNo")).list();
			GnlMusteriApsTx gnlMusteriApsTx = null;
			for (BirBasvuruTx basvuru : basvuruList) {
				gnlMusteriApsTx = (GnlMusteriApsTx) session.createCriteria(GnlMusteriApsTx.class).add(Restrictions.eq("txNo", basvuru.getTxNo())).uniqueResult();
				if (gnlMusteriApsTx != null)
					break;
			}
			if (gnlMusteriApsTx != null) {
				oMap.put("ADRES_NO", gnlMusteriApsTx.getApsAdresNo());

				if (gnlMusteriApsTx.getApsAdresNo() != null)
					oMap.put("F_APS", "E");
				else
					oMap.put("F_APS", "H");

				oMap.put("BUCAK", gnlMusteriApsTx.getApsBucak());
				oMap.put("BUCAK_KOD", gnlMusteriApsTx.getApsBucakKod());
				oMap.put("CSBM", gnlMusteriApsTx.getApsCsbm());
				oMap.put("CSBM_KODU", gnlMusteriApsTx.getApsCsbmKodu());
				oMap.put("DIS_KAPI_NO", gnlMusteriApsTx.getApsDisKapiNo());
				oMap.put("IC_KAPI_NO", gnlMusteriApsTx.getApsIcKapiNo());
				oMap.put("IL", gnlMusteriApsTx.getApsIl());
				oMap.put("ILCE", gnlMusteriApsTx.getApsIlce());
				oMap.put("ILCE_KODU", gnlMusteriApsTx.getApsIlceKodu());
				oMap.put("IL_KODU", gnlMusteriApsTx.getApsIlKodu());
				oMap.put("KOY", gnlMusteriApsTx.getApsKoy());
				oMap.put("KOY_KAYIT_NO", gnlMusteriApsTx.getApsKoyKayitNo());
				oMap.put("KOY_KOD", gnlMusteriApsTx.getApsKoyKod());
				oMap.put("MAHALLE", gnlMusteriApsTx.getApsMahalle());
				oMap.put("MAHALLE_KOD", gnlMusteriApsTx.getApsMahalleKod());
				oMap.put("F_APS_TEYIT", "E".equals(gnlMusteriApsTx.getFApsTeyit()) ? true : false);
				oMap.put("YABANCI_ULKE_KOD", gnlMusteriApsTx.getApsYabanciUlkeKod());
			}

		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE")
	public static Map<?, ?> kontaktMusteriGuncelle(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			Session session = DAOSession.getSession("BNSPRDal");
			BirKampanya birKampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", iMap.getBigDecimal("KAMP_KOD"))).uniqueResult();
			String ticariKrediEh = "H";
			if (birKampanya != null) {
				ticariKrediEh = birKampanya.getTicariKrediEh();
			}

			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI").trim());
			}

			iMap.put("KONTAKT_NO", iMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("tckno_in", iMap.getString("TC_KIMLIK_NO"));
			iMap.put("ACTION", "NEW");
			GMMap kontakt = new GMMap();

			kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_GET_INFO", iMap));
			if (iMap.get("MUSTERI_KONTAKT") == null) {
				GnlMusteri musteri = (GnlMusteri) session.get(GnlMusteri.class, iMap.getBigDecimal("MUSTERI_NO"));
				kontakt.put("MUSTERI_KONTAKT", musteri.getMusteriKontakt());
			}
			else {
				kontakt.put("MUSTERI_KONTAKT", iMap.get("MUSTERI_KONTAKT"));
			}

			kontakt.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
			if (kontakt.getString("UYRUK_KOD") != null && !kontakt.getString("UYRUK_KOD").isEmpty()) {
				if (kontakt.getString("UYRUK_KOD") != null)
					kontakt.remove("UYRUK_KOD");
				kontakt.put("UYRUK_KOD", "TR");
			}
			if (kontakt.getString("MUSTERI_KONTAKT") == null || kontakt.getString("MUSTERI_KONTAKT").isEmpty()) {
				if (kontakt.getString("MUSTERI_KONTAKT") != null)
					kontakt.remove("MUSTERI_KONTAKT");
				kontakt.put("MUSTERI_KONTAKT", "K");
			}
			if ("M".equals(kontakt.getString("MUSTERI_KONTAKT")) && !"7".equals(iMap.getString("KANAL_KODU"))) {
				return new GMMap();
			}
			if (kontakt.getString("MUSTERI_TIPI_KOD") == null || kontakt.getString("MUSTERI_TIPI_KOD").isEmpty()) {
				if (kontakt.getString("MUSTERI_TIPI_KOD") != null)
					kontakt.remove("MUSTERI_TIPI_KOD");
				kontakt.put("MUSTERI_TIPI_KOD", "G");
			}
			if ((kontakt.getString("KANAL_KODU") == null || kontakt.getString("KANAL_KODU").isEmpty()) && (kontakt.getString("BAGLI_KANAL_GRUBU") == null || kontakt.getString("BAGLI_KANAL_GRUBU").isEmpty())) {
				if (kontakt.getString("KANAL_KODU") != null)
					kontakt.remove("KANAL_KODU");
				kontakt.put("KANAL_KODU", iMap.getString("KANAL_ALT_KODU"));
			}
			if (kontakt.getString("BAGLI_KANAL_GRUBU") == null || kontakt.getString("BAGLI_KANAL_GRUBU").isEmpty()) {
				if (kontakt.getString("BAGLI_KANAL_GRUBU") != null)
					kontakt.remove("BAGLI_KANAL_GRUBU");
				kontakt.put("BAGLI_KANAL_GRUBU", iMap.getString("KANAL_KODU"));
			}
			if (kontakt.getString("MUSTERI_SEGMENTI") == null || kontakt.getString("MUSTERI_SEGMENTI").isEmpty()) {
				if (kontakt.getString("MUSTERI_SEGMENTI") != null)
					kontakt.remove("MUSTERI_SEGMENTI");
				kontakt.put("MUSTERI_SEGMENTI", "N");
			}
			if (kontakt.getString("DK_GRUP_KOD") == null || kontakt.getString("DK_GRUP_KOD").isEmpty()) {
				if (kontakt.getString("DK_GRUP_KOD") != null)
					kontakt.remove("DK_GRUP_KOD");
				/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
				if ("E".equals(ticariKrediEh))
					kontakt.put("DK_GRUP_KOD", new BigDecimal("1043"));
				else
					kontakt.put("DK_GRUP_KOD", new BigDecimal("1042"));
			}
			if (kontakt.getString("YERLESIM_KOD") == null || kontakt.getString("YERLESIM_KOD").isEmpty()) {
				if (kontakt.getString("YERLESIM_KOD") != null)
					kontakt.remove("YERLESIM_KOD");
				kontakt.put("YERLESIM_KOD", "I");
			}
			if (kontakt.getString("PROFIL_KOD") == null || kontakt.getString("PROFIL_KOD").isEmpty()) {
				if (kontakt.getString("PROFIL_KOD") != null)
					kontakt.remove("PROFIL_KOD");
				/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
				if ("E".equals(ticariKrediEh))
					kontakt.put("PROFIL_KOD", "4");
				else {
					kontakt.put("PROFIL_KOD", "1");
				}
			}
			if (kontakt.getString("HESAP_UCRETI_F") == null || kontakt.getString("HESAP_UCRETI_F").isEmpty()) {
				if (kontakt.getString("HESAP_UCRETI_F") != null)
					kontakt.remove("HESAP_UCRETI_F");
				kontakt.put("HESAP_UCRETI_F", "H");
			}

			if (kontakt.getString("MUSTERI_GRUP_KOD") == null || kontakt.getString("MUSTERI_GRUP_KOD").isEmpty()) {
				if (kontakt.getString("MUSTERI_GRUP_KOD") != null)
					kontakt.remove("MUSTERI_GRUP_KOD");
				if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{? = call pkg_kampanya.Kamp_MusteriGrupKod(?)}");
					stmt.registerOutParameter(1, Types.VARCHAR);
					stmt.setBigDecimal(2, iMap.getBigDecimal("URUN_KAMP_KOD"));
					stmt.execute();
					if (stmt.getString(1) != null && stmt.getString(1).isEmpty() == false)
						kontakt.put("MUSTERI_GRUP_KOD", stmt.getString(1));
					else
						kontakt.put("MUSTERI_GRUP_KOD", "1"); // normal musteri
				}
				else
					kontakt.put("MUSTERI_GRUP_KOD", "1"); // normal musteri
			}

			if (kontakt.getSize("GRUP_KOD") == 0 || !GuimlUtil.contains((List<?>) kontakt.get("GRUP_KOD"), "MUSTERI_GRUP_KOD", kontakt.get("MUSTERI_GRUP_KOD"))) {
				int grupKodInd = kontakt.getSize("GRUP_KOD");
				kontakt.put("GRUP_KOD", grupKodInd, "MUSTERI_GRUP_KOD", kontakt.getString("MUSTERI_GRUP_KOD"));
				kontakt.put("GRUP_KOD", grupKodInd, "MUSTERI_GRUP_ADI", LovHelper.diLov(kontakt.getString("MUSTERI_GRUP_KOD"), "10011/LOV_MUSTERI_GRUBU", "ACIKLAMA"));
			}

			// if(kontakt.getString("PORTFOY_KOD") == null || kontakt.getString("PORTFOY_KOD").isEmpty())
			{
				if (kontakt.getString("PORTFOY_KOD") != null)
					kontakt.remove("PORTFOY_KOD");
				kontakt.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD"));
			}
			// if(kontakt.getString("BOLUM_KODU") == null || kontakt.getString("BOLUM_KODU").isEmpty())
			{
				if (kontakt.getString("BOLUM_KODU") != null)
					kontakt.remove("BOLUM_KODU");
				kontakt.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", kontakt.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));
			}
			if (kontakt.getString("MUSTERIYI_KAZANDIRAN") == null || kontakt.getString("MUSTERIYI_KAZANDIRAN").isEmpty()) {
				if (iMap.getString("KANAL_KOD") != null && iMap.getString("KANAL_KOD").equals("3") && iMap.getString("KANAL_KOD").equals(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap).get("KANAL_KOD"))) {
					if (kontakt.getString("MUSTERIYI_KAZANDIRAN") != null)
						kontakt.remove("MUSTERIYI_KAZANDIRAN");
					kontakt.put("MUSTERIYI_KAZANDIRAN", GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANICI_KOD", iMap).get("KULLANICI_KOD"));
				}
			}
			if (kontakt.getString("KAZANIM_KANALI") == null || kontakt.getString("KAZANIM_KANALI").isEmpty()) {
				if (kontakt.getString("KAZANIM_KANALI") != null)
					kontakt.remove("KAZANIM_KANALI");
				kontakt.put("KAZANIM_KANALI", iMap.getString("KANAL_KODU"));
			}

			/** web kredide kazanim kanali guncellenecek **/
			if ("8".equals(iMap.getString("KANAL_KODU")) || "5".equals(iMap.getString("KANAL_KODU"))) {
				kontakt.put("KAZANIM_KANALI", iMap.getString("KANAL_KODU"));
				kontakt.put("KAZANIM_URUNU", "BRY");
			}

			if (kontakt.getBoolean("F_SAHTE")) {
				kontakt.remove("F_SAHTE");
				kontakt.put("F_SAHTE", "1");
			}
			else {
				kontakt.remove("F_SAHTE");
				kontakt.put("F_SAHTE", "0");
			}
			if (kontakt.getBoolean("F_MUSTERIYE_CEVRILEBILIR")) {
				kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "1");
			}
			else {
				kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "0");
			}

			kontakt.put("TCKNO_IN", iMap.getBigDecimal("TC_KIMLIK_NO"));
			if ("E".equals(iMap.getString("KPS_YAPILDI")))
				kontakt.put("TCKNO_OUT", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("TC_KIMLIK_NO", iMap.getBigDecimal("TC_KIMLIK_NO"));
			kontakt.put("ISIM", iMap.getString("ISIM"));
			kontakt.put("IKINCI_ISIM", iMap.getString("IKINCI_ISIM"));
			kontakt.put("SOYADI", iMap.getString("SOYADI"));
			if (iMap.getString("UYRUK_KOD") != null && !iMap.getString("UYRUK_KOD").isEmpty())
				kontakt.put("UYRUK_KOD", iMap.getString("UYRUK_KOD"));
			else
				kontakt.put("UYRUK_KOD", "TR");
			kontakt.put("DOGUM_TARIHI", iMap.getDate("DOGUM_TARIHI"));
			kontakt.put("DOGUM_YERI", iMap.getString("DOGUM_YERI"));
			kontakt.put("BABA_ADI", iMap.getString("BABA_ADI"));
			kontakt.put("ANNE_ADI", iMap.getString("ANNE_ADI"));
			kontakt.put("CINSIYET_KOD", iMap.getString("CINSIYET_KOD"));
			kontakt.put("ANNE_KIZLIK_SOYADI", iMap.getString("ANNE_KIZLIK_SOYADI"));
			kontakt.put("MEDENI_HAL_KOD", iMap.getString("MEDENI_HAL_KOD"));
			kontakt.put("AILE_SIRA_NO", iMap.getString("AILE_SIRA_NO"));
			kontakt.put("CILT_NO", iMap.getString("CILT_NO"));
			kontakt.put("SIRA_NO", iMap.getString("SIRA_NO"));

			kontakt.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("NUFUS_CUZDANI_SERI_NO"));
			kontakt.put("KIZLIK_SOYADI", iMap.getString("KIZLIK_SOYADI"));
			kontakt.put("MESLEK_KOD", iMap.getString("MESLEK_KOD"));
			kontakt.put("EGITIM_KOD", iMap.getString("EGITIM_KOD"));
			kontakt.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			kontakt.put("F_ISTEGE_BAGLI_SIGORTALI", iMap.getString("SIGORTALI_MI"));
			kontakt.put("ISYERI_ADI", iMap.getString("ISYERI_ADI"));
			/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			if ("E".equals(ticariKrediEh)) {
				kontakt.put("TICARI_UNVAN", iMap.getString("ISYERI_ADI"));
				kontakt.put("VERGI_DAIRE_IL_KODU", iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
				kontakt.put("VERGI_DAIRE_KODU", iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
				kontakt.put("VERGI_NO", iMap.getString("ISYERI_VERGI_NO"));

				kontakt.put("SEKTOR_KOD", iMap.getString("SEKTOR_KOD"));
				kontakt.put("SEKTOR_ALT1_KODU", iMap.getString("SEKTOR_ALT1_KODU"));
				kontakt.put("SEKTOR_ALT2_KODU", iMap.getString("SEKTOR_ALT2_KODU"));

			}
			kontakt.put("UNVAN_KOD", iMap.getString("UNVANI"));
			kontakt.put("IL_KOD", iMap.getString("IL_KOD"));
			kontakt.put("ILCE_KOD", iMap.getString("ILCE_KOD"));
			kontakt.put("MAHALLE_KOY", iMap.getString("MAHALLE_KOY"));

			kontakt.put("KISA_AD", iMap.getString("ISIM") + " " + (iMap.getString("IKINCI_ISIM") == null ? "" : iMap.getString("IKINCI_ISIM") + " ") + iMap.getString("SOYADI"));

			if (iMap.getString("NUFUS_CUZDANI_SERI_NO") != null && !iMap.getString("NUFUS_CUZDANI_SERI_NO").isEmpty())
				kontakt.put("F_NUF", "E");

			kontakt.put("NUF_VERILIS_NEDENI", iMap.getString("NUF_VERILIS_NEDENI"));
			kontakt.put("VERILDIGI_YER", iMap.getString("VERILDIGI_YER"));
			kontakt.put("VERILDIGI_TARIH", iMap.getDate("VERILDIGI_TARIH"));

			ArrayList<HashMap<String, Object>> adresList = (ArrayList<HashMap<String, Object>>) kontakt.get("ADRES_LIST");
			String tableName = "ADRES_LIST";
			kontakt.remove("ADRES_LIST");
			ArrayList<HashMap<String, Object>> adresListNew = new ArrayList<HashMap<String, Object>>();
			boolean addApsAddress = true;
			boolean ekstreAdresAps = false;
			iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_APS_INFO", iMap));

			if (adresList != null) {
				for (int row = 0; row < adresList.size(); row++) {

					HashMap<String, Object> adrMap = adresList.get(row);
					if ("E".equals(adrMap.get("ADRES_KOD")) && (iMap.getString("EV_ADRES") == null || iMap.getString("EV_ADRES").isEmpty())) {
						HashMap<String, Object> rowData = new HashMap<String, Object>();

						rowData.put("ADRES_KOD", "E");
						rowData.put("ADRES", adrMap.get("ADRES"));
						rowData.put("SEMT", adrMap.get("SEMT"));
						rowData.put("ADRES_IL_KOD", adrMap.get("ADRES_IL_KOD"));
						rowData.put("ADRES_ILCE_KOD", adrMap.get("ADRES_ILCE_KOD"));
						rowData.put("ULKE_KOD", adrMap.get("ULKE_KOD"));
						rowData.put("POSTA_KOD", adrMap.get("POSTA_KOD"));
						rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_IS")));
						rowData.put("ADRES_TEYIT", false);
						rowData.put("UPD_DATE", adrMap.get("UPD_DATE"));
						if (!iMap.getBoolean("YAZISMA_ADRESI_IS"))
							rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertFromCheckBoxValue((String) adrMap.get("EXTRE_ADRES_KOD_F")));
						else
							rowData.put("EXTRE_ADRES_KOD_F", "H");
						rowData.put("ILK_GECERLILIK_TARIHI", adrMap.get("ILK_GECERLILIK_TARIHI"));
						rowData.put("SON_GECERLILIK_TARIHI", adrMap.get("SON_GECERLILIK_TARIHI"));

						adresListNew.add(rowData);
					}
					if ("I".equals(adrMap.get("ADRES_KOD")) && !("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "6".equals(iMap.getString("MAAS_ALINAN_KURUM"))) && (iMap.getString("IS_ADRES") == null || iMap.getString("IS_ADRES").isEmpty())) {
						HashMap<String, Object> rowData = new HashMap<String, Object>();
						rowData.put("ADRES_KOD", "I");
						rowData.put("ISYERI_UNVANI", adrMap.get("ISYERI_UNVANI"));
						rowData.put("ADRES", adrMap.get("ADRES"));
						rowData.put("SEMT", adrMap.get("SEMT"));
						rowData.put("ADRES_IL_KOD", adrMap.get("ADRES_IL_KOD"));
						rowData.put("ADRES_ILCE_KOD", adrMap.get("ADRES_ILCE_KOD"));
						rowData.put("ULKE_KOD", adrMap.get("ULKE_KOD"));
						rowData.put("POSTA_KOD", adrMap.get("POSTA_KOD"));
						rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_IS")));
						rowData.put("ADRES_TEYIT", false);
						rowData.put("UPD_DATE", adrMap.get("UPD_DATE"));
						if (!iMap.getBoolean("YAZISMA_ADRESI_EV"))
							rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertFromCheckBoxValue((String) adrMap.get("EXTRE_ADRES_KOD_F")));
						else
							rowData.put("EXTRE_ADRES_KOD_F", "H");
						rowData.put("ILK_GECERLILIK_TARIHI", adrMap.get("ILK_GECERLILIK_TARIHI"));
						rowData.put("SON_GECERLILIK_TARIHI", adrMap.get("SON_GECERLILIK_TARIHI"));

						adresListNew.add(rowData);
					}
					if ("A".equals(adrMap.get("ADRES_KOD"))) {
						HashMap<String, Object> rowData = new HashMap<String, Object>();
						rowData = getAPSAddressObject(iMap);
						if (rowData.get("ADRES") != null && adrMap.get("ADRES") != null && rowData.get("ADRES").toString().equals(adrMap.get("ADRES").toString())) {
							rowData.put("ADRES_KOD", "A");
							rowData.put("ISYERI_UNVANI", adrMap.get("ISYERI_UNVANI"));
							rowData.put("ADRES", adrMap.get("ADRES"));
							rowData.put("SEMT", adrMap.get("SEMT"));
							rowData.put("ADRES_IL_KOD", adrMap.get("ADRES_IL_KOD"));
							rowData.put("ADRES_ILCE_KOD", adrMap.get("ADRES_ILCE_KOD"));
							rowData.put("ULKE_KOD", adrMap.get("ULKE_KOD"));
							rowData.put("POSTA_KOD", adrMap.get("POSTA_KOD"));
							rowData.put("ADRES_TEYIT", false);
							rowData.put("UPD_DATE", adrMap.get("UPD_DATE"));
							rowData.put("EXTRE_ADRES_KOD_F", "E");
							rowData.put("ILK_GECERLILIK_TARIHI", adrMap.get("ILK_GECERLILIK_TARIHI"));
							rowData.put("SON_GECERLILIK_TARIHI", adrMap.get("SON_GECERLILIK_TARIHI"));

							adresListNew.add(rowData);
							addApsAddress = false;
							ekstreAdresAps = true;
						}
					}
				}
			}

			if (iMap.getString("EV_ADRES") != null && !iMap.getString("EV_ADRES").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("ADRES_KOD", "E");
				rowData.put("ADRES", iMap.getString("EV_ADRES"));
				rowData.put("ADRES_IL_KOD", iMap.getString("EV_IL"));
				rowData.put("ADRES_ILCE_KOD", iMap.getString("EV_ILCE"));
				rowData.put("ULKE_KOD", "TR");
				rowData.put("POSTA_KOD", iMap.getString("EV_POSTA_KOD"));
				rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
				rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_EV")));
				adresListNew.add(rowData);
			}
			if (iMap.getString("IS_ADRES") != null && !iMap.getString("IS_ADRES").isEmpty() && (!"7".equals(iMap.getString("KANAL_KOD")) || "4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "6".equals(iMap.getString("MAAS_ALINAN_KURUM")))) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("ADRES_KOD", "I");
				rowData.put("ISYERI_UNVANI", iMap.getString("ISYERI_ADI"));
				rowData.put("ADRES", iMap.getString("IS_ADRES"));
				rowData.put("ADRES_IL_KOD", iMap.getString("IS_IL"));
				rowData.put("ADRES_ILCE_KOD", iMap.getString("IS_ILCE"));
				rowData.put("ULKE_KOD", "TR");
				rowData.put("POSTA_KOD", iMap.getString("IS_POSTA_KOD"));
				rowData.put("ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
				rowData.put("EXTRE_ADRES_KOD_F", GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("YAZISMA_ADRESI_IS")));
				rowData.put("ADRES_TEYIT", false);

				adresListNew.add(rowData);
			}
			if (addApsAddress && iMap.get("ADRES_NO") != null && !"0".equals(iMap.getString("ADRES_NO")) && iMap.get("YABANCI_ULKE_KOD") == null) {
				adresListNew.add(getAPSAddressObject(iMap));
				ekstreAdresAps = true;
			}
			if (ekstreAdresAps) {
				for (int row = 0; row < adresListNew.size(); row++) {
					HashMap<String, Object> adrMap = adresListNew.get(row);
					if ("E".equals(adrMap.get("ADRES_KOD")) || "I".equals(adrMap.get("ADRES_KOD"))) {
						adrMap.put("EXTRE_ADRES_KOD_F", "H");
					}
					adresListNew.set(row, adrMap);
				}
			}
			else {
				if (!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")) {
					for (int row = 0; row < adresListNew.size(); row++) {
						HashMap<String, Object> adrMap = adresListNew.get(row);
						if ("E".equals(adrMap.get("ADRES_KOD"))) {
							adrMap.put("EXTRE_ADRES_KOD_F", "E");
						}
						adresListNew.set(row, adrMap);
					}
				}
			}
			kontakt.put("ADRES_LIST", adresListNew);

			ArrayList<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();
			telefonList = (ArrayList<HashMap<String, Object>>) kontakt.get("TELEFON_LIST");

			tableName = "TELEFON_LIST";

			ArrayList<HashMap<String, Object>> telefonListNew = new ArrayList<HashMap<String, Object>>();

			if (telefonList != null) {
				for (int row = 0; row < telefonList.size(); row++) {
					HashMap<String, Object> telMap = telefonList.get(row);

					// 1-Ev 2-Is 3-GSM 4-Yazlik 5-Fax

					if ("1".equals(telMap.get("TEL_TIP")) && (iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty())) {
						HashMap<String, Object> rowData = new HashMap<String, Object>();
						rowData.put("TEL_TIP", telMap.get("TEL_TIP"));
						rowData.put("ALAN_KOD", telMap.get("ALAN_KOD"));
						rowData.put("TEL_NO", telMap.get("TEL_NO"));
						rowData.put("DAH_NO", telMap.get("DAH_NO"));
						rowData.put("BAGLI_KOD", telMap.get("BAGLI_KOD"));
						rowData.put("F_ILETISIM", GuimlUtil.convertFromCheckBoxValue((String) telMap.get("F_ILETISIM")));
						rowData.put("ULKE_KODU", telMap.get("ULKE_KODU"));
						rowData.put("TEL_UPD_DATE", telMap.get("TEL_UPD_DATE"));
						if ("7".equals(iMap.getString("KANAL_KOD")) && !("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "6".equals(iMap.getString("MAAS_ALINAN_KURUM"))))
							rowData.put("F_ILETISIM", "1");
						else if ((iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty()) && (iMap.getString("IS_TEL_NO") == null || iMap.getString("IS_TEL_NO").isEmpty()))
							rowData.put("F_ILETISIM", telMap.get("F_ILETISIM"));
						else
							rowData.put("F_ILETISIM", "0");
						rowData.put("TEL_TEYIT", iMap.getBoolean(tableName, row, "TEL_TEYIT"));

						telefonListNew.add(rowData);
					}
					if ("2".equals(telMap.get("TEL_TIP")) && (iMap.getString("IS_TEL_NO") == null || iMap.getString("IS_TEL_NO").isEmpty())) {
						HashMap<String, Object> rowData = new HashMap<String, Object>();
						rowData.put("TEL_TIP", telMap.get("TEL_TIP"));
						rowData.put("ALAN_KOD", telMap.get("ALAN_KOD"));
						rowData.put("TEL_NO", telMap.get("TEL_NO"));
						rowData.put("DAH_NO", telMap.get("DAH_NO"));
						rowData.put("BAGLI_KOD", telMap.get("BAGLI_KOD"));
						rowData.put("F_ILETISIM", GuimlUtil.convertFromCheckBoxValue((String) telMap.get("F_ILETISIM")));
						rowData.put("ULKE_KODU", telMap.get("ULKE_KODU"));
						rowData.put("TEL_UPD_DATE", telMap.get("TEL_UPD_DATE"));
						if ((iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty()) && (iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty()))
							rowData.put("F_ILETISIM", telMap.get("F_ILETISIM"));
						else
							rowData.put("F_ILETISIM", "0");
						rowData.put("TEL_TEYIT", iMap.getBoolean(tableName, row, "TEL_TEYIT"));

						telefonListNew.add(rowData);
					}
					if ("3".equals(telMap.get("TEL_TIP")) && (iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty())) {
						HashMap<String, Object> rowData = new HashMap<String, Object>();
						rowData.put("TEL_TIP", telMap.get("TEL_TIP"));
						rowData.put("ALAN_KOD", telMap.get("ALAN_KOD"));
						rowData.put("TEL_NO", telMap.get("TEL_NO"));
						rowData.put("DAH_NO", telMap.get("DAH_NO"));
						rowData.put("BAGLI_KOD", telMap.get("BAGLI_KOD"));
						rowData.put("F_ILETISIM", GuimlUtil.convertFromCheckBoxValue((String) telMap.get("F_ILETISIM")));
						rowData.put("ULKE_KODU", telMap.get("ULKE_KODU"));
						rowData.put("TEL_UPD_DATE", telMap.get("TEL_UPD_DATE"));
						if ("7".equals(iMap.getString("KANAL_KOD"))) {
							if ("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM"))|| "6".equals(iMap.getString("MAAS_ALINAN_KURUM")))
								rowData.put("F_ILETISIM", "1");
							else if (iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty())
								rowData.put("F_ILETISIM", telMap.get("F_ILETISIM"));
							else
								rowData.put("F_ILETISIM", "0");
						}
						else
							rowData.put("F_ILETISIM", telMap.get("F_ILETISIM"));
						rowData.put("TEL_TEYIT", iMap.getBoolean(tableName, row, "TEL_TEYIT"));
						rowData.put("OTPMI", telMap.get("OTPMI"));

						telefonListNew.add(rowData);
					}
				}
			}
			else
				telefonListNew = new ArrayList<HashMap<String, Object>>();

			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "1");
				rowData.put("ALAN_KOD", iMap.getString("EV_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("EV_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				if ("7".equals(iMap.getString("KANAL_KOD")) && !("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "6".equals(iMap.getString("MAAS_ALINAN_KURUM"))))
					rowData.put("F_ILETISIM", "1");
				else if (iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty())
					rowData.put("F_ILETISIM", "1");
				else
					rowData.put("F_ILETISIM", "0");
				rowData.put("TEL_TEYIT", false);
				telefonListNew.add(rowData);
			}
			if (iMap.getString("IS_TEL_NO") != null && !iMap.getString("IS_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "2");
				rowData.put("ALAN_KOD", iMap.getString("IS_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("IS_TEL_NO"));
				rowData.put("DAH_NO", iMap.getString("IS_TEL_DAHILI"));
				rowData.put("ULKE_KODU", "90");
				if ((iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty()) && (iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty()))
					rowData.put("F_ILETISIM", "1");
				rowData.put("TEL_TEYIT", false);
				telefonListNew.add(rowData);
			}
			if (iMap.getString("CEP_TEL_NO") != null && !iMap.getString("CEP_TEL_NO").isEmpty()) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("TEL_TIP", "3");
				rowData.put("ALAN_KOD", iMap.getString("CEP_TEL_KOD"));
				rowData.put("TEL_NO", iMap.getString("CEP_TEL_NO"));
				rowData.put("ULKE_KODU", "90");
				if ("7".equals(iMap.getString("KANAL_KOD"))) {
					if ("4".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "5".equals(iMap.getString("MAAS_ALINAN_KURUM")) || "6".equals(iMap.getString("MAAS_ALINAN_KURUM")))
						rowData.put("F_ILETISIM", "1");
					else if (iMap.getString("EV_TEL_NO") == null || iMap.getString("EV_TEL_NO").isEmpty())
						rowData.put("F_ILETISIM", "1");
					else
						rowData.put("F_ILETISIM", "0");
				}
				else
					rowData.put("F_ILETISIM", "1");
				rowData.put("TEL_TEYIT", false);
				if("E".equals(iMap.getString("PTT_SMS_MI"))){
					rowData.put("OTPMI", true);
				} else {
					rowData.put("OTPMI", false);
				}				
				telefonListNew.add(rowData);
			}
			kontakt.put("TELEFON_LIST", telefonListNew);

			try {
				kontakt.putAll(GMServiceExecuter.execute("BNSPR_QRY1098_GET_APS", iMap));
			}
			catch (Exception e) {
				System.out.println(e.getMessage().toString());
			}

			kontakt.put("F_APS", "E");
			kontakt.put("F_APS_TEYIT", iMap.getString("F_APS_TEYIT"));

			if ("E".equals(iMap.getString("APS_YAPILDIMI"))) {
				kontakt.put("F_APS_TEYIT", "true");
			}

			kontakt.put("DURUM_KODU", "A");

			if (iMap.getString("EMAIL1") != null && iMap.getString("EMAIL2") != null && !iMap.getString("EMAIL1").isEmpty() && !iMap.getString("EMAIL2").isEmpty())
				kontakt.put("EMAIL_KISISEL", iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));

			// �ifte vatanda�l�k : R ("Hay�r")
			// Green Card : R("De�ilim")

			if (iMap.getString("F_CIFTE_VATANDAS") == null) {
				kontakt.put("F_CIFTE_VATANDAS", "R");
			}
			if (iMap.getString("F_GREEN_CARD") == null) {
				kontakt.put("F_GREEN_CARD", "R");
			}

			// BNSPR_TRN10041_SAVE
			// GMServiceExecuter.call("BNSPR_TRN10011_SAVE", kontakt);
			GMMap oMap = new GMMap();
			try {
				// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
				kontakt.put("TRX_ONAYSIZ_ISLEM", "E");

				oMap = GMServiceExecuter.call("BNSPR_TRN10041_SAVE", kontakt);
			}
			catch (Exception e) {
				if ("2".equals(iMap.getString("KANAL_KODU"))) {
					throw new Exception("Musteri guncellenirken hata olustu.");
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3171_GET_ODEME_PLANI")
	public static GMMap getOdemePlani(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		try {

			Session session = DAOSession.getSession("BNSPRDal");

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3171.RC_GET_ODEME_PLANI(?)}");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rs = (ResultSet) stmt.getObject(1);
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			BigDecimal faizOrani = birBasvuru.getSozlesmeFaizi();
			oMap.put("SOZLESME_FAIZ_ORANI", faizOrani);
			String tableName = "ODEME_PLANI";
			BigDecimal toplamTaksitTutari = BigDecimal.ZERO;
			BigDecimal toplamAnapara = BigDecimal.ZERO;
			BigDecimal toplamFaiz = BigDecimal.ZERO;
			BigDecimal toplamKKDF = BigDecimal.ZERO;
			BigDecimal toplamBSMV = BigDecimal.ZERO;
			int i = 0;
			while (rs.next()) {
				oMap.put(tableName, i, "OP_TAKSIT_TARIHI", rs.getDate(1));
				oMap.put(tableName, i, "OP_TAKSIT_TUTAR", rs.getBigDecimal(2));
				toplamTaksitTutari = toplamTaksitTutari.add(rs.getBigDecimal(2));
				oMap.put(tableName, i, "OP_ANAPARA", rs.getBigDecimal(3));
				toplamAnapara = toplamAnapara.add(rs.getBigDecimal(3));
				oMap.put(tableName, i, "OP_FAIZ", rs.getBigDecimal(4));
				toplamFaiz = toplamFaiz.add(rs.getBigDecimal(4));
				oMap.put(tableName, i, "OP_KKDF", rs.getBigDecimal(5));
				toplamKKDF = toplamKKDF.add(rs.getBigDecimal(5));
				oMap.put(tableName, i, "OP_BSMV", rs.getBigDecimal(6));
				toplamBSMV = toplamBSMV.add(rs.getBigDecimal(6));
				oMap.put(tableName, i, "OP_KALAN_TUTAR", rs.getBigDecimal(7));
				oMap.put(tableName, i, "OP_TAKSIT_NO", i + 1);
				// oMap.put(tableName, i, "OP_MASRAF", new BigDecimal(0)); // simulasyon i�in �imdilik masraf s�f�r isteniyor
				// oMap.put(tableName, i, "OP_AYLIK_TOPLAM", rs.getBigDecimal(2)); // masraf s�f�r oldu�u i�in taksit tutar� ile ayn�
				// oMap.put(tableName, i, "GRP", 1 + i / 12); //raporda y�ll�k t oplamlar� bulmak i�in grup bu alan g�re gruplama yap�l�yor
				i++;
			}
			oMap.put("TOPLAM_TAKSIT_TUTARI", toplamTaksitTutari);
			oMap.put("TOPLAM_ANAPARA", toplamAnapara);
			oMap.put("TOPLAM_FAIZ", toplamFaiz);
			oMap.put("TOPLAM_KKDF", toplamKKDF);
			oMap.put("TOPLAM_BSMV", toplamBSMV);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BASVURU_NO")
	public static GMMap getBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("ID", new BigDecimal(DALUtil.getResult("select seq_bir_basvuru.nextval from dual")));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_GET_BAGLI_SATICI_ADI")
	public static GMMap getBagliSaticiAdi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3171.RC_GET_AYNI_SIFRELI_SATICI(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("KANAL_ALT_KODU"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.fillComboBox(iMap, "SATICI_ADI", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CREATE_KONTAKT_MUSTERI")
	public static GMMap createKontaktMusteri(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal musteriNo = null;
		try {

			iMap.putAll(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap));

			/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			Session session = DAOSession.getSession("BNSPRDal");
			BirKampanya birKampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", iMap.getBigDecimal("KAMP_KOD"))).uniqueResult();
			String ticariKrediEh = "H";
			if (birKampanya != null) {
				ticariKrediEh = birKampanya.getTicariKrediEh();
			}
			// Kampanya Ticari Kredi Evet ise ticari musteri(4) yoksa olusturur
			// Kampanya Ticari Kredi Hayir ise bireysel musteri(1) yoksa olusturur
			List<GnlMusteri> list;
			if ("E".equals(ticariKrediEh)) {
				list = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.eq("musteriStat1", "4")).add(Restrictions.eq("durumKodu", "A")).list();
			}
			else {
				list = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).list();
			}

			if (list != null && list.size() > 0) {

				musteriNo = list.get(0).getMusteriNo();
			}
			else {
				oMap.put("MUSTERI_YARATMA_TX_NO", iMap.getBigDecimal("TRX_NO"));
				GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", iMap);

				if ("E".equals(ticariKrediEh)) {
					list = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.eq("musteriStat1", "4")).list();
				}
				else {
					list = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.ne("musteriStat1", "4")).list();
				}
				if (list != null && list.size() > 0) {

					musteriNo = list.get(0).getMusteriNo();
				}
			}

			oMap.put("MUSTERI_NO", musteriNo);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_UPDATE_MUSTERI_NO")
	public static GMMap updateMusteriNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String proc = "{call PKG_TRN3171.updateMusteriNo(?,?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_YARATMA_TX_NO") };
			Object[] outputValues = {};
			oMap.putAll((GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_URUNLU_KAMPANYA")
	public static GMMap urunluKampanyaMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_Kampanya.Urunlu_Kampanya_Mi(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KOD"));

			stmt.execute();

			oMap.put("URUN_MU", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_PORTFOY_KOD")
	public static GMMap getPortfoyKod(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PORTFOY.Bir_Portfoy_Bul(?) }");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			oMap.put("PORTFOY_KOD", stmt.getString(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_PORTFOY_SUBE_KOD")
	public static GMMap getPortfoySubeKod(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PORTFOY.Sube_Bul(?) }");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("PORTFOY_KOD"));

			stmt.execute();
			oMap.put("PORTFOY_SUBE_KOD", stmt.getString(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR")
	public static GMMap getHerseyDahilTutar(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3171.hersey_dahil_tutar(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("KANAL_KOD"));
			stmt.setString(i++, iMap.getString("DOVIZ_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KNL_KOD"));
			stmt.setDate(i++, new Date(iMap.getDate("DOGUM_TARIHI").getTime()));
			stmt.setString(i++, iMap.getString("CINSIYET"));
			stmt.setString(i++, iMap.getString("MAAS_TARIH_SIKLIGI"));
			stmt.setString(i++, "E"); // guncelle = E
			stmt.setString(i++, iMap.getString("EK_IHTIYAC"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.execute();

			if (stmt.getBigDecimal(--i) != null)
				oMap.put("DOSYA_MASRAFI", stmt.getBigDecimal(i));

			oMap.put("HERSEY_DAHIL_TUTAR", stmt.getBigDecimal(--i));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * @param Map
	 *            <String, Object> MAAS_ALINAN_KURUM
	 * 
	 * @return Map<String, Object> KAMPANYA_KOD FAIZ_ORANI SOZLESME_FAIZ_ORANI
	 **/

	@GraymoundService("BNSPR_TRN3171_KMH_KAMPANYA_KOD")
	public static GMMap getCampaignCode(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3071.ptt_kmh_kampanya_bul()}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);

			stmt.execute();

			oMap.put("KAMPANYA_KOD", stmt.getBigDecimal(1));
			stmt.close();
			i = 1;
			stmt = conn.prepareCall("{? = call PKG_TRN3071.KMH_aylik_faiz_oran(?)}");
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAAS_ALINAN_KURUM"));
			stmt.execute();
			oMap.put("FAIZ_ORANI", stmt.getBigDecimal(1));
			oMap.put("SOZLESME_FAIZ_ORANI", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CALCULATE_BAYI_KAZANCI")
	public static GMMap calculateBayiKazanc(GMMap iMap) {
		GMMap oMap = new GMMap();
		int i = 0;
		BigDecimal kazanc = BigDecimal.ZERO;
		while (i < iMap.getSize("SIGORTA_TABLE")) {
			if (!StringUtil.isEmpty(iMap.getString("SIGORTA_TABLE", i, "BAYI_KAZANCI")))
				kazanc = kazanc.add(iMap.getBigDecimal("SIGORTA_TABLE", i, "BAYI_KAZANCI"));
			i++;
		}
		oMap.put("BAYI_KAZANCI", kazanc);
		oMap.put("BAYI_KAZANCI_FLAG", false);
		if (kazanc.compareTo(BigDecimal.ZERO) > 0)
			oMap.put("BAYI_KAZANCI_FLAG", true);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_YENIDEN_YAPILANDIRMA")
	public static GMMap yenidenYapilandirma(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3171.Yeniden_Yapilandirma_Uygun_Mu(?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));

			stmt.execute();

			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KAMP_KNL_KOD_RECURSIVE")
	public static Map<?, ?> getKampKnlKodRecursive(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			String urunKampKod = iMap.getString("KAMP_URUN_ADI");

			GMMap oMap = new GMMap();
			BigDecimal kampKod;
			int i = 1;
			if (urunKampKod.indexOf('-') < 0) {
				kampKod = new BigDecimal(urunKampKod);

				stmt = conn.prepareCall("{call pkg_trn3171.Kamp_Knl_Kod_Recursive( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }");

				stmt.setBigDecimal(i++, kampKod);
				stmt.setString(i++, iMap.getString("KANAL_KOD"));
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TUTARI"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KNL_KOD"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setDate(i++, iMap.getDate("DOGUM_TARIHI") == null ? null : new Date(iMap.getDate("DOGUM_TARIHI").getTime()));
				stmt.setString(i++, iMap.getString("CINSIYET"));
				stmt.setString(i++, iMap.getString("MAAS_TARIH_SIKLIGI"));
				stmt.setString(i++, iMap.getString("SIMULASYON_MU"));
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);

				stmt.execute();
				if (stmt.getBigDecimal(13) == null || kampKod.compareTo(stmt.getBigDecimal(13)) != 0) {
					oMap.put("GUNCEL_KAMP_KOD", stmt.getBigDecimal(13));
					oMap.put("SERBEST_KATKI_PAYI", stmt.getBigDecimal(14));
					oMap.put("FAIZ_ORANI", stmt.getBigDecimal(15));
					oMap.put("MIN_KATKI_PAYI", stmt.getBigDecimal(16));
					oMap.put("MAX_KATKI_PAYI", stmt.getBigDecimal(17));
					oMap.put("KATKI_PAYI_ORAN", stmt.getBigDecimal(18));
					oMap.put("MAX_DOSYA_MASRAFI", stmt.getBigDecimal(19));
				}
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KAMP_KNL_KOD_RECURSIVE_SIM")
	public static Map<?, ?> getKampKnlKodRecursiveSim(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			String urunKampKod = iMap.getString("KAMP_URUN_ADI");

			GMMap oMap = new GMMap();
			BigDecimal kampKod;
			int i = 1;
			if (urunKampKod.indexOf('-') < 0) {
				kampKod = new BigDecimal(urunKampKod);

				stmt = conn.prepareCall("{call pkg_trn3171.Kamp_Knl_Kod_Recursive( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) }");

				stmt.setString(i++, urunKampKod);
				stmt.setString(i++, iMap.getString("KANAL_KOD"));
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TUTARI"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KNL_KOD"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setDate(i++, iMap.getDate("DOGUM_TARIHI") == null ? null : new Date(iMap.getDate("DOGUM_TARIHI").getTime()));
				stmt.setString(i++, iMap.getString("CINSIYET"));
				stmt.setString(i++, iMap.getString("MAAS_TARIH_SIKLIGI"));
				stmt.setString(i++, iMap.getString("SIMULASYON_MU"));
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);
				stmt.registerOutParameter(i++, Types.NUMERIC);

				stmt.execute();
				if (stmt.getBigDecimal(13) == null || kampKod.compareTo(stmt.getBigDecimal(13)) != 0) {
					oMap.put("GUNCEL_KAMP_KOD", stmt.getBigDecimal(13));
					oMap.put("SERBEST_KATKI_PAYI", stmt.getBigDecimal(14));
					oMap.put("FAIZ_ORANI", stmt.getBigDecimal(15));
					oMap.put("MIN_KATKI_PAYI", stmt.getBigDecimal(16));
					oMap.put("MAX_KATKI_PAYI", stmt.getBigDecimal(17));
					oMap.put("KATKI_PAYI_ORAN", stmt.getBigDecimal(18));
					oMap.put("MAX_DOSYA_MASRAFI", stmt.getBigDecimal(19));
				}
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_SAVED_TEMINATLAR")
	public static Map<?, ?> getSavedTeminat(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GMMap oMap = new GMMap();

			List<?> teminatList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			int row = 0;
			String tableName = "TEMINAT_LIST";

			for (Object name : teminatList) {
				BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) name;
				oMap.put(tableName, row, "TEMINAT", birBasvuruTeminatTx.getId().getTeminatKod());
				oMap.put(tableName, row, "ADET", birBasvuruTeminatTx.getTeminatAdedi());
				row++;
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_GET_ES_BILGI")
	public static GMMap getEsBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call pkg_trn3171.rc_get_kimlik_diger(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, "E");
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put("REC_DATE", rSet.getObject("REC_DATE"));
				oMap.put("REC_OWNER", rSet.getObject("REC_OWNER"));
				oMap.put("BASVURU_NO", rSet.getObject("BASVURU_NO"));
				oMap.put("TCKIMLIKNO", rSet.getObject("TC_KIMLIK_NO"));
				oMap.put("AD", rSet.getObject("AD"));
				oMap.put("SOYAD", rSet.getObject("SOYAD"));
				oMap.put("ANNEAD", rSet.getObject("ANNE_ADI"));
				oMap.put("BABAAD", rSet.getObject("BABA_AD"));
				oMap.put("DOGUMYERKOD", rSet.getObject("DOGUMYERKOD"));
				oMap.put("DOGUMYER", rSet.getObject("DOGUM_YERI"));
				oMap.put("DOGUMTARIH", rSet.getObject("DOGUM_TAR"));
				oMap.put("CINSIYETKOD", rSet.getObject("CINSIYET"));
				oMap.put("CINSIYET", rSet.getObject("CINSIYET_KPS"));
				oMap.put("DIN", rSet.getObject("DIN"));
				oMap.put("DURUMKOD", rSet.getObject("DURUMKOD"));
				oMap.put("DURUM", rSet.getObject("DURUM"));
				oMap.put("MEDENIHALKOD", rSet.getObject("MEDENI_HAL"));
				oMap.put("MEDENIHAL", rSet.getObject("MEDENI_HAL_KPS"));
				oMap.put("OLUMTARIH", rSet.getObject("OLUMTARIH"));
				oMap.put("KAYITYERILKOD", rSet.getObject("NUFUS_IL_KOD"));
				oMap.put("KAYITYERIL", rSet.getObject("KAYITYERIL"));
				oMap.put("KAYITYERILCEKOD", rSet.getObject("NUFUS_ILCE_KOD"));
				oMap.put("KAYITYERILCE", rSet.getObject("KAYITYERILCE"));
				oMap.put("KAYITYERCILTKOD", rSet.getObject("CILT_NO"));
				oMap.put("KAYITYERCILT", rSet.getObject("MAHALLE_KOY"));
				oMap.put("AILESIRANO", rSet.getObject("AILE_SIRA_NO"));
				oMap.put("BIREYSIRANO", rSet.getObject("BIREY_SIRA_NO"));
				oMap.put("ESTCKIMLIKNO", rSet.getObject("ES_TCKN"));
				oMap.put("CUZDANNO", rSet.getObject("KIMLIK_SIRA_NO_KPS"));
				oMap.put("CUZDANSERI", rSet.getObject("KIMLIK_SERI_NO_KPS"));
				oMap.put("VERILDIGIILCEKOD", rSet.getObject("VERILDIGIILCEKOD"));
				oMap.put("VERILDIGIILCE", rSet.getObject("NUFUS_VER_YER"));
				oMap.put("VERILMENEDENKOD", rSet.getObject("VERILMENEDENKOD"));
				oMap.put("VERILMENEDEN", rSet.getObject("NUFUS_VER_NEDENI"));
				oMap.put("VERILMETARIH", rSet.getObject("NUFUS_VER_TAR"));
				oMap.put("BASVURU_TARIHI", rSet.getObject("BASVURU_TARIHI"));
				oMap.put("BASVURAN_TCKN", rSet.getObject("BASVURAN_TCKN"));
				oMap.put("BASVURAN_AD", rSet.getObject("BASVURAN_AD"));

				oMap.put("ADRES_NO", rSet.getObject("ADRES_NO"));
				oMap.put("IL", rSet.getObject("IL"));
				oMap.put("ILCE", rSet.getObject("ILCE"));
				oMap.put("IL_KOD", rSet.getObject("EV_ADR_IL_KOD"));
				oMap.put("ILCE_KOD", rSet.getObject("EV_ADR_ILCE_KOD"));
				oMap.put("BUCAK", rSet.getObject("BUCAK"));
				oMap.put("BUCAK_KOD", rSet.getObject("BUCAK_KOD"));
				oMap.put("MAHALLE", rSet.getObject("MAHALLE"));
				oMap.put("MAHALLE_KOD", rSet.getObject("MAHALLE_KOD"));
				oMap.put("KOY", rSet.getObject("KOY"));
				oMap.put("KOY_KOD", rSet.getObject("KOY_KOD"));
				oMap.put("KOY_KAYIT_NO", rSet.getObject("KOY_KAYIT_NO"));
				oMap.put("DIS_KAPI_NO", rSet.getObject("DIS_KAPI_NO"));
				oMap.put("IC_KAPI_NO", rSet.getObject("IC_KAPI_NO"));
				oMap.put("CSBM", rSet.getObject("CSBM"));
				oMap.put("CSBM_KOD", rSet.getObject("CSBM_KOD"));
				oMap.put("YABANCI_ADRES", rSet.getObject("YABANCI_ADRES"));
				oMap.put("YABANCI_SEHIR", rSet.getObject("YABANCI_SEHIR"));
				oMap.put("YABANCI_ULKE", rSet.getObject("YABANCI_ULKE"));
				oMap.put("YABANCI_ULKE_KOD", rSet.getObject("EV_ADR_ULKE_KOD"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_EVLI_MI")
	public static GMMap getEvliMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call pkg_trn3171.kimlik_diger_say(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, "E");
			stmt.execute();
			int count = stmt.getInt(1);
			oMap.put("ES_ENABLED", count > 0);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_GEC_TESLIM_NEDENLERI")
	public static GMMap getGecTeslimNeden(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "GEC_TESLIMAT_NEDEN_KOD");
			oMap.put("GEC_TESLIMAT_LIST", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KIMLIK2")
	public static GMMap getKimlik2(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "KIMLIK2_TIP_KOD");
			oMap.put("KIMLIK_LIST", GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_GEC_TESLIM_NEDEN_SOR")
	public static GMMap getGecTeslimNedenSor(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call pkg_trn3171.gec_teslim_nedeni_sor(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("GEC_NEDEN_SOR", stmt.getString(1).equals("E"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BASKA_KIMLIK_SOR")
	public static GMMap getGecBaskaKimlikSor(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call pkg_trn3171.baska_kimlik_sor(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("BASKA_KIMLIK_SOR", stmt.getString(1).equals("E"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_TESLIM_KIME")
	public static GMMap getTeslimKime(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			iMap.put("LIST_NAME", "TESLIM_KIME_LIST");
			iMap.put("LIST_QUERY", "SELECT KEY1,TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'TESLIMAT_KISI_KOD' and NVL(KEY3,'A') = 'A' ORDER BY KEY1");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(DALUtil.fillComboBox(iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_BAYI_URUN")
	public static GMMap getBayiUrun(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call pkg_trn3171.rc_mal_liste(?, ?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SATICI_KOD"));
			stmt.setBigDecimal(i++, iMap.get("KAMPANYA_KOD") != null ? iMap.getBigDecimal("KAMPANYA_KOD") : BigDecimal.valueOf(-1));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "URUN_LIST";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "UST_MALNO", rSet.getObject("UST_MALNO"));
				oMap.put(tableName, row, "UST_AD", rSet.getObject("UST_AD"));
				oMap.put(tableName, row, "MALNO", rSet.getObject("MALNO"));
				oMap.put(tableName, row, "AD", rSet.getObject("AD"));
				oMap.put(tableName, row, "UST_GRUP_TIP", rSet.getObject("UST_GRUP_TIP"));
				oMap.put(tableName, row, "KALITE", rSet.getObject("KALITE"));
				oMap.put(tableName, row, "TESLIM_SURE", rSet.getObject("TESLIM_SURE"));
				oMap.put(tableName, row, "URUN_TESLIM_YER", rSet.getObject("URUN_TESLIM_YER"));
				oMap.put(tableName, row, "HIZMET_TESLIM_YER", rSet.getObject("HIZMET_TESLIM_YER"));
				oMap.put(tableName, row, "DEGER2EL", rSet.getObject("DEGER2EL"));
				oMap.put(tableName, row, "SKOR", rSet.getObject("SKOR"));
				oMap.put(tableName, row, "SKOR_TAHSIS", rSet.getObject("SKOR_TAHSIS"));

				oMap.put(tableName, row, "NAME", rSet.getString("AD"));

				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_SAVE_ES_BILGILERI")
	public static GMMap saveEsBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap sMap = new GMMap();
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			BigDecimal musteriTxNo = iMap.getBigDecimal("MUSTERI_YARATMA_TX_NO");
			boolean musteriIsNotNull = (musteriNo != null || musteriTxNo != null);
			if (musteriIsNotNull) {
				String proc = "{call pkg_trn3171.musteri_iliski_sirano (?,?,?,?)}";
				Object[] inputValues = { BnsprType.NUMBER, musteriNo, BnsprType.NUMBER, musteriTxNo };
				Object[] outputValues = { BnsprType.NUMBER, "MUSTERI_NO", BnsprType.NUMBER, "SIRA_NO" };
				oMap.putAll((GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues));
				sMap.put("VELI_VASI", 0, "ILISKI_YAKINLIK_TIPI", veliVasiTurEs);
				sMap.put("VELI_VASI", 0, "MUSTERI_NO", oMap.getString("MUSTERI_NO"));
			}
			// GMMap outMap = new GMMap();
			GMMap esKpsMap = new GMMap();
			esKpsMap.put("TCKNO", iMap.getString("ES_TCKN"));
			esKpsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", esKpsMap));

			GMMap esApsMap = new GMMap();
			// Es aps bilgilerinin basvuru sahibi bilgilerini ezmemesi icin yeni tx no
			esApsMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			esApsMap.put("TC_KIMLIK_NO", iMap.getString("ES_TCKN"));
			esApsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_APS_SORGULAMA", esApsMap));
			//esApsMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_APS_SORGULAMA", esApsMap));

			sMap.put("KANAL_KODU", iMap.getString("KANAL_KOD"));
			sMap.put("KANAL_ALT_KODU", iMap.getString("KANAL_ALT_KOD"));
			sMap.put("URUN_KAMP_KOD", iMap.getString("URUN_KAMP_KOD"));
			sMap.put("SERI_NO", esKpsMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", esKpsMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", ("2").equals(esKpsMap.getString("CINSIYET_KOD")) ? "K" : "E");
			sMap.putAll(esKpsMap);
			sMap.putAll(esApsMap);
			sMap.put("BABA_ADI", sMap.getString("BABA_AD"));
			sMap.put("ANNE_ADI", sMap.getString("ANNE_AD"));
			sMap.put("TCK_NO", esKpsMap.get("TCKNO"));
			sMap.put("ISIM", sMap.get("AD1"));
			sMap.put("IKINCI_ISIM", sMap.get("AD2"));
			sMap.put("SOYADI", sMap.get("SOYAD"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", ("2").equals(esKpsMap.getString("CINSIYET_KOD")) ? "K" : "E");
			sMap.put("MEDENI_HAL_KOD", ("2").equals(sMap.get("MEDENI_HALI_KOD")) ? "1" : "2");
			sMap.put("NUFUS_AILE_SIRA_NO", sMap.get("AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("CILT_KODU"));
			sMap.put("SIRA_NO", sMap.get("BIREY_SIRA_NO"));
			sMap.put("VERILDIGI_YER", sMap.get("VERILDIGI_ILCE_ADI"));
			sMap.put("VERILDIGI_TARIH", sMap.get("VERILIS_TARIHI"));
			sMap.put("IL_KOD", esKpsMap.get("IL_KODU"));
			sMap.put("ILCE_KOD", esKpsMap.get("ILCE_KODU"));
			sMap.put("NUF_VERILIS_NEDENI", sMap.getString("VERILIS_NEDENI"));

			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}

			// Es Musteri degilse yaratilir.
			/**GMMap outMap = new GMMap();
			outMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_CREATE_KONTAKT_MUSTERI", sMap));
			**/

			BirBasvuruKimlikDigerTx birBasvuruKimlikDigerTx = (BirBasvuruKimlikDigerTx) session.createCriteria(BirBasvuruKimlikDigerTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.kimIcin", "E")).add(Restrictions.eq("id.siraNo", BigDecimal.ONE)).uniqueResult();

			if (birBasvuruKimlikDigerTx == null) {
				birBasvuruKimlikDigerTx = new BirBasvuruKimlikDigerTx();
			}
			BirBasvuruKimlikDigerTxId birBasvuruKimlikDigerTxId = new BirBasvuruKimlikDigerTxId();

			birBasvuruKimlikDigerTx.setTcKimlikNo(esKpsMap.getString("TCKNO"));
			birBasvuruKimlikDigerTx.setAd(esKpsMap.getString("AD"));
			birBasvuruKimlikDigerTx.setAileSiraNo(esKpsMap.getString("AILE_SIRA_NO"));
			birBasvuruKimlikDigerTx.setAnneAdi(esKpsMap.getString("ANNE_AD"));
			birBasvuruKimlikDigerTx.setBabaAd(esKpsMap.getString("BABA_AD"));
			birBasvuruKimlikDigerTx.setBireySiraNo(esKpsMap.getString("BIREY_SIRA_NO"));
			birBasvuruKimlikDigerTx.setCinsiyet(("1").equals(esKpsMap.getString("CINSIYET_KOD")) ? "E" : "K");
			birBasvuruKimlikDigerTx.setCinsiyetKps(esKpsMap.getString("CINSIYET"));
			birBasvuruKimlikDigerTx.setCiltNo(esKpsMap.getString("CILT_KODU"));
			birBasvuruKimlikDigerTx.setKimlikKayitNo(esKpsMap.getString("KIMLIK_KAYIT_NO"));// GELMIYOR
			birBasvuruKimlikDigerTx.setDin(esKpsMap.getString("DIN"));
			birBasvuruKimlikDigerTx.setDogumyerkod(esKpsMap.getString("DOGUM_YERI_KOD")); // GELMIYOR
			birBasvuruKimlikDigerTx.setDurumkod(esKpsMap.getString("DURUMU"));
			birBasvuruKimlikDigerTx.setKayityeril(esKpsMap.getString("IL"));
			birBasvuruKimlikDigerTx.setVerilmenedenkod(esKpsMap.getString("VERILIS_NEDENI_KOD"));
			birBasvuruKimlikDigerTx.setKayityerilce(esKpsMap.getString("ILCE"));
			birBasvuruKimlikDigerTx.setMedeniHal(("2").equals(esKpsMap.getString("MEDENI_HALI_KOD")) ? "1" : "2");
			birBasvuruKimlikDigerTx.setKimlikSeriNoKps(esKpsMap.getString("KIMLIK_SERI_NO"));
			birBasvuruKimlikDigerTx.setKimlikSiraNoKps(esKpsMap.getString("KIMLIK_SIRA_NO"));
			birBasvuruKimlikDigerTx.setDogumTar(esKpsMap.getDate("DOGUM_TARIHI"));
			birBasvuruKimlikDigerTx.setDogumYeri(esKpsMap.getString("DOGUM_YERI"));
			birBasvuruKimlikDigerTx.setDurum(esKpsMap.getString("DURUMU_ACIKLAMA"));
			birBasvuruKimlikDigerTx.setEsTckn(esKpsMap.getString("ES_TCKN"));
			birBasvuruKimlikDigerTx.setMahalleKoy(esKpsMap.getString("CILT"));
			birBasvuruKimlikDigerTx.setMahalleKod(esKpsMap.getString("CILT_KODU"));
			birBasvuruKimlikDigerTx.setNufusIlKod(esKpsMap.getString("IL_KODU"));
			birBasvuruKimlikDigerTx.setNufusIlceKod(esKpsMap.getString("ILCE_KODU"));
			birBasvuruKimlikDigerTx.setMedeniHalKps(esKpsMap.getString("MEDENI_HALI") != null ? esKpsMap.getString("MEDENI_HALI").substring(0, 1) : "");
			birBasvuruKimlikDigerTx.setOlumtarih(esKpsMap.getDate("OLUM_TARIHI"));
			birBasvuruKimlikDigerTx.setSoyad(esKpsMap.getString("SOYAD"));
			birBasvuruKimlikDigerTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruKimlikDigerTx.setNufusVerYer(esKpsMap.getString("VERILDIGI_ILCE_ADI"));
			birBasvuruKimlikDigerTx.setVerildigiilcekod(esKpsMap.getString("VERILDIGI_ILCE_KODU"));
			birBasvuruKimlikDigerTx.setNufusVerNedeni(esKpsMap.getString("VERILIS_NEDENI"));
			birBasvuruKimlikDigerTx.setVerilmenedenkod(esKpsMap.getString("VERILIS_NEDENI_KOD"));
			birBasvuruKimlikDigerTx.setNufusVerTar(esKpsMap.getDate("VERILIS_TARIHI"));
			//birBasvuruKimlikDigerTx.setMusteriNo(outMap.getBigDecimal("MUSTERI_NO"));

			String serviceName = "BNSPR_KPS_GET_ADDRESS_INFO";
			esApsMap.put("TCKN", esApsMap.getString("TC_KIMLIK_NO"));

			birBasvuruKimlikDigerTx.setApsLogId(GMServiceExecuter.call(serviceName, esApsMap).getBigDecimal("LOG_ID"));
			birBasvuruKimlikDigerTx.setBucak(esApsMap.getString("BUCAK"));
			birBasvuruKimlikDigerTx.setBucakKod(esApsMap.getString("BUCAK_KOD"));
			birBasvuruKimlikDigerTx.setCsbm(esApsMap.getString("CSBM"));
			birBasvuruKimlikDigerTx.setCsbmKod(esApsMap.getString("CSBM_KODU"));
			birBasvuruKimlikDigerTx.setDisKapiNo(esApsMap.getString("DIS_KAPI_NO"));
			birBasvuruKimlikDigerTx.setIcKapiNo(esApsMap.getString("IC_KAPI_NO"));
			birBasvuruKimlikDigerTx.setIl(esApsMap.getString("IL"));
			birBasvuruKimlikDigerTx.setIlce(esApsMap.getString("ILCE"));
			birBasvuruKimlikDigerTx.setEvAdrIlKod(esApsMap.getString("IL_KODU"));
			birBasvuruKimlikDigerTx.setEvAdrIlceKod(esApsMap.getString("ILCE_KODU"));
			birBasvuruKimlikDigerTx.setKoy(esApsMap.getString("KOY"));
			birBasvuruKimlikDigerTx.setKoyKayitNo(esApsMap.getString("KOY_KAYIT_NO"));
			birBasvuruKimlikDigerTx.setKoyKod(esApsMap.getString("KOY_KOD"));
			birBasvuruKimlikDigerTx.setMahalle(esApsMap.getString("MAHALLE"));
			birBasvuruKimlikDigerTx.setMahalleKod(esApsMap.getString("MAHALLE_KOD"));

			birBasvuruKimlikDigerTx.setYabanciAdres(esApsMap.getString("YABANCI_ADRES"));// GELMIYOR
			birBasvuruKimlikDigerTx.setYabanciSehir(esApsMap.getString("YABANCI_SEHIR"));// GELMIYOR
			birBasvuruKimlikDigerTx.setYabanciUlke(esApsMap.getString("YABANCI_ULKE"));// GELMIYOR
			birBasvuruKimlikDigerTx.setYabanciUlkeKod(esApsMap.getString("YABANCI_ULKE_KOD"));// GELMIYOR

			birBasvuruKimlikDigerTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruKimlikDigerTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruKimlikDigerTxId.setKimIcin("E");
			birBasvuruKimlikDigerTxId.setSiraNo(BigDecimal.ONE);

			birBasvuruKimlikDigerTx.setId(birBasvuruKimlikDigerTxId);
			session.saveOrUpdate(birBasvuruKimlikDigerTx);
			session.flush();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_PTT_EMEKLISI_MI")
	public static GMMap pttEmeklisiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_TRN3171.PTT_EMEKLISI_MI(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
			oMap.put("PTT_EMEKLISI_MI", (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Fetches the dependent region information for ui to fill combobox
	 * 
	 * @param iMap
	 * @return {@link GMMap}
	 */
	@GraymoundService("BNSPR_TRN3171_BAGLI_BOLGE")
	public static GMMap getBagliBolge(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String sql = "select vt.key1, vt.text from v_ml_gnl_param_text vt where vt.key1 in " + "(select bs.bagli_old_bolge_kod from bir_satici bs) and vt.kod = 'BAGLI_OLD_BOLGE_KOD'";
			GuimlUtil.wrapMyCombo(oMap, "BAGLI_BOLGE", null, "Hepsi");
			GMMap fillComboBox = DALUtil.fillComboBox(oMap, "BAGLI_BOLGE", false, sql);
			return fillComboBox;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_MUSTERINO")
	public static GMMap getMusteriNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_BIREYSEL2.GET_MUSTERINO(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
			oMap.put("MUSTERI_NO", DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_MUSTERINO_STR")
	public static GMMap getMusteriNoStr(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_BIREYSEL2.GET_MUSTERINO_STR(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
			oMap.put("MUSTERI_NO", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_TESLIMAT_FARKLI_OLMA_NEDENLERI")
	public static GMMap getTeslimatFarkliOlmaNedenleri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("LIST_NAME", "FARKLI_NEDEN_LIST");
			iMap.put("LIST_QUERY", "SELECT KEY1,TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'TESLIMAT_FARKLI_OLMA_NEDENI' and KEY2 = ? and NVL(KEY3,'A') = 'A' ORDER BY KEY1");
			List<String> queryParameters = new ArrayList<String>();
			queryParameters.add(iMap.getString("URUN_KIME"));
			iMap.put("QUERY_PARAMETERS", queryParameters);
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(DALUtil.fillComboBox(iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_SAVE_ONONAY_BASVURU")
	public static GMMap saveOnonayBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		GMMap mMap = new GMMap();
		GMMap kpsMap = new GMMap();
		GMMap apsMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			iMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));

			// ONONAY_BASVURU_KONTROL CEP_NO_KAYITLI_MI_KONTROLU

			String kontrolEh = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap.put("KOD", "ONONAY_BASVURU_KONTROL").put("KEY", "CEP_NO_KAYITLI_MI_KONTROLU")).getString("TEXT");

			if ("E".equalsIgnoreCase(kontrolEh)) {

				GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TCKN"))).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).uniqueResult();
				List<GnlMusteriTelefon> telefon = null;
				if (musteri != null) {
					telefon = (List<GnlMusteriTelefon>) session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("alanKod", iMap.getString("CEP_TEL_ALAN_KODU"))).add(Restrictions.eq("telNo", iMap.getString("CEP_TEL_NO"))).add(Restrictions.eq("id.musteriNo", musteri.getMusteriNo())).list();
				
					if (telefon == null || telefon.size() == 0) {
						List<GnlMusteriTelefon> telefonList = (List<GnlMusteriTelefon>) session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("alanKod", iMap.getString("CEP_TEL_ALAN_KODU"))).add(Restrictions.eq("telNo", iMap.getString("CEP_TEL_NO"))).list();
	
						if (telefonList != null && telefonList.size() > 0) {
							oMap.put("HATA_NO", "4218");
							oMap.put("HATA", "Giri� yap�lan cep telefonu ba�ka bir m��teri de kay�tl�d�r. Bu cep telefonundan giri� yap�lamaz.");
							return oMap;
						}
					}
				}
			}

			kpsMap.put("TCKNO", iMap.getString("TCKN"));
			kpsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", kpsMap));
			// kpsMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", kpsMap));

			if (kpsMap.getString("TCKNO_OUT") != null) {
				if ("5".equals(kpsMap.getString("DURUMU"))) {
					oMap.put("HATA_NO", "2087");
					oMap.put("HATA", "Kapali KPS Kaydi");
				}
				if (kpsMap.getString("OLUM_TARIHI") != null) {
					oMap.put("HATA_NO", "918");
					oMap.put("HATA", "Musteri Vefat Etmistir");
				}
				else {
					iMap.put("DOGUM_TARIHI", kpsMap.getDate("DOGUM_TARIHI"));
					try {
						GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
					}
					catch (Exception e) {
						oMap.put("HATA_NO", "918");
						oMap.put("HATA", "Dogum tarihi uygun degil");
					}
				}
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_DOGRULAMA", kpsMap));
				oMap.put("KPS_YAPILDI", "E");
			}
			else {
				oMap.put("KPS_YAPILDI", "H");
				if ("1".equals(iMap.getString("ONONAY_BASVURU"))) {
					oMap.put("HATA_NO", "99");
					oMap.put("HATA", "KPS sorgusu basarisiz");
					return oMap;
				}
			}
			
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			if ("E".equals(oMap.getString("KPS_YAPILDI"))) {
				apsMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				apsMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));
				apsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_APS_SORGULAMA", apsMap));
				// apsMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_APS_SORGULAMA", apsMap));

				sMap.put("KANAL_KODU", iMap.getString("KANAL_KOD"));
				sMap.put("KANAL_ALT_KODU", iMap.getString("KANAL_ALT_KOD"));
				sMap.put("URUN_KAMP_KOD", iMap.getString("URUN_KAMP_KOD"));
				sMap.put("SERI_NO", kpsMap.getString("KIMLIK_SERI_NO"));
				sMap.put("SIRA_NO", kpsMap.getString("KIMLIK_SIRA_NO"));
				sMap.put("CINSIYET", ("2").equals(kpsMap.getString("CINSIYET_KOD")) ? "K" : "E");
				sMap.putAll(kpsMap);
				sMap.putAll(apsMap);
				sMap.put("BABA_ADI", sMap.getString("BABA_AD"));
				sMap.put("ANNE_ADI", sMap.getString("ANNE_AD"));
				sMap.put("TCK_NO", kpsMap.get("TCKNO"));
				sMap.put("ISIM", sMap.get("AD1"));
				sMap.put("IKINCI_ISIM", sMap.get("AD2"));
				sMap.put("SOYADI", sMap.get("SOYAD"));
				sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
				sMap.put("CINSIYET_KOD", ("2").equals(kpsMap.getString("CINSIYET_KOD")) ? "K" : "E");
				sMap.put("MEDENI_HAL_KOD", ("2").equals(sMap.get("MEDENI_HALI_KOD")) ? "1" : "2");
				sMap.put("NUFUS_AILE_SIRA_NO", sMap.get("AILE_SIRA_NO"));
				sMap.put("CILT_NO", sMap.get("CILT_KODU"));
				sMap.put("SIRA_NO", sMap.get("BIREY_SIRA_NO"));
				sMap.put("VERILDIGI_YER", sMap.get("VERILDIGI_ILCE_ADI"));
				sMap.put("VERILDIGI_TARIH", sMap.get("VERILIS_TARIHI"));
				sMap.put("IL_KOD", kpsMap.get("IL_KODU"));
				sMap.put("ILCE_KOD", kpsMap.get("ILCE_KODU"));
				sMap.put("NUF_VERILIS_NEDENI", sMap.getString("VERILIS_NEDENI"));

				if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
					sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
				}
				else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
					sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
				}

			}

			/** KPS, APS bilgileriyle on onay durumunda tx yarat **/
			BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.get(BirBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birBasvuruTx == null)
				birBasvuruTx = new BirBasvuruTx();
			birBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));

			// Basvuru Numarasi al
			if (iMap.getString("BASVURU_NO") == null || iMap.getString("BASVURU_NO").isEmpty()) {
				iMap.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", iMap).getBigDecimal("ID"));
			}

			// Musteri degilse yaratilir.(KPS basarili ise)
			if ("E".equals(oMap.getString("KPS_YAPILDI")) && oMap.get("HATA_NO") == null) {
				sMap.put("KPS_YAPILDI", "E");
				mMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_CREATE_KONTAKT_MUSTERI", sMap));
				oMap.put("MUSTERI_NO", mMap.getBigDecimal("MUSTERI_NO"));
			}

			birBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			if (oMap.get("HATA_NO") == null)
				birBasvuruTx.setDurumKodu("ON_ONAY");
			else
				birBasvuruTx.setDurumKodu("ON_ONAY_RED");
			birBasvuruTx.setTcKimlikNo(iMap.getString("TCKN"));
			birBasvuruTx.setMusteriNo(mMap.getBigDecimal("MUSTERI_NO"));

			birBasvuruTx.setKanalKodu(iMap.getString("KANAL_KOD")); // bunlar gelmeli mi?
			birBasvuruTx.setDovizKodu("TRY");
			birBasvuruTx.setKrediTur(iMap.getBigDecimal("KRD_TUR_KOD"));
			birBasvuruTx.setBasvuruTarihi(iMap.getDate("BANKA_TARIHI"));
			birBasvuruTx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));
			birBasvuruTx.setKrediAltTur(null);
			birBasvuruTx.setKrediAltTur2(null);
			birBasvuruTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
			birBasvuruTx.setVade(iMap.getBigDecimal("VADE"));
			birBasvuruTx.setTutar(iMap.getBigDecimal("TUTAR"));
			birBasvuruTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			birBasvuruTx.setWebSatisKanali(iMap.getString("WEB_SATIS_KANALI"));
			birBasvuruTx.setPttIlkMaasTarihi(iMap.getDate("PTT_ILK_MAAS_TARIHI"));
			birBasvuruTx.setPttMaasAlinanKurum(iMap.getString("PTT_MAAS_ALINAN_KURUM"));
			birBasvuruTx.setPttTahsisNumarasi(iMap.getString("PTT_TAHSIS_NUMARASI"));
			birBasvuruTx.setPttSonMaasTarihi(iMap.getDate("PTT_SON_MAAS_TARIHI"));
			birBasvuruTx.setPttOncekiMaasOdemeTarihi(iMap.getDate("PTT_ONCEKI_MAAS_ODEME_TARIHI"));
			birBasvuruTx.setPttMaasEvdenMi(iMap.getString("PTT_MAAS_EVDEN_MI"));
			birBasvuruTx.setPttMaasTarihSikligi(iMap.getBigDecimal("PTT_MAAS_TARIH_SIKLIGI"));
			birBasvuruTx.setPttIsleminYapildigiMerkez(iMap.getString("PTT_ISLEMIN_YAPILDIGI_MERKEZ"));
			birBasvuruTx.setPttIsleminYapildigiSube(iMap.getString("PTT_ISLEMIN_YAPILDIGI_SUBE"));
			birBasvuruTx.setPttSubeIli(iMap.getString("PTT_SUBE_ILI"));
			birBasvuruTx.setKazanimTur(iMap.getString("KAYNAK"));
			
			session.saveOrUpdate(birBasvuruTx);

			BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			if (birBasvuruKimlikTx == null) {
				birBasvuruKimlikTx = new BirBasvuruKimlikTx();
			}

			birBasvuruKimlikTx.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			birBasvuruKimlikTx.setCepTelAlanKodu(iMap.getString("CEP_TEL_ALAN_KODU"));
			birBasvuruKimlikTx.setTcKimlikNo(kpsMap.getString("TCKNO"));
			birBasvuruKimlikTx.setAd(kpsMap.getString("AD"));
			birBasvuruKimlikTx.setAileSiraNo(kpsMap.getString("AILE_SIRA_NO"));
			birBasvuruKimlikTx.setAnneAdi(kpsMap.getString("ANNE_AD"));
			birBasvuruKimlikTx.setBabaAd(kpsMap.getString("BABA_AD"));
			birBasvuruKimlikTx.setBireySiraNo(kpsMap.getString("BIREY_SIRA_NO"));
			birBasvuruKimlikTx.setCinsiyet(("1").equals(kpsMap.getString("CINSIYET_KOD")) ? "E" : "K");
			birBasvuruKimlikTx.setCiltNo(kpsMap.getString("CILT_KODU"));
			birBasvuruKimlikTx.setKimlikKayitNo(kpsMap.getString("KIMLIK_KAYIT_NO"));// GELMIYOR
			birBasvuruKimlikTx.setMedeniHal(("2").equals(kpsMap.getString("MEDENI_HALI_KOD")) ? "1" : "2");
			birBasvuruKimlikTx.setKimlikSeriNoKps(kpsMap.getString("KIMLIK_SERI_NO"));
			birBasvuruKimlikTx.setKimlikSiraNoKps(kpsMap.getString("KIMLIK_SIRA_NO"));
			birBasvuruKimlikTx.setDogumTar(kpsMap.getDate("DOGUM_TARIHI"));
			birBasvuruKimlikTx.setDogumYeri(kpsMap.getString("DOGUM_YERI"));
			birBasvuruKimlikTx.setEsTckn(kpsMap.getString("ES_TCKN"));
			birBasvuruKimlikTx.setMahalleKoy(kpsMap.getString("CILT"));
			birBasvuruKimlikTx.setNufusIlKod(kpsMap.getString("IL_KODU"));
			birBasvuruKimlikTx.setNufusIlceKod(kpsMap.getString("ILCE_KODU"));
			birBasvuruKimlikTx.setSoyad(kpsMap.getString("SOYAD"));
			birBasvuruKimlikTx.setNufusVerYer(kpsMap.getString("VERILDIGI_ILCE_ADI"));
			birBasvuruKimlikTx.setNufusVerNedeni(kpsMap.getString("VERILIS_NEDENI"));
			birBasvuruKimlikTx.setNufusVerTar(kpsMap.getDate("VERILIS_TARIHI"));
			birBasvuruKimlikTx.setEvAdrIlKod(apsMap.getString("IL_KODU"));
			birBasvuruKimlikTx.setEvAdrIlceKod(apsMap.getString("ILCE_KODU"));
			birBasvuruKimlikTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			birBasvuruKimlikTx.setMeslekKod(iMap.getString("MESLEK_KOD"));
			birBasvuruKimlikTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));

			birBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

			session.saveOrUpdate(birBasvuruKimlikTx);
			session.flush();

			oMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap.put("SOYADI", sMap.get("SOYADI"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_URUN_MODEL")
	public static GMMap getUrunModel(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN3171.get_model_urun(?,?,?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("KAMPANYA_KOD"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("UST_MALNO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.fillComboBox(iMap, "URUN_MODEL_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_URUN_MODEL_ACIKLAMA")
	public static GMMap getUrunModelAciklama(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			String func = "{ ? = call PKG_TRN3171.get_model_urun_aciklama(?,?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("UST_MALNO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("MODEL");

			oMap.put("ACIKLAMA", (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}

	}

	@GraymoundService("BNSPR_TRN3171_BASVURU_PAYGATE_CHECK")
	public static GMMap basvuruPaygateCheck(GMMap iMap) {
		GMMap oMap = new GMMap();
		List<SearchRequest> searchRequestList = new ArrayList<SearchRequest>();
		DateFormat shortDateTimeFormat = new SimpleDateFormat("dd.MM.yyyy");
		String adiSoyadi = "";
		ArrayOfSearchRequest arrayOfSearchRequest = null;

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));

			arrayOfSearchRequest = new ArrayOfSearchRequest();

			SearchRequest srMusteri = new SearchRequest();
			srMusteri.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_HESAP_ACILIS, SearchType.GENERIC_NAME));
			adiSoyadi = birBasvuruKimlik.getAd();
			if (!StringUtils.isEmpty(birBasvuruKimlik.getIkinciAd())) {
				adiSoyadi = adiSoyadi.concat(" ").concat(birBasvuruKimlik.getIkinciAd());
			}
			adiSoyadi = adiSoyadi.concat(" ").concat(birBasvuruKimlik.getSoyad());
			srMusteri.setValue(adiSoyadi);
			ArrayOfSearchFilter arrOfSearchFilter = new ArrayOfSearchFilter();
			if (StringUtils.isNotBlank(birBasvuruKimlik.getTcKimlikNo())) {
				SearchFilter sf = new SearchFilter();
				sf.setKey(FilterName.NATIONAL_ID);
				sf.setValue(birBasvuruKimlik.getTcKimlikNo());
				arrOfSearchFilter.getSearchFilter().add(sf);
			}
			if (birBasvuruKimlik.getDogumTar() != null) {
				SearchFilter sf1 = new SearchFilter();
				sf1.setKey(FilterName.DATE_OF_BIRTH);
				sf1.setValue(shortDateTimeFormat.format(birBasvuruKimlik.getDogumTar()));
				arrOfSearchFilter.getSearchFilter().add(sf1);
			}
			srMusteri.setFilters(arrOfSearchFilter);
			searchRequestList.add(srMusteri);

			arrayOfSearchRequest.getSearchRequest().addAll(searchRequestList);

			GMMap amlMap = new GMMap();
			amlMap.put("TRX_NAME", "3171");
			amlMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			amlMap.put("SEARCH_REQUEST_LIST", arrayOfSearchRequest);

			oMap = GMServiceExecuter.call("BNSPR_EXT_FINEKSUS_SEARCH_BULK_DATA", amlMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static ArrayOfInstanceGroup getArrOfInstanceGroupWithTypeAndName(String instanceName, SearchType searchType) {
		ArrayOfInstanceGroup instanceGroupListArray = new ArrayOfInstanceGroup();
		List<InstanceGroup> instanceGroupList = new ArrayList<InstanceGroup>();
		InstanceGroup ig = new InstanceGroup();
		ig.setDetailLevel(DetailLevel.FULL);
		ig.setInstanceName(instanceName);
		ig.setSearchType(searchType);
		instanceGroupList.add(ig);
		instanceGroupListArray.getInstanceGroup().addAll(instanceGroupList);
		return instanceGroupListArray;
	}

	/** TY-6229 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	@GraymoundService("BNSPR_TRN3171_GET_COMBO_ARAC_INFO")
	public static GMMap getComboAracInfo(GMMap iMap) {

		GMMap tMap = new GMMap();
		String listName = "COMBO_ARAC_INFO";
		try {
			if ("MARKA".equals(iMap.getString("COMBO"))) {
				tMap.putAll(GMServiceExecuter.execute("BNSPR_GET_VEHICLE_MAKES", iMap));
				ArrayList<HashMap<String, String>> listMakes = new ArrayList<HashMap<String, String>>();
				listMakes = (ArrayList<HashMap<String, String>>) tMap.get("MAKES");
				GuimlUtil.wrapMyCombo(iMap, listName, null, " ");
				/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
				for (HashMap<String, String> make : listMakes) {
					GuimlUtil.wrapMyCombo(iMap, listName, make.get("MAKE"), make.get("MAKE"));
				}
			}

			tMap.clear();

			if ("MODEL_YILI".equals(iMap.getString("COMBO"))) {
				if (iMap.getString("MAKE_CODE") != null) {
					tMap.putAll(GMServiceExecuter.execute("BNSPR_GET_VEHICLE_MODEL_YEARS", iMap));
					ArrayList<HashMap<String, String>> listModelYears = new ArrayList<HashMap<String, String>>();
					listModelYears = (ArrayList<HashMap<String, String>>) tMap.get("MODEL_YEARS");
					GuimlUtil.wrapMyCombo(iMap, listName, null, " ");
					/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
					for (HashMap<String, String> year : listModelYears) {
						GuimlUtil.wrapMyCombo(iMap, listName, year.get("YEAR"), year.get("YEAR"));
					}
				}
			}

			tMap.clear();

			if ("MODEL".equals(iMap.getString("COMBO"))) {
				if (iMap.getString("MAKE_CODE") != null && iMap.getString("MODEL_YEAR") != null) {
					tMap.putAll(GMServiceExecuter.execute("BNSPR_GET_VEHICLE_MODELS", iMap));
					ArrayList<HashMap<String, String>> listModels = new ArrayList<HashMap<String, String>>();
					listModels = (ArrayList<HashMap<String, String>>) tMap.get("MODELS");
					GuimlUtil.wrapMyCombo(iMap, listName, null, " ");
					/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
					for (HashMap<String, String> model : listModels) {
						GuimlUtil.wrapMyCombo(iMap, listName, model.get("ID"), model.get("TIP"));
					}
				}
			}

			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}
	}

	/** TY-6229 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	@GraymoundService("BNSPR_TRN3171_GET_COMBO_KULLANIM_AMAC")
	public static GMMap getComboKullanimAmac(GMMap iMap) {
		try {
			return DALUtil.fillComboBox(iMap, "KULLANIM_AMAC", false, "select key2, text from gnl_param_text where kod = 'TASIT_KREDI_PARAMETRE' and key1 = 'KULLANIM _AMACI'");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/** TY-6229 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	@GraymoundService("BNSPR_TRN3171_GET_MODEL_KASKO_DEGER")
	public static GMMap getModelveKaskoDeger(GMMap iMap) {

		GMMap tMap = new GMMap();

		try {
			if (iMap.getString("ARAC_KOD") != null) {
				tMap.putAll(GMServiceExecuter.execute("BNSPR_GET_VEHICLE_MODELS", iMap));

				ArrayList<HashMap<String, String>> listModels = new ArrayList<HashMap<String, String>>();
				listModels = (ArrayList<HashMap<String, String>>) tMap.get("MODELS");
				for (HashMap<String, String> model : listModels) {
					if (iMap.getString("ARAC_KOD").equals(model.get("ID"))) {
						iMap.put("MODEL", model.get("TIP"));
						iMap.put("KASKO_DEGER", model.get("BEDEL"));
					}
				}
			}
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}
	}

	/** TY-6229 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	@GraymoundService("BNSPR_TRN3171_GET_KREDILENDIRILEBILECEK_MAX_TUTAR")
	public static GMMap getKredilendirilebilecekMaxTutar(GMMap iMap) {

		BigDecimal bdHesaplanacakTutar = iMap.getBigDecimal("HESAPLANACAK_TUTAR");
		BigDecimal bdPriceLimit = new BigDecimal(GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap.put("KOD", "LTV_MAX_LIMIT_TUTAR").put("KEY", "LTV_MAX_LIMIT_TUTAR")).getString("TEXT"));
		BigDecimal bdKredilendirilebilecekMaxTutar = null;

		try {
			if (bdHesaplanacakTutar != null) {
				if (bdHesaplanacakTutar.compareTo(bdPriceLimit) == 1) {
					BigDecimal bdPriceDifference = bdHesaplanacakTutar.subtract(bdPriceLimit);
					bdKredilendirilebilecekMaxTutar = bdPriceLimit.multiply(new BigDecimal("0.7")).add(bdPriceDifference.multiply(new BigDecimal("0.5")));
				}
				else {
					bdKredilendirilebilecekMaxTutar = bdHesaplanacakTutar.multiply(new BigDecimal("0.7"));
				}
			}
			iMap.put("KREDILENDIRILEBILECEK_MAX_TUTAR", bdKredilendirilebilecekMaxTutar);
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/** TY-6229 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	@GraymoundService("BNSPR_TRN3171_CHECK_LTV_KURALI")
	public static GMMap checkLtvKurali(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal bdKrediTutari = iMap.getBigDecimal("KREDI_TUTARI");
		BigDecimal bdKredilendirilebilecekMaxTutar = iMap.getBigDecimal("KREDILENDIRILEBILECEK_MAX_TUTAR");

		Session session = DAOSession.getSession("BNSPRDal");
		BirKampanya birKampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", iMap.getBigDecimal("KAMPANYA_KODU"))).uniqueResult();
		String ticariKrediEh = "H";
		if (birKampanya != null) {
			ticariKrediEh = birKampanya.getTicariKrediEh();
		}

		try {
			// Ticari Kredilerde LTV kontrolu yapilmasin.
			if ("H".equals(ticariKrediEh)) {
				if (bdKrediTutari.compareTo(bdKredilendirilebilecekMaxTutar) == 1) {
					iMap.put("HATA_NO", new BigDecimal(4263));
					iMap.put("P1", "Max. [" + bdKredilendirilebilecekMaxTutar + "] TL ye kadar kredi talebinde bulunabilirsiniz.");

					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}
			oMap.put("TICARI_KREDI_EH", ticariKrediEh);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/** TY-6229 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	@GraymoundService("BNSPR_TRN3171_CHECK_VADE_KURALI")
	public static GMMap checkVadeKurali(GMMap iMap) {

		int iKrediVade = iMap.getInt("KREDI_VADE");
		int iAracModelYili = iMap.getInt("ARAC_MODEL_YILI");
		int iYear = Calendar.getInstance().get(Calendar.YEAR);
		int iAracYasi = iYear - iAracModelYili;
		GMMap paramMap = new GMMap();
		paramMap.put("PARAMETRE", "BAYI_MAX_ARAC_YASI");
		int maxAracYasi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", paramMap).getInt("DEGER",14);

		try {
			if (iAracYasi <= maxAracYasi) {
				if (iAracYasi * 12 + iKrediVade > (maxAracYasi+1)*12) {
					iMap.put("HATA_NO", new BigDecimal(4263));
					iMap.put("P1", "Maksimum [" + String.valueOf(((maxAracYasi+1)*12) - iAracYasi * 12) + "] aya kadar kredi talebinde bulunabilirsiniz.");

					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}
			else {
				iMap.put("HATA_NO", new BigDecimal(4263));
				iMap.put("P1", "Arac�n Ya�� " + maxAracYasi + " y�ldan b�y�k olamaz.");

				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/** TY-6229 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	@GraymoundService("BNSPR_TRN3171_CHECK_PLAKA")
	public static GMMap checkPlaka(GMMap iMap) {

		String sPlaka = iMap.getString("PLAKA");

		try {
			if (sPlaka == null || sPlaka.equals("")) {
				iMap.put("HATA_NO", new BigDecimal(4263));
				iMap.put("P1", "2. El Ara�larda Plaka Girilmesi Zorunludur.");

				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
	@GraymoundService("BNSPR_TRN3171_CHECK_MARKA_MODEL_YIL")
	public static GMMap checkMarkaModelYil(GMMap iMap) {

		String marka = iMap.getString("MARKA");
		String yil = iMap.getString("YIL");
		String model = iMap.getString("MODEL");
		String aracTipiSifirArac = iMap.getString("ARAC_TIPI_SIFIR_ARAC");
		String anahtarTeslimFiyati = iMap.getString("ANAHTAR_TESLIM_FIYATI");

		try {
			if (marka == null || marka.equals("")) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Marka");

				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (yil == null || yil.equals("")) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Y�l");

				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (model == null || model.equals("")) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Model");

				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (aracTipiSifirArac.equals("E")) {
				if (anahtarTeslimFiyati == null || anahtarTeslimFiyati.equals("0.00")) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Anahtar Teslim Fiyat�");

					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}

			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_FAIZSIZ_FINANSMAN_EH")
	public static GMMap faizsizFinansmanEh(GMMap iMap) {
		GMMap oMap = new GMMap();
		List<?> list = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			if (StringUtils.isNotBlank(iMap.getString("BASVURU_NO"))) {
				list = session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("faizsizFinansman", "E")).list();
			}
			else if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
				list = session.createCriteria(BirBasvuru.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.eq("faizsizFinansman", "E")).list();
			}
			else {
				throw new GMRuntimeException(0, "M��teri No / Ba�vuru No dan birisi dolu olmal�d�r.");
			}

			if (list.size() > 0) {
				oMap.put("FAIZSIZ_FINANSMAN", "E");
			}
			else {
				oMap.put("FAIZSIZ_FINANSMAN", "H");
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3171_BASVURU_KAMPANYA_KONTROL")
	public static Map<?, ?> basvuruKampanyaKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_basvuru.basvuru_kampanya_kontrol(?,?,?) }");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KOD"));
			stmt.execute();

			GMMap oMap = new GMMap();
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
