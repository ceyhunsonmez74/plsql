package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrdAltTur2Tx;
import tr.com.aktifbank.bnspr.dao.BirKrdAltTur2TxId;
import tr.com.aktifbank.bnspr.dao.VMlBirKrdAltTur2;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKrdTurKnl;
import tr.com.calikbank.bnspr.dao.BirKrdTurKnlTx;
import tr.com.calikbank.bnspr.dao.BirKrdTurKnlTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3103Services {
	@GraymoundService("BNSPR_TRN3103_GET_COMBOBOX_INITIAL_VALUES")
	public static GMMap getComboboxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		getGecerlimi(oMap, "GECERLI_MI");
		
		iMap.put("KOD", "KRD_MUSTERI_TIP_KOD");
		oMap.put("MUSTERI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		getInternetGoruntulensinmi(oMap, "INT_GORNTUMELENME");
		getEveTeslimatliUrun(oMap, "EVE_TESLIMATLI_URUN");
		getDovizKodlari(oMap, "DOVIZ_KODLARI");
		getKanalKodlari(oMap, "KANAL_KODLARI");
		getGecerlimi(oMap, "DRM");
		getInternetGoruntulensinmi(oMap, "SERBEST_KATKI_PAYI");
		getTasitSecenek(oMap, "TASIT_SECENEK");
		return oMap;
	}

	public static void getGecerlimi(GMMap oMap, String listName) {
		GuimlUtil.wrapMyCombo(oMap, listName, "G", "Ge�erli");
		GuimlUtil.wrapMyCombo(oMap, listName, "I", "Ge�ersiz");
	}

	public static void getInternetGoruntulensinmi(GMMap oMap, String listName) {
		GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
	}

	public static void getEveTeslimatliUrun(GMMap oMap, String listName) {
		GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
	}
	
	public static void getTasitSecenek(GMMap oMap, String listName) {
		oMap.put("ADD_EMPTY_KEY", "H");
		oMap.put("LIST_NAME", listName);
		oMap.put("LIST_QUERY", "SELECT KEY1,TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'TASIT_SECENEK' ORDER BY KEY1");
		DALUtil.fillComboBox(oMap);
	}

	@GraymoundService("BNSPR_TRN3103_GET_KRD_ALT_TUR_2")
	public static GMMap getKrdAltTur(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(VMlBirKrdAltTur2.class).add(Restrictions.eq("id.krdTurKod", iMap.getBigDecimal("KRD_TUR_KOD")))
																				.add(Restrictions.eq("id.krdTurAltKod", iMap.getBigDecimal("KRD_ALT_TUR_KOD")))
																				.list();

			
			GMMap oMap = new GMMap();
			String tableName = "KREDI_TANIMLAMA";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				VMlBirKrdAltTur2 birKrdAltTur2 = (VMlBirKrdAltTur2) iterator.next();

				oMap.put(tableName, row, "ACIKLAMA", birKrdAltTur2.getAciklama());
				oMap.put(tableName, row, "FAIZ_KORUMA_SURESI", birKrdAltTur2.getFaizOranKorumaSure());
				oMap.put(tableName, row, "GECERLI_MI", birKrdAltTur2.getDrm());
				oMap.put(tableName, row, "KOD", birKrdAltTur2.getId().getKod());
				oMap.put(tableName, row, "MUSTERI_TIPI", birKrdAltTur2.getMusTip());
				oMap.put(tableName, row, "SECENEK", birKrdAltTur2.getSecenek());
				oMap.put(tableName, row, "EVE_TESLIMATLI_URUN", birKrdAltTur2.getEveTeslimatliUrun()==null?"H":birKrdAltTur2.getEveTeslimatliUrun());
				
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3103_GET_KREDI_DETAY")
	public static GMMap getSubeler(GMMap iMap) {
		GMMap oMap = new GMMap();
		Object o = null;
		if (iMap.get("KOD") != null)
			o = GMContext.getCurrentContext().getSession().get(iMap.getBigDecimal("TRX_NO").toString().concat(iMap.getString("KOD")));
		if (o == null) {
			try {
				Session session = DAOSession.getSession("BNSPRDal");

				List<?> list = (List<?>) session.createCriteria(BirKrdTurKnl.class).add(Restrictions.and(Restrictions.eq("krdTurKod", iMap.getBigDecimal("KRD_TUR_KOD")), Restrictions.and(Restrictions.eq("krdTurAltKod", iMap.getBigDecimal("KRD_ALT_TUR_KOD")), Restrictions.eq("krdTurAltKod2", iMap.getBigDecimal("KOD"))))).list();

				String tableName = "KREDI_DETAY_TANIMLAMA";
				int row = 0;
				for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
					BirKrdTurKnl birKrdTurKnl = (BirKrdTurKnl) iterator.next();

					oMap.put(tableName, row, "ID", birKrdTurKnl.getId());
					oMap.put(tableName, row, "K_KOD", birKrdTurKnl.getKrdTurAltKod2());
					oMap.put(tableName, row, "KANAL_KODU", birKrdTurKnl.getKanalKod());
					oMap.put(tableName, row, "KANALDAKI_ADI", birKrdTurKnl.getKanaldakiAd());
					oMap.put(tableName, row, "DOVIZ_CINSI", birKrdTurKnl.getDovizKod());
					oMap.put(tableName, row, "FAIZ_MARJI", birKrdTurKnl.getFaizMarj());
					oMap.put(tableName, row, "ESKI_FAIZ_MARJI", birKrdTurKnl.getFaizMarj());
					oMap.put(tableName, row, "ALT_LIMIT", birKrdTurKnl.getAltLimit());
					oMap.put(tableName, row, "UST_LIMIT", birKrdTurKnl.getUstLimit());
					oMap.put(tableName, row, "MIN_VADE", birKrdTurKnl.getMinVade());
					oMap.put(tableName, row, "MAX_VADE", birKrdTurKnl.getMaxVade());
					oMap.put(tableName, row, "MIN_KATKI_PAYI", birKrdTurKnl.getMinKatki());
					oMap.put(tableName, row, "MAX_KATKI_PAYI", birKrdTurKnl.getMaxKatki());
					oMap.put(tableName, row, "ODEME_GRUBU", birKrdTurKnl.getOdmGrpNo());
					oMap.put(tableName, row, "INT_GORNTUMELENME", birKrdTurKnl.getInternetGor());
					oMap.put(tableName, row, "DRM", birKrdTurKnl.getDrm());
					oMap.put(tableName, row, "SERBEST_KATKI_PAYI", birKrdTurKnl.getSerbestKatkiPay());
					
					row++;
				}
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		} else {
			oMap.put("KREDI_DETAY_TANIMLAMA", GMContext.getCurrentContext().getSession().get(iMap.getBigDecimal("TRX_NO").toString().concat(iMap.getString("KOD"))));
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3103_PUT_KREDI_TO_CONTEX")
	public static Map<?, ?> putKrediToContext(GMMap iMap) {
		if (iMap.get("KOD") != null)
			GMContext.getCurrentContext().getSession().put(iMap.getBigDecimal("TRX_NO").toString().concat(iMap.getString("KOD")), iMap.get("KREDI_DETAY_TANIMLAMA"));
		return new GMMap();
	}

	@GraymoundService("BNSPR_TRN3103_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		boolean flag = true;
		boolean flag1 = true;
		BigDecimal krdAltTurKod2 = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> listKrdAltTur = (List<?>) session.createCriteria(BirKrdAltTur2Tx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (Iterator<?> iterator = listKrdAltTur.iterator(); iterator.hasNext();) {
				BirKrdAltTur2Tx birKrdAltTur2Tx = (BirKrdAltTur2Tx) iterator.next();
				session.delete(birKrdAltTur2Tx);
			}
			List<?> listKrdTurKnl = (List<?>)session.createCriteria(BirKrdTurKnlTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (Iterator<?> iterator = listKrdTurKnl.iterator(); iterator.hasNext();) {
				BirKrdTurKnlTx birKrdTurKnlTx = (BirKrdTurKnlTx) iterator.next();
				session.delete(birKrdTurKnlTx);
			}

			session.flush();

			String tableName = "KREDI_TANIMLAMA";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {
				tableName = "KREDI_TANIMLAMA";
				BirKrdAltTur2Tx birKrdAltTur2Tx = new BirKrdAltTur2Tx();
				BirKrdAltTur2TxId birKrdAltTur2TxId = new BirKrdAltTur2TxId();
				krdAltTurKod2 = iMap.getBigDecimal(tableName, i, "KOD");
				birKrdAltTur2TxId.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
				birKrdAltTur2TxId.setKrdTurAltKod(iMap.getBigDecimal("KRD_ALT_TUR_KOD"));
				birKrdAltTur2TxId.setKrdTurKod(iMap.getBigDecimal("KRD_TUR_KOD"));
				birKrdAltTur2TxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				if (iMap.getString(tableName, i, "SECENEK") != null)
					birKrdAltTur2Tx.setSecenek(iMap.getString(tableName, i, "SECENEK"));
				else
					birKrdAltTur2Tx.setSecenek("0");

				birKrdAltTur2Tx.setId(birKrdAltTur2TxId);
				birKrdAltTur2Tx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				birKrdAltTur2Tx.setFaizOranKorumaSure(iMap.getBigDecimal(tableName, i, "FAIZ_KORUMA_SURESI"));
				birKrdAltTur2Tx.setDrm(iMap.getString(tableName, i, "GECERLI_MI"));
				birKrdAltTur2Tx.setMusTip(iMap.getString(tableName, i, "MUSTERI_TIPI"));
				birKrdAltTur2Tx.setEveTeslimatliUrun(iMap.getString(tableName, i, "EVE_TESLIMATLI_URUN"));

				Object o = null;
				ArrayList<?> krediDetayList = null;
				if (iMap.get("KOD") != null) {
					krediDetayList = (ArrayList<?>) GMContext.getCurrentContext().getSession().get(iMap.getBigDecimal("TRX_NO").toString().concat(iMap.getString(tableName, i, "KOD")));
					o = GMContext.getCurrentContext().getSession().get(iMap.getBigDecimal("TRX_NO").toString().concat(iMap.getString(tableName, i, "KOD")));
					iMap.put("KREDI_DETAY_LIST", krediDetayList);
				}

				if (o != null) {
					tableName = "KREDI_DETAY_LIST";
					for (int j = 0; j < krediDetayList.size(); j++) {
						BirKrdTurKnlTx birKrdTurKnlTx = new BirKrdTurKnlTx();
						BirKrdTurKnlTxId birKrdTurKnlTxId = new BirKrdTurKnlTxId();

						birKrdTurKnlTxId.setId(iMap.getBigDecimal(tableName, j, "ID"));
						birKrdTurKnlTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birKrdTurKnlTx.setId(birKrdTurKnlTxId);

						birKrdTurKnlTx.setDovizKod(iMap.getString(tableName, j, "DOVIZ_CINSI"));
						birKrdTurKnlTx.setKanalKod(iMap.getString(tableName, j, "KANAL_KODU"));
						birKrdTurKnlTx.setKrdTurAltKod(iMap.getBigDecimal("KRD_ALT_TUR_KOD"));
						birKrdTurKnlTx.setKrdTurAltKod2(iMap.getBigDecimal(tableName, j, "K_KOD"));
						birKrdTurKnlTx.setKrdTurKod(iMap.getBigDecimal("KRD_TUR_KOD"));
						if (iMap.getBigDecimal(tableName, j, "ALT_LIMIT") != null)
							birKrdTurKnlTx.setAltLimit(iMap.getBigDecimal(tableName, j, "ALT_LIMIT"));
						else
							birKrdTurKnlTx.setAltLimit(new BigDecimal(0));
						if (iMap.getBigDecimal(tableName, j, "UST_LIMIT") != null)
							birKrdTurKnlTx.setUstLimit(iMap.getBigDecimal(tableName, j, "UST_LIMIT"));
						else
							birKrdTurKnlTx.setUstLimit(new BigDecimal(0));
						if (iMap.getBigDecimal(tableName, j, "FAIZ_MARJI") != null)
							birKrdTurKnlTx.setFaizMarj(iMap.getBigDecimal(tableName, j, "FAIZ_MARJI"));
						else
							birKrdTurKnlTx.setFaizMarj(new BigDecimal(0));

						if (iMap.getBigDecimal(tableName, j, "ESKI_FAIZ_MARJI") != null)
							birKrdTurKnlTx.setEskiFaizMarj(iMap.getBigDecimal(tableName, j, "ESKI_FAIZ_MARJI"));
						else
							birKrdTurKnlTx.setEskiFaizMarj(new BigDecimal(0));
						birKrdTurKnlTx.setDrm(iMap.getString(tableName, j, "GECERLI_MI"));
						birKrdTurKnlTx.setInternetGor(iMap.getString(tableName, j, "INT_GORNTUMELENME"));
						birKrdTurKnlTx.setKanaldakiAd(iMap.getString(tableName, j, "KANALDAKI_ADI"));
						birKrdTurKnlTx.setMaxKatki(iMap.getBigDecimal(tableName, j, "MAX_KATKI_PAYI"));
						birKrdTurKnlTx.setMaxVade(iMap.getBigDecimal(tableName, j, "MAX_VADE"));
						birKrdTurKnlTx.setMinKatki(iMap.getBigDecimal(tableName, j, "MIN_KATKI_PAYI"));
						birKrdTurKnlTx.setMinVade(iMap.getBigDecimal(tableName, j, "MIN_VADE"));
						birKrdTurKnlTx.setOdmGrpNo(iMap.getBigDecimal(tableName, j, "ODEME_GRUBU"));
						birKrdTurKnlTx.setDrm(iMap.getString(tableName, j, "DRM"));
						birKrdTurKnlTx.setSerbestKatkiPay(iMap.getString(tableName, j, "SERBEST_KATKI_PAYI"));

						session.save(birKrdTurKnlTx);
						flag1 = false;
						GMContext.getCurrentContext().getSession().put(iMap.getBigDecimal("TRX_NO").toString().concat(iMap.getString("KREDI_TANIMLAMA", i, "KOD")), null);
					}
					if (flag1)
						kayitSil(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("KRD_TUR_KOD"), iMap.getBigDecimal("KRD_ALT_TUR_KOD"), krdAltTurKod2);

				}

				session.save(birKrdAltTur2Tx);
				flag = false;
			}
			session.flush();
			if (flag)
				kayitSil(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("KRD_TUR_KOD"), iMap.getBigDecimal("KRD_ALT_TUR_KOD"));

			iMap.put("TRX_NAME", "3103");
			/*Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			Map<?, ?> myMap = GMServiceExecuter.execute("BNSPR_KREDI_FAIZ_ORAN_TO_TURKLINE", iMap);

			if(myMap.get("RESULT").equals("HATA")){
				throw new GMRuntimeException(0, "TurkLine Aktar�mda hata al�nd�");
			}
			return oMap;*/
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static void kayitSil(BigDecimal trxNo, BigDecimal kod, BigDecimal kod1) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3103.TumKayitSil_kod2(?,?,?)}");
			stmt.setBigDecimal(1, trxNo);
			stmt.setBigDecimal(2, kod);
			stmt.setBigDecimal(3, kod1);
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static void kayitSil(BigDecimal trxNo, BigDecimal kod, BigDecimal kod1, BigDecimal kod2) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3103.TumKayitSil_knl(?,?,?,?)}");
			stmt.setBigDecimal(1, trxNo);
			stmt.setBigDecimal(2, kod);
			stmt.setBigDecimal(3, kod1);
			stmt.setBigDecimal(4, kod2);
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap getDovizKodlari(GMMap oMap, String listName) {
		oMap.put("ADD_EMPTY_KEY", "H");
		oMap.put("LIST_NAME", listName);
		oMap.put("LIST_QUERY", "select V.kod as doviz_kodu,V.kod aciklama from v_ml_gnl_doviz_kod_pr V where Pkg_Bireysel.KulDov ( V.KOD ) = 'E' order by V.SIRA_NO");
		DALUtil.fillComboBox(oMap);
		return oMap;
	}

	public static GMMap getKanalKodlari(GMMap oMap, String listName) {
		oMap.put("ADD_EMPTY_KEY", "H");
		oMap.put("LIST_NAME", listName);
		oMap.put("LIST_QUERY", "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by 1");
		DALUtil.fillComboBox(oMap);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3103_GET_KRD_ALT_TUR_DETAY_WITH_TX_NO")
	public static GMMap getKrdAltTurWithTxNo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirKrdAltTur2Tx.class).add(Restrictions.and(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")), Restrictions.isNull("sil"))).list();

			String tableName = "KREDI_TANIMLAMA";
			int row = 0;
			GMMap oMap = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirKrdAltTur2Tx birKrdAltTur2Tx = (BirKrdAltTur2Tx) iterator.next();

				oMap.put("KRD_TUR_KOD", birKrdAltTur2Tx.getId().getKrdTurKod());
				oMap.put("KRD_ALT_TUR_KOD", birKrdAltTur2Tx.getId().getKrdTurAltKod());
				oMap.put(tableName, row, "ACIKLAMA", birKrdAltTur2Tx.getAciklama());
				oMap.put(tableName, row, "FAIZ_KORUMA_SURESI", birKrdAltTur2Tx.getFaizOranKorumaSure());
				oMap.put(tableName, row, "GECERLI_MI", birKrdAltTur2Tx.getDrm());
				oMap.put(tableName, row, "KOD", birKrdAltTur2Tx.getId().getKod());
				oMap.put(tableName, row, "MUSTERI_TIPI", birKrdAltTur2Tx.getMusTip());
				oMap.put(tableName, row, "SECENEK", birKrdAltTur2Tx.getSecenek());
				oMap.put(tableName, row, "EVE_TESLIMATLI_URUN", birKrdAltTur2Tx.getEveTeslimatliUrun());

				row++;
			}
			oMap.put("KREDI_TURU_ADI", LovHelper.diLov(oMap.getString("KRD_TUR_KOD"), "3103/LOV_KREDI_TUR", "ACIKLAMA"));
			oMap.put("KREDI_ALT_TURU_ADI", LovHelper.diLov(oMap.getString("KRD_ALT_TUR_KOD"), oMap.getString("KRD_TUR_KOD"), "3103/LOV_KREDI_ALT_TUR", "ACIKLAMA"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3103_GET_KRD_DETAY_INFO")
	public static GMMap getKrdDetayInfo(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			
			List<?> list1 = (List<?>) session.createCriteria(BirKrdTurKnlTx.class).add(Restrictions.and(Restrictions.and(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")),Restrictions.eq("krdTurAltKod2", iMap.getBigDecimal("KRD_TUR_ALT_KOD2"))) , Restrictions.isNull("sil"))).list();
			String tableName = "KREDI_DETAY_TANIMLAMA";
			int row = 0;
			for (Iterator<?> iterator = list1.iterator(); iterator.hasNext();) {
				BirKrdTurKnlTx birKrdTurKnlTx = (BirKrdTurKnlTx) iterator.next();

				oMap.put(tableName, row, "ID", birKrdTurKnlTx.getId().getId());
				oMap.put(tableName, row, "K_KOD", birKrdTurKnlTx.getKrdTurAltKod2());
				oMap.put(tableName, row, "KANAL_KODU", birKrdTurKnlTx.getKanalKod());
				oMap.put(tableName, row, "KANALDAKI_ADI", birKrdTurKnlTx.getKanaldakiAd());
				oMap.put(tableName, row, "DOVIZ_CINSI", birKrdTurKnlTx.getDovizKod());
				oMap.put(tableName, row, "FAIZ_MARJI", birKrdTurKnlTx.getFaizMarj());
				oMap.put(tableName, row, "ALT_LIMIT", birKrdTurKnlTx.getAltLimit());
				oMap.put(tableName, row, "UST_LIMIT", birKrdTurKnlTx.getUstLimit());
				oMap.put(tableName, row, "MIN_VADE", birKrdTurKnlTx.getMinVade());
				oMap.put(tableName, row, "MAX_VADE", birKrdTurKnlTx.getMaxVade());
				oMap.put(tableName, row, "MIN_KATKI_PAYI", birKrdTurKnlTx.getMinKatki());
				oMap.put(tableName, row, "MAX_KATKI_PAYI", birKrdTurKnlTx.getMaxKatki());
				oMap.put(tableName, row, "ODEME_GRUBU", birKrdTurKnlTx.getOdmGrpNo());
				oMap.put(tableName, row, "INT_GORNTUMELENME", birKrdTurKnlTx.getInternetGor());
				oMap.put(tableName, row, "DRM", birKrdTurKnlTx.getDrm());
				oMap.put(tableName, row, "SERBEST_KATKI_PAYI", birKrdTurKnlTx.getSerbestKatkiPay());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3103_KREDI_DETAY_TUM_KAYIT_SIL")
	public static GMMap krediDetayTumKayitSil(GMMap iMap){
		try {
			
			ArrayList<Object> list = new ArrayList<Object>();
			String str = iMap.getString("KREDI_TANIMLAMA_KOD");
			String ydk = "";
			for (int i = 0; i < str.length(); i++) {
				if (str.charAt(i) != ',')
					ydk = ydk + str.charAt(i);
				else {
					list.add(ydk);
					ydk = "";
				}
			}
			list.add(ydk);
			for (int i = 0; i < list.size(); i++) {
				BigDecimal kod = new BigDecimal(Integer.parseInt(list.get(i) + ""));
				kayitSil(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("KRD_TUR_KOD"), iMap.getBigDecimal("KRD_ALT_TUR_KOD"), kod);
			}
			return new GMMap();
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3103_NOT_NULL_SECIM_KRITERLERI")
	public static GMMap notNullSecimKriterTRN3103(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			if (iMap.getBigDecimal("KREDI_TURU") == null) {
				iMap.put("HATA_NO", new BigDecimal(758));
				iMap.put("P1", "Kredi T�r� ve Kredi Tipini");
				iMap.put("P2", "Listele");
				return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			} else if (iMap.getBigDecimal("KREDI_TURU") != null) {
				if (iMap.getBigDecimal("KREDI_TIPI") == null) {
					iMap.put("HATA_NO", new BigDecimal(758));
					iMap.put("P1", "Kredi Tipi");
					iMap.put("P2", "Listele");
					return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);					
				}
			}

			return new GMMap();

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN3103_AFTER_APROVAL")
	public static GMMap afterApproval(GMMap iMap) { 
		try {
			GMServiceExecuter.execute("BNSPR_KREDI_FAIZ_ORAN_TO_TURKLINE", new GMMap());
			GMServiceExecuter.execute("BNSPR_DELETE_TURKLINE_KREDI_DATA", new GMMap());
			GMServiceExecuter.execute("BNSPR_SET_TURKLINE_KREDITUR_DATA", new GMMap());
			GMServiceExecuter.execute("BNSPR_SET_TURKLINE_KREDI_DATA", new GMMap());
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
