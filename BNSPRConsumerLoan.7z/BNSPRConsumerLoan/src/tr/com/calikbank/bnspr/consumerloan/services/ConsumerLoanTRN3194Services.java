package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipAdrTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipAdrTxId;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTelTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTelTxId;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTxId;
import tr.com.aktifbank.bnspr.dao.BirYasalTakipZararTx;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3194Services {
	private static final Logger logger = Logger.getLogger(ConsumerLoanTRN3194Services.class);
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3194_GET_COMBOBOX_INITIAL_VALUE")
	public static GMMap getComboBoxInitialValues(GMMap iMap) {
		try {			
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			List<GnlParametre> gnlParametre = (List<GnlParametre>) session.createCriteria(GnlParametre.class)
					.add(Restrictions.ilike("kod", "%3194_%")).list();
			if (gnlParametre != null && gnlParametre.size() > 0) {				
				int i = 0;
				oMap.put("ISLEM_TIPI",i,"VALUE", BigDecimal.ZERO);
				oMap.put("ISLEM_TIPI",i,"NAME", "Se�iniz");
				i++;				
				for(GnlParametre s : gnlParametre){
					oMap.put("ISLEM_TIPI",i,"VALUE", s.getDeger());
					oMap.put("ISLEM_TIPI",i,"NAME", s.getAciklama());
					i++;
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}


	@GraymoundService("BNSPR_TRN3194_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			if(iMap.getBigDecimal("ZARAR_DK").compareTo(BigDecimal.ZERO) == 0)
				throw new GMRuntimeException(0, "L�tfen i�lem tipi se�iniz !!");
			
			if(iMap.getBigDecimal("TAKIP_HESAP_NO") == null)
				throw new GMRuntimeException(0, "L�tfen zararla�t�rma yap�lacak Takip Hesap No'yu giriniz !!");
			
			if(iMap.getBigDecimal("ANAPARA_TUTAR").compareTo(BigDecimal.ZERO) == 0 && 
					iMap.getBigDecimal("MASRAF_TUTAR").compareTo(BigDecimal.ZERO) == 0){
				throw new GMRuntimeException(0, "Ba�vuruya ait zararla�t�rma yap�lacak uygun bakiyeli bir hesap bulunamad� !!");
			}
			
			BirYasalTakipZararTx birYasalTakipZararTx = new BirYasalTakipZararTx();					
			
			birYasalTakipZararTx.setAnaparaTutar(iMap.getBigDecimal("ANAPARA_TUTAR"));
			birYasalTakipZararTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESAP_NO"));
			birYasalTakipZararTx.setMasrafTutar(iMap.getBigDecimal("MASRAF_TUTAR"));
			birYasalTakipZararTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birYasalTakipZararTx.setTakipHesapNo(iMap.getBigDecimal("TAKIP_HESAP_NO"));
			birYasalTakipZararTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birYasalTakipZararTx.setUrunTipi(iMap.getString("URUN_TIPI"));
			birYasalTakipZararTx.setZararDk(iMap.getBigDecimal("ZARAR_DK"));
			
			session.saveOrUpdate(birYasalTakipZararTx);
			session.flush();

			iMap.put("TRX_NAME", "3194");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
		
}
