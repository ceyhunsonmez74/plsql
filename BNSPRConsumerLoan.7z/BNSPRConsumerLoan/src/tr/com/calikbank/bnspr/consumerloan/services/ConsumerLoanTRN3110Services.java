package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirTesvikTaksitli;
import tr.com.aktifbank.bnspr.dao.BirTesvikTaksitliTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikTanimKriterTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikTanimPrTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikTanimPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3110Services {
	@GraymoundService("BNSPR_TRN3110_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			iMap.put("KOD", "TESVIK_YONTEMI");
			oMap.put("TESVIK_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			int index = oMap.getSize("TESVIK_TIPI");
			oMap.put("TESVIK_TIPI", index, "VALUE", "");
			oMap.put("TESVIK_TIPI", index, "NAME", "");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3110_KAMPANYA_BAZLI_LISTELE")
	public static GMMap kampanyaBazliListele(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3110.QRY3110_KAMPANYA_BAZLI_LISTELE(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "RESULTS");
			for (int j = 0; j < oMap.getSize("RESULTS"); j++) {
				if (oMap.get("RESULTS", j, "TESVIK_TIPI") == null) {
					oMap.put("RESULTS", j, "TESVIK_TIPI", "");
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3110_BAYI_BAZLI_LISTELE")
	public static GMMap bayiBazliListele(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap oMap = new GMMap();
		;
		try {
			if (iMap.getBigDecimal("BAYI_KODU") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "BAYI KODU");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3110.QRY3110_BAYI_BAZLI_LISTELEME(?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAYI_KODU"));
			stmt.setString(i++, iMap.getString("TUM_KAMPANYA"));// EK
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(3);

			oMap = DALUtil.rSetResults(rSet, "RESULTS");
			for (int j = 0; j < oMap.getSize("RESULTS"); j++) {
				if (oMap.get("RESULTS", j, "TESVIK_TIPI") == null) {
					oMap.put("RESULTS", j, "TESVIK_TIPI", "");
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3110_BAYI_BAZLI_TUM_KAMPANYALAR_LISTELE")
	public static GMMap bayiBazliTumKampanyalarListele(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap;
		try {
			if (iMap.getBigDecimal("BAYI_KODU") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "BAYI KODU");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3110.QRY3110_BAYI_BAZLI_LISTELEME(?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAYI_KODU")); // EK
			stmt.setString(i++, iMap.getString("TUM_KAMPANYA"));
			stmt.registerOutParameter(i++, -10); // ref cursor

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(3);
			oMap = DALUtil.rSetResults(rSet, "RESULTS");
			if (oMap.getSize("RESULTS") == 0) {
				oMap.put("DEGER", 1);
			}
			else {
				oMap.put("DEGER", 2);
				// oMap.put("HATA_NO", 1946);
			}
			for (int j = 0; j < oMap.getSize("RESULTS"); j++) {
				if (oMap.get("RESULTS", j, "TESVIK_TIPI") == null) {
					oMap.put("RESULTS", j, "TESVIK_TIPI", "");
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3110_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirTesvikTanimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			BirTesvikTanimKriterTx birTesvikTanimKriterTx = (BirTesvikTanimKriterTx) session.createCriteria(BirTesvikTanimKriterTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			GMMap oMap = new GMMap();

			if ("B".equals(birTesvikTanimKriterTx.getTanimlamaSekli())) {
				oMap.put("BAYI_BAZINDA", true);
			}
			else {
				oMap.put("BAYI_BAZINDA", false);
			}
			if ("K".equals(birTesvikTanimKriterTx.getTanimlamaSekli())) {
				oMap.put("KAMPANYA_BAZINDA", true);
			}
			else {
				oMap.put("KAMPANYA_BAZINDA", false);
			}
			if ("H".equals(birTesvikTanimKriterTx.getTesvikOlacakMi())) {
				oMap.put("TESVIK", true);
			}
			else {
				oMap.put("TESVIK", false);
			}
			if ("E".equals(birTesvikTanimKriterTx.getTumKampanyalar())) {
				oMap.put("TUM_KAMPANYALAR", true);
			}
			else {
				oMap.put("TUM_KAMPANYALAR", false);
			}
			oMap.put("BAYI_KODU", birTesvikTanimKriterTx.getBayiKodu());
			oMap.put("BAYI_ADI", DALUtil.getResult("select s.satici_adi from bir_satici s where s.kod=" + birTesvikTanimKriterTx.getBayiKodu()));

			String tableName = "TESVIK_TANIMLAMA";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirTesvikTanimPrTx birTesvikTanimPrTx = (BirTesvikTanimPrTx) iterator.next();
				if (new BigDecimal(-1).equals(birTesvikTanimPrTx.getId().getKampanyaKodu())) {
					oMap.put(tableName, row, "KAMPANYA_KODU", "");
				}
				else {
					oMap.put(tableName, row, "KAMPANYA_KODU", birTesvikTanimPrTx.getId().getKampanyaKodu());
				}
				oMap.put(tableName, row, "KAMPANYA_ADI", DALUtil.getResult("select k.aciklama from bir_kampanya k where k.kod=" + birTesvikTanimPrTx.getId().getKampanyaKodu()));
				oMap.put(tableName, row, "TESVIK_TIPI", birTesvikTanimPrTx.getTesvikTipi());
				oMap.put(tableName, row, "BAYI_ORANI", birTesvikTanimPrTx.getBayiOrani());
				oMap.put(tableName, row, "BAYI_TUTARI", birTesvikTanimPrTx.getBayiTutari());
				oMap.put(tableName, row, "CALISAN_ORANI", birTesvikTanimPrTx.getCalisanOrani());
				oMap.put(tableName, row, "CALISAN_TUTARI", birTesvikTanimPrTx.getCalisanTutari());
				oMap.put(tableName, row, "BASLANGIC_TARIHI", birTesvikTanimPrTx.getId().getBaslangicTarihi());
				oMap.put(tableName, row, "BITIS_TARIHI", birTesvikTanimPrTx.getId().getBitisTarihi());
				if ("E".equals(birTesvikTanimPrTx.getSil())) {
					oMap.put("SIL", true);
				}
				else {
					oMap.put("SIL", false);
				}
				oMap.put(tableName, row, "BAYI_KODU", birTesvikTanimPrTx.getBayiKodu());

				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3110_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listBirTesvikTanimPrTx = (List<?>) session.createCriteria(BirTesvikTanimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = listBirTesvikTanimPrTx.iterator(); iterator.hasNext();) {
				BirTesvikTanimPrTx birTesvikTanimPrTx = (BirTesvikTanimPrTx) iterator.next();
				session.delete(birTesvikTanimPrTx);
			}
			session.flush();

			BirTesvikTanimKriterTx birTesvikTanimKriterTx = new BirTesvikTanimKriterTx();
			birTesvikTanimKriterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birTesvikTanimKriterTx.setBayiKodu(iMap.getBigDecimal("BAYI_KOD"));
			if (iMap.getBoolean("BAYI_BAZINDA"))
				birTesvikTanimKriterTx.setTanimlamaSekli("B");
			if (iMap.getBoolean("KAMPANYA_BAZINDA"))
				birTesvikTanimKriterTx.setTanimlamaSekli("K");
			if (iMap.getBoolean("TUM_KAMPANYALAR"))
				birTesvikTanimKriterTx.setTumKampanyalar("E");
			else
				birTesvikTanimKriterTx.setTumKampanyalar("H");
			if (iMap.getBoolean("TESVIK_DURUMU"))
				birTesvikTanimKriterTx.setTesvikOlacakMi("H");
			else
				birTesvikTanimKriterTx.setTesvikOlacakMi("E");

			String tableName = "TESVIK_TANIMLAMA";
			ArrayList<Object> tesvikTanimList = (ArrayList<Object>) iMap.get(tableName);
			ArrayList<Object> tesvikTanimListTemp = new ArrayList<Object>();
			HashSet<Integer> tobeDeleted = new HashSet<Integer>();
			for (int i = 0; i < tesvikTanimList.size(); i++) {
				BigDecimal kampKod = iMap.getBigDecimal(tableName, i, "KAMPANYA_KODU");
				if (iMap.getBoolean(tableName, i, "SIL") || kampKod == null)
					continue;
				for (int j = 0; j < tesvikTanimList.size(); j++) {
					if (iMap.getBigDecimal(tableName, j, "KAMPANYA_KODU") == null)
						continue;
					if (kampKod.compareTo(iMap.getBigDecimal(tableName, j, "KAMPANYA_KODU")) == 0 && iMap.getBoolean(tableName, j, "SIL")) {
						tobeDeleted.add(j);
					}
				}
			}

			for (int i = 0; i < tesvikTanimList.size(); i++) {
				if (!tobeDeleted.contains(i)) {
					tesvikTanimListTemp.add(tesvikTanimList.get(i));
				}
			}
			tesvikTanimList = tesvikTanimListTemp;

			tesvikTanimListTemp = new ArrayList<Object>();
			tobeDeleted = new HashSet<Integer>();

			for (int i = 0; i < tesvikTanimList.size(); i++) {
				BigDecimal kampKod = iMap.getBigDecimal(tableName, i, "KAMPANYA_KODU");
				if (!iMap.getBoolean(tableName, i, "SIL") || kampKod == null)
					continue;
				for (int j = i + 1; j < tesvikTanimList.size(); j++) {
					if (iMap.getBigDecimal(tableName, j, "KAMPANYA_KODU") == null)
						continue;
					if (kampKod.compareTo(iMap.getBigDecimal(tableName, j, "KAMPANYA_KODU")) == 0 && iMap.getBoolean(tableName, j, "SIL")) {
						tobeDeleted.add(j);
					}
				}
			}

			for (int i = 0; i < tesvikTanimList.size(); i++) {
				if (!tobeDeleted.contains(i)) {
					tesvikTanimListTemp.add(tesvikTanimList.get(i));
				}
			}
			tesvikTanimList = tesvikTanimListTemp;

			iMap.put(tableName, tesvikTanimList);

			if (iMap.getBoolean("TUM_KAMPANYALAR") && tesvikTanimList.size() == 0) {
				iMap.put("HATA_NO", new BigDecimal(2016)); // mesaj yaz!!!
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			for (int i = 0; i < tesvikTanimList.size(); i++) {

				if (iMap.getBoolean(tableName, i, "SIL") && iMap.getString(tableName, i, "KAMPANYA_KODU") == null && !iMap.getBoolean("TUM_KAMPANYALAR"))
					continue;
				if (iMap.getBoolean(tableName, i, "SIL") && (iMap.getString(tableName, i, "TESVIK_TIPI") == null || iMap.getString(tableName, i, "TESVIK_TIPI").length() == 0) && !iMap.getBoolean("TUM_KAMPANYALAR"))
					continue;
				if (iMap.getBoolean(tableName, i, "SIL") && (iMap.getString(tableName, i, "TESVIK_TIPI") == null || iMap.getString(tableName, i, "TESVIK_TIPI").length() == 0) && iMap.getBoolean("TUM_KAMPANYALAR")) {
					birTesvikTanimKriterTx.setTumKampanyalar("H");
					continue;
				}
				boolean l = false;

				for (int j = i + 1; j < tesvikTanimList.size(); j++) {

					if (iMap.getBoolean(tableName, j, "SIL") && iMap.getString(tableName, j, "KAMPANYA_KODU") == null && !iMap.getBoolean("TUM_KAMPANYALAR"))
						continue;
					if (iMap.getBoolean(tableName, j, "SIL") && (iMap.getString(tableName, j, "TESVIK_TIPI") == null || iMap.getString(tableName, j, "TESVIK_TIPI").length() == 0))
						continue;
					if ((iMap.getString(tableName, j, "KAMPANYA_KODU") == null || iMap.getString(tableName, j, "KAMPANYA_KODU").length() == 0)) {
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j + 1);
						iMap.put("P2", "KAMPANYA_KODU");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}

					l = iMap.getString(tableName, j, "KAMPANYA_KODU").compareTo(iMap.getString(tableName, i, "KAMPANYA_KODU")) == 0 
							&& ConsumerLoanCommonServices.nvl(iMap.getString(tableName, j, "SEGMENT"), "").compareTo(ConsumerLoanCommonServices.nvl(iMap.getString(tableName, i, "SEGMENT"), "")) == 0 
							&& ((iMap.getDate(tableName, j, "BASLANGIC_TARIHI").before(iMap.getDate(tableName, i, "BASLANGIC_TARIHI")) 
									&& iMap.getDate(tableName, j, "BITIS_TARIHI").after(iMap.getDate(tableName, i, "BASLANGIC_TARIHI"))) 
									|| (iMap.getDate(tableName, j, "BASLANGIC_TARIHI").after(iMap.getDate(tableName, i, "BASLANGIC_TARIHI")) 
											&& iMap.getDate(tableName, j, "BASLANGIC_TARIHI").before(iMap.getDate(tableName, i, "BITIS_TARIHI"))));

					if (l) {

						iMap.put("HATA_NO", new BigDecimal(1949));
						iMap.put("P1", iMap.getString(tableName, j, "KAMPANYA_KODU"));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);

					}

				}

				if (iMap.getString(tableName, i, "TESVIK_TIPI") == null || iMap.getString(tableName, i, "TESVIK_TIPI").length() == 0) {
					iMap.put("HATA_NO", new BigDecimal(1453));
					iMap.put("P1", i + 1);
					iMap.put("P2", "TESVIK_TIPI");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				if ("".equals(iMap.getString(tableName, i, "TESVIK_TIPI"))) {
					String a = null;
					iMap.put(tableName, i, "TESVIK_TIPI", a);
				}

				BirTesvikTanimPrTx birTesvikTanimPrTx = new BirTesvikTanimPrTx();
				BirTesvikTanimPrTxId birTesvikTanimPrTxId = new BirTesvikTanimPrTxId();

				birTesvikTanimPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birTesvikTanimPrTx.setBayiKodu(iMap.getBigDecimal(tableName, i, "BAYI_KODU"));
				birTesvikTanimPrTx.setBayiOrani(iMap.getBigDecimal(tableName, i, "BAYI_ORANI"));
				birTesvikTanimPrTx.setBayiTutari(iMap.getBigDecimal(tableName, i, "BAYI_TUTARI"));
				birTesvikTanimPrTxId.setBaslangicTarihi(iMap.getDate(tableName, i, "BASLANGIC_TARIHI") == null ? new Date() : iMap.getDate(tableName, i, "BASLANGIC_TARIHI"));
				birTesvikTanimPrTxId.setBitisTarihi(iMap.getDate(tableName, i, "BITIS_TARIHI") == null ? DateUtils.addYears(new Date(), 1000) : iMap.getDate(tableName, i, "BITIS_TARIHI"));
				birTesvikTanimPrTx.setCalisanOrani(iMap.getBigDecimal(tableName, i, "CALISAN_ORANI"));
				birTesvikTanimPrTx.setCalisanTutari(iMap.getBigDecimal(tableName, i, "CALISAN_TUTARI"));
				birTesvikTanimPrTx.setTesvikTipi(iMap.getString(tableName, i, "TESVIK_TIPI"));
				birTesvikTanimPrTx.setSegment(iMap.getString(tableName, i, "SEGMENT"));
				if (iMap.getBoolean(tableName, i, "SIL")) {
					birTesvikTanimPrTx.setSil("E");
					if (iMap.getBoolean("TUM_KAMPANYALAR") && iMap.getBoolean("BAYI_BAZINDA")) {
						birTesvikTanimKriterTx.setTumKampanyalar("H");
						birTesvikTanimPrTxId.setKampanyaKodu(iMap.getBigDecimal(tableName, i, "KAMPANYA_KODU"));
					}
				}
				else {
					birTesvikTanimPrTx.setSil("H");
				}

				if (!iMap.getBoolean("TUM_KAMPANYALAR") && iMap.getBoolean("KAMPANYA_BAZINDA")) {
					if (iMap.getString(tableName, i, "KAMPANYA_KODU") == null || iMap.getString(tableName, i, "KAMPANYA_KODU").length() == 0) {
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", i + 1);
						iMap.put("P2", "KAMPANYA_KODU");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}

					birTesvikTanimPrTxId.setKampanyaKodu(iMap.getBigDecimal(tableName, i, "KAMPANYA_KODU"));
				}

				/*if(!iMap.getBoolean("TUM_KAMPANYALAR")&&iMap.getBoolean("BAYI_BAZINDA")&&"E".equals(iMap.getString("TUM_KAMPANYALAR_ESKI"))){
					birTesvikTanimPrTxId.setKampanyaKodu(new BigDecimal(-1));
					//birTesvikTanimPrTx.setSil("E");
				}*/
				if (!iMap.getBoolean("TUM_KAMPANYALAR") && iMap.getBoolean("BAYI_BAZINDA") && "H".equals(iMap.getString("TUM_KAMPANYALAR_ESKI"))) {
					if (iMap.getString(tableName, i, "KAMPANYA_KODU") == null || iMap.getString(tableName, i, "KAMPANYA_KODU").length() == 0) {
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", i + 1);
						iMap.put("P2", "KAMPANYA_KODU");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					birTesvikTanimPrTxId.setKampanyaKodu(iMap.getBigDecimal(tableName, i, "KAMPANYA_KODU"));
				}
				if (iMap.getBoolean("TUM_KAMPANYALAR") && iMap.getBoolean("BAYI_BAZINDA") && iMap.getBigDecimal(tableName, i, "KAMPANYA_KODU") == null) {
					birTesvikTanimPrTxId.setKampanyaKodu(new BigDecimal(-1));
				}

				if (iMap.getBoolean("TUM_KAMPANYALAR") && iMap.getBoolean("BAYI_BAZINDA") && iMap.getBigDecimal(tableName, i, "KAMPANYA_KODU") != null && !iMap.getBoolean(tableName, i, "SIL")) {
					iMap.put("HATA_NO", new BigDecimal(1946));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				birTesvikTanimPrTx.setId(birTesvikTanimPrTxId);
				session.saveOrUpdate(birTesvikTanimPrTx);
			}
			session.saveOrUpdate(birTesvikTanimKriterTx);
			session.flush();
			iMap.put("TRX_NAME", "3110");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TAKSITLI_TESVIK_JOB")
	public static GMMap taksitliTesvikJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("IS_PARALLEL", true);
			iMap.put("LIST_SERVICE_NAME", "BNSPR_TAKSITLI_TESVIK_JOB_LIST");
			iMap.put("PROCESS_SERVICE_NAME", "BNSPR_TAKSITLI_TESVIK_JOB_PROCESS");
			iMap.put("THREAD_SIZE", 12);
			GMServiceExecuter.execute("BNSPR_PROCESS_CREDIT_CARD_JOB", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TAKSITLI_TESVIK_JOB_LIST")
	public static GMMap taksitliTesvikList(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_TRN3206.taksitli_tesvik_list");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TAKSITLI_TESVIK_JOB_PROCESS")
	public static GMMap processtaksitliTesvik(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");

		if (iMap.getInt("TAKSIT_NO") != 1) {
			List<BirTesvikTaksitli> tesvikList = session.createCriteria(BirTesvikTaksitli.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("id.taksitNo")).list();

			if (tesvikList != null) {
				BirTesvikTaksitli sonKayit = tesvikList.get(0);

				BirTesvikTaksitliTx yeniTesvik = new BirTesvikTaksitliTx();

				yeniTesvik.setTxNo(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				yeniTesvik.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				yeniTesvik.setTaksitNo(iMap.getBigDecimal("TAKSIT_NO"));
				yeniTesvik.setKullandirimTutari(iMap.getBigDecimal("KRD_TUTAR"));
				yeniTesvik.setTesvikTaksiti(sonKayit.getKalanTesvikTutari().divide(iMap.getBigDecimal("KALAN_TAKSIT").add(BigDecimal.ONE),RoundingMode.HALF_UP));
				yeniTesvik.setKalanTesvikTutari(sonKayit.getKalanTesvikTutari().subtract(yeniTesvik.getTesvikTaksiti()));
				yeniTesvik.setToplamTesvikTutari(sonKayit.getToplamTesvikTutari());
				yeniTesvik.setKrdHesapNo(iMap.getBigDecimal("KRD_HESAP_NO"));

				session.save(yeniTesvik);
				session.flush();

				iMap.put("TRX_NO", yeniTesvik.getTxNo());
				iMap.put("TRX_ONAYSIZ_ISLEM", "E");
				iMap.put("TRX_NAME", "3206");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			}
		}
		else {
			BirTesvikTaksitliTx yeniTesvik = new BirTesvikTaksitliTx();
			yeniTesvik.setTxNo(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			yeniTesvik.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			yeniTesvik.setTaksitNo(iMap.getBigDecimal("TAKSIT_NO"));
			yeniTesvik.setKullandirimTutari(iMap.getBigDecimal("KRD_TUTAR"));
			yeniTesvik.setKrdHesapNo(iMap.getBigDecimal("KRD_HESAP_NO"));

			BigDecimal tesvikTaksiti = BigDecimal.ZERO;

			if (iMap.getBigDecimal("TOPLAM_TESVIK_TUTAR") != null) {
				tesvikTaksiti = iMap.getBigDecimal("TOPLAM_TESVIK_TUTAR").divide(iMap.getBigDecimal("KALAN_TAKSIT").add(BigDecimal.ONE), 2, RoundingMode.HALF_UP);

			}
			else {
				tesvikTaksiti = iMap.getBigDecimal("BAYI_TUTARI").divide(iMap.getBigDecimal("KALAN_TAKSIT").add(BigDecimal.ONE), 2, RoundingMode.HALF_UP);
			}

			yeniTesvik.setTesvikTaksiti(tesvikTaksiti);
			yeniTesvik.setKalanTesvikTutari(tesvikTaksiti.multiply(iMap.getBigDecimal("KALAN_TAKSIT")));
			yeniTesvik.setToplamTesvikTutari(tesvikTaksiti.add(yeniTesvik.getKalanTesvikTutari()));

			session.save(yeniTesvik);
			session.flush();

			iMap.put("TRX_NO", yeniTesvik.getTxNo());
			iMap.put("TRX_ONAYSIZ_ISLEM", "E");
			iMap.put("TRX_NAME", "3206");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}

		return oMap;
	}
}
