package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3127Services {
	@GraymoundService("BNSPR_QRY3127_GET_MESLEK_KOD")
	public static GMMap trn3117GetMeslekKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			StringBuffer query = new StringBuffer();
			query.append("SELECT ");
			query.append("KOD, ACIKLAMA, EGITIM_DIZI, YAS_DIZI ");
			query.append("FROM ");
			query.append("V_ML_GNL_MESLEK_KOD_PR ");
			query.append("ORDER BY ACIKLAMA");

			stmt = conn.prepareStatement(query.toString());
			rSet = stmt.executeQuery();
			
			String tableName = "MESLEK_MATRIX";

			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "KOD", rSet.getString("KOD"));
				oMap.put(tableName, row, "MESLEKLER", rSet.getString("ACIKLAMA"));
				
				String egitimDizi = rSet.getString("EGITIM_DIZI");
				if(egitimDizi == null)
				{
					for (Integer i = 1; i <= 6; i++) {
						oMap.put(tableName, row, "EGITIM" + i.toString(), false);
					}
				}
				else
				{
					for (Integer i = 1; i <= egitimDizi.length(); i++) {
						oMap.put(tableName, row, "EGITIM" + i.toString(), GuimlUtil.convertBinaryToCheckBoxSelected(egitimDizi.substring(i-1, i)));
					}
				}
				String yasDizi = rSet.getString("YAS_DIZI");
				if(yasDizi == null)
				{
					for (Integer i = 1; i <= 5; i++) {
						oMap.put(tableName, row, "YAS" + i.toString(), false);
					}
				}
				else
				{
					for (Integer i = 1; i <= yasDizi.length(); i++) {
						oMap.put(tableName, row, "YAS" + i.toString(), GuimlUtil.convertBinaryToCheckBoxSelected(yasDizi.substring(i-1, i)));
					}
				}
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3127_GET_EGITIM_KOD")
	public static GMMap getEgitimKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer();
			query.append("SELECT ");
			query.append("KOD, ACIKLAMA ");
			query.append("FROM ");
			query.append("V_ML_GNL_EGITIM_KOD_PR ");
			query.append("ORDER BY SIRA_NO ");

			stmt = conn.prepareStatement(query.toString());

			rSet = stmt.executeQuery();
			String tableName = "EGITIM_TABLE";
			
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "EGITIMLER", rSet.getString(2));
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3127_GET_YAS_KOD")
	public static GMMap getYasKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			StringBuffer query = new StringBuffer();
			query.append("SELECT ");
			query.append("TEXT ");
			query.append("FROM ");
			query.append("V_ML_GNL_PARAM_TEXT ");
			query.append("WHERE KOD = 'YAS_ARALIGI' ");
			query.append("ORDER BY SIRA_NO ");

			stmt = conn.prepareStatement(query.toString());

			rSet = stmt.executeQuery();
			String tableName = "YAS_TABLE";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "YASLAR", rSet.getString(1));
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
