package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3224Services {
	
	@GraymoundService("BNSPR_QRY3224_SORGULA")
	public static GMMap sorgula(GMMap iMap){
      Connection conn=null;
      CallableStatement stmt=null;
      CallableStatement stmt1=null;
      ResultSet rSet=null;
      ResultSet rSet1=null;
      int row=0;
	  GMMap oMap = new GMMap();  
	  
		try{
			
		    conn = DALUtil.getGMConnection();	
		    stmt = conn.prepareCall("{call PKG_RC3224.sorgula(?,?,?,?,?)}");
            stmt.setBigDecimal(1,iMap.getBigDecimal("BAYI_KOD"));
            stmt.setBigDecimal(2,iMap.getBigDecimal("KAMPANYA_KOD"));
            if(iMap.getDate("BASLANGIC_TAR") != null)
				stmt.setDate(3, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else 
				stmt.setDate(3, null);
			if(iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(4,  new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else 
				stmt.setDate(4, null);			
			stmt.registerOutParameter(5,-10);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(5);
	        String tableName="BAYI_PERFORMANS_BILGILERI";
	        
			while (rSet.next()) {
			  oMap.put(tableName, row, "BAYI_KOD", rSet.getBigDecimal("BAYI_KOD"));		
			  oMap.put(tableName, row, "BAYI_ADI", rSet.getString("BAYI_ADI"));		
			  oMap.put(tableName, row, "BASVURU_ADEDI", rSet.getBigDecimal("BASVURU_ADEDI"));			 
			  oMap.put(tableName, row, "BASVURU_TUTARI", rSet.getBigDecimal("BASVURU_TUTARI"));	
			  oMap.put(tableName, row, "KULLANDIRIM_ADEDI", rSet.getBigDecimal("KULLANDIRIM_ADEDI"));	
			  oMap.put(tableName, row, "KULLANDIRIM_TUTARI", rSet.getBigDecimal("KULLANDIRIM_TUTARI"));	
			  oMap.put(tableName, row, "ONAYLANMIS_EVRAK_BEKLEYEN_BASVURU_ADEDI", rSet.getBigDecimal("EVRAKSIZ_BASVURU_ADEDI"));	
			  oMap.put(tableName, row, "ONAYLANMIS_EVRAK_BEKLEYEN_BASVURU_TUTARI", rSet.getBigDecimal("EVRAKSIZ_BASVURU_TUTARI"));	
			  oMap.put(tableName, row, "IPTAL_EDILEN_KREDI_SAYISI", rSet.getBigDecimal("IPTAL_EDILEN_KREDI_SAYISI"));	
			  oMap.put(tableName, row, "SATICILAR_ICI_SIRALAMA", rSet.getBigDecimal("SUBE_SIRALAMA"));	
			  oMap.put(tableName, row, "MERKEZLER_ICI_SIRALAMA", rSet.getBigDecimal("MERKEZ_SIRALAMA"));	
			  oMap.put(tableName, row, "AYNI_MERKEZ_SUBE_ICI_SIRALAMA", rSet.getBigDecimal("AYNI_MERKEZ_SIRALAMA"));	
			  oMap.put(tableName, row, "DAGITICILAR_ICI_SIRALAMA", rSet.getBigDecimal("TUM_DAGITICI_SIRALAMA"));	
			  
			  if (rSet.getString("SATICI_TIP_KOD").compareTo("M")==0){
				  
              stmt1=conn.prepareCall("{?=call PKG_RC3224.ayni_dagitici_merkez_siralama(?,?,?,?)}");
              stmt1.registerOutParameter(1,-10);
              stmt1.setBigDecimal(2,rSet.getBigDecimal("BAYI_KOD"));
              stmt1.setBigDecimal(3,iMap.getBigDecimal("KAMPANYA_KOD"));
              
              if(iMap.getDate("BASLANGIC_TAR") != null)
  				stmt1.setDate(4, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
  			else 
  				stmt1.setDate(4, null);
  			if(iMap.getDate("BITIS_TAR") != null)
  				stmt1.setDate(5,  new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
  			else 
  				stmt1.setDate(5, null);	
  			
  			stmt1.execute();
  			rSet1 = (ResultSet)stmt1.getObject(1);
  			
  			while (rSet1.next()) {
			  oMap.put(tableName, row, "BIRINCI_DAGITICI", rSet1.getBigDecimal("BIRINCI_DAGITICI_SIRA"));
			  oMap.put(tableName, row, "BIRINCI_DAGITICI_ADI", rSet1.getString("BIRINCI_DAGITICI_AD"));
			  oMap.put(tableName, row, "IKINCI_DAGITICI", rSet1.getBigDecimal("IKINCI_DAGITICI_SIRA"));
			  oMap.put(tableName, row, "IKINCI_DAGITICI_ADI", rSet1.getString("IKINCI_DAGITICI_AD"));
			  
  			}
  			
			GMServerDatasource.close(rSet1);
			  }
			  
			row++;
			}
			
			GMServerDatasource.close(rSet);


			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt1);
			GMServerDatasource.close(conn);
		}
	}
}