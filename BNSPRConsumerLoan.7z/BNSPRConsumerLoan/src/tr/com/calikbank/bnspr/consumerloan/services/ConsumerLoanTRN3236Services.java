package tr.com.calikbank.bnspr.consumerloan.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBayiTutariadeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3236Services {
	

	@GraymoundService("BNSPR_TRN3236_SAVE")
	public static Map<?, ?> save(GMMap iMap){

		try{
			Session session = DAOSession.getSession("BNSPRDal"); 
			
			BirBayiTutariadeTx tx = new BirBayiTutariadeTx();
			tx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			tx.setIadeTarih(iMap.getDate("IADE_TARIH"));
			tx.setIadeTutar(iMap.getBigDecimal("IADE_TUTAR"));
			tx.setGecikmeFaizToplamTutar(iMap.getBigDecimal("GECIKME_FAIZ_TOPLAM_TUTAR"));
			tx.setVergiFonOdendimi(iMap.getBoolean("VERGI_FON_ODENDIMI")?"E":"H");
			tx.setGecenGunFaiz(iMap.getBigDecimal("GECEN_GUN_FAIZ"));
			tx.setGecenGunFaizKkdf(iMap.getBigDecimal("GECEN_GUN_FAIZ_KKDF"));
			tx.setGecenGunFaizBsmv(iMap.getBigDecimal("GECEN_GUN_FAIZ_BSMV"));
			tx.setKatkiPayiIadeTutar(iMap.getBigDecimal("KATKI_PAYI_IADE_TUTAR"));
			tx.setDosyaMasrafIadeTutar(iMap.getBigDecimal("DOSYA_MASRAF_IADE_TUTAR"));
			tx.setGecikmeFaizToplamKkdf(iMap.getBigDecimal("GECIKME_FAIZ_TOPLAM_KKDF"));
			tx.setGecikmeFaizToplamBsmv(iMap.getBigDecimal("GECIKME_FAIZ_TOPLAM_BSMV"));
			tx.setToplamIadeTutar(iMap.getBigDecimal("TOPLAM_IADE_TUTAR"));
			tx.setBayidenAlinacakNetTutar(iMap.getBigDecimal("BAYIDEN_ALINACAK_NET_TUTAR"));
			tx.setBayiHesapNo(iMap.getBigDecimal("BAYI_HESAP_NO"));
			tx.setMusteriHesapNo(iMap.getBigDecimal("MUSTERI_HESAP_NO"));
			tx.setKatkiPayiBsmv(iMap.getBigDecimal("KATKI_PAYI_BSMV"));
			tx.setKatkiPayiKkdf(iMap.getBigDecimal("KATKI_PAYI_KKDF"));
			tx.setKrediHesapNo(iMap.getBigDecimal("KREDI_HESAP_NO"));
			tx.setKatkiPayi(iMap.getBigDecimal("KATKI_PAYI"));
			
			session.save(tx);
		    session.flush();  
			
			iMap.put("TRX_NAME", "3236");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3236_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(BirBayiTutariadeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();	 
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			 
				BirBayiTutariadeTx tx = (BirBayiTutariadeTx) iterator.next();
				oMap.put("BASVURU_NO", tx.getBasvuruNo());
				oMap.put("IADE_TARIH", tx.getIadeTarih());
				oMap.put("IADE_TUTAR", tx.getIadeTutar());
				oMap.put("GECIKME_FAIZ_TOPLAM_TUTAR", tx.getGecikmeFaizToplamTutar());
				oMap.put("VERGI_FON_ODENDIMI", tx.getVergiFonOdendimi().equals("E"));
				oMap.put("GECEN_GUN_FAIZ", tx.getGecenGunFaiz());
				oMap.put("GECEN_GUN_FAIZ_KKDF", tx.getGecenGunFaizKkdf());
				oMap.put("GECEN_GUN_FAIZ_BSMV", tx.getGecenGunFaizBsmv());
				oMap.put("KATKI_PAYI_IADE_TUTAR", tx.getKatkiPayiIadeTutar());
				oMap.put("DOSYA_MASRAF_IADE_TUTAR", tx.getDosyaMasrafIadeTutar());
				oMap.put("GECIKME_FAIZ_TOPLAM_KKDF", tx.getGecikmeFaizToplamKkdf());
				oMap.put("GECIKME_FAIZ_TOPLAM_BSMV", tx.getGecikmeFaizToplamBsmv());
				oMap.put("TOPLAM_IADE_TUTAR", tx.getToplamIadeTutar());
				oMap.put("BAYIDEN_ALINACAK_NET_TUTAR", tx.getBayidenAlinacakNetTutar());
				
				ArrayList<Object> inputList = new ArrayList<Object>();
	            inputList.add(tx.getBasvuruNo());
	            
	            HashMap<?, ?> lovMap = LovHelper.diLovAll(tx.getBasvuruNo() , "3236Q/LOV_BASVURU_NO" , inputList);
	            oMap.put("KREDI_TUTARI", lovMap.get("KRD_TUTAR"));
	            oMap.put("KULLANDIRIM_TARIHI", lovMap.get("KULLANDIRIM_TAR"));
	            oMap.put("KKDF_ORANI", lovMap.get("KKDF_ORAN"));
	            oMap.put("BSMV_ORANI", lovMap.get("BSMV_ORAN"));
	            oMap.put("BAZ_FAIZ_ORANI", lovMap.get("FAIZ_ORANI"));
	            oMap.put("INDIRIMLI_FAIZ_ORANI", lovMap.get("INDIRIMLI_FAIZ_ORANI"));
	            oMap.put("KATKI_PAYI_ORANI", lovMap.get("KATKI_PAYI_ORAN"));
	            oMap.put("KATKI_PAYI_TUTARI", lovMap.get("KATKI_PAYI"));
	            oMap.put("KATKI_PAYI_KKDF_TUTARI", lovMap.get("KATKI_PAYI_KKDF"));
	            oMap.put("KATKI_PAYI_BSMV_TUTARI", lovMap.get("KATKI_PAYI_BSMV"));
	            oMap.put("NET_KATKI_PAYI_TUTARI", lovMap.get("KATKI_PAYI_NET"));
	            oMap.put("DOSYA_MASRAF_TUTARI", lovMap.get("DOSYA_MASRAFI"));
	            oMap.put("DOSYA_MASRAF_BSMV_TUTARI", lovMap.get("DOSYA_MASRAFI_BSMV"));
	            oMap.put("NET_DOSYA_MASRAF_TUTARI", lovMap.get("DOSYA_MASRAFI_NET"));
	            
			}
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
}
