package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipAdrTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipAdrTxId;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTelTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTelTxId;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTxId;
import tr.com.aktifbank.bnspr.dao.KkbVefatRisk;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriKimlik;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3195Services {
	private static final Logger logger = Logger.getLogger(ConsumerLoanTRN3195Services.class);

	@GraymoundService("BNSPR_TRN3195_GET_COMBOBOX_INITIAL_VALUE")
	public static GMMap getComboBoxInitialValues(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "KANAL", true, "select b.kanal_kodu, " + "pkg_genel_pr.kanal_adi(b.kanal_kodu) kanal_adi from bir_basvuru b group by b.kanal_kodu order by 1");

			DALUtil.fillComboBox(oMap, "TELEFON_TIPLERI", true, "select key1, " + "text from v_ml_gnl_param_text v where v.KOD='TELEFON_TIPLERI'  order by key1");

			DALUtil.fillComboBox(oMap, "ADRES_TIPLERI", true, "SELECT a.adres_kod ADRES_TIPI, a.aciklama ACIKLAMA " + "FROM v_ml_gnl_adres_grup_pr a " + "where a.musteri_tur_kod='G' " + "and a.adres_kod in('E','I','Y') " + "ORDER BY a.adres_kod");

			DALUtil.fillComboBox(oMap, "MUSTERI_GRUBU", true, "select kod, aciklama from V_ML_GNL_MUSTERI_GRUP_KOD_PR v order by kod");

			oMap.putAll(GMServiceExecuter.call("BNSPR_QRY3196_GET_SATICI_KOD", iMap));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_KREDI_TURLERI", iMap));

			iMap.put("KOD", "KREDI_HESAP_DURUM");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("HESAP_DURUM_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			iMap.put("KOD", "KRD_HESAP_TAKIP_SON_GORUSME");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("SON_GORUSME_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "YASAL_TAKIP_HESAP_SECIM");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("HESAP_SECIM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "3195_FRAUD_PAR");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("FRAUD_PAR_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3195_GET_KREDI_BILGILERI")
	public static GMMap getKrediBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetKredi = null;
		ResultSet rSetGorus = null;
		ResultSet rSetTel = null;
		ResultSet rSetAdr = null;
		ResultSet rSetArama = null;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3196.get_kredi_bilgileri(?,?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_HESAP_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSetKredi = (ResultSet) stmt.getObject(2);
			rSetGorus = (ResultSet) stmt.getObject(3);
			rSetTel = (ResultSet) stmt.getObject(4);
			rSetAdr = (ResultSet) stmt.getObject(5);
			rSetArama = (ResultSet) stmt.getObject(6);

			while (rSetGorus.next()) {
				GuimlUtil.wrapMyCombo(oMap, "TAHSIS_GORUS_LIST", null, rSetGorus.getString(1));
			}

			oMap.putAll(DALUtil.rSetMap(rSetKredi));
			oMap.put("TAHSILAT_YAPILAMAZ", oMap.getString("TAHSILAT_YAPILAMAZ") == null ? false : (oMap.getString("TAHSILAT_YAPILAMAZ").equalsIgnoreCase("E") ? true : false));
			oMap.put("BAYIDEN_KAPATILACAK", oMap.getString("BAYIDEN_KAPATILACAK") == null ? false : (oMap.getString("BAYIDEN_KAPATILACAK").equalsIgnoreCase("E") ? true : false));
			List<?> list = session.createCriteria(KkbVefatRisk.class).add(Restrictions.eq("id.tckn", oMap.getString("TCKN"))).list();
			if (list.size() > 0) {
				oMap.put("KKB_VEFAT", true);
			}
			else {
				oMap.put("KKB_VEFAT", false);
			}

			if ("Y".equals(oMap.getString("FRAUD_NEDEN_KOD")) || "".equals(oMap.getString("FRAUD_NEDEN_KOD")))
				oMap.put("FRAUD_VAR_MI", false);
			else
				oMap.put("FRAUD_VAR_MI", true);

			oMap.putAll(DALUtil.rSetResults(rSetTel, "TEL_LIST"));
			for (int k = 0; k < oMap.getSize("TEL_LIST"); k++) {
				oMap.put("TEL_LIST", k, "T_SIRA_NO", "T" + oMap.getString("TEL_LIST", k, "SIRA_NO"));
				oMap.put("TEL_LIST", k, "KENDINE_MI_AIT", "E".equals(oMap.getString("TEL_LIST", k, "KENDINE_MI_AIT")));
			}
			oMap.put("TEL_COUNT", oMap.getSize("TEL_LIST"));

			oMap.putAll(DALUtil.rSetResults(rSetAdr, "ADR_LIST"));
			for (int k = 0; k < oMap.getSize("ADR_LIST"); k++) {
				oMap.put("ADR_LIST", k, "A_SIRA_NO", "A" + oMap.getString("ADR_LIST", k, "SIRA_NO"));
			}
			oMap.put("ADR_COUNT", oMap.getSize("ADR_LIST"));

			oMap.putAll(DALUtil.rSetResults(rSetArama, "ARAMA_LIST"));
			oMap.put("FPD", oMap.getString("FPD") == null ? false : (oMap.getString("FPD").equalsIgnoreCase("E") ? true : false));
			oMap.put("ILK_KEZ_GECIKME_MI", oMap.getString("ILK_KEZ_GECIKME_MI") == null ? false : (oMap.getString("ILK_KEZ_GECIKME_MI").equalsIgnoreCase("E") ? true : false));

			/* Son G�ncelleme Gerek�esi */
			stmt = conn.prepareCall("{? = call PKG_TRN3199.Son_Guncelleme_Gerekcesi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			oMap.put("SON_ISLEM_GEREKCE", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSetKredi);
			GMServerDatasource.close(rSetGorus);
			GMServerDatasource.close(rSetTel);
			GMServerDatasource.close(rSetAdr);
			GMServerDatasource.close(rSetArama);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3195_GET_KREDI_LIST")
	public static GMMap getKrediList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3195.get_kredi_list(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_BAKIYE").doubleValue() > 0 ? iMap.getBigDecimal("MIN_BAKIYE") : null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_BAKIYE").doubleValue() > 0 ? iMap.getBigDecimal("MAX_BAKIYE") : null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VADESIZ_HESAP_NO"));
			stmt.setString(i++, iMap.getString("MUSTERI_GRUBU"));
			stmt.setString(i++, iMap.getString("HESAP_DURUMU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_GECIKME_TUTARI").doubleValue() > 0 ? iMap.getBigDecimal("MIN_GECIKME_TUTARI") : null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_GECIKME_TUTARI").doubleValue() > 0 ? iMap.getBigDecimal("MAX_GECIKME_TUTARI") : null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_GECIKME_GUN_SAY"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_GECIKME_GUN_SAY"));
			if (iMap.getDate("BAS_GECIKME_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_GECIKME_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			if (iMap.getDate("SON_GECIKME_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("SON_GECIKME_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getString("KANAL"));

			stmt.setString(i++, iMap.getBoolean("MAAS_PROBLEMI") ? "E" : "H");
			stmt.setString(i++, iMap.getBoolean("VEFAT_DURUMU") ? "E" : "H");
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("TCKN"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "KREDI_LIST");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3195_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetKredi = null;
		ResultSet rSetGorus = null;
		ResultSet rSetArama = null;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3195.get_info(?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSetKredi = (ResultSet) stmt.getObject(2);
			rSetGorus = (ResultSet) stmt.getObject(3);
			rSetArama = (ResultSet) stmt.getObject(4);

			while (rSetGorus.next()) {
				GuimlUtil.wrapMyCombo(oMap, "TAHSIS_GORUS_LIST", null, rSetGorus.getString(1));
			}

			oMap.putAll(DALUtil.rSetMap(rSetKredi));
			oMap.put("TAHSILAT_YAPILAMAZ", oMap.getString("TAHSILAT_YAPILAMAZ") == null ? false : (oMap.getString("TAHSILAT_YAPILAMAZ").equalsIgnoreCase("E") ? true : false));
			oMap.put("BAYIDEN_KAPATILACAK", oMap.getString("BAYIDEN_KAPATILACAK") == null ? false : (oMap.getString("BAYIDEN_KAPATILACAK").equalsIgnoreCase("E") ? true : false));
			List<?> list = session.createCriteria(KkbVefatRisk.class).add(Restrictions.eq("id.tckn", oMap.getString("TCKN"))).list();
			if (list.size() > 0) {
				oMap.put("KKB_VEFAT", true);
			}
			else {
				oMap.put("KKB_VEFAT", false);
			}

			if ("Y".equals(oMap.getString("FRAUD_NEDEN_KOD")) || "".equals(oMap.getString("FRAUD_NEDEN_KOD")))
				oMap.put("FRAUD_VAR_MI", false);
			else
				oMap.put("FRAUD_VAR_MI", true);

			oMap.putAll(DALUtil.rSetResults(rSetArama, "ARAMA_LIST"));
			oMap.put("FPD", oMap.getString("FPD") == null ? false : (oMap.getString("FPD").equalsIgnoreCase("E") ? true : false));
			oMap.put("ILK_KEZ_GECIKME_MI", oMap.getString("ILK_KEZ_GECIKME_MI") == null ? false : (oMap.getString("ILK_KEZ_GECIKME_MI").equalsIgnoreCase("E") ? true : false));

			stmt = null;
			conn = null;
			conn = DALUtil.getGMConnection();

			/* Son G�ncelleme Gerek�esi */
			stmt = conn.prepareCall("{? = call PKG_TRN3199.Son_Guncelleme_Gerekcesi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, oMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			oMap.put("SON_ISLEM_GEREKCE", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSetKredi);
			GMServerDatasource.close(rSetGorus);
			GMServerDatasource.close(rSetArama);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3195_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirKrediHesapTakipTx birKrediHesapTakipTx = new BirKrediHesapTakipTx();
			BirKrediHesapTakipTxId id = new BirKrediHesapTakipTxId();

			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setKrdHesapNo(iMap.getBigDecimal("KRD_HESAP_NO"));
			birKrediHesapTakipTx.setId(id);

			birKrediHesapTakipTx.setAciklama(iMap.getString("ACIKLAMA"));
			birKrediHesapTakipTx.setHesapDurumKodu(iMap.getString("HESAP_DURUMU"));
			birKrediHesapTakipTx.setIhtarnameTarihi(iMap.getDate("IHTARNAME_TARIHI"));
			birKrediHesapTakipTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESAP_NO"));
			birKrediHesapTakipTx.setOncekiHesapDurum(iMap.getString("ONCEKI_HESAP_DURUM"));
			birKrediHesapTakipTx.setTakipHesapNo(iMap.getBigDecimal("TAKIP_HESAP_NO"));
			birKrediHesapTakipTx.setVefatTarihi(iMap.getDate("VEFAT_TARIHI"));
			birKrediHesapTakipTx.setHesapKapatilsinMi(iMap.getString("HESAP_KAPATILSIN_MI") != null ? "E" : "H");
			birKrediHesapTakipTx.setSonGorusmeDurum(iMap.getString("SON_GORUSME_DURUM"));
			birKrediHesapTakipTx.setMektup1Tarih(iMap.getDate("MEKTUP_1_TARIH"));
			birKrediHesapTakipTx.setMektup1GeriTarih(iMap.getDate("MEKTUP_1_GERI_TARIH"));
			birKrediHesapTakipTx.setMektup2Tarih(iMap.getDate("MEKTUP_2_TARIH"));
			birKrediHesapTakipTx.setTahsilatYapilamaz(iMap.getBoolean("TAHSILAT_YAPILAMAZ") ? "E" : "H");
			birKrediHesapTakipTx.setMektup2GeriTarih(iMap.getDate("MEKTUP_2_GERI_TARIH"));
			birKrediHesapTakipTx.setMaasProblemi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("MAAS_PROBLEMI")));
			birKrediHesapTakipTx.setFirmaAramasi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("FIRMA_ARAMASI")));
			birKrediHesapTakipTx.setTakipTahsilTutari(iMap.getBigDecimal("TAKIP_TAHSIL_TUTAR"));
			birKrediHesapTakipTx.setBayidenKapatilacak(iMap.getBoolean("BAYIDEN_KAPATILACAK") ? "E" : "H");

			if ("E".equals(iMap.getString("HESAP_KAPATILSIN_MI"))) {
				GMMap nMap = new GMMap();
				nMap.put("HESAP_NO", iMap.getBigDecimal("KRD_HESAP_NO"));
				GMMap mMap = new GMMap();
				mMap.putAll(GMServiceExecuter.execute("BNSPR_GET_DEFTER_BAKIYESI", nMap));
				birKrediHesapTakipTx.setKapamaBakiyesi(mMap.getBigDecimal("DEFTER_BAKIYE").abs());
			}

			if (iMap.getBoolean("FRAUD_VAR_MI"))
				birKrediHesapTakipTx.setFraudNedenKod(iMap.getString("FRAUD_NEDEN_KOD"));
			else
				birKrediHesapTakipTx.setFraudNedenKod("Y");

			birKrediHesapTakipTx.setHesapSecim(iMap.getString("HESAP_SECIM"));
			birKrediHesapTakipTx.setYenidenYapilandirma(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("YENIDEN_YAPILANDIRMA_2")));

			session.saveOrUpdate(birKrediHesapTakipTx);

			session.flush();

			for (int i = 0; i < iMap.getSize("TEL_LIST"); i++) {
				if ("".equals(iMap.getString("TEL_LIST", i, "YAKIN_ACIKLAMA"))) {
					String nuLL = null;
					iMap.put("TEL_LIST", i, "YAKIN_ACIKLAMA", nuLL);
				}
				if (iMap.getBoolean("TEL_LIST", i, "KENDINE_MI_AIT")) {
					if (iMap.getString("TEL_LIST", i, "YAKIN_ACIKLAMA") != null) {
						GMMap sMap = new GMMap();
						sMap.put("HATA_NO", "2068");
						sMap.put("P1", "Kendisine ait");
						sMap.put("P2", "kime ait");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
					}
				}
			}

			List<BirKrediHesapTakipTelTx> birKrediHesapTakipTelTxList = (List<BirKrediHesapTakipTelTx>) session.createCriteria(BirKrediHesapTakipTelTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			if (birKrediHesapTakipTelTxList != null && birKrediHesapTakipTelTxList.size() > 0) {
				for (int i = 0; i < birKrediHesapTakipTelTxList.size(); i++) {
					session.delete(birKrediHesapTakipTelTxList.get(i));
				}
				session.flush();
			}

			for (int k = 0; k < iMap.getSize("TEL_LIST"); k++) {
				BirKrediHesapTakipTelTxId birKrediHesapTakipTelIdTx = new BirKrediHesapTakipTelTxId();
				BirKrediHesapTakipTelTx birKrediHesapTakipTelTx = new BirKrediHesapTakipTelTx();
				birKrediHesapTakipTelIdTx.setSiraNo(iMap.getBigDecimal("TEL_LIST", k, "SIRA_NO"));
				birKrediHesapTakipTelIdTx.setKrdHesapNo(iMap.getBigDecimal("TEL_LIST", k, "KRD_HESAP_NO"));
				birKrediHesapTakipTelIdTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birKrediHesapTakipTelTx.setId(birKrediHesapTakipTelIdTx);
				birKrediHesapTakipTelTx.setKendineMiAit(iMap.getBoolean("TEL_LIST", k, "KENDINE_MI_AIT") ? "E" : "H");
				birKrediHesapTakipTelTx.setSil("H");
				birKrediHesapTakipTelTx.setTelAlanKod(iMap.getString("TEL_LIST", k, "TEL_ALAN_KOD"));
				birKrediHesapTakipTelTx.setTelNo(iMap.getString("TEL_LIST", k, "TEL_NO"));
				birKrediHesapTakipTelTx.setTelTip(iMap.getString("TEL_LIST", k, "TEL_TIP"));
				birKrediHesapTakipTelTx.setYakinAciklama(iMap.getString("TEL_LIST", k, "YAKIN_ACIKLAMA"));
				session.saveOrUpdate(birKrediHesapTakipTelTx);
				k++;
			}

			session.flush();

			List<BirKrediHesapTakipAdrTx> birKrediHesapTakipAdrTxList = (List<BirKrediHesapTakipAdrTx>) session.createCriteria(BirKrediHesapTakipAdrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			if (birKrediHesapTakipAdrTxList != null && birKrediHesapTakipAdrTxList.size() > 0) {
				for (int i = 0; i < birKrediHesapTakipAdrTxList.size(); i++) {
					session.delete(birKrediHesapTakipAdrTxList.get(i));
				}
				session.flush();
			}

			for (int k = 0; k < iMap.getSize("ADR_LIST"); k++) {
				BirKrediHesapTakipAdrTxId birKrediHesapTakipAdrIdTx = new BirKrediHesapTakipAdrTxId();
				BirKrediHesapTakipAdrTx birKrediHesapTakipAdrTx = new BirKrediHesapTakipAdrTx();
				birKrediHesapTakipAdrIdTx.setSiraNo(iMap.getBigDecimal("ADR_LIST", k, "SIRA_NO"));
				birKrediHesapTakipAdrIdTx.setKrdHesapNo(iMap.getBigDecimal("ADR_LIST", k, "KRD_HESAP_NO"));
				birKrediHesapTakipAdrIdTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birKrediHesapTakipAdrTx.setId(birKrediHesapTakipAdrIdTx);
				birKrediHesapTakipAdrTx.setAdresKod(iMap.getString("ADR_LIST", k, "ADRES_KOD"));
				birKrediHesapTakipAdrTx.setAdres(iMap.getString("ADR_LIST", k, "ADRES"));
				birKrediHesapTakipAdrTx.setSil("H");
				session.saveOrUpdate(birKrediHesapTakipAdrTx);

			}

			session.flush();

			iMap.put("TRX_NAME", "3195");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3195_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = yasalTakipBlokeKaldir(iMap);

		for (int i = 0; i < oMap.getSize("ISLEM"); i++) {

			GMMap blokeMap = new GMMap();
			blokeMap.put("ISLEM_KODU", new java.math.BigDecimal("4131"));
			blokeMap.put("ISLEM_NO", oMap.getBigDecimal("ISLEM", i, "ISLEM_NO"));
			GMServiceExecuter.call("BNSPR_TRN4131_AFTER_APPROVAL", blokeMap);

		}

		return oMap;
	}

	private static GMMap yasalTakipBlokeKaldir(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3195.yasal_takip_bloke_kaldir(?)}");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "ISLEM");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3195_ONCEKI_BASVURULAR")
	public static GMMap oncekiBasvurular(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			/** TY-6901 TY-Bireysel krediler Servis �al��malar�_Kredi ve ba�vuruya ait bilgiler i�in servis */
			if ("8034".equals(iMap.getString("EKRAN_NO"))) {
				if (iMap.getString("TCKN").length() == 0 && iMap.getString("MUSTERI_NO").length() == 0) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Musteri No yada TC Kimlik No zorunludur.");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3195.trn3195_onceki_basvurular(?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);

			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("TCKN"));
			stmt.setString(4, iMap.getString("MUSTERI_NO"));
			/** TY-6901 TY-Bireysel krediler Servis �al��malar�_Kredi ve ba�vuruya ait bilgiler i�in servis */
			stmt.setString(5, iMap.getString("HESAP_DURUMU"));
			/** TY-6901 TY-Bireysel krediler Servis �al��malar�_Kredi ve ba�vuruya ait bilgiler i�in servis */
			stmt.setString(6, iMap.getString("EKRAN_NO"));
			/** TY-6901 TY-Bireysel krediler Servis �al��malar�_Kredi ve ba�vuruya ait bilgiler i�in servis */

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "BASVURULAR"));

			/** TY-6901 TY-Bireysel krediler Servis �al��malar�_Kredi ve ba�vuruya ait bilgiler i�in servis */
			if ("8034".equals(iMap.getString("EKRAN_NO"))) {

				GMMap s3Map = new GMMap();
				Calendar c = Calendar.getInstance();
				/** PY-11226 **/
				s3Map.put("BANKA_TARIH", c.getTime());

				for (int i = 0; i < oMap.getSize("BASVURULAR"); i++) {
					GMMap tMap = new GMMap();
					tMap.put("BASVURU_NO", oMap.get("BASVURULAR", i, "BASVURU_NO"));
					GMMap taksitMap = GMServiceExecuter.call("BNSPR_GET_TAKSIT_BILGILER", tMap);
					oMap.put("BASVURULAR", i, "TAKSIT_TUTARI", taksitMap.get("TAKSIT_TUTAR"));

					GMMap inputDates = new GMMap();
					inputDates.put("FIRST_DATE", taksitMap.getDate("TAKSIT_VADE"));
					inputDates.put("SECOND_DATE", s3Map.getDate("BANKA_TARIH"));
					GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
					if (dayMap.getBigDecimal("DAYS") != null && dayMap.getBigDecimal("DAYS").signum() != -1) {
						oMap.put("BASVURULAR", i, "GECIKME_GUN_SAYISI", dayMap.getBigDecimal("DAYS"));
					} else {
						oMap.put("BASVURULAR", i, "GECIKME_GUN_SAYISI", BigDecimal.ZERO);
					}
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3195_MUSTERI_GRUP_LIST")
	public static GMMap musteriGruplari(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3195.TRN3195_MUSTERI_GRUP_LIST(?)}");
			stmt.registerOutParameter(1, -10);

			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "TBL_MUSTERI_GRUP");

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * Verilen musteri numarasina ait vefat kapama tutarini;
	 * belirtilen valor tarihine gore basvuru bazinda bilgileri listeler<br>
	 * 
	 * @author murat.el
	 * @since TY-3828
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>MUSTERI_NO - Musteri numarasi <li>VALOR_TARIHI - Kapama tutarinin hesaplanacagi valor tarihi
	 * @return oMap - Islem sonucu<br>
	 *         RESULT - Istenilen bilgileri iceren basvuru listesi<br>
	 *         <li>BASVURU_NO - Bireysel kredi basvuru numarasi <li>STATU - Basuvurunun durumu (A:Ac�k|K:Kapali|Y:Yasal Takip) <li>HESAP_NO - Tahsilat hesabi IBAN bilgisi <li>FINANSOR - Urun finansor tipi (VDMK|CREDIT_SUISSE|AKTIFBANK) <li>PTT_IADE_TUTARI - Musteri vefat tarihi sonrasi tahsil edilen toplam tutar <li>KAPAMA_BAKIYESI - Tahsilat tutari <li>TOPLAM_TUTAR - Ptt iade tutari ve kapama
	 *         bakiyesinin toplam tutari
	 */
	@GraymoundService("BNSPR_TRN3195_VEFAT_KAPAMA_TUTARI_HESAPLA")
	public static GMMap vefatKapamaTutariHesapla(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");

		try {
			// Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			// Musteri no gecerli mi?
			if (StringUtils.isBlank(iMap.getString("MUSTERI_NO"))) {
				ConsumerLoanCommonServices.raiseGMError("330", "Musteri No");
			}
			// Musteri var mi?
			GnlMusteriKimlik gnlMusteriKimlik = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, musteriNo);
			if (gnlMusteriKimlik == null) {
				ConsumerLoanCommonServices.raiseGMError("4232");
			}
			// Vefat tarihi var mi?
			if (gnlMusteriKimlik.getOlumTarihi() == null) {
				ConsumerLoanCommonServices.raiseGMError("5045");
			}
			// Musteriye ait kayitlari listele
			GMMap sorguMap = new GMMap();
			sorguMap.put("MUSTERI_NO", musteriNo);
			sorguMap.put("VALOR_TARIHI", iMap.get("VALOR_TARIHI"));
			sorguMap.putAll(getVefatKapamaBasvuruList(sorguMap));
			// Kontrol
			if (sorguMap.get(Constants.RESULT) == null || sorguMap.getSize(Constants.RESULT) < 1) {
				ConsumerLoanCommonServices.raiseGMError("1614");
			}
			// Listedeki kayitlari isle
			GMMap bakiyeMap = new GMMap();
			for (int i = 0; i < sorguMap.getSize(Constants.RESULT); i++) {
				// Kapama bakiyesi al
				bakiyeMap.clear();
				bakiyeMap.put("BASVURU_NO", sorguMap.get(Constants.RESULT, i, "BASVURU_NO"));
				bakiyeMap.put("MUSTERI_NO", sorguMap.get(Constants.RESULT, i, "MUSTERI_NO"));
				bakiyeMap.put("STATU", sorguMap.get(Constants.RESULT, i, "STATU"));
				bakiyeMap.put("VALOR_TARIHI", iMap.get("VALOR_TARIHI"));
				bakiyeMap.putAll(kapamaBakiyesiAl(bakiyeMap));
				// Degerleri al
				oMap.put(Constants.RESULT, i, "BASVURU_NO", sorguMap.get(Constants.RESULT, i, "BASVURU_NO"));
				oMap.put(Constants.RESULT, i, "STATU", sorguMap.get(Constants.RESULT, i, "STATU"));
				oMap.put(Constants.RESULT, i, "HESAP_NO", sorguMap.get(Constants.RESULT, i, "HESAP_NO"));
				oMap.put(Constants.RESULT, i, "FINANSOR", sorguMap.get(Constants.RESULT, i, "FINANSOR"));
				oMap.put(Constants.RESULT, i, "PTT_IADE_TUTARI", sorguMap.get(Constants.RESULT, i, "PTT_IADE_TUTARI"));
				oMap.put(Constants.RESULT, i, "KAPAMA_BAKIYESI", bakiyeMap.get("KAPAMA_BAKIYESI"));
				oMap.put(Constants.RESULT, i, "TOPLAM_TUTAR", sorguMap.getBigDecimal(Constants.RESULT, i, "PTT_IADE_TUTARI").add(bakiyeMap.getBigDecimal("KAPAMA_BAKIYESI")));
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Verilen musteri numarasina ait vefat kapama tutarini bulabilmek icin
	 * musterinin gecerli statudeki basvuru bilgilerini listeler<br>
	 * 
	 * @author murat.el
	 * @since TY-3828
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>MUSTERI_NO - Musteri numarasi <li>VALOR_TARIHI - Kapama tutarinin hesaplanacagi valor tarihi
	 * @return oMap - Islem sonucu<br>
	 *         RESULT - Istenilen bilgileri iceren basvuru listesi<br>
	 *         <li>BASVURU_NO - Bireysel kredi basvuru numarasi <li>STATU - Basuvurunun durumu (A:Ac�k|K:Kapali|Y:Yasal Takip) <li>HESAP_NO - Tahsilat hesabi IBAN bilgisi <li>FINANSOR - Urun finansor tipi (VDMK|CREDIT_SUISSE|AKTIFBANK) <li>PTT_IADE_TUTARI - Musteri vefat tarihi sonrasi tahsil edilen toplam tutar
	 */
	private static GMMap getVefatKapamaBasvuruList(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_TRN3195.get_vefat_kapama_basvuru_list(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			if (iMap.getDate("VALOR_TARIHI") != null) {
				stmt.setDate(3, new Date(iMap.getDate("VALOR_TARIHI").getTime()));
			}
			else {
				stmt.setDate(3, null);
			}
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, Constants.RESULT));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Verilen basvuru numarasina ait kapama bakiyesi tutarini statu/tarih bazli bulur.<br>
	 * 
	 * @author murat.el
	 * @since TY-3828
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>MUSTERI_NO - Musteri numarasi <li>BASVURU_NO - Bireysel kredi basvuru numarasi <li>VALOR_TARIHI - Kapama tutarinin hesaplanacagi valor tarihi <li>STATU - Basuvurunun durumu (A:Ac�k|K:Kapali|Y:Yasal Takip)
	 * @return oMap - Islem sonucu<br>
	 *         <li>KAPAMA_BAKIYESI - Tahsilat tutari
	 */
	private static GMMap kapamaBakiyesiAl(GMMap iMap) {
		GMMap oMap = new GMMap();
		String statu = iMap.getString("STATU");
		BigDecimal kapamaBakiyesi = null;

		try {
			// Statuye gore kapama bakiyesini al
			GMMap sorguMap = new GMMap();
			if (StringUtils.isBlank(statu)) {
				logger.info("Statu bilgisi alinamadi: NULL");
			}
			else if ("Y".equals(statu)) { // Statu yasal takip ise
				sorguMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_DCS_ANLIK_BAKIYE_AL", sorguMap));
				// Kontrol - kayit yoksa sifir olarak don.
				if (sorguMap.get(Constants.RESULT) == null || sorguMap.getSize(Constants.RESULT) < 1) {
					kapamaBakiyesi = BigDecimal.ZERO;
				}
				else {
					kapamaBakiyesi = sorguMap.getBigDecimal("SUM_TUMU").subtract(sorguMap.getBigDecimal("SUM_TAHSIL_EDILEN"));
				}
				if (kapamaBakiyesi != null)
					kapamaBakiyesi = kapamaBakiyesi.multiply(new BigDecimal(1.10));
			}
			else if(!"K".equals(statu)){
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("KAPAMA_YAPILMASI_ISTENEN_TARIH", iMap.get("VALOR_TARIHI"));
				sorguMap.put("ERKEN_KAPAMA_GEC_KISMI_DAHIL", Constants.EVET);
				sorguMap.put("EKRAN_NO", "3137");
				sorguMap.put("REZERVASYON_KURU", BigDecimal.ZERO);
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_GERI_ODEME_ERKEN_KAPAMA", sorguMap));
				if (StringUtils.isBlank(sorguMap.getString("TAHSILAT_TUTARI"))) {
					kapamaBakiyesi = BigDecimal.ZERO;
				}
				else {
					kapamaBakiyesi = sorguMap.getBigDecimal("TAHSILAT_TUTARI");
				}
			} else {
				kapamaBakiyesi = BigDecimal.ZERO;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KAPAMA_BAKIYESI", kapamaBakiyesi);
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3195_VEFAT_KAPAMA_TUTARI_TOPLAM_HESAPLA")
	public static GMMap vefatKapamaTutariToplamHesapla(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");

		try {
			// Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			// Musteri no gecerli mi?
			if (StringUtils.isBlank(iMap.getString("MUSTERI_NO"))) {
				ConsumerLoanCommonServices.raiseGMError("330", "Musteri No");
			}
			// Musteri var mi?
			GnlMusteriKimlik gnlMusteriKimlik = (GnlMusteriKimlik) session.get(GnlMusteriKimlik.class, musteriNo);
			if (gnlMusteriKimlik == null) {
				ConsumerLoanCommonServices.raiseGMError("4232");
			}
			// Vefat tarihi var mi?
			if (gnlMusteriKimlik.getOlumTarihi() == null) {
				ConsumerLoanCommonServices.raiseGMError("5045");
			}
			// Musteriye ait kayitlari listele
			GMMap sorguMap = new GMMap();
			sorguMap.put("MUSTERI_NO", musteriNo);
			sorguMap.put("VALOR_TARIHI", iMap.get("VALOR_TARIHI"));
			sorguMap.putAll(getVefatKapamaBasvuruList(sorguMap));
			// Kontrol
			if (sorguMap.get(Constants.RESULT) == null || sorguMap.getSize(Constants.RESULT) < 1) {
				ConsumerLoanCommonServices.raiseGMError("1614");
			}
			// Listedeki kayitlari isle
			GMMap bakiyeMap = new GMMap();
			for (int i = 0; i < sorguMap.getSize(Constants.RESULT); i++) {
				// Kapama bakiyesi al
				bakiyeMap.clear();
				bakiyeMap.put("BASVURU_NO", sorguMap.get(Constants.RESULT, i, "BASVURU_NO"));
				bakiyeMap.put("MUSTERI_NO", sorguMap.get(Constants.RESULT, i, "MUSTERI_NO"));
				bakiyeMap.put("STATU", sorguMap.get(Constants.RESULT, i, "STATU"));
				bakiyeMap.put("VALOR_TARIHI", iMap.get("VALOR_TARIHI"));
				bakiyeMap.putAll(kapamaBakiyesiAl(bakiyeMap));
				// Toplam bor� tutarlar
				GMMap imap = new GMMap();
				GMMap omap = new GMMap();
				imap.put("MUSTERI_NO", sorguMap.get(Constants.RESULT, i, "MUSTERI_NO"));
				imap.put("BASVURU_NO", sorguMap.get(Constants.RESULT, i, "BASVURU_NO"));
				omap = GMServiceExecuter.call("BNSPR_DCS_ANLIK_BAKIYE_AL", imap);
				BigDecimal sumTumu = null;
				if(omap.getBigDecimal("SUM_TUMU") == null){
					sumTumu = new BigDecimal(0);
				} else {
					sumTumu = omap.getBigDecimal("SUM_TUMU");
				}
				// Degerleri al
				oMap.put(Constants.RESULT, i, "BASVURU_NO", sorguMap.get(Constants.RESULT, i, "BASVURU_NO"));
				oMap.put(Constants.RESULT, i, "STATU", sorguMap.get(Constants.RESULT, i, "STATU"));
				oMap.put(Constants.RESULT, i, "HESAP_NO", sorguMap.get(Constants.RESULT, i, "HESAP_NO"));
				oMap.put(Constants.RESULT, i, "FINANSOR", sorguMap.get(Constants.RESULT, i, "FINANSOR"));
				oMap.put(Constants.RESULT, i, "PTT_IADE_TUTARI", sorguMap.get(Constants.RESULT, i, "PTT_IADE_TUTARI"));
				if(sumTumu.compareTo(BigDecimal.ZERO) > 0){
					oMap.put(Constants.RESULT, i, "KAPAMA_BAKIYESI", sumTumu.setScale(2, RoundingMode.HALF_UP));
					oMap.put(Constants.RESULT, i, "TOPLAM_TUTAR", sumTumu.add(sorguMap.getBigDecimal(Constants.RESULT, i, "PTT_IADE_TUTARI"))
							.setScale(2, RoundingMode.HALF_UP));
				} else {
					oMap.put(Constants.RESULT, i, "KAPAMA_BAKIYESI", bakiyeMap.getBigDecimal("KAPAMA_BAKIYESI"));
					oMap.put(Constants.RESULT, i, "TOPLAM_TUTAR", sorguMap.getBigDecimal(Constants.RESULT, i, "PTT_IADE_TUTARI")
							.add(bakiyeMap.getBigDecimal("KAPAMA_BAKIYESI")));
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	@GraymoundService("BNSPR_TRN3195_ONCEKI_BASVURULAR_CC_PTT")
	public static GMMap oncekiBasvurularCcPtt(GMMap iMap) {

		GMMap oMap=new GMMap();
		
 		iMap= GMServiceExecuter.call("BNSPR_TRN3195_ONCEKI_BASVURULAR" , iMap);
 		
 		int index=0;
 		
		for(int i=0;i<iMap.getSize("BASVURULAR");i++){
			
			  if("PTT".equals(iMap.getString("BASVURULAR", i, "KANAL"))){
		        						 
				 oMap.put("BASVURULAR", index++, iMap.getMap("BASVURULAR", i));	     
			  }
			  
		}
		return oMap;
	}
}
