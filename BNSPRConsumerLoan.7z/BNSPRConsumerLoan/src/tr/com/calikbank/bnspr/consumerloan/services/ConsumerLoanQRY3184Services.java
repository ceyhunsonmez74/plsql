package tr.com.calikbank.bnspr.consumerloan.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.dao.VBirFaizOran;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY3184Services {
	@GraymoundService("BNSPR_QRY3184_GET_FAIZ_ORAN")
	public static HashMap<String, Object> getFaizOran(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(VBirFaizOran.class)
			.add(Restrictions.eq("krdTurKod", iMap.getBigDecimal("KRD_TUR_KOD")))
			.add(Restrictions.eq("krdTurAltKod", iMap.getBigDecimal("KRD_ALT_TUR_KOD")))
			.add(Restrictions.eq("krdTurAltKod2", iMap.getBigDecimal("KRD_ALT_TUR_KOD_2")))
			.add(Restrictions.eq("kanalKod", iMap.getString("KANAL_KOD")))
			.add(Restrictions.eq("dovizKod", iMap.getString("DOVIZ_KOD")))
			.addOrder(Order.asc("kanalKod"))
			.addOrder(Order.asc("dovizKod"))
			.addOrder(Order.asc("minVade"))
			.addOrder(Order.asc("maxVade"))
			.addOrder(Order.asc("minTutar"))
			.addOrder(Order.asc("maxTutar"))
			.list();

			ArrayList<HashMap<String, Object>> outList = new ArrayList<HashMap<String, Object>>();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				VBirFaizOran vBirFaizOran = (VBirFaizOran) iterator.next();
				HashMap<String, Object> rowData = new HashMap<String, Object>();

				rowData.put("FAIZ_ORAN_ID", vBirFaizOran.getId().getFaizOranId());
				rowData.put("BAZ_FAIZ_ORAN_ID", vBirFaizOran.getId().getBazFaizOranId());
				rowData.put("KANAL_KODU", vBirFaizOran.getKanalKod());
				rowData.put("DOVIZ_CINSI", vBirFaizOran.getDovizKod());
				
				iMap.put("KRD_TUR_ALT_KOD",iMap.getBigDecimal("KRD_ALT_TUR_KOD"));
				iMap.put("KRD_TUR_ALT_KOD2",iMap.getBigDecimal("KRD_ALT_TUR_KOD_2"));
				iMap.put("KANAL_KOD",vBirFaizOran.getKanalKod());
				iMap.put("DOVIZ_KOD",vBirFaizOran.getDovizKod());	
				
				rowData.put("DI_KANAL_KODU", GMServiceExecuter.execute("BNSPR_TRN3109_GET_KANAL_ADI", iMap).get("KANAL_ADI"));
				
				rowData.put("MIN_VADE", vBirFaizOran.getMinVade());
				rowData.put("MAX_VADE", vBirFaizOran.getMaxVade());
				rowData.put("MIN_TUTAR", vBirFaizOran.getMinTutar());
				rowData.put("MAX_TUTAR", vBirFaizOran.getMaxTutar());
				rowData.put("FAIZ_ORANI", vBirFaizOran.getFaizOran());
				
				rowData.put("DOSYA_MASRAF_TIP", vBirFaizOran.getDosMasrafTip());
				rowData.put("DOSYA_MASRAFI", vBirFaizOran.getDosMasrafOran());
				rowData.put("MIN_DOSYA_MASRAFI", vBirFaizOran.getMinDosMasraf());
				rowData.put("MAX_DOSYA_MASRAFI", vBirFaizOran.getMaxDosMasraf());

				outList.add(rowData);
			}

			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("FAIZ_ORAN_PR", outList);

			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
}
