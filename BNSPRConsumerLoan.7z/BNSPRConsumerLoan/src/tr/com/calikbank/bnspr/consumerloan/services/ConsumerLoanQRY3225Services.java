package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.File;
import java.math.BigDecimal;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.ReportUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY3225Services {

	@GraymoundService("BNSPR_QRY3225_BASVURU_LIST")
	public static GMMap basvuruList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (StringUtil.isEmpty(iMap.getString("MUSTERI_NO"))) {
				if (StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))) {
					throw new GMRuntimeException(0, "M��teri No / Tc kimlik no dan birisi dolu olmal�d�r.");
				}
				else {
					String musteriNo = (String) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.Musteri_Varmi_TCKN(?)}", Types.VARCHAR, iMap.getString("TC_KIMLIK_NO"));
					if (musteriNo != null) {
						iMap.put("MUSTERI_NO", musteriNo);
					}
				}
			}
			
			String func = "{? = call PKG_RC3225.get_basvuru_list(?,?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), 
									BnsprType.NUMBER, iMap.getBigDecimal("SATICI_KOD")};
			String tableName = "BASVURU_LIST";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
			oMap.put("TABLE_NAME", tableName);
			oMap.put("CHECKED", false);

			if (oMap.get(tableName) != null && oMap.getSize(tableName) > 0) {
				inputValues = new Object[4];
				inputValues[0] = BnsprType.NUMBER;
				inputValues[1] = iMap.getBigDecimal("BASVURU_NO");
				inputValues[2] = BnsprType.NUMBER;
				inputValues[3] = iMap.getBigDecimal("MUSTERI_NO");

				func = "{ ? = call pkg_rc3956.eposta_bilgi(?,?) }";
				oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "EPOSTA_TABLO", inputValues));
				oMap.put("GONDERIM_TIPI", "E");
			}
			return selectAll(oMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3225_GONDERIM_LISTE")
	public static GMMap gonderimListesi(GMMap iMap) {
		GMMap tMap = new GMMap();
		GMMap oMap = new GMMap();

		String gonderimTipi = iMap.getString("GONDERIM_TIPI");

		if ("E".equalsIgnoreCase(gonderimTipi)) {
			try {
				Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };

				inputValues = new Object[4];
				inputValues[0] = BnsprType.NUMBER;
				inputValues[1] = iMap.getBigDecimal("BASVURU_NO");
				inputValues[2] = BnsprType.NUMBER;
				inputValues[3] = iMap.getBigDecimal("MUSTERI_NO");

				String func = "{ ? = call pkg_rc3956.eposta_bilgi(?,?) }";
				oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "EPOSTA_TABLO", inputValues));
			}
			catch (Exception e) {
				e.printStackTrace();
				throw ExceptionHandler.convertException(e);
			}
		}
		else {

			tMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_ADDRESS_LIST", iMap));

			StringBuilder sb = new StringBuilder();
			String listName = "RESULTS", listName2 = "EPOSTA_TABLO";
			int i;
			for (i = 0; i < tMap.getSize(listName); i++) {
				sb.setLength(0);
				sb.append(tMap.getString(listName, i, "ADRES")).append(" ");
				sb.append(tMap.getString(listName, i, "ILCE_ADI")).append(" / ");
				sb.append(tMap.getString(listName, i, "IL_ADI"));

				oMap.put(listName2, i, "EPOSTA", sb.toString());
				oMap.put(listName2, i, "EPOSTA_TURU", tMap.getString(listName, i, "ADRES_TIPI"));
			}

		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3225_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(iMap);
			String tableName = iMap.getString("TABLE_NAME");
			boolean isChecked = iMap.getBoolean("CHECKED");
			int size = iMap.getSize(tableName);
			for (int i = 0; i < size; i++) {
				oMap.put(tableName, i, "SEC", isChecked);
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Kapama yapilacak basvurulari toplu olarak loglar<br>
	 * 
	 * @author murat.el
	 * @since TY-3850
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>BASVURU_LIST - Musteri numarasi
	 * @return oMap - Sonuc yok<br>
	 */
	@GraymoundService("BNSPR_QRY3225_KREDI_KAPAMA_LOGLA_LIST")
	public static GMMap krediKapamaLoglaList(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Basvuru listesi dolu mu?
			String tableName = "BASVURU_LIST";
			if (iMap.get(tableName) == null || iMap.getSize(tableName) < 1) {
				return oMap;
			}
			// Kontrol et
			GMMap sorguMap = new GMMap();
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				// Secili mi
				if (!iMap.getBoolean(tableName, i, "SEC")) {
					continue;
				}
				if(iMap.getString(tableName, i, "URUN_SINIF_KOD") != null && "ZRTFN".equals(iMap.getString(tableName, i, "URUN_SINIF_KOD"))){
					iMap.put("HATA_NO", new BigDecimal(5948));
					iMap.put("P1", iMap.get(tableName, i, Constants.BASVURU_NO));
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					
				}
				// Islemler basarili ise logla
				sorguMap.clear();
				sorguMap.put(Constants.BASVURU_NO, iMap.get(tableName, i, Constants.BASVURU_NO));
				sorguMap.putAll(krediKapamaLogla(sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_QRY3225_KREDI_KAPAMA_LOGLA")
	public static GMMap krediKapamaLogla(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{call PKG_RC3225.kredi_kapama_log_olustur(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
			Object[] outputValues = {};
			DALUtil.callOracleProcedure(func, inputValues, outputValues);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3225_KMH_LIMIT_VAR_MI")
	public static GMMap kmhLimitVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_RC3225.kmh_limit_var_mi(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO") };
			oMap.put("KMH_LIMIT_VAR_YOK", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3225_IDARI_YASAL_TAKIP_VAR_MI")
	public static GMMap yasalIdariTakipVarmi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_RC3225.idari_yasal_takip_var_mi(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO") };
			oMap.put("YASAL_IDARI_TAKIP_VAR_MI", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3225_GECICI_HESAPTA_ALACAK_VAR_MI")
	public static GMMap geciciHesaptaAlacakVarmi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_RC3225.gecici_hesapta_alacak_var_mi(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO") };
			oMap.put("GECICI_HESAPTA_ALACAK_VAR_MI", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3225_RISK_VAR_MI")
	public static GMMap riskVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_RC3225.kredi_riski_var_mi(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO") };
			oMap.put("RISK_VAR_MI", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3225_HESAP_DURUM_KODU")
	public static GMMap krediHesapDurum(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_RC3225.get_hesap_durum_kodu(?)}";
			String hesap_durum_kodu = (String) DALUtil.callOneParameterFunction(func, Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));
			String hdk_mesaj[][] = new String[][] { { "T", "2836" }, { "GK", "2837" }, { "A", "2838" }, { "I", "2948" }, { "Y", "2949" }, { "G", "2950" }, { "K", "OK" } };
			String mesaj_kodu = "OK";
			for (int j = 0; j < hdk_mesaj.length; j++) {
				if (hesap_durum_kodu.equals(hdk_mesaj[j][0])) {
					mesaj_kodu = hdk_mesaj[j][1];
				}
			}
			oMap.put("HESAP_DURUM_KODU", hesap_durum_kodu);
			oMap.put("MESAJ_KODU", mesaj_kodu);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3225_MEKTUP_GONDER")
	public static GMMap mektupGonder(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();
		try {
			iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
			String eposta = iMap.getString("EPOSTA");

			// E-Posta
			if (iMap.getString("GONDERIM_TIPI") != null && "E".equals(iMap.getString("GONDERIM_TIPI"))) {
				if (eposta == null || eposta.length() == 0) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Eposta");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				//

				Object[] inputValues = new Object[4];
				inputValues[0] = BnsprType.STRING;
				inputValues[1] = iMap.getString("EPOSTA");
				Object[] outputValues = new Object[0];
				String proc = "{ call pkg_trn10011.e_mail_check(?) }";
				DALUtil.callOracleProcedure(proc, inputValues, outputValues);

				inputValues = new Object[4];
				inputValues[0] = BnsprType.STRING;
				inputValues[1] = eposta;
				outputValues = new Object[0];
				proc = "{ call pkg_trn10011.e_mail_check(?) }";
				DALUtil.callOracleProcedure(proc, inputValues, outputValues);

				Object[] inputValues2 = new Object[4];
				inputValues2[0] = BnsprType.STRING;
				inputValues2[1] = "KREDI_SOZLESME_MAIL";
				inputValues2[2] = BnsprType.STRING;
				inputValues2[3] = "KREDI_KAPAMA_YAZISI";
				Object[] outputValues2 = new Object[12];
				int n = 0;
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "FROM";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "CC";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "BCC";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "SUBJECT";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "BODY";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "FILENAME_PREFIX";

				String proc2 = "{ call pkg_rc3956.mail_gonderen_bilgi(?,?,?,?,?,?,?,?) }";
				iMap.putAll((GMMap) DALUtil.callOracleProcedure(proc2, inputValues2, outputValues2));

				/** TY-6558 TY-Adres Evrak G�nderim Talepleri */
				GMMap reportMap = GMServiceExecuter.call("BNSPR_QRY3225_GET_REPORTS", iMap);
				JasperPrint jasperPrint = (JasperPrint) reportMap.get("REPORT");

				String fileName = iMap.getString("FILENAME_PREFIX") + reportMap.getString("BASVURU_PATH") + "_" + System.currentTimeMillis() + ".pdf";
				String fileNamePath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;

				JRPdfExporter pdfexporter = new JRPdfExporter();
				pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
				pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileNamePath);
				pdfexporter.exportReport();

				oMap.put("FILENAME", fileName);
				oMap.put("FILENAMEPATH", fileNamePath);

				GMMap servisMap = new GMMap();
				servisMap.put("FROM", iMap.getString("FROM"));
				servisMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(eposta));
				if (StringUtils.isNotBlank(iMap.getString("CC")))
					servisMap.put("RECIPIENTS_CC", GuimlUtil.createFromCommaSeparatedList(iMap.getString("CC")));
				if (StringUtils.isNotBlank(iMap.getString("BCC")))
					servisMap.put("RECIPIENTS_BCC", GuimlUtil.createFromCommaSeparatedList(iMap.getString("BCC")));
				servisMap.put("SUBJECT", iMap.getString("SUBJECT"));
				servisMap.put("MESSAGE_BODY", iMap.getString("BODY"));
				servisMap.put("IS_BODY_HTML", true);
				servisMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
				servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", oMap.getString("FILENAME"));
				servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", FileUtil.readFileToByteArray(new File(oMap.getString("FILENAMEPATH"))));
				GMServiceExecuter.executeAsync("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);
			}
			else {
				/** TY-6558 TY-Adres Evrak G�nderim Talepleri */

				if (iMap.getString("EPOSTA") == null || iMap.getString("EPOSTA").length() == 0) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Di�er Adres");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				tMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3225_GET_REPORTS", iMap));
				JasperPrint jasperPrint = (JasperPrint) tMap.get("REPORT");
				
				String fileName = iMap.getString("FILENAME_PREFIX") + tMap.getString("BASVURU_PATH") + "_" + System.currentTimeMillis() + ".pdf";
				String fileNamePath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;
				JRPdfExporter pdfexporter = new JRPdfExporter();
				pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
				pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileNamePath);
				pdfexporter.exportReport();
				oMap.put("FILENAME", fileName);
				oMap.put("FILENAMEPATH", fileNamePath);
				iMap.put("ISLEM_TURU", "224");

				iMap.put("GONDERILEN_BOLUM", "BROPS"); // Bireysel Kredi Operasyon
				iMap.put("ISLEM_ADEDI", new BigDecimal(1));
				iMap.put("ISLEM_ONCELIGI", "N"); // Normal
				iMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
				iMap.put("UNVAN", LovHelper.diLov(iMap.getBigDecimal("MUSTERI_NO"), "4001/LOV_KONTAKT_MUSTERI", "UNVAN"));
				iMap.put("KREDI_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				iMap.put("ACIKLAMA", iMap.getString("EPOSTA"));

				iMap.put("DOSYA_SAYFA", 0, "FILE_NAME", oMap.get("FILENAME"));
				iMap.put("DOSYA_SAYFA", 0, "CONTENT", FileUtil.readFileToByteArray(new File(oMap.getString("FILENAMEPATH"))));

				GMServiceExecuter.execute("BNSPR_TRN4001_SAVE", iMap);

			}
			
			oMap.put("MESSAGE", "��lem tamamlanm��t�r.");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3225_GET_REPORTS")
	public static GMMap getReports(GMMap iMap) {
		GMMap oMap = new GMMap();
		BirBasvuru birBasvuru = null;
		try {
			String tableName = "BASVURU_LIST";
			if (iMap.getSize(tableName) == 0 && iMap.getBigDecimal("BASVURU_NO") != null) {
				iMap.put(tableName, 0, "BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				iMap.put(tableName, 0, "SEC", true);
			}
			Session session = DAOSession.getSession("BNSPRDal");
			
			int size = iMap.getSize(tableName);
			int adet = 0;
			String basvurular = "";
			String basvuruPath = "";
			JasperPrint jasperPrint = null;

			int seciliBasvuru = 0;

			for (int i = 0; i < size; i++) {
				if (iMap.getBoolean(tableName, i, "SEC")) {
					seciliBasvuru++;
				}
			}

			boolean topluMu = seciliBasvuru > 1;

			if (size > 0) {
				HashMap<String, Object> parameters = new HashMap<String, Object>();
				GMMap tMap = new GMMap();
				for (int i = 0; i < size; i++) {
					if (iMap.getBoolean(tableName, i, "SEC")) {
						if (topluMu) {
							if (adet != 0) {
								basvurular += ",";
								basvuruPath += "_";
							}
							basvurular += iMap.getBigDecimal(tableName, i, "BASVURU_NO");
							basvuruPath += iMap.getBigDecimal(tableName, i, "BASVURU_NO");
						}
						else {
							parameters.put("BASVURU_NO", iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
							if (adet == 0) {
								basvuruPath = iMap.getBigDecimal(tableName, i, "BASVURU_NO").toString();
								birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal(tableName, i, "BASVURU_NO"))).uniqueResult();
								if("E".equals(birBasvuru.getFaizsizFinansman())){
									jasperPrint = ReportUtil.generateReport("BNSPR_RAP3225_KREDI_KAPAMA_YAZISI_FZ", parameters);
								}else{
									jasperPrint = ReportUtil.generateReport("BNSPR_RAP3225_KREDI_KAPAMA_YAZISI", parameters);
								}
							}
							else {
								JasperPrint tmp = ReportUtil.generateReport("BNSPR_RAP3225_KREDI_KAPAMA_YAZISI", parameters);
								for (Object jasperPrintPage : tmp.getPages()) {
									jasperPrint.addPage((JRPrintPage) jasperPrintPage);
								}
							}
						}
						tMap.put("BASVURU_NO", iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
						krediKapamaLogla(tMap);
						adet++;
					}
				}
				if (topluMu && adet > 0) {
					if (adet == 1) {
						parameters.put("BASVURU_NO", iMap.getBigDecimal(tableName, 0, "BASVURU_NO"));
						birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal(tableName, 0, "BASVURU_NO"))).uniqueResult();
						if("E".equals(birBasvuru.getFaizsizFinansman())){
							jasperPrint = ReportUtil.generateReport("BNSPR_RAP3225_KREDI_KAPAMA_YAZISI_FZ", parameters);
						}else{
							jasperPrint = ReportUtil.generateReport("BNSPR_RAP3225_KREDI_KAPAMA_YAZISI", parameters);
						}
					}
					else {
						parameters.put("BASVURU_LIST", basvurular);
						parameters.put("ADET", adet);
						jasperPrint = ReportUtil.generateReport("BNSPR_RAP3225_KREDI_KAPAMA_YAZISI_TOPLU", parameters);
					}
				}
			}
			if (adet == 0) {
				throw new GMRuntimeException(0, "Hi�bir Kay�t Se�mediniz. L�tfen Kay�t Se�iniz");
			}
			oMap.put("BASVURU_PATH", basvuruPath);
			oMap.put("REPORT", jasperPrint);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/** TY-6900 TY-Bireysel krediler Servis �al��malar� _3179 ve 3225 ekranlar� i�in */
	@GraymoundService("BNSPR_QRY3225_KAPAMA_YAPILABILIR_MI")
	public static GMMap getKapamaYapilabilirMi(GMMap iMap) {
		GMMap tMap = new GMMap();
		ArrayList<String> tarrList = new ArrayList<String>();
		GMMap oMap = new GMMap();
		try {
			if (iMap.getString("MUSTERI_NO") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "M��teri No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			tMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3225_BASVURU_LIST", iMap));

			if (tMap.containsKey("BASVURU_LIST")) {
				tarrList = (ArrayList<String>) tMap.get("BASVURU_LIST");
			}

			if (tMap.containsKey("BASVURU_LIST") && tarrList.size() > 0) {
				oMap.put("KAPAMA_YAPILABILIR_MI", "E");
			}
			else {
				oMap.put("KAPAMA_YAPILABILIR_MI", "H");
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
