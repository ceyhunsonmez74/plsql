package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiMalDetayTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiMalDetayTxId;
import tr.com.aktifbank.bnspr.dao.BirSaticiMalTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiMalTxId;
import tr.com.aktifbank.bnspr.dao.BirSaticiTahsisEkisyeriTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiTahsisEkisyeriTxId;
import tr.com.aktifbank.bnspr.dao.BirSaticiTahsisTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisan;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisanTx;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisanTxId;
import tr.com.calikbank.bnspr.dao.BirSaticiLimitTx;
import tr.com.calikbank.bnspr.dao.BirSaticiLimitTxId;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisAraclarTx;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisFaaliyet;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisFaaliyetTx;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisFaaliyetTxId;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisMarkalarTx;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisMarkalarTxId;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3162Services {

	@GraymoundService("BNSPR_TRN3162_GET_YENI_MI")
	public static GMMap getYeniMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3162.satici_tahsis_yeni(?) }");
			int i = 0;
			stmt.registerOutParameter(++i, Types.VARCHAR);
			stmt.setBigDecimal(++i, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();
			// stmt.getMoreResults();
			String saticiTip = stmt.getString(1);
			if (saticiTip.equals("E"))
				oMap.put("YENI_MI", true);
			else
				oMap.put("YENI_MI", false);
			stmt.close();
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_DISTRIBUTOR_MU")
	public static GMMap getDistributorMu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tablo.BirSatici(?).satici_tip_kod }");
			int i = 0;
			stmt.registerOutParameter(++i, Types.VARCHAR);
			stmt.setBigDecimal(++i, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();
			// stmt.getMoreResults();
			String saticiTip = stmt.getString(1);
			if (saticiTip.equals("D"))
				oMap.put("DISTRIBUTOR_MU", true);
			else
				oMap.put("DISTRIBUTOR_MU", false);
			stmt.close();
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_3162_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			iMap.put("KOD", "BAYI_STATU_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BAYI_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "CALISMA_SEKLI_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BAYI_CALISMA_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_RISK_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BAYI_RISKI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "KISMI_KAPANMA_NEDEN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KISMI_KAPANMA_NEDENI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "KISMI_KAPANMA_STATU_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KISMI_KAPANMA_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "KAPANMA_NEDEN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KAPANMA_NEDENI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "ISYERI_MULKIYET_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("ISYERI_MULKIYETI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "ISYERI_KONUM_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("ISYERI_KONUMU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "DAGITICI_FIRMA_TEMINAT_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("DAGITICI_FIRMA_TEMINAT", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "MUSTERI_PORTFOY_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("MUSTERI_PORTFOYU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "VAR_YOK");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("YATIRIM_PLANI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "EVET_HAYIR");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("EVET_HAYIR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "YETKI_SEVIYE_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("YETKI_SEVIYESI_BOSSUZ", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "YETKI_SEVIYE_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("YETKI_SEVIYESI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "GARANTOR_BELGE_TIP");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("GARANTOR_BELGE_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "GARANTOR_BELGE_TIP");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("GARANTI_TAAHHUDU_BELGE_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "LIMIT_TIP_KOD");
			oMap.put("LIMIT_TIP_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			iMap.put("ADD_EMPTY_KEY", "E");

			iMap.put("KOD", "CAL_STATU_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("CAL_STATU_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "TUTTUGU_TAKIM_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("TUTTUGU_TAKIM_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "POZISYON_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("POZISYON_KOD_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "CAL_KAPANMA_NEDEN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("CAL_KAPANMA_NEDEN_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "CAL_KISMI_KAPANMA_NEDEN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("CAL_KISMI_KAPANMA_NEDEN_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("LOV", "3161/LOV_UYRUK");
			iMap.put("VALUE", "KOD");
			iMap.put("NAME", "ACIKLAMA");
			oMap.put("UYRUK_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "ONEM_DERECE_KOD");
			oMap.put("ONEM_DERECESI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_SEGMENTI");
			oMap.put("BAYI_SEGMENT", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_ANA_SATIS_KANAL");
			oMap.put("ANA_SATIS_KANAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_CIRO_DEGISIM");
			oMap.put("ANA_CIRO_DEGISIM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_DISTRIBUTOR_DURUM");
			oMap.put("DISTRIBUTOR_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_KATEGORI_SKOR");
			oMap.put("KATEGORI_SKOR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_KATEGORI_SKOR");
			oMap.put("KATEGORI_SKOR_TAHSIS", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_CALISMA_ESAS");
			oMap.put("CALISMA_ESAS", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_BLOKAJ_NEDEN");
			oMap.put("BLOKAJ_NEDEN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_BLOKAJ_KREDI_TIP");
			oMap.put("BLOKAJ_KREDI_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_BLOKAJ_COZUM_ZAMAN");
			oMap.put("BLOKAJ_COZUM_ZAMAN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_ISTIHBARAT_FIRMA_GORUS");
			oMap.put("ISTIHBARAT_FIRMA_GORUS", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_KITLE");
			oMap.put("DST_KITLE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_CIRO_DEGISIM");
			oMap.put("DST_CIRO_DEGISIM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_KAZANIM_KANAL");
			oMap.put("DST_KAZANIM_KANAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_URUN_TIP");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BAYI_URUN_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_UST_URUN_TIP");
			oMap.put("BAYI_UST_URUN_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_URUN_KALITE");
			oMap.put("KALITE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_URUN_TESLIMAT_YER");
			oMap.put("URUN_TESLIM_YER", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_HIZMET_TESLIMAT_YER");
			oMap.put("HIZMET_TESLIM_YER", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_URUN_2EL_DEGER");
			oMap.put("DEGER2EL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_URUN_SKOR");
			oMap.put("SKOR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAYI_URUN_SKOR");
			oMap.put("SKOR_TAHSIS", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_FAALIYET_KONULARI")
	public static GMMap getOdemeGruplarUrun(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1, text from gnl_param_text where kod = 'ISYERI_FAAL_KONU_KOD' order by sira_no, decode(UPPER(substr(text, 1, 1)), '�','GZ','�','UZ','�','SZ','�','IZ','�','OZ','�','CZ',UPPER(substr(text, 1, 1)))");

			rSet = stmt.executeQuery();

			GMMap oMap = new GMMap();
			String tableName = "FAALIYET_KONULARI";
			String tableName2 = "EK_ISYERI_FAALIYET_KONULARI";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "FAALIYET_KODU", rSet.getString(1));
				oMap.put(tableName2, row, "FAALIYET_KODU", rSet.getString(1));
				oMap.put(tableName, row, "FAALIYET_KONUSU", rSet.getString(2));
				oMap.put(tableName2, row, "FAALIYET_KONUSU", rSet.getString(2));
				oMap.put(tableName, row, "SEC", false);
				oMap.put(tableName2, row, "SEC", false);
				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_SUBE_LIMITLERI")
	public static GMMap getRecordList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3162.RC_QRY3162_GET_SATICI_LIMIT(?) }");
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			stmt.setBigDecimal(++i, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();
			// stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			// System.out.print(rSet.())DOVIZ_CINSI
			// GMMap oMap = new GMMap();
			// int row=0;
			/*
			 * while(rSet.next()){ oMap.put("LIMIT_TABLO",
			 * row,"Garanti_Taahhudu_maksimum_oran"
			 * ,rSet.getString("Doviz_Cinsi")); row++; }
			 */
			oMap = DALUtil.rSetResults(rSet, "LIMIT_TABLO");
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3162_SAVE")
	public static Map<?, ?> saveTRN3162(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		PreparedStatement pstmt = null;
		try {

			if (iMap.getBigDecimal("SATICI_NO") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Sat�c� No");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			conn = DALUtil.getGMConnection();

			Session session = DAOSession.getSession("BNSPRDal");

			BirSaticiTahsisTx birSaticiTahsisTx = (BirSaticiTahsisTx) session.get(BirSaticiTahsisTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birSaticiTahsisTx == null)
				birSaticiTahsisTx = new BirSaticiTahsisTx();
			birSaticiTahsisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));

			// yeni_eklenen
			birSaticiTahsisTx.setLimitMerkezBagimsizEh(iMap.getString("LIMIT_MERKEZ"));
			// yeni_eklenen_son
			birSaticiTahsisTx.setKod(iMap.getBigDecimal("SATICI_NO"));
			birSaticiTahsisTx.setBayiSskIsyeriKod(iMap.getString("BAYI_SSK_ISYERI_KODU"));
			birSaticiTahsisTx.setTicaretSicilNo(iMap.getString("TICARET_SICIL_NO"));
			birSaticiTahsisTx.setYetkiSeviyeKod(iMap.getString("YETKI_SEVIYE_KOD"));
			birSaticiTahsisTx.setTopCalisanSayi(iMap.getBigDecimal("TOPLAM_CALISAN_SAYISI"));
			if (iMap.getBoolean("AYNI_SIFRE_BASVURU") == true) {
				birSaticiTahsisTx.setAyniSifreBasvuruEh("E");
			}
			else {
				birSaticiTahsisTx.setAyniSifreBasvuruEh("H");
			}
			birSaticiTahsisTx.setIsyeriMulkiyetKod(iMap.getString("ISYERI_MULKIYETI"));
			if (iMap.getString("ISYERI_MULKIYETI") != null && iMap.getString("ISYERI_MULKIYETI").equals("KR"))
				birSaticiTahsisTx.setKiraBedeli(iMap.getBigDecimal("KIRA_BEDELI"));
			// birSaticiTahsisTx.setBlokeSuresi(iMap.getBigDecimal("BLOKE_SURESI"));
			birSaticiTahsisTx.setIsyeriKonumKod(iMap.getString("ISYERI_KONUMU"));
			birSaticiTahsisTx.setIsyeriYuzolcumu(iMap.getBigDecimal("YUZOLCUMU"));
			birSaticiTahsisTx.setEkIsyeriVar(iMap.getString("EK_ISYERI_VAR_MI"));
			birSaticiTahsisTx.setErkenBelgeAlimiEh(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("ERKEN_BELGE_ALABILIR_MI_DST") : iMap.getString("ERKEN_BELGE_ALABILIR_MI"));
			if (iMap.getString("EK_ISYERI_VAR_MI") != null && iMap.getString("EK_ISYERI_VAR_MI").equals("E"))
				birSaticiTahsisTx.setEkIsyeriAdi(iMap.getString("EK_ISYERI_ADI"));
			birSaticiTahsisTx.setAciklama(iMap.getString("ACIKLAMA"));
			birSaticiTahsisTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			birSaticiTahsisTx.setBayiStatuKod(iMap.getString("BAYI_STATU"));
			birSaticiTahsisTx.setCalismaSekliKod(iMap.getString("BAYI_CALISMA_SEKLI"));
			birSaticiTahsisTx.setBayiRiskKod(iMap.getString("BAYI_RISKI"));
			birSaticiTahsisTx.setBayiAylikLimit(iMap.getBigDecimal("AYLIK_LIMIT"));
			birSaticiTahsisTx.setBayiGunlukLimit(iMap.getBigDecimal("GUNLUK_LIMIT"));
			if (iMap.getString("BAYI_STATU") != null && iMap.getString("BAYI_STATU").equals("KK")) {
				birSaticiTahsisTx.setKismiKapanmaNedenKod(iMap.getString("KISMI_KAPANMA_NEDENI"));
				birSaticiTahsisTx.setKismiKapanmaStatuKod(iMap.getString("KISMI_KAPANMA_STATU"));
			}
			else if (iMap.getString("BAYI_STATU") != null && iMap.getString("BAYI_STATU").equals("K"))
				birSaticiTahsisTx.setKapanmaNedenKod(iMap.getString("KAPANMA_NEDENI"));
			birSaticiTahsisTx.setOrjEvrakGonSure(iMap.getBigDecimal("ORJINAL_EVRAK_GON_SURESI"));
			birSaticiTahsisTx.setBasvuruGirilebilirEh("H");
			if (iMap.getBoolean("BASVURU_GIREBILIR_EH")) {
				birSaticiTahsisTx.setBasvuruGirilebilirEh("E");
			}
			// birSaticiTahsisTx.setMaliYili(iMap.getBigDecimal("MALI_YILI"));
			birSaticiTahsisTx.setMusteriPortfoyKod(iMap.getString("MUSTERI_PORTFOYU"));
			// birSaticiTahsisTx.setSermayeTutar(iMap.getBigDecimal("SERMAYE_TUTAR"));
			// birSaticiTahsisTx.setVergiMatrah(iMap.getBigDecimal("VERGI_MATRAH"));
			// birSaticiTahsisTx.setAylikSatisAdet(iMap.getBigDecimal("AYLIK_SATIS_ADET"));
			// birSaticiTahsisTx.setTasitSayi(iMap.getBigDecimal("TASIT_SAYI"));
			birSaticiTahsisTx.setCalFinans1Eh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("CAL_FINANS1_EH")));
			birSaticiTahsisTx.setCalFinans2Eh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("CAL_FINANS2_EH")));
			birSaticiTahsisTx.setCalFinans3Eh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("CAL_FINANS3_EH")));
			birSaticiTahsisTx.setCalFinans4Eh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("CAL_FINANS4_EH")));
			if (iMap.getBoolean("CAL_FINANS_DIGER")) {
				if (iMap.getString("CAL_FINANS_DIGER_ADI") == null || iMap.getString("CAL_FINANS_DIGER_ADI").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "�al��t��� Finans Kurulu�lar� Di�er");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					return null;
				}
				birSaticiTahsisTx.setCalFinansDiger(iMap.getString("CAL_FINANS_DIGER_ADI"));
			}
			birSaticiTahsisTx.setDagiticiFirmaTeminatKod(iMap.getString("DAGITICI_FIRMA_TEMINAT_CINSI"));
			birSaticiTahsisTx.setTeminatTutar(iMap.getBigDecimal("TEMINAT_TUTARI"));
			birSaticiTahsisTx.setYatirimPlani(iMap.getString("YATIRIM_PLANI_VAR_MI"));
			if (iMap.getString("YATIRIM_PLANI_VAR_MI") != null && iMap.getString("YATIRIM_PLANI_VAR_MI").equals("VAR"))
				birSaticiTahsisTx.setYatirimPlaniAciklama(iMap.getString("YATIRIM_PLANI_ACIKLAMA"));
			birSaticiTahsisTx.setOrtakSektorTecrubesi(iMap.getBigDecimal("ORTAK_SEKTOR_TECRUBESI"));
			birSaticiTahsisTx.setBeklenenKrediHacmi(iMap.getBigDecimal("BEKLENEN_KREDI_HACMI"));
			// birSaticiTahsisTx.setDurum(iMap.getString("DURUM"));
			birSaticiTahsisTx.setGayrimenkulAdetArsa(iMap.getBigDecimal("GMENKUL_ARSA"));
			birSaticiTahsisTx.setGayrimenkulAdetDukkan(iMap.getBigDecimal("GMENKUL_DUKKAN"));
			birSaticiTahsisTx.setGayrimenkulAdetEv(iMap.getBigDecimal("GMENKUL_EV"));
			birSaticiTahsisTx.setSubeSayisi(iMap.getBigDecimal("SUBE_SAYISI"));
			birSaticiTahsisTx.setAylikBasvuruLimit(iMap.getBigDecimal("AYLIK_BASVURU_LIMIT"));
			birSaticiTahsisTx.setTasitSayi(iMap.getBigDecimal("TASIT_SAYISI"));
			birSaticiTahsisTx.setBayiSegmentKod(iMap.getString("BAYI_SEGMENT"));
			birSaticiTahsisTx.setAnaSatisKanal((iMap.getString("ANA_SATIS_KANAL")));
			birSaticiTahsisTx.setYillikCiro(iMap.getBigDecimal("YILLIK_CIRO"));
			birSaticiTahsisTx.setAnaCiroDegisim(iMap.getString("ANA_CIRO_DEGISIM"));
			birSaticiTahsisTx.setYatirimBuyukluk((iMap.getBigDecimal("YATIRIM_BUYUKLUGU")));
			String ayniAdresteFaaliyetSuresiYil = iMap.getString("AYNI_ISYERINDE_FAALIYET_SURESI_YIL");
			if (ayniAdresteFaaliyetSuresiYil == null || ayniAdresteFaaliyetSuresiYil.length() == 0)
				ayniAdresteFaaliyetSuresiYil = "00";
			else if (ayniAdresteFaaliyetSuresiYil.length() == 1)
				ayniAdresteFaaliyetSuresiYil = "0" + ayniAdresteFaaliyetSuresiYil;
			String ayniAdresteFaaliyetSuresiAy = iMap.getString("AYNI_ISYERINDE_FAALIYET_SURESI_AY");
			if (ayniAdresteFaaliyetSuresiAy == null || ayniAdresteFaaliyetSuresiAy.length() == 0)
				ayniAdresteFaaliyetSuresiAy = "00";
			else if (ayniAdresteFaaliyetSuresiAy.length() == 1)
				ayniAdresteFaaliyetSuresiAy = "0" + ayniAdresteFaaliyetSuresiAy;
			if (!(ayniAdresteFaaliyetSuresiYil + ayniAdresteFaaliyetSuresiAy).equals("0000"))
				birSaticiTahsisTx.setAyniAdresteFaaliyetSuresi(ayniAdresteFaaliyetSuresiYil + ayniAdresteFaaliyetSuresiAy);
			// birSaticiTahsisTx.setSubeSayisi(iMap.getBigDecimal("SUBE_SAYISI"));
			birSaticiTahsisTx.setOnemDereceKod(iMap.getString("ONEM_DERECE_KOD"));
			birSaticiTahsisTx.setDistributorDurum(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("DISTRIBUTOR_DURUM_DST") : iMap.getString("DISTRIBUTOR_DURUM"));
			birSaticiTahsisTx.setKategoriSkor(iMap.getString("KATEGORI_SKOR"));
			birSaticiTahsisTx.setKategoriSkorTahsis(iMap.getString("KATEGORI_SKOR_TAHSIS"));
			birSaticiTahsisTx.setCalismaEsas(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("CALISMA_ESAS_DST") : iMap.getString("CALISMA_ESAS"));
			birSaticiTahsisTx.setKurumsalGarantorLimit(iMap.getBigDecimal("KURUMSAL_GARANTOR_LIMIT"));
			birSaticiTahsisTx.setPerakendeRezervLimit(iMap.getBigDecimal("PERAKENDE_REZERV_LIMIT"));
			birSaticiTahsisTx.setBlokajOran(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getBigDecimal("BLOKAJ_ORAN_DST") : iMap.getBigDecimal("BLOKAJ_ORAN"));
			birSaticiTahsisTx.setMinBlokeTutar(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getBigDecimal("MIN_BLOKE_TUTAR_DST") : iMap.getBigDecimal("MIN_BLOKE_TUTAR"));
			birSaticiTahsisTx.setBlokajNeden(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("BLOKAJ_NEDEN_DST") : iMap.getString("BLOKAJ_NEDEN"));
			birSaticiTahsisTx.setUstNplOran(iMap.getBigDecimal("UST_NPL_ORAN"));
			birSaticiTahsisTx.setMaxKullLimit(iMap.getBigDecimal("MAX_KULL_LIMIT"));
			birSaticiTahsisTx.setGarantorGorunsunEh(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("GARANTOR_GORUNSUN_EH_DST") : iMap.getString("GARANTOR_GORUNSUN_EH"));
			birSaticiTahsisTx.setFotoCekimEh(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("FOTO_CEKIM_EH_DST") : iMap.getString("FOTO_CEKIM_EH"));
			birSaticiTahsisTx.setBarkodZarfEh(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("BARKOD_ZARF_EH_DST") : iMap.getString("BARKOD_ZARF_EH"));
			birSaticiTahsisTx.setGpsTakipEh(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("GPS_TAKIP_EH_DST") : iMap.getString("GPS_TAKIP_EH"));
			birSaticiTahsisTx.setBilgiFormuEh(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("BILGI_FORMU_EH_DST") : iMap.getString("BILGI_FORMU_EH"));
			birSaticiTahsisTx.setBelgeTeslimEh(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("BELGE_TESLIM_EH_DST") : iMap.getString("BELGE_TESLIM_EH"));
			birSaticiTahsisTx.setOtpKontrolEh(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("OTP_KONTROL_EH_DST") : iMap.getString("OTP_KONTROL_EH"));
			birSaticiTahsisTx.setBlokajKrediTip(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("BLOKAJ_KREDI_TIP_DST") : iMap.getString("BLOKAJ_KREDI_TIP"));
			birSaticiTahsisTx.setBlokajCozumZaman(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getString("BLOKAJ_COZUM_ZAMAN_DST") : iMap.getString("BLOKAJ_COZUM_ZAMAN"));
			birSaticiTahsisTx.setIstihbaratFirmaGorus(iMap.getString("ISTIHBARAT_FIRMA_GORUS"));
			birSaticiTahsisTx.setMaxBlokeTutar(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getBigDecimal("MAX_BLOKE_TUTAR_DST") : iMap.getBigDecimal("MAX_BLOKE_TUTAR"));
			birSaticiTahsisTx.setBlokeHesap(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getBigDecimal("BLOKE_HESAP_DST") : iMap.getBigDecimal("BLOKE_HESAP"));
			birSaticiTahsisTx.setBayiBeklKrediHacmi(iMap.getBigDecimal("BAYI_BEKL_KREDI_HACMI"));
			birSaticiTahsisTx.setBeklenenNpl(iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getBigDecimal("BEKLENEN_NPL_DST") : iMap.getBigDecimal("BEKLENEN_NPL"));
			birSaticiTahsisTx.setDstPazarPay(iMap.getBigDecimal("DST_PAZAR_PAY"));
			birSaticiTahsisTx.setDstKazanimKanal(iMap.getString("DST_KAZANIM_KANAL"));
			birSaticiTahsisTx.setDstBorcOran(iMap.getBigDecimal("DST_BORC_ORAN"));
			birSaticiTahsisTx.setDstBayiOran(iMap.getBigDecimal("DST_BAYI_ORAN"));
			birSaticiTahsisTx.setDstKitle(iMap.getString("DST_KITLE"));
			birSaticiTahsisTx.setDstCiro(iMap.getBigDecimal("DST_CIRO"));
			birSaticiTahsisTx.setDstCiroDegisim(iMap.getString("DST_CIRO_DEGISIM"));
			birSaticiTahsisTx.setDstSenetAgirlik(iMap.getBigDecimal("DST_SENET_AGIRLIK"));
			birSaticiTahsisTx.setDstYatirimBuyukluk(iMap.getBigDecimal("DST_YATIRIM_BUYUKLUK"));
			birSaticiTahsisTx.setValorBlokeHesap(iMap.getBigDecimal("VALOR_BLOKE_HESAP"));
			birSaticiTahsisTx.setUbeDistributorEh(iMap.getBoolean("DST_WEB_BAYI_IZIN_EH") ? "E" : "H");
			birSaticiTahsisTx.setUbeDistributorUnvan(iMap.getString("DST_WEB_GORUNTU_ISIM"));

			session.save(birSaticiTahsisTx);

			List<?> saticiTahsisFaaliyetList = session.createCriteria(BirSaticiTahsisFaaliyetTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : saticiTahsisFaaliyetList) {
				BirSaticiTahsisFaaliyetTx birSaticiTahsisFaaliyetTx = (BirSaticiTahsisFaaliyetTx) name;
				session.delete(birSaticiTahsisFaaliyetTx);
			}
			session.flush();

			List<?> saticiTahsisEkisyeriList = session.createCriteria(BirSaticiTahsisEkisyeriTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : saticiTahsisEkisyeriList) {
				BirSaticiTahsisEkisyeriTx birSaticiTahsisEkisyeriTx = (BirSaticiTahsisEkisyeriTx) name;
				session.delete(birSaticiTahsisEkisyeriTx);
			}
			session.flush();

			pstmt = conn.prepareStatement("DELETE FROM bir_satici_mal_tx WHERE TX_NO = ?");
			pstmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			pstmt.execute();
			pstmt.close();

			pstmt = conn.prepareStatement("DELETE FROM bir_satici_mal_detay_tx WHERE TX_NO = ?");
			pstmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			pstmt.execute();
			pstmt.close();
			saticiTahsisFaaliyetList = (List<?>) iMap.get("FAALIYET_KONUSU");

			String tableName = "FAALIYET_KONUSU";
			for (int i = 0; i < saticiTahsisFaaliyetList.size(); i++) {
				if (iMap.getBoolean(tableName, i, "SEC")) {
					BirSaticiTahsisFaaliyetTx birSaticiTahsisFaaliyetTx = new BirSaticiTahsisFaaliyetTx();
					BirSaticiTahsisFaaliyetTxId birSaticiTahsisFaaliyetTxId = new BirSaticiTahsisFaaliyetTxId();

					birSaticiTahsisFaaliyetTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birSaticiTahsisFaaliyetTxId.setFaaliyetKodu(iMap.getString(tableName, i, "FAALIYET_KODU"));
					birSaticiTahsisFaaliyetTxId.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));
					birSaticiTahsisFaaliyetTxId.setTur("X");

					birSaticiTahsisFaaliyetTx.setId(birSaticiTahsisFaaliyetTxId);

					// session.save(birSaticiTahsisFaaliyetTx);
					session.saveOrUpdate(birSaticiTahsisFaaliyetTx);
				}
			}

			if (iMap.getString("EK_ISYERI_VAR_MI") != null) {
				saticiTahsisFaaliyetList = (List<?>) iMap.get("EK_ISYERI_FAALIYET_KONUSU");
				tableName = "EK_ISYERI_FAALIYET_KONUSU";
				for (int i = 0; i < saticiTahsisFaaliyetList.size(); i++) {
					if (iMap.getBoolean(tableName, i, "SEC")) {
						BirSaticiTahsisFaaliyetTx birSaticiTahsisFaaliyetTx = new BirSaticiTahsisFaaliyetTx();
						BirSaticiTahsisFaaliyetTxId birSaticiTahsisFaaliyetTxId = new BirSaticiTahsisFaaliyetTxId();

						birSaticiTahsisFaaliyetTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birSaticiTahsisFaaliyetTxId.setFaaliyetKodu(iMap.getString(tableName, i, "FAALIYET_KODU"));
						birSaticiTahsisFaaliyetTxId.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));
						birSaticiTahsisFaaliyetTxId.setTur("EK");

						birSaticiTahsisFaaliyetTx.setId(birSaticiTahsisFaaliyetTxId);

						session.saveOrUpdate(birSaticiTahsisFaaliyetTx);
					}
				}

				saticiTahsisEkisyeriList = (List<?>) iMap.get("ILISKILI_BAYI");
				tableName = "ILISKILI_BAYI";

				for (int i = 0; i < saticiTahsisEkisyeriList.size(); i++) {
					if (iMap.getBigDecimal(tableName, i, "SATICI_KOD") == null) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "�li�kili Bayi Sat�c� Kod");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirSaticiTahsisEkisyeriTx birSaticiTahsisEkisyeriTx = new BirSaticiTahsisEkisyeriTx();
					BirSaticiTahsisEkisyeriTxId birSaticiTahsisEkisyeriTxId = new BirSaticiTahsisEkisyeriTxId();

					birSaticiTahsisEkisyeriTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birSaticiTahsisEkisyeriTxId.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));
					birSaticiTahsisEkisyeriTxId.setIliskiliSaticiKod(iMap.getBigDecimal(tableName, i, "SATICI_KOD"));
					birSaticiTahsisEkisyeriTx.setId(birSaticiTahsisEkisyeriTxId);
					birSaticiTahsisEkisyeriTx.setSaticiAdi(iMap.getString("SATICI_AD"));
					birSaticiTahsisEkisyeriTx.setIliskiliSaticiAdi(iMap.getString(tableName, i, "SATICI_ADI"));
					session.saveOrUpdate(birSaticiTahsisEkisyeriTx);
				}
			}
			if (iMap.getBoolean("DISTRIBUTOR_MU"))
				tableName = "URUN_HIZMET_TABLE_DST";
			else
				tableName = "URUN_HIZMET_TABLE";
			GMMap tMap = new GMMap();
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				tMap.put("DETAY_TABLE", iMap.get(tableName, i, "URUN_ALT_GRUP_DATA"));
				for (int j = 0; j < tMap.getSize("DETAY_TABLE"); j++) {
					BirSaticiMalDetayTx birSaticiMalDetayTx = new BirSaticiMalDetayTx();
					BirSaticiMalDetayTxId birSaticiMalDetayTxId = new BirSaticiMalDetayTxId();
					birSaticiMalDetayTxId.setMalno(tMap.getBigDecimal("DETAY_TABLE", j, "ALT_URUN"));
					birSaticiMalDetayTxId.setUstMalno(iMap.getBigDecimal(tableName, i, "UST_GRUP_NO"));
					birSaticiMalDetayTxId.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));
					birSaticiMalDetayTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birSaticiMalDetayTx.setId(birSaticiMalDetayTxId);
					session.saveOrUpdate(birSaticiMalDetayTx);
				}
				BirSaticiMalTx birSaticiMalTx = new BirSaticiMalTx();
				BirSaticiMalTxId birSaticiMalTxId = new BirSaticiMalTxId();
				birSaticiMalTxId.setDeger2el(iMap.getString(tableName, i, "URUN_2EL_DEGER"));
				birSaticiMalTxId.setHizmetTeslimYer(iMap.getString(tableName, i, "HIZMET_TESLIM_YER"));
				birSaticiMalTxId.setKalite(iMap.getString(tableName, i, "URUN_KALITE"));
				birSaticiMalTxId.setMalno(iMap.getBigDecimal(tableName, i, "UST_GRUP_NO"));
				birSaticiMalTxId.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));
				birSaticiMalTxId.setSkor(iMap.getString(tableName, i, "URUN_SKOR"));
				birSaticiMalTxId.setSkorTahsis(iMap.getString(tableName, i, "URUN_SKOR_TAHSIS"));
				birSaticiMalTxId.setTeslimSure(iMap.getBigDecimal(tableName, i, "TESLIMAT_SURESI"));
				birSaticiMalTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birSaticiMalTxId.setUrunTeslimYer(iMap.getString(tableName, i, "URUN_TESLIMAT_YER"));
				birSaticiMalTxId.setUstGrupTip(iMap.getString(tableName, i, "URUN_UST_GRUP_TIP"));
				birSaticiMalTx.setId(birSaticiMalTxId);
				session.saveOrUpdate(birSaticiMalTx);
			}
			session.flush();
			/* YENI EKLENENLER */

			// Connection conn_new = null;
			// conn_new = DALUtil.getGMConnection();
			// Session session = DAOSession.getSession("BNSPRDal");
			String tableName_limit = "LIMIT_TANIMLAMA_TABLO";
			// BirSaticiLimitTx birSaticiLimitTx =(BirSaticiLimitTx)session_NEW.get(BirSaticiLimitTx.class, iMap.getBigDecimal("TRX_NO"));

			List<?> list = session.createCriteria(BirSaticiLimitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : list) {
				BirSaticiLimitTx birSaticiLimitTx = (BirSaticiLimitTx) name;
				session.delete(birSaticiLimitTx);
			}
			session.flush();

			list = (List<?>) iMap.get(tableName_limit);
			for (int i = 0; i < list.size(); i++) {
				BirSaticiLimitTxId id = new BirSaticiLimitTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setDovizCins(iMap.getString(tableName_limit, i, "DOVIZ_CINSI"));
				id.setSaticiLimitTip(iMap.getBigDecimal(tableName_limit, i, "SATIC_LIMIT_TIP"));

				// hata mesaj�
				if (iMap.getString(tableName_limit, i, "DOVIZ_CINSI") == null || iMap.getString(tableName_limit, i, "DOVIZ_CINSI").isEmpty()) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Doviz Kodu");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				if (iMap.getBigDecimal("SATICI_NO") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "SATICI KOD");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				// hata mesaj� son
				// di�er key ler�de burada ekle...
				BirSaticiLimitTx birSaticiLimitTx = null; // = (BirSaticiLimitTx)session.get(BirSaticiLimitTx.class, id);

				// yukarda session � belli oldu
				if (birSaticiLimitTx == null) {
					birSaticiLimitTx = new BirSaticiLimitTx();
				}

				birSaticiLimitTx.setId(id);

				birSaticiLimitTx.setLimit(iMap.getBigDecimal(tableName_limit, i, "ORIJINAL_LIMIT_TUTAR"));

				birSaticiLimitTx.setDurum(iMap.getString(tableName_limit, i, "TALEP"));

				birSaticiLimitTx.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));

				birSaticiLimitTx.setBelgeTip(iMap.getString(tableName_limit, i, "BELGE_TIPI"));

				// /birSaticiLimitTx.setOrjLimit(iMap.getBigDecimal(tableName_limit, i, "ORIJINAL_LIMIT_TUTAR"));
				// /birSaticiLimitTx.setBelgeTaahMaxOran(iMap.getBigDecimal (tableName_limit, i,
				// "BELGE_TAAHHUTU_MAKSIMUM_ORAN"));//(iMap.getBigDecimal("KREDI_TURU"));

				// /birSaticiLimitTx.setGarantiTaahBelgeTip(iMap.getString(tableName_limit, i,
				// "GARANTI_TAAHHUDU_BELGE_TIPI"));//(iMap.getBigDecimal("KREDI_TIPI"));
				// katar = iMap.getString("GARANTI_BELGE");
				// /birSaticiLimitTx.setGarantiTaahMaxOran(iMap.getBigDecimal (tableName_limit, i,
				// "GARANTI_TAAHHUDU_MAKSIMUM_ORAN"));//(iMap.getBigDecimal("ALT_KREDI_TIPI"));
				// /birSaticiLimitTx.setGarantorBelgeTip(iMap.getString (tableName_limit, i, "GARANTOR_BELGE_TIPI"));//(iMap.getString("KANAL_KODU"));
				// /birSaticiLimitTx.setGarantorMaxOran(iMap.getBigDecimal(tableName_limit, i,
				// "GARANTOR_MAKSIMUM_ORAN"));//(iMap.getString("DOVIZ_KODU"));
				// /birSaticiLimitTx.setIade(iMap.getString(tableName_limit, i, "IADE"));

				if (iMap.getBigDecimal(tableName_limit, i, "ORIJINAL_LIMIT_TUTAR") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "ORIJINAL_LIMIT_TUTAR");
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				// session.saveOrUpdate(birSaticiLimitTx);
				session.save(birSaticiLimitTx);
			}

			/*
			 * List<?> birSaticiTahsisAraclarTxList =
			 * session.createCriteria(BirSaticiTahsisAraclarTx.class)
			 * .add(Restrictions
			 * .eq("txNo",iMap.getBigDecimal("TRX_NO"))).list();
			 */
			tableName = "TASIT_LISTESI";

			list = session.createCriteria(BirSaticiTahsisAraclarTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : list) {
				BirSaticiTahsisAraclarTx birSaticiTahsisAraclarTx = (BirSaticiTahsisAraclarTx) name;
				session.delete(birSaticiTahsisAraclarTx);
			}
			session.flush();

			list = (List<?>) iMap.get(tableName);
			if (list != null) {
				stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al(?)}");
				for (int row = 0; row < list.size(); row++) {
					stmt.registerOutParameter(1, Types.NUMERIC);
					stmt.setString(2, "BIR_SATICI_TAHSIS_ARACLAR_TX");

					stmt.execute();

					BirSaticiTahsisAraclarTx birSaticiTahsisAraclarTx = new BirSaticiTahsisAraclarTx();
					birSaticiTahsisAraclarTx.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));
					birSaticiTahsisAraclarTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birSaticiTahsisAraclarTx.setId(stmt.getBigDecimal(1));
					birSaticiTahsisAraclarTx.setMarka(iMap.getString(tableName, row, "MARKA"));
					birSaticiTahsisAraclarTx.setModel(iMap.getString(tableName, row, "MODEL"));
					birSaticiTahsisAraclarTx.setYil(iMap.getBigDecimal(tableName, row, "YIL"));

					session.saveOrUpdate(birSaticiTahsisAraclarTx);
				}
				session.flush();
				GMServerDatasource.close(stmt);
			}
			tableName = "MARKA_LISTESI";

			list = session.createCriteria(BirSaticiTahsisMarkalarTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : list) {
				BirSaticiTahsisMarkalarTx birSaticiTahsisMarkalarTx = (BirSaticiTahsisMarkalarTx) name;
				session.delete(birSaticiTahsisMarkalarTx);
			}
			session.flush();

			list = (List<?>) iMap.get(tableName);

			if (list.size() != 0 && list != null) {
				for (int row = 0; row < list.size(); row++) {

					BirSaticiTahsisMarkalarTxId id = new BirSaticiTahsisMarkalarTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));
					if (iMap.getString(tableName, row, "MARKA") == null || iMap.getString(tableName, row, "MARKA").equals("")) {
						stmt = conn.prepareCall("{call pkg_hata.hata_yaz(330,true,'MARKA')}");
						stmt.execute();
					}
					else
						id.setMarka(iMap.getString(tableName, row, "MARKA"));

					BirSaticiTahsisMarkalarTx birSaticiTahsisMarkalarTx = new BirSaticiTahsisMarkalarTx();
					birSaticiTahsisMarkalarTx.setBayilikSuresi(iMap.getBigDecimal(tableName, row, "BAYILIK_SURESI"));
					birSaticiTahsisMarkalarTx.setId(id);
					birSaticiTahsisMarkalarTx.setOrtAylikSatisAdet(iMap.getBigDecimal(tableName, row, "ORT_AYLIK_SATIS_ADET"));
					birSaticiTahsisMarkalarTx.setOrtAylikSatisTutar(iMap.getBigDecimal(tableName, row, "ORT_AYLIK_SATIS_TUTAR"));
					birSaticiTahsisMarkalarTx.setPesin(iMap.getBigDecimal(tableName, row, "PESIN"));
					birSaticiTahsisMarkalarTx.setSenet(iMap.getBigDecimal(tableName, row, "SENET"));
					birSaticiTahsisMarkalarTx.setKart(iMap.getBigDecimal(tableName, row, "KART"));
					birSaticiTahsisMarkalarTx.setYetkiliBayi(iMap.getString(tableName, row, "YETKILI_BAYI"));
					birSaticiTahsisMarkalarTx.setKredili(iMap.getBigDecimal(tableName, row, "KREDILI"));
					birSaticiTahsisMarkalarTx.setTeslimSure(iMap.getBigDecimal(tableName, row, "TESLIM_SURE"));

					session.saveOrUpdate(birSaticiTahsisMarkalarTx);
				}
			}
			else {
				if (!iMap.getBoolean("DISTRIBUTOR_MU")) {
					stmt = conn.prepareCall("{call pkg_hata.hata_yaz(330,true,'MARKA BILGILERI')}");
					stmt.execute();
					GMServerDatasource.close(stmt);
				}
			}

			List<?> listCalisanlar = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayCalisanlar = listCalisanlar.toArray();
			for (Object element : arrayCalisanlar) {
				listCalisanlar.remove(element);
				session.delete(element);

			}
			session.flush();

			List<?> calisanlarList = (List<?>) iMap.get("CALISANLAR");
			tableName = "CALISANLAR";
			for (int i = 0; i < calisanlarList.size(); i++) {

				BirSaticiCalisanTx birSaticiCalisanTx = new BirSaticiCalisanTx();

				BirSaticiCalisanTxId id = new BirSaticiCalisanTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));

				HashMap<String, Object> xMap = new HashMap<String, Object>();
				xMap.put("TABLE_NAME", "BIR_SATICI_CALISAN");

				if (iMap.get(tableName, i, "KOD") == null || iMap.get(tableName, i, "KOD").equals(""))
					id.setKod((BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", xMap).get("ID"));
				else
					id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
				BigDecimal musteriNo = iMap.getBigDecimal(tableName, i, "MUSTERI_NO");

				if (iMap.getBoolean(tableName, i, "YENI_MUSTERI_MI")) {
					iMap.put("CALISAN_ROW", i);
					musteriNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRN3161_KONTAKT_CALISAN", iMap).get("MUSTERI_NO").toString());
				}

				birSaticiCalisanTx.setId(id);
				birSaticiCalisanTx.setSaticiKod(iMap.getBigDecimal("SATICI_NO"));
				birSaticiCalisanTx.setMusteriNo(musteriNo);
				birSaticiCalisanTx.setTcKimlikNo(iMap.getString(tableName, i, "TCK_NO"));
				birSaticiCalisanTx.setAdi(iMap.getString(tableName, i, "ADI"));
				birSaticiCalisanTx.setIkinciAd(iMap.getString(tableName, i, "IKINCI_ADI"));
				birSaticiCalisanTx.setSoyadi(iMap.getString(tableName, i, "SOYADI"));
				birSaticiCalisanTx.setUyrukKod(iMap.getString(tableName, i, "UYRUK"));
				birSaticiCalisanTx.setDogumTarihi(iMap.getDate(tableName, i, "DOGUM_TARIHI"));
				birSaticiCalisanTx.setDogumYeri(iMap.getString(tableName, i, "DOGUM_YERI"));
				birSaticiCalisanTx.setBabaAdi(iMap.getString(tableName, i, "BABA_ADI"));
				birSaticiCalisanTx.setCepAlanKod(iMap.getString(tableName, i, "CEP_TEL_ALAN"));
				birSaticiCalisanTx.setCepTelNo(iMap.getString(tableName, i, "CEP_TEL"));
				String calisanEmailName = iMap.getString(tableName, i, "EPOSTA_NAME");
				String calisanEmailNet = iMap.getString(tableName, i, "EPOSTA_NET");
				if (!"".equals(calisanEmailName) || !"".equals(calisanEmailNet))
					birSaticiCalisanTx.setEposta(calisanEmailName + "@" + calisanEmailNet);
				else
					birSaticiCalisanTx.setEposta("");
				birSaticiCalisanTx.setOrtakEh(iMap.getString(tableName, i, "ORTAK_MI"));
				birSaticiCalisanTx.setOrtaklikPayi(iMap.getBigDecimal(tableName, i, "ORTAKLIK_PAYI"));
				birSaticiCalisanTx.setIseBaslamaTar(iMap.getDate(tableName, i, "ISE_BASLAMA_TARIHI"));
				birSaticiCalisanTx.setPozisyonKod(iMap.getString(tableName, i, "POZISYONU"));
				birSaticiCalisanTx.setTuttuguTakimKod(iMap.getString(tableName, i, "TUTTUGU_TAKIM"));
				birSaticiCalisanTx.setHobiKod(iMap.getString(tableName, i, "HOBILERI"));
				birSaticiCalisanTx.setCalStatuKod(iMap.getString(tableName, i, "CALISAN_STATUSU"));
				birSaticiCalisanTx.setCalKismiKapanmaNedenKod(iMap.getString(tableName, i, "KAPANMA_NEDENI"));

				/*
				 * birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName,
				 * i, "YETKI_SEVIYESI"));
				 */
				String bayiStatu = iMap.getString("BAYI_STATU");
				String ilkBayiStatu = iMap.getString("ILK_BAYI_STATU");
				if ( ilkBayiStatu != null && ((String) nvl(bayiStatu, "")).compareTo((String) nvl(ilkBayiStatu, "")) != 0) {
					if ("K".compareTo((String) nvl(iMap.getString("BAYI_STATU"), "")) == 0) {
						if ("K".compareTo((String) nvl(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"), "")) != 0) {
							birSaticiCalisanTx.setYetkiGirisKod("K");
							birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
							birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"));
							birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));
						}
						else {
							birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "ONCEKI_YETKI_SEVIYESI"));
							birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));
							birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "ONCEKI_YETKI_SEVIYESI"));
							birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR"));
						}
					}
					else {
						if (iMap.getString(tableName, i, "YETKI_SEVIYESI") != null && iMap.getString(tableName, i, "YETKI_SEVIYESI").compareTo((String) nvl(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"), "")) != 0) {
							birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
							birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
							birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"));
							birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));

						}
						else if (iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI") != null && iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI").compareTo((String) nvl(iMap.getString(tableName, i, "YETKI_SEVIYESI"), "")) != 0) {
							birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
							birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
							birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"));
							birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));

						}
						else if (iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI") == null && iMap.getString(tableName, i, "YETKI_SEVIYESI") == null || iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI").compareTo((String) nvl(iMap.getString(tableName, i, "YETKI_SEVIYESI"), "")) == 0) {
							birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "ONCEKI_YETKI_SEVIYESI"));
							birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));
							birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
							birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR"));
							birSaticiCalisanTx.setCalStatuKod("A");
						}
					}
				}
				else {
					birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
					birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));
					birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName, i, "GIZLI_YETKI_SEVIYESI"));
					birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName, i, "YETKI_SEVIYESI_GUNCELLEME_TAR"));
				}
				birSaticiCalisanTx.setDigerBankaKod(iMap.getString(tableName, i, "BANKA_KOD"));
				birSaticiCalisanTx.setDigerSubeKod(iMap.getString(tableName, i, "SUBE_KOD"));
				birSaticiCalisanTx.setDigerHesapNo(iMap.getString(tableName, i, "HESAP_A"));
				birSaticiCalisanTx.setHesapNo(iMap.getBigDecimal(tableName, i, "MUSTERI_HESAP_NO"));

				session.save(birSaticiCalisanTx);
				session.flush();
			}

			session.flush();

			if (iMap.getBoolean("IS_FROM_SCREEN")) {
				GMMap oMap = new GMMap();
				GMServerDatasource.close(stmt);

				stmt = conn.prepareCall("{?=call pkg_trn3162.portfoy_kod_kontrolu(?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.execute();

				oMap.put("MESSAGE", stmt.getString(1) == null ? "" : stmt.getString(1).trim());
				return oMap;
			}
			else {
				iMap.put("TRX_NAME", "3162");
				return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
		}
		catch (org.hibernate.NonUniqueObjectException nuoe) {

			iMap.put("HATA_NO", new BigDecimal(716));
			return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(pstmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	private static <T, T1, T2> T2 nvl(T a, T1 b) {
		if (a instanceof String) {
			return (T2) (StringUtils.isBlank((String) a) ? b : a);
		}
		return (T2) (a == null ? b : a);
	}

	@GraymoundService("BNSPR_TRN3162_GET_DEFAULT")
	public static GMMap getDefaultTRN3162(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call pkg_trn3162.get_default_tahsis(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put("DISTRIBUTOR_DURUM", rSet.getObject("DISTRIBUTOR_DURUM"));
				oMap.put("BLOKAJ_ORAN", rSet.getObject("BLOKAJ_ORAN"));
				oMap.put("CALISMA_ESAS", rSet.getObject("CALISMA_ESAS"));
				oMap.put("GARANTOR_GORUNSUN_EH", rSet.getObject("GARANTOR_GORUNSUN_EH"));
				oMap.put("FOTO_CEKIM_EH", rSet.getObject("FOTO_CEKIM_EH"));
				oMap.put("BARKOD_ZARF_EH", rSet.getObject("BARKOD_ZARF_EH"));
				oMap.put("GPS_TAKIP_EH", rSet.getObject("GPS_TAKIP_EH"));
				oMap.put("BILGI_FORMU_EH", rSet.getObject("BILGI_FORMU_EH"));
				oMap.put("BELGE_TESLIM_EH", rSet.getObject("BELGE_TESLIM_EH"));
				oMap.put("BEKLENEN_NPL", rSet.getObject("BEKLENEN_NPL"));
				oMap.put("OTP_KONTROL_EH", rSet.getObject("OTP_KONTROL_EH"));
				oMap.put("ISTIHBARAT_FIRMA_GORUS", rSet.getObject("ISTIHBARAT_FIRMA_GORUS"));
				oMap.put("BEKLENEN_NPL", rSet.getObject("BEKLENEN_NPL"));
				oMap.put("ERKEN_BELGE_ALIMI_EH", rSet.getObject("ERKEN_BELGE_ALIMI_EH"));
			}
			stmt = conn.prepareCall("{?=call PKG_TRN3162.Get_default_mal(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();
			String tableName = "URUN_HIZMET_TABLE";
			int row = 0;
			int j = 0;
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put(tableName, row, "UST_GRUP_NO", rSet.getObject("MALNO"));
				GMMap tMap = new GMMap();
				stmt2 = conn.prepareCall("{?=call PKG_TRN3162.get_default_mal_detay(?,?)}");
				stmt2.registerOutParameter(1, -10);
				stmt2.setBigDecimal(2, iMap.getBigDecimal("SATICI_NO"));
				stmt2.setBigDecimal(3, oMap.getBigDecimal(tableName, row, "UST_GRUP_NO"));
				stmt2.execute();
				j = 0;
				rSet2 = (ResultSet) stmt2.getObject(1);
				while (rSet2.next()) {
					tMap.put("DETAY_TABLE", j, "ALT_URUN", rSet2.getObject("MALNO"));
					j++;
				}
				oMap.put(tableName, row, "URUN_ALT_GRUP_DATA", tMap.get("DETAY_TABLE"));
				oMap.put(tableName, row, "URUN_UST_GRUP", rSet.getObject("MAL_AD"));
				oMap.put(tableName, row, "BAYI_URUN_KOD", rSet.getObject("TIP"));
				oMap.put(tableName, row, "BAYI_URUN_TIP", rSet.getObject("TIP_AD"));
				oMap.put(tableName, row, "URUN_UST_GRUP_TIP", rSet.getObject("UST_GRUP_TIP"));
				oMap.put(tableName, row, "URUN_KALITE", rSet.getObject("KALITE"));
				oMap.put(tableName, row, "TESLIMAT_SURESI", rSet.getObject("TESLIM_SURE"));
				oMap.put(tableName, row, "URUN_TESLIMAT_YER", rSet.getObject("URUN_TESLIM_YER"));
				oMap.put(tableName, row, "HIZMET_TESLIM_YER", rSet.getObject("HIZMET_TESLIM_YER"));
				oMap.put(tableName, row, "URUN_2EL_DEGER", rSet.getObject("DEGER2EL"));
				oMap.put(tableName, row, "URUN_SKOR", rSet.getObject("SKOR"));
				oMap.put(tableName, row, "URUN_SKOR_TAHSIS", rSet.getObject("SKOR_TAHSIS"));
				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_SATICI_INFO")
	public static GMMap getSaticiInfoTRN3162(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSetMSet = null;
		ResultSet rSet2 = null;

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			GMMap xMap = new GMMap();

			BirSaticiTahsis birSaticiTahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", iMap.getBigDecimal("SATICI_NO"))).uniqueResult();
			if (birSaticiTahsis != null) {
				// oMap.put("SATICI_AD", LovHelper.diLov(birSaticiTahsis.getKod(), "3162/LOV_SATICI", "SATICI_ADI"));
				oMap.put("BAYI_SSK_ISYERI_KODU", birSaticiTahsis.getBayiSskIsyeriKod());
				oMap.put("TICARET_SICIL_NO", birSaticiTahsis.getTicaretSicilNo());
				oMap.put("TOPLAM_CALISAN_SAYISI", birSaticiTahsis.getTopCalisanSayi());
				oMap.put("ISYERI_MULKIYETI", birSaticiTahsis.getIsyeriMulkiyetKod());
				oMap.put("KIRA_BEDELI", birSaticiTahsis.getKiraBedeli());
				oMap.put("ISYERI_KONUMU", birSaticiTahsis.getIsyeriKonumKod());
				oMap.put("YUZOLCUMU", birSaticiTahsis.getIsyeriYuzolcumu());
				if ("E".equals(birSaticiTahsis.getAyniSifreBasvuruEh())) {
					oMap.put("AYNI_SIFRE_BASVURU", true);
				}
				else {
					oMap.put("AYNI_SIFRE_BASVURU", false);
				}
				oMap.put("EK_ISYERI_VAR_MI", birSaticiTahsis.getEkIsyeriVar());
				oMap.put("ERKEN_BELGE_ALABILIR_MI_EH", birSaticiTahsis.getErkenBelgeAlimiEh());
				if (birSaticiTahsis.getEkIsyeriVar().equals("E"))
					oMap.put("EK_ISYERI_ADI", birSaticiTahsis.getEkIsyeriAdi());
				oMap.put("BAYI_STATU", birSaticiTahsis.getBayiStatuKod());
				oMap.put("BAYI_CALISMA_SEKLI", birSaticiTahsis.getCalismaSekliKod());
				oMap.put("BAYI_RISKI", birSaticiTahsis.getBayiRiskKod());
				oMap.put("AYLIK_LIMIT", birSaticiTahsis.getBayiAylikLimit());
				oMap.put("GUNLUK_LIMIT", birSaticiTahsis.getBayiGunlukLimit());
				oMap.put("AYLIK_BASVURU_LIMIT", birSaticiTahsis.getAylikBasvuruLimit());
				if (StringUtils.isNotBlank(birSaticiTahsis.getBayiStatuKod())) {
					if (birSaticiTahsis.getBayiStatuKod().equals("KK")) {
						oMap.put("KISMI_KAPANMA_NEDENI", birSaticiTahsis.getKismiKapanmaNedenKod());
						oMap.put("KISMI_KAPANMA_STATU", birSaticiTahsis.getKismiKapanmaStatuKod());
					}
					else if (birSaticiTahsis.getBayiStatuKod().equals("K"))
						oMap.put("KAPANMA_NEDENI", birSaticiTahsis.getKapanmaNedenKod());
				}
				oMap.put("ORJINAL_EVRAK_GON_SURESI", birSaticiTahsis.getOrjEvrakGonSure());
				oMap.put("BASVURU_GIREBILIR_EH",  GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getBasvuruGirilebilirEh()));
				oMap.put("MUSTERI_PORTFOYU", birSaticiTahsis.getMusteriPortfoyKod());
				oMap.put("CAL_FINANS1_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans1Eh()));
				oMap.put("CAL_FINANS2_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans2Eh()));
				oMap.put("CAL_FINANS3_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans3Eh()));
				oMap.put("CAL_FINANS3_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans3Eh()));
				oMap.put("CAL_FINANS4_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans4Eh()));
				if (birSaticiTahsis.getCalFinansDiger() != null) {
					oMap.put("CAL_FINANS_DIGER_ADI", birSaticiTahsis.getCalFinansDiger());
					oMap.put("CAL_FINANS_DIGER", true);
				}
				oMap.put("DAGITICI_FIRMA_TEMINAT_CINSI", birSaticiTahsis.getDagiticiFirmaTeminatKod());
				oMap.put("TEMINAT_TUTARI", birSaticiTahsis.getTeminatTutar());
				oMap.put("YATIRIM_PLANI_VAR_MI", birSaticiTahsis.getYatirimPlani());
				if (birSaticiTahsis.getYatirimPlani().equals("VAR"))
					oMap.put("YATIRIM_PLANI_ACIKLAMA", birSaticiTahsis.getYatirimPlaniAciklama());
				oMap.put("ORTAK_SEKTOR_TECRUBESI", birSaticiTahsis.getOrtakSektorTecrubesi());
				oMap.put("BEKLENEN_KREDI_HACMI", birSaticiTahsis.getBeklenenKrediHacmi());
				oMap.put("GMENKUL_ARSA", birSaticiTahsis.getGayrimenkulAdetArsa());
				oMap.put("GMENKUL_DUKKAN", birSaticiTahsis.getGayrimenkulAdetDukkan());
				oMap.put("GMENKUL_EV", birSaticiTahsis.getGayrimenkulAdetEv());
				oMap.put("LIMIT_MERKEZ_BAGIMSIZ_MI", birSaticiTahsis.getLimitMerkezBagimsizEh());
				oMap.put("TASIT_SAYI", birSaticiTahsis.getTasitSayi());
				oMap.put("BAYI_SEGMENT", birSaticiTahsis.getBayiSegmentKod());
				oMap.put("SUBE_SAYISI", birSaticiTahsis.getSubeSayisi());
				oMap.put("ANA_SATIS_KANAL", birSaticiTahsis.getAnaSatisKanal());
				oMap.put("YILLIK_CIRO", birSaticiTahsis.getYillikCiro());
				oMap.put("ANA_CIRO_DEGISIM", birSaticiTahsis.getAnaCiroDegisim());
				oMap.put("YATIRIM_BUYUKLUGU", birSaticiTahsis.getYatirimBuyukluk());

				if (birSaticiTahsis.getAyniAdresteFaaliyetSuresi() != null) {
					String ayniAdresteFaaliyetSuresiYil = birSaticiTahsis.getAyniAdresteFaaliyetSuresi().substring(0, 2);
					if (ayniAdresteFaaliyetSuresiYil.charAt(0) == '0')
						ayniAdresteFaaliyetSuresiYil = ayniAdresteFaaliyetSuresiYil.substring(1);
					String ayniAdresteFaaliyetSuresiAy = birSaticiTahsis.getAyniAdresteFaaliyetSuresi().substring(2, 4);
					if (ayniAdresteFaaliyetSuresiAy.charAt(0) == '0')
						ayniAdresteFaaliyetSuresiAy = ayniAdresteFaaliyetSuresiAy.substring(1);
					oMap.put("AYNI_ISYERINDE_FAALIYET_SURESI_YIL", ayniAdresteFaaliyetSuresiYil);
					oMap.put("AYNI_ISYERINDE_FAALIYET_SURESI_AY", ayniAdresteFaaliyetSuresiAy);
				}
				if (iMap.getBoolean("DISTRIBUTOR_MU")) {
					oMap.put("DISTRIBUTOR_DURUM_DST", birSaticiTahsis.getDistributorDurum());
					oMap.put("BEKLENEN_NPL_DST", birSaticiTahsis.getBeklenenNpl());
					oMap.put("CALISMA_ESAS_DST", birSaticiTahsis.getCalismaEsas());
					oMap.put("BLOKAJ_ORAN_DST", birSaticiTahsis.getBlokajOran());
					oMap.put("GARANTOR_GORUNSUN_EH_DST", birSaticiTahsis.getGarantorGorunsunEh());
					oMap.put("FOTO_CEKIM_EH_DST", birSaticiTahsis.getFotoCekimEh());
					oMap.put("BARKOD_ZARF_EH_DST", birSaticiTahsis.getBarkodZarfEh());
					oMap.put("GPS_TAKIP_EH_DST", birSaticiTahsis.getGpsTakipEh());
					oMap.put("BILGI_FORMU_EH_DST", birSaticiTahsis.getBilgiFormuEh());
					oMap.put("BELGE_TESLIM_EH_DST", birSaticiTahsis.getBelgeTeslimEh());
					oMap.put("OTP_KONTROL_EH_DST", birSaticiTahsis.getOtpKontrolEh());
					oMap.put("ERKEN_BELGE_ALABILIR_MI_EH_DST", birSaticiTahsis.getErkenBelgeAlimiEh());
				}
				else {
					oMap.put("DISTRIBUTOR_DURUM", birSaticiTahsis.getDistributorDurum());
					oMap.put("BEKLENEN_NPL", birSaticiTahsis.getBeklenenNpl());
					oMap.put("CALISMA_ESAS", birSaticiTahsis.getCalismaEsas());
					oMap.put("BLOKAJ_ORAN", birSaticiTahsis.getBlokajOran());
					oMap.put("GARANTOR_GORUNSUN_EH", birSaticiTahsis.getGarantorGorunsunEh());
					oMap.put("FOTO_CEKIM_EH", birSaticiTahsis.getFotoCekimEh());
					oMap.put("BARKOD_ZARF_EH", birSaticiTahsis.getBarkodZarfEh());
					oMap.put("GPS_TAKIP_EH", birSaticiTahsis.getGpsTakipEh());
					oMap.put("BILGI_FORMU_EH", birSaticiTahsis.getBilgiFormuEh());
					oMap.put("BELGE_TESLIM_EH", birSaticiTahsis.getBelgeTeslimEh());
					oMap.put("OTP_KONTROL_EH", birSaticiTahsis.getOtpKontrolEh());
					oMap.put("ERKEN_BELGE_ALABILIR_MI_EH", birSaticiTahsis.getErkenBelgeAlimiEh());
				}

				oMap.put("KATEGORI_SKOR", birSaticiTahsis.getKategoriSkor());
				oMap.put("KATEGORI_SKOR_TAHSIS", birSaticiTahsis.getKategoriSkorTahsis());

				oMap.put("KURUMSAL_GARANTOR_LIMIT", birSaticiTahsis.getKurumsalGarantorLimit());
				oMap.put("PERAKENDE_REZERV_LIMIT", birSaticiTahsis.getPerakendeRezervLimit());

				oMap.put("MIN_BLOKE_TUTAR", birSaticiTahsis.getMinBlokeTutar());
				oMap.put("BLOKAJ_NEDEN", birSaticiTahsis.getBlokajNeden());
				oMap.put("UST_NPL_ORAN", birSaticiTahsis.getUstNplOran());
				oMap.put("MAX_KULL_LIMIT", birSaticiTahsis.getMaxKullLimit());

				oMap.put("BLOKAJ_NEDEN", birSaticiTahsis.getBlokajNeden());
				oMap.put("BLOKAJ_KREDI_TIP", birSaticiTahsis.getBlokajKrediTip());
				oMap.put("BLOKAJ_COZUM_ZAMAN", birSaticiTahsis.getBlokajCozumZaman());
				oMap.put("MAX_BLOKE_TUTAR", birSaticiTahsis.getMaxBlokeTutar());
				oMap.put("ISTIHBARAT_FIRMA_GORUS", birSaticiTahsis.getIstihbaratFirmaGorus());
				oMap.put("BLOKE_HESAP", birSaticiTahsis.getBlokeHesap());
				oMap.put("BAYI_BEKL_KREDI_HACMI", birSaticiTahsis.getBayiBeklKrediHacmi());

				oMap.put("DST_PAZAR_PAY", birSaticiTahsis.getDstPazarPay());
				oMap.put("DST_BORC_ORAN", birSaticiTahsis.getDstBorcOran());
				oMap.put("DST_BAYI_ORAN", birSaticiTahsis.getDstBayiOran());
				oMap.put("DST_KITLE", birSaticiTahsis.getDstKitle());
				oMap.put("DST_CIRO", birSaticiTahsis.getDstCiro());
				oMap.put("DST_CIRO_DEGISIM", birSaticiTahsis.getDstCiroDegisim());
				oMap.put("DST_SENET_AGIRLIK", birSaticiTahsis.getDstSenetAgirlik());
				oMap.put("DST_YATIRIM_BUYUKLUK", birSaticiTahsis.getDstYatirimBuyukluk());
				oMap.put("DST_KAZANIM_KANAL", birSaticiTahsis.getDstKazanimKanal());
				oMap.put("VALOR_BLOKE_HESAP", birSaticiTahsis.getValorBlokeHesap());
				String ubeDistEH = birSaticiTahsis.getUbeDistributorEh();
				if (ubeDistEH == null || "null".equals(ubeDistEH) || ubeDistEH.isEmpty()) {
					ubeDistEH = "H";
				}
				oMap.put("DST_WEB_BAYI_IZIN_EH", "E".equals(ubeDistEH));
				oMap.put("DST_WEB_GORUNTU_ISIM", birSaticiTahsis.getUbeDistributorUnvan());
			}
			else {
				oMap.put("DST_WEB_BAYI_IZIN_EH", false);
				oMap.put("BASVURU_GIREBILIR_EH", false);
			}

			BirSatici birSatici = (BirSatici) session.createCriteria(BirSatici.class).add(Restrictions.eq("kod", iMap.getBigDecimal("SATICI_NO"))).uniqueResult();
			oMap.put("MUSTERI_NO", birSatici.getMusteriNo());
			oMap.put("DI_MUSTERI_NO", LovHelper.diLov(birSatici.getMusteriNo(), "3161/LOV_TUZEL_MUSTERI", "UNVAN"));
			oMap.put("HESAP_NO", birSatici.getHesapNo());
			oMap.put("DI_HESAP_NO", LovHelper.diLov(birSatici.getHesapNo(), birSatici.getMusteriNo(), "3161/LOV_VDSZ_HESAP", "KISA_ISIM"));
			oMap.put("ONEM_DERECESI", birSatici.getOnemDereceKod());

			List<?> saticiTahsisFaaliyetList = (List<?>) iMap.get("FAALIYET_KONULARI");
			String tableName = "FAALIYET_KONULARI";
			int row = 0;
			for (int i = 0; i < saticiTahsisFaaliyetList.size(); i++) {
				BirSaticiTahsisFaaliyet birSaticiTahsisFaaliyet = (BirSaticiTahsisFaaliyet) session.createCriteria(BirSaticiTahsisFaaliyet.class).add(Restrictions.eq("id.saticiKod", iMap.getBigDecimal("SATICI_NO"))).add(Restrictions.eq("id.faaliyetKodu", iMap.getString(tableName, i, "FAALIYET_KODU"))).add(Restrictions.eq("id.tur", "X")).uniqueResult();

				if (birSaticiTahsisFaaliyet != null)
					oMap.put(tableName, row, "SEC", true);
				oMap.put(tableName, row, "FAALIYET_KODU", iMap.getString(tableName, row, "FAALIYET_KODU"));
				oMap.put(tableName, row, "FAALIYET_KONUSU", iMap.getString(tableName, row, "FAALIYET_KONUSU"));
				row++;
			}

			// if(birSaticiTahsis.getEkIsyeriVar().equals("E"))
			{
				List<?> saticiTahsisEkIsyeriFaaliyetList = (List<?>) iMap.get("EK_ISYERI_FAALIYET_KONULARI");
				tableName = "EK_ISYERI_FAALIYET_KONULARI";
				row = 0;
				for (int i = 0; i < saticiTahsisEkIsyeriFaaliyetList.size(); i++) {
					BirSaticiTahsisFaaliyet birSaticiTahsisFaaliyet = (BirSaticiTahsisFaaliyet) session.createCriteria(BirSaticiTahsisFaaliyet.class).add(Restrictions.eq("id.saticiKod", iMap.getBigDecimal("SATICI_NO"))).add(Restrictions.eq("id.faaliyetKodu", iMap.getString(tableName, i, "FAALIYET_KODU"))).add(Restrictions.eq("id.tur", "EK")).uniqueResult();

					if (birSaticiTahsisFaaliyet != null)
						oMap.put(tableName, row, "SEC", true);
					oMap.put(tableName, row, "FAALIYET_KODU", iMap.getString(tableName, row, "FAALIYET_KODU"));
					oMap.put(tableName, row, "FAALIYET_KONUSU", iMap.getString(tableName, row, "FAALIYET_KONUSU"));
					row++;
				}
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3162.Get_Ekisyeri_List(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "ILISKILI_BAYI"));
			stmt.clearParameters();
			GMServerDatasource.close(rSet);
			stmt.close();
			// conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3162.Get_Vehicle_List(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();

			rSetMSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSetMSet, "TASIT_LISTESI"));
			stmt.clearParameters();
			GMServerDatasource.close(rSetMSet);
			stmt.close();

			stmt = conn.prepareCall("{? = call PKG_TRN3162.Get_Marka_List(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();

			rSetMSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSetMSet, "MARKA_LISTESI"));
			GMServerDatasource.close(rSetMSet);
			stmt.close();

			stmt = conn.prepareCall("{?=call PKG_TRN3162.Get_Mal_List(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();
			tableName = "URUN_HIZMET_TABLE";
			row = 0;
			int j = 0;
			rSet = (ResultSet) stmt.getObject(1);

			while (rSet.next()) {
				oMap.put(tableName, row, "UST_GRUP_NO", rSet.getObject("MALNO"));
				GMMap tMap = new GMMap();
				stmt2 = conn.prepareCall("{?=call PKG_TRN3162.Get_Mal_Detay_List(?,?)}");
				stmt2.registerOutParameter(1, -10);
				stmt2.setBigDecimal(2, iMap.getBigDecimal("SATICI_NO"));
				stmt2.setBigDecimal(3, oMap.getBigDecimal(tableName, row, "UST_GRUP_NO"));
				stmt2.execute();
				j = 0;
				rSet2 = (ResultSet) stmt2.getObject(1);
				while (rSet2.next()) {
					tMap.put("DETAY_TABLE", j, "ALT_URUN", rSet2.getObject("MALNO"));
					j++;
				}
				stmt2.close();

				oMap.put(tableName, row, "URUN_ALT_GRUP_DATA", tMap.get("DETAY_TABLE"));
				oMap.put(tableName, row, "URUN_UST_GRUP", rSet.getObject("MAL_AD"));
				oMap.put(tableName, row, "BAYI_URUN_KOD", rSet.getObject("TIP"));
				oMap.put(tableName, row, "BAYI_URUN_TIP", rSet.getObject("TIP_AD"));
				oMap.put(tableName, row, "URUN_UST_GRUP_TIP", rSet.getObject("UST_GRUP_TIP"));
				oMap.put(tableName, row, "URUN_KALITE", rSet.getObject("KALITE"));
				oMap.put(tableName, row, "TESLIMAT_SURESI", rSet.getObject("TESLIM_SURE"));
				oMap.put(tableName, row, "URUN_TESLIMAT_YER", rSet.getObject("URUN_TESLIM_YER"));
				oMap.put(tableName, row, "HIZMET_TESLIM_YER", rSet.getObject("HIZMET_TESLIM_YER"));
				oMap.put(tableName, row, "URUN_2EL_DEGER", rSet.getObject("DEGER2EL"));
				oMap.put(tableName, row, "URUN_SKOR", rSet.getObject("SKOR"));
				oMap.put(tableName, row, "URUN_SKOR_TAHSIS", rSet.getObject("SKOR_TAHSIS"));
				row++;
			}

			List<?> calisanlarList = session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("birSatici.kod", iMap.getBigDecimal("SATICI_NO"))).add(Restrictions.eq("durum", "ONAY")).list(); // .add(Restrictions.eq("durum","ONAY"))
			tableName = "CALISANLAR";
			row = 0;

			for (int i = 0; i < calisanlarList.size(); i++) {

				BirSaticiCalisan birSaticiCalisan = (BirSaticiCalisan) calisanlarList.get(i);
				oMap.put(tableName, row, "KOD", birSaticiCalisan.getKod());
				oMap.put(tableName, row, "MUSTERI_NO", birSaticiCalisan.getMusteriNo());

				ArrayList<Object> listPar = new ArrayList<Object>();
				listPar.add(birSaticiCalisan.getMusteriNo());
				HashMap<?, ?> gercekMusteri = LovHelper.diLovAll(birSaticiCalisan.getMusteriNo(), "3161/LOV_GERCEK_MUSTERI_GET_INFO", listPar);
				if (gercekMusteri != null) {
					oMap.put(tableName, row, "DI_MUSTERI_NO", (String) gercekMusteri.get("UNVAN"));
					oMap.put(tableName, row, "TCK_NO", (String) gercekMusteri.get("TC_KIMLIK_NO"));
					oMap.put(tableName, row, "ADI", (String) gercekMusteri.get("ADI"));
					oMap.put(tableName, row, "IKINCI_ADI", (String) gercekMusteri.get("IKINCI_ADI"));
					oMap.put(tableName, row, "SOYADI", (String) gercekMusteri.get("SOYADI"));
					oMap.put(tableName, row, "UYRUK", (String) gercekMusteri.get("UYRUK_KOD"));
					oMap.put(tableName, row, "DOGUM_TARIHI", (String) gercekMusteri.get("DOGUM_TARIHI"));
					oMap.put(tableName, row, "DOGUM_YERI", (String) gercekMusteri.get("DOGUM_YERI"));
					oMap.put(tableName, row, "BABA_ADI", (String) gercekMusteri.get("BABA_ADI"));
					oMap.put(tableName, row, "ANNE_ADI", (String) gercekMusteri.get("ANNE_ADI"));
					oMap.put(tableName, row, "CEP_TEL_ALAN", (String) gercekMusteri.get("GSM_ALAN"));
					oMap.put(tableName, row, "CEP_TEL", (String) gercekMusteri.get("GSM"));
					xMap = new GMMap();
					xMap.put("EMAIL_1", (String) gercekMusteri.get("EMAIL_KISISEL"));
				}

				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS", xMap));
				oMap.put(tableName, row, "EPOSTA_NAME", oMap.get("EMAIL_11"));
				oMap.put(tableName, row, "EPOSTA_NET", oMap.get("EMAIL_12"));

				oMap.put(tableName, row, "ORTAK_MI", birSaticiCalisan.getOrtakEh());
				oMap.put(tableName, row, "ORTAKLIK_PAYI", birSaticiCalisan.getOrtaklikPayi());
				oMap.put(tableName, row, "ISE_BASLAMA_TARIHI", birSaticiCalisan.getIseBaslamaTar());
				oMap.put(tableName, row, "POZISYONU", birSaticiCalisan.getPozisyonKod());
				oMap.put(tableName, row, "TUTTUGU_TAKIM", birSaticiCalisan.getTuttuguTakimKod());
				oMap.put(tableName, row, "HOBILERI", birSaticiCalisan.getHobiKod());
				oMap.put(tableName, row, "CALISAN_STATUSU", birSaticiCalisan.getCalStatuKod());
				oMap.put(tableName, row, "KAPANMA_NEDENI", birSaticiCalisan.getCalKismiKapanmaNedenKod());
				oMap.put(tableName, row, "YETKI_SEVIYESI", birSaticiCalisan.getYetkiGirisKod());
				oMap.put(tableName, row, "YETKI_SEVIYESI_GUNCELLEME_TAR", birSaticiCalisan.getYetkiGirisKodGuncellemeTar());
				oMap.put(tableName, row, "ONCEKI_YETKI_SEVIYESI", birSaticiCalisan.getOncekiYetkiGirisKod());
				oMap.put(tableName, row, "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR", birSaticiCalisan.getOncekiYetkiGuncellemeTar());
				oMap.put(tableName, row, "GIZLI_YETKI_SEVIYESI", birSaticiCalisan.getYetkiGirisKod());
				oMap.put(tableName, row, "BANKA_KOD", birSaticiCalisan.getDigerBankaKod());
				oMap.put(tableName, row, "DI_BANKA_KOD", LovHelper.diLov(birSaticiCalisan.getDigerBankaKod(), "3161/LOV_BANKA", "BANKA_ADI"));
				oMap.put(tableName, row, "SUBE_KOD", birSaticiCalisan.getDigerSubeKod());
				oMap.put(tableName, row, "DI_SUBE_KOD", LovHelper.diLov(birSaticiCalisan.getDigerSubeKod(), birSaticiCalisan.getDigerBankaKod(), oMap.getString("IL_KOD"), "3161/LOV_BANKA_SUBE", "SUBE_ADI"));
				oMap.put(tableName, row, "HESAP_A", birSaticiCalisan.getDigerHesapNo());
				oMap.put(tableName, row, "MUSTERI_HESAP_NO", birSaticiCalisan.getHesapNo());
				oMap.put(tableName, row, "DI_MUSTERI_HESAP_NO", LovHelper.diLov(birSaticiCalisan.getHesapNo(), birSaticiCalisan.getMusteriNo(), "3161/LOV_VDSZ_HESAP", "KISA_ISIM"));
				oMap.put(tableName, row, "YENI_MUSTERI_MI", false);

				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSetMSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt2);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_INFO")
	public static GMMap getInfoTRN3162(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			setBirSaticiTahsisMap(iMap.getBigDecimal("TRX_NO"), oMap);

			String faaliyetKonulari = "FAALIYET_KONULARI";
			setFaaliyetKonulariTable(iMap.getBigDecimal("TRX_NO"), faaliyetKonulari, oMap.getBigDecimal("SATICI_NO"), (List<?>) iMap.get("FAALIYET_KONULARI"), oMap);

			String ekIsyeriFaaliyetKonulari = "EK_ISYERI_FAALIYET_KONULARI";
			// if(birSaticiTahsis.getEkIsyeriVar().equals("E")) --> if(oMap.getString("").equals("EK_ISYERI_VAR_MI"))
			{
				setEkIsyeriFaaliyetTable(iMap.getBigDecimal("TRX_NO"), ekIsyeriFaaliyetKonulari, oMap.getBigDecimal("SATICI_NO"), (List<?>) iMap.get("EK_ISYERI_FAALIYET_KONULARI"), oMap);
			}
			String urunHizmetTable = "URUN_HIZMET_TABLE";
			setUrunHizmetTable(iMap.getBigDecimal("TRX_NO"), urunHizmetTable, oMap);

			String ekIsyeriTable = "ILISKILI_BAYI";
			setEkIsyeriTable(iMap.getBigDecimal("TRX_NO"), ekIsyeriTable, oMap);

			String limitTable = "LIMIT_TABLO";
			setLimitTable(iMap.getBigDecimal("TRX_NO"), limitTable, oMap);

			String tasitTable = "TASIT_LISTESI";
			setTasitTable(iMap.getBigDecimal("TRX_NO"), tasitTable, oMap);

			String markaTable = "MARKA_LISTESI";
			setMarkaTable(iMap.getBigDecimal("TRX_NO"), markaTable, oMap);

			String calisanTable = "CALISANLAR";
			setCalisanTable(iMap.getBigDecimal("TRX_NO"), calisanTable, oMap);

			GMMap oldMap = new GMMap();

			// Renklendirme
			if ("ISLEM_GORUNTULE".equals(iMap.getString("ACTION"))) {
				GMMap i2Map = new GMMap();
				i2Map.put("TRX_NO", iMap.get("TRX_NO"));
				i2Map.put("SATICI_NO", oMap.get("SATICI_NO"));
				BigDecimal oldTxNo = GMServiceExecuter.call("BNSPR_TRN3162_GET_ONCEKI_TX_NO", i2Map).getBigDecimal("OLD_TRX_NO");
				if (null != iMap.getString("PARENT_SCREEN")) {
					oldTxNo = iMap.getBigDecimal("TRX_NO");
				}
				setBirSaticiTahsisMap(oldTxNo, oldMap);

				oMap.putAll(BeanSetProperties.mapDifference(oldMap, oMap));

				// Tablolar i�in renklendirme

				String oldFaaliyetKonulari = "OLD_FAALIYET_KONULARI";
				setFaaliyetKonulariTable(oldTxNo, oldFaaliyetKonulari, oldMap.getBigDecimal("SATICI_NO"), (List<?>) iMap.get("FAALIYET_KONULARI"), oMap);
				oMap.put("FAALIYET_KONULARI_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldFaaliyetKonulari), (ArrayList<?>) oMap.get(faaliyetKonulari), "FAALIYET_KODU").get("COLOR_DATA"));

				String oldEkIsyeriFaaliyetKonulari = "OLD_EK_ISYERI_FAALIYET_KONULARI";
				setEkIsyeriFaaliyetTable(oldTxNo, oldEkIsyeriFaaliyetKonulari, oldMap.getBigDecimal("SATICI_NO"), (List<?>) iMap.get("FAALIYET_KONULARI"), oMap);
				oMap.put("EK_ISYERI_FAALIYET_KONULARI_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldEkIsyeriFaaliyetKonulari), (ArrayList<?>) oMap.get(ekIsyeriFaaliyetKonulari), "FAALIYET_KODU").get("COLOR_DATA"));

				String oldUrunHizmetTable = "OLD_URUN_HIZMET_TABLE";
				setUrunHizmetTable(oldTxNo, oldUrunHizmetTable, oMap);
				oMap.put("URUN_HIZMET_TABLE_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldUrunHizmetTable), (ArrayList<?>) oMap.get(urunHizmetTable), "URUN_UST_GRUP").get("COLOR_DATA"));

				String oldEkIsyeriTable = "OLD_ILISKILI_BAYI";
				setEkIsyeriTable(oldTxNo, oldEkIsyeriTable, oMap);
				oMap.put("ILISKILI_BAYI_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldEkIsyeriTable), (ArrayList<?>) oMap.get(ekIsyeriTable), "SATICI_KOD").get("COLOR_DATA"));

				String oldLimitTable = "OLD_LIMIT_TABLO";
				setLimitTable(oldTxNo, oldLimitTable, oMap);

				String oldTasitTable = "OLD_TASIT_LISTESI";
				setTasitTable(oldTxNo, oldTasitTable, oMap);
				ArrayList<String> keyColumns = new ArrayList<String>();
				keyColumns.add("MARKA");
				keyColumns.add("MODEL");
				keyColumns.add("YIL");
				oMap.put("TASIT_LISTESI_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldTasitTable), (ArrayList<?>) oMap.get(tasitTable), keyColumns).get("COLOR_DATA"));

				String oldMarkaTable = "OLD_MARKA_LISTESI";
				setMarkaTable(oldTxNo, oldMarkaTable, oMap);
				oMap.put("MARKA_LISTESI_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldMarkaTable), (ArrayList<?>) oMap.get(markaTable), "MARKA").get("COLOR_DATA"));

				String oldCalisanTable = "OLD_CALISANLAR";
				setCalisanTable(oldTxNo, oldCalisanTable, oMap);
				oMap.put("CALISANLAR_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldCalisanTable), (ArrayList<?>) oMap.get(calisanTable), "KOD").get("COLOR_DATA"));
				GMMap tempMap = new GMMap();
				tempMap.put("SATICI_NO", oMap.get("SATICI_NO"));
				oMap.put("LIMIT_HAREKET_IZLEME", getLimitKullanimbilgileri(tempMap).get("LIMIT_HAREKET_IZLEME"));
				if (iMap.getInt("LIMIT") == 1) {

					oMap.put("LIMIT_TABLO", getRecordList(tempMap).get("LIMIT_TABLO"));
				}
				tempMap.put("LIMIT_TABLO", getRecordList(tempMap).get("LIMIT_TABLO"));
				int limitTabloIndex = 0;
				int kayitTabloIndex = 0;
				int oldTableIndex = 0;
				while (limitTabloIndex < oMap.getSize("LIMIT_TABLO")) {
					kayitTabloIndex = 0;
					oldTableIndex = 0;
					while (kayitTabloIndex < tempMap.getSize("LIMIT_TABLO")) {
						if (tempMap.getString("LIMIT_TABLO", kayitTabloIndex, "SATIC_LIMIT_TIP").equals(oMap.getString("LIMIT_TABLO", limitTabloIndex, "SATIC_LIMIT_TIP"))) {
							oMap.put("LIMIT_TABLO", limitTabloIndex, "KULLANILMIS_LIMIT", tempMap.get("LIMIT_TABLO", kayitTabloIndex, "KULLANILMIS_LIMIT"));
							oMap.put("LIMIT_TABLO", limitTabloIndex, "KULLANILABILIR_LIMIT", oMap.getBigDecimal("LIMIT_TABLO", kayitTabloIndex, "ORIJINAL_LIMIT_TUTAR").subtract(tempMap.getBigDecimal("LIMIT_TABLO", kayitTabloIndex, "KULLANILMIS_LIMIT")));
						}
						kayitTabloIndex++;
					}
					while (oldTableIndex < oMap.getSize("OLD_LIMIT_TABLO")) {
						if (tempMap.getString("LIMIT_TABLO", oldTableIndex, "SATIC_LIMIT_TIP").equals(oMap.getString("OLD_LIMIT_TABLO", limitTabloIndex, "SATIC_LIMIT_TIP"))) {
							oMap.put("OLD_LIMIT_TABLO", limitTabloIndex, "KULLANILMIS_LIMIT", tempMap.get("LIMIT_TABLO", oldTableIndex, "KULLANILMIS_LIMIT"));
							oMap.put("OLD_LIMIT_TABLO", limitTabloIndex, "KULLANILABILIR_LIMIT", oMap.getBigDecimal("OLD_LIMIT_TABLO", oldTableIndex, "ORIJINAL_LIMIT_TUTAR").subtract(tempMap.getBigDecimal("LIMIT_TABLO", oldTableIndex, "KULLANILMIS_LIMIT")));
						}
						oldTableIndex++;
					}
					limitTabloIndex++;
				}
				if (null != iMap.getString("PARENT_SCREEN")) {
					oMap.put("OLD_LIMIT_TABLO", oMap.get("LIMIT_TABLO"));
				}
				oMap.put("LIMIT_TABLO_COLOR_DATA", BeanSetProperties.tableDifference((ArrayList<?>) oMap.get("OLD_LIMIT_TABLO"), (ArrayList<?>) oMap.get("LIMIT_TABLO"), "SATIC_LIMIT_TIP").get("COLOR_DATA"));

			}

			// Renklendirme biti�
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static void setBirSaticiTahsisMap(BigDecimal txNo, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		String nuLL = null;
		BirSaticiTahsisTx birSaticiTahsis = (BirSaticiTahsisTx) session.createCriteria(BirSaticiTahsisTx.class).add(Restrictions.eq("txNo", txNo)).uniqueResult();
		if (birSaticiTahsis != null) {

			oMap.put("SATICI_NO", birSaticiTahsis.getKod());
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3162_GET_DISTRIBUTOR_MU", oMap));
			oMap.put("BAYI_SSK_ISYERI_KODU", birSaticiTahsis.getBayiSskIsyeriKod());
			oMap.put("TICARET_SICIL_NO", birSaticiTahsis.getTicaretSicilNo());
			oMap.put("TOPLAM_CALISAN_SAYISI", birSaticiTahsis.getTopCalisanSayi());
			oMap.put("ISYERI_MULKIYETI", birSaticiTahsis.getIsyeriMulkiyetKod());
			oMap.put("KIRA_BEDELI", birSaticiTahsis.getKiraBedeli());
			oMap.put("ISYERI_KONUMU", birSaticiTahsis.getIsyeriKonumKod());
			if ("E".equals(birSaticiTahsis.getAyniSifreBasvuruEh())) {
				oMap.put("AYNI_SIFRE_BASVURU", true);
			}
			else {
				oMap.put("AYNI_SIFRE_BASVURU", false);
			}
			oMap.put("YUZOLCUMU", birSaticiTahsis.getIsyeriYuzolcumu());
			oMap.put("EK_ISYERI_VAR_MI", birSaticiTahsis.getEkIsyeriVar());
			if (birSaticiTahsis.getEkIsyeriVar() != null && birSaticiTahsis.getEkIsyeriVar().equals("E")) {
				oMap.put("EK_ISYERI_ADI", birSaticiTahsis.getEkIsyeriAdi());
			}
			else {
				oMap.put("EK_ISYERI_ADI", nuLL);
			}
			oMap.put("BAYI_STATU", birSaticiTahsis.getBayiStatuKod());
			oMap.put("BAYI_CALISMA_SEKLI", birSaticiTahsis.getCalismaSekliKod());
			oMap.put("BAYI_RISKI", birSaticiTahsis.getBayiRiskKod());
			oMap.put("AYLIK_LIMIT", birSaticiTahsis.getBayiAylikLimit());
			oMap.put("GUNLUK_LIMIT", birSaticiTahsis.getBayiGunlukLimit());
			oMap.put("AYLIK_BASVURU_LIMIT", birSaticiTahsis.getAylikBasvuruLimit());
			if ("KK".equals(birSaticiTahsis.getBayiStatuKod())) {
				oMap.put("KISMI_KAPANMA_NEDENI", birSaticiTahsis.getKismiKapanmaNedenKod());
				oMap.put("KISMI_KAPANMA_STATU", birSaticiTahsis.getKismiKapanmaStatuKod());
				oMap.put("KAPANMA_NEDENI", nuLL);
			}
			else if ("K".equals(birSaticiTahsis.getBayiStatuKod())) {
				oMap.put("KISMI_KAPANMA_NEDENI", nuLL);
				oMap.put("KISMI_KAPANMA_STATU", nuLL);
				oMap.put("KAPANMA_NEDENI", birSaticiTahsis.getKapanmaNedenKod());
			}
			else {
				oMap.put("KISMI_KAPANMA_NEDENI", nuLL);
				oMap.put("KISMI_KAPANMA_STATU", nuLL);
				oMap.put("KAPANMA_NEDENI", nuLL);
			}
			oMap.put("ORJINAL_EVRAK_GON_SURESI", birSaticiTahsis.getOrjEvrakGonSure());
			oMap.put("BASVURU_GIREBILIR_EH", birSaticiTahsis.getBasvuruGirilebilirEh());
			oMap.put("MUSTERI_PORTFOYU", birSaticiTahsis.getMusteriPortfoyKod());
			oMap.put("CAL_FINANS1_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans1Eh()));
			oMap.put("CAL_FINANS2_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans2Eh()));
			oMap.put("CAL_FINANS3_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans3Eh()));
			oMap.put("CAL_FINANS4_EH", GuimlUtil.convertToCheckBoxSelected(birSaticiTahsis.getCalFinans4Eh()));
			if (birSaticiTahsis.getCalFinansDiger() != null) {
				oMap.put("CAL_FINANS_DIGER_ADI", birSaticiTahsis.getCalFinansDiger());
				oMap.put("CAL_FINANS_DIGER", true);
			}
			else {
				oMap.put("CAL_FINANS_DIGER_ADI", nuLL);
				oMap.put("CAL_FINANS_DIGER", false);
			}
			oMap.put("DAGITICI_FIRMA_TEMINAT_CINSI", birSaticiTahsis.getDagiticiFirmaTeminatKod());
			oMap.put("TEMINAT_TUTARI", birSaticiTahsis.getTeminatTutar());
			oMap.put("YATIRIM_PLANI_VAR_MI", birSaticiTahsis.getYatirimPlani());
			if (birSaticiTahsis.getYatirimPlani() != null && birSaticiTahsis.getYatirimPlani().equals("VAR")) {
				oMap.put("YATIRIM_PLANI_ACIKLAMA", birSaticiTahsis.getYatirimPlaniAciklama());
			}
			else {
				oMap.put("YATIRIM_PLANI_ACIKLAMA", nuLL);
			}

			oMap.put("ORTAK_SEKTOR_TECRUBESI", birSaticiTahsis.getOrtakSektorTecrubesi());
			oMap.put("BEKLENEN_KREDI_HACMI", birSaticiTahsis.getBeklenenKrediHacmi());
			oMap.put("GMENKUL_ARSA", birSaticiTahsis.getGayrimenkulAdetArsa());
			oMap.put("GMENKUL_DUKKAN", birSaticiTahsis.getGayrimenkulAdetDukkan());
			oMap.put("GMENKUL_EV", birSaticiTahsis.getGayrimenkulAdetEv());
			oMap.put("LIMIT_MERKEZ_BAGIMSIZ_MI", birSaticiTahsis.getLimitMerkezBagimsizEh());
			oMap.put("TASIT_SAYI", birSaticiTahsis.getTasitSayi());
			oMap.put("SUBE_SAYISI", birSaticiTahsis.getSubeSayisi());
			oMap.put("YETKI_SEVIYE_KOD", birSaticiTahsis.getYetkiSeviyeKod());
			oMap.put("ANA_SATIS_KANAL", birSaticiTahsis.getAnaSatisKanal());
			oMap.put("YILLIK_CIRO", birSaticiTahsis.getYillikCiro());
			oMap.put("ANA_CIRO_DEGISIM", birSaticiTahsis.getAnaCiroDegisim());
			oMap.put("YATIRIM_BUYUKLUGU", birSaticiTahsis.getYatirimBuyukluk());

			if (birSaticiTahsis.getAyniAdresteFaaliyetSuresi() != null) {
				String ayniAdresteFaaliyetSuresiYil = birSaticiTahsis.getAyniAdresteFaaliyetSuresi().substring(0, 2);
				if (ayniAdresteFaaliyetSuresiYil.charAt(0) == '0')
					ayniAdresteFaaliyetSuresiYil = ayniAdresteFaaliyetSuresiYil.substring(1);
				String ayniAdresteFaaliyetSuresiAy = birSaticiTahsis.getAyniAdresteFaaliyetSuresi().substring(2, 4);
				if (ayniAdresteFaaliyetSuresiAy.charAt(0) == '0')
					ayniAdresteFaaliyetSuresiAy = ayniAdresteFaaliyetSuresiAy.substring(1);
				oMap.put("AYNI_ISYERINDE_FAALIYET_SURESI_YIL", ayniAdresteFaaliyetSuresiYil);
				oMap.put("AYNI_ISYERINDE_FAALIYET_SURESI_AY", ayniAdresteFaaliyetSuresiAy);
			}
			else {
				oMap.put("AYNI_ISYERINDE_FAALIYET_SURESI_YIL", nuLL);
				oMap.put("AYNI_ISYERINDE_FAALIYET_SURESI_AY", nuLL);
			}

			oMap.put("DISTRIBUTOR_DURUM_DST", birSaticiTahsis.getDistributorDurum());
			oMap.put("BEKLENEN_NPL_DST", birSaticiTahsis.getBeklenenNpl());
			oMap.put("CALISMA_ESAS_DST", birSaticiTahsis.getCalismaEsas());
			oMap.put("BLOKAJ_ORAN_DST", birSaticiTahsis.getBlokajOran());
			oMap.put("GARANTOR_GORUNSUN_EH_DST", birSaticiTahsis.getGarantorGorunsunEh());
			oMap.put("FOTO_CEKIM_EH_DST", birSaticiTahsis.getFotoCekimEh());
			oMap.put("BARKOD_ZARF_EH_DST", birSaticiTahsis.getBarkodZarfEh());
			oMap.put("ERKEN_BELGE_ALABILIR_MI_EH_DST", birSaticiTahsis.getErkenBelgeAlimiEh());
			oMap.put("GPS_TAKIP_EH_DST", birSaticiTahsis.getGpsTakipEh());
			oMap.put("BILGI_FORMU_EH_DST", birSaticiTahsis.getBilgiFormuEh());
			oMap.put("BELGE_TESLIM_EH_DST", birSaticiTahsis.getBelgeTeslimEh());
			oMap.put("OTP_KONTROL_EH_DST", birSaticiTahsis.getOtpKontrolEh());
			oMap.put("DISTRIBUTOR_DURUM", birSaticiTahsis.getDistributorDurum());
			oMap.put("BEKLENEN_NPL", birSaticiTahsis.getBeklenenNpl());
			oMap.put("CALISMA_ESAS", birSaticiTahsis.getCalismaEsas());
			oMap.put("BLOKAJ_ORAN", birSaticiTahsis.getBlokajOran());
			oMap.put("GARANTOR_GORUNSUN_EH", birSaticiTahsis.getGarantorGorunsunEh());
			oMap.put("FOTO_CEKIM_EH", birSaticiTahsis.getFotoCekimEh());
			oMap.put("BARKOD_ZARF_EH", birSaticiTahsis.getBarkodZarfEh());
			oMap.put("GPS_TAKIP_EH", birSaticiTahsis.getGpsTakipEh());
			oMap.put("BILGI_FORMU_EH", birSaticiTahsis.getBilgiFormuEh());
			oMap.put("BELGE_TESLIM_EH", birSaticiTahsis.getBelgeTeslimEh());
			oMap.put("OTP_KONTROL_EH", birSaticiTahsis.getOtpKontrolEh());
			oMap.put("ERKEN_BELGE_ALABILIR_MI_EH", birSaticiTahsis.getErkenBelgeAlimiEh());
			oMap.put("ERKEN_BELGE_ALABILIR_MI_EH_DST", birSaticiTahsis.getErkenBelgeAlimiEh());
			oMap.put("ONEM_DERECESI", birSaticiTahsis.getOnemDereceKod());
			oMap.put("KATEGORI_SKOR", birSaticiTahsis.getKategoriSkor());
			oMap.put("KATEGORI_SKOR_TAHSIS", birSaticiTahsis.getKategoriSkorTahsis());
			oMap.put("KURUMSAL_GARANTOR_LIMIT", birSaticiTahsis.getKurumsalGarantorLimit());
			oMap.put("PERAKENDE_REZERV_LIMIT", birSaticiTahsis.getPerakendeRezervLimit());
			oMap.put("MIN_BLOKE_TUTAR", birSaticiTahsis.getMinBlokeTutar());
			oMap.put("BLOKAJ_NEDEN", birSaticiTahsis.getBlokajNeden());
			oMap.put("UST_NPL_ORAN", birSaticiTahsis.getUstNplOran());
			oMap.put("MAX_KULL_LIMIT", birSaticiTahsis.getMaxKullLimit());
			oMap.put("BLOKAJ_NEDEN", birSaticiTahsis.getBlokajNeden());
			oMap.put("BLOKAJ_KREDI_TIP", birSaticiTahsis.getBlokajKrediTip());
			oMap.put("BLOKAJ_COZUM_ZAMAN", birSaticiTahsis.getBlokajCozumZaman());
			oMap.put("MAX_BLOKE_TUTAR", birSaticiTahsis.getMaxBlokeTutar());
			oMap.put("ISTIHBARAT_FIRMA_GORUS", birSaticiTahsis.getIstihbaratFirmaGorus());
			oMap.put("BLOKE_HESAP", birSaticiTahsis.getBlokeHesap());
			oMap.put("BAYI_BEKL_KREDI_HACMI", birSaticiTahsis.getBayiBeklKrediHacmi());
			oMap.put("DST_PAZAR_PAY", birSaticiTahsis.getDstPazarPay());
			oMap.put("DST_BORC_ORAN", birSaticiTahsis.getDstBorcOran());
			oMap.put("DST_BAYI_ORAN", birSaticiTahsis.getDstBayiOran());
			oMap.put("DST_KITLE", birSaticiTahsis.getDstKitle());
			oMap.put("DST_CIRO", birSaticiTahsis.getDstCiro());
			oMap.put("DST_CIRO_DEGISIM", birSaticiTahsis.getDstCiroDegisim());
			oMap.put("DST_SENET_AGIRLIK", birSaticiTahsis.getDstSenetAgirlik());
			oMap.put("DST_YATIRIM_BUYUKLUK", birSaticiTahsis.getDstYatirimBuyukluk());
			oMap.put("DST_KAZANIM_KANAL", birSaticiTahsis.getDstKazanimKanal());
			oMap.put("VALOR_BLOKE_HESAP", birSaticiTahsis.getValorBlokeHesap());
			String ubeDistEH = birSaticiTahsis.getUbeDistributorEh();
			if (ubeDistEH == null || "null".equals(ubeDistEH) || ubeDistEH.isEmpty()) {
				ubeDistEH = "H";
			}
			oMap.put("DST_WEB_BAYI_IZIN_EH", "E".equals(ubeDistEH));
			oMap.put("DST_WEB_GORUNTU_ISIM", birSaticiTahsis.getUbeDistributorUnvan());
		}
		else {
			oMap.put("DST_WEB_BAYI_IZIN_EH", false);
		}

		BirSatici birSatici = (BirSatici) session.createCriteria(BirSatici.class).add(Restrictions.eq("kod", oMap.getBigDecimal("SATICI_NO"))).uniqueResult();

		if (birSatici != null) {
			oMap.put("MUSTERI_NO", birSatici.getMusteriNo());
			oMap.put("DI_MUSTERI_NO", LovHelper.diLov(birSatici.getMusteriNo(), "3161/LOV_TUZEL_MUSTERI", "UNVAN"));
			oMap.put("HESAP_NO", birSatici.getHesapNo());
			oMap.put("DI_HESAP_NO", LovHelper.diLov(birSatici.getHesapNo(), birSatici.getMusteriNo(), "3161/LOV_VDSZ_HESAP", "KISA_ISIM"));

			oMap.put("SATICI_ADI", birSatici.getSaticiAdi());
			oMap.put("BAYI_MERKEZ", birSatici.getBagliMerkezBayi());
		}
		else {
			oMap.put("MUSTERI_NO", nuLL);
			oMap.put("DI_MUSTERI_NO", nuLL);
			oMap.put("HESAP_NO", nuLL);
			oMap.put("DI_HESAP_NO", nuLL);

			oMap.put("SATICI_ADI", nuLL);
			oMap.put("BAYI_MERKEZ", nuLL);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3162_GET_ROW_PROPERTIES")
	public static GMMap getRowProperties(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Map<String, Object> rowData = (Map<String, Object>) iMap.get("ROW_DATA");

			for (String key : rowData.keySet()) {
				if (key.endsWith("Properties")) {
					oMap.put(key, rowData.get(key));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static void setFaaliyetKonulariTable(BigDecimal txNo, String tableName, BigDecimal saticiKod, List<?> saticiTahsisFaaliyetList, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		int row = 0;
		for (int i = 0; i < saticiTahsisFaaliyetList.size(); i++) {
			BirSaticiTahsisFaaliyetTx birSaticiTahsisFaaliyet = (BirSaticiTahsisFaaliyetTx) session.createCriteria(BirSaticiTahsisFaaliyetTx.class).add(Restrictions.eq("id.saticiKod", saticiKod)).add(Restrictions.eq("id.faaliyetKodu", ((HashMap<?, ?>) saticiTahsisFaaliyetList.get(row)).get("FAALIYET_KODU"))).add(Restrictions.eq("id.tur", "X")).add(Restrictions.eq("id.txNo", txNo)).uniqueResult();

			if (birSaticiTahsisFaaliyet != null)
				oMap.put(tableName, row, "SEC", true);
			else
				oMap.put(tableName, row, "SEC", false);
			oMap.put(tableName, row, "FAALIYET_KODU", (String) ((HashMap<?, ?>) saticiTahsisFaaliyetList.get(row)).get("FAALIYET_KODU"));
			oMap.put(tableName, row, "FAALIYET_KONUSU", (String) ((HashMap<?, ?>) saticiTahsisFaaliyetList.get(row)).get("FAALIYET_KONUSU"));
			row++;
		}
	}

	private static void setEkIsyeriFaaliyetTable(BigDecimal txNo, String tableName, BigDecimal saticiKod, List<?> saticiTahsisEkIsyeriFaaliyetList, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		int row = 0;
		for (int i = 0; i < saticiTahsisEkIsyeriFaaliyetList.size(); i++) {
			BirSaticiTahsisFaaliyetTx birSaticiTahsisFaaliyet = (BirSaticiTahsisFaaliyetTx) session.createCriteria(BirSaticiTahsisFaaliyetTx.class).add(Restrictions.eq("id.saticiKod", saticiKod)).add(Restrictions.eq("id.faaliyetKodu", ((HashMap<?, ?>) saticiTahsisEkIsyeriFaaliyetList.get(row)).get("FAALIYET_KODU"))).add(Restrictions.eq("id.tur", "EK")).add(Restrictions.eq("id.txNo", txNo)).uniqueResult();

			if (birSaticiTahsisFaaliyet != null)
				oMap.put(tableName, row, "SEC", true);
			else
				oMap.put(tableName, row, "SEC", false);
			oMap.put(tableName, row, "FAALIYET_KODU", (String) ((HashMap<?, ?>) saticiTahsisEkIsyeriFaaliyetList.get(row)).get("FAALIYET_KODU"));
			oMap.put(tableName, row, "FAALIYET_KONUSU", (String) ((HashMap<?, ?>) saticiTahsisEkIsyeriFaaliyetList.get(row)).get("FAALIYET_KONUSU"));
			row++;
		}
	}

	private static void setUrunHizmetTable(BigDecimal txNo, String tableName, GMMap oMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3162.Get_Mal_List_tx(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, txNo);
			stmt.execute();
			int row = 0;
			int j = 0;
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put(tableName, row, "UST_GRUP_NO", rSet.getObject("MALNO"));
				GMMap tMap = new GMMap();
				stmt2 = conn.prepareCall("{?=call PKG_TRN3162.Get_Mal_Detay_List_tx(?,?)}");
				stmt2.registerOutParameter(1, -10);
				stmt2.setBigDecimal(2, txNo);
				stmt2.setBigDecimal(3, oMap.getBigDecimal(tableName, row, "UST_GRUP_NO"));
				stmt2.execute();
				j = 0;
				rSet2 = (ResultSet) stmt2.getObject(1);
				while (rSet2.next()) {
					tMap.put("DETAY_TABLE", j, "ALT_URUN", rSet2.getObject("MALNO"));
					j++;
				}
				stmt2.close();
				oMap.put(tableName, row, "URUN_ALT_GRUP_DATA", tMap.get("DETAY_TABLE"));
				oMap.put(tableName, row, "URUN_UST_GRUP", rSet.getObject("MAL_AD"));
				oMap.put(tableName, row, "BAYI_URUN_KOD", rSet.getObject("TIP"));
				oMap.put(tableName, row, "BAYI_URUN_TIP", rSet.getObject("TIP_AD"));
				oMap.put(tableName, row, "URUN_UST_GRUP_TIP", rSet.getObject("UST_GRUP_TIP"));
				oMap.put(tableName, row, "URUN_KALITE", rSet.getObject("KALITE"));
				oMap.put(tableName, row, "TESLIMAT_SURESI", rSet.getObject("TESLIM_SURE"));
				oMap.put(tableName, row, "URUN_TESLIMAT_YER", rSet.getObject("URUN_TESLIM_YER"));
				oMap.put(tableName, row, "HIZMET_TESLIM_YER", rSet.getObject("HIZMET_TESLIM_YER"));
				oMap.put(tableName, row, "URUN_2EL_DEGER", rSet.getObject("DEGER2EL"));
				oMap.put(tableName, row, "URUN_SKOR", rSet.getObject("SKOR"));
				oMap.put(tableName, row, "URUN_SKOR_TAHSIS", rSet.getObject("SKOR_TAHSIS"));
				row++;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt2);
		}
	}

	private static void setEkIsyeriTable(BigDecimal txNo, String tableName, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		int row = 0;
		List<?> ekisyerilist = session.createCriteria(BirSaticiTahsisEkisyeriTx.class).add(Restrictions.eq("id.txNo", txNo)).list();
		for (Object name : ekisyerilist) {
			BirSaticiTahsisEkisyeriTx birSaticiTahsisEkisyeriTx = (BirSaticiTahsisEkisyeriTx) name;
			oMap.put(tableName, row, "SATICI_KOD", birSaticiTahsisEkisyeriTx.getId().getIliskiliSaticiKod());
			oMap.put(tableName, row, "SATICI_ADI", birSaticiTahsisEkisyeriTx.getIliskiliSaticiAdi());
			row++;
		}
	}

	private static void setLimitTable(BigDecimal txNo, String tableName, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = session.createCriteria(BirSaticiLimitTx.class).add(Restrictions.eq("id.txNo", txNo)).list();
		int row = 0;
		for (Object name : list) {
			BirSaticiLimitTx birSaticiLimitTx = (BirSaticiLimitTx) name;

			oMap.put(tableName, row, "BELGE_TIPI", birSaticiLimitTx.getBelgeTip());
			oMap.put(tableName, row, "DURUM", birSaticiLimitTx.getDurum());
			// oMap.put(tableName, row, "KULLANILABILIR_LIMIT", birSaticiLimitTx);
			oMap.put(tableName, row, "SATIC_LIMIT_TIP", birSaticiLimitTx.getId().getSaticiLimitTip());
			oMap.put(tableName, row, "DOVIZ_CINSI", birSaticiLimitTx.getId().getDovizCins());
			oMap.put(tableName, row, "ORIJINAL_LIMIT_TUTAR", birSaticiLimitTx.getLimit());
			oMap.put(tableName, row, "SATIC_LIMIT_TIP", birSaticiLimitTx.getId().getSaticiLimitTip());
			// /oMap.put(tableName, row, "IADE", birSaticiLimitTx.getIade());
			row++;

		}
	}

	private static void setTasitTable(BigDecimal txNo, String tableName, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = session.createCriteria(BirSaticiTahsisAraclarTx.class).add(Restrictions.eq("txNo", txNo)).list();
		int row = 0;
		for (Object name : list) {
			BirSaticiTahsisAraclarTx birSaticiTahsisAraclarTx = (BirSaticiTahsisAraclarTx) name;

			oMap.put(tableName, row, "MARKA", birSaticiTahsisAraclarTx.getMarka());
			oMap.put(tableName, row, "MODEL", birSaticiTahsisAraclarTx.getModel());
			oMap.put(tableName, row, "YIL", birSaticiTahsisAraclarTx.getYil());
			oMap.put(tableName, row, "ID", birSaticiTahsisAraclarTx.getId());
			row++;

		}
	}

	private static void setMarkaTable(BigDecimal txNo, String tableName, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = session.createCriteria(BirSaticiTahsisMarkalarTx.class).add(Restrictions.eq("id.txNo", txNo))
		// .add(Restrictions.eq("id.marka", iMap.getBigDecimal("TRX_NO")))
		// .add(Restrictions.eq("id.saticiKod", iMap.getBigDecimal("SATICI_NO")))
		.list();
		int row = 0;
		for (Object name : list) {
			BirSaticiTahsisMarkalarTx birSaticiTahsisMarkalarTx = (BirSaticiTahsisMarkalarTx) name;

			oMap.put(tableName, row, "MARKA", birSaticiTahsisMarkalarTx.getId().getMarka());
			oMap.put(tableName, row, "BAYILIK_SURESI", birSaticiTahsisMarkalarTx.getBayilikSuresi());
			oMap.put(tableName, row, "ORT_AYLIK_SATIS_ADET", birSaticiTahsisMarkalarTx.getOrtAylikSatisAdet());
			oMap.put(tableName, row, "ORT_AYLIK_SATIS_TUTAR", birSaticiTahsisMarkalarTx.getOrtAylikSatisTutar());
			oMap.put(tableName, row, "PESIN", birSaticiTahsisMarkalarTx.getPesin());
			oMap.put(tableName, row, "SENET", birSaticiTahsisMarkalarTx.getSenet());
			oMap.put(tableName, row, "KART", birSaticiTahsisMarkalarTx.getKart());
			oMap.put(tableName, row, "YETKILI_BAYI", birSaticiTahsisMarkalarTx.getYetkiliBayi());
			oMap.put(tableName, row, "TESLIM_SURE", birSaticiTahsisMarkalarTx.getTeslimSure());
			oMap.put(tableName, row, "KREDILI", birSaticiTahsisMarkalarTx.getKredili());
			row++;
		}
	}

	private static void setCalisanTable(BigDecimal txNo, String tableName, GMMap oMap) {
		GMMap xMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> calisanlarList = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo", txNo)).list();
		int row = 0;
		for (int i = 0; i < calisanlarList.size(); i++) {

			BirSaticiCalisanTx birSaticiCalisanTx = (BirSaticiCalisanTx) calisanlarList.get(i);
			oMap.put(tableName, row, "MUSTERI_NO", birSaticiCalisanTx.getMusteriNo());

			ArrayList<Object> listPar = new ArrayList<Object>();
			listPar.add(birSaticiCalisanTx.getMusteriNo());
			HashMap<?, ?> musteriLovMap = LovHelper.diLovAll(birSaticiCalisanTx.getMusteriNo(), "3161/LOV_GERCEK_MUSTERI_GET_INFO", listPar);
			if (musteriLovMap != null) {
				oMap.put(tableName, row, "DI_MUSTERI_NO", (String) musteriLovMap.get("UNVAN"));
				oMap.put(tableName, row, "TCK_NO", (String) musteriLovMap.get("TC_KIMLIK_NO"));
				oMap.put(tableName, row, "ADI", (String) musteriLovMap.get("ADI"));
				oMap.put(tableName, row, "IKINCI_ADI", (String) musteriLovMap.get("IKINCI_ADI"));
				oMap.put(tableName, row, "SOYADI", (String) musteriLovMap.get("SOYADI"));
				oMap.put(tableName, row, "UYRUK", (String) musteriLovMap.get("UYRUK_KOD"));
				oMap.put(tableName, row, "DOGUM_TARIHI", musteriLovMap.get("DOGUM_TARIHI"));
				oMap.put(tableName, row, "DOGUM_YERI", (String) musteriLovMap.get("DOGUM_YERI"));
				oMap.put(tableName, row, "BABA_ADI", (String) musteriLovMap.get("BABA_ADI"));
				oMap.put(tableName, row, "ANNE_ADI", (String) musteriLovMap.get("ANNE_ADI"));

				xMap = new GMMap();
				xMap.put("EMAIL_1", (String) musteriLovMap.get("EMAIL_KISISEL"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS", xMap));
				oMap.put(tableName, row, "EPOSTA_NAME", oMap.get("EMAIL_11"));
				oMap.put(tableName, row, "EPOSTA_NET", oMap.get("EMAIL_12"));
				oMap.put(tableName, row, "CEP_TEL_ALAN", (String) musteriLovMap.get("GSM_ALAN"));
				oMap.put(tableName, row, "CEP_TEL", (String) musteriLovMap.get("GSM"));
			}
			oMap.put(tableName, row, "KOD", birSaticiCalisanTx.getId().getKod());
			oMap.put(tableName, row, "ORTAK_MI", birSaticiCalisanTx.getOrtakEh());
			oMap.put(tableName, row, "ORTAKLIK_PAYI", birSaticiCalisanTx.getOrtaklikPayi());
			oMap.put(tableName, row, "ISE_BASLAMA_TARIHI", birSaticiCalisanTx.getIseBaslamaTar());
			oMap.put(tableName, row, "POZISYONU", birSaticiCalisanTx.getPozisyonKod());
			oMap.put(tableName, row, "TUTTUGU_TAKIM", birSaticiCalisanTx.getTuttuguTakimKod());
			oMap.put(tableName, row, "HOBILERI", birSaticiCalisanTx.getHobiKod());
			oMap.put(tableName, row, "CALISAN_STATUSU", birSaticiCalisanTx.getCalStatuKod());
			oMap.put(tableName, row, "KAPANMA_NEDENI", birSaticiCalisanTx.getCalKismiKapanmaNedenKod());
			oMap.put(tableName, row, "YETKI_SEVIYESI", birSaticiCalisanTx.getYetkiGirisKod());
			oMap.put(tableName, row, "YETKI_SEVIYESI_GUNCELLEME_TAR", birSaticiCalisanTx.getYetkiGirisKodGuncellemeTar());
			oMap.put(tableName, row, "ONCEKI_YETKI_SEVIYESI", birSaticiCalisanTx.getOncekiYetkiGirisKod());
			oMap.put(tableName, row, "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR", birSaticiCalisanTx.getOncekiYetkiGuncellemeTar());
			oMap.put(tableName, row, "GIZLI_YETKI_SEVIYESI", birSaticiCalisanTx.getYetkiGirisKod());
			oMap.put(tableName, row, "BANKA_KOD", birSaticiCalisanTx.getDigerBankaKod());
			oMap.put(tableName, row, "DI_BANKA_KOD", LovHelper.diLov(birSaticiCalisanTx.getDigerBankaKod(), "3161/LOV_BANKA", "BANKA_ADI"));
			oMap.put(tableName, row, "SUBE_KOD", birSaticiCalisanTx.getDigerSubeKod());
			oMap.put(tableName, row, "MUSTERI_NO", birSaticiCalisanTx.getMusteriNo());
			oMap.put(tableName, row, "DI_SUBE_KOD", LovHelper.diLov(birSaticiCalisanTx.getDigerSubeKod(), birSaticiCalisanTx.getDigerBankaKod(), oMap.getString("IL_KOD"), "3161/LOV_BANKA_SUBE", "SUBE_ADI"));
			oMap.put(tableName, row, "HESAP_A", birSaticiCalisanTx.getDigerHesapNo());
			oMap.put(tableName, row, "MUSTERI_HESAP_NO", birSaticiCalisanTx.getHesapNo());
			oMap.put(tableName, row, "DI_MUSTERI_HESAP_NO", LovHelper.diLov(birSaticiCalisanTx.getHesapNo(), birSaticiCalisanTx.getMusteriNo(), "3161/LOV_VDSZ_HESAP", "KISA_ISIM"));
			oMap.put(tableName, row, "YENI_MUSTERI_MI", false);

			row++;
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_ONCEKI_TX_NO")
	public static GMMap getOncekiTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3162.onceki_txno_3162(?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();

			oMap.put("OLD_TRX_NO", stmt.getBigDecimal(1));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3162_CALISAN_STATU_GUNCELLEME")
	public static GMMap calisanStatuGuncelleme(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiTahsisTx birSaticiTahsisTx = (BirSaticiTahsisTx) session.createCriteria(BirSaticiTahsisTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			List<?> list = session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("birSatici.kod", birSaticiTahsisTx.getKod())).add(Restrictions.eq("durum", "ONAY")).list();
			String bayiStatu = birSaticiTahsisTx.getBayiStatuKod();
			String calisanKod = null;
			String calStatuKod = null;
			for (Object name : list) {
				BirSaticiCalisan birSaticiCalisan = (BirSaticiCalisan) name;
				calisanKod = birSaticiCalisan.getKod().toString();
				calStatuKod = birSaticiCalisan.getCalStatuKod();
				iMap.put("UID", calisanKod);
				oMap = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_DLR", iMap);
				if ("IPTAL".equals(birSaticiCalisan.getDurum())) {
					iMap.put("USER_STATUS", "Inactive");
				}
				else {
					if ("K".equals(calStatuKod)) {
						iMap.put("USER_STATUS", "Inactive");
					}
					else {
						iMap.put("USER_STATUS", "Active");
					}
				}
				if (oMap.getBoolean("LDAP_USER")) {
					GMServiceExecuter.execute("BNSPR_SYSTEM_LDAP_SET_USER_STATUS_DLR", iMap);
				}

				iMap.put("UID", birSaticiCalisan.getKod().toString());
				iMap.put("USER_STATUS", "K".equals(bayiStatu) ? "Inactive" : "Active");
				if ("K".equals(bayiStatu)) {
					if ("KK".equals(birSaticiCalisan.getCalStatuKod())) {
						birSaticiCalisan.setCalStatuKod("K");
						birSaticiCalisan.setCalKismiKapanmaNedenKod("5");
					}
					else if ("A".equals(birSaticiCalisan.getCalStatuKod())) {
						birSaticiCalisan.setCalStatuKod("K");
						birSaticiCalisan.setCalKismiKapanmaNedenKod("4");
						changeLdapUserStatus(iMap);
					}
				}
				else {
					if ("5".equals(birSaticiCalisan.getCalKismiKapanmaNedenKod())) {
						// birSaticiCalisan.setCalStatuKod("KK");
						// birSaticiCalisan.setCalKismiKapanmaNedenKod("");

					}
					// BD-228
					/*
					 * else
					 * if("4".equals(birSaticiCalisan.getCalKismiKapanmaNedenKod
					 * ())){ birSaticiCalisan.setCalStatuKod("A");
					 * birSaticiCalisan.setCalKismiKapanmaNedenKod("");
					 * changeLdapUserStatus(iMap); }
					 */
				}

				@SuppressWarnings("unchecked")
				List<BirSaticiCalisanTx> calisanTxList = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
				if (calisanTxList != null) {
					for (BirSaticiCalisanTx birSaticiCalisanTx : calisanTxList) {
						GMMap serviceMap = new GMMap();
						try {
							serviceMap.put("USERNAME", birSaticiCalisanTx.getId().getKod());
							serviceMap.put("ROLE_CODE", birSaticiCalisanTx.getYetkiGirisKod());
							serviceMap.put("SERVICE_NAME", "ADC_CORE_REMOTE_USER_ROLE_UPDATE");
							GMServiceExecuter.call("ADK_CALL_SERVICE", serviceMap);
						}
						catch (Exception e) {
							// Ilgili kullanicinin ADC_USER yok. Sonraki ile devam et
							System.out.println("Cannot update dealer employee user role " + serviceMap);
						}
					}
				}

			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN3162_CALISAN_STATU_GUNCELLE")
	public static GMMap calisanStatuGuncelle(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			String calisanKod = iMap.getString("CALISAN_KOD");
			String calStatuKod = iMap.getString("CALISAN_STATU_KOD");

			BirSaticiCalisan cal = (BirSaticiCalisan) session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("kod", calisanKod)).uniqueResult();

			iMap.put("UID", calisanKod);
			oMap = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_DLR", iMap);
			if ("IPTAL".equals(cal.getDurum())) {
				iMap.put("USER_STATUS", "Inactive");
			}
			else {
				if ("K".equals(calStatuKod)) {
					iMap.put("USER_STATUS", "Inactive");
				}
				else {
					iMap.put("USER_STATUS", "Active");
				}
			}
			if (oMap.getBoolean("LDAP_USER")) {
				GMServiceExecuter.execute("BNSPR_SYSTEM_LDAP_SET_USER_STATUS_DLR", iMap);
			}

			cal.setCalStatuKod(calStatuKod);
			cal.setCalKismiKapanmaNedenKod(iMap.getString("KISMI_KAPANMA_NEDEN_KOD"));

			if ("A".equals(calStatuKod)) {
				changeLdapUserStatus(iMap);
			}

			session.save(cal);
			session.flush();

			@SuppressWarnings("unchecked")
			List<BirSaticiCalisanTx> calisanTxList = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.kod", iMap.getBigDecimal("CALISAN_KOD"))).list();
			if (calisanTxList != null) {
				for (BirSaticiCalisanTx birSaticiCalisanTx : calisanTxList) {
					GMMap serviceMap = new GMMap();
					try {
						serviceMap.put("USERNAME", birSaticiCalisanTx.getId().getKod());
						serviceMap.put("ROLE_CODE", iMap.getString("YETKI_GIRIS_KOD"));
						serviceMap.put("SERVICE_NAME", "ADC_CORE_REMOTE_USER_ROLE_UPDATE");
						GMServiceExecuter.call("ADK_CALL_SERVICE", serviceMap);
					}
					catch (Exception e) {
						// Ilgili kullanicinin ADC_USER yok. Sonraki ile devam et
						System.out.println("Cannot update dealer employee user role " + serviceMap);
					}
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static void changeLdapUserStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_DLR", iMap);
		if (oMap.getBoolean("LDAP_USER")) {
			oMap.putAll(iMap);
			GMServiceExecuter.execute("BNSPR_SYSTEM_LDAP_SET_USER_STATUS_DLR", oMap);
		}
	}

	@GraymoundService("BNSPR_TRN3162_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		try {
			GMServiceExecuter.execute("BNSPR_TRN3162_CALISAN_STATU_GUNCELLEME", iMap);
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_YETKI_SEVIYESI")
	public static GMMap getYetkiSeviyesi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_Trn3162.Get_Yetki_Seviyesi(?) }");
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			stmt.setBigDecimal(++i, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_LIMIT_KULLANIM_BILGILERI")
	public static GMMap getLimitKullanimbilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3162.Limit_Kullanim_Bilgileri(?) }");
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			stmt.setBigDecimal(++i, iMap.getBigDecimal("SATICI_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap = DALUtil.rSetResults(rSet, "LIMIT_HAREKET_IZLEME");
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_CALISAN_STATU")
	public static GMMap getCalisanStatu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3162.CalisanStatuKontrol(?,?,?)}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("KOD"));
			stmt.setString(4, iMap.getString("STATU"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("COUNT", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3162_GET_ALT_URUN_COMBO")
	public static GMMap getAltUrunCombo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_trn3162.rc_Mal_Detay_Tanim_List(?) }");
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			stmt.setBigDecimal(++i, iMap.getBoolean("DISTRIBUTOR_MU") ? iMap.getBigDecimal("UST_URUN_NO_DST") : iMap.getBigDecimal("UST_URUN_NO"));
			stmt.execute();
			i = 0;
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put("URUN_ALT_GRUP", i, "NAME", rSet.getString("AD"));
				oMap.put("URUN_ALT_GRUP", i++, "VALUE", rSet.getString("MALNO"));
			}
			System.out.println(oMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
}
