package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.lowagie.text.pdf.codec.postscript.ParseException;

public class ConsumerLoanQRY3116Services {
	
	@GraymoundService("BNSPR_QRY3116_GET_MARKA_KOD")
	public static GMMap qry3116GetMarkaKod(GMMap iMap) throws ParseException 
	{ 
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3116.RC_QRY3116_GET_MARKA_KOD(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("KREDI_TURU"));
	
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "MARKA_TABLE");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3116_GET_MODEL_KOD")
	public static GMMap qry3116GetModelKod(GMMap iMap) throws ParseException 
	{
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3116.RC_QRY3116_GET_MODEL_KOD(?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("MARKA_KOD"));
			stmt.setString(i++, iMap.getString("KREDI_KOD"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "MODEL_TABLE");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3116_GET_MODEL_YIL_DEGER")
	public static GMMap qry3116GetModelYilDeger(GMMap iMap) throws ParseException 
	{
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3116.RC_QRY3116_GET_MODEL_YIL_DEGER(?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("MODEL_KOD"));
			stmt.setString(i++, iMap.getString("MARKA_KOD"));
			stmt.setString(i++, iMap.getString("KREDI_KOD"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "MODEL_YIL_DEGER_TABLE");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
