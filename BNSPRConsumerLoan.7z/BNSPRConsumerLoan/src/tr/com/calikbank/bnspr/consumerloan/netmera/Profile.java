package tr.com.calikbank.bnspr.consumerloan.netmera;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;
import com.graymound.util.GMRuntimeException;

public class Profile implements INullController {

	@SerializedName("krediOnOnayTutar")
	private Float krediOnOnayTutar;

	@SerializedName("kdhOnOnayTutar")
	private Float kdhOnOnayTutar;

	
	public Float getKrediOnOnayTutar() {
		return krediOnOnayTutar;
	}

	public void setKrediOnOnayTutar(Float krediOnOnayTutar) {
		this.krediOnOnayTutar = krediOnOnayTutar;
	}

	public Float getKdhOnOnayTutar() {
		return kdhOnOnayTutar;
	}

	public void setKdhOnOnayTutar(Float kdhOnOnayTutar) {
		this.kdhOnOnayTutar = kdhOnOnayTutar;
	}

	@Override
	public String toString() {
		return "ClassPojo [krediOnOnayTutar = " + krediOnOnayTutar
				+ ",kdhOnOnayTutar = " + kdhOnOnayTutar + " ]";
	}

	public void checkNull() {
		Field fields[] = this.getClass().getDeclaredFields();
		for (Field f : fields) {
			try {
				Object value = f.get(this);
				if (value == null) {
					throw new GMRuntimeException(99, f.getName().toUpperCase()
							+ " degeri bos olamaz");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new GMRuntimeException(99, e.getMessage());
			}
		}

	}
}