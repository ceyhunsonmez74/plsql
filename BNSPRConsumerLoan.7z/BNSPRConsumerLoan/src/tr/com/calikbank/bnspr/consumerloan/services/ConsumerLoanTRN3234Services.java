package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.biff.EmptyCell;

import tr.com.aktifbank.bnspr.dao.VdmkKrediDevirTx;
import tr.com.aktifbank.bnspr.dao.VdmkKrediDevirTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3234Services {

	@GraymoundService("BNSPR_TRN3234_UPLOAD_EXCEL")
	public static GMMap uploadExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			if (iMap.getString("URUN_TUR_KOD") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Portf�y");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("ISO-8859-9");

			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet dataSheet = workbook.getSheet(0);

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3234.kredi_bilgi(?,?,?,?,?,?,?,?,?,?)}");

			String tableName = "DEVIR_TABLO";
			int row = 0;
			for (int i = 0; i < dataSheet.getRows(); i++) {

				if (dataSheet.getCell(0, i) instanceof EmptyCell) {
					continue;
				}
				else {

					String basvuru = dataSheet.getCell(0, i).getContents();
					String taksitNo = dataSheet.getCell(1, i).getContents();
					String ggs = dataSheet.getCell(2, i).getContents().isEmpty() ? "0" : dataSheet.getCell(2, i).getContents();

					if (basvuru != null && !basvuru.trim().isEmpty()) {
						BigDecimal basvuruNo = new BigDecimal(basvuru);

						int index = 1;
						stmt.setBigDecimal(index++, basvuruNo);
						stmt.setBigDecimal(index++, new BigDecimal(taksitNo));
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.DATE);
						stmt.registerOutParameter(index++, Types.DECIMAL);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.registerOutParameter(index++, Types.VARCHAR);
						stmt.execute();

						oMap.put(tableName, row, "BASVURU_NO", basvuruNo);
						oMap.put(tableName, row, "TAKSIT_NO", taksitNo);
						oMap.put(tableName, row, "GECIKME_GUN_SAYISI", ggs);
						index = 3;
						oMap.put(tableName, row, "DURUM", stmt.getString(index++));
						oMap.put(tableName, row, "KRD_HESAP_NO", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "BAKIYE", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "TAKSIT_TARIHI", stmt.getDate(index++));
						oMap.put(tableName, row, "TAKSIT_TUTARI", stmt.getBigDecimal(index++));
						oMap.put(tableName, row, "MODUL_TUR_KOD", stmt.getString(index++));
						oMap.put(tableName, row, "URUN_TUR_KOD", stmt.getString(index++));
						oMap.put(tableName, row, "URUN_SINIF_KOD", stmt.getString(index++));

						row++;

						stmt.clearParameters();
					}
				}
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3234_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			Session session = DAOSession.getSession("BNSPRDal");

			List<VdmkKrediDevirTx> infoList = session.createCriteria(VdmkKrediDevirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3234.kredi_bilgi(?,?,?,?,?,?,?,?,?,?)}");

			int row = 0;
			String tableName = "DEVIR_TABLO";
			for (VdmkKrediDevirTx infoRecord : infoList) {
				oMap.put("DEVIR_NO", infoRecord.getId().getDevirNo());
				oMap.put(tableName, row, "BASVURU_NO", infoRecord.getId().getBasvuruNo());
				oMap.put(tableName, row, "TAKSIT_NO", infoRecord.getTaksitNo());
				oMap.put(tableName, row, "MODUL_TUR_KOD", infoRecord.getYeniModulTurKod());
				oMap.put(tableName, row, "URUN_TUR_KOD", infoRecord.getYeniUrunTurKod());
				oMap.put(tableName, row, "URUN_SINIF_KOD", infoRecord.getYeniUrunSinifKod());
				oMap.put("URUN_SINIF_KOD", infoRecord.getYeniUrunSinifKod());

				int i = 1;
				stmt.setBigDecimal(i++, infoRecord.getId().getBasvuruNo());
				stmt.setBigDecimal(i++, infoRecord.getTaksitNo());
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.registerOutParameter(i++, Types.DATE);
				stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.registerOutParameter(i++, Types.VARCHAR);
				stmt.execute();

				i = 3;
				oMap.put(tableName, row, "DURUM", stmt.getString(i++));
				oMap.put(tableName, row, "KRD_HESAP_NO", stmt.getBigDecimal(i++));
				oMap.put(tableName, row, "BAKIYE", stmt.getBigDecimal(i++));
				oMap.put(tableName, row, "TAKSIT_TARIHI", stmt.getDate(i++));
				oMap.put(tableName, row, "TAKSIT_TUTARI", stmt.getBigDecimal(i++));

				row++;
				stmt.clearParameters();
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3234_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");

			List<VdmkKrediDevirTx> removalList = session.createCriteria(VdmkKrediDevirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (VdmkKrediDevirTx record : removalList) {
				session.delete(record);
			}

			session.flush();

			String tableName = "DEVIR_TABLO";

			for (int i = 0; i < iMap.getSize(tableName); i++) {

				VdmkKrediDevirTxId id = new VdmkKrediDevirTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setDevirNo(iMap.getBigDecimal("DEVIR_NO"));
				id.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));

				VdmkKrediDevirTx newRecord = new VdmkKrediDevirTx();
				newRecord.setId(id);
				newRecord.setYeniModulTurKod(iMap.getString("MODUL_TUR_KOD"));
				newRecord.setYeniUrunTurKod(iMap.getString("URUN_TUR_KOD"));
				newRecord.setYeniUrunSinifKod(iMap.getString("KOD"));
				newRecord.setGecikmeGunSayisi(iMap.getBigDecimal(tableName, i, "GECIKME_GUN_SAYISI"));
				newRecord.setTaksitNo(iMap.getBigDecimal(tableName, i, "TAKSIT_NO"));
				session.save(newRecord);
			}

			session.flush();

			iMap.put("TRX_NAME", "3234");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3234_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("Select p.modul_tur_kod, p.urun_tur_kod, p.kod From gnl_modul_urun_sinif_kod_pr p" + " Where pkg_parametre.Varchar_Al(p.modul_tur_kod, p.urun_tur_kod, p.kod, 'VDMK_MI') = 'E'" + " or pkg_parametre.Varchar_Al(p.modul_tur_kod, p.urun_tur_kod, p.kod, 'TEMKRD_MI') = 'E'");
			rSet = stmt.executeQuery();

			String listName = "PORTFOY_LIST";
			int row = 0;
			while (rSet.next()) {

				oMap.put(listName, row, "NAME", rSet.getString("KOD"));
				oMap.put(listName, row, "MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));
				oMap.put(listName, row, "URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));

				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
