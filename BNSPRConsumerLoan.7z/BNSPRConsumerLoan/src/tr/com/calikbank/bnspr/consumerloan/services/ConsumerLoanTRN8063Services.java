package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.commons.lang.StringUtils;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BayiBasvuruDegerlendirmeTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiBasvuruDegTx;
import tr.com.aktifbank.bnspr.dao.BpmProcessDetail;
import tr.com.aktifbank.bnspr.dao.BpmTask;
import tr.com.aktifbank.bnspr.dao.BpmTaskId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8063Services {

	@GraymoundService("BNSPR_TRN8063_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			/*
			iMap.put("TABLE_NAME", "BAYI_TIP_KOD");
			iMap.put("KOD", "BAYI_TIP_KOD");
			iMap.put("ADD_EMPTY_KEY", "");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));
			*/
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "SATICI_TIP_KOD");
			oMap.put("SATICI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BAGLI_OLD_BOLGE_KOD");
			oMap.put("BAGLI_OLDUGU_BOLGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			/*
			iMap.put("TABLE_NAME", "BAGLI_OLD_BOLGE_KOD");
			iMap.put("LOV", "3272/LOV_BAYI_BOLGE");
			iMap.put("VALUE", "BOLGE_KOD");
			iMap.put("NAME", "BOLGE_AD");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap));*/

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "ISYERI_FAAL_KONU_KOD");
			oMap.put("FAALIYET_KONUSU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			
			 
			/*
			iMap.put("TABLE_NAME", "BAYI_FAAL_KONU_KOD");
			iMap.put("KOD", "ISYERI_FAAL_KONU_KOD");
			iMap.put("ADD_EMPTY_KEY", "");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap)); */

			
			iMap.put("TABLE_NAME", "BAYI_SORUMLU_KISI");
			iMap.put("LOV", "3272/LOV_SORUMLU_KISI");
			iMap.put("VALUE", "KOD");
			iMap.put("NAME", "UNVAN");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap));

			iMap.put("TABLE_NAME", "IL");
			iMap.put("LOV", "3272/LOV_IL_KOD");
			iMap.put("VALUE", "KOD");
			iMap.put("NAME", "IL_ADI");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap));

			iMap.put("IL", oMap.getString("IL", 0, "VALUE"));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3272_ILCE", iMap));

			String listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, "X", " ");
			GuimlUtil.wrapMyCombo(oMap, listName, "B", "Benzer");
			GuimlUtil.wrapMyCombo(oMap, listName, "K", "Kesin");
			GuimlUtil.wrapMyCombo(oMap, listName, "Y", "Yok");

			oMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("LIST_NAME", "SENARYO");
			oMap.put("LIST_QUERY", "select distinct key3 kod,text from gnl_param_text where kod = 'BAYI_BAS_SORGU_SENARYO' order by text");
			DALUtil.fillComboBox(oMap);
			
			/*
			iMap.put("TABLE_NAME", "EPOS_BAYI_BELGE_KARAR");
			iMap.put("KOD", "EPOS_BAYI_BELGE_KARAR"); 			
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap)); */
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN8063_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirSaticiBasvuruDegTx birSaticiBasvuruDegTx = (BirSaticiBasvuruDegTx) session.get(BirSaticiBasvuruDegTx.class, iMap.getBigDecimal("TRX_NO"));

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareStatement("select * from gnl_param_text where key1 ='" + birSaticiBasvuruDegTx.getRedSenaryoKey1() + "' and key2 ='" + birSaticiBasvuruDegTx.getRedSenaryoKey2() + "' and key3 = '" + birSaticiBasvuruDegTx.getRedSenaryoKey3() + "' ");
			rSet = stmt.executeQuery();

			if (rSet.next()) {
				iMap.put("SENARYO", rSet.getBigDecimal("ID"));
			}
			else {
				iMap.put("SENARYO", (String) null);
			}

			iMap.put("ACIKLAMA", birSaticiBasvuruDegTx.getAciklama());
			iMap.put("BASVURU_NO", birSaticiBasvuruDegTx.getBasvuruNo());
			iMap.put("KARAR", birSaticiBasvuruDegTx.getKarar().equals("KABUL") ? true : false);

			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	
	
	@GraymoundService("BNSPR_TRN8063_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_trn8063.get_tcmb_sorgu_sonuc(?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(i);

			return DALUtil.rSetResults(rSet, "RESULTS");

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY8063_GET_TCMB_CEK_GERCEK")
	public static GMMap getTcmbCekGercek(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn8063.rc_qry8063_get_tcmb_cek_gercek(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCMB_SORGU_ID"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY8063_GET_TCMB_PROTESTOLU_SENET")
	public static GMMap getTcmbProtestoluSenet(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn8063.rc_qry8063_get_tcmb_prot_senet(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCMB_SORGU_ID"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY8063_GET_TCMB_KARA_LISTE")
	public static GMMap getTcmbKaraListe(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn8063.rc_qry8063_get_tcmb_kara_liste(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCMB_SORGU_ID"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY8063_GET_TCMB_EHACIZ")
	public static GMMap getTcmbEHaciz(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn8063.rc_qry8063_get_tcmb_ehaciz(?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCMB_SORGU_ID"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY8063_GET_TCMB_CAPRAZ_SROGU")
	public static GMMap getCaprazSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn8063.rc_qry8063_get_capraz_sorgu(?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VERGINO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCKN"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN8063_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			if (iMap.getBigDecimal("BASVURU_NO") == null) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Basvuru No secilmelidir!");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", (GMMap) null).getBigDecimal("TRX_NO"));

			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiBasvuruDegTx  birSaticiBasvuruDegtx = (BirSaticiBasvuruDegTx) session.get(BirSaticiBasvuruDegTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if (birSaticiBasvuruDegtx == null) {
				birSaticiBasvuruDegtx = new BirSaticiBasvuruDegTx(iMap.getBigDecimal("TRX_NO"));
			}

			birSaticiBasvuruDegtx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birSaticiBasvuruDegtx.setKarar(iMap.getBoolean("KABUL_MU") ? "KABUL" : "RED");
			birSaticiBasvuruDegtx.setKarar(iMap.getBoolean("IADE_MI") ? "IADE" : birSaticiBasvuruDegtx.getKarar());
			birSaticiBasvuruDegtx.setAciklama(iMap.getString("ACIKLAMA"));

			conn = DALUtil.getGMConnection();

			if (StringUtils.isNotBlank(iMap.getString("SENARYO"))) {
				String musteri_tipi;
				String senaryo;

				senaryo = iMap.getString("SENARYO");

				if (StringUtils.isNotBlank(iMap.getString("TCKN"))) {
					musteri_tipi = "G";
				}
				else {
					musteri_tipi = "T";
				}

				stmt = conn.prepareStatement("select * from gnl_param_text where kod='BAYI_BAS_SORGU_SENARYO' and key3='" + senaryo + "' and key2='" + musteri_tipi + "'");
				rSet = stmt.executeQuery();

				if (rSet.next()) {

					birSaticiBasvuruDegtx.setRedSenaryoKey1(rSet.getString("KEY1"));
					birSaticiBasvuruDegtx.setRedSenaryoKey2(rSet.getString("KEY2"));
					birSaticiBasvuruDegtx.setRedSenaryoKey3(rSet.getString("KEY3"));
				}
			}

			session.saveOrUpdate(birSaticiBasvuruDegtx);
			
			session.flush();
			/*
			BpmProcessDetail bpmProcessDetail = (BpmProcessDetail) session.get(BpmProcessDetail.class, iMap.getString("PROCESS_INSTANCE_ID"));
			
			if(bpmProcessDetail != null){
				BpmTaskId bpmTaskId = new BpmTaskId();
				bpmTaskId.setProcessInstanceId(iMap.getString("PROCESS_INSTANCE_ID"));
				bpmTaskId.setTaskId(iMap.getString("TASK_ID"));
				bpmTaskId.setTrxNo(iMap.getBigDecimal("TRX_NO").toString());
				
				BpmTask task = new BpmTask(bpmTaskId,bpmProcessDetail);
				
				session.save(task);
				session.flush();
			} */

			iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap));

			return oMap;
		}
		catch (NonUniqueObjectException e) {
			return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", new GMMap().put("HATA_NO", 723).put("P1", "TxNo, Basvuru No, Karar, Senaryo, Aciklama"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	

}
