package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirKampSaticiKriterTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKampSaticiIliskiTx;
import tr.com.calikbank.bnspr.dao.BirKampSaticiIliskiTxId;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3223Services {

	@GraymoundService("BNSPR_TRN3223_GET_DAGITICI_BAYI_LIST")
	public static GMMap getDagiticiBayiList(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName1 = "FIRMA_LIST";
		String tableName2 = "BAYI_LIST";

		try {
			Connection conn = DALUtil.getGMConnection();
			CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getDagiticiBayiList(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("KAMPANYA_KODU"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.execute();

			// dagitici
			ResultSet rSet1 = (ResultSet) stmt.getObject(2);
			int row1 = 0;
			while (rSet1.next()) {
				int j = 1;
				oMap.put(tableName1, row1, "FIRMA_SEC", GuimlUtil.convertToCheckBoxSelected(rSet1.getString(j++)));
				oMap.put(tableName1, row1, "FIRMA_KODU", rSet1.getBigDecimal(j++));
				oMap.put(tableName1, row1, "FIRMA_ADI", rSet1.getString(j++));
				oMap.put(tableName1, row1, "FIRMA_SEC_ILK", oMap.get(tableName1, row1, "FIRMA_SEC"));
				row1++;
			}
			GMServerDatasource.close(rSet1);

			// bayi
			ResultSet rSet2 = (ResultSet) stmt.getObject(3);
			int row2 = 0;
			while (rSet2.next()) {
				int y = 1;
				oMap.put(tableName2, row2, "BAYI_SEC", GuimlUtil.convertToCheckBoxSelected(rSet2.getString(y++)));
				oMap.put(tableName2, row2, "BAYI_KODU", rSet2.getBigDecimal(y++));
				oMap.put(tableName2, row2, "BAYI_ADI", rSet2.getString(y++));
				oMap.put(tableName2, row2, "MERKEZ_SUBE", rSet2.getString(y++));
				oMap.put(tableName2, row2, "F_K", rSet2.getString(y++));
				oMap.put(tableName2, row2, "MERKEZ_BAYI_KOD", rSet2.getString(y++));
				oMap.put(tableName2, row2, "MERKEZ_BAYI_ADI", rSet2.getString(y++));
				oMap.put(tableName2, row2, "BAYI_SEC_ILK", oMap.get(tableName2, row2, "BAYI_SEC"));
				row2++;

			}
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_DAGITICI_TUMUNU_SEC_KALDIR")
	public static GMMap dagiticiTumunuSecKaldir(GMMap iMap) {
		GMMap oMap = new GMMap();
		ResultSet rSet2 = null;

		try {
			if (iMap.getBigDecimal("KAMPANYA_KODU") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "KAMPANYA_KODU");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			String tableName = "FIRMA_LIST";
			String tableName2 = "BAYI_LIST";
			List<?> firmaList = (List<?>) iMap.get(tableName);

			for (int i = 0; i < firmaList.size(); i++) {
				oMap.put(tableName, i, "FIRMA_SEC", iMap.getBoolean("T_F"));
				oMap.put(tableName, i, "FIRMA_KODU", iMap.getBigDecimal(tableName, i, "FIRMA_KODU"));
				oMap.put(tableName, i, "FIRMA_ADI", iMap.getString(tableName, i, "FIRMA_ADI"));
			}
			List<?> firmaList2 = (List<?>) oMap.get(tableName);
			int row = 0;
			for (int k = 0; k < firmaList2.size(); k++) {
				if (oMap.getBoolean(tableName, k, "FIRMA_SEC")) {
					Connection conn = DALUtil.getGMConnection();
					CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getBayiList(?,?,?)}");
					stmt.setBigDecimal(1, iMap.getBigDecimal("KAMPANYA_KODU"));
					stmt.setBigDecimal(2, oMap.getBigDecimal(tableName, k, "FIRMA_KODU"));
					stmt.registerOutParameter(3, -10);
					stmt.execute();

					rSet2 = (ResultSet) stmt.getObject(3);
					while (rSet2.next()) {
						int y = 1;
						oMap.put(tableName2, row, "BAYI_SEC", GuimlUtil.convertToCheckBoxSelected(rSet2.getString(y++)));
						oMap.put(tableName2, row, "BAYI_KODU", rSet2.getBigDecimal(y++));
						oMap.put(tableName2, row, "BAYI_ADI", rSet2.getString(y++));
						oMap.put(tableName2, row, "MERKEZ_SUBE", rSet2.getString(y++));
						oMap.put(tableName2, row, "F_K", rSet2.getString(y++));
						oMap.put(tableName2, row, "MERKEZ_BAYI_KOD", rSet2.getString(y++));
						oMap.put(tableName2, row, "MERKEZ_BAYI_ADI", rSet2.getString(y++));
						row++;

					}
					GMServerDatasource.close(rSet2);
					GMServerDatasource.close(stmt);
					GMServerDatasource.close(conn);
				}
			}
			List<?> bayiList = (List<?>) oMap.get(tableName2);
			List<HashMap> bayiList2 = new ArrayList<HashMap>();
			Map<BigDecimal, Integer> bayiSet = new HashMap<BigDecimal, Integer>();
			for (int i = 0; bayiList != null && i < bayiList.size(); i++) {
				bayiSet.put(oMap.getBigDecimal(tableName2, i, "BAYI_KODU"), i);
			}
			for (Map.Entry<BigDecimal, Integer> bayiKodu : bayiSet.entrySet()) {
				bayiList2.add((HashMap) bayiList.get(bayiKodu.getValue()));
			}
			oMap.put("BAYI_LIST", bayiList2);
			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_BAYI_TUMUNU_SEC_KALDIR")
	public static GMMap bayiTumunuSecKaldir(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String tableName = "BAYI_LIST";
			List<?> bayiList = (List<?>) iMap.get("BAYI_LIST");

			for (int i = 0; i < bayiList.size(); i++) {
				oMap.put(tableName, i, "BAYI_SEC", iMap.getBoolean("T_F"));
				oMap.put(tableName, i, "BAYI_KODU", iMap.getBigDecimal(tableName, i, "BAYI_KODU"));
				oMap.put(tableName, i, "BAYI_ADI", iMap.getString(tableName, i, "BAYI_ADI"));
				oMap.put(tableName, i, "MERKEZ_SUBE", iMap.getString(tableName, i, "MERKEZ_SUBE"));
				oMap.put(tableName, i, "F_K", iMap.getString(tableName, i, "F_K"));
				oMap.put(tableName, i, "MERKEZ_BAYI_KOD", iMap.getString(tableName, i, "MERKEZ_BAYI_KOD"));
				oMap.put(tableName, i, "MERKEZ_BAYI_ADI", iMap.getString(tableName, i, "MERKEZ_BAYI_ADI"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_KAMPANYA_TUMUNU_SEC_KALDIR")
	public static GMMap kampanyaTumunuSecKaldir(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String tableName = "KAMPANYA_LIST";
			List<?> kampanyaList = (List<?>) iMap.get("KAMPANYA_LIST");
			for (int i = 0; i < kampanyaList.size(); i++) {
				oMap.put(tableName, i, "KAMPANYA_SEC", iMap.getBoolean("T_F"));
				oMap.put(tableName, i, "KAMPANYA_KODU", iMap.getBigDecimal(tableName, i, "KAMPANYA_KODU"));
				oMap.put(tableName, i, "KAMPANYA_ADI", iMap.getString(tableName, i, "KAMPANYA_ADI"));
			}
			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_SAVE")
	public static Map<?, ?> save(GMMap iMap) {

		String tableName1 = "FIRMA_LIST";
		String tableName2 = "BAYI_LIST";
		String tableName3 = "KAMPANYA_LIST";

		try {

			if (iMap.getBigDecimal("TAB_SECIM").compareTo(new BigDecimal(0)) == 0) {

				if (iMap.getBigDecimal("KAMPANYA_KODU") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "KAMPANYA_KODU");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				Session session = DAOSession.getSession("BNSPRDal");
				BirKampSaticiKriterTx birKampSaticiKriterTx = new BirKampSaticiKriterTx();
				birKampSaticiKriterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birKampSaticiKriterTx.setKampBayi("K");
				birKampSaticiKriterTx.setDagiticiTumunu(iMap.getString("DAGITICI_TUMUNU"));
				birKampSaticiKriterTx.setMerkezSubeTumunu(iMap.getString("BAYI_TUMUNU"));

				session.save(birKampSaticiKriterTx);
				session.flush();

				Connection conn = DALUtil.getGMConnection();
				CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getKampanyaKanalBul(?,?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("KAMPANYA_KODU"));
				stmt.registerOutParameter(2, -10);
				stmt.execute();
				ResultSet rSet = (ResultSet) stmt.getObject(2);
				ArrayList<BigDecimal> kampKnlList = new ArrayList<BigDecimal>();
				while (rSet.next()) {
					kampKnlList.add(rSet.getBigDecimal(1));
				}
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
				// SATICILAR (FIRMA)
				List<?> listFirma = (List<?>) iMap.get("FIRMA_LIST");
				for (int j = 0; j < listFirma.size(); j++) {
					for (int k = 0; k < kampKnlList.size(); k++) {
						if (iMap.getBoolean(tableName1, j, "FIRMA_SEC") != iMap.getBoolean(tableName1, j, "FIRMA_SEC_ILK")) {
							BirKampSaticiIliskiTx birKampSaticiIliskiTx = new BirKampSaticiIliskiTx();
							BirKampSaticiIliskiTxId id = new BirKampSaticiIliskiTxId();

							id.setTxNo(iMap.getBigDecimal("TRX_NO"));
							id.setKampKnlKod(kampKnlList.get(k));
							id.setSaticiKod(iMap.getBigDecimal(tableName1, j, "FIRMA_KODU"));

							birKampSaticiIliskiTx.setId(id);
							birKampSaticiIliskiTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName1, j, "FIRMA_SEC")));

							session.save(birKampSaticiIliskiTx);
							session.flush();
						}
					}
				}
				// SATICILAR(BAYI)
				List<?> listBayi = (List<?>) iMap.get("BAYI_LIST");
				for (int j = 0; j < listBayi.size(); j++) {
					for (int k = 0; k < kampKnlList.size(); k++) {
						if (iMap.getBoolean(tableName2, j, "BAYI_SEC") != iMap.getBoolean(tableName2, j, "BAYI_SEC_ILK")) {
							BirKampSaticiIliskiTx birKampSaticiIliskiTx = new BirKampSaticiIliskiTx();
							BirKampSaticiIliskiTxId id = new BirKampSaticiIliskiTxId();

							id.setTxNo(iMap.getBigDecimal("TRX_NO"));
							id.setKampKnlKod(kampKnlList.get(k));
							id.setSaticiKod(iMap.getBigDecimal(tableName2, j, "BAYI_KODU"));

							birKampSaticiIliskiTx.setId(id);
							birKampSaticiIliskiTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName2, j, "BAYI_SEC")));

							session.save(birKampSaticiIliskiTx);
							session.flush();
						}
					}
				}
			}
			else {
				/*if (iMap.getBigDecimal("BAYI_KODU") == null){
				    iMap.put("HATA_NO" , new BigDecimal(330));
				    iMap.put("P1" , "BAYI_KODU");
				    GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
				}*/
				// KAMPANYA
				List<?> listKampanya = (List<?>) iMap.get("KAMPANYA_LIST");
				Session session = DAOSession.getSession("BNSPRDal");
				BirKampSaticiKriterTx birKampSaticiKriterTx = new BirKampSaticiKriterTx();
				birKampSaticiKriterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birKampSaticiKriterTx.setKampBayi("B");
				birKampSaticiKriterTx.setKampanyaTumunu(iMap.getString("KAMPANYA_TUMUNU"));

				session.save(birKampSaticiKriterTx);
				session.flush();

				for (int j = 0; j < listKampanya.size(); j++) {
					Connection conn = DALUtil.getGMConnection();
					CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getKampanyaKanalBul(?,?)}");
					stmt.setBigDecimal(1, iMap.getBigDecimal(tableName3, j, "KAMPANYA_KODU"));
					stmt.registerOutParameter(2, -10);
					stmt.execute();
					ResultSet rSet = (ResultSet) stmt.getObject(2);
					ArrayList<BigDecimal> kampKnlList = new ArrayList<BigDecimal>();
					while (rSet.next()) {
						kampKnlList.add(rSet.getBigDecimal(1));
					}
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);
					GMServerDatasource.close(conn);

					if (iMap.getBigDecimal("BAYI_KODU") != null) {
						for (int k = 0; k < kampKnlList.size(); k++) {
							if (iMap.getBoolean(tableName3, j, "KAMPANYA_SEC") != iMap.getBoolean(tableName3, j, "KAMPANYA_SEC_ILK")) {
								BirKampSaticiIliskiTx birKampSaticiIliskiTx = new BirKampSaticiIliskiTx();
								BirKampSaticiIliskiTxId id = new BirKampSaticiIliskiTxId();

								id.setTxNo(iMap.getBigDecimal("TRX_NO"));
								id.setKampKnlKod(kampKnlList.get(k));
								id.setSaticiKod(iMap.getBigDecimal("BAYI_KODU"));

								birKampSaticiIliskiTx.setId(id);
								birKampSaticiIliskiTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName3, j, "KAMPANYA_SEC")));

								session.save(birKampSaticiIliskiTx);
								session.flush();
							}
						}
					}
					if (iMap.getBigDecimal("DAGITICI_KODU") != null) {
						for (int k = 0; k < kampKnlList.size(); k++) {
							if (iMap.getBoolean(tableName3, j, "KAMPANYA_SEC") != iMap.getBoolean(tableName3, j, "KAMPANYA_SEC_ILK")) {
								BirKampSaticiIliskiTx birKampSaticiIliskiTx = new BirKampSaticiIliskiTx();
								BirKampSaticiIliskiTxId id = new BirKampSaticiIliskiTxId();

								id.setTxNo(iMap.getBigDecimal("TRX_NO"));
								id.setKampKnlKod(kampKnlList.get(k));
								id.setSaticiKod(iMap.getBigDecimal("DAGITICI_KODU"));

								birKampSaticiIliskiTx.setId(id);
								birKampSaticiIliskiTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName3, j, "KAMPANYA_SEC")));

								session.save(birKampSaticiIliskiTx);
								session.flush();
							}
						}
					}

				}
			}
			iMap.put("TRX_NAME", "3223");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_FILL_BAYI_LIST")
	public static GMMap fillBayiList(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName2 = "BAYI_LIST";
		try {
			List<?> firmaList = (List<?>) iMap.get("FIRMA_LIST");
			int row2 = 0;
			for (int k = 0; k < firmaList.size(); k++) {
				if (iMap.getBoolean("FIRMA_LIST", k, "FIRMA_SEC")) {
					Connection conn = DALUtil.getGMConnection();
					CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getBayiList(?,?,?)}");
					stmt.setBigDecimal(1, iMap.getBigDecimal("KAMPANYA_KODU"));
					stmt.setBigDecimal(2, iMap.getBigDecimal("FIRMA_LIST", k, "FIRMA_KODU"));
					stmt.registerOutParameter(3, -10);
					stmt.execute();

					ResultSet rSet2 = (ResultSet) stmt.getObject(3);

					while (rSet2.next()) {
						int y = 1;
						oMap.put(tableName2, row2, "BAYI_SEC", GuimlUtil.convertToCheckBoxSelected(rSet2.getString(y++)));
						oMap.put(tableName2, row2, "BAYI_KODU", rSet2.getBigDecimal(y++));
						oMap.put(tableName2, row2, "BAYI_ADI", rSet2.getString(y++));
						oMap.put(tableName2, row2, "MERKEZ_SUBE", rSet2.getString(y++));
						oMap.put(tableName2, row2, "F_K", rSet2.getString(y++));
						oMap.put(tableName2, row2, "MERKEZ_BAYI_KOD", rSet2.getString(y++));
						oMap.put(tableName2, row2, "MERKEZ_BAYI_ADI", rSet2.getString(y++));
						oMap.put(tableName2, row2, "BAYI_SEC_ILK", oMap.get(tableName2, row2, "BAYI_SEC"));
						row2++;
					}
					GMServerDatasource.close(rSet2);
					GMServerDatasource.close(stmt);
					GMServerDatasource.close(conn);
				}
			}
			List<?> bayiList = (List<?>) oMap.get(tableName2);
			List<HashMap> bayiList2 = new ArrayList<HashMap>();
			Map<BigDecimal, Integer> bayiSet = new HashMap<BigDecimal, Integer>();
			for (int i = 0; bayiList != null && i < bayiList.size(); i++) {
				bayiSet.put(oMap.getBigDecimal(tableName2, i, "BAYI_KODU"), i);
			}
			for (Map.Entry<BigDecimal, Integer> bayiKodu : bayiSet.entrySet()) {
				bayiList2.add((HashMap) bayiList.get(bayiKodu.getValue()));
			}
			Collections.sort(bayiList2, new ComparatorBayiKod());
			oMap.put("BAYI_LIST", bayiList2);
			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_GET_KAMPANYA_LIST")
	public static GMMap getKampanyaList(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "KAMPANYA_LIST";
		try {
			Connection conn = DALUtil.getGMConnection();
			CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getKampanyaList(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BAYI_KODU"));
			stmt.registerOutParameter(2, -10);
			stmt.execute();

			ResultSet rSet = (ResultSet) stmt.getObject(2);
			int row = 0;

			while (rSet.next()) {
				int j = 1;
				oMap.put(tableName, row, "KAMPANYA_SEC", GuimlUtil.convertToCheckBoxSelected(rSet.getString(j++)));
				oMap.put(tableName, row, "KAMPANYA_KODU", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KAMPANYA_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KAMPANYA_SEC_ILK", oMap.get(tableName, row, "KAMPANYA_SEC"));
				row++;
			}
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_GET_KAMPANYA_LIST2")
	public static GMMap getKampanyaList2(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "KAMPANYA_LIST";
		try {
			Connection conn = DALUtil.getGMConnection();
			CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getKampanyaList2(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BAYI_KODU"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("DAGITICI_KODU"));

			stmt.registerOutParameter(3, -10);
			stmt.execute();

			ResultSet rSet = (ResultSet) stmt.getObject(3);
			int row = 0;

			while (rSet.next()) {
				int j = 1;
				oMap.put(tableName, row, "KAMPANYA_SEC", GuimlUtil.convertToCheckBoxSelected(rSet.getString(j++)));
				oMap.put(tableName, row, "KAMPANYA_KODU", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KAMPANYA_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KAMPANYA_SEC_ILK", oMap.get(tableName, row, "KAMPANYA_SEC"));
				row++;
			}
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_GET_KAMPANYA_LIST3")
	public static GMMap getKampanyaList3(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "KAMPANYA_LIST";
		try {
			Connection conn = DALUtil.getGMConnection();
			CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getKampanyaList(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("DAGITICI_KODU"));
			stmt.registerOutParameter(2, -10);
			stmt.execute();

			ResultSet rSet = (ResultSet) stmt.getObject(2);
			int row = 0;

			while (rSet.next()) {
				int j = 1;
				oMap.put(tableName, row, "KAMPANYA_SEC", GuimlUtil.convertToCheckBoxSelected(rSet.getString(j++)));
				oMap.put(tableName, row, "KAMPANYA_KODU", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KAMPANYA_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KAMPANYA_SEC_ILK", oMap.get(tableName, row, "KAMPANYA_SEC"));
				row++;
			}
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3223_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			ArrayList<String> keyColumns = new ArrayList<String>();
			keyColumns.add("KAMPANYA_KODU");
			keyColumns.add("KAMPANYA_SEC");
			Connection conn = DALUtil.getGMConnection();
			CallableStatement stmt = conn.prepareCall("{call PKG_TRN3223.getinfo(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(2, -10);
			stmt.execute();
			ResultSet rSet = (ResultSet) stmt.getObject(2);
			getInfoWithTxNo(oMap, rSet);
			stmt.close();
			rSet.close();
			String tableName = "KAMPANYA_LIST";
			String tableName1 = "FIRMA_LIST";
			String tableName2 = "BAYI_LIST";
			Boolean flag = false;

			if (!StringUtil.isEmpty(oMap.getString("KAMPANYA_KODU"))) {
				stmt = conn.prepareCall("{? = call PKG_Renklendirme.onceki_txno_3223(?,?,?)}");
				stmt.registerOutParameter(1, Types.NUMERIC);
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.setBigDecimal(3, oMap.getBigDecimal("KAMPANYA_KODU"));
				stmt.setBigDecimal(4, null);

			}
			else {
				stmt = conn.prepareCall("{? = call PKG_Renklendirme.onceki_txno_3223(?,?,?)}");
				stmt.registerOutParameter(1, Types.NUMERIC);
				stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
				stmt.setBigDecimal(3, oMap.getBigDecimal("BAYI_KODU"));
				stmt.setBigDecimal(4, oMap.getBigDecimal("DAGITICI_KODU"));

				flag = true;
			}

			stmt.execute();
			BigDecimal trxNo = stmt.getBigDecimal(1);
			GMMap eskiMap = new GMMap();
			if (trxNo != null) {
				stmt.close();
				rSet.close();
				stmt = conn.prepareCall("{call PKG_TRN3223.getinfo(?,?)}");
				stmt.setBigDecimal(1, trxNo);
				stmt.registerOutParameter(2, -10);
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(2);
				getInfoWithTxNo(eskiMap, rSet);
				// oMap.putAll(BeanSetProperties.mapDifference(eskiMap , oMap));
			}
			if (flag) {
				oMap.put("KAMPANYA_LIST_COLOR", BeanSetProperties.tableDifference((ArrayList<?>) eskiMap.get(tableName), (ArrayList<?>) oMap.get(tableName), keyColumns).get("COLOR_DATA"));
			}
			else {
				keyColumns = new ArrayList<String>();
				keyColumns.add("FIRMA_KODU");
				keyColumns.add("FIRMA_SEC");
				oMap.put("DAGITICI_COLOR_DATA", BeanSetProperties.tableDifference((ArrayList<?>) eskiMap.get(tableName1), (ArrayList<?>) oMap.get(tableName1), keyColumns).get("COLOR_DATA"));
				keyColumns = new ArrayList<String>();
				keyColumns.add("BAYI_KODU");
				// keyColumns.add("BAYI_SEC");
				oMap.put("BAYI_COLOR_DATA", BeanSetProperties.tableDifference((ArrayList<?>) eskiMap.get(tableName2), (ArrayList<?>) oMap.get(tableName2), keyColumns).get("COLOR_DATA"));
			}

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	private static void getInfoWithTxNo(GMMap oMap, ResultSet rSet) {
		String tableName1 = "FIRMA_LIST";
		String tableName2 = "BAYI_LIST";
		String tableName3 = "KAMPANYA_LIST";
		int row1 = 0;
		int row2 = 0;
		int row3 = 0;
		try {
			while (rSet.next()) {
				if (rSet.getBigDecimal("KAMP_BAYI").compareTo(new BigDecimal(0)) == 0) {
					oMap.put("KAMP_BAYI", rSet.getBigDecimal("KAMP_BAYI"));
					oMap.put("KAMPANYA_KODU", rSet.getBigDecimal("KAMPANYA_KODU"));
					oMap.put("KAMPANYA_ADI", rSet.getString("KAMPANYA_ADI"));
					oMap.put("DAGITICI_TUMUNU", rSet.getBoolean("DAGITICI_TUMUNU"));
					oMap.put("BAYI_TUMUNU", rSet.getBoolean("BAYI_TUMUNU"));
					if (rSet.getString("SATICI_TIP").compareTo("D") == 0) {
						oMap.put(tableName1, row1, "FIRMA_SEC", GuimlUtil.convertToCheckBoxSelected(rSet.getString("SEC")));
						oMap.put(tableName1, row1, "FIRMA_KODU", rSet.getBigDecimal("SATICI_KODU"));
						oMap.put(tableName1, row1, "FIRMA_ADI", rSet.getString("SATICI_ADI"));
						row1++;
					}
					if (rSet.getString("SATICI_TIP").compareTo("D") != 0 & GuimlUtil.convertToCheckBoxSelected(rSet.getString("SEC"))) {
						oMap.put(tableName2, row2, "BAYI_SEC", GuimlUtil.convertToCheckBoxSelected(rSet.getString("SEC")));
						oMap.put(tableName2, row2, "BAYI_KODU", rSet.getBigDecimal("SATICI_KODU"));
						oMap.put(tableName2, row2, "BAYI_ADI", rSet.getString("SATICI_ADI"));
						oMap.put(tableName2, row2, "MERKEZ_SUBE", rSet.getString("SATICI_TIP"));
						oMap.put(tableName2, row2, "F_K", rSet.getString("BAGLI_DAGITICI_KOD"));
						oMap.put(tableName2, row2, "MERKEZ_BAYI_KOD", rSet.getString("BAGLI_MERKEZ_BAYI"));
						oMap.put(tableName2, row2, "MERKEZ_BAYI_ADI", rSet.getString("BAGLI_MERKEZ_BAYI_AD"));
						row2++;
					}
				}
				else {
					oMap.put("KAMP_BAYI", rSet.getBigDecimal("KAMP_BAYI"));
					oMap.put("BAYI_KODU", rSet.getBigDecimal("SATICI_KOD"));
					oMap.put("BAYI_ADI", rSet.getString("SATICI_ADI"));
					oMap.put("DAGITICI_KODU", rSet.getBigDecimal("DAGITICI_KOD"));
					oMap.put("DAGITICI_ADI", rSet.getString("DAGITICI_ADI"));
					oMap.put("KAMPANYA_TUMUNU", rSet.getBoolean("KAMPANYA_TUMUNU"));
					oMap.put(tableName3, row3, "KAMPANYA_KODU", rSet.getBigDecimal("KAMPANYA_KODU"));
					oMap.put(tableName3, row3, "KAMPANYA_SEC", GuimlUtil.convertToCheckBoxSelected(rSet.getString("SEC")));
					oMap.put(tableName3, row3, "KAMPANYA_ADI", rSet.getString("KAMPANYA_ADI"));
					row3++;
				}
			}
			if (oMap.get("KAMPANYA_TUMUNU") == null) {
				oMap.put("KAMPANYA_TUMUNU", false);
			}
			if (oMap.get("DAGITICI_TUMUNU") == null) {
				oMap.put("DAGITICI_TUMUNU", false);
			}
			if (oMap.get("BAYI_TUMUNU") == null) {
				oMap.put("BAYI_TUMUNU", false);
			}
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
}

class ComparatorBayiKod implements Comparator<HashMap> {

	@Override
	public int compare(HashMap o1, HashMap o2) {
		return new Integer(Integer.parseInt(((String) o1.get("BAYI_KODU")))).compareTo(new Integer(Integer.parseInt(((String) o2.get("BAYI_KODU")))));
	}

}
