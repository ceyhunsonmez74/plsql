package tr.com.calikbank.bnspr.consumerloan.services;

import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiTanim;
import tr.com.aktifbank.bnspr.dao.BirSaticiTanimTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8065Services {

	@GraymoundService("BNSPR_TRN8065_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		String listName = "DURUM";
		GuimlUtil.wrapMyCombo(oMap, listName, "G", "Ge�erli");
		GuimlUtil.wrapMyCombo(oMap, listName, "K", "Kapal�");

		return oMap;
	}

	@GraymoundService("BNSPR_TRN8065_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiTanimTx tanim = new BirSaticiTanimTx();

			tanim.setCredit(iMap.getBoolean("CREDIT") ? "E" : "H");
			tanim.setDurum(iMap.getString("DURUM"));
			tanim.setKod(iMap.getBigDecimal("KOD"));
			tanim.setSigorta(iMap.getBoolean("SIGORTA") ? "E" : "H");
			tanim.setTxNo(iMap.getBigDecimal("TRX_NO"));
			tanim.setUpt(iMap.getBoolean("UPT") ? "E" : "H");

			session.save(tanim);
			session.flush();

			iMap.put("TRX_NAME", "8065");

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
	
	@GraymoundService("BNSPR_TRN8065_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");

		BirSaticiTanimTx tx = (BirSaticiTanimTx) session.createCriteria(BirSaticiTanimTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
		BirSaticiTanim tanim = (BirSaticiTanim) session.createCriteria(BirSaticiTanim.class).add(Restrictions.eq("kod", tx.getKod())).uniqueResult();

		oMap.put("DURUM", tx.getDurum());
		oMap.put("CREDIT", GuimlUtil.convertToCheckBoxSelected(tx.getCredit()));
		oMap.put("UPT", GuimlUtil.convertToCheckBoxSelected(tx.getUpt()));
		oMap.put("SIGORTA", GuimlUtil.convertToCheckBoxSelected(tx.getSigorta()));
		oMap.put("TCKN_VKN", tanim.getTckn() != null ? tanim.getTckn() : tanim.getVergiNo());
		oMap.put("AGENT_ADI", tanim.getSaticiAdi());

		return oMap;
	}

	@GraymoundService("BNSPR_TRN8065_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");

		BirSaticiTanim tanim = (BirSaticiTanim) session.createCriteria(BirSaticiTanim.class).add(Restrictions.eq("kod", iMap.getBigDecimal("KOD"))).uniqueResult();

		oMap.put("DURUM", tanim.getDurum());
		oMap.put("CREDIT", GuimlUtil.convertToCheckBoxSelected(tanim.getCredit()));
		oMap.put("UPT", GuimlUtil.convertToCheckBoxSelected(tanim.getUpt()));
		oMap.put("SIGORTA", GuimlUtil.convertToCheckBoxSelected(tanim.getSigorta()));
		oMap.put("TCKN_VKN", tanim.getTckn() != null ? tanim.getTckn() : tanim.getVergiNo());
		oMap.put("AGENT_ADI", tanim.getSaticiAdi());

		return oMap;
	}

}
