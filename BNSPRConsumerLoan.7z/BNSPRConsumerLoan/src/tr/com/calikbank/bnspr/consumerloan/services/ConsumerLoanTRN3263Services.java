package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiTahsisTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3263Services {

    @GraymoundService("BNSPR_TRN3263_GET_GUNCELLEME_YETKI")
    public static GMMap getGuncellemeYetki(GMMap iMap) {
        GMMap oMap = new GMMap();
        Object[] inputValues;
        String func;
        try {

            func = "{? = call pkg_global.get_kullanicikod}";
            iMap.put("KULLANICI_KOD", DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[0]));

            inputValues = new Object[2];
            int i = 0;
            inputValues[i++] = BnsprType.STRING;
            inputValues[i++] = iMap.getString("KULLANICI_KOD");

            func = "{? = call pkg_trn3263.tahsis_guncelleme_yetki(?)}";

            oMap.put("GUNCELLEME_YETKI", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3263_BILGI_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap bilgiFillComboBoxInitialValues(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {

            iMap.put("KOD", "BAYI_STATU_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("BAYI_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "SATICI_TIP_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("SATICI_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "ISYERI_FAAL_KONU_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("FAALIYET_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAGLI_OLD_BOLGE_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("BAGLI_OLD_BOLGE_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            DALUtil.fillComboBox(oMap, "IL_LIST", true, "select kod, il_adi from gnl_il_kod_pr order by il_adi");
            
            iMap.put("ADD_EMPTY_KEY", "E");
            iMap.put("KOD", "BAYI_KAZANIM_KANAL");
            oMap.put("DST_KAZANIM_KANAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3263_PARAMETRE_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap parametreFillComboBoxInitialValues(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            iMap.put("KOD", "CALISMA_SEKLI_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("CALISMA_SEKLI_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAYI_RISK_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("BAYI_RISK_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAYI_STATU_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("BAYI_STATU_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "KISMI_KAPANMA_NEDEN_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("KISMI_KAPANMA_NEDEN_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "KAPANMA_NEDEN_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("KAPANMA_NEDEN_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "ONEM_DERECE_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("ONEM_DERECE_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "YETKI_SEVIYE_KOD");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("YETKI_SEVIYE_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAYI_DISTRIBUTOR_DURUM");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("DISTRIBUTOR_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAYI_KATEGORI_SKOR");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("KATEGORI_SKOR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAYI_CALISMA_ESAS");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("CALISMA_ESAS", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAYI_BLOKAJ_NEDEN");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("BLOKAJ_NEDEN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAYI_BLOKAJ_KREDI_TIP");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("BLOKAJ_KREDI_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("KOD", "BAYI_BLOKAJ_COZUM_ZAMAN");
            iMap.put("ADD_EMPTY_KEY", "E");
            oMap.put("BLOKAJ_COZUM_ZAMAN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            DALUtil.fillComboBox(oMap, "IL_LIST", true, "select kod, il_adi from gnl_il_kod_pr order by il_adi");

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}
    }

    @GraymoundService("BNSPR_TRN3263_GET_BAYI_BILGI")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        Object[] inputValues;
        String func;
        try {
            inputValues = new Object[2];
            int i = 0;
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("SATICI_KOD");

            func = "{? = call pkg_trn3263.get_bayi_bilgileri(?)}";
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BAYI_BILGILERI", inputValues));

            func = "{? = call pkg_trn3263.get_distributor_list(?)}";
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "DISTRIBUTOR_LIST", inputValues));

            func = "{? = call pkg_trn3263.get_bagli_bayi_list(?)}";
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BAGLI_BAYI_LIST", inputValues));

            func = "{? = call pkg_trn3263.get_faaliyet_list(?)}";
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "FAALIYET_LIST", inputValues));

            func = "{? = call pkg_trn3263.bayi_limit_asim_listesi(?)}";
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "LIMIT_ASIM_LIST", inputValues));

            oMap.put("TAHSIS_KAYIT_TARIHI", oMap.getDate("BAYI_BILGILERI", 0, "REC_DATE"));
            oMap.put("TANIM_TARIHI", oMap.getDate("BAYI_BILGILERI", 0, "TANIM_TARIHI"));
            oMap.put("AKTIFLIK_BASVURU", oMap.getString("BAYI_BILGILERI", 0, "AKTIFLIK_BASVURU_KOD"));
            oMap.put("AKTIFLIK_KULLANDIRIM", oMap.getString("BAYI_BILGILERI", 0, "AKTIFLIK_KULLANDIRIM_KOD"));
            oMap.put("RISK_KODU", oMap.getString("BAYI_BILGILERI", 0, "RISK_KOD"));
            oMap.put("POLITIKA_KODU", oMap.getString("BAYI_BILGILERI", 0, "POLITIKA_KOD"));
            oMap.put("SATICI_TIPI", oMap.getString("BAYI_BILGILERI", 0, "SATICI_TIP_KOD"));
            oMap.put("BAGLI_OLDUGU_BOLGE", oMap.getString("BAYI_BILGILERI", 0, "BAGLI_OLD_BOLGE_KOD"));
            oMap.put("SATICI_IL", oMap.getString("BAYI_BILGILERI", 0, "ADRES_IL"));
            oMap.put("YILLIK_CIRO", oMap.getString("BAYI_BILGILERI", 0, "YILLIK_CIRO"));
            oMap.put("BEKLENEN_HACIM", oMap.getString("BAYI_BILGILERI", 0, "BEKLENEN_KREDI_HACMI"));
            oMap.put("POTANSIYEL_KREDI_HACMI", oMap.getString("BAYI_BILGILERI", 0, "POTANSIYEL_KREDI_HACMI"));
            oMap.put("POTANSIYEL_KREDI_GERCEKLESTIRME_ORANI", oMap.getString("BAYI_BILGILERI", 0, "GERCEKLESME_ORANI"));
            oMap.put("BAYIDEN_BEKLENEN_NPL", oMap.getString("BAYI_BILGILERI", 0, "BEKLENEN_NPL"));
            oMap.put("KURUMSAL_LIMIT_E", "E".equals(oMap.getString("BAYI_BILGILERI", 0, "KURUMSAL_LIMIT_EH")) ? true : false);
            oMap.put("KURUMSAL_LIMIT_H", "H".equals(oMap.getString("BAYI_BILGILERI", 0, "KURUMSAL_LIMIT_EH")) ? true : false);
            oMap.put("TESLIMAT_BELGESI_E", "E".equals(oMap.getString("BAYI_BILGILERI", 0, "TESLIMAT_BELGESI_EH")) ? true : false);
            oMap.put("TESLIMAT_BELGESI_H", "H".equals(oMap.getString("BAYI_BILGILERI", 0, "TESLIMAT_BELGESI_EH")) ? true : false);
            oMap.put("GUNLUK_LIMIT", oMap.getString("BAYI_BILGILERI", 0, "BAYI_GUNLUK_LIMIT"));
            oMap.put("AYLIK_LIMIT", oMap.getString("BAYI_BILGILERI", 0, "BAYI_AYLIK_LIMIT"));
            oMap.put("MUSTERI_NO", oMap.getString("BAYI_BILGILERI", 0, "MUSTERI_NO"));
            oMap.put("DST_KAZANIM_KANAL", oMap.getString("BAYI_BILGILERI",0,"DST_KAZANIM_KANAL"));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

    }

    @GraymoundService("BNSPR_TRN3263_GET_BAYI_PARAMETRELERI")
    public static GMMap getBayiParametreleri(GMMap iMap) {
        GMMap oMap = new GMMap();
        Object[] inputValues;
        String func;
        try {
            inputValues = new Object[4];
            int i = 0;
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("SATICI_KOD");
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("TRX_NO");

            func = "{? = call pkg_trn3263.get_bayi_parametreleri(?,?)}";
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BAYI_PARAMETRELERI", inputValues));

            oMap.put("CALISMA_SEKLI_KOD", oMap.getString("BAYI_PARAMETRELERI", 0, "CALISMA_SEKLI_KOD"));
            oMap.put("BAYI_RISK_KOD", oMap.getString("BAYI_PARAMETRELERI", 0, "BAYI_RISK_KOD"));
            oMap.put("BAYI_STATU_KOD", oMap.getString("BAYI_PARAMETRELERI", 0, "BAYI_STATU_KOD"));
            oMap.put("KISMI_KAPANMA_NEDEN_KOD", oMap.getString("BAYI_PARAMETRELERI", 0, "KISMI_KAPANMA_NEDEN_KOD"));
            oMap.put("KAPANMA_NEDEN_KOD", oMap.getString("BAYI_PARAMETRELERI", 0, "KAPANMA_NEDEN_KOD"));
            oMap.put("ONEM_DERECE_KOD", oMap.getString("BAYI_PARAMETRELERI", 0, "ONEM_DERECE_KOD"));
            oMap.put("YETKI_SEVIYE_KOD", oMap.getString("BAYI_PARAMETRELERI", 0, "YETKI_SEVIYE_KOD"));
            oMap.put("DISTRIBUTOR_DURUM", oMap.getString("BAYI_PARAMETRELERI", 0, "DISTRIBUTOR_DURUM"));
            oMap.put("KATEGORI_SKOR", oMap.getString("BAYI_PARAMETRELERI", 0, "KATEGORI_SKOR"));
            oMap.put("KATEGORI_SKOR_TAHSIS", oMap.getString("BAYI_PARAMETRELERI", 0, "KATEGORI_SKOR_TAHSIS"));
            oMap.put("CALISMA_ESAS", oMap.getString("BAYI_PARAMETRELERI", 0, "CALISMA_ESAS"));
            oMap.put("UST_NPL_ORAN", oMap.getString("BAYI_PARAMETRELERI", 0, "UST_NPL_ORAN"));
            oMap.put("BLOKAJ_NEDEN", oMap.getString("BAYI_PARAMETRELERI", 0, "BLOKAJ_NEDEN"));
            oMap.put("GARANTOR_GORUNSUN_E", "E".equals(oMap.getString("BAYI_PARAMETRELERI", 0, "GARANTOR_GORUNSUN_EH")) ? true : false);
            oMap.put("GARANTOR_GORUNSUN_H", "H".equals(oMap.getString("BAYI_PARAMETRELERI", 0, "GARANTOR_GORUNSUN_EH")) ? true : false);
            oMap.put("BLOKAJ_KREDI_TIP", oMap.getString("BAYI_PARAMETRELERI", 0, "BLOKAJ_KREDI_TIP"));
            oMap.put("BLOKAJ_COZUM_ZAMAN", oMap.getString("BAYI_PARAMETRELERI", 0, "BLOKAJ_COZUM_ZAMAN"));
            oMap.put("BLOKAJ_ORAN", oMap.getString("BAYI_PARAMETRELERI", 0, "BLOKAJ_ORAN"));
            oMap.put("MIN_BLOKE_TUTAR", oMap.getString("BAYI_PARAMETRELERI", 0, "MIN_BLOKE_TUTAR"));
            oMap.put("MAX_BLOKE_TUTAR", oMap.getString("BAYI_PARAMETRELERI", 0, "MAX_BLOKE_TUTAR"));
            oMap.put("BLOKE_HESAP", oMap.getString("BAYI_PARAMETRELERI", 0, "BLOKE_HESAP"));

             return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

    }

    @GraymoundService("BNSPR_TRN3263_SAVE")
    public static Map<?, ?> save3263(GMMap iMap) {
        Session session = DAOSession.getSession("BNSPRDal");

        BirSaticiTahsis birSaticiTahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", iMap.getBigDecimal("SATICI_KOD"))).uniqueResult();

        BirSatici birSatici = (BirSatici) session.createCriteria(BirSatici.class).add(Restrictions.eq("kod", iMap.getBigDecimal("SATICI_KOD"))).uniqueResult();

        BirSaticiTahsisTx birSaticiTahsisTx = (BirSaticiTahsisTx) session.createCriteria(BirSaticiTahsisTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TX_NO"))).uniqueResult();

        if (birSaticiTahsisTx == null) {
            birSaticiTahsisTx = new BirSaticiTahsisTx();
        }

        birSaticiTahsisTx.setAciklama(birSaticiTahsis.getAciklama());
        birSaticiTahsisTx.setAnaCiroDegisim(birSaticiTahsis.getAnaCiroDegisim());
        birSaticiTahsisTx.setAnaSatisKanal(birSaticiTahsis.getAnaSatisKanal());
        birSaticiTahsisTx.setAylikSatisAdet(birSaticiTahsis.getAylikSatisAdet());
        birSaticiTahsisTx.setAylikSatisTutar(birSaticiTahsis.getAylikSatisTutar());
        birSaticiTahsisTx.setAyniAdresteFaaliyetSuresi(birSaticiTahsis.getAyniAdresteFaaliyetSuresi());
        birSaticiTahsisTx.setAyniSifreBasvuruEh(birSaticiTahsis.getAyniSifreBasvuruEh());
        birSaticiTahsisTx.setBarkodZarfEh(birSaticiTahsis.getBarkodZarfEh());
        birSaticiTahsisTx.setBayiAylikLimit(birSaticiTahsis.getBayiAylikLimit());
        birSaticiTahsisTx.setBayiBeklKrediHacmi(birSaticiTahsis.getBayiBeklKrediHacmi());
        birSaticiTahsisTx.setBayiGunlukLimit(birSaticiTahsis.getBayiGunlukLimit());
        birSaticiTahsisTx.setBayiRiskKod(iMap.getString("BAYI_RISK_KOD"));
        birSaticiTahsisTx.setBayiSegmentKod(birSaticiTahsis.getBayiSegmentKod());
        birSaticiTahsisTx.setBayiSskIsyeriKod(birSaticiTahsis.getBayiSskIsyeriKod());
        birSaticiTahsisTx.setBayiStatuKod(iMap.getString("BAYI_STATU_KOD"));
        birSaticiTahsisTx.setBeklenenKrediHacmi(birSaticiTahsis.getBeklenenKrediHacmi());
        birSaticiTahsisTx.setBeklenenNpl(birSaticiTahsis.getBeklenenNpl());
        birSaticiTahsisTx.setBelgeTeslimEh(birSaticiTahsis.getBelgeTeslimEh());
        birSaticiTahsisTx.setBilgiFormuEh(birSaticiTahsis.getBilgiFormuEh());
        birSaticiTahsisTx.setBlokajCozumZaman(iMap.getString("BLOKAJ_COZUM_ZAMAN"));
        birSaticiTahsisTx.setBlokajKrediTip(iMap.getString("BLOKAJ_KREDI_TIP"));
        birSaticiTahsisTx.setBlokajNeden(iMap.getString("BLOKAJ_NEDEN"));
        birSaticiTahsisTx.setBlokajOran(iMap.getBigDecimal("BLOKAJ_ORAN"));
        birSaticiTahsisTx.setBlokeHesap(iMap.getBigDecimal("BLOKE_HESAP"));
        birSaticiTahsisTx.setBlokeSuresi(birSaticiTahsis.getBlokeSuresi());
        birSaticiTahsisTx.setCalFinans1Eh(birSaticiTahsis.getCalFinans1Eh());
        birSaticiTahsisTx.setCalFinans2Eh(birSaticiTahsis.getCalFinans2Eh());
        birSaticiTahsisTx.setCalFinans3Eh(birSaticiTahsis.getCalFinans3Eh());
        birSaticiTahsisTx.setCalFinans4Eh(birSaticiTahsis.getCalFinans4Eh());
        birSaticiTahsisTx.setCalFinansDiger(birSaticiTahsis.getCalFinansDiger());
        birSaticiTahsisTx.setCalismaEsas(iMap.getString("CALISMA_ESAS"));
        birSaticiTahsisTx.setCalismaSekliKod(iMap.getString("CALISMA_SEKLI_KOD"));
        birSaticiTahsisTx.setDagiticiFirmaTeminatKod(birSaticiTahsis.getDagiticiFirmaTeminatKod());
        birSaticiTahsisTx.setDistributorDurum(iMap.getString("DISTRIBUTOR_DURUM"));
        birSaticiTahsisTx.setDstBayiOran(birSaticiTahsis.getDstBayiOran());
        birSaticiTahsisTx.setDstBorcOran(birSaticiTahsis.getDstBorcOran());
        birSaticiTahsisTx.setDstCiro(birSaticiTahsis.getDstCiro());
        birSaticiTahsisTx.setDstCiroDegisim(birSaticiTahsis.getDstCiroDegisim());
        birSaticiTahsisTx.setDstKazanimKanal(birSaticiTahsis.getDstKazanimKanal());
        birSaticiTahsisTx.setDstKitle(birSaticiTahsis.getDstKitle());
        birSaticiTahsisTx.setDstPazarPay(birSaticiTahsis.getDstPazarPay());
        birSaticiTahsisTx.setDstSenetAgirlik(birSaticiTahsis.getDstSenetAgirlik());
        birSaticiTahsisTx.setDstYatirimBuyukluk(birSaticiTahsis.getDstYatirimBuyukluk());
        birSaticiTahsisTx.setDurum(birSaticiTahsis.getDurum());
        birSaticiTahsisTx.setEkIsyeriAdi(birSaticiTahsis.getEkIsyeriAdi());
        birSaticiTahsisTx.setEkIsyeriVar(birSaticiTahsis.getEkIsyeriVar());
        birSaticiTahsisTx.setFotoCekimEh(birSaticiTahsis.getFotoCekimEh());

        if (iMap.getBoolean("GARANTOR_GORUNSUN_E")) {
            birSaticiTahsisTx.setGarantorGorunsunEh("E");
        } else if (iMap.getBoolean("GARANTOR_GORUNSUN_H")) {
            birSaticiTahsisTx.setGarantorGorunsunEh("H");
        }

        birSaticiTahsisTx.setGayrimenkulAdetArsa(birSaticiTahsis.getGayrimenkulAdetArsa());
        birSaticiTahsisTx.setGayrimenkulAdetDukkan(birSaticiTahsis.getGayrimenkulAdetDukkan());
        birSaticiTahsisTx.setGayrimenkulAdetEv(birSaticiTahsis.getGayrimenkulAdetEv());
        birSaticiTahsisTx.setGpsTakipEh(birSaticiTahsis.getGpsTakipEh());
        birSaticiTahsisTx.setHesapNo(birSatici.getHesapNo());
        birSaticiTahsisTx.setIstihbaratFirmaGorus(birSaticiTahsis.getIstihbaratFirmaGorus());
        birSaticiTahsisTx.setIsyeriKonumKod(birSaticiTahsis.getIsyeriKonumKod());
        birSaticiTahsisTx.setIsyeriMulkiyetKod(birSaticiTahsis.getIsyeriMulkiyetKod());
        birSaticiTahsisTx.setIsyeriYuzolcumu(birSaticiTahsis.getIsyeriYuzolcumu());
        birSaticiTahsisTx.setKapanmaNedenKod(iMap.getString("KAPANMA_NEDEN_KOD"));
        birSaticiTahsisTx.setKategoriSkor(iMap.getString("KATEGORI_SKOR"));
        birSaticiTahsisTx.setKategoriSkorTahsis(iMap.getString("KATEGORI_SKOR_TAHSIS"));
        birSaticiTahsisTx.setKiraBedeli(birSaticiTahsis.getKiraBedeli());
        birSaticiTahsisTx.setKismiKapanmaNedenKod(iMap.getString("KISMI_KAPANMA_NEDEN_KOD"));
        birSaticiTahsisTx.setKod(birSaticiTahsis.getKod());
        birSaticiTahsisTx.setKurumsalGarantorLimit(birSaticiTahsis.getKurumsalGarantorLimit());
        birSaticiTahsisTx.setLimitMerkezBagimsizEh(birSaticiTahsis.getLimitMerkezBagimsizEh());
        birSaticiTahsisTx.setMaliYili(birSaticiTahsis.getMaliYili());
        birSaticiTahsisTx.setMaxBlokeTutar(iMap.getBigDecimal("MAX_BLOKE_TUTAR"));
        birSaticiTahsisTx.setMaxKullLimit(birSaticiTahsis.getMaxKullLimit());
        birSaticiTahsisTx.setMinBlokeTutar(iMap.getBigDecimal("MIN_BLOKE_TUTAR"));
        birSaticiTahsisTx.setMusteriPortfoyKod(birSaticiTahsis.getMusteriPortfoyKod());
        birSaticiTahsisTx.setOnemDereceKod(iMap.getString("ONEM_DERECE_KOD"));
        birSaticiTahsisTx.setOrjEvrakGonSure(birSaticiTahsis.getOrjEvrakGonSure());
        birSaticiTahsisTx.setOrtakSektorTecrubesi(birSaticiTahsis.getOrtakSektorTecrubesi());
        birSaticiTahsisTx.setOtpKontrolEh(birSaticiTahsis.getOtpKontrolEh());
        birSaticiTahsisTx.setPerakendeRezervLimit(birSaticiTahsis.getPerakendeRezervLimit());
        birSaticiTahsisTx.setSatisPersonelSayi(birSaticiTahsis.getSatisPersonelSayi());
        birSaticiTahsisTx.setSermayeTutar(birSaticiTahsis.getSermayeTutar());
        birSaticiTahsisTx.setSubeSayisi(birSaticiTahsis.getSubeSayisi());
        birSaticiTahsisTx.setTasitSayi(birSaticiTahsis.getTasitSayi());
        birSaticiTahsisTx.setTeminatTutar(birSaticiTahsis.getTeminatTutar());
        birSaticiTahsisTx.setTicaretSicilNo(birSaticiTahsis.getTicaretSicilNo());
        birSaticiTahsisTx.setTopCalisanSayi(birSaticiTahsis.getTopCalisanSayi());
        birSaticiTahsisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
        birSaticiTahsisTx.setUstNplOran(iMap.getBigDecimal("UST_NPL_ORAN"));
        birSaticiTahsisTx.setVergiMatrah(birSaticiTahsis.getVergiMatrah());
        birSaticiTahsisTx.setYatirimBuyukluk(birSaticiTahsis.getYatirimBuyukluk());
        birSaticiTahsisTx.setYatirimPlani(birSaticiTahsis.getYatirimPlani());
        birSaticiTahsisTx.setYatirimPlaniAciklama(birSaticiTahsis.getYatirimPlaniAciklama());
        birSaticiTahsisTx.setYetkiSeviyeKod(iMap.getString("YETKI_SEVIYE_KOD"));
        birSaticiTahsisTx.setYillikCiro(birSaticiTahsis.getYillikCiro());

        session.saveOrUpdate(birSaticiTahsisTx);
        session.flush();

        iMap.put("TRX_NAME", "3263");
        return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
    }

    @GraymoundService("BNSPR_TRN3263_GET_INFO")
    public static GMMap trn3263GetInfo(GMMap iMap) {
        
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            
            GMMap oMap = new GMMap();
            GMMap i2Map = new GMMap();
            GMMap oldMap = new GMMap();
            BigDecimal saticiNo;
            
            BirSaticiTahsisTx birSaticiTahsisTx = (BirSaticiTahsisTx) session.createCriteria(BirSaticiTahsisTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            
            saticiNo = birSaticiTahsisTx.getKod();

            i2Map.put("TRX_NO", iMap.get("TRX_NO"));
            i2Map.put("SATICI_NO", saticiNo);
            oldMap.put("TRX_NO",GMServiceExecuter.call("BNSPR_TRN3163_GET_ONCEKI_TX_NO", i2Map).getBigDecimal("OLD_TRX_NO"));
            
            iMap.put("SATICI_NO", saticiNo);
            getDataforColoring(iMap);

            if (oldMap.getBigDecimal("TRX_NO")!=null){
                oldMap.put("SATICI_NO", saticiNo);
                getDataforColoring(oldMap);
            }

            oMap.putAll(BeanSetProperties.mapDifference(oldMap, iMap));
            oMap.putAll(iMap);

            return oMap;

        } catch (Exception e) {
            throw new GMRuntimeException(0, e);
        }
    }

    public static void getDataforColoring(GMMap iMap) {
        iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3263_GET_BAYI_PARAMETRELERI", iMap));
    }

    @GraymoundService("BNSPR_TRN3163_GET_ONCEKI_TX_NO")
    public static GMMap getOncekiTxNo(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN3162.onceki_txno_3162(?,?)}");
            stmt.registerOutParameter(1, Types.NUMERIC);
            stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
            stmt.setBigDecimal(3, iMap.getBigDecimal("SATICI_NO"));
            stmt.execute();

            oMap.put("OLD_TRX_NO", stmt.getBigDecimal(1));

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
}
