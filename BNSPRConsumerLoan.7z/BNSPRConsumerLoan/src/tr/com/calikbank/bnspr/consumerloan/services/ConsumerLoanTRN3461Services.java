package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.tree.DefaultMutableTreeNode;
import org.hibernate.Session;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import tr.com.aktifbank.bnspr.dao.BirUbeSaticiExcelTx;
import tr.com.aktifbank.bnspr.dao.BirUbeSaticiExcelTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.tree.checkbox.TristateTreeNode;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3461Services {
	@GraymoundService("BNSPR_TRN3461_ISLEM_YETKI")
	public static GMMap getIslemYetki(GMMap iMap) {
		GMMap oMap = new GMMap();
		String func = "{? = call pkg_trn3461.islem_yetki(?)}";
		try{
			Object inputValues[]={
				BnsprType.STRING,(String) DALUtil.callOracleFunction("{? = call pkg_global.get_kullanicikod}", BnsprType.STRING)  
			};		
			String yetki = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);			
			oMap.put("ISLEM_YETKI", "E".equals(yetki));			
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3461_IMPORT_EXCELL")
	public static GMMap load3461(GMMap iMap) {	
		GMMap oMap = new GMMap();
		try{			
			byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            int colCount = 0;
            String colNames[] = null;
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
                colCount = workbook.getSheet(0).getColumns();
                if(colCount < 1){
                    throw new GMRuntimeException(0, "Yanl�� Kolon Say�s�.");
                }                
                colNames = new String[colCount];
                for(int i=0;i<colCount;i++) {
                	String colName = workbook.getSheet(0).getCell(i,0).getContents().trim();
                	colNames[i] = colName;                	
                }
            } catch (Exception e) {
                e.printStackTrace();
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            String tableName="TABLO";
            for (int j = 0; j + 1 < sheet.getRows(); j++) {            
            	for(int i=0;i<colCount;i++) {
            		String val =  sheet.getCell(i, (j+1)).getContents().trim();
            		String key =  colNames[i];
            		oMap.put(tableName,j,key,val);
            	}            	
            }
            if(oMap.getSize("TABLO")==0) {
				 iMap.put("MESSAGE_NO", new java.math.BigDecimal(1614));
		         String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
		         throw new GMRuntimeException(0, message);
			}            
            return oMap;
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}


	@GraymoundService("BNSPR_TRN3461_SORGULA")
	public static GMMap sorgula(GMMap iMap) {		
		GMMap oMap = new GMMap();		
		try{
			BigDecimal ubeAktarimNo = iMap.getBigDecimal("UBE_AKTARIM_NO");	
	        if(ubeAktarimNo!=null) {	
				String func = "{? = call pkg_trn3461.sorgula(?)}";
				Object[] inputValues = {
					BnsprType.NUMBER,ubeAktarimNo
				};
				oMap.putAll(DALUtil.callOracleRefCursorFunction(func,"RESULTS", inputValues));
				if(oMap.getSize("RESULTS")==0) {
					 iMap.put("MESSAGE_NO", new java.math.BigDecimal(1614));
			         String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
			         throw new GMRuntimeException(0, message);
				}			
	        }										
			return oMap;
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}
	@GraymoundService("BNSPR_TRN3461_SATICI_OLUSTUR")
	public static GMMap saticiOlustur(GMMap iMap) {		
		GMMap oMap = new GMMap();
		try{		
			BigDecimal ubeAktarimNo = iMap.getBigDecimal("UBE_AKTARIM_NO");
		
			if(ubeAktarimNo==null) {
				throw new Exception("Aktar�m No Se�ilmedi");
			}
			String tableName = "TABLO";
			int len = iMap.getSize(tableName);
			
			for(int i=0;i<len;i++) {				
				String func = "{call pkg_trn3461.satici_sorgula(?,?,?,?,?,?,?)}";
				Object[] inputValues = {
					BnsprType.NUMBER,ubeAktarimNo,
					BnsprType.NUMBER,iMap.getBigDecimal(tableName,i,"DIST_SATICI_KOD"),
					BnsprType.NUMBER,iMap.getBigDecimal(tableName,i,"DIST_BAYI_REF")					
				};					
				Object[] outputValues = {
					BnsprType.REFCURSOR,"SATICI",
					BnsprType.REFCURSOR,"ILISKI",
					BnsprType.REFCURSOR,"CALISAN",
					BnsprType.REFCURSOR,"YETKI"
				};
				GMMap dMap = (GMMap) DALUtil.callOracleProcedure(func, inputValues, outputValues);
				if (dMap.getSize("SATICI")==1) {
					BigDecimal saticiKod = dMap.getBigDecimal("SATICI",0,"SATICI_KOD");
					String do3161 = dMap.getString("SATICI",0,"TRN3161_YAPILACAK");
					String do3162 = dMap.getString("SATICI",0,"TRN3162_YAPILACAK");
					String do3223 = dMap.getString("SATICI",0,"TRN3223_YAPILACAK");
					boolean devamEdilsinMi = true;
					String aciklama = "";
					if(do3161.equals("E") && devamEdilsinMi) {							
					    GMMap tMap = new GMMap();	
					    if (saticiKod==null) {
							tMap.put("TABLE_NAME", "BIR_SATICI");
							saticiKod =  (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", tMap).get("ID");
						}
						String sTrxNo = (String) GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", tMap).get("TRX_NO");
						BigDecimal trxNo = new BigDecimal(sTrxNo);						
						tMap = iMap.getMap(tableName,i);
						tMap.put("TRX_NO", trxNo);
						tMap.put("SATICI_KOD",saticiKod);						
						tMap.put("IL", dMap.getString("SATICI",0,"IL"));
						tMap.put("ILCE", dMap.getString("SATICI",0,"ILCE"));
						tMap.put("TELEFON_ALAN",  dMap.getString("SATICI",0,"TELEFON_ALAN"));
						tMap.put("TELEFON",  dMap.getString("SATICI",0,"TELEFON"));
						tMap.put("FAX_ALAN",  dMap.getString("SATICI",0,"FAX_ALAN"));
						tMap.put("FAKS",  dMap.getString("SATICI",0,"FAKS"));
						tMap.put("ADRES",  dMap.getString("SATICI",0,"ADRES"));
						tMap.put("DI_SATICI_KOD", dMap.getString("SATICI",0,"DI_SATICI_KOD"));
						tMap.put("DI_MUSTERI_NO", dMap.getString("SATICI",0,"DI_MUSTERI_NO"));
						tMap.put("SATICI_IL", dMap.getString("SATICI",0,"SATICI_IL"));
						tMap.put("SATICI_ILCE", dMap.getString("SATICI",0,"SATICI_ILCE"));
						tMap.put("SATICI_TELEFON_ALAN",  dMap.get("SATICI",0,"SATICI_TELEFON_ALAN"));
						tMap.put("SATICI_TELEFON",  dMap.getString("SATICI",0,"SATICI_TELEFON"));
						tMap.put("SATICI_FAX_ALAN",  dMap.getString("SATICI",0,"SATICI_FAX_ALAN"));
						tMap.put("SATICI_FAKS",  dMap.getString("SATICI",0,"SATICI_FAKS"));		
						tMap.put("SATICI_ADRES",dMap.getString("SATICI",0,"SATICI_ADRES"));		
						String ePostaName = dMap.getString("SATICI",0,"E_POSTA_NAME");
						tMap.put("E_POSTA_NAME",(ePostaName==null)?"":ePostaName);
						String ePostaNet  = dMap.getString("SATICI",0,"E_POSTA_NET");
						tMap.put("E_POSTA_NET", (ePostaNet==null)?"":ePostaNet);
						tMap.put("SATICI_TIP", dMap.getString("SATICI",0,"SATICI_TIP")); 
						tMap.put("SATICI_GORUSU",dMap.getString("SATICI",0,"SATICI_GORUSU"));
						tMap.put("BAGLI_OLDUGU_BOLGE",dMap.getString("SATICI",0,"BAGLI_OLDUGU_BOLGE"));
						tMap.put("BAGLI_OLDUGU_MERKEZ_BAYI_KOD", dMap.getString("SATICI",0,"BAGLI_OLDUGU_MERKEZ_BAYI_KOD"));
						tMap.put("DOKUMAN_YOLLAMA_TIPI",dMap.getString("SATICI",0,"DOKUMAN_YOLLAMA_TIPI"));
						tMap.put("DURUM", dMap.getString("SATICI",0,"DURUM"));				
						tMap.put("MUSTERI_NO",dMap.getString("SATICI",0,"MUSTERI_NO"));				
						tMap.put("SIRKET_TIPI", dMap.getString("SATICI",0,"SIRKET_TIPI"));
						tMap.put("VERGI_TCK_NO", dMap.getString("SATICI",0,"VERGI_TCK_NO"));
						tMap.put("VERGI_DAIRESI_IL", dMap.getString("SATICI",0,"VERGI_DAIRESI_IL"));
						tMap.put("VERGI_DAIRESI", dMap.getString("SATICI",0,"VERGI_DAIRESI"));
						tMap.put("KURULUS_TARIHI", dMap.getString("SATICI",0,"KURULUS_TARIHI"));
						tMap.put("WEB_ADRESI", dMap.getString("SATICI",0,"WEB_ADRESI"));
						tMap.put("PARA_CIKISI", dMap.getString("SATICI",0,"PARA_CIKISI"));
						tMap.put("BANKA_KOD", dMap.getString("SATICI",0,"BANKA_KOD"));
						tMap.put("SUBE_KOD", dMap.getString("SATICI",0,"SUBE_KOD"));
						tMap.put("HESAP_A", dMap.getString("SATICI",0,"HESAP_A"));
						tMap.put("KREDI_TURU", dMap.getString("SATICI",0,"KREDI_TURU"));
						tMap.put("ACIKLAMA", dMap.getString("SATICI",0,"ACIKLAMA"));
						tMap.put("BAYI_SORUMLU_KISI", dMap.getString("SATICI",0,"BAYI_SORUMLU_KISI"));
						tMap.put("BANKA_TARIHI", dMap.getString("SATICI",0,"BANKA_TARIHI"));
						tMap.put("PORTFOY_KOD", dMap.getString("SATICI",0,"PORTFOY_KOD"));
						tMap.put("SUBE_MUSTERI_NO", dMap.getString("SATICI",0,"SUBE_MUSTERI_NO"));
						tMap.put("DISTRIBUTOR_HESAP_NO", dMap.getString("SATICI",0,"DISTRIBUTOR_HESAP_NO"));
						tMap.put("SIGORTA_SATISI", dMap.getString("SATICI",0,"SIGORTA_SATISI").equals("E"));
						tMap.put("ISIM", dMap.getString("SATICI",0,"ISIM"));
						tMap.put("SOYADI", dMap.getString("SATICI",0,"SOYADI"));
						tMap.put("TICARI_UNVAN", dMap.getString("SATICI",0,"TICARI_UNVAN"));
						tMap.put("IS_FORM_SCREEN",false);
						tMap.put("IBAN", dMap.getString("SATICI",0,"IBAN"));						
						int size=dMap.getSize("CALISAN");
						if(size>0) {
							Set<?> keySet =  dMap.getMap("CALISAN",0).keySet();
							for(int j=0;j<size;j++) {								
								for(Object key:keySet) {
									String keyName = (String) key;									
									Object keyValue = dMap.get("CALISAN",j,keyName);
									tMap.put("CALISANLAR", j, keyName,keyValue);	
								}								
							}
						} 
						
						size=dMap.getSize("ILISKI");
						if(size>0) {
							Set<?> keySet =  dMap.getMap("ILISKI",0).keySet();
							for(int j=0;j<size;j++) {								
								for(Object key:keySet) {
									String keyName = (String) key;
									Object keyValue = null;
									if(keyName.equals("SATICI_KOD")) {
									    keyValue = saticiKod;	
									} else {
										keyValue = dMap.get("ILISKI",j,keyName);
									}
									if(keyName.equals("SEC")) {
										keyValue = dMap.get("ILISKI",j,keyName).equals("E");
									}
									tMap.put("BAGLI_OLDUGU_DAGITICI_FIRMALAR", j, keyName,keyValue);	
								}								
							}							
						}
						size=dMap.getSize("YETKI");
						if(size>0) {
							Set<?> keySet =  dMap.getMap("YETKI",0).keySet();						
							TristateTreeNode root = new TristateTreeNode(new GMMap());							
							for(int j=0;j<size;j++) {
								GMMap map = new GMMap();								
								for(Object key:keySet) {
									String keyName = (String) key;
									Object keyValue = null;
									if(keyName.equals("SELECTED")) {
									   keyValue = dMap.getString("YETKI",j,keyName).equals("E");	
									} else {
									   keyValue = dMap.get("YETKI",j,keyName);
									}									
									map.put(keyName, keyValue);
									tMap.put("ROLES",j,keyName,keyValue);
				            	}								
								root.add(new TristateTreeNode(map));								
							}
							tMap.put("YETKI_SEVIYE_TREE",root);				            						
						}
						
						try {
						    tMap.put("TRX_ONAYSIZ_ISLEM", "E");	
							oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3161_SAVE_AND_CREATE_CONTAKT", tMap));						 
						    tMap.put("ISLEM_NO", trxNo);						
							GMServiceExecuter.execute("BNSPR_TRN3161_AFTER_APPROVAL", tMap);							
							aciklama += oMap.getString("MESSAGE");						
							iMap.put(tableName, i,"SATICI_KOD",saticiKod);
							iMap.put(tableName, i,"MUSTERI_NO",oMap.getBigDecimal("MUSTERI_NO"));
							iMap.put(tableName, i,"SIRKET_TIPI",tMap.getString("SIRKET_TIPI"));								
							iMap.put(tableName, i,"TX_NO_3161",trxNo);
						} catch(Exception e) {
							aciklama += "3161.hata"+e.getMessage()+" trxNo:"+trxNo;
							devamEdilsinMi = false;
						}	
						
					} 
					if(do3162.equals("E") && devamEdilsinMi) {
						try {
							func = "{? = call pkg_trn3461.ube_satici_tahsis_olustur (?,?)}";
							inputValues = new Object[] {
								BnsprType.NUMBER,iMap.getBigDecimal(tableName,i,"DIST_SATICI_KOD"),
								BnsprType.NUMBER,saticiKod
							};
							BigDecimal trx3162 = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
							iMap.put(tableName,i,"TX_NO_3162",trx3162);
						} catch(Exception e) {
							aciklama+="3162.hata:"+e.getMessage();
							devamEdilsinMi = false;
						}
					}
					if(do3223.equals("E") && devamEdilsinMi) {
						try {
							func = "{? = call pkg_trn3461.ube_kampanya_iliski_olustur(?,?)}";
							inputValues = new Object[] {
								BnsprType.NUMBER,iMap.getBigDecimal(tableName,i,"DIST_SATICI_KOD"),
								BnsprType.NUMBER,saticiKod
							};
							BigDecimal trxKampanya = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
							iMap.put(tableName,i,"TX_NO_3223",trxKampanya);													
						} catch(Exception e) {
							aciklama+="3223.Hata :"+e.getMessage();
							devamEdilsinMi = false;
						}
					}					
					iMap.put(tableName, i,"ACIKLAMA",aciklama);	
				}				
			}		
			String sTrxNo = (String) GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", oMap).get("TRX_NO");
			BigDecimal trxNo = new BigDecimal(sTrxNo);
			iMap.put("ID", ubeAktarimNo);
			iMap.put("TX_NO",trxNo);
			iMap.put("TRX_NO",trxNo);							
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3461_SAVE", iMap));	
			return oMap;
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}
	@GraymoundService("BNSPR_TRN3461_SATICI_OLUSTUR_BATCH")
	public static GMMap saticiOlusturBatch(GMMap iMap) {			
		GMMap oMap = new GMMap();
		String func = "";
		Object[] inputValues = {};
		boolean ubeVarMi = false;
		int size = 0;
		try { 
			BigDecimal ubeAktarimNo = iMap.getBigDecimal("UBE_AKTARIM_NO");	
			if(ubeAktarimNo==null) {				
				func = "{? = call pkg_trn3461.ube_batch_id} ";				
				oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
			    size = oMap.getSize("RESULTS");
			} else {
				ubeVarMi = true;
				size = 1;					
			}			
		    for(int i=0;i<size;i++) {
		    	if(!ubeVarMi) {
			    	ubeAktarimNo = oMap.getBigDecimal("RESULTS",i,"ID");
		    	}
		    	func = "{? = call pkg_trn3461.sorgula(?)}";
				inputValues = new Object[] {
					BnsprType.NUMBER,ubeAktarimNo
				};						
				oMap.putAll(DALUtil.callOracleRefCursorFunction(func,"TABLO", inputValues));		    	
				int len = oMap.getSize("TABLO");											
				if (len>0) {  								
					for(int j=0;j<len;j++) { 		
					   GMMap tMap = new GMMap();
					   tMap.put("UBE_AKTARIM_NO", ubeAktarimNo);		
					   tMap.put("TABLO",0,oMap.getMap("TABLO",j));				   			 
					   try {						
					      GMServiceExecuter.executeNT("BNSPR_TRN3461_SATICI_OLUSTUR", tMap);
					      System.out.println(ubeAktarimNo+": OK");					     		       
					   } catch(Exception e) {
						  System.out.println(ubeAktarimNo+":"+e.getMessage());
					   }
					   tMap.clear();
					}		    	
		        }
		    }
		    oMap.put("MESSAGE", "Sat�c� olu�turma i�lemi tamamlanm��t�r");
			return oMap;	
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3461_SAVE")
	public static GMMap save3461(GMMap iMap) {			
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName="TABLO";
			int len = iMap.getSize(tableName);			
	        for(int i=0;i<len;i++) {	     
	        	BirUbeSaticiExcelTx birUbeSaticiExcelTx =  new 	BirUbeSaticiExcelTx(); 
	        	BirUbeSaticiExcelTxId birUbeSaticiExcelTxId =  new 	BirUbeSaticiExcelTxId(); 
	        	Field fields[] = BirUbeSaticiExcelTx.class.getDeclaredFields();
	        	for(Field f:fields) {
	        		String fname = f.getName();
	        		String ftype = f.getType().getSimpleName();
	        		if(fname.equals("serialVersionUID")) {
	        			continue;
	        		}	        	
	        		if(ftype.equals("BirUbeSaticiExcelTxId")) {
	        			Field idFields[] = BirUbeSaticiExcelTxId.class.getDeclaredFields();
	        			for(Field idf:idFields) {
	        				try {
	        				    setValue(idf,tableName,i,iMap,BirUbeSaticiExcelTxId.class,birUbeSaticiExcelTxId);
	        				} catch(Exception e) {
	        					System.out.println(idf.getName()+":"+e.getMessage());
	        				}
	        			}
	        		} else {	
	        			try {
	        			    setValue(f,tableName,i,iMap,BirUbeSaticiExcelTx.class,birUbeSaticiExcelTx);	  
	        			} catch(Exception e) {
        					System.out.println(f.getName()+":"+e.getMessage());
        				}
	        		}
	        	}
	        	birUbeSaticiExcelTx.setId(birUbeSaticiExcelTxId);	        		        		        	
	        	session.save(birUbeSaticiExcelTx);
	        }	      
	        session.flush();	       
	        iMap.put("TRX_NAME", "3461");
			return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}
	
	private static void setValue(Field field,String tableName,int indis,GMMap iMap,Class<?> clazz,Object obj) throws Exception {
		String fname = field.getName();
		String ftype = field.getType().getSimpleName();	
		String ffname = fname;
		String[] patterns = {"[A-Z]","\\d+"};
		for(String p:patterns) {
			Matcher m = Pattern.compile(p).matcher(fname);	        						
			while(m.find()) {		        			    
				ffname = ffname.replaceAll(m.group(),"_"+m.group());
			}			
		}
		ffname = ffname.replaceAll("i","I")
 		               .toUpperCase();			
	    String methodName="set"+fname.substring(0,1).replace("i","I").toUpperCase()+fname.substring(1);	        			 
	    Method method = clazz.getDeclaredMethod(methodName,field.getType());      			   
	    if(ftype.equals("String")) {	        			  
	    	method.invoke(obj,iMap.getString(tableName,indis,ffname));
	    }
	    if(ftype.equals("BigDecimal")) {	
	    	if(ffname.equals("ID") || ffname.equals("TX_NO")) {
	    		method.invoke(obj,iMap.getBigDecimal(ffname));
	    	} else {
	    	    method.invoke(obj,iMap.getBigDecimal(tableName,indis,ffname));
	    	}
	    }
	    if(ftype.equals("Date")) {	        			    	
	    	method.invoke(obj,iMap.getDate(tableName,indis,ffname));
	    }	        				  
	}
}
