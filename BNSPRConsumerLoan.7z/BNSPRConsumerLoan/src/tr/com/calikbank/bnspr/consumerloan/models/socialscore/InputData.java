package tr.com.calikbank.bnspr.consumerloan.models.socialscore;

public class InputData {
	private String timeElapsed;

    private String name;

    private String id;

    public String getTimeElapsed ()
    {
        return timeElapsed;
    }

    public void setTimeElapsed (String timeElapsed)
    {
        this.timeElapsed = timeElapsed;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }
}
