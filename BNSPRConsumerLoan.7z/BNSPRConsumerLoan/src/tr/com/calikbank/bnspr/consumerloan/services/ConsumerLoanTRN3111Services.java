package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKrdUrunSinifPr;
import tr.com.calikbank.bnspr.dao.BirKrdUrunSinifPrTx;
import tr.com.calikbank.bnspr.dao.BirKrdUrunSinifPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3111Services {

	@GraymoundService("BNSPR_TRN3111_FILL_TABLE_COMBOBOX")
	public static GMMap fillTableComboBox(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String listName = "VADE_TIPI";
			GuimlUtil.wrapMyCombo(oMap, listName, "UV", "UZUN VADE");
			GuimlUtil.wrapMyCombo(oMap, listName, "KV", "KISA VADE");
			
			listName = "TEMINATLI";
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "EVET");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "HAYIR");
			
			listName = "TL_YP";
			GuimlUtil.wrapMyCombo(oMap, listName, "TL", "TL");
			GuimlUtil.wrapMyCombo(oMap, listName, "YP", "YP");
			
			listName = "FAIZSIZ_FINANSMAN";
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "EVET");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "HAYIR");
			
			listName = "MODUL_TURU";
			GuimlUtil.wrapMyCombo(oMap, listName, "BIREYSEL", "BIREYSEL");
			GuimlUtil.wrapMyCombo(oMap, listName, "KREDI", "KREDI");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3111_GET_CODE")
	public static GMMap getCode(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('BIR_KRD_URUN_SINIF_PR')}");
			stmt.registerOutParameter(1, Types.NUMERIC);

			stmt.execute();

			BigDecimal code = stmt.getBigDecimal(1);

			oMap.put("CODE", code);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3111_SAVE")
	public static Map<?, ?> saveTRN3111(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> listBirKrdUrunSinif = (List<?>) session.createCriteria(BirKrdUrunSinifPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = listBirKrdUrunSinif.iterator(); iterator.hasNext();) {
				BirKrdUrunSinifPrTx birKrdUrunSinifPrTx = (BirKrdUrunSinifPrTx) iterator.next();
				session.delete(birKrdUrunSinifPrTx);
			}
			session.flush();
			
			String tableName = "BIR_KRD_URUN_SINIF";
			ArrayList<?> list = (ArrayList<?>) iMap.get(tableName);
			for (int i=0; i<list.size(); i++) {
				BirKrdUrunSinifPrTx birKrdUrunSinifPrTx  = new BirKrdUrunSinifPrTx();
				BirKrdUrunSinifPrTxId id = new BirKrdUrunSinifPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
				birKrdUrunSinifPrTx.setId(id);
				birKrdUrunSinifPrTx.setKrdTurKod(iMap.getBigDecimal(tableName, i, "KREDI_TURU"));
				birKrdUrunSinifPrTx.setVadeTip(iMap.getString(tableName, i, "VADE_TIPI"));
				birKrdUrunSinifPrTx.setTeminatli(iMap.getString(tableName, i, "TEMINATLI"));
				birKrdUrunSinifPrTx.setTlYp(iMap.getString(tableName, i, "TL_YP"));
				birKrdUrunSinifPrTx.setUrunTurKod(iMap.getString(tableName, i, "URUN_TURU"));
				birKrdUrunSinifPrTx.setUrunSinifKod(iMap.getString(tableName, i, "URUN_SINIFI"));
				birKrdUrunSinifPrTx.setDkGrupKod(iMap.getBigDecimal(tableName, i, "DK_GRUP_KOD"));
				birKrdUrunSinifPrTx.setFaizsizFinansman(iMap.getString(tableName, i, "FAIZSIZ_FINANSMAN"));
				birKrdUrunSinifPrTx.setModulTurKod(iMap.getString(tableName, i, "MODUL_TURU"));
				
				session.save(birKrdUrunSinifPrTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3111");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3111_GET_INFO")
	public static GMMap getInfoTRN3111(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listBirKrdUrunSinif = null;
			if ((iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI")) || (iMap.getString("ACTION").equals("EDIT"))) {
				listBirKrdUrunSinif = (List<?>) session.createCriteria(BirKrdUrunSinifPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			} else {
				listBirKrdUrunSinif = (List<?>) session.createCriteria(BirKrdUrunSinifPr.class).list();
			}
			String tableName = "BIR_KRD_URUN_SINIF";
			int row = 0;
			for (Iterator<?> iterator = listBirKrdUrunSinif.iterator(); iterator.hasNext();row++) {

				if ((iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI")) || (iMap.getString("ACTION").equals("EDIT"))) {
					BirKrdUrunSinifPrTx birKrdUrunSinifPrTx = (BirKrdUrunSinifPrTx) iterator.next();

					oMap.put(tableName, row, "KOD", birKrdUrunSinifPrTx.getId().getKod());
					oMap.put(tableName, row, "KREDI_TURU", birKrdUrunSinifPrTx.getKrdTurKod());
					oMap.put(tableName, row, "KREDI_TURU_ACIKLAMA", LovHelper.diLov(birKrdUrunSinifPrTx.getKrdTurKod(),"3111/LOV_KREDI_TURU","ACIKLAMA"));
					oMap.put(tableName, row, "VADE_TIPI", birKrdUrunSinifPrTx.getVadeTip());
					oMap.put(tableName, row, "TEMINATLI", birKrdUrunSinifPrTx.getTeminatli());
					oMap.put(tableName, row, "TL_YP", birKrdUrunSinifPrTx.getTlYp());
					oMap.put(tableName, row, "URUN_TURU", birKrdUrunSinifPrTx.getUrunTurKod());
					oMap.put(tableName, row, "URUN_SINIFI", birKrdUrunSinifPrTx.getUrunSinifKod());
					oMap.put(tableName, row, "DK_GRUP_KOD", birKrdUrunSinifPrTx.getDkGrupKod());
					oMap.put(tableName, row, "FAIZSIZ_FINANSMAN", birKrdUrunSinifPrTx.getFaizsizFinansman());
					oMap.put(tableName, row, "MODUL_TURU", birKrdUrunSinifPrTx.getModulTurKod());
				} else {
					BirKrdUrunSinifPr birKrdUrunSinifPr = (BirKrdUrunSinifPr) iterator.next();

					oMap.put(tableName, row, "KOD", birKrdUrunSinifPr.getKod());
					oMap.put(tableName, row, "KREDI_TURU", birKrdUrunSinifPr.getKrdTurKod());
					oMap.put(tableName, row, "KREDI_TURU_ACIKLAMA", LovHelper.diLov(birKrdUrunSinifPr.getKrdTurKod(),"3111/LOV_KREDI_TURU","ACIKLAMA"));
					oMap.put(tableName, row, "VADE_TIPI", birKrdUrunSinifPr.getVadeTip());
					oMap.put(tableName, row, "TEMINATLI", birKrdUrunSinifPr.getTeminatli());
					oMap.put(tableName, row, "TL_YP", birKrdUrunSinifPr.getTlYp());
					oMap.put(tableName, row, "URUN_TURU", birKrdUrunSinifPr.getUrunTurKod());
					oMap.put(tableName, row, "URUN_SINIFI", birKrdUrunSinifPr.getUrunSinifKod());
					oMap.put(tableName, row, "DK_GRUP_KOD", birKrdUrunSinifPr.getDkGrupKod());
					oMap.put(tableName, row, "FAIZSIZ_FINANSMAN", birKrdUrunSinifPr.getFaizsizFinansman());
					oMap.put(tableName, row, "MODUL_TURU", birKrdUrunSinifPr.getModulTurKod());
				}
			}

			oMap.put("ROW_COUNT", row);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
