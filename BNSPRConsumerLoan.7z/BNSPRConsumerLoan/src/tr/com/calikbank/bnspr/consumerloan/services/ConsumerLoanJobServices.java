package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKonsolidasyon;
import tr.com.aktifbank.bnspr.dao.BirKrediOtoYapilandirma;
import tr.com.aktifbank.bnspr.dao.BirKrediTaksit;
import tr.com.aktifbank.bnspr.dao.GnlBarcode;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.KkBasvuru;
import tr.com.aktifbank.bnspr.dao.KmhBireyselBasvuru;
import tr.com.aktifbank.bnspr.dao.MuhHesapKredi;
import tr.com.aktifbank.bnspr.dao.TffBasvuru;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.LOVExecuter;
import tr.com.obss.adc.core.services.transaction.ServiceExecuter;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanJobServices implements Constants {
	private static Logger logger = Logger.getLogger(ConsumerLoanJobServices.class);

	/**
	 * GNL_PARAM_TEXT.KOD = OTOMATIK_KULLANDIRIM text inin parametrelerine gore otomatik kullandirim
	 * islemi baslatir.
	 */
	@GraymoundService("BNSPR_OTOMATIK_KULLANDIRIM_JOB")
	public static GMMap autoKUllandirim(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TABLE";
		GMMap hataMap = new GMMap();
		int hataSatir = 0;

		try {

			String channelCode = DALUtil.getResult("select pkg_parametre.paramtextal ('OTOMATIK_KULLANDIRIM','BASVURU_KANAL_KODU','') from dual");
			String status = DALUtil.getResult("select pkg_parametre.paramtextal ('OTOMATIK_KULLANDIRIM','BASVURU_DURUM_KODU','') from dual");
			String customerContact = DALUtil.getResult("select pkg_parametre.paramtextal ('OTOMATIK_KULLANDIRIM','MUSTERI_KONTAKT','') from dual");
			int kkbGun = Integer.valueOf(DALUtil.getResult("select pkg_parametre.Deger_Al_K_N ('WEB_KKB_SORGU_GUN') from dual"));
			String primaryIdType = "6", financeType = "90", dot = ".", birthDate = "19000101";

			String fetchQuery = String.format("SELECT M.TC_KIMLIK_NO, B.BASVURU_NO, M.MUSTERI_NO, M.SUBE_KODU, M.MUSTERI_KONTAKT, K.E_MAIL, K.AD, K.SOYAD, KB.KART_TIPI, KB.KART_NO, B.sozlesme_tarihi FROM BNSPR.BIR_BASVURU B, BNSPR.BIR_BASVURU_KIMLIK K, BNSPR.GNL_MUSTERI M, BNSPR.BIR_BASVURU_KART_BILGI KB" + " WHERE B.BASVURU_NO = K.BASVURU_NO AND B.MUSTERI_NO = M.MUSTERI_NO AND B.BASVURU_NO = KB.BASVURU_NO(+) " + " AND B.KANAL_KODU IN ('%s') AND B.DURUM_KODU IN ('%s') AND M.MUSTERI_KONTAKT IN ('%s') " + " AND (PKG_MUSTERI_EK.Musteri_BHS_varmi(M.MUSTERI_NO) = 'E' OR PKG_TFF_RM_DOKUMAN.Musteri_Kart_BHS_varmi (M.MUSTERI_NO) = 'E')" + " AND B.KREDI_TUR != 5 ORDER BY B.BASVURU_NO", channelCode, status, customerContact);
			GMMap basvuruMap = DALUtil.getResults(fetchQuery, tableName);

			for (int i = 0; i < basvuruMap.getSize(tableName); i++) {

				try {
					Date kontrolGunu = DateUtils.addDays(new Date(), -kkbGun);
					Date sozlesmeTarihi = basvuruMap.getDate(tableName, i, "SOZLESME_TARIHI");

					if (sozlesmeTarihi.before(kontrolGunu)) {
						GMServiceExecuter.call("BNSPR_QRY3911_ONLINE_KKB_SORGULA", new GMMap().put("BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO")).put("PRIMARY_ID_TYPE", primaryIdType).put("PRIMARY_ID_NO", basvuruMap.getString(tableName, i, "TC_KIMLIK_NO")).put("FINANCE_TYPE", financeType).put("FORENAME1", dot).put("SURNAME", dot).put("BIRTHDATE", birthDate).put("BIRTHTOWN", dot));

						Connection conn = null;
						CallableStatement stmt = null;
						try {

							conn = DALUtil.getGMConnection();
							Object[] inputValues = new Object[2];
							String func = "{? = call pkg_bireysel2.kullandirimNbsmSonucKontrol (?)}";
							int k = 0;
							inputValues[k++] = BnsprType.NUMBER;
							inputValues[k++] = basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO");

							String aksiyonKod = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);

							if (!"00".equalsIgnoreCase(aksiyonKod)) {
								GMMap iptalMap = new GMMap();
								iptalMap.put("BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
								iptalMap.put("AKSIYON_KARAR_KOD", aksiyonKod);
								GMServiceExecuter.call("BNSPR_TRN3172_BASVURU_IPTAL", iptalMap);
								continue;
							}
						}
						catch (Exception e) {
							throw ExceptionHandler.convertException(e);
						}
						finally {
							GMServerDatasource.close(stmt);
							GMServerDatasource.close(conn);
						}
					}

					iMap.put("BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					iMap.put("MUSTERI_NO", basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					iMap.put("MUSTERI_KONTAKT", basvuruMap.get(tableName, i, "MUSTERI_KONTAKT"));
					iMap.put("E_MAIL", basvuruMap.get(tableName, i, "E_MAIL"));
					iMap.put("AD", basvuruMap.get(tableName, i, "AD"));
					iMap.put("SOYAD", basvuruMap.get(tableName, i, "SOYAD"));
					iMap.put("KART_TIPI", basvuruMap.get(tableName, i, "KART_TIPI"));
					iMap.put("KART_NO", basvuruMap.get(tableName, i, "KART_NO"));
					GMServiceExecuter.executeNT("BNSPR_OTOMATIK_KULLANDIRIM_PROCESS", iMap);

				}
				catch (Exception e) {
					hataMap.put(tableName, hataSatir, "BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					hataMap.put(tableName, hataSatir, "MUSTERI_NO", basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					hataMap.put(tableName, hataSatir, "HATA_ACK", e.getMessage());
					hataSatir++;
				}
			}

			GMServiceExecuter.call("BNSPR_OTOMATIK_KULLANDIRIM_JOB_MAIL", hataMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_OTOMATIK_KULLANDIRIM_JOB_MAIL")
	public static GMMap otoKullandirimMail(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TABLE";

		try {

			StringBuilder mailBody = new StringBuilder();
			mailBody.append("<html><body>");
			mailBody.append("<table border=\"1\">");
			mailBody.append("<tr>");
			mailBody.append("<th>BA�VURU NO</th>");
			mailBody.append("<th>M��TER� NO</th>");
			mailBody.append("<th>HATA A�IKLAMASI</th>");
			mailBody.append("</tr>");

			boolean mailAt = false;

			for (int row = 0; row < iMap.getSize(tableName); row++) {
				mailAt = true;
				mailBody.append("<tr>");
				mailBody.append("<td>" + iMap.getBigDecimal(tableName, row, "BASVURU_NO") + "</td>");
				mailBody.append("<td>" + iMap.getBigDecimal(tableName, row, "MUSTERI_NO") + "</td>");
				mailBody.append("<td>" + iMap.getString(tableName, row, "HATA_ACK") + "</td>");

				mailBody.append("</tr>");
			}

			if (mailAt) {
				GMMap servisMap = new GMMap();
				servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
				GMMap xMap = new GMMap();
				xMap.put("PARAMETRE", "WEBKREDI_KUL_HATA_MAIL");
				servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
				servisMap.put("MAIL_SUBJECT", "Web Kredi Kulland�r�lmayan Ba�vurular");
				if (mailBody.length() > 3000) {
					servisMap.put("MAIL_BODY_CLOB", mailBody);
				}
				else {
					servisMap.put("MAIL_BODY", mailBody);
				}
				servisMap.put("IS_BODY_HTML", "E");
				GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			}

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	@GraymoundService("BNSPR_OTOMATIK_PTT_SMS_KULLANDIRIM_JOB_MAIL")
	public static GMMap otoKullandirimPttSmsMail(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "RESULTS";

		try {

			StringBuilder mailBody = new StringBuilder();
			mailBody.append("<html><body>");
			mailBody.append("<table border=\"1\">");
			mailBody.append("<tr>");
			mailBody.append("<th>BA�VURU NO</th>");
			mailBody.append("<th>M��TER� NO</th>");
			mailBody.append("<th>HATA A�IKLAMASI</th>");
			mailBody.append("</tr>");

			boolean mailAt = false;

			for (int row = 0; row < iMap.getSize(tableName); row++) {
				mailAt = true;
				mailBody.append("<tr>");
				mailBody.append("<td>" + iMap.getBigDecimal(tableName, row, "BASVURU_NO") + "</td>");
				mailBody.append("<td>" + iMap.getBigDecimal(tableName, row, "MUSTERI_NO") + "</td>");
				mailBody.append("<td>" + iMap.getString(tableName, row, "HATA_ACK") + "</td>");

				mailBody.append("</tr>");
			}

			if (mailAt) {
				GMMap servisMap = new GMMap();
				servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
				GMMap xMap = new GMMap();
				xMap.put("PARAMETRE", "PTT_SMS_KUL_HATA_MAIL");
				servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
				servisMap.put("MAIL_SUBJECT", "PTT SMS Kulland�r�lmayan Ba�vurular");
				if (mailBody.length() > 3000) {
					servisMap.put("MAIL_BODY_CLOB", mailBody);
				}
				else {
					servisMap.put("MAIL_BODY", mailBody);
				}
				servisMap.put("IS_BODY_HTML", "E");
				GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			}

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return oMap;
	}

	@GraymoundService("BNSPR_OTOMATIK_PTT_SMS_KULLANDIRIM_JOB")
	public static GMMap pttSmsOtoKullandirim(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "RESULTS";
		GMMap basvuruMap = new GMMap();

		try {
			iMap.put("KULLANDIRIM", "E");
			GMMap hataMap = new GMMap();
			int hataSatir = 0;

			basvuruMap = GMServiceExecuter.call("BNSPR_OTOMATIK_PTT_SMS_KULLANDIRIM_LIST", iMap);

			for (int i = 0; i < basvuruMap.getSize(tableName); i++) {
				iMap.put("BASVURU_NO", basvuruMap.getString(tableName, i, "BASVURU_NO"));
				iMap.putAll(GMServiceExecuter.execute("BNSPR_PTT_SMS_KULLANDIRIM_KONTROL", iMap));

				if ("E".equalsIgnoreCase(iMap.getString("KULLANDIRILABILIR_EH"))) {

					iMap.put("BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					iMap.put("MUSTERI_NO", basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					iMap.put("MUSTERI_KONTAKT", basvuruMap.get(tableName, i, "MUSTERI_KONTAKT"));
					iMap.put("E_MAIL", basvuruMap.get(tableName, i, "E_MAIL"));
					iMap.put("AD", basvuruMap.get(tableName, i, "AD"));
					iMap.put("SOYAD", basvuruMap.get(tableName, i, "SOYAD"));

					GMMap resultMap = new GMMap();

					resultMap.putAll(GMServiceExecuter.executeNT("BNSPR_OTO_KULLANDIRIM_PROCESS_PTT_SMS", iMap));
					if (resultMap.getString("HATA_ACK") != null) {
						hataMap.put(tableName, hataSatir, "BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
						hataMap.put(tableName, hataSatir, "MUSTERI_NO", basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
						hataMap.put(tableName, hataSatir, "HATA_ACK", resultMap.getString("HATA_ACK"));
						hataSatir++;
					}
				}
				else {
					hataMap.put(tableName, hataSatir, "BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					hataMap.put(tableName, hataSatir, "MUSTERI_NO", basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					hataMap.put(tableName, hataSatir, "HATA_ACK", iMap.getString("ACIKLAMA"));
					hataSatir++;
				}
			}

			GMServiceExecuter.call("BNSPR_OTOMATIK_PTT_SMS_KULLANDIRIM_JOB_MAIL", hataMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_OTOMATIK_PTT_SMS_KULLANDIRIM_LIST")
	public static GMMap pttSmsOtoKullandirimList(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TABLE", takipTable = "TAKIP_TABLE", results = "RESULTS";
		int k = 0;
		BirBasvuru birBasvuru = null;
		BigDecimal masraf = null;
		BigDecimal topKapamaTutari = BigDecimal.ZERO;
		
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			String channelCode = "7";
			String status = DALUtil.getResult("select pkg_parametre.paramtextal ('OTOMATIK_KULLANDIRIM','BASVURU_DURUM_KODU','') from dual");

			String fetchQuery = String.format("SELECT M.TC_KIMLIK_NO, B.BASVURU_NO, M.MUSTERI_NO, M.SUBE_KODU, M.MUSTERI_KONTAKT, K.E_MAIL, K.AD, K.SOYAD, B.sozlesme_tarihi, KM.KOD KAMPANYA_KODU, KM.ACIKLAMA KAMPANYA_ADI, KM.BIRLESTIRME_EH " + 
			" FROM BNSPR.BIR_BASVURU B, BNSPR.BIR_BASVURU_KIMLIK K, BNSPR.GNL_MUSTERI M, BNSPR.BIR_KAMPANYA KM WHERE B.BASVURU_NO = K.BASVURU_NO AND B.MUSTERI_NO = M.MUSTERI_NO AND B.KAMP_KOD = KM.KOD AND " + 
					"B.KANAL_KODU IN ('%s') AND B.DURUM_KODU IN ('%s') and b.web_satis_kanali in ('PTT_SMS','PTT_ONONAY') AND B.KREDI_TUR != 5 ORDER BY B.BASVURU_NO", channelCode, status);
			
			GMMap basvuruMap = DALUtil.getResults(fetchQuery, tableName);

			for (int i = 0; i < basvuruMap.getSize(tableName); i++) {

				fetchQuery = String.format("select t.* from bnspr.kry_durum_takip t,bnspr.gnl_parametre p where t.proje_kod = 'PTTSMSKRE' and t.referans_no = '%s' and p.kod = t.firma_kod || '_TESLIM_KOD' and instr(p.deger, '''' ||t.durum_kodu || '''') > 0", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO").toString());
				GMMap takipMap = DALUtil.getResults(fetchQuery, takipTable);

				if (takipMap.getSize(takipTable) > 0) {
					oMap.put(results, k, "BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					oMap.put(results, k, "TC_KIMLIK_NO", basvuruMap.getString(tableName, i, "TC_KIMLIK_NO"));
					oMap.put(results, k, "MUSTERI_NO", basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					oMap.put(results, k, "MUSTERI_KONTAKT", basvuruMap.get(tableName, i, "MUSTERI_KONTAKT"));
					oMap.put(results, k, "E_MAIL", basvuruMap.get(tableName, i, "E_MAIL"));
					oMap.put(results, k, "AD", basvuruMap.get(tableName, i, "AD"));
					oMap.put(results, k, "SOYAD", basvuruMap.get(tableName, i, "SOYAD"));
					oMap.put(results, k, "KAMPANYA_KODU", basvuruMap.get(tableName, i, "KAMPANYA_KODU"));
					oMap.put(results, k, "KAMPANYA_ADI", basvuruMap.get(tableName, i, "KAMPANYA_ADI"));
					oMap.put(results, k, "BIRLESTIRME_EH", basvuruMap.get(tableName, i, "BIRLESTIRME_EH"));

					if (!"E".equals(iMap.getString("KULLANDIRIM"))) {
						GMServiceExecuter.executeNT("BNSPR_OTO_KULLANDIRIM_PROCESS_PTT_SMS", oMap.getMap(results, k));
						birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
						session.refresh(birBasvuru);
						
						/** konsolidasyon bilgileri **/
						BirKampanya birKampanya = (BirKampanya) session.get(BirKampanya.class, birBasvuru.getKampKod());
						
						if("E".equals(birKampanya.getBirlestirmeEh())) {
							List<BirBasvuruKonsolidasyon> konsolidasyonList = session.createCriteria(BirBasvuruKonsolidasyon.class).add(Restrictions.eq("id.basvuruNo", birBasvuru.getBasvuruNo())).add(Restrictions.eq("kapamaEh", "E")).list();
							for (BirBasvuruKonsolidasyon kons : konsolidasyonList) {
								kons.setKapamaTutar((BigDecimal) DALUtil.callOracleFunction(
										"{? = call pkg_trn3243.kredi_kapama_tutar(?)}", BnsprType.NUMBER, BnsprType.NUMBER,
										kons.getId().getYapilandirilanBasvuruNo()));
								topKapamaTutari = topKapamaTutari.add(kons.getKapamaTutar());
								
								session.save(kons);
								session.flush();
							}
						}

						masraf = ConsumerLoanCommonServices.nvl(birBasvuru.getDosyaMasrafi(), BigDecimal.ZERO).add(ConsumerLoanCommonServices.nvl(birBasvuru.getSigortaPrimi(), BigDecimal.ZERO)).add(ConsumerLoanCommonServices.nvl(birBasvuru.getFarkFaizi(), BigDecimal.ZERO));

						oMap.put(results, k, "TUTAR", birBasvuru.getOnayTutar().subtract(masraf).subtract(topKapamaTutari));
						oMap.put(results, k, "MASRAF", masraf);
					}
					k++;
				}
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_OTO_KULLANDIRIM_PROCESS_PTT_SMS")
	public static GMMap processOtoKullandirimPttSms(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tempMap = new GMMap();
		BigDecimal customerNo = null;
		BigDecimal basvuruNo = null;
		GMMap sMap = new GMMap();
		GMMap bMap = new GMMap();

		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			customerNo = iMap.getBigDecimal("MUSTERI_NO");
			basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, basvuruNo);

			/** Yeni tarihe g�re taksit tarihi, gecikme gun ve fark faizi belirle **/
			sMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
			sMap.putAll(GMServiceExecuter.call("CLKS_GET_PAY_PLN_3181_REQUEST_INFO", sMap));
			birBasvuru.setFarkFaizi(sMap.getBigDecimal("FARK_FAIZ"));
			birBasvuru.setGecikmeGunSayisi(sMap.getBigDecimal("GECIKME_GUN_SAYISI"));
			birBasvuru.setIlkTaksitTarihi(sMap.getDate("ILK_TAKSIT_TARIHI"));
			birBasvuru.setSigortaPrimi(sMap.getBigDecimal("SIGORTA_PRIMI"));

			session.save(birBasvuru);
			session.flush();

			if ("E".equalsIgnoreCase(iMap.getString("KULLANDIRILABILIR_EH"))) {
				/** odeme plani guncellenecek **/
				List<Object> inputList = new ArrayList<Object>();
				inputList.add(customerNo);
				tempMap.putAll((HashMap<?, ?>) LOVExecuter.execute("3199/LOV_BASVURU_1", basvuruNo, inputList).get(0));
				tempMap.put("BASVURU_NO", basvuruNo);
				tempMap.put("ISLEM_TIPI", "1");
				tempMap.put("KREDI_TUTAR", tempMap.get("TUTAR"));
				tempMap.put("VADE", tempMap.get("VADE"));
				tempMap.put("SOZLESME_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).get("BANKA_TARIH"));
				tempMap.put("TAKSIT_GUNU", birBasvuru.getTaksitGunu());
				tempMap.put("AY_SONU", false);
				tempMap.put("OTELEME_GUN_SAYISI", birBasvuru.getGecikmeGunSayisi());
				tempMap.put("SERBEST_KATKI_PAYI", tempMap.get("SERBEST_KATKI_PAYI"));
				tempMap.put("DOSYA_MASRAFI", tempMap.get("DOSYA_MASRAFI"));
				tempMap.put("FARK_FAIZI", birBasvuru.getFarkFaizi());
				tempMap.put("ILK_TAKSIT_YONTEM", birBasvuru.getIlkTaksitYontem());
				tempMap.put("BAZ_FAIZ", tempMap.get("FAIZ_ORANI"));
				tempMap.put("FAIZ_ORANI", tempMap.get("FAIZ_ORANI"));
				tempMap.put("KKDF_ORANI", tempMap.get("KKDF_ORANI"));
				tempMap.put("BSMV_ORANI", tempMap.get("BSMV_ORANI"));
				tempMap.put("ODEME_TIP_KOD", tempMap.get("ODEME_TIP_KOD"));
				iMap.put("ODEME_TIP_KOD", tempMap.get("ODEME_TIP_KOD"));
				tempMap.put("ODEME_TIP_VADE", tempMap.get("ODEME_TIP_VADE"));
				iMap.put("ODEME_TIP_VADE", tempMap.get("ODEME_TIP_VADE"));
				tempMap.put("ODEME_TIP_PERIYOD", tempMap.get("ODEME_TIP_PERIYOD"));
				tempMap.put("ODEME_TIP_TUTAR", tempMap.get("ODEME_TIP_TUT"));
				tempMap.put("ODEME_TIP_ORAN", tempMap.get("ODEME_TIP_ORAN"));
				tempMap.put("PTT_MAAS_ODEME_SIKLIGI", tempMap.get("PTT_MAAS_SIKLIGI"));
				tempMap.put("MEVCUT_LIST", ServiceExecuter.call("BNSPR_TRN3199_GET_RECORD_LIST", tempMap).get("MEVCUT_RESULTS"));
				tempMap.put("SOZLESME_FAIZI", tempMap.get("SOZLESME_FAIZI"));
				tempMap.putAll(GMServiceExecuter.call("BNSPR_TRN3199_NEW_GUNCEL_LIST", tempMap));

				/** yukardaki yeni guncel listte taksitlere dagit icin fark faizi eziliyor. bu nedenle tekrar set ediyoruz **/
				tempMap.put("FARK_FAIZI", birBasvuru.getFarkFaizi());
				tempMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				GMServiceExecuter.call("BNSPR_TRN3199_SAVE", tempMap);

				bMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				bMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
				bMap.put("CALISMA_TIPI", birBasvuru.getCalismaSekliKod());
				bMap.put("DURUM_KODU", "KUL");
				bMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				bMap.put("MUSTERI_ESLESTIRME", "false");
				bMap.put("OTOMATIK_KULLANDIRIM", "true");
				bMap.put("OTOMATIK_AKIS", "E");
				GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", bMap);

				GMServiceExecuter.execute("SMS_REPORT_CREDIT_APPLICATION", bMap);
			}
		}
		catch (Exception e) {
			if ("E".equalsIgnoreCase(iMap.getString("KULLANDIRILABILIR_EH"))) {
				oMap.put("HATA_ACK", e.getMessage());
			}
			else {
				ExceptionHandler.convertException(e);
			}
		}
		return oMap;
	}

	@GraymoundService("BNSPR_OTOMATIK_KULLANDIRIM_PROCESS")
	public static GMMap processAutoKullandirim(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tempMap = new GMMap();
		BigDecimal customerNo = null;
		BigDecimal basvuruNo = null;
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			customerNo = iMap.getBigDecimal("MUSTERI_NO");
			basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			/** odeme plani guncellenecek **/
			List<Object> inputList = new ArrayList<Object>();
			inputList.add(customerNo);
			tempMap.putAll((HashMap<?, ?>) LOVExecuter.execute("3199/LOV_BASVURU_1", basvuruNo, inputList).get(0));
			tempMap.put("BASVURU_NO", basvuruNo);
			tempMap.put("ISLEM_TIPI", "1");
			tempMap.put("KREDI_TUTAR", tempMap.get("TUTAR"));
			tempMap.put("VADE", tempMap.get("VADE"));
			tempMap.put("SOZLESME_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).get("BANKA_TARIH"));
			tempMap.put("OTELEME_GUN_SAYISI", "0");
			tempMap.put("SERBEST_KATKI_PAYI", tempMap.get("SERBEST_KATKI_PAYI"));
			tempMap.put("DOSYA_MASRAFI", tempMap.get("DOSYA_MASRAFI"));
			tempMap.put("FARK_FAIZI", "0.00");
			tempMap.put("ILK_TAKSIT_YONTEM", StringUtils.EMPTY);
			tempMap.put("BAZ_FAIZ", tempMap.get("FAIZ_ORANI"));
			tempMap.put("FAIZ_ORANI", tempMap.get("FAIZ_ORANI"));
			tempMap.put("KKDF_ORANI", tempMap.get("KKDF_ORANI"));
			tempMap.put("BSMV_ORANI", tempMap.get("BSMV_ORANI"));
			tempMap.put("ODEME_TIP_KOD", tempMap.get("ODEME_TIP_KOD"));
			iMap.put("ODEME_TIP_KOD", tempMap.get("ODEME_TIP_KOD"));
			tempMap.put("ODEME_TIP_VADE", tempMap.get("ODEME_TIP_VADE"));
			iMap.put("ODEME_TIP_VADE", tempMap.get("ODEME_TIP_VADE"));
			tempMap.put("ODEME_TIP_PERIYOD", tempMap.get("ODEME_TIP_PERIYOD"));
			tempMap.put("ODEME_TIP_TUTAR", tempMap.get("ODEME_TIP_TUT"));
			tempMap.put("ODEME_TIP_ORAN", tempMap.get("ODEME_TIP_ORAN"));
			tempMap.put("PTT_MAAS_ODEME_SIKLIGI", tempMap.get("PTT_MAAS_SIKLIGI"));
			tempMap.put("MEVCUT_LIST", ServiceExecuter.call("BNSPR_TRN3199_GET_RECORD_LIST", tempMap).get("MEVCUT_RESULTS"));
			tempMap.put("SOZLESME_FAIZI", tempMap.get("SOZLESME_FAIZI"));
			tempMap.putAll(GMServiceExecuter.call("BNSPR_TRN3199_NEW_GUNCEL_LIST", tempMap));
			Calendar c = Calendar.getInstance();
			c.setTime(tempMap.getDate("SOZLESME_TARIHI"));
			tempMap.put("TAKSIT_GUNU", c.get(Calendar.DAY_OF_MONTH));
			tempMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			GMServiceExecuter.call("BNSPR_TRN3199_SAVE", tempMap);

			/** otomatik kullandirim **/
			tempMap.clear();
			tempMap.put("TRX_ONAYSIZ_ISLEM", "E");
			tempMap.put("BASVURU_NO", basvuruNo);
			tempMap.put("MUSTERI_NO", customerNo);
			tempMap.put("SUBE_KODU", "444"/*basvuruMap.get(tableName, i, "SUBE_KODU")*/);
			tempMap.put("MUSTERI_KONTAKT", iMap.get("MUSTERI_KONTAKT"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_OTOMATIK_KULLANDIR", tempMap));

			/** odeme plani maille gonderim **/
			GMMap dMap = new GMMap();
			dMap.put("APPLICATION_NO", basvuruNo);
			dMap.put("MAIL_TRANSFER", true);
			dMap.put("DYS_TRANSFER", true);
			dMap.put("EMAIL_TO", iMap.get("E_MAIL"));
			dMap.put("EMAIL_NAME", iMap.get("AD"));
			dMap.put("EMAIL_SURNAME", iMap.get("SOYAD"));
			if ("P".equals(iMap.getString("KART_TIPI"))) {
				dMap.put("EMAIL_TYPE", "PP_KK");
			}
			else if ("N".equals(iMap.getString("KART_TIPI"))) {
				dMap.put("EMAIL_TYPE", "YM_KK");
			}
			else {
				if ("8".equals(iMap.getString("ODEME_TIP_KOD"))) {
					BirKullandirim birKullandirim = (BirKullandirim) session.get(BirKullandirim.class, basvuruNo);
					dMap.put("ODEMESIZ_SURE", birKullandirim.getFaizsizSure());
					dMap.put("EMAIL_TYPE", "SPOT_KK");
					dMap.put("SPOT_VADE", iMap.getString("ODEME_TIP_VADE"));
				}
				else {
					dMap.put("EMAIL_TYPE", "BHS_KK");
				}
			}
			dMap.put("EMAIL_CARD_NO", iMap.get("KART_NO"));
			List<?> belge = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();
			int k = 0;
			for (int row = 0; row < belge.size(); row++) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge.get(row);
				if (!"582".equals(birBasvuruBelge.getId().getDokumanKod())) {
					dMap.put("DOC_LIST", k, "CODE", birBasvuruBelge.getId().getDokumanKod());
					k++;
				}
			}
			GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return tempMap;
	}

	@GraymoundService("BNSPR_PTT_SMS_KURYE_DATA_JOB")
	public static GMMap pttSmsKuryeData(GMMap iMap) {

		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Session session = DAOSession.getSession("BNSPRDal");

		try {
			String eksiklikBasla = "E";
			String eksiklikBitir = "H";

			List<GnlParamText> firmalar = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "PTT_SMS_KRY_FIRMA")).addOrder(Order.asc("siraNo")).list();

			for (int firmaRow = 0; firmaRow < firmalar.size(); firmaRow++) {
				
				GnlParamText firma = firmalar.get(firmaRow);
				
				if (firmalar.size() == 1 || firmaRow == firmalar.size()-1) {
					eksiklikBitir = "E";
				}

				conn = DALUtil.getGMConnection();

				query = new StringBuilder();
				query.append("{? = call ");
				query.append("pkg_kurye.ptt_sms_kurye_data(?,?)");
				query.append("}");
				stmt = conn.prepareCall(query.toString());
				stmt.registerOutParameter(1, -10);
				stmt.setString(2, eksiklikBasla);
				stmt.setString(3, eksiklikBitir);
				
				stmt.execute();

				rSet = (ResultSet) stmt.getObject(1);

				int row = 0;

				while (rSet.next()) {
					if (firma.getText().equalsIgnoreCase(rSet.getString("KRY_FIRMA")) || (rSet.getString("KRY_FIRMA") == null && firma.getSiraNo().compareTo(BigDecimal.ONE) == 0)) {
						iMap.put("LINE_LIST", row, "PROJE_KODU", "PTTSMSKRE");
						iMap.put("LINE_LIST", row, "BASVURU_NO", rSet.getString("BASVURU_NO"));
						iMap.put("LINE_LIST", row, "BARKOD_NO", rSet.getString("BARKOD_NO"));
						iMap.put("LINE_LIST", row, "AD", rSet.getString("AD"));
						iMap.put("LINE_LIST", row, "SOYAD", rSet.getString("SOYAD"));
						iMap.put("LINE_LIST", row, "TELEFON1", rSet.getString("TELEFON1"));
						iMap.put("LINE_LIST", row, "TELEFON2", rSet.getString("TELEFON2"));
						iMap.put("LINE_LIST", row, "EMAIL", rSet.getString("EMAIL"));
						iMap.put("LINE_LIST", row, "ADRES1_DETAY", rSet.getString("ADRES1_DETAY"));
						iMap.put("LINE_LIST", row, "ADRES1_ILCE", rSet.getString("ADRES1_ILCE"));
						iMap.put("LINE_LIST", row, "ADRES1_IL", rSet.getString("ADRES1_IL"));
						iMap.put("LINE_LIST", row, "ADRES2_DETAY", rSet.getString("ADRES2_DETAY"));
						iMap.put("LINE_LIST", row, "ADRES2_ILCE", rSet.getString("ADRES2_ILCE"));
						iMap.put("LINE_LIST", row, "ADRES2_IL", rSet.getString("ADRES2_IL"));
						iMap.put("LINE_LIST", row, "DOKUMAN_KOD_1", rSet.getString("DOKUMAN_KOD_1"));
						iMap.put("LINE_LIST", row, "DOKUMAN_ADI_1", rSet.getString("DOKUMAN_ADI_1"));
						iMap.put("LINE_LIST", row, "DOKUMAN_KOD_2", rSet.getString("DOKUMAN_KOD_2"));
						iMap.put("LINE_LIST", row, "DOKUMAN_ADI_2", rSet.getString("DOKUMAN_ADI_2"));
						iMap.put("LINE_LIST", row, "DOKUMAN_KOD_3", rSet.getString("DOKUMAN_KOD_3"));
						iMap.put("LINE_LIST", row, "DOKUMAN_ADI_3", rSet.getString("DOKUMAN_ADI_3"));
						iMap.put("LINE_LIST", row, "DOKUMAN_KOD_4", rSet.getString("DOKUMAN_KOD_4"));
						iMap.put("LINE_LIST", row, "DOKUMAN_ADI_4", rSet.getString("DOKUMAN_ADI_4"));
						iMap.put("LINE_LIST", row, "DOKUMAN_KOD_5", rSet.getString("DOKUMAN_KOD_5"));
						iMap.put("LINE_LIST", row, "DOKUMAN_ADI_5", rSet.getString("DOKUMAN_ADI_5"));
						iMap.put("LINE_LIST", row, "DOKUMAN_KOD_6", rSet.getString("DOKUMAN_KOD_6"));
						iMap.put("LINE_LIST", row, "DOKUMAN_ADI_6", rSet.getString("DOKUMAN_ADI_6"));

						GMMap pMap = new GMMap();
						pMap.put("BARCODE", rSet.getString("BARKOD_NO"));
						pMap.put("PROJECT_TYPE", "CLKSDYS");
						pMap.put("REFERENCE", rSet.getString("BASVURU_NO"));
						pMap.put("STATUS", "1");

						List<GnlBarcode> barkod = session.createCriteria(GnlBarcode.class).add(Restrictions.eq("barcode", rSet.getString("BARKOD_NO"))).list();

						if (barkod == null || barkod.size() == 0) {
							GMServiceExecuter.call("DYS_SAVE_NEW_BARCODE_FOR_CLKS", pMap);
						}
						row++;
					}
				}

				iMap.put("KURYE_KOD", firma.getSiraNo());

				SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyy");
				iMap.put("FILE_NAME", firma.getKey3() + "_" + sdf.format(new Date()) + ".txt");

				iMap.put("FTP_CREDENTIAL_PARAMCODE", firma.getKey2());
				iMap.put("PROJE_KODU", "PTTSMSKRE");

				GMServiceExecuter.executeAsync("BNSPR_EXT_CREATE_KURYE_TOPLU_GONDERIM_DOSYASI", iMap);
				iMap.clear();
				eksiklikBasla = "H";
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_BIREYSEL_RISK_MAIL")
	public static GMMap bireyselRiskMailAt(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		DataInputStream dis = null;

		try {
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_BIREYSEL2.bireyselRisk");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			SimpleDateFormat format = new SimpleDateFormat("dd_MM_yyyy");
			String date = format.format(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			String fileName = "GUNLUK_KULLANDIRILAN_KREDILER_" + date + ".xls";
			File tempExcelFile = FileUtil.createTempDirFile(fileName);
			WritableWorkbook workbook = Workbook.createWorkbook(tempExcelFile);
			WritableSheet sheet = workbook.createSheet("BIREYSEL RISK", 0);

			// create excel column headers
			int col = 0;
			sheet.addCell(new Label(col++, 0, "HESAP NO"));
			sheet.addCell(new Label(col++, 0, "M��TER� NO"));
			sheet.addCell(new Label(col++, 0, "D�V�Z KODU"));
			sheet.addCell(new Label(col++, 0, "TUTAR"));
			sheet.addCell(new Label(col++, 0, "DURUM KODU"));
			sheet.addCell(new Label(col++, 0, "�UBE KODU"));
			sheet.addCell(new Label(col++, 0, "M��TER� DK NO"));
			sheet.addCell(new Label(col++, 0, "�R�N T�R KOD"));
			sheet.addCell(new Label(col++, 0, "�R�N SINIF KOD"));
			sheet.addCell(new Label(col++, 0, "MOD�L T�R KOD"));
			sheet.addCell(new Label(col++, 0, "KRED� VADE"));
			sheet.addCell(new Label(col++, 0, "KRED� KULLANDIRIM KODU"));
			sheet.addCell(new Label(col++, 0, "ENDEKS D�V�Z KODU"));
			sheet.addCell(new Label(col++, 0, "KULLANDIRIM D�V�Z KODU"));
			sheet.addCell(new Label(col++, 0, "FA�Z ORANI"));

			boolean mailAt = false;
			int i = 0;
			while (rSet.next()) {
				mailAt = true;
				i++;
				col = 0;
				sheet.addCell(new Label(col++, i, rSet.getString("HESAP_NO")));
				sheet.addCell(new Label(col++, i, rSet.getString("MUSTERI_NO")));
				sheet.addCell(new Label(col++, i, rSet.getString("DOVIZ_KODU")));
				sheet.addCell(new Label(col++, i, rSet.getString("TUTAR")));
				sheet.addCell(new Label(col++, i, rSet.getString("DURUM_KODU")));
				sheet.addCell(new Label(col++, i, rSet.getString("SUBE_KODU")));
				sheet.addCell(new Label(col++, i, rSet.getString("MUSTERI_DK_NO")));
				sheet.addCell(new Label(col++, i, rSet.getString("URUN_TUR_KOD")));
				sheet.addCell(new Label(col++, i, rSet.getString("URUN_SINIF_KOD")));
				sheet.addCell(new Label(col++, i, rSet.getString("MODUL_TUR_KOD")));
				sheet.addCell(new Label(col++, i, rSet.getString("KREDI_VADE")));
				sheet.addCell(new Label(col++, i, rSet.getString("KREDI_KULLANDIRIM_KODU")));
				sheet.addCell(new Label(col++, i, rSet.getString("ENDEKS_DOVIZ_KODU")));
				sheet.addCell(new Label(col++, i, rSet.getString("KULLANDIRIM_DOVIZ_KODU")));
				sheet.addCell(new Label(col++, i, rSet.getString("FAIZ_ORANI")));
			}

			workbook.write();
			workbook.close();

			// file to byte array
			int size = (int) tempExcelFile.length();
			byte[] fileContent = new byte[size];
			dis = new DataInputStream(new FileInputStream(tempExcelFile));
			int read = 0;
			int numRead = 0;
			while (read < fileContent.length && (numRead = dis.read(fileContent, read, fileContent.length - read)) >= 0) {
				read = read + numRead;
			}
			System.out.println("File size: " + read);
			if (read < fileContent.length) {
				System.out.println("Could not completely read: " + tempExcelFile.getName());
			}

			// sending mail with byte array attachment
			if (mailAt) {
				GMMap servisMap = new GMMap();
				servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
				GMMap xMap = new GMMap();
				xMap.put("PARAMETRE", "RAPORLAMA_MAIL");
				servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
				servisMap.put("MAIL_SUBJECT", "G�nl�k Kulland�r�lan Krediler");
				servisMap.put("MAIL_BODY", "G�nl�k Kulland�r�lan Krediler");
				servisMap.put("FILE_NAME", fileName);
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", fileName);
				servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", fileContent);
				servisMap.put("IS_BODY_HTML", "H");
				GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			try {
				if (dis != null)
					dis.close();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		return oMap;
	}

	@GraymoundService("BNSPR_BAYI_BASVURU_TUTAR_KONTROL_JOB")
	public static GMMap bayiBasvuruTutarKontrolJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_TRN3162.bayi_limit_list");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			StringBuilder mailBody = new StringBuilder();
			mailBody.append("<html><body>");
			mailBody.append("<table border=\"1\">");
			mailBody.append("<tr>");
			mailBody.append("<th>KOD</th>");
			mailBody.append("<th>BAY� ADI</th>");
			mailBody.append("<th>D�STR�B�T�R</th>");
			mailBody.append("<th>BAY� STAT�S�</th>");
			mailBody.append("<th>�NEM DERECES�</th>");
			mailBody.append("<th>BAY� R�SK�</th>");
			mailBody.append("<th>S�STEME TANIMLANMA TAR�H�</th>");
			mailBody.append("<th>SON AY BA�VURU TUTAR</th>");
			mailBody.append("<th>TANIMLANAN BA�VURU TUTARI</th>");
			mailBody.append("<th>KISM� KAPANMA NEDEN�</th>");
			mailBody.append("<th>KISM� KAPANMA STAT�S�</th>");
			mailBody.append("<th>�LK A�IM TAR�H�</th>");
			mailBody.append("<th>�LK A�IM TUTARI</th>");
			mailBody.append("</tr>");

			boolean mailAt = false;

			while (rSet.next()) {
				if (rSet.getBigDecimal("TOPLAM_TUTAR").compareTo(rSet.getBigDecimal("BAYI_AYLIK_LIMIT")) > 0) {

					Calendar c = Calendar.getInstance(); // this takes current date
					c.set(Calendar.DAY_OF_MONTH, 1);
					Date ayBasi = c.getTime();
					Date ilkAsimTarihi = new Date();
					BigDecimal ilkAsimTutar = rSet.getBigDecimal("TOPLAM_TUTAR");

					if (rSet.getDate("ILK_ASIM_TARIHI").before(ayBasi)) {
						BirSaticiTahsis tahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", rSet.getBigDecimal("KOD"))).uniqueResult();
						tahsis.setTutarAsimTarihi(ilkAsimTarihi);
						tahsis.setIlkAsimTutar(ilkAsimTutar);
						session.update(tahsis);
						session.flush();
					}
					else {
						ilkAsimTutar = rSet.getBigDecimal("ILK_ASIM_ADET");
						ilkAsimTarihi = rSet.getDate("ILK_ASIM_TARIHI");
					}

					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

					mailAt = true;
					mailBody.append("<tr>");
					mailBody.append("<td>" + rSet.getString("KOD") + "</td>");
					mailBody.append("<td>" + rSet.getString("SATICI_ADI") + "</td>");
					mailBody.append("<td>" + rSet.getString("DIST_ADI") + "</td>");
					mailBody.append("<td>" + rSet.getString("BAYI_STATUSU") + "</td>");
					mailBody.append("<td>" + rSet.getString("ONEM_DERECESI") + "</td>");
					mailBody.append("<td>" + rSet.getString("BAYI_RISKI") + "</td>");
					mailBody.append("<td>" + rSet.getString("TANIMLAMA_TAR") + "</td>");
					mailBody.append("<td>" + rSet.getString("TOPLAM_TUTAR") + "</td>");
					mailBody.append("<td>" + rSet.getString("BAYI_AYLIK_LIMIT") + "</td>");
					mailBody.append("<td>" + rSet.getString("KISMI_KAPANMA_NEDEN_KOD") + "</td>");
					mailBody.append("<td>" + rSet.getString("KISMI_KAPANMA_STATU_KOD") + "</td>");
					mailBody.append("<td>" + format.format(ilkAsimTarihi) + "</td>");
					mailBody.append("<td>" + ilkAsimTutar + "</td>");
					mailBody.append("</tr>");
				}
			}

			if (mailAt) {
				GMMap servisMap = new GMMap();
				servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
				GMMap xMap = new GMMap();
				xMap.put("PARAMETRE", "BK_TAHSIS_MAIL");
				servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
				servisMap.put("MAIL_SUBJECT", "Bayi Ayl�k Ba�vuru Tutar A��m�");
				if (mailBody.length() > 3000) {
					servisMap.put("MAIL_BODY_CLOB", mailBody);
				}
				else {
					servisMap.put("MAIL_BODY", mailBody);
				}
				servisMap.put("IS_BODY_HTML", "E");
				GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_BAYI_BASVURU_LIMIT_KONTROL_JOB")
	public static GMMap bayiBasvuruLimitKontrolJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_TRN3162.bayi_basvuru_limit_list");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			StringBuilder mailBody = new StringBuilder();
			mailBody.append("<html><body>");
			mailBody.append("<table border=\"1\">");
			mailBody.append("<tr>");
			mailBody.append("<th>KOD</th>");
			mailBody.append("<th>BAY� ADI</th>");
			mailBody.append("<th>D�STR�B�T�R</th>");
			mailBody.append("<th>BAY� STAT�S�</th>");
			mailBody.append("<th>�NEM DERECES�</th>");
			mailBody.append("<th>BAY� R�SK�</th>");
			mailBody.append("<th>S�STEME TANIMLANMA TAR�H�</th>");
			mailBody.append("<th>SON AY BA�VURU ADET</th>");
			mailBody.append("<th>TANIMLANAN ADET L�M�T�</th>");
			mailBody.append("<th>KISM� KAPANMA NEDEN�</th>");
			mailBody.append("<th>KISM� KAPANMA STAT�S�</th>");
			mailBody.append("<th>�LK A�IM TAR�H�</th>");
			mailBody.append("<th>�LK A�IM ADET�</th>");
			mailBody.append("</tr>");

			boolean mailAt = false;

			while (rSet.next()) {
				if (rSet.getInt("BASVURU_SAYISI") > rSet.getInt("AYLIK_BASVURU_LIMIT")) {

					Calendar c = Calendar.getInstance(); // this takes current date
					c.set(Calendar.DAY_OF_MONTH, 1);
					Date ayBasi = c.getTime();
					Date ilkAsimTarihi = new Date();
					BigDecimal ilkAsimAdet = rSet.getBigDecimal("BASVURU_SAYISI");

					if (rSet.getDate("ILK_ASIM_TARIHI").before(ayBasi)) {
						BirSaticiTahsis tahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", rSet.getBigDecimal("KOD"))).uniqueResult();
						tahsis.setAdetAsimTarihi(ilkAsimTarihi);
						tahsis.setIlkAsimAdet(ilkAsimAdet);
						session.update(tahsis);
						session.flush();
					}
					else {
						ilkAsimAdet = rSet.getBigDecimal("ILK_ASIM_ADET");
						ilkAsimTarihi = rSet.getDate("ILK_ASIM_TARIHI");
					}

					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

					mailAt = true;
					mailBody.append("<tr>");
					mailBody.append("<td>" + rSet.getString("KOD") + "</td>");
					mailBody.append("<td>" + rSet.getString("SATICI_ADI") + "</td>");
					mailBody.append("<td>" + rSet.getString("DIST_ADI") + "</td>");
					mailBody.append("<td>" + rSet.getString("BAYI_STATUSU") + "</td>");
					mailBody.append("<td>" + rSet.getString("ONEM_DERECESI") + "</td>");
					mailBody.append("<td>" + rSet.getString("BAYI_RISKI") + "</td>");
					mailBody.append("<td>" + rSet.getString("TANIMLAMA_TAR") + "</td>");
					mailBody.append("<td>" + rSet.getString("BASVURU_SAYISI") + "</td>");
					mailBody.append("<td>" + rSet.getString("AYLIK_BASVURU_LIMIT") + "</td>");
					mailBody.append("<td>" + rSet.getString("KISMI_KAPANMA_NEDEN_KOD") + "</td>");
					mailBody.append("<td>" + rSet.getString("KISMI_KAPANMA_STATU_KOD") + "</td>");
					mailBody.append("<td>" + format.format(ilkAsimTarihi) + "</td>");
					mailBody.append("<td>" + ilkAsimAdet + "</td>");
					mailBody.append("</tr>");
				}
			}

			if (mailAt) {
				GMMap servisMap = new GMMap();
				servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
				GMMap xMap = new GMMap();
				xMap.put("PARAMETRE", "BK_TAHSIS_MAIL");
				servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
				servisMap.put("MAIL_SUBJECT", "Bayi Ayl�k Ba�vuru Adet A��m�");
				if (mailBody.length() > 3000) {
					servisMap.put("MAIL_BODY_CLOB", mailBody);
				}
				else {
					servisMap.put("MAIL_BODY", mailBody);
				}
				servisMap.put("IS_BODY_HTML", "E");
				GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_ADK_FLAG_UPDATE_JOB")
	public static GMMap updateAdkFlagJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("IS_PARALLEL", true);
			iMap.put("LIST_SERVICE_NAME", "BNSPR_LIST_ADK_FLAG_JOB");
			iMap.put("PROCESS_SERVICE_NAME", "BNSPR_PROCESS_ADK_FLAG_JOB");
			iMap.put("THREAD_SIZE", 12);
			GMServiceExecuter.execute("BNSPR_PROCESS_CREDIT_CARD_JOB", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_LIST_ADK_FLAG_JOB")
	public static GMMap listAdkFlagJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_RC_3182.listAdkFlagJob");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_PROCESS_ADK_FLAG_JOB")
	public static GMMap processAdkFlagJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap musteri = new GMMap();
			if (iMap.getBigDecimal("MUSTERI_NO") != null) {
				musteri.put("DURUM_KODU", "A");
				musteri.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));

				BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRN1040_CREATE_TRX_NO", musteri).getBigDecimal("TRX_NO");
				musteri.put("TRX_NO", trxNo);
				musteri.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", musteri));
				musteri.put("ADK_MUSTERISIMI", "E");

				musteri.put("TRX_ONAYSIZ_ISLEM", "E");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_SAVE", musteri));
			}
		}
		catch (Exception e) {
			logger.error(iMap.getBigDecimal("MUSTERI_NO") + " - " + e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_FTP_FLAG_UPDATE_JOB")
	public static GMMap updateFtpFlagJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("IS_PARALLEL", false);
			iMap.put("LIST_SERVICE_NAME", "BNSPR_LIST_FTP_FLAG_JOB");
			iMap.put("PROCESS_SERVICE_NAME", "BNSPR_PROCESS_FTP_FLAG_JOB");
			iMap.put("THREAD_SIZE", 1);
			GMServiceExecuter.execute("BNSPR_PROCESS_CREDIT_CARD_JOB", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_LIST_FTP_FLAG_JOB")
	public static GMMap listFtpFlagJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_RC_3182.listFtpFlagJob");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_PROCESS_FTP_FLAG_JOB")
	public static GMMap processFtpFlagJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap sorguMap = new GMMap();
		sorguMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
		GMServiceExecuter.execute("BNSPR_TRN3182_GECICI_DOKUMAN_TRANSFER_ET", sorguMap);

		return oMap;
	}

	@GraymoundService("BNSPR_WEBKREDI_BELGE_JOB")
	public static GMMap webKrediBelgeJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TABLE";
		BigDecimal customerNo = null;
		BigDecimal basvuruNo = null;

		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			String fetchQuery = "SELECT B.BASVURU_NO, B.MUSTERI_NO, B.CALISMA_SEKLI_KOD FROM BNSPR.BIR_BASVURU B " + " WHERE B.KANAL_KODU = '8' AND B.DURUM_KODU = 'EVRAKSIZ' AND " + " PKG_MUSTERI_EK.Musteri_BHS_varmi(B.MUSTERI_NO) = 'E' " + " ORDER BY B.BASVURU_NO";

			GMMap basvuruMap = DALUtil.getResults(fetchQuery, tableName);

			for (int i = 0; i < basvuruMap.getSize(tableName); i++) {
				GMMap tempMap = new GMMap();
				customerNo = basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO");
				basvuruNo = basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO");

				List<?> belge = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();
				for (int row = 0; row < belge.size(); row++) {
					BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge.get(row);
					tempMap.put("BELGELER", row, "BELGE_KOD", birBasvuruBelge.getId().getDokumanKod());
					tempMap.put("BELGELER", row, "DOSYA_ADI", birBasvuruBelge.getBelgeAdi());
					tempMap.put("BELGELER", row, "BELGE_ALINMA_ADIMI", birBasvuruBelge.getBelgeAlinmaAdim());
					tempMap.put("BELGELER", row, "BELGE_KONTROL", "1");
					tempMap.put("BELGELER", row, "ORJINAL_EVRAK_MI", "1");
					tempMap.put("BELGELER", row, "KIMDEN_KOD", birBasvuruBelge.getId().getKimden());
					tempMap.put("BELGELER", row, "GELIS_TARIHI", new Date());
				}

				tempMap.put("BASVURU_NO", basvuruNo);
				tempMap.put("MUSTERI_NO", customerNo);
				tempMap.put("DURUM_KODU", "EVRAKSIZ");
				tempMap.put("CALISMA_TIPI", basvuruMap.getString(tableName, i, "CALISMA_SEKLI_KOD"));
				tempMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", tempMap);
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_ELEKTRONIK_BAYI_BELGE_JOB")
	public static GMMap elektronikBayiBelgeJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TABLE";
		BigDecimal musteriNo = null;
		BigDecimal basvuruNo = null;
		GMMap tempMap = new GMMap();

		try {
			String fetchQuery = "select b.basvuru_no, b.musteri_No, b.CALISMA_SEKLI_KOD from bnspr.bir_basvuru b, bnspr.bir_basvuru_sozlesme_tx a where b.kanal_kodu = '2' and " + "a.basvuru_no = b.basvuru_no and a.bayi_digital_basvuru = 'E' " + "and a.rec_date = (select max(rec_date) from bnspr.bir_basvuru_sozlesme_tx where basvuru_no = b.basvuru_no) " + "and b.durum_kodu = 'EVRAKSIZ'";

			GMMap basvuruMap = DALUtil.getResults(fetchQuery, tableName);
			Object[] inputValues = new Object[4];
			int k = 0;
			for (int i = 0; i < basvuruMap.getSize(tableName); i++) {
				musteriNo = basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO");
				basvuruNo = basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO");

				String func = "{? = call PKG_RC_3182.rm_elektronik_belge_getir(?, ?)}";

				k = 0;
				inputValues[k++] = BnsprType.NUMBER;
				inputValues[k++] = musteriNo;
				inputValues[k++] = BnsprType.NUMBER;
				inputValues[k++] = basvuruNo;

				oMap = DALUtil.callOracleRefCursorFunction(func, "BELGE_LIST", inputValues);

				if (oMap.getSize("BELGE_LIST") > 0) {
					tempMap.clear();
					for (int row = 0; row < oMap.getSize("BELGE_LIST"); row++) {
						tempMap.put("BELGELER", row, "BELGE_KOD", oMap.getString("BELGE_LIST", row, "BELGE_KODU"));
						tempMap.put("BELGELER", row, "BELGE_KONTROL", oMap.getString("BELGE_LIST", row, "BELGE_STATU"));
						tempMap.put("BELGELER", row, "BELGE_HATA", oMap.getString("BELGE_LIST", row, "BELGE_ALT_STATU"));
						tempMap.put("BELGELER", row, "KONTROL_NEDENI", oMap.getString("BELGE_LIST", row, "ACIKLAMA"));
						if ("1".equals(oMap.getString("BELGE_LIST", row, "BELGE_STATU"))) {
							tempMap.put("BELGELER", row, "ORJINAL_EVRAK_MI", "1");
						}
						tempMap.put("BELGELER", row, "GELIS_TARIHI", new Date());
						tempMap.put("BELGELER", row, "KIMDEN_KOD", "M");
					}
					tempMap.put("BASVURU_NO", basvuruNo);
					tempMap.put("MUSTERI_NO", musteriNo);
					tempMap.put("DURUM_KODU", "EVRAKSIZ");
					tempMap.put("CALISMA_TIPI", basvuruMap.getString(tableName, i, "CALISMA_SEKLI_KOD"));
					tempMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
					GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", tempMap);
				}
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * GNL_PARAM_TEXT.KOD = OTOMATIK_KULLANDIRIM text inin parametrelerine gore otomatik kullandirim
	 * islemi baslatir.
	 */
	@GraymoundService("BNSPR_OTOMATIK_KULLANDIRIM_JOB_KMH")
	public static GMMap autoKUllandirimKmh(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TABLE";
		boolean isOtoKul = false;
		String durumKodu = null;
		GMMap iptalMap = new GMMap();
		GMMap hataMap = new GMMap();
		int hataSatir = 0;
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String channelCode = DALUtil.getResult("select pkg_parametre.paramtextal ('OTOMATIK_KULLANDIRIM','KMH_BASVURU_KANAL_KODU','') from dual");
			String status = DALUtil.getResult("select pkg_parametre.paramtextal ('OTOMATIK_KULLANDIRIM','BASVURU_DURUM_KODU','') from dual");
			String customerContact = DALUtil.getResult("select pkg_parametre.paramtextal ('OTOMATIK_KULLANDIRIM','MUSTERI_KONTAKT','') from dual");

			String fetchQuery = String.format("SELECT B.BASVURU_NO, M.MUSTERI_NO, M.SUBE_KODU, B.ONAY_TUTAR KDH_LIMIT, M.MUSTERI_KONTAKT, K.E_MAIL, K.AD, K.SOYAD, B.WEB_SATIS_KANALI, K.TC_KIMLIK_NO TCKN," + " PKG_MUSTERI_EK.Musteri_BHS_varmi(M.MUSTERI_NO) BHS_VARMI, PKG_TFF_RM_DOKUMAN.Musteri_Kart_BHS_varmi (M.MUSTERI_NO) KART_BHS_VARMI" + " FROM BNSPR.BIR_BASVURU B, BNSPR.BIR_BASVURU_KIMLIK K, BNSPR.GNL_MUSTERI M" + " WHERE B.BASVURU_NO = K.BASVURU_NO AND B.MUSTERI_NO = M.MUSTERI_NO  " + " AND B.KANAL_KODU IN ('%s') AND B.DURUM_KODU IN ('%s') " + " AND B.KREDI_TUR = 5 " + " ORDER BY B.BASVURU_NO", channelCode, status, customerContact);
			GMMap basvuruMap = DALUtil.getResults(fetchQuery, tableName);
			
			for (int i = 0; i < basvuruMap.getSize(tableName); i++) {
				durumKodu = "";
				KmhBireyselBasvuru kmhBireyselBasvuru = (KmhBireyselBasvuru) session.get(KmhBireyselBasvuru.class, basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
				
				try{
				
					if (kmhBireyselBasvuru != null && kmhBireyselBasvuru.getIliskiliBasvuruNo() != null && basvuruMap.getString(tableName, i, "WEB_SATIS_KANALI") != null) {
						if ("webcrdca".equals(basvuruMap.getString(tableName, i, "WEB_SATIS_KANALI").toLowerCase())) {
							BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, kmhBireyselBasvuru.getIliskiliBasvuruNo());
							if (birBasvuru != null && birBasvuru.getDurumKodu() != null) {
								if (birBasvuru.getDurumKodu().equals("CEPTE") || birBasvuru.getDurumKodu().equals("EVRAKSIZ")) {
									BirKrediTaksit birKrediTaksit = (BirKrediTaksit) session.createCriteria(BirKrediTaksit.class).add(Restrictions.eq("id.basvuruNo", birBasvuru.getBasvuruNo())).add(Restrictions.eq("id.siraNo", new BigDecimal(1))).uniqueResult();
									if (birKrediTaksit == null || "ODENDI".equals(birKrediTaksit.getDurumKod()))
										isOtoKul = true;
									else
										isOtoKul = false;
								}
								else if (birBasvuru.getDurumKodu().equals("KAPANDI")) {
									List<MuhHesapKredi> acikKrediList = session.createCriteria(MuhHesapKredi.class).add(Restrictions.eq("musteriNo", birBasvuru.getMusteriNo())).add(Restrictions.or(Restrictions.isNull("takipDurumKodu"), Restrictions.eq("takipDurumKodu", "A"))).add(Restrictions.eq("durumKodu", "A")).list();
									if (acikKrediList.size() > 0) {
										isOtoKul = true;
									}
									else {
										isOtoKul = false;
									}
								}
								else {
									durumKodu = birBasvuru.getDurumKodu();
									isOtoKul = false;
								}
							}
						}
						else if ("passoligca".equals(basvuruMap.getString(tableName, i, "WEB_SATIS_KANALI").toLowerCase())) {
							TffBasvuru tffBasvuru = (TffBasvuru) session.get(TffBasvuru.class, kmhBireyselBasvuru.getIliskiliBasvuruNo());
							if (tffBasvuru != null && "KK".equals(tffBasvuru.getKartTipi()) && tffBasvuru.getKkBasvuruNo() != null) {
								KkBasvuru kkBasvuru = (KkBasvuru) session.get(KkBasvuru.class, tffBasvuru.getKkBasvuruNo());
								if (kkBasvuru != null) {
									int redCount = Integer.parseInt(DALUtil.getResult("select count(*) from bnspr.kk_basvuru_tarihce where durum_kodu='HUNTER' and islem_Sonrasi_durum_kodu = 'RED' and BASVURU_NO=" + kkBasvuru.getBasvuruNo()));
									if (redCount > 0) {
										durumKodu = "IPTAL";
										isOtoKul = false;
									}
									else {
										isOtoKul = true;
									}
								}
							}
							else {
								isOtoKul = true;
							}
						}
					}
					else {
						isOtoKul = true;
					}
	
					if (isOtoKul) {
						if (customerContact.equals(basvuruMap.get(tableName, i, "MUSTERI_KONTAKT")) && ("E".equals(basvuruMap.get(tableName, i, "BHS_VARMI")) || "E".equals(basvuruMap.get(tableName, i, "KART_BHS_VARMI")))) {
							iMap.put("BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
							iMap.put("MUSTERI_NO", basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
							iMap.put("MUSTERI_KONTAKT", basvuruMap.get(tableName, i, "MUSTERI_KONTAKT"));
							iMap.put("E_MAIL", basvuruMap.get(tableName, i, "E_MAIL"));
							iMap.put("AD", basvuruMap.get(tableName, i, "AD"));
							iMap.put("SOYAD", basvuruMap.get(tableName, i, "SOYAD"));
							iMap.put("KART_TIPI", basvuruMap.get(tableName, i, "KART_TIPI"));
							iMap.put("KART_NO", basvuruMap.get(tableName, i, "KART_NO"));
							iMap.put("KDH_LIMIT", basvuruMap.get(tableName, i, "KDH_LIMIT"));
							iMap.put("HESAP_NO", kmhBireyselBasvuru.getHesapNo());
							GMServiceExecuter.executeNT("BNSPR_OTOMATIK_KULLANDIRIM_PROCESS_KMH", iMap);
						}
					}
					else {
						if ("RED".equals(durumKodu)) {
							BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
							birBasvuru.setDurumKodu("RED");
							birBasvuru.setAksiyonKod("R");
							birBasvuru.setAksiyonKararKod("40");
							session.save(birBasvuru);
							session.flush();
						}
						else if ("IPTAL".equals(durumKodu)) {
							iptalMap.put("BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
							iptalMap.put("AKSIYON_KARAR_KOD", "16");
							GMServiceExecuter.call("BNSPR_TRN3172_BASVURU_IPTAL", iptalMap);
						}
					}
				
				}catch (Exception e) {
					hataMap.put(tableName, hataSatir, "BASVURU_NO", basvuruMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					hataMap.put(tableName, hataSatir, "MUSTERI_NO", basvuruMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					hataMap.put(tableName, hataSatir, "HATA_ACK", e.getMessage());
					hataSatir++;
				}
			}
			GMServiceExecuter.call("BNSPR_OTOMATIK_KULLANDIRIM_JOB_MAIL", hataMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_OTOMATIK_KULLANDIRIM_PROCESS_KMH")
	public static GMMap processAutoKullandirimKmh(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tempMap = new GMMap();
		BigDecimal customerNo = null;
		BigDecimal basvuruNo = null;
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			customerNo = iMap.getBigDecimal("MUSTERI_NO");
			basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			/** otomatik kullandirim **/
			tempMap.clear();
			tempMap.put("TRX_ONAYSIZ_ISLEM", "E");
			tempMap.put("BASVURU_NO", basvuruNo);
			tempMap.put("MUSTERI_NO", customerNo);
			tempMap.put("SUBE_KODU", "444");
			tempMap.put("MUSTERI_KONTAKT", iMap.get("MUSTERI_KONTAKT"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_OTOMATIK_KULLANDIR", tempMap));

			/** odeme plani maille gonderim **/
			GMMap dMap = new GMMap();
			dMap.put("APPLICATION_NO", basvuruNo);
			dMap.put("MAIL_TRANSFER", true);
			dMap.put("DYS_TRANSFER", true);
			dMap.put("EMAIL_TO", iMap.get("E_MAIL"));
			dMap.put("EMAIL_NAME", iMap.get("AD"));
			dMap.put("EMAIL_SURNAME", iMap.get("SOYAD"));
			dMap.put("EMAIL_TYPE", "KDH");
			dMap.put("KDH_LIMIT", iMap.get("KDH_LIMIT"));
			dMap.put("HESAP_NO", iMap.get("HESAP_NO"));

			List<?> belge = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();
			int k = 0;
			for (int row = 0; row < belge.size(); row++) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge.get(row);
				if (!"582".equals(birBasvuruBelge.getId().getDokumanKod())) {
					dMap.put("DOC_LIST", k, "CODE", birBasvuruBelge.getId().getDokumanKod());
					k++;
				}
			}

			// M��teriye gidecek mailde ad,soyad gibi alanlar g�z�kmeyecek
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			
			parameters.put("KISISEL_BILGI_GIZLE_EH", "E");
			dMap.put("PARAMETERS", parameters);
			
			dMap.put("DYS_TRANSFER", false);
			dMap.put("SEND_ATTACHMENTS", true);
			GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
			
			// DYS'ye at�lacak dok�manda t�m bilgiler yer alacak 
			dMap.put("DYS_TRANSFER", true);
			dMap.put("MAIL_TRANSFER", false);
			parameters.clear();
			dMap.put("PARAMETERS", parameters);
			GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return tempMap;
	}

	@GraymoundService("BNSPR_BASVURU_SOZLESMEDE_BEKLETME")
	public static GMMap basvuruSozlesmeBekletme(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap smsMap = new GMMap();
		BigDecimal beklemeGun = BigDecimal.ZERO;
		BigDecimal basvuruNo = BigDecimal.ZERO;

		try {
			beklemeGun = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", new GMMap().put("PARAMETRE", "BIR_SOZLESME_BEKLEME")).getBigDecimal("DEGER");
			String fetchQuery = String.format("select b.basvuru_no from bnspr.bir_basvuru b, bnspr.bir_satici s" + " where b.satici_kod = s.kod and s.bayi_kredi_tipi = '1' and b.sozlesme_bekleme_eh = 'E'" + " and b.durum_kodu = 'SOZLESME' and (pkg_muhasebe.Banka_Tarihi_Bul-%s) >= b.basvuru_tarihi", beklemeGun);
			GMMap basvuruMap = DALUtil.getResults(fetchQuery, "BASVURU_LIST");

			for (int i = 0; i < basvuruMap.getSize("BASVURU_LIST"); i++) {
				basvuruNo = basvuruMap.getBigDecimal("BASVURU_LIST", i, BASVURU_NO);
				oMap.clear();
				oMap.put("BASVURU_NO", basvuruNo);
				oMap.put("DURUM_KODU", "BASVURU");
				oMap.put("SKIP_DEVAM_SORGU", "E");
				oMap.put("SOZLESME_BEKLEME_EH", "H");
				oMap.put("DEVAM", "E");
				oMap = GMServiceExecuter.call("BNSPR_TRN3172_BASVURU_ILERLET", oMap);

				smsMap = GMServiceExecuter.call("BNSPR_CONSUMERLOAN_COMMON_ILERLET_SMS_GONDER", oMap);
			}			
			
			// PBIBK-546 PTT Toplu SMS Hata Alan Basvurular
			fetchQuery = "select b.basvuru_no from bnspr.bir_basvuru b, bnspr.clks_bir_basvuru_sms_talep s where b.web_satis_kanali = 'PTT_ONONAY' and b.basvuru_no = s.basvuru_no and b.durum_kodu = 'SOZLESME' and b.sozlesme_bekleme_eh = 'E' and s.pch is not null";
			basvuruMap = DALUtil.getResults(fetchQuery, "BASVURU_LIST");

			for (int i = 0; i < basvuruMap.getSize("BASVURU_LIST"); i++) {
				basvuruNo = basvuruMap.getBigDecimal("BASVURU_LIST", i, BASVURU_NO);
				oMap.clear();
				oMap.put("BASVURU_NO", basvuruNo);
				oMap = GMServiceExecuter.call("BNSPR_TRN3172_EVALUATE_PTT_BULK_APPLICATION", oMap);				
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_BASVURU_OTO_YAPILANDIRMA_JOB")
	public static GMMap basvuruOtoYapilandirma(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap bMap = new GMMap();
		GMMap tMap = new GMMap();
		Date taksitTarihi = new Date();
		int yeniTaksitSay;
		Session session = null;

		try {
			session = DAOSession.getSession("BNSPRDal");

			@SuppressWarnings("unchecked")
			List<BirKrediOtoYapilandirma> inputList = session.createCriteria(BirKrediOtoYapilandirma.class).add(Restrictions.or(Restrictions.isNull("durumKod"), Restrictions.eq("durumKod", "0"))).setMaxResults(500).list();

			for (BirKrediOtoYapilandirma input : inputList) {
				try {
					bMap.clear();
					bMap.put("BASVURU_NO", input.getBasvuruNo());
					bMap.put("ISLEM_TIPI", "2");
					bMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));

					bMap.putAll(GMServiceExecuter.call("BNSPR_TRN3199_BASVURU_LOV", bMap));
					bMap.put("SOZLESME_TARIHI", bMap.get("YENI_SOZLESME_TARIHI"));
					bMap.put("FAIZ_ORAN", bMap.get("SOZLESME_FAIZI"));

					tMap.put("BASVURU_NO", bMap.get("BASVURU_NO"));
					tMap.putAll(GMServiceExecuter.call("BNSPR_GET_TAKSIT_BILGILER", tMap));
					tMap.put("ILK_ACIK_TAKSIT_NO", tMap.get("TAKSIT_NO"));
					tMap.put("SOZLESME_TARIHI", bMap.get("YENI_SOZLESME_TARIHI"));
					if ("1".equals(tMap.getString("TAKSIT_NO"))) {
						if (bMap.get("GECIKME_GUN_SAYISI") != null) {
							tMap.put("OTELEME_GUN_SAYISI", bMap.get("GECIKME_GUN_SAYISI"));
						}
						else {
							tMap.put("OTELEME_GUN_SAYISI", "0");
						}
					}

					tMap.putAll(GMServiceExecuter.call("BNSPR_TRN3199_GET_ODENMEK_ISTENILEN_TARIH", tMap));

					taksitTarihi = tMap.getDate("ODENMEK_ISTENILEN_TARIH");
					Calendar c = Calendar.getInstance();
					c.setTime(taksitTarihi);
					c.add(Calendar.MONTH, input.getOtelemeAySayisi().intValue());
					taksitTarihi = c.getTime();
					bMap.put("TAKSIT_GUNU", taksitTarihi);

					bMap.putAll(GMServiceExecuter.call("BNSPR_TRN3199_GET_RECORD_LIST", bMap));
					bMap.put("MEVCUT_LIST", bMap.get("MEVCUT_RESULTS"));
					bMap.remove("MEVCUT_RESULTS");

					yeniTaksitSay = bMap.getInt("SUM_ACIK_TAKSIT") + input.getEkVade().intValue();
					bMap.put("VADE", yeniTaksitSay);
					bMap.put("SOZLESME_TELEFON", bMap.get("PHONE_NUMBER"));
					bMap.put("SOZLESME_EMAIL", bMap.get("EMAIL_ADDRESS"));

					bMap.putAll(GMServiceExecuter.call("BNSPR_TRN3199_OTELEME_GUN_HESAPLA", bMap));

					bMap.putAll(GMServiceExecuter.call("BNSPR_TRN3199_GECIKME_FAIZ_ORAN", bMap));

					bMap.put("ILK_TAKSIT_YONTEM", "2");
					bMap.putAll(GMServiceExecuter.call("BNSPR_TRN3199_NEW_GUNCEL_LIST", bMap));

					bMap.put("GEREKCE_KOD", input.getGerekceKod());
					bMap.put("OTELEME_AY_SAYISI", input.getOtelemeAySayisi());
					bMap.put("SOZLESME_CEP", bMap.get("PHONE_NUMBER"));
					GMServiceExecuter.executeNT("BNSPR_TRN3199_SAVE", bMap);
					// GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3199_SAVE", bMap);

					input.setDurumKod("1");
				}
				catch (Exception e) {
					logger.error(input.getBasvuruNo() + " nolu basvuru oto yapilandirma hata : ", e);
					input.setDurumKod("2");
					if (e.getMessage() != null) {
						input.setDurumAciklama(e.getMessage().length() > 3000 ? e.getMessage().substring(0, 3000) : e.getMessage());
					}
				}

				session.saveOrUpdate(input);
				session.flush();
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}
}
