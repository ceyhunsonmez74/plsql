package tr.com.calikbank.bnspr.consumerloan.document.type;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.calikbank.bnspr.consumerloan.utils.Enums;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMRuntimeException;

public class DocumentCreator {

	public static WebCreditDocument createWebCreditDocument(int documentCode){
		if(documentCode==Enums.CreditDocTypes.BEFORE_AGGREEMENT.getCode()){
			return new BeforeAgreementInfo();
			
		}else if(documentCode==Enums.CreditDocTypes.CONSUMER_CREDIT.getCode()){
			return new ConsumerCreditAgreement();
			
		}else if(documentCode==Enums.CreditDocTypes.BANKING_SERVICE_AGGREEMENT.getCode()){
			return new BankingServiceAgreement();
			
		}else if(documentCode==Enums.CreditDocTypes.BANKING_SERVICE_PRE_AGGREEMENT.getCode()){
			return new BankingServicePreAgreement();
			
		}else if(documentCode==Enums.CreditDocTypes.CREDIT_CARD_INFO.getCode()){
			return new CreditCardInfo();
			
		}else if(documentCode==Enums.CreditDocTypes.CREDIT_INFO.getCode()){
			return new CreditInfo();
			
		}else if(documentCode==Enums.CreditDocTypes.PRODUCT_INFO.getCode()){
			return new ProductInfo();
			
		}else if(documentCode==Enums.CreditDocTypes.CREDIT_PAYMENT_PLAN.getCode()){
			return new CreditPaymentPlan();
		
		}else if(documentCode==Enums.CreditDocTypes.PRE_AGGREEMENT.getCode()){
			return new PreAgreementInfo();
			
		}else if(documentCode==Enums.CreditDocTypes.KDH_AGGREEMENT.getCode()){
			return new KdhAgreement();
			
		}else if(documentCode==Enums.CreditDocTypes.KDH_INFO_FORM.getCode()){
			return new KdhInfoForm();
		
		}else if(documentCode==Enums.CreditDocTypes.KVK_FORM.getCode()){
			return new KvkForm();
	
		}else if(documentCode==Enums.CreditDocTypes.TRANSFER_FORM.getCode()){
			return new TransferForm();
			
		}else if(documentCode==Enums.CreditDocTypes.KDH_PRE_INFO_FORM.getCode()){
			return new KdhPreInfoForm();
		
		}
		throw new GMRuntimeException(0, "Gecersiz Web Kredi Dokuman Kodu!");
	}
	
	public static WebCreditDocument createDealerDocument(int documentCode){
		Session session = null;
		try{
			session = DAOSession.getSession("BNSPRDal");
		    Criteria criteria = session.createCriteria(GnlParamText.class)
		    										.add(Restrictions.eq("kod", "BIR_ELEKTRONIK_BELGE_TIP"))
		    										.add(Restrictions.eq("key1", String.valueOf(documentCode)));
		    										
			GnlParamText gnlParamText = (GnlParamText) criteria.uniqueResult();
			
			if(gnlParamText != null && gnlParamText.getKey3() != null){
				return new DealerDocument("bayiPortal", gnlParamText.getKey3(), documentCode);
			}else{
				throw new GMRuntimeException(0, "Dokuman kodu BIR_ELEKTRONIK_BELGE_TIP de tanimli degil!");
			}
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
