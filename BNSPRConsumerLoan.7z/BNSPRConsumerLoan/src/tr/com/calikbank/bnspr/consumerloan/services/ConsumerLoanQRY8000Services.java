package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.BasicClientConnectionManager;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAdkBasvuru;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruSmsTalep;
import tr.com.calikbank.bnspr.consumerloan.netmera.EventTypeEnum;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY8000Services {

	public final static String KAYIT = "0";
	public final static String ONAY = "1";
	public final static String RED = "2";
	public final static String IPTAL = "3";
	public final static String KULLANDIRIM = "4";
	public final static String HATA = "5";

	private final static String BIR_ADK_BASVURU_ONONAY_EVENT_NO = "62";
	private static final String confFile = "configuration/aktifbank-int-ononay.properties";
	private static Configurator configurator = null;
	private static Logger logger = Logger.getLogger(ConsumerLoanQRY8000Services.class);

	/**
	 * Ekran acilisinda kullanilacak degerleri bulur<br>
	 * 
	 * @author murat.el
	 * @since PY-11099
	 * @param iMap
	 *            - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>KANAL_KODLARI - Kanal listesi
	 */
	@GraymoundService("BNSPR_TRN8000_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			GMMap sorguMap = new GMMap();
			// Kanal Kodlari
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3109_GET_KANAL_KODLARI", sorguMap));
			
			iMap.put("KOD", "BIR_ADK_BASVURU_AKIS_TURU");
			oMap.put("AKIS_TURU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * 
	 * @author murat.el
	 * @since PY-11099
	 * @param iMap
	 *            - Islem bilgileri<br>
	 *            <li>DOSYA - Islem yapilmak istenen excel dosyasi <li>TRX_NO - Islem numarasi <li>KANAL - Basvurunun kanal bilgisi <li>KREDI_TUR - Basvurunun kredi turu <li>KAMPANYA - Basvurunun kredi kampanyasi <li>TUTAR - Istenen kredi tutari <li>VADE - Istenen kredi vadesi
	 * @return Islem sonucu<br>
	 *         <li>RESPONSE - Islem sonuc kodu(0:Basarisiz|2:Basarili)
	 */
	@GraymoundService("BNSPR_TRN8000_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();

		String wrongTckn = "";
		oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
		GMMap sorguMap = new GMMap();

		try {
			// 1. Excel kolon sayisi kontrol
			sorguMap.clear();
			sorguMap.put("PARAMETRE", "BIR_ADK_BASVURU_KOLON_SAYISI");
			String kolonSayisi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap).getString("DEGER");

			// 2. Excelden datalari al
			GMMap excelMap = new GMMap();
			excelMap.put("DOSYA", iMap.get("DOSYA"));
			excelMap.put("KOLON_SAYISI", kolonSayisi);
			excelMap.put("BASLIK_VAR_MI", Constants.EVET);
			excelMap.putAll(GMServiceExecuter.execute("BNSPR_EXCEL_TO_LIST", excelMap));// TABLE
			// Kontrol
			String excelTableName = "TABLE";
			if (excelMap.get(excelTableName) == null || excelMap.getSize(excelTableName) < 1) {
				ConsumerLoanCommonServices.raiseGMError("660", "Dosya icerisinde data bulunamadi");
			}

			// 3.Excelde tekrarlayan TCKN lerin al�nmamas�
			Set<String> tcknSet = new HashSet<String>();

			for (int i = 0; i < excelMap.getSize(excelTableName); i++) {
				tcknSet.add((String) excelMap.get(excelTableName, i, "TC_KIMLIK_NO"));
			}

			// 4. Alinan datalari havuza kaydet
			Iterator<String> iterator = tcknSet.iterator();
			while (iterator.hasNext()) {
				sorguMap.clear();
				sorguMap.put("TC_KIMLIK_NO", iterator.next());
				sorguMap.put("AKTARIM_NO", iMap.get("TRX_NO"));
				sorguMap.put("AKTARIM_KANALI", "DOSYA");
				sorguMap.put("AKIS_TURU", iMap.getString("AKIS_TURU", "O"));// On onayli basvuru
				sorguMap.put("KANAL_KOD", iMap.get("KANAL"));
				sorguMap.put("KREDI_TUR_KOD", iMap.get("KREDI_TUR"));
				sorguMap.put("KAMPANYA_KOD", iMap.get("KAMPANYA"));
				sorguMap.put("TUTAR", iMap.get("TUTAR"));
				sorguMap.put("VADE", iMap.get("VADE"));
				sorguMap.put("SEGMENT", iMap.get("SEGMENT"));
				sorguMap.put("SEGMENT_ALT_KOD", iMap.get("SEGMENT_ALT_KOD"));
				sMap = new GMMap();
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN8000_SAVE_HAVUZ", sorguMap));
				// hatal� olan tcknler
				if (sMap.getString("WRONG_TCKN_VALUES") != null) {
					wrongTckn = wrongTckn.concat(sMap.getString("WRONG_TCKN_VALUES") + " ");
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		oMap.put("WRONG_TCKN", wrongTckn);
		oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_SUCCESS);
		return oMap;
	}

	/**
	 * Adk basvuru havuzuna islenmek uzere on onay basvuru talebi kaydeder.<br>
	 * 
	 * @author murat.el
	 * @since PY-11099
	 * @param iMap
	 *            - Islem bilgileri<br>
	 *            <li>TC_KIMLIK_NO - Basvuru sahibi TC kimlik no <li>AKIS_TURU - Basvurunun tipi (O:On Onayli) <li>KANAL_KOD - Basvurunun kanal bilgisi <li>KREDI_TUR_KOD - Basvurunun kredi turu <li>KAMPANYA_KOD - Basvurunun kredi kampanyasi <li>AKTARIM_NO - Veri aktarim numarasi <li>AKTARIM_KANALI - Verinin aktarilma sekli(DOSYA:Excel) <li>TUTAR - Istenen kredi tutari <li>VADE - Istenen kredi
	 *            vadesi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN8000_SAVE_HAVUZ")
	public static GMMap saveHavuz(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

			// 1.Alan Kontrolleri

			// Tc Kimlik no
			if (StringUtils.isBlank(iMap.getString("TC_KIMLIK_NO"))) {
				ConsumerLoanCommonServices.raiseGMError("330", "Tc Kimlik No");
			}
			else {
				// TCKN kontrolu
				sorguMap.clear();
				sorguMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
				sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", sorguMap));

			}

			if (!"0".equals(sorguMap.getString("SONUC"))) {
				// Akis turu
				String akisTuru = iMap.getString("AKIS_TURU");
				if (StringUtils.isBlank(akisTuru)) {
					ConsumerLoanCommonServices.raiseGMError("330", "Akis Turu");
				}
				else {
					sorguMap.clear();
					sorguMap.put("KOD", "BIR_ADK_BASVURU_AKIS_TURU");
					sorguMap.put("KEY1", akisTuru);
					GMServiceExecuter.execute("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap);
				}
				// Kanal
				String kanalKod = iMap.getString("KANAL_KOD");
				if (StringUtils.isBlank(kanalKod)) {
					ConsumerLoanCommonServices.raiseGMError("330", "Kanal");
				}
				// Kredi Tur
				String krediTurKod = iMap.getString("KREDI_TUR_KOD");
				if (StringUtils.isBlank(krediTurKod)) {
					ConsumerLoanCommonServices.raiseGMError("330", "Kredi Turu");
				}
				// Kampanya
				String kampanyaKod = iMap.getString("KAMPANYA_KOD");
				if (StringUtils.isBlank(kampanyaKod)) {
					ConsumerLoanCommonServices.raiseGMError("330", "Kampanya");
				}

				// 2.Default alanlari ata
				// Id al
				sorguMap.clear();
				sorguMap.put("TABLE_NAME", "BIR_ADK_BASVURU");
				BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap).getBigDecimal("ID");
				// Durum kodu belirle
				sorguMap.clear();
				sorguMap.put("KOD", "BIR_ADK_BASVURU_DURUM_KOD");
				sorguMap.put("KEY1", KAYIT);// Kayit okundu.
				String durumAciklama = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");

				// 3.Havuza eklenecek datayi olustur
				BirAdkBasvuru birAdkBasvuru = new BirAdkBasvuru();
				birAdkBasvuru.setAkisTuru(akisTuru);
				birAdkBasvuru.setAktarimNo(iMap.getBigDecimal("AKTARIM_NO"));
				birAdkBasvuru.setAktarimKanali(iMap.getString("AKTARIM_KANALI"));
				birAdkBasvuru.setDurumAciklama(durumAciklama);
				birAdkBasvuru.setDurumKod(KAYIT);
				birAdkBasvuru.setId(id);
				birAdkBasvuru.setKampanyaKod(iMap.getBigDecimal("KAMPANYA_KOD"));
				birAdkBasvuru.setKanalKod(iMap.getString("KANAL_KOD"));
				birAdkBasvuru.setKrediTurKod(iMap.getBigDecimal("KREDI_TUR_KOD"));
				birAdkBasvuru.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
				birAdkBasvuru.setTutar(iMap.getBigDecimal("TUTAR"));
				birAdkBasvuru.setVade(iMap.getBigDecimal("VADE"));
				birAdkBasvuru.setMusteriSegment(iMap.getString("SEGMENT"));
				birAdkBasvuru.setMusteriSegmentAltKod(iMap.getString("SEGMENT_ALT_KOD"));
				birAdkBasvuru.setKaynak(iMap.getString("KAYNAK"));

				session.saveOrUpdate(birAdkBasvuru);
				session.flush();

				oMap.put("ID", id);

			}
			else {
				oMap.put("WRONG_TCKN_VALUES", iMap.getString("TC_KIMLIK_NO"));
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Adk basvuru havuzunda bulunan kaydin durumunu gunceller.
	 * Ononay akisindaki talep onay almissa EVAMi besler<br>
	 * 
	 * @author murat.el
	 * @since PY-11099
	 * @param iMap
	 *            - Islem bilgileri<br>
	 *            <li>ID - Adk basvuru havuz id <li>DURUM_KOD - Yeni Durum <li>DURUM_ACIKLAMA - Yeni Durum Aciklama <li>BASVURU_NO - Olusturulan basvuru numarasi <li>ONAY_TUTAR - Onaylanan kredi tutari <li>ONAY_VADE - Onaylanan kredi vadesi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN8000_UPDATE_STATUS")
	public static GMMap updateStatus(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BirAdkBasvuru birAdkBasvuru = null;
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			// Durum aciklamasi al
			sorguMap.clear();
			sorguMap.put("KOD", "BIR_ADK_BASVURU_DURUM_KOD");
			sorguMap.put("KEY1", iMap.getString("DURUM_KOD"));
			String durumAciklama = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");

			// Guncelle
			sorguMap.clear();
			sorguMap.put("ID", iMap.get("ID"));
			sorguMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
			sorguMap.put("DURUM_ACIKLAMA", iMap.getString("DURUM_ACIKLAMA", durumAciklama));
			sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sorguMap.put("ONAY_TUTAR", iMap.get("ONAY_TUTAR"));
			sorguMap.put("ONAY_VADE", iMap.get("ONAY_VADE"));
			sorguMap.put("KONSOLIDASYON_LIMIT", iMap.get("KONSOLIDASYON_LIMIT"));
			if (ONAY.equals(iMap.getString("DURUM_KOD"))) {
				birAdkBasvuru = (BirAdkBasvuru) session.get(BirAdkBasvuru.class, iMap.getBigDecimal("ID"));

				GMMap parameterMap = new GMMap();
				if (birAdkBasvuru.getKrediTurKod() != null && birAdkBasvuru.getKrediTurKod().compareTo(new BigDecimal(5)) == 0) {
					parameterMap.put("KEY1", "KDH");
					iMap.put("KREDI_TUR", "5");
				}
				else {
					if("S".equals(birAdkBasvuru.getAkisTuru())){
						parameterMap.put("KEY1", "SPOT");
					}else if("R".equals(birAdkBasvuru.getAkisTuru())){
						parameterMap.put("KEY1", "RETENTION");
					}else if("P".equals(birAdkBasvuru.getAkisTuru())){
						parameterMap.put("KEY1", "PTT_SMS");
					}else if("T".equals(birAdkBasvuru.getAkisTuru())){
						parameterMap.put("KEY1", "PTT_ONONAY");
					}else if("SMS".equals(iMap.getString("AKTARIM_KANALI")) || "YIM_SMS".equals(iMap.getString("AKTARIM_KANALI")) || "PTT_SMS".equals(iMap.getString("AKTARIM_KANALI"))){
						parameterMap.put("KEY1", "KREDI");
					}else{
						parameterMap.put("KEY1", "WEB");
					}
					
					iMap.put("KREDI_TUR", "1");
				}
				iMap.put("TC_KIMLIK_NO", birAdkBasvuru.getTcKimlikNo());
				parameterMap.put("KOD", "BIR_ADK_BASVURU_GEC_SURE");
				int gecerliGunSayisi = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", parameterMap).getInt("TEXT");

				Date gecerlilikTarihi = Calendar.getInstance().getTime();
				gecerlilikTarihi = DateUtils.addDays(gecerlilikTarihi, gecerliGunSayisi);
				sorguMap.put("GECERLILIK_TARIHI", gecerlilikTarihi);
			}
			update(sorguMap);

			// EVAM kontrollerini yap
			// Baska bir akista baska bir durum icin event istenirse
			// paramtextten evama beslencek mi kontrolu yapilarak ilerlenebilir.k
			if (ONAY.equals(iMap.getString("DURUM_KOD"))) {
				if("T".equals(birAdkBasvuru.getAkisTuru())){
					GMMap onOnayBilgi = new GMMap();
 					onOnayBilgi.put("TC_KIMLIK_NO", birAdkBasvuru.getTcKimlikNo());
 					onOnayBilgi.put("KREDI_TURU", birAdkBasvuru.getKrediTurKod());
 					onOnayBilgi.put("LIMIT_TURU", birAdkBasvuru.getAkisTuru());
 					oMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_ON_ONAY_BILGI", onOnayBilgi));
 					
 					oMap.put("KAYNAK", "BULK");
 					createEvamEventPtt(oMap);
				}else{
					sorguMap.clear();
					sorguMap.put("EVENT_TYPE_NO", BIR_ADK_BASVURU_ONONAY_EVENT_NO);
					sorguMap.put("EVENT_REF_NO", iMap.get("ID"));
					GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", sorguMap);
					
					/** netmera call **/
					sendEventToNetmera(iMap);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static void sendEventToNetmera(GMMap iMap) {
		iMap.put("EVENT_TYPE", EventTypeEnum.OnOnayEvent.toString());
		if("1".equals(iMap.getString("KREDI_TUR"))){
			iMap.put("KREDI_ON_ONAY_TUTAR", iMap.getBigDecimal("ONAY_TUTAR"));
			iMap.put("KDH_ON_ONAY_TUTAR", BigDecimal.ZERO);
		}else{
			iMap.put("KDH_ON_ONAY_TUTAR", iMap.getBigDecimal("ONAY_TUTAR"));
			iMap.put("KREDI_ON_ONAY_TUTAR", BigDecimal.ZERO);
		}
		GMServiceExecuter.executeAsync("BNSPR_CL_SEND_EVENT_TO_NETMERA", iMap);
	}
	
	/**
	 * TC_KIMLIK_NO 
	 * ilgili tc kimlik noya ait �n onay datas�n� netmeraya besler.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN8000_NETMERA_EVENT")
	public static GMMap netmeraEvent(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			if(!"".equals(iMap.getString("TCKN"))){
				iMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));;
			}
			iMap.put("EVENT_TYPE", EventTypeEnum.OnOnayEvent.toString());
			iMap.put("KREDI_TURU", 1);
			oMap.putAll(GMServiceExecuter.call("BNSPR_CL_GET_ON_ONAY_BILGI", iMap));
			iMap.put("KREDI_ON_ONAY_TUTAR", ConsumerLoanCommonServices.nvl(oMap.getBigDecimal("TUTAR"), BigDecimal.ZERO));
			
			iMap.put("KREDI_TURU", 5);
			oMap.putAll(GMServiceExecuter.call("BNSPR_CL_GET_ON_ONAY_BILGI", iMap));
			iMap.put("KDH_ON_ONAY_TUTAR", ConsumerLoanCommonServices.nvl(oMap.getBigDecimal("TUTAR"), BigDecimal.ZERO));
			
			GMServiceExecuter.execute("BNSPR_CL_SEND_EVENT_TO_NETMERA", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Alinan bilgilerle adk basvuru havuzundaki verilen kaydi gunceller.<br>
	 * 
	 * @author murat.el
	 * @since PY-11099
	 * @param iMap
	 *            - Islem bilgileri<br>
	 *            <li>ID - Adk basvuru havuz id <li>DURUM_KOD - Yeni Durum <li>DURUM_ACIKLAMA - Yeni Durum Aciklama <li>BASVURU_NO - Olusturulan basvuru numarasi <li>ONAY_TUTAR - Onaylanan kredi tutari <li>ONAY_VADE - Onaylanan kredi vadesi
	 * @return Output yok<br>
	 */
	@GraymoundService("BNSPR_TRN8000_UPDATE")
	public static GMMap update(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			// Durum guncelle
			BirAdkBasvuru birAdkBasvuru = (BirAdkBasvuru) session.get(BirAdkBasvuru.class, iMap.getBigDecimal("ID"));
			if (birAdkBasvuru != null) {
				birAdkBasvuru.setDurumKod(ConsumerLoanCommonServices.nvl(iMap.getString("DURUM_KOD"), birAdkBasvuru.getDurumKod()));
				birAdkBasvuru.setDurumAciklama(ConsumerLoanCommonServices.nvl(iMap.getString("DURUM_ACIKLAMA"), birAdkBasvuru.getDurumAciklama()));
				birAdkBasvuru.setBasvuruNo(ConsumerLoanCommonServices.nvl(iMap.getBigDecimal("BASVURU_NO"), birAdkBasvuru.getBasvuruNo()));
				birAdkBasvuru.setOnayTutar(ConsumerLoanCommonServices.nvl(iMap.getBigDecimal("ONAY_TUTAR"), birAdkBasvuru.getOnayTutar()));
				birAdkBasvuru.setOnayVade(ConsumerLoanCommonServices.nvl(iMap.getBigDecimal("ONAY_VADE"), birAdkBasvuru.getOnayVade()));
				birAdkBasvuru.setKonsolidasyonLimit(ConsumerLoanCommonServices.nvl(iMap.getBigDecimal("KONSOLIDASYON_LIMIT"), birAdkBasvuru.getKonsolidasyonLimit()));
				if (StringUtils.isNotBlank(iMap.getString("GECERLILIK_TARIHI"))) {
					birAdkBasvuru.setGecerlilikTarihi(iMap.getDate("GECERLILIK_TARIHI"));
				}

				session.saveOrUpdate(birAdkBasvuru);
				session.flush();
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Adk basvuru numarasi ya da adk havuz idsinden adk basvuruya ait bilgileri alir.<br>
	 * 
	 * @author murat.el
	 * @since PY-11099
	 * @param iMap
	 *            - Islem bilgileri<br>
	 *            <li>ID - Adk basvuru havuz id <li>BASVURU_NO - Olusturulan basvuru numarasi
	 * @return oMap - Sonuc bilgileri<br>
	 *         <li>ID - Adk basvuru havuz id <li>BASVURU_NO - Olusturulan basvuru numarasi
	 */
	@GraymoundService("BNSPR_TRN8000_GET_INFO")
	public static GMMap getBirAdkBasvuruById(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			// Kaydi al
			BirAdkBasvuru birAdkBasvuru = null;
			if (StringUtils.isNotBlank(iMap.getString("ID"))) {
				birAdkBasvuru = (BirAdkBasvuru) session.get(BirAdkBasvuru.class, iMap.getBigDecimal("ID"));
			}
			else if (StringUtils.isNotBlank(iMap.getString("BASVURU_NO"))) {
				birAdkBasvuru = (BirAdkBasvuru) session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			}
			// Kontrol
			if (birAdkBasvuru != null) {
				oMap.put("ID", birAdkBasvuru.getId());
				oMap.put("BASVURU_NO", birAdkBasvuru.getBasvuruNo());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * list on onay job service
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN8000_LIST_ONONAY_JOB")
	public static GMMap listOnOnayBasvuruJob(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_RC8000.listOnOnayBasvuruJob");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * process on onay job service
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN8000_PROCESS_ONONAY_JOB")
	public static GMMap processOnOnayBasvuruJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap sMap = new GMMap();
			sMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
			sMap.put("KANAL_KOD", iMap.get("KANAL_KOD"));
			sMap.put("KAMP_KOD", iMap.get("KAMPANYA_KOD"));
			sMap.put("KRD_TUR_KOD", iMap.get("KREDI_TUR_KOD"));
			sMap.put("DOVIZ_KODU", "TRY");
			sMap.put("TUTAR", iMap.get("TUTAR"));
			sMap.put("VADE", iMap.get("VADE"));
			sMap.put("CALL_NBSM", "E");
			if(iMap.getString("WEB_SATIS_KANALI") != null){
				sMap.put("WEB_SATIS_KANALI", iMap.get("WEB_SATIS_KANALI"));
			}else{
				if("R".equals(iMap.getString("AKIS_TURU"))){
					sMap.put("WEB_SATIS_KANALI", "retention");
				}else if("S".equals(iMap.getString("AKIS_TURU"))){
					sMap.put("WEB_SATIS_KANALI", "KREDI_ODE");
				}else if("T".equals(iMap.getString("AKIS_TURU"))){
					iMap.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", iMap).getBigDecimal("ID"));
					sMap.put("WEB_SATIS_KANALI", "PTT_ONONAY");
					sMap.put("KANAL_KOD", "7");
				}
			}
			
			if(iMap.getString("CEP_TEL_ALAN_KODU") != null){
				sMap.put("CEP_TEL_ALAN_KODU", iMap.get("CEP_TEL_ALAN_KODU"));
				sMap.put("CEP_TEL_NO", iMap.get("CEP_TEL_NO"));
			}
			
			if("P".equals(iMap.getString("AKIS_TURU")) || "T".equals(iMap.getString("AKIS_TURU"))){
				sMap.putAll(pttBasvuruBilgi(iMap));
				
				if (StringUtils.isBlank(sMap.getString("CEP_TEL_NO")) || StringUtils.isBlank(sMap.getString("CEP_TEL_ALAN_KODU"))) {
					ConsumerLoanCommonServices.raiseGMError("330", "Cep Tel");
				}
				
				sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sMap.put("TRX_NO", iMap.get("TRX_NO"));
				
				GMServiceExecuter.executeNT("BNSPR_CL_ONONAY_KONSOLIDASYON_KAYIT", iMap);
			}else{
				sMap.putAll(oncekiBasvuruBilgi(iMap));
			}
			
			sMap.put("KAYNAK", iMap.getString("KAYNAK"));

			sMap.putAll(GMServiceExecuter.execute("BNSPR_CL_ONONAY_BASVURU", sMap));
			//sMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_CL_ONONAY_BASVURU", sMap));

			if ("E".equals(sMap.getString("RESPONSE_CODE"))) {
				// validasyon hatalari, exception firlat.
				throw new Exception(sMap.getString("RESPONSE_MESSAGE"));
			}
			else {
				// kaydin durumu guncelle..
				if ("E".equals(sMap.getString("DEVAM")) && "Accept".equals(sMap.getString("NBSM_KARAR_KOD")) && "N".equals(sMap.getString("NBSM_FRAUD_SONUC"))) {
					if (sMap.get("ONAY_TUTAR") == null || sMap.getBigDecimal("ONAY_TUTAR").compareTo(BigDecimal.ZERO) == 0) {
						if(ConsumerLoanCommonServices.nvl(sMap.getBigDecimal("SPOT_KREDI_LIMIT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0){
							sMap.put("ONAY_TUTAR", sMap.get("SPOT_KREDI_LIMIT"));
						}else if(ConsumerLoanCommonServices.nvl(sMap.getBigDecimal("ONONAY_KONSOLIDASYON_LIMIT"), BigDecimal.ZERO).compareTo(BigDecimal.ZERO) > 0){
							sMap.put("ONAY_TUTAR", "0");
						}else{
							throw new Exception("NBSM Onay Tutar Hatasi");
						}
					}
					oMap.put("DURUM_KOD", ONAY);
					oMap.put("ID", iMap.get("ID"));
					oMap.put("BASVURU_NO", sMap.get("BASVURU_NO"));
					oMap.put("ONAY_TUTAR", sMap.get("ONAY_TUTAR"));
					oMap.put("ONAY_VADE", iMap.get("VADE"));
					oMap.put("FAIZ_ORANI", sMap.get("FAIZ_ORANI"));
					oMap.put("KONSOLIDASYON_LIMIT", sMap.get("ONONAY_KONSOLIDASYON_LIMIT"));
				}
				else {
					oMap.put("DURUM_KOD", RED);
					oMap.put("ID", iMap.get("ID"));
					oMap.put("BASVURU_NO", sMap.get("BASVURU_NO"));
					oMap.put("SPOT_MESSAGE", sMap.get("SPOT_MESSAGE"));
					oMap.put("SPOT_MESSAGE_RISK", sMap.get("SPOT_MESSAGE_RISK"));
					if("Y".equals(sMap.getString("SPOT_MESSAGE_RISK")) || "Y".equals(sMap.getString("SPOT_MESSAGE"))){
						oMap.put("DURUM_KOD", IPTAL);
					}
				}
				GMServiceExecuter.execute("BNSPR_TRN8000_UPDATE_STATUS", oMap);
			}
		}
		catch (Exception e) {
			oMap.put("DURUM_KOD", HATA);
			oMap.put("DURUM_ACIKLAMA", e.getMessage());
			oMap.put("ID", iMap.get("ID"));
			GMServiceExecuter.execute("BNSPR_TRN8000_UPDATE_STATUS", oMap);
		}
		return oMap;
	}

	private static GMMap pttBasvuruBilgi(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			if("P".equals(iMap.getString("AKIS_TURU"))) {
				Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
				ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class, iMap.getBigDecimal("BASVURU_NO"));
				if(clksBirBasvuruSmsTalep != null){
					oMap.put("AYLIK_GELIR", clksBirBasvuruSmsTalep.getAylikGelir());
					oMap.put("PTT_ILK_MAAS_TARIHI", clksBirBasvuruSmsTalep.getIlkMaasTarihi());
					oMap.put("PTT_MAAS_ALINAN_KURUM", clksBirBasvuruSmsTalep.getMaasAlinanKurum());
					oMap.put("PTT_TAHSIS_NUMARASI", clksBirBasvuruSmsTalep.getTahsisNumarasi());
					oMap.put("PTT_SON_MAAS_TARIHI", clksBirBasvuruSmsTalep.getSonMaasTarihi());
					oMap.put("PTT_ONCEKI_MAAS_ODEME_TARIHI", clksBirBasvuruSmsTalep.getOncekiMaasOdemeTarihi());
					oMap.put("PTT_MAAS_EVDEN_MI", clksBirBasvuruSmsTalep.getPttMaasEvdenMi());
				}
			}else{
				conn = DALUtil.getGMConnection();

				String query = "{? = call PKG_RC8000.ptt_toplu_basvuru_bilgi(?) }";
				stmt = conn.prepareCall(query);
				stmt.registerOutParameter(1, -10);
				stmt.setString(2, iMap.getString("TC_KIMLIK_NO"));
				stmt.execute();

				rSet = (ResultSet) stmt.getObject(1);
				iMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
				if (iMap.getSize("RESULTS") > 0) {
					oMap.putAll(iMap.getMap("RESULTS", 0));
				}
			}
			
			oMap.put("PTT_MAAS_TARIH_SIKLIGI", "1");
			oMap.put("CALISMA_SEKLI", "E");
			oMap.put("PTT_ISLEMIN_YAPILDIGI_MERKEZ", "0");
			oMap.put("PTT_ISLEMIN_YAPILDIGI_SUBE", "0");
			oMap.put("PTT_SUBE_ILI", "034");
		}
		catch (Exception e) {
			throw e;// ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_TRN8000_ONONAY_LIMIT_SORGULA")
	public static GMMap onOnayLimitSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		StringBuilder query = null;

		try {
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_RC8000.on_onay_limit_sorgula");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.put("QUERY", query);

			configurator = Configurator.createConfiguratorFromProperties(confFile);
			ClientConnectionManager ccm = new BasicClientConnectionManager();
			HttpClient client = new DefaultHttpClient(ccm);
			String endpoint = configurator.getProperty("endpoint");
			oMap.put("ENDPOINT", endpoint);

			StringBuffer json = new StringBuffer();
			// {"PreApproveList":[{"tckn":"0"},{"tckn":"1"},{"tckn":"2"},{"tckn":"3"},{"tckn":"4"},{"tckn":"5"},{"tckn":"6"},{"tckn":"7"},{"tckn":"8"},{"tckn":"9"}]}
			while (rSet.next()) {
				json.append("{\"tckn\":\"" + rSet.getString("TCKN") + "\"},");
			}

			if (json.length() != 0) {
				String jsonStr = "{\"PreApproveList\":[ " + json.substring(0, json.length() - 1) + "]}";
				oMap.put("JSON", jsonStr);
				HttpPost post = new HttpPost(endpoint);
				StringEntity input = new StringEntity(jsonStr);
				input.setContentType("application/json");
				post.setEntity(input);

				HttpResponse response = client.execute(post);

				if (response.getStatusLine().getStatusCode() != 200) {
					throw new RuntimeException("Ba�lant� hatas� : " + response.getStatusLine().getStatusCode());
				}

				oMap.put("SONUC", "Ba�ar�l�");

			}

		}
		catch (Exception e) {
			logger.error("�n onay limit sorgulama s�ras�nda hata : " + e);
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}

		return oMap;
	}

	/**
	 * on onay job service
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN8000_ONONAY_JOB")
	public static GMMap onOnayBasvuruJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("IS_PARALLEL", true);
			iMap.put("LIST_SERVICE_NAME", "BNSPR_TRN8000_LIST_ONONAY_JOB");
			iMap.put("PROCESS_SERVICE_NAME", "BNSPR_TRN8000_PROCESS_ONONAY_JOB");
			oMap.put("PARAMETRE", "BIR_ADK_BASVURU_THREAD_SIZE");
			iMap.put("THREAD_SIZE", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N" , oMap).getInt("DEGER"));
			GMServiceExecuter.execute("BNSPR_PROCESS_CREDIT_CARD_JOB", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static GMMap oncekiBasvuruBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();

			String query = "{? = call PKG_RC8000.onceki_basvuru_bilgi(?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("TC_KIMLIK_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			iMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
			if (iMap.getSize("RESULTS") > 0) {
				oMap.putAll(iMap.getMap("RESULTS", 0));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN8000_SAVE_ONAY")
	public static GMMap saveOnay(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

			String akisTuru = iMap.getString("AKIS_TURU");
			if (StringUtils.isBlank(akisTuru)) {
				ConsumerLoanCommonServices.raiseGMError("330", "Akis Turu");
			}
			else {
				sorguMap.clear();
				sorguMap.put("KOD", "BIR_ADK_BASVURU_AKIS_TURU");
				sorguMap.put("KEY1", akisTuru);
				GMServiceExecuter.execute("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap);
			}
			// Kanal
			String kanalKod = iMap.getString("KANAL_KOD");
			if (StringUtils.isBlank(kanalKod)) {
				ConsumerLoanCommonServices.raiseGMError("330", "Kanal");
			}
			// Kredi Tur
			String krediTurKod = iMap.getString("KREDI_TUR_KOD");
			if (StringUtils.isBlank(krediTurKod)) {
				ConsumerLoanCommonServices.raiseGMError("330", "Kredi Turu");
			}
			// Kampanya
			String kampanyaKod = iMap.getString("KAMPANYA_KOD");
			if (StringUtils.isBlank(kampanyaKod)) {
				ConsumerLoanCommonServices.raiseGMError("330", "Kampanya");
			}

			// Id al
			sorguMap.clear();
			sorguMap.put("TABLE_NAME", "BIR_ADK_BASVURU");
			BigDecimal id = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap).getBigDecimal("ID");
			// Durum kodu belirle
			sorguMap.clear();
			sorguMap.put("KOD", "BIR_ADK_BASVURU_DURUM_KOD");
			sorguMap.put("KEY1", ONAY);
			String durumAciklama = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", sorguMap).getString("TEXT");

			BirAdkBasvuru birAdkBasvuru = new BirAdkBasvuru();
			birAdkBasvuru.setAkisTuru(akisTuru);
			birAdkBasvuru.setAktarimNo(iMap.getBigDecimal("AKTARIM_NO"));
			birAdkBasvuru.setAktarimKanali(iMap.getString("AKTARIM_KANALI"));
			birAdkBasvuru.setDurumAciklama(durumAciklama);
			birAdkBasvuru.setDurumKod(ONAY);
			birAdkBasvuru.setId(id);
			birAdkBasvuru.setKampanyaKod(iMap.getBigDecimal("KAMPANYA_KOD"));
			birAdkBasvuru.setKanalKod(iMap.getString("KANAL_KOD"));
			birAdkBasvuru.setKrediTurKod(iMap.getBigDecimal("KREDI_TUR_KOD"));
			birAdkBasvuru.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			birAdkBasvuru.setTutar(iMap.getBigDecimal("TUTAR"));
			birAdkBasvuru.setVade(iMap.getBigDecimal("VADE"));
			birAdkBasvuru.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birAdkBasvuru.setOnayTutar(iMap.getBigDecimal("TUTAR"));
			birAdkBasvuru.setOnayVade(iMap.getBigDecimal("VADE"));

			GMMap parameterMap = new GMMap();
			if (birAdkBasvuru.getKrediTurKod() != null && birAdkBasvuru.getKrediTurKod().compareTo(new BigDecimal(5)) == 0) {
				parameterMap.put("KEY1", "KDH");
			}
			else {
				if("S".equals(akisTuru)){
					parameterMap.put("KEY1", "SPOT");
				}else{
					parameterMap.put("KEY1", "WEB");
				}
			}
			parameterMap.put("KOD", "BIR_ADK_BASVURU_GEC_SURE");
			int gecerliGunSayisi = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", parameterMap).getInt("TEXT");

			Date gecerlilikTarihi = Calendar.getInstance().getTime();
			gecerlilikTarihi = DateUtils.addDays(gecerlilikTarihi, gecerliGunSayisi);
			iMap.put("GECERLILIK_TARIHI", gecerlilikTarihi);

			birAdkBasvuru.setGecerlilikTarihi(iMap.getDate("GECERLILIK_TARIHI"));

			session.saveOrUpdate(birAdkBasvuru);
			session.flush();
			
			if(!"S".equals(akisTuru)){
				/** netmera event **/
				iMap.put("ONAY_TUTAR", iMap.get("TUTAR"));
				iMap.put("KREDI_TUR", iMap.getString("KREDI_TUR_KOD"));
				sendEventToNetmera(iMap);
			}

			oMap.put("ID", id);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/**
	 * iptal on onay job service
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN8000_ONONAY_IPTAL_JOB")
	public static GMMap listOnOnayIptalJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		BirAdkBasvuru birAdkBasvuru = null;
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			conn = DALUtil.getGMConnection();

			query = new StringBuilder();
			query.append("{? = call ");
			query.append("PKG_RC8000.listOnOnayIptalJob");
			query.append("}");
			stmt = conn.prepareCall(query.toString());
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			
			while (rSet.next()) {				
				 birAdkBasvuru = (BirAdkBasvuru) session.get(BirAdkBasvuru.class, rSet.getBigDecimal(1));
				 birAdkBasvuru.setDurumKod(IPTAL);
				 
				 session.saveOrUpdate(birAdkBasvuru);
				 session.flush();
				 
				 /** netmera profile **/
				 iMap.put("TC_KIMLIK_NO", rSet.getString(2));
				 GMServiceExecuter.executeAsync("BNSPR_TRN8000_NETMERA_EVENT", iMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_KREDI_ON_ONAYLI_BASVURU")
	public static GMMap krediOnOnayliBasvuru(GMMap iMap) {
		GMMap adkOnOnay = new GMMap();
		GMMap tMap = new GMMap();
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		boolean isPttEmekli = false;
		BigDecimal campCode = null;
		int rejectedApp = 0;
		String processType = null;
		GMMap pMap = new GMMap();
		
		try {
			tMap.put("KOD", "KMH_ON_ONAY_PARAMS");
			tMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", tMap);
			
			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
			BigDecimal crdTypeCode = iMap.getBigDecimal("KREDI_TUR_KOD", new BigDecimal(1));
			processType = iMap.getString("LIMIT_TURU", tMap.getString("RESULTS", 0, "NAME"));
			String channelCode = iMap.getString("KANAL_KOD", tMap.getString("RESULTS", 1, "NAME")); 
			if("S".equals(processType)){
				campCode = tMap.getBigDecimal("RESULTS", 5, "NAME");
				rejectedApp = ((BigDecimal) DALUtil.callOracleFunction("{? = call pkg_rc8000.getCountRejectedOnOnay(?,?,?,?)}", BnsprType.NUMBER, BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"), BnsprType.NUMBER, null, BnsprType.NUMBER, new BigDecimal(1), BnsprType.STRING, processType)).intValue();
				
				/** Ptt emeklisi mi? **/
				String pttEmeklisimi = (String) DALUtil.callOneParameterFunction("{? = call  pkg_webkredi.ptt_emekli_kredi_varmi(?)}", Types.VARCHAR, iMap.getString("TC_KIMLIK_NO"));
				if ("E".equals(pttEmeklisimi)) {
					isPttEmekli = true;
					
					/** Ptt emeklileri icin sms talep yaratilir **/
					if(iMap.get("CEP_TEL_ALAN_KODU") == null) {
						iMap.putAll(oncekiBasvuruBilgi(iMap));
					}
					
					if(iMap.get("CEP_TEL_ALAN_KODU") != null) {
						pMap.put("MSISDN", "+90".concat(iMap.getString("CEP_TEL_ALAN_KODU").concat(iMap.getString("CEP_TEL_NO"))));					
						pMap.put("NATIONAL_IDENTIFICATION_NUMBER", iMap.getString("TC_KIMLIK_NO"));
						pMap.put("CHANNEL", "WEB");
						GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION", pMap);
					}
				}
			}else if("P".equals(processType)){
				campCode = tMap.getBigDecimal("RESULTS", 6, "NAME");
			}
			else if("D".equals(processType)){
				campCode = tMap.getBigDecimal("RESULTS", 7, "NAME");
			}
			else{
				campCode = tMap.getBigDecimal("RESULTS", 4, "NAME");
			}
			
 			if(!isPttEmekli){
 				if(rejectedApp == 0){
 					/** Retention ise yarim basvurulari iptale et **/
 					if("R".equals(iMap.getString("LIMIT_TURU", "O"))){
 						GMServiceExecuter.executeNT("BNSPR_CL_CC_CANCEL_APPLICATION", iMap);
 					}
 					
 					GMMap onOnayBilgi = new GMMap();
 					onOnayBilgi.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
 					onOnayBilgi.put("KREDI_TURU", crdTypeCode);
 					onOnayBilgi.put("LIMIT_TURU", processType);
 					oMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_ON_ONAY_BILGI", onOnayBilgi));
 					
 					if( oMap.getBigDecimal("TUTAR", BigDecimal.ZERO).compareTo(BigDecimal.ZERO) < 1){
 						tMap.put("DOVIZ_KODU", "TRY");
 						tMap.put("KANAL_KOD", channelCode);
 						tMap.put("KRD_TUR_KOD", crdTypeCode);
 						tMap.put("KAMP_URUN_ADI", campCode);
 						tMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_KREDI_MIN_MAX_DEGER", tMap));
 						
 						adkOnOnay.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
 						adkOnOnay.put("AKTARIM_NO", trxNo);
 						adkOnOnay.put("AKTARIM_KANALI", ConsumerLoanCommonServices.nvl(iMap.getString("AKTARIM_KANALI"), "KREDI_ODE"));
 						adkOnOnay.put("AKIS_TURU", processType);
 						adkOnOnay.put("KANAL_KOD", channelCode);
 						adkOnOnay.put("KREDI_TUR_KOD", crdTypeCode);
 						adkOnOnay.put("KAMPANYA_KOD", campCode);
 						if("SMS".equals(iMap.getString("AKTARIM_KANALI")) || "YIM_SMS".equals(iMap.getString("AKTARIM_KANALI")) || "DTU_SMS".equals(iMap.getString("AKTARIM_KANALI")) || ("PTT_SMS".equals(iMap.getString("AKTARIM_KANALI")) && !"7".equals(channelCode))){
 							if(iMap.getBigDecimal("TUTAR").compareTo(tMap.getBigDecimal("MAX_TUTAR")) > 0){
 								iMap.put("TUTAR", tMap.getBigDecimal("MAX_TUTAR"));
 							}else if(iMap.getBigDecimal("TUTAR").compareTo(tMap.getBigDecimal("MIN_TUTAR")) < 0){
 								iMap.put("TUTAR", tMap.getBigDecimal("MIN_TUTAR"));
 							}
 							iMap.put("VADE", iMap.getBigDecimal("VADE", tMap.getBigDecimal("MAX_VADE")));
 							if(iMap.getBigDecimal("VADE").compareTo(tMap.getBigDecimal("MAX_VADE")) > 0){
 								iMap.put("VADE", tMap.getBigDecimal("MAX_VADE"));
 							}else if(iMap.getBigDecimal("TUTAR").compareTo(tMap.getBigDecimal("MIN_VADE")) < 0){
 								iMap.put("VADE", tMap.getBigDecimal("MIN_VADE"));
 							}
 						}
 						adkOnOnay.put("TUTAR", iMap.getBigDecimal("TUTAR", tMap.getBigDecimal("MAX_TUTAR")));
 						adkOnOnay.put("VADE", iMap.getBigDecimal("VADE", tMap.getBigDecimal("MAX_VADE")));
 						adkOnOnay.put("KAYNAK", iMap.getString("KAYNAK"));
 						oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN8000_SAVE_HAVUZ", adkOnOnay));
 						
 						BirAdkBasvuru birAdkBasvuru = (BirAdkBasvuru) session.get(BirAdkBasvuru.class, oMap.getBigDecimal("ID"));
 						tMap.clear();
 						tMap.put("TC_KIMLIK_NO", birAdkBasvuru.getTcKimlikNo());
 						tMap.put("KANAL_KOD", birAdkBasvuru.getKanalKod());
 						tMap.put("KAMPANYA_KOD", birAdkBasvuru.getKampanyaKod());
 						tMap.put("KREDI_TUR_KOD", crdTypeCode);
 						tMap.put("DOVIZ_KODU", "TRY");
 						tMap.put("TUTAR", birAdkBasvuru.getTutar());
 						tMap.put("VADE", birAdkBasvuru.getVade());
 						tMap.put("ID", birAdkBasvuru.getId());
 						tMap.put("AKTARIM_NO", trxNo);
 						tMap.put("WEB_SATIS_KANALI", birAdkBasvuru.getAktarimKanali());
 						tMap.put("CEP_TEL_ALAN_KODU", iMap.get("CEP_TEL_ALAN_KODU"));
 						tMap.put("CEP_TEL_NO", iMap.get("CEP_TEL_NO"));
 						tMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
 						tMap.put("TRX_NO", iMap.get("TRX_NO"));
 						tMap.put("AKIS_TURU", birAdkBasvuru.getAkisTuru());
 						tMap.put("KAYNAK", iMap.getString("KAYNAK"));
 						oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN8000_PROCESS_ONONAY_JOB", tMap));
 						oMap.put("KREDI_LIMIT", oMap.get("ONAY_TUTAR"));
 						
 						if(RED.equals(oMap.getString("DURUM_KOD")) || IPTAL.equals(oMap.getString("DURUM_KOD"))){
 							if("Y".equals(oMap.getString("SPOT_MESSAGE"))){
 								oMap.put(Constants.RESPONSE, "5805");
 							}else if("Y".equals(oMap.getString("SPOT_MESSAGE_RISK"))){
 								oMap.put(Constants.RESPONSE, "5808");
 							}else{
	 	 						oMap.put(Constants.RESPONSE, "5801");
 							}
 							oMap.put(Constants.RESPONSE_DATA, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", oMap.getString(Constants.RESPONSE))).get("ERROR_MESSAGE"));
 						}else{
 							if(ONAY.equals(oMap.getString("DURUM_KOD"))){
 								oMap.put(Constants.RESPONSE, "00");
 							}else{
 								oMap.put(Constants.RESPONSE, "99");
 							}
 							oMap.put(Constants.RESPONSE_DATA, "�n onayl� ba�vuru al�nm��t�r.");
 						}
 						
 						oMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_ON_ONAY_BILGI", onOnayBilgi));
 					}else {
 						oMap.put("KREDI_LIMIT", oMap.get("TUTAR"));
 						oMap.put(Constants.RESPONSE, "00");
 						oMap.put(Constants.RESPONSE_DATA, "Aktif �n Onayl� Kayd� Bulunmaktad�r.");
 					}
 				}else {
 					if(rejectedApp != 0){
 						oMap.put(Constants.RESPONSE, 5803);
 						oMap.put(Constants.RESPONSE_DATA, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5803)).get("ERROR_MESSAGE"));
 					}
 				}
 			}else {
 				oMap.put(Constants.RESPONSE, 5218);
				oMap.put(Constants.RESPONSE_DATA, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5218)).get("ERROR_MESSAGE"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	private static void createEvamEventPtt(GMMap iMap) {
		BigDecimal eventTypeNo = BigDecimal.valueOf(89);
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String query = null;
		
		try{
			/** Evam event **/
			GMMap dataMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
	
			query = "{? = call pkg_webkredi.Get_Evam_Info_Yarim_Basvuru(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("BASVURU_NO"));
			stmt.execute();
	
			rSet = (ResultSet) stmt.getObject(1);
			dataMap.putAll(DALUtil.rSetMap(rSet));
			
			dataMap.put("TUTAR", iMap.getBigDecimal("TUTAR"));
			dataMap.put("VADE", iMap.getBigDecimal("VADE"));
			dataMap.put("DOSYA_MASRAFI", iMap.getBigDecimal("DOSYA_MASRAFI"));
			if(iMap.get("CEP_TEL") != null) {
				dataMap.put("CEP_TEL", iMap.get("CEP_TEL"));
			}
			dataMap.put("TAKSIT_TUTAR", iMap.get("AYLIK_TAKSIT"));
			dataMap.put("AYLIK_TAKSIT", iMap.get("AYLIK_TAKSIT"));
			dataMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORANI"));
			dataMap.put("FAIZ_ORANI_YILLIK", iMap.get("FAIZ_ORANI")!=null?iMap.getBigDecimal("FAIZ_ORANI").multiply(new BigDecimal(12)):null);
			dataMap.put("HESABA_YATACAK_TUTAR", iMap.getBigDecimal("HESABA_YATACAK_TUTAR"));
			dataMap.put("GERI_ODEME_TUTAR", iMap.getBigDecimal("TOPLAM_TAKSIT_TUTARI"));
			dataMap.put("COST_RATIO", iMap.getBigDecimal("COST_RATIO"));
			dataMap.put("GECIKME_FAIZ_ORAN", iMap.getBigDecimal("GECIKME_FAIZ_ORAN"));
			dataMap.put("KAYNAK", iMap.getString("KAYNAK"));
			
			GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", new GMMap().put("SCENARIO_KEY",
					dataMap.getString("SCENARIO_KEY")).put("EVENT_TYPE_NO", eventTypeNo).put("EVENT_REF_NO",
					iMap.getString("BASVURU_NO")).put("INTEGRATION_TYPE", "S").put("DATA_MAP",
					dataMap));
		
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CL_PTT_CREATE_SMS_PREAPPROVE")
	public static GMMap pttCreateSmsApprove(GMMap iMap) {
		GMMap oMap = new GMMap();
		String cepTel = null;
		String adiSoyadi = null;
		
		try{
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			cepTel = iMap.getString("CEP_TEL_ALAN_KODU").concat(iMap.getString("CEP_TEL_NO"));
			
			iMap.put("AKTARIM_KANALI", "PTT_SMS");
			iMap.put("LIMIT_TURU", "P");
			iMap.put("KANAL_KOD", "7");
			oMap.putAll(GMServiceExecuter.call("BNSPR_KREDI_ON_ONAYLI_BASVURU", iMap));
			
			if("00".equals(oMap.getString(Constants.RESPONSE))){
				/** Onay **/
				oMap.put("DURUM", "ONAY");
				oMap.put("ONAY_TUTAR", oMap.get("KREDI_LIMIT"));
				oMap.put("ONAY_VADE", oMap.get("VADE"));
				
				/** Evam event **/
				oMap.put("CEP_TEL", cepTel);
				oMap.put("KAYNAK", iMap.getString("KAYNAK"));
				createEvamEventPtt(oMap);
				
			}else if("5801".equals(oMap.getString(Constants.RESPONSE)) || "5805".equals(oMap.getString(Constants.RESPONSE)) || "5808".equals(oMap.getString(Constants.RESPONSE)) || "5803".equals(oMap.getString(Constants.RESPONSE))){
				/** Red **/
				oMap.put("DURUM", "RED");
			}else{
				oMap.put("DURUM", "HATA");
			}
			
			List<BirBasvuruKimlikTx> txList = (List<BirBasvuruKimlikTx>) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("basvuruNo", oMap.getBigDecimal("BASVURU_NO"))).list();
			if(txList.size() > 0){
				BirBasvuruKimlikTx birBasvuruKimlikTx = txList.get(0);
				adiSoyadi = birBasvuruKimlikTx.getAd();
				if(!StringUtil.isEmpty(birBasvuruKimlikTx.getIkinciAd())){
					adiSoyadi = adiSoyadi.concat(" ").concat(birBasvuruKimlikTx.getIkinciAd());
				}
				adiSoyadi = adiSoyadi.concat(" ").concat(birBasvuruKimlikTx.getSoyad());
				oMap.put("ADI_SOYADI", adiSoyadi);
				oMap.put("SOYADI", birBasvuruKimlikTx.getSoyad());
			}
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_CL_PTT_SMS_VALIDATION")
	public static GMMap pttSmsValidation(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap kpsMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_rc8000.ptt_sms_validation(?, ?, ?)}");
			int pc = 1;
			stmt.setString(pc++, iMap.getString("TC_KIMLIK_NO"));
			stmt.registerOutParameter(pc++, Types.FLOAT);
			stmt.registerOutParameter(pc++, Types.VARCHAR);

			stmt.execute();

			iMap.put("HATA_NO", stmt.getBigDecimal(2));

			if (iMap.get("HATA_NO") == null) {
				/** Kps Kontrolleri **/
				kpsMap.put("TCKNO", iMap.getString("TC_KIMLIK_NO"));
				kpsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", kpsMap));
				//kpsMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", kpsMap));
				
				if (kpsMap.getString("TCKNO_OUT") != null) {
					if ("5".equals(kpsMap.getString("DURUMU"))) {
						iMap.put("HATA_NO", "2087");
						iMap.put("HATA", "Kapali KPS Kaydi");
					}
					if (kpsMap.getString("OLUM_TARIHI") != null) {
						iMap.put("HATA_NO", "918");
						iMap.put("HATA", "Musteri Vefat Etmistir");
					}
					else {
						iMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
						iMap.put("DOGUM_TARIHI", kpsMap.getDate("DOGUM_TARIHI"));
						try {
							GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
							
							Calendar dogumTar = GregorianCalendar.getInstance();
							dogumTar.setTime(iMap.getDate("DOGUM_TARIHI"));

							Calendar yilOncesi = new GregorianCalendar();
							yilOncesi.setTime(iMap.getDate("BANKA_TARIHI"));
							if ("1".equals(kpsMap.getString("CINSIYET_KOD"))){
								yilOncesi.add(GregorianCalendar.YEAR, -25);
							}else{
								yilOncesi.add(GregorianCalendar.YEAR, -35);
							}
							Calendar yilSonrasi = new GregorianCalendar();
							yilSonrasi.setTime(iMap.getDate("BANKA_TARIHI"));
							yilSonrasi.add(GregorianCalendar.YEAR, -80);
							if (dogumTar.after(yilOncesi) || dogumTar.before(yilSonrasi)) {
								iMap.put("HATA_NO", "918");
								iMap.put("HATA", "Dogum tarihi uygun degil");
							}
						}
						catch (Exception e) {
							iMap.put("HATA_NO", "918");
							iMap.put("HATA", "Dogum tarihi uygun degil");
						}
					}
				}
				else {
					iMap.put("HATA_NO", "99");
					iMap.put("HATA", "KPS sorgusu basarisiz");
				}
			}else{
				iMap.put("HATA", stmt.getString(3));
			}
			
			if (iMap.get("HATA_NO") != null) {
				oMap.put("RESPONSE_CODE", iMap.get("HATA_NO"));
				oMap.put("RESPONSE_MESSAGE", iMap.get("HATA"));
			}else{
				oMap.put("RESPONSE_CODE", "00");
				oMap.put("RESPONSE_MESSAGE", "");
			}
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_PTT_SMS_YARIM_BASVURU_JOB")
	public static GMMap yarimBasvuruJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		GMMap odrMap = new GMMap();
		GMMap odMap = new GMMap();
		GMMap odgMap = new GMMap();
		GMMap dataMap = new GMMap();
		BigDecimal eventTypeNo = BigDecimal.valueOf(89);
		BigDecimal basvuruNo = null;
		
		try{
            conn = DALUtil.getGMConnection();            
            stmt = conn.prepareCall("{ call pkg_rc8000.ptt_sms_yarim_basvuru_data(?) }");
            stmt.registerOutParameter(1, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);

            while (rSet.next()) {
            	try{
	            	basvuruNo = rSet.getBigDecimal(1);
	            	
	            	query = "{? = call pkg_webkredi.Get_Evam_Info_Yarim_Basvuru(?)}";
					stmt = conn.prepareCall(query);
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, basvuruNo);
					stmt.execute();

					rSet2 = (ResultSet) stmt.getObject(1);
					dataMap.putAll(DALUtil.rSetMap(rSet2));
	            	
					/** On onay durum guncelle **/
					if(!"BASVURU".equals(dataMap.getString("DURUM_KODU"))){
						GMServiceExecuter.call("BNSPR_TRN3198_SAVE", new GMMap()
						.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"))
						.put("BASVURU_NO", basvuruNo)
						.put("ESKI_DURUM_KODU", dataMap.getString("DURUM_KODU"))
						.put("YENI_DURUM_KODU", "KANALIADE") 
						.put("GEREKCE", 9)
						.put("ACIKLAMA", iMap.getString("ACIKLAMA", "PTT SMS Yar�m Ba�vuru Nedeniyle")));
					}
					
	            	/** Evam event **/
					odgMap.put("KAMP_URUN_ADI", dataMap.get("KAMP_KOD"));
					odgMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", odgMap));
					for (int index = 0; index < odgMap.getSize("ODEME_TIP_TABLE"); index++) {
						if ("7".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
							odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_VADE"));
						}
						else if ("8".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
							odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
						}
						odMap.put("ODEME_TIP_KOD", odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
					}

					odMap.put("KREDI_TUTARI", dataMap.getBigDecimal("TUTAR"));
					odMap.put("TUTAR", dataMap.getBigDecimal("TUTAR"));
					odMap.put("KAMPANYA_KODU", dataMap.get("KAMP_KOD"));
					odMap.put("KAMP_URUN_ADI", dataMap.get("KAMP_KOD"));
					odMap.put("KREDI_VADE", dataMap.getBigDecimal("VADE"));
					odMap.put("VADE", dataMap.getBigDecimal("VADE"));
					odMap.put("KREDI_TURU", "1");
					odMap.put("DOVIZ_KOD", "TRY");
					odMap.put("KANAL_KOD", "7");
					odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
					if (odMap.getInt("VADE") > 2) {
						dataMap.put("TAKSIT_TUTAR", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 2, "OP_TAKSIT_TUTAR"));
					}
					else {
						dataMap.put("TAKSIT_TUTAR", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 1, "OP_TAKSIT_TUTAR"));
					}
					dataMap.put("FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
					
					GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", new GMMap().put("SCENARIO_KEY",
							dataMap.getString("SCENARIO_KEY")).put("EVENT_TYPE_NO", eventTypeNo).put("EVENT_REF_NO",
							basvuruNo).put("INTEGRATION_TYPE", "S").put("DATA_MAP",
							dataMap));
            	}
				catch(Exception e){
					if(!"".equals(basvuruNo)){
						logger.error(basvuruNo + " no lu basvuruda hata alindi!");
					}
					e.printStackTrace();
				}
            }
			return oMap;
	    } catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    } finally {
	        GMServerDatasource.close(rSet);
	        GMServerDatasource.close(stmt);
	        GMServerDatasource.close(conn);
	        GMServerDatasource.close(rSet2);
	    }
	}
	
	@GraymoundService("BNSPR_CL_ONONAY_KONSOLIDASYON_KAYIT")
	public static GMMap ononayKonsolidasyonKayit(GMMap iMap) {
		try {
			
			DALUtil.callOracleProcedure("{call pkg_rc8000.ononay_konsolidasyon_kayit(?, ?)}", new Object[]{
				BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, iMap.getString("TC_KIMLIK_NO")
			}, new Object[]{});
			
			return new GMMap();
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
