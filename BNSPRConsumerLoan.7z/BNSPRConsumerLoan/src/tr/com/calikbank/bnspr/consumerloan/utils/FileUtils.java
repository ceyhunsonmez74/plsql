package tr.com.calikbank.bnspr.consumerloan.utils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class FileUtils {
	private static final int BUFFER_SIZE = 2048;

	public static void unzip(String zipFilePath, String destDir) throws IOException {
		ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath));
        ZipEntry entry = zipIn.getNextEntry();

        while (entry != null) {
            String path = destDir + File.separator + entry.getName();
            if (!entry.isDirectory()) {
                extractFile(zipIn, path);
            } else {
                File dir = new File(path);
                dir.mkdir();
            }
            zipIn.closeEntry();
            entry = zipIn.getNextEntry();
        }
        zipIn.close();
    }
	
	private static void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
        BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(filePath));
        byte[] bytesIn = new byte[BUFFER_SIZE];
        int read = 0;
        
        while ((read = zipIn.read(bytesIn)) != -1) {
            outputStream.write(bytesIn, 0, read);
        }
        
        outputStream.close();
    }
}
