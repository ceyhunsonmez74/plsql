package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrediTaksit;
import tr.com.aktifbank.bnspr.dao.GnlEkranAlanRolTanim;
import tr.com.aktifbank.bnspr.dao.MuhHesapKredi;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.consumerloan.utils.CreditTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirGeriOdemeTx;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.TemTeminatDetail;
import tr.com.calikbank.bnspr.dao.TemTeminatMain;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3133Services {
	@GraymoundService("BNSPR_GET_KKDF_KUR")
	public static GMMap getKKDFKur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_bireysel2.EnYuksekOdemeKur(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			GMMap oMap = new GMMap();

			oMap.put("KKDF_KUR", stmt.getBigDecimal(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3133_SCRIPT_OLUSTUR")
	public static GMMap scriptOlustur(GMMap iMap) {

		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		GMMap oMap = GMServiceExecuter.call("BNSPR_CL_GET_ON_ONAY_BILGI", iMap);

		if (oMap.get("KREDI_TURU") != null) {
			iMap.put("KANAL_KODU", 8);
			BigDecimal konTutar = GMServiceExecuter.call("BNSPR_CL_KONSOLIDASYON_TUTAR", iMap).getBigDecimal("TUTAR");

			BigDecimal musKalacakTutar = oMap.getBigDecimal("HESABA_YATACAK_TUTAR").subtract(konTutar);
			oMap.put("MUS_KALACAK_TUTAR", musKalacakTutar);

			BirBasvuru basvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			
			String mesajNo = "5907";

			if (musKalacakTutar.signum() > 0) {
				if (oMap.getBigDecimal("FAIZ_ORANI").compareTo(basvuru.getFaizOrani()) > 0) {
				mesajNo = "5915";
				} else {
					mesajNo = "5907";
				}
			} else if (musKalacakTutar.signum() == 0) {
				if (oMap.getBigDecimal("FAIZ_ORANI").compareTo(basvuru.getFaizOrani()) > 0) {
					mesajNo = "5952";
					} else {
						mesajNo = "5951";
					}
			}
			
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE_NO", "5978");
			
			messageMap.put("P1", konTutar);
			String kapamaText = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE");
			
			messageMap = new GMMap();
			messageMap.put("MESSAGE_NO", mesajNo);
			
			messageMap.put("P1", oMap.getBigDecimal("TUTAR"));
			messageMap.put("P2", oMap.getBigDecimal("FAIZ_ORANI"));
			messageMap.put("P3", musKalacakTutar);
			messageMap.put("P4", oMap.getBigDecimal("AYLIK_TAKSIT"));

			oMap.put("SCRIPT", kapamaText + " " + (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE"));
		}
		else {
			throw new GMRuntimeException(0, "M��teriye uygun kredi teklifi bulunamad�.");
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3133_ERKEN_KAPAMA_TAKIP_KONTROL")
	public static GMMap erkenKapamaTakipKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3133.get_takip_durum(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("TAKIP_MI", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_TAKSIT_BILGILER")
	public static GMMap getTaksitBilgiler(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call 	PKG_BIREYSEL2.ILKACIKTAKSIT(?,null,?,?,?,?,?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));

			stmt.registerOutParameter(2, Types.NUMERIC);
			stmt.registerOutParameter(3, Types.DATE);
			stmt.registerOutParameter(4, Types.NUMERIC);
			stmt.registerOutParameter(5, Types.NUMERIC);
			stmt.registerOutParameter(6, Types.NUMERIC);
			stmt.registerOutParameter(7, Types.NUMERIC);
			stmt.registerOutParameter(8, Types.NUMERIC);
			stmt.registerOutParameter(9, Types.NUMERIC);
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.execute();

			oMap.put("TAKSIT_NO", stmt.getBigDecimal(2));
			oMap.put("TAKSIT_VADE", stmt.getDate(3));
			oMap.put("TAKSIT_TUTAR", stmt.getBigDecimal(4));
			oMap.put("TAKSIT_ANAPARA", stmt.getBigDecimal(5));
			oMap.put("TAKSIT_FAIZ", stmt.getBigDecimal(6));
			oMap.put("TAKSIT_KKDF", stmt.getBigDecimal(7));
			oMap.put("TAKSIT_BSMV", stmt.getBigDecimal(8));
			oMap.put("TAKSIT_GECIKME", stmt.getBigDecimal(9));
			oMap.put("KISMI_ODEME_EH", stmt.getString(10));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_MUSTERI_IHTARNAME_MASRAF")
	public static GMMap ihtarnameMasrafBakiye(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_QRY8033.ihtarname_masraf_bakiye(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, musteriNo);
			stmt.execute();
			BigDecimal masrafBakiye = stmt.getBigDecimal(1);
			if (masrafBakiye != null && masrafBakiye.compareTo(BigDecimal.ZERO) > 0) {
				GMMap messageMap = new GMMap();
				messageMap.put("MESSAGE_NO", "5020");
				messageMap.put("P1", masrafBakiye);
				oMap.put("IHTAR_MASRAF", "1");
				oMap.put("IHTAR_MASRAF_MESAJ", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE"));
			}
			else {
				oMap.put("IHTAR_MASRAF", "0");
				oMap.put("IHTAR_MASRAF_MESAJ", StringUtils.EMPTY);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_GERI_ODEME_TAKSIT_TAHSILAT")
	public static GMMap getGeriOdemeTaksitTahsilat(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_bireysel2.GeriOdemeTaksitTahsilat(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			if (iMap.getBigDecimal("REZERVASYON_KURU").compareTo(new BigDecimal(0)) != 0)
				stmt.setBigDecimal(2, iMap.getBigDecimal("REZERVASYON_KURU"));
			else
				stmt.setBigDecimal(2, null);
			stmt.setBigDecimal(3, iMap.getBigDecimal("TAKSIT_NO"));

			int i = 3;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.execute();

			GMMap oMap = new GMMap();

			i = 3;
			oMap.put("TAKSIT_NO", stmt.getBigDecimal(i++));
			oMap.put("TAKSIT_TUTARI", stmt.getBigDecimal(i++));
			oMap.put("ANAPARA", stmt.getBigDecimal(i++));
			oMap.put("FAIZ", stmt.getBigDecimal(i++));
			oMap.put("FAIZ_KKDF", stmt.getBigDecimal(i++));
			oMap.put("FAIZ_BSMV", stmt.getBigDecimal(i++));
			oMap.put("GECIKME_FAIZ", stmt.getBigDecimal(i++));
			oMap.put("GECIKME_FAIZ_KKDF", stmt.getBigDecimal(i++));
			oMap.put("GECIKME_FAIZ_BSMV", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI_KKDF", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI_BSMV", stmt.getBigDecimal(i++));
			oMap.put("ERKEN_ODEME_FAIZ_INDIRIM", stmt.getBigDecimal(i++));
			oMap.put("TAHSILAT_TUTARI", stmt.getBigDecimal(i++));
			i++;
			oMap.put("TAKSIT_VADE", stmt.getDate(i++));
			oMap.put("TAKSIT_DURUM", stmt.getString(i++));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_GERI_ODEME_TAKSIT_TAHSILAT_KISMI")
	public static GMMap getGeriOdemeTaksitTahsilatKismi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_bireysel2.GeriOdemeKismiTahsilat(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("TAHSILAT_TUTARI"));
			stmt.setString(3, iMap.getString("KREDI_DOVIZ_KODU"));

			if (iMap.getBigDecimal("REZERVASYON_KURU").compareTo(new BigDecimal(0)) != 0)
				stmt.setBigDecimal(4, iMap.getBigDecimal("REZERVASYON_KURU"));
			else
				stmt.setBigDecimal(4, null);

			stmt.setBigDecimal(5, iMap.getBigDecimal("TAKSIT_NO"));
			stmt.setBigDecimal(16, iMap.getBigDecimal("ALINACAK_GECIKME_FAIZI"));

			stmt.registerOutParameter(5, Types.NUMERIC);
			int i = 6;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);

			stmt.execute();

			GMMap oMap = new GMMap();

			i = 5;

			oMap.put("TAKSIT_NO", stmt.getBigDecimal(i++));

			oMap.put("ANAPARA", stmt.getBigDecimal(i++) == null ? "0" : stmt.getBigDecimal(i - 1)); // stmt.getBigDecimal(i++)==
																									// null?"0":stmt.getBigDecimal(i)
			oMap.put("FAIZ", stmt.getBigDecimal(i++));
			oMap.put("FAIZ_KKDF", stmt.getBigDecimal(i++));
			oMap.put("FAIZ_BSMV", stmt.getBigDecimal(i++));
			oMap.put("KAP_GEC_ARA_FAIZI", stmt.getBigDecimal(i++));// KAP_GEC_ARA_FAIZI //GECIKME_FAIZ
			oMap.put("GECIKME_FAIZ_KKDF", stmt.getBigDecimal(i++));
			oMap.put("GECIKME_FAIZ_BSMV", stmt.getBigDecimal(i++)); //
			oMap.put("KUR_FARKI_KKDF", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI_BSMV", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI", stmt.getBigDecimal(i++));

			oMap.put("ERKEN_ODEME_FAIZ_INDIRIM", "0");

			oMap.put("TAKSIT_TUTARI_TAM", iMap.getBigDecimal("TAHSILAT_TUTARI"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_GERI_ODEME_ERKEN_KAPAMA")
	public static GMMap getGeriOdemeErkenKapama(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_bireysel2.GeriOdemeErkenKapama(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("REZERVASYON_KURU").compareTo(new BigDecimal(0)) == 0 ? null : iMap.getBigDecimal("REZERVASYON_KURU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_NO"));

			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);

			stmt.setString(i++, iMap.getString("ERKEN_KAPAMA_GEC_KISMI_DAHIL"));
			stmt.setDate(i++, iMap.getDate("KAPAMA_YAPILMASI_ISTENEN_TARIH") == null ? null : new java.sql.Date(iMap.getDate("KAPAMA_YAPILMASI_ISTENEN_TARIH").getTime()));
			stmt.setBigDecimal(i++, iMap.getString("EKRAN_NO") != null ? iMap.getBigDecimal("EKRAN_NO") : null);

			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.execute();

			i = 4;
			oMap.put("ANAPARA", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI_KKDF", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI_BSMV", stmt.getBigDecimal(i++));
			oMap.put("ERKEN_KAPAMA_FAIZ", stmt.getBigDecimal(i++));
			oMap.put("ERKEN_KAPAMA_FAIZ_KKDF", stmt.getBigDecimal(i++));
			oMap.put("ERKEN_KAPAMA_FAIZ_BSMV", stmt.getBigDecimal(i++));
			oMap.put("ERKEN_ODEME_KOMISYONU", stmt.getBigDecimal(i++));
			oMap.put("ERKEN_ODEME_KOMISYONU_BSMV", stmt.getBigDecimal(i++));
			oMap.put("TAHSILAT_TUTARI", stmt.getBigDecimal(i++));
			oMap.put("GECIKME_FAIZ", stmt.getBigDecimal(i++));
			oMap.put("FARK_FAIZI_HAKEDILEN", stmt.getBigDecimal(i + 3));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_GERI_ODEME_ARA_ODEME")
	public static GMMap getGeriOdemeAraOdeme(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_bireysel2.GeriOdemeAraOdeme(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			if (iMap.getBigDecimal("REZERVASYON_KURU").compareTo(new BigDecimal(0)) != 0)
				stmt.setBigDecimal(2, iMap.getBigDecimal("REZERVASYON_KURU"));
			else
				stmt.setBigDecimal(2, null);
			stmt.setBigDecimal(3, iMap.getBigDecimal("TAKSIT_NO"));

			int i = 4;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);

			stmt.execute();

			GMMap oMap = new GMMap();

			i = 4;
			oMap.put("ARA_ODEME_ANAPARA", stmt.getBigDecimal(i++));
			oMap.put("ARA_ODEME_FAIZ", stmt.getBigDecimal(i++));
			oMap.put("ARA_ODEME_FAIZ_KKDF", stmt.getBigDecimal(i++));
			oMap.put("ARA_ODEME_FAIZ_BSMV", stmt.getBigDecimal(i++));
			oMap.put("ERKEN_ODEME_KOMISYONU", stmt.getBigDecimal(i++));
			oMap.put("ERKEN_ODEME_KOMISYONU_BSMV", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI_KKDF", stmt.getBigDecimal(i++));
			oMap.put("KUR_FARKI_BSMV", stmt.getBigDecimal(i++));
			oMap.put("MIN_TAHSILAT_TUTARI", stmt.getBigDecimal(i++));
			oMap.put("MAX_TAHSILAT_TUTARI", stmt.getBigDecimal(i++));
			oMap.put("FARK_FAIZI_HAKEDILEN", stmt.getBigDecimal(i++));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3133_SAVE")
	public static GMMap saveTRN3133(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String islemTuru = iMap.getString("ISLEM_TURU");

			BirGeriOdemeTx birGeriOdemeTx = (BirGeriOdemeTx) session.get(BirGeriOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birGeriOdemeTx == null)
				birGeriOdemeTx = new BirGeriOdemeTx();

			birGeriOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birGeriOdemeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birGeriOdemeTx.setBirGeriOdmTip(iMap.getString("ISLEM_TURU"));
			// birGeriOdemeTx.set(iMap.getBigDecimal("MUSTERI_NO"));
			// birGeriOdemeTx.set(iMap.getBigDecimal("FAIZ_ORANI"));
			// birGeriOdemeTx.set(iMap.getBigDecimal("SOZLESME_ORANI"));
			// birGeriOdemeTx.set(iMap.getBigDecimal("KKDF_ORANI"));
			// birGeriOdemeTx.set(iMap.getBigDecimal("BSMV_ORANI"));
			birGeriOdemeTx.setBakiye(iMap.getBigDecimal("BAKIYE"));
			birGeriOdemeTx.setDovEndBakiye(iMap.getBigDecimal("DOVIZ_BAKIYE"));
			// birGeriOdemeTx.set(iMap.getBigDecimal("ACILIS_KURU"));
			birGeriOdemeTx.setDovEndKod(iMap.getString("DOVIZ_KODU"));
			birGeriOdemeTx.setDrm("G");
			birGeriOdemeTx.setKrdHesapNo(iMap.getBigDecimal("KREDI_HESAP_NO"));
			birGeriOdemeTx.setTahsilatDov(iMap.getString("TAHSILAT_DOVIZ_KODU"));
			birGeriOdemeTx.setTahsilHesapNo(iMap.getBigDecimal("TAHSILAT_HESAP_NO"));
			birGeriOdemeTx.setTaksitNo(iMap.getBigDecimal("ODENECEK_TAKSIT_NO"));
			birGeriOdemeTx.setTaksitVade(iMap.getDate("ODENECEK_TAKSIT_VADE"));
			birGeriOdemeTx.setTaksitTutar(iMap.getBigDecimal("ODENECEK_TAKSIT_TUTARI"));

			if ("E".equals(iMap.getString("ERKEN_OR_GECIKME")))
				birGeriOdemeTx.setErkenOdeFaizIndirimi(iMap.getBigDecimal("ERK_TAH_FAIZ_IND_GEC_FAIZI"));
			else if ("G".equals(iMap.getString("ERKEN_OR_GECIKME")))
				birGeriOdemeTx.setGecikmeFaizi(iMap.getBigDecimal("ERK_TAH_FAIZ_IND_GEC_FAIZI"));

			// birGeriOdemeTx.set(iMap.getBigDecimal("ODEME_PLAN_REZERVASYON"));
			birGeriOdemeTx.setTaksitFaizi(iMap.getBigDecimal("TAKSIT_FAIZI"));
			birGeriOdemeTx.setTaksitFaiziTl(iMap.getBigDecimal("TAKSIT_FAIZI_TL"));
			birGeriOdemeTx.setTaksitFaiziKkdf(iMap.getBigDecimal("TAKSIT_FAIZI_KKDF"));
			birGeriOdemeTx.setTaksitFaiziKkdfTl(iMap.getBigDecimal("TAKSIT_FAIZI_KKDF_TL"));
			birGeriOdemeTx.setTaksitFaiziBsmv(iMap.getBigDecimal("TAKSIT_FAIZI_BSMV"));
			birGeriOdemeTx.setTaksitFaiziBsmvTl(iMap.getBigDecimal("TAKSIT_FAIZI_BSMV_TL"));

			if (islemTuru.equals("1")) {

				birGeriOdemeTx.setTaksitAnapara(iMap.getBigDecimal("TAKSIT_ANAPARA"));
				birGeriOdemeTx.setTaksitAnaparaTl(iMap.getBigDecimal("TAKSIT_ANAPARA_TL"));

				birGeriOdemeTx.setGecikmeFaiziAlinan(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI"));
				birGeriOdemeTx.setGecikmeFaiziAlinanTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_TL"));
				birGeriOdemeTx.setGecikmeFaiziKkdf(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_KKDF"));
				birGeriOdemeTx.setGecikmeFaiziKkdfTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_KKDF_TL"));
				birGeriOdemeTx.setGecikmeFaiziBsmv(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_BSMV"));
				birGeriOdemeTx.setGecikmeFaiziBsmvTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_BSMV_TL"));

				iMap.getBigDecimal("TAHSILAT_TUTARI_TAM");
				iMap.getBigDecimal("TAHSILAT_TUTARI");

				if (iMap.getBigDecimal("TAHSILAT_TUTARI").compareTo(iMap.getBigDecimal("TAHSILAT_TUTARI_TAM")) == 0) {
					birGeriOdemeTx.setKismiOdemeEh("H");
				}
				else {
					birGeriOdemeTx.setKismiOdemeEh("E");
				}

				// birGeriOdemeTx.setKismiOdemeEh()

			}
			else if (islemTuru.equals("3")) {

				birGeriOdemeTx.setKapamaAnapara(iMap.getBigDecimal("TAKSIT_ANAPARA"));
				birGeriOdemeTx.setKapamaAnaparaTl(iMap.getBigDecimal("TAKSIT_ANAPARA_TL"));

				birGeriOdemeTx.setKapamaFaizi(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI"));
				birGeriOdemeTx.setKapamaFaiziTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_TL"));
				birGeriOdemeTx.setKapamaFaiziKkdf(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_KKDF"));
				birGeriOdemeTx.setKapamaFaiziKkdfTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_KKDF_TL"));
				birGeriOdemeTx.setKapamaFaiziBsmv(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_BSMV"));
				birGeriOdemeTx.setKapamaFaiziBsmvTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_BSMV_TL"));
				birGeriOdemeTx.setIptaldenKapamaEh(iMap.getBoolean("IPTALDEN_KAPAMA") == true ? "E" : "H");
				birGeriOdemeTx.setAnaparaFeragatTutar(iMap.getBigDecimal("ANAPARA_FERAGAT_TUTAR"));
				birGeriOdemeTx.setBayiUrunIadeTutar(iMap.getBigDecimal("BAYI_URUN_IADE_TUTAR"));

			}
			else if (islemTuru.equals("2")) {

				birGeriOdemeTx.setAraOdemeAnapara(iMap.getBigDecimal("TAKSIT_ANAPARA"));
				birGeriOdemeTx.setAraOdemeAnaparaTl(iMap.getBigDecimal("TAKSIT_ANAPARA_TL"));

				birGeriOdemeTx.setAraOdemeFaizi(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI"));
				birGeriOdemeTx.setAraOdemeFaiziTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_TL"));
				birGeriOdemeTx.setAraOdemeFaiziKkdf(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_KKDF"));
				birGeriOdemeTx.setAraOdemeFaiziKkdfTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_KKDF_TL"));
				birGeriOdemeTx.setAraOdemeFaiziBsmv(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_BSMV"));
				birGeriOdemeTx.setAraOdemeFaiziBsmvTl(iMap.getBigDecimal("KAP_GEC_ARA_FAIZI_BSMV_TL"));

			}

			birGeriOdemeTx.setErkenOdemeKom(iMap.getBigDecimal("ERKEN_ODEME_KOM"));
			birGeriOdemeTx.setErkenOdemeKomTl(iMap.getBigDecimal("ERKEN_ODEME_KOM_TL"));
			birGeriOdemeTx.setErkenOdemeKomBsmv(iMap.getBigDecimal("ERKEN_ODEME_KOM_BSMV"));
			birGeriOdemeTx.setErkenOdemeKomBsmvTl(iMap.getBigDecimal("ERKEN_ODEME_KOM_BSMV_TL"));
			birGeriOdemeTx.setKkdfKur(iMap.getBigDecimal("KKDF_KURU"));
			birGeriOdemeTx.setKurfarkiKkdf(iMap.getBigDecimal("KUR_FARKI_KKDF"));
			birGeriOdemeTx.setKurfarkiKkdfYp(iMap.getBigDecimal("KUR_FARKI_KKDF_YP"));
			birGeriOdemeTx.setKkdfMatrah(iMap.getBigDecimal("KKDF_MATRAHI"));
			birGeriOdemeTx.setKurfarkiBsmv(iMap.getBigDecimal("KUR_FARKI_BSMV"));
			birGeriOdemeTx.setKurfarkiBsmvYp(iMap.getBigDecimal("KUR_FARKI_BSMV_YP"));
			// birGeriOdemeTx.setKurfarki(iMap.getBigDecimal("BSMV_MATRAHI"));
			birGeriOdemeTx.setKurfarki(iMap.getBigDecimal("KUR_FARKI"));
			birGeriOdemeTx.setRezervasyonNo(iMap.getBigDecimal("REZERVASYON_NO"));
			birGeriOdemeTx.setRezervasyonKur(iMap.getBigDecimal("REZERVASYON_KURU"));
			// birGeriOdemeTx.set(iMap.getBigDecimal("ALINACAK_GECIKME_FAIZI"));
			birGeriOdemeTx.setTahsilatTutar(iMap.getBigDecimal("TAHSILAT_TUTARI"));
			birGeriOdemeTx.setTaksitKalanBorc(iMap.getBigDecimal("TAKSITTE_KALAN_BORC_YP"));
			birGeriOdemeTx.setTaksitKalanBorcTl(iMap.getBigDecimal("TAKSITTE_KALAN_BORC"));
			birGeriOdemeTx.setKalanGecFaizTahsilEh(iMap.getString("F_KALAN_GEC_FAIZI_SONRA"));
			birGeriOdemeTx.setAciklama(iMap.getString("ACIKLAMA"));

			birGeriOdemeTx.setTahsilatTutarTl(iMap.getBigDecimal("TAHSILAT_TUTARI_TL"));
			birGeriOdemeTx.setYeniTaksitTarihi(iMap.getDate("YENI_TAKSIT_TARIHI"));
			birGeriOdemeTx.setFaizFeragatTutar(iMap.getBigDecimal("FAIZ_FERAGAT_TUTAR", BigDecimal.ZERO));
			birGeriOdemeTx.setFaizFeragatNeden(iMap.getString("FAIZ_FERAGAT_NEDEN", StringUtils.EMPTY));
			birGeriOdemeTx.setKapamaNeden(iMap.getString("KAPAMA_NEDEN"));
			birGeriOdemeTx.setKulSigKom(iMap.getBigDecimal("KUL_SIG_KOM"));
			birGeriOdemeTx.setKulSigPrim(iMap.getBigDecimal("KUL_SIG_PRIM"));
			birGeriOdemeTx.setKulSigPrimHesapNo(iMap.getBigDecimal("KUL_SIG_PRIM_HESAP"));
			birGeriOdemeTx.setFarkFaizi(iMap.getBigDecimal("FARK_FAIZI"));
			birGeriOdemeTx.setFarkFaiziBsmv(iMap.getBigDecimal("FARK_FAIZI_BSMV"));
			birGeriOdemeTx.setFarkFaiziKkdf(iMap.getBigDecimal("FARK_FAIZI_KKDF"));
			birGeriOdemeTx.setKrediTahsisUcreti(iMap.getBigDecimal("TAHSIS_UCRETI"));
			birGeriOdemeTx.setKrediTahsisUcretiBsmv(iMap.getBigDecimal("TAHSIS_UCRETI_BSMV"));
			birGeriOdemeTx.setPttMasraf(iMap.getBigDecimal("PTT_BASVURU_MASRAF"));
			birGeriOdemeTx.setDigerMasraf(iMap.getBigDecimal("DIGER_MASRAF"));
			birGeriOdemeTx.setIslemTar(iMap.getDate("ISLEM_TAR"));
			birGeriOdemeTx.setMusteridenAlinacakTutar(iMap.getBigDecimal("MUSTERIDEN_ALINACAK_TUTAR"));
			birGeriOdemeTx.setPttHavaleTxno(iMap.getBigDecimal("PTT_HAVALE_TX_NO"));
			birGeriOdemeTx.setFarkFaiziHakedilen(iMap.getBigDecimal("FARK_FAIZI_HAKEDILEN"));
			birGeriOdemeTx.setRetentionRetNedeni(iMap.getString("RETENTION_RET_NEDENI"));

			session.saveOrUpdate(birGeriOdemeTx);
			session.flush();

			iMap.put("TRX_NAME", "3133");
			return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3133_NAKIT_KREDI_KONTROL")
	public static GMMap nakitKrediMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal isCashCredit = BigDecimal.ZERO;
		isCashCredit = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_basvuru.isCashCredit(?)}", Types.NUMERIC, iMap.getBigDecimal("BASVURU_NO"));

		oMap.put("NAKIT_KREDI_MI", isCashCredit);

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3133_ISLEM_TAR_KONTROL")
	public static GMMap islemTarKontrol(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
			Date ekranIslemTar = iMap.getDate("EKRAN_ISLEM_TAR");
			Date kulIslemTar = format.parse(iMap.getString("KUL_ISLEM_TAR"));

			if (ekranIslemTar != null && kulIslemTar != null && DateUtils.isSameDay(ekranIslemTar, kulIslemTar)) {
				oMap.put("HATA_NO", 5436);
			}
		}
		catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3133_GET")
	public static GMMap getTRN3133(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirGeriOdemeTx birGeriOdemeTx = (BirGeriOdemeTx) session.get(BirGeriOdemeTx.class, iMap.getBigDecimal("TRX_NO"));

			GMMap oMap = new GMMap();

			String islemTuru = birGeriOdemeTx.getBirGeriOdmTip();

			oMap.put("BASVURU_NO", birGeriOdemeTx.getBasvuruNo());
			oMap.put("ISLEM_TURU", birGeriOdemeTx.getBirGeriOdmTip());
			HashMap<?, ?> lovMap = LovHelper.diLovAll(birGeriOdemeTx.getBasvuruNo(), "3133/LOV_BASVURU_IZLEME");
			oMap.put("MUSTERI_NO", lovMap.get("MUSTERI_NO"));
			oMap.put("UNVAN", lovMap.get("UNVAN"));
			oMap.put("FAIZ_ORANI", lovMap.get("FAIZ_ORANI"));
			oMap.put("SOZLESME_ORANI", lovMap.get("SOZLESME_ORANI"));
			oMap.put("KKDF_ORANI", lovMap.get("KKDF_ORAN"));
			oMap.put("BSMV_ORANI", lovMap.get("BSMV_ORAN"));
			oMap.put("BAKIYE", birGeriOdemeTx.getBakiye());
			oMap.put("DOVIZ_BAKIYE", birGeriOdemeTx.getDovEndBakiye());
			oMap.put("ACILIS_KURU", lovMap.get("ACILIS_KUR"));

			oMap.put("KRD_SUBE", lovMap.get("KRD_SUBE"));
			oMap.put("TAH_SUBE", lovMap.get("TAH_SUBE"));

			oMap.put("DOVIZ_KODU", birGeriOdemeTx.getDovEndKod());
			oMap.put("KREDI_HESAP_NO", birGeriOdemeTx.getKrdHesapNo());
			oMap.put("TAHSILAT_DOVIZ_KODU", birGeriOdemeTx.getTahsilatDov());
			oMap.put("TAHSILAT_HESAP_NO", birGeriOdemeTx.getTahsilHesapNo());
			// BNSPR_TRN1101_GET_ACCOUNT_BALANCE
			if (birGeriOdemeTx != null && birGeriOdemeTx.getTahsilHesapNo() != null) {
				GMMap bakiyeMap = new GMMap();
				bakiyeMap.put("HESAP_NO", birGeriOdemeTx.getTahsilHesapNo());
				oMap.put("TAHSILAT_BAKIYE", GMServiceExecuter.call("BNSPR_TRN1101_GET_ACCOUNT_BALANCE", bakiyeMap).getBigDecimal("BALANCE"));
			}
			oMap.put("TAHSILAT_HESAP_NO", birGeriOdemeTx.getTahsilHesapNo());
			oMap.put("ODENECEK_TAKSIT_NO", birGeriOdemeTx.getTaksitNo());
			oMap.put("ODENECEK_TAKSIT_VADE", birGeriOdemeTx.getTaksitVade());
			oMap.put("ODENECEK_TAKSIT_TUTARI", birGeriOdemeTx.getTaksitTutar());

			if (birGeriOdemeTx.getErkenOdeFaizIndirimi() != null)
				oMap.put("ERK_TAH_FAIZ_IND_GEC_FAIZI", birGeriOdemeTx.getErkenOdeFaizIndirimi());
			else if (birGeriOdemeTx.getGecikmeFaizi() != null)
				oMap.put("ERK_TAH_FAIZ_IND_GEC_FAIZI", birGeriOdemeTx.getGecikmeFaizi());

			oMap.put("ODEME_PLAN_REZERVASYON", lovMap.get("ARA_ODEME_NO"));
			oMap.put("VADE", lovMap.get("VADE"));

			oMap.put("TAKSIT_FAIZI", birGeriOdemeTx.getTaksitFaizi());
			oMap.put("TAKSIT_FAIZI_TL", birGeriOdemeTx.getTaksitFaiziTl());
			oMap.put("TAKSIT_FAIZI_KKDF", birGeriOdemeTx.getTaksitFaiziKkdf());
			oMap.put("TAKSIT_FAIZI_KKDF_TL", birGeriOdemeTx.getTaksitFaiziKkdfTl());
			oMap.put("TAKSIT_FAIZI_BSMV", birGeriOdemeTx.getTaksitFaiziBsmv());
			oMap.put("TAKSIT_FAIZI_BSMV_TL", birGeriOdemeTx.getTaksitFaiziBsmvTl());
			oMap.put("IPTALDEN_KAPAMA", false);

			if (islemTuru.equals("1") || islemTuru.equals("4")) {

				oMap.put("TAKSIT_ANAPARA", birGeriOdemeTx.getTaksitAnapara());
				oMap.put("TAKSIT_ANAPARA_TL", birGeriOdemeTx.getTaksitAnaparaTl());

				oMap.put("KAP_GEC_ARA_FAIZI", birGeriOdemeTx.getGecikmeFaiziAlinan());
				oMap.put("KAP_GEC_ARA_FAIZI_TL", birGeriOdemeTx.getGecikmeFaiziAlinanTl());
				oMap.put("KAP_GEC_ARA_FAIZI_KKDF", birGeriOdemeTx.getGecikmeFaiziKkdf());
				oMap.put("KAP_GEC_ARA_FAIZI_KKDF_TL", birGeriOdemeTx.getGecikmeFaiziKkdfTl());
				oMap.put("KAP_GEC_ARA_FAIZI_BSMV", birGeriOdemeTx.getGecikmeFaiziBsmv());
				oMap.put("KAP_GEC_ARA_FAIZI_BSMV_TL", birGeriOdemeTx.getGecikmeFaiziBsmvTl());

			}
			else if (islemTuru.equals("3")) {

				oMap.put("TAKSIT_ANAPARA", birGeriOdemeTx.getKapamaAnapara());
				oMap.put("TAKSIT_ANAPARA_TL", birGeriOdemeTx.getKapamaAnaparaTl());

				oMap.put("KAP_GEC_ARA_FAIZI", birGeriOdemeTx.getKapamaFaizi());
				oMap.put("KAP_GEC_ARA_FAIZI_TL", birGeriOdemeTx.getKapamaFaiziTl());
				oMap.put("KAP_GEC_ARA_FAIZI_KKDF", birGeriOdemeTx.getKapamaFaiziKkdf());
				oMap.put("KAP_GEC_ARA_FAIZI_KKDF_TL", birGeriOdemeTx.getKapamaFaiziKkdfTl());
				oMap.put("KAP_GEC_ARA_FAIZI_BSMV", birGeriOdemeTx.getKapamaFaiziBsmv());
				oMap.put("KAP_GEC_ARA_FAIZI_BSMV_TL", birGeriOdemeTx.getKapamaFaiziBsmvTl());
				oMap.put("IPTALDEN_KAPAMA", birGeriOdemeTx.getIptaldenKapamaEh() == "E" ? true : false);
				oMap.put("ANAPARA_FERAGAT_TUTAR", birGeriOdemeTx.getAnaparaFeragatTutar());
			}
			else if (islemTuru.equals("2")) {

				oMap.put("TAKSIT_ANAPARA", birGeriOdemeTx.getAraOdemeAnapara());
				oMap.put("TAKSIT_ANAPARA_TL", birGeriOdemeTx.getAraOdemeAnaparaTl());

				oMap.put("KAP_GEC_ARA_FAIZI", birGeriOdemeTx.getAraOdemeFaizi());
				oMap.put("KAP_GEC_ARA_FAIZI_TL", birGeriOdemeTx.getAraOdemeFaiziTl());
				oMap.put("KAP_GEC_ARA_FAIZI_KKDF", birGeriOdemeTx.getAraOdemeFaiziKkdf());
				oMap.put("KAP_GEC_ARA_FAIZI_KKDF_TL", birGeriOdemeTx.getAraOdemeFaiziKkdfTl());
				oMap.put("KAP_GEC_ARA_FAIZI_BSMV", birGeriOdemeTx.getAraOdemeFaiziBsmv());
				oMap.put("KAP_GEC_ARA_FAIZI_BSMV_TL", birGeriOdemeTx.getAraOdemeFaiziBsmvTl());
				oMap.put("YENI_TAKSIT_TARIHI", birGeriOdemeTx.getYeniTaksitTarihi());

			}

			oMap.put("ERKEN_ODEME_KOM", birGeriOdemeTx.getErkenOdemeKom());
			oMap.put("ERKEN_ODEME_KOM_TL", birGeriOdemeTx.getErkenOdemeKomTl());
			oMap.put("ERKEN_ODEME_KOM_BSMV", birGeriOdemeTx.getErkenOdemeKomBsmv());
			oMap.put("ERKEN_ODEME_KOM_BSMV_TL", birGeriOdemeTx.getErkenOdemeKomBsmvTl());
			oMap.put("KKDF_KURU", birGeriOdemeTx.getKkdfKur());
			oMap.put("KUR_FARKI_KKDF", birGeriOdemeTx.getKurfarkiKkdf());
			oMap.put("KUR_FARKI_KKDF_YP", birGeriOdemeTx.getKurfarkiKkdfYp());
			oMap.put("KKDF_MATRAHI", birGeriOdemeTx.getKkdfMatrah());
			oMap.put("KUR_FARKI_BSMV", birGeriOdemeTx.getKurfarkiBsmv());
			oMap.put("KUR_FARKI_BSMV_YP", birGeriOdemeTx.getKurfarkiBsmvYp());
			oMap.put("BSMV_MATRAHI", birGeriOdemeTx.getKurfarki());
			oMap.put("REZERVASYON_NO", birGeriOdemeTx.getRezervasyonNo());
			oMap.put("REZERVASYON_KURU", birGeriOdemeTx.getRezervasyonKur());
			// oMap.put("ALINACAK_GECIKME_FAIZI", birGeriOdemeTx.get());
			oMap.put("TAHSILAT_TUTARI", birGeriOdemeTx.getTahsilatTutar());
			oMap.put("TAKSITTE_KALAN_BORC", birGeriOdemeTx.getTaksitKalanBorcTl());
			oMap.put("TAKSITTE_KALAN_BORC_YP", birGeriOdemeTx.getTaksitKalanBorc());
			oMap.put("F_KALAN_GEC_FAIZI_SONRA", GuimlUtil.convertToCheckBoxSelected(birGeriOdemeTx.getKalanGecFaizTahsilEh()));
			oMap.put("ACIKLAMA", birGeriOdemeTx.getAciklama());
			oMap.put("FAIZ_FERAGAT_TUTAR", birGeriOdemeTx.getFaizFeragatTutar());
			oMap.put("FAIZ_FERAGAT_NEDEN", birGeriOdemeTx.getFaizFeragatNeden());
			oMap.put("KAPAMA_NEDEN", birGeriOdemeTx.getKapamaNeden());
			oMap.put("KUL_SIG_KOM", birGeriOdemeTx.getKulSigKom());
			oMap.put("KUL_SIG_PRIM", birGeriOdemeTx.getKulSigPrim());
			oMap.put("KUL_SIG_PRIM_HESAP", birGeriOdemeTx.getKulSigPrimHesapNo());
			oMap.put("FARK_FAIZI", birGeriOdemeTx.getFarkFaizi());
			oMap.put("FARK_FAIZI_BSMV", birGeriOdemeTx.getFarkFaiziBsmv());
			oMap.put("FARK_FAIZI_KKDF", birGeriOdemeTx.getFarkFaiziKkdf());
			oMap.put("TAHSIS_UCRETI", birGeriOdemeTx.getKrediTahsisUcreti());
			oMap.put("TAHSIS_UCRETI_BSMV", birGeriOdemeTx.getKrediTahsisUcretiBsmv());
			oMap.put("PTT_BASVURU_MASRAF", birGeriOdemeTx.getPttMasraf());
			oMap.put("DIGER_MASRAF", birGeriOdemeTx.getDigerMasraf());

			if (!birGeriOdemeTx.getDovEndKod().equals(birGeriOdemeTx.getTahsilatDov()))
				oMap.put("TAHSILAT_TUTARI_YP", birGeriOdemeTx.getTahsilatTutar().divide(birGeriOdemeTx.getRezervasyonKur(), 5, 4));
			else
				oMap.put("TAHSILAT_TUTARI_YP", new BigDecimal(0));

			oMap.put("ILK_TAKSIT_ODENDIMI", (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3133.ilk_taksit_odendimi(?)}", Types.VARCHAR, birGeriOdemeTx.getBasvuruNo()));
			oMap.put("MUSTERIDEN_ALINACAK_TUTAR", birGeriOdemeTx.getMusteridenAlinacakTutar());
			oMap.put("FARK_FAIZI_HAKEDILEN", birGeriOdemeTx.getFarkFaiziHakedilen());
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_GET_ANAPARA_KUR_FARKI")
	public static GMMap getAnaParaKurFarki(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call 	Pkg_trn3133.AnaparaKurFarki(?,?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("KALAN"));
			stmt.setString(2, iMap.getString("TAHSILAT_DOVIZ_KOD"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TAHSILAT_KUR"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("ACILIS_KUR"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("BSMV_ORAN"));

			stmt.registerOutParameter(6, Types.NUMERIC);
			stmt.registerOutParameter(7, Types.NUMERIC);
			stmt.registerOutParameter(8, Types.NUMERIC);

			stmt.execute();

			oMap.put("ANAPARA", stmt.getBigDecimal(6));
			oMap.put("KF_BSMV", stmt.getBigDecimal(7));
			oMap.put("KUR_FARK", stmt.getBigDecimal(8));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3133_ARA_ODEME_TAKSIT_GUNU_DISI_KONTROL")
	public static GMMap araOdemeTaksitGunuDisiKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call Pkg_trn3133.ara_odeme_taksit_gunu_disi(?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setDate(2, new java.sql.Date(iMap.getDate("ODENECEK_TAKSIT_VADE").getTime()));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("DEGER", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3133_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap emailMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3133.taksittahsilatsms(?,?,?,?)}");
			int pc = 1;
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter(pc++, Types.DECIMAL);
			stmt.registerOutParameter(pc++, Types.VARCHAR);
			stmt.registerOutParameter(pc++, Types.VARCHAR);

			stmt.execute();
			String mesaj = stmt.getString(--pc);
			String cepTel = stmt.getString(--pc);
			if (mesaj != null) {
				GMMap iMap1 = new GMMap();
				iMap1.put("CONTENT", mesaj);
				iMap1.put("MSISDN", cepTel);
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS_ASYNC", iMap1).get("RESULT");
			}

			/** Ara odeme mail gonderimi **/
			Session session = DAOSession.getSession("BNSPRDal");
			BirGeriOdemeTx birGeriOdemeTx = (BirGeriOdemeTx) session.get(BirGeriOdemeTx.class, iMap.getBigDecimal("ISLEM_NO"));
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", birGeriOdemeTx.getBasvuruNo())).uniqueResult();
			
			if ("2".equals(birGeriOdemeTx.getBirGeriOdmTip())) {
				stmt = conn.prepareCall("{? = call Pkg_musteri.email_kisisel(?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, birBasvuru.getMusteriNo());
				stmt.execute();

				emailMap.put("EMAIL_ADDRESS", stmt.getString(1));

				if (!"".equals(emailMap.getString("EMAIL_ADDRESS"))) {
					List<String> emailList = new ArrayList<String>();
					emailList.add(emailMap.getString("EMAIL_ADDRESS"));

					emailMap.put("FROM", "aktifbank@aktifbank.com.tr");
					emailMap.put("RECIPIENTS_TO", emailList);
					emailMap.put("SUBJECT", "Kredinizin S�zle�me Formu ve �deme Plan�");

					String adSoyad = StringUtils.EMPTY;
					BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, birGeriOdemeTx.getBasvuruNo());
					if (birBasvuruKimlik != null) {
						if (StringUtils.isNotEmpty(birBasvuruKimlik.getIkinciAd())) {
							adSoyad = birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getIkinciAd() + " " + birBasvuruKimlik.getSoyad();
						}
						else {
							adSoyad = birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getSoyad();
						}
					}
					// mail body
					GMMap inputMap = new GMMap();
					inputMap.put("FOLDER_NAME", "bayiPortal");
					inputMap.put("TEMPLATE_NAME", "ara_odeme_sozlesme");
					inputMap.put("ENCODING", "ISO-8859-9");

					HashMap<String, Object> inputs = new HashMap<String, Object>();
					inputs.put("AD_SOYAD", adSoyad);
					inputs.put("BASVURU_NO", birGeriOdemeTx.getBasvuruNo());

					inputMap.put("INPUTS", inputs);
					emailMap.put("MESSAGE_BODY", GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_HTML", inputMap).getString("HTML_DATA"));

					emailMap.put("IS_BODY_HTML", true);
					emailMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);

					String fileNameGeriOdeme = birBasvuru.getBasvuruNo() + "_GERI_ODEME_" + System.currentTimeMillis() + ".pdf";
					iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
					iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3133_ARA_ODEME_RAPOR", iMap));
					byte[] geriOdeme = (byte[]) iMap.get("REPORT_ARA_ODEME");

					emailMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", fileNameGeriOdeme);
					emailMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", geriOdeme);
					GMServiceExecuter.executeAsync("BNSPR_SYSTEM_MAIL_SEND_EMAIL", emailMap);
				}
			}
			
			/** Tasit kredilerinden otomatik rehin kaldirilmasi **/
			iMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
			iMap.put("CEP_TEL", cepTel);
			GMServiceExecuter.call("BNSPR_TRN3133_REHIN_KALDIRIM", iMap);
		
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3133_REHIN_KALDIRIM")
	public static GMMap rehinKaldirim(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
		
		/** Tasit kredilerinden otomatik rehin kaldirilmasi **/
		List<MuhHesapKredi> takipList = session.createCriteria(MuhHesapKredi.class).add(Restrictions.eq("basvuruNo", birBasvuru.getBasvuruNo())).add(Restrictions.eq("takipDurumKodu", "Y")).list();
		
		if(birBasvuru.getKrediTur().equals(CreditTypes.TASIT.getCreditCode()) && "KAPANDI".equals(birBasvuru.getDurumKodu()) && takipList.size() == 0) {
			
			try {
				List<Object> list = session.createQuery("from TemTeminatMain t, TemTeminatDetail td where t.teminatNo = td.teminatNo and td.teminatKod = '01"
						+ "' and t.basvuruNo=" + birBasvuru.getBasvuruNo()).list();
				if(list.size() > 0){
					Object[] obj =  (Object[])list.get(0);
					TemTeminatMain teminatMain = (TemTeminatMain)obj[0];
					TemTeminatDetail teminatDetail = (TemTeminatDetail)obj[1];
					
					GMMap tMap = new GMMap();
					tMap.put("EGM_REF_NO", teminatDetail.getEgmRefNo());
					tMap.put("COLLATERAL_NO", teminatMain.getTeminatNo());
					
					tMap.putAll(GMServiceExecuter.call("EPLEDGE_CHECK_PLEDGE_STATUS_FOR_REMOVAL", tMap));
					
					tMap.put("EPLEDGE_PLEDGE_OID", tMap.get("PLEDGE_OID"));
					tMap.put("REMOVE_BRANCH_CODE", "555");
					tMap.put("WITHOUT_APPROVAL", "E");
					
					GMServiceExecuter.execute("EPLEDGE_REMOVE_PLEDGE", tMap);
					
					iMap.put("MSISDN", iMap.getString("CEP_TEL"));
					iMap.put("MESSAGE_NO", new BigDecimal(6054));
					iMap.put("CONTENT", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
					GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", iMap).get("RESULT");
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		return iMap;
		
	}

	@GraymoundService("BNSPR_TRN3133_GET_COMPONENT_ROLE")
	public static GMMap getComponentProperties(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<GnlEkranAlanRolTanim> roleList = null;
		String currentRole = StringUtils.EMPTY;

		try {
			String[] components = iMap.getString("ALAN_ADI").split(";");

			for (int i = 0; i < components.length; i++) {
				roleList = (List<GnlEkranAlanRolTanim>) session.createCriteria(GnlEkranAlanRolTanim.class).add(Restrictions.eq("id.islemKod", iMap.getBigDecimal("ISLEM_KOD"))).add(Restrictions.eq("id.alanAdi", components[i])).list(); // , values) eq("id.alanAdi", iMap.getString("ALAN_ADI"))).list();

				currentRole = (String) DALUtil.callNoParameterFunction("{? = call pkg_global.get_rolkod}", Types.VARCHAR);
				oMap.put(components[i], true);

				for (GnlEkranAlanRolTanim gnlEkranAlanRolTanim : roleList) {
					if (gnlEkranAlanRolTanim.getErisimsizRol() != null && Arrays.asList(gnlEkranAlanRolTanim.getErisimsizRol().split(";")).contains(currentRole)) {
						oMap.put(components[i], false);
					}
				}
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_3133_COMBO_PARAMETERS")
	public static GMMap getComboParameters(GMMap iMap) {
		GMMap oMap = new GMMap();
		String[] codeList = null;
		String[] key2List = null;
		String[] tableNameList = null;

		try {
			codeList = iMap.getString("KOD").split(";");
			key2List = iMap.getString("KEY2").split(";");
			tableNameList = iMap.getString("TABLE_NAME").split(";");

			for (int i = 0; i < tableNameList.length; i++) {
				GMMap tempMap = new GMMap();
				tempMap.put("KOD", codeList[i]);
				tempMap.put("KEY2", key2List[i]);
				tempMap.put("TABLE_NAME", tableNameList[i]);
				tempMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", tempMap);
				oMap.put(tableNameList[i], tempMap.get(tableNameList[i]));
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_GET_GERI_ODEME_ERKEN_KAPAMA_DETAY")
	public static GMMap getGeriOdemeErkenKapamaDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		Session session;

		try {
			session = DAOSession.getSession("BNSPRDal");
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_bireysel2.GeriOdemeErkenKapamaDetay(?,?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAPAMA_NEDENI"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i, Types.NUMERIC);
			stmt.execute();

			oMap.put("DIGER_MASRAF", stmt.getBigDecimal(i--));
			oMap.put("PTT_BASVURU_MASRAF", stmt.getBigDecimal(i--));
			oMap.put("TAHSIS_UCRETI_BSMV", stmt.getBigDecimal(i--));
			oMap.put("TAHSIS_UCRETI", stmt.getBigDecimal(i--));
			oMap.put("FARK_FAIZI_KKDF", stmt.getBigDecimal(i--));
			oMap.put("FARK_FAIZI_BSMV", stmt.getBigDecimal(i--));
			oMap.put("FARK_FAIZI", stmt.getBigDecimal(i--));
			oMap.put("KUL_SIG_PRIM_HESAP", stmt.getBigDecimal(i--));
			oMap.put("KUL_SIG_PRIM", stmt.getBigDecimal(i--));
			oMap.put("KUL_SIG_KOM", stmt.getBigDecimal(i--));
			oMap.put("ILK_TAKSIT_ODENDIMI", (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3133.ilk_taksit_odendimi(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO")));
			oMap.put("SIGORTA_FIRMA_KODU", ((BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult()).getPttSigortaFirmaKodu());

			BirKullandirim birKullandirim = (BirKullandirim) session.createCriteria(BirKullandirim.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if ("H".equals(oMap.getString("ILK_TAKSIT_ODENDIMI")) && TimeUnit.DAYS.convert(DateUtils.truncate(new Date(), Calendar.DATE).getTime() - birKullandirim.getIslemTar().getTime(), TimeUnit.MILLISECONDS) <= 14) {
				oMap.put("CAYMA_SURECINDE", "E");
			}
			else {
				oMap.put("CAYMA_SURECINDE", "H");
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_CHECK_OTOMATIK_TAHSILAT")
	public static GMMap checkOtomatikTahsilat(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap.put("OTOMATIK_TAHSILAT", (String) DALUtil.callNoParameterFunction("{? = call pkg_trn3133.checkOtomatikTahsilat}", Types.VARCHAR));
			if ("1".equals(oMap.getString("OTOMATIK_TAHSILAT"))) {
				ConsumerLoanCommonServices.raiseGMError("5409");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_CL_GET_SISTEM_TARIHI")
	public static GMMap getSistemTarihi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			String q = "select to_char(trunc(sysdate),'yyyymmdd') TARIH from   dual";

			stmt = conn.prepareCall(q);
			rSet = stmt.executeQuery();
			while (rSet.next()) {
				oMap.put("TARIH", rSet.getString("TARIH"));
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3133_ARA_ODEME_RAPOR")
	public static GMMap araOdemeRapor(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session;
		try {
			session = DAOSession.getSession("BNSPRDal");
			if (iMap.getBigDecimal("TRX_NO") == null) {
				oMap.put("ERROR_MESSAGE", "��lem numaras� zorunludur.");
				return oMap;
			}

			BirGeriOdemeTx birGeriOdemeTx = (BirGeriOdemeTx) session.get(BirGeriOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", birGeriOdemeTx.getBasvuruNo());

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", birGeriOdemeTx.getBasvuruNo())).uniqueResult();
			String queryGuncelBorc = "select sum(t.taksit_tut) from bir_kredi_taksit t where t.basvuru_no = " + birGeriOdemeTx.getBasvuruNo().toString();
			if (StringUtils.isNotEmpty(queryGuncelBorc)) {
				parameters.put("GUNCEL_BORC", new BigDecimal(DALUtil.getResult(queryGuncelBorc)));
			}
			else {
				parameters.put("GUNCEL_BORC", BigDecimal.ZERO);
			}
			BirKullandirim birKullandirim = (BirKullandirim) session.get(BirKullandirim.class, birGeriOdemeTx.getBasvuruNo());
			parameters.put("DAGITILAN_FARK_FAIZI", birKullandirim.getFarkFaiziTaksit());
			parameters.put("VADESIZ_HESAP_NO", (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.onceki_basvuru_hesap_no(?)}", Types.VARCHAR, birGeriOdemeTx.getBasvuruNo()));

			ArrayDeque<String> reportNames = new ArrayDeque<String>();
			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				reportNames.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME_FZ");
			}
			else {
				reportNames.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME");
			}

			JasperPrint reportOdemePlani = ReportUtil.generateAndConcatReports(reportNames, parameters);
			oMap.put("REPORT_ARA_ODEME_JASPER", reportOdemePlani);
			byte[] outReportGeriOdeme = JasperExportManager.exportReportToPdf(reportOdemePlani);
			oMap.put("REPORT_ARA_ODEME", outReportGeriOdeme);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_TRN3133_RETENTION_SORGU_KONTROL")
	public static GMMap retentionSorguKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = null;
		try {
			oMap.put("SORGU_DEVAM", "H");
			sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

			if ("E".equals(iMap.getString("SORGU_BASLA"))) {
				oMap.put("SORGU_ZAMAN", sdf.format(new Date()));
			}
			else {
				iMap.put("LIMIT_TURU", "R");
				oMap.putAll(GMServiceExecuter.call("BNSPR_CL_GET_ON_ONAY_BILGI", iMap));

				if (oMap.getString("KREDI_TURU") == null) {
					Calendar c = Calendar.getInstance();
					c.setTime(sdf.parse(iMap.getString("SORGU_ZAMAN")));
					c.add(Calendar.MINUTE, -2);

					String fetchQuery = "select b.id from bnspr.bir_adk_basvuru b where b.tc_kimlik_no = '" + iMap.getString("TC_KIMLIK_NO") + "' and b.akis_turu = 'R' and b.rec_date > to_date('" + sdf.format(c.getTime()) + "', 'dd.MM.yyyy HH24:mi:ss')";

					oMap = DALUtil.getResults(fetchQuery, "TABLE");
					c.add(Calendar.MINUTE, 2);

					long secDif = (Calendar.getInstance().getTimeInMillis() - c.getTimeInMillis()) / 1000 % 60;
					if (oMap.getSize("TABLE") == 0 && secDif < 30) {
						oMap.put("SORGU_DEVAM", "E");
					}
				}
				oMap.put("SORGU_ZAMAN", iMap.getString("SORGU_ZAMAN"));
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3133_ERKEN_TAHSILAT_YAPILABILIRMI")
	public static GMMap isErkenTahsilat(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Object[] inputValues = new Object[2];

			String func = "{? = call pkg_trn3133.erken_tahsilat_yapilabilir_mi(?,?)}";
			int i = 0;
			inputValues = new Object[4];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TAKSIT_NO");

			oMap.put("ERKEN_TAHSILAT_YAPILABILIRMI", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3133_MUSTERI_GECIKMEDEMI")
	public static GMMap musteriGecikmedemi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session;
		String gecikmede = "H";
		try {
			session = DAOSession.getSession("BNSPRDal");
			List<BirBasvuru> list = session.createQuery("from BirBasvuru where tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and krediTur = '1' and durumKodu in ('CEPTE', 'EVRAKSIZ')").list();

			for (BirBasvuru birBasvuru : list) {
				List<BirKrediTaksit> gecikmisTaksitList = session.createCriteria(BirKrediTaksit.class).add(Restrictions.eq("id.basvuruNo", birBasvuru.getBasvuruNo())).add(Restrictions.in("durumKod", new String[] { "ACIK", "KISMI" })).add(Restrictions.lt("taksitTarih", new Date())).list();
				if (gecikmisTaksitList.size() > 0) {
					gecikmede = "E";
				}
			}

			oMap.put("GECIKMEDE", gecikmede);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

}
