package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3178Services {

	@GraymoundService("BNSPR_QRY3178_BASVURU_ODEME_PLANI_GONDER")
	public static GMMap sendBasvuruOdemePlani(GMMap iMap) {
		GMMap oMap = new GMMap();

		HashMap<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("BASVURU_NO", iMap.get("BASVURU_NO"));

		JasperPrint jp = (JasperPrint) iMap.get("REPORT");
		try {
			jp = ReportUtil.generateReport("BNSPR_RAP3171_ODEME_PLANI", parameters);
		}
		catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		byte[] binary = null;
		try {
			binary = JasperExportManager.exportReportToPdf(jp);
		}
		catch (Exception e) {
			oMap.put("RESPONSE", 0);
			oMap.put("RESPONSE_DATA", "error");
			return oMap;
		}

		GMMap myMap = new GMMap();
		myMap.put("MAIL_FROM", "aktifbank@aktifbank.com.tr");
		myMap.put("MAIL_TO", iMap.get("EMAIL"));
		myMap.put("IS_BODY_HTML", "E");
		myMap.put("MAIL_SUBJECT", "�deme Plan�");
		myMap.put("MAIL_BODY", "De�erli M��terimiz,<br>Talep etmi� oldu�unuz belge ekte yer almaktad�r.<br>Sayg�lar�m�zla,");

		myMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", "odemePlani.pdf");
		myMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", binary);

		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", myMap);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY3178_BASVURU_IZLEME_LIST")
	public static GMMap getBasvuruGuncelleList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String durumList = "";
			if (iMap.containsKey("APP_TYPE")) {
				if ("CC".equals(iMap.getString("APP_TYPE"))) {
					durumList = iMap.getString("DURUM_LIST");
					if (durumList == null) {
						durumList = "HEPSI";
					}
					durumList += ",";
				}
			}
			else {
				Object[] selectedList = (Object[]) iMap.get("DURUM_LIST");

				if (selectedList != null) {
					for (Object selected : selectedList) {
						HashMap<String, Object> selectedMap = (HashMap<String, Object>) selected;

						if (null == selectedMap.get("VALUE")) {
							durumList += "HEPSI,";
						}
						else {
							durumList += selectedMap.get("VALUE") + ",";
						}
					}
				}
			}

			String func = "{? = call PKG_RC3178.RC_QRY3178_BASVURU_IZLEME_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"), BnsprType.NUMBER, iMap.getBigDecimal("KREDI_TURU"), BnsprType.STRING, iMap.getString("DOVIZ_KODU"), BnsprType.STRING, iMap.getString("ADI"), BnsprType.STRING, iMap.getString("IKINCI_ADI"), BnsprType.STRING,
					iMap.getString("SOYADI"), BnsprType.STRING, iMap.getString("KAMP_URUN_ADI"), BnsprType.DATE, iMap.getDate("BASLANGIC_TAR"), BnsprType.DATE, iMap.getDate("BITIS_TAR"), BnsprType.STRING, iMap.getString("KANAL_KODU"), BnsprType.STRING, iMap.getString("SATICI_KODU"), BnsprType.STRING, iMap.getString("SATICI_CALISMA_SEKLI"), BnsprType.STRING,
					(iMap.getBoolean("IPTAL")) ? "TRUE" : "FALSE", BnsprType.STRING, iMap.getString("CEP_ALAN"), BnsprType.STRING, iMap.getString("CEP_TLF"), BnsprType.STRING, iMap.getString("KAMP_DURUM_KOD"), BnsprType.STRING, iMap.getString("SISTEM_KARARI"), BnsprType.STRING, iMap.getString("FRAUD"), BnsprType.STRING, iMap.getString("ESYA_SIGORTA_LISTELENSIN"), BnsprType.STRING,
					iMap.getString("SUBE_KOD"), BnsprType.STRING, durumList, BnsprType.NUMBER, iMap.getBigDecimal("DISTRIBUTOR"), BnsprType.NUMBER, iMap.getBigDecimal("GARANTOR"), BnsprType.STRING, iMap.getString("KONSOLIDASYON"), BnsprType.STRING, iMap.getString("PTT"), // ptt emekli bilgileri icin eklendi
					BnsprType.STRING, iMap.getString("BAGLI_BOLGE"), // bagli oldugu bolge kriterleri icin eklendi
					BnsprType.STRING, iMap.getString("KAZANIM_KANAL"), BnsprType.STRING, (iMap.getBoolean("CH_TAKSITLI_KDH")) ? "E" : "H", BnsprType.STRING, iMap.getString("FAIZSIZ_FINANSMAN"), BnsprType.STRING, iMap.getString("BORC_TRANSFERI"), BnsprType.STRING, iMap.getString("PTT_ICI_BIRLESTIRME") };

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BASVURU_BILGILERI", inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3178_ONAY_STATU_LIST")
	public static GMMap getOnayStatuList(GMMap iMap) { // BNSPR_QRY3129_ONAY_STATU_LIST

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1 from v_ml_gnl_param_text where kod = 'ONAY_STATU_KOD' order by sira_no");

			rSet = stmt.executeQuery();
			String listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, null, "HEPSI");

			while (rSet.next()) {
				if (rSet.getString(1).equals("KUL"))
					GuimlUtil.wrapMyCombo(oMap, listName, "KUL", "KULLANDIRIM");
				else
					GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(1));
			}
			oMap.put("DATE", new Date());

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3178_SATICI_CALISMA_SEKLI")
	public static GMMap getCalismaSekliList(GMMap iMap) {
		try {

			GMMap oMap = new GMMap();
			iMap.put("KOD", "CALISMA_SEKLI_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BAYI_CALISMA_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3178_SATICI_KAZANIM_KANAL")
	public static GMMap getSaticiKazanimKanalList(GMMap iMap) {
		try {

			GMMap oMap = new GMMap();
			iMap.put("KOD", "BAYI_KAZANIM_KANAL");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KAZANIM_KANAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3178_NBSM_KARAR_KOD")
	public static GMMap getNBSMKararKod(GMMap iMap) {
		return DALUtil.fillComboBox(iMap, "NBSM_KARAR_LIST", true, "select b.KEY1, b.KEY1 from bnspr.v_ml_gnl_param_text b Where b.KOD='NBSM_KARAR_KOD' Order By b.SIRA_NO");
	}

	@GraymoundService("BNSPR_QRY3178_GET_KANAL_LIST")
	public static GMMap getKanalList(GMMap iMap) {
		return DALUtil.fillComboBox(iMap, "KANAL_LIST", true, "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr t " + "where t.KOD in " + "(select b.kanal_kodu from bnspr.bir_basvuru b UNION select bt.kanal_kodu from bnspr.bir_basvuru_tx bt where bt.kanal_kodu > 0 group by bt.kanal_kodu) " + "order by t.ACIKLAMA");
		// return DALUtil.fillComboBox(iMap, "KANAL_LIST", true, "select b.kanal_kodu, bnspr.pkg_genel_pr.kanal_adi(b.kanal_kodu) kanal_adi from bnspr.bir_basvuru b group by b.kanal_kodu order by 2");
	}

	@GraymoundService("BNSPR_QRY3178_GET_SATICI_LIST")
	public static GMMap getSaticiList(GMMap iMap) {
		return DALUtil.fillComboBox(iMap, "SATICI_LIST", true, "select kod, satici_adi from bir_satici B where B.Drm = 'G' and B.SATICI_TIP_KOD != 'D' order by kod");
	}

	@GraymoundService("BNSPR_QRY3178_GET_MUSTERI_BLOKE")
	public static GMMap getMusteriBloke(GMMap iMap) {

		GMMap oMap = new GMMap();

		String listName = "MUSTERI_BLOKE";
		GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
		GuimlUtil.wrapMyCombo(oMap, listName, "0", "Hay�r");
		GuimlUtil.wrapMyCombo(oMap, listName, "1", "Evet");

		return oMap;

	}

	@GraymoundService("BNSPR_QRY3178_GET_COMBO_EDITOR_DATA")
	public static GMMap getComboEditorData(GMMap iMap) {

		GMMap oMap = new GMMap();

		String listName = "EK_IHTIYAC";
		GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
		GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");

		listName = "UPSELL_MI";
		GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
		GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");

		listName = "FAIZSIZ_FINANSMAN";
		GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
		GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1,text from v_ml_gnl_param_text where kod = 'KREDI_HESAP_DURUM' order by sira_no");

			rSet = stmt.executeQuery();
			listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_QRY3178_ONAY_STATU_LIST_WITH_KAPANDI")
	public static GMMap getOnayStatuListWithKapandi(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1 from v_ml_gnl_param_text where kod = 'ONAY_STATU_KOD' and key1 not in ('KULONAY', 'NBSM', 'JOB') order by sira_no");

			rSet = stmt.executeQuery();
			String listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, null, "HEPSI");
			while (rSet.next()) {
				if (rSet.getString(1).equals("KUL"))
					GuimlUtil.wrapMyCombo(oMap, listName, "KUL", "KULLANDIRIM");
				else
					GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(1));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3188_SOZLESME_BASILDI_MI")
	public static GMMap sozlesmeDurum(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3178.RC_QRY3188_SOZLESME_BASILDI_MI(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			oMap.put("SOZLESME_BASILDI_MI", stmt.getString(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3168_TEMINAT_BELGE_INFO")
	public static GMMap getTeminatBelge(GMMap iMap) {
		Connection conn = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			DALUtil.fillComboBox(oMap, "TEMINAT_LIST", false, "select kod, aciklama from v_ml_tem_teminat_kodlari_pr order by 1");

			oMap.put("TEMINAT", GMServiceExecuter.execute("BNSPR_TRN3174_GET_TEMINAT_LIST", iMap).get("TEMINAT"));
			oMap.put("BELGE", GMServiceExecuter.execute("BNSPR_TRN3174_GET_BELGE_LIST", iMap).get("BELGE"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
		}
	}
}
