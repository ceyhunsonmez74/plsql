package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.Types;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlEkranAlanRolTanim;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3244Services {
	
	@GraymoundService("BNSPR_QRY3244_DCS_ANLIK_BAKIYE")
	public static GMMap dcsAnlikBakiye(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			GMMap tMap = new GMMap();
			tMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO") );			
			tMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
			
			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_DCS_ANLIK_BAKIYE_AL", tMap)); 
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
		return oMap;
		
	}
	
	@GraymoundService("BNSPR_QRY3244_GET_COMPONENT_ROLE")
	public static GMMap getComponentRoles(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<GnlEkranAlanRolTanim> roleList = null;
		String currentRole = StringUtils.EMPTY;
		
		try {
			String[] components = iMap.getString("ALAN_ADI").split(";");
			
			for(int i = 0; i < components.length; i++){
				roleList = (List<GnlEkranAlanRolTanim>) session.createCriteria(GnlEkranAlanRolTanim.class).
							add(Restrictions.eq("id.islemKod", iMap.getBigDecimal("ISLEM_KOD"))).
							add(Restrictions.eq("id.alanAdi", components[i])).list();
				
				currentRole = (String) DALUtil.callNoParameterFunction("{? = call pkg_global.get_rolkod}", Types.VARCHAR);
				oMap.put(components[i], false);
				
				for (GnlEkranAlanRolTanim gnlEkranAlanRolTanim : roleList) {
					if(gnlEkranAlanRolTanim.getErisimliRol() != null && Arrays.asList(gnlEkranAlanRolTanim.getErisimliRol().split(";")).contains(currentRole)){
						oMap.put(components[i], true);
					}
				}
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
}
