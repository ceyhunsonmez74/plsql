package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSigortaUrun;
import tr.com.aktifbank.bnspr.dao.BirSigortaUrunDetay;
import tr.com.aktifbank.bnspr.dao.BirSigortaUrunDetayTx;
import tr.com.aktifbank.bnspr.dao.BirSigortaUrunDetayTxId;
import tr.com.aktifbank.bnspr.dao.BirSigortaUrunTx;
import tr.com.aktifbank.bnspr.dao.BirSigortaUrunTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3237Services {

	@GraymoundService("BNSPR_TRN3237_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String query = "select key1, text from GNL_PARAM_TEXT WHERE KOD = 'SIGORTASIRKET' order by 1";
			DALUtil.fillComboBox(oMap, "LIST", false, query);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3237_GET_INFO")
	public static GMMap trn3237GetInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "URUN_LIST";

			int i = 0;
			GMMap oMap = new GMMap();
			List<BirSigortaUrun> list = (List<BirSigortaUrun>) session.createCriteria(BirSigortaUrun.class).addOrder(Order.asc("urunNo")).list();
			Iterator<?> iterator = list.iterator();
			while (iterator.hasNext()) {
				BirSigortaUrun birSigortaUrun = (BirSigortaUrun) iterator.next();
				oMap.put(tableName, i, "SIGORTA_SIRKETI", birSigortaUrun.getSigortaSirketi());
				oMap.put(tableName, i, "URUN_ACIKLAMA", birSigortaUrun.getUrunAciklamasi());
				oMap.put(tableName, i, "URUN_NO", birSigortaUrun.getUrunNo());
				if ("E".equals(birSigortaUrun.getDosyayaCikilacakMi())) {
					oMap.put(tableName, i, "DOSYAYA_CIKILACAK_MI", new BigDecimal(1));
				}
				else {
					oMap.put(tableName, i, "DOSYAYA_CIKILACAK_MI", new BigDecimal(0));
				}
				oMap.put(tableName, i, "SIL", false);
				List<BirSigortaUrunDetay> list2 = (List<BirSigortaUrunDetay>) session.createCriteria(BirSigortaUrunDetay.class).add(Restrictions.eq("id.urunNo", birSigortaUrun.getUrunNo())).addOrder(Order.asc("id.urunNo")).list();
				int j = 0;
				GMMap o2Map = new GMMap();
				Iterator<?> iterator2 = list2.iterator();
				String table2Name = "DETAY";
				while (iterator2.hasNext()) {
					BirSigortaUrunDetay birSigortaUrunDetay = (BirSigortaUrunDetay) iterator2.next();
					if (birSigortaUrunDetay != null) {
						o2Map.put(table2Name, j, "UZUN_KISA_VADE", birSigortaUrunDetay.getId().getUzunKisa());
						o2Map.put(table2Name, j, "TARIFE_KOD", birSigortaUrunDetay.getId().getTarifeKodu());
						o2Map.put(table2Name, j, "SABIT_AZALAN", birSigortaUrunDetay.getId().getSabitAzalan());
						o2Map.put(table2Name, j, "MARJ", birSigortaUrunDetay.getMarj());
						o2Map.put(table2Name, j, "KOMISYON_ORANI", birSigortaUrunDetay.getKomisyonOrani());

						j++;
					}
				}
				oMap.put(tableName, i, "DETAY", o2Map.get(table2Name));
				i++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN3237_SAVE")
	public static GMMap trn3237Save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "URUN_LIST";
			String table2Name = "DETAY";
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			int i = 0;
			int j = 0;
			while (i < iMap.getSize(tableName)) {
				j = 0;
				GMMap tMap = new GMMap();
				tMap.put(table2Name, iMap.get(tableName, i, table2Name));
				while (j < tMap.getSize(table2Name)) {
					String tarifKod = tMap.getString(table2Name, j, "TARIFE_KOD");
					if ("".equals(tarifKod) || tarifKod.isEmpty()) {

						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j + 1);
						iMap.put("P2", "Tarife Kod");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					j++;
				}
				i++;
			}

			for (i = 0; i < iMap.getSize(tableName); i++) {
				BirSigortaUrunTx birSigortaUrunTx = (BirSigortaUrunTx) session.createCriteria(BirSigortaUrunTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TX_NO"))).add(Restrictions.eq("id.urunNo", iMap.getBigDecimal(tableName, i, "URUN_NO"))).uniqueResult();
				if (birSigortaUrunTx == null) {
					birSigortaUrunTx = new BirSigortaUrunTx();
				}
				BirSigortaUrunTxId birSigortaUrunTxId = new BirSigortaUrunTxId();
				birSigortaUrunTxId.setTxNo(txNo);
				birSigortaUrunTxId.setUrunNo(iMap.getBigDecimal(tableName, i, "URUN_NO"));
				GMMap sMap = new GMMap();

				sMap.put(table2Name, iMap.get(tableName, i, table2Name));
				j = 0;
				while (j < sMap.getSize(table2Name)) {
					BirSigortaUrunDetayTx birSigortaUrunDetayTx = new BirSigortaUrunDetayTx();
					BirSigortaUrunDetayTxId id = new BirSigortaUrunDetayTxId();
					id.setTarifeKodu(sMap.getString(table2Name, j, "TARIFE_KOD"));
					id.setTxNo(txNo);
					id.setUrunNo(iMap.getBigDecimal(tableName, i, "URUN_NO"));

					birSigortaUrunDetayTx.setMarj(sMap.getBigDecimal(table2Name, j, "MARJ"));
					id.setSabitAzalan(sMap.getString(table2Name, j, "SABIT_AZALAN"));
					id.setUzunKisa(sMap.getString(table2Name, j, "UZUN_KISA_VADE"));
					birSigortaUrunDetayTx.setKomisyonOrani(sMap.getBigDecimal(table2Name, j, "KOMISYON_ORANI"));
					birSigortaUrunDetayTx.setId(id);
					j++;
					session.save(birSigortaUrunDetayTx);
				}
				birSigortaUrunTx.setSigortaSirketi(iMap.getString(tableName, i, "SIGORTA_SIRKETI"));
				birSigortaUrunTx.setUrunAciklamasi(iMap.getString(tableName, i, "URUN_ACIKLAMA"));
				birSigortaUrunTx.setSilinecekMi(iMap.getBoolean(tableName, i, "SIL") ? "E" : "H");
				birSigortaUrunTx.setDosyayaCikilacakMi(iMap.getBoolean(tableName, i, "DOSYAYA_CIKILACAK_MI") ? "E" : "H");
				birSigortaUrunTx.setId(birSigortaUrunTxId);
				session.save(birSigortaUrunTx);

			}
			session.flush();

			iMap.put("TRX_NAME", "3237");
			GMMap oMap = new GMMap();
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			return oMap;
		}
		catch (Exception e) {
			if (e.getCause() != null)
				throw new GMRuntimeException(0, e.getCause().getMessage());
			else
				throw new GMRuntimeException(0, e);
		}
	}
}
