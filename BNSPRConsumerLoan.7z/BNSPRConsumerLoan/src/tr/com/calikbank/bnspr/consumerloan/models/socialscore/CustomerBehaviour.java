package tr.com.calikbank.bnspr.consumerloan.models.socialscore;

public class CustomerBehaviour {
	private String entryTime;

    private String exitTime;

    private InputData[] inputData;

    private String BackspaceCount;

    private String CopyPasteCount;

    private String FieldChangeCount;

    private String DeleteCount;

    private String pageName;

    public String getEntryTime ()
    {
        return entryTime;
    }

    public void setEntryTime (String entryTime)
    {
        this.entryTime = entryTime;
    }

    public String getExitTime ()
    {
        return exitTime;
    }

    public void setExitTime (String exitTime)
    {
        this.exitTime = exitTime;
    }

    public InputData[] getInputData ()
    {
        return inputData;
    }

    public void setInputData (InputData[] inputData)
    {
        this.inputData = inputData;
    }

    public String getBackspaceCount ()
    {
        return BackspaceCount;
    }

    public void setBackspaceCount (String BackspaceCount)
    {
        this.BackspaceCount = BackspaceCount;
    }

    public String getCopyPasteCount ()
    {
        return CopyPasteCount;
    }

    public void setCopyPasteCount (String CopyPasteCount)
    {
        this.CopyPasteCount = CopyPasteCount;
    }

    public String getFieldChangeCount ()
    {
        return FieldChangeCount;
    }

    public void setFieldChangeCount (String FieldChangeCount)
    {
        this.FieldChangeCount = FieldChangeCount;
    }

    public String getDeleteCount ()
    {
        return DeleteCount;
    }

    public void setDeleteCount (String DeleteCount)
    {
        this.DeleteCount = DeleteCount;
    }

    public String getPageName ()
    {
        return pageName;
    }

    public void setPageName (String pageName)
    {
        this.pageName = pageName;
    }
}
