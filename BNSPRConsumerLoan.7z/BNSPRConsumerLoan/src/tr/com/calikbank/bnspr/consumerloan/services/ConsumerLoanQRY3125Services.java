package tr.com.calikbank.bnspr.consumerloan.services;
import java.io.File;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3125Services {
	private static String ROOT = GMServer.getProperty("graymound.home",null)+
	File.separator 	+
	"Server"		+
	File.separator 	+
	"Content"		+
	File.separator	+
	"Root"			;
	
@GraymoundService("BNSPR_QRY3125_GET_KULLANDIRILMIS_KREDILER")
public static GMMap GetKullandirilmisKrediler(GMMap iMap) throws ParseException, RowsExceededException, WriteException, IOException{
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3125.QRY3125_Kullandirimis_Krediler(?,?) }");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			if(iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			if(iMap.getDate("BIT_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
			else
				stmt.setDate(i++, null);			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			int fileNum = 1;
			File f = new File(ROOT+File.separator+"files"+File.separator + "KullandirilmisKrediler_"+fileNum+".csv");
			WritableWorkbook workbook = Workbook.createWorkbook(f); 
			int sheetNum = 0;
			WritableSheet sheet = workbook.createSheet("Krediler_"+fileNum+"_"+(sheetNum+1), sheetNum);
			//Baslik satiri.
			int row = 0;
			int col = 0;
			sheet.addCell(new Label(col++, row, "BASVURU NO"));
			sheet.addCell(new Label(col++, row, "MUSTERI NO"));
			sheet.addCell(new Label(col++, row, "ADI SOYADI"));
			sheet.addCell(new Label(col++, row, "MUSTERI DK NO"));
			sheet.addCell(new Label(col++, row, "SUBE KODU"));
			sheet.addCell(new Label(col++, row, "DURUM KODU"));
			sheet.addCell(new Label(col++, row, "KREDI TURU"));
			sheet.addCell(new Label(col++, row, "KREDI HESAP NO"));
			sheet.addCell(new Label(col++, row, "DOVIZ"));
			sheet.addCell(new Label(col++, row, "FAIZ ORANI"));
			sheet.addCell(new Label(col++, row, "TAHAKKUK TARIHI"));
			sheet.addCell(new Label(col++, row, "VADE"));
			sheet.addCell(new Label(col++, row, "ACILIS TARIHI"));
			sheet.addCell(new Label(col++, row, "BIRIKMIS FAIZ TUTARI"));
			sheet.addCell(new Label(col++, row, "RISK"));
			sheet.addCell(new Label(col++, row, "BASVURU KANALI"));
			sheet.addCell(new Label(col++, row, "KAMP KODU"));
			sheet.addCell(new Label(col++, row, "KAMP ADI"));
			sheet.addCell(new Label(col++, row, "BASVURU TARIHI"));

            row++;
    		DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
    		while(rSet.next()) {
    			col = 0;
    			sheet.addCell(new Label(col++, row, rSet.getString("basvuru_no") == null ? "" : rSet.getBigDecimal("basvuru_no").toString()));
    			sheet.addCell(new Label(col++, row, rSet.getString("musteri_no") == null ? "" : rSet.getBigDecimal("musteri_no").toString()));
    			sheet.addCell(new Label(col++, row, rSet.getString("unvan")));
    			sheet.addCell(new Label(col++, row, rSet.getString("musteri_dk_no")));
    			sheet.addCell(new Label(col++, row, rSet.getString("sube_kodu")));
    			sheet.addCell(new Label(col++, row, rSet.getString("durum_kodu")));
    			sheet.addCell(new Label(col++, row, rSet.getString("kred�_turu")));
    			sheet.addCell(new Label(col++, row, rSet.getString("kredi_hesap_no") == null ? "" : rSet.getBigDecimal("kredi_hesap_no").toString()));
    			sheet.addCell(new Label(col++, row, rSet.getString("dov")));
    			sheet.addCell(new Label(col++, row, rSet.getString("faiz_oran�") == null ? "" : rSet.getBigDecimal("faiz_oran�").toString()));
    			sheet.addCell(new Label(col++, row, rSet.getString("tahakkuk_tar")));
    			sheet.addCell(new Label(col++, row, rSet.getString("vade")));
    			sheet.addCell(new Label(col++, row, rSet.getString("acilis_tarihi")));
    			sheet.addCell(new Label(col++, row, rSet.getString("birikmis_faiz_tutari") == null ? "" : rSet.getBigDecimal("birikmis_faiz_tutari").toString()));
    			sheet.addCell(new Label(col++, row, rSet.getString("risk") == null ? "" : rSet.getBigDecimal("risk").toString()));
    			sheet.addCell(new Label(col++, row, rSet.getString("basvuru_kanali")));
    			sheet.addCell(new Label(col++, row, rSet.getString("kamp_kod") == null ? "" : rSet.getBigDecimal("kamp_kod").toString()));
    			sheet.addCell(new Label(col++, row, rSet.getString("kamp_adi")));
    			sheet.addCell(new Label(col++, row, rSet.getString("basvuru_tarihi")));

    			row++;
    			//Sorgu bazen maximum excel satirini geciyor. Bu sebeple satir kontrolu eklenip diger scheet'e gecicek.
                if(row>65000){
    				if(sheetNum == 2){
    					fileNum++;
    					workbook.write();
    					workbook.close();
    					f = new File(ROOT+File.separator+"files"+File.separator + "KullandirilmisKrediler_"+fileNum+".csv");
    					workbook = Workbook.createWorkbook(f);
    					sheetNum = 0;
    				}else
    					sheetNum++;
    				row = 0;
    				sheet = workbook.createSheet("Krediler_"+fileNum+"_"+(sheetNum+1), sheetNum);
    				//yeni sheet e baslik ekleyelim.
    				col = 0;
    				sheet.addCell(new Label(col++, row, "BASVURU NO"));
    				sheet.addCell(new Label(col++, row, "MUSTERI NO"));
    				sheet.addCell(new Label(col++, row, "ADI SOYADI"));
    				sheet.addCell(new Label(col++, row, "MUSTERI DK NO"));
    				sheet.addCell(new Label(col++, row, "SUBE KODU"));
    				sheet.addCell(new Label(col++, row, "DURUM KODU"));
    				sheet.addCell(new Label(col++, row, "KREDI TURU"));
    				sheet.addCell(new Label(col++, row, "KREDI HESAP NO"));
    				sheet.addCell(new Label(col++, row, "DOVIZ"));
    				sheet.addCell(new Label(col++, row, "FAIZ ORANI"));
    				sheet.addCell(new Label(col++, row, "TAHAKKUK TARIHI"));
    				sheet.addCell(new Label(col++, row, "VADE"));
    				sheet.addCell(new Label(col++, row, "ACILIS TARIHI"));
    				sheet.addCell(new Label(col++, row, "BIRIKMIS FAIZ TUTARI"));
    				sheet.addCell(new Label(col++, row, "RISK"));
    				sheet.addCell(new Label(col++, row, "BASVURU KANALI"));
    				sheet.addCell(new Label(col++, row, "KAMP KODU"));
    				sheet.addCell(new Label(col++, row, "KAMP ADI"));
    				sheet.addCell(new Label(col++, row, "BASVURU TARIHI"));
    				row++;
                }
                }
    		workbook.write();
    		workbook.close();
    		iMap.put("DOSYA_SAYISI", fileNum);
    		return iMap;
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
	
		}
    }
@GraymoundService("BNSPR_QRY3125_DELETE_TMP_FILE")
public static GMMap deleteTmpFile(GMMap iMap){ 
	try {
		for (int i = 1; i <= iMap.getInt("DOSYA_SAYISI"); i++) {
			File f = new File(ROOT+File.separator+"files"+File.separator + "KullandirilmisKrediler_"+i+".csv");
			f.delete();
		}
		return iMap;
	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	} 
}
}