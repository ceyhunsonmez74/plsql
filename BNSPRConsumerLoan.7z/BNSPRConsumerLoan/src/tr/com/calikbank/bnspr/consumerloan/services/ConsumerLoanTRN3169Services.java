package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirGeriOdemeiptalTx;
import tr.com.aktifbank.bnspr.dao.BirGeriOdemeiptalTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.TemTeminatDetail;
import tr.com.calikbank.bnspr.dao.TemTeminatMain;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3169Services {
	@GraymoundService("BNSPR_TRN3169_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3169.son_geri_odeme_sorgula(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "SON_GERI_ODEME";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "ISLEM_NO", rSet.getBigDecimal("TX_NO"));
				oMap.put(tableName, row, "TARIH", rSet.getDate("ISLEM_TAR"));
				oMap.put(tableName, row, "TAHSILAT_TUTAR", rSet.getBigDecimal("TAHSILAT_TUTAR"));
				oMap.put(tableName, row, "BIR_GERI_ODM_TIP", rSet.getString("BIR_GERI_ODM_TIP"));
				oMap.put(tableName, row, "TAKSIT_VADE", rSet.getDate("TAKSIT_VADE"));
				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3169_THE_SAME_DAY_CHECK")
	public static GMMap ayniGunKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3169.the_same_day_check(?) }");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("IPTAL_TRX_NO"));
			stmt.execute();
			oMap.put("MESSAGE", stmt.getObject(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3169_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirGeriOdemeiptalTx birGeriOdemeiptalTx = new BirGeriOdemeiptalTx();
			BirGeriOdemeiptalTxId id = new BirGeriOdemeiptalTxId();

			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setIptalEdilenTxNo(iMap.getBigDecimal("IPTAL_TRX_NO"));

			birGeriOdemeiptalTx.setId(id);
			birGeriOdemeiptalTx.setGecFaizIptalGununden(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("GEC_FAIZ_IPTAL_GUNUNDEN")));
			session.saveOrUpdate(birGeriOdemeiptalTx);
			session.flush();

			iMap.put("TRX_NAME", "3169");

			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}
	}

	@GraymoundService("BNSPR_TRN3169_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3169.get_info(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "SON_GERI_ODEME";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "ISLEM_NO", rSet.getBigDecimal("IPTAL_EDILEN_TX_NO"));
				oMap.put(tableName, row, "TARIH", rSet.getDate("ISLEM_TAR"));
				oMap.put(tableName, row, "TAHSILAT_TUTAR", rSet.getBigDecimal("TAHSILAT_TUTAR"));
				oMap.put(tableName, row, "SIL", new BigDecimal(1));
				oMap.put("TRX_NO", rSet.getBigDecimal("TX_NO"));
				oMap.put("BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
				oMap.put("MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
				oMap.put("KRD_TUTAR", rSet.getBigDecimal("KRD_TUTAR"));
				oMap.put("KATKI_PAYI", rSet.getBigDecimal("KATKI_PAYI"));
				oMap.put("VADE", rSet.getBigDecimal("VADE"));
				oMap.put("DOSYA_MASRAF", rSet.getBigDecimal("DOSYA_MASRAF"));
				oMap.put("BAZ_FAIZ", rSet.getBigDecimal("FAIZ_ORANI"));
				oMap.put("SOZLESME_FAIZI", rSet.getBigDecimal("SOZLESME_ORANI"));
				oMap.put("BSMV_ORAN", rSet.getBigDecimal("BSMV_ORAN"));
				oMap.put("KKDF_ORAN", rSet.getBigDecimal("KKDF_ORAN"));
				oMap.put("ADI_SOYADI", rSet.getString("ADI_SOYADI"));
				oMap.put("KAMP_URUN_ADI", rSet.getString("KAMP_URUN_ADI"));
				oMap.put("GEC_FAIZ_IPTAL_GUNUNDEN", GuimlUtil.convertToCheckBoxSelected(rSet.getString("GEC_FAIZ_IPTAL_GUNUNDEN")));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN3169_TEMINAT_KONTROL")
	public static GMMap teminatKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call pkg_trn3133.hesapkapanacakmi(?) }");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("IPTAL_TRX_NO"));
			stmt.execute();
			String kapanacakEh = stmt.getString(1);

			if ("E".equalsIgnoreCase(kapanacakEh)) {
				TemTeminatMain main = (TemTeminatMain) session.createCriteria(TemTeminatMain.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.ne("durumKodu", "I")).uniqueResult();

				if (main != null) {
					TemTeminatDetail detail = (TemTeminatDetail) session.createCriteria(TemTeminatDetail.class).add(Restrictions.eq("teminatNo", main.getTeminatNo())).add(Restrictions.eq("teminatKod", "03")).add(Restrictions.ne("drm", "I")).uniqueResult();

					if (detail != null) {
						GMMap tMap = new GMMap();
						tMap.put("MESSAGE_NO", 5788);
						oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", tMap).get("ERROR_MESSAGE"));
					}
				}

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3169_TARIH_KONTROL")
	public static GMMap tarihKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3169.tarih_kontrol(?) }");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("IPTAL_TRX_NO"));
			stmt.execute();
			oMap.put("MESSAGE", stmt.getObject(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3169_GECIKME_FAIZ_KONTROL")
	public static GMMap gecikmeFaizKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3169.gecikme_faiz_kontrol(?) }");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("IPTAL_TRX_NO"));
			stmt.execute();
			oMap.put("MESSAGE", stmt.getObject(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
