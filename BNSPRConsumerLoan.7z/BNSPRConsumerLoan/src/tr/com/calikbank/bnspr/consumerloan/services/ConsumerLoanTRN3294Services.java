package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirBasvuruYimTx;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3294Services implements Constants{
	
	@GraymoundService("BNSPR_TRN3294_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "RESULT";
		BigDecimal trxNo = BigDecimal.ZERO;
		BigDecimal yimHesapNo = BigDecimal.ZERO;
		BigDecimal appNo = BigDecimal.ZERO;
		BigDecimal yimTutar = BigDecimal.ZERO;
		
		try {
			GMMap paramMap = new GMMap();
			paramMap.put(KOD, "YIM_BASVURU_PARAMETRE");
			paramMap.put(KEY, "YIM_HESAP_NO");
			yimHesapNo = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).getBigDecimal(TEXT);
			paramMap.put(KEY, "YIM_TUTAR");
			yimTutar = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).getBigDecimal(TEXT);
			session = DAOSession.getSession("BNSPRDal");
			
			if(iMap.getBigDecimal(TRX_NO, BigDecimal.ZERO).compareTo(BigDecimal.ZERO) == 1){
				trxNo = iMap.getBigDecimal(TRX_NO);
			}else{
				trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal(TRX_NO);
			}
			
			conn = DALUtil.getGMConnection();
			int paramIndex = 1;
			appNo = iMap.getBigDecimal(BASVURU_NO);
			stmt = conn.prepareCall("{ call PKG_TRN3294.getKullandirim(?,?)}");
			stmt.setBigDecimal(paramIndex++, appNo);
			stmt.registerOutParameter(paramIndex, -10);
			stmt.execute();
			stmt.getMoreResults();
			
			rSet = (ResultSet) stmt.getObject(paramIndex);	
			oMap = DALUtil.rSetResults(rSet, tableName);
			
			for (int i = 0; i < oMap.getSize(tableName); i++) {
				BirBasvuruYimTx yimTx = new BirBasvuruYimTx();
				yimTx.setTxNo(trxNo);
				yimTx.setBasvuruNo(appNo);
				yimTx.setMusteriNo(oMap.getBigDecimal(tableName, i, MUSTERI_NO));
				yimTx.setMusteriHesapNo(oMap.getBigDecimal(tableName, i, "ALAC_HESAP_NO"));
				yimTx.setYimHesapNo(yimHesapNo);
				yimTx.setKrediTutari(oMap.getBigDecimal(tableName, i, KRD_TUTAR));
				yimTx.setDovizKodu(oMap.getString(tableName, i, DOVIZ_KOD));
				yimTx.setKullandirimTarihi(oMap.getDate(tableName, i, ISLEM_TARIHI));
				yimTx.setBasvuruTarihi(oMap.getDate(tableName, i, BASVURU_TARIHI));
				yimTx.setKullandirilanNetTutar(oMap.getBigDecimal(tableName, i, KUL_TUTAR));
				yimTx.setDurumKodu("5"); //GNL_PARAM_TEXT.KOD = YIM_BASVURU_PARAMETRE
				yimTx.setGuncellemeTarihi(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate(BANKA_TARIH));
				yimTx.setHesaptaKalanTutar(yimTutar);
				session.save(yimTx);
			}
			session.flush();
			
			GMMap txMap = new GMMap();
			txMap.put("TRX_ONAYSIZ_ISLEM", "E");
			txMap.put(TRX_NAME, "3294");
			txMap.put(TRX_NO, trxNo);
			GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", txMap);
			
			//odeme islemleri bittikten sonra YIM e bildirimde bulunuluyor. 
			for (int i = 0; i < oMap.getSize(tableName); i++) {
				GMMap yimMap = new GMMap();
				yimMap.put("TCKN", oMap.getString(tableName, i, "TCKN"));
				yimMap.put("AD", oMap.getString(tableName, i, "AD"));
				yimMap.put("SOYAD", oMap.getString(tableName, i, "SOYAD"));
				yimMap.put("DOGUM_TARIH", oMap.getDate(tableName, i, "DOGUM_TAR"));
				yimMap.put("GSM_KOD", oMap.getString(tableName, i, "GSM_KOD"));
				yimMap.put("GSM_NO", oMap.getString(tableName, i, "GSM_NO"));
				yimMap.put("SMS_GONDER", Boolean.TRUE);
				yimMap.put("SMS_REF_NO", "");
				yimMap.put("BASVURU_TARIH", oMap.getDate(tableName, i, BASVURU_TARIHI));
				yimMap.put("KUL_TARIH", oMap.getDate(tableName, i, ISLEM_TARIHI));
				yimMap.put("SUBE_KOD", oMap.getString(tableName, i, "SUBE_KOD"));
				yimMap.put("HESAP_NO", oMap.getBigDecimal(tableName, i, KRD_HESAP_NO));
				yimMap.put("KRD_BASVURU_NO", appNo);
				yimMap.put("KRD_TUTAR", oMap.getBigDecimal(tableName, i, KRD_TUTAR));
				yimMap.put("MASRAF_TUTAR", oMap.getBigDecimal(tableName, i, "MASRAF_TUTAR"));
				yimMap.put("ODENECEK_TUTAR", oMap.getBigDecimal(tableName, i, KUL_TUTAR).subtract(yimTutar));
				yimMap.put("ACIKLAMA_ID", "");
				yimMap.put("ACIKLAMA", "");
				yimMap.put("BAYI_KOD", oMap.getString(tableName, i, "YIM_BAYI_KODU"));
				GMServiceExecuter.executeAsync("BNSPR_YIM_TRANSFER", yimMap);
				
				GMMap ibanMap = new GMMap().put("HESAP_NO", oMap.getBigDecimal(tableName, i, "ALAC_HESAP_NO"));
				
				iMap.put("P1", GMServiceExecuter.call("BNSPR_COMMON_GET_IBAN", ibanMap).getString("IBAN"));
				iMap.put("MESSAGE_NO", new java.math.BigDecimal(5922));
				String mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
								
				GMMap cepMap = new GMMap();
				cepMap.put("CONTENT", mesaj);
				cepMap.put("MSISDN", oMap.getString(tableName, i, "GSM_KOD") + oMap.getString(tableName, i, "GSM_NO"));
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS_ASYNC", cepMap).get("RESULT");
			}
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
