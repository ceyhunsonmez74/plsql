package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3137Services {

	@GraymoundService("BNSPR_QRY3137_GET_RECORD_FILL_LIST")
	public static GMMap getRecordQRY3137FillList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		BigDecimal farkFaizi = BigDecimal.ZERO;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3133.Ara_Odeme_Sonrasi_Odeme_Plani(?,?,?,?,?,?,?,?,?)}");
			int i = 1;	
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAKIYE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("DOVIZ_BAKIYE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_ANAPARA"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODENECEK_TAKSIT_NO"));
			stmt.setDate(i++, iMap.getDate("YENI_TAKSIT_TARIHI") == null ? null : new java.sql.Date(iMap.getDate("YENI_TAKSIT_TARIHI").getTime()));
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.registerOutParameter(i++, Types.NUMERIC); 
			
			stmt.execute();
			
			int siraNo = stmt.getInt(--i);
			rSet = (ResultSet)stmt.getObject(--i);
			
			BigDecimal toplamTaksitTutari = BigDecimal.ZERO;
			BigDecimal toplamAnapara = BigDecimal.ZERO;
			BigDecimal toplamFaiz = BigDecimal.ZERO;
			BigDecimal toplamKKDF = BigDecimal.ZERO;
			BigDecimal toplamBSMV = BigDecimal.ZERO;
			
			String tableName = "RESULTS";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "OP_TAKSIT_NO", siraNo++);
				oMap.put(tableName, row, "OP_TAKSIT_TARIHI", rSet.getDate(1));
				oMap.put(tableName, row, "OP_TAKSIT_TUTAR", rSet.getBigDecimal(2));
				toplamTaksitTutari = toplamTaksitTutari.add(rSet.getBigDecimal(2));
				oMap.put(tableName, row, "OP_ANAPARA", rSet.getBigDecimal(3));
				toplamAnapara = toplamAnapara.add(rSet.getBigDecimal(3));
				oMap.put(tableName, row, "OP_FAIZ", rSet.getBigDecimal(4));
				toplamFaiz = toplamFaiz.add(rSet.getBigDecimal(4));
				oMap.put(tableName, row, "OP_KKDF", rSet.getBigDecimal(5));
				toplamKKDF = toplamKKDF.add(rSet.getBigDecimal(5));
				oMap.put(tableName, row, "OP_BSMV", rSet.getBigDecimal(6));
				toplamBSMV = toplamBSMV.add(rSet.getBigDecimal(6));
				oMap.put(tableName, row, "OP_KALAN_TUTAR", rSet.getBigDecimal(7));
				farkFaizi = farkFaizi.add(rSet.getBigDecimal("OVERDUEINTEREST"));
				row++;
			}

			oMap.put("TOPLAM_TAKSIT_TUTARI", toplamTaksitTutari);
			oMap.put("TOPLAM_ANAPARA", toplamAnapara);
			oMap.put("TOPLAM_FAIZ", toplamFaiz);
			oMap.put("TOPLAM_KKDF", toplamKKDF);
			oMap.put("TOPLAM_BSMV", toplamBSMV);
			oMap.put("ILK_TAKSIT_TARIHI", oMap.get(tableName, 0 , "OP_TAKSIT_TARIHI"));
			oMap.put("FARK_FAIZI", farkFaizi.setScale(2, RoundingMode.HALF_UP));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_GET_ILK_TAKSIT_TARIH")
	public static GMMap getIlkTaksitTarih(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3133.ara_odeme_ilk_taksit_tarihi(?)}");
			stmt.registerOutParameter(1, Types.DATE); 
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			
			GMMap oMap = new GMMap();

			oMap.put("YENI_TAKSIT_TARIHI", stmt.getDate(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static <T> T nvl(T a, T b) {
		if (a instanceof String) {
			return StringUtils.isBlank((String) a)?b:a;
		}

		return a==null?b:a;
	}

	@GraymoundService("BNSPR_Q3137_GET_GERI_ODEME_ERKEN_KAPAMA")
	public static GMMap getGeriOdemeErkenKapama(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();
		try {
			/**
			 * Tarih kontrol�
			 */
			{
				Date bankaTarihi = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", null).getDate("BANKA_TARIH");
				tMap.put("TAKSIT_DURUM", StringUtils.isBlank(iMap.getString("TAKSIT_VADE_TARIHI")) ? false : bankaTarihi.compareTo(iMap.getDate("TAKSIT_VADE_TARIHI"))==0);
	
				if (tMap.getBoolean("TAKSIT_DURUM")) {
					tMap.putAll(GMServiceExecuter.call("BNSPR_GET_GERI_ODEME_TAKSIT_TAHSILAT", iMap));
				}
			}

			oMap.putAll(GMServiceExecuter.call("BNSPR_GET_GERI_ODEME_ERKEN_KAPAMA", iMap));

			/**
			 * E�er geri �deme taksit tahsilat hesaplanm��sa...
			 */
			{
				if (tMap.getBoolean("TAKSIT_DURUM")) {
					//tMap'te de erken kapama tutarlar� ekli old. i�in 2 kere eklemeden dolay� bir tanesi ��kar�l�yor.
					oMap.put("TAHSILAT_TUTARI", 	nvl(oMap.getBigDecimal("TAHSILAT_TUTARI"), 	BigDecimal.ZERO).subtract(nvl(oMap.getBigDecimal("ERKEN_KAPAMA_FAIZ"), BigDecimal.ZERO)));
					oMap.put("TAHSILAT_TUTARI", 	nvl(oMap.getBigDecimal("TAHSILAT_TUTARI"), 	BigDecimal.ZERO).subtract(nvl(oMap.getBigDecimal("ERKEN_KAPAMA_FAIZ_KKDF"), BigDecimal.ZERO)));
					oMap.put("TAHSILAT_TUTARI", 	nvl(oMap.getBigDecimal("TAHSILAT_TUTARI"), 	BigDecimal.ZERO).subtract(nvl(oMap.getBigDecimal("ERKEN_KAPAMA_FAIZ_BSMV"), BigDecimal.ZERO)));
					
					// Ayn� alanlar
					oMap.put("KUR_FARKI_KKDF", 			nvl(oMap.getBigDecimal("KUR_FARKI_KKDF"), 			BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("KUR_FARKI_KKDF"), BigDecimal.ZERO)));
					oMap.put("KUR_FARKI_BSMV", 			nvl(oMap.getBigDecimal("KUR_FARKI_BSMV"), 			BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("KUR_FARKI_BSMV"), BigDecimal.ZERO)));
					oMap.put("ERKEN_KAPAMA_FAIZ", 		nvl(oMap.getBigDecimal("ERKEN_KAPAMA_FAIZ"), 		BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("GECIKME_FAIZ"), BigDecimal.ZERO)));
					oMap.put("ERKEN_KAPAMA_FAIZ_KKDF", 	nvl(oMap.getBigDecimal("ERKEN_KAPAMA_FAIZ_KKDF"), 	BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("GECIKME_FAIZ_KKDF"), BigDecimal.ZERO)));
					oMap.put("ERKEN_KAPAMA_FAIZ_BSMV", 	nvl(oMap.getBigDecimal("ERKEN_KAPAMA_FAIZ_BSMV"), 	BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("GECIKME_FAIZ_BSMV"), BigDecimal.ZERO)));
					oMap.put("TAHSILAT_TUTARI", 		nvl(oMap.getBigDecimal("TAHSILAT_TUTARI"), 			BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("TAHSILAT_TUTARI"), BigDecimal.ZERO)));
					oMap.put("ANAPARA", 				nvl(oMap.getBigDecimal("ANAPARA"), 					BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("ANAPARA"), BigDecimal.ZERO)));
					oMap.put("GECIKME_FAIZ", 			nvl(oMap.getBigDecimal("GECIKME_FAIZ"), 			BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("GECIKME_FAIZ"), BigDecimal.ZERO)));

					// Farkl� alanlar
					oMap.put("TAKSIT_TUTARI", 				nvl(iMap.getBigDecimal("TAKSIT_TUTARI"), 			BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("TAKSIT_TUTARI"), BigDecimal.ZERO)));
					oMap.put("FAIZ", 						nvl(iMap.getBigDecimal("FAIZ"), 					BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("FAIZ"), BigDecimal.ZERO)));
					oMap.put("FAIZ_KKDF", 					nvl(iMap.getBigDecimal("FAIZ_KKDF"), 				BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("FAIZ_KKDF"), BigDecimal.ZERO)));
					oMap.put("FAIZ_BSMV", 					nvl(iMap.getBigDecimal("FAIZ_BSMV"), 				BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("FAIZ_BSMV"), BigDecimal.ZERO)));
					oMap.put("ERKEN_ODEME_FAIZ_INDIRIM", 	nvl(iMap.getBigDecimal("ERKEN_ODEME_FAIZ_INDIRIM"), BigDecimal.ZERO).add(nvl(tMap.getBigDecimal("ERKEN_ODEME_FAIZ_INDIRIM"), BigDecimal.ZERO)));

				} else {
					// yap�lmad�ysa birka� �nceki de�eri geri g�nder
					oMap.put("TAKSIT_TUTARI", 				nvl(iMap.getBigDecimal("TAKSIT_TUTARI"), 			BigDecimal.ZERO));
					oMap.put("FAIZ", 						nvl(iMap.getBigDecimal("FAIZ"), 					BigDecimal.ZERO));
					oMap.put("FAIZ_KKDF", 					nvl(iMap.getBigDecimal("FAIZ_KKDF"), 				BigDecimal.ZERO));
					oMap.put("FAIZ_BSMV", 					nvl(iMap.getBigDecimal("FAIZ_BSMV"), 				BigDecimal.ZERO));
					oMap.put("ERKEN_ODEME_FAIZ_INDIRIM", 	nvl(iMap.getBigDecimal("ERKEN_ODEME_FAIZ_INDIRIM"), BigDecimal.ZERO));
				}
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_Q3137_GECIKMEDE_TAKSIT_SAYISI")
	public static GMMap gecikmedeTaksitSayisi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_bireysel2.Gecikmede_Taksit_Sayi(?)}");
			stmt.registerOutParameter(1, Types.DECIMAL); 
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			
			BigDecimal taksitSayisi = stmt.getBigDecimal(1);

			oMap.put("TAKSIT_SAYISI", taksitSayisi);
			oMap.put("ERKEN_KAPAMA_GEC_KISMI_DAHIL", taksitSayisi.signum() > 0);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_CHECK_ILK_TAKSIT_TARIH")
	public static GMMap checkIlkTaksitTarih(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Date date = iMap.getDate("YENI_TAKSIT_TARIHI");

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3133.check_ilk_taksit_tarih(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(2, new java.sql.Date(date.getTime()));

			stmt.execute();

			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_CHECK_GECIKMEDE")
	public static GMMap checkGecikmede(GMMap iMap) {

		try {
			GMMap oMap=new GMMap();
			if (iMap.getDate("KAPAMA_YAPILMASI_ISTENEN_TARIH") != null){
			  if(iMap.getDate("TAKSIT_VADE")!=null && iMap.getDate("TAKSIT_VADE").before(iMap.getDate("KAPAMA_YAPILMASI_ISTENEN_TARIH"))){
				  oMap.put("GECIKMEDEMI", "1");
			  }else
			  {
				  oMap.put("GECIKMEDEMI", "0");
			  }
			}else{
			  if(iMap.getDate("TAKSIT_VADE")!=null && iMap.getDate("TAKSIT_VADE").before(iMap.getDate("BUGUN_TARIH"))){
			      oMap.put("GECIKMEDEMI", "1");
		      }else
		      {
				  oMap.put("GECIKMEDEMI", "0");
			  }
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
