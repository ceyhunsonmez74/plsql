package tr.com.calikbank.bnspr.consumerloan.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3186Services {
	@GraymoundService("BNSPR_QRY3186_GET_COMBOBOX_INITIAL_VALUE")
	public static GMMap getComboBoxInitialValues(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			iMap.put("KOD", "CALISMA_SEKLI_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("CALISMA_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BELGE_KONTROL_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BELGE_KONTROL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BIR_BELGE_HATA");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BELGE_HATA", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3186_GET_BELGE_LIST")
	public static GMMap getBelgeList(GMMap iMap) {
		try {
			String func = "{? = call PKG_RC3186.RC_QRY3186_GET_BELGE_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"), BnsprType.STRING, iMap.getString("KONTAKT_MUSTERI"), BnsprType.STRING, iMap.getString("BELGE_KONTROLU"), BnsprType.STRING, iMap.getString("CALISMA_TIPI"), BnsprType.STRING, iMap.getString("ORJINAL_EVRAK_MI"), BnsprType.DATE,
					iMap.getDate("BELGE_GELIS_TARIHI"), BnsprType.STRING, iMap.getString("DURUM"), BnsprType.DATE, iMap.getDate("BELGE_TAMAMLAMA_BAS_TAR"), BnsprType.DATE, iMap.getDate("BELGE_TAMAMLAMA_BIT_TAR"), BnsprType.STRING, iMap.getString("DOKUMAN_KOD"), BnsprType.DATE, iMap.getDate("BASVURU_BAS_TAR"), BnsprType.DATE, iMap.getDate("BASVURU_BIT_TAR"), BnsprType.STRING,
					iMap.getBoolean("IPTAL") ? "TRUE" : "FALSE", BnsprType.NUMBER, iMap.getBigDecimal("KREDI_TUR")};
			String tableName = "BELGE_LIST";
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
			int len = oMap.getSize(tableName);
			for (int i = 0; i < len; i++) {
				oMap.put(tableName, i, "KIMDEN_ACIKLAMA", LovHelper.diLov(oMap.get(tableName, i, "KIMDEN"), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
				oMap.put(tableName, i, "ORJINAL_EVRAK_MI", GuimlUtil.convertToCheckBoxValue(oMap.getString(tableName, i, "ORJINAL_EVRAK_MI")));
				String dosyaYol = oMap.getString(tableName, i, "DOSYA_YOL");
				if ((dosyaYol != null) && !dosyaYol.isEmpty()) {
					try {
						String dokumanAdi = dosyaYol;// oMap.getString(tableName, row,"DOSYA_YOL");
						dokumanAdi = dokumanAdi.substring(dokumanAdi.lastIndexOf("/") + 1, dokumanAdi.length());
						oMap.put(tableName, i, "URL", GMServiceExecuter.call("DYS_CMIS_GET_DOKUMAN_LINK_BY_FILENAME", new GMMap().put("DOKUMAN_ADI", dokumanAdi).put("DOKUMAN_CLASS", "Musteri")).getString("DOKUMAN_LINK"));
					}
					catch (Exception e) {
						// Hata alirsa butun islemi kesmesin
						e.printStackTrace();
					}
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3186_GET_BELGE_TARIHCE")
	public static GMMap getBelgeTarihce(GMMap iMap) {
		try {
			String func = "{? = call PKG_RC3186.belge_tarihce(?,?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, iMap.getString("DOKUMAN_KOD"), BnsprType.STRING, iMap.getString("KIMDEN") };
			GMMap oMap = new GMMap();
			String tableName = "BELGE_LIST";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3186_HOBIM_RANDOM_SAVE")
	public static GMMap saveHobimRandom(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3182_HOBIM_RANDOM_SAVE", iMap));
		return oMap;
	}
}
