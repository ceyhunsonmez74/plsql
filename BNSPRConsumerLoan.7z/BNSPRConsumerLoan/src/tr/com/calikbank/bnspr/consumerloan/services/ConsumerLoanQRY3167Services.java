package tr.com.calikbank.bnspr.consumerloan.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3167Services {
	
	@GraymoundService("BNSPR_QRY3167_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("KOD", "YETKI_SEVIYE_KOD");
		oMap.put("YETKI_SEVIYESI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "BAYI_RISK_KOD");
		oMap.put("BAYI_RISKI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "CAL_STATU_KOD");
		oMap.put("CALISAN_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "SATICI_TIP_KOD");
		oMap.put("SATICI_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "CAL_STATU_KOD");
		oMap.put("BAYI_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "CALISMA_SEKLI_KOD");
		oMap.put("BAYI_CALISMA_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("ORTAK_CALISAN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "BAGLI_OLD_BOLGE_KOD");
		oMap.put("BAGLI_OLDUGU_BOLGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "EVET_HAYIR");
		oMap.put("FAIZSIZ_FINANSMAN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
	}
	@GraymoundService("BNSPR_QRY3167_GET_SATICI_LIST")
	public static GMMap getList(GMMap iMap){		
		GMMap oMap = new GMMap();
		try{
			String func = "{? = call PKG_RC3167.RC_QRY3167_Satici_Bilgileri(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			Object[] inputValues = {
			   BnsprType.NUMBER, iMap.getBigDecimal("BAYI_KODU"),
			   BnsprType.STRING, iMap.getString("UNVAN"),
			   BnsprType.STRING, iMap.getString("TC_KIMLIK_NO"),
			   BnsprType.STRING, iMap.getString("VERGI_NO"),
			   BnsprType.STRING, iMap.getString("CALISMA_STATU"),
			   BnsprType.STRING, iMap.getString("YETKI_SEVIYESI"),
			   BnsprType.STRING, iMap.getString("KREDI_TURU"),
			   BnsprType.STRING, iMap.getString("BAGLI_OLDUGU_BOLGE"),
			   BnsprType.STRING, iMap.getString("SATICI_TIPI"),
			   BnsprType.STRING, iMap.getString("BAYI_STATU"),
			   BnsprType.STRING, iMap.getString("BAYI_RISKI"),
			   BnsprType.STRING, iMap.getString("CALISAN_STATU"),
			   BnsprType.NUMBER, iMap.getBigDecimal("ORJINAL_EVRAK_GONDERIM_SURESI"),
			   BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
			   BnsprType.NUMBER, iMap.getBigDecimal("HESAP_NO"),
			   BnsprType.STRING, iMap.getString("CALISAN_TC_KIMLIK_NO"),
			   BnsprType.STRING, iMap.getString("AD"),
			   BnsprType.STRING, iMap.getString("SOYAD"),
			   BnsprType.STRING, iMap.getString("CEP_TEL"),
			   BnsprType.STRING, iMap.getString("ORTAK_CALISAN"),
			   BnsprType.STRING, iMap.getString("FAIZSIZ_FINANSMAN"),
			};
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "SATICI_LIST", inputValues));	
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
