package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirMarkaModelPrTx;
import tr.com.calikbank.bnspr.dao.BirMarkaModelPrTxId;
import tr.com.calikbank.bnspr.dao.BirMarkaPrTx;
import tr.com.calikbank.bnspr.dao.BirMarkaPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3115Services {

	@GraymoundService("BNSPR_TRN3115_REPLACE_TURKISH_CHARS")
	public static GMMap replaceTurkishChars(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
	
			String marka_kod = iMap.getString("MARKA_KOD");
			marka_kod = marka_kod.toUpperCase();
			marka_kod = marka_kod.replace('�', 'I');
			marka_kod = marka_kod.replace('�', 'C');
			marka_kod = marka_kod.replace('�', 'S');
			marka_kod = marka_kod.replace('�', 'O');
			marka_kod = marka_kod.replace('�', 'G');
			marka_kod = marka_kod.replace('�', 'U');
//			marka_kod = marka_kod.replace('.', '');
//			marka_kod = marka_kod.replace('-', null);
//			marka_kod = marka_kod.replace('/', null);
//			marka_kod = marka_kod.replace(' ', null);

			oMap.put("MARKA_KOD", marka_kod);
	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3115_CHECK_MARKA_KOD")
	public static GMMap checkMarkaKod(GMMap iMap){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try{
			GMMap oMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
			
			String krd_tur = iMap.getString("KREDI_KOD");
			String marka_kod = iMap.getString("MARKA_KOD");

			StringBuffer query = new StringBuffer();
			query.append("SELECT ");
			query.append("COUNT(*) ");
			query.append("FROM ");
			query.append("BIR_MARKA_PR ");
			query.append("WHERE BIR_KRD_TUR = ? ");
			query.append("AND KOD = ? ");

			stmt = conn.prepareStatement(query.toString());

			stmt.setString(1, krd_tur);
			stmt.setString(2, marka_kod);

			rSet = stmt.executeQuery();
			
			oMap.put("AYNI_MARKA", "H");
			if(rSet.next()){
				if(rSet.getBigDecimal(1).compareTo(new BigDecimal(0)) > 0){
					oMap.put("AYNI_MARKA", "E");
					//throw new GMRuntimeException(0, "Mevcut olan markay� yeniden girmek istiyorsunuz. De�i�iklik yapmak i�in g�ncelleme yap�n�z.");
//						iMap.put("HATA_NO", new BigDecimal(716));
//						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3115_GET_COMBOBOX_INITIAL_VALUES")
	public static GMMap getComboboxInitialValues(GMMap iMap) {
		String listName = "DURUM";
		GuimlUtil.wrapMyCombo(iMap, listName, "G", "Ge�erli");
		GuimlUtil.wrapMyCombo(iMap, listName, "I", "�ptal");
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3115_GET_MODEL_KOD")
	public static GMMap trn3115GetModelKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			String marka_kod = iMap.getString("MARKA_KOD");

			StringBuffer query = new StringBuffer();
			query.append("SELECT ");
			query.append("KOD, ACIKLAMA, DRM AS DURUM ");
			query.append("FROM ");
			query.append("BIR_MARKA_MODEL_PR ");
			query.append("WHERE MARKA_KOD = ? ");
			query.append("ORDER BY KOD, ACIKLAMA");

			stmt = conn.prepareStatement(query.toString());

			stmt.setString(1, marka_kod);

			rSet = stmt.executeQuery();

			String tableName = "MODEL_TABLE";

			
			ArrayList<HashMap<String, Object>> modelList = new ArrayList<HashMap<String, Object>>();
			int row = 0;
			while (rSet.next()) {
				int i = 1;
				String curModel, modelKod;
				modelKod = rSet.getString(i++);
				oMap.put(tableName, row, "MODEL_KOD", modelKod);
				curModel = rSet.getString(i++);
				Boolean flag = true;
				for (Iterator<?> iterator = modelList.iterator(); iterator
						.hasNext();) {
					HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
					if (curModel.equals(rowData.get("MODEL").toString()))
						flag = false;
				}

				if (flag) {
					HashMap<String, Object> rowData = new HashMap<String, Object>();
					rowData.put("MODEL_KOD", modelKod);
					rowData.put("MODEL", curModel);
					modelList.add(rowData);
				}

				oMap.put(tableName, row, "MODEL", curModel);
				oMap.put(tableName, row, "DURUM", rSet.getString(i++));
				row++;
			}
			oMap.put("MODEL_LIST", modelList);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3115_SAVE_MARKA_MODEL")
	public static Map<?, ?> saveMarkaModel(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			if(iMap.getBigDecimal("KREDI_KOD") == null)
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kredi T�r�");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("MARKA_KOD") == null || iMap.getString("MARKA_KOD").isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Marka Kodu");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("MARKA_ADI") == null || iMap.getString("MARKA_ADI").isEmpty())
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Marka Ad�");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("DURUM") == null)
			{
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Durum");
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			BirMarkaPrTx birMarkaPrTx =  (BirMarkaPrTx) session.createCriteria(BirMarkaPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birMarkaPrTx == null)
				birMarkaPrTx = new BirMarkaPrTx(); 
			
			BirMarkaPrTxId id = new BirMarkaPrTxId();
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setBirKrdTur(iMap.getBigDecimal("KREDI_KOD"));
			id.setKod(iMap.getString("MARKA_KOD"));
			birMarkaPrTx.setId(id);
			birMarkaPrTx.setAciklama(iMap.getString("MARKA_ADI"));
			birMarkaPrTx.setDrm(iMap.getString("DURUM"));

			session.saveOrUpdate(birMarkaPrTx);

			String tableName = "MODEL_TABLE";
			List<?> list = (List<?>) iMap.get(tableName);

			for (int j = 0; j < list.size(); j++) {
				BirMarkaModelPrTx modelPrTx =  (BirMarkaModelPrTx) session.createCriteria(BirMarkaModelPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																													.add(Restrictions.eq("id.kod", iMap.getBigDecimal(tableName, j, "MODEL_KOD")))
																													.add(Restrictions.eq("id.markaKod", iMap.getString("MARKA_KOD")))
																													.add(Restrictions.eq("id.birKrdTur", iMap.getBigDecimal("KREDI_KOD")))
																													.uniqueResult();
				if (modelPrTx == null)
				{
					modelPrTx = new BirMarkaModelPrTx(); 
			
					BirMarkaModelPrTxId	id2 = new BirMarkaModelPrTxId();
					id2.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id2.setMarkaKod(iMap.getString("MARKA_KOD"));
					id2.setKod(iMap.getBigDecimal(tableName, j, "MODEL_KOD"));
					id2.setBirKrdTur(iMap.getBigDecimal("KREDI_KOD"));
					modelPrTx.setId(id2);
				}
				modelPrTx.setAciklama(iMap.getString(tableName, j, "MODEL"));
				modelPrTx.setDrm(iMap.getString(tableName, j, "DURUM"));

				session.saveOrUpdate(modelPrTx);
				session.flush();
			}

			session.flush();
			iMap.put("TRX_NAME", "3115");
			return GMServiceExecuter
					.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3115_GET_MARKA_INFO")
	public static GMMap trn3115GetMarkaInfo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		PreparedStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			
			String tx_no = iMap.getString("TRX_NO");
			
			StringBuffer query = new StringBuffer();
			query.append("select BIR_KRD_TUR, KOD, ACIKLAMA, DRM from bir_marka_pr_tx where tx_no = ?");
			
			stmt = conn.prepareStatement(query.toString());

			stmt.setString(1, tx_no);
			
			rSet = stmt.executeQuery();
			
			if(rSet.next()){
				oMap.put("KREDI_KOD", rSet.getBigDecimal("BIR_KRD_TUR"));
				oMap.put("KREDI_TURU", LovHelper.diLov(rSet.getBigDecimal("BIR_KRD_TUR"), "3115/LOV_KREDI_TURU","KREDI_TURU"));
				oMap.put("MARKA_KOD", rSet.getString("KOD"));
				oMap.put("DF_MARKA_KOD", rSet.getString("KOD"));
				oMap.put("TF_MARKA_KOD", rSet.getString("KOD"));
				oMap.put("MARKA_ADI", rSet.getString("ACIKLAMA"));
				oMap.put("DURUM", rSet.getString("DRM"));

				StringBuffer query2 = new StringBuffer();
				query2.append("select kod, aciklama, drm from bir_marka_model_pr_tx where tx_no = ? and marka_kod = ? and bir_krd_tur = ? and (sil is null or sil <> 'E')");
				
				stmt2 = conn.prepareStatement(query2.toString());

				stmt2.setString(1, tx_no);
				stmt2.setString(2, rSet.getString("KOD"));
				stmt2.setString(3, rSet.getBigDecimal("BIR_KRD_TUR").toString());
				
				rSet2 = stmt2.executeQuery();
				
				String tableName = "MODEL_TABLE";
				int row = 0;
				while (rSet2.next()) {
					oMap.put(tableName, row, "MODEL_KOD", rSet2.getBigDecimal("KOD"));
					oMap.put(tableName, row, "MODEL", rSet2.getString("ACIKLAMA"));
					oMap.put(tableName, row, "DURUM", rSet2.getString("DRM"));
					
					row++;
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}
}
