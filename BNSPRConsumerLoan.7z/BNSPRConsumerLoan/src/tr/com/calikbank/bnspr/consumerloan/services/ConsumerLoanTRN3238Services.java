package tr.com.calikbank.bnspr.consumerloan.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipAdrTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipAdrTxId;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTelTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTelTxId;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTx;
import tr.com.aktifbank.bnspr.dao.BirKrediHesapTakipTxId;
import tr.com.aktifbank.bnspr.dao.KkbVefatRisk;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3238Services {
	
	
	@GraymoundService("BNSPR_TRN3238_GET_KREDI_BILGILERI")
	public static GMMap getKrediBilgileri(GMMap iMap){
		Connection 			conn 		= null;
		CallableStatement 	stmt 		= null;
		ResultSet 			rSetKredi 	= null;
		ResultSet 			rSetGorus 	= null;
		ResultSet 			rSetTel 	= null;
		ResultSet 			rSetAdr 	= null;
		ResultSet 			rSetArama 	= null;
		GMMap				oMap		= new GMMap();
		try{
			Session session = DAOSession.getSession("BNSPRDal");	
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3196.get_kredi_bilgileri(?,?,?,?,?,?)}");
			int i =1;	
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_HESAP_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSetKredi = (ResultSet)stmt.getObject(2);
			rSetGorus = (ResultSet)stmt.getObject(3);
			rSetTel= (ResultSet)stmt.getObject(4);
			rSetAdr = (ResultSet)stmt.getObject(5);
			rSetArama = (ResultSet)stmt.getObject(6);

			while (rSetGorus.next()) {
				GuimlUtil.wrapMyCombo(oMap, "TAHSIS_GORUS_LIST", null, rSetGorus.getString(1));
			}			
			
			oMap.putAll(DALUtil.rSetMap(rSetKredi));
            oMap.put("TAHSILAT_YAPILAMAZ", oMap.getString("TAHSILAT_YAPILAMAZ")==null?false:(oMap.getString("TAHSILAT_YAPILAMAZ").equalsIgnoreCase("E")?true:false));
            oMap.put("BAYIDEN_KAPATILACAK", oMap.getString("BAYIDEN_KAPATILACAK")==null?false:(oMap.getString("BAYIDEN_KAPATILACAK").equalsIgnoreCase("E")?true:false));
            oMap.put("YENIDEN_YAP_EH", oMap.getString("YENIDEN_YAP_EH")==null?false:(oMap.getString("YENIDEN_YAP_EH").equalsIgnoreCase("E")?true:false));
            oMap.put("YTS_YENIDEN_YAP_EH", oMap.getString("YTS_YENIDEN_YAP_EH")==null?false:(oMap.getString("YTS_YENIDEN_YAP_EH").equalsIgnoreCase("E")?true:false));
            oMap.put("OTO_YASAL_TAKIP", oMap.getString("OTO_YASAL_TAKIP")==null?false:(oMap.getString("OTO_YASAL_TAKIP").equalsIgnoreCase("E")?true:false));
			oMap.put("FPD", oMap.getString("FPD") == null ? false : (oMap.getString("FPD").equalsIgnoreCase("E") ? true : false));
			oMap.put("ILK_KEZ_GECIKME_MI", oMap.getString("ILK_KEZ_GECIKME_MI") == null ? false : (oMap.getString("ILK_KEZ_GECIKME_MI").equalsIgnoreCase("E") ? true : false));
			if("Y".equals(oMap.getString("FRAUD_NEDEN_KOD")) || "".equals(oMap.getString("FRAUD_NEDEN_KOD")))
				oMap.put("FRAUD_VAR_MI", false);
			else
				oMap.put("FRAUD_VAR_MI", true);
			
            List<?> list =  session.createCriteria(KkbVefatRisk.class).add(Restrictions.eq("id.tckn", oMap.getString("TCKN"))).list();
            if(list.size()>0) {
            	oMap.put("KKB_VEFAT", true); 
            } else {
            	oMap.put("KKB_VEFAT", false);
            }
			String aramaNedeni = oMap.getString("ARAMA_NEDENI");
			if(aramaNedeni != null && aramaNedeni.length()==13){
				if(aramaNedeni.charAt(0) == '1'){
					oMap.put("GECIKMEDE", true);
				}else{
					oMap.put("GECIKMEDE", false);
				}
				if(aramaNedeni.charAt(1) == '1'){
					oMap.put("EMEKLI_MAASINI_AKTARMIS", true);
				}else{
					oMap.put("EMEKLI_MAASINI_AKTARMIS", false);
				}
				if(aramaNedeni.charAt(2) == '1'){
					oMap.put("TEMINAT", true);
				}else{
					oMap.put("TEMINAT", false);
				}
				if(aramaNedeni.charAt(3) == '1'){
					oMap.put("E_HACIZ", true);
				}else{
					oMap.put("E_HACIZ", false);
				}
				if(aramaNedeni.charAt(4) == '1'){
					oMap.put("VEFAT", true);
				}else{
					oMap.put("VEFAT", false);
				}
				if(aramaNedeni.charAt(5) == '1'){
					oMap.put("TAKSIT_TARIHI_ERTELEME", true);
				}else{
					oMap.put("TAKSIT_TARIHI_ERTELEME", false);
				}	
				if(aramaNedeni.charAt(6) == '1'){
					oMap.put("MAASI_KESILMIS", true);
				}else{
					oMap.put("MAASI_KESILMIS", false);
				}
				if(aramaNedeni.charAt(7) == '1'){
					oMap.put("KAYIP_MUSTERI", true);
				}else{
					oMap.put("KAYIP_MUSTERI", false);
				}
				if(aramaNedeni.charAt(8) == '1'){
					oMap.put("IADE_ISTENDI", true);
				}else{
					oMap.put("IADE_ISTENDI", false);
				}
				if(aramaNedeni.charAt(8) == '1'){
					oMap.put("IADE_ISTENDI", true);
				}else{
					oMap.put("IADE_ISTENDI", false);
				}
				if(aramaNedeni.charAt(9) == '1'){
					oMap.put("HAREKETSIZ_HESAP", true);
				}else{
					oMap.put("HAREKETSIZ_HESAP", false);
				}
				if(aramaNedeni.charAt(10) == '1'){
					oMap.put("YENIDEN_YAPILANDIRMA", true);
				}else{
					oMap.put("YENIDEN_YAPILANDIRMA", false);
				}
				if(aramaNedeni.charAt(11) == '1'){
					oMap.put("HIC_ULASILAMADI", true);
				}else{
					oMap.put("HIC_ULASILAMADI", false);
				}
				if(aramaNedeni.charAt(12) == '1'){
					oMap.put("BASKA_BANKA_KREDISI_VAR", true);
				}else{
					oMap.put("BASKA_BANKA_KREDISI_VAR", false);
				}
			}else{
				oMap.put("GECIKMEDE", false);
				oMap.put("EMEKLI_MAASINI_AKTARMIS", false);
				oMap.put("TEMINAT", false);
				oMap.put("E_HACIZ", false);
				oMap.put("VEFAT", false);
				oMap.put("TAKSIT_TARIHI_ERTELEME", false);
				oMap.put("MAASI_KESILMIS", false);
				oMap.put("KAYIP_MUSTERI", false);
				oMap.put("IADE_ISTENDI", false);
				oMap.put("HAREKETSIZ_HESAP", false);
				oMap.put("YENIDEN_YAPILANDIRMA", false);
				oMap.put("HIC_ULASILAMADI", false);
				oMap.put("BASKA_BANKA_KREDISI_VAR", false);
			}
			oMap.putAll(DALUtil.rSetResults(rSetTel,"TEL_LIST"));
			for(int k=0;k<oMap.getSize("TEL_LIST");k++){
				oMap.put("TEL_LIST",k,"T_SIRA_NO","T"+oMap.getString("TEL_LIST",k,"SIRA_NO"));
				oMap.put("TEL_LIST",k,"KENDINE_MI_AIT", "E".equals(oMap.getString("TEL_LIST", k, "KENDINE_MI_AIT")));
			}
			oMap.put("TEL_COUNT", oMap.getSize("TEL_LIST"));
			
			oMap.putAll(DALUtil.rSetResults(rSetAdr,"ADR_LIST"));
			for(int k=0;k<oMap.getSize("ADR_LIST");k++){
				oMap.put("ADR_LIST",k,"A_SIRA_NO","A"+oMap.getString("ADR_LIST",k,"SIRA_NO"));
			}
			oMap.put("ADR_COUNT", oMap.getSize("ADR_LIST"));
			
			oMap.putAll(DALUtil.rSetResults(rSetArama,"ARAMA_LIST"));
			
			/* Son G�ncelleme Gerek�esi */
            stmt = conn.prepareCall("{? = call PKG_TRN3199.Son_Guncelleme_Gerekcesi(?)}");
            stmt.registerOutParameter(1 , Types.VARCHAR);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("BASVURU_NO"));
            stmt.execute();
            
            oMap.put("SON_ISLEM_GEREKCE", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSetKredi);
			GMServerDatasource.close(rSetGorus);
			GMServerDatasource.close(rSetTel);
			GMServerDatasource.close(rSetAdr);
			GMServerDatasource.close(rSetArama);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN3238_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");	
			
			String aramaNedeni = "";
			if(iMap.getBoolean("GECIKMEDE")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			if(iMap.getBoolean("EMEKLI_MAASINI_AKTARMIS")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			if(iMap.getBoolean("TEMINAT")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			if(iMap.getBoolean("E_HACIZ")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			if(iMap.getBoolean("VEFAT")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			if(iMap.getBoolean("TAKSIT_TARIHI_ERTELEME")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}		
			if(iMap.getBoolean("MAASI_KESILMIS")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			if(iMap.getBoolean("KAYIP_MUSTERI")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			if(iMap.getBoolean("IADE_ISTENDI")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			if(iMap.getBoolean("HAREKETSIZ_HESAP")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}if(iMap.getBoolean("YENIDEN_YAPILANDIRMA")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}if(iMap.getBoolean("HIC_ULASILAMADI")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}if(iMap.getBoolean("BASKA_BANKA_KREDISI_VAR")){
				aramaNedeni += "1";
			}else{
				aramaNedeni += "0";
			}
			
			
			BirKrediHesapTakipTx birKrediHesapTakipTx = new BirKrediHesapTakipTx();
			BirKrediHesapTakipTxId id = new BirKrediHesapTakipTxId();

			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setKrdHesapNo(iMap.getBigDecimal("KRD_HESAP_NO"));
			birKrediHesapTakipTx.setId(id);
			
			birKrediHesapTakipTx.setAciklama(iMap.getString("ACIKLAMA"));
			birKrediHesapTakipTx.setHesapDurumKodu(iMap.getString("HESAP_DURUMU"));
			birKrediHesapTakipTx.setIhtarnameTarihi(iMap.getDate("IHTARNAME_TARIHI"));
			birKrediHesapTakipTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESAP_NO"));
			birKrediHesapTakipTx.setOncekiHesapDurum(iMap.getString("ONCEKI_HESAP_DURUM"));
			birKrediHesapTakipTx.setTakipHesapNo(iMap.getBigDecimal("TAKIP_HESAP_NO"));
			birKrediHesapTakipTx.setVefatTarihi(iMap.getDate("VEFAT_TARIHI"));
			birKrediHesapTakipTx.setHesapKapatilsinMi(iMap.getString("HESAP_KAPATILSIN_MI") != null ? "E" : "H");
			birKrediHesapTakipTx.setSonGorusmeDurum(iMap.getString("SON_GORUSME_DURUM"));
			birKrediHesapTakipTx.setAramaNedeni(aramaNedeni);
			birKrediHesapTakipTx.setMektup1Tarih(iMap.getDate("MEKTUP_1_TARIH"));
			birKrediHesapTakipTx.setMektup1GeriTarih(iMap.getDate("MEKTUP_1_GERI_TARIH"));
            birKrediHesapTakipTx.setTahsilatYapilamaz(iMap.getBoolean("TAHSILAT_YAPILAMAZ")?"E":"H");
            birKrediHesapTakipTx.setBayidenKapatilacak(iMap.getBoolean("BAYIDEN_KAPATILACAK")?"E":"H");
			birKrediHesapTakipTx.setMektup2Tarih(iMap.getDate("MEKTUP_2_TARIH"));
			birKrediHesapTakipTx.setMektup2GeriTarih(iMap.getDate("MEKTUP_2_GERI_TARIH"));
			birKrediHesapTakipTx.setMaasProblemi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("MAAS_PROBLEMI")));
			birKrediHesapTakipTx.setFirmaAramasi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("FIRMA_ARAMASI")));
			birKrediHesapTakipTx.setBayidenKapatilacak(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("BAYIDEN_KAPATILACAK"))); 
			birKrediHesapTakipTx.setYenidenYapEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("YENIDEN_YAP_EH")));
			birKrediHesapTakipTx.setYtsYenidenYapEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("YTS_YENIDEN_YAP_EH")));
			birKrediHesapTakipTx.setOtoYasalTakipIstisna(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("OTO_YASAL_TAKIP")));
			if("E".equals(iMap.getString("HESAP_KAPATILSIN_MI")))
			{
				GMMap nMap = new GMMap();
				nMap.put("HESAP_NO", iMap.getBigDecimal("KRD_HESAP_NO"));
				GMMap mMap = new GMMap();
				mMap.putAll(GMServiceExecuter.execute("BNSPR_GET_DEFTER_BAKIYESI", nMap));
				birKrediHesapTakipTx.setKapamaBakiyesi(mMap.getBigDecimal("DEFTER_BAKIYE").abs());
			}
			session.saveOrUpdate(birKrediHesapTakipTx);
			
			session.flush();
			
			for(int i=0;i<iMap.getSize("TEL_LIST");i++){
				if("".equals(iMap.getString("TEL_LIST",i,"YAKIN_ACIKLAMA"))){
					String nuLL = null;
					iMap.put("TEL_LIST",i,"YAKIN_ACIKLAMA",nuLL);
				}
				if(iMap.getBoolean("TEL_LIST",i,"KENDINE_MI_AIT")){
					if(iMap.getString("TEL_LIST",i,"YAKIN_ACIKLAMA")!=null){
						GMMap sMap = new GMMap();
						sMap.put("HATA_NO", "2068");
						sMap.put("P1", "Kendisine ait");
						sMap.put("P2", "kime ait");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
					}
				}
			}			
			
			List<BirKrediHesapTakipTelTx> birKrediHesapTakipTelTxList = (List<BirKrediHesapTakipTelTx>)session.createCriteria(BirKrediHesapTakipTelTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			if(birKrediHesapTakipTelTxList!=null&&birKrediHesapTakipTelTxList.size()>0){
				for(int i=0;i<birKrediHesapTakipTelTxList.size();i++){
					session.delete(birKrediHesapTakipTelTxList.get(i));
				}
				session.flush();
			}

				for(int k=0;k<iMap.getSize("TEL_LIST");k++){
						BirKrediHesapTakipTelTxId birKrediHesapTakipTelIdTx = new BirKrediHesapTakipTelTxId();
						BirKrediHesapTakipTelTx birKrediHesapTakipTelTx = new BirKrediHesapTakipTelTx();
						birKrediHesapTakipTelIdTx.setSiraNo(iMap.getBigDecimal("TEL_LIST",k,"SIRA_NO"));
						birKrediHesapTakipTelIdTx.setKrdHesapNo(iMap.getBigDecimal("TEL_LIST",k,"KRD_HESAP_NO"));
						birKrediHesapTakipTelIdTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birKrediHesapTakipTelTx.setId(birKrediHesapTakipTelIdTx);
						birKrediHesapTakipTelTx.setKendineMiAit(iMap.getBoolean("TEL_LIST",k,"KENDINE_MI_AIT") ? "E" : "H");
						birKrediHesapTakipTelTx.setSil(iMap.getBoolean("TEL_LIST", k, "SIL") ? "E" : "H");
						birKrediHesapTakipTelTx.setTelAlanKod(iMap.getString("TEL_LIST",k,"TEL_ALAN_KOD"));
						birKrediHesapTakipTelTx.setTelNo(iMap.getString("TEL_LIST",k,"TEL_NO"));
						birKrediHesapTakipTelTx.setTelTip(iMap.getString("TEL_LIST",k,"TEL_TIP"));
						birKrediHesapTakipTelTx.setYakinAciklama(iMap.getString("TEL_LIST",k,"YAKIN_ACIKLAMA"));
						session.saveOrUpdate(birKrediHesapTakipTelTx);
			}
			
			session.flush();
			
			
			List<BirKrediHesapTakipAdrTx> birKrediHesapTakipAdrTxList = (List<BirKrediHesapTakipAdrTx>)session.createCriteria(BirKrediHesapTakipAdrTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			if(birKrediHesapTakipAdrTxList!=null&&birKrediHesapTakipAdrTxList.size()>0){
				for(int i=0;i<birKrediHesapTakipAdrTxList.size();i++){
					session.delete(birKrediHesapTakipAdrTxList.get(i));
				}
				session.flush();
			}
	
				for(int k=0;k<iMap.getSize("ADR_LIST");k++){
						BirKrediHesapTakipAdrTxId birKrediHesapTakipAdrIdTx = new BirKrediHesapTakipAdrTxId();
						BirKrediHesapTakipAdrTx birKrediHesapTakipAdrTx = new BirKrediHesapTakipAdrTx();
						birKrediHesapTakipAdrIdTx.setSiraNo(iMap.getBigDecimal("ADR_LIST",k,"SIRA_NO"));
						birKrediHesapTakipAdrIdTx.setKrdHesapNo(iMap.getBigDecimal("ADR_LIST",k,"KRD_HESAP_NO"));
						birKrediHesapTakipAdrIdTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birKrediHesapTakipAdrTx.setId(birKrediHesapTakipAdrIdTx);
						birKrediHesapTakipAdrTx.setAdresKod(iMap.getString("ADR_LIST",k,"ADRES_KOD"));
						birKrediHesapTakipAdrTx.setAdres(iMap.getString("ADR_LIST",k,"ADRES"));
						birKrediHesapTakipAdrTx.setSil(iMap.getBoolean("ADR_LIST", k, "SIL") ? "E" : "H");
						session.saveOrUpdate(birKrediHesapTakipAdrTx);
					   
				}
					
			session.flush();
			
			iMap.put("TRX_NAME", "3238");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3238_GET_INFO")
	public static Map<?, ?> getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");			
			
			BirKrediHesapTakipTx birKrediHesapTakipTx = (BirKrediHesapTakipTx)session.createCriteria(BirKrediHesapTakipTx.class)
														.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
														.uniqueResult();
			
			oMap.put("ACIKLAMA"				, birKrediHesapTakipTx.getAciklama());//GORUS
			oMap.put("HESAP_DURUMU"			, birKrediHesapTakipTx.getHesapDurumKodu());
			oMap.put("IHTARNAME_TARIHI"		, birKrediHesapTakipTx.getIhtarnameTarihi());
			oMap.put("KRD_HESAP_NO"			, birKrediHesapTakipTx.getId().getKrdHesapNo());
			oMap.put("MASRAF_HESAP_NO"		, birKrediHesapTakipTx.getMasrafHesapNo());
			oMap.put("ONCEKI_HESAP_DURUM"	, birKrediHesapTakipTx.getOncekiHesapDurum());
			oMap.put("TAKIP_HESAP_NO"		, birKrediHesapTakipTx.getTakipHesapNo());
			oMap.put("SON_GORUSME_DURUM"	, birKrediHesapTakipTx.getSonGorusmeDurum());
			oMap.put("ARAMA_NEDENI"			, birKrediHesapTakipTx.getAramaNedeni());
			oMap.put("VEFAT_TARIHI"			, birKrediHesapTakipTx.getVefatTarihi());
			oMap.put("MEKTUP_1_TARIH"		, birKrediHesapTakipTx.getMektup1Tarih());
            oMap.put("MEKTUP_1_GERI_TARIH"  , birKrediHesapTakipTx.getMektup1GeriTarih());
            oMap.put("TAHSILAT_YAPILAMAZ"  , birKrediHesapTakipTx.getTahsilatYapilamaz().equalsIgnoreCase("E")?true:false);
			oMap.put("MEKTUP_2_TARIH"		, birKrediHesapTakipTx.getMektup2Tarih());
			oMap.put("MEKTUP_2_GERI_TARIH"	, birKrediHesapTakipTx.getMektup2GeriTarih());
			oMap.put("MAAS_PROBLEMI"		, GuimlUtil.convertToCheckBoxSelected(birKrediHesapTakipTx.getMaasProblemi()));
			oMap.put("FIRMA_ARAMASI"		, GuimlUtil.convertToCheckBoxSelected(birKrediHesapTakipTx.getFirmaAramasi()));
			oMap.put("BAYIDEN_KAPATILACAK", birKrediHesapTakipTx.getBayidenKapatilacak().equalsIgnoreCase("E")?true:false);
			oMap.put("YENIDEN_YAP_EH"		, GuimlUtil.convertToCheckBoxSelected(birKrediHesapTakipTx.getYenidenYapEh()));
			oMap.put("YTS_YENIDEN_YAP_EH"		, GuimlUtil.convertToCheckBoxSelected(birKrediHesapTakipTx.getYtsYenidenYapEh()));
			oMap.put("OTO_YASAL_TAKIP"		, GuimlUtil.convertToCheckBoxSelected(birKrediHesapTakipTx.getOtoYasalTakipIstisna()));
			
			
			List<BirKrediHesapTakipTelTx> birKrediHesapTakipTelTxList = (List<BirKrediHesapTakipTelTx>)session.createCriteria(BirKrediHesapTakipTelTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			BigDecimal maxSiraNo = BigDecimal.ZERO;
			if(birKrediHesapTakipTelTxList!=null&&birKrediHesapTakipTelTxList.size()>0){
				for(int i=0;i<birKrediHesapTakipTelTxList.size();i++){
					oMap.put("TEL_LIST", i, "SIRA_NO", birKrediHesapTakipTelTxList.get(i).getId().getSiraNo());
					oMap.put("TEL_LIST", i, "T_SIRA_NO", "T"+birKrediHesapTakipTelTxList.get(i).getId().getSiraNo());
					oMap.put("TEL_LIST", i, "KRD_HESAP_NO", birKrediHesapTakipTelTxList.get(i).getId().getKrdHesapNo());
					oMap.put("TEL_LIST", i, "KENDINE_MI_AIT", "E".equals(birKrediHesapTakipTelTxList.get(i).getKendineMiAit()));					
					oMap.put("TEL_LIST", i, "TEL_ALAN_KOD", birKrediHesapTakipTelTxList.get(i).getTelAlanKod());
					oMap.put("TEL_LIST", i, "TEL_NO", birKrediHesapTakipTelTxList.get(i).getTelNo());
					oMap.put("TEL_LIST", i, "TEL_TIP", birKrediHesapTakipTelTxList.get(i).getTelTip());
					oMap.put("TEL_LIST", i, "YAKIN_ACIKLAMA", birKrediHesapTakipTelTxList.get(i).getYakinAciklama());
					oMap.put("TEL_LIST", i, "SIL", birKrediHesapTakipTelTxList.get(i).getSil().equals("E") ? true : false);
					if(birKrediHesapTakipTelTxList.get(i).getId().getSiraNo().compareTo(maxSiraNo)>0) maxSiraNo = birKrediHesapTakipTelTxList.get(i).getId().getSiraNo();
				}
				
			}
			oMap.put("TEL_SIRA_NO", maxSiraNo);
			
			List<BirKrediHesapTakipAdrTx> birKrediHesapTakipAdrTxList = (List<BirKrediHesapTakipAdrTx>)session.createCriteria(BirKrediHesapTakipAdrTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			maxSiraNo = BigDecimal.ZERO;
			if(birKrediHesapTakipAdrTxList!=null&&birKrediHesapTakipAdrTxList.size()>0){
				for(int i=0;i<birKrediHesapTakipAdrTxList.size();i++){
					oMap.put("ADR_LIST", i, "SIRA_NO", birKrediHesapTakipAdrTxList.get(i).getId().getSiraNo());
					oMap.put("ADR_LIST", i, "A_SIRA_NO", "A"+birKrediHesapTakipAdrTxList.get(i).getId().getSiraNo());
					oMap.put("ADR_LIST", i, "KRD_HESAP_NO", birKrediHesapTakipAdrTxList.get(i).getId().getKrdHesapNo());				
					oMap.put("ADR_LIST", i, "ADRES_KOD", birKrediHesapTakipAdrTxList.get(i).getAdresKod());
					oMap.put("ADR_LIST", i, "ADRES", birKrediHesapTakipAdrTxList.get(i).getAdres());
					oMap.put("ADR_LIST", i, "SIL", birKrediHesapTakipAdrTxList.get(i).getSil().equals("E") ? true : false);
					if(birKrediHesapTakipAdrTxList.get(i).getId().getSiraNo().compareTo(maxSiraNo)>0) maxSiraNo = birKrediHesapTakipAdrTxList.get(i).getId().getSiraNo();
				}
				
			}
			oMap.put("ADR_SIRA_NO", maxSiraNo);			
			
			String aramaNedeni = oMap.getString("ARAMA_NEDENI");
			if(aramaNedeni != null && aramaNedeni.length()==13){
				if(aramaNedeni.charAt(0) == '1'){
					oMap.put("GECIKMEDE", true);
				}else{
					oMap.put("GECIKMEDE", false);
				}
				if(aramaNedeni.charAt(1) == '1'){
					oMap.put("EMEKLI_MAASINI_AKTARMIS", true);
				}else{
					oMap.put("EMEKLI_MAASINI_AKTARMIS", false);
				}
				if(aramaNedeni.charAt(2) == '1'){
					oMap.put("TEMINAT", true);
				}else{
					oMap.put("TEMINAT", false);
				}
				if(aramaNedeni.charAt(3) == '1'){
					oMap.put("E_HACIZ", true);
				}else{
					oMap.put("E_HACIZ", false);
				}
				if(aramaNedeni.charAt(4) == '1'){
					oMap.put("VEFAT", true);
				}else{
					oMap.put("VEFAT", false);
				}
				if(aramaNedeni.charAt(5) == '1'){
					oMap.put("TAKSIT_TARIHI_ERTELEME", true);
				}else{
					oMap.put("TAKSIT_TARIHI_ERTELEME", false);
				}	
				if(aramaNedeni.charAt(6) == '1'){
					oMap.put("MAASI_KESILMIS", true);
				}else{
					oMap.put("MAASI_KESILMIS", false);
				}
				if(aramaNedeni.charAt(7) == '1'){
					oMap.put("KAYIP_MUSTERI", true);
				}else{
					oMap.put("KAYIP_MUSTERI", false);
				}
				if(aramaNedeni.charAt(8) == '1'){
					oMap.put("IADE_ISTENDI", true);
				}else{
					oMap.put("IADE_ISTENDI", false);
				}
				if(aramaNedeni.charAt(9) == '1'){
					oMap.put("HAREKETSIZ_HESAP", true);
				}else{
					oMap.put("HAREKETSIZ_HESAP", false);
				}
				if(aramaNedeni.charAt(10) == '1'){
					oMap.put("YENIDEN_YAPILANDIRMA", true);
				}else{
					oMap.put("YENIDEN_YAPILANDIRMA", false);
				}
				if(aramaNedeni.charAt(11) == '1'){
					oMap.put("HIC_ULASILAMADI", true);
				}else{
					oMap.put("HIC_ULASILAMADI", false);
				}
				if(aramaNedeni.charAt(12) == '1'){
					oMap.put("BASKA_BANKA_KREDISI_VAR", true);
				}else{
					oMap.put("BASKA_BANKA_KREDISI_VAR", false);
				}
			}else{
				oMap.put("GECIKMEDE", false);
				oMap.put("EMEKLI_MAASINI_AKTARMIS", false);
				oMap.put("TEMINAT", false);
				oMap.put("E_HACIZ", false);
				oMap.put("VEFAT", false);
				oMap.put("TAKSIT_TARIHI_ERTELEME", false);
				oMap.put("MAASI_KESILMIS", false);
				oMap.put("KAYIP_MUSTERI", false);
				oMap.put("IADE_ISTENDI", false);
				oMap.put("HAREKETSIZ_HESAP", false);
				oMap.put("YENIDEN_YAPILANDIRMA", false);
				oMap.put("HIC_ULASILAMADI", false);
				oMap.put("BASKA_BANKA_KREDISI_VAR", false);
			}
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	} 
	@GraymoundService("BNSPR_TRN3238_NUMBER_TEL_LIST")
    public static GMMap numberTelList(GMMap iMap){
	    String tableName = "TEL_LIST";
	    int j= 1;
	    for (int i = 0; i<iMap.getSize(tableName); i++){
	        if(!iMap.getBoolean(tableName, i, "SIL")){
	            iMap.put(tableName, i, "T_SIRA_NO", "T"+j);
	            iMap.put(tableName,i,"SIRA_NO", j);
	            j++;
	        }
	    }
	    for (int i = 0; i<iMap.getSize(tableName); i++){
            if(iMap.getBoolean(tableName, i, "SIL")){
                iMap.put(tableName, i, "T_SIRA_NO", "T"+j);
                iMap.put(tableName,i,"SIRA_NO", j);
                j++;
            }
        }
        return iMap;
	}
	@GraymoundService("BNSPR_TRN3238_NUMBER_ADR_LIST")
    public static GMMap numberAdrList(GMMap iMap){
        String tableName = "ADR_LIST";
        int j= 1;
        for (int i = 0; i<iMap.getSize(tableName); i++){
            if(!iMap.getBoolean(tableName, i, "SIL")){
                iMap.put(tableName, i, "A_SIRA_NO", "A"+j);
                iMap.put(tableName,i,"SIRA_NO", j);
                j++;
            }
        }
        for (int i = 0; i<iMap.getSize(tableName); i++){
            if(iMap.getBoolean(tableName, i, "SIL")){
                iMap.put(tableName, i, "A_SIRA_NO", "A"+j);
                iMap.put(tableName,i,"SIRA_NO", j);
                j++;
            }
        }
        return iMap;
    }
	
	@GraymoundService("BNSPR_TRN3238_GET_DIFFERENCES")
	public static GMMap get3238Differences(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3238.RC_3238_FARK_DATA(?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			Color differentBackground = new Color(255,255,128);
			Color defaultBackground = new Color(238,238,238);
			GMMap oMap = new GMMap();
			int row = 0;
			if (rSet.next()) {
				ResultSetMetaData rs = rSet.getMetaData();
				for (int c = 1; c <= rs.getColumnCount(); c++){
					oMap.put(rs.getColumnName(c), rSet.getObject(c));
					if(rs.getColumnName(c).endsWith("FARKLI")){
						if(rSet.getString(c).equals("1")){
							oMap.put(rs.getColumnName(c).substring(0,rs.getColumnName(c).lastIndexOf("_")), differentBackground);
						}else {
							oMap.put(rs.getColumnName(c).substring(0,rs.getColumnName(c).lastIndexOf("_")), defaultBackground);
						}
					}
				}
				row++;
			}
						
			oMap.put("ROW_COUNT", row);
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
}
