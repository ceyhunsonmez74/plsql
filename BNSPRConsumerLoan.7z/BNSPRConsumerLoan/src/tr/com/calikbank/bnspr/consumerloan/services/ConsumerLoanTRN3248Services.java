 package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirTesvikSaticiistisnaTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikSaticiistisnaTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class ConsumerLoanTRN3248Services {

    @GraymoundService("BNSPR_TRN3248_GET_RECORDS")
        public static GMMap getTransactionNo(GMMap iMap) {
            
            GMMap oMap = new GMMap();
            Connection conn = null;
            CallableStatement stmt = null;
            ResultSet rSet = null;
            String tableName = "TBL_TESVIK_SATICI_ISTISNA";
         
            try{
                conn = DALUtil.getGMConnection();
                stmt = conn.prepareCall("{? = call PKG_TRN3248.get_records(?)}");
                stmt.registerOutParameter(1 , -10); // ref cursor
                stmt.setBigDecimal(2,iMap.getBigDecimal("SATICI_KOD"));
                stmt.execute();
                rSet = (ResultSet) stmt.getObject(1);
                int row = 0;
                while (rSet.next()) {
                    oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
                    oMap.put(tableName , row , "SATICI_ISTISNA_KOD" , rSet.getBigDecimal("SATICI_ISTISNA_KOD"));
                    oMap.put(tableName, row, "SATICI_ADI",rSet.getString("SATICI_ADI"));
                    oMap.put(tableName , row , "SATICI_ISTISNA_MI" , GuimlUtil.convertToCheckBoxSelected(rSet.getString("SATICI_ISTISNA_MI")));
                    row++;
                   }
              
                return oMap;
                
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } finally{
            	GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
            
        }
        
        @GraymoundService("BNSPR_TRN3248_SAVE")
        public static Map<?, ?> save(GMMap iMap) {
            try{
                Session session = DAOSession.getSession("BNSPRDal");
                String tableName = "TBL_TESVIK_SATICI_ISTISNA";
                
                List<?> recordList = (List<?>) iMap.get(tableName);
                
                for (int row = 0; row < recordList.size(); row++){
                    
                    BirTesvikSaticiistisnaTxId id = new BirTesvikSaticiistisnaTxId();
                    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    id.setSaticiIstisnaKod(iMap.getBigDecimal(tableName , row , "SATICI_ISTISNA_KOD"));
                    
                    BirTesvikSaticiistisnaTx birTesvikSaticiistisnaTx = (BirTesvikSaticiistisnaTx) session.get(BirTesvikSaticiistisnaTx.class , id);
                    if (birTesvikSaticiistisnaTx == null){
                        birTesvikSaticiistisnaTx = new BirTesvikSaticiistisnaTx();
                    }
                    birTesvikSaticiistisnaTx.setId(id);
                   
                    
                    birTesvikSaticiistisnaTx.setSaticiIstisnaMi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName , row , "SATICI_ISTISNA_MI")));
                   
                    session.saveOrUpdate(birTesvikSaticiistisnaTx);
                }
                session.flush();
                iMap.put("TRX_NAME" , "3248");
                return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
        }
        
        @GraymoundService("BNSPR_TRN3248_GET_INFO")
        public static GMMap getInfo(GMMap iMap) {
            GMMap oMap = new GMMap();
            
            try{
                // Get Master
                String tableName = "TBL_TESVIK_SATICI_ISTISNA";
                Session session = DAOSession.getSession("BNSPRDal");
                Criteria criteria = session.createCriteria(BirTesvikSaticiistisnaTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")));
                
                List<?> recordList = (List<?>) criteria.list();
                
                for (int row = 0; row < recordList.size(); row++){
                    BirTesvikSaticiistisnaTx birTesvikSaticiistisnaTx = (BirTesvikSaticiistisnaTx) recordList.get(row);
                    oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
                    oMap.put(tableName , row , "SATICI_ISTISNA_KOD" , birTesvikSaticiistisnaTx.getId().getSaticiIstisnaKod());
                    oMap.put(tableName, row, "SATICI_ADI", DALUtil.getResult("select satici_adi from bir_satici where kod = "+birTesvikSaticiistisnaTx.getId().getSaticiIstisnaKod()+""));
                    oMap.put(tableName , row , "SATICI_ISTISNA_MI" , GuimlUtil.convertToCheckBoxSelected(birTesvikSaticiistisnaTx.getSaticiIstisnaMi()));
 

                }
                
                return oMap;
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
        }
 
    }


