package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.biff.EmptyCell;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import tr.com.aktifbank.bnspr.dao.BirihtarnameiptalTx;
import tr.com.aktifbank.bnspr.dao.BirihtarnameiptalTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3297Services {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanTRN3297Services.class);

	@GraymoundService("BNSPR_TRN3297_UPLOAD_EXCEL")
	public static GMMap uploadTakipMizanExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		BigDecimal musteriNo,masrafBakiye;
		try {
			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("ISO-8859-9");

			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet dataSheet = workbook.getSheet(0);

			conn = DALUtil.getGMConnection();

			String tableName = "IHTAR_IPTAL_TABLO";
			int row = 0;
			
				stmt = conn.prepareCall("{call bnspr.PKG_TRN3297.ihtar_iptal_data(?,?,?,?)}");
				
				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
				
				for (int i = 0; i < dataSheet.getRows(); i++) {

					if (dataSheet.getCell(0, i) instanceof EmptyCell) {
						continue;
					}
					else {
						String musteri = dataSheet.getCell(0, i).getContents();
						musteri = musteri.trim();

						if (musteri != null && !musteri.trim().isEmpty()) {
							musteriNo = new BigDecimal(musteri);						

							int index = 1;
							stmt.setBigDecimal(index++, musteriNo);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DATE);
							stmt.execute();

							oMap.put(tableName, row, "MUSTERI_NO", musteriNo);
							index = 2;	
							masrafBakiye = stmt.getBigDecimal(index++);
							if(masrafBakiye == null)
								throw new GMRuntimeException(0, "Dosyada hatal� kay�t bulunuyor.M��teri No : " + musteriNo.toString());
							oMap.put(tableName, row, "MASRAF_BAKIYE", masrafBakiye);
							oMap.put(tableName, row, "SORGU_NO", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "ISLEM_TARIHI", dateFormat.format(stmt.getDate(index++)));
							row++;

							stmt.clearParameters();
						}
					}
				}
			return oMap;
		}
		catch (Exception e) {			
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3297_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "IHTAR_IPTAL_TABLO";
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			
			for(int i=0;i< iMap.getSize(tableName);i++){
				
				BirihtarnameiptalTxId birihtarnameiptalTxId = new BirihtarnameiptalTxId();
				birihtarnameiptalTxId.setTxNo(trxNo);
				birihtarnameiptalTxId.setSorguNo(iMap.getBigDecimal(tableName, i, "SORGU_NO"));
				birihtarnameiptalTxId.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
				
				BirihtarnameiptalTx birihtarnameiptalTx = new BirihtarnameiptalTx();				
				birihtarnameiptalTx.setIhtarTarihi(new SimpleDateFormat("dd/MM/yyyy").parse(iMap.getString(tableName, i, "ISLEM_TARIHI")));
				birihtarnameiptalTx.setMasrafBakiye(iMap.getBigDecimal(tableName, i, "MASRAF_BAKIYE"));
				
				birihtarnameiptalTx.setId(birihtarnameiptalTxId);
				
				session.save(birihtarnameiptalTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3297");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
