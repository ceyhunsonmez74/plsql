package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;

import org.apache.log4j.Logger;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3246Services {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanQRY3246Services.class);
	
	@GraymoundService("BNSPR_QRY3246_KUYRUK_SORGULA")
	public static GMMap musteriKuyrukSorgula(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_rc3246.kuyruk_bilgi_al(?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			
			if (iMap.getDate("BAS_TAR") != null)
				stmt.setDate(3, new java.sql.Date(iMap.getDate("BAS_TAR")
						.getTime()));
			else
				stmt.setDate(3, null);
			
			if (iMap.getDate("BIT_TAR") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("BIT_TAR")
						.getTime()));
			else
				stmt.setDate(4, null);
			
			int urunTipi = iMap.getInt("URUN_TIPI");
			if(urunTipi == 1)
				stmt.setString(5, "BK");
			if(urunTipi == 2)
				stmt.setString(5, "KMH");
			if(urunTipi == 3)
				stmt.setString(5, "KK");
			if(urunTipi == 0)
				stmt.setString(5, null);
			
			boolean hataliKuyrukSorgulama = iMap.getBoolean("HATALI_EH");
			if(hataliKuyrukSorgulama == true){
				stmt.setString(6, "SUCCESSFUL");
			}else{
				stmt.setString(6, null);
			}
			
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "KUYRUK_TABLO";
			
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "KUYRUK_NO", rSet.getString("KUYRUK_NO"));
				oMap.put(tableName, i, "KUYRUK_TURU", rSet.getString("KUYRUK_TURU"));
				oMap.put(tableName, i, "KUYRUK_DURUMU", rSet.getString("KUYRUK_DURUMU"));
				oMap.put(tableName, i, "KUYRUK_TARIHI", rSet.getDate("KUYRUK_TARIHI"));

				i++;
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_QRY3246_KUYRUK_DETAY")
	public static GMMap musteriKuyrukDetay(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_rc3246.kuyruk_detay_bilgi_al(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KUYRUK_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
			
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "KUYRUK_DETAY";
			
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
				oMap.put(tableName, i, "TAKIP_HESAP_NO", rSet.getString("TAKIP_HESAP_NO"));
				oMap.put(tableName, i, "BORC_ALACAK_TANIM_TIPI", rSet.getString("BORC_ALACAK_TANIM_TIPI"));
				oMap.put(tableName, i, "FAIZ_ORAN", rSet.getBigDecimal("FAIZ_ORAN"));
				oMap.put(tableName, i, "FAIZE_BAZ_TARIH", rSet.getDate("FAIZE_BAZ_TARIH"));
				oMap.put(tableName, i, "FAIZE_BAZ_TUTAR", rSet.getBigDecimal("FAIZE_BAZ_TUTAR"));
				oMap.put(tableName, i, "FIS_NUMARA", rSet.getString("FIS_NUMARA"));
				oMap.put(tableName, i, "HES_HAR_TANIM_TIPI", rSet.getString("HES_HAR_TANIM_TIPI"));
				oMap.put(tableName, i, "HES_HAR_UST_TANIM_TIPI", rSet.getString("HES_HAR_UST_TANIM_TIPI"));
				oMap.put(tableName, i, "IPTAL_TX_NO", rSet.getString("IPTAL_TX_NO"));
				oMap.put(tableName, i, "ISLEM_TARIHI", rSet.getDate("ISLEM_TARIHI"));
				oMap.put(tableName, i, "TUTAR", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, i, "URUN_TIPI", rSet.getString("URUN_TIPI"));
				oMap.put(tableName, i, "VERGI_TIPI1", rSet.getString("VERGI_TIPI1"));
				oMap.put(tableName, i, "VERGI_TIPI2", rSet.getString("VERGI_TIPI2"));
				oMap.put(tableName, i, "VERGI_TUTAR1", rSet.getBigDecimal("VERGI_TUTAR1"));
				oMap.put(tableName, i, "VERGI_TUTAR2", rSet.getBigDecimal("VERGI_TUTAR2"));

				i++;
			}
		
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
		
	}
	@GraymoundService("BNSPR_QRY3246_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		try {
			iMap.put("URUN_TIP_LIST", 0 , "VALUE", 0);
			iMap.put("URUN_TIP_LIST", 0 , "NAME", "Se�iniz");
			iMap.put("URUN_TIP_LIST", 1 , "VALUE", 1);
			iMap.put("URUN_TIP_LIST", 1 , "NAME", "BK");
			iMap.put("URUN_TIP_LIST", 2 , "VALUE", 2);
			iMap.put("URUN_TIP_LIST", 2 , "NAME", "KMH");
			iMap.put("URUN_TIP_LIST", 3 , "VALUE", 3);
			iMap.put("URUN_TIP_LIST", 3 , "NAME", "KK");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
}
