package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKullandirimBloke;
import tr.com.aktifbank.bnspr.dao.BirKullandirimBlokeTx;
import tr.com.aktifbank.bnspr.dao.BirKullandirimBlokeTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3212Services {
	
	@GraymoundService("BNSPR_TRN3212_BAYI_BLOKE_SORGULA")
	public static GMMap findBayiBloke(GMMap iMap) {
		GMMap resultMap = new GMMap();
		try {
			Object[] inputValues = new Object[6];
			//verilen input de�erlerinin ilk de�eri tip olacak sekilde set edilmelidir.
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("MUSTERI_NO");
			inputValues[4] = BnsprType.NUMBER;
			inputValues[5] = iMap.getBigDecimal("SATICI_KOD");
			
			String func = "{? = call PKG_RC3212.BLOKE_HESAP_GETIR(?, ?, ?)}";
			//TABLO_BLOKE aray�zde out edilecek de�erdir. Map seklinde outjection yap�l�yor
			resultMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, "TABLO_BLOKE", inputValues);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return resultMap;
	}
	
	@GraymoundService("BNSPR_TRN3212_BAYI_BLOKE_COZME")
	public static GMMap blokeCozme(GMMap iMap) {
		BigDecimal basvuruNo = null;
		BigDecimal kalanBlokeTutar;
		BigDecimal cozulenBlokeTutar;
		BigDecimal cozulenTutar;
		boolean islemFlag = false;
		BigDecimal txNo = null;
		GMMap oMap = new GMMap();
		
		try {
			BigDecimal ekranTrxNo = iMap.getBigDecimal("TRX_NO");
			
			BigDecimal cozulecekMiktar = iMap.getBigDecimal("COZULECEK_MIKTAR");
			String cozmeNedeni = iMap.getString("ACIKLAMA");
			String cozmeTipi = iMap.getString("COZME_TIPI");
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			for (int i=0; i < iMap.getSize("TABLO_BLOKE"); i++) {
				if(iMap.getBoolean("TABLO_BLOKE", i, "SEC")){
					txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
					basvuruNo = iMap.getBigDecimal("TABLO_BLOKE", i, "BASVURU_NO");
					Criteria criteria = session.createCriteria(BirKullandirimBloke.class);
					criteria.add(Restrictions.eq("basvuruNo", basvuruNo));
					
					//basvuru numaras�na gore sorgulama yap�ld�g� icin tek kay�t gelecektir 
					BirKullandirimBloke bBloke = (BirKullandirimBloke) criteria.list().get(0);
					
					BirKullandirimBlokeTx bkTx = new BirKullandirimBlokeTx();
					BirKullandirimBlokeTxId id = new BirKullandirimBlokeTxId();
					id.setBasvuruNo(basvuruNo);
					bkTx.setBlokeGunSay(bBloke.getBlokeGunSay());
					bkTx.setBlokeHesapNo(bBloke.getBlokeHesapNo());
					bkTx.setBlokeTutar(bBloke.getBlokeTutar());
					bkTx.setCozmeNedeni(cozmeNedeni);
					bkTx.setCozmeTarihi(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH" , iMap).getDate("BANKA_TARIH"));
					bkTx.setBayiHesapNo(bBloke.getBayiHesapNo());
					
					if(!"K".equals(cozmeTipi)){
						kalanBlokeTutar = bBloke.getKalanBlokeTutar();
						cozulenBlokeTutar = bBloke.getCozulenBlokeTutar();
						cozulenTutar = bBloke.getCozulenTutar();
						
						if (kalanBlokeTutar == null || "".equals(kalanBlokeTutar))
							kalanBlokeTutar = BigDecimal.ZERO;
						
						if (cozulenBlokeTutar == null || "".equals(cozulenBlokeTutar))
							cozulenBlokeTutar = BigDecimal.ZERO;
						
						if (cozulenTutar == null || "".equals(cozulenTutar))
							cozulenTutar = BigDecimal.ZERO;
						
						if (cozulecekMiktar == null || "".equals(cozulecekMiktar))
							cozulecekMiktar = BigDecimal.ZERO;
						
						kalanBlokeTutar = kalanBlokeTutar.subtract(cozulecekMiktar);
						cozulenBlokeTutar = cozulenBlokeTutar.add(cozulecekMiktar);
						
						//cozulecek miktar�n 0 gelme durumu sadece IPTAL islemindedir
						//bu k�sm�n kontrolu ui taraf�nda yap�ld�, IPTAL olmadan 
						//0 miktar olarak gonderilemez
						if (cozulecekMiktar.compareTo(BigDecimal.ZERO) == 0) {
							bkTx.setDurum("IPTAL");
							//iptal durumunda kalan blokenin hepsi cozulur
							bkTx.setCozulenBlokeTutar(kalanBlokeTutar);
							
						} else if (kalanBlokeTutar.compareTo(cozulecekMiktar) == 0) {
							bkTx.setDurum("COZULMUS");
						} else {
							bkTx.setDurum("KISMI");
						}
					}else{
						kalanBlokeTutar = BigDecimal.ZERO;
						cozulenBlokeTutar = bBloke.getBlokeTutar();
						cozulecekMiktar = bBloke.getBlokeTutar();
						bkTx.setDurum("COZULMUS");
					}
					
					bkTx.setKalanBlokeTutar(kalanBlokeTutar);			
					bkTx.setCozulenBlokeTutar(cozulenBlokeTutar);
					bkTx.setCozulenTutar(cozulecekMiktar);

					bkTx.setKampanyaKod(bBloke.getKampanyaKod());
					bkTx.setKullandirimTutari(bBloke.getKullandirimTutari());
					bkTx.setVadeTarihi(bBloke.getVadeTarihi());
					bkTx.setMuhasebeTxNo(ekranTrxNo);
					
					id.setTxNo(txNo);
					bkTx.setId(id);
					session.save(bkTx);
					session.flush();
					
					iMap.put("TRX_NAME", "3212");
			        iMap.put("TRX_NO", txNo);
			        islemFlag = true;
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
				}
			}
			
			if(islemFlag){
		        return oMap;
			}else{
				throw new GMRuntimeException(0,"��lem yap�lacak kay�t se�ilmedi."); 
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3212_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Object[] inputValues = new Object[6];
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<BirKullandirimBlokeTx> blokeTx = session.createCriteria(BirKullandirimBlokeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			int i=0;
			for (BirKullandirimBlokeTx birKullandirimBlokeTx : blokeTx) {
				oMap.put("TABLO_BLOKE", i, "BASVURU_NO", birKullandirimBlokeTx.getId().getBasvuruNo());
				inputValues[0] = BnsprType.NUMBER;
				inputValues[1] = oMap.getBigDecimal("BASVURU_NO");
				inputValues[2] = BnsprType.NUMBER;
				inputValues[3] = null;
				inputValues[4] = BnsprType.NUMBER;
				inputValues[5] = null;
				
				String func = "{? = call PKG_RC3212.BLOKE_HESAP_GETIR(?, ?, ?)}";
				oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TABLO_BLOKE_DETAY", inputValues));
				
				oMap.put("TABLO_BLOKE", i, "MUSTERI_NO", oMap.get("TABLO_BLOKE_DETAY", 0, "MUSTERI_NO"));
				oMap.put("TABLO_BLOKE", i, "BAYI_ADI", oMap.get("TABLO_BLOKE_DETAY", 0, "BAYI_ADI"));
				oMap.put("TABLO_BLOKE", i, "KULLANDIRIM_TUTARI", birKullandirimBlokeTx.getKullandirimTutari());
				oMap.put("TABLO_BLOKE", i, "BLOKE_TUTARI", birKullandirimBlokeTx.getBlokeTutar());
				oMap.put("TABLO_BLOKE", i, "KALAN_BLOKE_TUTAR", birKullandirimBlokeTx.getKalanBlokeTutar());
				oMap.put("TABLO_BLOKE", i, "BLOKE_HESAP_NO", birKullandirimBlokeTx.getBlokeHesapNo());
				oMap.put("TABLO_BLOKE", i, "VADE_TARIHI", birKullandirimBlokeTx.getVadeTarihi());
				oMap.put("TABLO_BLOKE", i, "DURUM", birKullandirimBlokeTx.getDurum());
				
				oMap.put("ACIKLAMA", birKullandirimBlokeTx.getCozmeNedeni());
				oMap.put("COZULEN_TUTAR", birKullandirimBlokeTx.getCozulenTutar());
				
				i++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
