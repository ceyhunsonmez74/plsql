package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruKartBilgi;
import tr.com.aktifbank.bnspr.dao.BirBasvuruPaket;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSigortaSatis;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTasit;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.calikbank.bnspr.consumerloan.utils.CreditTypes;
import tr.com.calikbank.bnspr.consumerloan.utils.GeneralUtils;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirBasvuruSozlesmeTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTx;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanReports {
	private static final int BK_IHTARNAME_DOKUMAN_KOD = 489;
	private static final int KMH_IHTARNAME_DOKUMAN_KOD = 490;
	private static final int KK_IHTARNAME_DOKUMAN_KOD = 488;
	
	@GraymoundService("INTERNET_REPORT_PAYMENT_PLAN_SIM")
	public static GMMap createPaymentPlanSim(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();

			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3183_GET_ODEME_PLANI", iMap));
			iMap.put("KOD", "BIR_ODM_GRP");
			iMap.put("KEY", iMap.get("ODEME_TIP_KOD"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", iMap));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_DOVIZ_AD", iMap));

			parameters.put("BAZ_FAIZ", iMap.getBigDecimal("FAIZ_ORANI"));
			parameters.put("TUTAR", iMap.getBigDecimal("KREDI_TUTARI"));
			parameters.put("VADE", iMap.getBigDecimal("KREDI_VADE"));
			parameters.put("DOVIZ_KODU", iMap.getString("DOVIZ_AD"));
			parameters.put("SOZLESME_FAIZI", iMap.getBigDecimal("SOZLESME_FAIZ_ORANI"));
			parameters.put("KATILIM_BEDELI", iMap.getBigDecimal("KATKI_PAYI"));
			parameters.put("ODEME_SEKLI", iMap.getString("TEXT"));

			String listName = "ODEME_PLANI";
			for (int i = 0; i < iMap.getSize(listName); i++) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();

				rowData.put("OP_TAKSIT_TARIHI", iMap.getDate(listName, i, "OP_TAKSIT_TARIHI"));
				rowData.put("OP_TAKSIT_TUTAR", iMap.getBigDecimal(listName, i, "OP_TAKSIT_TUTAR"));
				rowData.put("OP_ANAPARA", iMap.getBigDecimal(listName, i, "OP_ANAPARA"));
				rowData.put("OP_FAIZ", iMap.getBigDecimal(listName, i, "OP_FAIZ"));
				rowData.put("OP_KKDF", iMap.getBigDecimal(listName, i, "OP_KKDF"));
				rowData.put("OP_BSMV", iMap.getBigDecimal(listName, i, "OP_BSMV"));
				rowData.put("OP_KALAN_TUTAR", iMap.getBigDecimal(listName, i, "OP_KALAN_TUTAR"));
				rowData.put("OP_TAKSIT_NO", i + 1);
				rowData.put("OP_MASRAF", new BigDecimal(0));
				rowData.put("OP_AYLIK_TOPLAM", iMap.getBigDecimal(listName, i, "OP_AYLIK_TOPLAM"));
				rowData.put("GRP", new BigDecimal(1 + i / 12));

				list.add(rowData);
			}
			parameters.put("REPORT_DATA", list);

			JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3171_SIM_ODEME_PLANI", parameters);
			oMap.put("REPORT", jasperPrint);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("INTERNET_REPORT_BACK_PAYMENT_PLAN")
	public static GMMap createBackPaymentPlanReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3181_GERI_ODEME_PLANI", parameters);
			oMap.put("REPORT", jasperPrint);
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			birBasvuru.setSozlesmeBasildiEh("E");
			session.saveOrUpdate(birBasvuru);
			session.flush();
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("INTERNET_REPORT_INTERNET_PAYMENT_PLAN")
	public static GMMap createInternetPaymentPlanReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));

			String reportType = iMap.getString("REPORT_TYPE");
			Object report = ReportUtil.generateReport("BNSPR_RAP3181_INTERNET_ODEME_PLANI", parameters, reportType);
			oMap.put("REPORT", report);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("INTERNET_REPORT_PAYMENT_PLAN")
	public static GMMap createPaymentPlanReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3171_ODEME_PLANI", parameters);
			oMap.put("REPORT", jasperPrint);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("INTERNET_REPORT_CREDIT_CONDITIONS_BYTE_ARRAY")
	public static GMMap createCreditContionsReportByteArray(GMMap iMap) {
		try {
			iMap.put("RAPOR_KANAL", "BAYI");
			GMMap serviceoutMap = GMServiceExecuter.call("INTERNET_REPORT_CREDIT_CONDITIONS", iMap);
			JasperPrint doc = (JasperPrint) serviceoutMap.get("REPORT");
			byte[] report = JasperExportManager.exportReportToPdf(doc);
			GMMap oMap = new GMMap();
			oMap.put("REPORT", report);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("INTERNET_REPORT_CREDIT_CONDITIONS")
	public static GMMap createCreditContionsReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		StringBuilder stb = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String tableName = "RESULT";
		BigDecimal yimTutar = BigDecimal.ZERO;

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			oMap.put("ERKEN_BELGE_TX_NO", GMServiceExecuter.execute("BNSPR_TRN3181_ERKEN_BELGE_TX_NO", iMap).get("ERKEN_BELGE_TX_NO"));

			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));

			Date sozlesme_tarihi = birBasvuru.getSozlesmeTarihi();
			Date bir_eylul_2013 = sdf.parse("01/09/2013");
			BirBasvuruTx birBasvuruTx = new BirBasvuruTx();
			if (oMap.getString("ERKEN_BELGE_TX_NO") != null) {
				birBasvuruTx = (BirBasvuruTx) session.get(BirBasvuruTx.class, oMap.getBigDecimal("ERKEN_BELGE_TX_NO"));
			}
			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));
			BirBasvuruSigortaSatis birBasvuruSigortaSatis = (BirBasvuruSigortaSatis) session.createCriteria(BirBasvuruSigortaSatis.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			BirBasvuruKartBilgi kartBilgi = (BirBasvuruKartBilgi) session.get(BirBasvuruKartBilgi.class, iMap.getBigDecimal("BASVURU_NO"));

			BirBasvuruTasit birBasvuruTasit = (BirBasvuruTasit) session.get(BirBasvuruTasit.class, iMap.getBigDecimal("BASVURU_NO"));

			boolean isDebit = false;

			if (kartBilgi != null && kartBilgi.getKartTipi() != null && kartBilgi.getKartNo() != null) {
				isDebit = true;
			}

			stb.append(birBasvuruKimlik.getAd());
			if (StringUtils.isNotBlank(birBasvuruKimlik.getIkinciAd())) {
				stb.append(" ");
				stb.append(birBasvuruKimlik.getIkinciAd());
			}
			stb.append(" ");
			stb.append(birBasvuruKimlik.getSoyad());

			iMap.put("AD_SOYAD", stb.toString());
			if (oMap.getString("ERKEN_BELGE_TX_NO") != null) {
				iMap.put("VADE", birBasvuruTx.getVade());
				iMap.put("KREDI_TUTARI", birBasvuruTx.getOnayTutar());
				iMap.put("FAIZ_ORANI", birBasvuruTx.getSozlesmeFaizi() != null ? birBasvuruTx.getSozlesmeFaizi() : birBasvuruTx.getFaizOrani());
				iMap.put("DOSYA_MASRAFI", birBasvuruTx.getDosyaMasrafi());
				iMap.put("KREDI_SIGORTA_PRIMI", birBasvuruTx.getSigortaPrimi() == null ? "0" : birBasvuru.getSigortaPrimi());
			}
			else {
				iMap.put("VADE", birBasvuru.getVade());
				iMap.put("KREDI_TUTARI", birBasvuru.getOnayTutar());
				iMap.put("FAIZ_ORANI", birBasvuru.getSozlesmeFaizi() != null ? birBasvuru.getSozlesmeFaizi() : birBasvuru.getFaizOrani());
				iMap.put("DOSYA_MASRAFI", birBasvuru.getDosyaMasrafi());
				iMap.put("KREDI_SIGORTA_PRIMI", birBasvuru.getSigortaPrimi() == null ? "0" : birBasvuru.getSigortaPrimi());
			}
			iMap.put("ESYA_SIGORTASI_PRIMI", birBasvuruSigortaSatis == null || birBasvuruSigortaSatis.getSigortaPrimi() == null ? "0" : birBasvuruSigortaSatis.getSigortaPrimi());

			iMap.put("KOD", "BIREYSEL_IHTAR_TEMERRUT_CARPAN");
			iMap.put("BIREYSEL_IHTAR_TEMERRUT_CARPAN", GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap).getBigDecimal("DEGER"));

			if (iMap.getBigDecimal("BIREYSEL_IHTAR_TEMERRUT_CARPAN") != null && iMap.getBigDecimal("FAIZ_ORANI") != null) {
				iMap.put("TEMERRUT_FAIZ_ORANI", iMap.getBigDecimal("BIREYSEL_IHTAR_TEMERRUT_CARPAN").multiply(iMap.getBigDecimal("FAIZ_ORANI"), new MathContext(3)));
			}
			else {
				iMap.put("TEMERRUT_FAIZ_ORANI", "");
			}

			/** Taksit tahsilat masrafi getir **/
			GMMap mMap = new GMMap();
			mMap.put("KOD", "KREDI_SART_GERI_ODEME");
			mMap.put("KEY", "BAYI_KOMISYON");
			String tahsilatUcret = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", mMap).getString("TEXT");

			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("AD_SOYAD", iMap.getString("AD_SOYAD"));
			parameters.put("VADE", iMap.getString("VADE"));
			parameters.put("KREDI_TUTARI", iMap.getString("KREDI_TUTARI"));
			parameters.put("FAIZ_ORANI", iMap.getString("FAIZ_ORANI"));
			parameters.put("DOSYA_MASRAFI", iMap.getString("DOSYA_MASRAFI"));
			parameters.put("KREDI_SIGORTA_PRIMI", iMap.getString("KREDI_SIGORTA_PRIMI"));
			parameters.put("TARIH", sdf.format(new Date()));
			parameters.put("IBAN", (String) DALUtil.callOneParameterFunction("{? = call Pkg_Iban.sp_IBAN_al(pkg_trn3181.onceki_basvuru_hesap_no(?))}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO")));

			iMap.put("KOD", "BIREYSEL_IHTAR_TEMERRUT_CARPAN");
			parameters.put("TEMERRUT_FAIZ_ORANI", iMap.getString("TEMERRUT_FAIZ_ORANI"));
			parameters.put("ESYA_SIGORTASI_PRIMI", iMap.getString("ESYA_SIGORTASI_PRIMI"));
			parameters.put("TAKSIT_TAHSILAT_UCRET", tahsilatUcret);

			/** TY-6797 TY-Kredi belgelerinin barkod numaras� ve /veya her belge i�in her bas�mda �retilecek bir numara ile kontrol edilmesi */
			BigDecimal txNo = (BigDecimal) session.createCriteria(BirBasvuruSozlesmeTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).setProjection(Projections.max("txNo")).uniqueResult();
			parameters.put("KONTROL_NUMARASI", txNo);

			BirBasvuruSozlesmeTx birBasvuruSozlesmeTx = null;
			if ("BAYI".equals(iMap.getString("RAPOR_KANAL"))) {
				birBasvuruSozlesmeTx = (BirBasvuruSozlesmeTx) session.get(BirBasvuruSozlesmeTx.class, txNo);
			}
			else {
				birBasvuruSozlesmeTx = new BirBasvuruSozlesmeTx();
			}

			ArrayDeque<String> reportNames = new ArrayDeque<String>();
			if (!"E".equals(birBasvuruSozlesmeTx.getBayiDigitalBasvuru())) {
				if ("E".equals(birBasvuru.getFaizsizFinansman())) {
					reportNames.add("BNSPR_RAP3181_KREDI_SART_GERI_ODEME_FZ");
					reportNames.add("BNSPR_RAP3181_KREDI_SART_GERI_ODEME_FZ");
				}
				else {
					reportNames.add("BNSPR_RAP3181_KREDI_SART_GERI_ODEME");
					reportNames.add("BNSPR_RAP3181_KREDI_SART_GERI_ODEME");
				}

				if (sozlesme_tarihi.after(bir_eylul_2013)) {
					/* TASIT */
					if (birBasvuru.getKrediTur().compareTo(CreditTypes.TASIT.getCreditCode()) == 0) {
						if ("E".equals(birBasvuru.getFaizsizFinansman())) {
							reportNames.add("TASIT_KREDISI_URUN_BILGI_FORMU_FZ");
							reportNames.add("TASIT_KREDISI_URUN_BILGI_FORMU_2_FZ");
							reportNames.add("TASIT_KREDISI_URUN_BILGI_FORMU_FZ");
							reportNames.add("TASIT_KREDISI_URUN_BILGI_FORMU_2_FZ");
						}
						else {
							reportNames.add("TASIT_KREDISI_URUN_BILGI_FORMU");
							reportNames.add("TASIT_KREDISI_URUN_BILGI_FORMU_2");
							reportNames.add("TASIT_KREDISI_URUN_BILGI_FORMU");
							reportNames.add("TASIT_KREDISI_URUN_BILGI_FORMU_2");
						}
						parameters.put("REHIN_MASRAFI", birBasvuruTasit.getRehinMasrafi());
					}
					else {
						/**
						 * TY-6530 TY-�htiya� - Ta��t kredisi bilgi formundan cayma hakk� maddesinin c�kar�lmas�
						 * kapsaminda sayfa 2 kaldirilip tek sayfaya indirildi
						 */
						if ("E".equals(birBasvuru.getFaizsizFinansman())) {
							reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU_FZ");
							reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU_2_FZ");
							reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU_FZ");
							reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU_2_FZ");
						}
						else {
							reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU");
							reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU_2");
							reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU");
							reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU_2");
						}
					}

					if ("E".equals(birBasvuru.getFaizsizFinansman())) {
						reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_FZ");
						if (isDebit) {
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_2_KART_TESLIM");
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_3_KART_TESLIM");
						}
						else {
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_2_FZ");
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_3_FZ");
						}
						reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_FZ");
						if (isDebit) {
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_2_KART_TESLIM");
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_3_KART_TESLIM");
						}
						else {
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_2_FZ");
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_3_FZ");
						}
					}
					else {
						reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU");
						if (isDebit) {
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_2_KART_TESLIM");
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_3_KART_TESLIM");
						}
						else {
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_2");
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_3");
						}
						reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU");
						if (isDebit) {
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_2_KART_TESLIM");
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_3_KART_TESLIM");
						}
						else {
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_2");
							reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_3");
						}
					}
				}
			}

			String pttEmeklisiMi = (String) (GMServiceExecuter.execute("BNSPR_TRN3171_PTT_EMEKLISI_MI", iMap)).get("PTT_EMEKLISI_MI");
			if ("E".equals(pttEmeklisiMi) || "7".equals(birBasvuru.getKanalKodu())) {
				parameters.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
				reportNames.add("BNSPR_RAP3181_MAAS_TAAHHUTNAME");
			}

			if ("7".equals(birBasvuru.getKanalKodu()) && !"E".equals(birBasvuruSozlesmeTx.getBayiDigitalBasvuru())) {
				parameters.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
				reportNames.add("BNSPR_RAP3181_PTT_SIGORTA_SOZLESME");
				reportNames.add("BNSPR_RAP3181_PTT_SIGORTA_SOZLESME");
				reportNames.add("BNSPR_BROKER_YETKILENDIRME_MEKTUBU");
			}

			BigDecimal kulTutar = BigDecimal.ZERO;
			if (!"E".equals(birBasvuruSozlesmeTx.getBayiDigitalBasvuru())) {
				// bayiden odeme
				if (BigDecimal.ONE.equals(birBasvuru.getKrediOdemeTipi())) {
					GMMap paramMap = new GMMap();
					paramMap.put("KOD", "YIM_BASVURU_PARAMETRE");
					paramMap.put("KEY", "YIM_HESAP_NO");

					BigDecimal yimHesapNo = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).getBigDecimal("TEXT");
					paramMap.put("KEY", "YIM_TUTAR");
					yimTutar = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).getBigDecimal("TEXT");

					BigDecimal dosyaMasraf = GeneralUtils.nvl(birBasvuru.getDosyaMasrafi(), BigDecimal.ZERO);
					BigDecimal serbestKatkiPay = GeneralUtils.nvl(birBasvuru.getSerbestKatkiPayi(), BigDecimal.ZERO);
					BigDecimal sigortaPrim = GeneralUtils.nvl(birBasvuru.getSigortaPrimi(), BigDecimal.ZERO);
					BigDecimal farkFaiz = GeneralUtils.nvl(birBasvuru.getFarkFaizi(), BigDecimal.ZERO);
					kulTutar = birBasvuru.getOnayTutar().add(dosyaMasraf.negate()).add(serbestKatkiPay.negate()).add(sigortaPrim.negate()).add(farkFaiz.negate().subtract(yimTutar));
					parameters.put("KUL_TUTAR", kulTutar);

					parameters.put("YIM_HESAP_NO", yimHesapNo);
					reportNames.add("BNSPR_TALEP_FORMU_PARA_TRANSFERI");
				}

				// kart verildiyse
				if (isDebit) {
					parameters.put("KART_NO", kartBilgi.getKartNo());
					parameters.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
					reportNames.add("BNSPR_KART_TESLIM_TUTANAGI");
				}
			}

			parameters.put("TARIM_EH", "H");

			/* Tasit Rehin Sozlesmesi */
			if (birBasvuru.getKrediTur().compareTo(CreditTypes.TASIT.getCreditCode()) == 0) {
				if (birBasvuruTasit != null) {

					parameters.put("TASIT_MARKA", StringUtils.EMPTY);
					parameters.put("TASIT_MODEL", StringUtils.EMPTY);
					parameters.put("TASIT_PLAKA_NO", StringUtils.EMPTY);
					parameters.put("TASIT_MOTOR_NO", StringUtils.EMPTY);
					parameters.put("TASIT_SASI_NO", StringUtils.EMPTY);
					parameters.put("TASIT_RUHSAT_TARIHI", StringUtils.EMPTY);
					parameters.put("TASIT_SICIL_NO", StringUtils.EMPTY);
					parameters.put("TASIT_TRAFIK_SUBE", StringUtils.EMPTY);
					parameters.put("TASIT_YIL", StringUtils.EMPTY);
					parameters.put("TASIT_ADRES", StringUtils.EMPTY);
					parameters.put("TC_KIMLIK_NO", StringUtils.EMPTY);

					String marka = birBasvuruTasit.getMarka();
					String model = birBasvuruTasit.getModel();
					String plaka = birBasvuruTasit.getPlaka();
					String motor = birBasvuruTasit.getMotorNo();
					String sasi = birBasvuruTasit.getSasiNo();
					String ruhsatTarihi = StringUtils.EMPTY;

					Date ruhsatDate = birBasvuruTasit.getRuhsatTarih();
					if (ruhsatDate != null) {
						ruhsatTarihi = ruhsatDate.toString().substring(0, 10);
					}
					String sicilNo = birBasvuruTasit.getSicilNo();
					String trafikSube = birBasvuruTasit.getTrafikSubesi();
					String yil = birBasvuruTasit.getModelYil();
					String adres = (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.basvuru_sozlesme_adres(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));
					String tcKimlikNo = birBasvuruKimlik.getTcKimlikNo();

					if (StringUtils.isNotEmpty(marka)) {
						parameters.put("TASIT_MARKA", marka);
					}
					if (StringUtils.isNotEmpty(model)) {
						parameters.put("TASIT_MODEL", model);
					}
					if (StringUtils.isNotEmpty(plaka)) {
						parameters.put("TASIT_PLAKA_NO", plaka);
					}
					if (StringUtils.isNotEmpty(motor)) {
						parameters.put("TASIT_MOTOR_NO", motor);
					}
					if (StringUtils.isNotEmpty(sasi)) {
						parameters.put("TASIT_SASI_NO", sasi);
					}
					if (StringUtils.isNotEmpty(ruhsatTarihi)) {
						parameters.put("TASIT_RUHSAT_TARIHI", ruhsatTarihi);
					}
					if (StringUtils.isNotEmpty(sicilNo)) {
						parameters.put("TASIT_SICIL_NO", sicilNo);
					}
					if (StringUtils.isNotEmpty(trafikSube)) {
						parameters.put("TASIT_TRAFIK_SUBE", trafikSube);
					}
					if (StringUtils.isNotEmpty(yil)) {
						parameters.put("TASIT_YIL", yil);
					}
					if (StringUtils.isNotEmpty(adres)) {
						parameters.put("TASIT_ADRES", adres);
					}
					if (StringUtils.isNotEmpty(tcKimlikNo)) {
						parameters.put("TC_KIMLIK_NO", tcKimlikNo);
					}

					if ("E".equals(birBasvuru.getFaizsizFinansman())) {
						reportNames.add("TASIT_REHIN_SOZLESME_FORMU_FZ");
						reportNames.add("TASIT_REHIN_SOZLESME_FORMU_2_FZ");
						reportNames.add("TASIT_REHIN_SOZLESME_FORMU_FZ");
						reportNames.add("TASIT_REHIN_SOZLESME_FORMU_2_FZ");
					}
					else {
						reportNames.add("TASIT_REHIN_SOZLESME_FORMU");
						reportNames.add("TASIT_REHIN_SOZLESME_FORMU_2");
						reportNames.add("TASIT_REHIN_SOZLESME_FORMU");
						reportNames.add("TASIT_REHIN_SOZLESME_FORMU_2");
					}
				}
			}
			else if (birBasvuru.getKrediTur().compareTo(CreditTypes.TARIM.getCreditCode()) == 0) {
				parameters.put("TARIM_EH", "E");
			}

			/** Ek �r�n para transferi **/
			if (!"E".equals(birBasvuruSozlesmeTx.getBayiDigitalBasvuru())) {
				List<?> paketList = session.createCriteria(BirBasvuruPaket.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				for (Iterator<?> iterator = paketList.iterator(); iterator.hasNext();) {
					BirBasvuruPaket birBasvuruPaket = (BirBasvuruPaket) iterator.next();
					parameters.put("PAKET_TUTAR", birBasvuruPaket.getTutar());
					kulTutar = kulTutar.subtract(birBasvuruPaket.getTutar());
					parameters.put("KUL_TUTAR", kulTutar);
					parameters.put("PAKET_FIRMA_ADI", "_ _ _ _ _ _ _ _ _ _ _ _");
					parameters.put("PAKET_IBAN", "TR_ _  _ _ _ _  _ _ _ _  _ _ _ _  _ _ _ _  _ _ _ _  _ _");

					if ("E".equals(birBasvuru.getFaizsizFinansman())) {
						reportNames.add("BNSPR_EK_URUN_PARA_TRANSFERI_FZ");
					}
					else {
						reportNames.add("BNSPR_EK_URUN_PARA_TRANSFERI");
					}
				}
			}

			/** Borc transferi **/
			BirKampanya kampanya = (BirKampanya) session.get(BirKampanya.class, birBasvuru.getKampKod());
			if (kampanya != null && "E".equals(kampanya.getBorcTransferiEh())) {
				oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_ptt_kredi.eft_ve_kapama_talimat_info(?)}", tableName, BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")));

				parameters.put("TC_KIMLIK_NO", oMap.getString("TC_KIMLIK_NO"));
				parameters.put("ADI_SOYADI", oMap.getString("ADI_SOYADI"));
				parameters.put("BORC_TRANSFER_BANKA", oMap.getString("BANKA"));
				parameters.put("BORC_TRANSFER_SUBE", oMap.getString("SUBE"));
				parameters.put("BORC_TRANSFER_IBAN", oMap.getString("IBAN"));

				reportNames.add("BNSPR_RAP3181_EFT_KAPAMA_FORMU");
			}

			/** Para transfer talimat formu **/
			if (kampanya != null && "E".equals(kampanya.getPttIciBirlestirmeEh())) {
				parameters.put("TC_KIMLIK_NO", birBasvuru.getTcKimlikNo());
				parameters.put("ADI_SOYADI", iMap.getString("AD_SOYAD"));
				parameters.put("HESAP_NO", parameters.get("IBAN"));

				reportNames.add("BNSPR_RAP3181_TRANSFER_TALIMAT_FORMU");
			}

			oMap.put("REPORT", ReportUtil.generateAndConcatReports(reportNames, parameters));

			birBasvuru.setSozlesmeBasildiEh("E");
			session.saveOrUpdate(birBasvuru);
			session.flush();
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("INTERNET_REPORT_CREDIT_KEFALET")
	public static GMMap createCreditKefaletReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3181_KEFALET_SOZLESMESI", parameters);
			oMap.put("REPORT", jasperPrint);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("INTERNET_REPORT_CREDIT_GARANTOR_MUTABAKAT")
	public static GMMap createGarantorMutabakatReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
			JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3181_GARANTOR_MUTABAKAT", parameters);
			oMap.put("REPORT", jasperPrint);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("SMS_REPORT_CREDIT_APPLICATION")
	public static GMMap createSmsApplicationReport(GMMap iMap) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String tableName = "RESULT";
		final String documentCode = "2049", messageNo = "5980", referenceType = "2";

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			oMap.put("ERKEN_BELGE_TX_NO", GMServiceExecuter.execute("BNSPR_TRN3181_ERKEN_BELGE_TX_NO", iMap).get("ERKEN_BELGE_TX_NO"));

			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			BirBasvuruTx birBasvuruTx = new BirBasvuruTx();
			if (oMap.getString("ERKEN_BELGE_TX_NO") != null) {
				birBasvuruTx = (BirBasvuruTx) session.get(BirBasvuruTx.class, oMap.getBigDecimal("ERKEN_BELGE_TX_NO"));
			}
			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));

			StringBuilder stb = new StringBuilder();
			stb.append(birBasvuruKimlik.getAd());
			if (StringUtils.isNotBlank(birBasvuruKimlik.getIkinciAd())) {
				stb.append(" ");
				stb.append(birBasvuruKimlik.getIkinciAd());
			}
			stb.append(" ");
			stb.append(birBasvuruKimlik.getSoyad());

			iMap.put("AD_SOYAD", stb.toString());
			if (oMap.getString("ERKEN_BELGE_TX_NO") != null) {
				iMap.put("KREDI_TUTARI", birBasvuruTx.getOnayTutar());
				iMap.put("FAIZ_ORANI", birBasvuruTx.getSozlesmeFaizi() != null ? birBasvuruTx.getSozlesmeFaizi() : birBasvuruTx.getFaizOrani());
				iMap.put("DOSYA_MASRAFI", birBasvuruTx.getDosyaMasrafi());
			}
			else {
				iMap.put("KREDI_TUTARI", birBasvuru.getOnayTutar());
				iMap.put("FAIZ_ORANI", birBasvuru.getSozlesmeFaizi() != null ? birBasvuru.getSozlesmeFaizi() : birBasvuru.getFaizOrani());
				iMap.put("DOSYA_MASRAFI", birBasvuru.getDosyaMasrafi());
			}
			iMap.put("KOD", "BIREYSEL_IHTAR_TEMERRUT_CARPAN");
			iMap.put("BIREYSEL_IHTAR_TEMERRUT_CARPAN", GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap).getBigDecimal("DEGER"));

			if (iMap.getBigDecimal("BIREYSEL_IHTAR_TEMERRUT_CARPAN") != null && iMap.getBigDecimal("FAIZ_ORANI") != null) {
				iMap.put("TEMERRUT_FAIZ_ORANI", iMap.getBigDecimal("BIREYSEL_IHTAR_TEMERRUT_CARPAN").multiply(iMap.getBigDecimal("FAIZ_ORANI"), new MathContext(3)));
			}
			else {
				iMap.put("TEMERRUT_FAIZ_ORANI", "");
			}

			/** Taksit tahsilat masrafi getir **/
			GMMap mMap = new GMMap();
			mMap.put("KOD", "KREDI_SART_GERI_ODEME");
			mMap.put("KEY", "BAYI_KOMISYON");
			String tahsilatUcret = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", mMap).getString("TEXT");

			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("AD_SOYAD", iMap.getString("AD_SOYAD"));
			parameters.put("KREDI_TUTARI", iMap.getString("KREDI_TUTARI"));
			parameters.put("FAIZ_ORANI", iMap.getString("FAIZ_ORANI"));
			parameters.put("DOSYA_MASRAFI", iMap.getString("DOSYA_MASRAFI"));
			parameters.put("TARIH", sdf.format(new Date()));
			parameters.put("IBAN", (String) DALUtil.callOneParameterFunction("{? = call Pkg_Iban.sp_IBAN_al(pkg_trn3181.onceki_basvuru_hesap_no(?))}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO")));

			iMap.put("KOD", "BIREYSEL_IHTAR_TEMERRUT_CARPAN");
			parameters.put("TEMERRUT_FAIZ_ORANI", iMap.getString("TEMERRUT_FAIZ_ORANI"));
			parameters.put("TAKSIT_TAHSILAT_UCRET", tahsilatUcret);

			/** TY-6797 TY-Kredi belgelerinin barkod numaras� ve /veya her belge i�in her bas�mda �retilecek bir numara ile kontrol edilmesi */
			BigDecimal txNo = (BigDecimal) session.createCriteria(BirBasvuruSozlesmeTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).setProjection(Projections.max("txNo")).uniqueResult();
			parameters.put("KONTROL_NUMARASI", txNo);

			oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_ptt_kredi.get_sobf_info(?,?)}", tableName, BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, "0"));

			parameters.put("KREDI_TURU", oMap.getString(tableName, 0, "KREDI_TURU"));
			parameters.put("KREDI_TUR", oMap.getString(tableName, 0, "KREDI_TURU"));
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("VADE", oMap.getString(tableName, 0, "VADE"));
			parameters.put("ONAY_TUTAR", oMap.getString(tableName, 0, "ONAY_TUTAR"));
			parameters.put("TAKSIT_TUTARI", oMap.getString(tableName, 0, "TAKSIT_TUTARI"));
			parameters.put("AKDI_FAIZ_AYLIK", oMap.getString(tableName, 0, "AKDI_FAIZ_AYLIK"));
			parameters.put("AKDI_FAIZ_YILLIK", oMap.getString(tableName, 0, "AKDI_FAIZ_YILLIK"));
			parameters.put("GECIKME_FAIZ_ORANI", oMap.getString(tableName, 0, "GECIKME_FAIZ_ORANI"));
			parameters.put("EFEKTIF_FAIZ_ORANI_AYLIK", oMap.getString(tableName, 0, "EFEKTIF_FAIZ_ORANI_AYLIK"));
			parameters.put("EFEKTIF_FAIZ_ORANI_YILLIK", oMap.getString(tableName, 0, "EFEKTIF_FAIZ_ORANI_YILLIK"));
			parameters.put("TOPLAM_GERI_ODEME_TUTARI", oMap.getString(tableName, 0, "TOPLAM_GERI_ODEME_TUTARI"));
			parameters.put("KREDI_TAHSIS_UCRETI", oMap.getString(tableName, 0, "KREDI_TAHSIS_UCRETI"));
			parameters.put("URUN_BILGISI", oMap.getString(tableName, 0, "URUN_BILGISI"));
			parameters.put("SATICI_ADI", oMap.getString(tableName, 0, "SATICI_ADI"));
			parameters.put("ADI_SOYADI", oMap.getString(tableName, 0, "ADI_SOYADI"));
			parameters.put("BASVURU_TARIHI", oMap.getString(tableName, 0, "BASVURU_TARIHI"));
			parameters.put("BAGLI_KREDI_NITELIGI", oMap.getString(tableName, 0, "BAGLI_KREDI_NITELIGI"));
			parameters.put("BANKA_ADI", oMap.getString(tableName, 0, "BANKA_ADI"));
			parameters.put("BANKA_ADRES", oMap.getString(tableName, 0, "BANKA_ADRES"));
			parameters.put("TRX_NO", oMap.getBigDecimal(tableName, 0, "TRX_NO"));
			parameters.put("HESAP_NO", birBasvuru.getHesapNo());
			parameters.put("KANAL_KODU", birBasvuru.getKanalKodu());
			parameters.put("PRIM_TUTARI", birBasvuru.getSigortaPrimi());
			parameters.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
			parameters.put("TELEFON", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));
			String adres = (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.basvuru_sozlesme_adres(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("ADRES", adres);
			parameters.put("WEB_SATIS_KANALI", "PTT_SMS");
			parameters.put("TARIM_EH", "H");
			oMap.remove(tableName);

			List<String> reportNames = new ArrayList<String>();

			List<?> list = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "SMS_CREDIT_REPORT_DOCS")).addOrder(Order.asc("siraNo")).list();

			Iterator<?> iterator = list.iterator();

			while (iterator.hasNext()) {

				GnlParamText param = (GnlParamText) iterator.next();
				reportNames.add(param.getText());
			}

			iMap.put("SAVE_DOCUMENT", true);
			iMap.put("DOCUMENT_CODE", documentCode);
			iMap.put("CUSTOMER_NO", birBasvuru.getMusteriNo());
			iMap.put("REFERENCE", iMap.getBigDecimal("BASVURU_NO"));
			iMap.put("REFERENCE_TYPE", referenceType);
			iMap.put("MSISDN", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));

			if (iMap.getBoolean("OTOMATIK_KULLANDIRIM")) {
				iMap.put("MESSAGE_NO", "5985");
				iMap.put("MESSAGE_CONTENT", new GMMap().put("P2", parameters.get("ADI_SOYADI").toString()).put("P3", iMap.getString("BASVURU_NO")).put("P4", birBasvuru.getOnayTutar()));
			}
			else {
				iMap.put("MESSAGE_NO", messageNo);
				iMap.put("MESSAGE_CONTENT", new GMMap().put("P2", parameters.get("ADI_SOYADI").toString()).put("P3", iMap.getString("BASVURU_NO")));
			}
			parameters.put("KISISEL_BILGILER_GIZLE_EH", "E");
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			iMap.put("DOCUMENT_PARAMETERS", parameters);
			
			iMap.remove("TRX_NO");
			oMap = GMServiceExecuter.call("BNSPR_COMMON_SEND_QS_DOCUMENT", iMap);

			iMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());

			// DYS TBUBF
			reportNames = new ArrayList<String>();
			reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_PTT_SMS");
			reportNames.add("BNSPR_TEMEL_BANKACILIK_URUN_BILGI_FORMU_PTT_SMS_2");
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			iMap.put("DOKUMAN_KOD", "2050");
			putSmsDocsToDys(iMap);

			// DYS SOBF
			reportNames = new ArrayList<String>();
			reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU_PTT_SMS_1");
			reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU_PTT_2");
			reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU_PTT_SMS_3");
			reportNames.add("BNSPR_RAP3171_SOBF_ODEME_PLANI_PTT_SMS");
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			parameters.put("KISISEL_BILGILER_GIZLE_EH", "H");
			iMap.put("DOCUMENT_PARAMETERS", parameters);
			iMap.put("DOKUMAN_KOD", "2048");
			putSmsDocsToDys(iMap);

			// DYS KBF
			reportNames = new ArrayList<String>();
			reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU_PTT_SMS");
			reportNames.add("BNSPR_RAP3171_KREDI_BILGI_FORMU_2");
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			iMap.put("DOKUMAN_KOD", "2049");
			putSmsDocsToDys(iMap);

			// DYS Odeme Plani
			reportNames = new ArrayList<String>();
			reportNames.add("BNSPR_RAP3181_KREDI_SART_GERI_ODEME");
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			iMap.put("DOKUMAN_KOD", "2047");
			putSmsDocsToDys(iMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("SMS_REPORT_CREDIT_APPLICATION_EXTRA")
	public static GMMap createSmsExtraApplicationReport(GMMap iMap) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String tableName = "RESULT";
		final String documentCode = "2051", messageNo = "6030", referenceType = "2";

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));

			StringBuilder stb = new StringBuilder();
			stb.append(birBasvuruKimlik.getAd());
			if (StringUtils.isNotBlank(birBasvuruKimlik.getIkinciAd())) {
				stb.append(" ");
				stb.append(birBasvuruKimlik.getIkinciAd());
			}
			stb.append(" ");
			stb.append(birBasvuruKimlik.getSoyad());

			iMap.put("AD_SOYAD", stb.toString());

			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("TARIH", sdf.format(new Date()));
			parameters.put("AD_SOYAD", iMap.getString("AD_SOYAD"));
			parameters.put("PRIM_TUTARI", birBasvuru.getSigortaPrimi());
			parameters.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
			parameters.put("TELEFON", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));
			String adres = (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.basvuru_sozlesme_adres(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("ADRES", adres);
			oMap.remove(tableName);

			List<String> reportNames = new ArrayList<String>();

			reportNames.add("BNSPR_PTT_SMS_PARA_TRANSFER_FORMU");
			reportNames.add("BNSPR_PTT_SMS_SIG_PRIM_TRANSFER_FORMU");

			
			iMap.put("SAVE_DOCUMENT", true);
			iMap.put("DOCUMENT_CODE", documentCode);
			iMap.put("CUSTOMER_NO", birBasvuru.getMusteriNo());
			iMap.put("REFERENCE", iMap.getBigDecimal("BASVURU_NO"));
			iMap.put("REFERENCE_TYPE", referenceType);
			iMap.put("MSISDN", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));
			iMap.put("MESSAGE_NO", messageNo);
			iMap.put("MESSAGE_CONTENT", new GMMap().put("P2", parameters.get("AD_SOYAD").toString()).put("P3", iMap.getString("BASVURU_NO")));
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			iMap.put("DOCUMENT_PARAMETERS", parameters);

			iMap.remove("TRX_NO");
			oMap = GMServiceExecuter.call("BNSPR_COMMON_SEND_QS_DOCUMENT", iMap);

			iMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());

			// DYS Para Transfer Formu
			reportNames = new ArrayList<String>();
			reportNames.add("BNSPR_PTT_SMS_PARA_TRANSFER_FORMU");
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			iMap.put("DOKUMAN_KOD", "2051");
			putSmsDocsToDys(iMap);

			// DYS Sigorta Primi Transfer Formu
			reportNames = new ArrayList<String>();
			reportNames.add("BNSPR_PTT_SMS_SIG_PRIM_TRANSFER_FORMU");
			iMap.put("DOCUMENT_REPORT_NAME", reportNames);
			iMap.put("DOKUMAN_KOD", "2046");
			putSmsDocsToDys(iMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("SMS_REPORT_CREDIT_DYS_UPLOAD")
	public static GMMap putSmsDocsToDys(GMMap iMap) {

		try {
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			JasperPrint jasperPrint;

			@SuppressWarnings("unchecked")
			HashMap<String, Object> parameters = (HashMap<String, Object>) iMap.get("DOCUMENT_PARAMETERS");

			if (iMap.get("DOCUMENT_REPORT_NAME") instanceof List<?>) {
				@SuppressWarnings("unchecked")
				ArrayDeque<String> reportNames = new ArrayDeque<String>((List<String>) iMap.get("DOCUMENT_REPORT_NAME"));
				jasperPrint = ReportUtil.generateAndConcatReports(reportNames, parameters);
			}
			else {
				jasperPrint = ReportUtil.generateReport(iMap.getString("DOCUMENT_REPORT_NAME"), parameters);
			}

			byte[] report = JasperExportManager.exportReportToPdf(jasperPrint);

			GMMap dysMap = new GMMap();
			dysMap.put("DOKUMAN_TIPI", iMap.getString("DOKUMAN_KOD"));
			dysMap.put("REFERANS_TIPI", iMap.getString("REFERENCE_TYPE", "2"));
			dysMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
			dysMap.put("REFERANS_NO", iMap.getString("REFERENCE"));
			dysMap.put("TRX_NO", trxNo);
			dysMap.put("ONAYSIZ_ISLEM_MI", true);
			dysMap.put("DOSYA_SAYFA", 0, "CONTENT", report);
			dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", "MUST_IMAJ_" + iMap.getBigDecimal("MUSTERI_NO").toString() + "_" + iMap.getString("DOKUMAN_KOD") + "_1.pdf");
			dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", 1);

			if (GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap).getBoolean("RESULT")) {
				GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
			}
			else {
				GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
			}

			GMServiceExecuter.execute("BNSPR_MUSTERI_DOKUMAN_EKLE", new GMMap().put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO")).put("DOKUMAN_KODU", iMap.getString("DOKUMAN_KOD")));
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return iMap;
	}

	@GraymoundService("SMS_REPORT_CREDIT_INSURANCE_APPLICATION")
	public static GMMap createCreditInsuranceReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		final String documentCode = "2044", messageNo = "5979", referenceType = "2";

		BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
		BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));

		StringBuilder stb = new StringBuilder();
		stb.append(birBasvuruKimlik.getAd());
		if (StringUtils.isNotBlank(birBasvuruKimlik.getIkinciAd())) {
			stb.append(" ");
			stb.append(birBasvuruKimlik.getIkinciAd());
		}
		stb.append(" ");
		stb.append(birBasvuruKimlik.getSoyad());

		HashMap<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
		parameters.put("AD_SOYAD", new String(stb));
		parameters.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
		parameters.put("TELEFON", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));
		parameters.put("EMAIL", birBasvuruKimlik.getEMail() == null ? "" : birBasvuruKimlik.getEMail());
		String adres = (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.basvuru_sozlesme_adres(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));
		parameters.put("ADRES", adres);
		parameters.put("KRD_BAS_TAR", sdf.format(birBasvuru.getBasvuruTarihi()));
		parameters.put("VADE", birBasvuru.getVade());
		parameters.put("KRD_TUTAR", birBasvuru.getOnayTutar());
		parameters.put("PRIM_TEKLIF_TUTARI", birBasvuru.getSigortaPrimi());
		parameters.put("TARIH", sdf.format(new Date()));
		parameters.put("WEB_SATIS_KANALI", "PTT_SMS");
		parameters.put("TARIM_EH", "H");

		List<String> reportNames = new ArrayList<String>();

		List<?> list = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "SMS_CREDIT_INSURANCE_REPORT_DOCS")).addOrder(Order.asc("siraNo")).list();

		Iterator<?> iterator = list.iterator();

		while (iterator.hasNext()) {

			GnlParamText param = (GnlParamText) iterator.next();
			reportNames.add(param.getText());
		}

		iMap.put("SAVE_DOCUMENT", true);
		iMap.put("DOCUMENT_CODE", documentCode);
		iMap.put("HEADER", ".SGRTAYERI");
		iMap.put("CUSTOMER_NO", birBasvuru.getMusteriNo());
		iMap.put("REFERENCE", iMap.getBigDecimal("BASVURU_NO"));
		iMap.put("REFERENCE_TYPE", referenceType);
		iMap.put("MSISDN", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));
		iMap.put("MESSAGE_NO", messageNo);
		iMap.put("MESSAGE_CONTENT", new GMMap().put("P2", parameters.get("AD_SOYAD").toString()).put("P3", iMap.getString("BASVURU_NO")));
		iMap.put("DOCUMENT_REPORT_NAME", reportNames);
		iMap.put("DOCUMENT_PARAMETERS", parameters);
		
		iMap.remove("TRX_NO");
		oMap = GMServiceExecuter.call("BNSPR_COMMON_SEND_QS_DOCUMENT", iMap);

		iMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());

		// DYS Hayat Sigorta Formu
		reportNames = new ArrayList<String>();
		reportNames.add("BNSPR_KREDI_BAGLANTILI_HAYAT_SIG_FORMU");
		reportNames.add("BNSPR_KREDI_BAGLANTILI_HAYAT_SIG_FORMU_2");
		reportNames.add("BNSPR_KREDI_BAGLANTILI_HAYAT_SIG_FORMU_3");
		iMap.put("DOCUMENT_REPORT_NAME", reportNames);
		iMap.put("DOKUMAN_KOD", "2044");
		putSmsDocsToDys(iMap);

		// DYS Hayat Sigorta Formu
		reportNames = new ArrayList<String>();
		reportNames.add("BNSPR_RAP3181_PTT_SIGORTA_SOZLESME");
		iMap.put("DOCUMENT_REPORT_NAME", reportNames);
		iMap.put("DOKUMAN_KOD", "2045");
		putSmsDocsToDys(iMap);

		// DYS Hayat Sigorta Formu
		reportNames = new ArrayList<String>();
		reportNames.add("BNSPR_BROKER_YETKILENDIRME_MEKTUBU");
		iMap.put("DOCUMENT_REPORT_NAME", reportNames);
		iMap.put("DOKUMAN_KOD", "2052");
		putSmsDocsToDys(iMap);

		// KVKK Aydinlatma Metni SMS'i
		GMMap smsMap = new GMMap();

		iMap.put("MESSAGE_NO", new BigDecimal(5981));
		String mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE");
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));

		smsMap.put("CONTENT", mesaj);
		smsMap.put("MSISDN", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));
		smsMap.put("FILTER", true);
		smsMap.put("HEADER", ".SGRTAYERI");
		smsMap.put("SECURE_CONTENT", true);
		smsMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
		smsMap.put("TRX_NO", trxNo);
		GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC", smsMap);

		return oMap;
	}

	@GraymoundService("INTERNET_REPORT_CREDIT_APPLICATION")
	public static GMMap createCreditApplicationReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String paramText = "";
		String kanalKodu = "";
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));

			if (StringUtils.isEmpty(iMap.getString("KANAL_KOD"))) {
				kanalKodu = birBasvuru.getKanalKodu();
			}
			else {
				kanalKodu = iMap.getString("KANAL_KOD");
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select text from gnl_param_text where kod = 'KREDI_BILGI_FORMU' and key1 = ?");

			if ("2".equals(kanalKodu) && !"1".equals(iMap.getString("CASH_CREDIT"))) {
				stmt.setString(1, "1");
			}
			else {
				stmt.setString(1, "2");
			}

			rSet = stmt.executeQuery();
			while (rSet.next()) {
				paramText = rSet.getString(1);
			}

			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			JasperPrint jasperPrint = null;
			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				parameters.put("PARAM_TEXT", paramText.replace("kredi", "finansman"));
				jasperPrint = ReportUtil.generateReport("BNSPR_RAP3171_KREDI_BASVURU_FORMU_FZ", parameters);
			}
			else {
				parameters.put("PARAM_TEXT", paramText);
				jasperPrint = ReportUtil.generateReport("BNSPR_RAP3171_KREDI_BASVURU_FORMU", parameters);
			}

			oMap.put("REPORT", jasperPrint);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("INTERNET_REPORT_SIM_PAYMENT_PLAN")
	public static GMMap createSimPaymentPlanReport(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			HashMap<String, Object> parameters = new HashMap<String, Object>();

			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("TUTAR", iMap.getBigDecimal("TUTAR"));
			parameters.put("BAZ_FAIZ", iMap.getBigDecimal("BAZ_FAIZ"));
			parameters.put("VADE", iMap.getBigDecimal("VADE"));
			parameters.put("DOVIZ_KODU", iMap.getString("DOVIZ_KODU"));
			parameters.put("SOZLESME_FAIZI", iMap.getBigDecimal("SOZLESME_FAIZI"));
			parameters.put("ODEME_SEKLI", GMServiceExecuter.execute("BNSPR_QRY3183_GET_ODEME_TIP", iMap).get("ODEME_SEKLI"));
			parameters.put("KATILIM_BEDELI", iMap.getBigDecimal("KATILIM_BEDELI"));
			parameters.put("DOSYA_MASRAFI", iMap.getBigDecimal("DOSYA_MASRAFI"));

			ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
			String listName = "PAYMENT_PLAN";
			for (int i = 0; i < iMap.getSize(listName); i++) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();

				rowData.put("OP_TAKSIT_TARIHI", iMap.getDate(listName, i, "OP_TAKSIT_TARIHI"));
				rowData.put("OP_TAKSIT_TUTAR", iMap.getBigDecimal(listName, i, "OP_TAKSIT_TUTAR"));
				rowData.put("OP_ANAPARA", iMap.getBigDecimal(listName, i, "OP_ANAPARA"));
				rowData.put("OP_FAIZ", iMap.getBigDecimal(listName, i, "OP_FAIZ"));
				rowData.put("OP_KKDF", iMap.getBigDecimal(listName, i, "OP_KKDF"));
				rowData.put("OP_BSMV", iMap.getBigDecimal(listName, i, "OP_BSMV"));
				rowData.put("OP_KALAN_TUTAR", iMap.getBigDecimal(listName, i, "OP_KALAN_TUTAR"));
				rowData.put("OP_TAKSIT_NO", i + 1);
				rowData.put("OP_MASRAF", new BigDecimal(0));
				rowData.put("OP_AYLIK_TOPLAM", iMap.getBigDecimal(listName, i, "OP_AYLIK_TOPLAM"));
				rowData.put("GRP", new BigDecimal(1 + i / 12));

				list.add(rowData);
			}
			parameters.put("REPORT_DATA", list);
			JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3171_SIM_ODEME_PLANI", parameters);
			oMap.put("REPORT", jasperPrint);

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	public static JasperPrint generateAndConcatReports(ArrayDeque<String> reportNames, HashMap<String, Object> parameters) throws Exception {
		if (reportNames == null || reportNames.size() == 0) {
			return null;
		}
		JasperPrint result = ReportUtil.generateReport(reportNames.poll(), parameters);
		JasperPrint tmp;
		while (!reportNames.isEmpty()) {
			tmp = ReportUtil.generateReport(reportNames.poll(), parameters);
			for (JRPrintPage jasperPrintPage : (List<JRPrintPage>) tmp.getPages()) {
				result.addPage(jasperPrintPage);
			}
		}

		return result;
	}

	@GraymoundService("INTERNET_REPORT_ESYA_SIGORTASI")
	public static GMMap createEsyaSigortasi(GMMap iMap) {
		GMMap oMap = new GMMap();
		boolean guvenceForm = false;
		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));

			iMap.put("PARAMETRE", "SIGORTA_GUVENCE_FORM_URUN");
			String urunParam = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).getString("DEGER");

			if (!"".equals(urunParam)) {
				String[] urunList = urunParam.split("-");
				Session session = DAOSession.getSession("BNSPRDal");
				List<?> sigortaList = session.createCriteria(BirBasvuruSigortaSatis.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				for (Iterator<?> iterator = sigortaList.iterator(); iterator.hasNext();) {
					BirBasvuruSigortaSatis birBasvuruSigortaSatis = (BirBasvuruSigortaSatis) iterator.next();
					for (int i = 0; i < urunList.length; i++) {
						if (urunList[i].equals(birBasvuruSigortaSatis.getId().getSigortaUrunNo().toString())) {
							guvenceForm = true;
						}
					}
				}
			}

			ArrayDeque<String> reports = new ArrayDeque<String>();

			if (guvenceForm) {
				reports.add("BNSPR_BAYI_KREDI_AYDINLATMA_FORMU");
				reports.add("BNSPR_BAYI_KREDI_AYDINLATMA_FORMU_2");
				reports.add("BNSPR_BAYI_KREDI_AYDINLATMA_FORMU_3");
				reports.add("BNSPR_BAYI_KREDI_AYDINLATMA_FORMU_4");
				reports.add("BNSPR_BAYI_KREDI_AYDINLATMA_FORMU_5");
			}
			else {
				reports.add("BNSPR_BAYI_KREDI_BAGLANTILI_SIGORTA_SOZLESMESI");
				reports.add("BNSPR_BAYI_KREDI_BAGLANTILI_SIGORTA_SOZLESMESI_1");
				reports.add("BNSPR_BAYI_KREDI_BAGLANTILI_SIGORTA_SOZLESMESI_2");
				reports.add("BNSPR_BAYI_KREDI_BAGLANTILI_SIGORTA_SOZLESMESI_3");
				reports.add("BNSPR_BAYI_KREDI_BAGLANTILI_SIGORTA_SOZLESMESI_4");
				reports.add("BNSPR_BAYI_KREDI_BAGLANTILI_SIGORTA_SOZLESMESI_5");
				reports.add("BNSPR_BAYI_KREDI_BAGLANTILI_SIGORTA_SOZLESMESI_6");
			}
			oMap.put("REPORT", generateAndConcatReports(reports, parameters));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_INTELLIGENCE_REPORT_Q3903")
	public static GMMap OpenTcmbBireysel(GMMap iMap) {

		GMMap oMap = new GMMap();
		String pattern = "dd/MM/yyyy";
		SimpleDateFormat format = new SimpleDateFormat(pattern);

		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();

			parameters.put("SORGU_NO", (iMap.getString("SORGU_NO") != null) ? iMap.getString("SORGU_NO") : "");
			parameters.put("BASVURU_NO", (iMap.getString("BASVURU_NO") != null) ? iMap.getString("BASVURU_NO") : "");
			parameters.put("TC_KIMLIK_NO", (iMap.getBigDecimal("TC_KIMLIK_NO") != null) ? iMap.getBigDecimal("TC_KIMLIK_NO") + "" : "");
			parameters.put("AD", (iMap.getString("AD") != null) ? iMap.getString("AD") : "");
			parameters.put("AD2", (iMap.getString("AD2") != null) ? iMap.getString("AD2") : "");
			parameters.put("SOYAD", (iMap.getString("SOYAD") != null) ? iMap.getString("SOYAD") : "");
			parameters.put("ONCEKI_SOYAD", (iMap.getString("ONCEKI_SOYAD") != null) ? iMap.getString("ONCEKI_SOYAD") : "");
			parameters.put("DOGUM_TARIHI", (iMap.getDate("DOGUM_TARIHI") != null) ? format.format(iMap.getDate("DOGUM_TARIHI")) : "");
			parameters.put("DOGUM_YERI", (iMap.getString("DOGUM_YERI") != null) ? iMap.getString("DOGUM_YERI") : "");
			parameters.put("BABA_ADI", (iMap.getString("BABA_ADI") != null) ? iMap.getString("BABA_ADI") : "");
			parameters.put("ANNE_ADI", (iMap.getString("ANNE_ADI") != null) ? iMap.getString("ANNE_ADI") : "");
			parameters.put("NUFUS_CUZDAN_SERI_NO", (iMap.getString("NUFUS_CUZDAN_SERI_NO") != null) ? iMap.getString("NUFUS_CUZDAN_SERI_NO") : "");
			parameters.put("NUFUS_CUZDAN_SIRA_NO", (iMap.getString("NUFUS_CUZDAN_SIRA_NO") != null) ? iMap.getString("NUFUS_CUZDAN_SIRA_NO") : "");
			parameters.put("ANNE_KIZLIK_SOYADI", (iMap.getString("ANNE_KIZLIK_SOYADI") != null) ? iMap.getString("ANNE_KIZLIK_SOYADI") : "");
			parameters.put("VKN", (iMap.getString("VKN") != null) ? iMap.getString("VKN") : "");
			parameters.put("EV_ADRESI", (iMap.getString("EV_ADRESI") != null) ? iMap.getString("EV_ADRESI") : "");
			parameters.put("EV_IL", (iMap.getString("EV_IL") != null) ? iMap.getString("EV_IL") : "");
			parameters.put("EV_ILCE", (iMap.getString("EV_ILCE") != null) ? iMap.getString("EV_ILCE") : "");
			parameters.put("SENET_IL", (iMap.getString("SENET_IL") != null) ? iMap.getString("SENET_IL") : "");
			parameters.put("IS_ADRESI", (iMap.getString("IS_ADRESI") != null) ? iMap.getString("IS_ADRESI") : "");
			parameters.put("IS_IL", (iMap.getString("IS_IL") != null) ? iMap.getString("IS_IL") : "");
			parameters.put("IS_ILCE", (iMap.getString("IS_ILCE") != null) ? iMap.getString("IS_ILCE") : "");

			List<Map<String, Object>> krediList = (List<Map<String, Object>>) iMap.get("KREDI_TABLE");
			if (krediList != null && !krediList.isEmpty()) {

				for (Map<String, Object> list : krediList) {
					for (String key : list.keySet()) {
						list.put(key, list.get(key) != null ? list.get(key).toString() : "");
					}
				}

				parameters.put("TABLE_KREDI", krediList);
			}
			else {
				parameters.put("TABLE_HATA_KREDI", "Sorgu kriterine uygun kayıt bulunmamaktadır.");
			}

			List<Map<String, Object>> cekList = (List<Map<String, Object>>) iMap.get("CEK_TABLE");
			if (cekList != null && !cekList.isEmpty()) {

				for (Map<String, Object> list : cekList) {
					for (String key : list.keySet()) {
						list.put(key, list.get(key) != null ? list.get(key).toString() : "");
					}
				}

				parameters.put("TABLE_CEK", cekList);
			}
			else {
				parameters.put("TABLE_HATA_CEK", "Sorgu kriterine uygun kayıt bulunmamaktadır.");
			}

			List<Map<String, Object>> mahkemeList = (List<Map<String, Object>>) iMap.get("MAHKEME_TABLE");
			if (mahkemeList != null && !mahkemeList.isEmpty()) {

				for (Map<String, Object> list : mahkemeList) {
					for (String key : list.keySet()) {
						list.put(key, list.get(key) != null ? list.get(key).toString() : "");
					}
				}

				parameters.put("TABLE_MAHKEME", mahkemeList);
			}
			else {
				parameters.put("TABLE_HATA_MAHKEME", "Sorgu kriterine uygun kayıt bulunmamaktadır.");
			}

			List<Map<String, Object>> senetList = (List<Map<String, Object>>) iMap.get("SENET_TABLE");
			if (senetList != null && !senetList.isEmpty()) {

				for (Map<String, Object> list : senetList) {
					for (String key : list.keySet()) {
						list.put(key, list.get(key) != null ? list.get(key).toString() : "");
					}
				}

				parameters.put("TABLE_SENET", senetList);
			}
			else {
				parameters.put("TABLE_HATA_SENET", "Sorgu kriterine uygun kayıt bulunmamaktadır.");
			}

			ArrayDeque<String> reports = new ArrayDeque<String>();

			reports.add("Q3903_TCMB_Manuel_Sorgu_Bireysel");

			JasperPrint jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);

			oMap.put("REPORT", jasperPrint);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("INTERNET_REPORT_INCENTIVE_EXPENSE_BILL")
	public static GMMap createInternetIncentiveExpenseBill(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			String tableName = "RESULTS";
			int i = 0;
			parameters.put("TX_NO", iMap.getString(tableName, i, "TX_NO"));
			parameters.put("ISIN_MAHIYETI", iMap.getString(tableName, i, "ISIN_MAHIYETI"));
			parameters.put("ADET", iMap.getString(tableName, i, "ADET"));
			parameters.put("TUTARI", iMap.getString(tableName, i, "TUTARI"));
			parameters.put("GV_TUTARI", iMap.getString(tableName, i, "GV_TUTARI"));
			parameters.put("KESINTI_TOPLAMI", iMap.getString(tableName, i, "KESINTI_TOPLAMI"));
			parameters.put("ODENECEK_NET_TUTAR", iMap.getString(tableName, i, "ODENECEK_NET_TUTAR"));
			parameters.put("NET_TUTAR_YAZI_ILE", iMap.getString(tableName, i, "NET_TUTAR_YAZI_ILE"));
			parameters.put("BANKA_ADRES", iMap.getString("BANKA_ADRES"));
			parameters.put("ADI_SOYADI", iMap.getString(tableName, i, "ADI_SOYADI"));
			parameters.put("CEP_NO", iMap.getString(tableName, i, "CEP_NO"));
			parameters.put("TC_KIMLIK_NO", iMap.getString(tableName, i, "TC_KIMLIK_NO"));
			parameters.put("IBAN", StringUtils.isNotBlank(iMap.getString(tableName, i, "IBAN")) ? iMap.getString(tableName, i, "IBAN") : "");
			parameters.put("ADRES", iMap.getString(tableName, i, "ADRES"));
			parameters.put("TARIH", sdf.format(new java.util.Date()));
			parameters.put("FON_PAYI", iMap.getString(tableName, i, "FON_PAYI"));
			parameters.put("GELIR_VERGISI_ORANI", iMap.getString(tableName, i, "GELIR_VERGISI_ORANI"));
			JasperPrint jasperPrint = ReportUtil.generateReport("TESVIK_GIDER_PUSULA", parameters);
			oMap.put("REPORT", jasperPrint);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_HAKEM_HEYET_IADE_TEXT")
	public static GMMap hakemHeyetIadeText(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();

			for (int i = 0; i < iMap.getSize("TABLE"); i++) {
				parameters.put("AD_SOYAD", iMap.getString("TABLE", i, "AD_SOYAD"));
				parameters.put("TC_KIMLIK_NO", iMap.getString("TABLE", i, "TC_KIMLIK_NO"));
				parameters.put("IADE_TIP_TEXT", iMap.getString("TABLE", i, "IADE_TIP_TEXT"));
				parameters.put("IADE_TIP_TEXT2", iMap.getString("TABLE", i, "IADE_TIP_TEXT2"));
				parameters.put("ADRES", iMap.getString("TABLE", i, "ADRES"));
				parameters.put("IADE_TUTAR", iMap.getBigDecimal("TABLE", i, "IADE_TUTAR"));
				parameters.put("IADE_TARIH", sdf.format(iMap.getDate("TABLE", i, "IADE_TARIHI")));
				parameters.put("HESAP_NO", iMap.getString("TABLE", i, "HESAP_NO"));
				parameters.put("TARIH", sdf.format(new java.util.Date()));
				oMap.put("REPORT_" + i, ReportUtil.generateReport("HAKEM_HEYET_IADE", parameters));
				oMap.put("REPORT_COUNT", i + 1);
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		oMap.putAll(printAll(oMap));

		return oMap;
	}

	public static GMMap printAll(GMMap iMap) {
		GMMap oMap = new GMMap();
		JasperPrint tmp;
		JasperPrint result = (JasperPrint) iMap.get("REPORT_0");

		for (int j = 1; j < iMap.getInt("REPORT_COUNT"); j++) {
			tmp = (JasperPrint) iMap.get("REPORT_" + j);
			for (Object jasperPrintPage : tmp.getPages()) {
				result.addPage((JRPrintPage) jasperPrintPage);
			}
		}
		oMap.put("REPORT_ALL", result);
		return oMap;
	}

	@GraymoundService("BNSPR_KK_IHTAR_RAPOR")
	public static GMMap kkIhtarReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			int i;
			for (i = 0; i < iMap.getSize("MUSTERI_LIST"); i++) {
				HashMap<String, Object> parameters = new HashMap<String, Object>();
				parameters.put("ADRES", iMap.getString("MUSTERI_LIST", i, "ADRES"));
				parameters.put("AD_SOYAD", iMap.getString("MUSTERI_LIST", i, "AD_SOYAD"));
				parameters.put("TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
				parameters.put("TARIH", sdf.format(new java.util.Date()));
				parameters.put("TOPLAM_BORC", iMap.getString("MUSTERI_LIST", i, "TOPLAM_BORC"));
				parameters.put("IHTAR_MASRAF", iMap.getString("MUSTERI_LIST", i, "IHTAR_MASRAF"));
				for (int j = 0, k = 0; j < iMap.getSize("KREDI_LIST"); j++) {
					if (iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO").equals(iMap.getString("KREDI_LIST", j, "MUSTERI_NO"))) {
						iMap.put("TEMP_KREDI_LIST", k, "MUSTERI_NO", iMap.getString("KREDI_LIST", j, "MUSTERI_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "KART_NO", iMap.getString("KREDI_LIST", j, "KART_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "BAGLI_HESAP_NO", iMap.getString("KREDI_LIST", j, "BAGLI_HESAP_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "IBAN", iMap.getString("KREDI_LIST", j, "IBAN"));
						iMap.put("TEMP_KREDI_LIST", k, "ASGARI_ODEME_TUTAR", iMap.getString("KREDI_LIST", j, "ASGARI_ODEME_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "ANAPARA_TUTAR", iMap.getString("KREDI_LIST", j, "ANAPARA_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "GECIKME_FAIZ_TUTAR", iMap.getString("KREDI_LIST", j, "GECIKME_FAIZ_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "KKDF_TUTAR", iMap.getString("KREDI_LIST", j, "KKDF_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "BSMV_TUTAR", iMap.getString("KREDI_LIST", j, "BSMV_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "TOPLAM_BORC_TUTARI", iMap.getString("KREDI_LIST", j, "TOPLAM_BORC_TUTARI"));
						iMap.put("TEMP_KREDI_LIST", k, "TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
						k++;
					}
				}
				List<?> liste = (List<?>) iMap.get("TEMP_KREDI_LIST");
				iMap.remove("TEMP_KREDI_LIST");
				parameters.put("TABLE_DATA", liste);
				oMap.put("REPORT_" + i, ReportUtil.generateReport("KK_IHTAR", parameters));
				GMMap dysMap = new GMMap();
				GMMap trxMap = new GMMap();
				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				dysMap.put("TRX_NO", trxMap.getString("TRX_NO"));
				dysMap.put("REFERANS_TIPI", "");
				dysMap.put("REFERANS_NO", "");
				dysMap.put("MUSTERI_NO", StringUtils.leftPad(iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO"), 8, "0"));
				dysMap.put("TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
				dysMap.put("DOKUMAN_TIPI", KK_IHTARNAME_DOKUMAN_KOD);
				dysMap.put("DOKUMAN_ADI", iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO") + "_" + KMH_IHTARNAME_DOKUMAN_KOD + "_IHTARNAME_" + iMap.getString("MUSTERI_LIST", i, "SORGU_NO") + ".pdf");
				JasperPrint doc = (JasperPrint) oMap.get("REPORT_" + i);
				byte[] report = JasperExportManager.exportReportToPdf(doc);
				dysMap.put("DOSYA_SAYFA", 0, "CONTENT", report);
				dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO") + "_" + BK_IHTARNAME_DOKUMAN_KOD + "_IHTARNAME_" + iMap.getString("MUSTERI_LIST", i, "SORGU_NO") + ".pdf");
				dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", 1);
				dysMap.put("TRX_ONAYSIZ_ISLEM", "E");
				GMMap isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
				if (isExistMap.getBoolean("RESULT")) {
					GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
				}
				else {
					GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
				}
			}
			oMap.put("REPORT_COUNT", i);

			oMap.putAll(printAll(oMap));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_NOTER_IHTAR_RAPOR")
	public static GMMap noterIhtarReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			int i;
			for (i = 0; i < iMap.getSize("MUSTERI_LIST"); i++) {
				HashMap<String, Object> parameters = new HashMap<String, Object>();
				parameters.put("ADRES", iMap.getString("MUSTERI_LIST", i, "ADRES"));
				parameters.put("AD_SOYAD", iMap.getString("MUSTERI_LIST", i, "AD_SOYAD"));
				parameters.put("TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
				parameters.put("TARIH", sdf.format(new java.util.Date()));
				parameters.put("BANKA_ADRES", "B�y�kdere Cad. No:163 Zincirlikuyu �i�li 34394"); // Parametrik olacak.
				parameters.put("TOPLAM_BORC", iMap.getString("MUSTERI_LIST", i, "TOPLAM_BORC"));
				parameters.put("IHTAR_MASRAF", iMap.getString("MUSTERI_LIST", i, "IHTAR_MASRAF"));
				for (int j = 0, k = 0; j < iMap.getSize("KREDI_LIST"); j++) {
					if (iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO").equals(iMap.getString("KREDI_LIST", j, "MUSTERI_NO"))) {
						iMap.put("TEMP_KREDI_LIST", k, "MUSTERI_NO", iMap.getString("KREDI_LIST", j, "MUSTERI_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "BASVURU_NO", iMap.getString("KREDI_LIST", j, "BASVURU_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "BAGLI_HESAP_NO", iMap.getString("KREDI_LIST", j, "BAGLI_HESAP_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "IBAN", iMap.getString("KREDI_LIST", j, "IBAN"));
						iMap.put("TEMP_KREDI_LIST", k, "KULLANDIRIM_TARIH", iMap.getString("KREDI_LIST", j, "KULLANDIRIM_TARIH"));
						iMap.put("TEMP_KREDI_LIST", k, "KULLANDIRIM_TUTAR", iMap.getString("KREDI_LIST", j, "KULLANDIRIM_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "FAIZ_ORAN", iMap.getString("KREDI_LIST", j, "FAIZ_ORAN"));
						iMap.put("TEMP_KREDI_LIST", k, "YILLIK_FAIZ_ORAN", iMap.getString("KREDI_LIST", j, "YILLIK_FAIZ_ORAN"));
						iMap.put("TEMP_KREDI_LIST", k, "TEMERRUT_ORAN", iMap.getString("KREDI_LIST", j, "TEMERRUT_ORAN"));
						iMap.put("TEMP_KREDI_LIST", k, "TAKSIT_TUTAR", iMap.getString("KREDI_LIST", j, "TAKSIT_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "GECIKMIS_TAKSIT_SAYI", iMap.getString("KREDI_LIST", j, "GECIKMIS_TAKSIT_SAYI"));
						iMap.put("TEMP_KREDI_LIST", k, "GECIKMIS_TAKSIT_TUTAR", iMap.getString("KREDI_LIST", j, "GECIKMIS_TAKSIT_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "GECIKME_FAIZ_TUTAR", iMap.getString("KREDI_LIST", j, "GECIKME_FAIZ_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "ODENMEMIS_TAKSIT_TOPLAM", iMap.getString("KREDI_LIST", j, "ODENMEMIS_TAKSIT_TOPLAM"));
						iMap.put("TEMP_KREDI_LIST", k, "TOPLAM_BORC_TUTARI", iMap.getString("KREDI_LIST", j, "TOPLAM_BORC_TUTARI"));
						k++;
						// if(k==3)
						// break;
					}
				}
				List<?> liste = (List<?>) iMap.get("TEMP_KREDI_LIST");
				iMap.remove("TEMP_KREDI_LIST");
				parameters.put("TABLE_DATA", liste);
				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_FAIZSIZ_FINANSMAN_EH", new GMMap().put("MUSTERI_NO", iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO"))));
				if ("E".equals(iMap.getString("FAIZSIZ_FINANSMAN"))) {
					if (iMap.getSize("TEMP_KREDI_LIST") < 6 && iMap.getString("TIP").equals("NOTER")) {
						oMap.put("REPORT_" + i, ReportUtil.generateReport("NOTER_IHTAR_S_FZ", parameters));
					}
					else if (iMap.getSize("TEMP_KREDI_LIST") >= 6 && iMap.getString("TIP").equals("NOTER")) {
						oMap.put("REPORT_" + i, ReportUtil.generateReport("NOTER_IHTAR_L_FZ", parameters));
					}
					else {
						oMap.put("REPORT_" + i, ReportUtil.generateReport("APS_IHTAR_FZ", parameters));
					}
				}
				else {
					if (iMap.getSize("TEMP_KREDI_LIST") < 6 && iMap.getString("TIP").equals("NOTER")) {
						oMap.put("REPORT_" + i, ReportUtil.generateReport("NOTER_IHTAR_S", parameters));
					}
					else if (iMap.getSize("TEMP_KREDI_LIST") >= 6 && iMap.getString("TIP").equals("NOTER")) {
						oMap.put("REPORT_" + i, ReportUtil.generateReport("NOTER_IHTAR_L", parameters));
					}
					else {
						oMap.put("REPORT_" + i, ReportUtil.generateReport("APS_IHTAR", parameters));
					}
				}

				// ihtarnameyi DYS musteri dokumanlarina kaydet
				GMMap dysMap = new GMMap();
				GMMap trxMap = new GMMap();
				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				dysMap.put("TRX_NO", trxMap.getString("TRX_NO"));
				dysMap.put("REFERANS_TIPI", "");
				dysMap.put("REFERANS_NO", "");

				dysMap.put("MUSTERI_NO", StringUtils.leftPad(iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO"), 8, "0"));
				dysMap.put("TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
				dysMap.put("DOKUMAN_TIPI", BK_IHTARNAME_DOKUMAN_KOD);
				dysMap.put("DOKUMAN_ADI", iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO") + "_" + BK_IHTARNAME_DOKUMAN_KOD + "_IHTARNAME_" + iMap.getString("MUSTERI_LIST", i, "SORGU_NO") + ".pdf");
				JasperPrint doc = (JasperPrint) oMap.get("REPORT_" + i);
				byte[] report = JasperExportManager.exportReportToPdf(doc);
				dysMap.put("DOSYA_SAYFA", 0, "CONTENT", report);
				dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", 1);

				dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO") + "_" + BK_IHTARNAME_DOKUMAN_KOD + "_IHTARNAME_" + iMap.getString("MUSTERI_LIST", i, "SORGU_NO") + ".pdf");
				dysMap.put("TRX_ONAYSIZ_ISLEM", "E");
				GMMap isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
				if (isExistMap.getBoolean("RESULT")) {
					GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
				}
				else {
					GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
				}

			}
			oMap.put("REPORT_COUNT", i);

			oMap.putAll(printAll(oMap));

			return oMap;

		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_NOTER_KMH_IHTAR_RAPOR")
	public static GMMap noterKMHIhtarReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			int i;
			for (i = 0; i < iMap.getSize("MUSTERI_LIST"); i++) {
				HashMap<String, Object> parameters = new HashMap<String, Object>();
				parameters.put("ADRES", iMap.getString("MUSTERI_LIST", i, "ADRES"));
				parameters.put("AD_SOYAD", iMap.getString("MUSTERI_LIST", i, "AD_SOYAD"));
				parameters.put("TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
				parameters.put("TARIH", sdf.format(new java.util.Date()));
				parameters.put("BANKA_ADRES", "B�y�kdere Cad. No:163 Zincirlikuyu �i�li 34394"); // Parametrik olacak.
				parameters.put("TOPLAM_BORC", iMap.getString("MUSTERI_LIST", i, "TOPLAM_BORC"));
				parameters.put("IHTAR_MASRAF", iMap.getString("MUSTERI_LIST", i, "IHTAR_MASRAF"));
				for (int j = 0, k = 0; j < iMap.getSize("KREDI_LIST"); j++) {
					if (iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO").equals(iMap.getString("KREDI_LIST", j, "MUSTERI_NO"))) {
						iMap.put("TEMP_KREDI_LIST", k, "MUSTERI_NO", iMap.getString("KREDI_LIST", j, "MUSTERI_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "BASVURU_NO", iMap.getString("KREDI_LIST", j, "BASVURU_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "BAGLI_HESAP_NO", iMap.getString("KREDI_LIST", j, "BAGLI_HESAP_NO"));
						iMap.put("TEMP_KREDI_LIST", k, "IBAN", iMap.getString("KREDI_LIST", j, "IBAN"));
						iMap.put("TEMP_KREDI_LIST", k, "KULLANDIRIM_TARIH", iMap.getString("KREDI_LIST", j, "KULLANDIRIM_TARIH"));
						iMap.put("TEMP_KREDI_LIST", k, "KULLANDIRIM_TUTAR", iMap.getString("KREDI_LIST", j, "KULLANDIRIM_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "FAIZ_ORAN", iMap.getString("KREDI_LIST", j, "FAIZ_ORAN"));
						iMap.put("TEMP_KREDI_LIST", k, "YILLIK_FAIZ_ORAN", iMap.getString("KREDI_LIST", j, "YILLIK_FAIZ_ORAN"));
						iMap.put("TEMP_KREDI_LIST", k, "TEMERRUT_ORAN", iMap.getString("KREDI_LIST", j, "TEMERRUT_ORAN"));
						iMap.put("TEMP_KREDI_LIST", k, "TAKSIT_TUTAR", iMap.getString("KREDI_LIST", j, "TAKSIT_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "GECIKMIS_TAKSIT_SAYI", iMap.getString("KREDI_LIST", j, "GECIKMIS_TAKSIT_SAYI"));
						iMap.put("TEMP_KREDI_LIST", k, "GECIKMIS_TAKSIT_TUTAR", iMap.getString("KREDI_LIST", j, "GECIKMIS_TAKSIT_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "GECIKME_FAIZ_TUTAR", iMap.getString("KREDI_LIST", j, "GECIKME_FAIZ_TUTAR"));
						iMap.put("TEMP_KREDI_LIST", k, "ODENMEMIS_TAKSIT_TOPLAM", iMap.getString("KREDI_LIST", j, "ODENMEMIS_TAKSIT_TOPLAM"));
						iMap.put("TEMP_KREDI_LIST", k, "TOPLAM_BORC_TUTARI", iMap.getString("KREDI_LIST", j, "TOPLAM_BORC_TUTARI"));
						iMap.put("TEMP_KREDI_LIST", k, "ANAPARA_TUTARI", iMap.getString("KREDI_LIST", j, "ANAPARA_TUTARI"));
						iMap.put("TEMP_KREDI_LIST", k, "BSMV_TUTARI", iMap.getString("KREDI_LIST", j, "BSMV_TUTARI"));
						iMap.put("TEMP_KREDI_LIST", k, "KKDF_TUTARI", iMap.getString("KREDI_LIST", j, "KKDF_TUTARI"));
						iMap.put("TEMP_KREDI_LIST", k, "TOPLAM_BORC", iMap.getString("KREDI_LIST", j, "TOPLAM_BORC"));
						k++;
						// if(k==3)
						// break;
					}
				}
				List<?> liste = (List<?>) iMap.get("TEMP_KREDI_LIST");
				iMap.remove("TEMP_KREDI_LIST");
				parameters.put("TABLE_DATA", liste);
				if (iMap.getSize("TEMP_KREDI_LIST") < 6 && iMap.getString("TIP").equals("NOTER")) {
					oMap.put("REPORT_" + i, ReportUtil.generateReport("KMH_IHTAR_S", parameters));
				}
				else if (iMap.getSize("TEMP_KREDI_LIST") >= 6 && iMap.getString("TIP").equals("NOTER")) {
					oMap.put("REPORT_" + i, ReportUtil.generateReport("KMH_IHTAR_L", parameters));
				}
				else {
					oMap.put("REPORT_" + i, ReportUtil.generateReport("KMH_IHTAR", parameters));
				}
				// ihtarnameyi DYS musteri dokumanlarina kaydet
				GMMap dysMap = new GMMap();
				GMMap trxMap = new GMMap();
				trxMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
				dysMap.put("TRX_NO", trxMap.getString("TRX_NO"));
				dysMap.put("REFERANS_TIPI", "");
				dysMap.put("REFERANS_NO", "");

				dysMap.put("MUSTERI_NO", StringUtils.leftPad(iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO"), 8, "0"));
				dysMap.put("TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
				dysMap.put("DOKUMAN_TIPI", KMH_IHTARNAME_DOKUMAN_KOD);
				dysMap.put("DOKUMAN_ADI", iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO") + "_" + KMH_IHTARNAME_DOKUMAN_KOD + "_IHTARNAME_" + iMap.getString("MUSTERI_LIST", i, "SORGU_NO") + ".pdf");
				JasperPrint doc = (JasperPrint) oMap.get("REPORT_" + i);
				byte[] report = JasperExportManager.exportReportToPdf(doc);
				dysMap.put("DOSYA_SAYFA", 0, "CONTENT", report);
				dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO") + "_" + BK_IHTARNAME_DOKUMAN_KOD + "_IHTARNAME_" + iMap.getString("MUSTERI_LIST", i, "SORGU_NO") + ".pdf");
				dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", 1);
				dysMap.put("TRX_ONAYSIZ_ISLEM", "E");
				GMMap isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
				if (isExistMap.getBoolean("RESULT")) {
					GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
				}
				else {
					GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
				}
			}
			oMap.put("REPORT_COUNT", i);

			oMap.putAll(printAll(oMap));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("INTERNET_REPORT_CREDIT_APPLICATION_SOBF")
	public static GMMap createCreditApplicationSobfReport(GMMap iMap) {

		GMMap oMap = new GMMap();
		String tableName = "RESULT";

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));

			HashMap<String, Object> parameters = new HashMap<String, Object>();

			oMap.putAll(DALUtil.callOracleRefCursorFunction("{? = call pkg_ptt_kredi.get_sobf_info(?)}", tableName, BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO")));

			parameters.put("KREDI_TURU", oMap.getString(tableName, 0, "KREDI_TURU"));
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("VADE", oMap.getBigDecimal(tableName, 0, "VADE"));
			parameters.put("ONAY_TUTAR", oMap.getString(tableName, 0, "ONAY_TUTAR"));
			parameters.put("TAKSIT_TUTARI", oMap.getString(tableName, 0, "TAKSIT_TUTARI"));
			parameters.put("AKDI_FAIZ_AYLIK", oMap.getString(tableName, 0, "AKDI_FAIZ_AYLIK"));
			parameters.put("AKDI_FAIZ_YILLIK", oMap.getString(tableName, 0, "AKDI_FAIZ_YILLIK"));
			parameters.put("GECIKME_FAIZ_ORANI", oMap.getString(tableName, 0, "GECIKME_FAIZ_ORANI"));
			parameters.put("EFEKTIF_FAIZ_ORANI_AYLIK", oMap.getString(tableName, 0, "EFEKTIF_FAIZ_ORANI_AYLIK"));
			parameters.put("EFEKTIF_FAIZ_ORANI_YILLIK", oMap.getString(tableName, 0, "EFEKTIF_FAIZ_ORANI_YILLIK"));
			parameters.put("TOPLAM_GERI_ODEME_TUTARI", oMap.getString(tableName, 0, "TOPLAM_GERI_ODEME_TUTARI"));
			parameters.put("KREDI_TAHSIS_UCRETI", oMap.getString(tableName, 0, "KREDI_TAHSIS_UCRETI"));
			parameters.put("URUN_BILGISI", oMap.getString(tableName, 0, "URUN_BILGISI"));
			parameters.put("SATICI_ADI", oMap.getString(tableName, 0, "SATICI_ADI"));
			parameters.put("ADI_SOYADI", oMap.getString(tableName, 0, "ADI_SOYADI"));
			parameters.put("BASVURU_TARIHI", oMap.getString(tableName, 0, "BASVURU_TARIHI"));
			parameters.put("BAGLI_KREDI_NITELIGI", oMap.getString(tableName, 0, "BAGLI_KREDI_NITELIGI"));
			parameters.put("BANKA_ADI", oMap.getString(tableName, 0, "BANKA_ADI"));
			parameters.put("BANKA_ADRES", oMap.getString(tableName, 0, "BANKA_ADRES"));
			parameters.put("TRX_NO", oMap.getBigDecimal(tableName, 0, "TRX_NO"));
			parameters.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
			parameters.put("TELEFON", birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo()));
			String adres = (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.basvuru_sozlesme_adres(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("ADRES", adres);
			parameters.put("KISISEL_BILGILER_GIZLE_EH", iMap.getString("KISISEL_BILGILER_GIZLE_EH","E"));

			ArrayDeque<String> reportNames = new ArrayDeque<String>();
			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				parameters.put("BAGLI_KREDI_NITELIGI", oMap.getString(tableName, 0, "BAGLI_KREDI_NITELIGI").replace("Kredi", "Finansman"));
				reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU_FZ");
				reportNames.add("BNSPR_RAP3171_SOBF_ODEME_PLANI_FZ");
			}
			else {
				reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU");
				reportNames.add("BNSPR_RAP3171_SOBF_ODEME_PLANI");
			}
			JasperPrint jasperPrint = ReportUtil.generateAndConcatReports(reportNames, parameters);
			oMap.put("REPORT", jasperPrint);
			
			if (iMap.getBoolean("DYS_TRANSFER")) {
				reportNames = new ArrayDeque<String>();
				if ("E".equals(birBasvuru.getFaizsizFinansman())) {
					parameters.put("BAGLI_KREDI_NITELIGI", oMap.getString(tableName, 0, "BAGLI_KREDI_NITELIGI").replace("Kredi", "Finansman"));
					reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU_FZ");
					reportNames.add("BNSPR_RAP3171_SOBF_ODEME_PLANI_FZ");
				}
				else {
					reportNames.add("BNSPR_RAP3171_SOZLESME_ONCESI_BILGI_FORMU");
					reportNames.add("BNSPR_RAP3171_SOBF_ODEME_PLANI");
				}
				parameters.put("KISISEL_BILGILER_GIZLE_EH", iMap.getString("KISISEL_BILGILER_GIZLE_EH","H"));
				jasperPrint = ReportUtil.generateAndConcatReports(reportNames, parameters);
				byte[] report = JasperExportManager.exportReportToPdf(jasperPrint);

				GMMap dysMap = new GMMap();
				dysMap.put("DOKUMAN_TIPI", "2062");
				dysMap.put("REFERANS_TIPI","2");
				dysMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
				dysMap.put("REFERANS_NO", iMap.getBigDecimal("BASVURU_NO"));
				dysMap.put("TRX_NO", oMap.getBigDecimal(tableName, 0, "TRX_NO"));
				dysMap.put("ONAYSIZ_ISLEM_MI", true);
				dysMap.put("DOSYA_SAYFA", 0, "CONTENT", report);
				dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", "MUST_IMAJ_" + birBasvuru.getMusteriNo().toString() + "_" + "2062" + "_1.pdf");
				dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", 1);

				if (GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap).getBoolean("RESULT")) {
					GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
				}
				else {
					GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
				}

				GMServiceExecuter.execute("BNSPR_MUSTERI_DOKUMAN_EKLE", new GMMap().put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO")).put("DOKUMAN_KODU", iMap.getString("DOKUMAN_KOD")));
			}
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("INTERNET_REPORT_CREDIT_APPLICATION_AND_SOBF")
	public static GMMap createCreditApplicationAndSobfReport(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			BigDecimal isCashCredit = BigDecimal.ZERO;
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			isCashCredit = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_basvuru.isCashCredit(?)}", Types.NUMERIC, iMap.getBigDecimal("BASVURU_NO"));

			int reportCount = 0;
			oMap.put("REPORT_" + reportCount++, GMServiceExecuter.call("INTERNET_REPORT_CREDIT_APPLICATION_SOBF", iMap).get("REPORT"));
			oMap.put("REPORT_" + reportCount++, GMServiceExecuter.call("INTERNET_REPORT_CREDIT_APPLICATION_SOBF", iMap).get("REPORT"));
			if (BigDecimal.ONE.compareTo(isCashCredit) == 0) {
				iMap.put("CASH_CREDIT", isCashCredit);
				oMap.put("REPORT_" + reportCount++, GMServiceExecuter.call("INTERNET_REPORT_CREDIT_APPLICATION", iMap).get("REPORT"));
			}
			oMap.put("REPORT_COUNT", reportCount);
			oMap.putAll(printAll(oMap));
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}
}
