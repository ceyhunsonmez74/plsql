package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3192Services {
	@GraymoundService("BNSPR_TRN3192_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "SORGU_SEVIYE_KOD", true, "SELECT key1,text FROM gnl_param_text t where kod = 'SORGU_SEVIYE_KOD' order by text");
			DALUtil.fillComboBox(oMap, "TUR_NO", true, "select tur_no,tanim from nbsm_bilgi_pr where aktif = 1");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3192_GET_LIST")
	public static GMMap GetList(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3192.RC_QRY3192_NBSM_Call_Deger(?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++,iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++,iMap.getBigDecimal("TUR_NO"));
			stmt.setString(i++,iMap.getString("SORGU_SEVIYE_KOD"));
			stmt.setString(i++,iMap.getString("KEY"));
			stmt.setString(i++,iMap.getString("I_O"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
		    oMap = DALUtil.rSetResults(rSet, "TABLE");

		return oMap;
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
	
		}
		
	}			

}
