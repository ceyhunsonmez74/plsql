package tr.com.calikbank.bnspr.consumerloan.models.socialscore;

public class Browser {
	private String Version;

    private String Name;

    public String getVersion ()
    {
        return Version;
    }

    public void setVersion (String Version)
    {
        this.Version = Version;
    }

    public String getName ()
    {
        return Name;
    }

    public void setName (String Name)
    {
        this.Name = Name;
    }
}
