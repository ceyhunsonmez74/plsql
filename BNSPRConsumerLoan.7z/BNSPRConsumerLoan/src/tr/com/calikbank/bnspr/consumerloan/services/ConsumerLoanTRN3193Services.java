package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBilgiKodPrTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBilgiKodPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3193Services {

	@GraymoundService("BNSPR_3193_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			iMap.put("KOD", "MESAI_ICI_DISI");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("MESAI_ICI_DISI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "CALISMA_GUNU");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("CALISMA_GUNU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3193_GET_LIST")
	public static GMMap get_mesai_disi_bilgi_pr(GMMap iMap){
		GMMap oMap = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "PR_TABLE";
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3193.get_bir_basvuru_bilgi_kod_pr}");
			int i = 1;
			
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			
			oMap.putAll(DALUtil.rSetResults(rSet, tableName));
		}
		catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3193_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		CallableStatement stmt = null;
		Connection conn = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "PR_TABLE";
			
			List<?> list = (List<?>)iMap.get("PR_TABLE");
			
			conn = DALUtil.getGMConnection();
			
			for (int i = 0; i < list.size(); i++) {
				BirBasvuruBilgiKodPrTx birBasvuruBilgiKodPrTx = new BirBasvuruBilgiKodPrTx();
				BirBasvuruBilgiKodPrTxId birBasvuruBilgiKodPrTxId = new BirBasvuruBilgiKodPrTxId();
				
				birBasvuruBilgiKodPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				
				stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('BIR_BASVURU_BILGI_KOD_PR')}");
				stmt.registerOutParameter(1, Types.NUMERIC);
				stmt.execute();
				
				birBasvuruBilgiKodPrTxId.setId(stmt.getBigDecimal(1));
				birBasvuruBilgiKodPrTx.setId(birBasvuruBilgiKodPrTxId);
				birBasvuruBilgiKodPrTx.setOnayStatuKod(iMap.getString(tableName, i,"ONAY_STATU_KOD"));
				birBasvuruBilgiKodPrTx.setUyariTipi(iMap.getString(tableName, i,"UYARI_TIPI"));
				birBasvuruBilgiKodPrTx.setTelAdres(iMap.getString(tableName, i,"TEL_ADRES"));
				birBasvuruBilgiKodPrTx.setAciklama(iMap.getString(tableName, i,"ACIKLAMA"));
				birBasvuruBilgiKodPrTx.setMesaiIciDisi(iMap.getString(tableName, i,"MESAI_ICI_DISI"));
				birBasvuruBilgiKodPrTx.setCalismaGunu(iMap.getString(tableName, i,"CALISMA_GUNU"));
				birBasvuruBilgiKodPrTx.setIslemTipi(iMap.getString(tableName, i,"ISLEM_TIPI"));
				session.save(birBasvuruBilgiKodPrTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "3193");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			if(e.getCause()!=null)throw new GMRuntimeException(0,e.getCause().getMessage());
			else throw new GMRuntimeException(0,e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3193_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;
		String tableName = "TABLO";
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> birBasvuruBilgiKodPrTxList = session.createCriteria(BirBasvuruBilgiKodPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			int row = 0;
			for (Iterator<?> iterator = birBasvuruBilgiKodPrTxList.iterator(); iterator.hasNext();row++) {
				BirBasvuruBilgiKodPrTx birBasvuruBilgiKodPrTx = (BirBasvuruBilgiKodPrTx) iterator.next();
				oMap.put(tableName, row, "TX_NO", iMap.getBigDecimal("TRX_NO"));
				oMap.put(tableName, row, "ONAY_STATU_KOD", birBasvuruBilgiKodPrTx.getOnayStatuKod());
				oMap.put(tableName, row, "UYARI_TIPI", birBasvuruBilgiKodPrTx.getUyariTipi());
				oMap.put(tableName, row, "TEL_ADRES", birBasvuruBilgiKodPrTx.getTelAdres());
				oMap.put(tableName, row, "ACIKLAMA", birBasvuruBilgiKodPrTx.getAciklama());
				oMap.put(tableName, row, "MESAI_ICI_DISI", birBasvuruBilgiKodPrTx.getMesaiIciDisi());
				oMap.put(tableName, row, "CALISMA_GUNU", birBasvuruBilgiKodPrTx.getCalismaGunu());
				oMap.put(tableName, row, "ISLEM_TIPI", birBasvuruBilgiKodPrTx.getIslemTipi());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
		
		return oMap;
	}
	
}
