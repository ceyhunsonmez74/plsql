package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TicariSicilFirma;
import tr.com.aktifbank.bnspr.dao.TicariSicilFirmaOrtak;
import tr.com.aktifbank.bnspr.dao.TicariSicilFirmaYonetici;
import tr.com.aktifbank.bnspr.dao.TicariSicilKod;
import tr.com.aktifbank.bnspr.dao.TicariSicilTescilKonu;
import tr.com.aktifbank.bnspr.dao.TicariSicililanDetay;
import tr.com.aktifbank.bnspr.dao.TicariSicililanDevir;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3940Services {

	@GraymoundService("BNSPR_QRY3940_INITIALIZE")
	public static GMMap intialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		return oMap;
	}

	@GraymoundService("BNSPR_QRY3940_TESCIL_ILLERI")
	public static GMMap tescilIlleri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		List<TicariSicilKod> kodlar = session.createCriteria(TicariSicilKod.class).add(Restrictions.eq("listeId", new BigDecimal(4))).list();

		String tableName = "TESCIL_IL_LISTE";
		GuimlUtil.wrapMyCombo(oMap, tableName, "", "");

		for (TicariSicilKod kod : kodlar) {
			GuimlUtil.wrapMyCombo(oMap, tableName, kod.getKod().toString(), kod.getAciklama());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_QRY3940_TESCIL_MERKEZLERI")
	public static GMMap tescilMerkezleri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		List<TicariSicilKod> kodlar = session.createCriteria(TicariSicilKod.class).add(Restrictions.eq("listeId", new BigDecimal(108))).list();

		String tableName = "TESCIL_MERKEZ_LISTE";
		GuimlUtil.wrapMyCombo(oMap, tableName, "", "");

		for (TicariSicilKod kod : kodlar) {
			GuimlUtil.wrapMyCombo(oMap, tableName, kod.getKod().toString(), kod.getAciklama());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_QRY3940_TESCIL_LISTELE")
	public static GMMap tescilListele(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		List<TicariSicilTescilKonu> konular = session.createCriteria(TicariSicilTescilKonu.class).add(Restrictions.eq("id.ilanNo", iMap.getBigDecimal("ILAN_NO"))).add(Restrictions.eq("id.sicilSorguNo", iMap.getBigDecimal("SICIL_SORGU_NO"))).list();

		String tableName = "TESCIL_TABLO";
		int row = 0;

		for (TicariSicilTescilKonu konu : konular) {
			oMap.put(tableName, row, "KOD", konu.getId().getTescilKonu());
			oMap.put(tableName, row, "KONU", kodBul(konu.getId().getTescilKonu(), 120));
			row++;
		}

		return oMap;
	}

	private static String kodBul(BigDecimal kod, int listeId) {
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		TicariSicilKod ticariSicilKod = (TicariSicilKod) session.createCriteria(TicariSicilKod.class).add(Restrictions.eq("kod", kod)).add(Restrictions.eq("listeId", new BigDecimal(listeId))).uniqueResult();

		if (ticariSicilKod != null) {
			return ticariSicilKod.getAciklama();
		}
		else {
			return "";
		}
	}

	@GraymoundService("BNSPR_QRY3940_FIRMA_BILGILERI")
	public static GMMap firmaBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		TicariSicililanDetay detay = (TicariSicililanDetay) session.createCriteria(TicariSicililanDetay.class).add(Restrictions.eq("id.ilanNo", iMap.getBigDecimal("ILAN_NO"))).add(Restrictions.eq("id.sicilSorguNo", iMap.getBigDecimal("SICIL_SORGU_NO"))).uniqueResult();
		TicariSicilFirma firma = (TicariSicilFirma) session.createCriteria(TicariSicilFirma.class).add(Restrictions.eq("id.ilanNo", iMap.getBigDecimal("ILAN_NO"))).add(Restrictions.eq("id.sicilSorguNo", iMap.getBigDecimal("SICIL_SORGU_NO"))).uniqueResult();

		if (detay != null) {
			oMap.put("ILAN_NO", detay.getId().getIlanNo());
			oMap.put("GAZETE_TARIHI", detay.getGazeteTarihi());
			oMap.put("GAZETE_SAYISI", detay.getGazeteSayisi());
			oMap.put("GAZETE_SAYFASI", detay.getGazeteSayfasi());
			oMap.put("TC_KIMLIK_NO", detay.getTcKimlikNo());
			oMap.put("VERGI_NO", detay.getVergiNo());
			oMap.put("UNVAN", detay.getUnvan());
			oMap.put("HUKUKI_YAPI", kodBul(detay.getHukukiYapi(), 9));
			oMap.put("TESCIL_TARIHI", detay.getTescilTarihi());
			oMap.put("TESCIL_ILI", kodBul(detay.getTescilIli(), 4));
			oMap.put("TESCIL_MERKEZI", kodBul(detay.getTescilMerkezi(), 108));

			if ("1".equalsIgnoreCase(detay.getSubeBelirteci())) {
				oMap.put("SUBE_MI", "Evet");
			}
			else {
				oMap.put("SUBE_MI", "Hay�r");
			}

			oMap.put("VERGI_DAIRESI", detay.getVergiDairesi());
			oMap.put("VERGI_DAIRESI_ILI", detay.getVergiDairesiIli());
			oMap.put("TESCIL_ADRESI", detay.getTescilAdresi());
			oMap.put("TESCIL_ILCESI", detay.getTescilIlcesi());
			oMap.put("TESCIL_POSTA_KODU", detay.getTescilPostaKodu());
			oMap.put("WEB_ADRESI", detay.getWebAdresi());
			
		}

		if (firma != null) {
			oMap.put("SICIL_NO", firma.getSicilNoTam());
			oMap.put("MERSIS_NO", firma.getMersisNoTam());
			oMap.put("HUKUKI_YAPI", kodBul(firma.getHukukiYapi(), 9));

			if ("5".equalsIgnoreCase(firma.getKimlikTuru())) {
				oMap.put("KIMLIK_TURU", "VKN");
			}
			else {
				oMap.put("KIMLIK_TURU", "TCKN");
			}
			
			oMap.put("KIMLIK_NO", firma.getKimlikNo());
			oMap.put("TESCIL_DETAYI", firma.getTescilDetayi());
			
			
			// Sermaye Bilgileri
			
			oMap.put("SERMAYE_TUTARI", firma.getSermayeTutari());
			oMap.put("ESKI_SERMAYE_TUTARI", firma.getEskiSermayeTutari());
			oMap.put("SON_TOPLANTI_TARIHI", firma.getSonToplantiTarihi());
			oMap.put("DOVIZ_CINSI", kodBul(firma.getDovizCinsi(), 10));
			oMap.put("SERMAYE_ARTTIRIM_TARIHI", firma.getSermayeArttirimTarihi());
			
			// �nvan Bilgileri
			
			oMap.put("ESKI_UNVAN", firma.getEskiUnvan());
			oMap.put("UNVAN_DEGISIM_TARIHI", firma.getUnvanDegisimTarihi());
			oMap.put("ESKI_TESCIL_ILI", kodBul(firma.getEskiTescilIli(), 4));
			oMap.put("ESKI_SICIL_NO", firma.getEskiSicilNo());
			oMap.put("ESKI_TESCIL_MERKEZI", firma.getEskiTescilMerkezi());
			oMap.put("SICIL_DEGISIM_TARIHI", firma.getSicilDegisimTarihi());
			oMap.put("YENI_HUKUK_YAPISI", kodBul(firma.getYeniHukukYapisi(), 9));
			oMap.put("HUKUK_YAPI_DEG_TAR", firma.getHukukYapiDegisimTar());
			
			// Kritik Bilgiler
			
			oMap.put("TASFIYE", firma.getTasfiye());
			oMap.put("TASFIYEDEN_DONUS", firma.getTasfiyedenDonus());
			oMap.put("FAALIYETE_DONUS_TARIHI", firma.getFaaliyeteDonusTarihi());
			oMap.put("ICRA_IFLAS", firma.getIcraIflas());
			oMap.put("KONKARDATO", firma.getKonkardato());
			oMap.put("DOSYA_SAYI_ESAS_NO", firma.getDosyaSayiEsasNo());
			oMap.put("ICRA_IFLAS_MUDURLUGU", firma.getIcraIflasMudurlugu());
			oMap.put("BOLUNME_BILGILERI", firma.getBolunmeBilgileri());
		}

		return oMap;
	}
	
	public static GMMap yoneticiBilgisi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		
		List<TicariSicilFirmaYonetici> yoneticiList = session.createCriteria(TicariSicilFirmaYonetici.class).add(Restrictions.eq("id.ilanNo", iMap.getBigDecimal("ILAN_NO"))).add(Restrictions.eq("id.sicilSorguNo", iMap.getBigDecimal("SICIL_SORGU_NO"))).list();
		
		String tableName = "YONETICI_TABLO";
		int row = 0;
		
		for (TicariSicilFirmaYonetici yonetici : yoneticiList) {
			oMap.put(tableName, row, "TC_KIMLIK_NO", yonetici.getId().getTcKimlikNo());
			oMap.put(tableName, row, "ADI", yonetici.getAdi());
			oMap.put(tableName, row, "DIGER_GOREVI", yonetici.getDigerGorevi());
			oMap.put(tableName, row, "SOYADI", yonetici.getSoyadi());
			oMap.put(tableName, row, "GOREVI", kodBul(new BigDecimal(yonetici.getGorevi()), 117));
			oMap.put(tableName, row, "IMZA_YETKISI", kodBul(new BigDecimal(yonetici.getImzaYetkisi()), 116));
			row++;
		}
		
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3940_ORTAK_LISTELE")
	public static GMMap ortaklikBilgisi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		
		List<TicariSicilFirmaOrtak> ortakList = session.createCriteria(TicariSicilFirmaOrtak.class).add(Restrictions.eq("id.ilanNo", iMap.getBigDecimal("ILAN_NO"))).add(Restrictions.eq("id.sicilSorguNo", iMap.getBigDecimal("SICIL_SORGU_NO"))).list();
		
		String tableName = "ORTAK_TABLO";
		int row = 0;
		
		for (TicariSicilFirmaOrtak ortak : ortakList) {
			if (ortak.getId().getOrtaklikTip().compareTo(BigDecimal.ONE) == 0) {
				oMap.put(tableName, row, "ORTAKLIK_TIPI", "Ortak");
			} else if (ortak.getId().getOrtaklikTip().compareTo(new BigDecimal(2)) == 0) {
				oMap.put(tableName, row, "ORTAKLIK_TIPI", "Eski Ortak");
			} else {
					oMap.put(tableName, row, "ORTAKLIK_TIPI", "T�zel Ortak");
			}
			oMap.put(tableName, row, "UNVAN", ortak.getId().getUnvan());
			oMap.put(tableName, row, "AYRILMA_TARIHI", ortak.getAyrilmaTarihi());
			oMap.put(tableName, row, "ESKI_HISSE_ORANI", ortak.getEskiHisseOrani());
			oMap.put(tableName, row, "HISSE_ORANI", ortak.getHisseOrani());
			oMap.put(tableName, row, "SIRKET_TIPI", ortak.getSirketTipi());
			oMap.put(tableName, row, "TC_KIMLIK_NO", ortak.getTcKimlikNo());
			oMap.put(tableName, row, "VEFAT_DURUMU", ortak.getVefatDurumu());
			oMap.put(tableName, row, "VERGI_NO", ortak.getVergiNo());
			
			row++;
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3940_DEVIR_LISTELE")
	public static GMMap devirListele(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		List<TicariSicililanDevir> devirList = session.createCriteria(TicariSicililanDevir.class).add(Restrictions.eq("id.ilanNo", iMap.getBigDecimal("ILAN_NO"))).add(Restrictions.eq("id.sicilSorguNo", iMap.getBigDecimal("SICIL_SORGU_NO"))).add(Restrictions.eq("id.devirAlanMi", iMap.getString("DEVIR_ALAN_MI"))).list();
		
		String tableName = "DEVIR_TABLO";
		int row = 0;
		
		for (TicariSicililanDevir devir : devirList) {
			
			oMap.put(tableName, row, "SICIL_NO", devir.getId().getSicilNo());
			oMap.put(tableName, row, "DEVIR_TARIHI", devir.getDevirTarihi());
			oMap.put(tableName, row, "HUKUKI_YAPI", kodBul(devir.getHukukiYapi(), 9));
			oMap.put(tableName, row, "TESCIL_ILI", kodBul(devir.getTescilIli(), 4));
			oMap.put(tableName, row, "TESCIL_MERKEZI", kodBul(devir.getTescilMerkezi(), 108));
			oMap.put(tableName, row, "UNVAN", devir.getUnvan());
			oMap.put(tableName, row, "VERGI_DAIRESI", devir.getVergiDairesi());
			oMap.put(tableName, row, "VERGI_DAIRESI_ILI", devir.getVergiDairesiIli());
			oMap.put(tableName, row, "VERGI_NO", devir.getVergiNo());
			
			row++;
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3940_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {

		if (iMap.getBoolean("OZET_SORGU")) {
			return  GMServiceExecuter.call("BNSPR_KKB_TICARI_SICIL_OZET_SORGU", iMap);
		}
		else if (iMap.getBoolean("DETAY_SORGU")) {
			return GMServiceExecuter.call("BNSPR_KKB_TICARI_SICIL_DETAY_SORGU", iMap);
		}
		else if (iMap.getBoolean("ILAN_DETAYI")) {
			return GMServiceExecuter.call("BNSPR_KKB_TICARI_SICIL_ILAN_DETAYI", iMap);
		}
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}
