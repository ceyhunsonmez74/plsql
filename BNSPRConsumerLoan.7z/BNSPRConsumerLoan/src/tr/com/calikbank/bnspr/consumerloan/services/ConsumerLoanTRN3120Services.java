package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.tree.DefaultMutableTreeNode;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMeslekCalismaMatrixTx;
import tr.com.calikbank.bnspr.dao.GnlMeslekCalismaMatrixTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;



public class ConsumerLoanTRN3120Services {
	private static final String calismaSekliListQuery = "select key1, text from v_ml_gnl_param_text where kod = 'CALISMA_SEKLI' order by sira_no";
	public static final String meslekQuery = "select a.aciklama, a.kod, a.calisma_sekli_dizi from gnl_meslek_kod_pr a";
	private static final String txGetInfoQuery = "select a.aciklama, m.kod, m.calisma_sekli_dizi from gnl_meslek_calisma_matrix_tx m, gnl_meslek_kod_pr a where a.kod = m.kod and m.tx_no = ?";
	
	
	@GraymoundService("BNSPR_TRN3120_GET_MESLEK_CALISMA_SEKLI_TREE")
	public static GMMap getMeslekCalismaSekliTree(GMMap iMap) {
		GMMap oMap = new GMMap();
		MeslekMatrixTreeFactory factory = new MeslekMatrixTreeFactory(meslekQuery, calismaSekliListQuery);
		oMap.put("ROOT", factory.createMatrixTree());
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3120_SAVE_MESLEK_CALISMA_MATRIX")
	public static Map<?, ?> saveMeslekCalismaMatrix(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			DefaultMutableTreeNode root = (DefaultMutableTreeNode)iMap.get("ROOT");
			for (int i = 0; i < root.getChildCount(); i++) {
				DefaultMutableTreeNode meslekNode = (DefaultMutableTreeNode)root.getChildAt(i);
				GnlMeslekCalismaMatrixTx calismaMatrixTx = new GnlMeslekCalismaMatrixTx();
				char[] calismaSekliDizi = new char[meslekNode.getChildCount()];
				GnlMeslekCalismaMatrixTxId id = new GnlMeslekCalismaMatrixTxId();
				HashMap<?, ?> meslekUo = (HashMap<?, ?>)meslekNode.getUserObject();
				id.setKod((String)meslekUo.get("KOD"));
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				calismaMatrixTx.setId(id);
				for (int j = 0; j < meslekNode.getChildCount(); j++) {
					DefaultMutableTreeNode calismaSekliNode = (DefaultMutableTreeNode)meslekNode.getChildAt(j);
					HashMap<?, ?> calismaSekliUo = (HashMap<?, ?>)calismaSekliNode.getUserObject();
					calismaSekliDizi[j] = getSelectedValueAsChar(calismaSekliUo.get("SELECTED"));
				}
				calismaMatrixTx.setCalismaSekliDizi(new String(calismaSekliDizi));
				session.save(calismaMatrixTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "3120");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static char getSelectedValueAsChar(Object selected){
		Boolean value;
		if(selected instanceof Boolean){
			value = (Boolean)selected;
		}else if(selected instanceof String){
			String strValue = (String)selected;
			if(strValue.equals("1"))
				value = true;
			else if(strValue.equals("0"))
				value = false;
			else
				value = new Boolean(strValue);
		}
		else
			value = false;
		return value ? '1' : '0';
	}
	
	@GraymoundService("BNSPR_TRN3120_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement(txGetInfoQuery);
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			resultSet = stmt.executeQuery();
			MeslekMatrixTreeFactory factory = new MeslekMatrixTreeFactory(resultSet, calismaSekliListQuery);
			oMap.put("ROOT", factory.createMatrixTree());
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(resultSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}

class MeslekMatrixTreeFactory{
	private static final String secondLevelListName = "MATRIX_LIST_NAME"; 
	private String firstLevelNodeQuery;
	private String secondLevelNodeQuery;
	private GMMap secondLevelListMap;
	private ResultSet firstLevelResultSet;
	
	public MeslekMatrixTreeFactory(String firstLevelNodeQuery, String secondLevelNodeQuery){
		this.firstLevelNodeQuery = firstLevelNodeQuery;
		this.secondLevelNodeQuery = secondLevelNodeQuery;
	}
	public MeslekMatrixTreeFactory(ResultSet firstLevelResultSet, String secondLevelNodeQuery){
		this.firstLevelResultSet = firstLevelResultSet;
		this.secondLevelNodeQuery = secondLevelNodeQuery;
	}
	public DefaultMutableTreeNode createMatrixTree() {
		DefaultMutableTreeNode root = createMeslekRootNode();
		secondLevelListMap = DALUtil.fillComboBox(new GMMap(), secondLevelListName, false, secondLevelNodeQuery);
		if(firstLevelResultSet == null){
			Connection conn = null;
			PreparedStatement stmt = null;
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareStatement(firstLevelNodeQuery);
				firstLevelResultSet = stmt.executeQuery();
				
				createMeslekTree(root, firstLevelResultSet);
				
			} catch (SQLException e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(firstLevelResultSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
		else{
			createMeslekTree(root, firstLevelResultSet);
		}
		
		return root;
	}
	
	
	private void createMeslekTree(DefaultMutableTreeNode root, ResultSet resultSet){
		try {
			while (resultSet.next()) {
				root.add(createMeslekNode(resultSet.getString(1), resultSet.getString(2),resultSet.getString(3)));
			}
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private DefaultMutableTreeNode createMeslekNode(String meslekNodeName, String meslekNodeKod, String strDizi){
		DefaultMutableTreeNode meslekNode = new DefaultMutableTreeNode();
		HashMap<String, Object> meslekUo = new HashMap<String, Object>();
		meslekNode.setUserObject(meslekUo);
		meslekUo.put("NAME", meslekNodeName);
		meslekUo.put("KOD", meslekNodeKod);
		meslekUo.put("SELECTED", new Boolean(false));
		meslekUo.put("LEVEL", new BigDecimal(1));
		
		char[]  binaryDizi = strDizi.toCharArray();
		for (int row = 0; row < secondLevelListMap.getSize(secondLevelListName); row++) {
			DefaultMutableTreeNode secondLevelNode = new DefaultMutableTreeNode();
			HashMap<String, Object> secondLevelUo = new HashMap<String, Object>();
			secondLevelUo.put("NAME", secondLevelListMap.getString(secondLevelListName, row, "NAME"));
			secondLevelUo.put("VALUE", secondLevelListMap.getString(secondLevelListName, row, "VALUE"));
			if(binaryDizi.length > row)
				secondLevelUo.put("SELECTED", "0".equals(binaryDizi[row]+"") ? new Boolean(false) : new Boolean(true));
			else
				secondLevelUo.put("SELECTED", new Boolean(false));
			secondLevelUo.put("LEVEL", new BigDecimal(3));
			secondLevelNode.setUserObject(secondLevelUo);
			meslekNode.add(secondLevelNode);
		}
		return meslekNode;
	}
	
	private DefaultMutableTreeNode createMeslekRootNode() {
		DefaultMutableTreeNode root = new DefaultMutableTreeNode();
		HashMap<String, Object> rootUo = new HashMap<String, Object>();
		rootUo.put("NAME", "Meslekler");
		rootUo.put("VALUE", "MESLEKLER");
		rootUo.put("LEVEL", new BigDecimal(0));
		root.setUserObject(rootUo);
		return root;
	}
}
