package tr.com.calikbank.bnspr.consumerloan.utils;


public interface Constants {
	//MapKeys
	public final static String ISO_8859_9 = "ISO-8859-9";
	public final static String DEFAULT_CHARSET = "ISO-8859-9";
	public final static String TR = "TR";
	public final static String FILE = "FILE";
	public final static String HATA_NO = "HATA_NO";
	public final static String TABLE = "TABLE";
	public final static String COLUMN = "COLUMN";
	public final static String LINE_SIZE = "LINE_SIZE";
	public final static String CONTENT = "CONTENT";
	public final static String VDMK_KREDI_DEVIR = "VDMK_KREDI_DEVIR";
	public final static String BASVURU_NO = "BASVURU_NO";
	public final static String RESPONSE = "RESPONSE";
	public final static String RESPONSE_DATA = "RESPONSE_DATA";
	public final static String RESULT = "RESULT";
	public final static String TRX_NO = "TRX_NO";
	public final static String TRX_NAME = "TRX_NAME";
	public final static String DOKUMAN_KOD = "DOKUMAN_KOD";
	public final static String RETURN_CODE = "RETURN_CODE";
	public final static String RETURN_DATA = "RETURN_DATA";
	public final static String DURUM = "DURUM";
	public final static String GUNCELLEME_TARIHI = "GUNCELLEME_TARIHI";
	public final static String BANKA_TARIH = "BANKA_TARIH";
	public final static String KOD = "KOD";
	public final static String KEY = "KEY";
	public final static String MUSTERI_NO = "MUSTERI_NO";
	public final static String KRD_HESAP_NO = "KRD_HESAP_NO";
	public final static String KRD_TUTAR = "KRD_TUTAR";
	public final static String DOVIZ_KOD = "DOVIZ_KOD";
	public final static String ISLEM_TARIHI = "ISLEM_TARIHI";
	public final static String BASVURU_TARIHI = "BASVURU_TARIHI";
	public final static String KUL_TUTAR = "KUL_TUTAR";
	public final static String TEXT = "TEXT";
	public final static String RAISE_ERROR = "RAISE_ERROR";
	public final static String MAKE_CODE = "MAKE_CODE";
	public final static String MODEL_YEAR = "MODEL_YEAR";
	public final static String MAKES = "MAKES";
	public final static String MODEL_YEARS = "MODEL_YEARS";
	public final static String MODELS = "MODELS";
	public final static String ID = "ID";
	public final static String CUSTOMER_ID = "CUSTOMER_ID";
	public final static String TCKN = "TCKN";
	public final static String PRODUCT_TYPE = "PRODUCT_TYPE";
	public final static String PRODUCT_TYPE_DESC = "PRODUCT_TYPE_DESC";
	public final static String MAP_ENTRY = "MAP_ENTRY";
	public final static String VALUE = "VALUE";
	public final static String HATA_VERILSIN_MI = "HATA_VERILSIN_MI";
	public final static String BELGE_KONTROL = "BELGE_KONTROL";
	public final static String KIMDEN = "KIMDEN";
	public final static String BELGE = "BELGE";
	public final static String EVRAKSIZ = "EVRAKSIZ";
	
	//Static variables
	public final static int VDMK_EXCEL_COLUMN_SIZE = 1;
	public final static int VDMK_EXCEL_DATE_COLUMN_ORDER_NUMBER = 2;
	public final static String BNSPR_SESSION_NAME = "BNSPRDal";
	public final static String YES = "Y";
	public final static String NO = "N";
	public final static String EVET = "E";
	public final static String HAYIR = "H";
	public final static String FIELD_SEPERATOR = "|";
	public final static String LINE_SEPERATOR = "\n";
	public final static String STR_ZERO = "0";
	public final static String STR_ONE = "1";
	public final static String STR_MINUS_ONE = "-1";
	public final static String BELGE_KONTROL_UYGUN = "1";
	public final static String BELGE_KONTROL_EKSIK = "2";
	public final static String BELGE_KONTROL_HATALI = "3";
	public final static String BELGE_KONTROL_SUPHELI = "4";
	public final static String BELGE_KONTROL_GONDERILDI = "5";
	public final static String BELGE_KONTROL_YUKLENDI = "6";
	public final static String BELGE_KONTROL_EKSIK_BELGE_YUKLENDI = "7";
	public final static String CALISMA_SEKLI_ORJINAL_EVRAKLI = "1";
	public final static String CALISMA_SEKLI_ORJINAL_EVRAKSIZ = "2";
	public final static String CALISMA_SEKLI_ELEKTRONIK_EVRAKLI = "3";
	
	
	public final static String CREDIT_TYPE_LIST = "KREDI_TUR_LIST";	
	public final String[] CREDIT_TYPES = {"�htiya�", "Konut", "Ta��t", "Mikro", null, null, "Tar�m"};
	public final char CREDIT_TYPE_ENABLED = '1';
	
	public final static String TASIT_TURU = "TASIT_TURU";
	public final static String TASIT_TURU_SIFIR = "1";
	public final static String TASIT_TURU_IKINCI_EL = "2";
}
