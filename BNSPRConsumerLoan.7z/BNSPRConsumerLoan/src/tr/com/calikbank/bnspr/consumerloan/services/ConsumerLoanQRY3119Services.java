package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3119Services {
	
    @SuppressWarnings("deprecation")
    @GraymoundService("BNSPR_QRY3119_GET_LIST")
    public static GMMap getList(GMMap iMap){
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_RC_3119.getbelgematris(?) }");
            
            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setString(i, iMap.getString("BELGE_KODU"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName = "RESULTS"; 
            int row = 0; 
            GMMap oMap = new GMMap();
            
            while(rSet.next()){ 
                oMap.put(tableName, row, "DOKUMAN_KOD", rSet.getObject("DOKUMAN_KOD"));
                oMap.put(tableName, row, "ACIKLAMA", LovHelper.diLov(rSet.getObject("DOKUMAN_KOD"), "3119Q/LOV_DOKUMAN_KOD", "ACIKLAMA"));
                oMap.put(tableName, row, "KRD_TUR_KOD", rSet.getObject("KRD_TUR_KOD"));
                oMap.put(tableName, row, "KRD_TUR_ACIKLAMA", rSet.getObject("KRD_TUR_ACIKLAMA"));
                oMap.put(tableName, row, "KRD_TUR_ALT_KOD", rSet.getObject("KRD_TUR_ALT_KOD"));
                oMap.put(tableName, row, "KRD_TUR_ALT_ACIKLAMA", rSet.getObject("KRD_TUR_ALT_ACIKLAMA"));
                oMap.put(tableName, row, "KRD_TUR_ALT_KOD2", rSet.getObject("KRD_TUR_ALT_KOD2"));
                oMap.put(tableName, row, "KRD_TUR_ALT_ACIKLAMA2", rSet.getObject("KRD_TUR_ALT_ACIKLAMA2"));
                oMap.put(tableName, row, "KANAL_KOD", rSet.getObject("KANAL_KOD"));
                oMap.put(tableName, row, "KANAL_ADI", LovHelper.diLov(rSet.getObject("KANAL_KOD"), "3119Q/LOV_KANAL_KOD", "ACIKLAMA"));
                oMap.put(tableName, row, "TEMINAT_KOD", rSet.getObject("TEMINAT_KOD"));
                oMap.put(tableName, row, "TEMINAT_ADI", LovHelper.diLov(rSet.getObject("TEMINAT_KOD"), "3119Q/LOV_TEMINAT", "ACIKLAMA"));
                oMap.put(tableName, row, "MESLEK_KOD", rSet.getObject("MESLEK_KOD"));
                oMap.put(tableName, row, "MESLEK_ADI", LovHelper.diLov(rSet.getObject("MESLEK_KOD"), "3119Q/LOV_MESLEK_KODU", "ACIKLAMA"));
                oMap.put(tableName, row, "CALISMA_SEKLI_TXT", rSet.getObject("CALISMA_SEKLI"));
                oMap.put(tableName, row, "CALISMA_SEKLI", rSet.getObject("CALISMA_SEKLI"));
                oMap.put(tableName, row, "KIMLIK_TIP_KOD", rSet.getObject("KIMLIK_TIP_KOD"));
                oMap.put(tableName, row, "KEFIL_TIP_KOD_TXT", rSet.getObject("KEFIL_TIP_KOD"));
                oMap.put(tableName, row, "KEFIL_TIP_KOD", rSet.getObject("KEFIL_TIP_KOD"));
                oMap.put(tableName, row, "KAMPANYA_KOD", rSet.getObject("KAMPANYA_KOD"));
                oMap.put(tableName, row, "KAMPANYA_ADI", LovHelper.diLov(rSet.getObject("KAMPANYA_KOD"),rSet.getObject("KRD_TUR_KOD"),rSet.getObject("KRD_TUR_ALT_KOD"),
                    rSet.getObject("KRD_TUR_ALT_KOD2") ,"3119Q/LOV_KAMPANYA_KOD", "ACIKLAMA"));
                oMap.put(tableName, row, "GELIR_BILGISI_KOD_TXT", rSet.getObject("GELIR_BILGISI_KOD"));
                oMap.put(tableName, row, "GELIR_BILGISI_KOD", rSet.getObject("GELIR_BILGISI_KOD"));
                oMap.put(tableName, row, "BHS_VAR_YOK", rSet.getObject("BHS_VAR_YOK"));
                oMap.put(tableName, row, "BAYI_KEFALETI", rSet.getObject("BAYI_KEFALETI"));
                oMap.put(tableName, row, "SATICI_KOD", rSet.getObject("SATICI_KOD"));
                oMap.put(tableName, row, "SATICI_ADI", LovHelper.diLov(rSet.getObject("SATICI_KOD"), "3119Q/LOV_SATICI_KODU", "SATICI_ADI"));
                oMap.put(tableName, row, "KDH_TUR", LovHelper.diLov(rSet.getObject("KDH_TUR_KOD"), "3119Q/LOV_KDH_TUR_KOD", "ACIKLAMA"));
                oMap.put(tableName, row, "MUSTERI_GRUP", LovHelper.diLov(rSet.getObject("MUSTERI_GRUP_KOD"), "3119/LOV_MUSTERI_GRUBU", "ACIKLAMA"));
                oMap.put(tableName, row, "EK_PAKET_VAR_YOK", rSet.getObject("EK_PAKET_VAR_YOK"));
                
                String bayiKrediTipi;
                try {
                GMMap queryMap = new GMMap();
    			queryMap.put("KOD", "BAYI_KREDI_TIPI");
    			queryMap.put("KEY", rSet.getObject("BAYI_KREDI_TIPI"));
    			bayiKrediTipi = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", queryMap).getString("TEXT");
                } catch (Exception e) {
                	bayiKrediTipi = null;
                }
                
                oMap.put(tableName, row, "BAYI_KREDI_TIPI", bayiKrediTipi);
                oMap.put(tableName, row, "FAIZSIZ_FINANSMAN", rSet.getObject("FAIZSIZ_FINANSMAN"));

                row++;
            }
            return oMap;
        }catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    @GraymoundService("BNSPR_QRY3119_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboBoxInitialValues(GMMap iMap){
    	Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        
        try{
        	conn = DALUtil.getGMConnection();
        	
            iMap.put("ADD_EMPTY_KEY", "E");
            iMap.put("KOD", "CALISMA_SEKLI");
            oMap.put("CALISMA_SEKLI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY", "E");
            iMap.put("KOD", "GELIR_BILGISI_KOD");
            oMap.put("GELIR_BILGISI_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY", "E");
            iMap.put("KOD", "KEFIL_TIP_KOD");
            oMap.put("KEFIL_TIP_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            
            String listName = "KIMLIK_TIP_KOD";

            stmt = conn.prepareStatement("SELECT KEY1, TEXT FROM GNL_PARAM_TEXT WHERE KOD = ? ORDER BY SIRA_NO");
            stmt.setString(1, "KIMLIK_TIP_KOD");
            rSet = stmt.executeQuery();

            GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
            while (rSet.next()) {
                GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
            }

            return oMap;
        }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
}