package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.consumerloan.utils.GeneralUtils;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirCollectionAramaTx;
import tr.com.calikbank.bnspr.dao.BirCollectionAramaTxId;
import tr.com.calikbank.bnspr.dao.BirCollectionEmailTx;
import tr.com.calikbank.bnspr.dao.BirCollectionEmailTxId;
import tr.com.calikbank.bnspr.dao.BirCollectionTelefonTx;
import tr.com.calikbank.bnspr.dao.BirCollectionTelefonTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8050Services implements Constants{
	
	@GraymoundService("BNSPR_TRN8050_GET_CUSTOMER_INFO")
	public static GMMap getCustomerInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		BigDecimal customerNumber = null;
		String tckn = StringUtils.EMPTY;
		int kmhCount = 0;
		
		try {
			customerNumber = iMap.getBigDecimal(MUSTERI_NO);
			tckn = StringUtils.trim(iMap.getString(TCKN));
			String proc = "{call  PKG_RC_COLLECTION.get_musteri_bilgileri(?,?,?)}";
			Object[] inputValues = {BnsprType.NUMBER, customerNumber, BnsprType.STRING, tckn};
			Object[] outputValues = {BnsprType.REFCURSOR, RESULT};
			oMap = ((GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues)).getMap(RESULT, 0);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		if(oMap == null){
			oMap = new GMMap();
			oMap.put("MESSAGE", "M��teri bilgileri bulunamad�!");	
		}else{
			if(customerNumber != null){
				kmhCount = Integer.valueOf(DALUtil.getResult("select count(*) from musteri_urun_risk where musteri_no = "+ customerNumber.toString() + " and trunc(sysdate) = trunc(rec_date) and urun_tipi = 'KMH'"));
			}
			else{
				kmhCount = Integer.valueOf(DALUtil.getResult("select count(*) from musteri_urun_risk where tckn = "+ tckn + " and trunc(sysdate) = trunc(rec_date) and urun_tipi = 'KMH'"));
			}
			if(kmhCount > 0){
				oMap.put("MESSAGE", "KMH �r�n� ile ilgili bilgi vermek i�in 3050 ekran�n� kullan�n�z!");
			}	
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_TRN8050_GET_PRODUCTS_INFO")
	public static GMMap getProductsInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		BigDecimal customerNumber = BigDecimal.ZERO; 		
		
		try {
			customerNumber = iMap.getBigDecimal(MUSTERI_NO);
			String proc = "{call  PKG_RC_COLLECTION.get_urun_bilgileri(?,?)}";
			Object[] inputValues = {BnsprType.NUMBER, customerNumber};
			Object[] outputValues = {BnsprType.REFCURSOR, RESULT};
			oMap = (GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}		
			
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8050_GET_AKSIYON_BILGI")
	public static GMMap getAksiyonBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		BigDecimal customerNumber = BigDecimal.ZERO; 
		
		try {
			customerNumber = iMap.getBigDecimal(MUSTERI_NO);
			String proc = "{call  PKG_TRN8050.get_aksiyon_tarihce(?,?)}";
			Object[] inputValues = {BnsprType.NUMBER, customerNumber};
			Object[] outputValues = {BnsprType.REFCURSOR, RESULT};
			oMap = (GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8050_GET_TELEFON_BILGI")
	public static GMMap getTelefonBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		BigDecimal customerNumber = BigDecimal.ZERO; 
		
		try {
			customerNumber = iMap.getBigDecimal(MUSTERI_NO);
			String proc = "{call  PKG_TRN8050.get_telefon_tarihce(?,?)}";
			Object[] inputValues = {BnsprType.NUMBER, customerNumber};
			Object[] outputValues = {BnsprType.REFCURSOR, RESULT};
			oMap = (GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8050_GET_EMAIL_BILGI")
	public static GMMap getEmailBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		BigDecimal customerNumber = BigDecimal.ZERO; 
		
		try {
			customerNumber = iMap.getBigDecimal(MUSTERI_NO);
			String proc = "{call  PKG_TRN8050.get_email(?,?)}";
			Object[] inputValues = {BnsprType.NUMBER, customerNumber};
			Object[] outputValues = {BnsprType.REFCURSOR, RESULT};
			oMap = (GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8050_GET_GONDERI_BILGI")
	public static GMMap getGonderiBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal customerNumber = BigDecimal.ZERO;

		try {
			customerNumber = iMap.getBigDecimal(MUSTERI_NO);
			String proc = "{call  PKG_TRN8050.get_gonderi_tarihce(?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, customerNumber };
			Object[] outputValues = { BnsprType.REFCURSOR, RESULT };
			oMap = (GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8050_GET_ODEME_BILGI")
	public static GMMap getOdemeBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		BigDecimal customerNumber = BigDecimal.ZERO;

		try {
			customerNumber = iMap.getBigDecimal(MUSTERI_NO);
			String proc = "{call  PKG_TRN8050.get_odeme_tarihce(?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, customerNumber };
			Object[] outputValues = { BnsprType.REFCURSOR, RESULT };
			oMap = (GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8050_GET_COMBOBOX_ARAMA_SONUC")
	public static GMMap getComboboxAramaSonuc(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "ARAMA_SONUC", true, "select key3 KEY, text VALUE from v_ml_gnl_param_text v where v.KOD='PKG_RC_COLLECTION' and key1= 'ARAMA_SONUC' and key2='" + iMap.getString("KEY2") + "' order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8050_GET_COMBOBOX_MAAS_PROBLEM")
	public static GMMap getComboboxMaasProblem(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "MAAS_PROBLEMI", true, "select key3 KEY, text VALUE from v_ml_gnl_param_text v where v.KOD='PKG_RC_COLLECTION' and key1= 'MAAS_PROBLEMI' and key2='" + iMap.getString("KEY2") + "' order by key1");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8050_GET_COMBOBOX_TEL_KAYNAK")
	public static GMMap getComboboxTelKaynak(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "TEL_KAYNAK", true, "select key2 KEY, text VALUE from v_ml_gnl_param_text v where v.KOD='PKG_RC_COLLECTION' and key1= 'TEL_KAYNAK' order by key1");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8050_SAVE_TELEFON_BILGI")
	public static GMMap saveTelefonBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal phoneOrderNumber = GeneralUtils.nvl(iMap.getBigDecimal("TEL_SIRA_NO"), BigDecimal.ZERO);
			BigDecimal customerNumber = iMap.getBigDecimal("MUSTERI_NO");
			
			if (BigDecimal.ZERO.compareTo(phoneOrderNumber) < 0) {
				BirCollectionTelefonTxId birCollectionTelefonTxId = new BirCollectionTelefonTxId(customerNumber, phoneOrderNumber);
				BirCollectionTelefonTx birCollectionTelefonTx = (BirCollectionTelefonTx) session.get(BirCollectionTelefonTx.class, birCollectionTelefonTxId);
				birCollectionTelefonTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birCollectionTelefonTx.setTelTip(iMap.getString("TEL_TIP"));
				birCollectionTelefonTx.setUlkeKod(iMap.getString("ULKE_KODU"));
				birCollectionTelefonTx.setAlanKod(iMap.getString("ALAN_KODU"));
				birCollectionTelefonTx.setTelNo(iMap.getString("TEL_NO"));
				birCollectionTelefonTx.setDahiliNo(iMap.getString("DAHILI_NO"));
				birCollectionTelefonTx.setKimeAit(iMap.getString("YAKINLIK_DURUMU"));
				birCollectionTelefonTx.setAd(iMap.getString("AD"));
				birCollectionTelefonTx.setSoyad(iMap.getString("SOYAD"));
				birCollectionTelefonTx.setDurum(iMap.getBoolean("AKTIF_PASIF") ? "1" : "0");
				birCollectionTelefonTx.setKaynak(iMap.getString("KAYNAK"));
				session.update(birCollectionTelefonTx);
				session.flush();
				
				
				String func = "{ ? = call pkg_trn8050.tel_kontrol(?) }";
				String result = (String) DALUtil.callOneParameterFunction(func, Types.VARCHAR, iMap.getBigDecimal("TRX_NO"));
				if("1".equals(result)){
					oMap.put("MESSAGE", "Telefon ba�ar�yla g�ncellendi!");
				}
			}
			else {
				List phoneList = session.createCriteria(BirCollectionTelefonTx.class).add(Restrictions.eq("id.musteriNo", customerNumber)).
						addOrder(Order.desc("id.siraNo")).list();
				phoneOrderNumber = BigDecimal.ZERO;
				if (!phoneList.isEmpty()) {
					BirCollectionTelefonTx birCollectionTelefonTx = (BirCollectionTelefonTx) phoneList.get(0);
					phoneOrderNumber = birCollectionTelefonTx.getId().getSiraNo().add(BigDecimal.ONE);
				}else {
					phoneOrderNumber = BigDecimal.ONE;
				}
				
				BirCollectionTelefonTxId birCollectionTelefonTxId = new BirCollectionTelefonTxId(customerNumber, phoneOrderNumber);
				BirCollectionTelefonTx birCollectionTelefonTx = new BirCollectionTelefonTx();
				birCollectionTelefonTx.setId(birCollectionTelefonTxId);
				birCollectionTelefonTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birCollectionTelefonTx.setTelTip(iMap.getString("TEL_TIP"));
				birCollectionTelefonTx.setUlkeKod(iMap.getString("ULKE_KODU"));
				birCollectionTelefonTx.setAlanKod(iMap.getString("ALAN_KODU"));
				birCollectionTelefonTx.setTelNo(iMap.getString("TEL_NO"));
				birCollectionTelefonTx.setDahiliNo(iMap.getString("DAHILI_NO"));
				birCollectionTelefonTx.setKimeAit(iMap.getString("YAKINLIK_DURUMU"));
				birCollectionTelefonTx.setAd(iMap.getString("AD"));
				birCollectionTelefonTx.setSoyad(iMap.getString("SOYAD"));
				birCollectionTelefonTx.setDurum(iMap.getBoolean("AKTIF_PASIF") ? STR_ONE : STR_ZERO);
				birCollectionTelefonTx.setKaynak(iMap.getString("KAYNAK"));
				session.save(birCollectionTelefonTx);
				session.flush();
				
				String func = "{ ? = call pkg_trn8050.tel_kontrol(?) }";
				String result = (String) DALUtil.callOneParameterFunction(func, Types.VARCHAR, iMap.getBigDecimal("TRX_NO"));
				if("1".equals(result)){
					oMap.put("MESSAGE", "Telefon ba�ar�yla eklendi!");
				}
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8050_SAVE_EMAIL_BILGI")
	public static GMMap saveEmailBilgi(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal customerNumber = iMap.getBigDecimal("MUSTERI_NO");
			String email = iMap.getString("EMAIL");
			String emailHost = iMap.getString("EMAIL_HOST");
			String fullMail = email + "@" + emailHost;
			
			Object[] inputValues = new Object[4];
			inputValues[0] = BnsprType.STRING;
			inputValues[1] = fullMail;
			Object[] outputValues = new Object[0];
			String proc = "{ call pkg_trn10011.e_mail_check(?) }";
			DALUtil.callOracleProcedure(proc, inputValues, outputValues);
			
			BirCollectionEmailTxId birCollectionEmailTxId = new BirCollectionEmailTxId(email, emailHost);
			BirCollectionEmailTx birCollectionEmailTx = (BirCollectionEmailTx) session.get(BirCollectionEmailTx.class, birCollectionEmailTxId);
			if(birCollectionEmailTx == null){
				birCollectionEmailTx = new BirCollectionEmailTx();
			}
			birCollectionEmailTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birCollectionEmailTx.setId(birCollectionEmailTxId);
			birCollectionEmailTx.setMusteriNo(customerNumber);
			birCollectionEmailTx.setDurum(iMap.getBoolean("DURUM") ? STR_ONE : STR_ZERO);
			session.saveOrUpdate(birCollectionEmailTx);
			session.flush();
			oMap.put("MESSAGE", "E-Mail ba�ar�yla eklendi!");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8050_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		GMMap collectionMap = new GMMap();
		boolean isNoSelectedRecord = true;
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
				collectionMap = iMap.getMap("TABLE_DATA", i);
				if(collectionMap.getBoolean("SEC") || "1".equals(collectionMap.getString("SEC"))){
					BirCollectionAramaTx birCollectionAramaTx = new BirCollectionAramaTx();
					BirCollectionAramaTxId birCollectionAramaTxId = new BirCollectionAramaTxId();
					birCollectionAramaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birCollectionAramaTxId.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
					birCollectionAramaTxId.setBasvuruNo(collectionMap.getBigDecimal("BASVURU_NO"));
					birCollectionAramaTx.setId(birCollectionAramaTxId);
					birCollectionAramaTx.setMesaj(iMap.getString("MESAJ"));
					birCollectionAramaTx.setAramaSonuc(iMap.getString("ARAMA_SONUC"));
					birCollectionAramaTx.setAramaSonucAksiyon(iMap.getString("ARAMA_SONUC_AKSIYON"));
					birCollectionAramaTx.setAksiyonTarihi(iMap.getDate("AKSIYON_TARIH"));
					birCollectionAramaTx.setTutar(iMap.getBigDecimal("TUTAR"));
					birCollectionAramaTx.setMaasProblemNeden(iMap.getString("MAAS_PROBLEM_NEDEN"));
					birCollectionAramaTx.setMaasProblemAciklama(iMap.getString("MAAS_PROBLEM_ACIKLAMA"));
					birCollectionAramaTx.setMaasBaglanmaTarih(iMap.getDate("MAAS_BAGLANMA_TARIH"));
					birCollectionAramaTx.setVefatTarih(iMap.getDate("VEFAT_TARIH"));
					birCollectionAramaTx.setDurum(iMap.getString("DURUM"));
					birCollectionAramaTx.setGgs(collectionMap.getBigDecimal("GGS"));
					birCollectionAramaTx.setUrun(collectionMap.getString("URUN"));
					birCollectionAramaTx.setTelAlanNo(iMap.getString("TEL_ALAN_NO"));
					birCollectionAramaTx.setTelNo(iMap.getString("TEL_NO"));
					birCollectionAramaTx.setTelAlanNo(iMap.getString("TEKRAR_ARAMA_TARIHI"));
					birCollectionAramaTx.setAramaBirimi(iMap.getString("ARAMA_BIRIMI"));
					birCollectionAramaTx.setCollector(iMap.getString("COLLECTOR"));
					birCollectionAramaTx.setModul(iMap.getString("MODUL"));
					birCollectionAramaTx.setSonuc(iMap.getString("KEPT_BROKEN"));
					birCollectionAramaTx.setAramaAciklama(iMap.getString("ARAMA_ACIKLAMA"));
					birCollectionAramaTx.setKrediHesapDurum(collectionMap.getString("KREDI_HESAP_DURUM"));
					session.save(birCollectionAramaTx);
					session.flush();
					isNoSelectedRecord = false;
				}
			}
			
			if(isNoSelectedRecord){
				ConsumerLoanCommonServices.raiseGMError("660", "L�tfen kay�t se�iniz!");
			}
			
			iMap.put("TRX_NAME", "8050");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8050_PRECALL_CONTROL")
	public static GMMap preCallControl(GMMap iMap){
		GMMap oMap = new GMMap();
		String result = StringUtils.EMPTY;
		
		try {
			BigDecimal customerNumber = iMap.getBigDecimal(MUSTERI_NO);
			String func = "{ ? = call pkg_trn8050.preCallControl(?) }";
			result = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.NUMBER, customerNumber);
			oMap.put("RESULT", result);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8050_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		boolean isCheckedAll = iMap.getBoolean("CHECKED");
		boolean isAnyProductChecked = Boolean.FALSE;
		
		try {
			for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
				if("G".equals(iMap.getString("TABLE_DATA", i, "KREDI_HESAP_DURUM"))){
					iMap.put("TABLE_DATA", i, "SEC", isCheckedAll);
					isAnyProductChecked = Boolean.TRUE;
				}else {
					iMap.put("TABLE_DATA", i, "SEC", Boolean.FALSE);
				}
			}
			
			if(isCheckedAll && !isAnyProductChecked){
				iMap.put("CHECKED", Boolean.TRUE);
			}
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}