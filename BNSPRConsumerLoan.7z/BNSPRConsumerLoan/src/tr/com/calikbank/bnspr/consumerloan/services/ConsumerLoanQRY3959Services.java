package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.tree.checkbox.TristateTreeNode;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY3959Services {

	@GraymoundService("BNSPR_QRY3959_MUSTERI_BILGI")
	public static GMMap musteriBilgiSorgulama(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (isNull(iMap.getString("BASVURU_NO")) && isNull(iMap.getString("MUSTERI_NO")) && isNull(iMap.getString("TC_KIMLIK_NO"))) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("HATA_NO", new BigDecimal(442));
			return oMap;
		}

		try {
			if (iMap.getString("ISLEM").equals("GNL_MUSTERI")) {
				GMMap sMap = new GMMap();
				String func = "{ ? = call PKG_IST_PTT_EMEKLI.RC_MUSTERI_BILGI(?) }";
				Object[] inputValues = new Object[2];
				int i = 0;
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("MUSTERI_NO");
				sMap = DALUtil.callOracleRefCursorFunction(func, "KIMLIK_TABLO", inputValues);

				oMap.put("MUSTERI_NO", sMap.get("KIMLIK_TABLO", 0, "MUSTERI_NO"));
				oMap.put("AD", sMap.get("KIMLIK_TABLO", 0, "AD"));
				oMap.put("SOYAD", sMap.get("KIMLIK_TABLO", 0, "SOYAD"));
				oMap.put("TC_KIMLIK_NO", sMap.get("KIMLIK_TABLO", 0, "TC_KIMLIK_NO"));
			}
			else if (iMap.getString("ISLEM").equals("BIR_BASVURU")) {
				GMMap sMap = new GMMap();
				String func = "{ ? = call PKG_IST_PTT_EMEKLI.RC_BASVURU_BILGI(?) }";
				Object[] inputValues = new Object[2];
				int i = 0;
				inputValues[i++] = BnsprType.NUMBER;
				inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
				sMap = DALUtil.callOracleRefCursorFunction(func, "KIMLIK_TABLO", inputValues);

				oMap.put("MUSTERI_NO", sMap.get("KIMLIK_TABLO", 0, "MUSTERI_NO"));
				oMap.put("AD", sMap.get("KIMLIK_TABLO", 0, "AD"));
				oMap.put("SOYAD", sMap.get("KIMLIK_TABLO", 0, "SOYAD"));
				oMap.put("TC_KIMLIK_NO", sMap.get("KIMLIK_TABLO", 0, "TC_KIMLIK_NO"));
			}
			else if (iMap.getString("ISLEM").equals("TC_KIMLIK_NO")) {
				GMMap sMap = new GMMap();
				String func = "{ ? = call PKG_IST_PTT_EMEKLI.RC_TCKN_BILGI(?) }";
				Object[] inputValues = new Object[2];
				int i = 0;
				inputValues[i++] = BnsprType.STRING;
				inputValues[i++] = iMap.getBigDecimal("TC_KIMLIK_NO");
				sMap = DALUtil.callOracleRefCursorFunction(func, "KIMLIK_TABLO", inputValues);

				oMap.put("MUSTERI_NO", sMap.get("KIMLIK_TABLO", 0, "MUSTERI_NO"));
				oMap.put("AD", sMap.get("KIMLIK_TABLO", 0, "AD"));
				oMap.put("SOYAD", sMap.get("KIMLIK_TABLO", 0, "SOYAD"));
				oMap.put("TC_KIMLIK_NO", sMap.get("KIMLIK_TABLO", 0, "TC_KIMLIK_NO"));
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3959_GET_COMBO_PARAMETERS")
	public static GMMap comboParameters(GMMap iMap) {

		GMMap oMap = new GMMap();
		DALUtil.fillComboBox(oMap, "SORGU_TURU", true, "select key1, text from gnl_param_text where kod = 'PARAM_REF_TUR' and key3 is null order by text");

		return oMap;

	}

	@GraymoundService("BNSPR_QRY3959_PTT_EMEKLI_SORGU")
	public static GMMap sorguBilinmeyenNumara(GMMap iMap) {

		GMMap oMap = new GMMap();

		if (isNull(iMap.getString("ISLEM_TUR"))) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("HATA_NO", new BigDecimal(442));
			throw new GMRuntimeException(0, "Sorgu turu secili olmalidir.");
		}
		else if (iMap.getString("ISLEM_TUR").equals("BIR_BASVURU") && isNull(iMap.getString("BASVURU_NO"))) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("HATA_NO", new BigDecimal(442));
			throw new GMRuntimeException(0, "Basvuru no tanimli olmalidir.");
		}
		else if (iMap.getString("ISLEM_TUR").equals("GNL_MUSTERI") && isNull(iMap.getString("MUSTERI_NO"))) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("HATA_NO", new BigDecimal(442));
			throw new GMRuntimeException(0, "Musteri no tanimli olmalidir.");
		}
		else if (iMap.getString("ISLEM_TUR").equals("TC_KIMLIK_NO") && isNull(iMap.getString("TC_KIMLIK_NO"))) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("HATA_NO", new BigDecimal(442));
			throw new GMRuntimeException(0, "Tc kimlik no tanimli olmalidir.");
		}

		if (!isNull(iMap.getString("BASVURU_NO"))) {
			iMap.put("PARAM_REF_TUR", "BIR_BASVURU");
			iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
		}
		else if (!isNull(iMap.getString("MUSTERI_NO"))) {
			iMap.put("PARAM_REF_TUR", "GNL_MUSTERI");
			iMap.put("PARAM_REF_ID", iMap.getString("MUSTERI_NO"));
		}
		else if (!isNull(iMap.getString("TC_KIMLIK_NO"))) {
			iMap.put("PARAM_REF_TUR", "TC_KIMLIK_NO");
			iMap.put("PARAM_REF_ID", iMap.getString("TC_KIMLIK_NO"));
		}

		iMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));

		try {
			GMServiceExecuter.executeNT("BNSPR_EXT_PTT_EMEKLI_ODEME_SORGULA", iMap);
		}
		catch (Exception e) {

		}
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_QRY3959_PTT_EMEKLI_SORGU_LISTELE", iMap));

		return oMap;

	}

	@GraymoundService("BNSPR_QRY3959_PTT_EMEKLI_SORGU_LISTELE")
	public static GMMap sorguBilinmeyenNumaraListele(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (isNull(iMap.getString("PARAM_REF_TUR"))) {
			if (!isNull(iMap.getString("BASVURU_NO"))) {
				iMap.put("PARAM_REF_TUR", "BIR_BASVURU");
				iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
			}
			else if (!isNull(iMap.getString("MUSTERI_NO"))) {
				iMap.put("PARAM_REF_TUR", "GNL_MUSTERI");
				iMap.put("PARAM_REF_ID", iMap.getString("MUSTERI_NO"));
			}
			else if (!isNull(iMap.getString("TC_KIMLIK_NO"))) {
				iMap.put("PARAM_REF_TUR", "TC_KIMLIK_NO");
				iMap.put("PARAM_REF_ID", iMap.getString("TC_KIMLIK_NO"));
			}
			else {
				return oMap;
			}
		}

		try {
			String func = "{ ? = call PKG_IST_PTT_EMEKLI.rc_ist_bilinmeyen_numara_cevap(?,?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PARAM_REF_ID");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PARAM_REF_TUR");

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TABLE", inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	public static boolean isNull(String text) {
		boolean status = false;

		if (text == null)
			status = true;
		else if (text.isEmpty())
			status = true;
		else if (text == "")
			status = true;

		return status;
	}
}
