package tr.com.calikbank.bnspr.consumerloan.utils;

import java.math.BigDecimal;


public enum CreditTypes {
	IHTIYAC(new BigDecimal(String.valueOf(1)), "\u0130htiya\u00E7"),
	KONUT(new BigDecimal(String.valueOf(2)), "Konut"),
	TASIT(new BigDecimal(String.valueOf(3)), "Ta\u015F\u0131t"),
	MIKRO(new BigDecimal(String.valueOf(4)), "Mikro"),
	KHD(new BigDecimal(String.valueOf(5)), "KDH"),
	TAKSITLI_KDH(new BigDecimal(String.valueOf(6)), "Taksitli KDH"),
	TARIM(new BigDecimal(String.valueOf(7)), "Tar�m");
	
	private BigDecimal creditCode;
    private String creditName;
    
    private CreditTypes(BigDecimal creditCode, String creditName) {
	    this.creditCode = creditCode;
	    this.creditName = creditName;
    }
    
	public BigDecimal getCreditCode() {
		return creditCode;
	}
	
	public String getCreditName() {
		return creditName;
	}
	
	public void setCreditCode(BigDecimal creditCode) {
		this.creditCode = creditCode;
	}
	
	public void setCreditName(String creditName) {
		this.creditName = creditName;
	}
}
