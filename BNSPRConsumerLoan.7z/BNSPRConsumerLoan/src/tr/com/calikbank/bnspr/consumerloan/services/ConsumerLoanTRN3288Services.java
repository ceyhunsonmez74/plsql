package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirKrediOdemeplaniiptalTx;
import tr.com.aktifbank.bnspr.dao.BirKrediOdemeplaniiptalTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3288Services {

	@GraymoundService("BNSPR_TRN3288_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3288.son_guncelleme_sorgula(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "SON_ODEME_PLANI_GUNCELLEME";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "ISLEM_NO", rSet.getBigDecimal("TX_NO"));
				oMap.put(tableName, row, "TARIH", rSet.getDate("REC_DATE"));
				oMap.put(tableName, row, "REC_OWNER", rSet.getString("REC_OWNER"));
				oMap.put(tableName, row, "ARA_ODEME_NO", rSet.getString("ARA_ODEME_NO"));
				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3288_AYNI_GUN_KONTROL")
	public static GMMap ayniGunKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3288.ayni_gun_kontrol(?) }");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("IPTAL_TRX_NO"));
			stmt.execute();
			oMap.put("MESSAGE", stmt.getObject(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3288_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirKrediOdemeplaniiptalTx birKrediOdemeplaniiptalTx = new BirKrediOdemeplaniiptalTx();
			BirKrediOdemeplaniiptalTxId id = new BirKrediOdemeplaniiptalTxId();

			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setIptalEdilenTxNo(iMap.getBigDecimal("IPTAL_TRX_NO"));

			birKrediOdemeplaniiptalTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birKrediOdemeplaniiptalTx.setId(id);
			session.saveOrUpdate(birKrediOdemeplaniiptalTx);
			session.flush();

			iMap.put("TRX_NAME", "3288");

			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3288_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_TRN3288.get_info(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "SON_ODEME_PLANI_GUNCELLEME";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "ISLEM_NO", rSet.getBigDecimal("IPTAL_EDILEN_TX_NO"));
				oMap.put(tableName, row, "TARIH", rSet.getDate("REC_DATE"));
				oMap.put(tableName, row, "REC_OWNER", rSet.getString("REC_OWNER"));
				oMap.put(tableName, row, "ARA_ODEME_NO", rSet.getString("ARA_ODEME_NO"));
				oMap.put("TRX_NO", rSet.getBigDecimal("TX_NO"));
				oMap.put("BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
				oMap.put("MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
				oMap.put("ADI_SOYADI", rSet.getString("ADI_SOYADI"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
}
