package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKampanyaSegmentTx;
import tr.com.aktifbank.bnspr.dao.BirKampanyaSegmentTxId;
import tr.com.aktifbank.bnspr.dao.GnlKaraListeTelistisna;
import tr.com.aktifbank.bnspr.dao.GnlKaraListeTelistisnaTx;
import tr.com.aktifbank.bnspr.dao.GnlKaraListeTelistisnaTxId;
import tr.com.calikbank.bnspr.consumerloan.services.ConsumerLoanTRN3113Services.IslemTipi;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3114Services {
	
	@GraymoundService("BNSPR_TRN3114_SAVE")
	public static GMMap saveKaraListeIstisna(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "KARA_LISTE_ISTISNA_TEL_TABLE";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				if (iMap.getString(tableName, row, "ISLEM_TIPI") == null) {
					GnlKaraListeTelistisnaTx istisnaTx = new GnlKaraListeTelistisnaTx();
					GnlKaraListeTelistisnaTxId id = new GnlKaraListeTelistisnaTxId();
					String telNo = iMap.getString(tableName, row, "TEL_NO");
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setIslemTip(IslemTipi.YENI.getKod());
					id.setTelNo(telNo);
					istisnaTx.setId(id);
					
					session.save(istisnaTx);
					session.flush();
				}
			}
			iMap.put("TRX_NAME", "3114");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}
		catch (Exception e) {
			iMap.put("HATA_NO", new BigDecimal(5920));
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3114_GET")
	public static GMMap getKaraListeIstisna(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<GnlKaraListeTelistisna> karaListeIstisna =  session.createCriteria(GnlKaraListeTelistisna.class).list();
			String tableName = "KARA_LISTE_ISTISNA_TEL_TABLE";
			if(!karaListeIstisna.isEmpty()){
				for (int i = 0; i < karaListeIstisna.size(); i++) {
					oMap.put(tableName, i, "TEL_NO", karaListeIstisna.get(i).getTelNo());
					oMap.put(tableName, i, "ISLEM_TIPI", IslemTipi.DEGISIKLIK_YOK.getKod());
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3114_GET_INFO")
	public static GMMap getKaraListeIstisnaById(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<GnlKaraListeTelistisnaTx> karaListeIstisnatx =  session.createCriteria(GnlKaraListeTelistisnaTx.class).
				add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		String tableName = "KARA_LISTE_ISTISNA_TEL_TABLE";
		for (int i = 0; i < karaListeIstisnatx.size(); i++) {
			oMap.put(tableName, i, "TEL_NO", karaListeIstisnatx.get(i).getId().getTelNo());
			oMap.put(tableName, i, "ISLEM_TIPI", karaListeIstisnatx.get(i).getId().getIslemTip());
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3114_DELETE")
	public static GMMap deleteKaraListeIstisna(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		GnlKaraListeTelistisnaTx istisnaTx = new GnlKaraListeTelistisnaTx();
		GnlKaraListeTelistisnaTxId id = new GnlKaraListeTelistisnaTxId();
		GMMap rowMap = iMap.getMap("ROW");
		if (rowMap.getString("TEL_NO") != null) {
			id.setTelNo(rowMap.getString("TEL_NO"));
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setIslemTip(IslemTipi.SILME.getKod());
			istisnaTx.setId(id);
			session.save(istisnaTx);
			session.flush();
			iMap.put("TRX_NAME", "3114");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}
		return oMap;
	}

}
