package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KreSozlesmeTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3153Services {
	@GraymoundService("BNSPR_TRN3153_GET_INFO")
	public static GMMap getInfoTRN1253(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GMMap oMap = new GMMap();

			KreSozlesmeTx kreSozlesmeTx = (KreSozlesmeTx) session.get(KreSozlesmeTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("MUSTERI_NO", kreSozlesmeTx.getMusteriNo());
			oMap.put("SOZLESME_TUR_KODU", kreSozlesmeTx.getSozlesmeTurKodu());
			oMap.put("SOZLESME_NO", kreSozlesmeTx.getSozlesmeNo());
			oMap.put("DURUM_KODU", kreSozlesmeTx.getDurumKodu());
			oMap.put("EK_SOZLESME_NO", kreSozlesmeTx.getEkSozlesmeNo());
			oMap.put("SOZLESME_TARIHI", kreSozlesmeTx.getSozlesmeTarihi());
			oMap.put("DOVIZ_KODU", kreSozlesmeTx.getDovizKodu());
			oMap.put("SOZLESME_TUTARI", kreSozlesmeTx.getSozlesmeTutari());
			oMap.put("VERGILIMI", kreSozlesmeTx.getVergilimi());
			oMap.put("DAMGA_VERGISI", kreSozlesmeTx.getDamgaVergisi());
			oMap.put("DAMGA_VERGISI_MUSTERI_PAYI", kreSozlesmeTx.getDamgaVergisiMusteriPayi());
			oMap.put("MUSTERI_TAHSIL_EDILECEK_TUTAR", kreSozlesmeTx.getMusteriTahsilEdilecekTutar());
			oMap.put("DV_TAHSIL_HESAP_NO", kreSozlesmeTx.getDvTahsilHesapNo());
			oMap.put("DI_MUSTERI_NO", LovHelper.diLov(kreSozlesmeTx.getMusteriNo(), "3153/LOV_MUSTERI", "UNVAN"));
			oMap.put("DI_DOVIZ_KODU", LovHelper.diLov(kreSozlesmeTx.getDovizKodu(), "3153/LOV_DOVIZ", "ACIKLAMA"));

			oMap.put("SOZLESME_AMACI", kreSozlesmeTx.getSozlesmeAmaci());
			oMap.put("SOZLESME_ACIKLAMA", kreSozlesmeTx.getAciklama());
			oMap.put("BASVURU_NO", kreSozlesmeTx.getBasvuruNo());
			oMap.put("HESAP_NO", kreSozlesmeTx.getHesapNo());
			oMap.put("TEMINAT_VEREN", kreSozlesmeTx.getTeminatVeren());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3153_GET_KEFIL_LIST")
	public static GMMap getKefilList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			BigDecimal sozlesmeNo = iMap.getBigDecimal("SOZLESME_NO");
			BigDecimal ekSozlesmeNo = iMap.getBigDecimal("EK_SOZLESME_NO");

			stmt = conn.prepareCall("{call PKG_TRN3153.get_kefil_list(?,?,?,?)}");
	 	 	
	 	 	stmt.setBigDecimal(1, sozlesmeNo);
	 	 	stmt.setBigDecimal(2, ekSozlesmeNo);
	 	 	stmt.setString(3, iMap.getString("KEFIL_MUSTERI_NO"));
	 	 	stmt.registerOutParameter(4, -10);
	 	 	stmt.execute();
	 	 	rSet = (ResultSet)stmt.getObject(4);
			
			String tableName = "KEFIL_LIST";
			
			int row = 0;
			while (rSet.next()) {
				int j = 1;
				
				oMap.put(tableName, row, "KEFIL_MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DI_UNVAN",rSet.getString(j++));
				oMap.put(tableName, row, "KEFALET_SEKLI", rSet.getString(j++));
				oMap.put(tableName, row, "KEFALET_TUTARI",rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "K_DOVIZ_KODU", rSet.getString(j++));				
				oMap.put(tableName, row, "KEFALET_ORANI", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KEFALET_TAAHHUTNAME", rSet.getString(j++));
				oMap.put(tableName, row, "KEFALET_ES_MUVAFAKATNAME", rSet.getString(j++));
				oMap.put(tableName, row, "KEFALET_CAYMA_TARIHI", rSet.getDate(j++));
				
				row++;
			}
			oMap.put("ROW_COUNT", row);
						
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3153_SAVE")
	public static Map<?, ?> saveTRN3153(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			KreSozlesmeTx kreSozlesmeTx = (KreSozlesmeTx) session.get(KreSozlesmeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kreSozlesmeTx == null) {
				kreSozlesmeTx = new KreSozlesmeTx();
			}

			kreSozlesmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kreSozlesmeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			kreSozlesmeTx.setSozlesmeNo(iMap.getBigDecimal("SOZLESME_NO"));
			kreSozlesmeTx.setSozlesmeTurKodu(iMap.getString("SOZLESME_TUR_KODU"));
			kreSozlesmeTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			kreSozlesmeTx.setEkSozlesmeNo(iMap.getBigDecimal("EK_SOZLESME_NO"));
			kreSozlesmeTx.setSozlesmeTarihi(iMap.getDate("SOZLESME_TARIHI"));
			kreSozlesmeTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			kreSozlesmeTx.setSozlesmeTutari(iMap.getBigDecimal("SOZLESME_TUTARI"));
			kreSozlesmeTx.setVergilimi(iMap.getString("VERGILIMI"));
			kreSozlesmeTx.setDamgaVergisi(iMap.getString("DAMGA_VERGISI"));
			kreSozlesmeTx.setDamgaVergisiMusteriPayi(iMap.getBigDecimal("DAMGA_VERGISI_MUSTERI_PAYI"));
			kreSozlesmeTx.setMusteriTahsilEdilecekTutar(iMap.getBigDecimal("MUSTERI_TAHSIL_EDILECEK_TUTAR"));
			kreSozlesmeTx.setDvTahsilHesapNo(iMap.getBigDecimal("DV_TAHSIL_HESAP_NO"));

			kreSozlesmeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			kreSozlesmeTx.setAciklama(iMap.getString("SOZLESME_ACIKLAMA"));
			kreSozlesmeTx.setSozlesmeAmaci(iMap.getString("SOZLESME_AMACI"));
			kreSozlesmeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));

			session.saveOrUpdate(kreSozlesmeTx);
			session.flush();

			iMap.put("TRX_NAME", "3153");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3153_HATA_YAZ")
	public static GMMap hataYaz(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			return oMap;
		} catch (Exception e) {
			oMap.put("MESSAGE", e.getMessage());
			return oMap;			
		} 
	}
}
