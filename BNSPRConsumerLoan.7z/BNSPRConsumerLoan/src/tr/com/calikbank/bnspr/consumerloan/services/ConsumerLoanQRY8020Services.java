package tr.com.calikbank.bnspr.consumerloan.services;


import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY8020Services {
	
	@GraymoundService("BNSPR_QRY8020_DCS_ARAMA_DETAYLARI")
	public static GMMap dcsAramaDetay(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			GMMap tMap = new GMMap();	
			tMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
			
			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_DCS_COMMUNICATION_INFO" , tMap));
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
		return oMap;
		
	}
	
	@GraymoundService("BNSPR_QRY8020_DCS_URUN_BILGILERI")
	public static GMMap dcsUrunBilgileri(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			GMMap tMap = new GMMap();	
			tMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));	
			tMap.put("BASVURU_NO", iMap.getString("BASVURU_NO"));
			
			oMap.putAll(GMServiceExecuter.executeNT("BNSPR_DCS_URUN_BILGILERI", tMap)); 
			
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		
		return oMap;
		
	}
	
}
