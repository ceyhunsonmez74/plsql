package tr.com.calikbank.bnspr.consumerloan.document.type;

import java.util.HashMap;
import java.util.Map.Entry;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.calikbank.bnspr.consumerloan.utils.Enums;

public class CreditPaymentPlan  extends WebCreditDocument {

	public CreditPaymentPlan() {
		super("creditInfoPaymentPlan", "creditInfoPaymentPlan", Enums.CreditDocTypes.CREDIT_PAYMENT_PLAN.getCode());
	}

	@Override
	public String generateXml(String applicationNo, HashMap<String, Object> parameters) {
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);

		StringBuilder builder = new StringBuilder();
		builder.append("<AGREEMENT_INFO>");
		
		if (parameters != null) {
			for (Entry<String, Object> entry : parameters.entrySet()) {
				builder.append("<" + entry.getKey() + ">");
				builder.append(entry.getValue());
				builder.append("</" + entry.getKey() + ">");
			}
		}
		
		builder.append(GMServiceExecuter.call("BNSPR_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		builder.append(GMServiceExecuter.call("BNSPR_BASVURU_ODEME_PLANI_XML", iMap).getString("XML"));
		builder.append(GMServiceExecuter.call("BNSPR_BASVURU_ODEME_TOPLAMLARI_XML", iMap).getString("XML"));
		builder.append(GMServiceExecuter.call("BNSPR_BASVURU_SOZLESME_BILGI_XML", iMap).getString("XML"));
		builder.append("</AGREEMENT_INFO>");

		return builder.toString();
	}

}
