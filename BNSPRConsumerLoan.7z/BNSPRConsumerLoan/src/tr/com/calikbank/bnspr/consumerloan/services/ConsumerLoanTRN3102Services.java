package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.PropertyValueException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKrdAltTurTx;
import tr.com.calikbank.bnspr.dao.BirKrdAltTurTxId;
import tr.com.calikbank.bnspr.dao.VMlBirKrdAltTur;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3102Services {

	@GraymoundService("BNSPR_TRN3102_GET_KRD_ALT_TUR")
	public static GMMap getKredAltTur(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(VMlBirKrdAltTur.class).add(Restrictions.eq("id.krdTurKod", iMap.getBigDecimal("KRD_TUR_KOD"))).addOrder(Order.asc("id.krdTurKod")).addOrder(Order.asc("id.kod")).list();

			GMMap oMap = new GMMap();
			String tableName = "KRD_ALT_TUR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				VMlBirKrdAltTur birKrdAltTur = (VMlBirKrdAltTur) iterator.next();

				oMap.put(tableName, row, "DRM", birKrdAltTur.getDrm());
				oMap.put(tableName, row, "KOD", birKrdAltTur.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA", birKrdAltTur.getAciklama());

				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3102_GET_KRD_ALT_TUR_WITH_TX_NO")
	public static GMMap getKrdAltTurWithTxNo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirKrdAltTurTx.class).add(Restrictions.and(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")), Restrictions.isNull("sil"))).list();

			String tableName = "KRD_ALT_TUR";
			int row = 0;
			GMMap oMap = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirKrdAltTurTx birKrdAltTurTx = (BirKrdAltTurTx) iterator.next();

				oMap.put(tableName, row, "DRM", birKrdAltTurTx.getDrm());
				oMap.put(tableName, row, "KOD", birKrdAltTurTx.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA", birKrdAltTurTx.getAciklama());
				oMap.put("KRD_TUR_KOD", birKrdAltTurTx.getId().getKrdTurKod());
				row++;
			}
			oMap.put("KRD_TUR_KOD_ACIKLAMA", LovHelper.diLov(oMap.getString("KRD_TUR_KOD"), "3102/LOV_KRD_ALT_TUR", "ACIKLAMA"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3102_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		boolean flag = true;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "KRD_ALT_TUR";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i=0;i<list.size();i++) {

				BirKrdAltTurTx birKrdAltTurTx = new BirKrdAltTurTx();
				BirKrdAltTurTxId birKrdAltTurTxId = new BirKrdAltTurTxId();
				birKrdAltTurTxId.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
				birKrdAltTurTxId.setKrdTurKod(iMap.getBigDecimal("TUR_KOD"));
				birKrdAltTurTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));

				birKrdAltTurTx.setId(birKrdAltTurTxId);

				birKrdAltTurTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				birKrdAltTurTx.setDrm(iMap.getString(tableName, i, "DRM"));

				session.save(birKrdAltTurTx);
				flag = false;
			}
			session.flush();
			if (flag)
				kayitSil(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("TUR_KOD"));
			iMap.put("TRX_NAME", "3102");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (NonUniqueObjectException e) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		} catch (ConstraintViolationException e) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("MESSAGE_NO", new BigDecimal(715));
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		} catch (PropertyValueException e) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("MESSAGE_NO", new BigDecimal(330));
			myMap.put("P1", "Kredi Tipi");
			throw new GMRuntimeException(0, (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static void kayitSil(BigDecimal trxNo, BigDecimal kod) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3102.TumKayitSil(?, ?)}");
			stmt.setBigDecimal(1, trxNo);
			stmt.setBigDecimal(2, kod);
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3102_GET_CODE")
	public static GMMap getCode(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('BIR_KRD_ALT_TUR')}");
			stmt.registerOutParameter(1, Types.NUMERIC);

			stmt.execute();

			BigDecimal code = stmt.getBigDecimal(1);

			oMap.put("CODE", code);

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3102_NOT_NULL_SECIM_KRITER")
	public static GMMap notNullSecimKriter(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			if (iMap.getBigDecimal("KREDI_TURU") == null) {
				iMap.put("HATA_NO", new BigDecimal(758));
				iMap.put("P1", "Kredi T�r�");
				iMap.put("P2", "Listele");
				return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			return new GMMap();

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
