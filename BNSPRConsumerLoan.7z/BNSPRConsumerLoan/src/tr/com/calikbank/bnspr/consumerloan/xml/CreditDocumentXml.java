package tr.com.calikbank.bnspr.consumerloan.xml;

import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CreditDocumentXml {

	
	@GraymoundService("BNSPR_BASVURU_ODEME_PLANI_XML")
	public static GMMap getBasvuruOdemePlaniXml(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KREDI_DOKUMAN_XML.basvuruOdemePlani(?)}");
			
			stmt.registerOutParameter(1, Types.CLOB);
			stmt.setLong(2, iMap.getLong("BASVURU_NO"));
			stmt.execute();
			
			Clob clob=stmt.getClob(1);
			if(clob!=null){
				oMap.put("XML", clob.getSubString(1, (int)clob.length()).trim());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_BASVURU_ODEME_TOPLAMLARI_XML")
	public static GMMap getBasvuruOdemeToplamlariXml(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KREDI_DOKUMAN_XML.basvuruOdemeToplamlari(?)}");
			
			stmt.registerOutParameter(1, Types.CLOB);
			stmt.setLong(2, iMap.getLong("BASVURU_NO"));
			stmt.execute();
			
			Clob clob=stmt.getClob(1);
			if(clob!=null){
				oMap.put("XML", clob.getSubString(1, (int)clob.length()).trim());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	
	@GraymoundService("BNSPR_BASVURU_SOZLESME_BILGI_XML")
	public static GMMap getBasvuruSozlesmeXml(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KREDI_DOKUMAN_XML.basvuruSozlesmeBilgi(?)}");
			
			stmt.registerOutParameter(1, Types.CLOB);
			stmt.setLong(2, iMap.getLong("BASVURU_NO"));
			stmt.execute();
			
			Clob clob=stmt.getClob(1);
			if(clob!=null){
				oMap.put("XML", clob.getSubString(1, (int)clob.length()).trim());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_BASVURU_MUSTERI_BILGI_XML")
	public static GMMap getBasvuruMusteriBilgiXml(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_KREDI_DOKUMAN_XML.basvuruMusteriBilgi(?)}");
			
			stmt.registerOutParameter(1, Types.CLOB);
			stmt.setLong(2, iMap.getLong("BASVURU_NO"));
			stmt.execute();
			
			Clob clob=stmt.getClob(1);
			if(clob!=null){
				oMap.put("XML", clob.getSubString(1, (int)clob.length()).trim());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	

	
}
