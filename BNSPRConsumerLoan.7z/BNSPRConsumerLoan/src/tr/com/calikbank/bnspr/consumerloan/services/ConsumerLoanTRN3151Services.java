package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KreSozlesmeKefilTx;
import tr.com.calikbank.bnspr.dao.KreSozlesmeKefilTxId;
import tr.com.calikbank.bnspr.dao.KreSozlesmeTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3151Services {
	
	@GraymoundService("BNSPR_TRN3151_GET_KEFALET_SEKLI")
	public static GMMap getComboLimit(GMMap iMap){
		String listName = "KEFALET_SEKLI_MODEL";
		GuimlUtil.wrapMyCombo(iMap, listName, "TUTAR", "Tutar");
		GuimlUtil.wrapMyCombo(iMap, listName, "ORAN", "Oran");
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN3151_GET_KEFALET_TAAHHUTNAME")
	public static GMMap getKefaletTaahhutname(GMMap iMap){
		String listName = "KEFALET_TAAHHUTNAME";
		GuimlUtil.wrapMyCombo(iMap, listName, "V", "Var");
		GuimlUtil.wrapMyCombo(iMap, listName, "Y", "Yok");
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN3151_GET_KEFALET_ES_MUVAFAKATNAME")
	public static GMMap getKefaletEsMuvafakatname(GMMap iMap){
		String listName = "KEFALET_ES_MUVAFAKATNAME";
		GuimlUtil.wrapMyCombo(iMap, listName, "V", "Var");
		GuimlUtil.wrapMyCombo(iMap, listName, "Y", "Yok");
		GuimlUtil.wrapMyCombo(iMap, listName, "B", "Bekar");
		GuimlUtil.wrapMyCombo(iMap, listName, "F", "Firma Sahibi/Orta��");
		GuimlUtil.wrapMyCombo(iMap, listName, "T", "T�zel");

		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN3151_SAVE_SOZLEME_GIRIS")
	public static Map<?, ?> saveTRN3151(GMMap iMap) {
		try{	                                                                  
	        Session session = DAOSession.getSession("BNSPRDal");
	        KreSozlesmeTx kreSozlesmeTx = (KreSozlesmeTx) session.get(KreSozlesmeTx.class, iMap.getBigDecimal("TRX_NO"));
	        if (kreSozlesmeTx == null ) {
	        	kreSozlesmeTx = new KreSozlesmeTx();
	        	kreSozlesmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
	        }
	        kreSozlesmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
	        kreSozlesmeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
	        kreSozlesmeTx.setSozlesmeTurKodu(iMap.getString("SOZLESME_TUR_KODU"));
	        kreSozlesmeTx.setSozlesmeNo(iMap.getBigDecimal("SOZLESME_NO"));
	        kreSozlesmeTx.setEkSozlesmeNo(iMap.getBigDecimal("EK_SOZLESME_NO"));
	        kreSozlesmeTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
	        kreSozlesmeTx.setSozlesmeTutari(iMap.getBigDecimal("SOZLESME_TUTARI"));
            kreSozlesmeTx.setSozlesmeTarihi(iMap.getDate("SOZLESME_TARIHI"));
            kreSozlesmeTx.setTanzimTarihi(iMap.getDate("TANZIM_TARIHI"));
	        kreSozlesmeTx.setSozlesmeAmaci(iMap.getString("SOZLESME_AMACI"));
	        kreSozlesmeTx.setVergilimi(iMap.getString("VERGILIMI"));
	        kreSozlesmeTx.setDamgaVergisi(iMap.getString("DAMGA_VERGISI"));
	        kreSozlesmeTx.setDamgaVergisiMusteriPayi(iMap.getBigDecimal("DAMGA_VERGISI_MUSTERI_PAYI"));
	        kreSozlesmeTx.setMusteriTahsilEdilecekTutar(iMap.getBigDecimal("MUSTERI_TAHSIL_EDILECEK_TUTAR"));
	        kreSozlesmeTx.setDvTahsilHesapNo(iMap.getBigDecimal("DV_TAHSIL_HESAP_NO"));
	        kreSozlesmeTx.setSubeKodu(iMap.getString("SUBE_KOD"));
	        kreSozlesmeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
	        kreSozlesmeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
	        kreSozlesmeTx.setDurumKodu("ACIK");
	        kreSozlesmeTx.setAciklama(iMap.getString("SOZLESME_ACIKLAMA"));
	        kreSozlesmeTx.setTeminatVeren(iMap.getBigDecimal("TEMINAT_VEREN"));
	        
	        session.saveOrUpdate(kreSozlesmeTx);
	        
	        List<?> kefilPersistenceList = session.createCriteria(KreSozlesmeKefilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        for (Iterator<?> iterator = kefilPersistenceList.iterator(); iterator.hasNext();) {
				KreSozlesmeKefilTx kreSozlesmeKefilTx = (KreSozlesmeKefilTx) iterator.next();
				session.delete(kreSozlesmeKefilTx);
			}
	        session.flush();
	        
	        String tableName = "SOZLESME_KEFIL_ISLEM";
	        ArrayList<?> sozlesmeKefilIslem = (ArrayList<?>)iMap.get(tableName);
	        for (int i=0; i<sozlesmeKefilIslem.size(); i++) {

				KreSozlesmeKefilTx kefilTx = (KreSozlesmeKefilTx) session.createCriteria(KreSozlesmeKefilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kefilMusteriNo", iMap.getBigDecimal(tableName, i, "KEFIL_MUSTERI_NO"))).uniqueResult();
				if(kefilTx != null)
				{
					iMap.put("HATA_NO", new BigDecimal(723));
					iMap.put("P1", "Kefiller");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				else
		        {
					kefilTx = new KreSozlesmeKefilTx();
					KreSozlesmeKefilTxId id = new KreSozlesmeKefilTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setKefilMusteriNo(iMap.getBigDecimal(tableName, i, "KEFIL_MUSTERI_NO"));
					kefilTx.setId(id);
					kefilTx.setDovizKodu(iMap.getString(tableName, i, "K_DOVIZ_KODU"));
					kefilTx.setEkSozlesmeNo(iMap.getBigDecimal("EK_SOZLESME_NO"));
					kefilTx.setKefaletOrani(iMap.getBigDecimal(tableName, i, "KEFALET_ORANI"));
					kefilTx.setKefaletSekli(iMap.getString(tableName, i, "KEFALET_SEKLI"));
					kefilTx.setKefaletTutari(iMap.getBigDecimal(tableName, i, "KEFALET_TUTARI"));
					kefilTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
					kefilTx.setSozlesmeNo(iMap.getBigDecimal("SOZLESME_NO"));
					kefilTx.setKefaletTaahhutname(iMap.getString(tableName, i, "KEFALET_TAAHHUTNAME"));
					kefilTx.setKefaletEsMuvafakatname(iMap.getString(tableName, i, "KEFALET_ES_MUVAFAKATNAME"));
					kefilTx.setKefaletCaymaTarihi(iMap.getDate(tableName, i, "KEFALET_CAYMA_TARIHI"));
					session.save(kefilTx);
	        	}
			}
	        session.flush();
	        
	        iMap.put("TRX_NAME","3151");
        	return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	        
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}                     
	}
	
	@GraymoundService("BNSPR_TRN3151_GET_SOZLESME_GIRIS")
	public static GMMap getSozlemeGiris(GMMap iMap) {
		try{	                                                                  
	        Session session = DAOSession.getSession("BNSPRDal");
	        GMMap oMap = new GMMap();
	        KreSozlesmeTx kreSozlesmeTx = null;
	        if(iMap.containsKey("TRX_NO"))
	        	kreSozlesmeTx = (KreSozlesmeTx) session.get(KreSozlesmeTx.class, iMap.getBigDecimal("TRX_NO"));
	        else
	        	kreSozlesmeTx = (KreSozlesmeTx) session.createCriteria(KreSozlesmeTx.class).add(Restrictions.eq("sozlesmeNo", iMap.getBigDecimal("SOZLESME_NO"))).uniqueResult();
	        oMap.put("TRX_NO", kreSozlesmeTx.getTxNo());
	        oMap.put("MUSTERI_NO", kreSozlesmeTx.getMusteriNo());
	        oMap.put("UNVAN", LovHelper.diLov(kreSozlesmeTx.getMusteriNo(), "3151/LOV_MUSTERI", "UNVAN"));
	        oMap.put("SOZLESME_TUR_KODU", kreSozlesmeTx.getSozlesmeTurKodu());
	        oMap.put("SOZLESME_NO", kreSozlesmeTx.getSozlesmeNo());
	        oMap.put("BASVURU_NO", kreSozlesmeTx.getBasvuruNo());
	        oMap.put("EK_SOZLESME_NO", kreSozlesmeTx.getEkSozlesmeNo());
	        oMap.put("DOVIZ_KODU", kreSozlesmeTx.getDovizKodu());
	        oMap.put("SOZLESME_TUTARI", kreSozlesmeTx.getSozlesmeTutari());
            oMap.put("SOZLESME_TARIHI", kreSozlesmeTx.getSozlesmeTarihi());
            oMap.put("TANZIM_TARIHI", kreSozlesmeTx.getTanzimTarihi());
	        oMap.put("VERGILIMI", kreSozlesmeTx.getVergilimi());
	        oMap.put("DAMGA_VERGISI", kreSozlesmeTx.getDamgaVergisi());
            oMap.put("HESAP_NO", kreSozlesmeTx.getHesapNo());
            oMap.put("SOZLESME_ACIKLAMA", kreSozlesmeTx.getAciklama());
            oMap.put("TEMINAT_VEREN", kreSozlesmeTx.getTeminatVeren());
            oMap.put("TEMINAT_VEREN_UNVAN", LovHelper.diLov(kreSozlesmeTx.getTeminatVeren(), "3151/LOV_TEMINAT_VEREN_MUSTERI", "UNVAN"));
            
	        if(kreSozlesmeTx.getDamgaVergisiMusteriPayi() != null)
	        	oMap.put("DAMGA_VERGISI_MUSTERI_PAYI", kreSozlesmeTx.getDamgaVergisiMusteriPayi().intValue() + "");
	        else
	        	oMap.put("DAMGA_VERGISI_MUSTERI_PAYI", (String)null);
	        oMap.put("MUSTERI_TAHSIL_EDILECEK_TUTAR", kreSozlesmeTx.getMusteriTahsilEdilecekTutar());
	        oMap.put("SUBE_KOD", kreSozlesmeTx.getSubeKodu());
	        oMap.put("DV_TAHSIL_HESAP_NO", kreSozlesmeTx.getDvTahsilHesapNo());

	        List<?> kefilPersistenceList = session.createCriteria(KreSozlesmeKefilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

	        String tableName = "SOZLESME_KEFIL_ISLEM";
			int row = 0;
	        for (Iterator<?> iterator = kefilPersistenceList.iterator(); iterator.hasNext();row++) {
				KreSozlesmeKefilTx kreSozlesmeKefilTx = (KreSozlesmeKefilTx) iterator.next();
				oMap.put(tableName, row, "KEFIL_MUSTERI_NO", kreSozlesmeKefilTx.getId().getKefilMusteriNo());
				oMap.put(tableName, row, "DI_UNVAN", LovHelper.diLov(kreSozlesmeKefilTx.getId().getKefilMusteriNo(),kreSozlesmeTx.getMusteriNo(), "3151/LOV_KEFIL_MUSTERI", "UNVAN"));
				oMap.put(tableName, row, "K_DOVIZ_KODU", kreSozlesmeKefilTx.getDovizKodu());
				oMap.put(tableName, row, "EK_SOZLESME_NO", kreSozlesmeKefilTx.getEkSozlesmeNo());
				oMap.put(tableName, row, "KEFALET_ORANI", kreSozlesmeKefilTx.getKefaletOrani());
				oMap.put(tableName, row, "KEFALET_TUTARI", kreSozlesmeKefilTx.getKefaletTutari());
				oMap.put(tableName, row, "KEFALET_SEKLI", kreSozlesmeKefilTx.getKefaletSekli());
				oMap.put(tableName, row, "SOZLESME_NO", kreSozlesmeKefilTx.getSozlesmeNo());
				oMap.put(tableName, row, "KEFALET_TAAHHUTNAME", kreSozlesmeKefilTx.getKefaletTaahhutname());
				oMap.put(tableName, row, "KEFALET_ES_MUVAFAKATNAME", kreSozlesmeKefilTx.getKefaletEsMuvafakatname());
				oMap.put(tableName, row, "KEFALET_CAYMA_TARIHI", kreSozlesmeKefilTx.getKefaletCaymaTarihi());
			}

        	return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}                     
	}
	
	@GraymoundService("BNSPR_TRN3151_GET_SOZLESME_NO")
	public static GMMap getSozlesmeNo(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();			
			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('KRE_SOZLESME')}");			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();

			oMap.put("SOZLESME_NO", stmt.getObject(1));
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3151_GET_SOZLESME_TIP")
	public static GMMap getSozlesmeTip(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();			
			stmt = conn.prepareCall("{? = call pkg_genel_pr.Sozlesme_Tip(?)}");			
			stmt.registerOutParameter(1, Types.CHAR);
			stmt.setString(2, iMap.getString("TUR"));
			stmt.execute();

			oMap.put("SOZLESME_TIP", stmt.getString(1));
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
}
