package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.BirBasvuruHasarTahsilat;
import tr.com.aktifbank.bnspr.dao.BirBasvuruHasarTahsilatTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSgPrimiade;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSgPrimiadeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruHasarTahsilat;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3243Services {
	
	@GraymoundService("BNSPR_TRN3243_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBox(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "SIGORTASIRKET");
			oMap.put(
					"SIGORTA_SIRKETI",
					GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
							iMap).get("RESULTS"));
			
			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "PRIM_IADE_NEDENI");
			oMap.put(
					"IADE_NEDENI",
					GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
							iMap).get("RESULTS"));
		   
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}


	@GraymoundService("BNSPR_TRN3243_CALCULATE_GECICI_DK_TUTAR")
	public static GMMap calculateGeciciDKTutar(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			BigDecimal kapamaTutari = iMap.getBigDecimal("KAPAMA_TUTARI");
			BigDecimal tutar = iMap.getBigDecimal("TUTAR");
			
			BigDecimal geciciDkTutar = kapamaTutari.subtract(tutar);				
			
			oMap.put("GECICI_DK_TUTAR", geciciDkTutar);		   
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			//
		}
	}
	
	@GraymoundService("BNSPR_TRN3243_CHECK_HASAR_TAHSIL_HESAP")
	public static GMMap checkHasarTahsilHesap(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3243.Hasar_tahsil_hesap_kontrol(?,?)}");
			int parameterIndex=1;
			
			stmt.registerOutParameter(parameterIndex++, Types.VARCHAR);
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("HESAP_NO"));
			
			stmt.execute();
			
			String mesaj = (String) stmt.getObject(1);
			
			oMap.put("MESAJ", mesaj);		   
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3243_SAVE")
	public static Map<?, ?> save(GMMap iMap){

		try{
			Session session = DAOSession.getSession("BNSPRDal"); 
					
			  if(iMap.getBigDecimal("TAB").compareTo(new BigDecimal(0)) == 0){
				  
		    	BirBasvuruHasarTahsilatTx birBasvuruHasarTahsilatTx = new BirBasvuruHasarTahsilatTx();
				
		    	birBasvuruHasarTahsilatTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		    	birBasvuruHasarTahsilatTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
		    	birBasvuruHasarTahsilatTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
		    	birBasvuruHasarTahsilatTx.setKrediHesapNo(iMap.getBigDecimal("KREDI_HESAP_NO"));
		    	birBasvuruHasarTahsilatTx.setVadesizHesapNo(iMap.getBigDecimal("VADESIZ_HESAP_NO"));
		    	birBasvuruHasarTahsilatTx.setSigortaSirketi(iMap.getString("SIGORTA_SIRKETI"));
		    	birBasvuruHasarTahsilatTx.setSigortaSirketMusteriNo(iMap.getBigDecimal("SIGORTA_SIRKET_MUSTERI_NO"));
		    	birBasvuruHasarTahsilatTx.setPoliceNo(iMap.getString("POLICE_NO"));
		    	birBasvuruHasarTahsilatTx.setHasarTahsilHesapNo(iMap.getBigDecimal("HASAR_TAHSIL_HESAP_NO"));
		    	birBasvuruHasarTahsilatTx.setTutar(iMap.getBigDecimal("TUTAR"));
		    	birBasvuruHasarTahsilatTx.setSgkGeciciHesapNo(iMap.getBigDecimal("SGK_GECICI_HESAP_NO"));
		    	birBasvuruHasarTahsilatTx.setAciklama(iMap.getString("ACIKLAMA"));
		    	birBasvuruHasarTahsilatTx.setDovizKod("TRY");

				session.saveOrUpdate(birBasvuruHasarTahsilatTx);
	          
			    session.flush();  
			  }else{
				  
				  BirBasvuruSgPrimiadeTx birBasvuruSgPrimiadeTx = new BirBasvuruSgPrimiadeTx();
				  
				  birBasvuruSgPrimiadeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				  birBasvuruSgPrimiadeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO2"));
				  birBasvuruSgPrimiadeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO2"));
				  birBasvuruSgPrimiadeTx.setKrediHesapNo(iMap.getBigDecimal("KREDI_HESAP_NO2"));
				  birBasvuruSgPrimiadeTx.setVadesizHesapNo(iMap.getBigDecimal("VADESIZ_HESAP_NO2"));
				  birBasvuruSgPrimiadeTx.setSigortaSirketi(iMap.getString("SIGORTA_SIRKETI2"));
				  birBasvuruSgPrimiadeTx.setSigSirketHesapNo(iMap.getBigDecimal("SIG_SIRKET_HESAP_NO"));
				  birBasvuruSgPrimiadeTx.setPrimTutari(iMap.getBigDecimal("PRIM_TUTARI"));
				  birBasvuruSgPrimiadeTx.setKomisyonTutari(iMap.getBigDecimal("KOMISYON_TUTARI"));
				  birBasvuruSgPrimiadeTx.setIadeSigSirketHesapNo(iMap.getBigDecimal("IADE_SIG_SIRKET_HESAP_NO"));
				  birBasvuruSgPrimiadeTx.setIadeNedeni(iMap.getString("IADE_NEDENI"));
				  birBasvuruSgPrimiadeTx.setAciklama(iMap.getString("ACIKLAMA2"));
				  birBasvuruSgPrimiadeTx.setDovizKod("TRY");
				  
				  session.save(birBasvuruSgPrimiadeTx);
		          
				  session.flush(); 
				 
			  }
			
			iMap.put("TRX_NAME", "3243");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3243_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
				
		List<?> list = (List<?>)session.createCriteria(BirBasvuruHasarTahsilatTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();	 
	    			
		 for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			 
			BirBasvuruHasarTahsilatTx birBasvuruHasarTahsilatTx = (BirBasvuruHasarTahsilatTx) iterator.next();
			
			oMap.put("BASVURU_NO", birBasvuruHasarTahsilatTx.getBasvuruNo());
			oMap.put("MUSTERI_NO", birBasvuruHasarTahsilatTx.getMusteriNo());
			oMap.put("UNVAN", LovHelper.diLov(birBasvuruHasarTahsilatTx.getMusteriNo(), birBasvuruHasarTahsilatTx.getBasvuruNo(), "3243/LOV_MUSTERI_NO", "UNVAN"));
			oMap.put("KREDI_HESAP_NO", birBasvuruHasarTahsilatTx.getKrediHesapNo());
			oMap.put("VADESIZ_HESAP_NO", birBasvuruHasarTahsilatTx.getVadesizHesapNo());
			oMap.put("SIGORTA_SIRKETI", birBasvuruHasarTahsilatTx.getSigortaSirketi());
			oMap.put("SIGORTA_SIRKET_MUSTERI_NO", birBasvuruHasarTahsilatTx.getSigortaSirketMusteriNo());
			oMap.put("POLICE_NO", birBasvuruHasarTahsilatTx.getPoliceNo());
			oMap.put("HASAR_TAHSIL_HESAP_NO", birBasvuruHasarTahsilatTx.getHasarTahsilHesapNo());
			oMap.put("TUTAR", birBasvuruHasarTahsilatTx.getTutar());
			oMap.put("SGK_GECICI_HESAP_NO", birBasvuruHasarTahsilatTx.getSgkGeciciHesapNo());
			oMap.put("ACIKLAMA", birBasvuruHasarTahsilatTx.getAciklama());
			oMap.put("TAB", new BigDecimal(0));

		 }
		 
		 List<?> list2 = (List<?>)session.createCriteria(BirBasvuruSgPrimiadeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();	 
			
		 for (Iterator<?> iterator = list2.iterator(); iterator.hasNext();) {
			 
			BirBasvuruSgPrimiadeTx birBasvuruSgPrimiadeTx = (BirBasvuruSgPrimiadeTx) iterator.next();
			
			oMap.put("BASVURU_NO2", birBasvuruSgPrimiadeTx.getBasvuruNo());
			oMap.put("MUSTERI_NO2", birBasvuruSgPrimiadeTx.getMusteriNo());
			oMap.put("UNVAN2", LovHelper.diLov(birBasvuruSgPrimiadeTx.getMusteriNo(), birBasvuruSgPrimiadeTx.getBasvuruNo(), birBasvuruSgPrimiadeTx.getBasvuruNo(), "3243/LOV_MUSTERI_NO2", "UNVAN"));
			oMap.put("KREDI_HESAP_NO2", birBasvuruSgPrimiadeTx.getKrediHesapNo());
			oMap.put("VADESIZ_HESAP_NO2", birBasvuruSgPrimiadeTx.getVadesizHesapNo());
			oMap.put("SIGORTA_SIRKETI2", birBasvuruSgPrimiadeTx.getSigortaSirketi());
			oMap.put("SIG_SIRKET_HESAP_NO", birBasvuruSgPrimiadeTx.getSigSirketHesapNo());
			oMap.put("PRIM_TUTARI", birBasvuruSgPrimiadeTx.getPrimTutari());
			oMap.put("KOMISYON_TUTARI", birBasvuruSgPrimiadeTx.getKomisyonTutari());
			oMap.put("IADE_SIG_SIRKET_HESAP_NO", birBasvuruSgPrimiadeTx.getIadeSigSirketHesapNo());
			oMap.put("IADE_NEDENI", birBasvuruSgPrimiadeTx.getIadeNedeni());
			oMap.put("ACIKLAMA2", birBasvuruSgPrimiadeTx.getAciklama());
			oMap.put("TAB", new BigDecimal(1));

		 }
		 
        	return oMap;
        	
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	
}
