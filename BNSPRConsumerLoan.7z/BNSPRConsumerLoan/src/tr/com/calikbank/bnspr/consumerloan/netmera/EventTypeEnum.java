package tr.com.calikbank.bnspr.consumerloan.netmera;

/*1601VD
 * serviceId-> "2" profile attribute , "3" push event*/
public enum EventTypeEnum {
	OnOnayEvent("1", "PASSO,ANKARA_CARD"),
	KullandirimEvent("WebCrediKdhKullanimEvent", "3", "PASSO");

	private String eventName;
	private String serviceId;
	private String appName;

	private EventTypeEnum(String eventName, String serviceId, String appName) {
		this.eventName = eventName;
		this.serviceId = serviceId;
		this.appName = appName;
	}
	
	private EventTypeEnum(String serviceId, String appName) {
		this.serviceId = serviceId;
		this.appName = appName;
	}
	
	public String getEventName() {
		return eventName;
	}
	
	public String getServiceId() {
		return serviceId;
	}

	public String getAppName() {
		return appName;
	}

}
