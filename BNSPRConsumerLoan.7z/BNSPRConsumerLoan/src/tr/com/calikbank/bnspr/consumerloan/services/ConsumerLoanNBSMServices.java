package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Struct;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import oracle.sql.ARRAY;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanNBSMServices {
	
	//**************************************************** ESKI SISTEM
	@GraymoundService("BNSPR_NBSM_COLLECT_DATA")
	public static GMMap collectNbsmData(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			GMMap sorguMap = null;
			
			//Calisacak is listesi
			List<GMMap> parallelJobList = new ArrayList<GMMap>();
			//Calisacak isleri olustur
			for (int i = 1; i <= 6; i++) {
				//KKB datasi alinmasin
				if (i == 5 && Constants.HAYIR.equals(ConsumerLoanCommonServices.nvl(iMap.getString("KKB_DATA_ALINSIN_MI"), Constants.EVET))) {
					continue;
				}
				//Isi olustur
				if(i == 5) {
					GMMap pMap = new GMMap();
					pMap.put("PARAMETRE", "BIR_NBSM_KKB_PARALEL_COUNT");
					int paralelCount = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", pMap).getInt("DEGER");
					for (int k = 1; k <= paralelCount; k++) {
						sorguMap = new GMMap();
						sorguMap.put("T_SERVICE_NAME", "BNSPR_NBSM_COLLECT_TYPE_DATA");//calisacak servis
						sorguMap.put("TUR_NO", i);//tur numarasi
						sorguMap.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));
						sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
						sorguMap.put("SIRA_NO", k);
						parallelJobList.add(sorguMap);
					}
				}else{
					sorguMap = new GMMap();
					sorguMap.put("T_SERVICE_NAME", "BNSPR_NBSM_COLLECT_TYPE_DATA");//calisacak servis
					sorguMap.put("TUR_NO", i);//tur numarasi
					sorguMap.put("SORGU_SEVIYESI", iMap.getString("SORGU_SEVIYESI"));
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
					parallelJobList.add(sorguMap);
				}
			}
			
			//Calisacak isleri paralel olarak isle.
			GMMap jobMap = new GMMap();
			jobMap.put("T_TASKS", parallelJobList);
			jobMap.putAll(GMServiceExecuter.callParallel(jobMap));
			
			//Hata alirsa handle et
			if (!jobMap.getBoolean("T_SUCCESSFUL")) {
				throw new GMRuntimeException(0, "NBSM data toplama hatasi");
			} else {
				GMMap keyMap = null;
				for (int i = 0; i < jobMap.getSize("T_RESULTS"); i++) {
					keyMap = jobMap.getMap("T_RESULTS", i);
					keyMap.remove("T_SUCCESSFUL");
					keyMap.remove("CORE_TRX_ID_RESERVED");
					if(oMap.containsKey("KKB") && keyMap.containsKey("KKB")){
						oMap.getMap("KKB").putAll(keyMap.getMap("KKB"));
					}else{
						oMap.putAll(keyMap);
					}	
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		oMap.remove("CORE_TRX_ID_RESERVED");
		return oMap;
	}	
	
	@GraymoundService("BNSPR_NBSM_COLLECT_TYPE_DATA")
	public static GMMap collectCallTypeData(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		//Diger
		int turNo = iMap.getInt("TUR_NO");
		String sorguSeviyesi = iMap.getString("SORGU_SEVIYESI");
		BigDecimal referansNo = null;

		try {
			// map adi al
			String tableName = null;
			switch (turNo) {
				case 1: tableName = "EXTRNL"; break;
				case 2: tableName = "FRAUD"; break;
				case 3: tableName = "APPL"; break;
				case 4: tableName = "MVT"; break;
				case 5: tableName = "KKB"; break;
				case 6: tableName = "TCMB"; break;
			}
			// referans no bul
			if (turNo == 3 || turNo == 4) {
				if ("R".equals(sorguSeviyesi)) {
					referansNo = iMap.getBigDecimal("BASVURU_NO");
				} else {
					referansNo = iMap.getBigDecimal("TRX_NO");
				}
			} else {
				referansNo = iMap.getBigDecimal("BASVURU_NO");
			}
			
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_NBSM.Get_Ref_Cursor (?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TUR_NO"));
			stmt.setString(3, sorguSeviyesi);
			stmt.setBigDecimal(4, referansNo);
			stmt.setBigDecimal(5, iMap.getBigDecimal("SIRA_NO"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap.put(tableName, DALUtil.rSetMap(rSet));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	//**************************************************** YENI SISTEM
	/** NBSM sorgusu icin sorgu seviyesi bazli datalari toplar<br>
	 * @author murat.el
	 * @since PY-10619
	 * @param iMap - Sorgu kriterleri<br>
	 * 		   SISTEM - KK:Kredi Karti | BK:Bireysel Kredi | KMH : Kmh
	 *         TUR_NO - bilgileri toplanacak Data Tur No. Bos gelirse 6 tur icin datalari toplar.<br>
	 *            <li>1-External Databases (Basvuru No ile calisir)
	 *            <li>2-Vertification-Fraud (Basvuru No ile calisir)
	 *            <li>3-Application (R call basvuru no, digerleri islem no ile calisir)
	 *            <li>4-MVT (R call basvuru no, digerleri islem no ile calisir)
	 *            <li>5-KKB (Basvuru No ile calisir)
	 *            <li>6-TCMB (Basvuru No ile calisir)
	 *            <br>
	 *         SORGU_SEVIYESI - Sorgu Seviyesi. Bos gelirse hata verilir.<br>
	 *         	  <li>H-KKB
	 *         	  <li>I-Initial
	 *         	  <li>K-KKB
	 *            <li>F-Final
	 *            <li>G-1.Kefil
	 *            <li>L-2.Kefil
	 *            <li>R-Result
	 *            <li>T-Toplu
	 *            <br>
	 *         BASVURU_NO - Basvuru numarasi<br>
	 *         TRX_NO - Islem Numarasi<br>
	 *         KKB_DATA_ALINSIN_MI - KKB datasi alinsin mi? (E:Evet|H:Hayir|Default:E)
	 * @return oMap - NBSM sorgusu icin bulunan datalar<br> 
	 */
	@GraymoundService("BNSPR_NBSM_COLLECT_DATA_YENI_SISTEM")
	public static GMMap collectNbsmDataYeniSistem(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			//Parametre Kontrol
			//Sorgu Seviyesi
			String sorguSeviyesi = iMap.getString("SORGU_SEVIYESI");
			if (StringUtils.isBlank(sorguSeviyesi)) {
				ConsumerLoanCommonServices.raiseGMError("330", "Sorgu Seviyesi");
			} else {
				//TODO parametre gecerli mi
			}
			//Referans No
			if (StringUtils.isBlank(iMap.getString("BASVURU_NO")) && StringUtils.isBlank(iMap.getString("TRX_NO"))) {
				ConsumerLoanCommonServices.raiseGMError("330", "Referans No");
			}
			//Tur No
			Integer turNo = iMap.getInt("TUR_NO");
			if (turNo != null && (1 > turNo || turNo > 8)) {
				ConsumerLoanCommonServices.raiseGMError("3", "Tur No", turNo);
			}
			//Sistem
			String sistem = iMap.getString("SISTEM");
			if (StringUtils.isBlank(sistem)) {
				ConsumerLoanCommonServices.raiseGMError("330", "Sistem");
			} else {
				//TODO parametre gecerli mi
			}
			
			//Islemi baslat
			//TUR_NO degeri dolu ise sadece o tur icin datalari topla, yoksa 6 tip icin de sorgu yap
			GMMap sorguMap = null;
			if (turNo == null) {
				//Calisacak is listesi
				List<GMMap> parallelJobList = new ArrayList<GMMap>();
				//Calisacak isleri olustur
				for (int i = 1; i <= 6; i++) {
					//KKB datasi alinmasin
					if (i == 5 && "H".equals(ConsumerLoanCommonServices.nvl(iMap.getString("KKB_DATA_ALINSIN_MI"), Constants.EVET))) {
						continue;
					}
					//Isi olustur
					sorguMap = new GMMap();
					sorguMap.put("T_SERVICE_NAME", "BNSPR_NBSM_COLLECT_TYPE_DATA");//calisacak servis
					sorguMap.put("SISTEM", sistem);
					sorguMap.put("TUR_NO", i);//tur numarasi
					sorguMap.put("SORGU_SEVIYESI", sorguSeviyesi);
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
					parallelJobList.add(sorguMap);
				}
				//Calisacak isleri paralel olarak isle.
				GMMap jobMap = new GMMap();
				jobMap.put("T_TASKS", parallelJobList);
				oMap.putAll(GMServiceExecuter.callParallel(jobMap));
				//TODO Hata alirsa napcaz
			} else {
				//Sadece bir tur icin datalari al
				sorguMap = new GMMap();
				sorguMap.put("SISTEM", sistem);
				sorguMap.put("TUR_NO", turNo);//tur numarasi
				sorguMap.put("SORGU_SEVIYESI", sorguSeviyesi);
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_NBSM_COLLECT_TYPE_DATA", sorguMap));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	//Tur no ya gore datalari toplar
	@GraymoundService("BNSPR_NBSM_COLLECT_TYPE_DATA_YENI_SISTEM")
	public static GMMap collectCallTypeDataYeniSistem(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap procMap = new GMMap();
		
		try {
			//Proc listesini al
			procMap.clear();
			procMap.put("SISTEM", iMap.get("SISTEM"));
			procMap.put("TUR_NO", iMap.get("TUR_NO"));
			procMap.put("SORGU_SEVIYESI", iMap.get("SORGU_SEVIYESI"));
			procMap.put("NBSM_PARAMETRE_ADI", iMap.get("NBSM_PARAMETRE_ADI"));
			procMap.putAll(getNbsmProcStrList(procMap));
			//Kontrol
			if (procMap.getSize("RESULT") > 0) {
				GMMap sorguMap = new GMMap();
				for (int i = 0; i < procMap.getSize("RESULT"); i++) {
					sorguMap.clear();
					sorguMap.put("PROC_STR", procMap.getString("RESULT", i, "PROC_STR"));
					sorguMap.put("SORGU_SEVIYESI", iMap.get("SORGU_SEVIYESI"));
					sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
					sorguMap.put("NBSM_PARAMETRE_ADI", iMap.get("NBSM_PARAMETRE_ADI"));
					sorguMap.put("TUR_NO", iMap.get("TUR_NO"));
					oMap.putAll(callProcedure(sorguMap));
				}
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	private static GMMap getNbsmProcStrList(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_nbsm_x.get_nbsm_proc_str(?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("SISTEM"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUR_NO"));
			stmt.setString(4, iMap.getString("SORGU_SEVIYESI"));
			stmt.setString(5, iMap.getString("NBSM_PARAMETRE_ADI"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "RESULT"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	private static GMMap callProcedure(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			//Proc stringini olustur
			StringBuilder query = new StringBuilder();
			query.append("{call ");
			query.append(iMap.getString("PROC_STR"));
			query.append("}");
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();
			// Call the procedure (or whatever else) that returns the table of a custom type
			stmt = conn.prepareCall(query.toString());
			int index = 1;
			stmt.setBigDecimal(index++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(index++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(index++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setString(index++, iMap.getString("NBSM_PARAMETRE_ADI"));
			//MVT blogunda musteri no ve kefil musteri no cok kullanildigindan 
			//defalarca git gel olmasin icin burada bir ayircalik yapildi. 
			if (4 == iMap.getInt("TUR_NO")) {
				//Musteri
				GMMap sorguMap = new GMMap();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("SORGU_SEVIYESI", iMap.get("SORGU_SEVIYESI"));
				sorguMap.put("HANGISI", 1);//Musteri
				sorguMap.putAll(getMvtCustomerNo(sorguMap));
				stmt.setBigDecimal(index++, sorguMap.getBigDecimal("MUSTERI_NO"));
				//Kefil
				sorguMap.remove("MUSTERI_NO");
				sorguMap.put("HANGISI", 2);//Kefil
				sorguMap.putAll(getMvtCustomerNo(sorguMap));
				stmt.setBigDecimal(index++, sorguMap.getBigDecimal("CUSTOMER_NO"));//Kefil
			}
			
			stmt.registerOutParameter(index, Types.ARRAY, "NBSM_PARAMETER_TABLE");
			stmt.execute();

			ARRAY arr = (ARRAY)stmt.getArray(index);
			Object[] values = (Object[]) arr.getOracleArray();
			for (int i=0; i < values.length; i++) {
				if (values[i] == null) {
					continue;
				}
				
				Struct nbsmParameter = (Struct) values[i];
				oMap.put(nbsmParameter.getAttributes()[0], nbsmParameter.getAttributes()[1]);//Name - Value
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
	private static GMMap getMvtCustomerNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal customerNo = null;

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call PKG_NBSM_4MVT_X.musteri_no(?,?,?,?)}";
			stmt = conn.prepareCall(query);
			int index = 1;
			stmt.registerOutParameter(index++, Types.NUMERIC);
			stmt.setBigDecimal(index++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(index++, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(index++, iMap.getString("SORGU_SEVIYESI"));
			stmt.setBigDecimal(index, iMap.getBigDecimal("HANGISI"));//1:Musteri | 2:Kefil
			stmt.execute();

			customerNo = stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("MUSTERI_NO", customerNo);
		return oMap;
	}
	
	@GraymoundService("BNSPR_NBSM_ESKI_YENI_KARSILASTIR_TOPLU")
	public static GMMap eskiYeniKarsilastirToplu(GMMap iMap) {
		System.out.println("Basladi....");
		GMMap oMap = new GMMap();
		String[] sorguSeviyeKodArray = {"H","I","K","F","G","R"};

		try {
			GMMap basvuruMap = getTestData();
			for (int i = 0; i < basvuruMap.getSize("TABLE"); i++) {
				iMap.put("BASVURU_NO", basvuruMap.get("TABLE", i, "BASVURU_NO"));
				iMap.put("TRX_NO", basvuruMap.get("TABLE", i, "TX_NO"));
				for (int j = 0; j < sorguSeviyeKodArray.length; j++) {
					System.out.println(sorguSeviyeKodArray[j] + " sorgusu " + iMap.getString("BASVURU_NO") + "-" + iMap.getString("TRX_NO") + " basvurusu isleniyor..." + (i+1));
					iMap.put("SORGU_SEVIYESI", sorguSeviyeKodArray[j]);
					eskiYeniKarsilastir(iMap);
				}
			}
			/*
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> basvuruList = session.createCriteria(BirBasvuru.class)
					.add(Restrictions.ne("krediTur", new BigDecimal(5)))
					.addOrder(Order.desc("basvuruNo"))
					.setMaxResults(20)
					.list();
			BirBasvuru birBasvuru = null;
			for (Object o : basvuruList) {
				birBasvuru = (BirBasvuru) o;
				iMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
				System.out.println(birBasvuru.getBasvuruNo() + " basvurusu isleniyor...");
				
				for (int i = 0; i < sorguSeviyeKodArray.length; i++) {
					System.out.println(sorguSeviyeKodArray[i] + " sorgusu isleniyor...");
					iMap.put("SORGU_SEVIYESI", sorguSeviyeKodArray[i]);
					eskiYeniKarsilastir(iMap);
				}
			}	
			*/	
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		System.out.println("Bitti....");
		return oMap;
	}
	
	@GraymoundService("BNSPR_NBSM_ESKI_YENI_KARSILASTIR")
	public static GMMap eskiYeniKarsilastir(GMMap iMap) {
		GMMap oMap = new GMMap();
		String sorguSeviyesi = iMap.getString("SORGU_SEVIYESI");
		BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
		int turNo = 4;

		try {
			System.out.println("1....");
			
			//Eskiyi al
			GMMap eskiMap = new GMMap();
			eskiMap.put("SORGU_SEVIYESI", sorguSeviyesi);
			eskiMap.put("BASVURU_NO", basvuruNo);
			eskiMap.put("TRX_NO", trxNo);
			eskiMap.putAll(ConsumerLoanInternalQueries.getCustomerData(eskiMap));
			
			System.out.println("2....");
			
			//Yeniyi al
			GMMap yeniMap = new GMMap();
			yeniMap.put("SISTEM", "BK");
			yeniMap.put("TUR_NO", turNo);
			yeniMap.put("SORGU_SEVIYESI", sorguSeviyesi);
			yeniMap.put("BASVURU_NO", basvuruNo);
			yeniMap.put("TRX_NO", trxNo);
			yeniMap.put("KKB_DATA_ALINSIN_MI", "H");
			yeniMap.putAll(collectNbsmData(yeniMap));
			
			System.out.println("3....");
			
			
			//Karsilastir
			for (Object o : eskiMap.keySet()) {
				String key = (String) o;
				//System.out.println("Key : " + key + " Eski: " + eskiMap.getString(key) + " Yeni: " + yeniMap.getString(key));
				if (yeniMap.containsKey(key)) {
					if (eskiMap.getString(key) == null) {
						if (yeniMap.getString(key) != null) {
							System.out.println(key + " eslesmedi. Eski: " + eskiMap.getString(key) + " Yeni: " + yeniMap.getString(key));
						}
					} else {
						if (yeniMap.getString(key) == null) {
							System.out.println(key + " eslesmedi. Eski: " + eskiMap.getString(key) + " Yeni: " + yeniMap.getString(key));
						} else {
							if (!eskiMap.getString(key).equals(yeniMap.getString(key))) {
								System.out.println(key + " eslesmedi. Eski: " + eskiMap.getString(key) + " Yeni: " + yeniMap.getString(key));
							}
						}
					}
				} else {
					System.out.println("Key yok : " + key);
				}
			}
			
			
			turNo = 3;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	private static GMMap getTestData() {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_nbsm_x.get_test_data}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "TABLE");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
	
}
