package tr.com.calikbank.bnspr.consumerloan.xml;

import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import oracle.jdbc.OracleTypes;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.calikbank.bnspr.consumerloan.document.type.DocumentCreator;
import tr.com.calikbank.bnspr.consumerloan.document.type.WebCreditDocument;
import tr.com.calikbank.bnspr.consumerloan.utils.Enums.CreditDocMailTypes;
import tr.com.calikbank.bnspr.consumerloan.utils.Enums.CreditDocTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.calikbank.integration.ftp.AktifSFTPClient;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CreditDocumentPdfServices {
	
private static Configurator webCreditParams=Configurator.createConfiguratorFromProperties("aktifbank-webcredit-document.properties");
	
	@GraymoundService("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS_BYTE")
	public static GMMap createWebCreditDocumentsByte(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String applicationNo = iMap.getString("APPLICATION_NO");
			for(int index=0;index<iMap.getSize("DOC_LIST");index++) {
				int documentCode=iMap.getInt("DOC_LIST", index, "CODE");
				WebCreditDocument creditDocument=DocumentCreator.createWebCreditDocument(documentCode);
				creditDocument.setDocName(getDocumentName(documentCode));
				creditDocument.generatePdf(applicationNo, null);
				oMap.put("DOC_LIST", index, "CODE", documentCode);
				oMap.put("DOC_LIST", index, "BYTE_ARRAY", creditDocument.getPdfByteArray());
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS")
	public static GMMap createWebCreditDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		String query = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String applicationNo = iMap.getString("APPLICATION_NO");
			boolean mailTransfer = iMap.getBoolean("MAIL_TRANSFER");
			boolean dysTransfer = iMap.getBoolean("DYS_TRANSFER");
			HashMap<String, Object> parameters = (HashMap<String, Object>) iMap.get("PARAMETERS");
			
			iMap.put("BASVURU_NO", applicationNo);
			iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3171_GET_MUSTERINO", iMap).get("MUSTERI_NO"));
	
			if(iMap.getSize("DOC_LIST")>0 && (dysTransfer || mailTransfer)) {
				
				ArrayList<WebCreditDocument> creditDocuments=new ArrayList<WebCreditDocument>();
				for(int index=0;index<iMap.getSize("DOC_LIST");index++) {
					int documentCode=iMap.getInt("DOC_LIST",index,"CODE");
					WebCreditDocument creditDocument=DocumentCreator.createWebCreditDocument(documentCode);
					creditDocument.setDocName(getDocumentName(documentCode));
					creditDocument.generatePdf(applicationNo, parameters);
					creditDocuments.add(creditDocument);
					if("E".equals(iMap.getString("DOC_LIST", index, "ALINDI"))){
						query = "update bnspr.GNL_MUSTERI_DOKUMAN set ALINDI_KUTUSU_F ='E' where MUSTERI_NO=" + iMap.getString("MUSTERI_NO") + " and DOKUMAN_ADI='" +documentCode+ "'";
						session.createSQLQuery(query).executeUpdate();
					}
				}
				
				if(dysTransfer) {
					putDocumentToFTP(applicationNo, creditDocuments);
				}
				
				if(mailTransfer) {
					sendEMailPdfDocument(iMap, creditDocuments);
				}
				
				oMap.put("RESPONSE", 2);
			} else {
				oMap.put("RESPONSE", 0);
				oMap.put("RESPONSE_DATA", "Gecersiz Request");
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	private static void putDocumentToFTP(String applicationNo, ArrayList<WebCreditDocument> creditDocuments){
		Connection conn = null;
        CallableStatement stmt = null;
	    ResultSet rSet = null;
	    AktifSFTPClient aktifSFTPClient = null;
	    
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2070.read_gnl_sifre(?)}");
			stmt.registerOutParameter(1, OracleTypes.CURSOR);
			stmt.setString(2, webCreditParams.getProperty("ftp.gnl.sifre.code"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			rSet.next();

			String serverUri = rSet.getString("ip");
			String username = rSet.getString("user_name");
			String password = rSet.getString("passwd");
			String path = rSet.getString("path");
			BigDecimal port = rSet.getBigDecimal("port");
			//String ftpType = rSet.getString("FTP_TURU");
			
			//FtpClient ftpClient=new FtpClient(serverUri, port, ftpType, username, password);
			aktifSFTPClient = new AktifSFTPClient(serverUri, username, password, port.intValue());
			
			if(!aktifSFTPClient.isFileExist(path, applicationNo)) {
				aktifSFTPClient.createDirectory(path, applicationNo);
			}
			StringBuilder sb=new StringBuilder(path);
			sb.append(File.separator).append(applicationNo);
			for(WebCreditDocument creditDocument:creditDocuments){
				aktifSFTPClient.put(sb.toString(), creditDocument.getDysPdfFileName(), creditDocument.getPdfByteArray());
			}
			
		}catch (Exception exp) {
			throw ExceptionHandler.convertException(exp);
			
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			if(aktifSFTPClient != null) {
				aktifSFTPClient.closeConnection();
			}
		}
	}
	
	private static void sendEMailPdfDocument(GMMap iMap, ArrayList<WebCreditDocument> creditDocuments){
		GMMap inputMap=new GMMap();
		if("KDH".equals(iMap.getString("EMAIL_TYPE"))){
			inputMap.put("FROM", "aktifbank@aktifbank.com.tr");
		}else{
			inputMap.put("FROM", webCreditParams.getProperty("mail.from"));
		}
		inputMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(iMap.getString("EMAIL_TO")));
		if(iMap.getString("EMAIL_SUBJECT") == null){
			iMap.put("KOD", "WEB_KREDI_EMAIL_BASLIK");
			iMap.put("KEY", iMap.getString("EMAIL_TYPE"));
			iMap.put("EMAIL_SUBJECT", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap).getString("TEXT"));
		}
		
		inputMap.put("SUBJECT", iMap.getString("EMAIL_SUBJECT")==null?webCreditParams.getProperty("mail.subject"):iMap.getString("EMAIL_SUBJECT"));		
		
		inputMap.put("IS_BODY_HTML", true);
		inputMap.put("MESSAGE_BODY", generateMailHtml(iMap));
		inputMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
		
		if (iMap.getBoolean("SEND_ATTACHMENTS")) {
			int index = 0;
			for (WebCreditDocument creditDocument : creditDocuments) {
				if (creditDocument.getCode() != CreditDocTypes.KDH_PRE_INFO_FORM.getCode()) {
					inputMap.put("ATTACMENT_FILE_LIST", index, "FILE_NAME", creditDocument.getMailPdfFileName());
					inputMap.put("ATTACMENT_FILE_LIST", index, "FILE_BYTE_ARRAY", creditDocument.getPdfByteArray());
					index++;
				}
			}
		}
		GMServiceExecuter.executeAsync("BNSPR_SYSTEM_MAIL_SEND_EMAIL", inputMap);
	}
	
	private static String generateMailHtml(GMMap iMap){
		GMMap inputMap=new GMMap();
		inputMap.put("FOLDER_NAME","webCredit");
		inputMap.put("TEMPLATE_NAME",CreditDocMailTypes.valueOf(iMap.getString("EMAIL_TYPE")).getVmName());
		inputMap.put("ENCODING", "ISO-8859-9");
		
		HashMap<String,Object> inputs=new HashMap<String, Object>();
		inputs.put("AD", iMap.getString("EMAIL_NAME"));
		inputs.put("SOYAD", iMap.getString("EMAIL_SURNAME"));
		inputs.put("BASVURU_NO", iMap.getString("APPLICATION_NO"));
		inputs.put("KDH_LIMIT", iMap.getString("KDH_LIMIT"));
		inputs.put("HESAP_NO", iMap.getString("HESAP_NO"));
		inputs.put("ODEMESIZ_SURE", iMap.getString("ODEMESIZ_SURE"));
		inputs.put("SPOT_VADE", iMap.getString("SPOT_VADE"));
		
		
		//Kart No son 4 hanesi g�sterilmelidir.
		if (!StringUtils.isEmpty(iMap.getString("EMAIL_CARD_NO")) && iMap.getString("EMAIL_CARD_NO").length()==16) {
			inputs.put("KART_NO", iMap.getString("EMAIL_CARD_NO").substring(12));
		}else{
			inputs.put("KART_NO", iMap.getString("EMAIL_CARD_NO"));
		}
		
		inputMap.put("INPUTS", inputs);
		
		return GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_HTML", inputMap).getString("HTML_DATA");
	}
	
	private static String getDocumentName(int documentCode) {
		Connection 			conn = null;
		PreparedStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareStatement("SELECT ACIKLAMA FROM v_ml_gnl_dokuman_kod_pr WHERE KOD = ?");
			stmt.setString(1, String.valueOf(documentCode));
			rSet = stmt.executeQuery();
			
			if(rSet.next()) {
				return rSet.getString(1);
			}
			throw new GMRuntimeException(0, "Gecersiz Dokuman Kodu!");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
