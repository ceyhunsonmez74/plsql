package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3138Services {

	@GraymoundService("BNSPR_QRY3138_GET_KULLANDIRIM_EFT_BILGILERI")
	public static GMMap getKullandirimEftBilgileri(GMMap iMap) {  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();		
			
			stmt = conn.prepareCall("{? = call PKG_RC3138.RC_QRY3138_GET_KUL_EFT_BILGI(?,?,?,?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			if( iMap.getDate("BASLANGIC_TARIHI") != null) 
				stmt.setDate(i++, new Date(iMap.getDate("BASLANGIC_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			if( iMap.getDate("BITIS_TARIHI") != null) 
				stmt.setDate(i++, new Date(iMap.getDate("BITIS_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			

				stmt.setString(i++, iMap.getString("EFT_KULLANMA")); //EK
				stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERINO")); //EK
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TCKIMLIKNO")); //EK
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURUNO")); //EK
				if (iMap.getString("SONYIRMIGUN").compareTo("false") ==0 ){
				stmt.setBigDecimal(i++, new BigDecimal(1)); //EK
				}else{
				stmt.setBigDecimal(i++, new BigDecimal(0)); //EK
				}
				
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "RESULTS");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
