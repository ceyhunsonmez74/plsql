package tr.com.calikbank.bnspr.consumerloan.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruicraOdeme;
import tr.com.aktifbank.bnspr.dao.BirBasvuruicraOdemeTx;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3282Services {

	@GraymoundService("BNSPR_TRN3282_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBox(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "H");
			iMap.put("KOD", "KREDI_HESAP_DURUM");
			oMap.put(
					"KREDI_HESAP_DURUM",
					GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
							iMap).get("RESULTS"));
		   
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3282_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal"); 
			
			BirBasvuruicraOdemeTx tx = (BirBasvuruicraOdemeTx) session.get(BirBasvuruicraOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (tx == null) {
				tx = new BirBasvuruicraOdemeTx();
				tx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}			
			
			tx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			tx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			tx.setAciklama(iMap.getString("ACIKLAMA"));
			tx.setBasvuruDurum(iMap.getString("BASVURU_DURUM"));
			tx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAF"));
			tx.setKanalKodu(iMap.getString("KANAL_KODU"));
			tx.setKrediHesapBakiye(iMap.getBigDecimal("KREDI_HESAP_BAKIYE"));
			tx.setKrediHesapDurum(iMap.getString("KREDI_HESAP_DURUM"));
			tx.setKrediHesapNo(iMap.getBigDecimal("KREDI_HESAP_NO"));
			tx.setKrediTutari(iMap.getBigDecimal("KREDI_TUTAR"));
			tx.setIcraTutar(iMap.getBigDecimal("ICRA_TUTAR"));
			tx.setMusteridenAlinacakTutar(iMap.getBigDecimal("MUSTERIDEN_ALINACAK_TUTAR"));
			tx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			tx.setVadesizHesapBakiye(iMap.getBigDecimal("VADESIZ_HESAP_BAKIYE"));
			tx.setVadesizHesapNo(iMap.getBigDecimal("VADESIZ_HESAP_NO"));
			tx.setRecOwner(ADCSession.getString("USER_NAME"));
			tx.setRecDate(new Date());
			
			session.save(tx);
		    session.flush();  
		    
		    iMap.put("TRX_NAME", "3282");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3282_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) session
					.createCriteria(BirBasvuruicraOdemeTx.class)
					.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
					.list();

			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {

				BirBasvuruicraOdemeTx tx = (BirBasvuruicraOdemeTx) iterator
						.next();

				oMap.put("BASVURU_NO", tx.getBasvuruNo());
				oMap.put("MUSTERI_NO", tx.getMusteriNo());
				oMap.put("UNVAN", LovHelper.diLov(tx.getMusteriNo(),
						tx.getBasvuruNo(), "3282/LOV_MUSTERI_NO", "UNVAN"));
				oMap.put("KREDI_HESAP_NO", tx.getKrediHesapNo());
				oMap.put("VADESIZ_HESAP_NO", tx.getVadesizHesapNo());
				oMap.put("ICRA_TUTAR", tx.getIcraTutar());
				oMap.put("MUSTERIDEN_ALINACAK_TUTAR", tx.getMusteridenAlinacakTutar());
				oMap.put("ACIKLAMA", tx.getAciklama());
				oMap.put("BASVURU_DURUM", tx.getBasvuruDurum());
				oMap.put("DOSYA_MASRAF", tx.getDosyaMasrafi());
				oMap.put("KANAL_KODU", tx.getKrediHesapBakiye());
				oMap.put("KREDI_HESAP_BAKIYE", tx.getKrediHesapBakiye());
				oMap.put("VADESIZ_HESAP_BAKIYE", tx.getVadesizHesapBakiye());
				oMap.put("KREDI_HESAP_DURUM", tx.getKrediHesapDurum());
				oMap.put("KREDI_TUTAR", tx.getKrediTutari());
				oMap.put("TC_KIMLIK_NO", tx.getTcKimlikNo());
			}
			return oMap;        	
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3282_GET_TARIHCE")
	public static GMMap getOncekiGiris(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			if (!"".equals(iMap.getString("BASVURU_NO"))) {
				List<?> list = session.createCriteria(BirBasvuruicraOdemeTx.class)
						.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
						.addOrder(Order.desc("txNo"))
						.list();
				if(list.size() > 0){
					SimpleDateFormat dt = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
					BirBasvuruicraOdemeTx t = null;
					for (int i = 0; i < list.size(); i++) {
						t = (BirBasvuruicraOdemeTx) list.get(i);
						oMap.put("SONUC_TABLE", i, "ISLEM_NO", t.getTxNo());
						oMap.put("SONUC_TABLE", i, "MUSTERI_NO", t.getMusteriNo());
						oMap.put("SONUC_TABLE", i, "ICRA_TUTARI", t.getIcraTutar());
						oMap.put("SONUC_TABLE", i, "MUSTERIDEN_KARSILANACAK_TUTAR", t.getMusteridenAlinacakTutar());;
						oMap.put("SONUC_TABLE", i, "ACIKLAMA", t.getAciklama());
						oMap.put("SONUC_TABLE", i, "ISLEM_TARIH", dt.format(t.getRecDate()));
					}
				}
			}
			return oMap;        	
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	/** Verilen basvuru numarasina ait tamamlanmis icra odeme islemi var mi kontrolunu yapar.<br>
	 * @author murat.el
	 * @since TY-3874
	 * @param iMap - Sorgu kriterleri<br>
	 *         <li>BASVURU_NO - Bireysel kredi basvuru numarasi
	 * @return oMap - Islem sonucu<br>
	 *         <li>ONCEKI_GIRIS_VAR_MI - Onceden tamamlanmis icra odeme islemi var mi? (E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_TRN3282_ONCEKI_GIRIS_VAR_MI")
	public static GMMap oncekiGirisVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		String girisVarMi = Constants.HAYIR;

		try {
			//Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			//Kayit var mi?
			List<?> list = session.createCriteria(BirBasvuruicraOdeme.class)
					.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal(Constants.BASVURU_NO)))
					.list();
			if (list != null && !list.isEmpty()) {
				girisVarMi = Constants.EVET;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("ONCEKI_GIRIS_VAR_MI", girisVarMi);
		return oMap;
	}
}
