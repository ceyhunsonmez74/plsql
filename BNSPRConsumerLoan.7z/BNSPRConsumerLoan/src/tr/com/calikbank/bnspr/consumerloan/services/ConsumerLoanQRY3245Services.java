package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.text.ParseException;

import jxl.Sheet;
import jxl.Workbook;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.gov.nvi.kpsv2.model.KisiAdresBilgileriModel;
import tr.gov.nvi.kpsv2.model.YurtDisiAdresiModel;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY3245Services {
	
	@GraymoundService("BNSPR_QRY3245_LOAD_EXCEL")	
		public static GMMap loadExcel(GMMap iMap) {
		
			GMMap oMap = new GMMap();
			
			try
			{		
				Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")));
				Sheet dataSheet1 = workbook.getSheet(0);
				
				int row = 0;
				String tableName = "APS_DATA";
				
				for(int i=0; i<dataSheet1.getRows(); i++){
					
					oMap.put(tableName, row, "TCKN", dataSheet1.getCell(0, i).getContents().trim());
					
					row++;
					
				}
				
				return oMap;
			}	  catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY3245_GET_APS")
	public static GMMap getAPS(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			
			GMMap sMap = new GMMap();
			String tableName = "APS_DATA";
			int row = 0;
			
			for(int k = 0; k < iMap.getSize(tableName); k++){
				
			  sMap.put("TCKN", iMap.getString(tableName, row, "TCKN"));
			  sMap = GMServiceExecuter.call("BNSPR_KPS_GET_KISI_ADRES_BILGISI", sMap);
			
			  if(sMap.getInt("HATA_KOD") == 0){
				KisiAdresBilgileriModel kisiAdresBilgisi = (KisiAdresBilgileriModel)sMap.get("KISI_ADRES_BILGISI");
				
				oMap.put(tableName, row, "TCKN", iMap.getString(tableName, row, "TCKN"));
				oMap.put(tableName, row, "ADRES_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getAdresNo());
				oMap.put(tableName, row, "BUCAK", kisiAdresBilgisi.getYerlesimYeriAdresi().getBucak());
				oMap.put(tableName, row, "BUCAK_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getBucakKodu());
				oMap.put(tableName, row, "CSBM", kisiAdresBilgisi.getYerlesimYeriAdresi().getCsbm());
				oMap.put(tableName, row, "CSBM_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getCsbmKodu());
				oMap.put(tableName, row, "DIS_KAPI_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getDisKapiNo());
				oMap.put(tableName, row, "IC_KAPI_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getIcKapiNo());
				oMap.put(tableName, row, "IL", kisiAdresBilgisi.getYerlesimYeriAdresi().getIl());
				oMap.put(tableName, row, "ILCE", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlce());
				oMap.put(tableName, row, "ILCE_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlceKodu());
				oMap.put(tableName, row, "IL_KODU", kisiAdresBilgisi.getYerlesimYeriAdresi().getIlKodu());
				oMap.put(tableName, row, "KOY", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoy());
				oMap.put(tableName, row, "KOY_KAYIT_NO", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoyKayitNo());
				oMap.put(tableName, row, "KOY_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getKoyKodu());
				oMap.put(tableName, row, "MAHALLE", kisiAdresBilgisi.getYerlesimYeriAdresi().getMahalle());
				oMap.put(tableName, row, "MAHALLE_KOD", kisiAdresBilgisi.getYerlesimYeriAdresi().getMahalleKodu());
				
				YurtDisiAdresiModel yurtDisiAdres = kisiAdresBilgisi.getYerlesimYeriAdresi().getYurtdisiAdresi();
				if(yurtDisiAdres != null){
					oMap.put(tableName, row, "YABANCI_ADRES", yurtDisiAdres.getYabanciAdres());
					oMap.put(tableName, row, "YABANCI_IL", yurtDisiAdres.getYabanciSehir());
					oMap.put(tableName, row, "YABANCI_ULKE_KOD", yurtDisiAdres.getYabanciUlke().getKod());
					oMap.put(tableName, row, "YABANCI_ULKE_ACIKLAMA", yurtDisiAdres.getYabanciUlke().getAciklama());
				}
				
				oMap.put(tableName, row, "DURUM", "APS Yap�ld�");

			  }
			else{
				
				oMap.put(tableName, row, "TCKN", iMap.getString(tableName, row, "TCKN"));
				oMap.put(tableName, row, "DURUM", "APS' de kay�tl� bir adres yoktur.");

			}
			  row++;
			  
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;

	}
	
	@GraymoundService("BNSPR_QRY3245_GET_TCK_NO_CONTROL")
	public static GMMap getTcknControl (GMMap iMap) {
		
		 Connection conn = null;
		 CallableStatement stmt = null;
		 
		 try {
			conn = DALUtil.getGMConnection();
			String tableName = "APS_DATA";
			int row= 0;
			
			for(int k = 0; k < iMap.getSize(tableName); k++){
				
			 stmt = conn.prepareCall("{? = call Pkg_Musteri.TCKN_KONTROL(?)}");
			 int i = 1;
					 
			 stmt.registerOutParameter(i++, java.sql.Types.INTEGER);
			 
		     if (iMap.getBigDecimal(tableName, row, "TCKN")  == null){
		    	 
		    	GMMap myMap = new GMMap();
			    myMap.put("MESSAGE_NO", new BigDecimal(330));
			    myMap.put("P1","TC Kimlik No");
			    throw new GMRuntimeException(0,(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		     
		     }else	
		    	 
			    stmt.setBigDecimal(i++, iMap.getBigDecimal(tableName, row, "TCKN"));
			
			    stmt.execute();
			    
			    if(stmt.getInt(1) == 0)
				throw new ParseException(null, 0);
			    
			 row++;
			 
			}
			return new GMMap();
			
		
		 } catch (ParseException e) {
				GMMap myMap = new GMMap();
				myMap.put("MESSAGE_NO", new BigDecimal(456));
				throw new GMRuntimeException(0,(String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		 } catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		 } finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		 }
	}
	
}
