package tr.com.calikbank.bnspr.consumerloan.utils;

import org.apache.commons.lang.StringUtils;

public class GeneralUtils {
	public static <T> T nvl(T value, T defaultValue) {
		if (value instanceof String) {
			return StringUtils.isBlank((String) value) ? defaultValue : value;
		}

		return value == null ? defaultValue : value;
	}
}
