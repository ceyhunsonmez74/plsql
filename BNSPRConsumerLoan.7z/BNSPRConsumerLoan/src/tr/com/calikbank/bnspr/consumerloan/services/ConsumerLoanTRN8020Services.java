package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.biff.EmptyCell;

import org.apache.axis.encoding.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.DcsGecikmeGonderiKarar;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeSmsData;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeSmsDataTx;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeSmsDataTxId;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeSmsLog;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.VysKrediDevirTx;
import tr.com.aktifbank.bnspr.dao.VysKrediDevirTxId;
import tr.com.calikbank.bnspr.consumerloan.document.type.WebCreditDocument;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.integration.ftp.AktifSFTPClient;
import tr.com.calikbank.integration.ftp.FtpClient;
import tr.com.calikbank.integration.ftp.FtpClientException;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN8020Services {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanTRN8020Services.class);
	private static int BK = 1;
	private static int KK = 2;
	private static int KMH = 3;
	
	private static final Integer SMS_DURUM_KAYDEDILDI = 0;

	@GraymoundService("BNSPR_TRN8020_UPLOAD_EXCEL")
	public static GMMap uploadSmsExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		BigDecimal musteriNo;
		try {
			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("ISO-8859-9");

			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet dataSheet = workbook.getSheet(0);

			conn = DALUtil.getGMConnection();

			String tableName = "SMS_TABLO";
			int row = 0;
			
			String urunTipi = iMap.getString("URUN_TIPI");
			
			if(StringUtils.isEmpty(urunTipi))
				throw new GMRuntimeException(0, "L�tfen �r�n tipi se�iniz!!");
			
			if(urunTipi.equalsIgnoreCase(Integer.toString(BK))){
				stmt = conn.prepareCall("{call bnspr.PKG_TRN8020.sms_data_bk(?,?,?,?,?,?,?,?,?,?,?,?)}");
				for (int i = 0; i < dataSheet.getRows(); i++) {

					if (dataSheet.getCell(0, i) instanceof EmptyCell) {
						continue;
					}
					else {
						String basvuru = dataSheet.getCell(0, i).getContents();
						String cepTel = StringUtils.EMPTY;

						if (basvuru != null && !basvuru.trim().isEmpty()) {
							BigDecimal basvuruNo = new BigDecimal(basvuru);						

							int index = 1;
							stmt.setBigDecimal(index++, basvuruNo);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.execute();

							oMap.put(tableName, row, "BASVURU_NO", basvuruNo);
							index = 2;
							musteriNo = stmt.getBigDecimal(index++);
							if(musteriNo == null){
								throw new GMRuntimeException(0, "Dosyada hatal� kay�t bulunuyor.Ba�vuru No : " + basvuruNo.toString());
							}
							oMap.put(tableName, row, "MUSTERI_NO", musteriNo);
							oMap.put(tableName, row, "AD_SOYAD", stmt.getString(index++));
							oMap.put(tableName, row, "KANAL_ADI", stmt.getString(index++));
							oMap.put(tableName, row, "GGS", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "KALAN_ANAPARA", stmt.getBigDecimal(index++));
							cepTel = stmt.getString(index++);	
							if(StringUtils.isNotEmpty(cepTel))
								oMap.put(tableName, row, "CEP_TEL", cepTel);
							else
								throw new GMRuntimeException(0, basvuruNo + " no'lu ba�vuruya ait m��terinin sistemde Cep Telefonu eksik !! : ");
							oMap.put(tableName, row, "TAKSIT_SIRA_NO", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "GECIKME_TUTARI", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "GECIKMELI_TAKSIT_SAYI", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "ASGARI_TUTAR", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "KISMI_ODEME", stmt.getString(index++));						
							row++;

							stmt.clearParameters();
						}
					}
				}
			}else if(urunTipi.equalsIgnoreCase(Integer.toString(KK))){
				stmt = conn.prepareCall("{call bnspr.PKG_TRN8020.sms_data_kk(?,?,?,?,?,?,?,?,?,?,?,?)}");
				for (int i = 0; i < dataSheet.getRows(); i++) {

					if (dataSheet.getCell(0, i) instanceof EmptyCell) {
						continue;
					}
					else {
						String kart = dataSheet.getCell(0, i).getContents();
						String cepTel = StringUtils.EMPTY;

						if (kart != null && !kart.trim().isEmpty()) {
							BigDecimal kartNo = new BigDecimal(kart);						

							int index = 1;
							stmt.setBigDecimal(index++, kartNo);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.execute();

							oMap.put(tableName, row, "BASVURU_NO", kartNo);
							index = 2;
							musteriNo = stmt.getBigDecimal(index++);
							if(musteriNo == null){
								throw new GMRuntimeException(0, "Dosyada hatal� kay�t bulunuyor.Kart No : " + kartNo.toString());
							}
							oMap.put(tableName, row, "MUSTERI_NO", musteriNo);
							oMap.put(tableName, row, "AD_SOYAD", stmt.getString(index++));
							oMap.put(tableName, row, "KANAL_ADI", stmt.getString(index++));
							oMap.put(tableName, row, "GGS", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "KALAN_ANAPARA", stmt.getBigDecimal(index++));
							cepTel = stmt.getString(index++);	
							if(StringUtils.isNotEmpty(cepTel))
								oMap.put(tableName, row, "CEP_TEL", cepTel);
							else
								throw new GMRuntimeException(0, kartNo + " no'lu kart m��terisinin sistemde Cep Telefonu eksik !! : ");
							oMap.put(tableName, row, "TAKSIT_SIRA_NO", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "GECIKME_TUTARI", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "GECIKMELI_TAKSIT_SAYI", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "ASGARI_TUTAR", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "KISMI_ODEME", stmt.getString(index++));						
							row++;

							stmt.clearParameters();
						}
					}
				}
			}else if(urunTipi.equalsIgnoreCase(Integer.toString(KMH))){
				stmt = conn.prepareCall("{call bnspr.PKG_TRN8020.sms_data_kmh(?,?,?,?,?,?,?,?,?,?,?,?)}");
				for (int i = 0; i < dataSheet.getRows(); i++) {

					if (dataSheet.getCell(0, i) instanceof EmptyCell) {
						continue;
					}
					else {
						String kmh = dataSheet.getCell(0, i).getContents();
						String cepTel = StringUtils.EMPTY;

						if (kmh != null && !kmh.trim().isEmpty()) {
							BigDecimal kmhHesapNo = new BigDecimal(kmh);						

							int index = 1;
							stmt.setBigDecimal(index++, kmhHesapNo);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.VARCHAR);
							stmt.execute();

							oMap.put(tableName, row, "BASVURU_NO", kmhHesapNo);
							index = 2;
							musteriNo = stmt.getBigDecimal(index++);
							if(musteriNo == null){
								throw new GMRuntimeException(0, "Dosyada hatal� kay�t bulunuyor.KMH Hesap No : " + kmhHesapNo.toString());
							}
							oMap.put(tableName, row, "MUSTERI_NO", musteriNo);
							oMap.put(tableName, row, "AD_SOYAD", stmt.getString(index++));
							oMap.put(tableName, row, "KANAL_ADI", stmt.getString(index++));
							oMap.put(tableName, row, "GGS", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "KALAN_ANAPARA", stmt.getBigDecimal(index++));
							cepTel = stmt.getString(index++);	
							if(StringUtils.isNotEmpty(cepTel))
								oMap.put(tableName, row, "CEP_TEL", cepTel);
							else
								throw new GMRuntimeException(0, kmhHesapNo + " no'lu hesab�n ait oldu�u m��terinin Cep Telefonu eksik !!");
							oMap.put(tableName, row, "TAKSIT_SIRA_NO", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "GECIKME_TUTARI", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "GECIKMELI_TAKSIT_SAYI", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "ASGARI_TUTAR", stmt.getBigDecimal(index++));
							oMap.put(tableName, row, "KISMI_ODEME", stmt.getString(index++));						
							row++;

							stmt.clearParameters();
						}
					}
				}
			}
			return oMap;
		}
		catch (Exception e) {			
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN8020_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Connection conn = null;			
			CallableStatement stmt = null;
			
			Session session = DAOSession.getSession("BNSPRDal");
			conn = DALUtil.getGMConnection();
			
			DcsGecikmeSmsDataTx dcsGecikmeSmsDataTx = null;
			
			String tableName = "SMS_TABLO";
			BigDecimal trxNo = null;
			
			String basvuruNo = StringUtils.EMPTY;
			String gecikmisTaksitSayi = StringUtils.EMPTY;
			String gecikmeGunSayisi = StringUtils.EMPTY;
			String kalanAnapara = StringUtils.EMPTY;
			String asgariOdeme = StringUtils.EMPTY;
			String toplamBorc = StringUtils.EMPTY;
			
			String smsIcerik = iMap.getString("SMS_ICERIK");
			if(StringUtils.isEmpty(smsIcerik)){
				throw new GMRuntimeException(0, "Sms i�erik bo� olamaz !!");
			}
			String urunTipi = iMap.getString("URUN_TIPI");
			
			trxNo = iMap.getBigDecimal("TRX_NO");
			
			for(int i=0;i< iMap.getSize(tableName);i++){

				stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('DCS_GECIKME_SMS_DATA')}");
				stmt.registerOutParameter(1, Types.NUMERIC);
				stmt.execute();
				
				DcsGecikmeSmsDataTxId dcsGecikmeSmsDataTxId = new DcsGecikmeSmsDataTxId();
				dcsGecikmeSmsDataTxId.setId(stmt.getBigDecimal(1));
				dcsGecikmeSmsDataTxId.setTxNo(trxNo);
				
				dcsGecikmeSmsDataTx = new DcsGecikmeSmsDataTx();
				dcsGecikmeSmsDataTx.setId(dcsGecikmeSmsDataTxId);
				dcsGecikmeSmsDataTx.setAsgariOdemeTutari(iMap.getBigDecimal(tableName, i, "ASGARI_TUTAR") != null ? iMap.getBigDecimal(tableName, i, "ASGARI_TUTAR") : BigDecimal.ZERO);
				dcsGecikmeSmsDataTx.setGunSayisi(iMap.getBigDecimal(tableName, i, "GGS")); 
				dcsGecikmeSmsDataTx.setKanalKod(iMap.getString(tableName, i, "KANAL_ADI"));  
				dcsGecikmeSmsDataTx.setKismiOdeme(iMap.getString(tableName, i, "KISMI_ODEME"));
				dcsGecikmeSmsDataTx.setKmhTurKod(null);
				dcsGecikmeSmsDataTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
				dcsGecikmeSmsDataTx.setReferansNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
				dcsGecikmeSmsDataTx.setTaksitSayisi(iMap.getBigDecimal(tableName, i, "GECIKMELI_TAKSIT_SAYI"));
				dcsGecikmeSmsDataTx.setTaksitSiraNo(iMap.getBigDecimal(tableName, i, "TAKSIT_SIRA_NO"));
				dcsGecikmeSmsDataTx.setToplamBorc(iMap.getBigDecimal(tableName, i, "GECIKME_TUTARI") != null ? iMap.getBigDecimal(tableName, i, "GECIKME_TUTARI") : BigDecimal.ZERO);
				
				basvuruNo = dcsGecikmeSmsDataTx.getReferansNo().toString();
				if(urunTipi.equalsIgnoreCase("1")){
					dcsGecikmeSmsDataTx.setUrunTip("BK");
				}
				else if(urunTipi.equalsIgnoreCase("2")){
					dcsGecikmeSmsDataTx.setUrunTip("KK");
					basvuruNo = "************" + basvuruNo.substring(12);
				}
				else if(urunTipi.equalsIgnoreCase("3")){
					dcsGecikmeSmsDataTx.setUrunTip("KMH"); 
				}
				
				/* Alan Kontrol */
				if(dcsGecikmeSmsDataTx.getTaksitSayisi() != null){
					gecikmisTaksitSayi = dcsGecikmeSmsDataTx.getTaksitSayisi().toString();
				}
				if(dcsGecikmeSmsDataTx.getGunSayisi() != null){
					gecikmeGunSayisi = dcsGecikmeSmsDataTx.getGunSayisi().toString();
				}
				if(iMap.getBigDecimal(tableName, i, "KALAN_ANAPARA") != null){
					kalanAnapara = iMap.getBigDecimal(tableName, i, "KALAN_ANAPARA").toString();
				}
				if(dcsGecikmeSmsDataTx.getAsgariOdemeTutari() != null){
					asgariOdeme = dcsGecikmeSmsDataTx.getAsgariOdemeTutari().toString();
				}
				if(dcsGecikmeSmsDataTx.getToplamBorc() != null){
					toplamBorc = dcsGecikmeSmsDataTx.getToplamBorc().toString();
				}
				
				smsIcerik = iMap.getString("SMS_ICERIK");
				smsIcerik = createSmsMessageWithParam(urunTipi,smsIcerik, iMap.getString(tableName, i, "AD_SOYAD"), dcsGecikmeSmsDataTx.getMusteriNo().toString() , basvuruNo, toplamBorc, gecikmeGunSayisi, asgariOdeme, kalanAnapara, gecikmisTaksitSayi);
				
				dcsGecikmeSmsDataTx.setCepNo(iMap.getString(tableName, i, "CEP_TEL"));
				dcsGecikmeSmsDataTx.setDurum(new BigDecimal(SMS_DURUM_KAYDEDILDI));
				dcsGecikmeSmsDataTx.setSms(smsIcerik);
				
				session.save(dcsGecikmeSmsDataTx);
				
			}
			session.flush();

			iMap.put("TRX_NAME", "8020");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8020_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		try {
			iMap.put("URUN_TIP_LIST", 0 , "VALUE", BK);
			iMap.put("URUN_TIP_LIST", 0 , "NAME", "BK");
			iMap.put("URUN_TIP_LIST", 1 , "VALUE", KK);
			iMap.put("URUN_TIP_LIST", 1 , "NAME", "KK");
			iMap.put("URUN_TIP_LIST", 2 , "VALUE", KMH);
			iMap.put("URUN_TIP_LIST", 2 , "NAME", "KMH");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	
	public static String createSmsMessageWithParam(String uruntipi,String smsIcerik,String p1,String p2,String p3,String p4,String p5,String p6,String p7,String p8) {

		String smsNoParam = StringUtils.EMPTY;

		try {
			smsNoParam = smsIcerik.replaceFirst("#1", StringUtils.isNotEmpty(p1) ? p1 : StringUtils.EMPTY).replaceFirst("#2", StringUtils.isNotEmpty(p2) ? p2 : StringUtils.EMPTY).replaceFirst("#3", StringUtils.isNotEmpty(p3) ? p3 : StringUtils.EMPTY).replaceFirst("#4", StringUtils.isNotEmpty(p4) ? p4 : StringUtils.EMPTY).replaceFirst("#5", StringUtils.isNotEmpty(p5) ? p5 : StringUtils.EMPTY).replaceFirst("#6", StringUtils.isNotEmpty(p6) ? p6 : StringUtils.EMPTY).replaceFirst("#7", StringUtils.isNotEmpty(p7) ? p7 : StringUtils.EMPTY).replaceFirst("#8", StringUtils.isNotEmpty(p8) ? p8 : StringUtils.EMPTY);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return smsNoParam;
	}
	
}
