package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Types;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.consumerloan.utils.CreditTypes;
import tr.com.calikbank.bnspr.consumerloan.utils.GeneralUtils;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirDogrulamaKilit;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.BirKullandirimTx;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanIwdServices implements Constants{
	
	private final static Logger LOGGER = Logger.getLogger(ConsumerLoanIwdServices.class);
	
	/**
	 * Project : IWD<br>
	 * DESC    : dokuman kontrol sureci icin iwd task i yaratir.
	 *
	 * @param iMap (GMMap)
	 *          PARAM_I
	 *
	 * @return oMap (GMMap)
	 *      RESPONSE
	 *      RESPONSE_DATA
	 *      PARAM_O
	 *
	 * @author huseyin.ceteci
	 * @since  PY-13301
	 *
	 */
	@GraymoundService("BNSPR_CL_IWD_CREATE_TASK")
	public static GMMap iwdCreateTask(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String productType = StringUtils.EMPTY;
		int mapIndex = 0;
		
		try {
			BirBasvuru basvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal(BASVURU_NO));
			BirBasvuruBelgeTxId belgeTxId = new BirBasvuruBelgeTxId(iMap.getBigDecimal("TRX_NO"), iMap.getString(DOKUMAN_KOD), iMap.getString(KIMDEN, "M"), iMap.getBigDecimal(BASVURU_NO));
			BirBasvuruBelgeTx belgeTx = (BirBasvuruBelgeTx)session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id", belgeTxId)).uniqueResult();
			BirKullandirim kullandirim = (BirKullandirim) session.get(BirKullandirim.class, iMap.getBigDecimal(BASVURU_NO));
			if(kullandirim == null){
				kullandirim = new BirKullandirim();
			}
			BirSatici satici = (BirSatici) session.get(BirSatici.class, basvuru.getSaticiKod());
			if(satici == null){
				satici = new BirSatici();
			}
			
			if("2".equals(basvuru.getKanalKodu())){
				if (!EVRAKSIZ.equals(basvuru.getDurumKodu())) {
					if (BELGE_KONTROL_YUKLENDI.equals(iMap.getString("BELGE_KONTROL")) || BELGE_KONTROL_EKSIK_BELGE_YUKLENDI.equals(iMap.getString("BELGE_KONTROL"))) {
						if (CreditTypes.TASIT.getCreditCode().compareTo(basvuru.getKrediTur()) == 0) {
							productType = "BireyselKrediBelgeKontrol1";
						}
						else if (CreditTypes.IHTIYAC.getCreditCode().compareTo(basvuru.getKrediTur()) == 0) {
							productType = "BireyselKrediBelgeKontrol2";
						}
					}
					else if (BELGE_KONTROL_UYGUN.equals(iMap.getString("BELGE_KONTROL"))) {
						String func = "{? = call PKG_TRN3182.veriGiriseBelgeGeldiMi (?,?)}";
						String veriGiriseBelgeGeldi = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal(BASVURU_NO), BnsprType.NUMBER, iMap.getBigDecimal(DOKUMAN_KOD)));
						String calismaSekliKod = basvuru.getCalismaSekliKod();
						if ("Evet".equals(veriGiriseBelgeGeldi) && CALISMA_SEKLI_ELEKTRONIK_EVRAKLI.equals(calismaSekliKod)) {
							productType = "BireyselKrediBelgeKontrol_OrjinalBelgeGeldimi";
						}
					}
				}
				else {
					if (HAYIR.equals(GeneralUtils.nvl(belgeTx.getOrjinalEvrakMi(), "H"))) {
						String func = "{? = call pkg_trn3182.veriGiriseBelgeGeldiMi(?,?)}";
						Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal(BASVURU_NO), BnsprType.NUMBER, iMap.getBigDecimal(DOKUMAN_KOD) };
						String veriGiriseBelgeGeldi = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
						if ("Evet".equals(veriGiriseBelgeGeldi)) {
							productType = "BireyselKrediBelgeKontrol3";
						}
					}
				}
			}
			
			if(!StringUtils.isEmpty(productType)){
				oMap.put(CUSTOMER_ID,  			basvuru.getMusteriNo());
				oMap.put(TCKN, 					basvuru.getTcKimlikNo());
				oMap.put(PRODUCT_TYPE,    		iMap.getString(PRODUCT_TYPE, productType));
				oMap.put(PRODUCT_TYPE_DESC,   	"Kredi Belge Kontrol");
				oMap.put("TASK_UNIQUE_ID", 		iMap.getBigDecimal(BASVURU_NO));
				oMap.put(MAP_ENTRY, mapIndex, 		KEY,    	"");
				oMap.put(MAP_ENTRY, mapIndex, 		VALUE,  	"");
				oMap.put(MAP_ENTRY, ++mapIndex, 	KEY,    	"TASK_SCREEN");
				oMap.put(MAP_ENTRY, mapIndex, 		VALUE,  	"BNSPR_TRN3182.guiml");
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"KREDI_TURU");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	basvuru.getKrediTur());
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"CALISMA_TIPI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	basvuru.getCalismaSekliKod());
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"BELGE_KODU");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	iMap.getString(BELGE_KONTROL));
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"KREDI_KULLANDIRIM_TARIHI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	kullandirim.getIslemTar());
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"KREDI_KULLANDIRIM_SAATI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	"");
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"BAYI_KREDI_TIP");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	satici.getBayiKrediTipi());
				
				String krdTurDesc = (String) DALUtil.callOneParameterFunction("{? = call  pkg_bireysel.KrdTur(?)}", Types.VARCHAR, basvuru.getKrediTur());
				String calismaSekliDesc = StringUtils.EMPTY;
				String belgeDurumDesc = StringUtils.EMPTY;
				if(!StringUtils.isEmpty(basvuru.getCalismaSekliKod())){
					String func = "{? = call Pkg_parametre.ParamTextAl (?,?)}";
					calismaSekliDesc =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "CALISMA_SEKLI_KOD", BnsprType.STRING, basvuru.getCalismaSekliKod()));
				}	
				
				if(!StringUtils.isEmpty(iMap.getString(BELGE_KONTROL))){
					String func = "{? = call Pkg_parametre.ParamTextAl (?,?)}";
					belgeDurumDesc = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "BELGE_KONTROL_KOD", BnsprType.STRING, iMap.getString(BELGE_KONTROL)));
				}
				
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"DESC_KREDI_TURU");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	krdTurDesc);
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"DESC_CALISMA_TIPI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	calismaSekliDesc);
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"DESC_BELGE_KODU");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	belgeDurumDesc);
				String func = "{? = call PKG_TRN3182.veriGiriseBelgeGeldiMi (?,?)}";
				String veriGiriseBelgeGeldi = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal(BASVURU_NO), BnsprType.NUMBER, iMap.getBigDecimal(DOKUMAN_KOD)));
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"VERI_GIRISE_GELDI_MI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	veriGiriseBelgeGeldi);
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"ONAY_TUTAR");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	basvuru.getOnayTutar());
				oMap = GMServiceExecuter.call("BNSPR_EXT_IWD_CREATE_TASK_MAIN", oMap);
			}
		}
		catch (Exception e) {
			if (Constants.EVET.equals(iMap.getString(HATA_VERILSIN_MI))) {
				throw ExceptionHandler.convertException(e);
			} else {
				LOGGER.error(e.getMessage() + " Basvuru No: " + iMap.getBigDecimal(BASVURU_NO));
				oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(Constants.RESPONSE_DATA, e.getMessage());
			}
		}
		
		return oMap;
	}
	
	/**
	 * Project : IWD<br>
	 * DESC    : iwd tasklari atanmadan once dokumanlara ait kontrol yapar.
	 *
	 * @param iMap (GMMap)
	 *        <li> BASVURU_NO
	 *
	 * @return oMap (GMMap)
	 *         <li> RESULT
	 *
	 * @author huseyin.ceteci
	 * @since  PY-13301
	 *
	 */
	@GraymoundService("BNSPR_CL_IWD_DOCUMENT_PRE_CONTROL")
	public static GMMap iwdDocumentPreControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		int documentCount = 0;
		BigDecimal basvuruNo = BigDecimal.ZERO;
		String isAvailable = STR_ZERO;
		String willBeAvailable = STR_ZERO;

		try {
			basvuruNo = iMap.getBigDecimal(BASVURU_NO);
			String[] basvuruDurum = {BELGE, EVRAKSIZ};
			BirBasvuru basvuru = (BirBasvuru)session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruNo)).add(Restrictions.in("durumKodu", basvuruDurum)).uniqueResult();
			
			String[] belgeKontrol = {BELGE_KONTROL_YUKLENDI, BELGE_KONTROL_EKSIK_BELGE_YUKLENDI};
			documentCount = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).add(Restrictions.in("belgeKontrol", belgeKontrol)).list().size();
			
			BirDogrulamaKilit dogrulamaKilit = (BirDogrulamaKilit) session.get(BirDogrulamaKilit.class, basvuruNo);
			
			if(basvuru != null && (BELGE.equals(basvuru.getDurumKodu()) || EVRAKSIZ.equals(basvuru.getDurumKodu()))){
				if(documentCount > 0){
					if(dogrulamaKilit == null){
						isAvailable = STR_ONE;
						willBeAvailable = STR_ZERO;
					}else {
						willBeAvailable = STR_ONE;
						isAvailable = STR_ZERO;
					}
				}else {
					willBeAvailable = STR_ZERO;
					if(EVRAKSIZ.equals(basvuru.getDurumKodu())){
						isAvailable = STR_ONE;
					}else {
						isAvailable = STR_ZERO;
					}
				}
			}else {
				isAvailable = STR_ZERO;
				willBeAvailable = STR_ZERO;
			}
			
			oMap.put("IS_AVAILABLE", isAvailable);
			oMap.put("WILL_BE_AVAILABLE", willBeAvailable);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * Project : IWD<br>
	 * DESC    : * DESC    : kredi kontrol onay sureci icin iwd task i yaratir.
	 *
	 * @param iMap (GMMap)
	 *        <li> BASVURU_NO
	 *
	 * @return oMap (GMMap)
	 *         <li> RESULT
	 *
	 * @author huseyin.ceteci
	 * @since  
	 *
	 */
	@GraymoundService("BNSPR_CL_IWD_CREATE_TASK_KREDI_KONTROL")
	public static GMMap iwdCreateTaskKrediKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		int mapIndex = 0;
		try {
			BirBasvuru basvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal(BASVURU_NO));
			BirKullandirimTx kullandirim = (BirKullandirimTx) session.get(BirKullandirimTx.class, iMap.getBigDecimal(TRX_NO));
			if(kullandirim == null){
				kullandirim = new BirKullandirimTx();
			}
			
			if("2".equals(basvuru.getKanalKodu())){
				oMap.put(CUSTOMER_ID,  			basvuru.getMusteriNo());
				oMap.put(TCKN, 					basvuru.getTcKimlikNo());
				oMap.put(PRODUCT_TYPE,    		"BireyselKrediKullandirimOnay");
				oMap.put(PRODUCT_TYPE_DESC,   	"Kullandırım Onay Akışı");
				oMap.put("TASK_UNIQUE_ID", 		iMap.getBigDecimal("TRX_NO"));
				oMap.put(MAP_ENTRY, mapIndex, 		KEY,    	"");
				oMap.put(MAP_ENTRY, mapIndex, 		VALUE,  	"");
				oMap.put(MAP_ENTRY, ++mapIndex, 	KEY,    	"TASK_SCREEN");
				oMap.put(MAP_ENTRY, mapIndex, 		VALUE,  	"BNSPR_MESAJ_KUTUSU_GELEN.guiml");
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"KREDI_TURU");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	basvuru.getKrediTur());
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"CALISMA_TIPI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	basvuru.getCalismaSekliKod());
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"BELGE_KODU");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	iMap.getString(BELGE_KONTROL));
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"KREDI_KULLANDIRIM_TARIHI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	kullandirim.getIslemTar());
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"KREDI_KULLANDIRIM_SAATI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	"");
				
				String krdTurDesc = (String) DALUtil.callOneParameterFunction("{? = call  pkg_bireysel.KrdTur(?)}", Types.VARCHAR, basvuru.getKrediTur());
				String calismaSekliDesc = StringUtils.EMPTY;
				String belgeDurumDesc = StringUtils.EMPTY;
				if(!StringUtils.isEmpty(basvuru.getCalismaSekliKod())){
					String func = "{? = call Pkg_parametre.ParamTextAl (?,?)}";
					calismaSekliDesc =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "CALISMA_SEKLI_KOD", BnsprType.STRING, basvuru.getCalismaSekliKod()));
				}
				
				if(!StringUtils.isEmpty(iMap.getString(BELGE_KONTROL))){
					String func = "{? = call Pkg_parametre.ParamTextAl (?,?)}";
					belgeDurumDesc = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "BELGE_KONTROL_KOD", BnsprType.STRING, iMap.getString(BELGE_KONTROL)));
				}
				
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"DESC_KREDI_TURU");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	krdTurDesc);
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"DESC_CALISMA_TIPI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	calismaSekliDesc);
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"DESC_BELGE_KODU");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	belgeDurumDesc);
				String func = "{? = call PKG_TRN3182.veriGiriseBelgeGeldiMi (?,?)}";
				String veriGiriseBelgeGeldi = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal(BASVURU_NO), BnsprType.NUMBER, iMap.getBigDecimal(DOKUMAN_KOD)));
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"VERI_GIRISE_GELDI_MI");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	veriGiriseBelgeGeldi);
				oMap.put(MAP_ENTRY, ++mapIndex,     KEY,      	"ONAY_TUTAR");
				oMap.put(MAP_ENTRY, mapIndex,      	VALUE,    	basvuru.getOnayTutar());
				oMap = GMServiceExecuter.call("BNSPR_EXT_IWD_CREATE_TASK_MAIN", oMap);
			}
		}
		catch (Exception e) {
			if (Constants.EVET.equals(iMap.getString(HATA_VERILSIN_MI))) {
				throw ExceptionHandler.convertException(e);
			} else {
				LOGGER.error(e.getMessage() + " Basvuru No: " + iMap.getBigDecimal(BASVURU_NO));
				oMap.put(Constants.RESPONSE, AkustikConstants.RESPONSE_FAIL);
				oMap.put(Constants.RESPONSE_DATA, e.getMessage());
			}
		}
		return oMap;
	}
}
