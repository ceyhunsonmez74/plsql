package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisDegerTx;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisFinansTx;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisOrtaklarTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3165Services {

	@GraymoundService("BNSPR_TRN3165_SAVE")
	public static Map<?, ?> saveTRN3165(GMMap iMap) {

		try {

			Session session = DAOSession.getSession("BNSPRDal");

			BirSaticiTahsisDegerTx birSaticiTahsisDegerTx = new BirSaticiTahsisDegerTx();

			birSaticiTahsisDegerTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birSaticiTahsisDegerTx.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
			birSaticiTahsisDegerTx.setKazandiranKanal(iMap.getString("KAZANDIRAN_KANAL"));
			birSaticiTahsisDegerTx.setTakyidatEh(iMap.getString("TAKYIDAT_EH"));
			birSaticiTahsisDegerTx.setIptalTar(iMap.getDate("IPTAL_TAR"));
			birSaticiTahsisDegerTx.setKefaletYetkiEh(iMap.getString("KEFALET_YETKI_EH"));
			birSaticiTahsisDegerTx.setIsyeriAdresAyniEh(iMap.getString("ISYERI_ADRES_AYNI_EH"));
			birSaticiTahsisDegerTx.setTelefonNoAyniEh(iMap.getString("TELEFON_NO_AYNI_EH"));
			birSaticiTahsisDegerTx.setBeyanBilgiSorgulamaAyniEh(iMap.getString("BEYAN_BILGI_SORGULAMA_AYNI_EH"));
			birSaticiTahsisDegerTx.setTcmbSorguSonucu(iMap.getString("TCMB_SORGU_SONUCU"));
			birSaticiTahsisDegerTx.setTcmbSorguSonucuAck(iMap.getString("TCMB_SORGU_SONUCU_ACK"));
			birSaticiTahsisDegerTx.setFaalKonusuAck(iMap.getString("FAAL_KONUSU_ACK"));

			session.save(birSaticiTahsisDegerTx);

			session.flush();

			List<?> birSaticiTahsisOrtaklar = (List<?>) iMap.get("BIR_SATICI_TAHSIS_ORTAKLAR");
			String tableName = "BIR_SATICI_TAHSIS_ORTAKLAR";
			for (int i = 0; i < birSaticiTahsisOrtaklar.size(); i++) {
				BirSaticiTahsisOrtaklarTx birSaticiTahsisOrtaklarTx = new BirSaticiTahsisOrtaklarTx();

				birSaticiTahsisOrtaklarTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birSaticiTahsisOrtaklarTx.setSaticiKod(iMap.getBigDecimal(tableName, i, "SATICI_KOD"));
				birSaticiTahsisOrtaklarTx.setOrtakAdi(iMap.getString(tableName, i, "ORTAK_ADI"));
				birSaticiTahsisOrtaklarTx.setOrtaklikPay(iMap.getBigDecimal(tableName, i, "ORTAKLIK_PAY"));
				birSaticiTahsisOrtaklarTx.setTcmbKkbSonucu(iMap.getString(tableName, i, "TCMB_KKB_SONUCU"));
				birSaticiTahsisOrtaklarTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));

				session.save(birSaticiTahsisOrtaklarTx);
			}
			session.flush();

			List<?> birSaticiTahsisFinans = (List<?>) iMap.get("BIR_SATICI_TAHSIS_FINANS");
			tableName = "BIR_SATICI_TAHSIS_FINANS";
			for (int i = 0; i < birSaticiTahsisFinans.size(); i++) {
				BirSaticiTahsisFinansTx birSaticiTahsisFinansTx = new BirSaticiTahsisFinansTx();

				birSaticiTahsisFinansTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birSaticiTahsisFinansTx.setSaticiKod(iMap.getBigDecimal(tableName, i, "SATICI_KOD"));
				birSaticiTahsisFinansTx.setDonem(iMap.getDate(tableName, i, "DONEM"));
				birSaticiTahsisFinansTx.setGelirNetSatis(iMap.getBigDecimal(tableName, i, "GELIR_NET_SATIS"));
				birSaticiTahsisFinansTx.setGelirKarZarar(iMap.getBigDecimal(tableName, i, "GELIR_KAR_ZARAR"));
				birSaticiTahsisFinansTx.setGelirVergiMatrah(iMap.getBigDecimal(tableName, i, "GELIR_VERGI_MATRAH"));
				birSaticiTahsisFinansTx.setBilAktifTop(iMap.getBigDecimal(tableName, i, "BIL_AKTIF_TOP"));
				birSaticiTahsisFinansTx.setBilDonenVarlikTop(iMap.getBigDecimal(tableName, i, "BIL_DONEN_VARLIK_TOP"));
				birSaticiTahsisFinansTx.setBilTicariAlacak(iMap.getBigDecimal(tableName, i, "BIL_TICARI_ALACAK"));
				birSaticiTahsisFinansTx.setBilStok(iMap.getBigDecimal(tableName, i, "BIL_STOK"));
				birSaticiTahsisFinansTx.setBilOrtakAlacak(iMap.getBigDecimal(tableName, i, "BIL_ORTAK_ALACAK"));
				birSaticiTahsisFinansTx.setBilDuranVarTop(iMap.getBigDecimal(tableName, i, "BIL_DURAN_VAR_TOP"));
				birSaticiTahsisFinansTx.setBilMaliDuranVarlik(iMap.getBigDecimal(tableName, i, "BIL_MALI_DURAN_VARLIK"));
				birSaticiTahsisFinansTx.setMaliKisaVadeBorc(iMap.getBigDecimal(tableName, i, "MALI_KISA_VADE_BORC"));
				birSaticiTahsisFinansTx.setMaliBankaKredi(iMap.getBigDecimal(tableName, i, "MALI_BANKA_KREDI"));
				birSaticiTahsisFinansTx.setMaliTicariBorc(iMap.getBigDecimal(tableName, i, "MALI_TICARI_BORC"));
				birSaticiTahsisFinansTx.setMaliOrtaklaraBorc(iMap.getBigDecimal(tableName, i, "MALI_ORTAKLARA_BORC"));
				birSaticiTahsisFinansTx.setMaliUzunVadeliBorc(iMap.getBigDecimal(tableName, i, "MALI_UZUN_VADELI_BORC"));
				birSaticiTahsisFinansTx.setMaliOzkaynak(iMap.getBigDecimal(tableName, i, "MALI_OZKAYNAK"));
				birSaticiTahsisFinansTx.setMaliOdenmisSermaye(iMap.getBigDecimal(tableName, i, "MALI_ODENMIS_SERMAYE"));
				birSaticiTahsisFinansTx.setMaliGecVergiBorc(iMap.getBigDecimal(tableName, i, "MALI_GEC_VERGI_BORC"));
				birSaticiTahsisFinansTx.setMaliGecSskBorc(iMap.getBigDecimal(tableName, i, "MALI_GEC_SSK_BORC"));
				birSaticiTahsisFinansTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));

				session.save(birSaticiTahsisFinansTx);
			}

			session.flush();

			iMap.put("TRX_NAME", "3165");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3165_GET_SATICI_TAHSIS_BILGI")
	public static GMMap getSaticiTahsisBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3165.Get_Satici_Tahsis_Bilgi(?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("KOD"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.NUMERIC);
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.registerOutParameter(5, Types.DATE);

			stmt.execute();

			oMap.put("SATICI_ADI", stmt.getString(2));
			oMap.put("MUSTERI_NO", stmt.getBigDecimal(3));
			oMap.put("MUSTERI_ADI", stmt.getString(4));
			oMap.put("KURULUS_TARIHI", stmt.getDate(5));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
