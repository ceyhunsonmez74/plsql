package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkbVefatRisk;
import tr.com.aktifbank.bnspr.dao.KkbVefatRiskId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.zehon.sftp.SFTPClient;

public class ConsumerLoanKKBGeriBildirimServices {
	 protected static Charset charset = Charset.forName("iso-8859-9");
     private static String    ROOT    = GMServer.getProperty("graymound.home" , null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";
     private static int counter = 0;
     @GraymoundService("BNSPR_GET_KKB_VEFAT_RISK")
     public static GMMap getKkbVefatRisk(GMMap iMap) {
    	 GMMap oMap = new GMMap();
    	 ServerInfo remoteServer = null;
    	 ServerInfo localServer = null;
    	 try {
    		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
    		remoteServer = getServerInfo("KKB_VEFAT");
    		localServer  = getServerInfo("FTPARSIV");    		    		    	
    		String dosyaAdi = "00143_vefatrisk.txt";
    		String remotePath = remoteServer.getPath(); 
    		String localPath = ROOT + File.separator + "files";
    		File file = new File(localPath + File.separator + dosyaAdi);    	
    		SFTPClient sftpRemote = new SFTPClient(remoteServer.getIp() , remoteServer.getUser() , remoteServer.getPass());
		    if (sftpRemote.fileExists(remotePath, dosyaAdi)) {
		    	sftpRemote.getFile(dosyaAdi, remotePath, localPath);
		    }  else {
		    	throw new Exception("KKB Sunucusunda 00143_vefatrisk.txt isimli dosya bulunamadi");
		    }
    		
    		String tableName = "VEFAT_RISK";
    		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));				
			String line = "";
			int i=0;
			counter = 0;
			while((line=br.readLine())!=null) {
				oMap.put(tableName, i,"LINE",line);				
				oMap.put(tableName, i,"TCKN",line.substring(0,22).trim());
				if(counter<3) {
					if (isSavedTckn(oMap.getString(tableName, i, "TCKN"))) {
						counter++;
					}
				} else {
					throw new Exception("Bu Dosya Daha �nce Y�klenmi� olabilir.");
				}		
				oMap.put(tableName, i,"BANKA_KODU",line.substring(22,32).trim());
				oMap.put(tableName, i,"BANKA_ADI", line.substring(32,141).trim());
				oMap.put(tableName, i,"RISK_KODU", line.substring(141,142).trim());
				oMap.put(tableName, i,"RISK_ADI", line.substring(142,208).trim());
				String riskTarihi = line.substring(208).trim();
				if(riskTarihi != null && !riskTarihi.isEmpty()) {				
					oMap.put(tableName, i,"RISK_TARIHI", formatter.parse(riskTarihi));
				} 				
				i++;
			}
			br.close();
			if(oMap.getSize(tableName)>0) {
				saveKkbVefatRisk(oMap);				
				String arsivDosyaAdi = formatter.format(new java.util.Date())+"_"+dosyaAdi;		
				SFTPClient sftpLocal = new SFTPClient(localServer.getIp() , localServer.getUser() , localServer.getPass());			
				sftpLocal.sendFile(file, "/VEFAT_RISK", arsivDosyaAdi);				
				sftpRemote.deleteFile(dosyaAdi, remotePath);				
				file.delete();				
			}
			return oMap;
		 }
		 catch (Exception e) {
			 throw ExceptionHandler.convertException(e);
         }    	
     } 
    @GraymoundService("BNSPR_LOAD_KKB_VEFAT_RISK")
    public static GMMap loadKkbVefatRisk(GMMap iMap) { 
    	try {
    		GMMap oMap = new GMMap();
    		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
    		OutputStreamWriter wr = null;
    		BufferedReader br = null;
    		String tableName = "VEFAT_RISK";
    		File file = FileUtil.createTempDirFile("txtread");
			wr = new OutputStreamWriter(new FileOutputStream(file), charset);
			wr.write(new String((byte[]) iMap.get("CONTENT"), charset));
			wr.close();

			br = new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));				
			String line = "";
			int i=0;
			counter = 0;
			while((line=br.readLine())!=null) {
				oMap.put(tableName, i,"LINE",line);
				oMap.put(tableName, i,"TCKN",line.substring(0,22).trim());	
				if(counter<3) {
					if (isSavedTckn(oMap.getString(tableName, i, "TCKN"))) {
						counter++;
					}
				} else {
					throw new GMRuntimeException(0,"Bu Dosya Daha �nce Y�klenmi� olabilir.");
				}						
				oMap.put(tableName, i,"BANKA_KODU",line.substring(22,32).trim());
				oMap.put(tableName, i,"BANKA_ADI", line.substring(32,141).trim());
				oMap.put(tableName, i,"RISK_KODU", line.substring(141,142).trim());
				oMap.put(tableName, i,"RISK_ADI", line.substring(142,208).trim());
				String riskTarihi = line.substring(208).trim();
				if(riskTarihi != null && !riskTarihi.isEmpty()) {				
					oMap.put(tableName, i,"RISK_TARIHI", formatter.parse(riskTarihi));
				} 
				i++;
			}
			br.close();
			file.delete();
			if(oMap.getSize(tableName)>0) {
				saveKkbVefatRisk(oMap);
			}
    		return oMap;
    	}  catch (Exception e) {
			throw ExceptionHandler.convertException(e);
        }   
    }
     
    private static GMMap saveKkbVefatRisk(GMMap iMap) {
    	try {    	
    		Session session = DAOSession.getSession("BNSPRDal");    	
    		GMMap oMap = new GMMap();
    	    String tableName = "VEFAT_RISK";
    	    int len = iMap.getSize(tableName);
    	    if (len>0) {    	  
    	  	      GMMap tMap = new GMMap();
    	  	      tMap.put("TABLE_NAME", "KKB_VEFAT_RISK");
				  BigDecimal sorguNo =  (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", tMap).get("ID");
		          for(int i=0;i<len;i++) {
		        	  KkbVefatRiskId kkbVefatRiskId = new KkbVefatRiskId();
		        	  kkbVefatRiskId.setSorguNo(sorguNo);
		        	  kkbVefatRiskId.setTckn(iMap.getString(tableName,i,"TCKN"));
		        	  KkbVefatRisk kkbVefatRisk = new KkbVefatRisk();
		        	  kkbVefatRisk.setId(kkbVefatRiskId);
		        	  kkbVefatRisk.setBankaKodu(iMap.getString(tableName, i, "BANKA_KODU"));
		        	  kkbVefatRisk.setRiskKodu(iMap.getString(tableName, i, "RISK_KODU"));		        	 
		        	  kkbVefatRisk.setRiskAdi(iMap.getString(tableName, i, "RISK_ADI"));		        	
		              kkbVefatRisk.setRiskTarihi(iMap.getDate(tableName,i, "RISK_TARIHI"));				        		  		        	  
		        	  kkbVefatRisk.setYuklemeTarihi(new java.util.Date());
		        	  try {
			        	  GMMap searchMap = new GMMap();
			  		      searchMap.put("COUNTRY_CODE", "TR");
			  			  searchMap.put("TCKN", kkbVefatRiskId.getTckn());
			  			  BigDecimal musteriNo = GMServiceExecuter.call("BNSPR_GET_CUSTOMER_NO_WITH_IDENTITY", searchMap).getBigDecimal("CUSTOMER_NO");
		        	      kkbVefatRisk.setMusteriNo(musteriNo);
		        	  } catch(Exception e) {
		        		  kkbVefatRisk.setMusteriNo(null);
		        	  }
		        	  try {
		        	      session.save(kkbVefatRisk);
		        	  } catch(Exception e) {
		                 
		        	  }
		        	  if(i % 100 == 0) {
		        		  session.flush();
		        	  }
		          }
		          session.flush();    	    	  
    	    }
    		return oMap;
    	} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
        }   
    }
    @GraymoundService("BNSPR_KKB_VEFAT_RISK_SORGULA")
    public static GMMap kkbVefatRiskSorgula(GMMap iMap) {
    	try {
    		GMMap oMap = new GMMap();
    		Session session = DAOSession.getSession("BNSPRDal");
    		List<?> list = null;
    		String tckn = iMap.getString("TCKN");
    		if(tckn != null && !tckn.isEmpty()) {
    		    list = session.createCriteria(KkbVefatRisk.class).add(Restrictions.eq("id.tckn", tckn)).list(); 
    		} else {
     		    list = session.createCriteria(KkbVefatRisk.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();      		      			
     		}
    		String tableName = "VEFAT_RISK";
    		if(!list.isEmpty()) {
    		    Iterator<?> iterator = list.iterator();
    		    int i=0;
    		    while(iterator.hasNext()) {
    		    	 KkbVefatRisk kkbVefatRisk = (KkbVefatRisk) iterator.next();
    		    	 oMap.put(tableName, i,"TCKN",kkbVefatRisk.getId().getTckn());
    		    	 oMap.put(tableName, i,"BANKA_KODU",kkbVefatRisk.getBankaKodu());    		   
    		    	 oMap.put(tableName, i,"RISK_KODU",kkbVefatRisk.getRiskKodu());
    		    	 oMap.put(tableName, i,"RISK_ADI",kkbVefatRisk.getRiskAdi());
    		    	 oMap.put(tableName, i,"RISK_TARIHI",kkbVefatRisk.getRiskTarihi());
    		    	 oMap.put(tableName, i,"MUSTERI_NO",kkbVefatRisk.getMusteriNo());    		    	 
    		    	 i++;
    		    }
    		}
    		return oMap;
    	} catch(Exception e) {
    		throw ExceptionHandler.convertException(e);
    	}
    }
    private static boolean isSavedTckn(String tckn) {
    	try{
    		Session session = DAOSession.getSession("BNSPRDal");
    		List<?> list = session.createCriteria(KkbVefatRisk.class).add(Restrictions.eq("id.tckn", tckn)).list(); 
			if(list.size()>0) {
				return true;
			}  else {
				throw new Exception("Bu Tckn Kay�tl� De�il");				
			}
    		
    	} catch(Exception e) {    		
    		return false;
    	}    
    }
    public static ServerInfo getServerInfo(String serverName) throws Exception{
    	ServerInfo si = new ServerInfo();
        String func = "{? = call PKG_TRN2070.read_gnl_sifre(?)}";
        Object[] inputValues = {
        	BnsprType.STRING, serverName	
        };
        GMMap oMap = new GMMap();
        String tableName = "RESULT";
        oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULT", inputValues));
        int len = oMap.getSize(tableName);
        if(len==1) {
        	si.setIp(oMap.getString(tableName,0,"IP"));
        	si.setPass(oMap.getString(tableName,0,"PASSWD"));
        	si.setPath(oMap.getString(tableName,0,"PATH"));
        	si.setUser(oMap.getString(tableName,0,"USER_NAME"));
        	si.setFtpTuru(oMap.getString(tableName,0,"FTP_TURU"));
        	si.setPort(oMap.getString(tableName,0,"PORT"));        	
        } else {
        	throw new Exception(serverName+ " ftp bilgileri al�n�rken hata olu�tu.");
        }
    	return si;
    }
	static class ServerInfo {
		private String ip;
		private String user;
		private String pass;
		private String path;
		private String ftpTuru;
		private String port;
	
		public String getIp() {
			return ip;
		}

		public void setIp(String ip) {
			this.ip = ip;
		}

		public String getUser() {
			return user;
		}

		public void setUser(String user) {
			this.user = user;
		}

		public String getPass() {
			return pass;
		}

		public void setPass(String pass) {
			this.pass = pass;
		}

		public String getPath() {
			return path;
		}

		public void setPath(String path) {
			this.path = path;
		}
		public String getFtpTuru() {
			return ftpTuru;
		}

		public void setFtpTuru(String ftpTuru) {
			this.ftpTuru = ftpTuru;
		}

		public String getPort() {
			return port;
		}

		public void setPort(String port) {
			this.port = port;
		}				
	}
}
