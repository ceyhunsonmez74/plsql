package tr.com.calikbank.bnspr.consumerloan.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KreSozlesme;
import tr.com.calikbank.bnspr.dao.KreSozlesmeKefil;
import tr.com.calikbank.bnspr.dao.KreSozlesmeKefilTx;
import tr.com.calikbank.bnspr.dao.KreSozlesmeKefilTxId;
import tr.com.calikbank.bnspr.dao.KreSozlesmeTx;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3152Services {

	@GraymoundService("BNSPR_TRN3152_SOZLEME_GUNCELLE")
	public static Map<?, ?> saveTRN3152(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			KreSozlesmeTx kreSozlesmeTx = (KreSozlesmeTx) session.get(KreSozlesmeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (kreSozlesmeTx == null) {
				kreSozlesmeTx = new KreSozlesmeTx();
			}
			kreSozlesmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kreSozlesmeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			kreSozlesmeTx.setSozlesmeTurKodu(iMap.getString("SOZLESME_TUR_KODU"));
			kreSozlesmeTx.setSozlesmeNo(iMap.getBigDecimal("SOZLESME_NO"));
			kreSozlesmeTx.setEkSozlesmeNo(iMap.getBigDecimal("EK_SOZLESME_NO"));
			kreSozlesmeTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			kreSozlesmeTx.setSozlesmeTutari(iMap.getBigDecimal("SOZLESME_TUTARI"));
			kreSozlesmeTx.setSozlesmeTarihi(iMap.getDate("SOZLESME_TARIHI"));
			kreSozlesmeTx.setSozlesmeAmaci(iMap.getString("SOZLESME_AMACI"));
			kreSozlesmeTx.setVergilimi(iMap.getString("VERGILIMI"));
			kreSozlesmeTx.setDamgaVergisi(iMap.getString("DAMGA_VERGISI"));				
			kreSozlesmeTx.setDamgaVergisiMusteriPayi(iMap.getBigDecimal("DAMGA_VERGISI_MUSTERI_PAYI"));
			kreSozlesmeTx.setMusteriTahsilEdilecekTutar(iMap.getBigDecimal("MUSTERI_TAHSIL_EDILECEK_TUTAR"));
			kreSozlesmeTx.setDvTahsilHesapNo(iMap.getBigDecimal("DV_TAHSIL_HESAP_NO"));
			
			kreSozlesmeTx.setOncVergilimi(iMap.getString("ONC_VERGILIMI"));
			kreSozlesmeTx.setOncDamgaVergisi(iMap.getString("ONC_DAMGA_VERGISI"));
			kreSozlesmeTx.setOncDamgaVergisiMusteriPayi(iMap.getBigDecimal("ONC_DAMGA_VERGISI_MUSTERI_PAYI"));
			kreSozlesmeTx.setOncMusTahsilEdilecekTutar(iMap.getBigDecimal("ONC_MUS_TAHSIL_EDILECEK_TUTAR"));
			kreSozlesmeTx.setOncDvTahsilHesapNo(iMap.getBigDecimal("ONC_DV_TAHSIL_HESAP_NO"));
			
			kreSozlesmeTx.setSubeKodu(iMap.getString("SUBE_KOD"));
			kreSozlesmeTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			kreSozlesmeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			kreSozlesmeTx.setDurumKodu("ACIK");
            kreSozlesmeTx.setAciklama(iMap.getString("SOZLESME_ACIKLAMA"));
            kreSozlesmeTx.setTanzimTarihi(iMap.getDate("TANZIM_TARIHI"));
			kreSozlesmeTx.setTeminatVeren(iMap.getBigDecimal("TEMINAT_VEREN"));
			
			session.saveOrUpdate(kreSozlesmeTx);

			List<?> kefilPersistenceList = session.createCriteria(KreSozlesmeKefilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = kefilPersistenceList.iterator(); iterator.hasNext();) {
				KreSozlesmeKefilTx kreSozlesmeKefilTx = (KreSozlesmeKefilTx) iterator.next();
				session.delete(kreSozlesmeKefilTx);
			}
			session.flush();

			String tableName = "SOZLESME_KEFIL_ISLEM";
			ArrayList<?> sozlesmeKefilIslem = (ArrayList<?>) iMap.get(tableName);
			for (int i=0; i<sozlesmeKefilIslem.size(); i++) {
			  //   for (int j = i+1;j<sozlesmeKefilIslem.size();j++){
			         if(i>0  && iMap.getBigDecimal(tableName, i, "KEFIL_MUSTERI_NO").compareTo(iMap.getBigDecimal(tableName, i-1, "KEFIL_MUSTERI_NO"))==0)
			         {
			             iMap.put("HATA_NO", new BigDecimal(3668));
                         return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			             
			         }else{
        				KreSozlesmeKefilTx kefilTx = new KreSozlesmeKefilTx();
        				KreSozlesmeKefilTxId id = new KreSozlesmeKefilTxId();
        				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
        				id.setKefilMusteriNo(iMap.getBigDecimal(tableName, i, "KEFIL_MUSTERI_NO"));
        				kefilTx.setId(id);
        				kefilTx.setDovizKodu(iMap.getString(tableName, i, "K_DOVIZ_KODU"));
        				kefilTx.setEkSozlesmeNo(iMap.getBigDecimal("EK_SOZLESME_NO"));
        				kefilTx.setKefaletOrani(iMap.getBigDecimal(tableName, i, "KEFALET_ORANI"));
        				kefilTx.setKefaletSekli(iMap.getString(tableName, i, "KEFALET_SEKLI"));
        				kefilTx.setKefaletTutari(iMap.getBigDecimal(tableName, i, "KEFALET_TUTARI"));
        				kefilTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
        				kefilTx.setSozlesmeNo(iMap.getBigDecimal("SOZLESME_NO"));
        				kefilTx.setKefaletTaahhutname(iMap.getString(tableName, i, "KEFALET_TAAHHUTNAME"));
        				kefilTx.setKefaletEsMuvafakatname(iMap.getString(tableName, i, "KEFALET_ES_MUVAFAKATNAME"));
        				kefilTx.setKefaletCaymaTarihi(iMap.getDate(tableName, i, "KEFALET_CAYMA_TARIHI"));
        				session.save(kefilTx);
			         }
			   //  }
			}
			session.flush();

			iMap.put("TRX_NAME", "3152");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3152_GET_SOZLESME")
	public static Map<?, ?> getSozleme(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			KreSozlesme kreSozlesme = null;
			kreSozlesme = (KreSozlesme) session.createCriteria(KreSozlesme.class).add(Restrictions.eq("id.sozlesmeNo", iMap.getBigDecimal("SOZLESME_NO"))).add(Restrictions.eq("id.ekSozlesmeNo", iMap.getBigDecimal("EK_SOZLESME_NO"))).uniqueResult();
			oMap.put("MUSTERI_NO", kreSozlesme.getId().getMusteriNo());
			oMap.put("UNVAN", LovHelper.diLov(kreSozlesme.getId().getMusteriNo(), "3152/LOV_MUSTERI", "UNVAN"));
			oMap.put("SOZLESME_TUR_KODU", kreSozlesme.getSozlesmeTurKodu());
			oMap.put("SOZLESME_TIPI", LovHelper.diLov(kreSozlesme.getSozlesmeTurKodu(),kreSozlesme.getBasvuruNo(),kreSozlesme.getBasvuruNo(), "3151/LOV_SOZLESME_KOD", "TIP"));
			
			oMap.put("SOZLESME_NO", kreSozlesme.getId().getSozlesmeNo());
			oMap.put("EK_SOZLESME_NO", kreSozlesme.getId().getEkSozlesmeNo());
			oMap.put("DOVIZ_KODU", kreSozlesme.getDovizKodu());
			oMap.put("SOZLESME_TUTARI", kreSozlesme.getSozlesmeTutari());
			oMap.put("SOZLESME_TARIHI", kreSozlesme.getSozlesmeTarihi());
			oMap.put("VERGILIMI", kreSozlesme.getVergilimi());
			oMap.put("DAMGA_VERGISI", kreSozlesme.getDamgaVergisi());
			oMap.put("BASVURU_NO", kreSozlesme.getBasvuruNo());
			oMap.put("HESAP_NO", kreSozlesme.getHesapNo());
			if (kreSozlesme.getDamgaVergisiMusteriPayi() != null)
				oMap.put("DAMGA_VERGISI_MUSTERI_PAYI", kreSozlesme.getDamgaVergisiMusteriPayi().intValue() + "");
			else
				oMap.put("DAMGA_VERGISI_MUSTERI_PAYI", "");
			oMap.put("MUSTERI_TAHSIL_EDILECEK_TUTAR", kreSozlesme.getMusteriTahsilEdilecekTutar());
			oMap.put("SUBE_KOD", kreSozlesme.getSubeKodu());
			oMap.put("DV_TAHSIL_HESAP_NO", kreSozlesme.getDvTahsilHesapNo());
			oMap.put("TEMINAT_VEREN", kreSozlesme.getTeminatVeren());
            oMap.put("TANZIM_TARIHI", kreSozlesme.getTanzimTarihi());
            oMap.put("TEMINAT_VEREN_UNVAN", LovHelper.diLov(kreSozlesme.getTeminatVeren(), "3151/LOV_TEMINAT_VEREN_MUSTERI", "UNVAN"));
            oMap.put("ACIKLAMA", kreSozlesme.getAciklama());
            
			String tableName = "SOZLESME_KEFIL_ISLEM";
			int row = 0;
			for (Iterator<?> iterator = kreSozlesme.getKreSozlesmeKefils().iterator(); iterator.hasNext();row++) {
				KreSozlesmeKefil kreSozlesmeKefil = (KreSozlesmeKefil) iterator.next();
				oMap.put(tableName, row, "KEFIL_MUSTERI_NO", kreSozlesmeKefil.getId().getKefilMusteriNo());
				oMap.put(tableName, row, "DI_UNVAN", LovHelper.diLov(kreSozlesmeKefil.getId().getKefilMusteriNo(), kreSozlesme.getId().getMusteriNo(), "3151/LOV_KEFIL_MUSTERI", "UNVAN"));
				oMap.put(tableName, row, "K_DOVIZ_KODU", kreSozlesmeKefil.getDovizKodu());
				oMap.put(tableName, row, "EK_SOZLESME_NO", kreSozlesme.getId().getEkSozlesmeNo());
				oMap.put(tableName, row, "KEFALET_ORANI", kreSozlesmeKefil.getKefaletOrani());
				oMap.put(tableName, row, "KEFALET_TUTARI", kreSozlesmeKefil.getKefaletTutari());
				oMap.put(tableName, row, "KEFALET_SEKLI", kreSozlesmeKefil.getKefaletSekli());
				oMap.put(tableName, row, "SOZLESME_NO", kreSozlesme.getId().getSozlesmeNo());
				oMap.put(tableName, row, "KEFALET_TAAHHUTNAME", kreSozlesmeKefil.getKefaletTaahhutname());
				oMap.put(tableName, row, "KEFALET_ES_MUVAFAKATNAME", kreSozlesmeKefil.getKefaletEsMuvafakatname());
				oMap.put(tableName, row, "KEFALET_CAYMA_TARIHI", kreSozlesmeKefil.getKefaletCaymaTarihi());
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3152_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			KreSozlesmeTx kreSozlesmeTx = (KreSozlesmeTx) session.get(KreSozlesmeTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("MUSTERI_NO", kreSozlesmeTx.getMusteriNo());
			oMap.put("UNVAN", LovHelper.diLov(kreSozlesmeTx.getMusteriNo(), "3152/LOV_MUSTERI", "UNVAN"));
			oMap.put("SOZLESME_TUR_KODU", kreSozlesmeTx.getSozlesmeTurKodu());
			oMap.put("SOZLESME_TIPI", LovHelper.diLov(kreSozlesmeTx.getSozlesmeTurKodu(),kreSozlesmeTx.getBasvuruNo(),kreSozlesmeTx.getBasvuruNo(), "3151/LOV_SOZLESME_KOD", "TIP"));
			
			oMap.put("SOZLESME_NO", kreSozlesmeTx.getSozlesmeNo());
			oMap.put("EK_SOZLESME_NO", kreSozlesmeTx.getEkSozlesmeNo());
			oMap.put("DOVIZ_KODU", kreSozlesmeTx.getDovizKodu());
			oMap.put("SOZLESME_TUTARI", kreSozlesmeTx.getSozlesmeTutari());
			oMap.put("SOZLESME_TARIHI", kreSozlesmeTx.getSozlesmeTarihi());
			oMap.put("VERGILIMI", kreSozlesmeTx.getVergilimi());
			oMap.put("DAMGA_VERGISI", kreSozlesmeTx.getDamgaVergisi());
			oMap.put("BASVURU_NO", kreSozlesmeTx.getBasvuruNo());
			oMap.put("HESAP_NO", kreSozlesmeTx.getHesapNo());
			oMap.put("DAMGA_VERGISI_MUSTERI_PAYI", kreSozlesmeTx.getDamgaVergisiMusteriPayi());
			oMap.put("MUSTERI_TAHSIL_EDILECEK_TUTAR", kreSozlesmeTx.getMusteriTahsilEdilecekTutar());
			oMap.put("SUBE_KOD", kreSozlesmeTx.getSubeKodu());
            oMap.put("TANZIM_TARIHI", kreSozlesmeTx.getTanzimTarihi());
			oMap.put("DV_TAHSIL_HESAP_NO", kreSozlesmeTx.getDvTahsilHesapNo());
			oMap.put("SOZLESME_ACIKLAMA", kreSozlesmeTx.getAciklama());
			oMap.put("TEMINAT_VEREN", kreSozlesmeTx.getTeminatVeren());
			
			
			 
			 KreSozlesme kreSozlesme = (KreSozlesme) session.createCriteria(KreSozlesme.class)
					 .add(Restrictions.eq("id.sozlesmeNo", oMap.getBigDecimal("SOZLESME_NO"))).uniqueResult();
		        
			
			 KreSozlesme kreSozlesme2 = kreSozlesme;
			
			String aciklama=kreSozlesme2.getAciklama();
			
			if (aciklama==null)
				oMap.put("SOZLESME_ACIKLAMA_COLOR", Color.YELLOW);
			else if (!aciklama.contentEquals(oMap.getString("SOZLESME_ACIKLAMA")))
				oMap.put("SOZLESME_ACIKLAMA_COLOR", Color.YELLOW);
			
			BigDecimal MUSTERI_NO=kreSozlesme2.getId().getMusteriNo();
			
			if (MUSTERI_NO==null)
				oMap.put("MUSTERI_NO_COLOR", Color.YELLOW);
			else if (!MUSTERI_NO.equals(oMap.getBigDecimal("MUSTERI_NO")))
				oMap.put("MUSTERI_NO_COLOR", Color.YELLOW);
			
			BigDecimal hesapNo=kreSozlesme2.getHesapNo();
			
			if (hesapNo==null)
				oMap.put("HESAP_NO_COLOR", Color.YELLOW);
			else if (!hesapNo.equals(oMap.getBigDecimal("HESAP_NO")))
				oMap.put("HESAP_NO_COLOR", Color.YELLOW);
			
			
			String dovizKodu=kreSozlesme2.getDovizKodu();
			
			if (dovizKodu==null)
				oMap.put("DOVIZ_KODU_COLOR", Color.YELLOW);
			else if (!dovizKodu.equals(oMap.getString("DOVIZ_KODU")))
				oMap.put("DOVIZ_KODU_COLOR", Color.YELLOW);
			
			BigDecimal sozlesmeTutar=kreSozlesme2.getSozlesmeTutari();
			
			if (sozlesmeTutar==null)
				oMap.put("SOZLESME_TUTARI_COLOR", Color.YELLOW);
			else if (!sozlesmeTutar.equals(oMap.getBigDecimal("SOZLESME_TUTARI")))
				oMap.put("SOZLESME_TUTARI_COLOR", Color.YELLOW);
			
			Date sozlesmeTarih=kreSozlesme2.getSozlesmeTarihi();
	
			if (sozlesmeTarih==null)
				oMap.put("SOZLESME_TARIHI_COLOR", Color.YELLOW);
			else if (!sozlesmeTarih.equals(oMap.getDate("SOZLESME_TARIHI")))
				oMap.put("SOZLESME_TARIHI_COLOR", Color.YELLOW);
			
			Date tanzimTarih=kreSozlesme2.getTanzimTarihi();
			
			if (tanzimTarih==null)
				oMap.put("TANZIM_TARIHI_COLOR", Color.YELLOW);
			else if (!tanzimTarih.equals(oMap.getDate("TANZIM_TARIHI")))
				oMap.put("TANZIM_TARIHI_COLOR", Color.YELLOW);
			
			
			
			BigDecimal teminatVeren=kreSozlesme2.getTeminatVeren();
			
			if (teminatVeren==null)
				oMap.put("TEMINAT_VEREN_COLOR", Color.YELLOW);
			else if (!teminatVeren.equals(oMap.getBigDecimal("TEMINAT_VEREN")))
				oMap.put("TEMINAT_VEREN_COLOR", Color.YELLOW);
			
			List<?> list = session.createCriteria(KreSozlesmeKefilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "SOZLESME_KEFIL_ISLEM";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KreSozlesmeKefilTx kreSozlesmeKefilTx = (KreSozlesmeKefilTx) iterator.next();

				oMap.put(tableName, row, "KEFIL_MUSTERI_NO", kreSozlesmeKefilTx.getId().getKefilMusteriNo());
				oMap.put(tableName, row, "DI_UNVAN", LovHelper.diLov(kreSozlesmeKefilTx.getId().getKefilMusteriNo(), kreSozlesmeTx.getMusteriNo(), "3151/LOV_KEFIL_MUSTERI", "UNVAN"));
				oMap.put(tableName, row, "K_DOVIZ_KODU", kreSozlesmeKefilTx.getDovizKodu());
				oMap.put(tableName, row, "EK_SOZLESME_NO", kreSozlesmeTx.getEkSozlesmeNo());
				oMap.put(tableName, row, "KEFALET_ORANI", kreSozlesmeKefilTx.getKefaletOrani());
				oMap.put(tableName, row, "KEFALET_TUTARI", kreSozlesmeKefilTx.getKefaletTutari());
				oMap.put(tableName, row, "KEFALET_SEKLI", kreSozlesmeKefilTx.getKefaletSekli());
				oMap.put(tableName, row, "SOZLESME_NO", kreSozlesmeTx.getSozlesmeNo());
				oMap.put(tableName, row, "KEFALET_TAAHHUTNAME", kreSozlesmeKefilTx.getKefaletTaahhutname());
				oMap.put(tableName, row, "KEFALET_ES_MUVAFAKATNAME", kreSozlesmeKefilTx.getKefaletEsMuvafakatname());
				oMap.put(tableName, row, "KEFALET_CAYMA_TARIHI", kreSozlesmeKefilTx.getKefaletCaymaTarihi());

				row++;
			}
			
		 
			  List<?> bbtTMPOld2 = session.createCriteria(KreSozlesme.class)
					  .add(Restrictions.eq("id.sozlesmeNo",oMap.getBigDecimal(tableName , 0 , "SOZLESME_NO")))					  
					  .list();
	            
	           String oldTableName = "SOZLESME_KEFIL_ISLEM_OLD";
	            
	            GMMap oldMap2=new GMMap();
	            for (int i = 0; i < bbtTMPOld2.size(); i++){
	                KreSozlesme bb = (KreSozlesme)bbtTMPOld2.get(i);
	            	oMap.put(oldTableName , i , "KEFIL_MUSTERI_NO" , bb.getId().getMusteriNo());
	            	oMap.put(oldTableName , i , "K_DOVIZ_KODU" , bb.getDovizKodu());
	            	oMap.put(oldTableName , i , "EK_SOZLESME_NO" , bb.getId().getEkSozlesmeNo());
	         
	            	oMap.put(oldTableName , i , "SOZLESME_NO" , bb.getId().getSozlesmeNo());
	           
	            	try {
	            	   	oMap.put(oldTableName , i , "KEFALET_ORANI" , bb.getKreSozlesmeKefils().iterator().next().getKefaletOrani());
		            	oMap.put(oldTableName , i , "KEFALET_TUTARI" , bb.getKreSozlesmeKefils().iterator().next().getKefaletTutari());
		            	oMap.put(oldTableName , i , "KEFALET_SEKLI" , bb.getKreSozlesmeKefils().iterator().next().getKefaletSekli());
	            	 	oMap.put(oldTableName , i , "KEFALET_TAAHHUTNAME" , bb.getKreSozlesmeKefils().iterator().next().getKefaletTaahhutname());
		            	oMap.put(oldTableName , i , "KEFALET_ES_MUVAFAKATNAME" , bb.getKreSozlesmeKefils().iterator().next().getKefaletEsMuvafakatname());
		            	oMap.put(oldTableName , i , "KEFALET_CAYMA_TARIHI" , bb.getKreSozlesmeKefils().iterator().next().getKefaletCaymaTarihi());
	            	}catch(Exception e)
	            	{
	            		oMap.put(oldTableName , i , "KEFALET_CAYMA_TARIHI" , "");
	            		oMap.put(oldTableName , i , "KEFALET_TAAHHUTNAME" ,"");
		            	oMap.put(oldTableName , i , "KEFALET_ES_MUVAFAKATNAME" , "");
		               	oMap.put(oldTableName , i , "KEFALET_ORANI" , "");
		            	oMap.put(oldTableName , i , "KEFALET_TUTARI" , "");
		            	oMap.put(oldTableName , i , "KEFALET_SEKLI" ,"");
	            	}
	                 
	            }
	            ArrayList<String> str2 = new ArrayList<String>();
	            
	            str2.add("KEFIL_MUSTERI_NO");
	            str2.add("K_DOVIZ_KODU");
	            str2.add("EK_SOZLESME_NO");
	            str2.add("KEFALET_ORANI");
	            str2.add("KEFALET_TUTARI");
	            str2.add("KEFALET_SEKLI");
	            str2.add("SOZLESME_NO");
	            str2.add("KEFALET_TAAHHUTNAME");
	            str2.add("KEFALET_ES_MUVAFAKATNAME");
	            str2.add("KEFALET_CAYMA_TARIHI");
	            
	            oMap.put("COLOR_DATA",BeanSetProperties.tableDifferenceWithPropertiesColumn( (ArrayList<?>) oMap.get(oldTableName),(ArrayList<?>) oMap.get(tableName)  , str2).get("COLOR_DATA"));
	            
	            

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
