package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.tree.DefaultMutableTreeNode;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMeslekUnvanMatrixTx;
import tr.com.calikbank.bnspr.dao.GnlMeslekUnvanMatrixTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3121Services {
	private static final String unvanListQuery = "select kod, aciklama  from v_ml_gnl_unvan_kod_pr order by kod "; //Decode(aciklama,'Di�er','ZZZZZZZ',aciklama)
	private static final String txGetInfoQuery = "select a.aciklama, m.kod, m.unvan_dizi from gnl_meslek_unvan_matrix_tx m, gnl_meslek_kod_pr a where a.kod = m.kod and m.tx_no = ?";
	public static final String meslekQuery = "select a.aciklama, a.kod, a.unvan_dizi from gnl_meslek_kod_pr a";
	
	@GraymoundService("BNSPR_TRN3121_GET_MESLEK_UNVAN_TREE")
	public static GMMap getMeslekTree(GMMap iMap) {
		GMMap oMap = new GMMap();
		MeslekMatrixTreeFactory factory = new MeslekMatrixTreeFactory(meslekQuery, unvanListQuery);
		oMap.put("ROOT", factory.createMatrixTree());
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3121_SAVE_MESLEK_UNVAN_MATRIX")
	public static Map<?, ?> saveMeslekUnvanMatrix(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			DefaultMutableTreeNode root = (DefaultMutableTreeNode)iMap.get("ROOT");
			for (int i = 0; i < root.getChildCount(); i++) {
				DefaultMutableTreeNode meslekNode = (DefaultMutableTreeNode)root.getChildAt(i);
				GnlMeslekUnvanMatrixTx unvanMatrixTx = new GnlMeslekUnvanMatrixTx();
				char[] unvanDizi = new char[meslekNode.getChildCount()];
				GnlMeslekUnvanMatrixTxId id = new GnlMeslekUnvanMatrixTxId();
				HashMap<?, ?> meslekUo = (HashMap<?, ?>)meslekNode.getUserObject();
				id.setKod((String)meslekUo.get("KOD"));
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				unvanMatrixTx.setId(id);
				for (int j = 0; j < meslekNode.getChildCount(); j++) {
					DefaultMutableTreeNode unvanNode = (DefaultMutableTreeNode)meslekNode.getChildAt(j);
					HashMap<?, ?> unvanUo = (HashMap<?, ?>)unvanNode.getUserObject();
					unvanDizi[j] = ConsumerLoanTRN3120Services.getSelectedValueAsChar(unvanUo.get("SELECTED"));
				}
				unvanMatrixTx.setUnvanDizi(new String(unvanDizi));
				session.save(unvanMatrixTx);
				session.flush();
			}
			
			iMap.put("TRX_NAME", "3121");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3121_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement(txGetInfoQuery);
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			resultSet = stmt.executeQuery();
			oMap.put("ROOT", new MeslekMatrixTreeFactory(resultSet, unvanListQuery).createMatrixTree());
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(resultSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
