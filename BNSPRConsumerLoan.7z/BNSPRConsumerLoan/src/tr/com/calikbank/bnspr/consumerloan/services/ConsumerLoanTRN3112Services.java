package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import jxl.Sheet;
import jxl.Workbook;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.aktifbank.bnspr.dao.BirAzamiFaizOranPr;
import tr.com.aktifbank.bnspr.dao.BirKampRiskUrunTx;
import tr.com.aktifbank.bnspr.dao.BirKampRiskUrunTxId;
import tr.com.aktifbank.bnspr.dao.BirKampSigortaSatisTx;
import tr.com.aktifbank.bnspr.dao.BirKampSigortaSatisTxId;
import tr.com.aktifbank.bnspr.dao.BirKampanyaSigUrunTx;
import tr.com.aktifbank.bnspr.dao.BirKampanyaSigUrunTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKampBloke;
import tr.com.calikbank.bnspr.dao.BirKampBlokeTx;
import tr.com.calikbank.bnspr.dao.BirKampBlokeTxId;
import tr.com.calikbank.bnspr.dao.BirKampKnlTx;
import tr.com.calikbank.bnspr.dao.BirKampKnlTxId;
import tr.com.calikbank.bnspr.dao.BirKampMeslekIliskiTx;
import tr.com.calikbank.bnspr.dao.BirKampMeslekIliskiTxId;
import tr.com.calikbank.bnspr.dao.BirKampTeminatIliskiTx;
import tr.com.calikbank.bnspr.dao.BirKampTeminatIliskiTxId;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.dao.BirKampanyaTx;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3112Services {
	
	private static BigDecimal VADE_12_AY = new BigDecimal("12");
	private static BigDecimal VADE_24_AY = new BigDecimal("24");

	@GraymoundService("BNSPR_TRN3112_GET_COMBOBOX_INITIAL_VALUES")
	public static GMMap getComboboxInitialValues(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			ConsumerLoanTRN3103Services.getDovizKodlari(oMap, "DOVIZ_KODLARI");
			ConsumerLoanTRN3103Services.getKanalKodlari(oMap, "KANAL_KODLARI");
			getMusteriGrupKodlari(oMap, "MUSTERI_GRUP_KOD");
			oMap.put("DATE", new Date());
			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3112_FILL_MESLEK_TABLE")
	public static GMMap fillMeslekTable(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareStatement("SELECT KOD, ACIKLAMA FROM V_ML_GNL_MESLEK_KOD_PR WHERE DURUM = 'A' ORDER BY TO_NUMBER(KOD)");

			rSet = stmt.executeQuery();

			GMMap oMap = new GMMap();
			String tableName = "MESLEK_KODLARI";
			int row = 0;
			while (rSet.next()) {

				oMap.put(tableName, row, "SEC", false);
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(1));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(2));

				row++;
			}

			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static ArrayList<BigDecimal> strTokenizer(String str) {

		try {

			ArrayList<BigDecimal> list = new ArrayList<BigDecimal>();

			StringTokenizer tok = new StringTokenizer(str, ",");
			while (tok.hasMoreTokens()) {
				String token = tok.nextToken();
				BigDecimal bd = new BigDecimal(Integer.parseInt(token));
				list.add(bd);
			}

			return list;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3112_SAVE")
	public static Map<?, ?> trn3112Save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirKampanyaTx birKampanyaTx = (BirKampanyaTx) session.get(BirKampanyaTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birKampanyaTx == null)
				birKampanyaTx = new BirKampanyaTx();

			if ("5".equals(iMap.getString("PARANIN_ODENECEGI_YER")) && iMap.getBigDecimal("FIRMA_HESAP_NO") == null) {
				GMMap t = new GMMap();
				t.put("HATA_NO", 330);
				t.put("P1", "Firma Hesap No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", t);
			}

			// KAMPANYA TANIMLAMA
			birKampanyaTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birKampanyaTx.setKod(iMap.getBigDecimal("KAMPANYA_KOD"));
			birKampanyaTx.setAciklama(iMap.getString("KAMPANYA_ADI"));
			birKampanyaTx.setKrdTurKod(iMap.getBigDecimal("KREDI_TURU"));
			birKampanyaTx.setKrdTurAltKod(iMap.getBigDecimal("KREDI_TIPI"));
			birKampanyaTx.setKrdTurAltKod2(iMap.getBigDecimal("ALT_KREDI_TIPI"));
			birKampanyaTx.setBasTarih(iMap.getDate("TARIH_ARALIK_BAS"));
			birKampanyaTx.setBitTarih(iMap.getDate("TARIH_ARALIK_BIT"));
			birKampanyaTx.setKamTipKod(iMap.getString("KAMPANYA_TIPI"));
			birKampanyaTx.setParOdeYerKod(iMap.getString("PARANIN_ODENECEGI_YER"));
			birKampanyaTx.setUrunBazDegEh(iMap.getString("URUN_BAZINDA_MI"));
			birKampanyaTx.setMusTipKod(iMap.getString("MUSTERI_GRUBU"));
			birKampanyaTx.setMusOzelEh(iMap.getString("MUSTERIYE_OZEL_MI"));
			birKampanyaTx.setDrm(iMap.getString("DURUM"));
			birKampanyaTx.setKampAck(iMap.getString("ACIKLAMA"));
			birKampanyaTx.setWeekendCare(iMap.getBigDecimal("WEEKEND_CARE"));
			birKampanyaTx.setOtelemeGunSayisi(iMap.getBigDecimal("OTELEME_GUN_SAYISI"));
			birKampanyaTx.setFirmaHesapNo(iMap.getBigDecimal("FIRMA_HESAP_NO"));
			birKampanyaTx.setFarkFaiziOdemeSekli(iMap.getString("FAIZ_ODEME_SEKLI"));
			birKampanyaTx.setKrdTutarDagitimTip(iMap.getString("KRD_TUTAR_DAGITIM"));
			birKampanyaTx.setKrdTutarDagitimOran(iMap.getBigDecimal("KRD_TUTAR_DAGITIM_ORAN"));
			birKampanyaTx.setKomisyonluDagitimEh(iMap.getString("KOMISYONLU_DAGITIM"));
			birKampanyaTx.setTaksitGunuDisiAraOdemeEh(iMap.getString("TAKSIT_GUNU_DISI_ARA_ODEME"));
			birKampanyaTx.setKulBlokeKodu(iMap.getString("KUL_BLOKE_KODU"));
			birKampanyaTx.setOdmGrpNo(iMap.getBigDecimal("ODEME_GRUBU"));
			birKampanyaTx.setFaizsizSure(iMap.getBigDecimal("FAIZSIZ_SURE"));
			if (iMap.getBoolean("HERSEY_DAHIL_EH")) {
				birKampanyaTx.setHerseyDahilEh("E");
			}
			else {
				birKampanyaTx.setHerseyDahilEh("H");
			}
			birKampanyaTx.setYenidenYapilandirma(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("YENIDEN_YAPILANDIRMA")));
			birKampanyaTx.setFinansmanTuru(iMap.getString("FINANSMAN_TURU"));
			birKampanyaTx.setValorOteGun(iMap.getBigDecimal("VALOR_OTE_GUN"));
			if (iMap.getBoolean("ON_ODEMELI_EH")) {
				birKampanyaTx.setOnOdemeliEh("E");
			}
			else {
				birKampanyaTx.setOnOdemeliEh("H");
			}
			if (iMap.getBoolean("GERI_CEKME_EH")) {
				birKampanyaTx.setGeriCekmeEh("E");
			}
			else {
				birKampanyaTx.setGeriCekmeEh("H");
			}
			
			/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			if (iMap.getBoolean("TICARI_KREDI_EH"))
				birKampanyaTx.setTicariKrediEh("E");
			else
				birKampanyaTx.setTicariKrediEh("H");
			birKampanyaTx.setEkPaketKod(iMap.getBigDecimal("EK_PAKET"));
			birKampanyaTx.setBirlestirmeEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("BIRLESTIRME_EH")));
			birKampanyaTx.setGormeEngelliEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("GORME_ENGELLI_EH")));
			birKampanyaTx.setBorcTransferiEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("BORC_TRANSFERI_EH")));
			birKampanyaTx.setUcuncuSahisEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("UCUNCU_SAHIS_EH")));
			birKampanyaTx.setPttIciBirlestirmeEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("PTT_ICI_BIRLESTIRME_EH")));
			
			session.saveOrUpdate(birKampanyaTx);
			session.flush();

			// MESLEK KODLARI
			List<?> listMeslekKodlari = (List<?>) iMap.get("MESLEK_KODLARI");
			String tableName = "MESLEK_KODLARI";
			for (int i = 0; i < listMeslekKodlari.size(); i++) {

				BirKampMeslekIliskiTx birKampMeslekIliskiTx = new BirKampMeslekIliskiTx();
				BirKampMeslekIliskiTxId id = new BirKampMeslekIliskiTxId();

				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKampKod(iMap.getBigDecimal("KAMPANYA_KOD"));
				id.setMeslekKod(iMap.getString(tableName, i, "KOD"));

				birKampMeslekIliskiTx.setId(id);
				birKampMeslekIliskiTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, i, "SEC")));

				session.save(birKampMeslekIliskiTx);
				session.flush();
			}

			BirAzamiFaizOranPr azamiFaizOranPr = findBirAzamiFaiz(iMap);
			
			// URUN LISTESI
			List<?> listUrun = (List<?>) iMap.get("URUN");
			if (listUrun != null)
				for (int i = 0; i < listUrun.size(); i++) {
					
					tableName = "URUN";
					BigDecimal bazFaiz = iMap.getBigDecimal(tableName, i, "BAZ_FAIZ");
					BigDecimal minVade = iMap.getBigDecimal(tableName, i, "MIN_VADE");
					BigDecimal maxVade = iMap.getBigDecimal(tableName, i, "MAX_VADE");
					
					if(azamiFaizAsildi(bazFaiz, minVade, azamiFaizOranPr) || azamiFaizAsildi(bazFaiz, maxVade, azamiFaizOranPr)) {
						throw new GMRuntimeException(0, "Azami faiz oran�n�n �zerinde tan�mlama yapamazs�n�z!");
					}

					//tableName = "URUN";
					BirKampKnlTx birKampKnlTx = new BirKampKnlTx();
					BirKampKnlTxId idKnl = new BirKampKnlTxId();

					idKnl.setTxNo(iMap.getBigDecimal("TRX_NO"));
					HashMap<String, Object> xMap = new HashMap<String, Object>();
					xMap.put("TABLE_NAME", "BIR_KAMP_KNL");

					BigDecimal birKampKnlKod;
					if (iMap.get(tableName, i, "KOD") == null)
						birKampKnlKod = (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", xMap).get("ID");
					else
						birKampKnlKod = iMap.getBigDecimal(tableName, i, "KOD");
					idKnl.setKod(birKampKnlKod);
					// idKnl.setKod((BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", xMap).get("ID"));

					birKampKnlTx.setId(idKnl);
					birKampKnlTx.setKampKod(iMap.getBigDecimal("KAMPANYA_KOD"));
					birKampKnlTx.setDrm(iMap.getString("DURUM"));
					birKampKnlTx.setMarkaKod(iMap.getString(tableName, i, "MARKA"));
					birKampKnlTx.setModelKod(iMap.getBigDecimal(tableName, i, "MODEL"));
					birKampKnlTx.setModelYil(iMap.getBigDecimal(tableName, i, "MODEL_YIL"));
					birKampKnlTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KODU"));
					birKampKnlTx.setKanaldakiAd(iMap.getString(tableName, i, "KANALDAKI_ADI"));
					birKampKnlTx.setDovizKod(iMap.getString(tableName, i, "DOVIZ_CINSI"));
					birKampKnlTx.setMinVade(iMap.getBigDecimal(tableName, i, "MIN_VADE"));
					birKampKnlTx.setMaxVade(iMap.getBigDecimal(tableName, i, "MAX_VADE"));
					birKampKnlTx.setAltLimit(iMap.getBigDecimal(tableName, i, "ALT_LIMIT"));
					birKampKnlTx.setUstLimit(iMap.getBigDecimal(tableName, i, "UST_LIMIT"));
					birKampKnlTx.setBazOran(iMap.getBigDecimal(tableName, i, "BAZ_FAIZ"));
					String sabitSozlesmeFaizi = iMap.getString(tableName, i, "SABIT_SOZLESME_FAIZI_EH");
					if ("X".equals(sabitSozlesmeFaizi)) {
						sabitSozlesmeFaizi = null;
					}
					birKampKnlTx.setSabitSozlesmeFaiziEh(sabitSozlesmeFaizi);
					birKampKnlTx.setSozlesmeOran(iMap.getBigDecimal(tableName, i, "SOZLESME_FAIZI"));
					// birKampKnlTx.setOdmGrpNo(iMap.getBigDecimal(tableName, i, "ODEME_GRUBU"));
					birKampKnlTx.setDosMasrafTipi(iMap.getString(tableName, i, "DOSYA_MASRAF_TIP"));
					birKampKnlTx.setMinDosMasraf(iMap.getBigDecimal(tableName, i, "MIN_DOSYA_MASRAFI"));
					birKampKnlTx.setMaxDosMasraf(iMap.getBigDecimal(tableName, i, "MAX_DOSYA_MASRAFI"));
					birKampKnlTx.setDosMasrafOran(iMap.getBigDecimal(tableName, i, "DOSYA_MASRAF_ORAN"));
					birKampKnlTx.setInternetEh(iMap.getString(tableName, i, "INTERNET_EH"));
					birKampKnlTx.setKatkiPayiKimden(iMap.getString(tableName, i, "KATKI_PAYI_KIMDEN"));
					birKampKnlTx.setKatkiPayiTipi(iMap.getString(tableName, i, "KATKI_PAYI_TIPI"));
					birKampKnlTx.setMinKatkiPayi(iMap.getBigDecimal(tableName, i, "MIN_KATKI_PAYI"));
					birKampKnlTx.setMaxKatkiPayi(iMap.getBigDecimal(tableName, i, "MAX_KATKI_PAYI"));
					birKampKnlTx.setKatkiPayiOran(iMap.getBigDecimal(tableName, i, "KATKI_PAYI_ORAN"));
					birKampKnlTx.setKatkiPayDagitimTip(iMap.getString(tableName, i, "KATKI_PAY_DAGITIM_TIP"));
					birKampKnlTx.setKatkiPayDagitimSekli(iMap.getString(tableName, i, "KATKI_PAY_DAGITIM_SEKLI"));
					birKampKnlTx.setKatkiPayDagitimOran(iMap.getBigDecimal(tableName, i, "KATKI_PAY_DAGITIM_ORAN"));
					birKampKnlTx.setKatkiPayDagitimTutar(iMap.getBigDecimal(tableName, i, "KATKI_PAY_DAGITIM_TUTAR"));

					if (iMap.getBoolean("HERSEY_DAHIL_EH")) {
						birKampKnlTx.setUstLimitNet(iMap.getBigDecimal(tableName, i, "NET_UST_LIMIT"));
					}

					session.save(birKampKnlTx);
					session.flush();
					
					// TEMINATLAR
					List<?> listTeminat = (List<?>) iMap.get(tableName, i, "TEMINAT_LIST");
					iMap.put("TEMINAT_LIST", listTeminat);
					String teminatTableName = "TEMINAT_LIST";
					if (listTeminat != null) {
						for (int j = 0; j < listTeminat.size(); j++) {

							BirKampTeminatIliskiTx birKampTeminatIliskiTx = new BirKampTeminatIliskiTx();
							BirKampTeminatIliskiTxId id = new BirKampTeminatIliskiTxId();

							id.setTxNo(iMap.getBigDecimal("TRX_NO"));
							id.setKampKnlKod(birKampKnlKod);
							id.setTeminatKod(iMap.getString(teminatTableName, j, "TEMINAT_KODU"));

							birKampTeminatIliskiTx.setId(id);
							birKampTeminatIliskiTx.setZorunlu(iMap.getString(teminatTableName, j, "ZORUNLU"));

							session.save(birKampTeminatIliskiTx);
							session.flush();
						}
					}
					
					// ILISKI SIGORTA
					List<?> listIliskiliSigorta = (List<?>) iMap.get(tableName, i, "ILISKILI_SIGORTA_URUN_LIST");
					iMap.put("ILISKILI_SIGORTA_LIST", listIliskiliSigorta);
					String iliskiSigortaTableName = "ILISKILI_SIGORTA_LIST";
					HashMap<String, String> controlMap = new HashMap<String, String>();
					if(listIliskiliSigorta != null){
						for (int j = 0; j < listIliskiliSigorta.size(); j++) {

							if (controlMap.get(iMap.getString(iliskiSigortaTableName, j, "URUN_NO")) != null) {

								iMap.put("HATA_NO", "2261");
								GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);

							}
							else {

								controlMap.put(iMap.getString(iliskiSigortaTableName, j, "URUN_NO"), "OK");

								BirKampanyaSigUrunTxId id = new BirKampanyaSigUrunTxId();
								id.setKampKnlKod(birKampKnlKod);
								id.setTxNo(iMap.getBigDecimal("TRX_NO"));
								id.setUrunNo(iMap.getBigDecimal(iliskiSigortaTableName, j, "URUN_NO"));
								BirKampanyaSigUrunTx urun = new BirKampanyaSigUrunTx();
								urun.setId(id);
								urun.setKampKod(iMap.getBigDecimal("KAMPANYA_KOD"));
								urun.setDagilimOrani(iMap.getBigDecimal(iliskiSigortaTableName, j, "DAGILIM_ORANI"));
								urun.setSegment(iMap.getString(iliskiSigortaTableName, j, "SEGMENT"));
								if (iMap.getBoolean(iliskiSigortaTableName, j, "SILINECEK_MI")) {
									urun.setSilinecekMi("E");
								}
								else {
									urun.setSilinecekMi("H");
								}
								session.save(urun);
							}

						}
						session.flush();
					}					
					
					// SIGORTA_URUN

					List<?> listSigortaUrun = (List<?>) iMap.get(tableName, i, "SIGORTA_URUN_LIST");
					iMap.put("SIGORTA_URUN_LIST", listSigortaUrun);
					String sigortaTableName = "SIGORTA_URUN_LIST";
					if (listSigortaUrun != null) {
						Set siraNolar = new HashSet();
						for (int j = 0; j < listSigortaUrun.size(); j++) {
							int size = siraNolar.size();
							if (iMap.getString(sigortaTableName, j, "SIGORTA_URUN_NO") == null || iMap.getString(sigortaTableName, j, "SIGORTA_URUN_NO").length() == 0) {
								iMap.put("HATA_NO", new BigDecimal(330));
								iMap.put("P1", "Sigorta Sat�� �r�n No");
								GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
							}
							BirKampSigortaSatisTx birKampSigortaSatisTx = new BirKampSigortaSatisTx();
							BirKampSigortaSatisTxId id = new BirKampSigortaSatisTxId();
							id.setTxNo(iMap.getBigDecimal("TRX_NO"));
							id.setKampKnlKod(birKampKnlKod);
							id.setSigortaUrunNo(iMap.getBigDecimal(sigortaTableName, j, "SIGORTA_URUN_NO"));
							birKampSigortaSatisTx.setSiraNo(iMap.getBigDecimal(sigortaTableName, j, "SIGORTA_SIRA_NO"));
							siraNolar.add(iMap.getBigDecimal(sigortaTableName, j, "SIGORTA_SIRA_NO"));
							birKampSigortaSatisTx.setId(id);

							if (size == siraNolar.size()) {
								GMMap t = new GMMap();
								t.put("HATA_NO", 660);
								t.put("P1", "Ayn� s�ra no'lu iki �r�n girilemez.");
								return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", t);
							}

							session.save(birKampSigortaSatisTx);
							session.flush();

						}
					}					
				}
			// Bloke
			String blokeTable = "BLOKE";
			List<?> blokeList = (List<?>) iMap.get("BLOKE");
			if (blokeList != null) {
				for (int i = 0; i < blokeList.size(); i++) {
					BirKampBlokeTx birKampBlokeTx = new BirKampBlokeTx();
					BirKampBlokeTxId birKampBlokeTxId = new BirKampBlokeTxId();

					birKampBlokeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birKampBlokeTxId.setKampKod(iMap.getBigDecimal("KAMPANYA_KOD"));
					birKampBlokeTxId.setBlokeGun(iMap.getString(blokeTable, i, "BLOKE_GUN"));

					birKampBlokeTx.setId(birKampBlokeTxId);
					birKampBlokeTx.setBlokeOrani(iMap.getBigDecimal(blokeTable, i, "BLOKE_ORAN"));
					birKampBlokeTx.setBlokeTutari(iMap.getBigDecimal(blokeTable, i, "BLOKE_TUTAR"));
					birKampBlokeTx.setBlokeFaizOrani(iMap.getBigDecimal(blokeTable, i, "BLOKE_FAIZ_ORAN"));

					session.save(birKampBlokeTx);
				}
				session.flush();
			}
			
			/** Risk urun **/
			String riskUrunTable = "RISKLI_URUN";
			List<?> riskliUrunList = (List<?>) iMap.get(riskUrunTable);
			if (riskliUrunList != null && riskliUrunList.size() > 0) {
				BirKampRiskUrunTx riskliUrun = null;
				BirKampRiskUrunTxId riskliUrunId = null;
				for (int i = 0; i < iMap.getSize(riskUrunTable); i++) {
					riskliUrun = new BirKampRiskUrunTx();
					riskliUrunId = new BirKampRiskUrunTxId();

					riskliUrunId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					riskliUrunId.setKampanyaKodu(iMap.getBigDecimal("KAMPANYA_KOD"));
					riskliUrunId.setUrunNo(iMap.getBigDecimal(riskUrunTable, i, "URUN_NO"));
					riskliUrun.setId(riskliUrunId);
					riskliUrun.setUrunAdi(iMap.getString(riskUrunTable, i, "URUN_ADI"));
					riskliUrun.setUstUrunAdi(iMap.getString(riskUrunTable, i, "UST_URUN_ADI"));
					session.save(riskliUrun);
				}
				session.flush();
			}

			iMap.put("TRX_NAME", "3112");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (NonUniqueObjectException e) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("MESSAGE_NO", new BigDecimal(330));
			myMap.put("P1", "�r�n No");
			throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}
		catch (ConstraintViolationException e) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("MESSAGE_NO", new BigDecimal(330));
			myMap.put("P1", "�r�n No");

			throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).get("ERROR_MESSAGE"));
		}
		catch (Exception e) {
			if (e.getCause() != null)
				throw new GMRuntimeException(0, e.getCause());
			else
				throw new GMRuntimeException(0, e);

		}
	}
	
	public static BirAzamiFaizOranPr findBirAzamiFaiz(GMMap iMap) {
		
		BigDecimal dkGrupKodu;
		if(iMap.getBoolean("TICARI_KREDI_EH"))
		{
			dkGrupKodu = new BigDecimal("1043");
		} else {
			String personelKredic = DALUtil.getResult("select pkg_parametre.Deger_Al_K_N('PERSONEL_KREDIC') from dual");
			if(personelKredic.equals(iMap.getString("KAMPANYA_KOD"))) {
				dkGrupKodu = new BigDecimal("1062");
			} else {
				dkGrupKodu = new BigDecimal("1042");
			}
		}
		BigDecimal krediTuru = iMap.getBigDecimal("KREDI_TURU");
		
		Session session = DAOSession.getSession("BNSPRDal");
		BirAzamiFaizOranPr birAzamiFaizOranPr = (BirAzamiFaizOranPr) session.createCriteria(BirAzamiFaizOranPr.class)
				.add(Restrictions.eq("id.dkGrupKodu", dkGrupKodu))
				.add(Restrictions.eq("id.krediTuru", krediTuru))
				.uniqueResult();
		session.flush();
		
		return birAzamiFaizOranPr;
	}
	
	public static boolean azamiFaizAsildi(BigDecimal bazFaiz, BigDecimal vade, BirAzamiFaizOranPr azamiFaizOranPr) {
		// azami faiz orani bulunamadiysa da hata verilmesi icin true donulur
		if(azamiFaizOranPr != null) {
			if(bazFaiz != null && vade != null)
			{
				if(vade.compareTo(VADE_12_AY) < 1)
				{
					if(bazFaiz.compareTo(azamiFaizOranPr.getVade012Ay()) == 1)
					{
						return true;
					}
				}
				else if(vade.compareTo(VADE_24_AY) < 1)
				{
					if(bazFaiz.compareTo(azamiFaizOranPr.getVade1224Ay()) == 1)
					{
						return true;
					}
				}
				else if(vade.compareTo(VADE_24_AY) == 1)
				{
					if(bazFaiz.compareTo(azamiFaizOranPr.getVade24AyUzeri()) == 1)
					{
						return true;
					}
				}
			}
			return false;
		} else {
			return true;
		}		
	}

	@GraymoundService("BNSPR_TRN3112_GET_FOR_UPDATE")
	public static GMMap trn3112GetForUpdate(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirKampanya birKampanya = (BirKampanya) session.get(BirKampanya.class, iMap.getBigDecimal("KAMPANYA_KOD"));

			GMMap oMap = new GMMap();

			oMap.put("KREDI_TURU", birKampanya.getKrdTurKod());
			oMap.put("DI_KREDI_TURU", LovHelper.diLov(birKampanya.getKrdTurKod(), "3112/LOV_KREDI_TURU", "ACIKLAMA"));
			oMap.put("KREDI_TIPI", birKampanya.getKrdTurAltKod());
			oMap.put("DI_KREDI_TIPI", LovHelper.diLov(birKampanya.getKrdTurAltKod(), birKampanya.getKrdTurKod(), "3112/LOV_KREDI_TIPI", "ACIKLAMA"));
			oMap.put("ALT_KREDI_TIPI", birKampanya.getKrdTurAltKod2());
			oMap.put("DI_ALT_KREDI_TIPI", LovHelper.diLov(birKampanya.getKrdTurAltKod2(), birKampanya.getKrdTurKod(), birKampanya.getKrdTurAltKod(), "3112/LOV_ALT_KREDI_TIP", "ACIKLAMA"));
			oMap.put("TARIH_ARALIK_BAS", birKampanya.getBasTarih());
			oMap.put("TARIH_ARALIK_BIT", birKampanya.getBitTarih());
			oMap.put("KAMPANYA_TIPI", birKampanya.getKamTipKod());
			oMap.put("PARANIN_ODENECEGI_YER", birKampanya.getParOdeYerKod());
			oMap.put("URUN_BAZINDA_MI", birKampanya.getUrunBazDegEh());
			oMap.put("MUSTERI_GRUBU", birKampanya.getMusTipKod());
			oMap.put("MUSTERIYE_OZEL_MI", birKampanya.getMusOzelEh());
			oMap.put("DURUM", birKampanya.getDrm());
			oMap.put("ACIKLAMA", birKampanya.getKampAck());
			oMap.put("WEEKEND_CARE", birKampanya.getWeekendCare());
			oMap.put("OTELEME_GUN_SAYISI", birKampanya.getOtelemeGunSayisi());
			oMap.put("FIRMA_HESAP_NO", birKampanya.getFirmaHesapNo());
			// oMap.put("FAIZ_ODEME_SEKLI", birKampanya.getFarkFaiziOdemeSekli());
			String faizOdemeSekli = birKampanya.getFarkFaiziOdemeSekli();
			oMap.put("F_PESIN", false);
			oMap.put("F_ILK_TAKSITTE_AL", false);
			oMap.put("F_TAKSITLERE_DAGIT", false);
			oMap.put("F_HIC_ALMA", false);
			if (faizOdemeSekli.charAt(0) == '1')
				oMap.put("F_PESIN", true);
			if (faizOdemeSekli.charAt(1) == '1')
				oMap.put("F_ILK_TAKSITTE_AL", true);
			if (faizOdemeSekli.charAt(2) == '1')
				oMap.put("F_TAKSITLERE_DAGIT", true);
			if (faizOdemeSekli.charAt(3) == '1')
				oMap.put("F_HIC_ALMA", true);
			oMap.put("KRD_TUTAR_DAGITIM", birKampanya.getKrdTutarDagitimTip());
			oMap.put("KRD_TUTAR_DAGITIM_ORAN", birKampanya.getKrdTutarDagitimOran());
			oMap.put("KOMISYONLU_DAGITIM", birKampanya.getKomisyonluDagitimEh());
			oMap.put("TAKSIT_GUNU_DISI_ARA_ODEME", birKampanya.getTaksitGunuDisiAraOdemeEh());
			oMap.put("KUL_BLOKE_KODU", birKampanya.getKulBlokeKodu());
			oMap.put("ODEME_GRUBU", birKampanya.getOdmGrpNo());

			String hersey_dahil_eh = birKampanya.getHerseyDahilEh();
			if ("E".equals(hersey_dahil_eh)) {
				oMap.put("HERSEY_DAHIL_EH", true);
			}
			else {
				oMap.put("HERSEY_DAHIL_EH", false);
			}

			String yeniden_yapilandirma = birKampanya.getYenidenYapilandirma();
			if ("E".equals(yeniden_yapilandirma)) {
				oMap.put("YENIDEN_YAPILANDIRMA", true);
			}
			else {
				oMap.put("YENIDEN_YAPILANDIRMA", false);
			}

			oMap.put("FINANSMAN_TURU", birKampanya.getFinansmanTuru());
			oMap.put("VALOR_OTE_GUN", birKampanya.getValorOteGun());

			iMap.put("KREDI_TURU", birKampanya.getKrdTurKod());
			
			String on_odemeli_eh = birKampanya.getOnOdemeliEh();
			if ("E".equals(on_odemeli_eh)) {
				oMap.put("ON_ODEMELI_EH", true);
			}
			else {
				oMap.put("ON_ODEMELI_EH", false);
			}
			
			String geri_cekme_eh = birKampanya.getGeriCekmeEh();
			if ("E".equals(geri_cekme_eh)) {
				oMap.put("GERI_CEKME_EH", true);
			}
			else {
				oMap.put("GERI_CEKME_EH", false);
			}
			
			/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
			String ticari_kredi_eh = birKampanya.getTicariKrediEh();
			if ("E".equals(ticari_kredi_eh)) {
				oMap.put("TICARI_KREDI_EH", true);
			}
			else {
				oMap.put("TICARI_KREDI_EH", false);
			}
			oMap.put("EK_PAKET", birKampanya.getEkPaketKod());
			oMap.put("FAIZSIZ_SURE", birKampanya.getFaizsizSure());
			oMap.put("BIRLESTIRME_EH", GuimlUtil.convertToCheckBoxSelected(birKampanya.getBirlestirmeEh()));
			oMap.put("GORME_ENGELLI_EH", GuimlUtil.convertToCheckBoxSelected(birKampanya.getGormeEngelliEh()));
			oMap.put("BORC_TRANSFERI_EH", GuimlUtil.convertToCheckBoxSelected(birKampanya.getBorcTransferiEh()));
			oMap.put("UCUNCU_SAHIS_EH", GuimlUtil.convertToCheckBoxSelected(birKampanya.getUcuncuSahisEh()));
			oMap.put("PTT_ICI_BIRLESTIRME_EH", GuimlUtil.convertToCheckBoxSelected(birKampanya.getPttIciBirlestirmeEh()));
			
			oMap.putAll(getForUpdateMeslekUrunTables(iMap));
			oMap.putAll(getForUpdateBlokeList(iMap));

//			// ILISKILI SIGORTA
//			conn = DALUtil.getGMConnection();
//			stmt = conn.prepareCall("{? = call PKG_TRN3112.getForUpdateSigortaUrunTable(?)}");
//			int i = 1;
//			stmt.registerOutParameter(i++, -10);
//			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMP_KNL_KOD"));
//			stmt.execute();
//			rSet = (ResultSet) stmt.getObject(1);
//			oMap.putAll(DALUtil.rSetResults(rSet, "ILISKI_SIGORTA_TABLE"));

			/** Riskli urun **/
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3112.getForUpdateRiskliUrunTable(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAMPANYA_KOD"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "RISKLI_URUN"));			

			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3112_TEMINAT_KOPYALA")
	public static GMMap teminatKopyala(GMMap iMap) {

		try {
			String tableName = "URUN";
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				GMMap tempMap = new GMMap();
				for (int k = 0; k < iMap.getSize("SELECTED_TEMINAT"); k++) {
					tempMap.put("SELECTED_TEMINAT", k, "TEMINAT_KODU", iMap.get("SELECTED_TEMINAT", k, "TEMINAT_KODU"));
					tempMap.put("SELECTED_TEMINAT", k, "TEMINAT_ADI", iMap.get("SELECTED_TEMINAT", k, "TEMINAT_ADI"));
					tempMap.put("SELECTED_TEMINAT", k, "ZORUNLU", iMap.get("SELECTED_TEMINAT", k, "ZORUNLU"));
				}

				iMap.put(tableName, i, "TEMINAT_LIST", tempMap.get("SELECTED_TEMINAT"));
			}
			return iMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}

	}

	@GraymoundService("BNSPR_TRN3112_SIGORTA_URUN_KOPYALA")
	public static GMMap sigortaUrunKopyala(GMMap iMap) {

		try {
			String tableName = "URUN";
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				GMMap sigortaMap = new GMMap();
				for (int k = 0; k < iMap.getSize("SELECTED_SIGORTA_URUN"); k++) {
					sigortaMap.put("SELECTED_SIGORTA_URUN", k, "SIGORTA_URUN_NO", iMap.get("SELECTED_SIGORTA_URUN", k, "SIGORTA_URUN_NO"));
					sigortaMap.put("SELECTED_SIGORTA_URUN", k, "SIGORTA_URUN_AD", iMap.get("SELECTED_SIGORTA_URUN", k, "SIGORTA_URUN_AD"));
					sigortaMap.put("SELECTED_SIGORTA_URUN", k, "SIGORTA_SIRA_NO", iMap.get("SELECTED_SIGORTA_URUN", k, "SIGORTA_SIRA_NO"));
				}

				iMap.put(tableName, i, "SIGORTA_URUN_LIST", sigortaMap.get("SELECTED_SIGORTA_URUN"));
			}
			return iMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}

	}

	@GraymoundService("BNSPR_TRN3112_URUN_KOPYALA")
	public static GMMap urunKopyala(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			GMMap tempMap = new GMMap();
			GMMap sigortaMap = new GMMap();

			String tableName = "URUN";

			int selected = iMap.getInt("SELECTED_ROW");
			int size = iMap.getSize(tableName);

			oMap.put(tableName, iMap.get(tableName));

			oMap.put(tableName, size, "MARKA", iMap.get(tableName, selected, "MARKA"));
			oMap.put(tableName, size, "DI_MODEL", iMap.get(tableName, selected, "DI_MODEL"));
			oMap.put(tableName, size, "MODEL", iMap.get(tableName, selected, "MODEL"));
			oMap.put(tableName, size, "MODEL_YIL", iMap.get(tableName, selected, "MODEL_YIL"));
			oMap.put(tableName, size, "KANAL_KODU", iMap.get(tableName, selected, "KANAL_KODU"));
			oMap.put(tableName, size, "KANALDAKI_ADI", iMap.get(tableName, selected, "KANALDAKI_ADI"));
			oMap.put(tableName, size, "DOVIZ_CINSI", iMap.get(tableName, selected, "DOVIZ_CINSI"));
			oMap.put(tableName, size, "MIN_VADE", iMap.get(tableName, selected, "MIN_VADE"));
			oMap.put(tableName, size, "MAX_VADE", iMap.get(tableName, selected, "MAX_VADE"));
			oMap.put(tableName, size, "ALT_LIMIT", iMap.get(tableName, selected, "ALT_LIMIT"));
			oMap.put(tableName, size, "UST_LIMIT", iMap.get(tableName, selected, "UST_LIMIT"));
			oMap.put(tableName, size, "BAZ_FAIZ", iMap.get(tableName, selected, "BAZ_FAIZ"));
			oMap.put(tableName, size, "SABIT_SOZLESME_FAIZI_EH", iMap.get(tableName, selected, "SABIT_SOZLESME_FAIZI_EH"));
			oMap.put(tableName, size, "SOZLESME_FAIZI", iMap.get(tableName, selected, "SOZLESME_FAIZI"));
			oMap.put(tableName, size, "SOZLESME_FAIZI_TEMP", iMap.get(tableName, selected, "SOZLESME_FAIZI_TEMP"));
			// oMap.put(tableName, size, "DI_ODEME_GRUBU",iMap.get(tableName,selected,"DI_ODEME_GRUBU"));
			// oMap.put(tableName, size, "ODEME_GRUBU",iMap.get(tableName,selected,"ODEME_GRUBU"));
			oMap.put(tableName, size, "DOSYA_MASRAF_TIP", iMap.get(tableName, selected, "DOSYA_MASRAF_TIP"));
			oMap.put(tableName, size, "MIN_DOSYA_MASRAFI", iMap.get(tableName, selected, "MIN_DOSYA_MASRAFI"));
			oMap.put(tableName, size, "MAX_DOSYA_MASRAFI", iMap.get(tableName, selected, "MAX_DOSYA_MASRAFI"));
			oMap.put(tableName, size, "DOSYA_MASRAF_ORAN", iMap.get(tableName, selected, "DOSYA_MASRAF_ORAN"));
			oMap.put(tableName, size, "INTERNET_EH", iMap.get(tableName, selected, "INTERNET_EH"));
			oMap.put(tableName, size, "KATKI_PAYI_TIPI", iMap.get(tableName, selected, "KATKI_PAYI_TIPI"));
			oMap.put(tableName, size, "KATKI_PAYI_KIMDEN", iMap.get(tableName, selected, "KATKI_PAYI_KIMDEN"));
			oMap.put(tableName, size, "MIN_KATKI_PAYI", iMap.get(tableName, selected, "MIN_KATKI_PAYI"));
			oMap.put(tableName, size, "MAX_KATKI_PAYI", iMap.get(tableName, selected, "MAX_KATKI_PAYI"));
			oMap.put(tableName, size, "KATKI_PAYI_ORAN", iMap.get(tableName, selected, "KATKI_PAYI_ORAN"));

			oMap.put(tableName, size, "KATKI_PAY_DAGITIM_TIP", iMap.get(tableName, selected, "KATKI_PAY_DAGITIM_TIP"));
			oMap.put(tableName, size, "KATKI_PAY_DAGITIM_SEKLI", iMap.get(tableName, selected, "KATKI_PAY_DAGITIM_SEKLI"));
			oMap.put(tableName, size, "KATKI_PAY_DAGITIM_ORAN", iMap.get(tableName, selected, "KATKI_PAY_DAGITIM_ORAN"));
			oMap.put(tableName, size, "KATKI_PAY_DAGITIM_TUTAR", iMap.get(tableName, selected, "KATKI_PAY_DAGITIM_TUTAR"));
			oMap.put(tableName, size, "NET_UST_LIMIT", iMap.get(tableName, selected, "NET_UST_LIMIT"));

			oMap.put("TEMINAT_LIST", iMap.get(tableName, selected, "TEMINAT_LIST"));
			for (int k = 0; k < oMap.getSize("TEMINAT_LIST"); k++) {
				tempMap.put("TEMINAT_LIST", k, "TEMINAT_KODU", oMap.get("TEMINAT_LIST", k, "TEMINAT_KODU"));
				tempMap.put("TEMINAT_LIST", k, "TEMINAT_ADI", oMap.get("TEMINAT_LIST", k, "TEMINAT_ADI"));
				tempMap.put("TEMINAT_LIST", k, "ZORUNLU", oMap.get("TEMINAT_LIST", k, "ZORUNLU"));
			}
			oMap.put(tableName, size, "TEMINAT_LIST", tempMap.get("TEMINAT_LIST"));

			oMap.put("SIGORTA_URUN_LIST", iMap.get(tableName, selected, "SIGORTA_URUN_LIST"));
			for (int k = 0; k < oMap.getSize("SIGORTA_URUN_LIST"); k++) {
				sigortaMap.put("SIGORTA_URUN_LIST", k, "SIGORTA_URUN_NO", oMap.get("SIGORTA_URUN_LIST", k, "SIGORTA_URUN_NO"));
				sigortaMap.put("SIGORTA_URUN_LIST", k, "SIGORTA_URUN_AD", oMap.get("SIGORTA_URUN_LIST", k, "SIGORTA_URUN_AD"));
			}
			oMap.put(tableName, size, "SIGORTA_URUN_LIST", sigortaMap.get("SIGORTA_URUN_LIST"));

			oMap.put("LAST_ROW", size);
			return oMap;
		}
		catch (Exception e) {
			System.out.println("asd");
			throw new GMRuntimeException(0, e);
		}

	}

	@GraymoundService("BNSPR_TRN3112_EXCELDEN_YUKLE")
	public static GMMap exceldenYukle(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("FILE")));
			Sheet sheet = workbook.getSheet(0);
			int colIndex, rowIndex;
			for (int i = 1; i < sheet.getRows(); i++) {
				colIndex = 0;
				rowIndex = i - 1;
				// System.out.println("Cell : "+sheet.getCell(6,i).getContents());
				oMap.put("URUN", rowIndex, "MARKA", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "MODEL", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "MODEL_YIL", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "KANAL_KODU", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "KANALDAKI_ADI", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "DOVIZ_CINSI", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "MIN_VADE", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "MAX_VADE", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "ALT_LIMIT", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "UST_LIMIT", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "BAZ_FAIZ", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "SABIT_SOZLESME_FAIZI_EH", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "SOZLESME_FAIZI", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "SOZLESME_FAIZI_TEMP", oMap.get("URUN", rowIndex, "SOZLESME_FAIZI"));
				// oMap.put("URUN",rowIndex,"ODEME_GRUBU",sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "DOSYA_MASRAF_TIP", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "MIN_DOSYA_MASRAFI", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "MAX_DOSYA_MASRAFI", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "DOSYA_MASRAF_ORAN", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "INTERNET_EH", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "KATKI_PAYI_TIPI", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "KATKI_PAYI_KIMDEN", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "MIN_KATKI_PAYI", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "MAX_KATKI_PAYI", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "KATKI_PAYI_ORAN", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));

				oMap.put("URUN", rowIndex, "KATKI_PAY_DAGITIM_TIP", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "KATKI_PAY_DAGITIM_SEKLI", sheet.getCell(colIndex++, i).getContents());
				oMap.put("URUN", rowIndex, "KATKI_PAY_DAGITIM_ORAN", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "KATKI_PAY_DAGITIM_TUTAR", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
				oMap.put("URUN", rowIndex, "NET_UST_LIMIT", parseBigDecimal(sheet.getCell(colIndex++, i).getContents()));
			}
			workbook.close();
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}

	}

	private static BigDecimal parseBigDecimal(String str) {
		try {
			str = str.replaceAll("\\.", "");
			str = str.replaceAll(",", ".");
			return new BigDecimal(str);
		}
		catch (Exception e) {
			return null;
		}
	}

	public static GMMap getForUpdateMeslekUrunTables(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;
		ResultSet rSet4 = null;
		GMMap oMap = new GMMap();
		String tableName;
		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3112.getForUpdateMeslekUrunTable(?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("KAMPANYA_KOD"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.execute();

			// meslek
			rSet = (ResultSet) stmt.getObject(2);
			tableName = "MESLEK_KODLARI";
			int row = 0;
			while (rSet.next()) {

				oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxSelected(rSet.getString(1)));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(2));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(3));

				row++;
			}
			GMServerDatasource.close(rSet);
			

			// urun
			rSet = (ResultSet) stmt.getObject(3);
			
			tableName = "URUN";
			row = 0;
			while (rSet.next()) {

				int i = 1;

				oMap.put(tableName, row, "MARKA", rSet.getString(i++));
				BigDecimal model = rSet.getBigDecimal(i++);
				oMap.put(tableName, row, "DI_MODEL", LovHelper.diLov(model, iMap.getBigDecimal("KREDI_TURU"), rSet.getString("MARKA_KOD"), "3112/LOV_MARKA_MODEL", "ACIKLAMA"));
				oMap.put(tableName, row, "MODEL", model);
				oMap.put(tableName, row, "MODEL_YIL", rSet.getBigDecimal(i++));
				String kanalKod = rSet.getString(i++);
				oMap.put(tableName, row, "KANAL_KODU", kanalKod);
				oMap.put(tableName, row, "KANALDAKI_ADI", rSet.getString(i++));
				String dovizKod = rSet.getString(i++);
				oMap.put(tableName, row, "DOVIZ_CINSI", dovizKod);
				oMap.put(tableName, row, "MIN_VADE", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_VADE", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "ALT_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "UST_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "BAZ_FAIZ", rSet.getBigDecimal(i++));
				String sabitSozlesmeFaizi = rSet.getString(i++);
				oMap.put(tableName, row, "SABIT_SOZLESME_FAIZI_EH", sabitSozlesmeFaizi == null ? "X" : sabitSozlesmeFaizi);
				oMap.put(tableName, row, "SOZLESME_FAIZI_TEMP", rSet.getBigDecimal(i));
				oMap.put(tableName, row, "SOZLESME_FAIZI", rSet.getBigDecimal(i++));
				// BigDecimal odemeGrubu = rSet.getBigDecimal(i++);
				// oMap.put(tableName, row, "ODEME_GRUBU", odemeGrubu);
				// oMap.put(tableName, row, "DI_ODEME_GRUBU", LovHelper.diLov(odemeGrubu, "3112/LOV_ODEME_GRUBU", "ACIKLAMA"));
				oMap.put(tableName, row, "DOSYA_MASRAF_TIP", rSet.getString(i++));
				oMap.put(tableName, row, "MIN_DOSYA_MASRAFI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_DOSYA_MASRAFI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "DOSYA_MASRAF_ORAN", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "INTERNET_EH", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAYI_KIMDEN", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAYI_TIPI", rSet.getString(i++));
				oMap.put(tableName, row, "MIN_KATKI_PAYI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_KATKI_PAYI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "KATKI_PAYI_ORAN", rSet.getBigDecimal(i++));
				BigDecimal kampKnlKod = rSet.getBigDecimal(i++);
				oMap.put(tableName, row, "KOD", kampKnlKod);
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_TIP", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_SEKLI", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_ORAN", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_TUTAR", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "NET_UST_LIMIT", rSet.getBigDecimal(i++));

				iMap.put("KANAL_KOD", kanalKod);
				iMap.put("DOVIZ_KOD", dovizKod);
				iMap.put("KAMP_KNL_KOD", kampKnlKod);

				// getForUpdateDetailsTable				
				stmt2 = conn.prepareCall("{call PKG_TRN3112.getForUpdateDetailsTable(?,?,?,?,?) }");

				stmt2.setBigDecimal(1, iMap.getBigDecimal("KAMP_KNL_KOD"));
				stmt2.setString(2, iMap.getString("KANAL_KOD"));
				stmt2.registerOutParameter(3, -10);
				stmt2.registerOutParameter(4, -10);
				stmt2.registerOutParameter(5, -10);

				stmt2.execute();

				// teminat list
				rSet2 = (ResultSet) stmt2.getObject(3);
				ArrayList<HashMap<String, Object>> temList = new ArrayList<HashMap<String, Object>>();

				while (rSet2.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("TEMINAT_KODU", rSet2.getString(y++));
					rowData.put("TEMINAT_ADI", rSet2.getString(y++));
					rowData.put("ZORUNLU", rSet2.getString(y++));

					temList.add(rowData);
				}
				oMap.put(tableName, row, "TEMINAT_LIST", temList);
				GMServerDatasource.close(rSet2);

				// sigorta �r�n list
				rSet3 = (ResultSet) stmt2.getObject(4);
				ArrayList<HashMap<String, Object>> sigortaList = new ArrayList<HashMap<String, Object>>();

				while (rSet3.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("SIGORTA_URUN_NO", rSet3.getBigDecimal(y++));
					rowData.put("SIGORTA_URUN_AD", rSet3.getString(y++));
					rowData.put("SIGORTA_SIRA_NO", rSet3.getString(y++));

					sigortaList.add(rowData);
				}
				oMap.put(tableName, row, "SIGORTA_URUN_LIST", sigortaList);
				GMServerDatasource.close(rSet3);
				
				// iliskili sigorta urun list
				rSet4 = (ResultSet) stmt2.getObject(5);
				ArrayList<HashMap<String, Object>> iliskiliSigortaUrunList = new ArrayList<HashMap<String, Object>>();

				while (rSet4.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("URUN_NO", rSet4.getBigDecimal(y++));
					rowData.put("DAGILIM_ORANI", rSet4.getString(y++));
					rowData.put("SEGMENT", rSet4.getString(y++));

					iliskiliSigortaUrunList.add(rowData);
				}
				oMap.put(tableName, row, "ILISKILI_SIGORTA_URUN_LIST", iliskiliSigortaUrunList);
				GMServerDatasource.close(rSet4);
				
				GMServerDatasource.close(stmt2);

				row++;
			}

			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(rSet4);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3112_GET_URUN_GERI")
	public static GMMap getForUpdateUrunTablesGeri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;
		GMMap oMap = new GMMap();
		String tableName;
		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3112.getForUpdateUrunTableGeri(?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(2, -10);
			stmt.execute();

			// urun
			rSet = (ResultSet) stmt.getObject(2);
			tableName = "URUN";
			int row = 0;
			while (rSet.next()) {

				int i = 1;

				oMap.put(tableName, row, "MARKA", rSet.getString(i++));
				oMap.put(tableName, row, "MODEL", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "DI_MODEL", rSet.getString(i++));
				oMap.put(tableName, row, "MODEL_YIL", rSet.getBigDecimal(i++));
				String kanalKod = rSet.getString(i++);
				oMap.put(tableName, row, "KANAL_KODU", kanalKod);
				oMap.put(tableName, row, "KANALDAKI_ADI", rSet.getString(i++));
				String dovizKod = rSet.getString(i++);
				oMap.put(tableName, row, "DOVIZ_CINSI", dovizKod);
				oMap.put(tableName, row, "MIN_VADE", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_VADE", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "ALT_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "UST_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "BAZ_FAIZ", rSet.getBigDecimal(i++));
				String sabitSozlesmeFaizi = rSet.getString(i++);
				oMap.put(tableName, row, "SABIT_SOZLESME_FAIZI_EH", sabitSozlesmeFaizi == null ? "X" : sabitSozlesmeFaizi);
				oMap.put(tableName, row, "SOZLESME_FAIZI_TEMP", rSet.getBigDecimal(i));
				oMap.put(tableName, row, "SOZLESME_FAIZI", rSet.getBigDecimal(i++));
				// BigDecimal odemeGrubu = rSet.getBigDecimal(i++);
				// oMap.put(tableName, row, "ODEME_GRUBU", odemeGrubu);
				// oMap.put(tableName, row, "DI_ODEME_GRUBU", LovHelper.diLov(odemeGrubu, "3112/LOV_ODEME_GRUBU", "ACIKLAMA"));
				oMap.put(tableName, row, "DOSYA_MASRAF_TIP", rSet.getString(i++));
				oMap.put(tableName, row, "MIN_DOSYA_MASRAFI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_DOSYA_MASRAFI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "DOSYA_MASRAF_ORAN", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "INTERNET_EH", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAYI_KIMDEN", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAYI_TIPI", rSet.getString(i++));
				oMap.put(tableName, row, "MIN_KATKI_PAYI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_KATKI_PAYI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "KATKI_PAYI_ORAN", rSet.getBigDecimal(i++));
				BigDecimal kampKnlKod = rSet.getBigDecimal(i++);
				oMap.put(tableName, row, "KOD", kampKnlKod);
				oMap.put(tableName, row, "SIL", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_TIP", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_SEKLI", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_ORAN", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_TUTAR", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "NET_UST_LIMIT", rSet.getBigDecimal(i++));

				iMap.put("KANAL_KOD", kanalKod);
				iMap.put("DOVIZ_KOD", dovizKod);
				iMap.put("KAMP_KNL_KOD", kampKnlKod);

				// getForUpdateDetailsTable
				stmt = conn.prepareCall("{call PKG_TRN3112.getForUpdateDetailsTable(?,?,?,?) }");

				stmt.setBigDecimal(1, iMap.getBigDecimal("KAMP_KNL_KOD"));
				stmt.setString(2, iMap.getString("KANAL_KODU"));
				stmt.registerOutParameter(3, -10);
				stmt.registerOutParameter(4, -10);

				stmt.execute();

				// teminat list
				rSet2 = (ResultSet) stmt.getObject(3);
				ArrayList<HashMap<String, Object>> temList = new ArrayList<HashMap<String, Object>>();

				while (rSet2.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("TEMINAT_KODU", rSet2.getString(y++));
					rowData.put("TEMINAT_ADI", rSet2.getString(y++));
					rowData.put("ZORUNLU", rSet2.getString(y++));

					temList.add(rowData);
				}
				oMap.put(tableName, row, "TEMINAT_LIST", temList);
				GMServerDatasource.close(rSet2);

				// sigorta �r�n list
				rSet3 = (ResultSet) stmt.getObject(4);
				ArrayList<HashMap<String, Object>> sigortaList = new ArrayList<HashMap<String, Object>>();

				while (rSet3.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("SIGORTA_URUN_NO", rSet3.getBigDecimal(y++));
					rowData.put("SIGORTA_URUN_AD", rSet3.getString(y++));

					sigortaList.add(rowData);
				}
				oMap.put(tableName, row, "SIGORTA_URUN_LIST", sigortaList);
				GMServerDatasource.close(rSet3);
				row++;
			}

			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3112_GET_INFO")
	public static GMMap trn3112GetInfo(GMMap iMap) {

		try {

			GMMap oMap = new GMMap();

			setBirKampanyaMap(iMap.getBigDecimal("TRX_NO"), oMap);

			getTrxNoMeslekUrunTables("", iMap.getBigDecimal("TRX_NO"), oMap.getBigDecimal("KREDI_TURU"), oMap);

			Session session = DAOSession.getSession("BNSPRDal");

			String iliskiSigortaTable = "ILISKI_SIGORTA_TABLE";

			List<BirKampanyaSigUrunTx> urunList = session.createCriteria(BirKampanyaSigUrunTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			getIliskiSigortaTable(iliskiSigortaTable, urunList, oMap);

			List<BirKampRiskUrunTx> riskUrunList = session.createCriteria(BirKampRiskUrunTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			getRiskUrunTable("RISKLI_URUN", riskUrunList, oMap);

			GMMap oldMap = new GMMap();
			// Renklendirme
			if ("ISLEM_GORUNTULE".equals(iMap.getString("ACTION"))) {
				GMMap i2Map = new GMMap();
				i2Map.put("TRX_NO", iMap.get("TRX_NO"));
				i2Map.put("KAMPANYA_KOD", oMap.get("KAMPANYA_KOD"));
				BigDecimal oldTxNo = GMServiceExecuter.call("BNSPR_TRN3112_GET_ONCEKI_TX_NO", i2Map).getBigDecimal("OLD_TRX_NO");

				if (oldTxNo != null)
					setBirKampanyaMap(oldTxNo, oldMap);

				oMap.putAll(BeanSetProperties.mapDifference(oldMap, oMap));

				// Tablolar i�in renklendirme
				getTrxNoMeslekUrunTables("OLD_", oldTxNo, oldMap.getBigDecimal("KREDI_TURU"), oMap);

				String oldIliskiSigortaTable = "OLD_ILISKI_SIGORTA_TABLE";

				List<BirKampanyaSigUrunTx> oldUrunList = session.createCriteria(BirKampanyaSigUrunTx.class).add(Restrictions.eq("id.txNo", oldTxNo)).list();
				getIliskiSigortaTable(oldIliskiSigortaTable, oldUrunList, oMap);

				List<BirKampRiskUrunTx> oldRiskUrunList = session.createCriteria(BirKampRiskUrunTx.class).add(Restrictions.eq("id.txNo", oldTxNo)).list();
				getRiskUrunTable("OLD_RISKLI_URUN", oldRiskUrunList, oMap);

				/** TX_NO, KOD, KAMP_KOD, KANAL_KOD, DOVIZ_KOD, MARKA_KOD, ALT_LIMIT, UST_LIMIT, MIN_VADE, MAX_VADE */
				// keyColumns.add("TRX_NO");
				
				oMap.put("RISKLI_URUN_COLOR_DATA", (BeanSetProperties.tableDifference((ArrayList<?>) oMap.get("OLD_RISKLI_URUN"), (ArrayList<?>) oMap.get("RISKLI_URUN"), "URUN_NO")).get("COLOR_DATA"));
				oMap.put("MESLEK_KODLARI_COLOR_DATA", (BeanSetProperties.tableDifference((ArrayList<?>) oMap.get("OLD_MESLEK_KODLARI"), (ArrayList<?>) oMap.get("MESLEK_KODLARI"), "KOD")).get("COLOR_DATA"));
				oMap.put("URUN_COLOR_DATA", (BeanSetProperties.tableDifference((ArrayList<?>) oMap.get("OLD_URUN"), (ArrayList<?>) oMap.get("URUN"), "KOD")).get("COLOR_DATA"));

				int i = 0;
				// ArrayList<String> keyColumn= new ArrayList<String>();
				// keyColumn.add("TEMINAT_KODU");
				// keyColumn.add("ZORUNLU");
				int oldUrunSize = oMap.getSize("OLD_URUN");
				while (i < oMap.getSize("URUN")) {
					oMap.put("URUN", i, "TEMINAT_LIST_COLOR_DATA", (BeanSetProperties.tableDifference(oldUrunSize > i ? (ArrayList<?>) oMap.get("OLD_URUN", i, "TEMINAT_LIST") : null, (ArrayList<?>) oMap.get("URUN", i, "TEMINAT_LIST"), "TEMINAT_KODU")).get("COLOR_DATA"));
					oMap.put("URUN", i, "SIGORTA_URUN_LIST_COLOR_DATA", (BeanSetProperties.tableDifference(oldUrunSize > i ? (ArrayList<?>) oMap.get("OLD_URUN", i, "SIGORTA_URUN_LIST") : null, (ArrayList<?>) oMap.get("URUN", i, "SIGORTA_URUN_LIST"), "SIGORTA_URUN_NO")).get("COLOR_DATA"));
					oMap.put("URUN", i, "ILISKILI_SIGORTA_URUN_LIST_COLOR_DATA", (BeanSetProperties.tableDifference(oldUrunSize > i ? (ArrayList<?>) oMap.get("OLD_URUN", i, "ILISKILI_SIGORTA_URUN_LIST") : null, (ArrayList<?>) oMap.get("URUN", i, "ILISKILI_SIGORTA_URUN_LIST"), "URUN_NO")).get("COLOR_DATA"));
					i++;
				}
			}
			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	@GraymoundService("BNSPR_TRN3112_GET_ONCEKI_TX_NO")
	public static GMMap getOncekiTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3112.onceki_txno_3112(?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("KAMPANYA_KOD"));
			stmt.execute();

			oMap.put("OLD_TRX_NO", stmt.getBigDecimal(1));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	private static void setBirKampanyaMap(BigDecimal txNo, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");

		BirKampanyaTx birKampanyaTx = (BirKampanyaTx) session.get(BirKampanyaTx.class, txNo);

		oMap.put("KAMPANYA_KOD", birKampanyaTx.getKod());
		oMap.put("KAMPANYA_ADI", birKampanyaTx.getAciklama());
		oMap.put("KREDI_TURU", birKampanyaTx.getKrdTurKod());
		oMap.put("DI_KREDI_TURU", LovHelper.diLov(birKampanyaTx.getKrdTurKod(), "3112/LOV_KREDI_TURU", "ACIKLAMA"));
		oMap.put("KREDI_TIPI", birKampanyaTx.getKrdTurAltKod());
		oMap.put("DI_KREDI_TIPI", LovHelper.diLov(birKampanyaTx.getKrdTurAltKod(), birKampanyaTx.getKrdTurKod(), "3112/LOV_KREDI_TIPI", "ACIKLAMA"));
		oMap.put("ALT_KREDI_TIPI", birKampanyaTx.getKrdTurAltKod2());
		oMap.put("DI_ALT_KREDI_TIPI", LovHelper.diLov(birKampanyaTx.getKrdTurAltKod2(), birKampanyaTx.getKrdTurKod(), birKampanyaTx.getKrdTurAltKod(), "3112/LOV_ALT_KREDI_TIP", "ACIKLAMA"));
		oMap.put("TARIH_ARALIK_BAS", birKampanyaTx.getBasTarih());
		oMap.put("TARIH_ARALIK_BIT", birKampanyaTx.getBitTarih());
		oMap.put("KAMPANYA_TIPI", birKampanyaTx.getKamTipKod());
		oMap.put("PARANIN_ODENECEGI_YER", birKampanyaTx.getParOdeYerKod());
		oMap.put("URUN_BAZINDA_MI", birKampanyaTx.getUrunBazDegEh());
		oMap.put("MUSTERI_GRUBU", birKampanyaTx.getMusTipKod());
		oMap.put("MUSTERIYE_OZEL_MI", birKampanyaTx.getMusOzelEh());
		oMap.put("DURUM", birKampanyaTx.getDrm());
		oMap.put("ACIKLAMA", birKampanyaTx.getKampAck());
		oMap.put("WEEKEND_CARE", birKampanyaTx.getWeekendCare());
		oMap.put("OTELEME_GUN_SAYISI", birKampanyaTx.getOtelemeGunSayisi());
		oMap.put("FIRMA_HESAP_NO", birKampanyaTx.getFirmaHesapNo());
		// oMap.put("FAIZ_ODEME_SEKLI", birKampanyaTx.getFarkFaiziOdemeSekli());
		String faizOdemeSekli = birKampanyaTx.getFarkFaiziOdemeSekli();
		oMap.put("F_PESIN", false);
		oMap.put("F_ILK_TAKSITTE_AL", false);
		oMap.put("F_TAKSITLERE_DAGIT", false);
		oMap.put("F_HIC_ALMA", false);

		if (faizOdemeSekli != null) {

			if (faizOdemeSekli.charAt(0) == '1')
				oMap.put("F_PESIN", true);
			if (faizOdemeSekli.charAt(1) == '1')
				oMap.put("F_ILK_TAKSITTE_AL", true);
			if (faizOdemeSekli.charAt(2) == '1')
				oMap.put("F_TAKSITLERE_DAGIT", true);
			if (faizOdemeSekli.charAt(3) == '1')
				oMap.put("F_HIC_ALMA", true);

		}

		oMap.put("KRD_TUTAR_DAGITIM", birKampanyaTx.getKrdTutarDagitimTip());
		oMap.put("KRD_TUTAR_DAGITIM_ORAN", birKampanyaTx.getKrdTutarDagitimOran());
		oMap.put("KOMISYONLU_DAGITIM", birKampanyaTx.getKomisyonluDagitimEh());
		oMap.put("TAKSIT_GUNU_DISI_ARA_ODEME", birKampanyaTx.getTaksitGunuDisiAraOdemeEh());
		oMap.put("KUL_BLOKE_KODU", birKampanyaTx.getKulBlokeKodu());
		oMap.put("ODEME_GRUBU", birKampanyaTx.getOdmGrpNo());
		oMap.put("FAIZSIZ_SURE", birKampanyaTx.getFaizsizSure());

		String hersey_dahil_eh = birKampanyaTx.getHerseyDahilEh();
		if ("E".equals(hersey_dahil_eh)) {
			oMap.put("HERSEY_DAHIL_EH", true);
		}
		else {
			oMap.put("HERSEY_DAHIL_EH", false);
		}

		String yeniden_yapilandirma = birKampanyaTx.getYenidenYapilandirma();
		if ("E".equals(yeniden_yapilandirma)) {
			oMap.put("YENIDEN_YAPILANDIRMA", true);
		}
		else {
			oMap.put("YENIDEN_YAPILANDIRMA", false);
		}
		oMap.put("FINANSMAN_TURU", birKampanyaTx.getFinansmanTuru());
		oMap.put("VALOR_OTE_GUN", birKampanyaTx.getValorOteGun());

		String on_odemeli_eh = birKampanyaTx.getOnOdemeliEh();
		if ("E".equals(on_odemeli_eh)) {
			oMap.put("ON_ODEMELI_EH", true);
		}
		else {
			oMap.put("ON_ODEMELI_EH", false);
		}
		
		String geri_cekme_eh = birKampanyaTx.getGeriCekmeEh();
		if ("E".equals(geri_cekme_eh)) {
			oMap.put("GERI_CEKME_EH", true);
		}
		else {
			oMap.put("GERI_CEKME_EH", false);
		}
		
		/** TY-6647 TY-Akustik bayi giri� ekranlar�n�n geli�tirilmesi */
		String ticari_kredi_eh = birKampanyaTx.getTicariKrediEh();
		if ("E".equals(ticari_kredi_eh)) {
			oMap.put("TICARI_KREDI_EH", true);
		}
		else {
			oMap.put("TICARI_KREDI_EH", false);
		}
		oMap.put("EK_PAKET", birKampanyaTx.getEkPaketKod());
		oMap.put("BIRLESTIRME_EH", GuimlUtil.convertToCheckBoxSelected(birKampanyaTx.getBirlestirmeEh()));
		oMap.put("GORME_ENGELLI_EH", GuimlUtil.convertToCheckBoxSelected(birKampanyaTx.getGormeEngelliEh()));
		oMap.put("BORC_TRANSFERI_EH", GuimlUtil.convertToCheckBoxSelected(birKampanyaTx.getBorcTransferiEh()));
		oMap.put("UCUNCU_SAHIS_EH", GuimlUtil.convertToCheckBoxSelected(birKampanyaTx.getUcuncuSahisEh()));
		oMap.put("PTT_ICI_BIRLESTIRME_EH", GuimlUtil.convertToCheckBoxSelected(birKampanyaTx.getPttIciBirlestirmeEh()));
	}

	@GraymoundService("BNSPR_TRN3112_KATKI_PAYI_DAGILIM_SIL")
	public static GMMap deleteKatkiPayiDagilim(GMMap iMap) {

		try {
			GMMap oMap = new GMMap();
			String tableName = "URUN";
			String nuLL = null;
			BigDecimal nulL = null;
			oMap.put(tableName, iMap.get(tableName));

			for (int i = 0; i < oMap.getSize(tableName); i++) {
				oMap.put(tableName, i, "KATKI_PAY_DAGITIM_TIP", nuLL);
				oMap.put(tableName, i, "KATKI_PAY_DAGITIM_SEKLI", nuLL);
				oMap.put(tableName, i, "KATKI_PAY_DAGITIM_ORAN", nulL);
				oMap.put(tableName, i, "KATKI_PAY_DAGITIM_TUTAR", nulL);
			}
			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	public static void getTrxNoMeslekUrunTables(String tablePrefix, BigDecimal txNo, BigDecimal krediTuru, GMMap oMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		ResultSet rSet3 = null;
		ResultSet rSet4 = null;
		String tableName;
		try {

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3112.getTrxNoMeslekUrunTable(?,?,?) }");
			stmt.setBigDecimal(1, txNo);
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.execute();

			// meslek
			rSet = (ResultSet) stmt.getObject(2);
			tableName = tablePrefix + "MESLEK_KODLARI";
			int row = 0;
			while (rSet.next()) {

				oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxSelected(rSet.getString(1)));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(2));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString(3));

				row++;
			}

			GMServerDatasource.close(rSet);
			// urun
			rSet = (ResultSet) stmt.getObject(3);
			tableName = tablePrefix + "URUN";
			row = 0;
			while (rSet.next()) {

				int i = 1;

				String marka = rSet.getString(i++);
				oMap.put(tableName, row, "MARKA", marka);
				BigDecimal model = rSet.getBigDecimal(i++);
				oMap.put(tableName, row, "DI_MODEL", LovHelper.diLov(model, krediTuru, marka, "3112/LOV_MARKA_MODEL", "ACIKLAMA"));
				oMap.put(tableName, row, "MODEL", model);
				oMap.put(tableName, row, "MODEL_YIL", rSet.getBigDecimal(i++));
				String kanalKod = rSet.getString(i++);
				oMap.put(tableName, row, "KANAL_KODU", kanalKod);
				oMap.put(tableName, row, "KANALDAKI_ADI", rSet.getString(i++));
				String dovizKod = rSet.getString(i++);
				oMap.put(tableName, row, "DOVIZ_CINSI", dovizKod);
				oMap.put(tableName, row, "MIN_VADE", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_VADE", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "ALT_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "UST_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "BAZ_FAIZ", rSet.getBigDecimal(i++));
				String sabitSozlesmeFaizi = rSet.getString(i++);
				oMap.put(tableName, row, "SABIT_SOZLESME_FAIZI_EH", sabitSozlesmeFaizi == null ? "X" : sabitSozlesmeFaizi);
				oMap.put(tableName, row, "SOZLESME_FAIZI_TEMP", rSet.getBigDecimal(i));
				oMap.put(tableName, row, "SOZLESME_FAIZI", rSet.getBigDecimal(i++));
				// BigDecimal odemeGrubu = rSet.getBigDecimal(i++);
				// oMap.put(tableName, row, "ODEME_GRUBU", odemeGrubu);
				// oMap.put(tableName, row, "DI_ODEME_GRUBU", LovHelper.diLov(odemeGrubu, "3112/LOV_ODEME_GRUBU", "ACIKLAMA"));
				oMap.put(tableName, row, "DOSYA_MASRAF_TIP", rSet.getString(i++));
				oMap.put(tableName, row, "MIN_DOSYA_MASRAFI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_DOSYA_MASRAFI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "DOSYA_MASRAF_ORAN", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "INTERNET_EH", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAYI_KIMDEN", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAYI_TIPI", rSet.getString(i++));
				oMap.put(tableName, row, "MIN_KATKI_PAYI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "MAX_KATKI_PAYI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "KATKI_PAYI_ORAN", rSet.getBigDecimal(i++));
				BigDecimal kampKnlKod = rSet.getBigDecimal(i++);
				oMap.put(tableName, row, "KOD", kampKnlKod);

				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_TIP", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_SEKLI", rSet.getString(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_ORAN", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "KATKI_PAY_DAGITIM_TUTAR", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "NET_UST_LIMIT", rSet.getBigDecimal(i++));
				oMap.put(tableName, row, "TRX_NO", txNo);

				stmt2 = conn.prepareCall("{call PKG_TRN3112.getTrxNoDetails(?,?,?,?,?,?) }");
				stmt2.setBigDecimal(1, kampKnlKod);
				stmt2.setBigDecimal(2, txNo);
				stmt2.setString(3, kanalKod);
				stmt2.registerOutParameter(4, -10);
				stmt2.registerOutParameter(5, -10);
				stmt2.registerOutParameter(6, -10);

				stmt2.execute();

				// teminat list
				rSet2 = (ResultSet) stmt2.getObject(4);
				ArrayList<HashMap<String, Object>> temList = new ArrayList<HashMap<String, Object>>();

				while (rSet2.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("TEMINAT_KODU", rSet2.getString(y++));
					rowData.put("TEMINAT_ADI", rSet2.getString(y++));
					rowData.put("ZORUNLU", rSet2.getString(y++));

					temList.add(rowData);
				}

				oMap.put(tableName, row, "TEMINAT_LIST", temList);
				GMServerDatasource.close(rSet2);

				// sigorta urun list
				rSet3 = (ResultSet) stmt2.getObject(5);
				ArrayList<HashMap<String, Object>> sigortaList = new ArrayList<HashMap<String, Object>>();

				while (rSet3.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("SIGORTA_URUN_NO", rSet3.getBigDecimal(y++));
					rowData.put("SIGORTA_URUN_AD", rSet3.getString(y++));
					rowData.put("SIGORTA_SIRA_NO", rSet3.getBigDecimal(y++));

					sigortaList.add(rowData);
				}

				oMap.put(tableName, row, "SIGORTA_URUN_LIST", sigortaList);
				GMServerDatasource.close(rSet3);
				
				// iliskili sigorta urun list
				rSet4 = (ResultSet) stmt2.getObject(6);
				ArrayList<HashMap<String, Object>> iliskiliSigortaUrunList = new ArrayList<HashMap<String, Object>>();

				while (rSet4.next()) {
					int y = 1;
					HashMap<String, Object> rowData = new HashMap<String, Object>();

					rowData.put("URUN_NO", rSet4.getBigDecimal(y++));
					rowData.put("DAGILIM_ORANI", rSet4.getString(y++));					

					iliskiliSigortaUrunList.add(rowData);
				}
				oMap.put(tableName, row, "ILISKILI_SIGORTA_URUN_LIST", iliskiliSigortaUrunList);
				GMServerDatasource.close(rSet4);
				
				GMServerDatasource.close(stmt2);

				row++;
			}

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet3);
			GMServerDatasource.close(rSet4);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}

	public static void getMusteriGrupKodlari(GMMap oMap, String listName) {
		oMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("LIST_NAME", listName);
		oMap.put("LIST_QUERY", "select kod,aciklama from v_ml_gnl_musteri_grup_kod_pr order by kod");
		DALUtil.fillComboBox(oMap);
	}

	public static GMMap getForUpdateBlokeList(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) session.createCriteria(BirKampBloke.class).add(Restrictions.eq("id.kampKod", iMap.getBigDecimal("KAMPANYA_KOD"))).list();
			GMMap oMap = new GMMap();
			String tableName = "BLOKE";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirKampBloke birKampBloke = (BirKampBloke) iterator.next();

				oMap.put(tableName, row, "BLOKE_GUN", birKampBloke.getId().getBlokeGun());
				oMap.put(tableName, row, "BLOKE_ORAN", birKampBloke.getBlokeOrani());
				oMap.put(tableName, row, "BLOKE_TUTAR", birKampBloke.getBlokeTutari());
				oMap.put(tableName, row, "BLOKE_FAIZ_ORAN", birKampBloke.getBlokeFaizOrani());

				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	public static GMMap getTrxNoBlokeList(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) session.createCriteria(BirKampBlokeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			GMMap oMap = new GMMap();
			String tableName = "BLOKE";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirKampBlokeTx birKampBlokeTx = (BirKampBlokeTx) iterator.next();

				oMap.put(tableName, row, "BLOKE_GUN", birKampBlokeTx.getId().getBlokeGun());
				oMap.put(tableName, row, "BLOKE_ORAN", birKampBlokeTx.getBlokeOrani());
				oMap.put(tableName, row, "BLOKE_TUTAR", birKampBlokeTx.getBlokeTutari());
				oMap.put(tableName, row, "BLOKE_FAIZ_ORAN", birKampBlokeTx.getBlokeFaizOrani());

				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	private static void getIliskiSigortaTable(String tableName, List<BirKampanyaSigUrunTx> urunList, GMMap oMap) {

		int row = 0;
		for (BirKampanyaSigUrunTx urun : urunList) {
			oMap.put(tableName, row, "URUN_NO", urun.getId().getUrunNo());
			oMap.put(tableName, row, "DAGILIM_ORANI", urun.getDagilimOrani());
			oMap.put(tableName, row, "SEGMENT", urun.getSegment());
			if ("E".equals(urun.getSilinecekMi())) {
				oMap.put(tableName, row, "SILINECEK_MI", true);
			}
			else {
				oMap.put(tableName, row, "SILINECEK_MI", false);
			}
			row++;
		}

	}

	private static void getRiskUrunTable(String tableName, List<BirKampRiskUrunTx> urunList, GMMap oMap) {
		int row = 0;
		for (BirKampRiskUrunTx urun : urunList) {
			oMap.put(tableName, row, "URUN_NO", urun.getId().getUrunNo());
			oMap.put(tableName, row, "URUN_ADI", urun.getUrunAdi());
			oMap.put(tableName, row, "UST_URUN_ADI", urun.getUstUrunAdi());
			row++;
		}

	}

}
