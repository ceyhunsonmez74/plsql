package tr.com.calikbank.bnspr.consumerloan.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirTasitDesen;
import tr.com.aktifbank.bnspr.dao.BirTasitDesenTx;
import tr.com.aktifbank.bnspr.dao.BirTasitDesenTxId;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3286Services {

	public enum IslemTipi {
		YENI("Y", "Yeni Kay�t"), GUNCELLEME("G", "G�ncelleme"), SILME("S", "Silme"), DEGISIKLIK_YOK("D", "De�i�iklik Yok");

		private String kod;
		private String aciklama;

		public String getKod() {
			return kod;
		}

		public String getAciklama() {
			return aciklama;
		}

		public static IslemTipi tipBul(String kod) {
			if ("Y".equalsIgnoreCase(kod)) {
				return YENI;
			}
			else if ("G".equalsIgnoreCase(kod)) {
				return GUNCELLEME;
			}
			else if ("S".equalsIgnoreCase(kod)) {
				return SILME;
			}

			return null;
		}

		private IslemTipi(String kod, String aciklama) {
			this.kod = kod;
			this.aciklama = aciklama;
		}

	}

	@GraymoundService("BNSPR_TRN3286_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<BirTasitDesen> liste = null;
		if (iMap.getString("MODEL_KOD") != null) {
			liste = session.createCriteria(BirTasitDesen.class).add(Restrictions.eq("id.modelKod", iMap.getString("MODEL_KOD"))).list();
		} else if (iMap.getString("MODEL_YIL") != null) {
			liste = session.createCriteria(BirTasitDesen.class).add(Restrictions.eq("id.marka", iMap.getString("MARKA"))).add(Restrictions.eq("id.modelYil", iMap.getString("MODEL_YIL"))).list();
		} else if (iMap.getString("MARKA") != null) {
			liste = session.createCriteria(BirTasitDesen.class).add(Restrictions.eq("id.marka", iMap.getString("MARKA"))).list();
		} else {
			liste = session.createCriteria(BirTasitDesen.class).add(Restrictions.eq("durum", "G")).list();
		}
		
		String tableName = "LISTE";
		int row = 0;

		for (BirTasitDesen desen : liste) {
			oMap.put(tableName, row, "MARKA", desen.getId().getMarka());
			oMap.put(tableName, row, "MODEL", desen.getModel());
			oMap.put(tableName, row, "MODEL_KOD", desen.getId().getModelKod());
			oMap.put(tableName, row, "MODEL_YIL", desen.getId().getModelYil());
			oMap.put(tableName, row, "SASI_DESEN", desen.getSasiDesen());
			row++;
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3286_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");
		List<BirTasitDesenTx> liste = session.createCriteria(BirTasitDesenTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();

		String tableName = "LISTE";
		int row = 0;

		for (BirTasitDesenTx desen : liste) {
			oMap.put(tableName, row, "MARKA", desen.getId().getMarka());
			oMap.put(tableName, row, "MODEL", desen.getModel());
			oMap.put(tableName, row, "MODEL_KOD", desen.getId().getModelKod());
			oMap.put(tableName, row, "MODEL_YIL", desen.getId().getModelYil());
			oMap.put(tableName, row, "SASI_DESEN", desen.getSasiDesen());
			oMap.put(tableName, row, "ISLEM_TIPI", desen.getIslemTipi());
			row++;
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3286_DELETE_RECORD")
	public static GMMap deleteRecord(GMMap iMap) {
		GMMap oMap = new GMMap();

		GMMap rowMap = iMap.getMap("ROW");

		Session session = DAOSession.getSession("BNSPRDal");

		// Yeni kay�tsa i�lem yap�lmamal�
		if (!"Yeni".equalsIgnoreCase(rowMap.getString("ISLEM_TIPI"))) {

			BirTasitDesenTx tx = new BirTasitDesenTx();
			BirTasitDesenTxId id = new BirTasitDesenTxId();
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setMarka(rowMap.getString("MARKA"));
			id.setModelKod(rowMap.getString("MODEL_KOD"));
			id.setModelYil(rowMap.getString("MODEL_YIL"));
			tx.setSasiDesen(rowMap.getString("SASI_DESEN"));

			tx.setId(id);
			tx.setIslemTipi(IslemTipi.SILME.getAciklama());

			session.save(tx);
			session.flush();
		}

		return oMap;
	}


	@GraymoundService("BNSPR_TRN3286_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");

		String tableName = "LISTE";

		for (int row = 0; row < iMap.getSize(tableName); row++) {
			if (iMap.getString(tableName, row, "ISLEM_TIPI") != null) {
				BirTasitDesenTx tx = new BirTasitDesenTx();
				BirTasitDesenTxId id = new BirTasitDesenTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setMarka(iMap.getString(tableName, row, "MARKA"));
				id.setModelKod(iMap.getString(tableName, row, "MODEL_KOD"));
				id.setModelYil(iMap.getString(tableName, row, "MODEL_YIL"));
				tx.setSasiDesen(iMap.getString(tableName, row, "SASI_DESEN"));

				tx.setId(id);
				tx.setIslemTipi(iMap.getString(tableName, row, "ISLEM_TIPI"));
				tx.setModel(iMap.getString(tableName, row, "MODEL"));

				session.save(tx);
				session.flush();
			}
		}
		iMap.put("TRX_NAME", "3286");
		oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		return oMap;
	}

}
