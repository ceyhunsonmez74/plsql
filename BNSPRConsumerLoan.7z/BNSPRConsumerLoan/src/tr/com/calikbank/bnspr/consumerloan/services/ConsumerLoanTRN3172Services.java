package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAdkBasvuru;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKonsolidasyon;
import tr.com.aktifbank.bnspr.dao.BirBasvuruPaket;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSigortaSatis;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSigortaSatisTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruSigortaSatisTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTarim;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTasit;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruBarkod;
import tr.com.aktifbank.bnspr.dao.ClksBirBasvuruSmsTalep;
import tr.com.aktifbank.bnspr.dao.MuhHesapRezerv;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.consumerloan.utils.CreditTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorus;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorusTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorusTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminat;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminatTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminatTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruTx;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3172Services {

	@GraymoundService("BNSPR_TRN3172_GET_AKSIYON_KARAR")
	public static GMMap getMedeniHalTurleri(GMMap iMap) {
		try {
			String queryString = "select t.key2, t.text from v_ml_gnl_param_text t where t.kod = 'BASVURU_AKSIYON_KARAR_KOD' and t.key1 = 'C' ";
			// if("E".equals(iMap.getString("CALL_CENTER")))
			if (!"FRAUD".equals(iMap.getString("DURUM")))
				queryString = queryString + "and t.KEY2 not in ('5', '4', '3', '7') "; // OTOMAT�K �PTAL, "m��teriye ula��lamad�" ve MEVCUT BA�VURU
																						// KONTROL� cikartildi
			else
				queryString = queryString + "and t.KEY2 in ('2', '5', '7') "; // fraud ise "m��teriye ula��lamad�"
			queryString = queryString + "order by sira_no ";
			return DALUtil.fillComboBox(iMap, "AKSIYON_KARAR_LIST", false, queryString);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_BASVURU_TAMAMLANMIS_MI")
	public static GMMap basvuruTamamlanmisMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3172.basvuru_tamamlanmis_mi(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			oMap.put("BASVURU_TAMAMLANMIS_MI", "E".equals(stmt.getString(1)));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3172_KVKK_SMS")
	public static GMMap kvkkSms(GMMap iMap) {

		GMMap oMap = new GMMap();

		String cepTel = iMap.getString("CEP_TEL");
		String mesaj = "";

		iMap.put("MESSAGE_NO", new java.math.BigDecimal(5683));

		mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
		if (!"".equals(cepTel) && !"".equals(mesaj)) {
			GMMap smsMap = new GMMap();
			smsMap.put("MSISDN", cepTel);
			smsMap.put("CONTENT", mesaj);
			smsMap.put("HEADER", "AktifBank");
			GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3172_GET_BASVURU")
	public static GMMap getBasvuruBilgileri(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			// birBasvuru tablosunda kaydi yoksa on onaydir.
			if (birBasvuru != null) {
				oMap.put("DOVIZ_KOD", birBasvuru.getDovizKodu());
				if (birBasvuru.getKampKod() != null) {
					oMap.put("URUN_KAMP_KOD", birBasvuru.getKampKod());
					oMap.put("KAMP_KNL_KOD", birBasvuru.getKampKnlKod());
					oMap.put("KAMP_KOD", birBasvuru.getKampKod());
				}
				else {
					oMap.put("KRD_TUR_ALT_KOD", birBasvuru.getKrediAltTur());
					oMap.put("KRD_TUR_ALT_KOD2", birBasvuru.getKrediAltTur2());
					oMap.put("URUN_KAMP_KOD", birBasvuru.getKrediAltTur() + "-" + birBasvuru.getKrediAltTur2());
				}
				oMap.put("EVE_TESLIM_URUN", birBasvuru.getEveTeslimatliUrun());
				oMap.put("TESLIMAT_TARIHI", birBasvuru.getUrunTeslimTarihi());
				oMap.put("KRD_TUR_KOD", birBasvuru.getKrediTur());
				oMap.put("KANAL_KODU", birBasvuru.getKanalKodu());
				oMap.put("KANAL_KOD", birBasvuru.getKanalKodu());
				oMap.put("KANAL_ALT_KODU", birBasvuru.getSaticiKod());
				oMap.put("KANAL_ALT_KOD", birBasvuru.getSaticiKod());
				if ("KANALIADE".equals(birBasvuru.getDurumKodu()) && birBasvuru.getBayiUrunTutari() != null && birBasvuru.getBayiUrunTutari().compareTo(BigDecimal.ZERO) > 0) {
					oMap.put("TUTAR", birBasvuru.getBayiUrunTutari());
				}
				else {
					List<BirBasvuruPaket> list = (List<BirBasvuruPaket>) session.createCriteria(BirBasvuruPaket.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
					List<BirBasvuruTasit> tasitList = (List<BirBasvuruTasit>) session.createCriteria(BirBasvuruTasit.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
					if (birBasvuru.getBasvuruTutari() != null && !"IPTAL".equals(iMap.getString("ISLEM_SONRASI_DURUM_KODU")) && (birBasvuru.getBasvuruTutari().compareTo(birBasvuru.getTutar()) >= 0 || "KANALIADE".equals(birBasvuru.getDurumKodu()) || ("BASVURU".equals(birBasvuru.getDurumKodu()) && (list.size() > 0 || tasitList.size() > 0))))
						oMap.put("TUTAR", birBasvuru.getBasvuruTutari());
					else
						oMap.put("TUTAR", birBasvuru.getTutar());
				}
				oMap.put("VADE", birBasvuru.getVade());
				oMap.put("FAIZ_ORANI", birBasvuru.getFaizOrani());
				oMap.put("SOZLESME_FAIZI", birBasvuru.getSozlesmeFaizi());
				oMap.put("DOSYA_MASRAFI", birBasvuru.getDosyaMasrafi());
				oMap.put("SIGORTA_PRIMI", birBasvuru.getSigortaPrimi());
				oMap.put("FARK_FAIZI", birBasvuru.getFarkFaizi());
				oMap.put("KPS_YAPILDI", birBasvuru.getKpsYapildi());
				oMap.put("SON_TX_NO", birBasvuru.getSonTxNo());
				oMap.put("DURUM_KODU", birBasvuru.getDurumKodu());
				oMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
				oMap.put("SUBE_KOD", birBasvuru.getSubeKod());
				oMap.put("HESAP_NO", birBasvuru.getHesapNo());
				oMap.put("SESSION_IP", birBasvuru.getSessionIp());
				oMap.put("DIGER_GORUS", birBasvuru.getGorus());
				oMap.put("BAGLI_SUBE_KOD", birBasvuru.getBagliSubeKodu());
				oMap.put("PERSONEL", birBasvuru.getSatisPersoneli());

				oMap.put("MAAS_ALINAN_KURUM", birBasvuru.getPttMaasAlinanKurum());
				oMap.put("ONCEKI_MAAS_ODEME_TARIHI", birBasvuru.getPttOncekiMaasOdemeTarihi());
				oMap.put("MAAS_TUTARI", birBasvuru.getPttSgkMaasTutar());
				oMap.put("SON_MAAS_TARIHI", birBasvuru.getPttSonMaasTarihi());
				oMap.put("MAAS_TARIH_SIKLIGI", birBasvuru.getPttMaasTarihSikligi());
				oMap.put("POSTA_CEK_HESABI", birBasvuru.getPttPostaCekiHesabi());
				oMap.put("MAAS_PTT_DENMI", birBasvuru.getPttMaasPttDenmi());
				oMap.put("EMEKLI_MAAS_EVDENMI", birBasvuru.getPttMaasEvdenMi());
				oMap.put("TAHSIS_NUMARASI", birBasvuru.getPttTahsisNumarasi());
				oMap.put("APS_YAPILDIMI", birBasvuru.getApsYapildimi());
				oMap.put("GECIKME_GUN_SAYISI", birBasvuru.getGecikmeGunSayisi());
				oMap.put("PTT_ILK_TAKSIT_YONTEM", birBasvuru.getIlkTaksitYontem());
				oMap.put("ILK_TAKSIT_TARIH", birBasvuru.getIlkTaksitTarihi());
				oMap.put("ISLEMIN_YAPILDIGI_IL", birBasvuru.getPttSubeIli());
				oMap.put("ISLEMIN_YAPILDIGI_MERKEZ", birBasvuru.getPttIsleminYapildigiMerkez());
				oMap.put("ISLEMIN_YAPILDIGI_SUBE", birBasvuru.getPttIsleminYapildigiSube());
				oMap.put("KURYE_SECIMI", birBasvuru.getKuryeSecimi());

				if (birBasvuru.getKanalKodu() != null && birBasvuru.getKanalKodu().compareTo("7") == 0) {

					int i = 1;
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{call PKG_TRN3172.PTT_GET_IL_SUBE_MERKEZ(?,?,?,?,?,?)}"); // PROSEDUR
					stmt.setString(i++, birBasvuru.getPttSubeIli());
					stmt.setString(i++, birBasvuru.getPttIsleminYapildigiSube());
					stmt.setString(i++, birBasvuru.getPttIsleminYapildigiMerkez());

					stmt.registerOutParameter(i++, Types.VARCHAR);
					stmt.registerOutParameter(i++, Types.VARCHAR);
					stmt.registerOutParameter(i++, Types.VARCHAR);
					stmt.execute();

					oMap.put("D_ISLEMIN_YAPILDIGI_IL", stmt.getString(4));
					oMap.put("D_ISLEMIN_YAPILDIGI_SUBE", stmt.getString(5));
					oMap.put("D_ISLEMIN_YAPILDIGI_MERKEZ", stmt.getString(6));
					conn.close();

				}

				oMap.put("GEC_TESLIM_NEDEN", birBasvuru.getGecTeslimatNeden());
				oMap.put("HESAP_KAPANSIN_MI", birBasvuru.getHesapKapansinMi());
				oMap.put("KAZANIM_TUR", birBasvuru.getKazanimTur());
				oMap.put("WEB_SATIS_KANALI", birBasvuru.getWebSatisKanali());
				oMap.put("FAIZSIZ_FINANSMAN", birBasvuru.getFaizsizFinansman());
				oMap.put("ONAY_TUTAR", birBasvuru.getOnayTutar());
				oMap.put("DEBIT_KART_TALEP", birBasvuru.getDebitKartTalep());

				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				oMap.put("ADI", birBasvuruKimlik.getAd());
				oMap.put("CALISMA_SEKLI", birBasvuruKimlik.getCalismaSekli());
				oMap.put("ANNE_KIZLIK_SOYADI", birBasvuruKimlik.getAnneKizlik());
				oMap.put("ANNE_ADI", birBasvuruKimlik.getAnneAdi());
				oMap.put("BABA_ADI", birBasvuruKimlik.getBabaAd());
				oMap.put("CEP_TEL_KOD", birBasvuruKimlik.getCepTelAlanKodu());
				oMap.put("CEP_TEL_NO", birBasvuruKimlik.getCepTelNo());
				oMap.put("CINSIYET", birBasvuruKimlik.getCinsiyet());
				oMap.put("DOGUM_TARIHI", birBasvuruKimlik.getDogumTar());
				oMap.put("DOGUM_YERI", birBasvuruKimlik.getDogumYeri());
				oMap.put("IKINCI_ADI", birBasvuruKimlik.getIkinciAd());
				oMap.put("KIMLIK_SERI_NO", birBasvuruKimlik.getKimlikSeriNo());
				oMap.put("KIMLIK_SIRA_NO", birBasvuruKimlik.getKimlikSiraNo());
				oMap.put("KIMLIK_SERI_NO_KPS", birBasvuruKimlik.getKimlikSeriNoKps());
				oMap.put("KIMLIK_SIRA_NO_KPS", birBasvuruKimlik.getKimlikSiraNoKps());
				oMap.put("MEDENI_HAL", birBasvuruKimlik.getMedeniHal());
				oMap.put("SOYADI", birBasvuruKimlik.getSoyad());
				oMap.put("ONCEKI_SOYADI", birBasvuruKimlik.getOncekiSoyad());
				oMap.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
				oMap.put("ES_TCKN", birBasvuruKimlik.getEsTckn());
				oMap.put("NUFUS_ILCE_KOD", birBasvuruKimlik.getNufusIlceKod());
				oMap.put("NUFUS_IL_KOD", birBasvuruKimlik.getNufusIlKod());
				oMap.put("NUFUS_MAHALLE", birBasvuruKimlik.getMahalleKoy());
				oMap.put("NUFUS_VERILIS_TARIHI", birBasvuruKimlik.getNufusVerTar());
				oMap.put("NUF_VERILIS_NEDENI", birBasvuruKimlik.getNufusVerNedeni());
				oMap.put("NUF_VERILDIGI_YER", birBasvuruKimlik.getNufusVerYer());

				oMap.put("NUFUS_CILT_NO", birBasvuruKimlik.getCiltNo());
				oMap.put("NUFUS_AILE_SIRA_NO", birBasvuruKimlik.getAileSiraNo());
				oMap.put("NUFUS_SIRA_NO", birBasvuruKimlik.getBireySiraNo());
				oMap.put("KAYIP_KIMLIK_SERI_NO", birBasvuruKimlik.getKayipKimlikSeriNo());
				oMap.put("KAYIP_KIMLIK_SIRA_NO", birBasvuruKimlik.getKayipKimlikSiraNo());
				oMap.put("UYRUK", birBasvuruKimlik.getUyrukKod());
				oMap.put("KIMLIK_KAYIT_NO", birBasvuruKimlik.getKimlikKayitNo());

				if (StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("E"))
					oMap.put("MUH_ADR_E", true);
				else if (StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("H"))
					oMap.put("MUH_ADR_H", true);
				else if (StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("B"))
					oMap.put("MUH_ADR_B", true);

				if (StringUtils.isNotBlank(birBasvuruKimlik.getTeslimatAdresAyniEh()) && birBasvuruKimlik.getTeslimatAdresAyniEh().equals("E"))
					oMap.put("ADR_AYNI_E", true);
				else if (StringUtils.isNotBlank(birBasvuruKimlik.getTeslimatAdresAyniEh()) && birBasvuruKimlik.getTeslimatAdresAyniEh().equals("H"))
					oMap.put("ADR_AYNI_H", true);

				oMap.put("TESLIMAT_ADRES", birBasvuruKimlik.getTeslimatAdresi());
				oMap.put("TESLIMAT_IL", birBasvuruKimlik.getTeslimatAdrIlKod());
				oMap.put("TESLIMAT_ILCE", birBasvuruKimlik.getTeslimatAdrIlceKod());
				oMap.put("TESLIMAT_POSTA_KODU", birBasvuruKimlik.getTeslimatPostakod());
				oMap.put("TESLIMAT_URUN_KIME", birBasvuruKimlik.getTeslimatKisi());
				oMap.put("TESLIMAT_TCKN", birBasvuruKimlik.getTeslimatKisiTckn());
				oMap.put("TESLIMAT_FARKLI_OLMA_NEDENI", birBasvuruKimlik.getTeslimatFarkliOlmaNedeni());

				if (StringUtils.isNotBlank(birBasvuruKimlik.getKimlik2KartIlk6()) && birBasvuruKimlik.getKimlik2KartIlk6().length() == 6) {
					oMap.put("KART1", birBasvuruKimlik.getKimlik2KartIlk6().substring(0, 4));
					oMap.put("KART2", birBasvuruKimlik.getKimlik2KartIlk6().substring(4));
				}

				oMap.put("KART3", birBasvuruKimlik.getKimlik2KartSon4());
				oMap.put("IKINCI_KIMLIK_TIPI", birBasvuruKimlik.getKimlik2Tip());
				oMap.put("KAMPANYA_BILGI", birBasvuruKimlik.getKampanyaBilgi());
			}
			else {
				// on onay icin basvuru bilgileri tx tablosundan doldurulur.
				List<?> birBasvuruTxList = session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("durumKodu", "ON_ONAY")).addOrder(Order.asc("txNo")).list();
				if (birBasvuruTxList != null && !birBasvuruTxList.isEmpty()) {
					BirBasvuruTx birBasvuruTx = (BirBasvuruTx) birBasvuruTxList.get(0);
					BigDecimal onOnayTxNo = birBasvuruTx.getTxNo();

					oMap.put("DOVIZ_KOD", birBasvuruTx.getDovizKodu());
					if (birBasvuruTx.getKampKod() != null) {
						oMap.put("URUN_KAMP_KOD", birBasvuruTx.getKampKod());
						oMap.put("KAMP_KNL_KOD", birBasvuruTx.getKampKnlKod());
						oMap.put("KAMP_KOD", birBasvuruTx.getKampKod());
					}
					else {
						oMap.put("KRD_TUR_ALT_KOD", birBasvuruTx.getKrediAltTur());
						oMap.put("KRD_TUR_ALT_KOD2", birBasvuruTx.getKrediAltTur2());
						oMap.put("URUN_KAMP_KOD", birBasvuruTx.getKrediAltTur() + "-" + birBasvuruTx.getKrediAltTur2());
						oMap.put("KAMP_KOD", birBasvuruTx.getKampKod());
					}

					oMap.put("EVE_TESLIM_URUN", birBasvuruTx.getEveTeslimatliUrun());
					oMap.put("TESLIMAT_TARIHI", birBasvuruTx.getUrunTeslimTarihi());
					oMap.put("KRD_TUR_KOD", birBasvuruTx.getKrediTur());
					oMap.put("KANAL_KODU", birBasvuruTx.getKanalKodu());
					oMap.put("KANAL_KOD", birBasvuruTx.getKanalKodu());
					oMap.put("KANAL_ALT_KODU", birBasvuruTx.getSaticiKod());
					oMap.put("KANAL_ALT_KOD", birBasvuruTx.getSaticiKod());
					if (birBasvuruTx.getBasvuruTutari() != null && !"IPTAL".equals(iMap.getString("ISLEM_SONRASI_DURUM_KODU")) && (birBasvuruTx.getBasvuruTutari().compareTo(birBasvuruTx.getTutar()) >= 0 || "KANALIADE".equals(birBasvuruTx.getDurumKodu()))) {
						oMap.put("TUTAR", birBasvuruTx.getBasvuruTutari());
						oMap.put("HERSEY_DAHIL_TUTAR", birBasvuruTx.getTutar());
					}
					else
						oMap.put("TUTAR", birBasvuruTx.getTutar());
					oMap.put("VADE", birBasvuruTx.getVade());
					oMap.put("FAIZ_ORANI", birBasvuruTx.getFaizOrani());
					oMap.put("SOZLESME_FAIZI", birBasvuruTx.getSozlesmeFaizi());
					oMap.put("DOSYA_MASRAFI", birBasvuruTx.getDosyaMasrafi());
					oMap.put("SIGORTA_PRIMI", birBasvuruTx.getSigortaPrimi());
					oMap.put("FARK_FAIZI", birBasvuruTx.getFarkFaizi());
					oMap.put("KPS_YAPILDI", birBasvuruTx.getKpsYapildi());
					oMap.put("SON_TX_NO", birBasvuruTx.getSonTxNo());
					oMap.put("DURUM_KODU", birBasvuruTx.getDurumKodu());
					oMap.put("MUSTERI_NO", birBasvuruTx.getMusteriNo());
					oMap.put("SUBE_KOD", birBasvuruTx.getSubeKod());
					oMap.put("HESAP_NO", birBasvuruTx.getHesapNo());
					oMap.put("SESSION_IP", birBasvuruTx.getSessionIp());
					oMap.put("DIGER_GORUS", birBasvuruTx.getGorus());
					oMap.put("BAGLI_SUBE_KOD", birBasvuruTx.getBagliSubeKodu());
					oMap.put("PERSONEL", birBasvuruTx.getSatisPersoneli());

					oMap.put("MAAS_ALINAN_KURUM", birBasvuruTx.getPttMaasAlinanKurum());
					oMap.put("ONCEKI_MAAS_ODEME_TARIHI", birBasvuruTx.getPttOncekiMaasOdemeTarihi());
					oMap.put("MAAS_TUTARI", birBasvuruTx.getPttSgkMaasTutar());
					oMap.put("SON_MAAS_TARIHI", birBasvuruTx.getPttSonMaasTarihi());
					oMap.put("MAAS_TARIH_SIKLIGI", birBasvuruTx.getPttMaasTarihSikligi());
					oMap.put("POSTA_CEK_HESABI", birBasvuruTx.getPttPostaCekiHesabi());
					oMap.put("MAAS_PTT_DENMI", birBasvuruTx.getPttMaasPttDenmi());
					oMap.put("EMEKLI_MAAS_EVDENMI", birBasvuruTx.getPttMaasEvdenMi());
					oMap.put("TAHSIS_NUMARASI", birBasvuruTx.getPttTahsisNumarasi());
					oMap.put("APS_YAPILDIMI", birBasvuruTx.getApsYapildimi());
					oMap.put("GECIKME_GUN_SAYISI", birBasvuruTx.getGecikmeGunSayisi());
					oMap.put("PTT_ILK_TAKSIT_YONTEM", birBasvuruTx.getIlkTaksitYontem());
					oMap.put("ILK_TAKSIT_TARIH", birBasvuruTx.getIlkTaksitTarihi());
					oMap.put("ISLEMIN_YAPILDIGI_IL", birBasvuruTx.getPttSubeIli());
					oMap.put("ISLEMIN_YAPILDIGI_MERKEZ", birBasvuruTx.getPttIsleminYapildigiMerkez());
					oMap.put("ISLEMIN_YAPILDIGI_SUBE", birBasvuruTx.getPttIsleminYapildigiSube());
					oMap.put("KURYE_SECIMI", birBasvuruTx.getKuryeSecimi());

					if (birBasvuruTx.getKanalKodu() != null && birBasvuruTx.getKanalKodu().compareTo("7") == 0) {

						int i = 1;
						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{call PKG_TRN3172.PTT_GET_IL_SUBE_MERKEZ(?,?,?,?,?,?)}"); // PROSEDUR
						stmt.setString(i++, birBasvuruTx.getPttSubeIli());
						stmt.setString(i++, birBasvuruTx.getPttIsleminYapildigiSube());
						stmt.setString(i++, birBasvuruTx.getPttIsleminYapildigiMerkez());

						stmt.registerOutParameter(i++, Types.VARCHAR);
						stmt.registerOutParameter(i++, Types.VARCHAR);
						stmt.registerOutParameter(i++, Types.VARCHAR);
						stmt.execute();

						oMap.put("D_ISLEMIN_YAPILDIGI_IL", stmt.getString(4));
						oMap.put("D_ISLEMIN_YAPILDIGI_SUBE", stmt.getString(5));
						oMap.put("D_ISLEMIN_YAPILDIGI_MERKEZ", stmt.getString(6));
						conn.close();
					}

					oMap.put("GEC_TESLIM_NEDEN", birBasvuruTx.getGecTeslimatNeden());
					oMap.put("HESAP_KAPANSIN_MI", birBasvuruTx.getHesapKapansinMi());
					oMap.put("KAZANIM_TUR", birBasvuruTx.getKazanimTur());
					oMap.put("WEB_SATIS_KANALI", birBasvuruTx.getWebSatisKanali());
					oMap.put("FAIZSIZ_FINANSMAN", birBasvuruTx.getFaizsizFinansman());
					/** PY-16299 PTT SMS */
					oMap.put("ONAY_TUTAR", birBasvuruTx.getOnayTutar());
					oMap.put("BASVURU_TARIHI", birBasvuruTx.getBasvuruTarihi());
					oMap.put("PTT_TAHSIS_NUMARASI", birBasvuruTx.getPttTahsisNumarasi());

					BirBasvuruKimlikTx birBasvuruKimlik = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", onOnayTxNo)).uniqueResult();
					oMap.put("ADI", birBasvuruKimlik.getAd());
					oMap.put("CALISMA_SEKLI", birBasvuruKimlik.getCalismaSekli());
					oMap.put("ANNE_KIZLIK_SOYADI", birBasvuruKimlik.getAnneKizlik());
					oMap.put("ANNE_ADI", birBasvuruKimlik.getAnneAdi());
					oMap.put("BABA_ADI", birBasvuruKimlik.getBabaAd());
					oMap.put("CEP_TEL_KOD", birBasvuruKimlik.getCepTelAlanKodu());
					oMap.put("CEP_TEL_NO", birBasvuruKimlik.getCepTelNo());
					oMap.put("CINSIYET", birBasvuruKimlik.getCinsiyet());
					oMap.put("DOGUM_TARIHI", birBasvuruKimlik.getDogumTar());
					oMap.put("DOGUM_YERI", birBasvuruKimlik.getDogumYeri());
					oMap.put("IKINCI_ADI", birBasvuruKimlik.getIkinciAd());
					oMap.put("KIMLIK_SERI_NO", birBasvuruKimlik.getKimlikSeriNo());
					oMap.put("KIMLIK_SIRA_NO", birBasvuruKimlik.getKimlikSiraNo());
					oMap.put("KIMLIK_SERI_NO_KPS", birBasvuruKimlik.getKimlikSeriNoKps());
					oMap.put("KIMLIK_SIRA_NO_KPS", birBasvuruKimlik.getKimlikSiraNoKps());
					oMap.put("MEDENI_HAL", birBasvuruKimlik.getMedeniHal());
					oMap.put("SOYADI", birBasvuruKimlik.getSoyad());
					oMap.put("ONCEKI_SOYADI", birBasvuruKimlik.getOncekiSoyad());
					oMap.put("TC_KIMLIK_NO", birBasvuruKimlik.getTcKimlikNo());
					oMap.put("ES_TCKN", birBasvuruKimlik.getEsTckn());
					oMap.put("NUFUS_ILCE_KOD", birBasvuruKimlik.getNufusIlceKod());
					oMap.put("NUFUS_IL_KOD", birBasvuruKimlik.getNufusIlKod());
					oMap.put("NUFUS_MAHALLE", birBasvuruKimlik.getMahalleKoy());
					oMap.put("NUFUS_VERILIS_TARIHI", birBasvuruKimlik.getNufusVerTar());
					oMap.put("NUF_VERILIS_NEDENI", birBasvuruKimlik.getNufusVerNedeni());
					oMap.put("NUF_VERILDIGI_YER", birBasvuruKimlik.getNufusVerYer());

					oMap.put("NUFUS_CILT_NO", birBasvuruKimlik.getCiltNo());
					oMap.put("NUFUS_AILE_SIRA_NO", birBasvuruKimlik.getAileSiraNo());
					oMap.put("NUFUS_SIRA_NO", birBasvuruKimlik.getBireySiraNo());
					oMap.put("KAYIP_KIMLIK_SERI_NO", birBasvuruKimlik.getKayipKimlikSeriNo());
					oMap.put("KAYIP_KIMLIK_SIRA_NO", birBasvuruKimlik.getKayipKimlikSiraNo());
					oMap.put("UYRUK", birBasvuruKimlik.getUyrukKod());
					oMap.put("KIMLIK_KAYIT_NO", birBasvuruKimlik.getKimlikKayitNo());

				}
			}
			String func = "{call Pkg_rc3173.get_teslimat_bilgileri(?,?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
			Object[] outputValues = { BnsprType.REFCURSOR, "TESLIMAT_TABLE", BnsprType.REFCURSOR, "URUN_TABLE" };
			oMap.putAll((GMMap) DALUtil.callOracleProcedure(func, inputValues, outputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3172_GET_BASVURU_DETAY")
	public static GMMap getBasvuruDetayBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			// birBasvuru tablosunda kaydi null degilse
			if (birBasvuru != null) {

				oMap.put("KANAL_KODU", birBasvuru.getKanalKodu());
				oMap.put("DOSYA_MASRAFI", birBasvuru.getDosyaMasrafi());
				oMap.put("SIGORTA_PRIMI", birBasvuru.getSigortaPrimi());
				oMap.put("FARK_FAIZI", birBasvuru.getFarkFaizi());
				oMap.put("ODEME_TIPI", birBasvuru.getOdemeTipKod());
				oMap.put("ODEME_ORANI", birBasvuru.getOdemeTipOran());
				oMap.put("ODEME_PERIYODU", birBasvuru.getOdemeTipPeriyod());
				oMap.put("ODEME_TUTARI", birBasvuru.getOdemeTipTut());
				oMap.put("ODEME_VADESI", birBasvuru.getOdemeTipVade());
				oMap.put("KATILIM_BEDELI", birBasvuru.getSerbestKatkiPayi());
				oMap.put("FAIZ_ORANI", birBasvuru.getFaizOrani());
				oMap.put("KEFIL_GEREKLI_MI", birBasvuru.getKefilGerekliEh());
				if ("E".equals(oMap.getString("KEFIL_GEREKLI_MI"))) {
					oMap.put("KEFIL_GEREKLI", "Y");
				}
				oMap.put("SUBE_KOD", birBasvuru.getSubeKod());
				oMap.put("HESAP_NO", birBasvuru.getHesapNo());

				oMap.put("ADRES_BILGILERI_UYUMLUMU", birBasvuru.getApsBilgileriUyumlumu());
				oMap.put("KIMLIK_BILGILERI_UYUMLUMU", birBasvuru.getPttKpsBilgileriUyumlumu());
				oMap.put("GEC_TESLIM_NEDEN", birBasvuru.getGecTeslimatNeden());
				oMap.put("HESAP_KAPANSIN_MI", birBasvuru.getHesapKapansinMi());
				oMap.put("TAHSIS_NUMARASI", birBasvuru.getPttTahsisNumarasi());
				oMap.put("KAZANIM_TUR", birBasvuru.getKazanimTur());
				oMap.put("KREDI_TUR", birBasvuru.getKrediTur());

				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

				if (birBasvuruKimlik.getAdresteFaaliyetSuresi() != null) {
					String adresteFaaliyetSuresiYil = birBasvuruKimlik.getAdresteFaaliyetSuresi().substring(0, 2);
					{
						if (adresteFaaliyetSuresiYil.charAt(0) == '0')
							adresteFaaliyetSuresiYil = adresteFaaliyetSuresiYil.substring(1);
					}
					String adresteFaaliyetSuresiAy = birBasvuruKimlik.getAdresteFaaliyetSuresi().substring(2, 4);
					{
						if (adresteFaaliyetSuresiAy.charAt(0) == '0')
							adresteFaaliyetSuresiAy = adresteFaaliyetSuresiAy.substring(1);
					}
					oMap.put("FAALIYET_SURESI_YIL", adresteFaaliyetSuresiYil);
					oMap.put("FAALIYET_SURESI_AY", adresteFaaliyetSuresiAy);
				}
				if (birBasvuruKimlik.getAdresteOturmaSuresi() != null) {
					String adresteOturmaSuresiYil = birBasvuruKimlik.getAdresteOturmaSuresi().substring(0, 2);
					{
						if (adresteOturmaSuresiYil.charAt(0) == '0')
							adresteOturmaSuresiYil = adresteOturmaSuresiYil.substring(1);
					}
					String adresteOturmaSuresiAy = birBasvuruKimlik.getAdresteOturmaSuresi().substring(2, 4);
					{
						if (adresteOturmaSuresiAy.charAt(0) == '0')
							adresteOturmaSuresiAy = adresteOturmaSuresiAy.substring(1);
					}
					oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL", adresteOturmaSuresiYil);
					oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY", adresteOturmaSuresiAy);
				}
				oMap.put("AYLIK_GELIR", birBasvuruKimlik.getAylikGelir() == null ? BigDecimal.ZERO : birBasvuruKimlik.getAylikGelir());
				oMap.put("CALISMA_SEKLI", birBasvuruKimlik.getCalismaSekli());
				oMap.put("DIGER_GELIR", birBasvuruKimlik.getDigerGelir() == null ? BigDecimal.ZERO : birBasvuruKimlik.getDigerGelir());
				oMap.put("OGRENIM_DURUMU", birBasvuruKimlik.getEgitimDurumKod());
				if (birBasvuruKimlik.getEMail() != null && birBasvuruKimlik.getEMail().length() > 1) {
					oMap.put("EMAIL1", birBasvuruKimlik.getEMail().substring(0, birBasvuruKimlik.getEMail().indexOf('@')));
					oMap.put("EMAIL2", birBasvuruKimlik.getEMail().substring(birBasvuruKimlik.getEMail().indexOf('@') + 1));
				}
				oMap.put("ES_GELIRI", birBasvuruKimlik.getEsGeliri() == null ? BigDecimal.ZERO : birBasvuruKimlik.getEsGeliri());
				oMap.put("EV_ADRESI", birBasvuruKimlik.getEvAdres());
				oMap.put("EV_ILCE", birBasvuruKimlik.getEvAdrIlceKod());
				oMap.put("EV_IL", birBasvuruKimlik.getEvAdrIlKod());
				oMap.put("EV_POSTA_KODU", birBasvuruKimlik.getEvPostakod());
				oMap.put("EV_TEL_KOD", birBasvuruKimlik.getEvTelAlan());
				oMap.put("EV_TEL_NO", birBasvuruKimlik.getEvTelNo());
				oMap.put("IKAMET_DURUMU", birBasvuruKimlik.getIkametDurumKod());
				oMap.put("IS_ADRESI", birBasvuruKimlik.getIsAdres());
				oMap.put("IS_ILCE", birBasvuruKimlik.getIsAdrIlceKod());
				oMap.put("IS_IL", birBasvuruKimlik.getIsAdrIlKod());
				oMap.put("IS_POSTA_KODU", birBasvuruKimlik.getIsPostakod());
				oMap.put("IS_TEL_KOD", birBasvuruKimlik.getIsTelAlan());
				oMap.put("IS_TEL_DAHILI", birBasvuruKimlik.getIsTelDahili());
				oMap.put("IS_TEL_NO", birBasvuruKimlik.getIsTelNo());
				oMap.put("ISYERI_ADI", birBasvuruKimlik.getIsyeriAdi());
				oMap.put("ISYERI_FAALIYET_ALANI", birBasvuruKimlik.getIsyeriFaalKonuKod());
				oMap.put("ISYERI_MULKIYET", birBasvuruKimlik.getIsyeriMulkiyetKod());

				if (birBasvuruKimlik.getIsyerindeCalismaSuresi() != null && birBasvuruKimlik.getIsyerindeCalismaSuresi().length() == 4) {
					String isyerindeCalismaSuresiYil = birBasvuruKimlik.getIsyerindeCalismaSuresi().substring(0, 2);
					{
						if (isyerindeCalismaSuresiYil.charAt(0) == '0')
							isyerindeCalismaSuresiYil = isyerindeCalismaSuresiYil.substring(1);
					}
					String isyerindeCalismaSuresiAy = birBasvuruKimlik.getIsyerindeCalismaSuresi().substring(2, 4);
					{
						if (isyerindeCalismaSuresiAy.charAt(0) == '0')
							isyerindeCalismaSuresiAy = isyerindeCalismaSuresiAy.substring(1);
					}
					oMap.put("ISYERINDE_CALISMA_SURESI_YIL", isyerindeCalismaSuresiYil);
					oMap.put("ISYERINDE_CALISMA_SURESI_AY", isyerindeCalismaSuresiAy);
				}
				oMap.put("ISYERI_VERGI_DAIRESI_ADI", birBasvuruKimlik.getIsyeriVergiDaireKodu());
				oMap.put("ISYERI_VERGI_DAIRESI_IL", birBasvuruKimlik.getIsyeriVergiIlKodu());
				oMap.put("ISYERI_VERGI_NO", birBasvuruKimlik.getIsyeriVergiNo());
				oMap.put("GMENKUL_GELIR", birBasvuruKimlik.getMenkulGmenkulGeliri() == null ? BigDecimal.ZERO : birBasvuruKimlik.getMenkulGmenkulGeliri());
				oMap.put("MESLEK", birBasvuruKimlik.getMeslekKod());
				oMap.put("UNVANI", birBasvuruKimlik.getUnvanKod());
				oMap.put("YAZISMA_ADRESI_EV", "E".equals(birBasvuruKimlik.getYazismaAdresKod()));
				oMap.put("YAZISMA_ADRESI_IS", "I".equals(birBasvuruKimlik.getYazismaAdresKod()));
				oMap.put("SIGORTALI_MI", GuimlUtil.convertToCheckBoxSelected(birBasvuruKimlik.getSigortaliMi()));
				oMap.put("ULASIM_KART_NO", birBasvuruKimlik.getUlasimKartNo());

				oMap.put("MUH_ADR_E", StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("E"));
				oMap.put("MUH_ADR_H", StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("H"));
				oMap.put("MUH_ADR_B", StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("B"));

				oMap.put("ADR_AYNI_E", StringUtils.isNotBlank(birBasvuruKimlik.getTeslimatAdresAyniEh()) && birBasvuruKimlik.getTeslimatAdresAyniEh().equals("E"));
				oMap.put("ADR_AYNI_H", StringUtils.isNotBlank(birBasvuruKimlik.getTeslimatAdresAyniEh()) && birBasvuruKimlik.getTeslimatAdresAyniEh().equals("H"));

				oMap.put("TESLIMAT_ADRES", birBasvuruKimlik.getTeslimatAdresi());
				oMap.put("TESLIMAT_IL", birBasvuruKimlik.getTeslimatAdrIlKod());
				oMap.put("TESLIMAT_ILCE", birBasvuruKimlik.getTeslimatAdrIlceKod());
				oMap.put("TESLIMAT_POSTA_KODU", birBasvuruKimlik.getTeslimatPostakod());
				oMap.put("TESLIMAT_URUN_KIME", birBasvuruKimlik.getTeslimatKisi());
				oMap.put("TESLIMAT_TCKN", birBasvuruKimlik.getTeslimatKisiTckn());
				oMap.put("TESLIMAT_FARKLI_OLMA_NEDENI", birBasvuruKimlik.getTeslimatFarkliOlmaNedeni());
				/** TY-6310 TY-tahsis izleme ekranlar�na teslimat adresi farkl� olma nedeni eklenmesi hk. */
				oMap.put("TESLIMAT_FARKLI_OLMA_NEDENI_DESC", GMServiceExecuter.execute("BNSPR_TRN3172_GET_TESLIMAT_FARKLI_OLMA_NEDENI_DESCRIPTION", oMap).get("TESLIMAT_FARKLI_OLMA_NEDENI_DESC"));

				if (StringUtils.isNotBlank(birBasvuruKimlik.getKimlik2KartIlk6()) && birBasvuruKimlik.getKimlik2KartIlk6().length() == 6) {
					oMap.put("KART1", birBasvuruKimlik.getKimlik2KartIlk6().substring(0, 4));
					oMap.put("KART2", birBasvuruKimlik.getKimlik2KartIlk6().substring(4));
				}

				oMap.put("KART3", birBasvuruKimlik.getKimlik2KartSon4());
				oMap.put("IKINCI_KIMLIK_TIPI", birBasvuruKimlik.getKimlik2Tip());
				oMap.put("TEYIT_EDILEN_GELIR", birBasvuruKimlik.getTeyitEdilenGelir() == null ? BigDecimal.ZERO : birBasvuruKimlik.getTeyitEdilenGelir());
				oMap.put("KAMPANYA_BILGI", birBasvuruKimlik.getKampanyaBilgi());
				List<?> limitList = session.createCriteria(BirBasvuruTeminat.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				String tableName = "TEMINAT_TABLE";
				int row = 0;
				for (Iterator<?> iterator = limitList.iterator(); iterator.hasNext();) {
					BirBasvuruTeminat birBasvuruTeminat = (BirBasvuruTeminat) iterator.next();
					oMap.put(tableName, row, "TEMINAT", birBasvuruTeminat.getId().getTeminatKod());
					oMap.put(tableName, row, "TEMINAT_TF", LovHelper.diLov(birBasvuruTeminat.getId().getTeminatKod(), "3171/LOV_TEMINAT", "ACIKLAMA"));
					oMap.put(tableName, row, "ADET", birBasvuruTeminat.getTeminatAdedi());
					row++;
				}

				List<?> sigortaList = session.createCriteria(BirBasvuruSigortaSatis.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				tableName = "SIGORTA_TABLE";
				row = 0;
				for (Iterator<?> iterator = sigortaList.iterator(); iterator.hasNext();) {
					BirBasvuruSigortaSatis birBasvuruSigortaSatis = (BirBasvuruSigortaSatis) iterator.next();
					oMap.put(tableName, row, "SIGORTA_SATIS_URUN", birBasvuruSigortaSatis.getId().getSigortaUrunNo());
					oMap.put(tableName, row, "ADET", "1");
					oMap.put(tableName, row, "PRIM", birBasvuruSigortaSatis.getSigortaPrimi());

					row++;
				}

				List<?> gorusList = session.createCriteria(BirBasvuruGorus.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				tableName = "GORUS_TABLE";
				row = 0;
				for (Iterator<?> iterator = gorusList.iterator(); iterator.hasNext();) {
					BirBasvuruGorus birBasvuruGorus = (BirBasvuruGorus) iterator.next();
					oMap.put(tableName, row, "BASVURU_GORUS", birBasvuruGorus.getId().getGorusKod());
					oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxValue(birBasvuruGorus.getEH()));
					row++;
				}

				String func = "{call Pkg_rc3173.get_teslimat_bilgileri(?,?,?)}";
				Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
				Object[] outputValues = { BnsprType.REFCURSOR, "TESLIMAT_TABLE", BnsprType.REFCURSOR, "URUN_TABLE" };
				oMap.putAll((GMMap) DALUtil.callOracleProcedure(func, inputValues, outputValues));

				if (CreditTypes.TASIT.getCreditCode().compareTo(birBasvuru.getKrediTur()) == 0) {
					BirBasvuruTasit birBasvuruTasit = (BirBasvuruTasit) session.createCriteria(BirBasvuruTasit.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					String aracTip = (String) DALUtil.callOneParameterFunction("{? = call pkg_basvuru.getTasitBasvuruTip(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO"));

					if (birBasvuruTasit != null) {
						oMap.put("ARAC_KOD", birBasvuruTasit.getAracKod());
						oMap.put("ARAC_MARKA", birBasvuruTasit.getMarka());
						oMap.put("ARAC_MODEL_YIL", birBasvuruTasit.getModelYil());
						oMap.put("ARAC_MODEL", birBasvuruTasit.getModel());
						oMap.put("ARAC_KULLANIM_AMAC", birBasvuruTasit.getKullanimAmac());
						oMap.put("ARAC_KASKO_DEGER", birBasvuruTasit.getKaskoDeger());
						oMap.put("ARAC_NOTER_DEGER", birBasvuruTasit.getNoterDeger());
						oMap.put("ARAC_PLAKA", birBasvuruTasit.getPlaka());
						oMap.put("ARAC_RUHSAT_TARIH", birBasvuruTasit.getRuhsatTarih());
						oMap.put("ARAC_SICIL_NO", birBasvuruTasit.getSicilNo());
						oMap.put("ARAC_MOTOR_NO", birBasvuruTasit.getMotorNo());
						oMap.put("ARAC_SASI_NO", birBasvuruTasit.getSasiNo());
						oMap.put("RUHSAT_TCKN_VKN", birBasvuruTasit.getRuhsatTcknVkn());
						oMap.put("KM", birBasvuruTasit.getKm());
						oMap.put("REHIN_MASRAFI", birBasvuruTasit.getRehinMasrafi());
						if ("".equals(birBasvuruTasit.getAracTipi())) {
							oMap.put("ARAC_TIP", aracTip);
						}
						else {
							oMap.put("ARAC_TIP", birBasvuruTasit.getAracTipi());
						}
						oMap.put("ARAC_TRAFIK_SUBE", birBasvuruTasit.getTrafikSubesi());
					}
				}
				if (CreditTypes.TARIM.getCreditCode().compareTo(birBasvuru.getKrediTur()) == 0) {
					BirBasvuruTarim birBasvuruTarim = (BirBasvuruTarim) session.createCriteria(BirBasvuruTarim.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

					if (birBasvuruTarim != null) {
						oMap.put("BUYUKBAS_SAYISI", birBasvuruTarim.getBuyukbasSayisi());
						oMap.put("DONUM", birBasvuruTarim.getDonum());
						oMap.put("GUNCEL_RISK", birBasvuruTarim.getGuncelRisk());
						oMap.put("KUCUKBAS_SAYISI", birBasvuruTarim.getKucukbasSayisi());
						oMap.put("TARIM_SATIS_KANAL_KOD", birBasvuruTarim.getTarimSatisKanalKod());
						oMap.put("TARIS_EH", birBasvuruTarim.getTarisEh());

					}
				}

				List<BirBasvuruPaket> list = (List<BirBasvuruPaket>) session.createCriteria(BirBasvuruPaket.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				if (list.size() > 0) {
					oMap.put("EK_IHTIYAC", "E");
				}
				else {
					oMap.put("EK_IHTIYAC", "H");
				}

				if ("2".equals(birBasvuru.getKanalKodu())) {
					iMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
					oMap.put("MUSTERI_KONTAKT", GMServiceExecuter.execute("BNSPR_CUST_GET_MUSTERIMI_KONTAKMI", iMap).get("KONTAK_MUSTERI"));
				}

				// TY-13652
				// PBIBK-416
				if ("PTT_SMS".equals(birBasvuru.getWebSatisKanali()) || "PTT_ONONAY".equals(birBasvuru.getWebSatisKanali())) {
					iMap.put("PARAMETRE", "BIR_PTT_SMS_IPTAL_SURE_SUBE");
					BigDecimal gecerlilikGunSayisi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", iMap).getBigDecimal("DEGER");
					// BirAdkBasvuru birAdkBasvuru = (BirAdkBasvuru) session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					// if (birAdkBasvuru != null && birAdkBasvuru.getGecerlilikTarihi() != null) {
					// Date sysdate = Calendar.getInstance().getTime();
					// double dayDiff = birAdkBasvuru.getGecerlilikTarihi().getTime() - sysdate.getTime();
					// double gecerlilikGunSayisi = Math.ceil(dayDiff / (1000*60*60*24));
					// oMap.put("GECERLILIK_GUN_SAYISI", gecerlilikGunSayisi);
					// }
					oMap.put("GECERLILIK_GUN_SAYISI", gecerlilikGunSayisi);
				}
				oMap.put("KURYE_SECIMI", birBasvuru.getKuryeSecimi());
			}
			else {
				// bir basvuru kaydi yoksa on onaydir.
				// on onay icin basvuru bilgileri tx tablosundan doldurulur.
				List<?> birBasvuruTxList = session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("durumKodu", "ON_ONAY")).addOrder(Order.asc("txNo")).list();
				if (birBasvuruTxList != null && !birBasvuruTxList.isEmpty()) {
					BirBasvuruTx birBasvuruTx = (BirBasvuruTx) birBasvuruTxList.get(0);
					BigDecimal onOnayTxNo = birBasvuruTx.getTxNo();

					oMap.put("KANAL_KODU", birBasvuruTx.getKanalKodu());
					oMap.put("DOSYA_MASRAFI", birBasvuruTx.getDosyaMasrafi());
					oMap.put("SIGORTA_PRIMI", birBasvuruTx.getSigortaPrimi());
					oMap.put("FARK_FAIZI", birBasvuruTx.getFarkFaizi());
					oMap.put("ODEME_TIPI", birBasvuruTx.getOdemeTipKod());
					oMap.put("ODEME_ORANI", birBasvuruTx.getOdemeTipOran());
					oMap.put("ODEME_PERIYODU", birBasvuruTx.getOdemeTipPeriyod());
					oMap.put("ODEME_TUTARI", birBasvuruTx.getOdemeTipTut());
					oMap.put("ODEME_VADESI", birBasvuruTx.getOdemeTipVade());
					oMap.put("KATILIM_BEDELI", birBasvuruTx.getSerbestKatkiPayi());
					oMap.put("FAIZ_ORANI", birBasvuruTx.getFaizOrani());
					oMap.put("SUBE_KOD", birBasvuruTx.getSubeKod());
					oMap.put("HESAP_NO", birBasvuruTx.getHesapNo());

					oMap.put("ADRES_BILGILERI_UYUMLUMU", birBasvuruTx.getApsBilgileriUyumlumu());
					oMap.put("KIMLIK_BILGILERI_UYUMLUMU", birBasvuruTx.getPttKpsBilgileriUyumlumu());
					oMap.put("GEC_TESLIM_NEDEN", birBasvuruTx.getGecTeslimatNeden());
					oMap.put("HESAP_KAPANSIN_MI", birBasvuruTx.getHesapKapansinMi());
					oMap.put("TAHSIS_NUMARASI", birBasvuruTx.getPttTahsisNumarasi());
					oMap.put("KAZANIM_TUR", birBasvuruTx.getKazanimTur());
					oMap.put("KREDI_TUR", birBasvuruTx.getKrediTur());

					BirBasvuruKimlikTx birBasvuruKimlik = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", onOnayTxNo)).uniqueResult();

					if (birBasvuruKimlik.getAdresteFaaliyetSuresi() != null) {
						String adresteFaaliyetSuresiYil = birBasvuruKimlik.getAdresteFaaliyetSuresi().substring(0, 2);
						{
							if (adresteFaaliyetSuresiYil.charAt(0) == '0')
								adresteFaaliyetSuresiYil = adresteFaaliyetSuresiYil.substring(1);
						}
						String adresteFaaliyetSuresiAy = birBasvuruKimlik.getAdresteFaaliyetSuresi().substring(2, 4);
						{
							if (adresteFaaliyetSuresiAy.charAt(0) == '0')
								adresteFaaliyetSuresiAy = adresteFaaliyetSuresiAy.substring(1);
						}
						oMap.put("FAALIYET_SURESI_YIL", adresteFaaliyetSuresiYil);
						oMap.put("FAALIYET_SURESI_AY", adresteFaaliyetSuresiAy);
					}
					if (birBasvuruKimlik.getAdresteOturmaSuresi() != null) {
						String adresteOturmaSuresiYil = birBasvuruKimlik.getAdresteOturmaSuresi().substring(0, 2);
						{
							if (adresteOturmaSuresiYil.charAt(0) == '0')
								adresteOturmaSuresiYil = adresteOturmaSuresiYil.substring(1);
						}
						String adresteOturmaSuresiAy = birBasvuruKimlik.getAdresteOturmaSuresi().substring(2, 4);
						{
							if (adresteOturmaSuresiAy.charAt(0) == '0')
								adresteOturmaSuresiAy = adresteOturmaSuresiAy.substring(1);
						}
						oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_YIL", adresteOturmaSuresiYil);
						oMap.put("MEVCUT_ADRESTE_OTURMA_SURESI_AY", adresteOturmaSuresiAy);
					}
					oMap.put("AYLIK_GELIR", birBasvuruKimlik.getAylikGelir() == null ? BigDecimal.ZERO : birBasvuruKimlik.getAylikGelir());
					oMap.put("CALISMA_SEKLI", birBasvuruKimlik.getCalismaSekli());
					oMap.put("DIGER_GELIR", birBasvuruKimlik.getDigerGelir() == null ? BigDecimal.ZERO : birBasvuruKimlik.getDigerGelir());
					oMap.put("OGRENIM_DURUMU", birBasvuruKimlik.getEgitimDurumKod());
					if (birBasvuruKimlik.getEMail() != null && birBasvuruKimlik.getEMail().length() > 1) {
						oMap.put("EMAIL1", birBasvuruKimlik.getEMail().substring(0, birBasvuruKimlik.getEMail().indexOf('@')));
						oMap.put("EMAIL2", birBasvuruKimlik.getEMail().substring(birBasvuruKimlik.getEMail().indexOf('@') + 1));
					}
					oMap.put("ES_GELIRI", birBasvuruKimlik.getEsGeliri() == null ? BigDecimal.ZERO : birBasvuruKimlik.getEsGeliri());
					oMap.put("EV_ADRESI", birBasvuruKimlik.getEvAdres());
					oMap.put("EV_ILCE", birBasvuruKimlik.getEvAdrIlceKod());
					oMap.put("EV_IL", birBasvuruKimlik.getEvAdrIlKod());
					oMap.put("EV_POSTA_KODU", birBasvuruKimlik.getEvPostakod());
					oMap.put("EV_TEL_KOD", birBasvuruKimlik.getEvTelAlan());
					oMap.put("EV_TEL_NO", birBasvuruKimlik.getEvTelNo());
					oMap.put("IKAMET_DURUMU", birBasvuruKimlik.getIkametDurumKod());
					oMap.put("IS_ADRESI", birBasvuruKimlik.getIsAdres());
					oMap.put("IS_ILCE", birBasvuruKimlik.getIsAdrIlceKod());
					oMap.put("IS_IL", birBasvuruKimlik.getIsAdrIlKod());
					oMap.put("IS_POSTA_KODU", birBasvuruKimlik.getIsPostakod());
					oMap.put("IS_TEL_KOD", birBasvuruKimlik.getIsTelAlan());
					oMap.put("IS_TEL_DAHILI", birBasvuruKimlik.getIsTelDahili());
					oMap.put("IS_TEL_NO", birBasvuruKimlik.getIsTelNo());
					oMap.put("ISYERI_ADI", birBasvuruKimlik.getIsyeriAdi());
					oMap.put("ISYERI_FAALIYET_ALANI", birBasvuruKimlik.getIsyeriFaalKonuKod());
					oMap.put("ISYERI_MULKIYET", birBasvuruKimlik.getIsyeriMulkiyetKod());

					if (birBasvuruKimlik.getIsyerindeCalismaSuresi() != null) {
						String isyerindeCalismaSuresiYil = birBasvuruKimlik.getIsyerindeCalismaSuresi().substring(0, 2);
						{
							if (isyerindeCalismaSuresiYil.charAt(0) == '0')
								isyerindeCalismaSuresiYil = isyerindeCalismaSuresiYil.substring(1);
						}
						String isyerindeCalismaSuresiAy = birBasvuruKimlik.getIsyerindeCalismaSuresi().substring(2, 4);
						{
							if (isyerindeCalismaSuresiAy.charAt(0) == '0')
								isyerindeCalismaSuresiAy = isyerindeCalismaSuresiAy.substring(1);
						}
						oMap.put("ISYERINDE_CALISMA_SURESI_YIL", isyerindeCalismaSuresiYil);
						oMap.put("ISYERINDE_CALISMA_SURESI_AY", isyerindeCalismaSuresiAy);
					}
					oMap.put("ISYERI_VERGI_DAIRESI_ADI", birBasvuruKimlik.getIsyeriVergiDaireKodu());
					oMap.put("ISYERI_VERGI_DAIRESI_IL", birBasvuruKimlik.getIsyeriVergiIlKodu());
					oMap.put("ISYERI_VERGI_NO", birBasvuruKimlik.getIsyeriVergiNo());
					oMap.put("GMENKUL_GELIR", birBasvuruKimlik.getMenkulGmenkulGeliri() == null ? BigDecimal.ZERO : birBasvuruKimlik.getMenkulGmenkulGeliri());
					oMap.put("MESLEK", birBasvuruKimlik.getMeslekKod());
					oMap.put("UNVANI", birBasvuruKimlik.getUnvanKod());
					oMap.put("YAZISMA_ADRESI_EV", "E".equals(birBasvuruKimlik.getYazismaAdresKod()));
					oMap.put("YAZISMA_ADRESI_IS", "I".equals(birBasvuruKimlik.getYazismaAdresKod()));
					oMap.put("SIGORTALI_MI", GuimlUtil.convertToCheckBoxSelected(birBasvuruKimlik.getSigortaliMi()));
					oMap.put("ULASIM_KART_NO", birBasvuruKimlik.getUlasimKartNo());

					oMap.put("MUH_ADR_E", StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("E"));
					oMap.put("MUH_ADR_H", StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("H"));
					oMap.put("MUH_ADR_B", StringUtils.isNotBlank(birBasvuruKimlik.getMuhtarlikAdresEhb()) && birBasvuruKimlik.getMuhtarlikAdresEhb().equals("B"));

					oMap.put("ADR_AYNI_E", StringUtils.isNotBlank(birBasvuruKimlik.getTeslimatAdresAyniEh()) && birBasvuruKimlik.getTeslimatAdresAyniEh().equals("E"));
					oMap.put("ADR_AYNI_H", StringUtils.isNotBlank(birBasvuruKimlik.getTeslimatAdresAyniEh()) && birBasvuruKimlik.getTeslimatAdresAyniEh().equals("H"));

					oMap.put("TESLIMAT_ADRES", birBasvuruKimlik.getTeslimatAdresi());
					oMap.put("TESLIMAT_IL", birBasvuruKimlik.getTeslimatAdrIlKod());
					oMap.put("TESLIMAT_ILCE", birBasvuruKimlik.getTeslimatAdrIlceKod());
					oMap.put("TESLIMAT_POSTA_KODU", birBasvuruKimlik.getTeslimatPostakod());
					oMap.put("TESLIMAT_URUN_KIME", birBasvuruKimlik.getTeslimatKisi());
					oMap.put("TESLIMAT_TCKN", birBasvuruKimlik.getTeslimatKisiTckn());
					oMap.put("TESLIMAT_FARKLI_OLMA_NEDENI", birBasvuruKimlik.getTeslimatFarkliOlmaNedeni());
					/** TY-6310 TY-tahsis izleme ekranlar�na teslimat adresi farkl� olma nedeni eklenmesi hk. */
					oMap.put("TESLIMAT_FARKLI_OLMA_NEDENI_DESC", GMServiceExecuter.execute("BNSPR_TRN3172_GET_TESLIMAT_FARKLI_OLMA_NEDENI_DESCRIPTION", oMap).get("TESLIMAT_FARKLI_OLMA_NEDENI_DESC"));

					if (StringUtils.isNotBlank(birBasvuruKimlik.getKimlik2KartIlk6())) {
						oMap.put("KART1", birBasvuruKimlik.getKimlik2KartIlk6().substring(0, 4));
						oMap.put("KART2", birBasvuruKimlik.getKimlik2KartIlk6().substring(4));
					}

					oMap.put("KART3", birBasvuruKimlik.getKimlik2KartSon4());
					oMap.put("IKINCI_KIMLIK_TIPI", birBasvuruKimlik.getKimlik2Tip());
					oMap.put("TEYIT_EDILEN_GELIR", birBasvuruKimlik.getTeyitEdilenGelir() == null ? BigDecimal.ZERO : birBasvuruKimlik.getTeyitEdilenGelir());

					List<?> limitList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", onOnayTxNo)).list();
					String tableName = "TEMINAT_TABLE";
					int row = 0;
					for (Iterator<?> iterator = limitList.iterator(); iterator.hasNext();) {
						BirBasvuruTeminatTx birBasvuruTeminat = (BirBasvuruTeminatTx) iterator.next();
						oMap.put(tableName, row, "TEMINAT", birBasvuruTeminat.getId().getTeminatKod());
						oMap.put(tableName, row, "TEMINAT_TF", LovHelper.diLov(birBasvuruTeminat.getId().getTeminatKod(), "3171/LOV_TEMINAT", "ACIKLAMA"));
						oMap.put(tableName, row, "ADET", birBasvuruTeminat.getTeminatAdedi());
						row++;
					}

					List<?> sigortaList = session.createCriteria(BirBasvuruSigortaSatisTx.class).add(Restrictions.eq("id.txNo", onOnayTxNo)).list();
					tableName = "SIGORTA_TABLE";
					row = 0;
					for (Iterator<?> iterator = sigortaList.iterator(); iterator.hasNext();) {
						BirBasvuruSigortaSatisTx birBasvuruSigortaSatisTx = (BirBasvuruSigortaSatisTx) iterator.next();
						oMap.put(tableName, row, "SIGORTA_SATIS_URUN", birBasvuruSigortaSatisTx.getId().getSigortaUrunNo());
						oMap.put(tableName, row, "ADET", "1");
						oMap.put(tableName, row, "PRIM", birBasvuruSigortaSatisTx.getSigortaPrimi());

						row++;
					}

					List<?> gorusList = session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", onOnayTxNo)).list();
					tableName = "GORUS_TABLE";
					row = 0;
					for (Iterator<?> iterator = gorusList.iterator(); iterator.hasNext();) {
						BirBasvuruGorusTx birBasvuruGorus = (BirBasvuruGorusTx) iterator.next();
						oMap.put(tableName, row, "BASVURU_GORUS", birBasvuruGorus.getId().getGorusKod());
						oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxValue(birBasvuruGorus.getEH()));
						row++;
					}

					String func = "{call Pkg_rc3173.get_teslimat_bilgileri(?,?,?)}";
					Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
					Object[] outputValues = { BnsprType.REFCURSOR, "TESLIMAT_TABLE", BnsprType.REFCURSOR, "URUN_TABLE" };
					oMap.putAll((GMMap) DALUtil.callOracleProcedure(func, inputValues, outputValues));
					oMap.put("KURYE_SECIMI", birBasvuruTx.getKuryeSecimi());
				}
			}

			// Basvuruya ait esgm sorgusundaki net gelir alani.
			String func = "{? = call pkg_ist_esgm.get_esgm_net_income(?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, oMap.getString("TAHSIS_NUMARASI") };
			BigDecimal esgmGelir = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			oMap.put("ESGM_GELIR", esgmGelir == null ? BigDecimal.ZERO : esgmGelir);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}

	@GraymoundService("BNSPR_TRN3172_BASVURU_GUNCELLE_LIST")
	public static GMMap getBasvuruGuncelleList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			String soyad = "%" + iMap.getString("SOYADI") + "%";
			String ad = "%" + iMap.getString("ADI") + "%";
			String ikinciAd = "%" + iMap.getString("IKINCI_ADI") + "%";

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3172.RC_QRY3172_GET_GUNCELLE_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("KANAL_ALT_KODU"));
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, soyad);
			stmt.setString(i++, ad);
			if (iMap.getString("IKINCI_ADI") != null && !iMap.getString("IKINCI_ADI").isEmpty())
				stmt.setString(i++, ikinciAd);
			else
				stmt.setString(i++, null);
			stmt.setString(i++, iMap.getString("KAMP_URUN_ADI"));

			if (iMap.getDate("BASLANGIC_TAR") != null)// && iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TAR").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("BITIS_TAR") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TAR").getTime()));
			else
				stmt.setDate(i++, null);
			stmt.setString(i++, iMap.getString("CALL_CENTER"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "BASVURU_BILGILERI");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3172_BASVURU_IPTAL")
	public static GMMap getBasvuruIptal(GMMap iMap) {
		try {
			GMMap xMap = new GMMap();
			iMap.put("ISLEM_SONRASI_DURUM_KODU", "IPTAL");
			xMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_BASVURU", iMap));
			xMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_BASVURU_DETAY", iMap));

			BigDecimal txNo = new BigDecimal((String) GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO"));

			xMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			xMap.put("ISLEM_SONRASI_DURUM_KODU", "IPTAL");
			xMap.put("AKSIYON_KOD", "C");
			xMap.put("SON_TX_NO", iMap.getBigDecimal("SON_TX_NO"));
			// if((iMap.getString("CALL_CENTER") != null) && iMap.getString("CALL_CENTER").equals("E")){
			xMap.put("AKSIYON_KARAR_KOD", iMap.getBigDecimal("AKSIYON_KARAR_KOD"));

			xMap.put("PTT_IPTAL", iMap.getString("PTT_IPTAL"));

			// }

			xMap.put("TRX_NO", txNo);
			GMMap oMap = new GMMap();

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_SAVE", xMap));

			iMap.put("MESSAGE_NO", new BigDecimal(1011));
			iMap.put("P1", iMap.getBigDecimal("BASVURU_NO").toString());

			oMap.put("MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_SAVE")
	public static Map<?, ?> saveTRN3172(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			if (iMap.getString("ANNE_KIZLIK_SOYADI") != null) {
				iMap.put("ANNE_KIZLIK_SOYADI", (iMap.getString("ANNE_KIZLIK_SOYADI")).trim());
			}

			BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.get(BirBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birBasvuruTx == null)
				birBasvuruTx = new BirBasvuruTx();

			birBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruTx.setAdcOwner(iMap.getString("ADC_OWNER"));
			birBasvuruTx.setSatisPersoneli(iMap.getBigDecimal("PERSONEL"));
			birBasvuruTx.setEveTeslimatliUrun(iMap.getString("EVE_TESLIM_URUN"));
			birBasvuruTx.setUrunTeslimTarihi(iMap.getDate("TESLIMAT_TARIHI"));
			birBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruTx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAFI"));
			birBasvuruTx.setDovizKodu(iMap.getString("DOVIZ_KOD"));
			if (iMap.getString("DURUM_KODU") == null || iMap.getString("DURUM_KODU").isEmpty())
				birBasvuruTx.setDurumKodu("BASVURU");
			else
				birBasvuruTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
				birBasvuruTx.setKampKod(iMap.getBigDecimal("URUN_KAMP_KOD"));
				birBasvuruTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
				birBasvuruTx.setKrediAltTur(null);
				birBasvuruTx.setKrediAltTur2(null);
			}
			else {
				birBasvuruTx.setKampKod(null);
				birBasvuruTx.setKampKnlKod(null);
				birBasvuruTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birBasvuruTx.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
			}
			birBasvuruTx.setKanalKodu(iMap.getString("KANAL_KOD"));
			if (iMap.containsKey("BAGLI_SUBE_KOD")) {
				birBasvuruTx.setBagliSubeKodu(iMap.getString("BAGLI_SUBE_KOD"));
			}
			birBasvuruTx.setKrediTur(iMap.getBigDecimal("KRD_TUR_KOD"));
			birBasvuruTx.setOdemeTipKod(iMap.getBigDecimal("ODEME_TIPI"));
			birBasvuruTx.setOdemeTipOran(iMap.getBigDecimal("ODEME_ORANI"));
			birBasvuruTx.setOdemeTipPeriyod(iMap.getBigDecimal("ODEME_PERIYODU"));
			birBasvuruTx.setOdemeTipTut(iMap.getBigDecimal("ODEME_TUTARI"));
			birBasvuruTx.setOdemeTipVade(iMap.getBigDecimal("ODEME_VADESI"));
			birBasvuruTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
			birBasvuruTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
			birBasvuruTx.setSaticiKod(iMap.getBigDecimal("KANAL_ALT_KOD"));
			if ((iMap.getString("SERBEST_KATKI_PAYI") != null && iMap.getString("SERBEST_KATKI_PAYI") != "H") || iMap.getBigDecimal("KATILIM_BEDELI") != null) {
				birBasvuruTx.setSerbestKatkiPayi(iMap.getBigDecimal("KATILIM_BEDELI"));
			}
			else {
				birBasvuruTx.setSerbestKatkiPayi(null);
			}
			birBasvuruTx.setTutar(iMap.getBigDecimal("HERSEY_DAHIL_TUTAR", iMap.getBigDecimal("TUTAR")));
			birBasvuruTx.setVade(iMap.getBigDecimal("VADE"));
			birBasvuruTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			birBasvuruTx.setSubeKod(iMap.getString("SUBE_KOD"));
			birBasvuruTx.setHesapNo(iMap.getString("HESAP_NO"));
			birBasvuruTx.setSessionIp(iMap.getString("SESSION_IP"));

			if ((iMap.getString("DOSYA_MASRAF_TIPI") != null && iMap.getString("DOSYA_MASRAF_TIPI") != "H") || iMap.getBigDecimal("SOZLESME_FAIZI") != null) {
				birBasvuruTx.setSozlesmeFaizi(iMap.getBigDecimal("SOZLESME_FAIZI"));
			}
			else {
				birBasvuruTx.setSozlesmeFaizi(null);
			}
			birBasvuruTx.setKpsYapildi(iMap.getString("KPS_YAPILDI"));
			birBasvuruTx.setGorus(iMap.getString("DIGER_GORUS"));
			birBasvuruTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			if (iMap.getString("ISLEM_SONRASI_DURUM_KODU") == null || iMap.getString("ISLEM_SONRASI_DURUM_KODU").isEmpty())
				birBasvuruTx.setIslemSonrasiDurumKodu("NBSM");
			else
				birBasvuruTx.setIslemSonrasiDurumKodu(iMap.getString("ISLEM_SONRASI_DURUM_KODU"));
			birBasvuruTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			birBasvuruTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));

			birBasvuruTx.setPttMaasAlinanKurum(iMap.getString("MAAS_ALINAN_KURUM"));
			birBasvuruTx.setPttOncekiMaasOdemeTarihi(iMap.getDate("ONCEKI_MAAS_ODEME_TARIHI"));
			birBasvuruTx.setPttSgkMaasTutar(iMap.getBigDecimal("MAAS_TUTARI"));
			birBasvuruTx.setPttSonMaasTarihi(iMap.getDate("SON_MAAS_TARIHI"));
			birBasvuruTx.setPttMaasTarihSikligi(iMap.getBigDecimal("MAAS_TARIH_SIKLIGI"));
			birBasvuruTx.setApsYapildimi(iMap.getString("APS_YAPILDIMI"));
			birBasvuruTx.setApsBilgileriUyumlumu(iMap.getString("ADRES_BILGILERI_UYUMLUMU"));
			birBasvuruTx.setPttKpsBilgileriUyumlumu(iMap.getString("KIMLIK_BILGILERI_UYUMLUMU"));

			if (iMap.containsKey("POSTA_CEK_HESABI")) {
				birBasvuruTx.setPttPostaCekiHesabi(iMap.getBigDecimal("POSTA_CEK_HESABI"));
			}
			if (iMap.containsKey("MAAS_PTT_DENMI")) {
				birBasvuruTx.setPttMaasPttDenmi(iMap.getString("MAAS_PTT_DENMI"));
			}
			if (iMap.containsKey("EMEKLI_MAAS_EVDENMI")) {
				birBasvuruTx.setPttMaasEvdenMi(iMap.getString("EMEKLI_MAAS_EVDENMI"));
			}
			if (iMap.containsKey("TAHSIS_NUMARASI")) {
				birBasvuruTx.setPttTahsisNumarasi(iMap.getString("TAHSIS_NUMARASI"));
			}
			birBasvuruTx.setBasvuruTutari(iMap.getBigDecimal("TUTAR"));

			// if (iMap.getString("PTT_IPTAL") == null){ // PTT taraf�ndan �ptal edildi�inde bu alanlar ezilmemeli
			//
			// if(iMap.containsKey("ISLEMIN_YAPILDIGI_IL")){
			// birBasvuruTx.setPttSubeIli(iMap.getString("ISLEMIN_YAPILDIGI_IL"));
			// }
			// if(iMap.containsKey("ISLEMIN_YAPILDIGI_MERKEZ")){
			// birBasvuruTx.setPttIsleminYapildigiMerkez(iMap.getString("ISLEMIN_YAPILDIGI_MERKEZ"));
			// }
			// if(iMap.containsKey("ISLEMIN_YAPILDIGI_SUBE")){
			// birBasvuruTx.setPttIsleminYapildigiSube(iMap.getString("ISLEMIN_YAPILDIGI_SUBE"));
			// }
			//
			// }

			birBasvuruTx.setGecTeslimatNeden(iMap.getString("GEC_TESLIM_NEDEN"));
			birBasvuruTx.setHesapKapansinMi(iMap.getString("HESAP_KAPANSIN_MI"));
			birBasvuruTx.setKazanimTur(iMap.getString("KAZANIM_TUR"));

			session.saveOrUpdate(birBasvuruTx);

			BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birBasvuruKimlikTx == null) {
				birBasvuruKimlikTx = new BirBasvuruKimlikTx();
				birBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			birBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruKimlikTx.setAd(iMap.getString("ADI"));
			birBasvuruKimlikTx.setAdresteFaaliyetSuresi(concatYilAy(iMap.getString("FAALIYET_SURESI_YIL"), iMap.getString("FAALIYET_SURESI_AY"))); // ay
																																					// yil
																																					// birlestir
			birBasvuruKimlikTx.setAdresteOturmaSuresi(concatYilAy(iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_YIL"), iMap.getString("MEVCUT_ADRESTE_OTURMA_SURESI_AY"))); //
			birBasvuruKimlikTx.setAileSiraNo(iMap.getString("NUFUS_AILE_SIRA_NO"));
			birBasvuruKimlikTx.setAnneAdi(iMap.getString("ANNE_ADI"));
			birBasvuruKimlikTx.setAnneKizlik(iMap.getString("ANNE_KIZLIK_SOYADI"));
			birBasvuruKimlikTx.setAylikGelir(iMap.getBigDecimal("AYLIK_GELIR"));
			birBasvuruKimlikTx.setBabaAd(iMap.getString("BABA_ADI"));
			birBasvuruKimlikTx.setBireySiraNo(iMap.getString("NUFUS_SIRA_NO"));
			birBasvuruKimlikTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
			birBasvuruKimlikTx.setCepTelAlanKodu(iMap.getString("CEP_TEL_KOD"));
			birBasvuruKimlikTx.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			birBasvuruKimlikTx.setCiltNo(iMap.getString("NUFUS_CILT_NO"));
			birBasvuruKimlikTx.setCinsiyet(iMap.getString("CINSIYET"));
			birBasvuruKimlikTx.setDigerGelir(iMap.getBigDecimal("DIGER_GELIR"));
			birBasvuruKimlikTx.setDogumTar(iMap.getDate("DOGUM_TARIHI"));
			birBasvuruKimlikTx.setDogumYeri(iMap.getString("DOGUM_YERI"));
			birBasvuruKimlikTx.setEgitimDurumKod(iMap.getString("OGRENIM_DURUMU"));
			if ((iMap.getString("EMAIL1") != null && !iMap.getString("EMAIL1").isEmpty()) && (iMap.getString("EMAIL2") != null && !iMap.getString("EMAIL2").isEmpty())) {
				birBasvuruKimlikTx.setEMail(iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));
			}
			else {
				birBasvuruKimlikTx.setEMail("");
			}
			birBasvuruKimlikTx.setEsGeliri(iMap.getBigDecimal("ES_GELIRI") == null ? BigDecimal.ZERO : iMap.getBigDecimal("ES_GELIRI"));
			if (iMap.getString("EV_ADRESI") != null) {
				birBasvuruKimlikTx.setEvAdres(iMap.getString("EV_ADRESI").trim());
			}
			else {
				birBasvuruKimlikTx.setEvAdres("");
			}
			birBasvuruKimlikTx.setEvAdrIlceKod(iMap.getString("EV_ILCE"));
			birBasvuruKimlikTx.setEvAdrIlKod(iMap.getString("EV_IL"));
			birBasvuruKimlikTx.setEvAdrUlkeKod("TR");
			birBasvuruKimlikTx.setEvPostakod(iMap.getString("EV_POSTA_KODU"));
			if (iMap.getString("EV_TEL_NO") != null && !iMap.getString("EV_TEL_NO").isEmpty()) {
				birBasvuruKimlikTx.setEvTelAlan(iMap.getString("EV_TEL_KOD"));
				birBasvuruKimlikTx.setEvTelNo(iMap.getString("EV_TEL_NO"));
			}
			else {
				birBasvuruKimlikTx.setEvTelAlan("");
				birBasvuruKimlikTx.setEvTelNo("");
			}
			birBasvuruKimlikTx.setIkametDurumKod(iMap.getString("IKAMET_DURUMU"));
			birBasvuruKimlikTx.setIkinciAd(iMap.getString("IKINCI_ADI"));
			if (iMap.getString("IS_ADRESI") != null) {
				birBasvuruKimlikTx.setIsAdres(iMap.getString("IS_ADRESI").trim());
			}
			else {
				birBasvuruKimlikTx.setIsAdres("");
			}
			birBasvuruKimlikTx.setIsAdrIlceKod(iMap.getString("IS_ILCE"));
			birBasvuruKimlikTx.setIsAdrIlKod(iMap.getString("IS_IL"));
			birBasvuruKimlikTx.setIsAdrUlkeKod("TR");
			birBasvuruKimlikTx.setIsPostakod(iMap.getString("IS_POSTA_KODU"));
			if (iMap.getString("IS_TEL_NO") != null && !iMap.getString("IS_TEL_NO").isEmpty()) {
				birBasvuruKimlikTx.setIsTelAlan(iMap.getString("IS_TEL_KOD"));
				birBasvuruKimlikTx.setIsTelNo(iMap.getString("IS_TEL_NO"));
				birBasvuruKimlikTx.setIsTelDahili(iMap.getString("IS_TEL_DAHILI"));
			}
			else {
				birBasvuruKimlikTx.setIsTelAlan(iMap.getString(""));
				birBasvuruKimlikTx.setIsTelNo(iMap.getString(""));
				birBasvuruKimlikTx.setIsTelDahili(iMap.getString(""));
			}
			if (iMap.getString("ISYERI_ADI") != null) {
				birBasvuruKimlikTx.setIsyeriAdi(iMap.getString("ISYERI_ADI").trim());
			}
			else {
				birBasvuruKimlikTx.setIsyeriAdi("");
			}
			birBasvuruKimlikTx.setIsyeriFaalKonuKod(iMap.getString("ISYERI_FAALIYET_ALANI"));
			birBasvuruKimlikTx.setIsyeriMulkiyetKod(iMap.getString("ISYERI_MULKIYET"));
			birBasvuruKimlikTx.setIsyerindeCalismaSuresi(concatYilAy(iMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), iMap.getString("ISYERINDE_CALISMA_SURESI_AY")));
			birBasvuruKimlikTx.setIsyeriVergiDaireKodu(iMap.getString("ISYERI_VERGI_DAIRESI_ADI"));
			birBasvuruKimlikTx.setIsyeriVergiIlKodu(iMap.getString("ISYERI_VERGI_DAIRESI_IL"));
			if (iMap.getString("KAYIP_CUZDAN_SERI") != null)
				birBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_CUZDAN_SERI"));
			else if (iMap.getString("KAYIP_KIMLIK_SERI_NO") != null)
				birBasvuruKimlikTx.setKayipKimlikSeriNo(iMap.getString("KAYIP_KIMLIK_SERI_NO"));
			if (iMap.getString("KAYIP_CUZDAN_NO") != null)
				birBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_CUZDAN_NO"));
			else if (iMap.getString("KAYIP_KIMLIK_SIRA_NO") != null)
				birBasvuruKimlikTx.setKayipKimlikSiraNo(iMap.getString("KAYIP_KIMLIK_SIRA_NO"));
			birBasvuruKimlikTx.setKimlikSeriNo(iMap.getString("KIMLIK_SERI_NO") != null ? iMap.getString("KIMLIK_SERI_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSeriNoKps(iMap.getString("KIMLIK_SERI_NO_KPS") != null ? iMap.getString("KIMLIK_SERI_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNo(iMap.getString("KIMLIK_SIRA_NO") != null ? iMap.getString("KIMLIK_SIRA_NO").toUpperCase() : null);
			birBasvuruKimlikTx.setKimlikSiraNoKps(iMap.getString("KIMLIK_SIRA_NO_KPS") != null ? iMap.getString("KIMLIK_SIRA_NO_KPS").toUpperCase() : null);
			birBasvuruKimlikTx.setMedeniHal(iMap.getString("MEDENI_HAL"));
			birBasvuruKimlikTx.setMenkulGmenkulGeliri(iMap.getBigDecimal("GMENKUL_GELIR"));
			birBasvuruKimlikTx.setMeslekKod(iMap.getString("MESLEK"));
			birBasvuruKimlikTx.setNufusIlceKod(iMap.getString("NUFUS_ILCE_KOD"));
			birBasvuruKimlikTx.setNufusIlKod(iMap.getString("NUFUS_IL_KOD"));
			birBasvuruKimlikTx.setMahalleKoy(iMap.getString("NUFUS_MAHALLE"));
			birBasvuruKimlikTx.setNufusVerTar(iMap.getDate("NUFUS_VERILIS_TARIHI"));
			birBasvuruKimlikTx.setNufusVerNedeni(iMap.getString("NUF_VERILIS_NEDENI"));
			birBasvuruKimlikTx.setNufusVerYer(iMap.getString("NUF_VERILDIGI_YER"));
			birBasvuruKimlikTx.setOncekiSoyad(iMap.getString("ONCEKI_SOYADI"));
			birBasvuruKimlikTx.setSoyad(iMap.getString("SOYADI"));
			birBasvuruKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			birBasvuruKimlikTx.setEsTckn(iMap.getString("ES_TCKN"));
			birBasvuruKimlikTx.setUnvanKod(iMap.getString("UNVANI"));
			birBasvuruKimlikTx.setUyrukKod(iMap.getString("UYRUK"));
			birBasvuruKimlikTx.setIsyeriVergiNo(iMap.getString("ISYERI_VERGI_NO"));
			if (iMap.getBoolean("YAZISMA_ADRESI_EV"))
				birBasvuruKimlikTx.setYazismaAdresKod("E");
			else if (iMap.getBoolean("YAZISMA_ADRESI_IS"))
				birBasvuruKimlikTx.setYazismaAdresKod("I");

			birBasvuruKimlikTx.setSigortaliMi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("SIGORTALI_MI")));
			birBasvuruKimlikTx.setUlasimKartNo(iMap.getString("ULASIM_KART_NO"));
			birBasvuruKimlikTx.setKimlikKayitNo(iMap.getString("KIMLIK_KAYIT_NO"));

			if (iMap.getBoolean("MUH_ADR_E"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("E");
			else if (iMap.getBoolean("MUH_ADR_H"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("H");
			else if (iMap.getBoolean("MUH_ADR_B"))
				birBasvuruKimlikTx.setMuhtarlikAdresEhb("B");

			if (iMap.getBoolean("ADR_AYNI_E"))
				birBasvuruKimlikTx.setTeslimatAdresAyniEh("E");
			else if (iMap.getBoolean("ADR_AYNI_H")) {
				birBasvuruKimlikTx.setTeslimatAdresAyniEh("H");
				birBasvuruKimlikTx.setTeslimatAdresi(iMap.getString("TESLIMAT_ADRES"));
				birBasvuruKimlikTx.setTeslimatAdrIlKod(iMap.getString("TESLIMAT_IL"));
				birBasvuruKimlikTx.setTeslimatAdrIlceKod(iMap.getString("TESLIMAT_ILCE"));
				birBasvuruKimlikTx.setTeslimatPostakod(iMap.getString("TESLIMAT_POSTA_KODU"));
				birBasvuruKimlikTx.setTeslimatKisiTckn(iMap.getString("TESLIMAT_TCKN"));
				birBasvuruKimlikTx.setTeslimatFarkliOlmaNedeni(iMap.getString("TESLIMAT_FARKLI_OLMA_NEDENI"));
			}
			birBasvuruKimlikTx.setTeslimatKisi(iMap.getString("TESLIMAT_URUN_KIME"));
			if (StringUtils.isNotBlank(iMap.getString("KART1"))) {
				birBasvuruKimlikTx.setKimlik2KartIlk6(iMap.getString("KART1").concat(iMap.getString("KART2")));
			}

			birBasvuruKimlikTx.setKimlik2KartSon4(iMap.getString("KART3"));
			birBasvuruKimlikTx.setKimlik2Tip(iMap.getString("IKINCI_KIMLIK_TURU"));
			birBasvuruKimlikTx.setTeyitEdilenGelir(iMap.getBigDecimal("TEYIT_EDILEN_GELIR"));
			birBasvuruKimlikTx.setKampanyaBilgi(iMap.getString("KAMPANYA_BILGI"));
			session.saveOrUpdate(birBasvuruKimlikTx);
			boolean evliMi = iMap.getString("MEDENI_HAL").equals("1") && StringUtils.isNotBlank(iMap.getString("ES_TCKN"));
			if (evliMi) {
				GMServiceExecuter.execute("BNSPR_TRN3171_SAVE_ES_BILGILERI", iMap);
			}
			List<?> silTeminatList = session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayTeminatlar = silTeminatList.toArray();
			for (int i = 0; i < arrayTeminatlar.length; i++) {
				silTeminatList.remove(arrayTeminatlar[i]);
				session.delete(arrayTeminatlar[i]);
			}
			session.flush();

			String tableName = "TEMINAT_TABLE";
			List<?> teminatList = (List<?>) iMap.get(tableName);

			if (teminatList != null) {
				for (int i = 0; i < teminatList.size(); i++) {
					if (iMap.getString(tableName, i, "TEMINAT") == null || iMap.getString(tableName, i, "TEMINAT").isEmpty()) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "Teminat Ad�n�");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.teminatKod", iMap.getString(tableName, i, "TEMINAT"))).uniqueResult();
					if (birBasvuruTeminatTx != null) {
						iMap.put("HATA_NO", new BigDecimal(723));
						iMap.put("P1", "Teminat Tablosu");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					else {
						birBasvuruTeminatTx = new BirBasvuruTeminatTx();
						BirBasvuruTeminatTxId teminatId = new BirBasvuruTeminatTxId();
						teminatId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						teminatId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						teminatId.setTeminatKod(iMap.getString(tableName, i, "TEMINAT"));
						birBasvuruTeminatTx.setId(teminatId);
					}
					birBasvuruTeminatTx.setTeminatAdedi(iMap.getBigDecimal(tableName, i, "ADET"));
					// birBasvuruTeminatTx.setTeminatTipi(iMap.getString(tableName, i, "TEMINAT_ADI"));

					session.saveOrUpdate(birBasvuruTeminatTx);
				}
			}
			session.flush();

			tableName = "SIGORTA_TABLE";
			List<?> sigortaList = (List<?>) iMap.get(tableName);

			if (sigortaList != null) {
				for (int i = 0; i < sigortaList.size(); i++) {
					if (iMap.getString(tableName, i, "SIGORTA_SATIS_URUN") == null || iMap.getString(tableName, i, "SIGORTA_SATIS_URUN").isEmpty()) {
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "Sigorta Sat�� �r�n�");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					BirBasvuruSigortaSatisTx birBasvuruSigortaSatisTx = (BirBasvuruSigortaSatisTx) session.createCriteria(BirBasvuruSigortaSatisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.sigortaUrunNo", iMap.getBigDecimal(tableName, i, "SIGORTA_SATIS_URUN"))).uniqueResult();
					if (birBasvuruSigortaSatisTx == null) {
						birBasvuruSigortaSatisTx = new BirBasvuruSigortaSatisTx();

					}
					BirBasvuruSigortaSatisTxId id = new BirBasvuruSigortaSatisTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					id.setSigortaUrunNo(iMap.getBigDecimal(tableName, i, "SIGORTA_SATIS_URUN"));
					birBasvuruSigortaSatisTx.setId(id);
					birBasvuruSigortaSatisTx.setSigortaPrimi(iMap.getBigDecimal(tableName, i, "PRIM"));
					//
					session.saveOrUpdate(birBasvuruSigortaSatisTx);
				}
			}
			session.flush();

			List<?> silGorusList = session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			Object[] arrayGorusler = silGorusList.toArray();
			for (int i = 0; i < arrayGorusler.length; i++) {
				silGorusList.remove(arrayGorusler[i]);
				session.delete(arrayGorusler[i]);
			}
			session.flush();

			String gorusTable = "GORUS";
			List<?> gorusList = (List<?>) iMap.get(gorusTable);
			if (gorusList != null) {
				for (int i = 0; i < gorusList.size(); i++) {
					BirBasvuruGorusTx birBasvuruGorusTx = new BirBasvuruGorusTx();
					BirBasvuruGorusTxId birBasvuruGorusTxId = new BirBasvuruGorusTxId();

					birBasvuruGorusTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruGorusTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birBasvuruGorusTxId.setGorusKod(iMap.getString(gorusTable, i, "BASVURU_GORUS"));
					birBasvuruGorusTx.setId(birBasvuruGorusTxId);
					if (iMap.getString(gorusTable, i, "SEC").equals("1") || iMap.getBoolean(gorusTable, i, "SEC"))
						birBasvuruGorusTx.setEH("E");
					else
						birBasvuruGorusTx.setEH("H");
					session.save(birBasvuruGorusTx);
				}
			}
			session.flush();

			/* zaten art�k silinen kefillerin SIL alan� E oluyor  bk. BNSPR_TRN3171_KEFIL_SIL
			//BK-1681
			String kefilTable = "KEFIL_TABLE";
			List<?> kefilList = (List<?>)iMap.get(kefilTable);
			if(kefilList != null)
			{
				for(int i=0;i<kefilList.size();i++){
					if(iMap.getBoolean(kefilTable, i,"K_SIL")){
						BirBasvuruKefilTx birBasvuruKefilTx = (BirBasvuruKefilTx) session.createCriteria(BirBasvuruKefilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
						.add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
						.add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal(kefilTable, i, "KEFIL_NO"))).uniqueResult();
						birBasvuruKefilTx.setSil("E");
						session.save(birBasvuruKefilTx);
					}
				}
			}
			session.flush();
			*/

			GMMap oMap = new GMMap();

			iMap.put("TRX_NAME", "3172");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

			iMap.put("MESSAGE_NO", new BigDecimal(1156));
			oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unused")
	public static String concatYilAy(String yil, String ay) {
		String yilAy = new String();
		if ((yil != null && yil.equals("")) && (ay != null && ay.equals(""))) {
			return null;
		}
		if (yil == null) {
			if (ay == null) {
				return null;
			}
			else if (ay.length() == 0) {
				return null;
			}
			else if (ay.length() == 1) {
				return ("000" + ay);
			}
			else {
				return ("00" + ay);
			}
		}

		if (ay == null) {
			if (yil == null) {
				return null;
			}
			else if (yil.length() == 0) {
				return null;
			}
			else if (yil.length() == 1) {
				return ("0" + yil + "00");
			}
			else {
				return (yil + "00");
			}
		}
		if (yil.length() == 0 || yil.equals("0"))
			yilAy = "00";
		else if (yil.length() == 1)
			yilAy = "0" + yil;
		else
			yilAy = yil;
		if (ay.length() == 0 || ay.equals("0"))
			yilAy = yilAy + "00";
		else if (ay.length() == 1)
			yilAy = yilAy + "0" + ay;
		else
			yilAy = yilAy + ay;

		return yilAy;
	}

	@GraymoundService("BNSPR_TRN3172_GET_GORUS")
	public static GMMap getGetGorus(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = null;
			boolean isCheckedKanal = true;
			String tableName = "GORUS_TABLE";
			String digerGorus = null;
			boolean isTx = "E".equals(iMap.getString("TX_MI"));
			if (isTx) {
				list = session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
				BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
				digerGorus = birBasvuruTx.getGorus();
				isCheckedKanal = !iMap.getString("KANAL_KODU").equals("5");
			}
			else {
				list = session.createCriteria(BirBasvuruGorus.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				if (birBasvuru != null) {
					digerGorus = birBasvuru.getGorus();
				}
			}
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				String gorusKod = null;
				String secEH = null;
				if (isTx) {
					BirBasvuruGorusTx birBasvuruGorusTx = (BirBasvuruGorusTx) iterator.next();
					if (birBasvuruGorusTx != null) {
						gorusKod = birBasvuruGorusTx.getId().getGorusKod();
						secEH = birBasvuruGorusTx.getEH();
					}
				}
				else {
					BirBasvuruGorus birBasvuruGorus = (BirBasvuruGorus) iterator.next();
					gorusKod = birBasvuruGorus.getId().getGorusKod();
					secEH = birBasvuruGorus.getEH();
				}
				oMap.put(tableName, row, "BASVURU_GORUS", gorusKod);
				oMap.put(tableName, row, "GORUS", DALUtil.getResult("SELECT TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and KEY1 = '" + gorusKod + "' and nvl(KEY3,'A') = 'A' ORDER BY KEY1"));
				oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxValue(secEH));
				row++;
			}
			if ((oMap.get(tableName) == null) && isCheckedKanal) {
				oMap.putAll(ConsumerLoanTRN3171Services.getGorus(iMap));
			}
			oMap.put("DIGER_GORUS", digerGorus);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_GET_DIGER_GORUS")
	public static GMMap getDigerGorus(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			if ("E".equals(iMap.getString("TX_MI"))) {
				BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
				oMap.put("DIGER_GORUS", birBasvuruTx.getGorus());
			}
			else {
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				oMap.put("DIGER_GORUS", birBasvuru.getGorus());
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_GET_OLUMLU_GORUS")
	public static GMMap getOlumluGorus(GMMap iMap) {
		try {
			return getGorus("OLUMLU_GORUS", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_GET_OLUMSUZ_GORUS")
	public static GMMap getOlumsuzGorus(GMMap iMap) {
		try {
			return getGorus("OLUMSUZ_GORUS", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_GET_YENI_GORUS")
	public static GMMap getYeniGorus(GMMap iMap) {
		try {
			return getGorus("YENI_GORUS", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_GET_KEFIL_GORUS")
	public static GMMap getKefilGorus(GMMap iMap) {
		try {
			return getGorus("KEFIL_GORUS", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_KONSOLIDASYON_BILGI")
	public static GMMap getKonsolidasyonBilgi(GMMap iMap) {

		GMMap oMap = new GMMap();
		int i = 0;

		try {

			Session session = DAOSession.getSession("BNSPRDal");

			@SuppressWarnings("unchecked")
			List<BirBasvuruKonsolidasyon> list = session.createCriteria(BirBasvuruKonsolidasyon.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			Iterator<BirBasvuruKonsolidasyon> iterator = list.iterator();
			oMap.put("KONSOLIDASYON_EH", iterator.hasNext());
			StringBuffer basvuruStr = new StringBuffer();

			while (iterator.hasNext()) {
				BirBasvuruKonsolidasyon basvuru = iterator.next();

				oMap.put("BASVURULAR", i, "BASVURU_NO", basvuru.getId().getYapilandirilanBasvuruNo());
				oMap.put("BASVURULAR", i++, "KONSOLIDASYON_EH", "E".equals(basvuru.getKapamaEh()) ? true : false);

				if ("E".equals(basvuru.getKapamaEh())) {
					basvuruStr.append(basvuru.getId().getYapilandirilanBasvuruNo() + ",");
				}

			}

			oMap.put("BASVURU_STR", new String(basvuruStr.substring(0, basvuruStr.length() - 1)));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * �M ilk ekran metinlerini olu�turur
	 * 
	 * @author mehmet.uluturk
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN3172_SCRIPT_OLUSTUR")
	public static GMMap scriptOlustur(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

			BigDecimal trxNo = (BigDecimal) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).setProjection(Projections.max("txNo")).uniqueResult();
			BirBasvuruKimlikTx kimlik = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("txNo", trxNo)).uniqueResult();

			iMap.put("TC_KIMLIK_NO", kimlik.getTcKimlikNo());
			iMap.put("CEP_TEL", kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo()));

			GMServiceExecuter.call("BNSPR_TRN3172_KVKK_SMS", iMap);

			BirAdkBasvuru adk = (BirAdkBasvuru) session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			iMap.put("LIMIT_TURU", adk.getAkisTuru());
			// oMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_CL_GET_ON_ONAY_BILGI", iMap));
			oMap = GMServiceExecuter.call("BNSPR_CL_GET_ON_ONAY_BILGI", iMap);

			if (oMap.get("KREDI_TURU") != null) {

				BigDecimal yillikFaiz = oMap.get("FAIZ_ORANI") != null ? oMap.getBigDecimal("FAIZ_ORANI").multiply(new BigDecimal(12)) : null;

				GMMap messageMap = new GMMap();
				messageMap.put("MESSAGE_NO", "6147");
				String yasalMetin = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE");
				if (oMap.get("KAPATILACAK_KREDI_ADET") != null && oMap.getBigDecimal("KAPATILACAK_KREDI_ADET").compareTo(BigDecimal.ZERO) > 0) {
					oMap.put("KONSOLIDASYON_EH", true);
					BigDecimal konsYillikFaiz = oMap.get("K_FAIZ_ORANI") != null ? oMap.getBigDecimal("K_FAIZ_ORANI").multiply(new BigDecimal(12)) : null;
					oMap.put("K_YASAL_METIN", String.format(yasalMetin, kimlik.getAd(), oMap.getString("K_AYLIK_TAKSIT"), oMap.getString("KONSOLIDASYON_VADE"), oMap.getString("KONSOLIDASYON_LIMIT"), oMap.getString("K_DOSYA_MASRAFI"), oMap.getString("K_FAIZ_ORANI"), oMap.getString("K_TOPLAM_TAKSIT_TUTARI"), oMap.getString("K_FAIZ_ORANI"), konsYillikFaiz, oMap.getString("K_COST_RATIO"), oMap.getString("K_GECIKME_FAIZ_ORAN")));

					messageMap = new GMMap();
					messageMap.put("P1", oMap.getString("KONSOLIDASYON_VADE"));
					messageMap.put("P2", oMap.getString("KONSOLIDASYON_LIMIT"));
					messageMap.put("P3", oMap.getString("KONSOLIDASYON_MIN_TUTAR"));

					if (oMap.getBigDecimal("KAPATILACAK_KREDI_ADET").compareTo(oMap.getBigDecimal("ACIK_KREDI_ADET")) != 0) {
						// K�smi konsolidasyon 6150
						messageMap.put("MESSAGE_NO", "6150");
						oMap.put("SCRIPT", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE"));
					}
					else {
						// Tam kapama konsolidasyon 6149
						messageMap.put("MESSAGE_NO", "6149");
						oMap.put("SCRIPT", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE"));
					}
				}
				else {
					oMap.put("KONSOLIDASYON_EH", false);
				}

				if (oMap.getBigDecimal("TUTAR") != null && oMap.getBigDecimal("TUTAR").signum() > 0) {
					oMap.put("NAKIT_EH", true);
					oMap.put("YASAL_METIN", String.format(yasalMetin, kimlik.getAd(), oMap.getString("AYLIK_TAKSIT"), oMap.getString("VADE"), oMap.getString("TUTAR"), oMap.getString("DOSYA_MASRAFI"), oMap.getString("FAIZ_ORANI"), oMap.getString("TOPLAM_TAKSIT_TUTARI"), oMap.getString("FAIZ_ORANI"), yillikFaiz, oMap.getString("COST_RATIO"), oMap.getString("GECIKME_FAIZ_ORAN")));
				}
				else {
					oMap.put("NAKIT_EH", false);
				}
			}
			else {
				oMap.put("HATA", "�n onay yok");
				oMap.put("KONSOLIDASYON_EH", false);
				oMap.put("NAKIT_EH", false);
			}
			return oMap;
		}
		catch (Exception e) {
			oMap.put("HATA", e.getMessage());
			oMap.put("KONSOLIDASYON_EH", false);
			oMap.put("NAKIT_EH", false);
			return oMap;
		}
	}

	/**
	 * �M ilk ekran bilgilerini kaydetme
	 * 
	 * @author mehmet.uluturk
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN3172_ONONAY_GUNCELLE")
	public static GMMap ononayGuncelle(GMMap iMap) {
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

			BirBasvuruTx tx = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("durumKodu", "ON_ONAY")).uniqueResult();

			if (tx != null) {
			tx.setOnayTutar(iMap.getBigDecimal("TUTAR"));
			tx.setVade(iMap.getBigDecimal("VADE"));
			tx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			tx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));

			session.saveOrUpdate(tx);
			session.flush();
			}
			
			BirBasvuru basvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if (basvuru != null) {
				basvuru.setOnayTutar(iMap.getBigDecimal("TUTAR"));
				basvuru.setVade(iMap.getBigDecimal("VADE"));
				basvuru.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
				basvuru.setKampKod(iMap.getBigDecimal("KAMP_KOD"));

				session.saveOrUpdate(basvuru);
				session.flush();
			}
			
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_CHECK_TCKN")
	public static GMMap checkTckn(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_basvuru.BasvuruVarMi_TCKN(?) }");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("TCKN"));

			stmt.execute();

			oMap.put("SONUC", stmt.getBigDecimal(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_TRN3172_CHECK_BASVURU_NO")
	public static GMMap checkBasvuruNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_basvuru.BasvuruVarMi_BasvuruNo(?) }");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			oMap.put("SONUC", stmt.getBigDecimal(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_TRN3172_GET_ONAY_STATU_LIST")
	public static GMMap getOnayStatuList(GMMap iMap) {
		return DALUtil.fillComboBox(iMap, "DURUM_LIST", true, "select key1,text from v_ml_gnl_param_text where kod = 'ONAY_STATU_KOD' and key1 in ('BASVURU','KANALIADE')");
	}

	@GraymoundService("BNSPR_TRN3172_GET_KANAL_KODLARI")
	public static GMMap getKanalKodlari(GMMap iMap) {
		try {
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("LIST_NAME", "KANAL_KODLARI");
			StringBuffer query = new StringBuffer();
			query.append("select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr ");
			if (("E").equals(iMap.getString("CALL_CENTER")))
				query.append("where kod in ('5', '3', '8','7') ");
			query.append("order by 1");
			iMap.put("LIST_QUERY", query.toString());
			DALUtil.fillComboBox(iMap);
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_KPS_KIMLIK_SORGULAMA")
	public static Map<?, ?> kpsDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			// oMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", iMap));
			if (oMap.getString("OLUM_TARIHI") != null) {
				oMap.put("KPS_LOG", "SHOW_MESSAGE");
				iMap.put("HATA_NO", "918");
				iMap.put("P1", oMap.getString("OLUM_TARIHI").substring(6, 8) + "/" + oMap.getString("OLUM_TARIHI").substring(4, 6) + "/" + oMap.getString("OLUM_TARIHI").substring(0, 4));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if ("5".equals(oMap.getString("DURUMU"))) {
				oMap.put("KPS_LOG", "SHOW_MESSAGE");
				iMap.put("HATA_NO", "2087");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (oMap.getString("TCKNO_OUT") != null) {
				iMap.put("DOGUM_TARIHI", oMap.getDate("DOGUM_TARIHI"));
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
			}
			if (oMap.getString("ANA_SOYAD") == null || oMap.getString("ANA_SOYAD").trim().length() == 0) {
				oMap.put("ANA_SOYAD", iMap.get("ANA_SOYAD"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3172_GET_SIGORTA_URUNLERI")
	public static GMMap getSigortaUrunleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3172.Get_Sigorta_Urunleri(?)}");

			stmt.registerOutParameter(1, -10);

			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "SIGORTA_LIST");

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3172_CAPTCHA_SOLVE")
	public static GMMap getApplicationCaptcha(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			iMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(iMap.getDate("DOGUM_YILI")));
			iMap.put("RAISE_ERROR", "N");
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3180_WEB_BILGILERI_GETIR", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3172_CONTROL_ESGM_INCOME")
	public static GMMap controlEsgmIncome(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call pkg_trn3172.ptt_ilk_maas_kontrol(?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
			String maasKontrol = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);

			if ("E".equals(maasKontrol)) {
				BigDecimal esgmGelir = (iMap.get("ESGM_GELIR") == null || iMap.getString("ESGM_GELIR").isEmpty()) ? BigDecimal.ZERO : iMap.getBigDecimal("ESGM_GELIR");
				BigDecimal aylikGelir = (iMap.get("AYLIK_GELIR") == null || iMap.getString("AYLIK_GELIR").isEmpty()) ? BigDecimal.ZERO : iMap.getBigDecimal("AYLIK_GELIR");

				func = "{? = call pkg_ist_esgm.control_esgm_income(?,?)}";
				Object[] inputValues2 = { BnsprType.NUMBER, esgmGelir, BnsprType.NUMBER, aylikGelir };
				BigDecimal result = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues2);
				if (result.compareTo(BigDecimal.ONE) == 0) {
					oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", "4174")));
				}
				else {
					oMap.put("ERROR_MESSAGE", "");
				}
				oMap.put("KONTROL", "E");
			}
			else {
				oMap.put("KONTROL", "H");
				oMap.put("ERROR_MESSAGE", "");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3172_PTT_IPTAL_BASVURU_TCKN")
	public static GMMap pttIptalBasvuruTckn(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call pkg_ptt_basvuru.basvuru_bilgi_tckn(?) }";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("TCKN") };
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BASVURU_LIST", inputValues));
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static GMMap getGorus(String tableName, GMMap iMap) {
		Map<String, String> gorusMap = new HashMap<String, String>();
		gorusMap.put("OLUMLU_GORUS", "1");
		gorusMap.put("OLUMSUZ_GORUS", "2");
		gorusMap.put("YENI_GORUS", "3");
		gorusMap.put("KEFIL_GORUS", "5");
		String gorusKod = gorusMap.get(tableName);
		GMMap oMap = new GMMap();
		int row = 0;
		int sayi = 0;
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = null;
		boolean isCheckedKanal = true;
		if ("E".equals(iMap.getString("TX_MI"))) {
			list = session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			isCheckedKanal = !iMap.getString("KANAL_KODU").equals("5");
		}
		else {
			list = session.createCriteria(BirBasvuruGorus.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
		}
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			BirBasvuruGorus birBasvuruGorus = (BirBasvuruGorus) iterator.next();
			if (gorusKod.equals(DALUtil.getResult("SELECT KEY2 FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and KEY1 = '" + birBasvuruGorus.getId().getGorusKod() + "' and nvl(KEY3,'A') = 'A'"))) {
				oMap.put(tableName, row, "BASVURU_GORUS", birBasvuruGorus.getId().getGorusKod());
				oMap.put(tableName, row, "GORUS", DALUtil.getResult("SELECT TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'BAYI_BASVURU_GORUS_KOD' and KEY1 = '" + birBasvuruGorus.getId().getGorusKod() + "'"));
				oMap.put(tableName, row, "SEC", GuimlUtil.convertToCheckBoxValue(birBasvuruGorus.getEH()));
				if ("E".equals(birBasvuruGorus.getEH())) {
					sayi++;
				}
				row++;
			}
		}
		if ((oMap.get(tableName) == null) && isCheckedKanal) {
			if ("1".equals(gorusKod)) {
				oMap.putAll(ConsumerLoanTRN3171Services.getOlumluGorus(iMap));
			}
			if ("2".equals(gorusKod)) {
				oMap.putAll(ConsumerLoanTRN3171Services.getOlumsuzGorus(iMap));
			}
			if ("3".equals(gorusKod)) {
				oMap.putAll(ConsumerLoanTRN3171Services.getYeniGorus(iMap));
			}
			else {
				oMap.put(tableName + "_SAYISI", sayi);
			}
			if ("5".equals(gorusKod)) {
				oMap.putAll(ConsumerLoanTRN3171Services.getKefilGorus(iMap));
			}
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3172_BASVURU_ILERLET")
	public static GMMap basvuruIlerlet(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap appMap = new GMMap();
		String keyword = "STANDART";
		try {
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}

			appMap = GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU", iMap);
			appMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU_DETAY", iMap));

			appMap.putAll(iMap); // yeni gelen degerleri koy..
			GMServiceExecuter.executeNT("BNSPR_TRN3171_CONTROL", appMap);

			if (!"E".equals(iMap.getString("SKIP_DEVAM_SORGU"))) {
				iMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_DEVAM_SORGULAR", iMap));
			}

			if ("E".equals(iMap.getString("DEVAM"))) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", iMap));

				if ("E".equals(oMap.getString("DEVAM"))) {
					oMap.put("KANAL_KODU", appMap.get("KANAL_KODU"));
					oMap.put("VADE", appMap.get("VADE"));
					oMap.put("TUTAR", appMap.get("TUTAR"));
					oMap.put("KANAL_KOD", appMap.get("KANAL_KODU"));
					oMap.put("DOVIZ_KODU", "TRY");
					oMap.put("KREDI_TURU", appMap.get("KREDI_TURU"));

					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3113_KAMPANYA_BUL", oMap));

					if (oMap.get("MINI_KREDI_LIMIT") != null && oMap.getBigDecimal("MINI_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "MINI";
					}
					else if (oMap.get("UPSELL_KREDI_LIMIT") != null && oMap.getBigDecimal("UPSELL_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "UPSELL";
					}
					else if (oMap.get("DUSUK_FAIZ_KREDI_LIMIT") != null && oMap.getBigDecimal("DUSUK_FAIZ_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "LOWINTEREST";
					}
					else if (oMap.get("KONSOLIDASYON_KREDI_LIMIT") != null && oMap.getBigDecimal("KONSOLIDASYON_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "CONSOLIDATION";
					}
					else if (oMap.get("SPOT_KREDI_LIMIT") != null && oMap.getBigDecimal("SPOT_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "SPOT";
					}
					else if (oMap.get("ONONAY_KREDI_LIMIT") != null && oMap.getBigDecimal("ONONAY_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "PREAPPROVED";
					}
					else if (oMap.get("NORMAL_KREDI_LIMIT") != null && oMap.getBigDecimal("NORMAL_KREDI_LIMIT").compareTo(appMap.getBigDecimal("TUTAR")) < 0) {
						keyword = "DOWNSELL";
					}

					oMap.put("KEYWORD", keyword);
				}
			}
			else {
				oMap.putAll(iMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/** TY-6310 TY-tahsis izleme ekranlar�na teslimat adresi farkl� olma nedeni eklenmesi hk. */
	@GraymoundService("BNSPR_TRN3172_GET_TESLIMAT_FARKLI_OLMA_NEDENI_DESCRIPTION")
	public static GMMap getTeslimatFarkliOlmaNedeniDescription(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("select text from v_ml_gnl_param_text where kod = 'TESLIMAT_FARKLI_OLMA_NEDENI' and key1 = ? and key2 = ? order by sira_no");

			stmt.setString(1, iMap.getString("TESLIMAT_FARKLI_OLMA_NEDENI"));
			stmt.setString(2, iMap.getString("TESLIMAT_URUN_KIME"));
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				oMap.put("TESLIMAT_FARKLI_OLMA_NEDENI_DESC", rs.getString("TEXT"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	/** TY-6900 TY-Bireysel krediler Servis �al��malar� _3179 ve 3225 ekranlar� i�in */
	@GraymoundService("BNSPR_TRN3172_BASVURU_GUNCELLEME_YAPILABILIR_MI")
	public static GMMap getGuncellemeYapilabilirMi(GMMap iMap) {
		GMMap tMap = new GMMap();
		ArrayList<String> tarrList = new ArrayList<String>();
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADI", "");
			iMap.put("SOYADI", "");

			tMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_BASVURU_GUNCELLE_LIST", iMap));

			if (tMap.containsKey("BASVURU_BILGILERI")) {
				tarrList = (ArrayList<String>) tMap.get("BASVURU_BILGILERI");
			}

			if (tMap.containsKey("BASVURU_BILGILERI") && tarrList.size() > 0) {
				oMap.put("BASVURU_GUNCELLEME_YAPILABILIR_MI", "E");
			}
			else {
				oMap.put("BASVURU_GUNCELLEME_YAPILABILIR_MI", "H");
			}
		}
		catch (Exception e) {
			oMap.put("BASVURU_GUNCELLEME_YAPILABILIR_MI", "H");
		}
		return oMap;
	}

	/** PY-16299 PTT SMS Kredi */
	@GraymoundService("BNSPR_TRN3172_GET_TAKSIT_TUTARI")
	public static GMMap getTaksitTutari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("TAKSIT_TUTARI", DALUtil.callOneParameterFunction("{? = call pkg_trn3172.get_taksit_tutari(?)}", Types.DECIMAL, iMap.getBigDecimal("BASVURU_NO")));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/** PY-16299 PTT SMS Kredi */
	@GraymoundService("BNSPR_TRN3172_GET_TAKSIT_AY_GUNU")
	public static GMMap getTaksitAyGunu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("TAKSIT_AY_GUNU", DALUtil.callOneParameterFunction("{? = call pkg_trn3172.get_taksit_ay_gunu(?)}", Types.BIGINT, iMap.getBigDecimal("BASVURU_NO")));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/** PY-16299 PTT SMS Kredi */
	@GraymoundService("BNSPR_TRN3172_CREATE_AGREEMENT")
	public static GMMap createAggrement(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO", iMap));

			oMap.put("CALISMA_SEKLI_KOD", sMap.get("CALISMA_SEKLI_KOD"));
			oMap.put("TBL_BELGE", sMap.get("TBL_BELGE"));

			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			sMap.put("TRX_NO", iMap.get("TRX_NO"));
			sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sMap.put("EKRAN_NO", "3181");
			if (iMap.containsKey("TAKSIT_GUNU") && iMap.get("TAKSIT_GUNU") != null) {
				sMap.put("TAKSIT_GUNU", iMap.get("TAKSIT_GUNU"));
				sMap.put("AY_SONU", "H");
				sMap.put("FARK_FAIZ", iMap.get("FARK_FAIZ"));
				sMap.put("FAIZ_ODEME_SEKLI", iMap.get("FAIZ_ODEME_SEKLI"));
				sMap.put("GECIKME_GUN_SAYISI", iMap.get("GECIKME_GUN_SAYISI"));
				sMap.put("ILK_TAKSIT_TARIHI", iMap.get("ILK_TAKSIT_TARIHI"));
			}
			else {
				sMap.put("TAKSIT_GUNU", Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
			}

			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_SAVE", sMap));
			oMap.put("SOZLESME_HESAP_NO", sMap.get("SOZLESME_HESAP_NO"));
			oMap.put("TRX_NO", sMap.get("TRX_NO"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/** PY-16299 PTT SMS Kredi */
	@GraymoundService("BNSPR_TRN3172_SAVE_AGREEMENT")
	public static GMMap saveAggrement(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		GMMap bMap = new GMMap();
		GMMap pMap = new GMMap();
		String belgeKodu = null;
		Session session = DAOSession.getSession("BNSPRDal");

		try {
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			for (int i = 0; i < iMap.getSize("TBL_BELGE"); i++) {
				iMap.put("TBL_BELGE", i, "ALINDI", true);
			}

			sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sMap.put("TRX_NO", iMap.get("AGREEMENT_TRX_NO"));
			sMap.put("TBL_BELGE", iMap.get("TBL_BELGE"));
			sMap.put("BELGE_KONTROL", true);
			sMap.put("TEYIT_GEREKLI", false);
			sMap.put("CALISMA_SEKLI_KOD", iMap.get("CALISMA_SEKLI_KOD"));
			sMap.put("KANAL_KODU", birBasvuru.getKanalKodu());
			// GMServiceExecuter.executeNT("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", sMap)
			sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", sMap));

			session.refresh(birBasvuru);

			if ("KUL".equals(birBasvuru.getDurumKodu())) {
				pMap.put("PARAMETRE", "BIR_PTT_SMS_KURYE_BELGELER");
				String kuryeBelgeler = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", pMap).getString("DEGER", "-1");
				bMap.put("BARKOD_NUMARASI", DALUtil.callOneParameterFunction("{? = call pkg_ptt_kredi.ptt_get_barkod_no_and_insert(?)}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO")));

				for (int j = 0; j < iMap.getSize("TBL_BELGE"); j++) {
					belgeKodu = iMap.getString("TBL_BELGE", j, "BELGE_KODU");
					bMap.put("BELGELER", j, "BELGE_KOD", belgeKodu);
					bMap.put("BELGELER", j, "BASVURU_NO", iMap.getString("BASVURU_NO"));
					bMap.put("BELGELER", j, "BELGE_ADI", iMap.getString("TBL_BELGE", j, "BELGE_ADI"));
					bMap.put("BELGELER", j, "ALINDI", "E");
					bMap.put("BELGELER", j, "KIMDEN_KOD", iMap.getString("TBL_BELGE", j, "KIMDEN"));
					bMap.put("BELGELER", j, "GELIS_TARIHI", new Date());
					if (kuryeBelgeler.contains("-" + belgeKodu + "-")) {
						bMap.put("BELGELER", j, "BELGE_KONTROL", "5");
						bMap.put("BELGELER", j, "BARKOD_NUMARASI", bMap.getString("BARKOD_NUMARASI"));
					}
					else {
						bMap.put("BELGELER", j, "ORJINAL_EVRAK_MI", "1");
						bMap.put("BELGELER", j, "BELGE_KONTROL", "1");
					}
					bMap.put("BELGELER", j, "ISLEM_TARIHI", new Date());
				}

				bMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				bMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
				bMap.put("CALISMA_TIPI", birBasvuru.getCalismaSekliKod());
				bMap.put("DURUM_KODU", "KUL");
				bMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				bMap.put("MUSTERI_ESLESTIRME", "false");
				bMap.put("OTOMATIK_KULLANDIRIM", "false");
				// GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3182_SAVE", bMap);
				GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", bMap);

				pMap.clear();
				pMap.put("BARCODE", bMap.getString("BARKOD_NUMARASI"));
				pMap.put("PROJECT_TYPE", "CLKSDYS");
				pMap.put("REFERENCE", iMap.getBigDecimal("BASVURU_NO"));
				pMap.put("STATUS", "1");

				GMServiceExecuter.call("DYS_SAVE_NEW_BARCODE_FOR_CLKS", pMap);

				GMServiceExecuter.call("BNSPR_CUSTOMER_SET_GROUP_PERSONAL_DATA_PERMISSION", new GMMap().put("CUSTOMER_NO", birBasvuru.getMusteriNo()).put("STATUS", "E").put("PRODUCT_CODE", "KREDI").put("IS_AUTHORIZED_TRANSACTION", "E"));

				ClksBirBasvuruBarkod clksBirBasvuruBarkod = (ClksBirBasvuruBarkod) session.createCriteria(ClksBirBasvuruBarkod.class).add(Restrictions.eq("barkodNumarasi", bMap.getString("BARKOD_NUMARASI"))).uniqueResult();
				clksBirBasvuruBarkod.setBarkodKullanildimi("E");
				clksBirBasvuruBarkod.setIslemTarihi(new Date());
				clksBirBasvuruBarkod.setIslemYapilanMerkez("0");
				clksBirBasvuruBarkod.setIsleminYapildigiIl("034");
				session.save(clksBirBasvuruBarkod);
				session.flush();
			}

			/** Sozlesme Basildi Yap **/
			GMServiceExecuter.execute("BNSPR_TRN3181_SOZLEZME_BASIM_EH", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/** PY-16299 PTT SMS Kredi */
	@GraymoundService("BNSPR_TRN3172_UPDATE_REZERV_HESAP")
	public static GMMap updateRezervHesap(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			MuhHesapRezerv muhHesapRezerv = (MuhHesapRezerv) session.createCriteria(MuhHesapRezerv.class).add(Restrictions.eq("id.hesapNo", iMap.getBigDecimal("SOZLESME_HESAP_NO"))).uniqueResult();
			if (muhHesapRezerv != null) {
				muhHesapRezerv.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				session.saveOrUpdate(muhHesapRezerv);
				session.flush();
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * PTT SMS Kredi sube basvurusuna donusum servisi
	 * 
	 * emre.cakmak
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN3172_UPDATE_APPLICATION")
	public static GMMap updateApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}

			GMMap appMap = GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU", iMap);
			
			BirKampanya birKampanya = (BirKampanya) session.get(BirKampanya.class, appMap.getBigDecimal("KAMP_KOD"));
			
			// SMS kampanyas� �ube kredisine d�n��t�r�l�r
			if("E".equals(birKampanya.getBirlestirmeEh())){
				appMap.put("KAMP_KOD", DALUtil.getResult("SELECT deger FROM bnspr.gnl_parametre WHERE KOD = 'PTT_SMS_SUBE_KONS_KAMP'"));
			}else{
				appMap.put("KAMP_KOD", DALUtil.getResult("SELECT deger FROM bnspr.gnl_parametre WHERE KOD = 'PTT_SMS_SUBE_EMEKLI_KAMP'"));
			}

			appMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU_DETAY", iMap));
			appMap.put("ISLEMIN_YAPILDIGI_IL", iMap.get("PTT_SUBE_ILI"));
			appMap.put("ISLEMIN_YAPILDIGI_MERKEZ", iMap.get("PTT_ISLEMIN_YAPILDIGI_MERKEZ"));
			appMap.put("ISLEMIN_YAPILDIGI_SUBE", iMap.get("PTT_ISLEMIN_YAPILDIGI_SUBE"));
			
			oMap.put("DURUM_KODU", appMap.get("DURUM_KODU"));
			oMap.put("TC_KIMLIK_NO", appMap.get("TC_KIMLIK_NO"));

			// appMap.putAll(iMap.getMap("APPLICATION_DETAIL"));

			sMap.put("KRD_TUR_KOD", appMap.getBigDecimal("KRD_TUR_KOD", new BigDecimal(1)));
			sMap.put("KAMP_URUN_ADI", appMap.getString("KAMP_KOD"));
			sMap.put("DOVIZ_KODU", appMap.getString("DOVIZ_KODU", "TRY"));
			sMap.put("KREDI_TUTARI", appMap.getBigDecimal("TUTAR"));
			sMap.put("KREDI_VADESI", appMap.getBigDecimal("VADE"));
			sMap.put("KANAL_KOD", appMap.getBigDecimal("KANAL_KOD", new BigDecimal(7)));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", sMap);

			sMap.put("TUTAR", appMap.getBigDecimal("TUTAR"));
			sMap.put("VADE", appMap.getBigDecimal("VADE"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", sMap));
			appMap.put("KAMP_KNL_KOD", sMap.get("KAMP_KNL_KOD"));

			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", sMap);

			sMap.put("DOVIZ_KOD", sMap.getString("DOVIZ_KODU"));
			sMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", sMap));
			sMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", sMap));
			appMap.put("FAIZ_ORANI", sMap.get("FAIZ_ORAN"));
			appMap.put("SOZLESME_FAIZI", sMap.get("SOZLESME_ORANI"));
			appMap.put("KATILIM_BEDELI", sMap.get("MAX_KATKI_PAYI"));
			appMap.put("DOSYA_MASRAFI", sMap.get("MAX_DOSYA_MASRAFI"));

			appMap.put("TRX_NO", iMap.get("TRX_NO"));
			appMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			appMap.put("KURYE_SECIMI", iMap.getString("KURYE_SECIMI", "S"));

			GMServiceExecuter.execute("BNSPR_TRN3171_CONTROL", appMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * PTT On Onay basvuru kaydetme servisi
	 * 
	 * emre.cakmak
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN3172_SAVE_PTT_BULK_APPLICATION")
	public static GMMap savePttBulkApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap pMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			if (birBasvuru != null) {
				birBasvuru.setSozlesmeBeklemeEh(iMap.getString("SOZLESME_BEKLEME_EH"));
				session.saveOrUpdate(birBasvuru);
				session.flush();
			}
			BirBasvuruKimlik kimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			pMap.put("MSISDN", "+90".concat(kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo())));
			pMap.put("NATIONAL_IDENTIFICATION_NUMBER", kimlik.getTcKimlikNo());
			pMap.put("CHANNEL", "BULK");
			pMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION", pMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * PTT SMS Toplu Basvuru Degerlendirme Servisi
	 * 
	 * emre.cakmak
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN3172_EVALUATE_PTT_BULK_APPLICATION")
	public static GMMap evaluatePttBulkApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		String messageNo = "";
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
		try {

			// basvuru bilgileri getirilir
			sMap = GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU", iMap);
			sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU_DETAY", iMap));

			BigDecimal tutar = sMap.getBigDecimal("TUTAR");

			// ptt maas bilgileri alinir
			ClksBirBasvuruSmsTalep clksBirBasvuruSmsTalep = (ClksBirBasvuruSmsTalep) session.get(ClksBirBasvuruSmsTalep.class, iMap.getBigDecimal("BASVURU_NO"));
			if (clksBirBasvuruSmsTalep != null) {
				sMap.put("AYLIK_GELIR", clksBirBasvuruSmsTalep.getAylikGelir());
				sMap.put("PTT_ILK_MAAS_TARIHI", clksBirBasvuruSmsTalep.getIlkMaasTarihi());
				sMap.put("MAAS_ALINAN_KURUM", clksBirBasvuruSmsTalep.getMaasAlinanKurum());
				sMap.put("PTT_TAHSIS_NUMARASI", clksBirBasvuruSmsTalep.getTahsisNumarasi());
				sMap.put("SON_MAAS_TARIHI", clksBirBasvuruSmsTalep.getSonMaasTarihi());
				sMap.put("ONCEKI_MAAS_ODEME_TARIHI", clksBirBasvuruSmsTalep.getOncekiMaasOdemeTarihi());
				sMap.put("PCH", clksBirBasvuruSmsTalep.getPch());
				sMap.put("PTT_MAAS_EVDEN_MI", clksBirBasvuruSmsTalep.getPttMaasEvdenMi());
			}

			// 3171 control oncesi durum kodu basvuru ya alinir
			birBasvuru.setDurumKodu("BASVURU");
			session.saveOrUpdate(birBasvuru);
			session.refresh(birBasvuru);

			// ptt maas bilgileri sonrasi tekrar 3171 control ve 3171 gonder sorgular yapilir
			sMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			sMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sMap.put("DURUM_KODU", "BASVURU");
			sMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_CONTROL", sMap));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", sMap));
			// sMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_CONTROL", sMap));
			// sMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_GONDER_SORGULAR", sMap));

			// sorgular sonrasi bir basvuru refresh edilir
			session.refresh(birBasvuru);

			// sorgu sonucu devam ise onay
			if ("E".equals(sMap.getString("DEVAM"))) {

				// kurye secimi durumunda dogrulama cikarsa sozlesme basilmaz
				if ("K".equals(sMap.getString("KURYE_SECIMI")) && ("E".equals(sMap.getString("PCH")) && "SOZLESME".equals(birBasvuru.getDurumKodu()))) {
					sMap.putAll(GMServiceExecuter.call("CLKS_GET_PAY_PLN_3181_REQUEST_INFO", iMap));
					sMap.put("TAKSIT_GUNU", birBasvuru.getTaksitGunu());
					sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_CREATE_AGREEMENT", sMap));
					sMap.put("AGREEMENT_TRX_NO", sMap.get("TRX_NO"));
					GMServiceExecuter.execute("BNSPR_TRN3172_SAVE_AGREEMENT", sMap);
				}

				iMap.put("P1", sMap.getBigDecimal("ONAY_TUTAR"));

				// tam onay
				if (sMap.getBigDecimal("ONAY_TUTAR") != null && sMap.getBigDecimal("ONAY_TUTAR").compareTo(tutar) >= 0) {
					// upsell
					if (sMap.getBigDecimal("ONAY_TUTAR").compareTo(tutar) > 0) {
						birBasvuru.setBasvuruTeklifTur("U");
						birBasvuru.setBasvuruTeklifTutar(sMap.getBigDecimal("ONAY_TUTAR"));
					}
					// pch uygun degil
					if ("H".equals(sMap.getString("PCH"))) {
						messageNo = "6124";
					}
					else {
						// sube tam onay
						if ("S".equals(sMap.getString("KURYE_SECIMI"))) {
							messageNo = "6118";
							// kurye tam onay
						}
						else {
							messageNo = "6119";
						}
					}
					// kismi onay
				}
				else {
					// sube kismi onay
					if ("S".equals(sMap.getString("KURYE_SECIMI"))) {
						messageNo = "6120";
						// kurye kismi onay
					}
					else {
						messageNo = "6119";
					}
				}

			}
			else {
				// maasi ptt olmadigi icin ret
				if (clksBirBasvuruSmsTalep.getTahsisNumarasi() == null) {
					messageNo = "6123";
					// maas yetersiz ret
				}
				else {
					messageNo = "6122";
				}
			}

			session.saveOrUpdate(birBasvuru);

			BirBasvuruKimlik kimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			String cepTel = kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo());
			String mesaj = "";

			iMap.put("MESSAGE_NO", messageNo);
			mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");

			if (!"".equals(cepTel) && !"".equals(mesaj)) {
				GMMap smsMap = new GMMap();
				smsMap.put("MSISDN", cepTel);
				smsMap.put("CONTENT", mesaj);
				smsMap.put("HEADER", "AktifBank");
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
			}
		}
		catch (Exception e) {
			// PBIBK-546 PTT Toplu SMS Hata Alan Basvurular
			// nbsm vb hata alinmasi durum kodu sozlesmeye alinir
			birBasvuru.setDurumKodu("SOZLESME");
			birBasvuru.setSozlesmeBeklemeEh("E");
			session.saveOrUpdate(birBasvuru);
			session.refresh(birBasvuru);
		}
		return oMap;
	}
}
