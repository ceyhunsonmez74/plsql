package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Date;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3236Services {
	
	@GraymoundService("BNSPR_QRY3236_KREDI_IADE_TUTAR_HESAPLA")
	public static GMMap calculate(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3236.KREDI_IADE_TUTAR_HESAPLA(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			
			int parameterIndex = 1;
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(parameterIndex++, iMap.getDate("IADE_YAPILACAK_TARIH") != null ? new java.sql.Date(iMap.getDate("IADE_YAPILACAK_TARIH").getTime()) : null);
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("IADE_YAPILACAK_TUTAR"));
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("GECIKME_FAIZI_TOPLAM_TUTARI"));
			stmt.setString(parameterIndex++, iMap.getBoolean("VERGI_FON_ODENDI_MI") ? "E" : "H");
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.registerOutParameter(parameterIndex++, Types.DECIMAL);
			stmt.execute();
			
			parameterIndex = 6;
			oMap.put("KATKI_PAYI_IADE_TUTARI", stmt.getBigDecimal(parameterIndex++));
			oMap.put("GECEN_GUN_FAIZ_TUTARI", stmt.getBigDecimal(parameterIndex++));
			oMap.put("GECEN_GUN_FAIZ_KKDF_TUTARI", stmt.getBigDecimal(parameterIndex++));
			oMap.put("GECEN_GUN_FAIZ_BSMV_TUTARI", stmt.getBigDecimal(parameterIndex++));
			oMap.put("DOSYA_MASRAF_IADE_TUTARI", stmt.getBigDecimal(parameterIndex++));
			oMap.put("GECIKME_FAIZI_TOPLAM_KKDF_TUTARI", stmt.getBigDecimal(parameterIndex++));
			oMap.put("GECIKME_FAIZI_TOPLAM_BSMV_TUTARI", stmt.getBigDecimal(parameterIndex++));
			oMap.put("BAYIYE_YAPILACAK_TOPLAM_IADE_TUTARI", stmt.getBigDecimal(parameterIndex++));
			oMap.put("NET_OLARAK_BAYIDEN_ALINACAK_TUTAR", stmt.getBigDecimal(parameterIndex++));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3236_GET_TODAY")
	public static GMMap getDate(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			oMap.put("TODAY", new Date());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
