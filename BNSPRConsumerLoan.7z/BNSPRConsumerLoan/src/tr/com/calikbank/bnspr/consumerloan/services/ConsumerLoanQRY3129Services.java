package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3129Services {

	@GraymoundService("BNSPR_QRY3129_GET_HAVUZDAKI_BASVURULAR")
	public static GMMap getHavuzdakiBasvurular(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "IS_HAVUZU";
		try {
			Object[] inputValues = new Object[24];
			int n = 0;
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("MUSTERI_NO");
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("KREDI_TURU");
			inputValues[n++] = BnsprType.DATE;
			if (iMap.getDate("BASVURU_TARIHI") != null)
				inputValues[n++] = new java.sql.Date(iMap.getDate("BASVURU_TARIHI").getTime());
			else
				inputValues[n++] = null;
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("DURUM_KODU");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("KANAL_KODU");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("KANAL_ALT_KODU");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("ADI");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("IKINCI_ADI").isEmpty() ? null : iMap.getString("IKINCI_ADI");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("SOYADI");
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("TAHSIS_ONCELIK");
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("FRAUD_ONCELIK");

			String func = "{ ? = call pkg_basvuru.GetHavuzdakiBasvurular(?,?,?,?,?,?,?,?,?,?,?,?) }";
			oMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		for (int i = 0; i < oMap.getSize(tableName); i++) {
			oMap.put(tableName, i, "TEMINAT", !"-1".equals(oMap.getString(tableName, i, "TEMINAT")));
			oMap.put(tableName, i, "ONCEKI_ADIMA_IADE", "E".equals(oMap.getString(tableName, i, "ONCEKI_ADIMA_IADE")));
			oMap.put(tableName, i, "IPTAL_EDILEBILIR_MI", "E".equals(oMap.getString(tableName, i, "IPTAL_EDILEBILIR_MI")));
			oMap.put(tableName, i, "KONTAKT_MUSTERI", "K".equals(oMap.getString(tableName, i, "KONTAKT_MUSTERI")));
		}

		oMap.put("ROW_COUNT", oMap.getSize(tableName));

		return oMap;
	}

	@GraymoundService("BNSPR_QRY3129_SON_ISLEM_BILGI")
	public static GMMap sonIslemBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_basvuru.SonIslemYapanKullanici(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			GMMap oMap = new GMMap();
			oMap.put("SON_ISLEM_YAPAN_KULLANICI", stmt.getString(1));
			GMServerDatasource.close(stmt);

			stmt = conn.prepareCall("{? = call pkg_basvuru.SonIslemTarihi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			oMap.put("SON_ISLEM_TARIHI", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_QRY3129_ADIMA_IADE")
	public static GMMap oncekiAdimaIade(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.AdimaIade(?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("IADE_DURUM"));
			stmt.setString(3, iMap.getString("IADE_NEDENI"));
			stmt.setString(4, iMap.getString("ESKI_DURUM"));
			stmt.setString(5, iMap.getString("ADI_SOYADI"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_QRY3129_IPTAL")
	public static GMMap iptal(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.HavuzdanIptal(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("AKSIYON_KARAR_KOD"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_TRN3129_GET_TEMINAT_GIRILMIS_MI")
	public static GMMap getTeminatGirilmisMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3132.TeminatGirilmisMi(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3129_GET_TEMINAT_DEGISMIS_MI")
	public static GMMap getTeminatDegismisMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3132.sonradan_eklenen_teminat_mesaj(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3129_ONCEKI_ADIM_LIST")
	public static GMMap getOncekiAdimList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "ONCEKI_ADIM_LIST", true, "select t.key1, t.key1 from v_ml_gnl_param_text t where t.KOD = 'ONAY_STATU_KOD' and t.sira_no < (select sira_no from v_ml_gnl_param_text t where t.KOD = 'ONAY_STATU_KOD' and t.KEY1 = '" + iMap.getString("DURUM_KODU") + "') and sira_no > 1 order by sira_no");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3129_ONAY_STATU_LIST")
	public static GMMap getOnayStatuList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1 from v_ml_gnl_param_text where kod = 'ONAY_STATU_KOD' and key1 not in ('KULONAY', 'NBSM', 'JOB', 'KAPANDI') order by sira_no");

			rSet = stmt.executeQuery();
			String listName = "DURUM";
			GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
			while (rSet.next()) {
				if (rSet.getString(1).equals("KUL"))
					GuimlUtil.wrapMyCombo(oMap, listName, "KUL", "KULLANDIRIM");
				else
					GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(1));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BAYI_LIMIT_IPTAL")
	public static GMMap BNSPR_Bayi_Limit_Iptal(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BAYI_LIMIT.Manuel_Limit_Iade(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, "IPTAL");
			stmt.setString(3, iMap.getString("ISLEM_KOD"));
			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BAYI_LIMIT_IADE_SON_DURUM")
	public static GMMap BNSPR_Bayi_Limit_Iade(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BAYI_LIMIT.Manuel_Limit_Iade(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));

			stmt.setString(2, iMap.getString("AKSIYON_KARAR_KOD"));

			stmt.setString(3, iMap.getString("ISLEM_KOD"));

			stmt.execute();
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BAYI_LIST_4_MI4BIZ")
	public static GMMap bnsprBayiList4Mi4Biz(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {

			String query = "SELECT s.KOD, s.SATICI_ADI, s.MUSTERI_NO, s.TANIMLAMA_TAR, s.SATICI_TIP_KOD, s.BAGLI_MERKEZ_BAYI, " + "s.KURULUS_TAR,s.KRD_TUR_KODLARI, s.YETKI_SEVIYE_KOD, s.ONEM_DERECE_KOD, s.TESVIK_UYGULAMA_EH, s.TESVIK_FARKLI_EH, " + "s.TESVIK_UYGULAMA_EH, s.TESVIK_FARKLI_EH, s.BELGE_GON_FAKS_EH, s.BELGE_GON_EMAIL_EH, s.ADRES, s.ALAN_KOD_TEL, s.TEL_NO, " + "s.ALAN_KOD_FAKS, s.FAKS_NO, s.EMAIL, s.WEB_ADRES, s.BANKA_KOD, s.BANKA_SUBE, s.BANKA_HESAP, s.PARA_CIKIS_OTO_EH, s.SATIS_GORUS_KOD, " + "s.DRM, s.BAGLI_OLD_BOLGE_KOD, s.DOK_YOLLAMA_KOD, s.ACIKLAMA, s.HESAP_NO, s.ADRES_IL, s.ADRES_ILCE, s.TESVIK_PUAN, s.BAYI_SORUMLU_KISI, s.PORTFOY_KOD, " + "s.SUBE_MUSTERI_NO, s.DISTRIBUTOR_HESAP_NO, s.SIGORTA_SATISI_EH, si.BAGLI_OLD_SAT_KOD " + "FROM bir_satici s " + "left outer join bir_satici_iliski si " + "on s.kod = si.satici_kod " + "where s.drm = 'G' and s.satici_tip_kod in ('M', 'S', 'D')";

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(query);
			stmt.execute();
			rSet = stmt.getResultSet();
			while (rSet.next()) {
				String kod = rSet.getString("KOD");

				if (oMap.get(kod) == null) {
					oMap.put(kod, new GMMap());
					GMMap bayiMap = oMap.getMap(kod);

					bayiMap.put("HESAP_NO", rSet.getString("HESAP_NO"));
					bayiMap.put("ADRES_IL", rSet.getString("ADRES_IL"));
					bayiMap.put("ADRES_ILCE", rSet.getString("ADRES_ILCE"));
					bayiMap.put("TESVIK_PUAN", rSet.getString("TESVIK_PUAN"));
					bayiMap.put("BAYI_SORUMLU_KISI", rSet.getString("BAYI_SORUMLU_KISI"));
					bayiMap.put("PORTFOY_KOD", rSet.getString("PORTFOY_KOD"));
					bayiMap.put("SUBE_MUSTERI_NO", rSet.getString("SUBE_MUSTERI_NO"));
					bayiMap.put("DISTRIBUTOR_HESAP_NO", rSet.getString("DISTRIBUTOR_HESAP_NO"));
					bayiMap.put("SIGORTA_SATISI_EH", rSet.getString("SIGORTA_SATISI_EH"));
					bayiMap.put("SATICI_ADI", rSet.getString("SATICI_ADI"));
					bayiMap.put("MUSTERI_NO", rSet.getString("MUSTERI_NO"));
					bayiMap.put("TANIMLAMA_TAR", rSet.getString("TANIMLAMA_TAR"));
					bayiMap.put("SATICI_TIP_KOD", rSet.getString("SATICI_TIP_KOD"));
					bayiMap.put("BAGLI_MERKEZ_BAYI", rSet.getString("BAGLI_MERKEZ_BAYI"));
					bayiMap.put("KURULUS_TAR", rSet.getString("KURULUS_TAR"));
					bayiMap.put("KRD_TUR_KODLARI", rSet.getString("KRD_TUR_KODLARI"));
					bayiMap.put("YETKI_SEVIYE_KOD", rSet.getString("YETKI_SEVIYE_KOD"));
					bayiMap.put("ONEM_DERECE_KOD", rSet.getString("ONEM_DERECE_KOD"));
					bayiMap.put("TESVIK_UYGULAMA_EH", rSet.getString("TESVIK_UYGULAMA_EH"));
					bayiMap.put("TESVIK_FARKLI_EH", rSet.getString("TESVIK_FARKLI_EH"));
					bayiMap.put("ALAN_KOD_FAKS", rSet.getString("ALAN_KOD_FAKS"));
					bayiMap.put("FAKS_NO", rSet.getString("FAKS_NO"));
					bayiMap.put("EMAIL", rSet.getString("EMAIL"));
					bayiMap.put("WEB_ADRES", rSet.getString("WEB_ADRES"));
					bayiMap.put("BANKA_KOD", rSet.getString("BANKA_KOD"));
					bayiMap.put("BANKA_SUBE", rSet.getString("BANKA_SUBE"));
					bayiMap.put("BANKA_HESAP", rSet.getString("BANKA_HESAP"));
					bayiMap.put("PARA_CIKIS_OTO_EH", rSet.getString("PARA_CIKIS_OTO_EH"));
					bayiMap.put("SATIS_GORUS_KOD", rSet.getString("SATIS_GORUS_KOD"));
					bayiMap.put("DRM", rSet.getString("DRM"));
					bayiMap.put("BAGLI_OLD_BOLGE_KOD", rSet.getString("BAGLI_OLD_BOLGE_KOD"));
					bayiMap.put("DOK_YOLLAMA_KOD", rSet.getString("DOK_YOLLAMA_KOD"));
					bayiMap.put("ACIKLAMA", rSet.getString("ACIKLAMA"));
					oMap.put(kod, bayiMap);

				}

				GMMap bayiMap = oMap.getMap(kod);
				if (bayiMap.get("BAGLI_OLD_SAT_KOD") == null || bayiMap.getString("BAGLI_OLD_SAT_KOD").trim().length() == 0) {
					bayiMap.put("BAGLI_OLD_SAT_KOD", rSet.getString("BAGLI_OLD_SAT_KOD"));
				}
				else {
					String str = bayiMap.getString("BAGLI_OLD_SAT_KOD").trim();
					str = str + "," + rSet.getString("BAGLI_OLD_SAT_KOD");
					bayiMap.put("BAGLI_OLD_SAT_KOD", str);
				}

				oMap.put(kod, bayiMap);
			}

			GMMap mp = new GMMap();

			Iterator<?> it = oMap.keySet().iterator();

			int i = 0;
			String tableName = "BAYI_LIST";

			while (it.hasNext()) {
				String kod = (String) it.next();
				GMMap bayiMap = oMap.getMap(kod);

				mp.put(tableName, i, "KOD", kod);
				mp.put(tableName, i, "HESAP_NO", bayiMap.getString("HESAP_NO"));
				mp.put(tableName, i, "ADRES_IL", bayiMap.getString("ADRES_IL"));
				mp.put(tableName, i, "ADRES_ILCE", bayiMap.getString("ADRES_ILCE"));
				mp.put(tableName, i, "TESVIK_PUAN", bayiMap.getString("TESVIK_PUAN"));
				mp.put(tableName, i, "BAYI_SORUMLU_KISI", bayiMap.getString("BAYI_SORUMLU_KISI"));
				mp.put(tableName, i, "PORTFOY_KOD", bayiMap.getString("PORTFOY_KOD"));
				mp.put(tableName, i, "SUBE_MUSTERI_NO", bayiMap.getString("SUBE_MUSTERI_NO"));
				mp.put(tableName, i, "DISTRIBUTOR_HESAP_NO", bayiMap.getString("DISTRIBUTOR_HESAP_NO"));
				mp.put(tableName, i, "SIGORTA_SATISI_EH", bayiMap.getString("SIGORTA_SATISI_EH"));
				mp.put(tableName, i, "SATICI_ADI", bayiMap.getString("SATICI_ADI"));
				mp.put(tableName, i, "MUSTERI_NO", bayiMap.getString("MUSTERI_NO"));
				mp.put(tableName, i, "TANIMLAMA_TAR", bayiMap.getString("TANIMLAMA_TAR"));
				mp.put(tableName, i, "SATICI_TIP_KOD", bayiMap.getString("SATICI_TIP_KOD"));
				mp.put(tableName, i, "BAGLI_MERKEZ_BAYI", bayiMap.getString("BAGLI_MERKEZ_BAYI"));
				mp.put(tableName, i, "KURULUS_TAR", bayiMap.getString("KURULUS_TAR"));
				mp.put(tableName, i, "KRD_TUR_KODLARI", bayiMap.getString("KRD_TUR_KODLARI"));
				mp.put(tableName, i, "YETKI_SEVIYE_KOD", bayiMap.getString("YETKI_SEVIYE_KOD"));
				mp.put(tableName, i, "ONEM_DERECE_KOD", bayiMap.getString("ONEM_DERECE_KOD"));
				mp.put(tableName, i, "TESVIK_UYGULAMA_EH", bayiMap.getString("TESVIK_UYGULAMA_EH"));
				mp.put(tableName, i, "TESVIK_FARKLI_EH", bayiMap.getString("TESVIK_FARKLI_EH"));
				mp.put(tableName, i, "ALAN_KOD_FAKS", bayiMap.getString("ALAN_KOD_FAKS"));
				mp.put(tableName, i, "FAKS_NO", bayiMap.getString("FAKS_NO"));
				mp.put(tableName, i, "EMAIL", bayiMap.getString("EMAIL"));
				mp.put(tableName, i, "WEB_ADRES", bayiMap.getString("WEB_ADRES"));
				mp.put(tableName, i, "BANKA_KOD", bayiMap.getString("BANKA_KOD"));
				mp.put(tableName, i, "BANKA_SUBE", bayiMap.getString("BANKA_SUBE"));
				mp.put(tableName, i, "BANKA_HESAP", bayiMap.getString("BANKA_HESAP"));
				mp.put(tableName, i, "PARA_CIKIS_OTO_EH", bayiMap.getString("PARA_CIKIS_OTO_EH"));
				mp.put(tableName, i, "SATIS_GORUS_KOD", bayiMap.getString("SATIS_GORUS_KOD"));
				mp.put(tableName, i, "DRM", bayiMap.getString("DRM"));
				mp.put(tableName, i, "BAGLI_OLD_BOLGE_KOD", bayiMap.getString("BAGLI_OLD_BOLGE_KOD"));
				mp.put(tableName, i, "DOK_YOLLAMA_KOD", bayiMap.getString("DOK_YOLLAMA_KOD"));
				mp.put(tableName, i, "ACIKLAMA", bayiMap.getString("ACIKLAMA"));
				mp.put(tableName, i, "BAGLI_OLD_SAT_KOD", bayiMap.getString("BAGLI_OLD_SAT_KOD"));

				i++;
			}

			return mp;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
}
