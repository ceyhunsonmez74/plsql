package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jxl.CellType;
import jxl.DateCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiProfilingKayitTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiProfilingTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiProfilingTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3268Services {

    @SuppressWarnings("deprecation")
    @GraymoundService("BNSPR_TRN3268_IMPORT_EXCEL")
    public static GMMap excelToTable(GMMap iMap) {
        GMMap oMap = new GMMap();
        String hataSonuc = null;
        try {
            byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();

            //ws.setCharacterSet(cs);
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
                if(workbook.getSheet(0).getColumns() < 4){
                    throw new GMRuntimeException(0, "Yanl�� Kolon Say�s�.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            
            Sheet sheet = workbook.getSheet(0);
            int hataliSatirSayisi = 0;
            int j;
            for (j = 0; j+1 < sheet.getRows(); j++) {
                for (int i = 0; i < sheet.getColumns(); i++) {
                    if (sheet.getCell(i, j+1) != null && sheet.getCell(i, j+1).getType().equals(CellType.DATE)) {
                        oMap.put("TABLE", j, "COLUMN_" + (i), ((DateCell) sheet.getCell(i, j+1)).getDate());
                    } else {
                        oMap.put("TABLE", j, "COLUMN_" + (i), sheet.getCell(i, j+1).getContents());
                    }
                }
                String func = "{? = call pkg_trn3268.kayit_hatalimi(?,?,?,?)}";
                Object[] inputValues = new Object[8];
                int k = 0;
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_1");
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_0");
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_2");
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_3");
                
                hataSonuc = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);

                if (hataSonuc != null && hataSonuc.equals("E")) {
                    oMap.put("TABLE", j, "HATALI_MI", true);
                    hataliSatirSayisi++;
                } else {
                    oMap.put("TABLE", j, "HATALI_MI", false);
                    oMap.put("TABLE", j, "SATICI_ADI", LovHelper.diLov(oMap.getString("TABLE", j, "COLUMN_1"), "3268/LOV_SATICI_KODU", "SATICI_ADI"));
                    oMap.put("TABLE", j, "COLUMN_0", StringUtils.isNotBlank(oMap.getString("TABLE", j, "COLUMN_0")) ? parseDate(oMap.getString("TABLE", j, "COLUMN_0")) : "");
                }

            }
            oMap.put("SATIR_SAYISI", oMap.getSize("TABLE"));
            oMap.put("HATALI_SATIR_SAYISI", hataliSatirSayisi);
            oMap.put("KAYDEDILECEK_SATIR_SAYISI", nvl(oMap.getSize("TABLE"), 0) - hataliSatirSayisi);
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

    @GraymoundService("BNSPR_TRN3268_SAVE")
    public static Map<?, ?> saveTRN3268(GMMap iMap) {
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            @SuppressWarnings("unchecked")
            List<BirSaticiProfilingTx> ProfilingList = (List<BirSaticiProfilingTx>) session.createCriteria(BirSaticiProfilingTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

            for (BirSaticiProfilingTx profiling : ProfilingList) {
                session.delete(profiling);
                session.flush();
            }
            for (int i = 0; i < iMap.getSize("TABLE"); i++) {
                if (!iMap.getBoolean("TABLE", i, "HATALI_MI")) {
                    BirSaticiProfilingTx birSaticiProfilingTx = new BirSaticiProfilingTx();
                    BirSaticiProfilingTxId Id = new BirSaticiProfilingTxId();
                    Id.setProfilingTarih(iMap.getDate("TABLE", i, "COLUMN_0"));
                    Id.setSaticiKod(iMap.getBigDecimal("TABLE", i, "COLUMN_1"));
                    Id.setProfilingPuan(iMap.getString("TABLE", i, "COLUMN_2" ));
                    Id.setProfilingSinif(iMap.getString("TABLE", i, "COLUMN_3"));
                    Id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    birSaticiProfilingTx.setId(Id);
                    session.save(birSaticiProfilingTx);
                }
            }
            session.flush();

            BirSaticiProfilingKayitTx birSaticiProfilingKayitTx =
                (BirSaticiProfilingKayitTx) session.createCriteria(BirSaticiProfilingKayitTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

            if (birSaticiProfilingKayitTx == null) {
                birSaticiProfilingKayitTx = new BirSaticiProfilingKayitTx();
            }

            birSaticiProfilingKayitTx.setDosyaAdi(iMap.getString("FILE_NAME"));
            birSaticiProfilingKayitTx.setHataliSatir(iMap.getBigDecimal("HATALI_SATIR_SAYISI"));
            birSaticiProfilingKayitTx.setKaydedilecekSatir(iMap.getBigDecimal("KAYDEDILECEK_SATIR_SAYISI"));
            birSaticiProfilingKayitTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            birSaticiProfilingKayitTx.setYuklenenSatir(iMap.getBigDecimal("SATIR_SAYISI"));

            session.saveOrUpdate(birSaticiProfilingKayitTx);
            session.flush();

            iMap.put("TRX_NAME", "3268");

            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

    @SuppressWarnings("deprecation")
    @GraymoundService("BNSPR_TRN3268_GET_GUNCEL_LISTE")
    public static GMMap getGuncelListe(GMMap iMap) {
        GMMap oMap = new GMMap();
        String func;
        Object[] inputValues;
        try {
            if (iMap.getBigDecimal("SATICI_KOD") != null) {
                func = "{? = call pkg_trn3268.get_guncel_liste(?)}";
                int i = 0;
                inputValues = new Object[2];
                inputValues[i++] = BnsprType.NUMBER;
                inputValues[i++] = iMap.getBigDecimal("SATICI_KOD");
                oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
            } else {
                func = "{? = call pkg_trn3268.get_guncel_liste()}";
                oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", new Object[0]));
            }
            for (int i = 0; i < oMap.getSize("RESULTS"); i++) {
                oMap.put("RESULTS", i, "SATICI_AD", LovHelper.diLov(oMap.getString("RESULTS", i, "SATICI_KOD"), "3268/LOV_SATICI_KODU", "SATICI_ADI"));
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

    @GraymoundService("BNSPR_TRN3268_GET_TARIHCE")
    public static GMMap getTarihce(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            String func = "{? = call pkg_trn3268.get_tarihce(?,?,?,?,?)}";
            Object[] inputValues = new Object[]{         
             BnsprType.NUMBER,iMap.getBigDecimal("SATICI_KOD"),
             BnsprType.DATE,iMap.getDate("BAS_TARIH"),
             BnsprType.DATE,iMap.getDate("BIT_TARIH"),
             BnsprType.DATE,iMap.getDate("PROF_BAS_TRH"),
             BnsprType.DATE,iMap.getDate("PROF_BIT_TRH")
            };
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
            
            for(int i = 0; i<oMap.getSize("RESULTS"); i++){
                oMap.put("RESULTS", i, "SATICI_AD",LovHelper.diLov(oMap.getString("RESULTS", i, "SATICI_KOD"), "3268/LOV_SATICI_KODU", "SATICI_ADI"));
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

    public static <T> T nvl(T a, T b) {
        if (a instanceof String) return StringUtils.isBlank((String) a) ? b : a;
        return a == null ? b : a;
    }
    
    public static Date parseDate(final String date) {
        if (date == null) {
          return null;
        }
        SimpleDateFormat sdf = (date.charAt(2) == '/') ? new SimpleDateFormat("MM/yyyy")
                                                         : new SimpleDateFormat("yyyyMMdd");
        try {
          return sdf.parse(date);
        } catch (ParseException e) {
        }
        return null;
      }
}
