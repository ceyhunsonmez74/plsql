package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3232Services {
	@GraymoundService("BNSPR_QRY3232_OLUSTUR")
	public static GMMap olustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_QRY3232.BIR_KREDI_KONTROL_BAKIYE_PROC}");
			stmt.execute();
			stmt.close();

			stmt = conn.prepareCall("{? = call PKG_QRY3232.RETURN_MAX_TX_NO}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();
			oMap.put("TX_NO", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3232_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_QRY3232.RETURN_REPORT_FNC(?, ?, ?, ?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setDate(i++, iMap.getDate("KAYIT_TARIHI") != null ? new java.sql.Date(iMap.getDate("KAYIT_TARIHI").getTime()) : null);
			stmt.setString(i++, iMap.get("DURUM_KODU") != null ? iMap.getString("DURUM_KODU") : null);
			stmt.setString(i++, GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("BORC_TRANSFERI")));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int row = 0;
			String tableName = "RESULTS";
			while (rSet.next()) {
				oMap.put(tableName, row, "HESAP_BAKIYE", rSet.getBigDecimal("HESAP_BAKIYE"));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString("HESAP_NO"));
				oMap.put(tableName, row, "TOPLAM_TAKSIT_TUTARI", rSet.getBigDecimal("TOPLAM_TAKSIT_TUTARI"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
				oMap.put(tableName, row, "REC_OWNER", rSet.getString("REC_OWNER"));
				oMap.put(tableName, row, "REC_DATE", rSet.getDate("REC_DATE"));
				oMap.put(tableName, row, "ISLEM_NO", rSet.getString("ISLEM_NO"));
				oMap.put(tableName, row, "ISLEM_ACIKLAMASI", rSet.getString("ISLEM_ACIKLAMASI"));
				oMap.put(tableName, row, "ISLEM_KODU", rSet.getString("ISLEM_KODU"));
				oMap.put(tableName, row, "ISLEM_TARIHI", rSet.getDate("ISLEM_TARIHI"));
				oMap.put(tableName, row, "ISLEM_TUTARI", rSet.getBigDecimal("ISLEM_TUTARI"));
				oMap.put(tableName, row, "TOPLAM_KAPAMA_TUTARI", rSet.getBigDecimal("TOPLAM_KAPAMA_TUTARI"));
				oMap.put(tableName, row, "KAYIT_TARIHI", rSet.getDate("KAYIT_TARIHI"));
				oMap.put(tableName, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				oMap.put(tableName, row, "ISLEMI_YAPAN_KULLANICI", rSet.getString("ISLEMI_YAPAN_KULLANICI"));
				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_QRY3232_TARIHCE")
	public static GMMap tarihce(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TBL_ISLEM_TARIHCE";
		oMap = DALUtil.getResults("select tx.islem_no, tx.islem_tarihi, k.ad ||' '|| k.soyad islemi_yapan_kullanici, t.text yeni_durum_kodu " + " from bir_kredi_kontrol_bakiye_tx tx, gnl_kullanici k, gnl_param_text t where t.kod = 'BAKIYE_KONTROL_AKSIYON_KOD' and t.key1 = tx.durum_kodu" + " and k.kod = tx.rec_owner and tx.islem_no =" + iMap.getBigDecimal("ISLEM_NO") + " order by tx.rec_date desc", tableName);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY3232_DETAY")
	public static GMMap detay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_QRY3232.RETURN_BASVURU_SONUC(?, ?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResultsPutStr(rSet, "RESULTS");
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
}
