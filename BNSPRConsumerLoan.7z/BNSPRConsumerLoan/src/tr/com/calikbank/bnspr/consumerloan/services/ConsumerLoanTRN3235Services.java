package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuruBelgeKontrolTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruBelgeKontrolTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3235Services {
	
	@GraymoundService("BNSPR_TRN3235_GET_EKSIK_LIST")
	public static GMMap getEksikList(GMMap iMap){
		GMMap 				oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3235.Get_Eksik_Belgeli_Basvurular(?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(i++, iMap.getDate("BAS_TAR") != null ? new java.sql.Date(iMap.getDate("BAS_TAR").getTime()) : null);
			stmt.setDate(i++, iMap.getDate("BIT_TAR") != null ? new java.sql.Date(iMap.getDate("BIT_TAR").getTime()) : null);
			stmt.setString(i++ , iMap.getString("IPTAL"));
			stmt.setString(i++ , iMap.getString("KANAL_KODU"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "EKSIK_LIST"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3235_GET_BELGE_LIST")
	public static GMMap getBelgeList(GMMap iMap){
		GMMap 				oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3235.Get_Cikabilir_Belgeli_Basvuru(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "BELGE"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3235_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			
			String tableName = "BELGELER";
			Session session = DAOSession.getSession("BNSPRDal");
			
			for(int i=0; i<iMap.getSize(tableName);i++){
				
				BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();
				birBasvuruBelgeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birBasvuruBelgeTxId.setDokumanKod(iMap.getString(tableName, i, "BELGE_KOD"));
				birBasvuruBelgeTxId.setKimden(iMap.getString(tableName, i, "KIMDEN"));
				birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				
				
				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, birBasvuruBelgeTxId);
				
				if(birBasvuruBelgeTx == null){
					birBasvuruBelgeTx = new BirBasvuruBelgeTx();
					birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
				}
				
				birBasvuruBelgeTx.setBelgeAdi(iMap.getString(tableName, i, "DOSYA_ADI"));
				birBasvuruBelgeTx.setBelgeKontrol(iMap.getString(tableName, i, "BELGE_KONTROL"));
				birBasvuruBelgeTx.setKontrolNedeni(iMap.getString(tableName, i, "KONTROL_NEDENI"));
				birBasvuruBelgeTx.setOrjinalEvrakMi(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i,"ORJINAL_EVRAK_MI")));
				birBasvuruBelgeTx.setBelgeGelisTarihi(iMap.getDate(tableName, i, "GELIS_TARIHI"));
				birBasvuruBelgeTx.setBelgeHata(iMap.getString(tableName, i, "BELGE_HATA"));
				birBasvuruBelgeTx.setBarkodNumarasi(iMap.getString(tableName, i, "BARKOD_NO"));
				birBasvuruBelgeTx.setOnayliMi(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i,"ONAYLI_MI")));
				birBasvuruBelgeTx.setBelgeYeri(iMap.getString(tableName, i, "DOSYA_YOL"));
				birBasvuruBelgeTx.setUyumsuzAciklama(iMap.getString(tableName, i, "UYUMSUZ_ACIKLAMA"));
				birBasvuruBelgeTx.setIslemTarihi(iMap.getDate(tableName, i, "ISLEM_TARIHI"))  ;
				birBasvuruBelgeTx.setKontrolNedeni(iMap.getString(tableName, i, "ACIKLAMA"));
				birBasvuruBelgeTx.setKaldirEh(iMap.getBoolean(tableName, i, "CHK_KALDIR")?"E":"H");
				
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge)session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
				                      																			.add(Restrictions.eq("id.dokumanKod", iMap.getString(tableName, i, "BELGE_KOD")))
				                      																			.add(Restrictions.eq("id.kimden", iMap.getString(tableName,i,"KIMDEN")))
				                      																			.uniqueResult();
				
				birBasvuruBelgeTx.setBelgeAlinmaAdim(birBasvuruBelge == null ? null: birBasvuruBelge.getBelgeAlinmaAdim());
				
				session.saveOrUpdate(birBasvuruBelgeTx);
				session.flush();
				
			}
			
			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrolTx = (BirBasvuruBelgeKontrolTx) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			BirBasvuruBelgeKontrolTxId id= new BirBasvuruBelgeKontrolTxId();
			if(birBasvuruBelgeKontrolTx == null)
			{
				birBasvuruBelgeKontrolTx = new BirBasvuruBelgeKontrolTx();
			}
			id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birBasvuruBelgeKontrolTx.setId(id);
			birBasvuruBelgeKontrolTx.setIstisnaGorusu(iMap.getString("ACIKLAMA"));
			birBasvuruBelgeKontrolTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			birBasvuruBelgeKontrolTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			birBasvuruBelgeKontrolTx.setBelgeIstisnasi(iMap.getString("BELGE_ISTISNASI"));			
			session.saveOrUpdate(birBasvuruBelgeKontrolTx);
			session.flush();
			
			iMap.put("TRX_NAME", "3235");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3235_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			String tableName;
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrolTx = (BirBasvuruBelgeKontrolTx) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			oMap.put("BASVURU_NO", birBasvuruBelgeKontrolTx.getId().getBasvuruNo());
			oMap.put("BELGE_ISTISNASI", birBasvuruBelgeKontrolTx.getBelgeIstisnasi());
			oMap.put("ACIKLAMA" , birBasvuruBelgeKontrolTx.getIstisnaGorusu());						
			if(birBasvuruBelgeKontrolTx.getBelgeIstisnasi() != null){

				if(birBasvuruBelgeKontrolTx.getBelgeIstisnasi().equals("I")){
					tableName = "BELGELER";
				}
				else{
					tableName = "BELGE";
				}

			}
			else{
				tableName = null;
			}
			
			
			if(tableName != null){
				
				int i = 0;
				List<BirBasvuruBelgeTx> birBasvuruBelgeList = (List<BirBasvuruBelgeTx>) session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

				for(BirBasvuruBelgeTx birBasvuruBelgeTx : birBasvuruBelgeList){

					oMap.put(tableName, i, "BELGE_KOD",birBasvuruBelgeTx.getId().getDokumanKod());
					oMap.put(tableName, i, "KIMDEN",birBasvuruBelgeTx.getId().getKimden());
					oMap.put(tableName, i, "KIMDEN_ACIKLAMA", LovHelper.diLov(birBasvuruBelgeTx.getId().getKimden(),"3181/LOV_BASVURU_KISI","ACIKLAMA"));
					oMap.put(tableName, i, "BELGE_ADI", LovHelper.diLov(birBasvuruBelgeTx.getId().getDokumanKod(),"3182/LOV_BELGE_KOD","ACIKLAMA"));
					oMap.put(tableName, i, "BASVURU_NO",birBasvuruBelgeTx.getId().getBasvuruNo());
					oMap.put(tableName, i, "DOSYA_ADI",birBasvuruBelgeTx.getBelgeAdi());
					oMap.put(tableName, i, "BELGE_KONTROL",birBasvuruBelgeTx.getBelgeKontrol());
					oMap.put(tableName, i, "GELIS_TARIHI",birBasvuruBelgeTx.getBelgeGelisTarihi());
					oMap.put(tableName, i, "KONTROL_NEDENI",birBasvuruBelgeTx.getKontrolNedeni());
					oMap.put(tableName, i, "ORJINAL_EVRAK_MI",birBasvuruBelgeTx.getOrjinalEvrakMi());
					oMap.put(tableName, i, "BELGE_HATA",birBasvuruBelgeTx.getBelgeHata());
					oMap.put(tableName, i, "BARKOD_NO",birBasvuruBelgeTx.getBarkodNumarasi());
					oMap.put(tableName, i, "ONAYLI_MI",birBasvuruBelgeTx.getOnayliMi());
                    oMap.put(tableName, i, "UYUMSUZ_ACIKLAMA",birBasvuruBelgeTx.getUyumsuzAciklama());
                    oMap.put(tableName, i, "ACIKLAMA",birBasvuruBelgeTx.getKontrolNedeni());
					
					i++;
				}
				
			}		
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_BELGE_KALDIR_KONTROL")
	public static GMMap belgeKaldirKontrol(GMMap iMap) {

		String msj = "";
		int k=0;
		try {

			String tableName = "BELGE";

			for (int i = 0; i < iMap.getSize(tableName); i++) {
				if (iMap.getBoolean(tableName, i, "CHK_KALDIR") == true) {
					k++;
					msj = msj + iMap.getString(tableName, i, "BELGE_ADI") + ", "+(k%4==0?"<br />":"");
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		msj=StringUtils.strip(msj, ", "+(k%4==0?"<br />":"")).trim();
		
		if (!msj.isEmpty()) {
			msj+=" belge listesinden ��kar�lacakt�r. Devam etmek istiyor musunuz?";
		}
		
		return iMap.put("UYARI_MESAJI", msj);
	}
	
	@GraymoundService("BNSPR_TRN3235_ONCEKI_ACIKLAMA")
	public static GMMap oncekiAciklama(GMMap iMap) {
	    GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<BirBasvuruBelgeKontrolTx> birBasvuruBelgeKontrolList = (List<BirBasvuruBelgeKontrolTx>) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("id.txNo")).list();
			int row = 0;
			for(BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrol : birBasvuruBelgeKontrolList ) {
				 oMap.put("ONCEKI_ACIKLAMA", row , "VALUE", ""+row);
				 String rec_owner = DALUtil.getResult("SELECT rec_owner FROM bnspr.bir_basvuru_belge_kontrol_tx where tx_no = "+birBasvuruBelgeKontrol.getId().getTxNo());
				 String rec_date  = DALUtil.getResult("SELECT TO_CHAR(rec_date,'DD/MM/YYYY HH24:MI:SS') FROM bnspr.bir_basvuru_belge_kontrol_tx where tx_no = "+birBasvuruBelgeKontrol.getId().getTxNo());
				 String gorus     = ""+birBasvuruBelgeKontrol.getIstisnaGorusu();
				 if("null".equals(gorus)) {
					 gorus = " " + rec_date + " " + rec_owner;
				 } else {
					 gorus += " " + rec_date + " " + rec_owner;
				 }
				 oMap.put("ONCEKI_ACIKLAMA", row , "NAME", gorus);					
				 row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}	
	
	@GraymoundService("BNSPR_TRN3235_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
	    GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrol = (BirBasvuruBelgeKontrolTx)session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			
			if(birBasvuruBelgeKontrol != null){
				if("KUL".equals(birBasvuruBelgeKontrol.getIslemSonrasiDurumKodu())){
					iMap.put("TRX_ONAYSIZ_ISLEM", "E");			
					iMap.put("BASVURU_NO", birBasvuruBelgeKontrol.getId().getBasvuruNo());
					iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3171_GET_MUSTERINO", iMap));
					iMap.put("MUSTERI_KONTAKT", GMServiceExecuter.execute("BNSPR_TRN1040_GET_MUSTERI_TUR_KONTAKT", iMap));
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_OTOMATIK_KULLANDIR", iMap));
				}
			}
		
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}	
}
