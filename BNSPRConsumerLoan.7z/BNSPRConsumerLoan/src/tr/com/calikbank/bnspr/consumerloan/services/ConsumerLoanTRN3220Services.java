package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.NbsmReasonCodePrTx;
import tr.com.aktifbank.bnspr.dao.NbsmReasonCodePrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3220Services {

	@GraymoundService("BNSPR_TRN3220_GET_LIST")
	public static GMMap getBelgeler(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn3220.Get_List}");
			stmt.registerOutParameter(1, -10);

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "REASON_CODE");
			
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3220_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "REASON_CODE";
			List<?> list = (List<?>)iMap.get(tableName);
			
			for (int i = 0; i < list.size(); i++) {
				NbsmReasonCodePrTx nbsmReasonCodePrTx = new NbsmReasonCodePrTx();
				NbsmReasonCodePrTxId nbsmReasonCodePrTxId = new NbsmReasonCodePrTxId();
				
				nbsmReasonCodePrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				nbsmReasonCodePrTxId.setKod(iMap.getString(tableName, i, "KOD"));
				
				nbsmReasonCodePrTx.setId(nbsmReasonCodePrTxId);
				nbsmReasonCodePrTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				if("1".equals(iMap.getString(tableName, i, "IPTAL")))
     				nbsmReasonCodePrTx.setDurum("IPTAL");
				else
					nbsmReasonCodePrTx.setDurum("GUNCEL");
				
				session.save(nbsmReasonCodePrTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "3220");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3220_VIEW")
	public static GMMap view(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String tableName = "REASON_CODE";
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(NbsmReasonCodePrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for (int i = 0; i < list.size(); i++) {
				NbsmReasonCodePrTx nbsmReasonCodePrTx = (NbsmReasonCodePrTx) list.get(i);
				oMap.put(tableName, i, "KOD", nbsmReasonCodePrTx.getId().getKod());
				oMap.put(tableName, i, "ACIKLAMA", nbsmReasonCodePrTx.getAciklama());
				if("IPTAL".equals(nbsmReasonCodePrTx.getDurum()))
					oMap.put(tableName, i, "IPTAL", "1");
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}

}
