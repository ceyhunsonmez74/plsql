package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.tree.checkbox.TristateTreeNode;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY3958Services {
	final static String[] services = { "AVEA", "TURKCELL", "TURK_TELEKOM", "VODAFONE" };

	@GraymoundService("BNSPR_QRY3958_MUSTERI_BILGI")
	public static GMMap musteriBilgiSorgulama(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		if (isNull(iMap.getString("BASVURU_NO")) && isNull(iMap.getString("MUSTERI_NO"))) {
			return oMap;
		}

		try {
			String func = null;
			BigDecimal sorguParameter = null;
			if ("GNL_MUSTERI".equals(iMap.getString("ISLEM"))) {
				func = "{ ? = call PKG_IST_BILINMEYEN_NUMARA.RC_MUSTERI_BILGI(?,?) }";
				sorguParameter = iMap.getBigDecimal("MUSTERI_NO");
			} else if ("BIR_BASVURU".equals(iMap.getString("ISLEM"))) {
				func = "{ ? = call PKG_IST_BILINMEYEN_NUMARA.RC_BASVURU_BILGI(?,?) }";
				sorguParameter = iMap.getBigDecimal("BASVURU_NO");
			} else if ("KK_BASVURU".equals(iMap.getString("ISLEM"))) {
				func = "{ ? = call PKG_IST_BILINMEYEN_NUMARA.RC_KK_BASVURU_BILGI(?,?) }";
				sorguParameter = iMap.getBigDecimal("BASVURU_NO");
			} else {
				return oMap;
			}
			//Bilgileri getir.
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = sorguParameter;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = "KIMLIK";
			sorguMap.clear();
			sorguMap.putAll(DALUtil.callOracleRefCursorFunction(func, "KIMLIK_TABLO", inputValues));

			oMap.put("MUSTERI_NO", sorguMap.get("KIMLIK_TABLO", 0, "MUSTERI_NO"));
			oMap.put("AD", sorguMap.get("KIMLIK_TABLO", 0, "AD"));
			oMap.put("SOYAD", sorguMap.get("KIMLIK_TABLO", 0, "SOYAD"));
			oMap.put("IL_KOD", sorguMap.get("KIMLIK_TABLO", 0, "IL_KOD"));

			inputValues = new Object[4];
			i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = sorguParameter;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i] = "TELEFON";
			sorguMap.clear();
			sorguMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TELEFON_TABLO", inputValues));
			oMap.put("TELEFON_TABLO", sorguMap.get("TELEFON_TABLO"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3958_GET_COMBO_PARAMETERS")
	public static GMMap comboParameters(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		ResultSet rSet = null;
		Statement stmt = null;
		DALUtil.fillComboBox(oMap, "IL", true, "select kod, il_adi from gnl_il_kod_pr where kod != 200 order by IL_ADI");
		DALUtil.fillComboBox(oMap, "SORGU_TURU", true, "select key1, text from gnl_param_text where kod = 'PARAM_REF_TUR' and key3 is null order by text");

		// Telekom firmalar�n� checkbox'dan alaca��m�z i�in a�a��daki k�s�ma gerek yok
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.createStatement();
			rSet = stmt.executeQuery("select kod, key1, text from gnl_param_text where  kod = 'TELEKOM_FIRMA'");

			TristateTreeNode root = new TristateTreeNode(new GMMap());

			while (rSet.next()) {
				GMMap roleMap = new GMMap();
				roleMap.put("OID", rSet.getObject("KOD"));
				roleMap.put("NAME", rSet.getObject("KEY1"));
				roleMap.put("SELECTED", rSet.getObject("TEXT"));
				root.add(new TristateTreeNode(roleMap));
			}

			oMap.put("LIST", root);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3958_BILINMEYEN_NUMARA_SORGU")
	public static GMMap sorguBilinmeyenNumara(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();

		int rowPhoneBookType = 0;
		for (String serviceName : services) {
			if (iMap.getBoolean("SERVIS_" + serviceName)) {
				sMap.put("PHONEBOOK_TYPE_SET", rowPhoneBookType++, "PHONEBOOK_TYPE", serviceName);
			}
		}

		if (isNull(iMap.getString("SORGU_TUR"))) {
			throw new GMRuntimeException(0, "Bilinmeyen numara sorgulma sekli secili olmalidir, Kisi ya da Secili Numara.");
		}

		if (iMap.getString("SORGU_TUR").equals("NUMARA") && (isNull(iMap.getString("TEL_NO")) || iMap.getString("TEL_NO").length() != 10)) {
			throw new GMRuntimeException(0, "Numara ile sorgulamada telefon bilgisi secili/ dogru tanimli olmalidir.");
		}

		if (iMap.getString("SORGU_TUR").equals("KISI")) {
			if (isNull(iMap.getString("AD")) || isNull(iMap.getString("IL_KOD"))) {
				throw new GMRuntimeException(0, "Kisi ile sorgulamada ad / unvan, soyad ve il tanimli olmalidir.");
			}

			if (rowPhoneBookType == 0) {
				throw new GMRuntimeException(0, "Kisi ile sorgulamada en az bir servis secili olmalidir.");
			}
		}

		if (!isNull(iMap.getString("BASVURU_NO"))) {
			sMap.put("PARAM_REF_TUR", iMap.getString("ISLEM_TUR"));
			sMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
		}
		else if (!isNull(iMap.getString("MUSTERI_NO"))) {
			sMap.put("PARAM_REF_TUR", "GNL_MUSTERI");
			sMap.put("PARAM_REF_ID", iMap.getString("MUSTERI_NO"));
		}
		else if (!isNull(iMap.getString("AD"))) {
			sMap.put("PARAM_REF_TUR", "GENEL");
			sMap.put("PARAM_REF_ID", trCharReplace(iMap.getString("AD") + " " + iMap.getString("SOYAD")));
		}
		else if (!isNull(iMap.getString("TEL_NO"))) {
			sMap.put("PARAM_REF_TUR", "GENEL");
			sMap.put("PARAM_REF_ID", iMap.getString("TEL_NO"));
		}

		sMap.put("PHONE_NUMBER", iMap.getString("TEL_NO"));
		sMap.put("CLIENT_QUERY_NO", "1");
		sMap.put("FIRST_NAME", iMap.getString("AD"));
		sMap.put("LAST_NAME", iMap.getString("SOYAD"));
		sMap.put("CITY_CODE", iMap.getString("IL_KOD"));
		sMap.put("DISTRICT_NAME", "");
		sMap.put("CONTACT_TYPE_ENUM_VALUE", (iMap.getString("SOYAD") != null) ? "PERSON" : "CORPORATION");
		sMap.put("PAGE_NUMBER", "");

		try {
			if (iMap.getString("SORGU_TUR").equals("NUMARA")) {
				GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NUMBER", sMap);
			}
			else if (iMap.getString("SORGU_TUR").equals("KISI")) {
				GMServiceExecuter.call("BNSPR_UNKNOWN_NUMBERS_GET_PHONEBOOK_WITH_NAME", sMap);
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3958_BILINMEYEN_NUMARA_LISTELE", sMap));
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3958_BILINMEYEN_NUMARA_SORGU_ISLEM")
	public static GMMap sorguBilinmeyenNumaraIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		if (isNull(iMap.getString("ISLEM_TUR"))) {
			throw new GMRuntimeException(0, "Sorgu turu secili olmalidir.");
		}
		else if (isNull(iMap.getString("BASVURU_NO")) && 
				("BIR_BASVURU".equals(iMap.getString("ISLEM_TUR")) || "KK_BASVURU".equals(iMap.getString("ISLEM_TUR"))) ) {
			throw new GMRuntimeException(0, "Basvuru no tanimli olmalidir.");
		}
		else if (iMap.getString("ISLEM_TUR").equals("GNL_MUSTERI") && isNull(iMap.getString("MUSTERI_NO"))) {
			throw new GMRuntimeException(0, "Musteri no tanimli olmalidir.");
		}
		
		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3958_BILINMEYEN_NUMARA_SORGU", iMap));
		return oMap;

	}

	@GraymoundService("BNSPR_QRY3958_BILINMEYEN_NUMARA_SORGU_MANUEL")
	public static GMMap sorguBilinmeyenNumaraManuel(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3958_BILINMEYEN_NUMARA_SORGU", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3958_BILINMEYEN_NUMARA_LISTELE")
	public static GMMap sorguBilinmeyenNumaraListele(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (isNull(iMap.getString("PARAM_REF_TUR"))) {
			if (!isNull(iMap.getString("BASVURU_NO")) && !isNull(iMap.getString("ISLEM"))) {
				iMap.put("PARAM_REF_TUR", iMap.getString("ISLEM"));
				iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
			}
			else if (!isNull(iMap.getString("MUSTERI_NO"))) {
				iMap.put("PARAM_REF_TUR", "GNL_MUSTERI");
				iMap.put("PARAM_REF_ID", iMap.getString("MUSTERI_NO"));
			}
			else if (!isNull(iMap.getString("AD"))) {
				iMap.put("PARAM_REF_TUR", "GENEL");
				iMap.put("PARAM_REF_ID", trCharReplace(iMap.getString("AD") + " " + iMap.getString("SOYAD")));
			}
			else if (!isNull(iMap.getString("TEL_NO"))) {
				iMap.put("PARAM_REF_TUR", "GENEL");
				iMap.put("PARAM_REF_ID", iMap.getString("TEL_NO"));
			}
			else {
				return oMap;
			}
		}

		String func = "{ ? = call PKG_IST_BILINMEYEN_NUMARA.rc_ist_bilinmeyen_numara_cevap(?,?) }";
		Object[] inputValues = new Object[4];
		int i = 0;
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = iMap.getString("PARAM_REF_ID");
		inputValues[i++] = BnsprType.STRING;
		inputValues[i++] = iMap.getString("PARAM_REF_TUR");

		try {
			oMap = DALUtil.callOracleRefCursorFunction(func, "TABLE", inputValues);
			oMap.put("SONUC", "Sorgu sonucu toplam " + oMap.getSize("TABLE") + " rehber kaydi bulunmustur.");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3958_BILINMEYEN_NUMARA_LISTELE_ISLEM")
	public static GMMap sorguBilinmeyenNumaraListeleIslem(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3958_BILINMEYEN_NUMARA_LISTELE", iMap));
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3958_BILINMEYEN_NUMARA_LISTELE_MANUEL")
	public static GMMap sorguBilinmeyenNumaraListeleManuel(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3958_BILINMEYEN_NUMARA_LISTELE", iMap));
		return oMap;
	}
	
	public static String trCharReplace(String text) {
		String trStr = "������������";
		String enStr = "cigousCIGOUS";
		char trArr[] = trStr.toCharArray();
		char enArr[] = enStr.toCharArray();

		String str = text;

		if (str != null) {
			for (int i = 0; i < trStr.length(); i++) {
				str = str.replace(trArr[i], enArr[i]);
			}
		}

		return str;
	}

	public static boolean isNull(String text) {
		boolean status = false;

		if (text == null)
			status = true;
		else if (text.isEmpty())
			status = true;
		else if (text == "")
			status = true;

		return status;
	}
}
