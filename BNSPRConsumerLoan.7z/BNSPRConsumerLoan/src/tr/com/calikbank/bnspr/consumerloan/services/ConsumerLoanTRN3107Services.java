package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirOdmGrpTanim;
import tr.com.calikbank.bnspr.dao.BirOdmGrpTanimTx;
import tr.com.calikbank.bnspr.dao.BirOdmGrpTanimTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3107Services {
	@GraymoundService("BNSPR_TRN3107_GET_ODEME_GRUP_TANIM")
	public static GMMap getOdemeGrupTanim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> odemGrubuTanimPersistenceList = (List<?>) session.createCriteria(BirOdmGrpTanim.class).add(Restrictions.eq("id.odmGrpKod", iMap.getBigDecimal("ODM_GRP_KOD"))).list();
			GMMap oMap = new GMMap();
			
			String tableName = "ODEME_GRUP_TANIM";
			int row = 0;
			for (Iterator<?> iterator = odemGrubuTanimPersistenceList.iterator(); iterator.hasNext();row++) {
				BirOdmGrpTanim birOdmGrpTanim = (BirOdmGrpTanim) iterator.next();
				
				oMap.put(tableName, row, "ODM_TIP_KOD", birOdmGrpTanim.getId().getOdmTipKod());
				oMap.put(tableName, row, "OT_ACIKLAMA", LovHelper.diLov(birOdmGrpTanim.getId().getOdmTipKod(), "3107/LOV_ODEME_TIPI", "ACIKLAMA"));
				oMap.put(tableName, row, "MIN_VADE", birOdmGrpTanim.getMinVade());
				oMap.put(tableName, row, "MAX_VADE", birOdmGrpTanim.getMaxVade());
				oMap.put(tableName, row, "MIN_ORAN", birOdmGrpTanim.getMinOran());
				oMap.put(tableName, row, "MAX_ORAN", birOdmGrpTanim.getMaxOran());
				oMap.put(tableName, row, "MIN_TUT", birOdmGrpTanim.getMinTut());
				oMap.put(tableName, row, "MAX_TUT", birOdmGrpTanim.getMaxTut());
				oMap.put(tableName, row, "MIN_PERIYOD", birOdmGrpTanim.getMinPeriyod());
				oMap.put(tableName, row, "MAX_PERIYOD", birOdmGrpTanim.getMaxPeriyod());
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3107_GET_RECORD")
	public static GMMap getRecord(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> odemGrubuTanimPersistenceList = (List<?>) session.createCriteria(BirOdmGrpTanimTx.class).add(Restrictions.and(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")),Restrictions.isNull("sil"))).list();
			GMMap oMap = new GMMap();
			String tableName = "ODEME_GRUP_TANIM";
			int row = 0;
			for (Iterator<?> iterator = odemGrubuTanimPersistenceList.iterator(); iterator.hasNext();row++) {
				BirOdmGrpTanimTx birOdmGrpTanimTx = (BirOdmGrpTanimTx) iterator.next();
				
				oMap.put("ODEME_GRUBU", birOdmGrpTanimTx.getId().getOdmGrpKod());
				oMap.put("DI_ODEME_GRUBU", birOdmGrpTanimTx.getOdmGrpAdi());
				oMap.put("DURUM", birOdmGrpTanimTx.getOdmGrpDrm());
				oMap.put(tableName, row, "ODM_TIP_KOD", birOdmGrpTanimTx.getId().getOdmTipKod());
				oMap.put(tableName, row, "OT_ACIKLAMA", LovHelper.diLov(birOdmGrpTanimTx.getId().getOdmTipKod(), "3107/LOV_ODEME_TIPI", "ACIKLAMA"));
				oMap.put(tableName, row, "MIN_VADE", birOdmGrpTanimTx.getMinVade());
				oMap.put(tableName, row, "MAX_VADE", birOdmGrpTanimTx.getMaxVade());
				oMap.put(tableName, row, "MIN_ORAN", birOdmGrpTanimTx.getMinOran());
				oMap.put(tableName, row, "MAX_ORAN", birOdmGrpTanimTx.getMaxOran());
				oMap.put(tableName, row, "MIN_TUT", birOdmGrpTanimTx.getMinTut());
				oMap.put(tableName, row, "MAX_TUT", birOdmGrpTanimTx.getMaxTut());
				oMap.put(tableName, row, "MIN_PERIYOD", birOdmGrpTanimTx.getMinPeriyod());
				oMap.put(tableName, row, "MAX_PERIYOD", birOdmGrpTanimTx.getMaxPeriyod());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3107_SAVE_ODEME_GRUP_TANIM")
	public static Map<?, ?> saveDemeGrupTanim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "ODEME_GRUP_TANIM";
			List<?> list = (List<?>) iMap.get(tableName);
			if (list.size() == 0) {
				// Connection conn = null;
				// CallableStatement stmt = null;
				// try{
				// conn = DALUtil.getGMConnection();
				// stmt = conn.prepareCall("{call PKG_TRN3107.TumKayitSil(?,
				// ?)}");
				// stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
				// stmt.setBigDecimal(2, iMap.getBigDecimal("ODM_TIP_KOD"));
				// stmt.execute();
				//					
				// }catch (SQLException e) {
				// throw new GMRuntimeException(0,e);
				// }finally{
				// GMServerDatasource.close(stmt);
				// GMServerDatasource.close(conn);
				// }

				iMap.put("HATA_NO", new BigDecimal(442));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);

			} else {
				for (int i = 0; i<list.size(); i++) {
					BirOdmGrpTanimTx birOdmGrpTanimTx = (BirOdmGrpTanimTx) session.get(BirOdmGrpTanimTx.class, new BirOdmGrpTanimTxId(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal("ODM_GRP_KOD"), iMap.getBigDecimal(tableName, i, "ODM_TIP_KOD")));
					if (birOdmGrpTanimTx == null) {
						birOdmGrpTanimTx = new BirOdmGrpTanimTx();
						BirOdmGrpTanimTxId id = new BirOdmGrpTanimTxId();
						id.setOdmGrpKod(iMap.getBigDecimal("ODM_GRP_KOD"));
						id.setOdmTipKod(iMap.getBigDecimal(tableName, i, "ODM_TIP_KOD"));
						id.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birOdmGrpTanimTx.setId(id);
					}
					birOdmGrpTanimTx.setOdmGrpDrm(iMap.getString("DURUM"));
					birOdmGrpTanimTx.setOdmGrpAdi(iMap.getString("ODM_GRUP_ADI"));

					birOdmGrpTanimTx.setMaxOran(iMap.getBigDecimal(tableName, i, "ODM_TIP_KOD"));
					birOdmGrpTanimTx.setMinVade(iMap.getBigDecimal(tableName, i, "MIN_VADE"));
					birOdmGrpTanimTx.setMaxVade(iMap.getBigDecimal(tableName, i, "MAX_VADE"));
					birOdmGrpTanimTx.setMinOran(iMap.getBigDecimal(tableName, i, "MIN_ORAN"));
					birOdmGrpTanimTx.setMaxOran(iMap.getBigDecimal(tableName, i, "MAX_ORAN"));
					birOdmGrpTanimTx.setMinTut(iMap.getBigDecimal(tableName, i, "MIN_TUT"));
					birOdmGrpTanimTx.setMaxTut(iMap.getBigDecimal(tableName, i, "MAX_TUT"));
					birOdmGrpTanimTx.setMinPeriyod(iMap.getBigDecimal(tableName, i, "MIN_PERIYOD"));
					birOdmGrpTanimTx.setMaxPeriyod(iMap.getBigDecimal(tableName, i, "MAX_PERIYOD"));
					
					
					if (iMap.getString(tableName, i, "ODM_TIP_KOD").compareTo("8") ==0){
						birOdmGrpTanimTx.setOdmPeriyodTipKod("D");
					}else if (iMap.getString(tableName, i, "ODM_TIP_KOD").compareTo("9")==0){
						birOdmGrpTanimTx.setOdmPeriyodTipKod("M");
					}else if (iMap.getString(tableName, i, "ODM_TIP_KOD").compareTo("10")==0){
						birOdmGrpTanimTx.setOdmPeriyodTipKod("W");
					}else if (iMap.getString(tableName, i, "ODM_TIP_KOD").compareTo("11")==0){
						birOdmGrpTanimTx.setOdmPeriyodTipKod("Y");
					}else{
						birOdmGrpTanimTx.setOdmPeriyodTipKod("M");
					}
					session.save(birOdmGrpTanimTx);
				}
			}
			session.flush();
			iMap.put("TRX_NAME", "3107");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3107_GET_ODEME_GRUBU")
	public static GMMap getOdemeGrubu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_GENEL_PR.GENEL_KOD_AL('BIR_ODM_GRP_PR')}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();
			BigDecimal odemeGrup = stmt.getBigDecimal(1);
			oMap.put("ODEME_GRUBU", odemeGrup);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
