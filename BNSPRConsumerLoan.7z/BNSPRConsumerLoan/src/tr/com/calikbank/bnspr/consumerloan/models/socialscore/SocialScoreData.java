package tr.com.calikbank.bnspr.consumerloan.models.socialscore;

public class SocialScoreData {
	private CustomerBehaviour[] CustomerBehaviour;

    public CustomerBehaviour[] getCustomerBehaviour ()
    {
        return CustomerBehaviour;
    }

    public void setCustomerBehaviour (CustomerBehaviour[] CustomerBehaviour)
    {
        this.CustomerBehaviour = CustomerBehaviour;
    }
    
    private DeviceInformation DeviceInformation;

    public DeviceInformation getDeviceInformation ()
    {
        return DeviceInformation;
    }

    public void setDeviceInformation (DeviceInformation DeviceInformation)
    {
        this.DeviceInformation = DeviceInformation;
    }

}
