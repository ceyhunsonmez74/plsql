package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BayiBasvuruDegerlendirmeTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiBasvuruDegTx;
import tr.com.aktifbank.bnspr.dao.BpmProcessDetail;
import tr.com.aktifbank.bnspr.dao.BpmTask;
import tr.com.aktifbank.bnspr.dao.BpmTaskId;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeGonderiKarar;
import tr.com.aktifbank.bnspr.dao.UrunRiskSinifAction;
import tr.com.aktifbank.bnspr.dao.UrunRiskSinifParametre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.GnlilKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPr;
import tr.com.calikbank.bnspr.dao.GnlilceKodPrId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.Validator;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN8030Services {

	@GraymoundService("BNSPR_TRN8030_FILL_TABLE_COMBOBOX")
	public static GMMap fillTableComboBox(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			GMMap oMap = new GMMap();

			String listName = "AKTIFLIK";			
			GuimlUtil.wrapMyCombo(oMap, listName, "A", "AKTIF");
			GuimlUtil.wrapMyCombo(oMap, listName, "P", "PASIF");
			
			iMap.put("KOD", "EVET_HAYIR");
			oMap.put("ORTAK_CALISAN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			listName = "ARAMA_SIRALAMA";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "R", "Risk");
			GuimlUtil.wrapMyCombo(oMap, listName, "G", "GGS");
			
			listName = "FPD";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
			
			listName = "TEKCIFT";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "T", "Tek");
			GuimlUtil.wrapMyCombo(oMap, listName, "C", "Cift");
			
			listName = "VEFAT";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
			
			listName = "FRAUD";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
			
			listName = "VYS";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
			
			listName = "POTANSIYEL";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
			
			listName = "SKOR";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "L", "D���k");
			GuimlUtil.wrapMyCombo(oMap, listName, "M", "Orta");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "Y�ksek");

			listName = "KANAL";
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select kod,aciklama from gnl_kanal_grup_kod_pr where kod IN('1','2','4','7','8') order by aciklama asc");

			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			rSet = stmt.executeQuery();			
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
			}
			
			listName = "URUN";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "BK", "BK");
			GuimlUtil.wrapMyCombo(oMap, listName, "KK", "KK");
			GuimlUtil.wrapMyCombo(oMap, listName, "KMH", "KDH");

			listName = "ACTION";
			GuimlUtil.wrapMyCombo(oMap, listName, StringUtils.EMPTY, "Se�iniz");
			GuimlUtil.wrapMyCombo(oMap, listName, "I", "IVN");
			GuimlUtil.wrapMyCombo(oMap, listName, "S", "SMS");
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "EMAIL");
			GuimlUtil.wrapMyCombo(oMap, listName, "M", "MEKTUP");
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select key1,text from bnspr.gnl_param_text a where a.kod = 'TAKIP_FIRMA_KOD' order by a.text asc");

			String kod = StringUtils.EMPTY;
			String aciklama = StringUtils.EMPTY;
			
			rSet = stmt.executeQuery();			
			while (rSet.next()) {
				kod = rSet.getString(1);
				aciklama = rSet.getString(2);	
				
				GuimlUtil.wrapMyCombo(oMap, "FIRMA1", kod, aciklama);
				GuimlUtil.wrapMyCombo(oMap, "FIRMA2", kod, aciklama);
				GuimlUtil.wrapMyCombo(oMap, "FIRMA3", kod, aciklama);
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN8030_GET_SINIF_KOD")
	public static GMMap getSinifKod(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('URUN_RISK_SINIF_PARAMETRE')}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();

			BigDecimal code = stmt.getBigDecimal(1);

			oMap.put("SINIF_KOD", code);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN8030_GET_ACTION_KOD")
	public static GMMap getActionKod(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('URUN_RISK_SINIF_ACTION')}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();

			BigDecimal code = stmt.getBigDecimal(1);

			oMap.put("ACTION_KOD", code);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN8030_GET_SINIFLAR")
	public static Map<?,?> getSinifParametreler(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> sinifParametreList = (List<?>) session.createCriteria(UrunRiskSinifParametre.class).addOrder(Order.asc("kod")).list();
			String tableName = "SINIF_RESULT";
			int row = 0;
			for (Iterator<?> iterator = sinifParametreList.iterator(); iterator.hasNext();row++) {
				UrunRiskSinifParametre urunRiskSinifParametre = (UrunRiskSinifParametre) iterator.next();
				oMap.put(tableName, row, "KOD", urunRiskSinifParametre.getKod());
				oMap.put(tableName, row, "AKTIFLIK", urunRiskSinifParametre.getAktiflik());
				oMap.put(tableName, row, "ONCELIK", urunRiskSinifParametre.getOncelik() );
				oMap.put(tableName, row, "ARAMA_SIRALAMA", urunRiskSinifParametre.getAramaSiralama() );
				oMap.put(tableName, row, "FPD", urunRiskSinifParametre.getFpd());
				oMap.put(tableName, row, "TEKCIFT", urunRiskSinifParametre.getTekcift());
				oMap.put(tableName, row, "VEFAT", urunRiskSinifParametre.getVefat());
				oMap.put(tableName, row, "FRAUD", urunRiskSinifParametre.getFraud());
				oMap.put(tableName, row, "VYS", urunRiskSinifParametre.getVys() );
				oMap.put(tableName, row, "POTANSIYEL", urunRiskSinifParametre.getPotansiyel() );
				oMap.put(tableName, row, "SKOR", urunRiskSinifParametre.getSkor() );
				oMap.put(tableName, row, "GECIKEN_RISK_MIN", urunRiskSinifParametre.getGecikenRiskMin() );
				oMap.put(tableName, row, "GECIKEN_RISK_MAX", urunRiskSinifParametre.getGecikenRiskMax() );
				oMap.put(tableName, row, "URUN_RISK_MIN", urunRiskSinifParametre.getUrunRiskMin() );
				oMap.put(tableName, row, "URUN_RISK_MAX", urunRiskSinifParametre.getUrunRiskMax() );
				oMap.put(tableName, row, "TOPLAM_MUSTERI_RISK_MIN", urunRiskSinifParametre.getToplamMusteriRiskMin()  );
				oMap.put(tableName, row, "TOPLAM_MUSTERI_RISK_MAX", urunRiskSinifParametre.getToplamMusteriRiskMax() );
				oMap.put(tableName, row, "GGS_MIN", urunRiskSinifParametre.getGgsMin() );				
				oMap.put(tableName, row, "GGS_MAX", urunRiskSinifParametre.getGgsMax() );
				oMap.put(tableName, row, "KANAL", urunRiskSinifParametre.getKanalKodu() );
				oMap.put(tableName, row, "URUN", urunRiskSinifParametre.getUrunTurKodu() );
				oMap.put(tableName, row, "FIRMA1", urunRiskSinifParametre.getFirma1Kodu());
				oMap.put(tableName, row, "FIRMA1_YUZDE", urunRiskSinifParametre.getFirma1Yuzde() );
				oMap.put(tableName, row, "FIRMA2", urunRiskSinifParametre.getFirma2Kodu());
				oMap.put(tableName, row, "FIRMA2_YUZDE", urunRiskSinifParametre.getFirma2Yuzde() );
				oMap.put(tableName, row, "FIRMA3", urunRiskSinifParametre.getFirma3Kodu());
				oMap.put(tableName, row, "FIRMA3_YUZDE", urunRiskSinifParametre.getFirma3Yuzde() );
			}
			
			return oMap;
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8030_GET_ACTIONLAR")
	public static Map<?,?> getSinifActions(GMMap iMap){
		GMMap oMap = new GMMap();
		
		Object o = GMContext.getCurrentContext().getSession().get("ACTIONS_" + iMap.getString("SINIF_KOD"));
		if(o == null){
		try {
				ArrayList<HashMap<String, Object>> actionOutList = new ArrayList<HashMap<String, Object>>();
				Session session = DAOSession.getSession("BNSPRDal");
				
				if(iMap.getString("SINIF_KOD") == null) return oMap;
					
				List<?> actionList = session.createCriteria(UrunRiskSinifAction.class).add(Restrictions.eq("sinifKod",new BigDecimal( iMap.getString("SINIF_KOD")) )).addOrder(Order.asc("kod")).list();
				for (Iterator<?> iterator2 = actionList.iterator(); iterator2.hasNext();) {
					UrunRiskSinifAction action = (UrunRiskSinifAction) iterator2.next();
					HashMap<String, Object> rowData = new HashMap<String, Object>();
					
					rowData.put("KOD", action.getKod() );					
					rowData.put("SINIF", action.getSinifKod());					
					rowData.put("ACTION_TYPE", action.getActionType());
					rowData.put("ACTION_DEGER_ID", action.getActionDegerId());
					
					DcsGecikmeGonderiKarar dcsGecikmeGonderiKarar = (DcsGecikmeGonderiKarar) session.createCriteria(DcsGecikmeGonderiKarar.class).add(Restrictions.eq("id", action.getActionDegerId())).uniqueResult();
					if(dcsGecikmeGonderiKarar != null){
						rowData.put("ACTION_DEGER", dcsGecikmeGonderiKarar.getIcerik());
					}
					
					actionOutList.add(rowData);
				}
				oMap.put("ACTION_RESULT", actionOutList);
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
		else
		{
			oMap.put("ACTION_RESULT", GMContext.getCurrentContext().getSession().get("ACTIONS_" + iMap.getString("SINIF_KOD")));
		}
		
		return oMap;
			
	}
	
	public static UrunRiskSinifParametre findSinif(String kod){
		Session session = DAOSession.getSession("BNSPRDal");
		return (UrunRiskSinifParametre)session.get(UrunRiskSinifParametre.class, new  BigDecimal( kod));
	}
	
	public static UrunRiskSinifAction  findAction(String actionKod){
		Session session = DAOSession.getSession("BNSPRDal");
		//UrunRiskSinifParametre sinif = findSinif(sinifKod );
		return (UrunRiskSinifAction)session.get( UrunRiskSinifAction.class ,new  BigDecimal( actionKod) );
	}

	@GraymoundService("BNSPR_TRN8030_PUT_ACTION_LIST_TO_CONTEX")
	public static Map<?,?> getEmptyModulModel(GMMap iMap){
		GMContext.getCurrentContext().getSession().put("ACTIONS_" + iMap.getString("SINIF_KOD"), iMap.get("ACTION_TANIM"));
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_TRN8030_SAVE")
	public static Map<?, ?>  save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableSinifParametreler = "SINIF_TANIM";
			String tableActions= "ACTION_TANIM";
			
			BigDecimal firmaYuzde2 = null;
			BigDecimal firmaYuzde3 = null;
			BigDecimal firmaToplamYuzde = null;
			
			List<?> siniflarGUIList = (List<?>) iMap.get(tableSinifParametreler);
			//List<?> actionlarGUIList = (List<?>) iMap.get(tableActions);
			
			//Eger action lari silmeden ,sinifi silersek hata vermemiz gerekir ,ama bunu DB yaipyor olmali cunku foregin key iliskisi kurduk  
			
			List<?> siniflarPersistentList = (List<?>) session.createCriteria(UrunRiskSinifParametre.class).addOrder(Order.asc("kod")).list();
			for (Iterator<?> iterator = siniflarPersistentList.iterator(); iterator.hasNext();) {
				UrunRiskSinifParametre sinifInDB = (UrunRiskSinifParametre) iterator.next();
				if(!GuimlUtil.contains(siniflarGUIList, "KOD", sinifInDB.getKod().toString() )){
					/* Silinen siniflarin varsa �nce action larini sil */
					List<?> actionDeleteList = session.createCriteria(UrunRiskSinifAction.class).add(Restrictions.eq("sinifKod",sinifInDB.getKod())).addOrder(Order.asc("kod")).list(); 
					for (Iterator<?> iteratorActionDelete = actionDeleteList.iterator(); iteratorActionDelete.hasNext();) {
						UrunRiskSinifAction actionDelete = ( UrunRiskSinifAction ) iteratorActionDelete.next();
						session.delete(actionDelete);
					}
					session.flush();
					session.delete(sinifInDB);
				}
			}
					
			for (Iterator<?> sinif = siniflarGUIList.iterator(); sinif.hasNext();) {
				HashMap<?, ?> sinifRowData = (HashMap<?, ?>) sinif.next();
				if(GuimlUtil.isDublicateKey(siniflarGUIList, "KOD", new BigDecimal(sinifRowData.get("KOD").toString())))
					throw new GMRuntimeException(0, sinifRowData.get("KOD") + " kodlu ba�ka bir sinif kayd� bulunmaktad�r'");
				
				if(sinifRowData.get("AKTIFLIK") == null || sinifRowData.get("ONCELIK") == null || sinifRowData.get("ARAMA_SIRALAMA") == null ||
					/*sinifRowData.get("TEKCIFT") == null || sinifRowData.get("FPD") == null || sinifRowData.get("VEFAT") == null ||sinifRowData.get("FRAUD") == null || sinifRowData.get("VYS") == null ||
					sinifRowData.get("POTANSIYEL") == null || sinifRowData.get("SKOR") == null ||*/ sinifRowData.get("GECIKEN_RISK_MIN") == null ||
					sinifRowData.get("GECIKEN_RISK_MAX") == null || sinifRowData.get("URUN_RISK_MIN") == null || sinifRowData.get("URUN_RISK_MAX") == null || 
					sinifRowData.get("TOPLAM_MUSTERI_RISK_MIN") == null || sinifRowData.get("TOPLAM_MUSTERI_RISK_MAX") == null ||
				    sinifRowData.get("GGS_MIN") == null || sinifRowData.get("GGS_MAX") == null || /*sinifRowData.get("KANAL") == null ||*/
				    sinifRowData.get("URUN") == null || sinifRowData.get("FIRMA1") == null || sinifRowData.get("FIRMA1_YUZDE") == null){
						throw new GMRuntimeException(0, "L�tfen s�n�f parametresine ait t�m alanlar� doldurunuz!!");
				}
				try{
					if(sinifRowData.get("FIRMA2_YUZDE") != null)
						firmaYuzde2 = new BigDecimal(sinifRowData.get("FIRMA2_YUZDE").toString());
					else
						firmaYuzde2 = BigDecimal.ZERO;
					if(sinifRowData.get("FIRMA3_YUZDE") != null)
						firmaYuzde3 = new BigDecimal(sinifRowData.get("FIRMA3_YUZDE").toString());
					else
						firmaYuzde3 = BigDecimal.ZERO;
				}catch(Exception e){
					firmaYuzde2 = BigDecimal.ZERO;
					firmaYuzde3 = BigDecimal.ZERO;
				}
				
				if(sinifRowData.get("FIRMA2") != null && firmaYuzde2.compareTo(BigDecimal.ZERO) == 0) {
					throw new GMRuntimeException(0, "Firma2 y�zde alan� bo� ya da s�f�r olamaz!!");
				}
				if((sinifRowData.get("FIRMA2") == null && (sinifRowData.get("FIRMA2_YUZDE") != null && new BigDecimal(sinifRowData.get("FIRMA2_YUZDE").toString()).compareTo(BigDecimal.ZERO) == 1))){
					throw new GMRuntimeException(0, "Firma2 alan� bo� olamaz!!");
				}
				if(sinifRowData.get("FIRMA3") != null && firmaYuzde3.compareTo(BigDecimal.ZERO) == 0) {
					throw new GMRuntimeException(0, "Firma3 y�zde alan� bo� ya da s�f�r olamaz!!");
				}
				if((sinifRowData.get("FIRMA3") == null && (sinifRowData.get("FIRMA3_YUZDE") != null && new BigDecimal(sinifRowData.get("FIRMA3_YUZDE").toString()).compareTo(BigDecimal.ZERO) == 1))){
					throw new GMRuntimeException(0, "Firma3 alan� bo� olamaz!!");
				}
				
				UrunRiskSinifParametre sinifInDB = findSinif(sinifRowData.get("KOD").toString());
				
				if(sinifInDB == null)
					sinifInDB = new UrunRiskSinifParametre();
				
				sinifInDB.setKod(StringUtils.isNotEmpty(sinifRowData.get("KOD").toString()) ? new BigDecimal(sinifRowData.get("KOD").toString()) : BigDecimal.ZERO);
				sinifInDB.setAktiflik( sinifRowData.get("AKTIFLIK").toString() );
				sinifInDB.setOncelik(StringUtils.isNotEmpty(sinifRowData.get("ONCELIK").toString()) ? new BigDecimal(sinifRowData.get("ONCELIK").toString()) : BigDecimal.ZERO);
				sinifInDB.setAramaSiralama(sinifRowData.get("ARAMA_SIRALAMA").toString());
				if(sinifRowData.get("FPD") != null)
					sinifInDB.setFpd(sinifRowData.get("FPD").toString());
				else
					sinifInDB.setFpd(StringUtils.EMPTY);
				if(sinifRowData.get("TEKCIFT") != null)
					sinifInDB.setTekcift(sinifRowData.get("TEKCIFT").toString());
				else
					sinifInDB.setTekcift(StringUtils.EMPTY);
				if(sinifRowData.get("VEFAT") != null)
					sinifInDB.setVefat(sinifRowData.get("VEFAT").toString());
				else
					sinifInDB.setVefat(StringUtils.EMPTY);
				if(sinifRowData.get("FRAUD") != null)
					sinifInDB.setFraud(sinifRowData.get("FRAUD").toString());
				else
					sinifInDB.setFraud(StringUtils.EMPTY);
				if(sinifRowData.get("VYS") != null)
					sinifInDB.setVys(sinifRowData.get("VYS").toString());
				else
					sinifInDB.setVys(StringUtils.EMPTY);
				if(sinifRowData.get("POTANSIYEL") != null)
					sinifInDB.setPotansiyel(sinifRowData.get("POTANSIYEL").toString());
				else
					sinifInDB.setPotansiyel(StringUtils.EMPTY);
				if(sinifRowData.get("SKOR") != null)
					sinifInDB.setSkor(sinifRowData.get("SKOR").toString());
				else
					sinifInDB.setSkor(StringUtils.EMPTY);
				sinifInDB.setGecikenRiskMin(StringUtils.isNotEmpty(sinifRowData.get("GECIKEN_RISK_MIN").toString())  ? new BigDecimal(sinifRowData.get("GECIKEN_RISK_MIN").toString()) : BigDecimal.ZERO);
				sinifInDB.setGecikenRiskMax(StringUtils.isNotEmpty(sinifRowData.get("GECIKEN_RISK_MAX").toString())  ? new BigDecimal(sinifRowData.get("GECIKEN_RISK_MAX").toString()) : BigDecimal.ZERO);
				sinifInDB.setUrunRiskMin(StringUtils.isNotEmpty(sinifRowData.get("URUN_RISK_MIN").toString())  ? new BigDecimal(sinifRowData.get("URUN_RISK_MIN").toString()) : BigDecimal.ZERO);
				sinifInDB.setUrunRiskMax(StringUtils.isNotEmpty(sinifRowData.get("URUN_RISK_MAX").toString())  ? new BigDecimal(sinifRowData.get("URUN_RISK_MAX").toString()) : BigDecimal.ZERO);
				sinifInDB.setToplamMusteriRiskMin(StringUtils.isNotEmpty(sinifRowData.get("TOPLAM_MUSTERI_RISK_MIN").toString())  ? new BigDecimal(sinifRowData.get("TOPLAM_MUSTERI_RISK_MIN").toString()) : BigDecimal.ZERO);
				sinifInDB.setToplamMusteriRiskMax(StringUtils.isNotEmpty(sinifRowData.get("TOPLAM_MUSTERI_RISK_MAX").toString())  ? new BigDecimal(sinifRowData.get("TOPLAM_MUSTERI_RISK_MAX").toString()) : BigDecimal.ZERO);
				sinifInDB.setGgsMin(StringUtils.isNotEmpty(sinifRowData.get("GGS_MIN").toString()) ? new BigDecimal(sinifRowData.get("GGS_MIN").toString()) : BigDecimal.ZERO) ;
				sinifInDB.setGgsMax(StringUtils.isNotEmpty(sinifRowData.get("GGS_MAX").toString()) ? new BigDecimal(sinifRowData.get("GGS_MAX").toString()) : BigDecimal.ZERO);
				if(sinifRowData.get("KANAL") != null)
					sinifInDB.setKanalKodu(sinifRowData.get("KANAL").toString());
				else
					sinifInDB.setKanalKodu(null);
				sinifInDB.setUrunTurKodu(sinifRowData.get("URUN").toString() );
				
				firmaToplamYuzde = BigDecimal.ZERO;
				
				if(sinifRowData.get("FIRMA1") != null)
					sinifInDB.setFirma1Kodu(sinifRowData.get("FIRMA1").toString());
				else
					sinifInDB.setFirma1Kodu(StringUtils.EMPTY);
				if(sinifRowData.get("FIRMA1_YUZDE") != null){
					sinifInDB.setFirma1Yuzde(new BigDecimal(sinifRowData.get("FIRMA1_YUZDE").toString()));
					firmaToplamYuzde = firmaToplamYuzde.add(sinifInDB.getFirma1Yuzde());
				}
				else
					sinifInDB.setFirma1Yuzde(BigDecimal.ZERO);
				if(sinifRowData.get("FIRMA2") != null)
					sinifInDB.setFirma2Kodu(sinifRowData.get("FIRMA2").toString());
				else
					sinifInDB.setFirma2Kodu(StringUtils.EMPTY);
				if(sinifRowData.get("FIRMA2_YUZDE") != null){
					sinifInDB.setFirma2Yuzde(new BigDecimal(sinifRowData.get("FIRMA2_YUZDE").toString()));
					firmaToplamYuzde = firmaToplamYuzde.add(sinifInDB.getFirma2Yuzde());
				}
				else
					sinifInDB.setFirma2Yuzde(BigDecimal.ZERO);
				if(sinifRowData.get("FIRMA3") != null)
					sinifInDB.setFirma3Kodu(sinifRowData.get("FIRMA3").toString());
				else
					sinifInDB.setFirma3Kodu(StringUtils.EMPTY);
				if(sinifRowData.get("FIRMA3_YUZDE") != null){
					sinifInDB.setFirma3Yuzde(new BigDecimal(sinifRowData.get("FIRMA3_YUZDE").toString()));
					firmaToplamYuzde = firmaToplamYuzde.add(sinifInDB.getFirma3Yuzde());
				}
				else
					sinifInDB.setFirma3Yuzde(BigDecimal.ZERO);
				
				if(firmaToplamYuzde.compareTo(new BigDecimal(100)) != 0){
					throw new GMRuntimeException(0, "Firma y�zdeler toplam� 100 olmal�d�r!!");
				}
				
				sinifInDB.setCallStartDate((Date)sinifRowData.get("CALL_START_DATE") );
				session.saveOrUpdate(sinifInDB);
				session.flush();
				
				ArrayList<?> actionlarGUIList = (ArrayList<?>) GMContext.getCurrentContext().getSession().get("ACTIONS_" + (String)sinifRowData.get("KOD"));
				
				if(actionlarGUIList != null ){
					//DB de olup ,gui den silinmis olan actionlari siliyoruz
					List<?> actionListPersistent = session.createCriteria(UrunRiskSinifAction.class).add(Restrictions.eq("sinifKod",sinifInDB.getKod())).addOrder(Order.asc("kod")).list(); 
					for (Iterator<?> iterator = actionListPersistent.iterator(); iterator.hasNext();) {
						UrunRiskSinifAction action = ( UrunRiskSinifAction ) iterator.next();
						if(!GuimlUtil.contains(actionlarGUIList, "KOD", new BigDecimal(action.getKod().toString()) ))
							session.delete(action);
					}
					for (Iterator<?> iteratorAction = actionlarGUIList.iterator(); iteratorAction.hasNext();) {
						HashMap<?, ?> actionRowData = (HashMap<?, ?>) iteratorAction.next();
						if(actionRowData.get("KOD") == null){
							throw new GMRuntimeException(0, "Aksiyon kodu bo� olamaz!");
						}
						if(actionRowData.get("ACTION_DEGER") == null || StringUtils.isEmpty(actionRowData.get("ACTION_DEGER").toString()) ||
								actionRowData.get("ACTION_DEGER_ID") == null || StringUtils.isEmpty(actionRowData.get("ACTION_DEGER_ID").toString())){
							throw new GMRuntimeException(0, "G�nderi ��erik alan� bo� olamaz!");
						}
						
						UrunRiskSinifAction actionInDB = findAction( actionRowData.get("KOD").toString());
						
						// SMS ID -75 yazicak mesela
						// IVN ID 43
						if(actionInDB == null){
							actionInDB = new UrunRiskSinifAction();
						}
						actionInDB.setKod(new BigDecimal(actionRowData.get("KOD").toString())); //Unique lik icin
						actionInDB.setActionType( actionRowData.get("ACTION_TYPE").toString()); //mesela SMS
						actionInDB.setActionDegerId(new BigDecimal(actionRowData.get("ACTION_DEGER_ID").toString())); //Mesela 75 
						actionInDB.setSinifKod(new BigDecimal(actionRowData.get("SINIF").toString()) );	//Bagli olunan sinif		
						
						try{
							session.saveOrUpdate(actionInDB);	
						}
						catch (NonUniqueObjectException e) {
							throw new GMRuntimeException(0, "Ayn� kodlu birden fazla action bulunmaktad�r!");
						}
					}
					//cache'i sil
					GMContext.getCurrentContext().getSession().put("ACTIONS_" + (String)sinifRowData.get("KOD"), null);
				}
				session.saveOrUpdate(sinifInDB);
			}
			session.flush();
			//Eger action lari silmeden ,sinifi silersek hata vermemiz gerekir ,ama bunu DB yaipyor olmali cunku foregin key iliskisi kurduk
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r!");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	

}
