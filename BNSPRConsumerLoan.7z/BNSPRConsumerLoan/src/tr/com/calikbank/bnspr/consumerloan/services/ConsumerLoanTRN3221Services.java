package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksBasvuruSigortaPrimTx;
import tr.com.aktifbank.bnspr.dao.ClksBasvuruSigortaPrimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3221Services {
	@GraymoundService("BNSPR_TRN3221_LOAD_EXCEL")
	public static GMMap sigortaKayitlariList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {			
			String tableName = "SIGORTA_DATALARI";
			File file = FileUtil.createTempDirFile("csvread");
			OutputStream writer = new FileOutputStream(file);
			writer.write((byte[])iMap.get("DOSYA"));
			writer.flush();

			BufferedReader br = new BufferedReader(new FileReader(file));

			//ilk sat�r header oldugu i�in atland�.
			br.readLine();
			String strLine = "";
			int i = 0;
			while((strLine = br.readLine()) != null){
				String[] list = strLine.split(";");

				oMap.put(tableName, i, "YAS", list[0].trim());
				oMap.put(tableName, i, "SIGORTA_PRIMI", list[1].replaceAll("\\.", "").replaceAll("TL", "").replaceAll(",", ".").trim());
				oMap.put(tableName, i, "VADE", list[2].trim());
				oMap.put(tableName, i, "ODEME_ARALIGI", list[3].trim());
				oMap.put(tableName, i, "CINSIYET", list[4].trim());
				if (list.length > 5) {
					oMap.put(tableName, i, "ERTELEME", list[5].trim());
				}
				else {
					oMap.put(tableName, i, "ERTELEME", "");
				}
				
				i++;
			}

			return oMap;
			}	  catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3221_SAVE")
	public static Map<?, ?> save(GMMap iMap){

		try{
			Session session = DAOSession.getSession("BNSPRDal"); 
            String tableName = "SIGORTA_DATALARI";
			List<?> guiList = (List<?>)iMap.get(tableName);
			if(guiList.size()==0){
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("URUN_NO")==null || iMap.getString("URUN_NO").length()==0){
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "URUN_NO");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("DOSYA_ADI")==null || iMap.getString("DOSYA_ADI").length()==0){
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "DOSYA_ADI");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			String erteleme;
			for (int i = 0; i < guiList.size(); i++) {
				
				ClksBasvuruSigortaPrimTx clksBasvuruSigortaPrimTx = new ClksBasvuruSigortaPrimTx();
				ClksBasvuruSigortaPrimTxId id=new ClksBasvuruSigortaPrimTxId();
				
			    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			    id.setYas(iMap.getBigDecimal(tableName, i,"YAS"));
				id.setSigortaYil(iMap.getBigDecimal(tableName, i, "VADE").divide(BigDecimal.valueOf(12), 0, RoundingMode.CEILING));
			    id.setSigortaAy(iMap.getBigDecimal(tableName, i, "VADE"));
			    id.setOdemeAraligi(iMap.getString(tableName, i,"ODEME_ARALIGI"));
			    id.setCinsiyet(iMap.getString(tableName, i,"CINSIYET"));
			    id.setUrunNo(iMap.getBigDecimal("URUN_NO"));
			    erteleme = iMap.getString(tableName, i, "ERTELEME");
			    
			    if("".equals(erteleme) || "0".equals(erteleme)){
			    	id.setErteleme("0");
			    }else if("1".equals(erteleme) || "E1".equals(erteleme)){
			    	id.setErteleme("1");
			    }else if("2".equals(erteleme)|| "E2".equals(erteleme)){
			    	id.setErteleme("2");
			    } else if ("3".equals(erteleme)|| "E3".equals(erteleme)) {
			    	id.setErteleme("3");
			    }
			    else{
			    	id.setErteleme("0");
			    }
			    
			    clksBasvuruSigortaPrimTx.setId(id);
			    clksBasvuruSigortaPrimTx.setSigortaPrim(iMap.getBigDecimal(tableName, i,"SIGORTA_PRIMI"));
			    clksBasvuruSigortaPrimTx.setDosyaAdi(iMap.getString("DOSYA_ADI"));
				session.save(clksBasvuruSigortaPrimTx);
				
			}
			session.flush();  
			iMap.put("TRX_NAME", "3221");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3221_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = (List<?>)session.createCriteria(ClksBasvuruSigortaPrimTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	
		String tableName = "SIGORTA_DATALARI";
		int row = 0;
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			ClksBasvuruSigortaPrimTx clksBasvuruSigortaPrimTx = (ClksBasvuruSigortaPrimTx) iterator.next();
			oMap.put(tableName, row, "YAS", clksBasvuruSigortaPrimTx.getId().getYas());
			oMap.put(tableName, row, "SIGORTA_PRIMI", clksBasvuruSigortaPrimTx.getSigortaPrim());
			oMap.put(tableName, row, "SIGORTA_YIL",clksBasvuruSigortaPrimTx.getId().getSigortaYil());
			oMap.put(tableName, row, "VADE",clksBasvuruSigortaPrimTx.getId().getSigortaAy());
			oMap.put(tableName, row, "ODEME_ARALIGI", clksBasvuruSigortaPrimTx.getId().getOdemeAraligi());
			oMap.put(tableName, row, "CINSIYET", clksBasvuruSigortaPrimTx.getId().getCinsiyet());
			oMap.put(tableName, row, "ERTELEME",clksBasvuruSigortaPrimTx.getId().getErteleme());
			oMap.put("URUN_NO", clksBasvuruSigortaPrimTx.getId().getUrunNo());
			oMap.put("DOSYA_ADI", clksBasvuruSigortaPrimTx.getDosyaAdi());
			row++;
		}
        	return oMap;
        	
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	
}
