 package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirTesvikCalisanistisnaTx;
import tr.com.aktifbank.bnspr.dao.BirTesvikCalisanistisnaTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class ConsumerLoanTRN3249Services {

    @GraymoundService("BNSPR_TRN3249_GET_RECORDS")
        public static GMMap getTransactionNo(GMMap iMap) {
            
            GMMap oMap = new GMMap();
            Connection conn = null;
            CallableStatement stmt = null;
            ResultSet rSet = null;
            String tableName = "TBL_TESVIK_CALISAN_ISTISNA";
         
            try{
                conn = DALUtil.getGMConnection();
                stmt = conn.prepareCall("{? = call PKG_TRN3249.get_records(?,?)}");
                stmt.registerOutParameter(1 , -10); // ref cursor
                stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
                stmt.setBigDecimal(3, iMap.getBigDecimal("SATICI_CALISAN_KOD"));
                stmt.execute();
                rSet = (ResultSet) stmt.getObject(1);
                int row = 0;
                while (rSet.next()) {
                    oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
                    oMap.put(tableName , row , "SATICI_KOD" , rSet.getBigDecimal("SATICI_KOD"));
                    oMap.put(tableName, row, "SATICI_ADI",rSet.getString("SATICI_ADI"));
                    oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
                    oMap.put(tableName, row, "SATICI_CALISAN_KOD", rSet.getBigDecimal("SATICI_CALISAN_KOD"));
                    oMap.put(tableName, row, "CALISAN_ADI", rSet.getString("CALISAN_ADI"));
                    oMap.put(tableName , row , "CALISAN_ISTISNA_MI" , GuimlUtil.convertToCheckBoxSelected(rSet.getString("CALISAN_ISTISNA_MI")));
                    row++;
                   }
              
                return oMap;
                
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } finally{            	
            	GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
            
        }
        
        @GraymoundService("BNSPR_TRN3249_SAVE")
        public static Map<?, ?> save(GMMap iMap) {
            try{
                Session session = DAOSession.getSession("BNSPRDal");
                String tableName = "TBL_TESVIK_CALISAN_ISTISNA";
                
                List<?> recordList = (List<?>) iMap.get(tableName);
                
                for (int row = 0; row < recordList.size(); row++){
                    
                    BirTesvikCalisanistisnaTxId id = new BirTesvikCalisanistisnaTxId();
                    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    id.setSaticiIstisnaKod(iMap.getBigDecimal(tableName, row, "SATICI_KOD"));
                    id.setMusteriNo(iMap.getBigDecimal(tableName , row , "MUSTERI_NO"));
                    id.setSaticiCalisanKod(iMap.getBigDecimal(tableName, row, "SATICI_CALISAN_KOD"));
                    
                    
                    BirTesvikCalisanistisnaTx birTesvikCalisanistisnaTx = (BirTesvikCalisanistisnaTx) session.get(BirTesvikCalisanistisnaTx.class , id);
                    if (birTesvikCalisanistisnaTx == null){
                        birTesvikCalisanistisnaTx = new BirTesvikCalisanistisnaTx();
                    }
                    birTesvikCalisanistisnaTx.setId(id);
                   
               
                    birTesvikCalisanistisnaTx.setCalisanIstisnaMi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName , row , "CALISAN_ISTISNA_MI")));
                    
                    session.saveOrUpdate(birTesvikCalisanistisnaTx);
                }
                session.flush();
                iMap.put("TRX_NAME" , "3249");
                return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
        }
        
        @GraymoundService("BNSPR_TRN3249_GET_INFO")
        public static GMMap getInfo(GMMap iMap) {
            GMMap oMap = new GMMap();
            
            try{
      
                String tableName = "TBL_TESVIK_CALISAN_ISTISNA";
                Session session = DAOSession.getSession("BNSPRDal");
                Criteria criteria = session.createCriteria(BirTesvikCalisanistisnaTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")));
                
                List<?> recordList = (List<?>) criteria.list();
                
                for (int row = 0; row < recordList.size(); row++){
                    BirTesvikCalisanistisnaTx birTesvikCalisanistisnaTx = (BirTesvikCalisanistisnaTx) recordList.get(row);
                    oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
                    oMap.put(tableName , row , "SATICI_KOD" , birTesvikCalisanistisnaTx.getId().getSaticiIstisnaKod());
                    oMap.put(tableName , row , "MUSTERI_NO" , birTesvikCalisanistisnaTx.getId().getMusteriNo());
                    oMap.put(tableName , row , "SATICI_CALISAN_KOD" , birTesvikCalisanistisnaTx.getId().getSaticiCalisanKod());
                    oMap.put(tableName, row, "SATICI_ADI", DALUtil.getResult("select satici_adi from bir_satici where kod = "+birTesvikCalisanistisnaTx.getId().getSaticiIstisnaKod()+""));
                    oMap.put(tableName, row, "CALISAN_ADI", DALUtil.getResult("select bc.adi||' '||bc.soyadi from  bir_satici_calisan bc ,bir_tesvik_calisan_istisna bt where bc.satici_kod = "+birTesvikCalisanistisnaTx.getId().getSaticiIstisnaKod()+" and bc.musteri_no = "+birTesvikCalisanistisnaTx.getId().getMusteriNo()+""));
                    oMap.put(tableName , row , "CALISAN_ISTISNA_MI" , GuimlUtil.convertToCheckBoxSelected(birTesvikCalisanistisnaTx.getCalisanIstisnaMi()));
 

                }
                
                return oMap;
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
        }
    }


