package tr.com.calikbank.bnspr.consumerloan.document.type;

import java.util.HashMap;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public abstract class WebCreditDocument {

	private int code;
	private String folderName;
	private String templateName;
	private String docName;
	
	private byte[] pdfByteArray;
	
	public WebCreditDocument(String folderName, String templateName, int code) {
		setFolderName(folderName);
		setTemplateName(templateName);
		setCode(code);
	}
	
	public abstract String generateXml(String applicationNo, HashMap<String, Object> parameters);
	
	public void generatePdf(String applicationNo, HashMap<String, Object> parameters) {
		
		try {
			GMMap iMap = new GMMap();
			iMap.put("XML", generateXml(applicationNo,parameters));
			iMap.put("FOLDER_NAME", getFolderName());
			iMap.put("TEMPLATE_NAME", getTemplateName());
			setPdfByteArray((byte[])GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_PDF_BYTE", iMap).get("PDF_BYTE_DATA"));
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static String generateAllXml(String applicationNo) {
		GMMap iMap=new GMMap();
		iMap.put("BASVURU_NO", applicationNo);

		StringBuilder builder = new StringBuilder();
		builder.append("<AGREEMENT_INFO>");
		builder.append(GMServiceExecuter.call("BNSPR_BASVURU_MUSTERI_BILGI_XML", iMap).getString("XML"));
		builder.append(GMServiceExecuter.call("BNSPR_BASVURU_SOZLESME_BILGI_XML", iMap).getString("XML"));
		builder.append(GMServiceExecuter.call("BNSPR_BASVURU_ODEME_PLANI_XML", iMap).getString("XML"));
		builder.append(GMServiceExecuter.call("BNSPR_BASVURU_ODEME_TOPLAMLARI_XML", iMap).getString("XML"));
		builder.append("</AGREEMENT_INFO>");

		return builder.toString();
		
	}
	
	public String getDysPdfFileName(){
		StringBuilder sb=new StringBuilder();
		sb.append(getCode());
		sb.append(".pdf");
		return sb.toString();
	}
	
	public String getMailPdfFileName(){
		StringBuilder sb=new StringBuilder();
		sb.append(getDocName());
		sb.append(".pdf");
		return sb.toString();
	}
	
	public String getFolderName() {
		return folderName;
	}
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public byte[] getPdfByteArray() {
		return pdfByteArray;
	}
	public void setPdfByteArray(byte[] pdfByteArray) {
		this.pdfByteArray = pdfByteArray;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	
}
