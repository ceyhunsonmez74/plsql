package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSaticiUrunTx;
import tr.com.calikbank.bnspr.dao.BirSaticiUrunTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3105Services {

	@GraymoundService("BNSPR_TRN3105_GET_LIST")
	public static GMMap getDagiticiListTRN3105(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		int row = 0;

		try {
			GMMap oMap = new GMMap();

			int i = 1;	

				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_trn3105.Get_Firma_List(?,?,?,?,?,?,?)}");
				
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TIPI"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ALT_KREDI_TIPI"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_KODU"));
				stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
				stmt.registerOutParameter(i++, -10); //ref cursor
				stmt.registerOutParameter(i++, -10); //ref cursor

				stmt.execute();
				rSet = (ResultSet)stmt.getObject(6);
				String tableName = "FIRMA_LIST";
              
			   while (rSet.next()) {
				int j = 1;

				oMap.put(tableName, row, "FIRMA_SEC", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "FIRMA_KODU", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "FIRMA_ADI", rSet.getString(j++));

				row++;
			}
            
			oMap.put("FIRMA_LIST_RC", row);
			
            rSet2 = (ResultSet)stmt.getObject(7);          
			tableName = "BAYI_LIST";
			row = 0;
			while (rSet2.next()) {
				int y = 1;

				oMap.put(tableName, row, "BAYI_SEC", rSet2.getBigDecimal(y++));
				oMap.put(tableName, row, "BAYI_KODU", rSet2.getBigDecimal(y++));
				oMap.put(tableName, row, "BAYI_ADI", rSet2.getString(y++));
				oMap.put(tableName, row, "MERKEZ_SUBE", rSet2.getString(y++));
				oMap.put(tableName, row, "F_K", rSet2.getString(y++));
				oMap.put(tableName, row, "MERKEZ_BAYI_KOD", rSet2.getString(y++));
				oMap.put(tableName, row, "MERKEZ_BAYI_ADI", rSet2.getString(y++));

				row++;
			}
			oMap.put("BAYI_LIST_RC", row);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3105_SAVE")
	public static Map<?, ?> saveTRN3105(GMMap iMap) {

		try {

			Session session = DAOSession.getSession("BNSPRDal");

			List<?> listBirSaticiUrunTx = (List<?>) session.createCriteria(BirSaticiUrunTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = listBirSaticiUrunTx.iterator(); iterator.hasNext();) {
				BirSaticiUrunTx birSaticiUrunTx = (BirSaticiUrunTx) iterator.next();
				session.delete(birSaticiUrunTx);
			}
			session.flush();

			String tableName = "FIRMA_LIST";
			ArrayList<?> firmaList = (ArrayList<?>) iMap.get(tableName);
			for (int i = 0; i < firmaList.size(); i++) {
				BirSaticiUrunTx birSaticiUrunTx = new BirSaticiUrunTx();
				BirSaticiUrunTxId id = new BirSaticiUrunTxId();

				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				iMap.put("TABLE_NAME", "BIR_SATICI_URUN");
				if (iMap.getBigDecimal(tableName, i, "KOD") == null) {
					iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap));
					id.setKod(iMap.getBigDecimal("ID"));
				} else
					id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));

				birSaticiUrunTx.setId(id);

				birSaticiUrunTx.setKrdTurKod(iMap.getBigDecimal("KREDI_TURU"));
				birSaticiUrunTx.setKrdTurAltKod(iMap.getBigDecimal("KREDI_TIPI"));
				birSaticiUrunTx.setKrdTurAltKod2(iMap.getBigDecimal("ALT_KREDI_TIPI"));
				birSaticiUrunTx.setKanalKod(iMap.getString("KANAL_KODU"));
				birSaticiUrunTx.setDovizCins(iMap.getString("DOVIZ_KODU"));
				birSaticiUrunTx.setSaticiKod(iMap.getBigDecimal(tableName, i,"FIRMA_KODU"));
				birSaticiUrunTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "FIRMA_SEC")));

				session.saveOrUpdate(birSaticiUrunTx);
			}
			session.flush();

			tableName = "BAYI_LIST";
			ArrayList<?> bayiList = (ArrayList<?>) iMap.get(tableName);
			for (int i = 0; i < bayiList.size(); i++) {

				BirSaticiUrunTx birSaticiUrunTx = new BirSaticiUrunTx();
				BirSaticiUrunTxId id = new BirSaticiUrunTxId();

				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				iMap.put("TABLE_NAME", "BIR_SATICI_URUN");
				if (iMap.getBigDecimal(tableName, i, "KOD") == null) {
					iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap));
					id.setKod(iMap.getBigDecimal("ID"));
				} else
					id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));

				birSaticiUrunTx.setId(id);

				birSaticiUrunTx.setKrdTurKod(iMap.getBigDecimal("KREDI_TURU"));
				birSaticiUrunTx.setKrdTurAltKod(iMap.getBigDecimal("KREDI_TIPI"));
				birSaticiUrunTx.setKrdTurAltKod2(iMap.getBigDecimal("ALT_KREDI_TIPI"));
				birSaticiUrunTx.setKanalKod(iMap.getString("KANAL_KODU"));
				birSaticiUrunTx.setDovizCins(iMap.getString("DOVIZ_KODU"));
				birSaticiUrunTx.setSaticiKod(iMap.getBigDecimal(tableName, i, "BAYI_KODU"));
				birSaticiUrunTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "BAYI_SEC")));

				session.saveOrUpdate(birSaticiUrunTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3105");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3105_GET_INFO")
	public static GMMap getInfoTRN3105KrediTurleri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		String tableName = null;
		int row = 0;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			
			int i = 1;	

				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_trn3105.Get_Info_Bayi_List(?,?,?)}");
				
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
				stmt.registerOutParameter(i++, -10); //ref cursor
				stmt.registerOutParameter(i++, -10); //ref cursor

				stmt.execute();
				rSet = (ResultSet)stmt.getObject(2);
				
				tableName = "FIRMA_LIST";
			   while (rSet.next()) {
				int j = 1;

				oMap.put("KREDI_TUR", rSet.getBigDecimal(j++));
				oMap.put("DI_KREDI_TUR", rSet.getString(j++));
				oMap.put("KREDI_TIP", rSet.getBigDecimal(j++));
				oMap.put("DI_KREDI_TIP", rSet.getString(j++));
				oMap.put("ALT_KREDI_TIP", rSet.getBigDecimal(j++));
				oMap.put("DI_ALT_KREDI_TIP", rSet.getString(j++));
				oMap.put("DOVIZ_KODU", rSet.getString(j++));
				oMap.put("DI_DOVIZ_KODU", rSet.getString(j++));
				oMap.put("KANAL_KODU", rSet.getString(j++));
				oMap.put("DI_KANAL_KODU", rSet.getString(j++));
				

				oMap.put(tableName, row, "FIRMA_SEC", GuimlUtil.convertToCheckBoxValue(rSet.getString(j++)));
				oMap.put(tableName, row, "KOD", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "FIRMA_KODU", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "FIRMA_ADI", rSet.getString(j++));

				row++;
			}
			   oMap.put("FIRMA_LIST_RC", row);
			   rSet2 = (ResultSet)stmt.getObject(3);
				
	           row = 0; 
	           tableName = "BAYI_LIST";
			   while (rSet2.next()) {
				int j = 1;

				
				

				oMap.put(tableName, row, "KOD", rSet2.getBigDecimal(j++));
				oMap.put(tableName, row, "BAYI_SEC", GuimlUtil.convertToCheckBoxValue(rSet2.getString(j++)));
				oMap.put(tableName, row, "BAYI_KODU", rSet2.getBigDecimal(j++));
				oMap.put(tableName, row, "BAYI_ADI", rSet2.getString(j++));
				oMap.put(tableName, row, "MERKEZ_SUBE", rSet2.getString(j++));
				oMap.put(tableName, row, "F_K", rSet2.getString(j++));
				oMap.put(tableName, row, "MERKEZ_BAYI_KOD", rSet2.getString(j++));
				oMap.put(tableName, row, "MERKEZ_BAYI_ADI", rSet2.getString(j++));

				row++;
			}
			   oMap.put("BAYI_LIST_RC", row);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3105_FILL_BAYI_LIST")
	public static GMMap fillBayiList(GMMap iMap) {
		try {
			ArrayList<BigDecimal> list = new ArrayList<BigDecimal>();
			Boolean flag = false;

			List<?> firmaList = (List<?>) iMap.get("FIRMA_LIST");
			String tblNameFirma = "FIRMA_LIST";

			List<?> bayiList = (List<?>) iMap.get("BAYI_LIST");
			String tblNameBayi = "BAYI_LIST";

			GMMap oMap = new GMMap();
			int row = 0;
			String tableName = "RESULTS";
			for (int i = 0; i < bayiList.size(); i++) {
				
				flag = false;
				list.clear();
				list = strTokenizer(iMap.getString(tblNameBayi, i, "F_K"));

				for (int j = 0; j < list.size(); j++) {
					for (int k = 0; k < firmaList.size(); k++) {
						if (iMap.getBigDecimal(tblNameFirma, k, "FIRMA_KODU").compareTo(list.get(j)) == 0)
							if (iMap.getString(tblNameFirma, k, "FIRMA_SEC").equals("1"))
								flag = true;
					}
				}
				
				if (flag){
					oMap.put(tableName, row, "KOD", iMap.getBigDecimal(tblNameBayi,i,"KOD"));
					oMap.put(tableName, row, "BAYI_SEC", iMap.getString(tblNameBayi,i,"BAYI_SEC"));
					oMap.put(tableName, row, "BAYI_KODU", iMap.getBigDecimal(tblNameBayi,i,"BAYI_KODU"));
					oMap.put(tableName, row, "BAYI_ADI",iMap.getString(tblNameBayi,i,"BAYI_ADI"));
					oMap.put(tableName, row, "MERKEZ_SUBE", iMap.getString(tblNameBayi,i,"MERKEZ_SUBE"));
					oMap.put(tableName, row, "F_K", iMap.getString(tblNameBayi,i,"F_K"));
					oMap.put(tableName, row, "MERKEZ_BAYI_KOD", iMap.getString(tblNameBayi,i,"MERKEZ_BAYI_KOD"));
					oMap.put(tableName, row, "MERKEZ_BAYI_ADI", iMap.getString(tblNameBayi,i,"MERKEZ_BAYI_ADI"));
					
					row++;
				}		
			}
			
			oMap.put("R_C", row);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3105_CHECKING_BAYI_LIST")
	public static GMMap checkingBayiList(GMMap iMap){
		
		try{
			
			List<?> varList = (List<?>) iMap.get("VAR_BAYI_LIST");
			String tblVarList = "VAR_BAYI_LIST";
			
			List<?> bayiList = (List<?>) iMap.get("BAYI_LIST");
			String tblNameBayi = "BAYI_LIST";

			for (int i = 0; i < bayiList.size(); i++) {
				for (int j = 0; j < varList.size(); j++) {
					if (iMap.getBigDecimal(tblVarList,j,"BAYI_KODU").compareTo(iMap.getBigDecimal(tblNameBayi,i,"BAYI_KODU"))==0){
						iMap.put(tblVarList,j,"BAYI_SEC",iMap.getString(tblNameBayi,i,"BAYI_SEC"));
					}
				}
			}
			
			GMMap oMap = new GMMap();
			oMap.put("RESULTS",iMap.get("VAR_BAYI_LIST"));
			return oMap;
		} catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}

	public static ArrayList<BigDecimal> strTokenizer(String str) {
		try {
			ArrayList<BigDecimal> list = new ArrayList<BigDecimal>();
			StringTokenizer tok = new StringTokenizer(str, ",");
			while (tok.hasMoreTokens()) {
				String token = tok.nextToken();
				BigDecimal bd = new BigDecimal(Integer.parseInt(token));
				list.add(bd);
			}
			return list;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3105_GET_DI_KANAL_KODU")
	public static GMMap getDiKanalKodu(GMMap iMap){
		GMMap oMap = new GMMap();
		oMap.put("DI_KANAL_KOD", LovHelper.diLov("2","2","3105/LOV_KANAL_KOD", "ACIKLAMA"));
		return oMap;
	}

}
