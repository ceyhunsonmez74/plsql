package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3158Services {
	
	@GraymoundService("BNSPR_QRY3158_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(DALUtil.fillComboBox(iMap, "IL_LIST", true, "SELECT A.KOD, A.IL_ADI FROM GNL_IL_KOD_PR A ORDER BY A.KOD"));
			oMap.putAll(DALUtil.fillComboBox(iMap, "KOMUR_CINS_LIST", true, "SELECT V.KOD, V.DEGER_C DEGER FROM URN_ATTRIB_LIST_VALUE V WHERE V.ATTRIBNO='2'"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY3158_GET_LIST")
	public static GMMap getList(GMMap iMap){
		GMMap 				oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PTT_URUN.F_GET_PRODUCT_INFO(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("TCKN"));
			stmt.setString(i++, iMap.getString("AD"));
			stmt.setString(i++, iMap.getString("IKINCI_AD"));
			stmt.setString(i++, iMap.getString("SOYAD"));
			stmt.setString(i++, iMap.getString("DURUM"));
			stmt.setDate(i++, iMap.getDate("KULLANDIRIM_BAS_TAR") != null ? new java.sql.Date(iMap.getDate("KULLANDIRIM_BAS_TAR").getTime()) : null );
			stmt.setDate(i++, iMap.getDate("KULLANDIRIM_BIT_TAR") != null ? new java.sql.Date(iMap.getDate("KULLANDIRIM_BIT_TAR").getTime()) : null );
			stmt.setDate(i++, iMap.getDate("TESLIMAT_BAS_TAR") != null ? new java.sql.Date(iMap.getDate("TESLIMAT_BAS_TAR").getTime()) : null );
			stmt.setDate(i++, iMap.getDate("TESLIMAT_BIT_TAR") != null ? new java.sql.Date(iMap.getDate("TESLIMAT_BIT_TAR").getTime()) : null );
			stmt.setString(i++, iMap.getString("KOMUR_CINSI"));
			stmt.setString(i++, iMap.getString("SATILDIGI_IL"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TONAJ"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "KREDILI_URUN_LIST"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
