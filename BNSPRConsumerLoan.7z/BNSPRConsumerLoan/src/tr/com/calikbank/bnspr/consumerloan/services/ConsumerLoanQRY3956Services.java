package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.File;
import java.math.BigDecimal;
import java.util.HashMap;

import oracle.net.aso.n;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import tr.com.aktifbank.bnspr.dao.GnlMusteriBelgeGonderimTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.sun.org.apache.bcel.internal.generic.NEW;

public class ConsumerLoanQRY3956Services {
	@GraymoundService("BNSPR_QRY3956_GET_COMBO_PARAMETERS")
	public static GMMap comboParameters(GMMap iMap) {

		GMMap oMap = new GMMap();
		String listName = "BELGE_LIST";

		try {
			Object[] inputValues = new Object[2];
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("EKRAN_KOD");
			String func = "{ ? = call pkg_rc3956.belge_turu_listesi(?) }";
			GMMap resultMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, listName, inputValues);

			// ADD_EMPTY_KEY
			GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
			for (int i = 0; i < resultMap.getSize(listName); i++) {
				GuimlUtil.wrapMyCombo(oMap, listName, resultMap.getString(listName, i, "KEY1"), resultMap.getString(listName, i, "TEXT"));
			}

			/** TY-6558 TY-Adres Evrak G�nderim Talepleri */
			listName = "GONDERIM_TIPI";
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "E-Posta");
			GuimlUtil.wrapMyCombo(oMap, listName, "P", "Posta");
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3956_BELGE_PARAMETRE_TURU")
	public static GMMap belgeParametreTuru(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			String func = "{? = call pkg_rc3956.belge_parametre_turu(?)}";
			Object[] inputValues = { BnsprType.STRING, iMap.getString("BELGE_TURU") };
			oMap.put("BELGE_PARAMETRE_TURU", (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3956_MUSTERI_BILGI")
	public static GMMap musteriBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Object[] inputValues = new Object[4];
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("MUSTERI_NO");

			String func = "{ ? = call pkg_rc3956.eposta_bilgi(?,?) }";
			oMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, "EPOSTA_TABLO", inputValues);

			String proc = "{ call pkg_rc3956.musteri_bilgi(?,?,?,?,?,?) }";

			Object[] outputValues = new Object[8];
			int n = 0;
			outputValues[n++] = BnsprType.NUMBER;
			outputValues[n++] = "MUSTERI_NO";
			outputValues[n++] = BnsprType.STRING;
			outputValues[n++] = "TC_KIMLIK_NO";
			outputValues[n++] = BnsprType.STRING;
			outputValues[n++] = "AD";
			outputValues[n++] = BnsprType.STRING;
			outputValues[n++] = "SOYAD";

			oMap.putAll((GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3956_BELGE_BILGI")
	public static GMMap belgeBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Object[] inputValues = new Object[6];
			inputValues[0] = BnsprType.STRING;
			inputValues[1] = iMap.getString("BELGE_TURU");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[4] = BnsprType.NUMBER;
			inputValues[5] = iMap.getBigDecimal("MUSTERI_NO");

			String proc = "{ call pkg_rc3956.belge_bilgi(?,?,?,?,?,?,?,?,?) }";

			Object[] outputValues = new Object[12];
			outputValues[0] = BnsprType.NUMBER;
			outputValues[1] = "KREDI_TUR";
			outputValues[2] = BnsprType.NUMBER;
			outputValues[3] = "KEFIL_SAYISI";
			outputValues[4] = BnsprType.STRING;
			outputValues[5] = "KMH_VAR_MI";
			outputValues[6] = BnsprType.STRING;
			outputValues[7] = "RISK_VAR_MI";
			outputValues[8] = BnsprType.STRING;
			outputValues[9] = "GECICI_HESAP_ALACAK_VAR_MI";			
			outputValues[10] = BnsprType.STRING;
			outputValues[11] = "SOZLESME_BASILDI_MI";

			oMap.putAll((GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3956_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();

		try {
			iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			// E-Posta
			if (iMap.getString("GONDERIM_TIPI") != null && "E".equals(iMap.getString("GONDERIM_TIPI"))) {
					
				if (iMap.getBigDecimal("MUSTERI_NO") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Musteri No");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				else if (iMap.getString("EPOSTA") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Eposta");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				if ("E".equals(birBasvuru.getFaizsizFinansman()) && ("KREDI_KAPAMA_YAZISI".equals(iMap.getString("BELGE_TURU")) || "SOBF".equals(iMap.getString("BELGE_TURU")))){
					iMap.put("BELGE_TURU", iMap.getString("BELGE_TURU").concat("_FZ"));
				}
				//
				Object[] inputValues = new Object[4];
				inputValues[0] = BnsprType.STRING;
				inputValues[1] = iMap.getString("EPOSTA");
				Object[] outputValues = new Object[0];
				String proc = "{ call pkg_trn10011.e_mail_check(?) }";
				DALUtil.callOracleProcedure(proc, inputValues, outputValues);
	
				Object[] inputValues2 = new Object[4];
				inputValues2[0] = BnsprType.STRING;
				inputValues2[1] = "KREDI_SOZLESME_MAIL";
				inputValues2[2] = BnsprType.STRING;
				inputValues2[3] = iMap.getString("BELGE_TURU");
				Object[] outputValues2 = new Object[12];
				int n = 0;
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "FROM";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "CC";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "BCC";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "SUBJECT";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "BODY";
				outputValues2[n++] = BnsprType.STRING;
				outputValues2[n++] = "FILENAME_PREFIX";
	
				String proc2 = "{ call pkg_rc3956.mail_gonderen_bilgi(?,?,?,?,?,?,?,?) }";			
				iMap.putAll((GMMap) DALUtil.callOracleProcedure(proc2, inputValues2, outputValues2));
	
				if ("KREDI_SOZLESME".equals(iMap.getString("BELGE_TURU")))
					oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3956_KREDI_SOZLESME_GONDER", iMap));
				else if ("KREDI_KAPAMA_YAZISI".equals(iMap.getString("BELGE_TURU")) || "KREDI_KAPAMA_YAZISI_FZ".equals(iMap.getString("BELGE_TURU")))
					oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3956_KREDI_KAPAMA_YAZISI_GONDER", iMap));
				else if("SOBF".equals(iMap.getString("BELGE_TURU")) || "SOBF_FZ".equals(iMap.getString("BELGE_TURU"))){
					oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3956_SOBF_GONDER", iMap));				
				}
	
				GMMap servisMap = new GMMap();
				servisMap.put("FROM", iMap.getString("FROM"));
				servisMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(iMap.getString("EPOSTA")));
				if(StringUtils.isNotBlank(iMap.getString("CC")))
						servisMap.put("RECIPIENTS_CC", GuimlUtil.createFromCommaSeparatedList(iMap.getString("CC")));
				if(StringUtils.isNotBlank(iMap.getString("BCC")))						
						servisMap.put("RECIPIENTS_BCC", GuimlUtil.createFromCommaSeparatedList(iMap.getString("BCC")));
				servisMap.put("SUBJECT", iMap.getString("SUBJECT"));
				servisMap.put("MESSAGE_BODY", iMap.getString("BODY"));
				servisMap.put("IS_BODY_HTML", true);
				servisMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
				servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", oMap.getString("FILENAME"));
				servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", FileUtil.readFileToByteArray(new File(oMap.getString("FILENAMEPATH"))));
				GMServiceExecuter.executeAsync("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap);
			}
			// Posta
			else {
				/** TY-6558 TY-Adres Evrak G�nderim Talepleri */
				
				if (iMap.getString("ADRES") == null || iMap.getString("ADRES").length() == 0) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Di�er Adres");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				if ("KREDI_SOZLESME".equals(iMap.getString("BELGE_TURU"))){ // 3188 Ekranindan Geliyor
					tMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3956_KREDI_SOZLESME_GONDER", iMap));
					iMap.put("ISLEM_TURU", "225");
				}	
				else if ("KREDI_KAPAMA_YAZISI".equals(iMap.getString("BELGE_TURU"))){ // 3225 Ekranindan Geliyor								
					tMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3956_KREDI_KAPAMA_YAZISI_GONDER", iMap));
					iMap.put("ISLEM_TURU", "224");
				}	
				
				iMap.put("GONDERILEN_BOLUM", "BROPS"); //Bireysel Kredi Operasyon				
				iMap.put("ISLEM_ADEDI", new BigDecimal(1));
				iMap.put("ISLEM_ONCELIGI", "N"); //Normal
				iMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));														
				iMap.put("UNVAN", LovHelper.diLov(iMap.getBigDecimal("MUSTERI_NO"), "4001/LOV_KONTAKT_MUSTERI", "UNVAN"));				
				iMap.put("KREDI_BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				iMap.put("ACIKLAMA", iMap.getString("ADRES"));
				
				iMap.put("DOSYA_SAYFA", 0, "FILE_NAME", tMap.get("FILENAME"));
				iMap.put("DOSYA_SAYFA", 0, "CONTENT", FileUtil.readFileToByteArray(new File(tMap.getString("FILENAMEPATH"))));
				
				GMServiceExecuter.execute("BNSPR_TRN4001_SAVE", iMap);
				
				
				
			}
			GnlMusteriBelgeGonderimTx gnlMusteriBelgeGonderimTx = new GnlMusteriBelgeGonderimTx();
			gnlMusteriBelgeGonderimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlMusteriBelgeGonderimTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			gnlMusteriBelgeGonderimTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			gnlMusteriBelgeGonderimTx.setBelgeTuru(iMap.getString("BELGE_TURU"));			
			gnlMusteriBelgeGonderimTx.setEposta(iMap.getString("EPOSTA"));						
			gnlMusteriBelgeGonderimTx.setMailId(oMap.getBigDecimal("MAIL_ID"));
			gnlMusteriBelgeGonderimTx.setGonderimTipi(iMap.getString("GONDERIM_TIPI")); /** TY-6558 TY-Adres Evrak G�nderim Talepleri */
			gnlMusteriBelgeGonderimTx.setAdres(iMap.getString("ADRES")); /** TY-6558 TY-Adres Evrak G�nderim Talepleri */
			session.saveOrUpdate(gnlMusteriBelgeGonderimTx);
			session.flush();

			iMap.put("MESSAGE_NO", new BigDecimal(308));
			iMap.put("P1", iMap.getBigDecimal("TRX_NO"));
			oMap.put("MESSAGE", GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).getString("ERROR_MESSAGE"));
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3956_KREDI_SOZLESME_GONDER")
	public static GMMap sendKrediSozlesmeMail(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBigDecimal("BASVURU_NO") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Basvuru No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			String fileName = iMap.getString("FILENAME_PREFIX") + iMap.getString("BASVURU_NO") + "_" + System.currentTimeMillis() + ".pdf";
			String fileNamePath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;

			//HashMap<String, Object> parameters = new HashMap<String, Object>();
			//parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			//JasperPrint jasperPrint = ReportUtil.generateReport("BNSPR_RAP3181_KREDI_SART_GERI_ODEME", parameters);
			JasperPrint jasperPrint = (JasperPrint) GMServiceExecuter.execute("INTERNET_REPORT_CREDIT_CONDITIONS", iMap).get("REPORT");
			JRPdfExporter pdfexporter = new JRPdfExporter();
			pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileNamePath);
			pdfexporter.exportReport();

			oMap.put("FILENAME", fileName);
			oMap.put("FILENAMEPATH", fileNamePath);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3956_KREDI_KAPAMA_YAZISI_GONDER")
	public static GMMap sendKrediKapamaYazisiMail(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBigDecimal("BASVURU_NO") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Basvuru No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			GMServiceExecuter.execute("BNSPR_QRY3225_KREDI_KAPAMA_LOGLA", iMap);

			String fileName = iMap.getString("FILENAME_PREFIX") + iMap.getString("BASVURU_NO") + "_" + System.currentTimeMillis() + ".pdf";
			String fileNamePath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;

			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));			
			parameters.put("ADRES", iMap.getString("ADRES")); /** TY-6558 TY-Adres Evrak G�nderim Talepleri */
			JasperPrint jasperPrint = null;
			if("E".equals(birBasvuru.getFaizsizFinansman())){
				jasperPrint = ReportUtil.generateReport("BNSPR_RAP3225_KREDI_KAPAMA_YAZISI_FZ", parameters);
			}else{
				jasperPrint = ReportUtil.generateReport("BNSPR_RAP3225_KREDI_KAPAMA_YAZISI", parameters);
			}
			
			JRPdfExporter pdfexporter = new JRPdfExporter();
			pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileNamePath);
			pdfexporter.exportReport();

			oMap.put("FILENAME", fileName);
			oMap.put("FILENAMEPATH", fileNamePath);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3956_SOBF_GONDER")
	public static GMMap sendSOBFMail(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBigDecimal("BASVURU_NO") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Basvuru No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			String fileName = iMap.getString("FILENAME_PREFIX") + iMap.getString("BASVURU_NO") + "_" + System.currentTimeMillis() + ".pdf";
			String fileNamePath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;

			oMap.putAll( GMServiceExecuter.execute("INTERNET_REPORT_CREDIT_APPLICATION_SOBF", iMap));
			JasperPrint jasperPrint = (JasperPrint) oMap.get("REPORT");
			JRPdfExporter pdfexporter = new JRPdfExporter();
			pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileNamePath);
			pdfexporter.exportReport();

			oMap.put("FILENAME", fileName);
			oMap.put("FILENAMEPATH", fileNamePath);
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/** TY-6558 TY-Adres Evrak G�nderim Talepleri */
	@GraymoundService("BNSPR_QRY3956_MUSTERI_ADRES")
	public static GMMap musteriAdres(GMMap iMap) {
		GMMap tMap = new GMMap();
		GMMap oMap = new GMMap();

		tMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_ADDRESS_LIST", iMap));
		
		StringBuilder sb = new StringBuilder();
		String listName = "RESULTS", listName2 = "MUSTERI_ADRES";
		int i;
		for (i = 0; i < tMap.getSize(listName); i++) {
			sb.setLength(0);
			sb.append(tMap.getString(listName, i, "ADRES")).append(" ");
			sb.append(tMap.getString(listName, i, "ILCE_ADI")).append(" / ");
			sb.append(tMap.getString(listName, i, "IL_ADI"));			
				
			oMap.put(listName2, i, "ADRES", sb.toString());
			oMap.put(listName2, i, "ADRES_TIPI", tMap.getString(listName, i, "ADRES_TIPI"));
		}
		
		oMap.put(listName2, i, "ADRES", "Di�er");
				
		return oMap;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
