package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.ws.Holder;

import org.apache.commons.httpclient.util.DateUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAdkBasvuru;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKartBilgi;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKartBilgiTx;
import tr.com.aktifbank.bnspr.dao.BirSmsOnonayLog;
import tr.com.aktifbank.bnspr.dao.BirSmsOnonayLogId;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.KartBasvuruTalep;
import tr.com.aktifbank.bnspr.dao.KmhBireyselBasvuru;
import tr.com.aktifbank.integration.InsuranceProcessClient;
import tr.com.calikbank.bnspr.consumerloan.document.type.DocumentCreator;
import tr.com.calikbank.bnspr.consumerloan.document.type.WebCreditDocument;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.consumerloan.utils.Enums;
import tr.com.calikbank.bnspr.consumerloan.utils.Enums.CreditDocTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirBasvuruTx;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.dao.GnlMusteriTelefon;
import tr.com.calikbank.bnspr.dao.KmhFaizOran;
import tr.com.calikbank.bnspr.dao.TemTeminatDetail;
import tr.com.calikbank.bnspr.dao.TemTeminatMain;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

/**
 * Web kredi gelistirilmeleri icin kullanilacak servisleri icerir.<br>
 * 
 * @author murat.el
 * @since PY-11117
 */
public class ConsumerLoanWebServices {
	private final static Logger LOGGER = Logger.getLogger(ConsumerLoanWebServices.class);

	
	/**
	 * Kisinin sahip oldugu kart donusumune uygun; herhangi bir sistemdeki debit kartlari,
	 * intra sistemindeki prepaid kartlari listelenir. Listelenen kartlara gore kisiye verilecek
	 * karta karar verilir. Debiti varsa kart verilmez. Yoksa tff prepaid karti varsa debite cevrilir.
	 * Yoksa Nkolay Debit kart verilir<br>
	 * 
	 * @author murat.el
	 * @since PY-11117
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>TCKN - Kisi tc kimlik numarasi
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>CARD_TYPE - Musteriye verilecek debit kart tipi(P:Prepaid|N:Nkolay|Hicbirsey) <li>APPLICATION_NO - Prepaid kart verilecekse tff prepaid karta ait basvuru no <li>CARD_NO - Prepaid kart verilecekse tff prepaid karta ait kart no
	 */
	@GraymoundService("BNSPR_CL_GET_DEBIT_CARD_INFO")
	public static GMMap getDebitCardInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap queryMap = new GMMap();
		// Outputs
		String cardType = null;
		BigDecimal applicationNo = null;
		BigDecimal kkApplicationNo = null;
		String cardNo = null;
		GMMap pMap = new GMMap();

		try {
			// Parametre kontrol
			String tckn = iMap.getString("TCKN");
			if (StringUtils.isBlank(tckn)) {
				ConsumerLoanCommonServices.raiseGMError("330", "Tc Kimlik No");
			}
			else {
				// TCKN kontrolu
				queryMap.clear();
				queryMap.put("TC_KIMLIK_NO", tckn);
				queryMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", queryMap));
				if ("0".equals(queryMap.getString("SONUC"))) {
					ConsumerLoanCommonServices.raiseGMError("456", tckn);
				}
			}

			// Alinabilecek kartlari listele
			queryMap.clear();
			queryMap.put("TCKN", tckn);
			queryMap.putAll(GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_LIST_CARDS_FOR_EXCHANGE", queryMap));
			// Kontrol
			String tableName = "KART_LIST";
			Date maxKayitTar = null;
			if (queryMap.get(tableName) != null && queryMap.getSize(tableName) > 0) {
				// Listedeki kayitlari kontrol et
				for (int i = 0; i < queryMap.getSize(tableName); i++) {
					// Debiti var mi, varsa hicbir kart verilmez
					if ("D".equals(queryMap.getString(tableName, i, "KART_TIPI"))) {
						if (maxKayitTar == null || maxKayitTar.before(queryMap.getDate(tableName, i, "KAYIT_TARIHI"))) {
							cardType = null;
							applicationNo = queryMap.getBigDecimal(tableName, i, "BASVURU_NO");
							cardNo = queryMap.getString(tableName, i, "KART_NO");
							maxKayitTar = queryMap.getDate(tableName, i, "KAYIT_TARIHI");
						}
					}
				}

				if (cardNo == null) {
					maxKayitTar = null;
					for (int i = 0; i < queryMap.getSize(tableName); i++) {
						/*sanal yenilemesi yap�lm�� kartlar P2D ak���na dahil edilmemelidir. m��terinin cebindeki skt dolmu� kart� ile para �ekmesi m�mk�n olamayaca��ndan bu ak��a dahil edilmeden nkolay banka kart� verilmelidir. */
						if (OceanConstants.Akustik_PrepaidCard.equals(queryMap.getString(tableName, i, "KART_TIPI"))) {
							pMap.clear();
							// pp kartlar i�in urun id bilgisine bak�l�p, intra ocaen ayr�m� yap�ld�.910 Yim PP �ncelikli
							GMMap nKolayMap = new GMMap();
							nKolayMap.put("PRODUCT_ID", ConsumerLoanCommonServices.nvl(queryMap.getString(tableName, i , "URUN_KODU"), queryMap.getString(tableName, i , "PRODUCT_ID")));
							nKolayMap.putAll(GMServiceExecuter.execute("BNSPR_IS_NKOLAY_PP_PRODUCT", nKolayMap));
							if ("Y".equals(nKolayMap.getString("IS_NKOLAY"))) {
								pMap.put("KK_BASVURU_NO", queryMap.getBigDecimal(tableName, i, "BASVURU_NO"));
								cardType = "P";
								kkApplicationNo = queryMap.getBigDecimal(tableName, i, "BASVURU_NO");
								cardNo = queryMap.getString(tableName, i, "KART_NO");
								maxKayitTar = queryMap.getDate(tableName, i, "KAYIT_TARIHI");
								applicationNo = null;
								break;

							}
							else {
								pMap.put("TFF_BASVURU_NO", queryMap.getBigDecimal(tableName, i, "BASVURU_NO"));

								pMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_PREPAID_TO_DEBIT_IS_PRODUCT_EXISTS", pMap));
								if ("E".equals(pMap.getString("IS_EXISTS"))) {
									if (maxKayitTar == null || maxKayitTar.before(queryMap.getDate(tableName, i, "KAYIT_TARIHI"))) {
										cardType = "P";
										applicationNo = queryMap.getBigDecimal(tableName, i, "BASVURU_NO");
										cardNo = queryMap.getString(tableName, i, "KART_NO");
										maxKayitTar = queryMap.getDate(tableName, i, "KAYIT_TARIHI");
									}
								}
							}
						}
					}
				}
			}
			
			if (cardNo == null && cardType == null && applicationNo == null) {
				// Hicbir karti yok ise NKolay Debit Kart verilir
				cardType = "N";
			}

			if (iMap.get("BASVURU_NO") != null) {
				Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
				BirBasvuruKartBilgi kartBilgi = (BirBasvuruKartBilgi) session.createCriteria(BirBasvuruKartBilgi.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				BirBasvuruKartBilgiTx kartTx = new BirBasvuruKartBilgiTx();
				if (kartBilgi == null) {
					kartBilgi = new BirBasvuruKartBilgi();
					kartBilgi.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				}
				if (!"NN".equals(kartBilgi.getKartTipi())) {
					kartBilgi.setKartTipi(cardType);
					kartBilgi.setTffBasvuruNo(applicationNo);
					kartBilgi.setKartNo(cardNo);
					kartBilgi.setKkBasvuruNo(kkApplicationNo);
					session.saveOrUpdate(kartBilgi);
					session.flush();
					kartTx.setTxNo(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
					kartTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					kartTx.setKartTipi(cardType);
					kartTx.setTffBasvuruNo(applicationNo);
					kartTx.setKartNo(cardNo);
					kartTx.setKkBasvuruNo(kkApplicationNo);
					session.saveOrUpdate(kartTx);
					session.flush();
				}
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("CARD_TYPE", cardType);
		oMap.put("APPLICATION_NO", applicationNo);
		oMap.put("KK_APPLICATION_NO", kkApplicationNo);
		oMap.put("CARD_NO", cardNo);
		return oMap;
	}

	/**
	 * Verilen bilgilerle krediye debit kart verilmesi icin gerekli data
	 * kredi basvurusu uzerinden toplanir. Toplanan data ile debit kart talebi olusturulur.<br>
	 * 
	 * @author murat.el
	 * @since PY-11117
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>PROCESS_TYPE - Islem tipi (P:PrepaidToDebit|N:NKolay Debit) <li>CL_APPLICATION_NO - Bir.Kredi basvuru numarasi <li>TFF_APPLICATION_NO - PrepaidToDebit islemi ise prepaid karta ait basvuru numarasi <li>CARD_NO - PrepaidToDebit islemi ise prepaid karta ait kart numarasi
	 * @return oMap - Output yok<br>
	 */
	@GraymoundService("BNSPR_CL_CREATE_DEBIT_CARD_REQUEST")
	public static GMMap createDebitCardRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap queryMap = new GMMap();
		String serviceName = "BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST";

		try {
			// Data topla
			GMMap applicationMap = new GMMap();
			queryMap.clear();
			queryMap.put("APPLICATION_NO", iMap.get("CL_APPLICATION_NO"));
			applicationMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_APPLICATION_INFO_FOR_DEBIT_CARD", queryMap));

			queryMap.clear();
			queryMap.put("KANAL", iMap.getString("KANAL", "WEBKREDI"));
			queryMap.put("REFERANS_NO", iMap.getString("CL_APPLICATION_NO"));
			queryMap.put("TFF_BASVURU_NO", iMap.getString("TFF_APPLICATION_NO"));
			queryMap.put("KK_BASVURU_NO", iMap.getString("KK_APPLICATION_NO"));
			queryMap.put("KART_NO", iMap.getString("CARD_NO"));
			queryMap.putAll(applicationMap);
			queryMap.put("DURUM_KOD", iMap.get("DURUM_KOD"));
			if ("TRUE".equals(iMap.getString("ONAY_FLAG"))) {
				queryMap.put("KREDI_TESLIMAT_ONAY", "Y");
			}
			else {
				queryMap.put("KREDI_TESLIMAT_ONAY", "N");
			}

			// Talebi olustur
			String processType = iMap.getString("PROCESS_TYPE");
			if ("P".equals(processType)) {
				processType = "P2D";// Prepaid to Debit
				serviceName = "BNSPR_PREPAID_TO_DEBIT_FROM_CHANNEL";

				if (queryMap.getString("EV_TEL_NO") != null)
					queryMap.put("EV_ULKE_KOD", "90");
				if (queryMap.getString("CEP_TEL_NO") != null)
					queryMap.put("CEP_ULKE_KOD", "90");
				if (queryMap.getString("IS_TEL_NO") != null)
					queryMap.put("IS_ULKE_KOD", "90");
			}
			else if ("N".equals(processType)) {
				processType = "NKD";// NKolay Debit
			}
			else {
				ConsumerLoanCommonServices.raiseGMError("330", "Islem Tipi");
			}
			queryMap.put("ISLEM_TIPI", processType);

			GMServiceExecuter.execute(serviceName, queryMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Verilen kredi basvurusuna ait debit kart olusturmak icin gerekli bilgileri toplar<br>
	 * 
	 * @author murat.el
	 * @since PY-11117
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>APPLICATION_NO - Bir.Kredi basvuru numarasi
	 * @return oMap - Basvuru bilgileri<br>
	 */
	@GraymoundService("BNSPR_CL_GET_APPLICATION_INFO_FOR_DEBIT_CARD")
	public static GMMap getClApplicationInfoForDebitCard(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_webkredi.get_application_info_for_debit(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("APPLICATION_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_CL_WEBKREDI_VALIDATION_API")
	public static GMMap webkrediValidationApi(GMMap iMap) {
		GMMap oMap = new GMMap();
		iMap.put("API_EH", "E");
		oMap = webkrediValidation(iMap);

		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		List<GnlMusteri> list = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).list();

		if (list != null && list.size() > 0) {
			oMap.put("MUSTERI_NO", list.get(0).getMusteriNo());
		}

		return oMap;
	}

	/**
	 * Web Kredi basvuru akisina almadan once business validasyonlari servisi
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEBKREDI_VALIDATION")
	public static GMMap webkrediValidation(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap kpsMap = new GMMap();
		GMMap sMap = new GMMap();
		GMMap apsMap = new GMMap();
		GMMap pMap = new GMMap();

		try {

			// Mevcut musteri cep tel kontrolu 5204
			// Farkli TCKNye ait cep tel kontrolu 5205
			// Daha onceden red basvuru var mi 5217
			// PTT emekli maas kontrolu 5218
			// PTT kredisi var mi? 5216
			// KPS 18 yas kontrolu 5220
			// KPS Vefat Kontrolu 5219
			// Basarisiz KPS sorgusu 5208
			// Spot kontrolleri 5808,6059

			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_CL_CCKREDI_VALIDATION", iMap));
				if (!"00".equals(oMap.getString("RESPONSE_CODE"))) {
					return oMap;
				}
				else {
					iMap.put("TC_KIMLIK_NO", oMap.get("TC_KIMLIK_NO"));
					iMap.put("CEP_TEL_ALAN_KODU", oMap.get("CEP_TEL_ALAN_KODU"));
					iMap.put("CEP_TEL_NO", oMap.get("CEP_TEL_NO"));
				}
			}
			else {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_webkredi.pre_apply_validation(?, ?, ?, ?, ?, ?)}");
				int pc = 1;
				stmt.setString(pc++, iMap.getString("TC_KIMLIK_NO"));
				stmt.setString(pc++, iMap.getString("CEP_TEL_ALAN_KODU"));
				stmt.setString(pc++, iMap.getString("CEP_TEL_NO"));
				stmt.setBigDecimal(pc++, iMap.getBigDecimal("ODEME_TIP_KOD"));
				stmt.registerOutParameter(pc++, Types.FLOAT);
				stmt.registerOutParameter(pc++, Types.VARCHAR);

				stmt.execute();

				iMap.put("HATA_NO", stmt.getBigDecimal(5));

				if (iMap.get("HATA_NO") != null) {
					oMap.put("RESPONSE_CODE", iMap.get("HATA_NO"));
					oMap.put("RESPONSE_MESSAGE", stmt.getString(6));
					return oMap;
				}
			}

			/** Ptt emeklisi mi? **/
			String pttEmeklisimi = (String) DALUtil.callOneParameterFunction("{? = call  pkg_webkredi.ptt_emekli_kredi_varmi(?)}", Types.VARCHAR, iMap.getString("TC_KIMLIK_NO"));
			if ("E".equals(pttEmeklisimi)) {
				/** Ptt emeklileri icin sms talep yaratilir **/
				pMap.put("MSISDN", "+90".concat(iMap.getString("CEP_TEL_ALAN_KODU").concat(iMap.getString("CEP_TEL_NO"))));
				pMap.put("NATIONAL_IDENTIFICATION_NUMBER", iMap.getString("TC_KIMLIK_NO"));
				pMap.put("CHANNEL", "WEB");
				GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION", pMap);
				
				oMap.put("RESPONSE_CODE", 5218);
				oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5218)).get("ERROR_MESSAGE"));
				return oMap;
			}

			/** KPS Sorgusu ve Kontrolleri **/
			iMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
			iMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));

			kpsMap.put("TCKNO", iMap.getString("TCKN"));
			kpsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", kpsMap));
			// kpsMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", kpsMap));

			if (kpsMap.getString("TCKNO_OUT") != null) {
				if ("5".equals(kpsMap.getString("DURUMU"))) {
					oMap.put("RESPONSE_CODE", 2087);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 2087)).get("ERROR_MESSAGE"));
					return oMap;
				}
				if (kpsMap.getString("OLUM_TARIHI") != null) {
					oMap.put("RESPONSE_CODE", 5219);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5219)).get("ERROR_MESSAGE"));
					return oMap;
				}
				else {
					iMap.put("DOGUM_TARIHI", kpsMap.getDate("DOGUM_TARIHI"));
					oMap.put("DOGUM_TARIHI", kpsMap.getDate("DOGUM_TARIHI"));
					try {
						GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
					}
					catch (Exception e) {
						oMap.put("RESPONSE_CODE", 5220);
						oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5220)).get("ERROR_MESSAGE"));
						return oMap;
					}
				}
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_DOGRULAMA", kpsMap));
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KAYIP_KIMLIK_SORGULAMA", iMap));
			}
			else {
				oMap.put("RESPONSE_CODE", 5208);
				oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5208)).get("ERROR_MESSAGE"));
				return oMap;
			}
			if (!"E".equalsIgnoreCase(iMap.getString("API_EH"))) {
				/** valiadasyon basarili ise musteri yarat **/
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				apsMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				apsMap.put("TC_KIMLIK_NO", iMap.getString("TCKN"));
				apsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_APS_SORGULAMA", apsMap));
				// apsMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_APS_SORGULAMA", apsMap));

				sMap.put("KANAL_KODU", iMap.getString("KANAL_KODU", "8"));
				sMap.put("KANAL_ALT_KODU", iMap.getString("KANAL_ALT_KOD"));
				sMap.put("URUN_KAMP_KOD", iMap.getString("URUN_KAMP_KOD"));
				sMap.put("SERI_NO", kpsMap.getString("KIMLIK_SERI_NO"));
				sMap.put("SIRA_NO", kpsMap.getString("KIMLIK_SIRA_NO"));
				sMap.put("CINSIYET", ("2").equals(kpsMap.getString("CINSIYET_KOD")) ? "K" : "E");
				sMap.putAll(kpsMap);
				sMap.putAll(apsMap);
				sMap.put("BABA_ADI", sMap.getString("BABA_AD"));
				sMap.put("ANNE_ADI", sMap.getString("ANNE_AD"));
				sMap.put("TCK_NO", kpsMap.get("TCKNO"));
				sMap.put("ISIM", sMap.get("AD1"));
				sMap.put("IKINCI_ISIM", sMap.get("AD2"));
				sMap.put("SOYADI", sMap.get("SOYAD"));
				sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
				sMap.put("CINSIYET_KOD", ("2").equals(kpsMap.getString("CINSIYET_KOD")) ? "K" : "E");
				sMap.put("MEDENI_HAL_KOD", ("2").equals(sMap.get("MEDENI_HALI_KOD")) ? "1" : "2");
				sMap.put("NUFUS_AILE_SIRA_NO", sMap.get("AILE_SIRA_NO"));
				sMap.put("CILT_NO", sMap.get("CILT_KODU"));
				sMap.put("SIRA_NO", sMap.get("BIREY_SIRA_NO"));
				sMap.put("VERILDIGI_YER", sMap.get("VERILDIGI_ILCE_ADI"));
				sMap.put("VERILDIGI_TARIH", sMap.get("VERILIS_TARIHI"));
				sMap.put("IL_KOD", kpsMap.get("IL_KODU"));
				sMap.put("ILCE_KOD", kpsMap.get("ILCE_KODU"));
				sMap.put("NUF_VERILIS_NEDENI", sMap.getString("VERILIS_NEDENI"));

				if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
					sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
				}
				else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
					sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
				}

				sMap.put("CEP_TEL_KOD", iMap.get("CEP_TEL_ALAN_KODU"));
				sMap.put("CEP_TEL_NO", iMap.get("CEP_TEL_NO"));
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_CREATE_KONTAKT_MUSTERI", sMap));
				oMap.put("MUSTERI_NO", sMap.getBigDecimal("MUSTERI_NO"));
				if (sMap.get("MUSTERI_NO") != null) {
					sMap.put("MUSTERI_KONTAKT", GMServiceExecuter.execute("BNSPR_CUST_GET_MUSTERIMI_KONTAKMI", sMap).get("KONTAK_MUSTERI"));

					sMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", sMap));
					sMap.putAll(GMServiceExecuter.execute("BNSPR_CL_KART_BHS_KONTROL", sMap));

					if ("M".equals(sMap.getString("MUSTERI_KONTAKT")) && ("E".equals(sMap.getString("F_BHS")) || "E".equals(sMap.getString("KK_BHS")))) {
						oMap.put("MUSTERI_KONTAKT", "M");
					}
					else {
						oMap.put("MUSTERI_KONTAKT", "K");
					}
					if ("M".equals(oMap.getString("MUSTERI_KONTAKT"))) {
						Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
						GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", sMap.getBigDecimal("MUSTERI_NO"))).uniqueResult();
						if (musteri != null) {
							oMap.put("CALISMA_SEKLI", musteri.getCalismaSekli());
						}

						String eksikBilgiEh = "H";
						
						stmt.close();
						stmt = conn.prepareCall("{call pkg_webkredi.musteri_eksik_bilgi_kontrol(?, ?)}");
						int pc = 1;
						stmt.setBigDecimal(pc++, sMap.getBigDecimal("MUSTERI_NO"));
						stmt.registerOutParameter(pc++, Types.VARCHAR);

						stmt.execute();

						eksikBilgiEh = stmt.getString(2);

						oMap.put("MUSTERI_EKSIK_BILGI_EH", eksikBilgiEh);
					}
				}

				// kanal kullanicisi yarat..
				iMap.put("MUSTERI_NO", sMap.get("MUSTERI_NO"));
				iMap.put("USERNAME", iMap.getString("TC_KIMLIK_NO"));
				iMap.put("CHANNELS", 0, "CODE", "WEB");
				iMap.put("ROLES", 0, "CODE", "GNL");
				GMServiceExecuter.call("ADK_CREATE_USER", iMap);

				/** kps datasini basvuruya uygun hale getirip oyle don. **/
				kpsMap.put("ADI", kpsMap.remove("AD1"));
				kpsMap.put("IKINCI_ADI", kpsMap.remove("AD2"));
				kpsMap.put("SOYADI", kpsMap.remove("SOYAD"));
				kpsMap.put("NUFUS_VERILIS_TARIHI", kpsMap.remove("VERILIS_TARIHI"));
				kpsMap.put("BABA_ADI", kpsMap.remove("BABA_AD"));
				kpsMap.put("ANNE_ADI", kpsMap.remove("ANNE_AD"));
				kpsMap.put("NUFUS_MAHALLE", kpsMap.remove("MAHALLE_KOY"));
				kpsMap.put("KIMLIK_SERI_NO_KPS", kpsMap.remove("KIMLIK_SERI_NO"));
				kpsMap.put("KIMLIK_SIRA_NO_KPS", kpsMap.remove("KIMLIK_SIRA_NO"));
				kpsMap.put("NUFUS_IL_KOD", kpsMap.remove("IL_KODU"));
				kpsMap.put("NUFUS_ILCE_KOD", kpsMap.remove("ILCE_KODU"));
				kpsMap.put("NUFUS_CILT_NO", kpsMap.remove("CILT_KODU"));
				kpsMap.put("NUFUS_AILE_SIRA_NO", kpsMap.remove("AILE_SIRA_NO"));
				kpsMap.put("NUFUS_SIRA_NO", kpsMap.get("BIREY_SIRA_NO"));
				if (kpsMap.get("CINSIYET") != null) {
					kpsMap.put("CINSIYET", ((String) kpsMap.remove("CINSIYET")).substring(0, 1));
				}
				if (kpsMap.get("MEDENI_HALI") != null) {
					kpsMap.put("MEDENI_HAL", ((String) kpsMap.remove("MEDENI_HALI")).substring(0, 1).equals("E") ? 1 : 2);
				}
				kpsMap.put("KAYIP_CUZDAN_NO", kpsMap.remove("KAYIP_CUZDAN_NO"));
				kpsMap.put("KAYIP_CUZDAN_SERI", kpsMap.remove("KAYIP_CUZDAN_SERI"));
				kpsMap.put("NUF_VERILIS_NEDENI", kpsMap.remove("VERILIS_NEDENI"));
				kpsMap.put("NUF_VERILDIGI_YER", kpsMap.remove("VERILDIGI_ILCE_ADI"));
				if (kpsMap.get("KIMLIK_SERI_NO_KPS") != null && kpsMap.get("KIMLIK_SIRA_NO_KPS") != null && kpsMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && kpsMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
					kpsMap.put("NUFUS_CUZDANI_SERI_NO", kpsMap.getString("KIMLIK_SERI_NO_KPS").concat(kpsMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
				}

			}

			oMap.put("KPS_DATA", kpsMap);
			oMap.put("RESPONSE_CODE", "00");
			oMap.put("RESPONSE_MESSAGE", "");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Web Kredi basvuru akisina almadan once mevcut basvuru kontrolu yapilir.
	 * Eger varsa bu basvurunun bilgileri, nbsm sonuclari ve tff bilgileri doner.
	 * 
	 * @author mehmet.uluturk
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_EXIST_APPLICATION_CONTROL_API")
	public static GMMap existApplicationApi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		GMMap pMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

			stmt = conn.prepareCall("{? = call pkg_webkredi.get_exist_application(?, ?, ?, ?)}");
			int pc = 1;
			stmt.registerOutParameter(pc++, -10);
			stmt.setString(pc++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ODEME_TIP_KOD"));
			stmt.registerOutParameter(pc++, Types.FLOAT);
			stmt.registerOutParameter(pc++, Types.VARCHAR);

			stmt.execute();

			iMap.put("HATA_NO", stmt.getBigDecimal(4));

			if (iMap.get("HATA_NO") != null) {
				oMap.put("RESPONSE_CODE", iMap.get("HATA_NO"));
				oMap.put("RESPONSE_MESSAGE", stmt.getString(5));
				return oMap;
			}
			rSet = (ResultSet) stmt.getObject(1);
			GMMap tMap = DALUtil.rSetMap(rSet);
			String keyword = "STANDART";

			/** aylik taksit bilgileri **/
			if (!StringUtils.isEmpty(tMap.getString("SORGU_SEVIYESI"))) {
				if (tMap.get("ONAY_TUTAR") != null && tMap.getBigDecimal("ONAY_TUTAR").compareTo(BigDecimal.ZERO) > 0) {
					BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", tMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					String tableName = "SEGMENT_TABLE";
					GMMap sMap = DALUtil.getResults("select s.normal_kredi_limit,s.mini_kredi_limit,s.upsell_kredi_limit, s.dusuk_faiz_kredi_limit, s.konsolidasyon_kredi_limit,s.spot_kredi_limit,s.ononay_kredi_limit,nvl(s.musteri_segment,'X') segment,nvl(s.musteri_segment_alt_kod,'X') segment_alt_kod from bnspr.bir_nbsm_sonuc s where s.basvuru_no = " + tMap.getBigDecimal("BASVURU_NO") + " and s.nbsm_call_tip_kod = '" + tMap.getString("SORGU_SEVIYESI") + "' and s.nbsm_call_id = (select max(s2.nbsm_call_id) from bir_nbsm_sonuc s2 where s2.basvuru_no = s.basvuru_no and s2.nbsm_call_tip_kod = s.nbsm_call_tip_kod)", tableName);
					String segment = null;
					String segmentAltKod = null;

					BigDecimal normalKrediLimit = null;
					BigDecimal miniKrediLimit = null;
					BigDecimal upsellKrediLimit = null;
					BigDecimal dusukFaizKrediLimit = null;
					BigDecimal konsolidasyonKrediLimit = null;
					BigDecimal spotKrediLimit = null;
					BigDecimal ononayKrediLimit = null;

					if (sMap != null && sMap.getSize(tableName) > 0) {
						segment = sMap.getString(tableName, 0, "SEGMENT");
						segmentAltKod = sMap.getString(tableName, 0, "SEGMENT_ALT_KOD");
						dusukFaizKrediLimit = sMap.getBigDecimal(tableName, 0, "DUSUK_FAIZ_KREDI_LIMIT");
						konsolidasyonKrediLimit = sMap.getBigDecimal(tableName, 0, "KONSOLIDASYON_KREDI_LIMIT");
						miniKrediLimit = sMap.getBigDecimal(tableName, 0, "MINI_KREDI_LIMIT");
						normalKrediLimit = sMap.getBigDecimal(tableName, 0, "NORMAL_KREDI_LIMIT");
						ononayKrediLimit = sMap.getBigDecimal(tableName, 0, "ONONAY_KREDI_LIMIT");
						spotKrediLimit = sMap.getBigDecimal(tableName, 0, "SPOT_KREDI_LIMIT");
						upsellKrediLimit = sMap.getBigDecimal(tableName, 0, "UPSELL_KREDI_LIMIT");
					}
					sMap.put("KANAL_KODU", birBasvuru.getKanalKodu());
					sMap.put("VADE", birBasvuru.getVade());
					sMap.put("TUTAR", birBasvuru.getTutar());
					sMap.put("KANAL_KOD", birBasvuru.getKanalKodu());
					sMap.put("DOVIZ_KODU", "TRY");
					sMap.put("KREDI_TURU", birBasvuru.getKrediTur());
					sMap.put("MUSTERI_SEGMENT", segment);
					sMap.put("SEGMENT_ALT_KOD", segmentAltKod);
					sMap.put("DUSUK_FAIZ_KREDI_LIMIT", dusukFaizKrediLimit);
					sMap.put("KONSOLIDASYON_KREDI_LIMIT", konsolidasyonKrediLimit);
					sMap.put("MINI_KREDI_LIMIT", miniKrediLimit);
					sMap.put("NORMAL_KREDI_LIMIT", normalKrediLimit);
					sMap.put("ONONAY_KREDI_LIMIT", ononayKrediLimit);
					sMap.put("SPOT_KREDI_LIMIT", spotKrediLimit);
					sMap.put("UPSELL_KREDI_LIMIT", upsellKrediLimit);

					oMap.putAll(sMap);

					sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3113_KAMPANYA_BUL", sMap));
					for (int row = 0; row < sMap.getSize("KAMPANYA_LISTE"); row++) {
						if (sMap.getBigDecimal("KAMPANYA_LISTE", row, "KAMP_KOD").compareTo(birBasvuru.getKampKod()) != 0) {
							if (sMap.get("KAMPANYA_LISTE", row, "SIGORTALI_KAMP_KOD") != null && sMap.getBigDecimal("KAMPANYA_LISTE", row, "SIGORTALI_KAMP_KOD").compareTo(birBasvuru.getKampKod()) == 0) {
								sMap.put("KAMPANYA_LISTE", row, "AYLIK_TAKSIT", sMap.getBigDecimal("KAMPANYA_LISTE", row, "SIGORTALI_AYLIK_TAKSIT"));
								sMap.put("KAMPANYA_LISTE", row, "FAIZ_ORANI", sMap.getBigDecimal("KAMPANYA_LISTE", row, "SIGORTALI_FAIZ_ORANI"));
								sMap.put("KAMPANYA_LISTE", row, "KAMP_KOD", sMap.getBigDecimal("KAMPANYA_LISTE", row, "SIGORTALI_KAMP_KOD"));
								sMap.put("KAMPANYA_LISTE", row, "SIGORTALI_KAMP_KOD", "");
							}
						}
					}
					oMap.put("KAMPANYA_LISTE", sMap.get("KAMPANYA_LISTE"));

					if (oMap.get("MINI_KREDI_LIMIT") != null && oMap.getBigDecimal("MINI_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "MINI";
					}
					else if (oMap.get("UPSELL_KREDI_LIMIT") != null && oMap.getBigDecimal("UPSELL_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0 && oMap.get("NORMAL_KREDI_LIMIT") != null && oMap.getBigDecimal("NORMAL_KREDI_LIMIT").compareTo(birBasvuru.getTutar()) < 0) {
						keyword = "UPDOWNSELL";
					}
					else if (oMap.get("UPSELL_KREDI_LIMIT") != null && oMap.getBigDecimal("UPSELL_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "UPSELL";
					}
					else if (oMap.get("DUSUK_FAIZ_KREDI_LIMIT") != null && oMap.getBigDecimal("DUSUK_FAIZ_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "LOWINTEREST";
					}
					else if (oMap.get("KONSOLIDASYON_KREDI_LIMIT") != null && oMap.getBigDecimal("KONSOLIDASYON_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "CONSOLIDATION";
					}
					else if (oMap.get("SPOT_KREDI_LIMIT") != null && oMap.getBigDecimal("SPOT_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "SPOT";
					}
					else if (oMap.get("ONONAY_KREDI_LIMIT") != null && oMap.getBigDecimal("ONONAY_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
						keyword = "PREAPPROVED";
					}
					else if (oMap.get("NORMAL_KREDI_LIMIT") != null && oMap.getBigDecimal("NORMAL_KREDI_LIMIT").compareTo(birBasvuru.getTutar()) < 0) {
						keyword = "DOWNSELL";
					}

					oMap.put("KEYWORD", keyword);

				}
				/** on onay bilgileri **/
				pMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_ON_ONAY_BILGI", iMap));
				if (pMap.get("BASVURU_NO") != null) {
					tMap.put("ON_ONAY_LIMIT", pMap.get("TUTAR"));
					tMap.put("ON_ONAY_VADE", pMap.get("VADE"));
					tMap.put("ON_ONAY_AYLIK_TAKSIT", pMap.get("AYLIK_TAKSIT"));
					tMap.put("ON_ONAY_FAIZ_ORANI", pMap.get("FAIZ_ORANI"));
				}
			}
			else {
				if (tMap.get("BASVURU_NO") != null && tMap.get("TRX_NO") != null) {
					tMap.remove("ONAY_TUTAR");
					tMap.putAll(GMServiceExecuter.execute("BNSPR_CL_WEB_INIT_EVALUATION_API", tMap));
				}
			}

			List<GnlMusteri> musteriList = session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).list();
			String eksikBilgiEh = "H";

			if (musteriList != null && musteriList.size() > 0) {

				stmt2 = conn.prepareCall("{call pkg_webkredi.musteri_eksik_bilgi_kontrol(?, ?)}");
				pc = 1;
				stmt2.setBigDecimal(pc++, musteriList.get(0).getMusteriNo());
				stmt2.registerOutParameter(pc++, Types.VARCHAR);

				stmt2.execute();
				eksikBilgiEh = stmt2.getString(2);
			}

			oMap.put("MUSTERI_EKSIK_BILGI_EH", eksikBilgiEh);
			
			/** Retention limit bilgileri **/
			oMap.put("RETENTION_EH", "H");
			iMap.put("LIMIT_TURU", "R");
			pMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_ON_ONAY_BILGI", iMap));
			if (pMap.get("BASVURU_NO") != null) {
				oMap.put("RETENTION_EH", "E");
				oMap.put("RETENTION_LIMIT", pMap.get("TUTAR"));
				oMap.put("RETENTION_VADE", pMap.get("VADE"));
				oMap.put("RETENTION_AYLIK_TAKSIT", pMap.get("AYLIK_TAKSIT"));
				oMap.put("RETENTION_FAIZ_ORANI", pMap.get("FAIZ_ORANI"));
			}

			oMap.put("APPLICATION_DETAIL", tMap);
			oMap.put("RESPONSE_CODE", "00");
			oMap.put("RESPONSE_MESSAGE", "");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Web Kredi basvuru akisina almadan once mevcut basvuru kontrolu yapilir.
	 * Eger varsa bu basvurunun bilgileri, nbsm sonuclari ve tff bilgileri doner.
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_EXIST_APPLICATION_CONTROL")
	public static GMMap existApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap pMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_webkredi.get_exist_application(?, ?, ?)}");
			int pc = 1;
			stmt.registerOutParameter(pc++, -10);
			stmt.setString(pc++, iMap.getString("TC_KIMLIK_NO"));
			stmt.registerOutParameter(pc++, Types.FLOAT);
			stmt.registerOutParameter(pc++, Types.VARCHAR);

			stmt.execute();

			iMap.put("HATA_NO", stmt.getBigDecimal(3));

			if (iMap.get("HATA_NO") != null) {
				oMap.put("RESPONSE_CODE", iMap.get("HATA_NO"));
				oMap.put("RESPONSE_MESSAGE", stmt.getString(4));
				return oMap;
			}
			rSet = (ResultSet) stmt.getObject(1);
			GMMap tMap = DALUtil.rSetMap(rSet);

			/** aylik taksit bilgileri **/
			if (!StringUtils.isEmpty(tMap.getString("SORGU_SEVIYESI"))) {
				if (tMap.get("ONAY_TUTAR") != null && tMap.getBigDecimal("ONAY_TUTAR").compareTo(BigDecimal.ZERO) > 0) {
					tMap.putAll(GMServiceExecuter.execute("BNSPR_CL_WEB_TAKSIT_BILGI", tMap));
				}
				/** on onay bilgileri **/
				pMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_ON_ONAY_BILGI", iMap));
				if (pMap.get("BASVURU_NO") != null) {
					tMap.put("ON_ONAY_LIMIT", pMap.get("TUTAR"));
					tMap.put("ON_ONAY_VADE", pMap.get("VADE"));
					tMap.put("ON_ONAY_AYLIK_TAKSIT", pMap.get("AYLIK_TAKSIT"));
					tMap.put("ON_ONAY_FAIZ_ORANI", pMap.get("FAIZ_ORANI"));
				}
			}
			else {
				if (tMap.get("BASVURU_NO") != null && tMap.get("TRX_NO") != null) {
					tMap.remove("ONAY_TUTAR");
					tMap.putAll(GMServiceExecuter.execute("BNSPR_CL_WEB_INIT_EVALUATION", tMap));
				}
			}

			oMap.put("APPLICATION_DETAIL", tMap);
			oMap.put("RESPONSE_CODE", "00");
			oMap.put("RESPONSE_MESSAGE", "");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Web Kredi basvuru iptal servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CANCEL_APPLICATION")
	public static GMMap cancelApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBigDecimal("BASVURU_NO") == null) {
				throw new GMRuntimeException(0, "Basvuru no zorunludur.");
			}
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if (birBasvuru != null && !"RED".equals(birBasvuru.getDurumKodu())) {
				iMap.put("AKSIYON_KARAR_KOD", ConsumerLoanCommonServices.nvl(iMap.getString("AKSIYON_KARAR_KOD"), "3"));
				GMServiceExecuter.call("BNSPR_TRN3172_BASVURU_IPTAL", iMap);
			}

			oMap.put("RESPONSE_CODE", "00");
			oMap.put("RESPONSE_MESSAGE", "");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Kisiye ait web kredi kanalindan yapilmis son basvuru numarasini verir.<br>
	 * 
	 * @author murat.el
	 * @since PY-11169
	 * @param iMap
	 *            - Sorgu kriterleri<br>
	 *            <li>TCKN - Kisi tc kimlik numarasi
	 * @return Basvuru numarasi<br>
	 *         <li>BASVURU_VAR_MI - E:Evet|H:Hayir <li>BASVURU_NO - Basvuru no <li>DURUM_KODU - Durum Kodu <li>VADE - Vade <li>ONAY_TUTAR - Onaylanan Tutar <li>CEP_TEL - Cep telefonu <li>EMAIL - Email adresi <li>AD_SOYAD - Musteri unvani
	 */
	@GraymoundService("BNSPR_CL_GET_LAST_APPPLICATION_NO_BY_TCKN")
	public static GMMap getLastApplicationNoByTckn(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_webkredi.get_last_application_for_evam(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("TCKN"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
			//
			if (oMap.get("BASVURU_NO") == null) {
				oMap.put("BASVURU_VAR_MI", Constants.HAYIR);
				String musteriNo = (String) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.Musteri_Varmi_TCKN(?)}", Types.VARCHAR, iMap.getString("TCKN"));
				if (musteriNo != null) {
					iMap.put("CUSTOMER_NO", musteriNo);
					iMap.put("FORMAT", "AT");
					iMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", iMap));
					oMap.put("CEP_TEL", iMap.get("PHONE_NUMBER"));
				}
			}
			else {
				oMap.put("BASVURU_VAR_MI", Constants.EVET);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	/**
	 * Web Kredi basvuru yaratma servisi
	 * 
	 * @author mehmet.uluturk
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CREATE_APPLICATION_API")
	public static GMMap createApplicationApi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		GMMap kpsMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			GMMap appMap = new GMMap();
			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				appMap.putAll(iMap);
				appMap.remove("KPS_DATA");
			}
			else {
				appMap.putAll(iMap.getMap("APPLICATION_DETAIL"));
			}

			/** KPS Sorgusu ve Kontrolleri **/
			iMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));

			kpsMap.put("TCKNO", appMap.getString("TC_KIMLIK_NO"));
			kpsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", kpsMap));

			if (kpsMap.getString("TCKNO_OUT") != null) {
				if ("5".equals(kpsMap.getString("DURUMU"))) {
					oMap.put("RESPONSE_CODE", 5207);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5207)).get("ERROR_MESSAGE"));
					return oMap;
				}
				if (kpsMap.getString("OLUM_TARIHI") != null) {
					oMap.put("RESPONSE_CODE", 5219);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5219)).get("ERROR_MESSAGE"));
					return oMap;
				}
				else {
					iMap.put("DOGUM_TARIHI", kpsMap.getDate("DOGUM_TARIHI"));
					try {
						GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
					}
					catch (Exception e) {
						oMap.put("RESPONSE_CODE", 5220);
						oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5220)).get("ERROR_MESSAGE"));
						return oMap;
					}
				}
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_DOGRULAMA", kpsMap));
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KAYIP_KIMLIK_SORGULAMA", iMap));
			}
			else {
				oMap.put("RESPONSE_CODE", 5208);
				oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5208)).get("ERROR_MESSAGE"));
				return oMap;
			}

			/** kps datasini basvuruya uygun hale getir. **/
			kpsMap.put("ADI", kpsMap.remove("AD1"));
			kpsMap.put("IKINCI_ADI", kpsMap.remove("AD2"));
			kpsMap.put("SOYADI", kpsMap.remove("SOYAD"));
			kpsMap.put("NUFUS_VERILIS_TARIHI", kpsMap.remove("VERILIS_TARIHI"));
			kpsMap.put("BABA_ADI", kpsMap.remove("BABA_AD"));
			kpsMap.put("ANNE_ADI", kpsMap.remove("ANNE_AD"));
			kpsMap.put("NUFUS_MAHALLE", kpsMap.remove("MAHALLE_KOY"));
			kpsMap.put("KIMLIK_SERI_NO_KPS", kpsMap.remove("KIMLIK_SERI_NO"));
			kpsMap.put("KIMLIK_SIRA_NO_KPS", kpsMap.remove("KIMLIK_SIRA_NO"));
			kpsMap.put("NUFUS_IL_KOD", kpsMap.remove("IL_KODU"));
			kpsMap.put("NUFUS_ILCE_KOD", kpsMap.remove("ILCE_KODU"));
			kpsMap.put("NUFUS_CILT_NO", kpsMap.remove("CILT_KODU"));
			kpsMap.put("NUFUS_AILE_SIRA_NO", kpsMap.remove("AILE_SIRA_NO"));
			kpsMap.put("NUFUS_SIRA_NO", kpsMap.get("BIREY_SIRA_NO"));
			if (kpsMap.get("CINSIYET") != null) {
				kpsMap.put("CINSIYET", ((String) kpsMap.remove("CINSIYET")).substring(0, 1));
			}
			if (kpsMap.get("MEDENI_HALI") != null) {
				kpsMap.put("MEDENI_HAL", ((String) kpsMap.remove("MEDENI_HALI")).substring(0, 1).equals("E") ? 1 : 2);
			}
			kpsMap.put("KAYIP_CUZDAN_NO", kpsMap.remove("KAYIP_CUZDAN_NO"));
			kpsMap.put("KAYIP_CUZDAN_SERI", kpsMap.remove("KAYIP_CUZDAN_SERI"));
			kpsMap.put("NUF_VERILIS_NEDENI", kpsMap.remove("VERILIS_NEDENI"));
			kpsMap.put("NUF_VERILDIGI_YER", kpsMap.remove("VERILDIGI_ILCE_ADI"));
			if (kpsMap.get("KIMLIK_SERI_NO_KPS") != null && kpsMap.get("KIMLIK_SIRA_NO_KPS") != null && kpsMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && kpsMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				kpsMap.put("NUFUS_CUZDANI_SERI_NO", kpsMap.getString("KIMLIK_SERI_NO_KPS").concat(kpsMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}

			appMap.putAll(kpsMap);

			// validasyonlar
			sMap.put("KRD_TUR_KOD", appMap.getBigDecimal("KRD_TUR_KOD", new BigDecimal(1)));
			sMap.put("KAMP_URUN_ADI", appMap.getString("KAMP_KOD"));
			sMap.put("DOVIZ_KODU", appMap.getString("DOVIZ_KODU", "TRY"));
			sMap.put("KREDI_TUTARI", appMap.getBigDecimal("TUTAR"));
			sMap.put("KREDI_VADESI", appMap.getBigDecimal("VADE"));
			sMap.put("KANAL_KOD", appMap.getBigDecimal("KANAL_KOD", new BigDecimal(8)));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", sMap);

			sMap.put("TUTAR", appMap.getBigDecimal("TUTAR"));
			sMap.put("VADE", appMap.getBigDecimal("VADE"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", sMap));
			appMap.put("KAMP_KNL_KOD", sMap.get("KAMP_KNL_KOD"));

			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", sMap);

			sMap.put("DOVIZ_KOD", sMap.getString("DOVIZ_KODU"));
			sMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", sMap));
			sMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", sMap));
			appMap.put("FAIZ_ORANI", sMap.get("FAIZ_ORAN"));
			appMap.put("SOZLESME_FAIZI", sMap.get("SOZLESME_ORANI"));
			appMap.put("KATILIM_BEDELI", sMap.get("MAX_KATKI_PAYI"));
			appMap.put("DOSYA_MASRAFI", sMap.get("MAX_DOSYA_MASRAFI"));

			sMap.clear();
			sMap.put("KAMP_KOD", appMap.get("KAMP_KOD"));
			sMap.put("TCKN", appMap.getString("TC_KIMLIK_NO"));
			GMServiceExecuter.execute("BNSPR_TRN3171_KAMPANYA_KULLANILABILIR_MI", sMap);

			// basvuru no yarat. Ononay limitinden basvuru no da gelebilir. incelenecek.
			if (appMap.getString("BASVURU_NO") == null || appMap.getString("BASVURU_NO").isEmpty()) {
				List<BirBasvuru> list = null;
				if("8".equals(appMap.getString("ODEME_TIPI", "2"))) {
					list = session.createCriteria(BirBasvuru.class).add(Restrictions.eq("tcKimlikNo", appMap.getString("TC_KIMLIK_NO"))).add(Restrictions.eq("durumKodu", "BASVURU")).add(Restrictions.eq("kanalKodu", "8")).add(Restrictions.eq("odemeTipKod", BigDecimal.valueOf(8))).addOrder(Order.desc("basvuruNo")).list();
				}else{
					list = session.createCriteria(BirBasvuru.class).add(Restrictions.eq("tcKimlikNo", appMap.getString("TC_KIMLIK_NO"))).add(Restrictions.eq("durumKodu", "BASVURU")).add(Restrictions.eq("kanalKodu", "8")).add(Restrictions.ne("odemeTipKod", BigDecimal.valueOf(8))).addOrder(Order.desc("basvuruNo")).list();
				}
				if (list.size() > 0) {
					appMap.put("BASVURU_NO", ((BirBasvuru) list.get(0)).getBasvuruNo());
				}
				else {
					appMap.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", iMap).getBigDecimal("ID"));
				}
			}

			sMap.clear();
			sMap.put("BASVURU_NO", appMap.getBigDecimal("BASVURU_NO"));
			sMap.put("CEP_TEL_ALAN", appMap.getString("CEP_TEL_KOD"));
			sMap.put("CEP_TEL_NO", appMap.getString("CEP_TEL_NO"));
			sMap.put("TC_KIMLIK_NO", appMap.getString("TC_KIMLIK_NO"));
			sMap.put("KANAL_KODU", appMap.getString("KANAL_KODU", "8"));
			sMap.put("KANAL_ALT_KODU", appMap.getString("KANAL_ALT_KOD"));
			sMap.put("KREDI_TURU", appMap.getString("KRD_TUR_KOD", "1"));
			GMServiceExecuter.execute("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU", sMap);

			appMap.put("EKRAN_NO", "3171");
			appMap.put("URUN_KAMP_KOD", appMap.get("KAMP_KOD"));

			if (appMap.getString("TRX_NO") == null || appMap.getString("TRX_NO").isEmpty()) {
				appMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			appMap.put("ODEME_TIPI", appMap.getString("ODEME_TIPI", "2"));
			appMap.put("ODEME_VADESI", appMap.getString("ODEME_VADESI"));
			appMap.put("KRD_TUR_KOD", appMap.getString("KRD_TUR_KOD", "1"));
			appMap.put("KANAL_KOD", appMap.getString("KANAL_KODU", "8"));
			appMap.put("DOVIZ_KOD", appMap.getString("DOVIZ_KODU", "TRY"));
			appMap.put("KIMLIK_SERI_NO", appMap.get("KIMLIK_SERI_NO_KPS"));
			appMap.put("KIMLIK_SIRA_NO", appMap.get("KIMLIK_SIRA_NO_KPS"));
			if (appMap.get("EMAIL") != null && !appMap.getString("EMAIL").isEmpty()) {
				Object[] inputValues = new Object[4];
				inputValues[0] = BnsprType.STRING;
				inputValues[1] = appMap.getString("EMAIL");
				Object[] outputValues = new Object[0];
				String proc = "{ call pkg_trn10011.e_mail_check(?) }";
				DALUtil.callOracleProcedure(proc, inputValues, outputValues);

				appMap.put("EMAIL1", appMap.getString("EMAIL").substring(0, appMap.getString("EMAIL").indexOf('@')));
				appMap.put("EMAIL2", appMap.getString("EMAIL").substring(appMap.getString("EMAIL").indexOf('@') + 1));
			}
			else {
				if ("5".equals(iMap.getString("KANAL_KODU"))) {
					ConsumerLoanCommonServices.raiseGMError("330", "EMAIL");
				}
			}
			appMap.put("KPS_YAPILDI", "E");

			/** calisma sekli - musteri uzerinden bilgileri al **/
			if (appMap.get("TC_KIMLIK_NO") != null) {
				GMMap mMap = new GMMap();
				mMap.put("TCKN", appMap.get("TC_KIMLIK_NO"));
				mMap.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", mMap));
				if ("M".equals(mMap.getString("MUSTERI_KONTAKT"))) {
					appMap.put("CALISMA_SEKLI", mMap.get("CALISMA_SEKLI"));
				}

				/** Aps bilgisinin nbsmde beslenmesi icin **/
				GMMap apsMap = new GMMap();
				apsMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_APS_SORGULAMA", appMap));
				appMap.put("APS_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));
			}
			
			/** Retention talep edilmediyse retention limit iptal edilir. **/
			if("H".equals(iMap.getString("RETENTION_EH"))){
				List<BirAdkBasvuru> retList = session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("tcKimlikNo", appMap.getString("TC_KIMLIK_NO"))).add(Restrictions.eq("durumKod", "1")).add(Restrictions.eq("akisTuru", "R")).list();
				for (BirAdkBasvuru birAdkBasvuru : retList) {
					birAdkBasvuru.setDurumKod(ConsumerLoanQRY8000Services.IPTAL);
					session.save(birAdkBasvuru);
					session.flush();
				}
			}

			GMMap outMap = new GMMap();
			outMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_SAVE_TEMP", appMap));

			BirBasvuruTx birBasvuruTx = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("txNo", appMap.getBigDecimal("TRX_NO"))).uniqueResult();

			if (birBasvuruTx != null) {
				session.refresh(birBasvuruTx);
				birBasvuruTx.setApiEh("E");
				session.saveOrUpdate(birBasvuruTx);
				session.flush();
			}

			iMap.put("MUSTERI_YARATMA_TX_NO", outMap.getBigDecimal("MUSTERI_YARATMA_TX_NO"));
			iMap.put("MUSTERI_NO", outMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("BASVURU_NO", appMap.get("BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_UPDATE_MUSTERI_NO", iMap));
			oMap.put("BASVURU_NO", appMap.get("BASVURU_NO"));
			oMap.put("TRX_NO", appMap.get("TRX_NO"));

			GMMap xMap = new GMMap();
			xMap.put("DOKUMAN_KODU", Enums.CreditDocTypes.KVK_FORM.getCode());
			xMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));

			Object sonuc = GMServiceExecuter.execute("BNSPR_GET_MUSTERI_DOKUMAN", xMap).get("DOKUMAN_LIST");

			if (sonuc == null) {
				GMMap dMap = new GMMap();
				dMap.put("APPLICATION_NO", appMap.get("BASVURU_NO"));
				dMap.put("MAIL_TRANSFER", false);
				dMap.put("DYS_TRANSFER", true);
				dMap.put("DOC_LIST", 0, "CODE", Enums.CreditDocTypes.KVK_FORM.getCode());
				dMap.put("DOC_LIST", 0, "ALINDI", "E");
				GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}

	/**
	 * Web Kredi basvuru yaratma servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CREATE_APPLICATION")
	public static GMMap createApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			GMMap appMap = new GMMap();
			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				appMap.putAll(iMap);
				appMap.remove("KPS_DATA");
			}
			else {
				appMap.putAll(iMap.getMap("APPLICATION_DETAIL"));
			}
			appMap.putAll(iMap.getMap("KPS_DATA"));

			// validasyonlar
			sMap.put("KRD_TUR_KOD", appMap.getBigDecimal("KRD_TUR_KOD", new BigDecimal(1)));
			sMap.put("KAMP_URUN_ADI", appMap.getString("KAMP_KOD"));
			sMap.put("DOVIZ_KODU", appMap.getString("DOVIZ_KODU", "TRY"));
			sMap.put("KREDI_TUTARI", appMap.getBigDecimal("TUTAR"));
			sMap.put("KREDI_VADESI", appMap.getBigDecimal("VADE"));
			sMap.put("KANAL_KOD", appMap.getBigDecimal("KANAL_KOD", new BigDecimal(8)));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", sMap);

			sMap.put("TUTAR", appMap.getBigDecimal("TUTAR"));
			sMap.put("VADE", appMap.getBigDecimal("VADE"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", sMap));
			appMap.put("KAMP_KNL_KOD", sMap.get("KAMP_KNL_KOD"));

			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", sMap);

			sMap.put("DOVIZ_KOD", sMap.getString("DOVIZ_KODU"));
			sMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", sMap));
			sMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", sMap));
			appMap.put("FAIZ_ORANI", sMap.get("FAIZ_ORAN"));
			appMap.put("SOZLESME_FAIZI", sMap.get("SOZLESME_ORANI"));
			appMap.put("KATILIM_BEDELI", sMap.get("MAX_KATKI_PAYI"));
			appMap.put("DOSYA_MASRAFI", sMap.get("MAX_DOSYA_MASRAFI"));

			sMap.clear();
			sMap.put("KAMP_KOD", appMap.get("KAMP_KOD"));
			sMap.put("TCKN", appMap.getString("TC_KIMLIK_NO"));
			GMServiceExecuter.execute("BNSPR_TRN3171_KAMPANYA_KULLANILABILIR_MI", sMap);

			// basvuru no yarat. Ononay limitinden basvuru no da gelebilir. incelenecek.
			if (appMap.getString("BASVURU_NO") == null || appMap.getString("BASVURU_NO").isEmpty()) {
				appMap.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", iMap).getBigDecimal("ID"));
			}

			sMap.clear();
			sMap.put("BASVURU_NO", appMap.getBigDecimal("BASVURU_NO"));
			sMap.put("CEP_TEL_ALAN", appMap.getString("CEP_TEL_KOD"));
			sMap.put("CEP_TEL_NO", appMap.getString("CEP_TEL_NO"));
			sMap.put("TC_KIMLIK_NO", appMap.getString("TC_KIMLIK_NO"));
			sMap.put("KANAL_KODU", appMap.getString("KANAL_KODU", "8"));
			sMap.put("KANAL_ALT_KODU", appMap.getString("KANAL_ALT_KOD"));
			sMap.put("KREDI_TURU", appMap.getString("KRD_TUR_KOD", "1"));
			GMServiceExecuter.execute("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU", sMap);

			appMap.put("EKRAN_NO", "3171");
			appMap.put("URUN_KAMP_KOD", appMap.get("KAMP_KOD"));

			if (appMap.getString("TRX_NO") == null || appMap.getString("TRX_NO").isEmpty()) {
				appMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			appMap.put("ODEME_TIPI", "2");
			appMap.put("KRD_TUR_KOD", appMap.getString("KRD_TUR_KOD", "1"));
			appMap.put("KANAL_KOD", appMap.getString("KANAL_KODU", "8"));
			appMap.put("DOVIZ_KOD", appMap.getString("DOVIZ_KODU", "TRY"));
			appMap.put("KIMLIK_SERI_NO", appMap.get("KIMLIK_SERI_NO_KPS"));
			appMap.put("KIMLIK_SIRA_NO", appMap.get("KIMLIK_SIRA_NO_KPS"));
			if (appMap.get("EMAIL") != null && !appMap.getString("EMAIL").isEmpty()) {
				Object[] inputValues = new Object[4];
				inputValues[0] = BnsprType.STRING;
				inputValues[1] = appMap.getString("EMAIL");
				Object[] outputValues = new Object[0];
				String proc = "{ call pkg_trn10011.e_mail_check(?) }";
				DALUtil.callOracleProcedure(proc, inputValues, outputValues);

				appMap.put("EMAIL1", appMap.getString("EMAIL").substring(0, appMap.getString("EMAIL").indexOf('@')));
				appMap.put("EMAIL2", appMap.getString("EMAIL").substring(appMap.getString("EMAIL").indexOf('@') + 1));
			}
			else {
				if ("5".equals(iMap.getString("KANAL_KODU"))) {
					ConsumerLoanCommonServices.raiseGMError("330", "EMAIL");
				}
			}
			appMap.put("KPS_YAPILDI", "E");

			/** calisma sekli - musteri uzerinden bilgileri al **/
			if (appMap.get("TC_KIMLIK_NO") != null) {
				GMMap mMap = new GMMap();
				mMap.put("TCKN", appMap.get("TC_KIMLIK_NO"));
				mMap.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", mMap));
				if ("M".equals(mMap.getString("MUSTERI_KONTAKT"))) {
					appMap.put("CALISMA_SEKLI", mMap.get("CALISMA_SEKLI"));
				}

				/** Aps bilgisinin nbsmde beslenmesi icin **/
				GMMap apsMap = new GMMap();
				apsMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_APS_SORGULAMA", appMap));
				appMap.put("APS_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));
			}

			GMMap outMap = new GMMap();
			outMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_SAVE_TEMP", appMap));
			iMap.put("MUSTERI_YARATMA_TX_NO", outMap.getBigDecimal("MUSTERI_YARATMA_TX_NO"));
			iMap.put("MUSTERI_NO", outMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("BASVURU_NO", appMap.get("BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_UPDATE_MUSTERI_NO", iMap));
			oMap.put("BASVURU_NO", appMap.get("BASVURU_NO"));
			oMap.put("TRX_NO", appMap.get("TRX_NO"));

			GMMap xMap = new GMMap();
			xMap.put("DOKUMAN_KODU", Enums.CreditDocTypes.KVK_FORM.getCode());
			xMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));

			Object sonuc = GMServiceExecuter.execute("BNSPR_GET_MUSTERI_DOKUMAN", xMap).get("DOKUMAN_LIST");

			if (sonuc == null) {
				GMMap dMap = new GMMap();
				dMap.put("APPLICATION_NO", appMap.get("BASVURU_NO"));
				dMap.put("MAIL_TRANSFER", false);
				dMap.put("DYS_TRANSFER", true);
				dMap.put("DOC_LIST", 0, "CODE", Enums.CreditDocTypes.KVK_FORM.getCode());
				dMap.put("DOC_LIST", 0, "ALINDI", "E");
				GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Web Kredi basvuru NBSM ilk degerlendirme servisi
	 * 
	 * @author mehmet.uluturk
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_INIT_EVALUATION_API")
	public static GMMap initEvaluationApplicationApi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap pMap = new GMMap();
		String keyword = "STANDART";

		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_DEVAM_SORGULAR", iMap));
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if ("E".equals(oMap.getString("DEVAM"))) {
				oMap.put("KANAL_KODU", birBasvuru.getKanalKodu());
				oMap.put("VADE", birBasvuru.getVade());
				oMap.put("TUTAR", birBasvuru.getTutar());
				oMap.put("KANAL_KOD", birBasvuru.getKanalKodu());
				oMap.put("DOVIZ_KODU", "TRY");
				oMap.put("KREDI_TURU", birBasvuru.getKrediTur());

				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3113_KAMPANYA_BUL", oMap));

				if (oMap.get("MINI_KREDI_LIMIT") != null && oMap.getBigDecimal("MINI_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "MINI";
				}
				else if (oMap.get("UPSELL_KREDI_LIMIT") != null && oMap.getBigDecimal("UPSELL_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0 && oMap.get("NORMAL_KREDI_LIMIT") != null && oMap.getBigDecimal("NORMAL_KREDI_LIMIT").compareTo(birBasvuru.getTutar()) < 0) {
					keyword = "UPDOWNSELL";
				}
				else if (oMap.get("UPSELL_KREDI_LIMIT") != null && oMap.getBigDecimal("UPSELL_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "UPSELL";
				}
				else if (oMap.get("DUSUK_FAIZ_KREDI_LIMIT") != null && oMap.getBigDecimal("DUSUK_FAIZ_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "LOWINTEREST";
				}
				else if (oMap.get("KONSOLIDASYON_KREDI_LIMIT") != null && oMap.getBigDecimal("KONSOLIDASYON_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "CONSOLIDATION";
				}
				else if (oMap.get("SPOT_KREDI_LIMIT") != null && oMap.getBigDecimal("SPOT_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "SPOT";
				}
				else if (oMap.get("ONONAY_KREDI_LIMIT") != null && oMap.getBigDecimal("ONONAY_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "PREAPPROVED";
				}
				else if (oMap.get("NORMAL_KREDI_LIMIT") != null && oMap.getBigDecimal("NORMAL_KREDI_LIMIT").compareTo(birBasvuru.getTutar()) < 0) {
					keyword = "DOWNSELL";
				}

				oMap.put("KEYWORD", keyword);
			}
			else {
				// Red almas� durumunda mail g�nderilir.
				GMMap kimlikMap = new GMMap();
				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

				kimlikMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				kimlikMap.put("EMAIL_TO", birBasvuruKimlik.getEMail());
				if(new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())){
					kimlikMap.put("EMAIL_TYPE", "SPOT_SOBF");
				}else{
					kimlikMap.put("EMAIL_TYPE", "SOBF");
				}
				kimlikMap.put("EMAIL_NAME", (birBasvuruKimlik.getAd() + (birBasvuruKimlik.getIkinciAd() != null ? " " + birBasvuruKimlik.getIkinciAd() : " ")).trim());
				kimlikMap.put("EMAIL_SURNAME", birBasvuruKimlik.getSoyad());
				kimlikMap.put("BELGE_KODU", "543");
				
				kimlikMap.put("SEND_ATTACHMENTS", true);

				GMServiceExecuter.execute("BNSPR_CL_CC_SAVE_BEFORE_AGGREMENT_DOCUMENT", kimlikMap);
			}

			/** on onay bilgileri **/

			pMap.put("TC_KIMLIK_NO", birBasvuru.getTcKimlikNo());
			pMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_ON_ONAY_BILGI", pMap));
			if (pMap.get("BASVURU_NO") != null) {
				oMap.put("ON_ONAY_LIMIT", pMap.get("TUTAR"));
				oMap.put("ON_ONAY_VADE", pMap.get("VADE"));
				oMap.put("ON_ONAY_AYLIK_TAKSIT", pMap.get("AYLIK_TAKSIT"));
				oMap.put("ON_ONAY_FAIZ_ORANI", pMap.get("FAIZ_ORANI"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Web Kredi basvuru NBSM ilk degerlendirme servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_INIT_EVALUATION")
	public static GMMap initEvaluationApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_DEVAM_SORGULAR", iMap));

			GMMap pMap = new GMMap();
			pMap.put("PARAMETRE", "WEBKREDI_UPSELL_VADE");
			oMap.put("UPSELL_VADE", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", pMap).getInt("DEGER"));

			pMap.putAll(ConsumerLoanCommonServices.getParamTextLists("MINI_KREDI_KAMPANYA", "RESULTS"));

			oMap.put("MINI_KREDI_TUTAR", pMap.get("RESULTS", 1, "DESCRIPTION"));
			oMap.put("MINI_KREDI_VADE", pMap.get("RESULTS", 2, "DESCRIPTION"));
			oMap.put("MINI_KREDI_KAMPANYA_KODU", pMap.get("RESULTS", 0, "DESCRIPTION"));
			
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			
			/** aylik taksit bilgileri **/
			if ("E".equals(oMap.getString("DEVAM"))) {
				if (oMap.get("ONAY_TUTAR") != null && oMap.getBigDecimal("ONAY_TUTAR").compareTo(BigDecimal.ZERO) > 0) {
					oMap.putAll(iMap);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_CL_WEB_TAKSIT_BILGI", oMap));
				}
			}
			else {
				// Red almas� durumunda mail g�nderilir.
				GMMap kimlikMap = new GMMap();
				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

				kimlikMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				kimlikMap.put("EMAIL_TO", birBasvuruKimlik.getEMail());
				if(new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())){
					kimlikMap.put("EMAIL_TYPE", "SPOT_SOBF");
				}else{
					kimlikMap.put("EMAIL_TYPE", "SOBF");
				}
				kimlikMap.put("EMAIL_NAME", (birBasvuruKimlik.getAd() + (birBasvuruKimlik.getIkinciAd() != null ? " " + birBasvuruKimlik.getIkinciAd() : " ")).trim());
				kimlikMap.put("EMAIL_SURNAME", birBasvuruKimlik.getSoyad());
				kimlikMap.put("BELGE_KODU", "543");

				GMServiceExecuter.execute("BNSPR_CL_CC_SAVE_BEFORE_AGGREMENT_DOCUMENT", kimlikMap);
			}

			/** on onay bilgileri **/
			pMap.clear();
			pMap.put("TC_KIMLIK_NO", birBasvuru.getTcKimlikNo());
			pMap.putAll(GMServiceExecuter.execute("BNSPR_CL_GET_ON_ONAY_BILGI", pMap));
			if (pMap.get("BASVURU_NO") != null) {
				oMap.put("ON_ONAY_LIMIT", pMap.get("TUTAR"));
				oMap.put("ON_ONAY_VADE", pMap.get("VADE"));
				oMap.put("ON_ONAY_AYLIK_TAKSIT", pMap.get("AYLIK_TAKSIT"));
				oMap.put("ON_ONAY_FAIZ_ORANI", pMap.get("FAIZ_ORANI"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Web Kredi onay tutar, mini kredi ve upsel icin taksit bilgilerini dondurur.
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_TAKSIT_BILGI")
	public static GMMap getTaksitBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			GMMap odMap = new GMMap();
			GMMap odrMap = new GMMap();
			odMap.put("KREDI_TURU", birBasvuru.getKrediTur());
			odMap.put("ODEME_TIP_KOD", birBasvuru.getOdemeTipKod());
			odMap.put("KANAL_KOD", birBasvuru.getKanalKodu());
			odMap.put("DOVIZ_KOD", birBasvuru.getDovizKodu());

			if ("Y".equals(iMap.getString("MINI_KREDI_SONUC")) && iMap.get("MINI_KREDI_TUTAR") != null) {
				odMap.put("KREDI_TUTARI", iMap.getBigDecimal("MINI_KREDI_TUTAR"));
				odMap.put("TUTAR", iMap.getBigDecimal("MINI_KREDI_TUTAR"));
				odMap.put("KAMPANYA_KODU", iMap.getBigDecimal("MINI_KREDI_KAMPANYA_KODU"));
				odMap.put("KAMP_URUN_ADI", iMap.getBigDecimal("MINI_KREDI_KAMPANYA_KODU"));
				odMap.put("KREDI_VADE", iMap.getBigDecimal("MINI_KREDI_VADE"));
				odMap.put("VADE", iMap.getBigDecimal("MINI_KREDI_VADE"));
				odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
				oMap.put("MINI_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_TUTAR"));
				oMap.put("MINI_FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
			}
			else {
				odMap.put("KAMPANYA_KODU", birBasvuru.getKampKod());
				odMap.put("KREDI_TUTARI", iMap.get("ONAY_TUTAR"));
				odMap.put("TUTAR", iMap.get("ONAY_TUTAR"));
				odMap.put("KREDI_VADE", birBasvuru.getVade());
				odMap.put("VADE", birBasvuru.getVade());
				odMap.put("KAMP_URUN_ADI", birBasvuru.getKampKod());
				odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
				oMap.put("ONAY_TUTAR_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_TUTAR"));
				oMap.put("FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
			}

			if (iMap.get("UPSELL_LIMIT") != null && iMap.getBigDecimal("UPSELL_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
				odrMap.clear();
				odMap.put("KREDI_TUTARI", iMap.getBigDecimal("UPSELL_LIMIT"));
				odMap.put("TUTAR", iMap.getBigDecimal("UPSELL_LIMIT"));
				odMap.put("KREDI_VADE", iMap.getBigDecimal("UPSELL_VADE"));
				odMap.put("VADE", iMap.getBigDecimal("UPSELL_VADE"));
				odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
				oMap.put("UPSELL_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_TUTAR"));
				oMap.put("UPSELL_FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Web Kredi basvuru guncelleme servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_UPDATE_APPLICATION")
	public static GMMap updateApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		GMMap apsMap = new GMMap();
		try {
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}

			GMMap appMap = GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU", iMap);
			appMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU_DETAY", iMap));
			oMap.put("DURUM_KODU", appMap.get("DURUM_KODU"));
			oMap.put("TC_KIMLIK_NO", appMap.get("TC_KIMLIK_NO"));

			appMap.putAll(iMap.getMap("APPLICATION_DETAIL"));

			if (!"H".equalsIgnoreCase(iMap.getString("VALIDASYON_EH"))) {
				// validasyonlar
				appMap.put("ANNE_KIZLIK_SOYADI", appMap.getString("ANNE_KIZLIK_SOYADI").toUpperCase());
				appMap.put("PERSON_ID", appMap.get("TC_KIMLIK_NO"));
				appMap.put("AKS_MUSTERI", GMServiceExecuter.execute("BNSPR_CUSTOMER_GET_MOTHER_MAIDEN_SURNAME", appMap).get("MOTHER_MAIDEN_SURNAME"));
				if (!StringUtils.isEmpty(appMap.getString("AKS_MUSTERI")) && !appMap.getString("ANNE_KIZLIK_SOYADI").equals(appMap.getString("AKS_MUSTERI").toUpperCase())) {
					throw new GMRuntimeException(0, "Anne kizlik soyadi hatali");
				}
			}

			sMap.put("KRD_TUR_KOD", appMap.getBigDecimal("KRD_TUR_KOD", new BigDecimal(1)));
			sMap.put("KAMP_URUN_ADI", appMap.getString("KAMP_KOD"));
			sMap.put("DOVIZ_KODU", appMap.getString("DOVIZ_KODU", "TRY"));
			sMap.put("KREDI_TUTARI", appMap.getBigDecimal("TUTAR"));
			sMap.put("KREDI_VADESI", appMap.getBigDecimal("VADE"));
			sMap.put("KANAL_KOD", appMap.getBigDecimal("KANAL_KOD", new BigDecimal(8)));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", sMap);

			sMap.put("TUTAR", appMap.getBigDecimal("TUTAR"));
			sMap.put("VADE", appMap.getBigDecimal("VADE"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", sMap));
			appMap.put("KAMP_KNL_KOD", sMap.get("KAMP_KNL_KOD"));

			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", sMap);

			sMap.put("DOVIZ_KOD", sMap.getString("DOVIZ_KODU"));
			sMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", sMap));
			sMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", sMap));
			appMap.put("FAIZ_ORANI", sMap.get("FAIZ_ORAN"));
			appMap.put("SOZLESME_FAIZI", sMap.get("SOZLESME_ORANI"));
			appMap.put("KATILIM_BEDELI", sMap.get("MAX_KATKI_PAYI"));
			appMap.put("DOSYA_MASRAFI", sMap.get("MAX_DOSYA_MASRAFI"));

			appMap.put("TRX_NO", iMap.get("TRX_NO"));
			appMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			if (!"H".equalsIgnoreCase(iMap.getString("VALIDASYON_EH"))) {
				GMServiceExecuter.executeNT("BNSPR_TRN3171_CONTROL", appMap);
			}else{
				appMap.put("EKRAN_NO", "3171");
				GMServiceExecuter.executeNT("BNSPR_TRN3171_SAVE_TEMP", appMap);
			}

			/** onay tutar guncelleme **/
			if (appMap.get("ONAY_TUTAR") != null && appMap.getBigDecimal("ONAY_TUTAR").compareTo(BigDecimal.ZERO) > 0) {
				Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				session.refresh(birBasvuru);
				birBasvuru.setOnayTutar(appMap.getBigDecimal("ONAY_TUTAR"));

				if (iMap.get("PRIM_TUTARI") != null) {
					birBasvuru.setBasvuruTeklifOnay("E");
					birBasvuru.setBasvuruTeklifTur("S");
					birBasvuru.setSigortaPrimi(iMap.getBigDecimal("PRIM_TUTARI"));
				}

				session.saveOrUpdate(birBasvuru);
				session.flush();
			}

			/** Debit kart talebi guncelleme **/
			if (!StringUtils.isEmpty(appMap.getString("TESLIMAT_ADRES_KOD"))) {
				Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
				BirBasvuruKartBilgi kartBilgi = (BirBasvuruKartBilgi) session.createCriteria(BirBasvuruKartBilgi.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				if (kartBilgi != null) {
					kartBilgi.setTeslimatAdresKod(appMap.getString("TESLIMAT_ADRES_KOD"));
					session.saveOrUpdate(kartBilgi);
					session.flush();
				}
			}

			// musteri guncelleme
			if (iMap.getBoolean("UPD_CUST")) {
				sMap.clear();
				sMap.putAll(appMap);
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sMap));
				sMap.put("TCK_NO", appMap.get("TC_KIMLIK_NO"));
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TCK_NO_GET_BAYI_BILGILERI", sMap));

				apsMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
				apsMap.put("TC_KIMLIK_NO", appMap.get("TC_KIMLIK_NO"));
				apsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_APS_SORGULAMA", apsMap));

				sMap.putAll(apsMap);
				sMap.put("ISIM", sMap.get("ADI"));
				sMap.put("IKINCI_ISIM", sMap.get("IKINCI_ADI"));
				sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
				sMap.put("CINSIYET_KOD", sMap.get("CINSIYET"));
				sMap.put("MEDENI_HAL_KOD", sMap.get("MEDENI_HAL"));
				sMap.put("AILE_SIRA_NO", sMap.get("NUFUS_AILE_SIRA_NO"));
				sMap.put("CILT_NO", sMap.get("NUFUS_CILT_NO"));
				sMap.put("SIRA_NO", sMap.get("NUFUS_SIRA_NO"));
				sMap.put("KIZLIK_SOYADI", sMap.get("ONCEKI_SOYADI"));
				sMap.put("MESLEK_KOD", sMap.get("MESLEK"));
				sMap.put("EGITIM_KOD", sMap.get("OGRENIM_DURUMU"));
				sMap.put("VERILDIGI_YER", sMap.get("NUF_VERILDIGI_YER"));
				sMap.put("VERILDIGI_TARIH", sMap.get("NUFUS_VERILIS_TARIHI"));
				sMap.put("EV_POSTA_KOD", sMap.get("EV_POSTA_KODU"));
				sMap.put("EV_ADRES", sMap.get("EV_ADRESI"));
				sMap.put("IS_POSTA_KOD", sMap.get("IS_POSTA_KODU"));
				sMap.put("IS_ADRES", sMap.get("IS_ADRESI"));
				sMap.put("MAHALLE_KOY", sMap.get("NUFUS_MAHALLE"));
				sMap.put("IL_KOD", sMap.get("NUFUS_IL_KOD"));
				sMap.put("ILCE_KOD", sMap.get("NUFUS_ILCE_KOD"));
				if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
					sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
				}
				else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
					sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
				}

				if (sMap.get("MUSTERI_NO") == null) {
					sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", sMap));
				}
				else {
					sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", sMap));
				}
			}
			GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE", appMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Web Kredi basvuru NBSM final degerlendirme servisi
	 * 
	 * @author mehmet.uluturk
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_FINAL_EVALUATION_API")
	public static GMMap finalEvaluationApplicationApi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		String keyword = "STANDART";
		GMMap pMap = new GMMap();
		
		try {
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3171_GET_MUSTERINO", iMap).get("MUSTERI_NO"));
			GnlMusteri musteri = (GnlMusteri) session.get(GnlMusteri.class, iMap.getBigDecimal("MUSTERI_NO"));
			session.refresh(musteri);
			iMap.put("MUSTERI_KONTAKT", musteri.getMusteriKontakt());

			GMMap appMap = new GMMap();
			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				appMap.putAll(iMap); // cm ekranindan imapte ayri ayri geliyor detay bilgiler..
			}
			else {
				appMap.putAll(iMap.getMap("APPLICATION_DETAIL"));
			}

			/** Adres bilgileri gelmiyorsa musteriden alinacak **/
			if (StringUtils.isEmpty(appMap.getString("EV_ADRESI")) && StringUtils.isEmpty(appMap.getString("IS_ADRESI"))) {
				GMMap addMap = new GMMap();
				addMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
				addMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_ADDRESS_LIST", addMap));
				appMap.put("YAZISMA_ADRESI_EV", false);
				appMap.put("YAZISMA_ADRESI_IS", false);
				for (int i = 0; i < addMap.getSize("RESULTS"); i++) {
					if ("E".equals(addMap.getString("RESULTS", i, "ADRES_TIPI"))) {
						appMap.put("EV_IL", addMap.get("RESULTS", i, "IL_KODU"));
						appMap.put("EV_ILCE", addMap.get("RESULTS", i, "ILCE_KODU"));
						appMap.put("EV_ADRESI", addMap.get("RESULTS", i, "ADRES"));
						appMap.put("YAZISMA_ADRESI_EV", GuimlUtil.convertToCheckBoxSelected(addMap.getString("RESULTS", i, "ILETISIM_ADRES_SECENEGI")));
					}
					else if ("I".equals(addMap.getString("RESULTS", i, "ADRES_TIPI"))) {
						appMap.put("IS_IL", addMap.get("RESULTS", i, "IL_KODU"));
						appMap.put("IS_ILCE", addMap.get("RESULTS", i, "ILCE_KODU"));
						appMap.put("IS_ADRESI", addMap.get("RESULTS", i, "ADRES"));
						appMap.put("ISYERI_ADI", addMap.get("RESULTS", i, "ISYERI_ADI"));
						appMap.put("YAZISMA_ADRESI_IS", GuimlUtil.convertToCheckBoxSelected(addMap.getString("RESULTS", i, "ILETISIM_ADRES_SECENEGI")));
					}
				}
				if (!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")) {
					appMap.put("YAZISMA_ADRESI_EV", true);
				}
			}
			if (StringUtils.isEmpty(appMap.getString("IS_TEL_NO"))) {
				GMMap telMap = new GMMap();
				telMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
				telMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_PHONE_LIST", telMap));
				for (int i = 0; i < telMap.getSize("RESULTS"); i++) {
					if ("2".equals(telMap.getString("RESULTS", i, "TEL_TIP"))) {
						appMap.put("IS_TEL_KOD", telMap.get("RESULTS", i, "ALAN_KODU"));
						appMap.put("IS_TEL_NO", telMap.get("RESULTS", i, "TELEFON_NO"));
						appMap.put("IS_TEL_DAHILI", telMap.get("RESULTS", i, "DAHILI_NO"));
					}
				}
			}
			iMap.put("APPLICATION_DETAIL", appMap);

			// basvuru guncelle
			if ("K".equals(iMap.getString("MUSTERI_KONTAKT"))) {
				if("E".equals(appMap.getString("MAAS_PTT_DENMI"))){
					iMap.put("AKSIYON_KARAR_KOD", "25"); // Ptt maas nedeniyle iptal
					oMap.putAll(GMServiceExecuter.execute("BNSPR_CL_WEB_CANCEL_APPLICATION", iMap));
					oMap.put("DURUM_KODU", "IPTAL");
					
					BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					
					/** Ptt emeklileri icin sms talep yaratilir **/
					pMap.put("MSISDN", "+90".concat(birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo())));
					pMap.put("NATIONAL_IDENTIFICATION_NUMBER", birBasvuruKimlik.getTcKimlikNo());
					pMap.put("CHANNEL", "WEB");
					GMServiceExecuter.call("BNSPR_CLKS_CONSUMERLOAN_SAVE_SMS_APPLICATION", pMap);
				}else{
					iMap.put("UPD_CUST", true);
					oMap.putAll(GMServiceExecuter.executeNT("BNSPR_CL_WEB_UPDATE_APPLICATION", iMap));
				}
			}
			else {
				/** Gercek musteri demektir. Musteri uzerinden bilgileri al.. **/
				appMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				GMMap mMap = GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", appMap);
				appMap.put("PERSON_ID", mMap.get("TC_KIMLIK_NO"));
				appMap.put("ANNE_KIZLIK_SOYADI", GMServiceExecuter.execute("BNSPR_CUSTOMER_GET_MOTHER_MAIDEN_SURNAME", appMap).get("MOTHER_MAIDEN_SURNAME"));
				appMap.put("KIMLIK_SERI_NO", mMap.getString("NUF_SERI_NO").substring(0, 3));
				appMap.put("KIMLIK_SIRA_NO", mMap.getString("NUF_SERI_NO").substring(3));

				if (iMap.getMap("APPLICATION_DETAIL").getString("CALISMA_SEKLI") != null) {
					appMap.put("CALISMA_SEKLI", iMap.getMap("APPLICATION_DETAIL").getString("CALISMA_SEKLI"));
				}
				else {
					appMap.put("CALISMA_SEKLI", mMap.get("CALISMA_SEKLI"));
				}

				if (iMap.getMap("APPLICATION_DETAIL").getString("OGRENIM_DURUMU") != null) {
					appMap.put("OGRENIM_DURUMU", iMap.getMap("APPLICATION_DETAIL").getString("OGRENIM_DURUMU"));
				}
				else {
					appMap.put("OGRENIM_DURUMU", mMap.get("EGITIM_KOD"));
				}

				if (iMap.getMap("APPLICATION_DETAIL").getString("MESLEK") != null) {
					appMap.put("MESLEK", iMap.getMap("APPLICATION_DETAIL").getString("MESLEK"));
				}
				else {
					appMap.put("MESLEK", mMap.get("MESLEK_KOD"));
				}

				appMap.put("AYLIK_GELIR", ConsumerLoanCommonServices.nvl(appMap.getString("AYLIK_GELIR"), "0"));
				appMap.put("ISYERINDE_CALISMA_SURESI_YIL", ConsumerLoanCommonServices.nvl(appMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), "1"));
				appMap.put("ISYERINDE_CALISMA_SURESI_AY", ConsumerLoanCommonServices.nvl(appMap.getString("ISYERINDE_CALISMA_SURESI_AY"), "1"));
				iMap.put("APPLICATION_DETAIL", appMap);

				/** eksik bilgi varsa g�ncelleme yap�lacak. **/
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_webkredi.musteri_eksik_bilgi_kontrol(?, ?)}");
				int pc = 1;
				stmt.setBigDecimal(pc++, iMap.getBigDecimal("MUSTERI_NO"));
				stmt.registerOutParameter(pc++, Types.VARCHAR);

				stmt.execute();

				String eksikBilgiEh = stmt.getString(2);

				if ("E".equals(eksikBilgiEh)) {
					iMap.put("UPD_CUST", true);
				}

				oMap.putAll(GMServiceExecuter.executeNT("BNSPR_CL_WEB_UPDATE_APPLICATION", iMap));
			}

			if (!"RED".equals(oMap.getString("DURUM_KODU")) && !"IPTAL".equals(oMap.getString("DURUM_KODU"))) {
				// nbsm call
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", iMap));
				
				if ("Y".equalsIgnoreCase(oMap.getString("SGK_BELGE_GEREKLI"))) {
					
					String cepTel = "";
					BirBasvuruKimlik kimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					cepTel = kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo());
					
					GMMap smsMap = new GMMap();
					GMMap getSmsMap = new GMMap();
					getSmsMap.put("P1", kimlik.getAd() + " " + kimlik.getSoyad());
					getSmsMap.put("P2", iMap.getBigDecimal("BASVURU_NO"));
					getSmsMap.put("MESSAGE_NO", new java.math.BigDecimal(5942));
					String mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", getSmsMap).get("ERROR_MESSAGE");

					smsMap.put("MSISDN", cepTel);
					smsMap.put("CONTENT", mesaj);
					smsMap.put("HEADER", "AktifBank");
					GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
				}

				/** KDH limit uretildiyse onayli on onay kaydi yaratiliyor.. **/
				if (oMap.get("KDH_LIMIT") != null && oMap.getBigDecimal("KDH_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					GMMap onOnayMap = new GMMap();
					onOnayMap.put("AKIS_TURU", "O");
					onOnayMap.put("KANAL_KOD", "81");
					onOnayMap.put("KREDI_TUR_KOD", "5");

					GMMap tMap = new GMMap();
					tMap.put("KOD", "KMH_ON_ONAY_PARAMS");
					tMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", tMap);

					onOnayMap.put("KAMPANYA_KOD", tMap.getBigDecimal("RESULTS", 2, "NAME"));
					onOnayMap.put("AKTARIM_NO", iMap.get("TRX_NO"));
					onOnayMap.put("AKTARIM_KANALI", "NKOLAY");
					onOnayMap.put("TC_KIMLIK_NO", oMap.get("TC_KIMLIK_NO"));
					onOnayMap.put("TUTAR", oMap.get("KDH_LIMIT"));
					onOnayMap.put("VADE", "1");
					onOnayMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					GMServiceExecuter.executeAsync("BNSPR_TRN8000_SAVE_ONAY", onOnayMap);
				}
			}

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if ("E".equals(oMap.getString("DEVAM"))) {
				oMap.put("KANAL_KODU", birBasvuru.getKanalKodu());
				oMap.put("VADE", birBasvuru.getVade());
				oMap.put("TUTAR", birBasvuru.getTutar());
				oMap.put("KANAL_KOD", birBasvuru.getKanalKodu());
				oMap.put("DOVIZ_KODU", "TRY");
				oMap.put("KREDI_TURU", birBasvuru.getKrediTur());

				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3113_KAMPANYA_BUL", oMap));

				if (oMap.get("MINI_KREDI_LIMIT") != null && oMap.getBigDecimal("MINI_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "MINI";
				}
				else if (oMap.get("UPSELL_KREDI_LIMIT") != null && oMap.getBigDecimal("UPSELL_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0 && oMap.get("NORMAL_KREDI_LIMIT") != null && oMap.getBigDecimal("NORMAL_KREDI_LIMIT").compareTo(birBasvuru.getTutar()) < 0) {
					keyword = "UPDOWNSELL";
				}
				else if (oMap.get("UPSELL_KREDI_LIMIT") != null && oMap.getBigDecimal("UPSELL_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "UPSELL";
				}
				else if (oMap.get("DUSUK_FAIZ_KREDI_LIMIT") != null && oMap.getBigDecimal("DUSUK_FAIZ_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "LOWINTEREST";
				}
				else if (oMap.get("KONSOLIDASYON_KREDI_LIMIT") != null && oMap.getBigDecimal("KONSOLIDASYON_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "CONSOLIDATION";
				}
				else if (oMap.get("SPOT_KREDI_LIMIT") != null && oMap.getBigDecimal("SPOT_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "SPOT";
				}
				else if (oMap.get("ONONAY_KREDI_LIMIT") != null && oMap.getBigDecimal("ONONAY_KREDI_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					keyword = "PREAPPROVED";
				}
				else if (oMap.get("NORMAL_KREDI_LIMIT") != null && oMap.getBigDecimal("NORMAL_KREDI_LIMIT").compareTo(birBasvuru.getTutar()) < 0) {
					keyword = "DOWNSELL";
				}

				oMap.put("KEYWORD", keyword);
			}
			else if(!"IPTAL".equals(oMap.getString("DURUM_KODU"))){
				// Red almas� durumunda mail g�nderilir.
				GMMap kimlikMap = new GMMap();
				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

				kimlikMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				kimlikMap.put("EMAIL_TO", birBasvuruKimlik.getEMail());
				if(new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())){
					kimlikMap.put("EMAIL_TYPE", "SPOT_SOBF");
				}else{
					kimlikMap.put("EMAIL_TYPE", "SOBF");
				}
				kimlikMap.put("EMAIL_NAME", (birBasvuruKimlik.getAd() + (birBasvuruKimlik.getIkinciAd() != null ? " " + birBasvuruKimlik.getIkinciAd() : " ")).trim());
				kimlikMap.put("EMAIL_SURNAME", birBasvuruKimlik.getSoyad());
				kimlikMap.put("BELGE_KODU", "543");
				kimlikMap.put("SEND_ATTACHMENTS", true);

				GMServiceExecuter.execute("BNSPR_CL_CC_SAVE_BEFORE_AGGREMENT_DOCUMENT", kimlikMap);
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	/**
	 * Web Kredi basvuru NBSM final degerlendirme servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_FINAL_EVALUATION")
	public static GMMap finalEvaluationApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3171_GET_MUSTERINO", iMap).get("MUSTERI_NO"));
			iMap.put("MUSTERI_KONTAKT", GMServiceExecuter.execute("BNSPR_CUST_GET_MUSTERIMI_KONTAKMI", iMap).get("KONTAK_MUSTERI"));

			GMMap appMap = new GMMap();
			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				appMap.putAll(iMap); // cm ekranindan imapte ayri ayri geliyor detay bilgiler..
			}
			else {
				appMap.putAll(iMap.getMap("APPLICATION_DETAIL"));
			}

			/** Adres bilgileri gelmiyorsa musteriden alinacak **/
			if (StringUtils.isEmpty(appMap.getString("EV_ADRESI")) && StringUtils.isEmpty(appMap.getString("IS_ADRESI"))) {
				GMMap addMap = new GMMap();
				addMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
				addMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_ADDRESS_LIST", addMap));
				appMap.put("YAZISMA_ADRESI_EV", false);
				appMap.put("YAZISMA_ADRESI_IS", false);
				for (int i = 0; i < addMap.getSize("RESULTS"); i++) {
					if ("E".equals(addMap.getString("RESULTS", i, "ADRES_TIPI"))) {
						appMap.put("EV_IL", addMap.get("RESULTS", i, "IL_KODU"));
						appMap.put("EV_ILCE", addMap.get("RESULTS", i, "ILCE_KODU"));
						appMap.put("EV_ADRESI", addMap.get("RESULTS", i, "ADRES"));
						appMap.put("YAZISMA_ADRESI_EV", GuimlUtil.convertToCheckBoxSelected(addMap.getString("RESULTS", i, "ILETISIM_ADRES_SECENEGI")));
					}
					else if ("I".equals(addMap.getString("RESULTS", i, "ADRES_TIPI"))) {
						appMap.put("IS_IL", addMap.get("RESULTS", i, "IL_KODU"));
						appMap.put("IS_ILCE", addMap.get("RESULTS", i, "ILCE_KODU"));
						appMap.put("IS_ADRESI", addMap.get("RESULTS", i, "ADRES"));
						appMap.put("ISYERI_ADI", addMap.get("RESULTS", i, "ISYERI_ADI"));
						appMap.put("YAZISMA_ADRESI_IS", GuimlUtil.convertToCheckBoxSelected(addMap.getString("RESULTS", i, "ILETISIM_ADRES_SECENEGI")));
					}
				}
				if (!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")) {
					appMap.put("YAZISMA_ADRESI_EV", true);
				}
			}
			if (StringUtils.isEmpty(appMap.getString("IS_TEL_NO"))) {
				GMMap telMap = new GMMap();
				telMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
				telMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_PHONE_LIST", telMap));
				for (int i = 0; i < telMap.getSize("RESULTS"); i++) {
					if ("2".equals(telMap.getString("RESULTS", i, "TEL_TIP"))) {
						appMap.put("IS_TEL_KOD", telMap.get("RESULTS", i, "ALAN_KODU"));
						appMap.put("IS_TEL_NO", telMap.get("RESULTS", i, "TELEFON_NO"));
						appMap.put("IS_TEL_DAHILI", telMap.get("RESULTS", i, "DAHILI_NO"));
					}
				}
			}
			iMap.put("APPLICATION_DETAIL", appMap);

			// basvuru guncelle
			if ("K".equals(iMap.getString("MUSTERI_KONTAKT"))) {
				iMap.put("UPD_CUST", true);
				oMap.putAll(GMServiceExecuter.executeNT("BNSPR_CL_WEB_UPDATE_APPLICATION", iMap));
			}
			else {
				/** Gercek musteri demektir. Musteri uzerinden bilgileri al.. **/
				appMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				GMMap mMap = GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", appMap);
				appMap.put("PERSON_ID", mMap.get("TC_KIMLIK_NO"));
				appMap.put("ANNE_KIZLIK_SOYADI", GMServiceExecuter.execute("BNSPR_CUSTOMER_GET_MOTHER_MAIDEN_SURNAME", appMap).get("MOTHER_MAIDEN_SURNAME"));
				appMap.put("KIMLIK_SERI_NO", mMap.getString("NUF_SERI_NO").substring(0, 3));
				appMap.put("KIMLIK_SIRA_NO", mMap.getString("NUF_SERI_NO").substring(3));

				if (iMap.getMap("APPLICATION_DETAIL").getString("CALISMA_SEKLI") != null) {
					appMap.put("CALISMA_SEKLI", iMap.getMap("APPLICATION_DETAIL").getString("CALISMA_SEKLI"));
				}
				else {
					appMap.put("CALISMA_SEKLI", mMap.get("CALISMA_SEKLI"));
				}

				if (iMap.getMap("APPLICATION_DETAIL").getString("OGRENIM_DURUMU") != null) {
					appMap.put("OGRENIM_DURUMU", iMap.getMap("APPLICATION_DETAIL").getString("OGRENIM_DURUMU"));
				}
				else {
					appMap.put("OGRENIM_DURUMU", mMap.get("EGITIM_KOD"));
				}

				if (iMap.getMap("APPLICATION_DETAIL").getString("MESLEK") != null) {
					appMap.put("MESLEK", iMap.getMap("APPLICATION_DETAIL").getString("MESLEK"));
				}
				else {
					appMap.put("MESLEK", mMap.get("MESLEK_KOD"));
				}

				appMap.put("AYLIK_GELIR", ConsumerLoanCommonServices.nvl(appMap.getString("AYLIK_GELIR"), "0"));
				appMap.put("ISYERINDE_CALISMA_SURESI_YIL", ConsumerLoanCommonServices.nvl(appMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), "1"));
				appMap.put("ISYERINDE_CALISMA_SURESI_AY", ConsumerLoanCommonServices.nvl(appMap.getString("ISYERINDE_CALISMA_SURESI_AY"), "1"));
				iMap.put("APPLICATION_DETAIL", appMap);

				/** eksik bilgi varsa g�ncelleme yap�lacak. **/
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_webkredi.musteri_eksik_bilgi_kontrol(?, ?)}");
				int pc = 1;
				stmt.setBigDecimal(pc++, iMap.getBigDecimal("MUSTERI_NO"));
				stmt.registerOutParameter(pc++, Types.VARCHAR);

				stmt.execute();

				String eksikBilgiEh = stmt.getString(2);

				if ("E".equals(eksikBilgiEh)) {
					iMap.put("UPD_CUST", true);
				}

				oMap.putAll(GMServiceExecuter.executeNT("BNSPR_CL_WEB_UPDATE_APPLICATION", iMap));
			}

			if (!"RED".equals(oMap.getString("DURUM_KODU"))) {
				// nbsm call
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", iMap));

				/** KDH limit uretildiyse onayli on onay kaydi yaratiliyor.. **/
				if (oMap.get("KDH_LIMIT") != null && oMap.getBigDecimal("KDH_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					GMMap onOnayMap = new GMMap();
					onOnayMap.put("AKIS_TURU", "O");
					onOnayMap.put("KANAL_KOD", "81");
					onOnayMap.put("KREDI_TUR_KOD", "5");

					GMMap tMap = new GMMap();
					tMap.put("KOD", "KMH_ON_ONAY_PARAMS");
					tMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", tMap);

					onOnayMap.put("KAMPANYA_KOD", tMap.getBigDecimal("RESULTS", 2, "NAME"));
					onOnayMap.put("AKTARIM_NO", iMap.get("TRX_NO"));
					onOnayMap.put("AKTARIM_KANALI", "NKOLAY");
					onOnayMap.put("TC_KIMLIK_NO", oMap.get("TC_KIMLIK_NO"));
					onOnayMap.put("TUTAR", oMap.get("KDH_LIMIT"));
					onOnayMap.put("VADE", "1");
					onOnayMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					GMServiceExecuter.executeAsync("BNSPR_TRN8000_SAVE_ONAY", onOnayMap);
				}
			}

			GMMap pMap = new GMMap();
			pMap.put("PARAMETRE", "WEBKREDI_UPSELL_VADE");
			oMap.put("UPSELL_VADE", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", pMap).getInt("DEGER"));

			pMap.putAll(ConsumerLoanCommonServices.getParamTextLists("MINI_KREDI_KAMPANYA", "RESULTS"));

			oMap.put("MINI_KREDI_TUTAR", pMap.get("RESULTS", 1, "DESCRIPTION"));
			oMap.put("MINI_KREDI_VADE", pMap.get("RESULTS", 2, "DESCRIPTION"));
			oMap.put("MINI_KREDI_KAMPANYA_KODU", pMap.get("RESULTS", 0, "DESCRIPTION"));

			/** aylik taksit bilgileri **/
			if ("E".equals(oMap.getString("DEVAM"))) {
				if (oMap.get("ONAY_TUTAR") != null && oMap.getBigDecimal("ONAY_TUTAR").compareTo(BigDecimal.ZERO) > 0) {
					oMap.putAll(iMap);
					oMap.putAll(GMServiceExecuter.execute("BNSPR_CL_WEB_TAKSIT_BILGI", oMap));
				}
			}
			else {
				// Red almas� durumunda mail g�nderilir.
				GMMap kimlikMap = new GMMap();
				Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

				kimlikMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				kimlikMap.put("EMAIL_TO", birBasvuruKimlik.getEMail());
				if(new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())){
					kimlikMap.put("EMAIL_TYPE", "SPOT_SOBF");
				}else{
					kimlikMap.put("EMAIL_TYPE", "SOBF");
				}
				kimlikMap.put("EMAIL_NAME", (birBasvuruKimlik.getAd() + (birBasvuruKimlik.getIkinciAd() != null ? " " + birBasvuruKimlik.getIkinciAd() : " ")).trim());
				kimlikMap.put("EMAIL_SURNAME", birBasvuruKimlik.getSoyad());
				kimlikMap.put("BELGE_KODU", "543");

				GMServiceExecuter.execute("BNSPR_CL_CC_SAVE_BEFORE_AGGREMENT_DOCUMENT", kimlikMap);
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_WEB_GET_SIMULATION_INFO")
	public static GMMap getSimulationInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_webkredi.get_simulation_latency_info(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
			int pc = 1;
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMPANYA_KODU"));
			stmt.setInt(pc++, iMap.getInt("TAKSIT_GUNU"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KREDI_TUTARI"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ODEME_TIP_KOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ODEME_TIP_VADE"));
			stmt.setString(pc++, iMap.getString("AY_SONU"));
			stmt.registerOutParameter(pc++, Types.INTEGER); // pn_fark_faizi
			stmt.registerOutParameter(pc++, Types.INTEGER); // pn_faiz_odeme_sekli
			stmt.registerOutParameter(pc++, Types.INTEGER); // pn_gecikme_gun_sayisi

			stmt.execute();

			oMap.put("FARK_FAIZI", stmt.getBigDecimal(8));
			oMap.put("FAIZ_ODEME_SEKLI", stmt.getBigDecimal(9));
			oMap.put("GECIKME_GUN_SAYISI", stmt.getBigDecimal(10));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
		
	}
	
	@GraymoundService("BNSPR_CL_WEB_GET_AGREEMENT_INFO")
	public static GMMap getAgreementInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_webkredi.get_agreement_info(?, ?, ?, ?, ?)}");
			int pc = 1;
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setInt(pc++, iMap.getInt("TAKSIT_GUNU"));
			stmt.registerOutParameter(pc++, Types.INTEGER); // pn_fark_faizi
			stmt.registerOutParameter(pc++, Types.INTEGER); // pn_faiz_odeme_sekli
			stmt.registerOutParameter(pc++, Types.INTEGER); // pn_gecikme_gun_sayisi

			stmt.execute();

			oMap.put("FARK_FAIZ", stmt.getBigDecimal(3));
			oMap.put("FAIZ_ODEME_SEKLI", stmt.getBigDecimal(4));
			oMap.put("GECIKME_GUN_SAYISI", stmt.getBigDecimal(5));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
		
	}

	/**
	 * Web Kredi basvuru sozlesmesi kayit yaratan servis
	 * 
	 * @author mehmet.uluturk
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CREATE_AGREEMENT_API")
	public static GMMap createAggrementApi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		String agreementXml = null;
		try {
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO", iMap));

			oMap.put("CALISMA_SEKLI_KOD", sMap.get("CALISMA_SEKLI_KOD"));
			oMap.put("TBL_BELGE", sMap.get("TBL_BELGE"));

			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			sMap.put("TRX_NO", iMap.get("TRX_NO"));
			sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sMap.put("EKRAN_NO", "3181");
			if (iMap.containsKey("TAKSIT_GUNU")) {
				sMap.put("TAKSIT_GUNU", iMap.get("TAKSIT_GUNU"));
				sMap.put("AY_SONU", iMap.get("AY_SONU"));
				sMap.put("FAIZ_ODEME_SEKLI", iMap.get("FAIZ_ODEME_SEKLI"));
				sMap.put("GECIKME_GUN_SAYISI", iMap.get("GECIKME_GUN_SAYISI"));
			}
			else if ("8".equals(sMap.getString("ODEME_TIPI"))) {
				Calendar c = Calendar.getInstance();
				c.setTime(new Date());
				c.add(Calendar.DATE, sMap.getInt("ODEME_VADESI"));
				sMap.put("TAKSIT_GUNU", c.get(Calendar.DAY_OF_MONTH));
			}
			else {
				if(sMap.get("TAKSIT_GUNU") == null){
					sMap.put("TAKSIT_GUNU", Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
				}else{
					sMap.putAll(GMServiceExecuter.execute("BNSPR_CL_WEB_GET_AGREEMENT_INFO", sMap));
				}
			}
			
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_SAVE", sMap));

			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				String dokListeAdi = "";
				for (int index = 0; index < oMap.getSize("TBL_BELGE"); index++) {
					dokListeAdi += oMap.getString("TBL_BELGE", index, "BELGE_ADI");
					if (index < oMap.getSize("TBL_BELGE")) {
						dokListeAdi += ", ";
					}
				}
				oMap.put("DOKUMAN_LISTE_ADI", dokListeAdi);
			}
			else {
				agreementXml = WebCreditDocument.generateAllXml(iMap.getString("BASVURU_NO"));
				for (int index = 0; index < oMap.getSize("TBL_BELGE"); index++) {
					oMap.put("TBL_BELGE", index, "XML", agreementXml);
				}
			}

			oMap.put("TRX_NO", sMap.get("TRX_NO"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Web Kredi basvuru sozlesmesi kayit yaratan servis
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CREATE_AGREEMENT")
	public static GMMap createAggrement(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO", iMap));

			oMap.put("CALISMA_SEKLI_KOD", sMap.get("CALISMA_SEKLI_KOD"));
			oMap.put("TBL_BELGE", sMap.get("TBL_BELGE"));

			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			sMap.put("TRX_NO", iMap.get("TRX_NO"));
			sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sMap.put("EKRAN_NO", "3181");
			if (iMap.containsKey("TAKSIT_GUNU")) {
				sMap.put("TAKSIT_GUNU", iMap.get("TAKSIT_GUNU"));
				sMap.put("AY_SONU", iMap.get("AY_SONU"));
				sMap.put("FAIZ_ODEME_SEKLI", iMap.get("FAIZ_ODEME_SEKLI"));
				sMap.put("GECIKME_GUN_SAYISI", iMap.get("GECIKME_GUN_SAYISI"));
			}
			else {
				sMap.put("TAKSIT_GUNU", Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
			}

			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_SAVE", sMap));

			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				String dokListeAdi = "";
				for (int index = 0; index < oMap.getSize("TBL_BELGE"); index++) {
					dokListeAdi += oMap.getString("TBL_BELGE", index, "BELGE_ADI");
					if (index < oMap.getSize("TBL_BELGE")) {
						dokListeAdi += ", ";
					}
				}
				oMap.put("DOKUMAN_LISTE_ADI", dokListeAdi);
			}
			else {
				for (int index = 0; index < oMap.getSize("TBL_BELGE"); index++) {
					int documentCode = oMap.getInt("TBL_BELGE", index, "BELGE_KODU");
					WebCreditDocument creditDocument = DocumentCreator.createWebCreditDocument(documentCode);
					oMap.put("TBL_BELGE", index, "XML", creditDocument.generateXml(iMap.getString("BASVURU_NO"), null));
				}
			}

			oMap.put("TRX_NO", sMap.get("TRX_NO"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CL_WEB_SAVE_AGREEMENT_DOCUMENTS_API")
	public static GMMap saveAggrementDocumentsApi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.get("KANAL_KODU") == null) {
				iMap.put("KANAL_KODU", "8");
			}
			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				for (int i = 0; i < iMap.getSize("TBL_BELGE"); i++) {
					iMap.put("TBL_BELGE", i, "ALINDI", true);
				}
			}
			GMMap sMap = new GMMap();
			sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sMap.put("TRX_NO", iMap.get("TRX_NO"));
			sMap.put("TBL_BELGE", iMap.get("TBL_BELGE"));
			sMap.put("BELGE_KONTROL", true);
			sMap.put("TEYIT_GEREKLI", false);
			sMap.put("CALISMA_SEKLI_KOD", iMap.get("CALISMA_SEKLI_KOD"));
			sMap.put("KANAL_KODU", iMap.getString("KANAL_KODU", "8"));
			sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", sMap));

			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			session.refresh(birBasvuru);
			
			String cerceveSozlesmeEh = "H";

			if (birBasvuru.getTcKimlikNo() != null && !birBasvuru.getTcKimlikNo().isEmpty() && "P2D".equalsIgnoreCase(iMap.getString("PROCESS_TYPE"))) {
				GMMap cMap = new GMMap();
				cMap.put("UYRUK", "TR");
				cMap.put("SOURCE", "WEBKREDI");
				cMap.put("SORGU_TIPI", "P2D");
				cMap.put("TFF_BASVURU_NO", iMap.get("TFF_APPLICATION_NO"));
				cMap.put("KK_BASVURU_NO", iMap.get("KK_APPLICATION_NO"));
				cMap.put("TCKN", birBasvuru.getTcKimlikNo());
				cMap.putAll(GMServiceExecuter.call("BNSPR_KART_DOKUMAN_ALINDI_MI_BY_KANAL", cMap));

				cerceveSozlesmeEh = cMap.getString("ANINDA_DONUSUM", "H");
			}

			/** Kart talebini guncelle **/
			if (iMap.get("PROCESS_TYPE") != null) {
				GMMap cMap = new GMMap();
				cMap.put("PROCESS_TYPE", iMap.get("PROCESS_TYPE"));
				cMap.put("CL_APPLICATION_NO", iMap.get("BASVURU_NO"));
				cMap.put("TFF_APPLICATION_NO", iMap.get("TFF_APPLICATION_NO"));
				cMap.put("KK_APPLICATION_NO", iMap.get("KK_APPLICATION_NO"));
				cMap.put("CARD_NO", iMap.get("CARD_NO"));
				if ("DOGRULAMA".equals(birBasvuru.getDurumKodu())) {
					cMap.put("DURUM_KOD", new BigDecimal(-1));
				}
				else {
					cMap.put("DURUM_KOD", BigDecimal.ZERO);
				}
				cMap.put("ONAY_FLAG", "TRUE");
				GMServiceExecuter.execute("BNSPR_CL_CREATE_DEBIT_CARD_REQUEST", cMap);
			}

			oMap.put("CERCEVE_SOZLESME_EH", cerceveSozlesmeEh);

			sMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());

			GnlMusteri musteri = (GnlMusteri) session.get(GnlMusteri.class, birBasvuru.getMusteriNo());
			session.refresh(musteri);
			
			/** oto kul kontrol **/
			String [] otoKulSaat = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "WEBKREDI_OTOKUL_CUTOFF_SAAT")).getString("DEGER").split(":");
			Calendar c = Calendar.getInstance();
			c.set(Calendar.HOUR_OF_DAY, Integer.valueOf(otoKulSaat[0]));
			c.set(Calendar.MINUTE, Integer.valueOf(otoKulSaat[1]));

			sMap.put("MUSTERI_KONTAKT", musteri.getMusteriKontakt());
			sMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", sMap));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_CL_KART_BHS_KONTROL", sMap));
			if ("M".equals(sMap.getString("MUSTERI_KONTAKT")) && ("E".equals(sMap.getString("F_BHS")) || "E".equals(sMap.getString("KK_BHS"))) && Calendar.getInstance().before(c)) {
				if ("KUL".equals(birBasvuru.getDurumKodu())) {
					// kullandir..
					GMMap kMap = new GMMap();
					kMap.put("TRX_ONAYSIZ_ISLEM", "E");
					kMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					kMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
					kMap.put("MUSTERI_KONTAKT", "M");
					kMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_OTOMATIK_KULLANDIR", kMap));
					session.refresh(birBasvuru);
				}
			}
			else {
				// basvuru tamamlanma sms i atilacak..
				if (iMap.get("PROCESS_TYPE") != null && !"DOGRULAMA".equals(birBasvuru.getDurumKodu())) {
					String mesaj = "";
					String cepTel = "";
					BirBasvuruKimlik kimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					cepTel = kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo());
					iMap.put("P1", kimlik.getAd());
					iMap.put("P2", birBasvuru.getOnayTutar());
					if ("P".equals(iMap.getString("PROCESS_TYPE"))) {
						iMap.put("MESSAGE_NO", new java.math.BigDecimal(5235));
					}
					else {
						if(new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())) {
							iMap.put("MESSAGE_NO", new java.math.BigDecimal(6173));
						}else{
							iMap.put("MESSAGE_NO", new java.math.BigDecimal(5232));
						}
					}
					mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
					if (!"".equals(cepTel) && !"".equals(mesaj)) {
						GMMap smsMap = new GMMap();
						if(new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())) {
							smsMap.put("HEADER", ".NKOLAY");
						}else{
							smsMap.put("HEADER", "AktifBank");
						}
						smsMap.put("MSISDN", cepTel);
						smsMap.put("CONTENT", mesaj);
						GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
					}
				}
			}

			/** Sozlesme Basildi Yap **/
			GMServiceExecuter.execute("BNSPR_TRN3181_SOZLEZME_BASIM_EH", iMap);

			/** Mail gonder **/
			GMMap dMap = new GMMap();
			GMMap eMap = new GMMap();
			dMap.put("APPLICATION_NO", iMap.get("BASVURU_NO"));
			if ("DOGRULAMA".equals(birBasvuru.getDurumKodu())) {
				
				dMap.put("MAIL_TRANSFER", false);
				/*
				GMMap smsMap = new GMMap();
				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				iMap.put("MESSAGE_NO", new java.math.BigDecimal(5545));
				iMap.put("P1", birBasvuruKimlik.getSoyad());
				iMap.put("P2", birBasvuru.getBasvuruNo());
				String mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
				if (!"".equals(birBasvuruKimlik.getCepTelNo()) && !"".equals(mesaj)) {
					smsMap.put("MSISDN", birBasvuruKimlik.getCepTelAlanKodu() + birBasvuruKimlik.getCepTelNo());
					smsMap.put("CONTENT", mesaj);

					GMServiceExecuter.call("BNSPR_SMS_SEND_SMS", smsMap);
				}
				*/
			}
			else {
				dMap.put("MAIL_TRANSFER", true);
			}
			dMap.put("DYS_TRANSFER", true);
			dMap.put("EMAIL_TO", iMap.get("EMAIL_TO"));
			dMap.put("EMAIL_NAME", iMap.get("EMAIL_NAME"));
			dMap.put("EMAIL_SURNAME", iMap.get("EMAIL_SURNAME"));
			dMap.put("EMAIL_CARD_NO", iMap.get("EMAIL_CARD_NO"));

			if ("E".equalsIgnoreCase(cerceveSozlesmeEh)) {
				dMap.put("EMAIL_TYPE", "PP_CS");
			}else if(new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())){
				if (iMap.get("PROCESS_TYPE") != null) {
					dMap.put("EMAIL_TYPE", "SPOT_KURYE");
				}
				else {
					dMap.put("EMAIL_TYPE", "SPOT_KK");
				}
				BirKampanya kampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", birBasvuru.getKampKod())).uniqueResult();
				dMap.put("ODEMESIZ_SURE", kampanya.getFaizsizSure());
				dMap.put("SPOT_VADE", birBasvuru.getOdemeTipVade());
			}
			else {
				dMap.put("EMAIL_TYPE", iMap.get("EMAIL_TYPE"));
			}

			int k = 0;
			boolean sobfVarMi = false;
			eMap.putAll(dMap);

			for (int i = 0; i < iMap.getSize("TBL_BELGE"); i++) {
				if ("543".equals(iMap.get("TBL_BELGE", i, "BELGE_KODU"))) {
					sobfVarMi = true;
					eMap.put("DOC_LIST", 0, "CODE", Enums.CreditDocTypes.BEFORE_AGGREEMENT.getCode());
				}
				else if (!"582".equals(iMap.get("TBL_BELGE", i, "BELGE_KODU"))) {
					dMap.put("DOC_LIST", k, "CODE", iMap.get("TBL_BELGE", i, "BELGE_KODU"));
					k++;
				}
			}
			GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
			if (sobfVarMi) {
				
				// M��teriye gidecek mailde ad,soyad gibi alanlar g�z�kmeyecek
				HashMap<String, Object> parameters = new HashMap<String, Object>();
				
				parameters.put("KISISEL_BILGI_GIZLE_EH", "E");
				eMap.put("PARAMETERS", parameters);
				
				eMap.put("DYS_TRANSFER", false);
				eMap.put("SEND_ATTACHMENTS", true);
				GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", eMap);
				
				// DYS'ye at�lacak dok�manda t�m bilgiler yer alacak 
				eMap.put("DYS_TRANSFER", true);
				eMap.put("MAIL_TRANSFER", false);
				parameters.clear();
				eMap.put("PARAMETERS", parameters);
				GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", eMap);
			}

			oMap.put("DURUM_KODU", birBasvuru.getDurumKodu());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Web Kredi basvuru sozlesme belgelerini kaydeden servis
	 * TRX_NO zorunludur. Create_agreement servisinden donen trx_no iletilmelidir.
	 * TBL_BELGE.ALINDI true/false olarak gonderilmelidir.
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_SAVE_AGREEMENT_DOCUMENTS")
	public static GMMap saveAggrementDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.get("KANAL_KODU") == null) {
				iMap.put("KANAL_KODU", "8");
			}
			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				for (int i = 0; i < iMap.getSize("TBL_BELGE"); i++) {
					iMap.put("TBL_BELGE", i, "ALINDI", true);
				}
			}
			GMMap sMap = new GMMap();
			sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sMap.put("TRX_NO", iMap.get("TRX_NO"));
			sMap.put("TBL_BELGE", iMap.get("TBL_BELGE"));
			sMap.put("BELGE_KONTROL", true);
			sMap.put("TEYIT_GEREKLI", false);
			sMap.put("CALISMA_SEKLI_KOD", iMap.get("CALISMA_SEKLI_KOD"));
			sMap.put("KANAL_KODU", iMap.getString("KANAL_KODU", "8"));
			sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", sMap));

			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			sMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
			sMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", sMap));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_CL_KART_BHS_KONTROL", sMap));
			if ("M".equals(iMap.getString("MUSTERI_KONTAKT")) && ("E".equals(sMap.getString("F_BHS")) || "E".equals(sMap.getString("KK_BHS")))) {
				if ("KUL".equals(birBasvuru.getDurumKodu())) {
					// kullandir..
					GMMap kMap = new GMMap();
					kMap.put("TRX_ONAYSIZ_ISLEM", "E");
					kMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					kMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
					kMap.put("MUSTERI_KONTAKT", "M");
					kMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_OTOMATIK_KULLANDIR", kMap));
				}
			}
			else {
				// basvuru tamamlanma sms i atilacak..
				if (iMap.get("PROCESS_TYPE") != null && !"DOGRULAMA".equals(birBasvuru.getDurumKodu())) {
					String mesaj = "";
					String cepTel = "";
					BirBasvuruKimlik kimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					cepTel = kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo());
					iMap.put("P1", kimlik.getAd());
					iMap.put("P2", birBasvuru.getOnayTutar());
					if ("P".equals(iMap.getString("PROCESS_TYPE"))) {
						iMap.put("MESSAGE_NO", new java.math.BigDecimal(5235));
					}
					else {
						iMap.put("MESSAGE_NO", new java.math.BigDecimal(5232));
					}
					mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
					if (!"".equals(cepTel) && !"".equals(mesaj)) {
						GMMap smsMap = new GMMap();
						smsMap.put("MSISDN", cepTel);
						smsMap.put("CONTENT", mesaj);
						GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
					}
				}
			}

			/** Sozlesme Basildi Yap **/
			GMServiceExecuter.execute("BNSPR_TRN3181_SOZLEZME_BASIM_EH", iMap);

			/** Mail gonder **/
			GMMap dMap = new GMMap();
			dMap.put("APPLICATION_NO", iMap.get("BASVURU_NO"));
			if ("M".equals(iMap.getString("MUSTERI_KONTAKT")) && "DOGRULAMA".equals(birBasvuru.getDurumKodu())) {
				dMap.put("MAIL_TRANSFER", false);
			}
			else {
				dMap.put("MAIL_TRANSFER", true);
			}
			dMap.put("DYS_TRANSFER", true);
			dMap.put("EMAIL_TO", iMap.get("EMAIL_TO"));
			dMap.put("EMAIL_TYPE", iMap.get("EMAIL_TYPE"));
			dMap.put("EMAIL_NAME", iMap.get("EMAIL_NAME"));
			dMap.put("EMAIL_SURNAME", iMap.get("EMAIL_SURNAME"));
			dMap.put("EMAIL_CARD_NO", iMap.get("EMAIL_CARD_NO"));
			int k = 0;
			for (int i = 0; i < iMap.getSize("TBL_BELGE"); i++) {
				if (!"582".equals(iMap.get("TBL_BELGE", i, "BELGE_KODU"))) {
					dMap.put("DOC_LIST", k, "CODE", iMap.get("TBL_BELGE", i, "BELGE_KODU"));
					k++;
				}
			}
			GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);

			/** Kart talebini guncelle **/
			if (iMap.get("PROCESS_TYPE") != null) {
				GMMap cMap = new GMMap();
				cMap.put("PROCESS_TYPE", iMap.get("PROCESS_TYPE"));
				cMap.put("CL_APPLICATION_NO", iMap.get("BASVURU_NO"));
				cMap.put("TFF_APPLICATION_NO", iMap.get("TFF_APPLICATION_NO"));
				cMap.put("KK_APPLICATION_NO", iMap.get("KK_APPLICATION_NO"));
				cMap.put("CARD_NO", iMap.get("CARD_NO"));
				if ("DOGRULAMA".equals(birBasvuru.getDurumKodu())) {
					cMap.put("DURUM_KOD", new BigDecimal(-1));
				}
				else {
					cMap.put("DURUM_KOD", BigDecimal.ZERO);
				}
				cMap.put("ONAY_FLAG", "TRUE");
				GMServiceExecuter.executeAsync("BNSPR_CL_CREATE_DEBIT_CARD_REQUEST", cMap);
			}
			oMap.put("DURUM_KODU", birBasvuru.getDurumKodu());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CL_WEB_GET_DOCUMENT_TEMPLATES")
	public static GMMap getDocumentTemplates(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			List<CreditDocTypes> list = Arrays.asList(CreditDocTypes.values());
			int i = 0;
			for (CreditDocTypes creditDocTypes : list) {
				if ("WEB".equals(creditDocTypes.getType())) {
					oMap.put("DOC_LIST", i, "CODE", creditDocTypes.getCode());
					WebCreditDocument creditDocument = DocumentCreator.createWebCreditDocument(creditDocTypes.getCode());
					iMap.put("FOLDER_NAME", creditDocument.getFolderName());
					iMap.put("TEMPLATE_NAME", creditDocument.getTemplateName());
					oMap.put("DOC_LIST", i, "TEMPLATE", GMServiceExecuter.call("BNSPR_GET_DOCUMENT_TEMPLATE", iMap).get("XSL"));
					i++;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CL_WEB_GET_DEBIT_DOCUMENTS_DATA")
	public static GMMap getDebitDocumentsData(GMMap iMap) {
		GMMap oMap = new GMMap();
		String kartTipi = "";
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuruKartBilgi kartBilgi = (BirBasvuruKartBilgi) session.createCriteria(BirBasvuruKartBilgi.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			if (kartBilgi != null) {
				kartTipi = kartBilgi.getKartTipi();
			}
			List<CreditDocTypes> list = Arrays.asList(CreditDocTypes.values());
			int i = 0;
			int dokumanKod;
			for (CreditDocTypes creditDocTypes : list) {
				dokumanKod = creditDocTypes.getCode();
				if (dokumanKod == CreditDocTypes.CREDIT_CARD_INFO.getCode() || (dokumanKod == CreditDocTypes.PRODUCT_INFO.getCode() && "P".equals(kartTipi))) {
					WebCreditDocument creditDocument = DocumentCreator.createWebCreditDocument(dokumanKod);
					oMap.put("DOC_LIST", i, "CODE", dokumanKod);
					oMap.put("DOC_LIST", i, "NAME", getDocumentName(dokumanKod));
					oMap.put("DOC_LIST", i, "XML", creditDocument.generateXml(iMap.getString("BASVURU_NO"), null));
					i++;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	public static String getDocumentName(int documentCode) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareStatement("SELECT ACIKLAMA FROM v_ml_gnl_dokuman_kod_pr WHERE KOD = ?");
			stmt.setString(1, String.valueOf(documentCode));
			rSet = stmt.executeQuery();

			if (rSet.next()) {
				return rSet.getString(1);
			}
			throw new GMRuntimeException(0, "Gecersiz Dokuman Kodu!");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static GMMap sigortaPrimiHesapla(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_webkredi.sigorta_primi_hesapla(?, ?, ?, ?)}");
			int pc = 1;
			stmt.registerOutParameter(pc++, Types.DECIMAL);
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMP_KOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("VADE"));

			stmt.execute();
			oMap.put("PRIM_TUTARI", stmt.getBigDecimal(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CL_PROPOSE_CREDIT_LIFE")
	public static GMMap proposeCreditLife(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap odMap = new GMMap();
		GMMap odrMap = new GMMap();
		GMMap sMap = new GMMap();
		GMMap apsMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			sMap.put("APPLICATION_CODE", "BANKASURANS");
			sMap.put("START_DATE", DateUtil.formatDate(new Date(), "yyyyMMdd"));
			sMap.put("PRODUCT_CODE", 665);
			sMap.put("BANK_CREDIT_APPLICATION", iMap.getBigDecimal("BASVURU_NO"));
			sMap.put("TIMEOUT", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", new GMMap().put("PARAMETRE", "WEBKREDI_SIGORTA_TIMEOUT")).get("DEGER"));
			sMap.put("PARAM_REF_TUR", "BIR_BASVURU");
			sMap.put("PARAM_REF_ID", iMap.getBigDecimal("BASVURU_NO"));
			
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if (birBasvuru != null) {

				odMap.put("KREDI_TURU", birBasvuru.getKrediTur());
				odMap.put("ODEME_TIP_KOD", birBasvuru.getOdemeTipKod());
				odMap.put("KANAL_KOD", birBasvuru.getKanalKodu());
				odMap.put("DOVIZ_KOD", birBasvuru.getDovizKodu());
				odMap.put("ODEME_TIP_VADE", birBasvuru.getOdemeTipVade());

				odMap.put("KREDI_TUTARI", iMap.getBigDecimal("TUTAR"));
				odMap.put("TUTAR", iMap.getBigDecimal("TUTAR"));
				odMap.put("KAMPANYA_KODU", iMap.getBigDecimal("KAMP_KOD"));
				odMap.put("KAMP_URUN_ADI", iMap.getBigDecimal("KAMP_KOD"));
				odMap.put("KREDI_VADE", iMap.getBigDecimal("VADE"));
				odMap.put("VADE", iMap.getBigDecimal("VADE"));
				odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
				
				sMap.put("CAPITAL_REPAYMENT", 0, "ORDER", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_NO"));
				sMap.put("CAPITAL_REPAYMENT", 0, "DUE", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_TARIHI"));
				sMap.put("CAPITAL_REPAYMENT", 0, "AMOUNT", odrMap.get("KREDI_TUTARI"));

				for (int num = 1; odrMap.getSize("ODEME_PLANI") > num; num++) {
					sMap.put("CAPITAL_REPAYMENT", num, "ORDER", odrMap.get("ODEME_PLANI", num, "OP_TAKSIT_NO"));
					sMap.put("CAPITAL_REPAYMENT", num, "DUE", odrMap.get("ODEME_PLANI", num, "OP_TAKSIT_TARIHI"));
					sMap.put("CAPITAL_REPAYMENT", num, "AMOUNT", odrMap.get("ODEME_PLANI", num-1, "OP_KALAN_TUTAR"));
				}

				if (odrMap.getSize("ODEME_PLANI") > 0) {
					sMap.put("CREDIT", 0, "PAYMENT_TERM", odrMap.get("VADE"));
					sMap.put("CREDIT", 0, "PAYMENT_PERIOD", birBasvuru.getOdemeTipPeriyod());
					sMap.put("CREDIT", 0, "PREMIUM_PAYMENT_TERM", 1);
					sMap.put("CREDIT", 0, "COVERAGE_PERIOD", odrMap.get("VADE"));
					sMap.put("CREDIT", 0, "CREDIT_AMOUNT", odrMap.get("KREDI_TUTARI"));
					sMap.put("CREDIT", 0, "INITIAL_COVERAGE_AMOUNT", odrMap.get("KREDI_TUTARI"));
					sMap.put("CREDIT", 0, "INTEREST_RATE", odrMap.get("FAIZ_ORAN"));
				}

				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				
				if ("E".equalsIgnoreCase(iMap.getString("IPAZ_EH"))) {
					try {
						Holder<String> resultCodeH = new Holder<String>();
						Holder<String> resultMessageH = new Holder<String>();
						InsuranceProcessClient.fibaKvkkOnay(birBasvuruKimlik.getTcKimlikNo(), "E".equalsIgnoreCase(iMap.getString("IPAZ_SMS_EH", "H")) ? "1" : "0", "E".equalsIgnoreCase(iMap.getString("IPAZ_TEL_EH", "H")) ? "1" : "0", "E".equalsIgnoreCase(iMap.getString("IPAZ_EMAIL_EH", "H")) ? "1" : "0", resultCodeH, resultMessageH);
					}
					catch (Exception e) {
						e.printStackTrace();
					}
				}
				sMap.put("POLICY_INSURED", 0, "TCKNO", birBasvuru.getTcKimlikNo());
				sMap.put("POLICY_INSURED", 0, "NAME", birBasvuruKimlik.getAd());
				sMap.put("POLICY_INSURED", 0, "SURNAME", birBasvuruKimlik.getSoyad());
				sMap.put("POLICY_INSURED", 0, "FATHER_NAME", birBasvuruKimlik.getBabaAd());
				sMap.put("POLICY_INSURED", 0, "MOTHER_NAME", birBasvuruKimlik.getAnneAdi());
				sMap.put("POLICY_INSURED", 0, "SURNAME", birBasvuruKimlik.getSoyad());
				sMap.put("POLICY_INSURED", 0, "BIRTHDAY", DateUtil.formatDate(birBasvuruKimlik.getDogumTar(), "yyyyMMdd"));
				sMap.put("POLICY_INSURED", 0, "GENDER", birBasvuruKimlik.getCinsiyet());
				sMap.put("POLICY_INSURED", 0, "GSM_AREA_CODE", birBasvuruKimlik.getCepTelAlanKodu());
				sMap.put("POLICY_INSURED", 0, "GSM_NO", birBasvuruKimlik.getCepTelNo());
				sMap.put("POLICY_INSURED", 0, "GSM_NO", birBasvuruKimlik.getCepTelNo());
				sMap.put("POLICY_INSURED", 0, "TEL_AREA_CODE", birBasvuruKimlik.getEvTelAlan());
				sMap.put("POLICY_INSURED", 0, "TEL_NO", birBasvuruKimlik.getEvTelNo());
				sMap.put("POLICY_INSURED", 0, "EMAIL", birBasvuruKimlik.getEMail());
				
				apsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_APS_INFO", iMap));
				if(apsMap.get("ADRES_NO") != null && !"0".equals(apsMap.getString("ADRES_NO"))){
					apsMap.putAll(ConsumerLoanTRN3171Services.getAPSAddressObject(apsMap));
					
					sMap.put("POLICY_INSURED_ADDRESS", 0, "ADDRESS", apsMap.getString("ADRES"));
					sMap.put("POLICY_INSURED_ADDRESS", 0, "CITY_CODE", apsMap.getString("ADRES_IL_KOD"));
					sMap.put("POLICY_INSURED_ADDRESS", 0, "TOWN_CODE", apsMap.getString("ADRES_ILCE_KOD"));
					sMap.put("POLICY_INSURED_ADDRESS", 0, "CITY_NAME", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '" + apsMap.getString("ADRES_IL_KOD") + "'"));
					sMap.put("POLICY_INSURED_ADDRESS", 0, "COUNTRY_NAME", "T�RK�YE");
					sMap.put("POLICY_INSURED_ADDRESS", 0, "COUNTRY", 119);
				}
				
				GMMap cMap = null;
				if ("TEKLIF".equalsIgnoreCase(iMap.getString("SERVIS_TIPI"))) {
					cMap = GMServiceExecuter.call("BNSPR_EXT_PROPOSAL_CREDIT_LIFE", sMap);
					oMap.put("POLICE_NO", cMap.get("PROPOSALS", 0, "EBS_PROPOSAL_ID"));
					if (oMap.get("POLICE_NO") != null) {
						GMMap proposalMap = (GMMap) cMap.get("PROPOSALS", 0, "PREMIUM");
						oMap.put("PRIM_TUTARI", proposalMap.get("PREMIUMS", 0, "GROSS_PREMIUM"));
					}else{
						GMMap spMap = sigortaPrimiHesapla(iMap);
						oMap.put("PRIM_TUTARI", spMap.get("PRIM_TUTARI"));
						oMap.put("POLICE_NO", "1");
					}
				}
				else {	
					GMMap uMap = new GMMap();
					if("E".equals(iMap.getString("POLICELESTIR"))){
						cMap = GMServiceExecuter.call("BNSPR_EXT_ISSUE_CREDIT_LIFE", sMap);
						oMap.put("POLICE_NO", cMap.get("INSURANCE_COMPANY_POLICY_NO"));
						oMap.put("PRIM_TUTARI", cMap.get("GROSS_PREMIUM"));
						
						uMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						uMap.put("PRIM_TUTARI", oMap.get("PRIM_TUTARI"));
						uMap.put("POLICE_NO", oMap.get("POLICE_NO"));
						
						if (uMap.get("POLICE_NO") != null && !StringUtils.isEmpty(uMap.getString("POLICE_NO"))) {
							List<Object> list = session.createQuery("from TemTeminatMain t, TemTeminatDetail td where t.teminatNo = td.teminatNo and td.teminatKod = '03"
									+ "' and t.basvuruNo=" + uMap.getString("BASVURU_NO")).list();
							if(list.size() > 0){
								Object[] obj =  (Object[])list.get(0);
								TemTeminatMain teminatMain = (TemTeminatMain)obj[0];
								teminatMain.setDurumKodu("P");
								session.save(teminatMain);
								TemTeminatDetail teminatDetail = (TemTeminatDetail)obj[1];
								teminatDetail.setSigortaTutari(uMap.getBigDecimal("PRIM_TUTARI"));
								teminatDetail.setPoliceNo(uMap.getString("POLICE_NO"));
								session.save(teminatDetail);
								session.flush();
							}else{
								GMServiceExecuter.execute("BNSPR_TRN3182_OTOMATIK_TEMINAT", uMap);
							}
							birBasvuru.setSigortaPrimi(uMap.getBigDecimal("PRIM_TUTARI"));
							session.save(birBasvuru);
							session.flush();
						}
					}else{
						cMap = GMServiceExecuter.call("BNSPR_EXT_PROPOSAL_CREDIT_LIFE", sMap);
						oMap.put("POLICE_NO", cMap.get("PROPOSALS", 0, "EBS_PROPOSAL_ID"));
						if (oMap.get("POLICE_NO") != null) {
							GMMap proposalMap = (GMMap) cMap.get("PROPOSALS", 0, "PREMIUM");
							oMap.put("PRIM_TUTARI", proposalMap.get("PREMIUMS", 0, "GROSS_PREMIUM"));
						}
						
						if (oMap.get("PRIM_TUTARI") == null || StringUtils.isEmpty(oMap.getString("PRIM_TUTARI"))) {
							GMMap spMap = sigortaPrimiHesapla(iMap);
							oMap.put("PRIM_TUTARI", spMap.get("PRIM_TUTARI"));
						}
						
						odMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						odMap.put("ONAY_TUTAR", iMap.get("ONAY_TUTAR"));
						odMap.put("ODEME_TIPI", iMap.get("ODEME_TIPI"));
						odMap.put("ODEME_VADESI", iMap.get("ODEME_VADESI"));
						
						odMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_TEMINATLAR", odMap));
						odMap.put("TEMINAT_TABLE", odMap.get("TEMINAT_LIST"));
						odMap.put("KAMP_KOD", iMap.getBigDecimal("KAMP_KOD"));
						uMap.put("APPLICATION_DETAIL", odMap);
						uMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
						uMap.put("VALIDASYON_EH", "H");
						uMap.put("PRIM_TUTARI", oMap.get("PRIM_TUTARI"));
						
						GMServiceExecuter.executeNT("BNSPR_CL_WEB_UPDATE_APPLICATION", uMap);
						
						if (oMap.get("POLICE_NO") == null || StringUtils.isEmpty(oMap.getString("POLICE_NO"))) {
							oMap.put("POLICE_NO", "1");
						}
					}
				}

				oMap.put("RESULT_CODE", cMap.get("RESULT_CODE"));
				oMap.put("ERROR_DESCRIPTION", cMap.get("ERROR_DESCRIPTION"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_ISSUE_CREDIT_LIFE_JOB")
	public static GMMap issueCreditLifeJob(GMMap iMap) {
		GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        String basvuruNo = null;
        int denemeSay = 0;
        StringBuilder body = new StringBuilder();
        GMMap sMap = null;
        GMMap cMap = null;
        GMMap odMap = new GMMap();
		GMMap odrMap = new GMMap();
		GMMap apsMap = new GMMap();
		try{
			GMMap pMap = new GMMap();
			pMap.put("PARAMETRE", "WEBKREDI_SIGORTA_DENEME_SAY");
			oMap.put("SIGORTA_DENEME_SAY", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", pMap).getInt("DEGER"));
			
        	Session session = DAOSession.getSession("BNSPRDal");
            conn = DALUtil.getGMConnection();            
            stmt = conn.prepareCall("{ call pkg_webkredi.sigorta_tanzim_job_data(?) }");
            stmt.registerOutParameter(1, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);

            while (rSet.next()) {
            	sMap = new GMMap();
            	try{
	            	basvuruNo = rSet.getString(1);
	            	denemeSay = rSet.getInt(2);
	            	
	            	sMap.put("APPLICATION_CODE", "BANKASURANS");
	    			sMap.put("START_DATE", DateUtil.formatDate(new Date(), "yyyyMMdd"));
	    			sMap.put("PRODUCT_CODE", 665);
	    			sMap.put("BANK_CREDIT_APPLICATION", basvuruNo);
	    			sMap.put("TIMEOUT", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", new GMMap().put("PARAMETRE", "WEBKREDI_SIGORTA_TIMEOUT")).get("DEGER"));
	    			sMap.put("PARAM_REF_TUR", "BIR_BASVURU");
	    			sMap.put("PARAM_REF_ID", basvuruNo);
	    			
	    			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", new BigDecimal(basvuruNo))).uniqueResult();

    				odMap.put("KREDI_TURU", birBasvuru.getKrediTur());
    				odMap.put("ODEME_TIP_KOD", birBasvuru.getOdemeTipKod());
    				odMap.put("KANAL_KOD", birBasvuru.getKanalKodu());
    				odMap.put("DOVIZ_KOD", birBasvuru.getDovizKodu());

    				odMap.put("KREDI_TUTARI", birBasvuru.getOnayTutar());
    				odMap.put("TUTAR", birBasvuru.getOnayTutar());
    				odMap.put("KAMPANYA_KODU", birBasvuru.getKampKod());
    				odMap.put("KAMP_URUN_ADI", birBasvuru.getKampKod());
    				odMap.put("KREDI_VADE", birBasvuru.getVade());
    				odMap.put("VADE", birBasvuru.getVade());
    				odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
    				
    				sMap.put("CAPITAL_REPAYMENT", 0, "ORDER", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_NO"));
    				sMap.put("CAPITAL_REPAYMENT", 0, "DUE", odrMap.get("ODEME_PLANI", 0, "OP_TAKSIT_TARIHI"));
    				sMap.put("CAPITAL_REPAYMENT", 0, "AMOUNT", odrMap.get("KREDI_TUTARI"));

    				for (int num = 1; odrMap.getSize("ODEME_PLANI") > num; num++) {
    					sMap.put("CAPITAL_REPAYMENT", num, "ORDER", odrMap.get("ODEME_PLANI", num, "OP_TAKSIT_NO"));
    					sMap.put("CAPITAL_REPAYMENT", num, "DUE", odrMap.get("ODEME_PLANI", num, "OP_TAKSIT_TARIHI"));
    					sMap.put("CAPITAL_REPAYMENT", num, "AMOUNT", odrMap.get("ODEME_PLANI", num-1, "OP_KALAN_TUTAR"));
    				}

    				if (odrMap.getSize("ODEME_PLANI") > 0) {
    					sMap.put("CREDIT", 0, "PAYMENT_TERM", odrMap.get("VADE"));
    					sMap.put("CREDIT", 0, "PAYMENT_PERIOD", birBasvuru.getOdemeTipPeriyod());
    					sMap.put("CREDIT", 0, "PREMIUM_PAYMENT_TERM", 1);
    					sMap.put("CREDIT", 0, "COVERAGE_PERIOD", odrMap.get("VADE"));
    					sMap.put("CREDIT", 0, "CREDIT_AMOUNT", odrMap.get("KREDI_TUTARI"));
    					sMap.put("CREDIT", 0, "INITIAL_COVERAGE_AMOUNT", odrMap.get("KREDI_TUTARI"));
    					sMap.put("CREDIT", 0, "INTEREST_RATE", odrMap.get("FAIZ_ORAN"));
    				}

    				BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", new BigDecimal(basvuruNo))).uniqueResult();
    				
    				sMap.put("POLICY_INSURED", 0, "TCKNO", birBasvuru.getTcKimlikNo());
    				sMap.put("POLICY_INSURED", 0, "NAME", birBasvuruKimlik.getAd());
    				sMap.put("POLICY_INSURED", 0, "SURNAME", birBasvuruKimlik.getSoyad());
    				sMap.put("POLICY_INSURED", 0, "FATHER_NAME", birBasvuruKimlik.getBabaAd());
    				sMap.put("POLICY_INSURED", 0, "MOTHER_NAME", birBasvuruKimlik.getAnneAdi());
    				sMap.put("POLICY_INSURED", 0, "SURNAME", birBasvuruKimlik.getSoyad());
    				sMap.put("POLICY_INSURED", 0, "BIRTHDAY", DateUtil.formatDate(birBasvuruKimlik.getDogumTar(), "yyyyMMdd"));
    				sMap.put("POLICY_INSURED", 0, "GENDER", birBasvuruKimlik.getCinsiyet());
    				sMap.put("POLICY_INSURED", 0, "GSM_AREA_CODE", birBasvuruKimlik.getCepTelAlanKodu());
    				sMap.put("POLICY_INSURED", 0, "GSM_NO", birBasvuruKimlik.getCepTelNo());
    				sMap.put("POLICY_INSURED", 0, "GSM_NO", birBasvuruKimlik.getCepTelNo());
    				sMap.put("POLICY_INSURED", 0, "TEL_AREA_CODE", birBasvuruKimlik.getEvTelAlan());
    				sMap.put("POLICY_INSURED", 0, "TEL_NO", birBasvuruKimlik.getEvTelNo());
    				sMap.put("POLICY_INSURED", 0, "EMAIL", birBasvuruKimlik.getEMail());
    				
    				iMap.put("BASVURU_NO", basvuruNo);
    				
    				apsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_APS_INFO", iMap));
    				if(apsMap.get("ADRES_NO") != null && !"0".equals(apsMap.getString("ADRES_NO"))){
    					apsMap.putAll(ConsumerLoanTRN3171Services.getAPSAddressObject(apsMap));
    					
    					sMap.put("POLICY_INSURED_ADDRESS", 0, "ADDRESS", apsMap.getString("ADRES"));
    					sMap.put("POLICY_INSURED_ADDRESS", 0, "CITY_CODE", apsMap.getString("ADRES_IL_KOD"));
    					sMap.put("POLICY_INSURED_ADDRESS", 0, "TOWN_CODE", apsMap.getString("ADRES_ILCE_KOD"));
    					sMap.put("POLICY_INSURED_ADDRESS", 0, "CITY_NAME", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '" + apsMap.getString("ADRES_IL_KOD") + "'"));
    					sMap.put("POLICY_INSURED_ADDRESS", 0, "COUNTRY_NAME", "T�RK�YE");
    					sMap.put("POLICY_INSURED_ADDRESS", 0, "COUNTRY", 119);
    				}
	            	
					cMap = GMServiceExecuter.call("BNSPR_EXT_ISSUE_CREDIT_LIFE", sMap);
					cMap.put("POLICE_NO", cMap.get("INSURANCE_COMPANY_POLICY_NO"));
					cMap.put("PRIM_TUTARI", cMap.get("GROSS_PREMIUM"));
	            	
					if (cMap.get("POLICE_NO") != null && !StringUtils.isEmpty(cMap.getString("POLICE_NO"))) {
						List<Object> list = session.createQuery("from TemTeminatMain t, TemTeminatDetail td where t.teminatNo = td.teminatNo and td.teminatKod = '03"
								+ "' and t.basvuruNo=" + basvuruNo).list();
						if(list.size() > 0){
							Object[] obj =  (Object[])list.get(0);
							TemTeminatDetail teminatDetail = (TemTeminatDetail)obj[1];
							teminatDetail.setSigortaTutari(cMap.getBigDecimal("PRIM_TUTARI"));
							teminatDetail.setPoliceNo(cMap.getString("POLICE_NO"));
							session.save(teminatDetail);
							session.flush();
						}
					}else{
						if(denemeSay == oMap.getInt("SIGORTA_DENEME_SAY")){
							body.append("<!DOCTYPE html><html lang=\"en\"><head></head><body>");
							body.append("<div style\"margin:20px 0\">").append("Ba�vuru No: ").append(basvuruNo).append("</div>");
							body.append("<div style\"margin:20px 0\">").append("Hata: ").append(cMap.getString("RESPONSE_MESSAGE")).append("</div>");
							body.append("</body></html>");
							
							GMMap mailMap = new GMMap();
							mailMap.put("MAIL_TO", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", new GMMap().put("PARAMETRE", "WEBKREDI_SIGORTA_HATA_MAIL_TO")).getString("DEGER"));
							mailMap.put("TRX_NO", iMap.getString("ISLEM_NO"));
							mailMap.put("MAIL_FROM", "System@aktifbank.com.tr");
							mailMap.put("MAIL_SUBJECT", "Web Kredi Sigorta Tanzim Job - Hata");
							mailMap.put("MAIL_BODY", body.toString());
							mailMap.put("IS_BODY_HTML", "E");
							GMServiceExecuter.call("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
						}
					}
            	}
				catch(Exception e){
					if(!"".equals(basvuruNo)){
						LOGGER.error(basvuruNo + " no lu basvuruda hata alindi!");
					}
					e.printStackTrace();
				}
            }
			return oMap;
	    } catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    } finally {
	        GMServerDatasource.close(rSet);
	        GMServerDatasource.close(stmt);
	        GMServerDatasource.close(conn);
	    }
	}

	/**
	 * BASVURU_NO, DURUM_KOD zorunlu
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_UPDATE_DEBIT_CARD_REQUEST")
	public static GMMap kartTalepGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			List<KartBasvuruTalep> list = session.createCriteria(KartBasvuruTalep.class).add(Restrictions.eq("referansNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("durumKod", new BigDecimal(-1))).list();
			if (list.size() > 0) {
				iMap.put("ID", list.get(0).getId());
				GMServiceExecuter.execute("BNSPR_DEBIT_COMMON_SAVE_OR_UPDATE_CARD_REQUEST", iMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_CL_WEB_AUTOMATIC_AGREEMENT_PROCESS")
	public static GMMap autoAgreementProcess(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		String kullaniciKod = GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", null).getString("KULLANICI_KOD");
		try {
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO", iMap));
			if ("E".equals(sMap.getString("SOZLESME_BASILDI"))) {
				/** kullanici WEB olarak guncelle **/
				GMMap sorguMap = new GMMap();
				sorguMap.put("KULLANICI_KOD", "WEB");
				sorguMap.put("HATA_VERILSIN_MI", Constants.EVET);
				GMServiceExecuter.call("BNSPR_KK_SET_USER_GLOBALS", sorguMap);

				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));

				sMap.put("TRX_NO", iMap.get("TRX_NO"));
				sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sMap.put("EKRAN_NO", "3181");

				if ("8".equals(sMap.getString("ODEME_TIPI"))) {
					Calendar c = Calendar.getInstance();
					c.setTime(new Date());
					c.add(Calendar.DATE, sMap.getInt("ODEME_VADESI"));
					sMap.put("TAKSIT_GUNU", c.get(Calendar.DAY_OF_MONTH));
				}
				else {
					sMap.put("TAKSIT_GUNU", Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
					sMap.put("GECIKME_GUN_SAYISI", 0);
				}

				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_SAVE", sMap));

				sMap.put("BELGE_KONTROL", true);
				sMap.put("TEYIT_GEREKLI", false);
				sMap.put("KANAL_KODU", "8");
				for (int i = 0; i < sMap.getSize("TBL_BELGE"); i++) {
					sMap.put("TBL_BELGE", i, "ALINDI", true);
				}
				sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", sMap));

				/** kullanici eskiye geri al **/
				sorguMap.put("KULLANICI_KOD", kullaniciKod);
				sorguMap.put("HATA_VERILSIN_MI", Constants.EVET);
				GMServiceExecuter.call("BNSPR_KK_SET_USER_GLOBALS", sorguMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * Call Center basvuru akisina almadan once business validasyonlari servisi
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_CCKREDI_VALIDATION")
	public static GMMap cckrediValidation(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			// kontakt musteri kontrolu 5284
			// degerlendirmede basvuru varmi 5275
			// on onayli limit aktif mi 5285

			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirAdkBasvuru adk = null;
			if (iMap.get("BASVURU_NO") != null) {
				adk = (BirAdkBasvuru) session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("krediTurKod", BigDecimal.ONE)).uniqueResult();
			}
			else {
				adk = (BirAdkBasvuru) session.get(BirAdkBasvuru.class, iMap.getBigDecimal("ON_ONAY_ID"));
			}
			
			oMap.put("KANAL_KODU", "5");
			if (adk != null) {
				iMap.put("TC_KIMLIK_NO", adk.getTcKimlikNo());
				oMap.put("TC_KIMLIK_NO", adk.getTcKimlikNo());

				/*
				/** degerlendirmede basvuru var mi **/
				List<BirBasvuru> list = session.createQuery("from BirBasvuru where tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and krediTur <> '5' and (durumKodu = 'KUL' or (durumKodu='DOGRULAMA' and sozlesmeBasildiEh = 'E'))").list();

				if (list.size() > 0) {
					oMap.put("RESPONSE_CODE", 5275);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", oMap.getString("RESPONSE_CODE"))).get("ERROR_MESSAGE"));
					return oMap;
				}

				oMap.putAll(GMServiceExecuter.call("BNSPR_CL_GET_ON_ONAY_BILGI", iMap));

				if (oMap.get("BASVURU_NO") == null) {
					oMap.put("RESPONSE_CODE", 5285);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", oMap.getString("RESPONSE_CODE"))).get("ERROR_MESSAGE"));
					return oMap;
				}

				GMMap mMap = new GMMap();
				mMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
				mMap.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", mMap));
				oMap.put("MUSTERI_NO", mMap.get("MUSTERI_NO"));
				oMap.put("CALISMA_SEKLI", mMap.get("CALISMA_SEKLI"));
				oMap.put("UNVAN", mMap.get("UNVAN"));
				oMap.put("EMAIL", mMap.get("EMAIL_KISISEL"));
				GMMap telMap = new GMMap();
				telMap.put("CUSTOMER_NO", mMap.get("MUSTERI_NO"));
				telMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_PHONE_LIST", telMap));
				for (int i = 0; i < telMap.getSize("RESULTS"); i++) {
					if ("3".equals(telMap.getString("RESULTS", i, "TEL_TIP"))) {
						oMap.put("CEP_TEL_ALAN_KODU", telMap.get("RESULTS", i, "ALAN_KODU"));
						oMap.put("CEP_TEL_NO", telMap.get("RESULTS", i, "TELEFON_NO"));
					}
				}
				oMap.put("TAKSIT_GUNU", Calendar.getInstance().get(Calendar.DAY_OF_MONTH));

				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_TRN3112.FarkFaiziOdemeSekli(?)}");
				stmt.registerOutParameter(1, -10);
				stmt.setBigDecimal(2, oMap.getBigDecimal("KAMPANYA_KODU"));
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(1);
				String listName = "FAIZ_ODEME_SEKLI_LIST";
				while (rSet.next()) {
					GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString("KEY1"), rSet.getString("TEXT"));
				}
			}
			else {
				BirBasvuru basvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("kanalKodu", "8")).add(Restrictions.in("durumKodu", Arrays.asList("DOGRULAMA", "SOZLESME", "BASVURU"))).add(Restrictions.gt("onayTutar", BigDecimal.ZERO)).uniqueResult();

				if (basvuru != null) {
					iMap.put("TC_KIMLIK_NO", basvuru.getTcKimlikNo());
					oMap.put("TC_KIMLIK_NO", basvuru.getTcKimlikNo());
					oMap.put("KREDI_TURU", basvuru.getKrediTur());
					oMap.put("DOVIZ_KOD", basvuru.getDovizKodu());
					oMap.put("VADE", basvuru.getVade());
					oMap.put("TUTAR", basvuru.getTutar());
					oMap.put("KANAL_KODU", basvuru.getKanalKodu());

					/** degerlendirmede basvuru var mi **/
					List<BirBasvuru> list = session.createQuery("from BirBasvuru where tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and krediTur <> '5' and (durumKodu = 'KUL' or (durumKodu='DOGRULAMA' and sozlesmeBasildiEh = 'E'))").list();

					if (list.size() > 0) {
						oMap.put("RESPONSE_CODE", 5275);
						oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", oMap.getString("RESPONSE_CODE"))).get("ERROR_MESSAGE"));
						return oMap;
					}

					GMMap mMap = new GMMap();
					mMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
					mMap.putAll(GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", mMap));
					oMap.put("MUSTERI_NO", mMap.get("MUSTERI_NO"));
					oMap.put("CALISMA_SEKLI", mMap.get("CALISMA_SEKLI"));
					oMap.put("UNVAN", mMap.get("UNVAN"));
					oMap.put("EMAIL", mMap.get("EMAIL_KISISEL"));
					GMMap telMap = new GMMap();
					telMap.put("CUSTOMER_NO", mMap.get("MUSTERI_NO"));
					telMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_PHONE_LIST", telMap));
					for (int i = 0; i < telMap.getSize("RESULTS"); i++) {
						if ("3".equals(telMap.getString("RESULTS", i, "TEL_TIP"))) {
							oMap.put("CEP_TEL_ALAN_KODU", telMap.get("RESULTS", i, "ALAN_KODU"));
							oMap.put("CEP_TEL_NO", telMap.get("RESULTS", i, "TELEFON_NO"));
						}
					}
					oMap.put("TAKSIT_GUNU", Calendar.getInstance().get(Calendar.DAY_OF_MONTH));

					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{? = call PKG_TRN3112.FarkFaiziOdemeSekli(?)}");
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, oMap.getBigDecimal("KAMPANYA_KODU"));
					stmt.execute();
					rSet = (ResultSet) stmt.getObject(1);
					String listName = "FAIZ_ODEME_SEKLI_LIST";
					while (rSet.next()) {
						GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString("KEY1"), rSet.getString("TEXT"));
					}
				}
				else {
					oMap.put("RESPONSE_CODE", 5285);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", oMap.getString("RESPONSE_CODE"))).get("ERROR_MESSAGE"));
					return oMap;
				}
			}
			oMap.put("RESPONSE_CODE", "00");
			oMap.put("RESPONSE_MESSAGE", "");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	/**
	 * Call center - mevcut basvuru iptal servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_CC_CANCEL_APPLICATION")
	public static GMMap ccCancelApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			List<BirBasvuru> list = session.createQuery("from BirBasvuru where tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and krediTur = '1' and durumKodu in ('BASVURU', 'SOZLESME')").list();

			iMap.put("AKSIYON_KARAR_KOD", ConsumerLoanCommonServices.nvl(iMap.getString("AKSIYON_KARAR_KOD"), "3"));
			for (BirBasvuru birBasvuru : list) {
				iMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
				GMServiceExecuter.call("BNSPR_TRN3172_BASVURU_IPTAL", iMap);
			}

			oMap.put("RESPONSE_CODE", "00");
			oMap.put("RESPONSE_MESSAGE", "");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Call center - on bilgi dokuman mail gonderim servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_CC_SAVE_BEFORE_AGGREMENT_DOCUMENT")
	public static GMMap ccSaveBeforeAggrementDocument(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			GMMap dMap = new GMMap();
			dMap.put("APPLICATION_NO", iMap.get("BASVURU_NO"));
			dMap.put("MAIL_TRANSFER", true);
			dMap.put("DYS_TRANSFER", true);
			dMap.put("EMAIL_TO", iMap.get("EMAIL_TO"));
			dMap.put("EMAIL_TYPE", iMap.get("EMAIL_TYPE"));
			dMap.put("EMAIL_NAME", iMap.get("EMAIL_NAME"));
			dMap.put("EMAIL_SURNAME", iMap.get("EMAIL_SURNAME"));
			dMap.put("EMAIL_CARD_NO", iMap.get("EMAIL_CARD_NO"));
			dMap.put("SEND_ATTACHMENTS", iMap.get("SEND_ATTACHMENTS"));
			dMap.put("DOC_LIST", 0, "CODE", iMap.get("BELGE_KODU"));
			
			// M��teriye gidecek mailde ad,soyad gibi alanlar g�z�kmeyecek
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			
			parameters.put("KISISEL_BILGI_GIZLE_EH", "E");
			dMap.put("PARAMETERS", parameters);
			
			dMap.put("DYS_TRANSFER", false);
			dMap.put("SEND_ATTACHMENTS", true);
			GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
			
			// DYS'ye at�lacak dok�manda t�m bilgiler yer alacak 
			dMap.put("DYS_TRANSFER", true);
			dMap.put("MAIL_TRANSFER", false);
			parameters.clear();
			dMap.put("PARAMETERS", parameters);
			GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Call center - adres bilgileri ekrani dolduran servis
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_CC_GET_CUSTOMER_ADDRESS")
	public static GMMap ccGetCustomerAddress(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap addMap = new GMMap();
			addMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			addMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_ADDRESS_LIST", addMap));
			oMap.put("YAZISMA_ADRESI_EV", false);
			oMap.put("YAZISMA_ADRESI_IS", false);
			for (int i = 0; i < addMap.getSize("RESULTS"); i++) {
				if ("E".equals(addMap.getString("RESULTS", i, "ADRES_TIPI"))) {
					oMap.put("EV_IL", addMap.get("RESULTS", i, "IL_KODU"));
					oMap.put("EV_ILCE", addMap.get("RESULTS", i, "ILCE_KODU"));
					oMap.put("EV_ADRESI", addMap.get("RESULTS", i, "ADRES"));
					oMap.put("YAZISMA_ADRESI_EV", GuimlUtil.convertToCheckBoxSelected(addMap.getString("RESULTS", i, "ILETISIM_ADRES_SECENEGI")));
				}
				else if ("I".equals(addMap.getString("RESULTS", i, "ADRES_TIPI"))) {
					oMap.put("IS_IL", addMap.get("RESULTS", i, "IL_KODU"));
					oMap.put("IS_ILCE", addMap.get("RESULTS", i, "ILCE_KODU"));
					oMap.put("IS_ADRESI", addMap.get("RESULTS", i, "ADRES"));
					oMap.put("ISYERI_ADI", addMap.get("RESULTS", i, "ISYERI_ADI"));
					oMap.put("YAZISMA_ADRESI_IS", GuimlUtil.convertToCheckBoxSelected(addMap.getString("RESULTS", i, "ILETISIM_ADRES_SECENEGI")));
				}
			}
			if (!oMap.getBoolean("YAZISMA_ADRESI_EV") && !oMap.getBoolean("YAZISMA_ADRESI_IS")) {
				oMap.put("YAZISMA_ADRESI_EV", true);
			}

			GMMap telMap = new GMMap();
			telMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
			telMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_PHONE_LIST", telMap));
			for (int i = 0; i < telMap.getSize("RESULTS"); i++) {
				if ("2".equals(telMap.getString("RESULTS", i, "TEL_TIP"))) {
					oMap.put("IS_TEL_KOD", telMap.get("RESULTS", i, "ALAN_KODU"));
					oMap.put("IS_TEL_NO", telMap.get("RESULTS", i, "TELEFON_NO"));
					oMap.put("IS_TEL_DAHILI", telMap.get("RESULTS", i, "DAHILI_NO"));
				}
				else if ("1".equals(telMap.getString("RESULTS", i, "TEL_TIP"))) {
					oMap.put("EV_TEL_KOD", telMap.get("RESULTS", i, "ALAN_KODU"));
					oMap.put("EV_TEL_NO", telMap.get("RESULTS", i, "TELEFON_NO"));
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Anne kizlik soyadi ekrandan rastgele girilen karekterlerin dogrulugunun kontrolunu yapar.
	 * 
	 * ebru.peker
	 * 
	 * @param iMap
	 * @return boolean
	 */
	@GraymoundService("BNSPR_CL_CC_MOTHER_SURNAME_VALIDATION")
	public static GMMap ccMotherSurnameValidation(GMMap iMap) {
		GMMap oMap = new GMMap();
		String enteredFirstCharecter = iMap.getString("FIRST_ENTERED_CHARECTER");
		String enteredSecondCharecter = iMap.getString("SECOND_ENTERED_CHARECTER");
		String surname = iMap.getString("MOTHER_MAIDEN_SURNAME");
		Integer index1 = Integer.parseInt(iMap.getString("INDEX_1"));
		Integer index2 = Integer.parseInt(iMap.getString("INDEX_2"));
		boolean checkSurName = false;

		checkSurName = surname.substring(index1 - 1, index1).equalsIgnoreCase(enteredFirstCharecter) && surname.substring(index2 - 1, index2).equalsIgnoreCase(enteredSecondCharecter);

		oMap.put("RESULT", checkSurName);

		return oMap;

	}

	/**
	 * Musteriye ait anne kizlik soyadi bilgisi ve random se�ilen index bilgisi doner.
	 * 
	 * ebru.peker
	 * 
	 * @param iMap
	 * @return boolean
	 */
	@GraymoundService("BNSPR_CL_CC_MOTHER_SURNAME_GET_INFO")
	public static GMMap ccMotherSurnameGetInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap indexMap = new GMMap();
		int index1 = 0;
		int index2 = 0;
		oMap.put("MOTHER_SURNAME", GMServiceExecuter.execute("BNSPR_CUSTOMER_GET_MOTHER_MAIDEN_SURNAME", iMap).get("MOTHER_MAIDEN_SURNAME"));
		indexMap.putAll(GMServiceExecuter.execute("BNSPR_CUSTOMER_GET_MOTHER_MAIDEN_SURNAME_RANDOM_CHAR_SEQ", iMap));
		index1 = indexMap.getInt("INDEX_1");
		index2 = indexMap.getInt("INDEX_2");

		oMap.put("INDEX_1", index1 < index2 ? index1 : index2);
		oMap.put("INDEX_2", index1 < index2 ? index2 : index1);

		return oMap;
	}

	@GraymoundService("BNSPR_CL_KART_BHS_KONTROL")
	public static GMMap getKartBhsKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("KK_BHS", DALUtil.callOneParameterFunction("{? = call PKG_TFF_RM_DOKUMAN.Musteri_Kart_BHS_varmi(?)}", Types.VARCHAR, iMap.getBigDecimal("MUSTERI_NO")));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * @author mehmet.uluturk
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CAMPAIGN_LIST")
	public static GMMap getWebCampaignList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		GnlParametre gnlParametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "WEBKREDI_KAMP_KOD")).uniqueResult();

		if (gnlParametre != null && !gnlParametre.getDeger().isEmpty()) {
			String[] kampKodlari = gnlParametre.getDeger().split("\\*");

			int satir = 0;
			String tableName = "KAMPANYA_LISTE";

			for (String kampKod : kampKodlari) {

				BirKampanya kampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", new BigDecimal(kampKod))).uniqueResult();

				GMMap sMap = new GMMap();
				sMap.put("KAMP_URUN_ADI", kampKod);
				sMap.put("KANAL_KOD", 8);
				sMap.put("DOVIZ_KODU", "TRY");
				sMap.put("KREDI_TURU", 1);
				GMMap rMap = (GMMap) GMServiceExecuter.call("BNSPR_TRN3171_GET_KREDI_MIN_MAX_DEGER", sMap);
				rMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", sMap));
				oMap.put(tableName, satir, "KAMP_KOD", kampKod);
				oMap.put(tableName, satir, "KAMPANYA_ADI", kampanya.getAciklama());
				oMap.put(tableName, satir, "FAIZSIZ_SURE", kampanya.getFaizsizSure());
				oMap.put(tableName, satir, "MIN_TUTAR", rMap.get("MIN_TUTAR"));
				oMap.put(tableName, satir, "MAX_TUTAR", rMap.get("MAX_TUTAR"));
				oMap.put(tableName, satir, "MIN_VADE", rMap.get("MIN_VADE"));
				oMap.put(tableName, satir, "MAX_VADE", rMap.get("MAX_VADE"));
				oMap.put(tableName, satir, "MIN_MAX_TUTAR", rMap.get("MIN_MAX_TUTAR"));
				oMap.put(tableName, satir, "MIN_MAX_VADE", rMap.get("MIN_MAX_VADE"));
				oMap.put(tableName, satir, "ODEME_TIP_TABLE", rMap.get("ODEME_TIP_TABLE"));

				satir++;
			}
		}

		return oMap;
	}

	/**
	 * Web kredi KDH - mevcut basvuru iptal servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_KDH_CANCEL_APPLICATION")
	public static GMMap kdhCancelApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			List<BirBasvuru> list = session.createQuery("from BirBasvuru where tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and krediTur = '5' and durumKodu in ('SOZLESME', 'DOGRULAMA')").list();

			iMap.put("AKSIYON_KARAR_KOD", ConsumerLoanCommonServices.nvl(iMap.getString("AKSIYON_KARAR_KOD"), "3"));
			for (BirBasvuru birBasvuru : list) {
				iMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
				GMServiceExecuter.call("BNSPR_TRN3172_BASVURU_IPTAL", iMap);
			}

			oMap.put("RESPONSE_CODE", "00");
			oMap.put("RESPONSE_MESSAGE", "");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Web Kredi KDH basvuru yaratma servisi
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CREATE_KDH_APPLICATION")
	public static GMMap createKDHApplication(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		GMMap kpsMap = new GMMap();
		GMMap apsMap = new GMMap();
		String otpTelKod = null;
		String otpTel = null;
		
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			GMMap appMap = new GMMap();
			if ("5".equals(iMap.getString("KANAL_KODU"))) {
				appMap.putAll(iMap);
				appMap.remove("KPS_DATA");
			}
			else {
				appMap.putAll(iMap.getMap("APPLICATION_DETAIL"));
			}

			/** KUL durumunda basvurusu var mi ? **/
			List<BirBasvuru> list = session.createQuery("from BirBasvuru where tcKimlikNo='" + appMap.getString("TC_KIMLIK_NO") + "' and krediTur = '5' and durumKodu in ('KUL')").list();
			if (list.size() > 0) {
				oMap.put("RESPONSE_CODE", 5503);
				oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5503)).get("ERROR_MESSAGE"));
				return oMap;
			}

			/** Tan�ml� kdh var mi **/
			appMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_AKTIF_KDH_VARMI", appMap));
			if ("E".equals(appMap.getString("AKTIF_KDH_VARMI"))) {
				oMap.put("RESPONSE_CODE", 5503);
				oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5503)).get("ERROR_MESSAGE"));
				return oMap;
			}

			/** KPS Sorgusu ve Kontrolleri **/
			iMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));

			kpsMap.put("TCKNO", appMap.getString("TC_KIMLIK_NO"));
			kpsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", kpsMap));

			if (kpsMap.getString("TCKNO_OUT") != null) {
				if ("5".equals(kpsMap.getString("DURUMU"))) {
					oMap.put("RESPONSE_CODE", 5207);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5207)).get("ERROR_MESSAGE"));
					return oMap;
				}
				if (kpsMap.getString("OLUM_TARIHI") != null) {
					oMap.put("RESPONSE_CODE", 5219);
					oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5219)).get("ERROR_MESSAGE"));
					return oMap;
				}
				else {
					iMap.put("DOGUM_TARIHI", kpsMap.getDate("DOGUM_TARIHI"));
					try {
						GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
					}
					catch (Exception e) {
						oMap.put("RESPONSE_CODE", 5220);
						oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5220)).get("ERROR_MESSAGE"));
						return oMap;
					}
				}
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_DOGRULAMA", kpsMap));
				kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KAYIP_KIMLIK_SORGULAMA", iMap));
			}
			else {
				oMap.put("RESPONSE_CODE", 5208);
				oMap.put("RESPONSE_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", new GMMap().put("MESSAGE_NO", 5208)).get("ERROR_MESSAGE"));
				return oMap;
			}

			/** varsa onceki basvurular iptal edilecek **/
			GMServiceExecuter.execute("BNSPR_CL_KDH_CANCEL_APPLICATION", appMap);

			/** Default KDH kampanya ve tutar bilgileri **/
			GMMap pMap = new GMMap();
			pMap.put("PARAMETRE", "WEBKREDI_KDH_KAMP_KOD");
			appMap.put("KAMP_KOD", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", pMap).getInt("DEGER"));
			if (appMap.get("TUTAR") == null) {
				appMap.put("TUTAR", appMap.get("MAKSIMUM_LIMIT"));
			}
			appMap.put("VADE", "1");

			/** musteri yarat (Web kanalinda normalde musteri yarat�l�yor ama yine de konuldu) **/
			iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			apsMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			apsMap.put("TC_KIMLIK_NO", appMap.getString("TC_KIMLIK_NO"));
			apsMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_APS_SORGULAMA", apsMap));

			sMap.put("KANAL_KODU", appMap.getString("KANAL_KODU", "8"));
			sMap.put("KANAL_ALT_KODU", appMap.getString("KANAL_ALT_KOD"));
			sMap.put("URUN_KAMP_KOD", appMap.getString("URUN_KAMP_KOD"));
			sMap.put("SERI_NO", kpsMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", kpsMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", ("2").equals(kpsMap.getString("CINSIYET_KOD")) ? "K" : "E");
			sMap.putAll(kpsMap);
			sMap.putAll(apsMap);
			sMap.put("BABA_ADI", sMap.getString("BABA_AD"));
			sMap.put("ANNE_ADI", sMap.getString("ANNE_AD"));
			sMap.put("TCK_NO", kpsMap.get("TCKNO"));
			sMap.put("ISIM", sMap.get("AD1"));
			sMap.put("IKINCI_ISIM", sMap.get("AD2"));
			sMap.put("SOYADI", sMap.get("SOYAD"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", ("2").equals(kpsMap.getString("CINSIYET_KOD")) ? "K" : "E");
			sMap.put("MEDENI_HAL_KOD", ("2").equals(sMap.get("MEDENI_HALI_KOD")) ? "1" : "2");
			sMap.put("NUFUS_AILE_SIRA_NO", sMap.get("AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("CILT_KODU"));
			sMap.put("SIRA_NO", sMap.get("BIREY_SIRA_NO"));
			sMap.put("VERILDIGI_YER", sMap.get("VERILDIGI_ILCE_ADI"));
			sMap.put("VERILDIGI_TARIH", sMap.get("VERILIS_TARIHI"));
			sMap.put("IL_KOD", kpsMap.get("IL_KODU"));
			sMap.put("ILCE_KOD", kpsMap.get("ILCE_KODU"));
			sMap.put("NUF_VERILIS_NEDENI", sMap.getString("VERILIS_NEDENI"));

			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}

			sMap.put("CEP_TEL_KOD", iMap.get("CEP_TEL_ALAN_KODU"));
			sMap.put("CEP_TEL_NO", iMap.get("CEP_TEL_NO"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_CREATE_KONTAKT_MUSTERI", sMap));
			oMap.put("MUSTERI_NO", sMap.getBigDecimal("MUSTERI_NO"));

			// kanal kullanicisi yarat..
			iMap.put("MUSTERI_NO", sMap.get("MUSTERI_NO"));
			iMap.put("USERNAME", appMap.getString("TC_KIMLIK_NO"));
			iMap.put("CHANNELS", 0, "CODE", "WEB");
			iMap.put("ROLES", 0, "CODE", "GNL");
			GMServiceExecuter.call("ADK_CREATE_USER", iMap);

			GMMap addMap = new GMMap();
			if ("passoligca".equals(iMap.getString("WEB_SATIS_KANALI")) && iMap.get("ILISKILI_BASVURU_NO") != null) {
				addMap.put("TCKN", appMap.getString("TC_KIMLIK_NO"));
				addMap.put("SOURCE", "NTS01");
				addMap.put("UYRUK", "TR");
				addMap.putAll(GMServiceExecuter.execute("BNSPR_TFF_UYE_BILGILERI_VER", addMap));
				/** Adres bilgileri gelmiyorsa musteriden alinacak **/
				if (StringUtils.isEmpty(appMap.getString("EV_ADRESI")) && StringUtils.isEmpty(appMap.getString("IS_ADRESI"))) {
					appMap.put("YAZISMA_ADRESI_EV", false);
					appMap.put("YAZISMA_ADRESI_IS", false);
					for (int i = 0; i < addMap.getSize("ADRES_LISTE"); i++) {
						if ("E".equals(addMap.getString("ADRES_LISTE", i, "ADRES_TIPI"))) {
							appMap.put("EV_IL", addMap.get("ADRES_LISTE", i, "IL_KODU"));
							appMap.put("EV_ILCE", addMap.get("ADRES_LISTE", i, "ILCE_KODU"));
							appMap.put("EV_ADRESI", addMap.get("ADRES_LISTE", i, "ACIK_ADRES"));
							appMap.put("YAZISMA_ADRESI_EV", GuimlUtil.convertToCheckBoxSelected(addMap.getString("ADRES_LISTE", i, "ILETISIM_ADRESI_MI")));
						}
						else if ("I".equals(addMap.getString("ADRES_LISTE", i, "ADRES_TIPI"))) {
							appMap.put("IS_IL", addMap.get("ADRES_LISTE", i, "IL_KODU"));
							appMap.put("IS_ILCE", addMap.get("ADRES_LISTE", i, "ILCE_KODU"));
							appMap.put("IS_ADRESI", addMap.get("ADRES_LISTE", i, "ACIK_ADRES"));
							appMap.put("ISYERI_ADI", addMap.get("ADRES_LISTE", i, "ISYERI_ADI"));
							appMap.put("YAZISMA_ADRESI_IS", GuimlUtil.convertToCheckBoxSelected(addMap.getString("ADRES_LISTE", i, "ILETISIM_ADRESI_MI")));
						}
					}
					if (!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")) {
						appMap.put("YAZISMA_ADRESI_EV", true);
					}
				}
				if (StringUtils.isEmpty(appMap.getString("IS_TEL_NO"))) {
					for (int i = 0; i < addMap.getSize("TELEFON_LISTE"); i++) {
						if ("2".equals(addMap.getString("TELEFON_LISTE", i, "TELEFON_TIPI"))) {
							appMap.put("IS_TEL_KOD", addMap.get("TELEFON_LISTE", i, "ALAN_KOD"));
							appMap.put("IS_TEL_NO", addMap.get("TELEFON_LISTE", i, "TELEFON_NUMARA"));
							appMap.put("IS_TEL_DAHILI", addMap.get("TELEFON_LISTE", i, "DAHILI_NO"));
						}
						else if ("3".equals(addMap.getString("TELEFON_LISTE", i, "TELEFON_TIPI")) && StringUtils.isEmpty(appMap.getString("CEP_TEL_NO"))) {
							appMap.put("CEP_TEL_KOD", addMap.get("TELEFON_LISTE", i, "ALAN_KOD"));
							appMap.put("CEP_TEL_NO", addMap.get("TELEFON_LISTE", i, "TELEFON_NUMARA"));
						}
					}
				}
				appMap.put("CALISMA_SEKLI", addMap.get("MUSTERI_BILGI", 0, "CALISMA_SEKLI"));
				appMap.put("OGRENIM_DURUMU", addMap.get("MUSTERI_BILGI", 0, "OGRENIM_DURUMU"));
				appMap.put("EMAIL", addMap.get("MUSTERI_BILGI", 0, "EMAIL"));
				appMap.put("ANNE_KIZLIK_SOYADI", addMap.get("MUSTERI_BILGI", 0, "ANNE_KIZLIK_SOYADI"));
				appMap.put("MESLEK", addMap.get("UYE_MESLEKI_BILGI", 0, "MESLEK"));
			}
			else {
				/** Adres bilgileri gelmiyorsa musteriden alinacak **/
				if (StringUtils.isEmpty(appMap.getString("EV_ADRESI")) && StringUtils.isEmpty(appMap.getString("IS_ADRESI"))) {
					addMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
					addMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_ADDRESS_LIST", addMap));
					appMap.put("YAZISMA_ADRESI_EV", false);
					appMap.put("YAZISMA_ADRESI_IS", false);
					for (int i = 0; i < addMap.getSize("RESULTS"); i++) {
						if ("E".equals(addMap.getString("RESULTS", i, "ADRES_TIPI"))) {
							appMap.put("EV_IL", addMap.get("RESULTS", i, "IL_KODU"));
							appMap.put("EV_ILCE", addMap.get("RESULTS", i, "ILCE_KODU"));
							appMap.put("EV_ADRESI", addMap.get("RESULTS", i, "ADRES"));
							appMap.put("YAZISMA_ADRESI_EV", GuimlUtil.convertToCheckBoxSelected(addMap.getString("RESULTS", i, "ILETISIM_ADRES_SECENEGI")));
						}
						else if ("I".equals(addMap.getString("RESULTS", i, "ADRES_TIPI"))) {
							appMap.put("IS_IL", addMap.get("RESULTS", i, "IL_KODU"));
							appMap.put("IS_ILCE", addMap.get("RESULTS", i, "ILCE_KODU"));
							appMap.put("IS_ADRESI", addMap.get("RESULTS", i, "ADRES"));
							appMap.put("ISYERI_ADI", addMap.get("RESULTS", i, "ISYERI_ADI"));
							appMap.put("YAZISMA_ADRESI_IS", GuimlUtil.convertToCheckBoxSelected(addMap.getString("RESULTS", i, "ILETISIM_ADRES_SECENEGI")));
						}
					}
					if (!iMap.getBoolean("YAZISMA_ADRESI_EV") && !iMap.getBoolean("YAZISMA_ADRESI_IS")) {
						appMap.put("YAZISMA_ADRESI_EV", true);
					}
				}
				if (StringUtils.isEmpty(appMap.getString("IS_TEL_NO"))) {
					GMMap telMap = new GMMap();
					telMap.put("CUSTOMER_NO", iMap.get("MUSTERI_NO"));
					telMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_PHONE_LIST", telMap));
					for (int i = 0; i < telMap.getSize("RESULTS"); i++) {
						if ("2".equals(telMap.getString("RESULTS", i, "TEL_TIP"))) {
							appMap.put("IS_TEL_KOD", telMap.get("RESULTS", i, "ALAN_KODU"));
							appMap.put("IS_TEL_NO", telMap.get("RESULTS", i, "TELEFON_NO"));
							appMap.put("IS_TEL_DAHILI", telMap.get("RESULTS", i, "DAHILI_NO"));
						}
						else if ("3".equals(telMap.getString("RESULTS", i, "TEL_TIP"))){
							if(StringUtils.isEmpty(appMap.getString("CEP_TEL_NO"))) {
								appMap.put("CEP_TEL_KOD", telMap.get("RESULTS", i, "ALAN_KODU"));
								appMap.put("CEP_TEL_NO", telMap.get("RESULTS", i, "TELEFON_NO"));
							}
							if("E".equals(telMap.getString("RESULTS", i, "OTP_MI"))){
								otpTelKod = telMap.getString("RESULTS", i, "ALAN_KODU");
								otpTel = telMap.getString("RESULTS", i, "TELEFON_NO");
							}
						}
					}
					if(!"".equals(otpTelKod)){
						appMap.put("CEP_TEL_KOD", otpTelKod); appMap.put("CEP_TEL_NO", otpTel);
					}
				}

				/** M��teri �zerindeki di�er bilgiler **/
				appMap.put("MUSTERI_NO", iMap.get("MUSTERI_NO"));
				GMMap mMap = GMServiceExecuter.call("BNSPR_CUST_GET_CUSTOMER_INFO", appMap);
				appMap.put("PERSON_ID", mMap.get("TC_KIMLIK_NO"));
				appMap.put("ANNE_KIZLIK_SOYADI", GMServiceExecuter.execute("BNSPR_CUSTOMER_GET_MOTHER_MAIDEN_SURNAME", appMap).get("MOTHER_MAIDEN_SURNAME"));
				appMap.put("KIMLIK_SERI_NO", mMap.getString("NUF_SERI_NO").substring(0, 3));
				appMap.put("KIMLIK_SIRA_NO", mMap.getString("NUF_SERI_NO").substring(3));
				appMap.put("SUBE_KOD", mMap.get("SUBE_KODU"));

				if (iMap.getMap("APPLICATION_DETAIL").getString("CALISMA_SEKLI") != null) {
					appMap.put("CALISMA_SEKLI", iMap.getMap("APPLICATION_DETAIL").getString("CALISMA_SEKLI"));
				}
				else {
					appMap.put("CALISMA_SEKLI", mMap.get("CALISMA_SEKLI"));
				}

				if (iMap.getMap("APPLICATION_DETAIL").getString("OGRENIM_DURUMU") != null) {
					appMap.put("OGRENIM_DURUMU", iMap.getMap("APPLICATION_DETAIL").getString("OGRENIM_DURUMU"));
				}
				else {
					appMap.put("OGRENIM_DURUMU", mMap.get("EGITIM_KOD"));
				}

				if (iMap.getMap("APPLICATION_DETAIL").getString("MESLEK") != null) {
					appMap.put("MESLEK", iMap.getMap("APPLICATION_DETAIL").getString("MESLEK"));
				}
				else {
					appMap.put("MESLEK", mMap.get("MESLEK_KOD"));
				}

				if (StringUtils.isEmpty(appMap.getString("EMAIL"))) {
					appMap.put("EMAIL", mMap.get("EMAIL_KISISEL"));
				}
			}

			appMap.put("AYLIK_GELIR", ConsumerLoanCommonServices.nvl(appMap.getString("AYLIK_GELIR"), "0"));
			appMap.put("ISYERINDE_CALISMA_SURESI_YIL", ConsumerLoanCommonServices.nvl(appMap.getString("ISYERINDE_CALISMA_SURESI_YIL"), "1"));
			appMap.put("ISYERINDE_CALISMA_SURESI_AY", ConsumerLoanCommonServices.nvl(appMap.getString("ISYERINDE_CALISMA_SURESI_AY"), "1"));

			/** Kdh turu bul **/
			iMap.put("KANAL_KODU", appMap.getString("KANAL_KODU", "8"));
			appMap.put("KMH_TUR_KOD", GMServiceExecuter.execute("BNSPR_TRN3013_GET_VARSAYILAN_KDH_TUR", iMap).get("KDH_TURU"));

			/** kps datasini basvuruya uygun hale getir. **/
			kpsMap.put("ADI", kpsMap.remove("AD1"));
			kpsMap.put("IKINCI_ADI", kpsMap.remove("AD2"));
			kpsMap.put("SOYADI", kpsMap.remove("SOYAD"));
			kpsMap.put("NUFUS_VERILIS_TARIHI", kpsMap.remove("VERILIS_TARIHI"));
			kpsMap.put("BABA_ADI", kpsMap.remove("BABA_AD"));
			kpsMap.put("ANNE_ADI", kpsMap.remove("ANNE_AD"));
			kpsMap.put("NUFUS_MAHALLE", kpsMap.remove("MAHALLE_KOY"));
			kpsMap.put("KIMLIK_SERI_NO_KPS", kpsMap.remove("KIMLIK_SERI_NO"));
			kpsMap.put("KIMLIK_SIRA_NO_KPS", kpsMap.remove("KIMLIK_SIRA_NO"));
			kpsMap.put("NUFUS_IL_KOD", kpsMap.remove("IL_KODU"));
			kpsMap.put("NUFUS_ILCE_KOD", kpsMap.remove("ILCE_KODU"));
			kpsMap.put("NUFUS_CILT_NO", kpsMap.remove("CILT_KODU"));
			kpsMap.put("NUFUS_AILE_SIRA_NO", kpsMap.remove("AILE_SIRA_NO"));
			kpsMap.put("NUFUS_SIRA_NO", kpsMap.get("BIREY_SIRA_NO"));
			if (kpsMap.get("CINSIYET") != null) {
				kpsMap.put("CINSIYET", ((String) kpsMap.remove("CINSIYET")).substring(0, 1));
			}
			if (kpsMap.get("MEDENI_HALI") != null) {
				kpsMap.put("MEDENI_HAL", ((String) kpsMap.remove("MEDENI_HALI")).substring(0, 1).equals("E") ? 1 : 2);
			}
			kpsMap.put("KAYIP_CUZDAN_NO", kpsMap.remove("KAYIP_CUZDAN_NO"));
			kpsMap.put("KAYIP_CUZDAN_SERI", kpsMap.remove("KAYIP_CUZDAN_SERI"));
			kpsMap.put("NUF_VERILIS_NEDENI", kpsMap.remove("VERILIS_NEDENI"));
			kpsMap.put("NUF_VERILDIGI_YER", kpsMap.remove("VERILDIGI_ILCE_ADI"));
			if (kpsMap.get("KIMLIK_SERI_NO_KPS") != null && kpsMap.get("KIMLIK_SIRA_NO_KPS") != null && kpsMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && kpsMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				kpsMap.put("NUFUS_CUZDANI_SERI_NO", kpsMap.getString("KIMLIK_SERI_NO_KPS").concat(kpsMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}

			appMap.putAll(kpsMap);

			// validasyonlar
			sMap.put("KRD_TUR_KOD", appMap.getBigDecimal("KRD_TUR_KOD", new BigDecimal(5)));
			sMap.put("KAMP_URUN_ADI", appMap.getString("KAMP_KOD"));
			sMap.put("DOVIZ_KODU", appMap.getString("DOVIZ_KODU", "TRY"));
			sMap.put("KREDI_TUTARI", appMap.getBigDecimal("TUTAR"));
			sMap.put("KREDI_VADESI", appMap.getBigDecimal("VADE"));
			sMap.put("KANAL_KOD", appMap.getBigDecimal("KANAL_KOD", new BigDecimal(8)));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", sMap);

			sMap.put("TUTAR", appMap.getBigDecimal("TUTAR"));
			sMap.put("VADE", appMap.getBigDecimal("VADE"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", sMap));
			appMap.put("KAMP_KNL_KOD", sMap.get("KAMP_KNL_KOD"));

			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", sMap);

			sMap.put("DOVIZ_KOD", sMap.getString("DOVIZ_KODU"));
			sMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", sMap));
			sMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", sMap));
			appMap.put("FAIZ_ORANI", sMap.get("FAIZ_ORAN"));
			appMap.put("SOZLESME_FAIZI", sMap.get("SOZLESME_ORANI"));
			appMap.put("KATILIM_BEDELI", sMap.get("MAX_KATKI_PAYI"));
			appMap.put("DOSYA_MASRAFI", sMap.get("MAX_DOSYA_MASRAFI"));

			sMap.clear();
			sMap.put("KAMP_KOD", appMap.get("KAMP_KOD"));
			sMap.put("TCKN", appMap.getString("TC_KIMLIK_NO"));
			GMServiceExecuter.execute("BNSPR_TRN3171_KAMPANYA_KULLANILABILIR_MI", sMap);

			// basvuru no yarat. Ononay limitinden basvuru no da gelebilir. incelenecek.
			if (appMap.getString("BASVURU_NO") == null || appMap.getString("BASVURU_NO").isEmpty()) {
				appMap.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", iMap).getBigDecimal("ID"));
			}

			sMap.clear();
			sMap.put("BASVURU_NO", appMap.getBigDecimal("BASVURU_NO"));
			sMap.put("CEP_TEL_ALAN", appMap.getString("CEP_TEL_KOD"));
			sMap.put("CEP_TEL_NO", appMap.getString("CEP_TEL_NO"));
			sMap.put("TC_KIMLIK_NO", appMap.getString("TC_KIMLIK_NO"));
			sMap.put("KANAL_KODU", appMap.getString("KANAL_KODU", "8"));
			sMap.put("KANAL_ALT_KODU", appMap.getString("KANAL_ALT_KOD"));
			sMap.put("KREDI_TURU", appMap.getString("KRD_TUR_KOD", "5"));
			GMServiceExecuter.execute("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU", sMap);

			appMap.put("EKRAN_NO", "3171");
			appMap.put("URUN_KAMP_KOD", appMap.get("KAMP_KOD"));

			if (appMap.getString("TRX_NO") == null || appMap.getString("TRX_NO").isEmpty()) {
				appMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			appMap.put("ODEME_TIPI", "2");
			appMap.put("KRD_TUR_KOD", appMap.getString("KRD_TUR_KOD", "5"));
			appMap.put("KANAL_KOD", appMap.getString("KANAL_KODU", "8"));
			appMap.put("DOVIZ_KOD", appMap.getString("DOVIZ_KODU", "TRY"));
			appMap.put("KIMLIK_SERI_NO", appMap.get("KIMLIK_SERI_NO_KPS"));
			appMap.put("KIMLIK_SIRA_NO", appMap.get("KIMLIK_SIRA_NO_KPS"));
			if (appMap.get("EMAIL") != null && !appMap.getString("EMAIL").isEmpty()) {
				Object[] inputValues = new Object[4];
				inputValues[0] = BnsprType.STRING;
				inputValues[1] = appMap.getString("EMAIL");
				Object[] outputValues = new Object[0];
				String proc = "{ call pkg_trn10011.e_mail_check(?) }";
				DALUtil.callOracleProcedure(proc, inputValues, outputValues);

				appMap.put("EMAIL1", appMap.getString("EMAIL").substring(0, appMap.getString("EMAIL").indexOf('@')));
				appMap.put("EMAIL2", appMap.getString("EMAIL").substring(appMap.getString("EMAIL").indexOf('@') + 1));
			}
			else {
				if ("5".equals(iMap.getString("KANAL_KODU"))) {
					ConsumerLoanCommonServices.raiseGMError("330", "EMAIL");
				}
			}
			appMap.put("KPS_YAPILDI", "E");

			GMMap outMap = new GMMap();
			outMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_SAVE_TEMP", appMap));
			iMap.put("MUSTERI_YARATMA_TX_NO", outMap.getBigDecimal("MUSTERI_YARATMA_TX_NO"));
			iMap.put("MUSTERI_NO", outMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("BASVURU_NO", appMap.get("BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_UPDATE_MUSTERI_NO", iMap));
			oMap.put("BASVURU_NO", appMap.get("BASVURU_NO"));
			oMap.put("TRX_NO", appMap.get("TRX_NO"));

			/*
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_DEVAM_SORGULAR", appMap));

			if ("E".equals(oMap.getString("DEVAM"))) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", appMap));
			}*/
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", appMap));
			GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE", oMap);

			KmhFaizOran kmhFaizOran = (KmhFaizOran) session.get(KmhFaizOran.class, appMap.getBigDecimal("KMH_TUR_KOD"));
			if (kmhFaizOran != null) {
				oMap.put("KDH_FAIZ_ORANI", kmhFaizOran.getFaizOrani().divide(new BigDecimal(12)).setScale(2, RoundingMode.HALF_UP));
				oMap.put("KDH_GECIKME_FAIZ_ORANI", kmhFaizOran.getGecikmeFaizOrani().divide(new BigDecimal(12)).setScale(2, RoundingMode.HALF_UP));
			}

			BirAdkBasvuru adkBasvuru = (BirAdkBasvuru) session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("id", iMap.getBigDecimal("ILISKILI_BASVURU_NO"))).uniqueResult();

			if (adkBasvuru != null && "NKOLAY".equalsIgnoreCase(adkBasvuru.getAktarimKanali())) {
				oMap.put("WEB_AKTARIM_KANALI_MI", true);
			}
			else {
				oMap.put("WEB_AKTARIM_KANALI_MI", false);
			}

			oMap.put("RESPONSE_CODE", "00");
			oMap.put("RESPONSE_MESSAGE", "");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * Web Kredi KDH basvuru sozlesmesi kayit yaratan servis
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CREATE_KDH_AGREEMENT")
	public static GMMap createKDHAggrement(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		String mesaj = "";
		String cepTel = "";
		try {
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO", iMap));

			oMap.put("CALISMA_SEKLI_KOD", sMap.get("CALISMA_SEKLI_KOD"));
			oMap.put("TBL_BELGE", sMap.get("TBL_BELGE"));

			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			sMap.put("TRX_NO", iMap.get("TRX_NO"));
			sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sMap.put("EKRAN_NO", "3181");
			if (iMap.containsKey("TAKSIT_GUNU")) {
				sMap.put("TAKSIT_GUNU", iMap.get("TAKSIT_GUNU"));
				sMap.put("AY_SONU", iMap.get("AY_SONU"));
				sMap.put("FAIZ_ODEME_SEKLI", iMap.get("FAIZ_ODEME_SEKLI"));
				sMap.put("GECIKME_GUN_SAYISI", iMap.get("GECIKME_GUN_SAYISI"));
			}
			else {
				sMap.put("TAKSIT_GUNU", Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
			}
			sMap.put("SOZLESME_ADRESI_APSMI", "E");

			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_SAVE", sMap));

			oMap.put("TRX_NO", sMap.get("TRX_NO"));

			for (int i = 0; i < sMap.getSize("TBL_BELGE"); i++) {
				sMap.put("TBL_BELGE", i, "ALINDI", true);
			}

			sMap.put("BELGE_KONTROL", true);
			sMap.put("TEYIT_GEREKLI", false);
			sMap.put("KANAL_KODU", iMap.getString("KANAL_KODU", "8"));
			sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", sMap));

			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			session.refresh(birBasvuru);

			cepTel = birBasvuruKimlik.getCepTelAlanKodu().concat(birBasvuruKimlik.getCepTelNo());
			iMap.put("P1", birBasvuruKimlik.getSoyad());
			iMap.put("P2", birBasvuru.getOnayTutar());
			iMap.put("MESSAGE_NO", new java.math.BigDecimal(5507));

			mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
			if (!"".equals(cepTel) && !"".equals(mesaj)) {
				GMMap smsMap = new GMMap();
				smsMap.put("MSISDN", cepTel);
				smsMap.put("CONTENT", mesaj);
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
			}

			/** Sozlesme Basildi Yap **/
			GMServiceExecuter.execute("BNSPR_TRN3181_SOZLEZME_BASIM_EH", iMap);

			oMap.put("DURUM_KODU", birBasvuru.getDurumKodu());

			/** Kart talebini guncelle **/
//			if (iMap.get("PROCESS_TYPE") != null) {
//				GMMap cMap = new GMMap();
//				cMap.put("PROCESS_TYPE", iMap.get("PROCESS_TYPE"));
//				cMap.put("CL_APPLICATION_NO", iMap.get("BASVURU_NO"));
//				cMap.put("TFF_APPLICATION_NO", iMap.get("TFF_APPLICATION_NO"));
//				cMap.put("KK_APPLICATION_NO", iMap.get("KK_APPLICATION_NO"));
//				cMap.put("CARD_NO", iMap.get("CARD_NO"));
//				cMap.put("KANAL", "WEB");
//				if ("DOGRULAMA".equals(birBasvuru.getDurumKodu())) {
//					cMap.put("DURUM_KOD", new BigDecimal(-1));
//				}
//				else {
//					cMap.put("DURUM_KOD", BigDecimal.ZERO);
//				}
//				cMap.put("ONAY_FLAG", "TRUE");
//				GMServiceExecuter.execute("BNSPR_CL_CREATE_DEBIT_CARD_REQUEST", cMap);
//			}

			GnlMusteri musteri = (GnlMusteri) session.get(GnlMusteri.class, birBasvuru.getMusteriNo());
			session.refresh(musteri);

			sMap.put("MUSTERI_KONTAKT", musteri.getMusteriKontakt());

			sMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", sMap));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_CL_KART_BHS_KONTROL", sMap));

			if ("M".equals(sMap.getString("MUSTERI_KONTAKT")) && ("E".equals(sMap.getString("F_BHS")) || "E".equals(sMap.getString("KK_BHS"))) && !"webcrdca".equals(birBasvuru.getWebSatisKanali())) {
				if ("KUL".equals(birBasvuru.getDurumKodu())) {
					// kullandir..
					GMMap kMap = new GMMap();
					kMap.put("TRX_ONAYSIZ_ISLEM", "E");
					kMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					kMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
					kMap.put("MUSTERI_KONTAKT", "M");
					kMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_OTOMATIK_KULLANDIR", kMap));

					/** odeme plani maille gonderim **/
					KmhBireyselBasvuru kmhBireyselBasvuru = (KmhBireyselBasvuru) session.get(KmhBireyselBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));

					GMMap dMap = new GMMap();
					dMap.put("APPLICATION_NO", iMap.getBigDecimal("BASVURU_NO"));
					dMap.put("MAIL_TRANSFER", true);
					dMap.put("DYS_TRANSFER", true);
					dMap.put("EMAIL_TO", birBasvuruKimlik.getEMail());
					dMap.put("EMAIL_NAME", birBasvuruKimlik.getAd());
					dMap.put("EMAIL_SURNAME", birBasvuruKimlik.getSoyad());
					dMap.put("EMAIL_TYPE", "KDH");
					dMap.put("KDH_LIMIT", birBasvuru.getOnayTutar());
					dMap.put("HESAP_NO", kmhBireyselBasvuru.getHesapNo());

					List<?> belge = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();
					int k = 0;
					for (int row = 0; row < belge.size(); row++) {
						BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge.get(row);
						if (!"582".equals(birBasvuruBelge.getId().getDokumanKod())) {
							dMap.put("DOC_LIST", k, "CODE", birBasvuruBelge.getId().getDokumanKod());
							k++;
						}
					}
					
					// M��teriye gidecek mailde ad,soyad gibi alanlar g�z�kmeyecek
					HashMap<String, Object> parameters = new HashMap<String, Object>();
					
					parameters.put("KISISEL_BILGI_GIZLE_EH", "E");
					dMap.put("PARAMETERS", parameters);
					
					dMap.put("DYS_TRANSFER", false);
					dMap.put("SEND_ATTACHMENTS", true);
					GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
					
					// DYS'ye at�lacak dok�manda t�m bilgiler yer alacak 
					dMap.put("DYS_TRANSFER", true);
					dMap.put("MAIL_TRANSFER", false);
					parameters.clear();
					dMap.put("PARAMETERS", parameters);
					GMServiceExecuter.executeAsync("BNSPR_CREATE_WEB_CREDIT_DOCUMENTS", dMap);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/**
	 * Web Kredi SMS �n onay kayit yaratan servis
	 * Sonuca g�re sms g�nderir
	 * 
	 * ahmet.karaman
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_CL_WEB_CREATE_SMS_PREAPPROVE")
	public static GMMap createSmsApprove(GMMap iMap) {
		GMMap oMap = new GMMap();
		String mesaj = null;
		String cepTel = null;
		BigDecimal eventTypeNo = BigDecimal.valueOf(89);
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap odrMap = new GMMap();
		GMMap odMap = new GMMap();
		GMMap odgMap = new GMMap();
		GMMap pMap = new GMMap();
		int gecerliGunSayisi;
		Session session = null;
		
		try{
			// onay - 5869  
			// ret - 5889
			// cep telefonu kontrol - 5870 ptt - 6164
			// teknik hata - 5871 ptt - 6165
			// ptt kontrol - 5872 - ptt - 6166
			// kimlik - 5873
			// yarim basvuru - 5888 ptt - 5977
			// ticari kredi - 5886
			cepTel = iMap.getString("CEP_TEL_ALAN_KODU").concat(iMap.getString("CEP_TEL_NO"));
			
			session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			
			if(!"DTU_CREDIT".equals(iMap.getString("CLIENT"))){
				List<BirBasvuru> list= null;
			
				if("PTT_CREDIT".equals(iMap.getString("CLIENT"))){
					list = session.createQuery("from BirBasvuru where tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and krediTur = '1' and kanalKodu = '7' and pttMaasAlinanKurum not in ('1', '2', '3') and durumKodu not in ('CEPTE', 'EVRAKSIZ', 'KAPANDI', 'IPTAL')").list();
				}else{
					list = session.createQuery("from BirBasvuru where tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and krediTur = '1' and kanalKodu = '8' and durumKodu in ('SOZLESME', 'BASVURU')").list();
				}
				
				if(list.size() > 0){
					if("PTT_CREDIT".equals(iMap.getString("CLIENT"))){
						oMap.put("RESPONSE_CODE", "5977");
					}else{
						oMap.put("RESPONSE_CODE", "5888");
					}
				}else{
					oMap.putAll(GMServiceExecuter.call("BNSPR_CL_WEBKREDI_VALIDATION_API", iMap)); 
				}
			}else{
				oMap.put("RESPONSE_CODE", "00");
				
				/** telefon kontrol **/ 
				GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).uniqueResult();
				List<GnlMusteriTelefon> telefon = null;
				if (musteri != null) {
					telefon = (List<GnlMusteriTelefon>) session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("alanKod", iMap.getString("CEP_TEL_ALAN_KODU"))).add(Restrictions.eq("telNo", iMap.getString("CEP_TEL_NO"))).add(Restrictions.eq("id.musteriNo", musteri.getMusteriNo())).list();
				
					if (telefon == null || telefon.size() == 0) {
						List<GnlMusteriTelefon> telefonList = (List<GnlMusteriTelefon>) session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("alanKod", iMap.getString("CEP_TEL_ALAN_KODU"))).add(Restrictions.eq("telNo", iMap.getString("CEP_TEL_NO"))).list();
	
						if (telefonList != null && telefonList.size() > 0) {
							oMap.put("RESPONSE_CODE", "6134");
						}
					}
				}
			}
			
			if("00".equals(oMap.getString("RESPONSE_CODE"))){
				if("YIM_CREDIT".equals(iMap.getString("CLIENT"))){
					iMap.put("AKTARIM_KANALI", "YIM_SMS");
				}else if("PTT_CREDIT".equals(iMap.getString("CLIENT"))){
					iMap.put("AKTARIM_KANALI", "PTT_KREDI");
				}else if("DTU_CREDIT".equals(iMap.getString("CLIENT"))){
					iMap.put("AKTARIM_KANALI", "DTU_SMS");
					iMap.put("LIMIT_TURU", "D");
				}else{
					iMap.put("AKTARIM_KANALI", "SMS");
				}
				oMap.putAll(GMServiceExecuter.call("BNSPR_KREDI_ON_ONAYLI_BASVURU", iMap));
				
				if("00".equals(oMap.getString(Constants.RESPONSE))){
					/** Onay **/
					iMap.put("MESSAGE_NO", 5869);
					pMap.put("KOD", "BIR_ADK_BASVURU_GEC_SURE");
					pMap.put("KEY1", "KREDI");
					gecerliGunSayisi = GMServiceExecuter.call("BNSPR_CREDITCARD_GET_PARAM_TEXT", pMap).getInt("TEXT");
					if("PTT_CREDIT".equals(iMap.getString("CLIENT"))){
						iMap.put("P1", oMap.getString("KREDI_LIMIT"));
						iMap.put("P2", oMap.getString("ONAY_VADE"));
						iMap.put("P3", gecerliGunSayisi);
						iMap.put("P5", "7");
					}else if("YIM_CREDIT".equals(iMap.getString("CLIENT"))){
						iMap.put("P1", oMap.getMap("KPS_DATA").getString("SOYAD"));
						iMap.put("P2", oMap.getString("KREDI_LIMIT"));
						iMap.put("P3", oMap.getString("ONAY_VADE"));
						iMap.put("P4", gecerliGunSayisi);
						iMap.put("P5", "2");
					}else if("DTU_CREDIT".equals(iMap.getString("CLIENT"))){
						iMap.put("MESSAGE_NO", 6057);
						iMap.put("P1", oMap.getString("KREDI_LIMIT"));
						iMap.put("P2", gecerliGunSayisi);
						
						/** Nakit limit icin tekrar on onay olustur **/
						GMMap nMap = new GMMap();
						nMap.putAll(iMap);
						nMap.put("LIMIT_TURU", "O");
						nMap.put("AKTARIM_KANALI", "SMS");
						GMServiceExecuter.call("BNSPR_KREDI_ON_ONAYLI_BASVURU", nMap);
					}else{
						/** Web Sms **/
						iMap.put("P1", oMap.getMap("KPS_DATA").getString("SOYAD"));
						iMap.put("P2", oMap.getBigDecimal("KREDI_LIMIT"));
					
						/** debit kart sorgusu **/
						iMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
						iMap.put("BASVURU_NO", oMap.getString("BASVURU_NO"));
						GMServiceExecuter.execute("BNSPR_CL_GET_DEBIT_CARD_INFO", iMap);
						
						/** Evam event **/
						GMMap dataMap = new GMMap();
						
						conn = DALUtil.getGMConnection();
	
						query = "{? = call pkg_webkredi.Get_Evam_Info_Yarim_Basvuru(?)}";
						stmt = conn.prepareCall(query);
						stmt.registerOutParameter(1, -10);
						stmt.setString(2, oMap.getString("BASVURU_NO"));
						stmt.execute();
	
						rSet = (ResultSet) stmt.getObject(1);
						dataMap.putAll(DALUtil.rSetMap(rSet));
						
						dataMap.put("TUTAR", oMap.getBigDecimal("TUTAR"));
						dataMap.put("VADE", oMap.getBigDecimal("VADE"));
						dataMap.put("DOSYA_MASRAFI", oMap.getBigDecimal("DOSYA_MASRAFI"));
						
						/** taksit ve faiz **/
						odgMap.put("KAMP_URUN_ADI", dataMap.get("KAMP_KOD"));
						odgMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", odgMap));
						for (int index = 0; index < odgMap.getSize("ODEME_TIP_TABLE"); index++) {
							if ("7".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
								odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_VADE"));
							}
							else if ("8".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
								odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
							}
							odMap.put("ODEME_TIP_KOD", odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
						}
	
						odMap.put("KREDI_TUTARI", oMap.getBigDecimal("TUTAR"));
						odMap.put("TUTAR", oMap.getBigDecimal("TUTAR"));
						odMap.put("KAMPANYA_KODU", dataMap.get("KAMP_KOD"));
						odMap.put("KAMP_URUN_ADI", dataMap.get("KAMP_KOD"));
						odMap.put("KREDI_VADE", oMap.getBigDecimal("VADE"));
						odMap.put("VADE", oMap.getBigDecimal("VADE"));
						odMap.put("KREDI_TURU", "1");
						odMap.put("DOVIZ_KOD", "TRY");
						odMap.put("KANAL_KOD", "8");
						odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
						if (odMap.getInt("VADE") > 2) {
							dataMap.put("TAKSIT_TUTAR", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 2, "OP_TAKSIT_TUTAR"));
						}
						else {
							dataMap.put("TAKSIT_TUTAR", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 1, "OP_TAKSIT_TUTAR"));
						}
						dataMap.put("FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
						
						/** sigorta bilgileri */
						if(dataMap.get("SIGORTALI_KAMP_KOD") != null) {
							odrMap.clear();
							odgMap.put("KAMP_URUN_ADI", dataMap.get("SIGORTALI_KAMP_KOD"));
							odgMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", odgMap));
							for (int index = 0; index < odgMap.getSize("ODEME_TIP_TABLE"); index++) {
								if ("7".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
									odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_VADE"));
								}
								else if ("8".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
									odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
								}
								odMap.put("ODEME_TIP_KOD", odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
							}
		
							odMap.put("KAMPANYA_KODU", dataMap.get("SIGORTALI_KAMP_KOD"));
							odMap.put("KAMP_URUN_ADI", dataMap.get("SIGORTALI_KAMP_KOD"));
							odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
							if (odMap.getInt("VADE") > 2) {
								dataMap.put("SIGORTALI_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 2, "OP_TAKSIT_TUTAR"));
							}
							else {
								dataMap.put("SIGORTALI_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 1, "OP_TAKSIT_TUTAR"));
							}
							dataMap.put("SIGORTALI_FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
						}
						dataMap.put("CEP_TEL", cepTel);
						
						GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", new GMMap().put("SCENARIO_KEY",
								dataMap.getString("SCENARIO_KEY")).put("EVENT_TYPE_NO", eventTypeNo).put("EVENT_REF_NO",
								oMap.getString("BASVURU_NO")).put("INTEGRATION_TYPE", "S").put("DATA_MAP",
								dataMap));
					
						/** kampanya guncelleme **/
						List<BirBasvuruTx> txList = (List<BirBasvuruTx>) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("basvuruNo", oMap.getBigDecimal("BASVURU_NO"))).list();
						for (BirBasvuruTx birBasvuruTx : txList) {
							session.refresh(birBasvuruTx);
							birBasvuruTx.setKampKod(dataMap.getBigDecimal("KAMP_KOD"));
							birBasvuruTx.setFaizOrani(dataMap.getBigDecimal("FAIZ_ORANI"));
							session.saveOrUpdate(birBasvuruTx);
							session.flush();
						}
					}
				}else if("5801".equals(oMap.getString(Constants.RESPONSE)) || "5805".equals(oMap.getString(Constants.RESPONSE)) || "5808".equals(oMap.getString(Constants.RESPONSE)) || "5803".equals(oMap.getString(Constants.RESPONSE))){
					/** Red **/
					iMap.put("MESSAGE_NO", 5889);
					iMap.put("BASVURU_NO", oMap.getString("BASVURU_NO"));
				}else{
					if("PTT_CREDIT".equals(iMap.getString("CLIENT"))){
						iMap.put("MESSAGE_NO", 6165);
					}else{
						iMap.put("MESSAGE_NO", 5871);
					}
				}
			}else if("5204".equals(oMap.getString("RESPONSE_CODE")) || "5205".equals(oMap.getString("RESPONSE_CODE"))){
				if("PTT_CREDIT".equals(iMap.getString("CLIENT"))){
					iMap.put("MESSAGE_NO", 6164);
				}else{
					iMap.put("MESSAGE_NO", 5870);
				}
			}else if("5217".equals(oMap.getString("RESPONSE_CODE")) || "5220".equals(oMap.getString("RESPONSE_CODE"))){
				iMap.put("MESSAGE_NO", 5889);
			}else if("5218".equals(oMap.getString("RESPONSE_CODE"))){
				if("PTT_CREDIT".equals(iMap.getString("CLIENT"))){
					iMap.put("MESSAGE_NO", 6166);
				}else{
					iMap.put("MESSAGE_NO", 5872);
				}
			}else if("5208".equals(oMap.getString("RESPONSE_CODE"))){
				iMap.put("MESSAGE_NO", 5871);
			}else if("5219".equals(oMap.getString("RESPONSE_CODE"))){
				iMap.put("MESSAGE_NO", 5873);
			}else if("5210".equals(oMap.getString("RESPONSE_CODE"))){
				iMap.put("MESSAGE_NO", 5884);
			}else if("5211".equals(oMap.getString("RESPONSE_CODE"))){
				iMap.put("MESSAGE_NO", 5885);
			}else if("5275".equals(oMap.getString("RESPONSE_CODE"))){
				iMap.put("MESSAGE_NO", 5886);
			}else{
				iMap.put("MESSAGE_NO", oMap.getString("RESPONSE_CODE"));
			}
		}
		catch (Exception e) {
			LOGGER.error("BNSPR_CL_WEB_CREATE_SMS_PREAPPROVE err:" + iMap.toString(), e);
			e.printStackTrace();
			iMap.put("MESSAGE_NO", "5871");
		}finally{
			/** Log **/
			BirSmsOnonayLogId birSmsOnonayLogId = new BirSmsOnonayLogId();
			birSmsOnonayLogId.setBasvuruNo(oMap.getBigDecimal("BASVURU_NO"));
			birSmsOnonayLogId.setCepTelAlanKodu(iMap.getString("CEP_TEL_ALAN_KODU"));
			birSmsOnonayLogId.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			birSmsOnonayLogId.setClient(iMap.getString("CLIENT"));
			birSmsOnonayLogId.setMesajNo(iMap.getString("MESSAGE_NO"));
			birSmsOnonayLogId.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			BirSmsOnonayLog birSmsOnonayLog = new BirSmsOnonayLog();
			birSmsOnonayLog.setId(birSmsOnonayLogId);
			
			session.save(birSmsOnonayLog);
			 
			/** Sonu� sms olarak g�nderilir. **/
			mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
			if (!"".equals(cepTel) && !"".equals(mesaj)) {
				GMMap smsMap = new GMMap();
				smsMap.put("MSISDN", cepTel);
				smsMap.put("CONTENT", mesaj);
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
			}
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_CL_WEB_YARIM_BASVURU_JOB")
	public static GMMap yarimBasvuruJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		GMMap odrMap = new GMMap();
		GMMap odMap = new GMMap();
		GMMap odgMap = new GMMap();
		GMMap dataMap = new GMMap();
		BigDecimal eventTypeNo = BigDecimal.valueOf(63);
		String basvuruNo = null;
		
		try{
            conn = DALUtil.getGMConnection();            
            stmt = conn.prepareCall("{ call pkg_webkredi.yarim_basvuru_job_data(?) }");
            stmt.registerOutParameter(1, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);

            while (rSet.next()) {
            	try{
	            	basvuruNo = rSet.getString(1);
	            	
	            	query = "{? = call pkg_webkredi.Get_Evam_Info_Yarim_Basvuru(?)}";
					stmt = conn.prepareCall(query);
					stmt.registerOutParameter(1, -10);
					stmt.setString(2, basvuruNo);
					stmt.execute();

					rSet2 = (ResultSet) stmt.getObject(1);
					dataMap.putAll(DALUtil.rSetMap(rSet2));
					
					/** taksit ve faiz **/
					odgMap.put("KAMP_URUN_ADI", dataMap.get("KAMP_KOD"));
					odgMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", odgMap));
					for (int index = 0; index < odgMap.getSize("ODEME_TIP_TABLE"); index++) {
						if ("7".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
							odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_VADE"));
						}
						else if ("8".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
							odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
						}
						odMap.put("ODEME_TIP_KOD", odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
					}

					odMap.put("KREDI_TUTARI", dataMap.getBigDecimal("TUTAR"));
					odMap.put("TUTAR", dataMap.getBigDecimal("TUTAR"));
					odMap.put("KAMPANYA_KODU", dataMap.get("KAMP_KOD"));
					odMap.put("KAMP_URUN_ADI", dataMap.get("KAMP_KOD"));
					odMap.put("KREDI_VADE", dataMap.getBigDecimal("VADE"));
					odMap.put("VADE", dataMap.getBigDecimal("VADE"));
					odMap.put("KREDI_TURU", "1");
					odMap.put("DOVIZ_KOD", "TRY");
					odMap.put("KANAL_KOD", "8");
					odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
					if (odMap.getInt("VADE") > 2) {
						dataMap.put("TAKSIT_TUTAR", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 2, "OP_TAKSIT_TUTAR"));
					}
					else {
						dataMap.put("TAKSIT_TUTAR", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 1, "OP_TAKSIT_TUTAR"));
					}
					dataMap.put("FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
					
					/** sigorta bilgileri */
					if(dataMap.get("SIGORTALI_KAMP_KOD") != null) {
						odrMap.clear();
						odgMap.put("KAMP_URUN_ADI", dataMap.get("SIGORTALI_KAMP_KOD"));
						odgMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", odgMap));
						for (int index = 0; index < odgMap.getSize("ODEME_TIP_TABLE"); index++) {
							if ("7".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
								odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_VADE"));
							}
							else if ("8".equals(odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"))) {
								odMap.put("ODEME_TIP_VADE", odgMap.get("ODEME_TIP_TABLE", index, "MAX_PERIYOD"));
							}
							odMap.put("ODEME_TIP_KOD", odgMap.get("ODEME_TIP_TABLE", index, "ODEME_TIP_KOD"));
						}
	
						odMap.put("KAMPANYA_KODU", dataMap.get("SIGORTALI_KAMP_KOD"));
						odMap.put("KAMP_URUN_ADI", dataMap.get("SIGORTALI_KAMP_KOD"));
						odrMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER", odMap));
						if (odMap.getInt("VADE") > 2) {
							dataMap.put("SIGORTALI_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 2, "OP_TAKSIT_TUTAR"));
						}
						else {
							dataMap.put("SIGORTALI_AYLIK_TAKSIT", odrMap.get("ODEME_PLANI", odMap.getInt("VADE") - 1, "OP_TAKSIT_TUTAR"));
						}
						dataMap.put("SIGORTALI_FAIZ_ORANI", odrMap.get("FAIZ_ORANI"));
					}
					
					GMServiceExecuter.call("BNSPR_CORE_EVENT_CREATE_EVENT", new GMMap().put("SCENARIO_KEY",
							dataMap.getString("SCENARIO_KEY")).put("EVENT_TYPE_NO", eventTypeNo).put("EVENT_REF_NO",
									basvuruNo).put("INTEGRATION_TYPE", "S").put("DATA_MAP",
							dataMap));
            	}
				catch(Exception e){
					if(!"".equals(basvuruNo)){
						LOGGER.error(basvuruNo + " no lu basvuruda hata alindi!");
					}
					e.printStackTrace();
				}
            }
			return oMap;
	    } catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    } finally {
	        GMServerDatasource.close(rSet);
	        GMServerDatasource.close(stmt);
	        GMServerDatasource.close(conn);
	        GMServerDatasource.close(rSet2);
	    }
	}
            	
}
