package tr.com.calikbank.bnspr.consumerloan.netmera;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;
import com.graymound.util.GMRuntimeException;

public class OnOnayEventDetail implements INullController {

	@SerializedName("extId")
	private String tcKimlikNo;

	private Profile profile;

	public String getTcKimlikNo() {
		return tcKimlikNo;
	}

	public void setTcKimlikNo(String tcKimlikNo) {
		this.tcKimlikNo = tcKimlikNo;
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	@Override
	public String toString() {
		return "ClassPojo [extId = " + tcKimlikNo + ", profile = " + profile + "]";
	}

	public void checkNull() {
		Field fields[] = this.getClass().getDeclaredFields();
		for (Field f : fields) {
			try {
				Object value = f.get(this);
				if (value == null) {
					throw new GMRuntimeException(99, f.getName().toUpperCase()
							+ " degeri bos olamaz");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new GMRuntimeException(99, e.getMessage());
			}

		}
	}
}
